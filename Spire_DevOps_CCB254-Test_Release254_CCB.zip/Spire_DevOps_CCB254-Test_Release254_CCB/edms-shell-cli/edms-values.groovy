// EDMS Values CLI

def cli = new CliBuilder(
  usage: 'edms-values.groovy -f output.json -k key.key',
  header: '\nAvailable options (use -h for help):\n',
  footer: '\nInformation provided via above options is used to generate printed string.\n'
)

import org.apache.commons.cli.Option
import groovy.json.*

cli.with
{
  h(longOpt: 'help', 'Usage Information', required: false)
  f(longOpt: 'file', 'Config file', args: 1, required: true)
  k(longOpt: 'key', 'keys (separated by dot)', args: 1, required: true)
  j(longOpt: 'json', 'json output')
}
def opt = cli.parse(args)

if (!opt) return
if (opt.h) cli.usage()

String file = opt.f
String key = opt.k

// --- FIX 1: Validate file existence and content before parsing ---
File jsonFile = new File(file)
if (!jsonFile.exists()) {
    System.err.println "ERROR: File does not exist: ${file}"
    System.exit(1)
}

String fileText = jsonFile.text.trim()
if (fileText.isEmpty()) {
    System.err.println "ERROR: The file '${file}' is completely empty. The upstream pipeline step likely failed."
    System.exit(1)
}

// --- FIX 2: Use LAX parser to tolerate minor JSON formatting issues ---
def jsonSlurper = new JsonSlurper().setType(JsonParserType.LAX)

def fileJson
try {
    fileJson = jsonSlurper.parseText(fileText)
} catch (JsonException e) {
    System.err.println "ERROR: Failed to parse JSON. Content of file was:"
    System.err.println "----------------------------------------"
    System.err.println fileText
    System.err.println "----------------------------------------"
    System.err.println "Underlying Groovy Error: ${e.message}"
    System.exit(1)
}

key = key.replaceAll(/\.\[(\d+)\]/, '[\$1]')
def value = fileJson
for (String part : key.tokenize('.')) {
    def matcher = part =~ /^(.+?)\[(\d+)\]$/
    if (matcher.matches()) {
        String field = matcher[0][1]
        int index = matcher[0][2].toInteger()
        if (!(value instanceof Map) || !value.containsKey(field)) {
            System.err.println "Error: Key '${field}' not found."
            System.exit(1)
        }
        value = value[field]
        if (!(value instanceof List) || index >= value.size()) {
            System.err.println "Error: Array index ${index} out of bounds."
            System.exit(1)
        }
        value = value[index]
    }
    else {
        if (!(value instanceof Map) || !value.containsKey(part)) {
            System.err.println "Error: Key '${part}' not found."
            System.exit(1)
        }
        value = value[part]
    }
}
if (opt.j)
    println JsonOutput.toJson(value)
else
    println value
