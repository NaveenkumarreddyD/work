/*
 ***************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Bill is Ready File Upload (E-bill) - Send Notification
 * 
 *            
 ****************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2020-03-18   JLumbre SpireOne. CCB-108. Initial Version.
 * 2020-05-13   JLumbre SpireOne. Do not error on skip scenarios.
 * 2021-10-07   JLumbre QAC#4604993. Send all pay methods when there is no
 * 						primary/autopay pay method.
 *  
 ****************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.serviceScript.ServiceScriptDispatcher;
import com.splwg.base.api.serviceScript.ServiceScriptInstance;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.ccb.api.lookup.ContactDetailActiveInactiveLookup;
import com.splwg.ccb.api.lookup.ContactDetailPrimaryLookup;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillCharacteristic;
import com.splwg.ccb.domain.billing.bill.entity.BillCharacteristic_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillCharacteristics;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.cm.api.lookup.BillFormatLookup;
import com.splwg.cm.api.lookup.CmAllUserProcessingLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.cm.domain.customerinfo.cmFirsTechCustomerData.CmBillIsReady;
import com.splwg.cm.domain.customerinfo.cmFirsTechCustomerData.CmBillIsReady_Id;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author TMG02631
 *
@BatchJob (rerunnable = false, modules={},
 *      softParameters = { @BatchJobSoftParameter (entityName = featureConfiguration, name = ALL_USER_FEAT_CONFIG, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = EMAIL_NTF_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = SMS_NTF_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = OUTMSG_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = BILL_PAY_VENDOR_CHAR_TYPE, required = true, type = entity)})
 */
public class CmSendEbillNotificationBatch extends
CmSendEbillNotificationBatch_Gen {

	public static final Logger log = LoggerFactory.getLogger(CmSendEbillNotificationBatch.class);
	//batch parms
	private FeatureConfiguration alluserFc;
	private CharacteristicType emailNtfCharType;
	private CharacteristicType smsNtfCharType;
	private CharacteristicType bpVendorCharType;
	private CharacteristicType outMsgCharType;

	@Override
	public void validateSoftParameters(boolean isNewRun) {

		alluserFc = getParameters().getALL_USER_FEAT_CONFIG();
		emailNtfCharType = getParameters().getEMAIL_NTF_CHAR_TYPE();
		smsNtfCharType =getParameters().getSMS_NTF_CHAR_TYPE();
		bpVendorCharType = getParameters().getBILL_PAY_VENDOR_CHAR_TYPE();
		outMsgCharType = getParameters().getOUTMSG_CHAR_TYPE();

		log.debug(">>>>>alluserFc: " + alluserFc );
		log.debug(">>>>>emailNtfCharType: " + emailNtfCharType );
		log.debug(">>>>>smsNtfCharType: " + smsNtfCharType );
		log.debug(">>>>>bpVendorCharType: " + bpVendorCharType );
		log.debug(">>>>>bpVendorCharType: " + outMsgCharType );
	}

	public JobWork getJobWork() {

		StringBuilder mainStr = new StringBuilder();
		mainStr.append("SELECT CM_FIRSTECH_BL_RDY_ID ");
		mainStr.append("FROM CM_FIRSTECH_BILL_RDY");

		PreparedStatement  mainQry = createPreparedStatement(mainStr.toString(), "getJobWork");
		mainQry.setAutoclose(false);
		mainQry.execute();


		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();		

		QueryIterator<SQLResultRow> iter = mainQry.iterate();

		while (iter.hasNext()) {
			SQLResultRow row = iter.next();

			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId(new CmBillIsReady_Id(row.getString("CM_FIRSTECH_BL_RDY_ID")));
			workUnits.add(workUnit);              
		}
		iter.close();  
		mainQry.close();

		return createJobWorkForThreadWorkUnitList(workUnits);
	}

	public Class<CmSendEbillNotificationBatchWorker> getThreadWorkerClass() {
		return CmSendEbillNotificationBatchWorker.class;
	}

	public static class CmSendEbillNotificationBatchWorker extends
	CmSendEbillNotificationBatchWorker_Gen {

		//batch parms
		private FeatureConfiguration alluserFc;
		private CharacteristicType emailNtfCharType;
		private CharacteristicType smsNtfCharType;
		private CharacteristicType bpVendorCharType;
		private CharacteristicType outmsgCharType;

		//work variables
		private Account account;
		private Bill bill;
		private String customerName;
		private String address;
		private String amountDue;
		private String payoffBalance;
		private Date dueDate;
		private Date billDate;
		private Date lateChargeDate;		

		//Dates to String
		private String dueDateStr;
		private String billDateStr;
		private String lateChargeDateStr;	

		//pmoc variables
		private ServiceScriptInstance serviceScriptInstance;
		private COTSInstanceNode scriptInput;
		private COTSInstanceNode scriptOutput;
		private Bool hasEmailEbillPMOC = Bool.FALSE;
		private Bool hasSmsEbillPMOC = Bool.FALSE;		
		private String emailEbillPmoc;
		private String smsEbillPmoc;

		//pay method variables

		//constants
		private static final String emailCommType = "E";
		private static final String textCommType = "T";
		private static final String bothCommType = "A";
		private static final String COMMA = ",";
		private static final String CM_PmocInfo = "CM-PmocInfo";
		private static final String INPUT = "input";
		private static final String OUTPUT = "output";
		private static final String CM_SAPNotif = "CM-SAPNotif";
		private static final String MOBR = "MOBR";
		private static final String MOBRAP = "MOBRAP";
		private static final String PAY = "PAY";
		private static final String DOLLAR_SIGN = "$";		

		private int recordsProcessed = 0;
		private Bool reprintSw = Bool.FALSE;
		private Bool isOnApay;	
		private Bool isAmtDueLessZero;			
		private DateFormat dF = new DateFormat("MM/dd/yyyy");
		private static BigInteger sequence = BigInteger.ONE;


		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}


		@Override
		protected boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			alluserFc = getParameters().getALL_USER_FEAT_CONFIG();
			emailNtfCharType = getParameters().getEMAIL_NTF_CHAR_TYPE();
			smsNtfCharType =getParameters().getSMS_NTF_CHAR_TYPE();
			bpVendorCharType = getParameters().getBILL_PAY_VENDOR_CHAR_TYPE();
			outmsgCharType = getParameters().getOUTMSG_CHAR_TYPE();

			CmBillIsReady_Id rowId = (CmBillIsReady_Id) unit.getPrimaryId();
			log.debug(">>>>> rowId: " + rowId);
			CmBillIsReady row = rowId.getEntity();			

			//Retrieve ID Values
			Account_Id acctId = new Account_Id(row.getAccountId());
			Bill_Id billId = new Bill_Id(row.getBillId());
			//String messageString = "";

			customerName = row.getCmCustomerName();
			address = row.getCmAddress();
			amountDue = DOLLAR_SIGN.concat(row.getCmCurrentBalance().getAmount().toString());
			payoffBalance = DOLLAR_SIGN.concat(row.getCmPayoffBalance().getAmount().toString());
			dueDate = row.getDueDate();
			billDate = row.getBillDate();
			lateChargeDate = row.getLatePaymentChargeDate();

			//Parse Dates to String
			dueDateStr = dueDate.toString(dF);
			billDateStr = billDate.toString(dF);
			lateChargeDateStr = lateChargeDate.toString(dF);

			//Get Entities
			account = acctId.getEntity();
			bill = billId.getEntity();

			Date apayDt = bill.getAutopayCreationDate();
			if (!isNull(apayDt)){
				isOnApay = Bool.TRUE;
			}
			else{
				isOnApay = Bool.FALSE;
			}

			if (isNull(account)){
				//Start Change - JLumbre - 2020-05-13
				//messageString = "Account ID not found";
				//exitProcessing(rowId, messageString);
				//return false;
				return true;
				//End Change - JLumbre - 2020-05-13
			}

			if (isNull(bill)){
				//Start Change - JLumbre - 2020-05-13
				//Bill is Ready ID %1 is skipped. Bill ID not found
				//messageString = "Bill ID not found";
				//exitProcessing(rowId, messageString);
				//return false;
				return true;
				//End Change - JLumbre - 2020-05-13
			}

			//Check Account BPVENDOR Characteristic
			Bool isSkipAccount = skipAccount(bpVendorCharType);
			if (isSkipAccount.isTrue()){
				//Start Change - JLumbre - 2020-05-13
				//add message: Log Info: Bill is Ready ID %1 is skipped.
				//messageString = "Bill Presentment Vendors Characteristic exists on Account";
				//exitProcessing(rowId, messageString);
				//return false;
				return true;
				//End Change - JLumbre - 2020-05-13
			}

			//Check Bill's Bill Format
			Bool isEbill = checkBillRouting();
			if (isEbill.isFalse()){
				//Start Change - JLumbre - 2020-05-13
				//add message: Log Info: Bill is Ready ID %1 is skipped. Not on Ebill
				//messageString = "Not on Ebill";
				//exitProcessing(rowId, messageString);
				//return false;
				return true;
				//End Change - JLumbre - 2020-05-13
			}

			//E-Bill PMOC processing
			retrieveEbillPMOC(CM_PmocInfo);
			String commType = "";
			if (hasEmailEbillPMOC.isTrue() && hasSmsEbillPMOC.isTrue()){
				commType = bothCommType;				
			}
			else{
				if (hasEmailEbillPMOC.isTrue()){
					commType = emailCommType;		
				}

				if (hasSmsEbillPMOC.isTrue()){
					commType = textCommType;			
				}
			}

			if (reprintSw.isFalse()){
				Bool hasEmailChar = hasBillCharacteristic(emailNtfCharType);
				Bool hasSmsChar = hasBillCharacteristic(smsNtfCharType);

				if (hasEmailChar.isTrue() || hasSmsChar.isTrue()){
					//Start Change - JLumbre - 2020-05-13
					//Bill is Ready ID %1 is skipped. Bill has Notification Char
					//messageString = "Bill has Email or SMS Notification Characteristic";
					//exitProcessing(rowId, messageString);
					//return false;
					return true;
					//End Change - JLumbre - 2020-05-13			
				}
			}
			//Check Amount Due
			if (row.getCmCurrentBalance().isLessThanOrEqual(Money.ZERO)){
				isAmtDueLessZero = Bool.TRUE;
			}
			else{
				isAmtDueLessZero = Bool.FALSE;
			}
			//Retrieve payment method
			String payMethod = retrievePaymentMethod("CmPayOpt2");
			//Build SMS message
			String smsMessage = buildSmsMessage(payMethod);
			//Send Notification
			sendNotification(smsMessage,commType, payMethod);
			//count record processed
			recordsProcessed = recordsProcessed++;					
			return true;
		}

		/*private void exitProcessing(CmBillIsReady_Id id,  String messageString){			
			logInfo(CustomMessageRepositorySpireOne.S1_billIsReadyIsSkipped(id.getTrimmedValue(), messageString));							
		}*/

		private Bool skipAccount(CharacteristicType billPayVendorCharType){
			log.debug(">>>>>skipAccount");
			String bpVendorAcctCharVal;
			//Check Account Characteristics
			AccountCharacteristic bpVendorAcctChar = null;
			log.debug(">>>>>bpVendorAcctChar1: " + bpVendorAcctChar );
			bpVendorAcctChar = account.getEffectiveCharacteristic(billPayVendorCharType);
			log.debug(">>>>>bpVendorAcctChar2: " + bpVendorAcctChar );
			if (!isNull(bpVendorAcctChar)){

				if (billPayVendorCharType.getCharacteristicType().isPredefinedValue()){
					bpVendorAcctCharVal = bpVendorAcctChar.getCharacteristicValue().trim();					
				}
				else if (billPayVendorCharType.getCharacteristicType().isForeignKeyValue()){
					bpVendorAcctCharVal = bpVendorAcctChar.getCharacteristicValueForeignKey1().trim();
				}
				else {
					bpVendorAcctCharVal = bpVendorAcctChar.getAdhocCharacteristicValue().trim();
				}

				CmFeatureConfigurationRetriever fcRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
				fcRetriever.setParmWFMName(alluserFc);
				fcRetriever.setParmOptType(CmAllUserProcessingLookup.constants.CMB_BILL_PRESENTMENT_VENDORS.getLookupValue().fetchIdFieldValue().trim());
				String vendorList = fcRetriever.getMaxSequenceOptionValue();

				String[] vendorListSplit = vendorList.split(COMMA);
				List<String> bpVendorList = new ArrayList<>();
				for (String vendor : vendorListSplit){
					bpVendorList.add(vendor);
				}

				if (bpVendorList.contains(bpVendorAcctCharVal)){
					//Add CMBPVNDR Characteristic to the Bill
					addBillCharacteristic(bpVendorCharType, bpVendorAcctCharVal);					
					return Bool.TRUE;
				}
			}
			return Bool.FALSE;
		}

		public void retrieveEbillPMOC(String service){
			log.debug(">>>>> START retrieveEbillPMOC ");
			serviceScriptInstance = null;
			scriptInput = null;
			scriptOutput = null;
			hasEmailEbillPMOC = Bool.FALSE;
			hasSmsEbillPMOC = Bool.FALSE;

			// Create an instance of the service script
			serviceScriptInstance = ServiceScriptInstance.create(service);
			// Retrieve the script's input node
			scriptInput = serviceScriptInstance.getGroup(INPUT);
			// Account Id
			scriptInput.set("accountId", account.getId().getTrimmedValue());
			// Invoke the service script
			try {
				ServiceScriptDispatcher.invoke(serviceScriptInstance);
				scriptOutput = serviceScriptInstance.getGroup(OUTPUT);
				if (scriptOutput.getGroup("errorInformation").getBoolean("isInError").isFalse()){					
					if (!isEmptyOrNull(scriptOutput.getGroup("ebillPmoc").getString("ebillEmailAddress"))){						
						emailEbillPmoc = scriptOutput.getGroup("ebillPmoc").getString("ebillEmailAddress");
						log.debug(">>>>> emailPmoc: " + emailEbillPmoc);
						hasEmailEbillPMOC = Bool.TRUE;
					}

					if (!isEmptyOrNull(scriptOutput.getGroup("ebillPmoc").getString("ebillSmsPhone"))){					
						smsEbillPmoc = scriptOutput.getGroup("ebillPmoc").getString("ebillSmsPhone");
						log.debug(">>>>> smsPmoc: " + smsEbillPmoc);
						hasSmsEbillPMOC = Bool.TRUE;								
					}

					if (hasSmsEbillPMOC.isFalse() && hasEmailEbillPMOC.isFalse()){
						//retrieve the Person Contact Email Address that is flagged as Primary and Active
						//and create the Out bound message with a commType of E.									
						emailEbillPmoc = retrieveEmailPersonContact();
						if (!isBlankOrNull(emailEbillPmoc)){
							hasEmailEbillPMOC = Bool.TRUE;
						}
					}
				}
				else{
					if (hasSmsEbillPMOC.isFalse() && hasEmailEbillPMOC.isFalse()){
						//retrieve the Person Contact Email Address that is flagged as Primary and Active
						//and create the Out bound message with a commType of E.									
						emailEbillPmoc = retrieveEmailPersonContact();
						if (!isBlankOrNull(emailEbillPmoc)){
							hasEmailEbillPMOC = Bool.TRUE;
						}
					}
				}
			} catch (ApplicationError ae){
				ae.getServerMessage();
			}
			log.debug(">>>>> hasSmsEbillPMOC: " + hasSmsEbillPMOC);
			log.debug(">>>>> hasEmailEbillPMOC: " + hasEmailEbillPMOC);
			log.debug(">>>>> END retrieveEbillPMOC ");
		}
		public Bool checkBillRouting(){

			log.debug(">>>>>checkBillRouting: ");
			//BillFormatLookup billFormatLkp = null;
			Bool isEbill = Bool.FALSE;

			StringBuilder str = new StringBuilder();
			str.append("SELECT BR.REPRINT_SW, BR.BILL_FORMAT_FLG ");
			str.append("FROM CI_BILL_ROUTING BR ");
			str.append("WHERE BR.BILL_ID = :billId ");
			//Start Change - JLumbre - 2020-05-13
			/*str.append("AND BR.SEQNO = (SELECT MAX(BR1.SEQNO) ");
			str.append("FROM CI_BILL_ROUTING BR1 ");
			str.append("WHERE BR1.BILL_ID=BR.BILL_ID ");
			str.append("AND BR1.EXTRACT_DTTM <= :processDateTime) ");*/
			str.append("AND BR.BILL_FORMAT_FLG= :XE ");
			str.append("AND BR.EXTRACT_DTTM <= :processDateTime ");
			str.append("ORDER BY BR.SEQNO DESC ");			
			//End Change - JLumbre - 2020-05-13

			PreparedStatement billRoutingQry = createPreparedStatement(str.toString(), getClass().getName());
			billRoutingQry.bindId("billId", bill.getId());
			billRoutingQry.bindDateTime("processDateTime", getProcessDateTime());
			//Start Change - JLumbre - 2020-05-13
			billRoutingQry.bindLookup("XE", BillFormatLookup.constants.EBILL);
			//End Change - JLumbre - 2020-05-13
			billRoutingQry.setAutoclose(false);
			billRoutingQry.execute();


			if (billRoutingQry.list().size() > 0){				
				SQLResultRow row = billRoutingQry.firstRow();
				reprintSw = row.getBoolean("REPRINT_SW");
				log.debug(">>>>>reprintSw: " +reprintSw);
				//Start Change - JLumbre - 2020-05-13
				//billFormatLkp = (BillFormatLookup) row.getLookup("BILL_FORMAT_FLG", BillFormatLookup.class);							
				/*if (billFormatLkp.equals(BillFormatLookup.constants.EBILL)){
					log.debug(">>>>>billFormatLkp: " +billFormatLkp);	
					isEbill = Bool.TRUE;
				}*/
				isEbill = Bool.TRUE;
				//End Change - JLumbre - 2020-05-13

			}
			else {
				isEbill = Bool.FALSE;
			}
			billRoutingQry.close();			

			return isEbill;
		}

		public Bool hasBillCharacteristic(CharacteristicType charType){
			log.debug(">>>>> hasBillCharacteristic" );
			ListFilter<BillCharacteristic> bc = bill.getCharacteristics().createFilter("WHERE this.id.characteristicType = :charType order by this.id.sequence desc", getClass().getName());
			bc.bindEntity("charType", charType);						
			log.debug(">>>>>bc.list().size(): " + bc.list().size() );
			if (bc.list().size() > 0){
				sequence = bc.firstRow().fetchIdSequence();
				return Bool.TRUE;
			}			
			return Bool.FALSE;
		}

		public void addBillCharacteristic(CharacteristicType charType, String charVal){
			log.debug(">>>>> addBillCharacteristic" );

			Bool hasChar = hasBillCharacteristic(charType);

			if (hasChar.isTrue()){
				sequence = sequence.add(BigInteger.ONE);
			}

			BillCharacteristics billChars = bill.getCharacteristics();
			BillCharacteristic_DTO bcDto = billChars.newChildDTO();
			if (charType.getCharacteristicType().isAdhocValue()){
				bcDto.setAdhocCharacteristicValue(charVal);
			}else if (charType.getCharacteristicType().isPredefinedValue()){
				bcDto.setCharacteristicValue(charVal);
			}else if (charType.getCharacteristicType().isForeignKeyValue()){
				bcDto.setCharacteristicValueForeignKey1(charVal);
			}
			billChars.add(bcDto, charType.getId(), sequence);	
		}

		public String buildSmsMessage(String payMethodLast4){
			String textMessage = "";
			log.debug(">>>>> start buildSmsMessage");
			//retrieve parameter info
			String accountFirst4 = account.getId().getTrimmedValue().substring(0,4);
			String blank = "";
			String textCode = PAY.concat(accountFirst4).concat(payMethodLast4);
			String smsMessage = "";


			if (isAmtDueLessZero.isTrue()){
				textMessage = CustomMessageRepositorySpireOne.S1_billIsReadyNoAmountDue(accountFirst4, customerName, address,payoffBalance, amountDue, dueDateStr, billDateStr, lateChargeDateStr, payMethodLast4).getMessageText();
			}
			else if (isOnApay.isTrue()){
				textMessage = CustomMessageRepositorySpireOne.S1_billIsReadyAutoPay(accountFirst4, customerName, address, payoffBalance, amountDue, dueDateStr, billDateStr, lateChargeDateStr, payMethodLast4).getMessageText();
			}
			else if (isOnApay.isFalse() && !isBlankOrNull(payMethodLast4)){
				textMessage = CustomMessageRepositorySpireOne.S1_billIsReadyNotAutoPay(accountFirst4, customerName, address, payoffBalance, amountDue, dueDateStr, billDateStr, lateChargeDateStr, payMethodLast4, textCode).getMessageText();
			}
			else {	
				//Start Change - JLumbre - 2021-10-07 - QAC#4604993
				//textMessage = CustomMessageRepositorySpireOne.S1_billIsReadyNotAutoPayNoPrimaryPayMethod(accountFirst4, customerName, address, payoffBalance, amountDue, dueDateStr, billDateStr, lateChargeDateStr, smsMessage).getMessageText();
				serviceScriptInstance = null;
				scriptInput = null;
				scriptOutput = null;

				// Create an instance of the service script
				serviceScriptInstance = ServiceScriptInstance.create("CM-RetPMMsg");
				// Retrieve the script's input node
				scriptInput = serviceScriptInstance.getGroup(INPUT);
				// Account Id
				scriptInput.set("accountId", account.getId().getTrimmedValue());
				// Invoke the service script
				try {
					ServiceScriptDispatcher.invoke(serviceScriptInstance);
					scriptOutput = serviceScriptInstance.getGroup(OUTPUT);

					if (!isBlankOrNull(scriptOutput.getString("smsMessage"))){ //smsMessage
						smsMessage = scriptOutput.getString("smsMessage").trim();
						textMessage = CustomMessageRepositorySpireOne.S1_billIsReadyNotAutoPayNoPrimaryPayMethod(accountFirst4, customerName, address, payoffBalance, amountDue, dueDateStr, billDateStr, lateChargeDateStr, smsMessage).getMessageText();
					}else{
						textMessage = CustomMessageRepositorySpireOne.S1_billIsReadyNotAutoPayNoPayMethod(accountFirst4, customerName, address, payoffBalance, amountDue, dueDateStr, billDateStr, lateChargeDateStr, blank).getMessageText();
					}							

				} catch (ApplicationError ae){
					ae.getServerMessage();
				}
				//End Change - JLumbre - 2021-10-07 - QAC#4604993
			}
				

			log.debug(">>>>> textMessage" + textMessage);
			log.debug(">>>>> smsMessage" + smsMessage);
			log.debug(">>>>> end buildSmsMessage");
			return textMessage;
			
		}


		public String retrievePaymentMethod(String service){
			log.debug(">>>>> START retrievePaymentMethod ");
			String paymentMethodInfo = "";
			serviceScriptInstance = null;
			scriptInput = null;
			scriptOutput = null;

			// Create an instance of the service script
			serviceScriptInstance = ServiceScriptInstance.create(service);
			// Retrieve the script's input node
			scriptInput = serviceScriptInstance.getGroup(INPUT);
			// Account Id
			scriptInput.set("accountId", account.getId().getTrimmedValue());
			// Invoke the service script
			try {
				ServiceScriptDispatcher.invoke(serviceScriptInstance);
				scriptOutput = serviceScriptInstance.getGroup(OUTPUT);
				log.debug(">>>>> START retrievePaymentMethod 1 ");
				if (scriptOutput.getGroup("errorInformation").getBoolean("isInError").isFalse()){
					log.debug(">>>>> START retrievePaymentMethod 2 ");
					Iterator<COTSInstanceListNode> pymIter = scriptOutput.getList("paymentOption").iterator();
					COTSInstanceListNode paymentMethodNode;					
					while (pymIter.hasNext()){
						log.debug(">>>>> START retrievePaymentMethod 3 ");
						paymentMethodNode = pymIter.next();
						if (isOnApay.isTrue()){
							if (!isNull(paymentMethodNode.getBoolean("onApay"))){
								if (paymentMethodNode.getBoolean("onApay").isTrue()){
									if (!isEmptyOrNull(paymentMethodNode.getGroup("creditCardInfo").getString("cardNumber"))){
										log.debug(">>>>> START retrievePaymentMethod CARD ");
										paymentMethodInfo = paymentMethodNode.getGroup("creditCardInfo").getString("cardNumber");								
									}
									else{
										log.debug(">>>>> START retrievePaymentMethod BANK ");
										paymentMethodInfo = paymentMethodNode.getGroup("bankAccountInfo").getString("accountNumber");	
									}
									break;
								}
							}
						}

						if (!isNull(paymentMethodNode.getBoolean("isPrimary"))){
							if (paymentMethodNode.getBoolean("isPrimary").isTrue()){
								if (!isEmptyOrNull(paymentMethodNode.getGroup("creditCardInfo").getString("cardNumber"))){
									log.debug(">>>>> START retrievePaymentMethod CARD ");
									paymentMethodInfo = paymentMethodNode.getGroup("creditCardInfo").getString("cardNumber");								
								}
								else{
									log.debug(">>>>> START retrievePaymentMethod BANK ");
									paymentMethodInfo = paymentMethodNode.getGroup("bankAccountInfo").getString("accountNumber");	
								}
								break;
							}
						}
					}
				}					

			} catch (ApplicationError ae){
				ae.getServerMessage();
			}
			log.debug(">>>>>paymentMethodInfo: " + paymentMethodInfo);

			String payMethodLast4 = "";
			if (!isBlankOrNull(paymentMethodInfo)){
				payMethodLast4 = getLast4Digits(paymentMethodInfo,4);
			}
			log.debug(">>>>> END retrieveEbillPMOC ");
			return payMethodLast4;

		}
		
		public String getLast4Digits(String acctNbr, int digit){
			int length = acctNbr.length();
			if(length <= digit){
				return acctNbr;
			}
			int startIndex = length-digit;
			return acctNbr.substring(startIndex);
		}
		public void sendNotification(String smsMessage, String communicationType, String payMethod){
			log.debug(">>>>> START sendNotification");	

			if (!isBlankOrNull(communicationType)){
				serviceScriptInstance = null;
				scriptInput = null;
				scriptOutput = null;

				serviceScriptInstance = ServiceScriptInstance.create(CM_SAPNotif);
				// Account Id
				serviceScriptInstance.set("account", account.getId().getTrimmedValue());
				serviceScriptInstance.set("communicationType", communicationType);
				if (isOnApay.isTrue()){
					serviceScriptInstance.set("event", MOBRAP);
				}
				else{
					serviceScriptInstance.set("event", MOBR);
				}

				log.debug(">>>>> communicationType: "  +communicationType);				

				if (communicationType.compareTo("E") == 0 || communicationType.compareTo("A") == 0){					
					log.debug(">>>>> sendNotification emailPmoc");
					log.debug(">>>>> emailEbillPmoc"  +emailEbillPmoc);
					log.debug(">>>>> emailParameter1:"  + customerName);
					log.debug(">>>>> emailParameter2:"  + address);
					log.debug(">>>>> emailParameter3 :"  +payoffBalance);
					log.debug(">>>>> emailParameter4:"  +amountDue);
					log.debug(">>>>> emailParameter5:"  +dueDate.toString(dF));
					log.debug(">>>>> emailParameter6:"  +billDate.toString(dF));
					log.debug(">>>>> emailParameter7:"  +lateChargeDate.toString(dF));
					log.debug(">>>>> emailParameter8:"  +isOnApay.toString());
					log.debug(">>>>> emailParameter9:"  +payMethod);
					serviceScriptInstance.set("emailDestination", emailEbillPmoc);
					serviceScriptInstance.set("emailParameter1", account.getId().getTrimmedValue());
					serviceScriptInstance.set("emailParameter2", billDate.toString(dF));
					serviceScriptInstance.set("emailParameter3", dueDateStr);
					serviceScriptInstance.set("emailParameter4", amountDue);
					serviceScriptInstance.set("emailParameter5", address);
					serviceScriptInstance.set("emailParameter6", customerName);
					serviceScriptInstance.set("emailParameter7", lateChargeDateStr);
					serviceScriptInstance.set("emailParameter8", isOnApay.toString());
					serviceScriptInstance.set("emailParameter9", payMethod);

				}
				if (communicationType.compareTo("T") == 0 || communicationType.compareTo("A") == 0){
					log.debug(">>>>> textDestination"  +smsEbillPmoc);
					log.debug(">>>>> textMessage"  + smsMessage);
					serviceScriptInstance.set("textDestination", smsEbillPmoc);
					serviceScriptInstance.set("textMessage", smsMessage);
				}

				try{
					ServiceScriptDispatcher.invoke(serviceScriptInstance);
					String outMsgId = serviceScriptInstance.getString("outboundMessageId");
					if (!isBlankOrNull(outMsgId)){
						log.debug(">>>>> outMsgId" + outMsgId);
						addBillCharacteristic(outmsgCharType, outMsgId);
						if (hasEmailEbillPMOC.isTrue()){
							addBillCharacteristic(emailNtfCharType, emailEbillPmoc);
						}

						if (hasSmsEbillPMOC.isTrue()){
							addBillCharacteristic(smsNtfCharType, smsEbillPmoc);
						}
					}
					log.debug(">>>>> Success sendNotification");
				}
				catch (ApplicationError e){
					log.debug(">>>>> ERROR sendNotification");
					e.getServerMessage();
				}
				log.debug(">>>>> END comm type is not blank");
			}
			log.debug(">>>>> END sendNotification");
		}

		private String retrieveEmailPersonContact(){
			String email = "";

			ListFilter<AccountPerson> acctPer = account.getPersons().createFilter("WHERE this.isMainCustomer = :F1", getClass().getName());
			acctPer.bindBoolean("F1",Bool.TRUE);

			Person_Id personId = acctPer.firstRow().getId().getPersonId();

			StringBuilder mainStr = new StringBuilder();
			mainStr.append("SELECT CONTACT_VALUE ");
			mainStr.append("FROM C1_PER_CONTDET ");
			mainStr.append("WHERE COMM_RTE_TYPE_CD= 'EMAIL' ");
			mainStr.append("AND CND_PRIMARY_FLG= :yes ");
			mainStr.append("AND CND_ACTINACT_FLG= :active ");
			mainStr.append("AND PER_ID= :perId");


			PreparedStatement mainQry = createPreparedStatement(mainStr.toString(), getClass().getName());				
			mainQry.bindId("perId", personId);
			mainQry.bindLookup("yes", ContactDetailPrimaryLookup.constants.YES);
			mainQry.bindLookup("active", ContactDetailActiveInactiveLookup.constants.ACTIVE);
			mainQry.setAutoclose(false);
			mainQry.execute();


			if (mainQry.list().size() > 0){
				SQLResultRow row = mainQry.firstRow();
				email = row.getString("CONTACT_VALUE");
			}		
			mainQry.close();
			return email;
		}
	}

}
