/*
 *************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * CCB016: ITRON Meter Read Download Batch 2
 * 
 * This background process will use the information stored on the 
 * Meter Read Staging Download table (CI_MR_STAGING_DWN) to generate
 * a flat file that will be used to interface to ITRON.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 * 
 * 2020-05-11   JVitug          CCB016.1. Initial Version.   
 * 2021-01-28   NMendo          CCB016.3. ITRON Meter Read Download updates.
 *                              Move all defaults and char type code batch 
 *                              parameters to ITRON CONFIG service task type. 
 *                              Update Meter.MeterSegment logic to check for 
 *                              Town Code and Gride Code prem chars. Update 
 *                              Hi/Low estimation logic to reference ITRON 
 *                              CONFIG to determine if estimation logic should 
 *                              be run or if defaults should be used.
 * 2021-02-08   JVitug          CCB016.Defect1. Updated source for Scheduled Read date 
 *                              to be derived using the Meter Read Cycle 
 *                              and the scheduled selection date. Updated
 *                              variable name of wScheduleDate to 
 *                              wScheduleSelectionDate
 * 2021-03-03   NMendo          CCB016.Defect2. Update Meter Reading values to 
 *                              be integer. Update header/s.
 * 2021-03-09   NMendo          CCB016.Defect3. Remove Meter.InstructionLocationCode 
 *                              from extract. Change Meter.MeterSegment to Meter.Segment. 
 *                              Change Customer.StateorProvince to Customer.StateOrProvince. 
 *                              Change Customer.Postal to Customer.PostalCode. 
 *                              Update Hi1/Hi2 and Low1/Low2 values to consumption 
 *                              (not reading). Retrieve Address details for vacant 
 *                              premises (active meter, no SA).
 * 2021-03-24   JVitug/NMendo   CCB016.Defect4. Updated the retrieval of the 
 * 								EndpointID field to look for the CM-RDTYPE
 * 								characteristic type in the Item 
 * 								to determine the register with ERT.
 * 2021-05-18   JGoco           B-18838. Set Data Collection Type and Filtering Information
 * 								accordingly if the mr down record is for Succession Reads.
 * 2021-06-07   BMarquez        CCB016.Defect5. Remove commas and new lines 
 *                              and limit length for Street Address, Meter 
 *                              Location Details and Customer Name fields. 
 *                              Retrieve only effective Registers.
 * 2021-06-17   NMendo          CCB016.Defect6. Derive value of WorkSet.DefaultDataCollectionType
 *                              on Succession Read. Remove retrieval of uomItemCharType.
 * 2021-07-19   NMendo          CCB016.Defect7. Added processing for Customer Read Meters.
 * 2021-08-07   NMendo          CCB016.Defect8. Added Premise Characteristic on Customer Read 
 *                              Customer Contact.
 * 2023-02-08	IReyes          B-26006. Added new batch parameter SUPPRESS_EXTRACT_FILE_FIELD
 * 								to remove the value of the customer full name field from the
 * 								extract file.
 * 2025-11-14   EQuint      CCB25.4 Upgrade
 **************************************************************************
 */
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.geographicType.GeographicType;
import com.splwg.base.domain.common.geographicType.GeographicType_Id;
import com.splwg.base.domain.common.workCalendar.WorkCalendar;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.EstimateTypeLookup;
import com.splwg.ccb.api.lookup.ItemStatusLookup;
import com.splwg.ccb.api.lookup.MeterOnOffStatusLookup;
import com.splwg.ccb.api.lookup.ReadTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.meterReadCycle.entity.MeterReadCycle;
import com.splwg.ccb.domain.admin.meterReadCycle.entity.MeterReadCycle_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristics;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.data.HighLowCalculationAlgorithmData;
import com.splwg.ccb.domain.meterread.item.entity.Item;
import com.splwg.ccb.domain.meterread.item.entity.ItemCharacteristic;
import com.splwg.ccb.domain.meterread.item.entity.Item_Id;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterReadCharacteristic;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterReadCharacteristics;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
/**
 * @author JVitug
 *
 @BatchJob (multiThreaded = false, modules={},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = CM_ITRONCONFIG, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CUSTOMER_READ_SA_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (name = CUSTOMER_READ_SA_CHAR_VAL, type = string)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CUSTOMER_READ_CC_CLASS, type = entity)
 *            , @BatchJobSoftParameter (name = CUSTOMER_READ_CC_TYPE, type = string)
 *            , @BatchJobSoftParameter (name = SUPPRESS_EXTRACT_FILE_FIELD, type = boolean)})
 */
public class CmITRONMeterReadDownload2Batch 
	extends CmITRONMeterReadDownload2Batch_Gen {
	
	// Start Add - NMendo - CCB016.Defect7 - 2021-07-19
	private static final String CUSTOMER_READ_SA_CHAR_TYPE_STR = "CUSTOMER_READ_SA_CHAR_TYPE";
	private static final String CUSTOMER_READ_SA_CHAR_VAL_STR = "CUSTOMER_READ_SA_CHAR_VAL";
	private static final String CUSTOMER_READ_CC_CLASS_STR = "CUSTOMER_READ_CC_CLASS";
	private static final String CUSTOMER_READ_CC_TYPE_STR = "CUSTOMER_READ_CC_TYPE";
	// End Add - NMendo - CCB016.Defect7 - 2021-07-19
	
	@Override
	public void validateSoftParameters(boolean arg0) {

		// Validate that parameter is a valid file path	
		cmOuterValidateFilePath(this.getParameters().getFILE_PATH());
		
		// Start Add - NMendo - CCB016.Defect7 - 2021-07-19
		CharacteristicType parmCustomerReadSaCharType = this.getParameters().getCUSTOMER_READ_SA_CHAR_TYPE();
		String parmCustomerReadSaCharVal = this.getParameters().getCUSTOMER_READ_SA_CHAR_VAL();
		CustomerContactClass parmCustomerReadCustomerContactClass = this.getParameters().getCUSTOMER_READ_CC_CLASS();
		String parmCustomerReadCustomerContactType = this.getParameters().getCUSTOMER_READ_CC_TYPE();
		
		if(notNull(parmCustomerReadSaCharType)) {
			CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(
					parmCustomerReadSaCharType.getId(), CharacteristicEntityLookup.constants.SERVICE_AGREEMENT);        
	        if (isNull(charEntityId.getEntity())) {
	        	// Batch Parameter %1 value (%2) is an invalid Characteristic Type for %3 entity.
	        	addError(CustomMessageRepositorySpireOne.CCB016_batchParmInvalidCharTypeForEntity(
	        			CUSTOMER_READ_SA_CHAR_TYPE_STR, 
	        			parmCustomerReadSaCharType.getId().getTrimmedValue(), 
	        			CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().fetchLanguageDescription()));
	        }
	        
	        if(isNull(parmCustomerReadSaCharVal)) {
	        	// Batch Parameter %1 is required when Batch Parameter %2 is populated.
	        	addError(CustomMessageRepositorySpireOne.CCB016_batchParmRequired(CUSTOMER_READ_SA_CHAR_VAL_STR, CUSTOMER_READ_SA_CHAR_TYPE_STR));
	        }
	        
	        if(isNull(parmCustomerReadCustomerContactClass)) {
	        	// Batch Parameter %1 is required when Batch Parameter %2 is populated.
	        	addError(CustomMessageRepositorySpireOne.CCB016_batchParmRequired(CUSTOMER_READ_CC_CLASS_STR, CUSTOMER_READ_SA_CHAR_TYPE_STR));
	        }
	        
	        if(isNull(parmCustomerReadCustomerContactType)) {
	        	// Batch Parameter %1 is required when Batch Parameter %2 is populated.
	        	addError(CustomMessageRepositorySpireOne.CCB016_batchParmRequired(CUSTOMER_READ_CC_TYPE_STR, CUSTOMER_READ_SA_CHAR_TYPE_STR));
	        }
	        
	        if(parmCustomerReadSaCharType.getCharacteristicType().isPredefinedValue()) {
	        	CharacteristicValue_Id charValId = new CharacteristicValue_Id(parmCustomerReadSaCharType, parmCustomerReadSaCharVal);
	        	if(isNull(charValId.getEntity())) {
	        		// Batch Parameter %1 value (%2) is an invalid Characteristic Value for Characteristic Type (%3).
	        		addError(CustomMessageRepositorySpireOne.CCB016_batchParmInvalidCharValForCharType(
	        				CUSTOMER_READ_SA_CHAR_VAL_STR, parmCustomerReadSaCharVal, parmCustomerReadSaCharType.getId().getTrimmedValue()));
	        	}
	        }
	        
	        CustomerContactType_Id ccTypeId = new CustomerContactType_Id(parmCustomerReadCustomerContactClass, parmCustomerReadCustomerContactType);
	        if(isNull(ccTypeId.getEntity())) {
	        	// Batch Parameter %1 value (%2) is an invalid Customer Contact Type for Customer Contact Class (%3).
	        	addError(CustomMessageRepositorySpireOne.CCB016_batchParmInvalidCcTypeForCcClass(
	        			CUSTOMER_READ_CC_TYPE_STR, parmCustomerReadCustomerContactType, parmCustomerReadCustomerContactClass.getId().getTrimmedValue()));
	        }
		}
		// End Add - NMendo - CCB016.Defect7 - 2021-07-19
	}

	/**
	 * Custom method which validates that the file path is a valid directory
	 * @param filePath
	 * @param parmDesc
	 */
	private void cmOuterValidateFilePath(String filePath) {

		File fileValidator = new File(filePath.trim());		
		if (isNull(fileValidator)
				|| !fileValidator.isDirectory()) {
			// Batch Parameter File Path %1 is an invalid file path.
			addError(CustomMessageRepositorySpireOne.CCB016_1_batchParmFilePathInvalid(filePath.trim()));
		}
	}
	
	@Override
	public JobWork getJobWork() {

		QueryIterator queryIter = cmMainSelectionCriteria();
		return createJobWorkForQueryIterator(queryIter, this);
	}
	
	/**
	 * Custom method which retrieves the records to be processed
	 * @return QueryIterator object
	 */
	private QueryIterator<SQLResultRow> cmMainSelectionCriteria() {

		QueryIterator<SQLResultRow> queryIterator = null;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT MRD.MR_CYC_CD, MRD.SCHED_SEL_DT, MRD.MR_RTE_CD, MRD.SP_MTR_HIST_ID ");
		stringBuilder.append("FROM CI_MR_STAGE_DWN MRD, CI_SP SP, CI_SP_MTR_HIST SPMH ");
		stringBuilder.append("WHERE BATCH_CD = :batchCd ");
		stringBuilder.append("AND BATCH_NBR = :batchNbr ");
		stringBuilder.append("AND SPMH.SP_MTR_HIST_ID = MRD.SP_MTR_HIST_ID ");
		stringBuilder.append("AND SP.SP_ID = SPMH.SP_ID ");
		stringBuilder.append("ORDER BY MR_CYC_CD, MR_RTE_CD, SP.MR_CYC_RTE_SEQ, SP_MTR_HIST_ID ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		prepState.bindId("batchCd", this.getBatchControlId());
		prepState.bindBigInteger("batchNbr", this.getBatchNumber());
		queryIterator = prepState.iterate();
		
		return queryIterator;
	}
	/**
	 * Base method which creates the Work Unit that will be processed by the batch worker
	 */
	@Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow qrw) { 
		ThreadWorkUnit twu = new ThreadWorkUnit();
		MeterReadCycle_Id meterReadCycleID = (MeterReadCycle_Id) qrw.getId("MR_CYC_CD", MeterReadCycle.class);
		Date schedSelDate =  qrw.getDate("SCHED_SEL_DT");
		String mrRteCdStr = (String) qrw.get("MR_RTE_CD");
		ServicePointMeterHistory_Id spMtrHistID = (ServicePointMeterHistory_Id) qrw.getId("SP_MTR_HIST_ID", ServicePointMeterHistory.class);
		
		twu.setPrimaryId(spMtrHistID);
		twu.addSupplementalData("MR_CYC_CD", meterReadCycleID);
		twu.addSupplementalData("SCHED_SEL_DT", schedSelDate);
		twu.addSupplementalData("MR_RTE_CD", mrRteCdStr);
		
		return twu;
	}
	
	public Class<CmITRONMeterReadDownload2BatchWorker> getThreadWorkerClass() {
		return CmITRONMeterReadDownload2BatchWorker.class;
	}
	/**
	 * The Inner Class / Batch Worker
	 */
	public static class CmITRONMeterReadDownload2BatchWorker 
		extends CmITRONMeterReadDownload2BatchWorker_Gen {

		// Soft Parameters
		private String parmFileName;
		private String parmFilePath;
		private ServiceTaskType itronServiceTaskType;
		// Start Add - NMendo - CCB016.Defect7 - 2021-07-19
		private CharacteristicType parmCustomerReadSaCharType;
		private String parmCustomerReadSaCharVal;
		private CustomerContactClass parmCustomerReadCustomerContactClass;
		private String parmCustomerReadCustomerContactType;
		// End Add - NMendo - CCB016.Defect7 - 2021-07-19
		
		// ITRON Configuration
		private CharacteristicType tamper1CharType;
		private CharacteristicType tamper2CharType;
		private CharacteristicType districtCharType;
		// Start Delete - NMendo - CCB016.Defect6 -  2021-06-17
		//private CharacteristicType uomItemCharType;
		// End Delete - NMendo - CCB016.Defect6 -  2021-06-17
		private CharacteristicType townCodeCharType;
		private CharacteristicType ertCharType;
		//Start Add JVitug - CCB016.Defect4 - 2021-03-24
		private CharacteristicType maximoReadTypeCharType;
		//End Add JVitug - CCB016.Defect4 - 2021-03-24
		private GeographicType latLongGeoType;
		private GeographicType gridCodeGeoType;
		
		// Constants
		private static final String COMMA = ",";
		private static final String SINGLE_QUOTE = "'";
		private static final String BACKSLASH = "/";
		private static final String FORWARDSLASH = "\\";
		private static final String UNDERSCORE = "_";
		private static final String CARRIAGE_RETURN_LINE_FEED = "\r\n";
		private static final String HYPHEN = "-";
		private static final String SPACE = " ";
		private static final String CSV = "csv";
		private static final String DOT = ".";
		private static final String METER_CONFIGURATION_TYPE_001 = "001";
		//Start Add JVitug - CCB016.Defect4 - 2021-03-24
		private static final String METER_CONFIGURATION_TYPE_004 = "004";
		private static final String MAXIMO_READ_TYPE_CORRECTED = "C";
		private static final String MAXIMO_READ_TYPE_UNCORRECTED = "U";
		//End Add JVitug - CCB016.Defect4 - 2021-03-24
		private static final String HEADER_WORKSET_WORKID = "WorkSet.WorkSetID";
		private static final String HEADER_WORKSET_WORK_SET_TYPE= "WorkSet.WorkSetType";
		private static final String HEADER_WORKSET_SCHEDULED_READ_DATE = "WorkSet.ScheduledReadDate";
		private static final String HEADER_WORKSET_FILTERING_INFORMATION = "WorkSet.FilteringInformation";
		private static final String HEADER_WORKSET_CYCLE= "WorkSet.Cycle";
		private static final String HEADER_WORKSET_CRITICAL_READ_DATE = "WorkSet.CriticalReadDate";
		private static final String HEADER_WORKSET_DEFAULT_DATA_COLLECTION_TYPE = "WorkSet.DefaultDataCollectionType";
		private static final String HEADER_CUSTOMER_FULLNAME = "Customer.FullName";
		private static final String HEADER_CUSTOMER_FULL_STREET_ADRESS = "Customer.FullStreetAddress";
		private static final String HEADER_CUSTOMER_ACCOUNT_NUMBER = "Customer.AccountNumber";
		private static final String HEADER_CUSTOMER_LAST_NAME = "Customer.LastName";
		private static final String HEADER_CUSTOMER_FIRST_NAME = "Customer.FirstName";
		private static final String HEADER_CUSTOMER_MIDDLE_NAME = "Customer.MiddleName";
		private static final String HEADER_CUSTOMER_STREET_NUMBER = "Customer.StreetNumber";
		private static final String HEADER_CUSTOMER_STREET_NAME = "Customer.StreetName";
		private static final String HEADER_CUSTOMER_CUSTOMER_SUITE = "Customer.Suite";
		private static final String HEADER_CUSTOMER_CITY = "Customer.City";
		// Start Change - NMendo - 2021-03-09 - CCB016.Defect3
		//private static final String HEADER_CUSTOMER_STATE_OR_PROVINCE = "Customer.StateorProvince";
		private static final String HEADER_CUSTOMER_STATE_OR_PROVINCE = "Customer.StateOrProvince";
		//private static final String HEADER_CUSTOMER_POSTAL = "Customer.Postal";
		private static final String HEADER_CUSTOMER_POSTAL = "Customer.PostalCode";
		// End Change - NMendo - 2021-03-09 - CCB016.Defect3
		private static final String HEADER_METER_UTILITY_METER_SEQUENCE_NUMBER = "Meter.UtilityMeterSequenceNumber";
		private static final String HEADER_METER_METER_NUMBER = "Meter.MeterNumber";
		private static final String HEADER_METER_METER_CATEGORY = "Meter.MeterCategory";
		private static final String HEADER_METER_METER_TYPE = "Meter.MeterType";
		private static final String HEADER_METER_ACTIVE_INDICATOR = "Meter.ActiveIndicator";
		// Start Change - NMendo - 2021-03-09 - CCB016.Defect3
		//private static final String HEADER_METER_METER_SEGMENT = "Meter.MeterSegment";
		private static final String HEADER_METER_METER_SEGMENT = "Meter.Segment";
		// End Change - NMendo - 2021-03-09 - CCB016.Defect3
		private static final String HEADER_METER_METER_SEAL_NUMBER = "Meter.SealNumber";
		private static final String HEADER_METER_CUSTOM_DATA_FIELD_CUSTOM_DATA = "Meter.CustomDataField.CustomData";
		// Start Delete - NMendo - 2021-03-09 - CCB016.Defect3
		//private static final String HEADER_METER_INSTRUCTION_LOCATION_CODE ="Meter.InstructionLocationCode";
		// End Delete - NMendo - 2021-03-09 - CCB016.Defect3
		private static final String HEADER_METER_SPECIAL_MESSAGE = "Meter.SpecialMessage";
		private static final String HEADER_METER_SPECIAL_MESSAGE_INDICATOR = "Meter.SpecialMessageIndicator";
		private static final String HEADER_GPS_INFORMATION_LATITUDE = "GPSInformation.Latitude";
		private static final String HEADER_GPS_INFORMATION_LONGITUDE = "GPSInformation.Longitude";
		private static final String HEADER_METER_SESSION_INPUT_NUMBER_DIALS = "MeterSessionInput.NumberDials";
		private static final String HEADER_METER_SESSION_INPUT_NUMBER_DECIMALS = "MeterSessionInput.NumberDecimals";
		private static final String HEADER_METER_SESSION_INPUT_PREVIOUS_READ = "MeterSessionInput.PreviousRead";
		private static final String HEADER_METER_SESSION_INPUT_PREVIOUS_READ_DATE_TIME = "MeterSessionInput.PreviousReadDateTime";
		private static final String HEADER_METER_SESSION_INPUT_CONSTANT_MULTIPLIER = "MeterSessionInput.ConstantMultiplier";
		private static final String HEADER_METER_SESSION_INPUT_CONSTANT_MULTIPLIER_VALIDATION_INDICATOR = "MeterSessionInput.ConstantMultiplierValidationIndicator";
		private static final String HEADER_METER_SESSION_INPUT_READ_TYPE_CODE = "MeterSessionInput.ReadTypeCode";
		private static final String HEADER_METER_SESSION_INPUT_READ_METHOD = "MeterSessionInput.ReadMethod";
		private static final String HEADER_METER_SESSION_INPUT_PROMPT_CODE = "MeterSessionInput.PromptCode";
		private static final String HEADER_METER_SESSION_INPUT_TEXT_PROMPT = "MeterSessionInput.TextPrompt";
		private static final String HEADER_METER_SESSION_INPUT_READ_DIRECTION = "MeterSessionInput.ReadDirection";
		private static final String HEADER_METER_SESSION_INPUT_CONSECUTIVE_ESTIMATES = "MeterSessionInput.ConsecutiveEstimates";
		private static final String HEADER_METER_SESSION_INPUT_TYPE_OF_VALIDATION_INDICATOR = "MeterSessionInput.TypeOfValidationIndicator";
		private static final String HEADER_METER_SESSION_INPUT_HI1 = "MeterSessionInput.Hi1";
		private static final String HEADER_METER_SESSION_INPUT_HI2 = "MeterSessionInput.Hi2";
		private static final String HEADER_METER_SESSION_INPUT_LOW1 = "MeterSessionInput.Low1";
		private static final String HEADER_METER_SESSION_INPUT_LOW2 = "MeterSessionInput.Low2";
		private static final String HEADER_METER_SESSION_INPUTRF_ENDPOINT_TYPE = "MeterSessionInputRF.EndpointType";
		private static final String HEADER_METER_SESSION_INPUTRF_RF_FREQUENCY = "MeterSessionInputRF.RFFrequency";
		// Start Change - NMendo - 2021-03-03 - CCB016.Defect2
		//private static final String HEADER_METER_SESSION_INPUTRF_ENDPOINT_ID = "MeterSessionInputRF.EndpointId";
		private static final String HEADER_METER_SESSION_INPUTRF_ENDPOINT_ID = "MeterSessionInputRF.EndpointID";
		// End Change - NMendo - 2021-03-03 - CCB016.Defect2
		private static final String HEADER_METER_SESSION_INPUTRF_WAKEUPTONE = "MeterSessionInputRF.WakeupTone";
		private static final String HEADER_METER_SESSION_INPUTRF_TAMPER_COUNT1 = "MeterSessionInputRF.TamperCount1";
		private static final String HEADER_METER_SESSION_INPUTRF_TAMPER_COUNT2 = "MeterSessionInputRF.TamperCount2";
		private static final String ZERO = "0";
		private static final String ONE = "1";
		private static final String DFLT_BLANK_SPECIAL_MESSAGE_INDICATOR = "3";
		private static final String DFLT_METER_READ_METHOD_WITH_ERT = "4";
		private static final String DEFAULT_WORKSET_TYPE = "5";
        /*
         * Start Change - CCB016.Defect5 - 2021-06-07
         */
		//private static final String DEFAULT_WAKEUP_TONE = "7";
		private static final String DEFAULT_WAKEUP_TONE = "4";
        /*
         * Start Change - CCB016.Defect5 - 2021-06-07
         */
		private static final int EIGHT = 8;
		private static final int TWO_INTEGER = 2;
		private static final String BLANK = "";
		private static final String GAS = "GAS";
		private static final String DFLT_MGE_RF_FREQ = "000956.44375";
		// Start Change - NMendo - 2021-03-09 - CCB016.Defect3
		//private static final BigDecimal DFLT_HI_LIMIT = BigDecimal.valueOf(20);
		private static final String DFLT_HI_LIMIT = "20";
		private static final String DFLT_LO_LIMIT = "0";
		// End Change - NMendo - 2021-03-09 - CCB016.Defect3
		private static final CisDivision_Id MGE_CIS_DIVISION = new CisDivision_Id("MGE");

		// Start Change B-18838 JGoco 2021-05-18
		private static final String SUCCESSION_DATA_COLLECTION_TYPE = "S";
		private static final String SUCCESSION_MR_CYCLE_ID = "99";		
		// End Change B-18838 JGoco 2021-05-18
		
		// Start Add - NMendo - CCB016.Defect7 - 2021-07-19
		private static final String BADGE_NUMBER_CHAR_TYPE = "BADGENBR";
		private static final String SERVICE_ROUTE_CHAR_TYPE = "CI_MRRTE";
		private static final String DUE_DATE_CHAR_TYPE = "DUEDATE";
		// End Add - NMendo - CCB016.Defect7 - 2021-07-19
		// Start Add - NMendo - CCB016.Defect8 - 2021-08-07
		private static final String PREMISE_CHAR_TYPE = "PREMISE";
		// End Add - NMendo - CCB016.Defect8 - 2021-08-07
		
		// Work Variables
		private String resultingFilePathName;
		private BufferedWriter buffWriter;
		private Date wScheduleSelectionDate = null;
		//Start Add JVitug - CCB016.Defect 1 - 2020-02-08
		private Date wScheduledReadDate = null;
		//End Add JVitug - CCB016.Defect 1 - 2020-02-08
		private final DateFormat dateFormat = new DateFormat("yyyy-MM-dd");
		private final DateFormat dateTimeFormat = new DateFormat("yyyy-MM-dd'T'HH:mm:ss");
		private Bool isFirstTime = Bool.TRUE;
		private COTSInstanceList itronMeterFilteringInfoList;
		// Start Change B-18838 JGoco 2021-05-18
		private COTSInstanceList successionFilteringInfoList;
		// End Change B-18838 JGoco 2021-05-18
		// Start Delete - NMendo - 2021-03-09 - CCB016.Defect3
		//private COTSInstanceList itronMeterLocationList;
		// End Delete - NMendo - 2021-03-09 - CCB016.Defect3
		private COTSInstanceList itronReadTypeCodeList;
		private COTSInstanceList itronEndpointTypeList;
		private COTSInstanceList mrRouteTypeList;
		private String workSetFieldsDelimitedByComma;
		private String customerFieldsDelimitedByComma;
		private String meterFieldsDelimitedByComma;
		private String latLongFieldsDelimitedByComma;
		private String meterSessionInputFieldDelimitedByComma;
		private String meterSessionInputFieldRFDelimitedByComma;
		private String wErtCharValue;
		private Item_Id itemID;
		private ServicePointMeterHistory_Id spMeterHistID;
		private String ertItemTypeListStr;
		private String hiLimit;
		private String loLimit;
		private Bool shouldDefaultHighLow = Bool.FALSE;
		// Start Add - NMendo - CCB016.Defect7 - 2021-07-19
		private CharacteristicTypeLookup customerReadSaCharTypeLookup;
		private CustomerContactType_Id customerReadCcTypeId;
		private CharacteristicType badgeNumberCharType;
		private CharacteristicType serviceRouteCharType;
		private CharacteristicType dueDateCharType;
		// End Add - NMendo - CCB016.Defect7 - 2021-07-19
		// Start Add - NMendo - CCB016.Defect8 - 2021-08-07
		private CharacteristicType premiseCharType;
		// End Add - NMendo - CCB016.Defect8 - 2021-08-07
		// Start Add - IReyes - B-26006 - 2023-02-08
		private Bool suppressFileField = Bool.FALSE;
		// End Add - IReyes - B-26006 - 2023-02-08

		//WorkSet Details
		private String workSetID;
		private String workSetType = DEFAULT_WORKSET_TYPE;
		private String scheduledReadDate;
		private String filteringInformation;
		private String cycle;
		private String criticalReadDate;
		private String defaultDataCollectionType;

		//Customer Details
		private String fullname;
		private String fullStreetAddress;
		private String accountNumber;
		private String lastName;
		private String firstName;
		private String middleName;
		private String streetNumber;
		private String streetName;
		private String suite;
		private String city;
		private String stateOrProvince;
		private String postal;

		//Meter Details
		private String meterUtilityMeterSequenceNumber;
		private String meterMeterNumber;
		private String meterMeterCategory;
		private String meterMeterType;
		private String meterActiveIndicator;
		private String meterMeterSegment;
		private String meterSealNumber;
		private String meterCustomDataFieldCustomData;
		// Start Delete - NMendo - 2021-03-09 - CCB016.Defect3
		//private String meterInstructionLocationCode;
		// End Delete - NMendo - 2021-03-09 - CCB016.Defect3
		private String meterSpecialMessage;
		private String meterSpecialMessageIndicator;

		//GPS Information
		private String latitude;
		private String longitude;

		//Meter Session Input Details
		private String meterSessionInputNumberDials;
		private String meterSessionInputNumberDecimals;
		private String meterSessionInputPreviousRead;
		private String meterSessionInputPreviousReadDateTime;
		private String meterSessionInputConstantMultiplier;
		private String meterSessionInputConstantMultiplierValidationIndicator;
		private String meterSessionInputReadTypeCode;
		private String meterSessionInputReadMethod;
		private String meterSessionInputPromptCode;
		private String meterSessionInputTextPrompt;
		private String meterSessionInputReadDirection;
		private String meterSessionInputConsecutiveEstimates;
		private String meterSessionInputTypeOfValidationIndicator;
		private String meterSessionInputHi1;
		private String meterSessionInputHi2;
		private String meterSessionInputLow1;
		private String meterSessionInputLow2;

		//Meter Session Input RF Details
		private String meterSessionInputRFEndpointType;
		private String meterSessionInputRFRFFrequency;
		private String meterSessionInputRFEndpointId;
		private String meterSessionInputRFWakeupTone;
		private String meterSessionInputRFTamperCount1;
		private String meterSessionInputRFTamperCount2;
		

		/**
		 * Base method which is invoked once per thread (executed before the main processing)
		 */		
		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
			parmFilePath = this.getParameters().getFILE_PATH();
			// Retrieve File Name
			parmFileName = this.getParameters().getFILE_NAME();
			// Retrieve Service Task Type for ITRON
			itronServiceTaskType = this.getParameters().getCM_ITRONCONFIG();
			
			// Form file path name
			cmFormFilePathName();
			// Open the file
			cmOpenFile(resultingFilePathName);

			// Form and write the header record line	
			cmFormFileHeaderRecordLineAndWrite();	
			
			// Start Add - NMendo - CCB016.Defect7 - 2021-07-19
			parmCustomerReadSaCharType = this.getParameters().getCUSTOMER_READ_SA_CHAR_TYPE();
			parmCustomerReadSaCharVal = this.getParameters().getCUSTOMER_READ_SA_CHAR_VAL();
			parmCustomerReadCustomerContactClass = this.getParameters().getCUSTOMER_READ_CC_CLASS();
			parmCustomerReadCustomerContactType = this.getParameters().getCUSTOMER_READ_CC_TYPE();
			
			if(notNull(parmCustomerReadSaCharType)) {
				customerReadSaCharTypeLookup = parmCustomerReadSaCharType.getCharacteristicType();
				customerReadCcTypeId = new CustomerContactType_Id(parmCustomerReadCustomerContactClass, parmCustomerReadCustomerContactType);
				CharacteristicType_Id badgeNumberCharTypeId = new CharacteristicType_Id(BADGE_NUMBER_CHAR_TYPE);
				badgeNumberCharType = badgeNumberCharTypeId.getEntity();
				CharacteristicType_Id serviceRouteCharTypeId = new CharacteristicType_Id(SERVICE_ROUTE_CHAR_TYPE);
				serviceRouteCharType = serviceRouteCharTypeId.getEntity();
				CharacteristicType_Id dueDateCharTypeId = new CharacteristicType_Id(DUE_DATE_CHAR_TYPE);
				dueDateCharType = dueDateCharTypeId.getEntity();
				// Start Add - NMendo - CCB016.Defect8 - 2021-08-07
				CharacteristicType_Id premiseCharTypeId = new CharacteristicType_Id(PREMISE_CHAR_TYPE);
				premiseCharType = premiseCharTypeId.getEntity();
				// End Add - NMendo - CCB016.Defect8 - 2021-08-07
			}
			// End Add - NMendo - CCB016.Defect7 - 2021-07-19
			
			// Start Add - IReyes - B-26006 - 2023-02-08
			if(notNull(this.getParameters().getSUPPRESS_EXTRACT_FILE_FIELD())){
				suppressFileField = this.getParameters().getSUPPRESS_EXTRACT_FILE_FIELD();
			}
			// End Add - IReyes - B-26006 - 2023-02-08
		}
		
		/**
		 * Method to write the header record to a file 
		 */
		private void cmFormFileHeaderRecordLineAndWrite() {
			
			StringBuilder header = new StringBuilder();
			
			header.append(HEADER_WORKSET_WORKID);
			header.append(COMMA);
			header.append(HEADER_WORKSET_WORK_SET_TYPE);
			header.append(COMMA);
			header.append(HEADER_WORKSET_SCHEDULED_READ_DATE);
			header.append(COMMA);
			header.append(HEADER_WORKSET_FILTERING_INFORMATION);
			header.append(COMMA);
			header.append(HEADER_WORKSET_CYCLE);
			header.append(COMMA);
			header.append(HEADER_WORKSET_CRITICAL_READ_DATE);
			header.append(COMMA);
			header.append(HEADER_WORKSET_DEFAULT_DATA_COLLECTION_TYPE);
			header.append(COMMA);
			header.append(HEADER_CUSTOMER_FULLNAME);
			header.append(COMMA);
			header.append(HEADER_CUSTOMER_FULL_STREET_ADRESS);
			header.append(COMMA);
			header.append(HEADER_CUSTOMER_ACCOUNT_NUMBER);
			header.append(COMMA);
			header.append(HEADER_CUSTOMER_LAST_NAME);
			header.append(COMMA);
			header.append(HEADER_CUSTOMER_FIRST_NAME);
			header.append(COMMA);
			header.append(HEADER_CUSTOMER_MIDDLE_NAME);
			header.append(COMMA);
			header.append(HEADER_CUSTOMER_STREET_NUMBER);
			header.append(COMMA);
			header.append(HEADER_CUSTOMER_STREET_NAME);
			header.append(COMMA);
			header.append(HEADER_CUSTOMER_CUSTOMER_SUITE);
			header.append(COMMA);
			header.append(HEADER_CUSTOMER_CITY);
			header.append(COMMA);
			header.append(HEADER_CUSTOMER_STATE_OR_PROVINCE);
			header.append(COMMA);
			header.append(HEADER_CUSTOMER_POSTAL);
			header.append(COMMA);
			header.append(HEADER_METER_UTILITY_METER_SEQUENCE_NUMBER);
			header.append(COMMA);
			header.append(HEADER_METER_METER_NUMBER);
			header.append(COMMA);
			header.append(HEADER_METER_METER_CATEGORY);
			header.append(COMMA);
			header.append(HEADER_METER_METER_TYPE);
			header.append(COMMA);
			header.append(HEADER_METER_ACTIVE_INDICATOR);
			header.append(COMMA);
			header.append(HEADER_METER_METER_SEGMENT);
			header.append(COMMA);
			header.append(HEADER_METER_METER_SEAL_NUMBER);
			header.append(COMMA);
			header.append(HEADER_METER_CUSTOM_DATA_FIELD_CUSTOM_DATA);
			header.append(COMMA);
			// Start Delete - NMendo - 2021-03-09 - CCB016.Defect3
			//header.append(HEADER_METER_INSTRUCTION_LOCATION_CODE);
			//header.append(COMMA);
			// End Delete - NMendo - 2021-03-09 - CCB016.Defect3
			header.append(HEADER_METER_SPECIAL_MESSAGE);
			header.append(COMMA);
			header.append(HEADER_METER_SPECIAL_MESSAGE_INDICATOR);
			header.append(COMMA);
			header.append(HEADER_GPS_INFORMATION_LATITUDE);
			header.append(COMMA);
			header.append(HEADER_GPS_INFORMATION_LONGITUDE);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_NUMBER_DIALS);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_NUMBER_DECIMALS);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_PREVIOUS_READ);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_PREVIOUS_READ_DATE_TIME);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_CONSTANT_MULTIPLIER);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_CONSTANT_MULTIPLIER_VALIDATION_INDICATOR);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_READ_TYPE_CODE);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_READ_METHOD);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_PROMPT_CODE);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_TEXT_PROMPT);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_READ_DIRECTION);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_CONSECUTIVE_ESTIMATES);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_TYPE_OF_VALIDATION_INDICATOR);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_HI1);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_HI2);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_LOW1);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUT_LOW2);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUTRF_ENDPOINT_TYPE);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUTRF_RF_FREQUENCY);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUTRF_ENDPOINT_ID);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUTRF_WAKEUPTONE);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUTRF_TAMPER_COUNT1);
			header.append(COMMA);
			header.append(HEADER_METER_SESSION_INPUTRF_TAMPER_COUNT2);
			
			cmWriteToFile(header.toString());
		}

		/**
		 * Custom Method which forms the resulting file path 
		 * 
		 * FILE_PATH.concat(FILE_NAME.concat(_BatchCode.concat(_BatchThreadNumber.concat(_ProcessDateTime
		 *
		 */
		private void cmFormFilePathName() {

			// Filepath = replace all \ with / and make sure that the file path ends with a /
			String filePath = parmFilePath;
			if (!filePath.trim().endsWith(FORWARDSLASH)
					&& !filePath.trim().endsWith(BACKSLASH)) {
				filePath = filePath.trim().concat(BACKSLASH);
			}
			filePath = filePath.replace(FORWARDSLASH, BACKSLASH);

			// Filename = parameter 20_batchCode_batchNumber_batchThreadNumber
			String fileName;

			String batchDetails = this.getBatchControlId().getTrimmedValue();
			batchDetails = batchDetails.trim().concat(UNDERSCORE).concat(this.getBatchNumber().toString());				
			batchDetails = batchDetails.trim().concat(UNDERSCORE).concat(this.getBatchThreadNumber().toString());
			batchDetails = batchDetails.trim().concat(UNDERSCORE).concat(this.getProcessDateTime().toString());

			fileName = parmFileName.trim().concat(UNDERSCORE).concat(batchDetails).concat(DOT).concat(CSV);

			resultingFilePathName = filePath.trim().concat(fileName.trim());						
		}

		/**
		 * Custom method which opens the file
		 * @param fileName
		 */
		private void cmOpenFile(String fileName) {
			try {
				File file = new File(fileName);
				buffWriter = new BufferedWriter(new FileWriter(file));
			} catch (Exception e) { 
				// Error encountered opening file (%1%2%3%4)
				addError(CustomMessageRepositorySpireOne.errorOpeningFile(fileName.trim()));
			}
		}
		/**
		 * Custom method which writes to the file
		 * @param stringToWrite
		 */
		private void cmWriteToFile(String stringToWrite) {
			
			try {
				buffWriter.write(stringToWrite);
				buffWriter.write(CARRIAGE_RETURN_LINE_FEED);
			} catch (Exception e) {
				// Error encountered writing to file
				addError(CustomMessageRepositorySpireOne.errorWritingToFile(resultingFilePathName.trim()));
			}
		}
		/**
		 * Custom method which closes the file
		 *
		 */
		private void cmCloseFile() {
			try {
				buffWriter.close();
			} catch (Exception e) {
				// Error encountered closing file
				addError(CustomMessageRepositorySpireOne.errorClosingFile(resultingFilePathName.trim()));
			}
		}

		/**
		 * Single commit strategy
		 */
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new CommitEveryUnitStrategy(this);
		}
		// retrieve directly the itron amr segment via SQL instead of using OOP 
		// which would then get the entire row before retrieving the Segment Code.
		private String cmRetrieveItronAMRSegmentCode(String townCode, String gridCode) {
			String amrSegmentCode = "";
			
			StringBuilder stringBuilder = new StringBuilder();			
			stringBuilder.append("SELECT CM_ITRON_SEGMENT_CD ");
			stringBuilder.append("FROM CM_AMR_SEGMENT ");
			stringBuilder.append("WHERE CM_ITRON_TOWN_CD = :townCode ");
			stringBuilder.append("AND CM_ITRON_GRID_CD = :gridCode ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			prepState.bindString("townCode", townCode, "CM_ITRON_TOWN_CD");
			prepState.bindString("gridCode", gridCode, "CM_ITRON_GRID_CD");
			
			SQLResultRow sqlRow = prepState.firstRow();
			prepState.close();
			if (notNull(sqlRow)) {
				amrSegmentCode = sqlRow.getString("CM_ITRON_SEGMENT_CD").trim();
			}
			
			return amrSegmentCode;
		}
		
		private void initializeWorkingVariables() {
			workSetFieldsDelimitedByComma = BLANK;
			customerFieldsDelimitedByComma = BLANK;
			meterFieldsDelimitedByComma = BLANK;
			latLongFieldsDelimitedByComma = BLANK;
			meterSessionInputFieldDelimitedByComma = BLANK;
			meterSessionInputFieldRFDelimitedByComma = BLANK;
			hiLimit = BLANK;
			loLimit = BLANK;

			//WorkSet Details
			workSetID = BLANK ;
			workSetType = DEFAULT_WORKSET_TYPE ;
			scheduledReadDate = BLANK ;
			filteringInformation = BLANK ;
			cycle = BLANK ;
			criticalReadDate = BLANK ;
			defaultDataCollectionType = BLANK ;

			//Customer Details
			fullname = BLANK ;
			fullStreetAddress = BLANK ;
			accountNumber = BLANK ;
			lastName = BLANK ;
			firstName = BLANK ;
			middleName = BLANK ;
			streetNumber = BLANK ;
			streetName = BLANK ;
			suite = BLANK ;
			city = BLANK ;
			stateOrProvince = BLANK ;
			postal = BLANK ;

			//Meter Details
			meterUtilityMeterSequenceNumber = BLANK ;
			meterMeterNumber = BLANK ;
			meterMeterCategory = ONE ;
			meterMeterType = BLANK ;
			meterActiveIndicator = BLANK ;
			meterMeterSegment = BLANK ;
			meterSealNumber = BLANK ;
			meterCustomDataFieldCustomData = BLANK ;
			// Start Delete - NMendo - 2021-03-09 - CCB016.Defect3
			//meterInstructionLocationCode = BLANK ;
			// End Delete - NMendo - 2021-03-09 - CCB016.Defect3
			meterSpecialMessage = BLANK ;
			meterSpecialMessageIndicator = BLANK ;

			//GPS Information
			latitude = BLANK;
			longitude = BLANK;

			//Meter Session Input Details
			meterSessionInputNumberDials = BLANK ;
			meterSessionInputNumberDecimals = BLANK ;
			meterSessionInputPreviousRead = BLANK ;
			meterSessionInputPreviousReadDateTime = BLANK ;
			meterSessionInputConstantMultiplier = BLANK ;
			meterSessionInputConstantMultiplierValidationIndicator = BLANK ;
			meterSessionInputReadTypeCode = BLANK ;
			meterSessionInputReadMethod = BLANK ;
			meterSessionInputPromptCode = BLANK ;
			meterSessionInputTextPrompt = BLANK ;
			meterSessionInputReadDirection = BLANK ;
			meterSessionInputConsecutiveEstimates = BLANK ;
			meterSessionInputTypeOfValidationIndicator = BLANK ;
			meterSessionInputHi1 = BLANK ;
			meterSessionInputHi2 = BLANK ;
			meterSessionInputLow1 = BLANK ;
			meterSessionInputLow2 = BLANK ;

			//Meter Session Input RF Details
			meterSessionInputRFEndpointType = BLANK ;
			meterSessionInputRFRFFrequency = BLANK ;
			meterSessionInputRFEndpointId = BLANK ;
			meterSessionInputRFWakeupTone = BLANK ;
			meterSessionInputRFTamperCount1 = BLANK ;
			meterSessionInputRFTamperCount2 = BLANK ;
			
			itemID = null;
			wErtCharValue = BLANK;
		}

		/**
		 * The main processing method
		 */
		@Override
		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
		    spMeterHistID = (ServicePointMeterHistory_Id) unit.getPrimaryId();
			wScheduleSelectionDate = (Date) unit.getSupplementallData("SCHED_SEL_DT");
			String mrRouteCode = (String) unit.getSupplementallData("MR_RTE_CD");
			MeterReadCycle_Id mrCycleID  = (MeterReadCycle_Id) unit.getSupplementallData("MR_CYC_CD");
			ServicePoint sp = spMeterHistID.getEntity().getServicePoint();
			MeterConfiguration cfg = spMeterHistID.getEntity().getMeterConfiguration();
			Meter meter = cfg.getMeter();
			Premise premise = sp.getPremise();
			MeterRead previousRead = cmRetrieveLatestMeterRead(cfg.getId());
			List<SQLResultRow> registers = cmRetrieveRegisters(cfg.getMeter());
			
			//Read the Service task
			//process service task type (CM-ITRONCONFIG) one time only
			if (isFirstTime.isTrue()){				
				
				isFirstTime = Bool.FALSE;			
				// Retrieve Itron meter location from CM-ITRONCONFIG
				BusinessObjectInstance placementBoInstance;
				placementBoInstance = BusinessObjectInstance.create(itronServiceTaskType.getBusinessObject());
				placementBoInstance.setXMLString("serviceTaskType",itronServiceTaskType.getId().getTrimmedValue());
				placementBoInstance = BusinessObjectDispatcher.read(placementBoInstance);	

				COTSInstanceNode itronDetailInstruction = placementBoInstance.getGroup("itronDetails");
				itronMeterFilteringInfoList = itronDetailInstruction.getList("mrFilterInfo");
				// Start Change B-18838 JGoco 2021-05-18
				successionFilteringInfoList = itronDetailInstruction.getList("succFilterInfo");
				// End Change B-18838 JGoco 2021-05-18
				// Start Delete - NMendo - 2021-03-09 - CCB016.Defect3
				//itronMeterLocationList = itronDetailInstruction.getList("meterLocationList");
				// End Delete - NMendo - 2021-03-09 - CCB016.Defect3
				itronReadTypeCodeList = itronDetailInstruction.getList("mrReadTypeCode");
				itronEndpointTypeList = itronDetailInstruction.getList("mrEndpointType");
				mrRouteTypeList = itronDetailInstruction.getList("mrRouteType");
				
				COTSInstanceList mrErtItemTypeList = itronDetailInstruction.getList("mrErtItemType");
				Iterator<COTSInstanceListNode> mrErtItemTypeIter = mrErtItemTypeList.iterator();
				ertItemTypeListStr = SINGLE_QUOTE.concat(SINGLE_QUOTE);
				StringBuilder mrErtItemTypeSb = new StringBuilder();
				while(mrErtItemTypeIter.hasNext()) {
					COTSInstanceListNode mrErtItemTypeNode = mrErtItemTypeIter.next();
					mrErtItemTypeSb.append(SINGLE_QUOTE);
					mrErtItemTypeSb.append(mrErtItemTypeNode.getString("ertItemTypeCd").trim());
					mrErtItemTypeSb.append(SINGLE_QUOTE);
					
					if(mrErtItemTypeIter.hasNext()) {
						mrErtItemTypeSb.append(COMMA);
					}
				}
				ertItemTypeListStr = mrErtItemTypeSb.toString();
				
				COTSInstanceNode mrCharTypes = itronDetailInstruction.getGroup("mrCharTypes");
				String tamper1CharTypeStr = mrCharTypes.getString("tamper1CharType").trim();
				String tamper2CharTypeStr = mrCharTypes.getString("tamper2CharType").trim();
				String districtCharTypeStr = mrCharTypes.getString("districtCodeCharType").trim();
				// Start Delete - NMendo - CCB016.Defect6 -  2021-06-17
				//String uomItemCharTypeStr = mrCharTypes.getString("itemUomCharType").trim();
				// End Delete - NMendo - CCB016.Defect6 -  2021-06-17
				String townCodeCharTypeStr = mrCharTypes.getString("townCodeCharType").trim();
				String ertCharTypeStr = mrCharTypes.getString("ertTypeCharType").trim();
				//Start Add JVitug - CCB016.Defect4 - 2021-03-24
				String maximoReadTypeCharTypeStr = mrCharTypes.getString("maximoReadTypeCharType").trim();
				//End Add JVitug - CCB016.Defect4 - 2021-03-24
				
				tamper1CharType = new CharacteristicType_Id(tamper1CharTypeStr).getEntity();
				tamper2CharType = new CharacteristicType_Id(tamper2CharTypeStr).getEntity();
				districtCharType = new CharacteristicType_Id(districtCharTypeStr).getEntity();
				// Start Delete - NMendo - CCB016.Defect6 -  2021-06-17
				//uomItemCharType = new CharacteristicType_Id(uomItemCharTypeStr).getEntity();
				// End Delete - NMendo - CCB016.Defect6 -  2021-06-17
				townCodeCharType = new CharacteristicType_Id(townCodeCharTypeStr).getEntity();
				ertCharType = new CharacteristicType_Id(ertCharTypeStr).getEntity();
				//Start Add JVitug - CCB016.Defect4 - 2021-03-24
				maximoReadTypeCharType = new CharacteristicType_Id(maximoReadTypeCharTypeStr).getEntity();
				//End Add JVitug - CCB016.Defect4 - 2021-03-24
				
				COTSInstanceNode mrPremGeoType = itronDetailInstruction.getGroup("mrPremGeoType");
				String latLongGeoTypeStr = mrPremGeoType.getString("latLongGeoType").trim();
				String gridCodeGeoTypeStr = mrPremGeoType.getString("gridCodeGeoType").trim();
				
				latLongGeoType = new GeographicType_Id(latLongGeoTypeStr).getEntity();
				gridCodeGeoType = new GeographicType_Id(gridCodeGeoTypeStr).getEntity();
			}
			
			// Start Add - NMendo - CCB016.Defect7 - 2021-07-19
			processCustomerReadMeter(sp.getId(), meter, mrRouteCode);
			// End Add - NMendo - CCB016.Defect7 - 2021-07-19
			
			for(SQLResultRow row : registers) {
				Register register = row.getEntity("REG_ID", Register.class);
				
				//initialize working variables
				initializeWorkingVariables();
				
				cmCheckMeterForErtEquipment(meter , cfg, register);
				
				prepareWorkSetDetails(sp , premise , wScheduleSelectionDate , mrRouteCode , mrCycleID);
				
				// Retrieve current customer with active service
				prepareCustomerDetails(sp.getId());
				
				//Prepare GPS details
				prepareGPSDetails(premise);

				//Prepare meter Details
				prepareMeterRecordDetails(spMeterHistID, sp , cfg , register, premise);


				//Prepare the meterInputSessionDetails
				prepareMeterSessionInputDetails(sp ,register , cfg , previousRead);

				//Prepare the meterSessionInputRFDetails
				prepareMeterSessionInputRFDetails(premise , meter , cfg, previousRead , register);
				
				// Form the record line and Write it to the flat file per register
				writeToFile();
			}
			
			
			return true;
		}

		/**
		 * Custom method which retrieves premise characteristic value base on charType (in this case it is towncode)
		 *  @param premise: the premise of service point that is processing
		 *  @param charType: characteristic TOWNCD of premise
		 *  @return charVal: characteristic value 
		 */
		private String getPremiseChar(Premise premise, CharacteristicType charType) {

			String charVal = BLANK;
			PremiseCharacteristic premChar = premise.getEffectiveCharacteristic(charType);
			if (notNull(premChar)){       
				if (charType.getCharacteristicType().isPredefinedValue()){
					charVal = premChar.getCharacteristicValue().trim();
				} else if (charType.getCharacteristicType().isForeignKeyValue()) {
					charVal = premChar.getCharacteristicValueForeignKey1().trim();
				} else {
					charVal = premChar.getAdhocCharacteristicValue().trim();
				}
			}
			return charVal.trim();
		}
		
		/**
		 * Custom method which retrieves Route Type base on cycle and route number
		 * @param cycle, route
		 * @return Route type
		 */
		private String cmRetrieveRouteType(String cycle, String route) {
			StringBuilder sql = new StringBuilder();
			MeterReadCycle_Id mrCycle = new MeterReadCycle_Id(cycle);
			
			sql.append("SELECT ");
			sql.append(   "MRRTE.MR_RTE_TYPE_CD ");
			sql.append("FROM ");
			sql.append(   "CI_MR_RTE MRRTE ");
			sql.append("WHERE ");
			sql.append(   "MRRTE.MR_CYC_CD = :cycle ");
			sql.append("AND ");
			sql.append(   "MRRTE.MR_RTE_CD = :route ");
			
			PreparedStatement countRoute = createPreparedStatement(sql.toString(), getClass().getName());
			countRoute.bindId("cycle", mrCycle);
			countRoute.bindString("route", route , "MR_RTE_CD");
	  
			SQLResultRow result = countRoute.firstRow();
			countRoute.close();
			if (notNull(result)) {
				return result.getString("MR_RTE_TYPE_CD").trim();
			}  else {
				return BLANK;
			}
		}

		/**
		 * Prepare WorkSet fields 
		 * @param spmhID the ServicePointMeterHistoryID
		 */
		private void prepareWorkSetDetails(ServicePoint sp
				, Premise premise
				, Date wScheduleSelectionDate 
				, String mrRouteCode 
				,MeterReadCycle_Id mrCycleID) {
			
			String districtValue = getPremiseChar(premise, districtCharType);
			workSetID = prepareWorkSetID(mrCycleID , mrRouteCode);
			
			//Start Delete JVitug - CCB016.Defect 1 - 2020-02-08
			//scheduledReadDate = wScheduleDate.toString(dateFormat).trim();
			//End Delete JVitug - CCB016.Defect 1 - 2020-02-08
			if(notNull(sp.fetchMeterReadCycle())) {
				cycle = sp.fetchMeterReadCycle().getId().getTrimmedValue();
			}
			
			//Start Add Jvitug - CCB016.Defect 1 - 2020-02-08
			//Derive the Scheduled read date using the Scheduled selection date
			//and Meter Cycle Code
			wScheduledReadDate = getScheduledReadDate(mrCycleID , wScheduleSelectionDate);
			if(notNull(wScheduledReadDate)) {
				scheduledReadDate = wScheduledReadDate.toString(dateFormat).trim();
			//End Add JVitug - CCB016.Defect 1 - 2020-02-08
			
			//Start Change JVitug - CCB016.Defect 1 - 2020-02-08	
				//criticalReadDate = getCriticalReadDate(mrCycleID , wScheduleSelectionDate);
				criticalReadDate = getCriticalReadDate(mrCycleID , wScheduledReadDate);
			}
			//End Change JVitug - CCB016.Defect 1 - 2020-02-08
			
			//If the meter route type code is I-AMR , set the defaultDataCollectionType to 2, else 
			//if the meter route type code is I-OMR , set the defaultDataCollectionType to 1
			String mrRouteTypeCode = cmRetrieveRouteType(mrCycleID.getTrimmedValue(), mrRouteCode.trim());
					
			shouldDefaultHighLow = Bool.FALSE;
			Iterator<COTSInstanceListNode> mrRouteTypeIter = mrRouteTypeList.iterator();
			while(mrRouteTypeIter.hasNext()) {
				COTSInstanceListNode mrRouteTypeListNode = mrRouteTypeIter.next();
				if(mrRouteTypeListNode.getString("meterReadRouteType").trim().equals(mrRouteTypeCode)) {
					defaultDataCollectionType = mrRouteTypeListNode.getString("defaultCollectionType").trim();
					
					if(mrRouteTypeListNode.getBoolean("defaultHighLowSw").isTrue()) {
						shouldDefaultHighLow = Bool.TRUE;
					}
					break;
				}
			}
			
			//Get the filtering information from the Service Task Id using the District code
			//Check if filtering information is not empty then create meterInstructionIter	        
			if((!itronMeterFilteringInfoList.isEmpty()) 
					&& (notBlank(districtValue))) {
				
				Iterator<COTSInstanceListNode> meterFilteringInfoIterator = itronMeterFilteringInfoList.iterator();
				while(meterFilteringInfoIterator.hasNext()) {           	
					
					COTSInstanceListNode meterFilteringInfoNode = meterFilteringInfoIterator.next();	        		
					if (meterFilteringInfoNode.getString("mrDistrict").trim().equalsIgnoreCase(
							districtValue)) {
						filteringInformation = meterFilteringInfoNode.getString("itronFilterInfo").trim();
						break;
					}
				}
			}
			
			// Start Change B-18838 JGoco 2021-05-18
			// If meter route type code is Blank and MR Cycle ID is 99, this is a Succession Read.
			// Recreate the Work Set ID with MR Cycle + "S" + MR Route Code(Territory).
			// Set Data Collection Type to "S", scheduled Read and Critical Read Date to 
			// Schedule Selection date, cycle to "99", and retrieve succession filtering information.
			if (mrRouteTypeCode.equals(BLANK) && mrCycleID.getTrimmedValue().equals(SUCCESSION_MR_CYCLE_ID)) {
				
				workSetID = mrCycleID.getTrimmedValue();
				workSetID = workSetID.concat(SUCCESSION_DATA_COLLECTION_TYPE);
				workSetID = workSetID.concat(mrRouteCode.trim());				
				cycle = mrCycleID.getTrimmedValue();
				// Start Change - NMendo - CCB016.Defect6 -  2021-06-17
				//defaultDataCollectionType = SUCCESSION_DATA_COLLECTION_TYPE;	
				String spMrRouteTypeCode = cmRetrieveRouteType(sp.fetchMeterReadCycle().getId().getTrimmedValue(), sp.getMeterReadRoute());
				Iterator<COTSInstanceListNode> spMrRouteTypeIter = mrRouteTypeList.iterator();
				while(spMrRouteTypeIter.hasNext()) {
					COTSInstanceListNode spMrRouteTypeListNode = spMrRouteTypeIter.next();
					if(spMrRouteTypeListNode.getString("meterReadRouteType").trim().equals(spMrRouteTypeCode)) {
						defaultDataCollectionType = spMrRouteTypeListNode.getString("defaultCollectionType").trim();
						break;
					}
				}
				// End Change - NMendo - CCB016.Defect6 -  2021-06-17
				scheduledReadDate = wScheduleSelectionDate.toString(dateFormat).trim();
				criticalReadDate = wScheduleSelectionDate.toString(dateFormat).trim();
				
				//Get the filtering information from the Service Task Id using the Premise CIS Division
				if((!successionFilteringInfoList.isEmpty())) {
					
					Iterator<COTSInstanceListNode> meterFilteringInfoIterator = successionFilteringInfoList.iterator();
					while(meterFilteringInfoIterator.hasNext()) {           	
						
						COTSInstanceListNode meterFilteringInfoNode = meterFilteringInfoIterator.next();	        		
						if (meterFilteringInfoNode.getString("cisDivision").trim().equalsIgnoreCase(
								premise.getDivisionId().getTrimmedValue())) {
							filteringInformation = meterFilteringInfoNode.getString("itronFilterInfo").trim();
							break;
						}
					}
				}
				
				
			}
			// End Change B-18838 JGoco 2021-05-18				
			
			//Merge all fields delimited by comma
			workSetFieldsDelimitedByComma = workSetFieldsDelimitedByComma.concat(workSetID).concat(COMMA);
			workSetFieldsDelimitedByComma = workSetFieldsDelimitedByComma.concat(workSetType).concat(COMMA); 
			workSetFieldsDelimitedByComma = workSetFieldsDelimitedByComma.concat(scheduledReadDate).concat(COMMA);
			workSetFieldsDelimitedByComma = workSetFieldsDelimitedByComma.concat(filteringInformation).concat(COMMA);
			workSetFieldsDelimitedByComma = workSetFieldsDelimitedByComma.concat(cycle).concat(COMMA);
			workSetFieldsDelimitedByComma = workSetFieldsDelimitedByComma.concat(criticalReadDate).concat(COMMA);
			workSetFieldsDelimitedByComma = workSetFieldsDelimitedByComma.concat(defaultDataCollectionType);
		}
		
		private String prepareWorkSetID(MeterReadCycle_Id mrCycleID , String mrRouteCode) {
			String workSetId = "";
			String holder = "";
			
			workSetId = mrCycleID.getTrimmedValue();
			holder = mrCycleID.getTrimmedValue().concat(mrRouteCode.trim());
			
			//If the length of the string resulting
			//from the combination of the Meter Read Cycle and Meter Route Code 
			//is less than 8, we append dashes in between
			if(holder.length() < EIGHT) {
				for(int i = 0 ; i < (EIGHT - holder.length()) ; i++) {
					workSetId = workSetId.concat(HYPHEN);
				}
			}
			workSetId = workSetId.concat(mrRouteCode.trim());
			
			return workSetId;
		}
		
		/**
		 * Get the next bill window start date after the schedule read date
		 * @param mrCycleID
		 * @param wScheduleDate
		 * @return Next bill window start date after schedule read date
		 */
		private String getCriticalReadDate(MeterReadCycle_Id mrCycleID, Date wScheduleDate) {
			String criticalReadDateInThisMethod = BLANK;
			StringBuilder sql = new StringBuilder();
			
			sql.append("SELECT ");
			sql.append(   "MIN(BILL.WIN_END_DT) AS WIN_START_DT ");
			sql.append("FROM ");
			sql.append(   "CI_BILL_CYC_SCH BILL, ");
			sql.append(   "CI_MR_CYC MR ");
			sql.append("WHERE ");
			sql.append(   "MR.MR_CYC_CD = :meterReadCycle ");
			sql.append("AND ");
			sql.append(   "MR.BILL_CYC_CD = BILL.BILL_CYC_CD ");
			sql.append("AND ");
			sql.append(   "BILL.WIN_START_DT >= :scheduleDate ");
			
			PreparedStatement stmt = createPreparedStatement(sql.toString() , getClass().getName());
			stmt.bindId("meterReadCycle", mrCycleID);
			stmt.bindDate("scheduleDate", wScheduleDate);
			
			SQLResultRow result = stmt.firstRow();
			stmt.close();
			
			if(notNull(result.getDate("WIN_START_DT"))) {
				criticalReadDateInThisMethod = result.getDate("WIN_START_DT").toString(dateFormat).trim();
			}
			
			return criticalReadDateInThisMethod.trim();
		}
		/**
		 * Custom method which retrieves the current customer Account
		 * @param spID the Service Point Id
		 */
		private void prepareCustomerDetails(ServicePoint_Id spID) {
			Account_Id account = getActiveCustomer(spID);
			Premise premise = spID.getEntity().getPremise();
			// Start Change - NMendo - 2021-03-09 - CCB016.Defect3
			if(notNull(account)) {
				fullname = account.getEntity().getMainPerson().getPersonPrimaryName().toUpperCase();
				
				//if Full name contains a comma, set the last name as the string before the comma
				// and the first name as the string after the comma. Rearrange them so that 
				//the first name is first before the last name
				if(fullname.contains(COMMA)){
					lastName = fullname.subSequence(0, fullname.indexOf(COMMA)).toString().trim();
					firstName = fullname.substring(fullname.indexOf(COMMA)+1).trim();
					
					/*
					 * Start Change - CCB016.Defect5 - 2021-06-07
					 */
					//fullname = firstName.concat(SPACE).concat(lastName).trim();
					fullname = firstName.concat(SPACE).concat(lastName).replace(',', ' ').trim();
					/*
                     * End Change - CCB016.Defect5 - 2021-06-07
                     */
				}
				
                /*
                 * Start Add - CCB016.Defect5 - 2021-06-07
                 */
                fullname = StringUtils.left(fullname, 42);
                /*
                 * End Add - CCB016.Defect5 - 2021-06-07
                 */
				
				//fullStreetAddress = premise.getAddress1().trim().toUpperCase();
				accountNumber = account.getTrimmedValue();
				//streetNumber = premise.getStreetNumber1().trim();
				//city = premise.getCity().trim();
				//stateOrProvince = premise.getState().trim();
				//postal = premise.getPostal().trim();
				
			}
			
			/*
             * Start Change - CCB016.Defect5 - 2021-06-07
             */
			//fullStreetAddress = premise.getAddress1().trim().toUpperCase();
			fullStreetAddress = StringUtils.left(premise.getAddress1().replace(',', ' ').trim().toUpperCase(), 40);
			/*
             * End Change - CCB016.Defect5 - 2021-06-07
             */
			streetNumber = premise.getStreetNumber1().trim();
			city = premise.getCity().trim();
			stateOrProvince = premise.getState().trim();
			postal = premise.getPostal().trim();
			// End Change - NMendo - 2021-03-09 - CCB016.Defect3
			
			// Start Change - IReyes - B-26006 - 2023-02-08
			//customerFieldsDelimitedByComma = customerFieldsDelimitedByComma.concat(fullname).concat(COMMA);
			if (suppressFileField.isTrue()){
				customerFieldsDelimitedByComma = customerFieldsDelimitedByComma.concat(BLANK).concat(COMMA);
			} else {
				customerFieldsDelimitedByComma = customerFieldsDelimitedByComma.concat(fullname).concat(COMMA);
			}
			// End Change - IReyes - B-26006 - 2023-02-08
			customerFieldsDelimitedByComma = customerFieldsDelimitedByComma.concat(fullStreetAddress).concat(COMMA);
			customerFieldsDelimitedByComma = customerFieldsDelimitedByComma.concat(accountNumber).concat(COMMA);
			customerFieldsDelimitedByComma = customerFieldsDelimitedByComma.concat(BLANK).concat(COMMA);
			customerFieldsDelimitedByComma = customerFieldsDelimitedByComma.concat(BLANK).concat(COMMA);
			customerFieldsDelimitedByComma = customerFieldsDelimitedByComma.concat(middleName).concat(COMMA);
			customerFieldsDelimitedByComma = customerFieldsDelimitedByComma.concat(streetNumber).concat(COMMA);
			customerFieldsDelimitedByComma = customerFieldsDelimitedByComma.concat(streetName).concat(COMMA);
			customerFieldsDelimitedByComma = customerFieldsDelimitedByComma.concat(suite).concat(COMMA);
			customerFieldsDelimitedByComma = customerFieldsDelimitedByComma.concat(city).concat(COMMA);
			customerFieldsDelimitedByComma = customerFieldsDelimitedByComma.concat(stateOrProvince).concat(COMMA);
			customerFieldsDelimitedByComma = customerFieldsDelimitedByComma.concat(postal);
		}
		
		private void prepareMeterRecordDetails(ServicePointMeterHistory_Id spMeterHistID
				,ServicePoint sp 
				, MeterConfiguration mcfg
				, Register register
				, Premise premise) {
			
			// Start Delete - NMendo - 2021-03-09 - CCB016.Defect3
			//String meterLoc = null;
			//if(notNull(sp.getMeterLocationId())) {
				//meterLoc = sp.getMeterLocationId().getTrimmedValue();
			//}
			// End Delete - NMendo - 2021-03-09 - CCB016.Defect3
			
			if(notNull(sp.getMeterReadCycleRouteSequence())) {
				meterUtilityMeterSequenceNumber = sp.getMeterReadCycleRouteSequence().toString().trim();
			}
			meterMeterNumber = mcfg.getMeter().getBadgeNumber().trim();
			//Get the meter configuration type for hte meter Type field, ommitting the first character
			// of the meter configuration type (e.g 001 should be 01)
			meterMeterType = mcfg.getMeterConfigurationType().getId().getTrimmedValue().substring(1);
			
			meterActiveIndicator = getMeterActiveIndicator(spMeterHistID);

			//Check Premise Town Code and Gride Code. 
			//If both exist retrieve AMR segment value from CM_AMR_SEG table.
			//If both do not exist, default to 1.
			String townCode = getPremiseChar(premise, townCodeCharType);
			String gridCode = cmRetrieveGeoValFromPrem(premise.getId() , gridCodeGeoType.getId()) ;
			if(!isBlankOrNull(townCode) && !isBlankOrNull(gridCode)) {
				meterMeterSegment = cmRetrieveItronAMRSegmentCode(townCode, gridCode);
			} else {
				meterMeterSegment = ONE;
			}
			
			//Get the meter seal number by appending the register sequence number and the UOM 
			meterSealNumber = register.getSeq().toString().trim().
					concat(register.getUnitOfMeasure().getId().getTrimmedValue());
			meterCustomDataFieldCustomData = mcfg.getId().getTrimmedValue();
			
			// Start Delete - NMendo - 2021-03-09 - CCB016.Defect3
			//Set the meterInstructionLocationCode as the Itron Location Code from the Service Task type
			/*if(!itronMeterLocationList.isEmpty() 
					&& (notNull(meterLoc)) ) {
				
				Iterator<COTSInstanceListNode> meterLocationIter = itronMeterLocationList.iterator();
				//Loop to find the ITRON value
				while(meterLocationIter.hasNext()) {            	
					
					COTSInstanceListNode meterLocationRow = meterLocationIter.next();  
					if (meterLocationRow.getString("mtrLocation").trim().equalsIgnoreCase(meterLoc)) {
						
						meterInstructionLocationCode = meterLocationRow.getString("itronLocation").trim();
						break;   
					}
				}
			}*/
			// End Delete - NMendo - 2021-03-09 - CCB016.Defect3
			
			if(!isBlankOrNull(sp.getMeterLocationDetails())) {
			    /*
                 * Start Change - CCB016.Defect5 - 2021-06-07
                 */
				//meterSpecialMessage = sp.getMeterLocationDetails().trim();
				meterSpecialMessage = StringUtils.left(sp.getMeterLocationDetails().replace(',',' ').replaceAll("\\r\\n|\\r|\\n", " ").trim(), 160);
				/*
                 * End Change - CCB016.Defect5 - 2021-06-07
                 */
			}
			
			if(!isBlankOrNull(meterSpecialMessage)) {
				meterSpecialMessageIndicator = ONE;
			} 
			else {
				meterSpecialMessageIndicator = DFLT_BLANK_SPECIAL_MESSAGE_INDICATOR;
			}
			
			meterFieldsDelimitedByComma = meterFieldsDelimitedByComma.concat(meterUtilityMeterSequenceNumber).concat(COMMA);
			meterFieldsDelimitedByComma = meterFieldsDelimitedByComma.concat(meterMeterNumber).concat(COMMA);
			meterFieldsDelimitedByComma = meterFieldsDelimitedByComma.concat(meterMeterCategory).concat(COMMA);
			meterFieldsDelimitedByComma = meterFieldsDelimitedByComma.concat(meterMeterType).concat(COMMA);
			meterFieldsDelimitedByComma = meterFieldsDelimitedByComma.concat(meterActiveIndicator).concat(COMMA);
			meterFieldsDelimitedByComma = meterFieldsDelimitedByComma.concat(meterMeterSegment).concat(COMMA);
			meterFieldsDelimitedByComma = meterFieldsDelimitedByComma.concat(meterSealNumber).concat(COMMA);
			meterFieldsDelimitedByComma = meterFieldsDelimitedByComma.concat(meterCustomDataFieldCustomData).concat(COMMA);
			// Start Delete - NMendo - 2021-03-09 - CCB016.Defect3
			//meterFieldsDelimitedByComma = meterFieldsDelimitedByComma.concat(meterInstructionLocationCode).concat(COMMA);
			// End Delete - NMendo - 2021-03-09 - CCB016.Defect3
			meterFieldsDelimitedByComma = meterFieldsDelimitedByComma.concat(meterSpecialMessage).concat(COMMA);
			meterFieldsDelimitedByComma = meterFieldsDelimitedByComma.concat(meterSpecialMessageIndicator);
		}
		
		private void prepareGPSDetails(Premise premise) {
			
			if (notNull(premise)) {
				String geoVal = cmRetrieveGeoValFromPrem(premise.getId(), latLongGeoType.getId());
				if (notBlank(geoVal)) {				
					String[] splitGeoVal = geoVal.split(" ", TWO_INTEGER);
					if (splitGeoVal.length == TWO_INTEGER) {
						// Retrieve the Latitude (the first component)
						latitude = splitGeoVal[0];				
						// Retrieve the Longitude (the second component)
						longitude = splitGeoVal[1];	
					}
				}
			}

			latLongFieldsDelimitedByComma = latitude.concat(COMMA).concat(longitude);
		}
		
		private void prepareMeterSessionInputDetails(ServicePoint sp 
				, Register register 
				, MeterConfiguration cfg 
				, MeterRead previousRead) {

			UnitOfMeasure uom = register.getUnitOfMeasure();
			String numberOfDigitsLeft = register.getNumberOfDigitsLeft().toString();
			// Start Add - NMendo - 2021-03-09 - CCB016.Defect3
			BigDecimal prevRegReadRounded = BigDecimal.ZERO;
			// End Add - NMendo - 2021-03-09 - CCB016.Defect3
			
			meterSessionInputNumberDials = register.getNumberOfDigitsLeft().toString().trim();
			meterSessionInputNumberDecimals = register.getNumberOfDigitsRight().toString().trim();
			meterSessionInputPreviousRead = ZERO;
			//If meter configuration has latest meter read , 
			if(notNull(previousRead)) {
				RegisterRead previousRegisterRead = retrieveRegisterReadOfLatestMeterRead(previousRead , register);
				if(notNull(previousRegisterRead)) {
					// Start Change - NMendo - 2021-03-03 - CCB016.Defect2
					//meterSessionInputPreviousRead = previousRegisterRead.getRegisterReading().toString().trim();
					prevRegReadRounded = previousRegisterRead.getRegisterReading().setScale(0, BigDecimal.ROUND_HALF_UP);
					meterSessionInputPreviousRead = prevRegReadRounded.toBigInteger().toString().trim();
					
					if(shouldDefaultHighLow.isTrue()) {
						//hiLimit = previousRegisterRead.getRegisterReading().add(DFLT_HI_LIMIT).toString().trim();
						// Start Change - NMendo - 2021-03-09 - CCB016.Defect3
						//hiLimit = prevRegReadRounded.add(DFLT_HI_LIMIT).toBigInteger().toString().trim();
						//loLimit = meterSessionInputPreviousRead;
						hiLimit = DFLT_HI_LIMIT;
						loLimit = DFLT_LO_LIMIT;
						// Start Change - NMendo - 2021-03-09 - CCB016.Defect3
					}
					// End Change - NMendo - 2021-03-03 - CCB016.Defect2
				}
				meterSessionInputPreviousReadDateTime = previousRead.getReadDateTime().toString(dateTimeFormat);
			} 

			meterSessionInputConstantMultiplier = register.getRegisterConstant().toString().trim();
			meterSessionInputConstantMultiplierValidationIndicator = ZERO;
			
			//Translate the read type code using the register details and the meter configuration type
			if(!itronReadTypeCodeList.isEmpty()) {
				
				Iterator<COTSInstanceListNode> readTypeIterator = itronReadTypeCodeList.iterator();
				//Loop to find the ITRON value
				while(readTypeIterator.hasNext()) {            	
					
					COTSInstanceListNode itronReadTypeNode = readTypeIterator.next();  
					if (itronReadTypeNode.getString("mrUOM").trim().equalsIgnoreCase(uom.getId().getTrimmedValue())
							&& itronReadTypeNode.getNumber("mrNbrDials").toString().trim().equalsIgnoreCase(numberOfDigitsLeft.trim())
							&& itronReadTypeNode.getString("mrConfigType").trim().equalsIgnoreCase(cfg.getMeterConfigurationType().
									getId().getTrimmedValue() )) {
						
						meterSessionInputReadTypeCode = itronReadTypeNode.getString("itronReadTypeCd").trim();
						break;   
					}
				}
			}
			//If Meter has ERT Equipment, set the read method to 4
			// else set it to zero
			if(notNull(itemID))  {
				meterSessionInputReadMethod = DFLT_METER_READ_METHOD_WITH_ERT;
			} else  {
				meterSessionInputReadMethod = ZERO;
			}
			
			meterSessionInputPromptCode = ZERO;
			meterSessionInputTextPrompt = GAS;
			meterSessionInputReadDirection = ZERO;
			meterSessionInputConsecutiveEstimates = ZERO;
			meterSessionInputTypeOfValidationIndicator = ZERO;
			
			//set the hi and lo limits
			if(shouldDefaultHighLow.isFalse()) {
				// Start Change - NMendo - 2021-03-09 - CCB016.Defect3
				//cmRetrieveHiLoLimits(sp , register);
				cmRetrieveHiLoLimits(sp , register, prevRegReadRounded);
				// End Change - NMendo - 2021-03-09 - CCB016.Defect3
			}
			
			meterSessionInputHi1 = hiLimit;
			meterSessionInputHi2 = meterSessionInputHi1;
			meterSessionInputLow1 = loLimit;
			meterSessionInputLow2 = meterSessionInputLow1;
			
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputNumberDials).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputNumberDecimals).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputPreviousRead).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputPreviousReadDateTime).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputConstantMultiplier).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputConstantMultiplierValidationIndicator).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputReadTypeCode).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputReadMethod).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputPromptCode).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputTextPrompt).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputReadDirection).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputConsecutiveEstimates).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputTypeOfValidationIndicator).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputHi1).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputHi2).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputLow1).concat(COMMA);
			meterSessionInputFieldDelimitedByComma = meterSessionInputFieldDelimitedByComma.concat(meterSessionInputLow2);
		}
		
		private void prepareMeterSessionInputRFDetails(Premise premise , Meter meter, MeterConfiguration cfg, MeterRead meterRead , Register register) {
			
			//Translate the read type code using the register details and the meter configuration type
			if(!itronEndpointTypeList.isEmpty() && !isBlankOrNull(wErtCharValue)) {
				Iterator<COTSInstanceListNode> endPointIterator = itronEndpointTypeList.iterator();
				//Loop to find the ITRON value
				while(endPointIterator.hasNext()) {            	
					
					COTSInstanceListNode itronReadTypeNode = endPointIterator.next();  
					if (itronReadTypeNode.getString("mrERTType").trim().equalsIgnoreCase(wErtCharValue.trim())) {
						
						meterSessionInputRFEndpointType = itronReadTypeNode.getString("itronEndpointType").trim();
						break;   
					}
				}
			}
			
			if(premise.getDivisionId().equals(MGE_CIS_DIVISION)) {
				meterSessionInputRFRFFrequency = DFLT_MGE_RF_FREQ;
			} else {
				meterSessionInputRFRFFrequency = ZERO;
			}
			
			if(notNull(itemID)) {
				meterSessionInputRFEndpointId = itemID.getEntity().getBadgeNumber().trim();
			}
			
			meterSessionInputRFWakeupTone = DEFAULT_WAKEUP_TONE;
			
			//Start Add - NMendo - CCB016.Defect4 - 2021-03-25
			if(notNull(meterRead)) {
			//End Add - NMendo - CCB016.Defect4 - 2021-03-25
				//Get the Tamper Code Values
				MeterReadCharacteristics meterReadChars = meterRead.getCharacteristics();
				
				for(MeterReadCharacteristic mrChar : meterReadChars) {
					if(mrChar.getId().getCharacteristicType().equals(tamper1CharType)) {
						if(tamper1CharType.getCharacteristicType().isPredefinedValue()) {
							meterSessionInputRFTamperCount1 = mrChar.getCharacteristicValue().trim();
							
						} else if (tamper1CharType.getCharacteristicType().isAdhocValue()
								|| tamper1CharType.getCharacteristicType().isFileLocationValue()) {
							meterSessionInputRFTamperCount1 = mrChar.getAdhocCharacteristicValue().trim();
							
						} else if (tamper1CharType.getCharacteristicType().isForeignKeyValue()) {
							meterSessionInputRFTamperCount1 = mrChar.getCharacteristicValueForeignKey1().trim();
						}
						
					} else if (mrChar.getId().getCharacteristicType().equals(tamper2CharType)) {
						
						if(tamper2CharType.getCharacteristicType().isPredefinedValue()) {
							meterSessionInputRFTamperCount2 = mrChar.getCharacteristicValue().trim();
							
						} else if (tamper2CharType.getCharacteristicType().isAdhocValue()
								|| tamper2CharType.getCharacteristicType().isFileLocationValue()) {
							meterSessionInputRFTamperCount2 = mrChar.getAdhocCharacteristicValue().trim();
							
						} else if (tamper2CharType.getCharacteristicType().isForeignKeyValue()) {
							meterSessionInputRFTamperCount2 = mrChar.getCharacteristicValueForeignKey1().trim();
							
						}
					}
				}
			}
			
			meterSessionInputFieldRFDelimitedByComma = meterSessionInputFieldRFDelimitedByComma.concat(meterSessionInputRFEndpointType).concat(COMMA);
			meterSessionInputFieldRFDelimitedByComma = meterSessionInputFieldRFDelimitedByComma.concat(meterSessionInputRFRFFrequency).concat(COMMA);
			meterSessionInputFieldRFDelimitedByComma = meterSessionInputFieldRFDelimitedByComma.concat(meterSessionInputRFEndpointId).concat(COMMA);
			meterSessionInputFieldRFDelimitedByComma = meterSessionInputFieldRFDelimitedByComma.concat(meterSessionInputRFWakeupTone).concat(COMMA);
			meterSessionInputFieldRFDelimitedByComma = meterSessionInputFieldRFDelimitedByComma.concat(meterSessionInputRFTamperCount1).concat(COMMA);
			meterSessionInputFieldRFDelimitedByComma = meterSessionInputFieldRFDelimitedByComma.concat(meterSessionInputRFTamperCount2);
		}
		
		/**
		 * Get active customer linked to SP
		 * @param spID
		 * @return account linked to SP
		 */
		private Account_Id getActiveCustomer(ServicePoint_Id spID) {
			Account_Id acctId;
			StringBuilder sql = new StringBuilder();	
			
			sql.append("SELECT ");
			sql.append(   "SA.ACCT_ID ");
			sql.append("FROM ");
			sql.append(   "CI_SA_SP SASP, CI_SA SA ");
			sql.append("WHERE ");
			sql.append(   "SASP.SP_ID = :spID ");
			sql.append("AND ");
			sql.append(   "SA.SA_ID = SASP.SA_ID ");
			sql.append("AND ");
			sql.append(   "SA.SA_STATUS_FLG IN (:pendingStop, :active, :pendingStart, :reactivated) ");
			sql.append("AND ");
			sql.append(   "SA.START_DT <= :procDate ");
			sql.append("ORDER BY SA.START_DT DESC ");
			
			PreparedStatement prepState = createPreparedStatement(sql.toString(), getClass().getName());
			prepState.bindId("spID", spID);
			prepState.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
			prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
			prepState.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
			prepState.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
			prepState.bindDate("procDate", this.getProcessDateTime().getDate());
			SQLResultRow result = prepState.firstRow();
			prepState.close();
			
			if (notNull(result)) {
				acctId = (Account_Id) result.getId("ACCT_ID", Account.class);
			}
			else {
				acctId = null;
			}
			
			return acctId;
		}

		/**
		 * Get the most recent SP Meter Event and check the on/off flag. Returns 
		 * 0 if meter is on, 1 if the meter is not
		 * @param spMeterHistID
		 * @return
		 */
		private String getMeterActiveIndicator(ServicePointMeterHistory_Id spMeterHistID) {
			String activeIndicator = BLANK;
			StringBuilder sql = new StringBuilder();
			
			sql.append("SELECT ");
			sql.append(    "MTR.MTR_ON_OFF_FLG ");
			sql.append("FROM ");
			sql.append(   "CI_SP_MTR_EVT MTR ");
			sql.append("WHERE ");
			sql.append(   "MTR.SP_MTR_HIST_ID = :spMeterHist ");
			sql.append("AND ");
			sql.append(   "MTR.SEQNO = ( ");
			sql.append(      "SELECT ");
			sql.append(         "MAX(MTR2.SEQNO) ");
			sql.append(      "FROM ");
			sql.append(         "CI_SP_MTR_EVT MTR2 ");
			sql.append(      "WHERE ");
			sql.append(         "MTR2.SP_MTR_HIST_ID = MTR.SP_MTR_HIST_ID ");
			sql.append(   ") ");
			
			PreparedStatement stmt = createPreparedStatement(sql.toString(), getClass().getName());
			stmt.bindId("spMeterHist", spMeterHistID);
			
			SQLResultRow result = stmt.firstRow();
			stmt.close();
			
			if(notNull(result)) {
				MeterOnOffStatusLookup onOffFlag = result.getLookup("MTR_ON_OFF_FLG" , MeterOnOffStatusLookup.class);
				
				//If Meter is On set to 0
				//else If Meter is Off set to 1
				if(onOffFlag.isOn()) {
					activeIndicator = ZERO;
				} else {
					activeIndicator = ONE;
				}
			}
			
			return activeIndicator;
		}
		
		/**
		 * Custom method which retrieves the Meter's Register 
		 * It is assumed that each meter would only have one register
		 * @param meter 
		 */
		private List<SQLResultRow> cmRetrieveRegisters(Meter meter) {
			List<SQLResultRow> registers = null;
			
			if (notNull(meter)) {
				// Assumption is that each meter will only have one register
				StringBuilder sql = new StringBuilder();
                sql.append("SELECT ");
                sql.append(   "REG.REG_ID ");
                sql.append("FROM ");
                sql.append(   "CI_REG REG ");
                sql.append("WHERE ");
                sql.append(   "REG.MTR_ID = :meterID ");
                sql.append("AND ");
                /*
                 * Start Change - CCB016.Defect5 - 2021-06-07
                 */
                //sql.append(   "REG.EFF_DTTM <= :effDttm ");
                //sql.append("ORDER BY REG.EFF_DTTM DESC ");
                sql.append(    "REG.EFF_DTTM = (");
                sql.append(       "SELECT ");
                sql.append(           "MAX(REG1.EFF_DTTM) ");
                sql.append(       "FROM ");
                sql.append(           "CI_REG REG1 ");
                sql.append(       "WHERE ");
                sql.append(           "REG1.MTR_ID = REG.MTR_ID ");
                sql.append(       "AND ");
                sql.append(           "REG1.EFF_DTTM <= :effDttm ) ");
                /*
                 * End Change - CCB016.Defect5 - 2021-06-07
                 */

				PreparedStatement prepState = createPreparedStatement(sql.toString(), getClass().getName());
				prepState.bindId("meterID", meter.getId());
				prepState.bindDateTime("effDttm", this.getProcessDateTime());
				
				registers = prepState.list();
				prepState.close();
				
				if(isNull(registers)) {
					// Failed to retrieve registers of meter (%1)
					logError(CustomMessageRepositorySpireOne.CCB016_1_noRegisterRetrievedForMeter(spMeterHistID.getTrimmedValue() , 
							meter.getId().getTrimmedValue()));
					registers = null;
				}			
			}			
			return registers;
		}

		/**
		 * Custom method which retrieves the Hi Limit and Lo Limit by calling the HighLowCalculationAlgorithm
		 * @param sp the service point
		 * @param reg the register
		 */
		// Start Change - NMendo - 2021-03-09 - CCB016.Defect3
		//private void cmRetrieveHiLoLimits(ServicePoint sp, Register reg) {
		private void cmRetrieveHiLoLimits(ServicePoint sp, Register reg, BigDecimal previousRead) {
		// End Change - NMendo - 2021-03-09 - CCB016.Defect3
			try {
				//Start Change JVitug - CCB016.Defect 1 -2021-02-09 
				//DateTime wScheduleDateWithTime = new DateTime(wScheduleSelectionDate.getYear(), wScheduleSelectionDate.getMonth(), wScheduleSelectionDate.getDay());
				DateTime wScheduleDateWithTime = new DateTime(wScheduledReadDate.getYear(), wScheduledReadDate.getMonth(), wScheduledReadDate.getDay());
				//End Change JVitug - CCB016.Defect 1 - 2021-02-09
				
				HighLowCalculationAlgorithmData hiLoData = HighLowCalculationAlgorithmData.Factory.newInstance();
				hiLoData.setReadDateTime(wScheduleDateWithTime);	
				hiLoData.setReadType(ReadTypeLookup.constants.REGULAR);
				hiLoData.setEstimateType(EstimateTypeLookup.constants.HIGH_LOW_ONLY);
				hiLoData.setServicePoint(sp);				
				HighLowCalculationAlgorithmData output = reg.callHighLowCalculationAlgorithms(hiLoData);
				// Start Change - NMendo - 2021-03-09 - CCB016.Defect3
				//hiLimit = String.valueOf(output.getHighLimit().intValueExact());
				//loLimit = String.valueOf(output.getLowLimit().intValueExact());
				BigDecimal hiConsumption = output.getHighLimit().subtract(previousRead);
				if (hiConsumption.compareTo(BigDecimal.ZERO) <= 0) {
					hiLimit = ZERO;
				} else {
					hiLimit = String.valueOf(hiConsumption.intValueExact());
				}
				
				BigDecimal loConsumption = output.getLowLimit().subtract(previousRead);
				if (loConsumption.compareTo(BigDecimal.ZERO) <= 0) {
					loLimit = ZERO;
				} else {
					loLimit = String.valueOf(loConsumption.intValueExact());
				}
				// End Change - NMendo - 2021-03-09 - CCB016.Defect3
				
			}
			catch (Exception e) {
				hiLimit = ZERO;
				loLimit = ZERO;
				logError(CustomMessageRepositorySpireOne.CCB016_1_errorEncounteredRetrievingHiLo(spMeterHistID.getTrimmedValue() , 
						reg.getId().getTrimmedValue(), sp.getId().getTrimmedValue()));
			}			
		}

		/**
		 * Custom method which retrieves the latest meter read.
		 * @param mtrConfigID 
		 * @return mrId Entity
		 */
		private MeterRead cmRetrieveLatestMeterRead(MeterConfiguration_Id mtrConfigID) {
			
			MeterRead returnValue = null;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT MR.MR_ID ");
			stringBuilder.append("FROM CI_MR MR ");
			stringBuilder.append("WHERE MR.MTR_CONFIG_ID = :mtrConfigId ");
			stringBuilder.append("AND MR.READ_DTTM <= :procDttm ");
			stringBuilder.append("AND USE_ON_BILL_SW = :useOnBill ");			
			stringBuilder.append("ORDER BY MR.READ_DTTM DESC ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			prepState.bindId("mtrConfigId", mtrConfigID);
			prepState.bindDateTime("procDttm", this.getProcessDateTime());
			prepState.bindBoolean("useOnBill", Bool.TRUE);
			SQLResultRow sqlRow = prepState.firstRow();
			prepState.close();
			
			if (notNull(sqlRow)) {
				MeterRead_Id mrId = (MeterRead_Id)sqlRow.getId("MR_ID", MeterRead.class) ;
				returnValue = mrId.getEntity();
			}
			else {		
				logError(CustomMessageRepositorySpireOne.CCB016_1_noMeterReadRetrieved(spMeterHistID.getTrimmedValue() , 
						mtrConfigID.getTrimmedValue()));

			}	
			
			return returnValue;
		}		
		
		/**
		 * Custom method which retrieves the Longitude/Latiude Geographic value from the premise
		 * @param premID the premise
		 * @param geoTypeID the geo type
		 * @return the Geo Value
		 */
		private String cmRetrieveGeoValFromPrem(Premise_Id premID, GeographicType_Id geoTypeID) {
			
			String returnValue = "";
			StringBuilder sql = new StringBuilder();			
			sql.append("SELECT ");
			sql.append(   "GEO_VAL ");
			sql.append("FROM ");
			sql.append(   "CI_PREM_GEO ");
			sql.append("WHERE ");
			sql.append(   "PREM_ID = :premId ");
			sql.append("AND ");
			sql.append(   "GEO_TYPE_CD = :geoTypeCd ");
			PreparedStatement prepState = createPreparedStatement(sql.toString(), getClass().getName());
			prepState.bindId("premId", premID);
			prepState.bindId("geoTypeCd", geoTypeID);
			
			SQLResultRow result = prepState.firstRow();
			prepState.close();
			
			if (notNull(result)) {
				returnValue = result.getString("GEO_VAL").trim();
			}
			
			return returnValue;
		}
		
		private RegisterRead retrieveRegisterReadOfLatestMeterRead(MeterRead latestMeterRead , Register register) {
			RegisterRead registerRead = null;
			StringBuilder sql = new StringBuilder();
			
			sql.append("SELECT ");
			sql.append(   "READ.REG_READ_ID ");
			sql.append("FROM ");
			sql.append(   "CI_REG_READ READ ");
			sql.append("WHERE ");
			sql.append(   "READ.MR_ID = :meterRead ");
			sql.append("AND ");
			sql.append(   "READ.REG_ID = :register ");
			
			PreparedStatement stmt = createPreparedStatement(sql.toString() , getClass().getName());
			stmt.bindId("meterRead", latestMeterRead.getId());
			stmt.bindId("register", register.getId());
			
			SQLResultRow result = stmt.firstRow();
			stmt.close();
			
			if(notNull(result)) {
				registerRead = result.getEntity("REG_READ_ID" , RegisterRead.class);
			}
			
			return registerRead;			
		}
		
		//Start Add JVitug - CCB016.Defect 1 - 2020-02-08
		/**
		 * Retrieve the Scheduled Read Date
		 * using the Meter Read Cycle and the 
		 * Scheduled Selection Date
		 * @param cycId
		 * @param scheduledSelectionDate
		 * @return scheduled read date
		 */
		private Date getScheduledReadDate(MeterReadCycle_Id cycId , Date scheduledSelectionDate) {
			Date returnValue = null;
			StringBuilder stringSql = new StringBuilder();
			
			stringSql.append("SELECT ");
			stringSql.append(   "MRS.SCHED_READ_DT ");
			stringSql.append("FROM ");
			stringSql.append(   "CI_MR_SCHED MRS ");
			stringSql.append("WHERE ");
			stringSql.append(   "MRS.MR_CYC_CD = :meterReadCycle ");
			stringSql.append("AND ");
			stringSql.append(   "MRS.SCHED_SEL_DT = :scheduleSelectionDate ");
			
			PreparedStatement sql = createPreparedStatement(stringSql.toString() , getClass().getName());
			sql.bindId("meterReadCycle" , cycId);
			sql.bindDate("scheduleSelectionDate" , scheduledSelectionDate);
			
			SQLResultRow result = sql.firstRow();
			sql.close();
			
			if(notNull(result)) {
				returnValue = result.getDate("SCHED_READ_DT");
			}
			
			return returnValue;
		}
		//End Add JVitug - CCB016.Defect 1 - 2020-02-08
		
		/**
		 * Custom method which determines if the equipment is an ERT 
		 * @param meter 
		 */
		private void cmCheckMeterForErtEquipment(Meter meter, MeterConfiguration cfg , Register register) {
			
			//Start Add - NMendo - CCB016.Defect4 - 2021-03-25
			String meterConfigType = cfg.getMeterConfigurationType().getId().getTrimmedValue();
			BigInteger regSeq = register.getSeq();
			SQLResultRow result = null;
			
			// If dual register meter configuration type
			if(meterConfigType.equals(METER_CONFIGURATION_TYPE_001) || meterConfigType.equals(METER_CONFIGURATION_TYPE_004)) {
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.append("SELECT EQP.MTR_ID, ITM.ITEM_ID ");
				stringBuilder.append("FROM CI_MTR_EQ EQP, CI_ITEM ITM, CI_MTR MTR, CI_ITEM_CHAR ITMCHAR ");
				stringBuilder.append("WHERE (EQP.REMOVAL_DT IS  NULL ");			
				stringBuilder.append(		 "OR EQP.REMOVAL_DT > :procDttm) ");			
				stringBuilder.append("AND EQP.ITEM_ID_EQ = ITM.ITEM_ID ");
				stringBuilder.append("AND ITM.ITEM_TYPE_CD IN (" + ertItemTypeListStr + ") ");
				stringBuilder.append("AND ITM.ITEM_STATUS_FLG = :itemStatus ");			
				stringBuilder.append("AND EQP.MTR_ID = MTR.MTR_ID ");		
				stringBuilder.append("AND (MTR.RETIRE_DT IS NULL ");
				stringBuilder.append(	   "OR MTR.RETIRE_DT > :procDttm) ");			
				stringBuilder.append("AND MTR.MTR_ID = :meterID ");
				stringBuilder.append("AND ITM.ITEM_ID = ITMCHAR.ITEM_ID ");
				//Start Change - NMendo - CCB016.Defect4 - 2021-03-25
				//stringBuilder.append("AND ITMCHAR.CHAR_TYPE_CD = :parmUOMCharType ");
				//stringBuilder.append("AND ITMCHAR.CHAR_VAL = :registerUOM ");
				stringBuilder.append("AND ITMCHAR.CHAR_TYPE_CD = :maximoReadTypeCharType ");
				stringBuilder.append("AND ITMCHAR.CHAR_VAL = :readType ");
				stringBuilder.append("ORDER BY EQP.INSTALL_DT DESC ");
				//End Change - NMendo - CCB016.Defect4 - 2021-03-25
				
				PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
				prepState.bindLookup("itemStatus", ItemStatusLookup.constants.ACTIVE);
				prepState.bindId("meterID", meter.getId());
				prepState.bindDate("procDttm", this.getProcessDateTime().getDate());
				//Start Change - NMendo - CCB016.Defect4 - 2021-03-25
				//prepState.bindId("parmUOMCharType", uomItemCharType.getId());
				//prepState.bindString("registerUOM", register.getUnitOfMeasure().getId().getTrimmedValue(), "CHAR_VAL");
				prepState.bindId("maximoReadTypeCharType", maximoReadTypeCharType.getId());
				if (regSeq.compareTo(BigInteger.ONE) == 0) {
					prepState.bindStringProperty("readType", CharacteristicValue.properties.characteristicValue, MAXIMO_READ_TYPE_CORRECTED);
				} else {
					prepState.bindStringProperty("readType", CharacteristicValue.properties.characteristicValue, MAXIMO_READ_TYPE_UNCORRECTED);
				}
				//End Change - NMendo - CCB016.Defect4 - 2021-03-25

				result = prepState.firstRow();
				prepState.close();	
				
				
				
			} else {
				// Retrieve the latest installed ERT badge number.
				//Start Delete - NMendo - CCB016.Defect4 - 2021-03-25
				//if(!cfg.getMeterConfigurationType().getId().getTrimmedValue().equalsIgnoreCase(METER_CONFIGURATION_TYPE_001)) {
				//End Delete - NMendo - CCB016.Defect4 - 2021-03-25
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder = new StringBuilder();
				stringBuilder.append("SELECT EQP.MTR_ID, ITM.ITEM_ID ");
				stringBuilder.append("FROM CI_MTR_EQ EQP, CI_ITEM ITM, CI_MTR MTR ");
				stringBuilder.append("WHERE (EQP.REMOVAL_DT IS  NULL ");			
				stringBuilder.append(		 "OR EQP.REMOVAL_DT > :procDttm) ");			
				stringBuilder.append("AND EQP.ITEM_ID_EQ = ITM.ITEM_ID ");
				stringBuilder.append("AND ITM.ITEM_TYPE_CD IN (" + ertItemTypeListStr + ") ");
				stringBuilder.append("AND ITM.ITEM_STATUS_FLG = :itemStatus ");			
				stringBuilder.append("AND EQP.MTR_ID = MTR.MTR_ID ");		
				stringBuilder.append("AND (MTR.RETIRE_DT IS NULL ");
				stringBuilder.append(	   "OR MTR.RETIRE_DT > :procDttm) ");			
				stringBuilder.append("AND MTR.MTR_ID = :meterID ");
				//Start Add - NMendo - CCB016.Defect4 - 2021-03-24
				stringBuilder.append("ORDER BY EQP.INSTALL_DT DESC ");
				//End Add - NMendo - CCB016.Defect4 - 2021-03-24
				
				PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
				prepState.bindLookup("itemStatus", ItemStatusLookup.constants.ACTIVE);
				prepState.bindId("meterID", meter.getId());
				prepState.bindDate("procDttm", this.getProcessDateTime().getDate());

				result = prepState.firstRow();
				prepState.close();	
			}
			
			if (notNull(result)) {
				itemID = (Item_Id) result.getId("ITEM_ID", Item.class);
				ItemCharacteristic itemChar = itemID.getEntity().getEffectiveCharacteristic(ertCharType);
				if(notNull(itemChar)) {
					if(ertCharType.getCharacteristicType().isAdhocValue()) {
						wErtCharValue = itemChar.getAdhocCharacteristicValue().trim();
					} 
					else if(ertCharType.getCharacteristicType().isPredefinedValue()) {
						wErtCharValue = itemChar.getCharacteristicValue().trim();
					} 
					else if(ertCharType.getCharacteristicType().isForeignKeyValue()) {
						wErtCharValue = itemChar.getCharacteristicValueForeignKey1().trim();
					}
				}
			}
		}	
		
		/**
		 * Custom method which process Meter Read Download record and forming different record type and write to flat file
		 * @param mrSchedRte the Meter Read Schedule Route
		 * @param mrSched the Meter Read Schedule
		 */
		private void writeToFile() {
			String record = workSetFieldsDelimitedByComma.concat(COMMA) 
				.concat(customerFieldsDelimitedByComma).concat(COMMA)
				.concat(meterFieldsDelimitedByComma).concat(COMMA)
				.concat(latLongFieldsDelimitedByComma).concat(COMMA)
				.concat(meterSessionInputFieldDelimitedByComma).concat(COMMA)
				.concat(meterSessionInputFieldRFDelimitedByComma);
			cmWriteToFile(record);
		}
		
		/**
		 * Base method which is called at the end after processing all records for each thread. This is called only once per thread
		 */
		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
			cmCloseFile();
		}
		
		// Start Add - NMendo - CCB016.Defect7 - 2021-07-19
		/**
		 * Process Customer Read Meter. 
		 * Create a Customer Contact for the Main Customer/Account/Premise.
		 * @param spId
		 * @param meter
		 * @param mrRouteCode
		 */
		private void processCustomerReadMeter(ServicePoint_Id spId, Meter meter, String mrRouteCode) {
			// If the Batch Parameter Customer Read SA Char Type is populated and SP's Meter is a
			// Customer Read Meter.
			if(notNull(parmCustomerReadSaCharType) && isCustomerReadMeter(spId).isTrue()) {
				Account_Id accountId = getActiveCustomer(spId);
				if(isNull(accountId)) {
					return;
				}
				
				ServicePoint sp = spId.getEntity();
				Premise premise = sp.getPremise();
				WorkCalendar workCalendar = premise.fetchDivision().getWorkCalendar();
				String badgeNumber = meter.getBadgeNumber();
				String serviceRoute = sp.getMeterReadRoute();
				String dueDateStr = retrieveDueDate(mrRouteCode, workCalendar);
				
				// Create Customer Contact
				CustomerContact_DTO customerContactDto = createDTO(CustomerContact.class);
	            customerContactDto.setPersonId(accountId.getEntity().getMainPerson().getId());
	            customerContactDto.setAccountId(accountId);
	            customerContactDto.setPremiseId(premise.getId());
	            customerContactDto.setCustomerContactTypeId(customerReadCcTypeId);
	            customerContactDto.setContactDateTime(getProcessDateTime());
	            customerContactDto.setUserId(getActiveContextUser().getId());
	            CustomerContact custContact = customerContactDto.newEntity();
	            
	            // Create Customer Contact Characteristics
	            CustomerContactCharacteristics ccChars =  custContact.getCharacteristics();
	            createCustomerContactChar(ccChars, badgeNumberCharType, badgeNumber);
	            createCustomerContactChar(ccChars, serviceRouteCharType, serviceRoute);
	            createCustomerContactChar(ccChars, dueDateCharType, dueDateStr);
	            // Start Add - NMendo - CCB016.Defect8 - 2021-08-07
	            createCustomerContactChar(ccChars, premiseCharType, premise.getId().getTrimmedValue());
	            // End Add - NMendo - CCB016.Defect8 - 2021-08-07
			}
		}
		
		/**
		 * Retrieve due date (Bill Cycle Window End Date, minus 1 business day).
		 * @param mrRouteCode
		 * @param workCalendar
		 * @return String
		 */
		private String retrieveDueDate(String mrRouteCode, WorkCalendar workCalendar) {
			String dueDateStr = null;
			
			// Retrieve Bill Cycle Window End Date
			StringBuilder sb = new StringBuilder();
			sb.append("SELECT BC.WIN_END_DT ");
			sb.append("FROM CI_MR_STAGE_DWN STG, ");
			sb.append(     "CI_MR_SCHED MRS, ");
			sb.append(     "CI_MR_CYC MC, ");
			sb.append(     "CI_BILL_CYC_SCH BC ");
			sb.append("WHERE STG.MR_RTE_CD = :mrRouteCode ");
			sb.append("AND STG.SCHED_SEL_DT = :scheduleSelectionDate ");
			sb.append("AND STG.SP_MTR_HIST_ID = :spMeterHistID ");
			sb.append("AND MRS.MR_CYC_CD = STG.MR_CYC_CD ");
			sb.append("AND MRS.SCHED_SEL_DT = STG.SCHED_SEL_DT ");
			sb.append("AND MRS.MR_CYC_CD = MC.MR_CYC_CD ");
			sb.append("AND MC.BILL_CYC_CD = BC.BILL_CYC_CD ");
			sb.append("AND BC.WIN_START_DT = MRS.SCHED_READ_DT ");
			
			PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
			ps.bindId("spMeterHistID", spMeterHistID);
			ps.bindStringProperty("mrRouteCode", ServicePoint.properties.meterReadRoute, mrRouteCode);
			ps.bindDate("scheduleSelectionDate", wScheduleSelectionDate);

			SQLResultRow result = ps.firstRow();
			ps.close();
			
			if(notNull(result)) {
				Date dueDate = result.getDate("WIN_END_DT");
				
				// Subtract 1 business day to Window End Date
				dueDate = workCalendar.addBusinessDays(dueDate, -1);
				dueDateStr = dueDate.toString(dateFormat).trim();
			}

			return dueDateStr;
		}
		
		/**
		 * Create Customer Contact Characteristic.
		 * @param ccChars
		 * @param charType
		 * @param charVal
		 */
		private void createCustomerContactChar(CustomerContactCharacteristics ccChars, CharacteristicType charType, String charVal) {
			if(isNull(charVal) || isBlankOrNull(charVal.trim())) {
				return;
			}

			CustomerContactCharacteristic_DTO ccCharDto = ccChars.newChildDTO();
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
            if (charTypeLookup.isPredefinedValue()){
            	ccCharDto.setCharacteristicValue(charVal.trim());
            } else if (charTypeLookup.isForeignKeyValue()){
            	ccCharDto.setCharacteristicValueForeignKey1(charVal.trim());
            } else {
            	ccCharDto.setAdhocCharacteristicValue(charVal.trim());
            }
            
            ccChars.add(ccCharDto, charType.getId());
		}
		
		/**
		 * This method check if Meter/SP has an SA/SP record with null Stop Date/Stop Date in future, 
		 * and the Service Agreement has an effective Characteristic with Char Type equal to Parameter 
		 * Customer Read SA Char Type and Char Value equal to Parameter Customer Read SA Char Val.
		 * @param spId
		 * @return Bool
		 */
		private Bool isCustomerReadMeter(ServicePoint_Id spId) {
			Bool isCustomerReadMeter = Bool.FALSE;
			
			// Retrieve SP's SA
			StringBuilder sb = new StringBuilder();
			sb.append("SELECT SASP.SA_ID ");
			sb.append("FROM CI_SA_SP SASP ");
			sb.append("WHERE SASP.SP_ID = :spId ");
			sb.append("AND SASP.START_DTTM <= :processDate ");
			sb.append("AND (SASP.STOP_DTTM IS NULL ");
			sb.append(     "OR SASP.STOP_DTTM >= :processDate) ");
			
			PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
			ps.bindId("spId", spId);
			ps.bindDateTime("processDate", getProcessDateTime());
			
			SQLResultRow result = ps.firstRow();
			ps.close();
			
			if(notNull(result)) {
				ServiceAgreement sa = result.getEntity("SA_ID", ServiceAgreement.class);
				
				// Retrieve the effective Customer Read SA Char and compare the value with Parameter Customer Read SA Char Val.
				ServiceAgreementCharacteristic customerReadSaChar = sa.getEffectiveCharacteristic(parmCustomerReadSaCharType);
				if(notNull(customerReadSaChar)) {
					String customerReadSaCharVal = null;
					if(customerReadSaCharTypeLookup.isPredefinedValue()) {
						customerReadSaCharVal = customerReadSaChar.getCharacteristicValue();
					} else if(customerReadSaCharTypeLookup.isForeignKeyValue()) {
						customerReadSaCharVal = customerReadSaChar.getCharacteristicValueForeignKey1();
					} else {
						customerReadSaCharVal = customerReadSaChar.getAdhocCharacteristicValue();
					}
					
					if(parmCustomerReadSaCharVal.equals(customerReadSaCharVal.trim())) {
						isCustomerReadMeter = Bool.TRUE;
					}
				}
			}
			
			return isCustomerReadMeter;
		}
		// End Add - NMendo - CCB016.Defect7 - 2021-07-19
	}
}
