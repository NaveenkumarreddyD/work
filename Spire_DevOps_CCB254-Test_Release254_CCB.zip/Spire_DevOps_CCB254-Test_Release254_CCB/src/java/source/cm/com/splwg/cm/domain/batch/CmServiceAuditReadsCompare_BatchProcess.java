/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Service Reads (Audit Reads) 
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-05-17   Srikanth          NM0074. Initial Version.
 * 2013-06-05   Srikanth          Common Business Component Web Service Call
 * 2013-17-06   Srikanth          Cleared Log statements 
 * 2013-09-23   Neha/Srikanth	  IM-037780 Remove reference to FA Upload staging
 * 2013-10-17   Mohit          	  IM-037780 change in creation of Meter read char logic
 * 2016-01-29  	MPang			  Updated for CCB v2.4 compilation.
 * 2016-06-09   SFelip            Defect 3443676. Retrieve the batch parameters inside the
 *                                Batch Worker class.
 * 2024-11-04   EQuint            B-35560. Exclude creation of to do for specific CIS divisions. 
 * 2025-03-20   EQuint		      B-37805. Missed skipped to do creation                              
 ******************************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.changehandling.StringProperty;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_Id;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole;
import com.splwg.base.domain.todo.toDoType.ToDoTypeSortKeyTypes;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.FieldActivityStepTypeActionLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.meterReadSource.MeterReadSource_Id;
import com.splwg.ccb.domain.admin.timeOfUse.TimeOfUse;
import com.splwg.ccb.domain.admin.timeOfUse.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePointCharacteristic;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_Id;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.MeterReadCharacteristic_DTO;
import com.splwg.ccb.domain.meterread.meterRead.MeterReadCharacteristic_Id;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead_Id;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoMaintenanceData;
import com.splwg.ccb.domain.todo.toDoType.ToDoType;*/
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.meterReadSource.entity.MeterReadSource_Id;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterReadCharacteristic_DTO;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterReadCharacteristic_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_Id;
import com.splwg.ccb.domain.todo.common.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.data.ToDoMaintenanceData;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.api.lookup.CmServiceReadsAuditLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.common.CmWSDLCallToAMRDataBase;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.StringUtilities;

/**
*
@BatchJob (modules = {}
*      ,multiThreaded = true, rerunnable = false,
*      softParameters = {@BatchJobSoftParameter (entityName = toDoType, name = SRVC_AUD_TD_TYPE_CD, required = true, type = entity)
*            , @BatchJobSoftParameter (entityName = role, name = SRVC_AUD_ROLE_ID, required = false, type = entity)
*            , @BatchJobSoftParameter (name = VARIANCE_THRESHOLD, required = true, type = integer)
*            , @BatchJobSoftParameter (entityName = unitOfMeasure, name = UOM_CD1, required = true, type = entity)
*            , @BatchJobSoftParameter (entityName = unitOfMeasure, name = UOM_CD2, required = false, type = entity)
*            , @BatchJobSoftParameter (entityName = timeOfUse, name = TOU_CD1, required = false, type = entity)
*            , @BatchJobSoftParameter (entityName = timeOfUse, name = TOU_CD2, required = false, type = entity)
*            , @BatchJobSoftParameter (entityName = featureConfiguration, name = SRVC_AUDT_FEATURE_CONFIG_NAME, required = true, type = entity)
*            , @BatchJobSoftParameter (name = MET_SIZE_FC_OPT_TYP, required = true, type = string)
*            , @BatchJobSoftParameter (name = MET_READ_SRC_FC_OPT_TYP, required = true, type = string)
*            , @BatchJobSoftParameter (name = FA_TYPE_FC_OPT_TYP, required = true, type = string)
*            , @BatchJobSoftParameter (entityName = characteristicType, name = SP_POW_STAT_CHAR_TYP, required = true, type = entity)
*            , @BatchJobSoftParameter (name = SP_POW_STAT_CHAR_VAL, required = true, type = string)
*            , @BatchJobSoftParameter (entityName = characteristicType, name = SERVICE_AUDIT_MR_CHAR_TYP, required = true, type = entity)
*            , @BatchJobSoftParameter (name = SERVICE_AUDIT_MR_CHAR_VAL, required = true, type = string)
*            , @BatchJobSoftParameter (entityName = characteristicType, name = METER_SIZE_CHAR_TYP, required = true, type = entity)
*            , @BatchJobSoftParameter (entityName = characteristicType, name = AMR_READ_TODO_CHAR_TYP, required = true, type = entity)
*            , @BatchJobSoftParameter (entityName = characteristicType, name = DAILY_READ_TODO_CHAR_TYP, required = true, type = entity)
*            , @BatchJobSoftParameter (name = X_DAYS_BEFORE_DUE_DATE, required = true, type = integer)
*            , @BatchJobSoftParameter (name = EXCLUDE_CIS_DIV_TD, required = false, type = string)
*            }
*            )
*/
public class CmServiceAuditReadsCompare_BatchProcess extends
		CmServiceAuditReadsCompare_BatchProcess_Gen {
	
	//Soft Params
    // Start Change - 2016-06-09 - SFelipe - Defect 3443676
    //private static ToDoType paramToDoType;
    //private static Role paramToDoRole;
    //private static BigInteger paramVarianceThreshold;
    //private static UnitOfMeasure paramCorrectedUOM;
    //private static UnitOfMeasure paramUnCorrectedUOM;
    
    private ToDoType paramToDoType;
    private Role paramToDoRole;
    private BigInteger paramVarianceThreshold;
    private UnitOfMeasure paramCorrectedUOM;
    private UnitOfMeasure paramUnCorrectedUOM;
    // End Change - 2016-06-09 - SFelipe - Defect 3443676
    private  TimeOfUse paramTOU1;
    private  TimeOfUse paramTOU2;
    private  FeatureConfiguration paramFeatConfig;
    private  CharacteristicType paramMtrSizeCharType;
    private  String paramMtrSizeOptType; 
    private  String paramMtrReadSrcOptType; 
    private  String paramFATypeOptType; 
    private BigInteger paramDaysBeforeDueDate;
    private  CharacteristicType paramSPPowStatCharType;
    private  String paramSPPowStatCharVal; 
    // Start Change - 2016-06-09 - SFelipe - Defect 3443676
    //private static CharacteristicType paramServiceAuditMRCharType;
    //private static CharacteristicType paramDailyReadIdToDoCharType;
    //private static CharacteristicType paramAMRIdToDoCharType;
    //private static String strServiceCharVal;
    
    private CharacteristicType paramServiceAuditMRCharType;
    private CharacteristicType paramDailyReadIdToDoCharType;
    private CharacteristicType paramAMRIdToDoCharType;
    private String strServiceCharVal;
    // End Change - 2016-06-09 - SFelipe - Defect 3443676
    
    // start add - equint - B-35560 - 11-04-2024
    private String paramExcludeCisDivsStr;
    // end add - equint - B-35560 - 11-04-2024
    
    //Class Level Record variables
    private static List<FieldActivityType_Id> faTypeList = new ArrayList<FieldActivityType_Id>();
    private static List<MeterReadSource_Id> mtrReadSrcList = new ArrayList<MeterReadSource_Id>();
    private static List<String> mtrSizeList =  new ArrayList<String>();
    
    //Program Constants
    private static final String MR_ID = "MR_ID";
    private static final String BADGE_NUMBER = "BADGE_NBR";
    private static final String READ_DTTM = "READ_DTTM";
    private static final String REGREAD = "REGREAD";
    private static final String UOM_CD = "UOM_CD";
    private static final String TOU_CD = "TOU_CD";
    private static final String SP_ID = "SP_ID";
    
     
    public void validateSoftParameters(boolean isNewRun) {
         initializeSoftParams();
    
         if(paramVarianceThreshold.intValue() < 0){
             //addError("Variance Threshold should not be negative");
        	 addError(CustomMessageRepository.nm0074_VarianceThresholdCannotBeNegative(paramVarianceThreshold.toString().trim()));
         }
         
         BigInteger parmMaxErrors = getParameters().getSoftMaxErrors();
         // Check if the override maximum errors is less than 0 
         if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
             addError(CustomMessageRepository.nm0074_IntegerParamCannotBeNegative(parmMaxErrors.toString().trim()));
         }
         
         if(paramDaysBeforeDueDate.intValue()<0){
        	 addError(CustomMessageRepository.nm0074_DaysBeforeDueCannotBeNegative(parmMaxErrors.toString().trim()));
         }
         
         validateToDoRole();
         validateFCOptions();
         validateAndGetFCOptionFATypeList(paramFATypeOptType);
         validateAndGetFCOptionMtrSourceList(paramMtrReadSrcOptType);
         validateAndGetFCOptionMtrSizeList(paramMtrSizeOptType);
         validatePowerSource();
         validateServiceAuditChar();
         valiadateToDoEntryCharType();
         
         // start add - equint - B-35560 - 11-04-2024
         valiadateExcludeCisDivsToDo();
         // end add - equint - B-35560 - 11-04-2024
    }
    
    private void initializeSoftParams(){
        paramToDoType = getParameters().getSRVC_AUD_TD_TYPE_CD();
        paramToDoRole = getParameters().getSRVC_AUD_ROLE_ID();
        paramVarianceThreshold = getParameters().getVARIANCE_THRESHOLD();
        paramCorrectedUOM = getParameters().getUOM_CD1();
        paramUnCorrectedUOM = getParameters().getUOM_CD2();
        paramTOU1 = getParameters().getTOU_CD1();
        paramTOU2 = getParameters().getTOU_CD2();
        paramFeatConfig = getParameters().getSRVC_AUDT_FEATURE_CONFIG_NAME();
        paramMtrSizeOptType = getParameters().getMET_SIZE_FC_OPT_TYP().trim();
        paramMtrReadSrcOptType = getParameters().getMET_READ_SRC_FC_OPT_TYP().trim();
        paramFATypeOptType = getParameters().getFA_TYPE_FC_OPT_TYP().trim();
        paramSPPowStatCharType = getParameters().getSP_POW_STAT_CHAR_TYP();
        paramSPPowStatCharVal = getParameters().getSP_POW_STAT_CHAR_VAL().trim();
        paramServiceAuditMRCharType = getParameters().getSERVICE_AUDIT_MR_CHAR_TYP();
        strServiceCharVal = getParameters().getSERVICE_AUDIT_MR_CHAR_VAL().trim();
        paramMtrSizeCharType = getParameters().getMETER_SIZE_CHAR_TYP();
        paramDailyReadIdToDoCharType = getParameters().getDAILY_READ_TODO_CHAR_TYP();
        paramAMRIdToDoCharType = getParameters().getAMR_READ_TODO_CHAR_TYP();       
        paramDaysBeforeDueDate = getParameters().getX_DAYS_BEFORE_DUE_DATE();
	    // start add - equint - B-35560 - 11-04-2024
        paramExcludeCisDivsStr = getParameters().getEXCLUDE_CIS_DIV_TD();    
	    // end add - equint - B-35560 - 11-04-2024
      }
    
    /**
     * @return void
     *  if the Role is specified this method Validates if it is Valid for the ToDo Type.
     *  If Role is not specified, Default Role of the To DO Type is assigned
     */ 
    private void validateToDoRole(){
    	boolean exists = false;
    	paramToDoType.getId().getEntity();
    	if(notNull(paramToDoRole)){
        	 for(ToDoTypeRole todoTypeRole: paramToDoType.getRoles()){
       		   if(todoTypeRole.fetchIdToDoRole().getId().equals(paramToDoRole.getId())){
       			 exists = true;
       			 break;
       		 }
       	 }
       	 if(!exists){
       		 addError(CustomMessageRepository.nm0074_RoleInvalidForToDoType(paramToDoRole.getId().getIdValue(),paramToDoType.getId().getIdValue()));
       	 }
        }else{
        	paramToDoRole = paramToDoType.getDefaultRole().fetchIdToDoRole();
       	 
        }
    }
    
    private void validateFCOptions(){
       
		CmServiceReadsAuditLookup srvcLookup =  LookupHelper.getLookupInstance(CmServiceReadsAuditLookup.class, paramMtrSizeOptType);
		if(!srvcLookup.isValidLookupValue()){
			addError(CustomMessageRepository.nm0074_InvalidMeterSizeFCOption(paramMtrSizeOptType,paramFeatConfig.getId().getIdValue()));
		}
		
		srvcLookup =  LookupHelper.getLookupInstance(CmServiceReadsAuditLookup.class, paramMtrReadSrcOptType);
		if(!srvcLookup.isValidLookupValue()){
    		addError(CustomMessageRepository.nm0074_InvalidMeterReadSourceFCOption(paramMtrReadSrcOptType,paramFeatConfig.getId().getIdValue()));
		}
		
		srvcLookup =  LookupHelper.getLookupInstance(CmServiceReadsAuditLookup.class, paramFATypeOptType);
		if(!srvcLookup.isValidLookupValue()){
			addError(CustomMessageRepository.nm0074_InvalidFATypeFCOption(paramFATypeOptType,paramFeatConfig.getId().getIdValue()));
		}
    }
    
    private void validateAndGetFCOptionFATypeList(String strOption){
    	List<String> optValuesList = retrieveFCOptionValuesList(strOption);
    	if(optValuesList.size() == 0){
    		addError(CustomMessageRepository.nm0074_FATypesNotConfigured(paramFeatConfig.getId().getIdValue()));
     	}
    	FieldActivityType_Id faTypeId = null;
    	for(String strFAVal :optValuesList ){
    		faTypeId = new FieldActivityType_Id(strFAVal);
    		if(isNull(faTypeId.getEntity())){
    			addError(CustomMessageRepository.nm0074_InvalidFATypeConfiguredInFC(faTypeId.getIdValue(),paramFeatConfig.getId().getIdValue()));
    		}
    		faTypeList.add(faTypeId);
    	}
    }
    
    private void validateAndGetFCOptionMtrSourceList(String strOption){

    	List<String> optValuesList = retrieveFCOptionValuesList(strOption);
    	if(optValuesList.size() == 0){
    		addError(CustomMessageRepository.nm0074_MtrReadSrcNotConfigured(paramFeatConfig.getId().getIdValue()));
    	}
    	MeterReadSource_Id mtrSourceId = null;
    	for(String strMtrSrcVal :optValuesList ){
    		mtrSourceId = new MeterReadSource_Id(strMtrSrcVal);
    		if(isNull(mtrSourceId.getEntity())){
    			addError(CustomMessageRepository.nm0074_InvalidMtrReadSrcConfiguredInFC(mtrSourceId.getIdValue(),paramFeatConfig.getId().getIdValue()));
    		}
    		mtrReadSrcList.add(mtrSourceId);
    	}
    }
    
    private void validateAndGetFCOptionMtrSizeList(String strOption){
    	List<String> optValuesList = retrieveFCOptionValuesList(strOption);
    	if(optValuesList.size() == 0){
    		addError(CustomMessageRepository.nm0074_MtrSizeListNotConfigured(paramFeatConfig.getId().getIdValue()));
    	}
    	CharacteristicValue_Id charValId = null;
    	
    	for(String strMtrSrcVal :optValuesList ){
    		charValId = new CharacteristicValue_Id(paramMtrSizeCharType,strMtrSrcVal);
    		if(isNull(charValId.getEntity())){
    			addError(CustomMessageRepository.nm0074_InvalidMtrSizeConfiguredInFC(strMtrSrcVal,paramMtrSizeCharType.getId().getIdValue(),paramFeatConfig.getId().getIdValue()));
    		}
    		mtrSizeList.add(strMtrSrcVal.trim());
    	}
    }
    
    
    private List<String> retrieveFCOptionValuesList(String strOptionValue){
    	List<String> optValuesList = new ArrayList<String>();
        CmFeatureConfigurationRetriever cmFeatureConfigRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
        cmFeatureConfigRetriever.setParmWFMName(paramFeatConfig);
        cmFeatureConfigRetriever.setParmOptType(strOptionValue);
        optValuesList = cmFeatureConfigRetriever.getListOfOptionValues();
        
        return optValuesList;
    }
    
    private void validatePowerSource(){
    	CharacteristicValue_Id charValId = null;
		CharacteristicEntity_Id charEntityId  =  new CharacteristicEntity_Id(paramSPPowStatCharType,CharacteristicEntityLookup.constants.SERVICE_POINT);
		if(isNull(charEntityId.getEntity())){
                 addError(CustomMessageRepository.nm0074_CharTypeInvalidForSPEntity(paramSPPowStatCharType.getId().getIdValue()));
     	}
		//TODO Check if this val is predefined
    	charValId = new CharacteristicValue_Id(paramSPPowStatCharType,paramSPPowStatCharVal);
		if(isNull(charValId.getEntity())){
			addError(CustomMessageRepository.nm0074_InvalidPowerSrcValConfiguredInFC(paramSPPowStatCharVal,paramSPPowStatCharType.getId().getIdValue()));
		}

    }
    
    private void validateServiceAuditChar(){
    	CharacteristicValue_Id charValId = null;
		CharacteristicEntity_Id charEntityId  =  new CharacteristicEntity_Id(paramServiceAuditMRCharType,CharacteristicEntityLookup.constants.METER_READ);
		if(isNull(charEntityId.getEntity())){
			addError(CustomMessageRepository.nm0074_CharTypeInvalidForMREntity(paramServiceAuditMRCharType.getId().getIdValue()));
		}
		
    	charValId = new CharacteristicValue_Id(paramServiceAuditMRCharType,strServiceCharVal);
    	//TODO Check if this val is predefined
		if(isNull(charValId.getEntity())){ 
			addError(CustomMessageRepository.nm0074_InvalidSrvcAuditValConfiguredInFC(strServiceCharVal,paramServiceAuditMRCharType.getId().getIdValue()));
		}

    }
    
    private void valiadateToDoEntryCharType(){
		CharacteristicEntity_Id charEntityId  =  new CharacteristicEntity_Id(paramDailyReadIdToDoCharType,CharacteristicEntityLookup.constants.TO_DO_ENTRY);
		if(isNull(charEntityId.getEntity())){
			addError(CustomMessageRepository.nm0074_CharTypeInvalidForTDEntity(paramDailyReadIdToDoCharType.getId().getIdValue()));
		}
		
		 charEntityId  =  new CharacteristicEntity_Id(paramAMRIdToDoCharType,CharacteristicEntityLookup.constants.TO_DO_ENTRY);
		if(isNull(charEntityId.getEntity())){
			addError(CustomMessageRepository.nm0074_CharTypeInvalidForTDEntity(paramDailyReadIdToDoCharType.getId().getIdValue()));
		}
    }
    
    // start add - equint - B-35560 - 11-04-2024
    private void valiadateExcludeCisDivsToDo(){
    	if (notBlank(paramExcludeCisDivsStr)) {
    		String[] cisDivsArray = paramExcludeCisDivsStr.split("\\s*,\\s*");
        	for (String cisDivStr : cisDivsArray) {
        		CisDivision_Id cisDivId = new CisDivision_Id(cisDivStr);
        		if (isNull(cisDivId.getEntity())) {
        			addError(CustomMessageRepository.nm0074_InvalidExcludeCisDivToDo(cisDivStr));
        		}
        	}
    	}
    }
    // end add - equint - B-35560 - 11-04-2024

	public JobWork getJobWork() {
		QueryIterator mainIterator = retrieveManualMtrReads().iterate();
    	return createJobWorkForQueryIterator(mainIterator, this);
	}
	
	private PreparedStatement retrieveManualMtrReads(){
	      
        StringBuilder manualMtrReadsQuery = new StringBuilder();
        
        manualMtrReadsQuery.append("SELECT FA.FA_ID, FA.SP_ID, MR.MR_ID, MTR.BADGE_NBR, REG.REG_ID, REG.UOM_CD,REG.TOU_CD, MR.READ_DTTM, RR.REG_READING REGREAD ") ;
        // Start change IM-037780 Neha
		//manualMtrReadsQuery.append("FROM  CI_FA FA, CI_FA_STEP FS, CI_MR MR, CI_REG_READ RR, CI_REG REG, CI_MTR MTR, CI_FA_STAGE_UP SFS ");
		manualMtrReadsQuery.append("FROM  CI_FA FA, CI_FA_STEP FS, CI_MR MR, CI_REG_READ RR, CI_REG REG, CI_MTR MTR ");
		// End change IM-037780 Neha
        manualMtrReadsQuery.append("WHERE FA.FA_ID = FS.FA_ID ");
		// Start delete IM-037780 Neha
        //manualMtrReadsQuery.append("AND SFS.FA_ID = FA.FA_ID ");
		// End delete IM-037780 Neha
        manualMtrReadsQuery.append("AND FA.FA_STATUS_FLG = :faComplete ");
        manualMtrReadsQuery.append("AND FS.FA_STEP_TY_ACT_FLG= :mtrRead ");
        manualMtrReadsQuery.append("AND FS.MR_ID IS NOT NULL ");
        manualMtrReadsQuery.append("AND FS.MR_ID = MR.MR_ID ");
		// Start change IM-037780 Neha
        //manualMtrReadsQuery.append("AND TRUNC(SFS.WORK_DTTM) BETWEEN (:pastXDaysDt) AND :processDt ");
		manualMtrReadsQuery.append("AND TRUNC(FA.SCHED_DTTM) BETWEEN (:pastXDaysDt) AND :processDt ");
		// End change IM-037780 Neha
        manualMtrReadsQuery.append("AND MR.MR_ID = RR.MR_ID ");
        manualMtrReadsQuery.append("AND RR.REG_ID = REG.REG_ID ");
        manualMtrReadsQuery.append("AND REG.MTR_ID = MTR.MTR_ID ");
        
        manualMtrReadsQuery.append("AND MR.MR_SOURCE_CD IN ( ");
        int counter = 0;
        for (;counter < mtrReadSrcList.size(); counter++) {
            if (counter == 0) {
            	manualMtrReadsQuery.append(":mtrSrcId" + counter);
            } else {
            	manualMtrReadsQuery.append(", :mtrSrcId" + counter);
            }
        }
        manualMtrReadsQuery.append(")  ");

        manualMtrReadsQuery.append("AND REG.UOM_CD IN (:uomCd1 ");
        if(notNull(paramUnCorrectedUOM)){ //optional param
        	manualMtrReadsQuery.append(",:uomCd2 ");
        }
        manualMtrReadsQuery.append(" )  ");
        if(notNull(paramTOU1) &&  notNull(paramTOU2))
        	manualMtrReadsQuery.append("AND REG.TOU_CD IN ( :touCd1, :touCd2) "); 
        manualMtrReadsQuery.append("AND EXISTS "); //AMR Read Check
        manualMtrReadsQuery.append("( SELECT '1' FROM CI_SP_CHAR SC "); 
        manualMtrReadsQuery.append("WHERE SC.CHAR_TYPE_CD = :pwrStatus "); 
        manualMtrReadsQuery.append("AND SC.CHAR_VAL = :pwrCharVal  ");
        manualMtrReadsQuery.append("AND SC.SP_ID = FA.SP_ID  "); 
        manualMtrReadsQuery.append("AND SC.EFFDT=(SELECT MAX(SC1.EFFDT)  "); 
        manualMtrReadsQuery.append("FROM CI_SP_CHAR SC1  "); 
        manualMtrReadsQuery.append("WHERE SC1.SP_ID = SC.SP_ID  "); 
        manualMtrReadsQuery.append("AND SC1.CHAR_TYPE_CD = :pwrStatus   "); 
        manualMtrReadsQuery.append("AND SC1.EFFDT <= :processDt ))  "); 
        
        manualMtrReadsQuery.append("AND EXISTS   "); //Large Meter Check
        manualMtrReadsQuery.append("( SELECT '1' FROM CI_MTR_CHAR MC  "); 
        manualMtrReadsQuery.append("WHERE MC.CHAR_TYPE_CD = :mtrSizeCharType  ");
        manualMtrReadsQuery.append("AND MC.CHAR_VAL IN (   ");
         counter = 0;
        for (;counter < mtrSizeList.size(); counter++) {
            if (counter == 0) {
            	manualMtrReadsQuery.append(":mtrSize" + counter);
            } else {
            	manualMtrReadsQuery.append(", :mtrSize" + counter);
            }
        }
        manualMtrReadsQuery.append(")  ");
        
        manualMtrReadsQuery.append("AND MC.MTR_ID = MTR.MTR_ID  ");
        manualMtrReadsQuery.append("AND MC.EFFDT=(SELECT MAX(MC1.EFFDT) ");
        manualMtrReadsQuery.append(" FROM CI_MTR_CHAR MC1 ");
        manualMtrReadsQuery.append("WHERE MC1.MTR_ID = MC.MTR_ID ");
        manualMtrReadsQuery.append("AND MC1.CHAR_TYPE_CD = :mtrSizeCharType ");
        manualMtrReadsQuery.append("AND MC1.EFFDT <= :processDt))   ");
        manualMtrReadsQuery.append("AND NOT EXISTS   ");
        manualMtrReadsQuery.append("( SELECT '1' FROM CI_MR_CHAR MRC   ");
        manualMtrReadsQuery.append("WHERE MRC.CHAR_TYPE_CD = :srvcCharType ");
        manualMtrReadsQuery.append("AND MRC.MR_ID = MR.MR_ID   ");
        manualMtrReadsQuery.append("AND MRC.SEQ_NUM = (SELECT MAX(MR1.SEQ_NUM) ");
        manualMtrReadsQuery.append(" FROM CI_MR_CHAR MR1 ");
        manualMtrReadsQuery.append("WHERE MR1.MR_ID = MR.MR_ID  ");
        manualMtrReadsQuery.append("AND MR1.CHAR_TYPE_CD = :srvcCharType )) ");
        manualMtrReadsQuery.append("AND NOT EXISTS   ");
        manualMtrReadsQuery.append("(SELECT '1' FROM CI_FA FA1  ");// Specific FA Type
        manualMtrReadsQuery.append(" WHERE FA1.FA_TYPE_CD IN ( ");
        counter = 0;
        for (;counter < faTypeList.size(); counter++) {
            if (counter == 0) {
            	manualMtrReadsQuery.append(":faTypeId" + counter);
            } else {
            	manualMtrReadsQuery.append(", :faTypeId" + counter);
            }
        }
        manualMtrReadsQuery.append(")  ");
        manualMtrReadsQuery.append("AND FA1.FA_STATUS_FLG = :faPending ");
        manualMtrReadsQuery.append("AND FA1.SP_ID = FA.SP_ID) ");
        manualMtrReadsQuery.append("ORDER BY  MTR.BADGE_NBR ");
        //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation   
        //PreparedStatement pstmt =  createPreparedStatement(manualMtrReadsQuery.toString());
        PreparedStatement pstmt =  createPreparedStatement(manualMtrReadsQuery.toString(), getClass().getName());
        //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        pstmt.bindLookup("faComplete",  FieldActivityStatusLookup.constants.COMPLETED);
        pstmt.bindLookup("mtrRead",  FieldActivityStepTypeActionLookup.constants.READ_METER);
        pstmt.bindDate("processDt", getProcessDateTime().getDate());
        pstmt.bindDate("pastXDaysDt", getProcessDateTime().getDate().addDays(paramDaysBeforeDueDate.negate().intValue()));
        counter = 0;
        for (MeterReadSource_Id mrsId : mtrReadSrcList) {
        	pstmt.bindId("mtrSrcId" + counter++, mrsId);
        	
        }
        pstmt.bindId("uomCd1",paramCorrectedUOM.getId() );
        if(notNull(paramUnCorrectedUOM)){ //optional param
        	pstmt.bindId("uomCd2",paramUnCorrectedUOM.getId() );
        }
          
         if(notNull(paramTOU1) &&  notNull(paramTOU2)){
        	 pstmt.bindId("touCd1",paramTOU1.getId() );
        	 pstmt.bindId("touCd2",paramTOU2.getId() );
         }
         
        //pstmt.bindString("touCd1",TimeOfUse.properties.toString() );
        pstmt.bindId("pwrStatus", paramSPPowStatCharType.getId() );
        pstmt.bindStringProperty("pwrCharVal", getStringPropertyForCharType(paramSPPowStatCharType), StringUtilities.padRight(paramSPPowStatCharVal,16));

      
        pstmt.bindId("mtrSizeCharType", paramMtrSizeCharType.getId() );      
        StringProperty strProperty = getStringPropertyForCharType(paramMtrSizeCharType);
        counter = 0;
        for (String meterSize  : mtrSizeList) {
        	pstmt.bindStringProperty("mtrSize" + counter++,strProperty, StringUtilities.padRight(meterSize.trim(),16));
        	
        }
        
        pstmt.bindId("srvcCharType", paramServiceAuditMRCharType.getId() );
        counter = 0;
        for (FieldActivityType_Id faTyId : faTypeList) {
        	pstmt.bindId("faTypeId" + counter++, faTyId);
        	
        }
        pstmt.bindLookup("faPending", FieldActivityStatusLookup.constants.PENDING);

        return pstmt;

	}
	
	private StringProperty getStringPropertyForCharType(CharacteristicType charType){
		StringProperty strProperty = null;
        if(charType.getCharacteristicType().isAdhocValue()){
        	strProperty = MeterCharacteristic.properties.adhocCharacteristicValue;
        }else if(charType.getCharacteristicType().isPredefinedValue()){
        	strProperty = ServicePointCharacteristic.properties.characteristicValue;
        }else if(charType.getCharacteristicType().isForeignKeyValue()){
        	strProperty = ServicePointCharacteristic.properties.characteristicValueForeignKey1;
        }
        return strProperty;
	}
	
    public ThreadWorkUnit createWorkUnit(QueryResultRow row){
    	ThreadWorkUnit threadUnit = new ThreadWorkUnit();             
        FieldActivity_Id mtrReadId = (FieldActivity_Id) row.getId("FA_ID", FieldActivity.class);
        threadUnit.setPrimaryId(mtrReadId);
        threadUnit.addSupplementalData(MR_ID, ((MeterRead_Id)row.getId("MR_ID", MeterRead.class)));
        threadUnit.addSupplementalData(BADGE_NUMBER, row.getString("BADGE_NBR"));
        threadUnit.addSupplementalData(UOM_CD, (UnitOfMeasure_Id) row.getId("UOM_CD",UnitOfMeasure.class));
        threadUnit.addSupplementalData(TOU_CD, (TimeOfUse_Id)row.getId("TOU_CD",TimeOfUse.class));
        threadUnit.addSupplementalData(READ_DTTM, row.getDateTime("READ_DTTM"));
        threadUnit.addSupplementalData(REGREAD, row.getBigDecimal("REGREAD"));
        threadUnit.addSupplementalData(SP_ID, ((ServicePoint_Id)row.getId("SP_ID",ServicePoint.class)));
        
        return threadUnit;
    }
	

	public Class<CmServiceAuditReadsCompare_BatchProcessWorker> getThreadWorkerClass() {
		return CmServiceAuditReadsCompare_BatchProcessWorker.class;
	}

	public static class CmServiceAuditReadsCompare_BatchProcessWorker extends
			CmServiceAuditReadsCompare_BatchProcessWorker_Gen {
	    
	    // Start Add - 2016-06-09 - SFelipe - Defect 3443676
	    // Batch parameters
	    private ToDoType paramToDoType;
	    private Role paramToDoRole;
	    private BigInteger paramVarianceThreshold;
	    private UnitOfMeasure paramCorrectedUOM;
	    private UnitOfMeasure paramUnCorrectedUOM;
	    private CharacteristicType paramServiceAuditMRCharType;
	    private CharacteristicType paramDailyReadIdToDoCharType;
	    private CharacteristicType paramAMRIdToDoCharType;
	    private String strServiceCharVal;
	    // End Add - 2016-06-09 - SFelipe - Defect 3443676
		
		private String previousBadgeNumber = " ";
		private BigDecimal amrCorrectedRead = null;
		private BigDecimal amrUnCorrectedRead = null;
		private Date amrCorrectedReadDate = null;
		private Date amrUnCorrectedReadDate = null;
		
		private FieldActivity_Id faId = null;
		private DateTime dailyReadDateTime = null;
		private BigDecimal regRead = null;
		private String strBadgeNumber = null;
		private UnitOfMeasure_Id uomCd = null;
		private MeterRead_Id mrId = null;
		private Bool isToDoCreated = Bool.FALSE;
		private ServicePoint_Id spId = null;
		private String strAMRWsdlURL = null;
		
		// start add - equint - B-35560 - 11-04-2024
		private List<CisDivision_Id> excludeCisDivIds = new ArrayList<CisDivision_Id>();
	    // end add - equint - B-35560 - 11-04-2024
        
		// Start Add - 2016-06-09 - SFelipe - Defect 3443676
		@Override
        public void initializeThreadWork(boolean initializationPreviouslySuccessful) 
                throws ThreadAbortedException, RunAbortedException {
		    paramToDoType = getParameters().getSRVC_AUD_TD_TYPE_CD();
		    paramToDoRole = getParameters().getSRVC_AUD_ROLE_ID();
		    paramVarianceThreshold = getParameters().getVARIANCE_THRESHOLD();
		    paramCorrectedUOM = getParameters().getUOM_CD1();
		    paramUnCorrectedUOM = getParameters().getUOM_CD2();
		    paramServiceAuditMRCharType = getParameters().getSERVICE_AUDIT_MR_CHAR_TYP();
		    paramDailyReadIdToDoCharType = getParameters().getDAILY_READ_TODO_CHAR_TYP();
		    paramAMRIdToDoCharType = getParameters().getAMR_READ_TODO_CHAR_TYP();  
		    strServiceCharVal = getParameters().getSERVICE_AUDIT_MR_CHAR_VAL().trim();
		    
		    // start add - equint - B-35560 - 11-04-2024
		    String excludeCisDivsStr = getParameters().getEXCLUDE_CIS_DIV_TD();
		    if (notBlank(excludeCisDivsStr)) {
			    String[] cisDivsArray = excludeCisDivsStr.split("\\s*,\\s*");
		    	for (String cisDivStr : cisDivsArray) {
		    		CisDivision_Id cisDivId = new CisDivision_Id(cisDivStr);
		    		if (notNull(cisDivId.getEntity())) {
		    			excludeCisDivIds.add(cisDivId);
		    		}
		    	}
		    }
	    	// end add - equint - B-35560 - 11-04-2024
        }
		// End Add - 2016-06-09 - SFelipe - Defect 3443676

		public ThreadExecutionStrategy createExecutionStrategy() {
			// TODO Auto-generated method stub
			return new StandardCommitStrategy(this);
		}
		

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			//Initialize record variables
			faId = null;
			dailyReadDateTime = null;
			regRead = null;
			strBadgeNumber = null;
			uomCd = null;
			mrId = null;
			spId = null;
			
			faId  = (FieldActivity_Id)unit.getPrimaryId();
			mrId = (MeterRead_Id)unit.getSupplementallData(MR_ID);
			strBadgeNumber = ((String)unit.getSupplementallData(BADGE_NUMBER)).trim();
			uomCd = (UnitOfMeasure_Id)unit.getSupplementallData(UOM_CD);
			TimeOfUse_Id touCd = (TimeOfUse_Id)unit.getSupplementallData(TOU_CD);
			dailyReadDateTime = (DateTime)unit.getSupplementallData(READ_DTTM);
			regRead = (BigDecimal)unit.getSupplementallData(REGREAD); 
			spId = (ServicePoint_Id)unit.getSupplementallData(SP_ID); 

			
			if(!strBadgeNumber.equals(previousBadgeNumber.trim())){
				//New Fetch - Initalize variables
				amrCorrectedRead = null;
				amrUnCorrectedRead = null;
				amrCorrectedReadDate = null;
				amrUnCorrectedReadDate = null;
				isToDoCreated = Bool.FALSE;
				retreiveReadDetailsFromAMR(strBadgeNumber);
			}
			
			if((uomCd.compareTo(paramCorrectedUOM.getId())!=0) && (uomCd.compareTo(paramUnCorrectedUOM.getId())!=0)){
				logError(CustomMessageRepository.nm0074_MtrReadUomNotMatchingInputUOMParams(uomCd.getIdValue(),strBadgeNumber));
			}
			
			//Mohit IM-037780
			//mark the Meter Read as Service Audited
			//if (isToDoCreated.isFalse()){
			    // Add Meter Read Char
			  //     addMeterReadChar();	
			//}
			//Mohit IM-037780
			// isToDoCreated check is for the Two register Meters where if ToDo is already created for the first register,this flag helps  to avoid processing and creation of other ToDo
			if((uomCd.compareTo(paramCorrectedUOM.getId())==0) && isToDoCreated.isFalse()){ 
				processCorrectedRead();
			}else if( notNull(paramUnCorrectedUOM) &&  (uomCd.compareTo(paramUnCorrectedUOM.getId())==0) && isToDoCreated.isFalse()){
				processUnCorrectedRead();
			}
			
			previousBadgeNumber = 	strBadgeNumber;
				
			return true;
		}

		/*
		 * TODO: A webservice call to the AMR Read Database has to be implemented to fetch the latest read.
		 * 
		 */
		private void retreiveReadDetailsFromAMR(String strBadgeNumber){ 
			/*
			 * Use the Badge Number and get the Register Reads
			 * set the Corrected read value to the amrCorrectedRead
			 * set the Uncorrected value if exists to amrUnCorrectedRead
			 *  set the Corrected read Date to the amrCorrectedReadDate
			 * set the Uncorrected read Date if exists to amrUnCorrectedReadDate;
			 * 
			 * */
			
			CmWSDLCallToAMRDataBase wsdlComp = CmWSDLCallToAMRDataBase.Factory.newInstance();
			if(isNull(strAMRWsdlURL)){
				
			    strAMRWsdlURL = wsdlComp.getWsdlURLForAMRReads();
			      if(isNull(strAMRWsdlURL)){
			    	  addError(wsdlComp.getServerMessage());
				  
			    }
			}
			wsdlComp.setWsdlURL(strAMRWsdlURL);
			wsdlComp.setInputBadgeNumber(strBadgeNumber);
			wsdlComp.setInputSpId(spId);
			// Start change IM-037780
			  //wsdlComp.setInputReadDate(dailyReadDateTime.getDate());
			   wsdlComp.setInputReadDate(dailyReadDateTime.getDate().addDays(-1));
			// End change IM-037780  
			try{
				wsdlComp.retreiveReadDetailsFromAMR();
			    
			}catch(UnknownHostException uhe){
				throw new RunAbortedException(CustomMessageRepository.webServiceHostUnreachable(uhe.getMessage()));
			}catch(Exception excp){
				 
				throw new RunAbortedException(CustomMessageRepository.errorInvokingAMRWebService(excp.getMessage()));
			}
			amrCorrectedRead = wsdlComp.getAmrCorrectedRead();
			amrUnCorrectedRead = wsdlComp.getAmrUnCorrectedRead();
			if(notNull(wsdlComp.getAmrCorrectedReadDate()))
			    amrCorrectedReadDate = wsdlComp.getAmrCorrectedReadDate().getDate();
			if(notNull(wsdlComp.getAmrUnCorrectedReadDate()))
			   amrUnCorrectedReadDate = wsdlComp.getAmrUnCorrectedReadDate().getDate();


		}
		
		private void processCorrectedRead(){
			
			BigDecimal readDifference = BigDecimal.ZERO;
			boolean isReadExists = true;
			
			//Check if the AMR Read exists and if the Latest read is equals Daily Read Date - 1
			if(isNull(amrCorrectedReadDate) || isNull(amrCorrectedRead)){
				isReadExists = false;  
			}else if(notNull(amrCorrectedReadDate) && ( amrCorrectedReadDate.compareTo(dailyReadDateTime.getDate().addDays(-1)) != 0 )){
				isReadExists = false; 
			}
			
			if(!isReadExists){
				// start add - equint - B-35560 - 11-04-2024
				if (shouldSkipToDo().isFalse()) {
				// end add - equint - B-35560 - 11-04-2024
				
	                String strMessage = CustomMessageRepository.nm0074_td_err_amrReadNotFound(strBadgeNumber,uomCd.getIdValue()).getMessageText();
				    createToDo(getMessageId(CustomMessageRepository.NM0074_AMR_READ_NOT_FOUND),getNoReadMessageParams(),strMessage);
	     		    isToDoCreated = Bool.TRUE;
	     		    
     		    // start add - equint - B-35560 - 11-04-2024
				}
				// end add - equint - B-35560 - 11-04-2024
			    return;
			}
			//Check if the Corrected Read is within the Threshold.
			if(notNull(amrCorrectedRead) ){
			  	readDifference = regRead.add(amrCorrectedRead.negate());
			  	//Start Mohit IM-037780
				//if((readDifference.abs().toBigInteger()).compareTo(paramVarianceThreshold) >= 0){
				if((readDifference.abs().toBigInteger()).compareTo(paramVarianceThreshold) > 0){
				//End Mohit IM-037780
					// start add - equint - B-37805 - 03-20-2025
					if (shouldSkipToDo().isFalse()) {
					// end add - equint - B-37805 - 03-20-2025
		                String strMessage = CustomMessageRepository.nm0074_tderr_varianceThresholdExceeded(strBadgeNumber).getMessageText();
					    ToDoEntry tdEntry = createToDo(getMessageId(CustomMessageRepository.NM0074_VARIANCE_THRESHOLD_EXCEEDED),getVarThresholdMessageParams(),strMessage);
					      // Add ToDo Chars
					    addToDoChars(tdEntry,Bool.TRUE);
						//Start Mohit IM-037780
						//addMeterReadChar();
						//End Mohit IM-037780
					    isToDoCreated = Bool.TRUE;
				    // start add - equint - B-37805 - 03-20-2025
					}
					// end add - equint - B-37805 - 03-20-2025
				}
				//Start Mohit IM-037780
				addMeterReadChar();	
				//End Mohit IM-037780
				
			}
		}
		
		
		private void processUnCorrectedRead(){
			BigDecimal readDifference = BigDecimal.ZERO;
			boolean isReadExists = true;
			
			if(isNull(amrUnCorrectedReadDate) || isNull(amrUnCorrectedRead)){
				isReadExists = false; 
			}else if(notNull(amrUnCorrectedReadDate) && ( amrUnCorrectedReadDate.compareTo(dailyReadDateTime.getDate().addDays(-1)) != 0 )){
				isReadExists = false;
			}
			if(!isReadExists){
				// start add - equint - B-35560 - 11-04-2024
				if (shouldSkipToDo().isFalse()) {
				// end add - equint - B-35560 - 11-04-2024
					
	                String strMessage = CustomMessageRepository.nm0074_td_err_amrReadNotFound(strBadgeNumber,uomCd.getIdValue()).getMessageText();
				    createToDo(getMessageId(CustomMessageRepository.NM0074_AMR_READ_NOT_FOUND),getNoReadMessageParams(),strMessage);
				    isToDoCreated = Bool.TRUE;
				    
			    // start add - equint - B-35560 - 11-04-2024
				}
				// end add - equint - B-35560 - 11-04-2024
			    return;
			}
			if(notNull(amrUnCorrectedRead) ){
			  	readDifference = regRead.add(amrUnCorrectedRead.negate());
				//Start Mohit IM-037780
				if((readDifference.abs().toBigInteger()).compareTo(paramVarianceThreshold) > 0){
				//End Mohit IM-037780
					// start add - equint - B-37805 - 03-20-2025
					if (shouldSkipToDo().isFalse()) {
					// end add - equint - B-37805 - 03-20-2025

		                String strMessage = CustomMessageRepository.nm0074_tderr_varianceThresholdExceeded(strBadgeNumber).getMessageText();
					    ToDoEntry tdEntry = createToDo(getMessageId(CustomMessageRepository.NM0074_VARIANCE_THRESHOLD_EXCEEDED),getVarThresholdMessageParams(),strMessage);
					      // Add ToDo Chars
					    addToDoChars(tdEntry,Bool.FALSE);
						//Start Mohit IM-037780
						//addMeterReadChar();
						//End Mohit IM-037780

					    isToDoCreated = Bool.TRUE;
				    // start add - equint - B-37805 - 03-20-2025
					}
					// end add - equint - B-37805 - 03-20-2025
					
				}
				//Start Mohit IM-037780
			    addMeterReadChar();
				//End Mohit IM-037780
			}	
		}
		
		// start add - equint - B-35560 - 11-04-2024
		/**
		 * Skip to do depending on the set criteria 
		 * - do not create to do if the CIS division is included in the exclude CIS Div Param
		 * @return
		 */
		private Bool shouldSkipToDo() {
			return Bool.valueOf(excludeCisDivIds.contains(spId.getEntity().getPremise().getDivisionId()));
		}
		// end add - equint - B-35560 - 11-04-2024
		
		private Message_Id getMessageId(int msgNum){
		    MessageCategory_Id msgCatId = new MessageCategory_Id(BigInteger.valueOf(CustomMessageRepository.MESSAGE_CATEGORY));
		    Message_Id msgId = new Message_Id(msgCatId, BigInteger.valueOf(msgNum)); 
		    return msgId;
		}
		
		private List<String> getNoReadMessageParams(){
			List <String> messageParameterList = new ArrayList<String> ();
			messageParameterList.add(0,strBadgeNumber);
			messageParameterList.add(1,uomCd.getIdValue().trim());
			messageParameterList.add(2,dailyReadDateTime.getDate().toString()); 
			return messageParameterList;
		}
		
		private List<String> getVarThresholdMessageParams(){
			List <String> messageParameterList = new ArrayList<String> ();
			messageParameterList.add(0,strBadgeNumber);
			messageParameterList.add(1,dailyReadDateTime.getDate().toString()); 
			return messageParameterList;
		}
		
		private void addMeterReadChar(){
		    MeterRead meterRead = mrId.getEntity();
		    MeterReadCharacteristic_DTO mreadDTO = meterRead.getCharacteristics().newChildDTO();
		    MeterReadCharacteristic_Id mrCharId  = new MeterReadCharacteristic_Id(meterRead,paramServiceAuditMRCharType,BigInteger.valueOf(meterRead.getCharacteristics().size()+1));
		    mreadDTO.setId(mrCharId);
		    mreadDTO.setCharacteristicValue(strServiceCharVal);
     	    mreadDTO.newEntity();
		}
		
		private void addToDoChars(ToDoEntry tdEntry, Bool isCorrected){
			BigDecimal mtrRead = null;
			if(isCorrected.isTrue())
				mtrRead = amrCorrectedRead;
			else
				mtrRead = amrUnCorrectedRead;
			
		    ToDoEntryCharacteristic_DTO tdEntryDTO = tdEntry.getCharacteristics().newChildDTO();
		    ToDoEntryCharacteristic_Id tdEntryCharId = new ToDoEntryCharacteristic_Id(tdEntry,paramAMRIdToDoCharType,BigInteger.ONE);
		    tdEntryDTO.setId(tdEntryCharId);
		    tdEntryDTO.setAdhocCharacteristicValue(mtrRead.toString());
		    tdEntryDTO.newEntity();
		    
		    tdEntryDTO = tdEntry.getCharacteristics().newChildDTO();
		    tdEntryCharId = new ToDoEntryCharacteristic_Id(tdEntry,paramDailyReadIdToDoCharType,BigInteger.valueOf(2));
		    tdEntryDTO.setId(tdEntryCharId);
		    tdEntryDTO.setCharacteristicValueForeignKey1(mrId.getIdValue());
		    tdEntryDTO.newEntity();
		}
		
		/**
	     * @return void 
	     *  This method created todo.
	     * 
	     */  
		private ToDoEntry createToDo(Message_Id msgId,List <String> messageParameterList, String strSortMessage){
			ToDoEntry_DTO entryDto  = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
			 paramToDoType = (ToDoType)new ToDoType_Id(paramToDoType.getId().getIdValue()).getEntity();
			entryDto.setToDoTypeId(paramToDoType.getId());
			entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
			entryDto.setToDoPriority(paramToDoType.getToDoPriority());
			if(isNull(paramToDoRole)){
				entryDto.setToDoRoleId(paramToDoType.getDefaultRole().fetchIdToDoRole().getId());
			}else{
				entryDto.setToDoRoleId(paramToDoRole.getId());
			}
						
			entryDto.setCreationDateTime(getProcessDateTime());
			entryDto.setToDoPriority(paramToDoType.getToDoPriority());

			ArrayList<ToDoSortKeyValue_DTO>sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();
			ToDoTypeSortKeyTypes sortKeyTypes = paramToDoType.getSortKeyTypes();
			
			for (Iterator<ToDoSortKeyType> iter = sortKeyTypes.iterator(); iter.hasNext();) {
				ToDoSortKeyType sortKeyType =  iter.next();
				ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
				BigInteger seq = sortKeyType.fetchIdSequence();
				sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));
			
				if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(1))==0){
					sortKeyDto.setKeyValue(strSortMessage); 
				}
			    sortKeyList.add(sortKeyDto);
			  }
			
			
			
			ArrayList<ToDoDrillKeyValue_DTO>drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
			ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO)	createDTO(ToDoDrillKeyValue.class);
			ToDoDrillKeyType drillKeyType = (ToDoDrillKeyType) paramToDoType.getDrillKeyTypes().iterator().next();
			BigInteger sequence = drillKeyType.fetchIdSequence();
			drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, sequence));
		
			drillKeyDto.setKeyValue(faId.getIdValue());
			drillKeyList.add(drillKeyDto);
			
		    entryDto.setMessageId(msgId); 
		    
	    
			ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory.newInstance();
    		toDoEntryData.setDrillKeys(drillKeyList);
			toDoEntryData.setEntryDto(entryDto);
			toDoEntryData.setSortKeys(sortKeyList);
			toDoEntryData.setMessageParams(messageParameterList);
			ArrayList <ToDoEntryCharacteristic_DTO>  charList = new ArrayList<ToDoEntryCharacteristic_DTO> ();
			toDoEntryData.setToDoCharacteristics(charList);
				
			ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
			ToDoEntry tdEntry =  toDoProcessor.addToDo(toDoEntryData);
			return tdEntry;
			
		}

	}//Inner

}
