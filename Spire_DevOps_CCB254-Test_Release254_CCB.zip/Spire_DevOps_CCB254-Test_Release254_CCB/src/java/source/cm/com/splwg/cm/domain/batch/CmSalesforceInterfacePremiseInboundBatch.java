/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * SalesForce Interface - Premise In-bound Process to CC&B Batch
 * 
 * This new batch process will interrogate the staging data and process 
 * none completed records. This interface will create a notification upload
 * staging record as well as notification upload context records to hold
 * the data from the staging record. It will then crate a To Do for each
 * created notification upload record that will allow users to navigate 
 * from the To Do directly to the notification upload staging page.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-07-26   JHERNA      Initial Version. Post v2.4 upgrade.
 * 2017-07-12	JHERNA		SysAid#201312. Long premise notes are not being
 *                          catered by current solution (max premise notes 
 *                          found is 2000 bytes while current solution only 
 *                          expects max of 50 bytes)
 * 2017-07-13	JHERNA		SysAid#201309. Request to add City, Region and
 *                          Created By identifiers as a To Do Message 
 * 2018-08-16   SMiranda	SA-251520A. Add the following fields to the
 * 							XXL_INT_PREM_IN_STG table:
 * 							1. PRNT_PREM_ID
 *  						2. CIAC_MO_CHARGE
 *  						3. CIAC_TOT_COST
 *  						4. CIAC_TRM_IN_MO
 *  						5. BLDR_BUILD_STAGE
 *  						6. BLDR_DUE_DATE
 *  						The new fields will be added as NUS Context
 *  						values
 * *************************************************************************                
 */


package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Id;
import com.splwg.base.api.lookup.CharacteristicEntityLookup;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.NotificationUploadExtensionLookup;
import com.splwg.base.api.lookup.NotificationUploadStatusLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.role.Role_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.base.domain.workflow.notificationExternalId.NotificationExternalId;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadCharacteristic_DTO;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadCharacteristic_Id;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadContext_DTO;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadContext_Id;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload_DTO;
import com.splwg.base.domain.workflow.notificationUploadExtensionType.NotificationUploadExtensionType;
import com.splwg.cm.api.lookup.CmInterfaceStatusLookup;
import com.splwg.cm.api.lookup.NotificationUploadContextLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.interfaceStaging.CmInterfaceErrorLogMaintenance;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

/**
 * @author 90622
 *
@BatchJob (modules = {}, multiThreaded = false, rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (name = INTERFACE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = notificationUploadExtensionType, name = SF_ADD_PREM_SP_NT_UPLOAD_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = notificationExternalId, name = SF_EXTERNAL_SYSTEM, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = SF_ADD_PREM_TD_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = role, name = SF_ADD_PREM_TD_ROLE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = SF_ADD_PREM_SP_TD_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = role, name = SF_ADD_PREM_SP_TD_ROLE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CHAR_TYPE_PREM_NOTES, required = true, type = entity)})
 */
public class CmSalesforceInterfacePremiseInboundBatch extends
		CmSalesforceInterfacePremiseInboundBatch_Gen {
	
	// Soft Parameters needed by JobWork
	private String interfaceName;

	// Id class for the Staging Key
	private static class CmInboundStaging_Id 
			implements Id {
		
		private static final long serialVersionUID = 1L;		
		private String stagingKey;
		
		public CmInboundStaging_Id(String stagingKey) {
			setStagingKey(stagingKey);
		}
		
		public String getStagingKey() {
			return stagingKey;
		}
		
		private void setStagingKey(String stagingKey) {
			this.stagingKey = stagingKey;
		}
		
		public boolean isNull() {
			return false;
		}
		
		public void appendContents(StringBuilder arg0) {
			
		}		
	}
	
	@Override
	public void validateSoftParameters(boolean isNewRun) {

		// Retrieve Parameter 10: Interface Name
		interfaceName = this.getParameters().getINTERFACE_NAME();
	}

	@SuppressWarnings("unchecked")
	public JobWork getJobWork() {

		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT STAGING_KEY, LOGICAL_TRX_NUMBER, ORIGINATING_KEY, ");
		stringBuilder.append("   CREATION_DATETIME, UPDATE_DATETIME, SOURCE_SYSTEM_NAME, TARGET_SYSTEM_NAME ");
		stringBuilder.append("FROM XXL_INT_INBOUND_STG ");
		stringBuilder.append("WHERE STATUS_FLAG = :statusFlag ");
		stringBuilder.append("AND INTERFACE_NAME = :interfaceName ");
		stringBuilder.append("ORDER BY STAGING_KEY ");

		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), 
				"=MAIN QUERY - SELECT PENDING SALESFORCE DATA FROM STAGING=");
		prepState.bindString("statusFlag", CmInterfaceStatusLookup.constants.NEW.trimmedValue(), "STATUS_FLAG");
		prepState.bindString("interfaceName", interfaceName.trim(), "INTERFACE_NAME");
		prepState.execute();
		
		@SuppressWarnings("rawtypes")
		QueryIterator mainSQL = prepState.iterate();
		
		return  createJobWorkForQueryIterator(mainSQL, this);		
	}

	@Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow queryResultRow) {

		DateTime creationDttm = (DateTime) queryResultRow.getDateTime("CREATION_DATETIME");
		DateTime updateDttm = (DateTime) queryResultRow.getDateTime("UPDATE_DATETIME");
		String stagingKey = (String) queryResultRow.getString("STAGING_KEY");
		String logicalTrxNbr = (String) queryResultRow.getString("LOGICAL_TRX_NUMBER");
		String originatingKey = (String) queryResultRow.getString("ORIGINATING_KEY");
		String sourceSystemName = (String) queryResultRow.getString("SOURCE_SYSTEM_NAME");
		String targetSystemName = (String) queryResultRow.getString("TARGET_SYSTEM_NAME");
		CmInboundStaging_Id stagingID = new CmInboundStaging_Id(stagingKey.trim());
		
		ThreadWorkUnit twu = new ThreadWorkUnit();
		twu.setPrimaryId(stagingID);
		twu.addSupplementalData("CREATION_DATETIME", creationDttm);
		twu.addSupplementalData("UPDATE_DATETIME", updateDttm);
		twu.addSupplementalData("LOGICAL_TRX_NUMBER", logicalTrxNbr.trim());
		twu.addSupplementalData("ORIGINATING_KEY", originatingKey.trim());
		twu.addSupplementalData("SOURCE_SYSTEM_NAME", sourceSystemName.trim());
		twu.addSupplementalData("TARGET_SYSTEM_NAME", targetSystemName.trim());
		
		return twu;
	}
	
	public Class<CmSalesforceInterfacePremiseInboundBatchWorker> getThreadWorkerClass() {
		return CmSalesforceInterfacePremiseInboundBatchWorker.class;
	}

	public static class CmSalesforceInterfacePremiseInboundBatchWorker extends
			CmSalesforceInterfacePremiseInboundBatchWorker_Gen {

		// Soft Parameter
		private String parmInterfaceName;
		private NotificationUploadExtensionType parmSalesForceNTUploadType;
		private NotificationExternalId parmSalesForceExternalSystem;
		private ToDoType parmAddPremiseTDType;
		private Role parmAddPremiseRole;
		private ToDoType parmAddPremiseAndServicePointTDType;
		private Role parmAddPremiseAndServicePointRole;
		// START ADD - JHERNA - 2017-07-12 - SysAid#201312
		private CharacteristicType parmCharTypePremiseNotes;
		// END ADD - JHERNA - 2017-07-12 - SysAid#201312
		// base provided soft parameter
		private int maxErrors;
		
		// Variables
		private String addressStreet;		
		private String buildingMeter;
		private String builderName;
		private String builderPhone;
		private String creationDate;
		private String createdBy;
		private String city;
		private String houseNumber;
		private String load;
		private String lotNumber;
		private String meterLocation;
		private String opportunityID;
		private String sfOpportunityGroup;
		private String sfOpportunityType;
		private String addressPrefix;
		@SuppressWarnings("unused")
		private String premiseKey;
		private String premiseType;
		private String deliveryPressure;
		private String region;
		private String salesRepPhone;
		private String rate;
		private String subDivisionName;
		private String addressSuffix;
		private String spType;
		private String state;
		private String workOrderNumber;
		private String srNumber;
		private String premiseNotes;
		private String zipPostalCode;	
		@SuppressWarnings("unused")
		private String tranSeq;
		private String trxType;
		private DateTime processDttm;
		private int errorCount;
		// START ADD - SMiranda - 2018-08-16 - SA-251520A
		private String parentPremId;
		private String ciacMoCharge;
		private String ciacTotCost;
		private String ciacTermInMo;
		private String bldrBuildStage;
		private String bldrDueDate;
		// END ADD - SMiranda - 2018-08-16 - SA-251520A
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
			
			// Retrieve Parameter 10: SalesForce Interface Name
			parmInterfaceName = this.getParameters().getINTERFACE_NAME();
			// Retrieve Parameter 20: SalesForce NT Upload Type
			parmSalesForceNTUploadType = this.getParameters().getSF_ADD_PREM_SP_NT_UPLOAD_TYPE();
			// Retrieve Parameter 30: SalesForce External System
			parmSalesForceExternalSystem = this.getParameters().getSF_EXTERNAL_SYSTEM();
			// Retrieve Parameter 40: Add Premise To Do Type
			parmAddPremiseTDType = this.getParameters().getSF_ADD_PREM_TD_TYPE();
			// Retrieve Parameter 50: Add Premise Role
			parmAddPremiseRole = this.getParameters().getSF_ADD_PREM_TD_ROLE();
			// Validate Role is valid for To Do Type
			cmValidateRoleForToDoType(parmAddPremiseTDType, parmAddPremiseRole);
			// Retrieve Parameter 60: Add Premise and SP To Do Type
			parmAddPremiseAndServicePointTDType = this.getParameters().getSF_ADD_PREM_SP_TD_TYPE();
			// Retrieve Parameter 70: Add Premise and SP Role
			parmAddPremiseAndServicePointRole = this.getParameters().getSF_ADD_PREM_SP_TD_ROLE();
			// Validate Role is valid for To Do Type
			cmValidateRoleForToDoType(parmAddPremiseAndServicePointTDType, parmAddPremiseAndServicePointRole);
			// store the process date time
			processDttm = this.getProcessDateTime();
			// retrieve Max Errors base parameter
			maxErrors = this.getParameters().getSoftMaxErrors().intValue();
			// Initialize Error Count
			errorCount = 0;		
			// START ADD - JHERNA - 2017-07-12 - SysAid#201312
			parmCharTypePremiseNotes = this.getParameters().getCHAR_TYPE_PREM_NOTES();
			cmValidateCharType(parmCharTypePremiseNotes, CharacteristicEntityLookup.constants.NOTIFICATION_UPLOAD, "Char Type for Premise Notes");
			// END ADD - JHERNA - 2017-07-12 - SysAid#201312
		}

		// START ADD - JHERNA - 2017-07-12 - SysAid#201312		
		private void cmValidateCharType(CharacteristicType charType, CharacteristicEntityLookup entity, String parmDescr) {
			
			CharacteristicEntity_Id charEntityID = new CharacteristicEntity_Id(charType, entity);
			if (isNull(charEntityID.getEntity())) {
				addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharTypeForEntity(
						parmDescr, 
						charType.getId().getTrimmedValue(),
						entity.getLookupValue().fetchLanguageDescription().trim()));
			}
		}
		// END ADD - JHERNA - 2017-07-12 - SysAid#201312
		
		private void cmValidateRoleForToDoType(ToDoType tdType, Role role) {
			
			ToDoTypeRole_Id tdTypeRoleID = new ToDoTypeRole_Id(tdType.getId(), role.getId());
			if (isNull(tdTypeRoleID.getEntity())) {
				addError(CustomMessageRepositoryMGE.commBatchParameterToDoRoleNotValidForParameterToDoType(
						this.getBatchControlId().getTrimmedValue(), 
						role.getId().getTrimmedValue(), tdType.getId().getTrimmedValue()));
			}
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			// Retrieve Data from Main SQL			
			CmInboundStaging_Id stagingID = (CmInboundStaging_Id) unit.getPrimaryId();
			//DateTime creationDttm = (DateTime) unit.getSupplementallData("CREATION_DATETIME");
			//DateTime updateDttm = (DateTime) unit.getSupplementallData("UPDATE_DATETIME");
			String logicalTrxNbr = (String) unit.getSupplementallData("LOGICAL_TRX_NUMBER");
			//String originatingKey = (String) unit.getSupplementallData("ORIGINATING_KEY");
			//String sourceSystemName = (String) unit.getSupplementallData("SOURCE_SYSTEM_NAME");
			//String targetSystemName = (String) unit.getSupplementallData("TARGET_SYSTEM_NAME");
			
			// Update the interface inbound staging record to in progress
			cmUpdateInboundInterfaceStagingStatus(
					stagingID.getStagingKey().trim()
					, CmInterfaceStatusLookup.constants.IN_PROGRESS
					, processDttm);
			
			try {
				// Retrieve data from premise inbound staging table
				cmRetrieveDataFromPremiseInboundStaging(logicalTrxNbr);
				// START CHANGE - SMiran - 2018-08-16 - SA-251520A


				// Validate Opportunity ID
				cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "OPPTY_ID", opportunityID);
				// Validate Transaction Type
				cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "TRX_TYPE", trxType);








				// Valdiate Address Street
				cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "ADDR_STREET", addressStreet);


				// Validate City
				cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "ADDR_CITY", city);
				// Validate State
				cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "ADDR_STATE", state);
				// Validate Postal Code
				cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "ADDR_POSTAL_CODE", zipPostalCode);
				// Validate Premise Type
				cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "PREMISE_TYPE", premiseType);






				// Validate Creation Date
				cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "CREATED_DATE", creationDate);
				// Validate Subdivision Name
				cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "SUBDIV_NAME", subDivisionName);
				// Validate the following fields are supplied for:
				// 1. For a Premise not covered by a CIAC agreement
				// 2. For a Physical premise covered by a CIAC agreement
				if (!premiseType.trim().toUpperCase().equals("VIRTUAL")){
					// If any of the data above are not populated / null / blank, then log an error for this record and skip to the next record
					// Validate Opportunity ID
					//cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "OPPTY_ID", opportunityID);
					// Validate Transaction Type
					//cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "TRX_TYPE", trxType);
					// Validate Builder name
					cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "BUILDER_NAME", builderName);
					// validate Builder Phone
					cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "BUILDER_PHONE", builderPhone);
					// Validate House Number
					cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "ADDR_HSE_NO", houseNumber);
					// Valdiate Address Prefix -- OPTIONAL
					//cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "ADDR_PREFIX", addressPrefix);
					// Valdiate Address Street
					//cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "ADDR_STREET", addressStreet);
					// Valdiate Address Suffix
					cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "ADDR_SFX", addressSuffix);
					// Validate City
					//cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "ADDR_CITY", city);
					// Validate State
					//cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "ADDR_STATE", state);
					// Validate Postal Code
					//cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "ADDR_POSTAL_CODE", zipPostalCode);
					// Validate Premise Type
					//cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "PREMISE_TYPE", premiseType);
					// Validate Region
					cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "REGION", region);	
					// Validate Created By / Sales Representative Name
					cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "CREATED_BY", createdBy);
					// Validate Sales Representative Phone
					cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "REP_PHONE", salesRepPhone);
					// Validate Creation Date
					//cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "CREATED_DATE", creationDate);
					// Validate Subdivision Name
					//cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "SUBDIV_NAME", subDivisionName);
					// Validate Lot Number -- OPTIONAL
					//cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "LOT_NUMBER", lotNumber);
					// Validate Load
					cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "LOAD", load);
				}
				if (premiseType.trim().toUpperCase().equals("VIRTUAL")){
					// Validate CIAC Total Cost
					cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "CIAC_TOT_COST", ciacTotCost);
					// Validate CIAC Terms in months
					cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "CIAC_TRM_IN_MO", ciacTermInMo);
					// Validate CIAC Monthly Charge
					cmValidateStagingFields(stagingID.getStagingKey(), logicalTrxNbr, "XXL_INT_PREM_IN_STG", "CIAC_MO_CHARGE", ciacMoCharge);
				}
				// END CHANGE - SMiran - 2018-08-16 - SA-251520A	
				
				// Create Notification Upload record
				NotificationUpload ntUpload = cmCreateNTUpload();
				
				// Create Notification Upload Contexts
				cmAddDetails(ntUpload);

				// create collection of sort keys
				List<String> collSortKeyValues = new ArrayList<String>();
				collSortKeyValues.add(ntUpload.getId().getIdValue().toString().trim());
				
				// create collection of drill keys
				List<String> collDrillKeyValues = new ArrayList<String>();
				collDrillKeyValues.add(ntUpload.getId().getIdValue().toString().trim());
				
				// Create a To Do Entry
				cmCreateToDo(collSortKeyValues, collDrillKeyValues);
				
			}
			catch (ApplicationError e) {
				addError(CustomMessageRepositoryMGE.commXxlInterfaceGenericError(
						stagingID.getStagingKey().trim(), logicalTrxNbr.trim(), e.getServerMessage().getMessageText()));
			}
			catch (Exception e) {
				e.printStackTrace();				
				String errorMessage = e.getMessage();
				if (isBlankOrNull(errorMessage)) {
					errorMessage = "Exception encountered while processing staging id '"
							+stagingID.getStagingKey().trim()
							+"'  of XXL_INT_INBOUND_STG. See  batch logs for details.";
				}
				addError(CustomMessageRepositoryMGE.commXxlInterfaceGenericError(
						stagingID.getStagingKey().trim(), logicalTrxNbr.trim(), 
						errorMessage));
			}

			// Update the interface in bound staging record to complete
			cmUpdateInboundInterfaceStagingStatus(
					stagingID.getStagingKey().trim()
					, CmInterfaceStatusLookup.constants.COMPLETE
					, processDttm);
			
			return true;
		}
		
		private void cmRetrieveDataFromPremiseInboundStaging(String logicalTrxNbr) {
			
			// START ADD - SMiranda - 2018-08-16 - SA-251520A
			initializeVariables();
			// END ADD - SMiranda - 2018-08-16 - SA-251520A
			
			StringBuilder stringBuilder = new StringBuilder();				
			stringBuilder.append("SELECT TRANSEQ, PREM_KEY, OPPTY_ID, WO_NUM, TRX_TYPE, "); 
			stringBuilder.append("	BUILDER_NAME, BUILDER_PHONE, ADDR_HSE_NO,  ");
			stringBuilder.append("	ADDR_PREFIX, ADDR_STREET, ADDR_SFX, ADDR_CITY, ");
			stringBuilder.append("	ADDR_STATE, ADDR_POSTAL_CODE, PREMISE_TYPE, ");
			stringBuilder.append("	REGION, CREATED_BY, REP_PHONE, CREATED_DATE, "); 
			stringBuilder.append("	SUBDIV_NAME, LOT_NUMBER, LOAD, DELIVERY_PRESSURE, ");
			stringBuilder.append("	RATE, SF_OPPTY_TYPE, SF_OPPTY_GROUP, "); 
			stringBuilder.append("	BUILDING_METER, SP_TYPE, MTR_LOCATION, SR_NUM, PREM_NOTES ");
			// START ADD - SMiranda - 2018-08-16 - SA-251520A
			//stringBuilder.append("	, NVL(PRNT_PREM_ID, ' ') PRNT_PREM_ID ");
			//stringBuilder.append("	, TO_CHAR(NVL(CIAC_MO_CHARGE, 0)) CIAC_MO_CHARGE ");
			//stringBuilder.append("	, TO_CHAR(NVL(CIAC_TOT_COST, 0)) CIAC_TOT_COST ");
			//stringBuilder.append("	, TO_CHAR(NVL(CIAC_TRM_IN_MO, 0)) CIAC_TRM_IN_MO ");
			//stringBuilder.append("	, NVL(BLDR_BUILD_STAGE, ' ') BLDR_BUILD_STAGE ");
			stringBuilder.append("	, PRNT_PREM_ID ");
			stringBuilder.append("	, CIAC_MO_CHARGE ");
			stringBuilder.append("	, CIAC_TOT_COST ");
			stringBuilder.append("	, CIAC_TRM_IN_MO ");
			stringBuilder.append("	, BLDR_BUILD_STAGE ");
			stringBuilder.append("	, BLDR_DUE_DATE ");
			// END ADD - SMiranda - 2018-08-16 - SA-251520A
			stringBuilder.append("FROM XXL_INT_PREM_IN_STG ");
			stringBuilder.append("WHERE LOGICAL_TRX_NUMBER = :logicalTrxNbr ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), 
					"=RETRIEVE DATA FROM XXL_INT_PREM_IN_STG=");
			prepState.bindString("logicalTrxNbr", logicalTrxNbr.trim(), "LOGICAL_TRX_NUMBER");
			prepState.execute();
			
			if (prepState.list().size() > 0) {
				
				SQLResultRow sqlRow = prepState.firstRow();
				tranSeq = (String) sqlRow.getString("TRANSEQ");
				premiseKey = (String) sqlRow.getString("PREM_KEY");
				opportunityID = (String) sqlRow.getString("OPPTY_ID");
				workOrderNumber = (String) sqlRow.getString("WO_NUM");
				trxType = (String) sqlRow.getString("TRX_TYPE");
				builderName = (String) sqlRow.getString("BUILDER_NAME");
				builderPhone = (String) sqlRow.getString("BUILDER_PHONE");
				houseNumber = (String) sqlRow.getString("ADDR_HSE_NO");
				addressPrefix = (String) sqlRow.getString("ADDR_PREFIX");
				addressStreet = (String) sqlRow.getString("ADDR_STREET");
				addressSuffix = (String) sqlRow.getString("ADDR_SFX");
				city = (String) sqlRow.getString("ADDR_CITY");
				state = (String) sqlRow.getString("ADDR_STATE");
				zipPostalCode = (String) sqlRow.getString("ADDR_POSTAL_CODE");
				premiseType = (String) sqlRow.getString("PREMISE_TYPE");
				region = (String) sqlRow.getString("REGION");
				createdBy = (String) sqlRow.getString("CREATED_BY");
				salesRepPhone = (String) sqlRow.getString("REP_PHONE");
				creationDate = (String) sqlRow.getString("CREATED_DATE");
				subDivisionName = (String) sqlRow.getString("SUBDIV_NAME");
				lotNumber = (String) sqlRow.getString("LOT_NUMBER");
				load = (String) sqlRow.getString("LOAD");
				deliveryPressure = (String) sqlRow.getString("DELIVERY_PRESSURE");
				rate = (String) sqlRow.getString("RATE");
				sfOpportunityType = (String) sqlRow.getString("SF_OPPTY_TYPE");
				sfOpportunityGroup = (String) sqlRow.getString("SF_OPPTY_GROUP");
				buildingMeter = (String) sqlRow.getString("BUILDING_METER");
				spType = (String) sqlRow.getString("SP_TYPE");
				meterLocation = (String) sqlRow.getString("MTR_LOCATION");
				srNumber = (String) sqlRow.getString("SR_NUM");
				premiseNotes = (String) sqlRow.getString("PREM_NOTES");
				// START ADD - SMiranda - 2018-08-16 - SA-251520A
				/*
				parentPremId = (String) sqlRow.getString("PRNT_PREM_ID").trim();
				ciacMoCharge = (String) sqlRow.getString("CIAC_MO_CHARGE").trim();
				if (ciacMoCharge.equals("0")){
					ciacMoCharge = "";
				}
				ciacTotCost = (String) sqlRow.getString("CIAC_TOT_COST").trim();
				if (ciacTotCost.equals("0")){
					ciacTotCost = "";
				}
				ciacTermInMo = (String) sqlRow.getString("CIAC_TRM_IN_MO").trim();
				if (ciacTermInMo.equals("0")){
					ciacTermInMo = "";
				}
				bldrBuildStage = (String) sqlRow.getString("BLDR_BUILD_STAGE").trim();
				*/
				if (notNull(sqlRow.getString("PRNT_PREM_ID"))){
					parentPremId = sqlRow.getString("PRNT_PREM_ID").trim();
				}
				if (notNull(sqlRow.getBigDecimal("CIAC_MO_CHARGE"))){
					ciacMoCharge = sqlRow.getBigDecimal("CIAC_MO_CHARGE").toString();
				}
				if (notNull(sqlRow.getBigDecimal("CIAC_TOT_COST"))){
					ciacTotCost = sqlRow.getBigDecimal("CIAC_TOT_COST").toString();
				}
				if (notNull(sqlRow.getBigDecimal("CIAC_TRM_IN_MO"))){
					ciacTermInMo = sqlRow.getBigDecimal("CIAC_TRM_IN_MO").toString();
				}
				if (notNull(sqlRow.getString("BLDR_BUILD_STAGE"))){
					bldrBuildStage = sqlRow.getString("BLDR_BUILD_STAGE").trim();
				}
				if (notNull(sqlRow.getDate("BLDR_DUE_DATE"))){
					bldrDueDate = sqlRow.getDate("BLDR_DUE_DATE").toString();
				}
				// END ADD - SMiranda - 2018-08-16 - SA-251520A
			}
			
			prepState.close();											
		}
		
		
		// START ADD - SMiranda - 2018-08-16 - SA-251520A
		private void initializeVariables(){
			
			parentPremId = "";
			ciacMoCharge = "";
			ciacTotCost = "";
			ciacTermInMo = "";
			bldrBuildStage = "";
			bldrDueDate = "";
			
		}
		// END ADD - SMiranda - 2018-08-16 - SA-251520A
		
		private void cmValidateStagingFields(String stagingKey, String logicalTrxNbr, String tableName, String fieldName, String fieldValue) {
			
			if (isBlankOrNull(fieldValue)) {
				addError(CustomMessageRepositoryMGE.commXxlInterfaceTableFieldIsMissing(stagingKey.trim(), 
						logicalTrxNbr.trim(), tableName.trim(), fieldName.trim()));
			}			
		}
		
		private NotificationUpload cmCreateNTUpload() {
			
			NotificationUpload returnValue = null;
			NotificationUpload_DTO ntUpDTO = new NotificationUpload_DTO();
			ntUpDTO.setCreationDateTime(processDttm);
			ntUpDTO.setNotificationExternalId(parmSalesForceExternalSystem.getId());
			ntUpDTO.setNotificationStatus(NotificationUploadStatusLookup.constants.PENDING);
			ntUpDTO.setNotificationUploadTypeId(parmSalesForceNTUploadType.getId());
			ntUpDTO.setNotificationUploadExtension(NotificationUploadExtensionLookup.constants.SAMPLE_EXTENSION_RECORD);
			returnValue = ntUpDTO.newEntity();
			return returnValue;			
		}
		
		private void cmAddDetails(NotificationUpload ntUpload) {
			
			// Opportunity ID
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.OPPTY_ID, opportunityID.trim());
			// Work Order Number
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.WO_NUM, workOrderNumber);
			// SR Number
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.SR_NUMBER, srNumber);
			// Premise Notes
			// START CHANGE- JHERNA - 2017-07-12 - SysAid#201312
			//cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.PREMISE_NOTE, premiseNotes);
			cmCreateNTUploadCharacteristics(ntUpload, parmCharTypePremiseNotes, premiseNotes);
			// END CHANGE - JHERNA - 2017-07-12 - SysAid#201312
			// Builder Name
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.BUILDER_NAME, builderName);
			// Builder Phone
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.BUILDER_PHONE, builderPhone);
			// House Number
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.HOUSE_NUM, houseNumber);
			// Address Prefix
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.ADDRESS_PREFIX, addressPrefix);
			// START ADD - SMiranda - 2018-08-16 - SA-251520A
			// If premise type is Virtual, format Street name to CIAC + <Subdivision Name>
			if (premiseType.trim().toUpperCase().equals("VIRTUAL")){
				addressStreet = "CIAC " + subDivisionName;  
			}
			// END ADD - SMiranda - 2018-08-16 - SA-251520A
			// Address Street
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.ADDRESS_STREET, addressStreet);
			// Address Suffix
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.ADDRESS_SUFFIX, addressSuffix);
			// City
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.CITY, city);
			// State
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.STATE, state);
			// Zip Postal Code
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.ZIP_CODE, zipPostalCode);
			// Premise Type
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.PREMISE_TYPE, premiseType);
			// Region
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.REGION, region);
			// Created By
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.CREATED_BY, createdBy);
			// Representative Phone
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.SALES_REP_PHONE, salesRepPhone);
			// Created Date
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.CREATE_DATE, creationDate);
			// Subdivision Name
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.SUB_DIVISION_NAME, subDivisionName);
			// Lot Number
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.LOT_NUMBER, lotNumber);
			// Load	
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.LOAD, load);
			// Delivery Pressure
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.DELIVERY_PRESSURE, deliveryPressure);
			// Rate
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.RATE, rate);
			// SalesForce Opportunity Type
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.OPPORTUNITY_TYPE, sfOpportunityType);
			// SalesForce Opportunity Group
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.OPPORTUNITY_GROUP, sfOpportunityGroup);
			// Building meter
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.BUILDING_METER, buildingMeter);
			// SP Type
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.SP_TYPE, spType);
			// Meter Location
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.METER_LOCATION, meterLocation);
			// START ADD - SMiranda - 2018-08-16 - SA-251520A
			// Transaction Type
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.TRANSACTION_TYPE, trxType);
			// Parent Premise ID
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.PARENT_PREMISE_I_D, parentPremId);
			// Building Stage
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.BUILDER_BUILD_STAGE, bldrBuildStage);
			// Due Date
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.BUILDER_DUE_DATE, bldrDueDate);
			// CIAC Total Cost
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.CIAC_TOTAL_COST, ciacTotCost);
			// CIAC Terms (in Months)
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.CIAC_TERMS, ciacTermInMo);
			// CIAC Monthly Charge
			cmCreateNTUploadContext(ntUpload, NotificationUploadContextLookup.constants.CIAC_MONTHLY_CHARGE, ciacMoCharge);
			// END ADD - SMiranda - 2018-08-16 - SA-251520A
			
		}
		
		private void cmCreateNTUploadContext(NotificationUpload ntUpload, 
				NotificationUploadContextLookup notificationContextType,
				String contextValue) {
			
			if (notBlank(contextValue)) {
				
				NotificationUploadContext_Id ntUpCtxtID = new NotificationUploadContext_Id(
						ntUpload, notificationContextType, contextValue);
				NotificationUploadContext_DTO ntUpCtxtDTO = new NotificationUploadContext_DTO();
				ntUpCtxtDTO.setId(ntUpCtxtID);
				ntUpCtxtDTO.newEntity();		
			}	
		}
		
		// START ADD - JHERNA - 2017-07-12 - SysAid#201312
		private void cmCreateNTUploadCharacteristics(NotificationUpload ntUpload,
				CharacteristicType charType,
				String charValue) {
			
			if (notBlank(charValue)) {				
				charValue = charValue.trim();
				BigInteger seqNbr = BigInteger.ONE;
				
				/*Entire characteristic value needs to be stored using multiple instance because it is too long for one characteristic*/
				if (charValue.length() > 250) {										
					for (int startPos = 0; startPos <= charValue.length(); startPos = startPos + 249) {
					
						int endPos = startPos + 249;
						if (endPos > charValue.length()) {
							endPos = charValue.length();
						}
						String resultingCharVal = charValue.substring(startPos, endPos);
						addCharToNtUploadRecord(ntUpload, charType, seqNbr, resultingCharVal);
						seqNbr = seqNbr.add(BigInteger.ONE);
					}
				}
				/*Entire characteristic value can be stored on a single characteristic (length is <= 250)*/
				else {
					addCharToNtUploadRecord(ntUpload, charType, seqNbr, charValue);
				}				
			}
		}
		
		private void addCharToNtUploadRecord(NotificationUpload ntUpload, 
				CharacteristicType charType, 
				BigInteger seqNbr, 
				String resultingCharVal) {
			
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			NotificationUploadCharacteristic_DTO ntUploadCharDTO = new NotificationUploadCharacteristic_DTO();
			NotificationUploadCharacteristic_Id ntUploadCharID = new NotificationUploadCharacteristic_Id(ntUpload, charType, seqNbr);
			if (charTypeLookup.isAdhocValue()
					|| charTypeLookup.isFileLocationValue()) {
				ntUploadCharDTO.setAdhocCharacteristicValue(resultingCharVal);
			}
			else if (charTypeLookup.isPredefinedValue()) {
				ntUploadCharDTO.setCharacteristicValue(resultingCharVal);
			}
			else {
				ntUploadCharDTO.setCharacteristicValueForeignKey1(resultingCharVal);
			}
			ntUploadCharDTO.setId(ntUploadCharID);
			ntUploadCharDTO.newEntity();
		}
		// END ADD - JHERNA - 2017-07-12 - SysAid#201312
		
		private void cmCreateToDo(List<String> collSortKeyValues, List<String> collDrillKeyValues) {
			
			ToDoType_Id tdTypeID = null;
			Role_Id tdRoleID = null;
			Message_Id msgID = null;
			
			// START CHANGES - JHERNA - 2018-07-13 - SysAid#201309
			if (trxType.trim().compareTo("PREM") == 0) {
				
				tdTypeID = parmAddPremiseTDType.getId();
				tdRoleID = parmAddPremiseRole.getId();
				//msgID = CustomMessageRepositoryMGE.sfReqCreatePremise().getMessageId();
				msgID = CustomMessageRepositoryMGE.sfReqCreatePremise(city, region, createdBy).getMessageId();
			}
			else {
				
				tdTypeID = parmAddPremiseAndServicePointTDType.getId();
				tdRoleID = parmAddPremiseAndServicePointRole.getId();
				//msgID = CustomMessageRepositoryMGE.sfReqCreatePremiseAndSP().getMessageId();
				msgID = CustomMessageRepositoryMGE.sfReqCreatePremiseAndSP(city, region, createdBy).getMessageId();
			}
			// END CHANGES - JHERNA - 2018-07-13 - SysAid#201309
			
			ToDoCreator tdCreator = ToDoCreator.Factory.newInstance();
			ToDoEntry_DTO tdEntryDTO = tdCreator.getToDoDTO();
			tdEntryDTO.setCreationDateTime(processDttm);
			tdEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
			tdEntryDTO.setToDoTypeId(tdTypeID);
			tdEntryDTO.setToDoRoleId(tdRoleID);
			tdEntryDTO.setBatchControlId(this.getBatchControlId());
			tdEntryDTO.setBatchNumber(this.getBatchNumber());
			tdEntryDTO.setMessageId(msgID);
			tdCreator.setToDoDTO(tdEntryDTO);
			//---------set message parameter---------//
			
			List<ToDoSortKeyType> collOfSortKeyTypes = cmGetSortKeyTypes(tdTypeID);
			
			for (int x = 0; x < collOfSortKeyTypes.size(); x++) {
				
				ToDoSortKeyType tdSortKeyType = collOfSortKeyTypes.get(x);
				tdCreator.addSortKeyValue(tdSortKeyType, collSortKeyValues.get(x));
			}
			
			List<ToDoDrillKeyType> collOfDrillKeyTypes = cmGetDrillKeyTypes(tdTypeID);
			
			for (int x = 0; x < collOfDrillKeyTypes.size(); x++) {
				
				ToDoDrillKeyType tdDrillKeyType = collOfDrillKeyTypes.get(x);
				tdCreator.addDrillKeyValue(tdDrillKeyType, collDrillKeyValues.get(x));				
			}
			
			// START ADD - JHERNA - 2018-07-13 - SysAid#201309
			tdCreator.addMessageParameter(city);
			tdCreator.addMessageParameter(region);
			tdCreator.addMessageParameter(createdBy);
			// END ADD - JHERNA - 2018-07-13 - SysAid#201309
			
			@SuppressWarnings("unused")
			ToDoEntry tdEntry = tdCreator.create();			
			
		}
		
		private List<ToDoSortKeyType> cmGetSortKeyTypes(ToDoType_Id tdTypeID) {
			
			List<ToDoSortKeyType> returnValue = new ArrayList<ToDoSortKeyType>();
			
			StringBuilder stringBuilder = new StringBuilder();					
			stringBuilder.append("SELECT TD_TYPE_CD, SEQ_NUM ");
			stringBuilder.append("FROM CI_TD_SRTKEY_TY ");
			stringBuilder.append("WHERE TD_TYPE_CD = :tdTypeID ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=GET TO DO TYPE SORT KEYS");
			prepState.bindId("tdTypeID", tdTypeID);
			prepState.execute();
			
			if (prepState.list().size() > 0) {
				
				Iterator<SQLResultRow> iter = prepState.list().iterator();
				
				while (iter.hasNext()) {
				
					SQLResultRow sqlRow = (SQLResultRow) iter.next();					
					BigInteger seq = (BigInteger) sqlRow.getInteger("SEQ_NUM");
					ToDoSortKeyType_Id tdSortKeyTypeID = new ToDoSortKeyType_Id(tdTypeID, seq);
					returnValue.add(tdSortKeyTypeID.getEntity());
				}								
			}			
			prepState.close();
			return returnValue;
		}
		
		private List<ToDoDrillKeyType> cmGetDrillKeyTypes(ToDoType_Id tdTypeID) {
			
			List<ToDoDrillKeyType> returnValue = new ArrayList<ToDoDrillKeyType>();
			
			StringBuilder stringBuilder = new StringBuilder();					
			stringBuilder.append("SELECT TD_TYPE_CD, SEQ_NUM ");
			stringBuilder.append("FROM CI_TD_DRLKEY_TY ");
			stringBuilder.append("WHERE TD_TYPE_CD = :tdTypeID ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=GET TO DO TYPE DRILL KEYS=");
			prepState.bindId("tdTypeID", tdTypeID);
			prepState.execute();
			
			if (prepState.list().size() > 0) {
				
				Iterator<SQLResultRow> iter = prepState.list().iterator();
				
				while (iter.hasNext()) {
				
					SQLResultRow sqlRow = (SQLResultRow) iter.next();
					BigInteger seq = (BigInteger) sqlRow.getInteger("SEQ_NUM");
					ToDoDrillKeyType_Id tdDrillKeyTypeID = new ToDoDrillKeyType_Id(tdTypeID, seq);
					returnValue.add(tdDrillKeyTypeID.getEntity());
				}								
			}			
			prepState.close();
			return returnValue;
			
		}
		
		private void cmUpdateInboundInterfaceStagingStatus(String stagingID, 
				CmInterfaceStatusLookup statusFlag,
				DateTime updateDttm) {
			
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("UPDATE XXL_INT_INBOUND_STG ");
			stringBuilder.append("SET STATUS_FLAG = :statusFlag , ");
			stringBuilder.append("    UPDATE_DATETIME = :updateDttm ");
			stringBuilder.append("WHERE STAGING_KEY = :stagingKey ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(),
					"=UPDATE INTERFACE INBOUND STAGING RECORD=");
			prepState.bindString("statusFlag", statusFlag.trimmedValue(), "STATUS_FLAG");
			prepState.bindDateTime("updateDttm", updateDttm);
			prepState.bindString("stagingKey", stagingID, "STAGING_KEY");
			prepState.execute();
			prepState.close();
		}

		@Override
		public boolean handleApplicationError(ApplicationError ae,
				ThreadWorkUnit unit) {
			
			errorCount++;
			if (errorCount > maxErrors){
				throw new RunAbortedException(CustomMessageRepositoryMGE.commMaxErrorLimitExceeded(String.valueOf(maxErrors)));
			}
			
			CmInboundStaging_Id stagingID = (CmInboundStaging_Id) unit.getPrimaryId();
			String logicalTrxNbr = (String) unit.getSupplementallData("LOGICAL_TRX_NUMBER");			
			DateTime creationDttm = (DateTime) unit.getSupplementallData("CREATION_DATETIME");
			String originatingKey = (String) unit.getSupplementallData("ORIGINATING_KEY");
			String sourceSystemName = (String) unit.getSupplementallData("SOURCE_SYSTEM_NAME");
			String targetSystemName = (String) unit.getSupplementallData("TARGET_SYSTEM_NAME");
			String stagingKey = stagingID.getStagingKey();
			DateTime updateDttm = this.getProcessDateTime();			
			
			// Update interface inbound staging record to error status
			cmUpdateInboundInterfaceStagingStatus(stagingKey,
					CmInterfaceStatusLookup.constants.ERROR,
					updateDttm);
			
			// Retrieve details of the error encountered.
			String errorCategory = " ";
			String errorNumber = " ";
			String errorCode = " ";
			String errorDescription = " ";
			String additionalInfo = " ";
			if(notNull(ae)){
				ServerMessage serverMessage = ae.getServerMessage();
				if(notNull(serverMessage)){
					errorCategory = serverMessage.getCategory().toString().trim();
					errorNumber = serverMessage.getNumber().toString().trim();
					errorCode = errorCategory.concat("-").concat(errorNumber);
					errorDescription = serverMessage.getMessageText().trim();
					if (serverMessage.getLongDescription().length() > 0){
						if (serverMessage.getLongDescription().length() > 200){
							additionalInfo = serverMessage.getLongDescription().substring(0, 200);
						}else{
							additionalInfo = serverMessage.getLongDescription();
						}
					}					
				}
			}
						
			// Create Interface Error Log
			CmInterfaceErrorLogMaintenance intErrorLog = CmInterfaceErrorLogMaintenance.Factory.newInstance();
			intErrorLog.createInterfaceErrorLog(sourceSystemName,
					targetSystemName,
					logicalTrxNbr, 
					"XXL_INT_PREM_IN_STG", 
					parmInterfaceName, 
					errorCode, 
					errorDescription, 
					creationDttm, 
					updateDttm, 
					targetSystemName, 
					originatingKey, 
					additionalInfo, 
					sourceSystemName, 
					" ", " ", " ", " ", " ", " ", " ", " ", " ", " ");
			
			return true;					
		}		
	}	
}
