/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * CCB030.3 - This batch process reads and uploads payment return files 
 * from Fiserv for Spire Gulf. It will read the inbound file and load the
 * records into the payment upload staging table (for payments) and
 * notification upload staging table (for returns). 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:      		Reason:
 * YYYY-MM-DD   IN       		Reason text.
 * 2021-04-07   PCayab  		CCB030.3. Initial Version    
 * 2021-06-25   NMendo          CCB030.Issue3. Move declaration of soft parameters
 *                              inside the worker class.
 * 2021-07-12	JMeden			CCB030.Issue4. Default Payment Time if the
 * 								value from the file is blank 
 * 2021-09-17   NMendo          Defect 4595996. Added default payment batch 
 *                              number parameter.
 * 2025-11-14   EQuint      	CCB25.4 Upgrade
 **************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.lookup.NotificationUploadContextLookup;
import com.splwg.base.api.lookup.NotificationUploadExtensionLookup;
import com.splwg.base.api.lookup.NotificationUploadStatusLookup;
import com.splwg.base.domain.workflow.notificationExternalId.NotificationExternalId_Id;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadContext_DTO;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadContext_Id;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload_DTO;
import com.splwg.base.domain.workflow.notificationUploadExtensionType.NotificationUploadExtensionType;
import com.splwg.ccb.api.lookup.DepositControlStagingStatusLookup;
import com.splwg.ccb.api.lookup.PaymentTenderStagingStatusLookup;
import com.splwg.ccb.api.lookup.TenderControlStatusLookup;
import com.splwg.ccb.domain.admin.paymentCancelReason.entity.PaymentCancelReason_Id;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource;
import com.splwg.ccb.domain.admin.tenderType.entity.TenderType;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging_Id;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging_Id;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentTenderUpload_DTO;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentTenderUpload_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author PCayab
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules={},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = EXTERNAL_ID, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = notificationUploadExtensionType, name = NOTIFICATION_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = ACCT_ID_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = AMT_PAID_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = RET_PAY_DT_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = RET_RSN_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (entityName = tenderSource, name = TENDER_SOURCE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = tenderType, name = TENDER_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = RETURN_REASON, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PYMT_BATCH_NBR, required = true, type = string)})
 */
public class CmFiservPaymentAndReturnsUpload_BatchProcess extends
		CmFiservPaymentAndReturnsUpload_BatchProcess_Gen {
	
	// Start Change - NMendo - CCB030.Issue3 -  2021-06-25
	//private static String parmFilePath;
	//private static String parmFileName;
	//private static File inputFile = null;
	//private static String parmExternalId;
	//private static NotificationUploadExtensionType parmNotificationType;
	//private static NotificationUploadContextLookup parmAcctIdCtxtType;
	//private static NotificationUploadContextLookup parmAmtPaidCtxtType;
	//private static NotificationUploadContextLookup parmRetPayDtCtxtType;
	//private static NotificationUploadContextLookup parmRetRsnCtxtType;
	//private static TenderSource parmTenderSource;
	//private static TenderType parmTenderType;
	//private static String parmReturnReason;
	//private static NotificationExternalId_Id notificationExternalId;
	private String parmFilePath;
	private String parmFileName;
	private String parmExternalId;
	private String parmReturnReason;
	private NotificationExternalId_Id notificationExternalId;
	// End Change - NMendo - CCB030.Issue3 -  2021-06-25
	
	@Override
	public JobWork getJobWork() {
		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit workUnit = new ThreadWorkUnit();
        workUnits.add(workUnit);
        return createJobWorkForThreadWorkUnitList(workUnits);

	}

	/**
	 * Validate Soft Parameters
	 */
	@Override
	public void validateSoftParameters(boolean isNewRun) {
		initializeVariables();
		// Validate if the file path exists
		File folder = new File(parmFilePath.trim());
		if(!(folder.exists() && folder.isDirectory())) {
			addError(CustomMessageRepositorySpireOne.CCB030_3_batchParmInvalidFilePath("FILE_PATH", parmFilePath));
		}
		// Validate whether the file is valid
		File inputFile = new File(parmFilePath, parmFileName);
		if(!inputFile.exists() || !inputFile.canRead()){
			addError(CustomMessageRepositorySpireOne.CCB030_3_batchParmInvalidFile("FILE_NAME", parmFileName));
		} 
		
		// Validate if the External ID is a valid Notification External ID
		notificationExternalId = new NotificationExternalId_Id(parmExternalId);
		if(isNull(notificationExternalId.getEntity())){
			addError(CustomMessageRepositorySpireOne.CCB030_3_batchParmInvalidExternalSystem("EXTERNAL_ID", parmExternalId));
		}
		
		// Validate if the Return Reason is valid
		PaymentCancelReason_Id returnReasonId = new PaymentCancelReason_Id(parmReturnReason);
		if(isNull(returnReasonId.getEntity())){
			addError(CustomMessageRepositorySpireOne.CCB030_3_batchParmInvalidReturnReason("RETURN_REASON", parmReturnReason));
		}
	}
	
	/**
	 * Initialize the parameters
	 */
	private void initializeVariables(){
		parmFilePath = getParameters().getFILE_PATH().trim();
		parmFileName = getParameters().getFILE_NAME();
		parmExternalId = getParameters().getEXTERNAL_ID();
		notificationExternalId = new NotificationExternalId_Id(parmExternalId);
		parmReturnReason = getParameters().getRETURN_REASON();
		// Start Delete - NMendo - CCB030.Issue3 -  2021-06-25
		//inputFile = new File(parmFilePath, parmFileName);
		//parmNotificationType = getParameters().getNOTIFICATION_TYPE();
		//parmAcctIdCtxtType = getParameters().getACCT_ID_NT_CTXT_TYPE();
		//parmAmtPaidCtxtType = getParameters().getAMT_PAID_NT_CTXT_TYPE();
		//parmRetPayDtCtxtType = getParameters().getRET_PAY_DT_NT_CTXT_TYPE();
		//parmRetRsnCtxtType = getParameters().getRET_RSN_NT_CTXT_TYPE();
		//parmTenderSource = getParameters().getTENDER_SOURCE_CD();
		//parmTenderType = getParameters().getTENDER_TYPE_CD();
		// End Delete - NMendo - CCB030.Issue3 -  2021-06-25
	}
	
	public Class<CmFiservPaymentAndReturnsUpload_BatchProcessWorker> getThreadWorkerClass() {
		return CmFiservPaymentAndReturnsUpload_BatchProcessWorker.class;
	}

	public static class CmFiservPaymentAndReturnsUpload_BatchProcessWorker
			extends CmFiservPaymentAndReturnsUpload_BatchProcessWorker_Gen {
		
		// Start Add - NMendo - CCB030.Issue3 -  2021-06-25
		// Soft Parameters
		private String parmFilePath;
		private String parmFileName;
		private String parmExternalId;
		private NotificationUploadExtensionType parmNotificationType;
		private NotificationUploadContextLookup parmAcctIdCtxtType;
		private NotificationUploadContextLookup parmAmtPaidCtxtType;
		private NotificationUploadContextLookup parmRetPayDtCtxtType;
		private NotificationUploadContextLookup parmRetRsnCtxtType;
		private TenderSource parmTenderSource;
		private TenderType parmTenderType;
		private String parmReturnReason;
		private NotificationExternalId_Id notificationExternalId;
		// End Add - NMendo - CCB030.Issue3 -  2021-06-25
		// Start Add - NMendo - Defect 4595996 - 2021-09-17
        private String parmPaymentBatchNumber;
        // End Add - NMendo - Defect 4595996 - 2021-09-17
		
		//Work Variables
		private BufferedReader inputBufferReader = null;
		private BigInteger lineCounter = BigInteger.ZERO;
		private BigInteger totalFileRecordCount = BigInteger.ZERO;
		private BigDecimal totalPaymentsCountProcessed = BigDecimal.ZERO;
		private BigDecimal totalPaymentsAmountProcessed = BigDecimal.ZERO;
		private BigDecimal totalReturnsCountProcessed = BigDecimal.ZERO;
		private BigDecimal totalReturnsAmountProcessed = BigDecimal.ZERO;	
		private BigInteger headerCreditCount = BigInteger.ZERO;
		private BigDecimal headerCreditTotalAmount = BigDecimal.ZERO;
		private BigInteger headerDebitCount = BigInteger.ZERO;
		private BigDecimal headerDebitTotalAmount = BigDecimal.ZERO;
		private DepositControlStaging depositControlStaging;
		private TenderControlStaging tenderControlStaging;
		private NotificationUpload notificationUpload;
		private String sequenceCode;
		
		//Constants
		private static final String RECORD_TYPE_CREDIT = "C";
		private static final String RECORD_TYPE_DEBIT = "D";
		private static final String DATE_FORMAT = "MMddyyyy";
		private static final String NEW_DATE_FORMAT = "MMddyy";
		// Start Add - JMeden - CCB030.Issue4 - 2021-07-12
		private static final String DEFAULT_PAYMENT_TIME = "000000";
		// End Add - JMeden - CCB030.Issue4 - 2021-07-12
		
		//Header Record
		private static final int BUSINESS_DATE_INDEX = 10;
		private static final int BUSINESS_DATE_LENGTH = 8;
		private static final int CREDIT_LINE_COUNT_INDEX = 18;
		private static final int CREDIT_LINE_COUNT_LENGTH = 8;
		private static final int CREDIT_TOTAL_AMOUNT_INDEX = 26;
		private static final int CREDIT_TOTAL_AMOUNT_LENGTH = 12;
		private static final int DEBIT_LINE_COUNT_INDEX = 38;
		private static final int DEBIT_LINE_COUNT_LENGTH = 8;
		private static final int DEBIT_TOTAL_AMOUNT_INDEX = 46;
		private static final int DEBIT_TOTAL_AMOUNT_LENGTH = 12;
		
		//DETAIL RECORD
		private static final int ACCOUNT_NUMBER_INDEX = 2;
		private static final int ACCOUNT_NUMBER_LENGTH = 20;
		private static final int RECORD_TYPE_INDEX = 22;
		private static final int RECORD_TYPE_LENGTH = 1;
		private static final int AMOUNT_INDEX = 23;
		private static final int AMOUNT_LENGTH = 12;
		private static final int PAYMENT_DATE_INDEX = 35;
		private static final int PAYMENT_DATE_LENGTH = 8;
		private static final int PAYMENT_TIME_INDEX = 43;
		private static final int PAYMENT_TIME_LENGTH = 6;
		private static final int SEQUENCE_CODE_INDEX = 50;
		private static final int SEQUENCE_CODE_LENGTH = 8;

		public ThreadExecutionStrategy createExecutionStrategy() {
			
			return new SingleTransactionStrategy(this);
		}

		// Start Add - NMendo - CCB030.Issue3 -  2021-06-25
        @Override
        public void initializeThreadWork(
                boolean initializationPreviouslySuccessful)
                throws ThreadAbortedException, RunAbortedException {
        	// Retrieve Soft Parameters
        	parmFilePath = getParameters().getFILE_PATH().trim();
    		parmFileName = getParameters().getFILE_NAME();
    		parmExternalId = getParameters().getEXTERNAL_ID();
    		notificationExternalId = new NotificationExternalId_Id(parmExternalId);
    		parmNotificationType = getParameters().getNOTIFICATION_TYPE();
    		parmAcctIdCtxtType = getParameters().getACCT_ID_NT_CTXT_TYPE();
    		parmAmtPaidCtxtType = getParameters().getAMT_PAID_NT_CTXT_TYPE();
    		parmRetPayDtCtxtType = getParameters().getRET_PAY_DT_NT_CTXT_TYPE();
    		parmRetRsnCtxtType = getParameters().getRET_RSN_NT_CTXT_TYPE();
    		parmTenderSource = getParameters().getTENDER_SOURCE_CD();
    		parmTenderType = getParameters().getTENDER_TYPE_CD();
    		parmReturnReason = getParameters().getRETURN_REASON();
    		// Start Add - NMendo - Defect 4595996 - 2021-09-17
            parmPaymentBatchNumber = getParameters().getPYMT_BATCH_NBR().trim();
            // End Add - NMendo - Defect 4595996 - 2021-09-17
        }
		// End Add - NMendo - CCB030.Issue3 -  2021-06-25

		@Override
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit) 
				throws ThreadAbortedException, RunAbortedException{
			processFile();
			validateRecords();
			// Log Total Number of Records Processed and Total Amount of Payments and Returns Processed
			logMessage(CustomMessageRepositorySpireOne.CCB030_3_totalNumberOfRecordsProcessed("payments", totalPaymentsCountProcessed.toString().trim()), MessageSeverityLookup.constants.INFORMATIONAL);
			logMessage(CustomMessageRepositorySpireOne.CCB030_3_totalAmountOfRecordsProcessed("payments", totalPaymentsAmountProcessed.toString().trim()), MessageSeverityLookup.constants.INFORMATIONAL);
			logMessage(CustomMessageRepositorySpireOne.CCB030_3_totalNumberOfRecordsProcessed("returns", totalReturnsCountProcessed.toString().trim()), MessageSeverityLookup.constants.INFORMATIONAL);
			logMessage(CustomMessageRepositorySpireOne.CCB030_3_totalAmountOfRecordsProcessed("returns", totalReturnsAmountProcessed.toString().trim()), MessageSeverityLookup.constants.INFORMATIONAL);

			WorkUnitResult workUnitResult = new WorkUnitResult(true);
			workUnitResult.setUnitsProcessed(totalFileRecordCount.intValue());
			closeFile();
			
			return workUnitResult;
		}

		/**
		 *This method opens a buffered reader for the input file
		 */
		private void openFile() {
			  try {
				  // Start Add - NMendo - CCB030.Issue3 -  2021-06-25
				  File inputFile = new File(parmFilePath, parmFileName);
				  // End Add - NMendo - CCB030.Issue3 -  2021-06-25
				  inputBufferReader = new BufferedReader(new FileReader(inputFile));                    
			  } catch (IOException exception) {               
				  throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB030_3_ErrorInFile(exception.getMessage().trim()));
			  } 
		}
		
		/**
		 * This method closes a buffered reader for input file
		 *
		 */
		private void closeFile() {
			try {
				if(notNull(inputBufferReader)){
					inputBufferReader.close();
				}           
			}catch (IOException exception) {
				throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB030_3_ErrorInFile(exception.getMessage().trim()));                                      
			}
		} 
		  
		 /**
		  * Process the upload file
		  */
		private void processFile(){
			openFile();
			String record = null;
			while(!isNull(record = readRecord())){
				lineCounter = lineCounter.add(BigInteger.ONE);
				
				if(lineCounter.equals(BigInteger.ONE)){
					processHeaderRecord(record);				
				}else{
					totalFileRecordCount = totalFileRecordCount.add(BigInteger.ONE);
					processDetailsRecord(record);
				}
			}
		}	
		
		/**
		 * This method returns the next record from the input file.
		 * @return a String object.
		 */
		private String readRecord() {
			String record = null;
			try {
				record =  inputBufferReader.readLine();                 
			} catch (IOException exception) {
				throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB030_3_ErrorInFile(exception.getMessage().trim()));
			}  
			return record;
		}
		  
		/**
		 * This method retrieves the trimmed field value from the record starting 
		 * from the startPos and of the given length.
		 * @param record
		 * @param startPos
		 * @param length
		 * @return
		 */
		private String getFieldValue(String record, int startPos, int length) {

		   String value = "";
		   if(record.length() >= startPos+length){
			   value = record.substring(startPos, startPos+length).trim();
		   }
		   return value;
		}
		  
		/**
		 * This method will process the File Header Record.
		 * @param record
		 */
		private void processHeaderRecord(String record){
			String strBusinessDate = getFieldValue(record, BUSINESS_DATE_INDEX, BUSINESS_DATE_LENGTH);
			validateDate(strBusinessDate.trim(), "Business Date");
			
			String creditLineCount = getFieldValue(record, CREDIT_LINE_COUNT_INDEX, CREDIT_LINE_COUNT_LENGTH);
			validateNumber(creditLineCount.trim(), "Credit Line Count");
			headerCreditCount = new BigInteger(creditLineCount);
			
			String creditTotalAmount = getFieldValue(record, CREDIT_TOTAL_AMOUNT_INDEX, CREDIT_TOTAL_AMOUNT_LENGTH);
			validateNumber(creditTotalAmount.trim(), "Credit Total Amount");
			headerCreditTotalAmount = addDecimals(creditTotalAmount);
			
			String debitLineCount = getFieldValue(record, DEBIT_LINE_COUNT_INDEX, DEBIT_LINE_COUNT_LENGTH);
			validateNumber(debitLineCount.trim(), "Debit Line Count");
			headerDebitCount = new BigInteger(debitLineCount);
			
			String debitTotalAmount = getFieldValue(record, DEBIT_TOTAL_AMOUNT_INDEX, DEBIT_TOTAL_AMOUNT_LENGTH);
			validateNumber(debitTotalAmount.trim(), "Debit Total Amount");
			
			headerDebitTotalAmount = addDecimals(debitTotalAmount);
			if(headerCreditCount.intValue() > 0){
				createDepositControlStaging();
				createTenderControlStagingRecord();
			}
		}
		  
		/**
		* This method will process the Detail record present in the File.
		  * It will create the Payment Upload Staging records and the 
		  * Notification Upload Staging records.
		  * @param record
		  */
		private void processDetailsRecord(String record){
			String customerAccountNumber = getFieldValue(record, ACCOUNT_NUMBER_INDEX, ACCOUNT_NUMBER_LENGTH);
			validateNumber(customerAccountNumber.trim(), "Customer Account Number");
			
			String recordType = getFieldValue(record, RECORD_TYPE_INDEX, RECORD_TYPE_LENGTH);
			validateRecordType(recordType.trim(), "Record Type");
			
			String strAmount = getFieldValue(record, AMOUNT_INDEX, AMOUNT_LENGTH);
			validateNumber(strAmount.trim(), "Credit or Debit Amount");
			BigDecimal amount = addDecimals(strAmount.trim());
			Money tenderAmount = new Money(amount,parmTenderSource.getCurrency().getId());
			
			String strPaymentDate = getFieldValue(record, PAYMENT_DATE_INDEX, PAYMENT_DATE_LENGTH);
			validateDate(strPaymentDate.trim(), "Payment Date");
			String formattedPaymentDate = changeDateFormat(strPaymentDate).trim();
			
			String strPaymentTime = getFieldValue(record, PAYMENT_TIME_INDEX, PAYMENT_TIME_LENGTH);
			
			// Start Add - JMeden - CCB030.Issue4 -  2021-07-12
			if(isBlankOrNull(strPaymentTime)){
				strPaymentTime = DEFAULT_PAYMENT_TIME;
			}
			// End Add - JMeden - CCB030.Issue4 -  2021-07-12
			
			validateNumber(strPaymentTime.trim(), "Payment Time");
			validatePaymentDateTime(strPaymentDate, strPaymentTime, "Payment Date");
			
			sequenceCode = getFieldValue(record, SEQUENCE_CODE_INDEX, SEQUENCE_CODE_LENGTH);
			validateNumber(sequenceCode.trim(), "Sequence Code");
			
			if(recordType.equals(RECORD_TYPE_CREDIT)){
				createPaymentTenderStagingRecord(tenderAmount,customerAccountNumber);
				totalPaymentsCountProcessed = totalPaymentsCountProcessed.add(BigDecimal.ONE);
				totalPaymentsAmountProcessed = totalPaymentsAmountProcessed.add(amount);
			}else if(recordType.equals(RECORD_TYPE_DEBIT)){
				startChanges();
				createNotificationUpload();
				createContextRecord(parmAcctIdCtxtType, customerAccountNumber);
				createContextRecord(parmRetRsnCtxtType, parmReturnReason);
				createContextRecord(parmRetPayDtCtxtType, formattedPaymentDate);
				createContextRecord(parmAmtPaidCtxtType, amount.toString());
				saveChanges();
				totalReturnsCountProcessed = totalReturnsCountProcessed.add(BigDecimal.ONE); 
				totalReturnsAmountProcessed = totalReturnsAmountProcessed.add(amount);
			}
		}
		
		/**
		 * This method validates if the input is a valid date and not null.
		 * @param date
		 */		
		private void validateDate(String strDate, String columnName){
			if(isNull(strDate) || strDate.isEmpty()){
				addError(CustomMessageRepositorySpireOne.CCB030_3_recordColumnEmpty(parmFileName, columnName, lineCounter.toString().trim()));
			}else{
				SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyy");
		        formatter.setLenient(false);
		        try{
		            Date date = formatter.parse(strDate);
		            if (!formatter.format(date).equals(strDate)){
		            	addError(CustomMessageRepositorySpireOne.CCB030_3_recordInvalidDate(parmFileName, strDate, columnName, lineCounter.toString().trim()));
		            } 
		        }catch(ParseException e){

		        	addError(CustomMessageRepositorySpireOne.CCB030_3_recordInvalidDate(parmFileName, strDate, columnName, lineCounter.toString().trim()));
		        }
			}
	    }
		
		/**
		 * This method changes the date format of the input into the new date format
		 * @param value
		 * @return
		 */
		private String changeDateFormat(String value){
        	String newDate = value;
        	SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT);
            try {
				java.util.Date date = format.parse(value);
				format.applyPattern(NEW_DATE_FORMAT);
				newDate = format.format(date);
			} catch (ParseException e) {
				return newDate;
			}
            
        	return newDate;
        }
		
		/**
		 * This method validates if the input is a valid date time and not null.
		 * @param date
		 */
		private void validatePaymentDateTime(String date, String time, String columnName){
			String dateConcat = date.concat(" ").concat(time);
			SimpleDateFormat dateFormat = new SimpleDateFormat("MMddyyyy HHmmss");
			try {
				Date parsedDate = dateFormat.parse(dateConcat.trim());
		    } catch (ParseException pe) {
		    	addError(CustomMessageRepositorySpireOne.CCB030_3_recordInvalidDate(parmFileName, columnName, date, lineCounter.toString().trim()));
		    }
		}
		
		/**
		 * This method validates if the input is numeric and not null.
		 * @param number
		 */
		private void validateNumber(String number, String columnName){
			if(isNull(number) || number.isEmpty()){
				addError(CustomMessageRepositorySpireOne.CCB030_3_recordColumnEmpty(parmFileName, columnName, lineCounter.toString().trim()));
			}else{
				if(!StringUtils.isNumeric(number)){
					addError(CustomMessageRepositorySpireOne.CCB030_3_recordInvalidNumber(parmFileName, columnName, number, lineCounter.toString().trim()));
				}
			}
		}
		
		/**
		 * This method will add a decimal point to a number and transform it into a BigDecimal 
		 * @param number
		 * @return
		 */
		private BigDecimal addDecimals(String number){
			BigInteger unscaled = new BigInteger(number);
			BigDecimal result = new BigDecimal(unscaled, 2);
			return result;
		}
		
		/**
		 * This method validates if the input is a valid record type and not null.
		 * @param recordType
		 */
		private void validateRecordType(String recordType, String columnName){
			if(isNull(recordType) || recordType.isEmpty()){
				addError(CustomMessageRepositorySpireOne.CCB030_3_recordColumnEmpty(parmFileName, columnName, lineCounter.toString().trim()));
			}else{
				if(recordType.equals(RECORD_TYPE_CREDIT) || recordType.equals(RECORD_TYPE_DEBIT)){
					return;
				}else{
					addError(CustomMessageRepositorySpireOne.CCB030_3_recordTypeInvalid(parmFileName, recordType, lineCounter.toString().trim()));
				}
			}
		}
		
		/**
		 * This method creates a Deposit Control Staging record
		 */
		private void createDepositControlStaging(){
			DepositControlStaging_Id depositControlStagingId = new DepositControlStaging_Id(parmTenderSource.getExternalSourceId().trim(), parmFileName);                                                
			DepositControlStaging_DTO depositControlStagingDTO = depositControlStagingId.newDTO();                                                                                 
			depositControlStagingDTO.setDepositControlStagingStatus(DepositControlStagingStatusLookup.constants.PENDING);
			depositControlStagingDTO.setTransmissionDateTime(getProcessDateTime());                                                                       
			depositControlStagingDTO.setCurrencyId(parmTenderSource.getCurrency().getId());                                                           
			depositControlStagingDTO.setTenderControlTotalAmount(new Money(headerCreditTotalAmount,parmTenderSource.getCurrency().getId()));
			depositControlStagingDTO.setTotalTenderControl(BigInteger.ONE);   
			depositControlStaging = depositControlStagingDTO.newEntity();
		}

		/**
		 * This method creates a Tender Control Staging Record
		 */
		private void createTenderControlStagingRecord() {
			// Start Change - NMendo - Defect 4595996 - 2021-09-17
			//TenderControlStaging_Id tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, "00001");
			TenderControlStaging_Id tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, parmPaymentBatchNumber);
			// End Change - NMendo - Defect 4595996 - 2021-09-17
			TenderControlStaging_DTO tenderControlStagingDTO = tenderControlStagingId.newDTO();
			tenderControlStagingDTO.setTenderControlStatus(TenderControlStatusLookup.constants.PENDING);                                             
			tenderControlStagingDTO.setTotalTendersAmount(new Money(headerCreditTotalAmount,parmTenderSource.getCurrency().getId())); 
			tenderControlStagingDTO.setTotalNumberOfTender(headerCreditCount);
			tenderControlStaging = tenderControlStagingDTO.newEntity();
		}
		
		/**
		 * This method creates a Payment Tender Staging Record
		 */
		private void createPaymentTenderStagingRecord(Money tenderAmount, String accountNumber) {
			PaymentTenderUpload_Id paymentTenderUploadId = new PaymentTenderUpload_Id(tenderControlStaging.getId(), sequenceCode);
			PaymentTenderUpload_DTO paymentTenderUploadDTO = paymentTenderUploadId.newDTO(); 
			paymentTenderUploadDTO.setPaymentTenderStagingStatus(PaymentTenderStagingStatusLookup.constants.PENDING);  
			paymentTenderUploadDTO.setTenderAmount(tenderAmount);               
			paymentTenderUploadDTO.setAccountingDate(getProcessDateTime().getDate());
			paymentTenderUploadDTO.setTenderTypeId(parmTenderType.getId());
			paymentTenderUploadDTO.setCustomerId(accountNumber);
			paymentTenderUploadDTO.newEntity();
		}
		
		/**
		 * This method creates a Notification Upload Record
		 */
		private void createNotificationUpload(){
			NotificationUpload_DTO notificationUploadDto = createDTO(NotificationUpload.class);
			notificationUploadDto.setCreationDateTime(getProcessDateTime());
			notificationUploadDto.setNotificationUploadTypeId(parmNotificationType.getId());
			notificationUploadDto.setNotificationExternalId(notificationExternalId);
			notificationUploadDto.setNotificationStatus(NotificationUploadStatusLookup.constants.PENDING);
			notificationUploadDto.setNotificationUploadExtension(NotificationUploadExtensionLookup.constants.NO_EXTENSION);
			notificationUpload = notificationUploadDto.newEntity();
		} 
		
		/**
		 * This method will add a Notification Upload Context Record
		 * @param notificationUploadContextType
		 * @param contextValue
		 */
		private void createContextRecord(NotificationUploadContextLookup notificationUploadContextType, String contextValue){
			NotificationUploadContext_DTO notificationUploadContextDTO = new NotificationUploadContext_DTO();
			notificationUploadContextDTO.setId(new NotificationUploadContext_Id(notificationUpload, notificationUploadContextType, contextValue.trim()));
			notificationUploadContextDTO.newEntity();
		}
		
		/**
		 * This method will validate that the Payments and Returns Count and Amounts are in sync
		 */
		private void validateRecords(){
			BigDecimal headerPaymentsCount = new BigDecimal(headerCreditCount);
			BigDecimal headerReturnsCount = new BigDecimal(headerDebitCount);
			if(headerPaymentsCount.compareTo(totalPaymentsCountProcessed) != 0){
				addError(CustomMessageRepositorySpireOne.CCB030_3_totalPaymentsCountDoNotMatch(totalPaymentsCountProcessed.toString().trim(), headerPaymentsCount.toString().trim()));
			}
			if(headerCreditTotalAmount.compareTo(totalPaymentsAmountProcessed) != 0){
				addError(CustomMessageRepositorySpireOne.CCB030_3_totalPaymentsAmountDoNotMatch(totalPaymentsAmountProcessed.toString().trim(), headerCreditTotalAmount.toString().trim()));
			}
			if(headerReturnsCount.compareTo(totalReturnsCountProcessed) != 0){
				addError(CustomMessageRepositorySpireOne.CCB030_3_totalReturnsCountDoNotMatch(totalReturnsCountProcessed.toString().trim(), headerReturnsCount.toString().trim()));
			}
			if(headerDebitTotalAmount.compareTo(totalReturnsAmountProcessed) != 0){
				addError(CustomMessageRepositorySpireOne.CCB030_3_totalReturnsAmountDoNotMatch(totalReturnsAmountProcessed.toString().trim(), headerDebitTotalAmount.toString().trim()));
			}
		}
	}

}

