/*
 ***************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This batch process will upload Tokenized SSN of a person from an upload file.
 * *NOTE* Paymetrix Token will no longer be used
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2018-07-19   LBallo			PII-01. Initial Version.
 * 2018-08-22   JVitug          PII-01-02. Updated the sequence of the 
 *                              details being retrieved from input file
 * 2018-09-26   MPang       	PII-03/Defect 9/ID 8,9 and 10. Added dashes
 *                          	in input SSN before comparing to SSN id
 *                              in CCB.
 * 2020-08-07   JVitug          B-15945. Paymetrix Token will no longer
 *                              be used.
 **************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.ccb.domain.admin.idType.entity.IdType_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonId;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonId_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonId_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
//import com.splwg.cm.api.lookup.CmSsnTokenizationParametersLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever_Impl;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author Administrator
 *
@BatchJob (multiThreaded = true, rerunnable = false, modules =  {} ,
 * 		softParameters = { @BatchJobSoftParameter (name = filePath, required = true, type = string)
 * 				, @BatchJobSoftParameter (name = fileName, required = true, type = string)
 * 				, @BatchJobSoftParameter (entityName = featureConfiguration, name = ssnTokenParametersFeatConfig, required = true, type = entity)})
 */
public class CmSsnTokenUploadBatch extends
			CmSsnTokenUploadBatch_Gen {
	
	// Soft Parameters
	private String filePath;
	private String fileName;

	// Constant variables
	private String DELIMITER = ",";
	
	public JobWork getJobWork() {

		// Read File
		File file = new File(filePath, fileName);
		BufferedReader bufferedreader = null;
		
		ThreadWorkUnit threadWorkUnit = null;
		List<ThreadWorkUnit> threadWorkUnits = new ArrayList<ThreadWorkUnit>();

		try {
			
			bufferedreader = new BufferedReader(new FileReader(file));
			String record = "";
			Person_Id perId = null;
			
			while (bufferedreader.ready()) {
				record = bufferedreader.readLine();
				//Start Change JVitug - PII-01-02 - 2018-08-22
				//perId = new Person_Id(record.split(DELIMITER)[0]);
				perId = new Person_Id(record.split(DELIMITER)[2]);
				//End Change JVitug - PII-01-02 - 2018-08-22
				
				threadWorkUnit = new ThreadWorkUnit();
				threadWorkUnit.setPrimaryId(perId);
                //Start Change JVitug - PII-01-02 - 2018-08-22
				//threadWorkUnit.addSupplementalData("ssn", record.split(DELIMITER)[1]);
				threadWorkUnit.addSupplementalData("ssn", record.split(DELIMITER)[0]);
				//threadWorkUnit.addSupplementalData("ssnToken", record.split(DELIMITER)[2]);
				threadWorkUnit.addSupplementalData("ssnToken", record.split(DELIMITER)[1]);
                //End Change JVitug - PII-01-02 - 2018-08-22
				
				threadWorkUnits.add(threadWorkUnit);
			}
		} catch (FileNotFoundException ex) {
			addError(CustomMessageRepository.PII_TOKENIZATION_errorReadingFile(file.getAbsolutePath()));
		} catch (IOException e) {
			addError(CustomMessageRepository.PII_TOKENIZATION_errorProcessingFile(file.getAbsolutePath()));
		}
		
		return createJobWorkForThreadWorkUnitList(threadWorkUnits);
	}
	
	@Override
	public void validateSoftParameters(boolean isNewRun) {
		
		// File Path and File name should be valid
		filePath = getParameters().getFilePath();
		File directory = new File(filePath);
		if (!directory.isDirectory()) {
			addError(CustomMessageRepository.PII_TOKENIZATION_invalidFilePath(filePath));
		}
		
		fileName = getParameters().getFileName();
		File file = new File(filePath, fileName);
		if (isNull(file) || !file.isFile()) {
			addError(CustomMessageRepository.PII_TOKENIZATION_fileNotFound(fileName));
		}
		
		// append a directory separator to the end if none is provided
		if (filePath.substring(filePath.length() -1) != File.separator) {
			filePath = filePath.concat(File.separator);
		}
		
	}

	public Class<CmSsnTokenUploadBatchWorker> getThreadWorkerClass() {
		return CmSsnTokenUploadBatchWorker.class;
	}

	public static class CmSsnTokenUploadBatchWorker extends
			CmSsnTokenUploadBatchWorker_Gen {
		
		// Soft Parameters
		private String fileName;
		private FeatureConfiguration ssnTokenizationParametersFeatConfig;
		
		// Work variables
		private int row = 0;
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}
		
		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
			
			row = 0;
			fileName = getParameters().getFileName();
			ssnTokenizationParametersFeatConfig = getParameters().getSsnTokenParametersFeatConfig();
			
		}
		
		@Override
		protected boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			// increment row count
			row++;
			
			Person_Id perId = (Person_Id) unit.getPrimaryId();
			String ssnStr = (String) unit.getSupplementallData("ssn");
			String ssnTokenStr = (String) unit.getSupplementallData("ssnToken");
			
			Person per = null;
			
			// Validate Person Id in file
			if (notNull(perId.getEntity())) {
				per = perId.getEntity();
			} else {
				logError(CustomMessageRepository.PII_TOKENIZATION_personDoesNotExist(perId.getTrimmedValue(), BigInteger.valueOf(row), fileName));
				return false;
			}
			
			CmFeatureConfigurationRetriever_Impl featConfigRetriever = new CmFeatureConfigurationRetriever_Impl();
			featConfigRetriever.setParmWFMName(ssnTokenizationParametersFeatConfig);
			//featConfigRetriever.setParmOptType(CmSsnTokenizationParametersLookup.constants.CM_SSN_TOKEN_ID_TYPE.value());
			
			IdType_Id ssnTokenIdTypeId = new IdType_Id(featConfigRetriever.getMaxSequenceOptionValue());
			// PII-03 - 2018-09-26 - Start Change
			String ssnStrDash = ssnStr.replaceFirst("(\\d{3})(\\d{2})(\\d+)", "$1-$2-$3");
			//if (doesRecordInFileMatch(perId, ssnStr).isTrue()) {
			if (doesRecordInFileMatch(perId, ssnStrDash).isTrue()) {
			// PII-03 - 2018-09-26 - End Change
				ListFilter<PersonId> personIdIdFilter = per.getIds().createFilter(" where this.id.person = :personId and this.id.idType = :ssnTokenIdTypeId "
						, getClass().getName());
				
				personIdIdFilter.bindId("personId", perId);
				personIdIdFilter.bindId("ssnTokenIdTypeId", ssnTokenIdTypeId);
				if (notNull(personIdIdFilter.firstRow())) {
					PersonId ssnToken = personIdIdFilter.firstRow();
					PersonId_DTO perIdDto = ssnToken.getDTO();
					perIdDto.setPersonIdNumber(ssnTokenStr);
					ssnToken.setDTO(perIdDto);
				} else {
					PersonId_Id	perIdSsn  = new PersonId_Id(perId, ssnTokenIdTypeId);
					PersonId_DTO perIdDto = createDTO(PersonId.class);
					perIdDto.setId(perIdSsn);
					perIdDto.setPersonIdNumber(ssnTokenStr);
					perIdDto.newEntity();
				}
			}
			
			return true;
		}
		
		/**
		 * This method will check if the Person Id and SSN in the file matches to a Person Id and SSN in CCB
		 * @param perId
		 * @param ssn
		 * @return
		 */
		private Bool doesRecordInFileMatch(Person_Id perId, String ssn) {
			
			StringBuilder doesRecordInFileMatchQueryStr = new StringBuilder();
			doesRecordInFileMatchQueryStr.append("SELECT ");
			doesRecordInFileMatchQueryStr.append(  "PERID.PER_ID ");
			doesRecordInFileMatchQueryStr.append("FROM ");
			doesRecordInFileMatchQueryStr.append(  "CI_PER_ID PERID ");
			doesRecordInFileMatchQueryStr.append("WHERE ");
			doesRecordInFileMatchQueryStr.append(  "PERID.ID_TYPE_CD = 'SSN' ");
			doesRecordInFileMatchQueryStr.append(  "AND PERID.PER_ID = :perId ");
			doesRecordInFileMatchQueryStr.append(  "AND PER_ID_NBR = :ssn ");
			
			PreparedStatement pStmt = createPreparedStatement(doesRecordInFileMatchQueryStr.toString(), getClass().getName());
			pStmt.bindId("perId", perId);
			pStmt.bindStringProperty("ssn", PersonId.properties.personIdNumber, ssn);
			
			SQLResultRow resultRow = pStmt.firstRow();
			
			if (notNull(resultRow)) {
				return Bool.TRUE;
			} else {
				return Bool.FALSE;
			}
		}
	}
}
