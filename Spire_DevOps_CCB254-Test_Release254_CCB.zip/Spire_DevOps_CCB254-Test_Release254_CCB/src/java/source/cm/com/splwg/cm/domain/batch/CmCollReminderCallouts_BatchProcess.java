/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NI0011.3 - Collection Notice Reminder
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:      		Reason:
 * YYYY-MM-DD   IN       		Reason text.
 * 2013-04-12   Rakesh  		NI0011.3. Initial Version
 * 2013-05-06   Jagadeesh       TIR 1 - pointed to the right message
 * 2013-05-14	Karthik			KL20130514: TIR 2 - Swapped firstname and
 * 								middlename values and populated Zipcode
 * 2013-07-01	Karthik			KL20130701 - Fix for Defect #2642
 * 2015-05-22 	Dhuynh			3220373: Include MGE Division to output file
 * 2015-11-03   SMiran          SF-55857. Do not abort if there are no records
 * 								to process.
 * 2016-01-27	MPang	 		Updated for CCB v2.4 compilation. 
 * 2016-09-05   Sreekanth       SF-62632. Mimic calculation of past due amount
 * 								in 96-hour notice (GC410-CALC-AMT-OWED).
 * 2016-09-06	Sreekanth		SF-72853. Current Due Unsigned value is now set
 *                              as the Service Agreement's Total Current Balance.
 * 2018-02-29	DarrylH			SA:235882 Altered Java variables and soft parameter 
 * 								intialization. Static variable did not work well 
 * 								in AE (uc4 schedule).
 * 2019-01-31   SRoman			Defect 4156578. 1. Added override annotation on 
 * 								createWorkUnit method.  
 * 								2. Move the checking of list size to getJobWork
 * 								method to avoid calling the query twice.
 * 2021-03-26	PCayab			CCB020.4.Updated to accommodate new CC Types for IVR  .
 * 2021-05-10   SRoman			CCB039.3. Modified the processing of the batch instead
 * 								of using file transfer to trigger outbound calls,
 * 					            the calls are made real-time.
 * 2021-08-10   GCrisp          CCB039.Issue2. Enable multi-threading
 * 2021-11-15	JMeden			Defect 4592887. Do not create Outbound Message
 * 								if the Person has no Phone Number.
 * 2026-05-19	CAtilano		E-13167 INC0081039 CM-NONRG Execution times in PROD.
 * 							    Changed to Thread Iteration Strategy, 
 * 								Added Error Chars to discard processed records in error.
 **************************************************************************/

package com.splwg.cm.domain.batch;

// Start Change - 2021-05-10 - SRoman - CCB039.3. 
import java.math.BigInteger;
import java.util.Iterator;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadIterationStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.StringId;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonPhone;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;

/**
@BatchJob (modules = {}, multiThreaded = true, rerunnable = false,
*      softParameters = { @BatchJobSoftParameter (name = COMM_TYPE, required = true, type = string)
*       , @BatchJobSoftParameter (name = SVC_TASK_TYPE, required = true, type = entity, entityName = serviceTaskType)
*       , @BatchJobSoftParameter (name = IVR_CALL_CONFIG_BO, required = true, type = entity, entityName = businessObject)
*       , @BatchJobSoftParameter (name = CC_CHAR_CALLDT, required = true, type = entity, entityName = characteristicType)
*       , @BatchJobSoftParameter (name = CC_CHAR_STATUS, required = true, type = entity, entityName = characteristicType)
*       , @BatchJobSoftParameter (name = CC_CHAR_ERRORS, required = true, type = entity, entityName = characteristicType)})
*/

public class CmCollReminderCallouts_BatchProcess 
		extends CmCollReminderCallouts_BatchProcess_Gen {

	// Constant Variables
	private static final String SERVICE_TASK_TYPE = "serviceTaskType";
	private static final String CUST_CONTACT_CLASS = "customerContactClass";
	private static final String CUST_CONTACT_TYPE = "customerContactType";
	private static final String PHONE_ERROR_STRING = "Valid phone not found";
	
	// Soft Parameter Variables

	/*  2026-05-19	CAtilano		E-13167 Start Delete
	public JobWork getJobWork() {
		QueryIterator mainIter = retrieveCollectionReminder().iterate();
		
		if(!mainIter.hasNext()){
			logInfo(CustomMessageRepository.ni0011_3NoEligibleCollectionRemindersFound());
		}

		return createJobWorkForQueryIterator(mainIter, this);
	}

	private PreparedStatement retrieveCollectionReminder() {
		// Read IVR Service Task Type
		BusinessObjectInstance boInstance = BusinessObjectInstance.create(parmIvrCallConfigBO);
		boInstance.set(SERVICE_TASK_TYPE, parmSvTaskType.getId().getIdValue());
		boInstance = BusinessObjectDispatcher.read(boInstance);
		
		COTSInstanceList custContactOutboundBOList = boInstance.getGroup("ivrCallConfigurationDetails").getList("outboundMessageBOList");
		Iterator <COTSInstanceListNode> iterator = custContactOutboundBOList.iterator();
		
		StringBuilder retrieveCollReminderStr = new StringBuilder();
		// Initial Processing - Customer Contacts that do not have Call Date and Call Status Characteristics
		retrieveCollReminderStr.append("SELECT CC.CC_ID FROM CI_CC CC ");
		retrieveCollReminderStr.append("WHERE 1=1 ");
		
		// Loop thru the Outbound Message BO and CC Class/CC Type list in IVR Service Task Type
		int x = 1;
		COTSInstanceListNode ccDetails;
		retrieveCollReminderStr.append("AND ( ");
		while(iterator.hasNext()) {
			ccDetails = iterator.next();
			if(x == 1) {
				retrieveCollReminderStr.append("(CC.CC_CL_CD = '" + ccDetails.getString(CUST_CONTACT_CLASS).trim() + "' ");
				retrieveCollReminderStr.append("AND CC.CC_TYPE_CD = '" + ccDetails.getString(CUST_CONTACT_TYPE).trim() + "') ");
			} else {
				retrieveCollReminderStr.append("OR (CC.CC_CL_CD = '" + ccDetails.getString(CUST_CONTACT_CLASS).trim() + "' ");
				retrieveCollReminderStr.append(		"AND CC.CC_TYPE_CD = '" + ccDetails.getString(CUST_CONTACT_TYPE).trim() + "') ");
			}
			x++;
		}
		retrieveCollReminderStr.append(		") ");

		retrieveCollReminderStr.append("AND NOT EXISTS ");
		retrieveCollReminderStr.append(		"(SELECT 'X' FROM CI_CC_CHAR C1 WHERE C1.CHAR_TYPE_CD = :ccCharCallDate AND C1.CC_ID = CC.CC_ID ) ");
		retrieveCollReminderStr.append("AND NOT EXISTS ");
		retrieveCollReminderStr.append(		"(SELECT 'X' FROM CI_CC_CHAR C1 WHERE C1.CHAR_TYPE_CD = :ccCharStatus AND C1.CC_ID = CC.CC_ID ) ");
		retrieveCollReminderStr.append(" AND CC.CC_ID = '0000113527' ");
		
		// Follow-up Processing - Customer Contacts that has Call Date Characteristic with Char Value equal to process date but has no Call Status Characteristic yet
		retrieveCollReminderStr.append("UNION ");
		retrieveCollReminderStr.append("SELECT CC.CC_ID FROM CI_CC CC ");
		retrieveCollReminderStr.append("WHERE 1=1 ");
		
		// Loop thru the Outbound Message BO and CC Class/CC Type list in IVR Service Task Type
		int y = 1;
		iterator = custContactOutboundBOList.iterator();
		retrieveCollReminderStr.append("AND ( ");
		while(iterator.hasNext()) {
			ccDetails = iterator.next();
			
			if(y == 1) {
				retrieveCollReminderStr.append("(CC.CC_CL_CD = '" + ccDetails.getString(CUST_CONTACT_CLASS).trim() + "' ");
				retrieveCollReminderStr.append("AND CC.CC_TYPE_CD = '" + ccDetails.getString(CUST_CONTACT_TYPE).trim() + "') ");
			} else {
				retrieveCollReminderStr.append("OR (CC.CC_CL_CD = '" + ccDetails.getString(CUST_CONTACT_CLASS).trim() + "' ");
				retrieveCollReminderStr.append(		"AND CC.CC_TYPE_CD = '" + ccDetails.getString(CUST_CONTACT_TYPE).trim() + "') ");
			}
			y++;
		}
		retrieveCollReminderStr.append(		") ");

		retrieveCollReminderStr.append("AND EXISTS ");
		retrieveCollReminderStr.append(		"(SELECT 'X' FROM CI_CC_CHAR C1 WHERE C1.CHAR_TYPE_CD = :ccCharCallDate AND TO_DATE(TRIM(C1.ADHOC_CHAR_VAL), 'MM/DD/YYYY') = :batchBusinessDate AND C1.CC_ID = CC.CC_ID ) ");
		retrieveCollReminderStr.append("AND NOT EXISTS ");
		retrieveCollReminderStr.append(		"(SELECT 'X' FROM CI_CC_CHAR C1 WHERE C1.CHAR_TYPE_CD = :ccCharStatus AND C1.CC_ID = CC.CC_ID ) ");
	
        PreparedStatement retrieveCollReminderQry = createPreparedStatement(retrieveCollReminderStr.toString(), getClass().getName());
        
        retrieveCollReminderQry.bindId("ccCharCallDate", parmCCCharCallDate.getId());
        retrieveCollReminderQry.bindId("ccCharStatus",  parmCCCharStatus.getId());
        retrieveCollReminderQry.bindDate("batchBusinessDate", getProcessDateTime().getDate());
		
		return retrieveCollReminderQry;	
	}
	
	@Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow row){
		ThreadWorkUnit threadUnit = new ThreadWorkUnit();
		CustomerContact_Id customerContactId = (CustomerContact_Id) row.getId("CC_ID", CustomerContact.class);
		threadUnit.setPrimaryId(customerContactId);
		return threadUnit;
	}
	 2026-05-19	CAtilano		E-13167 End Delete*/
	@Override
	public void validateSoftParameters(boolean isNewRun) {

		
		// Check if the override maximum errors is less than 0
		if (notNull(getParameters().getSoftMaxErrors()) && getParameters().getSoftMaxErrors().intValue() < 0) {
			addError(CustomMessageRepository.ni0011_3MaxErrorIsInvalid(getParameters().getSoftMaxErrors().toString().trim()));
		}

		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(getParameters().getCC_CHAR_CALLDT(), CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);
		if (isNull(charEntityId.getEntity())) {
			addError(CustomMessageRepository.ni0011_3InvalidInputCharTypeForEntity(getParameters().getCC_CHAR_CALLDT().getId().getTrimmedValue()));
		}

		charEntityId = null;
		charEntityId = new CharacteristicEntity_Id(getParameters().getCC_CHAR_STATUS(), CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);
		if (isNull(charEntityId.getEntity())) {
			addError(CustomMessageRepository.ni0011_3InvalidInputCharTypeForEntity(getParameters().getCC_CHAR_STATUS().getId().getTrimmedValue()));
		}
		// 2026-05-19	CAtilano		E-13167 Start Add 
		charEntityId = null;
		charEntityId = new CharacteristicEntity_Id(getParameters().getCC_CHAR_ERRORS(), CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);
		if (isNull(charEntityId.getEntity())) {
			addError(CustomMessageRepository.ni0011_3InvalidInputCharTypeForEntity(getParameters().getCC_CHAR_ERRORS().getId().getTrimmedValue()));
		}
		//  2026-05-19	CAtilano		E-13167 End Add
		
	}
	
	/**
	 * @return void
	 *  This method retrieves Batch Param variables and initializes the class variables
	 */
	
	public Class<CmCollReminderCallouts_BatchProcessWorker> getThreadWorkerClass() {
		return CmCollReminderCallouts_BatchProcessWorker.class;
	}

	public static class CmCollReminderCallouts_BatchProcessWorker extends
		CmCollReminderCallouts_BatchProcessWorker_Gen {
		
		// Constant Variables
		private static final String IVR_CONFIG_DTLS_GRP = "ivrCallConfigurationDetails";
		private static final String OUTBOUND_MSG_BO_LIST = "outboundMessageBOList";
		private static final String COMM_TYPE = "communicationType";
		private static final String OUTBOUND_MSG_BO = "outboundMessageBO";
		private static final String CRE_DTTM = "creationDateTime";
		private static final String NOTIF_DETAILS_GRP = "notificationDetails";
		private static final String EMAIL_PARM_6 = "emailParameter6";
		
		private BigInteger parmMaxErrors;
		private CharacteristicType parmCCCharStatus;
		private CharacteristicType parmCCCharError; 
		
		// Soft Parameter Variables
		private String parmCommType;
		private ServiceTaskType parmSvTaskType;
		private BusinessObject parmIvrCallConfigBO;
		private CharacteristicType parmCCCharCallDate;
		
		// Work Variables
		private BusinessObjectInstance boInstance = null;
		private CustomerContact_Id ccId = null;
		private String ccClasStr = "";
		private String ccTypeStr = "";
		private DateFormat dateFormat = new DateFormat("MM/dd/yyyy");
		
		//Start Add - 2021-11-15 - JMeden - Defect 4592887
		private String personPhoneList = "'";
		private String businessPhoneList = "'";
		//End Add - 2021-11-15 - JMeden - Defect 4592887
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new ThreadIterationStrategy(this);
		}
		
		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful) 
				throws ThreadAbortedException, RunAbortedException {
			
			parmMaxErrors = getParameters().getSoftMaxErrors();
			parmCCCharStatus = getParameters().getCC_CHAR_STATUS();
			parmCCCharError = getParameters().getCC_CHAR_ERRORS();
			parmCommType = getParameters().getCOMM_TYPE();
			parmSvTaskType = getParameters().getSVC_TASK_TYPE();
			parmIvrCallConfigBO = getParameters().getIVR_CALL_CONFIG_BO();
			parmCCCharCallDate = getParameters().getCC_CHAR_CALLDT();
			
			// Read IVR Service Task Type
			boInstance = BusinessObjectInstance.create(parmIvrCallConfigBO);
			boInstance.set(SERVICE_TASK_TYPE, parmSvTaskType.getId().getIdValue());
			boInstance = BusinessObjectDispatcher.read(boInstance);
			
			//Start Add - 2021-11-15 - JMeden - Defect 4592887
			COTSInstanceList personPhoneTypeListOutboundBOList = boInstance.getGroup("priorityPersonPhoneTypes").getList("phoneTypeList");
			COTSInstanceList businessPhoneTypeListOutboundBOList = boInstance.getGroup("priorityBusinessPhoneTypes").getList("phoneTypeList");
			
			//Get the Phone List for  the service task for Person
			Iterator <COTSInstanceListNode> iterator = personPhoneTypeListOutboundBOList.iterator();
			COTSInstanceListNode priorityPhoneList = null;
			while(iterator.hasNext()) {
				priorityPhoneList = iterator.next();
				personPhoneList = personPhoneList.concat(priorityPhoneList.getString("phoneType").trim()).concat("','");
			}
			personPhoneList = personPhoneList.substring(0, personPhoneList.length()-2);
			
			//Get the Phone List for  the service task for Business
			iterator = businessPhoneTypeListOutboundBOList.iterator();
			priorityPhoneList = null;
			while(iterator.hasNext()) {
				priorityPhoneList = iterator.next();
				businessPhoneList = businessPhoneList.concat(priorityPhoneList.getString("phoneType").trim()).concat("','");
			}
			businessPhoneList = businessPhoneList.substring(0, businessPhoneList.length()-2);
			this.startResultRowQueryIteratorForThread(CustomerContact_Id.class);

			//End Add - 2021-11-15 - JMeden - Defect 4592887
		}
		
		protected QueryIterator getQueryIteratorForThread(StringId lowId, StringId highId) {
			
			BusinessObjectInstance boInstance = BusinessObjectInstance.create(parmIvrCallConfigBO);
			boInstance.set(SERVICE_TASK_TYPE, parmSvTaskType.getId().getIdValue());
			boInstance = BusinessObjectDispatcher.read(boInstance);
			
			COTSInstanceList custContactOutboundBOList = boInstance.getGroup("ivrCallConfigurationDetails").getList("outboundMessageBOList");
			Iterator <COTSInstanceListNode> iterator = custContactOutboundBOList.iterator();
			
			StringBuilder retrieveCollReminderStr = new StringBuilder();
			// Initial Processing - Customer Contacts that do not have Call Date and Call Status Characteristics
			retrieveCollReminderStr.append("SELECT CC.CC_ID FROM CI_CC CC ");
			retrieveCollReminderStr.append("WHERE 1=1 ");
			
			// Loop thru the Outbound Message BO and CC Class/CC Type list in IVR Service Task Type
			int x = 1;
			COTSInstanceListNode ccDetails;
			retrieveCollReminderStr.append("AND ( ");
			while(iterator.hasNext()) {
				ccDetails = iterator.next();
				if(x == 1) {
					retrieveCollReminderStr.append("(CC.CC_CL_CD = '" + ccDetails.getString(CUST_CONTACT_CLASS).trim() + "' ");
					retrieveCollReminderStr.append("AND CC.CC_TYPE_CD = '" + ccDetails.getString(CUST_CONTACT_TYPE).trim() + "') ");
				} else {
					retrieveCollReminderStr.append("OR (CC.CC_CL_CD = '" + ccDetails.getString(CUST_CONTACT_CLASS).trim() + "' ");
					retrieveCollReminderStr.append(		"AND CC.CC_TYPE_CD = '" + ccDetails.getString(CUST_CONTACT_TYPE).trim() + "') ");
				}
				x++;
			}
			retrieveCollReminderStr.append(		") ");

			retrieveCollReminderStr.append("AND NOT EXISTS ");
			retrieveCollReminderStr.append(		"(SELECT 'X' FROM CI_CC_CHAR C1 WHERE C1.CHAR_TYPE_CD = :ccCharCallDate AND C1.CC_ID = CC.CC_ID ) ");
			retrieveCollReminderStr.append("AND NOT EXISTS ");
			retrieveCollReminderStr.append(		"(SELECT 'X' FROM CI_CC_CHAR C1 WHERE C1.CHAR_TYPE_CD = :ccCharStatus AND C1.CC_ID = CC.CC_ID ) ");
			//  2026-05-19	CAtilano		E-13167 Start Add - Discard CCs that have NONRGERR characteristic 
			retrieveCollReminderStr.append("AND NOT EXISTS ");
			retrieveCollReminderStr.append(		"(SELECT 'X' FROM CI_CC_CHAR C1 WHERE C1.CHAR_TYPE_CD = :ccErrorChar AND C1.CC_ID = CC.CC_ID ) ");
			retrieveCollReminderStr.append(" AND CC.CC_ID BETWEEN :lowId AND :highId ");
			// 2026-05-19	CAtilano		E-13167 End Add
			
			// Follow-up Processing - Customer Contacts that has Call Date Characteristic with Char Value equal to process date but has no Call Status Characteristic yet
			retrieveCollReminderStr.append("UNION ");
			retrieveCollReminderStr.append("SELECT CC.CC_ID FROM CI_CC CC ");
			retrieveCollReminderStr.append("WHERE 1=1 ");
			
			// Loop thru the Outbound Message BO and CC Class/CC Type list in IVR Service Task Type
			int y = 1;
			iterator = custContactOutboundBOList.iterator();
			retrieveCollReminderStr.append("AND ( ");
			while(iterator.hasNext()) {
				ccDetails = iterator.next();
				
				if(y == 1) {
					retrieveCollReminderStr.append("(CC.CC_CL_CD = '" + ccDetails.getString(CUST_CONTACT_CLASS).trim() + "' ");
					retrieveCollReminderStr.append("AND CC.CC_TYPE_CD = '" + ccDetails.getString(CUST_CONTACT_TYPE).trim() + "') ");
				} else {
					retrieveCollReminderStr.append("OR (CC.CC_CL_CD = '" + ccDetails.getString(CUST_CONTACT_CLASS).trim() + "' ");
					retrieveCollReminderStr.append(		"AND CC.CC_TYPE_CD = '" + ccDetails.getString(CUST_CONTACT_TYPE).trim() + "') ");
				}
				y++;
			}
			retrieveCollReminderStr.append(		") ");

			retrieveCollReminderStr.append("AND EXISTS ");
			retrieveCollReminderStr.append(		"(SELECT 'X' FROM CI_CC_CHAR C1 WHERE C1.CHAR_TYPE_CD = :ccCharCallDate AND TO_DATE(TRIM(C1.ADHOC_CHAR_VAL), 'MM/DD/YYYY') = :batchBusinessDate AND C1.CC_ID = CC.CC_ID ) ");
			retrieveCollReminderStr.append("AND NOT EXISTS ");
			retrieveCollReminderStr.append(		"(SELECT 'X' FROM CI_CC_CHAR C1 WHERE C1.CHAR_TYPE_CD = :ccCharStatus AND C1.CC_ID = CC.CC_ID ) ");
			// 2026-05-19	CAtilano		E-13167 Start Add - Discard CCs that have NONRGERR characteristic 
			retrieveCollReminderStr.append("AND NOT EXISTS ");
			retrieveCollReminderStr.append(		"(SELECT 'X' FROM CI_CC_CHAR C1 WHERE C1.CHAR_TYPE_CD = :ccErrorChar AND C1.CC_ID = CC.CC_ID ) ");
			retrieveCollReminderStr.append(" AND CC.CC_ID BETWEEN :lowId AND :highId ");
		    // 2026-05-19	CAtilano		E-13167 End Add
	        PreparedStatement retrieveCollReminderQry = createPreparedStatement(retrieveCollReminderStr.toString(), getClass().getName());
	        
	        retrieveCollReminderQry.bindId("ccCharCallDate", parmCCCharCallDate.getId());
	        retrieveCollReminderQry.bindId("ccCharStatus",  parmCCCharStatus.getId());
	        retrieveCollReminderQry.bindId("ccErrorChar", parmCCCharError.getId());
	        retrieveCollReminderQry.bindDate("batchBusinessDate", getProcessDateTime().getDate());
	        retrieveCollReminderQry.bindId("lowId", lowId);
	        retrieveCollReminderQry.bindId("highId", highId);
	        retrieveCollReminderQry.setAutoclose(false);
	        retrieveCollReminderQry.execute();
	        
			return retrieveCollReminderQry.iterate();

        }	
		
		protected ThreadWorkUnit getNextWorkUnit(QueryResultRow row) {
			
			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId(new CustomerContact_Id(row.getString("CC_ID")));
			return workUnit;
		}
		
		@Override
		public boolean executeWorkUnit(ThreadWorkUnit unit)
		throws ThreadAbortedException, RunAbortedException {
			
			ccId = (CustomerContact_Id) unit.getPrimaryId();
			
			//Start Add - 2021-11-15 - JMeden - Defect 4592887
			if(hasPhoneNumber(ccId.getEntity().getPerson()).isFalse()){
				return true;
			}
			//End Add - 2021-11-15 - JMeden - Defect 4592887
			
			COTSInstanceList custContactOutboundBOList = boInstance.getGroup(IVR_CONFIG_DTLS_GRP).getList(OUTBOUND_MSG_BO_LIST);
			Iterator <COTSInstanceListNode> iterator = custContactOutboundBOList.iterator();
			
			ccClasStr = ccId.getEntity().getCustomerContactType().fetchIdContactClass().getId().getTrimmedValue();
			ccTypeStr = ccId.getEntity().getCustomerContactType().fetchIdContactType().trim();
			
			COTSInstanceListNode ccDetails = null;
			
			while(iterator.hasNext()) {
				ccDetails = iterator.next();
				if(ccClasStr.compareTo(ccDetails.getString(CUST_CONTACT_CLASS).trim()) == 0
						&& ccTypeStr.compareTo(ccDetails.getString(CUST_CONTACT_TYPE).trim()) == 0) {
					try {
						BusinessObjectInstance outboundBOInstance = null;
						outboundBOInstance = BusinessObjectInstance.create(ccDetails.getString(OUTBOUND_MSG_BO).trim());
						outboundBOInstance.set(CRE_DTTM, getProcessDateTime());
						
						COTSInstanceNode notifDetails = outboundBOInstance.getGroup(NOTIF_DETAILS_GRP);
						notifDetails.set(COMM_TYPE, parmCommType);
						notifDetails.set(EMAIL_PARM_6, ccId.getTrimmedValue());
						outboundBOInstance = BusinessObjectDispatcher.add(outboundBOInstance);
						
						// Add customer contact characteristic
						if(isNull(ccId.getEntity().getEffectiveCharacteristic(parmCCCharCallDate))) {
							addCustomerContactChar(ccId, parmCCCharCallDate, getProcessDateTime().getDate().toString(dateFormat));
						}
						
					} catch (ApplicationError ae) {
						// 2026-05-19	CAtilano		E-13167 Start Add - Add NONRGERR characteristic 
						addCustomerContactChar(ccId, parmCCCharError, ae.getServerMessage().getMessageText());
						//logError(ae.getServerMessage());
						// 2026-05-19	CAtilano		E-13167 End Add
					}
					break;
				}
			}
			
			return true;
		}
		
		//Start Add - 2021-11-15 - JMeden - Defect 4592887
		/**
		 * This method will check if the person has existing Phone number
		 * @param person
		 * @return
		 */
		private Bool hasPhoneNumber(Person person){
			String phoneList = "";
			Bool returnVal = Bool.FALSE;
			
			if(person.getPersonOrBusiness().isPerson()){
				phoneList = personPhoneList;
			} else {
				phoneList = businessPhoneList;
			}
			
			StringBuilder sbSql = new StringBuilder();
			sbSql.append(" WHERE this.phoneType.id IN (");
			sbSql.append(phoneList);
			sbSql.append(") ");
			
			ListFilter<PersonPhone> perPhone = person.getPhones().createFilter(sbSql.toString(), getClass().getName());
			
			if(notNull(perPhone.firstRow())){
				returnVal = Bool.TRUE;
			}
			else {
				// 2026-05-19	CAtilano		E-13167 Start Add - Add NONRGERR characteristic 
				addCustomerContactChar(ccId, parmCCCharError, PHONE_ERROR_STRING);
				// 2026-05-19	CAtilano		E-13167 End Add
			}
			
			return returnVal;
		}
		//End Add - 2021-11-15 - JMeden - Defect 4592887
		
		private void addCustomerContactChar(CustomerContact_Id customerContactId, CharacteristicType charType, String charValue){

			CustomerContactCharacteristic_DTO customerContactCharDTO = new CustomerContactCharacteristic_DTO();
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			customerContactCharDTO.setId(new CustomerContactCharacteristic_Id( charType, customerContactId.getEntity()));

			if (charTypeLookup.isPredefinedValue()){
				customerContactCharDTO.setCharacteristicValue(charValue);
			} else if (charTypeLookup.isForeignKeyValue()){
				customerContactCharDTO.setCharacteristicValueForeignKey1(charValue);
			} else{
				customerContactCharDTO.setAdhocCharacteristicValue(charValue);
			}

			customerContactCharDTO.newEntity();

		}
	}
}

//import java.io.BufferedWriter;
//import java.io.File;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.math.BigInteger;
//import java.util.Iterator;
//import java.util.List;
//import java.util.StringTokenizer;
//
//import com.ibm.icu.math.BigDecimal;
//import com.splwg.base.api.QueryIterator;
//import com.splwg.base.api.QueryResultRow;
//import com.splwg.base.api.batch.JobWork;
//import com.splwg.base.api.batch.RunAbortedException;
//import com.splwg.base.api.batch.StandardCommitStrategy;
//import com.splwg.base.api.batch.ThreadAbortedException;
//import com.splwg.base.api.batch.ThreadExecutionStrategy;
//import com.splwg.base.api.batch.ThreadWorkUnit;
//import com.splwg.base.api.datatypes.Bool;
//import com.splwg.base.api.datatypes.Date;
//import com.splwg.base.api.datatypes.DateFormat;
//import com.splwg.base.api.datatypes.Money;
//import com.splwg.base.api.lookup.CharacteristicTypeLookup;
//import com.splwg.base.api.lookup.MessageSeverityLookup;
//import com.splwg.base.api.sql.PreparedStatement;
//import com.splwg.base.api.sql.SQLResultRow;
//import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
//import com.splwg.base.domain.common.characteristicType.CharacteristicType;
//import com.splwg.base.domain.common.phoneType.PhoneType;
//import com.splwg.base.domain.common.phoneType.PhoneType_Id;
//import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
//import com.splwg.ccb.api.lookup.PersonOrBusinessLookup;
////Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
///*import com.splwg.ccb.domain.admin.customerContactClass.CustomerContactClass;
//import com.splwg.ccb.domain.admin.customerContactType.CustomerContactType;
//import com.splwg.ccb.domain.admin.customerContactType.CustomerContactType_Id;
//import com.splwg.ccb.domain.customerinfo.account.Account;
//import com.splwg.ccb.domain.customerinfo.account.Account_Id;
//import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact;
//import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic;
//import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic_DTO;
//import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic_Id;
//import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact_Id;
//import com.splwg.ccb.domain.customerinfo.person.Person;
//import com.splwg.ccb.domain.customerinfo.person.Person_Id;*/
//
//import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
//import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
//import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
////2016-09-05. Sreekanth. SF-62632. Start Add
//import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceProcess;
//import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceProcess_Id;
////2016-09-05. Sreekanth. SF-62632. End Add
//import com.splwg.ccb.domain.customerinfo.account.entity.Account;
//import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
//import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
//import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic;
//import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
//import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_Id;
//import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_Id;
//import com.splwg.ccb.domain.customerinfo.person.entity.Person;
//import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
////2016-09-05. Sreekanth. SF-62632. Start Add
//import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
//import com.splwg.ccb.domain.customerinfo.data.ServiceAgreementBalanceData;
//import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
////2016-09-05. Sreekanth. SF-62632. End Add
////End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
//import com.splwg.cm.domain.customMessages.CustomMessageRepository;
//import com.splwg.shared.common.StringUtilities;

///**
// *
//@BatchJob (modules = {}, multiThreaded = false, rerunnable = false,
// *      softParameters = { @BatchJobSoftParameter (name = FILE_LOCATION, required = true, type = string)
// *       , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
// *       , @BatchJobSoftParameter (name = AMOUNT, required = true, type = decimal)
// *       , @BatchJobSoftParameter (name = CC_TYPE, required = true, type=string)
// *       , @BatchJobSoftParameter (entityName = customerContactClass,name = CC_CLASS, required = true, type = entity)
// *       , @BatchJobSoftParameter (name = CC_CHAR_CALLDT, required = true, type = entity, entityName = characteristicType)
// *       , @BatchJobSoftParameter (name = CC_CHAR_STATUS, required = true, type = entity, entityName = characteristicType)
// *       , @BatchJobSoftParameter (name = PRI_PER_PHONETYPE, required = true, type = string)
// *       , @BatchJobSoftParameter (name = PRI_BUS_PHONETYPE, required = true, type = string)
// *       , @BatchJobSoftParameter (name = FRIEND_REM_CC_TYPE, required = true, type = string)
// *       , @BatchJobSoftParameter (name = LAST_WARN_CC_TYPE, required = true, type = string)})
// */
//public class CmCollReminderCallouts_BatchProcess 
//		extends CmCollReminderCallouts_BatchProcess_Gen {
///*
//	//Soft Parameters
//	// START CHANGE-DarrylH -2018-02-29 SA-235882
//	/*
//	private static BigInteger parmMaxErrors;
//	private static String parmFilePath = null;
//	private static String parmFileName = null;
//	private static BigDecimal parmAmount = null;
//	private static String parmCCType = null;
//	private static CustomerContactClass parmcustomerContactClass = null;
//	private static CharacteristicType parmCCCharCallDate = null;
//	private static CharacteristicType parmCCCharStatus = null;
//	private static String parmPriorityPerPhoneType = null;
//	private static String parmPriorityBusPhoneType = null;
//	private static CustomerContactType_Id custContactType = null;
//	*/
//	private  BigInteger parmMaxErrors;
//	private  String parmFilePath = null;
//	private  String parmFileName = null;
//	private  BigDecimal parmAmount = null;
//	private  String parmCCType = null;
//	private  CustomerContactClass parmcustomerContactClass = null;
//	private  CharacteristicType parmCCCharCallDate = null;
//	private  CharacteristicType parmCCCharStatus = null;
//	private  String parmPriorityPerPhoneType = null;
//	private  String parmPriorityBusPhoneType = null;
//	private  CustomerContactType_Id custContactType = null;
//	// END CHANGE-DarrylH -2018-02-29 SA-235882
//	//Start Add - 2021-03-26 - PCayab - CCB020.4.Updated to accommodate new CC Types for IVR.
//	private  String parmFriendRemCCType = null;
//	private  CustomerContactType_Id friendRemCustContactType = null;
//	private  String parmLastWarnCCType = null;
//	private  CustomerContactType_Id lastWarnCustContactType = null;
//	//End Add - 2021-03-26 - PCayab - CCB020.4.Updated to accommodate new CC Types for IVR.
//	// Constants
//	private static final String COMMA = ",";
//
//	//Class Variables
//	// START CHANGE-DarrylH -2018-02-29 SA-235882
//	//private static PhoneType_Id [] perPhoneType = null;
//	//private static PhoneType_Id [] busPhoneType = null;
//	private PhoneType_Id [] perPhoneType = null;
//	private PhoneType_Id [] busPhoneType = null;
//	// END CHANGE-DarrylH -2018-02-29 SA-235882
//	public void validateSoftParameters(boolean isNewRun){
//
//
//
//		initializeSoftParams();
//
//		// Validate if the file path is valid
//		File folder = new File(parmFilePath);
//		if(!(folder.exists() && folder.isDirectory())) {
//			addError(CustomMessageRepository.ni0011_3FilePathIsInvalid(parmFilePath));
//		}
//
//		// Check if the override maximum errors is less than 0
//		if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
//			addError(CustomMessageRepository.ni0011_3MaxErrorIsInvalid(parmMaxErrors.toString().trim()));
//		}
//
//		custContactType = new CustomerContactType_Id(parmcustomerContactClass,parmCCType);
//		if(isNull(custContactType.getEntity())){
//			addError(CustomMessageRepository.ni0011_3CustomerContactTypeInvalid(parmCCType.trim()));
//		}
//
//		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(parmCCCharCallDate, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);
//		if (isNull(charEntityId.getEntity())){
//			addError(CustomMessageRepository.ni0011_3InvalidInputCharTypeForEntity(parmCCCharCallDate.getId().getTrimmedValue()));
//		}
//
//		charEntityId = null;
//		charEntityId = new CharacteristicEntity_Id(parmCCCharStatus, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);
//		if (isNull(charEntityId.getEntity())){
//			addError(CustomMessageRepository.ni0011_3InvalidInputCharTypeForEntity(parmCCCharStatus.getId().getTrimmedValue()));
//		}
//
//
//
//		StringTokenizer strPerPhoneTypeTokenizer = new StringTokenizer(parmPriorityPerPhoneType,COMMA);
//		int perPhoneTypeCount = strPerPhoneTypeTokenizer.countTokens();
//		perPhoneType = new PhoneType_Id[perPhoneTypeCount];
//		for (int i = 0; i < perPhoneTypeCount; i++) {
//			PhoneType_Id perPhoneTypeId = new PhoneType_Id(strPerPhoneTypeTokenizer.nextToken());
//			if(!isNull(perPhoneTypeId.getEntity())){
//				perPhoneType[i] = perPhoneTypeId;
//			}else{
//				addError(CustomMessageRepository.ni0011_3InvalidPerPhoneType(perPhoneTypeId.getIdValue().trim()));
//			}
//		}
//
//		StringTokenizer strBusPhoneTypeTokenizer = new StringTokenizer(parmPriorityBusPhoneType,COMMA);
//		int busPhoneTypeCount = strBusPhoneTypeTokenizer.countTokens();
//		busPhoneType = new PhoneType_Id[busPhoneTypeCount];
//		for (int i = 0; i < busPhoneTypeCount; i++) {
//			PhoneType_Id busPhoneTypeId = new PhoneType_Id(strBusPhoneTypeTokenizer.nextToken());
//			if(!isNull(busPhoneTypeId.getEntity())){
//				busPhoneType[i] = busPhoneTypeId;
//			}else{
//				addError(CustomMessageRepository.ni0011_3InvalidBusPhoneType(busPhoneTypeId.getIdValue().trim()));
//			}
//		}
//
//		//Start Add - 2021-03-26 - PCayab - CCB020.4.Updated to accommodate new CC Types for IVR.
//		friendRemCustContactType = new CustomerContactType_Id(parmcustomerContactClass,parmFriendRemCCType);
//		if(isNull(friendRemCustContactType.getEntity())){
//			addError(CustomMessageRepository.ni0011_3CustomerContactTypeInvalid(parmFriendRemCCType.trim()));
//		}
//		
//		lastWarnCustContactType = new CustomerContactType_Id(parmcustomerContactClass,parmLastWarnCCType);
//		if(isNull(lastWarnCustContactType.getEntity())){
//			addError(CustomMessageRepository.ni0011_3CustomerContactTypeInvalid(parmLastWarnCCType.trim()));
//		}
//		//End Add - 2021-03-26 - PCayab - CCB020.4.Updated to accommodate new CC Types for IVR.
//	}
//
//
//	/**
//	 * @return void
//	 *  This method retrieves Batch Param variables and initializes the class variables
//	 */
//	private void initializeSoftParams(){
//
//		parmFileName = getParameters().getFILE_NAME();
//		parmFilePath = getParameters().getFILE_LOCATION();
//		parmAmount = getParameters().getAMOUNT();
//		parmcustomerContactClass = getParameters().getCC_CLASS();
//		parmCCType = getParameters().getCC_TYPE();
//		parmCCCharCallDate = getParameters().getCC_CHAR_CALLDT();
//		parmCCCharStatus = getParameters().getCC_CHAR_STATUS();
//		parmPriorityBusPhoneType = getParameters().getPRI_BUS_PHONETYPE();
//		parmPriorityPerPhoneType = getParameters().getPRI_PER_PHONETYPE();
//		parmMaxErrors = getParameters().getSoftMaxErrors();
//		//Start Add - 2021-03-26 - PCayab - CCB020.4.Updated to accommodate new CC Types for IVR.
//		parmFriendRemCCType = getParameters().getFRIEND_REM_CC_TYPE();
//		parmLastWarnCCType = getParameters().getLAST_WARN_CC_TYPE();
//		//Start Add - 2021-03-26 - PCayab - CCB020.4.Updated to accommodate new CC Types for IVR.
//		
//
//	}
//	public JobWork getJobWork() {
//		QueryIterator mainIter = retreiveCollectionReminder().iterate();
//		//Start Add - 2019-01-31 - SRoman -  Defect 4156578.
//		if(!mainIter.hasNext()){
//			logInfo(CustomMessageRepository.ni0011_3NoEligibleCollectionRemindersFound());
//		}
//		//End Add - 2019-01-31 - SRoman -  Defect 4156578.
//		return createJobWorkForQueryIterator(mainIter, this);
//	}
//
//	private PreparedStatement retreiveCollectionReminder(){
//		//Modified Main SQL as per code review comments
//		StringBuilder getAppointmentFAQueryStr = new StringBuilder();
//		// 2016-09-05. Sreekanth. SF-62632. Start Change
//		//getAppointmentFAQueryStr.append("SELECT SC.CC_ID, SA.ACCT_ID, PN.ENTITY_NAME, SP.ARS_AMT ");
//		getAppointmentFAQueryStr.append("SELECT SC.CC_ID, SA.ACCT_ID, PN.ENTITY_NAME, SP.ARS_AMT, SP.SEV_PROC_ID, SP.SA_ID ");
//		// 2016-09-05. Sreekanth. SF-62632. End Change
//		// 2016-09-05. Sreekanth. SF-72853. Start Change
//		//getAppointmentFAQueryStr.append(", ((SELECT SUM(CUR_AMT) FROM CI_FT WHERE SA_ID = SP.SA_ID) -  SP.ARS_AMT) CUR_DUE ");
//		getAppointmentFAQueryStr.append(", (SELECT SUM(CUR_AMT) FROM CI_FT WHERE SA_ID = SP.SA_ID) CUR_DUE ");
//		// 2016-09-05. Sreekanth. SF-72853. End Change
//		getAppointmentFAQueryStr.append(", PM.ADDRESS1, PM.ADDRESS2 ,PM.ADDRESS3 ,PM.ADDRESS4 ");
//		getAppointmentFAQueryStr.append(", PM.CITY, PM.STATE, PM.POSTAL ");
//		getAppointmentFAQueryStr.append(", SE.TRIGGER_DT DATE_DELIQ, P.PER_OR_BUS_FLG, P.PER_ID ");
//		getAppointmentFAQueryStr.append("FROM  CI_SEV_PROC SP, CI_SEV_EVT SE, CI_SEV_EVT_CC SC,  ");
//		getAppointmentFAQueryStr.append("        CI_CC CC, CI_SA SA, CI_ACCT_PER AP, CI_PER_NAME PN,CI_PER P, ");
//		getAppointmentFAQueryStr.append("(SELECT DISTINCT SS.SA_ID, SP.PREM_ID FROM CI_SA_SP SS, CI_SP SP ");
//		getAppointmentFAQueryStr.append("WHERE SS.SP_ID = SP.SP_ID AND ((:processDate BETWEEN SS.START_DTTM AND SS.STOP_DTTM) OR (SS.STOP_DTTM IS NULL)) ");
//		getAppointmentFAQueryStr.append(") SA_PREM, CI_PREM PM ");
//		getAppointmentFAQueryStr.append("WHERE SP.SEV_PROC_ID = SE. SEV_PROC_ID ");
//		getAppointmentFAQueryStr.append("AND SE.SEV_PROC_ID = SC.SEV_PROC_ID ");
//		getAppointmentFAQueryStr.append("AND SE.EVT_SEQ = SC.EVT_SEQ ");
//		getAppointmentFAQueryStr.append("AND SC.CC_ID = CC.CC_ID ");
//		getAppointmentFAQueryStr.append("AND SP.SA_ID = SA.SA_ID ");
//		getAppointmentFAQueryStr.append("AND SA.ACCT_ID = AP.ACCT_ID ");
//		getAppointmentFAQueryStr.append("AND AP.PER_ID = P.PER_ID ");
//		getAppointmentFAQueryStr.append("AND AP.MAIN_CUST_SW = :mainCustomer ");
//		getAppointmentFAQueryStr.append("AND AP.PER_ID = PN.PER_ID ");
//		getAppointmentFAQueryStr.append("AND PN.PRIM_NAME_SW = :primaryName ");
//		getAppointmentFAQueryStr.append("AND SP.ARS_AMT >= :amount ");
//		getAppointmentFAQueryStr.append("AND CC.CC_CL_CD = :customerContactClass ");
//		getAppointmentFAQueryStr.append("AND CC.CC_TYPE_CD =:customerContactType ");
//		getAppointmentFAQueryStr.append("AND SA.SA_ID= SA_PREM.SA_ID ");
//		getAppointmentFAQueryStr.append("AND SA_PREM.PREM_ID = PM.PREM_ID ");
//		getAppointmentFAQueryStr.append("AND NOT EXISTS ");
//		getAppointmentFAQueryStr.append("(SELECT 'X' FROM CI_CC_CHAR C1 WHERE C1.CHAR_TYPE_CD = :ccCharCallDate AND C1.CC_ID = CC.CC_ID ) ");
//		getAppointmentFAQueryStr.append("AND NOT EXISTS ");
//		getAppointmentFAQueryStr.append("(SELECT 'X' FROM CI_CC_CHAR C1 WHERE C1.CHAR_TYPE_CD = :ccCharStatus AND C1.CC_ID = CC.CC_ID ) ");
//		
//		//Start Add - 2021-03-26 - PCayab - CCB020.4.Updated to accommodate new CC Types for IVR.
//		getAppointmentFAQueryStr.append("UNION ");
//		getAppointmentFAQueryStr.append("SELECT CC.CC_ID, AP.ACCT_ID, PN.ENTITY_NAME, ");
//		getAppointmentFAQueryStr.append("(SELECT CP.ARS_AMT FROM CI_COLL_PROC CP, CI_COLL_EVT_CC CEC WHERE CEC.COLL_PROC_ID = CP.COLL_PROC_ID AND CEC.CC_ID = CC.CC_ID) AS ARS_AMT, ");
//		getAppointmentFAQueryStr.append("' ' AS SEV_PROC_ID, ' ' AS SA_ID, ");
//		getAppointmentFAQueryStr.append("(SELECT SUM(CUR_AMT) FROM CI_ACCT_FT_HST_VW ACH WHERE ACH.ACCT_ID = AP.ACCT_ID) AS CUR_DUE, ");
//		getAppointmentFAQueryStr.append("(SELECT PR.ADDRESS1 FROM CI_PREM PR WHERE PR.PREM_ID = AC.MAILING_PREM_ID) AS ADDRESS1, ");
//		getAppointmentFAQueryStr.append("(SELECT PR.ADDRESS2 FROM CI_PREM PR WHERE PR.PREM_ID = AC.MAILING_PREM_ID) AS ADDRESS2, ");
//		getAppointmentFAQueryStr.append("(SELECT PR.ADDRESS3 FROM CI_PREM PR WHERE PR.PREM_ID = AC.MAILING_PREM_ID) AS ADDRESS3, ");
//		getAppointmentFAQueryStr.append("(SELECT PR.ADDRESS4 FROM CI_PREM PR WHERE PR.PREM_ID = AC.MAILING_PREM_ID) AS ADDRESS4, ");
//		getAppointmentFAQueryStr.append("(SELECT PR.CITY FROM CI_PREM PR WHERE PR.PREM_ID = AC.MAILING_PREM_ID) AS CITY, ");
//		getAppointmentFAQueryStr.append("(SELECT PR.STATE FROM CI_PREM PR WHERE PR.PREM_ID = AC.MAILING_PREM_ID) AS STATE, ");
//		getAppointmentFAQueryStr.append("(SELECT PR.POSTAL FROM CI_PREM PR WHERE PR.PREM_ID = AC.MAILING_PREM_ID) AS POSTAL, ");
//		getAppointmentFAQueryStr.append("(CASE WHEN CC.CC_TYPE_CD = :friendRem THEN (SELECT CE.TRIGGER_DT FROM CI_COLL_EVT CE, CI_COLL_EVT_CC CEC ");
//		getAppointmentFAQueryStr.append("      WHERE  CE.COLL_EVT_TYP_CD = 'FRNDREM' AND CEC.CC_ID = CC.CC_ID AND CEC.COLL_PROC_ID = CE.COLL_PROC_ID) ");
//		getAppointmentFAQueryStr.append("      ELSE TRUNC(CC.CC_DTTM) END ");
//		getAppointmentFAQueryStr.append("      )AS DATE_DELIQ, ");
//		getAppointmentFAQueryStr.append("P.PER_OR_BUS_FLG, P.PER_ID ");
//		getAppointmentFAQueryStr.append("FROM CI_CC CC, CI_ACCT_PER AP, CI_PER_NAME PN, CI_PER P, CI_ACCT AC ");
//		getAppointmentFAQueryStr.append("WHERE 1=1 ");
//		getAppointmentFAQueryStr.append("AND CC.PER_ID = AP.PER_ID ");
//		getAppointmentFAQueryStr.append("AND AP.MAIN_CUST_SW = 'Y' ");
//		getAppointmentFAQueryStr.append("AND AP.PER_ID = P.PER_ID ");
//		getAppointmentFAQueryStr.append("AND P.PER_ID = PN.PER_ID ");
//		getAppointmentFAQueryStr.append("AND AC.ACCT_ID = AP.ACCT_ID ");
//		getAppointmentFAQueryStr.append("AND CC.CC_CL_CD = :customerContactClass ");
//		getAppointmentFAQueryStr.append("AND CC.CC_TYPE_CD IN (:friendRem, :lastWarn) ");
//		getAppointmentFAQueryStr.append("AND NOT EXISTS ");
//		getAppointmentFAQueryStr.append("(SELECT 'X' FROM CI_CC_CHAR C1 WHERE C1.CHAR_TYPE_CD = :ccCharCallDate AND C1.CC_ID = CC.CC_ID ) ");
//		getAppointmentFAQueryStr.append("AND NOT EXISTS ");
//		getAppointmentFAQueryStr.append("(SELECT 'X' FROM CI_CC_CHAR C1 WHERE C1.CHAR_TYPE_CD = :ccCharStatus AND C1.CC_ID = CC.CC_ID ) ");
//		//End Add - 2021-03-26 - PCayab - CCB020.4.Updated to accommodate new CC Types for IVR.
//		
//		//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
//		//PreparedStatement appointmentFAQueryPrepStmt = createPreparedStatement(getAppointmentFAQueryStr.toString());
//		PreparedStatement appointmentFAQueryPrepStmt = createPreparedStatement(getAppointmentFAQueryStr.toString(), getClass().getName());
//		//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
//		appointmentFAQueryPrepStmt.bindDate("processDate", getProcessDateTime().getDate());
//		appointmentFAQueryPrepStmt.bindBoolean("mainCustomer", Bool.TRUE);
//		appointmentFAQueryPrepStmt.bindBoolean("primaryName", Bool.TRUE);
//		appointmentFAQueryPrepStmt.bindBigDecimal("amount",  parmAmount);
//		appointmentFAQueryPrepStmt.bindId("customerContactClass",  parmcustomerContactClass.getId());
//		appointmentFAQueryPrepStmt.bindStringProperty("customerContactType",CustomerContactType.properties.contactType , custContactType.getContactType());
//		appointmentFAQueryPrepStmt.bindId("ccCharCallDate", parmCCCharCallDate.getId());
//		appointmentFAQueryPrepStmt.bindId("ccCharStatus",  parmCCCharStatus.getId());
//		
//		//Start Delete - 2019-01-31 - SRoman -  Defect 4156578.
//		//if(appointmentFAQueryPrepStmt.list().isEmpty()){
//			// 2015-11-03. SMiran. SF-55857. Start Change
//			//addError(CustomMessageRepository.ni0011_3NoEligibleCollectionRemindersFound());
//			//logInfo(CustomMessageRepository.ni0011_3NoEligibleCollectionRemindersFound());
//			// 2015-11-03. SMiran. SF-55857. End Change
//		//}
//		//End Delete - 2019-01-31 - SRoman -  Defect 4156578.
//		
//		//Start Add - 2021-03-26 - PCayab - CCB020.4.Updated to accommodate new CC Types for IVR.
//		appointmentFAQueryPrepStmt.bindStringProperty("friendRem",CustomerContactType.properties.contactType , friendRemCustContactType.getContactType());
//		appointmentFAQueryPrepStmt.bindStringProperty("lastWarn",CustomerContactType.properties.contactType , lastWarnCustContactType.getContactType());
//		//End Add - 2021-03-26 - PCayab - CCB020.4.Updated to accommodate new CC Types for IVR.
//		return appointmentFAQueryPrepStmt;
//	}
//	
//	//Start Add - 2019-01-31 - SRoman -  Defect 4156578.
//	@Override
//	//End Add - 2019-01-31 - SRoman -  Defect 4156578.
//	public ThreadWorkUnit createWorkUnit(QueryResultRow row){
//		ThreadWorkUnit threadUnit = new ThreadWorkUnit();
//		CustomerContact_Id customerContactId = (CustomerContact_Id) row.getId("CC_ID", CustomerContact.class);
//		threadUnit.setPrimaryId(customerContactId);
//
//		threadUnit.addSupplementalData("ACCT_ID", row.getId("ACCT_ID",Account.class));
//		threadUnit.addSupplementalData("ENTITY_NAME", row.getString("ENTITY_NAME"));
//		threadUnit.addSupplementalData("ARS_AMT", row.getMoney("ARS_AMT"));
//		// 2016-09-05. Sreekanth. SF-62632. Start Add
//		threadUnit.addSupplementalData("SEV_PROC_ID", row.getId("SEV_PROC_ID",SeveranceProcess.class));
//		threadUnit.addSupplementalData("SA_ID", row.getId("SA_ID",ServiceAgreement.class));
//		// 2016-09-05. Sreekanth. SF-62632. End Add
//		threadUnit.addSupplementalData("CUR_DUE", row.getMoney("CUR_DUE"));
//		threadUnit.addSupplementalData("ADDRESS1", row.getString("ADDRESS1"));
//		threadUnit.addSupplementalData("ADDRESS2", row.getString("ADDRESS2"));
//		threadUnit.addSupplementalData("ADDRESS3", row.getString("ADDRESS3"));
//		threadUnit.addSupplementalData("ADDRESS4", row.getString("ADDRESS4"));
//		threadUnit.addSupplementalData("CITY", row.getString("CITY"));
//		threadUnit.addSupplementalData("STATE", row.getString("STATE"));
//		threadUnit.addSupplementalData("POSTAL", row.getString("POSTAL"));
//		threadUnit.addSupplementalData("DATE_DELIQ", row.getDate("DATE_DELIQ"));
//		threadUnit.addSupplementalData("PER_OR_BUS_FLG", row.getLookup("PER_OR_BUS_FLG", PersonOrBusinessLookup.class));
//		threadUnit.addSupplementalData("PER_ID", row.getId("PER_ID",Person.class));
//
//		return threadUnit;
//	}
//
//	public Class<CmCollReminderCallouts_BatchProcessWorker> getThreadWorkerClass() {
//		return CmCollReminderCallouts_BatchProcessWorker.class;
//	}
//
//	public static class CmCollReminderCallouts_BatchProcessWorker extends
//	CmCollReminderCallouts_BatchProcessWorker_Gen {
//
//		// Thread Class Variables
//		private BufferedWriter bufferedWriter;
//		private File inputFilePathAndName;
//		private Integer recordsProcessed = 0;
//		// START ADD-DarrylH -2018-02-29 SA-235882
//		private  String parmFilePath = null;
//		private  String parmFileName = null;
//		private  CharacteristicType parmCCCharCallDate = null;
//		private  String parmPriorityPerPhoneType = null;
//		private  String parmPriorityBusPhoneType = null;
//		private PhoneType_Id [] perPhoneType = null;
//		private PhoneType_Id [] busPhoneType = null;
//		
//		// END ADD-DarrylH -2018-02-29 SA-235882		
//		//*
//		// Constants
//		private static final String FILLER_STRING = " ";
//		private static final String SPACE = " ";
//		private static final Integer NAME_LENGTH = 25;
//		private static final Integer ADDRESS_LENGTH = 30;
//		private static final Integer CITY_LENGTH = 17;
//		private static final Integer STATE_LENGTH = 2;
//		private static final Integer ZIP_LENGTH = 5;
//		private static final Integer PHONE_LENGTH = 12;
//		private static final Integer AMOUNT_LENGTH = 12;
//		private static final Integer CC_ID_LENGTH = 15;
//
//		// Member Variables
//		private DateFormat dateFormat = new DateFormat("MM/dd/yyyy");
//
//		public ThreadExecutionStrategy createExecutionStrategy() {
//			return new StandardCommitStrategy(this);
//		}
//
//		public void initializeThreadWork(boolean initializationPreviouslySuccessful) throws ThreadAbortedException,
//		RunAbortedException {
//			// START ADD-DarrylH -2018-02-29 SA-235882
//			parmFileName = getParameters().getFILE_NAME();
//			parmFilePath = getParameters().getFILE_LOCATION();
//			parmCCCharCallDate = getParameters().getCC_CHAR_CALLDT();
//			parmPriorityBusPhoneType = getParameters().getPRI_BUS_PHONETYPE();
//			parmPriorityPerPhoneType = getParameters().getPRI_PER_PHONETYPE();
//			
//			StringTokenizer strPerPhoneTypeTokenizer = new StringTokenizer(parmPriorityPerPhoneType,COMMA);
//			int perPhoneTypeCount = strPerPhoneTypeTokenizer.countTokens();
//			perPhoneType = new PhoneType_Id[perPhoneTypeCount];
//			for (int i = 0; i < perPhoneTypeCount; i++) {
//				PhoneType_Id perPhoneTypeId = new PhoneType_Id(strPerPhoneTypeTokenizer.nextToken());
//				if(!isNull(perPhoneTypeId.getEntity())){
//					perPhoneType[i] = perPhoneTypeId;
//				}else{
//					addError(CustomMessageRepository.ni0011_3InvalidPerPhoneType(perPhoneTypeId.getIdValue().trim()));
//				}
//			}
//
//			StringTokenizer strBusPhoneTypeTokenizer = new StringTokenizer(parmPriorityBusPhoneType,COMMA);
//			int busPhoneTypeCount = strBusPhoneTypeTokenizer.countTokens();
//			busPhoneType = new PhoneType_Id[busPhoneTypeCount];
//			for (int i = 0; i < busPhoneTypeCount; i++) {
//				PhoneType_Id busPhoneTypeId = new PhoneType_Id(strBusPhoneTypeTokenizer.nextToken());
//				if(!isNull(busPhoneTypeId.getEntity())){
//					busPhoneType[i] = busPhoneTypeId;
//				}else{
//					addError(CustomMessageRepository.ni0011_3InvalidBusPhoneType(busPhoneTypeId.getIdValue().trim()));
//				}
//			}
//			// END ADD-DarrylH -2018-02-29 SA-235882		
//			openFileWriter();
//		}
//		public boolean executeWorkUnit(ThreadWorkUnit unit)
//		throws ThreadAbortedException, RunAbortedException {
//
//			Person_Id personId;
//			PersonOrBusinessLookup perOrBusFlag;
//			Account_Id accountId ;
//			String accountStr ="";
//			String entityName = "";
//			String firstName = "";
//			String middleName = "";
//			String lastName = "";
//			String prefixName = "   ";
//			String address = "";
//			String city = "";
//			String state ="";
//			String zip = "";
//			String phone ="";
//			Money curDueUnsigned =null;
//			Money pastDueUnisgned = null;
//			String curDueUnsignedStr = "";
//			String pastDueUnisgnedStr = "";
//			String dateDelinquentStr;
//			String choicePayFlag = "Y";
//			String custType = "";
//			String company = "";
//			CustomerContact_Id customerContactId;
//			String customerContactStr = "";
//
//			Integer index ;
//			recordsProcessed = recordsProcessed+1;
//
//			StringBuilder ccDetailLine = new StringBuilder();
//
//			//CC_ID
//			customerContactId = (CustomerContact_Id) unit.getPrimaryId();
//			customerContactStr = StringUtilities.padRight(customerContactId.getIdValue().trim(),CC_ID_LENGTH);
//
//			//Add customer contact characteristics
//			addCustomerContactChar(customerContactId, parmCCCharCallDate, getProcessDateTime().getDate().addDays(1).toString(dateFormat));
//
//
//			//Get Phone Number
//			personId = (Person_Id) unit.getSupplementallData("PER_ID");
//			perOrBusFlag = (PersonOrBusinessLookup) unit.getSupplementallData("PER_OR_BUS_FLG");
//
//
//			//Account Number
//			accountId =  (Account_Id) unit.getSupplementallData("ACCT_ID");
//			if(!isNull(accountId)){
//				accountStr = accountId.getIdValue().trim();
//				//START ADD - Dhuynh - 2015-05-22 - Defect#3220373
//				company = accountId.getEntity().fetchDivision().getId().getTrimmedValue();
//				//END ADD - Dhuynh - 2015-05-22 - Defect#3220373
//			}
//
//			//Name
//			entityName = (String) unit.getSupplementallData("ENTITY_NAME");
//
//			if(perOrBusFlag.isPerson()){
//				index = entityName.indexOf(COMMA);
//				if(index>0){
//					lastName = entityName.substring(0,index).trim();
//					String firstNameAndMiddleName = entityName.substring(index+1).trim();
//					Integer spaceIndex =firstNameAndMiddleName.indexOf(SPACE);
//					if(spaceIndex > 0){
//						// KL20130514 - Corrected the Firstname and middlename values by swapping them
//						firstName = firstNameAndMiddleName.substring(0, spaceIndex);
//						middleName = firstNameAndMiddleName.substring(spaceIndex+1);
//					}else{
//						firstName = firstNameAndMiddleName;
//					}
//				}
//			}
//			else{
//				lastName = entityName;
//			}
//			lastName = StringUtilities.padRight(lastName,NAME_LENGTH);
//			middleName = StringUtilities.padRight(middleName,NAME_LENGTH);
//			firstName = StringUtilities.padRight(firstName,NAME_LENGTH);
//
//			//Service Address
//			address = (String) unit.getSupplementallData("ADDRESS1") + (String) unit.getSupplementallData("ADDRESS2")+(String) unit.getSupplementallData("ADDRESS3")+(String) unit.getSupplementallData("ADDRESS4");
//			address = StringUtilities.padRight(address, ADDRESS_LENGTH);
//			if(address.length()>ADDRESS_LENGTH){
//				address = address.substring(0, ADDRESS_LENGTH-1);
//			}
//
//			//City
//			city = (String) unit.getSupplementallData("CITY");
//			city = StringUtilities.padRight(city,CITY_LENGTH);
//			//State
//			state = (String) unit.getSupplementallData("STATE");
//			state = StringUtilities.padRight(state,STATE_LENGTH);
//			//ZIP
//			// KL20130514 - Passed POSTAL to get the Zipcode value
//			zip = (String) unit.getSupplementallData("POSTAL");
//			zip = StringUtilities.padRight(zip,ZIP_LENGTH);
//
//			//Phone
//			phone = getPhone( personId,  perOrBusFlag);
//			if(!isBlankOrNull(phone)){
//				phone = formatPhone(phone);
//				phone = StringUtilities.padRight(phone,PHONE_LENGTH);
//			}else{
//				logMessage(CustomMessageRepository.ni0011_3PhoneNumberNotExist(personId.getIdValue()), MessageSeverityLookup.constants.WARNING);
//				return false;
//			}
//
//			//Current Balance on SA
//			curDueUnsigned = (Money) unit.getSupplementallData("CUR_DUE");
//			if(!isNull(curDueUnsigned)){
//				curDueUnsignedStr = StringUtilities.leftPadWithZeros(curDueUnsigned.getAmount().toString().trim(),AMOUNT_LENGTH);
//			}
//			//Delinquent SA Amount in Severance
//			// 2016-09-05. Sreekanth. SF-62632. Start Change
//			//pastDueUnisgned = (Money) unit.getSupplementallData("ARS_AMT");
//			SeveranceProcess_Id sevProcId = (SeveranceProcess_Id)unit.getSupplementallData("SEV_PROC_ID");
//			ServiceAgreement_Id sevProcSaId = (ServiceAgreement_Id)unit.getSupplementallData("SA_ID");
//			
//			//Start Change - 2021-03-26 - PCayab - CCB020.4.Updated to accommodate new CC Types for IVR.
//			//pastDueUnisgned = getPastDue(sevProcId, sevProcSaId);
//			if(!isNull(sevProcId.getEntity()) && !isNull(sevProcSaId.getEntity())){
//				pastDueUnisgned = getPastDue(sevProcId, sevProcSaId);
//			}
//			//End Change - 2021-03-26 - PCayab - CCB020.4.Updated to accommodate new CC Types for IVR.
//			
//			// 2016-09-05. Sreekanth. SF-62632. End Change
//
//			if(!isNull(pastDueUnisgned)){
//				pastDueUnisgnedStr = StringUtilities.leftPadWithZeros(pastDueUnisgned.getAmount().toString().trim(),AMOUNT_LENGTH);
//			}
//			//Delinquent Date
//			Date dateDelinquent = (Date) unit.getSupplementallData("DATE_DELIQ");
//			dateDelinquentStr = dateDelinquent.toString(dateFormat);
//
//			//Cust Type
//			custType = perOrBusFlag.getLookupValue().getId().getFieldValue();
//
//
//			ccDetailLine.append(accountStr);
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(prefixName);
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(lastName);
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(firstName);
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(middleName);
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(address);
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(city);
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(state);
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(zip);
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(phone);
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(curDueUnsignedStr);
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(pastDueUnisgnedStr);
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(dateDelinquentStr);
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(choicePayFlag);
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(custType.trim());
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(company);
//			ccDetailLine.append(FILLER_STRING);
//			ccDetailLine.append(customerContactStr);
//
//			writeLine(ccDetailLine.toString());
//			return true;
//
//		}
//		
//		// 2016-09-05. Sreekanth. SF-62632. Start Add
//		private Money getPastDue(SeveranceProcess_Id sevProcId, ServiceAgreement_Id sevProcSaId) {
//			
//			Money amountOwed = Money.ZERO;
//			
//			// Get past due for Severance SA (up to Severance Process Base Date)
//			Date debitDate = null;
//			if (notNull(sevProcId.getEntity().getArrearsDate())){
//				debitDate = sevProcId.getEntity().getArrearsDate();
//			}else{
//				debitDate = getProcessDateTime().getDate();
//			}
//			ServiceAgreementBalanceData saBalanceData = ServiceAgreementBalanceData.Factory.newInstance();
//			saBalanceData = sevProcSaId.getEntity().getFinancialBalances(Date.MAX, debitDate, Bool.TRUE);
//			if (saBalanceData.getCurrentAmount().getAmount().compareTo(BigDecimal.ZERO) == 1){
//				amountOwed = saBalanceData.getCurrentAmount();
//			}
//			
//			return amountOwed;
//		}
//		// 2016-09-05. Sreekanth. SF-62632. End Add
//		
//		private void addCustomerContactChar(CustomerContact_Id customerContactId, CharacteristicType charType, String charValue){
//
//			CustomerContactCharacteristic_DTO customerContactCharDTO = new CustomerContactCharacteristic_DTO();
//			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
//			customerContactCharDTO.setId(new CustomerContactCharacteristic_Id( charType, customerContactId.getEntity()));
//
//			if(charTypeLookup.isAdhocValue()){
//				customerContactCharDTO.setAdhocCharacteristicValue(charValue);
//			} else if (charTypeLookup.isPredefinedValue()){
//				customerContactCharDTO.setCharacteristicValue(charValue);
//			} else if (charTypeLookup.isForeignKeyValue()){
//				customerContactCharDTO.setCharacteristicValueForeignKey1(charValue);
//			}
//			CustomerContactCharacteristic customerContactChar = customerContactCharDTO.newEntity();
//
//		}
//		/**
//		 * Open File Writer
//		 */
//		private void openFileWriter(){
//			inputFilePathAndName = new File(parmFilePath, parmFileName);
//			try {
//				bufferedWriter = new BufferedWriter(new FileWriter(inputFilePathAndName));
//			} catch (IOException e) {
//				addError(CustomMessageRepository.ni0011_3ErrorInFile(e.getMessage()));
//			}
//		}
//
//		/**
//		 * Write Line to File
//		 */
//		private void writeLine(String recordline){
//
//			try {
//				bufferedWriter.write(recordline);
//				bufferedWriter.newLine();
//			} catch (IOException e) {
//				addError(CustomMessageRepository.ni0011_3ErrorInFile(e.getMessage()));
//			}
//		}
//
//		private String getPhone(Person_Id personId, PersonOrBusinessLookup perOrBusFlag){
//			String phone = null;;
//			SQLResultRow phoneRow = null;
//			PhoneType_Id phoneType;
//			PhoneType_Id [] phoneTypeArray = null;;
//			List<SQLResultRow> phoneList = retrievePhoneList(personId);
//			if (perOrBusFlag.isPerson()){
//				phoneTypeArray = perPhoneType;
//			}else if (perOrBusFlag.isBusiness()) {
//				phoneTypeArray = busPhoneType;
//			}
//
//			for (int i = 0; i < phoneTypeArray.length; i++) {
//
//				for (Iterator<SQLResultRow> phoneIter = phoneList.iterator(); phoneIter.hasNext();) {
//					phoneRow = (SQLResultRow) phoneIter.next();
//					phoneType = (PhoneType_Id) phoneRow.getId("PHONE_TYPE_CD",PhoneType.class);
//
//					if(phoneTypeArray[i].equals(phoneType)){
//						return phoneRow.getString("PHONE");
//					}
//				}
//			}
//
//			return phone;
//		}
//
//
//		private List<SQLResultRow> retrievePhoneList(Person_Id personId) {
//
//
//			StringBuilder retrievePhoneListString = new StringBuilder();
//			retrievePhoneListString.append(" SELECT PHONE_TYPE_CD,PHONE ") ;
//			retrievePhoneListString.append(" FROM CI_PER_PHONE ");
//			retrievePhoneListString.append(" WHERE PER_ID = :personId ");
//			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
//			//PreparedStatement retrievePhoneListPrepStmt = createPreparedStatement(retrievePhoneListString.toString());
//			PreparedStatement retrievePhoneListPrepStmt = createPreparedStatement(retrievePhoneListString.toString(), getClass().getName());
//			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
//			retrievePhoneListPrepStmt.bindId("personId", personId);
//			List<SQLResultRow> resultList = retrievePhoneListPrepStmt.list();
//
//			retrievePhoneListPrepStmt.close();
//
//			return resultList;
//
//		}
//
//
//		public static String formatPhone(String phone) {
//			phone = phone.replaceAll("[-() ]","");
//			if (phone.length()==10){
//				phone = phone.substring( 0,3 ) + "-" + phone.substring( 3,6 ) + "-" + phone.substring( 6,10 );
//			}
//			return phone;
//		}
//
//
//
//		/**
//		 * Close File Writer after all the records for this thread are processed.
//		 */
//		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException{
//
//			try {
//				bufferedWriter.close();
//			} catch (IOException e) {
//				addError(CustomMessageRepository.ni0011_3ErrorInFile(e.getMessage()));
//			}
//		}
//
//	}
//}
// End Change - 2021-05-10 - SRoman - CCB039.3.