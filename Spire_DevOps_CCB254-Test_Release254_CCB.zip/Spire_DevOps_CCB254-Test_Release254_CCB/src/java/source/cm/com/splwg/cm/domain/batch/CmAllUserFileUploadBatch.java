/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * All User File Upload 
 * 
 * This custom Batch Process will read the inbound All User file and load 
 * the data into a custom table. This table will have the same layout as 
 * the All User file's detail records and will be emptied of all data prior 
 * to loading the file.
 *            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-02-12   JPunza  NI0019.1 Initial Version.
 * 2013-05-15   JPunza  Defect 1201. Make sure the previous error logs are
 *                      displayed when maximum number of errors is reached.
 * 2013-08-30   Srikanth IM-34846. Change Parameter usage.  
 * 2016-01-29  	MPang	Updated for CCB v2.4 compilation.  
 * 2016-05-17   MPang   Defect 3438165. Added try catch when account is null.   
 * 2017-04-19	LBallo	CCB-CC-005.5. Allow upload of records with the same
 * 						Account Id and enrolledVia.     
 * 2017-07-19   AMasil  Defect 3800656. Update to only insert values to 
 *                      the table fields with default value of blank if the 
 *                      value from file is not blank.
 * 2018-08-01   SFelip  CCB v2.6 Upgrade. Use correct StringProperty values
 *                      to pass to the bindStringProperty method.           
 *************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.cm.domain.customerinfo.cmKubraAllUser.CmKubraAllUser;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

/**
 * @author jpunzalan2
 *
 @BatchJob (multiThreaded = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = DELIMITER, required = true, type = string)})
 */
public class CmAllUserFileUploadBatch 
        extends CmAllUserFileUploadBatch_Gen {

    // Constant Variables
    private final String FILE_PATH = "FILE_PATH";
    
    public JobWork getJobWork() {

        List<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        arrayList.add(threadWorkUnit);
        return createJobWorkForThreadWorkUnitList(arrayList);
    }
    
    public void validateSoftParameters(boolean arg0) {

        // Parameter FILE_PATH
        String filePath = getParameters().getFILE_PATH();        
        if (notBlank(filePath) && validateFilePath(filePath).isFalse()) {
            addError(CustomMessageRepositoryMDC.commBatchParmFilePathInvalid(
                    getBatchControlId().getTrimmedValue(), 
                    FILE_PATH, filePath));            
        }
    }
    
    /**
     * This method validates file path
     * @param filePath - String
     * @return Bool
     */
    private Bool validateFilePath(String filePath) {

        File folder = new File(filePath);
        if (folder.exists()) {
            return Bool.TRUE;
        }
        return Bool.FALSE;
    }
    
    public Class<CmAllUserFileUploadBatchWorker> getThreadWorkerClass() {
        return CmAllUserFileUploadBatchWorker.class;
    }

    public static class CmAllUserFileUploadBatchWorker 
            extends CmAllUserFileUploadBatchWorker_Gen {

        // Constant Variables        
        private final DateFormat DATE_FORMAT = new DateFormat("MM/dd/yyyy");        
        private final int ACCOUNT_NUM = 0;
        private final int E_BILLER = 1;
        private final int FIRST_NAME = 2;
        private final int LAST_NAME = 3;        
        private final int ENROLL_DATE = 4;
        private final int EMAIL = 5;        
        private final int USER_NAME = 6;
        private final int TURN_OFF_PAPER = 7;
        private final int TOKEN1 = 8;
        
        private final String QUOTE_MARK = "\"";
        
        // Counters
        private int processedRecord = 0;
        private int recordInError = 0;
        private Integer recordsInserted = 0; //IM-34846. Change Parameter usage
        
        // Working Variables
        private BigInteger maxErrors;
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }
        
        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit arg0) 
                throws ThreadAbortedException, RunAbortedException {
            
            maxErrors = getParameters().getSoftMaxErrors();
            
            // Open file
            String fileName = getParameters().getFILE_NAME();
            String filePath = getParameters().getFILE_PATH();
            
            File file = new File(filePath, fileName);            
            BufferedReader bufferedReader = null;            
            try {
                bufferedReader = new BufferedReader(new FileReader(file));
            } catch (FileNotFoundException fe) {
                addError(CustomMessageRepositoryMDC.NI0019_1_errorWhileAccessingFile(fe.getMessage()));
            }
            
            // Purge CM Kubra All User Table
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement purgeTable = createPreparedStatement("DELETE FROM CM_KUBRA_ALL_USER"); 
            PreparedStatement purgeTable = createPreparedStatement("DELETE FROM CM_KUBRA_ALL_USER", getClass().getName()); 
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            purgeTable.execute();
            purgeTable.close();
                   
            // Read file
            Bool firstLine = Bool.TRUE;

            try {
                while (bufferedReader.ready()) {
                    String record = bufferedReader.readLine();
                                        
                    // Ignore first and last record
                    if (firstLine.isTrue() || !bufferedReader.ready()) {
                        firstLine = Bool.FALSE;
                        continue;
                    }
                    
                    // Split the record into fields
                    processedRecord++;
                    /*
                     * Start Change - JPunza - Defect 1201
                     */
                    //String[] elements = record.split(getParameters().getDELIMITER());
                    String[] elements = record.split(QUOTE_MARK + getParameters().getDELIMITER());
                    /*
                     * End Change - JPunza - Defect 1201
                     */
                    
                    if (elements.length != 9) {
                        /*
                         * Start Change - JPunza - Defect 1201
                         */
                        //logErrorMessage(CustomMessageRepositoryMDC.NI0019_1_recordHasIncorrectNumOfFields(
                        //        processedRecord + 1));
                        if (logErrorMessage(CustomMessageRepositoryMDC.NI0019_1_recordHasIncorrectNumOfFields(
                                processedRecord + 1)).isTrue()) {
                            break;
                        }
                        /*
                         * End Change - JPunza - Defect 1201
                         */
                        continue;
                    }
                    
                    
                    // Retrieve values
                    String accountNum = elements[ACCOUNT_NUM].replace(QUOTE_MARK, "");
                    String eBiller = elements[E_BILLER].replace(QUOTE_MARK, "");
                    String firstName = elements[FIRST_NAME].replace(QUOTE_MARK, "");
                    String lastName = elements[LAST_NAME].replace(QUOTE_MARK, "");
                    String enrollDate = elements[ENROLL_DATE].replace(QUOTE_MARK, "");
                    String email = elements[EMAIL].replace(QUOTE_MARK, "");
                    String userName = elements[USER_NAME].replace(QUOTE_MARK, "");
                    String turnOffPaper = elements[TURN_OFF_PAPER].replace(QUOTE_MARK, "");
                    String token1 = elements[TOKEN1].replace(QUOTE_MARK, "");
                    
                  //Start Change - 2016-05-17 - MPang - Defect 3438165
                  ////IM-34846. Change Parameter usage - Start
                    //if(isNull( new Account_Id(accountNum.trim()).getEntity()) )
                    //    continue;
                    //
                  ////IM-34846. Change Parameter usage - End
                    try {
                        if(isNull( new Account_Id(accountNum.trim()).getEntity()) )
                            continue;
                    } catch (Exception e) {  
                        continue;
                    }
                    //End Change - 2016-05-17 - MPang - Defect 3438165
                    
                    // Add record to CM Kubra User Table
                    startChanges();
                    
                    /*
                     * Start Add - JPunza - Defect 1201
                     */
                    try {
                    /*
                     * End Add - JPunza - Defect 1201
                     */
                        /*
                         * Start Change - 2017-04-19 - LBallo - CCB-CC-005.5
                         */
                        //CmKubraAllUser_DTO dto = createDTO(CmKubraAllUser.class); 

                        //dto.setId(new CmKubraAllUser_Id(accountNum, eBiller));
                        //dto.setFirstName(firstName);
                        //dto.setLastName(lastName);                        
                        //try {
                        //    dto.setEnrolledOn(DATE_FORMAT.parseDate(enrollDate));
                        //} catch (DateFormatParseException e) {
                        //    /*
                        //     * Start Change - JPunza - Defect 1201
                        //     */
                        //    //logErrorMessage(CustomMessageRepositoryMDC.NI0019_1_dateFormatInvalid(
                        //    //        accountNum, eBiller, enrollDate));
                        //    if (logErrorMessage(CustomMessageRepositoryMDC.NI0019_1_dateFormatInvalid(
                        //            accountNum, eBiller, enrollDate)).isTrue()) {
                        //        break;
                        //    }
                        //    /*
                        //     * End Change - JPunza - Defect 1201
                        //     */
                        //    continue;
                        //}
                        //dto.setEmailAddress(email);
                        //dto.setUserName(userName);
                        //dto.setTurnOffPaper(turnOffPaper);
                        //dto.setToken1(token1);
                        
                    /*
                     * Start Delete - JPunza - Defect 1201
                     */ 
                    //try {
                    /*
                     * End Delete - JPunza - Defect 1201
                     */
                        //dto.newEntity();   
                        //recordsInserted++;
                        Date enrolledOnDate;
                        try {
                        	enrolledOnDate = DATE_FORMAT.parseDate(enrollDate);
                        } catch (DateFormatParseException e) {
                            /*
                             * Start Change - JPunza - Defect 1201
                             */
                            //logErrorMessage(CustomMessageRepositoryMDC.NI0019_1_dateFormatInvalid(
                            //        accountNum, eBiller, enrollDate));
                            if (logErrorMessage(CustomMessageRepositoryMDC.NI0019_1_dateFormatInvalid(
                                    accountNum, eBiller, enrollDate)).isTrue()) {
                                break;
                            }
                            /*
                             * End Change - JPunza - Defect 1201
                             */
                            continue;
                        }
                        
                        StringBuilder insertQuery = new StringBuilder();
                        insertQuery.append("Insert into ");
                        insertQuery.append(  "CM_KUBRA_ALL_USER ");
                        insertQuery.append(  "( ");
                        insertQuery.append(    "ACCT_ID, ");
                        insertQuery.append(    "CM_ENROLLED_VIA, ");
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        if(!isBlankOrNull(firstName)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656                            
                            insertQuery.append(    "FIRST_NAME, ");
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        if(!isBlankOrNull(lastName)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                            insertQuery.append(    "LAST_NAME, "); 
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                        insertQuery.append(    "CM_ENROLLED_ON, ");
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        if(!isBlankOrNull(email)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                        insertQuery.append(    "EMAILID, ");
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        if(!isBlankOrNull(userName)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                        insertQuery.append(    "USER_NAME, ");
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        if(!isBlankOrNull(turnOffPaper)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                        insertQuery.append(    "CM_TURN_OFF_PAPER, ");
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        if(!isBlankOrNull(token1)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                        insertQuery.append(    "CM_TOKEN1, ");
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                        insertQuery.append(    "VERSION ");
                        insertQuery.append(  ") values ( ");
                        insertQuery.append(    ":accountId, ");
                        insertQuery.append(    ":enrolledVia, ");
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        if(!isBlankOrNull(firstName)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656 
                            insertQuery.append(    ":firstName, ");
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        if(!isBlankOrNull(lastName)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                            insertQuery.append(    ":lastName, ");
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                        insertQuery.append(    ":enrolledOnDate, ");
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        if(!isBlankOrNull(email)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                            insertQuery.append(    ":emailId, ");
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        if(!isBlankOrNull(userName)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                            insertQuery.append(    ":userName, ");
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        if(!isBlankOrNull(turnOffPaper)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                            insertQuery.append(    ":turnOffPaper, ");
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        if(!isBlankOrNull(token1)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                            insertQuery.append(    ":token1, ");
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                        insertQuery.append(    "1 ");
                        insertQuery.append(") ");
                        
                        PreparedStatement insertSQL = createPreparedStatement(insertQuery.toString(), accountNum);
                        insertSQL.bindStringProperty("accountId", CmKubraAllUser.properties.accountId, accountNum);
                        insertSQL.bindStringProperty("enrolledVia", CmKubraAllUser.properties.enrolledVia, eBiller);
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        if(!isBlankOrNull(firstName)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                            insertSQL.bindStringProperty("firstName", CmKubraAllUser.properties.firstName, firstName);
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        if(!isBlankOrNull(lastName)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                            insertSQL.bindStringProperty("lastName", CmKubraAllUser.properties.lastName, lastName);
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                        insertSQL.bindDate("enrolledOnDate", enrolledOnDate);
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        if(!isBlankOrNull(email)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                            // CCB v2.6 Upgrade - 2018-07-31 - Start Change
                            //insertSQL.bindStringProperty("emailId", CmKubraAllUser.properties.accountId, email);
                            insertSQL.bindStringProperty("emailId", CmKubraAllUser.properties.emailAddress, email);
                            // CCB v2.6 Upgrade - 2018-07-31 - End Change
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        if(!isBlankOrNull(userName)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                            // CCB v2.6 Upgrade - 2018-07-31 - Start Change
                            //insertSQL.bindStringProperty("userName", CmKubraAllUser.properties.accountId, userName);
                            insertSQL.bindStringProperty("userName", CmKubraAllUser.properties.userName, userName);
                            // CCB v2.6 Upgrade - 2018-07-31 - End Change
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        if(!isBlankOrNull(turnOffPaper)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                            // CCB v2.6 Upgrade - 2018-07-31 - Start Change
                            //insertSQL.bindStringProperty("turnOffPaper", CmKubraAllUser.properties.accountId, turnOffPaper);
                            insertSQL.bindStringProperty("turnOffPaper", CmKubraAllUser.properties.turnOffPaper, turnOffPaper);
                            // CCB v2.6 Upgrade - 2018-07-31 - End Change
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        if(!isBlankOrNull(token1)){
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                            // CCB v2.6 Upgrade - 2018-07-31 - Start Change
                            //insertSQL.bindStringProperty("token1", CmKubraAllUser.properties.accountId, token1);
                            insertSQL.bindStringProperty("token1", CmKubraAllUser.properties.token1, token1);
                            // CCB v2.6 Upgrade - 2018-07-31 - End Change
                        //Start Add - 2017-07-19 - AMasil - Defect 3800656
                        }
                        //End Add - 2017-07-19 - AMasil - Defect 3800656
                        
                        insertSQL.execute();
                        insertSQL.close();
						recordsInserted++;
                        /*
                         * End Change - 2017-04-19 - LBallo - CCB-CC-005.5
                         */
                    } catch (ApplicationError ae) {
                        /*
                         * Start Change - JPunza - Defect 1201
                         */
                        //logErrorMessage(CustomMessageRepositoryMDC.NI0019_1_unableToAddRecord(
                        //        processedRecord + 1, ae.getServerMessage().getMessageText()));
                        if (logErrorMessage(CustomMessageRepositoryMDC.NI0019_1_unableToAddRecord(
                                processedRecord + 1, ae.getServerMessage().getMessageText())).isTrue()) {
                            break;
                        }
                        /*
                         * End Change - JPunza - Defect 1201
                         */
                        continue;
                    }
                    saveChanges();
                }
                
                bufferedReader.close();
            } catch (IOException ie) {
                addError(CustomMessageRepositoryMDC.NI0019_1_errorWhileAccessingFile(ie.getMessage().trim()));
            }
                        
            WorkUnitResult result = new WorkUnitResult(true);
            result.setUnitsProcessed(processedRecord);
            result.setUnitsInError(recordInError);
          //IM-34846. Change Parameter usage - Start
            logInfo(CustomMessageRepositoryMDC.NI0019_1_totalRecordsInserted(recordsInserted));
          //IM-34846. Change Parameter usage - End
            
            
                        
            return result;
        }
        
        /**
         * This method logs message and checks if the max error has been reached.
         * @param message - ServerMessage
         */
        /*
         * Start Change - JPunza - Defect 1201
         */
        //private void logErrorMessage(ServerMessage message) {
        private Bool logErrorMessage(ServerMessage message) {
        /*
         * End Change - JPunza - Defect 1201
         */    
            logError(message);
            recordInError++;
            
            if (notNull(maxErrors) && recordInError == maxErrors.intValue()) {
                /*
                 * Start Change - JPunza - Defect 1201
                 */
                //addError(CustomMessageRepositoryMDC.NI0019_1_maxErrorReached(maxErrors));
                logError(CustomMessageRepositoryMDC.NI0019_1_maxErrorReached(maxErrors));
                
                return Bool.TRUE;
                /*
                 * End Change - JPunza - Defect 1201
                 */
            }
            
            /*
             * Start Add - JPunza - Defect 1201
             */
            return Bool.FALSE;
            /*
             * End Add - JPunza - Defect 1201
             */
        }
        
    }

}
