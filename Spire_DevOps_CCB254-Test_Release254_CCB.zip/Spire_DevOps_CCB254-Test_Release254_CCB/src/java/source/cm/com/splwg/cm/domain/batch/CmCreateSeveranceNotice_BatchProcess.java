/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * CCB020.3 - Create Severance Notice Batch
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:              Reason:
 * YYYY-MM-DD   IN               Reason text.
 * 2021-03-24   PCayab          CCB020.3. Initial Version  
 * 2021-04-22   PCayab          CCB020.Issue1. Re-initialize the Work Calendar 
 * 2021-08-04   RDizon          CCB020.Issue7. Use separate Customer Contact
 *                              Type for Small Commercial.
 * 2021-08-06   NMendo          CCB020.Issue8. Initialize soft parameters and
 *                              work variables in inner class.
 * 2021-08-09   NMendo          CCB020.Issue9. Get arrears with age >= 30.
 * 2021-08-11   NMendo          CCB020.Issue10. Log warning if the bill has no
 *                              previous bill.
 * 2021-10-21   JMeden          Defect 4608039. Additional condition to Main
 *                              SQL. Due Date must be greater than the 
 *                              process date. Use the Latest bill as the value
 *                              of Last Warning Characteristic 
 * 2021-12-02   RDizon          Defect 4621945. In computing arrears, use
 *                              Bill Date as reference date, and previous
 *                              Bill Date as credit Reference Date. 
 * 2022-01-25   NMendo          Defect 389348. Exclude Limiting SA when 
 *                              calculating for arrears amount.
 * 2022-02-16   JVitug          Defect 389348. Updated Limiting validation 
 *                              to validate the SA regardless
 *                              of CIS Division
 * 2022-06-17   JTiozon         CCB047. Updated to align MO severance.
 * 2022-09-01   JHERNA          B-23365. Updated after MO Severance review. 
 * 2022-11-08   Kiran           use LPC date for MO   
 * 2025-03-04	EQuint			B-37616. create last warning CC with state not "open"   
 * 2025-03-05   DHuynh          B-36764 Stop disconnect notice for MO. CMDNPWRN      
 * 2025-06-26	EQuint          B-40031. Do not create M-POST FA when a completed one
 * 								exists since the latest bill completion       
 * 2026-07-09   JVitug          INC0083589. Updated the getJobWork() SQL and added bill period filter
 *                              when checking if a Disconnection Warning Letter
 *                              has been created for an account.   
 **************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Time;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.workCalendar.WorkCalendar;
import com.splwg.base.domain.common.workCalendar.WorkCalendar_Id;
import com.splwg.ccb.api.lookup.ArrearsCollectionLimitOptionLookup;
import com.splwg.ccb.api.lookup.ArrearsInformationSourceLookup;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.BillStatusLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.CustomerContactStatusLookup;
import com.splwg.ccb.api.lookup.FieldActivityCreatedByLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.SeveranceStatusLookup;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.entity.FieldActivityCancelReason;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactLog_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_Id;
import com.splwg.ccb.domain.customerinfo.data.ArrearsInfoArrearsCollection;
import com.splwg.ccb.domain.customerinfo.data.ArrearsInfoParameters;
import com.splwg.ccb.domain.customerinfo.data.ArrearsInfoResults;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristics;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCancelProcessorData;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.cm.api.lookup.BillFormatLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

// Start Change JTiozon - CCB047 - 06-17-2021
// Start Change - RDizon - CCB020.Issue7 - 08-04-2021
///**
// * @author Administrator
// *
//@BatchJob (modules={},
// *            softParameters = { @BatchJobSoftParameter (name = NUM_OF_DAYS, required = true, type = integer)
// *            , @BatchJobSoftParameter (entityName = billMessageType, name = BILL_MSG_CD, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = AMT_THRESHOLD, required = true, type = decimal)
// *            , @BatchJobSoftParameter (name = DISC_WARN_CC_TYPE, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = customerContactClass, name = DISC_WARN_CC_CLASS, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = LAST_WARN_CC_TYPE, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = customerContactClass, name = LAST_WARN_CC_CLASS, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = COLL_AMT_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = BILL_ID_CHAR_TYPE, required = true, type = entity)})
// */
///**
// * @author Administrator
// *
//@BatchJob (modules={},
// *            softParameters = { @BatchJobSoftParameter (name = NUM_OF_DAYS, required = true, type = integer)
// *            , @BatchJobSoftParameter (entityName = billMessageType, name = BILL_MSG_CD, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = AMT_THRESHOLD, required = true, type = decimal)
// *            , @BatchJobSoftParameter (name = DISC_WARN_CC_TYPE, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = customerContactClass, name = DISC_WARN_CC_CLASS, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = VALID_SA_TYPES_FOR_LWC_RES, required = true, type = string)
// *            , @BatchJobSoftParameter (name = LAST_WARN_CC_TYPE_RES, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = customerContactClass, name = LAST_WARN_CC_CLASS_RES, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = VALID_SA_TYPES_FOR_LWC_SCOM, required = true, type = string)
// *            , @BatchJobSoftParameter (name = LAST_WARN_CC_TYPE_SCOM, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = customerContactClass, name = LAST_WARN_CC_CLASS_SCOM, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = COLL_AMT_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = BILL_ID_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = LIMITING_SA_TYPES, type = string)})
// */
 // End Change - RDizon - CCB020.Issue7 - 08-04-2021
/**
 * @author Administrator
 *
@BatchJob (modules={},
 *            softParameters = { @BatchJobSoftParameter (name = NUM_OF_DAYS, required = true, type = integer)
 *            , @BatchJobSoftParameter (name = BILL_MSG_CD, required = true, type = string)
 *            , @BatchJobSoftParameter (name = AMT_THRESHOLD, required = true, type = decimal)
 *            , @BatchJobSoftParameter (name = DISC_WARN_CC_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = DISC_WARN_CC_CLASS, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = VALID_SA_TYPES_FOR_LWC_RES, required = true, type = string)
 *            , @BatchJobSoftParameter (name = LAST_WARN_CC_TYPE_RES, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = LAST_WARN_CC_CLASS_RES, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = VALID_SA_TYPES_FOR_LWC_SCOM, required = true, type = string)
 *            , @BatchJobSoftParameter (name = LAST_WARN_CC_TYPE_SCOM, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = LAST_WARN_CC_CLASS_SCOM, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = COLL_AMT_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = BILL_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = LIMITING_SA_TYPES, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = MULTI_BLDG_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = MULTI_BLDG_CHAR_VALUE, type = string)
 *            , @BatchJobSoftParameter (name = NDAYS_MO_MPOST_FA_CREATE, required = true, type = integer)
 *            , @BatchJobSoftParameter (entityName = fieldActivityType, name = FA_TYPE_MULTI_BLDG, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = AMT_THRESHOLD_CREATE_FA, required = true, type = decimal)
 *            , @BatchJobSoftParameter (name = LAST_WARN_CALL_CC_DAYS, required = true, type = integer)
 *            , @BatchJobSoftParameter (name = LAST_WARN_CALL_CC_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = LAST_WARN_CALL_CC_CLASS, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = AL_GULF_CIS_DIVISION, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MO_CIS_DIVISION, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = BILL_AMT_DUE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = ACCT_CREDIT_SCORE_THRESHOLD, required = true, type = integer)
 *            , @BatchJobSoftParameter (entityName = fieldActivityCancelReason, name = FA_CAN_REASON, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = FA_COMP_DT_CHAR_TYPE, required = true, type = entity)})
 */

//End Change JTiozon - CCB047 - 06-17-2021

public class CmCreateSeveranceNotice_BatchProcess extends
        CmCreateSeveranceNotice_BatchProcess_Gen {
    //Constants
    private String numOfDays = "NUM_OF_DAYS";
    private String amountThreshold = "AMT_THRESHOLD";
    private String discWarnCCType = "DISC_WARN_CC_TYPE";
    // Start Change - RDizon - CCB020.Issue7 - 08-04-2021
    // private String lastWarnCCType = "LAST_WARN_CC_TYPE";
    private String lastWarnCCTypeRes = "LAST_WARN_CC_TYPE_RES";
    private String lastWarnCCTypeSmCom = "LAST_WARN_CC_TYPE_COM";
    // End Change - RDizon - CCB020.Issue7 - 08-04-2021
    private String collectionAmountCharType = "COLL_AMT_CHAR_TYPE";
    private String billIdCharType = "BILL_ID_CHAR_TYPE";
    // Start Add - JTiozon - CCB047 - 06-17-2022
    private String multiBldgCharType = "MULTI_BLDG_CHAR_TYPE";
    private String nDAysMoMPostFaCreate ="NDAYS_MO_MPOST_FA_CREATE";
    private String amtThresholdCreateFa = "NDAYS_MO_MPOST_FA_CREATE";
    private String lastWarnCCdays = "LAST_WARN_CALL_CC_DAYS";
    private String lastWCallCCType = "LAST_WARN_CALL_CC_TYPE";
    private String alGulfCisDiv = "AL_GULF_CIS_DIVISION";
    private String moCisDiv = "MO_CIS_DIVISION";
    private String billAmtDueCharType = "BILL_AMT_DUE_CHAR_TYPE";
    private String acctCrScoreThreshold = "ACCT_CREDIT_SCORE_THRESHOLD";
    private String billMsgCode = "BILL_MSG_CD";
    // End Add - JTiozon - CCB047 - 06-17-2022
    // start add - EQuint - B-40031 - 2025-06-26
    private String faCompDtIdCharType = "FA_COMP_DT_CHAR_TYPE";
    // end add - EQuint - B-40031 - 2025-06-26
    // Soft Parameters
    private BigInteger parmNumberOfDays = null;
    // Start Change - JTiozon - CCB047 - 06-17-2022
    //private BillMessageType parmBillMessageCode = null;
    private String parmBillMessageCode = null;
    // End Change - JTiozon - CCB047 - 06-17-2022
    private BigDecimal parmAmountThreshold = BigDecimal.ZERO;
    private String parmDisconnectionLetterCCType = null;
    private CustomerContactClass parmDisconnectionLetterCCClass = null;
    // Start Change - RDizon - CCB020.Issue7 - 08-04-2021
    // private String parmLastWarningCCType = null;
    // private CustomerContactClass parmLastWarningCCClass = null;
    private String parmLastWarningCCTypeRes = null;
    private CustomerContactClass parmLastWarningCCClassRes = null;
    private String parmLastWarningCCTypeSmCom = null;
    private CustomerContactClass parmLastWarningCCClassSmCom = null;
    // End Change - RDizon - CCB020.Issue7 - 08-04-2021
    private CharacteristicType parmBillCharType = null;
    private CharacteristicType parmCollectionAmountCharType = null;
    // Start Add - JTiozon - CCB047 - 06-17-2022
    // start add - EQuint - B-40031 - 2025-06-26
    private CharacteristicType parmFaCompleteDateCharType = null;
    // end add - EQuint - B-40031 - 2025-06-26
    private CharacteristicType parmMultiBldgCharType = null;
    private String parmMultiBldgCharValue = null;
    private BigInteger parmNumberOfDaysMoMpostFaCreate = null;
    private BigDecimal parmAmountThresholdCreateFa = null;
    private BigInteger parmLastWarnCallCCDays = null;
    private String parmLastWarnCallCCType = null;
    private CustomerContactClass parmLastWarnCallCCClass = null;  
    private String parmAlGulfCisDivision = null;
    private String parmMoCisDivision = null;
    private CustomerContactType_Id lastWarnCallCCType = null;
    private CharacteristicType parmBillAmtDueCharType = null;  
    private BigInteger parmAcctCrScoreThreshold =  null;
    // End Add - JTiozon - CCB047 - 06-17-2022
    // Work Variables
    private CustomerContactType_Id discLetterContactType = null;
    // Start Change - RDizon - CCB020.Issue7 - 08-04-2021
    // private static CustomerContactType_Id lastWarningContactType = null;
    private CustomerContactType_Id lastWarningContactTypeRes = null;
    private CustomerContactType_Id lastWarningContactTypeSmCom = null;
    // End Change - RDizon - CCB020.Issue7 - 08-04-2021
    private WorkCalendar wrkCalendar;
    
    /**
     *  This method retrieves Batch Parameters variables and initializes the class variables
     */
    private void initializeSoftParams(){
        parmNumberOfDays = getParameters().getNUM_OF_DAYS();
        parmBillMessageCode = getParameters().getBILL_MSG_CD();
        parmAmountThreshold = getParameters().getAMT_THRESHOLD();
        parmDisconnectionLetterCCType = getParameters().getDISC_WARN_CC_TYPE();
        parmDisconnectionLetterCCClass = getParameters().getDISC_WARN_CC_CLASS();
        // Start Change - RDizon - CCB020.Issue7 - 08-04-2021
        // parmLastWarningCCType = getParameters().getLAST_WARN_CC_TYPE();
        // parmLastWarningCCClass = getParameters().getLAST_WARN_CC_CLASS();
        parmLastWarningCCTypeRes = getParameters().getLAST_WARN_CC_TYPE_RES();
        parmLastWarningCCClassRes = getParameters().getLAST_WARN_CC_CLASS_RES();
        parmLastWarningCCTypeSmCom = getParameters().getLAST_WARN_CC_TYPE_SCOM();
        parmLastWarningCCClassSmCom = getParameters().getLAST_WARN_CC_CLASS_SCOM();
        // End Change - RDizon - CCB020.Issue7 - 08-04-2021
        parmBillCharType = getParameters().getBILL_ID_CHAR_TYPE();
        parmCollectionAmountCharType = getParameters().getCOLL_AMT_CHAR_TYPE();
        
        // start add - EQuint - B-40031 - 2025-06-26
        parmFaCompleteDateCharType = getParameters().getFA_COMP_DT_CHAR_TYPE();
        // end add - EQuint - B-40031 - 2025-06-26
        
        WorkCalendar_Id wrkCalendarId = new WorkCalendar_Id("LGC");
        wrkCalendar = wrkCalendarId.getEntity();
        
        // Start Add - JTiozon - CCB047 - 06-17-2022
        parmMultiBldgCharType = getParameters().getMULTI_BLDG_CHAR_TYPE();
        parmMultiBldgCharValue = getParameters().getMULTI_BLDG_CHAR_VALUE();
        parmNumberOfDaysMoMpostFaCreate = getParameters().getNDAYS_MO_MPOST_FA_CREATE();       
        parmAmountThresholdCreateFa = getParameters().getAMT_THRESHOLD_CREATE_FA();
        parmLastWarnCallCCDays = getParameters().getLAST_WARN_CALL_CC_DAYS();
        parmLastWarnCallCCType = getParameters().getLAST_WARN_CALL_CC_TYPE();
        parmLastWarnCallCCClass =  getParameters().getLAST_WARN_CALL_CC_CLASS();
        parmAlGulfCisDivision = getParameters().getAL_GULF_CIS_DIVISION();
        parmMoCisDivision = getParameters().getMO_CIS_DIVISION();
        parmBillAmtDueCharType = getParameters().getBILL_AMT_DUE_CHAR_TYPE(); 
        parmAcctCrScoreThreshold = getParameters().getACCT_CREDIT_SCORE_THRESHOLD();
        // End Add - JTiozon - CCB047 - 06-17-2022
    }
    
    // Validate Soft Parameters
    @Override
    public void validateSoftParameters(boolean isNewRun) {
        initializeSoftParams();
        //Check if the Number of days parameter is a valid number
        if(parmNumberOfDays.signum() == -1){
            addError(CustomMessageRepositorySpireOne.CCB020_3_batchParmInvalidNumber(numOfDays, parmNumberOfDays.toString()));
        }
        
        //Check if the Amount Threshold parameter is a valid number
        if(parmAmountThreshold.signum() == -1){
            addError(CustomMessageRepositorySpireOne.CCB020_3_batchParmInvalidNumber(amountThreshold, parmAmountThreshold.toString()));
        }
        
        //Check if the Customer Contact Type is valid
        discLetterContactType = new CustomerContactType_Id(parmDisconnectionLetterCCClass,parmDisconnectionLetterCCType);
        if(isNull(discLetterContactType.getEntity())){
            addError(CustomMessageRepositorySpireOne.CCB020_3_batchParmInvalidCCType(discWarnCCType,
                    parmDisconnectionLetterCCType.trim(), parmDisconnectionLetterCCClass.getId().getTrimmedValue()));
        }
        
        //Check if the Customer Contact Type is valid
        // Start Change - RDizon - CCB020.Issue7 - 08-04-2021
        // lastWarningContactType = new CustomerContactType_Id(parmLastWarningCCClass,parmLastWarningCCType);
        // if(isNull(lastWarningContactType.getEntity())){
        lastWarningContactTypeRes = new CustomerContactType_Id(parmLastWarningCCClassRes,parmLastWarningCCTypeRes);
        if(isNull(lastWarningContactTypeRes.getEntity())){
             addError(CustomMessageRepositorySpireOne.CCB020_3_batchParmInvalidCCType(lastWarnCCTypeRes,
                    // parmLastWarningCCType.trim(), parmLastWarningCCClass.getId().getTrimmedValue()));
                    parmLastWarningCCTypeRes.trim(), parmLastWarningCCClassRes.getId().getTrimmedValue()));
        }
        
        lastWarningContactTypeSmCom = new CustomerContactType_Id(parmLastWarningCCClassSmCom,parmLastWarningCCTypeSmCom);
        if(isNull(lastWarningContactTypeSmCom.getEntity())){
            addError(CustomMessageRepositorySpireOne.CCB020_3_batchParmInvalidCCType(lastWarnCCTypeSmCom,
                    parmLastWarningCCTypeSmCom.trim(), parmLastWarningCCClassSmCom.getId().getTrimmedValue()));
        }
        // End Change - RDizon - CCB020.Issue7 - 08-04-2021
        
        // Check if Characteristic Type is valid for the Customer Contact entity
        CharacteristicEntity colAmtCharEntity = new CharacteristicEntity_Id(parmCollectionAmountCharType, 
                CharacteristicEntityLookup.constants.CUSTOMER_CONTACT).getEntity();
        if (isNull(colAmtCharEntity)) {
            addError(CustomMessageRepositorySpireOne.CCB020_3_batchParmInvalidCharTypeForEntity(
                    collectionAmountCharType, parmCollectionAmountCharType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.CUSTOMER_CONTACT.getLookupValue().getEffectiveDescription()));
        }
        
        // Check if Characteristic Type is valid for the Customer Contact entity
        CharacteristicEntity saCharEntity = new CharacteristicEntity_Id(parmBillCharType, 
                CharacteristicEntityLookup.constants.CUSTOMER_CONTACT).getEntity();
        if (isNull(saCharEntity)) {
            addError(CustomMessageRepositorySpireOne.CCB020_3_batchParmInvalidCharTypeForEntity(
                        billIdCharType, parmBillCharType.getId().getTrimmedValue(),
                        CharacteristicEntityLookup.constants.CUSTOMER_CONTACT.getLookupValue().getEffectiveDescription()));
        }
        
        // start add - EQuint - B-40031 - 2025-06-26
        CharacteristicEntity faCharEntity = new CharacteristicEntity_Id(parmFaCompleteDateCharType, 
                CharacteristicEntityLookup.constants.FIELD_ACTIVITY).getEntity();
        if (isNull(faCharEntity)) {
            addError(CustomMessageRepositorySpireOne.CCB020_3_batchParmInvalidCharTypeForEntity(
            		faCompDtIdCharType, parmFaCompleteDateCharType.getId().getTrimmedValue(),
                        CharacteristicEntityLookup.constants.FIELD_ACTIVITY.getLookupValue().getEffectiveDescription()));
        }
        // end add - EQuint - B-40031 - 2025-06-26
        
        // Start Add - JTiozon - CCB047 - 06-17-2022
        //Validate Bill Message Codes
        String[] billMsgCodes = parmBillMessageCode.trim().split(",");
        for(String value : billMsgCodes){
        	BillMessageType_Id billMsgType = new BillMessageType_Id(value);
        	if(isNull(billMsgType.getEntity())){
        		addError(CustomMessageRepositorySpireOne.CCB047_invalidBillMsgCode(billMsgCode, value));
        	}
        }
        
        //Check if multi-building char type value is valid for the multi-building char type
        CharacteristicValue_Id charValue = new CharacteristicValue_Id(parmMultiBldgCharType, parmMultiBldgCharValue);
        if(isNull(charValue.getEntity())){
        	addError(CustomMessageRepositorySpireOne.CCB047_ParameterMustBeValidCharValueForCharType(multiBldgCharType, parmMultiBldgCharValue, parmMultiBldgCharType.getId().getTrimmedValue()));
        }
        
        //Check if the Number of Days MO M-POST FA creation parameter is a positive number
        if(parmNumberOfDaysMoMpostFaCreate.signum() == -1){
            addError(CustomMessageRepositorySpireOne.CCB020_3_batchParmInvalidNumber(nDAysMoMPostFaCreate, parmNumberOfDaysMoMpostFaCreate.toString()));
        }
        
        //Check if Amount threshold in creating FA is a positive number        
        if(parmAmountThresholdCreateFa.signum() == -1){
            addError(CustomMessageRepositorySpireOne.CCB020_3_batchParmInvalidNumber(amtThresholdCreateFa, parmAmountThresholdCreateFa.toString()));
        }
        //Check if the Last Warning CC days parameter is a positive number
        if(parmLastWarnCallCCDays.signum() == -1){
            addError(CustomMessageRepositorySpireOne.CCB020_3_batchParmInvalidNumber(lastWarnCCdays, parmLastWarnCallCCDays.toString()));
        }
        
        //Check if the Last Warning Call Customer Contact Type is valid
        lastWarnCallCCType = new CustomerContactType_Id(parmLastWarnCallCCClass,parmLastWarnCallCCType);
        if(isNull(lastWarnCallCCType.getEntity())){
             addError(CustomMessageRepositorySpireOne.CCB020_3_batchParmInvalidCCType(lastWCallCCType,                   
            		 parmLastWarnCallCCType.trim(), parmLastWarnCallCCClass.getId().getTrimmedValue()));
        }
        
        //Check if the CIS division(s) are valid
        String[] alGulfCisDivArr = parmAlGulfCisDivision.trim().split(",");
        for(String value : alGulfCisDivArr){
        	
        	CisDivision_Id cisDiv = new CisDivision_Id(value);
        	if(isNull(cisDiv.getEntity())){
        		addError(CustomMessageRepositorySpireOne.CCB047_invalidCisDivision(alGulfCisDiv, value));
        	}
        }
        
        String[] moCisDivArr = parmMoCisDivision.trim().split(",");
        for(String value : moCisDivArr){
        	
        	CisDivision_Id cisDiv = new CisDivision_Id(value);
        	if(isNull(cisDiv.getEntity())){
        		addError(CustomMessageRepositorySpireOne.CCB047_invalidCisDivision(moCisDiv, value));
        	}
        }
        
        // Check if Bill Amount Due parameter is valid for Customer Contact entity.
        CharacteristicEntity billAmtCharEntity = new CharacteristicEntity_Id(parmBillAmtDueCharType, 
                CharacteristicEntityLookup.constants.CUSTOMER_CONTACT).getEntity();
        if (isNull(billAmtCharEntity)) {
            addError(CustomMessageRepositorySpireOne.CCB020_3_batchParmInvalidCharTypeForEntity(
                        billAmtDueCharType, parmBillAmtDueCharType.getId().getTrimmedValue(),
                        CharacteristicEntityLookup.constants.CUSTOMER_CONTACT.getLookupValue().getEffectiveDescription()));
        }
        //Check if the Account Credit Score Threshold parameter is a valid number
        if(parmAcctCrScoreThreshold.signum() == -1){
            addError(CustomMessageRepositorySpireOne.CCB020_3_batchParmInvalidNumber(acctCrScoreThreshold, parmAcctCrScoreThreshold.toString()));
        }       
        // End Add - JTiozon - CCB047 - 06-17-2022
    }
        
    @Override
    public JobWork getJobWork() {
        QueryIterator mainIter = retrieveAccounts().iterate();
        return createJobWorkForQueryIterator(mainIter, this);
    }
    
    private PreparedStatement retrieveAccounts(){
        StringBuilder getAccountsQueryStr = new StringBuilder();
        getAccountsQueryStr.append("SELECT ACCT.ACCT_ID, BILL.BILL_ID, ACTPER.PER_ID ");
        getAccountsQueryStr.append("FROM CI_ACCT ACCT, CI_BILL BILL, CI_BILL_MSGS BMSG, CI_ACCT_PER ACTPER ");
        getAccountsQueryStr.append("WHERE ACCT.ACCT_ID = ACTPER.ACCT_ID ");
        getAccountsQueryStr.append("AND ACTPER.MAIN_CUST_SW = :mainCustomer ");
        getAccountsQueryStr.append("AND BILL.ACCT_ID = ACCT.ACCT_ID ");
        getAccountsQueryStr.append("AND BILL.BILL_ID = BMSG.BILL_ID ");
        // Start Add - JTiozon - CCB047 - 06-17-2022
        String billMessageCodes = buindSqlInParam(parmBillMessageCode);
        // End Add - JTiozon - CCB047 - 06-17-2022  
        // Start Change - JTiozon - CCB047 - 06-17-2022
        //getAccountsQueryStr.append("AND BMSG.BILL_MSG_CD = :billMessageCode ");
        getAccountsQueryStr.append("AND BMSG.BILL_MSG_CD IN (" + billMessageCodes + ") ");
        // End Change - JTiozon - CCB047 - 06-17-2022
        // Start Add - JMeden - Defect 4608039 - 2021-10-21
        getAccountsQueryStr.append("AND (BILL.DUE_DT > :batchProcessDate or BILL.LATE_PAY_CHARGE_DT > :batchProcessDate) ");
        // End Add - JMeden - Defect 4608039 - 2021-10-21
        getAccountsQueryStr.append("AND BILL.COMPLETE_DTTM = ");
        getAccountsQueryStr.append("    (SELECT MAX(BILL2.COMPLETE_DTTM) "); 
        getAccountsQueryStr.append("    FROM CI_BILL BILL2 ");
        getAccountsQueryStr.append("    WHERE BILL2.ACCT_ID = ACCT.ACCT_ID and BILL_STAT_FLG = :complete) ");
        // Start Delete - NMendo - CCB020.Issue9 - 2021-08-09
        //getAccountsQueryStr.append("AND :amountThreshold < ");
        //getAccountsQueryStr.append("    (SELECT SUM(BSA.CUR_AMT) ");
        //getAccountsQueryStr.append("    FROM CI_BILL_SA BSA, CI_BILL BILL2 ");
        //getAccountsQueryStr.append("    WHERE BSA.BILL_ID = BILL2.BILL_ID ");
        //getAccountsQueryStr.append("    AND BILL2.ACCT_ID = ACCT.ACCT_ID ");
        //getAccountsQueryStr.append("    AND BILL2.COMPLETE_DTTM = ");
        //getAccountsQueryStr.append("        (SELECT MAX(BILL3.COMPLETE_DTTM) ");
        //getAccountsQueryStr.append("        FROM CI_BILL BILL3 ");
        //getAccountsQueryStr.append("        WHERE BILL3.ACCT_ID = ACCT.ACCT_ID ");
        //getAccountsQueryStr.append("        AND BILL3.COMPLETE_DTTM < BILL.COMPLETE_DTTM)) ");
        // End Delete - NMendo - CCB020.Issue9 - 2021-08-09
        getAccountsQueryStr.append("AND (BILL.COMPLETE_DTTM + :numOfDays < :nextProcessDate ");
        getAccountsQueryStr.append("    OR (ACTPER.BILL_FORMAT_FLG = :eBill ");
        getAccountsQueryStr.append("        AND TRUNC(BILL.COMPLETE_DTTM) = :processDate");
        getAccountsQueryStr.append("        AND NOT EXISTS  ");
        getAccountsQueryStr.append("            (SELECT 'X' FROM CI_CC CC ");
        getAccountsQueryStr.append("            WHERE CC.PER_ID = ACTPER.PER_ID ");
        getAccountsQueryStr.append("            AND CC.CC_TYPE_CD = :disconnectLetterCCType ");
        //Start Add JVitug - INC0083589 - 2026-07-09
        //Only exclude accounts that did not have a disconnection letter for its latest Bill.
        getAccountsQueryStr.append("            AND CC.CC_DTTM > BILL.COMPLETE_DTTM ");
        //End Add JVitug - INC0083589 - 2026-07-09
        getAccountsQueryStr.append("            AND CC.CC_CL_CD = :disconnectLetterCCClass))) ");
        // Start Delete - JTiozon - CCB047 - 06-17-2022
        //getAccountsQueryStr.append("AND NOT EXISTS ");
        //getAccountsQueryStr.append("  (SELECT 'X' FROM CI_CC CC ");
        //getAccountsQueryStr.append("    WHERE CC.PER_ID = ACTPER.PER_ID ");
        // Start Change - RDizon - CCB020.Issue7 - 08-04-2021
        // getAccountsQueryStr.append("    AND CC.CC_TYPE_CD = :lastWarningCCType ");
        // getAccountsQueryStr.append("    AND CC.CC_CL_CD = :lastWarningCCClass ");
        //getAccountsQueryStr.append("    AND CC.CC_TYPE_CD = :lastWarningCCTypeRes ");
        //getAccountsQueryStr.append("    AND CC.CC_CL_CD = :lastWarningCCClassRes ");
        // End Change - RDizon - CCB020.Issue7 - 08-04-2021
        //getAccountsQueryStr.append("    AND CC.CC_DTTM > BILL.COMPLETE_DTTM) ");
        // End Delete - JTiozon - CCB047 - 06-17-2022
        // Start Add - RDizon - CCB020.Issue7 - 08-04-2021
        // Start Delete - JTiozon - CCB047 - 06-17-2022
        //getAccountsQueryStr.append("AND NOT EXISTS ");
        //getAccountsQueryStr.append("  (SELECT 'X' FROM CI_CC CC ");
        //getAccountsQueryStr.append("    WHERE CC.PER_ID = ACTPER.PER_ID ");
        //getAccountsQueryStr.append("    AND CC.CC_TYPE_CD = :lastWarningCCTypeSmCom ");
        //getAccountsQueryStr.append("    AND CC.CC_CL_CD = :lastWarningCCClassSmCom ");
        //getAccountsQueryStr.append("    AND CC.CC_DTTM > BILL.COMPLETE_DTTM) ");
        // End Add - RDizon - CCB020.Issue7 - 08-04-2021
        // End Delete - JTiozon - CCB047 - 06-17-2022
        // Start Add - JTiozon - CCB047 - 06-17-2022
        String alGulfCisDiv = buindSqlInParam(parmAlGulfCisDivision);
        getAccountsQueryStr.append("AND ((ACCT.CIS_DIVISION IN (" + alGulfCisDiv + ") ");
        getAccountsQueryStr.append(			"AND NOT EXISTS  ");
        getAccountsQueryStr.append(			"(SELECT 'X' FROM CI_CC CC ");
        getAccountsQueryStr.append(			"WHERE CC.PER_ID = ACTPER.PER_ID ");
        getAccountsQueryStr.append(				"AND CC.CC_TYPE_CD = :lastWarningCCTypeRes ");
        getAccountsQueryStr.append(				"AND CC.CC_CL_CD = :lastWarningCCClassRes ");
        getAccountsQueryStr.append(				"AND CC.CC_DTTM > BILL.COMPLETE_DTTM) ");
        getAccountsQueryStr.append(			"AND NOT EXISTS ");
        getAccountsQueryStr.append(			"(SELECT 'X' FROM CI_CC CC ");
        getAccountsQueryStr.append(			"WHERE CC.PER_ID = ACTPER.PER_ID ");
        getAccountsQueryStr.append(				"AND CC.CC_TYPE_CD = :lastWarningCCTypeSmCom ");
        getAccountsQueryStr.append(				"AND CC.CC_CL_CD = :lastWarningCCClassSmCom ");
        getAccountsQueryStr.append(				"AND CC.CC_DTTM > BILL.COMPLETE_DTTM)) ");
        
        String moCisDiv = buindSqlInParam(parmMoCisDivision);
        /* START CHANGES - JHERNA - B-23365 - 2022-09-01 */
        /*getAccountsQueryStr.append(			"OR ACCT.CIS_DIVISION IN (" + moCisDiv + "))");*/        
        getAccountsQueryStr.append("OR (ACCT.CIS_DIVISION IN (" + moCisDiv + ")  "); 
        getAccountsQueryStr.append("        AND NOT EXISTS (SELECT 'X'  "); 
        getAccountsQueryStr.append("		                FROM CI_CC CC  "); 
        getAccountsQueryStr.append("						WHERE CC.PER_ID = ACTPER.PER_ID  ");
        getAccountsQueryStr.append("						AND CC.CC_CL_CD = :moLastWarnContactClass  ");
        getAccountsQueryStr.append("						AND CC.CC_TYPE_CD = :moLastWarnContactType  ");							
        getAccountsQueryStr.append("						AND CC.CC_DTTM > BILL.COMPLETE_DTTM  ");
        getAccountsQueryStr.append("		                )  ");		
        getAccountsQueryStr.append("	   )  ");
        getAccountsQueryStr.append("	)  ");
        getAccountsQueryStr.append("AND ACCT.ACCT_ID = '1181041668' ");
        /* END CHANGES - JHERNA - B-23365 - 2022-09-01 */
        
        // End Add - JTiozon - CCB047 - 06-17-2022
        PreparedStatement accountsQueryPrepStmt = createPreparedStatement(getAccountsQueryStr.toString(), getClass().getName());
        // Start Delete - JTiozon - CCB047 - 06-17-2022
        //accountsQueryPrepStmt.bindEntity("billMessageCode", parmBillMessageCode);
        // End Delete - JTiozon - CCB047 - 06-17-2022
        // Start Delete - NMendo - CCB020.Issue9 - 2021-08-09
        //accountsQueryPrepStmt.bindBigDecimal("amountThreshold", parmAmountThreshold);
        // End Delete - NMendo - CCB020.Issue9 - 2021-08-09
        accountsQueryPrepStmt.bindLookup("complete", BillStatusLookup.constants.COMPLETE);
        accountsQueryPrepStmt.bindBigInteger("numOfDays", parmNumberOfDays);
        accountsQueryPrepStmt.bindDate("processDate", wrkCalendar.addBusinessDays(getProcessDateTime().getDate(), -1));
        accountsQueryPrepStmt.bindDate("nextProcessDate", getProcessDateTime().getDate().addDays(1));
        accountsQueryPrepStmt.bindBoolean("mainCustomer", Bool.TRUE);
        accountsQueryPrepStmt.bindLookup("eBill", BillFormatLookup.constants.EBILL);
        accountsQueryPrepStmt.bindStringProperty("disconnectLetterCCType",CustomerContactType.properties.contactType , discLetterContactType.getContactType());
        accountsQueryPrepStmt.bindId("disconnectLetterCCClass",  parmDisconnectionLetterCCClass.getId());
        // Start Change - RDizon - CCB020.Issue7 - 08-04-2021
        // accountsQueryPrepStmt.bindStringProperty("lastWarningCCType",CustomerContactType.properties.contactType , lastWarningContactType.getContactType());
        // accountsQueryPrepStmt.bindId("lastWarningCCClass",  parmLastWarningCCClass.getId());
        accountsQueryPrepStmt.bindStringProperty("lastWarningCCTypeRes",CustomerContactType.properties.contactType , lastWarningContactTypeRes.getContactType());
        accountsQueryPrepStmt.bindId("lastWarningCCClassRes",  parmLastWarningCCClassRes.getId());
        accountsQueryPrepStmt.bindStringProperty("lastWarningCCTypeSmCom",CustomerContactType.properties.contactType , lastWarningContactTypeSmCom.getContactType());
        accountsQueryPrepStmt.bindId("lastWarningCCClassSmCom",  parmLastWarningCCClassSmCom.getId());
        // End Change - RDizon - CCB020.Issue7 - 08-04-2021
        // Start Add - JMeden - Defect 4608039 - 2021-10-21
        accountsQueryPrepStmt.bindDate("batchProcessDate", getProcessDateTime().getDate());
        // End Add - JMeden - Defect 4608039 - 2021-10-21
        
        /* START CHANGES - JHERNA - B-23365 - 2022-09-01 */
        accountsQueryPrepStmt.bindId("moLastWarnContactClass", parmLastWarnCallCCClass.getId());
        accountsQueryPrepStmt.bindString("moLastWarnContactType", parmLastWarnCallCCType, "CC_TYPE_CD");
        /* END CHANGES - JHERNA - B-23365 - 2022-09-01 */

        return accountsQueryPrepStmt;
    } 
    
    // Start Add - JTiozon - CCB047 - 06-17-2022
    private String buindSqlInParam(String value){       
        
        StringTokenizer strTokenizer = new StringTokenizer(value, ",");
    	
        StringBuilder stringWithQuotes = new StringBuilder();
        while(strTokenizer.hasMoreElements()){
            stringWithQuotes.append("'" + strTokenizer.nextToken().trim()+"'");
            if(strTokenizer.hasMoreTokens()){
                stringWithQuotes.append(",");
            }
        }
        return stringWithQuotes.toString();
    }
    // End Add - JTiozon - CCB047 - 06-17-2022
    @Override
    public ThreadWorkUnit createWorkUnit(QueryResultRow row){
        ThreadWorkUnit threadUnit = new ThreadWorkUnit();
        Account_Id accountId = (Account_Id) row.getId("ACCT_ID", Account.class);
        threadUnit.setPrimaryId(accountId);
        threadUnit.addSupplementalData("BILL_ID", row.getId("BILL_ID", Bill.class));
        threadUnit.addSupplementalData("PER_ID", row.getId("PER_ID", Person.class));

        return threadUnit;
    }

    public Class<CmCreateSeveranceNotice_BatchProcessWorker> getThreadWorkerClass() {
        return CmCreateSeveranceNotice_BatchProcessWorker.class;
    }

    public static class CmCreateSeveranceNotice_BatchProcessWorker extends
            CmCreateSeveranceNotice_BatchProcessWorker_Gen {
   	
        // Start Add - NMendo - CCB020.Issue8 - 2021-08-06
        // Constants
        // Start Delete - RDizon - Defect 4621945 - 2021-12-02
        // private static final BigInteger ARS_DAYS = new BigInteger("30");.
        // End Delete - RDizon - Defect 4621945 - 2021-12-02
        // Start Add - NMendo - Defect 389348 - 2022-01-25
        private static final String COMMA = ",";
        private static final String SINGLE_QUOTE = "'";
        // End Add - NMendo - Defect 389348 - 2022-01-25
        // Start Add - JTiozon - CCB047 - 06-17-2022
        private static final String MGE = "MGE";
        // End Add - JTiozon - CCB047 - 06-17-2022
        // Soft Parameters
        private BigInteger parmNumberOfDays = null;
        private String parmValidSaTypesRes = null;
        private String parmValidSaTypesSmCom = null;
        private CharacteristicType parmBillCharType = null;
        private CharacteristicType parmCollectionAmountCharType = null;
        // start add - EQuint - B-40031 - 2025-06-26
        private CharacteristicType parmFaCompleteDateCharType = null;
        // end add - EQuint - B-40031 - 2025-06-26
        // Start Add - NMendo - CCB020.Issue9 - 2021-08-09
        private BigDecimal parmAmountThreshold = BigDecimal.ZERO;
        // End Add - NMendo - CCB020.Issue9 - 2021-08-09
        // Start Add - NMendo - Defect 389348 - 2022-01-25
        private String parmLimitingSATypes = null;
        // End Add - NMendo - Defect 389348 - 2022-01-25        
        // Start Add - JTiozon - CCB047 - 06-17-2022
        private FieldActivityType parmFaTypeMultiBldg = null;
        private CharacteristicType parmMultiBldgCharType = null;
        private String parmMultiBldgCharValue = null;
        private BigInteger parmNumberOfDaysMoMpostFaCreate = null;
        private BigInteger parmLastWarnCallCCDays = null;
        private String parmLastWarnCallCCType = null;
        private CustomerContactClass parmLastWarnCallCCClass = null;  
        private String parmAlGulfCisDivision = null;
        private String parmMoCisDivision = null;
        private CustomerContactType_Id lastWarnCallCCType = null;
        private CharacteristicType parmBillAmtDueCharType = null;
        private CustomerContactClass parmLastWarningCCClassRes = null;     
        private CustomerContactClass parmLastWarningCCClassSmCom = null;
        private BigInteger parmAcctCreditScoreThreshold = null;
        private FieldActivityCancelReason faCancelReason = null;
        // End Add - JTiozon - CCB047 - 06-17-2022
        // Work Variables
        private CustomerContactType_Id discLetterContactType = null;
        private CustomerContactType_Id lastWarningContactTypeRes = null;
        private CustomerContactType_Id lastWarningContactTypeSmCom = null;
        private WorkCalendar_Id wrkCalendarId;
        private WorkCalendar wrkCalendar;
        // End Add - NMendo - CCB020.Issue8 - 2021-08-06
        // Start Add - JTiozon - CCB047 - 06-17-2022
        String[] alGulfCisDiv;
        String[] moCisDiv;
        // End Add - JTiozon - CCB047 - 06-17-2022
       
        public ThreadExecutionStrategy createExecutionStrategy() {
            
            return new StandardCommitStrategy(this);
        }
        
        // Start Add - NMendo - CCB020.Issue8 - 2021-08-06
        @Override
        public void initializeThreadWork(boolean initializationPreviouslySuccessful) throws ThreadAbortedException, RunAbortedException {
            // Initialize Soft Parameters
            parmNumberOfDays = getParameters().getNUM_OF_DAYS();
            parmValidSaTypesRes = getParameters().getVALID_SA_TYPES_FOR_LWC_RES();
            parmValidSaTypesSmCom = getParameters().getVALID_SA_TYPES_FOR_LWC_SCOM();
            parmBillCharType = getParameters().getBILL_ID_CHAR_TYPE();
            parmCollectionAmountCharType = getParameters().getCOLL_AMT_CHAR_TYPE();
            // Start Add - NMendo - CCB020.Issue9 - 2021-08-09
            parmAmountThreshold = getParameters().getAMT_THRESHOLD();
            // End Add - NMendo - CCB020.Issue9 - 2021-08-09
            // Start Add - NMendo - Defect 389348 - 2022-01-25
            parmLimitingSATypes = getParameters().getLIMITING_SA_TYPES();
            // End Add - NMendo - Defect 389348 - 2022-01-25
            
            String parmDisconnectionLetterCCType = getParameters().getDISC_WARN_CC_TYPE();
            CustomerContactClass parmDisconnectionLetterCCClass = getParameters().getDISC_WARN_CC_CLASS();
            String parmLastWarningCCTypeRes = getParameters().getLAST_WARN_CC_TYPE_RES();
            // Start Change - JTiozon - CCB047 - 06-17-2022
            //CustomerContactClass parmLastWarningCCClassRes = getParameters().getLAST_WARN_CC_CLASS_RES();
            parmLastWarningCCClassRes = getParameters().getLAST_WARN_CC_CLASS_RES();
            String parmLastWarningCCTypeSmCom = getParameters().getLAST_WARN_CC_TYPE_SCOM();
            //CustomerContactClass parmLastWarningCCClassSmCom = getParameters().getLAST_WARN_CC_CLASS_SCOM();
            parmLastWarningCCClassSmCom = getParameters().getLAST_WARN_CC_CLASS_SCOM();
            // End Change - JTiozon - CCB047 - 06-17-2022
            
            // Initialize Work Variables
            discLetterContactType = new CustomerContactType_Id(parmDisconnectionLetterCCClass,parmDisconnectionLetterCCType);
            lastWarningContactTypeRes = new CustomerContactType_Id(parmLastWarningCCClassRes,parmLastWarningCCTypeRes);
            lastWarningContactTypeSmCom = new CustomerContactType_Id(parmLastWarningCCClassSmCom,parmLastWarningCCTypeSmCom);
            wrkCalendarId = new WorkCalendar_Id("LGC");
            wrkCalendar = wrkCalendarId.getEntity();
            
            // Start Add - JTiozon - CCB047 - 06-17-2022
            parmFaTypeMultiBldg = getParameters().getFA_TYPE_MULTI_BLDG();
            parmNumberOfDaysMoMpostFaCreate = getParameters().getNDAYS_MO_MPOST_FA_CREATE();
            parmMultiBldgCharType = getParameters().getMULTI_BLDG_CHAR_TYPE();
            parmMultiBldgCharValue = getParameters().getMULTI_BLDG_CHAR_VALUE();
            parmLastWarnCallCCDays = getParameters().getLAST_WARN_CALL_CC_DAYS();
            parmLastWarnCallCCType = getParameters().getLAST_WARN_CALL_CC_TYPE();
            parmLastWarnCallCCClass =  getParameters().getLAST_WARN_CALL_CC_CLASS();
            parmAlGulfCisDivision = getParameters().getAL_GULF_CIS_DIVISION();
            parmMoCisDivision = getParameters().getMO_CIS_DIVISION();
            alGulfCisDiv = parmAlGulfCisDivision.split(COMMA);
            moCisDiv = parmMoCisDivision.split(COMMA);
            parmBillAmtDueCharType = getParameters().getBILL_AMT_DUE_CHAR_TYPE();
            lastWarnCallCCType = new CustomerContactType_Id(parmLastWarnCallCCClass, parmLastWarnCallCCType);  
            parmAcctCreditScoreThreshold = getParameters().getACCT_CREDIT_SCORE_THRESHOLD();
            faCancelReason = getParameters().getFA_CAN_REASON();
            // End Add - JTiozon - CCB047 - 06-17-2022
            
            // start add - EQuint - B-40031 - 2025-06-26
            parmFaCompleteDateCharType = getParameters().getFA_COMP_DT_CHAR_TYPE();
            // end add - EQuint - B-40031 - 2025-06-26
           
        }
        // End Add - NMendo - CCB020.Issue8 - 2021-08-06
        
        @Override
        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
            Account_Id accountId;
            Bill_Id billId; 
            Person_Id perId;
            accountId = (Account_Id) unit.getPrimaryId();
            billId = (Bill_Id) unit.getSupplementallData("BILL_ID");
            perId = (Person_Id) unit.getSupplementallData("PER_ID");
            Bill bill = billId.getEntity();
            DateTime billCompleteDateTime = bill.getCompletedDatetime();
            Bool isEBill = Bool.TRUE;
            BigDecimal amount = BigDecimal.ZERO;
            // Start Add - NMendo - CCB020.Issue9 - 2021-08-09
            // Start Add - RDizon - Defect 4621945 - 2021-12-02
            
            // Start Change- JTiozon - CCB047 - 06-17-2022
            //Bill previousBill = getPreviousBill(accountId, billCompleteDateTime);
            
            //Date referenceDate = accountId.getEntity().getSetUpDate(); 
            //if (notNull(previousBill)){
            //   referenceDate = previousBill.getBillDate(); 
            //}
            Date referenceDate = bill.getBillDate();
            // End Change- JTiozon - CCB047 - 06-17-2022
            
            // End Add - RDizon - Defect 4621945 - 2021-12-02
            
            // Start Change - RDizon - Defect 4621945 - 2021-12-02
            // amount = getArrearsAmount(accountId.getEntity(), getProcessDateTime().getDate());
            amount = getArrearsAmount(accountId.getEntity(), referenceDate, getProcessDateTime().getDate());
            // End Change - RDizon - Defect 4621945 - 2021-12-02

            if(parmAmountThreshold.compareTo(amount) > 0) { 
                // Do not process Account if Arrears Amount is less than Threshold
                return true;
            }
            // End Add - NMendo - CCB020.Issue9 - 2021-08-09
            
            // Start Delete - JMeden - Defect 4608039 - 2021-10-21
            // Get the 2nd latest bill of the Account.
//            Bill previousBill = getPreviousBill(accountId, billCompleteDateTime);
//            
//            // Start Add - NMendo - CCB020.Issue10 - 2021-08-11
//            if(isNull(previousBill)) {
//              logWarning(CustomMessageRepositorySpireOne.CCB020_accountNoPreviousBill(
//                      accountId.getTrimmedValue(), billId.getTrimmedValue()));
//              return true;
//            }
            // End Add - NMendo - CCB020.Issue10 - 2021-08-11
            // End Delete - JMeden - Defect 4608039 - 2021-10-21    
            
            ListFilter<AccountPerson> acctPerLst = accountId.getEntity().getPersons().createFilter("where this.isMainCustomer = :MAIN_CUST_SW and this.billFormat = :eBill", "");
            acctPerLst.bindBoolean("MAIN_CUST_SW", Bool.TRUE);
            acctPerLst.bindLookup("eBill", BillFormatLookup.constants.EBILL);
            List<AccountPerson> acctPers = acctPerLst.list();
            if(isNull(acctPers) || acctPers.isEmpty()){
                isEBill = Bool.FALSE;
            }
            //Start Add-dhuynh 36764- 2025-03-06
            //move all codes section below to different block
            // Start Add - PCayab - CCB020.Issue1 - 04-22-2021
            //wrkCalendarId = new WorkCalendar_Id("LGC");
            //wrkCalendar = wrkCalendarId.getEntity();
            // End Add - PCayab - CCB020.Issue1 - 04-22-2021
            //Date adjustedDate = wrkCalendar.addBusinessDays(billCompleteDateTime.getDate(), 1);
            // Check if the Latest Bill's Completion Date + 1 Business Date is equal to the process date and if Account's Bill Format is E-Bill
            //if(isEBill.isTrue() && adjustedDate.equals(this.getProcessDateTime().getDate())){
                // Create the Customer Contact    
            	// start change -  EQuint - B-37616 - 2025-03-04
                // CustomerContact_Id ccId = createCustomerContact(perId, discLetterContactType); 
            	//CustomerContact_Id ccId = createCustomerContact(perId, discLetterContactType, CustomerContactStatusLookup.constants.OPEN); 
                // end change -  EQuint - B-37616 - 2025-03-04
                
                // Add a Customer Contact Log
               // createCcLog(ccId);
                
                // Start Delete - NMendo - CCB020.Issue9 - 2021-08-09
                // Get the Arrears Amount
                //amount = getArrearsAmount(accountId.getEntity(), previousBill.getCompletedDatetime().getDate());
                // End Delete - NMendo - CCB020.Issue9 - 2021-08-09

                //Add Customer Contact Characteristic for the Collection Amount
               // addCustomerContactChar(ccId,parmCollectionAmountCharType, amount.toString().trim());
                 
                //Add Customer Contact Characteristic for the Bill Id
                // Start Change - JMeden - Defect 4608039 - 2021-10-21  
                //addCustomerContactChar(ccId,parmBillCharType, previousBill.getId().getIdValue().trim());
               // addCustomerContactChar(ccId,parmBillCharType, billId.getIdValue().trim());
                // End Change - JMeden - Defect 4608039 - 2021-10-21
                
                // Start Add - JTiozon - CCB047 - 06-17-2022
                /*
                 * Add Bill Amount Due Characteristic
                 */
               // BigDecimal amountDue = getBillAmountDue(bill);
               // addCustomerContactChar(ccId,parmBillAmtDueCharType, amountDue.toString()); 
                // End Add - JTiozon - CCB047 - 06-17-2022
           // }
            
            //End Add-dhuynh 36764- 2025-03-06

            // Start Add - RDizon - CCB020.Issue7 - 08-04-2021           
            String validSaTypesRes = buildSaTypes(parmValidSaTypesRes);
            String validSaTypesSmCom = buildSaTypes(parmValidSaTypesSmCom);           
            // End Add - RDizon - CCB020.Issue7 - 08-04-2021
            
            // Start Add - JTiozon - CCB047 - 06-17-2022
            CisDivision_Id accountCisDiv = accountId.getEntity().getDivisionId();
            Bool isAlGulfCisDiv = Bool.FALSE;
            for(String cisDiv : alGulfCisDiv){
            	
            	if(accountCisDiv.getTrimmedValue().equals(cisDiv)){
            		isAlGulfCisDiv = Bool.TRUE;
            		continue;
            	}
            }
            
            Bool isMoCisDiv = Bool.FALSE;
            Bool isMge = Bool.FALSE;
            for(String cisDiv : moCisDiv){
            	
            	if(accountCisDiv.getTrimmedValue().equals(cisDiv)){
            		isMoCisDiv = Bool.TRUE;            		
            	}
            	
            	if(accountCisDiv.getIdValue().trim().equals(MGE)){
            		isMge = Bool.TRUE;            		
            	}
            }
            
            //Start Add-dhuynh 36764- 2025-03-06
            // Start Add - PCayab - CCB020.Issue1 - 04-22-2021
            wrkCalendarId = new WorkCalendar_Id("LGC");
            wrkCalendar = wrkCalendarId.getEntity();
            // End Add - PCayab - CCB020.Issue1 - 04-22-2021
            Date adjustedDate = wrkCalendar.addBusinessDays(billCompleteDateTime.getDate(), 1);
            // Check if the Latest Bill's Completion Date + 1 Business Date is equal to the process date and if Account's Bill Format is E-Bill
            //Start Add-dhuynh 36764- 2025-03-06
            if(isEBill.isTrue() && adjustedDate.equals(this.getProcessDateTime().getDate())&& isMoCisDiv.isFalse() ){
            //if(isEBill.isTrue() && adjustedDate.equals(this.getProcessDateTime().getDate() ){
            //End Add-dhuynh 36764- 2025-03-06

                // Create the Customer Contact    
            	// start change -  EQuint - B-37616 - 2025-03-04
                // CustomerContact_Id ccId = createCustomerContact(perId, discLetterContactType); 
            	CustomerContact_Id ccId = createCustomerContact(perId, discLetterContactType, CustomerContactStatusLookup.constants.OPEN); 
                // end change -  EQuint - B-37616 - 2025-03-04
                
                // Add a Customer Contact Log
                createCcLog(ccId);
                
                // Start Delete - NMendo - CCB020.Issue9 - 2021-08-09
                // Get the Arrears Amount
                //amount = getArrearsAmount(accountId.getEntity(), previousBill.getCompletedDatetime().getDate());
                // End Delete - NMendo - CCB020.Issue9 - 2021-08-09

                //Add Customer Contact Characteristic for the Collection Amount
                addCustomerContactChar(ccId,parmCollectionAmountCharType, amount.toString().trim());
                 
                //Add Customer Contact Characteristic for the Bill Id
                // Start Change - JMeden - Defect 4608039 - 2021-10-21  
                //addCustomerContactChar(ccId,parmBillCharType, previousBill.getId().getIdValue().trim());
                addCustomerContactChar(ccId,parmBillCharType, billId.getIdValue().trim());
                // End Change - JMeden - Defect 4608039 - 2021-10-21
                
                // Start Add - JTiozon - CCB047 - 06-17-2022
                /*
                 * Add Bill Amount Due Characteristic
                 */
                BigDecimal amountDue = getBillAmountDue(bill);
                addCustomerContactChar(ccId,parmBillAmtDueCharType, amountDue.toString()); 
                // End Add - JTiozon - CCB047 - 06-17-2022
            }
            //End Add-dhuynh 36764- 2025-03-06
            
            // End Add - JTiozon - CCB047 - 06-17-2022
            // Start Add - JTiozon - CCB047 - 06-17-2022
            if(isAlGulfCisDiv.isTrue()){  
	            // End Add - JTiozon - CCB047 - 06-17-2022
	            // Check if the Latest Bill's Completion Date + Number of days is equal or less than the process date
	            if(billCompleteDateTime.addDays(parmNumberOfDays.intValue()).getDate().isSameOrBefore(this.getProcessDateTime().getDate())){ 
	            	// Create the Customer Contact     
	            	// Start Change - RDizon - CCB020.Issue7 - 08-04-2021
	            	// CustomerContact_Id ccId = createCustomerContact(perId, lastWarningContactType);
	            	CustomerContact_Id ccId = null;
	            	Bool isSmComCustomer = checkBsegSAs(bill.getId(), validSaTypesSmCom);
	            	if (isSmComCustomer.isTrue()){
	            		// start change -  EQuint - B-37616 - 2025-03-04
	            		// ccId = createCustomerContact(perId, lastWarningContactTypeSmCom);
	            		ccId = createCustomerContact(perId, lastWarningContactTypeSmCom, null);
	            		// end change -  EQuint - B-37616 - 2025-03-04
	            	}
	            	else {
	            		Bool isResCustomer = checkBsegSAs(bill.getId(), validSaTypesRes);
	            		if (isResCustomer.isTrue()){
	            			// start change -  EQuint - B-37616 - 2025-03-04
	            			// ccId = createCustomerContact(perId, lastWarningContactTypeRes);
	            			ccId = createCustomerContact(perId, lastWarningContactTypeRes, null);
	            			// end change -  EQuint - B-37616 - 2025-03-04
	            		}    
	            	}
	            	// End Change - RDizon - CCB020.Issue7 - 08-04-2021
	
	            	// Start Add - RDizon - CCB020.Issue7 - 08-04-2021
	            	if (!isNull(ccId)){ 
	            	// End Add - RDizon - CCB020.Issue7 - 08-04-2021
	            	// Add a Customer Contact Log
	            	createCcLog(ccId);
	
	            	// Start Delete - NMendo - CCB020.Issue9 - 2021-08-09
	            	// Get the Arrears Amount
	            	//amount = getArrearsAmount(accountId.getEntity(), previousBill.getCompletedDatetime().getDate());
	            	// End Delete - NMendo - CCB020.Issue9 - 2021-08-09
	
	            	//Add Customer Contact Characteristic for the Collection Amount
	            	addCustomerContactChar(ccId,parmCollectionAmountCharType, amount.toString().trim());
	
	            	// Add Customer Contact Characteristic for the Bill Id
	            	// Start Change - JMeden - Defect 4608039 - 2021-10-21  
	            	//addCustomerContactChar(ccId,parmBillCharType, previousBill.getId().getIdValue().trim());
	            	addCustomerContactChar(ccId,parmBillCharType, billId.getIdValue().trim());
	            	// End Change - JMeden - Defect 4608039 - 2021-10-21
	
	
	            	// Start Add - RDizon - CCB020.Issue7 - 08-04-2021
	            	}
	            	// End Add - RDizon - CCB020.Issue7 - 08-04-2021
	            }	           
            // End Add - JTiozon - CCB047 - 06-17-2022
            }
            // End Add - JTiozon - CCB047 - 06-17-2022
            
            // Start Add - JTiozon - CCB047 - 06-17-2022
            if(isMoCisDiv.isTrue()){
            	if(billCompleteDateTime.addDays(parmLastWarnCallCCDays.intValue()).getDate().isSameOrBefore(this.getProcessDateTime().getDate())){
	                
            		Bill previousBill = getPreviousBill(accountId, billCompleteDateTime);
                    
                    Date refDate = accountId.getEntity().getSetUpDate(); 
                    if (notNull(previousBill)){
                    	refDate = previousBill.getBillDate(); 
                    }                  
                    BigDecimal collAmount = getArrearsAmount(accountId.getEntity(), refDate, getProcessDateTime().getDate());
                    
            		// Create the Customer Contact
                    // start change -  EQuint - B-37616 - 2025-03-04
	                // CustomerContact_Id ccId = createCustomerContact(perId,lastWarnCallCCType );
                    CustomerContact_Id ccId = createCustomerContact(perId, lastWarnCallCCType, null );
	                // end change -  EQuint - B-37616 - 2025-03-04
	              	              
	                if (!isNull(ccId)){	                
	                    // Add a Customer Contact Log
	                    createCcLog(ccId);
	                
	                    //Add Customer Contact Characteristic for the Collection Amount
	                    addCustomerContactChar(ccId,parmCollectionAmountCharType, collAmount.toString().trim());
	                            
	                    // Add Customer Contact Characteristic for the Bill Id	                  
	                    addCustomerContactChar(ccId,parmBillCharType, billId.getIdValue().trim());
	                    // End Change - JMeden - Defect 4608039 - 2021-10-21
	                    
	              
	                }
	               
	            }
            	
            	
            	if(isMge.isTrue()){ 
            		//Check if there is no existing Pending M-POST FA created with date after the latest completed bill that has DNP bill message and no active severance process
            		                	
                	DateTime latestBillComplDttm = bill.getCompletedDatetime();
                		
                		SQLResultRow resultRow = getSpAndSA(bill.getId());
                		
                		if(notNull(resultRow)){
                			ServicePoint sp = resultRow.getEntity("SP_ID", ServicePoint.class); 
                			ServiceAgreement sa = resultRow.getEntity("SA_ID", ServiceAgreement.class); 
                			
                			//Check for Pending M-POST FA
                			Bool faExist = Bool.FALSE;
                			FieldActivity fa = checkFaExist(sp.getId(), parmFaTypeMultiBldg, latestBillComplDttm.addDays(parmNumberOfDaysMoMpostFaCreate.intValue()));
                    		if(notNull(fa)){
                    			faExist = Bool.TRUE;
                    		}
                    		//Check for active severance process
                    		Bool sevProcessExist = checkActiveSeverance(sa); 
                    		Premise_Id premiseId = sa.getPremiseId();
                    		if(faExist.isFalse() && sevProcessExist.isFalse()){
                    			if(billCompleteDateTime.addDays(parmNumberOfDaysMoMpostFaCreate.intValue()).getDate().isSameOrBefore(this.getProcessDateTime().getDate())){
                    				//Check Multi-Building Premise Characteristic
                    				PremiseCharacteristics premChars = premiseId.getEntity().getCharacteristics();                    				
                    				
                    				ListFilter<PremiseCharacteristic> premCharsFilter = premChars.createFilter("where this.id.characteristicType = :multiBldgCharType "
                    																						+ "and this.id.effectiveDate <= :processDate "
                    																						+ "ORDER BY this.id.effectiveDate DESC", getClass().getName());
                    				premCharsFilter.bindEntity("multiBldgCharType", parmMultiBldgCharType);
                    				premCharsFilter.bindDate("processDate", this.getProcessDateTime().getDate());
                    				
                    				PremiseCharacteristic premChar = premCharsFilter.firstRow(); 
                    				
                    				if(notNull(premChar)){ 
                    					String premCharValue = "";
                    					if(parmMultiBldgCharType.getCharacteristicType().isPredefinedValue()){
                    						premCharValue = premChar.getCharacteristicValue().trim();
                    					}else if(parmMultiBldgCharType.getCharacteristicType().isAdhocValue()){
                    						premCharValue = premChar.getAdhocCharacteristicValue().trim();
                    					}else if(parmMultiBldgCharType.getCharacteristicType().isForeignKeyValue()){
                    						premCharValue = premChar.getCharacteristicValueForeignKey1().trim();
                    					}
                    					
                    					if(premCharValue.equals(parmMultiBldgCharValue.trim())){ 
                    						//Check account's credit score
                    						BigInteger creditRatingPoints = accountId.getEntity().getCreditRatingInfo(getProcessDateTime().getDate()).getCreditRatingPoints();
                    						
                    						if(creditRatingPoints.compareTo(parmAcctCreditScoreThreshold) <= 0){ 
                    							
                    							// start add - EQuint - B-40031 - 2025-06-26
                    							if(hasCompleteFaSinceDate(sp, latestBillComplDttm.getDate(), parmFaTypeMultiBldg).isFalse()) {
                    							// end add - EQuint - B-40031 - 2025-06-26
                    							
	                    							Date billCompletionDate = latestBillComplDttm.getDate().addDays(parmNumberOfDaysMoMpostFaCreate.intValue());                    							
	                    							Date adjustedFaSchDate = wrkCalendar.addBusinessDays(billCompletionDate, 1);
	                    							Time time = new Time(0, 0, 0);
	                    							DateTime scheduleDttm = new DateTime(adjustedFaSchDate, time);
	                    							
	                    							FieldActivity_DTO fieldActivityDTO = (FieldActivity_DTO)createDTO(FieldActivity.class);
	                    			                fieldActivityDTO.setFieldActivityTypeId(parmFaTypeMultiBldg.getId());
	                    			                fieldActivityDTO.setServicePointId(sp.getId());
	                    			                fieldActivityDTO.setScheduleDateTimeStart(scheduleDttm);
	                    			                fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);
	                    			                FieldActivityCreatorData faCreatorData = FieldActivityCreatorData.Factory.newInstance();
	                    			                faCreatorData.setFaDTO(fieldActivityDTO);
	
	                    			                FieldActivityCreator faCreator = FieldActivityCreator.Factory.newInstance();
	                    			                faCreator.addFieldActivity(faCreatorData);
                    			                
                    			                // start add - EQuint - B-40031 - 2025-06-26
                    							}
                    							// end add - EQuint - B-40031 - 2025-06-26
                    			               
                    						}
                    					}
                    				}
                    				
                    			}
                    		}
                    		
                    		if(faExist.isTrue()){ 
                    			DateTime faScheduleDttm = fa.getScheduleDateTimeStart();
                    			Bool hasCancelledSeverance = checkCancelledSeverance(sa, faScheduleDttm);
                    			
                    			if(hasCancelledSeverance.isTrue()){
                    				//Cancel M-POST FA
                    				 FieldActivityCancelProcessorData faCancelData = FieldActivityCancelProcessorData.Factory.newInstance();
                    	             faCancelData.setFieldActivity(fa);
                    	             faCancelData.setMustCancelDispatchedFa(Bool.TRUE);
                    	             faCancelData.setCancelReason(faCancelReason);                
                    	             fa.cancel(faCancelData); 
                    			}
                    		}
                		}
            	}
            }
            // End Add - JTiozon - CCB047 - 06-17-2022
            return true;
        }
        
        // start add - EQuint - B-40031 - 2025-06-26
        /**
         * Check if there exists a completed FA of a specific type and date
         * @param sp Service Point
         * @param fromDate from date
         * @param faType FA type
         * @return true if has completed FA since date
         */
        private Bool hasCompleteFaSinceDate(ServicePoint sp, Date fromDate, FieldActivityType faType) {
        	PreparedStatement stmt = createPreparedStatement("" 
        			+ "SELECT FA.FA_ID from CI_FA FA, CI_FA_CHAR FC "
                    + "WHERE FA.SP_ID = :spId "
                    + "AND FA.FA_ID = FC.FA_ID "
                    + "AND FA.FA_STATUS_FLG = :complete "
                    + "AND FA.FA_TYPE_CD = :faType "
                    + "AND FC.CHAR_TYPE_CD = :charType "
                    + "AND TO_DATE(FC.SRCH_CHAR_VAL, 'YYYY-MM-DD') BETWEEN :fromDt AND :toDt ", getClass().getName());
        	
        	stmt.bindId("spId", sp.getId());
        	stmt.bindLookup("complete", FieldActivityStatusLookup.constants.COMPLETED);
            stmt.bindId("faType", faType.getId());
            stmt.bindId("charType", parmFaCompleteDateCharType.getId());
            stmt.bindDate("fromDt", fromDate);
            stmt.bindDate("toDt", getProcessDateTime().getDate());
            SQLResultRow row = stmt.firstRow();

            stmt.close();
            
            return Bool.valueOf(notNull(row));
        }
        // end add - EQuint - B-40031 - 2025-06-26
        
        /**
         * Add a Customer Contact Characteristic
         * @param customerContactId
         * @param charType
         * @param charValue
         */
        private void addCustomerContactChar(CustomerContact_Id customerContactId, CharacteristicType charType, String charValue){
            CustomerContactCharacteristic_DTO customerContactCharDTO = new CustomerContactCharacteristic_DTO();
            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
            
            customerContactCharDTO.setId(new CustomerContactCharacteristic_Id( charType, customerContactId.getEntity()));
            if(charTypeLookup.isAdhocValue()){
                customerContactCharDTO.setAdhocCharacteristicValue(charValue);
            } else if (charTypeLookup.isPredefinedValue()){
                customerContactCharDTO.setCharacteristicValue(charValue);
            } else if (charTypeLookup.isForeignKeyValue()){
                customerContactCharDTO.setCharacteristicValueForeignKey1(charValue);
            }
            customerContactCharDTO.newEntity();
        }
        
        // Start Add - RDizon - Defect 4621945 - 2021-12-02
        // Start Delete - JMeden - Defect 4608039 - 2021-10-21  
        /**
         * Get the second to the last Bill of the Account
         * @param acctId
         * @param completeDttm
         * @return
         */
        private Bill getPreviousBill(Account_Id acctId, DateTime completeDttm){
            Bill_Id billId = null;
            Bill bill = null;
            PreparedStatement stmt = this.createPreparedStatement("" 
                    + " SELECT BILL.BILL_ID "
                    + " FROM CI_BILL BILL "
                    + " WHERE BILL.ACCT_ID = :accountId "
                    + " AND BILL.COMPLETE_DTTM = ( "
                    + " SELECT MAX(BILL2.COMPLETE_DTTM) "
                    + " FROM CI_BILL BILL2 "
                    + " WHERE BILL2.ACCT_ID = :accountId "
                    + " AND BILL2.COMPLETE_DTTM < :completeDttm)","");
            stmt.bindId("accountId", acctId);
            stmt.bindDateTime("completeDttm", completeDttm);
            SQLResultRow row = stmt.firstRow();
            if(!isNull(row)){
                billId = (Bill_Id) row.getId("BILL_ID", Bill.class);
                if(!isNull(billId.getEntity())){
                    bill = billId.getEntity();
                }
            }
            stmt.close();
            
            return bill;
        }
        // End Delete - JMeden - Defect 4608039 - 2021-10-21
        // Start Add - RDizon - Defect 4621945 - 2021-12-02
        
        /**
         * Get the Arrears Amount of the Account from a Reference Date
         * @param account
         * @param referenceDate
         * @return
         */
        // Start Change - RDizon - Defect 4621945 - 2021-12-02
        //private BigDecimal getArrearsAmount(Account account, Date referenceDate){
        private BigDecimal getArrearsAmount(Account account, Date referenceDate, Date creditReferenceDate){
        // End Change - RDizon - Defect 4621945 - 2021-12-02
            //Compute for the debt of the Account
            BigDecimal wkAmtOwed = BigDecimal.ZERO;
            // Start Change - NMendo - CCB020.Issue9 - 2021-08-09
            ArrearsInfoParameters infoParm = ArrearsInfoParameters.Factory.newInstance();
            infoParm.setArrearsSource(ArrearsInformationSourceLookup.constants.ACCOUNT);
            infoParm.setCollectionLimitOption(ArrearsCollectionLimitOptionLookup.constants.LUMP_ARREARS);
            // Start Delete - RDizon - Defect 4621945 - 2021-12-02
            // infoParm.setOldestBucketAgeDays(ARS_DAYS);
            // End Delete - RDizon - Defect 4621945 - 2021-12-02
            //infoParm.setMustReturnCumulativeArrears(Bool.TRUE);
            infoParm.setMustReturnCumulativeArrears(Bool.FALSE);
            //infoParm.setMustReturnTotalAmount(Bool.TRUE);
            infoParm.setMustReturnTotalAmount(Bool.FALSE);
            infoParm.setMustReturnNewDebits(Bool.FALSE);
            infoParm.setReferenceDate(referenceDate);
            // Start Change - RDizon - Defect 4621945 - 2021-12-02
            // infoParm.setCreditReferenceDate(referenceDate);
            infoParm.setCreditReferenceDate(creditReferenceDate);
            // End Change - RDizon - Defect 4621945 - 2021-12-02
            ArrearsInfoResults infoResults = account.fetchArrearsInfo(infoParm);            
            //wkAmtOwed = infoResults.getCurrentAmount().getAmount();
            
            Iterator<ArrearsInfoArrearsCollection> arrearsIter = infoResults.getArrearsDetails().iterator();
            while (arrearsIter.hasNext()) {
                ArrearsInfoArrearsCollection arrearsColl = arrearsIter.next();
                // Start Change - RDizon - Defect 4621945 - 2021-12-02
                // if(arrearsColl.getDaysAged().compareTo(ARS_DAYS) >= 0) {
                wkAmtOwed = wkAmtOwed.add(arrearsColl.getArrearsAmount().getAmount());
                // }
                // End Change - RDizon - Defect 4621945 - 2021-12-02
            }
            // End Change - NMendo - CCB020.Issue9 - 2021-08-09
            
            // Start Add - NMendo - Defect 389348 - 2022-01-25
            // Exclude Limiting SA when calculating for arrears amount.
            wkAmtOwed = wkAmtOwed.subtract(retrieveLimitingSAsArrears(account.getId(), referenceDate, creditReferenceDate));
            // End Add - NMendo - Defect 389348 - 2022-01-25
            
            return wkAmtOwed;
        }
        
        /**
         * Create a Customer Contact
         * @param personId
         * @param ccType
         * @param ccStatus
         * @return
         */
        // start change -  EQuint - B-37616 - 2025-03-04
        // private CustomerContact_Id createCustomerContact(Person_Id personId, CustomerContactType_Id ccType){
        private CustomerContact_Id createCustomerContact(Person_Id personId, CustomerContactType_Id ccType, CustomerContactStatusLookup ccStatus){
    	// end change -  EQuint - B-37616 - 2025-03-04
            CustomerContact_DTO ccNew = new CustomerContact_DTO();
            ccNew.setPersonId(personId);
            ccNew.setCustomerContactStatus(CustomerContactStatusLookup.constants.OPEN);
            ccNew.setUserId(getActiveContextUser().getId());                
            ccNew.setContactDateTime(getProcessDateTime());
            ccNew.setCustomerContactTypeId(ccType);
            // start add -  EQuint - B-37616 - 2025-03-04
            ccNew.setCustomerContactStatus(ccStatus);
            // end add -  EQuint - B-37616 - 2025-03-04
            ccNew.newEntity();

            return ccNew.getId();
        }
        
        /**
         * Create Customer Contact Log
         * @param ccId
         */
        private void createCcLog(CustomerContact_Id ccId){
            CustomerContactLog_DTO ccLogDto = new CustomerContactLog_DTO();
            ccLogDto.setCustomerContactId(ccId);
            ccLogDto.setUserId(this.getActiveContextUser().getId());
            ccLogDto.setTriggerBusinessProcess(Bool.FALSE);
            ccLogDto.setCreationDateTime(getProcessDateTime());
            ccLogDto.setLogEntry("Customer Contact Created");
            ccLogDto.newEntity();
        }
        
        // Start Add - RDizon - CCB020.Issue7 - 08-04-2021s       
        /**
         * Build CSV string of SA Types
         * @param saTypes
         * @return String
        */ 
        private String buildSaTypes(String saTypes){       
       
            StringTokenizer strTokenizer = new StringTokenizer(saTypes, ",");
        	
            StringBuilder stringWithQuotes = new StringBuilder();
            while(strTokenizer.hasMoreElements()){
                stringWithQuotes.append("'" + strTokenizer.nextToken().trim()+"'");
                if(strTokenizer.hasMoreTokens()){
                    stringWithQuotes.append(",");
                }
            }
            return stringWithQuotes.toString();
        }
        
        /**
         * Check if a certain SA Type exists on the Bill's Bill Segments
         * @param billId
         * @param saTypes
         * @return Bool
         */
        private Bool checkBsegSAs(Bill_Id billId, String saTypes){
            Bool saExists = Bool.FALSE;
            
            StringBuilder sbCheckBsegSAs = new StringBuilder();
            sbCheckBsegSAs.append("SELECT SA.SA_ID ");
            sbCheckBsegSAs.append("FROM CI_BSEG BSEG, ");
            sbCheckBsegSAs.append(    "CI_SA SA ");
            sbCheckBsegSAs.append("WHERE BSEG.BILL_ID = :billId ");
            sbCheckBsegSAs.append(    "AND BSEG.BSEG_STAT_FLG = :frozen ");
            sbCheckBsegSAs.append(    "AND BSEG.SA_ID = SA.SA_ID ");
            sbCheckBsegSAs.append(    "AND SA.SA_TYPE_CD IN (" + saTypes + ") ");
            
            PreparedStatement ps = createPreparedStatement(sbCheckBsegSAs.toString(), "checkBsegSAs()");
            ps.bindId("billId", billId);
            ps.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
            SQLResultRow resultRow = ps.firstRow();
            if(!isNull(resultRow)){
                saExists = Bool.TRUE;
            }
            ps.close();
            
            return saExists;
        }
        // End Add - RDizon - CCB020.Issue7 - 08-04-2021

        // Start Add - NMendo - Defect 389348 - 2022-01-25
        /**
         * Retrieve Account's Limiting SAs Arrears
         * @param accountId
         * @param referenceDate
         * @param creditReferenceDate
         * @return BigDecimal
         */
        private BigDecimal retrieveLimitingSAsArrears(Account_Id accountId, Date referenceDate, Date creditReferenceDate) {
            BigDecimal limitingSAsArrears = BigDecimal.ZERO;
            
            if(isNull(parmLimitingSATypes)) {
                return BigDecimal.ZERO;
            }
            
            StringBuilder limitingSATypesQuotedSb = new StringBuilder();
            String[] limitingSATypesSplitted = parmLimitingSATypes.split(COMMA);
            CisDivision cisDivision = accountId.getEntity().getDivisionId().getEntity();
            
            // Validate and Add quote to Limiting SA Types parameter
            for(int i = 0; i < limitingSATypesSplitted.length; i++) {
                String currentSAType = limitingSATypesSplitted[i].trim();
                //Start Change JVitug - Defect 389348 - 2022-02-16
                //ServiceAgreementType_Id currentSATypeId = new ServiceAgreementType_Id(cisDivision, currentSAType); 
                //if(isNull(currentSATypeId.getEntity())) {
                //    throw new RunAbortedException(CustomMessageRepositorySpireOne.D389348_invalidSAType(
                //            "LIMITING_SA_TYPES", 
                //            currentSAType,
                //            cisDivision.fetchLanguageDescription()));					
                if(isValidSAType(currentSAType).isFalse()) {
                    throw new RunAbortedException(CustomMessageRepositorySpireOne.D389348_invalidSAType(
                            "LIMITING_SA_TYPES", 
                            currentSAType));
                //End Change JVitug - Defect 389348 - 2022-02-16
							
                }
                
                if(i > 0) {
                    limitingSATypesQuotedSb.append(COMMA);
                }
                limitingSATypesQuotedSb.append(SINGLE_QUOTE);
                limitingSATypesQuotedSb.append(currentSAType);
                limitingSATypesQuotedSb.append(SINGLE_QUOTE);
            }
            String limitingSATypesQuoted = limitingSATypesQuotedSb.toString();
            
            // Retrieve Account's Limiting SAs
            StringBuilder prepStmtSb = new StringBuilder();
            prepStmtSb.append("SELECT SA_ID ");
            prepStmtSb.append("FROM CI_SA ");
            prepStmtSb.append("WHERE ACCT_ID = :accountId ");
            prepStmtSb.append("AND SA_TYPE_CD IN (" + limitingSATypesQuoted + ") ");
            prepStmtSb.append("AND SA_STATUS_FLG IN (:pendingStart, :active, :pendingStop, :stopped, :reactivated) ");
            
            PreparedStatement ps = createPreparedStatement(prepStmtSb.toString(), getClass().getName());
            ps.setAutoclose(false);
            ps.bindId("accountId", accountId);
            ps.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
            ps.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
            ps.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
            ps.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
            ps.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
            
            List<SQLResultRow> results = ps.list();
            ps.close();
            
            if(results.isEmpty()) {
                return BigDecimal.ZERO;
            }
            
            // Retrieve Account's Limiting SAs Arrears
            for(SQLResultRow sqlRow : results) {
                ServiceAgreement limitingSA = sqlRow.getEntity("SA_ID", ServiceAgreement.class);
                
                ArrearsInfoParameters arrearsInfoParms = ArrearsInfoParameters.Factory.newInstance();
                arrearsInfoParms.setArrearsSource(ArrearsInformationSourceLookup.constants.SERVICE_AGREEMENT);
                arrearsInfoParms.setServiceAgreement(limitingSA);
                arrearsInfoParms.setMustReturnCumulativeArrears(Bool.FALSE);
                arrearsInfoParms.setCollectionLimitOption(ArrearsCollectionLimitOptionLookup.constants.LUMP_ARREARS);
                arrearsInfoParms.setMustReturnTotalAmount(Bool.TRUE);
                arrearsInfoParms.setMustReturnNewDebits(Bool.FALSE);
                arrearsInfoParms.setReferenceDate(referenceDate);
                arrearsInfoParms.setCreditReferenceDate(creditReferenceDate);

                ArrearsInfoResults arrearsInfoResults = limitingSA.fetchArrearsInfo(arrearsInfoParms);
                limitingSAsArrears = limitingSAsArrears.add(arrearsInfoResults.getCurrentAmount().getAmount());
            }
            
            return limitingSAsArrears;
        }
        // End Add - NMendo - Defect 389348 - 2022-01-25
        
        //Start Add JVitug - Defect 389348 - 2022-02-16
        private Bool isValidSAType(String saType) {
            Bool isValidSAType = Bool.FALSE;
            StringBuilder stringSql = new StringBuilder();
            
            stringSql.append("SELECT " );
            stringSql.append(   "SAT.SA_TYPE_CD ");
            stringSql.append("FROM ");
            stringSql.append(   "CI_SA_TYPE SAT ");
            stringSql.append("WHERE ");
            stringSql.append(   "SAT.SA_TYPE_CD = :saType ");
            
            PreparedStatement sql = createPreparedStatement(stringSql.toString() , getClass().getName());
            sql.bindString("saType" , saType , "SA_TYPE_CD");
            
            SQLResultRow result = sql.firstRow();
            sql.close();
            
            if(notNull(result)) {
                isValidSAType = Bool.TRUE;
            }
            
            return isValidSAType;
        }
        //End Add JVitug - Defect 389348 - 2022-02-16
        
     // Start Add - JTiozon - CCB047 - 06-17-2022
        private BigDecimal getBillAmountDue(Bill bill){
        	
        	BigDecimal amountDue = BigDecimal.ZERO;
        	
        	StringBuilder stringSql = new StringBuilder();
             
            stringSql.append("SELECT " );
            stringSql.append(   "NVL(SUM(FT.CUR_AMT), 0) SUM_CUR_AMT ");
            stringSql.append("FROM ");
            stringSql.append(   "CI_FT FT ");
            stringSql.append("WHERE ");
            stringSql.append(   "FT.BILL_ID = :bill ");
             
            PreparedStatement sql = createPreparedStatement(stringSql.toString() , getClass().getName());
            sql.bindId("bill", bill.getId());
             
            SQLResultRow result = sql.firstRow();
            sql.close();
             
            if(notNull(result)) {
            	amountDue = (BigDecimal) result.getBigDecimal("SUM_CUR_AMT");
             }
             
        	return amountDue;
        			
        			
        			
        }    
       
       
        public FieldActivity checkFaExist(ServicePoint_Id spId, FieldActivityType faType, DateTime faDttm) {
    		
        	FieldActivity fa = null;
        	StringBuilder stringSql = new StringBuilder();
            
        	stringSql.append("SELECT FA.FA_ID ");
        	stringSql.append("FROM CI_FA FA ");
        	stringSql.append("WHERE FA.SP_ID = :spId ");
        	stringSql.append(	"AND FA.FA_TYPE_CD = :faType ");
        	stringSql.append(	"AND FA.FA_STATUS_FLG = :pending ");
        	stringSql.append(	"AND FA.SCHED_DTTM > :faDttm ");
        	             
            PreparedStatement sql = createPreparedStatement(stringSql.toString() , getClass().getName());
            sql.bindId("spId", spId);
            sql.bindEntity("faType", faType);
            sql.bindLookup("pending", FieldActivityStatusLookup.constants.PENDING);
            sql.bindDateTime("faDttm", faDttm);
            SQLResultRow result = sql.firstRow();
            if(notNull(result)){
            	fa = result.getEntity("FA_ID", FieldActivity.class);
            }
    		return fa;
        	
    	}
        
        private SQLResultRow getSpAndSA(Bill_Id billId){        	
           
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.append("SELECT SASP.SP_ID, SA.SA_ID ");
            strBuilder.append("FROM CI_BSEG BSEG, ");
            strBuilder.append(    "CI_SA SA, ");
            strBuilder.append(    "CI_SA_SP SASP ");
            strBuilder.append("WHERE BSEG.BILL_ID = :billId ");
            strBuilder.append(    "AND BSEG.BSEG_STAT_FLG = :frozen ");
            strBuilder.append(    "AND BSEG.SA_ID = SA.SA_ID ");
            strBuilder.append(    "AND SASP.SA_ID = BSEG.SA_ID ");
            strBuilder.append(    "AND SASP.START_DTTM = (SELECT MAX(START_DTTM) FROM CI_SA_SP SASP2 WHERE SASP2.SA_ID = SASP.SA_ID ");
            strBuilder.append(    							"AND SASP2.START_DTTM <= BSEG.START_DT) ");
            
            PreparedStatement ps = createPreparedStatement(strBuilder.toString(), "getSpAndSA()");
            ps.bindId("billId", billId);
            ps.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
            SQLResultRow resultRow = ps.firstRow();
           
            ps.close();
            
            return resultRow;
            
        }
        
        private Bool checkActiveSeverance(ServiceAgreement sa){        	
            
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.append("SELECT 'X' ");
            strBuilder.append("FROM CI_SEV_PROC P ");           
            strBuilder.append("WHERE P.SA_ID = :sa ");
            strBuilder.append(    "AND P.SEV_STATUS_FLG = :active ");
          
            
            PreparedStatement ps = createPreparedStatement(strBuilder.toString(), "checkActiveSeverance()");
            ps.bindId("sa", sa.getId());
            ps.bindLookup("active", SeveranceStatusLookup.constants.ACTIVE);
            SQLResultRow resultRow = ps.firstRow();
           
            if(notNull(resultRow)){
            	return Bool.TRUE;
            }
            ps.close();
            
            return Bool.FALSE;
        }
        
        private Bool checkCancelledSeverance(ServiceAgreement sa, DateTime faScheduleDttm){        	
            
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.append("SELECT 'X' ");
            strBuilder.append("FROM CI_SEV_PROC P ");           
            strBuilder.append("WHERE P.SA_ID = :sa ");
            strBuilder.append(    "AND P.SEV_STATUS_FLG = :cancelled ");
            strBuilder.append(    "AND P.CRE_DTTM > :faScheduleDttm ");
          
            
            PreparedStatement ps = createPreparedStatement(strBuilder.toString(), "checkCancelledSeverance()");
            ps.bindId("sa", sa.getId());
            ps.bindLookup("cancelled", SeveranceStatusLookup.constants.INACTIVE);
            ps.bindDateTime("faScheduleDttm", faScheduleDttm);
            SQLResultRow resultRow = ps.firstRow();
           
            if(notNull(resultRow)){
            	return Bool.TRUE;
            }
            ps.close();
            
            return Bool.FALSE;
        }
        // End Add - JTiozon - CCB047 - 06-17-2022
        
    }

	


}

