/**************************************************************************
* Program Name: CmExpireSelfServiceQuoteBatch
* Program Title: CmExpireSelfServiceQuoteBatch
* Author: Joshua Ace Vitug
* Creation Date: 2018-03-06
* Purpose: This Batch Job expires any unpaid self - service quotes at the 
*          end of each day
* Functional Spec: CCB-CC-022-2.7
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  CCB-CC-022-2.7    JVitug           2018-03-06    CCB-CC-022-2.7. Initial Version      
 *  E-11648           JVitug           2026-06-04    E-11648. Updated batch strategy to thread 
 *                                                   iteration strategy to prevent multiple cancel
 *                                                   FTs from being created.                                                                                                                                                                                                                                                                       
 ************************************************************************************************/

package com.splwg.cm.domain.batch;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadIterationStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.StringId;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author JVitug
 *
 @BatchJob (modules = {}, rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (entityName = serviceTaskType, name = SVC_TASK_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name =  CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CURRENT_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = NEW_STATUS, required = true, type = string)})
 */
public class CmExpireSelfServiceQuoteBatch extends CmExpireSelfServiceQuoteBatch_Gen {

    //Batch Parameters
    private ServiceTaskType serviceTaskType;
    private CharacteristicType quoteSourceCharacteristicType;
    private String quoteSourceCharacteristicValues;
    private String pendingStatus;
    private String expiredStatus;
    
    
    @Override
    public void validateSoftParameters(boolean isNewRun) {
        serviceTaskType = getParameters().getSVC_TASK_TYPE();
        quoteSourceCharacteristicType = getParameters().getCHAR_TYPE();
        quoteSourceCharacteristicValues = getParameters().getCHAR_VAL();
        pendingStatus = getParameters().getCURRENT_STATUS();
        expiredStatus = getParameters().getNEW_STATUS();
        
        StringBuilder quoteSourceCharValForQuery = new StringBuilder();
        String[] validateQuoteSourceCharacteristicValues = quoteSourceCharacteristicValues.split(",");
        
        if(validateQuoteSourceCharacteristicValues.length < 1){
            addError(CustomMessageRepository.CCB_CC_022_27_quoteSourceCharValIsEmpty());
        }
        
        if(validateQuoteStatus(pendingStatus).isFalse()){
            addError(CustomMessageRepository.CCB_CC_022_27_quoteStatusIsInvalid(pendingStatus, serviceTaskType.getRelatedTransactionBO().getId().getTrimmedValue()));
        }
        
        if(validateQuoteStatus(expiredStatus).isFalse()){
            addError(CustomMessageRepository.CCB_CC_022_27_quoteStatusIsInvalid(expiredStatus, serviceTaskType.getRelatedTransactionBO().getId().getTrimmedValue()));
        }
        
        for(int i = 0 ; i < validateQuoteSourceCharacteristicValues.length; i ++){
            if(!validateQuoteSourceCharacteristicValues[i].trim().isEmpty()){
                quoteSourceCharValForQuery.append("'");
                quoteSourceCharValForQuery.append(validateQuoteSourceCharacteristicValues[i].trim());
                quoteSourceCharValForQuery.append("'");
                if(i < validateQuoteSourceCharacteristicValues.length - 1){
                    quoteSourceCharValForQuery.append(",");
                }   
            } 
        }
        quoteSourceCharacteristicValues = quoteSourceCharValForQuery.toString();
    }
    
    /**
     * Check if the status supplied to this method is a valid status of
     * the BO parameter
     * @param status
     * @param quoteBO
     * @return
     */
    private Bool validateQuoteStatus(String status){
        StringBuilder stringCheckIfPendingStatusValid = new StringBuilder();
        PreparedStatement queryCheckIfPendingStatusValid;
        
        stringCheckIfPendingStatusValid.append("SELECT 'X' ");
        stringCheckIfPendingStatusValid.append("FROM F1_BUS_OBJ_STATUS ST ");
        stringCheckIfPendingStatusValid.append("WHERE BUS_OBJ_CD = :bo ");
        stringCheckIfPendingStatusValid.append(  "AND BO_STATUS_CD = :status ");
        
        queryCheckIfPendingStatusValid = createPreparedStatement(stringCheckIfPendingStatusValid.toString(), this.getClass().getName());
        queryCheckIfPendingStatusValid.bindEntity("bo", serviceTaskType.getRelatedTransactionBO());
        queryCheckIfPendingStatusValid.bindString("status", status, "BO_STATUS_CD");
        
        if(queryCheckIfPendingStatusValid.list().size() > 0){
            queryCheckIfPendingStatusValid.close();
            return Bool.TRUE;
        }
        
        queryCheckIfPendingStatusValid.close();
        return Bool.FALSE;
    }
    
      //Start Delete JVitug - E-11648 - 2026-06-04
//    public JobWork getJobWork() {
//        
//        StringBuilder stringBuilder = new StringBuilder();              
//        stringBuilder.append("SELECT F1_SVC_TASK_ID ");
//        stringBuilder.append("FROM F1_SVC_TASK STASK ");
//        stringBuilder.append("WHERE STASK.F1_STASK_TYPE_CD = :serviceTaskType ");
//        stringBuilder.append("AND STASK.BO_STATUS_CD = :pendingStatus ");
//        stringBuilder.append("AND F1_SVC_TASK_ID IN ('44080838930661','44080838930659') ");
//        stringBuilder.append("AND EXISTS (SELECT 'X' ");
//        stringBuilder.append("            FROM F1_SVC_TASK_CHAR STC ");
//        stringBuilder.append("            WHERE STC.F1_SVC_TASK_ID = STASK.F1_SVC_TASK_ID ");
//        stringBuilder.append("            AND STC.CHAR_TYPE_CD = :charType ");
//        stringBuilder.append("            AND STC.SRCH_CHAR_VAL IN (" + quoteSourceCharacteristicValues + ") ");
//        stringBuilder.append(") ");
//
//        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
//        prepState.bindString("pendingStatus", pendingStatus, "BO_STATUS_CD");
//        prepState.bindId("serviceTaskType" , serviceTaskType.getId());
//        prepState.bindEntity("charType", quoteSourceCharacteristicType);
//        QueryIterator queryIter = prepState.iterate();
//        
//        return createJobWorkForQueryIterator(queryIter, this);      
//    }

//    @Override
//    public ThreadWorkUnit createWorkUnit(QueryResultRow qrw) {
//        
//        ThreadWorkUnit twu = new ThreadWorkUnit();
//        ServiceTask_Id serviceTaskID = (ServiceTask_Id) qrw.getId("F1_SVC_TASK_ID", ServiceTask.class); 
//        twu.setPrimaryId(serviceTaskID);
//        return twu;
//    }
    //End Delete JVitug - E-11648 - 2026-06-04

    public Class<CmExpireSelfServiceQuoteBatchWorker> getThreadWorkerClass() {
        return CmExpireSelfServiceQuoteBatchWorker.class;
    }

    public static class CmExpireSelfServiceQuoteBatchWorker extends
        CmExpireSelfServiceQuoteBatchWorker_Gen {
        
        private ServiceTaskType serviceTaskType;
        private CharacteristicType quoteSourceCharacteristicType;
        private String quoteSourceCharacteristicValues;
        private String pendingStatus;
        private String expiredStatus;
        
        public ThreadExecutionStrategy createExecutionStrategy() {
        	//Start Change JVitug - E-11648 - 2026-06-04
            //return new StandardCommitStrategy(this);
        	return new ThreadIterationStrategy(this);
        	//End Change JVitug - E-11648 - 2026-06-04
        }

        //Start Add JVitug - E-11648 - 2026-06-04
        @Override
        protected QueryIterator getQueryIteratorForThread(StringId lowID, StringId highID) {
        	StringBuilder stringBuilder = new StringBuilder();              
        	stringBuilder.append("SELECT F1_SVC_TASK_ID ");
        	stringBuilder.append("FROM F1_SVC_TASK STASK ");
        	stringBuilder.append("WHERE STASK.F1_SVC_TASK_ID between :lowId AND :highId ");
        	stringBuilder.append("AND STASK.F1_STASK_TYPE_CD = :serviceTaskType ");
        	stringBuilder.append("AND STASK.BO_STATUS_CD = :pendingStatus ");
        	stringBuilder.append("AND F1_SVC_TASK_ID IN ('23935602011734' , '23935602011735') ");
        	stringBuilder.append("AND EXISTS (SELECT 'X' ");
        	stringBuilder.append("            FROM F1_SVC_TASK_CHAR STC ");
        	stringBuilder.append("            WHERE STC.F1_SVC_TASK_ID = STASK.F1_SVC_TASK_ID ");
        	stringBuilder.append("            AND STC.CHAR_TYPE_CD = :charType ");
        	stringBuilder.append("            AND STC.SRCH_CHAR_VAL IN (" + quoteSourceCharacteristicValues + ") ");
        	stringBuilder.append(") ");

        	PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        	prepState.bindId("lowId" , lowID);
        	prepState.bindId("highId" , highID);
        	prepState.bindString("pendingStatus", pendingStatus, "BO_STATUS_CD");
        	prepState.bindId("serviceTaskType" , serviceTaskType.getId());
        	prepState.bindEntity("charType", quoteSourceCharacteristicType);
        	prepState.execute();

        	return prepState.iterate(); 
        }
        //End Add JVitug - E-11648 - 2026-06-04

        @Override
        public void initializeThreadWork(
                boolean initializationPreviouslySuccessful)
                throws ThreadAbortedException, RunAbortedException {
            
            serviceTaskType = getParameters().getSVC_TASK_TYPE();
            quoteSourceCharacteristicType = getParameters().getCHAR_TYPE();
            quoteSourceCharacteristicValues = getParameters().getCHAR_VAL();
            pendingStatus = getParameters().getCURRENT_STATUS();
            expiredStatus = getParameters().getNEW_STATUS();

            //Start Add JVitug - E-11648 - 2026-06-04
            StringBuilder quoteSourceCharValForQuery = new StringBuilder();
            String[] validateQuoteSourceCharacteristicValues = quoteSourceCharacteristicValues.split(",");

            for(int i = 0 ; i < validateQuoteSourceCharacteristicValues.length; i ++){
            	if(!validateQuoteSourceCharacteristicValues[i].trim().isEmpty()){
            		quoteSourceCharValForQuery.append("'");
            		quoteSourceCharValForQuery.append(validateQuoteSourceCharacteristicValues[i].trim());
            		quoteSourceCharValForQuery.append("'");
            		if(i < validateQuoteSourceCharacteristicValues.length - 1){
            			quoteSourceCharValForQuery.append(",");
            		}   
            	} 
            }
            quoteSourceCharacteristicValues = quoteSourceCharValForQuery.toString();

            this.startResultRowQueryIteratorForThread(ServiceTask_Id.class);
            //End Add JVitug - E-11648 - 2026-06-04
        }
        
        //Start Add JVitug - E-11648 - 2026-06-04
        @Override
        protected ThreadWorkUnit getNextWorkUnit(QueryResultRow row) {

        	ThreadWorkUnit twu = new ThreadWorkUnit(row.getId("F1_SVC_TASK_ID", ServiceTask.class));

        	return twu;
        } 
        //End Add JVitug - E-11648 - 2026-06-04

        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {            
            
            // Retrieve quote to be updated
            ServiceTask_Id serviceTaskID = (ServiceTask_Id) unit.getPrimaryId();
            // Expire the quote
            try{
                cmUpdateQuoteStatus(serviceTaskID, expiredStatus);
            }catch(Exception e){
                logError(CustomMessageRepository.CCB_CC_022_27_errorInExpiringQuote(serviceTaskID.getIdValue().trim()));
                return false;
            }
            
            return true;
        }
        /**
         * Method which updates the service task's BO Status
         * @param serviceTaskID the service task's id that needs to be updated
         * @param newStatus the new status of the BO Status for the service task
         */
        private void cmUpdateQuoteStatus(ServiceTask_Id serviceTaskID, String newStatus) {
            //Read the Service Task Business Object
            BusinessObjectInstance serviceTaskType = BusinessObjectInstance.create(serviceTaskID.getEntity().getBusinessObject());
            serviceTaskType.set("serviceTaskId", serviceTaskID.getTrimmedValue());
            
            //Update the Service Task Business Object Status to PAID
            serviceTaskType = BusinessObjectDispatcher.read(serviceTaskType);  
            serviceTaskType.set("status", newStatus);
            BusinessObjectDispatcher.update(serviceTaskType);
        }
    }
    
    
}
 