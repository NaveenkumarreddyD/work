/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NB0057 - Severance Expiration       
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2012-11-28   Arun    NB0057. Initial Version.
 * 2012-12-05   Arun    NB0057. Reviews Comments Incorporated.
 * 2012-12-07   Arun    NB0057. Reviews Comments Incorporated.
 * 2013-02-11   MOL     TIR NB0057_20130211. Fixed the main SQL and also
 *                      the # of days condition checking.
 * 2015-03-10   MCruz   MGE-CCB004.009 (CR3135978)
 *                      - Added CIS Division parameter.
 *                      - Modified query to only process Severance Processes
 *                      for SA's with a CIS Division specified in the parameter.  
 * 2015-04-28   BMarqu  SF-3212399. Refactored for performance, enable
 *                      multi-threading.   
 * 2016-01-29  	MPang	Updated for CCB v2.4 compilation.                                  
 **************************************************************************/

package com.splwg.cm.domain.batch;

/*
 * Start Delete - Defect 3212399 - 2015-04-28
 */
//import com.splwg.shared.common.ApplicationError;
/*
 * End Delete - Defect 3212399 - 2015-04-28
 */

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.DayInMonth;
import com.splwg.base.api.datatypes.TimeInterval;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.CustomerEventLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.SeveranceEventTypeLookup;
import com.splwg.ccb.api.lookup.SeveranceStatusLookup;
import com.splwg.ccb.api.lookup.SeveranceStatusReasonLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.creditcollections.severanceProcess.SeveranceProcess;
import com.splwg.ccb.domain.creditcollections.severanceProcess.SeveranceProcess_Id;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.CreditReviewSchedule;
import com.splwg.ccb.domain.customerinfo.account.CreditReviewSchedule_DTO;
import com.splwg.ccb.domain.customerinfo.account.CreditReviewSchedule_Id;*/
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceProcess;
import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceProcess_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.CreditReviewSchedule;
import com.splwg.ccb.domain.customerinfo.account.entity.CreditReviewSchedule_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.CreditReviewSchedule_Id;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author adevaraj001
 *
@BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = NORMAL_EXPIRATION_DAYS, required = true, type = integer)
 *            , @BatchJobSoftParameter (name = EXCEPTION_EXPIRATION_DAYS, required = true, type = integer)
 *            , @BatchJobSoftParameter (name = EXCEPTION_PERIOD_START_DATE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = EXCEPTION_PERIOD_END_DATE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity)})
 */ 

public class CmSeveranceExpiration_BatchProcess extends
        CmSeveranceExpiration_BatchProcess_Gen {

    /*
     * Start Change - Defect 3212399 - 2015-04-28
     */
    ////Soft Parameters
    //private static BigInteger parmMaxErrors;
    //private static BigInteger parmNormalExpirationDays;
    //private static BigInteger parmExceptionExpirationDays;
    //private static String exceptionPeriodStartDate;
    //private static String exceptionPeriodEndDate;
    //private static  List<SQLResultRow> severanceProcessList;
    
    // Soft parameters
    private TimeInterval normalExpirationDays;
    private TimeInterval exceptionExpirationDays;
    private DayInMonth exceptionPeriodStartDayInMonth;
    private DayInMonth exceptionPeriodEndDayInMonth;
    private CisDivision cisDivision;
    /*
     * End Change - Defect 3212399 - 2015-04-28
     */

    /*
     * Start Change - Defect 2312399 - 2015-04-28
     */
    ////Constants
    //private static final String DATE_DELIMITER = "/";
    //private static final String DATE_FORMAT = "MM/dd";
    //private static final int ZERO = 0;
    //private static final int ONE = 1;
    //private static final int TWELVE = 12;
    //private static final int THIRTY_ONE = 31;
    
    // Constants
    private static final DateFormat MONTH_DAY_DATE_FORMAT = new DateFormat("MM/dd");
    /*
     * End Change - Defect 2312399 - 2015-04-28
     */
    
    @Override
    public void validateSoftParameters(boolean isNewRun) {

        /*
         * Start Change - Defect 3212399 - 2015-04-28
         */
        //initializeSoftParams();
        //
        //if(parmNormalExpirationDays.compareTo(BigInteger.ZERO) == -1){
        //    addError(CustomMessageRepository.nb0057BatchParmNormExpirationDaysCannotBeNegative(parmNormalExpirationDays.toString().trim()));
        //}
        //
        //if(parmExceptionExpirationDays.compareTo(BigInteger.ZERO) == -1){
        //    addError(CustomMessageRepository.nb0057BatchParmExceptionExpirationdaysCannotBeNegative(parmExceptionExpirationDays.toString().trim()));
        //}
        //
        //exceptionPeriodStartDate = getParameters().getEXCEPTION_PERIOD_START_DATE();
        //DateFormat strdf = new DateFormat(DATE_FORMAT);
        //
        //try{
        //    strdf.parseDate(exceptionPeriodStartDate);
        //
        //}catch(DateFormatParseException e){
        //    addError(CustomMessageRepository.nb0057BatchParmStartDateIsInvalid(exceptionPeriodStartDate, DATE_FORMAT));
        //}
        //
        //exceptionPeriodEndDate = getParameters().getEXCEPTION_PERIOD_END_DATE();
        //DateFormat enddf = new DateFormat(DATE_FORMAT);
        //
        //try{
        //    enddf.parseDate(exceptionPeriodEndDate);
        //
        //}catch(DateFormatParseException e){
        //    addError(CustomMessageRepository.nb0057BatchParmEndDateIsInvalid(exceptionPeriodEndDate, DATE_FORMAT));
        //}
        //
        //if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
        //    addError(CustomMessageRepository.nb0057MaxErrorInvalid(parmMaxErrors.toString().trim()));
        //}
        
        BigInteger parmNormalExpirationDays = getParameters().getNORMAL_EXPIRATION_DAYS();
        if (parmNormalExpirationDays.compareTo(BigInteger.ZERO) == -1) {
            addError(CustomMessageRepository.nb0057BatchParmNormExpirationDaysCannotBeNegative(parmNormalExpirationDays.toString().trim()));
        }
        normalExpirationDays = new TimeInterval(0, parmNormalExpirationDays.longValue(), 0, 0, 0);

        BigInteger parmExceptionExpirationDays = getParameters().getEXCEPTION_EXPIRATION_DAYS();
        if (parmExceptionExpirationDays.compareTo(BigInteger.ZERO) == -1) {
            addError(CustomMessageRepository.nb0057BatchParmExceptionExpirationdaysCannotBeNegative(parmExceptionExpirationDays.toString().trim()));
        }
        exceptionExpirationDays = new TimeInterval(0, parmExceptionExpirationDays.longValue(), 0, 0, 0);
        
        try {
            exceptionPeriodStartDayInMonth = MONTH_DAY_DATE_FORMAT.parseDate(getParameters().getEXCEPTION_PERIOD_START_DATE()).dayInMonth();
        } catch(DateFormatParseException e) {
            addError(CustomMessageRepository.nb0057BatchParmStartDateIsInvalid(getParameters().getEXCEPTION_PERIOD_START_DATE(), MONTH_DAY_DATE_FORMAT.getFormatString()));
        }
        
        try {
            exceptionPeriodEndDayInMonth = MONTH_DAY_DATE_FORMAT.parseDate(getParameters().getEXCEPTION_PERIOD_END_DATE()).dayInMonth();
        } catch(DateFormatParseException e) {
            addError(CustomMessageRepository.nb0057BatchParmEndDateIsInvalid(getParameters().getEXCEPTION_PERIOD_END_DATE(), MONTH_DAY_DATE_FORMAT.getFormatString()));
        }
        
        cisDivision = getParameters().getCIS_DIVISION();
        /*
         * End Change - Defect 3212399 - 2015-04-28
         */
    }
    
    /*
     * Start Delete - Defect 3212399 - 2015-04-28
     */
    ///**
    // * @return void
    // *  This method retrieves Batch Param varaibles and initializes the class variables
    // */   
    //private void initializeSoftParams(){
    //    parmNormalExpirationDays = getParameters().getNORMAL_EXPIRATION_DAYS();
    //    parmExceptionExpirationDays = getParameters().getEXCEPTION_EXPIRATION_DAYS();
    //    parmMaxErrors = getParameters().getSoftMaxErrors();
    //}
    /*
     * End Delete - Defect 3212399 - 2015-04-28
     */
    
    @Override
    public JobWork getJobWork() {
        /*
         * Start Change - Defect 3212399 - 2015-04-28
         */
        //ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
        //ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        //arrayList.add(threadWorkUnit);
        //return createJobWorkForThreadWorkUnitList(arrayList);
        
        // Determine if process date falls inside Exception Period
        Bool isExceptionPeriod = Bool.FALSE;
        Date processDate = getProcessDateTime().getDate();
        Date startDate = exceptionPeriodStartDayInMonth.dateForYear(processDate.getYear());
        Date endDate = exceptionPeriodEndDayInMonth.dateForYear(processDate.getYear());

        if (startDate.isAfter(endDate)
                && (processDate.isSameOrBefore(endDate) || processDate.isSameOrAfter(startDate))) {
            isExceptionPeriod = Bool.TRUE;
        } else if (endDate.isSameOrAfter(startDate) 
                && (processDate.isSameOrAfter(startDate) && processDate.isSameOrBefore(endDate))) {
            isExceptionPeriod = Bool.TRUE;
        }
        
        // Determine Severance Process Expiration Date
        Date expirationDate = (isExceptionPeriod.isTrue()) ? processDate.subtract(exceptionExpirationDays) : processDate.subtract(normalExpirationDays);
        
        // Create Prepared Statement (because project doesn't use Hibernate Queries) to find Severance Processes
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(   "SVP.SEV_PROC_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(   "CI_SEV_PROC SVP, ");
        stringBuilder.append(   "CI_SA SA, ");
        stringBuilder.append(   "CI_SEV_EVT SE, ");
        stringBuilder.append(   "CI_SEV_EVT_TYPE SETY, ");
        stringBuilder.append(   "CI_SEV_EVT_FA SEFA, CI_FA FA ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(   "SVP.SEV_STATUS_FLG = :activeSeveranceStatus ");
        stringBuilder.append(   "AND SVP.CRE_DTTM <= :expirationDate ");
        stringBuilder.append(   "AND SA.SA_ID = SVP.SA_ID ");
        stringBuilder.append(   "AND SA.CIS_DIVISION = :cisDivision ");
        stringBuilder.append(   "AND SE.SEV_PROC_ID = SVP.SEV_PROC_ID ");
        stringBuilder.append(   "AND SETY.SEV_EVT_TYPE_CD = SE.SEV_EVT_TYPE_CD ");
        stringBuilder.append(   "AND SETY.SEV_EVT_TYPE_FLG = :fieldActivityEventType ");
        stringBuilder.append(   "AND SETY.CUST_EVT_FLG = :cutNonPayCustomerEvent ");
        stringBuilder.append(   "AND SEFA.SEV_PROC_ID = SVP.SEV_PROC_ID ");
        stringBuilder.append(   "AND SEFA.EVT_SEQ = SE.EVT_SEQ ");
        stringBuilder.append(   "AND FA.FA_ID = SEFA.FA_ID ");
        stringBuilder.append(   "AND FA.FA_STATUS_FLG <> :completeFaStatus ");
        
        //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        preparedStatement.bindLookup("activeSeveranceStatus", SeveranceStatusLookup.constants.ACTIVE);
        preparedStatement.bindDate("expirationDate", expirationDate);
        preparedStatement.bindEntity("cisDivision", cisDivision);
        preparedStatement.bindLookup("fieldActivityEventType", SeveranceEventTypeLookup.constants.CREATE_FIELD_ACTIVITIES);
        preparedStatement.bindLookup("cutNonPayCustomerEvent", CustomerEventLookup.constants.CUTFOR_NON_PAYMENT);
        preparedStatement.bindLookup("completeFaStatus", FieldActivityStatusLookup.constants.COMPLETED);
        
        List<SQLResultRow> results = preparedStatement.list();
        
        preparedStatement.close();
        
        // Results to Thread Work Unit List
        List<ThreadWorkUnit> threadWorkUnitList = new ArrayList<ThreadWorkUnit>();
        for (SQLResultRow sqlResultRow : results) {
            ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
            threadWorkUnit.setPrimaryId(sqlResultRow.getId("SEV_PROC_ID", SeveranceProcess.class));
            threadWorkUnitList.add(threadWorkUnit);
        }
        
        return createJobWorkForThreadWorkUnitList(threadWorkUnitList);
        /*
         * End Change - Defect 3212399 - 2015-04-28
         */
    }

    public Class<CmSeveranceExpiration_BatchProcessWorker> getThreadWorkerClass() {
        return CmSeveranceExpiration_BatchProcessWorker.class;
    }

    public static class CmSeveranceExpiration_BatchProcessWorker extends
            CmSeveranceExpiration_BatchProcessWorker_Gen {
        
        /*
         * Start Delete - Defect 3212399 - 2015-04-28
         */
        //private BigInteger noOfRecordsProcessed = BigInteger.ZERO;
        //private BigInteger recordsInError = BigInteger.ZERO;
        //private BigInteger numberOfSeveranceProcessCancelled = BigInteger.ZERO;
        //private Date processingDate;
        //private SeveranceProcess severanceProcess;
        //
        //// CCB004.009 (CR3135978) - MCruz 2015-01-07 - Start Add
        //private CisDivision parmCisDivision;
        //// CCB004.009 (CR3135978) - MCruz 2015-01-07 - End Add
        /*
         * End Delete - Defect 3212399 - 2015-04-28
         */
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            /*
             * Start Change - Defect 3212399 - 2015-04-28
             */
            //return new SingleTransactionStrategy(this);
            return new StandardCommitStrategy(this);
            /*
             * End Change - Defect 3212399 - 2015-04-28
             */
        }

        /*
         * Start Delete - Defect 3212399 - 2015-04-28
         */
        //// CCB004.009 (CR3135978) - MCruz 2015-01-07 - Start Add
        //@Override
        //public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
        //    parmCisDivision = getParameters().getCIS_DIVISION();
        //}
        //// CCB004.009 (CR3135978) - MCruz 2015-01-07 - End Add
        /*
         * End Delete - Defect 3212399 - 2015-04-28
         */
        
        @Override
        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit threadWorkUnit)
                throws ThreadAbortedException, RunAbortedException {
            
            /*
             * Start Change - Defect 3212399 - 2015-04-28
             */
            //WorkUnitResult workUnitResult = new WorkUnitResult(true);
            //
            //processingDate = getProcessDateTime().getDate();
            //retrieveSeveranceProcesses();
            //            
            //if(severanceProcessList.isEmpty()){
            //    
            //    workUnitResult.setUnitsProcessed(0);
            //    workUnitResult.setUnitsInError(0);
            //    logInfo(CustomMessageRepository.nb057NoOfSeveranceRecordsProcessed(noOfRecordsProcessed.toString()));
            //    logInfo(CustomMessageRepository.nb0057NoOfActiveSevProcessCancelled(numberOfSeveranceProcessCancelled.toString()));
            //
            //    return workUnitResult;
            //}
            //
            //for(SQLResultRow severanceProcessResultsRow : severanceProcessList){
            //    severanceProcess = severanceProcessResultsRow.getEntity("SEV_PROC_ID", SeveranceProcess.class);
            //    processSeveranceRecords();
            //}
            //
            //logInfo(CustomMessageRepository.nb057NoOfSeveranceRecordsProcessed(BigInteger.valueOf(severanceProcessList.size()).toString()));
            //logInfo(CustomMessageRepository.nb0057NoOfActiveSevProcessCancelled(numberOfSeveranceProcessCancelled.toString()));
            //workUnitResult.setUnitsProcessed(noOfRecordsProcessed.intValue());
            //workUnitResult.setUnitsInError(recordsInError.intValue());
            //return workUnitResult;
            
            SeveranceProcess severanceProcess = ((SeveranceProcess_Id) threadWorkUnit.getPrimaryId()).getEntity();
            severanceProcess.cancel(SeveranceStatusReasonLookup.constants.CANCELEDBY_SYSTEM, Bool.FALSE);
            
            Account account = severanceProcess.getServiceAgreement().getAccount();
            CreditReviewSchedule_Id creditReviewScheduleId = new CreditReviewSchedule_Id(account, getProcessDateTime().getDate());
            if (isNull(creditReviewScheduleId.getEntity())) {
                CreditReviewSchedule_DTO creditReviewScheduleDTO = createDTO(CreditReviewSchedule.class);
                creditReviewScheduleDTO.setId(creditReviewScheduleId);
                creditReviewScheduleDTO.newEntity();
            }
            
            WorkUnitResult workUnitResult = new WorkUnitResult(true);
            return workUnitResult;
            /*
             * End Change - Defect 3212399 - 2015-04-28
             */

        }

        /*
         * Start Delete - Defect 3212399 - 2015-04-28
         */
        //private void processSeveranceRecords(){
        //    Bool isError = Bool.FALSE;
        //    
        //    if (isProcessDateBetweenExceptionPeriodStartAndEndDates(exceptionPeriodStartDate, exceptionPeriodEndDate, processingDate).isTrue()){
        //        /*
        //         * TIR NB0057_20130211 - removed the subtraction of 1 day
        //         */
        //        // if(processingDate.difference(severanceProcess.getCreationDateTime().getDate()).getTotalDays()-1 >= parmExceptionExpirationDays.intValue()){
        //        if(processingDate.difference(severanceProcess.getCreationDateTime().getDate()).getTotalDays() >= parmExceptionExpirationDays.intValue()){
        //            isError = cancelSeveranceProcess(severanceProcess);
        //        }
        //    }
        //    else{
        //        /*
        //         * TIR NB0057_20130211 - removed the subtraction of 1 day
        //         */
        //        // if(processingDate.difference(severanceProcess.getCreationDateTime().getDate()).getTotalDays()-1 >= parmNormalExpirationDays.intValue()){
        //        if(processingDate.difference(severanceProcess.getCreationDateTime().getDate()).getTotalDays() >= parmNormalExpirationDays.intValue()){
        //            isError = cancelSeveranceProcess(severanceProcess);
        //        }
        //    }
        //    if(isError.isFalse()){
        //        noOfRecordsProcessed = noOfRecordsProcessed.add(BigInteger.ONE);
        //    }
        //    else{
        //        recordsInError = recordsInError.add(BigInteger.ONE);
        //        handleMaxErrors();
        //    }
        //}
        //
        ///**
        // * @return Bool 
        // * @param String Start Date (MM/DD), String End Date(MM/DD) and Process Date
        // * This method returns true if the Process date falls between the Start and End Dates.
        // * 
        // */     
        //private Bool isProcessDateBetweenExceptionPeriodStartAndEndDates(String exceptionPeriodStartDate,String exceptionPeriodEndDate,Date processDate){
        //    Date startDateExp = null;
        //    Date endDateExp = null;
        //
        //    int startMonth = Integer.parseInt(exceptionPeriodStartDate.substring(ZERO, exceptionPeriodStartDate.indexOf(DATE_DELIMITER)));
        //    int startDate = Integer.parseInt(exceptionPeriodStartDate.substring(exceptionPeriodStartDate.indexOf(DATE_DELIMITER) + 1));
        //
        //    int endMonth = Integer.parseInt(exceptionPeriodEndDate.substring(ZERO, exceptionPeriodEndDate.indexOf(DATE_DELIMITER)));
        //    int endDate = Integer.parseInt(exceptionPeriodEndDate.substring(exceptionPeriodEndDate.indexOf(DATE_DELIMITER) + 1));
        //
        //    int currentYearInt = processDate.getYear();
        //    int nextYearInt = currentYearInt + 1;
        //
        //    if (startMonth <= endMonth) 
        //    {
        //        startDateExp = new Date(currentYearInt, startMonth, startDate);
        //        endDateExp = new Date(currentYearInt, endMonth, endDate);
        //        if (isInputDateInTheRange(startDateExp, endDateExp,processDate).isTrue()) return Bool.TRUE;
        //    }
        //    else 
        //    {
        //        startDateExp = new Date(currentYearInt, startMonth, startDate);
        //        endDateExp = new Date(currentYearInt, TWELVE, THIRTY_ONE);
        //
        //        if (isInputDateInTheRange(startDateExp, endDateExp,processDate).isTrue()) return Bool.TRUE;
        //
        //        startDateExp = new Date(nextYearInt, ONE, ONE);
        //        endDateExp = new Date(nextYearInt, endMonth, endDate);
        //        processDate = processDate.addYears(1);
        //
        //        if (isInputDateInTheRange(startDateExp, endDateExp,processDate).isTrue()) return Bool.TRUE;
        //    }
        //
        //    return Bool.FALSE;
        //}
        //
        ///**
        // * @return Bool 
        // * @param Date Start Date , Date End Date and Process Date
        // * This method returns true if the Process date falls between the Start and End Dates.
        // * 
        // */                 
        //private Bool isInputDateInTheRange(Date startDate, Date endDate, Date processDate) 
        //{
        //    if(processDate.compareTo(startDate)>= 0 && processDate.compareTo(endDate) <= 0){
        //        return Bool.TRUE;
        //    }else{
        //        return Bool.FALSE;
        //    }
        //}
        //
        //private Bool cancelSeveranceProcess(SeveranceProcess severanceProcess){
        //    try{
        //        severanceProcess.cancel(SeveranceStatusReasonLookup.constants.CANCELEDBY_SYSTEM, Bool.FALSE);
        //        Account account = severanceProcess.getServiceAgreement().getAccount();
        //        CreditReviewSchedule_Id creditReviewScheduleId = new CreditReviewSchedule_Id(account, getProcessDateTime().getDate());
        //        if(isNull(creditReviewScheduleId.getEntity())){
        //            CreditReviewSchedule_DTO creditReviewScheduleDTO = createDTO(CreditReviewSchedule.class);
        //            creditReviewScheduleDTO.setId(creditReviewScheduleId);
        //            creditReviewScheduleDTO.newEntity();
        //        }
        //        numberOfSeveranceProcessCancelled = numberOfSeveranceProcessCancelled.add(BigInteger.ONE);
        //    } catch(ApplicationError appError) {
        //        logError(CustomMessageRepository.nb0057ErrorInCancellingSevProcess(severanceProcess.getId().getTrimmedValue(), appError.getServerMessage().getMessageText()));
        //        return Bool.TRUE;
        //    }
        //    return Bool.FALSE;
        //}
        //
        //private void handleMaxErrors()
        //{
        //    if(notNull(parmMaxErrors)) {
        //        if(recordsInError.compareTo(parmMaxErrors) > 0) {
        //            throw new RunAbortedException(CustomMessageRepository.nb0057_Max_Error_Exceeded(parmMaxErrors.toString()));
        //        }
        //    }
        //}
        //private void retrieveSeveranceProcesses() {
        //    StringBuilder getSAQueryString = new StringBuilder();
        //    /* TIR_NB0057_20130207 Begin */
        //    
        //    /* 
        //     * 
        //     * Modified the SQL
        //     * Get only those Severance Processes that have a Disconnect for Non Pay Severance Event, which is not linked to a completed FA.
        //     * 
        //     */
        //
        //    // getSAQueryString.append("SELECT DISTINCT (SEVPROC.SA_ID),SEVPROC.CRE_DTTM, SEVPROC.SEV_PROC_ID ");
        //    // getSAQueryString.append("FROM CI_SEV_EVT SE, CI_SEV_EVT_FA SEFA, CI_FA FA, CI_SEV_PROC SEVPROC ");
        //    // getSAQueryString.append("WHERE SEVPROC.SEV_STATUS_FLG = :activeStatus AND SEVPROC.CRE_DTTM <= :processDateTime ");
        //    // getSAQueryString.append("AND SE.SEV_PROC_ID = SEVPROC.SEV_PROC_ID  ");
        //    // getSAQueryString.append("AND EXISTS(SELECT 'X' FROM CI_SEV_EVT_TYPE SEVT ");
        //    // getSAQueryString.append("WHERE SEVT.SEV_EVT_TYPE_FLG = :fieldActivity ");
        //    // getSAQueryString.append("AND SE.SEV_EVT_TYPE_CD = SEVT.SEV_EVT_TYPE_CD AND SEVT.CUST_EVT_FLG = :cutNonPay) ");
        //    // getSAQueryString.append("AND SE.SEV_PROC_ID = SEFA.SEV_PROC_ID AND SEVPROC.SEV_PROC_ID = SEFA.SEV_PROC_ID ");
        //    // getSAQueryString.append("AND SE.EVT_SEQ = SEFA.EVT_SEQ AND SEFA.FA_ID = FA.FA_ID ");
        //    // getSAQueryString.append("AND FA.FA_STATUS_FLG <> :completed ");
        //
        //
        //    // CCB004.009 (CR3135978) - MCruz 2015-01-07 - Start Change
        //    //getSAQueryString.append(" SELECT SEV_PROC_ID ");
        //    //getSAQueryString.append("       ,SA_ID ");
        //    //getSAQueryString.append("       ,CRE_DTTM ");
        //    //getSAQueryString.append(" FROM CI_SEV_PROC ");
        //    //getSAQueryString.append(" WHERE SEV_PROC_ID IN (SELECT SEVPROC.SEV_PROC_ID ");   
        //    getSAQueryString.append(" SELECT SVP.SEV_PROC_ID ");
        //    getSAQueryString.append("       ,SVP.SA_ID ");
        //    getSAQueryString.append("       ,SVP.CRE_DTTM ");
        //    getSAQueryString.append(" FROM CI_SEV_PROC SVP, ");
        //    getSAQueryString.append("      CI_SA SA ");
        //    getSAQueryString.append(" WHERE SVP.SEV_PROC_ID IN (SELECT SEVPROC.SEV_PROC_ID ");
        //    // CCB004.009 (CR3135978) - MCruz 2015-01-07 - End Change
        //    getSAQueryString.append("                       FROM CI_SEV_EVT SE ");
        //    getSAQueryString.append("                          , CI_SEV_PROC SEVPROC ");
        //    getSAQueryString.append("                       WHERE SEVPROC.SEV_STATUS_FLG = :activeStatus ");
        //    getSAQueryString.append("                         AND SEVPROC.CRE_DTTM <= :processDateTime ");
        //    getSAQueryString.append("                         AND SE.SEV_PROC_ID = SEVPROC.SEV_PROC_ID ");
        //    getSAQueryString.append("                         AND EXISTS (SELECT 'X' ");
        //    getSAQueryString.append("                                     FROM CI_SEV_EVT_TYPE SEVT ");
        //    getSAQueryString.append("                                     WHERE SEVT.SEV_EVT_TYPE_FLG = :fieldActivity ");
        //    getSAQueryString.append("                                       AND SE.SEV_EVT_TYPE_CD = SEVT.SEV_EVT_TYPE_CD ");
        //    getSAQueryString.append("                                       AND SEVT.CUST_EVT_FLG = :cutNonPay) ");
        //    getSAQueryString.append("                         AND NOT EXISTS (SELECT 'X' ");
        //    getSAQueryString.append("                                         FROM CI_SEV_EVT_FA SEFA ");
        //    getSAQueryString.append("                                             ,CI_FA FA ");
        //    getSAQueryString.append("                                         WHERE SE.SEV_PROC_ID = SEFA.SEV_PROC_ID ");
        //    getSAQueryString.append("                                           AND SE.EVT_SEQ = SEFA.EVT_SEQ ");
        //    getSAQueryString.append("                                           AND SEFA.FA_ID = FA.FA_ID ");
        //    getSAQueryString.append("                                           AND FA.FA_STATUS_FLG = :completed ) ");
        //    getSAQueryString.append("                       ) ");
        //    // CCB004.009 (CR3135978) - MCruz 2015-01-07 - Start Add
        //    getSAQueryString.append(" AND SA.SA_ID = SVP.SA_ID ");
        //    getSAQueryString.append(" AND SA.CIS_DIVISION = :cisDivision ");        
        //    // CCB004.009 (CR3135978) - MCruz 2015-01-07 - End Add
        //    
        //    /* TIR NB0057_20130211 End */
        //
        //    PreparedStatement getSAPrepStmt = createPreparedStatement(getSAQueryString.toString());
        //
        //    getSAPrepStmt.bindLookup("activeStatus", SeveranceStatusLookup.constants.ACTIVE);
        //    getSAPrepStmt.bindLookup("fieldActivity", SeveranceEventTypeLookup.constants.CREATE_FIELD_ACTIVITIES);
        //    getSAPrepStmt.bindLookup("cutNonPay", CustomerEventLookup.constants.CUTFOR_NON_PAYMENT);
        //    getSAPrepStmt.bindDateTime("processDateTime", getProcessDateTime());
        //    getSAPrepStmt.bindLookup("completed", FieldActivityStatusLookup.constants.COMPLETED);
        //    // CCB004.009 (CR3135978) - MCruz 2015-01-07 - Start Add
        //    getSAPrepStmt.bindEntity("cisDivision", parmCisDivision);
        //    // CCB004.009 (CR3135978) - MCruz 2015-01-07 - End Add
        //    severanceProcessList = getSAPrepStmt.list();
        //    getSAPrepStmt.close();
        //}
        /*
         * Start Delete - Defect 3212399 - 2015-04-28
         */

    }
}
