/* ************************************************************************
 *                Confidentiality Information:
 *
 * This module is the confidential and proprietary information of
 * Oracle Corporation; it is not to be copied, reproduced, or
 * transmitted in any form, by any means, in whole or in part,
 * nor is it to be used for any purpose other than that for which
 * it is expressly provided without the written permission of
 * Oracle Corporation.
 *
 *
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * Customer Delta File Extract
 *
 * This custom batch process will extract account information into a file 
 * for payment vendors. The Customer Delta File extract includes only the 
 * changed accounts (based on records in the Change Log Table).
 * 
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:        Reason:
 * YYYY-MM-DD   IN         Reason text.
 *
 * 2016-02-29   MPang     NI0019.3. Initial Version.
 * 2016-05-18	EQuint	  Defect 3437885. Update SQL looping. Use Standard
 * 						  Commit strategy
 * 2016-07-20   SMiran    Defect 3477729. When extracting Master File, write
 *                        space before CRLF. 
 * 2017-01-26   GCinco    CCB-CC-007. Add E-Bill Override parameter. When 
 *                        switch is Yes, skip E-Bill eligibility processing
 *                        and set E-BILL to Y for all records
 * 2018-06-07   SFelip    CCB v2.6 Upgrade.
 * 2018-12-07   SFelip    Defect 4144085. Updated how error messages are 
 *                        logged to the run tree when JACOB code returns an 
 *                        error.   
 * 2020-03-26  JTiozon    B-15263. Updated to add Third Party Ebill field.
 *            
 * 2020-04-21  Kiran      B-15263. Updated logic to determing Ebill flag based on bill format and
 * 						  batch input char type   
 * 2025-11-14   EQuint    CCB25.4 Upgrade 
 * 2026-03-04   EQuint    Defect 5167721 - heap error fix 
 ***************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadIterationStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.StringId;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.StandardMessages;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.domain.database.table.Table_Id;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.cm.api.lookup.CmCustomerMasterDeltaExtractOptionLookup;
import com.splwg.cm.domain.common.customBusinessComponent.ChangeLogTable;
import com.splwg.cm.domain.common.customBusinessComponent.ChangeLogTable_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpcmden;

/**
 * @author MPang
 *
 @BatchJob (multiThreaded = true, rerunnable = false, modules={},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)
 *            , @BatchJobSoftParameter (name = RUN_MODE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = EXCLUDE_MONTHS, type = integer)
 *            , @BatchJobSoftParameter (name = INCLUDE_CR_HIST_DAYS, type = integer)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = MSTR_DLTA_FTR_NAME, required = true, type = entity)
 *            , @BatchJobSoftParameter (lookupName = cmCustomerMasterDeltaExtractOption, name = RES_CUST_CLASS_OPT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = cmCustomerMasterDeltaExtractOption, name = COM_CUST_CLASS_OPT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = cmCustomerMasterDeltaExtractOption, name = EBILL_ELIG_RT_OPT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = cmCustomerMasterDeltaExtractOption, name = EBILL_NELIG_CH_OPT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = NON_PAY_SA_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = NON_PAY_SA_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CHARITY_SA_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CHARITY_SA_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = OVERRIDE_EBILL_SW, required = true, type = boolean)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = THIRD_PTY_BPAY_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = THIRD_PTY_BPAY_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = ALL_USER_PROCESSING, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = EBILL_ENROLL_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = EBILL_ENROLL_CHAR_VALUE, required = true, type = string)})
 */
public class CmCustomerMasterDeltaExtractBatch extends CmCustomerMasterDeltaExtractBatch_Gen{

	//Constants
	private static final String THREAD_NUMBER_DESC = "Thread Number";
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";

	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";

	// start delete - equint - 2026-03-04 - Defect 5167721
	// private String typeFlag1 = "U   ";
	// private String typeFlag2 = "I   ";
	// end delete - equint - 2026-03-04 - Defect 5167721

	private static final String ACCT_TABLE = "CI_ACCT";
	private static final String DAILY_OR_MONTHLY_SW = "Daily or Monthly";
	
	// start delete - equint - 2026-03-04 - Defect 5167721
	// public JobWork getJobWork() {
	// 	
	// 	/*
	// 	 * Start Change - EQuint - Defect 3437885 - 2016-05-22
	// 	 */
	// 	// If  RUN-MODE = 'DELTA' perform checkCreditHistory
	// 	//if(getParameters().getRUN_MODE().equalsIgnoreCase("DELTA")){
	// 	//	checkCreditHistory();
	// 	//}
	// 	//// Select Customer Class, CIS_DIVISION
	// 	//PreparedStatement getMainPreparedStatement = createPreparedStatement(
	// 	//		" SELECT DISTINCT(CHL.PK_VAL1), ACCT.CUST_CL_CD , ACCT.CIS_DIVISION " +
	// 	//				" FROM CI_CHG_LOG CHL, CI_ACCT ACCT " +
	// 	//				" WHERE 'DELTA' = :runMode " +
	// 	//				" AND RTRIM(CHL.PK_VAL1) = RTRIM(ACCT.ACCT_ID) " +
	// 	//				" AND CHL.BATCH_CD = :batchCode " +
	// 	//				" AND CHL.BATCH_NBR = :batchNumber " +
	// 	//				" AND TRIM(CHL.CHG_TYPE_FLG) IN (:typeFlag1, :typeFlag2) " +
	// 	//				" 	UNION SELECT ACCT.ACCT_ID , ACCT.CUST_CL_CD, ACCT.CIS_DIVISION " +
	// 	//				" 		  FROM CI_ACCT ACCT " +
	// 	//				" 		  WHERE 'MASTER' = :runMode "
	// 	//				,getClass().getName());
	// 
	// 	//getMainPreparedStatement.bindString("runMode",getParameters().getRUN_MODE(), "DELTA/MASTER");
	// 	//getMainPreparedStatement.bindId("batchCode", getBatchControlId());
	// 	//getMainPreparedStatement.bindBigInteger("batchNumber", getBatchNumber());
	// 	//getMainPreparedStatement.bindString("typeFlag1", typeFlag1.trim(), "CHL.CHG_TYPE_FLG");
	// 	//getMainPreparedStatement.bindString("typeFlag2", typeFlag2.trim(), "CHL.CHG_TYPE_FLG");
	// 
	// 	//List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
	// 	//
	// 	//QueryIterator<SQLResultRow> iter = getMainPreparedStatement.iterate();
	// 	//while (iter.hasNext()) {
	// 	//	SQLResultRow row = iter.next();
	// 
	// 	//	ThreadWorkUnit workUnit = new ThreadWorkUnit();
	// 	//	workUnit.setPrimaryId(new Account_Id(row.getString("PK_VAL1")));
	// 	//	workUnit.addSupplementalData("CUST_CL_CD", row.getString("CUST_CL_CD"));
	// 	//	workUnit.addSupplementalData("CIS_DIVISION", row.getString("CIS_DIVISION"));
	// 	//	
	// 	//	
	// 	//		workUnits.add(workUnit);  
	// 	//}
	// 
	// 	//iter.close(); 
	// 	//return createJobWorkForThreadWorkUnitList(workUnits);
	// 	
	// 	String sql;
	// 	PreparedStatement getMainPreparedStatement;
	// 	
	// 	if(getParameters().getRUN_MODE().compareToIgnoreCase("DELTA") == 0){
	// 		checkCreditHistory();
	// 		sql = " SELECT DISTINCT(ACCT.ACCT_ID), ACCT.CUST_CL_CD , ACCT.CIS_DIVISION " +
	// 				" FROM CI_CHG_LOG CHL, CI_ACCT ACCT " +
	// 				" WHERE CHL.BATCH_CD = :batchCode " +
	// 				" AND CHL.BATCH_NBR = :batchNumber " +
	// 				" AND CHL.PK_VAL1 = ACCT.ACCT_ID " +
	// 				" AND CHL.CHG_TYPE_FLG IN (:typeFlag1, :typeFlag2) ";
	// 		
	// 		getMainPreparedStatement = createPreparedStatement(sql, getClass().getName());
	// 		getMainPreparedStatement.bindId("batchCode", getBatchControlId());
	// 		getMainPreparedStatement.bindBigInteger("batchNumber", getBatchNumber());
	// 		getMainPreparedStatement.bindString("typeFlag1", typeFlag1, "CHL.CHG_TYPE_FLG");
	// 		getMainPreparedStatement.bindString("typeFlag2", typeFlag2, "CHL.CHG_TYPE_FLG");
	// 		
	// 	}
	// 	else {
	// 		sql = "SELECT ACCT.ACCT_ID , ACCT.CUST_CL_CD, ACCT.CIS_DIVISION " +
	// 					" 		  FROM CI_ACCT ACCT ";			
	// 		
	// 		getMainPreparedStatement = createPreparedStatement(sql, getClass().getName());
	// 	}
	// 	
	// 	QueryIterator iterator = getMainPreparedStatement.iterate();
	// 	
	// 	return createJobWorkForQueryIterator(iterator, this);
	// 
	// 	/*
	// 	 * End Change - EQuint - Defect 3437885 - 2016-05-22
	// 	 */
	// 	
	// }
	// 
	// /*
	//  * Start Add - EQuint - Defect 3437885 - 2016-05-22
	//  */
	// 
	// 
	// public ThreadWorkUnit createWorkUnit(QueryResultRow row){
	// 	ThreadWorkUnit workUnit = new ThreadWorkUnit();
	// 	workUnit.setPrimaryId(new Account_Id(row.getString("ACCT_ID")));
	// 	workUnit.addSupplementalData("CUST_CL_CD", row.getString("CUST_CL_CD"));
	// 	workUnit.addSupplementalData("CIS_DIVISION", row.getString("CIS_DIVISION"));
	// 	
    //     return workUnit;
    // } 
	// /*
	//  * End Add - EQuint - Defect 3437885 - 2016-05-22
	//  */
	// 
	// private void checkCreditHistory() {
	// 	
	// 	/*
	// 	 * Subtract the number of days defined by the Include X Days
	// 	 * of Credit History Expiration batch parameter from the
	// 	 * process date.  This will serve as start of the range of
	// 	 * included credit rating histories for processing.
	// 	 */
	// 	BigInteger creditHistoryExpiration = getParameters().getINCLUDE_CR_HIST_DAYS();
	// 	Date startDateOfIncludedCreditRating = getProcessDateTime().getDate().addDays(creditHistoryExpiration.negate().intValue());
	// 
	// 	/*
	// 	 * Retrieve the Credit Rating Histories that have expired
	// 	 * within the computed time frame.
	// 	 */
	// 	PreparedStatement getCreditRatingHistories = createPreparedStatement(
	// 			"SELECT DISTINCT(CRH.ACCT_ID) " +
	// 					" FROM CI_CR_RAT_HIST CRH" +
	// 					" WHERE CRH.END_DT IS NOT NULL " +
	// 					" AND CRH.END_DT >= :startDt " +
	// 					" AND CRH.END_DT <= :endDt " +
	// 					" 	   AND NOT EXISTS(SELECT 'X' " +
	// 					"	   FROM CI_CHG_LOG CHL " +
	// 					
	// 					// "	   WHERE CHL.BATCH_CD = :batchCd " +
	// 					// "	   AND CHL.BATCH_NBR = :batchNumber " +
	// 					// "	   AND CHL.CHG_TYPE_FLG IN ('I','U') " +
	// 					// "	   AND TRIM(CHL.PK_VAL1) = TRIM(CRH.ACCT_ID))", getClass().getName());
	// 					
	// 					" WHERE CHL.PK_VAL1 = CRH.ACCT_ID " +
	// 					"      AND CHL.BATCH_CD = :batchCd " +
	// 					"	   AND CHL.BATCH_NBR = :batchNumber " +
	// 					"	   AND CHL.CHG_TYPE_FLG IN ('I   ','U   ') )", getClass().getName());
	// 					/*
	// 					 * End Update - EQuint - Defect 3437885 - 2016-05-18
	// 					 */
	// 
	// 	getCreditRatingHistories.bindDate("startDt", startDateOfIncludedCreditRating);
	// 	getCreditRatingHistories.bindDate("endDt", getProcessDateTime().getDate());
	// 	getCreditRatingHistories.bindId("batchCd", getBatchControlId());
	// 	getCreditRatingHistories.bindBigInteger("batchNumber", getBatchNumber());
	// 
	// 
	// 	/*
	// 	 * For each record retrieved, Insert a new record in the
	// 	 * Change Log table
	// 	 */
	// 	
	// 	/*
	// 	 * Start Update - EQuint - Defect 3437885 - 2016-05-18
	// 	 */
	// 	List<SQLResultRow> creditHistoriesResultRowList = getCreditRatingHistories.list();
	// 	for(SQLResultRow creditHistoriesResultRow:creditHistoriesResultRowList){
	// 	//	for(SQLResultRow creditHistoriesResultRow:getCreditRatingHistories.list()){
	// 			
	// 	// 		getCreditRatingHistories.close();
	// 	/*
	// 	 * End Update - EQuint - Defect 3437885 - 2016-05-18
	// 	 */
	// 
	// 		Account_Id acctId = (Account_Id) creditHistoriesResultRow.getId("ACCT_ID", Account.class);
	// 
	// 		// Generate Change Log ID.
	// 		ChangeLogTable_Id changeLogId = null;
	// 		Bool isUniqueId = Bool.FALSE;
	// 		while(isUniqueId.isFalse()) {
	// 
	// 			BigInteger genId = generateChangeLogId();
	// 
	// 			if(isUniqueChangeLogId(genId).isTrue()) {
	// 				changeLogId = new ChangeLogTable_Id(genId);
	// 				isUniqueId = Bool.TRUE;
	// 				break;
	// 			}
	// 		}
	// 		// Create a Change Log record.
	// 		
	// 		/*
	// 		 * Start Change - EQuint - Defect 3437885 - 2016-05-18
	// 		 */
	// 		
	// 		Table_Id saTableId = new Table_Id(ACCT_TABLE);
	// 
	// 		// ChangeLogTable_DTO changeLogDto = (ChangeLogTable_DTO)this.createDTO(ChangeLogTable.class);
	// 		// changeLogDto.setId(changeLogId);
	// 		// changeLogDto.setBatchControlId(getBatchControlId());
	// 		// changeLogDto.setBatchNumber(getBatchNumber());
	// 		// changeLogDto.setChangeDateTime(getProcessDateTime());
	// 		// changeLogDto.setChangeType(typeFlag1);
	// 		// changeLogDto.setChangeType(typeFlag2);
	// 		// changeLogDto.setTableId(saTableId);
	// 		// changeLogDto.setPkVal1(acctId.getIdValue());
	// 		// changeLogDto.newEntity();
	// 		
	// 		PreparedStatement insertChangeLogQuery = createPreparedStatement("INSERT INTO CI_CHG_LOG "
	// 				+ " (CHG_LOG_ID, BATCH_CD, BATCH_NBR, CHG_DTTM, CHG_TYPE_FLG, TBL_NAME, PK_VAL1) "
	// 				+ " VALUES (:id, :batchCd, :batchNbr, :chgDttm, :chgTypeFlg, :tblName, :pkVal1) ", getClass().getName());
	// 		
	// 		insertChangeLogQuery.bindId("id", changeLogId);
	// 		insertChangeLogQuery.bindId("batchCd", getBatchControlId());
	// 		insertChangeLogQuery.bindBigInteger("batchNbr", getBatchNumber());
	// 		insertChangeLogQuery.bindDateTime("chgDttm", getProcessDateTime());
	// 		insertChangeLogQuery.bindStringProperty("chgTypeFlg", ChangeLogTable.properties.changeType, typeFlag2);
	// 		insertChangeLogQuery.bindId("tblName", saTableId);
	// 		insertChangeLogQuery.bindStringProperty("pkVal1", ChangeLogTable.properties.pkVal1, acctId.getIdValue());
	// 		
	// 		insertChangeLogQuery.executeUpdate();
	// 		insertChangeLogQuery.close();
	// 		
	// 		/*
	// 		 * End Change - EQuint - Defect 3437885 - 2016-05-18
	// 		 */
	// 		
	// 		
	// 	}
	// 	
	// 	/*
	// 	 * Start Add - EQuint - Defect 3437885 - 2016-05-18
	// 	 */
	// 	getCreditRatingHistories.close();
	// 	/*
	// 	 * End Add - EQuint - Defect 3437885 - 2016-05-18
	// 	 */
	// 
	// }
	// 
	// /**
	//  * This method returns a randomly generated key.
	//  * @return BigInteger
	//  */
	// private BigInteger generateChangeLogId() {
	// 
	// 	PreparedStatement createId = createPreparedStatement("SELECT " +
	// 			"	(TO_NUMBER(ROUND(DBMS_RANDOM.VALUE(1,99999999999999),0))) AS CHG_LOG_ID " +
	// 			" FROM " +
	// 			"	DUAL ", getClass().getName());
	// 
	// 	SQLResultRow row = createId.firstRow();
	// 	BigInteger intId = row.getInteger("CHG_LOG_ID");
	// 
	// 	createId.close();
	// 
	// 	return intId;
	// }
	// /**
	//  * This method checks if the generated key is unique to the Change Log table.
	//  * @param BigInteger
	//  * @return Bool
	//  */
	// private Bool isUniqueChangeLogId(BigInteger changeLogId) {
	// 
	// 	Bool isUnique = Bool.FALSE;
	// 
	// 	PreparedStatement checkId = createPreparedStatement("SELECT " +
	// 			"	CHG_LOG_ID " +
	// 			" FROM " +
	// 			"	CI_CHG_LOG " +
	// 			" WHERE " +
	// 			"	CHG_LOG_ID = :changeLogId", getClass().getName());
	// 
	// 	checkId.bindId("changeLogId", new ChangeLogTable_Id(changeLogId));
	// 	
	// 	// start update - equint - 2025-11-14 - CCB25.4 Upgrade
	// 	// List checkIdList = checkId.list();
	// 
	// 	// if(notNull(checkIdList) || !checkIdList.isEmpty()) {
	// 	// 	isUnique = Bool.TRUE;
	// 	// }
	// 	if (isNull(checkId.firstRow())) {
	// 		isUnique = Bool.TRUE;
	// 	}
	// 	// end update - equint - 2025-11-14 - CCB25.4 Upgrade
	// 	checkId.close();
	// 
	// 	return isUnique;
	// }
	// end delete - equint - 2026-03-04 - Defect 5167721
	
	public Class<CmCustomerMasterDeltaExtractBatchWorker> getThreadWorkerClass() {
		return CmCustomerMasterDeltaExtractBatchWorker.class;
	}

	public static class CmCustomerMasterDeltaExtractBatchWorker extends
	CmCustomerMasterDeltaExtractBatchWorker_Gen {

		//Work Variable
        private Cmpcmden cmpcmden;
        /*
		 * Start Delete - EQuint - Defect 3437885 - 2016-05-18
		 */
		// private int extractRecordCount = 0;
		/*
		 * End Delete - EQuint - Defect 3437885 - 2016-05-18
		 */
		private BufferedWriter outputWriter;
		private File extractFile;

		//Batch Parameter
		private String parmFilePath;
		private String parmFileName;
		/*
		 * Start Delete - EQuint - Defect 3437885 - 2016-05-18
		 */
		// private BigInteger parmMaxErrors;
		/*
		 * End Delete - EQuint - Defect 3437885 - 2016-05-18
		 */
		private String parmRunMode;
		private BigInteger parmExcludeMonths;
		/*
		 * Start Delete - EQuint - Defect 3437885 - 2016-05-18
		 */
		// private BigInteger parmIncludeCrHistDays;
		/*
		 * End Delete - EQuint - Defect 3437885 - 2016-05-18
		 */
		private FeatureConfiguration parmMstrDltaFtrName;
		private CmCustomerMasterDeltaExtractOptionLookup parmResCustClassOptType;
		private CmCustomerMasterDeltaExtractOptionLookup parmComCustClassOptType;
		private CmCustomerMasterDeltaExtractOptionLookup parmEbillEligRtOptType;
		private CmCustomerMasterDeltaExtractOptionLookup parmEbillNeligChOptType;
		private CharacteristicType parmNonPaySaCharType;
		private String parmNonPaySaCharVal;
		private CharacteristicType parmCharitySaCharType;
		private String parmCharitySaCharVal;
		/*
		 * Start - GCinco - CCB-CC-007 - 2017-01-26
		 */
		private Bool overrideEbillSw;
		/*
		 * End - GCinco - CCB-CC-007 - 2017-01-26
		 */

		/*
		 * Start - JTiozon - B-15263 - 2020-03-26
		 */
		private CharacteristicType thirdParyBpayCharType;
		private String thirdParyBpayCharVal;
		private FeatureConfiguration allUserProcessing;
		/*
         * End - JTiozon - B-15263 - 2020-03-26
         */
		/*
		 * Start - Kiran - B-15263 - 2020-04-21
		 */
		private CharacteristicType ebillCharType;
		private String ebillCharVal;
		/*
         * End - Kiran - B-15263 - 2020-04-21
         */
		private Bool addrErrorSw;
		private String fileRecord = "";
		private BigDecimal cashOnly = BigDecimal.ZERO;

		//Unit Variables
		private Account_Id acctId;
		private String cisDivision;
		private String customerClass;
		
		/*
		 * Start Add - EQuint - Defect 3437885 - 2016-05-18
		 */
		private FrameworkSession session;
		private RequestContext context;
		// start delete - equint - 2026-03-04 - Defect 5167721
		// private Connection connection;
		// end delete - equint - 2026-03-04 - Defect 5167721
		/*
		 * End Add - EQuint - Defect 3437885 - 2016-05-18
		 */
		
		// start add - equint - 2026-03-04 - Defect 5167721 
		private String typeFlag1 = "U   ";
		private String typeFlag2 = "I   ";
		// end add - equint - 2026-03-04 - Defect 5167721 

		
		public ThreadExecutionStrategy createExecutionStrategy() {
			// start edit - equint - 2026-03-04 - Defect 5167721 
			// return new SingleTransactionStrategy(this);
			return new ThreadIterationStrategy(this);
			// end edit - equint - 2026-03-04 - Defect 5167721 
		}
		
		@Override
		public void initializeThreadWork(boolean flag)
				throws ThreadAbortedException, RunAbortedException {
			
			//Batch Parameter
			parmFilePath = getParameters().getFILE_PATH();
			parmFileName = getParameters().getFILE_NAME();
			/*
			 * Start Delete - EQuint - Defect 3437885 - 2016-05-18
			 */
			// parmMaxErrors = getParameters().getMAX_ERRORS();
			/*
			 * End Delete - EQuint - Defect 3437885 - 2016-05-18
			 */
			parmRunMode = getParameters().getRUN_MODE();
			parmExcludeMonths = getParameters().getEXCLUDE_MONTHS();
			/*
			 * Start Delete - EQuint - Defect 3437885 - 2016-05-18
			 */
			// parmIncludeCrHistDays = getParameters().getINCLUDE_CR_HIST_DAYS();
			/*
			 * End Delete - EQuint - Defect 3437885 - 2016-05-18
			 */
			parmMstrDltaFtrName = getParameters().getMSTR_DLTA_FTR_NAME();
			parmResCustClassOptType = getParameters().getRES_CUST_CLASS_OPT_TYPE();
			parmComCustClassOptType = getParameters().getCOM_CUST_CLASS_OPT_TYPE();
			parmEbillEligRtOptType = getParameters().getEBILL_ELIG_RT_OPT_TYPE();
			parmEbillNeligChOptType = getParameters().getEBILL_NELIG_CH_OPT_TYPE();
			parmNonPaySaCharType = getParameters().getNON_PAY_SA_CHAR_TYPE();
			parmNonPaySaCharVal = getParameters().getNON_PAY_SA_CHAR_VAL();
			parmCharitySaCharType = getParameters().getCHARITY_SA_CHAR_TYPE();
			parmCharitySaCharVal = getParameters().getCHARITY_SA_CHAR_VAL();
			/*
			 * Start - GCinco - CCB-CC-007 - 2017-01-26
			 */
			overrideEbillSw = getParameters().getOVERRIDE_EBILL_SW();
			/*
			 * End - GCinco - CCB-CC-007 - 2017-01-26
			 */
			/*
			 * Start - JTiozon - B-15263 - 2020-03-26
			 */
			thirdParyBpayCharType = getParameters().getTHIRD_PTY_BPAY_CHAR_TYPE();
			thirdParyBpayCharVal = getParameters().getTHIRD_PTY_BPAY_CHAR_VAL();
			allUserProcessing = getParameters().getALL_USER_PROCESSING();
			/*
			 * End - JTiozon - B-15263 - 2020-03-26
			 */
			/*
			 * Start - Kiran - B-15263 - 2020-04-21
			 */
			ebillCharType = getParameters().getEBILL_ENROLL_CHAR_TYPE();
			ebillCharVal = getParameters().getEBILL_ENROLL_CHAR_VALUE();
			
			/*
			 * End - Kiran - B-15263 - 2020-04-21
			 */
			// Get Cash Only Threshold from Installation record
			PreparedStatement cashOnlyThreshold = createPreparedStatement(
					"SELECT CASH_ONLY_PTS_THRS FROM CI_INSTALLATION", getClass().getName());
			QueryResultRow cashOnlyRow = cashOnlyThreshold.firstRow();
			/*
			 * Start Add - EQuint - Defect 3437885 - 2016-05-18
			 */
			cashOnlyThreshold.close();
			/*
			 * End Add - EQuint - Defect 3437885 - 2016-05-18
			 */
			cashOnly = cashOnlyRow.getBigDecimal("CASH_ONLY_PTS_THRS").toBigDecimal();
			if(cashOnly.compareTo(BigDecimal.ZERO) < 0) {
				addError(CustomMessageRepository.JACOB_InvalidNumericValue(cashOnly.toString()));
			}

			// If ?? is present in the file name, replace it with the thread number
			if (parmFileName.indexOf("??") >= 0) {
				parmFileName = parmFileName.replace("??", String.format("%02d", getBatchThreadNumber()));
			} else if (parmFileName.indexOf("?") >= 0) {

				if(getBatchThreadNumber().compareTo(BigInteger.valueOf(9)) > 0) {
					addError(StandardMessages.fieldMissing(THREAD_NUMBER_DESC));
				}
				parmFileName = parmFileName.replace("?", String.format("%01d", getBatchThreadNumber()));
			}
			
			if (isBlankOrNull(parmFilePath)) {
				parmFilePath = new File("").getAbsolutePath();
			}
			extractFile = new File(parmFilePath, parmFileName);

			try {
				outputWriter = new BufferedWriter(new FileWriter(extractFile));		
			}
			catch(IOException ioe) {
				//If an error is encountered while opening the file, raise an error 
				addError(CustomMessageRepository.JACOB_FileOpenError(ioe.getMessage()));
			}

			
			try {
				// initialize program
				initializeCobolProgram();
				
				// start add - equint - 2026-03-04 - Defect 5167721 
				initializeCobolParms();
				// end add - equint - 2026-03-04 - Defect 5167721 
			}
			catch(Exception err) {
				addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), err.toString()));
			}
			
			// start add - equint - 2026-03-04 - Defect 5167721
			this.startResultRowQueryIteratorForThread(Account_Id.class);
			// end add - equint - 2026-03-04 - Defect 5167721
			
		}
		
		// start add - equint - 2026-03-04 - Defect 5167721 
		@Override
		protected QueryIterator getQueryIteratorForThread(StringId lowId, StringId highId) {
			
			String sql;
			PreparedStatement getMainPreparedStatement;
			
			if(getParameters().getRUN_MODE().compareToIgnoreCase("DELTA") == 0){
				checkCreditHistory();
				sql = " SELECT DISTINCT(ACCT.ACCT_ID), ACCT.CUST_CL_CD , ACCT.CIS_DIVISION " +
						" FROM CI_CHG_LOG CHL, CI_ACCT ACCT " +
						" WHERE CHL.BATCH_CD = :batchCode " +
						" AND CHL.BATCH_NBR = :batchNumber " +
						" AND CHL.PK_VAL1 = ACCT.ACCT_ID " +
						" AND CHL.CHG_TYPE_FLG IN (:typeFlag1, :typeFlag2) " + 
						" AND ACCT.ACCT_ID BETWEEN :lowID AND :highID";
				
				getMainPreparedStatement = createPreparedStatement(sql, getClass().getName());
				getMainPreparedStatement.bindId("batchCode", getBatchControlId());
				getMainPreparedStatement.bindBigInteger("batchNumber", getBatchNumber());
				getMainPreparedStatement.bindString("typeFlag1", typeFlag1, "CHL.CHG_TYPE_FLG");
				getMainPreparedStatement.bindString("typeFlag2", typeFlag2, "CHL.CHG_TYPE_FLG");
				
			}
			else {
				sql = "SELECT ACCT.ACCT_ID , ACCT.CUST_CL_CD, ACCT.CIS_DIVISION " +
							" 		  FROM CI_ACCT ACCT WHERE ACCT.ACCT_ID BETWEEN :lowID AND :highID";			
				
				getMainPreparedStatement = createPreparedStatement(sql, getClass().getName());
			}
			
			getMainPreparedStatement.bindId("lowID", lowId);
			getMainPreparedStatement.bindId("highID", highId);
			
			getMainPreparedStatement.setAutoclose(false);
			getMainPreparedStatement.execute();
			
			return getMainPreparedStatement.iterate();

        }	
		
		@Override
		protected ThreadWorkUnit getNextWorkUnit(QueryResultRow row) {
			
			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId(new Account_Id(row.getString("ACCT_ID")));
			workUnit.addSupplementalData("CUST_CL_CD", row.getString("CUST_CL_CD"));
			workUnit.addSupplementalData("CIS_DIVISION", row.getString("CIS_DIVISION"));

			return workUnit;
		}
		// end add - equint - 2026-03-04 - Defect 5167721 

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			/*
			 * Start Add - EQuint - Defect 3437885 - 2016-05-18
			 */
			try {
				// start edit - equint - 2026-03-04 - Defect 5167721 
				// initializeCobolParms();
				
				session = (FrameworkSession) SessionHolder.getSession();
				session.doWork(new ConnectionWork() {
		  			
		  			@Override
		  			public void execute(Connection connection) throws SQLException {
		  				try {  
							// assign new connection as it closes per work unit
		  					cmpcmden.getSession().getDbSession().setUpdateConnection(connection);
		  				}
		  				catch(Exception e) {
							throw new SQLException(e.getCause());
						}
						
					}
				});
				
				// end edit - equint - 2026-03-04 - Defect 5167721 
				
				
			}
			catch(Exception err) {
			 	addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), err.toString()));
			}
			/*
			 * End Add - EQuint - Defect 3437885 - 2016-05-18
			 */
			
			// set unit parameters
			acctId = (Account_Id) unit.getPrimaryId();
			customerClass = (String) unit.getSupplementallData("CUST_CL_CD");
			cisDivision = (String) unit.getSupplementallData("CIS_DIVISION");

			// reset program status and message numbers every unit
			cmpcmden.setProgramStatus(" ");
			cmpcmden.setMessageNbr(BigDecimal.ZERO);
			cmpcmden.setZmsgnMessageCatNbr(BigDecimal.ZERO);
			
			cmpcmden.setInputWrkPkVal1(acctId.getTrimmedValue());
			cmpcmden.setCustClCd(customerClass.trim());
			cmpcmden.setInputWrkCisDivision(cisDivision.trim());

			// set batch parameters
			cmpcmden.setRunMode(parmRunMode.trim());
			if(notNull(parmExcludeMonths)) {
				cmpcmden.setExcludeMonths(BigDecimal.valueOf(parmExcludeMonths.doubleValue()));
			}
			cmpcmden.setInputWrkBatchCd(getBatchControlId().getTrimmedValue());
			cmpcmden.setInputWrkBatchNbr(BigDecimal.valueOf(getBatchNumber().doubleValue()));
			cmpcmden.setMstrDltaFtrName(parmMstrDltaFtrName.getId().getIdValue());
			cmpcmden.setResCustClassOptType(parmResCustClassOptType.trimmedValue());
			cmpcmden.setComCustClassOptType(parmComCustClassOptType.trimmedValue());
			cmpcmden.setEbillEligRtOptType(parmEbillEligRtOptType.trimmedValue());
			cmpcmden.setEbillNeligChOptType(parmEbillNeligChOptType.trimmedValue());
			cmpcmden.setNonPaySaCharType(parmNonPaySaCharType.getId().getTrimmedValue());
			cmpcmden.setNonPaySaCharVal(parmNonPaySaCharVal.trim());
			cmpcmden.setCharitySaCharType(parmCharitySaCharType.getId().getTrimmedValue());
			cmpcmden.setCharitySaCharVal(parmCharitySaCharVal.trim());
			//Cash Only Threshold from Installation record
			cmpcmden.setCashOnlyPtsThrs(cashOnly);		
			/*
			 * Start - GCinco - CCB-CC-007 - 2017-01-26
			 */
			String overrideEbillSwParm = (overrideEbillSw.isTrue()) ? SWITCH_YES : SWITCH_NO;
			cmpcmden.setOverrideEBillSw(overrideEbillSwParm); 
			/*
             * Start - JTiozon - B-15263 - 2020-03-26
             */
			cmpcmden.setThirdPartyBillPayVndrCharType(thirdParyBpayCharType.getId().getTrimmedValue());
			cmpcmden.setThirdPartyBillPayVndrCharVal(thirdParyBpayCharVal.trim());
			cmpcmden.setAllUserProcessing(allUserProcessing.getId().getIdValue());
			/*
             * End - JTiozon - B-15263 - 2020-03-26
             */
			
			/*
             * Start - Kiran - B-15263 - 2020-04-21
             */
			cmpcmden.setEbillCharType(ebillCharType.getId().getTrimmedValue());
			cmpcmden.setEbillCharVal(ebillCharVal.trim());

			/*
             * End - Kiran - B-15263 - 2020-04-21
             */
			
			/*
			 * End - GCinco - CCB-CC-007 - 2017-01-26
			 */
			callCobol();
			/*
			 * Start Change - SFelip - Defect 4144085 - 2018-12-07
			 */
			//return !(cmpcmden.getAddrErrorSw().compareToIgnoreCase(SWITCH_YES) == 0);
			if(cmpcmden.getAddrErrorSw().compareToIgnoreCase(SWITCH_NO) == 0) {
				return true;
			} else {
				return false;
			}
			/*
			 * End Change - SFelip - Defect 4144085 - 2018-12-07
			 */
		}

		/**
		 * Write Line to File
		 */
		private void writeLine(String recordline){              
			try {
				outputWriter.write(recordline);
				outputWriter.newLine();
			} catch (IOException e) {
				addError(CustomMessageRepository.JACOB_FileWriteError(e.getMessage()));  
			}
		}
		
		@Override
		public void finalizeThreadWork() throws ThreadAbortedException,
				RunAbortedException {
			
			try {
				outputWriter.close();	
				/*
				 * Start Add - EQuint - Defect 3437885 - 2016-05-22
				 */
				cmpcmden=Session.returnSessionAndCodeToCache(cmpcmden);
				// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
				// connection.close();
				// end delete - equint - 2025-11-14 - CCB25.4 Upgrade
				/*
				 * End Add - EQuint - Defect 3437885 - 2016-05-22
				 */
			}
			catch(IOException ioe) {
				//If an error is encountered while opening the file, raise an error 
			    addError(CustomMessageRepository.JACOB_FileCloseError(ioe.getMessage()));
			}
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
			// catch(SQLException se) {
			// 	addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getIdValue(), se.getMessage()));
			// }
			// end delete - equint - 2025-11-14 - CCB25.4 Upgrade
			
		}

		
		/*
		 * Initialize cobol program
		 */
		/*
		 * Start Change - EQuint - Defect 3437885 - 2016-05-22
		 */
		// private void initializeCobolProgram() throws Exception {
		@SuppressWarnings("deprecation")
		private void initializeCobolParms() throws Exception {
			
			// FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
			// RequestContext context = session.getRequestContext();
            // 
			// SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
			// Connection connection = implementor.getConnectionProvider().getConnection();
            // 
			// String username = connection.getMetaData().getUserName();
			// String url = connection.getMetaData().getURL();
            // 
			// CobolSession.setLogSessionStartEnd(false);
			// cmpcmden=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpcmden.class);
            // 
			// cmpcmden.getSession().getDbSession().setUpdateConnection(connection);
			// cmpcmden.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
			
			cmpcmden.aa100Initialize();
			
		/*
		 * End Change - EQuint - Defect 3437885 - 2016-05-22
		 */
			
			// set ZSTAT parameters

			cmpcmden.setProcessDttmProcessDt(getProcessDateTime().getDate().toString());
			cmpcmden.setProcessDttmSep("-");
			cmpcmden.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");

			if (session.isOnlineConnection()) { 
				cmpcmden.setConnectionFlg(CONNECTION_ONLINE);
			}
			else {
				cmpcmden.setConnectionFlg(CONNECTION_BATCH);
			}

			cmpcmden.setUserId(context.getUserId()); 
			cmpcmden.setLanguageCd(context.getLanguageCode());

			if (context.ignoreWarnings()) {
				cmpcmden.setIgnoreWarningSw(SWITCH_YES);
			}
			else {
				cmpcmden.setIgnoreWarningSw(SWITCH_NO);
			}

			if (session.getBatchInstanceId() != null) {
				cmpcmden.setZstatSchedulerId(new BigDecimal(session.getBatchInstanceId()));
				cmpcmden.setSchedulerId(new BigDecimal(session.getBatchInstanceId()));

			} else {
				cmpcmden.setZstatSchedulerId(new BigDecimal(0));
				cmpcmden.setSchedulerId(new BigDecimal(0));
			}

			cmpcmden.setAppSvcId(context.getSecurityServiceIdContext());

			DatabaseHelper dbHelper = session.getDatabaseHelper();
			cmpcmden.setDbMode(dbHelper.getCobolDBMode());
			// CCB v2.6 Upgrade - 2018-05-31 - Start Change
			//cmpcmden.setSplHighValue(cmpcmden.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
			//cmpcmden.setSplLowValue(cmpcmden.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
			
			cmpcmden.setSplHighValue(cmpcmden.getSession().getSettings().getString(
			        new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
            cmpcmden.setSplLowValue(cmpcmden.getSession().getSettings().getString(
                    new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
			// CCB v2.6 Upgrade - 2018-05-31 - End Change

			cmpcmden.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()));
			
			cmpcmden.setLkExpiryDt(Date.MAX.toString());
			
			cmpcmden.setProgramStatus(" ");
			
			// CCB v2.6 Upgrade - 2018-08-02 - Start Add
	        cmpcmden.setCallSeq(";");
	        cmpcmden.setMessageAreaProgramName("CMPCMDEN");
	        // CCB v2.6 Upgrade - 2018-08-02 - End Add

			if (context.getRandomGeneratorSeedSet().isTrue()) {
				cmpcmden.setRandomGenSeedSw(SWITCH_YES);
				cmpcmden.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()));
				cmpcmden.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()));
				cmpcmden.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()));
				cmpcmden.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()));
			}
			else {
				cmpcmden.setRandomGenSeedSw(SWITCH_NO);
			}

			if (context.traceStandardOut()) { 
				cmpcmden.setTrcStdoutSw(SWITCH_YES);
			}
			else {
				cmpcmden.setTrcStdoutSw(SWITCH_NO);
			}

			if (context.traceProgramStart()) { 
				cmpcmden.setTrcProgStartSw(SWITCH_YES);
			}
			else {
				cmpcmden.setTrcProgStartSw(SWITCH_NO);
			}

			if (context.traceProgramExit()) { 
				cmpcmden.setTrcProgExitSw(SWITCH_YES);
			}
			else {
				cmpcmden.setTrcProgExitSw(SWITCH_NO);
			}

			if (context.traceSQL()) { 
				cmpcmden.setTrcExecSqlSw(SWITCH_YES);
			}
			else {
				cmpcmden.setTrcExecSqlSw(SWITCH_NO);
			} 

		}
		
		/*
		 * Start Add - EQuint - Defect 3437885 - 2016-05-22
		 */
		private void initializeCobolProgram() throws Exception {
			
			session = (FrameworkSession) SessionHolder.getSession();
			context = session.getRequestContext();
			
			// start update - equint - 2025-11-14 - CCB25.4 Upgrade
			
			// SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
			// 
			// connection = implementor.getConnectionProvider().getConnection();
			// String username = connection.getMetaData().getUserName();
			// String url = connection.getMetaData().getURL();
			// 
			// CobolSession.setLogSessionStartEnd(false);
			// cmpcmden=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpcmden.class);
			// 
			// cmpcmden.getSession().getDbSession().setUpdateConnection(connection);
			// cmpcmden.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
			
			session.doWork(new ConnectionWork() {
	  			
	  			@Override
	  			public void execute(Connection connection) throws SQLException {
	  				try {  
	  					String username = connection.getMetaData().getUserName();
	  					String url = connection.getMetaData().getURL();
	  					
	  					CobolSession.setLogSessionStartEnd(false);
	  					cmpcmden=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpcmden.class);

	  					cmpcmden.getSession().getDbSession().setUpdateConnection(connection);
	  					cmpcmden.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
	  				}
	  				catch(Exception e) {
						throw new SQLException(e.getCause());
					}
					
				}
			});
			
			// end update - equint - 2025-11-14 - CCB25.4 Upgrade
		}
		/*
		 * End Add - EQuint - Defect 3437885 - 2016-05-22
		 */

		private void callCobol() {
			try {
				
				cmpcmden.cobolMain();
				
			} catch(Exception _ex) {
				Throwable ex=_ex;
				ex.printStackTrace();
				while(ex.getCause()!=null) ex=ex.getCause();
				
				if(ex instanceof Stop) {

					// if message number and category are not 0, meaning a server message is passed from the jacob code
					if (cmpcmden.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
							&& cmpcmden.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {

						// pass the parameter to the server message
						MessageParameters messageparameters = new MessageParameters();
						for (int i = 1; i <= 9; i++) {
							try { 
								String parmValue = cmpcmden.getMessageParm(i);
								if (notBlank(parmValue)) {
									messageparameters.addRawString(parmValue.trim());
								}
							}
							catch(IndexOutOfBounds e) {
								break;
							}

						}
						MessageCategory_Id categoryId = new MessageCategory_Id(cmpcmden.getZmsgnMessageCatNbr().toBigInteger());
						ServerMessage serverMessage = 
								ServerMessageFactory.Factory.newInstance().createMessage(
										categoryId, cmpcmden.getMessageNbr().intValue(), messageparameters);

						// check the message severity so we'll know what type of message to raise
						// info
			    		if (cmpcmden.getMessageSeverity().compareTo(
			    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
			    			logInfo(serverMessage);
			    		}
			    		// warning
			    		else if (cmpcmden.getMessageSeverity().compareTo(
			    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
			    			logWarning(serverMessage);
			    		}
			    		// error
			    		else {
			    			logError(serverMessage);
			    		}
					}

					// The following are the output returned CMPCMDEN
					/*
					 * Start Change - SFelip - Defect 4144085 - 2018-12-07
					 */
					//addrErrorSw = Bool.valueOf(cmpcmden.getAddrErrorSw().compareToIgnoreCase(SWITCH_YES) == 0);
					if(cmpcmden.getAddrErrorSw().compareToIgnoreCase(SWITCH_NO) == 0) {
						addrErrorSw = Bool.FALSE;
					} else{
						addrErrorSw = Bool.TRUE;
					}
					/*
					 * End Change - SFelip - Defect 4144085 - 2018-12-07
					 */
					fileRecord = String.valueOf(cmpcmden.getFileRec());
					//If Add Error SW = 'N'
					// 2016-07-20. SMiran. Defect 3477729. Start Change
					//if(addrErrorSw.isFalse()) {
					if(addrErrorSw.isFalse() && notBlank(fileRecord)) {
					// 2016-07-20. SMiran. Defect 3477729. End Change
						//Write FILE-REC to extract file
						// 2016-07-20. SMiran. Defect 3477729. Start Add
						if (parmRunMode.trim().equals("MASTER")){
							fileRecord = fileRecord + " ";
						}
						// 2016-07-20. SMiran. Defect 3477729. End Add
						writeLine(fileRecord);
						/*
						 * Start Delete - EQuint - Defect 3437885 - 2016-05-18
						 */
						// //Add 1 to records processed
						// extractRecordCount++;
						/*
						 * End Delete - EQuint - Defect 3437885 - 2016-05-18
						 */
					}

				}
				/*
				 * Start Add - SFelip - Defect 4144085 - 2018-12-07
				 */
				else if(ex instanceof ApplicationError) {
					logError(((ApplicationError) ex).getServerMessage());
				}
				/*
				 * End Add - SFelip - Defect 4144085 - 2018-12-07
				 */
				else  {
					addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), ex.toString()));
				}
			}
		}
		
		// start add - equint - 2026-03-04 - Defect 5167721
		
		private void checkCreditHistory() {
			
			/*
			 * Subtract the number of days defined by the Include X Days
			 * of Credit History Expiration batch parameter from the
			 * process date.  This will serve as start of the range of
			 * included credit rating histories for processing.
			 */
			BigInteger creditHistoryExpiration = getParameters().getINCLUDE_CR_HIST_DAYS();
			Date startDateOfIncludedCreditRating = getProcessDateTime().getDate().addDays(creditHistoryExpiration.negate().intValue());

			/*
			 * Retrieve the Credit Rating Histories that have expired
			 * within the computed time frame.
			 */
			PreparedStatement getCreditRatingHistories = createPreparedStatement(
					"SELECT DISTINCT(CRH.ACCT_ID) " +
							" FROM CI_CR_RAT_HIST CRH" +
							" WHERE CRH.END_DT IS NOT NULL " +
							" AND CRH.END_DT >= :startDt " +
							" AND CRH.END_DT <= :endDt " +
							" 	   AND NOT EXISTS(SELECT 'X' " +
							"	   FROM CI_CHG_LOG CHL " +
							" WHERE CHL.PK_VAL1 = CRH.ACCT_ID " +
							"      AND CHL.BATCH_CD = :batchCd " +
							"	   AND CHL.BATCH_NBR = :batchNumber " +
							"	   AND CHL.CHG_TYPE_FLG IN ('I   ','U   ') )", getClass().getName());

			getCreditRatingHistories.bindDate("startDt", startDateOfIncludedCreditRating);
			getCreditRatingHistories.bindDate("endDt", getProcessDateTime().getDate());
			getCreditRatingHistories.bindId("batchCd", getBatchControlId());
			getCreditRatingHistories.bindBigInteger("batchNumber", getBatchNumber());


			/*
			 * For each record retrieved, Insert a new record in the
			 * Change Log table
			 */
			List<SQLResultRow> creditHistoriesResultRowList = getCreditRatingHistories.list();
			for(SQLResultRow creditHistoriesResultRow:creditHistoriesResultRowList){

				Account_Id acctId = (Account_Id) creditHistoriesResultRow.getId("ACCT_ID", Account.class);

				// Generate Change Log ID.
				ChangeLogTable_Id changeLogId = null;
				Bool isUniqueId = Bool.FALSE;
				while(isUniqueId.isFalse()) {

					BigInteger genId = generateChangeLogId();

					if(isUniqueChangeLogId(genId).isTrue()) {
						changeLogId = new ChangeLogTable_Id(genId);
						isUniqueId = Bool.TRUE;
						break;
					}
				}
				// Create a Change Log record.
				
				Table_Id saTableId = new Table_Id(ACCT_TABLE);
				
				PreparedStatement insertChangeLogQuery = createPreparedStatement("INSERT INTO CI_CHG_LOG "
						+ " (CHG_LOG_ID, BATCH_CD, BATCH_NBR, CHG_DTTM, CHG_TYPE_FLG, TBL_NAME, PK_VAL1) "
						+ " VALUES (:id, :batchCd, :batchNbr, :chgDttm, :chgTypeFlg, :tblName, :pkVal1) ", getClass().getName());
				
				insertChangeLogQuery.bindId("id", changeLogId);
				insertChangeLogQuery.bindId("batchCd", getBatchControlId());
				insertChangeLogQuery.bindBigInteger("batchNbr", getBatchNumber());
				insertChangeLogQuery.bindDateTime("chgDttm", getProcessDateTime());
				insertChangeLogQuery.bindStringProperty("chgTypeFlg", ChangeLogTable.properties.changeType, typeFlag2);
				insertChangeLogQuery.bindId("tblName", saTableId);
				insertChangeLogQuery.bindStringProperty("pkVal1", ChangeLogTable.properties.pkVal1, acctId.getIdValue());
				
				insertChangeLogQuery.executeUpdate();
				insertChangeLogQuery.close();
				
			}
			
			getCreditRatingHistories.close();
		}

		/**
		 * This method returns a randomly generated key.
		 * @return BigInteger
		 */
		private BigInteger generateChangeLogId() {

			PreparedStatement createId = createPreparedStatement("SELECT " +
					"	(TO_NUMBER(ROUND(DBMS_RANDOM.VALUE(1,99999999999999),0))) AS CHG_LOG_ID " +
					" FROM " +
					"	DUAL ", getClass().getName());

			SQLResultRow row = createId.firstRow();
			BigInteger intId = row.getInteger("CHG_LOG_ID");

			createId.close();

			return intId;
		}
		
		/**
		 * This method checks if the generated key is unique to the Change Log table.
		 * @param BigInteger
		 * @return Bool
		 */
		private Bool isUniqueChangeLogId(BigInteger changeLogId) {

			Bool isUnique = Bool.FALSE;

			PreparedStatement checkId = createPreparedStatement("SELECT " +
					"	CHG_LOG_ID " +
					" FROM " +
					"	CI_CHG_LOG " +
					" WHERE " +
					"	CHG_LOG_ID = :changeLogId", getClass().getName());

			checkId.bindId("changeLogId", new ChangeLogTable_Id(changeLogId));

			if (isNull(checkId.firstRow())) {
				isUnique = Bool.TRUE;
			}

			checkId.close();

			return isUnique;
		}
		
		// end add - equint - 2026-03-04 - Defect 5167721

	}

	/**
	 * This method validates if characteristic value is valid for a given characteristic type. 
	 * @param charType - Characteristic Type
	 * @param charValue - String
	 * @return Bool
	 */
	private Bool validateCharTypeAndCharValue(CharacteristicType charType, String charValue) {

		CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
		if (charTypeLookup.isPredefinedValue()) {
			CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charType, charValue);
			if (isNull(charValueId.getEntity())) {
				return Bool.FALSE;
			}
		}

		return Bool.TRUE;
	}

	public void validateSoftParameters(boolean isNewRun) {
		// Validate that RUN-MODE parameter is either 'DELTA' or 'MASTER'
		String deltaOrMasterRunMode = getParameters().getRUN_MODE();
		if (!(deltaOrMasterRunMode.equalsIgnoreCase("DELTA") || deltaOrMasterRunMode.equalsIgnoreCase("MASTER"))) {
			addError(CustomMessageRepository.JACOB_valueEitherMorD(DAILY_OR_MONTHLY_SW, deltaOrMasterRunMode));

		}
		// If supplied, validate that EXCLUDE-MONTHS is an integer greater than zero
		BigInteger excludeMonths = getParameters().getEXCLUDE_MONTHS();
		if (notNull(excludeMonths)) {
			if(excludeMonths.compareTo(BigInteger.ZERO) < 0) {
				addError(CustomMessageRepository.JACOB_InvalidNumericValue(excludeMonths.toString()));
			}
			
			// If supplied, validate that INCLUDE-CR-HIST-DAYS is an integer greater than zero
			BigInteger includeCrHistDays = getParameters().getINCLUDE_CR_HIST_DAYS();
			if (notNull(includeCrHistDays)) {
				if(excludeMonths.compareTo(BigInteger.ZERO) < 0) {
					addError(CustomMessageRepository.JACOB_InvalidNumericValue(excludeMonths.toString()));
				}

			}

		}
		/*
		 * Start - Kiran - B-15263 - 2020-04-21
		 */
		
		String ebillCharVal = getParameters().getEBILL_ENROLL_CHAR_VALUE();
		if(validateCharTypeAndCharValue(getParameters().getEBILL_ENROLL_CHAR_TYPE(), ebillCharVal).isFalse()) {
			addError(CustomMessageRepository.JACOB_charValueInvalidForCharType(ebillCharVal, getParameters().getEBILL_ENROLL_CHAR_TYPE().toString()));
		}
		
		/*
		 * End - Kiran - B-15263 - 2020-04-21
		 */
		// Validate that NON-PAY-SA-CHAR-VAL is a valid value for NON-PAY-SA-CHAR-TYPE
		// Validate that CHARITY-SA-CHAR-VAL is a valid value for CHARITY-SA-CHAR-TYPE
		String nonPaySaCharVal = getParameters().getNON_PAY_SA_CHAR_VAL();
		if(validateCharTypeAndCharValue(getParameters().getNON_PAY_SA_CHAR_TYPE(), nonPaySaCharVal).isFalse()) {
			addError(CustomMessageRepository.JACOB_charValueInvalidForCharType(nonPaySaCharVal, getParameters().getNON_PAY_SA_CHAR_TYPE().toString()));
		}
	}

}
