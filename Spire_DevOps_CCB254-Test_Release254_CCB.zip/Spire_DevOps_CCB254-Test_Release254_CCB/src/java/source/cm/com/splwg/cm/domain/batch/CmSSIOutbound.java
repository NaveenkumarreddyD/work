/**********************************************************************************************
 * Program Name: CmSSIOutbound
 * Program Title: CmSSIOutbound
 * Author: Sharma Diksha
 * Creation Date: 2019-07-11
 * Purpose: This batch process will create a flat file of new applicants and customers currently 
 * 			receiving the customer charge exemption to send to the state of AL.
 * 
 **********************************************************************************************/
/*----------------------------------------------------------------------------------------
 *-------------------------- Modification HISTORY: ---------------------------------------
 * ---------------------------------------------------------------------------------------
 * Modification ID:   CCTicket:	  Author:          Date:       Description:
.* --------------------------------------------------------------------------------------
 * CCB002  	       	  46096   	 Diksha Sharma     2019-07-11   TMG02493 - Initial Version
 * CCB002			  46096	 	 Ravi			   2020-06-17	File Layout Record total size 
 *																updated to 194
 * CCB002			  46096	 	 Ravi			   2021-03-30	Added Decryption logic for 
 *																encrypted SSI Id value and
 *                                                              marking  PREM_CHAR_TYPE as optional                                            
 *                                                      
 *****************************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.util.StringTokenizer;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.encryption.DecryptedValue;
import com.splwg.base.api.lookup.BusinessObjectStatusConditionLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObject_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.idType.entity.IdType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonId;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.security.common.FieldEncryptionDecryption;
import com.splwg.ccb.domain.security.data.FieldEncryptionDecryptionData;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.StringUtilities;

/**
 * @author Diksha
 *
@BatchJob (multiThreaded = false, rerunnable = true, modules =  {} ,
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = SSI_REQUEST_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CIS_DIVISION_LIST, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PREM_CHAR_TYPE, required = false, type = entity)    
 *            })
 */
public class CmSSIOutbound extends CmSSIOutbound_Gen {

	//Constants
	private static final String DELIMITER = ",";
	private static final String file_path = "FILE_PATH";
	private static final String cis_div_list = "CIS_DIVISION_LIST";

	//Work Variables
	private String strFilePath;
	private String strCisDivisionList;


	public void validateSoftParameters(boolean isNewRun){
		initializeSoftParams();

		// Validate if the file path is valid
		File folder = new File(strFilePath);
		if(!(folder.exists() && folder.isDirectory())) {
			addError(CustomMessageRepository.SA269362_parameterIsInvalid(file_path,strFilePath));
		}

		// Validate Parameter CIS Division
		StringTokenizer strTokenizerCis = new StringTokenizer(strCisDivisionList, DELIMITER);
		int cisDivisionCount = strTokenizerCis.countTokens();
		if (cisDivisionCount < 1) {
			addError(CustomMessageRepository.SA269362_parameterIsMissing(cis_div_list));
		}

		for (int i=0; i < cisDivisionCount; i++){
			String cisDivisionStr = strTokenizerCis.nextToken();
			CisDivision cisDivision = new CisDivision_Id(cisDivisionStr.trim()).getEntity();
			if (isNull(cisDivision)){
				addError(CustomMessageRepository.SA269362_parameterIsInvalid(cis_div_list, cisDivisionStr.trim()));
			}
		}

	}

	private void initializeSoftParams(){
		//Intialize Soft Parameters
		strFilePath = getParameters().getFILE_PATH();
		strCisDivisionList = getParameters().getCIS_DIVISION_LIST();                        
	}

	public JobWork getJobWork() {
		// Create Job Work with dummy work unit
		List<ThreadWorkUnit> threadWorkUnitList = new ArrayList<ThreadWorkUnit>();
		threadWorkUnitList.add(new ThreadWorkUnit());
		return createJobWorkForThreadWorkUnitList(threadWorkUnitList);
	}

	public Class<CmSSIOutboundWorker> getThreadWorkerClass() {
		return CmSSIOutboundWorker.class;
	}

	public static class CmSSIOutboundWorker extends CmSSIOutboundWorker_Gen {

		//Constants
		private static final MaintenanceObject_Id ACCOUNT = new MaintenanceObject_Id("ACCOUNT");
		private static final MaintenanceObject_Id PREMISE = new MaintenanceObject_Id("PREMISE");
		private static final String RECIPIENT_ID_TYPE = "Recipient Identifier Type";
		private static final String BLANK = "";

		//Person ID length 
		private static final int PER_ID_LENGTH=9;
		private static final int ACCT_ID_LENGTH=13;
		private static final int DATE_LENGTH=8;
		private static final int DIVISION_LENGTH=3;
		private static final int FILLER_1_LENGTH=2;
		private static final int FILLER_2_LENGTH=141;
		private static final int FILLER_3_LENGTH=9;
		private static final int FILLER_4_LENGTH=9;


		//Soft Parameters
		private String parmFilePath;
		private String parmFileName;
		private ServiceTaskType parmSvcTaskType;
		private String parmCisDivisionListStr;
		private CharacteristicType parmPremDivCharType;
		private List<CisDivision_Id> parmCisDivisionIdList = new ArrayList<CisDivision_Id>(); 
		private int cisDivisionCount = 0;

		//Working Variables
		private File extractFile = null;
		private BufferedWriter outputFileWriter = null;
		private Person person = null;
		private Account_Id accountId = null;
		private Premise premise = null;
		private String recipientIdentifierType = BLANK;
		private String personIdNum = BLANK;
		private BigInteger numberOfRecordsProcessed = BigInteger.ZERO;
		private String divisionCharValue = BLANK;
		private Bool hadError = Bool.FALSE;
		private String errorMsg = BLANK;   


		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		public void initializeThreadWork(boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {

			//Soft Parameters
			parmFileName = getParameters().getFILE_NAME();
			parmFilePath = getParameters().getFILE_PATH();
			parmSvcTaskType = getParameters().getSSI_REQUEST_TYPE();
			parmCisDivisionListStr = getParameters().getCIS_DIVISION_LIST();
			parmPremDivCharType = getParameters().getPREM_CHAR_TYPE();

			// Validate Parameter CIS Division
			StringTokenizer strTokenizerCis = new StringTokenizer(parmCisDivisionListStr, DELIMITER);
			cisDivisionCount = strTokenizerCis.countTokens();
			for (int i=0; i < cisDivisionCount; i++){
				String cisDivisionStr = strTokenizerCis.nextToken();
				parmCisDivisionIdList.add(new CisDivision_Id(cisDivisionStr.trim()));
			}

			// Generate File name
			extractFile = new File(parmFilePath, parmFileName);
			try {
				// Open File
				outputFileWriter = new BufferedWriter(new FileWriter(extractFile));
			} catch (IOException iOException) {
				// Error in file : %1.(While Opening)
				throw new RunAbortedException(CustomMessageRepository.ni0026_6ErrorInFile(iOException.getMessage()));
			}

		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			//Read BO linked with SSI Request Type
			BusinessObjectInstance ssiRequestTypeBOInst = BusinessObjectInstance.create(parmSvcTaskType.getBusinessObject());
			ssiRequestTypeBOInst.setXMLString("serviceTaskType", parmSvcTaskType.getId().getIdValue());
			ssiRequestTypeBOInst = BusinessObjectDispatcher.read(ssiRequestTypeBOInst);

			//Retrieve Recipient Identifier Type from schema
			COTSInstanceNode ssiIntegrationDetails = ssiRequestTypeBOInst.getGroup("ssiIntegrationDetails");
			if(isNull(ssiIntegrationDetails)){
				hadError=Bool.TRUE;
				errorMsg = CustomMessageRepositorySpireOne.cmCcb002SSIInvalidSsiRequestTypeBo().getMessageText();
				return false;
			}else{
				recipientIdentifierType = ssiIntegrationDetails.getString("recipientIdentifierType");
				if(isBlankOrNull(recipientIdentifierType)){
					hadError=Bool.TRUE;
					errorMsg=CustomMessageRepositorySpireOne.cmCcb002SSIMissingParam(RECIPIENT_ID_TYPE).getMessageText();
					return false;
				}
			}

			// Retrieving customers having open SSI for the specified CIS division(s).
			List<SQLResultRow> openSSIPersonList = retrieveOpenSSIPerson();

			if(!openSSIPersonList.isEmpty()){
				String batchDate = StringUtilities.padRight(formatDate(getProcessDateTime().getDate()),DATE_LENGTH);
				String filler1 = StringUtilities.padRight(null, FILLER_1_LENGTH);
				String filler2 = StringUtilities.padRight(null, FILLER_2_LENGTH);
				String filler3 = StringUtilities.padRight(null, FILLER_3_LENGTH);
				String filler4 = StringUtilities.padRight(null, FILLER_4_LENGTH);
				StringBuffer newRecord;
				int maxSize= openSSIPersonList.size();
				for(SQLResultRow ssiInfoRow : openSSIPersonList){
					person = ssiInfoRow.getEntity("PER_ID", Person.class);
					accountId = (Account_Id) ssiInfoRow.getId("ACCT_ID", Account.class);
					premise = ssiInfoRow.getEntity("PREM_ID", Premise.class);
					if(isNull(premise)){
						hadError=Bool.TRUE;
						errorMsg = CustomMessageRepositorySpireOne.cmCcb002SSIPremiseMissing(accountId.getIdValue()).getMessageText();
						return false;
					}
					personIdNum = getPersonIdNum(person);
					if(isBlankOrNull(personIdNum)) {
						hadError=Bool.TRUE;
						errorMsg = CustomMessageRepositorySpireOne.cmCcb002SSIPerIdNumMissing(recipientIdentifierType, person.getId().getIdValue()).getMessageText();
						return false;
					}

					divisionCharValue = BLANK;
					//Start Change - Ravi - 03302021 - Making characteristic optional
					if(notNull(parmPremDivCharType)){
						PremiseCharacteristic divisionChar= premise.getEffectiveCharacteristicAsOfDate(parmPremDivCharType, getProcessDateTime().getDate());
						if(notNull(divisionChar)) {
							divisionCharValue = divisionChar.getSearchCharacteristicValue();
						}
					}
					//End Change - Ravi - 03302021 - Making characteristic optional

					// write to file
					newRecord  = new StringBuffer();
					newRecord.append( StringUtilities.padRight(personIdNum.trim().replace("-", BLANK), PER_ID_LENGTH));
					newRecord.append( filler1);
					newRecord.append( StringUtilities.padRight(accountId.getTrimmedValue(),ACCT_ID_LENGTH));
					newRecord.append( filler2);
					newRecord.append( batchDate);
					newRecord.append( filler3);
					newRecord.append( StringUtilities.padRight(divisionCharValue,DIVISION_LENGTH));
					newRecord.append( filler4);
					writeIntoFile(maxSize,newRecord.toString());
					numberOfRecordsProcessed = numberOfRecordsProcessed.add(BigInteger.ONE);
				}

			}

			return true;
		}

		/**
		 * This function will retrieve the Id Number for given Id type of person.
		 * @param person
		 * @return
		 */
		private String getPersonIdNum(Person person) {
			ListFilter<PersonId> personIdFilter = person.getIds().createFilter(" WHERE this.id.idType = :ssnIdType ",
					getClass().getName());
			personIdFilter.bindId("ssnIdType", new IdType_Id(recipientIdentifierType));

			if(personIdFilter.list().isEmpty()){
				hadError=Bool.TRUE;
				errorMsg = CustomMessageRepositorySpireOne.cmCcb002SSIPerIdNumMissing(recipientIdentifierType, person.getId().getIdValue()).getMessageText();
				return null;
			}

			//Start Change - Ravi - 03302021 Adding Decryption logic
			PersonId personId = personIdFilter.firstRow();

			String encryptedSSN = personId.getEncryptedIdNumber();       
			if(!isBlankOrNull(encryptedSSN)){ 
				String decryptedSSN = "";

				try {
					FieldEncryptionDecryptionData decryptData = FieldEncryptionDecryptionData.Factory.newInstance();
					decryptData.setTableName("CI_PER_ID");
					decryptData.setFieldName("PER_ID_NBR");
					decryptData.setCipherText(encryptedSSN.trim());
					decryptData.setFilterField("ID_TYPE_CD");
					decryptData.setFilterValue(recipientIdentifierType.trim());

					FieldEncryptionDecryption decrypt = FieldEncryptionDecryption.Factory.newInstance(); 
					DecryptedValue decryptedValue = decrypt.decrypt(decryptData); 

					decryptedSSN = decryptedValue.getBuffer().toString().trim();
					decryptedValue.clear();
					return decryptedSSN;

				} catch (Exception e) {
					addError(CustomMessageRepositorySpireOne.CCB009_2_unableToDecrypt(person.getId().getTrimmedValue()));
				}
				//End Change - Ravi - 03302021 Adding Decryption logic
			}

			return personIdFilter.firstRow().getPersonIdNumber();
		}

		/**
		 * Method to format the date in MMDDYYYY format.                       
		 * @param Date
		 * @return String
		 */
		private String formatDate(Date Dt){
			String str = "";
			str+= StringUtilities.leftPadWithZeros(""+Dt.getMonth(), 2);
			str+= StringUtilities.leftPadWithZeros(""+Dt.getDay(), 2);
			str+= Dt.getYear();
			return str;
		}

		/**
		 * Method to write record into a file.
		 * @param outputFileWriter a BufferedWriter object.
		 * @param recordString a string.
		 */
		private void writeIntoFile(int maxSize, String recordString) {

			try {
				outputFileWriter.flush();
				outputFileWriter.write(recordString);
				//Do not add new line if all the records are already processed
				if(numberOfRecordsProcessed.intValue() < maxSize-1){
					outputFileWriter.write("\r\n");
				}

			} catch (IOException iOException) {
				// Error in file : %1. (Writing into file)
				hadError=Bool.TRUE;
				addError(CustomMessageRepository.ni0026_6ErrorInFile(iOException.getMessage()));
			}
		}

		/**
		 * Method to retrieve all the open SSI.
		 * @return List of query result row
		 */
		private List<SQLResultRow> retrieveOpenSSIPerson(){
			String cisDivisionStr = BLANK;

			StringBuffer getOpenSSIPersonQry = new StringBuffer();
			getOpenSSIPersonQry.append(" SELECT ACTPER.PER_ID, ACTPER.ACCT_ID, ");                                     
			getOpenSSIPersonQry.append("        NVL((SELECT PREM_ID FROM CI_PREM PREM,F1_SVC_TASK_REL_OBJ OBJ1 ");
			getOpenSSIPersonQry.append("          WHERE PREM.PREM_ID=OBJ1.PK_VALUE1 ");
			getOpenSSIPersonQry.append("          AND OBJ1.MAINT_OBJ_CD = :premiseMO ");
			getOpenSSIPersonQry.append("          AND OBJ1.F1_SVC_TASK_ID= OBJ.F1_SVC_TASK_ID), ' ') AS PREM_ID ");
			getOpenSSIPersonQry.append(" FROM F1_SVC_TASK SVC, F1_SVC_TASK_REL_OBJ OBJ, CI_ACCT ACT, CI_ACCT_PER ACTPER, F1_BUS_OBJ_STATUS BOS ");
			getOpenSSIPersonQry.append(" WHERE SVC.F1_STASK_TYPE_CD = :reqType ");
			getOpenSSIPersonQry.append(" AND SVC.BUS_OBJ_CD = BOS.BUS_OBJ_CD ");
			getOpenSSIPersonQry.append(" AND SVC.BO_STATUS_CD = BOS.BO_STATUS_CD ");
			getOpenSSIPersonQry.append(" AND BOS.BO_STATUS_COND_FLG <> :boFinalFlag ");
			getOpenSSIPersonQry.append(" AND SVC.F1_SVC_TASK_ID = OBJ.F1_SVC_TASK_ID ");
			getOpenSSIPersonQry.append(" AND OBJ.MAINT_OBJ_CD = :accountMO ");
			getOpenSSIPersonQry.append(" AND OBJ.PK_VALUE1 = ACT.ACCT_ID ");
			getOpenSSIPersonQry.append(" AND ACT.CIS_DIVISION IN ( ");
			for(int i=0; i<cisDivisionCount; i++){
				cisDivisionStr = " :cisDivision"+i;
				getOpenSSIPersonQry.append(cisDivisionStr);
				if (i!=(cisDivisionCount-1)){
					getOpenSSIPersonQry.append(",");
				}
			}		 
			getOpenSSIPersonQry.append(" ) AND ACT.ACCT_ID= ACTPER.ACCT_ID ");
			getOpenSSIPersonQry.append(" AND ACTPER.ACCT_REL_TYPE_CD='MAIN' ");
			getOpenSSIPersonQry.append(" AND ACTPER.MAIN_CUST_SW= :isMainCustomer ");

			PreparedStatement openSSIPersonPrepStmt = createPreparedStatement(getOpenSSIPersonQry.toString(), "retrieveOpenSSIPersonQry");

			openSSIPersonPrepStmt.bindEntity("reqType", parmSvcTaskType);
			openSSIPersonPrepStmt.bindLookup("boFinalFlag", BusinessObjectStatusConditionLookup.constants.FINAL);
			openSSIPersonPrepStmt.bindId("accountMO", ACCOUNT);
			openSSIPersonPrepStmt.bindId("premiseMO", PREMISE);
			for(int i=0; i<parmCisDivisionIdList.size(); i++){
				cisDivisionStr = "cisDivision"+i;
				openSSIPersonPrepStmt.bindId(cisDivisionStr, parmCisDivisionIdList.get(i));
			}
			openSSIPersonPrepStmt.bindBoolean("isMainCustomer", Bool.TRUE);
			openSSIPersonPrepStmt.setAutoclose(false);


			List<SQLResultRow> resultList = openSSIPersonPrepStmt.list();
			openSSIPersonPrepStmt.close();

			return resultList;
		}


		/**
		 * Perform final processing before ending the thread.
		 * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted
		 * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
		 * @see com.splwg.base.api.batch.ThreadWorker#finalizeThreadWork()
		 */
		public void finalizeThreadWork()
				throws ThreadAbortedException, RunAbortedException {

			try{
				if(notNull(outputFileWriter)){
					outputFileWriter.close();
				}
				if(numberOfRecordsProcessed.intValue() == 0){
					extractFile.delete();
				}
				if(hadError.isTrue()){
					extractFile.delete();
					addError(CustomMessageRepository.ni0026_6ErrorInFile(errorMsg));
				}
			}catch(IOException iOException){
				addError(CustomMessageRepository.ni0026_6ErrorInFile(iOException.getMessage()));
			}
		}

	}

}
