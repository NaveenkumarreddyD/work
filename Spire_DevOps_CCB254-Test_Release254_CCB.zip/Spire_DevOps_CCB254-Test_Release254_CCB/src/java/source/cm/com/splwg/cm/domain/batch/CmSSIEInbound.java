/*********************************************************************************************
 * Program Name: CmSSIEInbound
 * Program Title: CmSSIEInbound
 * Author: Diksha Sharma
 * Creation Date: 2019-07-11
 * Purpose: This batch process will read the file and update the customer's data accordingly.
 * 
 **********************************************************************************************/
/*----------------------------------------------------------------------------------------
 *-------------------------- Modification HISTORY: ---------------------------------------
 * ---------------------------------------------------------------------------------------
 * Modification ID:   CCTicket:	  Author:          Date:       Description:
.* --------------------------------------------------------------------------------------
 * CCB002  	       	  46096   	 Diksha Sharma     2019-07-11   TMG02493 - Initial Version 
 * CCB002			  46096	 	 Ravi			   2020-06-17	File Layout Record total size 
 *																updated to 194  
 * CCB002			  46096		 Ravi			   2021-03-30	File Layout Record Total Size
 *																updated to be greater than or 
 *																equal to 184 and updating the 
 *																person id with the encryption logic 
 *CCB002			  46096      Ravi    		   2021-04-10   Update the First, Middle and Last
 *																Names in the service task with 
 *																the data received in the inbound file. 
 *CCB002			  46096      Ravi    		   2021-04-20   Updated the First, Middle and Last 
 *																Names for Active Service Tasks             
 *                                                      
 *****************************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.encryption.AutomaticApplicationCryptography.EncryptedData;
import com.splwg.base.api.lookup.BusinessObjectStatusConditionLookup;
import com.splwg.base.api.lookup.LogEntryTypeLookup;
import com.splwg.base.api.maintenanceObject.MaintenanceObjectLogHelper;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObject_Id;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTaskLog;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.ccb.domain.admin.idType.entity.IdType;
import com.splwg.ccb.domain.admin.idType.entity.IdType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonId;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonId_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonId_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.security.common.FieldEncryptionDecryption;
import com.splwg.ccb.domain.security.data.FieldEncryptionDecryptionData;
import com.splwg.cm.api.lookup.CmInformationFlagLookup;
import com.splwg.cm.api.lookup.CmSsiApplicationStatusLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.StringUtilities;

/**
 * @author TMG02493
 *
@BatchJob (multiThreaded = false, rerunnable = false,modules =  {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE-PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE-NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = SSI_REQUEST_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = MAX-ERRORS, type = integer)})
 */
public class CmSSIEInbound extends CmSSIEInbound_Gen {
	private static BigInteger maxErrors = BigInteger.ZERO;
	public void validateSoftParameters(boolean isNewRun){
		String	strFilePath = getParameters().getFILE_PATH();

		// Validate if the file path is valid
		File folder = new File(strFilePath);
		if(!(folder.exists() && folder.isDirectory())) {
			addError(CustomMessageRepository.SA269362_parameterIsInvalid("FILE-PATH",strFilePath));
		}
		maxErrors = getParameters().getMAX_ERRORS();
		if(notNull(maxErrors))
		{
			if(maxErrors.intValue()<0)
			{
				addError(CustomMessageRepositoryMDC.NI0028_3_maxErrorInv());
			}
		}	
	}


	//prepares the units to get executed
	public JobWork getJobWork() {

		List<ThreadWorkUnit> threadWorkUnitList = new ArrayList<ThreadWorkUnit>();
		threadWorkUnitList.add(new ThreadWorkUnit());
		return createJobWorkForThreadWorkUnitList(threadWorkUnitList);
	}


	public Class<CmSSIEInboundWorker> getThreadWorkerClass() {
		return CmSSIEInboundWorker.class;
	}

	public static class CmSSIEInboundWorker extends CmSSIEInboundWorker_Gen {

		//Soft Parameters
		private String parmFilePath;
		private String parmFileName;
		private ServiceTaskType parmSSIRequestType;

		//Working Variables

		private BufferedReader bufferedReader = null;  
		private boolean fileFound = false;
		private Person person = null;
		private IdType recipientIdentifierType = null;
		private ToDoType toDoType= null;
		private Account account = null;	
		private String applicationStatus= null;
		private String informationFlag = null;
		private String newSSN = null;
		private String eligibleFlag = null;

		// Constants
		private static final MaintenanceObject_Id ACCT_MO = new MaintenanceObject_Id("ACCOUNT");
		private BigInteger count= BigInteger.ZERO;
		private static final int ACCOUNT_ID_INDEX = 11;
		private static final int ACCOUNT_ID_LENGTH = 13;
		private static final int ELIGIBILITY_FLAG_INDEX = 120;
		private static final int ELIGIBILITY_FLAG_LENGTH = 1;
		private static final int NEW_SSN_INDEX = 156;
		private static final int NEW_SSN_LENGTH = 9;
		private static final int APP_STATUS_INDEX = 9;
		private static final int APP_STATUS_LENGTH = 1;
		private static final int INFO_FLG_INDEX = 10;
		private static final int INFO_FLG_LENGTH = 1;

		/*
		 * Start - Change - Ravi20210410 - Updating First , Middle and Last Names in the SSI Service Task
		 */
		//working variables
		private String firstName =  null;
		private String lastName = null;
		private String middleName = null;

		//constants
		private static final int FIRST_NAME_INDEX = 40;
		private static final int FIRST_NAME_LENGTH = 10;
		private static final int LAST_NAME_INDEX = 24;
		private static final int LAST_NAME_LENGTH = 16;
		private static final int MIDDLE_NAME_INDEX = 50;
		private static final int MIDDLE_NAME_LENGTH = 1;

		/*
		 * End - Change - Ravi20210410 - Updating First , Middle and Last Names in the SSI Service Task
		 */

		/**
		 * Record length is updated in SSI system to 184, so updating the same in the inbound batch to be >=184
		 */
		//private static final int record_length=194;
		private static final int record_length=184;
		private static final String RECIPIENT_NOT_FOUND= "Recipient Identifier Type";
		private static final String TODO_TYPE_NOT_FOUND= "To Do Type";
		private static final String APP_OR_INF_NOT_FOUND= "Application status or information Flag";
		private static final String NEW_SSN_NUM= "New SSN Number";
		private static final String ACCOUNT_ID= "Account Id";
		private static final String INFORMATION_FLAG_LOOKUP= "Information Flag";
		private static final String APPLICATON_STATUS_LOOKUP= "Application Status";



		public ThreadExecutionStrategy createExecutionStrategy() {

			return new SingleTransactionStrategy(this);
		}

		public void initializeThreadWork(boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {

			//Soft Parameters
			parmFileName = getParameters().getFILE_NAME();
			parmFilePath = getParameters().getFILE_PATH();
			parmSSIRequestType= getParameters().getSSI_REQUEST_TYPE();
			File file = new File(parmFilePath, parmFileName);            			
			try {
				bufferedReader = new BufferedReader(new FileReader(file));
				fileFound =true;
			} catch (FileNotFoundException fe) {
				fileFound =false;	        	
				//terminate process without error
			}

		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			if(!fileFound)
			{
				return true;
			}

			//retrieve request type BO details

			BusinessObjectInstance ssiRequestTypeBOInst =BusinessObjectInstance.create(parmSSIRequestType.getBusinessObject());
			ssiRequestTypeBOInst.setXMLString("serviceTaskType", parmSSIRequestType.getId().getIdValue());			
			ssiRequestTypeBOInst = BusinessObjectDispatcher.read(ssiRequestTypeBOInst);

			//Retrieve Recipient Identifier Type and to do type from schema

			try{
				COTSInstanceNode ssiIntegrationDetails = ssiRequestTypeBOInst.getGroup("ssiIntegrationDetails");				
				recipientIdentifierType = new IdType_Id(ssiIntegrationDetails.getString("recipientIdentifierType")).getEntity();
				toDoType= new ToDoType_Id(ssiIntegrationDetails.getString("todoType")).getEntity();

			}
			catch(Exception e)
			{
				addError(CustomMessageRepositorySpireOne.cmCcb002SSIInvalidSsiRequestTypeBo());
				return false;
			}

			if(isNull(recipientIdentifierType)){

				addError(CustomMessageRepositorySpireOne.cmCcb002SSIMissingParam(RECIPIENT_NOT_FOUND)); 
				return false;
			}
			if(isNull(toDoType)){

				addError(CustomMessageRepositorySpireOne.cmCcb002SSIMissingParam(TODO_TYPE_NOT_FOUND)); 
				return false;
			}


			try {
				while(bufferedReader.ready()) {

					count= count.add(BigInteger.ONE);
					String record = bufferedReader.readLine();

					if(!isBlankOrNull(record) && record.trim().length() == 0){
						continue;
					}

					if(!isBlankOrNull(record) && record.length()<record_length)
					{		        			
						logError(CustomMessageRepositorySpireOne.cmCcb002SSI_InvalidLengthForDetailRecord(count.toString()));
						continue;
					}
					account=null;
					informationFlag=null;
					applicationStatus=null;
					newSSN=null;
					person=null;
					String accountId=null;

					accountId=getFieldValue(record,ACCOUNT_ID_INDEX,ACCOUNT_ID_LENGTH).trim();


					if(isBlankOrNull(accountId))
					{  logError(CustomMessageRepositorySpireOne.cmCcb002SSIMissingValueForRecord(count.toString(),ACCOUNT_ID));
					continue;		        			
					}
					account = new Account_Id(accountId).getEntity();

					if(isNull(account))
					{ logError(CustomMessageRepositorySpireOne.cmCcb002SSIAccountNotFound(count.toString(),accountId));
					continue;	        			
					}

					//check for open ssi request

					SQLResultRow activeSSIRow = checkIfHasOpenSSI(account);
					if(isNull(activeSSIRow))
					{
						//error- no active ssi request found for account 
						logError(CustomMessageRepositorySpireOne.cmCcb002SSInoActiveRequest(count.toString(),account.getId().getIdValue()));
						continue;		        			
					}
					ServiceTask_Id ssiRequestId = (ServiceTask_Id)activeSSIRow.getId("F1_SVC_TASK_ID", ServiceTask.class);
					String ssiRequestStatus = activeSSIRow.getString("BO_STATUS_CD");
					BusinessObject ssiRequestBO = ((BusinessObject_Id)activeSSIRow.getId("BUS_OBJ_CD",BusinessObject.class)).getEntity();
					ServiceTask ssiRequest=	ssiRequestId.getEntity();


					//read application status
					applicationStatus= getFieldValue(record,APP_STATUS_INDEX,APP_STATUS_LENGTH).trim();

					//read information flag
					informationFlag = getFieldValue(record, INFO_FLG_INDEX, INFO_FLG_LENGTH).trim();

					//check if any one of application status or information flag is present
					if(isBlankOrNull(applicationStatus) && isBlankOrNull(informationFlag))
					{
						// error -- missing parameter
						logError(CustomMessageRepositorySpireOne.cmCcb002SSIMissingValueForRecord(count.toString(),APP_OR_INF_NOT_FOUND));
						continue;
					}

					/*
					 * Start - Change - Ravi20210410 - Updating First , Middle and Last Names in the SSI Service Task
					 */
					lastName = getFieldValue(record, LAST_NAME_INDEX, LAST_NAME_LENGTH);
					firstName = getFieldValue(record, FIRST_NAME_INDEX, FIRST_NAME_LENGTH);
					middleName = getFieldValue(record, MIDDLE_NAME_INDEX, MIDDLE_NAME_LENGTH);

					/*
					 * End - Change - Ravi20210410 - Updating First , Middle and Last Names in the SSI Service Task
					 */

					//Fetch ssi request details: main person,bo status , application status and information flag


					BusinessObjectInstance ssiRequestBoInstance;
					ssiRequestBoInstance = BusinessObjectInstance.create(ssiRequestBO);							 
					ssiRequestBoInstance.setXMLString("serviceTaskId", ssiRequestId.getIdValue());
					ssiRequestBoInstance = BusinessObjectDispatcher.read(ssiRequestBoInstance);

					person= new Person_Id(ssiRequestBoInstance.getString("personId")).getEntity();

					COTSInstanceNode ssiRequestDetails= ssiRequestBoInstance.getGroup("ssiRequestDetails");

					COTSInstanceNode ssiRecipientName= ssiRequestDetails.getGroup("ssiRecipientName");
					ssiRecipientName.set("firstName",StringUtilities.padRight(firstName, FIRST_NAME_LENGTH));
					ssiRecipientName.set("lastName",StringUtilities.padRight(lastName, LAST_NAME_LENGTH));
					ssiRecipientName.set("middleName",StringUtilities.padRight(middleName, MIDDLE_NAME_LENGTH));


					CmInformationFlagLookup informationFlagLookup = LookupHelper.getLookupInstance(CmInformationFlagLookup.class,informationFlag);
					if(!informationFlagLookup.isValidLookupValue() && !isBlankOrNull(informationFlag))
					{
						logError(CustomMessageRepositorySpireOne.cmCcb002SSIInvalidLookupValue(count.toString(),INFORMATION_FLAG_LOOKUP));
						continue;
					}
					//If Information Flag is Deceased

					if(informationFlagLookup.isCmDeceased())
					{
						//delete identifier

						PersonId_Id personIdNbr= new PersonId_Id(person, recipientIdentifierType);
						person.getIds().remove(personIdNbr);		        			 
						//update ssi request,Move BO to close state

						ssiRequestDetails.set("informationFlag",informationFlagLookup);

						ssiRequestBoInstance.set("boStatus", "CLOSED");		        						
						ssiRequestBoInstance = BusinessObjectDispatcher.update(ssiRequestBoInstance);

						// Create a Service Task Log
						MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog> maintenanceObjectLogHelper = new MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog>(
								ssiRequestBO.getMaintenanceObject(), 
								ssiRequest, ssiRequestBO.getId());
						maintenanceObjectLogHelper.addLogEntry(LogEntryTypeLookup.constants.SYSTEM, 
								CustomMessageRepositorySpireOne.cmCcb002SSIRecipientStatus("",informationFlagLookup.getLookupValue().fetchLanguageDescription()), null);	
						continue;

					}

					//If Information Flag is Unknown 
					if(informationFlagLookup.isCmUnknown())
					{		        	
						//delete the identifier from main person
						//Start Change - Ravi - 033021 - Close SSI instead of creating ToDo
						PersonId_Id personIdNbr= new PersonId_Id(person, recipientIdentifierType);
						person.getIds().remove(personIdNbr);

						//update ssi request,Move BO to close state
						ssiRequestDetails.set("informationFlag",informationFlagLookup);		        						
						ssiRequestBoInstance.set("boStatus", "CLOSED");

						ssiRequestBoInstance = BusinessObjectDispatcher.update(ssiRequestBoInstance);
						//End Change - Ravi - 033021 - Close SSI instead of creating ToDo
						// Create a Service Task Log
						MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog> maintenanceObjectLogHelper = new MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog>(
								ssiRequestBO.getMaintenanceObject(), 
								ssiRequest, ssiRequestBO.getId());
						maintenanceObjectLogHelper.addLogEntry(LogEntryTypeLookup.constants.SYSTEM, 
								CustomMessageRepositorySpireOne.cmCcb002SSIRecipientStatus("",informationFlagLookup.getLookupValue().fetchLanguageDescription()),null);	

						//Start Change - Ravi - 033021 - Close SSI instead of creating ToDo
						/*//check if open toDo already exist
						if(!fetchExistingToDoForSameSsiRequest(ssiRequestId))
						{		 			        	
							//create new toDo
							createToDo(ssiRequestId);
						}	*/	 
						//End Change - Ravi - 033021 - Close SSI instead of creating ToDo
						continue;
					}
					//If Information Flag is New SSN 
					if(informationFlagLookup.isCmNewSsn())
					{	
						//read new SSN number
						newSSN= getFieldValue(record, NEW_SSN_INDEX, NEW_SSN_LENGTH);
						//check if new ssn is null

						if(isBlankOrNull(newSSN))
						{
							logError(CustomMessageRepositorySpireOne.cmCcb002SSIMissingValueForRecord(count.toString(),NEW_SSN_NUM));
							continue;
						}

						newSSN = StringUtilities.padRight(newSSN, NEW_SSN_LENGTH);

						newSSN=newSSN.substring(0, 3).concat("-").concat(newSSN.substring(3, 5)).concat("-").concat(newSSN.substring(5));

						//update the SSN number
						PersonId_Id recipientNbrId= new PersonId_Id(person,recipientIdentifierType);
						PersonId recipientNbr = recipientNbrId.getEntity();

						PersonId_DTO personIdDTO = null;
						if(notNull(recipientNbr)){
							personIdDTO =recipientNbr.getDTO();


							FieldEncryptionDecryptionData decryptData = FieldEncryptionDecryptionData.Factory.newInstance();
							decryptData.setTableName("CI_PER_ID");
							decryptData.setFieldName("PER_ID_NBR");
							decryptData.setPlainText(newSSN);
							decryptData.setFilterField("ID_TYPE_CD");
							decryptData.setFilterValue(recipientIdentifierType.getId().getTrimmedValue());

							FieldEncryptionDecryption encrypt = FieldEncryptionDecryption.Factory.newInstance(); 
							EncryptedData encryptedData= encrypt.encrypt(decryptData);
							if(notNull(encryptedData)){
								String encryptedValue = encryptedData.encryptedValue;
								String hmacValue = encryptedData.hmacValue;
								String maskedValue = encryptedData.maskedValue;
								personIdDTO.setEncryptedIdNumber(encryptedValue);
								personIdDTO.setHashIdNumber(hmacValue);
								personIdDTO.setPersonIdNumber(maskedValue);
							}else{
								personIdDTO.setEncryptedIdNumber(null);
								personIdDTO.setHashIdNumber(null);
								personIdDTO.setPersonIdNumber(newSSN);
							}


							recipientNbr.setDTO(personIdDTO);		

							ssiRequestBoInstance = BusinessObjectDispatcher.update(ssiRequestBoInstance);


							// Create a Service Task Log
							MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog> maintenanceObjectLogHelper = new MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog>(
									ssiRequestBO.getMaintenanceObject(), 
									ssiRequest, ssiRequestBO.getId());
							maintenanceObjectLogHelper.addLogEntry(LogEntryTypeLookup.constants.SYSTEM, 
									CustomMessageRepositorySpireOne.cmCcb002SSIRecipientStatus("New SSN received for ",""),null);			 			       		 			       	 			        

						}
						continue;
					}


					CmSsiApplicationStatusLookup applicationStatusLookup = LookupHelper.getLookupInstance(CmSsiApplicationStatusLookup.class,applicationStatus);
					if(!applicationStatusLookup.isBlankLookupValue() && !applicationStatusLookup.isValidLookupValue())
					{
						logError(CustomMessageRepositorySpireOne.cmCcb002SSIInvalidLookupValue(count.toString(),APPLICATON_STATUS_LOOKUP));
					}
					//if application status is not qualified

					if(applicationStatusLookup.isCmNotqualified())
						//delete the identifier from main person
					{

						PersonId_Id personIdNbr= new PersonId_Id(person, recipientIdentifierType);
						person.getIds().remove(personIdNbr);

						//update ssi request,Move BO to close state

						ssiRequestDetails.set("applicationStatus",applicationStatusLookup);			       			 
						ssiRequestBoInstance.set("boStatus", "CLOSED");
						ssiRequestBoInstance = BusinessObjectDispatcher.update(ssiRequestBoInstance);

						// Create a Service Task Log
						MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog> maintenanceObjectLogHelper = new MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog>(
								ssiRequestBO.getMaintenanceObject(), 
								ssiRequest, ssiRequestBO.getId());
						maintenanceObjectLogHelper.addLogEntry(LogEntryTypeLookup.constants.SYSTEM, 
								CustomMessageRepositorySpireOne.cmCcb002SSIRecipientStatus("",applicationStatusLookup.getLookupValue().fetchLanguageDescription()),null);
						continue;
					}

					//if application status is qualified
					if(applicationStatusLookup.isCmQualified()){

						//check for ssi requeest status
						if(ssiRequestStatus.equalsIgnoreCase("AWAIT-VERIFY"))
						{
							eligibleFlag= getFieldValue(record, ELIGIBILITY_FLAG_INDEX, ELIGIBILITY_FLAG_LENGTH);

							if(eligibleFlag.equalsIgnoreCase("X"))
							{
								//update the application status, move BO to active 
								ssiRequestDetails.set("applicationStatus",applicationStatusLookup);					       			
								ssiRequestBoInstance.set("boStatus", "ACTIVE");
								ssiRequestBoInstance = BusinessObjectDispatcher.update(ssiRequestBoInstance);

								// Create a Service Task Log
								MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog> maintenanceObjectLogHelper = new MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog>(
										ssiRequestBO.getMaintenanceObject(), 
										ssiRequest, ssiRequestBO.getId());
								maintenanceObjectLogHelper.addLogEntry(LogEntryTypeLookup.constants.SYSTEM, 
										CustomMessageRepositorySpireOne.cmCcb002SSIRecipientStatus("",applicationStatusLookup.getLookupValue().fetchLanguageDescription()),null);
							}
							//Start Change - Ravi - 042021 - Updating the name of the Active SSI customers
						}else{
							ssiRequestBoInstance = BusinessObjectDispatcher.update(ssiRequestBoInstance);
						}
						//End Change - Ravi - 042021 - Updating the name of the Active SSI customers
						continue;

					}
				}

				return true;
			} catch (IOException ie) {

				logError(CustomMessageRepositorySpireOne.cmCcb002SSIUnableToAccessFile(parmFileName));
				return false;
			}
		}


		/**
		 * This method retrieves active SSI Request.
		 * 
		 */
		private SQLResultRow checkIfHasOpenSSI( Account account) {


			SQLResultRow ssiRequestRow = null;


			StringBuilder getOpenSSIRequest = new StringBuilder();
			getOpenSSIRequest.append(" SELECT SVC.F1_SVC_TASK_ID, "); 			
			getOpenSSIRequest.append(" SVC.BO_STATUS_CD, SVC.BUS_OBJ_CD ");
			getOpenSSIRequest.append(" FROM F1_SVC_TASK SVC, ");
			getOpenSSIRequest.append(" F1_SVC_TASK_REL_OBJ OBJ, ");
			getOpenSSIRequest.append(" F1_BUS_OBJ_STATUS BOS ");
			getOpenSSIRequest.append(" WHERE SVC.F1_SVC_TASK_ID = OBJ.F1_SVC_TASK_ID ");
			getOpenSSIRequest.append(" AND SVC.F1_STASK_TYPE_CD = :serviceTaskType ");
			getOpenSSIRequest.append(" AND OBJ.MAINT_OBJ_CD = :maintenanceObject ");
			getOpenSSIRequest.append(" AND OBJ.PK_VALUE1 = :account ");
			getOpenSSIRequest.append(" AND SVC.BUS_OBJ_CD = BOS.BUS_OBJ_CD ");
			getOpenSSIRequest.append(" AND SVC.BO_STATUS_CD = BOS.BO_STATUS_CD ");
			getOpenSSIRequest.append(" AND BOS.BO_STATUS_COND_FLG <> :finalBoStatusCondition ");

			PreparedStatement getOpenSSIRequestStmt = createPreparedStatement(getOpenSSIRequest.toString(),"check for open SSI Request");
			getOpenSSIRequestStmt.bindEntity("serviceTaskType", parmSSIRequestType);
			getOpenSSIRequestStmt.bindId("maintenanceObject", ACCT_MO);
			getOpenSSIRequestStmt.bindEntity("account", account);
			getOpenSSIRequestStmt.bindLookup("finalBoStatusCondition", BusinessObjectStatusConditionLookup.constants.FINAL);

			getOpenSSIRequestStmt.setAutoclose(false);
			ssiRequestRow= getOpenSSIRequestStmt.firstRow();

			getOpenSSIRequestStmt.close();

			return ssiRequestRow;
		}		


		private String getFieldValue(String record, int startPos, int length) {
			String value = "";
			if(record.length() >= startPos+length){
				value = record.substring(startPos, startPos+length).trim();
			}
			return value;
		}

		//Start Change - Ravi - 033021 - Close SSI instead of creating ToDo
		/*		private boolean fetchExistingToDoForSameSsiRequest(ServiceTask_Id ssiRequestId){
			StringBuilder mainHQL = new StringBuilder();
			mainHQL.append(" from ToDoEntry td, ToDoDrillKeyValue val ");
			mainHQL.append(" where td.id = val.id.toDo  ");
			mainHQL.append(" and td.toDoType.id =:toDoType ");
			mainHQL.append(" and val.keyValue =:keyValue ");

			Query<ToDoEntry> mainQry=createQuery(mainHQL.toString(),getClass().getSimpleName());
			mainQry.bindId("toDoType", toDoType.getId());
			mainQry.bindStringProperty("keyValue", ToDoDrillKeyValue.properties.keyValue, ssiRequestId.getIdValue());
			if(mainQry.list().size()>0){
				return true;
			}else
				return false;
		}

		private ToDoEntry createToDo(ServiceTask_Id ssiRequestId){


			ToDoCreator creator = ToDoCreator.Factory.newInstance();
			ToDoEntry_DTO toDoEntry_DTO=(ToDoEntry_DTO) createDTO(ToDoEntry.class);
			toDoEntry_DTO.setToDoTypeId(toDoType.getId());
			toDoEntry_DTO.setToDoRoleId(toDoType.getDefaultRole().getId().getToDoRoleId());
			toDoEntry_DTO.setCreationDateTime(getProcessDateTime());
			toDoEntry_DTO.setToDoPriority(toDoType.getToDoPriority());
			toDoEntry_DTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
			toDoEntry_DTO.setBatchControlId(getBatchControlId());
			toDoEntry_DTO.setBatchNumber(getBatchNumber());

			creator.setToDoDTO(toDoEntry_DTO);
			// Add Drill Key: Service task ID
			if (!toDoType.getDrillKeyTypes().isEmpty()) {
				ToDoDrillKeyType drillKeyTpe = toDoType.getDrillKeyTypes()
						.iterator().next();
				creator.addDrillKeyValue(drillKeyTpe, ssiRequestId.getIdValue());
			}
			creator.addMessageParameter(ssiRequestId.getIdValue());


			// Add Sort Key: person name
			if (!toDoType.getSortKeyTypes().isEmpty()) {
				ToDoSortKeyType sortKeyTpe = toDoType.getSortKeyTypes().iterator().next();
				creator.addSortKeyValue(sortKeyTpe, person.getPersonPrimaryName());
			}



			return creator.create();
		}*/
		//End Change - Ravi - 033021 - Close SSI instead of creating ToDo

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException,
		RunAbortedException {

			try {
				bufferedReader.close();
			} catch (IOException e) {
				//Error in file : %1.(While Closing)
				throw new RunAbortedException(CustomMessageRepository.ni0026_6ErrorInFile(e.getMessage()));
			}
		}
	}


}
