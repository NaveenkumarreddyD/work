/****************************************************************************************
 * Program Name: CmSSIRequestCheck_AlgComp_Impl
 * Program Title: CmSSIRequestCheck_AlgComp_Impl
 * Author: Jain Akshita
 * Creation Date: 2019-07-01
 * Purpose: This SA activation algorithm checks if the SA is linked to an
 * account that has an open SSI Request that references the SSI Request 
 * Type specified. If found, it updates the SSI Request with the new SA 
 * details and adds the contract rider on the new SA.
 * 
 ****************************************************************************************/
/*----------------------------------------------------------------------------------------
 *-------------------------- Modification HISTORY: ---------------------------------------
 * ---------------------------------------------------------------------------------------
 * Modification ID:   CCTicket:	  Author:          Date:       Description:
.* --------------------------------------------------------------------------------------
 * CCB002  	       	  46096   	 Jain Akshita     2019-08-01   TMG02493 - Initial Version                 
 *                                                      
 *****************************************************************************************/
package com.splwg.cm.domain.admin.serviceAgreementType;


import java.math.BigInteger;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.BusinessObjectStatusConditionLookup;
import com.splwg.base.api.lookup.LogEntryTypeLookup;
import com.splwg.base.api.maintenanceObject.MaintenanceObjectLogHelper;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObject_Id;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTaskLog;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.api.lookup.ContractTermTypeLookup;
import com.splwg.ccb.domain.admin.billFactor.entity.BillFactor_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saActivation.SaTypeSaActivationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementContractTerm_DTO;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author TMG02493
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = serviceTaskType, name = ssiRequestType, required = true, type = entity)})
 */
public class CmSSIRequestCheck_AlgComp_Impl extends
CmSSIRequestCheck_AlgComp_Gen implements
SaTypeSaActivationAlgorithmSpot {


	//hard parameter
	private ServiceAgreement parmSA=null;		

	//soft parameter
	private ServiceTaskType parmSSIRequestType;

	//work variables
	private Account parmAccount=null;
	private Date parmSAStartDate = null;
	private Premise_Id parmPremiseId=null;
	private String customerChargeRiderBillFactor=null;
	private BigInteger seq=BigInteger.ONE;


	//constants
	private static final MaintenanceObject_Id ACCT_MO = new MaintenanceObject_Id("ACCOUNT");
	private static final MaintenanceObject_Id SA_MO = new MaintenanceObject_Id("SA");

	@Override
	public void invoke() {


		parmAccount=parmSA.getAccount();
		parmSAStartDate=parmSA.getStartDate();
		parmPremiseId= parmSA.fetchPremise().getId();					
		parmSSIRequestType= getSsiRequestType();

		BusinessObjectInstance ssiRequestTypeBoInstance;
		ssiRequestTypeBoInstance = BusinessObjectInstance.create(parmSSIRequestType.getBusinessObject());		

		ssiRequestTypeBoInstance.setXMLString("serviceTaskType", parmSSIRequestType.getId().getIdValue());
		ssiRequestTypeBoInstance = BusinessObjectDispatcher.read(ssiRequestTypeBoInstance);
		try{
			COTSInstanceNode ssiIntegartionDetails = ssiRequestTypeBoInstance.getGroup("ssiIntegrationDetails");


			customerChargeRiderBillFactor = ssiIntegartionDetails.getString("customerChargeRiderBillFactor");

		}
		catch(Exception e)
		{
			addError(CustomMessageRepositorySpireOne.cmCcb002SSIInvalidSsiRequestTypeBo());
		}

		//Check if account has open SSI request

		SQLResultRow activeSSIRow = checkIfHasOpenSSI();
		if(notNull(activeSSIRow))
		{		
			ServiceTask_Id ssiRequestId = (ServiceTask_Id)activeSSIRow.getId("F1_SVC_TASK_ID",ServiceTask.class);
			BusinessObject ssiRequestBO = ((BusinessObject_Id)activeSSIRow.getId("BUS_OBJ_CD",BusinessObject.class)).getEntity();
			//retrieve latest SA details

			SQLResultRow latestSA= retrieveLatestSA(ssiRequestId);

			if(notNull(latestSA)) {

				seq= seq.add(latestSA.getInteger("SEQ_NUM"));	

			}

			//Add Service agreement to SSI request and update premise Id
			BusinessObjectInstance ssiRequestBoInstance;
			ssiRequestBoInstance = BusinessObjectInstance.create(ssiRequestBO);							 
			ssiRequestBoInstance.setXMLString("serviceTaskId", ssiRequestId.getIdValue());
			ssiRequestBoInstance = BusinessObjectDispatcher.read(ssiRequestBoInstance);

			if(ssiRequestBoInstance.getString("boStatus").equalsIgnoreCase("ACTIVE"))
			{
				//add contract rider on SA with start date equal to the SA start date is the b sttaus is active. The end date will be left blank.
				ServiceAgreementContractTerm_DTO sactDto = new ServiceAgreementContractTerm_DTO();
				parmSA.getContractTerms().add(sactDto, new BillFactor_Id(customerChargeRiderBillFactor), ContractTermTypeLookup.constants.CONTRACT_RIDER
						, "", parmSAStartDate);    
			}

			COTSInstanceNode serviceAgreementList = ssiRequestBoInstance.getList("serviceAgreement").newChild();
			serviceAgreementList.set("saId", parmSA);
			serviceAgreementList.set("sequence",new BigDecimal(seq));					
			ssiRequestBoInstance.set("premiseId", parmPremiseId.getIdValue());					
			ssiRequestBoInstance = BusinessObjectDispatcher.update(ssiRequestBoInstance);

			// Create a Service Task Log
			MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog> maintenanceObjectLogHelper = new MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog>(
					ssiRequestBO.getMaintenanceObject(), 
					ssiRequestId.getEntity(), ssiRequestBO.getId());
			maintenanceObjectLogHelper.addLogEntry(
					LogEntryTypeLookup.constants.SYSTEM, 
					CustomMessageRepositorySpireOne.cmCcb002SSIRequestUpdated(), 
					null);	


		}
	}

	/**
	 * This method retrieves active SSI Request.
	 * 
	 */
	private SQLResultRow checkIfHasOpenSSI() {


		SQLResultRow ssiRequestRow = null;


		StringBuilder getOpenSSIRequest = new StringBuilder();
		getOpenSSIRequest.append(" SELECT SVC.F1_SVC_TASK_ID,SVC.BUS_OBJ_CD "); 
		getOpenSSIRequest.append(" FROM F1_SVC_TASK SVC, ");
		getOpenSSIRequest.append(" F1_SVC_TASK_REL_OBJ OBJ, ");
		getOpenSSIRequest.append(" F1_BUS_OBJ_STATUS BOS ");
		getOpenSSIRequest.append(" WHERE SVC.F1_SVC_TASK_ID = OBJ.F1_SVC_TASK_ID ");
		getOpenSSIRequest.append(" AND SVC.F1_STASK_TYPE_CD = :serviceTaskType ");
		getOpenSSIRequest.append(" AND OBJ.MAINT_OBJ_CD = :maintenanceObject ");
		getOpenSSIRequest.append(" AND OBJ.PK_VALUE1 = :account ");
		getOpenSSIRequest.append(" AND SVC.BUS_OBJ_CD = BOS.BUS_OBJ_CD ");
		getOpenSSIRequest.append(" AND SVC.BO_STATUS_CD = BOS.BO_STATUS_CD ");
		getOpenSSIRequest.append(" AND BOS.BO_STATUS_COND_FLG <> :finalBoStatusCondition ");

		PreparedStatement getOpenSSIRequestStmt = createPreparedStatement(getOpenSSIRequest.toString(),"check for open SSI Request");
		getOpenSSIRequestStmt.bindEntity("serviceTaskType", parmSSIRequestType);
		getOpenSSIRequestStmt.bindId("maintenanceObject", ACCT_MO);
		getOpenSSIRequestStmt.bindEntity("account", parmAccount);
		getOpenSSIRequestStmt.bindLookup("finalBoStatusCondition", BusinessObjectStatusConditionLookup.constants.FINAL);

		getOpenSSIRequestStmt.setAutoclose(false);
		ssiRequestRow= getOpenSSIRequestStmt.firstRow();

		getOpenSSIRequestStmt.close();

		return ssiRequestRow;
	}


	/**
	 * This method retrieves SA on ssi request with highest sequence.
	 * 
	 */
	private SQLResultRow retrieveLatestSA(ServiceTask_Id ssiRequestId) {


		SQLResultRow serviceAgreementDetails = null;

		StringBuilder retrieveLatestSA = new StringBuilder();
		retrieveLatestSA.append(" SELECT PK_VALUE1, "); 
		retrieveLatestSA.append(" SEQ_NUM "); 
		retrieveLatestSA.append(" FROM F1_SVC_TASK_REL_OBJ ");			
		retrieveLatestSA.append(" WHERE F1_SVC_TASK_ID= :ssiRequestId");
		retrieveLatestSA.append(" AND MAINT_OBJ_CD = :maintenanceObject ");				
		retrieveLatestSA.append(" ORDER BY SEQ_NUM DESC");

		PreparedStatement retrieveLatestSAStmt = createPreparedStatement(retrieveLatestSA.toString(),"retrieve Service agreements");
		retrieveLatestSAStmt.bindId("ssiRequestId", ssiRequestId);
		retrieveLatestSAStmt.bindId("maintenanceObject", SA_MO);

		retrieveLatestSAStmt.setAutoclose(false);

		serviceAgreementDetails= retrieveLatestSAStmt.firstRow();

		retrieveLatestSAStmt.close();

		return serviceAgreementDetails;
	}



	@Override
	public void setServiceAgreement(ServiceAgreement sa) {
		parmSA = sa;

	}

}
