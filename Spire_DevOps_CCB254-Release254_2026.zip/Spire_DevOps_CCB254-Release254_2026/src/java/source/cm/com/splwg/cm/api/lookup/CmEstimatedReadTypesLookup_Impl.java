/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Estimated Read Types Lookup
 *            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-10-07   JPunza  NM0104 Initial Version.
 *************************************************************************/

package com.splwg.cm.api.lookup;

/**
 * @author jpunzalan001
 *
 @LookupFieldname (value = XERT_OPT_TYP_FLG)
 */
public class CmEstimatedReadTypesLookup_Impl 
    extends CmEstimatedReadTypesLookup_Gen {

}
