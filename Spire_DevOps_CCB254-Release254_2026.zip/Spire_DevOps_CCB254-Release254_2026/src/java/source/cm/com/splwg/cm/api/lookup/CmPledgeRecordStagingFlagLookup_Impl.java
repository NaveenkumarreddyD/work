package com.splwg.cm.api.lookup;

/**
 * @author rsaran003
 *
@LookupFieldname (value = CM_PLDG_RCRD_ST_FLG)
 */
public class CmPledgeRecordStagingFlagLookup_Impl extends
		CmPledgeRecordStagingFlagLookup_Gen {

}
