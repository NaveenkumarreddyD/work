/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * CmCreateMonthlyMtrReadsOptOutCustBatch
 *
 * This new batch process will be developed to create manual meter read 
 * field activities for each opted out service point. These reads will be 
 * used for billing since the service points will not have smart meters installed.
 *  
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *
 * 2021-11-25   PLi         STIP036. Initial Version. 
 * 2022-03-02   Kiran Machavarapu check whether the SP already has a pending FA of that type 
 * 								  on that date. If so, do not create a new FA and end processing
 * 2022-07-18   Kiran       also check and see if there is a completed FA for that date 
 **************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;

import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.splwg.base.api.Query;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.YesNoOptionLookup;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityCreatedByLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointSourceStatusLookup;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.meterReadCycle.entity.MeterReadCycle;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.cm.domain.customMessages.CustomMessagesSpireOne;

/**
 * @author OTC-DEV
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = MTR_RTE_TYPE_CD, required = true, type = string)
 *            , @BatchJobSoftParameter (lookupName = yesNoOption, name = INCLUDE_DISCONNECTED, required = true, type = lookup)
 *            , @BatchJobSoftParameter (entityName = fieldActivityType, name = FA_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = FORCE_FA_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = FORCE_FA_CHAR_VAL, required = true, type = string)})
 */
public class CmCreateMonthlyMtrReadsOptOutCustBatch extends
		CmCreateMonthlyMtrReadsOptOutCustBatch_Gen {

	// Batch Parameters
	private String mtrRouteTypeStr = "";
	private YesNoOptionLookup includeDisconnectedFlg;
	private CharacteristicType forceFACharType;
	private String forceFACharVal;
	
	// Work Variables
	private List<String> mtrRouteTypeStrList = new ArrayList<String>();
	private List<MeterReadRouteType> mtrRouteTypeList = new ArrayList<MeterReadRouteType>();
	
	/**
	 * Validate Soft Parameters 
	 */
	public void validateSoftParameters(boolean isNewRun) {
		
		mtrRouteTypeStr = getParameters().getMTR_RTE_TYPE_CD();
		includeDisconnectedFlg = getParameters().getINCLUDE_DISCONNECTED();
		forceFACharType = getParameters().getFORCE_FA_CHAR_TYPE();
		forceFACharVal = getParameters().getFORCE_FA_CHAR_VAL();
		
		mtrRouteTypeStrList = Arrays.asList(mtrRouteTypeStr.split(","));
		// Validate each Meter Route Type
		for (String mtrRouteTypeStr : mtrRouteTypeStrList) {
			validateMeterRouteType(mtrRouteTypeStr);
		}
		
		// Validate Char Type for Entity
		validateCharacteristicEntity("Forece FA Char Type", forceFACharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY);
		
		// Validate Char Type Char Value Combination
		validateCharVal("Force FA Char Val", forceFACharType, forceFACharVal);
	}
	
	/**
	 * Validate Meter Route Type
	 * @param meterRouteTypeStr
	 */
	private void validateMeterRouteType(String meterRouteTypeStr) {
		
		MeterReadRouteType_Id mtrReadRouteTypeId = new MeterReadRouteType_Id(meterRouteTypeStr);
		if (isNull(mtrReadRouteTypeId.getEntity())) {
			addError(CustomMessageRepositorySpireOne.getParameterizedMessage(CustomMessagesSpireOne.STIP036_ALG_PARM_INVALID, "Service Read Types"
					,meterRouteTypeStr
					,"Meter Read Route Type"));
		}
		else {
			mtrRouteTypeList.add(mtrReadRouteTypeId.getEntity());
		}
	}
	
	/**
     *  Validate Characteristic Entity 
     *
     */     
    private void validateCharacteristicEntity(String parmName, CharacteristicType inputCharType, CharacteristicEntityLookup inputCharEntityLookup){
        CharacteristicEntity_Id characteristicEntityId = new CharacteristicEntity_Id(inputCharType,inputCharEntityLookup);
        CharacteristicEntity characteristicEntity = characteristicEntityId.getEntity();
        if(isNull(characteristicEntity)){
            addError(CustomMessageRepositorySpireOne.getParameterizedMessage(CustomMessagesSpireOne.STIP036_ALG_PARM_INVALID_CHAR_ENTITY, parmName, 
                    inputCharType.getId().getIdValue(), 
                    inputCharEntityLookup.getLookupValue().fetchLanguageDescription().trim()));
        }
    }
    
    /**
     * This method will validate a Characteristic Value.
     * @param charTypeStr charTypeStr
     * @param charValStr charValStr
     */
    private void validateCharVal(String parmName, CharacteristicType charType, String charValStr) {
    	
    	CharacteristicValue_Id charValId = new CharacteristicValue_Id(charType, charValStr);
    	if (isNull(charValId.getEntity())) {
    		addError(CustomMessageRepositorySpireOne.getParameterizedMessage(CustomMessagesSpireOne.STIP036_ALG_PARM_INVALID_CHAR_VAL, parmName, charValStr, charType.fetchLanguageDescription()));
    	}
    }

    /**
     * Job Work
     */
	public JobWork getJobWork() {
		
        StringBuilder sb = new StringBuilder();
        
        sb.append("FROM ServicePoint sp                                                    ");
        sb.append("WHERE sp.meterReadRoute IN ( SELECT mrr.id.meterReadRoute               ");
        sb.append("                             FROM MeterReadRoute mrr                    ");
        sb.append("                             WHERE mrr.meterReadRouteType IN (''        ");
	        for(int i=0;i<mtrRouteTypeList.size();i++) {
	        	sb.append(",");
	        	sb.append(":mtrRouteType" + i);
	        }
	        sb.append("))                                                                  ");
        if (includeDisconnectedFlg.isNo()) {
        	sb.append("AND sp.servicePointSourceStatus <> :disconnected         ");
        }
       
        Query<ServicePoint> query = createQuery(sb.toString(), getClass().getName());
        for(int i=0;i<mtrRouteTypeList.size();i++) {
        	query.bindEntity("mtrRouteType" + i, mtrRouteTypeList.get(i));
        }
        if (includeDisconnectedFlg.isNo()) {
        	query.bindLookup("disconnected", ServicePointSourceStatusLookup.constants.DISCONNECTED);
        }
        query.addResult("servicePointId", "sp");

        return createJobWorkForEntityQuery(query);
	}

	public Class<CmCreateMonthlyMtrReadsOptOutCustBatchWorker> getThreadWorkerClass() {
		return CmCreateMonthlyMtrReadsOptOutCustBatchWorker.class;
	}

	public static class CmCreateMonthlyMtrReadsOptOutCustBatchWorker extends
			CmCreateMonthlyMtrReadsOptOutCustBatchWorker_Gen {
		
		// Batch Parameters
		private FieldActivityType faType;
		private CharacteristicType forceFACharType;
		private String forceFACharVal;

		/**
		 * Initialize Thread Work
		 */
		public void initializeThreadWork(boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
			
			// Initialize Batch Parameters
			faType = getParameters().getFA_TYPE_CD();
			forceFACharType = getParameters().getFORCE_FA_CHAR_TYPE();
			forceFACharVal = getParameters().getFORCE_FA_CHAR_VAL();
			
		}

		/**
		 * Thread Execution Strategy
		 */
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		/**
		 * Main Processing
		 */
		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			ServicePoint sp = ((ServicePoint_Id) unit.getPrimaryId()).getEntity();
			 
			if (isNull(sp.getMeterReadCycleId())) {
				addError(CustomMessageRepositorySpireOne.getParameterizedMessage(CustomMessagesSpireOne.STIP036_CANNOT_DETERMINE_NEXT_SCHED_WORK_DATE));
			}
			
			MeterReadCycle mtrReadCycle = sp.getMeterReadCycleId().getEntity();
			Query<Date> getNextSchedWorkDate = getNextScheduledWorkDate(mtrReadCycle, getProcessDateTime().getDate());
			Date nextSchedWorkDate = getNextSchedWorkDate.firstRow();
			
			// Raise Error if no Next Scheduled Work Date is found.
			if (isNull(nextSchedWorkDate)) {
				addError(CustomMessageRepositorySpireOne.getParameterizedMessage(CustomMessagesSpireOne.STIP036_CANNOT_DETERMINE_NEXT_SCHED_WORK_DATE));
			}
			
			// Create Field Activity
			createFieldActivity(sp, nextSchedWorkDate);
			
            return true;
		}
		
		/**
		 * Finalize ThreadWork
		 */
		public void finalizeThreadWork() throws ThreadAbortedException,
				RunAbortedException {
		}
		
		/**
		 * This method will create a Field Activity
		 */
		private FieldActivity createFieldActivity(ServicePoint sp, Date schedDate){

			
			// 2022-03-02   Kiran Machavarapu Check if FA already exists or not
			FieldActivity fa = null;
			StringBuilder queryStr = new StringBuilder();		
			queryStr.append("SELECT FA_ID FROM CI_FA WHERE SP_ID = :spId AND TRUNC(SCHED_DTTM) = :Scheduled ");
			queryStr.append("AND FA_TYPE_CD = :faType AND FA_STATUS_FLG IN ('C','P') ");
			PreparedStatement getFaStmt = createPreparedStatement(queryStr.toString(), getClass().getName());
			getFaStmt.bindId("spId", sp.getId());
			getFaStmt.bindDate("Scheduled", schedDate);
			getFaStmt.bindId("faType", faType.getId());
		//	getFaStmt.bindLookup("faStatus", FieldActivityStatusLookup.constants.PENDING);
			SQLResultRow faRow = getFaStmt.firstRow();
			getFaStmt.close();
			
			
			if(isNull(faRow)){	
			
			// Create a new FA DTO
			FieldActivity_DTO faDto = new FieldActivity_DTO();
			
			// Set DTO values
			faDto.setCreatedBy(FieldActivityCreatedByLookup.constants.BACKGROUND);
			faDto.setCreationDateTime(getProcessDateTime());
			faDto.setFieldActivityStatus(FieldActivityStatusLookup.constants.PENDING);
			faDto.setServicePointId(sp.getId());	
			faDto.setFieldActivityTypeId(faType.getId());
			faDto.setScheduleDateTimeStart(schedDate.startOfDay());
						
			// Create a new FA Creator Data
			FieldActivityCreatorData faCreatorData = FieldActivityCreatorData.Factory.newInstance();
			faCreatorData.setFaDTO(faDto);
			
			// Create a new Field Activity Creator
			FieldActivityCreator faCreator = FieldActivityCreator.Factory.newInstance();
			fa = faCreator.addFieldActivity(faCreatorData);
			
	        // Add FA Characteristics
	        addFieldActivityCharacteristic(fa, forceFACharType, forceFACharVal);
	        
			return fa;
			
			}
			else
			{
	            List<SQLResultRow> faList=getFaStmt.list();
	            
	            for(SQLResultRow row:faList)
	            {
	            //	fa =(FieldActivity)row.getId("FA_ID", FieldActivity.class);
	            	
	            }
	            return fa;
			}
			
		
		}
		
	    /**
	     * This method add FA Characteristics.
	     * @param fa - FieldActivity
	     * @param charType - CharacteristicType
	     * @param charValue - String
	     */
	    private void addFieldActivityCharacteristic(FieldActivity fa, CharacteristicType charType, String charValue) {
	                    
	        // Add Characteristic to the Field Activity
	        FieldActivityCharacteristic_DTO fieldActivityCharacteristic_DTO = fa.getCharacteristics().newChildDTO();
	        CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
	    
	        if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
	            fieldActivityCharacteristic_DTO.setAdhocCharacteristicValue(charValue);
	        } 
	        else if (charTypeLookup.isForeignKeyValue()) {
	            fieldActivityCharacteristic_DTO.setCharacteristicValueForeignKey1(charValue);
	        } 
	        else {
	            fieldActivityCharacteristic_DTO.setCharacteristicValue(charValue);
	        }
	        
	        fa.getCharacteristics().add(fieldActivityCharacteristic_DTO, charType.getId(), BigInteger.TEN);
	    }
		
		/**
		 * This method will get the Next Scheduled Work Date
		 * @param mrCycle
		 * @param windowStartDate
		 * @return query
		 */
		private Query<Date> getNextScheduledWorkDate(MeterReadCycle mrCycle, Date windowStartDate) {
			
			StringBuilder sb = new StringBuilder();
			sb.append(" FROM MeterReadSchedule meterReadSchedule ");
			sb.append(" WHERE meterReadSchedule.id.meterReadCycle = :meterReadCycle ");
			sb.append(" AND meterReadSchedule.scheduledReadDate > :windowStartDate ");
			
			Query<Date> getNextScheduledWorkDate = createQuery(sb.toString(), "getEarliestScheduledWorkDate");
			getNextScheduledWorkDate.bindEntity("meterReadCycle", mrCycle);
			getNextScheduledWorkDate.bindDate("windowStartDate", windowStartDate);
			getNextScheduledWorkDate.addResult("scheduledReadDate", "meterReadSchedule.scheduledReadDate");
			getNextScheduledWorkDate.orderBy("scheduledReadDate", Query.ASCENDING);
			
			return getNextScheduledWorkDate;
		}
	}
}
