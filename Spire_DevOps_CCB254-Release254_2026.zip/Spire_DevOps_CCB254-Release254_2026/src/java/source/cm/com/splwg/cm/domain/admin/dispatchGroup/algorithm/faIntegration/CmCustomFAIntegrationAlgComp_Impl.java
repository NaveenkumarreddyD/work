/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPOWORX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      NI0009.1. Initial Version.
 * 2016-06-14   SMiran      Defect 3454796. Fixed FA Header Changed Switch  
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.                             
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.dispatchGroup.algorithm.faIntegration;

import java.math.BigInteger;
import java.sql.Connection;
import java.util.List;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpoworx;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.domain.workflow.notificationDownload.NotificationDownload_Id;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.api.lookup.FieldActivityChangeEventLookup;
import com.splwg.ccb.domain.admin.dispatchGroup.algorithm.faIntegration.DispatchGroupFaIntegrationAlgorithmSpot;
import com.splwg.ccb.domain.admin.dispatchGroup.entity.DispatchGroup;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.ccb.domain.workflow.notificationDownload.entity.NotificationDownload;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.HibernateHelper;
import com.splwg.shared.common.ServerMessage;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = faIDCharType, type = entity)
 *            , @AlgorithmSoftParameter (name = createLogEntry, type = boolean)
 *            , @AlgorithmSoftParameter (name = postponeFAInterfaceAfterAppointmentIsBooked, type = boolean)
 *            , @AlgorithmSoftParameter (name = appointmentProcessingViaOrders, type = boolean)})
 */
public class CmCustomFAIntegrationAlgComp_Impl extends
		CmCustomFAIntegrationAlgComp_Gen implements
		DispatchGroupFaIntegrationAlgorithmSpot {

	// hard parameters
	private Bool isFaChangeProcessed;
	private List<NotificationDownload> notificationDownloads;
	private BigInteger notificationDownloadCount;
	private FieldActivityData faDataAfterChange;
	private FieldActivityData faDataBeforeChange;
	private FieldActivity fieldActivity;
	private FieldActivityChangeEventLookup fieldActivityChangeEventLookup;
	private DispatchGroup fieldActivityIntDispatchGroup;
	private Bool isFaHeaderChanged;
	
	// soft parameters
	private CharacteristicType faIDCharType;
	private Bool createLogEntry;
	private Bool postponeFAInterfaceAfterAppointmentIsBooked;
	private Bool appointmentProcessingViaOrders;
	
	private Cmpoworx cmpoworx;
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	
	@Override
	public Bool getIsFaChangeProcessed() {
		return isFaChangeProcessed;
	}

	@Override
	public List<NotificationDownload> getNotificationDownloads() {
		return notificationDownloads;
	}

	@Override
	public BigInteger getnotificationDownloadCount() {
		return notificationDownloadCount;
	}

	@Override
	public void setFaDataAfterChange(FieldActivityData arg0) {
		faDataAfterChange = arg0;
	}

	@Override
	public void setFaDataBeforeChange(FieldActivityData arg0) {
		faDataBeforeChange = arg0;
	}

	@Override
	public void setFieldActivity(FieldActivity arg0) {
		fieldActivity = arg0;
	}

	@Override
	public void setFieldActivityChangeEventLookup(
			FieldActivityChangeEventLookup arg0) {
		fieldActivityChangeEventLookup = arg0;
	}

	@Override
	public void setFieldActivityIntDispatchGroup(DispatchGroup arg0) {
		fieldActivityIntDispatchGroup = arg0;
	}

	@Override
	public void setIsFaChangeProcessed(Bool arg0) {
		isFaChangeProcessed = arg0;
	}

	@Override
	public void setIsFaHeaderChanged(Bool arg0) {
		isFaHeaderChanged = arg0;
	}
	
	
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		faIDCharType = getFaIDCharType();
		createLogEntry = getCreateLogEntry();
		postponeFAInterfaceAfterAppointmentIsBooked = getPostponeFAInterfaceAfterAppointmentIsBooked();
		appointmentProcessingViaOrders = getAppointmentProcessingViaOrders();
	}

	@Override
	public void invoke() {
		
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			if(notNull(fieldActivity)) {
				cmpoworx.setFaInfoFaId(fieldActivity.getId().getTrimmedValue());
			}else{
				cmpoworx.setFaInfoFaId(CobolCode.SPACES.toString());
			}
			if(notNull(fieldActivityChangeEventLookup)) {
				cmpoworx.setFaEvtFlg(fieldActivityChangeEventLookup.trimmedValue());
			}else{
				cmpoworx.setFaEvtFlg(CobolCode.SPACES.toString());
			}
			// 2016-06-14. SMiran. Defect 3454796. Start Change
			//cmpoworx.setFaHdrChgSw(SWITCH_YES);
			if (notNull(isFaHeaderChanged)){
				String isFaHeaderChangedStr = (isFaHeaderChanged.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpoworx.setFaHdrChgSw(isFaHeaderChangedStr);
			}else{
				cmpoworx.setFaHdrChgSw(SWITCH_YES);
				
				if (fieldActivityChangeEventLookup.isChangeFieldActivity()){
					
					if (faDataBeforeChange.getFieldActivity_DTO().getFieldActivityTypeId()
							.equals(faDataAfterChange.getFieldActivity_DTO().getFieldActivityTypeId())
					    && faDataBeforeChange.getFieldActivity_DTO().getDispatchGroupId()
							.equals(faDataAfterChange.getFieldActivity_DTO().getDispatchGroupId())
						&& faDataBeforeChange.getFieldActivity_DTO().getAppointmentScheduleId()
							.equals(faDataAfterChange.getFieldActivity_DTO().getAppointmentScheduleId())
						&& (
								(isNull(faDataBeforeChange.getFieldActivity_DTO().getScheduleDateTimeStart()) 
								&& isNull(faDataAfterChange.getFieldActivity_DTO().getScheduleDateTimeStart()))
							)
						&& faDataBeforeChange.getFieldActivity_DTO().getInstructions().trim()
							.equals(faDataAfterChange.getFieldActivity_DTO().getInstructions().trim())
						&& faDataBeforeChange.getFieldActivity_DTO().getLongDescription().trim()
							.equals(faDataAfterChange.getFieldActivity_DTO().getLongDescription().trim())
						&& faDataBeforeChange.getFieldActivity_DTO().getFieldActivityPriority()	
							.equals(faDataAfterChange.getFieldActivity_DTO().getFieldActivityPriority())
						&& faDataBeforeChange.getFieldActivity_DTO().getFieldActivityStatus()
							.equals(faDataAfterChange.getFieldActivity_DTO().getFieldActivityStatus())
						&& faDataBeforeChange.getFieldActivity_DTO().getExternalId().trim()
							.equals(faDataAfterChange.getFieldActivity_DTO().getExternalId().trim())	
						&& faDataBeforeChange.getFieldActivity_DTO().getIntermediateStatus().trim()
							.equals(faDataAfterChange.getFieldActivity_DTO().getIntermediateStatus().trim())	
						&& faDataBeforeChange.getFieldActivity_DTO().getServicePointId()
							.equals(faDataAfterChange.getFieldActivity_DTO().getServicePointId())
						&& faDataBeforeChange.getFieldActivity_DTO().getFieldOrderId()
							.equals(faDataAfterChange.getFieldActivity_DTO().getFieldOrderId())							
					){
						cmpoworx.setFaHdrChgSw(SWITCH_NO);
					}
				}
			}
			// 2016-06-14. SMiran. Defect 3454796. End Change
			
			if(notNull(faDataBeforeChange)) {
				FieldActivity_DTO beforeChangeFaDto = faDataBeforeChange.getFieldActivity_DTO();
				if(notNull(beforeChangeFaDto)) {
					if(notNull(beforeChangeFaDto.getId())) {
						cmpoworx.setOfactBeforeChgFaId(beforeChangeFaDto.getId().getTrimmedValue());
					}else{
						cmpoworx.setOfactBeforeChgFaId(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getFieldActivityTypeId())) {
						cmpoworx.setOfactBeforeChgFaTypeCd(beforeChangeFaDto.getFieldActivityTypeId().getTrimmedValue());
					}else{
						cmpoworx.setOfactBeforeChgFaTypeCd(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getServicePointId())) {
						cmpoworx.setOfactBeforeChgSpId(beforeChangeFaDto.getServicePointId().getTrimmedValue());
					}else{
						cmpoworx.setOfactBeforeChgSpId(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getFieldActivityPriority())) {
						cmpoworx.setOfactBeforeChgFaPriorityFlg(beforeChangeFaDto.getFieldActivityPriority().trimmedValue());
					}else{
						cmpoworx.setOfactBeforeChgFaPriorityFlg(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getCreatedBy())) {
						cmpoworx.setOfactBeforeChgFaCreatedByFlg(beforeChangeFaDto.getCreatedBy().trimmedValue());
					}else{
						cmpoworx.setOfactBeforeChgFaCreatedByFlg(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getScheduleDateTimeStart())) {
						cmpoworx.setOfactBeforeChgSchedDttm(beforeChangeFaDto.getScheduleDateTimeStart().toString());
					}else{
						cmpoworx.setOfactBeforeChgSchedDttm(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getFieldActivityStatus())) {
						cmpoworx.setOfactBeforeChgFaStatusFlg(beforeChangeFaDto.getFieldActivityStatus().trimmedValue());
					}else{
						cmpoworx.setOfactBeforeChgFaStatusFlg(CobolCode.SPACES.toString());
					}
					
					if(notNull(beforeChangeFaDto.getIsEligibleForDispatch())) {
						String isEligibleForDispatch = (beforeChangeFaDto.getIsEligibleForDispatch().isTrue()) ? SWITCH_YES : SWITCH_NO;
						cmpoworx.setOfactBeforeChgEligDispatchSw(isEligibleForDispatch);
					}else{
						cmpoworx.setOfactBeforeChgEligDispatchSw(CobolCode.SPACES.toString());
					}
					
					if(notNull(beforeChangeFaDto.getDispatchGroupId())) {
						cmpoworx.setOfactBeforeChgDispGrpCd(beforeChangeFaDto.getDispatchGroupId().getTrimmedValue());
					}else{
						cmpoworx.setOfactBeforeChgDispGrpCd(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getFieldOrderId())) {
						cmpoworx.setOfactBeforeChgFoId(beforeChangeFaDto.getFieldOrderId().getTrimmedValue());
					}else{
						cmpoworx.setOfactBeforeChgFoId(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getCreationDateTime())) {
						cmpoworx.setOfactBeforeChgCreDttm(beforeChangeFaDto.getCreationDateTime().toString());
					}else{
						cmpoworx.setOfactBeforeChgCreDttm(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getTestSelectionId())) {
						cmpoworx.setOfactBeforeChgTestSelId(beforeChangeFaDto.getTestSelectionId().getTrimmedValue());
					}else{
						cmpoworx.setOfactBeforeChgTestSelId(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getUserId())) {
						cmpoworx.setOfactBeforeChgUserId(beforeChangeFaDto.getUserId().getTrimmedValue());
					}else{
						cmpoworx.setOfactBeforeChgUserId(CobolCode.SPACES.toString());
					}
					if(notBlank(beforeChangeFaDto.getInstructions())) {
						cmpoworx.setOfactBeforeChgInstructions(beforeChangeFaDto.getInstructions().trim());
					}else{
						cmpoworx.setOfactBeforeChgInstructions(CobolCode.SPACES.toString());
					}
					if(notBlank(beforeChangeFaDto.getLongDescription())) {
						cmpoworx.setOfactBeforeChgDescrlong(beforeChangeFaDto.getLongDescription().trim());
					}else{
						cmpoworx.setOfactBeforeChgDescrlong(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getCancelReasonId())) {
						cmpoworx.setOfactBeforeChgFaCanRsnCd(beforeChangeFaDto.getCancelReasonId().getTrimmedValue());
					}else{
						cmpoworx.setOfactBeforeChgFaCanRsnCd(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getAppointmentScheduleId())) {
						cmpoworx.setOfactBeforeChgAppSchedId(beforeChangeFaDto.getAppointmentScheduleId().getTrimmedValue());
					}else{
						cmpoworx.setOfactBeforeChgAppSchedId(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getIsEligibleForArchiving())) {
						String isEligibleForArchiving = (beforeChangeFaDto.getIsEligibleForArchiving().isTrue()) ? SWITCH_YES : SWITCH_NO;
						cmpoworx.setOfactBeforeChgIlmArchSw(isEligibleForArchiving);
					}else{
						cmpoworx.setOfactBeforeChgIlmArchSw(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getIlmDate())) {
						cmpoworx.setOfactBeforeChgIlmDt(beforeChangeFaDto.getIlmDate().toString());
					}else{
						cmpoworx.setOfactBeforeChgIlmDt(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getVersion())) {
						cmpoworx.setOfactBeforeChgVersion(java.math.BigDecimal.valueOf(beforeChangeFaDto.getVersion()));
					}else{
						cmpoworx.setOfactBeforeChgVersion(java.math.BigDecimal.ZERO);
					}
					if(notBlank(beforeChangeFaDto.getIntermediateStatus())) {
						cmpoworx.setOfactBeforeChgFaIntStatusFlg(beforeChangeFaDto.getIntermediateStatus().trim());
					}else{
						cmpoworx.setOfactBeforeChgFaIntStatusFlg(CobolCode.SPACES.toString());
					}
					if(notBlank(beforeChangeFaDto.getFieldActivityDataArea())) {
						cmpoworx.setOfactBeforeChgFaDataArea(beforeChangeFaDto.getFieldActivityDataArea().trim());
					}
					if(notNull(beforeChangeFaDto.getFieldworkRescheduleReasonId())) {
						cmpoworx.setOfactBeforeChgFaReschedRsnCd(beforeChangeFaDto.getFieldworkRescheduleReasonId().getTrimmedValue());
					}else{
						cmpoworx.setOfactBeforeChgFaReschedRsnCd(CobolCode.SPACES.toString());
					}
					if(notNull(beforeChangeFaDto.getExternalId())) {
						cmpoworx.setOfactBeforeChgFaExtId(beforeChangeFaDto.getExternalId());
					}else{
						cmpoworx.setOfactBeforeChgFaExtId(CobolCode.SPACES.toString());
					}
				}
				
				if(notNull(faDataBeforeChange.getIsFieldActivityTypeChanged())) {
					String isFieldActivityTypeChanged = (faDataBeforeChange.getIsFieldActivityTypeChanged().isTrue()) ? SWITCH_YES : SWITCH_NO;
					cmpoworx.setOfactBeforeChgFaTypeChangeSw(isFieldActivityTypeChanged);
				}else{
					cmpoworx.setOfactBeforeChgFaTypeChangeSw(CobolCode.SPACES.toString());
				}
				
			}
			
			if (notNull(faDataAfterChange)) {
				FieldActivity_DTO afterChangeFaDto = faDataAfterChange.getFieldActivity_DTO();
				if (notNull(afterChangeFaDto)) {
					if (notNull(afterChangeFaDto.getId())) {
						cmpoworx.setOfactAfterChgFaId(afterChangeFaDto.getId().getTrimmedValue());
					}else{
						cmpoworx.setOfactAfterChgFaId(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getFieldActivityTypeId())) {
						cmpoworx.setOfactAfterChgFaTypeCd(afterChangeFaDto.getFieldActivityTypeId().getTrimmedValue());
					}else{
						cmpoworx.setOfactAfterChgFaTypeCd(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getServicePointId())) {
						cmpoworx.setOfactAfterChgSpId(afterChangeFaDto.getServicePointId().getTrimmedValue());
					}else{
						cmpoworx.setOfactAfterChgSpId(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getFieldActivityPriority())) {
						cmpoworx.setOfactAfterChgFaPriorityFlg(afterChangeFaDto.getFieldActivityPriority().trimmedValue());
					}else{
						cmpoworx.setOfactAfterChgFaPriorityFlg(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getCreatedBy())) {
						cmpoworx.setOfactAfterChgFaCreatedByFlg(afterChangeFaDto.getCreatedBy().trimmedValue());
					}else{
						cmpoworx.setOfactAfterChgFaCreatedByFlg(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getScheduleDateTimeStart())) {
						cmpoworx.setOfactAfterChgSchedDttm(afterChangeFaDto.getScheduleDateTimeStart().toString());
					}else{
						cmpoworx.setOfactAfterChgSchedDttm(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getFieldActivityStatus())) {
						cmpoworx.setOfactAfterChgFaStatusFlg(afterChangeFaDto.getFieldActivityStatus().trimmedValue());
					}else{
						cmpoworx.setOfactAfterChgFaStatusFlg(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getIsEligibleForDispatch())) {
						String isEligibleForDispatch = (afterChangeFaDto.getIsEligibleForDispatch().isTrue()) ? SWITCH_YES : SWITCH_NO;
						cmpoworx.setOfactAfterChgEligDispatchSw(isEligibleForDispatch);
					}else{
						cmpoworx.setOfactAfterChgEligDispatchSw(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getDispatchGroupId())) {
						cmpoworx.setOfactAfterChgDispGrpCd(afterChangeFaDto.getDispatchGroupId().getTrimmedValue());
					}else{
						cmpoworx.setOfactAfterChgDispGrpCd(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getFieldOrderId())) {
						cmpoworx.setOfactAfterChgFoId(afterChangeFaDto.getFieldOrderId().getTrimmedValue());
					}else{
						cmpoworx.setOfactAfterChgFoId(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getCreationDateTime())) {
						cmpoworx.setOfactAfterChgCreDttm(afterChangeFaDto.getCreationDateTime().toString());
					}else{
						cmpoworx.setOfactAfterChgCreDttm(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getTestSelectionId())) {
						cmpoworx.setOfactAfterChgTestSelId(afterChangeFaDto.getTestSelectionId().getTrimmedValue());
					}else{
						cmpoworx.setOfactAfterChgTestSelId(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getUserId())) {
						cmpoworx.setOfactAfterChgUserId(afterChangeFaDto.getUserId().getTrimmedValue());
					}else{
						cmpoworx.setOfactAfterChgUserId(CobolCode.SPACES.toString());
					}
					if (notBlank(afterChangeFaDto.getInstructions())) {
						cmpoworx.setOfactAfterChgInstructions(afterChangeFaDto.getInstructions().trim());
					}else{
						cmpoworx.setOfactAfterChgInstructions(CobolCode.SPACES.toString());
					}
					if (notBlank(afterChangeFaDto.getLongDescription())) {
						cmpoworx.setOfactAfterChgDescrlong(afterChangeFaDto.getLongDescription().trim());
					}else{
						cmpoworx.setOfactAfterChgDescrlong(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getCancelReasonId())) {
						cmpoworx.setOfactAfterChgFaCanRsnCd(afterChangeFaDto.getCancelReasonId().getTrimmedValue());
					}else{
						cmpoworx.setOfactAfterChgFaCanRsnCd(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getAppointmentScheduleId())) {
						cmpoworx.setOfactAfterChgAppSchedId(afterChangeFaDto.getAppointmentScheduleId().getTrimmedValue());
					}else{
						cmpoworx.setOfactAfterChgAppSchedId(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getIsEligibleForArchiving())) {
						String isEligibleForArchiving = (afterChangeFaDto.getIsEligibleForArchiving().isTrue()) ? SWITCH_YES : SWITCH_NO;
						cmpoworx.setOfactAfterChgIlmArchSw(isEligibleForArchiving);
					}else{
						cmpoworx.setOfactAfterChgIlmArchSw(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getIlmDate())) {
						cmpoworx.setOfactAfterChgIlmDt(afterChangeFaDto.getIlmDate().toString());
					}else{
						cmpoworx.setOfactAfterChgIlmDt(CobolCode.SPACES.toString());
					}
					if (notNull(afterChangeFaDto.getVersion())) {
						cmpoworx.setOfactAfterChgVersion(java.math.BigDecimal.valueOf(afterChangeFaDto.getVersion()));
					}else{
						cmpoworx.setOfactAfterChgVersion(java.math.BigDecimal.ZERO);
					}
					if (notBlank(afterChangeFaDto.getIntermediateStatus())) {
						cmpoworx.setOfactAfterChgFaIntStatusFlg(afterChangeFaDto.getIntermediateStatus().trim());
					}else{
						cmpoworx.setOfactAfterChgFaIntStatusFlg(CobolCode.SPACES.toString());
					}
					if (notBlank(afterChangeFaDto.getFieldActivityDataArea())) {
						cmpoworx.setOfactAfterChgFaDataArea(afterChangeFaDto.getFieldActivityDataArea().trim());
					}
					if (notNull(afterChangeFaDto.getFieldworkRescheduleReasonId())) {
						cmpoworx.setOfactAfterChgFaReschedRsnCd(afterChangeFaDto.getFieldworkRescheduleReasonId().getTrimmedValue());
					}else{
						cmpoworx.setOfactAfterChgFaReschedRsnCd(CobolCode.SPACES.toString());
					}
					if(notNull(afterChangeFaDto.getExternalId())) {
						cmpoworx.setOfactAfterChgFaExtId(afterChangeFaDto.getExternalId());
					}else{
						cmpoworx.setOfactAfterChgFaExtId(CobolCode.SPACES.toString());
					}
				}
				
				if (notNull(faDataAfterChange.getIsFieldActivityTypeChanged())) {
					String isFieldActivityTypeChanged = (faDataAfterChange.getIsFieldActivityTypeChanged().isTrue()) ? SWITCH_YES : SWITCH_NO;
					cmpoworx.setOfactAfterChgFaTypeChangeSw(isFieldActivityTypeChanged);
				}else{
					cmpoworx.setOfactAfterChgFaTypeChangeSw(CobolCode.SPACES.toString());
				}
			}
			
			if (notNull(fieldActivityIntDispatchGroup)) {
				cmpoworx.setFaIntDispGrp(fieldActivityIntDispatchGroup.getId().getTrimmedValue());
			}else{
				cmpoworx.setFaIntDispGrp(CobolCode.SPACES.toString());
			}
			
			if (notNull(isFaChangeProcessed)) {
				String isFAChangeProcessedSw = (isFaChangeProcessed.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpoworx.setFaChgProcessedSw(isFAChangeProcessedSw);
			}else{
				cmpoworx.setFaChgProcessedSw(CobolCode.SPACES.toString());
			}
			
			// set cobol program's soft parameters
			
			if (notNull(faIDCharType)) {
				cmpoworx.setAlgParmVal(1, faIDCharType.getId().getTrimmedValue());
			}else{
				cmpoworx.setAlgParmVal(1, CobolCode.SPACES.toString());
			}
			if (notNull(createLogEntry)) {
				String createLogEntrySw = (createLogEntry.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpoworx.setAlgParmVal(2, createLogEntrySw); 
			}else{
				cmpoworx.setAlgParmVal(2, CobolCode.SPACES.toString());
			}
			if (notNull(postponeFAInterfaceAfterAppointmentIsBooked)) {
				String postponeFAInterfaceAfterAppointmentIsBookedSw = (postponeFAInterfaceAfterAppointmentIsBooked.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpoworx.setAlgParmVal(3, postponeFAInterfaceAfterAppointmentIsBookedSw);
			}else{
				cmpoworx.setAlgParmVal(3, CobolCode.SPACES.toString());
			}
			if (notNull(postponeFAInterfaceAfterAppointmentIsBooked)) {
				String appointmentProcessingViaOrdersSw = (appointmentProcessingViaOrders.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpoworx.setAlgParmVal(4, appointmentProcessingViaOrdersSw); 
			}else{
				cmpoworx.setAlgParmVal(4, CobolCode.SPACES.toString());
			}
			
			// invoke the main method
		    cmpoworx.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
		    
		    ex.printStackTrace();
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmpoworx.getZmsgnMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmpoworx.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmpoworx.getParmCollMessageParm(i);
			    			if (notBlank(cmpoworx.getParmCollMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmpoworx.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmpoworx.getZmsgnMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmpoworx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmpoworx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    	isFaChangeProcessed = (cmpoworx.getFaChgProcessedSw().compareTo(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE;
		    	
		    	notificationDownloadCount = cmpoworx.getNtDwnIdCollCnt().toBigInteger();
		    	for (int i = 1; i <= notificationDownloadCount.intValue(); i++) {
		    		try {
		    			NotificationDownload notificationDownload = (NotificationDownload) new NotificationDownload_Id(cmpoworx.getNtDwnIdCollNtDwnId(i)).getEntity();
		    			notificationDownloads.add(notificationDownload);
		    		
					} catch (IndexOutOfBounds e) {
						addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
					}
		    	}
		    }
		    else {
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmpoworx=Session.returnSessionAndCodeToCache(cmpoworx);
		}

	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
        FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
        RequestContext context = session.getRequestContext();
                        
        @SuppressWarnings("deprecation")
        Connection conn=HibernateHelper.getConnection(session.getHibernateSession());
                        
        String username = conn.getMetaData().getUserName();
        String url = conn.getMetaData().getURL();
                        
        CobolSession.setLogSessionStartEnd(false);
                        
        cmpoworx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpoworx.class);
        cmpoworx.getSession().getDbSession().setUpdateConnection(conn);
		
        // initialize linkage copybooks
        cmpoworx.aa100Initialize();
        
		// set ZSTAT parameters

		cmpoworx.setProcessDttmProcessDt(getProcessDateTime().getDate().toString());
		cmpoworx.setProcessDttmSep("-");
		cmpoworx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
		
		if (session.isOnlineConnection()) { 
			cmpoworx.setConnectionFlg(CONNECTION_ONLINE);
		}
		else {
			cmpoworx.setConnectionFlg(CONNECTION_BATCH);
		}
		
		cmpoworx.setZstatUserId(context.getUserId());
		cmpoworx.setZstatLanguageCd(context.getLanguageCode());
        
        if (context.ignoreWarnings()) {
        	cmpoworx.setIgnoreWarningSw(SWITCH_YES);
        }
        else {
        	cmpoworx.setIgnoreWarningSw(SWITCH_NO);
        }
        
        if (session.getBatchInstanceId() != null) {
        	cmpoworx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
        	
		} else {
			cmpoworx.setSchedulerId(new BigDecimal(0).toBigDecimal());
		}
        
        cmpoworx.setAppSvcId(context.getSecurityServiceIdContext());
        
        DatabaseHelper dbHelper = session.getDatabaseHelper();
        cmpoworx.setDbMode(dbHelper.getCobolDBMode());
        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
        //cmpoworx.setSplHighValue(cmpoworx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
        //cmpoworx.setSplLowValue(cmpoworx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
        
        cmpoworx.setSplHighValue(cmpoworx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
        cmpoworx.setSplLowValue(cmpoworx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
        // CCB v2.6 Upgrade - 2018-05-31 - End Change
        
        cmpoworx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
        
        cmpoworx.setLkExpiryDt(Date.MAX.toString());
        
        cmpoworx.setProgramStatus(" ");
        
        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
        cmpoworx.setCallSeq(";");
        cmpoworx.setMessageAreaProgramName("CMPOWORX");
        // CCB v2.6 Upgrade - 2018-08-02 - End Add
        
        if (context.getRandomGeneratorSeedSet().isTrue()) {
        	cmpoworx.setRandomGenSeedSw(SWITCH_YES);
        	cmpoworx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
        	cmpoworx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
        	cmpoworx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
        	cmpoworx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
        }
        else {
        	cmpoworx.setRandomGenSeedSw(SWITCH_NO);
        }
        
        if (context.traceStandardOut()) { 
        	cmpoworx.setTrcStdoutSw(SWITCH_YES);
        }
        else {
        	cmpoworx.setTrcStdoutSw(SWITCH_NO);
        }
        
        if (context.traceProgramStart()) { 
        	cmpoworx.setTrcProgStartSw(SWITCH_YES);
        }
        else {
        	cmpoworx.setTrcProgStartSw(SWITCH_NO);
        }
        
        if (context.traceProgramExit()) { 
        	cmpoworx.setTrcProgExitSw(SWITCH_YES);
        }
        else {
        	cmpoworx.setTrcProgExitSw(SWITCH_NO);
        }
        
        if (context.traceSQL()) { 
        	cmpoworx.setTrcExecSqlSw(SWITCH_YES);
        }
        else {
        	cmpoworx.setTrcExecSqlSw(SWITCH_NO);
        }
        
        // Set ZMSGN parms
        BigInteger messageSequence = session.getMessageSequence();
        if (notNull(messageSequence)) {
        	cmpoworx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
        }
        else {
        	cmpoworx.setMessageSeq(new BigDecimal(0).toBigDecimal());
        }

	}

}
