/*******************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NB0029 - Manual Meter Read Field Activity
 *
 *  This batch process generates Field Activities for Service Points without AMR Devices.
 *  The batch process will select the Service Points due for Billing based on Service Cycle
 *  on the Service Point by verifying the Power Status on the Service Point Characteristic.
 *  The batch process will create the Field Activities on all the Service Points.
 *
 ********************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2012-09-16	Srikanth	NB0029. Initial Version.
 * 2012-10-05	Srikanth	NB0029. Code Review Comments.
 * 2013-02-01   Srikanth	NB0029. Change Request
 * 2013-05-23   Srikanth    Bug 1032 : SD20130523 - FS Change
 * 2014-05-06	Rahul		IM-044549 : Skip FA creation for Disconnected SP
 * 2015-06-04   BMarquez    SF-3227483. Add CIS Division parameter.
 * 2016-01-29  	MPang		Updated for CCB v2.4 compilation.
 * 2018-02-29	DarrylH		SA:241261 Altered Java variables
 * 							intialization. Static variable did not work well
 * 							in AE (uc4 schedule)
 * 2020-12-02	DarrylH		SA:353846 fix sql to select the right spID
 * 2021-07-16	EQuint		SA-374433 added logic to exclude FA creation
 * 							depending on meter type
 * 2022-03-24 Darryl H		B-21850 exclude meter with ERT installed.
 ********************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Time;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicTypeValues;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityCreatedByLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.meterReadSchedule.MeterReadSchedule_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_DTO;*/
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.meterReadSchedule.entity.MeterReadSchedule_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/*
 * Start Change - SF-3227483 - 2015-06-04
 */
///**
// * @author sdesabhatl002
// *
// @BatchJob (modules = {}
// *      , multiThreaded = true
// *      , rerunnable = true
// *      , softParameters = { @BatchJobSoftParameter (lookupName = schemaConstantOption, name = FC_FIELD_ACTIVITY_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = schemaConstantOption, name = FC_POWER_STATUS_CHAR_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = TRANSPORT_ACCOUNT_CHAR, required = true, type = entity)})
// */

// start change - SA-374433 - EQuint - 2021-07-16
///**
// * @author sdesabhatl002
// *
// @BatchJob (modules = {}, softParameters = { @BatchJobSoftParameter (lookupName = schemaConstantOption, name = FC_FIELD_ACTIVITY_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = schemaConstantOption, name = FC_POWER_STATUS_CHAR_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = TRANSPORT_ACCOUNT_CHAR, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity)})
// */

/**
 * @author sdesabhatl002
 *
 @BatchJob (modules = {}, softParameters = { @BatchJobSoftParameter (lookupName = schemaConstantOption, name = FC_FIELD_ACTIVITY_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = schemaConstantOption, name = FC_POWER_STATUS_CHAR_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = schemaConstantOption, name = FC_MAXIMO_MTR_TYPE_CHAR_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (name = EXCLUDE_MTR_TYPE, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = TRANSPORT_ACCOUNT_CHAR, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = EXCL_MTR_CFG_TY, type = string, required = false)})
 */
//end change - SA-374433 - EQuint - 2021-07-16
/*
 * End Change - SF-3224783 - 2015-06-04
 */

public class CmManualMeterReadFACreation_BatchProcess extends
		CmManualMeterReadFACreation_BatchProcess_Gen {

	private List<SQLResultRow> servicePointList;
	// START CHANGE-DarrylH -2018-02-29 SA-241261
	//private static FieldActivityType fieldActivityType;
	private FieldActivityType fieldActivityType;
	// END CHANGE-DarrylH -2018-02-29 SA-241261
	private CharacteristicType powerSourceChar;
	private CharacteristicType transportAccountChar;
	// start add - SA-374433 - EQuint - 2021-07-16
	private CharacteristicType maximoMeterChar;
	private String excludeMeterTypeFilter = "";
	// end add - SA-374433 - EQuint - 2021-07-16
    /*
     * Start Add - SF-3224783 - 2015-06-04
     */
    private CisDivision cisDivision;
    /*
     * End Add - SF-3224783 - 2015-06-04
     */
    // start add ADDP Kiran 2023-02-07
    private String excludeMeterConfigFilter = "";
    // end add ADDP Kiran 2023-02-07
    
	private static final String FEATURE_CONFIG_NAME = "SCHEMACONST";

	public void validateSoftParameters(boolean isnewRun){

		BigInteger parmMaxErrors = getParameters().getSoftMaxErrors();
		// Check if the override maximum errors is less than 0
		if (notNull(parmMaxErrors) && parmMaxErrors.intValue() <= 0) {
			addError(CustomMessageRepository.nb0029IntegerParamCannotBeNegative(parmMaxErrors.toString().trim()));
		}

		String strInputFAType = getParameters().getFC_FIELD_ACTIVITY_TYPE().value().trim();
		String strInputPwrStatusCharType = getParameters().getFC_POWER_STATUS_CHAR_TYPE().value().trim();
		// start add - SA-374433 - EQuint - 2021-07-16
	    String strInputMaximoMtrTypeCharType = getParameters().getFC_MAXIMO_MTR_TYPE_CHAR_TYPE().value().trim();
	    // end add - SA-374433 - EQuint - 2021-07-16
		transportAccountChar = getParameters().getTRANSPORT_ACCOUNT_CHAR();


		String strFAType =   retrieveFeatureConfigOptionVal(strInputFAType);
		String strPwrStatusCharType = retrieveFeatureConfigOptionVal(strInputPwrStatusCharType);
		// start add - SA-374433 - EQuint - 2021-07-16
		String strMaximoMtrTypeCharType = retrieveFeatureConfigOptionVal(strInputMaximoMtrTypeCharType);
	    // end add - SA-374433 - EQuint - 2021-07-16

		if(isBlankOrNull(strFAType)){
			addError(CustomMessageRepository.nb0029FeatureConfigFANotConfigured(strInputFAType));
		}
		if(isBlankOrNull(strPwrStatusCharType)){
			addError(CustomMessageRepository.nb0029FeatureConfigCharNotConfigured(strInputPwrStatusCharType));
		}
		// start add - SA-374433 - EQuint - 2021-07-16
		if(isBlankOrNull(strMaximoMtrTypeCharType)){
			addError(CustomMessageRepository.nb0029FeatureConfigCharNotConfigured(strInputMaximoMtrTypeCharType));
		}
	    // end add - SA-374433 - EQuint - 2021-07-16

		 fieldActivityType =  new FieldActivityType_Id(strFAType).getEntity();
		 powerSourceChar = new CharacteristicType_Id(strPwrStatusCharType).getEntity();
		// start add - SA-374433 - EQuint - 2021-07-16
		 maximoMeterChar = new CharacteristicType_Id(strMaximoMtrTypeCharType).getEntity();
		// end add - SA-374433 - EQuint - 2021-07-16

		 if(isNull(fieldActivityType)){
			addError(CustomMessageRepository.nb0029InvalidFAType(strFAType));
		 }

		if(isNull(powerSourceChar)){
		   	addError(CustomMessageRepository.nb0029InvalidCharType(strPwrStatusCharType));
		}
		// start add - SA-374433 - EQuint - 2021-07-16
		if(isNull(maximoMeterChar)){
		   	addError(CustomMessageRepository.nb0029InvalidCharType(strMaximoMtrTypeCharType));
		}
	    // end add - SA-374433 - EQuint - 2021-07-16

		CharacteristicEntity charEntity = null;
		charEntity = new CharacteristicEntity_Id(powerSourceChar, CharacteristicEntityLookup.constants.SERVICE_POINT).getEntity();
		if(isNull(charEntity)){
			addError(CustomMessageRepository.nb0029FCPowerSourceCharTypeInvalidForEntity(powerSourceChar.getId()));
		}
		charEntity = null;
		charEntity = new CharacteristicEntity_Id(transportAccountChar, CharacteristicEntityLookup.constants.SERVICE_POINT_TYPE).getEntity();
		if(isNull(charEntity)){
			addError(CustomMessageRepository.nb0029CharTypeInvalidForEntity(transportAccountChar.getId()));
		}
		// start add - SA-374433 - EQuint - 2021-07-16
		charEntity = new CharacteristicEntity_Id(maximoMeterChar, CharacteristicEntityLookup.constants.METER).getEntity();
		if(isNull(charEntity)){
			addError(CustomMessageRepository.SA374433_invalidCharTypeForMeterEntity(strMaximoMtrTypeCharType));
		}
		// end add - SA-374433 - EQuint - 2021-07-16
		
		// Start add Kiran ADDP 2023-02-07
		//excludeMeterConfig
		
		String inputexcludeMeterConfig = getParameters().getEXCL_MTR_CFG_TY();
		if (notBlank(inputexcludeMeterConfig)) {
			//CharacteristicTypeValues charValues = maximoMeterChar.getValues();
			String[] excludeMeterConfig = inputexcludeMeterConfig.trim().split("\\s*,\\s*");
			for (int i = 0; i < excludeMeterConfig.length; i++) {
				String mtrConfig = excludeMeterConfig[i];
				
				excludeMeterConfigFilter += "'" + mtrConfig + "'";
						if (i < excludeMeterConfig.length - 1) {
							excludeMeterConfigFilter += ",";
						}
					}
				
				}

		
		// End add Kiran ADDP 2023-02-07
		
		// start add - SA-374433 - EQuint - 2021-07-16
		String inputExcludeMterType = getParameters().getEXCLUDE_MTR_TYPE();
		if (notBlank(inputExcludeMterType)) {
			CharacteristicTypeValues charValues = maximoMeterChar.getValues();
			String[] excludeMeterTypes = inputExcludeMterType.trim().split("\\s*,\\s*");
			for (int i = 0; i < excludeMeterTypes.length; i++) {
				String mtrType = excludeMeterTypes[i];
				// if char type has char values, validate the meter type char value against the char value list
				if (!charValues.isEmpty()) {
					ListFilter<CharacteristicValue> charValuesFilter = charValues.createFilter("WHERE this.id.characteristicValue = :mtrType", getClass().getName());
					charValuesFilter.bindStringProperty("mtrType", CharacteristicValue.properties.characteristicValue, mtrType);
					if (charValuesFilter.listSize() == 0) {
						addError(CustomMessageRepository.SA374433_invalidMeterType(mtrType));
					} else {
						excludeMeterTypeFilter += "'" + mtrType + "'";
						if (i < excludeMeterTypes.length - 1) {
							excludeMeterTypeFilter += ",";
						}
					}
				} else {
					excludeMeterTypeFilter += "'" + mtrType + "'";
					if (i < excludeMeterTypes.length - 1) {
						excludeMeterTypeFilter += ",";
					}
				}
			}
		}

		// end add - SA-374433 - EQuint - 2021-07-16

        /*
         * Start Add - SF-3224783 - 2015-06-04
         */
        cisDivision = getParameters().getCIS_DIVISION();
        /*
         * End Add - SF-3224783 - 2015-06-04
         */

	}

	/**
	 * @return String
	 * @param Feature Configuration Option
	 *  This method retrieves Maximum Sequence Feature Configuration Option Value for the given Feature Configuration Option type input.
	 */

	private String retrieveFeatureConfigOptionVal(String strFeatureConfigOption){

		String strFeatureConfigVal = null;



		FeatureConfiguration_Id schemaConstantsId = new FeatureConfiguration_Id(FEATURE_CONFIG_NAME);
		FeatureConfiguration schemaConstantsFeatureConfig = schemaConstantsId.getEntity();
		if(isNull(schemaConstantsFeatureConfig)){
			addError(CustomMessageRepository.nb0029SchemaConstFeatureConfigNotExists(FEATURE_CONFIG_NAME));
		}
		CmFeatureConfigurationRetriever cmFeatureConfigurationRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
		cmFeatureConfigurationRetriever.setParmWFMName(schemaConstantsFeatureConfig);
		cmFeatureConfigurationRetriever.setParmOptType(strFeatureConfigOption);
		strFeatureConfigVal = cmFeatureConfigurationRetriever.getMaxSequenceOptionValue();
		return strFeatureConfigVal;

	}

	public JobWork getJobWork() {
		getEligibleServicePoints();
		ArrayList<ThreadWorkUnit> workUnitList =  new ArrayList<ThreadWorkUnit>();
		for(SQLResultRow resultRow : servicePointList){
			ThreadWorkUnit workUnit = new ThreadWorkUnit((ServicePoint_Id)resultRow.getId("SP_ID", ServicePoint.class));
			workUnitList.add(workUnit);
		}

		return createJobWorkForThreadWorkUnitList(workUnitList);

	}

	/**
	 * @return void
	 *
	 *  This method retrieves all Service Points for the given Business Date for which there is no Power Status Characteristic or if exists with
	 *  a value "N". It then restricts the Service points by Field Activity if already created and completed.
	 */
	private void getEligibleServicePoints(){

		StringBuilder getSPFromSCQuery = new StringBuilder();

		getSPFromSCQuery.append("SELECT SP.SP_ID ");
		getSPFromSCQuery.append("FROM CI_MR_SCHED SCHED,CI_SP SP,CI_SP_MTR_HIST HIST ");
        /*
         * Start Add - SF-3224783 - 2015-06-04
         */
        getSPFromSCQuery.append(", CI_PREM PR ");
        /*
         * End - Add - SF-3224783 - 2015-06-04
         */
		getSPFromSCQuery.append("WHERE SP.MR_CYC_CD = SCHED.MR_CYC_CD ");
        /*
         * Start Add - SF-3224783 - 2015-06-04
         */
        getSPFromSCQuery.append("AND PR.PREM_ID = SP.PREM_ID ");
        getSPFromSCQuery.append("AND PR.CIS_DIVISION = :cisDivision ");
        /*
         * End - Add - SF-3224783 - 2015-06-04
         */
		getSPFromSCQuery.append("AND HIST.SP_ID = SP.SP_ID ");
		// START CHANGES	2014-05-06	Rahul		IM-044549
		getSPFromSCQuery.append("AND SP.SP_SRC_STATUS_FLG = 'C' ");
		// END CHANGES		2014-05-06	Rahul		IM-044549
		getSPFromSCQuery.append("AND SCHED.SCHED_SEL_DT = :processDate ");
		getSPFromSCQuery.append("AND (HIST.REMOVAL_DTTM IS NULL OR HIST.REMOVAL_DTTM >= :processDateTime) ");
		getSPFromSCQuery.append("AND SP.SP_TYPE_CD NOT IN ");
		getSPFromSCQuery.append("( SELECT SPTY.SP_TYPE_CD ");
		getSPFromSCQuery.append("FROM CI_SP_TYPE SPTY, CI_SP_TYPE_CHAR SPTC ");
		getSPFromSCQuery.append("WHERE SPTY.SP_TYPE_CD = SPTC.SP_TYPE_CD ");
		getSPFromSCQuery.append("AND (SPTC.CHAR_TYPE_CD = :inputTransAcctChar AND SPTC.CHAR_VAL ='Y')) ");
		getSPFromSCQuery.append("AND NOT EXISTS ");
		getSPFromSCQuery.append("(SELECT 'X' FROM CI_SP_CHAR SPCHAR ");
		getSPFromSCQuery.append("WHERE SPCHAR.SP_ID =SP.SP_ID   ");
		getSPFromSCQuery.append("AND (SPCHAR.CHAR_TYPE_CD = :inputPowerSourceChar AND SPCHAR.CHAR_VAL='Y') ");
		getSPFromSCQuery.append("AND SPCHAR.EFFDT = ");
		getSPFromSCQuery.append("( SELECT MAX(SPCHR.EFFDT) FROM  CI_SP_CHAR SPCHR   ");
		// START CHANGES	2020-12-02	darrylh		SA-353846
		//getSPFromSCQuery.append(" WHERE  SPCHR.SP_ID = SP.SP_ID   ");
		getSPFromSCQuery.append(" WHERE  SPCHR.SP_ID = SPCHAR.SP_ID   ");
		// START CHANGES	2020-12-02	darrylh		SA-353846
		getSPFromSCQuery.append(" AND SPCHR.EFFDT <= :processDate  ");
		getSPFromSCQuery.append("AND SPCHR.CHAR_TYPE_CD =:inputPowerSourceChar )) ");
		getSPFromSCQuery.append("AND NOT EXISTS   ");
		getSPFromSCQuery.append(" (SELECT 'X' FROM CI_FA FA   ");
		getSPFromSCQuery.append("  WHERE FA.FA_TYPE_CD = :inputFAType   ");
		getSPFromSCQuery.append("  AND FA.SP_ID = SP.SP_ID  ");
		getSPFromSCQuery.append("  AND TRUNC(FA.SCHED_DTTM) = SCHED.SCHED_READ_DT  ");
		getSPFromSCQuery.append("  AND FA.FA_STATUS_FLG != :faStatus)  ");
		// start add - SA-374433 - EQuint - 2021-07-16
		if (notBlank(excludeMeterTypeFilter)) {
			getSPFromSCQuery.append("AND NOT EXISTS   ");
			getSPFromSCQuery.append("  (SELECT 'X' FROM CI_MTR_CONFIG MC, CI_MTR_CHAR MCH ");
			getSPFromSCQuery.append("  WHERE MC.MTR_CONFIG_ID = HIST.MTR_CONFIG_ID ");
			getSPFromSCQuery.append("  AND MC.MTR_ID = MCH.MTR_ID ");
			getSPFromSCQuery.append("  AND MCH.CHAR_TYPE_CD = :maximoCharType ");
			getSPFromSCQuery.append("  AND MCH.EFFDT = (SELECT MAX(MCH2.EFFDT) FROM CI_MTR_CHAR MCH2 ");
			getSPFromSCQuery.append("    WHERE MCH2.MTR_ID = MCH.MTR_ID ");
			getSPFromSCQuery.append("    AND MCH2.CHAR_TYPE_CD = MCH.CHAR_TYPE_CD) ");
			getSPFromSCQuery.append("  AND MCH.SRCH_CHAR_VAL IN ("+excludeMeterTypeFilter+")) ");
		}
		// end add - SA-374433 - EQuint - 2021-07-16
		// start add - ADDP - Kiran - 2023-02-07
		if (notBlank(excludeMeterConfigFilter)) {
			getSPFromSCQuery.append("AND NOT EXISTS   ");
			getSPFromSCQuery.append("  (SELECT 'X' FROM CI_MTR_CONFIG MCADDP ");
			getSPFromSCQuery.append("  WHERE MCADDP.MTR_CONFIG_ID = HIST.MTR_CONFIG_ID ");
			getSPFromSCQuery.append("  AND MCADDP.MTR_CONFIG_TY_CD IN ("+excludeMeterConfigFilter+")) ");
		}
		// end add - ADDP - Kiran - 2023-02-07
		//start add dlh B-21850 3-24-22
		getSPFromSCQuery.append("AND NOT EXISTS   ");
		getSPFromSCQuery.append(" (SELECT 'X'  FROM CI_MTR_EQ EQP, CI_ITEM ITM, CI_MTR MTR,CI_MTR_CONFIG MCE  ");
		getSPFromSCQuery.append("  WHERE (EQP.REMOVAL_DT IS NULL)  ");
		getSPFromSCQuery.append("  AND EQP.ITEM_ID_EQ = ITM.ITEM_ID ");
		getSPFromSCQuery.append("  AND ITM.ITEM_TYPE_CD = 'ERT'  ");
		getSPFromSCQuery.append("  AND ITM.ITEM_STATUS_FLG = 'A'     ");
		getSPFromSCQuery.append("  AND EQP.MTR_ID = MTR.MTR_ID   ");
		getSPFromSCQuery.append("  AND HIST.MTR_CONFIG_ID=MCE.MTR_CONFIG_ID   ");
		getSPFromSCQuery.append(" AND MCE.MTR_ID = MTR.MTR_ID    ");
		getSPFromSCQuery.append("  AND (MTR.RETIRE_DT IS NULL)    ");
		getSPFromSCQuery.append("  AND MTR.MTR_STATUS_FLG = 'A')   ");
		// end add - dlh B-21850 3-24-22

		/* Bug SD20130523 :FS Changed from "If the Power Status value is "Y" or a non-canceled Field Activity exists for same FA Type, skip the Service Point Processing"
		 * to "	If the Power Status value is "Y" or a non-canceled Field Activity exists for same 'scheduled date as schedule work date' and FA Type, skip the Service Point Processing'
		 *
		 * */
		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement spPrepStmt = createPreparedStatement(getSPFromSCQuery.toString());
		PreparedStatement spPrepStmt = createPreparedStatement(getSPFromSCQuery.toString(), getClass().getName());
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        spPrepStmt.bindId("inputPowerSourceChar", powerSourceChar.getId());
        spPrepStmt.bindId("inputTransAcctChar", transportAccountChar.getId());
        spPrepStmt.bindDateTime("processDateTime", getProcessDateTime());
        spPrepStmt.bindDate("processDate", getProcessDateTime().getDate());
        spPrepStmt.bindEntity("inputFAType",fieldActivityType );
        spPrepStmt.bindLookup("faStatus",FieldActivityStatusLookup.constants.CANCELED );
        /*
         * Start Add - SF-3224783 - 2015-06-04
         */
        spPrepStmt.bindEntity("cisDivision", cisDivision);
        /*
         * End - Add - SF-3224783 - 2015-06-04
         */

        // start add - SA-374433 - EQuint - 2021-07-16
 		if (notBlank(excludeMeterTypeFilter)) {
 			spPrepStmt.bindId("maximoCharType", maximoMeterChar.getId());
 		}
     	// end add - SA-374433 - EQuint - 2021-07-16

        servicePointList = spPrepStmt.list();
        spPrepStmt.close();


	}

	public Class<CmManualMeterReadFACreation_BatchProcessWorker> getThreadWorkerClass() {
		return CmManualMeterReadFACreation_BatchProcessWorker.class;
	}

	public static class CmManualMeterReadFACreation_BatchProcessWorker extends
		  CmManualMeterReadFACreation_BatchProcessWorker_Gen {
		// START add-DarrylH -2018-02-29 SA-241261
		//private static FieldActivityType fieldActivityType;
		private FieldActivityType fieldActivityType;
		// END add-DarrylH -2018-02-29 SA-241261

		/**
		 * This method identifies the execution strategy to be used for the thread.
		 *
		 * @return an instance of ThreadExecutionStrategy that governs how this ThreadWorker will be executed at runtime.
		 * @see com.splwg.base.api.batch.ThreadWorker#createExecutionStrategy()
		 */

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new CommitEveryUnitStrategy(this);
		}

		// START add-DarrylH -2018-02-29 SA-241261
        public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
    		String strInputFAType = getParameters().getFC_FIELD_ACTIVITY_TYPE().value().trim();
     		FeatureConfiguration_Id schemaConstantsId = new FeatureConfiguration_Id(FEATURE_CONFIG_NAME);
    		FeatureConfiguration schemaConstantsFeatureConfig = schemaConstantsId.getEntity();

    		CmFeatureConfigurationRetriever cmFeatureConfigurationRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
    		cmFeatureConfigurationRetriever.setParmWFMName(schemaConstantsFeatureConfig);
    		cmFeatureConfigurationRetriever.setParmOptType(strInputFAType);
    		String strFAType = cmFeatureConfigurationRetriever.getMaxSequenceOptionValue();
    		fieldActivityType =  new FieldActivityType_Id(strFAType).getEntity();
           }
        // END add-DarrylH -2018-02-29 SA-241261
		/**
		 * Execute a WorkUnit and provide result details.
		 *
		 * @param unit - a ThreadWorkUnit
		 * @return a boolean that describes the success or failure of the work unit processing.
		 * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted
		 * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
		 * @see com.splwg.base.api.batch.ThreadWorker#executeWorkUnit(com.splwg.base.api.batch.ThreadWorkUnit)
		 * This work unit creates the Field Activity.
		 */
		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			   ServicePoint_Id spId = (ServicePoint_Id)unit.getPrimaryId();
			   	MeterReadSchedule_Id mreadSchedule = new MeterReadSchedule_Id(spId.getEntity().getMeterReadCycleId(),getProcessDateTime().getDate());
				DateTime schedWorkDate = new DateTime(mreadSchedule.getEntity().getScheduledReadDate(),new Time(0,0,0));

			   FieldActivity_DTO faDto = new FieldActivity_DTO();
			   faDto.setFieldActivityTypeId(fieldActivityType.getId());
			   faDto.setServicePointId(spId);
			   faDto.setScheduleDateTimeStart(schedWorkDate);
			   faDto.setUserId(getActiveContextUser().getId());
			   faDto.setCreationDateTime(getProcessDateTime());
			   faDto.setCreatedBy(FieldActivityCreatedByLookup.constants.BACKGROUND);

			   FieldActivityCreatorData faCreatorData = FieldActivityCreatorData.Factory.newInstance();
			   faCreatorData.setFaDTO(faDto);

			   FieldActivityCreator faCreator = FieldActivityCreator.Factory.newInstance();
			   faCreator.addFieldActivity(faCreatorData);


			return true;
		}

	}

}
