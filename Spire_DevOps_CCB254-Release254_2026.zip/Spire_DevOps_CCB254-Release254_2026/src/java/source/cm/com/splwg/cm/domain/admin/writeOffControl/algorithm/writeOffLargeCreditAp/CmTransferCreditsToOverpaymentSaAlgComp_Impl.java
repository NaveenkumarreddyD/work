/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPLA3PX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      Initial Version.      
 * 2016-05-23   MPang/      Defect 3427607. Added close connection to avoid
 *              SFelip      UniversalPoolConnectionException.
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.       
 * 2025-11-14   EQuint      CCB25.4 Upgrade                     
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.writeOffControl.algorithm.writeOffLargeCreditAp;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.writeOffControl.algorithm.writeOffLargeCreditAp.WriteOffLargeCreditApAlgorithmSpot;
import com.splwg.ccb.domain.admin.writeOffDebtClass.entity.WriteOffDebtClass;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpla3px;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentType, name = syncAdjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = transferAdjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = cisDivision, name = cisDivision, type = entity)
 *            , @AlgorithmSoftParameter (name = saType, required = true, type = string)})
 */
public class CmTransferCreditsToOverpaymentSaAlgComp_Impl extends
		CmTransferCreditsToOverpaymentSaAlgComp_Gen implements
		WriteOffLargeCreditApAlgorithmSpot {

	
	// hard parameters
	private Bool areServiceAgreementClosed;
	private Account account;
	private WriteOffDebtClass writeOffDebtClass;
	private Money writeOffDebtClassTotalBalance;
	
	// soft parameters
	private AdjustmentType syncAdjustmentType;
	private AdjustmentType transferAdjustmentType;
	private CisDivision cisDivision;
	private String saType;
	
	private Cmpla3px cmpla3px;
	
	// Start Add - MPang - Defect 3427607 - 2016-05-23
	private Connection connection;
	// End Add - MPang - Defect 3427607 - 2016-05-23
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	
	@Override
	public Bool getAreServiceAgreementsClosed() {
		return areServiceAgreementClosed;
	}

	@Override
	public void setAccount(Account arg0) {
		account = arg0;
	}

	@Override
	public void setWriteOffDebtClass(WriteOffDebtClass arg0) {
		writeOffDebtClass = arg0;
	}

	@Override
	public void setWriteOffDebtClassTotalBalance(Money arg0) {
		writeOffDebtClassTotalBalance = arg0;
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		syncAdjustmentType = getSyncAdjustmentType();
		transferAdjustmentType = getTransferAdjustmentType();
		cisDivision = getCisDivision();
		saType = getSaType();
	}

	@Override
	public void invoke() {
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			
			if(notNull(account)) {
				cmpla3px.setInputWrkAcctId(account.getId().getTrimmedValue());
			}
			else {
				cmpla3px.setInputWrkAcctId(CobolCode.SPACES.toString());
			}
			
			if(notNull(writeOffDebtClass)) {
				cmpla3px.setInputWrkWoDebtClCd(writeOffDebtClass.getId().getTrimmedValue());
			}
			else {
				cmpla3px.setInputWrkWoDebtClCd(CobolCode.SPACES.toString());
			}
			
			if(notNull(writeOffDebtClassTotalBalance)) {
				cmpla3px.setWoDebtClTotBal(writeOffDebtClassTotalBalance.getAmount().toBigDecimal());
			}
			else {
				cmpla3px.setWoDebtClTotBal(java.math.BigDecimal.ZERO);
			}
			
			
			// soft parameters
			cmpla3px.setAlgParmVal(1, syncAdjustmentType.getId().getTrimmedValue()); 
			cmpla3px.setAlgParmVal(2, transferAdjustmentType.getId().getTrimmedValue()); 
			if(notNull(cisDivision)) {
				cmpla3px.setAlgParmVal(3, cisDivision.getId().getTrimmedValue());
			}
			else {
				cmpla3px.setAlgParmVal(3, CobolCode.SPACES.toString());
			}
			cmpla3px.setAlgParmVal(4, saType); 
			
			// invoke the main method
		    cmpla3px.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmpla3px.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmpla3px.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmpla3px.getMessageParm(i);
			    			if (notBlank(cmpla3px.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmpla3px.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmpla3px.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmpla3px.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmpla3px.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    	areServiceAgreementClosed = (cmpla3px.getSasClosedSw().trim().compareTo(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE;
		    }
		    else {
		        // Start Add - MPang - Defect 3427607 - 2016-05-23
		        ex.printStackTrace();
		        // End Add - MPang - Defect 3427607 - 2016-05-23
		        
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmpla3px=Session.returnSessionAndCodeToCache(cmpla3px);
			
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
            // Start Add - MPang - Defect 3427607 - 2016-05-23
//			try {
//                connection.close();
//            } catch (SQLException e) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
//            }
            // End Add - MPang - Defect 3427607 - 2016-05-23
			// end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}

	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
	    FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
		RequestContext context = session.getRequestContext();
		
		// start update - equint - 2025-11-14 - CCB25.4 Upgrade
  		session.doWork(new ConnectionWork() {
  			
  			@Override
  			public void execute(Connection connection) throws SQLException {
  				try { 
  					String username = connection.getMetaData().getUserName();
  					String url = connection.getMetaData().getURL();
  					
  					CobolSession.setLogSessionStartEnd(false);
  				    cmpla3px=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpla3px.class);
  					
  					cmpla3px.getSession().getDbSession().setUpdateConnection(connection);
  					cmpla3px.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
  					
  					// set ZSTAT parameters

  					cmpla3px.setProcessDt(getProcessDateTime().getDate().toString());
  					cmpla3px.setProcessDttmSep("-");
  					cmpla3px.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
  					
  					if (session.isOnlineConnection()) { 
  						cmpla3px.setConnectionFlg(CONNECTION_ONLINE);
  					}
  					else {
  						cmpla3px.setConnectionFlg(CONNECTION_BATCH);
  					}
  					
  					cmpla3px.setUserId(context.getUserId());
  					cmpla3px.setZstatLanguageCd(context.getLanguageCode());
  			        
  			        if (context.ignoreWarnings()) {
  			        	cmpla3px.setIgnoreWarningSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpla3px.setIgnoreWarningSw(SWITCH_NO);
  			        }
  			        
  			        if (session.getBatchInstanceId() != null) {
  			        	cmpla3px.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
  			        	
  					} else {
  						cmpla3px.setSchedulerId(new BigDecimal(0).toBigDecimal());
  					}
  			        
  			        cmpla3px.setAppSvcId(context.getSecurityServiceIdContext());
  			        
  			        DatabaseHelper dbHelper = session.getDatabaseHelper();
  			        cmpla3px.setDbMode(dbHelper.getCobolDBMode());
  			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
  			        //cmpla3px.setSplHighValue(cmpla3px.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
  			        //cmpla3px.setSplLowValue(cmpla3px.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
  			        
  			        cmpla3px.setSplHighValue(cmpla3px.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
  			        cmpla3px.setSplLowValue(cmpla3px.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
  			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
  			        
  			        cmpla3px.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
  			        
  			        cmpla3px.setLkExpiryDt(Date.MAX.toString());
  			        
  			        cmpla3px.setProgramStatus(" ");
  			        
  			        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
  			        cmpla3px.setCallSeq(";");
  			        cmpla3px.setMessageAreaProgramName("CMPLA3PX");
  			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
  			        
  			        if (context.getRandomGeneratorSeedSet().isTrue()) {
  			        	cmpla3px.setRandomGenSeedSw(SWITCH_YES);
  			        	cmpla3px.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
  			        	cmpla3px.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
  			        	cmpla3px.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
  			        	cmpla3px.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
  			        }
  			        else {
  			        	cmpla3px.setRandomGenSeedSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceStandardOut()) { 
  			        	cmpla3px.setTrcStdoutSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpla3px.setTrcStdoutSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramStart()) { 
  			        	cmpla3px.setTrcProgStartSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpla3px.setTrcProgStartSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramExit()) { 
  			        	cmpla3px.setTrcProgExitSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpla3px.setTrcProgExitSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceSQL()) { 
  			        	cmpla3px.setTrcExecSqlSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpla3px.setTrcExecSqlSw(SWITCH_NO);
  			        }
  			        
  			        // Set ZMSGN parms
  			        BigInteger messageSequence = session.getMessageSequence();
  			        if (notNull(messageSequence)) {
  			        	cmpla3px.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
  			        }
  			        else {
  			        	cmpla3px.setMessageSeq(new BigDecimal(0).toBigDecimal());
  			        }
  				}
  				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		 
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//		// Start Change - MPang - Defect 3427607 - 2016-05-23
//	    //Connection connection = implementor.getConnectionProvider().getConnection();
//		connection = implementor.getConnectionProvider().getConnection();
//	    // End Change - MPang - Defect 3427607 - 2016-05-23
//		
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmpla3px=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpla3px.class);
//		
//		cmpla3px.getSession().getDbSession().setUpdateConnection(connection);
//		cmpla3px.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		
//		// set ZSTAT parameters
//
//		cmpla3px.setProcessDt(getProcessDateTime().getDate().toString());
//		cmpla3px.setProcessDttmSep("-");
//		cmpla3px.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmpla3px.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmpla3px.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmpla3px.setUserId(context.getUserId());
//		cmpla3px.setZstatLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmpla3px.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmpla3px.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmpla3px.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmpla3px.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmpla3px.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmpla3px.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmpla3px.setSplHighValue(cmpla3px.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmpla3px.setSplLowValue(cmpla3px.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmpla3px.setSplHighValue(cmpla3px.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmpla3px.setSplLowValue(cmpla3px.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmpla3px.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmpla3px.setLkExpiryDt(Date.MAX.toString());
//        
//        cmpla3px.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmpla3px.setCallSeq(";");
//        cmpla3px.setMessageAreaProgramName("CMPLA3PX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmpla3px.setRandomGenSeedSw(SWITCH_YES);
//        	cmpla3px.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmpla3px.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmpla3px.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmpla3px.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmpla3px.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmpla3px.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmpla3px.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmpla3px.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmpla3px.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmpla3px.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmpla3px.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmpla3px.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmpla3px.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmpla3px.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmpla3px.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }
  		
  	// end update - equint - 2025-11-14 - CCB25.4 Upgrade

	}

}
