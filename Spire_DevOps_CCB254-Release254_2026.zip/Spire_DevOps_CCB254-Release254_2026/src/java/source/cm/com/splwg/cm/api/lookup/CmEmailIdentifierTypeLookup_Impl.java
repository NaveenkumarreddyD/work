/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Email Identifier Type Lookup
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2012-06-26	Karthik		NU0001. Initial Version.
 **************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author kloganatha001
 *
 @LookupFieldname (value = CM_EMAIL_ID_TYP_FLG)
 */
public class CmEmailIdentifierTypeLookup_Impl extends
		CmEmailIdentifierTypeLookup_Gen {

}
