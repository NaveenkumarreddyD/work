/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Premise Information Extract Record                                                               
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                          
 * 2020-04-01  JHERNA      SA-322461. Initial version                 
 *                                                                
 *******************************************************************************
 */

package com.splwg.cm.api.batch.generalLetters;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmGeneralLetterPremiseInfoExtractRecord extends ColumnDelimitedRecord {
    
    // Mailing Information
    private static final String PREM_PRINT_KEY = "1160";
    private static final String MAIL_GRP = "20";
    private static final String BLANK = "  ";
    private static final String EMPTY_STR = "";
    
    public CmGeneralLetterPremiseInfoExtractRecord() {
        super(26);
        defaultPrintKey();
    }

    /* EXTRACT COMMON SECTIONS */
    private void defaultPrintKey() {
        this.rightPadColumn(1, 4, formatString(PREM_PRINT_KEY, 4));
    }
    
    public void setSortKeyLetterTemplateCode(String letterTemplateCode) {
        this.rightPadColumn(2, 12, formatString(letterTemplateCode, 12));
    }
    
    public void setSortKeyCcId(String ccId) {
        this.rightPadColumn(3, 10, formatString(ccId, 10));
        setSortKeyCcRecordGroup();
        setSortKeyCAndCRecordGroup();
    }
    
    private void setSortKeyCcRecordGroup() {
        this.rightPadColumn(4, 2, MAIL_GRP);
    }
    
    private void setSortKeyCAndCRecordGroup() {
        this.rightPadColumn(5, 2, BLANK);
    }
    
    public void setMailingKey(String mailingKey) {
        this.rightPadColumn(6, 12, formatString(mailingKey, 12));
        setFiller3Spaces();
    }
    
    private void setFiller3Spaces() {
        this.rightPadColumn(7, 3, " ");
    }
    
    /* EXTRACT DETAILS SECTION */    
    public void setFKCharType(String fkCharType) {    	
    	this.rightPadColumn(8, 8, formatString(fkCharType, 8));
    }
          
    public void setCharTypeDescr(String charTypeDescr) {    	
    	this.rightPadColumn(9, 60, formatString(charTypeDescr, 60));
    }  
    
    public void setPremId(String premID) {
    	this.rightPadColumn(10, 10, formatString(premID, 10));    	
    }

    public void setCountry(String country) {
    	this.rightPadColumn(11, 3, formatString(country, 3));    	
    }
    
    public void setAddress1(String address1) {
    	this.rightPadColumn(12, 254, formatString(address1, 254));    	
    }
    
    public void setAddress2(String address2) {
    	this.rightPadColumn(13, 254, formatString(address2, 254));    	
    }
    
    public void setAddress3(String address3) {
    	this.rightPadColumn(14, 254, formatString(address3, 254));    	
    }
    
    public void setAddress4(String address4) {
    	this.rightPadColumn(15, 254, formatString(address4, 254));    	
    }
    
    public void setCity(String city) {
    	this.rightPadColumn(16, 30, formatString(city, 30));    	
    }
    
    public void setNum1(String num1) {
    	this.rightPadColumn(17, 6, formatString(num1, 6));    	
    }
    
    public void setNum2(String num2) {
    	this.rightPadColumn(18, 4, formatString(num2, 4));    	
    }
    
    public void setHouseType(String houseType) {
    	this.rightPadColumn(19, 2, formatString(houseType, 2));    	
    }
    
    public void setCounty(String county) {
    	this.rightPadColumn(20, 30, formatString(county, 30));    	
    }
    
    public void setState(String state) {
    	this.rightPadColumn(21, 6, formatString(state, 6));    	
    }
    
    public void setPostal(String postal) {
    	this.rightPadColumn(22, 12, formatString(postal, 12));    	
    }
    
    public void setGeoCode(String geoCode) {
    	this.rightPadColumn(23, 11, formatString(geoCode, 11));    	
    }
    
    public void setInCityLimit(String isInCityLimit) {
    	this.rightPadColumn(24, 1, formatString(isInCityLimit, 1));    	
    }

    public void setMailToMulti(String isMailToMulti) {
    	this.rightPadColumn(25, 1, formatString(isMailToMulti, 1));  
    	setFillerEndSpaces();
    }
    
    private void setFillerEndSpaces() {
        this.rightPadColumn(26, 767, BLANK);
    }
        
    /**
     * Returns "" if text is null;
     * Truncates text if length exceed fieldLength;
     * @param text String variable to be formatted
     * @param fieldLength Length of Field
     * @return formatted text
     */
    private String formatString(String text, int fieldLength) {
        if(text == null) {
            text = EMPTY_STR;
        }
        else {
            text = text.trim();
            if(text.length() > fieldLength) {
                text = text.substring(0, fieldLength);
            }
        }
        return text;
    }
}
