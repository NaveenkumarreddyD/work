/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 2024-07-30   DLampa     INC0037039. Updated field lengths to match 
 *                         the file layout extracted by the CM-BILEXTR 
 *                         algorithm 
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractDetailsBillCalcLineRecord 
		extends ColumnDelimitedRecord{	
		
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractDetailsBillCalcLineRecord() {
		super(17);
		this.setBPPrinterKey(" ");		
		this.setBPSortKey(" ");
		this.setBPMailingKey(" ");	
		this.setAppInSummSw(" ");
		this.setCalcAmt(BigDecimal.ZERO, "0");
		this.setExemptAmt(BigDecimal.ZERO, "0");
		this.setUomCd(" ");
		this.setTouCd(" ");
		this.setSqiCd(" ");
		this.setBillSq(BigDecimal.ZERO, "0");
		this.setDescrOnBill(" ");
		this.setHeaderCd(" ");
		this.setHeaderFlg(" ");
		this.setFiller();
	}
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * 
	 */
	public void setBPPrinterKey(String value) {		
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
	public void setBPSortKey(String value) {
		rightPadColumn(2, 184, truncateInput(value, 184));
	}
	public void setBPMailingKey(String value) {
		rightPadColumn(3, 15, truncateInput(value, 15));
	}	
	/*
	 * Bill Calc Line (List Item)
	 */
	public void setAppInSummSw(String value) {
		rightPadColumn(4, 1, truncateInput(value, 1));
	}
	public void setCalcAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(5, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(6, 15, truncateInput(value, 15));
	}
	public void setExemptAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(7, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(8, 15, truncateInput(value, 15));
	}
	public void setUomCd(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(9, 4, truncateInput(value, 4));
		rightPadColumn(9, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setTouCd(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(10, 8, truncateInput(value, 8));
		rightPadColumn(10, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setSqiCd(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(11, 8, truncateInput(value, 8));
		rightPadColumn(11, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setBillSq(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(12, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(13, 18, truncateInput(value, 18));
	}
	public void setDescrOnBill(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(14, 80, truncateInput(value, 80));
		rightPadColumn(14, 254, truncateInput(value, 254));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setHeaderCd(String value) {
		rightPadColumn(15, 16, truncateInput(value, 16));
	}
	public void setHeaderFlg(String value) {
		rightPadColumn(16, 1, truncateInput(value, 1));
	}
	public void setFiller() {
		/*For some reason OLD version has this field to be only 3072 characters long; We are going to follow this instead of using base field length of 3275*/
		//rightPadColumn(17, 3275, " ");
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(17, 3072, " ");
		rightPadColumn(17, 2828, " ");
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
}