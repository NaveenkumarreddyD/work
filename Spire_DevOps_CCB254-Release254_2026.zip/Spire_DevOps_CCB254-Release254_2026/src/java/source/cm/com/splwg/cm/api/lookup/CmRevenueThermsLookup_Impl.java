/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Revenue Therms Lookup
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-04-25   JPunza  NI0034.1 Initial Version.
 *************************************************************************/

package com.splwg.cm.api.lookup;

/**
 * @author jpunzalan2
 *
 @LookupFieldname (value = XRVT_OPT_TYP_FLG)
 */
public class CmRevenueThermsLookup_Impl 
        extends CmRevenueThermsLookup_Gen {

}
