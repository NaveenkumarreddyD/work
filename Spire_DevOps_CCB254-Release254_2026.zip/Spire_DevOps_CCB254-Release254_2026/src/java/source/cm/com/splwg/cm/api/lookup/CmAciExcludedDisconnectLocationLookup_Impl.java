/**************************************************************************
* Program Name: CmAciExcludedDisconnectLocationLookup_Impl
* Program Title: CmAciExcludedDisconnectLocationLookup_Impl
* Author: Justine Roxas
* Creation Date: 2017-08-16
* Purpose: This is a lookup extension for XACI_OPT_TYP_FLG.
*  
* Functional Spec: SA-188394.1
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 * SA-188394.1        Justine Roxas    2017-08-16    Initial Version
 ************************************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author JRoxas
 *
@LookupFieldname (value = XACI_OPT_TYP_FLG)
 */
public class CmAciExcludedDisconnectLocationLookup_Impl extends
        CmAciExcludedDisconnectLocationLookup_Gen {

}
