/*
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                
 *    
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * Placement Task and Collection Agency Referral cleanup.
 * 
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:       by:          Reason:
 * YYYY-MM-DD  FLName
 * 2015-12-01  SMiranda     SF-70684. Initial Version. Cleaup for 68113
 * 2016-01-14  SMiranda     SF-70684-001. Closed query iterator
 * 2016-02-18  MPang	 	Updated for CCB v2.4 compilation.
 ***********************************************************************
 */
package com.splwg.cm.domain.batch;

import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControl;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.api.lookup.ReferralStatusLookup;
//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral_DTO;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTask;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTask_Id;*/
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral_DTO;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral_Id;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.api.lookup.ReferralHistoryReasonLookup;

/**
 * @author 90723
 *
 @BatchJob (rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = batchControl, name = BATCH_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = serviceTask, name = F1_SVC_TASK_ID, type = entity)})
 */
public class CmClosePlacementTaskBatch extends
		CmClosePlacementTaskBatch_Gen {

	public JobWork getJobWork() {

		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
		StringBuilder getSTasks = new StringBuilder();
		
		getSTasks.append("SELECT ST.F1_SVC_TASK_ID ");
		getSTasks.append("FROM F1_SVC_TASK ST ");
		if (notNull(getParameters().getF1_SVC_TASK_ID())){
			getSTasks.append("WHERE ST.F1_SVC_TASK_ID = :staskId ");
			getSTasks.append("AND ST.BUS_OBJ_CD = 'CM-CollAgencyPlacement' ");
		}else{
			getSTasks.append("WHERE ST.BUS_OBJ_CD = 'CM-CollAgencyPlacement' ");
		}
		getSTasks.append("AND ST.BO_STATUS_CD = 'ACTIVE' ");
		getSTasks.append("AND EXISTS (SELECT 'X' FROM F1_SVC_TASK_CHAR STC ");
		getSTasks.append("			WHERE STC.F1_SVC_TASK_ID = ST.F1_SVC_TASK_ID ");
		getSTasks.append("			AND STC.CHAR_TYPE_CD = 'C1-SA') ");
		getSTasks.append("AND NOT EXISTS (SELECT 'x' FROM F1_SVC_TASK_CHAR STC, CI_SA SA ");
		getSTasks.append("			WHERE STC.F1_SVC_TASK_ID = ST.F1_SVC_TASK_ID ");
		getSTasks.append("			AND STC.CHAR_TYPE_CD = 'C1-SA' ");
		getSTasks.append("			AND SA.SA_ID = TRIM(STC.SRCH_CHAR_VAL) ");
		getSTasks.append("			AND SA.SA_STATUS_FLG IN ('20','30','40','50')) ");
		
		//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement pstmt =  createPreparedStatement(getSTasks.toString());
		PreparedStatement pstmt =  createPreparedStatement(getSTasks.toString(), getClass().getName());
		//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		if (notNull(getParameters().getF1_SVC_TASK_ID())){
			pstmt.bindId("staskId", getParameters().getF1_SVC_TASK_ID().getId());
		}
		QueryIterator<SQLResultRow> pstmtIter = pstmt.iterate();
		
		while (pstmtIter.hasNext()){
			SQLResultRow row = pstmtIter.next();
			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId((ServiceTask_Id)row.getId("F1_SVC_TASK_ID", ServiceTask.class));
			workUnits.add(workUnit);
		}		

		pstmt.close();
		return createJobWorkForThreadWorkUnitList(workUnits);

	}

	public Class<CmClosePlacementTaskBatchWorker> getThreadWorkerClass() {
		return CmClosePlacementTaskBatchWorker.class;
	}

	public static class CmClosePlacementTaskBatchWorker extends
			CmClosePlacementTaskBatchWorker_Gen {
		
		// Soft parameter
		private BatchControl batchCode;
		
		// Primary Unit
		private ServiceTask_Id staskId;

		public ThreadExecutionStrategy createExecutionStrategy() {
			// TODO Auto-generated method stub
			return new StandardCommitStrategy(this);
		}			

		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {

			batchCode = getParameters().getBATCH_CD();
			
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			// Get pimary Id
			staskId = (ServiceTask_Id)unit.getPrimaryId();
			
			// Get collection agency referral
			StringBuilder getCollAgyRef = new StringBuilder();
			getCollAgyRef.append("SELECT PK_VALUE1 FROM F1_SVC_TASK_REL_OBJ WHERE F1_SVC_TASK_ID = :id AND MAINT_OBJ_CD = 'COLL AGY REF'");
			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//PreparedStatement pstmt =  createPreparedStatement(getCollAgyRef.toString());
			PreparedStatement pstmt =  createPreparedStatement(getCollAgyRef.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			pstmt.bindId("id", staskId);
			
			SQLResultRow collAgyRow = pstmt.firstRow();
			pstmt.close();
			
			// Process CAR
			if(notNull(collAgyRow)){
				CollectionAgencyReferral_Id carId = (CollectionAgencyReferral_Id) collAgyRow.getId("PK_VALUE1", CollectionAgencyReferral.class);
				closeCar(carId);
			}
			
			return true;
		}

		private void closeCar(CollectionAgencyReferral_Id carId) {

			// Close the CAR. This will also close the Placement Task
			CollectionAgencyReferral_DTO carDto = carId.getEntity().getDTO();
			carDto.setReferralStatus(ReferralStatusLookup.constants.CLOSED);
			carId.getEntity().setDTO(carDto);
			
			// Perform additional processing if CAR's most recent history referral amount is geater than zero
			StringBuilder getCollAgyRefHist = new StringBuilder();
			getCollAgyRefHist.append("SELECT SEQ_NUM, CRE_DT, REF_AMT ");
			getCollAgyRefHist.append("FROM CI_COLL_AGY_HIS ");
			getCollAgyRefHist.append("WHERE COLL_AGY_REF_ID = :carId ");
			getCollAgyRefHist.append("ORDER BY SEQ_NUM DESC");
			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//PreparedStatement pstmt =  createPreparedStatement(getCollAgyRefHist.toString());
			PreparedStatement pstmt =  createPreparedStatement(getCollAgyRefHist.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			pstmt.bindId("carId", carId);
			
			SQLResultRow collAgyHistRow = pstmt.firstRow();
			pstmt.close();
						
			// We need to send to DebtNext the FTs that caused the Placement Task to close (except SYSXFR3)
			if (notNull(collAgyHistRow)){
				BigDecimal maxSeqNum = collAgyHistRow.getBigDecimal("SEQ_NUM");
				Date maxCreDt = collAgyHistRow.getDate("CRE_DT");
				BigDecimal maxRefAmount = collAgyHistRow.getBigDecimal("REF_AMT");
				
				if (maxRefAmount.compareTo(BigDecimal.ZERO) == 1){
					
					// Get FTs on or after the most recent history
					StringBuilder getFTs = new StringBuilder();
					getFTs.append("SELECT TRUNC(FT.FREEZE_DTTM) AS FREEZE_DT, FT.FT_TYPE_FLG, SUM(FT.CUR_AMT) AS CUR_AMT ");
					getFTs.append("FROM CI_FT FT ");
					getFTs.append("WHERE FT.SA_ID IN (SELECT TRIM(STC.SRCH_CHAR_VAL) ");
					getFTs.append("					FROM F1_SVC_TASK_CHAR STC ");
					getFTs.append("					WHERE STC.F1_SVC_TASK_ID = :staskId ");
					getFTs.append("					AND STC.CHAR_TYPE_CD = 'C1-SA' ");
					getFTs.append("					AND LENGTH(STC.SRCH_CHAR_VAL) > 10) ");
					getFTs.append("AND TRUNC(FT.FREEZE_DTTM) >= :maxCreDt ");
					getFTs.append("AND FT.FT_TYPE_FLG IN ('PS','AD') ");
					getFTs.append("AND FT.PARENT_ID <> 'SYSXFR3' ");
					getFTs.append("AND FT.CUR_AMT < 0 ");
					getFTs.append("GROUP BY TRUNC(FT.FREEZE_DTTM), FT.FT_TYPE_FLG ");

					//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
					//PreparedStatement ftStmt =  createPreparedStatement(getFTs.toString());
					PreparedStatement ftStmt =  createPreparedStatement(getFTs.toString(), getClass().getName());
					//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
					ftStmt.bindId("staskId", staskId);
					ftStmt.bindDate("maxCreDt", maxCreDt);
					QueryIterator<SQLResultRow> ftRowIter = ftStmt.iterate();
					
					while (ftRowIter.hasNext() && (maxRefAmount.compareTo(BigDecimal.ZERO) == 1)){
						SQLResultRow ftRow = ftRowIter.next();
						// Get History date
						Date refCreDate = ftRow.getDate("FREEZE_DT");
						// Get FT Type Flag
						FinancialTransactionTypeLookup ftTypeLookup = ftRow.getLookup("FT_TYPE_FLG", FinancialTransactionTypeLookup.class);
						// Calculate history referral amount
						maxRefAmount = maxRefAmount.add(ftRow.getBigDecimal("CUR_AMT"));
						if (maxRefAmount.compareTo(BigDecimal.ZERO) == -1){
							maxRefAmount = BigDecimal.ZERO;
						}
						// Calculate Sequence Number
						maxSeqNum = maxSeqNum.add(BigDecimal.ONE);
						
						StringBuilder insertHist = new StringBuilder();
						insertHist.append("INSERT INTO CI_COLL_AGY_HIS ");
						insertHist.append("(COLL_AGY_REF_ID, SEQ_NUM, CRE_DT, REF_AMT, REF_HIST_RSN_FLG, SYS_GEN_SW, TRIGGER_BP_SW, BATCH_CD, BATCH_NBR) ");
						insertHist.append("VALUES ( ");
						insertHist.append(":collAgyRefId, ");
						insertHist.append(":seqNum, ");
						insertHist.append(":creDate, ");
						insertHist.append(":refAmount, ");
						insertHist.append(":refHistRsnFlag, ");
						insertHist.append(":sysGenSw, ");
						insertHist.append(":triggerBpSw, ");
						insertHist.append(":batchCode, ");
						insertHist.append(":batchNbr ");
						insertHist.append(") ");
						
						//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
						//PreparedStatement insertStmt =  createPreparedStatement(insertHist.toString());
						PreparedStatement insertStmt =  createPreparedStatement(insertHist.toString(), getClass().getName());
						//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
						insertStmt.bindId("collAgyRefId", carId);
						insertStmt.bindBigDecimal("seqNum", maxSeqNum);
						insertStmt.bindDate("creDate", refCreDate);
						insertStmt.bindBigDecimal("refAmount", maxRefAmount);
						if (ftTypeLookup.isAdjustment()){
							insertStmt.bindLookup("refHistRsnFlag", ReferralHistoryReasonLookup.constants.CHANGE_REFERRAL);
						}
						if (ftTypeLookup.isPaySegment()){
							insertStmt.bindLookup("refHistRsnFlag", ReferralHistoryReasonLookup.constants.REFERRAL_PAID);
						}
						insertStmt.bindBoolean("sysGenSw", Bool.TRUE);
						insertStmt.bindBoolean("triggerBpSw", Bool.FALSE);
						insertStmt.bindEntity("batchCode", batchCode);
						insertStmt.bindBigInteger("batchNbr", batchCode.getNextBatchNumber());
						insertStmt.execute();
						insertStmt.close();
					}
					
					ftStmt.close();
					// 2016-01-14. SMiran. SF-70684-001. Start Add
					ftRowIter.close();
					// 2016-01-14. SMiran. SF-70684-001. End Add
				}
			}
		}

	}

}
