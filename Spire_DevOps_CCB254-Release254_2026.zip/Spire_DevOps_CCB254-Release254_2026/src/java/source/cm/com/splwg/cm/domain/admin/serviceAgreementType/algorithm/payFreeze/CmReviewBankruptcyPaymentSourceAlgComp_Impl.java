/**************************************************************************
 * Program Name: CmReviewBankruptcyPaymentSourceAlgComp_Impl
 * Program Title: CmReviewBankruptcyPaymentSourceAlgComp_Impl
 * Author: Jamie Lumbre
 * Creation Date: 2019-08-14
 * Purpose: The Algorithm creates a to do when the Payment's tender source
 *          is not equal to the value defined in soft parameter 1.
 *  
 * Functional Spec: B-09127 (SpireOne - Project Two)
 **************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 * B-09127            Jamie Lumbre     2019-08-14    Initial Version
 *                                                                                                                                
 ************************************************************************************************/
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.payFreeze;

import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.payFreeze.SaTypePaymentFreezeAlgorithmSpot;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.ccb.domain.payment.payment.entity.PaymentSegment;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author TMG02631
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = tenderSource, name = tenderSource, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = role, name = toDoRole, type = entity)})
 */
public class CmReviewBankruptcyPaymentSourceAlgComp_Impl extends
CmReviewBankruptcyPaymentSourceAlgComp_Gen implements
SaTypePaymentFreezeAlgorithmSpot {

	//soft parameter
	private TenderSource tenderSourceParm;
	private ToDoType toDoTypeParm;
	private Role roleParm;

	//hard parameters
	private Payment payment;

	@Override
	public void invoke() {

		StringBuilder checkTenderSource = new StringBuilder();
		checkTenderSource.append("SELECT B.TNDR_SOURCE_CD ");
		checkTenderSource.append("FROM CI_PAY_TNDR A, CI_TNDR_CTL B, CI_PAY_EVENT C, CI_PAY D ");
		checkTenderSource.append("WHERE D.PAY_ID =:payId ");
		checkTenderSource.append("AND C.PAY_EVENT_ID = D.PAY_EVENT_ID ");
		checkTenderSource.append("AND A.PAY_EVENT_ID = C.PAY_EVENT_ID ");
		checkTenderSource.append("AND A.TNDR_CTL_ID = B.TNDR_CTL_ID ");


		PreparedStatement checkTenderSourceQuery = createPreparedStatement(checkTenderSource.toString(), 
				getClass().getName());

		checkTenderSourceQuery.setAutoclose(false);
		checkTenderSourceQuery.bindEntity("payId", payment);
		checkTenderSourceQuery.execute();

		if (notNull(checkTenderSourceQuery.firstRow())){
			if (!checkTenderSourceQuery.firstRow().get("TNDR_SOURCE_CD").toString().trim().equals(tenderSourceParm.getExternalSourceId().trim())){
				createToDo();
			}
		}
	}

	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		tenderSourceParm = getTenderSource();
		toDoTypeParm = getToDoType();
		roleParm = getToDoRole();

		if(notNull(roleParm)) {
			ToDoTypeRole_Id toDoTypeRoleId = new ToDoTypeRole_Id(toDoTypeParm, roleParm);
			if(isNull(toDoTypeRoleId.getEntity())) {
				addError(CustomMessageRepository.CCB_CC_23_2_invalidRoleForToDoType(roleParm.getId().getTrimmedValue(), toDoTypeParm.getId().getTrimmedValue()));
			}
		} else {
			roleParm = toDoTypeParm.getDefaultRole().fetchIdToDoRole();
		}

		super.extraSoftParameterValidations(forAlgorithmValidation);
	}

	private void createToDo(){
		ToDoEntry_DTO toDoEntryDto = createDTO(ToDoEntry.class);
		toDoEntryDto.setToDoTypeId(toDoTypeParm.getId());
		toDoEntryDto.setToDoRoleId(roleParm.getId());
		toDoEntryDto.setCreationDateTime(getProcessDateTime());
		toDoEntryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
		toDoEntryDto.setToDoPriority(toDoTypeParm.getToDoPriority());
		toDoEntryDto.setMessageId(toDoTypeParm.getMessageId());

		ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
		toDoCreator.setToDoDTO(toDoEntryDto);

		toDoCreator.addSortKeyValue(toDoTypeParm.getSortKeyTypes().iterator().next(), payment.getId().getTrimmedValue());
		toDoCreator.addDrillKeyValue(toDoTypeParm.getDrillKeyTypes().iterator().next(), payment.getPaymentEvent().getId().getTrimmedValue());

		toDoCreator.create();
	}


	@Override
	public void setFinancialTransaction(FinancialTransaction arg0) {

	}

	@Override
	public void setPayment(Payment arg0) {
		payment = arg0;

	}

	@Override
	public void setPaymentSegment(PaymentSegment arg0) {


	}

	@Override
	public void setServiceAgreement(ServiceAgreement arg0) {

	}

}
