/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Meter Location Update to Maximo 
 * 
 * This algorithm will evaluate the completed field activity, determine
 * whether a meter location change has taken place, and create the outbound
 * staging records when appropriate. The following scenarios will trigger
 * the interface:
 * 
 * Meter installation - all instances
 * Meter removal - all instances
 * Meter exchange - only when the meter being removed has a different Meter
 * Id than the meter being installed.
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2015-06-03   SMiran  MINT-00185. Initial Version.
 * 2016-01-26   MPang	Updated for CCB v2.4 compilation.
 * 2022-06-03	DarrylH B22345-Check for actual meterreadhisID for remove
 * 						install step 
 *************************************************************************/
package com.splwg.cm.domain.admin.fieldActivityType;

import java.math.BigInteger;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.security.user.User;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityStepTypeActionLookup;
import com.splwg.ccb.api.lookup.ServicePointMeterEventTypeLookup;
//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityTypeFaCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityStep;
import com.splwg.ccb.domain.meterread.meter.Meter;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.ServicePointMeterEvent;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.ServicePointMeterHistory_Id;*/

import com.splwg.ccb.domain.admin.fieldActivityType.algorithm.faCompletion.FieldActivityTypeFaCompletionAlgorithmSpot;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityStep;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterEvent;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory_Id;
//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.interfaceStaging.CmMeterLocationOutboundInterfaceStagingMaintenance;

/**
 * @author 90723
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = serviceTaskType, name = meterLocationUpdateServiceTaskType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = user, name = maximoUserId, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = technicianNameFaCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = removalReasonCodeFaCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = meterSiteNumberCharType, required = true, type = entity)})
 */
public class CmMeterLocationUpdateToMaximoAlgComp_Impl 
		extends CmMeterLocationUpdateToMaximoAlgComp_Gen 
		implements FieldActivityTypeFaCompletionAlgorithmSpot {
	// Hard parameters
	private FieldActivity fa = null;
 
	// Soft parameters
	private ServiceTaskType meterLocationUpdateServiceTaskType;
	private User maximoUserId;
	private CharacteristicType technicianNameFaCharType;
	private CharacteristicType removalReasonCodeFaCharType;
	private CharacteristicType siteNumberMeterCharType;
	
	// Work variable
	private BigInteger installLogicalTrxNumber;

	public void setFieldActivity(FieldActivity fa) {
		this.fa = fa;
	}

	public void invoke() {
		
		// If the user is Maximo, end processing
		if (this.getActiveContextUser().equals(maximoUserId)){
			return;
		}		
		
        // Check for Install Meter FA Step Action 
		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        // ListFilter<FieldActivityStep> faStepsFilter = fa.getSteps().createFilter("where this.faStepTypeAction = :installMeterAction");
		ListFilter<FieldActivityStep> faStepsFilter = fa.getSteps().createFilter("where this.faStepTypeAction = :installMeterAction", getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        faStepsFilter.bindLookup("installMeterAction", FieldActivityStepTypeActionLookup.constants.INSTALL_METER);
        FieldActivityStep installMeterfaStep = faStepsFilter.firstRow();

        
        // Check for Remove Meter FA Step Action
        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        // faStepsFilter = fa.getSteps().createFilter("where this.faStepTypeAction = :removeMeterAction");
        faStepsFilter = fa.getSteps().createFilter("where this.faStepTypeAction = :removeMeterAction", getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        faStepsFilter.bindLookup("removeMeterAction", FieldActivityStepTypeActionLookup.constants.REMOVE_METER);
        FieldActivityStep removeMeterfaStep = faStepsFilter.firstRow();

        
        // If only "Install Meter" was completed, create the outbound staging record based on the mapping spreadsheet
        if (notNull(installMeterfaStep) && isNull(removeMeterfaStep)){
        	if (notNull(installMeterfaStep.getSpMeterHistoryId())){     
        		createOutboundRecord(installMeterfaStep.getSpMeterHistoryId(), ServicePointMeterEventTypeLookup.constants.INSTALL, BigInteger.ZERO);
        	}      	       	
         
        }
        // If only "Remove Meter" was complete, create the oubound staging record based on the mapping spreadsheet
        if (isNull(installMeterfaStep) && notNull(removeMeterfaStep)){
        	if (notNull(removeMeterfaStep.getSpMeterHistoryId())){
        		createOutboundRecord(removeMeterfaStep.getSpMeterHistoryId(), ServicePointMeterEventTypeLookup.constants.REMOVAL, BigInteger.ZERO);

        	}        	
        }

        // If both "Install Meter" and "Remove Meter" steps were completed
        if (notNull(installMeterfaStep) && notNull(removeMeterfaStep)){

        	// Retrieve the SP/Meter History Id from the remove and install steps
        	ServicePointMeterHistory_Id removeMeterSpmhId = removeMeterfaStep.getSpMeterHistoryId();
        	ServicePointMeterHistory_Id installMeterSpmhId = installMeterfaStep.getSpMeterHistoryId();
        	if (notNull(removeMeterSpmhId) && notNull(installMeterSpmhId)){
        		// Get meter configuration associated with SP/Meter history
        		MeterConfiguration removeMeterConfig = removeMeterSpmhId.getEntity().getMeterConfiguration();
        		MeterConfiguration installMeterConfig = installMeterSpmhId.getEntity().getMeterConfiguration();
        		// Retrieve Meter Id using meter configuration and compare the Meter Ids
        		if (removeMeterConfig.getMeter().equals(installMeterConfig.getMeter())){
        			// If the Meter Id for the removed and installed meters are the same, end processing.

        			return;
        		}else{

        			createOutboundRecord(removeMeterSpmhId, ServicePointMeterEventTypeLookup.constants.REMOVAL, BigInteger.ZERO);
        			createOutboundRecord(installMeterSpmhId, ServicePointMeterEventTypeLookup.constants.INSTALL, installLogicalTrxNumber);
        		}
              //Start Add -20220603-DarrylH B22345	
        	}else{
        		
                if (isNull(removeMeterSpmhId) && notNull(installMeterSpmhId)){
                		createOutboundRecord(installMeterfaStep.getSpMeterHistoryId(), ServicePointMeterEventTypeLookup.constants.INSTALL, BigInteger.ZERO);
                }
        		
                if (notNull(removeMeterSpmhId) && isNull(installMeterSpmhId)){
                		createOutboundRecord(removeMeterfaStep.getSpMeterHistoryId(), ServicePointMeterEventTypeLookup.constants.REMOVAL, BigInteger.ZERO);
                }
        	}               	
            //End Add -20220603-DarrylH B22345	
        }
	}

	
	private void createOutboundRecord(ServicePointMeterHistory_Id spMhId, ServicePointMeterEventTypeLookup eventType, BigInteger logicaTrxNumber) {
		
		CmMeterLocationOutboundInterfaceStagingMaintenance meterLocOutboundMaint 
				= CmMeterLocationOutboundInterfaceStagingMaintenance.Factory.newInstance();
		
		// Set Logical Transaction Number
		meterLocOutboundMaint.setLogicalTransactionNumber(logicaTrxNumber);
		
		// Set Service Task Type
		meterLocOutboundMaint.setServiceTaskType(meterLocationUpdateServiceTaskType);
		
		// Get Meter from SP Meter History via Meter Configuration
		Meter meter = spMhId.getEntity().getMeterConfiguration().getMeter();
		
		// Get site number from meterCharacteristic
		String siteId = getMeterChar(meter, siteNumberMeterCharType);
		
		// Raise error message if Meter does not have Site Id
		if (isEmptyOrNull(siteId)){
			addError(CustomMessageRepositoryMGE.mint00185_mtrSiteIdCharMiss(this.getAlgorithm().getId().getTrimmedValue()
					, meter.getId().getTrimmedValue()));
		}
		
		// Set siteId
		meterLocOutboundMaint.setSiteId(siteId);
		
		// Set badgeNumber
		meterLocOutboundMaint.setBadgeNumber(meter.getBadgeNumber());
		
		// Set serialNumber
		meterLocOutboundMaint.setSerialNumber(meter.getSerialNumber());			
		
		// Set faId
		meterLocOutboundMaint.setFaId(fa.getId());
		
		// If meter was removed
		if (eventType.isRemoval()){
			
			// Set SP ID
			meterLocOutboundMaint.setSpId(null);
			
			// Get Technician Name from FA Characteristic
			String techName = getFaCharacteristicValue(technicianNameFaCharType);
			
			// Set Technician Name
			meterLocOutboundMaint.setTechName(techName);
			
			// Set Removal Date Time
			DateTime removalDateTime = spMhId.getEntity().getRemovalDateTime();
			meterLocOutboundMaint.setRemovalDateTime(removalDateTime);
			
			// Set Removal Reason Code
			String removalReasonCode = getFaCharacteristicValue(removalReasonCodeFaCharType);
			meterLocOutboundMaint.setRemoveReasonCode(removalReasonCode);
		}
		
		// If meter was installed
		if (eventType.isInstall()){
			
			// Set SP Id
			meterLocOutboundMaint.setSpId(fa.getServicePoint().getId());
			
			// Get the SP Meter Event for Install
			//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
			// ListFilter<ServicePointMeterEvent> spMeterEventFilter 
			// 		= spMhId.getEntity().getServicePointMeterEvents().createFilter("where this.spMeterEventType = :eventType");
			ListFilter<ServicePointMeterEvent> spMeterEventFilter 
			= spMhId.getEntity().getServicePointMeterEvents().createFilter("where this.spMeterEventType = :eventType", getClass().getName());
			//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
			
			spMeterEventFilter.bindLookup("eventType", ServicePointMeterEventTypeLookup.constants.INSTALL);
			ServicePointMeterEvent installEvent = spMeterEventFilter.firstRow();		
			
			// Set Install Date Time
			meterLocOutboundMaint.setInstallDateTime(installEvent.getMeterRead().getReadDateTime());
			
			// Set Technician Name
			meterLocOutboundMaint.setTechName("");
			
			// Set Removal Date Time
			meterLocOutboundMaint.setRemovalDateTime(null);
			
			// Set Removal Reason Code
			meterLocOutboundMaint.setRemoveReasonCode("");
		}
		
		// Set SP Meter History Id
		meterLocOutboundMaint.setSpMtrHistId(spMhId);					
		
		// Create outbound staging record
		meterLocOutboundMaint.createMeterLocationUpdateStagingRecords();
		
		// Store the Logical Transaction Number locally (Remove and Install on an Exchange FA will use the same logical transaction number)
		installLogicalTrxNumber = meterLocOutboundMaint.getLogicalTransactionNumber();
	}
	
	/**
	 * This method retrieves the Meter characteristic value of the given characteristic type. 
	 * @param meter
	 * @param charType
	 * @return
	 */
	private String getMeterChar(Meter meter, CharacteristicType charType) {

		MeterCharacteristic meterChar = meter.getEffectiveCharacteristic(charType);
		
		if (notNull(meterChar)){
			
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			
			if (charTypeLookup.isPredefinedValue()){
				return meterChar.getCharacteristicValue().trim();
			}else if (charTypeLookup.isForeignKeyValue()){
				return meterChar.getCharacteristicValueForeignKey1().trim();
			}else {
				return meterChar.getAdhocCharacteristicValue().trim();
			}
		}
		
		return "";
	}

	/**
     * This method retrieves the FA characteristic value of the given characteristic type.
     * @param characteristicType
     * @return String
     */
    private String getFaCharacteristicValue(CharacteristicType characteristicType) {    	

        // Retrieve FA Characteristic with the highest sequence
    	//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        // ListFilter<FieldActivityCharacteristic> charFilter = fa.getCharacteristics()
        // 		.createFilter("where this.id.characteristicType = :charType order by this.id.sequence desc");
        
        ListFilter<FieldActivityCharacteristic> charFilter = fa.getCharacteristics()
        		.createFilter("where this.id.characteristicType = :charType order by this.id.sequence desc", getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        charFilter.bindEntity("charType", characteristicType);
        
        FieldActivityCharacteristic faCharacteristic = charFilter.firstRow();
                
        if (notNull(faCharacteristic)) {
        
            CharacteristicTypeLookup charTypeLookup = characteristicType.getCharacteristicType();
            
            if (charTypeLookup.isPredefinedValue()) {
                return faCharacteristic.getCharacteristicValue().trim();
            }else if (charTypeLookup.isForeignKeyValue()) {
                return faCharacteristic.getCharacteristicValueForeignKey1().trim();
            }else {            
                return faCharacteristic.getAdhocCharacteristicValue().trim();
            }
        }
        
        return "";
    }

	@Override
	protected void extraSoftParameterValidations(boolean arg0) {
		
		// Meter Location Update Service Task Type
		meterLocationUpdateServiceTaskType = this.getMeterLocationUpdateServiceTaskType();
		
		// Get Maximo User Id
		maximoUserId = this.getMaximoUserId();
		
		// Get Technician Name FA Char Type
		technicianNameFaCharType = this.getTechnicianNameFaCharType();
		
		// Technician Name FA Char Type must be valid for FA entity
		validateCharTypeForEntity(technicianNameFaCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY
				,"Technician Name FA Char Type");
		
		// Get Meter Removal Reason FA Char Type
		removalReasonCodeFaCharType = this.getRemovalReasonCodeFaCharType();
		
		// Removal Reason Code FA Char Type must be valid for FA entity
		validateCharTypeForEntity(removalReasonCodeFaCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY
				,"Removal Reason FA Char Type");		
		
		// Get Meter Site Number Meter Char Type
		siteNumberMeterCharType = this.getMeterSiteNumberCharType();
		
		// Meter Site Number Char Type must be valid for Meter entity
		validateCharTypeForEntity(siteNumberMeterCharType, CharacteristicEntityLookup.constants.METER
				,"Meter Site Number Char Type");
		
	}
	
	/**
	 * Validate if characteristic type is valid for given entity
	 * @param charType
	 * @param charEntity
	 * @param parmDescr
	 */
	private void validateCharTypeForEntity(CharacteristicType charType, CharacteristicEntityLookup charEntity, String parmDescr) {
		
		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType,charEntity);
		if (isNull(charEntityId.getEntity())){
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharTypeNotValidForEntity(
					this.getAlgorithm().getId().getTrimmedValue()
					,parmDescr
					,charType.getId().getTrimmedValue()
					,charEntity.getLookupValue().fetchLanguageDescription()));
		}
		
	}
	
	

}
