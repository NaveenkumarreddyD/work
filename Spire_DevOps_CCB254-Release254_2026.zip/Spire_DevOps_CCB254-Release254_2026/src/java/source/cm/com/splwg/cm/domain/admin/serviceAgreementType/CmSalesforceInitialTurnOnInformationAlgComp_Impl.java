/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * SalesForce Interface - Initial Turn On Information
 * 
 * This new service agreement activation algorithm will be developed to
 * trigger the CC&B to SalesForce transmission of the initial turn on 
 * information for the premises with opportunity IDs. At the time a 
 * service agreement is activated, if the SA meets the conditions defined
 * in the processing rules, outbound staging data will be populated.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-08-04   JHERNA      Initial Version. Post v2.4 upgrade.
 * 2018-08-16	MPang		SA-251520B. Added a new criteria to cater
 * 							SalesForce requirements.
 * 2018-09-24   SMiranda    The move in date must be set to SA Start Date
 * 2018-12-17   SRoman		Merged the changes from Spire PRD version for 
 *  						the 2.4 to 2.6 Upgrade Activity.
 * 2021-06-17   FRoig       B-19000. Add source system for CIS Divisions 
 * 							Alabama and Gulf.
 * *************************************************************************                
 */
package com.splwg.cm.domain.admin.serviceAgreementType;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.algorithmType.AlgorithmTypeParameter_Id;
import com.splwg.base.domain.common.algorithmType.AlgorithmTypeParameter_LanguageId;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.BillMessageTypeLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saActivation.SaTypeSaActivationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountMessage_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountMessage_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountMessages;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.cm.api.lookup.CmInterfaceStatusLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = interfaceName, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = sourceSystemLGC, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = sourceSystemMGE, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = targetSystem, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = charTypeOpportunityId, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = charTypeCiacStartDate, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = charTypeCiacBillingStatus, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = ciacBillingStatus, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = accountBillMessage, type = entity)
 *            , @AlgorithmSoftParameter (name = sourceSystemAla, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = sourceSystemGulf, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = sourceSystemMs, required = true, type = string)})
 */
public class CmSalesforceInitialTurnOnInformationAlgComp_Impl 
		extends CmSalesforceInitialTurnOnInformationAlgComp_Gen 
		implements SaTypeSaActivationAlgorithmSpot {

	// Hard Parameter
	private static ServiceAgreement hpServiceAgreement;
	
	// Soft Parameter 
	private static CharacteristicType parmCharTypeOpportunity;
	private static String parmInterfaceName;
	private static String parmSourceSystemLGC;
	private static String parmSourceSystemMGE;
	private static String parmTargetSystem;
    /*
     * SA-251520B - 2018-08-16 - Start Add
     */
	private static CharacteristicType parmCharTypeCiacStartDate;
	private static CharacteristicType parmCharTypeCiacBillingStatus;
	private static String parmCiacBillingStatus;
	private static BillMessageType parmAccountBillMessage;
    /*
     * SA-251520B - 2018-08-16 - End Add
     */
	/*
	 * B-19000 - 2021-06-17 - Start Add
	 */
	private static String parmSourceSystemAla;
	private static String parmSourceSystemGulf;
	private static String parmSourceSystemMs;	/*
	 * B-19000 - 2021-06-17 - End Add
	 */

	// Variables
	private List<ServicePoint_Id> collOfServicePoints = new ArrayList<ServicePoint_Id>();
	private List<Premise_Id> collOfPremises = new ArrayList<Premise_Id>();
    /*
     * SA-251520B - 2018-08-16 - Start Add
     */
	private static final String DATE_STRING = "yyyy-MM-dd";
	private final DateFormat DATE_FORMAT_yyyy_MM_dd = new DateFormat("yyyy-MM-dd");
    /*
     * SA-251520B - 2018-08-16 - End Add
     */

	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
	
		// Retrieve Algorithm Parameter 10: Interface Name
		parmInterfaceName = this.getInterfaceName();
		// Retrieve Algorithm Parameter 20: Source System LGC
		parmSourceSystemLGC = this.getSourceSystemLGC();
		// Retrieve Algorithm Parameter 30: Source System MGE
		parmSourceSystemMGE = this.getSourceSystemMGE();
		// Retrieve Algorithm Parameter 40: Target System
		parmTargetSystem = this.getTargetSystem();
		// Retrieve Algorithm Parameter 50: Characteristic Type Opportunity ID
		parmCharTypeOpportunity = this.getCharTypeOpportunityId();
	    /*
	     * SA-251520B - 2018-08-16 - Start Add
	     */
		// Retrieve Algorithm Parameter 60: Characteristic Type CIAC Start Date
		parmCharTypeCiacStartDate = this.getCharTypeCiacStartDate();
		// Retrieve Algorithm Parameter 70: Characteristic Type CIAC Billing Status
		parmCharTypeCiacBillingStatus = this.getCharTypeCiacBillingStatus();
		// Retrieve Algorithm Parameter 80: Characteristic Value CIAC Billing Status
		parmCiacBillingStatus = this.getCiacBillingStatus();
		// Retrieve Algorithm Parameter 90: Bill Message
		parmAccountBillMessage = this.getAccountBillMessage();
	    /*
	     * SA-251520B - 2018-08-16 - End Add
	     */
		/*
		 * B-19000 - 2021-06-17 - Start Add
		 */
		parmSourceSystemAla = this.getSourceSystemAla();
		parmSourceSystemGulf = this.getSourceSystemGulf();
		parmSourceSystemMs = this.getSourceSystemMs();
		/*
		 * B-19000 - 2021-06-17 - End Add
		 */

		// Validate that the characteristic type is valid for the premise entity
		CharacteristicEntity_Id charEntityID = new CharacteristicEntity_Id(parmCharTypeOpportunity, CharacteristicEntityLookup.constants.PREMISE);
		if (isNull(charEntityID.getEntity())) {
		    /*
		     * SA-251520B - 2018-08-16 - Start Change
		     */
			//addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharTypeNotValidForEntity(this.getAlgorithmId().getTrimmedValue(), 
			//		this.getCharTypeOpportunityId().fetchLanguageDescription().trim(),
			//		parmCharTypeOpportunity.getId().getTrimmedValue(),
			//		"Premise"));
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharTypeNotValidForEntity(this.getAlgorithmId().getTrimmedValue(), 
					getAlgorithmParameterName(50),
					parmCharTypeOpportunity.getId().getTrimmedValue(),
					"Premise"));
		    /*
		     * SA-251520B - 2018-08-16 - End Change
		     */
		}
	    /*
	     * SA-251520B - 2018-08-16 - Start Add
	     */
		
		// Validate that the characteristic type CIAC Start Date is valid for the premise entity
		CharacteristicEntity_Id ciacStartDatecharEntityID = new CharacteristicEntity_Id(parmCharTypeCiacStartDate, CharacteristicEntityLookup.constants.PREMISE);
		if (isNull(ciacStartDatecharEntityID.getEntity())) {
			
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharTypeNotValidForEntity(this.getAlgorithmId().getTrimmedValue(), 
					getAlgorithmParameterName(60),
					parmCharTypeCiacStartDate.getId().getTrimmedValue(),
					"Premise"));
		}
		
		// Validate that the characteristic type CIAC Billing Status is valid for the premise entity
		CharacteristicEntity_Id ciacBillingStatuscharEntityID = new CharacteristicEntity_Id(parmCharTypeCiacBillingStatus, CharacteristicEntityLookup.constants.PREMISE);
		if (isNull(ciacBillingStatuscharEntityID.getEntity())) {
			
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharTypeNotValidForEntity(this.getAlgorithmId().getTrimmedValue(), 
					getAlgorithmParameterName(70),
					parmCharTypeCiacBillingStatus.getId().getTrimmedValue(),
					"Premise"));
		}
		
		// Validate that the characteristic value CIAC Billing Status is valid characteristic value for CIAC Billing Status Characteristic Type
        CharacteristicValue_Id ciacBillingStatusCharValue = new CharacteristicValue_Id(parmCharTypeCiacBillingStatus, parmCiacBillingStatus); 
        if(isNull(ciacBillingStatusCharValue.getEntity())){
            addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharValueNotValidForCharType(this.getAlgorithmId().getTrimmedValue(), 
            		getAlgorithmParameterName(80), 
            		parmCiacBillingStatus.trim(), 
            		parmCharTypeCiacBillingStatus.getId().getTrimmedValue()));
        }
		
	    /*
	     * SA-251520B - 2018-08-16 - End Add
	     */
	}

	@Override
	public void invoke() {
		// Retrieve SP(s) linked to SA
		cmRetrieveSPslinkedToSA();
		
		// For each service point linked to the SA, check if this SA is the first none cancelled / billable Service Agreement.
		for (int x = 0; x < collOfServicePoints.size(); x++) {
			
			ServicePoint_Id spID = collOfServicePoints.get(x);
			Bool shouldProceed = cmCheckIfSABeingActivatedIsFirstForSP(spID);
			
			// store all unique premises on a collection
			if (shouldProceed.isTrue()) {
				Premise_Id premID = spID.getEntity().getPremise().getId();
				if (!collOfPremises.contains(premID)) {
					collOfPremises.add(premID);
				}
			}						
		}
		
		// Check if Premise contains an "Opportunity ID" characteristic, if so create outbound staging
		cmProcessPremises();
	}

	@Override
	public void setServiceAgreement(ServiceAgreement sa) {

		hpServiceAgreement = sa;
	}	
	
	private void cmRetrieveSPslinkedToSA() {
		
		StringBuilder stringBuilder = new StringBuilder();				
		stringBuilder.append("SELECT UNIQUE(SP_ID) SPID "); 
		stringBuilder.append("FROM CI_SA_SP "); 
		stringBuilder.append("WHERE SA_ID = :saID "); 
		stringBuilder.append("AND STOP_DTTM IS NULL ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=GET SP LINKED TO SA=");
		prepState.bindId("saID", hpServiceAgreement.getId());
		prepState.execute();
		
		if (prepState.list().size() > 0) {
			
			Iterator<SQLResultRow> iter = prepState.list().iterator();
			
			while (iter.hasNext()) {
				SQLResultRow sqlRow = (SQLResultRow) iter.next();
				ServicePoint_Id spID = (ServicePoint_Id) sqlRow.getId("SPID", ServicePoint.class);
				collOfServicePoints.add(spID);				
			}
		}				
		prepState.close();		
	}
	
	private Bool cmCheckIfSABeingActivatedIsFirstForSP(ServicePoint_Id spID) {
		
		Bool returnValue = Bool.TRUE;
		StringBuilder stringBuilder = new StringBuilder(); 

		stringBuilder.append("SELECT UNIQUE(SASP.SA_ID) ");
		stringBuilder.append("FROM CI_SA_SP SASP, CI_SA SA ");
		stringBuilder.append("WHERE SASP.SP_ID = :spID ");
		stringBuilder.append("AND SASP.SA_ID != :saID ");
		stringBuilder.append("AND SASP.STOP_DTTM IS NULL ");
		stringBuilder.append("AND SA.SA_ID = SASP.SA_ID ");
		stringBuilder.append("AND SA.SA_STATUS_FLG < '60' ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), 
				"=CHECK IF SA BEING ACTIVATED IS FIRST FOR SP=");
		prepState.bindId("spID", spID);
		prepState.bindId("saID", hpServiceAgreement.getId());
		prepState.execute();
		
		if (prepState.list().size() > 0) {
			returnValue = Bool.FALSE;
		}		
		prepState.close();
		return returnValue;		
	}
	
	private void cmProcessPremises() {
	    /*
	     * SA-251520B - 2018-08-16 - Start Add
	     */
		String ciacStartDateCharValue = "";
		Date ciachStartDate = null;
		Premise_Id parentPremiseId = null;
		
	    /*
	     * SA-251520B - 2018-08-16 - End Add
	     */
		
		// Check if premise has opportunity characteristic
		for (int x = 0; x < collOfPremises.size(); x++) {
			
			Premise premise = collOfPremises.get(x).getEntity();
			
			PremiseCharacteristic premChar = premise.getEffectiveCharacteristic(parmCharTypeOpportunity);
			
			// Retrieve Opportunity ID value
			if (notNull(premChar)) {
				CharacteristicTypeLookup charTypeValueType = parmCharTypeOpportunity.getCharacteristicType();
				String opportunityID = "";
				
				if (charTypeValueType.isAdhocValue()
						|| charTypeValueType.isFileLocationValue()) {
					opportunityID = premChar.getAdhocCharacteristicValue().trim();
					
				}
				else if (charTypeValueType.isPredefinedValue()) {
					opportunityID = premChar.getCharacteristicValue().trim();
					
				}
				else {
					opportunityID = premChar.getCharacteristicValueForeignKey1().trim();					
				}
				
				/*
				 * B-19000 - 2021-06-17 - Start Change
				 */
				String sourceSystemToUse = parmSourceSystemLGC;
				if (premise.getDivisionId().getTrimmedValue().compareTo("MGE") == 0) {
					sourceSystemToUse = parmSourceSystemMGE;
				} else if (premise.getDivisionId().getTrimmedValue().compareTo("LGC") == 0) {
					sourceSystemToUse = parmSourceSystemLGC;
				} else if (premise.getDivisionId().getTrimmedValue().compareTo("200") == 0) {
					sourceSystemToUse = parmSourceSystemAla;
				} else if (premise.getDivisionId().getTrimmedValue().compareTo("203") == 0) {
					sourceSystemToUse = parmSourceSystemGulf;
				} else if (premise.getDivisionId().getTrimmedValue().compareTo("205") == 0) {
					sourceSystemToUse = parmSourceSystemMs;
				}
				/*
				 * B-19000 - 2021-06-17 - End Change
				 */
				
			    /*
			     * SA-251520B - 2018-08-16 - Start Add
			     */

				//Retrieve the Parent Premise
				parentPremiseId = premise.getParentPremiseId();
				if(notNull(parentPremiseId)) {
					// Retrieve the CIAC Start Date Characteristic Type in the Parent Premise
					PremiseCharacteristic ciacStartDatePremChar = parentPremiseId.getEntity().getEffectiveCharacteristic(parmCharTypeCiacStartDate);
					//Retrieve the CIAC Billing Status Characteristic Type in the Parent Premise
					PremiseCharacteristic ciacBillingStatusPremChar = parentPremiseId.getEntity().getEffectiveCharacteristic(parmCharTypeCiacBillingStatus);
					// If the CIAC Start Date Characteristic Type is retrieved.
					if(notNull(ciacStartDatePremChar)) {
						// Retrieve the CIAC Start Date characteristic value
						ciacStartDateCharValue = retrieveCharacteristicValue(parmCharTypeCiacStartDate, ciacStartDatePremChar);
						try {
							ciachStartDate= Date.fromString(ciacStartDateCharValue, DATE_FORMAT_yyyy_MM_dd);
						} catch(DateFormatParseException e) {
							addError(CustomMessageRepositoryMGE.dateFormatInvalid(ciachStartDate.toString()));
						}
					
						//If the SA Start Date is earlier than the CIAC Start Date Characteristic Value 
						if(hpServiceAgreement.getStartDate().isBefore(ciachStartDate)) {
							//Update the characteristic value of Parent Premise Id
							updatePremiseCharacteristic(ciacStartDatePremChar, parmCharTypeCiacStartDate, 
									hpServiceAgreement.getStartDate().toString(new DateFormat(DATE_STRING)));

							//Check if the Parent Premise has the CIAC Billing Status
							checkCiacBillingStatus(parentPremiseId, ciacBillingStatusPremChar);
						}

						// Else CIAC Start Date is NOT retrieved
					} else {
						//Add the CIAC Start Date Characteristic Type to Premise.
						addPremiseCharacteristic(parentPremiseId, getProcessDateTime().getDate(), 
								parmCharTypeCiacStartDate, hpServiceAgreement.getStartDate().toString(new DateFormat(DATE_STRING)));
						//Check if the Parent Premise has the CIAC Billing Status
						checkCiacBillingStatus(parentPremiseId, ciacBillingStatusPremChar);
					}
					//If Parameter Account Bill Message is present
					if(notNull(parmAccountBillMessage)) {
						//Retrieve the bill message in account.
						AccountMessage_Id acctMessageID = new AccountMessage_Id(parmAccountBillMessage, hpServiceAgreement.getAccount());
						//If bill message in account is not provided.
						if (isNull(acctMessageID.getEntity())) {
							// Add the Account Bill Message 
							AccountMessages acctMessages = hpServiceAgreement.getAccount().getMessages();
							AccountMessage_DTO acctMessageDTO = acctMessages.newChildDTO();
							acctMessageDTO.setBillMessageType(BillMessageTypeLookup.constants.TEMPORARY);
							acctMessages.add(acctMessageDTO, parmAccountBillMessage.getId());
						}
					}	// End if Parameter Account Bill Message is NOT null
				} //End if Parent premise is NOT null
			    /*
			     * SA-251520B - 2018-08-16 - End Add
			     */
				// Create Interface Outbound Staging record
				BigInteger stagingKey = cmCreateInterfaceOutboundStagingRecord(premise.getId().getTrimmedValue(),
						parmInterfaceName.trim(), sourceSystemToUse.trim(), parmTargetSystem.trim());
				// Create Interface Turn On Outbound staging record
				cmCreateTurnOnOutboundStagingRecord(stagingKey, opportunityID, premise);

			}
		}
	}

    /*
     * SA-251520B - 2018-08-16 - Start Add
     */
	/**
	 * Checks the CIAC Billing Status in the Premise Characteristic
	 * @param parentPremise
	 * @param ciacBillingStatusPremChar
	 */
	private void checkCiacBillingStatus(Premise_Id parentPremiseId,
			PremiseCharacteristic ciacBillingStatusPremChar) {
		
		String ciacBillingStatusCharValue;
		
		//If CIAC Billing Status Characteristic Type is retrieved
		if(notNull(ciacBillingStatusPremChar)) {
			ciacBillingStatusCharValue = retrieveCharacteristicValue(parmCharTypeCiacBillingStatus, ciacBillingStatusPremChar);
			//Check if the existing CIAC Billing Status Characteristic Value is equal to Parameter CIAC Billing Status Characteristic Value.
			if(!ciacBillingStatusCharValue.trim().equalsIgnoreCase(parmCiacBillingStatus.trim())) {
				//Update the Premise Characteristic CIAC Characteristic Value 
				updatePremiseCharacteristic(ciacBillingStatusPremChar, parmCharTypeCiacBillingStatus, parmCiacBillingStatus);
			}
		// Else CIAC Billing Status Characteristic Type is NOT retrieved
		} else {
			//Add the CIAC Billing Status Characteristic Type to Premise Characteristic
			addPremiseCharacteristic(parentPremiseId, getProcessDateTime().getDate(), 
					parmCharTypeCiacBillingStatus, parmCiacBillingStatus.trim());
		}
	}	
	
	/**
	 * Retrieve the Characteristic Value
	 * @param characteristicType
	 * @param premChar
	 * @return charValue - Characteristic Value
	 */
	private String retrieveCharacteristicValue(CharacteristicType characteristicType, PremiseCharacteristic premChar) {
		String charValue = "";
		
		if(characteristicType.getCharacteristicType().isPredefinedValue()) {
			charValue = premChar.getCharacteristicValue();
		} else if(characteristicType.getCharacteristicType().isForeignKeyValue()) {
			charValue = premChar.getCharacteristicValueForeignKey1();
		} else {
			charValue = premChar.getAdhocCharacteristicValue();
	    }
		return charValue;
	}
	

	/**
	 * Add Premise Characteristic
	 * @param premise
	 * @param effectiveDate
	 * @param charType
	 * @param value
	 * @return Premise Characteristic
	 */
	private  PremiseCharacteristic addPremiseCharacteristic(Premise_Id premiseId, Date effectiveDate, CharacteristicType charType, String value) {
        PremiseCharacteristic_DTO charDto = premiseId.getEntity().getCharacteristics().newChildDTO();
        if (charType.getCharacteristicType().isForeignKeyValue()) {
            charDto.setCharacteristicValueForeignKey1(value);
        } else if (charType.getCharacteristicType().isPredefinedValue()) {
            charDto.setCharacteristicValue(value);
        } else {
            charDto.setAdhocCharacteristicValue(value);
        }
        return premiseId.getEntity().getCharacteristics().add(charDto, charType.getId(), effectiveDate);
    }
	
	/**
	 * Update Premise Characteristic
	 * @param premChar
	 * @param charType
	 * @param charVal
	 */
    private void updatePremiseCharacteristic(PremiseCharacteristic premChar, CharacteristicType charType, String charVal) {
        PremiseCharacteristic_DTO premCharDto = premChar.getDTO();
        if(charType.getCharacteristicType().isPredefinedValue()) {
            premCharDto.setCharacteristicValue(charVal);
        }
        else if(charType.getCharacteristicType().isForeignKeyValue()) {
            premCharDto.setCharacteristicValueForeignKey1(charVal);
        }
        else {
            premCharDto.setAdhocCharacteristicValue(charVal);
        }
        
        premChar.setDTO(premCharDto);        
    }
	
    /*
     * SA-251520B - 2018-08-16 - End Add
     */
    
	// Create record on XXL_INT_OUTBOUND_STG
    private BigInteger cmCreateInterfaceOutboundStagingRecord(String originatingKey, String interfaceName, String sourceSystem, String targetSystem) {
    	
    	// Retrieve Logical Transaction Number to be used
    	BigInteger logicalTrxNbr = cmGetNextValOfDBSequence("XXL_INT_TURNON_OUT_SEQ");
    	// Retrieve Staging Key to be used
    	BigInteger stagingKey = cmGetNextValOfDBSequence("XXL_INT_OUTBOUND_SEQ");    	
    	
    	StringBuilder insertString = new StringBuilder();
        insertString.append("INSERT INTO                    ");
        insertString.append("    XXL_INT_OUTBOUND_STG       ");
        insertString.append("    (                          ");
        insertString.append("    STAGING_KEY,               ");
        insertString.append("    LOGICAL_TRX_NUMBER,        ");
        insertString.append("    INTERFACE_NAME,            ");
        insertString.append("    STATUS_FLAG,               ");
        insertString.append("    ORIGINATING_KEY,           ");
        insertString.append("    CREATION_DATETIME,         ");
        insertString.append("    UPDATE_DATETIME,           ");
        insertString.append("    SOURCE_SYSTEM_NAME,        ");
        insertString.append("    TARGET_SYSTEM_NAME         ");
        insertString.append("    )                          ");
        insertString.append("VALUES                         ");
        insertString.append("    (                          ");
        insertString.append("    :stagingKey,               ");
        insertString.append("    :logicalTransactionNumber, ");
        insertString.append("    :interfaceName,            ");
        insertString.append("    :status,                   ");
        insertString.append("    :originatingKey,           ");
        insertString.append("    :creationDateTime,         ");
        insertString.append("    :updateDateTime,           ");
        insertString.append("    :sourceSystemName,         ");
        insertString.append("    :targetSystemName          ");
        insertString.append("    )                          ");

        PreparedStatement insertSQL = createPreparedStatement(insertString.toString(), "=CREATE INTERFACE OUTBOUND STAGING RECORD=");
        insertSQL.bindBigInteger("stagingKey", stagingKey);
        insertSQL.bindBigInteger("logicalTransactionNumber", logicalTrxNbr);
        insertSQL.bindString("interfaceName", interfaceName.trim(), "INTERFACE_NAME");      
        insertSQL.bindString("status", CmInterfaceStatusLookup.constants.NEW.trimmedValue(), "STATUS_FLAG");
        insertSQL.bindString("originatingKey", originatingKey.trim(), "ORIGINATING_KEY");
        insertSQL.bindDateTime("creationDateTime", this.getProcessDateTime());
        insertSQL.bindDateTime("updateDateTime", null);
        insertSQL.bindString("sourceSystemName", sourceSystem.trim(), "SOURCE_SYSTEM_NAME");
        insertSQL.bindString("targetSystemName", targetSystem.trim(), "TARGET_SYSTEM_NAME");        
        insertSQL.execute();
        insertSQL.close();
        
        return stagingKey;
    }
    // Get the next sequence to use
    private BigInteger cmGetNextValOfDBSequence(String dbSequence) {
    	
    	BigInteger returnValue = BigInteger.ZERO;
    	StringBuilder stringBuilder = new StringBuilder();
    	stringBuilder.append("SELECT "+dbSequence+".NEXTVAL  ");
    	stringBuilder.append("FROM DUAL ");
    	PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=GET NEXT VALUE FROM DB SEQUENCE "+dbSequence.trim()+"=");
    	prepState.execute();
    	returnValue = prepState.firstRow().getInteger("NEXTVAL");
    	prepState.close();
    	
    	return returnValue;
    }
    // Retrieve the matching Logical Transaction Number of the Staging from the XXL_INT_OUTBOUND_STG table 
    private BigInteger cmRetrieveLogicalTrxNbr(BigInteger stagingKey) {
    	
    	BigInteger returnValue = BigInteger.ZERO;
    	
    	StringBuilder stringBuilder = new StringBuilder();
    	stringBuilder.append("SELECT LOGICAL_TRX_NUMBER ");
    	stringBuilder.append("FROM XXL_INT_OUTBOUND_STG ");
    	stringBuilder.append("WHERE STAGING_KEY = :stagingKey ");
    	PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=RETRIEVE LOGICAL_TRX_NUMBER TO USE=");
    	prepState.bindBigInteger("stagingKey", stagingKey);
    	prepState.execute();
    	returnValue = prepState.firstRow().getInteger("LOGICAL_TRX_NUMBER");
    	prepState.close();
    	return returnValue;    		
    }
    // Create record on XXL_INT_TURNON_OUT_STG table
    private void cmCreateTurnOnOutboundStagingRecord(BigInteger stagingKey, String opptyID, Premise prem) {
    	
    	String add2 = prem.getAddress2();
    	if (isBlankOrNull(add2)) {
    		add2 = " ";
    	}
    	
    	BigInteger logicalTrxNbr = cmRetrieveLogicalTrxNbr(stagingKey);
    	
    	StringBuilder stringBuilder = new StringBuilder();
    	    	
    	stringBuilder.append("INSERT INTO ");
    	stringBuilder.append("  XXL_INT_TURNON_OUT_STG ");
    	stringBuilder.append("  ( ");
    	stringBuilder.append("  LOGICAL_TRX_NUMBER, "); 
    	stringBuilder.append("  TRANSEQ, "); 
    	stringBuilder.append("  MS_TURNON_KEY, "); 
    	stringBuilder.append("  OPPTY_ID, "); 
    	stringBuilder.append("  PREMISE_ID, "); 
    	stringBuilder.append("  MOVE_IN_DATE, "); 
    	stringBuilder.append("  ADDRESS1, "); 
    	stringBuilder.append("  ADDRESS2, "); 
    	stringBuilder.append("  CITY, "); 
    	stringBuilder.append("  STATE, "); 
    	stringBuilder.append("  POSTAL ");   
    	stringBuilder.append("  ) ");
    	stringBuilder.append("VALUES ");
    	stringBuilder.append("  ( ");
    	stringBuilder.append("  :logicalTrxNbr , "); 
    	stringBuilder.append("  :tranSeq , "); 
    	stringBuilder.append("  :msTurnOnKey , "); 
    	stringBuilder.append("  :opptyID , "); 
    	stringBuilder.append("  :premID , "); 
    	stringBuilder.append("  :moveInDate , "); 
    	stringBuilder.append("  :address1 , ");     	
    	stringBuilder.append("  '"+add2+"' , "); 
    	stringBuilder.append("  :city , "); 
    	// Manually put the state because of issue with system padding it with spaces which makes it 6 bytes (field only allows 2 bytes)
    	//stringBuilder.append("  :state , "); 
    	stringBuilder.append("  '"+prem.getState().trim()+"' , ");
    	stringBuilder.append("  :postal ");    	
    	stringBuilder.append("  ) ");

    	PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=CREATE TURN ON OUTBOUND STAGING RECORD=");
    	prepState.bindBigInteger("logicalTrxNbr", logicalTrxNbr);
    	prepState.bindBigInteger("tranSeq", BigInteger.ONE);
    	prepState.bindBigInteger("msTurnOnKey", BigInteger.ZERO);
    	prepState.bindString("opptyID", opptyID.trim(), "OPPTY_ID");
    	prepState.bindString("premID", prem.getId().getTrimmedValue(), "PREM_ID");
        // SMiran - 2018-09-24 - Start Change
    	//prepState.bindDate("moveInDate", this.getProcessDateTime().getDate());
    	prepState.bindDate("moveInDate", hpServiceAgreement.getStartDate());
        // SMiran - 2018-09-24 - End Change
    	prepState.bindString("address1", prem.getAddress1().trim(), "ADDRESS1");    
    	prepState.bindString("city", prem.getCity().trim(), "CITY");
    	//prepState.bindString("state", prem.getState().trim(), "STATE");    	
    	prepState.bindString("postal", prem.getPostal().trim(), "POSTAL");
    	prepState.execute();
    	prepState.close();

    }
    /*
     * SA-251520B - 2018-08-16 - Start Add
     */
    /**
     * Get Algorithm Parameter
     * @param numSeq
     * @return paramName - Algorithm Parameter Name
     */
    private String getAlgorithmParameterName(int numSeq){

        String paramName = "";      
        AlgorithmTypeParameter_Id algorithmTypeParameterId = new AlgorithmTypeParameter_Id(this.getAlgorithm().getAlgorithmType(), BigInteger.valueOf(numSeq));        
        AlgorithmTypeParameter_LanguageId algorithmTypeParameterLanguageId = new AlgorithmTypeParameter_LanguageId(algorithmTypeParameterId, 
                                                                                                                            getActiveContextLanguage().getId());       
        paramName = algorithmTypeParameterLanguageId.getParent().fetchLanguageParameterLabel();
        
        return paramName;
    }
    /*
     * SA-251520B - 2018-08-16 - End Add
     */
}
