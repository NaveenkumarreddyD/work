/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Letter Extract Record                                                               
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                          
 * 2019-12-27  JVitug      SA-315895. Initial version                    
 *                                                                
 *******************************************************************************
 */

package com.splwg.cm.api.batch;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmInvoiceRecord extends ColumnDelimitedRecord {
    // Letter Record
    private static final String INVOICE_RECORD_PRINT_KEY = "2000";
    private static final String LETTER_RECORD_GRP = "60";
    private static final String BLANK = "  ";
    private static final String EMPTY_STR = "";
    
    public CmInvoiceRecord() {
        super(39);  
        defaultPrintKey();
    }
    
    private void defaultPrintKey() {
        this.rightPadColumn(1, 4, formatString(INVOICE_RECORD_PRINT_KEY, 4));
    }
    
    public void setSortKeyLetterTemplateCode(String letterTemplateCode) {
        this.rightPadColumn(2, 12, formatString(letterTemplateCode, 12));
    }
    
    public void setSortKeyCcId(String ccId) {
        this.rightPadColumn(3, 10, formatString(ccId, 10));
        setSortKeyCcRecordGroup();
        setSortKeyCAndCRecordGroup();
    }
    
    private void setSortKeyCcRecordGroup() {
        this.rightPadColumn(4, 2, LETTER_RECORD_GRP);
    }
    
    private void setSortKeyCAndCRecordGroup() {
        this.rightPadColumn(5, 2, BLANK);
    }
    
    public void setMailingKey(String mailingKey) {
        this.rightPadColumn(6, 12, formatString(mailingKey, 12));
        setFiller3Spaces();
    }
    
    private void setFiller3Spaces() {
        this.rightPadColumn(7, 3, " ");
    }
    
    public void setBillId(String billId) {
        this.rightPadColumn(8, 12, formatString(billId, 12));
    }
    
    public void setAccountId(String accountId) {
        this.rightPadColumn(9, 10, formatString(accountId, 10));
    }
    
    public void setBillDate(String billDate) {
        this.rightPadColumn(10, 10, formatString(billDate, 10));
    }
    
    public void setDueDate(String dueDate) {
        this.rightPadColumn(11, 10, formatString(dueDate, 10));
    }
    
    public void setServiceDate(String serviceDate) {
        this.rightPadColumn(12, 10, formatString(serviceDate, 10));
    }
    
    public void setCurrentBalance(BigDecimal currentBalance) {
        this.rightPadColumn(13, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(currentBalance));
    }
    
    public void setCurrentChargeAmount(BigDecimal currentChargeAmount) {
        this.rightPadColumn(14, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(currentChargeAmount));
    }
    
    public void setCurrentCorrAmount(BigDecimal currCorrAmount) {
        this.rightPadColumn(15, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(currCorrAmount));
    }
   
    public void setCurrentAdjustmentAmount(BigDecimal adjCurrentAmount) {
    	this.rightPadColumn(16, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(adjCurrentAmount));
    }
    
    public void setCurrentPayAmount(BigDecimal payCurrentAmount) {
    	this.rightPadColumn(17, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(payCurrentAmount));
    }
    
    public void setCurrentPreviousBalance(BigDecimal currentPreviousBalance) {
    	this.rightPadColumn(18, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(currentPreviousBalance));
    }
    
    public void setTotalBalance(BigDecimal totalBalance) {
    	this.rightPadColumn(19, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(totalBalance));
    }
    
    public void setTotalChargeAmount(BigDecimal totalCharge) {
    	this.rightPadColumn(20, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(totalCharge));
    }
    
    public void setTotalCorrAmount(BigDecimal totalCorrAmount) {
    	this.rightPadColumn(21, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(totalCorrAmount));
    }
    
    public void setTotalAdjAmount(BigDecimal totalAdjAmount) {
    	this.rightPadColumn(22, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(totalAdjAmount));
    }
    
    public void setTotalPayAmount(BigDecimal totalPayAmount) {
    	this.rightPadColumn(23, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(totalPayAmount));
    }
    
    public void setTotalPreviousBalance(BigDecimal totalPrevBalance) {
    	this.rightPadColumn(24, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(totalPrevBalance));
    }
    
    public void setCurrencyCode(String currencyCode) {
        this.rightPadColumn(25, 3, formatString(currencyCode, 3));
    }
    
    public void setDelinquentAmount(BigDecimal delinquentAmount) {
    	this.rightPadColumn(26, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(delinquentAmount));
    }
    
    public void setCustomerPOId(String customerPOId) {
        this.rightPadColumn(27, 20, formatString(customerPOId, 20));
    }
    
    public void setAccountEntityName(String accountEntityName) {
        this.rightPadColumn(28, 64, formatString(accountEntityName, 64));
    }
    
    public void setEntityName(String entityName) {
        this.rightPadColumn(29, 64, formatString(entityName, 64));
    }
    
    public void setAddressSbr(String country,
					    		String addressLine1,
					    		String addressLine2,
					    		String addressLine3,
					    		String addressLine4,
					    		String city        ,
					    		String num1        ,
					    		String num2        ,
					    		String houseType   ,
					    		String county      ,
					    		String state       ,
					    		String postal      ,
					    		String geoCode     ,
					    		String inCityLimit ) {
    	this.rightPadColumn(30, 361, formatString(
    			padRightString(country , 3) +
				padRightString(addressLine1 , 64) +
				padRightString(addressLine2 , 64) +
				padRightString(addressLine3 , 64) +
				padRightString(addressLine4 , 64) +
				padRightString(city , 30) + 
				padRightString(num1 , 6) + 
				padRightString(num2 , 6) + 
				padRightString(houseType, 2) + 
				padRightString(county , 28) + 
				padRightString(state , 6 ) + 
				padRightString(postal , 12) + 
				padRightString(geoCode , 11) + 
				padRightString(inCityLimit , 1)
		, 361));
    }
    
    public void setFinalBillSwitch(String finalBillSwitch) {
        this.rightPadColumn(31, 1, formatString(finalBillSwitch, 1));
    }
    
    public void setScheduledExtractDate(String scheduledExtractDate) {
        this.rightPadColumn(32, 10, formatString(scheduledExtractDate, 10));
    }
    
    public void setEntityName1(String entityName1) {
        this.rightPadColumn(33, 64, formatString(entityName1, 64));
    }
    
    public void setEntityName2(String entityName2) {
        this.rightPadColumn(34, 64, formatString(entityName2, 64));
    }
    
    public void setEntityName3(String entityName3) {
        this.rightPadColumn(35, 64, formatString(entityName3, 64));
    }
    
    public void setAccountCurrencySymbol(String accountCurrencySymbol) {
    	this.rightPadColumn(36, 4, formatString(accountCurrencySymbol, 4));
    }
    
    public void setTotalLatePaymentCharge(BigDecimal lpcAmount) {
    	this.rightPadColumn(37, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(lpcAmount));
    }
    
    public void setRemitToFlag(String remitToFlag) {
    	this.rightPadColumn(38, 16, formatString(remitToFlag, 16));
    }
    
    public void setCheckDigit(String checkDigit) {
    	this.rightPadColumn(39, 1, formatString(checkDigit, 1));
    }
    
    /**
     * Returns "" if text is null;
     * Truncates text if length exceed fieldLength;
     * @param text String variable to be formatted
     * @param fieldLength Length of Field
     * @return formatted text
     */
    private String formatString(String text, int fieldLength) {
        if(text == null) {
            text = EMPTY_STR;
        }
        else {
            text = text.trim();
            if(text.length() > fieldLength) {
                text = text.substring(0, fieldLength);
            }
        }
        return text;
    }
    
    private String padRightString(String text , int fieldLength){
    	String padBuffer = "";
    	for (int i = 0 ; i < (fieldLength - text.length()) ; i++) {
    		padBuffer = padBuffer + " ";
    	}
    	
    	return text.concat(padBuffer);
    }
}
