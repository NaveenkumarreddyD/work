/* ************************************************************************
 *                Confidentiality Information:
 *
 * This module is the confidential and proprietary information of
 * Oracle Corporation; it is not to be copied, reproduced, or
 * transmitted in any form, by any means, in whole or in part,
 * nor is it to be used for any purpose other than that for which
 * it is expressly provided without the written permission of
 * Oracle Corporation.
 *
 *
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * Field Activity Type Override
 *
 * This will check if the FA Type 
 * should be overridden.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:        Reason:
 * YYYY-MM-DD   IN         Reason text.
 *
 * 2013-04-20   CVB        Initial version.
 * 2013-05-14   CVB        Add Meter Removal Reason Characteristic
 * 2014-04-21	Rahul	   IM-045515 Changed query to check open meter exception cases
 * 2014-04-23	Rahul	   IM-047162 Added code to check systematic meter and failed sample characteristic values
 * 2016-01-26   MPang	   Updated for CCB v2.4 compilation.
 * 2018-08-09	Bhaskar	   SA-249344 - Changed query to check the latest the systematic and failed meter sample characteristic values. CCB v2.6 Upgrade 12/12/2018
 * 2020-06-12   FRoig      Defect 4436383. For Click FAs, create a Sync Request after updating ACIs into Meter Exchanges.
 * 2020-08-01   FRoig      Defect 4456684. Roll back changes for 4436383.
 ***************************************************************************/

package com.splwg.cm.domain.admin.maintenanceObject;

import java.math.BigInteger;
import java.util.Iterator;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.Query;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.EntityId;
import com.splwg.base.api.datatypes.Lookup;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.program.standard.StandardRecords;
import com.splwg.base.api.service.PageBody;
import com.splwg.base.api.service.PageHeader;
import com.splwg.base.api.service.ServiceDispatcher;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObject;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObjectAuditAlgorithmSpot;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObject_Id;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.program.types.RecordFactory;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityPriorityLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.FieldActivityStepTypeActionLookup;
import com.splwg.ccb.api.lookup.StepUpdateEntityLookup;
//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseType;
import com.splwg.ccb.domain.admin.caseType.CaseType_Id;
import com.splwg.ccb.domain.admin.dispatchGroup.DispatchGroup;
import com.splwg.ccb.domain.admin.dispatchGroup.DispatchGroup_Id;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityStepType;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityTypeCharacteristicType;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityTypeCharacteristicTypes;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityTypeFieldActivityStepTypes;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.operationalArea.OperationalArea;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePointOperationArea;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePointOperationArea_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_Id;
import com.splwg.ccb.domain.meterread.meter.Meter;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic_DTO;
import com.splwg.ccb.domain.meterread.meter.Meter_Id;*/
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType_Id;
import com.splwg.ccb.domain.admin.data.RecordCICODGDX;
import com.splwg.ccb.domain.admin.dispatchGroup.entity.DispatchGroup;
import com.splwg.ccb.domain.admin.dispatchGroup.entity.DispatchGroup_Id;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityStepType;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityTypeCharacteristicType;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityTypeCharacteristicTypes;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityTypeFieldActivityStepTypes;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.fieldServiceControl.algorithm.driver.ProgramCIPODGDX;
import com.splwg.ccb.domain.admin.operationalArea.entity.OperationalArea;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointOperationArea;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointOperationArea_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.api.lookup.WfmOptionTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmCreateSyncRequest;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.cm.domain.fieldOrder.fieldActivity.CobolCopybookCMCODGDX;
import com.splwg.cm.domain.fieldOrder.fieldActivity.CobolProgramCMPODGDX;*/
//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation

/**
 * @author cborbon001
 *
 @AlgorithmComponent ()
 */
public class CmFieldActivityOverrideAlgComp_Impl extends CmFieldActivityOverrideAlgComp_Gen
implements MaintenanceObjectAuditAlgorithmSpot {

    private MaintenanceObject mo;
    private EntityId entityId;

    private FeatureConfiguration featureConfiguration;
    private Bool caseTypeExists = Bool.TRUE;
    // CVB - 2013-05-14 - Start
    private Bool systematicCharExists = Bool.FALSE;
    private Bool failedSamplingCharExists = Bool.FALSE;
    private Bool meteringExceptionCaseExists = Bool.FALSE;
    // CVB - 2013-05-14 - End

    /* 2014-04-23	Rahul	   IM-047162	Start */
    private String systematicCharVal = "N";
    private String failedSamplingCharVal = "N";
    /* 2014-04-23	Rahul	   IM-047162	End */
    
    /* 2020-08-01   FRoig       Defect 4456684  Start */
    /* 2020-06-12	FRoig		Defect 4436383	Start */
    //private static final String CLICK_DISP_GRP_CD = "CLICK";
    //private static final String NT_DWN_TY_COND_CHANGE ="FACH";
    /* 2020-06-12	FRoig		Defect 4436383	End */
    /* 2020-08-01   FRoig		Defect 4456684	End */
    
    public void setEntityId(EntityId arg0) {
        entityId = arg0;

    }

    public void setMaintenanceObject(MaintenanceObject arg0) {
        mo = arg0;

    }

    public void invoke() {

        MaintenanceObject_Id faMaintenanceObjectId = new MaintenanceObject_Id("FA");
        MaintenanceObject faMaintenanceObject = faMaintenanceObjectId.getEntity();

        if (notNull(faMaintenanceObject)){
            if (mo.equals(faMaintenanceObject)) {

                Bool shouldOverrideFA = Bool.FALSE;

                FieldActivity_Id faId = new FieldActivity_Id(entityId.getOrderedPKFieldValues().get(0).toString());
                FieldActivity fa = faId.getEntity();
                if (notNull(fa)){

                    shouldOverrideFA = determineIfFAWillOverride(fa);

                }
                if (shouldOverrideFA.isTrue()){
                	//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
                    // ListFilter<FeatureConfigurationOption> featConfigOptionFilter = featureConfiguration.getOptions().createFilter("WHERE this.id.optionType = :optionType");
                    ListFilter<FeatureConfigurationOption> featConfigOptionFilter = featureConfiguration.getOptions().
                    		createFilter("WHERE this.id.optionType = :optionType", getClass().getName());
                    //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
                    featConfigOptionFilter.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, WfmOptionTypeLookup.constants.MTR_EXCHANGE_FA_TYPE.trimmedValue());

                    FeatureConfigurationOption featConfigOption = featConfigOptionFilter.firstRow();
                    String meterExchangeFaTypeStr = featConfigOption.getValue().trim();
                    FieldActivityType_Id meterExchangeFaTypeId = new FieldActivityType_Id(meterExchangeFaTypeStr);

                    FieldActivityType faType = meterExchangeFaTypeId.getEntity();

                    // Update Field Activity

                    DispatchGroup_Id dispatchGroupId = null;
                    String dispatchGroupStr = "";

                    if (faType.getIsEligibleForDispatch().isTrue()) {
                        // Retrieve the Dispatch Group.
                        ServicePointOperationArea_Id spOperationId = new ServicePointOperationArea_Id(fa.getServicePoint(),faType.getFieldServiceClass());
                        ServicePointOperationArea spOperationArea = spOperationId.getEntity();



                        if (notNull(spOperationArea)) {
                            OperationalArea opArea = spOperationArea.getOperationsArea();

                            /*
                             * Start Change - 2.5 Upgrade - EQuint - 12-02-2016 
                             */
                         // Create Records
                            RecordCICODGDX recordCICODGDX = RecordFactory.getFactory(RecordCICODGDX.class).newInstance();
                            recordCICODGDX.refInputWrk().refSpTypeCd().setValue(fa.getServicePoint().getSpType().getId().getTrimmedValue());
                            recordCICODGDX.refInputWrk().refFaTypeCd().setValue(meterExchangeFaTypeStr);
                            recordCICODGDX.refInputWrk().refOpAreaCd().setValue(opArea.getId().getTrimmedValue());
                            
                            StandardRecords standardRecords = new StandardRecords();
                            
                            ProgramCIPODGDX.invoke(standardRecords, recordCICODGDX);
                            
                            dispatchGroupId =  new DispatchGroup_Id(recordCICODGDX.refOutputWrk().refDispGrpCd().getRightTrimmedStringValue());
                            
//                            CobolProgramCMPODGDX cobolCMPODGDX = (CobolProgramCMPODGDX) getDynamicComponent(CobolProgramCMPODGDX.class);
//                            //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
//                            //CobolCopybookCMCODGDX odgdx = cobolCMPODGDX.getCobolCopybookCMCODGDX();
//                            CobolCopybookCICODGDX odgdx = cobolCMPODGDX.getCobolCopybookCICODGDX();
//                            //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
//                            odgdx.get_INPUT_WRK().set_SP_TYPE_CD(fa.getServicePoint().getSpType().getId().getTrimmedValue());
//                            odgdx.get_INPUT_WRK().set_FA_TYPE_CD(meterExchangeFaTypeStr);
//                            odgdx.get_INPUT_WRK().set_OP_AREA_CD(opArea.getId().getTrimmedValue());
//                            cobolCMPODGDX.callCobol();
//
//                            dispatchGroupId =  new DispatchGroup_Id(odgdx.get_OUTPUT_WRK().get_DISP_GRP_CD());
                            
                            /*
                             * End Change - 2.5 Upgrade - EQuint - 12-02-2016 
                             */
                        }
                    }
                    if (notNull(dispatchGroupId)){
                        dispatchGroupStr = dispatchGroupId.getTrimmedValue();
                    }

                    updateFieldActivity(fa.getId(),meterExchangeFaTypeId,faType.getFieldActivityPriority(),faType.getIsEligibleForDispatch(),dispatchGroupStr);

                    // Delete FA Steps
                    deleteOldFieldActivitySteps(fa.getId());

                    // Insert New FA Steps

                    insertNewFASteps(fa,faType);

                    // Delete FA Characteristics

                    deleteOldFieldActivityCharacteristics(fa.getId());

                    // Insert New FA Characteristics

                    insertNewFAChars(fa,faType);

                    // CVB - 2013-05-14 - Start
                    // Insert Meter Removal Reason Characteristic

                    insertRemovalReasonFAChar(fa);
                    // CVB - 2013-05-14 - End
                    
                    /* 2020-08-01	FRoig		Defect 4456684	Start */
                    /* 2020-06-12	FRoig		Defect 4436383	Start */
                    //if (!dispatchGroupStr.isEmpty() && CLICK_DISP_GRP_CD.equalsIgnoreCase(dispatchGroupStr)) {
                    //	
                    //    // We need to force a commit, so that the sync request creation process can see the updates on this FA.
            		//	PreparedStatement commit = createPreparedStatement("COMMIT", getClass().getName());
            		//	commit.execute();
            		//	commit.close();

                    //	// Flush session to refresh the FA after updating with PreparedStatements.
            		//	FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
                    //	session.flush(session.toString().trim());
                    //	session.clear(session.toString().trim());

                    //	createSyncRequest(fa, NT_DWN_TY_COND_CHANGE, CLICK_DISP_GRP_CD);
                    //}
                    /* 2020-06-12	FRoig		Defect 4436383	End */
                    /* 2020-08-01	FRoig		Defect 4456684	End */
                }
            }
        }
    }
    
    private Bool determineIfFAWillOverride(FieldActivity fa){

        Bool overrideFAType = Bool.FALSE;

        // Check that this is for Add action

        PageHeader pageHeader = new PageHeader();
        pageHeader.put("FA_ID", fa.getId().getIdValue());

        PageBody pageBody = new PageBody();
        pageBody = ServiceDispatcher.readItem("CMLONFAP", pageHeader, SessionHolder.getSession().getRequestContext(),false);

        Boolean faIsBeingCreated = (Boolean) pageBody.get("CREATE_SW");

        if (!faIsBeingCreated){
            return overrideFAType;
        }

        // Override only Pending FAs

        if (!fa.getFieldActivityStatus().isPending()){
            return overrideFAType;
        }

        // Retrieve the feature configuration from the FA's Dispatch Group

        DispatchGroup_Id dispGrpId = fa.getDispatchGroupId();

        if (isNull(dispGrpId)) {
            return overrideFAType;
        }

        DispatchGroup dispatchGroup = dispGrpId.getEntity();
        if (isNull(dispatchGroup)) {
            addError(CustomMessageRepositoryMDC.ni00091FAInvalidDispatchGroup(fa.getId().getTrimmedValue(), dispGrpId.getTrimmedValue()));
        }

        featureConfiguration = dispatchGroup.fetchWorkforceManagementSystem();

        if(isNull(featureConfiguration)) {
            return overrideFAType;
        }

        // Check if FA was created by an external system
        if(cmCheckExternalSystem(fa).isTrue()) {
            return overrideFAType;
        }

        // Validate the feature configuration options and check if FA Type is "ACI Inspection"
        if(cmValidateFeatureConfigurationOptions().isTrue() && 
                cmCheckValue(fa.getFieldActivityType().getId().getIdValue(), WfmOptionTypeLookup.constants.ACI_INSPECTION_FA_TYPE).isTrue()) {

            ServicePoint sp = fa.getServicePoint();
            Meter meter = cmGetMeterFromServicePoint(sp);

            // If there is no Systematic Meter, Failed Meter Sample and no active Metering Exception Case, exit processing
            // CVB - 2013-05-14 - Start
            /*            if (notNull(meter)){
                systematicCharExists = cmRetrieveMeterCharacteristic(meter.getId(), WfmOptionTypeLookup.constants.SYSTEMATIC_MTR_EXCHANGE_CHAR_TYPE);
                failedSamplingCharExists = cmRetrieveMeterCharacteristic(meter.getId(), WfmOptionTypeLookup.constants.FAILED_SAMPLE_MTR_EXCHANGE_CHAR_TYPE);
            }

            if(isNull(meter) || (systematicCharExists.isFalse() && failedSamplingCharExists.isFalse())) {

                if(caseTypeExists.isFalse()) {
                    return overrideFAType;
                } else {
                    meteringExceptionCaseExists = cmDoesMeteringExceptionCaseExist(WfmOptionTypeLookup.constants.METERING_EXCEPTION_CASE_TYPE, sp.getPremise().getId());
                    if (meteringExceptionCaseExists.isFalse()){     */
            // CVB - 2013-05-14 - End


            /* 2014-04-23	Rahul	   IM-047162	Start */
            if (notNull(meter)){

                systematicCharExists = cmRetrieveMeterCharacteristic(meter.getId(), WfmOptionTypeLookup.constants.SYSTEMATIC_MTR_EXCHANGE_CHAR_TYPE);
                if(systematicCharExists.isTrue()){
                    systematicCharVal = cmRetrieveMeterCharacteristicValue(meter.getId(), WfmOptionTypeLookup.constants.SYSTEMATIC_MTR_EXCHANGE_CHAR_TYPE);
                }

                failedSamplingCharExists = cmRetrieveMeterCharacteristic(meter.getId(), WfmOptionTypeLookup.constants.FAILED_SAMPLE_MTR_EXCHANGE_CHAR_TYPE);
                if(failedSamplingCharExists.isTrue()){
                    failedSamplingCharVal = cmRetrieveMeterCharacteristicValue(meter.getId(), WfmOptionTypeLookup.constants.FAILED_SAMPLE_MTR_EXCHANGE_CHAR_TYPE);
                }
            }

            if(isNull(meter) || (systematicCharVal.trim().equalsIgnoreCase("N") && failedSamplingCharVal.trim().equalsIgnoreCase("N"))) {

                if(caseTypeExists.isFalse()) {
                    return overrideFAType;
                } else {
                    meteringExceptionCaseExists = cmDoesMeteringExceptionCaseExist(WfmOptionTypeLookup.constants.METERING_EXCEPTION_CASE_TYPE, sp.getPremise().getId());
                    if (meteringExceptionCaseExists.isFalse()){
                        /* 2014-04-23	Rahul	   IM-047162	End */
                        return overrideFAType;
                    }
                }
            }

            // Check if a Pending Meter Exchange Field Activity already exist for the Current SP
            if(cmDoesMeterExchangeFaExist(sp).isTrue()) {
                return overrideFAType;
            }

            overrideFAType = Bool.TRUE;
        }
        
        return overrideFAType;

    }

    private Bool cmCheckExternalSystem(FieldActivity fa) {

        if(isBlankOrNull(fa.getIntermediateStatus())) {
            return Bool.FALSE;
        }

        return cmCheckValue(fa.getIntermediateStatus().trim(), WfmOptionTypeLookup.constants.STATUS_TO_SKIP_MESSAGE);
    }
    /*
     * This method will check the value against the feature configuration options
     */
    private Bool cmCheckValue(String value, WfmOptionTypeLookup optionTypeLookup) {

        Bool isFound = Bool.FALSE;

        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder.append("FROM FeatureConfigurationOption optionValues ");
        queryBuilder.append("WHERE optionValues.id.workforceManagementSystem.id = :featureConfigurationId ");
        queryBuilder.append("AND optionValues.id.optionType = :optionType ");
        queryBuilder.append("AND TRIM(optionValues.value) = TRIM(:searchValue) ");

        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //Query faQuery = createQuery(queryBuilder.toString());
        Query faQuery = createQuery(queryBuilder.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        faQuery.bindStringProperty("searchValue", FeatureConfigurationOption.properties.value, value);
        faQuery.bindId("featureConfigurationId", featureConfiguration.getId());
        faQuery.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, optionTypeLookup.value());

        if(faQuery.list().size() > 0) {
            isFound = Bool.TRUE;
        }

        return isFound;
    }

    /*
     * This method will validate the Feature Configuration Options retrieved
     */
    private Bool cmValidateFeatureConfigurationOptions() {

        if(cmValidateFaTypes(WfmOptionTypeLookup.constants.ACI_INSPECTION_FA_TYPE, Bool.TRUE).isFalse()) {
            return Bool.FALSE;
        }
        if(cmValidateFaTypes(WfmOptionTypeLookup.constants.MTR_EXCHANGE_FA_TYPE, Bool.FALSE).isFalse()) {
            return Bool.FALSE;
        }
        cmValidateCharacteristicTypes(WfmOptionTypeLookup.constants.SYSTEMATIC_MTR_EXCHANGE_CHAR_TYPE, CharacteristicEntityLookup.constants.METER);
        cmValidateCharacteristicTypes(WfmOptionTypeLookup.constants.FAILED_SAMPLE_MTR_EXCHANGE_CHAR_TYPE, CharacteristicEntityLookup.constants.METER);
        cmValidateCaseTypes(WfmOptionTypeLookup.constants.METERING_EXCEPTION_CASE_TYPE);

        return Bool.TRUE;
    }

    /*
     * This method will validate the FA Types retrieved from the feature configuration
     */
    private Bool cmValidateFaTypes(WfmOptionTypeLookup optionTypeLookup, Bool allowMultiple) {
    	//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //ListFilter<FeatureConfigurationOption> faTypeOptionFilter = featureConfiguration.getOptions().createFilter("WHERE this.id.optionType = :optionType");
    	ListFilter<FeatureConfigurationOption> faTypeOptionFilter = featureConfiguration.getOptions().
    			createFilter("WHERE this.id.optionType = :optionType",getClass().getName());
    	//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        faTypeOptionFilter.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, optionTypeLookup.trimmedValue());

        if(faTypeOptionFilter.list().size() == 0) {
            return Bool.FALSE;
        } else if(faTypeOptionFilter.list().size() > 1 && allowMultiple.isFalse()) {
            addError(CustomMessageRepositoryMDC.ni00091MultipleOptionValuesRetrieved(featureConfiguration.getId().getIdValue(), optionTypeLookup.getLookupValue().fetchLanguageDescription()));
        }

        Iterator<FeatureConfigurationOption> faTypeIter = faTypeOptionFilter.list().iterator();
        while(faTypeIter.hasNext()) {
            FeatureConfigurationOption faTypeOption = faTypeIter.next();
            String faTypeStr = faTypeOption.getValue().trim();
            FieldActivityType_Id faTypeId = new FieldActivityType_Id(faTypeStr);
            FieldActivityType faType = faTypeId.getEntity();

            if(isNull(faType)) {
                addError(CustomMessageRepositoryMDC.ni00091InvalidFieldActivityType(featureConfiguration.getId().getIdValue(), faTypeStr));
            }
        }

        return Bool.TRUE;
    }

    /*
     * This method will validate the Characteristic Types retrieved from the feature configuration
     */
    private void cmValidateCharacteristicTypes(WfmOptionTypeLookup optionTypeLookup, CharacteristicEntityLookup charEntityLookup) {
    	//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //ListFilter<FeatureConfigurationOption> charTypeOptionFilter = featureConfiguration.getOptions().createFilter("WHERE this.id.optionType = :optionType");
        ListFilter<FeatureConfigurationOption> charTypeOptionFilter = featureConfiguration.getOptions().
        		createFilter("WHERE this.id.optionType = :optionType", getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        charTypeOptionFilter.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, optionTypeLookup.trimmedValue());

        if(charTypeOptionFilter.list().size() == 0) {
            addError(CustomMessageRepositoryMDC.ni00091NoOptionValuesRetrieved(featureConfiguration.getId().getIdValue(), optionTypeLookup.getLookupValue().fetchLanguageDescription()));
        }

        Iterator<FeatureConfigurationOption> charTypeIter = charTypeOptionFilter.list().iterator();
        while(charTypeIter.hasNext()) {
            FeatureConfigurationOption charTypeOption = charTypeIter.next();
            String charTypeStr = charTypeOption.getValue().trim();
            CharacteristicType_Id charTypeId = new CharacteristicType_Id(charTypeStr);
            CharacteristicType charType = charTypeId.getEntity();

            if(notNull(charType)) {
                CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, charEntityLookup);
                if(isNull(charEntityId.getEntity())) {
                    addError(CustomMessageRepositoryMDC.ni00091InvalidCharacteristicTypeForEntity(featureConfiguration.getId().getIdValue(), charTypeStr, charEntityLookup.getLookupValue().fetchLanguageDescription()));
                }
            }
        }
    }

    /*
     * This method will validate the Case Types retrieved from the feature configuration
     */
    private void cmValidateCaseTypes(WfmOptionTypeLookup optionTypeLookup) {
    	//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //ListFilter<FeatureConfigurationOption> caseTypeOptionFilter = featureConfiguration.getOptions().createFilter("WHERE this.id.optionType = :optionType");
        ListFilter<FeatureConfigurationOption> caseTypeOptionFilter = featureConfiguration.getOptions().
        		createFilter("WHERE this.id.optionType = :optionType", getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        
        caseTypeOptionFilter.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, optionTypeLookup.trimmedValue());

        if(caseTypeOptionFilter.list().size() == 0) {
            caseTypeExists = Bool.FALSE;
            return;
        }

        Iterator<FeatureConfigurationOption> caseTypeIter = caseTypeOptionFilter.list().iterator();
        while(caseTypeIter.hasNext()) {
            FeatureConfigurationOption caseTypeOption = caseTypeIter.next();
            String caseTypeStr = caseTypeOption.getValue().trim();
            CaseType_Id caseTypeId = new CaseType_Id(caseTypeStr);
            CaseType caseType = caseTypeId.getEntity();

            if(isNull(caseType)) {
                addError(CustomMessageRepositoryMDC.ni00091InvalidCaseType(featureConfiguration.getId().getIdValue(), caseTypeStr));
            }
        }
    }

    /*
     * This method will retrieve the Service Point's meter
     */
    private Meter cmGetMeterFromServicePoint(ServicePoint sp) {

        Meter meter = null;

        Query meterQuery = createQuery("FROM Meter mtr, ServicePointMeterHistory spMtrHistory, MeterConfiguration mtrConfig " +
                "WHERE spMtrHistory.servicePoint.id = :spId " +
                "AND (spMtrHistory.removalDateTime IS NULL OR spMtrHistory.removalDateTime > :processDate) " +
        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //"AND spMtrHistory.meterConfiguration.id = mtrConfig.id AND mtrConfig.meter.id = mtr.id");
        		"AND spMtrHistory.meterConfiguration.id = mtrConfig.id AND mtrConfig.meter.id = mtr.id", getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        meterQuery.bindId("spId", sp.getId());
        meterQuery.bindDateTime("processDate", getProcessDateTime());
        meterQuery.addResult("meterId", "mtr.id");

        if(meterQuery.listSize() > 0) {
            Meter_Id meterId = (Meter_Id) meterQuery.firstRow();
            meter = meterId.getEntity();
        }

        return meter;
    }
    /*
     * This method will retrieve the Meter Characteristic whose Characteristic Type is found in the Feature Configuration options
     */
    private Bool cmRetrieveMeterCharacteristic(Meter_Id meterId, WfmOptionTypeLookup optionTypeLookup) {

        Bool isFound = Bool.FALSE;

        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder.append("FROM MeterCharacteristic meterCharacteristic, FeatureConfigurationOption optionValues ");
        queryBuilder.append("WHERE meterCharacteristic.id.meter.id = :meterId ");
        queryBuilder.append("AND optionValues.id.workforceManagementSystem.id = :featureConfigurationId ");
        queryBuilder.append("AND optionValues.id.optionType = :charTypeOptionType ");
        queryBuilder.append("AND TRIM(meterCharacteristic.id.characteristicType.id) = TRIM(optionValues.value) ");
        queryBuilder.append("AND meterCharacteristic.id.effectiveDate <= :processDate ");

        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //Query charTypeQuery = createQuery(queryBuilder.toString());
        Query charTypeQuery = createQuery(queryBuilder.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        charTypeQuery.bindId("meterId", meterId);
        charTypeQuery.bindId("featureConfigurationId", featureConfiguration.getId());
        charTypeQuery.bindStringProperty("charTypeOptionType", FeatureConfigurationOption.properties.optionType, optionTypeLookup.value());
        charTypeQuery.bindDate("processDate", this.getProcessDateTime().getDate());

        if(charTypeQuery.list().size() > 0) {
            isFound = Bool.TRUE;
        }

        return isFound;
    }
    /* 2014-04-23	Rahul	   IM-047162	Start */
    /*
     * This method will retrieve the Meter Characteristic value whose Characteristic Type is found in the Feature Configuration options
     */

    private String cmRetrieveMeterCharacteristicValue(Meter_Id meterId, WfmOptionTypeLookup optionTypeLookup) {

        String characteristicValue = null;

        StringBuilder queryBuilder = new StringBuilder();
        //Bhaskar - SA 249344 Change - Start
        /* queryBuilder.append("FROM MeterCharacteristic meterCharacteristic, FeatureConfigurationOption optionValues ");
        queryBuilder.append("WHERE meterCharacteristic.id.meter.id = :meterId ");
        queryBuilder.append("AND optionValues.id.workforceManagementSystem.id = :featureConfigurationId ");
        queryBuilder.append("AND optionValues.id.optionType = :charTypeOptionType ");
        queryBuilder.append("AND TRIM(meterCharacteristic.id.characteristicType.id) = TRIM(optionValues.value) ");
        queryBuilder.append("AND meterCharacteristic.id.effectiveDate <= :processDate ");

        
        
        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //Query charTypeQuery = createQuery(queryBuilder.toString());
        Query charTypeQuery = createQuery(queryBuilder.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        charTypeQuery.bindId("meterId", meterId);
        charTypeQuery.bindId("featureConfigurationId", featureConfiguration.getId());
        charTypeQuery.bindStringProperty("charTypeOptionType", FeatureConfigurationOption.properties.optionType, optionTypeLookup.value());
        charTypeQuery.bindDate("processDate", this.getProcessDateTime().getDate());
        charTypeQuery.addResult("charVal", "meterCharacteristic.characteristicValue");
        

        if(charTypeQuery.list().size() > 0) {
            characteristicValue = (String)charTypeQuery.firstRow();


        }*/
        
        
       
		queryBuilder.append("SELECT MC.MTR_ID, MC.CHAR_TYPE_CD, MC.CHAR_VAL, MC.EFFDT ");
		queryBuilder.append("FROM CI_MTR_CHAR MC, CI_WFM_OPT FCO ");
		queryBuilder.append("WHERE MC.MTR_ID = :meterId ");
		queryBuilder.append("AND FCO.WFM_NAME = :featureConfigurationId ");
		queryBuilder.append("AND FCO.EXT_OPT_TYPE = :charTypeOptionType ");
		queryBuilder.append("AND trim(MC.CHAR_TYPE_CD) = trim(FCO.WFM_OPT_VAL) ");
		queryBuilder.append("AND MC.EFFDT <= :processDate ");
		queryBuilder.append("ORDER BY MC.EFFDT DESC ");
		
		PreparedStatement prepStatement = createPreparedStatement(queryBuilder.toString(), "== retrieving service point ==");
		
		prepStatement.bindString("meterId", meterId.getIdValue(), "MeterId");
		prepStatement.bindString("featureConfigurationId", featureConfiguration.getId().getIdValue(), "featureConfigId");
		prepStatement.bindString("charTypeOptionType",  optionTypeLookup.value(),"OptionType");
		prepStatement.bindDateTime("processDate", this.getProcessDateTime());
		prepStatement.execute();
		
		if(notNull(prepStatement.firstRow())){
			SQLResultRow sqlRow = (SQLResultRow) prepStatement.firstRow();
			characteristicValue = sqlRow.getString("CHAR_VAL");
		}
		prepStatement.close();
        return characteristicValue;
        //Bhaskar - SA 249344 Change - END
    }
    /* 2014-04-23	Rahul	   IM-047162	End */

    /*
     * This method will check if an active Metering Exception Case exists on the Premise
     */
    private Bool cmDoesMeteringExceptionCaseExist(WfmOptionTypeLookup optionTypeLookup, Premise_Id premiseId) {

        Bool caseExists = Bool.FALSE;

        String activeCaseStatus = cmGetOptionValue(WfmOptionTypeLookup.constants.METERING_EXCEPTION_ACTIVE_CASE_STATUS);

        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder.append("FROM ToDoCase toDoCase, FeatureConfigurationOption optionValues ");
        queryBuilder.append("WHERE toDoCase.premiseId = :premiseId ");
        queryBuilder.append("AND optionValues.id.workforceManagementSystem.id = :featureConfigurationId ");
        queryBuilder.append("AND optionValues.id.optionType = :caseTypeOptionType ");
        queryBuilder.append("AND TRIM(toDoCase.caseStatus.id.caseType.id) = TRIM(optionValues.value) ");
        /*  2014-04-21	Rahul	   IM-045515	Start  */
        //queryBuilder.append("AND toDoCase.caseStatus.id.status = :activeStatus ");
        queryBuilder.append("AND toDoCase.caseCondition = :activeStatus ");
        /*  2014-04-21	Rahul	   IM-045515	End  */

        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //Query caseQuery = createQuery(queryBuilder.toString());
        Query caseQuery = createQuery(queryBuilder.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        caseQuery.bindId("premiseId", premiseId);
        caseQuery.bindId("featureConfigurationId", featureConfiguration.getId());
        caseQuery.bindStringProperty("caseTypeOptionType", FeatureConfigurationOption.properties.optionType, optionTypeLookup.value());
        /*  2014-04-21  Rahul      IM-045515    Start  */
        //caseQuery.bindStringProperty("activeStatus", CaseStatus.properties.status, activeCaseStatus);        
        caseQuery.bindLookup("activeStatus", CaseConditionLookup.constants.OPEN);
        /*  2014-04-21  Rahul      IM-045515    End  */

        if(caseQuery.list().size() >= 1) {
            caseExists = Bool.TRUE;
        }

        return caseExists;
    }

    /*
     * This method will retrieve the option value from the feature configuration
     */
    private String cmGetOptionValue(Lookup optionType) {

        String optionValue = "";
        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //ListFilter<FeatureConfigurationOption> featConfigOptionFilter = featureConfiguration.getOptions().createFilter("WHERE this.id.optionType = :optionType");
        ListFilter<FeatureConfigurationOption> featConfigOptionFilter = featureConfiguration.getOptions().
        		createFilter("WHERE this.id.optionType = :optionType", getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        featConfigOptionFilter.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, optionType.trimmedValue());

        if(featConfigOptionFilter.list().size() == 0) {
            addError(CustomMessageRepositoryMDC.ni00091NoOptionValuesRetrieved(featureConfiguration.getId().getIdValue(), optionType.getLookupValue().fetchLanguageDescription()));
        } else if(featConfigOptionFilter.list().size() > 1) {
            addError(CustomMessageRepositoryMDC.ni00091MultipleOptionValuesRetrieved(featureConfiguration.getId().getIdValue(), optionType.getLookupValue().fetchLanguageDescription()));
        } else {
            FeatureConfigurationOption featConfigOption = featConfigOptionFilter.firstRow();
            optionValue = featConfigOption.getValue().trim();
        }

        return optionValue;
    }

    /*
     * This method will check if a pending Meter Exchange FA already exists on the Service Point
     */
    private Bool cmDoesMeterExchangeFaExist(ServicePoint sp) {

        Bool faExists = Bool.FALSE;

        StringBuilder queryBuilder = new StringBuilder();
        queryBuilder.append("FROM FieldActivity fieldActivity, FeatureConfigurationOption optionValues ");
        queryBuilder.append("WHERE fieldActivity.servicePoint.id = :spId ");
        queryBuilder.append("AND fieldActivity.fieldActivityStatus = :pendingStatus ");
        queryBuilder.append("AND optionValues.id.workforceManagementSystem.id = :featureConfigurationId ");
        queryBuilder.append("AND optionValues.id.optionType = :faTypeOptionType ");
        queryBuilder.append("AND TRIM(fieldActivity.fieldActivityType.id) = TRIM(optionValues.value) ");

        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //Query meterExchangeFaQuery = createQuery(queryBuilder.toString());
        Query meterExchangeFaQuery = createQuery(queryBuilder.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        meterExchangeFaQuery.bindId("spId", sp.getId());
        meterExchangeFaQuery.bindLookup("pendingStatus", FieldActivityStatusLookup.constants.PENDING);
        meterExchangeFaQuery.bindId("featureConfigurationId", featureConfiguration.getId());
        meterExchangeFaQuery.bindStringProperty("faTypeOptionType", FeatureConfigurationOption.properties.optionType, WfmOptionTypeLookup.constants.MTR_EXCHANGE_FA_TYPE.value());

        if(meterExchangeFaQuery.list().size() > 0) {
            faExists = Bool.TRUE;
        }

        return faExists;
    }

    private void updateFieldActivity(FieldActivity_Id faId, FieldActivityType_Id faTypeId, FieldActivityPriorityLookup faPriority, Bool eligibleForDispatch, String dispatchGroupString) {

        StringBuilder updateFAString = new StringBuilder();
        updateFAString.append("UPDATE CI_FA                                       ");
        updateFAString.append("       SET FA_TYPE_CD = :faTypeCode                ");
        updateFAString.append("          ,FA_PRIORITY_FLG = :faPriorityFlag       ");
        updateFAString.append("          ,ELIG_DISPATCH_SW = :eligibleForDispatch ");
        updateFAString.append("          ,DISP_GRP_CD = :dispatchGroup ");
        updateFAString.append(" WHERE FA_ID = :faId                               ");

        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //PreparedStatement updateFA = createPreparedStatement(updateFAString.toString());
        PreparedStatement updateFA = createPreparedStatement(updateFAString.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        updateFA.bindId("faTypeCode", faTypeId);
        updateFA.bindLookup("faPriorityFlag", faPriority);
        updateFA.bindBoolean("eligibleForDispatch", eligibleForDispatch);
        updateFA.bindString("dispatchGroup", dispatchGroupString, "DISP_GRP_CD");
        updateFA.bindId("faId", faId);

        updateFA.execute();
    }

    private void deleteOldFieldActivitySteps(FieldActivity_Id faId) {

        StringBuilder deleteFAStepString = new StringBuilder();
        deleteFAStepString.append("DELETE FROM CI_FA_STEP  ");
        deleteFAStepString.append(" WHERE FA_ID = :faId                               ");

        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //PreparedStatement deleteFAStep = createPreparedStatement(deleteFAStepString.toString());
        PreparedStatement deleteFAStep = createPreparedStatement(deleteFAStepString.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        deleteFAStep.bindId("faId", faId);

        deleteFAStep.execute();
    }

    private void insertNewFASteps(FieldActivity fa, FieldActivityType faType){

        FieldActivityTypeFieldActivityStepTypes faStepTypes = faType.getFieldActivityStepTypes();
        Iterator<FieldActivityStepType> newFAStepsIter = faStepTypes.iterator();

        while (newFAStepsIter.hasNext()){

            FieldActivityStepType faStepType = newFAStepsIter.next();

            StepUpdateEntityLookup faStepEntity = null;

            FieldActivityStepTypeActionLookup faStepActionLookup = faStepType.getFaStepTypeAction();

            if (faStepActionLookup.isInstallMeter()) {
                faStepEntity = StepUpdateEntityLookup.constants.SP_METER_HISTORY;
            }
            if (faStepActionLookup.isRemoveMeter()) {
                faStepEntity = StepUpdateEntityLookup.constants.SP_METER_HISTORY;
            }
            if (faStepActionLookup.isTurnOffMeter()) {
                faStepEntity = StepUpdateEntityLookup.constants.SP_METER_HISTORY;
            }
            if (faStepActionLookup.isTurnOnMeter()) {
                faStepEntity = StepUpdateEntityLookup.constants.SP_METER_HISTORY;
            }
            if (faStepActionLookup.isInstallItem()) {
                faStepEntity = StepUpdateEntityLookup.constants.SP_ITEM_HISTORY;
            }
            if (faStepActionLookup.isRemoveItem()) {
                faStepEntity = StepUpdateEntityLookup.constants.SP_ITEM_HISTORY;
            }
            if (faStepActionLookup.isTurnOffItem()) {
                faStepEntity = StepUpdateEntityLookup.constants.SP_ITEM_HISTORY;
            }
            if (faStepActionLookup.isTurnOnItem()) {
                faStepEntity = StepUpdateEntityLookup.constants.SP_ITEM_HISTORY;
            }
            if (faStepActionLookup.isReadMeter()) {
                faStepEntity = StepUpdateEntityLookup.constants.METER_READ;
            }
            if (faStepActionLookup.isChangeServicePoint()) {
                faStepEntity = StepUpdateEntityLookup.constants.SERVICE_POINT;
            }
            if (faStepActionLookup.isReconfigureMultiItem()) {
                faStepEntity = StepUpdateEntityLookup.constants.SERVICE_POINT;
            }
            if (faStepActionLookup.isConnectServicePoint()) {
                faStepEntity = StepUpdateEntityLookup.constants.SERVICE_POINT;
            }
            if (faStepActionLookup.isDisconnectServicePoint()) {
                faStepEntity = StepUpdateEntityLookup.constants.SERVICE_POINT;
            }
            if (faStepActionLookup.isChangeMeter()) {
                faStepEntity = StepUpdateEntityLookup.constants.METER;
            }
            if (faStepActionLookup.isChangeMeterConfiguration()) {
                faStepEntity = StepUpdateEntityLookup.constants.METER_CONFIGURATION;
            }
            if (faStepActionLookup.isChangeItem()) {
                faStepEntity = StepUpdateEntityLookup.constants.ITEM;
            }
            if (faStepActionLookup.isContactCustomer()) {
                faStepEntity = StepUpdateEntityLookup.constants.CUSTOMER_CONTACT;
            }
            if (faStepActionLookup.isTestDevice()) {
                faStepEntity = StepUpdateEntityLookup.constants.DEVICE_TEST;
            }

            insertFieldActivityStep(fa.getId(),faStepType.fetchIdStepSequence(),faStepType.getFaStepTypeAction(),faStepEntity);
        }

    }

    private void insertFieldActivityStep(FieldActivity_Id faId, BigInteger sequence, FieldActivityStepTypeActionLookup faStepTypeAction, StepUpdateEntityLookup faStepEntity) {

        StringBuilder insertFAStepString = new StringBuilder();
        insertFAStepString.append("INSERT INTO CI_FA_STEP (FA_ID, STEP_SEQ_NBR, FA_STEP_TY_ACT_FLG, STP_ENTITY_FLG) ");
        insertFAStepString.append("VALUES (:faId, :sequence, :faStepTypeAction, :stepEntity)");

        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //PreparedStatement insertFAStep = createPreparedStatement(insertFAStepString.toString());
        PreparedStatement insertFAStep = createPreparedStatement(insertFAStepString.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        insertFAStep.bindId("faId", faId);
        insertFAStep.bindBigInteger("sequence", sequence);
        insertFAStep.bindLookup("faStepTypeAction", faStepTypeAction);
        insertFAStep.bindLookup("stepEntity", faStepEntity);

        insertFAStep.execute();
    }

    private void deleteOldFieldActivityCharacteristics (FieldActivity_Id faId) {

        StringBuilder deleteFACharString = new StringBuilder();
        deleteFACharString.append("DELETE FROM CI_FA_CHAR  ");
        deleteFACharString.append(" WHERE FA_ID = :faId                               ");

        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //PreparedStatement deleteFAChar = createPreparedStatement(deleteFACharString.toString());
        PreparedStatement deleteFAChar = createPreparedStatement(deleteFACharString.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        deleteFAChar.bindId("faId", faId);

        deleteFAChar.execute();
    }

    private void insertNewFAChars(FieldActivity fa, FieldActivityType faType){

        FieldActivityTypeCharacteristicTypes faTypeFACharTypes = faType.getCharacteristicTypes();
        Iterator<FieldActivityTypeCharacteristicType> newFACharsIter = faTypeFACharTypes.iterator();

        while (newFACharsIter.hasNext()){

            String srchCharVal = "";

            FieldActivityTypeCharacteristicType faTypeCharType = newFACharsIter.next();

            if (faTypeCharType.getShouldUseAsDefault().isTrue()) {

                CharacteristicTypeLookup charTypeLookup = faTypeCharType.fetchIdCharacteristicType().getCharacteristicType();

                if (charTypeLookup.isForeignKeyValue()) {

                    srchCharVal = faTypeCharType.getCharacteristicValueForeignKey1();
                }
                else if (charTypeLookup.isPredefinedValue()) {
                    srchCharVal = faTypeCharType.getCharacteristicValue();
                }
                else {
                    srchCharVal = faTypeCharType.getAdhocCharacteristicValue();
                }

                insertFieldActivityChar(fa.getId(),faTypeCharType.getId().getCharacteristicTypeId(),faTypeCharType.getSortSequence()
                        , faTypeCharType.getCharacteristicValue()
                        , faTypeCharType.getAdhocCharacteristicValue()
                        , faTypeCharType.getCharacteristicValueForeignKey1()
                        , faTypeCharType.getCharacteristicValueFK2()
                        , faTypeCharType.getCharacteristicValueFK3()
                        , faTypeCharType.getCharacteristicValueFk4()
                        , faTypeCharType.getCharacteristicValueFK5()
                        , srchCharVal);
            }

        }
    }
    // CVB - 2013-05-14 - Start
    private void insertRemovalReasonFAChar(FieldActivity fa){

        // Determine Removal Reason
        String removalReasonValue = determineRemovalReason(fa);

        if (!isBlankOrNull(removalReasonValue)){

            String removalReasonCharTypeString = cmGetOptionValue(WfmOptionTypeLookup.constants.REASON_TO_REMOVE_CHAR_TYPE);
            if (!isBlankOrNull(removalReasonCharTypeString)){

                CharacteristicType_Id id = new CharacteristicType_Id(removalReasonCharTypeString);
                CharacteristicType removalReasonCharType;

                removalReasonCharType = id.getEntity();    

                if (notNull(removalReasonCharType)){
                    BigInteger maxSequenceNumber = retrieveSequenceNumber(fa,removalReasonCharTypeString);
                    BigInteger faSequenceNumber = BigInteger.TEN;
                    if (maxSequenceNumber.compareTo(BigInteger.ZERO) == 1 ){
                        faSequenceNumber = maxSequenceNumber.add(BigInteger.ONE);
                    }

                    String srchCharVal = " ";
                    String charValue = " ";
                    String adhocCharValue = " ";
                    String charValueFK1 = " ";

                    CharacteristicTypeLookup charTypeLookup = removalReasonCharType.getCharacteristicType();

                    if (charTypeLookup.isForeignKeyValue()) {

                        charValueFK1 = removalReasonValue;
                    }
                    else if (charTypeLookup.isPredefinedValue()) {
                        charValue = removalReasonValue;
                    }
                    else {
                        adhocCharValue = removalReasonValue;
                    }
                    srchCharVal = removalReasonValue;

                    insertFieldActivityChar(fa.getId()
                            ,removalReasonCharType.getId()
                            ,faSequenceNumber
                            ,charValue
                            ,adhocCharValue
                            ,charValueFK1
                            ," "
                            ," "
                            ," "
                            ," "
                            ,srchCharVal);
                }
            }
        }
    }

    private String determineRemovalReason(FieldActivity fa){
        String removalReason = "";

        if (systematicCharExists.isTrue()){
            removalReason = cmGetOptionValue(WfmOptionTypeLookup.constants.SYSTEMATIC_CHAR_VAL);
        }

        if (isBlankOrNull(removalReason)){

            if (failedSamplingCharExists.isTrue()){
                removalReason = cmGetOptionValue(WfmOptionTypeLookup.constants.FAILED_CHAR_VAL);
            }
        }

        if (isBlankOrNull(removalReason)){

            if (meteringExceptionCaseExists.isTrue()){
                removalReason = cmGetOptionValue(WfmOptionTypeLookup.constants.MTR_EXCEPTION_CHAR_VAL);
            }
        }

        return removalReason;
    }

    private BigInteger retrieveSequenceNumber(FieldActivity fa, String charTypeString) {

        BigInteger sequenceNumber;

        StringBuilder strBldr = new StringBuilder();

        strBldr.append(" SELECT MAX(SEQ_NUM) AS SEQNUM            ");
        strBldr.append("   FROM CI_FA_CHAR FACHAR                 ");
        strBldr.append("  WHERE FACHAR.FA_ID = :fa                ");
        strBldr.append("    AND FACHAR.CHAR_TYPE_CD = :charType   ");

        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //PreparedStatement qry = createPreparedStatement(strBldr.toString());
        PreparedStatement qry = createPreparedStatement(strBldr.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        qry.bindEntity("fa", fa);
        qry.bindString("charType", charTypeString, "CHAR_TYPE_CD");

        SQLResultRow row = qry.firstRow();

        sequenceNumber = row.getInteger("SEQNUM");

        if (isNull(sequenceNumber)){
            sequenceNumber = BigInteger.ZERO;
        }

        qry.close();

        return sequenceNumber;
    }   
    // CVB - 2013-05-14 - End

    private void insertFieldActivityChar(FieldActivity_Id faId, CharacteristicType_Id charTypeId, BigInteger charSequence, String charVal, String adhocCharVal, String charValFK1, String charValFK2, String charValFK3, String charValFK4, String charValFK5, String searchCharVal) {

        StringBuilder insertFACharString = new StringBuilder();
        insertFACharString.append("INSERT INTO CI_FA_CHAR (FA_ID, CHAR_TYPE_CD, SEQ_NUM, CHAR_VAL, ADHOC_CHAR_VAL, CHAR_VAL_FK1, CHAR_VAL_FK2, CHAR_VAL_FK3, CHAR_VAL_FK4, CHAR_VAL_FK5, SRCH_CHAR_VAL) ");
        insertFACharString.append("VALUES (:faId, :charTypeId, :sequence, :charVal, :adhocCharVal, :charValFK1, :charValFK2, :charValFK3, :charValFK4, :charValFK5, :searchCharVal) ");

        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //PreparedStatement insertFAChar = createPreparedStatement(insertFACharString.toString());
        PreparedStatement insertFAChar = createPreparedStatement(insertFACharString.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        insertFAChar.bindId("faId", faId);
        insertFAChar.bindId("charTypeId", charTypeId);
        insertFAChar.bindBigInteger("sequence", charSequence);
        insertFAChar.bindString("charVal", charVal, "CHAR_VAL");
        insertFAChar.bindString("adhocCharVal", adhocCharVal, "ADHOC_CHAR_VAL");
        insertFAChar.bindString("charValFK1", charValFK1, "CHAR_VAL_FK1");
        insertFAChar.bindString("charValFK2", charValFK2, "CHAR_VAL_FK2");
        insertFAChar.bindString("charValFK3", charValFK3, "CHAR_VAL_FK3");
        insertFAChar.bindString("charValFK4", charValFK4, "CHAR_VAL_FK4");
        insertFAChar.bindString("charValFK5", charValFK5, "CHAR_VAL_FK5");
        insertFAChar.bindString("searchCharVal", searchCharVal, "SRCH_CHAR_VAL");

        insertFAChar.execute();
    }
    
    /* 2020-08-01	FRoig		Defect 4456684	Start */
    /* 2020-06-12	FRoig		Defect 4436383	Start */
    //private void createSyncRequest(FieldActivity fieldActivity, String ntDownTypeCondition, String dispatchGroupId) {
    //    
    //    CmCreateSyncRequest createSyncRequest = CmCreateSyncRequest.Factory.newInstance();
    //    createSyncRequest.cmCreateSyncRequest(fieldActivity.getId(), ntDownTypeCondition, dispatchGroupId, "CmFieldActivityOverrideAlgComp");
    //}
    /* 2020-06-12	FRoig		Defect 4436383	End */
    /* 2020-08-01	FRoig		Defect 4456684	End */

}
