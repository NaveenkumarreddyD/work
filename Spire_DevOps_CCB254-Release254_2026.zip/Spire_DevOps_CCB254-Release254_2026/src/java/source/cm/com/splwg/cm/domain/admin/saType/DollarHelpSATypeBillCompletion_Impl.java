/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Dollar Help Billing Adjustment
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2012-10-23   Arun          NA0039. Initial Version.
 * 2012-10-29   Arun          NA0039. Review Comments Incorporated.
 * 2016-01-26   MPang		  Updated for CCB v2.4 compilation.
 * 2016-11-06   Rgoke		  Updated for Incident# 77605. 
 * 2017-09-04	JHERNA		  SysAid# 225136. update the code so that when an SA does not
 * 							  have any current balance, this program would stop processing
 * 							  and immediately terminate.
 * 2019-10-07   BMarquez      SysAid# 310829. Correct calculation of the accrued balance on the SA.
 *                            If SA is closed, end processing immediately.
 * 2021-03-24   JHERNA		  SysAid# 363692. Allow reopening of Dollar Help Bills.
 * 
 ******************************************************************************************/

package com.splwg.cm.domain.admin.saType;

import java.math.BigInteger;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.billCompletion.SaTypeBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage;
import com.splwg.ccb.domain.billing.bill.entity.BillMessageParameter_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill_DTO;
import com.splwg.ccb.domain.billing.data.BillData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;

/**
 * 
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentType, name = adjType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = billMessage, type = entity)})
 */

public class DollarHelpSATypeBillCompletion_Impl 
		extends DollarHelpSATypeBillCompletion_Gen 
		implements SaTypeBillCompletionAlgorithmSpot {

    private ServiceAgreement saId;
    private BillData billData;
  //77605 - start change
    @SuppressWarnings("unused")
	private Date billDate;
    
    public Bool getAllowBillReopening() {
    	/* START CHANGES - JHERNA - 2021-03-24 - SysAid#363692 */            
        //return null;
    	return outAllowBillReopening;
    	/* END CHANGES - JHERNA - 2021-03-24 - SysAid#363692 */
    }

    public BillData getBillData() {
        return billData;
    }

    public Bool getDoMultipleBillingRelationshipsExist() {
        return null;
    }

    public Bool getIsFtProcessAdded() {
        return null;
    }

    public Bool getIsFtTransferred() {
        return null;
    }

    public void setAccountingDate(Date arg0) {
    }

    public void setBillData(BillData billData) {
        this.billData=billData;
    }

    public void setBillDate(Date arg0) {
    	this.billDate = arg0;
    }

    public void setServiceAgreement(ServiceAgreement sa) {
        saId = sa;
    }

    /* START ADD - JHERNA - 2021-03-24 - SysAid#363692 */    
    private Bool outAllowBillReopening;
    
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		// Initialize output
		outAllowBillReopening = Bool.TRUE;
	}
   /* END ADD - JHERNA - 2021-03-24 - SysAid#363692 */
	
    public void invoke() {
        
    	/*
    	 * Start Change - 310829 - 2019-10-07
    	 */
		////Start Change - 2016-11-07 - RGoke - 77605
		////Money currBillAmt;
		////Money currUnBilledAdjAmt;
		////Money previousCurrBalance;
		//Money currBalance = Money.ZERO;
		//Money recurringChargeAmount = Money.ZERO;
		//Money adjAmt = Money.ZERO;
		////Dollar help SA's current balance
		//currBalance = saId.getCurrentBalance();
		//
		//// START ADD - JHERNA - 2017-09-04 - SysAid#225136
		//if (currBalance.isEqualTo(Money.ZERO)) {
		//	return;
		//}
		//// END ADD - JHERNA - 2017-09-04 - SysAid#225136
		//
		////Retrieve the dollar help SAs effective recurring charge amount
		//ListFilter<ServiceAgreementRecurringCharge> recurringChargeFilter =
		//		saId.getRecurringCharges().createFilter("WHERE this.id.serviceAgreement=:F1 AND this.id.effectiveDate<=:F2 ORDER BY this.id.effectiveDate DESC", getClass().getName());
		//recurringChargeFilter.bindEntity("F1", saId);
		//recurringChargeFilter.bindDate("F2", billDate);
		//
		//ServiceAgreementRecurringCharge recurringCharge = recurringChargeFilter.firstRow();
		//if(isNull(recurringCharge)){
		//	return;
		//}
		//recurringChargeAmount = recurringCharge.getRecurringChargeAmount();
		//adjAmt = currBalance.subtract(recurringChargeAmount);
		//
		////currBillAmt = getCurrentAmount(saId);
		////currUnBilledAdjAmt = retreiveCurrentUnbilledAmt(saId);
		////if(notNull(currUnBilledAdjAmt))
		////    previousCurrBalance = currBillAmt.add(currUnBilledAdjAmt);
		////else
		////    previousCurrBalance = currBillAmt;
		//BillMessageType billMessage=getBillMessage();
		////if(previousCurrBalance.compareTo(Money.ZERO) == 0 ){
		//if(adjAmt.isZero()){
		//    return;
		//}
		//////End Change - 2016-11-07 - RGoke - 77605
		//CreateFrozenAdjustmentData frozenAdjData = CreateFrozenAdjustmentData.Factory.newInstance();
		//frozenAdjData.setServiceAgreement(saId);
		//frozenAdjData.setAdjustmentType(getAdjType());
		////Start Change - 2016-11-07 - RGoke - 77605
		////frozenAdjData.setAdjustmentAmount(previousCurrBalance.negate());
		//frozenAdjData.setAdjustmentAmount(adjAmt.negate());
		////End Change - 2016-11-07 - RGoke - 77605
		//frozenAdjData.setAllowZeroAmount(Bool.FALSE);
		//CreateFrozenAdjustment frozenAdjustment =  CreateFrozenAdjustment.Factory.newInstance();
		//frozenAdjustment.createFrozenAdjustment(frozenAdjData);
		//
		//if(notNull(billMessage))
		//{
		//    Bill_DTO billDTO = billData.getBillDTO();
		//    startChanges();
		//    BillMessage_DTO billMsgDTO =  billDTO.getEntity().getMessages().newChildDTO();
		//    BillMessage_Id billMsgId = new BillMessage_Id(billMessage.getId(),billDTO.getId());
		//    billMsgDTO.setId(billMsgId);
		//    billMsgDTO.setVersion(1);
		//    BillMessage billMsg = billMsgDTO.newEntity();
		//    BillMessageParameter_DTO billMsgParmDTO = billMsg.getParameters().newChildDTO();
		//    //Start Change - 2016-11-07 - RGoke - 77605
		//    //billMsgParmDTO.setMessageParameterValue(previousCurrBalance.toString());
		//    billMsgParmDTO.setMessageParameterValue(adjAmt.toLocalizedString(adjAmt.getCurrencyId().getEntity()));
		//    //End Change - 2016-11-07 - RGoke - 77605
		//    billMsgParmDTO.setVersion(1);
		//    billMsg.getParameters().add(billMsgParmDTO,BigInteger.ONE);
		//    billDTO.getId().getEntity().getMessages().add(billMsg);
		//    saveChanges();
		//
		//}
        
    	// If the Dollar Help SA is closed, end processing
    	if (saId.getStatus().isClosed()) {
    		return;
    	}
    	
    	// If the current balance of the Dollar Help SA is zero, end processing
    	Money currentBalance = saId.getCurrentBalance();
    	if (currentBalance.isZero()) {
    		return;
    	}
    	
    	// If the current balance of FTs unlinked to Bills is zero, end processing
    	Money balanceBeforeThisBilling = currentBalance.subtract(retrieveUnbilledAmount(saId));
    	if (balanceBeforeThisBilling.isZero()) {
    		return;
    	}
    	
    	// Create and freeze the Adjustment to make the balance zero before this bill
    	CreateFrozenAdjustmentData createFrozenAdjustmentData = CreateFrozenAdjustmentData.Factory.newInstance();
    	createFrozenAdjustmentData.setServiceAgreement(saId);
    	createFrozenAdjustmentData.setAdjustmentType(getAdjType());
    	createFrozenAdjustmentData.setAdjustmentAmount(balanceBeforeThisBilling.negate());
    	createFrozenAdjustmentData.setAllowZeroAmount(Bool.FALSE);
    	CreateFrozenAdjustment createFrozenAdjustment = CreateFrozenAdjustment.Factory.newInstance();
    	createFrozenAdjustment.createFrozenAdjustment(createFrozenAdjustmentData);

    	BillMessageType billMessageType = getBillMessage();
    	if (notNull(billMessageType)) {
    		
    		Bill_DTO billDTO = billData.getBillDTO();
    		
    		BillMessage_DTO billMessageDTO =  billDTO.getEntity().getMessages().newChildDTO();
    		billMessageDTO.setId(new BillMessage_Id(billMessageType.getId(),billDTO.getId()));
    		BillMessage billMessage = billMessageDTO.newEntity();
    		
    		BillMessageParameter_DTO billMessageParameterDTO = billMessage.getParameters().newChildDTO();
    		billMessageParameterDTO.setMessageParameterValue(balanceBeforeThisBilling.toLocalizedString(saId.fetchCurrency()));
    		billMessage.getParameters().add(billMessageParameterDTO, BigInteger.ONE);
    		
    		startChanges();
    		billDTO.getId().getEntity().getMessages().add(billMessage);
    		saveChanges();

    	}
        /*
         * End Change - 310829 - 2019-10-07
         */
        
    }
    
    /*
     * Start Add - 310829 - 2019-10-07 
     */
    /**
     * Retrieve the most recent frozen Bill Segment FT of the Dollar Help SA that is not linked to a Bill.
     * @param serviceAgreement
     * @return Money
     */
    private Money retrieveUnbilledAmount(ServiceAgreement serviceAgreement){
    	
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT SUM(FT.CUR_AMT) SUMCURAMT ");
        stringBuilder.append("FROM CI_FT FT ");
        stringBuilder.append("WHERE FT.SA_ID = :serviceAgreement ");
        stringBuilder.append("AND FT.FREEZE_SW = :yes ");
        stringBuilder.append("AND FT.BILL_ID = ' ' ");
        stringBuilder.append("AND FT.REDUNDANT_SW = :no ");
        stringBuilder.append("AND FT.FT_TYPE_FLG IN (:adjustment, :billSegment) ");
        stringBuilder.append("AND NOT EXISTS (");
        stringBuilder.append(    "SELECT 'X' ");
        stringBuilder.append(    "FROM CI_FT FTC ");
        stringBuilder.append(    "WHERE FT.SIBLING_ID = FTC.SIBLING_ID  ");
        stringBuilder.append(	 "AND FTC.SA_ID = :serviceAgreement ");
        stringBuilder.append(    "AND FTC.FT_TYPE_FLG IN (:adjustmentCancel, :billCancel)) ");
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.setAutoclose(false);
        preparedStatement.bindId("serviceAgreement", serviceAgreement.getId());
        preparedStatement.bindBoolean("yes", Bool.TRUE);
        preparedStatement.bindBoolean("no", Bool.FALSE);
        preparedStatement.bindLookup("adjustment", FinancialTransactionTypeLookup.constants.ADJUSTMENT);
        preparedStatement.bindLookup("billSegment", FinancialTransactionTypeLookup.constants.BILL_SEGMENT);
        preparedStatement.bindLookup("adjustmentCancel", FinancialTransactionTypeLookup.constants.ADJUSTMENT_CANCELLATION);
        preparedStatement.bindLookup("billCancel", FinancialTransactionTypeLookup.constants.BILL_CANCELLATION);
        
        Money unbilledAmount = preparedStatement.firstRow().getMoney("SUMCURAMT", serviceAgreement.getCurrencyId());
        preparedStatement.close();

        if (isNull(unbilledAmount)) {
            return Money.ZERO;
        }
        
        return unbilledAmount;
    }
    /*
     * End Add - 310829 - 2019-10-07
     */
    
    //Start Change - 2016-11-07 - RGoke - 77605
//    private Money retreiveCurrentBillAmt(ServiceAgreement saId){
//        Money currentBillAmt = null;
//        StringBuilder currentBillAmtQueryString = new StringBuilder();
//        currentBillAmtQueryString.append("SELECT SUM(CUR_AMT)CURAMNT FROM CI_FT FT  ");
//        currentBillAmtQueryString.append("WHERE FT.SA_ID = :saId ");
//        currentBillAmtQueryString.append("AND FT.FREEZE_SW = :yes ");
//        currentBillAmtQueryString.append("AND FT.REDUNDANT_SW = :no ");
//        currentBillAmtQueryString.append("AND FT.FT_TYPE_FLG IN (:adjustment,:billSegment) ");
//        currentBillAmtQueryString.append("AND NOT EXISTS (SELECT 'X' FROM CI_FT FTC WHERE FT.SIBLING_ID=FTC.SIBLING_ID  ");
//        currentBillAmtQueryString.append("AND FTC.SA_ID= :saId AND FTC.FT_TYPE_FLG IN (:adjCancel,:billCancel)) ");
//        currentBillAmtQueryString.append("AND FT.BILL_ID != ' ' ");
//        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
//        // PreparedStatement currentBillAmtPrepStmt = createPreparedStatement(currentBillAmtQueryString.toString());
//        PreparedStatement currentBillAmtPrepStmt = createPreparedStatement(currentBillAmtQueryString.toString(), getClass().getName()); 
//        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
//        currentBillAmtPrepStmt.bindId("saId", saId.getId());
//        currentBillAmtPrepStmt.bindBoolean("yes", Bool.TRUE);
//        currentBillAmtPrepStmt.bindBoolean("no", Bool.FALSE);
//        currentBillAmtPrepStmt.bindLookup("adjustment", FinancialTransactionTypeLookup.constants.ADJUSTMENT);
//        currentBillAmtPrepStmt.bindLookup("billSegment", FinancialTransactionTypeLookup.constants.BILL_SEGMENT);
//        currentBillAmtPrepStmt.bindLookup("adjCancel", FinancialTransactionTypeLookup.constants.ADJUSTMENT_CANCELLATION);
//        currentBillAmtPrepStmt.bindLookup("billCancel", FinancialTransactionTypeLookup.constants.BILL_CANCELLATION);
//        currentBillAmt = currentBillAmtPrepStmt.firstRow().getMoney("CURAMNT");
//        currentBillAmtPrepStmt.close();
//        if(isNull(currentBillAmt))
//            return Money.ZERO;
//        else
//            return currentBillAmt;
//    }
//    private Money retreivePaymentAmt(ServiceAgreement saId){
//        Money paySegmentAmt = null;
//        StringBuilder paySegmentAmtQueryString = new StringBuilder();
//        paySegmentAmtQueryString.append("SELECT SUM(PAYSEG.PAY_SEG_AMT)PAYAMNT FROM CI_PAY_SEG PAYSEG,CI_PAY PAY ");
//        paySegmentAmtQueryString.append("WHERE PAYSEG.SA_ID = :saId ");
//        paySegmentAmtQueryString.append("AND PAYSEG.PAY_ID=PAY.PAY_ID ");
//        paySegmentAmtQueryString.append("AND PAY.PAY_STATUS_FLG= :frozen ");
//        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
//       // PreparedStatement paySegmentAmtPrepStmt = createPreparedStatement(paySegmentAmtQueryString.toString()); 
//        PreparedStatement paySegmentAmtPrepStmt = createPreparedStatement(paySegmentAmtQueryString.toString(), getClass().getName()); 
//        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
//        paySegmentAmtPrepStmt.bindId("saId", saId.getId());
//        paySegmentAmtPrepStmt.bindLookup("frozen", PaymentStatusLookup.constants.FROZEN);
//        paySegmentAmt = paySegmentAmtPrepStmt.firstRow().getMoney("PAYAMNT");
//        paySegmentAmtPrepStmt.close();
//        if(isNull(paySegmentAmt))
//            return Money.ZERO;
//        else
//            return paySegmentAmt;
//    }
//    private Money retreiveCurrentUnbilledAmt(ServiceAgreement saId){
//        Money currentBalAmt = null;
//        StringBuilder currentBillAmtQueryString = new StringBuilder();
//        currentBillAmtQueryString.append("SELECT SUM(CUR_AMT)CURAMNT FROM CI_FT FT  ");
//        currentBillAmtQueryString.append("WHERE FT.SA_ID = :saId ");
//        currentBillAmtQueryString.append("AND FT.FREEZE_SW = :yes ");
//        currentBillAmtQueryString.append("AND FT.REDUNDANT_SW = :no ");
//        currentBillAmtQueryString.append("AND FT.FT_TYPE_FLG IN (:adjustment) ");
//        currentBillAmtQueryString.append("AND NOT EXISTS (SELECT 'X' FROM CI_FT FTC WHERE FT.SIBLING_ID=FTC.SIBLING_ID  ");
//        currentBillAmtQueryString.append("AND FTC.SA_ID= :saId AND FTC.FT_TYPE_FLG IN (:adjCancel)) ");
//        currentBillAmtQueryString.append("AND FT.BILL_ID = ' ' ");
//        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
//       // PreparedStatement currentBillAmtPrepStmt = createPreparedStatement(currentBillAmtQueryString.toString()); 
//        PreparedStatement currentBillAmtPrepStmt = createPreparedStatement(currentBillAmtQueryString.toString(), getClass().getName());
//        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
//        currentBillAmtPrepStmt.bindId("saId", saId.getId());
//        currentBillAmtPrepStmt.bindBoolean("yes", Bool.TRUE);
//        currentBillAmtPrepStmt.bindBoolean("no", Bool.FALSE);
//        currentBillAmtPrepStmt.bindLookup("adjustment", FinancialTransactionTypeLookup.constants.ADJUSTMENT);
//        currentBillAmtPrepStmt.bindLookup("adjCancel", FinancialTransactionTypeLookup.constants.ADJUSTMENT_CANCELLATION);
//        currentBalAmt = currentBillAmtPrepStmt.firstRow().getMoney("CURAMNT");
//        currentBillAmtPrepStmt.close();
//
//        if(isNull(currentBalAmt))
//            return Money.ZERO;
//        else
//            return currentBalAmt;
//    }
//    
//    private Money getCurrentAmount(ServiceAgreement sa){
//        Money curBillAmnt = retreiveCurrentBillAmt(sa);
//        Money curPayAmnt = retreivePaymentAmt(sa);
//        Money diffAmt= curBillAmnt.subtract(curPayAmnt);
//        return diffAmt;
//
//    }
    //End Change - 2016-11-07 - RGoke - 77605
}
