/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Check Voiding Batch Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2021-06-01   GCrisp     Initial version. CCB041.3 Voiding File Extract
 *                         Batch
 * 2021-09-09   JLumbre    QAC#4594194. AP Voids not transferring the 
 *                          amount back to account balance     
 * 2021-10-12   JLumbre    QAC#4602715. Select distinct AP Request records. 
 * 2021-12-14   JLumbre    Mercury#47156.Populate DebitAmount on record 8
 *                              and 9, instead of credit amount.                
 * 2023-06-02   JVitug     E-04899.2. Updated to include adjustments A/P 
 *                         requests in Escheated status.
 * 2023-06-23   JVitug     D-03395. Updated main Job work SQL to include
 *                         all adjustments in Eligible for Escheatment
 *                         and in Escheatment status
 *************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.ccb.api.lookup.AdjustmentStatusLookup;
import com.splwg.ccb.api.lookup.PaymentSelectionStatusLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic_DTO;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic_Id;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristics;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.adjustment.adjustment.entity.ApCheckRequest;
import com.splwg.ccb.domain.adjustment.adjustment.entity.ApCheckRequest_DTO;
import com.splwg.ccb.domain.adjustment.adjustment.entity.ApCheckRequest_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.cm.api.batch.CmCheckVoidingExtractACHBatchControlRecord;
import com.splwg.cm.api.batch.CmCheckVoidingExtractACHBatchHeaderRecord;
import com.splwg.cm.api.batch.CmCheckVoidingExtractACHFileControlRecord;
import com.splwg.cm.api.batch.CmCheckVoidingExtractACHFileHeaderRecord;
import com.splwg.cm.api.batch.CmCheckVoidingExtractACHFooterRecord;
import com.splwg.cm.api.batch.CmCheckVoidingExtractACHPpdEntryDetailRecord;
import com.splwg.cm.api.batch.CmCheckVoidingExtractVoidingFileRecord;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.cm.api.lookup.CmAdjCharChandlerParmLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever_Impl;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author GCrisp
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules = {}, 
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MISSOURI_VOID_FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = ALABAMA_VOID_FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = GULF_VOID_FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = ALABAMA_ACH_FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = GULF_ACH_FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = VOID_REQUEST_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = adjustmentCancelReason, name = ADJ_CANCEL_REASON, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = EXT_ESC_CHECK_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = EXT_ESC_CHECK_CHAR_VAL, required = true, type = string)})
 */
public class CmCheckVoidingExtractBatch extends CmCheckVoidingExtractBatch_Gen {

    // Batch Parameters
    private String parmFilePath;
    //Start Add JVitug - E-04899.2 - 2023-06-02
    CharacteristicType extractEscheatedCharacteristicType;
    String extractEscheatedCharacteristicValue;
    //End Add JVitug - E-04899.2 - 2023-06-02

    @Override
    public void validateSoftParameters(boolean isJobWorkNeeded) {
        // Retrieve Batch Parameters
        parmFilePath = getParameters().getFILE_PATH();
        //Start Add JVitug - E-04899.2 - 2023-06-02
        extractEscheatedCharacteristicType  = getParameters().getEXT_ESC_CHECK_CHAR_TYPE();
        extractEscheatedCharacteristicValue = getParameters().getEXT_ESC_CHECK_CHAR_VAL();
        //End Add JVitug - E-04899.2 - 2023-06-02

        File folder = new File(parmFilePath);

        if (!folder.isDirectory()) {
            addError(CustomMessageRepositorySpireOne.CCB041_3_filePathInvalid(parmFilePath));
        }
        
        //Start Add JVitug - E-04899.2 - 2023-06-02
        //Validate that the Escheated Characteristic Type is valid for the Adjustment Entity
        CharacteristicEntity validateChar = new CharacteristicEntity_Id(extractEscheatedCharacteristicType , 
                CharacteristicEntityLookup.constants.ADJUSTMENT).getEntity();
        
        if(isNull(validateChar)) {
            addError(CustomMessageRepositorySpireOne.
                    E04899_2_invalidCharacteristicTypeForEntity(extractEscheatedCharacteristicType.getId().getTrimmedValue() 
                            , CharacteristicEntityLookup.constants.ADJUSTMENT.getLookupValue().fetchLanguageDescription().trim()));
        }
        
        //Validate that the Characteristic Value defined in the Batch parameters 
        if(extractEscheatedCharacteristicType.getCharacteristicType().isPredefinedValue()) {
            CharacteristicValue validateCharVal = new CharacteristicValue_Id(extractEscheatedCharacteristicType , 
                    extractEscheatedCharacteristicValue).getEntity();
            
            if(isNull(validateCharVal)) {
                addError(CustomMessageRepositorySpireOne.E04899_2_invalidCharValForCharType(extractEscheatedCharacteristicValue
                        , extractEscheatedCharacteristicType.getId().getTrimmedValue() ));
            }
        }
        //End Add JVitug - E-04899.2 - 2023-06-02
        
    }

    @Override
    public JobWork getJobWork() {
        StringBuilder getVoidedAdjustments = new StringBuilder();
        //Start Change - JLumbre - 2021-10-12 - QAC#4602715
        //getVoidedAdjustments.append("SELECT ");
        getVoidedAdjustments.append("SELECT DISTINCT ");
        //End Change - JLumbre - 2021-10-12 - QAC#4602715
        getVoidedAdjustments.append(    "APREQ.AP_REQ_ID APREQID, ");
        getVoidedAdjustments.append(    "ADJ.ADJ_ID ADJ_ID, ");
        //Start Add JVitug - E-04899.2 - 2023-06-02
        getVoidedAdjustments.append(    "APREQ.PYMNT_SEL_STAT_FLG ,  ");
        //Start Add JVitug - E-04899.2 - 2023-06-02
        getVoidedAdjustments.append(    "SA.CIS_DIVISION CISDIVISION ");
        getVoidedAdjustments.append("FROM CI_ADJ ADJ, ");
        getVoidedAdjustments.append(    "CI_ADJ_APREQ APREQ, ");
        //Start Delete JVitug - D-03395- 2023-06-23
        //getVoidedAdjustments.append(    "CI_ADJ_CHAR ADJCHAR, ");
        //End Delete JVitug - D-03395- 2023-06-23
        getVoidedAdjustments.append(    "CI_SA SA ");
        getVoidedAdjustments.append("WHERE ");
        getVoidedAdjustments.append(    "ADJ.ADJ_STATUS_FLG <> :canceled ");
        //Start Delete JVitug - D-03395- 2023-06-23
        //getVoidedAdjustments.append(    "AND ADJ.ADJ_ID = ADJCHAR.ADJ_ID ");
        //getVoidedAdjustments.append(    "AND ADJCHAR.CHAR_TYPE_CD = :voidCharType ");
        //End Delete JVitug - D-03395- 2023-06-23
        getVoidedAdjustments.append(    "AND APREQ.ADJ_ID = ADJ.ADJ_ID ");
        //Start Change JVitug - E-04899.2 - 2023-06-02
        //getVoidedAdjustments.append(    "AND PYMNT_SEL_STAT_FLG = :requestedForPayment ");
        //Start Change JVitug - D-03395- 2023-06-23
        //getVoidedAdjustments.append(    "AND (PYMNT_SEL_STAT_FLG = :requestedForPayment ");
        getVoidedAdjustments.append(    "AND ((PYMNT_SEL_STAT_FLG = :requestedForPayment ");
        getVoidedAdjustments.append(              "AND EXISTS ( ");
        getVoidedAdjustments.append(                 "SELECT ");
        getVoidedAdjustments.append(                    "'X' ");
        getVoidedAdjustments.append(                 "FROM ");
        getVoidedAdjustments.append(                    "CI_ADJ_CHAR ADJCHAR ");
        getVoidedAdjustments.append(                 "WHERE ");
        getVoidedAdjustments.append(                    "ADJCHAR.ADJ_ID = ADJ.ADJ_ID ");
        getVoidedAdjustments.append(                 "AND ");
        getVoidedAdjustments.append(                    "ADJCHAR.CHAR_TYPE_CD = :voidCharType ");
        getVoidedAdjustments.append(              ") ");
        getVoidedAdjustments.append(          ") ");
        //End Change JVitug - D-03395- 2023-06-23
        getVoidedAdjustments.append(       "OR (PYMNT_SEL_STAT_FLG IN (:escheated, :eligibleEscheated) ");
        getVoidedAdjustments.append(          "AND NOT EXISTS ( ");
        getVoidedAdjustments.append(             "SELECT ");
        getVoidedAdjustments.append(                "'X' ");
        getVoidedAdjustments.append(             "FROM ");
        getVoidedAdjustments.append(                "CI_ADJ_CHAR ACHR ");
        getVoidedAdjustments.append(             "WHERE ");
        getVoidedAdjustments.append(                "ACHR.ADJ_ID = ADJ.ADJ_ID ");
        getVoidedAdjustments.append(             "AND ");
        getVoidedAdjustments.append(                "ACHR.CHAR_TYPE_CD = :extractCheckCharType ");
        getVoidedAdjustments.append(          ") ");
        getVoidedAdjustments.append(       ") ");
        getVoidedAdjustments.append(    ") ");
        //End Change JVitug - E-04899.2 - 2023-06-02
        getVoidedAdjustments.append(    "AND ADJ.SA_ID = SA.SA_ID ");

        PreparedStatement pstmt =  createPreparedStatement(getVoidedAdjustments.toString(), getClass().getName());
        pstmt.bindLookup("canceled", AdjustmentStatusLookup.constants.CANCELED);
        pstmt.bindId("voidCharType", getParameters().getVOID_REQUEST_CHAR_TYPE().getId());
        pstmt.bindLookup("requestedForPayment", PaymentSelectionStatusLookup.constants.REQUESTED_FOR_PAYMENT);
        //Start Add JVitug - E-04899.2 - 2023-06-02
        //Due to the PYMNT_SEL_STAT_FLG being base and uncustomizable, the CONVERT_ERROR lookup was recycled 
        //as Escheated, and the negative voucher sum as Eligible for Escheated
        pstmt.bindLookup("escheated", PaymentSelectionStatusLookup.constants.CONVERT_ERROR);
        pstmt.bindLookup("eligibleEscheated", PaymentSelectionStatusLookup.constants.NEGATIVE_VOUCHER_SUM);
        pstmt.bindId("extractCheckCharType", getParameters().getEXT_ESC_CHECK_CHAR_TYPE().getId());
        //End Add JVitug - E-04899.2 - 2023-06-02

        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();

        QueryIterator<SQLResultRow> iterator = pstmt.iterate();     
        while (iterator.hasNext()){
            SQLResultRow resultRow = iterator.next();

            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId(resultRow.getId("APREQID", ApCheckRequest.class));
            workUnit.addSupplementalData("ADJ_ID", resultRow.getId("ADJ_ID", Adjustment.class));   
            workUnit.addSupplementalData("CISDIVISION", resultRow.getId("CISDIVISION", CisDivision.class));   
            //Start Add JVitug - E-04899.2 - 2023-06-02
            workUnit.addSupplementalData("PYMNT_SEL_STAT_FLG", resultRow.getLookup("PYMNT_SEL_STAT_FLG", PaymentSelectionStatusLookup.class));   
            //End Add JVitug - E-04899.2 - 2023-06-02
            workUnits.add(workUnit);
        }
        iterator.close();
        pstmt.close();
        
        return createJobWorkForThreadWorkUnitList(workUnits);
    }

    public Class<CmCheckVoidingExtractBatchWorker> getThreadWorkerClass() {
        return CmCheckVoidingExtractBatchWorker.class;
    }

    public static class CmCheckVoidingExtractBatchWorker extends
    CmCheckVoidingExtractBatchWorker_Gen {

        // Batch Parameters
        private String parmFilePath;
        private String parmMissouriVoidingFileName;
        private String parmAlabamaVoidingFileName;
        private String parmGulfVoidingFileName;
        private String parmAlabamaACHFileName;
        private String parmGulfACHFileName;
        //Start Add JVitug - E-04899.2 - 2023-06-02
        CharacteristicType extractEscheatedCharacteristicType;
        String extractEscheatedCharacteristicValue;
        //End Add JVitug - E-04899.2 - 2023-06-02

        // Work variables
        private File voidingFileMissouri;
        private File voidingFileAlabama;
        private File voidingFileGulf;
        private File achFileAlabama;
        private File achFileGulf;
        private BufferedWriter bwVoidingFileMissouri;
        private BufferedWriter bwVoidingFileAlabama;
        private BufferedWriter bwVoidingFileGulf;
        private BufferedWriter bwACHAlabama;
        private BufferedWriter bwACHGulf;

        private BigDecimal aTotalCheckAmount;
        private BigDecimal gTotalCheckAmount;
        private BigInteger checkNumber;
        private Bool isInitializedMoFile;
        private Bool isInitializedAlFile;
        private Bool isInitializedGlFile;

        private CmCheckVoidingExtractVoidingFileRecord mVoidingFileRecord;

        private CmCheckVoidingExtractVoidingFileRecord aVoidingFileRecord;
        private CmCheckVoidingExtractACHFileHeaderRecord aACHFileHeaderRecord;
        private CmCheckVoidingExtractACHBatchHeaderRecord aACHBatchHeaderRecord;
        private CmCheckVoidingExtractACHPpdEntryDetailRecord aACHPPDEntryDetailRecord;
        private CmCheckVoidingExtractACHBatchControlRecord aACHBatchControlRecord;
        private CmCheckVoidingExtractACHFileControlRecord aACHFileControlRecord;
        private CmCheckVoidingExtractACHFooterRecord aACHFooterRecord;

        private CmCheckVoidingExtractVoidingFileRecord gVoidingFileRecord;
        private CmCheckVoidingExtractACHFileHeaderRecord gACHFileHeaderRecord;
        private CmCheckVoidingExtractACHBatchHeaderRecord gACHBatchHeaderRecord;
        private CmCheckVoidingExtractACHPpdEntryDetailRecord gACHPPDEntryDetailRecord;
        private CmCheckVoidingExtractACHBatchControlRecord gACHBatchControlRecord;
        private CmCheckVoidingExtractACHFileControlRecord gACHFileControlRecord;
        private CmCheckVoidingExtractACHFooterRecord gACHFooterRecord;

        // Constants
        private static final String CIS_DIVISION_LGC = "LGC";
        private static final String CIS_DIVISION_MGE = "MGE";
        private static final String CIS_DIVISION_AL = "200";
        private static final String CIS_DIVISION_GF = "203";

        private static final String ZERO = "0";
        private static final String BLANK = " ";
        private static final String THREE_SPACE_BLANK = "   ";
        private static final String V_FILLER = "V";

        private static final String RECORD_TYPE_FILE_HDR = "1";
        private static final String PRIO_CD = "01";
        private static final String IMMEDIATE_DESTINATION = " 062000019";
        private static final String IMMEDIATE_ORIGIN = "1630022000";
        private static final String FILE_ID_MODIFIER = "A";
        private static final String RECORD_SIZE = "094";
        private static final String BLOCKING_FACTOR = "10";
        private static final String FORMAT_CODE = "1";
        private static final String IMMEDIATE_DESTINATION_NAME = "REGIONS BANK";
        private static final String IMMEDIATE_ORIGIN_NAME_ALABAMA = "SPIRE ALABAMA";
        private static final String IMMEDIATE_ORIGIN_NAME_GULF = "SPIRE GULF";
        private static final String REFERENCE_CODE = "        ";

        private static final String RECORD_TYPE_BATCH_HDR = "5";
        private static final String SERVICE_CLASS_CD = "225";
        private static final String COMPANY_NAME_ALABAMA = "Spire Alabama";
        private static final String COMPANY_NAME_GULF = "Spire Gulf";
        private static final String DISCRETIONARY_DATA = "                    ";
        private static final String COMPANY_IDENTIFICATION_ALABAMA = "1630022000";
        private static final String COMPANY_IDENTIFICATION_GULF = "1630142930";
        private static final String STANDARD_ENTRY_CLASS = "PPD";
        private static final String COMPANY_ENTRY_DESCR = "PAYABLE";
        private static final String RESERVED_FIELD = "   ";
        private static final String ORIGINATOR_STATUS_CD = "1";
        private static final String ORIGINATING_FINANCIAL_INSTITUTION = "06200001";
        private static final String BATCH_NBR = "0000001";

        private static final String RECORD_TYPE_PPD = "6";
        private static final String TRANSACTION_CD = "27";
        private static final String RECEIVING_DFI_IDENTIFICATION = "10100001";
        private static final String CHECK_DIGIT = "9";
        private static final String DFI_ACCT_NBR_ALABAMA = "165516195";
        private static final String DFI_ACCT_NBR_GULF = "174301207";
        private static final String INDIE_ID_NBR_ALABAMA = "183555";
        private static final String INDIE_ID_NBR_GULF = "101903780";
        private static final String INDIE_NAME_ALABAMA = "SPIRE ALABAMA";
        private static final String INDIE_NAME_GULF = "SPIRE GULF";
        private static final String DISCRETIONARY_DATA_2 = "  ";
        private static final String ADDENDA_RECORD_INDICATOR = "0";
        private static final String TRACE_NUMBER = "000000000000001";

        private static final String RECORD_TYPE_BATCH_CTRL = "8";
        private static final String ENTRY_ADDENDA_COUNT = "000001";
        private static final String ENTRY_HASH = "0010100001";
        private static final String TOT_DEBIT_ENTRY_DOLLAR_AMT = "000000000000";
        private static final String MESSAGE_AUTH_CD = " ";
        private static final String RESERVED_FIELD_2 = " ";
        private static final String ORIGINATING_DFI_ID = "06200001";

        private static final String RECORD_TYPE_FILE_CTRL = "9";
        private static final String BATCH_COUNT = "000001";
        private static final String BLOCK_COUNT = "000010";
        private static final String ENTRY_ADDENDA_COUNT_2 = "00000001";

        private static final String FOOTER = "9999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999";

        private static final BigDecimal ONE_HUNDRED = new BigDecimal(100); 
        private static final String CM_LGC_CHECK_NUMBER_SEQ = "CM_LGC_CHECK_NUMBER_SEQ";
        private static final String CM_MGE_CHECK_NUMBER_SEQ = "CM_MGE_CHECK_NUMBER_SEQ";
        private static final String CM_AL_CHECK_NUMBER_SEQ = "CM_AL_CHECK_NUMBER_SEQ";
        private static final String CM_GL_CHECK_NUMBER_SEQ = "CM_GL_CHECK_NUMBER_SEQ";

        private static final DateFormat FORMAT_MMDDYY = new DateFormat("MMddyy");
        private static final DateFormat FORMAT_YYMMDD = new DateFormat("yyMMdd");
        private static final DateFormat FORMAT_HHMM = new DateFormat("hhmm");

        private static final String COMMA = ",";

        // Constants
        private static final String XACP_FEAT_CONFG = "CM_ADJCHPRM";
        private static String SPIRE_ACCT_NO_AL = "";
        private static String SPIRE_ACCT_NO_GF = "";
        private static String SPIRE_ACCT_NO_MO = "";

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new SingleTransactionStrategy(this);
        }

        @Override
        public void initializeThreadWork(
                boolean initializationPreviouslySuccessful){
            // Retrieve Batch Parameters
            parmFilePath = getParameters().getFILE_PATH();
            parmMissouriVoidingFileName = getParameters().getMISSOURI_VOID_FILE_NAME();
            parmAlabamaVoidingFileName = getParameters().getALABAMA_VOID_FILE_NAME();
            parmGulfVoidingFileName = getParameters().getGULF_VOID_FILE_NAME();
            parmAlabamaACHFileName = getParameters().getALABAMA_ACH_FILE_NAME();
            parmGulfACHFileName = getParameters().getGULF_ACH_FILE_NAME();
            //Start Add JVitug - E-04899.2 - 2023-06-02
            extractEscheatedCharacteristicType  = getParameters().getEXT_ESC_CHECK_CHAR_TYPE();
            extractEscheatedCharacteristicValue = getParameters().getEXT_ESC_CHECK_CHAR_VAL();
            //End Add JVitug - E-04899.2 - 2023-06-02

            // Initialize file flags - initialize/create the file if there is at 
            // least 1 record extracted for the respective CIS Division
            isInitializedMoFile = Bool.FALSE;
            isInitializedAlFile = Bool.FALSE;
            isInitializedGlFile = Bool.FALSE;

            // Create Files
            voidingFileMissouri = new File(parmFilePath, parmMissouriVoidingFileName);

            voidingFileAlabama = new File(parmFilePath, parmAlabamaVoidingFileName);
            achFileAlabama = new File(parmFilePath, parmAlabamaACHFileName);

            voidingFileGulf = new File(parmFilePath, parmGulfVoidingFileName);
            achFileGulf = new File(parmFilePath, parmGulfACHFileName);

            // Initialize Records
            mVoidingFileRecord = new CmCheckVoidingExtractVoidingFileRecord();

            aVoidingFileRecord = new CmCheckVoidingExtractVoidingFileRecord();
            aACHFileHeaderRecord = new CmCheckVoidingExtractACHFileHeaderRecord();
            aACHBatchHeaderRecord = new CmCheckVoidingExtractACHBatchHeaderRecord();
            aACHPPDEntryDetailRecord = new CmCheckVoidingExtractACHPpdEntryDetailRecord();
            aACHBatchControlRecord = new CmCheckVoidingExtractACHBatchControlRecord();
            aACHFileControlRecord = new CmCheckVoidingExtractACHFileControlRecord();
            gACHFooterRecord = new CmCheckVoidingExtractACHFooterRecord();

            gVoidingFileRecord = new CmCheckVoidingExtractVoidingFileRecord();
            gACHFileHeaderRecord = new CmCheckVoidingExtractACHFileHeaderRecord();
            gACHBatchHeaderRecord = new CmCheckVoidingExtractACHBatchHeaderRecord();
            gACHPPDEntryDetailRecord = new CmCheckVoidingExtractACHPpdEntryDetailRecord();
            gACHBatchControlRecord = new CmCheckVoidingExtractACHBatchControlRecord();
            gACHFileControlRecord = new CmCheckVoidingExtractACHFileControlRecord();
            aACHFooterRecord = new CmCheckVoidingExtractACHFooterRecord();

            aTotalCheckAmount = BigDecimal.ZERO;
            gTotalCheckAmount = BigDecimal.ZERO;

        }

        private void initializeMissouriVoidingFile(){
            try{
                bwVoidingFileMissouri = new BufferedWriter(new FileWriter(voidingFileMissouri));
            } catch (IOException e) {
                addError(CustomMessageRepositorySpireOne.CCB041_3_errorWritingFile(e.getMessage()));
                e.printStackTrace();
            }
            isInitializedMoFile = Bool.TRUE;
        }

        private void initializeAlabamaVoidingFile(){
            try{
                bwVoidingFileAlabama = new BufferedWriter(new FileWriter(voidingFileAlabama));
            } catch (IOException e) {
                addError(CustomMessageRepositorySpireOne.CCB041_3_errorWritingFile(e.getMessage()));
                e.printStackTrace();
            }
            isInitializedAlFile = Bool.TRUE;
        }

        private void initializeVoidingGulfFile(){
            try{
                bwVoidingFileGulf = new BufferedWriter(new FileWriter(voidingFileGulf));
            } catch (IOException e) {
                addError(CustomMessageRepositorySpireOne.CCB041_3_errorWritingFile(e.getMessage()));
                e.printStackTrace();
            }
            isInitializedGlFile = Bool.TRUE;
        }

        /*private BigInteger getNextCheckNumberSequence(String dbSequence){

            BigInteger returnValue = null;

            StringBuilder queryString = new StringBuilder();
            queryString.append("SELECT ");
            queryString.append( dbSequence + ".NEXTVAL ");
            queryString.append( "AS CHECK_NUMBER ");
            queryString.append("FROM DUAL ");

            PreparedStatement getNextSeqenceSQL = createPreparedStatement(queryString.toString(), "getNexhtCheckNumberSequence");
            returnValue = getNextSeqenceSQL.firstRow().getInteger("CHECK_NUMBER");
            getNextSeqenceSQL.close();

            return returnValue;
        }*/

        private void retrieveBankDetailVariables(){
            CmFeatureConfigurationRetriever_Impl featConfigRetriever = new CmFeatureConfigurationRetriever_Impl();
            FeatureConfiguration_Id featConfigId = new FeatureConfiguration_Id(XACP_FEAT_CONFG);
            featConfigRetriever.setParmWFMName(featConfigId.getEntity());

            //Bank Details
            featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_MO_BANK_ACCOUNT_NO.value());
            SPIRE_ACCT_NO_MO = featConfigRetriever.getMaxSequenceOptionValue().trim();
            if (isBlankOrNull(SPIRE_ACCT_NO_MO)){
                addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Missouri Bank Account Number"));
            }

            featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_AL_BANK_ACCOUNT_NO.value());
            SPIRE_ACCT_NO_AL = featConfigRetriever.getMaxSequenceOptionValue().trim();
            if (isBlankOrNull(SPIRE_ACCT_NO_AL)){
                addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Alabama Bank Account Number"));
            }

            featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_GF_BANK_ACCOUNT_NO.value());
            SPIRE_ACCT_NO_GF = featConfigRetriever.getMaxSequenceOptionValue().trim();
            if (isBlankOrNull(SPIRE_ACCT_NO_GF)){
                addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Gulf Bank Account Number"));
            }
        }


        public boolean executeWorkUnit(ThreadWorkUnit threadWorkUnit)
                throws ThreadAbortedException, RunAbortedException {

            Adjustment_Id adjId = (Adjustment_Id) threadWorkUnit.getSupplementallData("ADJ_ID");
            
            ApCheckRequest_Id apRequestId = (ApCheckRequest_Id) threadWorkUnit.getPrimaryId();
            
            ApCheckRequest apRequest = apRequestId.getEntity();
            //Start Add JVitug - E-04899.2 - 2023-06-02
            PaymentSelectionStatusLookup paymentSelectionStatus = (PaymentSelectionStatusLookup) threadWorkUnit.
                    getSupplementallData("PYMNT_SEL_STAT_FLG");
            //Start Add JVitug - E-04899.2 - 2023-06-02

            //retrieve bank details
            retrieveBankDetailVariables();

            CisDivision_Id cisDivisionId = (CisDivision_Id) threadWorkUnit.getSupplementallData("CISDIVISION");

            BigDecimal adjustmentAmount = apRequest.getAdjustmentId().getEntity().getCurrentAmount().getAmount();

            StringBuilder payeeNameAndAddressStringBuilder = new StringBuilder();
            // Split last name and first name, if applicable. 
            String lastName = "";
            String firstName = "";
            Integer index = 0;
            String entityName = apRequest.getEntityName();
            index = entityName.indexOf(COMMA);
            if(index > 0){
                lastName = entityName.substring(0,index).trim();
                firstName = entityName.substring(index+1).trim();
                payeeNameAndAddressStringBuilder.append(firstName + BLANK);
                payeeNameAndAddressStringBuilder.append(lastName + BLANK);

            } else{
                payeeNameAndAddressStringBuilder.append(apRequest.getEntityName().trim() + BLANK);
            }
            payeeNameAndAddressStringBuilder.append(apRequest.getAddress1().trim() + BLANK);
            payeeNameAndAddressStringBuilder.append(apRequest.getCity().trim() + BLANK);
            payeeNameAndAddressStringBuilder.append(apRequest.getStateId().getState().toString().trim() + BLANK);
            payeeNameAndAddressStringBuilder.append(apRequest.getPostal().trim() + BLANK);
            payeeNameAndAddressStringBuilder.append(apRequest.getCountryId().getIdValue().toString().trim() + BLANK);

            
            
            // Update A/P Request Payment Selection Status to canceled
            ApCheckRequest_DTO apRequestDto = apRequest.getDTO();
            
            //Start Add JVitug - E-04899.2 - 2023-06-02
            if(paymentSelectionStatus.isRequestedForPayment()) {    
            //End Add JVitug - E-04899.2 - 2023-06-02
                apRequestDto.setPaymentSelectionStatus(PaymentSelectionStatusLookup.constants.CANCELED);
                apRequest.setDTO(apRequestDto);

                // Update Adjustment to canceled status
                //Start Change - JLumbre - 2021-09-09 - QAC#4594194
                /*Adjustment_DTO adjustmentDTO = adjId.getEntity().getDTO();
                adjustmentDTO.setCancelReasonId(getParameters().getADJ_CANCEL_REASON().getId());
                adjustmentDTO.setAdjustmentStatus(AdjustmentStatusLookup.constants.CANCELED);
                adjId.getEntity().setDTO(adjustmentDTO);*/
                adjId.getEntity().cancel(getParameters().getADJ_CANCEL_REASON());
                //End Change - JLumbre - 2021-09-09 - QAC#4594194
                
            //Start Add JVitug - E-04899.2 - 2023-06-02
            }  else if (paymentSelectionStatus.isConvertError() || paymentSelectionStatus.isNegativeVoucherSum()) {
                //Convert Error lookup status from the Payment Selection Status lookup 
                //is recycled to be the Escheated status and the Negative Voucher Sum is recycled as the Eligible for Escheated status
                //Add the Escheated characteristic if it does not exist in the Adjustment
                createEscheatedAdjustmentCharacteristic(adjId.getEntity());
            }
            //End Add JVitug - E-04899.2 - 2023-06-02

            // Write Missouri Voiding File
            if (cisDivisionId.getTrimmedValue().equalsIgnoreCase(CIS_DIVISION_LGC)
                    || cisDivisionId.getTrimmedValue().equalsIgnoreCase(CIS_DIVISION_MGE)){
                /*if (cisDivisionId.getTrimmedValue().equalsIgnoreCase(CIS_DIVISION_LGC)){
                    checkNumber = getNextCheckNumberSequence(CM_LGC_CHECK_NUMBER_SEQ);
                }
                else {
                    checkNumber = getNextCheckNumberSequence(CM_MGE_CHECK_NUMBER_SEQ);
                }*/

                // Initialize the MO file once
                if(isInitializedMoFile.isFalse()){
                    initializeMissouriVoidingFile();
                }

                try{
                    mVoidingFileRecord.setSpace(ZERO);
                    if (SPIRE_ACCT_NO_MO.length() == 10){
                        mVoidingFileRecord.setAccountNumber(SPIRE_ACCT_NO_MO);
                    }else{
                        mVoidingFileRecord.setAccountNumber(SPIRE_ACCT_NO_MO.substring(2, SPIRE_ACCT_NO_MO.length()));
                    }
                    //mVoidingFileRecord.setCheckNumber(checkNumber.toString());
                    mVoidingFileRecord.setCheckNumber(apRequestDto.getPaymentNumber().trim());
                    //mVoidingFileRecord.setOneSpaceBlankFieldFiller(ZERO);
                    mVoidingFileRecord.setAmount(adjustmentAmount.multiply(ONE_HUNDRED).abs().format(10, 0).trim());
                    mVoidingFileRecord.setDateField(getSystemDateTime().getDate().toString(FORMAT_MMDDYY));
                    mVoidingFileRecord.setThreeSpaceBlankFieldFiller(THREE_SPACE_BLANK);
                    mVoidingFileRecord.setVfiller(V_FILLER);
                    mVoidingFileRecord.setPayeeNameAndAddress(payeeNameAndAddressStringBuilder.toString());

                    bwVoidingFileMissouri.write(mVoidingFileRecord.createRecordString());
                    bwVoidingFileMissouri.newLine();

                } catch (IOException e) {
                    addError(CustomMessageRepositorySpireOne.CCB041_3_errorWritingFile(e.getMessage()));
                    e.printStackTrace();
                }
            }
            // Write Alabama Voiding File 
            else if (cisDivisionId.getTrimmedValue().equalsIgnoreCase(CIS_DIVISION_AL)){
                //checkNumber = getNextCheckNumberSequence(CM_AL_CHECK_NUMBER_SEQ);
                // Initialize the AL file once
                if(isInitializedAlFile.isFalse()){
                    initializeAlabamaVoidingFile();
                }
                try{
                    aVoidingFileRecord.setSpace(ZERO);
                    aVoidingFileRecord.setAccountNumber(SPIRE_ACCT_NO_AL);
                    aVoidingFileRecord.setCheckNumber(apRequestDto.getPaymentNumber().trim());
                    //aVoidingFileRecord.setOneSpaceBlankFieldFiller(ZERO);
                    aVoidingFileRecord.setAmount(adjustmentAmount.multiply(ONE_HUNDRED).abs().format(10, 0).trim());
                    aVoidingFileRecord.setDateField(getSystemDateTime().getDate().toString(FORMAT_MMDDYY));
                    aVoidingFileRecord.setThreeSpaceBlankFieldFiller(THREE_SPACE_BLANK);
                    aVoidingFileRecord.setVfiller(V_FILLER);
                    aVoidingFileRecord.setPayeeNameAndAddress(payeeNameAndAddressStringBuilder.toString());

                    bwVoidingFileAlabama.write(aVoidingFileRecord.createRecordString());
                    bwVoidingFileAlabama.newLine();

                    aTotalCheckAmount = aTotalCheckAmount.add(adjustmentAmount);

                } catch (IOException e) {
                    addError(CustomMessageRepositorySpireOne.CCB041_3_errorWritingFile(e.getMessage()));
                    e.printStackTrace();
                }
            }
            // Write Gulf Voiding File
            else if (cisDivisionId.getTrimmedValue().equalsIgnoreCase(CIS_DIVISION_GF)){
                //checkNumber = getNextCheckNumberSequence(CM_GL_CHECK_NUMBER_SEQ);
                // Initialize the AL file once
                if(isInitializedGlFile.isFalse()){
                    initializeVoidingGulfFile();
                }
                try{
                    gVoidingFileRecord.setSpace(ZERO);
                    gVoidingFileRecord.setAccountNumber(SPIRE_ACCT_NO_GF);
                    gVoidingFileRecord.setCheckNumber(apRequestDto.getPaymentNumber().trim());
                    //gVoidingFileRecord.setOneSpaceBlankFieldFiller(ZERO);
                    gVoidingFileRecord.setAmount(adjustmentAmount.multiply(ONE_HUNDRED).abs().format(10, 0).trim());
                    gVoidingFileRecord.setDateField(getSystemDateTime().getDate().toString(FORMAT_MMDDYY));
                    gVoidingFileRecord.setThreeSpaceBlankFieldFiller(THREE_SPACE_BLANK);
                    gVoidingFileRecord.setVfiller(V_FILLER);
                    gVoidingFileRecord.setPayeeNameAndAddress(payeeNameAndAddressStringBuilder.toString());

                    bwVoidingFileGulf.write(gVoidingFileRecord.createRecordString());
                    bwVoidingFileGulf.newLine();

                    gTotalCheckAmount = gTotalCheckAmount.add(adjustmentAmount);

                } catch (IOException e) {
                    addError(CustomMessageRepositorySpireOne.CCB041_3_errorWritingFile(e.getMessage()));
                    e.printStackTrace();
                }
            }

            return true;
        }
        
        //Start Add JVitug - E-04899.2 - 2023-06-02
        /**
         * This method will add the Escheated characteristic status only if the adjustment being processed
         * does not have the Escheated characteristic yet
         * @param adjustment
         */
        private void createEscheatedAdjustmentCharacteristic(Adjustment adjustment){
            AdjustmentCharacteristics adjustmentCharacteristics = adjustment.getCharacteristics();
            ListFilter<AdjustmentCharacteristic> faCharFilter = adjustmentCharacteristics.
                    createFilter("where this.id.characteristicType = :charType " +
                    "order by this.id.sequence desc" , getClass().getName());
            faCharFilter.bindId("charType", extractEscheatedCharacteristicType.getId());

            AdjustmentCharacteristic latestCharOfSameCharType = faCharFilter.firstRow();
            
            //Only add the characteristic if the Escheated characteristic does not exist
            if(isNull(latestCharOfSameCharType)) {
                AdjustmentCharacteristic_DTO adjustmentCharDTO = adjustmentCharacteristics.newChildDTO();
                adjustmentCharDTO.setId(new AdjustmentCharacteristic_Id(extractEscheatedCharacteristicType, adjustment, BigInteger.ONE));

                CharacteristicTypeLookup charTypeLookup = extractEscheatedCharacteristicType.getCharacteristicType();
                
                if(charTypeLookup.isAdhocValue()){
                    adjustmentCharDTO.setAdhocCharacteristicValue(extractEscheatedCharacteristicValue);
                } else if (charTypeLookup.isPredefinedValue()){
                    adjustmentCharDTO.setCharacteristicValue(extractEscheatedCharacteristicValue);
                } else if (charTypeLookup.isForeignKeyValue()){
                    adjustmentCharDTO.setCharacteristicValueForeignKey1(extractEscheatedCharacteristicValue);
                }
                
                AdjustmentCharacteristic adjChar = adjustmentCharDTO.newEntity();
                adjustmentCharacteristics.add(adjChar); 
            }
        }
        //End Add JVitug - E-04899.2 - 2023-06-02

        @Override
        public void finalizeThreadWork() throws ThreadAbortedException,
        RunAbortedException {
            // Close Missouri Voiding File
            if(isInitializedMoFile.isTrue()){
                if (bwVoidingFileMissouri != null) {
                    try {
                        bwVoidingFileMissouri.close();
                    } catch (IOException e) {
                        addError(CustomMessageRepositorySpireOne.CCB041_3_errorClosingFile(e.getMessage()));
                        e.printStackTrace();
                    }
                }
            }

            // Close Alabama Voiding File
            if(isInitializedAlFile.isTrue()){
                if (bwVoidingFileAlabama != null) {
                    try {
                        bwVoidingFileAlabama.close();
                    } catch (IOException e) {
                        addError(CustomMessageRepositorySpireOne.CCB041_3_errorClosingFile(e.getMessage()));
                        e.printStackTrace();
                    }
                }
            }

            // Close Gulf Voiding File
            if(isInitializedGlFile.isTrue()){
                if (bwVoidingFileGulf != null) {
                    try {
                        bwVoidingFileGulf.close();
                    } catch (IOException e) {
                        addError(CustomMessageRepositorySpireOne.CCB041_3_errorClosingFile(e.getMessage()));
                        e.printStackTrace();
                    }
                }
            }

            // Write Alabama ACH File
            if(isInitializedAlFile.isTrue()){
                try {
                    bwACHAlabama = new BufferedWriter(new FileWriter(achFileAlabama));

                    // File Header Record
                    aACHFileHeaderRecord.setRecordTypeCode(RECORD_TYPE_FILE_HDR);
                    aACHFileHeaderRecord.setPriorityCode(PRIO_CD);
                    aACHFileHeaderRecord.setImmediateDestination(IMMEDIATE_DESTINATION);
                    aACHFileHeaderRecord.setImmediateOrigin(IMMEDIATE_ORIGIN);
                    aACHFileHeaderRecord.setFileCreationDate(getSystemDateTime().getDate().toString(FORMAT_YYMMDD));
                    aACHFileHeaderRecord.setFileCreationTime(getSystemDateTime().getDate().toString(FORMAT_HHMM));
                    aACHFileHeaderRecord.setFileIdModifier(FILE_ID_MODIFIER);
                    aACHFileHeaderRecord.setRecordSize(RECORD_SIZE);
                    aACHFileHeaderRecord.setBlockingFactor(BLOCKING_FACTOR);
                    aACHFileHeaderRecord.setFormatCode(FORMAT_CODE);
                    aACHFileHeaderRecord.setImmediateDestinationName(IMMEDIATE_DESTINATION_NAME);
                    aACHFileHeaderRecord.setImmediateOriginName(IMMEDIATE_ORIGIN_NAME_ALABAMA);
                    aACHFileHeaderRecord.setReferenceCode(REFERENCE_CODE);      
                    bwACHAlabama.write(aACHFileHeaderRecord.createRecordString());
                    bwACHAlabama.newLine();

                    // Batch Header Record
                    aACHBatchHeaderRecord.setRecordTypeCode(RECORD_TYPE_BATCH_HDR);
                    aACHBatchHeaderRecord.setServiceClassCode(SERVICE_CLASS_CD);
                    aACHBatchHeaderRecord.setCompanyName(COMPANY_NAME_ALABAMA);
                    aACHBatchHeaderRecord.setDiscretionaryData(DISCRETIONARY_DATA);
                    aACHBatchHeaderRecord.setCompanyIdentification(COMPANY_IDENTIFICATION_ALABAMA);
                    aACHBatchHeaderRecord.setStandardEntryClass(STANDARD_ENTRY_CLASS);
                    aACHBatchHeaderRecord.setCompanyEntryDescription(COMPANY_ENTRY_DESCR);
                    aACHBatchHeaderRecord.setCompanyDescriptiveDate(getSystemDateTime().getDate().toString(FORMAT_YYMMDD));
                    aACHBatchHeaderRecord.setEffectiveEntryDate(getSystemDateTime().getDate().toString(FORMAT_YYMMDD));
                    aACHBatchHeaderRecord.setReservedField(RESERVED_FIELD);
                    aACHBatchHeaderRecord.setOriginatorStatusCode(ORIGINATOR_STATUS_CD);
                    aACHBatchHeaderRecord.setOriginatingFinancialInstitution(ORIGINATING_FINANCIAL_INSTITUTION);
                    aACHBatchHeaderRecord.setBatchNumber(BATCH_NBR);
                    bwACHAlabama.write(aACHBatchHeaderRecord.createRecordString());
                    bwACHAlabama.newLine();

                    // PPD Entry Detail Record
                    aACHPPDEntryDetailRecord.setRecordTypeCode(RECORD_TYPE_PPD);
                    aACHPPDEntryDetailRecord.setTransactionCode(TRANSACTION_CD);
                    aACHPPDEntryDetailRecord.setReceivingDFIIdentification(RECEIVING_DFI_IDENTIFICATION);
                    aACHPPDEntryDetailRecord.setCheckDigit(CHECK_DIGIT);
                    aACHPPDEntryDetailRecord.setDFIAccountNumber(DFI_ACCT_NBR_ALABAMA);
                    aACHPPDEntryDetailRecord.setAmount(aTotalCheckAmount.multiply(ONE_HUNDRED).abs().format(12, 0).trim());
                    aACHPPDEntryDetailRecord.setIndividualIdentificationNumber(INDIE_ID_NBR_ALABAMA);
                    aACHPPDEntryDetailRecord.setIndividualName(INDIE_NAME_ALABAMA);
                    aACHPPDEntryDetailRecord.setDiscretionaryData(DISCRETIONARY_DATA_2);
                    aACHPPDEntryDetailRecord.setAddendaRecordIndicator(ADDENDA_RECORD_INDICATOR);
                    aACHPPDEntryDetailRecord.setTraceNumber(TRACE_NUMBER);
                    bwACHAlabama.write(aACHPPDEntryDetailRecord.createRecordString());
                    bwACHAlabama.newLine();

                    // Batch Control Record
                    aACHBatchControlRecord.setRecordTypeCode(RECORD_TYPE_BATCH_CTRL);
                    aACHBatchControlRecord.setServiceClassCode(SERVICE_CLASS_CD);
                    aACHBatchControlRecord.setEntryAddendaCount(ENTRY_ADDENDA_COUNT);
                    aACHBatchControlRecord.setEntryHash(ENTRY_HASH);
                    //Start Change - JLumbre - 2021-12-14 - Mercury#47156
                    //aACHBatchControlRecord.setTotalDebitEntryDollarAmt(TOT_DEBIT_ENTRY_DOLLAR_AMT);
                    //aACHBatchControlRecord.setTotalCreditEntryDollarAmt(aTotalCheckAmount.multiply(ONE_HUNDRED).abs().format(12, 0).trim());
                    aACHBatchControlRecord.setTotalDebitEntryDollarAmt(aTotalCheckAmount.multiply(ONE_HUNDRED).abs().format(12, 0).trim());
                    aACHBatchControlRecord.setTotalCreditEntryDollarAmt(TOT_DEBIT_ENTRY_DOLLAR_AMT);
                    //End Change - JLumbre - 2021-12-14 - Mercury#47156
                    aACHBatchControlRecord.setCompanyIdentification(COMPANY_IDENTIFICATION_ALABAMA);
                    aACHBatchControlRecord.setMessageAuthCode(MESSAGE_AUTH_CD);
                    aACHBatchControlRecord.setReservedField(RESERVED_FIELD_2);
                    aACHBatchControlRecord.setOriginatingDFIIdentification(ORIGINATING_DFI_ID);
                    aACHBatchControlRecord.setBatchNumber(BATCH_NBR);
                    bwACHAlabama.write(aACHBatchControlRecord.createRecordString());
                    bwACHAlabama.newLine();

                    // File Control Record
                    aACHFileControlRecord.setRecordTypeCode(RECORD_TYPE_FILE_CTRL);
                    aACHFileControlRecord.setBatchCount(BATCH_COUNT);
                    aACHFileControlRecord.setBlockCount(BLOCK_COUNT);
                    aACHFileControlRecord.setEntryAddendaCount(ENTRY_ADDENDA_COUNT_2);
                    aACHFileControlRecord.setEntryHash(ENTRY_HASH);
                    //Start Change - JLumbre - 2021-12-14 - Mercury#47156                   
                    //aACHFileControlRecord.setTotalDebitEntryDollarAmtInFile(TOT_DEBIT_ENTRY_DOLLAR_AMT);
                    //aACHFileControlRecord.setTotalCreditEntryDollarAmtInFile(aTotalCheckAmount.multiply(ONE_HUNDRED).abs().format(12, 0).trim());
                    aACHFileControlRecord.setTotalDebitEntryDollarAmtInFile(aTotalCheckAmount.multiply(ONE_HUNDRED).abs().format(12, 0).trim());
                    aACHFileControlRecord.setTotalCreditEntryDollarAmtInFile(TOT_DEBIT_ENTRY_DOLLAR_AMT);
                    //End Change - JLumbre - 2021-12-14 - Mercury#47156
                    aACHFileControlRecord.setReservedField(RESERVED_FIELD_2);
                    bwACHAlabama.write(aACHFileControlRecord.createRecordString());
                    bwACHAlabama.newLine();

                    // Footer Records
                    aACHFooterRecord.setFooterValue(FOOTER);
                    bwACHAlabama.write(aACHFooterRecord.createRecordString());
                    bwACHAlabama.newLine();
                    aACHFooterRecord.setFooterValue(FOOTER);
                    bwACHAlabama.write(aACHFooterRecord.createRecordString());
                    bwACHAlabama.newLine();
                    aACHFooterRecord.setFooterValue(FOOTER);
                    bwACHAlabama.write(aACHFooterRecord.createRecordString());
                    bwACHAlabama.newLine();
                    aACHFooterRecord.setFooterValue(FOOTER);
                    bwACHAlabama.write(aACHFooterRecord.createRecordString());
                    bwACHAlabama.newLine();
                    aACHFooterRecord.setFooterValue(FOOTER);
                    bwACHAlabama.write(aACHFooterRecord.createRecordString());
                    bwACHAlabama.newLine();

                } catch (IOException e) {
                    addError(CustomMessageRepositorySpireOne.CCB041_3_errorWritingFile(e.getMessage()));
                    e.printStackTrace(); 
                }
                finally {
                    if (bwACHAlabama != null) {
                        try {
                            bwACHAlabama.close();
                        } catch (IOException e) {
                            addError(CustomMessageRepositorySpireOne.CCB041_3_errorClosingFile(e.getMessage()));
                            e.printStackTrace();
                        }
                    }
                }
            }

            // Write Gulf ACH File
            if(isInitializedGlFile.isTrue()){
                try {
                    bwACHGulf = new BufferedWriter(new FileWriter(achFileGulf));

                    // File Header Record
                    gACHFileHeaderRecord.setRecordTypeCode(RECORD_TYPE_FILE_HDR);
                    gACHFileHeaderRecord.setPriorityCode(PRIO_CD);
                    gACHFileHeaderRecord.setImmediateDestination(IMMEDIATE_DESTINATION);
                    gACHFileHeaderRecord.setImmediateOrigin(IMMEDIATE_ORIGIN);
                    gACHFileHeaderRecord.setFileCreationDate(getSystemDateTime().getDate().toString(FORMAT_YYMMDD));
                    gACHFileHeaderRecord.setFileCreationTime(getSystemDateTime().getDate().toString(FORMAT_HHMM));
                    gACHFileHeaderRecord.setFileIdModifier(FILE_ID_MODIFIER);
                    gACHFileHeaderRecord.setRecordSize(RECORD_SIZE);
                    gACHFileHeaderRecord.setBlockingFactor(BLOCKING_FACTOR);
                    gACHFileHeaderRecord.setFormatCode(FORMAT_CODE);
                    gACHFileHeaderRecord.setImmediateDestinationName(IMMEDIATE_DESTINATION_NAME);
                    gACHFileHeaderRecord.setImmediateOriginName(IMMEDIATE_ORIGIN_NAME_GULF);
                    gACHFileHeaderRecord.setReferenceCode(REFERENCE_CODE);      
                    bwACHGulf.write(gACHFileHeaderRecord.createRecordString());
                    bwACHGulf.newLine();

                    // Batch Header Record
                    gACHBatchHeaderRecord.setRecordTypeCode(RECORD_TYPE_BATCH_HDR);
                    gACHBatchHeaderRecord.setServiceClassCode(SERVICE_CLASS_CD);
                    gACHBatchHeaderRecord.setCompanyName(COMPANY_NAME_GULF);
                    gACHBatchHeaderRecord.setDiscretionaryData(DISCRETIONARY_DATA);
                    gACHBatchHeaderRecord.setCompanyIdentification(COMPANY_IDENTIFICATION_GULF);
                    gACHBatchHeaderRecord.setStandardEntryClass(STANDARD_ENTRY_CLASS);
                    gACHBatchHeaderRecord.setCompanyEntryDescription(COMPANY_ENTRY_DESCR);
                    gACHBatchHeaderRecord.setCompanyDescriptiveDate(getSystemDateTime().getDate().toString(FORMAT_YYMMDD));
                    gACHBatchHeaderRecord.setEffectiveEntryDate(getSystemDateTime().getDate().toString(FORMAT_YYMMDD));
                    gACHBatchHeaderRecord.setReservedField(RESERVED_FIELD);
                    gACHBatchHeaderRecord.setOriginatorStatusCode(ORIGINATOR_STATUS_CD);
                    gACHBatchHeaderRecord.setOriginatingFinancialInstitution(ORIGINATING_FINANCIAL_INSTITUTION);
                    gACHBatchHeaderRecord.setBatchNumber(BATCH_NBR);
                    bwACHGulf.write(gACHBatchHeaderRecord.createRecordString());
                    bwACHGulf.newLine();

                    // PPD Entry Detail Record
                    gACHPPDEntryDetailRecord.setRecordTypeCode(RECORD_TYPE_PPD);
                    gACHPPDEntryDetailRecord.setTransactionCode(TRANSACTION_CD);
                    gACHPPDEntryDetailRecord.setReceivingDFIIdentification(RECEIVING_DFI_IDENTIFICATION);
                    gACHPPDEntryDetailRecord.setCheckDigit(CHECK_DIGIT);
                    gACHPPDEntryDetailRecord.setDFIAccountNumber(DFI_ACCT_NBR_GULF);
                    gACHPPDEntryDetailRecord.setAmount(gTotalCheckAmount.multiply(ONE_HUNDRED).abs().format(12, 0).trim());
                    gACHPPDEntryDetailRecord.setIndividualIdentificationNumber(INDIE_ID_NBR_GULF);
                    gACHPPDEntryDetailRecord.setIndividualName(INDIE_NAME_GULF);
                    gACHPPDEntryDetailRecord.setDiscretionaryData(DISCRETIONARY_DATA_2);
                    gACHPPDEntryDetailRecord.setAddendaRecordIndicator(ADDENDA_RECORD_INDICATOR);
                    gACHPPDEntryDetailRecord.setTraceNumber(TRACE_NUMBER);
                    bwACHGulf.write(gACHPPDEntryDetailRecord.createRecordString());
                    bwACHGulf.newLine();

                    // Batch Control Record
                    gACHBatchControlRecord.setRecordTypeCode(RECORD_TYPE_BATCH_CTRL);
                    gACHBatchControlRecord.setServiceClassCode(SERVICE_CLASS_CD);
                    gACHBatchControlRecord.setEntryAddendaCount(ENTRY_ADDENDA_COUNT);
                    gACHBatchControlRecord.setEntryHash(ENTRY_HASH);
                    //Start Change - JLumbre - 2021-12-14 - Mercury#47156
                    //gACHBatchControlRecord.setTotalDebitEntryDollarAmt(TOT_DEBIT_ENTRY_DOLLAR_AMT);
                    //gACHBatchControlRecord.setTotalCreditEntryDollarAmt(gTotalCheckAmount.multiply(ONE_HUNDRED).abs().format(12, 0).trim());              
                    gACHBatchControlRecord.setTotalDebitEntryDollarAmt(gTotalCheckAmount.multiply(ONE_HUNDRED).abs().format(12, 0).trim());
                    gACHBatchControlRecord.setTotalCreditEntryDollarAmt(TOT_DEBIT_ENTRY_DOLLAR_AMT);
                    //End Change - JLumbre - 2021-12-14 - Mercury#47156
                    gACHBatchControlRecord.setCompanyIdentification(COMPANY_IDENTIFICATION_GULF);
                    gACHBatchControlRecord.setMessageAuthCode(MESSAGE_AUTH_CD);
                    gACHBatchControlRecord.setReservedField(RESERVED_FIELD_2);
                    gACHBatchControlRecord.setOriginatingDFIIdentification(ORIGINATING_DFI_ID);
                    gACHBatchControlRecord.setBatchNumber(BATCH_NBR);
                    bwACHGulf.write(gACHBatchControlRecord.createRecordString());
                    bwACHGulf.newLine();

                    // File Control Record
                    gACHFileControlRecord.setRecordTypeCode(RECORD_TYPE_FILE_CTRL);
                    gACHFileControlRecord.setBatchCount(BATCH_COUNT);
                    gACHFileControlRecord.setBlockCount(BLOCK_COUNT);
                    gACHFileControlRecord.setEntryAddendaCount(ENTRY_ADDENDA_COUNT_2);
                    gACHFileControlRecord.setEntryHash(ENTRY_HASH);
                    //Start Change - JLumbre - 2021-12-14 - Mercury#47156
                    //gACHFileControlRecord.setTotalDebitEntryDollarAmtInFile(TOT_DEBIT_ENTRY_DOLLAR_AMT);
                    //gACHFileControlRecord.setTotalCreditEntryDollarAmtInFile(gTotalCheckAmount.multiply(ONE_HUNDRED).abs().format(12, 0).trim());
                    gACHFileControlRecord.setTotalDebitEntryDollarAmtInFile(gTotalCheckAmount.multiply(ONE_HUNDRED).abs().format(12, 0).trim());
                    gACHFileControlRecord.setTotalCreditEntryDollarAmtInFile(TOT_DEBIT_ENTRY_DOLLAR_AMT);
                    //End Change - JLumbre - 2021-12-14 - Mercury#47156
                    gACHFileControlRecord.setReservedField(RESERVED_FIELD_2);
                    bwACHGulf.write(gACHFileControlRecord.createRecordString());
                    bwACHGulf.newLine();

                    // Footer Records
                    gACHFooterRecord.setFooterValue(FOOTER);
                    bwACHGulf.write(gACHFooterRecord.createRecordString());
                    bwACHGulf.newLine();
                    gACHFooterRecord.setFooterValue(FOOTER);
                    bwACHGulf.write(gACHFooterRecord.createRecordString());
                    bwACHGulf.newLine();
                    gACHFooterRecord.setFooterValue(FOOTER);
                    bwACHGulf.write(gACHFooterRecord.createRecordString());
                    bwACHGulf.newLine();
                    gACHFooterRecord.setFooterValue(FOOTER);
                    bwACHGulf.write(gACHFooterRecord.createRecordString());
                    bwACHGulf.newLine();
                    gACHFooterRecord.setFooterValue(FOOTER);
                    bwACHGulf.write(gACHFooterRecord.createRecordString());
                    bwACHGulf.newLine();

                } catch (IOException e) {
                    addError(CustomMessageRepositorySpireOne.CCB041_3_errorWritingFile(e.getMessage()));
                    e.printStackTrace(); 
                }
                finally {
                    if (bwACHGulf != null) {
                        try {
                            bwACHGulf.close();
                        } catch (IOException e) {
                            addError(CustomMessageRepositorySpireOne.CCB041_3_errorClosingFile(e.getMessage()));
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }
}
