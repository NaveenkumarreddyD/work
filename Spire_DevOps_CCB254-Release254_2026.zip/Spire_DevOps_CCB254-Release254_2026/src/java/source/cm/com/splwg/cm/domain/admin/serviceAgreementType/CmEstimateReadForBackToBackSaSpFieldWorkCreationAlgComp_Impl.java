/* *************************************************************************************************
 * PROGRAM DESCRIPTION 
 *
 * CCB038.1 - SA/SP Estimated Back-to-Back Field Work Creation
 *
 * Description
 *
 * This algorithm will determine the type of field activities to be created for pending start 
 * and stop service agreements. Its basis is the SASP FW CRE algorithm type (CIPCSFWX), 
 * except that it can create an FA that will generate an estimated read for back-to-back services.
 *
 ***************************************************************************************************
 *
 * CHANGE HISTORY
 *
 * Date:        by:			Reason:
 * YYYY-MM-DD   IN        	Reason text.
 *
 * 2021-05-06   SRoman		CCB038.1. Initial version.
 * 2021-06-16   GCrisp		CCB038.Issue1. Estimation FA Type should be used instead of the one in 
 *							FA Type profile, even when the request is not back-to-back.
 * 2021-06-23   BMarquez    CCB038.Issue3. Stop services should use usual FA Type Profile.
 * 2021-08-03	JMeden		CCB038.Issue4. Updating the condition to consider SP start activity
 * 							if the date is not back to back.
 * 2021-09-23	JMeden		Defect 4595558. SP with completed Stop Service Activity will not be
 * 							applicable for Back to Back
 * 2022-01-04   DLampa      D-03066. Update to create the M-ESTMT FA for Alabama and Gulf.
 * 2022-08-03   Darryl/Jon  D-03066. Undo D-03306. add new logic
 * 2022-06-06   EQuint      SA401158. Only create estimate FA when activity type is stop and premise
 * 							has landlord agreement
 * 2022-08-03   Kiran       handle back to back to to determine correct FA's
 * 2023-03-29   Kiran       Ignore this alg for ADDP Route
 **************************************************************************************************/
package com.splwg.cm.domain.admin.serviceAgreementType;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.FieldActivityCreatedByLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.FieldActivitySystemDefaultLookup;
import com.splwg.ccb.api.lookup.FieldOrderStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementSpFaTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointFieldConditionLookup;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.entity.FieldActivityCancelReason;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.meterLocation.entity.MeterLocation;
import com.splwg.ccb.domain.admin.meterLocation.entity.MeterLocation_Id;
import com.splwg.ccb.domain.admin.meterReadCycle.entity.MeterReadRoute;
import com.splwg.ccb.domain.admin.meterReadCycle.entity.MeterReadRoute_Id;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saSpFieldWorkCreation.SaTypeSaSpFieldWorkCreationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.data.SaSpFieldActivityCreatorData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCancelProcessorData;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristics;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityRemark;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityRemark_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityRemark_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.cm.api.lookup.CustomerEventLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmCancelUnlinkFasOfSaSp;
import com.splwg.cm.domain.common.customBusinessComponent.CmCancelUnlinkFasOfSaSpData;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author SRoman
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = numberOfDaysLeadTime, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = backToBackThresholdDays, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = estimatedReadFieldActivityType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = servicePointFieldCondition, name = spsDesiredStateForMeterRead, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (name = excludeRouteTypes, type = string)
 *            , @AlgorithmSoftParameter (name = excludeMeterLocations, type = string)
 *            , @AlgorithmSoftParameter (name = immediateFaCreation, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = powerStatusSpCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = powerStatusCharVal, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityRemarkCode, name = faRemarkForCancelledFAs, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = customerRequestRealReadCharType, type = entity)
 *            , @AlgorithmSoftParameter (name = customerRequestRealReadCharVal, type = string)
 *            , @AlgorithmSoftParameter (name = excludeLogicForRouteTypes, type = string)})
 *
 */
public class CmEstimateReadForBackToBackSaSpFieldWorkCreationAlgComp_Impl
		extends CmEstimateReadForBackToBackSaSpFieldWorkCreationAlgComp_Gen
		implements SaTypeSaSpFieldWorkCreationAlgorithmSpot {
	
	private static final Logger logger= LoggerFactory.getLogger(CmEstimateReadForBackToBackSaSpFieldWorkCreationAlgComp_Impl.class);    
	
    // Constants
    private static final String COMMA_DELIMITER = ",";
    private static final String NEVER_CREATE_SINGLE_FA = "N";
    private static final String insideMeterLoc = "IN";
    // Hard parameters - input
    private ServiceAgreementSpFaTypeLookup saSpFieldActivityType;
    private DateTime saSpStartDateTime;
    private DateTime saSpStopDateTime;
    @SuppressWarnings("unused")
	private Date saStartDate;
    @SuppressWarnings("unused")
	private Date saStopDate;
    private ServiceAgreement serviceAgreement;
    private ServiceAgreementServicePoint serviceAgreementServicePoint;
    private ServicePoint servicePoint;
    private Bool shouldActivateManually;
    
    // Hard parameters - input/output
    private Bool isFaCreated;
    private Bool isAddp = Bool.FALSE;
    private FieldActivity fa1;
    private FieldActivity fa2;
    Bool hasCreatedFA2 =  Bool.FALSE;
    // Soft parameters
    private Bool neverCreateSingleFieldActivity = Bool.FALSE;
    private BigInteger backToBackThresholdDays;
    private List<MeterReadRouteType> excludedMeterReadRouteTypesList = new ArrayList<MeterReadRouteType>();
    private List<MeterLocation> excludedMeterLocationsList = new ArrayList<MeterLocation>();
    private List<String> realReadCharValuesList =  new ArrayList<String>();
    private Bool immediateFaCreation;
    private CharacteristicValue truePowerStatusCharVal;
    ServiceAgreementServicePoint futureStoppedPendingStopSASP;
    // Working variables
    private Bool isBackToBack = Bool.FALSE;
    private Bool hasCustRequestedRealReadChar = Bool.FALSE;
    private DateTime leastStopDateTime;
    private DateTime scheduleDateTime;
    private FieldActivityCancelReason saStartStopCanceledFaCancelReason = null;
  //  private List<MeterReadRouteType> excludedMeterReadRouteTypesList = new ArrayList<MeterReadRouteType>();
    private List<MeterReadRouteType> excludedLogicMeterReadRouteTypesList = new ArrayList<MeterReadRouteType>();
    // Common component
    private CmCancelUnlinkFasOfSaSp cancelUnlinkFasOfSaSp = CmCancelUnlinkFasOfSaSp.Factory.newInstance();

	@Override
	public Bool getIsFaCreated() {
		return this.isFaCreated;
	}

	@Override
	public void setFaCreated(Bool isFaCreated) {
		this.isFaCreated = isFaCreated;
	}

	@Override
	public void setSaSpFieldActivityType(ServiceAgreementSpFaTypeLookup saSpFieldActivityType) {
		this.saSpFieldActivityType = saSpFieldActivityType;
	}

	@Override
	public void setSaSpStartDateTime(DateTime saSpStartDateTime) {
		this.saSpStartDateTime = saSpStartDateTime;
	}

	@Override
	public void setSaSpStopDateTime(DateTime saSpStopDateTime) {
		this.saSpStopDateTime = saSpStopDateTime;
	}

	@Override
	public void setSaStartDate(Date saStartDate) {
		this.saStartDate = saStartDate;
	}

	@Override
	public void setSaStopDate(Date saStopDate) {
		this.saStopDate = saStopDate;
	}

	@Override
	public void setServiceAgreement(ServiceAgreement serviceAgreement) {
		this.serviceAgreement = serviceAgreement;
	}

	@Override
	public void setServiceAgreementServicePoint(
			ServiceAgreementServicePoint serviceAgreementServicePoint) {
		this.serviceAgreementServicePoint = serviceAgreementServicePoint;
	}

	@Override
	public void setServicePoint(ServicePoint servicePoint) {
		this.servicePoint = servicePoint;
	}

	@Override
	public void setShouldActivateManually(Bool shouldActivateManually) {
		this.shouldActivateManually = shouldActivateManually;
	}

	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        // Back to Back Threshold Days parameter can either be a string value "N" or an integer
        String backToBackThresholdDaysString = getBackToBackThresholdDays();
        logger.info(">>>>> 215" + backToBackThresholdDaysString);
        if (NEVER_CREATE_SINGLE_FA.equals(backToBackThresholdDaysString.trim())) {
            neverCreateSingleFieldActivity = Bool.TRUE;
        } else {
            try {
                backToBackThresholdDays = BigInteger.valueOf(Integer.parseInt(backToBackThresholdDaysString));
            } catch (NumberFormatException e) {
                addError(CustomMessageRepositorySpireOne.CCB038_1_invalidB2bThresholdDays(NEVER_CREATE_SINGLE_FA, getAlgorithm()));
            }
        }
        
        String excludeRouteTypes = getExcludeRouteTypes();
        if (notBlank(excludeRouteTypes)) {

            String[] excludeRouteTypeList = excludeRouteTypes.split(COMMA_DELIMITER);

            for (String excludedMeterReadRouteTypeIdString : excludeRouteTypeList) {

                if (excludedMeterReadRouteTypeIdString.trim().length() > MeterReadRouteType_Id.FIELD_SIZE) {
                    addError(CustomMessageRepositorySpireOne.CCB038_1_invalidRouteType(excludedMeterReadRouteTypeIdString, getAlgorithm()));
                }

                MeterReadRouteType_Id meterReadRouteTypeId = new MeterReadRouteType_Id(excludedMeterReadRouteTypeIdString.trim());
                if (isNull(meterReadRouteTypeId.getEntity())) {
                    addError(CustomMessageRepositorySpireOne.CCB038_1_invalidRouteType(excludedMeterReadRouteTypeIdString, getAlgorithm()));
                }

                excludedMeterReadRouteTypesList.add(meterReadRouteTypeId.getEntity());
            }
        }

        String excludeLogicForRouteTypes = getExcludeLogicForRouteTypes();
        if (notBlank(excludeLogicForRouteTypes)) {

            String[] excludeLogicForRouteTypesList = excludeLogicForRouteTypes.split(COMMA_DELIMITER);

            for (String excludeLogicMeterReadRouteTypeIdString : excludeLogicForRouteTypesList) {

                if (excludeLogicMeterReadRouteTypeIdString.trim().length() > MeterReadRouteType_Id.FIELD_SIZE) {
                    addError(CustomMessageRepositorySpireOne.CCB108_InvalidRouteType(
                    		excludeLogicMeterReadRouteTypeIdString, getAlgorithm()));
                }

                MeterReadRouteType_Id meterReadRouteTypeId = new MeterReadRouteType_Id(excludeLogicMeterReadRouteTypeIdString.trim());
                if (isNull(meterReadRouteTypeId.getEntity())) {
                    addError(CustomMessageRepositorySpireOne.CCB108_InvalidRouteType(
                    		excludeLogicMeterReadRouteTypeIdString, getAlgorithm()));
                }

                excludedLogicMeterReadRouteTypesList.add(meterReadRouteTypeId.getEntity());
            }
        }
        String excludeMeterLocations = getExcludeMeterLocations();
        if (notBlank(excludeMeterLocations)) {

            String[] excludeMeterLocationList = excludeMeterLocations.split(COMMA_DELIMITER);

            for (String excludedMeterLocationIdString : excludeMeterLocationList) {

                if (excludedMeterLocationIdString.trim().length() > MeterLocation_Id.FIELD_SIZE) {
                    addError(CustomMessageRepositorySpireOne.CCB038_1_invalidMeterLocation(excludedMeterLocationIdString, getAlgorithm()));
                }

                MeterLocation_Id meterLocationId = new MeterLocation_Id(excludedMeterLocationIdString.trim());
                if (isNull(meterLocationId.getEntity())) {
                    addError(CustomMessageRepositorySpireOne.CCB038_1_invalidMeterLocation(excludedMeterLocationIdString, getAlgorithm()));
                }
                
                excludedMeterLocationsList.add(meterLocationId.getEntity());
            }
        }

        immediateFaCreation = getImmediateFaCreation();

        CharacteristicValue_Id truePowerStatusCharValueId = new CharacteristicValue_Id(getPowerStatusSpCharType()
        		, getPowerStatusCharVal());
        if (isNull(truePowerStatusCharValueId.getEntity())) {
        	addError(CustomMessageRepositorySpireOne.CCB038_1_invalidPowerStatus(getPowerStatusSpCharType().getId().getTrimmedValue(), getAlgorithm()));
        }
        
        truePowerStatusCharVal = truePowerStatusCharValueId.getEntity();
        
        if(notNull(getCustomerRequestRealReadCharType())) {
        	if(isBlankOrNull(getCustomerRequestRealReadCharVal())) {
        		addError(CustomMessageRepositorySpireOne.CCB038_1_missingRealReadCharValue(getAlgorithm()));
        	} else {
        		String realReadCharValuesStr = getCustomerRequestRealReadCharVal();
                String[] realReadCharValueList = realReadCharValuesStr.split(COMMA_DELIMITER);

                for (String realReadCharValueStr : realReadCharValueList) {
                    CharacteristicValue_Id realReadCharValueId = new CharacteristicValue_Id(getCustomerRequestRealReadCharType(), realReadCharValueStr);
                    
                    if (isNull(realReadCharValueId.getEntity())) {
                    	addError(CustomMessageRepositorySpireOne.CCB038_1_invalidRealReadCharValue(realReadCharValueStr, getAlgorithm()));
                    }
                    
                    realReadCharValuesList.add(realReadCharValueStr.trim());
                }
        	}
        } 
        
		super.extraSoftParameterValidations(forAlgorithmValidation);
	}

    /**
     * GA000-PERFORM-PROC
     */
	@Override
	public void invoke() {
		
		
    	// 03-23-2023 Kiran Begin exit for the ADDP Route type
    	
    	MeterReadRoute meterReadRoute = servicePoint.fetchMeterReadRoute();
    	
    	if (notNull(meterReadRoute)
                && excludedLogicMeterReadRouteTypesList.contains(meterReadRoute.getMeterReadRouteType()))
    		{
    	if (servicePoint.fetchMeterLocation().getId().getIdValue().trim().equals(insideMeterLoc))
    			{
    		
    			}
    	else
    		if(servicePoint.getServicePointSourceStatus().isDisconnected())
			{
				// if disconnected and not inside then continue otherwise halt
			}
    		else
    			
    			{
    		return;
    			}
    		
    	}
    		
        // 03-23-2023 Kiran End
    	
    	// Decide if it is time to create the FA
        decideIfTooEarly();
        


        // Process the pending start/stop SA/SP for the SP
        checkPendingStartStop(); 

        // Process the pending start/stop SA/SP for same SP type (Same Start and Stop Date)
        checkPendingStartStopForSameSpType();
        
        // Determine if Back-To-Back situation exists
        checkForBackToBack();

        if (shouldActivateManually.isFalse()) {
            // Create Field Activity and Field Activity Steps for SA/SP
            processServiceAgreementServicePoint();
            logger.info(">>>>> 319" + isBackToBack);
            // Link newly created pending Field Activity
            processFieldActivity();

        } else {
        	logger.info(">>>>> 324" + isBackToBack);
        	if (immediateFaCreation.isTrue()) {
        		logger.info(">>>>> 326" + isBackToBack);
                processServiceAgreementServicePoint();
                processFieldActivity();
        	 } else {
                if (saSpFieldActivityType.isStartActivity()
                		
                        && saSpStartDateTime.getDate().isSameOrBefore(getProcessDateTime().getDate())) {
                	logger.info(">>>>> 333" + isBackToBack);
                    processServiceAgreementServicePoint();
                    processFieldActivity();
                }

                if (saSpFieldActivityType.isStopActivity()
                        && saSpStopDateTime.getDate().isSameOrBefore(getProcessDateTime().getDate())) {
                	logger.info(">>>>> 340" + isBackToBack);
                    processServiceAgreementServicePoint();
                    processFieldActivity();
                }
        	}
        }
	}
	
    /**
     * MA000 - If the Manual Activation switch is false and calculated days for START/STOP 
     * exceeds the Number of Days Lead Time, it's too early for creating Field Activities.
     */
    private void decideIfTooEarly() {
        if (saSpFieldActivityType.isStartActivity()) {
            // Calculate Date Difference between SASP's Start Date and Business Date
            long startDays = saSpStartDateTime.getDate().difference(getProcessDateTime().getDate()).getDays();

            if (shouldActivateManually.isFalse()) {
                if (startDays > getNumberOfDaysLeadTime().longValue()) {
                    addError(CustomMessageRepositorySpireOne.CCB038_1_tooEarlyForFa(serviceAgreement, servicePoint
                    		, getNumberOfDaysLeadTime(), getAlgorithm()));
                }
            }
        }

        if (saSpFieldActivityType.isStopActivity()) {
            // Calculate Date Difference between SA/SP's Stop Date and Business Date
            long stopDays = saSpStopDateTime.getDate().difference(getProcessDateTime().getDate()).getTotalDays();

            if (shouldActivateManually.isFalse()) {
                if (stopDays > getNumberOfDaysLeadTime().longValue()) {
                    addError(CustomMessageRepositorySpireOne.CCB038_1_tooEarlyForFa(serviceAgreement, servicePoint
                    		, getNumberOfDaysLeadTime(), getAlgorithm()));
                }
            }
        }
    }
    
    /**
     * MC000 - This has been modified to cater the custom requirements for CCB038.1.
     */
    private void checkPendingStartStop() {
        // Do not cancel if creating 2 different FAs
    	logger.info(">>>>> 384" + neverCreateSingleFieldActivity);
        if (neverCreateSingleFieldActivity.isTrue()) {
            return;
        }

        // If FA Type is Start, determine if there is a Pending Stop, Pending Start or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the PAST of the Start Date that has a
        // Non-Dispatched Pending Field Activity for Stop
        if (saSpFieldActivityType.isStartActivity()) {
        	logger.info(">>>>> 393" + neverCreateSingleFieldActivity);
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.negate().intValue());
            
            //Start Add - JMeden - Defect 4595558 - 2021-09-23
            if(start1Date.isBefore(getProcessDateTime().getDate())){
            	start1Date = getProcessDateTime().getDate();
            }
            //End Add - JMeden - Defect 4595558 - 2021-09-23

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, start1Date, saSpStartDateTime.getDate()
            		, null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
 
            if (!results.isEmpty()) {
            	// Ensure only latest one is selected
	            ServiceAgreementServicePoint pendingSaSp = results.get(0);
	            
	            // If P11 is not populated, proceed with the existing logic.
	            if(isNull(getCustomerRequestRealReadCharType())) {
	            	for (FieldActivity fieldActivity : getSaSpFas(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY)) {
	            		cancelUnlinkFa(fieldActivity, pendingSaSp);
	            	}
	            }
	            // Otherwise, check if the Pending Stop FA link to pendingSaSp has FA Characteristic (P11)
	            else {
		        	for (FieldActivity fieldActivity : getSaSpFas(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY)) {
		        		
	                	FieldActivityCharacteristics faChars = fieldActivity.getCharacteristics();
	                	ListFilter<FieldActivityCharacteristic> faCharFilter = faChars.createFilter("where this.id.characteristicType = :charType ", getClass().getName());
	                	faCharFilter.bindEntity("charType", getCustomerRequestRealReadCharType());

                        if (notNull(faCharFilter.firstRow())) {

                            FieldActivityCharacteristic realReadFaChar = faCharFilter.firstRow();
                            String faCharVal = realReadFaChar.getSearchCharacteristicValue();

                            // Check if the Pending Stop FA has eligible Real Read Characteristic value defined in P12
                        	if(!realReadCharValuesList.contains(faCharVal)) {

                            	// Check if the Start Field Activity is scheduled for the same date as the Stop Field Activity and has Real Read Characteristic not listed in P12
                            	if(fieldActivity.getScheduleDateTimeStart().getDate().compareTo(saSpStartDateTime.getDate()) == 0) {
                            		addError(CustomMessageRepositorySpireOne.CCB038_1_unableToCancelFaPerCustRequest(fieldActivity));
                            	}
                            	hasCustRequestedRealReadChar = Bool.TRUE;

                        	} else {

                        		if (isBackToBack.isTrue()) { 
                        			cancelUnlinkFa(fieldActivity, pendingSaSp);
                        		}
                        		hasCustRequestedRealReadChar = Bool.TRUE;
                        		
                        	}
                    	} 
                        // If the FA has no FA Characteristic (P11), proceed with the existing logic.
                        else {
                    		cancelUnlinkFa(fieldActivity, pendingSaSp);
                    	}
		            }
	            }
            }
        }

        // If FA Type is Stop, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the FUTURE of the Stop Date that has a
        // Non-Dispatched Pending Field Activity for Start
        if (saSpFieldActivityType.isStopActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Stop Date Time of SA/SP
            Date stop2Date = saSpStopDateTime.getDate().addDays(backToBackThresholdDays.intValue());

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, null, null, saSpStopDateTime.getDate()
            		, stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);

            for (ServiceAgreementServicePoint pendingSaSp : results) {
            	cancelUnlinkPendingFa(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
        }
    }
    
    /**
     * SQ010, SQ030
     * @param servicePoint
     * @param start1Date
     * @param start2Date
     * @param stop1Date
     * @param stop2Date
     * @param serviceAgreementSpFaTypeLookup
     * @return List&lt;ServiceAgreementServicePoint&gt;
     */
    private List<ServiceAgreementServicePoint> getPendingSaSp(ServicePoint servicePoint, Date start1Date, Date start2Date
    		, Date stop1Date, Date stop2Date, ServiceAgreementSpFaTypeLookup serviceAgreementSpFaTypeLookup) {

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "S2.STOP_DTTM, ");
        // Selected S2.START_DTTM instead of S2.SA_ID so that query can be used when searching for either Stop or Start
        stringBuilder.append(  "S2.START_DTTM, ");
        stringBuilder.append(  "S2.SA_SP_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA S1, ");
        stringBuilder.append(  "CI_SA_SP_DT_VW S2 ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "S2.SA_ID = S1.SA_ID ");
        stringBuilder.append("AND S2.SP_ID = :servicePoint ");
        stringBuilder.append("AND S1.SA_STATUS_FLG IN (:activeSaStatus , :pendingStopSaStatus, :pendingStartSaStatus) ");
        
        // Cater for either stop or start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_DT BETWEEN :start1Date AND :start2Date ");
        }
        
        // Cater for either stop or start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_DT BETWEEN :stop1Date AND :stop2Date ");
        }
        // Cater for either stop or start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_MR_ID = ' ' ");
        }
        
        // Cater for either stop or start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_MR_ID = ' ' ");
        }
        
        stringBuilder.append("AND EXISTS ( ");
        stringBuilder.append(  "SELECT ");
        stringBuilder.append(    "S3.FA_ID ");
        stringBuilder.append(  "FROM ");
        stringBuilder.append(    "CI_SA_SP_FA S3, ");
        stringBuilder.append(    "CI_FA F1 ");
        stringBuilder.append(  "WHERE ");
        stringBuilder.append(    "S3.SA_SP_ID = S2.SA_SP_ID ");
        stringBuilder.append(  "AND F1.FA_ID = S3.FA_ID ");
        stringBuilder.append(  "AND F1.FA_STATUS_FLG = :pendingFaStatus ");
        stringBuilder.append(  "AND S3.SA_SP_FA_TYPE_FLG = :saSpFaType ");
        stringBuilder.append(  "AND F1.FA_ID = S3.FA_ID ");
        stringBuilder.append(  "AND ( ");
        stringBuilder.append(    "F1.FO_ID = ' ' ");	// FO SHOULD BE BLANK
        stringBuilder.append(      "OR EXISTS ( ");
        stringBuilder.append(        "SELECT ");
        stringBuilder.append(          "'X' ");
        stringBuilder.append(        "FROM ");
        stringBuilder.append(          "CI_FO FO ");
        stringBuilder.append(        "WHERE ");
        stringBuilder.append(          "F1.FO_ID = FO.FO_ID ");
        stringBuilder.append(        "AND FO.FO_STATUS_FLG = :pendingFoStatus ");
        stringBuilder.append(      ") ");
        stringBuilder.append(    ") ");
        stringBuilder.append(  ") ");
        stringBuilder.append("ORDER BY ");
        // Cater for either stop or start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append(  "S2.STOP_DTTM DESC ");
        }
        // Cater for either stop or start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append(  "S2.START_DTTM DESC ");
        }

        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindLookup("activeSaStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
        preparedStatement.bindLookup("pendingStopSaStatus", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        preparedStatement.bindLookup("pendingStartSaStatus", ServiceAgreementStatusLookup.constants.PENDING_START);
        
        if (notNull(start1Date) && notNull(start2Date)) {
            preparedStatement.bindDate("start1Date", start1Date);
            preparedStatement.bindDate("start2Date", start2Date);
        }
        if (notNull(stop1Date) && notNull(stop2Date)) {
            preparedStatement.bindDate("stop1Date", stop1Date);
            preparedStatement.bindDate("stop2Date", stop2Date);
        }
        preparedStatement.bindLookup("saSpFaType", serviceAgreementSpFaTypeLookup);
        preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);
        preparedStatement.bindLookup("pendingFoStatus", FieldOrderStatusLookup.constants.PENDEDBY_USER);

        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<ServiceAgreementServicePoint> serviceAgreementServicePointResults = new ArrayList<ServiceAgreementServicePoint>();
        
        for (SQLResultRow sqlResultRow : results) {
            serviceAgreementServicePointResults.add(sqlResultRow.getEntity("SA_SP_ID", ServiceAgreementServicePoint.class));
        }

        return serviceAgreementServicePointResults;
    }
    
    /**
     * MC060
     * @param serviceAgreementServicePoint
     * @param serviceAgreementSpFaType
     */
    private void cancelUnlinkPendingFa(ServiceAgreementServicePoint serviceAgreementServicePoint
    		, ServiceAgreementSpFaTypeLookup serviceAgreementSpFaType) {

        CmCancelUnlinkFasOfSaSpData data = CmCancelUnlinkFasOfSaSpData.Factory.newInstance();
        data.setServiceAgreementServicePoint(serviceAgreementServicePoint);
        data.setServiceAgreementSpFaType(serviceAgreementSpFaType);
        cancelUnlinkFasOfSaSp.cancelUnlinkFas(data);
    }

    /**
     * ME000 - This has been modified to cater the custom requirements for CCB038.1.
     */
    private void checkPendingStartStopForSameSpType() {

        // Do not cancel if creating 2 different FAs
        if (neverCreateSingleFieldActivity.isTrue()) {
            return;
            
        }

        // If FA Type is Start, determine if there is a Pending Stop, Pending Start or Active SA/SP for the SP
        // on the exact date as start date that has a Non-Dispatched Field Activity for Start
        if (saSpFieldActivityType.isStartActivity()) {
            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, null, null
            		, saSpStartDateTime.getDate(), saSpStartDateTime.getDate(), ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            
            for (ServiceAgreementServicePoint pendingSaSp : results) {
            	cancelUnlinkPendingFa(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
        }

        // If FA Type is Stop, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // on the exact date as stop date that has a Non-Dispatched Pending Field Activity for Stop
        if (saSpFieldActivityType.isStopActivity()) {

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, saSpStopDateTime.getDate()
            		, saSpStopDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            
            for (ServiceAgreementServicePoint pendingSaSp : results) {            
	            // If P11 is not populated, proceed with the existing logic.
	            if(isNull(getCustomerRequestRealReadCharType())) {
	            	for (FieldActivity fieldActivity : getSaSpFas(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY)) {
	            		cancelUnlinkFa(fieldActivity, pendingSaSp);
	            	}
	            }
	            // Otherwise, check if the Pending Stop FA link to pendingSaSp has FA Characteristic
	            else {
		        	for (FieldActivity fieldActivity : getSaSpFas(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY)) {
		        		
	                	FieldActivityCharacteristics faChars = fieldActivity.getCharacteristics();
	                	ListFilter<FieldActivityCharacteristic> faCharFilter = faChars.createFilter("where this.id.characteristicType = :charType ", getClass().getName());
	                	faCharFilter.bindEntity("charType", getCustomerRequestRealReadCharType());
	                	
                        if (notNull(faCharFilter.firstRow())) {

                            FieldActivityCharacteristic realReadFaChar = faCharFilter.firstRow();
                            String faCharVal = realReadFaChar.getSearchCharacteristicValue();

                            // Check if the Pending Stop FA has eligible Real Read Characteristic value defined in P12
                        	if(!realReadCharValuesList.contains(faCharVal)) {
                        		// Check if the Field Activity is scheduled for the same date as the Stop Field Activity and has Real Read Characteristic not listed in P12
                            	if(fieldActivity.getScheduleDateTimeStart().getDate().compareTo(saSpStopDateTime.getDate()) == 0) {
                            		addError(CustomMessageRepositorySpireOne.CCB038_1_unableToCancelFaPerCustRequest(fieldActivity));
                            	}
                            	hasCustRequestedRealReadChar = Bool.TRUE;

                        	} else {
                        		
                        		if(isBackToBack.isTrue()) {
                        			cancelUnlinkFa(fieldActivity, pendingSaSp);
                        		}
                        		hasCustRequestedRealReadChar = Bool.TRUE;
                        		
                        	}
                    	} 
                        // If the FA has no FA Characteristic (P11), proceed with the existing logic.
                        else {
                    		cancelUnlinkFa(fieldActivity, pendingSaSp);
                    	}
		            }
	            }
            }
        }
    }
    
    /**
     * MG000
     *
     */
    private void checkForBackToBack() {
    	logger.info(">>>>> 676" + isBackToBack);
    	logger.info(">>>>> 677" + neverCreateSingleFieldActivity);
        // There is no need to check for back to back if creating separate FAs
        if (neverCreateSingleFieldActivity.isTrue()) {
            return;
        }

        // If FA Type is Start, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the Past of the Start Date
        // without Pending, Held or Completed Field Activity for Stop
        if (saSpFieldActivityType.isStartActivity()) {
        	logger.info(">>>>> 686" + isBackToBack);
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.negate().intValue());

            //Start Add - JMeden - Defect 4595558 - 2021-09-23
         //   if(start1Date.isBefore(getProcessDateTime().getDate())){
         //   	start1Date = getProcessDateTime().getDate();
         //   }
            //End Add - JMeden - Defect 4595558 - 2021-09-23
            
            List<ServiceAgreementServicePoint> results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
            		, start1Date, saSpStartDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY, Bool.FALSE);
            //Start Change - JMeden - Defect 4595558 - 2021-09-23
            //if (!results.isEmpty()) {
   // Kiran   cooment 08/03/22      if (!results.isEmpty() && !getSaSpFas(results.get(0), ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY).isEmpty()) {
            //End Change - JMeden - Defect 4595558 - 2021-09-23
            if (!results.isEmpty()) {
        		// Assume back to back
            	logger.info(">>>>> 704" + isBackToBack);
            	isBackToBack = Bool.TRUE;
            	leastStopDateTime = results.get(0).getStopDateTime();
            }
            
            //Start Add Kiran Machavarapu - TBD - 2022-02-04
            //Now check if there is a pending stop SA whose pending stop date is on a later date compared to the 
            //Start date of this new SA. This is to cater a possible back-to-back scenario
            //where a pending stop SA is linked to a SP whose end date is future dated.
            start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.intValue());
            results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint, saSpStartDateTime.getDate(), 
            		start1Date, null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY , Bool.TRUE);

            if (!results.isEmpty()) {
                // Assume back to back
            	logger.info(">>>>> 719" + isBackToBack);
                isBackToBack = Bool.TRUE;
                leastStopDateTime = results.get(0).getStopDateTime();
                futureStoppedPendingStopSASP = results.get(0);
            }
            //End Add Kiran Machavarapu - TBD - 2022-02-04
        }
        
        
        

        // If FA Type is Stop, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the Future of the Stop Date
        // without Pending, Held or Completed Field Activity for Start
        if (saSpFieldActivityType.isStopActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date stop2Date = saSpStopDateTime.getDate().addDays(backToBackThresholdDays.intValue());

            List<ServiceAgreementServicePoint> results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
            		, null, null, saSpStopDateTime.getDate(), stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY, Bool.FALSE);

            if (!results.isEmpty()) {
            	// Assume back to back
            	isBackToBack = Bool.TRUE;
            }
        }
    }
    
    /**
     * SQ050, SQ070	- This has been modified to cater the custom requirements for CCB038.1.
     * @param servicePoint
     * @param serviceAgreementServicePoint
     * @param start1Date
     * @param start2Date
     * @param stop1Date
     * @param stop2Date
     * @param serviceAgreementSpFaTypeLookup
     * @return List&lt;ServiceAgreementServicePoint&gt;
     */
    private List<ServiceAgreementServicePoint> getOtherSaSpFieldActivities(ServicePoint servicePoint
    		, ServiceAgreementServicePoint serviceAgreementServicePoint, Date start1Date, Date start2Date
    		, Date stop1Date, Date stop2Date, ServiceAgreementSpFaTypeLookup serviceAgreementSpFaTypeLookup, Bool shouldCheckForFutureDatedBackToBack) {

    	StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "S2.STOP_DTTM, ");
        // Selected S2.START_DTTM instead of S2.SA_ID so that query can be used when searching for either back-to-back Stop or back-to-back Start
        stringBuilder.append(  "S2.START_DTTM, ");
        stringBuilder.append(  "S2.SA_SP_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA S1, ");
        stringBuilder.append(  "CI_SA_SP_DT_VW S2 ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "S2.SA_ID = S1.SA_ID ");
        stringBuilder.append("AND S2.SP_ID = :servicePoint ");
        stringBuilder.append("AND S2.SA_SP_ID <> :serviceAgreementServicePoint ");
        stringBuilder.append("AND S1.SA_STATUS_FLG IN ");
        stringBuilder.append(  "( ");
        stringBuilder.append(    ":activeSaStatus, :pendingStopSaStatus, :pendingStartSaStatus");
        
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append(    ", :stoppedSaStatus");
        }
        
        stringBuilder.append(  ") ");
        
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_DT BETWEEN :start1Date AND :start2Date ");
        }
        
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_DT BETWEEN :stop1Date AND :stop2Date ");
        }
        
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_MR_ID = ' ' ");
        }
        
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_MR_ID = ' ' ");
        }
       
    	if(shouldCheckForFutureDatedBackToBack.isFalse()) {
    	
    		stringBuilder.append("AND NOT EXISTS ");
    		stringBuilder.append(  "( ");
    		stringBuilder.append(    "SELECT ");
    		stringBuilder.append(      "S3.FA_ID ");
    		stringBuilder.append(    "FROM ");
    		stringBuilder.append(      "CI_SA_SP_FA S3, ");
    		stringBuilder.append(      "CI_FA F1 ");
    		stringBuilder.append(    "WHERE ");
    		stringBuilder.append(      "S3.SA_SP_ID = S2.SA_SP_ID ");
    		stringBuilder.append(    "AND S3.SA_SP_FA_TYPE_FLG = :saSpFaType ");
    		stringBuilder.append(    "AND F1.FA_ID = S3.FA_ID ");
    		stringBuilder.append(    "AND F1.FA_STATUS_FLG IN (:heldFaStatus, :pendingFaStatus, :completedFaStatus) ");
    		stringBuilder.append(  ") ");
    	
    	}
    	      
        stringBuilder.append("ORDER BY ");
        
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append(  "S2.STOP_DTTM DESC ");
        }
        
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append(  "S2.START_DTTM DESC ");
        }

        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindId("serviceAgreementServicePoint", serviceAgreementServicePoint.getId());
        preparedStatement.bindLookup("activeSaStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
        preparedStatement.bindLookup("pendingStopSaStatus", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        preparedStatement.bindLookup("pendingStartSaStatus", ServiceAgreementStatusLookup.constants.PENDING_START);
        
        if (notNull(start1Date) && notNull(start2Date)) {
            preparedStatement.bindLookup("stoppedSaStatus", ServiceAgreementStatusLookup.constants.STOPPED);
        }
        
        if (notNull(start1Date) && notNull(start2Date)) {
            preparedStatement.bindDate("start1Date", start1Date);
            preparedStatement.bindDate("start2Date", start2Date);
        }
        
        if (notNull(stop1Date) && notNull(stop2Date)) {
            preparedStatement.bindDate("stop1Date", stop1Date);
            preparedStatement.bindDate("stop2Date", stop2Date);
        }

        
        if(shouldCheckForFutureDatedBackToBack.isFalse()) {

        	preparedStatement.bindLookup("saSpFaType", serviceAgreementSpFaTypeLookup);
        	preparedStatement.bindLookup("heldFaStatus", FieldActivityStatusLookup.constants.HELD);
        	preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);
        	preparedStatement.bindLookup("completedFaStatus", FieldActivityStatusLookup.constants.COMPLETED);

        }
      
        
        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<ServiceAgreementServicePoint> serviceAgreementServicePointResults = new ArrayList<ServiceAgreementServicePoint>();
        for (SQLResultRow sqlResultRow : results) {
            serviceAgreementServicePointResults.add(sqlResultRow.getEntity("SA_SP_ID", ServiceAgreementServicePoint.class));
        }
        
        return serviceAgreementServicePointResults;
    }
    
    /**
     * MI000 -  Create FA based on SP condition in FA Profile
     * This has been modified to cater the custom requirements for CCB038.1.
     */
    private void processServiceAgreementServicePoint() {
        // Retrieve information about the Service Point
        ServicePointFieldConditionLookup spCondition = servicePoint.determineFieldCondition();
        
        MeterReadRoute_Id meterReadRouteId = new MeterReadRoute_Id(servicePoint.getMeterReadCycleId(), servicePoint.getMeterReadRoute()); 
        scheduleDateTime = decideScheduleDateTime();
        logger.info(">>>>> 890" + isBackToBack);
        if ( isBackToBack.isTrue() && (servicePoint.fetchMeterLocation().getId().getIdValue().trim().equals(insideMeterLoc)) && (notNull(meterReadRouteId.getEntity()) 
        		&& excludedLogicMeterReadRouteTypesList.contains(meterReadRouteId.getEntity().getMeterReadRouteType())) )
        {
        	isAddp = Bool.TRUE;
        	//createFieldActivityAndLinkToSaSp_addp(getEstimatedReadFieldActivityType());
        }
        if (!spCondition.equals(getSpsDesiredStateForMeterRead())) {
            // If the SP's condition does not match the SP's desired State for Meter Read value
        	logger.info(">>>>> 889" + isBackToBack);
            createFieldActivityViaFieldActivityTypeProfile();

        } else if (notNull(meterReadRouteId.getEntity()) 
        		&& excludedMeterReadRouteTypesList.contains(meterReadRouteId.getEntity().getMeterReadRouteType())) {
        	// If the SP's Route Type is in the Exclude Route Type List (this is not an AMR meter),
        	// create FA via FA Type profile
        	logger.info(">>>>> 896" + isBackToBack);
        	createFieldActivityViaFieldActivityTypeProfile();
        
        /*
         * Start Change - CCB038.Issue3 - 2021-06-23
         */
        //} else if (saSpFieldActivityType.isStopActivity()
        //        && notNull(servicePoint.fetchMeterLocation())
        //        && excludedMeterLocationsList.contains(servicePoint.fetchMeterLocation())) {
        //    // If the SP's Meter Location is in the Exclude Meter Location list, meaning Meter location is IN
        //    // create FA via FA Type profile
        //    createFieldActivityViaFieldActivityTypeProfile();
        
        //Start Change - JMeden - CCB038.Issue4 - 2021-08-03
        //} else if (saSpFieldActivityType.isStopActivity() && isBackToBack.isFalse()) {
        
        //Start add darryl H. 03066  2/3/22
        } else if (saSpFieldActivityType.isStartActivity() && isBackToBack.isFalse() && spCondition.isDeviceInstalledOnSpConnection()) {
            // Override M-Daily
        	logger.info(">>>>> 915" + isBackToBack);
        	createFieldActivityAndLinkToSaSp_on(getEstimatedReadFieldActivityType());

          //End  add darryl H. 03066  2/3/22
           
        } 
        
        
        else if ((saSpFieldActivityType.isStartActivity() || saSpFieldActivityType.isStopActivity()) && isBackToBack.isFalse()) {
        //End Change - JMeden - CCB038.Issue4 - 2021-08-03
        	// If the SP is being stopped
        	//Start Change darryl H. 03066  2/3/22
        	//Start Change - DLampa - D-03306 - 2022-01-04
        	logger.info(">>>>> 928" + isBackToBack);
        	createFieldActivityViaFieldActivityTypeProfile();
	        //createFieldActivityAndLinkToSaSp(getEstimatedReadFieldActivityType());
        	//End Change - DLampa - D-03306 - 2022-01-04
	      //End Change darryl H. 03066 2/3/22
        } else if (notNull(servicePoint.fetchMeterLocation())
        		&& excludedMeterLocationsList.contains(servicePoint.fetchMeterLocation())) {
        	// If the SP's Meter Location is in the Exclude Meter Location list, meaning Meter location is IN
        	// create FA via FA Type profile
        	logger.info(">>>>> 937" + isBackToBack);
        	createFieldActivityViaFieldActivityTypeProfile();
        /*
         * End Change - CCB038.Issue3 - 2021-06-23
         */
		// Start Change - GCrisp - 2021-06-16 - CCB038.Issue1
        //}else if (hasCustRequestedRealReadChar.isTrue() || isBackToBack.isFalse()) {
		}else if (hasCustRequestedRealReadChar.isTrue()) {
		// End Change - GCrisp - 2021-06-16 - CCB038.Issue1
        	// create FA via FA Type profile
			logger.info(">>>>> 947" + isBackToBack);
        	createFieldActivityViaFieldActivityTypeProfile();

        } 
		// Start Add - EQuint - 2022-06-06 - SA401158
        // comment kiran 08/04/2022
		//else if ((saSpFieldActivityType.isStopActivity() && notNull(servicePoint.getPremise().getLandLordId())) || isBackToBack.isTrue()) {
		else if ((saSpFieldActivityType.isStopActivity() && notNull(servicePoint.getPremise().getLandLordId()))) {
        	createFieldActivityAndLinkToSaSp(getEstimatedReadFieldActivityType());
        	logger.info(">>>>> 958" + isBackToBack);
		}
        
        // End Add - EQuint - 2022-06-06 - SA401158
		else{
			// Start Change - EQuint - 2022-06-06 - SA401158
        	// createFieldActivityAndLinkToSaSp(getEstimatedReadFieldActivityType());
        	// createFieldActivityViaFieldActivityTypeProfile();
        	// End Change - EQuint - 2022-06-06 - SA401158

            ServicePointCharacteristic spChar = servicePoint.getEffectiveCharacteristic(getPowerStatusSpCharType());
            String powerStatusStr = "";
            CharacteristicTypeLookup spCharType = getPowerStatusSpCharType().getCharacteristicType();
            logger.info(">>>>> 966" + isBackToBack);
            if (isNull(spChar)){
                //Start Change Kiran - TBD - 2022-08-03
                //createFieldActivityAndLinkToSaSp(getDispatchableFieldActivityTypeForMeterRead());
            	logger.info(">>>>> 970" + isBackToBack);
                if(saSpFieldActivityType.isStopActivity()) {
                    fa1 = createFieldActivityAndLinkToSaSp_date(getEstimatedReadFieldActivityType() , saSpStopDateTime);
                } else {
                    fa1 = createFieldActivityAndLinkToSaSp_date(getEstimatedReadFieldActivityType() , saSpStartDateTime);
                }
                //End Change Kiran - TBD - 2022-08-03
                
                //Start Add Kiran - TBD - 2022-08-03
                //Only create a second FA if there is a back-to-back situation and 
                // the Pending Stop SA's stop-date-time is earlier than the new SA's
                // start date
                if(isBackToBack.isTrue() && saSpFieldActivityType.isStartActivity()  
                        && (notNull(leastStopDateTime) && leastStopDateTime.isBefore(saSpStartDateTime))) {
                	logger.info(">>>>> 984" + isBackToBack);
                    fa2 = createFieldActivityAndLinkToSaSp_date(getEstimatedReadFieldActivityType() , leastStopDateTime);
                    hasCreatedFA2 = Bool.TRUE; 
                }
                //End Add Kiran - TBD - 2022-08-03
            }else{
            	logger.info(">>>>> 995" + isBackToBack);
                if (spCharType.isPredefinedValue()){
                    powerStatusStr = spChar.getCharacteristicValue();
                }else if (spCharType.isForeignKeyValue()){
                    powerStatusStr = spChar.getCharacteristicValueForeignKey1();
                }else{
                    powerStatusStr = spChar.getAdhocCharacteristicValue();
                }
            }
            
            if (powerStatusStr.trim().equals(truePowerStatusCharVal.fetchIdCharacteristicValue().trim())){
                //Start Change Kiran - TBD - 2022-08-03
                //createFieldActivityAndLinkToSaSp(getNonDispatchableFieldActivityTypeForMeterRead());
                if(saSpFieldActivityType.isStopActivity()) {
                    fa1 = createFieldActivityAndLinkToSaSp_date(getEstimatedReadFieldActivityType() , saSpStopDateTime);
                } else {
                	logger.info(">>>>> 1005" + isBackToBack);
                    fa1 = createFieldActivityAndLinkToSaSp_date(getEstimatedReadFieldActivityType() , saSpStartDateTime);
                }
                //End Change Kiran - TBD - 2022-08-03
                
                //Start Add Kiran - TBD - 2022-08-03
                //Only create a second FA if there is a back-to-back situation and 
                // the Pending Stop SA's stop-date-time is earlier than the new SA's
                // start date
                if(isBackToBack.isTrue() && saSpFieldActivityType.isStartActivity() 
                        && (notNull(leastStopDateTime) && leastStopDateTime.isBefore(saSpStartDateTime))) {
                	logger.info(">>>>> 1016" + isBackToBack);
                    fa2 = createFieldActivity_date(getEstimatedReadFieldActivityType() , leastStopDateTime);
                    hasCreatedFA2 = Bool.TRUE;
                }
                //End Add Kiran - TBD - 2022-08-03
            } else {
                //Start Change Kiran - TBD - 2022-08-03
                //createFieldActivityAndLinkToSaSp(getDispatchableFieldActivityTypeForMeterRead());
                if(saSpFieldActivityType.isStopActivity()) {
                    fa1 = createFieldActivityAndLinkToSaSp_date(getEstimatedReadFieldActivityType() , saSpStopDateTime);
                } else {
                	logger.info(">>>>> 1027" + isBackToBack);
                    fa1 = createFieldActivityAndLinkToSaSp_date(getEstimatedReadFieldActivityType() , saSpStartDateTime);
                }
                //End Change Kiran - TBD - 2022-08-03
                
                //Start Add Kiran - TBD - 2022-08-03
                //Only create a second FA if there is a back-to-back situation and 
                // the Pending Stop SA's stop-date-time is earlier than the new SA's
                // start date
                if(isBackToBack.isTrue() && saSpFieldActivityType.isStartActivity()
                        && (notNull(leastStopDateTime) && leastStopDateTime.isBefore(saSpStartDateTime))) {
                	logger.info(">>>>> 1038" + isBackToBack);
                    fa2 = createFieldActivity_date(getEstimatedReadFieldActivityType() , leastStopDateTime);
                    hasCreatedFA2 = Bool.TRUE;
                }
                //End Add Kiran - TBD - 2022-08-03
            }
        
        }
    }

	/**
     * MI040
     * @return scheduleDateTime
     */
    private DateTime decideScheduleDateTime() {
    	// If it is START and there is no BACK-to-BACK situation then SCHED-DTTM will be set to START-DTTM,
    	// otherwise (i.e. BACK-to-BACK) it will be set to earliest STOP-DTTM among SA/SPs
        if (saSpFieldActivityType.isStartActivity() && isBackToBack.isTrue()) {
            return leastStopDateTime;
        }

        if (saSpFieldActivityType.isStartActivity() && isBackToBack.isFalse()) {
            return saSpStartDateTime;
        }

        // If it is STOP, SCHED-DTTM will be set to STOP-DTTM of SA/SP regardless of BACK-to-BACK situation
        if (saSpFieldActivityType.isStopActivity()) {
            return saSpStopDateTime;
        }

        return null;
    }

    /**
     * PA130
     */
    private void createFieldActivityViaFieldActivityTypeProfile() {    	
    	SaSpFieldActivityCreatorData data = SaSpFieldActivityCreatorData.Factory.newInstance();
    	
        data.setServiceAgreementSpFaType(saSpFieldActivityType);
        // Set isBackToBack to False
        data.setIsBackToBack(Bool.FALSE);
        
        if (saSpFieldActivityType.isStartActivity()) {
        	data.setCustomerEvent(CustomerEventLookup.constants.START_SERVICE);
        }
        
        if (saSpFieldActivityType.isStopActivity()) {
        	data.setCustomerEvent(CustomerEventLookup.constants.STOP_SERVICE);
        }
        
        if (isBackToBack.isTrue()) {
        	// Check SP's Power status. If the Power Status is equal to Power Status Char Val, SP is an AMR SP so use
        	// Start/Stop Customer Event. Otherwise, if the Power Status on the SP is not equal to the Power Status
        	// Char Val or if the SP does not have a Power Status Characteristic, the SP is not an AMR SP so use
        	// Start/Stop Non-AMR Customer Event.
        	ServicePointCharacteristic spChar = servicePoint.getEffectiveCharacteristic(getPowerStatusSpCharType());

        	if (isNull(spChar)){
        		data.setCustomerEvent(CustomerEventLookup.constants.X_START_STOP_NON_A_M_R);
        	}else{
        		String powerStatusStr = "";
        		CharacteristicTypeLookup spCharType = getPowerStatusSpCharType().getCharacteristicType();
        		if (spCharType.isPredefinedValue()){
        			powerStatusStr = spChar.getCharacteristicValue();
        		} else if (spCharType.isForeignKeyValue()){
        			powerStatusStr = spChar.getCharacteristicValueForeignKey1();
        		} else {
        			powerStatusStr = spChar.getAdhocCharacteristicValue();
        		}
        		
        		if (powerStatusStr.trim().equals(truePowerStatusCharVal.fetchIdCharacteristicValue().trim())) {
        			data.setCustomerEvent(CustomerEventLookup.constants.START_STOP);
        		} else{
        			data.setCustomerEvent(CustomerEventLookup.constants.X_START_STOP_NON_A_M_R);
        		}
        	}
        }

        data.setScheduledDateTime(scheduleDateTime);
        data.setFieldActivityCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);
        data.setIsFaCollectionRequired(Bool.FALSE);

        data = serviceAgreementServicePoint.addFieldActivity(data);
        isFaCreated = data.getIsFaCreated();
    }
    
  
    private FieldActivity createFieldActivityAndLinkToSaSp_addp(FieldActivityType fieldActivityType) {
    	
    	FieldActivityType faType = new FieldActivityType_Id("ADDPREAD").getEntity();
    	
    	FieldActivity_DTO fieldActivityDTO = new FieldActivity_DTO();
        fieldActivityDTO.setServicePointId(servicePoint.getId());
        fieldActivityDTO.setFieldActivityTypeId(faType.getId());
        fieldActivityDTO.setScheduleDateTimeStart(scheduleDateTime);
        fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);

        FieldActivityCreatorData data = FieldActivityCreatorData.Factory.newInstance();
        data.setFaDTO(fieldActivityDTO);

        FieldActivity fieldActivity = FieldActivityCreator.Factory.newInstance().addFieldActivity(data);

        ServiceAgreementSpFieldActivity_DTO serviceAgreementSpFieldActivityDTO = new ServiceAgreementSpFieldActivity_DTO();
        serviceAgreementSpFieldActivityDTO.setFieldActivityType(saSpFieldActivityType);
        serviceAgreementSpFieldActivityDTO.setServiceAgreementId(serviceAgreementServicePoint.getServiceAgreement().getId());
        serviceAgreementSpFieldActivityDTO.setServicePointId(serviceAgreementServicePoint.getServicePoint().getId());
        serviceAgreementServicePoint.getServiceAgreementSpFieldActivities().add(serviceAgreementSpFieldActivityDTO, fieldActivity.getId());

        isFaCreated = Bool.TRUE;

        return fieldActivity;
    }
    
    private FieldActivity createFieldActivityAndLinkToSaSp_on(FieldActivityType fieldActivityType) {
    	
    	FieldActivityType faType = new FieldActivityType_Id("M-ON").getEntity();
    	
    	FieldActivity_DTO fieldActivityDTO = new FieldActivity_DTO();
        fieldActivityDTO.setServicePointId(servicePoint.getId());
        fieldActivityDTO.setFieldActivityTypeId(faType.getId());
        fieldActivityDTO.setScheduleDateTimeStart(scheduleDateTime);
        fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);

        FieldActivityCreatorData data = FieldActivityCreatorData.Factory.newInstance();
        data.setFaDTO(fieldActivityDTO);

        FieldActivity fieldActivity = FieldActivityCreator.Factory.newInstance().addFieldActivity(data);

        ServiceAgreementSpFieldActivity_DTO serviceAgreementSpFieldActivityDTO = new ServiceAgreementSpFieldActivity_DTO();
        serviceAgreementSpFieldActivityDTO.setFieldActivityType(saSpFieldActivityType);
        serviceAgreementSpFieldActivityDTO.setServiceAgreementId(serviceAgreementServicePoint.getServiceAgreement().getId());
        serviceAgreementSpFieldActivityDTO.setServicePointId(serviceAgreementServicePoint.getServicePoint().getId());
        serviceAgreementServicePoint.getServiceAgreementSpFieldActivities().add(serviceAgreementSpFieldActivityDTO, fieldActivity.getId());

        isFaCreated = Bool.TRUE;

        return fieldActivity;
    }

    
    private FieldActivity createFieldActivityAndLinkToSaSp(FieldActivityType fieldActivityType) {

    	FieldActivity_DTO fieldActivityDTO = new FieldActivity_DTO();
        fieldActivityDTO.setServicePointId(servicePoint.getId());
        fieldActivityDTO.setFieldActivityTypeId(fieldActivityType.getId());
        fieldActivityDTO.setScheduleDateTimeStart(scheduleDateTime);
        fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);

        FieldActivityCreatorData data = FieldActivityCreatorData.Factory.newInstance();
        data.setFaDTO(fieldActivityDTO);

        FieldActivity fieldActivity = FieldActivityCreator.Factory.newInstance().addFieldActivity(data);

        ServiceAgreementSpFieldActivity_DTO serviceAgreementSpFieldActivityDTO = new ServiceAgreementSpFieldActivity_DTO();
        serviceAgreementSpFieldActivityDTO.setFieldActivityType(saSpFieldActivityType);
        serviceAgreementSpFieldActivityDTO.setServiceAgreementId(serviceAgreementServicePoint.getServiceAgreement().getId());
        serviceAgreementSpFieldActivityDTO.setServicePointId(serviceAgreementServicePoint.getServicePoint().getId());
        serviceAgreementServicePoint.getServiceAgreementSpFieldActivities().add(serviceAgreementSpFieldActivityDTO, fieldActivity.getId());

        isFaCreated = Bool.TRUE;

        return fieldActivity;
    }

    private FieldActivity createFieldActivityAndLinkToSaSp_date(FieldActivityType fieldActivityType , DateTime scheduleDateTime) {

    	
    	FieldActivityType faType = new FieldActivityType_Id("ADDPREAD").getEntity();
    	FieldActivity_DTO fieldActivityDTO = new FieldActivity_DTO();
        fieldActivityDTO.setServicePointId(servicePoint.getId());
        logger.info(">>>>> 1277" + isAddp);
    	if (isAddp.isTrue()){
    		fieldActivityDTO.setFieldActivityTypeId(faType.getId());
    	}
    	else
    	{
    		fieldActivityDTO.setFieldActivityTypeId(fieldActivityType.getId());
    	}
       // fieldActivityDTO.setFieldActivityTypeId(fieldActivityType.getId());
        fieldActivityDTO.setScheduleDateTimeStart(scheduleDateTime);
        fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);

        FieldActivityCreatorData data = FieldActivityCreatorData.Factory.newInstance();
        data.setFaDTO(fieldActivityDTO);

        FieldActivity fieldActivity = FieldActivityCreator.Factory.newInstance().addFieldActivity(data);

        ServiceAgreementSpFieldActivity_DTO serviceAgreementSpFieldActivityDTO = new ServiceAgreementSpFieldActivity_DTO();
        serviceAgreementSpFieldActivityDTO.setFieldActivityType(saSpFieldActivityType);
        serviceAgreementSpFieldActivityDTO.setServiceAgreementId(serviceAgreementServicePoint.getServiceAgreement().getId());
        serviceAgreementSpFieldActivityDTO.setServicePointId(serviceAgreementServicePoint.getServicePoint().getId());
        serviceAgreementServicePoint.getServiceAgreementSpFieldActivities().add(serviceAgreementSpFieldActivityDTO, fieldActivity.getId());

        isFaCreated = Bool.TRUE;

        return fieldActivity;
    }
    /**
     * MM000 - Retrieve newly created Pending FAs of SA/SP and link to Back-to-Back SA/SPs
     */
    private void processFieldActivity() {

        //Start Add Kiran - TBD - 2022-08-03
        if(hasCreatedFA2.isTrue()) {
            //If another FA was created, this means that there is a back to back SA for the SP. Link FA2 to the pending stop
            //and FA 1 to the active SA
            linkSameType(fa1);
            
            linkB2BSaSpFa(fa2);
        } else {
        //End Add Kiran - TBD - 2022-08-03
            for (FieldActivity fieldActivity : getSaSpFas_noFaTyp(serviceAgreementServicePoint)) {

                if (isBackToBack.isTrue()) {
                    linkB2BSaSpFa(fieldActivity);
                }

                linkSameType(fieldActivity);
            }
      //Start Add Kiran - TBD - 2022-08-03
        }
      //End Add Kiran - TBD - 2022-08-03
    }

    
    private List<FieldActivity> getSaSpFas_noFaTyp(ServiceAgreementServicePoint serviceAgreementServicePoint) {

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "SASPFA.FA_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA_SP_FA SASPFA, ");
        stringBuilder.append(  "CI_FA FA ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "SASPFA.SA_SP_ID = :saSpId ");
        stringBuilder.append(  "AND SASPFA.SA_SP_FA_TYPE_FLG = :saSpFaType ");
        stringBuilder.append(  "AND FA.FA_ID = SASPFA.FA_ID ");
        stringBuilder.append(  "AND FA.FA_STATUS_FLG = :pendingFaStatus ");

        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("saSpId", serviceAgreementServicePoint.getId());

        preparedStatement.bindLookup("saSpFaType", saSpFieldActivityType);
        preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);

        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<FieldActivity> fieldActivityResults = new ArrayList<FieldActivity>();
        for (SQLResultRow sqlResultRow : results) {
            fieldActivityResults.add(sqlResultRow.getEntity("FA_ID", FieldActivity.class));
        }

        return fieldActivityResults;
    }
    /**
     * SQ090 - This has been modified to cater the changes for CCB038.1.
     * @param serviceAgreementServicePoint
     * @param serviceAgreementSpFaType
     * @return List&lt;FieldActivity&gt;
     */
    private List<FieldActivity> getSaSpFas(ServiceAgreementServicePoint serviceAgreementServicePoint,  ServiceAgreementSpFaTypeLookup serviceAgreementSpFaType) {

    	StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "SASPFA.FA_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA_SP_FA SASPFA, ");
        stringBuilder.append(  "CI_FA FA ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "SASPFA.SA_SP_ID = :saSpId ");
        stringBuilder.append(  "AND SASPFA.SA_SP_FA_TYPE_FLG = :saSpFaType ");
        stringBuilder.append(  "AND FA.FA_ID = SASPFA.FA_ID ");
        stringBuilder.append(  "AND FA.FA_STATUS_FLG = :pendingFaStatus ");

        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("saSpId", serviceAgreementServicePoint.getId());
        preparedStatement.bindLookup("saSpFaType", serviceAgreementSpFaType);
        preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);

        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<FieldActivity> fieldActivityResults = new ArrayList<FieldActivity>();
        for (SQLResultRow sqlResultRow : results) {
            fieldActivityResults.add(sqlResultRow.getEntity("FA_ID", FieldActivity.class));
        }

        return fieldActivityResults;
    }
    
    private void cancelUnlinkFa(FieldActivity fieldActivity, ServiceAgreementServicePoint saSp) {
    	
        if (isNull(saStartStopCanceledFaCancelReason)) {
            saStartStopCanceledFaCancelReason = getDefaultFaCancelReason(FieldActivitySystemDefaultLookup.constants.SA_START_STOPCANCELED);
        }
        
        //Start Change - JMeden - Defect 4595558 - 2021-09-23
        //if (fieldActivity.getFieldActivityStatus().isPending()) {
        if (fieldActivity.getFieldActivityStatus().isPending() && fieldActivity.getScheduleDateTimeStart().isSameOrAfter(getProcessDateTime().startOfDay())) {       
        //End Change - JMeden - Defect 4595558 - 2021-09-23
        	cancelFieldActivity(fieldActivity);
        }
        
        if (fieldActivity.getFieldActivityStatus().isCompleted()) {
            addWarning(CustomMessageRepositorySpireOne.CCB038_1_warningFaIsComplete(fieldActivity, saSp.getServiceAgreement(), saSp.getServicePoint()));
        }
        
        if (fieldActivity.getFieldActivityStatus().isCanceled()) {
            return;
        }
        
    }
    
    private FieldActivityCancelReason getDefaultFaCancelReason(FieldActivitySystemDefaultLookup fieldActivitySystemDefaultLookup) {
        
        // Get the FA Cancel Reason Code for SA Start/Stop
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "FA_CAN_RSN_CD ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_FA_CAN_RSN ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "FACAN_SYS_DFLT_FLG = :systemDefault ");
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindLookup("systemDefault", fieldActivitySystemDefaultLookup);
        
        SQLResultRow sqlResultRow = preparedStatement.firstRow();
        
        preparedStatement.close();
        
        if (isNull(sqlResultRow)) {
            addError(CustomMessageRepositorySpireOne.CCB038_1_missingDefaultFaCancelReason(fieldActivitySystemDefaultLookup));
        }
        
        return sqlResultRow.getEntity("FA_CAN_RSN_CD", FieldActivityCancelReason.class);   
    }
    
    private void cancelFieldActivity(FieldActivity fieldActivity) {
    	// Check if FA Remark For Cancelled FAs parameter is populated prior creating the FA Remark
    	if(notNull(getFaRemarkForCancelledFAs())) {
    		FieldActivityRemark_Id faRemarkId = new FieldActivityRemark_Id(getFaRemarkForCancelledFAs(), fieldActivity);
    		if(isNull(faRemarkId.getEntity())) {
    			FieldActivityRemark_DTO faRemarkDto = createDTO(FieldActivityRemark.class);
    			faRemarkDto.setId(faRemarkId);
    			faRemarkDto.newEntity();
    		}
    	}
    	
        FieldActivityCancelProcessorData fieldActivityCancelProcessorData = FieldActivityCancelProcessorData.Factory.newInstance();
        fieldActivityCancelProcessorData.setFieldActivity(fieldActivity);
        fieldActivityCancelProcessorData.setCancelReason(saStartStopCanceledFaCancelReason);
        fieldActivityCancelProcessorData.setMustCancelDispatchedFa(Bool.FALSE);
        fieldActivity.cancel(fieldActivityCancelProcessorData);        
    }

    
    private FieldActivity createFieldActivity_date(FieldActivityType fieldActivityType , DateTime scheduledDateTime) {

    	FieldActivityType faType = new FieldActivityType_Id("ADDPREAD").getEntity();
    	FieldActivity_DTO fieldActivityDTO = new FieldActivity_DTO();
        fieldActivityDTO.setServicePointId(servicePoint.getId());
        
    	if (isAddp.isTrue()){
    		fieldActivityDTO.setFieldActivityTypeId(faType.getId());
    	}
    	else
    	{
    		fieldActivityDTO.setFieldActivityTypeId(fieldActivityType.getId());
    	}
    	
        fieldActivityDTO.setScheduleDateTimeStart(scheduleDateTime);
        fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);

        FieldActivityCreatorData data = FieldActivityCreatorData.Factory.newInstance();
        data.setFaDTO(fieldActivityDTO);

        FieldActivity fieldActivity = FieldActivityCreator.Factory.newInstance().addFieldActivity(data);
        
        return fieldActivity;
    }
    
    /**
     * MM020 - Link the Field Activity to the Pending Start and Pending Stop SA/SPs.
     * @param fieldActivity
     */
    
    private void linkB2BSaSpFa(FieldActivity fieldActivity) {

    	if (saSpFieldActivityType.isStartActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.negate().intValue());

            //Start Add - JMeden - Defect 4595558 - 2021-09-23
            if(start1Date.isBefore(getProcessDateTime().getDate())){
            	start1Date = getProcessDateTime().getDate();
            }
            //End Add - JMeden - Defect 4595558 - 2021-09-23
            
            for (ServiceAgreementServicePoint pendingStopSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
            		, start1Date, saSpStartDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY, Bool.FALSE)) {

                createSaSpFa(pendingStopSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }
            
            //Start Add Kiran Machavarapu - TBD - 2022-08-03
            //If there is a future dated pending stop whose stop date is future dated and is within the number of back to back threshold days
            // link the FA created to the future-dated Pending Stop SA and update its end date to be equal to the 
            //start date of the new SA
            if(notNull(futureStoppedPendingStopSASP) && futureStoppedPendingStopSASP.getStopDateTime().isAfter(saStartDate)) {
                //Update the SA's end date 
                ServiceAgreement pendingStopSA = futureStoppedPendingStopSASP.getServiceAgreement();
                ServiceAgreement_DTO pendingStopSA_DTO = pendingStopSA.getDTO();
                pendingStopSA_DTO.setEndDate(saStartDate);
                pendingStopSA.setDTO(pendingStopSA_DTO);
                
                //Update the SA/SP Record of the 
                ServiceAgreementServicePoint_DTO pendingStopSaSpDto = futureStoppedPendingStopSASP.getDTO();
                
                pendingStopSaSpDto.setStopDateTime(saSpStartDateTime);
                futureStoppedPendingStopSASP.setDTO(pendingStopSaSpDto);
                
                //Cancel any pending Stop Activity FAs on the Pending Stop SA
                cancelUnlinkPendingFa(futureStoppedPendingStopSASP, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
                
                //Link the created FA to the pending stop 
                createSaSpFa(futureStoppedPendingStopSASP, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }
            //End Add Kiran Machavarapu - TBD - 2022-08-03
        }

        

        if (saSpFieldActivityType.isStopActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date stop2Date = saSpStopDateTime.getDate().addDays(backToBackThresholdDays.intValue());

            for (ServiceAgreementServicePoint pendingStartSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
            		, null, null, saSpStopDateTime.getDate(), stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY, Bool.FALSE)) {

            	createSaSpFa(pendingStartSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
        }
    }

    /**
     * MM060 - Create SA/SP/FA record using the row maintenance.
     */
    private void createSaSpFa(ServiceAgreementServicePoint serviceAgreementServicePoint, FieldActivity fieldActivity
    		, ServiceAgreementSpFaTypeLookup lookup) {

        ServiceAgreementSpFieldActivity_Id serviceAgreementSpFieldActivityId = new ServiceAgreementSpFieldActivity_Id(serviceAgreementServicePoint
        		, fieldActivity);

        if (isNull(serviceAgreementSpFieldActivityId.getEntity())) {
            ServiceAgreementSpFieldActivity_DTO serviceAgreementSpFieldActivityDTO = new ServiceAgreementSpFieldActivity_DTO();
            serviceAgreementSpFieldActivityDTO.setFieldActivityType(lookup);
            serviceAgreementSpFieldActivityDTO.setServiceAgreementId(serviceAgreementServicePoint.getServiceAgreement().getId());
            serviceAgreementSpFieldActivityDTO.setServicePointId(serviceAgreementServicePoint.getServicePoint().getId());
            serviceAgreementSpFieldActivityDTO.setId(serviceAgreementSpFieldActivityId);
            serviceAgreementSpFieldActivityDTO.newEntity();
        }
    }

    /**
     * MK040 - Link the FA to the Pending Start and Pending Stop SA/SPs
     * This has been modified to cater the changes for CCB038.1.
     */
    private void linkSameType(FieldActivity fieldActivity) {

    	if (saSpFieldActivityType.isStartActivity()) {
            for (ServiceAgreementServicePoint pendingStartSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
            		, null, null, saSpStartDateTime.getDate(), saSpStartDateTime.getDate(), ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY,Bool.FALSE)) {
            	
                // Cancel field activity and disconnect from SA/SP
            	if(hasCustRequestedRealReadChar.isFalse()) {
            		cancelUnlinkPendingFa(pendingStartSaSp, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            	}
            	
                // Link new FA to SA/SP
                createSaSpFa(pendingStartSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
        }

        if (saSpFieldActivityType.isStopActivity()) {
            for (ServiceAgreementServicePoint pendingStopSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
            		, saSpStopDateTime.getDate(), saSpStopDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY,Bool.FALSE)) {
            	
            	// 	Cancel field activity and disconnect from SA/SP
            	if(hasCustRequestedRealReadChar.isFalse()) {
            		cancelUnlinkPendingFa(pendingStopSaSp, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            	}
            	
                // Link new FA to SA/SP
                createSaSpFa(pendingStopSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }
        }
    }
}

