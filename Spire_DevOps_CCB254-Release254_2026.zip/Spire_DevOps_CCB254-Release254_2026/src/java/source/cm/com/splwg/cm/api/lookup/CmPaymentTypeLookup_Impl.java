/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Payment Type Lookup - Reffered for both Remittance and Returns 
 * 						 File Processing
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2013-05-30	Karthik		NI0019.4. Initial Version.
 **************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author kloganatha001
 *
@LookupFieldname (value = XRFP_OPT_TYP_FLG)
 */
public class CmPaymentTypeLookup_Impl extends CmPaymentTypeLookup_Gen {

}
