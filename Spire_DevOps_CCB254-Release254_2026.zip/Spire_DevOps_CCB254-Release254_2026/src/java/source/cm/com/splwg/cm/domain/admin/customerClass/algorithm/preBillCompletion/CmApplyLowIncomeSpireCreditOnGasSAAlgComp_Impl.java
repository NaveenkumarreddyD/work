/*
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                     
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * This algorithm would apply the correct spire credit to the customer
 * enrolled on the FCAP Budget Plan based on the season and the customer's
 * Federal Poverty Level.
 * 
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:       by:          Reason:
 * YYYY-MM-DD  FLName
 * 2018-08-20  JHERNA		SysAid#245408 Initial Version.
 * 2019-02-19  JHERNA		SysAid#278448 only create budget credit for
 *                          the customer if the budget plan is still
 *                          for FCAP.
 * 2019-12-19  JHERNA		SysAid#317404 FCAP Winter Budget credits not
 * 							getting applied. Issue is with season check.
 * 2021-03-18  JHERNA       SysAid#362495 while creating test data to for
 * 							CMQUMON, an issue was encountered where the 
 * 							account with blank budget plan is being read
 * 							by the code as a null, hence a null pointer
 * 							is being encountered. This fixes that issue.
 * 2024-06-12  EQUINT		B-33471. Only create budget credit when
 * 							FCAP SA exists.
 ***********************************************************************
 */
package com.splwg.cm.domain.admin.customerClass.algorithm.preBillCompletion;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.Query;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.ccb.api.lookup.BillCompletionActionLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic_DTO;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic_Id;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType_Id;
import com.splwg.ccb.domain.admin.budgetPlan.entity.BudgetPlan_Id;
import com.splwg.ccb.domain.admin.customerClass.algorithm.preBillCompletion.CustomerClassPreBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.api.lookup.CmLowIncomeProgramConfigurationsOptionTypeLookup;
import com.splwg.cm.api.lookup.ExternalSystemTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.common.ServerMessage;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = featureConfiguration, name = lowIncomeProgramFeatureConfiguration, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = federalPovertyLevelLowPercentage, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = federalPovertyLevelHighPercentage, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = eligibleSATypes, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = charTypeBillId, required = true, type = entity)})
 */
public class CmApplyLowIncomeSpireCreditOnGasSAAlgComp_Impl 
		extends CmApplyLowIncomeSpireCreditOnGasSAAlgComp_Gen
		implements CustomerClassPreBillCompletionAlgorithmSpot {

	/*Hard Parameters*/
	private Bool hpAllowReopeningOfBills;
	private BillCompletionActionLookup hpBillCompletionAction;
	private ServerMessage hpServerMessage;
	private Account hpAccount;
	@SuppressWarnings("unused")
	private Date hpAccountingDate;
	private Bill hpBill;
	@SuppressWarnings("unused")
	private Date hpBillDate;
	private List<BillSegment> hpListOfBsegs;
	@SuppressWarnings("unused")
	private Bill hpCreditNoteForBill;
	
	/*Soft Parameters*/
	private FeatureConfiguration parmFeatConf;
	private BigInteger parmFPLLowPerc;
	private BigInteger parmFPLHighPerc;
	private List<String> parmListOfEligibleSATypes;
	private CharacteristicType parmCharTypeBillID;
	
	/*Global Work Variables*/
	private String wAlgorithm;
	private CharacteristicType_Id wCharTypeIdFPL;
	private BudgetPlan_Id wBudgetPlanIdFCAP;
	private Date wCurrentDate;
	/*START CHANGES - JHERNA - SysAid#278448*/
	//private String wCurrentSeason;
	private Season wCurrentSeason;
	/*END CHANGES - JHERNA - SysAid#278448*/
	private BigDecimal wFCAPSummerSeasonCredit;
	private BigDecimal wFCAPWinterSeasonCreditForLowFPL;
	private BigDecimal wFCAPWinterSeasonCreditForHighFPL;
	private BigDecimal wAdjustmentAmount;
	private AdjustmentType_Id wAdjTypeSpireCredit; 	
	
	/*Constants*/
	private final static String COMMA = ",";		
	private final static String SLASH = "/";
	/*START DELETE - JHERNA - SysAid#278448*/
	//private final static String SUMMER = "SUMMER";
	//private final static String WINTER = "WINTER";
	/*END DELETE - JHERNA - SysAid#278448*/
	private final static CmMGEFeatureConfigurationOptionsRetriever FCHELPER = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
	
	// start add -  EQuint - 06-11-2024 - B-33471
	private static final String FCAP_SA_TYPE_CD = "GPAFARP";
	// end add -  EQuint - 06-11-2024 - B-33471
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		
		wAlgorithm = this.getAlgorithmId().getTrimmedValue();
		wCurrentDate = this.getProcessDateTime().getDate();
		wFCAPSummerSeasonCredit = BigDecimal.ZERO;
		wFCAPWinterSeasonCreditForLowFPL = BigDecimal.ZERO;
		wFCAPWinterSeasonCreditForHighFPL = BigDecimal.ZERO;
		wAdjustmentAmount = BigDecimal.ZERO;
		parmListOfEligibleSATypes = new ArrayList<String>();
		
		// Retrieve Parameter 10: Low Income Program Feature Configuration
		parmFeatConf = this.getLowIncomeProgramFeatureConfiguration();
		// Retrieve Parameter 20: Federal Poverty Level Low Percentage
		parmFPLLowPerc = this.getFederalPovertyLevelLowPercentage();
		if (parmFPLLowPerc.compareTo(BigInteger.ZERO) <= 0) {
			// Algorithm %1's parameter '%2%3' value (%4) must be greater than zero
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterMustBeGreaterThanZero(
					wAlgorithm.trim(),
					"FPL Low Percentage",
					parmFPLLowPerc.toString().trim()));
		}
		// Retrieve Parameter 30: Federal Poverty Level High Percentage
		parmFPLHighPerc = this.getFederalPovertyLevelHighPercentage();
		if (parmFPLHighPerc.compareTo(BigInteger.ZERO) <= 0) {
			// Algorithm %1's parameter '%2%3' value (%4) must be greater than zero
				addError(CustomMessageRepositoryMGE.commAlgorithmParameterMustBeGreaterThanZero(
						wAlgorithm.trim(),
						"FPL High Percentage",
						parmFPLHighPerc.toString().trim()));
		}
		if (parmFPLHighPerc.compareTo(parmFPLLowPerc) <= 0) {
		    // Algorithm %1's parameter '%2%3' value (%4) must be greater than parameter '%5%6' value (%7)
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterMustBeGreaterThanParameterValue(
					wAlgorithm.trim(),
					"FPL Low Percentage",
					parmFPLLowPerc.toString().trim(),
					"FPL High Percentage",
					parmFPLHighPerc.toString().trim()));
		}
		// Retrieve Parameter 40: List Of Eligible SA Types
		String parm40 = this.getEligibleSATypes();
		StringTokenizer st = new StringTokenizer(parm40, COMMA); 
		while (st.hasMoreTokens()) {
			String sa = cmValidateSaType(st.nextToken(), "List of Eligible SA Types");
			parmListOfEligibleSATypes.add(sa.trim());
		}
		// Retrieve Parameter 50: Characteristic Type for Bill ID
		parmCharTypeBillID = this.getCharTypeBillId();
		CharacteristicEntity_Id charEntID = new CharacteristicEntity_Id(parmCharTypeBillID, CharacteristicEntityLookup.constants.ADJUSTMENT);
		if (isNull(charEntID.getEntity())) {
		    // Algorithm %1's parameter '%2%3' value (%4) is not a valid char type for %5%6 entity
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharTypeNotValidForEntity(wAlgorithm.trim(),
					"Characteristic Type for Bill ID", parmCharTypeBillID.getId().getTrimmedValue(), "Adjustment"));
		}
	}	
	
	private String cmValidateSaType(String saType, String parmDesc) {
		
		String returnValue = " ";
		if (notBlank(saType)) {
			
			PreparedStatement prepState = createPreparedStatement(
					"SELECT 'X' "
					+ "FROM CI_SA_TYPE "
					+ "WHERE SA_TYPE_CD = '"+saType.trim()+"' ", 
					"===cmValidateSaType===");
			prepState.execute();
			prepState.setAutoclose(false);
			if (notNull(prepState.firstRow())) {
				returnValue = saType.trim();
			}	
			else {
				// Algorithm %1's parameter '%2%3' has an invalid value (%4).
				addError(CustomMessageRepositoryMGE.commAlgorithmParameterIsInvalid(
						wAlgorithm,
						parmDesc.trim(),
						saType.trim()));
			}
			prepState.close();
		}
		return returnValue;		
	}

	@Override
	public Bool getAllowReopeningOfBills() {
		return hpAllowReopeningOfBills;
	}

	@Override
	public BillCompletionActionLookup getBillCompletionAction() {
		return hpBillCompletionAction;
	}

	@Override
	public ServerMessage getServerMessage() {
		return hpServerMessage;
	}

	@Override
	public void setAccount(Account arg0) {
		hpAccount = arg0;
	}

	@Override
	public void setAccountingDate(Date arg0) {
		hpAccountingDate = arg0;
	}

	@Override
	public void setAllowReopeningOfBills(Bool arg0) {
		hpAllowReopeningOfBills = arg0;
	}

	@Override
	public void setBill(Bill arg0) {
		hpBill = arg0;
	}

	@Override
	public void setBillDate(Date arg0) {
		hpBillDate = arg0;
	}

	@Override
	public void setBillSegments(List<BillSegment> arg0) {
		hpListOfBsegs = arg0;
	}

	@Override
	public void setCreditNoteForBill(Bill arg0) {
		hpCreditNoteForBill = arg0;
	}
	
	// START ADD - JHERNA - 2018-02-19 - SysAid#278448
	private enum Season {
		SUMMER,
		WINTER,
		UNKNOWN
	}
	// END ADD - JHERNA - 2018-02-19 - SysAid#278448
	
	/* ** MAIN METHOD - INVOKE** */

	@Override
	public void invoke() {
		
		// start add -  EQuint - 06-11-2024 - B-33471
		// account should have billable FCAP SA to proceed
		if (hasBillableFcapSas().isFalse()) {
			return;
		}
		// end add -  EQuint - 06-11-2024 - B-33471

		cmCheckInput();

		// START ADD - JHERNA - 2018-02-19 - SysAid#278448
		// Continue processing only if the customer is currently on an FCAP Budget Plan
		BudgetPlan_Id customerBudgetPlanID = hpAccount.getBudgetPlanId();
		/* START CHANGE - JHERNA - 2021-MAR-18 - SysAid#362495 */	
		//if (customerBudgetPlanID.compareTo(wBudgetPlanIdFCAP) != 0) {
		if (isNull(customerBudgetPlanID)
				|| customerBudgetPlanID.compareTo(wBudgetPlanIdFCAP) != 0) {
		/* END CHANGE - JHERNA - 2021-MAR-18 - SysAid#362495 */	
			// if the customer is not on FCAP Budget Plan, terminate program.
			return;
		}
		// END ADD - JHERNA - 2018-02-19 - SysAid#278448
		
		/*
		 * Retrieve all bill segments
		 * Note: base hard parameter list of bill segments is faulty and is always empty. 
		 */
		retrieveBillSegments(hpBill);
				
		for (int x = 0; x < hpListOfBsegs.size(); x++) {
						
			BillSegment bseg = hpListOfBsegs.get(x);
			ServiceAgreement sa = bseg.getServiceAgreement();
			String saType = sa.getServiceAgreementType().fetchIdSaType().trim();
			Date bsegEndDate = bseg.getEndDate();
			
			getSeasonAndCreditAmounts(bsegEndDate);
			
			// Proceed processing only the SA Type matches any on the list of eligible SA Types of parameter 40 
			// and the bill segment is frozen (not cancelled)
			// and current season falls on either summer or winter.
			
			if (parmListOfEligibleSATypes.contains(saType.trim())
					&& bseg.getBillSegmentStatus().isFrozen()
/*START CHANGES- JHERNA - SysAid#278448*/					
					//&& notBlank(wCurrentSeason)) {
					&& wCurrentSeason.compareTo(Season.UNKNOWN) != 0) {
				// Retrieve the most effective recurring charge amount of the SA
				BigDecimal rcAmount = retrieveRecurringCharge(sa, 2);
								
				// Proceed only if the recurring amount is greater than zero
				if (rcAmount.compareTo(BigDecimal.ZERO) > 0) {
					
					//if (wCurrentSeason.equals(SUMMER)) {
					if (wCurrentSeason.compareTo(Season.SUMMER) == 0) {
						if (rcAmount.compareTo(wFCAPSummerSeasonCredit) < 0) {
							wAdjustmentAmount = rcAmount;
						}
						else {
							wAdjustmentAmount = wFCAPSummerSeasonCredit;
						}
					}
					//else if (wCurrentSeason.equals(WINTER)) {
					else if (wCurrentSeason.compareTo(Season.WINTER) == 0) {
/*END CHANGES - JHERNA - SysAid#278448*/						
						Account account = sa.getAccount();
						AccountCharacteristic acctChar = account.getEffectiveCharacteristic(wCharTypeIdFPL.getEntity());
						String fplCharVal = "";
						if (notNull(acctChar)) {							
							CharacteristicTypeLookup charTypeLookup = acctChar.fetchIdCharacteristicType().getCharacteristicType();
							if (charTypeLookup.isAdhocValue()
									|| charTypeLookup.isFileLocationValue()) {
								fplCharVal = acctChar.getAdhocCharacteristicValue().trim();
							}
							else if (charTypeLookup.isPredefinedValue()) {
								fplCharVal = acctChar.getCharacteristicValue().trim();
							}
							else {
								fplCharVal = acctChar.getCharacteristicValueForeignKey1().trim();
							}							
						}

						// Account does not have an FPL or the FPL is equals to 135%
						if (isBlankOrNull(fplCharVal)
								|| (convertStringToInteger(fplCharVal).compareTo(parmFPLLowPerc) == 0) ) {
							if (rcAmount.compareTo(wFCAPWinterSeasonCreditForLowFPL) < 0) {
								wAdjustmentAmount = rcAmount;
							}
							else {
								wAdjustmentAmount = wFCAPWinterSeasonCreditForLowFPL;
							}
						}
						// Account have an FPL of 185%
						else if (convertStringToInteger(fplCharVal).compareTo(parmFPLHighPerc) == 0) {
							if (rcAmount.compareTo(wFCAPWinterSeasonCreditForHighFPL) < 0) {
								wAdjustmentAmount = rcAmount;
							}
							else {
								wAdjustmentAmount = wFCAPWinterSeasonCreditForHighFPL;
							}
						}						
					}
					
					/*Prepare the Frozen Adjustment Data*/
					CreateFrozenAdjustmentData data = CreateFrozenAdjustmentData.Factory.newInstance();
					data.setServiceAgreement(sa);
					data.setAdjustmentType(wAdjTypeSpireCredit.getEntity());
					data.setAdjustmentAmount(new Money(wAdjustmentAmount.negate(), hpAccount.getCurrency().getId()));
					data.setAdjustmentDate(wCurrentDate);
					data.setCalculationDate(wCurrentDate);
					data.setArrearsDate(wCurrentDate);
					data.setAllowZeroAmount(Bool.FALSE);
					data.setTransferServiceAgreement(null);

					Adjustment newSpireCreditAdj = cmCreateAdustment(sa, data);
					
					/*Create Adjustment Characteristic*/
					cmCreateAdjChar(newSpireCreditAdj, parmCharTypeBillID, hpBill.getId().getTrimmedValue());
				}
			}
			
		}
	}

	private void cmCheckInput() {
		
		// Retrieve FPL Characteristic Type
		wCharTypeIdFPL = FCHELPER.getCharacteristicTypeFeatureOptionValue(
				parmFeatConf.getId(), 
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FPL_CHARACTERISTIC_TYPE, 
				Bool.TRUE,
				Bool.FALSE,
				CharacteristicEntityLookup.constants.ACCOUNT);
		// Retrieve FCAP Budget Plan
		String budPlanStr = FCHELPER.getMaximumSequenceFeatureOptionValue(
				parmFeatConf.getId(),
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_BUDGET_PLAN,
				Bool.TRUE);
		wBudgetPlanIdFCAP = new BudgetPlan_Id(budPlanStr.trim());
		if (isNull(wBudgetPlanIdFCAP.getEntity())) {
		    // Feature Configuration (%1)'s %2%3 value (%4) is an invalid %4<entity>
			addError(CustomMessageRepositoryMGE.commFeatConfOptIsNotTheExpectedEntity(
					parmFeatConf.getId().getTrimmedValue(), 
					CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_BUDGET_PLAN.getLookupValue().fetchLanguageDescription().trim(),
					budPlanStr.trim(), 
					"Budget Plan"));
		}		
		// Retrieve Spire Credit Adjustment Type
		wAdjTypeSpireCredit = FCHELPER.getAdjustmentTypeFeatureOptionValue(
				parmFeatConf.getId(), 
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.SPIRE_CREDIT_ADJUSTMENT_TYPE,
				Bool.TRUE,
				Bool.FALSE);
	}
	
	private void getSeasonAndCreditAmounts(Date dateToCheck) {
		
		/*START CHANGES - JHERNA - SysAid#278448*/	
		// Check Season
		wCurrentSeason = cmCheckSeason(dateToCheck);
		// If processing date falls on summer
		//if (wCurrentSeason.equals(SUMMER)) {
		if (wCurrentSeason.compareTo(Season.SUMMER) == 0) {
			// Retrieve FCAP Summer Season Credit
			String temp = FCHELPER.getMaximumSequenceFeatureOptionValue(
					parmFeatConf.getId(), 
					CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_SUMMER_SEASON_CREDIT, 
					Bool.TRUE);
			wFCAPSummerSeasonCredit = convertStringToAmount(temp, 2);
		}
		// Else (processing date falls on winter)
		//else if (wCurrentSeason.equals(WINTER)){
		else if (wCurrentSeason.compareTo(Season.WINTER) == 0){
			// Retrieve FCAP Winter Season Hi 
			String temp1 = FCHELPER.getMaximumSequenceFeatureOptionValue(
					parmFeatConf.getId(), 
					CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_WINTER_SEASON_CREDIT_HI_F_P_L_1_8_5, 
					Bool.TRUE);
			wFCAPWinterSeasonCreditForHighFPL = convertStringToAmount(temp1,  2);
			// Retrieve FCAP Winter Season Lo
			String temp2 = FCHELPER.getMaximumSequenceFeatureOptionValue(
					parmFeatConf.getId(), 
					CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_WINTER_SEASON_CREDIT_LO_F_P_L_1_3_5, 
					Bool.TRUE);
			wFCAPWinterSeasonCreditForLowFPL = convertStringToAmount(temp2, 2);
		}
		else {
			Logger lg = LoggerFactory.getLogger(CmApplyLowIncomeSpireCreditOnGasSAAlgComp_Impl.class);
			lg.info("\n===Cannot find defined season for date:"+dateToCheck+"===");
			lg.info("\n===Spire Budget Credit will not be created===");
		}
		/*END CHANGES - JHERNA - SysAid#278448*/
	}
	
	private BigDecimal convertStringToAmount(String strValue, int decimalPlace) {
		BigDecimal returnValue = BigDecimal.ZERO;
		
		if (notBlank(strValue)) {
			try {
				double newVal = Double.parseDouble(strValue.trim());
				returnValue = BigDecimal.valueOf(newVal);
			}
			catch (NumberFormatException nfe) {
				nfe.printStackTrace();
				addError(CustomMessageRepositoryMGE.commGenericError(nfe.getMessage()));
			}
			catch (Exception e) {
				e.printStackTrace();
				addError(CustomMessageRepositoryMGE.commGenericError(e.getMessage()));
			}
		}
		returnValue = returnValue.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);
		return returnValue;
	}
	
	private BigInteger convertStringToInteger(String strValue) {
		BigInteger returnValue = BigInteger.ZERO;
		
		if (notBlank(strValue)) {
			try {
				int newVal = Integer.parseInt(strValue.trim());
				returnValue = BigInteger.valueOf(newVal);
			}
			catch (NumberFormatException nfe) {
				nfe.printStackTrace();
				addError(CustomMessageRepositoryMGE.commGenericError(nfe.getMessage()));
			}
			catch (Exception e) {
				e.printStackTrace();
				addError(CustomMessageRepositoryMGE.commGenericError(e.getMessage()));
			}
		}
		return returnValue;
	}
	
	/*START CHANGES - JHERNA - SysAid#278448*/
	/*
	private String cmCheckSeason(Date dateToCheck) {
		
		String returnValue = " ";
		
		// Retrieve FCAP Summer Season
		String summerStartDtStr = FCHELPER.getMaximumSequenceFeatureOptionValue(parmFeatConf.getId(),
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_SUMMER_START_DATE,
				Bool.TRUE);
		
		String summerEndDtStr = FCHELPER.getMaximumSequenceFeatureOptionValue(parmFeatConf.getId(),
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_SUMMER_END_DATE,
				Bool.TRUE); 

		
		Date summerEndDate = null;
		Date summerStartDate = null;
		
		try {
			StringTokenizer st = new StringTokenizer(summerEndDtStr, SLASH);
			String monthStr = st.nextToken();
			String dayStr = st.nextToken();
			int month = Integer.parseInt(monthStr);
			int day = Integer.parseInt(dayStr);
			Date date = new Date(wCurrentDate.getYear(), month, day);
			
			if (wCurrentDate.isAfter(date)) {
				summerEndDate = date.addYears(1);
			}
			else {
				summerEndDate = date;
			}
		}
		catch (Exception e) {
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterIsInvalid(wAlgorithm, "FCAP Summer Season End Date", summerEndDtStr));
		}
		
		try {
			StringTokenizer st = new StringTokenizer(summerStartDtStr, SLASH);
			String monthStr = st.nextToken();
			String dayStr = st.nextToken();
			int month = Integer.parseInt(monthStr);
			int day = Integer.parseInt(dayStr);
			Date date = new Date(wCurrentDate.getYear(), month, day);
			if (summerEndDate.isBefore(date)) {
				summerStartDate = date.addYears(-1);
			}		
			else {
				summerStartDate = date;
			}
		}
		catch (Exception e) {
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterIsInvalid(wAlgorithm, "FCAP Summer Season Start Date", summerStartDtStr));
		}		
				
		// Retrieve FCAP Winter Season
		String winterStartDtStr = FCHELPER.getMaximumSequenceFeatureOptionValue(parmFeatConf.getId(),
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_WINTER_START_DATE,
				Bool.TRUE);
		
		String winterEndDtStr = FCHELPER.getMaximumSequenceFeatureOptionValue(parmFeatConf.getId(),
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_WINTER_END_DATE,
				Bool.TRUE);		
		
		Date winterEndDate = null;
		Date winterStartDate = null;
		
		try {
			StringTokenizer st1 = new StringTokenizer(winterEndDtStr, SLASH);
			String monthStr1 = st1.nextToken();
			String dayStr1 = st1.nextToken();
			int month1 = Integer.parseInt(monthStr1);
			int day1 = Integer.parseInt(dayStr1);
			Date date1 = new Date(wCurrentDate.getYear(), month1, day1);
			
			if (wCurrentDate.isAfter(date1)) {
				winterEndDate = date1.addYears(1);
			}
			else {
				winterEndDate = date1;
			}
		}
		catch (Exception e) {
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterIsInvalid(wAlgorithm, "FCAP Winter Season End Date", winterEndDtStr));
		}
		
		try {
			StringTokenizer st2 = new StringTokenizer(winterStartDtStr, SLASH);
			String monthStr2 = st2.nextToken();
			String dayStr2 = st2.nextToken();
			int month2 = Integer.parseInt(monthStr2);
			int day2 = Integer.parseInt(dayStr2);
			Date date2 = new Date(wCurrentDate.getYear(), month2, day2);
			if (winterEndDate.isBefore(date2)) {
				winterStartDate = date2.addYears(-1);
			}		
			else {
				winterStartDate = date2;
			}
		}
		catch (Exception e) {
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterIsInvalid(wAlgorithm, "FCAP Winter Season Start Date", winterStartDtStr));
		}
		
		if (dateToCheck.isSameOrAfter(winterStartDate)
				&& dateToCheck.isSameOrBefore(winterEndDate)) {
			returnValue = WINTER;
		}
		else if (dateToCheck.isSameOrAfter(summerStartDate)
				&& dateToCheck.isSameOrBefore(summerEndDate)) {
			returnValue = SUMMER;
		}
		return returnValue;
	}
	*/
	private Season cmCheckSeason(Date dateToCheck) {
		
		// START CHANGES - JHERNA - 2019-12-19 - SysAid#317404
		/*
		int month = this.getProcessDateTime().getMonth();
		int day = this.getProcessDateTime().getDay();
		*/
		int month = dateToCheck.getMonth();
		int day = dateToCheck.getDay();
		// END CHANGES - JHERNA - 2019-12-19 - SysAid#317404
		
		CmMGEFeatureConfigurationOptionsRetriever fcHelper = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
		FeatureConfiguration_Id featConfID = fcHelper.getFeatureConfiguration(ExternalSystemTypeLookup.constants.LOW_INCOME_PROGRAM_CONFIG_OPTIONS);
		
		// Retrieve FCAP Summer Season
		String summerStart = fcHelper.getMaximumSequenceFeatureOptionValue(featConfID,
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_SUMMER_START_DATE,
				Bool.TRUE);
		
		String summerEnd = fcHelper.getMaximumSequenceFeatureOptionValue(featConfID,
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_SUMMER_END_DATE,
				Bool.TRUE); 
		
		// Retrieve FCAP WINTER Season
		String winterStart = fcHelper.getMaximumSequenceFeatureOptionValue(featConfID,
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_WINTER_START_DATE,
				Bool.TRUE);
				
		String winterEnd = fcHelper.getMaximumSequenceFeatureOptionValue(featConfID,
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_WINTER_END_DATE,
				Bool.TRUE); 
		
		CmMonthDay monthDayHelper = new CmMonthDay();
		monthDayHelper.invoke(summerStart, SLASH);
		int summerStartMonth = monthDayHelper.getMonth();
		int summerStartDay = monthDayHelper.getDay();
		
		monthDayHelper.invoke(summerEnd, SLASH);
		int summerEndMonth = monthDayHelper.getMonth();
		int summerEndDay = monthDayHelper.getDay();

		monthDayHelper.invoke(winterStart, SLASH);
		int winterStartMonth = monthDayHelper.getMonth();
		int winterStartDay = monthDayHelper.getDay();		

		monthDayHelper.invoke(winterEnd, SLASH);
		int winterEndMonth = monthDayHelper.getMonth();
		int winterEndDay = monthDayHelper.getDay();		
		
		// Check if processing date is winter
		if (month == winterStartMonth
				&& day >= winterStartDay) {
			return Season.WINTER;
		}
		else if (month == winterEndMonth
				&& day <= winterEndDay) {
			return Season.WINTER;
		}
		// START CHANGES - JHERNA - 2019-12-19 - SysAid#317404
		/*
		else if (month > winterStartMonth
				&& month < winterEndMonth) {
			return Season.WINTER;
		}
		*/
		else if (month > winterStartMonth
				|| month < winterEndMonth) {
			return Season.WINTER;
		}
		// END CHANGES - JHERNA - 2019-12-19 - SysAid#317404
		
		// Check if processing date is summer
		if (month == summerStartMonth
				&& day >= summerStartDay) {
			return Season.SUMMER;
		}
		else if (month == summerEndMonth
				&& day <= summerEndDay) {
			return Season.SUMMER;
		}
		else if (month > summerStartMonth
				&& month < summerEndMonth) {
			return Season.SUMMER;
		}
		return Season.UNKNOWN;
	}	
	/*END CHANGES - JHERNA - SysAid#278448*/
	/*START ADD - JHERNA - SysAid#278448*/
	private class CmMonthDay {
		
		private int month;
		private int day;
		
		private int getMonth() {
			return month;
		}
		private int getDay() {
			return day;
		}
		private void invoke(String monthDay, String delim) {
			
			if (notBlank(monthDay)
					&& notBlank(delim)) {
				
				StringTokenizer tz = new StringTokenizer(monthDay, delim);
				String mo = tz.nextToken();
				String dy = tz.nextToken();
				month = Integer.parseInt(mo);
				day = Integer.parseInt(dy);				
			}			
		}
	}
	/*END ADD - JHERNA - SysAid#278448*/
	
	private void retrieveBillSegments(Bill bill) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "BSEG_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_BSEG ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "BILL_ID = :bill ");
          
        PreparedStatement retrieveBillSegments = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        retrieveBillSegments.bindEntity("bill", bill);
        retrieveBillSegments.execute();
        if (notNull(retrieveBillSegments.firstRow())) {
        	Iterator<SQLResultRow> coll = retrieveBillSegments.list().iterator();
        	while (coll.hasNext()) {
        		SQLResultRow sqlRow = coll.next();
        		BillSegment bseg = ((BillSegment_Id) sqlRow.getId("BSEG_ID", BillSegment.class)).getEntity();
        		hpListOfBsegs.add(bseg);        		
        	}
        }
        retrieveBillSegments.close();
        
    }
	
	
	private BigDecimal retrieveRecurringCharge(ServiceAgreement sa, int decimalPlace) {
		
		BigDecimal returnValue = BigDecimal.ZERO;
		PreparedStatement prepState = createPreparedStatement(
				"SELECT EFFDT, RCR_CHG_AMT " +
				"FROM CI_SA_RCHG_HIST " +
				"WHERE SA_ID = :saID " +
				"AND EFFDT <= :currentDate " +
				"ORDER BY EFFDT DESC ", 
				"=test=");
		prepState.bindId("saID", sa.getId());
		prepState.bindDate("currentDate", wCurrentDate);
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			
			SQLResultRow sqlRow = prepState.firstRow();
			returnValue = (BigDecimal) sqlRow.getBigDecimal("RCR_CHG_AMT");			
		}		
		prepState.close();
		returnValue = returnValue.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);
		return returnValue;
	}
	
	private Adjustment cmCreateAdustment(ServiceAgreement sa, CreateFrozenAdjustmentData input) {
		
		Adjustment returnValue = null;
		CreateFrozenAdjustmentData output = sa.createFrozenAdjustment(input);
		returnValue = output.getAdjustment();
		return returnValue;
	}
	
	private void cmCreateAdjChar(Adjustment adj, CharacteristicType charType, String charValue) {
		
		if (notBlank(charValue)) {
			
			AdjustmentCharacteristic_Id adjCharID = new AdjustmentCharacteristic_Id(charType, adj, BigInteger.TEN);
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			
			if (notNull(adjCharID.getEntity())) {
				
				
				AdjustmentCharacteristic_DTO adjCharDTO = adjCharID.getEntity().getDTO();
				
				if (charTypeLookup.isForeignKeyValue()) {
					adjCharDTO.setCharacteristicValueForeignKey1(charValue.trim());
				}
				else if (charTypeLookup.isPredefinedValue()) {
					adjCharDTO.setCharacteristicValue(charValue.trim());
				}
				else {
					adjCharDTO.setAdhocCharacteristicValue(charValue.trim());
				}
				adjCharID.getEntity().setDTO(adjCharDTO);
				
			}
			else {
				
				AdjustmentCharacteristic_DTO adjCharDTO = new AdjustmentCharacteristic_DTO();
				
				if (charTypeLookup.isForeignKeyValue()) {
					adjCharDTO.setCharacteristicValueForeignKey1(charValue.trim());
				}
				else if (charTypeLookup.isPredefinedValue()) {
					adjCharDTO.setCharacteristicValue(charValue.trim());
				}
				else {
					adjCharDTO.setAdhocCharacteristicValue(charValue.trim());
				}
				adjCharDTO.setId(adjCharID);
				adjCharDTO.newEntity();
			}
		}						
	}
	
	// start add -  EQuint - 06-11-2024 - B-33471
	/**
	 * Checks if account has billable FCAP SA
	 * Returns true of account has billable FCAP SA.
	 * If SA is stopped, bill segment should be a closing bill.
	 * @return
	 */
	private Bool hasBillableFcapSas() {
		// get account's billable FCAP SAs
		Query<ServiceAgreement> query = createQuery(
				" FROM ServiceAgreement sa "
				+ " WHERE sa.account.id = :acctId "
				+ " AND sa.serviceAgreementType.id.saType = :saTypeCd "
				+ " AND sa.status IN (:pendingStart, :active, :pendingStop) "
		, "has FCAP SA");
		
		query.bindId("acctId", hpAccount.getId());
		query.bindStringProperty("saTypeCd", ServiceAgreementType.properties.saType, FCAP_SA_TYPE_CD);
		query.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
		query.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
		query.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
		
		ServiceAgreement fcapSa = query.firstRow();
		
		return Bool.valueOf(notNull(fcapSa));
	}
	// end add -  EQuint - 06-11-2024 - B-33471
}
