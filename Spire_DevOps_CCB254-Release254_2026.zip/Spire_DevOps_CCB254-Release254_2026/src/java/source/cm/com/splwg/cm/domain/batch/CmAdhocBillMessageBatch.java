/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Batch - Adhoc Bill Message
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-04-04   RDizon  NM0079. Initial Version.
 * 2013-06-21   CVB     Removed trim on SA Rate Class parameter assignment
 *                      to prevent null error from happening if no 
 *                      parameter value is present.
 * 2016-01-22	MPang	Updated for CCB v2.4 compilation.
 **************************************************************************/


package com.splwg.cm.domain.batch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.Query;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;

//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
/*import com.splwg.ccb.domain.admin.billMessage.BillMessageType;
import com.splwg.ccb.domain.admin.billRouteType.BillRouteType;
import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.CisDivision_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType_Id;
import com.splwg.ccb.domain.billing.bill.Bill;
import com.splwg.ccb.domain.billing.bill.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.Bill_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCharacteristic;*/

import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.billRouteType.entity.BillRouteType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.cm.api.lookup.CmAdhocBillMessageBatchParametersLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author redizon
 *
 @BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = billMessageType, name = BILL_MESSAGE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = FEATURE_NAME, type = entity)
 *            , @BatchJobSoftParameter (name = SA_TYPE_OPTION_TYPE, type = string)
 *            , @BatchJobSoftParameter (name = SA_RATE_CLASS_OPTION_TYPE, type = string)
 *            , @BatchJobSoftParameter (entityName = billRouteType, name = BILL_ROUTE_TYPE, required = true, type = entity)})
 */
public class CmAdhocBillMessageBatch extends CmAdhocBillMessageBatch_Gen {

    // Batch Parameters
    private static FeatureConfiguration parmFeatureConfiguration;
    private static String parmSaTypeOptionType;
    private static String parmSaRateClassOptionType;
    private static BillRouteType parmBillRouteType;

    /**
     * Retrieves the records to be processed as work units.
     * @return JobWork
     */
    public JobWork getJobWork() {
        return createJobWorkForEntityQuery(cmRetrieveBillsUsingBillRouting());
    }

    private Query<Bill> cmRetrieveBillsUsingBillRouting() {

        parmBillRouteType = this.getParameters().getBILL_ROUTE_TYPE();
      
        //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
        
//        Query<Bill> query = createQuery("FROM BillRouting BR "
//                + "WHERE BR.batchControlId = :batchControlId "
//                + "AND BR.batchNumber = :nextBatchNumber" );
        
        Query<Bill> query = createQuery("FROM BillRouting BR "
                + "WHERE BR.batchControlId = :batchControlId "
                + "AND BR.batchNumber = :nextBatchNumber", getClass().getName());
       //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
        query.bindId("batchControlId", parmBillRouteType.getBatchControl().getId());
        query.bindBigInteger("nextBatchNumber", parmBillRouteType.getBatchControl().getNextBatchNumber());
        query.addResult("bill", "BR.id.bill");

        return query;
    }

    @Override
    public void validateSoftParameters(boolean arg0) {
        // Retrieve the Batch Parameters
        parmFeatureConfiguration = this.getParameters().getFEATURE_NAME();
        parmSaTypeOptionType = this.getParameters().getSA_TYPE_OPTION_TYPE();
        // CVB - 2013-06-21 - Start
        // parmSaRateClassOptionType = this.getParameters().getSA_RATE_CLASS_OPTION_TYPE().trim();
        parmSaRateClassOptionType = this.getParameters().getSA_RATE_CLASS_OPTION_TYPE();
        // CVB - 2013-06-21 - End
        parmBillRouteType = this.getParameters().getBILL_ROUTE_TYPE();
        
        if ((notBlank(parmSaTypeOptionType) || notBlank(parmSaRateClassOptionType)) && isNull(parmFeatureConfiguration)){
            addError(CustomMessageRepositoryMDC.nm0079_BatchParameterFeatureConfigurationNameIsRequired());
        }
    }

    public Class<CmAdhocBillMessageBatchWorker> getThreadWorkerClass() {
        return CmAdhocBillMessageBatchWorker.class;
    }

    public static class CmAdhocBillMessageBatchWorker extends
    CmAdhocBillMessageBatchWorker_Gen {
        
        Logger logger = LoggerFactory.getLogger(this.getClass());

        // Batch Parameters
        private BillMessageType parmBillMessage;
        private FeatureConfiguration parmFeatureConfiguration;
        private String parmSaTypeOptionType;
        private String parmSaRateClassOptionType;

        // Work Variables
        private Bill bill;
        private List<CisDivision> cisDivisions = new ArrayList<CisDivision>();
        private List<String> saTypeCodes = new ArrayList<String>();
        private List<CharacteristicType> charTypes = new ArrayList<CharacteristicType>();
        private List<String> charValues = new ArrayList<String>();
        
        // Constants
        private String VALID_FORMAT_CIS_DIVISION_SA_TYPE_OPTION_VALUE = "CIS_DIVISION,SA_TYPE_CD";
        private String VALID_FORMAT_CHARTYPE_CHARVALUE_OPTION_VALUE = "CHAR_TYPE_CD,CHAR_VALUE";
        private String OPTION_VALUE_ENTITY_CIS_DIVISION = "CIS Division";
        private String OPTION_VALUE_ENTITY_SA_TYPE_CD = "SA Type Code";
        private String OPTION_VALUE_ENTITY_CHARTYPE = "Characteristic Type";
        private String OPTION_VALUE_ENTITY_CHARVALUE = "Characteristic Value";

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

        @Override
        public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
            // Retrieve the Batch Parameters
            parmBillMessage = this.getParameters().getBILL_MESSAGE();
            parmFeatureConfiguration = this.getParameters().getFEATURE_NAME();
            parmSaTypeOptionType = this.getParameters().getSA_TYPE_OPTION_TYPE();
            // CVB - 2013-06-21 - Start
            // parmSaRateClassOptionType = this.getParameters().getSA_RATE_CLASS_OPTION_TYPE().trim();
            parmSaRateClassOptionType = this.getParameters().getSA_RATE_CLASS_OPTION_TYPE();
            // CVB - 2013-06-21 - End            
            parmBillRouteType = this.getParameters().getBILL_ROUTE_TYPE();

            if (notBlank(parmSaTypeOptionType)){
                Query getSaTypes = cmGetFeatureConfigurationOptionValue(parmFeatureConfiguration, parmSaTypeOptionType);
                
                // Check if the option value exists
                if (getSaTypes.listSize() == 0){
                    addError(CustomMessageRepositoryMDC.nm0079_FeatConfigurationOptionValueIsRequired(parmFeatureConfiguration.getId().getIdValue(),
                            CmAdhocBillMessageBatchParametersLookup.constants.CIS_DIVISION_AND_SA_TYPE.toLocalizedString()));
                }
                
                Iterator itrFeatConfigOptionValues = getSaTypes.iterate();
                while (itrFeatConfigOptionValues.hasNext()){
                    String featConfOptionValue = (String) itrFeatConfigOptionValues.next();

                    List<String> saTypeOption =  Arrays.asList(featConfOptionValue.trim().split(","));
                   
                    // Check if the option value is in a valid format
                    if (saTypeOption.size() != 2){
                        addError(CustomMessageRepositoryMDC.nm0079_FeatConfigurationOptionValueInvalidFormat(parmFeatureConfiguration.getId().getIdValue(),
                                CmAdhocBillMessageBatchParametersLookup.constants.CIS_DIVISION_AND_SA_TYPE.toLocalizedString(),
                                VALID_FORMAT_CIS_DIVISION_SA_TYPE_OPTION_VALUE));
                    }
                   
                    // Check if the CIS Division and SA Type are valid
                    CisDivision_Id cisDivisionId = new CisDivision_Id(saTypeOption.get(0));
                    if (isNull(cisDivisionId.getEntity())){
                        addError(CustomMessageRepositoryMDC.nm0079_FeatConfigurationOptionValueInvalidValue(parmFeatureConfiguration.getId().getIdValue(),
                                saTypeOption.get(0), OPTION_VALUE_ENTITY_CIS_DIVISION,
                                CmAdhocBillMessageBatchParametersLookup.constants.CIS_DIVISION_AND_SA_TYPE.toLocalizedString()));
                    }
                    ServiceAgreementType_Id saTypeId = new ServiceAgreementType_Id(cisDivisionId, saTypeOption.get(1));
                    if (isNull(saTypeId.getEntity())){
                        addError(CustomMessageRepositoryMDC.nm0079_FeatConfigurationOptionValueInvalidValue(parmFeatureConfiguration.getId().getIdValue(),
                                saTypeOption.get(1), OPTION_VALUE_ENTITY_SA_TYPE_CD,
                                CmAdhocBillMessageBatchParametersLookup.constants.CIS_DIVISION_AND_SA_TYPE.toLocalizedString()));
                    }
                    
                    cisDivisions.add(new CisDivision_Id(saTypeOption.get(0)).getEntity());
                    saTypeCodes.add(saTypeOption.get(1));
                }
            }

            if (notBlank(parmSaRateClassOptionType)){
                // CVB - 2013-06-21 - Start
                // Query getSaRateClasses = cmGetFeatureConfigurationOptionValue(parmFeatureConfiguration, parmSaRateClassOptionType);
                Query getSaRateClasses = cmGetFeatureConfigurationOptionValue(parmFeatureConfiguration, parmSaRateClassOptionType.trim());
                // CVB - 2013-06-21 - End
                
                // Check if the option value exists
                if (getSaRateClasses.listSize() == 0){
                    addError(CustomMessageRepositoryMDC.nm0079_FeatConfigurationOptionValueIsRequired(parmFeatureConfiguration.getId().getIdValue(),
                            CmAdhocBillMessageBatchParametersLookup.constants.SA_RATE_CLASS.toLocalizedString()));
                }
                
                Iterator itrFeatConfigOptionValues = getSaRateClasses.iterate();
                while (itrFeatConfigOptionValues.hasNext()){
                    String featConfOptionValue = (String) itrFeatConfigOptionValues.next();

                    List<String> saRateClassOption =  Arrays.asList(featConfOptionValue.trim().split(","));
                    
                    // Check if the option value is in a valid format
                    if (saRateClassOption.size() != 2){
                        addError(CustomMessageRepositoryMDC.nm0079_FeatConfigurationOptionValueInvalidFormat(parmFeatureConfiguration.getId().getIdValue(),
                                CmAdhocBillMessageBatchParametersLookup.constants.SA_RATE_CLASS.toLocalizedString(),
                                VALID_FORMAT_CHARTYPE_CHARVALUE_OPTION_VALUE));
                    }
                   
                    // Check if the Characteristic Type and Value are valid
                    CharacteristicType_Id charTypeId = new  CharacteristicType_Id(saRateClassOption.get(0));
                    if (isNull(charTypeId.getEntity())){
                        addError(CustomMessageRepositoryMDC.nm0079_FeatConfigurationOptionValueInvalidValue(parmFeatureConfiguration.getId().getIdValue(),
                                saRateClassOption.get(0), OPTION_VALUE_ENTITY_CHARTYPE,
                                CmAdhocBillMessageBatchParametersLookup.constants.SA_RATE_CLASS.toLocalizedString()));
                    }
                    CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charTypeId, saRateClassOption.get(1));
                    if (isNull(charValueId.getEntity())){
                        addError(CustomMessageRepositoryMDC.nm0079_FeatConfigurationOptionValueInvalidValue(parmFeatureConfiguration.getId().getIdValue(),
                                saRateClassOption.get(1), OPTION_VALUE_ENTITY_CHARVALUE,
                                CmAdhocBillMessageBatchParametersLookup.constants.SA_RATE_CLASS.toLocalizedString()));
                    }
                    
                    // Check if the Characteristic Type is valid for the Service Agreement entity
                    CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charTypeId, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT);
                    if (isNull(charEntityId.getEntity())){
                        addError(CustomMessageRepositoryMDC.nm0079_FeatConfigurationOptionValueInvalidCharTypeForEntity(parmFeatureConfiguration.getId().getIdValue(),
                                charTypeId.getIdValue(), CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().fetchLanguageDescription()));
                    }
                    
                    charTypes.add(new CharacteristicType_Id(saRateClassOption.get(0)).getEntity());
                    charValues.add(saRateClassOption.get(1));
                }
            }
            
        }

        public boolean executeWorkUnit(ThreadWorkUnit threadWorkUnit)
        throws ThreadAbortedException, RunAbortedException {

            bill = ((Bill_Id) threadWorkUnit.getPrimaryId()).getEntity();

            // Check if Bill has existing Bill Message
            Query getExistingBillMessage = cmGetExistingBillMessage();
            if (getExistingBillMessage.listSize() > 0){
                return true;
            }
            
            // Create the Bill Message if the associated Bill Segments exist
            if (notBlank(parmSaTypeOptionType) || notBlank(parmSaRateClassOptionType)){                
                Query getAssociatedBillSegment = cmGetAssociatedBillSegment();
                if (getAssociatedBillSegment.listSize() > 0){
                    cmCreateBillMessage(parmBillMessage);
                }
            }

            return true;
        }
        
        /**
         * Create a Bill Message that is of a specific Bill Message Type
         * @param billMessageType BillMessageType
         */
        private void cmCreateBillMessage(BillMessageType billMessageType) {
            bill.getMessages().add(new BillMessage_DTO(), billMessageType.getId());
        }

        /**
         * Get the existing Bill Message
         * @return query Query
         */
        private Query cmGetExistingBillMessage() {
        	//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
//        	Query query = createQuery("FROM BillMessage BM "
//                    + "WHERE BM.id.bill.id = :billId "
//                    + "AND BM.id.billMessage = :billMessageType");
        	
        	Query query = createQuery("FROM BillMessage BM "
                    + "WHERE BM.id.bill.id = :billId "
                    + "AND BM.id.billMessage = :billMessageType " , getClass().getName());
        	
        	//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            query.bindId("billId", bill.getId());
            query.bindId("billMessageType", parmBillMessage.getId());
            query.addResult("billMessage", "BM.id.billMessage");

            return query;
        }
        
        /**
         * Get the Feature Configuration Option Value
         * @param featureConfiguration FeatureConfiguration
         * @param optionType String
         * @return query Query
         */
        private Query cmGetFeatureConfigurationOptionValue(FeatureConfiguration featureConfiguration, String optionType) {
        	
        	//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
//            Query query = createQuery("FROM FeatureConfigurationOption FCO "
//                    + "WHERE FCO.id.workforceManagementSystem = :featConfName "
//                    + "AND FCO.id.optionType = :optionType ");
        	Query query = createQuery("FROM FeatureConfigurationOption FCO "
        			+ "WHERE FCO.id.workforceManagementSystem = :featConfName "
        			+ "AND FCO.id.optionType = :optionType " , getClass().getName());
        	//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
        	
            query.bindEntity("featConfName", featureConfiguration);
            query.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, optionType);
            query.addResult("optionValue", "FCO.value");
           
            return query;
        }
        
        /**
         * Get the associated Bill Segment
         * @return query Query
         */
        private Query cmGetAssociatedBillSegment() {
            StringBuilder queryStringBuilder =  new StringBuilder();
            queryStringBuilder.append("FROM BillSegment BS ");
            queryStringBuilder.append("WHERE BS.billId = :billId ");
            queryStringBuilder.append("AND BS.billSegmentStatus = :frozen ");
            
            if (notBlank(parmSaTypeOptionType)){
                // Check if the Bill Segment is of any of the associated SA Types in the Feature Configuration
                queryStringBuilder.append("AND EXISTS (FROM ServiceAgreement SA ");
                queryStringBuilder.append("WHERE SA = BS.serviceAgreement ");
                queryStringBuilder.append("AND ");
                
                for (int i = 0; i < cisDivisions.size(); i++){
                    queryStringBuilder.append("(SA.serviceAgreementType.id.division = :cisDivision" + i + " ");                    
                    queryStringBuilder.append("AND SA.serviceAgreementType.id.saType = :saTypeCode" + i + ") ");
                    
                    if (i < cisDivisions.size() - 1){
                        queryStringBuilder.append("OR ");
                    }
                }
                
                queryStringBuilder.append(") ");
            }
            
            if (notBlank(parmSaRateClassOptionType)){
                // Check if the SA has any of the associated SA Characteristic Type and values in the Feature Configuration
                queryStringBuilder.append("AND EXISTS (FROM ServiceAgreementCharacteristic SAC1 ");
                queryStringBuilder.append("WHERE SAC1.id.serviceAgreement = BS.serviceAgreement ");
                queryStringBuilder.append("AND ");
                
                for (int i = 0; i < charTypes.size(); i++){
                    queryStringBuilder.append("(SAC1.id.characteristicType = :charType" + i + " ");
                    queryStringBuilder.append("AND SAC1.id.effectiveDate <= :processDate ");
                    queryStringBuilder.append("AND (SAC1.characteristicValue = :charValue" + i + " ");
                    queryStringBuilder.append("OR SAC1.adhocCharacteristicValue = :adhocCharValue" + i + " ");
                    queryStringBuilder.append("OR SAC1.characteristicValueForeignKey1 = :fkCharValue" + i + ") ");
                    queryStringBuilder.append("AND NOT EXISTS (FROM ServiceAgreementCharacteristic SAC2 ");
                    queryStringBuilder.append("WHERE SAC2.id.serviceAgreement = SAC1.id.serviceAgreement ");
                    queryStringBuilder.append("AND SAC2.id.characteristicType = SAC1.id.characteristicType ");
                    queryStringBuilder.append("AND (SAC2.id.effectiveDate <= :processDate ");
                    queryStringBuilder.append("AND SAC2.id.effectiveDate > SAC1.id.effectiveDate)))");
                    
                    if (i < charTypes.size() - 1){
                        queryStringBuilder.append("OR ");
                    }
                }
                queryStringBuilder.append(")");
            }
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            // Query query = createQuery(queryStringBuilder.toString());
            Query query = createQuery(queryStringBuilder.toString() , getClass().getName());

            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            query.bindId("billId", bill.getId());
            query.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);            
            
            if (notBlank(parmSaTypeOptionType)){
                for (int i = 0; i < cisDivisions.size(); i++){
                    query.bindEntity("cisDivision" + i, cisDivisions.get(i));
                }

                for (int i = 0; i < saTypeCodes.size(); i++){
                    query.bindStringProperty("saTypeCode" + i, ServiceAgreementType.properties.saType, saTypeCodes.get(i));
                }
            }

            if (notBlank(parmSaRateClassOptionType)){
                query.bindDate("processDate", getProcessDateTime().getDate());
                for (int i = 0; i < charTypes.size(); i++){
                    query.bindEntity("charType" + i, charTypes.get(i));
                }
                for (int i = 0; i < charValues.size(); i++){
                    query.bindStringProperty("charValue" + i, ServiceAgreementCharacteristic.properties.characteristicValue, charValues.get(i));
                    query.bindStringProperty("adhocCharValue" + i, ServiceAgreementCharacteristic.properties.characteristicValue, charValues.get(i));
                    query.bindStringProperty("fkCharValue" + i, ServiceAgreementCharacteristic.properties.characteristicValue, charValues.get(i));
                    
                }
            }
            
            return query;
        }
    }
}
