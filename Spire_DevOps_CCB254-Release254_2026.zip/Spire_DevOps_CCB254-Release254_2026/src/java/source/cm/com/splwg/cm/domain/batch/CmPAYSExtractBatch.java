/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * PAYS Extract Batch
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                                                                
 * 2022-02-11   JVitug     B-20169. Initial Version                                                
 *******************************************************************************
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.math.BigInteger;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.SeveranceStatusLookup;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass_Id;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.data.AccountMailingAddressData;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author jvitug
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CUST_CLASS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = NBR_OF_RECORDS, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CC_CL_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CC_TYPE_CD, required = true, type = string)
 *            , @BatchJobSoftParameter (name = SKIP_MONTHS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MIN_SVC_HIST, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MIN_USAGE, type = string)
 *            , @BatchJobSoftParameter (name = BKRPT_MONTHS, required = true, type = string)})
 */
public class CmPAYSExtractBatch extends CmPAYSExtractBatch_Gen {
	
    //Batch Parameters
	String filePath;
	String fileName;
	CisDivision cisDivision;
	String customerClasses;
	CustomerContactClass customerContactClass;
	String customerContactType;
	BigInteger numberOfRecords;
	BigInteger skipMonths;
	BigInteger minimumServiceHistory;
	BigDecimal minimumUsage;
	String minUsageStr = "";
	BigInteger bankruptcyMonths;
	
	// Constants
    private final String COMMA = ",";
    private final String QUOTE = "'";
    private final String FILE_PATH = "FILE_PATH";
    private final String CUST_CLASS = "CUST_CLASS";
    private final String NBR_OF_RECORDS = "NBR_OF_RECORDS";
    private final String CC_TYPE_CD = "CC_TYPE_CD";
    private final String SKIP_MONTHS = "SKIP_MONTHS";
    private final String MIN_SVC_HIST = "MIN_SVC_HIST";
    private final String MIN_USAGE = "MIN_USAGE";
    private final String BKRPT_MONTHS = "BKRPT_MONTHS";	
    
    @Override
	public void validateSoftParameters(boolean isNewRun) {
    	
    	filePath = getParameters().getFILE_PATH();
    	fileName = getParameters().getFILE_NAME();
    	cisDivision = getParameters().getCIS_DIVISION();
    	customerClasses = getParameters().getCUST_CLASS();
    	customerContactClass = getParameters().getCC_CL_CD();
    	customerContactType = getParameters().getCC_TYPE_CD();
    	minUsageStr = getParameters().getMIN_USAGE();
    	
        // Validate that File Path is a valid directory
        if (notBlank(getParameters().getFILE_PATH())){
            File tempPath = new File(getParameters().getFILE_PATH());
            if (!tempPath.isDirectory()){
                addError(CustomMessageRepositorySpireOne.b20169_invalidFilePath(FILE_PATH, filePath));
            }
        }
        
        //Validate the Customer Class parameter that they are valid.
        String[] customerClassValidationArray = customerClasses.split(COMMA);
        CustomerClass_Id validator;
        for(String customerClassStr : customerClassValidationArray) {
        	validator = new CustomerClass_Id(customerClassStr.trim());
        	
        	if(isNull(validator.getEntity())) {
        		addError(CustomMessageRepositorySpireOne.b20169_invalidAlgParmValForEntity(CUST_CLASS, customerClassStr, "Customer Class"));
        	}
        }
        
        //Validate that the customer contact type is valid
        String customerContactTypeValidator = getParameters().getCC_TYPE_CD();
        CustomerContactType_Id ccTypeValidator = new CustomerContactType_Id(customerContactClass , customerContactType);
        
        if(isNull(ccTypeValidator.getEntity())) {
        	addError(CustomMessageRepositorySpireOne.b20169_invalidCustomerContactTypeForClass(CC_TYPE_CD, customerContactTypeValidator , customerContactClass.getId().getTrimmedValue()));
        }
        
        //Validate that the number of records is greater than -1
        try {
        	numberOfRecords = BigInteger.valueOf(Integer.parseInt(getParameters().getNBR_OF_RECORDS()));
        }catch (Exception e) {
        	addError(CustomMessageRepositorySpireOne.b20169_invalidAlgParmVal(NBR_OF_RECORDS, getParameters().getNBR_OF_RECORDS()));
        }
        
        if(numberOfRecords.compareTo(BigInteger.ZERO) <= 0) {
        	addError(CustomMessageRepositorySpireOne.b20169_AlgParmValShouldBeGreaterThanZero(NBR_OF_RECORDS, numberOfRecords.toString()));
        }
        //Validate that skip months is greater than -1
        try {
        	skipMonths = BigInteger.valueOf(Integer.parseInt(getParameters().getSKIP_MONTHS()));
        }catch(Exception e) {
        	addError(CustomMessageRepositorySpireOne.b20169_invalidAlgParmVal(SKIP_MONTHS, getParameters().getSKIP_MONTHS()));
        }
        
        
        if(skipMonths.compareTo(BigInteger.ZERO) < 0) {
        	addError(CustomMessageRepositorySpireOne.b20169_parmValShouldBeAtLeastZero(SKIP_MONTHS, skipMonths.toString()));
        }
        
        //Validate that the minimum service history is greater than -1
        try {
        	minimumServiceHistory = BigInteger.valueOf(Integer.parseInt(getParameters().getMIN_SVC_HIST()));
        }catch (Exception e) { 
        	addError(CustomMessageRepositorySpireOne.b20169_invalidAlgParmVal(MIN_SVC_HIST, getParameters().getMIN_SVC_HIST()));
        }
         
        if(minimumServiceHistory.compareTo(BigInteger.ZERO) < 0) {
        	addError(CustomMessageRepositorySpireOne.b20169_parmValShouldBeAtLeastZero(MIN_SVC_HIST, minimumServiceHistory.toString()));
        } 
        
        //If supplied , validate that the minimum usage is greater than -1
        if(!isBlankOrNull(minUsageStr)) {
        	try {
        		minimumUsage = new BigDecimal(minUsageStr);
        	} catch (Exception e) { 
        		addError(CustomMessageRepositorySpireOne.b20169_invalidAlgParmVal(MIN_USAGE, getParameters().getMIN_USAGE()));
        	}
        	
        	if(minimumUsage.compareTo(BigDecimal.ZERO) < 0) {
        		addError(CustomMessageRepositorySpireOne.b20169_parmValShouldBeAtLeastZero(MIN_USAGE, minimumUsage.toString()));
        	}
        }
        
        //Validate that the bankruptcy months is greater than -1
        try {
        	bankruptcyMonths = BigInteger.valueOf(Integer.parseInt(getParameters().getBKRPT_MONTHS()));
        }catch (Exception e) {
        	addError(CustomMessageRepositorySpireOne.b20169_invalidAlgParmVal(BKRPT_MONTHS, getParameters().getBKRPT_MONTHS()));
        }
        
        if(bankruptcyMonths.compareTo(BigInteger.ZERO) < 0) {
        	addError(CustomMessageRepositorySpireOne.b20169_parmValShouldBeAtLeastZero(BKRPT_MONTHS, bankruptcyMonths.toString()));
        }
	}

	public JobWork getJobWork() {
		String encloseCustomerClassesInQuotes = encloseCustomerClassesInQuotes();
		Date minServiceDateForInclusion = getProcessDateTime().getDate().addMonths(minimumServiceHistory.negate().intValue());
		
		StringBuilder stringSql = new StringBuilder();
		
		stringSql.append("SELECT ");
		stringSql.append(   "ACCT.ACCT_ID ");
		stringSql.append("FROM ");
		stringSql.append(   "CI_ACCT ACCT ");
		stringSql.append("WHERE ");
		stringSql.append(   "ACCT.CIS_DIVISION = :cisDivision ");
		stringSql.append("AND ");
		stringSql.append(   "ACCT.CUST_CL_CD IN (" + encloseCustomerClassesInQuotes +") ");
		stringSql.append("AND ");
		stringSql.append(   "EXISTS ( ");
		stringSql.append(      "SELECT ");
		stringSql.append(         "'X' ");
		stringSql.append(      "FROM ");
		stringSql.append(         "CI_SA SA, ");
		stringSql.append(         "CI_PREM PREM, ");
		stringSql.append(         "CM_PAYS_ZIP PAYS ");
		stringSql.append(      "WHERE ");
		stringSql.append(         "SA.ACCT_ID = ACCT.ACCT_ID ");
		stringSql.append(      "AND ");
		stringSql.append(         "SA.SA_STATUS_FLG = :active ");
		stringSql.append(      "AND ");
		stringSql.append(         "SA.CHAR_PREM_ID = PREM.PREM_ID ");
		stringSql.append(      "AND ");
		stringSql.append(         "SUBSTR(PREM.POSTAL , 1 , 5) = PAYS.PAYS_ZIP ");
		stringSql.append(      "AND ");
		stringSql.append(         "SA.START_DT < :date ");
		stringSql.append(   ") ");
		
		PreparedStatement getMainPreparedStatement = createPreparedStatement(stringSql.toString(), getClass().getName());
		getMainPreparedStatement.bindId("cisDivision", cisDivision.getId());
		getMainPreparedStatement.bindLookup("active" , ServiceAgreementStatusLookup.constants.ACTIVE);
		getMainPreparedStatement.bindDate("date", minServiceDateForInclusion);
		
		QueryIterator iterator = getMainPreparedStatement.iterate();
		
		return createJobWorkForQueryIterator(iterator, this);	
		
    }
	
	/**
	 * Encloses the Customer Classes Batch parameter in quotes.
	 * @return Customer Classes enclosed in Quotes (e.g 'RES', 'IND')
	 */
	private String encloseCustomerClassesInQuotes() {
		String returnValue = "";

		String[] splitter = customerClasses.split(COMMA);

		String customerClassStr = "";
		for (int i = 0 ; i < splitter.length ; i++) {
			customerClassStr = splitter[i].trim();

			customerClassStr = QUOTE + customerClassStr + QUOTE;
			//Enclose them in quotes and add them to the string to be returned
			if(i == (splitter.length - 1)) {
				returnValue = returnValue + customerClassStr;
			} else {
				returnValue = returnValue + customerClassStr + COMMA;
			}
		}

		return returnValue;
	}

    @Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow queryResultRow) {
    	
    	String accountIdString = (String)queryResultRow.get("ACCT_ID");
    	Account_Id accountId = new Account_Id(accountIdString);
    	
    	ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
    	threadWorkUnit.setPrimaryId(accountId);
    	
    	return threadWorkUnit;
	}

	public Class<CmPAYSExtractBatchWorker> getThreadWorkerClass() {
        return CmPAYSExtractBatchWorker.class;
    }

    public static class CmPAYSExtractBatchWorker extends
    	CmPAYSExtractBatchWorker_Gen {
    	
        // Constants
    	//Header variables
    	private final String nameHeader = "MI_CustomerName";
    	private final String mailingAddressHeader = "MI_MailingAddress";
    	private final String mailingStateHeader = "MI_MailingState";
    	private final String mailingCityHeader = "MI_MailingCity";
    	private final String mailingZipCodeHeader = "MI_MailingZipCode";
    	private final String serviceAddressHeader = "MI_ServiceAddress";
    	private final String serviceStateHeader = "MI_ServiceState";
    	private final String serviceCityHeader = "MI_ServiceCity";
    	private final String serviceZipCodeHeader = "MI_ServiceZipCode";
    	private final String naturalGasSupplierHeader = "NG_FuelSupplier";
    	private final String participantGasAccountHeader = "NG_AcctNo";
    	private final String premiseIDforNGHeader = "NG_PremiseID";
    	private final String meterNumberHeader = "NG_MeterNumber";
    	private final String rateHeader = "NG_Rate";
    	private final String specialBillingHeader = "NG_Special";
    	private final String startDateBill1Header = "NG_FuelMth0Date";
    	private final String endBill1Header = "NG_FuelMth1Date";
    	private final String month1GasUsageHeader = "NG_FuelMth1Usage";
    	private final String month1CostHeader = "NG_FuleMth1Cost";
    	private final String endBill2Header = "NG_FuelMth2Date";
    	private final String month2GasUsageHeader = "NG_FuelMth2Usage";
    	private final String month2CostHeader = "NG_FuleMth2Cost";
    	private final String endBill3Header = "NG_FuelMth3Date";
    	private final String month3GasUsageHeader = "NG_FuelMth3Usage";
    	private final String month3CostHeader = "NG_FuleMth3Cost";
    	private final String endBill4Header = "NG_FuelMth4Date";
    	private final String month4GasUsageHeader = "NG_FuelMth4Usage";
    	private final String month4CostHeader = "NG_FuleMth4Cost";
    	private final String endBill5Header = "NG_FuelMth5Date";
    	private final String month5GasUsageHeader = "NG_FuelMth5Usage";
    	private final String month5CostHeader = "NG_FuleMth5Cost";
    	private final String endBill6Header = "NG_FuelMth6Date";
    	private final String month6GasUsageHeader = "NG_FuelMth6Usage";
    	private final String month6CostHeader = "NG_FuleMth6Cost";
    	private final String endBill7Header = "NG_FuelMth7Date";
    	private final String month7GasUsageHeader = "NG_FuelMth7Usage";
    	private final String month7CostHeader = "NG_FuleMth7Cost";
    	private final String endBill8Header = "NG_FuelMth8Date";
    	private final String month8GasUsageHeader = "NG_FuelMth8Usage";
    	private final String month8CostHeader = "NG_FuleMth8Cost";
    	private final String endBill9Header = "NG_FuelMth9Date";
    	private final String month9GasUsageHeader = "NG_FuelMth9Usage";
    	private final String month9CostHeader = "NG_FuleMth9Cost";
    	private final String endBill10Header = "NG_FuelMth10Date";
    	private final String month10GasUsageHeader = "NG_FuelMth10Usage";
    	private final String month10CostHeader = "NG_FuleMth10Cost";
    	private final String endBill11Header = "NG_FuelMth11Date";;
    	private final String month11GasUsageHeader = "NG_FuelMth11Usage";
    	private final String month11CostHeader = "NG_FuleMth11Cost";
    	private final String endBill12Header = "NG_FuelMth12Date";
    	private final String month12GasUsageHeader = "NG_FuelMth12Usage";
    	private final String month12CostHeader = "NG_FuleMth12Cost";
    	private final String COMMA = ",";
    	private final String BUDGET = "BUD";
    	
    	
    	// Batch Parameters
    	String filePath;
    	String fileName;
    	CisDivision cisDivision;
    	String customerClasses;
    	CustomerContactClass customerContactClass;
    	String customerContactType;
    	BigInteger numberOfRecords;
    	BigInteger skipMonths;
    	BigInteger minimumServiceHistory;
    	BigDecimal minimumUsage;
    	BigInteger bankruptcyMonths;    
        
        // Work variables
        private File extractFile;
        private BufferedWriter extractFileWriter;
        Account account;
        Account_Id accountId;
        Bool shouldExtractAccount = Bool.FALSE;
        List<SQLResultRow> serviceAgreements;
        private static int recordCount = 0;
        DateFormat dateFormat = new DateFormat("yyyyMMdd");
        BigDecimal totalUsage;
        //We create a flag to catch the possibility that the usage or service history
        //is not enough. We skip the account if these criteria are met
        Bool shouldProcessAccount = Bool.TRUE;
        Premise mailingPremiseOfAccount;
        StringBuilder extractBuffer;
        
        //Extract fields
        private String name;
        private String mailingAddress;
        private String mailingState;
        private String mailingCity;
        private String mailingZipCode;
        private String serviceAddress;
        private String serviceState;
        private String serviceCity;
        private String serviceZipCode;
        private String naturalGasSupplier = "SPIRE";
        private String participantGasAccount;
        private String premiseIDforNG;
        private String meterNumber;
        private String rate;
        private String specialBilling;
        private Date startDateBill1;
        private Date endBill1;
        private BigDecimal month1GasUsage;
        private BigDecimal month1Cost;
        private Date endBill2;
        private BigDecimal month2GasUsage;
        private BigDecimal month2Cost;
        private Date endBill3;
        private BigDecimal month3GasUsage;
        private BigDecimal month3Cost;
        private Date endBill4;
        private BigDecimal month4GasUsage;
        private BigDecimal month4Cost;
        private Date endBill5;
        private BigDecimal month5GasUsage;
        private BigDecimal month5Cost;
        private Date endBill6;
        private BigDecimal month6GasUsage;
        private BigDecimal month6Cost;
        private Date endBill7;
        private BigDecimal month7GasUsage;
        private BigDecimal month7Cost;
        private Date endBill8;
        private BigDecimal month8GasUsage;
        private BigDecimal month8Cost;
        private Date endBill9;
        private BigDecimal month9GasUsage;
        private BigDecimal month9Cost;
        private Date endBill10;
        private BigDecimal month10GasUsage;
        private BigDecimal month10Cost;
        private Date endBill11;
        private BigDecimal month11GasUsage;
        private BigDecimal month11Cost;
        private Date endBill12;
        private BigDecimal month12GasUsage;
        private BigDecimal month12Cost;
        
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }     

        @Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
        	//Prevent Lazy Initiation Exception
        	filePath = getParameters().getFILE_PATH();
        	fileName = getParameters().getFILE_NAME();
        	cisDivision = getParameters().getCIS_DIVISION();
        	customerClasses = getParameters().getCUST_CLASS();
        	customerContactClass = getParameters().getCC_CL_CD();
        	customerContactType = getParameters().getCC_TYPE_CD();
        	numberOfRecords = new BigInteger(getParameters().getNBR_OF_RECORDS());
        	bankruptcyMonths = new BigInteger(getParameters().getBKRPT_MONTHS());
        	skipMonths = new BigInteger(getParameters().getSKIP_MONTHS());
        	minimumServiceHistory = new BigInteger(getParameters().getMIN_SVC_HIST());
        	if(!isBlankOrNull(getParameters().getMIN_USAGE())) {
        		minimumUsage = new BigDecimal(getParameters().getMIN_USAGE());
        	}
            
        	// Open Extract File
            try {
            	extractFile = new File(filePath,fileName);   
            	extractFileWriter = new BufferedWriter(new FileWriter(extractFile));  
            	writeHeadersToExtractFile();
            }
            catch(Exception e) {
                throw new RunAbortedException(CustomMessageRepositorySpireOne.b20169_errorInOpeningFile(extractFile.getAbsolutePath()));
            }
		}

        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
        	
        	 int processedRecord = 0;
             int recordsInError = 0;
        	initializeVariables();
        	
        	
        	if(recordCount < numberOfRecords.intValue()) {
        	
        		accountId = (Account_Id) unit.getPrimaryId();
        		account = accountId.getEntity();
        		

        		shouldExtractAccount = determineEligibilityOfAccount();

        		if(shouldExtractAccount.isTrue()) {
        			getAccountMainPersonMailingAddress();
        			
        			if(notNull(account.getBudgetPlanId())) {
        				specialBilling = BUDGET;
        			}
        			
        			iterateThroughSAListAndPrintRecordsToExtract();
        			
        			if(shouldProcessAccount.isTrue()) {
            			recordCount++;
                		processedRecord++;
                		//Create a customer contact for the account's main person.
                		createPAYSCustomerContact(account.getMainPerson());
            		}
        		}
        	}

        	WorkUnitResult result = new WorkUnitResult(true);
    		
    		result.setUnitsProcessed(processedRecord);
    		result.setUnitsInError(recordsInError);
    		
    		return result;
        }
        
        /**
         * Method that initializes variables
         */
        private void initializeVariables() {
        	shouldExtractAccount = Bool.FALSE;
        	extractBuffer = new StringBuilder();
        	serviceAgreements = null;
        	if(notNull(minimumUsage) && minimumUsage.compareTo(BigDecimal.ZERO) > 0) {
        		totalUsage = BigDecimal.ZERO;
        	}
        	
        	//Extract variables
        	name = "";
        	mailingAddress = "";
        	mailingState = "";
        	mailingCity = "";
        	mailingZipCode = "";
        	serviceAddress = "";
        	serviceState = "";
        	serviceCity = "";
        	serviceZipCode = "";
        	participantGasAccount = "";
        	premiseIDforNG = "";
        	meterNumber = "";
        	rate = "";
        	specialBilling = "";
        	startDateBill1 = null;
        	endBill1 = null;
        	month1GasUsage = BigDecimal.ZERO;
        	month1Cost = BigDecimal.ZERO;
        	endBill2 = null;
        	month2GasUsage = BigDecimal.ZERO;
        	month2Cost = BigDecimal.ZERO;
        	endBill3 = null;
        	month3GasUsage = BigDecimal.ZERO;
        	month3Cost = BigDecimal.ZERO;
        	endBill4 = null;
        	month4GasUsage = BigDecimal.ZERO;
        	month4Cost = BigDecimal.ZERO;
        	endBill5 = null;
        	month5GasUsage = BigDecimal.ZERO;
        	month5Cost = BigDecimal.ZERO;
        	endBill6 = null;
        	month6GasUsage = BigDecimal.ZERO;
        	month6Cost = BigDecimal.ZERO;
        	endBill7 = null;
        	month7GasUsage = BigDecimal.ZERO;
        	month7Cost = BigDecimal.ZERO;
        	endBill8 = null;
        	month8GasUsage = BigDecimal.ZERO;
        	month8Cost = BigDecimal.ZERO;
        	endBill9 = null;
        	month9GasUsage = BigDecimal.ZERO;
        	month9Cost = BigDecimal.ZERO;
        	endBill10 = null;
        	month10GasUsage = BigDecimal.ZERO;
        	month10Cost = BigDecimal.ZERO;
        	endBill11 = null;
        	month11GasUsage = BigDecimal.ZERO;
        	month11Cost = BigDecimal.ZERO;
        	endBill12 = null;
        	month12GasUsage = BigDecimal.ZERO;
        	month12Cost = BigDecimal.ZERO;
        	shouldProcessAccount = Bool.TRUE;
        }
        
        /**
         * This method determines whether an account should be extracted for PAYS Program processing. To be included in the PAYS extract , the account 
         * must : 
         * 		- have an active gas SA whose start date is prior to the process date minus skip-months parameter
         * 		- has Opted in to Marketing Communications (OptedOut value of main person's CM-PMOC Service Task is IN)
         * 		- was not recently included in a PAYS Extract from the Process date minus skip - months up to the process date 
         * 		- Characteristic Premises of the SAs of the account do not have a Landlord agreement
         * 		- Does not have an active Severance Process
         * 		- Main person of the account is not linked to any Bankruptcy or Write-off SA whose start date 
         * 		  is the same or after the process date minus the bankruptcy months parameter
         * 
         * @return True if all the criteria specified above is true, false if otherwise.
         */
        private Bool determineEligibilityOfAccount() {
        	Bool shouldExtractAccount = Bool.FALSE;
        	
        	//Check if the Account has SAs whose start date is prior to the current process date minus the SKIP-MONTHS
        	//parameter and whose premise' zip code is in the CM_PAYS_ZIP table
        	serviceAgreements = retrieveServiceAgreements();
        	
        	if(notNull(serviceAgreements) && serviceAgreements.size() > 0) {
        		// check whether the main person of the account has opted out of marketing communications.
        		if(hasCustomerOptedOutOfMarketingCommunications().isFalse()) {
        			//Determine if the account was included in a recent PAYS Extract 
        			if(wasIncludedInRecentPAYSExtract().isFalse()) {
        				//Determine if any of the account's SA's characteristic premise has a landlord agreement. 
        				if(doesAccountSAHaveLandlordAgreement().isFalse()) {
        					//Determine if the account has an active severance process
        					if(doesAccountHaveAnActiveSeveranceProcess().isFalse()) {
        						//Determine if the account's main person associated has any other account with a bankruptcy or write-off SA with a start date in the past months
        						List<SQLResultRow> bankruptcySAs = null;
        						bankruptcySAs = retrieveBankruptcyWriteOffSAsLinkedToPerson();
        						if(bankruptcySAs.size() < 1) {
        							shouldExtractAccount = Bool.TRUE;
        						}
        					}
        				}
        			}
        		}
        	}
        	
        	return shouldExtractAccount;
        }
        
        /**
         * Get the list of SAs of the account whose Start Date is prior to the 
         * current date - skip-months parameter. 
         * @return List of SAs of the account prior to the current date - skip-months parameter
         */
        private List<SQLResultRow> retrieveServiceAgreements() {
        	List<SQLResultRow> saList = null;
        	Date resultDateAfterSkipMonths = getProcessDateTime().getDate().addMonths(minimumServiceHistory.negate().intValue());
        	StringBuilder stringSql = new StringBuilder();
        	
        	stringSql.append("SELECT ");
        	stringSql.append(   "SA.CHAR_PREM_ID , ");
        	stringSql.append(   "SA.SA_ID ");
        	stringSql.append("FROM ");
        	stringSql.append(   "CI_SA SA, ");
        	stringSql.append(   "CI_SA_TYPE SAT ");
        	stringSql.append("WHERE ");
        	stringSql.append(   "SA.ACCT_ID = :accountId ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.SA_TYPE_CD = SAT.SA_TYPE_CD ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.CIS_DIVISION = SAT.CIS_DIVISION ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.SA_STATUS_FLG = :active ");
        	stringSql.append("AND ");
        	stringSql.append(   "SAT.SVC_TYPE_CD = 'G' ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.START_DT < :dateAfterSkipMonths ");
        	stringSql.append("AND ");
        	stringSql.append(   "EXISTS (");
        	stringSql.append(       "SELECT ");
        	stringSql.append(          "'X' ");
        	stringSql.append(       "FROM ");
        	stringSql.append(          "CI_PREM PREM, ");
        	stringSql.append(          "CM_PAYS_ZIP PAYS ");
        	stringSql.append(       "WHERE ");
        	stringSql.append(          "PREM.PREM_ID = SA.CHAR_PREM_ID ");
        	stringSql.append(       "AND ");
        	stringSql.append(          "SUBSTR(PREM.POSTAL, 1 , 5) = PAYS.PAYS_ZIP " );
        	stringSql.append(   ")");

        	PreparedStatement sql = createPreparedStatement( stringSql.toString () , getClass().getName());
        	sql.bindId("accountId" , accountId);
        	sql.bindLookup("active" , ServiceAgreementStatusLookup.constants.ACTIVE);
        	sql.bindDate("dateAfterSkipMonths", resultDateAfterSkipMonths);

        	saList = sql.list();
        	sql.close();
        	return saList;
        }
        
        /**
         * Check if the customer has Opted out for Marketing Communications
         * @return True if OptedOut is OUT, false if otherwise
         */
        private Bool hasCustomerOptedOutOfMarketingCommunications() {
        	Bool hasOptedOut = Bool.FALSE;
        	StringBuilder stringSql = new StringBuilder();
        	
        	stringSql.append("SELECT ");
        	stringSql.append(   "xmlType('<root>' || bo_data_area || '</root>').extract('//marketingOptOut/text()').getStringVal() AS MARKETING_OPT_IN ");
        	stringSql.append("FROM ");
        	stringSql.append(   "F1_SVC_TASK TASK, ");
        	stringSql.append(   "F1_SVC_TASK_REL_OBJ OBJ ");
        	stringSql.append("WHERE ");
        	stringSql.append(   "TASK.F1_STASK_TYPE_CD = 'CM-PMOC' ");
        	stringSql.append("AND ");
        	stringSql.append(   "TASK.F1_SVC_TASK_ID = OBJ.F1_SVC_TASK_ID ");
        	stringSql.append("AND ");
        	stringSql.append(   "OBJ.PK_VALUE1 = :mainPerson ");
        	
        	PreparedStatement sql = createPreparedStatement(stringSql.toString() , getClass().getName());
        	sql.bindId("mainPerson", account.getMainPerson().getId());
        	
        	SQLResultRow result = sql.firstRow();
        	sql.close();
        	
        	String hasOptedOutStr = "";
        	if(notNull(result)) {
        		hasOptedOutStr = result.getString("MARKETING_OPT_IN");
        	} else {
        		hasOptedOutStr = "IN";
        	}
        	
        	if(hasOptedOutStr.trim() == "OUT") {
        		hasOptedOut = Bool.TRUE;
        	}
        	
        	return hasOptedOut;
        }
        
        /**
         * Checks if a PAYS Extract Customer Contact was created for the account's main person
         * within a certain range. The start date of the range is calculated
         * by getting the resulting date after subtracting the SKIP-MONTHS parameter from the
         * process date
         * 
         * @return True if a PAYS Extract customer contact was created within the date range, 
         * false if otherwise
         */
        private Bool wasIncludedInRecentPAYSExtract() {
        	Bool wasIncludedInRecentPAYSExtract = Bool.FALSE;
        	Date startDateOfRange = getProcessDateTime().getDate().addMonths(skipMonths.negate().intValue());
        	StringBuilder stringSql = new StringBuilder();
        	
        	stringSql.append("SELECT ");
        	stringSql.append(   "CC.CC_ID ");
        	stringSql.append("FROM ");
        	stringSql.append(   "CI_CC CC ");
        	stringSql.append("WHERE ");
        	stringSql.append(   "CC.PER_ID = :mainPerson ");
        	stringSql.append("AND ");
        	stringSql.append(   "CC.CC_CL_CD = :customerContactClass ");
        	stringSql.append("AND ");
        	stringSql.append(   "CC.CC_TYPE_CD = :customerContactType ");
        	stringSql.append("AND ");
        	stringSql.append(   "(TRUNC(CC.CC_DTTM) >= :startDate AND TRUNC(CC.CC_DTTM) <= :processDate) ");
        	
        	PreparedStatement sql = createPreparedStatement(stringSql.toString() , getClass().getName());
        	sql.bindId("mainPerson" , account.getMainPerson().getId());
        	sql.bindId("customerContactClass", customerContactClass.getId());
        	sql.bindString("customerContactType" , customerContactType  , "CC_TYPE_CD");
        	sql.bindDate("startDate" , startDateOfRange);
        	sql.bindDate("processDate" , getProcessDateTime().getDate());
        	
        	SQLResultRow result = sql.firstRow();
        	sql.close();
        	
        	if(notNull(result)) {
        		wasIncludedInRecentPAYSExtract = Bool.TRUE;
        	}
        	
        	return wasIncludedInRecentPAYSExtract;
        }
                   
        /**
         * This method checks if any of the account's SA's Characteristic Premise 
         * has a land lord agreement. Returns true if one of the account's SA has a landlord agreement, false if otherwise
         * @return
         */
        private Bool doesAccountSAHaveLandlordAgreement() {
        	Bool doesAccountSAHaveLandlordAgreement = Bool.FALSE;
        	StringBuilder stringSql = new StringBuilder();
        	
        	stringSql.append("SELECT ");
        	stringSql.append(   "PREM.LL_ID ");
        	stringSql.append("FROM ");
        	stringSql.append(   "CI_PREM PREM , ");
        	stringSql.append(   "CI_SA SA ");
        	stringSql.append("WHERE ");
        	stringSql.append(   "SA.ACCT_ID = :accountId ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.SA_STATUS_FLG NOT IN (:closed , :cancelled) ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.CHAR_PREM_ID = PREM.PREM_ID ");
        	stringSql.append("AND ");
        	stringSql.append(   "PREM.LL_ID <> ' ' ");
        	
        	PreparedStatement sql = createPreparedStatement(stringSql.toString() , getClass().getName());
        	sql.bindId("accountId" , accountId);
        	sql.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
        	sql.bindLookup("cancelled", ServiceAgreementStatusLookup.constants.CANCELED);
        	
        	SQLResultRow result = sql.firstRow();
        	sql.close();
        	
        	if(notNull(result)) {
        		doesAccountSAHaveLandlordAgreement = Bool.TRUE;
        	}
        	
        	return doesAccountSAHaveLandlordAgreement;
        }
        
        /**
         * This method checks if an active severance process exists for the account.
         * 
         * @return true if there is an active Severance process for the account, 
         * false if otherwise.
         */
        private Bool doesAccountHaveAnActiveSeveranceProcess() {
        	Bool doesAccountHaveAnActiveSeveranceProcess = Bool.FALSE;
        	StringBuilder stringSql = new StringBuilder();
        	
        	stringSql.append("SELECT ");
        	stringSql.append(   "SEV.SEV_PROC_ID ");
        	stringSql.append("FROM ");
        	stringSql.append(   "CI_SA SA , ");
        	stringSql.append(   "CI_SEV_PROC SEV ");
        	stringSql.append("WHERE ");
        	stringSql.append(   "SA.ACCT_ID = :accountId ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.SA_ID = SEV.SA_ID ");
        	stringSql.append("AND ");
        	stringSql.append(   "SEV.SEV_STATUS_FLG = :active ");
        	
        	PreparedStatement sql = createPreparedStatement(stringSql.toString() , getClass().getName());
        	sql.bindId("accountId" , accountId);
        	sql.bindLookup("active" , SeveranceStatusLookup.constants.ACTIVE);
        	
        	SQLResultRow result = sql.firstRow();
        	sql.close();
        	
        	if(notNull(result)) {
        		doesAccountHaveAnActiveSeveranceProcess = Bool.TRUE;
        	}
        	
        	return doesAccountHaveAnActiveSeveranceProcess;
        }
        
        /**
         * Get the list of Bankruptcy SAs linked to a person 
         *  
         * @return List of Bankruptcy SAs linked to Person
         */
        private List<SQLResultRow> retrieveBankruptcyWriteOffSAsLinkedToPerson() {
        	List<SQLResultRow> saList = null;
        	Date resultDateAfterSkipMonths = getProcessDateTime().getDate().addMonths(bankruptcyMonths.negate().intValue());
        	StringBuilder stringSql = new StringBuilder();
        	
        	stringSql.append("SELECT ");
        	stringSql.append(   "SA.SA_ID ");
        	stringSql.append("FROM ");
        	stringSql.append(   "CI_SA SA, ");
        	stringSql.append(   "CI_ACCT_PER ACPER, ");
        	stringSql.append(   "CI_SA_TYPE SAT ");
        	stringSql.append("WHERE ");
        	stringSql.append(   "ACPER.ACCT_ID <> :accountBeingProcessed ");
        	stringSql.append("AND ");
        	stringSql.append(   "ACPER.PER_ID = :mainPerson ");
        	stringSql.append("AND ");
        	stringSql.append(   "ACPER.MAIN_CUST_SW = 'Y' ");
        	stringSql.append("AND ");
        	stringSql.append(   "ACPER.ACCT_ID = SA.ACCT_ID ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.SA_TYPE_CD = SAT.SA_TYPE_CD ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.CIS_DIVISION = SAT.CIS_DIVISION ");
        	stringSql.append("AND ");
        	stringSql.append(   "SAT.SPECIAL_ROLE_FLG = 'WO' ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.SA_STATUS_FLG < :saStatus ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.START_DT >= :dateAfterbankruptcyMonths ");

        	PreparedStatement sql = createPreparedStatement( stringSql.toString () , getClass().getName());
        	sql.bindId("accountBeingProcessed" , accountId);
        	sql.bindId("mainPerson" , account.getMainPerson().getId());
        	sql.bindDate("dateAfterbankruptcyMonths", resultDateAfterSkipMonths);
        	sql.bindLookup("saStatus" , ServiceAgreementStatusLookup.constants.CANCELED);

        	saList = sql.list();
        	sql.close();
        	return saList;
        }
        
        /**
         * This method will get the Account's Main Person Mailing address
         */
        private void getAccountMainPersonMailingAddress() {
        	AccountMailingAddressData personMailingAddress = account.fetchMailingAddress(account.getMainPerson());
        	
        	if(account.getMainPerson().getPersonOrBusiness().isPerson()) {
        		String[] personNameSplitted = account.getMainPerson().getPersonPrimaryName().split(COMMA);
        		
        		name = personNameSplitted[1].trim() + " " + personNameSplitted[0].trim();
        	} else {
        		name = account.getMainPerson().getPersonPrimaryName();
        	}
        	
        	mailingAddress = personMailingAddress.getAddress1().trim() + " " + personMailingAddress.getAddress2().trim() + " " + personMailingAddress.getAddress3().trim() + " " + personMailingAddress.getAddress4().trim();
        	mailingAddress = mailingAddress.trim();
        	mailingCity = personMailingAddress.getCity().trim();
        	if(notNull(personMailingAddress.getState())) {
        		mailingState = personMailingAddress.getState().getId().getState().trim();
        	}
        	mailingZipCode = personMailingAddress.getPostalCode().trim();
        	
        }
        
        /**
         * This method iterates through the list of the account's SAs and retrieves their service address details 
         * and prints the record in the extract
         */
        private void iterateThroughSAListAndPrintRecordsToExtract() {
        	//Create a temporary premise variable to store the premise being processed
        	//this is to consolidate the usages for each of the SA's linked to the premise before outputting
        	Premise premiseTemp = null;
        	Premise premiseBeingProcessed;
        	ServiceAgreement saBeingProcessed;        	
        	participantGasAccount = accountId.getTrimmedValue();
        	
        	for(SQLResultRow cmPaysSA : serviceAgreements) {
        		if(shouldProcessAccount.isFalse()) {
        			return;
        		}
        		
        		premiseBeingProcessed = cmPaysSA.getEntity("CHAR_PREM_ID", Premise.class);
        		saBeingProcessed = cmPaysSA.getEntity("SA_ID" , ServiceAgreement.class);
        		
        		if(isNull(premiseTemp)) {
        			premiseTemp = premiseBeingProcessed;
        			rate = getEffectiveRateDescription(saBeingProcessed);
        			meterNumber = getBadgeNumberOfSAMeter(saBeingProcessed);
        			
        			retrieveServiceAddress(saBeingProcessed);
        			
        		} else if (premiseTemp.getId().compareTo(premiseBeingProcessed.getId()) != 0) {
        			
        			//If the premise being processed is not equal to the value of the premise in the Temporary variable
        			//This means that the premise is now different. We now output the records to the extract. 
        			//This is so that we can output the consolidated usages for accounts that has multiple SAs
        			//for the same premise
        			writeInformationToExtractBuffer();
        			
        			//Set the premise temporary variable to the char premise being processed to start consolidating the usages
        			//of the SAs in the premise
        			premiseTemp = premiseBeingProcessed;
        			
        			//Reset the values for the monthly information (e.g bill1MonthlyUsage , bill2MonthlyCost, etc)
        			resetExtractValues();
        			
        			rate = getEffectiveRateDescription(saBeingProcessed);
        			meterNumber = getBadgeNumberOfSAMeter(saBeingProcessed);
        			retrieveServiceAddress(saBeingProcessed);
        			
        		} 

        		//Continue consolidating the usages for the 12 most recent bill segments 
        		//for each SA having the same characteristic premise
        		retrieveUsagesForSA(saBeingProcessed);
        	}
        	//After the loop, write the last record that was processed
        	//Only write to the file if Account should be processed
        	if(shouldProcessAccount.isTrue()) { 
        		writeInformationToExtractBuffer();
        		try {
        		extractFileWriter.write(extractBuffer.toString());
        		} catch (Exception e) {
                    e.printStackTrace();
                    throw new RunAbortedException(CustomMessageRepositorySpireOne.b20169_errorInWritingFile(extractFile.getAbsolutePath()));
                }
        	}
        }
        
        private String getEffectiveRateDescription(ServiceAgreement sa) {
        	String rateDescription = "";
        	StringBuilder stringSql = new StringBuilder();
        	
        	stringSql.append("SELECT ");
        	stringSql.append(   "RATE.DESCR ");
        	stringSql.append("FROM ");
        	stringSql.append(   "CI_SA_RS_HIST HIST , ");
        	stringSql.append(   "CI_RS_L RATE ");
        	stringSql.append("WHERE ");
        	stringSql.append(   "HIST.SA_ID = :saId ");
        	stringSql.append("AND ");
        	stringSql.append(   "HIST.RS_CD = RATE.RS_CD ");
        	stringSql.append("AND ");
        	stringSql.append(   "HIST.EFFDT = ( ");
        	stringSql.append(      "SELECT " );
        	stringSql.append(         "MAX(HIST2.EFFDT) ");
        	stringSql.append(      "FROM ");
        	stringSql.append(         "CI_SA_RS_HIST HIST2 ");
        	stringSql.append(      "WHERE ");
        	stringSql.append(         "HIST2.SA_ID = HIST.SA_ID ");
        	stringSql.append(      "AND ");
        	stringSql.append(         "HIST2.EFFDT <= :processDate ");
        	stringSql.append(   ") ");
        	
        	PreparedStatement sql = createPreparedStatement(stringSql.toString(), getClass().getName());
        	sql.bindId("saId" ,  sa.getId());
        	sql.bindDate("processDate", getProcessDateTime().getDate());
        	
        	SQLResultRow result = sql.firstRow();
        	sql.close();
        	
        	if(notNull(result)) {
        		rateDescription = result.getString("DESCR");
        	}
        	
        	return rateDescription;
        }
        
        /**
         * This method will get the first Meter badge number 
         * that is linked to the SA
         * @param sa
         * @return
         */
        private String getBadgeNumberOfSAMeter(ServiceAgreement sa) {
        	String badgeNumber = "";
        	StringBuilder stringSql = new StringBuilder();
        	
        	stringSql.append("SELECT ");
        	stringSql.append(   "MTR.BADGE_NBR ");
        	stringSql.append("FROM ");
        	stringSql.append(   "CI_MTR MTR ,");
        	stringSql.append(   "CI_SA_SP SASP ,");
        	stringSql.append(   "CI_MTR_CONFIG CFG ,");
        	stringSql.append(   "CI_SP_MTR_HIST HIST ");
        	stringSql.append("WHERE ");
        	stringSql.append(   "SASP.SA_ID = :saId ");
        	stringSql.append("AND ");
        	stringSql.append(   "SASP.START_DTTM = ( ");
        	stringSql.append(      "SELECT ");
        	stringSql.append(         "MAX(SASP2.START_DTTM) ");
        	stringSql.append(      "FROM ");
        	stringSql.append(         "CI_SA_SP SASP2 ");
        	stringSql.append(      "WHERE ");
        	stringSql.append(         "SASP2.SA_ID = SASP.SA_ID ");
        	stringSql.append(      "AND ");
        	stringSql.append(         "SASP2.START_DTTM <= :processDate ");
        	stringSql.append(") ");
        	stringSql.append("AND ");
        	stringSql.append(   "(SASP.STOP_DTTM IS NULL OR SASP.STOP_DTTM > :processDate) ");
        	stringSql.append("AND ");
        	stringSql.append(   "SASP.SP_ID = HIST.SP_ID ");
        	stringSql.append("AND ");
        	stringSql.append(   "HIST.MTR_CONFIG_ID = CFG.MTR_CONFIG_ID ");
        	stringSql.append("AND ");
        	stringSql.append(   "CFG.MTR_ID = MTR.MTR_ID ");
        	
        	PreparedStatement sql = createPreparedStatement(stringSql.toString() , getClass().getName());
        	sql.bindId("saId" , sa.getId());
        	sql.bindDate("processDate" ,  getProcessDateTime().getDate());
        	
        	SQLResultRow result = sql.firstRow();
        	sql.close();
        	
        	if(notNull(result)) {
        		badgeNumber = result.getString("BADGE_NBR").trim();
        	}
        	
        	return badgeNumber;
        }
        
        private void retrieveServiceAddress(ServiceAgreement sa) {
        	Premise charPremise = sa.fetchPremise();
        	
        	serviceAddress = charPremise.getAddress1().trim() + " " + charPremise.getAddress2().trim() +  " " 
        			+ charPremise.getAddress3().trim() +  " " + charPremise.getAddress2().trim();
        	
        	serviceCity = charPremise.getCity().trim();
        	serviceZipCode = charPremise.getPostal();
        	
        	if(notNull(charPremise.getState())) {
        		serviceState = charPremise.getState();
        	}
        	premiseIDforNG = charPremise.getId().getTrimmedValue();
        }
        
        /**
         * This method retrieves the most recent 12 bills of an SA and then gets their usages.
         */
        private void retrieveUsagesForSA(ServiceAgreement sa){
        	List<SQLResultRow> recentBillSegmentUsagesFor12Months = get12RecentBillSegments(sa);
        	int billSegmentCounter = 1;
        	BigDecimal usage = BigDecimal.ZERO;
        	BigDecimal cost = BigDecimal.ZERO;
        	
        	for(SQLResultRow billSegment : recentBillSegmentUsagesFor12Months) {
        		//If the billSegmentCounter variable is 1, this is the most recent bill. we get the start  date
        		BillSegment recentBseg = billSegment.getEntity("BSEG_ID", BillSegment.class);
        		usage = BigDecimal.ZERO;
        		cost = BigDecimal.ZERO;
        		if(billSegment.getBigDecimal("USAGE_CCFC").compareTo(BigDecimal.ZERO) > 0) {
        			usage = billSegment.getBigDecimal("USAGE_CCFC");
        		} else if (billSegment.getBigDecimal("USAGE_CCF").compareTo(BigDecimal.ZERO) > 0){
        			usage = billSegment.getBigDecimal("USAGE_CCF");
        		} 

        		cost = billSegment.getBigDecimal("COST");

        		if(billSegmentCounter == 1) {
        			startDateBill1 = recentBseg.getStartDate();
        			endBill1 = recentBseg.getEndDate();
        			month1GasUsage = month1GasUsage.add(usage);
        			month1Cost = month1Cost.add(cost);
        		} else if(billSegmentCounter == 2) {
        			endBill2 = recentBseg.getEndDate();
        			month2GasUsage = month2GasUsage.add(usage);
        			month2Cost = month2Cost.add(cost);
        		} else if(billSegmentCounter == 3) {
        			endBill3 = recentBseg.getEndDate();
        			month3GasUsage = month3GasUsage.add(usage);
        			month3Cost = month3Cost.add(cost);
        		} else if (billSegmentCounter == 4) {
        			endBill4 = recentBseg.getEndDate();
        			month4GasUsage = month4GasUsage.add(usage);
        			month4Cost = month4Cost.add(cost);
        		} else if(billSegmentCounter == 5) {
        			endBill5 = recentBseg.getEndDate();
        			month5GasUsage = month5GasUsage.add(usage);
        			month5Cost = month5Cost.add(cost);
        		} else if(billSegmentCounter == 6) {
        			endBill6 = recentBseg.getEndDate();
        			month6GasUsage = month6GasUsage.add(usage);
        			month6Cost = month6Cost.add(cost);
        		} else if(billSegmentCounter == 7) {
        			endBill7 = recentBseg.getEndDate();
        			month7GasUsage = month7GasUsage.add(usage);
        			month7Cost = month7Cost.add(cost);
        		} else if(billSegmentCounter == 8) {
        			endBill8 = recentBseg.getEndDate();
        			month8GasUsage = month8GasUsage.add(usage);
        			month8Cost = month8Cost.add(cost);
        		} else if(billSegmentCounter == 9) {
        			endBill9 = recentBseg.getEndDate();
        			month9GasUsage = month9GasUsage.add(usage);
        			month9Cost = month9Cost.add(cost);
        		} else if(billSegmentCounter == 10) {
        			endBill10 = recentBseg.getEndDate();
        			month10GasUsage = month10GasUsage.add(usage);
        			month10Cost = month10Cost.add(cost);
        		} else if(billSegmentCounter == 11) {
        			endBill11 = recentBseg.getEndDate();
        			month11GasUsage = month11GasUsage.add(usage);
        			month11Cost = month11Cost.add(cost);
        		} else if(billSegmentCounter == 12) {
        			endBill12 = recentBseg.getEndDate();
        			month12GasUsage = month12GasUsage.add(usage);
        			month12Cost = month12Cost.add(cost);
        		} 

        		billSegmentCounter ++;

        		//We only tally the total usage if the minimum usage is provided.
        		//This is to ensure that we only compare the total usage of this
        		//SA if the minimum usage history is provided
        		if(notNull(minimumUsage)) {
        			totalUsage = totalUsage.add(usage);
        		}
        	} 

        	//After iterating through the list of all bill segments
        	//if the minimum usage parameter is provided, check that the 
        	//total usage of the account is greater than or equal to the
        	//minimum usage. If it's not, we skip the account
        	if(notNull(minimumUsage) && totalUsage.compareTo(minimumUsage) < 0) {
        		shouldProcessAccount = Bool.FALSE;
        		return;
        	}
        }
        
        /**
         * This method will get the recent bill segments for 12 months for the SA
         * @param sa
         * @return 12 most recent bill segments
         */
        private List<SQLResultRow> get12RecentBillSegments(ServiceAgreement sa) {
        	List<SQLResultRow> billSegmentList = null;
        	StringBuilder stringSql = new StringBuilder();
        	
        	stringSql.append("SELECT ");
        	stringSql.append(	"BSEG.BSEG_ID, ");
        	stringSql.append(	"BSEG.START_DT, ");
        	stringSql.append(	"BSEG.END_DT, ");
        	stringSql.append(	"( ");
        	stringSql.append(	   "SELECT ");
        	stringSql.append(	      "NVL(SUM(SQ.BILL_SQ) , 0) ");
        	stringSql.append(	   "FROM ");
        	stringSql.append(	      "CI_BSEG_SQ SQ ");
        	stringSql.append(	   "WHERE ");
        	stringSql.append(	      "SQ.BSEG_ID = BSEG.BSEG_ID ");
        	stringSql.append(	   "AND ");
        	stringSql.append(	      "SQ.UOM_CD = 'CCF' ");
        	stringSql.append(   ") AS USAGE_CCF, ");
        	stringSql.append(	"( ");
        	stringSql.append(	   "SELECT ");
        	stringSql.append(	      "NVL(SUM(SQ.BILL_SQ) , 0) ");
        	stringSql.append(	   "FROM ");
        	stringSql.append(	      "CI_BSEG_SQ SQ ");
        	stringSql.append(	   "WHERE ");
        	stringSql.append(	      "SQ.BSEG_ID = BSEG.BSEG_ID ");
        	stringSql.append(	   "AND ");
        	stringSql.append(	      "SQ.UOM_CD = 'CCFC' ");
        	stringSql.append(   ") AS USAGE_CCFC, ");
        	stringSql.append(	"NVL(SUM(CALC.CALC_AMT) , 0) AS COST ");
        	stringSql.append("FROM ");
        	stringSql.append(	"CI_BSEG BSEG, ");
        	stringSql.append(	"CI_BSEG_CALC CALC ");
        	stringSql.append("WHERE ");
        	stringSql.append(	"BSEG.SA_ID = :saId ");
        	stringSql.append("AND ");
        	stringSql.append(	"BSEG.BSEG_STAT_FLG = :frozen ");
        	stringSql.append("AND ");
        	stringSql.append(	"BSEG.BSEG_ID = CALC.BSEG_ID ");
        	stringSql.append("GROUP BY ");
        	stringSql.append(	"BSEG.BSEG_ID, ");
        	stringSql.append(	"BSEG.START_DT, ");
        	stringSql.append(	"BSEG.END_DT ");
        	stringSql.append("ORDER BY BSEG.END_DT DESC ");
        	stringSql.append("FETCH FIRST 12 ROWS ONLY ");
        	
        	PreparedStatement sql = createPreparedStatement(stringSql.toString() , getClass().getName());
        	sql.bindId("saId", sa.getId());
        	sql.bindLookup("frozen" , BillSegmentStatusLookup.constants.FROZEN);
        	
        	billSegmentList = sql.list();
        	sql.close();
        	
        	return billSegmentList;
        }
        
        /**
         * Reset the values for the monthly information
         */
        private void resetExtractValues(){
        	startDateBill1 = null;
        	endBill1 = null;
        	month1GasUsage = BigDecimal.ZERO;
        	month1Cost = BigDecimal.ZERO;
        	endBill2 = null;
        	month2GasUsage = BigDecimal.ZERO;
        	month2Cost = BigDecimal.ZERO;
        	endBill3 = null;
        	month3GasUsage = BigDecimal.ZERO;
        	month3Cost = BigDecimal.ZERO;
        	endBill4 = null;
        	month4GasUsage = BigDecimal.ZERO;
        	month4Cost = BigDecimal.ZERO;
        	endBill5 = null;
        	month5GasUsage = BigDecimal.ZERO;
        	month5Cost = BigDecimal.ZERO;
        	endBill6 = null;
        	month6GasUsage = BigDecimal.ZERO;
        	month6Cost = BigDecimal.ZERO;
        	endBill7 = null;
        	month7GasUsage = BigDecimal.ZERO;
        	month7Cost = BigDecimal.ZERO;
        	endBill8 = null;
        	month8GasUsage = BigDecimal.ZERO;
        	month8Cost = BigDecimal.ZERO;
        	endBill9 = null;
        	month9GasUsage = BigDecimal.ZERO;
        	month9Cost = BigDecimal.ZERO;
        	endBill10 = null;
        	month10GasUsage = BigDecimal.ZERO;
        	month10Cost = BigDecimal.ZERO;
        	endBill11 = null;
        	month11GasUsage = BigDecimal.ZERO;
        	month11Cost = BigDecimal.ZERO;
        	endBill12 = null;
        	month12GasUsage = BigDecimal.ZERO;
        	month12Cost = BigDecimal.ZERO;
        	premiseIDforNG = "";
        	meterNumber = "";
        	
        	//We also reset the total usage 
        	totalUsage = BigDecimal.ZERO;
        }
        
        /**
         * This method will write information retrieved to extract file
         */
        private void writeInformationToExtractBuffer() {
        	
        	extractBuffer.append(name.trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(mailingAddress.trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(mailingState.trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(mailingCity.trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(mailingZipCode.trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(serviceAddress.trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(serviceState.trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(serviceCity.trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(serviceZipCode.trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(naturalGasSupplier.trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(participantGasAccount.trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(premiseIDforNG.trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(meterNumber.trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(rate.trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(specialBilling.trim());
        	extractBuffer.append(COMMA);

        	if(notNull(startDateBill1)) {
        		extractBuffer.append(startDateBill1.toString(dateFormat).trim());
        	} else {
        		extractBuffer.append("");
        	}
        	extractBuffer.append(COMMA);

        	if(notNull(endBill1)) {
        		extractBuffer.append(endBill1.toString(dateFormat).trim());
        	}else {
        		extractBuffer.append("");
        	}

        	extractBuffer.append(COMMA);
        	extractBuffer.append(month1GasUsage.toString().trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(month1Cost.toString().trim());
        	extractBuffer.append(COMMA);

        	if(notNull(endBill2)) {
        		extractBuffer.append(endBill2.toString(dateFormat).trim());
        	}else {
        		extractBuffer.append("");
        	}

        	extractBuffer.append(COMMA);
        	extractBuffer.append(month2GasUsage.toString().trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(month2Cost.toString().trim());
        	extractBuffer.append(COMMA);

        	if(notNull(endBill3)) {
        		extractBuffer.append(endBill3.toString(dateFormat).trim());
        	}else {
        		extractBuffer.append("");
        	}

        	extractBuffer.append(COMMA);
        	extractBuffer.append(month3GasUsage.toString().trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(month3Cost.toString().trim());
        	extractBuffer.append(COMMA);

        	if(notNull(endBill4)) {
        		extractBuffer.append(endBill4.toString(dateFormat).trim());
        	}else {
        		extractBuffer.append("");
        	}

        	extractBuffer.append(COMMA);
        	extractBuffer.append(month4GasUsage.toString().trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(month4Cost.toString().trim());
        	extractBuffer.append(COMMA);

        	if(notNull(endBill5)) {
        		extractBuffer.append(endBill5.toString(dateFormat).trim());
        	}else {
        		extractBuffer.append("");
        	}

        	extractBuffer.append(COMMA);
        	extractBuffer.append(month5GasUsage.toString().trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(month5Cost.toString().trim());
        	extractBuffer.append(COMMA);

        	if(notNull(endBill6)) {
        		extractBuffer.append(endBill6.toString(dateFormat).trim());
        	}else {
        		extractBuffer.append("");
        	}

        	extractBuffer.append(COMMA);
        	extractBuffer.append(month6GasUsage.toString().trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(month6Cost.toString().trim());
        	extractBuffer.append(COMMA);

        	if(notNull(endBill7)) {
        		extractBuffer.append(endBill7.toString(dateFormat).trim());
        	}else {
        		extractBuffer.append("");
        	}

        	extractBuffer.append(COMMA);
        	extractBuffer.append(month7GasUsage.toString().trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(month7Cost.toString().trim());
        	extractBuffer.append(COMMA);

        	if(notNull(endBill8)) {
        		extractBuffer.append(endBill8.toString(dateFormat).trim());
        	}else {
        		extractBuffer.append("");
        	}

        	extractBuffer.append(COMMA);
        	extractBuffer.append(month8GasUsage.toString().trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(month8Cost.toString().trim());
        	extractBuffer.append(COMMA);

        	if(notNull(endBill9)) {
        		extractBuffer.append(endBill9.toString(dateFormat).trim());
        	}else {
        		extractBuffer.append("");
        	}
        	extractBuffer.append(COMMA);
        	extractBuffer.append(month9GasUsage.toString().trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(month9Cost.toString().trim());
        	extractBuffer.append(COMMA);

        	if(notNull(endBill10)) {
        		extractBuffer.append(endBill10.toString(dateFormat).trim());
        	}else {
        		extractBuffer.append("");
        	}

        	extractBuffer.append(COMMA);
        	extractBuffer.append(month10GasUsage.toString().trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(month10Cost.toString().trim());
        	extractBuffer.append(COMMA);

        	if(notNull(endBill11)) {
        		extractBuffer.append(endBill11.toString(dateFormat).trim());
        	}else {
        		extractBuffer.append("");
        	}

        	extractBuffer.append(COMMA);
        	extractBuffer.append(month11GasUsage.toString().trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(month11Cost.toString().trim());
        	extractBuffer.append(COMMA);

        	if(notNull(endBill12)) {
        		extractBuffer.append(endBill12.toString(dateFormat).trim());
        	}else {
        		extractBuffer.append("");
        	}

        	extractBuffer.append(COMMA);
        	extractBuffer.append(month12GasUsage.toString().trim());
        	extractBuffer.append(COMMA);
        	extractBuffer.append(month12Cost.toString().trim());
        	extractBuffer.append("\n");
        }       
        
        /**
         * This method will write the headers to the extract file. This throws an IO exception
         * if there is an issue writing to the file
         * @throws Exception
         */
        private void writeHeadersToExtractFile() throws Exception {
        	extractFileWriter.write(nameHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(mailingAddressHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(mailingStateHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(mailingCityHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(mailingZipCodeHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(serviceAddressHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(serviceStateHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(serviceCityHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(serviceZipCodeHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(naturalGasSupplierHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(participantGasAccountHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(premiseIDforNGHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(meterNumberHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(rateHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(specialBillingHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(startDateBill1Header);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(endBill1Header);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month1GasUsageHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month1CostHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(endBill2Header);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month2GasUsageHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month2CostHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(endBill3Header);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month3GasUsageHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month3CostHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(endBill4Header);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month4GasUsageHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month4CostHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(endBill5Header);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month5GasUsageHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month5CostHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(endBill6Header);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month6GasUsageHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month6CostHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(endBill7Header);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month7GasUsageHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month7CostHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(endBill8Header);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month8GasUsageHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month8CostHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(endBill9Header);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month9GasUsageHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month9CostHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(endBill10Header);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month10GasUsageHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month10CostHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(endBill11Header);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month11GasUsageHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month11CostHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(endBill12Header);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month12GasUsageHeader);
        	extractFileWriter.write(COMMA);
        	extractFileWriter.write(month12CostHeader);
        	extractFileWriter.newLine();;
        }
        
        private void createPAYSCustomerContact(Person person){

        	CustomerContact_DTO customerContactDTO = createDTO(CustomerContact.class);
        	String comment = "Account %1, Premise %2 included in PAYS program data extract on %3";
        	DateFormat dateFormatForCustomerContactComment = new DateFormat("MM/dd/yyyy");
        	
        	comment = comment.replace("%1", accountId.getTrimmedValue());
        	comment = comment.replace("%2" , account.getMailingPremiseId().getTrimmedValue());
        	comment = comment.replace("%3" , getProcessDateTime().getDate().toString(dateFormatForCustomerContactComment).trim());
        	
        	customerContactDTO.setCustomerContactTypeId(new CustomerContactType_Id(customerContactClass, customerContactType));
        	customerContactDTO.setPersonId(person.getId());
        	customerContactDTO.setAccountId(accountId);
        	customerContactDTO.setPremiseId(account.getMailingPremiseId());
        	customerContactDTO.setContactDateTime(getProcessDateTime());
        	customerContactDTO.setLongDescription(comment);
        	    
        	customerContactDTO.newEntity();
        }

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException,
				RunAbortedException {
            // Close Extract File
            try {
            	extractFileWriter.close();    
            }
            catch(Exception e) {
                e.printStackTrace();
                throw new RunAbortedException(CustomMessageRepositoryMGE.commGenericErrorClosingFile(extractFile.getAbsolutePath()));
            }
		}            
    }
}
