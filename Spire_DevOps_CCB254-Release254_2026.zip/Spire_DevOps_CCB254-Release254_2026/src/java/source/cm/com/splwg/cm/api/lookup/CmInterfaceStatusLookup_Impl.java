/*
 ************************************************************************ 
 *                 Confidentiality Information: 
 * 
 ************************************************************************
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * Service Info Outbound Interface Staging Maintenance Routine. 
 * 
 ************************************************************************ 
 * CHANGE HISTORY: 
 * 
 * Date:        by:         Reason: 
 * YYYY-MM-DD   FLName
 * 2014-01-30   WCARANDA    Initial Version. COMMON. 					
 ************************************************************************
 */
package com.splwg.cm.api.lookup;

/**
 *
 @LookupFieldname (value = CM_INT_STATUS_FLG)
 */
@SuppressWarnings("serial")
public class CmInterfaceStatusLookup_Impl 
		extends CmInterfaceStatusLookup_Gen {

}
