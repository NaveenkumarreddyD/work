/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Failed Meter Sampling Case
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-04-08   Neha            NM0101 Initial Version.
 * 2013-08-14   Neha		IM-033957 Change date format for due date char values
 * 2013-09-25	Neha		Tune the main query
 * 2013-11-29   Neha            IM-041589 Static variables removed
 * 2014-03-21   Neha            IM-044350 Add a new parameter to add Meter Badge Number 
 *                              Characteristic on Case
 * 2014-05-06   Neha            IM-050188 Case pointing to old customer
 * 2014-06-25   Ujesh           IM-053037 Sample Meter Change Case not Creating.
 * 2016-01-29  	MPang			Updated for CCB v2.4 compilation.
 * 2018-07-25   SFelip          Updated for CCB v2.6. No need to trim the 
 *                              CHAR_VAL field.
 * 2019-03-20	JHERNA			SysAid#286046. Update code to retrieve the correct 
 * 								and latest customer information linked to the service point.
 ******************************************************************************************/

package com.splwg.cm.domain.batch;


import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.phoneType.PhoneType;
import com.splwg.base.domain.common.phoneType.PhoneType_Id;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ContactMethodLookup;
import com.splwg.ccb.api.lookup.ServicePointMeterEventTypeLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseType;
import com.splwg.ccb.domain.admin.caseType.CaseTypeCaseStatues;
import com.splwg.ccb.domain.admin.caseType.CharacteristicTypeCaseType;
import com.splwg.ccb.domain.admin.meterLocation.MeterLocation;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.Person;
import com.splwg.ccb.domain.customerinfo.person.Person_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.Meter;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meter.Meter_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseCreator;
import com.splwg.ccb.domain.todo.toDoCase.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_Id;*/

import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.caseType.entity.CaseTypeCaseStatues;
import com.splwg.ccb.domain.admin.caseType.entity.CharacteristicTypeCaseType;
import com.splwg.ccb.domain.admin.meterLocation.entity.MeterLocation;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.common.CaseCreator;
import com.splwg.ccb.domain.todo.data.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_Id;
import com.splwg.cm.domain.common.customBusinessComponent.CmSaSpMeterRelationshipsRoutine_Impl;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;


///** 
// * @BatchJob ( modules = {} 
// *              , multiThreaded = true
// *              , rerunnable = false
// *              , softParameters = { @BatchJobSoftParameter (name = CASE_TYPE, required = true, type = entity, entityName = caseType)                                
// *                                 , @BatchJobSoftParameter (name = X_DAYS_LESS_THN_DUE, required = true, type = integer)
// *                                 , @BatchJobSoftParameter (name = DUE_DT_MTR_CHAR_TY, required = true, type = entity, entityName = characteristicType)
// *                                 , @BatchJobSoftParameter (name = SAMPLE_MTR_CHAR_TY, required = true, type = entity, entityName = characteristicType)
// *                                 , @BatchJobSoftParameter (name = SAMPLE_MTR_CHAR_VAL, required = true, type = string)
// *                                 , @BatchJobSoftParameter (name = METER_ID_CHAR_TYPE, required = true, type = entity, entityName = characteristicType)
// *                                 , @BatchJobSoftParameter (name = ELIG_PORTAL_CASE_CHAR_TY, required = true, type = entity, entityName = characteristicType)
// *                                 , @BatchJobSoftParameter (name = ELIG_PORTAL_CASE_CHAR_VAL, required = true, type = string)
// *                                 , @BatchJobSoftParameter (name = MTR_LOCATION, required = true, type = entity, entityName = meterLocation)
// *                                 , @BatchJobSoftParameter (name = SP_ID_CHAR_TYPE, required = true, type = entity, entityName = characteristicType)
// *                                 }
// *           )
// */
// Start change Neha 2014-03-21 IM-044350
/** 
 * @BatchJob ( modules = {} 
 *              , multiThreaded = true
 *              , rerunnable = false
 *              , softParameters = { @BatchJobSoftParameter (name = CASE_TYPE, required = true, type = entity, entityName = caseType)                                
 *                                 , @BatchJobSoftParameter (name = X_DAYS_LESS_THN_DUE, required = true, type = integer)
 *                                 , @BatchJobSoftParameter (name = DUE_DT_MTR_CHAR_TY, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = SAMPLE_MTR_CHAR_TY, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = SAMPLE_MTR_CHAR_VAL, required = true, type = string)
 *                                 , @BatchJobSoftParameter (name = METER_ID_CHAR_TYPE, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = ELIG_PORTAL_CASE_CHAR_TY, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = ELIG_PORTAL_CASE_CHAR_VAL, required = true, type = string)
 *                                 , @BatchJobSoftParameter (name = MTR_LOCATION, required = true, type = entity, entityName = meterLocation)
 *                                 , @BatchJobSoftParameter (name = SP_ID_CHAR_TYPE, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = BADGE_NBR_CHAR_TYPE, required = true, type = entity, entityName = characteristicType)
 *                                 }
 *           )
 */
// End change Neha 2014-03-21 IM-044350
public class CmFailedMeterSamplingCase_BatchProcess 
extends CmFailedMeterSamplingCase_BatchProcess_Gen{

    // Soft Parameters
    // Start change Neha IM-041589 2013-11-29
    /*private static CaseType parmCaseType;
    private static BigInteger parmXDaysLessThnDueDt = BigInteger.ZERO;
    private static CharacteristicType parmDueDateCharType;
    private static CharacteristicType parmSampleCharType;
    private static String parmSampleCharValue;
    private static CharacteristicType parmMeterIdCharType;
    private static CharacteristicType parmEligPortalCharType;
    private static String parmEligPortalCharVal;
    private static MeterLocation parmMeterLocation;
    private static CharacteristicType parmSpIdCharType;
    private static BigInteger parmMaxErrors;*/
    private CaseType parmCaseType;
    private BigInteger parmXDaysLessThnDueDt = BigInteger.ZERO;
    private CharacteristicType parmDueDateCharType;
    private CharacteristicType parmSampleCharType;
    private String parmSampleCharValue;
    private CharacteristicType parmMeterIdCharType;
    private CharacteristicType parmEligPortalCharType;
    private String parmEligPortalCharVal;
    @SuppressWarnings("unused")
	private MeterLocation parmMeterLocation;
    private CharacteristicType parmSpIdCharType;
    // Start change Neha 2014-03-21 IM-044350
    private CharacteristicType parmBadgeNbrCharType;
    // End change Neha 2014-03-21 IM-044350
    private BigInteger parmMaxErrors;
    // End change Neha IM-041589 2013-11-29

    // Start changes 08-14-2013 IM-033957 Neha
    //private static final String DATE_FORMAT = "MM/dd/yyyy";
    private static final String DATE_FORMAT = "yyyy-MM-dd";
    // end changes 08-14-2013 IM-033957 Neha
    private static final String SAVEPOINT = "CREATE_CASE";

    /**
     * This method retrieves the records to be processed and in case of error returns a JobWork with single ThreadWorkUnit
     * 
     * @return the JobWork that will be processed in this run.
     */
    public JobWork getJobWork() {
        List<SQLResultRow> eligibleSpList = getEligibleSPs();

        ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
        ServicePoint_Id spId;
        Meter_Id meterId;
        for(SQLResultRow resultSPRow : eligibleSpList){
            spId = (ServicePoint_Id)resultSPRow.getId("SP_ID", ServicePoint.class);
            meterId = (Meter_Id)resultSPRow.getId("MTR_ID", Meter.class);
            ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
            threadWorkUnit.setPrimaryId(spId);         
            threadWorkUnit.addSupplementalData("MTR_ID", meterId);
            threadWorkUnit.addSupplementalData("INSTALL_DT", resultSPRow.getString("INSTALL_DT"));
            
            arrayList.add(threadWorkUnit);
        }

        return createJobWorkForThreadWorkUnitList(arrayList);
    }

    private List<SQLResultRow> getEligibleSPs(){
        CharacteristicTypeLookup charTypeLookup = parmSampleCharType.getCharacteristicType();
        StringBuilder getSPMeterString = new StringBuilder();
        // Start changes 08-14-2013 IM-033957 Neha
        //getSPMeterString.append("SELECT MTR.MTR_ID, TO_CHAR(MR.READ_DTTM, 'MM/DD/YYYY') INSTALL_DT, MTR.BADGE_NBR, HIST.SP_ID ");
        getSPMeterString.append("SELECT MTR.MTR_ID, TO_CHAR(MR.READ_DTTM, 'YYYY-MM-DD') INSTALL_DT, MTR.BADGE_NBR, HIST.SP_ID ");
        // End changes 08-14-2013 IM-033957 Neha
        getSPMeterString.append("FROM CI_MTR MTR, CI_SP_MTR_EVT EVNT ");
        getSPMeterString.append(", CI_MTR_CONFIG CONFIG ");
        getSPMeterString.append(", CI_SP_MTR_HIST HIST ");
        getSPMeterString.append(", CI_MTR_CHAR CH ");
        getSPMeterString.append(", CI_MR MR ");
        getSPMeterString.append(", CI_SP SP ");
        getSPMeterString.append("WHERE CONFIG.MTR_ID = MTR.MTR_ID ");        
        getSPMeterString.append("AND EVNT.SP_MTR_EVT_FLG = :install ");        
        getSPMeterString.append("AND HIST.SP_MTR_HIST_ID = EVNT.SP_MTR_HIST_ID ");
        getSPMeterString.append("AND HIST.MTR_CONFIG_ID = CONFIG.MTR_CONFIG_ID ");
        getSPMeterString.append("AND (HIST.REMOVAL_DTTM IS NULL OR HIST.REMOVAL_DTTM > :processDateTime) ");
        getSPMeterString.append("AND EVNT.MR_ID = MR.MR_ID ");
        getSPMeterString.append("AND MR.READ_DTTM <= :processDateTime ");
        getSPMeterString.append("AND NOT EXISTS (SELECT 'X' FROM CI_CASE CSE, CI_CASE_CHAR CASECH  ");
        getSPMeterString.append("		WHERE CASECH.CHAR_TYPE_CD = :spIdCharType ");
        getSPMeterString.append("		AND TRIM(CASECH.CHAR_VAL_FK1) = TRIM(HIST.SP_ID) ");
        getSPMeterString.append("		AND CASECH.CASE_ID = CSE.CASE_ID ");
		// Start add Neha 2013-09-25
		getSPMeterString.append("       AND CSE.CASE_TYPE_CD = :caseType ");
		// End add Neha 2013-09-25
        getSPMeterString.append("		AND CSE.CASE_COND_FLG = :open) ");
        getSPMeterString.append("AND HIST.SP_ID = SP.SP_ID ");
        // Start change 2014-06-25 - Ujesh - IM-053037
        //getSPMeterString.append("AND (SP.MTR_LOC_CD IS NULL OR SP.MTR_LOC_CD <> :mtrLocation) ");
        // End change 2014-06-25 Ujesh - IM-053037   
        getSPMeterString.append("AND CH.MTR_ID = MTR.MTR_ID ");
        getSPMeterString.append("AND CH.CHAR_TYPE_CD = :sampleCharType  ");
        if(charTypeLookup.isAdhocValue()){
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //getSPMeterString.append("AND TRIM(CH.ADHOC_CHAR_VAL) = :sampleCharVal ");
            getSPMeterString.append("AND CH.ADHOC_CHAR_VAL = :sampleCharVal ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change
        } else if (charTypeLookup.isPredefinedValue()){
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //getSPMeterString.append("AND TRIM(CH.CHAR_VAL) = :sampleCharVal ");
            getSPMeterString.append("AND CH.CHAR_VAL = :sampleCharVal ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change
        } else if (charTypeLookup.isForeignKeyValue()){
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //getSPMeterString.append("AND TRIM(CH.CHAR_VAL_FK1) = :sampleCharVal ");
            getSPMeterString.append("AND CH.CHAR_VAL_FK1 = :sampleCharVal ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change
        }
        getSPMeterString.append("AND CH.EFFDT = (SELECT MAX(CH1.EFFDT) FROM CI_MTR_CHAR CH1 WHERE CH1.MTR_ID = CH.MTR_ID AND CH1.CHAR_TYPE_CD = CH.CHAR_TYPE_CD AND CH1.EFFDT <= :processDate) ");
        //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement spPrepStmt = createPreparedStatement(getSPMeterString.toString()); 
        PreparedStatement spPrepStmt = createPreparedStatement(getSPMeterString.toString(), getClass().getName()); 
        //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        spPrepStmt.bindLookup("open", CaseConditionLookup.constants.OPEN);
        spPrepStmt.bindLookup("install", ServicePointMeterEventTypeLookup.constants.INSTALL);
        spPrepStmt.bindDate("processDate", getProcessDateTime().getDate());
        spPrepStmt.bindDateTime("processDateTime", getProcessDateTime());
        // Start change 2014-06-25 - Ujesh - IM-053037        
        //spPrepStmt.bindId("mtrLocation", parmMeterLocation.getId());
        // End change 2014-06-25 - Ujesh - IM-053037        
        spPrepStmt.bindId("spIdCharType", parmSpIdCharType.getId());
	    spPrepStmt.bindId("caseType", parmCaseType.getId());
        spPrepStmt.bindId("sampleCharType", parmSampleCharType.getId());
        spPrepStmt.bindStringProperty("sampleCharVal", MeterCharacteristic.properties.adhocCharacteristicValue, parmSampleCharValue);
        
        if(charTypeLookup.isAdhocValue()){
            spPrepStmt.bindStringProperty("sampleCharVal", MeterCharacteristic.properties.adhocCharacteristicValue, parmSampleCharValue);
        } else if (charTypeLookup.isPredefinedValue()){
            spPrepStmt.bindStringProperty("sampleCharVal", MeterCharacteristic.properties.characteristicValue, parmSampleCharValue);
        } else if (charTypeLookup.isForeignKeyValue()){
            spPrepStmt.bindStringProperty("sampleCharVal", MeterCharacteristic.properties.characteristicValueForeignKey1, parmSampleCharValue);
        }

        List<SQLResultRow> eligibleSPsList = spPrepStmt.list();
        spPrepStmt.close();
        return eligibleSPsList;
    }

    /**
     * This method checks if all required Soft Parameters were populated,
     * and all optional Soft Parameters (if populated) are valid.
     * 
     * @param isNewRun - a boolean value
     */
    public void validateSoftParameters(boolean isNewRun){

        parmCaseType = getParameters().getCASE_TYPE();     

        parmXDaysLessThnDueDt = getParameters().getX_DAYS_LESS_THN_DUE();
        if (parmXDaysLessThnDueDt.intValue() < 0) {
            addError(CustomMessageRepository.nm0101XDaysCannotBeLessThanZero(parmXDaysLessThnDueDt.toString().trim()));
        }
        
        parmDueDateCharType = getParameters().getDUE_DT_MTR_CHAR_TY();
        validateCharTypeAndEntity(parmDueDateCharType, CharacteristicEntityLookup.constants.METER);        
        
        parmSampleCharType = getParameters().getSAMPLE_MTR_CHAR_TY();
        validateCharTypeAndEntity(parmSampleCharType,  CharacteristicEntityLookup.constants.METER);

        parmSampleCharValue = getParameters().getSAMPLE_MTR_CHAR_VAL().trim();
        //validate Characteristic Values
        CharacteristicTypeLookup charTypeLookup = parmSampleCharType.getCharacteristicType();
        if(charTypeLookup.isPredefinedValue()){
            CharacteristicValue_Id charValId = new CharacteristicValue_Id(parmSampleCharType.getId(), parmSampleCharValue);
            if(isNull(charValId.getEntity())){
                addError(CustomMessageRepository.nm0101InvalidInputCharVal(parmSampleCharValue, parmSampleCharType.getId().getTrimmedValue()));
            }
        }
        
        parmMeterIdCharType = getParameters().getMETER_ID_CHAR_TYPE();
        validateCharTypeAndEntity(parmMeterIdCharType, CharacteristicEntityLookup.constants.CASE);
        validateCharTypeForCaseType(parmMeterIdCharType);
        
        parmEligPortalCharType = getParameters().getELIG_PORTAL_CASE_CHAR_TY();
        validateCharTypeAndEntity(parmEligPortalCharType, CharacteristicEntityLookup.constants.CASE);
        validateCharTypeForCaseType(parmEligPortalCharType);
        
        parmEligPortalCharVal = getParameters().getELIG_PORTAL_CASE_CHAR_VAL().trim();
        //validate Characteristic Values
        charTypeLookup = parmEligPortalCharType.getCharacteristicType();
        if(charTypeLookup.isPredefinedValue()){
            CharacteristicValue_Id charValId = new CharacteristicValue_Id(parmEligPortalCharType.getId(), parmEligPortalCharVal);
            if(isNull(charValId.getEntity())){
                addError(CustomMessageRepository.nm0101InvalidInputCharVal(parmEligPortalCharVal, parmEligPortalCharType.getId().getTrimmedValue()));
            }
        }
        
        parmMeterLocation = getParameters().getMTR_LOCATION();
        
        parmSpIdCharType = getParameters().getSP_ID_CHAR_TYPE();
        validateCharTypeAndEntity(parmSpIdCharType, CharacteristicEntityLookup.constants.CASE);
        validateCharTypeForCaseType(parmSpIdCharType);
        
        // Start change Neha 2014-03-21 IM-044350
        parmBadgeNbrCharType = getParameters().getBADGE_NBR_CHAR_TYPE();
        validateCharTypeAndEntity(parmBadgeNbrCharType, CharacteristicEntityLookup.constants.CASE);
        validateCharTypeForCaseType(parmBadgeNbrCharType);
        // End change Neha 2014-03-21 IM-044350
        
        parmMaxErrors = getParameters().getSoftMaxErrors();
        // Validates Max Error soft parameter
        if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
            addError(CustomMessageRepository.nm0101MaxErrorCannotBeLessThanZero(parmMaxErrors.toString().trim()));
        } 
    }

    /**
     * This method will validate the input CharacteristicType is valid for the 
     * CharacteristicEntityLookup for Field Activity.
     * 
     * @param characteristicType a Characteristic Type Entity 
     * return returns Bool.TRUE if the Char Value is valid for the Char Type, otherwise returns Bool.FALSE.
     */
    private void validateCharTypeAndEntity(CharacteristicType characteristicType, CharacteristicEntityLookup lookup) {

        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(characteristicType.getId(), lookup);
        if(isNull(charEntityId.getEntity())){
            addError(CustomMessageRepository.nm0101InvalidInputCharTypeForEntity(characteristicType.getId().getTrimmedValue(),lookup.getLookupValue().fetchLanguageDescription()));  
        }
    }
    
    private void validateCharTypeForCaseType(CharacteristicType characteristicType) {

        boolean charTypeValid = false;
        for(CharacteristicTypeCaseType charType : parmCaseType.getCharacteristicTypeCaseTypes()){
            if(charType.fetchIdCharacteristicType().equals(characteristicType)){
                charTypeValid = true;
                break;
            }
        }
        if(!charTypeValid){
            addError(CustomMessageRepository.nm0101CharTypeInvalidForCaseType(characteristicType.getId().getTrimmedValue(), parmCaseType.getId().getTrimmedValue()));
        }
    }

    /**
     * Method to retrieve the Thread Worker Class.
     * 
     * @return the thread worker class
     */
    public Class<CmFailedMeterSamplingCase_BatchProcessWorker> getThreadWorkerClass() {

        return CmFailedMeterSamplingCase_BatchProcessWorker.class;
    }

    /**
     * This Worker Class is responsible for processing a single Thread Instance.
     */
    public static class CmFailedMeterSamplingCase_BatchProcessWorker
    extends CmFailedMeterSamplingCase_BatchProcessWorker_Gen {

        // Working Variables
        private ArrayList <CaseCharacteristic_DTO>  charList;// = new ArrayList<CaseCharacteristic_DTO>();
        // Start add Neha IM-041589 2013-11-29
        private CaseType parmCaseType;
        private BigInteger parmXDaysLessThnDueDt = BigInteger.ZERO;
        private CharacteristicType parmDueDateCharType;
        private CharacteristicType parmMeterIdCharType;
        private CharacteristicType parmEligPortalCharType;
        private String parmEligPortalCharVal;
        private CharacteristicType parmSpIdCharType;
        // Start change Neha 2014-03-21 IM-044350
        private CharacteristicType parmBadgeNbrCharType;
        // End change Neha 2014-03-21 IM-044350
        
        //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        private static FrameworkSession session;
        //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        /**
         * Perform any initialization that must be done at the start of this thread processing work. 
         * @param initializationPreviouslySuccessful - indicates that this method was called successfully called during some 
         * prior execution, presumably because this is a restart situation.
         * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
         * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
         * @see com.splwg.base.api.batch.ThreadWorker#initializeThreadWork(boolean) 
         */
        public void initializeThreadWork(boolean initializationPreviouslySuccessful)
        throws ThreadAbortedException, RunAbortedException {
            // retrieving parameters
            JobParameters parameters = getParameters();
            parmCaseType = parameters.getCASE_TYPE();     
            parmXDaysLessThnDueDt = parameters.getX_DAYS_LESS_THN_DUE();
            parmDueDateCharType = parameters.getDUE_DT_MTR_CHAR_TY();
            parmMeterIdCharType = parameters.getMETER_ID_CHAR_TYPE();
            parmEligPortalCharType = parameters.getELIG_PORTAL_CASE_CHAR_TY();
            parmEligPortalCharVal = parameters.getELIG_PORTAL_CASE_CHAR_VAL().trim();        
            parmSpIdCharType = parameters.getSP_ID_CHAR_TYPE();
            // Start change Neha 2014-03-21 IM-044350
            parmBadgeNbrCharType = getParameters().getBADGE_NBR_CHAR_TYPE();
            // Start change Neha 2014-03-21 IM-044350
           
        }
        // End add Neha IM-041589 2013-11-29

        /**
         * This method identifies the execution strategy to be used for the thread.
         * 
         * @return an instance of ThreadExecutionStrategy that governs how this ThreadWorker will be executed at runtime.
         * @see com.splwg.base.api.batch.ThreadWorker#createExecutionStrategy()
         */
        public ThreadExecutionStrategy createExecutionStrategy() {

            return new StandardCommitStrategy(this);
        }

        /**
         * Execute a WorkUnit and provide result details.
         * 
         * @param unit - a ThreadWorkUnit
         * @return a boolean that describes the success or failure of the work unit processing.
         * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
         * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
         * @see com.splwg.base.api.batch.ThreadWorker#executeWorkUnit(com.splwg.base.api.batch.ThreadWorkUnit)
         */
        public boolean executeWorkUnit(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {
             charList = new ArrayList<CaseCharacteristic_DTO>();

            ServicePoint_Id servicePointId = (ServicePoint_Id)unit.getPrimaryId(); 
            Meter_Id meterId =  (Meter_Id)unit.getSupplementallData("MTR_ID");   
            Date installDate = null;
            try {
                installDate = Date.fromString((String)unit.getSupplementallData("INSTALL_DT"), new DateFormat(DATE_FORMAT));
            } catch (DateFormatParseException e) {
                e.printStackTrace();
            }

            MeterCharacteristic meterChar = meterId.getEntity().getEffectiveCharacteristic(parmDueDateCharType);
            if(isNull(meterChar)){
                // Due date characteristic missing from Meter %1.
                logError(CustomMessageRepository.nm0101DueDtCharMissingFromMtr(meterId.getTrimmedValue())); 
                return false;
            }
            Date dueDate = null;
            try{

                CharacteristicTypeLookup charTypeLookup = parmDueDateCharType.getCharacteristicType();
                if(charTypeLookup.isAdhocValue()){
                    dueDate = Date.fromString(meterChar.getAdhocCharacteristicValue().trim(), new DateFormat(DATE_FORMAT));
                } else if (charTypeLookup.isPredefinedValue()){
                    dueDate = Date.fromString(meterChar.getCharacteristicValue().trim(), new DateFormat(DATE_FORMAT));
                } else if (charTypeLookup.isForeignKeyValue()){
                    dueDate = Date.fromString(meterChar.getCharacteristicValueForeignKey1().trim(), new DateFormat(DATE_FORMAT));
                }
               
            }catch(DateFormatParseException ex){
                logError(CustomMessageRepository.nm0101InvalidDate(meterChar.getAdhocCharacteristicValue(), meterId.getTrimmedValue()));
                return false;
            }
            if(installDate.isSameOrAfter(dueDate)){
                return true;
            }
            if(getProcessDateTime().getDate().isBefore(dueDate.addDays(parmXDaysLessThnDueDt.negate().intValue()))){
                return true;
            }
            //Start Add - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            session = (FrameworkSession)SessionHolder.getSession();
            //End Add - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            try{ 
            	//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
                //setSavepoint(SAVEPOINT);
                session.setSavepoint(SAVEPOINT);
                //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
                boolean result = createCase(servicePointId,meterId);
                if(!result){
                    return false;
                }
            }catch(ApplicationError appError){                
                String msgText = appError.getServerMessage().toString();
                if(notNull(appError.getServerMessage().getMessageText())){
                    msgText = appError.getServerMessage().getMessageText();
                }
                //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
                //rollbackToSavepoint(SAVEPOINT);
                session.rollbackToSavepoint(SAVEPOINT);
                //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
                logError(CustomMessageRepository.nm0101ApplicationError(servicePointId.getTrimmedValue(), msgText));      
                return false;
            }   
            return true;
        }

        private boolean createCase(ServicePoint_Id servicePointId, Meter_Id meterId){

            ToDoCase_DTO toDoCaseDTO = (ToDoCase_DTO) createDTO(ToDoCase.class);
            // To avoid lazy initialization reinitialize case type
            parmCaseType = parmCaseType.getId().getEntity();
            CaseTypeCaseStatues statuses = parmCaseType.getCaseStatues();
            for (CaseStatus status : statuses){
                if(status.getStatusCondition().isInitial()){
                    toDoCaseDTO.setCaseStatusId(status.getId());
                }
            }
            Account_Id accountId = null;
            Person_Id personId = null;
            String phone = "";

            // START CHANGES - JHERNA - 2019-03-20 - SysAid#286046
            /*
            SQLResultRow usageRow = getUsageInformation(servicePointId);
            if(notNull(usageRow)){
                accountId = (Account_Id)usageRow.getId("ACCT_ID", Account.class);
                personId = (Person_Id)usageRow.getId("PER_ID", Person.class);                
            }
            */
        	CmSaSpMeterRelationshipsRoutine_Impl.LatestCustomerData latestCustomerData = new CmSaSpMeterRelationshipsRoutine_Impl.LatestCustomerData();
        	latestCustomerData.setSPID(servicePointId);
        	latestCustomerData.invoke();
        	accountId = latestCustomerData.getAccountID();
        	personId = latestCustomerData.getPersonID();        	
            // END CHANGES - JHERNA - 2019-03-20 - SysAid#286046
        	
            if(isNull(accountId) && (parmCaseType.getAccountUsage().isRequired())){
                logError(CustomMessageRepository.nm0101AccountNotFoundButReqdOnCase(servicePointId.getTrimmedValue(),parmCaseType.getId().getTrimmedValue()));
                return false;
            }
            if(notNull(accountId) && ((parmCaseType.getAccountUsage().isRequired()) || parmCaseType.getAccountUsage().isOptional())){
                toDoCaseDTO.setAccountId(accountId);
            }
            
            if(isNull(personId) && (parmCaseType.getPersonUsage().isRequired())){
                logError(CustomMessageRepository.nm0101PersonNotFoundButReqdOnCase(servicePointId.getTrimmedValue(),parmCaseType.getId().getTrimmedValue()));
                return false;
            }
            if(notNull(personId) && (parmCaseType.getPersonUsage().isRequired() || parmCaseType.getPersonUsage().isOptional())){
                toDoCaseDTO.setPersonId(personId);
            }
            if(parmCaseType.getCallbackPhoneUsage().isRequired()){
                if(notNull(personId)){
                    List<SQLResultRow> list = getPhoneInformation(personId);
                    phone = list.iterator().next().getString("PHONE");
                    toDoCaseDTO.setPhoneTypeId((PhoneType_Id)list.iterator().next().getId("PHONE_TYPE_CD", PhoneType.class));
                    toDoCaseDTO.setPhone(phone);
                }
            }
            if(parmCaseType.getContactInformationUsage().isRequired()){
                toDoCaseDTO.setContactPersonId(personId);
                toDoCaseDTO.setPreferredContactMethod(ContactMethodLookup.constants.NOT_APPLICABLE);
            }
            if(parmCaseType.getContactInstructionsUsage().isRequired()){
                toDoCaseDTO.setContactInstructions(CustomMessageRepository.nm0101ContactInstructionsUsage().getMessageText());
            }
            if(isNull(servicePointId.getEntity().getPremise()) && parmCaseType.getPremiseUsage().isRequired()){
                logError(CustomMessageRepository.nm0101PremiseNotFoundButReqdOnCase(servicePointId.getTrimmedValue(), parmCaseType.getId().getTrimmedValue()));
                return false;
            }
            if(parmCaseType.getPremiseUsage().isRequired() || parmCaseType.getPremiseUsage().isOptional()){
                toDoCaseDTO.setPremiseId(servicePointId.getEntity().getPremise().getId());
            }
            if(parmCaseType.getResponsibleUserUsage().isRequired()){
                toDoCaseDTO.setUserId(getActiveContextUser().getId());
            }


            addCharacteristic(parmMeterIdCharType, meterId.getTrimmedValue());
            addCharacteristic(parmSpIdCharType, servicePointId.getTrimmedValue());
            addCharacteristic(parmEligPortalCharType, parmEligPortalCharVal);
            // Start change Neha 2014-03-21 IM-044350
            addCharacteristic(parmBadgeNbrCharType, meterId.getEntity().getBadgeNumber().trim());
            // End change Neha 2014-03-21 IM-044350
            
            CaseCreatorData caseCreatorData = CaseCreatorData.Factory.newInstance();
            caseCreatorData.setToDoCaseDTO(toDoCaseDTO);             
            caseCreatorData.setCaseCharacteristics(charList);

            CaseCreator caseCreator = CaseCreator.Factory.newInstance();
            caseCreatorData = caseCreator.createCase(caseCreatorData);
            return true;
        }
        
    	// START DELETE - JHERNA - 2019-03-20 - SysAid#286046
        /*
        private SQLResultRow getUsageInformation(ServicePoint_Id spId){
            StringBuilder getUsageDetailsString = new StringBuilder();
            getUsageDetailsString.append("SELECT SA.ACCT_ID, APER.PER_ID,(SELECT PHONE FROM CI_PER_PHONE WHERE PER_ID = APER.PER_ID AND ROWNUM <=1) PHONE ");
            getUsageDetailsString.append("FROM CI_SA_SP SASP ");
            getUsageDetailsString.append(", CI_SA SA ");
            getUsageDetailsString.append(", CI_ACCT_PER APER ");
            getUsageDetailsString.append("WHERE SASP.SP_ID = :spId ");
            getUsageDetailsString.append("AND SASP.SA_ID = SA.SA_ID ");
            // Start add 2014-05-06   Neha  IM-050188
            getUsageDetailsString.append("  AND SASP.STOP_DTTM IS NULL ");
            // End add 2014-05-06   Neha  IM-050188
            getUsageDetailsString.append("AND SA.ACCT_ID = APER.ACCT_ID  "); 
            getUsageDetailsString.append("AND APER.MAIN_CUST_SW = 'Y' "); 
            getUsageDetailsString.append("AND APER.ACCT_REL_TYPE_CD = 'MAIN' "); 
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString());
            PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            getUsageDetailsPrepStmt.bindId("spId", spId);

            SQLResultRow row = getUsageDetailsPrepStmt.firstRow();

            getUsageDetailsPrepStmt.close();

            return row;
        }
        */
    	// END DELETE - JHERNA - 2019-03-20 - SysAid#286046
        
        private List<SQLResultRow> getPhoneInformation(Person_Id perId){
            StringBuilder getUsageDetailsString = new StringBuilder();
            getUsageDetailsString.append("SELECT PHONE , PHONE_TYPE_CD FROM CI_PER_PHONE WHERE PER_ID = :perId ");
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString()); 
            PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString(), getClass().getName()); 
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            getUsageDetailsPrepStmt.bindId("perId", perId);

            List<SQLResultRow> usageList = getUsageDetailsPrepStmt.list();

            getUsageDetailsPrepStmt.close();

            return usageList;
        }


        private void addCharacteristic(CharacteristicType charType, String charVal){
            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

            CaseCharacteristic_DTO caseCharacteristicDTO;   
            CaseCharacteristic_Id caseCharacteristicId = new CaseCharacteristic_Id(charType.getId(), ToDoCase_Id.NULL, BigInteger.ONE);            
            caseCharacteristicDTO = caseCharacteristicId.newDTO();
            caseCharacteristicDTO.setId(caseCharacteristicId);
            if(charTypeLookup.isAdhocValue()){
                caseCharacteristicDTO.setAdhocCharacteristicValue(charVal);
            } else if (charTypeLookup.isPredefinedValue()){
                caseCharacteristicDTO.setCharacteristicValue(charVal);
            } else if (charTypeLookup.isForeignKeyValue()){
                caseCharacteristicDTO.setCharacteristicValueForeignKey1(charVal);
            }
            charList.add(caseCharacteristicDTO);
            return;
        }


    }
}
