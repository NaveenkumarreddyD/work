/*
 ***********************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * E-06820.2 - Custom Create Late Payment Charges Batch
 *
 ***********************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2023-04-13   DLampa          Initial version.
 * 2025-02-20	IReyes			B-35958. Add process to retrieve current balance for SE accounts since
 * 								they are not configured to have LPC.
 *2025-09-19	Dhuynh			B-40189-Add bill-char late or notlate for billId which meet criteria
 ***********************************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.List;
import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadIterationStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.ThreadWorker;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.datatypes.StringId;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.currency.Currency_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillCharacteristic_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillCharacteristics;
import com.splwg.ccb.domain.billing.bill.entity.Bill_DTO;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.customerinfo.common.AccountFinancialBalanceRetriever;
import com.splwg.ccb.domain.customerinfo.common.AccountLpcFinancialBalanceRetriever;
import com.splwg.ccb.domain.customerinfo.data.AccountFinancialBalanceData;
import com.splwg.ccb.domain.customerinfo.data.AccountLpcFinancialBalanceData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.api.lookup.CmSaMaintenanceExtensionOptionLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
/**
 * @author DLampa
 *
 @BatchJob (modules = {},
 *          rerunnable = false,
 *          multiThreaded = true,
 *          toDoCreation = @ToDoCreation (drillKeyEntity = account, sortKeys = { "BATCH_NBR", "ACCT_ID", "ACCT_NAME"}),
 *          softParameters = { @BatchJobSoftParameter (name = CHAR_TYPE_CD, required = true, type = entity, entityName = characteristicType)
 *                           , @BatchJobSoftParameter (name = CHAR_VAL, required = true, type = string)
 *                           , @BatchJobSoftParameter (name = CHAR_VAL_NOTLATE, required = true, type = string)
 *                           , @BatchJobSoftParameter (name = MIN_AMT, required = true, type = decimal)
 *                           , @BatchJobSoftParameter (name = MAX_ERRORS, required = false, type = integer)
 *                           , @BatchJobSoftParameter (name = DIST_THD_POOL, required = false, type = string)})
 */

public class CmCreateLatePaymentChargesBatch
        extends CmCreateLatePaymentChargesBatch_Gen {

    // Constants
    private static final String XSMP_FEAT_CONFIG = "CMXSMP";
    private static final String RES_CUST_CL = "RES";
    //Start Add - 2025-02-20 - B-35958
    private static final String CIS_DIVISION_AL = "200";
    private static final String CIS_DIVISION_GL = "203";
    //End Add - 2025-02-20 - B-35958

    public void validateSoftParameters(boolean arg0) {

        CharacteristicType parmBillCharType;
        String parmBillCharVal;
        //Start Add Dhuynh- 2025-09-19 - B-40189
        String parmBillCharValNotlate;
        //End Add Dhuynh- 2025-09-19 - B-40189
        BigDecimal parmMinAmountForBillChar;

        parmBillCharType = getParameters().getCHAR_TYPE_CD();
        parmBillCharVal = getParameters().getCHAR_VAL();
        //Start Add Dhuynh- 2025-09-19 - B-40189
        parmBillCharValNotlate = getParameters().getCHAR_VAL_NOTLATE();
        //End Add Dhuynh- 2025-09-19 - B-40189
        parmMinAmountForBillChar = getParameters().getMIN_AMT();

        if (parmBillCharType.getCharacteristicType().isPredefinedValue()) {
            CharacteristicValue_Id charValueId = new CharacteristicValue_Id(parmBillCharType, parmBillCharVal);

            if (isNull(charValueId.getEntity())) {
                addError(CustomMessageRepository.E06820_2_CharValInvalidForCharType("CHAR_VAL", parmBillCharVal, parmBillCharType.getId().getIdValue()));
            }
            //Start Add Dhuynh- 2025-09-19 - B-40189
            CharacteristicValue_Id charValueIdNolate = new CharacteristicValue_Id(parmBillCharType, parmBillCharValNotlate);

            if (isNull(charValueIdNolate.getEntity())) {
                addError(CustomMessageRepository.E06820_2_CharValInvalidForCharType("CHAR_VAL", parmBillCharValNotlate, parmBillCharType.getId().getIdValue()));
            //End Add Dhuynh- 2025-09-19 - B-40189
            }
        }

    }

    public Class<CmCreateLatePaymentChargesBatchWorker> getThreadWorkerClass() {
        return CmCreateLatePaymentChargesBatchWorker.class;
    }

    public static class CmCreateLatePaymentChargesBatchWorker extends CmCreateLatePaymentChargesBatchWorker_Gen {
        // Soft Parameters
        private CharacteristicType parmBillCharType;
        private String parmBillCharVal;
        //Start Add Dhuynh- 2025-09-19 - B-40189
        private String parmBillCharValNotlate;
        private Bool wLatePaymentFlag;
        //End Add Dhuynh- 2025-09-19 - B-40189
        private BigDecimal parmMinAmountForBillChar;  

        public ThreadExecutionStrategy createExecutionStrategy() {
            return (ThreadExecutionStrategy)new ThreadIterationStrategy((ThreadWorker)this);
        }

        public void initializeThreadWork(boolean initializationPreviouslySuccessful) throws ThreadAbortedException, RunAbortedException {

            parmBillCharType = getParameters().getCHAR_TYPE_CD();
            parmBillCharVal = getParameters().getCHAR_VAL();
            //Start Add Dhuynh- 2025-09-19 - B-40189
            parmBillCharValNotlate = getParameters().getCHAR_VAL_NOTLATE();
            //End Add Dhuynh- 2025-09-19 - B-40189
            parmMinAmountForBillChar = getParameters().getMIN_AMT();

            startEntityQueryIteratorForThread(Bill_Id.class);

        }

        protected QueryIterator getQueryIteratorForThread(StringId lowId, StringId highId) {

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("FROM Bill BILL ");
            stringBuilder.append("WHERE ((BILL.isLatePaymentCharge = 'Y' ");
            stringBuilder.append(  "AND BILL.latePaymentChargeDate <= :procDate) ");      
            //Start Change Dhuynh- 2025-09-19 - B-40189
            stringBuilder.append(  "OR( BILL.latePaymentChargeDate is NULL ");
            stringBuilder.append(  "AND BILL.dueDate <= :procDate ");
            stringBuilder.append(  "AND BILL.billDate >= :lastYearDate )) ");
            stringBuilder.append(  "AND NOT EXISTS (SELECT BC.id  ");
            stringBuilder.append(              "FROM BillCharacteristic BC ");
            stringBuilder.append(              "WHERE BC.id.bill = BILL.id ");
            stringBuilder.append(                "AND BC.id.characteristicType = :lateCharType )");
            stringBuilder.append(  "AND BILL.id between :lowId and :highId ");
            //End Change Dhuynh- 2025-09-19 - B-40189
            Query<Bill> query = createQuery(stringBuilder.toString(), getClass().getName());           
            query.bindDate("procDate", getProcessDateTime().getDate());
            query.bindDate("lastYearDate", getProcessDateTime().getDate().addYears(-1));
            query.bindId("lowId", lowId);
            query.bindId("highId", highId);           
            query.addResult("BILL", "BILL");
            query.orderBy("BILL");
            query.bindId("lateCharType", parmBillCharType.getId());
            return query.iterate();
           
        }

        protected boolean executeWorkUnit(ThreadWorkUnit unit) throws ThreadAbortedException, RunAbortedException {
            
            Bill_Id billId = (Bill_Id)unit.getPrimaryId();
            Bill bill = (Bill)billId.getEntity();
            //Start Change Dhuynh- 2025-09-19 - B-40189
            wLatePaymentFlag = bill.getIsLatePaymentCharge();
       //   bill.calculateLatePaymentCharges();  
            Bill_DTO billDTO = bill.getDTO();
            billDTO.setIsLatePaymentCharge(Bool.FALSE);
            bill.setDTO(billDTO);

            // Add the Bill Characteristic if applicable
         //   if (bill.getAccount().getCustomerClass().getId().getTrimmedValue().equalsIgnoreCase(RES_CUST_CL)) {
            	addBillChar(bill);
          //  }
                //End Change Dhuynh- 2025-09-19 - B-40189
            return true;

        }
        

        private void addBillChar(Bill bill) {


            Money accountBalance, disputeSaBalance = Money.ZERO;

            // Determine the account balance
            AccountLpcFinancialBalanceRetriever acctBalance = AccountLpcFinancialBalanceRetriever.Factory.newInstance();
            AccountLpcFinancialBalanceData financialBalanceData =  acctBalance.getAccountLpcFinancialBalances(bill.getAccount(), getProcessDateTime().getDate(), bill.getBillDate());
            accountBalance = financialBalanceData.getCurrentAmount();
            
            //Start Add - 2025-02-20 - B-35958
            if (bill.getAccount().fetchDivision().getId().getTrimmedValue().equalsIgnoreCase(CIS_DIVISION_AL)
            		|| bill.getAccount().fetchDivision().getId().getTrimmedValue().equalsIgnoreCase(CIS_DIVISION_GL)){
                // Determine the account balance for SE account (no LPC)
                AccountFinancialBalanceRetriever acctBalanceRet = AccountFinancialBalanceRetriever.Factory.newInstance();
                AccountFinancialBalanceData acctFinancialBalanceData =  acctBalanceRet.getAccountFinancialBalances(bill.getAccount(), getProcessDateTime().getDate(), bill.getBillDate());
                accountBalance = acctFinancialBalanceData.getCurrentAmount(); 

            }
            //End Add - 2025-02-20 - B-35958

            // Deduct any Dispute SA balance from the total account balance
            disputeSaBalance = getDisputeSaBalance(bill);
            if (disputeSaBalance.compareTo(Money.ZERO) > 0) {
                accountBalance = accountBalance.subtract(disputeSaBalance);
            }
            
            Money minAmountForBillChar = new Money(parmMinAmountForBillChar, bill.getAccount().getCurrency().getId());
          //Start Add Dhuynh- 2025-09-19 - B-40189
            Money pledgeAmount = getPaymentsAndPledges(bill);
            accountBalance = accountBalance.subtract(pledgeAmount);
          //End Add Dhuynh- 2025-09-19 - B-40189
            if (accountBalance.isGreaterThan(minAmountForBillChar)) {
            	if (wLatePaymentFlag.isTrue())
            	{
            	bill.calculateLatePaymentCharges();
            	}
                // Add the characteristic only if it is not yet on the bill
                if ((getBillCharSequence(bill, parmBillCharType).equals(BigInteger.ZERO)) &&
                	 (bill.getAccount().getCustomerClass().getId().getTrimmedValue().equalsIgnoreCase(RES_CUST_CL)))
                {
                    // Determine if Bill Characteristic should be added
                    BillCharacteristics billCharacteristics = bill.getCharacteristics();
                    BillCharacteristic_DTO billCharDto = billCharacteristics.newChildDTO();

                    if (parmBillCharType.getCharacteristicType().isAdhocValue()) {
                        billCharDto.setAdhocCharacteristicValue(parmBillCharVal);
                    } else  if (parmBillCharType.getCharacteristicType().isPredefinedValue()) {
                        billCharDto.setCharacteristicValue(parmBillCharVal);
                    } else  if (parmBillCharType.getCharacteristicType().isForeignKeyValue()) {
                        billCharDto.setCharacteristicValueForeignKey1(parmBillCharVal);
                    }
                    billCharacteristics.add(billCharDto, parmBillCharType.getId(), getBillCharSequence(bill, parmBillCharType).add(BigInteger.ONE));
                }
               //Start Add Dhuynh- 2025-09-19 - B-40189
            }else{	
                if ((getBillCharSequence(bill, parmBillCharType).equals(BigInteger.ZERO)) &&
               	 (bill.getAccount().getCustomerClass().getId().getTrimmedValue().equalsIgnoreCase(RES_CUST_CL)))
                {
                    // Determine if Bill Characteristic should be added
                    BillCharacteristics billCharacteristics = bill.getCharacteristics();
                    BillCharacteristic_DTO billCharDto = billCharacteristics.newChildDTO();

                    if (parmBillCharType.getCharacteristicType().isAdhocValue()) {
                        billCharDto.setAdhocCharacteristicValue(parmBillCharValNotlate);
                    } else  if (parmBillCharType.getCharacteristicType().isPredefinedValue()) {
                        billCharDto.setCharacteristicValue(parmBillCharValNotlate);
                    } else  if (parmBillCharType.getCharacteristicType().isForeignKeyValue()) {
                        billCharDto.setCharacteristicValueForeignKey1(parmBillCharValNotlate);
                    }
                    billCharacteristics.add(billCharDto, parmBillCharType.getId(), getBillCharSequence(bill, parmBillCharType).add(BigInteger.ONE));

                }
  
 		   }
            //End Add Dhuynh- 2025-09-19 - B-40189

        }

        private Money getPaymentsAndPledges(Bill bill) {

			StringBuilder activePledgeAmt = new StringBuilder();
            activePledgeAmt.append(" select NVL(SUM(ADHOC_CHAR_VAL), 0) ACTIVEPLEDGE FROM f1_svc_task_char WHERE CHAR_TYPE_CD = 'PLDGAMT' AND  ");
            activePledgeAmt.append(" F1_SVC_TASK_ID IN (select distinct a.F1_SVC_TASK_ID from f1_svc_task a, F1_SVC_TASK_CHAR b ");
            activePledgeAmt.append(" where a.F1_SVC_TASK_ID = b.F1_SVC_TASK_ID ");
            activePledgeAmt.append(" and b.CHAR_VAL_fk1 = :pledgeAccount ");
            activePledgeAmt.append(" and a.F1_STASK_TYPE_CD = 'PLEDGE' and a.BUS_OBJ_CD = 'CMPLEDGE' and a.F1_STASK_TYPE_CD = 'PLEDGE' ");
            activePledgeAmt.append(" and a.BO_STATUS_CD = 'ACTIVE' ");
            activePledgeAmt.append(" and b.CHAR_TYPE_CD = 'ACCOUNT' ) ");
          
            PreparedStatement pledgeAccount = createPreparedStatement(activePledgeAmt.toString(), getClass().getName());
            pledgeAccount.setAutoclose(false);
            
            pledgeAccount.bindId("pledgeAccount", bill.getAccount().getId());
            
            List<SQLResultRow> sqlResultRowList = pledgeAccount.list();
            
            pledgeAccount.close();
            Money totalActivePledges = Money.ZERO;
            if (sqlResultRowList.size() == 0) {
            	totalActivePledges = Money.ZERO;
            }
            else
            {
            	SQLResultRow sqlResultRow = sqlResultRowList.get(0);
            	BigDecimal referralAmount = sqlResultRow.getBigDecimal("ACTIVEPLEDGE");
                // Retrieve the Account's Currency.
                Currency_Id currencyId = bill.getAccount().getCurrency().getId();
                
            	totalActivePledges = new Money(referralAmount, currencyId);

            }

            return totalActivePledges;
	
		}
        private Money getDisputeSaBalance(Bill bill){

            Money disputeSaBalance = Money.ZERO;

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT SA_ID  ");
            stringBuilder.append("FROM CI_SA ");
            stringBuilder.append("WHERE ACCT_ID = :account ");
            stringBuilder.append(  "AND SA_TYPE_CD IN (" + getDisputeSaTypes() + ") ");
            stringBuilder.append(  "AND SA_STATUS_FLG < :closed ");

            PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==getDisputeSaBalance==");
            prepState.bindEntity("account", bill.getAccount());
            prepState.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);            
            prepState.setAutoclose(false);

            List<SQLResultRow> results = prepState.list();

            prepState.close();

            // Tally the balance of the Dispute SA
            for (SQLResultRow sqlResultRow : results) {
                ServiceAgreement sa = sqlResultRow.getEntity("SA_ID", ServiceAgreement.class);

                disputeSaBalance.add(sa.getFinancialBalances(getProcessDateTime().getDate(), bill.getBillDate(), Bool.TRUE).getCurrentAmount());
            }

            return disputeSaBalance;

        }
        
        private String getDisputeSaTypes() {

            CmFeatureConfigurationRetriever cmFeatureConfigurationRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
            FeatureConfiguration_Id featConfigId = new FeatureConfiguration_Id(XSMP_FEAT_CONFIG);
            cmFeatureConfigurationRetriever.setParmWFMName(featConfigId.getEntity());
            cmFeatureConfigurationRetriever.setParmOptType(CmSaMaintenanceExtensionOptionLookup.constants.DISPUTE_SA_TYPE.getLookupValue().fetchIdFieldValue());

            List<String> disputeSaTypeList = cmFeatureConfigurationRetriever.getListOfOptionValues();
            
            String disputeSaTypeStr = "";                     
            
            for (String saType: disputeSaTypeList) {
            	if (isBlankOrNull(disputeSaTypeStr)) {
                    disputeSaTypeStr = disputeSaTypeStr.trim().concat("'");
                    disputeSaTypeStr = disputeSaTypeStr.trim().concat(saType.trim());
                    disputeSaTypeStr = disputeSaTypeStr.trim().concat("'");             		
            	} else {
                    disputeSaTypeStr = disputeSaTypeStr.trim().concat(",'");
                    disputeSaTypeStr = disputeSaTypeStr.trim().concat(saType.trim());
                    disputeSaTypeStr = disputeSaTypeStr.trim().concat("'");            		
            	}
            }

            return disputeSaTypeStr;

        }        

        private BigInteger getBillCharSequence(Bill bill, CharacteristicType charType){

            BigInteger sequence = BigInteger.ZERO;

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT NVL(MAX(SEQ_NUM), 0) AS SEQ_NUM  ");
            stringBuilder.append("FROM CI_BILL_CHAR ");
            stringBuilder.append("WHERE BILL_ID = :bill ");
            stringBuilder.append(  "AND CHAR_TYPE_CD = :charType ");

            PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==getBillCharSequence==");
            prepState.bindEntity("bill", bill);
            prepState.bindEntity("charType", charType);
            prepState.setAutoclose(false);
            prepState.execute();

            if (notNull(prepState.firstRow())) {
                SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
                sequence = sqlRow.getInteger("SEQ_NUM");
            }

            prepState.close();

            return sequence;

        }

        public ToDoProperties createToDoProperties(ThreadWorkUnit unit) {

            Bill_Id billId = (Bill_Id)unit.getPrimaryId();
            ToDoProperties toDoProperties = new ToDoProperties(((Bill)billId.getEntity()).getAccount().getId());
            toDoProperties.setACCT_ID(((Bill)billId.getEntity()).getAccount().getId().toString());
            toDoProperties.setBATCH_NBR(getBatchNumber().toString());
            toDoProperties.setACCT_NAME(((Bill)billId.getEntity()).getAccount().fetchInformation());
            return toDoProperties;

        }

    }

}

