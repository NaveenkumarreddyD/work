/*******************************************************************************
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2018-07-26   LBallo      PII-02. Initial Version.
 ********************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author Administrator
 *
@LookupFieldname (value = XSTP_OPT_TYP_FLG)
 */
public class CmSsnTokenizationParametersLookup_Impl extends
		CmSsnTokenizationParametersLookup_Gen {

}
