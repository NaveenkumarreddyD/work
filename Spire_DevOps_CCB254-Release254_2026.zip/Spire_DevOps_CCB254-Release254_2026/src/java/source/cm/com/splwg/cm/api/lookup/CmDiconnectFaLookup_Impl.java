/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Adjustment Or Billable Charge Lookup
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-01-25   Rakesh    NA0073. Initial Version.
 **************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * 
 * @LookupFieldname (value = DCFA_OPT_TYP_FLG)
 */
public class CmDiconnectFaLookup_Impl 
extends CmDiconnectFaLookup_Gen {

}
