/**************************************************************************
* Program Name: CmRecurringPaymentUploadBatch
* Program Title: CmRecurringPaymentUploadBatch
* Author: LBallo
* Creation Date: 2017-05-22
* Purpose: Upload records to the Recurring Payment Staging table from an
* 		   input file
* Functional Spec: Defect 3753240 / CCB.CC.005.6
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:         Date:         Description:
* -----------------------------------------------------------------------------------------------
 *  Defect 3753240    Louis Ballon    2017-05-16    Initial Version
 ************************************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.ThreadWorker;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;


/**
 * @author LBallo
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)})
 */

public class CmRecurringPaymentUploadBatch extends CmRecurringPaymentUploadBatch_Gen {

	public JobWork getJobWork() {
        List<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        arrayList.add(threadWorkUnit);
        return createJobWorkForThreadWorkUnitList(arrayList);
	}
	
    public void validateSoftParameters(boolean arg0) {
        // Parameter FILE_PATH
        String filePath = getParameters().getFILE_PATH();        
        if (notBlank(filePath) && validateFilePath(filePath).isFalse()) {
            addError(CustomMessageRepository.DEFECT_3753240_InvalidDirectory(getParameters().getFILE_PATH()));
        }
    }
    
    private Bool validateFilePath(String filePath) {

        File folder = new File(filePath);
        if (folder.exists()) {
            return Bool.TRUE;
        }
        return Bool.FALSE;
    }
	
	public Class<? extends ThreadWorker> getThreadWorkerClass() {
		return CmRecurringPaymentUploadBatchWorker.class;
	}
	
    public static class CmRecurringPaymentUploadBatchWorker extends
    CmRecurringPaymentUploadBatchWorker_Gen {

    	// Constant Variables
        private static final String QUOTE_MARK = "\"";
        private static final String COMMA = ",";
        private static final int ACCOUNT_NUM = 0;
        private static final int USER_NAME = 1;
        private static final int ENROLL_DATE = 2;
        private static final int DISTRIBUROR = 3;
        private static final int DATE_CREATED = 4;
        private static final int PAYMENT_SCHEDULE = 5;
        private static final int PAYMENT_FREQUENCY = 6;
        private static final int PAYMENT_TYPE = 7;
        private static final int RECURRING_ID = 8;
    	private final DateFormat DATE_FORMAT = new DateFormat("MM/dd/yyyy hh:mm:ss a"); 
    	
    	// Work variables
    	private BufferedReader bufferedReader = null;  
    	
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}
		

		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
			
			String filePath = getParameters().getFILE_PATH();
	        String fileName = getParameters().getFILE_NAME();
	        
	        File file = new File(filePath, fileName);            
	        
	        try {
	            bufferedReader = new BufferedReader(new FileReader(file));
	        } catch (FileNotFoundException fe) {
	            addError(CustomMessageRepository.DEFECT_3753240_UnableToAccessFile());
	        }
	        
	        PreparedStatement purgeTable = createPreparedStatement("DELETE FROM CM_RECR_PAY", getClass().getName()); 
            purgeTable.execute();
            purgeTable.close();
		}
		
		protected boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			Bool firstLine = Bool.TRUE;
	        
	        try {
	        	while(bufferedReader.ready()) {
	        		
	        		String record = bufferedReader.readLine();
	        		
	        		if (firstLine.isTrue() || !bufferedReader.ready()) {
	                    firstLine = Bool.FALSE;
	                    continue;
	                }
	        		
	        		String[] elements = record.split(QUOTE_MARK + COMMA);
	        		
	        	    String accountNum = elements[ACCOUNT_NUM].replace(QUOTE_MARK, "");
	        	    String userName = elements[USER_NAME].replace(QUOTE_MARK, "");
	        	    String enrollDateStr = elements[ENROLL_DATE].replace(QUOTE_MARK, "");
	        	    String distributor = elements[DISTRIBUROR].replace(QUOTE_MARK, "");
	        	    String createDateStr = elements[DATE_CREATED].replace(QUOTE_MARK, "");
	        	    String paymentSchedule = elements[PAYMENT_SCHEDULE].replace(QUOTE_MARK, "");
	        	    String paymentFrequency = elements[PAYMENT_FREQUENCY].replace(QUOTE_MARK, "");
	        	    String paymentAccountType = elements[PAYMENT_TYPE].replace(QUOTE_MARK, "");
	        	    String recurringId = elements[RECURRING_ID].replace(QUOTE_MARK, "");
	        	    
	                try {
	                    if(isNull( new Account_Id(accountNum.trim()).getEntity())) {
	                        continue;
	                    }
	                } catch (Exception e) {  
	                	continue;
	                }
	        	    
	        	    Date enrollDate;
	        	    Date createDate;
	    			try {
	    				enrollDate = DATE_FORMAT.parseDate(enrollDateStr);
	    				createDate = DATE_FORMAT.parseDate(createDateStr);
	    			} catch (DateFormatParseException e) {
	    				addError(CustomMessageRepository.DEFECT_3753240_DateFormatInvalid());
	    				continue;
	    			}
	        	    
	        	    StringBuilder insertQuery = new StringBuilder();
	        	    insertQuery.append("Insert into ");
	        	    insertQuery.append( "CM_RECR_PAY ");
	        	    insertQuery.append( "( ");
	        	    insertQuery.append(   "ACCT_ID, ");
	        	    insertQuery.append(   "USER_NAME, ");
	        	    insertQuery.append(   "ENROLL_DT, ");
	        	    insertQuery.append(   "DISTRIBUTOR, ");
	        	    insertQuery.append(   "CREATE_DT, ");
	        	    insertQuery.append(   "RECR_PAY_SCHEDULE, ");
	        	    insertQuery.append(   "RECR_PAY_FREQUENCY, ");
	        	    insertQuery.append(   "RECR_PAY_TYPE, ");
	        	    insertQuery.append(   "RECR_ID ");
	        	    insertQuery.append( ") values ( ");
	        	    insertQuery.append(   ":accountNum, ");
	        	    insertQuery.append(   ":userName, ");
	        	    insertQuery.append(   ":enrollDate, ");
	        	    insertQuery.append(   ":distributor, ");
	        	    insertQuery.append(   ":createDate, ");
	        	    insertQuery.append(   ":recrPaySched, ");
	        	    insertQuery.append(   ":recrPayFrequency, ");
	        	    insertQuery.append(   ":recrPayType, ");
	        	    insertQuery.append(   ":recrId ");
	        	    insertQuery.append( ") ");
	        	    
	        	    PreparedStatement insertSQL = createPreparedStatement(insertQuery.toString(), accountNum);
	        	    insertSQL.bindString("accountNum", accountNum, "ACCT_ID");
	        	    insertSQL.bindString("userName", userName, "USER_NAME");
	        	    insertSQL.bindDate("enrollDate", enrollDate);
	        	    insertSQL.bindString("distributor", distributor, "DISTRIBUTOR");
	        	    insertSQL.bindDate("createDate", createDate);
	        	    insertSQL.bindString("recrPaySched", paymentSchedule, "RECR_PAY_SCHEDULE");
	        	    insertSQL.bindString("recrPayFrequency", paymentFrequency, "RECR_PAY_FREQUENCY");
	        	    insertSQL.bindString("recrPayType", paymentAccountType, "RECR_PAY_TYPE");
	        	    insertSQL.bindString("recrId", recurringId, "RECR_ID");
	        	    
	        	    insertSQL.execute();
	        	    insertSQL.close();
	        	}
	        } catch (IOException ie) {
	        	addError(CustomMessageRepository.DEFECT_3753240_UnableToAccessFile());
	        }
    	    return true;
		}
		
    	@Override
    	public void finalizeThreadWork() throws ThreadAbortedException,
    			RunAbortedException {
    		try {
				bufferedReader.close();
			} catch (IOException e) {
				logError(CustomMessageRepository.DEFECT_3753240_UnableToCloseFile());
			}
    	}
    }
}
