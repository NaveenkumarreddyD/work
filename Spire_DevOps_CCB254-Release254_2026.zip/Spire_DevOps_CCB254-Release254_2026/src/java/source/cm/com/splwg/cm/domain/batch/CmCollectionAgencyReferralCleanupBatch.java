/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Collection Agency Referral Clean Up Batch
 * 
 * This batch program selects all active LGC Collection Agency Referrals.
 * For each record, it adds a new Change Record line to zero the balance,
 * adds an explanation to the comments, closes the Collection Agency
 * Referral.
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2015-06-22   BMARQUEZ   SF-3198240. Initial version.
 * 2016-01-27	MPang	   Updated for CCB v2.4 compilation.
 * 2018-07-31   SFelip     CCB v2.6 Upgrade. Fix value being passed to the 
 *                         3rd parameter when calling the bindString() 
 *                         method. It should not include the table alias.              
 *************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControl;
import com.splwg.ccb.api.lookup.ReferralHistoryReasonLookup;
import com.splwg.ccb.api.lookup.ReferralStatusLookup;
//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
/*import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyHistory;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyHistory_DTO;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferralCollectionAgencyHistories;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral_DTO;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral_Id;*/

import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyHistory;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyHistory_DTO;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferralCollectionAgencyHistories;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral_DTO;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral_Id;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 90725
 *
 @BatchJob (rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = batchControl, name = CACI_BATCH_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = ACCT_ID_LOW, required = false, type = string)
 *            , @BatchJobSoftParameter (name = ACCT_ID_HIGH, required = false, type = string)})
 */
public class CmCollectionAgencyReferralCleanupBatch 
		extends CmCollectionAgencyReferralCleanupBatch_Gen {
	
	private String accountIdLow = "";
	private String accountIdHigh = "";

    public JobWork getJobWork() {
    	
    	accountIdLow = getParameters().getACCT_ID_LOW();
    	accountIdHigh = getParameters().getACCT_ID_HIGH();
    	if (isEmptyOrNull(accountIdLow)){
    		accountIdLow = "0000000000";
    	}
    	if (isEmptyOrNull(accountIdHigh)){
    		accountIdHigh = "9999999999";
    	}

        ArrayList<ThreadWorkUnit> threadWorkUnitList =  new ArrayList<ThreadWorkUnit>();
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT CAR.COLL_AGY_REF_ID ");
        stringBuilder.append("FROM CI_COLL_AGY_REF CAR, CI_ACCT AC ");
        stringBuilder.append("WHERE CAR.ACCT_ID >= :accountIdLow AND CAR.ACCT_ID <= :accountIdHigh ");
        stringBuilder.append("AND CAR.REF_STATUS_FLG = :referralStatusActive ");
        stringBuilder.append("AND AC.ACCT_ID = CAR.ACCT_ID ");
        stringBuilder.append("AND AC.CIS_DIVISION = :cisDivision ");
        //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
        //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
        // CCB v2.6 Upgrade - 2018-07-31 - Start Change
        //preparedStatement.bindString("accountIdLow", accountIdLow.trim(), "CAR.ACCT_ID");
        //preparedStatement.bindString("accountIdHigh", accountIdHigh.trim(), "CAR.ACCT_ID");
        
        preparedStatement.bindString("accountIdLow", accountIdLow.trim(), "ACCT_ID");
        preparedStatement.bindString("accountIdHigh", accountIdHigh.trim(), "ACCT_ID");
        // CCB v2.6 Upgrade - 2018-07-31 - End Change
        preparedStatement.bindLookup("referralStatusActive", ReferralStatusLookup.constants.ACTIVE);
        preparedStatement.bindId("cisDivision", getParameters().getCIS_DIVISION().getId());
        
        List<SQLResultRow> sqlResultRowList = preparedStatement.list();
        
        preparedStatement.close();
        
        for (SQLResultRow sqlResultRow : sqlResultRowList) {
            
            ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
            threadWorkUnit.setPrimaryId(sqlResultRow.getId("COLL_AGY_REF_ID", CollectionAgencyReferral.class));
            threadWorkUnitList.add(threadWorkUnit);
            
        }
        
        return createJobWorkForThreadWorkUnitList(threadWorkUnitList);
        
    }

    public Class<CmCollectionAgencyReferralCleanupBatchWorker> getThreadWorkerClass() {
        return CmCollectionAgencyReferralCleanupBatchWorker.class;
    }

    public static class CmCollectionAgencyReferralCleanupBatchWorker extends
            CmCollectionAgencyReferralCleanupBatchWorker_Gen {
        
        private String messageText;
        private BatchControl batchControl;
        private BigInteger nextRun;
        
        @Override
        public void initializeThreadWork(boolean initializationPreviouslySuccessful) throws ThreadAbortedException, RunAbortedException {
            messageText = CustomMessageRepositoryMGE.sf3198240CollectionAgencyReferralComment(getProcessDateTime().getDate()).getMessageText();
            batchControl = getParameters().getCACI_BATCH_CD();
            nextRun = batchControl.getNextBatchNumber();
        }

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new CommitEveryUnitStrategy(this);
        }

        public boolean executeWorkUnit(ThreadWorkUnit threadWorkUnit)
                throws ThreadAbortedException, RunAbortedException {
            
            CollectionAgencyReferral collectionAgencyReferral = ((CollectionAgencyReferral_Id) threadWorkUnit.getPrimaryId()).getEntity();
            
            // Get the latest Collection Agency History
            CollectionAgencyReferralCollectionAgencyHistories collectionAgencyHistories = collectionAgencyReferral.getCollectionAgencyHistories();
            CollectionAgencyHistory latestHistory = null;
            for (CollectionAgencyHistory collectionAgencyHistory : collectionAgencyHistories) {
                if (isNull(latestHistory)) {
                    latestHistory = collectionAgencyHistory;
                    continue;
                }
                
                if (collectionAgencyHistory.getCreDt().isAfter(latestHistory.getCreDt())) {
                    latestHistory = collectionAgencyHistory;
                    continue;
                }
                
                if (collectionAgencyHistory.getCreDt().equals(latestHistory.getCreDt())
                        && collectionAgencyHistory.fetchIdSequence().compareTo(latestHistory.fetchIdSequence()) > 0) {
                    latestHistory = collectionAgencyHistory;
                    continue;
                }
            }
            
            if (isNull(latestHistory)) {
                return false;
            }
            
            // Add a "change referral" (CHG) collection agency referral history record to set the amount to zero
            CollectionAgencyHistory_DTO collectionAgencyHistoryDTO = collectionAgencyHistories.newChildDTO();
            collectionAgencyHistoryDTO.setBatchControlId(batchControl.getId());
            collectionAgencyHistoryDTO.setBatchNumber(nextRun);
            collectionAgencyHistoryDTO.setCreDt(getProcessDateTime().getDate());
            collectionAgencyHistoryDTO.setIsSystemGenerated(Bool.TRUE);
            collectionAgencyHistoryDTO.setReferralAmount(new Money(BigDecimal.ZERO, latestHistory.getReferralAmount().getCurrencyId()));
            collectionAgencyHistoryDTO.setReferralHistoryReason(ReferralHistoryReasonLookup.constants.CHANGE_REFERRAL);
            collectionAgencyHistoryDTO.setTriggerBusinessProcess(Bool.FALSE);
            collectionAgencyHistories.add(collectionAgencyHistoryDTO, latestHistory.fetchIdSequence().add(BigInteger.TEN));
            
            CollectionAgencyReferral_DTO collectionAgencyReferralDTO = collectionAgencyReferral.getDTO();
            
            // Change the Referral Status to CLOSED
            collectionAgencyReferralDTO.setReferralStatus(ReferralStatusLookup.constants.CLOSED);
            
            // Add or append a closing comment to the referral
            String existingComments = collectionAgencyReferral.getComments();
            if (isBlankOrNull(existingComments)) {
                collectionAgencyReferralDTO.setComments(messageText);
            } else {
                collectionAgencyReferralDTO.setComments(messageText + " -- " + existingComments);
            }
            
            collectionAgencyReferral.setDTO(collectionAgencyReferralDTO);
            
            return true;
            
        }

    }

}
