/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Update Bill Routing for Alabama and Gulf Utilities.
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2021-03-31   RDizon     CCB027.3. Initial version. 
 * 2021-05-19   RDizon     CCB027.Issue1. Update Batch Control and Next 
 *                         Run Number when updating the Bill Route Type.
 * 2021-07-08   JMeden     CCB027.Issue3. Update logic to not update the
 *                         Bill Route Details if the Do Not Extract is Checked
 * 2021-09-10   JGoco      CCB027.Issue4. Retrieve all Bill Routing records.
 *                         Update the Account Persons Bill Route Type to 
 *                         the parameter Bill Route Type.
 * 2021-11-02   BMarquez   Defect 4604507. Alter Bill Route Type if the
 *                         Account on the Bill has specified Bill Cycle
 *                         and Bill Cycle is open.
 * 2022-02-03   BMarquez   D-03125. Non-Transportation Bills should not be
 *                         marked with 
 * 2025-11-14   EQuint      CCB25.4 Upgrade
 *************************************************************************/

package com.splwg.cm.domain.admin.customerClass.algorithm.postBillCompletion;

import java.math.BigInteger;
import java.util.Iterator;

import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.batch.batchControl.BatchControl;
import com.splwg.base.domain.security.user.User_Id;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.domain.admin.billCycle.entity.BillCycle;
import com.splwg.ccb.domain.admin.billRouteType.entity.BillRouteType;
import com.splwg.ccb.domain.admin.customerClass.algorithm.postBillCompletion.CustomerClassPostBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillRouting;
import com.splwg.ccb.domain.billing.bill.entity.BillRouting_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPersons;
import com.splwg.ccb.domain.security.user.entity.User;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;


/**
 * @author RDizon
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = billRouteType, name = billRouteType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billCycle, name = transportationBillCycle, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billRouteType, name = transportationBillRouteType, type = entity)
 *            , @AlgorithmSoftParameter (entityName = user, type = entity, name = transportationInterceptUser)})
 */
public class CmUpdateBillRouteTypeAlgComp_Impl
    extends CmUpdateBillRouteTypeAlgComp_Gen
    implements CustomerClassPostBillCompletionAlgorithmSpot {
    
    // Hard Parameters
    private Bill bill;
    
    // Soft Parameters    
    private BillRouteType parmBillRouteType;
    /*
     * Start Add - Defect 4604507 - 2021-11-02
     */
    private BillCycle parmTransportationBillCycle;
    private BillRouteType parmTransportationBillRouteType;
    private User parmTransportationInterceptUser;
    /*
     * End Add - Defect 4604507 - 2021-11-02
     */
    
    // Work Variables
    /*
     * Start Delete - Defect 4604507 - 2021-11-02
     */
    //private BillRouting billRouting;
    /*
     * End Delete - Defect 4604507 - 2021-11-02
     */
    
    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        parmBillRouteType = getBillRouteType();
        
        /*
         * Start Add - Defect 4604507 - 2021-11-02
         */
        parmTransportationBillCycle = getTransportationBillCycle();
        parmTransportationBillRouteType = getTransportationBillRouteType();
        parmTransportationInterceptUser = getTransportationInterceptUser();
        
        // ^ is the XOR operator (only true if one is true and the other is false)
        if (notNull(parmTransportationBillCycle) ^ (notNull(parmTransportationBillRouteType) || notNull(parmTransportationInterceptUser))) {
            addError(CustomMessageRepositorySpireOne.CCB027_3_IncompleteTransportationConfiguration(getAlgorithm()));
        }
        /*
         * End Add - Defect 4604507 - 2021-11-02
         */
        
    }

    @Override
    public void invoke() {

    	// Start Delete - JGoco - 2021-09-10 - CCB027.Issue4    	
        /*
        ListFilter<BillRouting> listBillRoutings = bill.getRoutings().createFilter("WHERE this.id.sequence = :sequence", 
                getClass().getName());
        listBillRoutings.bindBigInteger("sequence", BigInteger.ONE);
        billRouting = listBillRoutings.firstRow();    
      
        
        
        
        // Start Add - JMeden - 2021-07-08 - CCB027.Issue3
        if(billRouting.getDoNotExtract().isTrue()){
            return;
        }
        // End Add - JMeden - 2021-07-08 - CCB027.Issue3

        // Update the Bill Route Type
        BillRouting_DTO billRoutingDto = billRouting.getDTO();
        billRoutingDto.setBillRouteTypeId(parmBillRouteType.getId());
        
        // Start Add - RDizon - 2021-05-19 - CCB037.Issue1
        BatchControl billRouteTypeBatch = parmBillRouteType.getBatchControl();
        billRoutingDto.setBatchControlId(billRouteTypeBatch.getId());
        billRoutingDto.setBatchNumber(billRouteTypeBatch.getNextBatchNumber());
        // End Add - RDizon - 2021-05-19 - CCB037.Issue1
        
        billRouting.setDTO(billRoutingDto);       
        */
    	// End Delete - JGoco - 2021-09-10 - CCB027.Issue4    	
        
        // Start Add - JGoco - 2021-09-10 - CCB027.Issue4
        
        /*
         * Start Add - Defect 4604507 - 2021-11-02
         */
        BillRouteType billRouteType = determineBillRouteType();
        String interceptUser = determineInterceptUser();
        
        BatchControl billRouteTypeBatch = billRouteType.getBatchControl();
        BigInteger billRouteTypeBatchNextBatchNumber = billRouteTypeBatch.getNextBatchNumber();
        /*
         * End Add - Defect 4604507 - 2021-11-02
         */
        
    	// Go through the bill routing entries 
        for (Iterator<BillRouting> iter = bill.getRoutings().iterator(); iter.hasNext(); ) {
        	BillRouting billRouting = (BillRouting)iter.next();
        	
        	// Update only routings that are not flagged for do not extract.
        	if(billRouting.getDoNotExtract().isFalse()){
                BillRouting_DTO billRoutingDto = billRouting.getDTO();
                
                /*
                 * Start Change - Defect 4604507 - 2021-11-02
                 */
                //billRoutingDto.setBillRouteTypeId(parmBillRouteType.getId());
                //
                //BatchControl billRouteTypeBatch = parmBillRouteType.getBatchControl();
                //billRoutingDto.setBatchControlId(billRouteTypeBatch.getId());
                //billRoutingDto.setBatchNumber(billRouteTypeBatch.getNextBatchNumber());  
                
                billRoutingDto.setBillRouteTypeId(billRouteType.getId());
                billRoutingDto.setBatchControlId(billRouteTypeBatch.getId());
                billRoutingDto.setBatchNumber(billRouteTypeBatchNextBatchNumber);
                
                if (notNull(interceptUser)) {
                	// start update - equint - 2025-11-14 - CCB25.4 Upgrade
                    // billRoutingDto.setBillPrintIntercept(interceptUser);
                    billRoutingDto.setBillPrintInterceptId(new User_Id(interceptUser));;
                    // end update - equint - 2025-11-14 - CCB25.4 Upgrade
                }
                /*
                 * End Change - Defect 4604507 - 2021-11-02
                 */
                
                ((FrameworkSession)SessionHolder.getSession()).overrideDTOValue(billRoutingDto);
        	}
        
        }        
        
        // Update Account Persons Bill Route Type to the CIS Division default Bill Route Type defined as parameter
        AccountPersons acctPersons = bill.getAccount().getPersons();        
        for (Iterator<AccountPerson> iter = acctPersons.iterator(); iter.hasNext(); ) {
            AccountPerson accountPerson = (AccountPerson)iter.next();                        
            
            // update only persons who will receive copy of bill and has a different route type from the parameter
            if(accountPerson.getShouldReceiveCopyOfBill().isTrue() &&
                    !(accountPerson.getBillRouteTypeId().equals(parmBillRouteType.getId()))) {
                AccountPerson_DTO accountPersonDto = accountPerson.getDTO();
                accountPersonDto.setBillRouteTypeId(parmBillRouteType.getId());
                ((FrameworkSession)SessionHolder.getSession()).overrideDTOValue(accountPersonDto);
            }
          } 
        // End Add - JGoco - 2021-09-10 - CCB027.Issue4
    }

    @Override
    public void setBill(Bill bill) {    
        this.bill = bill;
    }
    
    /*
     * Start Add - Defect 4604507 - 2021-11-02
     */
    private BillRouteType determineBillRouteType() {
        
        // If the Transportation Bill Cycle or Bill Route Type were not provided
        if (isNull(parmTransportationBillCycle) || isNull(parmTransportationBillRouteType)) {
            return parmBillRouteType;
        }
        
        BillCycle accountBillCycle = bill.getAccount().fetchBillCycle();
            
        // If the Account has a Bill Cycle not matching the Transportation Bill Cycle or the Bill Cycle is not open
        if (isNull(accountBillCycle) || !parmTransportationBillCycle.equals(accountBillCycle) || !isBillCycleOpen(accountBillCycle)) {
            return parmBillRouteType;   
        }
        
        // Change the Bill Route Type to the Transportation Bill Route Type
        return parmTransportationBillRouteType;
        
    }
    
    private boolean isBillCycleOpen(BillCycle billCycle) {
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select 'X' ");
        stringBuilder.append("from CI_BILL_CYC_SCH ");
        stringBuilder.append("where BILL_CYC_CD = :billCycle ");
        stringBuilder.append("and WIN_START_DT <= :processDate ");
        stringBuilder.append("and WIN_END_DT >= :processDate");
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("billCycle", billCycle.getId());
        preparedStatement.bindDate("processDate", getProcessDateTime().getDate());
        
        preparedStatement.setAutoclose(true);
        preparedStatement.execute();
        
        return notNull(preparedStatement.firstRow());
        
    }
    
    private String determineInterceptUser() {
        
    	/*
    	 *  Start Add - D-03125 - 2022-02-03
    	 */
    	// Use the Account Intercept User if populated
    	User accountInterceptUser = bill.getAccount().fetchBillPrintIntercept();
    	if (notNull(accountInterceptUser)) {
    		return accountInterceptUser.getId().getTrimmedValue();
    	}
    	/*
    	 *  End Add - D-03125 - 2022-02-03
    	 */
    	
        // If the Transportation Bill Cycle or Transportation Intercept User CIS Division Characteristic Type were not provided
        if (isNull(parmTransportationBillCycle) || isNull(parmTransportationInterceptUser)) {
            return null;
        }
        
        /*
         * Start Add - D-03125 - 2022-02-03
         */
        BillCycle accountBillCycle = bill.getAccount().fetchBillCycle();
        
        // If the Account has a Bill Cycle not matching the Transportation Bill Cycle or the Bill Cycle is not open
        if (isNull(accountBillCycle) || !parmTransportationBillCycle.equals(accountBillCycle) || !isBillCycleOpen(accountBillCycle)) {
            return null;   
        }
        /*
         * End Add - D-03125 - 2022-02-03
         */
        
        // Populate the Intercept User with the Algorithm parameter
        return parmTransportationInterceptUser.getId().getTrimmedValue();
        
    }
    /*
     * End Add - Defect 4604507 - 2021-11-02
     */
}