/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * MGE-CCB004.006 (CR3135978) - Collections New Turn On Extract 
 * 
 * This batch process reads the change log table that captures new turn on 
 * (start service) requests and creates an extract for DebtNext.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2014-01-30	MCRUZ			MGE-CCB004.006 (CR3135978) Initial Version.
 * 2016-01-27	MPang	 		Updated for CCB v2.4 compilation. 
 **************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.database.table.Table_Id;
import com.splwg.ccb.api.lookup.ReferralStatusLookup;
//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
/*import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;*/
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.api.batch.CmCollectionsNewTurnOnExtractRecord;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author mcruz
 *
 @BatchJob (multiThreaded = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)})
 */
public class CmCollectionsNewTurnOnExtractBatch 
		extends CmCollectionsNewTurnOnExtractBatch_Gen {
	
	private static final Table_Id CI_SA_TBL = new Table_Id("CI_SA");
	private static final String PARM_DESCR_FILE_PATH = "File Path";

	public JobWork getJobWork() {
		
		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
		
		// Retrieve all SA change log records for this batch control/run.
		QueryIterator<SQLResultRow> changeLogsIter = null;
		
		PreparedStatement getChangeLogs = createPreparedStatement("SELECT " +
				"	PK_VAL1 " +
				"FROM " +
				"	CI_CHG_LOG " +
				"WHERE " +
				"	BATCH_CD = :batchCode " +
				"	AND BATCH_NBR = :batchNumber " +
				//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
				//"	AND TBL_NAME = :tableName");
				"	AND TBL_NAME = :tableName", getClass().getName());
				//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
		
		getChangeLogs.bindId("batchCode", this.getBatchControlId());
		getChangeLogs.bindBigInteger("batchNumber", this.getBatchNumber());
		getChangeLogs.bindId("tableName", CI_SA_TBL);
		
		changeLogsIter = getChangeLogs.iterate();
		
		while(changeLogsIter.hasNext()) {
			SQLResultRow row = changeLogsIter.next();
			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			String pkVal = (String) row.get("PK_VAL1");
			ServiceAgreement_Id saId = new ServiceAgreement_Id(pkVal);
			workUnit.setPrimaryId(saId);
			workUnits.add(workUnit);
		}
		
		changeLogsIter.close();
		getChangeLogs.close();
		
		return createJobWorkForThreadWorkUnitList(workUnits);
		
	}
	
	@Override
	public void validateSoftParameters(boolean arg0) {
		
		String parmFilePath = this.getParameters().getFILE_PATH();
		validateFilePath(parmFilePath);
		
	}

	private void validateFilePath(String filePath) {
		File file = new File(filePath.trim());
		if (!file.isDirectory()) {
			// Batch parameter '%1%2' value (%3%4) is not a valid file path.
			addError(CustomMessageRepositoryMGE.commBatchParameterIsNotValidFilePath(PARM_DESCR_FILE_PATH, filePath));
		}
	}
	
	public Class<CmCollectionsNewTurnOnExtractBatchWorker> getThreadWorkerClass() {
		return CmCollectionsNewTurnOnExtractBatchWorker.class;
	}

	public static class CmCollectionsNewTurnOnExtractBatchWorker extends
			CmCollectionsNewTurnOnExtractBatchWorker_Gen {
		
		private static final String DATE_FORMAT = "yyyy-MM-dd";		
		
		private String parmFileName;
		private String parmFilePath;
		
		private String accountIdStr;
		private String saIdStr;
		private String cisDivisionIdStr;
		private String saTypeIdStr;
		private String saStartDateStr;
		
		private CmCollectionsNewTurnOnExtractRecord record;
		
		private File extractFile; 
		private BufferedWriter bufferedWriter;
		private String recordString;
		
		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
			
			// Get the parameters
			parmFilePath = this.getParameters().getFILE_PATH();
			parmFileName = this.getParameters().getFILE_NAME();
			
			// Create or open the extract file.
			openFile();

		}

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
			
			// Close the extract file.
			closeFile();
		}

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			// Get the SA from the Change Log.
			ServiceAgreement_Id saId = (ServiceAgreement_Id) unit.getPrimaryId();
			ServiceAgreement sa = saId.getEntity();
						
			// Get data related to the SA.
			accountIdStr = sa.getAccount().getId().getIdValue().trim();
			saIdStr = saId.getIdValue().trim();
			cisDivisionIdStr = sa.getServiceAgreementType().getId().getDivisionId().getIdValue().trim();
			saTypeIdStr = sa.getServiceAgreementType().getId().getSaType().trim();
			saStartDateStr = sa.getStartDate().toString(new DateFormat(DATE_FORMAT));
			
			// Get the active Collection Agency Referrals linked to the Account.
			Account_Id accountId = new Account_Id(accountIdStr);
			List collectionReferrals = getActiveCollectionReferrals(accountId);
			
			if(!collectionReferrals.isEmpty()) {
				Iterator collectionReferralsIter = collectionReferrals.iterator();
				
				// Write a record line for every retrieved referral.
				while(collectionReferralsIter.hasNext()) {
					
					SQLResultRow resultRow = (SQLResultRow) collectionReferralsIter.next();
					String collAgyReferralIdStr = resultRow.getString("COLL_AGY_REF_ID");
					
					record = new CmCollectionsNewTurnOnExtractRecord();
					record.setAccount(accountIdStr);
					record.setServiceAgreement(saIdStr);
					record.setCisDivision(cisDivisionIdStr);
					record.setSaType(saTypeIdStr);
					record.setSaStartDate(saStartDateStr);
					record.setCollectionAgencyReferral(collAgyReferralIdStr);

					recordString = record.createRecordString();
					writeToFile(recordString);
				}
			}
			return true;
		}

		/**
		 * This method opens the File to prepare it for writing.
		 *
		 */
		private void openFile() {
						
			try {
    			extractFile = new File(parmFilePath.trim(), parmFileName.trim());
				bufferedWriter = new BufferedWriter(new FileWriter(extractFile));
			} 
            catch (Exception e) {
            	throw new RunAbortedException((CustomMessageRepositoryMGE.commFileError(parmFilePath.trim() + parmFileName.trim())));
			}
		}
		
		/**
		 * This method writes a single line to the extract file.
		 * @param String
		 */
		private void writeToFile(String lineString) {
						
			try {
				bufferedWriter.write(lineString);
				bufferedWriter.newLine();
			}
			catch (Exception e) {
				// Error writing file: %1%2
				throw new RunAbortedException(CustomMessageRepositoryMGE.ccb004ErrorWritingToFile(parmFilePath.trim(), parmFilePath.trim()));
			}
		}
		
		/**
		 * This method closes the extract file.
		 *
		 */
		private void closeFile() {
			
			try {
				bufferedWriter.close();
			}
			catch (Exception e) {
				// Error closing file: %1%2
				throw new RunAbortedException(CustomMessageRepositoryMGE.ccb004ErrorClosingFile(parmFilePath.trim(), parmFilePath.trim()));
			}
		}
		
		/**
		 * This mehod retrieves the active collection referrals from the account.
		 * @param Account_Id
		 * @return
		 */
		private List getActiveCollectionReferrals(Account_Id accountId) {
						
			List collectionReferrals = null;
			
			PreparedStatement getCollectionReferrals = createPreparedStatement("SELECT " +
					"	COLL_AGY_REF_ID " +
					"FROM " +
					"	CI_COLL_AGY_REF " +
					"WHERE " +
					"	ACCT_ID = :accountId " +
					//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
					//"	AND REF_STATUS_FLG IN (:status)");
					"	AND REF_STATUS_FLG IN (:status)", getClass().getName());
					//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			
			getCollectionReferrals.bindId("accountId", accountId);
			getCollectionReferrals.bindLookup("status", ReferralStatusLookup.constants.ACTIVE);
			
			collectionReferrals = getCollectionReferrals.list();
			getCollectionReferrals.close();
			
			return collectionReferrals;
		}
	}

}
