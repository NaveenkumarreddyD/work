/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NI0026.6 - Pledge Payment Reconciliation- Outbound
 *
 * This batch creates an extract file for the Agency Website. The extract
 * file will contain information on all Pledge Payments; these Payments
 * will be identified by designated suspense Accounts. The Agency Website will
 * then match a corresponding Pledge.
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-03-27   Neha    NI0026.6. Initial Version.
 * 2013-05-31   JPunza  TIR1 & TIR2. Modified to replace static variables
 *                      and retrieve the Customer ID correctly.
 * 2013-08-22   Mohit   Fixed as per IM-36265 , Exlude the pledge records
 * 						which has been paid.
 * 2016-01-29  	MPang	Updated for CCB v2.4 compilation.
 * 2018-07-25   SFelip  CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                      longer needed. 
 * 2020-10-27   DLampa  B-17434. Remove To Do Creation.                     
 **************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
/*
 * Start Delete - 2013-05-31 - JPunza
 */
//import com.splwg.base.api.datatypes.Bool;
/*
 * End Delete - 2013-05-31 - JPunza
 */
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.ccb.api.lookup.TenderStatusLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType;
import com.splwg.ccb.domain.admin.tenderSource.TenderSource;
import com.splwg.ccb.domain.admin.tenderSource.TenderSource_Id;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentEvent;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentEvent_Id;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoMaintenanceData;*/
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource_Id;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentEvent;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentEvent_Id;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @BatchJob ( modules = {}
 *              , multiThreaded = false
 *              , rerunnable = true
 *              , softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string )
 *                                 , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string )
 *                                 , @BatchJobSoftParameter (name = MAX_ERRORS, required = false, type = integer)
 *                                 , @BatchJobSoftParameter (name = PLDG_FUND_TNDR_SRC_OPT_TYP, required = true, type = string)
 *                                 , @BatchJobSoftParameter (name = SUSPENSE_SA_TYP_OPT_TYP, required = true, type = string)
 *                                 , @BatchJobSoftParameter (name = TO_DO_TYPE_INVAL_PAYEE, required = true, type = entity, entityName = toDoType)
 *                                 }
 *            )
 */

public class CmPledgePayReconOut_BatchProcess
extends CmPledgePayReconOut_BatchProcess_Gen {

    // Constants
    private final static String DATE_FORMAT = "yyyy-MM-dd";
    private static final String FEATURE_CONFIG_NAME = "SCHEMACONST";

    /*
     * Start Delete - 2013-05-31 - JPunza
     */
    //// Soft Parameters
    //private static String parmFileName;
    //private static String parmFilePath;
    //private static BigInteger parmMaxErrors = BigInteger.ZERO;
    //private static String parmPldgFundType;
    //private static String parmSuspenseSaType;
    //private static ToDoType parmTodoTypeInvalPayee;
    /*
     * End Delete - 2013-05-31 - JPunza
     */

    /**
     * Method to validate batch Soft Paramters.
     * @param isNewRun a boolean value.
     */
    public void validateSoftParameters(boolean isNewRun) {

        /*
         * Start Change - 2013-05-31 - JPunza
         */
        //parmFileName = getParameters().getFILE_NAME();
        String parmFilePath;
        BigInteger parmMaxErrors;
        String parmPldgFundType;
        String parmSuspenseSaType;
        /*
         * End Change - 2013-05-31 - JPunza
         */

        parmFilePath = getParameters().getFILE_PATH();

        // Raise an error if the FILE_PATH is invalid.
        File folder = new File(parmFilePath);
        if(!folder.exists()){
            // Batch Parameter %1 (%2) is not a valid file path.
            addError(CustomMessageRepository.ni0026_6InvalidFilePath(parmFilePath));
        }

        parmMaxErrors = getParameters().getSoftMaxErrors();
        // Check if the override maximum errors is less than 0
        if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
            addError(CustomMessageRepository.ni0026_6MaxErrorCannotBeLessThanZero(parmMaxErrors.toString().trim()));
        }

        parmPldgFundType = getParameters().getPLDG_FUND_TNDR_SRC_OPT_TYP();
        List<String> values = validateOptionType(parmPldgFundType);
        if(values.isEmpty()){
            addError(CustomMessageRepository.ni0026_6TenderSourceNotConfiguredOnFeatConf(FEATURE_CONFIG_NAME));
        }
        for(String value : values){
            TenderSource_Id tndrSrcId = new TenderSource_Id(value);
            if(isNull(tndrSrcId) || isNull(tndrSrcId.getEntity())){
                addError(CustomMessageRepository.ni0026_6InvalidTenderSourceOnFeatConf(value,parmPldgFundType, FEATURE_CONFIG_NAME));
            }
        }
        parmSuspenseSaType = getParameters().getSUSPENSE_SA_TYP_OPT_TYP();
        values = validateOptionType(parmSuspenseSaType);
        if(values.isEmpty()){
            addError(CustomMessageRepository.ni0026_6SuspenseSATypesNotConfigOnFeatConf(FEATURE_CONFIG_NAME));
        }
        /*
         * Start Change - 2013-05-31 - JPunza
         */
        //validateSaTypes(values);
        //parmTodoTypeInvalPayee = getParameters().getTO_DO_TYPE_INVAL_PAYEE();
        validateSaTypes(values, parmSuspenseSaType);
        /*
         * End Change - 2013-05-31 - JPunza
         */
    }

    @SuppressWarnings("unchecked")
    private List<String> validateOptionType(String optType){

        List<String> strFeatureConfigVal = null;

        FeatureConfiguration_Id schemaConstantsId = new FeatureConfiguration_Id(FEATURE_CONFIG_NAME);
        FeatureConfiguration schemaConstantsFeatureConfig = schemaConstantsId.getEntity();
        if(isNull(schemaConstantsFeatureConfig)){
            addError(CustomMessageRepository.ni0026_6SchemaConstFeatureConfigNotExists(FEATURE_CONFIG_NAME));
        }

        StringBuilder getOptionTypeString = new StringBuilder();
        getOptionTypeString.append("SELECT 'X' FROM CI_LOOKUP_VAL LOOK ");
        getOptionTypeString.append("WHERE TRIM(LOOK.FIELD_NAME) = (SELECT TRIM(WFM.EXT_SYS_TYP_FLG)|| '_OPT_TYP_FLG' FROM CI_WFM WFM WHERE WFM.WFM_NAME = :wfmName) ");
        // CCB v2.6 Upgrade - 2018-07-25 - Start Change
        //getOptionTypeString.append("AND TRIM(LOOK.FIELD_VALUE) = :optionType ");
        getOptionTypeString.append("AND LOOK.FIELD_VALUE = :optionType ");
        // CCB v2.6 Upgrade - 2018-07-25 - End Change

        //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement optionTypeStmt = createPreparedStatement(getOptionTypeString.toString());
        PreparedStatement optionTypeStmt = createPreparedStatement(getOptionTypeString.toString(), getClass().getName());
        //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        optionTypeStmt.bindId("wfmName", schemaConstantsId);
        optionTypeStmt.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType,optType);
        if(isNull(optionTypeStmt.firstRow())){
            addError(CustomMessageRepository.ni0026_6InvalidOptionTypForFeatureConfig(optType,FEATURE_CONFIG_NAME));
        }
        optionTypeStmt.close();

        CmFeatureConfigurationRetriever cmFeatureConfigurationRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
        cmFeatureConfigurationRetriever.setParmWFMName(schemaConstantsFeatureConfig);
        cmFeatureConfigurationRetriever.setParmOptType(optType);
        strFeatureConfigVal = cmFeatureConfigurationRetriever.getListOfOptionValues();
        return strFeatureConfigVal;
    }
    /*
     * Start Change - 2013-05-31 - JPunza
     */
    //private void validateSaTypes(List<String> saTypeList){
    private void validateSaTypes(List<String> saTypeList, String parmSuspenseSaType){
    /*
     * End Change - 2013-05-31 - JPunza
     */
        for(String saType : saTypeList){
            StringBuilder getSaTypeString = new StringBuilder();
            getSaTypeString.append("SELECT 'X' FROM CI_SA_TYPE ");
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //getSaTypeString.append("WHERE TRIM(SA_TYPE_CD) = :saType ");
            getSaTypeString.append("WHERE SA_TYPE_CD = :saType ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement saTypeStmt = createPreparedStatement(getSaTypeString.toString());
            PreparedStatement saTypeStmt = createPreparedStatement(getSaTypeString.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            saTypeStmt.bindStringProperty("saType", ServiceAgreementType.properties.saType,saType.trim());
            if(isNull(saTypeStmt.firstRow())){
                addError(CustomMessageRepository.ni0026_6InvalidSATypConfFeatureConfig(saType,parmSuspenseSaType,FEATURE_CONFIG_NAME));
            }
            saTypeStmt.close();
        }

    }
    /**
     * Retrieves the records to be processed.
     * @return the JobWork that will be processed in this run.
     */
    public JobWork getJobWork() {

        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit workUnit = new ThreadWorkUnit();
        workUnits.add(workUnit);
        return createJobWorkForThreadWorkUnitList(workUnits);
    }
    /**
     * Method to retrieve the Thread Worker Class
     * @return CmPledgePayReconOut_BatchProcessWorker.class a CmPledgePayReconOut_BatchProcessWorker Class
     */
    public Class<CmPledgePayReconOut_BatchProcessWorker> getThreadWorkerClass() {

        return CmPledgePayReconOut_BatchProcessWorker.class;
    }

    public static class CmPledgePayReconOut_BatchProcessWorker
    extends CmPledgePayReconOut_BatchProcessWorker_Gen {

        //Working Variables
        private File extractFile = null;
        private BufferedWriter outputFileWriter = null;

        private final String COMMA_DELIMITER = ",";

        //Working variables
        private BigInteger numberOfRecordsInError = BigInteger.ZERO;
        private BigInteger numberOfRecordsProcessed = BigInteger.ZERO;

        /*
         * Start Add - 2013-05-31 - JPunza
         */
        // Soft Parameters
        private String parmFileName;
        private String parmFilePath;
        private BigInteger parmMaxErrors;
        private String parmPldgFundType;
        private String parmSuspenseSaType;
        /*
         * End Add - 2013-05-31 - JPunza
         */

        /**
         * This method identifies the execution strategy to be used for the thread.
         * @return an instance of ThreadExecutionStrategy that governs how this ThreadWorker will be executed at runtime.
         * @see com.splwg.base.api.batch.ThreadWorker#createExecutionStrategy()
         */
        public ThreadExecutionStrategy createExecutionStrategy() {

            return new SingleTransactionStrategy(this);
        }

        /**
         * Perform any initialization that must be done at the start of this thread processing work.
         * @param initializationPreviouslySuccessful - indicates that this method was called successfully called during some
         * prior execution, presumably because this is a restart situation.
         * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted
         * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
         * @see com.splwg.base.api.batch.ThreadWorker#initializeThreadWork(boolean)
         */
        public void initializeThreadWork(boolean initializationPreviouslySuccessful)
        throws ThreadAbortedException, RunAbortedException {

            /*
             * Start Add - 2013-05-31 - JPunza
             */
            ThreadParameters parameters = getParameters();
            parmFileName = parameters.getFILE_NAME();
            parmFilePath = parameters.getFILE_PATH();
            parmMaxErrors = parameters.getSoftMaxErrors();
            parmPldgFundType = parameters.getPLDG_FUND_TNDR_SRC_OPT_TYP();
            parmSuspenseSaType = parameters.getSUSPENSE_SA_TYP_OPT_TYP();
            /*
             * End Add - 2013-05-31 - JPunza
             */

            // Generate File name
            extractFile = new File(parmFilePath, parmFileName);
            try {
                // Open File
                outputFileWriter = new BufferedWriter(new FileWriter(extractFile));
            } catch (IOException iOException) {
                // Error in file : %1.(While Opening)
                throw new RunAbortedException(CustomMessageRepository.ni0026_6ErrorInFile(iOException.getMessage()));
            }
        }
        /**
         * Execute a WorkUnit and provide result details.
         * @param unit - a ThreadWorkUnit
         * @return a workUnitResult that describes the number of total records processed and number of reocrds in error status work unit processing.
         * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted
         * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
         * @see com.splwg.base.api.batch.ThreadWorker#executeWorkUnitDetailedResult(com.splwg.base.api.batch.ThreadWorkUnit)
         */

        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit arg0)
        throws ThreadAbortedException, RunAbortedException {

            PaymentEvent_Id payEventId = null;
            String payeeAcct = "";
            Date payDate = null;
            String payorAccount ="";
            Money tenderAmount = Money.ZERO;
            TenderSource_Id fundType = null;

            // Retrieving all eligible customer contacts.
            List<SQLResultRow> getEligiblePaymentTendersList = getEligiblePaymentTendersQry();
            if(!getEligiblePaymentTendersList.isEmpty()){
                StringBuffer newRecord;

                for(SQLResultRow tenderRow : getEligiblePaymentTendersList){
                    payEventId = (PaymentEvent_Id)tenderRow.getId("PAY_EVENT_ID", PaymentEvent.class);
                    payeeAcct = tenderRow.getString("MICR_ID");
                    payDate = tenderRow.getDate("PAY_DT");
                    // Start Delete - 2020-10-27 - DLampa - B-17434 
                    //if(isNull(payeeAcct) || (notNull(payeeAcct) && payeeAcct.trim().length() != 10)){
                    //    createToDoEntry(payEventId.getTrimmedValue(), payeeAcct, payDate);
                    //    numberOfRecordsInError = numberOfRecordsInError.add(BigInteger.ONE);
                    //    maxErrorHandling();
                    //    continue;

                    //}
                    // End Delete - 2020-10-27 - DLampa - B-17434 
                    
                    if(notNull(tenderRow.getString("AGCY_ACCT_ID"))){
                        payorAccount = tenderRow.getString("AGCY_ACCT_ID").trim();
                    }
                    /*
                     * Start Add - 2013-05-31 - JPunza
                     */
                    else {
                        payorAccount = new String();
                    }
                    /*
                     * End Add - 2013-05-31 - JPunza
                     */
                    tenderAmount = tenderRow.getMoney("TENDER_AMT");
                    fundType = (TenderSource_Id)tenderRow.getId("FUND_TYPE", TenderSource.class);

                    // write to file
                    newRecord  = new StringBuffer();
                    newRecord.append(payEventId.getTrimmedValue());
                    newRecord.append(COMMA_DELIMITER);
                    newRecord.append(payeeAcct.trim());
                    newRecord.append(COMMA_DELIMITER);
                    newRecord.append(payDate.toString(new DateFormat(DATE_FORMAT)));
                    newRecord.append(COMMA_DELIMITER);
                    newRecord.append(payorAccount);
                    newRecord.append(COMMA_DELIMITER);
                    newRecord.append(tenderAmount.getAmount().toString());
                    newRecord.append(COMMA_DELIMITER);
                    newRecord.append(fundType.getTrimmedValue());
                    writeIntoFile(newRecord.toString());
                    numberOfRecordsProcessed = numberOfRecordsProcessed.add(BigInteger.ONE);
                }
            }


            WorkUnitResult workUnitResult = new WorkUnitResult(true);
            workUnitResult.setUnitsProcessed(numberOfRecordsProcessed.intValue());
            workUnitResult.setUnitsInError(numberOfRecordsInError.intValue());
            return workUnitResult;
        }
        // Start Delete - 2020-10-27 - DLampa - B-17434
        /**
         * This method handles Max Error handling
         */
        //private void maxErrorHandling() {

        //    if (notNull(parmMaxErrors)) {
        //        if (numberOfRecordsInError.intValue() >= parmMaxErrors.intValue()) {
        //            try {
        //                if(notNull(outputFileWriter))
        //                    outputFileWriter.close();
        //            } catch (IOException e) {
        //                throw new RunAbortedException(CustomMessageRepository.ni0026_6ErrorInFile(e.getMessage().trim()));
        //            }
        //            extractFile.delete();
        //            throw new RunAbortedException(CustomMessageRepository.ni0026_6MaxErrorCountReached(parmMaxErrors.toString()));
        //        }
        //    }
        //}
        // End Delete - 2020-10-27 - DLampa - B-17434
        
        /**
         * Method to write record into a file.
         * @param outputFileWriter a BufferedWriter object.
         * @param recordString a string.
         */
        private void writeIntoFile(String recordString) {

            try {
                outputFileWriter.flush();
                outputFileWriter.write(recordString);
                outputFileWriter.write("\r\n");
            } catch (IOException iOException) {
                // Error in file : %1. (Writing into file)
                throw new RunAbortedException(CustomMessageRepository.ni0026_6ErrorInFile(iOException.getMessage()));
            }
        }

        private List<SQLResultRow> getEligiblePaymentTendersQry(){


            StringBuilder getPayTendersString = new StringBuilder();
            /*
             * Start Change - 2013-05-31 - JPunza
             */
            //getPayTendersString.append("SELECT TNDR.PAY_EVENT_ID, TNDR.MICR_ID, EVNT.PAY_DT , SUBSTR(TNDR.CUST_ID,-10 ) AGCY_ACCT_ID, TNDR.TENDER_AMT, TNDRCTL.TNDR_SOURCE_CD FUND_TYPE ");
            getPayTendersString.append("SELECT TNDR.PAY_EVENT_ID, TNDR.MICR_ID, EVNT.PAY_DT , SUBSTR(TRIM(TNDR.CUST_ID),-10,10) AGCY_ACCT_ID, TNDR.TENDER_AMT, TNDRCTL.TNDR_SOURCE_CD FUND_TYPE ");
            /*
             * End Change - 2013-05-31 - JPunza
             */
            getPayTendersString.append("FROM CI_WFM_OPT OPT ");
            getPayTendersString.append(", CI_PAY_TNDR TNDR ");
            getPayTendersString.append(", CI_TNDR_CTL TNDRCTL ");
            getPayTendersString.append(", CI_SA SA ");
            getPayTendersString.append(", CI_TNDR_SRCE SRC ");
            getPayTendersString.append(", CI_WFM_OPT OPT2 ");
            getPayTendersString.append(", CI_PAY_EVENT EVNT ");
            getPayTendersString.append("WHERE OPT.WFM_NAME= 'SCHEMACONST' ");
            getPayTendersString.append("AND OPT.EXT_OPT_TYPE = :optTypForTndrSrc ");
            getPayTendersString.append("AND TRIM(OPT.WFM_OPT_VAL) = TRIM(TNDRCTL.TNDR_SOURCE_CD) ");
            getPayTendersString.append("AND TNDR.TNDR_CTL_ID = TNDRCTL.TNDR_CTL_ID ");
            getPayTendersString.append("AND TNDR.TNDR_STATUS_FLG = :valid ");
            getPayTendersString.append("AND TNDRCTL.TNDR_SOURCE_CD = SRC.TNDR_SOURCE_CD ");
            getPayTendersString.append("AND SRC.SA_ID = SA.SA_ID ");
            getPayTendersString.append("AND TRIM(SA.SA_TYPE_CD) = TRIM(OPT2.WFM_OPT_VAL) ");
            getPayTendersString.append("AND OPT2.WFM_NAME= 'SCHEMACONST' ");
            getPayTendersString.append("AND OPT2.EXT_OPT_TYPE = :optTypForSuspenseSATyp ");
            getPayTendersString.append("AND EVNT.PAY_EVENT_ID = TNDR.PAY_EVENT_ID ");

//Start Changes IM-36265 Mohit
            getPayTendersString.append("AND  EXISTS (SELECT 1 FROM CI_PAY PAY ");
            getPayTendersString.append(",ci_pay_seg payseg ");
            getPayTendersString.append("WHERE PAY.PAY_EVENT_ID = EVNT.PAY_EVENT_ID  ");
            getPayTendersString.append("AND PAY.PAY_STATUS_FLG = 50  ");
            getPayTendersString.append("AND PAY.PAY_ID = PAYSEG.PAY_ID  ");
            getPayTendersString.append("AND PAYSEG.SA_ID = SRC.SA_ID )  ");
//End Changes IM-36265 Mohit

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement payTenderPrepStmt = createPreparedStatement(getPayTendersString.toString());
            PreparedStatement payTenderPrepStmt = createPreparedStatement(getPayTendersString.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            payTenderPrepStmt.bindStringProperty("optTypForTndrSrc", FeatureConfigurationOption.properties.optionType,parmPldgFundType.trim());
            payTenderPrepStmt.bindLookup("valid", TenderStatusLookup.constants.VALID);
            payTenderPrepStmt.bindStringProperty("optTypForSuspenseSATyp", FeatureConfigurationOption.properties.optionType,parmSuspenseSaType.trim());
            List<SQLResultRow> resultList = payTenderPrepStmt.list();
            payTenderPrepStmt.close();
            return resultList;
        }

        /**
         * @return void
         *  This method creates todo.
         *
         */
        // Start Delete - 2020-10-27 - DLampa - B-17434 
        //private void createToDoEntry(String payEventStr, String payeeAcctId, Date payDt){
        //    ToDoEntry_DTO entryDto  = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
            /*
             * Start Change - 2013-05-31 - JPunza
             */
            //ToDoType toDoType = parmTodoTypeInvalPayee.getId().getEntity();
        //    ToDoType toDoType = getParameters().getTO_DO_TYPE_INVAL_PAYEE();
            /*
             * End Change - 2013-05-31 - JPunza
             */
        //    entryDto.setToDoTypeId(toDoType.getId());
        //    entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
            /*
             * Start Delete - 2013-05-31 - JPunza
             */
            //entryDto.setToDoPriority(toDoType.getToDoPriority());
            //entryDto.setToDoRoleId(getDefaultToDoRole().getId());
            /*
             * End Delete - 2013-05-31 - JPunza
             */
        //    entryDto.setCreationDateTime(getProcessDateTime());
            /*
             * Start Delete - 2013-05-31 - JPunza
             */
            //entryDto.setToDoPriority(toDoType.getToDoPriority());
            /*
             * End Delete - 2013-05-31 - JPunza
             */
        //    entryDto.setBatchControlId(getBatchControlId());
        //    entryDto.setBatchNumber(getBatchNumber());

        //    ArrayList<ToDoSortKeyValue_DTO>sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();
        //    ToDoTypeSortKeyTypes sortKeyTypes = toDoType.getSortKeyTypes();

        //    for (Iterator<ToDoSortKeyType> iter = sortKeyTypes.iterator(); iter.hasNext();) {
        //        ToDoSortKeyType sortKeyType = (ToDoSortKeyType) iter.next();
        //        ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
        //        BigInteger seq = sortKeyType.fetchIdSequence();
        //        sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));

        //        if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(1))==0){
        //            sortKeyDto.setKeyValue(payDt.toString());
        //         }
        //        sortKeyList.add(sortKeyDto);
        //    }

        //    ArrayList<ToDoDrillKeyValue_DTO>drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
        //    ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO)     createDTO(ToDoDrillKeyValue.class);
        //    ToDoDrillKeyType drillKeyType = (ToDoDrillKeyType) toDoType.getDrillKeyTypes().iterator().next();
        //    BigInteger sequence = drillKeyType.fetchIdSequence();
        //    drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, sequence));

        //    drillKeyDto.setKeyValue(payEventStr);
        //    drillKeyList.add(drillKeyDto);



        //    MessageCategory_Id msgCatId = new MessageCategory_Id(BigInteger.valueOf(CustomMessageRepository.MESSAGE_CATEGORY));
        //    Message_Id msgId = new Message_Id(msgCatId, BigInteger.valueOf(CustomMessageRepository.NI0026_6_INVALID_PAYEE_ACCT_ID));
        //    entryDto.setMessageId(msgId);


        //    ArrayList <String> messageParameterList = new ArrayList<String> ();
        //    messageParameterList.add(0,payeeAcctId);
        //    messageParameterList.add(1,payEventStr);
        //    ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory.newInstance();

        //    toDoEntryData.setDrillKeys(drillKeyList);
        //    toDoEntryData.setEntryDto(entryDto);
        //    toDoEntryData.setSortKeys(sortKeyList);
        //    toDoEntryData.setMessageParams(messageParameterList);
        //    ArrayList <ToDoEntryCharacteristic_DTO>  charList = new ArrayList<ToDoEntryCharacteristic_DTO> ();
        //    toDoEntryData.setToDoCharacteristics(charList);

        //    ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
        //    toDoProcessor.addToDo(toDoEntryData);

        //}
        // End Delete - 2020-10-27 - DLampa - B-17434 
        /*
         * Start Delete - 2013-05-31 - JPunza
         */
//        /**
//         * @return Role
//         * This method fetches the Default Role to create a TODO
//         *
//         */
//        private Role getDefaultToDoRole(){
//            Role defaultRole = null;
//            StringBuilder defaultRoleQueryString = new StringBuilder();
//            defaultRoleQueryString.append("SELECT ROLE_ID FROM CI_TD_VAL_ROLE WHERE TD_TYPE_CD = :toDoType AND DEFAULT_SW = :yes ");
//
//            PreparedStatement defaultRolePrepStmt = createPreparedStatement(defaultRoleQueryString.toString());
//            defaultRolePrepStmt.bindId("toDoType", parmTodoTypeInvalPayee.getId());
//            defaultRolePrepStmt.bindBoolean("yes", Bool.TRUE);
//            defaultRole = defaultRolePrepStmt.firstRow().getEntity("ROLE_ID", Role.class);
//            defaultRolePrepStmt.close();
//            return defaultRole;
//        }
        /*
         * End Delete - 2013-05-31 - JPunza
         */
        /**
         * Perform final processing before ending the thread.
         * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted
         * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
         * @see com.splwg.base.api.batch.ThreadWorker#finalizeThreadWork()
         */
        public void finalizeThreadWork()
        throws ThreadAbortedException, RunAbortedException {

            try{
                if(notNull(outputFileWriter)){
                    outputFileWriter.close();
                }
                if(numberOfRecordsProcessed.intValue() == 0){
                    extractFile.delete();

                }
            }catch(IOException iOException){
                // Error in file : %1.(While Closing)
                throw new RunAbortedException(CustomMessageRepository.ni0026_6ErrorInFile(iOException.getMessage()));
            }
        }
    }
}