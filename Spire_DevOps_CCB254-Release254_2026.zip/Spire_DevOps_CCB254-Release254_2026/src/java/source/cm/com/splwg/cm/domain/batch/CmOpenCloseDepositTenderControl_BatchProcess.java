/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NI0019.7 Real Time Payments
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-01-05   Srikanth    NI0019.7. Initial Version.
 * 2013-06-12   CVB         Modified to balance tender and
 *                          Deposit control instead of setting 
 *                          them to Balancing in Progress.
 * 2016-01-29  	MPang		Updated for CCB v2.4 compilation. 
 * 2016-04-04	MPang		Updated to call Cmppbctn.java instead of 
 * 							CobolProgramCMPPBCTN. 
 * 2016-04-04	MPang		Deleted the unused methods, variables.
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.
 * 2025-11-14   EQuint      CCB25.4 Upgrade
 **************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.api.lookup.DepositControlStatusLookup;
import com.splwg.ccb.api.lookup.TenderControlStagingStatusLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.tenderSource.TenderSource;
import com.splwg.ccb.domain.payment.depositControl.DepositControl;
import com.splwg.ccb.domain.payment.depositControl.DepositControl_DTO;
import com.splwg.ccb.domain.payment.depositControl.DepositControl_Id;
import com.splwg.ccb.domain.payment.tenderControl.TenderControl;
import com.splwg.ccb.domain.payment.tenderControl.TenderControl_DTO;
import com.splwg.ccb.domain.payment.tenderControl.TenderControl_Id;
import com.splwg.ccb.domain.security.user.User;
import com.splwg.cm.domain.payment.tenderControl.CobolCopybookCMCPBCTN;
import com.splwg.cm.domain.payment.tenderControl.CobolProgramCMPPBCTN;*/
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource;
import com.splwg.ccb.domain.payment.depositControl.entity.DepositControl;
import com.splwg.ccb.domain.payment.depositControl.entity.DepositControl_DTO;
//Start Delete - 2016-04-04 - MPang - Deleted the unused methods and variables.
//import com.splwg.ccb.domain.payment.depositControl.entity.DepositControl_Id;
//End Delete - 2016-04-04 - MPang - Deleted the unused methods and variables.
import com.splwg.ccb.domain.payment.tenderControl.entity.TenderControl;
import com.splwg.ccb.domain.payment.tenderControl.entity.TenderControl_DTO;
import com.splwg.ccb.domain.payment.tenderControl.entity.TenderControl_Id;
import com.splwg.ccb.domain.security.user.entity.User;

//Start Delete - 2016-04-04 - MPang - Updated to call Cmppbctn.java
//import com.splwg.cm.cobol.cm.CobolCopybookCMCPBCTN;
//import com.splwg.cm.cobol.cm.CobolProgramCMPPBCTN;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
//End Delete - 2016-04-04 - MPang - Updated to call Cmppbctn.java

import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmppbctn;

/**
 * @author sdesabhatl002
 *
 @BatchJob (multiThreaded = false, 
 *      rerunnable = false, 
 *      modules={},
 *      softParameters = { @BatchJobSoftParameter (entityName = user, name = USER_ID, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = tenderSource, name = TNDR_SOURCE_CD, required = true, type = entity)})
 */
public class CmOpenCloseDepositTenderControl_BatchProcess extends
CmOpenCloseDepositTenderControl_BatchProcess_Gen {

	// Soft Parameters
	private static TenderSource parmTenderSource;
	private static User parmUser;
	//Start Add - 2016-04-04 - MPang - Updated to call Cmppbctn.java
	//Constants
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";

	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";

	//End Add - 2016-04-04 - MPang - Updated to call Cmppbctn.java
	
	public JobWork getJobWork() {
		ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
		arrayList.add(threadWorkUnit);

		return createJobWorkForThreadWorkUnitList(arrayList);

	}

	public Class<CmOpenCloseDepositTenderControl_BatchProcessWorker> getThreadWorkerClass() {
		return CmOpenCloseDepositTenderControl_BatchProcessWorker.class;
	}

	public void validateSoftParameters(boolean isValid){
		// Get all parameter value
		parmTenderSource = getParameters().getTNDR_SOURCE_CD();
		parmUser = getParameters().getUSER_ID();
	}

	public static class CmOpenCloseDepositTenderControl_BatchProcessWorker
	extends	CmOpenCloseDepositTenderControl_BatchProcessWorker_Gen {

		private static final String CREATED_BY = "Created by ";
		//Start Delete - 2016-04-04 - MPang - Deleted the unused methods and variables.
		//private static final String DEPOSIT_CTRL_ID = "depositCtrlId";
		//End Delete - 2016-04-04 - MPang - Deleted the unused methods and variables.
		private static final String TENDER_CTRL_ID = "tenderCtrlId";
		private DepositControl depositCtrl = null;
		private TenderControl tndrCtrl = null;

		//Start Add - 2016-04-04 - MPang - Updated to call Cmppbctn.java
		//Work Variable
		Cmppbctn cmppbctn;
		//End Add - 2016-04-04 - MPang - Updated to call Cmppbctn.java

		private Connection connection;
		/**
		 * This method identifies the execution strategy to be used for the thread.
		 * 
		 * @return an instance of ThreadExecutionStrategy that governs how this ThreadWorker will be executed at runtime.
		 * @see com.splwg.base.api.batch.ThreadWorker#createExecutionStrategy()
		 */

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		/**
		 * Execute a WorkUnit and provide result details.
		 * 
		 * @param unit - a ThreadWorkUnit
		 * @return a boolean that describes the success or failure of the work unit processing.
		 * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
		 * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
		 * This work unit creates the Field Activity.
		 */

		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			WorkUnitResult workUnitResult = new WorkUnitResult(true);
			workUnitResult.setUnitsInError(BigInteger.ZERO.intValue());

			createDepositControl();
			createTenderControl();
			updateDepositControlUser();

			BigInteger noOfRecordsUpdated = updateExistingDepositAndTenderControls();
			logMessage(CustomMessageRepository.ni0019_7NumberOfRecordsProcessed(noOfRecordsUpdated),MessageSeverityLookup.constants.INFORMATIONAL);
			workUnitResult.setUnitsProcessed(BigInteger.ONE.intValue());
			return workUnitResult;
		}

		//Start Add - 2016-04-04 - MPang - Updated to call Cmppbctn.java
		@Override
		public void initializeThreadWork(boolean flag)
				throws ThreadAbortedException, RunAbortedException {

			parmTenderSource = getParameters().getTNDR_SOURCE_CD();
			parmUser = getParameters().getUSER_ID();

			try {
				// initialize program
				initializeCobolProgram();
			}
			catch(Exception err) {
				addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), err.toString()));
			} 	
		}
		//End Add - 2016-04-04 - MPang - Updated to call Cmppbctn.java

		private void createDepositControl(){
			startChanges();
			DepositControl_DTO depCtrlDto = (DepositControl_DTO) createDTO(DepositControl.class); 
			depCtrlDto.setDepositControlStatus(DepositControlStatusLookup.constants.OPEN);
			depCtrlDto.setTenderSourceType(parmTenderSource.getTenderSourceType());
			depCtrlDto.setCurrencyId(parmTenderSource.getCurrency().getId());
			depCtrlDto.setUserId(parmUser.getId());
			depCtrlDto.setCreationDateTime(getProcessDateTime());
			depCtrlDto.setComments(CREATED_BY + getBatchControlId().getTrimmedValue());
			depositCtrl = depCtrlDto.newEntity();
			saveChanges();
		}

		private void createTenderControl(){
			startChanges();
			TenderControl_DTO tndrCtrlDto = (TenderControl_DTO) createDTO(TenderControl.class);
			tndrCtrlDto.setTenderControlStagingStatus(TenderControlStagingStatusLookup.constants.OPEN);
			tndrCtrlDto.setBatchControlId(getBatchControlId());
			tndrCtrlDto.setBatchNumber(getBatchNumber());
			tndrCtrlDto.setCurrencyId(parmTenderSource.getCurrency().getId());
			tndrCtrlDto.setTenderSourceId(parmTenderSource.getId());
			tndrCtrlDto.setUserId(parmUser.getId());
			tndrCtrlDto.setCreationDateTime(getProcessDateTime());
			tndrCtrlDto.setDepositControlId(depositCtrl.getId());
			tndrCtrlDto.setIsAllUsers(Bool.FALSE);
			tndrCtrlDto.setIsArchived(Bool.FALSE);
			tndrCtrlDto.setComments(CREATED_BY + getBatchControlId().getTrimmedValue());
			tndrCtrl = tndrCtrlDto.newEntity();
			saveChanges();
		}

		private void updateDepositControlUser(){
			StringBuilder updDepCtrlStr = new StringBuilder();
			updDepCtrlStr.append("UPDATE CI_DEP_CTL SET USER_ID=:userId ");
			updDepCtrlStr.append("WHERE DEP_CTL_ID =:depCtrlId");

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement updDepCtrlPrepStmt = createPreparedStatement(updDepCtrlStr.toString());
			PreparedStatement updDepCtrlPrepStmt = createPreparedStatement(updDepCtrlStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			updDepCtrlPrepStmt.bindId("userId", parmUser.getId());
			updDepCtrlPrepStmt.bindId("depCtrlId", depositCtrl.getId());
			updDepCtrlPrepStmt.executeUpdate();
			updDepCtrlPrepStmt.close();
		}
		private BigInteger updateExistingDepositAndTenderControls(){

			// Retrieving list of existing Deposit Control - Tender Control Pairs which  
			List<QueryResultRow> existingDepTndrCtrlList = retrieveExistingDepAndTndrCrtlStatus(); 
			if(existingDepTndrCtrlList.isEmpty()){
				return BigInteger.ZERO;
			}
			startChanges();
			for(QueryResultRow resultRow: existingDepTndrCtrlList){

				// CVB - 2013-06-12 - Start
				// DepositControl_Id depositCtrlId = (DepositControl_Id) resultRow.get(DEPOSIT_CTRL_ID);
				// CVB - 2013-06-12 - End
				TenderControl_Id tenderCtrlId = (TenderControl_Id) resultRow.get(TENDER_CTRL_ID);

				// Updating the Existing Deposit Control in Open status to Balancing In Progress status
				// CVB - 2013-06-12 - Start
				// updateExistingDepositControlStatus(depositCtrlId);

				// Updating the Existing Tender Control in Open status to Balancing In Progress status 
				// updateExistingTenderControlStatus(tenderCtrlId);

				//Start Delete - 2016-04-04 - MPang - Updated to call Cmppbctn.java
				//CobolProgramCMPPBCTN cobolCMPPBCTN = (CobolProgramCMPPBCTN) getDynamicComponent(CobolProgramCMPPBCTN.class);
				//CobolCopybookCMCPBCTN pbctn = cobolCMPPBCTN.getCobolCopybookCMCPBCTN();

				//pbctn.get_INPUT_WRK().set_TNDR_CTL_ID(tenderCtrlId.getTrimmedValue());
				//cobolCMPPBCTN.callCobol();
				// CVB - 2013-06-12 - End
				//End Delete - 2016-04-04 - MPang - Updated to call Cmppbctn.java

				//Start Add - 2016-04-04 - MPang - Updated to call Cmppbctn.java
				cmppbctn.setProgramStatus(" ");
				cmppbctn.setMessageNbr(BigDecimal.ZERO);
				cmppbctn.setZmsgnMessageCatNbr(BigDecimal.ZERO);
				
				cmppbctn.setInputWrkTndrCtlId(tenderCtrlId.getTrimmedValue());
				// log an error in batch run tree
				try {
					// initialize program
					callCobol();
				} catch(Exception err) {
					logError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), err.toString()));
					//Continue to the next record if there was an error
					//return true;
				}
				//End Add - 2016-04-04 - MPang - Updated to call Cmppbctn.java

			}
			saveChanges();
			return BigInteger.valueOf(existingDepTndrCtrlList.size());
		}

		private List<QueryResultRow> retrieveExistingDepAndTndrCrtlStatus(){
			StringBuilder depAndTndrCtrlRetrievalHql = new StringBuilder();
			depAndTndrCtrlRetrievalHql.append("from DepositControl dc, TenderControl tc ");
			depAndTndrCtrlRetrievalHql.append("where dc.id = tc.depositControl ");
			depAndTndrCtrlRetrievalHql.append("and dc.tenderSourceType = :tenderSourceType ");
			depAndTndrCtrlRetrievalHql.append("and dc.depositControlStatus = :OpenStatusDC ");
			depAndTndrCtrlRetrievalHql.append("and dc.id <> :currentDepCtrlId ");
			// CVB - 2013-06-12 - Start
			depAndTndrCtrlRetrievalHql.append("and dc.userId = :userId ");
			// CVB - 2013-06-12 - End
			depAndTndrCtrlRetrievalHql.append("and tc.tenderSource = :inputTenderSource ");
			depAndTndrCtrlRetrievalHql.append("and tc.tenderControlStagingStatus = :OpenStatusTC ");
			depAndTndrCtrlRetrievalHql.append("and tc.id <> :currentTndrCtrlId ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//Query<QueryResultRow> depAndTndrCtrlRetrievalQuery = createQuery(depAndTndrCtrlRetrievalHql.toString());
			Query<QueryResultRow> depAndTndrCtrlRetrievalQuery = createQuery(depAndTndrCtrlRetrievalHql.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			depAndTndrCtrlRetrievalQuery.bindLookup("tenderSourceType", parmTenderSource.getTenderSourceType());
			depAndTndrCtrlRetrievalQuery.bindLookup("OpenStatusDC", DepositControlStatusLookup.constants.OPEN);
			depAndTndrCtrlRetrievalQuery.bindId("currentDepCtrlId", depositCtrl.getId());
			// CVB - 2013-06-12 - Start
			depAndTndrCtrlRetrievalQuery.bindId("userId", parmUser.getId());
			// CVB - 2013-06-12 - End
			depAndTndrCtrlRetrievalQuery.bindId("inputTenderSource", parmTenderSource.getId());
			depAndTndrCtrlRetrievalQuery.bindLookup("OpenStatusTC", TenderControlStagingStatusLookup.constants.OPEN);
			depAndTndrCtrlRetrievalQuery.bindId("currentTndrCtrlId", tndrCtrl.getId());
			depAndTndrCtrlRetrievalQuery.addResult("depositCtrlId", "dc.id");
			depAndTndrCtrlRetrievalQuery.addResult("tenderCtrlId", "tc.id");
			return depAndTndrCtrlRetrievalQuery.list();
		}
		//Start Delete - 2016-04-04 - MPang - Deleted the unused methods and variables.
		/*private void updateExistingDepositControlStatus(DepositControl_Id depCtrlId){
			StringBuilder updDepCtrlStatusStr = new StringBuilder();
			updDepCtrlStatusStr.append("UPDATE CI_DEP_CTL SET DEP_CTL_STATUS_FLG=:status ");
			updDepCtrlStatusStr.append("WHERE DEP_CTL_ID =:depCtrlId");

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement updDepCtrlStatusPS = createPreparedStatement(updDepCtrlStatusStr.toString());
			PreparedStatement updDepCtrlStatusPS = createPreparedStatement(updDepCtrlStatusStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			updDepCtrlStatusPS.bindLookup("status", DepositControlStatusLookup.constants.BALANCING_IN_PROGRESS);
			updDepCtrlStatusPS.bindId("depCtrlId", depCtrlId);
			updDepCtrlStatusPS.executeUpdate();
			updDepCtrlStatusPS.close();
		}*/
		//End Delete - 2016-04-04 - MPang - Deleted the unused methods and variables.

		//Start Delete - 2016-04-04 - MPang - Deleted the unused methods and variables.
		/*private void updateExistingTenderControlStatus(TenderControl_Id tndrCtlId){
			StringBuilder updTndrCtrlStatusStr = new StringBuilder();
			updTndrCtrlStatusStr.append("UPDATE CI_TNDR_CTL SET TNDR_CTL_ST_FLG = :status ");
			updTndrCtrlStatusStr.append("WHERE TNDR_CTL_ID =:tndrCtlId");

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement updTndrCtrlStatusPS = createPreparedStatement(updTndrCtrlStatusStr.toString());
			PreparedStatement updTndrCtrlStatusPS = createPreparedStatement(updTndrCtrlStatusStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			updTndrCtrlStatusPS.bindLookup("status", TenderControlStagingStatusLookup.constants.BALANCING_IN_PROGRESS);
			updTndrCtrlStatusPS.bindId("tndrCtlId", tndrCtlId);
			updTndrCtrlStatusPS.executeUpdate();
			updTndrCtrlStatusPS.close();
		}*/
		//End Delete - 2016-04-04 - MPang - Deleted the unused methods and variables.

		//Start Add - 12/19/2016
		@Override
		public void finalizeThreadWork() throws ThreadAbortedException,
		RunAbortedException {
			// start update - equint - 2025-11-14 - CCB25.4 Upgrade
			cmppbctn=Session.returnSessionAndCodeToCache(cmppbctn);
//			try {
//				cmppbctn=Session.returnSessionAndCodeToCache(cmppbctn);
//				connection.close();
//			} catch(SQLException se) {
//				addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getIdValue(), se.getMessage()));
//			}
			// end update - equint - 2025-11-14 - CCB25.4 Upgrade
		}
		//End add - 12/19/2016
		
		//Start Add - 2016-04-04 - MPang - Updated to call Cmppbctn.java
		/*
		 * Initialize cobol program
		 */
		@SuppressWarnings("deprecation")
		private void initializeCobolProgram() throws Exception {
			FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
			RequestContext context = session.getRequestContext();
			
			// start update - equint - 2025-11-14 - CCB25.4 Upgrade
      		session.doWork(new ConnectionWork() {
      			
      			@Override
      			public void execute(Connection connection) throws SQLException {
      				try {  
      					
      					String username = connection.getMetaData().getUserName();
      					String url = connection.getMetaData().getURL();

      					CobolSession.setLogSessionStartEnd(false);
      					cmppbctn=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url), Cmppbctn.class);

      					cmppbctn.getSession().getDbSession().setUpdateConnection(connection);
      					cmppbctn.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");

      					// set ZSTAT parameters

      					cmppbctn.setProcessDt(getProcessDateTime().getDate().toString());
      					cmppbctn.setProcessDttmSep("-");
      					cmppbctn.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");

      					if (session.isOnlineConnection()) { 
      						cmppbctn.setConnectionFlg(CONNECTION_ONLINE);
      					}
      					else {
      						cmppbctn.setConnectionFlg(CONNECTION_BATCH);
      					}

      					cmppbctn.setZstatUserId(context.getUserId()); 
      					cmppbctn.setZstatLanguageCd(context.getLanguageCode());

      					if (context.ignoreWarnings()) {
      						cmppbctn.setIgnoreWarningSw(SWITCH_YES);
      					}
      					else {
      						cmppbctn.setIgnoreWarningSw(SWITCH_NO);
      					}

      					if (session.getBatchInstanceId() != null) {
      						cmppbctn.setZstatSchedulerId(new BigDecimal(session.getBatchInstanceId()));
      						cmppbctn.setSchedulerId(new BigDecimal(session.getBatchInstanceId()));

      					} else {
      						cmppbctn.setZstatSchedulerId(new BigDecimal(0));
      						cmppbctn.setSchedulerId(new BigDecimal(0));
      					}

      					cmppbctn.setAppSvcId(context.getSecurityServiceIdContext());

      					DatabaseHelper dbHelper = session.getDatabaseHelper();
      					cmppbctn.setDbMode(dbHelper.getCobolDBMode());
      					// CCB v2.6 Upgrade - 2018-05-31 - Start Change
      					//cmppbctn.setSplHighValue(cmppbctn.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
      					//cmppbctn.setSplLowValue(cmppbctn.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
      					
      					cmppbctn.setSplHighValue(cmppbctn.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
      		            cmppbctn.setSplLowValue(cmppbctn.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
      					// CCB v2.6 Upgrade - 2018-05-31 - End Change

      					cmppbctn.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()));
      					cmppbctn.setLkExpiryDt(Date.MAX.toString());
      					cmppbctn.setProgramStatus(" ");
      					
      					// CCB v2.6 Upgrade - 2018-08-02 - Start Add
      			        cmppbctn.setCallSeq(";");
      			        cmppbctn.setMessageAreaProgramName("CMPBBCTN");
      			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
      					
      					if (context.getRandomGeneratorSeedSet().isTrue()) {
      						cmppbctn.setRandomGenSeedSw(SWITCH_YES);
      						cmppbctn.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()));
      						cmppbctn.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()));
      						cmppbctn.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()));
      						cmppbctn.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()));
      					}
      					else {
      						cmppbctn.setRandomGenSeedSw(SWITCH_NO);
      					}

      					if (context.traceStandardOut()) { 
      						cmppbctn.setTrcStdoutSw(SWITCH_YES);
      					}
      					else {
      						cmppbctn.setTrcStdoutSw(SWITCH_NO);
      					}

      					if (context.traceProgramStart()) { 
      						cmppbctn.setTrcProgStartSw(SWITCH_YES);
      					}
      					else {
      						cmppbctn.setTrcProgStartSw(SWITCH_NO);
      					}

      					if (context.traceProgramExit()) { 
      						cmppbctn.setTrcProgExitSw(SWITCH_YES);
      					}
      					else {
      						cmppbctn.setTrcProgExitSw(SWITCH_NO);
      					}

      					if (context.traceSQL()) { 
      						cmppbctn.setTrcExecSqlSw(SWITCH_YES);
      					}
      					else {
      						cmppbctn.setTrcExecSqlSw(SWITCH_NO);
      					} 
      				}
      				catch(Exception e) {
    					throw new SQLException(e.getCause());
    				}
    				
    			}
    		});

//			SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//			//Start Change - 12/19/2016
//			//Connection connection = implementor.getConnectionProvider().getConnection();
//			connection = implementor.getConnectionProvider().getConnection();
//			//End Change - 12/19/2016
//			String username = connection.getMetaData().getUserName();
//			String url = connection.getMetaData().getURL();
//
//			CobolSession.setLogSessionStartEnd(false);
//			cmppbctn=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url), Cmppbctn.class);
//
//			cmppbctn.getSession().getDbSession().setUpdateConnection(connection);
//			cmppbctn.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//
//			// set ZSTAT parameters
//
//			cmppbctn.setProcessDt(getProcessDateTime().getDate().toString());
//			cmppbctn.setProcessDttmSep("-");
//			cmppbctn.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//
//			if (session.isOnlineConnection()) { 
//				cmppbctn.setConnectionFlg(CONNECTION_ONLINE);
//			}
//			else {
//				cmppbctn.setConnectionFlg(CONNECTION_BATCH);
//			}
//
//			cmppbctn.setZstatUserId(context.getUserId()); 
//			cmppbctn.setZstatLanguageCd(context.getLanguageCode());
//
//			if (context.ignoreWarnings()) {
//				cmppbctn.setIgnoreWarningSw(SWITCH_YES);
//			}
//			else {
//				cmppbctn.setIgnoreWarningSw(SWITCH_NO);
//			}
//
//			if (session.getBatchInstanceId() != null) {
//				cmppbctn.setZstatSchedulerId(new BigDecimal(session.getBatchInstanceId()));
//				cmppbctn.setSchedulerId(new BigDecimal(session.getBatchInstanceId()));
//
//			} else {
//				cmppbctn.setZstatSchedulerId(new BigDecimal(0));
//				cmppbctn.setSchedulerId(new BigDecimal(0));
//			}
//
//			cmppbctn.setAppSvcId(context.getSecurityServiceIdContext());
//
//			DatabaseHelper dbHelper = session.getDatabaseHelper();
//			cmppbctn.setDbMode(dbHelper.getCobolDBMode());
//			// CCB v2.6 Upgrade - 2018-05-31 - Start Change
//			//cmppbctn.setSplHighValue(cmppbctn.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//			//cmppbctn.setSplLowValue(cmppbctn.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//			
//			cmppbctn.setSplHighValue(cmppbctn.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//            cmppbctn.setSplLowValue(cmppbctn.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//			// CCB v2.6 Upgrade - 2018-05-31 - End Change
//
//			cmppbctn.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()));
//			cmppbctn.setLkExpiryDt(Date.MAX.toString());
//			cmppbctn.setProgramStatus(" ");
//			
//			// CCB v2.6 Upgrade - 2018-08-02 - Start Add
//	        cmppbctn.setCallSeq(";");
//	        cmppbctn.setMessageAreaProgramName("CMPBBCTN");
//	        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//			
//			if (context.getRandomGeneratorSeedSet().isTrue()) {
//				cmppbctn.setRandomGenSeedSw(SWITCH_YES);
//				cmppbctn.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()));
//				cmppbctn.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()));
//				cmppbctn.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()));
//				cmppbctn.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()));
//			}
//			else {
//				cmppbctn.setRandomGenSeedSw(SWITCH_NO);
//			}
//
//			if (context.traceStandardOut()) { 
//				cmppbctn.setTrcStdoutSw(SWITCH_YES);
//			}
//			else {
//				cmppbctn.setTrcStdoutSw(SWITCH_NO);
//			}
//
//			if (context.traceProgramStart()) { 
//				cmppbctn.setTrcProgStartSw(SWITCH_YES);
//			}
//			else {
//				cmppbctn.setTrcProgStartSw(SWITCH_NO);
//			}
//
//			if (context.traceProgramExit()) { 
//				cmppbctn.setTrcProgExitSw(SWITCH_YES);
//			}
//			else {
//				cmppbctn.setTrcProgExitSw(SWITCH_NO);
//			}
//
//			if (context.traceSQL()) { 
//				cmppbctn.setTrcExecSqlSw(SWITCH_YES);
//			}
//			else {
//				cmppbctn.setTrcExecSqlSw(SWITCH_NO);
//			} 
      		
      	// end update - equint - 2025-11-14 - CCB25.4 Upgrade

		}
		//End Add - 2016-04-04 - MPang - Updated to call Cmppbctn.java

		//Start Add - 2016-04-04 - MPang - Updated to call Cmppbctn.java
		private void callCobol() {
			try {
				cmppbctn.cobolMain();
			}catch(Exception _ex) {
				Throwable ex=_ex;
				while(ex.getCause()!=null) ex=ex.getCause();
				if(ex instanceof Stop) {
					// if message number and category are not 0, meaning a server message is passed from the jacob code
					if (cmppbctn.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
							&& cmppbctn.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {

						// pass the parameter to the server message
						MessageParameters messageparameters = new MessageParameters();
						for (int i = 1; i <= 9; i++) {
							try { 
								String parmValue = cmppbctn.getMessageParm(i);
								if (notBlank(parmValue)) {
									messageparameters.addRawString(parmValue.trim());
								}
							}
							catch(IndexOutOfBounds e) {
								break;
							}

						}
						MessageCategory_Id categoryId = new MessageCategory_Id(cmppbctn.getZmsgnMessageCatNbr().toBigInteger());
						ServerMessage serverMessage = 
								ServerMessageFactory.Factory.newInstance().createMessage(
										categoryId, cmppbctn.getMessageNbr().intValue(), messageparameters);

						// check the message severity so we'll know what type of message to raise

						// info
						if (cmppbctn.getMessageSeverity().compareTo(
								MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
							logInfo(serverMessage);
						}
						// warning
						else if (cmppbctn.getMessageSeverity().compareTo(
								MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
							logWarning(serverMessage);
						}
						// error
						else {
							logError(serverMessage);
						}
					}
				}
				else  {
					//Start Add - 12/19/2016
					ex.printStackTrace();
					//End Add - 12/19/2016
					addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), _ex.toString()));
				}
			}

		}

		//End Add - 2016-04-04 - MPang - Updated to call Cmppbctn.java
	}

}
