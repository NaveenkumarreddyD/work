/*
 **************************************************************************
 *                Confidentiality Information:                    
 *                                                                
 * This module is the confidential and proprietary information of 
 * Oracle Corporation; it is not to be copied, reproduced, or         
 * transmitted in any form, by any means, in whole or in part,    
 * nor is it to be used for any purpose other than that for which 
 * it is expressly provided without the written permission of     
 * Oracle Corporation.                                                
 *                                                                
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Record Layout for Bad Debt Extract Record 
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2012-11-15   BCordo  NI006.3. Initial Version.   
 * 2013-05-13   CVB     Enclosed in quotes the first field   
 * 2014-09-24	DHuynh	MGE-CCB007
 * 						-Added method for CIS Division output column for 
 *                      differentiating between MGE and LGC
 * 					    - Updated method for Town Code output  
 *                      column to accomodate up to 16 characters.
 **************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

/**
 * @author 95223
 */
public class CmBadDebtExtractRecord extends ColumnDelimitedRecord{
    
    private static final String DELIMITER1 = ",\"";
    private static final String DELIMITER2 = "\",\"";
    private static final String DELIMITER3 = "\"";
    
    public CmBadDebtExtractRecord() {
    // Start Change - DHuynh - 2014-09-22 - MGE-CCB007
	//  super(31);
        super(33);
    // End Change - DHuynh - 2014-09-22 - MGE-CCB007
    }
    
    // CVB - 2013-05-13 - Start
    
    public void cmSetDelimiter0() {
        this.rightPadColumn(1, DELIMITER3.length(), DELIMITER3);
    }
    
    public void cmSetRecordType(String recordType) {
        this.rightPadColumn(2, 1, cmTruncateString(recordType, 1));
    }
    
    //public void cmSetDelimiter1() {
    //    this.rightPadColumn(2, DELIMITER1.length(), DELIMITER1);
    //}
    
    public void cmSetDelimiter1() {
        this.rightPadColumn(3, DELIMITER2.length(), DELIMITER2);
    }
    
    
    // CVB - 2013-05-13 - End
        
    
    public void cmSetCDate(String cDate) {
        this.rightPadColumn(4, 6, cmTruncateString(cDate, 6));
    }
    
    public void cmSetDelimiter2() {
        this.rightPadColumn(5, DELIMITER2.length(), DELIMITER2);
    }
    
    public void cmSetFDate(String fDate) {
        this.rightPadColumn(6, 6, cmTruncateString(fDate, 6));
    }
    
    public void cmSetDelimiter3() {
        this.rightPadColumn(7, DELIMITER2.length(), DELIMITER2);
    }
    
    public void cmSetTownCode(String townCode) {
    // Start Change - DHuynh - 2014-09-22 - MGE-CCB007
	//  this.rightPadColumn(8, 3, cmTruncateString(townCode, 3));
        this.rightPadColumn(8, 16, cmTruncateString(townCode, 16));
    }
    // End Change - DHuynh - 2014-09-22 - MGE-CCB007
    
    public void cmSetDelimiter4() {
        this.rightPadColumn(9, DELIMITER2.length(), DELIMITER2);
    }
    
    public void cmSetRevenueClass(String revenueClass) {
        this.rightPadColumn(10, 3, cmTruncateString(revenueClass, 3));
    }  
    
    public void cmSetDelimiter5() {
        this.rightPadColumn(11, DELIMITER2.length(), DELIMITER2);
    }
    
    public void cmSetPremise(String premise) {
        this.rightPadColumn(12, 10, cmTruncateString(premise, 10));
    }
    
    public void cmSetDelimiter6() {
        this.rightPadColumn(13, DELIMITER2.length(), DELIMITER2);
    }
    
    public void cmSetAccount(String account) {
        this.rightPadColumn(14, 10, cmTruncateString(account, 10));
    }
    
    public void cmSetDelimiter7() {
        this.rightPadColumn(15, DELIMITER2.length(), DELIMITER2);
    }
    
    public void cmSetNetRevenue(String netRevenue) {
        this.leftPadColumn(16, 12, cmTruncateString(netRevenue, 12));
    }
    
    public void cmSetDelimiter8() {
        this.rightPadColumn(17, DELIMITER2.length(), DELIMITER2);
    }
    
    public void cmSetStateTax(String stateTax) {
        this.leftPadColumn(18, 12, cmTruncateString(stateTax, 12));
    }
    
    public void cmSetDelimiter9() {
        this.rightPadColumn(19, DELIMITER2.length(), DELIMITER2);
    }
    
    public void cmSetCityTax(String cityTax) {
        this.leftPadColumn(20, 12, cmTruncateString(cityTax, 12));
    }
    
    public void cmSetDelimiter10() {
        this.rightPadColumn(21, DELIMITER2.length(), DELIMITER2);
    }
    
    public void cmSetGrtTax(String grtTax) {
        this.leftPadColumn(22, 12, cmTruncateString(grtTax, 12));
    }
    
    public void cmSetDelimiter11() {
        this.rightPadColumn(23, DELIMITER2.length(), DELIMITER2);
    }
    
    public void cmSetMerch(String merch) {
        this.leftPadColumn(24, 12, cmTruncateString(merch, 12));
    }
    
    public void cmSetDelimiter12() {
        this.rightPadColumn(25, DELIMITER2.length(), DELIMITER2);
    }
    
    public void cmSetRemote(String remote) {
        this.leftPadColumn(26, 12, cmTruncateString(remote, 12));
    }
    
    public void cmSetDelimiter13() {
        this.rightPadColumn(27, DELIMITER2.length(), DELIMITER2);
    }
    
    public void cmSetJobbing(String jobbing) {
        this.leftPadColumn(28, 12, cmTruncateString(jobbing, 12));
    }
    
    public void cmSetDelimiter14() {
        this.rightPadColumn(29, DELIMITER2.length(), DELIMITER2);
    }
    
    public void cmSetInsulation(String insulation) {
        this.leftPadColumn(30, 12, cmTruncateString(insulation, 12));
    }
	
    public void cmSetDelimiter15() {
    // Start Change - DHuynh - 2014-09-22 - MGE-CCB007
	//  this.rightPadColumn(31, DELIMITER3.length(), DELIMITER3);
        this.rightPadColumn(31, DELIMITER2.length(), DELIMITER2);
    // End Change - DHuynh - 2014-09-22 - MGE-CCB007
    }
    // Start Add - DHuynh - 2014-09-22 - MGE-CCB007
    
    public void cmSetCISDivision(String cisDivision) {
        this.rightPadColumn(32, 5, cmTruncateString(cisDivision, 5));
    }
    
    public void cmSetDelimiter16() {
        this.rightPadColumn(33, DELIMITER3.length(), DELIMITER3);
    // End Add - DHuynh - 2014-09-22 - MGE-CCB007
    }
    
    private String cmTruncateString(String string, int maxFieldLength) {
        // If string exceeds allowable record field length, return trimmed substring
        if(string.length() > maxFieldLength) {
            return string.substring(0, maxFieldLength).trim();
        }
        else {
            return string.trim();
        }
    }
 
}
