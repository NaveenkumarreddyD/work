/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Algorithm - Payment Bill Message
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-04-04   RDizon  NM0079. Initial Version.
 * 2013-05-24   SMiran  Defect #1561. Set Allow Bill Reopen to true
 * 2016-01-26   MPang	Updated for CCB v2.4 compilation.
 **************************************************************************/

package com.splwg.cm.domain.admin.serviceAgreementType;

import com.splwg.base.api.Query;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.billMessage.BillMessageType;
import com.splwg.ccb.domain.admin.serviceAgreementType.SaTypeBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.BillData;
import com.splwg.ccb.domain.billing.bill.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.Bill_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.payment.payment.PaymentCharacteristic;*/
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.billCompletion.SaTypeBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.billing.data.BillData;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.payment.payment.entity.PaymentCharacteristic;
//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author redizon
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = billMessageType, name = billMessageCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = paymentCharacteristicType, type = entity)
 *            , @AlgorithmSoftParameter (name = paymentCharacteristicValue, type = string)})
 */
public class CmPaymentBillMessageAlgComp_Impl 
		extends CmPaymentBillMessageAlgComp_Gen 
		implements SaTypeBillCompletionAlgorithmSpot {

    // Soft Parameters
    private BillMessageType parmBillMessageCode; 
    private CharacteristicType parmPaymentCharType;
    private String parmPaymentCharValue;

    // Hard Parameters
    private Date accountingDate;
    private BillData billData;
    private Date billDate;
    private ServiceAgreement serviceAgreement;
    //2013-05-24 SMiran Start
    private Bool shouldAllowBillReopen;
    //2013-05-24 SMiran End

    // Properties
    private Bill_Id billId;

    public Bool getAllowBillReopening() {
        //2013-05-24 SMiran Start
        //return null;
        return shouldAllowBillReopen;
        //2013-05-24 SMiran End
    }

    public BillData getBillData() {
        return billData;
    }

    public Bool getDoMultipleBillingRelationshipsExist() {
        return null;
    }

    public Bool getIsFtProcessAdded() {
        return null;
    }

    public Bool getIsFtTransferred() {
        return null;
    }

    public void setAccountingDate(Date accountingDate) {
        this.accountingDate = accountingDate;
    }

    public void setBillData(BillData billData) {
        this.billData = billData;
    }

    public void setBillDate(Date billDate) {
        this.billDate = billDate;
    }

    public void setServiceAgreement(ServiceAgreement serviceAgreement) {
        this.serviceAgreement = serviceAgreement;
    }

    public void invoke() {
        //2013-05-24 SMiran Start
        shouldAllowBillReopen = Bool.TRUE;
        //2013-05-24 SMiran End
        billId = billData.getBillDTO().getId();

        Query getExistingBillMessage = cmGetExistingBillMessage();
        
        if (getExistingBillMessage.listSize() == 0){
            Query getPaymentOnServiceAgreement = cmGetPaymentOnServiceAgreement(serviceAgreement);
            
            // Create Bill Message if an associated Payment on the Service Agreement exists
            if (getPaymentOnServiceAgreement.listSize() > 0){
                cmCreateBillMessage(parmBillMessageCode);
            }
        }
    }

    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        // Retrieve the Algorithm Parameters
        parmBillMessageCode = getBillMessageCode();
        parmPaymentCharType = getPaymentCharacteristicType();
        parmPaymentCharValue = getPaymentCharacteristicValue();

        if (notNull(parmPaymentCharType) && isNull(parmPaymentCharValue)){
            addError(CustomMessageRepositoryMDC.nm0079_PaymentCharacteristicValueIsRequired());
        }
    }

    /**
     * Create a Bill Message that is of a specific Bill Message Type
     * @param billMessageType BillMessageType
     */
    private void cmCreateBillMessage(BillMessageType billMessageType) {
        billData.getBillDTO().getEntity().getMessages().add(new BillMessage_DTO(), billMessageType.getId());
    }

    /**
     * Get the existing Bill Message
     * @return query Query
     */
    private Query cmGetExistingBillMessage() {
        Query query = createQuery("FROM BillMessage BM "
                + "WHERE BM.id.bill.id = :billId "
              //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
              //  + "AND BM.id.billMessage = :billMessageType");
              + "AND BM.id.billMessage = :billMessageType", getClass().getName());
        	//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        
        query.bindId("billId", billId);
        query.bindId("billMessageType", parmBillMessageCode.getId());
        query.addResult("billMessage", "BM.id.billMessage");

        return query;
    }

    /**
     * Get the Payment on the Service Agreement with the associated Payment Characteristic
     * @param sa ServiceAgreement
     * @return query Query
     */
    private Query cmGetPaymentOnServiceAgreement(ServiceAgreement sa) {
        StringBuilder queryStringBuilder =  new StringBuilder();
        queryStringBuilder.append("FROM FinancialTransaction FT1 ");
        queryStringBuilder.append("WHERE FT1.serviceAgreement = :serviceAgreement ");
        queryStringBuilder.append("AND FT1.financialTransactionType = :paymentFt ");
        queryStringBuilder.append("AND FT1.isFrozen = :frozen ");
        queryStringBuilder.append("AND FT1.billId = ' '");
        queryStringBuilder.append("AND NOT EXISTS (SELECT FT2.id FROM FinancialTransaction FT2 ");
        queryStringBuilder.append("WHERE FT2.parentId = FT1.parentId ");
        queryStringBuilder.append("AND FT2.siblingId = FT1.siblingId ");
        queryStringBuilder.append("AND FT2.financialTransactionType = :paymentCancellationFt) ");
        if (notNull(parmPaymentCharType)){
            queryStringBuilder.append(" AND EXISTS (SELECT PC.id.characteristicType FROM PaymentCharacteristic PC ");
            queryStringBuilder.append("WHERE PC.id.payment = FT1.parentId ");
            queryStringBuilder.append("AND PC.id.characteristicType = :charType ");
            queryStringBuilder.append("AND (PC.characteristicValue = :charValue ");
            queryStringBuilder.append("OR PC.adhocCharacteristicValue = :adhocCharValue ");
            queryStringBuilder.append("OR PC.characteristicValueForeignKey1 = :charValueFk1))");
        }
        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //Query query = createQuery(queryStringBuilder.toString());
        Query query = createQuery(queryStringBuilder.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        query.bindEntity("serviceAgreement", sa);
        query.bindLookup("paymentFt", FinancialTransactionTypeLookup.constants.PAY_SEGMENT);
        query.bindLookup("paymentCancellationFt", FinancialTransactionTypeLookup.constants.PAY_CANCELLATION);
        query.bindBoolean("frozen", Bool.TRUE);
        if (notNull(parmPaymentCharType)){
            query.bindId("charType", parmPaymentCharType.getId());
            query.bindStringProperty("charValue", PaymentCharacteristic.properties.characteristicValue, parmPaymentCharValue);
            query.bindStringProperty("adhocCharValue", PaymentCharacteristic.properties.adhocCharacteristicValue, parmPaymentCharValue);
            query.bindStringProperty("charValueFk1", PaymentCharacteristic.properties.characteristicValueForeignKey1, parmPaymentCharValue);
        }
        query.addResult("ftId", "FT.id");

        return query;
    }
}
