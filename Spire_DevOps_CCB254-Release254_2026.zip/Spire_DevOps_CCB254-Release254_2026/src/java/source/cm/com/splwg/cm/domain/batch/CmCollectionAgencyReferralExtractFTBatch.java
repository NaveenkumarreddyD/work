/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * DebtNext Financial Update File (Conversion Only)
 * 
 * The current PROD collection agency referral extract job (CMCAREXT) does some
 * intense FT lookups to determine the "type" of financial transaction that has occurred on 
 * a bad debt customer's SA(s), i.e. adjustment or payment or if the customer had a quote 
 * or CWR pay arrangement, etc.  For MGE converted referrals, we do not know the FT that 
 * changed the initial referral balance (historic payments and adjustments are not converted
 * to CCB), so all this complex FT logic can be skipped.
 * 
 * We need to create a copy of CMCAREXT that we can run at cutover only to create the 
 * financial updates file for MGE customers.  The following is required:
 * 
 * Copy CMCAREXT and create a new batch control & extract program to be run at cutoff ONLY
 * (CMCARXFT)
 * This extract should behave similar to the "INIT" extract when creating a financialUpdates 
 * file, i.e. get the CHG collection agency referral record, write one record for the account 
 * to the extract (versus one record per SA which is what the PROD extract is currently doing) 
 * and pull details from the referral record.
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2015-08-19   SMiranda        Defect 3290157. Initial Version.
 * 2016-01-27	MPang	 		Updated for CCB v2.4 compilation. 
 ******************************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import com.splwg.base.api.Query;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
/*import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyHistory;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyHistory_Id;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.Premise;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;
import com.splwg.ccb.domain.financial.financialTransaction.FinancialTransaction;
import com.splwg.ccb.domain.financial.financialTransaction.FinancialTransaction_Id;*/
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyHistory;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyHistory_Id;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction_Id;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.

/**
 * @author 90723
 *
 @BatchJob (modules = {}, softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)})
 */

public class CmCollectionAgencyReferralExtractFTBatch 
		extends CmCollectionAgencyReferralExtractFTBatch_Gen {        
        
    //Constants
    private final String PARM_FILE_PATH = "File Path";
    
    @Override
	public void validateSoftParameters(boolean isNewRun) {
        // Validate that File Path is a valid directory
        if (notBlank(getParameters().getFILE_PATH())){
            File tempPath = new File(getParameters().getFILE_PATH());
            if (!tempPath.isDirectory()){
                addError(CustomMessageRepositoryMGE.commBatchParameterIsNotValidFilePath(PARM_FILE_PATH, getParameters().getFILE_PATH()));
            }
        }
	}           
    
    public JobWork getJobWork() {
    	
    	Query<CollectionAgencyHistory_Id> carHistQuery = createQuery(" from CollectionAgencyHistory hist " +
    			"where hist.batchControlId = :batchControlId " +
    			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
    			// "and hist.batchNumber = :batchNumber ");
    			"and hist.batchNumber = :batchNumber ", getClass().getName());
    			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
    	carHistQuery.bindId("batchControlId", this.getBatchControlId());
    	carHistQuery.bindBigInteger("batchNumber", this.getBatchNumber());
    	
    	carHistQuery.addResult("hist", "hist.id");
    	
    	return createJobWorkForEntityIdQuery(carHistQuery);
        
    }

    public Class<CmCollectionAgencyReferralExtractFTBatchWorker> getThreadWorkerClass() {
        return CmCollectionAgencyReferralExtractFTBatchWorker.class;
    }
    
    
    public static class CmCollectionAgencyReferralExtractFTBatchWorker
            extends CmCollectionAgencyReferralExtractFTBatchWorker_Gen {                       
        
        //File  Header Constants
        private final String HDR_ACCT_ID = "\"Account_Id\"";
        private final String HDR_REFERRAL_ID = "\"Referral_Id\"";
        private final String HDR_PREM_ID = "\"Premise_Id\"";
        private final String HDR_CUR_BAL = "\"CurrentBalance\"";
        private final String HDR_AMOUNT = "\"Amount\"";
        private final String HDR_TRANSACTION_DTTM = "\"Transaction_Dttm\"";
        private final String HDR_TRANSACTION_ID = "\"Transaction_Id\"";
        private final String HDR_UPDATE_REASON = "\"Update_Reason\"";
        private final String HDR_EXPORT_DTTM = "\"Export_Date\"";       

        // Constants
        private final String EMPTY_STRING_QUOTE = "\"\"";                      
        private final String COLUMN_SEPERATOR = ",";
        private final String CHG_FILE_EXT = "_FinancialUpdates";
        private DateFormat dateTimeFormat = new DateFormat("yyyy-MM-dd HH:mm:ss");
        private final String UPDATE_REASON = "ADJUST";
        
        // Batch parameters
        private String filePath;
        private String fileName;
        
        // Work variables
        private File extractFile;
        private BufferedWriter extractFileWriter;
        
        @Override
        public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
            
        	// Retrieve parameters
        	filePath = getParameters().getFILE_PATH();
        	fileName = getParameters().getFILE_NAME();            
            
            String strNewFileName = "";
            String strFileNameNoExt = "";
            String strExtension = "";
            
            // Check if the input file name has an extension
            if(fileName.lastIndexOf(".") !=-1){
                strFileNameNoExt = fileName.substring(0, fileName.lastIndexOf("."));
                strExtension  = fileName.substring(fileName.lastIndexOf("."));
            }else{
                strFileNameNoExt = fileName;
                strExtension = ".txt";
            }
            
            // If multi-threaded, append thread numbe to file name
            if (getParameters().getThreadCount().intValue() > 1){
            	strFileNameNoExt = strFileNameNoExt + "_THD" + this.getBatchThreadNumber();
            }
            
            // Append "_FinancialUpdates" to file name
            strNewFileName = strFileNameNoExt + CHG_FILE_EXT + strExtension;            
        	
            // Open Extract File
            try {
            	extractFile = new File(filePath,strNewFileName);   
            	extractFileWriter = new BufferedWriter(new FileWriter(extractFile));     
            }
            catch(Exception e) {
                e.printStackTrace();
                throw new RunAbortedException(CustomMessageRepositoryMGE.commGenericErrorOpeningFile(extractFile.getAbsolutePath()));
            }
            
            // Write Header
            writeFileHeader();           

        }

        private void writeFileHeader() {

            StringBuilder headerLineBuilder = new StringBuilder();
            headerLineBuilder.append(HDR_ACCT_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_REFERRAL_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_PREM_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_CUR_BAL);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_AMOUNT);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_TRANSACTION_DTTM);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_TRANSACTION_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_UPDATE_REASON);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_EXPORT_DTTM);

            writeLineToFile(headerLineBuilder.toString());
			
		}

		public ThreadExecutionStrategy createExecutionStrategy() {
            return new SingleTransactionStrategy(this);
        }

        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {

        	CollectionAgencyHistory_Id carHistId = (CollectionAgencyHistory_Id) unit.getPrimaryId();
        	CollectionAgencyHistory carHist = carHistId.getEntity();
        	
        	String accountIdStr = "";
        	String carIdStr = "";
        	String premiseIdStr = "";
        	Money currentBalance = Money.ZERO;
        	Money amount = Money.ZERO;
        	String transactionDttmStr = "";
        	String transactionIdStr = "";
        	String exportDateTimeStr = getProcessDateTime().toString(dateTimeFormat);
        	
        	// Account_Id - Retrieve from collection agency referral record	        	
        	Account_Id accountId = carHistId.getCollectionReferral().getAccount().getId();
	        accountIdStr = accountId.getTrimmedValue();
	        	
	        // Referral_Id - Retrieve from collection agency referral record
	        CollectionAgencyReferral_Id carId = carHistId.getCollectionReferralId();
	        carIdStr = carId.getTrimmedValue();
	        	
	        // Premise Id - No change to how we're retrieving this - pick one (Get from one of the SA's Char Prem Id)	        	
	        Premise_Id premiseId = getPremiseId(accountId);
	        if (notNull(premiseId)){
	        	premiseIdStr = premiseId.getTrimmedValue();
	        }
	        	
	        // Current_Balance - Set to referral amount associated with the CHG referral record
	        currentBalance = carHist.getReferralAmount();
	        	
	        // Amount - Set to referral amount associated with the CHG referral record
	        amount = carHist.getReferralAmount();
	        	
	        // Transaction_Dttm - Set to creation date associated with the CHG referral record
	        DateTime transactionDttm = getCarHistCredDttm(carHist);
	        if (notNull(transactionDttm)){
	        	transactionDttmStr = transactionDttm.toString(dateTimeFormat);
	        }
	        	
	        // Transaction_Id - Pick a tidy balance FT ID associated with one of the account's SA's:	        	
	        FinancialTransaction_Id ftId = getFtId(accountId);
	        if (notNull(ftId)){
	        	transactionIdStr = ftId.getTrimmedValue();
	        }
	        	
        	// Write to File
	        StringBuilder recordLine = new StringBuilder();
	        recordLine.append(toUpperAndEncloseinQuote(accountIdStr));
	        recordLine.append(COLUMN_SEPERATOR);
	        recordLine.append(toUpperAndEncloseinQuote(carIdStr));
	        recordLine.append(COLUMN_SEPERATOR);
	        recordLine.append(toUpperAndEncloseinQuote(premiseIdStr));
	        recordLine.append(COLUMN_SEPERATOR);
	        recordLine.append(toUpperAndEncloseinQuote(currentBalance.toPlainString()));
	        recordLine.append(COLUMN_SEPERATOR);
	        recordLine.append(toUpperAndEncloseinQuote(amount.toPlainString()));
	        recordLine.append(COLUMN_SEPERATOR);
	        recordLine.append(toUpperAndEncloseinQuote(transactionDttmStr));
	        recordLine.append(COLUMN_SEPERATOR);
	        recordLine.append(toUpperAndEncloseinQuote(transactionIdStr));
	        recordLine.append(COLUMN_SEPERATOR);
	        recordLine.append(toUpperAndEncloseinQuote(UPDATE_REASON));
	        recordLine.append(COLUMN_SEPERATOR);
	        recordLine.append(toUpperAndEncloseinQuote(exportDateTimeStr));
	            
	        writeLineToFile(recordLine.toString());
        	
            return true;
        }        

		private DateTime getCarHistCredDttm(CollectionAgencyHistory carHist) {

			StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");
            stringBuilder.append("	HIS.CRE_DT ");
            stringBuilder.append("FROM ");
            stringBuilder.append("	CI_COLL_AGY_HIS HIS ");
            stringBuilder.append("WHERE ");
            stringBuilder.append("	HIS.COLL_AGY_REF_ID = :carId ");
            stringBuilder.append("	AND HIS.SEQ_NUM = :seqNum ");
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            preparedStatement.bindId("carId", carHist.getId().getCollectionReferralId());
            preparedStatement.bindBigInteger("seqNum", carHist.getId().getSequence());
            SQLResultRow carHistRow = preparedStatement.firstRow();
            preparedStatement.close();            
            
            if (notNull(carHistRow)){
            	DateTime carHistDateTime = carHistRow.getDateTime("CRE_DT");
            	return carHistDateTime;
            }
			
			return null;
		}

		private Premise_Id getPremiseId(Account_Id accountId) {

        	// Get from SA's Char Prem Id
			StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");
            stringBuilder.append("	SA.CHAR_PREM_ID ");
            stringBuilder.append("FROM ");
            stringBuilder.append("	CI_SA SA ");
            stringBuilder.append("WHERE ");
            stringBuilder.append("	SA.SA_ID IN (SELECT SA.SA_ID FROM CI_SA SA WHERE ACCT_ID = :accountId) ");
            stringBuilder.append("	AND SA.CHAR_PREM_ID <> ' ' ");
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            preparedStatement.bindId("accountId", accountId);
            SQLResultRow premIdRow = preparedStatement.firstRow();
            preparedStatement.close();
            
            if (notNull(premIdRow)){
            	Premise_Id premiseId = (Premise_Id)premIdRow.getId("CHAR_PREM_ID", Premise.class);
            	return premiseId;
            }
        	
			return null;
			
		}
		
        private FinancialTransaction_Id getFtId(Account_Id accountId) {

        	// Pick a tidy balance FT ID associated with one of the account's SA's:
			StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");
            stringBuilder.append("	FT.FT_ID ");
            stringBuilder.append("FROM ");
            stringBuilder.append("	CI_FT FT ");
            stringBuilder.append("WHERE ");
            stringBuilder.append("	FT.SA_ID IN (SELECT SA.SA_ID FROM CI_SA SA WHERE ACCT_ID = :accountId) ");
            stringBuilder.append("	AND PARENT_ID IN ('SETCURR','SETPAYOF') ");
            stringBuilder.append("	AND CUR_AMT <> 0 ");
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            preparedStatement.bindId("accountId", accountId);
            SQLResultRow ftIdRow = preparedStatement.firstRow();
            preparedStatement.close();

            if (notNull(ftIdRow)){
            	FinancialTransaction_Id ftId = (FinancialTransaction_Id)ftIdRow.getId("FT_ID", FinancialTransaction.class);
            	return ftId;
            }
        	
			return null;
		}
              
        
        private String toUpperAndEncloseinQuote(String str){
            
            if(!isBlankOrNull(str)){
                str = "\"" + str.trim().toUpperCase() + "\"";
                return str;
            }
            
            return EMPTY_STRING_QUOTE;
            
        }
        
        private void writeLineToFile(String recordLine){       

            try {
            	extractFileWriter.write(recordLine);
            	extractFileWriter.newLine();
            }
            catch (Exception e) {
                e.printStackTrace();
                throw new RunAbortedException(CustomMessageRepositoryMGE.commGenericErrorWritingToFile(extractFile.getAbsolutePath()));
            }
        }
        
        public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException{

            // Close Extract File
            try {
            	extractFileWriter.close();    
            }
            catch(Exception e) {
                e.printStackTrace();
                throw new RunAbortedException(CustomMessageRepositoryMGE.commGenericErrorClosingFile(extractFile.getAbsolutePath()));
            }
        	
        }

    }

}
