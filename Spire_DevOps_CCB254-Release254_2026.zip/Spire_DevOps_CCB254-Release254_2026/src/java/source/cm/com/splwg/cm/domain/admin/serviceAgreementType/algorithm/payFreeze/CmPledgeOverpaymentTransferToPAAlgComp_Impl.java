/**************************************************************************
 * Program Name: CmPledgeOverpaymentTransferToPAAlgComp_Impl
 * Program Title: CmPledgeOverpaymentTransferToPAAlgComp_Impl
 * Author: Gerard Cinco
 * Creation Date: 2017-05-29
 * Purpose: The Algorithm attempts to look for an Active Payment Arrangement 
 *          on the Account in the event a Payment is Frozen on a Pledge 
 *          Overpayment Service Agreement. In the event an Active Payment 
 *          Arrangement is found will perform the following:
 *              1. Transfer up to full amount of Overpayment Credit not 
 *              exceeding the Payment Arrangement Payoff Balance
 *              2. Initiating Stop If PA is paid in full & Adjusting Current 
 *              Balance of Payment Arrangement to $0.00 after transfer
 *              3. Recalculation of Payment Arrangement Recurring Charge Amount if balance 
 *              remains
 *          To Dos will be generated in the event of an error or multiple 
 *          eligible Payment Arrangements are identified.
 *  
 * Functional Spec: FN191784
 **************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 * FN191784           Gerard Cinco     2017-05-29    Initial Version
 * Defect 3793747     Alfonso Castano  2017-07-18    Updated to add a new SA Recurring Charge 
 *                                                   History when Parameter 50 is not populated;
 *                                                   Fixed Adjust Current Balance Adjustment
 *                                                   calculation.
 * Defect 3809657     Aya Masilang     2017-08-02    Update recurring charge calculation and 
 *                                                   checking if the workPledgeSAPayment is null.
 * Defect 3809657     Sharmayne Felipe 2018-09-04    Update recurring charge calculation to use 
 *                                                   the payoff balance and recurring charge from 
 *                                                   the day the PA SA was started.  
 * SysAid# 235562	  Jon Hernandez	   2017-12-01	 Check the active payment arrangement SA's 
 *                                                   balance first before attempting to transfer 
 *                                                   amount from pledge overpayment SA.
 * SysAid# 236254	  Jon Hernandez    2018-05-09	 Fix code portion for zeroing SA Current Balance.                                                    
 * CCB v2.6 Upgrade	  Sarah Romano	   2018-12-13    Merged the changes from Spire PRD version for 
 *  												 the 2.4 to 2.6 Upgrade Activity  
 * Defect 4196429     Sarah Romano	   2019-01-24	 Fix the issue on Adjustment Amount 
 * 													 calculation. 		    
 * SpireOne B-08020   Jamie Lumbre     2019-08-19    Do not create to do in case of multiple PA SA.                                                                                                                                       
 ************************************************************************************************/
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.payFreeze;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
//import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
//import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
//import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
//import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
//import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
//import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.SpecialRoleLookup;
import com.splwg.ccb.api.lookup.StopReasonLookup;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.payFreeze.SaTypePaymentFreezeAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.common.InitiateStopServiceAgreement;
import com.splwg.ccb.domain.customerinfo.common.InitiateStopServiceAgreement_Impl;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementRecurringCharge;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementRecurringCharge_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.ccb.domain.payment.payment.entity.PaymentSegment;
//import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
import com.splwg.cm.api.lookup.CmPledgePaymentsOptionTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author GCinco
 *
 * @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = featureConfiguration, name = pledgePaymentReconFeatureConfiguration, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = transAdjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = setCurBalAdjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = paymentArrangementSATypesToExcludeCalc, required = false, type = string)})
 */

public class CmPledgeOverpaymentTransferToPAAlgComp_Impl 
extends CmPledgeOverpaymentTransferToPAAlgComp_Gen 
implements SaTypePaymentFreezeAlgorithmSpot {

	// Soft Parameters
	private FeatureConfiguration pledgePAFeatureConf;
	private AdjustmentType transferAdjustmentType;
	private AdjustmentType setCurrentBalanceAdjustmentType;
	//private ToDoType errorToDoType;
	private String paymentArrangementSATypes;

	private List<String> excludeSAList;

	@SuppressWarnings("unused")
	private String eligiblePledgeSATypes;
	@SuppressWarnings("unused")
	private FinancialTransaction ft;
	private Payment payment;
	@SuppressWarnings("unused")
	private PaymentSegment paymentSegment;
	private ServiceAgreement sa;
	private ServiceAgreement workPledgeSA;

	private List<String> pledgeSAList;
	private CmMGEFeatureConfigurationOptionsRetriever featConfRetriever;

	private static final String COMMA = ",";
	/*
	 * Defect 3809657 - 2017-08-02 - Start Delete
	 */
	//private static final String BS_PAY_ARRANGEMENT_READ = "C1PayArrangementRead";
	/*
	 * Defect 3809657 - 2017-08-02 - End Delete
	 */
	@Override
	public void invoke() {
		retrieveCollOfEligibleSaTypes();
		// Check if account has pledge SA where SA Type Special Role Flag is PA
		Account workAccount = sa.getAccount();
		//Start Change - 2019-08-19 - JLumbre - SpireOne B-08020
		//int getPledgeSA = pledgeSACount(workAccount);
		//if (getPledgeSA==1){
		Iterator<SQLResultRow> getPledgeSA = getPledgeSACount(workAccount);
		while (getPledgeSA.hasNext()){
			SQLResultRow row = getPledgeSA.next();
			ServiceAgreement_Id saId = (ServiceAgreement_Id) row.getId("SA_ID", ServiceAgreement.class);
			ServiceAgreement tempSA =  saId.getEntity();
			String tempSAType = tempSA.getServiceAgreementType().fetchIdSaType().trim();
			if (pledgeSAList.contains(tempSAType)){
				workPledgeSA = tempSA;               
		
		//End Change - 2019-08-19 - JLumbre - SpireOne B-08020
				// Process Pledge SA. Compare Pledge SA Balance against Overpayment SA Balance
				Money pledgePayoffBal = workPledgeSA.getPayoffBalance();
				// 2019-01-24. SRoman. Defect 4196429. Start Add.
				Money pledgeCurrentBal = workPledgeSA.getCurrentBalance();
				// 2019-01-24. SRoman. Defect 4196429. End Add.
				Money pledgeOverpaymentPayOffBal = sa.getPayoffBalance();            

				// START ADD - JHERNA - 2017-12-01 - SysAid#235562
				// In the event that the Payment Arrangement SA does not have a balance, exit the program
				if (pledgePayoffBal.isEqualTo(Money.ZERO)
						|| pledgeOverpaymentPayOffBal.isEqualTo(Money.ZERO)) {
					return;
				}
				// END ADD - JHERNA - 2017-12-01 - SysAid#235562

				/*
				 * Defect 3809657(Reopen) - 2017-09-04 - Start Add
				 * Added checking if the current Payment Segment made on the PA SA has already been applied.
				 * If not, we have to subtract the Payment Segment amount from the PA SA's current Payoff balance.
				 */
				Money workPledgeSAPayAmount = Money.ZERO;
				ListFilter<PaymentSegment> getWorkPledgeSAPS = payment.getSegments().createFilter(
						"WHERE this.serviceAgreement = :sa ", getClass().getName());
				getWorkPledgeSAPS.bindEntity("sa", workPledgeSA);

				PaymentSegment ps = getWorkPledgeSAPS.firstRow();

				if (notNull(ps)){
					workPledgeSAPayAmount = ps.getPaySegmentAmount();
				}

				Bool isPaySegAppliedtoPASA = Bool.FALSE;
				if (!workPledgeSAPayAmount.isZero()){
					isPaySegAppliedtoPASA = checkPaySegment(workPledgeSA.getId(), workPledgeSAPayAmount);
					if (isPaySegAppliedtoPASA.isFalse()){
						pledgePayoffBal = pledgePayoffBal.subtract(workPledgeSAPayAmount);
						// 2019-01-24. SRoman. Defect 4196429. Start Add.
						pledgeCurrentBal = pledgeCurrentBal.subtract(workPledgeSAPayAmount);
						// 2019-01-24. SRoman. Defect 4196429. End Add.
					}
				}

				// START ADD - JHERNA - 2017-12-01 - SysAid#235562
				// In the event that the Payment Arrangement SA does not have a balance, exit the program
				if (pledgePayoffBal.isEqualTo(Money.ZERO)
						|| pledgeOverpaymentPayOffBal.isEqualTo(Money.ZERO)) {
					return;
				}
				// END ADD - JHERNA - 2017-12-01 - SysAid#235562

				/*
				 * Defect 3809657(Reopen) - 2017-09-04 - End Add
				 */
				// If Pledge Overpayment amount is equal to or greater than Payment Arrangement SA amount
				if (pledgeOverpaymentPayOffBal.negate().isGreaterThanOrEqual(pledgePayoffBal)){

					// Transfer balance of Overpayment SA to Payment Arrangement
					CreateFrozenAdjustmentData frozenAdjustmentData;
					// Transfer amount equal to balance of PA SA.
					frozenAdjustmentData = prepareAdjustmentData(sa, workPledgeSA, transferAdjustmentType, pledgePayoffBal.negate());
					sa.createFrozenAdjustment(frozenAdjustmentData);

					// Create Sync Adjustment
					AdjustmentType syncAdjType = sa.getServiceAgreementType().getAdjustmentTypeSynchCurrentId().getEntity();
					CreateFrozenAdjustmentData syncAdjData = CreateFrozenAdjustmentData.Factory.newInstance();
					syncAdjData.setServiceAgreement(workPledgeSA);                             
					syncAdjData.setAdjustmentType(syncAdjType);                                                                                  
					syncAdjData.setAllowZeroAmount(Bool.FALSE);
					syncAdjData.setAdjustmentDate(getProcessDateTime().getDate());
					sa.createFrozenAdjustment(syncAdjData);

					// Stop payment arrangement SA
					InitiateStopServiceAgreement stopSa = new InitiateStopServiceAgreement_Impl();
					stopSa.initiateStop(workPledgeSA, this.getProcessDateTime().getDate(), null, null, StopReasonLookup.constants.SYSTEM_GENERATED, Bool.FALSE, Bool.FALSE);
				} else {

					/*
					 * Defect 3793747 - 2017-07-18 - Start Add
					 */

					/*
					 * Defect 3809657 - 2017-08-02 - Start Change
					 */
					// Get remaining Installments
					//BigDecimal remainingInstallments = getPAInstallments(workPledgeSA).subtract(BigDecimal.ONE);
					//Retrieve the Work Pledge SA Payoff Balance before any adjustments are done
					Money workPledgePayOff = workPledgeSA.getPayoffBalance();
					/*
					 * Defect 3809657 - 2017-08-02 - End Change
					 */
					// Pledge Overpayment amount is less than Payment Arrangement Payoff Amount
					// Transfer amount from the Pledge Overpayment SA to the Payment Arrangement
					CreateFrozenAdjustmentData frozenAdjustmentData = prepareAdjustmentData(sa, workPledgeSA, transferAdjustmentType, pledgeOverpaymentPayOffBal);
					sa.createFrozenAdjustment(frozenAdjustmentData);
					saveChanges();
					/*
					 * Defect 3809657(Reopen) - 2017-09-04 - Start Delete
					 */
					//Money workPledgeSAPayAmount = Money.ZERO;
					//ListFilter<PaymentSegment> getWorkPledgeSAPS = payment.getSegments().createFilter(
					//        "WHERE this.serviceAgreement = :sa ", getClass().getName());
					//getWorkPledgeSAPS.bindEntity("sa", workPledgeSA);
					//
					//PaymentSegment ps = getWorkPledgeSAPS.firstRow();
					//
					///*
					// * Defect 3809657 - 2017-08-02 - Start Change
					// */
					////if (notNull(getWorkPledgeSAPS)){
					//if (notNull(ps)){
					///*
					// * Defect 3809657 - 2017-08-02 - End Change
					// */   
					//    workPledgeSAPayAmount = ps.getPaySegmentAmount();
					//}
					/*
					 * Defect 3809657(Reopen) - 2017-09-04 - End Delete
					 */

					Money adjustmentAmount = Money.ZERO;
					/*
					 * Defect 3809657(Reopen) - 2017-09-04 - Start Change
					 */
					//Bool isPaySegAppliedtoPASA = Bool.FALSE;
					//if (!workPledgeSAPayAmount.isZero()){
					//    isPaySegAppliedtoPASA = checkPaySegment(workPledgeSA.getId(), workPledgeSAPayAmount);
					//    if (isPaySegAppliedtoPASA.isTrue()){
					//        adjustmentAmount = workPledgeSA.getCurrentBalance().negate();
					//    }else{
					//        adjustmentAmount = workPledgeSA.getCurrentBalance()
					//                .subtract(workPledgeSAPayAmount).negate();
					//    }
					//}

					// 2019-01-24. SRoman. Defect 4196429. Start Delete.
					//if (!workPledgeSAPayAmount.isZero()){
					//    if (isPaySegAppliedtoPASA.isTrue()){
					//        adjustmentAmount = workPledgeSA.getCurrentBalance().negate();
					//    }else{
					//        adjustmentAmount = workPledgeSA.getCurrentBalance()
					//                .subtract(workPledgeSAPayAmount).negate();
					//    }
					//}
					// 2019-01-24. SRoman. Defect 4196429. End Delete.

					/*
					 * Defect 3809657(Reopen) - 2017-09-04 - End Change
					 */

					/*
					 * Defect 3793747 - 2017-07-18 - End Add
					 */
					/*
					 * Defect 3793747 - 2017-07-18 - Start Delete
					 */
					// Get remaining Installments
					//BigDecimal remainingInstallments = getPAInstallments(workPledgeSA).subtract(BigDecimal.ONE);
					// Pledge Overpayment amount is less than Payment Arrangement Payoff Amount
					// Transfer amount from the Pledge Overpayment SA to the Payment Arrangement
					//CreateFrozenAdjustmentData frozenAdjustmentData = prepareAdjustmentData(sa, workPledgeSA, transferAdjustmentType, pledgeOverpaymentPayOffBal);
					//sa.createFrozenAdjustment(frozenAdjustmentData);
					//saveChanges();
					/*
					 * Defect 3793747 - 2017-07-18 - End Delete
					 */
					// Create recurring charge for PA SA if Parameter 5 is provided and PA SA Type is not in the list.
					if (!isNull(paymentArrangementSATypes)){
						String tempSATypeRC = workPledgeSA.getServiceAgreementType().fetchIdSaType().trim();
						if (!excludeSAList.contains(tempSATypeRC)){
							// Compute new recurring charge using original payoff balance on SA as basis
							/*
							 * Defect 3793747 - 2017-07-18 - Start Change
							 */
							//        processPaSaRecurringChargeHistory(workPledgeSA,remainingInstallments);
							//    }
							//}
							/*
							 * Defect 3809657 - 2017-08-02 - Start Change
							 */
							//processPaSaRecurringChargeHistory(workPledgeSA, remainingInstallments, isPaySegAppliedtoPASA, workPledgeSAPayAmount);
							processPaSaRecurringChargeHistory(workPledgeSA, workPledgePayOff, isPaySegAppliedtoPASA, workPledgeSAPayAmount);
							/*
							 * Defect 3809657 - 2017-08-02 - End Change
							 */
						}
					} else {
						// Compute new recurring charge using original payoff balance on SA as basis
						/*
						 * Defect 3809657 - 2017-08-02 - Start Change
						 */

						//processPaSaRecurringChargeHistory(workPledgeSA, remainingInstallments, isPaySegAppliedtoPASA, workPledgeSAPayAmount);
						processPaSaRecurringChargeHistory(workPledgeSA, workPledgePayOff, isPaySegAppliedtoPASA, workPledgeSAPayAmount);
						/*
						 * Defect 3809657 - 2017-08-02 - Start Change
						 */
					}
					/*
					 * Defect 3793747 - 2017-07-18 - End Change
					 */

					/*
					 * Defect 3809657(Reopen) - 2017-09-04 - Start Add
					 */

					// 2019-01-24. SRoman. Defect 4196429. Start Change.
					/* Sum the Pledge SA Current Balance and the Transfer Adjustment 
					 * from PledgOverpayment after processing the payment. 
					 */
					pledgeCurrentBal = pledgeCurrentBal.add(pledgeOverpaymentPayOffBal);
					if(!pledgeCurrentBal.isEqualTo(Money.ZERO)) {
						adjustmentAmount = pledgeCurrentBal.negate();
						/* if(!workPledgeSA.getCurrentBalance().isEqualTo(Money.ZERO)) {             	
                    // START ADD - JHERNA - 2018-06-07 - SysAid#236254
                	// Zero Out Current Balance
                	adjustmentAmount = workPledgeSA.getCurrentBalance().negate();
                    // END ADD - JHERNA - 2018-06-07 - SysAid#236254 */
						// 2019-01-24. SRoman. Defect 4196429. End Change.	

						/*
						 * Defect 3809657(Reopen) - 2017-09-04 - End Add
						 */
						// Create adjustment to zero out balance
						CreateFrozenAdjustmentData zeroBalanceAdj = CreateFrozenAdjustmentData.Factory.newInstance();
						zeroBalanceAdj.setServiceAgreement(workPledgeSA); 
						zeroBalanceAdj.setArrearsDate(getProcessDateTime().getDate());
						/*
						 * Defect 3793747 - 2017-07-18 - Start Change
						 */
						//zeroBalanceAdj.setAdjustmentAmount(workPledgeSA.getCurrentBalance().negate());
						zeroBalanceAdj.setAdjustmentAmount(adjustmentAmount);
						/*
						 * Defect 3793747 - 2017-07-18 - End Change
						 */
						zeroBalanceAdj.setAdjustmentType(setCurrentBalanceAdjustmentType);  
						/*
						 * Defect 3809657 - 2017-08-02 - Start Add
						 */
						if(adjustmentAmount.isZero()){
							zeroBalanceAdj.setAllowZeroAmount(Bool.TRUE);
						} else {
							/*
							 * Defect 3809657 - 2017-08-02 - End Add
							 */
							zeroBalanceAdj.setAllowZeroAmount(Bool.FALSE);    
							/*
							 * Defect 3809657 - 2017-08-02 - Start Add
							 */
						}
						/*
						 * Defect 3809657 - 2017-08-02 - End Add
						 */
						zeroBalanceAdj.setAdjustmentDate(getProcessDateTime().getDate());
						workPledgeSA.createFrozenAdjustment(zeroBalanceAdj);
						/*
						 * Defect 3809657(Reopen) - 2017-09-04 - Start Add
						 */
					}
					/*
					 * Defect 3809657(Reopen) - 2017-09-04 - End Add
					 */
				}
			}
		}
		//Start Delete - 2019-08-19 - JLumbre - SpireOne B-08020
		/*} else if (getPledgeSA > 1){
            // More than one Pledge SA Retrieved on the account. Create ToDo. End algorithm. Do not create any adjustments
            createToDo();
        }*/
		//End Delete - 2019-08-19 - JLumbre - SpireOne B-08020
	}

	public void setFinancialTransaction(FinancialTransaction ft) {
		this.ft = ft;
	}
	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	public void setPaymentSegment(PaymentSegment paymentSegment) {
		this.paymentSegment = paymentSegment;
	}
	public void setServiceAgreement(ServiceAgreement sa) {
		this.sa = sa;
	}
	@Override
	protected void extraSoftParameterValidations(boolean arg0) {
		// Retrieve the Algorithm Parameters
		pledgePAFeatureConf = getPledgePaymentReconFeatureConfiguration();
		transferAdjustmentType = getTransAdjustmentType();
		setCurrentBalanceAdjustmentType = getSetCurBalAdjustmentType();
		//errorToDoType = getToDoType();
		paymentArrangementSATypes = getPaymentArrangementSATypesToExcludeCalc();
		excludeSAList = new ArrayList<String>();

		if (!isNull(paymentArrangementSATypes)){
			StringBuilder stringBuilder = new StringBuilder();      
			stringBuilder.append("SELECT 'X' ");
			stringBuilder.append("FROM CI_SA_TYPE ");
			stringBuilder.append("WHERE SA_TYPE_CD = :saType ");

			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());

			String[] saTypeStr = paymentArrangementSATypes.split(COMMA);
			for (int i = 0;i < saTypeStr.length; i++){
				prepState.bindString("saType", saTypeStr[i].trim(), "SA_TYPE_CD");
				prepState.setAutoclose(false);
				prepState.execute();
				if (prepState.list().size() > 0) {
					excludeSAList.add(saTypeStr[i].trim());
				} else {
					// SA Type is invalid
					addError(CustomMessageRepository.FN191784_saTypeParameterNotValid(saTypeStr[i]));
				}
			}
			prepState.close();
		}
	}
	/**
	 * Retrieve Collection of Eligible SA Types from feature configuration
	 */
	private void retrieveCollOfEligibleSaTypes() {      
		featConfRetriever = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
		pledgeSAList = featConfRetriever.getListOfFeatureOptionValues(pledgePAFeatureConf.getId(), 
				CmPledgePaymentsOptionTypeLookup.constants.ELIGIBLE_PLEDGE_SA_TYPES);       


		// Initialize 
		pledgeSAList = new ArrayList<String>();
		CmMGEFeatureConfigurationOptionsRetriever featConfRoutine = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
		// Retrieve the option value (comma delimited)      
		String optVal = featConfRoutine.cmGetFeatOptValue(pledgePAFeatureConf.getId(),CmPledgePaymentsOptionTypeLookup.constants.ELIGIBLE_PLEDGE_SA_TYPES,Bool.TRUE,Bool.FALSE);

		// Retrieve, Validate and Store the valid pledge tender sources     
		String[] strArrayOptVal = optVal.split(COMMA);

		StringBuilder stringBuilder = new StringBuilder();      
		stringBuilder.append("SELECT 'X' ");
		stringBuilder.append("FROM CI_SA_TYPE ");
		stringBuilder.append("WHERE SA_TYPE_CD = :saType ");

		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());

		for (String saTypeStr : strArrayOptVal) {
			if (notBlank(saTypeStr)) {      
				prepState.bindString("saType", saTypeStr.trim(), "SA_TYPE_CD");
				prepState.setAutoclose(false);
				prepState.execute();
				if (prepState.list().size() > 0) {
					pledgeSAList.add(saTypeStr.trim());
				} else {
					// SA Type is invalid
					addError(CustomMessageRepository.FN191784_saTypeParameterNotValidFromFeatureConfiguration(saTypeStr));
				}
			}
		}
		prepState.close();
	}
	/**
	 * Retrieves Eligible Payment Arrangement SA given an account.
	 * @param account
	 * @output count
	 */
	//Start Delete - 2019-08-19 - JLumbre - SpireOne B-08020
	/*public int pledgeSACount(Account account){
        int count = 0;
        StringBuilder strBldr = new StringBuilder();

        strBldr.append("SELECT SA.SA_ID "); 
        strBldr.append("FROM CI_SA SA "); 
        strBldr.append(",CI_SA_TYPE SATYPE "); 
        strBldr.append("WHERE SA.ACCT_ID = :ACCT_ID "); 
        strBldr.append("AND SA.SA_STATUS_FLG = :SA_STATUS_FLG ");
        strBldr.append("AND SA.CIS_DIVISION = SATYPE.CIS_DIVISION "); 
        strBldr.append("AND SA.SA_TYPE_CD = SATYPE.SA_TYPE_CD "); 
        strBldr.append("AND SATYPE.SPECIAL_ROLE_FLG = :PA "); 
        PreparedStatement qry = createPreparedStatement(strBldr.toString(), getClass().getName()); 
        qry.bindEntity("ACCT_ID", account);
        qry.bindLookup("SA_STATUS_FLG", ServiceAgreementStatusLookup.constants.ACTIVE);
        qry.bindLookup("PA", SpecialRoleLookup.constants.PAYMENT_ARRANGEMENT);
        List<SQLResultRow> rowList = qry.list();
        qry.close();

        Iterator<SQLResultRow> rowListIter = rowList.iterator();
        while (rowListIter.hasNext()){
            SQLResultRow row = rowListIter.next();
            ServiceAgreement_Id saId = (ServiceAgreement_Id) row.getId("SA_ID", ServiceAgreement.class);
            ServiceAgreement tempSA =  saId.getEntity();
            String tempSAType = tempSA.getServiceAgreementType().fetchIdSaType().trim();
            if (pledgeSAList.contains(tempSAType)){
                workPledgeSA = tempSA;
                count++;
                // return count if more than 1. Account has more than one PA SA. ToDo will be created.
                if (count>1){
                    return count;
                }
            }
        }
        return count;
    }*/
	//End Delete - 2019-08-19 - JLumbre - SpireOne B-08020
	
	//Start Add - 2019-08-19 - JLumbre - SpireOne B-08020
	public Iterator<SQLResultRow> getPledgeSACount(Account account){
		//int count = 0;
		Iterator<SQLResultRow> rowListIter;
		StringBuilder strBldr = new StringBuilder();

		strBldr.append("SELECT SA.SA_ID "); 
		strBldr.append("FROM CI_SA SA "); 
		strBldr.append(",CI_SA_TYPE SATYPE "); 
		strBldr.append("WHERE SA.ACCT_ID = :ACCT_ID "); 
		strBldr.append("AND SA.SA_STATUS_FLG = :SA_STATUS_FLG ");
		strBldr.append("AND SA.CIS_DIVISION = SATYPE.CIS_DIVISION "); 
		strBldr.append("AND SA.SA_TYPE_CD = SATYPE.SA_TYPE_CD "); 
		strBldr.append("AND SATYPE.SPECIAL_ROLE_FLG = :PA ");
		strBldr.append("ORDER BY SATYPE.PAY_PRIORITY_FLG ASC ");
		PreparedStatement qry = createPreparedStatement(strBldr.toString(), getClass().getName()); 
		qry.bindEntity("ACCT_ID", account);
		qry.bindLookup("SA_STATUS_FLG", ServiceAgreementStatusLookup.constants.ACTIVE);
		qry.bindLookup("PA", SpecialRoleLookup.constants.PAYMENT_ARRANGEMENT);
		List<SQLResultRow> rowList = qry.list();
		qry.close();

		rowListIter = rowList.iterator();
		return rowListIter;
	}
	//End Add - 2019-08-19 - JLumbre - SpireOne B-08020

	/**
	 * Create adjustment data for transfer adjustment
	 * @param Overpayment SA
	 * @param Pledge Payment Arrangement SA
	 * @param Adjustment Type
	 * @param Adjustment amount
	 */

	private CreateFrozenAdjustmentData prepareAdjustmentData(ServiceAgreement pledgeOverpaymentSA, ServiceAgreement pledgePASA, AdjustmentType adjType, Money amount) {
		CreateFrozenAdjustmentData frozenAdjData = CreateFrozenAdjustmentData.Factory.newInstance();

		frozenAdjData.setServiceAgreement(pledgeOverpaymentSA);
		frozenAdjData.setAdjustmentType(adjType);
		frozenAdjData.setAdjustmentAmount(amount);
		frozenAdjData.setAdjustmentDate(getProcessDateTime().getDate());
		frozenAdjData.setCalculationDate(getProcessDateTime().getDate());
		frozenAdjData.setArrearsDate(getProcessDateTime().getDate());
		frozenAdjData.setAllowZeroAmount(Bool.TRUE);
		frozenAdjData.setCustomCommonArea("");
		frozenAdjData.setTransferServiceAgreement(pledgePASA);
		return frozenAdjData;
	}

	/**
	 * Adds or updates a recurring charge for the given service agreement
	 * @param Payment Arrangement Service Agreement
	 */
	/*
	 * Defect 3793747 - 2017-07-18 - Start Change
	 */
	//private void processPaSaRecurringChargeHistory(ServiceAgreement paSa, BigDecimal remainingInstallments) {
	/*
	 * Defect 3809657 - 2017-08-02 - Start Change
	 */
	//private void processPaSaRecurringChargeHistory(ServiceAgreement paSa, BigDecimal remainingInstallments, Bool paySegAppliedtoPASA, Money workPledgeSAPayAmount) {  
	private void processPaSaRecurringChargeHistory(ServiceAgreement paSa, Money workPledgeSAPayOff,
			Bool paySegAppliedtoPASA, Money workPledgeSAPayAmount) {        
		/*
		 * Defect 3809657 - 2017-08-02 - End Change
		 */
		/*
		 * Defect 3793747 - 2017-07-18 - End Change
		 */
		/*
		 * Defect 3809657(Reopen) - 2017-09-04 - Start Delete
		 */
		///*
		// * Defect 3809657 - 2017-08-02 - Start Add
		// */
		//Iterator<ServiceAgreementRecurringCharge> curIter = paSa.getRecurringCharges().iterator();
		//ServiceAgreementRecurringCharge latestRecurringCharge=null;
		//while (curIter.hasNext()){
		//    latestRecurringCharge = curIter.next();
		//}
		///*
		// * Defect 3809657 - 2017-08-02 - End Add
		// */
		//
		///*
		// * Defect 3809657 - 2017-08-02 - Start Delete
		// */
		////DateInterval dateDifference = getProcessDateTime().getDate().difference(paSa.getStartDate());
		////long differenceInMonths = dateDifference.getTotalMonths();
		////BigDecimal divideBy = remainingInstallments.subtract(BigDecimal.valueOf(differenceInMonths));
		///*
		// * Defect 3809657 - 2017-08-02 - End Delete
		// */
		//
		///*
		// * Defect 3809657 - 2017-08-02 - Start Add
		// */
		////Retrieve remaining installments by original PA payoff balance - PA payment / recurring charge amount
		//BigDecimal divideBy = BigDecimal.ZERO;
		//if(paySegAppliedtoPASA.isTrue()){
		//    divideBy = workPledgeSAPayOff.getAmount().divide(latestRecurringCharge.getRecurringChargeAmount().getAmount(), BigDecimal.ROUND_HALF_UP);
		//} else {
		//    BigDecimal tempWorkPledgeSAPayOff = workPledgeSAPayOff.getAmount().subtract(workPledgeSAPayAmount.getAmount());
		//    divideBy = tempWorkPledgeSAPayOff.divide(latestRecurringCharge.getRecurringChargeAmount().getAmount(),BigDecimal.ROUND_HALF_UP);
		//}
		///*
		// * Defect 3809657 - 2017-08-02 - End Add
		// */
		//
		///*
		// * Defect 3809657 - 2017-08-02 - Start Change
		// */
		////if (divideBy.equals(BigDecimal.ZERO) || divideBy.compareTo(BigDecimal.ZERO)==-1 || remainingInstallments.equals(BigDecimal.ZERO)){
		//if (divideBy.equals(BigDecimal.ZERO) || divideBy.compareTo(BigDecimal.ZERO)==-1 ){
		///*
		// * Defect 3809657 - 2017-08-02 - End Change
		// */
		//    //Do not compute new recurring charge. If zero or less than, this means the Payment Arrangement SA has run its course.
		//    return;
		//}
		///*
		// * Defect 3809657 - 2017-08-02 - Start Delete
		// */
		////Iterator<ServiceAgreementRecurringCharge> curIter = paSa.getRecurringCharges().iterator();
		////ServiceAgreementRecurringCharge latestRecurringCharge=null;
		////while (curIter.hasNext()){
		//    //latestRecurringCharge = curIter.next();
		////}
		///*
		// * Defect 3809657 - 2017-08-02 - End Delete
		// */
		//
		///*
		// * Defect 3793747 - 2017-07-18 - Start Change
		// */
		////BigDecimal amount = paSa.getPayoffBalance().getAmount().divide(divideBy, BigDecimal.ROUND_HALF_UP);
		//BigDecimal amount = BigDecimal.ZERO;
		//
		//if (paySegAppliedtoPASA.isTrue()){
		//    amount = paSa.getPayoffBalance().getAmount().divide(divideBy, BigDecimal.ROUND_HALF_UP);
		//}else {
		//    amount = (paSa.getPayoffBalance().getAmount().subtract(workPledgeSAPayAmount.getAmount()).divide(divideBy,BigDecimal.ROUND_HALF_UP));
		//}
		///*
		// * Defect 3793747 - 2017-07-18 - Start Change
		// */
		/*
		 * Defect 3809657(Reopen) - 2017-09-04 - End Delete
		 */
		/*
		 * Defect 3809657(Reopen) - 2017-09-04 - Start Add
		 */
		// Retrieve the earliest recurring charge of the Payment Arrangement SA.
		ServiceAgreementRecurringCharge earliestRecurringCharge = null;
		ServiceAgreementRecurringCharge latestRecurringCharge = null;

		ListFilter<ServiceAgreementRecurringCharge> recurringChargesFilter = paSa.getRecurringCharges().createFilter(
				"ORDER BY this.id.effectiveDate ASC", getClass().getName());

		QueryIterator<ServiceAgreementRecurringCharge> iter = recurringChargesFilter.iterate();
		ServiceAgreementRecurringCharge currentCharge = null;
		int resultsCounter = 0;

		while(iter.hasNext()) {
			currentCharge = iter.next();
			resultsCounter++;

			if(resultsCounter == 1) {
				earliestRecurringCharge = currentCharge;
			}
			else if(resultsCounter == recurringChargesFilter.list().size()) {
				latestRecurringCharge = currentCharge;
			}
		}

		Money earliestRecurringChargeAmount = earliestRecurringCharge.getRecurringChargeAmount();

		// Retrieve the payoff balance of the Payment Arrangement SA on its start date.
		Money originalPayoffBalance = paSa.getPayoffBalance(paSa.getStartDate(), paSa.getStartDate(), Bool.TRUE);

		// Calculate the original number of installments.
		BigInteger originalInstallmentNumber = originalPayoffBalance.getAmount().divide(earliestRecurringChargeAmount.getAmount()).
				setScale(0, BigDecimal.ROUND_HALF_UP).toBigInteger();

		// Retrieve the number of frozen Bill Segments for the Payment Arrangement SA.
		BigInteger frozenBsegCount = retrieveNumberOfFrozenBsegs(paSa);

		// Compute how many installments are remaining.
		BigInteger remainingInstallmentNumber = originalInstallmentNumber.subtract(frozenBsegCount);

		if(remainingInstallmentNumber.compareTo(BigInteger.ZERO) == 0) {
			remainingInstallmentNumber = BigInteger.ONE;
		}

		if(remainingInstallmentNumber.compareTo(BigInteger.ZERO) <= 0) {
			// Do not compute new recurring charge. If zero or less than, this means the Payment Arrangement SA has run its course.
			return;
		}

		BigDecimal amount = BigDecimal.ZERO;

		if (paySegAppliedtoPASA.isTrue()){
			amount = paSa.getPayoffBalance().getAmount().divide(BigDecimal.valueOf(remainingInstallmentNumber.longValue()), 
					BigDecimal.ROUND_CEILING);
		}else {
			amount = (paSa.getPayoffBalance().getAmount().subtract(workPledgeSAPayAmount.getAmount()).divide(
					BigDecimal.valueOf(remainingInstallmentNumber.longValue()),BigDecimal.ROUND_CEILING));
		}
		/*
		 * Defect 3809657(Reopen) - 2017-09-04 - End Add
		 */
		Money recurringChargeAmt = new Money(amount,sa.getCurrencyId());
		if (!isNull(latestRecurringCharge)&&(latestRecurringCharge.fetchIdEffectiveDate().equals(getProcessDateTime().getDate()))) {
			//if effective date = business date, update amount
			ServiceAgreementRecurringCharge_DTO latestRecurringChargeDto = latestRecurringCharge.getDTO();
			latestRecurringChargeDto.setRecurringChargeAmount(recurringChargeAmt);
			latestRecurringCharge.setDTO(latestRecurringChargeDto);
			return;
		}

		//otherwise, add a new entry to the recurring charge amount history
		ServiceAgreementRecurringCharge_DTO recurringChargeDto = (ServiceAgreementRecurringCharge_DTO) createDTO(ServiceAgreementRecurringCharge.class);
		recurringChargeDto.setCurrencyId(recurringChargeAmt.getCurrencyId());
		recurringChargeDto.setRecurringChargeAmount(recurringChargeAmt);
		paSa.getRecurringCharges().add(recurringChargeDto, getProcessDateTime().getDate());
	}

	/**
	 * Create To Do
	 */
	//Start Delete - 2019-08-19 - JLumbre - SpireOne B-08020
	/*private void createToDo(){
        //Create To Do Entry
        ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
        ToDoEntry_DTO toDoDTO = createDTO(ToDoEntry.class);

        //Set To Do Type and Role
        toDoDTO.setToDoTypeId(errorToDoType.getId());
        toDoDTO.setToDoRoleId(errorToDoType.getDefaultRole().getId().getToDoRoleId());  

        toDoDTO.setCreationDateTime(getProcessDateTime());
        toDoDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
        toDoDTO.setToDoPriority(errorToDoType.getToDoPriority());   
        toDoCreator.setToDoDTO(toDoDTO);

        //Set Sort Keys
        ToDoSortKeyType sortKeyType = null;
        int seq = 1;
        for (Iterator<ToDoSortKeyType> sortKeyIter = errorToDoType.getSortKeyTypes().iterator(); sortKeyIter.hasNext();) {
            sortKeyType = (ToDoSortKeyType) sortKeyIter.next();
            if (seq==1){
                toDoCreator.addSortKeyValue(sortKeyType, sa.getAccount().getId().getIdValue());
            }
            seq++;
        }       

        //Set Drill Keys
        ToDoDrillKeyType drillKeyType = null;
        seq = 1;
        for (Iterator<ToDoDrillKeyType> drillKeyIter = errorToDoType.getDrillKeyTypes().iterator(); drillKeyIter.hasNext();) {
            drillKeyType = (ToDoDrillKeyType) drillKeyIter.next();
            if (seq ==1){
                toDoCreator.addDrillKeyValue(drillKeyType, sa.getAccount().getId().getIdValue());
            }
            seq++;
        }
        // Setting To Do message values
        toDoCreator.addMessageParameter(sa.getAccount().getId().getIdValue());

        //Create the To Do Entry
        toDoCreator.create();     
    }*/
	//End Delete - 2019-08-19 - JLumbre - SpireOne B-08020
	/*
	 * Defect 3809657 - 2017-08-02 - Start Delete
	 */
	///**
	// * Use business service to retrieve remaining installments on PA 
	// * @param Payment Arrangement Service Agreement
	// * @output number of installments
	// */
	//private BigDecimal getPAInstallments(ServiceAgreement paSa){
	//BigDecimal installments;
	//BusinessServiceInstance busSvcInstance = BusinessServiceInstance.create(BS_PAY_ARRANGEMENT_READ);
	//busSvcInstance.set("paymentArrangementSA", paSa.getId().getTrimmedValue());
	//busSvcInstance.set("canPageRead",Bool.TRUE);
	//busSvcInstance = BusinessServiceDispatcher.execute(busSvcInstance); 
	//installments = busSvcInstance.getNumber("currInstallment");
	//return installments;
	//}
	/*
	 * Defect 3809657 - 2017-08-02 - End Delete
	 */

	/*
	 * Defect 3793747 - 2017-07-18 - Start Add
	 */
	private Bool checkPaySegment(ServiceAgreement_Id saId, Money paymentAmount) {
		Bool returnValue = Bool.FALSE;

		StringBuilder checkPaySegmentQueryStr = new StringBuilder();

		checkPaySegmentQueryStr.append("SELECT 'X' ");
		checkPaySegmentQueryStr.append("FROM CI_FT FT ");
		/*
		 * Defect 3809657(Reopen) - 2017-09-04 - Start Change
		 * Added the Payment ID as filter to check if this particular Payment has already been applied to the Account.
		 */
		//checkPaySegmentQueryStr.append("WHERE FT.SA_ID = :saId ");
		checkPaySegmentQueryStr.append("WHERE FT.PARENT_ID = :payment ");
		checkPaySegmentQueryStr.append("AND FT.SA_ID = :saId ");
		/*
		 * Defect 3809657(Reopen) - 2017-09-04 - End Change
		 */
		checkPaySegmentQueryStr.append("AND FT.FT_TYPE_FLG = :paySegment ");
		checkPaySegmentQueryStr.append("AND FT.CUR_AMT = :paymentAmount ");
		checkPaySegmentQueryStr.append("AND FT.FREEZE_SW = :yes ");
		checkPaySegmentQueryStr.append("AND TRUNC(FT.FREEZE_DTTM) = :freezeDate ");
		checkPaySegmentQueryStr.append("AND NOT EXISTS (SELECT 'X' ");
		checkPaySegmentQueryStr.append(                "FROM CI_FT FT2 ");
		/*
		 * Defect 3809657(Reopen) - 2017-09-04 - Start Change
		 * Added the Payment ID as filter to check if this particular Payment has already been applied to the Account.
		 */
		//checkPaySegmentQueryStr.append(                "WHERE FT2.SA_ID = FT.SA_ID ");
		checkPaySegmentQueryStr.append(                "WHERE FT2.PARENT_ID = :payment ");
		checkPaySegmentQueryStr.append(                "AND FT2.SA_ID = FT.SA_ID ");
		/*
		 * Defect 3809657(Reopen) - 2017-09-04 - End Change
		 */
		checkPaySegmentQueryStr.append(                "AND FT2.SIBLING_ID = FT.SIBLING_ID ");
		checkPaySegmentQueryStr.append(                "AND FT2.FT_TYPE_FLG = :payCancel ) ");

		PreparedStatement qry = createPreparedStatement(checkPaySegmentQueryStr.toString(), getClass().getName());
		/*
		 * Defect 3809657(Reopen) - 2017-09-04 - Start Add
		 */
		qry.bindEntity("payment", payment);
		/*
		 * Defect 3809657(Reopen) - 2017-09-04 - End Add
		 */
		qry.bindId("saId", saId);
		qry.bindLookup("paySegment", FinancialTransactionTypeLookup.constants.PAY_SEGMENT);
		qry.bindMoney("paymentAmount", paymentAmount.negate());
		qry.bindBoolean("yes", Bool.TRUE);
		qry.bindDate("freezeDate", payment.getPaymentEvent().getPaymentDate());
		qry.bindLookup("payCancel", FinancialTransactionTypeLookup.constants.PAY_CANCELLATION);

		if (qry.list().size() > 0){
			returnValue = Bool.TRUE;
		}

		return returnValue;
	}
	/*
	 * Defect 3793747 - 2017-07-18 - End Add
	 */

	/*
	 * Defect 3809657(Reopen) - 2017-09-04 - Start Add
	 */
	private BigInteger retrieveNumberOfFrozenBsegs(ServiceAgreement sa) {

		StringBuilder getNumberOfFrozenBsegsStr = new StringBuilder();

		getNumberOfFrozenBsegsStr.append("SELECT ");
		getNumberOfFrozenBsegsStr.append(  "COUNT(BSEG_ID) AS COUNT ");
		getNumberOfFrozenBsegsStr.append("FROM ");
		getNumberOfFrozenBsegsStr.append(  "CI_BSEG ");
		getNumberOfFrozenBsegsStr.append("WHERE SA_ID = :sa ");
		getNumberOfFrozenBsegsStr.append(  "AND BSEG_STAT_FLG = :frozen ");

		PreparedStatement getNumberOfFrozenBsegsQuery = createPreparedStatement(
				getNumberOfFrozenBsegsStr.toString(), getClass().getName());

		getNumberOfFrozenBsegsQuery.bindEntity("sa", sa);
		getNumberOfFrozenBsegsQuery.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);

		BigInteger numberOfFrozenBillSegments = getNumberOfFrozenBsegsQuery.firstRow().getInteger("COUNT");

		getNumberOfFrozenBsegsQuery.close();
		return numberOfFrozenBillSegments;
	}
	/*
	 * Defect 3809657(Reopen) - 2017-09-04 - End Add
	 */

}