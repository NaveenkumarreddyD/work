/*
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                     
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * This SA Type - Initiate Stop algorithm will revert the customer's 
 * customer class, collection class and cancel their budgets as well
 * as remove CM-FPL characteristic. 
 * 
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:        by:          Reason:
 * YYYY-MM-DD   FLName
 * 2018-11-02   JHERNA		SysAid#271015. 
 * 
 ***********************************************************************
 */
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.initiateStopSa;

import java.util.Iterator;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.admin.budgetPlan.entity.BudgetPlan;
import com.splwg.ccb.domain.admin.budgetPlan.entity.BudgetPlan_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.collectionClass.entity.CollectionClass;
import com.splwg.ccb.domain.admin.collectionClass.entity.CollectionClass_Id;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClassControl;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClassControl_Id;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.initiateStopSa.SaTypeInitiateStopSaAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristics;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_DTO;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.api.lookup.CmLowIncomeProgramConfigurationsOptionTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = featureConfiguration, name = featureConfigLIP, required = true, type = entity)})
 */
public class CmRevertFCAPCustomersAlgComp_Impl 
		extends CmRevertFCAPCustomersAlgComp_Gen 
		implements SaTypeInitiateStopSaAlgorithmSpot {

	/*Soft Parameter*/
	private FeatureConfiguration parmFeatConfLIP;
	
	/*Hard Parameters*/
	private ServiceType hpServiceType;
	@SuppressWarnings("unused")
	private Premise hpPremise;
	@SuppressWarnings("unused")
	private String hpRevertToLandlord;
	private ServiceAgreement hpSA;
	@SuppressWarnings("unused")
	private Bool hpShouldCreateFA;
	@SuppressWarnings("unused")
	private Date hpStopDate;
	@SuppressWarnings("unused")
	private String hpStopRequestedBy;

	/* Work Variables*/
	private CmMGEFeatureConfigurationOptionsRetriever fcHelper;
	private CharacteristicType_Id wCharTypeIdFederalPovertyLevel;
	private CharacteristicType_Id wCharTypeIdOldCustomerClass;
		
	@Override
	public ServiceType getServiceType() {
		return hpServiceType;
	}

	@Override
	public void setPremise(Premise arg0) {
		hpPremise = arg0;
	}

	@Override
	public void setRevertToLandlord(String arg0) {
		hpRevertToLandlord = arg0;
	}

	@Override
	public void setServiceAgreement(ServiceAgreement arg0) {
		hpSA = arg0;
	}

	@Override
	public void setServiceType(ServiceType arg0) {
		hpServiceType = arg0;
	}

	@Override
	public void setShouldCreateFieldActivity(Bool arg0) {
		hpShouldCreateFA = arg0;
	}

	@Override
	public void setStopDate(Date arg0) {
		hpStopDate = arg0;
	}

	@Override 
	public void setStopRequestedBy(String arg0) {
		hpStopRequestedBy = arg0;
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		
		parmFeatConfLIP = this.getFeatureConfigLIP();
		
		fcHelper = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
		wCharTypeIdFederalPovertyLevel = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfLIP.getId(), 
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FPL_CHARACTERISTIC_TYPE, 
				Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.ACCOUNT);
		wCharTypeIdOldCustomerClass = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfLIP.getId(),
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.OLD_CUSTOMER_CLASS_CHARACTERISTIC_TYPE, 
				Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.ACCOUNT);		
	}
	
	@Override
	public void invoke() {

		Bool shouldUpdate = Bool.FALSE;
		Account account = hpSA.getAccount();
		Account_DTO acctDTO = account.getDTO();

		// Retrieve old customer class
		CharacteristicType charTypeOldCustClass = wCharTypeIdOldCustomerClass.getEntity();			
		CustomerClass oldCustClass = retrieveOldCustClass(account, charTypeOldCustClass);

		CollectionClass oldCollClass = oldCustClass.fetchCollectionClass();
		BudgetPlan oldDefaultBudPlan = retrieveDefaultBudgetPlan(oldCustClass, account.fetchDivision());
		
		// Revert customer class if the current customer class is FCAP
		CustomerClass currentCustomerClass = account.getCustomerClass();
		String fcapCustClassStr = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfLIP.getId(), 
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_CUSTOMER_CLASS, Bool.TRUE);
		
		if (currentCustomerClass.getId().getTrimmedValue().compareTo(fcapCustClassStr.trim()) == 0) {			
			shouldUpdate = Bool.TRUE;
			acctDTO.setCustomerClassId(oldCustClass.getId());						
		}
		
		// Revert collection class if the current collection class is FCAP
		CollectionClass_Id currentCollectionClassID = account.getCollectionClassId();
		String fcapCollClassStr = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfLIP.getId(), 
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_COLLECTION_CLASS, Bool.TRUE);
		
		if (currentCollectionClassID.getTrimmedValue().compareTo(fcapCollClassStr.trim()) == 0) {
			shouldUpdate = Bool.TRUE;
			acctDTO.setCollectionClassId(oldCollClass.getId());
		}
		
		// Revert budget plan if the current budget plan is FCAP
		BudgetPlan_Id currentBudPlanID = account.getBudgetPlanId();
		String fcapBudPlanStr = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfLIP.getId(), 
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_BUDGET_PLAN, Bool.TRUE);
		
		if (currentBudPlanID.getTrimmedValue().compareTo(fcapBudPlanStr.trim()) == 0) {
			shouldUpdate = Bool.TRUE;
			acctDTO.setBudgetPlanId(oldDefaultBudPlan.getId());
		}
		
		if (shouldUpdate.isTrue()) {
			account.setDTO(acctDTO);		
		}
		
		// Remove Old Customer Class characteristic
		deleteAccountChar(account, wCharTypeIdOldCustomerClass);
		
		// Remove Federal Poverty Level characteristic
		deleteAccountChar(account, wCharTypeIdFederalPovertyLevel);
		
		// Cancel Account's all Budget Amount
		account.cancelBudget(this.getProcessDateTime().getDate());
		
	}
	
	private CustomerClass retrieveOldCustClass(Account acct, CharacteristicType charTypeOldCustClass) {
		
		CustomerClass returnValue = null;
		AccountCharacteristic acctChar = acct.getEffectiveCharacteristic(charTypeOldCustClass);
		
		if (notNull(acctChar)) {
			
			CharacteristicTypeLookup charTypeLookup = charTypeOldCustClass.getCharacteristicType();
			String oldCcStr = " ";
			if (charTypeLookup.isAdhocValue()
					|| charTypeLookup.isFileLocationValue()) {
				oldCcStr = acctChar.getAdhocCharacteristicValue().trim();
			}
			else if (charTypeLookup.isPredefinedValue()) {
				oldCcStr = acctChar.getCharacteristicValue().trim();
			}
			else {
				oldCcStr = acctChar.getCharacteristicValueForeignKey1().trim();
			}
			CustomerClass_Id oldCustClassID = new CustomerClass_Id(oldCcStr);
			if (notNull(oldCustClassID.getEntity())) {
				returnValue = oldCustClassID.getEntity();									
			}
		}
		
		if (isNull(returnValue)) {
			// Cannot revert customer (account id %1) to pre-low income program data.
			addError(CustomMessageRepositoryMGE.sa271015_CannotRevertToPreLowIncomeProgram(acct.getId().getTrimmedValue()));
		}
		return returnValue;
	}
	
	private BudgetPlan retrieveDefaultBudgetPlan(CustomerClass custClass, CisDivision cisDivision) {
		
		BudgetPlan returnValue = null;
		
		CustomerClassControl_Id custClassControlID = new CustomerClassControl_Id(custClass, cisDivision);
		if (notNull(custClassControlID.getEntity())) {
			CustomerClassControl custClassControl = custClassControlID.getEntity();
			returnValue = custClassControl.fetchDefaultBudgetPlan();
		}
		
		return returnValue;
	}
	
	private void deleteAccountChar(Account account, CharacteristicType_Id charTypeID) {
		
		AccountCharacteristics acctChars = account.getCharacteristics();
		if (notNull(acctChars)) {
			Iterator<AccountCharacteristic> iter = acctChars.iterator();
			while (iter.hasNext()) {
				AccountCharacteristic acctChar = iter.next();
				CharacteristicType acctCharType = acctChar.fetchIdCharacteristicType();
				if (acctCharType.getId().compareTo(charTypeID) == 0) {
					iter.remove();
				}
			}
		}		
	}
}
