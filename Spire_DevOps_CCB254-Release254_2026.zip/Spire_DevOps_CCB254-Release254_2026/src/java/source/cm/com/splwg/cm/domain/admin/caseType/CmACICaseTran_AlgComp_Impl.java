/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * ACI Case Transition Algorithm
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-04-08   Jagadeesh	NM0101 Initial Version.
 * 2013-05-07	Jagadeesh	TIR1 Fix
 * 2014-07-02	Rahul		IM-053688
 * 2014-07-10   Ujesh       IM-053688 - Added softparameter for ACI Inspetion Code
 * 2014-12-10   Ujesh	    IM-053688 - Bug Fix for Cases getting closed
 * 2016-01-22	MPang		Updated for CCB v2.4 compilation.
 ******************************************************************************************/
package com.splwg.cm.domain.admin.caseType;

import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.CaseLogTypeLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.TransitionConditionLookup;

//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation

//import com.splwg.ccb.domain.admin.caseType.CaseStatus.entity;
//import com.splwg.ccb.domain.admin.caseType.CaseTypeAutoTransitionAlgorithmSpot;
//import com.splwg.ccb.domain.admin.meterLocation.MeterLocation_Id;
//import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
//import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePointCharacteristic;
//import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
//import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic;
//import com.splwg.ccb.domain.todo.toDoCase.CaseLog;
//import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;

import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.algorithm.autoTransition.AutoTransitionAlgorithmSpot;
import com.splwg.ccb.domain.admin.meterLocation.entity.MeterLocation_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;

//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation

import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

// Start Change - 2014-07-10 - Ujesh - IM-053688

/*
/**
 * @author jgali001
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = caseSPCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = tranCondClose, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = tranCondReview, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (entityName = meterLocation, name = meterLocationOut, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = spResultCdCharType, type = entity)
 *            , @AlgorithmSoftParameter (name = spResultCdCharVal, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = spDueDateCharType, required = true, type = entity))})
 */

/**
 * @author jgali001
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = caseSPCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = tranCondClose, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = tranCondReview, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (entityName = meterLocation, name = meterLocationOut, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = spResultCdCharType, type = entity)
 *            , @AlgorithmSoftParameter (name = spResultCdCharVal, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = spDueDateCharType, required = true, type = entity)            
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = spCaseClosureCdCharType, type = entity)    
 *            , @AlgorithmSoftParameter (name = spCaseClosureCdCharVal, type = string)})
 */

// End Change - 2014-07-10 - Ujesh - IM-053688

public class CmACICaseTran_AlgComp_Impl extends CmACICaseTran_AlgComp_Gen

	//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
	//implements CaseTypeAutoTransitionAlgorithmSpot {
		implements AutoTransitionAlgorithmSpot {
	//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation

	private CharacteristicType parmCaseSPCharType;
    private TransitionConditionLookup parmTranCondClose ;
    private TransitionConditionLookup parmTranCondReview ;
    private MeterLocation_Id parmMeterLocationIdOut;
    private CharacteristicType parmSPResultCdCharType;
    private CharacteristicType parmSPDueDateCharType;
    //private Logger logger = LoggerFactory.getLogger(CmACICaseTran_AlgComp_Impl.class);    

    // Start Add - 2014-07-10 - Ujesh - IM-053688
    private CharacteristicType paramSPCaseClosureCharType;
    private String paramSPCaseClosureCdCharVal;
    // End Add - 2014-07-10 - Ujesh - IM-053688
    
    private ToDoCase inpCase;
    private String parmSPResultCdCharVal;
    private String tranCond;
    private Bool shouldAutoTransition = Bool.FALSE;
	// TIR-1 fix
    //private static final String dueDateFormat = "MM/dd/yyyy";

    protected void extraSoftParameterValidations(boolean arg0) {
        parmCaseSPCharType = getCaseSPCharType();
        CharacteristicEntity charEntity = new CharacteristicEntity_Id(parmCaseSPCharType, CharacteristicEntityLookup.constants.CASE).getEntity();
        if(isNull(charEntity)){
            addError(CustomMessageRepository.nm0101InvalidCharEntity(parmCaseSPCharType.getId().getIdValue()));
        }
        parmSPResultCdCharType = getSpResultCdCharType();
        if(notNull(parmSPResultCdCharType)){
            charEntity = new CharacteristicEntity_Id(parmSPResultCdCharType, CharacteristicEntityLookup.constants.SERVICE_POINT).getEntity();
            if(isNull(charEntity)){
                addError(CustomMessageRepository.nm0101InvalidCharEntity(parmSPResultCdCharType.getId().getIdValue()));
            }
            parmSPResultCdCharVal = getSpResultCdCharVal();
            if(isNull(parmSPResultCdCharVal)){
                addError(CustomMessageRepository.nm0101NullCharVal());
            }
            CharacteristicValue_Id cvl = new CharacteristicValue_Id(parmSPResultCdCharType,parmSPResultCdCharVal);
            if(isNull(cvl.getEntity()))
            {
                addError(CustomMessageRepository.nm0101InvalidCharVal(parmSPResultCdCharType.getId().getIdValue(),parmSPResultCdCharVal));
            }               
        }
        parmSPDueDateCharType = getSpDueDateCharType();
        charEntity = new CharacteristicEntity_Id(parmSPDueDateCharType, CharacteristicEntityLookup.constants.SERVICE_POINT).getEntity();
        if(isNull(charEntity)){
            addError(CustomMessageRepository.nm0101InvalidCharEntity(parmSPDueDateCharType.getId().getIdValue()));
        }
        
        // Start Add - 2014-07-10 - Ujesh - IM-053688     
        paramSPCaseClosureCharType = getSpCaseClosureCdCharType();
        if(notNull(paramSPCaseClosureCharType))
        {        
	        charEntity = new CharacteristicEntity_Id(paramSPCaseClosureCharType, CharacteristicEntityLookup.constants.SERVICE_POINT).getEntity();
	        if(isNull(charEntity)){
	            addError(CustomMessageRepository.nm0101InvalidCharEntity(paramSPCaseClosureCharType.getId().getIdValue()));
	        }        
	        
	        paramSPCaseClosureCdCharVal = getSpCaseClosureCdCharVal();
	        if(isNull(paramSPCaseClosureCdCharVal)){
	            addError(CustomMessageRepository.nm0101NullCharVal());
	        }
	        CharacteristicValue_Id cvl = new CharacteristicValue_Id(paramSPCaseClosureCharType,paramSPCaseClosureCdCharVal);
	        if(isNull(cvl.getEntity()))
	        {
	            addError(CustomMessageRepository.nm0101InvalidCharVal(paramSPCaseClosureCharType.getId().getIdValue(),paramSPCaseClosureCdCharVal));
	        }  
        }
        // End Add - 2014-07-10 - Ujesh - IM-053688

    }

    public void invoke() {
	
        List<CaseCharacteristic> caseSPCharList = inpCase.getSortedCharacteristicsOfType(parmCaseSPCharType);
        if(caseSPCharList.isEmpty()){

            addError(CustomMessageRepository.nm0101NoSPChar(inpCase.getId().getIdValue()));
        }
        parmTranCondReview = getTranCondReview();
        parmTranCondClose = getTranCondClose();
        ServicePoint_Id spId =  new ServicePoint_Id(caseSPCharList.iterator().next().getCharacteristicValueForeignKey1());
        ServicePoint sp = spId.getEntity();
        if(notNull(parmSPResultCdCharType)){
            ServicePointCharacteristic spResultCdChar = sp.getEffectiveCharacteristic(parmSPResultCdCharType);
            if(notNull(spResultCdChar)){
	       
                if(spResultCdChar.getCharacteristicValue().trim().equalsIgnoreCase(parmSPResultCdCharVal)){
                    tranCond = parmTranCondReview.value();
                    shouldAutoTransition = Bool.TRUE;
                    return;
                }
            }
        }

        parmMeterLocationIdOut = getMeterLocationOut().getId();
        if(notNull(sp.getMeterLocationId()) && sp.getMeterLocationId().equals(parmMeterLocationIdOut)){
            tranCond = parmTranCondClose.value();
            shouldAutoTransition = Bool.TRUE;
            return;
        }

        Date logDate = null;
        for (CaseLog clog:inpCase.getLogs()){
            if (clog.getLogType().equals(CaseLogTypeLookup.constants.CREATED)){
                logDate = clog.getLogDateTime().getDate();
                break;
            }
        }

        StringBuilder getCheckSPDueDateCharString = new StringBuilder();
		//Start of change 2014-07-02	Rahul		IM-053688
		//getCheckSPDueDateCharString.append(" SELECT '1' FROM CI_SP_CHAR SC ");
        //getCheckSPDueDateCharString.append(" WHERE SC.CHAR_TYPE_CD = :dueDate AND SC.EFFDT > :caseLogDate AND SC.SP_ID = :caseSP  ");
        

        
        // Start Add - 2014-07-10 - Ujesh - IM-053688     
        if(notNull(paramSPCaseClosureCharType))
        {
            getCheckSPDueDateCharString.append(" SELECT '1' FROM CI_SP_CHAR SCO ");
            getCheckSPDueDateCharString.append(" WHERE (SCO.CHAR_TYPE_CD = :caseCoseCharType AND SCO.CHAR_VAL = :caseCoseCharVal AND SCO.SP_ID = :caseSP AND SCO.EFFDT >= :caseLogDate AND ");
            getCheckSPDueDateCharString.append(" SCO.EFFDT = (SELECT MAX(EFFDT) FROM CI_SP_CHAR SCI2 WHERE SCI2.SP_ID = SCO.SP_ID AND SCI2.CHAR_TYPE_CD = SCO.CHAR_TYPE_CD AND ");
            getCheckSPDueDateCharString.append(" SCI2.CHAR_VAL = SCO.CHAR_VAL AND SCI2.EFFDT >= :caseLogDate)) OR");
            getCheckSPDueDateCharString.append(" (SCO.CHAR_TYPE_CD = :dueDate AND to_date(SCO.ADHOC_CHAR_VAL,'YYYY-MM-DD') >= :caseLogDate AND SCO.SP_ID = :caseSP ");
    	    getCheckSPDueDateCharString.append(" AND SCO.EFFDT = (SELECT MAX(EFFDT) FROM CI_SP_CHAR SCI WHERE SCI.SP_ID = SCO.SP_ID AND SCI.CHAR_TYPE_CD = SCO.CHAR_TYPE_CD AND SCI.EFFDT >= :caseLogDate )) ");
    	    
        	
        }
        else
        {
        	
        // End Add - 2014-07-10 - Ujesh - IM-053688    
        	
	        getCheckSPDueDateCharString.append(" SELECT '1' FROM CI_SP_CHAR SCO ");
	        getCheckSPDueDateCharString.append(" WHERE SCO.CHAR_TYPE_CD = :dueDate AND to_date(SCO.ADHOC_CHAR_VAL,'YYYY-MM-DD') >= :caseLogDate AND SCO.SP_ID = :caseSP  ");
			getCheckSPDueDateCharString.append(" AND SCO.EFFDT = (SELECT MAX(EFFDT) FROM CI_SP_CHAR SCI WHERE SCI.SP_ID = SCO.SP_ID AND SCI.CHAR_TYPE_CD = SCO.CHAR_TYPE_CD AND SCI.EFFDT >= :caseLogDate) ");
		//End of change 2014-07-02	Rahul		IM-053688
			
		// Start Add - 2014-07-10 - Ujesh - IM-053688  	
        }	
		// End Add - 2014-07-10 - Ujesh - IM-053688  	
        //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement getCheckSPDueDateCharStmt = createPreparedStatement(getCheckSPDueDateCharString.toString()); 
        PreparedStatement getCheckSPDueDateCharStmt = createPreparedStatement(getCheckSPDueDateCharString.toString(), getClass().getName()); 
        //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        getCheckSPDueDateCharStmt.bindId("dueDate", parmSPDueDateCharType.getId());
        getCheckSPDueDateCharStmt.bindDate("caseLogDate", logDate);
        getCheckSPDueDateCharStmt.bindId("caseSP", spId);
        

        
        // Start Add - 2014-07-10 - Ujesh - IM-053688    
        if(notNull(paramSPCaseClosureCharType))
        {
            
        	getCheckSPDueDateCharStmt.bindId("caseCoseCharType", paramSPCaseClosureCharType.getId());
        	getCheckSPDueDateCharStmt.bindString("caseCoseCharVal", paramSPCaseClosureCdCharVal, "CHAR_VAL");
        }
        // End Add - 2014-07-10 - Ujesh - IM-053688  	
        if (notNull(getCheckSPDueDateCharStmt.firstRow())){
            tranCond = parmTranCondClose.value();
            shouldAutoTransition = Bool.TRUE;
        }
        
        getCheckSPDueDateCharStmt.close();
    }
    

    public CaseStatus getNextCaseStatus() {
        return null;
    }

    public String getNextTransCondition() {
        return tranCond;
    }

    
    public Bool getShouldAutoTransition() {
        return shouldAutoTransition;
    }

    
    public void setCase(ToDoCase arg0) {
        inpCase = arg0;
    }

}
