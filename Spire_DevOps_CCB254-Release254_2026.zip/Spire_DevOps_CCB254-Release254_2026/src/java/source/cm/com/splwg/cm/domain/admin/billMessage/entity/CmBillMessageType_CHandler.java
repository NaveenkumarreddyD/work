/*******************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * CCB043 - Bill Message Type Change Handler
 *
 * This is a new Change Handler on the Bill Message Type Entity.
 * It raises a warning to inform the user that there are prefixes designated
 * for each CIS Division.
 *
 ********************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *
 * 2021-05-24   DLampa          CCB043. Initial Version.
 ********************************************************************************/
package com.splwg.cm.domain.admin.billMessage.entity;

import com.splwg.base.api.DataTransferObject;
import com.splwg.base.api.changehandling.AbstractChangeHandler;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
/**
 * @author dlampa
 *
 @ChangeHandler (entityName = billMessageType)
 */
public class CmBillMessageType_CHandler extends AbstractChangeHandler<BillMessageType> {
    
    
    public void handleAddOrChange(BillMessageType billMessageType, DataTransferObject<BillMessageType> billMessageTypeDTO) {        
        addWarning(CustomMessageRepositorySpireOne.CCB043_ValidBillMessageRange());
    }
    


}