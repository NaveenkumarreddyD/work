/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Algorithm - Create ARP Credit Adjustment
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-03-04   RDizon  NA0050. Initial Version.
 * 2013-03-18   RDizon  TIR_NA0050. The Cents Of Payoff
 * 2013-03-26   CVB     Fixed issue on negative current balance.
 * 2016-01-26   MPang	Updated for CCB v2.4 compilation.
 **************************************************************************/

package com.splwg.cm.domain.admin.serviceAgreementType;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;

//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.adjustment.adjustment.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.AdjustmentType;
import com.splwg.ccb.domain.admin.serviceAgreementType.SaTypePaymentFreezeAlgorithmSpot;
import com.splwg.ccb.domain.admin.tenderSource.TenderSource;
import com.splwg.ccb.domain.admin.tenderSource.TenderSource_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.financial.financialTransaction.FinancialTransaction;
import com.splwg.ccb.domain.payment.payment.Payment;
import com.splwg.ccb.domain.payment.payment.PaymentSegment;
import com.splwg.ccb.domain.payment.payment.PaymentSegment_DTO;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentTender;*/

import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.payFreeze.SaTypePaymentFreezeAlgorithmSpot;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.ccb.domain.payment.payment.entity.PaymentSegment;
import com.splwg.ccb.domain.payment.payment.entity.PaymentSegment_DTO;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentTender;
//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author redizon
 *
 * @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentType, name = adjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = tenderSourceFeatureConfiguration, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = featureOptionTypeForTenderSourceCode, required = true, type = string)})
 */

public class CmArpCreditAdjustmentAlgComp_Impl 
	extends CmArpCreditAdjustmentAlgComp_Gen 
	implements SaTypePaymentFreezeAlgorithmSpot {

	// Soft Parameters
	private AdjustmentType parmAdjustmentType;
	private FeatureConfiguration parmFeatureConfiguration;
	private String parmTenderSourceOptionType;

	// Hard Parameters
	private FinancialTransaction ft;
	private Payment payment;
	private PaymentSegment paymentSegment;
	private ServiceAgreement sa;

	// Properties
	private List<TenderSource_Id> tenderSourceIdList = new ArrayList<TenderSource_Id>();
	private TenderSource_Id tenderSourceId;
	private Money adjustmentAmount;


	public void setFinancialTransaction(FinancialTransaction ft) {
		this.ft = ft;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

	public void setPaymentSegment(PaymentSegment paymentSegment) {
		this.paymentSegment = paymentSegment;
	}

	public void setServiceAgreement(ServiceAgreement sa) {
		this.sa = sa;
	}

	public void invoke() {
		cmRetrieveAndValidateTenderSourceOptionValues();

		// Check that the Tender Source of all Payment Tenders or the Payment's Payment Event are the same
		TenderSource previousTenderSource = null;
		for (PaymentTender paymentTender : payment.getPaymentEvent().getPaymentTenders()){
			if (isNull(previousTenderSource)){
				previousTenderSource = paymentTender.getTenderControlId().getEntity().getTenderSource();
				continue;
			}
			else {
				if (!previousTenderSource.equals(paymentTender.getTenderControlId().getEntity().getTenderSource())){
					addError(CustomMessageRepositoryMDC.na0050_PaymentEvenHasMultipleTenderSource(payment.getId().getTrimmedValue()));
				}
				previousTenderSource = paymentTender.getTenderControlId().getEntity().getTenderSource();
			}
		}
		tenderSourceId = previousTenderSource.getId();

		// If tenderSourceId is not in the tenderSourceList, create Adjustment and link it to the Payment Segment
		if (!tenderSourceIdList.contains(tenderSourceId)){
			// Create the ARP Credit Adjustment
			CreateFrozenAdjustmentData createFrozenAdjustment = CreateFrozenAdjustmentData.Factory.newInstance();
			createFrozenAdjustment.setServiceAgreement(sa);                             
			createFrozenAdjustment.setAdjustmentType(parmAdjustmentType);
			createFrozenAdjustment.setAllowZeroAmount(Bool.FALSE);

			Iterator<PaymentSegment> itrPaymentSegments = payment.getSegments().iterator();
			while (itrPaymentSegments.hasNext()){		
				PaymentSegment paymentSegment = itrPaymentSegments.next();
				if (paymentSegment.getServiceAgreement().equals(sa)){
					Money paymentAmount = paymentSegment.getPaySegmentAmount();
					BigDecimal fiftyPercentOfPayoff = sa.getPayoffBalance().getAmount().add(paymentAmount.getAmount()).divide(BigDecimal.valueOf(2));
					
                    // TIR_NA0050 RDizon Start Change
                    //BigInteger centsOfPayoff = sa.getPayoffBalance().getAmount().remainder(BigDecimal.ONE).multiply(BigDecimal.valueOf(100)).toBigInteger();
                    Money payoffBalanceBeforePayment = sa.getPayoffBalance().add(paymentAmount);
                    BigInteger centsOfPayoff = payoffBalanceBeforePayment.getAmount().remainder(BigDecimal.ONE).multiply(BigDecimal.valueOf(100)).toBigInteger();
                    // TIR_NA0050 RDizon End Change
                    
					// If Payment Segment Amount is 50% of the SA's Payoff Balance and the Payoff Balance cents is an odd number
					if ((paymentAmount.getAmount().compareTo(fiftyPercentOfPayoff) == 0)
							&& (centsOfPayoff.mod(BigInteger.valueOf(2)).compareTo(BigInteger.ONE) == 0)){
						BigDecimal amountForOddPayoffCents = paymentAmount.getAmount().subtract(BigDecimal.valueOf(0.01));
						adjustmentAmount = new Money(amountForOddPayoffCents, paymentAmount.getCurrencyId()).negate();
					}
					else {
						adjustmentAmount = paymentAmount.negate();
					}
					break;
				}
			}
			createFrozenAdjustment.setAdjustmentAmount(adjustmentAmount);
			createFrozenAdjustment = sa.createFrozenAdjustment(createFrozenAdjustment);

			// Link the newly created Adjustment to the Payment Segment
			PaymentSegment_DTO paymentSegmentDTO = paymentSegment.getDTO();
			paymentSegmentDTO.setAdjustmentId(createFrozenAdjustment.getAdjustment().getId());
			paymentSegment.setDTO(paymentSegmentDTO);
		}

		// If ARP SA's Payoff Balance is reduced to 0, synch the Current Balance
		if ((sa.getPayoffBalance().getAmount().compareTo(BigDecimal.ZERO) == 0) && (sa.getCurrentBalance().getAmount().compareTo(BigDecimal.ZERO) < 0)
                // TIR_NA0050 2013-03-26 - CVB Start
		    || (sa.getPayoffBalance().getAmount().compareTo(BigDecimal.ZERO) > 0) && (sa.getCurrentBalance().getAmount().compareTo(BigDecimal.ZERO) < 0)){
               // TIR_NA0050 2013-03-26 - CVB End
			PreparedStatement psFt = createPreparedStatement("UPDATE CI_FT ft "
					+ "SET ft.CUR_AMT = :newCurrentAmount "
					//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
					// + "WHERE ft.FT_ID = :ftId");
					+ "WHERE ft.FT_ID = :ftId", getClass().getName());
					//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
			psFt.bindBigDecimal("newCurrentAmount", ft.getCurrentAmount().subtract(sa.getCurrentBalance()).getAmount());
			psFt.bindId("ftId", ft.getId());
			psFt.executeUpdate();
			psFt.close();
		}
	}

	@Override
	protected void extraSoftParameterValidations(boolean arg0) {
		// Retrieve the Algorithm Parameters
		parmAdjustmentType = getAdjustmentType();
		parmFeatureConfiguration = getTenderSourceFeatureConfiguration();
		parmTenderSourceOptionType = getFeatureOptionTypeForTenderSourceCode();

		// Validate that the Option Type Parameter is a valid for the Feature Configuration parameter
		if (!isBlankOrNull(parmTenderSourceOptionType)){
			Bool isValidOptionType = Bool.FALSE;
			for (FeatureConfigurationOption featConfOption : parmFeatureConfiguration.getOptions()){
				if (parmTenderSourceOptionType.trim().equalsIgnoreCase(featConfOption.fetchIdOptionType())){
					isValidOptionType = Bool.TRUE;
				}
			}
			if (isValidOptionType.isFalse()){
				addError(CustomMessageRepositoryMDC.na0050_InvalidOptionTypeForFeatureConfiguration(parmTenderSourceOptionType, parmFeatureConfiguration.getId().getTrimmedValue()));
			}
		}
	}

	/**
	 * Retrieve and validate Tender Source Option Values
	 */
	private void cmRetrieveAndValidateTenderSourceOptionValues(){
		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		// ListFilter<FeatureConfigurationOption> featConfOptions = parmFeatureConfiguration.getOptions().createFilter("WHERE this.id.optionType = :optionType");
		ListFilter<FeatureConfigurationOption> featConfOptions = parmFeatureConfiguration.getOptions().
				createFilter("WHERE this.id.optionType = :optionType", getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		featConfOptions.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, parmTenderSourceOptionType.trim());

		Iterator<FeatureConfigurationOption> itrFeatConfigOptions = featConfOptions.iterate();
		while (itrFeatConfigOptions.hasNext()){
			FeatureConfigurationOption tenderSourceOption = itrFeatConfigOptions.next();
			String tenderSourceCodeStr = tenderSourceOption.getValue().trim();
			TenderSource_Id tenderSourceId = new TenderSource_Id(tenderSourceCodeStr);
			if (isNull(tenderSourceId.getEntity())){
				addError(CustomMessageRepositoryMDC.na0050_InvalidTenderSourceCodesOnFeatureConfiguration(tenderSourceCodeStr));
			}
			tenderSourceIdList.add(tenderSourceId);
		}
	}
}
