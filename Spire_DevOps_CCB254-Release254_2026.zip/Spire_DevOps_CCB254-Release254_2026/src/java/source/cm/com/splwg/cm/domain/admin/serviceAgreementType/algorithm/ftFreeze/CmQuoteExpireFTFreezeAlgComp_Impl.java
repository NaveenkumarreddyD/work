/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm will expire all Standard and CWR quotes whenever 
 * a payment is cancelled, when an adjustment is created or 
 * cancelled, or when a bill segment is created or cancelled 
 * (including final bill segments).
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2019-06-18	JHERNA		SysAid#171236. Original version was created by 
 *                          Origin (Marianne Pango) on 2018-11-14 for v2.4  
 *                          This is a complete overhaul to fix how the 
 *                          Quotes will be expired (by using the BO instead
 *                          of directly updating the field of the table so 
 *                          that life cycle BO algorithms will still be kicked
 *                          off). Also updated to make this 2.6 compatible.                                        
 * *************************************************************************                
 */
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.ftFreeze;

import java.util.Iterator;

import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.BusinessObjectStatusConditionLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus_Id;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.ftFreeze.SaTypeFtFreezeAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristics;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
import com.splwg.cm.api.lookup.CmQuotePortalParametersLookup;
import com.splwg.cm.api.lookup.ExternalSystemTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 90622
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = serviceTaskType, name = serviceTaskTypeQuote, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = boStatusQuoteExpire, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = charTypeHasQuote, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = charTypeSaId, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = charTypeQuoteSource, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = charValExcludedQuoteSources, required = true, type = string)})
 */
public class CmQuoteExpireFTFreezeAlgComp_Impl 
        extends CmQuoteExpireFTFreezeAlgComp_Gen
		implements SaTypeFtFreezeAlgorithmSpot {
	
	/* HARD PARAMETER */
	private Bool hpWasFinancialProcessAdded;
	private FinancialTransaction hpFT;
	private FinancialTransactionTypeLookup hpFTType;
	@SuppressWarnings("unused")
	private FinancialTransaction hpRegFT;
	
	/* SOFT PARAMETERS */
	private ServiceTaskType parmServiceTaskTypeQuote;
	private String parmBOStatusQuoteExpire;
	private CharacteristicType parmCharTypeHasQuote;
	private CharacteristicType parmCharTypeSAID;
	private CharacteristicType parmCharTypeQuoteSource;
	private String parmCharValExcludeQuoteSource;
	
	/* WORK VARIABLES */	
	private String wListOfExcludedQuoteSource;
	private BusinessObject_Id wBusinessObjectIDQuote;
	private ServiceAgreement wServiceAgreement;
	private String wAlgorithm;
	
	/* CONSTANTS */
	private CmMGEFeatureConfigurationOptionsRetriever FC_HELPER = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();	

	@Override
	public Bool getWasFinancialProcessAdded() {
		return hpWasFinancialProcessAdded;
	}

	@Override
	public void setFinancialTransaction(FinancialTransaction arg0) {
		hpFT = arg0;
		wServiceAgreement = hpFT.getServiceAgreement();
	}

	@Override
	public void setFinancialTransactionType(FinancialTransactionTypeLookup arg0) {
		hpFTType = arg0;
	}

	@Override
	public void setRegularFinancialTransaction(FinancialTransaction arg0) {
		hpRegFT = arg0;
	}
	
	protected void extraSoftParameterValidations(boolean arg0) {

		wAlgorithm = this.getAlgorithmId().getTrimmedValue();		
		
		FeatureConfiguration_Id featConfIDQuote = FC_HELPER.getFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_QUOTE_PORTAL_PARAMETERS);
		
		wBusinessObjectIDQuote = FC_HELPER.getBusinessObjectFeatureOptionValue(featConfIDQuote, 
				CmQuotePortalParametersLookup.constants.QUOTE_BUSINESS_OBJECT, Bool.TRUE, Bool.FALSE);
		// Retrieve Parameter 10: Quote service task type
		parmServiceTaskTypeQuote = this.getServiceTaskTypeQuote();
		// Retrieve and validate parameter 20: BO status for expired quote
		parmBOStatusQuoteExpire = this.getBoStatusQuoteExpire().trim();
		BusinessObject_Id transServiceTaskBOId = parmServiceTaskTypeQuote.getRelatedTransactionBO().getId();
		String svcTaskBoName = transServiceTaskBOId.getIdValue().trim();
		BusinessObjectStatus quoteExpireStatus = new BusinessObjectStatus_Id(transServiceTaskBOId,parmBOStatusQuoteExpire).getEntity();

		if(isNull(quoteExpireStatus)){
			addError(CustomMessageRepository.sa171236InvalidInputExpireBOStatus(parmBOStatusQuoteExpire,svcTaskBoName,parmServiceTaskTypeQuote.getId().getTrimmedValue()));
		}
		// Retrieve and validate parameter 30: Has Quote Characteristic Type
		parmCharTypeHasQuote = this.getCharTypeHasQuote();
		validateCharType(parmCharTypeHasQuote, CharacteristicEntityLookup.constants.SERVICE_TASK, "Has Quote Char Type");
		// Retrieve and validate parameter 40: SA ID Characteristic Type
		parmCharTypeSAID = this.getCharTypeSaId();
		validateCharType(parmCharTypeSAID, CharacteristicEntityLookup.constants.SERVICE_TASK, "SA ID Char Type");
		// Retrieve and validate parameter 50: Quote Source Characteristic Type
		parmCharTypeQuoteSource = this.getCharTypeQuoteSource();
		validateCharType(parmCharTypeQuoteSource, CharacteristicEntityLookup.constants.SERVICE_TASK, "Quote Source Char Type");
		// Retrieve, validate and store parameter 60: List of excluded quote sources
		parmCharValExcludeQuoteSource = this.getCharValExcludedQuoteSources();
		
		String[] listOfCharVals = parmCharValExcludeQuoteSource.split(",");
		if(listOfCharVals.length == 0){
			addError(CustomMessageRepository.sa171236quoteSourceListInvalid(parmCharValExcludeQuoteSource));
		}
		
		wListOfExcludedQuoteSource = " ";
		for (int x = 0; x < listOfCharVals.length; x++) {
			
			String excludedQuoteSource = listOfCharVals[x];
			wListOfExcludedQuoteSource = wListOfExcludedQuoteSource.trim().concat("'");
			wListOfExcludedQuoteSource = wListOfExcludedQuoteSource.trim().concat(excludedQuoteSource);
			wListOfExcludedQuoteSource = wListOfExcludedQuoteSource.trim().concat("',");	
		}
		wListOfExcludedQuoteSource = wListOfExcludedQuoteSource.substring(0, (wListOfExcludedQuoteSource.length() - 1));
		
	}
	
	private void validateCharType(CharacteristicType charType, CharacteristicEntityLookup entity, String description) {
		
		CharacteristicEntity_Id charEntityID = new CharacteristicEntity_Id(charType, entity);
		if (isNull(charEntityID.getEntity())) {
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharTypeNotValidForEntity(
					wAlgorithm,
					description, 
					charType.getId().getTrimmedValue(),
					entity.getLookupValue().fetchLanguageDescription().trim()));
		}
	}

	@Override
	public void invoke() {
				
		/* Do nothing if the FT is for a payment segment */
		if (!hpFTType.isPaySegment()) {
			
			Iterator<SQLResultRow> iterActiveQuotes = retrieveActiveQuotes(wServiceAgreement.getId());
			
			while (iterActiveQuotes.hasNext()) {
				
				SQLResultRow sqlRow = (SQLResultRow) iterActiveQuotes.next();
				ServiceTask_Id quoteID = (ServiceTask_Id) sqlRow.getId("F1_SVC_TASK_ID", ServiceTask.class);
				/*==================*/
				/* Expire the Quote */
				/*==================*/				
				// Retrieve the Quote BO Instance				
				BusinessObjectInstance boInstance = BusinessObjectInstance.create(wBusinessObjectIDQuote.getEntity());
				boInstance.setXMLString("serviceTaskId", quoteID.getTrimmedValue());
				
				BusinessObjectInstance quoteBO = BusinessObjectDispatcher.read(boInstance);
				quoteBO.setXMLString("status", parmBOStatusQuoteExpire.trim());
				quoteBO.set("statusDateTime", this.getProcessDateTime());
				
				BusinessObjectDispatcher.update(quoteBO);
				
				/*==========================*/
				/* Delete SA Characteristic */
				/*==========================*/
				deleteSACharacteristic(wServiceAgreement, parmCharTypeHasQuote);
			}			
		}
	}
	
	private Iterator<SQLResultRow> retrieveActiveQuotes(ServiceAgreement_Id saID){
		
		Iterator<SQLResultRow> returnValue = null;

        StringBuilder stringBuilder = new StringBuilder();                
        stringBuilder.append("SELECT ");
        stringBuilder.append("    QUOTE.F1_SVC_TASK_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append("    F1_SVC_TASK QUOTE, "); 
        stringBuilder.append("    F1_SVC_TASK_CHAR QCHAR, ");
        stringBuilder.append("    F1_BUS_OBJ_STATUS BOSTAT ");    
        stringBuilder.append("WHERE ");
        stringBuilder.append("    QUOTE.F1_STASK_TYPE_CD = :svcTaskTypeQuote ");
        stringBuilder.append("    AND BOSTAT.BUS_OBJ_CD = QUOTE.BUS_OBJ_CD ");
        stringBuilder.append("    AND BOSTAT.BO_STATUS_CD = QUOTE.BO_STATUS_CD ");
        stringBuilder.append("    AND BOSTAT.BO_STATUS_COND_FLG != :final ");
        stringBuilder.append("    AND QCHAR.F1_SVC_TASK_ID = QUOTE.F1_SVC_TASK_ID ");
        stringBuilder.append("    AND QCHAR.CHAR_TYPE_CD = :charTypeSAID ");
        stringBuilder.append("    AND QCHAR.SRCH_CHAR_VAL = :saID ");
        stringBuilder.append("    AND EXISTS (SELECT 'X' ");
        stringBuilder.append("                FROM F1_SVC_TASK_CHAR QC ");
        stringBuilder.append("                WHERE QC.F1_SVC_TASK_ID = QUOTE.F1_SVC_TASK_ID ");
        stringBuilder.append("                AND QC.CHAR_TYPE_CD = :charTypeQuoteSource ");
        stringBuilder.append("                AND QC.SRCH_CHAR_VAL NOT IN ("+wListOfExcludedQuoteSource+") ");
        stringBuilder.append("                ) ");
        
        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), 
        		"=CmQuoteExpireFTFreezeAlgComp_Impl.retrieveActiveQuotes=");
        prepState.bindId("svcTaskTypeQuote", parmServiceTaskTypeQuote.getId());
        prepState.bindLookup("final", BusinessObjectStatusConditionLookup.constants.FINAL);
        prepState.bindId("charTypeSAID", parmCharTypeSAID.getId());
        prepState.bindId("saID", saID);
        prepState.bindId("charTypeQuoteSource", parmCharTypeQuoteSource.getId());
        prepState.setAutoclose(false);
        prepState.execute();
        returnValue = prepState.list().iterator();        
        prepState.close();
        return returnValue;
	}
	
	private void deleteSACharacteristic(ServiceAgreement serviceAgreement, CharacteristicType characteristicType) {
		
		// Check if a characteristic of the type exists and remove them			
		ServiceAgreementCharacteristics saChars = serviceAgreement.getCharacteristics();
		if (notNull(saChars)) {
			Iterator<ServiceAgreementCharacteristic> saCharIter = saChars.iterator();
			while (saCharIter.hasNext()) {
				ServiceAgreementCharacteristic saChar = saCharIter.next();
				CharacteristicType saCharType = saChar.fetchIdCharacteristicType();
				if (saCharType.equals(characteristicType)) {
					saCharIter.remove();
				}
			}
		}			
	}
}
