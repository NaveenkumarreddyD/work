/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NA0073 - Field Activity Completion - Field Charge Algorithm
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-02-08   Rakesh          NA0073. Initial Version.
 * 2013-02-19   Rakesh          Incorporated Code Review Comments
 * 2013-03-15   Rakesh          TIR2_NA0073 - Removed the logic to exit processing when 
 *                              Account ID was not defined as a char on Completed FA. Also
 *                              included null checks for this char at other places.
 * 2013-03-15   Rakesh          Modified to create an Adjustment or Billable Charge ID 
 *                              Characteristic entry on the FA instead of FT ID Char entry.
 * 2013-05-29   JPunza          TIR6. Modified to skip the creation of the Adjustments or
 *                              Billable Charge if the total amount is zero.      
 * 2013-06-06	Karthik			KL20130606 - Fix for Defect 1972 - Modified the logic to  
 * 								create a to do and exit processing when account associated 
 * 								to the current FA was not found.   
 * 2013-06-17	Karthik			KL20130617 - Fix for Defect 2279 - New changes. Process the 
 * 								adjustment on the current account if 'Charge Another Account 
 * 								Flag' is set to 'Y' and account is not specified as FA Char.
 * 								Also, disable creation of all the ToDos.     
 * 2013-06-25	Karthik			KL20130625 - Defect fix for #2495, #2279 & #2539  
 * 2013-06-26	Karthik			KL20130626 - Defect fix for #2598 - set currency on the SA 
 * 								while creating a new SA
 * 2013-07-24	Karthik			KL20130724 - Fix for IM-034446: ToDo is getting created even 
 * 								though a valid value of Zero is being passed.
 * 2013-10-18	Karthik			KL20131018 - Fix for IM-034868. While retrieving the linked 
 * 								account, if more than one SA is linked to the Char Prem Id,  
 * 								the SA Status is used to pick the appropriate SA. Active SAs 
 * 								are given the highest priority followed by Stopped SAs and 
 * 								then any non-cancelled SA.
 * 2015-09-11	JHERNA			3298881. updated the retrieval of associated Account.
 * 								- moved the package to the correct location 
 * 									com.splwg.cm.domain.admin.fieldActivityType
 * 2016-01-26   MPang			Updated for CCB v2.4 compilation.
 * 2018-07-25   SFelip          CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                              longer needed.   
 * 2021-07-15   RDizon          CCB37.4. Copy Tax Exemptions from Gas SAs for the created SA.                              
 * 2021-07-15   GCrisp          Defect 44598508. Add null checker for the value returned by 
 *                              getActiveSAsWithTaxExemptions method.
 * 2022-01-06   JVitug/FRoig    B-19769. Added creation of payment arrangements. Updated
 * 								conditions on reusing existing Service Work SAs.
 * 2022-02-15   AshishR         B-20934. Set account to charAccount if Bill 2 Account set on
 *                              characteristic; without it createPaymentArrangement fails
 ******************************************************************************************/
//package com.splwg.cm.domain.admin.faType;
package com.splwg.cm.domain.admin.fieldActivityType;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
//Start Add JVitug - B-19769 - 2021-12-29
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessService.BusinessServiceDispatcher;
import com.splwg.base.api.businessService.BusinessServiceInstance;
//End Add JVitug - B-19769 - 2021-12-29
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.algorithmType.AlgorithmTypeParameter_Id;
import com.splwg.base.domain.common.algorithmType.AlgorithmTypeParameter_LanguageId;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.currency.Currency_Id;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_Id;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeSortKeyTypes;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ContractTermTypeLookup;
import com.splwg.ccb.api.lookup.CopyOptionForProposalSALookup;
import com.splwg.ccb.api.lookup.CustomerReadLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.StartReasonLookup;
//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.adjustment.adjustment.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.adjustment.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.AdjustmentType;
import com.splwg.ccb.domain.admin.billableChargeTemplate.BillableChargeTemplate;
import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityTypeFaCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType_Id;
import com.splwg.ccb.domain.billing.billableCharge.BillableCharge;
import com.splwg.ccb.domain.billing.billableCharge.BillableChargeLine;
import com.splwg.ccb.domain.billing.billableCharge.BillableChargeLine_DTO;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.premise.Premise;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCreator;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCreatorData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristics;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoMaintenanceData;*/
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.billableChargeTemplate.entity.BillableChargeTemplate;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.fieldActivityType.algorithm.faCompletion.FieldActivityTypeFaCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.servicePointType.entity.ServicePointType;
import com.splwg.ccb.domain.billing.billableCharge.entity.BillableCharge;
import com.splwg.ccb.domain.billing.billableCharge.entity.BillableChargeLine;
import com.splwg.ccb.domain.billing.billableCharge.entity.BillableChargeLine_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.common.ServiceAgreementCreator;
import com.splwg.ccb.domain.customerinfo.data.ServiceAgreementCreatorData;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementContractTerm;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementContractTerm_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristics;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
import com.splwg.ccb.domain.todo.common.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.data.ToDoMaintenanceData;
//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.api.lookup.CmAdjOrBillableChargeLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

//Start Change JVitug - B-19769 - 2021-12-29
///**
//*
// @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
//*            , @AlgorithmSoftParameter (entityName = cisDivision, name = cisDivision, required = true, type = entity)
//*            , @AlgorithmSoftParameter (name = serviceAgreementType, required = true, type = string)
//*            , @AlgorithmSoftParameter (name = chargeAnotherAccountFlg, required = true, type = boolean)
//*            , @AlgorithmSoftParameter (name = faCharStoreAmountFlg, required = true, type = boolean)
//*            , @AlgorithmSoftParameter (lookupName = cmAdjOrBillableCharge, name = adjOrBillableCharge, required = true, type = lookup)
//*            , @AlgorithmSoftParameter (entityName = characteristicType, name = accountIdCharType, required = true, type = entity)
//*            , @AlgorithmSoftParameter (entityName = adjustmentType, name = adjType1, type = entity)
//*            , @AlgorithmSoftParameter (entityName = adjustmentType, name = adjType2, type = entity)
//*            , @AlgorithmSoftParameter (entityName = adjustmentType, name = adjType3, type = entity)
//*            , @AlgorithmSoftParameter (entityName = adjustmentType, name = adjType4, type = entity)
//*            , @AlgorithmSoftParameter (entityName = adjustmentType, name = adjType5, type = entity)
//*            , @AlgorithmSoftParameter (entityName = billableChargeTemplate, name = billableChargeTemplate, type = entity)
//*            , @AlgorithmSoftParameter (entityName = characteristicType, name = amountCharType1, type = entity)
//*            , @AlgorithmSoftParameter (entityName = characteristicType, name = amountCharType2, type = entity)
//*            , @AlgorithmSoftParameter (entityName = characteristicType, name = amountCharType3, type = entity)
//*            , @AlgorithmSoftParameter (entityName = characteristicType, name = amountCharType4, type = entity)
//*            , @AlgorithmSoftParameter (entityName = characteristicType, name = amountCharType5, type = entity)
//*            , @AlgorithmSoftParameter (entityName = characteristicType, name = adjIdCharType, required = true, type = entity)
//*            , @AlgorithmSoftParameter (entityName = characteristicType, name = billableChargeIdCharType, required = true, type = entity)})
//*/

/**
 *
  @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = cisDivision, name = cisDivision, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = serviceAgreementType, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = chargeAnotherAccountFlg, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (name = faCharStoreAmountFlg, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (lookupName = cmAdjOrBillableCharge, name = adjOrBillableCharge, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = accountIdCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = adjType1, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = adjType2, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = adjType3, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = adjType4, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = adjType5, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billableChargeTemplate, name = billableChargeTemplate, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = amountCharType1, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = amountCharType2, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = amountCharType3, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = amountCharType4, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = amountCharType5, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = adjIdCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = billableChargeIdCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = shouldCreatePaymentArrangement, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (name = PASAType, required = false, type = string)
 *            , @AlgorithmSoftParameter (name = numberOfInstallments, type = integer)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, required = true, name = adjTypeJobPaXfer, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = chargeAsFlatFeeCharacteristicType, type = entity)})
 */
//End Change JVitug - B-19769 - 2021-12-29
public class CmFieldChargeForFAAlgComp_Impl 
		extends CmFieldChargeForFAAlgComp_Gen 
		implements FieldActivityTypeFaCompletionAlgorithmSpot {

	private FieldActivity currentFA;
	private Account account;
	// KL20130625 - Start of defect fix for #2539
	private Premise currentPremise;
	// KL20130625 - End of defect fix for #2539

	/*
	 * Start Delete - 2013-05-29 - JPunza 
	 */
	//private ToDoType parmToDoType = null;
	/*
	 * End Delete - 2013-05-29 - JPunza 
	 */
	private CisDivision parmCisDivision=null;
	private String parmSaType = null;
	private Bool parmChargeAnotherAccountFlg = null;
	private Bool parmFaCharStoreAmountFlg = null;
	private CharacteristicType parmAccountIdCharType = null;
	private CmAdjOrBillableChargeLookup parmAdjOrBillable=null;
	private AdjustmentType parmAdjType1 = null;
	private AdjustmentType parmAdjType2 = null;
	private AdjustmentType parmAdjType3 = null;
	private AdjustmentType parmAdjType4 = null;
	private AdjustmentType parmAdjType5 = null;
	private BillableChargeTemplate parmBillableChargeTemplate=null;
	private CharacteristicType parmAmountCharType1= null;
	private CharacteristicType parmAmountCharType2 = null;
	private CharacteristicType parmAmountCharType3 = null;
	private CharacteristicType parmAmountCharType4 = null;
	private CharacteristicType parmAmountCharType5 = null;
	private CharacteristicType parmAdjIdCharType = null;
	private CharacteristicType parmBillableChargeIdCharType = null;
	private ServiceAgreementType_Id saTypeId;
	//KL20130617 - Start of defect fix for 2279
	private boolean shouldCreateToDoEntry = false;
	private ServiceAgreement saToBeCharged = null;
	//KL20130617 - End of defect fix for 2279
	//KL20130625 - Start of defect fix for 2279
	private BigDecimal amount1Val = BigDecimal.ZERO;
	private BigDecimal amount2Val = BigDecimal.ZERO;
	private BigDecimal amount3Val = BigDecimal.ZERO;
	private BigDecimal amount4Val = BigDecimal.ZERO;
	private BigDecimal amount5Val = BigDecimal.ZERO;
	//KL20130625 - End of defect fix for 2279
	// KL20130626 - Start of defect fix for #2598
	private Currency_Id currencyId = null;
	// KL20130626 - End of defect fix for #2598
	//Start Add JVitug - B-19769 - 12-29-2021
	private String paymentArrangementSAType;
	private CharacteristicType chargeAsFlatFeeCharacteristicType;
	private BigInteger numberOfInstallments;
	private Bool shouldCreatePaymentArrangement;
	private Bool chargeAsFlatFee;
	private AdjustmentType parmAdjTypeJobPaXfer = null;
	//End Add JVitug - B-19769 - 12-29-2021

	private static final Logger logger = LoggerFactory
			.getLogger(CmFieldChargeForFAAlgComp_Impl.class);

	public void setFieldActivity(FieldActivity arg0) {
		currentFA=arg0;
	}

	protected void extraSoftParameterValidations(boolean arg0) {
		initializeSoftParams();
		validateSoftParams();
	}

	private void validateSoftParams(){     

		if(parmChargeAnotherAccountFlg.isTrue() && isNull(parmAccountIdCharType)){
			addError(CustomMessageRepository.na0073AccountCharTypeRequired(getAlgorithmParameterName(BigInteger.valueOf(40)),getAlgorithmParameterName(BigInteger.valueOf(70))));
		}

		if(parmAdjOrBillable.isA() && isNull(parmAdjType1)){
			addError(CustomMessageRepository.na0073AdjustmentType1Required(getAlgorithmParameterName(BigInteger.valueOf(80)),getAlgorithmParameterName(BigInteger.valueOf(60))));
		}

		if(parmAdjOrBillable.isB() && (isNull(parmBillableChargeTemplate) || isNull(parmAmountCharType1))){
			addError(CustomMessageRepository.na0073BillableChargeRequired(getAlgorithmParameterName(BigInteger.valueOf(130)),getAlgorithmParameterName(BigInteger.valueOf(140)),getAlgorithmParameterName(BigInteger.valueOf(60))));
		}

		if(parmFaCharStoreAmountFlg.isTrue() && isNull(parmAmountCharType1)){
			addError(CustomMessageRepository.na0073parmAmountCharType1Required(getAlgorithmParameterName(BigInteger.valueOf(140)),getAlgorithmParameterName(BigInteger.valueOf(50))));
		}

		//sa type validation
		validateSAType(parmCisDivision, parmSaType.trim(), BigInteger.valueOf(30));

		//accountIdCharType
		if(notNull(parmAccountIdCharType)){
			validateCharType(parmAccountIdCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY, BigInteger.valueOf(70));           
		}
		//amountCharType1
		if(notNull(parmAmountCharType1)){
			validateCharType(parmAmountCharType1, CharacteristicEntityLookup.constants.FIELD_ACTIVITY, BigInteger.valueOf(140));           
		}

		//amountCharType2
		if(notNull(parmAmountCharType2)){
			validateCharType(parmAmountCharType2, CharacteristicEntityLookup.constants.FIELD_ACTIVITY, BigInteger.valueOf(150));           
		}
		//amountCharType3
		if(notNull(parmAmountCharType3)){
			validateCharType(parmAmountCharType3, CharacteristicEntityLookup.constants.FIELD_ACTIVITY, BigInteger.valueOf(160));           
		}
		//amountCharType4
		if(notNull(parmAmountCharType4)){
			validateCharType(parmAmountCharType4, CharacteristicEntityLookup.constants.FIELD_ACTIVITY, BigInteger.valueOf(170));           
		}
		//amountCharType5
		if(notNull(parmAmountCharType5)){
			validateCharType(parmAmountCharType5, CharacteristicEntityLookup.constants.FIELD_ACTIVITY, BigInteger.valueOf(180));           
		}
		//Adjustment Id Char Type
		if(notNull(parmAdjIdCharType)){
			validateCharType(parmAdjIdCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY, BigInteger.valueOf(190));
		}
		//Billable Charge Id Char Type
		if(notNull(parmBillableChargeIdCharType)){
			validateCharType(parmBillableChargeIdCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY, BigInteger.valueOf(200));
		}
		
		//Start Add JVitug - B-19769 - 2021-12-29
		if (shouldCreatePaymentArrangement.isTrue()) {
			//If we should create a payment arrangement, PA SA Type and Number of installments is required.
			if (isBlankOrNull(paymentArrangementSAType)) {
				addError(CustomMessageRepository.b19769PaymentArrangementIsRequired(getAlgorithmParameterName(BigInteger.valueOf(220))));
			} else {
				//Validate that the Payment Arrangement SA Type exists and is valid for the CIS Division
				validatePASAType(parmCisDivision, paymentArrangementSAType.trim(), BigInteger.valueOf(220));
			}
			
			if (isNull(numberOfInstallments)) {
				addError(CustomMessageRepository.b19769NumberOfInstallmentsIsRequired(getAlgorithmParameterName(BigInteger.valueOf(230))));
			} else {
				//Validate that the number of installments is greater than zero
				if(numberOfInstallments.compareTo(BigInteger.ZERO) <= 0) {
					addError(CustomMessageRepository.b19769NumberOfInstallmentsShouldBeGreaterThanZero(getAlgorithmParameterName(BigInteger.valueOf(230))));
				}
			}
			
			if (isNull(chargeAsFlatFeeCharacteristicType)) {
				addError(CustomMessageRepository.b19769PaymentArrangementIsRequired(getAlgorithmParameterName(BigInteger.valueOf(250))));
			} else {
				//Validate that the characteristic type for the Should Charge as Flat Fee on FA Completion is valid for the Field Activity Entity
				validateCharType(chargeAsFlatFeeCharacteristicType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY, BigInteger.valueOf(250));
			}
		}
		//End Add JVitug - B-19769 - 2021-12-29
	}
	
	//Start Add JVitug - B-19769 - 2021-12-29
	/**
	 * Validate the PA SA Type if it exists. 
	 * @param cisdivision
	 * @param strSAType
	 * @param paramSeq
	 */
	private void validatePASAType(CisDivision cisdivision, String strSAType, BigInteger paramSeq){

		ServiceAgreementType_Id validator = new ServiceAgreementType_Id(cisdivision,strSAType);
		if(isNull(validator.getEntity())){
			addError(CustomMessageRepository.na0073InvalidServiceAgreementType(getAlgorithmParameterName(paramSeq), strSAType, cisdivision.getId().getTrimmedValue())); 
		}
	}
	//End Add JVitug - B-19769 - 2021-12-29

	public void validateSAType(CisDivision cisdivision, String strSAType, BigInteger paramSeq){

		saTypeId = new ServiceAgreementType_Id(cisdivision,strSAType);
		if(isNull(saTypeId.getEntity())){
			addError(CustomMessageRepository.na0073InvalidServiceAgreementType(getAlgorithmParameterName(paramSeq), strSAType, cisdivision.getId().getTrimmedValue())); 
		}
	}

	private void validateCharType(CharacteristicType charType,CharacteristicEntityLookup lookup, BigInteger seq){

		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, lookup);
		if (isNull(charEntityId.getEntity())){
			addError(CustomMessageRepository.na0073InvalidInputCharTypeForEntity(getAlgorithmParameterName(seq), charType.getId().getTrimmedValue(),lookup.getLookupValue().fetchIdFieldValue()));
		} 
	}


	private String getAlgorithmParameterName(BigInteger paramSeq){

		String paramName = "";      
		AlgorithmTypeParameter_Id algorithmTypeParameterId = new AlgorithmTypeParameter_Id(getAlgorithm().getAlgorithmType(), paramSeq);        
		AlgorithmTypeParameter_LanguageId algorithmTypeParameterLanguageId = new AlgorithmTypeParameter_LanguageId(algorithmTypeParameterId, getActiveContextLanguage().getId());       
		paramName = algorithmTypeParameterLanguageId.getParent().fetchLanguageParameterLabel();
		return paramName;
	}

	private void initializeSoftParams(){        
		/*
		 * Start Delete - 2013-05-29 - JPunza 
		 */
		//parmToDoType = getToDoType();
		/*
		 * End Delete - 2013-05-29 - JPunza 
		 */
		parmCisDivision=getCisDivision();
		parmSaType = getServiceAgreementType();  
		parmChargeAnotherAccountFlg = getChargeAnotherAccountFlg();
		parmFaCharStoreAmountFlg = getFaCharStoreAmountFlg();
		parmAccountIdCharType = getAccountIdCharType();
		parmAdjOrBillable=getAdjOrBillableCharge();
		parmAdjType1 = getAdjType1();
		parmAdjType2 = getAdjType2();
		parmAdjType3 = getAdjType3();
		parmAdjType4 = getAdjType4();
		parmAdjType5 = getAdjType5();
		parmBillableChargeTemplate=getBillableChargeTemplate();
		parmAmountCharType1= getAmountCharType1();
		parmAmountCharType2 = getAmountCharType2();
		parmAmountCharType3 = getAmountCharType3();
		parmAmountCharType4 = getAmountCharType4();
		parmAmountCharType5 = getAmountCharType5();
		parmAdjIdCharType = getAdjIdCharType();
		parmBillableChargeIdCharType = getBillableChargeIdCharType();
		
		//Start Add JVitug - B-19769 - 2021-12-29
		paymentArrangementSAType = getPASAType();
		numberOfInstallments = getNumberOfInstallments();
		shouldCreatePaymentArrangement = getShouldCreatePaymentArrangement();
		chargeAsFlatFeeCharacteristicType = getChargeAsFlatFeeCharacteristicType();
		parmAdjTypeJobPaXfer = getAdjTypeJobPaXfer();
		//End Add JVitug - B-19769 - 2021-12-29
	}

	public void invoke() {

		logger.info("IM-034868 ----------Control entered into Field Charge Algoroithm---------");
		if(isAllAmountCharValsZeros()){
			return;
		}
		
		//Start Add FRoig - B-19769 - 2022-01-06
		//Get the Action Flag Characteristic Type from the FA
		chargeAsFlatFee = Bool.FALSE;
		if (shouldCreatePaymentArrangement.isTrue() && notNull(chargeAsFlatFeeCharacteristicType)) {
			ListFilter<FieldActivityCharacteristic> chargeAsFlatFeeListFilter = currentFA.
					getCharacteristics().createFilter("where this.id.characteristicType = :charType " +
			                "order by this.id.sequence desc ", getClass().getName());
			chargeAsFlatFeeListFilter.bindEntity("charType", chargeAsFlatFeeCharacteristicType);
			FieldActivityCharacteristic chargeAsFlatFeeCharacteristic = chargeAsFlatFeeListFilter.firstRow();
			if (notNull(chargeAsFlatFeeCharacteristic)) {
				chargeAsFlatFee = Bool.TRUE;
			}
		}
		//End Add FRoig - B-19769 - 2022-01-06
		logger.info("Retrive Account Char ID");
		Account charAccount = retrieveCharAccountId();
		//Start Add AshishR - B-20934 - 2022-02-15
		if (notNull(charAccount))
			account = charAccount;
		//End Add AshishR - B-20934 - 2022-02-15		
		//KL20130617 - Start of fix for Defect 2279 -  Per Fred, commented out the below logic and added new processing
		//KL20130606 - Start of fix for Defect 1972
		//		if(parmChargeAnotherAccountFlg.isTrue() && isNull(charAccount)){
		//			return;
		//		}
		//account = retrieveAccountId();
		//KL20130606 - End of fix for Defect 1972
		
		//KL20130625 - Start of fix for Defect 2539
		if((parmChargeAnotherAccountFlg.isTrue() && isNull(charAccount)) || parmChargeAnotherAccountFlg.isFalse()){
		//KL20130625 - End of fix for Defect 2539
			
			//KL20131018 - Start of fix for IM-034868
			//List<SQLResultRow> associatedAccountsList = retrieveAccountAssociatedToCurrentFA();
			//Retrieve based on Active SAs
			List<SQLResultRow> associatedAccountsList = retrieveAccountAssociatedToCurrentFA(true, false, false);
			
			if(isNull(associatedAccountsList) || associatedAccountsList.isEmpty()){
				//Retrieve based on Stopped SAs
				associatedAccountsList = retrieveAccountAssociatedToCurrentFA(false, true, false);
			}
			if(isNull(associatedAccountsList) || associatedAccountsList.isEmpty()){
				//Retrieve based on Non-Canceled SAs
				associatedAccountsList = retrieveAccountAssociatedToCurrentFA(false, false, true);
			}
			
			//KL20131018 - Start of fix for IM-034868
			if(isNull(associatedAccountsList) || associatedAccountsList.isEmpty()){
				//if(isNull(account)){
				// If no account is associated, error out so that the user will not be able to complete FA until 
				// an associated account is created
				addError(CustomMessageRepository.na0073NoValidAccountAssociatedToFA(currentFA.getId().getTrimmedValue()));
			} else if (associatedAccountsList.size() > 1){
				// In case of multiple accounts associated to FA, we need to allow the FA to be completed with a to do 
				// so that some one can work on it without the FA waiting for them to complete.
				createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_MORE_THAN_ONE_ACCOUNT_ASSOCIATED_TO_FA),currentFA.getId().getIdValue().trim());
				return;
			}
			account = associatedAccountsList.get(0).getEntity("ACCT_ID", Account.class);
			if(isNull(account)){
				return;
			}
			//KL20130625 - Start of fix for Defect 2539
			//Per Fred, process the adjustment on the current account if the other account is not provided as FA Char,
			// in spite of the 'Charge Another Account Flag' being set to 'Y' on the Algorithm.
			charAccount = account;
			//KL20130625 - End of fix for Defect 2539
		}
		//KL20130625 - Start of fix for Defect 2539
		//createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_MORE_THAN_ONE_ACCOUNT_ASSOCIATED_TO_FA),currentFA.getId().getIdValue().trim());
		
		//Per Fred, process the adjustment on the current account if the other account is not provided as FA Char,
		// in spite of the 'Charge Another Account Flag' being set to 'Y' on the Algorithm.
		//if(parmChargeAnotherAccountFlg.isTrue() && isNull(charAccount)){
		//	charAccount = account;
		//}
		//KL20130625 - End of fix for Defect 2539
		//KL20130617 - End of fix for Defect 2279

		/*
		 * Start Change - 2013-05-29 - JPunza 
		 */
		//Premise currentPremise = retrievePremise();
		currentPremise = currentFA.getServicePoint().getPremise();
		/*
		 * End Change - 2013-05-29 - JPunza 
		 */
		//KL20130617 - Start of defect fix for 2279
		//ServiceAgreement saToBeCharged = null;
		//KL20130617 - End of defect fix for 2279
		BillableCharge billableCharge;

		/*
		 * Start Change - 2013-05-29 - JPunza 
		 */
		//Adjustment adj1=null;
		//Adjustment adj2=null;
		//Adjustment adj3=null;
		//Adjustment adj4=null;
		//Adjustment adj5=null;

		//KL20130625 - Start of defect fix for 2279
		Money amount1 = Money.ZERO;
		Money amount2 = Money.ZERO;
		Money amount3 = Money.ZERO;
		Money amount4 = Money.ZERO;
		Money amount5 = Money.ZERO;
		//KL20130625 - Start of defect fix for 2279
		/*
		 * End Change - 2013-05-29 - JPunza 
		 */

		if(parmChargeAnotherAccountFlg.isTrue() && notNull(charAccount) ){ //&& !(charAccount.getId().equals(account.getId()))){
		    // KL20130626 - Start of defect fix for #2598
			currencyId = charAccount.getCurrency().getId();
			// KL20130626 - End of defect fix for #2598
			//KL20130625 - Start of defect fix for #2539 - removed premise being passed as a paramter and made it a global variable
			if(!hasSA(charAccount)){
				// Create SA
				saToBeCharged = createSA(charAccount);
			}
			//KL20130625 - End of defect fix for #2539
		}

		//KL20130617 - Start of fix for Defect 2279 - commented below code as this validation is not required
		/**
		 * Commented out unwanted To Do Creation
		 * 
		if(parmChargeAnotherAccountFlg.isFalse() && notNull(account) && notNull(charAccount) && !(charAccount.getId().equals(account.getId()))){         
			//Create ToDo
			if(this.isOnlineConnection()){
				addError(CustomMessageRepository.na0073FANotEligible(currentFA.getId().getTrimmedValue()));
			}else{
				createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_FA_NOT_ELIGIBLE),currentFA.getId().getIdValue().trim());
			}
			if(!hasSA(account, currentPremise)){
				sa = createSA(currentPremise.getId() , account);
			}
		}

		if(!(isNull(charAccount)) && !(isNull(account)) &&  charAccount.getId().equals(account.getId())){           
			//Create ToDo
			if(this.isOnlineConnection()){
				addError(CustomMessageRepository.na0073InvalidCharAccountAndAccount());
			}else{
				createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_INVALID_CHAR_ACCOUNT_AND_ACCOUNT),null);
			}
			if(!hasSA(account, currentPremise)){
				sa = createSA(currentPremise.getId() , account);
			}
		}
		 */

		//if(parmChargeAnotherAccountFlg.isFalse() &&  isNull(charAccount)) {
		if(parmChargeAnotherAccountFlg.isFalse()) {
			//KL20130617 - End of fix for Defect 2279

			// KL20130626 - Start of defect fix for #2598
			currencyId = account.getCurrency().getId();
			// KL20130626 - End of defect fix for #2598

			//KL20130625 - Start of defect fix for #2539 - removed premise being passed as a paramter and made it a global variable
			if(!hasSA(account)){
				saToBeCharged = createSA(account);
			}
			//KL20130625 - End of defect fix for #2539
		}

		if(notNull(saToBeCharged) && parmFaCharStoreAmountFlg.isTrue()){

			if(parmAdjOrBillable.isA()){
				
				if(notNull(parmAdjType1) && notNull(parmAmountCharType1)){
					/*
					 * Start Change - 2013-05-29 - JPunza 
					 */
					//if(!isNull(retrieveCharValue(sa,parmAmountCharType1))){
					//    //Create Adjustment(adj1) of Type adjType1 for above selected SA
					//    adj1 = createAdjustment(sa.getId(),parmAdjType1,retrieveCharValue(sa,parmAmountCharType1)) ;
					//    //Set FA Characteristic (Char Type = ftIdCharType, Char Val Fk1=ftId)
					//    createCharOnFA(parmAdjIdCharType, adj1.getId().getIdValue().trim());
					//}else{

					// KL20130625 - Start of fix for defect 2279
					//amount1 = retrieveCharValue(saToBeCharged,parmAmountCharType1);
					if(amount1Val.compareTo(BigDecimal.ZERO) == 0){
						amount1 = Money.ZERO;
						// KL20130724 - Start of Fix for IM-034446
						//shouldCreateToDoEntry = true;
						// KL20130724 - End of Fix for IM-034446
					} else {
						// KL20130626 - Start of defect fix for #2598
						//amount1 = new Money(amount1Val, saToBeCharged.getCurrencyId());
						amount1 = new Money(amount1Val, currencyId);
						// KL20130626 - Start of defect fix for #2598
					}
					//if (isNull(amount1)) {
					//	amount1 = Money.ZERO;
					// KL20130625 - End of fix for defect 2279
					/*
					 * End Change - 2013-05-29 - JPunza 
					 */
					//shouldCreateToDoEntry = true;
					//createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
					// KL20130617 - Start of fix for defect 2279
					//}
					// KL20130625 - End of fix for defect 2279
				}

				if(notNull(parmAdjType2) && notNull(parmAmountCharType2)){
					/*
					 * Start Change - 2013-05-29 - JPunza 
					 */
					//if(!isNull(retrieveCharValue(sa,parmAmountCharType2))){
					//    //Create Adjustment(adj2) of Type adjType2 for above selected SA
					//    adj2 = createAdjustment(sa.getId(),parmAdjType2,retrieveCharValue(sa,parmAmountCharType2));
					//    //Set FA Characteristic (Char Type = ftIdCharType, Char Val Fk1=ftId of adj2)
					//    createCharOnFA(parmAdjIdCharType, adj2.getId().getIdValue().trim());
					//}else{
					// KL20130625 - Start of fix for defect 2279
					//amount2 = retrieveCharValue(saToBeCharged,parmAmountCharType2);
					if(amount2Val.compareTo(BigDecimal.ZERO) == 0){
						amount2 = Money.ZERO;
						// KL20130724 - Start of Fix for IM-034446
						//shouldCreateToDoEntry = true;
						// KL20130724 - End of Fix for IM-034446
					} else {
						// KL20130626 - Start of defect fix for #2598
						//amount2 = new Money(amount2Val, saToBeCharged.getCurrencyId());
						amount2 = new Money(amount2Val, currencyId);
						// KL20130626 - Start of defect fix for #2598
					}
					//if (isNull(amount2)) {
					//	amount2 = Money.ZERO;
					/*
					 * End Change - 2013-05-29 - JPunza 
					 */
					//create To Do
					// KL20130617 - Start of fix for defect 2279
					//shouldCreateToDoEntry = true;
					//createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
					// KL20130617 - Start of fix for defect 2279
					//}
					// KL20130625 - End of fix for defect 2279
				}

				if(!(isNull(parmAdjType3)) && !(isNull(parmAmountCharType3))){
					/*
					 * Start Change - 2013-05-29 - JPunza 
					 */
					//if(!isNull(retrieveCharValue(sa,parmAmountCharType3))){
					//  //Create Adjustment(adj3) of Type adjType1 for above selected SA
					//    adj3 = createAdjustment(sa.getId(),parmAdjType3,retrieveCharValue(sa,parmAmountCharType3));
					//    //Set FA Characteristic (Char Type = ftIdCharType, Char Val Fk1=ftId of adj3)
					//    createCharOnFA(parmAdjIdCharType, adj3.getId().getIdValue().trim());
					//}else{
					// KL20130625 - Start of fix for defect 2279
					//amount3 = retrieveCharValue(saToBeCharged,parmAmountCharType3);
					if(amount3Val.compareTo(BigDecimal.ZERO) == 0){
						amount3 = Money.ZERO;
						// KL20130724 - Start of Fix for IM-034446
						//shouldCreateToDoEntry = true;
						// KL20130724 - End of Fix for IM-034446
					} else {
						// KL20130626 - Start of defect fix for #2598
						//amount3 = new Money(amount3Val, saToBeCharged.getCurrencyId());
						amount3 = new Money(amount3Val, currencyId);
						// KL20130626 - Start of defect fix for #2598
					}

					//if (isNull(amount3)) {
					//	amount3 = Money.ZERO;
					/*
					 * End Change - 2013-05-29 - JPunza 
					 */
					//Create To Do
					// KL20130617 - Start of fix for defect 2279
					//	shouldCreateToDoEntry = true;
					//createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
					// KL20130617 - Start of fix for defect 2279
					//}
					// KL20130625 - End of fix for defect 2279
				}

				if(!(isNull(parmAdjType4)) && !(isNull(parmAmountCharType4))){
					/*
					 * Start Change - 2013-05-29 - JPunza 
					 */
					//if(!isNull(retrieveCharValue(sa,parmAmountCharType4))){
					//    //Create Adjustment(adj4) of Type adjType1 for above selected SA
					//    adj4 = createAdjustment(sa.getId(),parmAdjType4,retrieveCharValue(sa,parmAmountCharType4));
					//    //Set FA Characteristic (Char Type = ftIdCharType, Char Val Fk1=Adj id) 
					//    createCharOnFA(parmAdjIdCharType, adj4.getId().getIdValue().trim());
					//}else{
					// KL20130625 - Start of fix for defect 2279
					//amount4 = retrieveCharValue(saToBeCharged,parmAmountCharType4);
					if(amount4Val.compareTo(BigDecimal.ZERO) == 0){
						amount4 = Money.ZERO;
						// KL20130724 - Start of Fix for IM-034446
						//shouldCreateToDoEntry = true;
						// KL20130724 - End of Fix for IM-034446
					} else {
						// KL20130626 - Start of defect fix for #2598
						//amount4 = new Money(amount4Val, saToBeCharged.getCurrencyId());
						amount4 = new Money(amount4Val, currencyId);
						// KL20130626 - Start of defect fix for #2598
					}

					//if (isNull(amount4)) {
					//	amount4 = Money.ZERO;
					/*
					 * End Change - 2013-05-29 - JPunza 
					 */
					//Create To Do
					// KL20130617 - Start of fix for defect 2279
					//	shouldCreateToDoEntry = true;
					//createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
					// KL20130617 - Start of fix for defect 2279
					//}
					// KL20130625 - End of fix for defect 2279
				}

				if(!(isNull(parmAdjType5)) && !(isNull(parmAmountCharType5))){
					/*
					 * Start Change - 2013-05-29 - JPunza 
					 */
					//if(!isNull(retrieveCharValue(sa,parmAmountCharType5))){
					//    //Create Adjustment(adj5) of Type adjType1 for above selected SA
					//    adj5 = createAdjustment(sa.getId(),parmAdjType5,retrieveCharValue(sa,parmAmountCharType5));
					//    //Set FA Characteristic (Char Type = ftIdCharType, Char Val Fk1=Adj id)                     
					//    createCharOnFA(parmAdjIdCharType, adj5.getId().getIdValue().trim());
					//}else{
					// KL20130625 - Start of fix for defect 2279
					//amount5 = retrieveCharValue(saToBeCharged,parmAmountCharType5);
					if(amount5Val.compareTo(BigDecimal.ZERO) == 0){
						amount5 = Money.ZERO;
						// KL20130724 - Start of Fix for IM-034446
						//shouldCreateToDoEntry = true;
						// KL20130724 - End of Fix for IM-034446
					} else {
						// KL20130626 - Start of defect fix for #2598
						//amount5 = new Money(amount5Val, saToBeCharged.getCurrencyId());
						amount5 = new Money(amount5Val, currencyId);
						// KL20130626 - Start of defect fix for #2598
					}
					//if (isNull(amount5)) {
					//	amount5 = Money.ZERO;
					/*
					 * End Change - 2013-05-29 - JPunza 
					 */    
					//Create To Do
					// KL20130617 - Start of fix for defect 2279
					//shouldCreateToDoEntry = true;
					//createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
					// KL20130617 - Start of fix for defect 2279
					//}
					// KL20130625 - End of fix for defect 2279
				}

				// KL20130724 - Start of fix for IM-034446
				// KL20130617 - Start of fix for defect 2279
				//if(shouldCreateToDoEntry){
					//createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
				//}
				// KL20130617 - Start of fix for defect 2279
				// KL20130724 - End of fix for IM-034446
				
				/*
				 * Start Add - 2013-05-29 - JPunza 
				 */
				// KL20130625 - Start of fix for defect 2279
				/*
				 * commented out this logic as it has been extracted as above as the first logic to be preformed
				 * 
			Money totalAmount = amount1.add(amount2).add(amount3).add(amount4).add(amount5);
			if (totalAmount.isZero()) {
				return;
			}
				 */
				// KL20130625 - End of fix for defect 2279
				if (!amount1.isZero()) {
					String adjIdStr = createAdjustment(saToBeCharged.getId(), parmAdjType1, amount1);
					createCharOnFA(parmAdjIdCharType, adjIdStr);
				}
				if (!amount2.isZero()) {
					String adjIdStr = createAdjustment(saToBeCharged.getId(), parmAdjType2, amount2);
					createCharOnFA(parmAdjIdCharType, adjIdStr);
				}
				if (!amount3.isZero()) {
					String adjIdStr = createAdjustment(saToBeCharged.getId(), parmAdjType3, amount3);
					createCharOnFA(parmAdjIdCharType, adjIdStr);
				}
				if (!amount4.isZero()) {
					String adjIdStr = createAdjustment(saToBeCharged.getId(), parmAdjType4, amount4);
					createCharOnFA(parmAdjIdCharType, adjIdStr);
				}
				if (!amount5.isZero()) {
					String adjIdStr = createAdjustment(saToBeCharged.getId(), parmAdjType5, amount5);
					createCharOnFA(parmAdjIdCharType, adjIdStr);
				}
				/*
				 * End Add - 2013-05-29 - JPunza 
				 */
				//Start Add JVitug/FRoig - B-19769 - 2021-12-29
				if(shouldCreatePaymentArrangement.isTrue() && chargeAsFlatFee.isFalse()) {
					createPaymentArrangement(saToBeCharged);
				}
				//End Add JVitug/FRoig - B-19769 - 2021-12-29
			}

			if(parmAdjOrBillable.isB()){                
				/*
				 * Start Change - 2013-05-29 - JPunza 
				 */
				//                //Create Billable Charge (bc) using template 'billableChargeTemplate' for above selected SA
				//                billableCharge = createBillableCharge(sa);
				//                
				//                //Set FA Characteristic (Char Type = ftIdCharType, Char Val Fk1=bc) 
				//                createCharOnFA(parmBillableChargeIdCharType,  billableCharge.getId().getIdValue().trim());
				//                
				//                if(parmFaCharStoreAmountFlg.isTrue()){
				//
				//                    Map<Integer, BigInteger> sequenceMap = new HashMap<Integer, BigInteger>();
				//                    Map<Integer, Money> chargeAmountMap = new HashMap<Integer, Money>();
				//                    int i=1;
				//    
				//                    for(BillableChargeLine billableChargeLine : billableCharge.getLines()){
				//                        sequenceMap.put(i, billableChargeLine.fetchIdLineSequence());
				//                        i++;
				//                    }
				//    
				//                    Iterator<Map.Entry<Integer, BigInteger>> iter = sequenceMap.entrySet().iterator();
				//    
				//                    while (iter.hasNext()) {
				//                        Map.Entry<Integer, BigInteger> mEntry = (Map.Entry<Integer, BigInteger>) iter.next();
				//                        if(mEntry.getKey().equals(1) && !(isNull(parmAmountCharType1))){
				//
				//                            if(!isNull(retrieveCharValue(sa,parmAmountCharType1))){
				//                                chargeAmountMap.put(1, retrieveCharValue(sa,parmAmountCharType1));
				//                            }else{
				//                                //Create To Do
				//                                createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
				//                            }
				//                        }
				//                        else if(mEntry.getKey().equals(2) && !(isNull(parmAmountCharType2))){
				//
				//                            if(!isNull(retrieveCharValue(sa,parmAmountCharType2))){
				//                                chargeAmountMap.put(2, retrieveCharValue(sa,parmAmountCharType2));
				//                            }else{
				//                                //Create To Do
				//                                createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
				//                            }
				//                        }
				//                        else if(mEntry.getKey().equals(3) && !(isNull(parmAmountCharType3))){
				//
				//                            if(!isNull(retrieveCharValue(sa,parmAmountCharType3))){
				//                                chargeAmountMap.put(3, retrieveCharValue(sa,parmAmountCharType3));
				//                            }else{  
				//                                //Create To Do
				//                                createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
				//                            }
				//                        }
				//                        else if(mEntry.getKey().equals(4) && !(isNull(parmAmountCharType4))){
				//
				//                            if(!isNull(retrieveCharValue(sa,parmAmountCharType4))){
				//                                chargeAmountMap.put(4, retrieveCharValue(sa,parmAmountCharType4));
				//                            }else{    
				//                                //Create To Do
				//                                createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
				//                            }
				//                        }
				//                        else if(mEntry.getKey().equals(5) && !(isNull(parmAmountCharType5))){
				//
				//                            if(!isNull(retrieveCharValue(sa,parmAmountCharType5))){
				//                                chargeAmountMap.put(5, retrieveCharValue(sa,parmAmountCharType5));
				//                            }else{
				//                                //Create To Do
				//                                createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
				//                            }
				//                        }
				//    
				//                    }
				//
				//                    int j = 1;
				//                    for(BillableChargeLine billableChargeLine : billableCharge.getLines()){
				//                        if (chargeAmountMap.containsKey(j)){
				//                            BillableChargeLine_DTO billableChargeLineDTO = billableChargeLine.getDTO();
				//                            billableChargeLineDTO.setChargeAmount(chargeAmountMap.get(j));
				//                            billableChargeLine.setDTO(billableChargeLineDTO);
				//                        }
				//                        j++;
				//                    }
				//                }
				ArrayList<Money> amountList = new ArrayList<Money>();
				Money tempAmount = Money.ZERO;
				Money totalAmount = Money.ZERO;
				if (notNull(parmAmountCharType1)) {
					// KL20130625 - Start of fix for defect 2279
					if(amount1Val.compareTo(BigDecimal.ZERO) == 0){
						tempAmount = Money.ZERO;
						// KL20130724 - Start of Fix for IM-034446
						//shouldCreateToDoEntry = true;
						// KL20130724 - End of Fix for IM-034446
					} else {
						// KL20130626 - Start of defect fix for #2598
						//tempAmount = new Money(amount1Val, saToBeCharged.getCurrencyId());
						tempAmount = new Money(amount1Val, currencyId);
						// KL20130626 - Start of defect fix for #2598
					}
					/**
					 * 
				tempAmount = retrieveCharValue(saToBeCharged, parmAmountCharType1);
				if (isNull(tempAmount)) {
					tempAmount = Money.ZERO;

					//Create To Do
					// KL20130617 - Start of fix for defect 2279
					shouldCreateToDoEntry = true;
					//createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
					// KL20130617 - Start of fix for defect 2279
				}
					 */
					// KL20130625 - Start of fix for defect 2279
					amountList.add(tempAmount);
					totalAmount = totalAmount.add(tempAmount);
				}
				if (notNull(parmAmountCharType2)) {
					// KL20130625 - Start of fix for defect 2279
					if(amount2Val.compareTo(BigDecimal.ZERO) == 0){
						tempAmount = Money.ZERO;
						// KL20130724 - Start of Fix for IM-034446
						//shouldCreateToDoEntry = true;
						// KL20130724 - End of Fix for IM-034446
					} else {
						// KL20130626 - Start of defect fix for #2598
						//tempAmount = new Money(amount2Val, saToBeCharged.getCurrencyId());
						tempAmount = new Money(amount2Val, currencyId);
						// KL20130626 - Start of defect fix for #2598
					}
					/**
					 * 
				tempAmount = retrieveCharValue(saToBeCharged, parmAmountCharType2);
				if (isNull(tempAmount)) {
					tempAmount = Money.ZERO;

					//Create To Do
					// KL20130617 - Start of fix for defect 2279
					shouldCreateToDoEntry = true;
					//createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
					// KL20130617 - Start of fix for defect 2279
				}
					 */
					// KL20130625 - Start of fix for defect 2279
					amountList.add(tempAmount);
					totalAmount = totalAmount.add(tempAmount);
				}
				if (notNull(parmAmountCharType3)) {
					// KL20130625 - Start of fix for defect 2279
					if(amount3Val.compareTo(BigDecimal.ZERO) == 0){
						tempAmount = Money.ZERO;
						// KL20130724 - Start of Fix for IM-034446
						//shouldCreateToDoEntry = true;
						// KL20130724 - End of Fix for IM-034446
					} else {
						// KL20130626 - Start of defect fix for #2598
						//tempAmount = new Money(amount3Val, saToBeCharged.getCurrencyId());
						tempAmount = new Money(amount3Val, currencyId);
						// KL20130626 - Start of defect fix for #2598
					}
					/**
					 * 
				tempAmount = retrieveCharValue(saToBeCharged, parmAmountCharType3);
				if (isNull(tempAmount)) {
					tempAmount = Money.ZERO;

					//Create To Do
					// KL20130617 - Start of fix for defect 2279
					shouldCreateToDoEntry = true;
					//createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
					// KL20130617 - Start of fix for defect 2279
				}
					 */
					// KL20130625 - Start of fix for defect 2279
					amountList.add(tempAmount);
					totalAmount = totalAmount.add(tempAmount);
				}
				if (notNull(parmAmountCharType4)) {
					// KL20130625 - Start of fix for defect 2279
					if(amount4Val.compareTo(BigDecimal.ZERO) == 0){
						tempAmount = Money.ZERO;
						// KL20130724 - Start of Fix for IM-034446
						//shouldCreateToDoEntry = true;
						// KL20130724 - End of Fix for IM-034446
					} else {
						// KL20130626 - Start of defect fix for #2598
						//tempAmount = new Money(amount4Val, saToBeCharged.getCurrencyId());
						tempAmount = new Money(amount4Val, currencyId);
						// KL20130626 - Start of defect fix for #2598
					}
					/**
					 * 
				tempAmount = retrieveCharValue(saToBeCharged, parmAmountCharType4);
				if (isNull(tempAmount)) {
					tempAmount = Money.ZERO;

					//Create To Do
					// KL20130617 - Start of fix for defect 2279
					shouldCreateToDoEntry = true;
					//createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
					// KL20130617 - Start of fix for defect 2279
				}
					 */
					// KL20130625 - Start of fix for defect 2279
					amountList.add(tempAmount);
					totalAmount = totalAmount.add(tempAmount);
				}
				if (notNull(parmAmountCharType5)) {
					// KL20130625 - Start of fix for defect 2279
					if(amount5Val.compareTo(BigDecimal.ZERO) == 0){
						tempAmount = Money.ZERO;
						// KL20130724 - Start of Fix for IM-034446
						//shouldCreateToDoEntry = true;
						// KL20130724 - End of Fix for IM-034446
					} else {
						// KL20130626 - Start of defect fix for #2598
						//tempAmount = new Money(amount5Val, saToBeCharged.getCurrencyId());
						tempAmount = new Money(amount5Val, currencyId);
						// KL20130626 - Start of defect fix for #2598
					}
					/**
					 * 
				tempAmount = retrieveCharValue(saToBeCharged, parmAmountCharType5);
				if (isNull(tempAmount)) {
					tempAmount = Money.ZERO;

					//Create To Do
					// KL20130617 - Start of fix for defect 2279
					shouldCreateToDoEntry = true;
					//createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
					// KL20130617 - Start of fix for defect 2279
				}
					 */
					// KL20130625 - Start of fix for defect 2279
					amountList.add(tempAmount);
					totalAmount = totalAmount.add(tempAmount);
				}

				// KL20130724 - Start of Fix for IM-034446
				// KL20130617 - Start of fix for defect 2279
				//if(shouldCreateToDoEntry){
					//createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
				//}
				// KL20130617 - Start of fix for defect 2279
				// KL20130724 - End of Fix for IM-034446

				if (totalAmount.isZero()) {
					return;
				}

				billableCharge = createBillableCharge(saToBeCharged);
				logger.info("--------------------------------------------Completed Billable charge creation---------------------------------------");
				logger.info("Billable Charge is :"+billableCharge);
				createCharOnFA(parmBillableChargeIdCharType,  billableCharge.getId().getTrimmedValue());

				int numAmount = amountList.size();
				int i = 0;
				for (BillableChargeLine billableChargeLine : billableCharge.getLines()) {
					if (i < numAmount) {
						BillableChargeLine_DTO billableChargeLineDTO = billableChargeLine.getDTO();
						billableChargeLineDTO.setChargeAmount(amountList.get(i));
						billableChargeLine.setDTO(billableChargeLineDTO);
					}
					i++;
				}                
				/*
				 * End Change - 2013-05-29 - JPunza 
				 */
			}
		}
	}

	private Account retrieveCharAccountId(){
		Account charAccountId = null;
		StringBuilder charAccountIdQueryString = new StringBuilder();
		charAccountIdQueryString.append("SELECT CHAR_VAL_FK1 ACCT_ID ");
		charAccountIdQueryString.append("FROM CI_FA_CHAR FC ");
		charAccountIdQueryString.append("WHERE FC.FA_ID = :faId ");
		charAccountIdQueryString.append("AND FC.CHAR_TYPE_CD = :accountIdCharType  ");

		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement charAccountIdPrepStmt = createPreparedStatement(charAccountIdQueryString.toString()); 
		PreparedStatement charAccountIdPrepStmt = createPreparedStatement(charAccountIdQueryString.toString(), getClass().getName()); 
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		charAccountIdPrepStmt.bindId("faId", currentFA.getId());  
		charAccountIdPrepStmt.bindId("accountIdCharType", parmAccountIdCharType.getId());
		SQLResultRow firstRow=charAccountIdPrepStmt.firstRow();
		charAccountIdPrepStmt.close();
		if(isNull(firstRow)){
			return null;
		}
		charAccountId = firstRow.getEntity("ACCT_ID", Account.class);
		return charAccountId;
	}

	/**
	 * KL20130606 - Start of fix for Defect 1972 - Changing the logic to retrieve the account associated to the current FA
	 */
	//	KL20130606 - Start of Delete     
	//    private Account retrieveAccountId(){
	//        Account account = null;
	//        StringBuilder accountIdQueryString = new StringBuilder();
	//        accountIdQueryString.append("SELECT SA.ACCT_ID ");
	//        accountIdQueryString.append("FROM CI_SA SA, CI_SA_SP SS, CI_SP SP, CI_FA FA ");
	//        accountIdQueryString.append("WHERE FA.FA_ID = :faId ");
	//        accountIdQueryString.append("AND FA.SP_ID = SP.SP_ID  ");
	//        accountIdQueryString.append("AND SP.SP_ID = SS.SP_ID  ");
	//        accountIdQueryString.append("AND ((:processDateTime BETWEEN SS.START_DTTM AND  SS.STOP_DTTM) OR (SS.STOP_DTTM IS NULL))  ");
	//        accountIdQueryString.append("AND SS.SA_ID = SA.SA_ID  ");
	//
	//        PreparedStatement accountIdPrepStmt = createPreparedStatement(accountIdQueryString.toString()); 
	//        accountIdPrepStmt.bindId("faId", currentFA.getId()); 
	//        accountIdPrepStmt.bindDateTime("processDateTime",getProcessDateTime());
	//        SQLResultRow firstRow = accountIdPrepStmt.firstRow();
	//        //KL20130606 - Start of fix for Defect 1972 - Introduced null check
	//        if(notNull(firstRow)){
	//        	account = firstRow.getEntity("ACCT_ID", Account.class);
	//        }
	//      //KL20130606 - End of fix for Defect 1972
	//        accountIdPrepStmt.close();
	//        return account;
	//    }
	//	KL20130606 - End of Delete


	// KL20130617 - Start of fix for Defect 2279		
	// Per discussion with functional designer, modified logic to retrieve account associated to current FA
	// P.S: As the field activites on which these algorithms are configured are jobbing type, it is a mandated 
	// business process that SAs linked to the premise should have the CharPremId populated on it. So logic 
	// used to retrieve associated Accounts are based on the CharPremId.

	//public void populateAccountAssociatedToCurrentFA(){
	// KL20131018 - Start of fix for IM-034868 --- Added new parameters and changed the logic
	//private List<SQLResultRow> retrieveAccountAssociatedToCurrentFA(){
	private List<SQLResultRow> retrieveAccountAssociatedToCurrentFA(boolean checkForActiveSAs, boolean checkForStoppedSAs, boolean checkForNonCanceledSAs){
	// KL20131018 - End of fix for IM-034868
		
		List<SQLResultRow> accountList = new ArrayList<SQLResultRow>();
		StringBuilder accountIdQueryString = new StringBuilder();

		accountIdQueryString.append("SELECT DISTINCT SA.ACCT_ID FROM CI_SA SA, CI_SP SP, CI_FA FA ");
		accountIdQueryString.append("WHERE SP.SP_ID = FA.SP_ID AND SP.PREM_ID = SA.CHAR_PREM_ID ");
		accountIdQueryString.append("AND FA.FA_ID = :faId ");
		// KL20130617 - End of fix for Defect 2279	
		// KL20130724 - Start of Fix for IM-034446
		// START CHANGE - JHERNA - 2015-09-11 - 3298881
		//accountIdQueryString.append("AND SA.START_DT < :processDate ");
		accountIdQueryString.append("AND SA.START_DT <= :processDate ");
		// END CHANGE - JHERNA - 2015-09-11 - 3298881
		accountIdQueryString.append("AND (SA.END_DT IS NULL OR SA.END_DT >= :processDate) ");
		// KL20130724 - End of Fix for IM-034446
		// KL20131018 - Start of fix for IM-034868
		if(checkForActiveSAs){
			accountIdQueryString.append("AND SA.SA_STATUS_FLG IN (:active, :pendingStop, :reactivated) ");
		} else if (checkForStoppedSAs){
			accountIdQueryString.append("AND SA.SA_STATUS_FLG IN (:pendingStart, :stopped) ");
		} else if (checkForNonCanceledSAs){
			accountIdQueryString.append("AND SA.SA_STATUS_FLG != :canceled ");
		}
		// KL20131018 - End of fix for IM-034868

		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement accountIdPrepStmt = createPreparedStatement(accountIdQueryString.toString()); 
		PreparedStatement accountIdPrepStmt = createPreparedStatement(accountIdQueryString.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		accountIdPrepStmt.bindId("faId", currentFA.getId()); 
		// KL20130724 - Start of Fix for IM-034446
		accountIdPrepStmt.bindDate("processDate", getProcessDateTime().getDate()); 
		// KL20130724 - End of Fix for IM-034446
		// KL20131018 - Start of fix for IM-034868
		if(checkForActiveSAs){
			accountIdPrepStmt.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
			accountIdPrepStmt.bindLookup("pendingStop",ServiceAgreementStatusLookup.constants.PENDING_STOP);
			accountIdPrepStmt.bindLookup("reactivated",ServiceAgreementStatusLookup.constants.REACTIVATED);
		} else if (checkForStoppedSAs){
			accountIdPrepStmt.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
			accountIdPrepStmt.bindLookup("stopped",ServiceAgreementStatusLookup.constants.STOPPED);
		} else if (checkForNonCanceledSAs){
			accountIdPrepStmt.bindLookup("canceled", ServiceAgreementStatusLookup.constants.CANCELED);
		}
		// KL20131018 - End of fix for IM-034868
		
		// KL20130617 - Start of fix for Defect 2279		
		accountList = accountIdPrepStmt.list();
		//SQLResultRow firstRow = accountIdPrepStmt.firstRow();
		//if(notNull(firstRow)){
		//	account = firstRow.getEntity("ACCT_ID", Account.class);
		//}
		accountIdPrepStmt.close();
		return accountList;
		// KL20130617 - End of fix for Defect 2279		
	}

	/**
	 * KL20130606 - End of fix for Defect 1972
	 */


	/*
	 * Start Delete - 2013-05-29 - JPunza 
	 */
	//    private Premise retrievePremise(){
	//        Premise premise = null;
	//        StringBuilder premiseQueryString = new StringBuilder();
	//        premiseQueryString.append("SELECT SP.PREM_ID  ");
	//        premiseQueryString.append("FROM CI_SP SP, CI_FA FA ");
	//        premiseQueryString.append("WHERE FA.FA_ID = :faId ");
	//        premiseQueryString.append("AND FA.SP_ID = SP.SP_ID  ");
	//        
	//        PreparedStatement premisePrepStmt = createPreparedStatement(premiseQueryString.toString()); 
	//        premisePrepStmt.bindId("faId", currentFA.getId());  
	//        premise = premisePrepStmt.firstRow().getEntity("PREM_ID", Premise.class);
	//        premisePrepStmt.close();
	//        return premise;
	//    }
	/*
	 * End Delete - 2013-05-29 - JPunza 
	 */
	private boolean hasSA(Account accountToBeCharged){
		/**
		 * KL20130617 - End of fix for Defect 2279
		 * Commented out below logic to follow base implementation in 
		 *  com.splwg.ccb.domain.admin.fieldActivityType.ApplyChargesCompletionAlgComp_Impl.java
		 * 
		StringBuilder hasSAString = new StringBuilder();
		hasSAString.append(" SELECT SA1.SA_ID ");
		hasSAString.append("FROM CI_SA SA1 ");
		hasSAString.append( "WHERE SA1.ACCT_ID = :charAccountId ");
		hasSAString.append( "AND TRIM(SA1.SA_TYPE_CD) = :saType ");
		hasSAString.append( "AND SA1.CIS_DIVISION = :cisDivision ");
		hasSAString.append( "AND SA1.SA_STATUS_FLG IN (:active, :pendingStart)  ");
		hasSAString.append( "AND SA1.CHAR_PREM_ID != :currentPremise ");

		PreparedStatement hasSAPrepStmt = createPreparedStatement(hasSAString.toString());
		hasSAPrepStmt.bindId("charAccountId",charAccount.getId());
		hasSAPrepStmt.bindStringProperty("saType", ServiceAgreementType.properties.saType,parmSaType);

		hasSAPrepStmt.bindId("cisDivision", parmCisDivision.getId());
		hasSAPrepStmt.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
		hasSAPrepStmt.bindLookup("pendingStart",ServiceAgreementStatusLookup.constants.PENDING_START);
		hasSAPrepStmt.bindId("currentPremise",currentPremise.getId());

		List<SQLResultRow> resultList = hasSAPrepStmt.list();
		hasSAPrepStmt.close();

		if (resultList.isEmpty()){
			return false;
		}else{
			return true;
		}
		 */

		//KL20130625 - Start of defect fix for #2539 - passing the account to be charged as a parameter
		//Start Change FRoig - B-19769 - 2022-01-06
		// If we are creating a payment arrangement, we always need a new SA.
		ServiceAgreement_Id saId = null;
		if (shouldCreatePaymentArrangement.isTrue() && chargeAsFlatFee.isFalse()) {
			logger.info("B-19769 New SA and Payment Arrangement should be created.");
			return false;
		} else {
			logger.info("B-19769 Payment Arrangement not required. Retrieve active SA.");
			saId = getActiveSAs(accountToBeCharged);
		}
		//End Change FRoig - B-19769 - 2022-01-06
		//Start Delete FRoig - B-19769 - 2022-01-06
		//if (isNull(saId)) {
		//	saId = getStoppedSAs(accountToBeCharged);
		//}
		//if (isNull(saId)) {
		//	saId = getNonCanceledSAs(accountToBeCharged);
		//}
		//End Delete FRoig - B-19769 - 2022-01-06
		//KL20130625 - End of defect fix for #2539
		if(isNull(saId)){
			return false;
		}
		saToBeCharged = saId.getEntity();
		if(isNull(saToBeCharged)){
			return false;
		}
		return true;
	}

	/**
	 * KL20130625 - Start of defect fix for #2539
	 * 
	 */
	private ServiceAgreement_Id getActiveSAs(Account accountToBeCharged) {
		//Get the first Pending Start, Active, Pending Stop SA starting on the same day. (B-19769)
		SQLResultRow firstRow = null;
		StringBuilder getActiveSAsStr = new StringBuilder();

		getActiveSAsStr.append("SELECT SA.SA_ID FROM CI_SA SA ");
		getActiveSAsStr.append("WHERE SA.CHAR_PREM_ID = :currentPremise AND SA.ACCT_ID = :accountToBeCharged ");
		// CCB v2.6 Upgrade - 2018-07-25 - Start Change
		//getActiveSAsStr.append("AND TRIM(SA.SA_TYPE_CD) = :saType AND SA.CIS_DIVISION = :cisDivision ");
		getActiveSAsStr.append("AND SA.SA_TYPE_CD = :saType AND SA.CIS_DIVISION = :cisDivision ");
		// CCB v2.6 Upgrade - 2018-07-25 - End Change
		//Start Change FRoig - B-19769 - 2022-01-06
		//getActiveSAsStr.append("AND SA.SA_STATUS_FLG IN (:active, :pendingStop, :reactivated) ");
		getActiveSAsStr.append("AND SA.SA_STATUS_FLG IN (:pendingStart, :active, :pendingStop) ");
		getActiveSAsStr.append("AND SA.START_DT = :processDate ");
		getActiveSAsStr.append("AND not exists (select 'x' from CI_FT ft where ft.SA_ID = SA.SA_ID and ft.PARENT_ID = :jobPaXfer) ");
		//End Change FRoig - B-19769 - 2022-01-06
		getActiveSAsStr.append("ORDER BY SA.SA_STATUS_FLG");

		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement hasActiveSAsPrepStmt = createPreparedStatement(getActiveSAsStr.toString());
		PreparedStatement hasActiveSAsPrepStmt = createPreparedStatement(getActiveSAsStr.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		hasActiveSAsPrepStmt.bindId("currentPremise",currentPremise.getId());
		hasActiveSAsPrepStmt.bindId("accountToBeCharged",accountToBeCharged.getId());
		hasActiveSAsPrepStmt.bindStringProperty("saType", ServiceAgreementType.properties.saType,parmSaType.trim());
		hasActiveSAsPrepStmt.bindId("cisDivision", parmCisDivision.getId());
		hasActiveSAsPrepStmt.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
		hasActiveSAsPrepStmt.bindLookup("pendingStop",ServiceAgreementStatusLookup.constants.PENDING_STOP);
		//Start Change FRoig - B-19769 - 2022-01-06
		//hasActiveSAsPrepStmt.bindLookup("reactivated",ServiceAgreementStatusLookup.constants.REACTIVATED);
		hasActiveSAsPrepStmt.bindLookup("pendingStart",ServiceAgreementStatusLookup.constants.PENDING_START);
		hasActiveSAsPrepStmt.bindDate("processDate", getProcessDateTime().getDate());
		hasActiveSAsPrepStmt.bindStringProperty("jobPaXfer",FinancialTransaction.properties.parentId,parmAdjTypeJobPaXfer.getId().getIdValue());
		//End Change FRoig - B-19769 - 2022-01-06

		firstRow = hasActiveSAsPrepStmt.firstRow();
		hasActiveSAsPrepStmt.close();

		if(isNull(firstRow)) return null;
		return (ServiceAgreement_Id) firstRow.getId("SA_ID", ServiceAgreement.class);
	}

	//Start Delete FRoig - B-19769 - 2022-01-06
	//private ServiceAgreement_Id getStoppedSAs(Account accountToBeCharged) {
	//	//Get the first Pending Start or Stopped SA
	//	SQLResultRow firstRow = null;
	//	StringBuilder getStoppedSAsStr = new StringBuilder();
	//
	//	getStoppedSAsStr.append("SELECT SA.SA_ID FROM CI_SA SA ");
	//	getStoppedSAsStr.append("WHERE SA.CHAR_PREM_ID = :currentPremise AND SA.ACCT_ID = :accountToBeCharged ");
	//	// CCB v2.6 Upgrade - 2018-07-25 - Start Change
	//	//getStoppedSAsStr.append("AND TRIM(SA.SA_TYPE_CD) = :saType AND SA.CIS_DIVISION = :cisDivision ");
	//	getStoppedSAsStr.append("AND SA.SA_TYPE_CD = :saType AND SA.CIS_DIVISION = :cisDivision ");
	//	// CCB v2.6 Upgrade - 2018-07-25 - End Change
	//	getStoppedSAsStr.append("AND SA.SA_STATUS_FLG IN (:pendingStart, :stopped) ");
	//	getStoppedSAsStr.append("ORDER BY SA.SA_STATUS_FLG");
	//
	//	//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
	//	//PreparedStatement hasStoppedSAsPrepStmt = createPreparedStatement(getStoppedSAsStr.toString());
	//	PreparedStatement hasStoppedSAsPrepStmt = createPreparedStatement(getStoppedSAsStr.toString(), getClass().getName());
	//	//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
	//	hasStoppedSAsPrepStmt.bindId("currentPremise",currentPremise.getId());
	//	hasStoppedSAsPrepStmt.bindId("accountToBeCharged",accountToBeCharged.getId());
	//	hasStoppedSAsPrepStmt.bindStringProperty("saType", ServiceAgreementType.properties.saType,parmSaType.trim());
	//	hasStoppedSAsPrepStmt.bindId("cisDivision", parmCisDivision.getId());
	//	hasStoppedSAsPrepStmt.bindLookup("pendingStart",ServiceAgreementStatusLookup.constants.PENDING_START);
	//	hasStoppedSAsPrepStmt.bindLookup("stopped",ServiceAgreementStatusLookup.constants.STOPPED);
	//
	//	firstRow = hasStoppedSAsPrepStmt.firstRow();
	//	hasStoppedSAsPrepStmt.close();
	//
	//	if(isNull(firstRow)) return null;
	//	return (ServiceAgreement_Id) firstRow.getId("SA_ID", ServiceAgreement.class);
	//}
	//
	//private ServiceAgreement_Id getNonCanceledSAs(Account accountToBeCharged) {
	//	//Get the first non Cancelled SA
	//	SQLResultRow firstRow = null;
	//	StringBuilder getNonCanceledSAsStr = new StringBuilder();
	//
	//	getNonCanceledSAsStr.append("SELECT SA.SA_ID FROM CI_SA SA ");
	//	getNonCanceledSAsStr.append("WHERE SA.CHAR_PREM_ID = :currentPremise AND SA.ACCT_ID = :accountToBeCharged ");
	//	// CCB v2.6 Upgrade - 2018-07-25 - Start Change
	//	//getNonCanceledSAsStr.append("AND TRIM(SA.SA_TYPE_CD) = :saType AND SA.CIS_DIVISION = :cisDivision ");
	//	getNonCanceledSAsStr.append("AND SA.SA_TYPE_CD = :saType AND SA.CIS_DIVISION = :cisDivision ");
	//	// CCB v2.6 Upgrade - 2018-07-25 - End Change
	//	getNonCanceledSAsStr.append("AND SA.SA_STATUS_FLG != :canceled ");
	//
	//	//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
	//	//PreparedStatement hasNonCanceledSAsPrepStmt = createPreparedStatement(getNonCanceledSAsStr.toString());
	//	PreparedStatement hasNonCanceledSAsPrepStmt = createPreparedStatement(getNonCanceledSAsStr.toString(), getClass().getName());
	//	//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
	//	hasNonCanceledSAsPrepStmt.bindId("currentPremise",currentPremise.getId());
	//	hasNonCanceledSAsPrepStmt.bindId("accountToBeCharged",accountToBeCharged.getId());
	//	hasNonCanceledSAsPrepStmt.bindStringProperty("saType", ServiceAgreementType.properties.saType,parmSaType.trim());
	//	hasNonCanceledSAsPrepStmt.bindId("cisDivision", parmCisDivision.getId());
	//	hasNonCanceledSAsPrepStmt.bindLookup("canceled",ServiceAgreementStatusLookup.constants.CANCELED);
	//
	//	firstRow = hasNonCanceledSAsPrepStmt.firstRow();
	//	hasNonCanceledSAsPrepStmt.close();
	//
	//	if(isNull(firstRow)) return null;
	//	return (ServiceAgreement_Id) firstRow.getId("SA_ID", ServiceAgreement.class);
	//}
	//End Delete FRoig - B-19769 - 2022-01-06
	/**
	 * KL20130625 - End of defect fix for #2539
	 * 
	 */

	/**
	 * KL20130625 - Start of defect fix for #2279
	 * 
	 */
	private boolean isAllAmountCharValsZeros(){

		if(parmAdjOrBillable.isA()){
			
			logger.info("Checking Amount 1 : ");
			if(notNull(parmAdjType1) && notNull(parmAmountCharType1)){
				amount1Val = retrieveCharValue(parmAmountCharType1);
			}
			logger.info("Checking Amount 2 : ");
			if(notNull(parmAdjType2) && notNull(parmAmountCharType2)){
				amount2Val = retrieveCharValue(parmAmountCharType2);
			}
			logger.info("Checking Amount 3 : ");
			if(notNull(parmAdjType3) && notNull(parmAmountCharType3)){
				amount3Val = retrieveCharValue(parmAmountCharType3);
			}
			logger.info("Checking Amount 4 : ");
			if(notNull(parmAdjType4) && notNull(parmAmountCharType4)){
				amount4Val = retrieveCharValue(parmAmountCharType4);
			}
			logger.info("Checking Amount 5 : ");
			if(notNull(parmAdjType5) && notNull(parmAmountCharType5)){
				amount5Val = retrieveCharValue(parmAmountCharType5);
			}
			
		} else if(parmAdjOrBillable.isB()){
			if (notNull(parmAmountCharType1)) {
				amount1Val = retrieveCharValue(parmAmountCharType1);
			}
			if (notNull(parmAmountCharType2)) {
				amount2Val = retrieveCharValue(parmAmountCharType2);
			}
			if (notNull(parmAmountCharType3)) {
				amount3Val = retrieveCharValue(parmAmountCharType3);
			}
			if (notNull(parmAmountCharType4)) {
				amount4Val = retrieveCharValue(parmAmountCharType4);
			}
			if (notNull(parmAmountCharType5)) {
				amount5Val = retrieveCharValue(parmAmountCharType5);
			}
		}

		// KL20130724 - Start of Fix for IM-034446
		if(shouldCreateToDoEntry){
			createToDoEntry(BigInteger.valueOf(CustomMessageRepository.NA0073_CHAR_TYPE_REQUIRED_ON_FA),currentFA.getId().getIdValue().trim());
			return true;
		}
		// KL20130724 - End of Fix for IM-034446

		BigDecimal totalAmount = amount1Val.add(amount2Val).add(amount3Val).add(amount4Val).add(amount5Val);
		if (totalAmount.compareTo(BigDecimal.ZERO) == 0) {
			return true;
		}
		return false;
	}

	/**
	 * KL20130625 - End of defect fix for #2279
	 * 
	 */
	private ServiceAgreement createSA(Account account) {
		logger.info("IM-034868 ----------SA Creation has been called---------");
		logger.info("Current Account --- "+ account.getId().getTrimmedValue());

		ServiceAgreementCreator saCreator = ServiceAgreementCreator.Factory.newInstance();
		ServiceAgreement_DTO saDto = (ServiceAgreement_DTO) createDTO(ServiceAgreement.class);
		ServiceAgreementCreatorData saCreatorData = ServiceAgreementCreatorData.Factory.newInstance();
		saDto.setServiceAgreementTypeId(saTypeId); 
		saDto.setStatus(ServiceAgreementStatusLookup.constants.ACTIVE);
		saDto.setAccountId(account.getId());
		saDto.setPremiseId(currentPremise.getId());
		saDto.setStartDate(getProcessDateTime().getDate());
		saDto.setAreEstimatesAllowed(Bool.FALSE);
		saDto.setCustomerRead(CustomerReadLookup.constants.NO);
		saDto.setStartReason(StartReasonLookup.constants.CUSTOMER_REQUEST);
		// KL20130626 - Start of defect fix for #2598
		saDto.setCurrencyId(account.getCurrency().getId());
		// KL20130626 - Start of defect fix for #2598
		saCreatorData.setShouldCreateFieldActivity(Bool.FALSE);
		saCreatorData.setShouldExcludeCopySASP(Bool.TRUE);
		saCreatorData.setCopyOption(CopyOptionForProposalSALookup.constants.COPY_OPTION_FOR_PROPOSAL_S_A_B_S_P);

		// Start Change - RDizon - 2021-07-15 - CCB037.4
		//return saCreator.addServiceAgreement(saDto, saCreatorData);
		ServiceAgreement serviceAgreement = saCreator.addServiceAgreement(saDto, saCreatorData);

		ServiceAgreement_Id saWithExemptionsId = getActiveSAsWithTaxExemptions(account);
		// Start Change - GCrisp - 2021-09-21 - Defect 44598508
		//if (!isNull(saWithExemptionsId.getEntity())){
		if (notNull(saWithExemptionsId)){
		// End Change - GCrisp - 2021-09-21 - Defect 44598508
		    // Copy active Tax Exemptions 
		    ServiceAgreement saWithExemptions = saWithExemptionsId.getEntity();
		    
		    Iterator<ServiceAgreementContractTerm> itrSaContractTerms = saWithExemptions.getContractTerms().iterator();
		    while (itrSaContractTerms.hasNext()){
		        ServiceAgreementContractTerm saContractTerm = itrSaContractTerms.next();
		        
		        if (saContractTerm.fetchIdContractTermType().isTaxExemption()
		                && (isNull(saContractTerm.getEndDate())
		                        || saContractTerm.getEndDate().isSameOrAfter(getProcessDateTime().getDate()))){
		            
		            ServiceAgreementContractTerm_DTO newSaContracTermDto = new ServiceAgreementContractTerm_DTO();
		            newSaContracTermDto.setValue(saContractTerm.getValue());
		            newSaContracTermDto.setTaxExemptTypeId(saContractTerm.getTaxExemptTypeId());
		            newSaContracTermDto.setPercentExempt(saContractTerm.getPercentExempt());
		            newSaContracTermDto.setEndDate(saContractTerm.getEndDate());
		            newSaContracTermDto.setTaxCertification(saContractTerm.getTaxCertification());;

		            serviceAgreement.getContractTerms().add(
		                    newSaContracTermDto,
		                    saContractTerm.fetchIdBillFactor().getId(),
		                    saContractTerm.fetchIdContractTermType(),
		                    "",
		                    getProcessDateTime().getDate());
		            saveChanges();
		        }
		    }
		}
		
		return serviceAgreement;
		// End Change - RDizon - 2021-07-15 - CCB037.4
	}
	
	// Start Add - RDizon - 2021-07-15 - CCB037.4
	/**
	 * This method retrieves a gas SA with active Tax Exemptions 
	 */
	private ServiceAgreement_Id getActiveSAsWithTaxExemptions(Account account) {
	    //Get the first Active, Pending Stop or Reactivated SA
	    SQLResultRow firstRow = null;
	    StringBuilder sbSAswithTaxExemptions = new StringBuilder();

	    sbSAswithTaxExemptions.append("SELECT SA.SA_ID ");
	    sbSAswithTaxExemptions.append("FROM CI_SA SA, ");
	    sbSAswithTaxExemptions.append(    "CI_SA_TYPE SAT ");
	    sbSAswithTaxExemptions.append("WHERE SA.CHAR_PREM_ID = :currentPremise ");
	    sbSAswithTaxExemptions.append(    "AND SA.ACCT_ID = :accountToBeCharged ");
	    sbSAswithTaxExemptions.append(    "AND SA.SA_TYPE_CD = SAT.SA_TYPE_CD ");
	    sbSAswithTaxExemptions.append(    "AND SA.CIS_DIVISION = SAT.CIS_DIVISION ");
	    sbSAswithTaxExemptions.append(    "AND SAT.SVC_TYPE_CD = 'G' ");
	    sbSAswithTaxExemptions.append(    "AND SA.SA_STATUS_FLG IN (:active, :pendingStop, :reactivated) ");
	    sbSAswithTaxExemptions.append(    "AND EXISTS (SELECT 'X' FROM CI_SA_CONTERM SACT ");
	    sbSAswithTaxExemptions.append(                "WHERE SACT.SA_ID = SA.SA_ID ");
	    sbSAswithTaxExemptions.append(                "AND SACT.CONTERM_TYPE_FLG = :taxExemption ");
	    sbSAswithTaxExemptions.append(                "AND (SACT.END_DT <= :processDate ");
	    sbSAswithTaxExemptions.append(                     "OR SACT.END_DT IS NULL)) ");
	    sbSAswithTaxExemptions.append("ORDER BY SA.SA_STATUS_FLG");

	    PreparedStatement psSAsWithTaxExemptions = createPreparedStatement(sbSAswithTaxExemptions.toString(), getClass().getName());
	    psSAsWithTaxExemptions.bindId("currentPremise",currentPremise.getId());
	    psSAsWithTaxExemptions.bindId("accountToBeCharged",account.getId());
	    psSAsWithTaxExemptions.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
	    psSAsWithTaxExemptions.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
	    psSAsWithTaxExemptions.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
	    psSAsWithTaxExemptions.bindLookup("taxExemption", ContractTermTypeLookup.constants.TAX_EXEMPTION);
	    psSAsWithTaxExemptions.bindDate("processDate", getProcessDateTime().getDate());

	    firstRow = psSAsWithTaxExemptions.firstRow();
	    psSAsWithTaxExemptions.close();

	    if(isNull(firstRow)) return null;
	    return (ServiceAgreement_Id) firstRow.getId("SA_ID", ServiceAgreement.class);
	}
	// End Add - RDizon - 2021-07-15 - CCB037.4
	
	/*
	 * Start Change - 2013-05-29 - JPunza 
	 */
	//private Adjustment createAdjustment(ServiceAgreement_Id sourceSA,AdjustmentType adjType,Money amount) {
	private String createAdjustment(ServiceAgreement_Id sourceSA,AdjustmentType adjType,Money amount) {
		/*
		 * End Change - 2013-05-29 - JPunza 
		 */
		logger.info("Adjustment creation entered: ---- ");

		CreateFrozenAdjustmentData frozenAdjData = CreateFrozenAdjustmentData.Factory.newInstance();
		frozenAdjData.setServiceAgreement(sourceSA.getEntity());
		frozenAdjData.setAdjustmentType(adjType);
		frozenAdjData.setAdjustmentAmount(amount);
		frozenAdjData.setAllowZeroAmount(Bool.FALSE);
		CreateFrozenAdjustment frozenAdjustment = CreateFrozenAdjustment.Factory.newInstance();
		frozenAdjData = frozenAdjustment.createFrozenAdjustment(frozenAdjData);
		Adjustment newAdjustment = frozenAdjData.getAdjustment();

		logger.info("Adjustment Successfully Created: ---- "+ newAdjustment.getId().getTrimmedValue());
		/*
		 * Start Change - 2013-05-29 - JPunza 
		 */
		//return newAdjustment;
		return newAdjustment.getId().getTrimmedValue();
		/*
		 * End Change - 2013-05-29 - JPunza 
		 */
	}

	private void createCharOnFA(CharacteristicType charType, String charValue){

		logger.info("------------------------------------------------Char on FA creation entered: ---------------------------------------------------- ");

		FieldActivityCharacteristics faCharacteristics = currentFA.getCharacteristics();
		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//ListFilter<FieldActivityCharacteristic> faCharListFilter = currentFA.getCharacteristics().createFilter(" WHERE this.id.characteristicType = :characteristicType ");
		ListFilter<FieldActivityCharacteristic> faCharListFilter = currentFA.getCharacteristics().createFilter(" WHERE this.id.characteristicType = :characteristicType ", getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		faCharListFilter.bindEntity("characteristicType",charType);
		FieldActivityCharacteristic_DTO faCharacteristicDTO = faCharacteristics.newChildDTO();
		CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

		faCharacteristicDTO.setId(new FieldActivityCharacteristic_Id(currentFA, charType, BigInteger.valueOf(faCharListFilter.listSize() +1)));

		if(charTypeLookup.isAdhocValue()){
			faCharacteristicDTO.setAdhocCharacteristicValue(charValue);
		} else if (charTypeLookup.isPredefinedValue()){
			faCharacteristicDTO.setCharacteristicValue(charValue);
		} else if (charTypeLookup.isForeignKeyValue()){
			faCharacteristicDTO.setCharacteristicValueForeignKey1(charValue);
		}
		FieldActivityCharacteristic faChar = faCharacteristicDTO.newEntity();
		faCharacteristics.add(faChar);
		logger.info("--------------------------------------------Completed adding FA Char---------------------------------------");

	}

	private BillableCharge createBillableCharge(ServiceAgreement sa){

		logger.info("------------------------------------------------Billable Charge creation entered: ---------------------------------------------------- ");
		/*
		 * Start Change - 2013-05-29 - JPunza 
		 */
		//        Date startDate = getProcessDateTime().getDate();
		//        Date endDate = getProcessDateTime().getDate();
		//        BillableChargeTemplate template = new BillableChargeTemplate_Id(parmBillableChargeTemplate.getId().getIdValue()).getEntity();
		//
		//        BillableCharge billableCharge = template.createBillableCharge(sa, startDate, endDate);
		//
		//        return billableCharge;
		Date processDate = getProcessDateTime().getDate();

		return parmBillableChargeTemplate.createBillableCharge(sa, processDate, processDate);
		/*
		 * End Change - 2013-05-29 - JPunza 
		 */
	}


	private void createToDoEntry(BigInteger msgNum, String msgParm1){
		ToDoEntry_DTO entryDto  = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
		/*
		 * Start Change - 2013-05-29 - JPunza 
		 */
		//        ToDoType toDoType = parmToDoType.getId().getEntity();
		//
		//        entryDto.setToDoTypeId(toDoType.getId());
		//        entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
		//        entryDto.setToDoPriority(toDoType.getToDoPriority());
		//        entryDto.setToDoRoleId(getDefaultToDoRole(toDoType).getId());
		//        entryDto.setCreationDateTime(getProcessDateTime());
		//        entryDto.setToDoPriority(toDoType.getToDoPriority());
		ToDoType toDoType = getToDoType();

		entryDto.setToDoTypeId(toDoType.getId());
		entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
		entryDto.setCreationDateTime(getProcessDateTime());
		/*
		 * End Change - 2013-05-29 - JPunza 
		 */

		ArrayList<ToDoSortKeyValue_DTO>sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();
		ToDoTypeSortKeyTypes sortKeyTypes = toDoType.getSortKeyTypes();

		for (Iterator<ToDoSortKeyType> iter = sortKeyTypes.iterator(); iter.hasNext();) {
			ToDoSortKeyType sortKeyType = (ToDoSortKeyType) iter.next();
			ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
			BigInteger seq = sortKeyType.fetchIdSequence();
			sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));

			if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(1))==0){
				sortKeyDto.setKeyValue(currentFA.getCreationDateTime().toString());
			}
			sortKeyList.add(sortKeyDto);
		}

		ArrayList<ToDoDrillKeyValue_DTO>drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
		ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO) createDTO(ToDoDrillKeyValue.class);
		ToDoDrillKeyType drillKeyType = (ToDoDrillKeyType) toDoType.getDrillKeyTypes().iterator().next();
		BigInteger sequence = drillKeyType.fetchIdSequence();
		drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, sequence));

		drillKeyDto.setKeyValue(currentFA.getId().getTrimmedValue());
		drillKeyList.add(drillKeyDto);

		MessageCategory_Id msgCatId = new MessageCategory_Id(BigInteger.valueOf(CustomMessageRepository.MESSAGE_CATEGORY));
		Message_Id msgId = new Message_Id(msgCatId, msgNum);
		entryDto.setMessageId(msgId);

		ArrayList <String> messageParameterList = new ArrayList<String> ();
		if (!isNull(msgParm1)){
			messageParameterList.add(0, msgParm1);
		}
		ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory.newInstance();

		toDoEntryData.setDrillKeys(drillKeyList);
		toDoEntryData.setEntryDto(entryDto);
		toDoEntryData.setSortKeys(sortKeyList);
		toDoEntryData.setMessageParams(messageParameterList);

		//KL20130617 - Start of fix for Defect 1972 
		ArrayList <ToDoEntryCharacteristic_DTO>  charList = new ArrayList<ToDoEntryCharacteristic_DTO> ();
		toDoEntryData.setToDoCharacteristics(charList);

		ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
		@SuppressWarnings("unused")
		ToDoEntry toDoEntry = toDoProcessor.addToDo(toDoEntryData);
		//ArrayList <ToDoEntryCharacteristic_DTO>  charList = new ArrayList<ToDoEntryCharacteristic_DTO> ();
		//KL20130617 - End of fix for Defect 1972 

		/**
		 * KL20130624 - Defect fix for #2495 - Received confirmation from Fred that though the FS says we need to 
		 * add the account provided as FA Char as characteristics on the To Do entry, it is no more required.
		 * Hence, commented out below logic. 
		 * 
		 * 
		ToDoEntryCharacteristic_DTO toDoCharDTO = (ToDoEntryCharacteristic_DTO) createDTO(ToDoEntryCharacteristic.class);
		toDoCharDTO.setId(new ToDoEntryCharacteristic_Id(toDoEntry.getId(),parmAccountIdCharType.getId(),BigInteger.ONE));
		CharacteristicTypeLookup toDoCharTypeLookup = parmAccountIdCharType.getCharacteristicType();
		if(toDoCharTypeLookup.isAdhocValue()){
			toDoCharDTO.setAdhocCharacteristicValue(account.getId().getIdValue().trim());
		} else if (toDoCharTypeLookup.isPredefinedValue()){
			toDoCharDTO.setCharacteristicValue(account.getId().getIdValue().trim());
		} else if (toDoCharTypeLookup.isForeignKeyValue()){
			toDoCharDTO.setCharacteristicValueForeignKey1(account.getId().getIdValue().trim());
		}

		//KL20130617 - Start of fix for Defect 1972 
		toDoCharDTO.newEntity();
		//KL20130617 - End of fix for Defect 1972 
		 */

		/**
		 * KL20130617 - Start of Defect Fix for 1972
		 * 
		charList.add(toDoCharDTO);
		toDoEntryData.setToDoCharacteristics(charList);

		//KL20130606 - Start of fix for Defect 2279
		//ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
		toDoProcessor.addToDo(toDoEntryData);
		 *
		 * KL20130617 - Defect Fix for 1972
		 */

	}

	/*
	 * Start Delete - 2013-05-29 - JPunza 
	 */
	//    private Role getDefaultToDoRole(ToDoType toDoType) {
	//        Role defaultRole = null;
	//        StringBuilder defaultRoleQueryString = new StringBuilder();
	//        defaultRoleQueryString.append("SELECT ROLE_ID FROM CI_TD_VAL_ROLE WHERE TD_TYPE_CD = :toDoType AND DEFAULT_SW = :yes ");
	//
	//        PreparedStatement defaultRolePrepStmt = createPreparedStatement(defaultRoleQueryString.toString());
	//        defaultRolePrepStmt.bindId("toDoType", toDoType.getId());
	//        defaultRolePrepStmt.bindBoolean("yes", Bool.TRUE);
	//        defaultRole = defaultRolePrepStmt.firstRow().getEntity("ROLE_ID",Role.class);
	//        defaultRolePrepStmt.close();
	//        return defaultRole;
	//    }
	/*
	 * End Delete - 2013-05-29 - JPunza 
	 */

	// KL20130625 - Start of defect fix for #2539
	//private Money retrieveCharValue(ServiceAgreement sa,CharacteristicType charType){
	private BigDecimal retrieveCharValue(CharacteristicType charType){
		// KL20130625 - Start of defect fix for #2539

		/*
		 * Start Change - 2013-05-29 - JPunza 
		 */
		//        String charVal = null;
		//
		//        for(FieldActivityCharacteristic faChar : currentFA.getCharacteristics()){
		//            if(faChar.fetchIdCharacteristicType().equals(charType)){
		//
		//                CharacteristicTypeLookup charTypeLookup = faChar.fetchIdCharacteristicType().getCharacteristicType();
		//                if(charTypeLookup.isAdhocValue()){
		//                    charVal = faChar.getAdhocCharacteristicValue();
		//                }else if(charTypeLookup.isPredefinedValue()){
		//                    charVal = faChar.getCharacteristicValue();
		//                }else if(charTypeLookup.isForeignKeyValue()){
		//                    charVal = faChar.getCharacteristicValueForeignKey1();
		//                }
		//            }
		//
		//        }
		//        if(!isNull(charVal)){
		//            return new Money(charVal,sa.getCurrencyId());
		//        }else{
		//            return null;
		//        }

		String amountStr = null;
		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//ListFilter<FieldActivityCharacteristic> charFilter = currentFA.getCharacteristics().createFilter("where this.id.characteristicType = :charType");
		ListFilter<FieldActivityCharacteristic> charFilter = currentFA.getCharacteristics().createFilter("where this.id.characteristicType = :charType", getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		charFilter.bindEntity("charType", charType);

		FieldActivityCharacteristic faCharacteristic = charFilter.firstRow();

		if (notNull(faCharacteristic)) {

			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

			if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
				amountStr = faCharacteristic.getAdhocCharacteristicValue().trim();
			}            
			else if (charTypeLookup.isPredefinedValue()) {
				amountStr = faCharacteristic.getCharacteristicValue().trim();
			}
			else {
				amountStr = faCharacteristic.getCharacteristicValueForeignKey1().trim();
			}
		}

		// KL20130625 - Start of defect fix for #2539
		if (isBlankOrNull(amountStr)) {
			// KL20130724 - Start of Fix for IM-034446
			shouldCreateToDoEntry = true;
			return BigDecimal.ZERO;
			// KL20130724 - End of Fix for IM-034446
		}
		else {
			return new BigDecimal(amountStr);
		}

		/**
		 * 
		if (isBlankOrNull(amountStr)) {
			return null;
		}
		else {
			return new Money(amountStr, sa.getCurrencyId());
		}
		 */
		// KL20130625 - End of defect fix for #2539
		/*
		 * End Change - 2013-05-29 - JPunza 
		 */
	}
	
	//Start Add JVitug - B-19769 - 2021-12-29
	private void createPaymentArrangement(ServiceAgreement saToCharge) {
					
		// If we're creating a payment arrangement for this SA, activate the SA first.
		// Start Add AshishR - B-20934 - 2022-03-08
		// LGC and 200 service divisions seem to be behaving differently
		// LGC jobbing SA auto closes but Alabama jobbing SA stays open
		// following code is to make sure that jobbing SA closes since we are moving balance to payment arrangement
		ServiceAgreement_DTO pendingStopSA_DTO = saToCharge.getDTO();
		pendingStopSA_DTO.setEndDate(saToCharge.getStartDate());
		saToCharge.setDTO(pendingStopSA_DTO);
		// End Add AshishR - B-20934 - 2022-03-08
		saToCharge.activateOrTerminate(saToCharge.getStartDate());
		// Use the base business service "C1-CreatePaymentArrangement" to create a payment arrangement
		BusinessServiceInstance bsInstance = BusinessServiceInstance.create("CM-CreatePaymentArrangement");
		
		// populate schema elements
		bsInstance.set("accountId", account.getId().getTrimmedValue());
		bsInstance.set("cisDivision", parmCisDivision.getId().getTrimmedValue());
		bsInstance.set("saType", paymentArrangementSAType.trim());	
		bsInstance.set("create" , Bool.TRUE);
		bsInstance.set("paNewTotAmt", saToCharge.getPayoffBalance().getAmount());
		bsInstance.set("recurringChargeAmount", Money.ZERO);
		bsInstance.set("installment" , BigDecimal.valueOf(numberOfInstallments.doubleValue()));
		
		//Set the PA SA Collection element List
		COTSInstanceList pasaCollection = bsInstance.getList("PASACollection");
		COTSInstanceListNode newPasa = pasaCollection.newChild();
		
		newPasa.set("saId", saToCharge.getId().getTrimmedValue());
		newPasa.set("currentAmount", saToCharge.getCurrentBalance());
		newPasa.set("totalAmount", saToCharge.getPayoffBalance());
		
		//populate the SA Arrears list element
		COTSInstanceList saArrears = newPasa.getList("saArrears"); 
		COTSInstanceListNode newSaArrear = saArrears.newChild();
		
		newSaArrear.set("saId" , saToCharge.getId().getTrimmedValue());
		newSaArrear.set("arrearsAmount" , saToCharge.getPayoffBalance());
		newSaArrear.set("checkedForPA" , Bool.TRUE);
		
		BusinessServiceInstance outputBsInstance = BusinessServiceDispatcher.execute(bsInstance);
		
	}
	//End Add JVitug - B-19769 - 2021-12-29
}
