/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Maintain Removal Reason Code Characteristic 
 * 
 * This algorithm will add Removal Reason and Technician Name Meter 
 * Characteristics when a Remove Meter Step type was completed.
 *            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-03-27   JPunza  NI0009.3 Initial Version.
 * 2016-01-26   MPang	Updated for CCB v2.4 compilation.
 * 2020-05-22   NMendo  B-15626. Copy the characteristics to the meter 
 *                      only if the remove step is performed.
 *************************************************************************/

package com.splwg.cm.domain.admin.fieldActivityType;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityStepTypeActionLookup;

//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
import com.splwg.ccb.domain.admin.fieldActivityType.algorithm.faCompletion.FieldActivityTypeFaCompletionAlgorithmSpot;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityStep;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic_DTO;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristics;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory;
//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author jpunzalan2
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = removalReasonCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = unknownReasonCharacteristicValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = technicianNameCharacteristicType, required = true, type = entity)})
 */
public class CmMaintainRemovalReasonCodeCharacteristicAlgComp_Impl 
        extends CmMaintainRemovalReasonCodeCharacteristicAlgComp_Gen 
        implements FieldActivityTypeFaCompletionAlgorithmSpot {

    // Constant Variables
    private final String REMOVAL_REASON = "Removal Reason";
    private final String UNKNOWN_REASON = "Unknown Reason";
    private final String TECHNICIAN_NAME = "Technician Name";
        
    // Soft Parameters
    private CharacteristicType removalReasonCharType;
    private CharacteristicType technicianNameCharType;
    private String unknownReasonCharValue;
    
    // Hard Parameter
    private FieldActivity fieldActivity;
    
    public void setFieldActivity(FieldActivity arg0) {
        fieldActivity = arg0;
    }
    
    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        
        // Removal Reason Characteristic Type
        removalReasonCharType = getRemovalReasonCharacteristicType();
        if (validateCharacteristicEntity(removalReasonCharType, CharacteristicEntityLookup.constants.METER).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0009_3_charTypeInvalidForEntity(
                    getAlgorithm().getId().getTrimmedValue(),
                    REMOVAL_REASON, 
                    removalReasonCharType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.METER.getLookupValue().fetchLanguageDescription()));
        }
        
        if (validateCharacteristicEntity(removalReasonCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0009_3_charTypeInvalidForEntity(
                    getAlgorithm().getId().getTrimmedValue(),
                    REMOVAL_REASON, 
                    removalReasonCharType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.FIELD_ACTIVITY.getLookupValue().fetchLanguageDescription()));
        }
        
        // Unknown Reason Characteristic Value
        unknownReasonCharValue = getUnknownReasonCharacteristicValue();
        if (removalReasonCharType.getCharacteristicType().isPredefinedValue() 
                && validateCharTypeAndCharValue(removalReasonCharType, unknownReasonCharValue).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0009_3_charValueInvalidForCharType(
                    getAlgorithm().getId().getTrimmedValue(),
                    UNKNOWN_REASON, 
                    unknownReasonCharValue, 
                    removalReasonCharType.getId().getTrimmedValue()));
        }
        
        // Technician Name Characteristic Type
        technicianNameCharType = getTechnicianNameCharacteristicType();
        if (validateCharacteristicEntity(technicianNameCharType, CharacteristicEntityLookup.constants.METER).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0009_3_charTypeInvalidForEntity(
                    getAlgorithm().getId().getTrimmedValue(),
                    TECHNICIAN_NAME, 
                    technicianNameCharType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.METER.getLookupValue().fetchLanguageDescription()));
        }
        
        if (validateCharacteristicEntity(technicianNameCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0009_3_charTypeInvalidForEntity(
                    getAlgorithm().getId().getTrimmedValue(),
                    TECHNICIAN_NAME, 
                    technicianNameCharType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.FIELD_ACTIVITY.getLookupValue().fetchLanguageDescription()));
        }
    }

    /**
     * This method validates if a characteristic type is valid for a specific characteristic entity.
     * @param charType - Characteristic Type
     * @param charEntityLookup - Characteristic Entity Lookup
     * @return Bool
     */
    private Bool validateCharacteristicEntity(CharacteristicType charType, CharacteristicEntityLookup charEntityLookup) {
        
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType.getId(), charEntityLookup);        
        if (isNull(charEntityId.getEntity())) {
            return Bool.FALSE;
        }
        
        return Bool.TRUE;
    }
    
    /**
     * This method validates if characteristic value is valid for a given characteristic type. 
     * @param charType - Characteristic Type
     * @param charValue - String
     * @return Bool
     */
    private Bool validateCharTypeAndCharValue(CharacteristicType charType, String charValue) {

        CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
        if (charTypeLookup.isPredefinedValue()) {
            CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charType, charValue);
            if (isNull(charValueId.getEntity())) {
                return Bool.FALSE;
            }
        }

        return Bool.TRUE;
    }
    
    public void invoke() {

        // Check for Remove Meter FA Step Action 
    	//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        // ListFilter<FieldActivityStep> faStepsFilter = fieldActivity.getSteps().createFilter("where this.faStepTypeAction = :removeMeterAction");
    	ListFilter<FieldActivityStep> faStepsFilter = fieldActivity.getSteps().
    			createFilter("where this.faStepTypeAction = :removeMeterAction", getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        faStepsFilter.bindLookup("removeMeterAction", FieldActivityStepTypeActionLookup.constants.REMOVE_METER);

        FieldActivityStep faStep = faStepsFilter.firstRow();
        
        if (notNull(faStep)) {
            
            // Get Removal Reason Characteristic from FA
            String removalReason = getFaCharacteristicValue(removalReasonCharType);
            if (isBlankOrNull(removalReason)) {
                removalReason = unknownReasonCharValue;
            }
            
            // Get Technical Name Characteristic from FA
            String technicalName = getFaCharacteristicValue(technicianNameCharType);
            
            ServicePointMeterHistory spmh = faStep.fetchSpMeterHistory();
            
            // Start Change - NMendo - 2020-05-22 - B-15626
            //if (isNull(spmh)) {
                //addError(CustomMessageRepositoryMDC.NI0009_3_spMeterHistoryNotProvided(fieldActivity.getId().getTrimmedValue()));    
            //}
            // Copy the characteristics to the meter only if the remove step is performed.
            if (notNull(spmh)) {
            	Meter meter = spmh.getMeterConfiguration().getMeter();
                
                // Add Removal Reason Characteristic to Meter
                addMeterCharacteristic(meter, removalReasonCharType, removalReason);
                            
                // Add Technical Name Characteristic to Meter
                if (notBlank(technicalName)) {
                    addMeterCharacteristic(meter, technicianNameCharType, technicalName);               
                }
            }
            // End Change - NMendo - 2020-05-22 - B-15626
        }    
    }
    
    /**
     * This method retrieves the value from a FA characteristic given the characteristic type.
     * @param characteristicType - Characteristic Type
     * @return String
     */
    private String getFaCharacteristicValue(CharacteristicType characteristicType) {

        // Retrieve FA Characteristic with the highest sequence
    	//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        // ListFilter<FieldActivityCharacteristic> charFilter = fieldActivity.getCharacteristics().createFilter("where this.id.characteristicType = :charType order by this.id.sequence desc");
    	ListFilter<FieldActivityCharacteristic> charFilter = fieldActivity.
    			getCharacteristics().createFilter("where this.id.characteristicType = :charType order by this.id.sequence desc", getClass().getName());
    	//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        charFilter.bindEntity("charType", characteristicType);
        
        FieldActivityCharacteristic faCharacteristic = charFilter.firstRow();
                
        if (notNull(faCharacteristic)) {
        
            CharacteristicTypeLookup charTypeLookup = characteristicType.getCharacteristicType();
            
            if (charTypeLookup.isPredefinedValue()) {
                return faCharacteristic.getCharacteristicValue().trim();
            }
            else if (charTypeLookup.isForeignKeyValue()) {
                return faCharacteristic.getCharacteristicValueForeignKey1().trim();
            }
            else {            
                return faCharacteristic.getAdhocCharacteristicValue().trim();
            }
        }
        
        return null;
    }
    
    /**
     * This method adds Meter Characteristic.
     * @param meter - Meter
     * @param charType - Characteristic Type
     * @param charValue - Characteristic Value
     */
    private void addMeterCharacteristic(Meter meter, CharacteristicType charType, String charValue) {
        
        CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType(); 
        MeterCharacteristics meterChars = meter.getCharacteristics();
            
        // Add Meter Characteristic
        MeterCharacteristic_DTO meterCharDto = meterChars.newChildDTO();
        
        if (charTypeLookup.isPredefinedValue()) { 
            meterCharDto.setCharacteristicValue(charValue);
        } 
        else if (charTypeLookup.isForeignKeyValue()) {
            meterCharDto.setCharacteristicValueForeignKey1(charValue);
        }
        else { 
            meterCharDto.setAdhocCharacteristicValue(charValue);   
        }
        
        meterChars.add(meterCharDto, charType.getId(), getProcessDateTime().getDate());        
    }

}
