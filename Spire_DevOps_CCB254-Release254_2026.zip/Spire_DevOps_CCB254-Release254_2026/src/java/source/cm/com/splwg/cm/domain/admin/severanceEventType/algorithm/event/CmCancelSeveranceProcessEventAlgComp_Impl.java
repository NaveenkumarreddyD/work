/*
 ***************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This Severance Event Type Event Algorithm will cancel its own 
 * Severance Process and all pending Severance Events.
 *      
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2018-03-27   JHERNA  SysAid#235527. Initial Version.
 * 
 **************************************************************************/
package com.splwg.cm.domain.admin.severanceEventType.algorithm.event;

import java.util.Iterator;

import com.splwg.ccb.api.lookup.SeveranceEventStatusLookup;
import com.splwg.ccb.api.lookup.SeveranceStatusLookup;
import com.splwg.ccb.api.lookup.SeveranceStatusReasonLookup;
import com.splwg.ccb.domain.admin.severanceEventType.algorithm.event.SeveranceEventTypeEventAlgorithmSpot;
import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceEvent;
import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceEvent_DTO;
import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceProcess;
import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceProcess_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;

/**
 * @author 90622
 *
@AlgorithmComponent ()
 */
public class CmCancelSeveranceProcessEventAlgComp_Impl 
		extends CmCancelSeveranceProcessEventAlgComp_Gen 
		implements SeveranceEventTypeEventAlgorithmSpot {

	// Hard Parameters
	@SuppressWarnings("unused")
	private ServiceAgreement hpSA;
	private SeveranceEvent hpSeveranceEvent;
	
	// Setter Methods
	@Override
	public void setServiceAgreement(ServiceAgreement sa) {
		hpSA = sa;
	}

	@Override
	public void setSeveranceEvent(SeveranceEvent sevEvt) {
		hpSeveranceEvent = sevEvt;
	}
	
	// Main Method
	@Override
	public void invoke() {
	
		SeveranceProcess severanceProcess = hpSeveranceEvent.fetchIdSeveranceProcess();
		// Cannot use this base method because of requirement that previously completed events should not be updated to cancel status.
		//Bool allowReconnect = Bool.TRUE;
		//severanceProcess.cancel(SeveranceStatusReasonLookup.constants.CANCELEDBY_SYSTEM, allowReconnect);
		
		Iterator<SeveranceEvent> collSevEvts = severanceProcess.getSeveranceEvents().iterator();
		// Cancel other pending severance events
		while (collSevEvts.hasNext()) {
			SeveranceEvent sevEvt = (SeveranceEvent) collSevEvts.next();
			if (sevEvt.getSeveranceEventStatus().isPending()) {
				if(hpSeveranceEvent.equals(sevEvt)) {
					try {
						startChanges();
						SeveranceEvent_DTO sevEvtDTO = hpSeveranceEvent.getDTO();
						sevEvtDTO.setSeveranceEventStatus(SeveranceEventStatusLookup.constants.COMPLETED);
						sevEvtDTO.setCompletionDate(this.getProcessDateTime().getDate());
						hpSeveranceEvent.setDTO(sevEvtDTO);
						saveChanges();
					}
					catch (Exception e) {
						e.printStackTrace();
					}					
				}
				else {
					try {	
						startChanges();
						SeveranceEvent_DTO sevEvtDTO = sevEvt.getDTO();
						sevEvtDTO.setSeveranceEventStatus(SeveranceEventStatusLookup.constants.CANCELED);
						sevEvtDTO.setCompletionDate(this.getProcessDateTime().getDate());
						sevEvt.setDTO(sevEvtDTO);
						saveChanges();
					}
					catch (Exception e) {
						e.printStackTrace();						
					}
				}
			}
		}
		// Cancel this severance process
		startChanges();
		SeveranceProcess_DTO sevProcDTO = severanceProcess.getDTO();
		sevProcDTO.setSeveranceStatus(SeveranceStatusLookup.constants.INACTIVE);
		sevProcDTO.setSeveranceStatusReason(SeveranceStatusReasonLookup.constants.CANCELEDBY_SYSTEM);
		//sevProcDTO.setComments("==Canceled By Severance Event on "+this.getProcessDateTime().toLocalizedString()+"==");
		severanceProcess.setDTO(sevProcDTO);
		saveChanges();
	}
}