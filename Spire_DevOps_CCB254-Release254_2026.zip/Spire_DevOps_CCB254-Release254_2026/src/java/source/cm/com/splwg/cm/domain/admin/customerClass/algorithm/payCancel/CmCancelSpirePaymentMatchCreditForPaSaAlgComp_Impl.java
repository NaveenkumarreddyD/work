/*
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                     
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * This algorithm would perform the following if a payment event is
 * being cancelled:
 * 
 * 1.) Search for spire credit adjustment created by this payment event
 * 2.) Cancel the spire credit adjustment when found.
 * 
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:       by:          Reason:
 * YYYY-MM-DD  FLName
 * 2018-09-19  JHERNA		SysAid#245408 Initial Version.
 * 
 ***********************************************************************
 */
package com.splwg.cm.domain.admin.customerClass.algorithm.payCancel;

import java.util.Iterator;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.admin.adjustmentCancelReason.entity.AdjustmentCancelReason;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType_Id;
import com.splwg.ccb.domain.admin.customerClass.algorithm.payCancel.CustomerClassPaymentCancellationAlgorithmSpot;
import com.splwg.ccb.domain.admin.paymentCancelReason.entity.PaymentCancelReason;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.ccb.domain.payment.payment.entity.PaymentSegment;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentEvent;
import com.splwg.cm.api.lookup.CmLowIncomeProgramConfigurationsOptionTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;

/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = featureConfiguration, name = featureConfigLIP, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = charTypePayEventId, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentCancelReason, name = adjustmentCancelReason, required = true, type = entity)})
 */
public class CmCancelSpirePaymentMatchCreditForPaSaAlgComp_Impl 
		extends CmCancelSpirePaymentMatchCreditForPaSaAlgComp_Gen 
		implements CustomerClassPaymentCancellationAlgorithmSpot {

	/*Hard Parameter*/
	@SuppressWarnings("unused")
	private Account hpAccount;
	private Payment hpPayment;
	@SuppressWarnings("unused")
	private Money hpPaymentAmount;
	@SuppressWarnings("unused")
	private PaymentCancelReason hpPayCancelReason;
	
	/*Soft Parameter*/
	private FeatureConfiguration parmFeatConigfLIP;
	private AdjustmentCancelReason parmAdjCancelReason;
	private CharacteristicType parmCharTypePayEventID;	
	
	/*Work Variables*/
	private AdjustmentType_Id wAdjTypeIDSpireCredit;	

	@Override
	public void setAccount(Account arg0) {
		hpAccount = arg0;
	}

	@Override
	public void setPayment(Payment arg0) {
		hpPayment = arg0;
	}

	@Override
	public void setPaymentAmount(Money arg0) {
		hpPaymentAmount = arg0;
	}

	@Override
	public void setPaymentCancelReason(PaymentCancelReason arg0) {
		hpPayCancelReason = arg0;
	}

	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		
		// Retrieve Parameter 10: Feature Configuration for Low Income Program Configuration
		parmFeatConigfLIP = this.getFeatureConfigLIP();
		// Retrieve Parameter 20: Characteristic Type Payment Event Id
		parmCharTypePayEventID = this.getCharTypePayEventId();
		// Retrieve Parameter 30: Adjustment Cancel Reason
		parmAdjCancelReason = this.getAdjustmentCancelReason();
		// Retrieve Spire Credit Adjustment Type from the feature configuration
		CmMGEFeatureConfigurationOptionsRetriever fcHelper = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
		wAdjTypeIDSpireCredit = fcHelper.getAdjustmentTypeFeatureOptionValue(parmFeatConigfLIP.getId(),
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.SPIRE_CREDIT_ADJUSTMENT_TYPE,
				Bool.TRUE,
				Bool.FALSE);
	}

	@Override
	public void invoke() {
		
		PaymentEvent payEvent = hpPayment.getPaymentEvent();
		
		Iterator<PaymentSegment> collOfPaySegment = hpPayment.getSegments().iterator();
		while (collOfPaySegment.hasNext()) {
			PaymentSegment paySegment = collOfPaySegment.next();
			Iterator<SQLResultRow> collOfSpireCred = cmRetrieveSpirePayMatchCredit(payEvent, paySegment.getServiceAgreement().getId());
			while (collOfSpireCred.hasNext()) {
				SQLResultRow sqlRow = collOfSpireCred.next();
				Adjustment_Id adjID = (Adjustment_Id) sqlRow.getId("ADJ_ID", Adjustment.class);
				Adjustment adj = adjID.getEntity();
				adj.cancel(parmAdjCancelReason);
			}			
		}		
	}
	
	private Iterator<SQLResultRow> cmRetrieveSpirePayMatchCredit(PaymentEvent payEvent, ServiceAgreement_Id saID) {
		
		Iterator<SQLResultRow> returnValue;
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT "); 
		stringBuilder.append("  UNIQUE(ADJ.ADJ_ID) ADJ_ID ");
		stringBuilder.append("FROM "); 
		stringBuilder.append("  CI_ADJ ADJ, ");
		stringBuilder.append("  CI_ADJ_CHAR AC ");
		stringBuilder.append("WHERE "); 
		stringBuilder.append("  ADJ.SA_ID = :saID ");
		stringBuilder.append("  AND ADJ.ADJ_TYPE_CD = :adjType ");
		stringBuilder.append("  AND AC.ADJ_ID = ADJ.ADJ_ID ");
		stringBuilder.append("  AND AC.CHAR_TYPE_CD = :charTypePayEventId ");
		stringBuilder.append("  AND AC.SRCH_CHAR_VAL = '"+payEvent.getId().getTrimmedValue()+"' ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==cmRetrieveSpirePayMatchCredit==");
		prepState.bindId("saID", saID);
		prepState.bindId("adjType", wAdjTypeIDSpireCredit);
		prepState.bindId("charTypePayEventId", parmCharTypePayEventID.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		returnValue = prepState.list().iterator();
		prepState.close();
		return returnValue;	 
		
	}	
}
