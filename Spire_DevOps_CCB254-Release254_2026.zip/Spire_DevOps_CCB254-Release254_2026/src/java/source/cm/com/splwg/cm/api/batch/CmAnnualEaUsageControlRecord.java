package com.splwg.cm.api.batch;

import java.math.BigInteger;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmAnnualEaUsageControlRecord {
    
    // Values
    private String recordName;
    private String filler1;
    private BigInteger numberOfRecords;
    private String filler2;
    private String dateOfReport;
    private String filler3;
    private String dssReportNoSupplierInfo;
    
    public CmAnnualEaUsageControlRecord(String rawControlRecord) {
        
        recordName = rawControlRecord.substring(0, 7);
        filler1 = rawControlRecord.substring(7, 8);
        numberOfRecords = new BigInteger(rawControlRecord.substring(8, 14));
        filler2 = rawControlRecord.substring(14, 15);
        dateOfReport = rawControlRecord.substring(15, 23);
        filler3 = rawControlRecord.substring(23, 24);
        dssReportNoSupplierInfo = rawControlRecord.substring(24);
        
    }
    
    public BigInteger getNumberOfRecords() {
        return numberOfRecords;
    }

    public class CmAnnualEaUsageControlOutputRecord extends ColumnDelimitedRecord {

        public CmAnnualEaUsageControlOutputRecord() {
            
            super(7);
            
            rightPadColumn(1, 7, recordName);
            rightPadColumn(2, 1, filler1);
            leftPadColumnWithZeros(3, 6, numberOfRecords.toString());
            rightPadColumn(4, 1, filler2);
            rightPadColumn(5, 8, dateOfReport);
            rightPadColumn(6, 1, filler3);
            rightPadColumn(7, 9, dssReportNoSupplierInfo);
            
        }
        
    }

    public String createRecordString() {
        
        return new CmAnnualEaUsageControlOutputRecord().createRecordString();
        
    }
    
}
