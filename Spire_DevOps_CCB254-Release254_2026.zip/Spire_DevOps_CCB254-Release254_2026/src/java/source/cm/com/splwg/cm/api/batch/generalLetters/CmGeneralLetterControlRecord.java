/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * End of Letter Extract Record                                                               
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                          
 * 2020-04-01  JHERNA      SA-322461. Initial version                 
 *                                                                
 *******************************************************************************
 */

package com.splwg.cm.api.batch.generalLetters;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmGeneralLetterControlRecord extends ColumnDelimitedRecord {
    
    // Mailing Information
    private static final String CTRL_PRINT_KEY = "0010"; 
    private static final String BLANK = "  ";
    private static final String EMPTY_STR = "";
    private static final String DEFAULT_TIME_FORMAT_FILLER = ".000000";
    
    public CmGeneralLetterControlRecord() {
        super(18);
        defaultPrintKey();
    }

    /* EXTRACT COMMON SECTIONS */
    private void defaultPrintKey() {
        this.rightPadColumn(1, 4, formatString(CTRL_PRINT_KEY, 4));
    }
    
    public void setSortKeyLetterTemplateCode(String letterTemplateCode) {
    	letterTemplateCode = BLANK; // Control Record does not have any sort key
        this.rightPadColumn(2, 12, formatString(letterTemplateCode, 12));
    }
    
    public void setSortKeyCcId(String ccId) {
    	ccId = BLANK; // Control Record does not have any sort key
        this.rightPadColumn(3, 10, formatString(ccId, 10));
        this.setSortKeyCcRecordGroup();
        this.setSortKeyCAndCRecordGroup();
    }
    
    private void setSortKeyCcRecordGroup() {
        this.rightPadColumn(4, 2, BLANK);
    }
    
    private void setSortKeyCAndCRecordGroup() {
        this.rightPadColumn(5, 2, BLANK);
    }          
    
    public void setMailingKey(String mailingKey) {
    	mailingKey =  BLANK; // Control Record does not have any sort key
        this.rightPadColumn(6, 12, formatString(mailingKey, 12));
        this.setFiller3Spaces();
    }
    
    private void setFiller3Spaces() {
        this.rightPadColumn(7, 3, " ");

    }
    
    /* ************************/
    /* Control Record Details */
    /* ************************/
    
    public void setBatchControl(String batchControlID) {
    	this.rightPadColumn(8, 8, formatString(batchControlID, 8));
    }
    
    public void setBatchNbr(String batchNbr) {
    	this.leftPadColumnWithZeros(9, 10, formatString(batchNbr, 10));
    }
    
    public void setBatchRerunNbr(String batchRerunNbr) {
    	this.leftPadColumnWithZeros(10, 10, formatString(batchRerunNbr, 10));
    }
    
    public void setExtractedCCCount(String extractedCcCount) {        
        this.leftPadColumnWithZeros(11, 10, formatString(extractedCcCount, 10));
    }
    
    public void setExtractDttm(String extractDttm) {
        this.rightPadColumn(12, 19, formatString(extractDttm, 19));
        this.setTimeFormatFiller();
    }   
    
    private void setTimeFormatFiller() {
    	this.rightPadColumn(13, 7, DEFAULT_TIME_FORMAT_FILLER);
    }
    
    public void setCCIDStart(String ccIdStart) {        
        this.leftPadColumnWithZeros(14, 10, ccIdStart);
    }
    
    public void setCCIDEnd(String ccIdEnd) {        
        this.leftPadColumnWithZeros(15, 10, ccIdEnd);
    }
    
    public void setThreadNumber(String threadNbr) {        
        this.leftPadColumnWithZeros(16, 10, threadNbr);
    }
    
    public void setThreadCnt(String threadCnt) {        
        this.leftPadColumnWithZeros(17, 10, threadCnt);
        setFillerEndSpaces();
    }    
        
    private void setFillerEndSpaces() {
        this.rightPadColumn(18, 1863, BLANK);
    }

    /**
     * Returns "" if text is null;
     * Truncates text if length exceed fieldLength;
     * @param text String variable to be formatted
     * @param fieldLength Length of Field
     * @return formatted text
     */
    private String formatString(String text, int fieldLength) {
        if(text == null) {
            text = EMPTY_STR;
        }
        else {
            text = text.trim();
            if(text.length() > fieldLength) {
                text = text.substring(0, fieldLength);
            }
        }
        return text;
    }
}
