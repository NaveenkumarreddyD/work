/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Walmart Payment Returns File Type 
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2021-06-09   Nyada          WalmartRTP. Initial Version.
 ******************************************************************************************/

package com.splwg.cm.api.lookup;

/**
 * @author 42422
 *
@LookupFieldname (value = CM_WAL_FILE_TYP_FLG)
 */
public class CmWalmartPayFileTypeFlagLookup_Impl extends
		CmWalmartPayFileTypeFlagLookup_Gen {

}
