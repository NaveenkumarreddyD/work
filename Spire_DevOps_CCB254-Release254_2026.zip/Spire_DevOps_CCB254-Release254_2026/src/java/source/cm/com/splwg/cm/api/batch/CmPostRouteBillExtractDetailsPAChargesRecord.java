/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 2024-07-30   DLampa     INC0037039. Updated field lengths to match 
 *                         the file layout extracted by the CM-BILEXTR 
 *                         algorithm
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractDetailsPAChargesRecord 
		extends ColumnDelimitedRecord{	
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractDetailsPAChargesRecord() {
		super(9);
		
		// Initialize all fields as blank/spaces
		this.setBPPrinterKey(" ");		
		this.setBPSortKey(" ");
		this.setBPMailingKey(" ");
		this.setSAID(" ");
		this.setSaType(" ");
		this.setDescrOnBill(" ");
		this.setCalcAmt(BigDecimal.ZERO, "0");	
		this.setFiller();
	}
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * 
	 */
	public void setBPPrinterKey(String value) {		
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
	public void setBPSortKey(String value) {
		rightPadColumn(2, 184, truncateInput(value, 184));
	}
	public void setBPMailingKey(String value) {
		rightPadColumn(3, 15, truncateInput(value, 15));
	}	
	/*
	 * Payment Arrangement Charges
	 */
	public void setSAID(String value) {
		rightPadColumn(4, 10, truncateInput(value, 10));
	}
	public void setSaType(String value) {
		rightPadColumn(5, 8, truncateInput(value, 8));
	}
	public void setDescrOnBill(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(6, 80, truncateInput(value, 80));
		rightPadColumn(6, 254, truncateInput(value, 254));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setCalcAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(7, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(8, 15, truncateInput(value, 15));			
	}	
	private void setFiller() {
		//rightPadColumn(8, 3331, " ");
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(9, 3127, " ");
		rightPadColumn(9, 2953, " ");
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
}