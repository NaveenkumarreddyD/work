/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This custom Batch Process will upload customer contacts
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2016-09-15   RGoke			SA-138152-001 Initial Version.
 * **************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass_Id;
import com.splwg.ccb.domain.admin.customerContactType.entity.CharacteristicTypeContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author psreekan
 *
@BatchJob (multiThreaded = false, rerunnable = false,modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)})
 */
public class CmCustomerContactUploadBatch extends
		CmCustomerContactUploadBatch_Gen {

	// Start - Batch job Soft Parameters
	private String filePath;
	private String fileName;

	private static final String FILE_PATH = "FILE_PATH";
	private static final String FILE_NAME = "FILE_NAME";

	/**
	 * This method validates the soft parameters of the batch
	 * 
	 * @param isNewRun
	 *            boolean
	 */
	public void validateSoftParameters(boolean isNewRun) {

		retrieveBatchParameters();
		validateBatchParameters();
	}

	public JobWork getJobWork() {

		List<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();

		if (!filePath.endsWith(File.separator)) {
			filePath = filePath + File.separator;
		}
		if (notNull(fileName)) {
			boolean fileExists = new File(filePath + fileName).exists();

			if (!(fileExists)) {

				 addError(CustomMessageRepositoryMGE.fileDoesNotExist(filePath,
				 fileName));

			} else {
				File file = new File(filePath + fileName);
				if (file.isFile()) {

					threadWorkUnit = new ThreadWorkUnit();
					threadWorkUnit.addSupplementalData(FILE_PATH,
							file.getAbsolutePath());
					threadWorkUnit.addSupplementalData(FILE_NAME,
							file.getName());
					arrayList.add(threadWorkUnit);
				}
			}
		}

		// Return the list to framework
		return createJobWorkForThreadWorkUnitList(arrayList);
	}

	/**
	 * This method retrieves all the soft Parameters of the batch
	 */
	private void retrieveBatchParameters() {

		filePath = getParameters().getFILE_PATH();
		fileName = getParameters().getFILE_NAME();
	}

	/**
	 * This method validates all the soft Parameters of the batch
	 */
	public void validateBatchParameters() {

		/*
		 * Validate batch parameter filePath is not null and valid File Path
		 * directory. If filePath directory does not exists, then raise error
		 */
		File path = new File(filePath);
		if (!path.exists() || !path.isDirectory()) {
			
			 addError(CustomMessageRepositoryMGE.filePathIsNotValid(
			 filePath));
		}
	}

	public Class<CmCustomerContactUploadBatchWorker> getThreadWorkerClass() {
		return CmCustomerContactUploadBatchWorker.class;
	}

	public static class CmCustomerContactUploadBatchWorker extends
			CmCustomerContactUploadBatchWorker_Gen {

		private String stringFileName;
		private String stringFilePath;
		private File inputFileName;
		private BufferedReader fileReader;
		private Map<Integer, CharacteristicType> characteristicTypeMap;
		private Map<Integer, String> characteristicValueMap;
		List<CharacteristicType> requiredCharacteriscts;
		private boolean recordInError = false;
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			// TODO Auto-generated method stub
			return new SingleTransactionStrategy(this);
		}

		
		@Override
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			stringFileName = (String) unit.getSupplementallData(FILE_NAME);
			stringFilePath = (String) unit.getSupplementallData(FILE_PATH);
			inputFileName = new File(stringFilePath);

			try {
				// Open upload file
				openFile(inputFileName);
			} catch (Exception e) {
				addError(CustomMessageRepositoryMGE.errorOpeningFile(stringFilePath));
			}

			int rowCount = 1;
			String line = null;
			String personIdStr = null;
			Person_Id personId = null;
			String customerContactClassCodeStr = null;
			CustomerContactClass_Id customerContactClassId = null;
			String customerContactTypeCodeStr = null;
			CustomerContactType_Id customerContactTypeId = null;
			String comments = null;
			CustomerContact_DTO customerContactDTO = null;
			CustomerContact customerContact = null;
			int recordsProcessed = 0;
			int recordsInError = 0;
			
			try {
				line = fileReader.readLine();
				while ((line = fileReader.readLine()) != null) {
					recordInError = false;
					rowCount++;
					String[] lineContents = line.split(",");

					personIdStr = lineContents[0];
					personId = new Person_Id(personIdStr);
					if (isNull(personId) || isNull(personId.getEntity())) {
						addWarning(CustomMessageRepositoryMGE.personIdIsNotValid(
								rowCount, personIdStr));
						recordsInError++;
						recordsProcessed++;
						continue;
					}

					customerContactClassCodeStr = lineContents[1];
					customerContactClassId = new CustomerContactClass_Id(
							customerContactClassCodeStr);
					if (isNull(customerContactClassId)
							|| isNull(customerContactClassId.getEntity())) {
						addWarning(CustomMessageRepositoryMGE
								.customerContactClassIsNotValid(rowCount,
										customerContactClassCodeStr));
						recordsInError++;
						recordsProcessed++;
						continue;
					}

					customerContactTypeCodeStr = lineContents[2];
					customerContactTypeId = new CustomerContactType_Id(
							customerContactClassId, customerContactTypeCodeStr);
					if (isNull(customerContactTypeId)
							|| isNull(customerContactTypeId.getEntity())) {
						addWarning(CustomMessageRepositoryMGE
								.customerContactTypeIsNotValid(rowCount,
										customerContactTypeCodeStr));
						recordsInError++;
						recordsProcessed++;
						continue;
					}
					requiredCharacteriscts = getRequiredCharacteristics(customerContactTypeId.getEntity());
					validateRequiredCharacteristic(lineContents, rowCount);
					if(recordInError){
						recordsInError++;
						recordsProcessed++;
						continue;
					}
					
					comments = lineContents[3];

					customerContactDTO = createDTO(CustomerContact.class);
					customerContactDTO
							.setCustomerContactTypeId(customerContactTypeId);
					customerContactDTO.setPersonId(personId);
					customerContactDTO.setLongDescription(comments);
					customerContactDTO.setContactDateTime(getProcessDateTime());
					customerContact = customerContactDTO.newEntity();
					createCustomerContactCharacteristics(customerContact);
					recordsProcessed++;
				}
			} catch (IOException io) {

				addError(CustomMessageRepositoryMGE
						.errorReadingFile(stringFileName));
			} catch (Exception e) {
				e.printStackTrace();
			}

			closeFile(inputFileName);
			
			WorkUnitResult result = new WorkUnitResult(true);
            result.setUnitsProcessed(recordsProcessed);
            result.setUnitsInError(recordsInError);
            
			return result;
		}

		private void createCustomerContactCharacteristics(CustomerContact customerContact) {

			CharacteristicType charType = null;
			String charVal = null;
			for (Iterator<Integer> iterator = characteristicTypeMap.keySet().iterator(); iterator.hasNext();) {
				Integer sequence =  iterator.next();
				charType = characteristicTypeMap.get(sequence);
				charVal = characteristicValueMap.get(sequence);
				
				CustomerContactCharacteristic_DTO charDto = customerContact
						.getCharacteristics().newChildDTO();
				CharacteristicTypeLookup charTypeLookup = charType
						.getCharacteristicType();
				if (charTypeLookup.isAdhocValue()
						|| charTypeLookup.isFileLocationValue()) {
					charDto.setAdhocCharacteristicValue(charVal);
				} else if (charTypeLookup.isPredefinedValue()) {
					charDto.setCharacteristicValue(charVal);
				} else if (charTypeLookup.isForeignKeyValue()) {
					charDto.setCharacteristicValueForeignKey1(charVal);
				}
				customerContact.getCharacteristics().add(charDto, charType.getId());
			}
		}

		/**
		 * This method validates the characteristic type. Returns the
		 * CharacteristicType_Id if validation successful.
		 */
		private CharacteristicType_Id validateAndRetrieveCharType(
				String charTypeStr, int rowCount) {

			CharacteristicType_Id charType = new CharacteristicType_Id(
					charTypeStr);
			if (isNull(charType.getEntity())) {
				addWarning(CustomMessageRepositoryMGE.charTypeIsNotValid(
						rowCount, charTypeStr));
			}

			CharacteristicEntity_Id characteristicId = new CharacteristicEntity_Id(
					charType,
					CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);
			// Validate if the Characteristic Entity is not null, else raise
			// error
			if (isNull(characteristicId.getEntity())) {
				addWarning(CustomMessageRepositoryMGE.invalidCharTypeForEntity(
						rowCount, charTypeStr,
						CharacteristicEntityLookup.constants.CUSTOMER_CONTACT
								.value()));
			}
			return charType;
		}

		/**
		 * This method opens file for processing
		 * 
		 * @param uploadFile
		 *            - uploadFile
		 * @throws IOException
		 *             - IOException
		 * @throws Exception
		 *             - Exception
		 */
		private void openFile(File uploadFile) throws IOException, Exception {

			try {
				fileReader = new BufferedReader(new FileReader(uploadFile));
			} catch (IOException ioe) {
				 addError(CustomMessageRepositoryMGE.errorOpeningFile(uploadFile.getName()));
			} catch (Exception e) {
				 addError(CustomMessageRepositoryMGE.errorOpeningFile(uploadFile.getName()));
			}

		}

		/**
		 * This method closes the upload file
		 * 
		 * @param closingFileName
		 *            - closingFileName
		 */
		private void closeFile(File closingFileName) {

			try {
				fileReader.close();
			} catch (IOException ioe) {
				 addError(CustomMessageRepositoryMGE.errorClosingFile(closingFileName.getName()));

			} catch (Exception e) {
				 addError(CustomMessageRepositoryMGE.errorClosingFile(closingFileName.getName()));

			}

		}
		
		private List<CharacteristicType> getRequiredCharacteristics(
				CustomerContactType customerContactType) {

			List<CharacteristicType> requiredCharacteristics = new ArrayList<CharacteristicType>();
			ListFilter<CharacteristicTypeContactType> charTypeFilter = customerContactType
					.getCharacteristicTypeContactTypes()
					.createFilter(
							" WHERE this.id.customerContactType = :customerContactType AND this.isRequired = :isRequired",
							getClass().getName());
			charTypeFilter.bindEntity("customerContactType", customerContactType);
			charTypeFilter.bindBoolean("isRequired", Bool.TRUE);
			
			CharacteristicTypeContactType characteristicTypeContactType = null;
			for (Iterator<CharacteristicTypeContactType> iterator = charTypeFilter.list().iterator(); iterator.hasNext();) {
				
				characteristicTypeContactType = iterator.next();
				requiredCharacteristics.add(characteristicTypeContactType.getId().getCharacteristicType());
			}
			
			return requiredCharacteristics;
		}
		
		private void validateRequiredCharacteristic(String[] lineContent, int rowCount){
			
			int charTypePosition = 4;
			int arraySize = lineContent.length;
			String characteristicTypeCodeStr = null;
			String characteristicValueStr =null;
			CharacteristicType_Id charTypeId =null;
			int sequence = 1;
			
			characteristicTypeMap = new HashMap<Integer,CharacteristicType>();
			characteristicValueMap = new HashMap<Integer,String>();
			while (arraySize > charTypePosition) {
				
				characteristicTypeCodeStr = lineContent[charTypePosition++];
				if (!isEmptyOrNull(characteristicTypeCodeStr)) {
					charTypeId = validateAndRetrieveCharType(
							characteristicTypeCodeStr, rowCount);
					characteristicValueStr = lineContent[charTypePosition++];
					if (isEmptyOrNull(characteristicValueStr)) {
						
						recordInError = true;
						addWarning(CustomMessageRepositoryMGE
								.charValueNotProvided(rowCount,
										characteristicTypeCodeStr));
						return;
					}
					
					if (charTypeId.getEntity().getCharacteristicType().isPredefinedValue()) {
						
			            CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charTypeId,
			            		characteristicValueStr);
			            if (isNull(charValueId.getEntity())) {
			            	
			            	recordInError = true;
			            	addWarning(CustomMessageRepositoryMGE.invalidCharValue(characteristicValueStr,
			                		charTypeId.getTrimmedValue()));
			            	return;
			            }
			        }
					characteristicTypeMap.put(Integer.valueOf(sequence), charTypeId.getEntity());
					characteristicValueMap.put(Integer.valueOf(sequence), characteristicValueStr);
					requiredCharacteriscts.remove(charTypeId.getEntity());
					sequence++;
				}
			}
			if(!requiredCharacteriscts.isEmpty()){
				recordInError = true;
				addWarning(CustomMessageRepositoryMGE.requiredCharMissing(rowCount));
			}
		}
	}

}
