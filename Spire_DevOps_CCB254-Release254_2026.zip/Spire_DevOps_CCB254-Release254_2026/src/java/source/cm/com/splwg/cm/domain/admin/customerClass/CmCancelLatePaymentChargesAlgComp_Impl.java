/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Algorithm for Automatic Cancellation of LPCs
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-01-24   RDizon  NA0077. Initial Version.
 * 2016-01-25   MPang	Updated for CCB v2.4 compilation.
 **************************************************************************/

package com.splwg.cm.domain.admin.customerClass;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.AdjustmentStatusLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.adjustment.adjustment.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.AdjustmentCharacteristic;
import com.splwg.ccb.domain.adjustment.adjustment.Adjustment_Id;
import com.splwg.ccb.domain.admin.adjustmentCancelReason.AdjustmentCancelReason;
import com.splwg.ccb.domain.admin.customerClass.CustomerClassFtFreezeAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.Bill;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;
import com.splwg.ccb.domain.financial.financialTransaction.FinancialTransaction;*/

import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.admin.adjustmentCancelReason.entity.AdjustmentCancelReason;
import  com.splwg.ccb.domain.admin.customerClass.algorithm.ftFreeze.CustomerClassFtFreezeAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
//End Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author REDIZON
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = adjustmentTypeCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = adjustmentTypeCharacteristicValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = adjustmentCancelReason, name = cancelReasonCode, required = true, type = entity)})
 */

public class CmCancelLatePaymentChargesAlgComp_Impl 
		extends CmCancelLatePaymentChargesAlgComp_Gen 
		implements CustomerClassFtFreezeAlgorithmSpot {

	// Soft Parameters
	private CharacteristicType adjustmentTypeCharType;
	private String adjustmentTypeCharValue;
	private AdjustmentCancelReason adjustmentCancelReason;

	// Hard Parameters
	private FinancialTransaction ft;
	private FinancialTransactionTypeLookup ftTypeLookup;
	private FinancialTransaction originalFt;

	// Properties
	Money saBalance;
	Money latePaymentAmount;
	Bool closingSwitch;
	BigDecimal billFactorValue;


	public Bool getFinancialTransactionProcessAdded() {

		return null;
	}

	public void setFinancialTransaction(FinancialTransaction ft) {
		this.ft = ft;
	}

	public void setFinancialTransactionType(FinancialTransactionTypeLookup ftTypeLookup) {
		this.ftTypeLookup = ftTypeLookup;
	}

	public void setRegularFinancialTransaction(FinancialTransaction regularFt) {
		this.originalFt = regularFt;
	}

	public void invoke() {
		if (ftTypeLookup.isBillCancellation()){
			Bill currentBill = originalFt.fetchBill();
			if (notNull(currentBill)){
				Date startDate = currentBill.getDueDate();
				Date endDate = (Date) cmGetNextBillDueDate(currentBill.getAccount().getId(), startDate).firstRow();
				if (isNull(endDate)){
					endDate = getProcessDateTime().getDate();				
				}

				QueryIterator itrLpcAdjustments = cmGetLpcAdjustments(ft.getServiceAgreement().getId(), startDate, endDate).iterate();
				while (itrLpcAdjustments.hasNext()){
					Adjustment_Id lpcAdjustmentId = (Adjustment_Id) itrLpcAdjustments.next();
					Adjustment lpcAdjustment = lpcAdjustmentId.getEntity();
					lpcAdjustment.cancel(adjustmentCancelReason);
				}
			}
		}
	}

	@Override
	protected void extraSoftParameterValidations(boolean arg0) {
		// Retrieve the soft parameters
		adjustmentTypeCharType = this.getAdjustmentTypeCharacteristicType();
		adjustmentTypeCharValue = this.getAdjustmentTypeCharacteristicValue();
		adjustmentCancelReason = this.getCancelReasonCode();

		// Check if input Adjustment Type Characteristic Type is a Pre-Defined value
		if (!adjustmentTypeCharType.getCharacteristicType().isPredefinedValue()){
			addError(CustomMessageRepositoryMDC.na0077_AdjustmentTypeCharTypeIsNotPreDefined(adjustmentTypeCharType.getId().getTrimmedValue()));
		}

		// Check if input Adjustment Type Characteristic Value is a valid Characteristic Value for the Adjustment Type Characteristic Type
		if(notBlank(adjustmentTypeCharValue.trim()) &&  adjustmentTypeCharValue.length() > 0){
			CharacteristicValue_Id charValueId = new CharacteristicValue_Id(adjustmentTypeCharType, adjustmentTypeCharValue.trim());
			if(isNull(charValueId.getEntity())){
				addError(CustomMessageRepositoryMDC.na0077_InvalidCharValueForAdjustmentTypeCharType(adjustmentTypeCharValue, adjustmentTypeCharType.getId().getTrimmedValue()));
			}
		}
	}

	/**
	 * Get the Due Date of the Next Bill
	 * @param accountId Account ID
	 * @param startDate Start Date
	 * @return query Query
	 */
	private Query cmGetNextBillDueDate(Account_Id accountId, Date startDate) {
		Query query = createQuery("FROM Bill NB "
				+ "WHERE NB.account = :accountId "
				//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
				//+ "AND NB.dueDate > :currentBillDueDate");
				+ "AND NB.dueDate > :currentBillDueDate" , getClass().getName());
		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
		query.bindId("accountId", accountId);
		query.bindDate("currentBillDueDate", startDate);
		query.addResult("nextBillDueDate", "NB.dueDate");
		query.orderBy("nextBillDueDate", Query.ASCENDING);

		return query;
	}

	/**
	 * Get the 
	 * @param accountId Account ID
	 * @param startDate Start Date
	 * @return query Query
	 */
	private Query cmGetLpcAdjustments(ServiceAgreement_Id saId, Date startDate, Date endDate) {
		Query query = createQuery("FROM Adjustment ADJ, AdjustmentTypeCharacteristic ATC "
				+ "WHERE ADJ.serviceAgreement = :saId "
				+ "AND ADJ.adjustmentStatus = :frozenStatus "
				+ "AND ADJ.creDt >= :startDate "
				+ "AND ADJ.creDt <= :endDate "
				+ "AND ADJ.adjustmentType = ATC.id.adjustmentType "
				+ "AND ATC.id.characteristicType = :charTypeCode "
				//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
				// + "AND ATC.characteristicValue = :charValue");
				+ "AND ATC.characteristicValue = :charValue", getClass().getName());
				//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
		query.bindId("saId", saId);
		query.bindLookup("frozenStatus", AdjustmentStatusLookup.constants.FROZEN);
		query.bindDate("startDate", startDate);
		query.bindDate("endDate", endDate);
		query.bindEntity("charTypeCode", adjustmentTypeCharType);
		query.bindStringProperty("charValue", AdjustmentCharacteristic.properties.characteristicValue, adjustmentTypeCharValue);
		query.addResult("adjId", "ADJ.id");

		return query;
	}
}
