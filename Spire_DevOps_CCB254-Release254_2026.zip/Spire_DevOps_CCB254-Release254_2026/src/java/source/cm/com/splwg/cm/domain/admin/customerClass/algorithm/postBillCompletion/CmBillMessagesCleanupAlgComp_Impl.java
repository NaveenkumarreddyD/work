 /*************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * CCB043 - Post-Bill Completion Bill Message Cleanup
 *
 * This algorithm will delete bill messages that are not considered valid 
 * for the Account's CIS Division
 *
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2021-04-14   DLampa     CCB043.2. Initial version. 
 *************************************************************************/

package com.splwg.cm.domain.admin.customerClass.algorithm.postBillCompletion;

import java.util.Iterator;

import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.customerClass.algorithm.postBillCompletion.CustomerClassPostBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage;
import com.splwg.ccb.domain.billing.bill.entity.BillMessages;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author DLampa
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = serviceTaskType, name = cisDivisionBillMessageConfigSvcTaskType, required = true, type = entity)})
 */
public class CmBillMessagesCleanupAlgComp_Impl
    extends CmBillMessagesCleanupAlgComp_Gen
    implements CustomerClassPostBillCompletionAlgorithmSpot {
    
    // Hard Parameters
    private Bill bill;
    
    // Soft Parameters
    private ServiceTaskType cisDivisionBillMessageConfigSvcTaskType;
    
    // Work Variables
    private String[] billMessagePrefix;
    private COTSInstanceList exemptionsList;

    // Constants
    private static final String CISDIV_BMSG_CFG_BO = "CM-CisDivBillMsgConfig";
    private static final String SERVICE_TASK_TYPE = "serviceTaskType";
    private static final String CISDIV_BMSG_DETAILS_GROUP = "cisDivBillMessageDetails";
    private static final String CISDIV_BMSG_LIST = "cisDivBillMessageList";
    private static final String CIS_DIVISION = "cisDivision";
    private static final String BILL_MSG_PREFIX = "billMessagePrefix";
    private static final String EXEMPTIONS_LIST = "exemptionsList";
    private static final String BILL_MSG = "billMessage";
    private static final String COMMA = ",";

    // Debug logger
    private Logger logger = LoggerFactory.getLogger(getClass());     
    
    @Override
    public void setBill(Bill bill) {
        this.bill = bill;
    }

    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        
        cisDivisionBillMessageConfigSvcTaskType = getCisDivisionBillMessageConfigSvcTaskType();
        
    }

    @Override
    public void invoke() {              
        
        determineValidBillMessages();
        
        BillMessages billMsgs = bill.getMessages();
        Bool isMatchFound = Bool.FALSE;
        Iterator<BillMessage> billMsgsIter = billMsgs.iterator();
        
        // Loop though the existing bill messages and check each one against the valid prefixes and the exemptions list.
        // Delete messages where a match cannot be found in the valid prefixes or the exemptions list.
        while (billMsgsIter.hasNext()) {
            isMatchFound = Bool.FALSE;
            BillMessage currBillMsg = billMsgsIter.next();          
            
            // Loop through the prefixes to check if the first character of the bill message matches any of those
            // that are valid for the CIS Division.
            for (int i=0; i < billMessagePrefix.length; i++) {
                if (Character.toString(currBillMsg.fetchIdBillMessage().getId().getIdValue().charAt(0)).equals(billMessagePrefix[i])) {
                    isMatchFound = Bool.TRUE;
                    break;
                }
            }
            
            // If the first character of the bill message did not match any of the valid prefixes, check if the actual message
            // is included in the list exempted from deletion.
            if (isMatchFound.isFalse() && !exemptionsList.isEmpty()) {
                Iterator<COTSInstanceListNode> exemptionsListIter = exemptionsList.iterator();
                COTSInstanceListNode cotsInstanceListNode;
                
                while (exemptionsListIter.hasNext()){
                    cotsInstanceListNode = exemptionsListIter.next();
                    String billMessageStr = cotsInstanceListNode.getString(BILL_MSG);
                    
                    if(currBillMsg.fetchIdBillMessage().getId().getIdValue().equalsIgnoreCase(billMessageStr.trim())) {
                        isMatchFound = Bool.TRUE;
                        break;
                    }
                }
            }

            // Delete the message if a match is not found
            if (isMatchFound.isFalse()) {
                deleteBillMessage(currBillMsg.fetchIdBillMessage());
            }
        }

    }

    private void determineValidBillMessages() {

        // Read the CIS Division/Bill Message Configurations Service Task Type
        BusinessObjectInstance boInstance = BusinessObjectInstance.create(CISDIV_BMSG_CFG_BO);
        boInstance.set(SERVICE_TASK_TYPE, cisDivisionBillMessageConfigSvcTaskType.getId().getTrimmedValue());
        boInstance = BusinessObjectDispatcher.read(boInstance);

        // Loop through the list to determine the valid message prefixes and specific bill message codes for the account's CIS Division
        COTSInstanceNode cisDivBillMsgDetails = boInstance.getGroup(CISDIV_BMSG_DETAILS_GROUP);
        COTSInstanceList cisDivBillMsgList = cisDivBillMsgDetails.getList(CISDIV_BMSG_LIST);

        Iterator<COTSInstanceListNode> cisDivBillMsgListIter = cisDivBillMsgList.iterator();
        String cisDivision = "";
        COTSInstanceListNode cotsInstanceListNode = null;

        while (cisDivBillMsgListIter.hasNext()){
            cotsInstanceListNode = cisDivBillMsgListIter.next();
            cisDivision = cotsInstanceListNode.getString(CIS_DIVISION);

            if (cisDivision.trim().equals(bill.getAccount().getDivisionId().getTrimmedValue())) {
                billMessagePrefix = cotsInstanceListNode.getString(BILL_MSG_PREFIX).split(COMMA);
                exemptionsList = cotsInstanceListNode.getList(EXEMPTIONS_LIST);
                

                break;
            }
        }

    }
    
    private void deleteBillMessage(BillMessageType billMessage) {

        StringBuilder stringBuilder = new StringBuilder();              
        stringBuilder.append("DELETE FROM CI_BILL_MSGS ");
        stringBuilder.append("WHERE BILL_ID = :bill ");
        stringBuilder.append("  AND BILL_MSG_CD = :billMsgCd ");

        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        prepState.bindId("bill", bill.getId());
        prepState.bindId("billMsgCd", billMessage.getId());
        prepState.execute();
        prepState.close();

    }

}
