/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Meter Sample Case Transition Algorithm
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-04-08   Jagadeesh		NM0101 Initial Version.
 * 2013-07-19   Neha            CR- Remove Meter Location parameter and logic
 * 2014-07-03	Rahul			IM-053271	Changed a query condition
 * 2014-08-11	Rahul			IM-055861	Add logic to close a case if meter on case has been removed
 * 2014-09-23   Ujesh           IM-055858   Autoclose not working even if the char val is N
 * 2016-01-25   MPang	        Updated for CCB v2.4 compilation.
 * 2020-03-20   dhuynh	        SA320049 modify logic if meter on case has been removed.
 ******************************************************************************************/
package com.splwg.cm.domain.admin.caseType;

import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.CaseLogTypeLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.TransitionConditionLookup;

//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.algorithm.autoTransition.AutoTransitionAlgorithmSpot;
import com.splwg.ccb.domain.admin.meterLocation.entity.MeterLocation_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;

//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author jgali001
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = caseSPCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = caseMeterCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = tranCondClose, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = meterSampleCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = meterSampleCharVal, type = string, required = true)})
 */
public class CmMeterSampleCaseTran_AlgComp_Impl extends CmMeterSampleCaseTran_AlgComp_Gen
	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
	//implements CaseTypeAutoTransitionAlgorithmSpot {
	implements AutoTransitionAlgorithmSpot {
	//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation

	private CharacteristicType parmCaseSPCharType;
    private CharacteristicType parmCaseMeterCharType ;
    private CharacteristicType parmMeterSampleCharType ;
    private TransitionConditionLookup parmTranCondClose ;
    // Start CR changes - Neha - 22-Jul-13
    //private MeterLocation_Id parmMeterLocationIdOut;
    // End CR changes - Neha - 22-Jul-13
    private ToDoCase inpCase;
    private String parmMeterSampleCharVal;
    private String tranCond;
    private Bool shouldAutoTransition = Bool.FALSE;
    private ServicePoint_Id spId;


    protected void extraSoftParameterValidations(boolean arg0) {
        parmCaseSPCharType = getCaseSPCharType();
        CharacteristicEntity charEntity = new CharacteristicEntity_Id(parmCaseSPCharType, CharacteristicEntityLookup.constants.CASE).getEntity();
        if(isNull(charEntity)){
            addError(CustomMessageRepository.nm0101InvalidCharEntity(parmCaseSPCharType.getId().getIdValue()));
        }

        parmCaseMeterCharType = getCaseMeterCharType();
        charEntity = new CharacteristicEntity_Id(parmCaseMeterCharType, CharacteristicEntityLookup.constants.CASE).getEntity();
        if(isNull(charEntity)){
            addError(CustomMessageRepository.nm0101InvalidCharEntity(parmCaseMeterCharType.getId().getIdValue()));
        }

        parmMeterSampleCharType = getMeterSampleCharType();
        charEntity = new CharacteristicEntity_Id(parmMeterSampleCharType, CharacteristicEntityLookup.constants.METER).getEntity();
        if(isNull(charEntity)){
            addError(CustomMessageRepository.nm0101InvalidCharEntity(parmMeterSampleCharType.getId().getIdValue()));
        }

        parmMeterSampleCharVal = getMeterSampleCharVal();
        CharacteristicValue_Id cvl = new CharacteristicValue_Id(parmMeterSampleCharType,parmMeterSampleCharVal);
        if(isNull(cvl.getEntity()))
        {
            addError(CustomMessageRepository.nm0101InvalidCharVal(parmMeterSampleCharType.getId().getIdValue(),parmMeterSampleCharVal));
        }
    }

    public void invoke() {

        List<CaseCharacteristic> caseSPCharList = inpCase.getSortedCharacteristicsOfType(parmCaseSPCharType);
        if(caseSPCharList.isEmpty()){
            addError(CustomMessageRepository.nm0101NoSPChar(inpCase.getId().getIdValue()));
        }

        parmTranCondClose = getTranCondClose();
        spId =  new ServicePoint_Id(caseSPCharList.iterator().next().getCharacteristicValueForeignKey1());
        ServicePoint sp = spId.getEntity();

        // Start CR changes - Neha - 22-Jul-13
        /*parmMeterLocationIdOut = getMeterLocationOut().getId();
        if(notNull(sp.getMeterLocationId()) && sp.getMeterLocationId().equals(parmMeterLocationIdOut)){
            tranCond = parmTranCondClose.value();
            shouldAutoTransition = Bool.TRUE;
            return;
        }*/
        // End CR changes - Neha - 22-Jul-13
		// Start 	Add 	Rahul 	11-Aug-14 	IM-055861
		checkMeterNotExists();
		// End 	 	Add 	Rahul 	11-Aug-14 	IM-055861
        checkTransition();


    }
	// Start 	Add 	Rahul 	11-Aug-14 	IM-055861
	private void checkMeterNotExists(){
		StringBuilder checkMeterExistsString = new StringBuilder();
		checkMeterExistsString.append(" SELECT '1' ");
		checkMeterExistsString.append(" FROM CI_CASE CASE, CI_CASE_CHAR CASECHAR, CI_MTR_CONFIG METERCONFIG, CI_SP_MTR_HIST SPMETERHIST ");
		checkMeterExistsString.append(" WHERE CASE.CASE_ID = :inpCaseId ");
		checkMeterExistsString.append(" AND CASE.CASE_ID = CASECHAR.CASE_ID ");
		checkMeterExistsString.append(" AND CASECHAR.CHAR_TYPE_CD = :caseMtr ");
		checkMeterExistsString.append(" AND TRIM(CASECHAR.CHAR_VAL_FK1) = METERCONFIG.MTR_ID ");
		checkMeterExistsString.append(" AND METERCONFIG.MTR_CONFIG_ID = SPMETERHIST.MTR_CONFIG_ID ");
		checkMeterExistsString.append(" AND SPMETERHIST.SP_ID = :caseSP ");
		//Start Change 2020-03-20 dhuynh sa-320049-check for meter is still there
		//checkMeterExistsString.append(" AND SPMETERHIST.REMOVAL_DTTM IS NOT NULL ");
		checkMeterExistsString.append(" AND (SPMETERHIST.REMOVAL_DTTM IS NULL OR SPMETERHIST.REMOVAL_DTTM > :procDate)");
		//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement checkMeterExistsStmt = createPreparedStatement(checkMeterExistsString.toString());
		PreparedStatement checkMeterExistsStmt = createPreparedStatement(checkMeterExistsString.toString(), getClass().getName());
		//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
		checkMeterExistsStmt.bindId("inpCaseId", inpCase.getId());
		checkMeterExistsStmt.bindId("caseMtr", parmCaseMeterCharType.getId());
		checkMeterExistsStmt.bindId("caseSP", spId);
		checkMeterExistsStmt.bindDate("procDate", getProcessDateTime().getDate());
		//if (notNull(checkMeterExistsStmt.firstRow())){
        if (isNull(checkMeterExistsStmt.firstRow())){
            tranCond = parmTranCondClose.value();
            shouldAutoTransition = Bool.TRUE;
        }
		//end Change 2020-03-20 dhuynh sa-320049-check for meter is still there
        checkMeterExistsStmt.close();
	}
	// End 	 	Add 	Rahul 	11-Aug-14	IM-055861

    private void checkTransition(){

        StringBuilder getCheckTransitionString = new StringBuilder();
        getCheckTransitionString.append(" SELECT '1' FROM CI_CASE C, CI_CASE_CHAR CCMT, CI_CASE_LOG CL, CI_MTR_CONFIG MC, CI_SP_MTR_HIST SMH, CI_MTR_CHAR MH ");
        getCheckTransitionString.append(" WHERE C.CASE_ID = :inpCaseId AND C.CASE_ID = CL.CASE_ID AND CL.CASE_LOG_TYPE_FLG = :caseCreatedFlag  ");
        getCheckTransitionString.append(" AND C.CASE_ID = CCMT.CASE_ID AND CCMT.CHAR_TYPE_CD = :caseMtr AND TRIM(CCMT.CHAR_VAL_FK1) = MC.MTR_ID ");
		// Start 2014-07-03	Rahul			IM-053271
        //getCheckTransitionString.append(" AND MC.MTR_CONFIG_ID = SMH.MTR_CONFIG_ID AND SMH.SP_ID = :caseSP AND SMH.REMOVAL_DTTM > CL.LOG_DTTM ");
		getCheckTransitionString.append(" AND MC.MTR_CONFIG_ID = SMH.MTR_CONFIG_ID AND SMH.SP_ID = :caseSP AND ((SMH.REMOVAL_DTTM IS NULL) OR (SMH.REMOVAL_DTTM > CL.LOG_DTTM)) ");
		// End 2014-07-03	Rahul			IM-053271
		// Start Change - IM-055858 - Ujesh - 2014-09-25
        //getCheckTransitionString.append(" AND MC.MTR_ID = MH.MTR_ID AND MH.CHAR_TYPE_CD = :meterSampleType AND TRIM(MH.CHAR_VAL) = :meterSampleVal " );
		getCheckTransitionString.append(" AND MC.MTR_ID = MH.MTR_ID AND MH.CHAR_TYPE_CD = :meterSampleType AND MH.CHAR_VAL = :meterSampleVal " );
        //End Change - IM-055858   - Ujesh - 2014-09-25
        getCheckTransitionString.append(" AND MH.EFFDT = (SELECT MAX(MH1.EFFDT) FROM CI_MTR_CHAR MH1 " );
        getCheckTransitionString.append(" WHERE MH1.CHAR_TYPE_CD = :meterSampleType AND MH1.MTR_ID = MH.MTR_ID AND MH1.EFFDT <= :procDate)");
        //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement getCheckTransitionStmt = createPreparedStatement(getCheckTransitionString.toString());
        PreparedStatement getCheckTransitionStmt = createPreparedStatement(getCheckTransitionString.toString(), getClass().getName());
        //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        getCheckTransitionStmt.bindId("inpCaseId", inpCase.getId());
        getCheckTransitionStmt.bindLookup("caseCreatedFlag", CaseLogTypeLookup.constants.CREATED);
        getCheckTransitionStmt.bindId("caseMtr", parmCaseMeterCharType.getId());
        getCheckTransitionStmt.bindId("caseSP", spId);
        getCheckTransitionStmt.bindId("meterSampleType", parmMeterSampleCharType.getId());
        getCheckTransitionStmt.bindString("meterSampleVal",parmMeterSampleCharVal.trim() , "CHAR_VAL");
        getCheckTransitionStmt.bindDate("procDate", getProcessDateTime().getDate());
        if (notNull(getCheckTransitionStmt.firstRow())){
            tranCond = parmTranCondClose.value();
            shouldAutoTransition = Bool.TRUE;
        }
        getCheckTransitionStmt.close();
    }


    public CaseStatus getNextCaseStatus() {
        // TODO Auto-generated method stub
        return null;
    }


    public String getNextTransCondition() {
        // TODO Auto-generated method stub
        return tranCond;
    }


    public Bool getShouldAutoTransition() {
        return shouldAutoTransition;
    }


    public void setCase(ToDoCase arg0) {
        inpCase = arg0;
    }

}
