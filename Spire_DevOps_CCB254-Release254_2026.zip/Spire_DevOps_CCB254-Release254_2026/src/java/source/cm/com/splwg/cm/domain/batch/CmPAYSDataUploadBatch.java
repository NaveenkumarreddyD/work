/*
 ***********************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * CCB030.2 - PAYS Enrollment
 * 
 * This batch process reads records from a CSV file, for each record it will create an NUS record
 * of the specified type on the batch parameters, if the TO Do type is configured will create a record
 * for every Notification Upload record, also it will mark the record as complete
 *
 ***********************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2021-03-30   CAtilano         CCB030.2. Initial Version.
  ***********************************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.lookup.NotificationUploadExtensionLookup;
import com.splwg.base.api.lookup.NotificationUploadStatusLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoCharacteristicData;
import com.splwg.base.domain.todo.toDoEntry.ToDoCharacteristicData_Impl;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.base.domain.workflow.notificationExternalId.NotificationExternalId;
import com.splwg.base.domain.workflow.notificationExternalId.NotificationExternalId_Id;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadContext_DTO;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadContext_Id;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload_DTO;
import com.splwg.base.domain.workflow.notificationUploadExtensionType.NotificationUploadExtensionType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.workflow.workFlowProcess.entity.RecordCICWPCTCFragment.ProcCtxtColl;
import com.splwg.cm.api.lookup.NotificationUploadContextLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

/**
 * @author OGC04023
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = notificationUploadExtensionType, name = NT_UP_XTYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = TD_TYPE_CD, type = entity, required = false)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = DIV_CHAR_TYPE, type = entity, required = true)})
 */
public class CmPAYSDataUploadBatch extends CmPAYSDataUploadBatch_Gen {

	public JobWork getJobWork() {
        ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        arrayList.add(threadWorkUnit);

        return createJobWorkForThreadWorkUnitList(arrayList);
	}

	public Class<CmPAYSDataUploadBatchWorker> getThreadWorkerClass() {
		return CmPAYSDataUploadBatchWorker.class;
	}

	public static class CmPAYSDataUploadBatchWorker extends
			CmPAYSDataUploadBatchWorker_Gen {
		
		//CONSTANTS
		public static final int NUM_FIELDS = 12;
		public static final String NT_UP_CTXT_FLG_ACCT = "ACCT";	
		public static final String NT_UP_CTXT_FLG_PREM = "PREM";
		public static final String NT_UP_CTXT_FLG_FNM = "FNM";
		public static final String NT_UP_CTXT_FLG_LNM = "LNM";
		public static final String NT_UP_CTXT_FLG_PNUM = "ACCT";
		public static final String NT_UP_CTXT_FLG_PREF = "ACCT";
		public static final String NT_UP_CTXT_FLG_PDT = "PDT";
		public static final String NT_UP_CTXT_FLG_PCST = "PCST";
		public static final String NT_UP_CTXT_FLG_PAMT = "PAMT";
		public static final String NT_UP_CTXT_FLG_PMOS = "PMOS";
		public static final String NT_UP_CTXT_FLG_PST = "PST";
		public static final String NT_UP_CTXT_FLG_PINT = "PINT";
		public static final String EXTERNAL_SYS = "AEG";
		
		
		public String filePath = null;
		public String fileName = null;
		public String fileNamePath = null;
		public File uploadFile;
		public CharacteristicType divisionCharType = null;
		public ToDoType tdType = null;
		public NotificationUploadExtensionType ntUpType;
		private ServerMessage serverMessage = null;
		private Integer totalItems = 0;
		private Integer recordsError = 0;
		private NotificationExternalId_Id extId; 

		public BufferedReader uploadFileReader;
		
        @Override
		public void finalizeJobWork() throws Exception {
			
			super.finalizeJobWork();
		}
        
		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
			
			fileName = getParameters().getFILE_NAME();
			filePath = getParameters().getFILE_PATH();
			divisionCharType = getParameters().getDIV_CHAR_TYPE();
			tdType = getParameters().getTD_TYPE_CD();
			ntUpType = getParameters().getNT_UP_XTYPE_CD();
			extId = new NotificationExternalId_Id(EXTERNAL_SYS);
				
		}

		public ThreadExecutionStrategy createExecutionStrategy() {
			
			return new SingleTransactionStrategy(this);
		}

		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			WorkUnitResult results = new WorkUnitResult(true);
			
			openFile();
			processRecords();
			closeFile();
			
			// TODO update these counts appropriately
			results.setUnitsInError(recordsError);
			results.setUnitsProcessed(totalItems);
			return results;
		}
		
		 private void openFile() {
             try {
                 uploadFile = new File(filePath,fileName);   
                 uploadFileReader = new BufferedReader(new FileReader(uploadFile)); 
                 fileNamePath = uploadFile.getAbsolutePath();
             } catch(Exception e) {
                 e.printStackTrace();
                 throw new RunAbortedException(CustomMessageRepositorySpireOne.ccb030_2_errorOpeningFile(e.getLocalizedMessage()));
             }
         }
		 
         private void closeFile() {
             try {
                 if(notNull(uploadFileReader)){
                     uploadFileReader.close();                    
                 }
             } catch (IOException exception) {
                 throw new RunAbortedException(CustomMessageRepositorySpireOne.ccb030_2_errorClosingFile(fileNamePath));
             }
         }
         private void processRecords(){
        	 String record;
        	 while(!isNull(record = readRecord())){
        		 totalItems = totalItems + 1;
        		 processLine(record);
   
        	 }
         }
         
         private String readRecord() {
 			String record = null;
 			try {
 				record =  uploadFileReader.readLine();                 
 			} catch (IOException exception) {
 				throw new RunAbortedException(CustomMessageRepositorySpireOne.ccb015_1ErrorInFile(exception.getMessage().trim()));  
 			}  
 			return record;
 		}
         /**
          * Create Notification Upload Staging record
          * @return returnValue
          */
         private NotificationUpload createNTUpload() {
             
             NotificationUpload returnValue = null;
             NotificationUpload_DTO ntUpDTO = createDTO(NotificationUpload.class);
             ntUpDTO.setCreationDateTime(this.getProcessDateTime());
             ntUpDTO.setNotificationExternalId(extId);
             ntUpDTO.setNotificationUploadTypeId(ntUpType.getId());
             if(isNull(tdType)){
            	 ntUpDTO.setNotificationStatus(NotificationUploadStatusLookup.constants.PENDING);
             }
             else {
            	 ntUpDTO.setNotificationStatus(NotificationUploadStatusLookup.constants.COMPLETE);
             }
             ntUpDTO.setNotificationUploadExtension(NotificationUploadExtensionLookup.constants.NO_EXTENSION);
             returnValue = ntUpDTO.newEntity();
             return returnValue;            
             
         }
         
         /**
          * Create Notification Upload Context Staging record
          * @return returnValue
          */
         private void createNTUploadContext(NotificationUpload ntUpload, NotificationUploadContextLookup notificationContextType, 
                 String contextValue) {
             
             if (notBlank(contextValue)) {
                 NotificationUploadContext_Id ntUpCtxtID = new NotificationUploadContext_Id(
                         ntUpload, notificationContextType, contextValue);
                 NotificationUploadContext_DTO ntUpCtxtDTO = new NotificationUploadContext_DTO();
                 ntUpCtxtDTO.setId(ntUpCtxtID);
                 ntUpCtxtDTO.newEntity();        
             }    
         }
         
         private ToDoEntry createToDo(String ntUpId, Account acct) {
             
             ToDoType toDoType = getParameters().getTD_TYPE_CD();
             
             ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
             ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();
                         
             toDoEntryDTO.setBatchControlId(getBatchControlId());
             toDoEntryDTO.setBatchNumber(getBatchNumber());            
             toDoEntryDTO.setCreationDateTime(getProcessDateTime());
             toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
             toDoEntryDTO.setToDoTypeId(toDoType.getId());
                         
             toDoCreator.setToDoDTO(toDoEntryDTO);            
             toDoCreator.addSortKeyValue(new ToDoSortKeyType_Id(toDoType, BigInteger.ONE).getEntity(), ntUpId);
             toDoCreator.addDrillKeyValue(new ToDoDrillKeyType_Id(toDoType, BigInteger.ONE).getEntity(), ntUpId);
             
             /*ToDoCharacteristicData charData = new ToDoCharacteristicData.Factory().newInstance();
             charData.*/
             toDoCreator.addForeignKeyCharacteristic(divisionCharType, acct.getDivisionId().getEntity());
             
             return toDoCreator.create();
         } 
         
         private void processLine(String recordLine){
        	 if(isBlankOrNull(recordLine)) {
    			 logMessage(CustomMessageRepositorySpireOne.ccb030_2_noRecordLineFound(
                         totalItems.toString(), fileNamePath), MessageSeverityLookup.constants.INFORMATIONAL);
    			 recordsError++;
    			 return;
             }
    		 String[] recordString = recordLine.split(",");
    		 if(recordString.length != NUM_FIELDS){
    			 logMessage(CustomMessageRepositorySpireOne.S1_recordHasIncorrectNumOfFields(
                         totalItems), MessageSeverityLookup.constants.INFORMATIONAL);
    			 recordsError++;
    			 return;
    		 }
    		 String accountStr = recordString[0];

    		 Account acct = new Account_Id(accountStr).getEntity();
    		 if(isNull(acct)){
    			 logMessage(CustomMessageRepositorySpireOne.cmCcb002SSIAccountNotFound(totalItems.toString(), accountStr), MessageSeverityLookup.constants.INFORMATIONAL);
    			 recordsError++;
    			 return;
    		 }
    		 String premId = recordString[1];  
    		 Premise prem = new Premise_Id(premId).getEntity();
    		 if(isNull(prem)){
    			 logMessage(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(totalItems.toString(),  NotificationUploadContextLookup.constants.PREMISE_ID.getConstantName()), MessageSeverityLookup.constants.INFORMATIONAL);
    			 recordsError++;
    			 return;
    		 }
    		 String custFn = recordString[2];
    		 if(isBlankOrNull(custFn)){
    			 recordsError++;
    			 logMessage(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(totalItems.toString(), NotificationUploadContextLookup.constants.CUSTOMER_FIRST_NAME.getConstantName()), MessageSeverityLookup.constants.INFORMATIONAL);
    			 return;
    		 }
    		 String custLn = recordString[3];
    		 if(isBlankOrNull(custLn)){
    			 logMessage(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(totalItems.toString(), NotificationUploadContextLookup.constants.CUSTOMER_LAST_NAME.getConstantName()), MessageSeverityLookup.constants.INFORMATIONAL);
    			 recordsError++;
    			 return;
    		 }
    		 String projNbr = recordString[4];
    		 if(isBlankOrNull(projNbr)){
    			 logMessage(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(totalItems.toString(), NotificationUploadContextLookup.constants.VDSM_PROJECT_NUM.getConstantName()), MessageSeverityLookup.constants.INFORMATIONAL);
    			 recordsError++;
    			 return;
    		 }
    		 String eetilityRefId = recordString[5];
    		 if(isBlankOrNull(eetilityRefId)){
    			 logMessage(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(totalItems.toString(),NotificationUploadContextLookup.constants.E_E_E_TILITY_REF_ID.getConstantName()), MessageSeverityLookup.constants.INFORMATIONAL);
    			 recordsError++;
    			 return;
    		 }
    		 String paysCloseoutDt = recordString[6];
    		 if(isBlankOrNull(paysCloseoutDt)){
    			 logMessage(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(totalItems.toString(), NotificationUploadContextLookup.constants.PAYS_CUST_CLOSEOUT_DT.getConstantName()), MessageSeverityLookup.constants.INFORMATIONAL);
    			 recordsError++;
    			 return;
    		 }
    		 String paysEquipmentCost = recordString[7];
    		 if(isBlankOrNull(paysEquipmentCost)){
    			 recordsError++;
    			 logMessage(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(totalItems.toString(), NotificationUploadContextLookup.constants.PAYS_TOTAL_EQUIPMENT_COST.getConstantName()), MessageSeverityLookup.constants.INFORMATIONAL);
    			 return;
    		 }
    		 String paysMonthlyAmt = recordString[8];
    		 if(isBlankOrNull(paysMonthlyAmt)){
    			 recordsError++;
    			 logMessage(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(totalItems.toString(), NotificationUploadContextLookup.constants.PAYS_MONTHLY_AMOUNT.getConstantName()), MessageSeverityLookup.constants.INFORMATIONAL);
    			 return;
    		 }
    		 String paysTermsMths = recordString[9];
    		 if(isBlankOrNull(paysTermsMths)){
    			 recordsError++;
    			 logMessage(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(totalItems.toString(), NotificationUploadContextLookup.constants.PAYS_TERMS.getConstantName()), MessageSeverityLookup.constants.INFORMATIONAL);
    			 return;
    		 }
    		 String paysBillStat = recordString[10];
    		 if(isBlankOrNull(paysBillStat)){
    			 logMessage(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(totalItems.toString(), NotificationUploadContextLookup.constants.PAYS_BILLING_STATUS.getConstantName()), MessageSeverityLookup.constants.INFORMATIONAL);
    			 recordsError++;
    			 return;
    		 }
    		 String paysIntrerestRate = recordString[11];
    		 if(isBlankOrNull(paysIntrerestRate)){
    			 logMessage(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(totalItems.toString(), NotificationUploadContextLookup.constants.PAYS_INTEREST_RATE.getConstantName()), MessageSeverityLookup.constants.INFORMATIONAL);
    			 recordsError++;
    			 return;
    		 }
    		
    		 
    		 try {
                 startChanges();
                 NotificationUpload notifUploadId = createNTUpload();
                 createNTUploadContext(notifUploadId, NotificationUploadContextLookup.constants.ACCOUNT_ID, accountStr);
                 createNTUploadContext(notifUploadId, NotificationUploadContextLookup.constants.PREMISE_ID, premId);
                 createNTUploadContext(notifUploadId, NotificationUploadContextLookup.constants.CUSTOMER_FIRST_NAME, custFn);
                 createNTUploadContext(notifUploadId, NotificationUploadContextLookup.constants.CUSTOMER_LAST_NAME, custLn);
                 createNTUploadContext(notifUploadId, NotificationUploadContextLookup.constants.VDSM_PROJECT_NUM, projNbr );
                 createNTUploadContext(notifUploadId, NotificationUploadContextLookup.constants.E_E_E_TILITY_REF_ID,eetilityRefId );
                 createNTUploadContext(notifUploadId, NotificationUploadContextLookup.constants.PAYS_CUST_CLOSEOUT_DT, paysCloseoutDt);
                 createNTUploadContext(notifUploadId, NotificationUploadContextLookup.constants.PAYS_TOTAL_EQUIPMENT_COST,paysEquipmentCost );
                 createNTUploadContext(notifUploadId, NotificationUploadContextLookup.constants.PAYS_MONTHLY_AMOUNT,paysMonthlyAmt );
                 createNTUploadContext(notifUploadId, NotificationUploadContextLookup.constants.PAYS_TERMS,paysTermsMths );
                 createNTUploadContext(notifUploadId, NotificationUploadContextLookup.constants.PAYS_BILLING_STATUS,paysBillStat );
                 createNTUploadContext(notifUploadId, NotificationUploadContextLookup.constants.PAYS_INTEREST_RATE,paysIntrerestRate );

                 if(!isNull(getParameters().getTD_TYPE_CD())){
                	 createToDo(notifUploadId.getId().getIdValue().toString(), acct);
                 }
                 saveChanges();
             } catch(ApplicationError ae) {
                 serverMessage = CustomMessageRepositorySpireOne.ccb030_2_errorUpdStaging(ae.getLocalizedMessage());
                 recordsError++;
              }
         }

	}

}
