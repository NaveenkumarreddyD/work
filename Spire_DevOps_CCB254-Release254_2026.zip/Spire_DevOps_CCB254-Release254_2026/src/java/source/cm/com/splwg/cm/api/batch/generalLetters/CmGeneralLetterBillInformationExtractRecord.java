/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Bill Information Extract Record                                                               
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                          
 * 2020-04-01  JHERNA      SA-322461. Initial version                 
 *                                                                
 *******************************************************************************
 */

package com.splwg.cm.api.batch.generalLetters;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmGeneralLetterBillInformationExtractRecord extends ColumnDelimitedRecord {
    
    // Mailing Information
    private static final String BILL_PRINT_KEY = "1110";
    private static final String MAIL_GRP = "20";
    private static final String BLANK = "  ";
    private static final String EMPTY_STR = "";
    
    public CmGeneralLetterBillInformationExtractRecord() {
        super(17);
        defaultPrintKey();
    }

    /* EXTRACT COMMON SECTIONS */
    private void defaultPrintKey() {
        this.rightPadColumn(1, 4, formatString(BILL_PRINT_KEY, 4));
    }
    
    public void setSortKeyLetterTemplateCode(String letterTemplateCode) {
        this.rightPadColumn(2, 12, formatString(letterTemplateCode, 12));
    }
    
    public void setSortKeyCcId(String ccId) {
        this.rightPadColumn(3, 10, formatString(ccId, 10));
        setSortKeyCcRecordGroup();
        setSortKeyCAndCRecordGroup();
    }
    
    private void setSortKeyCcRecordGroup() {
        this.rightPadColumn(4, 2, MAIL_GRP);
    }
    
    private void setSortKeyCAndCRecordGroup() {
        this.rightPadColumn(5, 2, BLANK);
    }
    
    public void setMailingKey(String mailingKey) {
        this.rightPadColumn(6, 12, formatString(mailingKey, 12));
        setFiller3Spaces();
    }
    
    private void setFiller3Spaces() {
        this.rightPadColumn(7, 3, " ");
    }
    
    /* EXTRACT DETAILS SECTION */
    public void setFKCharType(String fkCharType) {    	
    	this.rightPadColumn(8, 8, formatString(fkCharType, 8));
    }
          
    public void setCharTypeDescr(String charTypeDescr) {    	
    	this.rightPadColumn(9, 60, formatString(charTypeDescr, 60));
    }
    
    public void setBillId(String billID) {    	
    	this.rightPadColumn(10, 12, formatString(billID, 12));
    }
    
    public void setAcctId(String acctID) {    	
    	this.rightPadColumn(11, 10, formatString(acctID, 10));
    }
    
    public void setApayAmt(BigDecimal apayAmt) {    	
    	this.rightPadColumn(12, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(apayAmt));
    }
    
    public void setBillDate(String billDate) {    	
    	this.rightPadColumn(13, 10, formatString(billDate, 10));
    }
    
    public void setDueDate(String dueDate) {    	
    	this.rightPadColumn(14, 10, formatString(dueDate, 10));
    }
    
    public void setLpcDate(String lpcDate) {    	
    	this.rightPadColumn(15, 10, formatString(lpcDate, 10));
    }
    
    public void setBillAmt(BigDecimal billAmt) {    	
    	this.rightPadColumn(16, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(billAmt));
    	setFillerEndSpaces();
    }
    
    private void setFillerEndSpaces() {
        this.rightPadColumn(17, 1815, BLANK);
    }
        
    /**
     * Returns "" if text is null;
     * Truncates text if length exceed fieldLength;
     * @param text String variable to be formatted
     * @param fieldLength Length of Field
     * @return formatted text
     */
    private String formatString(String text, int fieldLength) {
        if(text == null) {
            text = EMPTY_STR;
        }
        else {
            text = text.trim();
            if(text.length() > fieldLength) {
                text = text.substring(0, fieldLength);
            }
        }
        return text;
    }
}
