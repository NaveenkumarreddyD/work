/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2021-03-19   RDizon     Initial version. Duplicate and optimized version
 *                         of the existing CM-BLEX algorithm.
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmBillExtractSortKeyRecord 
		extends ColumnDelimitedRecord{
	
	// Constants
    public static final String BILL_REC_BILL = "10";
    public static final String PAY_DTL_DTL = "20";
    public static final String CURR_CHG_DTL = "30";
    public static final String PA_REC_DTL = "31";
    public static final String CANCEL_CHG_DTL = "32";
    public static final String OTHER_CHG_DTL = "34";
    public static final String BILL_MSG_DTL = "40";
    public static final String BILL_REC_NONPREM = "50";
    public static final String BILL_REC_NONPREM_END = "55";
    public static final String BILL_REC_PREM = "60";
    public static final String BILL_END = "70";
    
    public static final String NP_SA_REC_SA_DTL = "10";
    public static final String NP_SA_REC_CURRENT_CHARGE = "20";
    public static final String NP_SA_REC_ADJ_DTL = "30";
    public static final String NP_SA_REC_SA_END = "40";
    
    public static final String BSEG_REC_BSEG_DTL = "10";
    public static final String BSEG_REC_CALC = "20";
    public static final String BSEG_REC_BSEGMSG_DTL = "55";
    public static final String BSEG_REC_BSEG_END = "30";
    
    public static final String CALCHDR_REC_HEADER = "10";
    public static final String CALCHDR_REC_LINE = "20";
    public static final String CALCHDR_REC_END = "30";
    
    public static final String PREM_REC_PREM = "10";
    public static final String PREM_REC_SA = "20";
    public static final String PREM_REC_END = "30";
    
    public static final String SA_REC_SA_DTL = "10";
    public static final String SA_REC_HISTOGRAM_DTL = "20";
    public static final String SA_UOM_CHAR_HIST = "22";
    public static final String SA_SQI_CHAR_HIST = "24";
    public static final String SA_REC_CURRENT_CHARGE = "30";
    public static final String SA_REC_ADJ_DTL = "40";
    public static final String SA_REC_SA_END = "50";
    
    public static final String BSEG_REC_BSEGRD_DTL = "30";
    public static final String BSEG_REC_BSEGSQ_DTL = "40";
    public static final String BSEG_REC_BSEGITM_DTL = "50";
    public static final String BSEG_REC_GRP_SEQ_BSEG_REC_BSEG_END = "60";
    
	/*
	 * Constructor
	 */
	public CmBillExtractSortKeyRecord() {
		super(17);

		// Initialize all fields to blanks/space
		this.setBillPrintIntercept(" ");
		this.setBillId(" ");
		this.setSeqNbr(" ");
		this.setCopyNbr(" ");
		this.setBillRecordGroupSeq(" ");
		this.setPayNbr(" ");
		this.setCurrentChargeNbr(" ");
		this.setMsgNbr(" ");
		this.setPremiseNbr(" ");
		this.setNonPremiseNbr(" ");
		this.STATE = " ";
		this.CITY = " ";
		this.ADDRESS1 = " ";
		this.PREMISE = " ";
		this.setPremiseSeq();		
		this.NP_SA_PRIORITY_FLG = " ";
		this.NP_SA_ID = " ";
		this.NP_SA_REC_GRP_SEQ = " ";
		this.NP_BSEG_END_DT = " ";
		this.NP_ADJ_CRE_DT = " ";
		this.NP_BSEG_ID = " ";
		this.NP_ADJ_ID = " ";
		this.NP_BSEG_REC_GRP_SEQ = " ";
		this.NP_CALCHDR_SEQ = " ";
		this.BSEG_MSGS_NBR = " ";
		this.NP_CALCHDR_REC_GRP_SEQ = " ";
		this.NP_CALC_LINE_SEQ = " ";
		this.FILLER = " ";
		this.setNonPremSaSeq();		
		this.setPremRecGrpSeq(" ");
		this.setSaPriorityFlg(" ");
		this.setSaID(" ");
		this.setSaRecGrpSeq(" ");
		this.setBsegEndDt(" ");
		this.setAdjCreDt(" ");
		this.setHistDtlNbr(" ");
		this.setBsegID(" ");
		this.setAdjID(" ");
		this.setBsegRecGrpSeq(" ");
		this.setCalcHdrSeq(" ");
		this.setBsegReadNbr(" "); 
		this.setBsegSqNbr(" ");
		this.setBsegItemNbr(" ");
		this.setCalcHdrLineBsegMsgsNbr(" ");
		this.setCalcHdrRecGrpSeq(" ");
		this.setCalcLineSeq(" ");		
	}
	
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * CICBXBKS
	 */
	public void setBillPrintIntercept(String value) {
		leftPadColumn(1, 8, truncateInput(value, 8));
	}
	
	public void setBillId(String value) {
		if (StringUtilities.isBlankOrNull(value)) {
			value = "0";
		}
		leftPadColumnWithZeros(2, 12, truncateInput(value, 12));
	}
	
	public void setSeqNbr(String value) {
		if (StringUtilities.isBlankOrNull(value)) {
			value = "0";
		}
		leftPadColumnWithZeros(3, 2, truncateInput(value, 2));
	}
	
	public void setCopyNbr(String value) {
		if (StringUtilities.isBlankOrNull(value)) {
			value = "0";
		}
		leftPadColumnWithZeros(4, 1, truncateInput(value, 1));
	}	
	
	public void setBillRecordGroupSeq(String value) {
		rightPadColumn(5, 2, truncateInput(value, 2));
	}
	
	public void setPayNbr(String value) {
		rightPadColumn(6, 2, truncateInput(value, 2));
	}
	// Redefines PayNbr
	public void setCurrentChargeNbr(String value) {
		rightPadColumn(6, 2, truncateInput(value, 2));
	}
	// Redefines PayNbr	
	public void setMsgNbr(String value) {
		rightPadColumn(6, 2, truncateInput(value, 2));
	}
	// Redefines PayNbr
	public void setPremiseNbr(String value) {
		rightPadColumn(6, 2, truncateInput(value, 2));
	}
	// Redefines PayNbr
	public void setNonPremiseNbr(String value) {
		rightPadColumn(6, 2, truncateInput(value, 2));
	}

	public String STATE = " ";
	public String CITY = " ";
	public String ADDRESS1 = " ";
	public String PREMISE = " ";
	public void setPremiseSeq() {
		
		String value = " ";
		STATE = StringUtilities.padRight(truncateInput(STATE, 6), 6);
		CITY = StringUtilities.padRight(truncateInput(CITY, 30), 30);
		ADDRESS1 = StringUtilities.padRight(truncateInput(ADDRESS1, 64), 64);
		PREMISE = StringUtilities.padRight(truncateInput(PREMISE, 10), 10);
		value = STATE.concat(CITY);
		value = value.concat(ADDRESS1);
		value = value.concat(PREMISE);
		rightPadColumn(7, 110, value);
	}
	public String NP_SA_PRIORITY_FLG = " ";
	public String NP_SA_ID = " ";
	public String NP_SA_REC_GRP_SEQ = " ";
	public String NP_BSEG_END_DT = " ";
	public String NP_ADJ_CRE_DT = " "; 
	public String NP_BSEG_ID = " ";
	public String NP_ADJ_ID = " "; 
	public String NP_BSEG_REC_GRP_SEQ = " ";
	public String NP_CALCHDR_SEQ = " "; 
	public String BSEG_MSGS_NBR = " "; 
	public String NP_CALCHDR_REC_GRP_SEQ = " ";
	public String NP_CALC_LINE_SEQ = " "; 
	public String FILLER = " "; 
	public void setNonPremSaSeq() {
		
		String value = " ";
		NP_SA_PRIORITY_FLG = StringUtilities.padRight(truncateInput(NP_SA_PRIORITY_FLG, 2), 2);
		NP_SA_ID = StringUtilities.padRight(truncateInput(NP_SA_ID, 10), 10);
		NP_SA_REC_GRP_SEQ = StringUtilities.padRight(truncateInput(NP_SA_REC_GRP_SEQ, 2), 2);
		NP_BSEG_END_DT = StringUtilities.padRight(truncateInput(NP_BSEG_END_DT, 10), 10);
		NP_ADJ_CRE_DT = StringUtilities.padRight(truncateInput(NP_ADJ_CRE_DT, 10), 10);
		NP_BSEG_ID = StringUtilities.padRight(truncateInput(NP_BSEG_ID, 12), 12);
		NP_ADJ_ID = StringUtilities.padRight(truncateInput(NP_ADJ_ID, 12), 12);
		NP_BSEG_REC_GRP_SEQ = StringUtilities.padRight(truncateInput(NP_BSEG_REC_GRP_SEQ, 2), 2);
		
		if (StringUtilities.notEmptyOrBlank(NP_CALCHDR_SEQ)) {
			NP_CALCHDR_SEQ =  StringUtilities.leftPadWithZeros(NP_CALCHDR_SEQ.trim(), 2);
		}
		else {
			NP_CALCHDR_SEQ =  this.padLeft(NP_CALCHDR_SEQ, 2);
		}		
						
		if (StringUtilities.notEmptyOrBlank(BSEG_MSGS_NBR)) {
			BSEG_MSGS_NBR = StringUtilities.leftPadWithZeros(BSEG_MSGS_NBR, 2);
		}
		else {
			BSEG_MSGS_NBR = this.padLeft(BSEG_MSGS_NBR, 2);
		}				
		
		NP_CALCHDR_REC_GRP_SEQ = StringUtilities.padRight(truncateInput(NP_CALCHDR_REC_GRP_SEQ, 2), 2);
		
		if (StringUtilities.notEmptyOrBlank(NP_CALC_LINE_SEQ)) {
			NP_CALC_LINE_SEQ = StringUtilities.leftPadWithZeros(NP_CALC_LINE_SEQ.trim(), 3);
		}
		else {
			NP_CALC_LINE_SEQ = this.padLeft(NP_CALC_LINE_SEQ, 3); // Justified Right
		}
		
		
		FILLER = StringUtilities.padRight(FILLER, 65); 
		value = NP_SA_PRIORITY_FLG.concat(NP_SA_ID);
		value = value.concat(NP_SA_REC_GRP_SEQ);
		if (StringUtilities.notEmptyOrBlank(NP_BSEG_END_DT)) {
			value = value.concat(NP_BSEG_END_DT);
			
		}else {
			value = value.concat(NP_ADJ_CRE_DT);
		}				
		if (StringUtilities.notEmptyOrBlank(NP_BSEG_ID)) {
			value = value.concat(NP_BSEG_ID);
		}else {
			value = value.concat(NP_ADJ_ID);
		}
		value = value.concat(NP_BSEG_REC_GRP_SEQ);
		if (StringUtilities.notEmptyOrBlank(NP_CALCHDR_SEQ)) {
			value = value.concat(NP_CALCHDR_SEQ);
		}else {
			value = value.concat(BSEG_MSGS_NBR);
		}
		value = value.concat(NP_CALCHDR_REC_GRP_SEQ);
		value = value.concat(NP_CALC_LINE_SEQ);
		value = value.concat(FILLER);
		rightPadColumn(7, 110, value);
	}
	public String padLeft(String value, int maxSize) {
		
		String returnValue = value;
		while (returnValue.length() < maxSize) {
			returnValue = " ".concat(returnValue);
		}
		return returnValue;
	}	

	public void setPremRecGrpSeq(String value) {
		rightPadColumn(8, 2, truncateInput(value, 2));
	}

	public void setSaPriorityFlg(String value) {
		rightPadColumn(9, 2, truncateInput(value, 2));
	}

	public void setSaID(String value) {
		rightPadColumn(10, 10, truncateInput(value, 10));
	}
	
	public void setSaRecGrpSeq(String value) {
		rightPadColumn(11, 2, truncateInput(value, 2));
	}
	
	public void setBsegEndDt(String value) {
		rightPadColumn(12, 10, truncateInput(value, 10));
	}
	
	public void setAdjCreDt(String value) {
		rightPadColumn(12, 10, truncateInput(value, 10));
	}
	
	public void setHistDtlNbr(String value) {
		if (StringUtilities.notEmptyOrBlank(value)) {
			String histogramDetailNbr = " ";
			histogramDetailNbr = StringUtilities.leftPadWithZeros(truncateInput(value, 3), 3);		
			rightPadColumn(12, 10, truncateInput(histogramDetailNbr, 10));
		}
		else {
			rightPadColumn(12, 10, truncateInput(" ", 10));
		}
	}
	public void setBsegID(String value) {
		rightPadColumn(13, 12, truncateInput(value, 12));
	}

	public void setAdjID(String value) {
		rightPadColumn(13, 12, truncateInput(value, 12));
	}
	
	public void setBsegRecGrpSeq(String value) {
		rightPadColumn(14, 2, truncateInput(value, 2));
	}
	
	public void setCalcHdrSeq(String value) {
		if (StringUtilities.isBlankOrNull(value)) {
			leftPadColumn(15, 2, truncateInput(value, 2));
		}
		else {
			leftPadColumnWithZeros(15, 2, truncateInput(value, 2));
		}		
	}

	public void setBsegReadNbr(String value) {
		if (StringUtilities.isBlankOrNull(value)) {
			leftPadColumn(15, 2, truncateInput(value, 2));
		}
		else {
			leftPadColumnWithZeros(15, 2, truncateInput(value, 2));
		}
	}

	public void setBsegSqNbr(String value) {
		if (StringUtilities.isBlankOrNull(value)) {
			leftPadColumn(15, 2, truncateInput(value, 2));
		}
		else {
			leftPadColumnWithZeros(15, 2, truncateInput(value, 2));
		}
	}

	public void setBsegItemNbr(String value) {
		if (StringUtilities.isBlankOrNull(value)) {
			leftPadColumn(15, 2, truncateInput(value, 2));
		}
		else {
			leftPadColumnWithZeros(15, 2, truncateInput(value, 2));
		}
	}

	public void setCalcHdrLineBsegMsgsNbr(String value) {
		if (StringUtilities.isBlankOrNull(value)) {
			leftPadColumn(15, 2, truncateInput(value, 2));
		}
		else {
			leftPadColumnWithZeros(15, 2, truncateInput(value, 2));
		}
	}
	
	public void setCalcHdrRecGrpSeq(String value) {
		if (StringUtilities.isBlankOrNull(value)) {
			leftPadColumn(16, 2, truncateInput(value, 2));
		}
		else {
			leftPadColumnWithZeros(16, 2, truncateInput(value, 2));
		}
	}
	
	public void setCalcLineSeq(String value) {
		if (StringUtilities.isBlankOrNull(value)) {
			leftPadColumn(17, 3, truncateInput(value, 3));
		}
		else {
			leftPadColumnWithZeros(17, 3, truncateInput(value, 3));
		}
	}
	
	public void setFillerNonPremRecGrp1() {
		rightPadColumn(8, 1, " ");
	}
	
	public void setFillerNonPremRecGrp2() {
		rightPadColumn(9, 1, " ");
	}
	
	public void setFillerNonPremRecGrp3() {
		rightPadColumn(10, 1, " ");
	}
	
	public void setFillerNonPremRecGrp4() {
		rightPadColumn(11, 1, " ");
	}
	
	public void setFillerNonPremRecGrp5() {
		rightPadColumn(12, 1, " ");
	}
	
	public void setFillerNonPremRecGrp6() {
		rightPadColumn(13, 1, " ");
	}
	
	public void setFillerNonPremRecGrp7() {
		rightPadColumn(14, 1, " ");
	}
	
	public void setFillerNonPremRecGrp8() {
		rightPadColumn(15, 1, " ");
	}
	
	public void setFillerNonPremRecGrp9() {
		rightPadColumn(16, 1, " ");
	}
	
	public void setFillerNonPremRecGrp10() {
		rightPadColumn(17, 38, " ");
	}
}