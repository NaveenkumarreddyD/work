package com.splwg.cm.domain.admin.generalLedgerDistributionCode;

/**************************************************************************
 *                                                                         *
 * PROGRAM DESCRIPTION:                                                    *
 *                                                                         *
 * This custom Algorithm Type will take a GL Account String from a         *
 * distribution code and substitute any default values from the CIS        *
 * Division if a % with the appropriate name is given instead of the       *
 * literal code for the GL Accounting string.                              *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * CHANGE HISTORY:                                                         *
 *                                                                         *
 * Date:        by:             Reason:                                    *
 * YYYY-MM-DD   IN              Reason text.                               *
 *                                                                         *
 * 2014-08-26   Ted Schmidt     CCB015 Initial Version.					   *
 * 2016-01-26   MPang			Updated for CCB v2.4 compilation.          *
 * 2019-07-15   JLumbre	        Updated for Finance testing.               *
 * 2021-10-04   GCrisp	        Defect 4595530. Close prepared statement   *
 *                              and remove execute.                        *
 **************************************************************************/

import java.math.BigInteger;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.EffectiveStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.StandardMessages;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.CisDivisionCharacteristic;
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.GeneralLedgerDistributionCode;
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.GeneralLedgerDistributionCodeGlAccountConstructionAlgorithmSpot;
import com.splwg.ccb.domain.financial.financialTransaction.FinancialTransaction;*/

import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivisionCharacteristic;
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.entity.GeneralLedgerDistributionCode;
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.algorithm.glAccountConstruction.GeneralLedgerDistributionCodeGlAccountConstructionAlgorithmSpot;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 20404
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = delimiter, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = companyCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = lineOfBusinessCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = providerCostCenterCharType, type = entity)            
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = receiverCostCenterCharType, type = entity)            
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = costElementCharType, type = entity)            
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = placeholder1CharType, type = entity)             
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = placeholder2CharType, type = entity)             
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = placeholder3CharType, type = entity)            
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = placeholder4CharType, type = entity)})
 */
public class CmGlAccountConstructionAlgComp_Impl extends
CmGlAccountConstructionAlgComp_Gen implements
GeneralLedgerDistributionCodeGlAccountConstructionAlgorithmSpot {

	// Constants
	//private static final int GL_MAX_NUM_COMPONENTS = 10;
	private static final String SUB_COMP = "%COMP";
	// Ferc Number will never be defaulted
	//private static final String SUB_FERC = "%FERC";
	private static final String SUB_PCOST = "%PCOST";
	//private static final String SUB_RCOST = "%RCOST";
	private static final String SUB_CELMT = "%CELMT";
	//private static final String SUB_LOB = "%LOB";
	private static final String SUB_PH1 = "%PH1";
	private static final String SUB_PH2 = "%PH2";
	//private static final String SUB_PH3 = "%PH3";
	private static final String SUB_PH4 = "%PH4";

	// Hard Parameters
	private String outGlAccount;
	private FinancialTransaction inFinancialTransaction;
	private GeneralLedgerDistributionCode inGlDistribution;

	// Soft Parameters
	private String parmDelimiter;
	private CharacteristicType parmCompanyCharType;
	private CharacteristicType parmLineOfBusinessCharType;
	private CharacteristicType parmProviderCostCenterCharType;
	private CharacteristicType parmReceiverCostCenterCharType;
	private CharacteristicType parmCostElementCharType;
	private CharacteristicType parmPlaceholder1CharType;
	private CharacteristicType parmPlaceholder2CharType;
	private CharacteristicType parmPlaceholder3CharType;
	private CharacteristicType parmPlaceholder4CharType;

	// Initial GL Account Components
	private String initComp = "";
	private String initFercNbr = "";
	private String initProvCost = "";
	//private String initRecCost = "";
	private String initCostEl = "";
	//private String initLOB = "";
	private String initPH1 = "";
	private String initPH2 = "";
	//private String initPH3 = "";
	private String initPH4 = "";

	// Final GL Account Components
	private String fnlComp = "";
	private String fnlFercNbr = "";
	private String fnlProvCost = "";
	//private String fnlRecCost = "";
	private String fnlCostEl = "";
	//private String fnlLOB = "";
	private String fnlPH1 = "";
	private String fnlPH2 = "";
	//private String fnlPH3 = "";
	private String fnlPH4 = "";

	protected void extraSoftParameterValidations(boolean arg0) {
		// Retrieve parameter 10
		parmDelimiter = this.getDelimiter();

		// Retrieve parameter 20
		parmCompanyCharType = this.getCompanyCharType();

		cmValidateCharTypeForEntity(parmCompanyCharType, CharacteristicEntityLookup.constants.CIS_DIVISION, "Company Char Type");

		// Retrieve parameter 30
		parmLineOfBusinessCharType = this.getLineOfBusinessCharType();

		cmValidateCharTypeForEntity(parmLineOfBusinessCharType, CharacteristicEntityLookup.constants.CIS_DIVISION, "Line of Bus Char Type");

		// Retrieve parameter 40 (optional)
		parmProviderCostCenterCharType = this.getProviderCostCenterCharType();

		if (notNull(parmProviderCostCenterCharType)) {
			cmValidateCharTypeForEntity(parmProviderCostCenterCharType, CharacteristicEntityLookup.constants.CIS_DIVISION, "Provider Cost Ctr Char Type");
		}
		// Retrieve parameter 50 (optional)
		parmReceiverCostCenterCharType = this.getReceiverCostCenterCharType();

		if (notNull(parmReceiverCostCenterCharType)) {
			cmValidateCharTypeForEntity(parmReceiverCostCenterCharType, CharacteristicEntityLookup.constants.CIS_DIVISION, "Receiver Cost Ctr Char Type");
		}
		// Retrieve parameter 60 (optional)
		parmCostElementCharType = this.getCostElementCharType();

		if (notNull(parmCostElementCharType)) {
			cmValidateCharTypeForEntity(parmCostElementCharType, CharacteristicEntityLookup.constants.CIS_DIVISION, "Cost Element Char Type");
		}
		// Retrieve parameter 70 (optional)
		parmPlaceholder1CharType = this.getPlaceholder1CharType();

		if (notNull(parmPlaceholder1CharType)) {
			cmValidateCharTypeForEntity(parmPlaceholder1CharType, CharacteristicEntityLookup.constants.CIS_DIVISION, "Placeholder 1 Char Type");
		}
		// Retrieve parameter 80 (optional)
		parmPlaceholder2CharType = this.getPlaceholder2CharType();

		if (notNull(parmPlaceholder2CharType)) {
			cmValidateCharTypeForEntity(parmPlaceholder2CharType, CharacteristicEntityLookup.constants.CIS_DIVISION, "Placeholder 2 Char Type");
		}
		// Retrieve parameter 90 (optional)
		parmPlaceholder3CharType = this.getPlaceholder3CharType();

		if (notNull(parmPlaceholder3CharType)) {
			cmValidateCharTypeForEntity(parmPlaceholder3CharType, CharacteristicEntityLookup.constants.CIS_DIVISION, "Placeholder 3 Char Type");
		}
		// Retrieve parameter 100 (optional)
		parmPlaceholder4CharType = this.getPlaceholder4CharType();

		if (notNull(parmPlaceholder4CharType)) {
			cmValidateCharTypeForEntity(parmPlaceholder4CharType, CharacteristicEntityLookup.constants.CIS_DIVISION, "Placeholder 4 Char Type");
		}
	}

	private void cmValidateCharTypeForEntity(CharacteristicType charType, CharacteristicEntityLookup entity, String parmDesc) {
		if (this.isOnlineConnection()) {
			CharacteristicEntity_Id charEntity_Id = new CharacteristicEntity_Id(charType, entity);
			if (isNull(charEntity_Id.getEntity())) {
				addError(CustomMessageRepositoryMGE.commAlgorithmParameterIsInvalid(this.getAlgorithm().getId().getTrimmedValue(),
						parmDesc.trim(), charType.getId().getTrimmedValue()));
			}
		}
	}

	public String getGlAccount() {
		//Final GL Account String
		return outGlAccount;
	}

	public void setFinancialTransaction(FinancialTransaction fT) {
		if (isNull(fT)) {
			addError(StandardMessages.fieldMissing("Financial Transaction"));
		}

		inFinancialTransaction = fT;
	}

	public void setGlDistribution(GeneralLedgerDistributionCode gLDC) {
		if (isNull(gLDC)) {
			addError(StandardMessages.fieldMissing("GL Distribution Code"));
		}
		
		inGlDistribution = gLDC;
	}

	public void setGlSequenceNumber(BigInteger arg0) {
	}

	public void invoke() {
		// Retrieve the account date from the financial transaction
		Date accountingDate = inFinancialTransaction.getAccountingDate();

		// Validate Account Date
		if (isNull(accountingDate)) {
			addError(CustomMessageRepositoryMGE.ccb015AccountDateNotFound(inFinancialTransaction.getId().getTrimmedValue()));
		}

		// Retrieve the GL Account string from Distribution code
		String glAccount = cmGLAccountString(inGlDistribution, accountingDate);

		// Derive the Account String Components
		cmSplitAccountString(glAccount);

		// Process the Account String Components
		cmProcessAccountString();

		// Assemble the Account String Components
		outGlAccount = cmAssembleAccountString();
	}

	private String cmAssembleAccountString() {
		// Concatenate the new GL Accounting String together
		String returnVal = "";

		returnVal = returnVal.concat(fnlComp.trim());
		returnVal = returnVal.concat(parmDelimiter.trim());
		returnVal = returnVal.concat(fnlFercNbr.trim());
		returnVal = returnVal.concat(parmDelimiter.trim());
		returnVal = returnVal.concat(fnlProvCost.trim());
		returnVal = returnVal.concat(parmDelimiter.trim());
		//returnVal = returnVal.concat(fnlRecCost.trim());
		//returnVal = returnVal.concat(parmDelimiter.trim());
		returnVal = returnVal.concat(fnlCostEl.trim());
		returnVal = returnVal.concat(parmDelimiter.trim());
		//returnVal = returnVal.concat(fnlLOB.trim());
		//returnVal = returnVal.concat(parmDelimiter.trim());
		returnVal = returnVal.concat(fnlPH1.trim());
		returnVal = returnVal.concat(parmDelimiter.trim());
		returnVal = returnVal.concat(fnlPH2.trim());
		returnVal = returnVal.concat(parmDelimiter.trim());
		//returnVal = returnVal.concat(fnlPH3.trim());
		//returnVal = returnVal.concat(parmDelimiter.trim());
		returnVal = returnVal.concat(fnlPH4.trim());

		return returnVal;
	}

	private void cmProcessAccountString() {
		// Derive the new string based on substitutions

		// Calculate Company section of GL Account String
		fnlComp = cmRetrieveFinalSection(initComp, SUB_COMP, parmCompanyCharType);

		// FERC Number will never be derived
		fnlFercNbr = initFercNbr;

		// Calculate Provider Cost section of the GL Account String	
		fnlProvCost = cmRetrieveFinalSection(initProvCost, SUB_PCOST, parmProviderCostCenterCharType);

		// Calculate Receiver Cost section of the GL Account String
		//fnlRecCost = cmRetrieveFinalSection(initRecCost, SUB_RCOST, parmReceiverCostCenterCharType);

		// Calculate Cost Element section of the GL Account String
		fnlCostEl = cmRetrieveFinalSection(initCostEl, SUB_CELMT, parmCostElementCharType);

		// Calculate Line of Business section of the GL Account String
		//fnlLOB = cmRetrieveFinalSection(initLOB, SUB_LOB, parmLineOfBusinessCharType);

		// Calculate Placeholder 1 section of the GL Account String
		fnlPH1 = cmRetrieveFinalSection(initPH1, SUB_PH1, parmPlaceholder1CharType);

		// Calculate Placeholder 2 section of the GL Account String
		fnlPH2 = cmRetrieveFinalSection(initPH2, SUB_PH2, parmPlaceholder2CharType);

		// Calculate Placeholder 3 section of the GL Account String
		//fnlPH3 = cmRetrieveFinalSection(initPH3, SUB_PH3, parmPlaceholder3CharType);

		// Calculate Placeholder 4 section of the GL Account String
		fnlPH4 = cmRetrieveFinalSection(initPH4, SUB_PH4, parmPlaceholder4CharType);
	}

	private String cmRetrieveFinalSection(String initialVal, String compareVal, CharacteristicType charType) {
		// If no substitution found (later) then set to initial value (no change)
		String finalVal = initialVal;

		// Check to see if the substitution parameter was used
		if (initialVal.compareTo(compareVal) == 0) {

			// Lookup the value if substitution parameter used
			finalVal = cmRetrieveFromCisDivChar(charType);

			// If not found throw an error
			if (isBlankOrNull(finalVal)) {
				addError(CustomMessageRepositoryMGE.ccb015CisDivCharNotFound(charType.getId().getTrimmedValue(), initialVal.trim()));
			}

		}

		// Insure derived value, even if just copied from original, is valid
		if (!(finalVal.trim().matches("[a-zA-Z0-9]+"))) {
			addError(CustomMessageRepositoryMGE.ccb015CisDivCharInvalid(charType.getId().getTrimmedValue(), finalVal.trim()));
		}	

		return finalVal;
	}

	private String cmRetrieveFromCisDivChar(CharacteristicType charType) {
		String returnValue = " ";
		CisDivision cisDiv = inFinancialTransaction.getDivision();
		CisDivisionCharacteristic cisDivChar = cisDiv.getEffectiveCharacteristic(charType);

		if (notNull(cisDivChar)) {

			// adhoc and file location value use the same field
			if (charType.getCharacteristicType().isAdhocValue()) {
				returnValue = cisDivChar.getAdhocCharacteristicValue();

			} else if (charType.getCharacteristicType().isForeignKeyValue()) {
				returnValue = cisDivChar.getCharacteristicValueForeignKey1();

			} else if (charType.getCharacteristicType().isFileLocationValue()){
				returnValue = cisDivChar.getAdhocCharacteristicValue();

			} else {
				// isPredefinedValue()
				returnValue = cisDivChar.getCharacteristicValue();

			}
		}

		return returnValue;
	}

	private void cmSplitAccountString(String glAccount) {
		// Use split to delimit the GL account
		String delimiter = "["+parmDelimiter.trim()+"]";

		// Use -1 so if there are successive periods each period will be used as a delimiter
		String[] splitVal = glAccount.split(delimiter,-1);

		//Start Delete - 2019-07-15 JLumbre - Defect XX
		/*if (splitVal.length != GL_MAX_NUM_COMPONENTS) {
			addError(CustomMessageRepositoryMGE.ccb015GlAcct_Invalid_Num_Components(String.valueOf(GL_MAX_NUM_COMPONENTS).trim(), glAccount.trim(), String.valueOf(splitVal.length).trim()));

		}*/
		//End Delete - 2019-07-15 JLumbre - Defect XX

		initComp = splitVal[0];
		initFercNbr = splitVal[1];
		initProvCost = splitVal[2];
		//initRecCost = splitVal[3];
		initCostEl = splitVal[3];
		//initLOB = splitVal[5];
		initPH1 = splitVal[4];
		initPH2 = splitVal[5];
		//initPH3 = splitVal[8];
		initPH4 = splitVal[6];

	}

	private String cmGLAccountString(GeneralLedgerDistributionCode GlDistribution, Date accountingDate) {
		// Get the GL account String given a general ledger distribution code and accounting date
		String returnValue = " ";

		// Use SQL to lookup GL Account
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT GL_ACCT ");
		stringBuilder.append("FROM CI_DST_CODE_EFF ");
		stringBuilder.append("WHERE DST_ID = :distCode ");
		stringBuilder.append("AND EFF_STATUS = :status ");
		stringBuilder.append("AND EFFDT <= :accountingDate ");
		stringBuilder.append("AND ROWNUM = 1 ");
		stringBuilder.append("ORDER BY EFFDT DESC ");
		//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
		// PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
		prepState.bindId("distCode", GlDistribution.getId());
		prepState.bindLookup("status", EffectiveStatusLookup.constants.ACTIVE);
		prepState.bindDate("accountingDate", accountingDate);
		// Start Delete - GCrisp - Defect 4595530 - 2021-10-04
		//prepState.execute();
		// End Delete - GCrisp - Defect 4595530 - 2021-10-04
		prepState.setAutoclose(false);

		// Should only return 1 row
		if (prepState.list().size() == 1) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			returnValue = (String) sqlRow.get("GL_ACCT");
		}
		
		// Start Add - GCrisp - Defect 4595530 - 2021-10-04
		prepState.close();
		// End Add - GCrisp - Defect 4595530 - 2021-10-04

		return returnValue;
	}

}
