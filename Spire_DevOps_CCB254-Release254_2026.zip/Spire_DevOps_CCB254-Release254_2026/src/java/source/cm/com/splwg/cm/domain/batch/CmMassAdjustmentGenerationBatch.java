/**************************************************************************
 * Program Name: CmMassAdjustmentGenerationBatch
 * Program Title: CmMassAdjustmentGenerationBatch
 * Author: Marianne Pango
 * Creation Date: 2019-05-15
 * Purpose: This custom Batch Process is one-time batch that uses an input
 *          file to determine which accounts need to be processed. 
 *          Batch will create an adjustment on the processed accounts 
 *          using the processing logic defined below and that 
 *          batch process parameters.
 * Functional Spec: SA-286376
 **************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 *-----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 * SA-286376          Marianne Pango   2019-05-15    Initial version
 * SysAid#340159      JHERNA		   2020-07-20    Updates:
 *                                                     1.) Fix defect wherein stopped SAs are not
 *                                                         taken into consideration.
 *                                                     2.) Make customer contact creation to be 
 *                                                         an optional functionality.
 *                                                     3.) Performance improvements.
 *                                                     4.) add new parameter which would determine
 *                                                         if a new SA will be created if the
 *                                                         only SA on the account is a stopped SA.
 * Defect 4609833     BMarquez         2021-10-20    Add option to not set the Arrears Date for
 *                                                   the created Adjustment.
 ************************************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.StringTokenizer;

import com.ibm.icu.math.BigDecimal;
import com.ibm.icu.text.DecimalFormat;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.CustomerReadLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.StartReasonLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_DTO;
import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.common.ServiceAgreementCreator;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.data.ServiceAgreementCreatorData;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.common.ApplicationError;

/**
 * @author MPang
 *
 @BatchJob (modules = {}, multiThreaded = false, rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS_THRESHOLD, type = integer)
 *            , @BatchJobSoftParameter (name = SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = adjustmentType, name = ADJUSTMENT_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CUSTOMER_CONTACT_TYPE, type = string)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CUSTOMER_CONTACT_CLASS, type = entity)
 *            , @BatchJobSoftParameter (name = EXCLUDE_SA_TYPES, type = string)
 *            , @BatchJobSoftParameter (name = ADJUSTMENT_COMMENT, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CUSTOMER_CONTACT_COMMENT, type = string)
 *            , @BatchJobSoftParameter (name = CREATE_NEW_SA_FOR_STOPPED_SA, required = true, type = boolean)
 *            , @BatchJobSoftParameter (name = SET_ADJ_ARREARS_DT_SW, required = true, type = boolean)})
 */
public class CmMassAdjustmentGenerationBatch
extends CmMassAdjustmentGenerationBatch_Gen {

	// Soft Parameters
	private String filePath;
	private String fileName;
	private BigInteger maxErrorsThreshold;
	private String saType;
	@SuppressWarnings("unused")
	private AdjustmentType adjustmentType;
	private CustomerContactClass customerContactClass;
	private String customerContactTypeStr;
	private String excludeSaTypes;
	@SuppressWarnings("unused")
	private String adjustmentComment;
	private String customerContactComment;

	/* START ADD - JHERNA - 2020-07-20 - SysAid#340159 */
	@SuppressWarnings("unused")
	private Bool parmCreateSAIfAccountOnlyHaveStoppedSA;
	private static final String PARM_60_CC_TYPE_DESC = "Customer Contact Type";
	private static final String PARM_70_CC_CLASS_DESC = "Customer Contact Class";
	private static final String PARM_100_CC_COMMENT_DESC = "Customer Contact Comment";
	/* END ADD - JHERNA - 2020-07-20 - SysAid#340159 */
	
	// Work Variable
	private CustomerContactType_Id ccTypeId;

	// Constants
	private final static String COMMA = ",";

	public JobWork getJobWork() {
		ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
		arrayList.add(threadWorkUnit);
		return createJobWorkForThreadWorkUnitList(arrayList);
	}
	/**
	 * This method retrieves all the soft Parameters of the batch
	 */
	private void retrieveBatchParameters() {

		filePath = getParameters().getFILE_PATH();
		fileName = getParameters().getFILE_NAME();
		maxErrorsThreshold = getParameters().getMAX_ERRORS_THRESHOLD();
		saType = getParameters().getSA_TYPE();
		adjustmentType = getParameters().getADJUSTMENT_TYPE();
		customerContactClass = getParameters().getCUSTOMER_CONTACT_CLASS();
		customerContactTypeStr = getParameters().getCUSTOMER_CONTACT_TYPE();
		excludeSaTypes = getParameters().getEXCLUDE_SA_TYPES();
		adjustmentComment = getParameters().getADJUSTMENT_COMMENT();
		customerContactComment = getParameters().getCUSTOMER_CONTACT_COMMENT();
		/* START ADD - JHERNA - 2020-07-20 - SysAid#340159 */
		parmCreateSAIfAccountOnlyHaveStoppedSA = this.getParameters().getCREATE_NEW_SA_FOR_STOPPED_SA();				
		/* END ADD - JHERNA - 2020-07-20 - SysAid#340159 */
	}

	public void validateSoftParameters(boolean arg0) {

		retrieveBatchParameters();

		// Validate filePath directory does exists.
		File path = new File(filePath);
		if (!path.exists() || !path.isDirectory()) {
			addError(CustomMessageRepository.SA_286376_filePathNotFound(filePath));
		}

		// Validate fileName does exists.
		File inputFile = new File(filePath, fileName);
		if(!inputFile.exists() || !inputFile.canRead()){
			addError(CustomMessageRepository.SA_286376_parameterFileNameInvalid(fileName)); 
		} 

		// Check if the parameter MAX_ERRORS_THRESHOLD is less than 0 
		if(notNull(maxErrorsThreshold)) {
			if (maxErrorsThreshold.intValue() < 0) {
				addError(CustomMessageRepository.SA_286376_parameterMaxThresholdCannotBeZero(maxErrorsThreshold.toString())); 
			}
		}
		
		/* START DELETE - JHERNA - 2020-07-20 - SysAid#340159 */
		/* MOVED TO ANOTHER SECTION */
		/*
		// Validate Parameter CUSTOMER_CONTACT_TYPE
		ccTypeId = new CustomerContactType_Id(customerContactClass, customerContactTypeStr);
		if(isNull(ccTypeId.getEntity())){
			addError(CustomMessageRepository.SA_286376_invalidCcClassTypeCombination(customerContactClass.getId().getTrimmedValue(),customerContactTypeStr));
		}
		*/
		/* START DELETE - JHERNA - 2020-07-20 - SysAid#340159 */	
		
		// Validate Parameter SA_TYPE
		cmValidateSaType(saType, "SA Type");

		// Validate Parameter EXCLUDE_SA_TYPES
		if (notBlank(excludeSaTypes)) {
			StringTokenizer saTypeTokenizer = new StringTokenizer(excludeSaTypes, COMMA); 
			while (saTypeTokenizer.hasMoreTokens()) {
				cmValidateSaType(saTypeTokenizer.nextToken(), "List of Excluded SA Types");
			}
		}

		/* START ADD - JHERNA - 2020-07-20 - SysAid#340159 */		
		// customer contact generation is now optional. If one of the 3 customer contact related parameter is provided then all must be provided
		if (notNull(customerContactClass)) {
			if (isBlankOrNull(customerContactTypeStr)) {
				// Batch parameter '%1%2' is required when parameter '%3%4' is supplied.
				addError(CustomMessageRepositoryMGE.commBatchParameterRequiredWhenParameterSupplied(
						PARM_60_CC_TYPE_DESC, PARM_70_CC_CLASS_DESC));
			}
			if (isBlankOrNull(customerContactComment)) {
				// Batch parameter '%1%2' is required when parameter '%3%4' is supplied.
				addError(CustomMessageRepositoryMGE.commBatchParameterRequiredWhenParameterSupplied(
						PARM_100_CC_COMMENT_DESC, PARM_70_CC_CLASS_DESC));
			}			
		}
		else if (notBlank(customerContactTypeStr)) {
			if (isNull(customerContactClass)) {
				// Batch parameter '%1%2' is required when parameter '%3%4' is supplied.
				addError(CustomMessageRepositoryMGE.commBatchParameterRequiredWhenParameterSupplied(
						PARM_70_CC_CLASS_DESC, PARM_60_CC_TYPE_DESC));
			}
			if (isBlankOrNull(customerContactComment)) {
				// Batch parameter '%1%2' is required when parameter '%3%4' is supplied.
				addError(CustomMessageRepositoryMGE.commBatchParameterRequiredWhenParameterSupplied(
						PARM_100_CC_COMMENT_DESC, PARM_60_CC_TYPE_DESC));
			}
		} 
		else if (notBlank(customerContactComment)) {
			if (isNull(customerContactClass)) {
				// Batch parameter '%1%2' is required when parameter '%3%4' is supplied.
				addError(CustomMessageRepositoryMGE.commBatchParameterRequiredWhenParameterSupplied(
						PARM_70_CC_CLASS_DESC, PARM_100_CC_COMMENT_DESC));
			}
			if (isBlankOrNull(customerContactTypeStr)) {
				// Batch parameter '%1%2' is required when parameter '%3%4' is supplied.
				addError(CustomMessageRepositoryMGE.commBatchParameterRequiredWhenParameterSupplied(
						PARM_60_CC_TYPE_DESC, PARM_100_CC_COMMENT_DESC));
			}			
		}
		/* Validate that the provided customer contact related parameters are valid.*/
		if (notNull(customerContactClass)
				|| notBlank(customerContactTypeStr)
				|| notBlank(customerContactComment)) {
			// Validate Parameter CUSTOMER_CONTACT_TYPE
			ccTypeId = new CustomerContactType_Id(customerContactClass, customerContactTypeStr);
			if(isNull(ccTypeId.getEntity())){
				addError(CustomMessageRepository.SA_286376_invalidCcClassTypeCombination(customerContactClass.getId().getTrimmedValue(),customerContactTypeStr));
			}
		}
		/* END ADD - JHERNA - 2020-07-20 - SysAid#340159 */
	}

	/**
	 * This method validates the SA Type
	 * @param saType
	 * @param parmDesc
	 * @return
	 */
	private String cmValidateSaType(String saType, String parmDesc) {

		String returnValue = " ";
		if (notBlank(saType)) {
			PreparedStatement prepState = createPreparedStatement(
					"SELECT 'X' "
							+ "FROM CI_SA_TYPE "
							+ "WHERE SA_TYPE_CD = '"+saType.trim()+"' ", 
							getClass().getName());
			
			prepState.setAutoclose(false); 
			prepState.execute();
			if (notNull(prepState.firstRow())) {
				returnValue = saType.trim();
			}	
			else {
				addError(CustomMessageRepository.SA_286376_invalidSatype(parmDesc, saType));
			}
			prepState.close();
		}
		return returnValue;		
	}

	public Class<CmMassAdjustmentGenerationBatchWorker> getThreadWorkerClass() {
		return CmMassAdjustmentGenerationBatchWorker.class;
	}

	public static class CmMassAdjustmentGenerationBatchWorker extends
	CmMassAdjustmentGenerationBatchWorker_Gen {

		// Soft Parameters
		private String filePath;
		private String fileName;
		@SuppressWarnings("unused")
		private BigInteger maxErrorsThreshold;
		private String saType;
		private AdjustmentType adjustmentType;
		private CustomerContactClass customerContactClass;
		private String customerContactTypeStr;
		private String excludeSaTypes;
		private String adjustmentComment;
		private String customerContactComment;
		/* START ADD - JHERNA - 2020-07-20 - SysAid#340159 */
		private Bool parmCreateSAIfAccountOnlyHaveStoppedSA;
		/* END ADD - JHERNA - 2020-07-20 - SysAid#340159 */
		  /*
	     * Start Add - Defect 4609833 - 2021-10-20
	     */
	    private Bool setAdjustmentArrearsDateSw;
	    /*
	     * End Add - Defect 4609833 - 2021-10-20
	     */
		
		// Work Variables
		private BigInteger numberOfRecordsInError = BigInteger.ZERO;
		private BufferedReader inputFile = null;
		private File inputFilePathAndName = null;
		private CustomerContactType_Id ccTypeId = null;
		private Account_Id accountId = null;
		private int totalFileRecordCount = 0;
		private int processedFileRecordsCount = 0;
		private BigDecimal totalAdjustmentAmount = BigDecimal.ZERO;
		private BigDecimal processedTotalAdjustmentAmount = BigDecimal.ZERO;
		private DecimalFormat formatter;
		private ServiceType_Id gasServiceType;
		
		// Constants
		private static final String COMMA_DELIMITER = ",";
		private static final String SINGLE_QUOTE = "'";
		private static final String GAS_SERVICE_TYPE = "G";
		private static final String SPACE = " ";
		private static final String ADJ = "Adjustment ID: ";
		private static final String AMOUNT = "Amount: ";
		private static final String SA = "Service Agreement ID: ";
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		public void initializeThreadWork(boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
			filePath = getParameters().getFILE_PATH();
			fileName = getParameters().getFILE_NAME();
			maxErrorsThreshold = getParameters().getMAX_ERRORS_THRESHOLD();
			saType = getParameters().getSA_TYPE();
			adjustmentType = getParameters().getADJUSTMENT_TYPE();
			customerContactClass = getParameters().getCUSTOMER_CONTACT_CLASS();
			customerContactTypeStr = getParameters().getCUSTOMER_CONTACT_TYPE();
			excludeSaTypes = getParameters().getEXCLUDE_SA_TYPES();
			adjustmentComment = getParameters().getADJUSTMENT_COMMENT();
			customerContactComment = getParameters().getCUSTOMER_CONTACT_COMMENT();
			/* START CHANGES - JHERNA - 2020-07-20 - SysAid#340159 */			
			//ccTypeId = new CustomerContactType_Id(customerContactClass, customerContactTypeStr);
			parmCreateSAIfAccountOnlyHaveStoppedSA = this.getParameters().getCREATE_NEW_SA_FOR_STOPPED_SA();
			if (notNull(customerContactClass)
					|| notBlank(customerContactTypeStr)
					|| notBlank(customerContactComment)) {
				ccTypeId = new CustomerContactType_Id(customerContactClass, customerContactTypeStr);
			}
			/* END CHANGES - JHERNA - 2020-07-20 - SysAid#340159 */
			 /*
		     * Start Add - Defect 4609833 - 2021-10-20
		     */
		    setAdjustmentArrearsDateSw = getParameters().getSET_ADJ_ARREARS_DT_SW();
		    /*
		     * End Add - Defect 4609833 - 2021-10-20
		     */
			openFile();
		}

		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			formatter = new DecimalFormat("###,###.##");
			
			processFile();
			
			// Log Total Number of Records Processed and Total Amount of Adjustment Processed
			logMessage(CustomMessageRepository.SA_286376_totalRecordNumberProcessed(
					processedFileRecordsCount, totalFileRecordCount), MessageSeverityLookup.constants.INFORMATIONAL);
			logMessage(CustomMessageRepository.SA_286376_totalAmountProcessed(
					formatter.format(processedTotalAdjustmentAmount), 
					formatter.format(totalAdjustmentAmount)), MessageSeverityLookup.constants.INFORMATIONAL);  
			
			// Set Batch Run Totals
			WorkUnitResult workUnitResult = new WorkUnitResult(true);
			workUnitResult.setUnitsProcessed(totalFileRecordCount);
			workUnitResult.setUnitsInError(numberOfRecordsInError.intValue());
			return workUnitResult;
		}

		private void processFile() {
			/* START CHANGES - JHERNA - 2020-07-20 - SysAid#340159 */
			/* throwing an error defeats the purpose of catching it.  */
			/*
			String fileRecord = null;

			fileRecord = readFileLine();
			while (notNull(fileRecord)){
				try {
					// Process the file record if and only if record length != 0
					if(fileRecord.length()!= 0) { 
						processRecord(fileRecord);
					}	
					// Read the next line						
					fileRecord = readFileLine();

				} catch (ApplicationError ae){
					numberOfRecordsInError  = numberOfRecordsInError.add(BigInteger.ONE);
					throw ae;										
				}
			}
			*/
			String recordLine = "";
			/* read the record line on the file until the end of file or a null record line */
			while (notNull(recordLine = readFileLine())) {
				try {
					/* process the account */
					processRecord(recordLine);
				}
				catch (ApplicationError ae) {
					/* add 1 to the number of erroneous record and then log the error message to the run tree. Proceed with the next record. */
					numberOfRecordsInError  = numberOfRecordsInError.add(BigInteger.ONE);
					logMessage(ae.getServerMessage(), MessageSeverityLookup.constants.ERROR);						
				}					
			}			
			/* END CHANGES - JHERNA - 2020-07-20 - SysAid#340159 */
		}
		
		/**
		 * This Method will process each Account Id present in the file.
		 * @param detailRecord
		 */
		private void processRecord(String detailRecord){
			// Retrieve account from file
			String accountStr = getFieldValue(detailRecord,0,10);
			accountId = new Account_Id(accountStr);
			// Retrieve amount from file
			String amountStr = getFieldValue(detailRecord,10,18);
			BigInteger tempAmount = new BigInteger(amountStr);
			BigDecimal amount = new BigDecimal(tempAmount, 2);
			totalAdjustmentAmount = totalAdjustmentAmount.add(amount);
			
			//If an account from file does not exists, log message
			if (isNull(accountId) || isNull(accountId.getEntity())) {
				//log message
				logMessage(CustomMessageRepository.SA_286376_accountIdNotFoundInFile(accountId.getIdValue().trim()), MessageSeverityLookup.constants.INFORMATIONAL);
			} else {
				/* Get SA linked to Account.
				 * Priority: Active, Pending Stopped, Stopped and Reactivated
				 */
				/* START CHANGES - JHERNA - 2020-07-20 - SysAid#340159 */
				/*
				ServiceAgreement_Id saId = getActiveSAs(accountId);
				Adjustment adjustment = null;
				
				if (notNull(saId)) {
					adjustment = createAdjustments(saId.getEntity(), amount);
					createCustomerContact(adjustment,amount,saId.getEntity());
				} else {
					ServiceAgreement newSa = newSa();
					adjustment = createAdjustments(newSa, amount);
					createCustomerContact(adjustment,amount,newSa);
				}
				*/
				Adjustment adjustment = null;
				/* Retrieve billable SAs of account */
				ServiceAgreement_Id activeBillableSAID = getActiveSA(accountId);
				
				if (notNull(activeBillableSAID)
						&& notNull(activeBillableSAID.getEntity())) {
					
					ServiceAgreement activeBillableSA = activeBillableSAID.getEntity();
					/* create adjustment for the billable SA */
					adjustment = createAdjustments(activeBillableSA, amount);
					if (notNull(adjustment)) {
						/* if customer contact parameters are provided, create customer contact */
						if (notNull(ccTypeId)
								&& notNull(ccTypeId.getEntity())) {							
							createCustomerContact(adjustment, amount, activeBillableSA);
						}
					}
				}
				/* *************************************************************************/
				/* If there are no active billable SA (active, pending stop, reactivated), */
				/* check if there is at least a Stopped SA for the account. If so, then    */				
				/* raise an error message on the batch run tree and skip processing account*/
				/* Otherwise, if there are no stopped SAs for the account. Create a new SA */
				/* using parameter 40 SA Type and create an adjustment for the new SA      */
				/* *************************************************************************/				
				else {
					ServiceAgreement_Id stoppedBillableSAID = getStoppedSA(accountId);
					if (parmCreateSAIfAccountOnlyHaveStoppedSA.isFalse()
							&& notNull(stoppedBillableSAID)
							&& notNull(stoppedBillableSAID.getEntity())) {						
						// log message on run tree (cannot create adjustment) and skip processing this record
						logMessage(CustomMessageRepositoryMGE.sa340159CantCreateSaForAccountWithOnlyStoppedSAs(
								accountStr.trim(), stoppedBillableSAID.getTrimmedValue()),
								MessageSeverityLookup.constants.WARNING);
						numberOfRecordsInError  = numberOfRecordsInError.add(BigInteger.ONE);
						totalFileRecordCount++;
						return;
					}
					else {
						Account account = accountId.getEntity();
						ServiceAgreement newSA = createNewSA(account, 
								new ServiceAgreementType_Id(account.getDivisionId(), saType.trim()),
								account.getMailingPremiseId());

						/* create adjustment for the new SA */
						adjustment = createAdjustments(newSA, amount);
						if (notNull(adjustment)) {
							/* if customer contact parameters are provided, create customer contact */
							if (notNull(ccTypeId)
									&& notNull(ccTypeId.getEntity())
									&& notNull(adjustment)) {							
								createCustomerContact(adjustment,amount,newSA);
							}
						}
					}
				}
				/* END CHANGES - JHERNA - 2020-07-20 - SysAid#340159 */
				
				processedFileRecordsCount++;
				processedTotalAdjustmentAmount = processedTotalAdjustmentAmount.add(amount);
			}
			
			totalFileRecordCount++;
		}
				
		/* START CHANGES - JHERNA - 2020-07-20 - SysAid#340159 */
		/*
		private ServiceAgreement_Id getActiveSAs(Account_Id acctId) {
			gasServiceType = new ServiceType_Id(GAS_SERVICE_TYPE);
			StringBuilder strBuilder = new StringBuilder();
			String exludedSaTypesStr = "";
			if (notBlank(excludeSaTypes)) {
				exludedSaTypesStr = createsStringForQuery(excludeSaTypes);
			}		
			
			strBuilder.append("FROM ServiceAgreement sa, ServiceAgreementType st ");
			strBuilder.append("WHERE sa.account = :accountId ");
			strBuilder.append(  "AND sa.status in (:active, :pendingStop, :stopped, :reactivated) ");
			strBuilder.append(  "AND sa.serviceAgreementType.id.division = :cisDivision ");
			strBuilder.append(  "AND sa.serviceAgreementType.id.division = st.id.division ");
			strBuilder.append(  "AND sa.serviceAgreementType.id.saType = st.id.saType ");
			strBuilder.append(  "AND st.serviceType.id = :gasServiceType ");
			if (notBlank(excludeSaTypes)) {
				strBuilder.append(  "AND st.id.saType not in (" + exludedSaTypesStr.trim() + ") ");
			}
			
			Query<QueryResultRow> query = createQuery(strBuilder.toString(), getClass().getName());
			query.bindId("accountId", acctId);
			query.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
			query.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
			query.bindLookup("stopped", ServiceAgreementStatusLookup.constants.PENDING_STOP);
			query.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
			query.bindId("cisDivision", acctId.getEntity().getDivisionId());
			query.bindId("gasServiceType", gasServiceType);

			query.addResult("id", "sa.id");
			query.addResult("status", "sa.status");

			query.orderBy("status", Query.ASCENDING);

			QueryResultRow firstRow = query.firstRow();

			if (isNull(firstRow)){
				return null;
			}

			ServiceAgreement_Id sa = (ServiceAgreement_Id) firstRow.getId("id", ServiceAgreement.class);
			return sa;
						
		}
		*/
		
		private ServiceAgreement_Id getActiveSA(Account_Id acctID) {
			
			ServiceAgreement_Id returnValue = null;			
			Account acct = acctID.getEntity();
			CisDivision_Id cisDivID = acct.getDivisionId();
			
			gasServiceType = new ServiceType_Id(GAS_SERVICE_TYPE);
			StringBuilder stringBuilder = new StringBuilder();
			String exludedSaTypesStr = "";
			if (notBlank(excludeSaTypes)) {
				exludedSaTypesStr = createsStringForQuery(excludeSaTypes);
			}	
			
			stringBuilder.append("SELECT SA.SA_ID ");
			stringBuilder.append("FROM CI_SA SA, CI_SA_TYPE SAT ");
			stringBuilder.append("WHERE SA.ACCT_ID = :accountID ");			
			stringBuilder.append("AND SA.SA_STATUS_FLG IN (:active, :pendingStop, :reactivated) ");
			stringBuilder.append("AND SA.CIS_DIVISION = :cisDivID ");
			stringBuilder.append("AND SAT.CIS_DIVISION = SA.CIS_DIVISION ");
			stringBuilder.append("AND SAT.SA_TYPE_CD = SA.SA_TYPE_CD ");
			if (notBlank(excludeSaTypes)) {
				stringBuilder.append("AND SAT.SA_TYPE_CD NOT IN ("+exludedSaTypesStr+") ");
			}			
			stringBuilder.append("AND SAT.SVC_TYPE_CD = :gasServiceType ");
			stringBuilder.append("ORDER BY SA_STATUS_FLG ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==getActiveSA==");
			prepState.setAutoclose(false);
			prepState.bindId("accountID", acctID);
			prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
			prepState.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
			prepState.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
			prepState.bindId("cisDivID", cisDivID);
			prepState.bindId("gasServiceType", gasServiceType);
			prepState.execute();			
			if (notNull(prepState.firstRow())) {
				SQLResultRow sqlRow = prepState.firstRow();
				returnValue = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);				
			}
			prepState.close();
			return returnValue;			
		}
		
		private ServiceAgreement_Id getStoppedSA(Account_Id acctID) {
			
			ServiceAgreement_Id returnValue = null;			
			Account acct = acctID.getEntity();
			CisDivision_Id cisDivID = acct.getDivisionId();
			
			gasServiceType = new ServiceType_Id(GAS_SERVICE_TYPE);
			StringBuilder stringBuilder = new StringBuilder();
			String exludedSaTypesStr = "";
			if (notBlank(excludeSaTypes)) {
				exludedSaTypesStr = createsStringForQuery(excludeSaTypes);
			}	
			
			stringBuilder.append("SELECT SA.SA_ID ");
			stringBuilder.append("FROM CI_SA SA, CI_SA_TYPE SAT ");
			stringBuilder.append("WHERE SA.ACCT_ID = :accountID ");			
			stringBuilder.append("AND SA.SA_STATUS_FLG = :stopped ");
			stringBuilder.append("AND SA.CIS_DIVISION = :cisDivID ");
			stringBuilder.append("AND SAT.CIS_DIVISION = SA.CIS_DIVISION ");
			stringBuilder.append("AND SAT.SA_TYPE_CD = SA.SA_TYPE_CD ");
			if (notBlank(excludeSaTypes)) {
				stringBuilder.append("AND SAT.SA_TYPE_CD NOT IN ("+exludedSaTypesStr+") ");
			}			
			stringBuilder.append("AND SAT.SVC_TYPE_CD = :gasServiceType ");
			stringBuilder.append("ORDER BY SA_STATUS_FLG ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==getStoppedSA==");
			prepState.setAutoclose(false);
			prepState.bindId("accountID", acctID);
			prepState.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
			prepState.bindId("cisDivID", cisDivID);
			prepState.bindId("gasServiceType", gasServiceType);
			prepState.execute();			
			if (notNull(prepState.firstRow())) {
				SQLResultRow sqlRow = prepState.firstRow();
				returnValue = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);				
			}
			prepState.close();
			return returnValue;			
		}

		/* END CHANGES - JHERNA - 2020-07-20 - SysAid#340159 */
		
		/**
		 * Create an Adjustment
		 * @param activeSa
		 * @param amount
		 */
		private Adjustment createAdjustments(ServiceAgreement activeSa, BigDecimal amount) {
			Money money = null;
			money = new Money(amount, activeSa.getCurrencyId());
			CreateFrozenAdjustmentData adjustmentData = CreateFrozenAdjustmentData.Factory.newInstance();

			adjustmentData.setServiceAgreement(activeSa);
			adjustmentData.setAdjustmentAmount(money);
			adjustmentData.setAdjustmentType(adjustmentType);
			adjustmentData.setAllowZeroAmount(Bool.FALSE);
			/*
			 * Start Change - Defect 4609833 - 2021-10-20
			 */
			//adjustmentData.setArrearsDate(getProcessDateTime().getDate());
			if (setAdjustmentArrearsDateSw.isTrue()) {
			    adjustmentData.setArrearsDate(getProcessDateTime().getDate());
			}
			/*
             * End Change - Defect 4609833 - 2021-10-20
             */
			
			CreateFrozenAdjustment createFrozenAdjustment = CreateFrozenAdjustment.Factory.newInstance();
			CreateFrozenAdjustmentData output = createFrozenAdjustment.createFrozenAdjustment(adjustmentData);
			
			Adjustment adjustment = output.getAdjustment();
			Adjustment_DTO adjustmentDTO = adjustment.getDTO();
			adjustmentDTO.setComments(adjustmentComment); 
			adjustment.setDTO(adjustmentDTO);
			
			return adjustment;
			
		}
		
		/**
		 * Create a Customer Contact
		 */
		private void createCustomerContact(Adjustment adjustment, BigDecimal amount, ServiceAgreement sa) {
			CustomerContact_DTO contactDto = new CustomerContact_DTO();
			contactDto.setCustomerContactTypeId(ccTypeId);
			contactDto.setPersonId(accountId.getEntity().getMainPerson().getId());
			contactDto.setContactDateTime(getProcessDateTime());
			contactDto.setUserId(getActiveContextUser().getId());
			contactDto.setLongDescription(customerContactComment.concat(SPACE).
					concat(ADJ).concat(adjustment.getId().getIdValue().concat(SPACE).
					concat(AMOUNT).concat(formatter.format(amount)).concat(SPACE).
					concat(SA).concat(sa.getId().getIdValue())));
			contactDto.newEntity();
		}
		
		/**
		 * Create a new SA
		 * @return sa
		 */
		/* START CHANGES - JHERNA - 2020-07-20 - SysAid#340159 */
		/*
		private ServiceAgreement newSa() {
			ServiceAgreementType_Id saTypeId = new ServiceAgreementType_Id(accountId.getEntity().fetchDivision(),saType);
			
			ServiceAgreement returnValue = null;
			ServiceAgreementCreatorData saCreatorData = ServiceAgreementCreatorData.Factory.newInstance();
			ServiceAgreementCreator saCreator = ServiceAgreementCreator.Factory.newInstance();
			ServiceAgreement_DTO saDTO = new ServiceAgreement_DTO();
			
			saDTO.setAccountId(accountId);
			saDTO.setServiceAgreementTypeId(saTypeId);
			saDTO.setStartDate(this.getProcessDateTime().getDate());
			saDTO.setCustomerRead(CustomerReadLookup.constants.NO);
			saDTO.setStatus(ServiceAgreementStatusLookup.constants.PENDING_START);
			saDTO.setAreEstimatesAllowed(saTypeId.getEntity().getAreEstimatesAllowed());
			saDTO.setStartReason(StartReasonLookup.constants.SYSTEM_GENERATED);
			saDTO.setPremiseId(accountId.getEntity().getMailingPremiseId());
			saCreatorData.setServiceAgreementDTO(saDTO);
			saCreatorData.setShouldOverrideSAStatus(Bool.FALSE);
			returnValue = saCreator.addServiceAgreement(saDTO, saCreatorData);
			
			return returnValue;
		}
		*/
		private ServiceAgreement createNewSA(Account acct,
				ServiceAgreementType_Id saTypeID,
				Premise_Id mailingPremID) {
			
			ServiceAgreement returnValue = null;
			
			ServiceAgreementCreatorData saCreatorData = ServiceAgreementCreatorData.Factory.newInstance();
			ServiceAgreementCreator saCreator = ServiceAgreementCreator.Factory.newInstance();
			ServiceAgreement_DTO saDTO = new ServiceAgreement_DTO();
			
			saDTO.setAccountId(acct.getId());
			saDTO.setServiceAgreementTypeId(saTypeID);
			saDTO.setStartDate(this.getProcessDateTime().getDate());
			saDTO.setCustomerRead(CustomerReadLookup.constants.NO);
			saDTO.setStatus(ServiceAgreementStatusLookup.constants.PENDING_START);
			saDTO.setAreEstimatesAllowed(saTypeID.getEntity().getAreEstimatesAllowed());
			saDTO.setStartReason(StartReasonLookup.constants.SYSTEM_GENERATED);
			saDTO.setPremiseId(mailingPremID);
			saCreatorData.setServiceAgreementDTO(saDTO);
			saCreatorData.setShouldOverrideSAStatus(Bool.FALSE);
			returnValue = saCreator.addServiceAgreement(saDTO, saCreatorData);
			
			return returnValue;			
		}
		/* END CHANGES - JHERNA - 2020-07-20 - SysAid#340159 */
		
		 /**
		  * This method retrieves the trimmed field value from the record starting 
		  * from the startPos and of the given length.
		  * @param record
		  * @param startPosition
		  * @param length
		  * @return
		  */
		 private String getFieldValue(String record, int startPosition, int endPosition) {

			 String value = null;
			 if(record.length() >= endPosition){
				 value = record.substring(startPosition,endPosition).trim();
			 }
			 return value;
		 }

		/**
		 * Open the file
		 */
		private void openFile(){
			inputFilePathAndName = new File(filePath, fileName);
			try {
				inputFile = new BufferedReader(new FileReader(inputFilePathAndName));  

			}
			catch (IOException e) {     
				throw new RunAbortedException(CustomMessageRepository.SA_286376_errorInFile(e.getMessage()));
			}
		}      

		/**
		 * Read the file
		 * @return
		 */
		private String readFileLine(){
			try {       
				return inputFile.readLine();
			}
			catch(IOException e) {
				throw new RunAbortedException(CustomMessageRepository.SA_286376_errorInFile(e.getMessage()));
			}
		}

		@Override
		public void finalizeThreadWork() 
				throws ThreadAbortedException, RunAbortedException {
			try {
				inputFile.close();
			} catch(IOException e) {
				throw new RunAbortedException(CustomMessageRepository.SA_286376_errorInFile(e.getMessage()));
			}  
		}
		

		/**
		 * This method builds the String for query.
		 * @param saTypesStr
		 * @return String
		 */
		private String createsStringForQuery(String saTypesStr) {
			StringTokenizer strTokenizer = new StringTokenizer(saTypesStr, COMMA_DELIMITER);
			StringBuilder strBuilder = new StringBuilder();

			while (strTokenizer.hasMoreElements()) {
				strBuilder.append(SINGLE_QUOTE);
				strBuilder.append(strTokenizer.nextToken().trim());
				strBuilder.append(SINGLE_QUOTE);

				if (strTokenizer.hasMoreTokens()) {
					strBuilder.append(COMMA_DELIMITER);
				}
			}

			return strBuilder.toString();
		}
		
	}

}
