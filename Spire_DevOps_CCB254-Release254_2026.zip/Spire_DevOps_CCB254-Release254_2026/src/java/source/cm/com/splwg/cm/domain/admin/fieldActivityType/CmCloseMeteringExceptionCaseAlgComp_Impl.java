/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Close Metering Exception Case
 * 
 * This algorithm will close any open Metering Exception Cases of the 
 * Service Point when the FA is completed.
 *            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-04-15   JPunza  NI0007.5 Initial Version.
 * 2013-05-03   JPunza  NI0007.5 - 7. Create To Do first before Transition 
 *                      Case Status. 
 * 2016-01-26   MPang	Updated for CCB v2.4 compilation.
 * 2016-09-14   SMiran  Defect 3508794. Interchanged case current status 
 * 						and next status.
 * 2020-10-23   JVitug  Defect 4504524. Updated to check completion of  
 *                      remove meter and install meter steps before 
 *                      transitioning case to next status.
 *************************************************************************/

package com.splwg.cm.domain.admin.fieldActivityType;

import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CaseLogTypeLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.FieldActivityStepTypeActionLookup;
//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseStatusTransitionRule_Id;
import com.splwg.ccb.domain.admin.caseType.CaseStatus_Id;
import com.splwg.ccb.domain.admin.dispatchGroup.DispatchGroup;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityTypeFaCompletionAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameter_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameter_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameters;
import com.splwg.ccb.domain.todo.toDoCase.CaseLog_DTO;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_Id;*/
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatusTransitionRule_Id;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus_Id;
import com.splwg.ccb.domain.admin.dispatchGroup.entity.DispatchGroup;
import com.splwg.ccb.domain.admin.fieldActivityType.algorithm.faCompletion.FieldActivityTypeFaCompletionAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityStep;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivitySteps;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameter_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameter_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameters;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_Id;
//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.cm.domain.customMessages.CustomMessagesMDC;

/**
 * @author jpunzalan2
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = spIdCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = caseType, name = meterExceptionCaseType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = newCaseStatus, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = dispatchGroup, name = dispatchGroup, type = entity)
 *            , @AlgorithmSoftParameter (entityName = toDoType, name = manualReviewToDoType, type = entity)})
 */
public class CmCloseMeteringExceptionCaseAlgComp_Impl 
        extends CmCloseMeteringExceptionCaseAlgComp_Gen 
        implements FieldActivityTypeFaCompletionAlgorithmSpot {
	
    // Hard Parameter
    private FieldActivity fieldActivity;
    
    public void setFieldActivity(FieldActivity arg0) {
        fieldActivity = arg0;
    }
    
    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        
        // New Case Status
        CaseStatus_Id caseStatusId = new CaseStatus_Id(getMeterExceptionCaseType(), getNewCaseStatus());
        if (isNull(caseStatusId.getEntity())) {
            addError(CustomMessageRepositoryMDC.NI0007_5_caseStatusInvalidForCaseType(
                    getAlgorithm().getId().getTrimmedValue(),
                    getNewCaseStatus(),
                    getMeterExceptionCaseType().getId().getTrimmedValue()));
        }
    }    

    public void invoke() {

        ServicePoint sp = fieldActivity.getServicePoint();
        
        //Start Add JVitug - Defect 4504524 - 2020-10-23
        //Check if the FA Type has a remove and install meter
        //If it has an install and / or remove meter step
        // If the SP/Mtr history field is blank, halt processing
       
        FieldActivitySteps faSteps = fieldActivity.getSteps();
        List<FieldActivityStep> installOrRemoveMeterSteps;

        ListFilter<FieldActivityStep> listFilterInstallOrRemoveMeterSteps = faSteps.
        		createFilter("where (this.faStepTypeAction = :installMeter "
        				+ "or this.faStepTypeAction = :removeMeter) ", getClass().getName());
        listFilterInstallOrRemoveMeterSteps.bindLookup("installMeter", FieldActivityStepTypeActionLookup.constants.INSTALL_METER);
        listFilterInstallOrRemoveMeterSteps.bindLookup("removeMeter", FieldActivityStepTypeActionLookup.constants.REMOVE_METER);
        installOrRemoveMeterSteps = listFilterInstallOrRemoveMeterSteps.list();
        
        //if the FA steps does not have any installation or removal meter read steps. Halt processing
        if(installOrRemoveMeterSteps.isEmpty()) {
        	return;
        }

        //Iterate through the install and remove meter steps. If one of these
        //steps has no SP/Meter History ID yet, halt processing
        Bool hasRemoveMeterStep = Bool.FALSE;
    	Bool hasInstallMeterStep = Bool.FALSE;
        for(FieldActivityStep step : installOrRemoveMeterSteps) {
        	
        	if(step.getFaStepTypeAction().isRemoveMeter()) {
        		hasRemoveMeterStep = Bool.TRUE;
        	} else if (step.getFaStepTypeAction().isInstallMeter()) {
        		hasInstallMeterStep = Bool.TRUE;
        	}
        	
        	if(isNull(step.getSpMeterHistoryId())) {
        		return;
        	} 
        }
        //If the FA has no remove Meter nor a Install Meter Step , halt processing
        if(hasRemoveMeterStep.isFalse() || hasInstallMeterStep.isFalse()) {
        	return;
        }
        //End Add JVitug - Defect 4504524 - 2020-10-23
        
        // Retrieve open Cases
        PreparedStatement getCases = createPreparedStatement("SELECT DISTINCT(CSCH.CASE_ID) " +
                "FROM CI_CASE_CHAR CSCH, CI_CASE CS " +
                "WHERE CSCH.CHAR_TYPE_CD = :charType " +
                "AND CSCH.SRCH_CHAR_VAL = :charValue " +
                "AND CS.CASE_ID = CSCH.CASE_ID " +
                "AND CS.CASE_TYPE_CD = :caseType " +
              //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
               // "AND CS.CASE_COND_FLG = :caseConditionFlag");
    			"AND CS.CASE_COND_FLG = :caseConditionFlag", getClass().getName());
        	  //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        
        getCases.bindEntity("charType", getSpIdCharacteristicType());
        getCases.bindStringProperty("charValue", 
                CaseCharacteristic.properties.searchCharacteristicValue, 
                sp.getId().getTrimmedValue());
        getCases.bindEntity("caseType", getMeterExceptionCaseType());
        getCases.bindLookup("caseConditionFlag", CaseConditionLookup.constants.OPEN);
        
        Iterator<SQLResultRow> iter = getCases.list().iterator();
        while (iter.hasNext()) {
            
            ToDoCase_Id toDoCaseId = (ToDoCase_Id) iter.next().getId("CASE_ID", ToDoCase.class);
            ToDoCase toDoCase = toDoCaseId.getEntity();
                                          
            CaseStatus caseStatus = toDoCase.getCaseStatus();                                    
            CaseStatus_Id newCaseStatusId = new CaseStatus_Id(caseStatus.fetchIdCaseType(), getNewCaseStatus());                 
            
            /*
             * Start Add - JPunza - NI0007.5 - 7
             */
            // Check other Field Activities
            checkOtherFieldActivities(sp, toDoCaseId.getTrimmedValue());
            /*
             * End Add - JPunza - NI0007.5 - 7
             */
            
            // Check if transition is valid
            // 2016-09-14. SMiran. Defect 3508794. Start Change
            //CaseStatusTransitionRule_Id caseStatusTransRoleId = new CaseStatusTransitionRule_Id(newCaseStatusId, caseStatus.fetchIdStatus());
            CaseStatusTransitionRule_Id caseStatusTransRoleId = new CaseStatusTransitionRule_Id(caseStatus, newCaseStatusId.getStatus());
            // 2016-09-14. SMiran. Defect 3508794. End Change
            if (isNull(caseStatusTransRoleId.getEntity())) {
                addError(CustomMessageRepositoryMDC.NI0007_5_unableToTransitionStatus(
                        caseStatus.fetchIdStatus().trim(),
                        getNewCaseStatus().trim(),
                        toDoCaseId.getTrimmedValue()));
            }
            
            // Transition Case Status
            toDoCase.autoTransitionCase(newCaseStatusId.getEntity(), null, Bool.TRUE);
            
            // Create Case Log
            createCaseLog(toDoCase);
            
            /*
             * Start Delete - JPunza - NI0007.5 - 7
             */
            //// Check other Field Activities
            //checkOtherFieldActivities(sp, toDoCaseId.getTrimmedValue());
            /*
             * End Delete - JPunza - NI0007.5 - 7
             */
        }
    }
    
    /**
     * This method creates Case Log.
     * @param toDoCase - To Do Case
     */
    private void createCaseLog(ToDoCase toDoCase) {
        
        // Create Case Log Entry
        CaseLog_DTO caseLogDto = new CaseLog_DTO();
        caseLogDto.setCaseStatusId(toDoCase.getCaseStatus().getId());
        caseLogDto.setLogType(CaseLogTypeLookup.constants.SYSTEM);
        
        // Set Message Id
        MessageCategory_Id messageCategoryId = new MessageCategory_Id(BigInteger.valueOf(CustomMessagesMDC.MESSAGE_CATEGORY));
        caseLogDto.setMessageId(new Message_Id(messageCategoryId, BigInteger.valueOf(CustomMessagesMDC.NI0007_5_CASE_COMPLETED_DUE_TO_FA)));
                
        // Get newly created Case Log
        CaseLog caseLog = toDoCase.getLogs().add(caseLogDto, null);                    

        CaseLogMessageParameters messageParms = caseLog.getMessageParameters();
        
        // Add message parameter for field activity
        CaseLogMessageParameter_DTO caseLogMsgParmDto = messageParms.newChildDTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.ONE));
        caseLogMsgParmDto.setMessageParameter(fieldActivity.getId().getTrimmedValue());        
        messageParms.add(caseLogMsgParmDto, BigInteger.ONE);              
    }
    
    /**
     * This method checks for other Field Activities.
     * @param sp - Service Point
     * @param toDoCaseStr - String
     */
    private void checkOtherFieldActivities(ServicePoint sp, String toDoCaseStr) {
        
        if (notNull(getManualReviewToDoType())) {
             
            DispatchGroup dispatchGrp = getDispatchGroup();
            
            // Check other Field Activities
            StringBuilder sb = new StringBuilder("SELECT COUNT(*) AS CNT " +
                    "FROM CI_FA FA " +
                    "WHERE FA.SP_ID = :sp " +
                    "AND FA.FA_STATUS_FLG NOT IN (:canceled,:completed) " +
                    "AND FA.FA_ID <> :fa ");
            
            if (notNull(dispatchGrp)) {
                sb.append("AND FA.DISP_GRP_CD = :dispatchGroup");
            }
            else {
                sb.append("AND FA.SCHED_DTTM > :dateTime");
            }
          //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
           // PreparedStatement checkOtherFieldActivities = createPreparedStatement(sb.toString());
            PreparedStatement checkOtherFieldActivities = createPreparedStatement(sb.toString(), getClass().getName());
          //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
            checkOtherFieldActivities.bindEntity("sp", sp);
            checkOtherFieldActivities.bindLookup("canceled", FieldActivityStatusLookup.constants.CANCELED);
            checkOtherFieldActivities.bindLookup("completed", FieldActivityStatusLookup.constants.COMPLETED);
            checkOtherFieldActivities.bindEntity("fa", fieldActivity);
            
            if (notNull(dispatchGrp)) {
                checkOtherFieldActivities.bindEntity("dispatchGroup", dispatchGrp);
            }
            else {
                checkOtherFieldActivities.bindDateTime("dateTime", getProcessDateTime());
            }
            
            BigInteger count = checkOtherFieldActivities.firstRow().getInteger("CNT");
            if (!count.equals(BigInteger.ZERO)) {
                createToDo(toDoCaseStr);
            }            
        }        
    }

    /**
     * This method creates To Do Entry.
     * @param toDoCaseStr - String
     */
    private void createToDo(String toDoCaseStr) {
        
        ToDoType toDoType = getManualReviewToDoType();
        
        ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
        ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();
                    
        toDoEntryDTO.setCreationDateTime(getProcessDateTime());
        toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
        toDoEntryDTO.setToDoTypeId(toDoType.getId());
                            
        toDoCreator.setToDoDTO(toDoEntryDTO);
        
        for (ToDoSortKeyType sortKeyType : toDoType.getSortKeyTypes()) {
            toDoCreator.addSortKeyValue(sortKeyType, toDoCaseStr);
        }
            
        for (ToDoDrillKeyType drillKeyType : toDoType.getDrillKeyTypes()) {
            toDoCreator.addDrillKeyValue(drillKeyType, toDoCaseStr);
        }    
        
        toDoCreator.create();
    } 
}
