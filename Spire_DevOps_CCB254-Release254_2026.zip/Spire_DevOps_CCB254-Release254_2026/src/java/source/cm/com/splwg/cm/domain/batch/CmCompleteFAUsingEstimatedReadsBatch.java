/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * CCB038.2 -This Batch Process executes the relevant Trend Area Estimation 
 * Algorithm to generate an estimate that can be used as a Start/Stop read 
 * for back-to-back service
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2021-05-07   JMeden        	CCB038.2 Initial Version.
 * 2021-06-22   BMarquez        CCB038.2.Issue1. Alter estimation call, add
 *                              conditions when checking if estimation
 *                              returned a read.
 * 2021-08-10	JMeden          CCB038.Issue5. Pass the process date time as
 *                              Read Date time for Estimate Meter Read 
 *                              algorithm
 * 2021-09-28   NMendo          Defect 4595558. Update proration logic.
 * 2021-10-01   DLampa          Defect 4595558. Issue 3. Update query that  
 *                              retrieves registers for estimation to  
 *                              filter those from configuration that are 
 *                              no longer valid.                                
 **************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.Query;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Time;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.algorithm.AlgorithmComponentCache;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.ccb.api.lookup.EstimateTypeLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.MeterOnOffStatusLookup;
import com.splwg.ccb.api.lookup.MeterReadRemarkStatusLookup;
import com.splwg.ccb.api.lookup.ReadTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementSpFaTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointFieldConditionLookup;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.meterReaderRemark.entity.MeterReaderRemark;
import com.splwg.ccb.domain.admin.trendArea.algorithm.meterReadEstimation.MeterReadEstimationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityStep;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityStep_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.ccb.domain.meterread.common.DifferenceBetweenRegisterReadsRetriever;
import com.splwg.ccb.domain.meterread.common.MeterReadCreator;
import com.splwg.ccb.domain.meterread.data.DifferenceBetweenRegisterReadsResults;
import com.splwg.ccb.domain.meterread.data.MeterReadCreatorData;
import com.splwg.ccb.domain.meterread.data.MeterReadCreatorRegisterReadData;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterReadRemark;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterReadRemark_DTO;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterReadRemark_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author OGC03758
 *
 *@BatchJob (modules={}, rerunnable = true, multiThreaded = true, 
 *      toDoCreation = @ToDoCreation (drillKeyEntity = fieldActivity,
 *            sortKeys = { "SCHED_DTTM"
 *                  , "CIS_DIVISION"
 *                  , "CHAR_VAL"
 *                  , "SP_COND_FLG"}),
 *      softParameters = { @BatchJobSoftParameter (entityName = fieldActivityType, name = ESTIMATE_FA_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = PRORATION_THRESHOLD_NO_OF_DAYS, required = true, type = integer)
 *            , @BatchJobSoftParameter (entityName = meterReaderRemark, name = MR_REM_CD, type = entity)
 *            , @BatchJobSoftParameter (lookupName = servicePointFieldCondition, name = SP_DESIRED_STATE_FOR_MR, required = true, type = lookup)})
 */
public class CmCompleteFAUsingEstimatedReadsBatch extends
		CmCompleteFAUsingEstimatedReadsBatch_Gen {
	
	//Constants
    /*
     * Start Delete - CCB038.2.Issue1 - 2021-06-22
     */
	//private static final String EST_TYPE_EST_AND_HI_LOW = "EST&HILOW";
	/*
     * End Delete - CCB038.2.Issue1 - 2021-06-22
     */
	private static final CharacteristicType_Id WORK_DISTRICT_CHAR_TYPE = new CharacteristicType_Id("CM-DSTCT");
	
	private static int totalMeterReadEstimates = 0;
	private static int totalFAScheduling = 0;
	private static int totalFASkippedOpenTodo = 0;
	
	@Override
	public void validateSoftParameters(boolean isNewRun) {
		// Number of Days must be a positive number
		if (getParameters().getPRORATION_THRESHOLD_NO_OF_DAYS().intValue() < 0){
			addError(CustomMessageRepositorySpireOne.CCB038_2_BatchParmValidationNoOfDays(getParameters().getPRORATION_THRESHOLD_NO_OF_DAYS().toString()));
		}
	}

	
	public JobWork getJobWork() {
		ArrayList<ThreadWorkUnit> workUnitList =  new ArrayList<ThreadWorkUnit>();
	   	StringBuilder sqlFa = new StringBuilder();
    	sqlFa.append(" FROM FieldActivity FA");
    	sqlFa.append(" WHERE FA.fieldActivityType = :faTypeCd ");
    	sqlFa.append(" AND FA.fieldActivityStatus = :pendingStatus ");
    	sqlFa.append(" AND FA.scheduleDateTimeStart <= :processDttm ");
    	
    	Query<FieldActivity> queryFa = createQuery(sqlFa.toString(), getClass().getName());
    	queryFa.bindEntity("faTypeCd", getParameters().getESTIMATE_FA_TYPE_CD());
    	queryFa.bindLookup("pendingStatus", FieldActivityStatusLookup.constants.PENDING);
    	queryFa.bindDate("processDttm", getProcessDateTime().getDate());
    	
    	for(FieldActivity fa: queryFa.list()){
            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId(fa.getId());
            workUnitList.add(workUnit);
    	}

        return createJobWorkForThreadWorkUnitList(workUnitList);
	}

	public Class<CmCompleteFAUsingEstimatedReadsBatchWorker> getThreadWorkerClass() {
		return CmCompleteFAUsingEstimatedReadsBatchWorker.class;
	}

	public static class CmCompleteFAUsingEstimatedReadsBatchWorker extends
			CmCompleteFAUsingEstimatedReadsBatchWorker_Gen {
		//Soft Parameters
		private FieldActivityType parmEstimateFaTypeCd;
		private BigInteger parmNumberOfDays;
		private MeterReaderRemark parmMeterReadRemarkCode;
		private ServicePointFieldConditionLookup parmSpDesiredStateForMR;
		
		//Other Variables
		FieldActivity_Id faId = null;
		
		/*
		 * Get all the value of Parameter and assign it to the Global Variables
		 */
		private void getBatchParameters(){
			parmEstimateFaTypeCd = getParameters().getESTIMATE_FA_TYPE_CD();
			parmNumberOfDays = getParameters().getPRORATION_THRESHOLD_NO_OF_DAYS();
			parmMeterReadRemarkCode = getParameters().getMR_REM_CD();
			parmSpDesiredStateForMR = getParameters().getSP_DESIRED_STATE_FOR_MR();
		}
		
		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
			getBatchParameters();
		}

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			SQLResultRow srrMeterAndStatus = null;
			ServicePoint sp = null;
			MeterOnOffStatusLookup meterOnOrOffStatus = null;
			
			MeterRead_Id billableMeterReadId = null;
			MeterConfiguration_Id meterConfigId = null;
			DateTime meterConfigInstallDateTime = null;
			Meter_Id meterId = null;
			ServiceAgreement sa = null;
			DateTime readDttm = null;
			
			// Get the primary Id (FieldActivity Id)
			faId = (FieldActivity_Id)unit.getPrimaryId();
			
			//Check if FA Schedule Date is not the same with Process Date Time and if FA has existing OPEN To Do Entry
			if(faId.getEntity().getScheduleDateTimeStart().getDate().isBefore(getProcessDateTime().getDate())){
				if(hasOpenToDoForFieldActivity(faId.getTrimmedValue()).isTrue()){
					totalFASkippedOpenTodo++;
					return true;
				}
			}
			
			//Check if SP's Determine Field Condition is not the same with Meter Read Remark Code parameter and if the SP's Source Status is Disconnected
			sp = faId.getEntity().getServicePoint();
			if(!parmSpDesiredStateForMR.equals(sp.determineFieldCondition())){
				if(sp.getServicePointSourceStatus().isDisconnected()){
					totalFAScheduling++;
					addError((CustomMessageRepositorySpireOne.CCB038_2_Disconnected(faId.getTrimmedValue(),sp.getPremise().fetchInformation())));
					
					return false;
				}
			}
			
			//Check if SP has no metered installed
			srrMeterAndStatus = getInstalledMeterFromSP(sp.getId(), faId.getEntity().getScheduleDateTimeStart().getDate());
			if(isNull(srrMeterAndStatus)){
				totalFAScheduling++;
				addError((CustomMessageRepositorySpireOne.CCB038_2_NoMeteredInstalled(faId.getTrimmedValue(),sp.getPremise().fetchInformation())));
				
				return false;
			}
			
			meterConfigId = (MeterConfiguration_Id) srrMeterAndStatus.getId("MTR_CONFIG_ID", MeterConfiguration.class);
			meterConfigInstallDateTime = srrMeterAndStatus.getDateTime("INSTALL_DTTM");
			meterId =  (Meter_Id) srrMeterAndStatus.getId("MTR_ID", Meter.class);
			meterOnOrOffStatus = srrMeterAndStatus.getLookup("MTR_ON_OFF_FLG", MeterOnOffStatusLookup.class);
			billableMeterReadId = (MeterRead_Id) srrMeterAndStatus.getId("MR_ID", MeterRead.class);
			// Start Change - JMeden - CCB038.Issue5 - 2021-08-10
			//readDttm = srrMeterAndStatus.getDateTime("READ_DTTM");
			readDttm = getProcessDateTime();
			// End Change - JMeden - CCB038.Issue5 - 2021-08-10
			sa = getSAFromFieldActivity(faId.getEntity());
			
			//Check if Meter has been turned off
			if(meterOnOrOffStatus.isOff()){
				totalFAScheduling++;
				addError((CustomMessageRepositorySpireOne.CCB038_2_TurnedOff(faId.getTrimmedValue(),sp.getPremise().fetchInformation())));
				return false;
			}
			
			//Check if billable Meter Read for the Meter exists for the FA scheduled date with Register Read Types higher than No Read (20)
			billableMeterReadId = getBillableMeterReadOnScheduleDate(faId.getEntity().getScheduleDateTimeStart().getDate(), meterConfigId);
			if(notNull(billableMeterReadId)){
				completeFa(billableMeterReadId);
				return true;
			}
			//If a billable Meter Read for the Meter exists for the FA scheduled date, plus or minus the PRORATION-THRESHOLD-NO-OF-DAYS with Register Read Types equal to or higher than Regular Read (60)
			billableMeterReadId = getBillableMeterReadBetweenScheduleDate(faId.getEntity().getScheduleDateTimeStart().getDate(), meterConfigId);
			if(notNull(billableMeterReadId)){
				billableMeterReadId = createProratedMeterRead(billableMeterReadId, meterConfigId, meterConfigInstallDateTime);
				if(notNull(billableMeterReadId)){
					completeFa(billableMeterReadId);
					return true;
				}
			}
			//Create the Estimated Meter Read
			try {
				// Call Estimation Algorithm
				billableMeterReadId = estimateMeterRead(meterId, readDttm, sp, sa, meterConfigId);
			} catch(Exception e) {
				// Raise error when estimation algorithm returns error
			    /*
                 * Start Change - CCB038.2.Issue1 - 2021-06-22
                 */
				//logError(CustomMessageRepositorySpireOne.CCB038_2_NoEstimation());
				addError(CustomMessageRepositorySpireOne.CCB038_2_NoEstimation());
				/*
                 * End Change - CCB038.2.Issue1 - 2021-06-22
                 */
				return false;
			}
			
			/*
             * Start Change - CCB038.2.Issue1 - 2021-06-22
             */
			if (isNull(billableMeterReadId)) {
	            // Raise error when estimation algorithm returns null
			    addError(CustomMessageRepositorySpireOne.CCB038_2_NoEstimation());
                return false;
			}
			/*
             * End Change - CCB038.2.Issue1 - 2021-06-22
             */
			
			// Add a meter read remark if the parameter is supplied
			if (notNull(parmMeterReadRemarkCode)){
				MeterReadRemark_Id meterReadRemarkId = new MeterReadRemark_Id(parmMeterReadRemarkCode.getId(),billableMeterReadId);
				MeterReadRemark_DTO mrRDto = createDTO(MeterReadRemark.class);
				mrRDto.setId(meterReadRemarkId);
				if (parmMeterReadRemarkCode.getIsEligibleForProcessing().isTrue()){
					mrRDto.setIsEligibleForProcessing(Bool.TRUE);
					mrRDto.setMeterReadRemarkStatus(MeterReadRemarkStatusLookup.constants.PENDING);
				}
				mrRDto.newEntity();
			}

			completeFa(billableMeterReadId);
			totalMeterReadEstimates++;
					
			return true; 
		}

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException,
				RunAbortedException {
			logInfo(CustomMessageRepositorySpireOne.CCB038_2_TotalMeterReadEstimate(totalMeterReadEstimates));
			logInfo(CustomMessageRepositorySpireOne.CCB038_2_TotalFAResched(totalFAScheduling));
			logInfo(CustomMessageRepositorySpireOne.CCB038_2_TotalFASkippedOpenTodo(totalFASkippedOpenTodo));
		}
		

		@Override
		public ToDoProperties createToDoProperties(ThreadWorkUnit unit) {

			FieldActivity_Id faId = (FieldActivity_Id)unit.getPrimaryId();
			ServiceAgreement sa = getSAFromFieldActivity(faId.getEntity());
			
			String strCisDiv = "";
			String strWorkingDisctrict = "";
			if (notNull(sa)){
				strCisDiv = sa.getAccount().getDivisionId().getIdValue();
			}
			

			PremiseCharacteristic premChar = faId.getEntity().getServicePoint().getPremise()
					.getEffectiveCharacteristic(WORK_DISTRICT_CHAR_TYPE.getEntity());
			
			if(notNull(premChar)){
				if(WORK_DISTRICT_CHAR_TYPE.getEntity().getCharacteristicType().isPredefinedValue()){
					strWorkingDisctrict = premChar.getCharacteristicValue();
				} else if(WORK_DISTRICT_CHAR_TYPE.getEntity().getCharacteristicType().isAdhocValue()){
					strWorkingDisctrict = premChar.getAdhocCharacteristicValue();
				} else {
					strWorkingDisctrict = premChar.getCharacteristicValueForeignKey1();
				}	
			}
			
			ToDoProperties toDoProperties = new ToDoProperties(faId);
			toDoProperties.setSCHED_DTTM(faId.getEntity().getScheduleDateTimeStart().toString());
			toDoProperties.setCIS_DIVISION(strCisDiv);
			toDoProperties.setCHAR_VAL(strWorkingDisctrict);
			toDoProperties.setSP_COND_FLG(faId.getEntity().getServicePoint().determineFieldCondition().getLookupValue().fetchIdFieldValue());
			return toDoProperties;
		}
		
		/**
		 * This method will determine if the Field Activity has 
		 * exsiting Open To Do Entry
		 * @param faId
		 * @return Bool
		 */
		private Bool hasOpenToDoForFieldActivity(String faId){
	    	StringBuilder sqlToDo = new StringBuilder();
	    	sqlToDo.append(" FROM ToDoEntry TD, ToDoDrillKeyValue TDD");
	    	sqlToDo.append(" WHERE TD.id = TDD.id.toDo.id ");
	    	sqlToDo.append(" AND TD.batchControlId = :batchControl ");
	    	sqlToDo.append(" AND TD.toDoType.id = :toDoType ");
	    	sqlToDo.append(" AND TDD.keyValue = :faId ");
	    	sqlToDo.append(" AND TD.toDoEntryStatus = :toDoStatus ");
	    	
	    	ToDoType_Id toDoTypeId = new ToDoType_Id(getBatchControlId().getTrimmedValue());
	    	Query<ToDoEntry> queryToDo = createQuery(sqlToDo.toString(), "");
	    	queryToDo.bindId("toDoType", toDoTypeId);
	    	queryToDo.bindStringProperty("faId", ToDoDrillKeyValue.properties.keyValue, faId);
	    	queryToDo.bindId("batchControl", getBatchControlId());
	    	queryToDo.bindLookup("toDoStatus", ToDoEntryStatusLookup.constants.OPEN);
	    	queryToDo.addResult("toDoEntry", "TD");
	    	
	    	if(notNull(queryToDo.firstRow())){
	    		return Bool.TRUE;
	    	} else {
	    		return Bool.FALSE;
	    	}
		}
		
		/**
		 * This method will get the Service Point Meter History Id
		 * for the installed Meter of SP.
		 * @param spId
		 * @return ServicePointMeterHistory
		 */
		private SQLResultRow getInstalledMeterFromSP(ServicePoint_Id spId, Date faScheduleDate){
			SQLResultRow row = null;
			StringBuilder meterConfigQueryStr = new StringBuilder();
			meterConfigQueryStr.append(" SELECT ");
			meterConfigQueryStr.append(   " VW.MTR_CONFIG_ID "); 
			meterConfigQueryStr.append(   " , VW.INSTALL_DTTM ");
			meterConfigQueryStr.append(   " , MC.MTR_ID ");
			meterConfigQueryStr.append(   " , SME.MTR_ON_OFF_FLG ");
			meterConfigQueryStr.append(   " , MR.MR_ID ");
			meterConfigQueryStr.append(   " , MR.READ_DTTM ");
			meterConfigQueryStr.append(" FROM "); 
			meterConfigQueryStr.append(    " CI_CFG_SPMR_VW VW, CI_MTR_CONFIG MC, CI_SP_MTR_EVT SME, CI_MR MR ");
			meterConfigQueryStr.append(" WHERE "); 
			meterConfigQueryStr.append(    " VW.SP_ID = :spId "); 
			meterConfigQueryStr.append(    " AND VW.INSTALL_DTTM = "); 
			meterConfigQueryStr.append(       " (SELECT MAX (CFG.INSTALL_DTTM) ");
			meterConfigQueryStr.append( 	  " FROM CI_CFG_SPMR_VW CFG "); 
			meterConfigQueryStr.append(  	  " WHERE CFG.SP_ID = :spId "); 
			meterConfigQueryStr.append(       " AND TRUNC(CFG.INSTALL_DTTM) <= :faScheduleDate) "); 
			meterConfigQueryStr.append(       " AND (VW.REMOVAL_DTTM IS NULL OR VW.REMOVAL_DTTM = "); 
			meterConfigQueryStr.append(       " (SELECT MIN (CFG.REMOVAL_DTTM) "); 
			meterConfigQueryStr.append(       " FROM CI_CFG_SPMR_VW CFG "); 
			meterConfigQueryStr.append(       " WHERE CFG.SP_ID = :spId "); 
			meterConfigQueryStr.append(       " AND TRUNC(CFG.REMOVAL_DTTM) > :faScheduleDate)) ");
			meterConfigQueryStr.append(    " AND MC.MTR_CONFIG_ID  = VW.MTR_CONFIG_ID "); 
			meterConfigQueryStr.append(    " AND SME.SP_MTR_HIST_ID = VW.SP_MTR_HIST_ID ");
			meterConfigQueryStr.append(    " AND SME.MR_ID = MR.MR_ID ");
			meterConfigQueryStr.append(    " ORDER BY MR.READ_DTTM DESC ");

			PreparedStatement meterConfigPrepStmt = createPreparedStatement(meterConfigQueryStr.toString(), getClass().getName());
			meterConfigPrepStmt.bindId("spId", spId);
			meterConfigPrepStmt.bindDate("faScheduleDate", faScheduleDate);
			
			row = meterConfigPrepStmt.firstRow();
			meterConfigPrepStmt.close();
			
			return row;
		}
		
		/**
		 * This method will get the Billable Meter Read based on the
		 * Field Activity Schedule Date and Meter Configuration Id
		 * @param faScheduleDate
		 * @param meterConfigId
		 * @return Meter Read Id
		 */
		private MeterRead_Id getBillableMeterReadOnScheduleDate(Date faScheduleDate, MeterConfiguration_Id meterConfigId) {
			// Return Meter Read Id
			MeterRead_Id meterReadId = null;
			
			StringBuilder billableMeterReadQueryStr = new StringBuilder();
			billableMeterReadQueryStr.append("  SELECT ");
			billableMeterReadQueryStr.append( 	" MR.MR_ID ");
			billableMeterReadQueryStr.append( " FROM "); 
			billableMeterReadQueryStr.append(   " CI_MR MR "); 
			billableMeterReadQueryStr.append( " WHERE ");
			billableMeterReadQueryStr.append(   " MR.MTR_CONFIG_ID = :meterConfigId "); 
			billableMeterReadQueryStr.append( 	" AND MR.USE_ON_BILL_SW = :useOnBillSw "); 
			billableMeterReadQueryStr.append( 	" AND MR.READ_DTTM = "); 
			billableMeterReadQueryStr.append( 	  " (SELECT MIN (READ_DTTM) "); 
			billableMeterReadQueryStr.append(      " FROM CI_MR MRV "); 
			billableMeterReadQueryStr.append(      " WHERE MRV.MTR_CONFIG_ID = :meterConfigId "); 
			billableMeterReadQueryStr.append(      " AND MRV.USE_ON_BILL_SW = :useOnBillSw "); 
			billableMeterReadQueryStr.append(      " AND TRUNC(MRV.READ_DTTM) = :faScheduleDate ");
			billableMeterReadQueryStr.append(      " AND EXISTS (SELECT 'X' "); 
			billableMeterReadQueryStr.append(                  " FROM CI_REG_READ RGRD "); 
			billableMeterReadQueryStr.append(                  " WHERE RGRD.MR_ID = MRV.MR_ID "); 
			billableMeterReadQueryStr.append(                  " AND RGRD.READ_TYPE_FLG > :noRead)) "); 
			
			PreparedStatement billableMeterReadPrepStmt = createPreparedStatement(billableMeterReadQueryStr.toString(), getClass().getName());
			billableMeterReadPrepStmt.bindId("meterConfigId", meterConfigId);
			billableMeterReadPrepStmt.bindBoolean("useOnBillSw", Bool.TRUE);
			billableMeterReadPrepStmt.bindDate("faScheduleDate", faScheduleDate);
			billableMeterReadPrepStmt.bindLookup("noRead", ReadTypeLookup.constants.NO_READ);
			
			SQLResultRow row = billableMeterReadPrepStmt.firstRow();
			if (notNull(row)){
				meterReadId = (MeterRead_Id)row.getId("MR_ID", MeterRead.class);
			}
			billableMeterReadPrepStmt.close();
			
			return meterReadId;
		}	
		
		/**
		 * This method will complete the Field Activity and update the other information that are linked to it.
		 * @param billableMeterReadId
		 */
		private void completeFa(MeterRead_Id billableMeterReadId) {
			// Update SA_SP with Meter Read. Get all start/stop SA_SP that is linked to this FA
			List<SQLResultRow> saSpFaList = getSaSpFa();
			Iterator<SQLResultRow> saSpFaListIter = saSpFaList.iterator();
			while (saSpFaListIter.hasNext()){
				SQLResultRow saSpFaRow = saSpFaListIter.next();
				// Get SA_SP_ID
				ServiceAgreementServicePoint_Id saSpId = (ServiceAgreementServicePoint_Id)saSpFaRow.getId("SA_SP_ID", ServiceAgreementServicePoint.class);
				// Get SA SP FA Type
				ServiceAgreementSpFaTypeLookup saSpFaType = saSpFaRow.getLookup("SA_SP_FA_TYPE_FLG", ServiceAgreementSpFaTypeLookup.class);
				// Update SA_SP
				ServiceAgreementServicePoint_DTO saSpDTO = saSpId.getEntity().getDTO();
				if (saSpFaType.isStartActivity()){
					saSpDTO.setStartMeterReadId(billableMeterReadId);
				}
				if (saSpFaType.isStopActivity()){
					saSpDTO.setStopMeterReadId(billableMeterReadId);
				}			
				saSpId.getEntity().setDTO(saSpDTO);
			}
			
			// Update FA Step
	        for (FieldActivityStep fieldActivityStep : faId.getEntity().getSteps()) {
	            if (fieldActivityStep.getFaStepTypeAction().isReadMeter()) {
	                FieldActivityStep_DTO faStepDTO = fieldActivityStep.getDTO();
	                faStepDTO.setMeterReadId(billableMeterReadId);
	                faStepDTO.setExtraTCopybookFieldValue("C1_T_FA_TYPE_CD", faId.getEntity().getFieldActivityType().getId().getTrimmedValue());
	                fieldActivityStep.setDTO(faStepDTO);
	                break;
	            }
	        }
			
			// Complete the FA
	        faId.getEntity().complete();
			
		}	
		
		/**
		 * This method will get the SA_SP_ID id of the Field Activity
		 * @return List<SQLResultRow>
		 */
		private List<SQLResultRow> getSaSpFa() {

			StringBuilder saSpFaQueryStr = new StringBuilder();
			saSpFaQueryStr.append(" SELECT ");
			saSpFaQueryStr.append(  " SASPFA.SA_SP_ID ");
			saSpFaQueryStr.append(  " , SASPFA.SA_SP_FA_TYPE_FLG ");
			saSpFaQueryStr.append(  " , SASP.SA_ID ");
			saSpFaQueryStr.append(  " , SASP.START_DTTM ");
			saSpFaQueryStr.append(" FROM CI_SA_SP_FA SASPFA, CI_SA_SP SASP, CI_FA FA ");
			saSpFaQueryStr.append(" WHERE SASPFA.FA_ID = :faId ");
			saSpFaQueryStr.append(" AND SASPFA.SA_SP_FA_TYPE_FLG = :saSpFaTypeFlag1 ");
			saSpFaQueryStr.append(" AND FA.FA_ID = SASPFA.FA_ID ");
			saSpFaQueryStr.append("	AND FA.FA_TYPE_CD = :faTypeCd ");
			saSpFaQueryStr.append("	AND SASP.SA_SP_ID = SASPFA.SA_SP_ID ");
			saSpFaQueryStr.append("	UNION SELECT SASPFA.SA_SP_ID ");
			saSpFaQueryStr.append(  " , SASPFA.SA_SP_FA_TYPE_FLG ");
			saSpFaQueryStr.append(  " , SASP.SA_ID ");
			saSpFaQueryStr.append(  " , SASP.STOP_DTTM ");
			saSpFaQueryStr.append(" FROM CI_SA_SP_FA SASPFA, CI_SA_SP SASP , CI_FA FA ");
			saSpFaQueryStr.append(" WHERE SASPFA.FA_ID = :faId ");
			saSpFaQueryStr.append(" AND SASPFA.SA_SP_FA_TYPE_FLG = :saSpFaTypeFlag2 ");
			saSpFaQueryStr.append(" AND FA.FA_ID = SASPFA.FA_ID ");
			saSpFaQueryStr.append("	AND FA.FA_TYPE_CD = :faTypeCd ");
			saSpFaQueryStr.append("	AND SASP.SA_SP_ID = SASPFA.SA_SP_ID ");
			saSpFaQueryStr.append("	ORDER BY 4 DESC ");

			PreparedStatement saSpFaPrepStmt = createPreparedStatement(saSpFaQueryStr.toString(), getClass().getName());

			saSpFaPrepStmt.bindId("faId", faId);
			saSpFaPrepStmt.bindId("faTypeCd", faId.getEntity().getFieldActivityType().getId());
			saSpFaPrepStmt.bindLookup("saSpFaTypeFlag1", ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
			saSpFaPrepStmt.bindLookup("saSpFaTypeFlag2", ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
			List<SQLResultRow> rowList = saSpFaPrepStmt.list();
			saSpFaPrepStmt.close();
			
			return rowList;
		}
		
		/**
		 * This method will get the Billable Meter Read based on the
		 * Field Activity Schedule Date and Meter Configuration Id
		 * @param faScheduleDate
		 * @param meterConfigId
		 * @return Meter Read Id
		 */
		private MeterRead_Id getBillableMeterReadBetweenScheduleDate(Date faScheduleDate, MeterConfiguration_Id meterConfigId) {
			// Return Meter Read Id
			MeterRead_Id meterReadId = null;
			//Date startReadDate = faScheduleDate.
			
			StringBuilder billableMeterReadQueryStr = new StringBuilder();
			billableMeterReadQueryStr.append(" SELECT MR.MR_ID, ABS(:faScheduledDate - MR.READ_DTTM) AS CLOSEST_DAY ");
			billableMeterReadQueryStr.append(" FROM CI_MR MR ");
			billableMeterReadQueryStr.append(" WHERE MR.MTR_CONFIG_ID = :meterConfigId ");
			billableMeterReadQueryStr.append(" AND MR.USE_ON_BILL_SW = :useOnBillSw ");
			billableMeterReadQueryStr.append(" AND MR.READ_DTTM BETWEEN :startReadDateTime AND :endReadDateTime ");
			billableMeterReadQueryStr.append(" AND EXISTS (SELECT 'X' "); 
			billableMeterReadQueryStr.append(            " FROM CI_REG_READ RGRD ");
			billableMeterReadQueryStr.append(            " WHERE RGRD.MR_ID = MR.MR_ID ");
			billableMeterReadQueryStr.append(            " AND RGRD.READ_TYPE_FLG >= :regular) ");
			billableMeterReadQueryStr.append(" ORDER BY CLOSEST_DAY ASC ");
			
			PreparedStatement billableMeterReadPrepStmt = createPreparedStatement(billableMeterReadQueryStr.toString(), getClass().getName());
			billableMeterReadPrepStmt.bindId("meterConfigId", meterConfigId);
			billableMeterReadPrepStmt.bindBoolean("useOnBillSw", Bool.TRUE);
			billableMeterReadPrepStmt.bindDateTime("startReadDateTime", new DateTime(faScheduleDate.addDays(-(parmNumberOfDays.intValue())),Time.MIN));
			billableMeterReadPrepStmt.bindDateTime("endReadDateTime",  new DateTime(faScheduleDate.addDays(parmNumberOfDays.intValue()),Time.MAX));
			billableMeterReadPrepStmt.bindDate("faScheduledDate",  faScheduleDate);
			
			billableMeterReadPrepStmt.bindLookup("regular", ReadTypeLookup.constants.REGULAR);
			
			SQLResultRow row = billableMeterReadPrepStmt.firstRow();
			if (notNull(row)){
				meterReadId = (MeterRead_Id)row.getId("MR_ID", MeterRead.class);
			}
			billableMeterReadPrepStmt.close();
			
			return meterReadId;
		}	
		
		/**
		 * This method will create a Prorated Meter read.
		 * @param billableMeterReadId
		 * @param meterConfigId
		 * @return MeterRead Id
		 */
		private MeterRead_Id createProratedMeterRead(MeterRead_Id billableMeterReadId, MeterConfiguration_Id meterConfigId, DateTime meterConfigInstallDateTime) {

			MeterRead_Id proratedMeterReadId = null;
			
			// Retrieve Previous Billable Meter Read
			MeterRead_Id previousMeterReadId = getPreviousMeterRead(meterConfigId, meterConfigInstallDateTime, billableMeterReadId);
			
			// If no previous read was found
			if (isNull(previousMeterReadId)){
				return null;
			}		
			
			// If number of registers between current and previous reads is not the same
			if (billableMeterReadId.getEntity().getRegisterReadList().size() 
					!= previousMeterReadId.getEntity().getRegisterReadList().size()){
				return null;
			}
			
			// Compute Number of Days from Previous read to FA Schedule Date Time
			int daysDiffPrevAndFA = (int)previousMeterReadId.getEntity().getReadDateTime().getDate()
					.difference(faId.getEntity().getScheduleDateTimeStart().getDate()).getDays();
			if (daysDiffPrevAndFA > 1){
				daysDiffPrevAndFA = daysDiffPrevAndFA - 1;
			}
			
			if(daysDiffPrevAndFA < 0){
				daysDiffPrevAndFA = daysDiffPrevAndFA * (-1);
			}
			
			// Compute Number of Days difference between previous and current reads
			int daysDiffPrevAndCurr = (int)previousMeterReadId.getEntity().getReadDateTime().getDate()
					.difference(billableMeterReadId.getEntity().getReadDateTime().getDate()).getDays();
			if (daysDiffPrevAndCurr > 1){
				daysDiffPrevAndCurr = daysDiffPrevAndCurr - 1;
			} else if(daysDiffPrevAndCurr < 0){
				daysDiffPrevAndCurr = daysDiffPrevAndCurr * -1;
			}
			
			// Prepare Register Read Collection
			List<MeterReadCreatorRegisterReadData> regReadDataList = new ArrayList<MeterReadCreatorRegisterReadData>();
			
			// Prorate each register read
			Iterator<RegisterRead> currReadIter = billableMeterReadId.getEntity().getRegisterReads().iterator();
			while (currReadIter.hasNext()){
				RegisterRead currRegRead = currReadIter.next();
				Iterator<RegisterRead> prevReadIter = previousMeterReadId.getEntity().getRegisterReads().iterator();
				while (prevReadIter.hasNext()){
					RegisterRead prevRegRead = prevReadIter.next();
					if (currRegRead.getRegister().getId().equals(prevRegRead.getRegister().getId())){
						if (prevRegRead.getRegisterReading().compareTo(currRegRead.getRegisterReading()) == 1){
							// Proration is not allowed if a rollover occurs
							// System Prorated meter read cannot be created. Field Activity (%1) is not complete
							logError(CustomMessageRepositorySpireOne.CCB038_2_ProratedMeterRead(faId.getTrimmedValue()));	
							return null;
	
						}
						// Compute usage
						DifferenceBetweenRegisterReadsRetriever diff = DifferenceBetweenRegisterReadsRetriever.Factory.newInstance();
						DifferenceBetweenRegisterReadsResults diffResult 
								= diff.retrieveDifferenceBetweenRegisterReads(
										currRegRead.getRegister()
										, prevRegRead.getRegisterReading()
										, currRegRead.getRegisterReading()
										, currRegRead.getRegister().getNumberOfDigitsLeft()
										, BigDecimal.ZERO);
						
						// Start Change - NMendo - Defect 4595558 - 2021-09-28
						//BigDecimal proratedUsage = null;
						//if(faId.getEntity().getScheduleDateTimeStart().getDate().isAfter(billableMeterReadId.getEntity().getReadDateTime().getDate())){
						//	proratedUsage = diffResult.getDifference().multiply(BigDecimal.valueOf(daysDiffPrevAndFA))
						//			.divide(BigDecimal.valueOf(daysDiffPrevAndCurr));
						//} else {
						//	proratedUsage = diffResult.getDifference().multiply(BigDecimal.valueOf(daysDiffPrevAndCurr))
						//			.divide(BigDecimal.valueOf(daysDiffPrevAndFA));
						//}
						
						// Prorated Read
						//BigDecimal proratedReading = currRegRead.getRegister().calculateEndRegisterRead(
						//		prevRegRead.getRegisterReading()
						//		, proratedUsage
						//		, currRegRead.getRegister().getRegisterConstant());
						
						BigDecimal proratedReading = BigDecimal.ZERO;
						if(daysDiffPrevAndCurr > 0) {
							// Prorated Usage = (Difference of reads * Nbr of days from Prev Read to FA Sched Date) / Nbr of days from Prev Read to Curr Read
							BigDecimal proratedUsage = diffResult.getDifference().multiply(BigDecimal.valueOf(daysDiffPrevAndFA))
									.divide(BigDecimal.valueOf(daysDiffPrevAndCurr));
							
							// Prorated Read
							proratedReading = currRegRead.getRegister().calculateEndRegisterRead(
									prevRegRead.getRegisterReading()
									, proratedUsage
									, currRegRead.getRegister().getRegisterConstant());
						} else {
							proratedReading = currRegRead.getRegisterReading();
						}
						// End Change - NMendo - Defect 4595558 - 2021-09-28
						
						// Store prorated read to local collection
						MeterReadCreatorRegisterReadData regReadData = MeterReadCreatorRegisterReadData.Factory.newInstance();
						regReadData.setIsHighLowReviewed(Bool.FALSE);
						regReadData.setReadType(ReadTypeLookup.constants.SYSTEM_PRORATE);
						regReadData.setReadSequence(currRegRead.getRegister().getSeq());
						regReadData.setRegisterReading(proratedReading);
						regReadDataList.add(regReadData);						
					}
				}
			}
			
			// Add prorated meter read
			MeterReadCreator mrCreator = MeterReadCreator.Factory.newInstance();
			MeterReadCreatorData mrCreatorData = MeterReadCreatorData.Factory.newInstance(); 
			mrCreatorData.setCanStoreEstimatedRead(Bool.FALSE);
			mrCreatorData.setCanUseOnBill(Bool.TRUE);
			mrCreatorData.setIsInstallationRead(Bool.FALSE);
			mrCreatorData.setIsTrended(Bool.FALSE);
			mrCreatorData.setReadDateTime(faId.getEntity().getScheduleDateTimeStart());
			mrCreatorData.setRegisterReadDataList(regReadDataList);
			MeterRead proratedRead = mrCreator.addMeterRead(meterConfigId.getEntity(), mrCreatorData);
			proratedMeterReadId = proratedRead.getId();
			
			// Add a meter read remark if the parameter is supplied
			if (notNull(parmMeterReadRemarkCode)){
				MeterReadRemark_Id meterReadRemarkId = new MeterReadRemark_Id(parmMeterReadRemarkCode.getId(),proratedMeterReadId);
				MeterReadRemark_DTO mrRDto = createDTO(MeterReadRemark.class);
				mrRDto.setId(meterReadRemarkId);
				if (parmMeterReadRemarkCode.getIsEligibleForProcessing().isTrue()){
					mrRDto.setIsEligibleForProcessing(Bool.TRUE);
					mrRDto.setMeterReadRemarkStatus(MeterReadRemarkStatusLookup.constants.PENDING);
				}
				mrRDto.newEntity();
			}
			
			return proratedMeterReadId;
		}
		
		/**
		 * This method will get the previous meter read.
		 * @param meterConfigId
		 * @param meterConfigInstallDateTime
		 * @return Meter Read Id
		 */
		private MeterRead_Id getPreviousMeterRead(MeterConfiguration_Id meterConfigId, DateTime meterConfigInstallDateTime, MeterRead_Id billableMeterReadId) {
			
			// Return Meter Read Id
			MeterRead_Id meterReadId = null;
			
			StringBuilder previousMeterReadQueryStr = new StringBuilder();
			previousMeterReadQueryStr.append(" SELECT ");
			previousMeterReadQueryStr.append(  " MR.MR_ID ");
			previousMeterReadQueryStr.append(" FROM ");
			previousMeterReadQueryStr.append(  " CI_MR MR ");
			previousMeterReadQueryStr.append(" WHERE ");
			previousMeterReadQueryStr.append(  " MR.MTR_CONFIG_ID = :meterConfigId ");
			previousMeterReadQueryStr.append(  " AND MR.USE_ON_BILL_SW = :useOnBillSw ");
			previousMeterReadQueryStr.append(  " AND MR.READ_DTTM = ");
			previousMeterReadQueryStr.append(     " (SELECT MAX (READ_DTTM) ");
			previousMeterReadQueryStr.append(     " FROM CI_MR MRV ");
			previousMeterReadQueryStr.append(     " WHERE MRV.MTR_CONFIG_ID = MR.MTR_CONFIG_ID ");
			previousMeterReadQueryStr.append(     " AND MRV.USE_ON_BILL_SW = :useOnBillSw ");
			previousMeterReadQueryStr.append(     " AND MRV.READ_DTTM BETWEEN :startReadDttm AND :endReadDttm ");
			previousMeterReadQueryStr.append(     " AND MRV.MR_ID <> :meterId ");
			previousMeterReadQueryStr.append(     " AND EXISTS ");
			previousMeterReadQueryStr.append(         " (SELECT 'X' ");
			previousMeterReadQueryStr.append(         " FROM CI_REG_READ RGRD ");
			previousMeterReadQueryStr.append(         " WHERE RGRD.MR_ID = MRV.MR_ID ");
			previousMeterReadQueryStr.append(         " AND RGRD.READ_TYPE_FLG IN (:verified, :regular, :customer)) ");
			previousMeterReadQueryStr.append(     " AND NOT EXISTS ");
			previousMeterReadQueryStr.append(         " (SELECT 'X' ");
			previousMeterReadQueryStr.append(         " FROM CI_REG_READ RGRD ");
			previousMeterReadQueryStr.append(         " WHERE RGRD.MR_ID = MRV.MR_ID ");
			previousMeterReadQueryStr.append(         " AND RGRD.READ_TYPE_FLG NOT IN (:verified, :regular, :customer)))");

			PreparedStatement previousMeterReadPrepStmt = createPreparedStatement(previousMeterReadQueryStr.toString(), getClass().getName());

			previousMeterReadPrepStmt.bindId("meterConfigId", meterConfigId);
			previousMeterReadPrepStmt.bindId("meterId", billableMeterReadId);
			
			previousMeterReadPrepStmt.bindBoolean("useOnBillSw", Bool.TRUE);
			// Meter Config Install Date Time and MIN Time
			previousMeterReadPrepStmt.bindDateTime("startReadDttm", new DateTime(meterConfigInstallDateTime.getDate(),Time.MIN));
			// FA Schedule Date and MAX Time
			previousMeterReadPrepStmt.bindDateTime("endReadDttm", new DateTime(faId.getEntity().getScheduleDateTimeStart().getDate(),Time.MAX));
			previousMeterReadPrepStmt.bindLookup("verified", ReadTypeLookup.constants.VERIFIED);
			previousMeterReadPrepStmt.bindLookup("regular", ReadTypeLookup.constants.REGULAR);
			previousMeterReadPrepStmt.bindLookup("customer", ReadTypeLookup.constants.CUSTOMER_READ);
			
			SQLResultRow row = previousMeterReadPrepStmt.firstRow();
			if (notNull(row)){
				meterReadId = (MeterRead_Id)row.getId("MR_ID", MeterRead.class);
			}
			previousMeterReadPrepStmt.close();
			return meterReadId;
		}
		
		/**
		 * Custom method which retrieves the Meter's Register 
		 * It is assumed that each meter would only have one register
		 * @param meter 
		 */
		// 2021-10-01 - D-4595558 - Start Change
		//private List<SQLResultRow> retrieveRegisters(Meter meter) {
		private List<SQLResultRow> retrieveRegisters(Meter meter, MeterConfiguration_Id meterConfigId) {
	    // 2021-10-01 - End Change

			// Assumption is that each meter will only have one register
	    	List<SQLResultRow> registers = null;
			StringBuilder sql = new StringBuilder();			
			sql.append("SELECT REG.REG_ID ");
			sql.append("FROM CI_REG REG ");
			sql.append("WHERE REG.MTR_ID = :meterID ");
			// 2021-10-01 - D-4595558 - Start Add
			sql.append("AND REG.EFF_DTTM >= :configEffectiveDttm ");
			// 2021-10-01 - D-4595558 - End Add			
			sql.append("AND REG.EFF_DTTM <= :effDttm ");
			sql.append("ORDER BY REG.EFF_DTTM DESC ");
	    	
			PreparedStatement prepState = createPreparedStatement(sql.toString(), getClass().getName());
			prepState.bindId("meterID", meter.getId());
			// 2021-10-01 - D-4595558 - Start Add
			prepState.bindDateTime("configEffectiveDttm", meterConfigId.getEntity().getEffectiveDateTime());
			// 2021-10-01 - D-4595558 - End Add			
			prepState.bindDateTime("effDttm", getSystemDateTime());
			
			registers = prepState.list();
			prepState.close();		
	
			return registers;
		}
		
		/**
		 * This method will get the Service Agreement 
		 * using the Field Activity
		 * @param fa
		 * @return Service Agreement
		 */
		private ServiceAgreement getSAFromFieldActivity(FieldActivity fa){
	    	ServiceAgreement sa = null;
			//Get Service Agreement using Service Point Id to retrieve the Account Id
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append(" FROM ServiceAgreementServicePoint SS, ServiceAgreement SA ");
			sqlQuery.append(" WHERE SS.servicePoint.id  = :spId ");
			sqlQuery.append(" AND SS.serviceAgreement.id  = SA.id ");
			sqlQuery.append(" AND SS.startDateTime <= :dttm ");
			sqlQuery.append(" AND (SS.stopDateTime is NULL OR SS.stopDateTime < :dttm) ");
			sqlQuery.append(" AND SA.status in (:active, :pendingStop) ");
			
			Query<ServiceAgreement> query = createQuery(sqlQuery.toString(), getClass().getName());
			
			query.bindId("spId", fa.getServicePoint().getId());
			query.bindDate("dttm", this.getProcessDateTime().getDate());
			query.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
			query.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
			
			query.addResult("sa", "SS.serviceAgreement");

			if(notNull(query.firstRow())){
				sa = query.firstRow();
			}
			
			return sa;
		}
		
		/**
		 * This method will call the Estimation Meter Read Algorithm.
		 * @param meterId
		 * @param readDttm
		 * @param sp
		 * @param sa
		 * @param meterConfigId
		 * @return Meter Read Id
		 */
		private MeterRead_Id estimateMeterRead(Meter_Id meterId, DateTime readDttm, ServicePoint sp, ServiceAgreement sa, MeterConfiguration_Id meterConfigId){
			List<SQLResultRow> srrRegisterList = null;
			// 2021-10-01 - Start Change
			//srrRegisterList = retrieveRegisters(meterId.getEntity());
			srrRegisterList = retrieveRegisters(meterId.getEntity(), meterConfigId);
			// 2021-10-01 - End Change
			BigDecimal registerReading = BigDecimal.ZERO;
			Register_Id regId = null;
			
			List<MeterReadCreatorRegisterReadData> meterReadCreatirReadReg = new ArrayList<MeterReadCreatorRegisterReadData>();
			MeterReadCreatorRegisterReadData mrCreatorRegRead = null;
			MeterReadCreatorData mrCreator = MeterReadCreatorData.Factory.newInstance();
	        mrCreator.setReadDateTime(readDttm);
	        
			if(notNull(srrRegisterList)){

				for (SQLResultRow srrRegister : srrRegisterList){
					regId = (Register_Id) srrRegister.getId("REG_ID", Register.class);
					MeterReadEstimationAlgorithmSpot estimateAlgoSpot = AlgorithmComponentCache.getAlgorithmComponent(
		    				sp.getPremise().getTrendArea().getMeterReadEstimationAlgorithm().getId(), MeterReadEstimationAlgorithmSpot.class);
					/*
                     * Start Change - CCB038.2.Issue1 - 2021-06-22
                     */
					//estimateAlgoSpot.setEstimationType(EST_TYPE_EST_AND_HI_LOW);
					estimateAlgoSpot.setEstimationType(EstimateTypeLookup.constants.ESTIMATE_AND_HIGH_LOW.toString());
		    		/*
                     * End Change - CCB038.2.Issue1 - 2021-06-22
                     */
		    		estimateAlgoSpot.setNumberOfReads(BigInteger.ONE);
		    		estimateAlgoSpot.setReadDateTime(readDttm);
		    		estimateAlgoSpot.setRegister(regId.getEntity());
		    		estimateAlgoSpot.setRegisterConstant(regId.getEntity().getRegisterConstant());
		    		estimateAlgoSpot.setServiceAgreement(sa);
		    		estimateAlgoSpot.setServicePoint(sp);
		    		estimateAlgoSpot.setTrendArea(sp.getPremise().getTrendArea());
		    		estimateAlgoSpot.setTrendClass(sp.getSpType().fetchTrendClass());
		    		estimateAlgoSpot.setConsumptionType(regId.getEntity().getConsumptionType());
		    		estimateAlgoSpot.setMeasuresPeakQuantity(regId.getEntity().getUnitOfMeasure().getMeasuresPeakQuantity());
		    		estimateAlgoSpot.setNumberOfDigitsLeft(regId.getEntity().getNumberOfDigitsLeft());
		    		estimateAlgoSpot.setNumberOfDigitsRight(regId.getEntity().getNumberOfDigitsRight());
		    		estimateAlgoSpot.setRegisterReading(registerReading.setScale(0));
		    		estimateAlgoSpot.setTimeOfUse(regId.getEntity().fetchTimeOfUse());
		    		estimateAlgoSpot.setUnitOfMeasure(regId.getEntity().getUnitOfMeasure());
		    		estimateAlgoSpot.invoke();
		    		
		    		/*
		    		 * Start Change - CCB038.2.Issue1 - 2021-06-22
		    		 */
		    		//if(estimateAlgoSpot.getIsEstimateImpossible().isTrue()) {

	    		    if(estimateAlgoSpot.getIsEstimateImpossible().isTrue() 
	    		            || isNull(estimateAlgoSpot.getEstimatedRegisterReading())) {
	    		    /*
                     * End Change - CCB038.2.Issue1 - 2021-06-22
                     */
		        		return null;
		        	}
		        	
		    		mrCreatorRegRead = MeterReadCreatorRegisterReadData.Factory.newInstance();
		            mrCreatorRegRead.setReadSequence(regId.getEntity().getSeq());
		            mrCreatorRegRead.setReadType(ReadTypeLookup.constants.SYSTEM_ESTIMATE);
		            mrCreatorRegRead.setRegisterReading(estimateAlgoSpot.getEstimatedRegisterReading());
		            meterReadCreatirReadReg.add(mrCreatorRegRead);
		    		
				}
				mrCreator.setRegisterReadDataList(meterReadCreatirReadReg);
			    mrCreator.setIsInstallationRead(Bool.FALSE);
			    mrCreator.setCanUseOnBill(Bool.TRUE);
			}
			return meterConfigId.getEntity().addMeterRead(mrCreator).getId();
		}
	}

}
