/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Advance Deposit Sa Creation Algorithm
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2022-04-28   Carlos Atilano  B21582 - This Algorithm will be used for automating the steps
 * 								 needed for advanced deposits. It will create and freeze some
 * 								 adjustments that will put the deposit amount into the Current
 * 								 Balance of the SA. This allows the payment to post properly. 
 * 								It will also create a Service Task which will allow the deposit
 * 							     quote to be picked up by the batch job CMEXPSSQ
 * 2023-04-06   EQuint			D-03376. Skip processing for certain users
 ******************************************************************************************/
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.saCreation;

import java.util.Arrays;

import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.security.user.User_Id;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType_Id;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saCreation.SaTypeSaCreationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.domain.constants.CustomConstantsRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;


/**
 * @author OGC04023
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = quoteSourceValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = adjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = customerContactClass, name = customerContactClass, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = customerContactType, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = excludeUserIds, type = string)})
 */
public class CmAdvanceDepositAlgComp_Impl extends CmAdvanceDepositAlgComp_Gen
		implements SaTypeSaCreationAlgorithmSpot {
	
	public static final String ST_CHAR_TYPE_ACCT = "CWRAC";
	public static final String ST_CHAR_TYPE_QTESRC = "QTESRC";
	public static final String BO_STATUS_CD_QUOTE= "QUOTE";
	public static final String ST_TYPE_QUOTE= "QUOTE";
	public static final String ST_CHAR_TYPE_CSS_DEP = "CSS-DEP";
	public static final String ST_BO_TYPE_CD = "CM-QUOTE";
	public static final String ST_CHAR_TYPE_DEPAMT = "CMDEPAMT";
	public Logger logger = LoggerFactory.getLogger(CmAdvanceDepositAlgComp_Impl.class);
	public Account acct;
	public Boolean verifySt = false;
	public ServiceAgreement sa;
	
	// start add -  EQuint - 2023-04-06 - D-03376
	String[] excludeUserIdArr;
	// end add -  EQuint - 2023-04-06 - D-03376

	@Override
	protected void extraSoftParameterValidations() {
		if(isNull(new CustomerContactType_Id(getCustomerContactClass(),getCustomerContactType()).getEntity())){
			addError(CustomMessageRepositorySpireOne.CCB018_6_ccTypeNotValidForCCClass(getCustomerContactType(), 
    				getCustomerContactClass().getId().getTrimmedValue()));
		}
		
		// start add -  EQuint - 2023-04-06 - D-03376
		String excludeUserIdsStr = getExcludeUserIds();
		if (notBlank(excludeUserIdsStr)) {
			excludeUserIdArr = excludeUserIdsStr.split("\\s*,\\s*");
			for (String userId: excludeUserIdArr) {
				if (isNull(new User_Id(userId).getEntity())) {
					// add error
					addError(CustomMessageRepositorySpireOne.S1_Ocfst_InvalidUserId(userId));
				}
			}
		}
		// end add -  EQuint - 2023-04-06 - D-03376
		
	}

	@Override
	public void invoke() {
		try{
			// start add -  EQuint - 2023-04-06 - D-03376
			if (notNull(excludeUserIdArr) && excludeUserIdArr.length > 0 && Arrays.asList(excludeUserIdArr).contains(getActiveContextUser().getId().getTrimmedValue())) {
				return;
			}
			// end add -  EQuint - 2023-04-06 - D-03376
			
			acct = sa.getAccount();
			//verify Service Task QTESRC for the same date
			if(verifyServiceTask(true,false, ST_CHAR_TYPE_QTESRC, null))
				return;
			//Verify Service Task with Quote Status regardless of the date
			if(verifyServiceTask(false ,true, ST_CHAR_TYPE_QTESRC,ST_CHAR_TYPE_CSS_DEP)){
				return;			
			}
			//Verify Service Task regardless of the status
			if(!verifyServiceTask(false ,false, ST_CHAR_TYPE_QTESRC,ST_CHAR_TYPE_CSS_DEP)){
				createServiceTask();		
			}
			createAdjustment();
			createCustomerContact();
		}catch(ApplicationError e){
			logger.info("Error in Advanced Deposit: "+e.getLocalizedMessage());
		}
		

	}

	@Override
	public void setServiceAgreement(ServiceAgreement arg0) {
		sa = arg0;

	}
	
	public Boolean verifyServiceTask(Boolean checkdate, Boolean checkStatus, String charType, String adhocCharVal){
		Boolean exists = false;
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT F1_SVC_TASK_ID FROM F1_SVC_TASK ST ");
		sql.append(" WHERE EXISTS (SELECT STC.F1_SVC_TASK_ID FROM  F1_SVC_TASK_CHAR STC ");
		sql.append(" 	WHERE STC.CHAR_TYPE_CD = :acctCharType ");
		sql.append(" 	AND STC.CHAR_VAL_FK1 = :acctId ");
		sql.append("	AND STC.F1_SVC_TASK_ID = ST.F1_SVC_TASK_ID)");
		sql.append(" AND EXISTS (SELECT STC.F1_SVC_TASK_ID FROM F1_SVC_TASK_CHAR STC ");
		sql.append(" 	WHERE STC.CHAR_TYPE_CD = :chtype ");
		if(!isBlankOrNull(adhocCharVal)){
			sql.append("	AND STC.ADHOC_CHAR_VAL = :adhocCharVal");
		}
		sql.append("	AND STC.F1_SVC_TASK_ID = ST.F1_SVC_TASK_ID) ");
		if(checkStatus){
			sql.append(" AND ST.BO_STATUS_CD = :quote ");
		}
		sql.append(" AND ST.F1_STASK_TYPE_CD = :taskType ");
		if(checkdate){
			sql.append(" AND TRUNC(ST.CRE_DTTM) = :date");
		}
		
		PreparedStatement ps = createPreparedStatement(sql.toString(), "verifyServiceTask");
		ps.bindEntity("acctCharType",new CharacteristicType_Id(ST_CHAR_TYPE_ACCT).getEntity());
		ps.bindEntity("chtype",new CharacteristicType_Id(charType).getEntity());
		ps.bindEntity("acctId", sa.getAccount());
		if(checkStatus){
			ps.bindStringProperty("quote", ServiceTask.properties.status,BO_STATUS_CD_QUOTE);
		}
		ps.bindEntity("taskType", new ServiceTaskType_Id(ST_TYPE_QUOTE).getEntity());
		if(checkdate){
			ps.bindDate("date", getProcessDateTime().getDate());
		}
		if(!isBlankOrNull(adhocCharVal)){
			ps.bindStringProperty("adhocCharVal", ServiceTaskCharacteristic.properties.adhocCharacteristicValue, adhocCharVal);
		}
		if(!isNull(ps.firstRow()))
				exists = true;
		ps.close();
		return exists;
	}
	
	public void createAdjustment(){
		//FrozenAdju
		CreateFrozenAdjustmentData adjData = CreateFrozenAdjustmentData.Factory.newInstance();
		adjData.setAdjustmentAmount(sa.getTotalAmountToBill());
		adjData.setAdjustmentDate(getProcessDateTime().getDate());
		adjData.setAdjustmentType(getAdjustmentType());
		adjData.setServiceAgreement(sa);
		adjData.setAllowZeroAmount(Bool.FALSE);
		sa.createFrozenAdjustment(adjData);
	}
	
	public void createCustomerContact(){	
		CustomerContact_DTO customerContactDTO = createDTO(CustomerContact.class);
		customerContactDTO
				.setCustomerContactTypeId(new CustomerContactType_Id(getCustomerContactClass(), getCustomerContactType()));
		customerContactDTO.setPersonId(sa.getAccount().getMainPerson().getId());
		customerContactDTO.setContactDateTime(getProcessDateTime());
		customerContactDTO.setPremiseId(sa.getPremiseId());
		customerContactDTO.setLongDescription(CustomMessageRepositorySpireOne.B21582_DepositQuote(sa.getTotalAmountToBill().getAmount().toString(), 
				sa.getPremiseId().getEntity().fetchInformation()).getMessageText());    
		CustomerContact cc = customerContactDTO.newEntity();
		CustomerContactCharacteristic_DTO ccCharDto = cc.getCharacteristics().newChildDTO();
		ccCharDto.setCharacteristicValueForeignKey1(sa.getPremiseId().getIdValue());
		cc.getCharacteristics().add(ccCharDto, new CharacteristicType_Id(CustomConstantsRepository.CHAR_TYPE_PREM));
		
	}
	
	private ServiceTask createServiceTask() {

		ServiceTask returnValue = null;

		BusinessObjectInstance boInstance =  BusinessObjectInstance.create(new BusinessObject_Id(ST_BO_TYPE_CD).getEntity());

		// Main fields for Quote Service Task
		boInstance.set("serviceTaskType", new ServiceTaskType_Id(ST_TYPE_QUOTE).getTrimmedValue());
		boInstance.set("businessObject", new BusinessObject_Id(ST_BO_TYPE_CD).getIdValue());
		boInstance.set("status", BO_STATUS_CD_QUOTE);
		boInstance.set("creationDateTime", getProcessDateTime());
		boInstance.set("statusDateTime", getProcessDateTime());
		boInstance.set("effectiveDateTime", getProcessDateTime());
		// Child fields for Quote Service Task Characteristic
		boInstance.set("saID", sa.getId().getTrimmedValue());
		boInstance.set("cisDiv", acct.getDivisionId().getIdValue());
		boInstance.set("debtClass", sa.getServiceAgreementType().getDebtClass().getId().getIdValue());
		boInstance.set("account", sa.getAccount().getId().getIdValue());

		boInstance.set("quoteSource", getQuoteSourceValue());
		boInstance.set("depositAmount", sa.getTotalAmountToBill().getAmount().toString());

		
		BusinessObjectInstance newQuoteBOInstance = BusinessObjectDispatcher.add(boInstance);
		String quoteIdStr = newQuoteBOInstance.getString("serviceTaskId");
		ServiceTask_Id quoteID = new ServiceTask_Id(quoteIdStr);
		returnValue = quoteID.getEntity();		
		return returnValue;
	
	}
	
	
}
