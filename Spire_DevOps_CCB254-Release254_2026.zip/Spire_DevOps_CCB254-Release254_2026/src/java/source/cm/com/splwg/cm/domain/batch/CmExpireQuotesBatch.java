/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * One Time Batch Program to expire all active quotes that have an expiration
 * which matches whatever is specified on the batch parameter.     
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2015-10-22	JHERNA	SF-58938. Initial Version.
 * 2016-01-28  	MPang	Updated for CCB v2.4 compilation.
 **************************************************************************/

package com.splwg.cm.domain.batch;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
//Start Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTask;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTask_Id;*/
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
//End Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation

/**
 * @author 90622
 *
 @BatchJob (modules = {}, rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (entityName = characteristicType, name = CHAR_TYPE_EXPIRE_DT, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = EXPIRE_DT, required = true, type = date)})
 */
public class CmExpireQuotesBatch extends CmExpireQuotesBatch_Gen {

	public JobWork getJobWork() {
		
		CharacteristicType charTypeExpireDate = this.getParameters().getCHAR_TYPE_EXPIRE_DT();
		Date expireDate = this.getParameters().getEXPIRE_DT();	
		String expDate = expireDate.toString(new DateFormat("yyyy-MM-dd"));
		
		StringBuilder stringBuilder = new StringBuilder();				
		stringBuilder.append("SELECT F1_SVC_TASK_ID ");
		stringBuilder.append("FROM F1_SVC_TASK STASK ");
		stringBuilder.append("WHERE STASK.BUS_OBJ_CD = 'CM-QUOTE' ");
		stringBuilder.append("AND STASK.BO_STATUS_CD = 'QUOTE' ");
		stringBuilder.append("AND STASK.F1_STASK_TYPE_CD = 'QUOTE' ");
		stringBuilder.append("AND EXISTS (SELECT 'X' ");
		stringBuilder.append("            FROM F1_SVC_TASK_CHAR STC ");
		stringBuilder.append("            WHERE STC.F1_SVC_TASK_ID = STASK.F1_SVC_TASK_ID ");
		stringBuilder.append("            AND STC.CHAR_TYPE_CD = :charType ");
		stringBuilder.append("            AND STC.SRCH_CHAR_VAL = :expDate ");
		stringBuilder.append(") ");
		//Start Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
		prepState.bindId("charType", charTypeExpireDate.getId());
		prepState.bindString("expDate", expDate.trim(), "SRCH_CHAR_VAL");
		QueryIterator queryIter = prepState.iterate();
		
		return createJobWorkForQueryIterator(queryIter, this);		
	}

	@Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow qrw) {
		
		ThreadWorkUnit twu = new ThreadWorkUnit();
		ServiceTask_Id serviceTaskID = (ServiceTask_Id) qrw.getId("F1_SVC_TASK_ID", ServiceTask.class); 
		twu.setPrimaryId(serviceTaskID);
		return twu;
	}

	public Class<CmExpireQuotesBatchWorker> getThreadWorkerClass() {
		return CmExpireQuotesBatchWorker.class;
	}

	public static class CmExpireQuotesBatchWorker extends
			CmExpireQuotesBatchWorker_Gen {

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {			
			
			// Retrieve quote to be updated
			ServiceTask_Id serviceTaskID = (ServiceTask_Id) unit.getPrimaryId();

			// Expire the quote
			cmUpdateQuoteStatus(serviceTaskID, "EXPIRED");
			
			return true;
		}
		/**
		 * Method which updates the service task's BO Status
		 * @param serviceTaskID the service task's id that needs to be updated
		 * @param newStatus the new status of the BO Status for the service task
		 */
		private void cmUpdateQuoteStatus(ServiceTask_Id serviceTaskID, String newStatus) {
			
			StringBuilder stringBuilder = new StringBuilder();			
			stringBuilder.append("UPDATE F1_SVC_TASK ");
			stringBuilder.append("SET BO_STATUS_CD = '"+newStatus.trim()+"' ");
			stringBuilder.append("WHERE F1_SVC_TASK_ID = :quoteID ");
			//Start Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("quoteID", serviceTaskID);
			prepState.execute();
			
			//Start Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement commit = createPreparedStatement("COMMIT");
			PreparedStatement commit = createPreparedStatement("COMMIT", getClass().getName());
			//End Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
			commit.execute();
			commit.close();
			
			prepState.close();						
			
		}
	}
}
