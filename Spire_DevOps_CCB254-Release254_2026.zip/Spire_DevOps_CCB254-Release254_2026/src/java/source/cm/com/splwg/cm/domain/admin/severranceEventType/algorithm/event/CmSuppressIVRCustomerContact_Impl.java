/**************************************************************************
* Program Name: CmSuppressIVRCustomerContact_Impl
* Program Title: CmSuppressIVRCustomerContact_Impl
* Author: Justine Roxas
* Creation Date: 2017-06-27
* Purpose: This algorithm will prevent the activation of a succeeding 
*          severance event (as defined by a parameter) by setting the
*          severance event status to 'Cancelled' before it is processed.
*  
* Functional Spec: SA-147283
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
 * ----------------------------------------------------------------------------------------------
 * SA-147283          Justine Roxas    2017-06-27    Initial Version
 ************************************************************************************************/
package com.splwg.cm.domain.admin.severranceEventType.algorithm.event;

import java.math.BigInteger;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.datatypes.Money;
import com.splwg.ccb.api.lookup.SeveranceEventStatusLookup;
import com.splwg.ccb.domain.admin.severanceEventType.algorithm.event.SeveranceEventTypeEventAlgorithmSpot;
import com.splwg.ccb.domain.admin.severanceEventType.entity.SeveranceEventType;
import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceEvent;
import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceEvent_DTO;
import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceProcess;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;

/**
 * @author JRoxas
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = amount, required = true, type = integer)
 *            , @AlgorithmSoftParameter (entityName = severanceEventType, name = severanceEventType, required = true, type = entity)})
 */
public class CmSuppressIVRCustomerContact_Impl extends
        CmSuppressIVRCustomerContact_Gen implements
        SeveranceEventTypeEventAlgorithmSpot {
    
    //Hard Parameters
    private ServiceAgreement sa;
    private SeveranceEvent severanceEvent;
    
    //Soft Parameters
    private BigInteger amountParm;
    private SeveranceEventType severanceEventType;
    
    @Override
    public void invoke() {
        
        SeveranceProcess severanceProcss = severanceEvent.fetchIdSeveranceProcess();
        Money arrearsAmt = severanceProcss.getArrearsAmount();
        Money amount = new Money(new BigDecimal(amountParm), sa.getAccount().getCurrency().getId());
        
        if (arrearsAmt.isLessThan(amount)) {
            
            ListFilter<SeveranceEvent> ivrSeveranceEventFilter =  severanceProcss.getSeveranceEvents().createFilter("WHERE this.severanceEventType = :ivrSevEvtType "
                    , getClass().getName());
            ivrSeveranceEventFilter.bindEntity("ivrSevEvtType", severanceEventType);
            SeveranceEvent ivrSeveranceEvent = ivrSeveranceEventFilter.firstRow();
            
            if (notNull(ivrSeveranceEvent)) {
                
                SeveranceEvent_DTO ivrSeveranceEvent_DTO =  ivrSeveranceEvent.getDTO();
                ivrSeveranceEvent_DTO.setSeveranceEventStatus(SeveranceEventStatusLookup.constants.CANCELED);
                ivrSeveranceEvent_DTO.setCompletionDate(getProcessDateTime().getDate());
                ivrSeveranceEvent.setDTO(ivrSeveranceEvent_DTO);
                
            }
        }
        
    }

    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        
        amountParm = getAmount();
        severanceEventType = getSeveranceEventType();
        
        super.extraSoftParameterValidations(forAlgorithmValidation);
    }

    @Override
    public void setServiceAgreement(ServiceAgreement arg0) {
        
        sa = arg0;
        
    }

    @Override
    public void setSeveranceEvent(SeveranceEvent arg0) {
        
        severanceEvent = arg0;
        
    }
    
}
