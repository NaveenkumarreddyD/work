/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Customer Data Record for Gulf Accounts for Regions Bank
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                                                                
 * 2021-05-26  JVitug      CCB031.3.  Initial Version                                                              
 *******************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

/**
 * @author JVitug
 */
public class CmGulfCustomerDataRecordForRegionsBank extends ColumnDelimitedRecord{
    
    //Constants
	private static final String EMPTY_STRING = "";
	
    public CmGulfCustomerDataRecordForRegionsBank() {
        super(1);
    }
    
    public void setAccount(String account) {
        this.rightPadColumn(1, 10, formatString(account , 10));
    }
    
    /**
     * Returns "" if text is null;
     * Truncates text if length exceed fieldLength;
     * @param text String variable to be formatted
     * @param fieldLength Length of Field
     * @return formatted text
     */
    private String formatString(String text, int fieldLength) {
        if(text == null) {
            text = EMPTY_STRING;
        }
        else {
            text = text.trim();
            if(text.length() > fieldLength) {
                text = text.substring(0, fieldLength);
            }
        }
        return text;
    }

}
