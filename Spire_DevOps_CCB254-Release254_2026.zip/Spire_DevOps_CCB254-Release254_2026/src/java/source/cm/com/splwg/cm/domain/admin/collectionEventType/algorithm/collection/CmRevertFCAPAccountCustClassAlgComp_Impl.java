/*
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                     
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * This algorithm would revert an FCAP Account's Customer Class 
 * and mark bills as in-eligible for late fees
 * 
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:       by:          Reason:
 * YYYY-MM-DD  FLName
 * 2018-09-20  JHERNA		SysAid#245408 Initial Version.
 * 
 ***********************************************************************
 */
package com.splwg.cm.domain.admin.collectionEventType.algorithm.collection;

import java.util.Iterator;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.admin.budgetPlan.entity.BudgetPlan;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.collectionClass.entity.CollectionClass;
import com.splwg.ccb.domain.admin.collectionEventType.algorithm.collection.CollectionEventAlgorithmSpot;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClassControl;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClassControl_Id;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.Bill_DTO;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.creditcollections.collectionProcess.entity.CreditAndCollectionEvent;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = charTypeAccountOldCustClass, required = true, type = entity)})
 */
public class CmRevertFCAPAccountCustClassAlgComp_Impl
		extends CmRevertFCAPAccountCustClassAlgComp_Gen 
		implements CollectionEventAlgorithmSpot {

	/*Hard Parameter*/
	private Account hpAccount;
	@SuppressWarnings("unused")
	private Bool hpAddWorkDays;
	@SuppressWarnings("unused")
	private CreditAndCollectionEvent hpCredAndCollEvt;	
	
	/*Soft Parameter*/
	private CharacteristicType parmCharTypeOldCustClass;	

	/*Work Variables*/
	private String wAlgorithmCode;
	
	@Override
	public void setAccount(Account arg0) {
		 hpAccount = arg0;
	}

	@Override
	public void setAddWorkDays(Bool arg0) {
		hpAddWorkDays = arg0;
	}

	@Override
	public void setCreditAndCollectionEvent(CreditAndCollectionEvent arg0) {
		hpCredAndCollEvt = arg0;
	}

	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		// Algorithm Code
		wAlgorithmCode = this.getAlgorithmId().getTrimmedValue();
		// Retrieve Parameter 10: Characteristic Type for Account Old Customer Class
		parmCharTypeOldCustClass = this.getCharTypeAccountOldCustClass();
		CharacteristicEntity_Id charEntityID = new CharacteristicEntity_Id(parmCharTypeOldCustClass, CharacteristicEntityLookup.constants.ACCOUNT);
		if (isNull(charEntityID.getEntity())) {
		    // Algorithm %1's parameter '%2%3' value (%4) is not a valid char type for %5%6 entity
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharTypeNotValidForEntity(wAlgorithmCode, 
					"Characteristic Type for Old Customer Class",
					parmCharTypeOldCustClass.getId().getTrimmedValue(),
					"Account"));
		}
	}

	@Override
	public void invoke() {

		/*retrieve the account's old customer class*/
		AccountCharacteristic acctChar = hpAccount.getEffectiveCharacteristic(parmCharTypeOldCustClass);
		if (notNull(acctChar)) {
			String oldCustCharStr = " ";
			CharacteristicTypeLookup valueType = parmCharTypeOldCustClass.getCharacteristicType();
			if (valueType.isForeignKeyValue()) {
				oldCustCharStr = acctChar.getCharacteristicValueForeignKey1().trim();
			}
			else if (valueType.isPredefinedValue()) {
				oldCustCharStr = acctChar.getCharacteristicValue().trim();
			}
			else {
				oldCustCharStr = acctChar.getAdhocCharacteristicValue().trim();
			}
			
			if (notBlank(oldCustCharStr)) {
				CustomerClass_Id customerClassID = new CustomerClass_Id(oldCustCharStr.trim());
				if (isNull(customerClassID.getEntity())) {
				    // Account %1 old customer class (%2) is not a valid customer class on the system.
					addError(CustomMessageRepositoryMGE.sa245408Lip7OldCustClassInvalid(hpAccount.getId().getTrimmedValue(), oldCustCharStr.trim()));
				}
				// revert the account's customer class, default collection class, default budget plan.
				CisDivision cisDivision = hpAccount.fetchDivision();				
				CustomerClass customerClass = customerClassID.getEntity();
				CollectionClass collectionClass = customerClass.fetchCollectionClass();
				CustomerClassControl_Id custClassCtrlID = new CustomerClassControl_Id(customerClass, cisDivision);
				if (isNull(custClassCtrlID.getEntity())) {					
				    // Customer Class Control not available for the combination of the customer class %1 and cis division %2
					addError(CustomMessageRepositoryMGE.sa245408Lip7CustClassControlInvalidForCisDivision(oldCustCharStr.trim(), cisDivision.getId().getTrimmedValue()));
				}
				CustomerClassControl custClassCtrl = custClassCtrlID.getEntity();
				BudgetPlan defaultBudgetPlan = custClassCtrl.fetchDefaultBudgetPlan();
												
				Account_DTO acctDTO = hpAccount.getDTO();
				acctDTO.setCustomerClassId(customerClass.getId());
				acctDTO.setCollectionClassId(collectionClass.getId());				
				if (notNull(defaultBudgetPlan)) {
					acctDTO.setBudgetPlanId(defaultBudgetPlan.getId());
				}
				hpAccount.setDTO(acctDTO);		
			}
			else {
				// Account %1 does not have previous customer class used prior to enrolling on FCAP (source: account characteristic).
				addError(CustomMessageRepositoryMGE.sa245408Lip7OldCustomerClassMissing(hpAccount.getId().getTrimmedValue()));				
			}
		}
		else {
			// Account %1 does not have previous customer class used prior to enrolling on FCAP (source: account characteristic).
			addError(CustomMessageRepositoryMGE.sa245408Lip7OldCustomerClassMissing(hpAccount.getId().getTrimmedValue()));
		}
		
		/*Retrieve all bills for the account that have not yet been processed by the LATEPAY Batch Process and switched their LPC Switch to N*/
		Iterator<SQLResultRow> collOfBillsEligibleForLPC = cmGetBillsEligibleForLPC(hpAccount.getId());
		while (collOfBillsEligibleForLPC.hasNext()) {
			SQLResultRow sqlRow = (SQLResultRow) collOfBillsEligibleForLPC.next();
			Bill_Id billID = (Bill_Id) sqlRow.getId("BILL_ID", Bill.class);
			Bill bill = billID.getEntity();
			Bill_DTO billDTO = bill.getDTO();
			billDTO.setIsLatePaymentCharge(Bool.FALSE);
			bill.setDTO(billDTO);
		}
	}
	
	private Iterator<SQLResultRow> cmGetBillsEligibleForLPC(Account_Id acctID) {
				
		StringBuilder stringBuilder = new StringBuilder();				
		stringBuilder.append("SELECT BILL_ID ");
		stringBuilder.append("FROM CI_BILL "); 
		stringBuilder.append("WHERE ACCT_ID = :acctID ");
		stringBuilder.append("AND LATE_PAY_CHARGE_SW = :lpcSw ");
		stringBuilder.append("AND LATE_PAY_CHARGE_DT <= :procDate ");
		stringBuilder.append(" ");

		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), 
				"==CmReverFCAPAccountCustClassAlgComp_Impl - Retrieve Bills Eligible for LPC==");
		prepState.bindId("acctID", acctID);
		prepState.bindBoolean("lpcSw", Bool.TRUE);
		prepState.bindDate("procDate", this.getProcessDateTime().getDate());
		prepState.setAutoclose(false);
		prepState.execute();
		Iterator<SQLResultRow> returnValue = prepState.list().iterator();
		prepState.close();
		return returnValue;
	}
}
