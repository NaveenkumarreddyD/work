/**************************************************************************
* Program Name: CmPostWriteOffFinanciallyResponsibleUpdatesBatch
* Program Title: CmPostWriteOffFinanciallyResponsibleUpdatesBatch
* Author: LBallo
* Creation Date: 2017-07-10 
* Purpose: This batch process will update the custom table CM_WO_XFERS
* 	Account Persons based on the current Account Persons data in CI_ACCR_PER
* Functional Spec: SA-68623.4
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:         Date:         Description:
 * ----------------------------------------------------------------------------------------------
 * SA-68623.4         Louis Ballon    2017-07-10    Initial Version
 * CCB25.4 Upgrade    EQuint          2025-11-14        
 ************************************************************************************************/

package com.splwg.cm.domain.batch;

import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.cm.domain.creditcollections.writeOffProcess.CmWriteOffTransfer;
import com.splwg.cm.domain.creditcollections.writeOffProcess.CmWriteOffTransfer_DTO;
import com.splwg.cm.domain.creditcollections.writeOffProcess.CmWriteOffTransfer_Id;


/**
 * @author LBallo
 *
 * @BatchJob (multiThreaded = true, rerunnable = false, modules = {})
 */
public class CmPostWriteOffFinanciallyResponsibleUpdatesBatch extends
		CmPostWriteOffFinanciallyResponsibleUpdatesBatch_Gen {

	@Override
	public JobWork getJobWork() {
		
		StringBuilder mainQueryStr = new StringBuilder();
		List<ThreadWorkUnit> threadWorkUnits = new ArrayList<ThreadWorkUnit>();
		
		mainQueryStr.append("SELECT ");
		mainQueryStr.append(  "A.WO_SA_ID, ");
		mainQueryStr.append(  "A.WO_ACCT_ID, ");
		mainQueryStr.append(  "A.MAIN_PER_ID ");
		mainQueryStr.append("FROM ");
		mainQueryStr.append(  "CM_WO_XFERS A ");
		
		PreparedStatement mainQuery = createPreparedStatement(mainQueryStr.toString(), getClass().getName());
		ThreadWorkUnit threadWorkUnit;
		
		for(SQLResultRow row : mainQuery.list()) {
			threadWorkUnit = new ThreadWorkUnit();
			threadWorkUnit.setPrimaryId(row.getId("WO_SA_ID", CmWriteOffTransfer.class));
			threadWorkUnit.addSupplementalData("WO_ACCT_ID", row.getString("WO_ACCT_ID"));
			threadWorkUnit.addSupplementalData("MAIN_PER_ID", row.getString("MAIN_PER_ID"));
			threadWorkUnits.add(threadWorkUnit);
		}
		
		return createJobWorkForThreadWorkUnitList(threadWorkUnits);
	}
	
	@Override
	public Class<CmPostWriteOffFinanciallyResponsibleUpdatesBatchWorker> getThreadWorkerClass() {
		return CmPostWriteOffFinanciallyResponsibleUpdatesBatchWorker.class;
	}
	
	public static class CmPostWriteOffFinanciallyResponsibleUpdatesBatchWorker extends
					CmPostWriteOffFinanciallyResponsibleUpdatesBatchWorker_Gen {

		@Override
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}
		
		@Override
		protected boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			CmWriteOffTransfer_Id writeOFfTransferIdFromTable = (CmWriteOffTransfer_Id) unit.getPrimaryId();
			String accountIdStrFromCmWoXferTable = (String) unit.getSupplementallData("WO_ACCT_ID");
			String mainPersonStrFromCmWoXferTable = (String) unit.getSupplementallData("MAIN_PER_ID");
			
			Account_Id accountIdFromCmWoXferTable = new Account_Id(accountIdStrFromCmWoXferTable);
			
			if(notNull(accountIdFromCmWoXferTable.getEntity())) {
				Account account = accountIdFromCmWoXferTable.getEntity();
				Person_Id mainPersonIdFromAccount = account.getMainPerson().getId();
				Person_Id mainPersonIdFromCmWoXferTable = new Person_Id(mainPersonStrFromCmWoXferTable);
				
				if(!mainPersonIdFromAccount.equals(mainPersonIdFromCmWoXferTable)) {
					updateMainPersonQuery(writeOFfTransferIdFromTable,mainPersonIdFromAccount);
				}

				updateFRPersonsToNull(writeOFfTransferIdFromTable);
				
				ListFilter<AccountPerson> financiallyResponsiblePersons = account.getPersons()
						.createFilter("where " +
									    "this.isFinanciallyResponsible = 'Y' " +
									    "and this.isMainCustomer = 'N' ", getClass().getName());
				populateFRPersonsInCmWoXfers(financiallyResponsiblePersons.list(), writeOFfTransferIdFromTable);
			}
			
			return true;
		}
		
		private void updateMainPersonQuery(CmWriteOffTransfer_Id writeOFfTransferIdFromTable,Person_Id mainPersonIdFromAccount) {
			
			CmWriteOffTransfer writeOffTransfer = writeOFfTransferIdFromTable.getEntity();
			
			CmWriteOffTransfer_DTO writeOffTransferDto = writeOffTransfer.getDTO();
			
			// start update - equint - 2025-11-14 - CCB25.4 Upgrade
			// writeOffTransferDto.setMainPersonId(mainPersonIdFromAccount.getTrimmedValue());
			writeOffTransferDto.setMainPerson(mainPersonIdFromAccount.getTrimmedValue());
			// end update - equint - 2025-11-14 - CCB25.4 Upgrade
			
			writeOffTransfer.setDTO(writeOffTransferDto);
		}
		
		private void updateFRPersonsToNull(CmWriteOffTransfer_Id writeOFfTransferIdFromTable) {
			CmWriteOffTransfer writeOffTransfer = writeOFfTransferIdFromTable.getEntity();
			
			CmWriteOffTransfer_DTO writeOffTransferDto = writeOffTransfer.getDTO();
			
			writeOffTransferDto.setCmFinanciallyRespPer1(null);
			writeOffTransferDto.setCmFinanciallyRespPer2(null);
			writeOffTransferDto.setCmFinanciallyRespPer3(null);
			writeOffTransferDto.setCmFinanciallyRespPer4(null);
			writeOffTransferDto.setCmFinanciallyRespPer5(null);
			
			writeOffTransfer.setDTO(writeOffTransferDto);
		}
		
		private void populateFRPersonsInCmWoXfers(List<AccountPerson> financiallyResponsiblePersons, CmWriteOffTransfer_Id writeOFfTransferIdFromTable) {
			CmWriteOffTransfer writeOffTransfer = writeOFfTransferIdFromTable.getEntity();
			
			CmWriteOffTransfer_DTO writeOffTransferDto = writeOffTransfer.getDTO();
			
			if(financiallyResponsiblePersons.size() >= 1) {
				writeOffTransferDto.setCmFinanciallyRespPer1(financiallyResponsiblePersons.get(0).fetchIdPerson().getId().getTrimmedValue());
			} 
			if(financiallyResponsiblePersons.size() >= 2) {
				writeOffTransferDto.setCmFinanciallyRespPer2(financiallyResponsiblePersons.get(1).fetchIdPerson().getId().getTrimmedValue());
			} 
			if(financiallyResponsiblePersons.size() >= 3) {
				writeOffTransferDto.setCmFinanciallyRespPer3(financiallyResponsiblePersons.get(2).fetchIdPerson().getId().getTrimmedValue());
			} 
			if(financiallyResponsiblePersons.size() >= 4) {
				writeOffTransferDto.setCmFinanciallyRespPer4(financiallyResponsiblePersons.get(3).fetchIdPerson().getId().getTrimmedValue());
			} 
			if(financiallyResponsiblePersons.size() >= 5) {
				writeOffTransferDto.setCmFinanciallyRespPer5(financiallyResponsiblePersons.get(4).fetchIdPerson().getId().getTrimmedValue());
			}
			
			writeOffTransfer.setDTO(writeOffTransferDto);
		}
		
	}
	
}
