/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Dollar Help Billing Adjustment
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2012-10-23   Arun          NA0039. Initial Version.
 * 2012-10-29   Arun          NA0039. Review Comments Incorporated.
 * 2013-02015   Srikanth   	  TIR - Invalid Currency Symbol -Bill Message Correction
 * 2016-01-26   MPang		  Updated for CCB v2.4 compilation. 
 ******************************************************************************************/

package com.splwg.cm.domain.admin.saType;

import java.math.BigInteger;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.api.lookup.PaymentStatusLookup;
//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.billCompletion.SaTypeBillCompletionAlgorithmSpot;
import  com.splwg.ccb.domain.billing.data.BillData;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage;
import com.splwg.ccb.domain.billing.bill.entity.BillMessageParameter_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation

/**
 * 
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentType, name = adjType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = billMessage, type = entity)})
 */

public class CmDollarHelpArrearsAdjAlgComp_Impl 
		extends CmDollarHelpArrearsAdjAlgComp_Gen 
		implements SaTypeBillCompletionAlgorithmSpot {

    private ServiceAgreement saId;
    private BillData billData;
    private Bool isFtProcessAdded = Bool.FALSE;
    private Bool isFtTransferred = Bool.FALSE;
    private Bool isMultiRelExists = Bool.FALSE;
    
    

    public Bool getAllowBillReopening() {
        return billData.getBillDTO().getIsReopenAllowed();
    }

    public BillData getBillData() {
        return billData;
    }

    public Bool getDoMultipleBillingRelationshipsExist() {
    	return isMultiRelExists;
    }

    public Bool getIsFtProcessAdded() {
        return isFtProcessAdded;
    }

    public Bool getIsFtTransferred() {
        return isFtTransferred;
    }

    public void setAccountingDate(Date arg0) {
    }

    public void setBillData(BillData billData) {
        this.billData=billData;
    }

    public void setBillDate(Date billDt) {
    	
    }

    public void setServiceAgreement(ServiceAgreement sa) {
        saId = sa;
    }

    public void invoke() {
        Money currBillAmt;
        Money currUnBilledAdjAmt;
        Money previousCurrBalance;
        currBillAmt = getCurrentAmount(saId);
        currUnBilledAdjAmt = retreiveCurrentUnbilledAmt(saId);
        if(notNull(currUnBilledAdjAmt))
            previousCurrBalance = currBillAmt.add(currUnBilledAdjAmt);
        else
            previousCurrBalance = currBillAmt;
        BillMessageType billMessage=getBillMessage();
        if(previousCurrBalance.compareTo(Money.ZERO) == 0 ){
            return;
        }

        CreateFrozenAdjustmentData frozenAdjData = CreateFrozenAdjustmentData.Factory.newInstance();
        frozenAdjData.setServiceAgreement(saId);
        frozenAdjData.setAdjustmentType(getAdjType());
        frozenAdjData.setAdjustmentAmount(previousCurrBalance.negate());
        frozenAdjData.setAllowZeroAmount(Bool.FALSE);
        CreateFrozenAdjustment frozenAdjustment =  CreateFrozenAdjustment.Factory.newInstance();
        frozenAdjustment.createFrozenAdjustment(frozenAdjData);

        if(notNull(billMessage))
        {
            Bill_DTO billDTO = billData.getBillDTO();
            startChanges();
            BillMessage_DTO billMsgDTO =  billDTO.getEntity().getMessages().newChildDTO();
            BillMessage_Id billMsgId = new BillMessage_Id(billMessage.getId(),billDTO.getId());
            billMsgDTO.setId(billMsgId);
            billMsgDTO.setVersion(1);
            BillMessage billMsg = billMsgDTO.newEntity();
            BillMessageParameter_DTO billMsgParmDTO = billMsg.getParameters().newChildDTO();
            billMsgParmDTO.setMessageParameterValue(previousCurrBalance.toLocalizedString(saId.fetchCurrency()));
            billMsgParmDTO.setVersion(1);
            billMsg.getParameters().add(billMsgParmDTO,BigInteger.ONE);
            billDTO.getId().getEntity().getMessages().add(billMsg);
            saveChanges();

        }
    }

    private Money retreiveCurrentBillAmt(ServiceAgreement saId){
        Money currentBillAmt = null;
        StringBuilder currentBillAmtQueryString = new StringBuilder();
        currentBillAmtQueryString.append("SELECT SUM(CUR_AMT)CURAMNT FROM CI_FT FT  ");
        currentBillAmtQueryString.append("WHERE FT.SA_ID = :saId ");
        currentBillAmtQueryString.append("AND FT.FREEZE_SW = :yes ");
        currentBillAmtQueryString.append("AND FT.REDUNDANT_SW = :no ");
        currentBillAmtQueryString.append("AND FT.FT_TYPE_FLG IN (:adjustment,:billSegment) ");
        currentBillAmtQueryString.append("AND NOT EXISTS (SELECT 'X' FROM CI_FT FTC WHERE FT.SIBLING_ID=FTC.SIBLING_ID  ");
        currentBillAmtQueryString.append("AND FTC.SA_ID= :saId AND FTC.FT_TYPE_FLG IN (:adjCancel,:billCancel)) ");
        currentBillAmtQueryString.append("AND FT.BILL_ID != ' ' ");
        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement currentBillAmtPrepStmt = createPreparedStatement(currentBillAmtQueryString.toString()); 
        PreparedStatement currentBillAmtPrepStmt = createPreparedStatement(currentBillAmtQueryString.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        currentBillAmtPrepStmt.bindId("saId", saId.getId());
        currentBillAmtPrepStmt.bindBoolean("yes", Bool.TRUE);
        currentBillAmtPrepStmt.bindBoolean("no", Bool.FALSE);
        currentBillAmtPrepStmt.bindLookup("adjustment", FinancialTransactionTypeLookup.constants.ADJUSTMENT);
        currentBillAmtPrepStmt.bindLookup("billSegment", FinancialTransactionTypeLookup.constants.BILL_SEGMENT);
        currentBillAmtPrepStmt.bindLookup("adjCancel", FinancialTransactionTypeLookup.constants.ADJUSTMENT_CANCELLATION);
        currentBillAmtPrepStmt.bindLookup("billCancel", FinancialTransactionTypeLookup.constants.BILL_CANCELLATION);
        currentBillAmt = currentBillAmtPrepStmt.firstRow().getMoney("CURAMNT");
        currentBillAmtPrepStmt.close();
        if(isNull(currentBillAmt))
            return Money.ZERO;
        else
            return currentBillAmt;
    }
    private Money retreivePaymentAmt(ServiceAgreement saId){
        Money paySegmentAmt = null;
        StringBuilder paySegmentAmtQueryString = new StringBuilder();
        paySegmentAmtQueryString.append("SELECT SUM(PAYSEG.PAY_SEG_AMT)PAYAMNT FROM CI_PAY_SEG PAYSEG,CI_PAY PAY ");
        paySegmentAmtQueryString.append("WHERE PAYSEG.SA_ID = :saId ");
        paySegmentAmtQueryString.append("AND PAYSEG.PAY_ID=PAY.PAY_ID ");
        paySegmentAmtQueryString.append("AND PAY.PAY_STATUS_FLG= :frozen ");
        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement paySegmentAmtPrepStmt = createPreparedStatement(paySegmentAmtQueryString.toString()); 
        PreparedStatement paySegmentAmtPrepStmt = createPreparedStatement(paySegmentAmtQueryString.toString(), getClass().getName()); 
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        paySegmentAmtPrepStmt.bindId("saId", saId.getId());
        paySegmentAmtPrepStmt.bindLookup("frozen", PaymentStatusLookup.constants.FROZEN);
        paySegmentAmt = paySegmentAmtPrepStmt.firstRow().getMoney("PAYAMNT");
        paySegmentAmtPrepStmt.close();
        if(isNull(paySegmentAmt))
            return Money.ZERO;
        else
            return paySegmentAmt;
    }
    private Money retreiveCurrentUnbilledAmt(ServiceAgreement saId){
        Money currentBalAmt = null;
        StringBuilder currentBillAmtQueryString = new StringBuilder();
        currentBillAmtQueryString.append("SELECT SUM(CUR_AMT)CURAMNT FROM CI_FT FT  ");
        currentBillAmtQueryString.append("WHERE FT.SA_ID = :saId ");
        currentBillAmtQueryString.append("AND FT.FREEZE_SW = :yes ");
        currentBillAmtQueryString.append("AND FT.REDUNDANT_SW = :no ");
        currentBillAmtQueryString.append("AND FT.FT_TYPE_FLG IN (:adjustment) ");
        currentBillAmtQueryString.append("AND NOT EXISTS (SELECT 'X' FROM CI_FT FTC WHERE FT.SIBLING_ID=FTC.SIBLING_ID  ");
        currentBillAmtQueryString.append("AND FTC.SA_ID= :saId AND FTC.FT_TYPE_FLG IN (:adjCancel)) ");
        currentBillAmtQueryString.append("AND FT.BILL_ID = ' ' ");
        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement currentBillAmtPrepStmt = createPreparedStatement(currentBillAmtQueryString.toString()); 
        PreparedStatement currentBillAmtPrepStmt = createPreparedStatement(currentBillAmtQueryString.toString(), getClass().getName()); 
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        currentBillAmtPrepStmt.bindId("saId", saId.getId());
        currentBillAmtPrepStmt.bindBoolean("yes", Bool.TRUE);
        currentBillAmtPrepStmt.bindBoolean("no", Bool.FALSE);
        currentBillAmtPrepStmt.bindLookup("adjustment", FinancialTransactionTypeLookup.constants.ADJUSTMENT);
        currentBillAmtPrepStmt.bindLookup("adjCancel", FinancialTransactionTypeLookup.constants.ADJUSTMENT_CANCELLATION);
        currentBalAmt = currentBillAmtPrepStmt.firstRow().getMoney("CURAMNT");
        currentBillAmtPrepStmt.close();

        if(isNull(currentBalAmt))
            return Money.ZERO;
        else
            return currentBalAmt;
    }

    private Money getCurrentAmount(ServiceAgreement sa){
        Money curBillAmnt = retreiveCurrentBillAmt(sa);
        Money curPayAmnt = retreivePaymentAmt(sa);
        Money diffAmt= curBillAmnt.subtract(curPayAmnt);
        return diffAmt;

    }
}
