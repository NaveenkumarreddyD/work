/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Voiding File Batch Extract - ACH Batch
 * Control Record
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2021-06-01   GCrisp     Initial version. CCB041.3 ACH File Batch Record
 * 2021-12-14   JLumbre    Mercury#47156. Updated format of debit and credit 
 * 							amounts fields.
 *
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmCheckVoidingExtractACHBatchControlRecord extends ColumnDelimitedRecord{
	
	/*
	 * Constructor
	 */
	public CmCheckVoidingExtractACHBatchControlRecord() {
		super(11);
	}

	public void setRecordTypeCode(String value) {
		rightPadColumn(1, 1, value);
	}
	
	public void setServiceClassCode(String value) {
		rightPadColumn(2, 3, value);
	}
	
	public void setEntryAddendaCount(String value) {
		rightPadColumn(3, 6, value);
	}
	
	public void setEntryHash(String value) {
		rightPadColumn(4, 10, value);
	}
	
	public void setTotalDebitEntryDollarAmt(String value) {
		leftPadColumnWithZeros(5, 12, value);
	}
	
	public void setTotalCreditEntryDollarAmt(String value) {
		leftPadColumnWithZeros(6, 12, value);
	}
	
	public void setCompanyIdentification(String value) {		
		rightPadColumn(7, 10, value);
	}
	
	public void setMessageAuthCode(String value) {		
		rightPadColumn(8, 19, value);
	}
	
	public void setReservedField(String value) {		
		rightPadColumn(9, 6, value);
	}
	
	public void setOriginatingDFIIdentification(String value) {		
		rightPadColumn(10, 8, value);
	}
	
	public void setBatchNumber(String value) {		
		rightPadColumn(11, 7, value);
	}
}
