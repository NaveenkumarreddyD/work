/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Revenue Model Extract Batch
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-04-22   JPunza  NI0034.1 Initial Version.
 * 2013-06-06   JPunza  TIR3. Modified to require FILE_PATH.
 * 2013-06-10   CVB     Get FERC from the 5th character.
 * 2013-06-11   CVB     Subtract number of bills for Bseg Cancel
 * 2013-07-18   CVB     Remove trim to improve performance.
 * 2013-07-22   CVB     Insert record in CM table instead of writing to file.
 * 2013-07-24   JPunza  Remove unused logic.
 * 2013-07-25   JPunza  Close prepared statements. 
 * 2014-01-30   Neha    IM-044824 Code modified to get the effective 
 *						characteristics on Distributione Code
 * 2014-03-02	Neha	IM-046173 performance issues
 * 2016-01-29  	MPang	Updated for CCB v2.4 compilation. 
 *************************************************************************/

package com.splwg.cm.domain.batch;

// JPunza - 2013-07-24 - Start
//import java.io.BufferedWriter;
//import java.io.File;
//import java.io.FileWriter;
// JPunza - 2013-07-24 - End
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
// JPunza - 2013-07-24 - Start
//import com.splwg.base.api.datatypes.Month;
// JPunza - 2013-07-24 - End
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.GeneralLedgerDistributionCode;
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.GeneralLedgerDistributionCodeCharacteristic;
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.GeneralLedgerDistributionEff;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantity;
import com.splwg.ccb.domain.common.featureConfiguration.FeatureConfigurationOptionData;*/
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.entity.GeneralLedgerDistributionCode;
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.entity.GeneralLedgerDistributionCodeCharacteristic;
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.entity.GeneralLedgerDistributionEff;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity;
import com.splwg.ccb.domain.common.data.FeatureConfigurationOptionData;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.ccb.domain.common.featureConfiguration.FeatureConfigurationOptionsRetriever;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.financial.financialTransaction.FinancialTransaction;
import com.splwg.ccb.domain.financial.financialTransaction.FinancialTransactionGeneralLedger;*/
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransactionGeneralLedger;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
// JPunza - 2013-07-24 - Start
//import com.splwg.cm.api.batch.CmRevenueModelExtractRecord;
// JPunza - 2013-07-24 - End
import com.splwg.cm.api.lookup.CmRevenueBillingDeterminantsLookup;
import com.splwg.cm.api.lookup.CmRevenueRateClassLookup;
import com.splwg.cm.api.lookup.CmRevenueThermsLookup;
import com.splwg.cm.api.lookup.ExternalSystemTypeLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

// JPunza - 2013-06-06 - Start
///**
//* @author jpunzalan2
//*
//@BatchJob (rerunnable = false, modules = {},
//*      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, type = string)
//*            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
//*            , @BatchJobSoftParameter (name = DAILY_OR_MONTHLY_SW, required = true, type = string)
//*            , @BatchJobSoftParameter (entityName = featureConfiguration, name = REVENUE_RATE_CLASS_FC, required = true, type = entity)
//*            , @BatchJobSoftParameter (entityName = featureConfiguration, name = REVENUE_THERMS_FC, required = true, type = entity)
//*            , @BatchJobSoftParameter (entityName = featureConfiguration, name = REVENUE_BILLING_DTM_FC, required = true, type = entity)
//*            , @BatchJobSoftParameter (entityName = characteristicType, name = REVENUE_RATE_CLASS_CHAR_TYPE, required = true, type = entity)
//*            , @BatchJobSoftParameter (entityName = characteristicType, name = REVENUE_THERMS_CHAR_TYPE, required = true, type = entity)
//*            , @BatchJobSoftParameter (entityName = characteristicType, name = REVENUE_BILLING_DTM_CHAR_TYPE, required = true, type = entity)
//*            , @BatchJobSoftParameter (name = RES_LP_CHAR_VAL, required = true, type = string)
//*            , @BatchJobSoftParameter (name = COM_LP_CHAR_VAL, required = true, type = string)
//*            , @BatchJobSoftParameter (name = IND_LP_CHAR_VAL, required = true, type = string)
//*            , @BatchJobSoftParameter (entityName = serviceQuantityIdentifier, name = DAYS_SQI, required = true, type = entity)
//*            , @BatchJobSoftParameter (name = BTU_FACTOR, required = true, type = decimal)
//*            , @BatchJobSoftParameter (name = TRANS_SALES_COM_BASIC_CHAR_VAL, required = true, type = string)
//*            , @BatchJobSoftParameter (name = TRANS_SALES_COM_FIRM_CHAR_VAL, required = true, type = string)
//*            , @BatchJobSoftParameter (name = TRANS_SALES_IND_BASIC_CHAR_VAL, required = true, type = string)
//*            , @BatchJobSoftParameter (name = TRANS_SALES_IND_FIRM_CHAR_VAL, required = true, type = string)
//*            , @BatchJobSoftParameter (name = TRANSPORT_COM_BASIC_CHAR_VAL, required = true, type = string)
//*            , @BatchJobSoftParameter (name = TRANSPORT_COM_FIRM_CHAR_VAL, required = true, type = string)
//*            , @BatchJobSoftParameter (name = TRANSPORT_IND_BASIC_CHAR_VAL, required = true, type = string)
//*            , @BatchJobSoftParameter (name = TRANSPORT_IND_FIRM_CHAR_VAL, required = true, type = string)})
//*/
// JPunza - 2013-07-24 - Start
///**
// * @author jpunzalan2
// *
// @BatchJob (rerunnable = false, modules = {},
// *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
// *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
// *            , @BatchJobSoftParameter (name = DAILY_OR_MONTHLY_SW, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = REVENUE_RATE_CLASS_FC, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = REVENUE_THERMS_FC, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = REVENUE_BILLING_DTM_FC, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = REVENUE_RATE_CLASS_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = REVENUE_THERMS_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = REVENUE_BILLING_DTM_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = RES_LP_CHAR_VAL, required = true, type = string)
// *            , @BatchJobSoftParameter (name = COM_LP_CHAR_VAL, required = true, type = string)
// *            , @BatchJobSoftParameter (name = IND_LP_CHAR_VAL, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = serviceQuantityIdentifier, name = DAYS_SQI, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = BTU_FACTOR, required = true, type = decimal)
// *            , @BatchJobSoftParameter (name = TRANS_SALES_COM_BASIC_CHAR_VAL, required = true, type = string)
// *            , @BatchJobSoftParameter (name = TRANS_SALES_COM_FIRM_CHAR_VAL, required = true, type = string)
// *            , @BatchJobSoftParameter (name = TRANS_SALES_IND_BASIC_CHAR_VAL, required = true, type = string)
// *            , @BatchJobSoftParameter (name = TRANS_SALES_IND_FIRM_CHAR_VAL, required = true, type = string)
// *            , @BatchJobSoftParameter (name = TRANSPORT_COM_BASIC_CHAR_VAL, required = true, type = string)
// *            , @BatchJobSoftParameter (name = TRANSPORT_COM_FIRM_CHAR_VAL, required = true, type = string)
// *            , @BatchJobSoftParameter (name = TRANSPORT_IND_BASIC_CHAR_VAL, required = true, type = string)
// *            , @BatchJobSoftParameter (name = TRANSPORT_IND_FIRM_CHAR_VAL, required = true, type = string)})
// */
//// JPunza - 2013-06-06 - End
/**
 * @author jpunzalan2
 *
 @BatchJob (rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, type = string)
 *            , @BatchJobSoftParameter (name = DAILY_OR_MONTHLY_SW, type = string)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = REVENUE_RATE_CLASS_FC, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = REVENUE_THERMS_FC, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = REVENUE_BILLING_DTM_FC, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = REVENUE_RATE_CLASS_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = REVENUE_THERMS_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = REVENUE_BILLING_DTM_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = RES_LP_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = COM_LP_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = IND_LP_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = serviceQuantityIdentifier, name = DAYS_SQI, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = BTU_FACTOR, required = true, type = decimal)
 *            , @BatchJobSoftParameter (name = TRANS_SALES_COM_BASIC_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = TRANS_SALES_COM_FIRM_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = TRANS_SALES_IND_BASIC_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = TRANS_SALES_IND_FIRM_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = TRANSPORT_COM_BASIC_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = TRANSPORT_COM_FIRM_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = TRANSPORT_IND_BASIC_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = TRANSPORT_IND_FIRM_CHAR_VAL, required = true, type = string)})
 */
// JPunza - 2013-07-24 - End

public class CmRevenueModelExtractBatch 
extends CmRevenueModelExtractBatch_Gen {

    // Constant Variables
    // JPunza - 2013-07-24 - Start
    //private final static String THREAD_PLACE_HOLDER = "??";
    //private final static String FILE_PATH = "FILE_PATH";
    //private final static String DAILY_OR_MONTHLY_SW = "DAILY_OR_MONTHLY_SW";
    // JPunza - 2013-07-24 - End
    private final static String RES_LP_CHAR_VAL = "RES_LP_CHAR_VAL";
    private final static String COM_LP_CHAR_VAL = "COM_LP_CHAR_VAL";
    private final static String IND_LP_CHAR_VAL = "IND_LP_CHAR_VAL";
    private final static String TRANS_SALES_COM_BASIC_CHAR_VAL = "TRANS_SALES_COM_BASIC_CHAR_VAL";
    private final static String TRANS_SALES_COM_FIRM_CHAR_VAL = "TRANS_SALES_COM_FIRM_CHAR_VAL";
    private final static String TRANS_SALES_IND_BASIC_CHAR_VAL = "TRANS_SALES_IND_BASIC_CHAR_VAL";
    private final static String TRANS_SALES_IND_FIRM_CHAR_VAL = "TRANS_SALES_IND_FIRM_CHAR_VAL";
    private final static String TRANSPORT_COM_BASIC_CHAR_VAL = "TRANSPORT_COM_BASIC_CHAR_VAL";
    private final static String TRANSPORT_COM_FIRM_CHAR_VAL = "TRANSPORT_COM_FIRM_CHAR_VAL";
    private final static String TRANSPORT_IND_BASIC_CHAR_VAL = "TRANSPORT_IND_BASIC_CHAR_VAL";
    private final static String TRANSPORT_IND_FIRM_CHAR_VAL = "TRANSPORT_IND_FIRM_CHAR_VAL";
    // JPunza - 2013-07-24 - Start
    //private final static String DAILY = "D";
    //private final static String MONTHLY = "M";
    // JPunza - 2013-07-24 - End
    private final static BigDecimal BILL_DAYS = BigDecimal.valueOf(30);
    private final static BigDecimal MIN_DAYS = BigDecimal.valueOf(26);
    private final static BigDecimal MAX_DAYS = BigDecimal.valueOf(35);

    public JobWork getJobWork() {

        // Delete records in CM table
        deleteRecordsInTempTable();

        // Revenue Rate Classes and FERC Numbers
        FeatureConfiguration fc = getParameters().getREVENUE_RATE_CLASS_FC();

        PreparedStatement getRevenueRateClasses = createPreparedStatement(
                "SELECT FC1.WFM_OPT_VAL AS RATE_CLASS, FC2.WFM_OPT_VAL AS FERC_NUM " +
                "FROM CI_WFM_OPT FC1, CI_WFM_OPT FC2 " +
                "WHERE FC1.WFM_NAME = :featConfig " +
                "AND FC1.EXT_OPT_TYPE = :optionType1 " +
                "AND FC2.WFM_NAME = FC1.WFM_NAME " +
                "AND FC2.SEQ_NUM = FC1.SEQ_NUM " +
                "AND FC2.EXT_OPT_TYPE = :optionType2 " +
                //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
                //"ORDER BY FC1.SEQ_NUM ASC");
        		"ORDER BY FC1.SEQ_NUM ASC", getClass().getName());
        		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation

        getRevenueRateClasses.bindEntity("featConfig", fc);
        getRevenueRateClasses.bindLookup("optionType1", CmRevenueRateClassLookup.constants.REVENUE_RATE_CLASS);
        getRevenueRateClasses.bindLookup("optionType2", CmRevenueRateClassLookup.constants.FERC_NUMBER);

        // Build Worklist
        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();

        QueryIterator<SQLResultRow> iter = getRevenueRateClasses.iterate();
        while (iter.hasNext()) {
            SQLResultRow row = iter.next();

            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId(fc.getId());
            workUnit.addSupplementalData("rateClass", row.getString("RATE_CLASS"));
            workUnit.addSupplementalData("fercNum", row.getString("FERC_NUM"));

            workUnits.add(workUnit);              
        }
        iter.close();  
        
        getRevenueRateClasses.close();

        return createJobWorkForThreadWorkUnitList(workUnits);  
    }

    public Class<CmRevenueModelExtractBatchWorker> getThreadWorkerClass() {
        return CmRevenueModelExtractBatchWorker.class;
    }

    @Override
    public void validateSoftParameters(boolean arg0) {

        JobParameters parameters = getParameters();

        // JPunza - 2013-07-24 - Start
        //// File Path
        //String filePath = parameters.getFILE_PATH();        
        ///*
        // * Start Change - 2013-06-06 - JPunza 
        // */
        ////if (notBlank(filePath) && validateFilePath(filePath).isFalse()) {
        //if (validateFilePath(filePath).isFalse()) {
        //    /*
        //     * End Change - 2013-06-06 - JPunza 
        //     */
        //    addError(CustomMessageRepositoryMDC.NI0034_1_filePathInvalid(FILE_PATH, filePath));
        //}
        //
        //// Daily Or Monthly Switch
        //String dailyOrMonthlySwitch = parameters.getDAILY_OR_MONTHLY_SW();
        //if (!(dailyOrMonthlySwitch.equalsIgnoreCase(DAILY) || dailyOrMonthlySwitch.equalsIgnoreCase(MONTHLY))) {
        //    addError(CustomMessageRepositoryMDC.NI0034_1_valueEitherMorD(DAILY_OR_MONTHLY_SW, dailyOrMonthlySwitch));
        //}
        // JPunza - 2013-07-24 - End

        CharacteristicType charType = parameters.getREVENUE_RATE_CLASS_CHAR_TYPE();                
        if (charType.getCharacteristicType().isPredefinedValue()) {

            // Residential LP Revenue Rate Class Characteristic Value
            String charValue = parameters.getRES_LP_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        RES_LP_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));
            }

            // Commercial LP Revenue Rate Class Characteristic Value
            charValue = parameters.getCOM_LP_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        COM_LP_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Industrial LP Revenue Rate Class Characteristic Value
            charValue = parameters.getIND_LP_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        IND_LP_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Transport Sales Commercial Basic Revenue Rate Class Characteristic Value
            charValue = parameters.getTRANS_SALES_COM_BASIC_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANS_SALES_COM_BASIC_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Transport Sales Commercial Firm Revenue Rate Class Characteristic Value
            charValue = parameters.getTRANS_SALES_COM_FIRM_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANS_SALES_COM_FIRM_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Transport Sales Industrial Basic Revenue Rate Class Characteristic Value
            charValue = parameters.getTRANS_SALES_IND_BASIC_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANS_SALES_IND_BASIC_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Transport Sales Industrial Firm Revenue Rate Class Characteristic Value
            charValue = parameters.getTRANS_SALES_IND_FIRM_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANS_SALES_IND_FIRM_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Transportation Commercial Basic Revenue Rate Class Characteristic Value
            charValue = parameters.getTRANSPORT_COM_BASIC_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANSPORT_COM_BASIC_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Transportation Commercial Firm Revenue Rate Class Characteristic Value
            charValue = parameters.getTRANSPORT_COM_FIRM_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANSPORT_COM_FIRM_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Transportation Industrial Basic Revenue Rate Class Characteristic Value
            charValue = parameters.getTRANSPORT_IND_BASIC_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANSPORT_IND_BASIC_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Transportation Industrial Firm Revenue Rate Class Characteristic Value
            charValue = parameters.getTRANSPORT_IND_FIRM_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANSPORT_IND_FIRM_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }
        }        
    }

    // JPunza - 2013-07-24 - Start
    ///**
    // * This method validates file path.
    // * @param filePath - String
    // * @return Bool
    // */
    //private Bool validateFilePath(String filePath) {
    //
    //    File folder = new File(filePath);
    //    /*
    //     * Start Change - 2013-06-06 - JPunza 
    //     */
    //    //if (folder.exists()) {
    //    if (folder.isDirectory()) {
    //        /*
    //         * End Change - 2013-06-06 - JPunza 
    //         */
    //        return Bool.TRUE;
    //   }
    //    return Bool.FALSE;
    //}
    // JPunza - 2013-07-24 - End

    /**
     * This method validates if characteristic value is valid for a given characteristic type. 
     * @param charType - Characteristic Type
     * @param charValue - String
     * @return Bool
     */
    private Bool validateCharacteristicValue(CharacteristicType charType, String charValue) {

        CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charType, charValue);
        if (isNull(charValueId.getEntity())) {
            return Bool.FALSE;
        }        
        return Bool.TRUE;
    }


    public static class CmRevenueModelExtractBatchWorker 
    extends CmRevenueModelExtractBatchWorker_Gen {

        // Soft Parameters
        // JPunza - 2013-07-24 - Start
        //private Bool dailyFlag;
        // JPunza - 2013-07-24 - End
        private FeatureConfiguration revenueThermsFeatConfig;
        private FeatureConfiguration revenueBillingDtmFeatConfig;
        private CharacteristicType revenueRateClassCharType;
        private CharacteristicType revenueThermsCharType;
        private CharacteristicType revenueBillingDeterminantsCharType;
        private String resLpRevenueRateClassCharValue;
        private String comLpRevenueRateClassCharValue;
        private String indLpRevenueRateClassCharValue;
        private String transportSalesComBasicCharValue;
        private String transportSalesComFirmCharValue;
        private String transportSalesIndBasicCharValue;
        private String transportSalesIndFirmCharValue;
        private String transportationComBasicCharValue;
        private String transportationComFirmCharValue;
        private String transportationIndBasicCharValue;
        private String transportationIndFirmCharValue;
        private ServiceQuantityIdentifier daysSqi;
        private BigDecimal btuFactor;

        // Working Variables
        private Date processDate;
        // JPunza - 2013-07-24 - Start
        //private Date startDate;
        //private Date endDate;
        //private BufferedWriter bufferedWriter;
        // JPunza - 2013-07-24 - End
        private String revenueRateClass;
        private String fercNumber;
        private String transportRateClass1;
        private String transportRateClass2;
        private int saCount;
        private BigDecimal billCount;

        // Revenue Therms
        private String block1WinterThermsBilled;
        private String block1SummerThermsBilled;
        private String block2WinterThermsBilled;
        private String block2SummerThermsBilled;
        private String demandThermsBilled;
        private String authorizedOverrunTherms;
        private String unauthorizedOverrunTherms;

        private BigDecimal block1WinterThermsBilledAmt;
        private BigDecimal block1SummerThermsBilledAmt;
        private BigDecimal block2WinterThermsBilledAmt;
        private BigDecimal block2SummerThermsBilledAmt;
        private BigDecimal demandThermsBilledAmt;
        private BigDecimal authorizedOverrunThermsAmt;
        private BigDecimal unauthorizedOverrunThermsAmt;

        // Revenue Billing Determinants
        private String block1WinterRevenueBilled;
        private String block1SummerRevenueBilled;
        private String block2WinterRevenueBilled;
        private String block2SummerRevenueBilled;
        private String customerChargeBilled;
        private String demandChargeRevenue;
        private String isrsRevenueBilled;
        private String authorizedOverrunRevenue;
        private String unauthorizedOverrunRevenue;        
        private String pgaRevenueBilled;
        private String acaRevenueBilled;
        private String grtInRevenue;
        private String iaRevenue;
        private String principalRefund;        
        private String lacledeIntRefund;
        private String grtRefund;
        private String stateSalesTax;
        private String citySalesTax;
        private String transportationStorageRevenue;

        private BigDecimal block1WinterRevenueBilledAmt;
        private BigDecimal block1SummerRevenueBilledAmt;
        private BigDecimal block2WinterRevenueBilledAmt;
        private BigDecimal block2SummerRevenueBilledAmt;
        private BigDecimal customerChargeBilledAmt;
        private BigDecimal demandChargeRevenueAmt;
        private BigDecimal isrsRevenueBilledAmt;
        private BigDecimal authorizedOverrunRevenueAmt;
        private BigDecimal unauthorizedOverrunRevenueAmt;        
        private BigDecimal pgaRevenueBilledAmt;
        private BigDecimal acaRevenueBilledAmt;
        private BigDecimal grtInRevenueAmt;
        private BigDecimal iaRevenueAmt;
        private BigDecimal principalRefundAmt;        
        private BigDecimal lacledeIntRefundAmt;
        private BigDecimal grtRefundAmt;
        private BigDecimal stateSalesTaxAmt;
        private BigDecimal citySalesTaxAmt;
        private BigDecimal transportationStorageRevenueAmt;

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new CommitEveryUnitStrategy(this);
        }

        @Override
        public void initializeThreadWork(boolean arg0) 
        throws ThreadAbortedException, RunAbortedException {

            // Soft Parameters
            ThreadParameters parameters = getParameters();

            // JPunza - 2013-07-24 - Start
            //// Daily Or Monthly Switch
            //dailyFlag = Bool.FALSE;
            //if (parameters.getDAILY_OR_MONTHLY_SW().equalsIgnoreCase(DAILY)) {
            //    dailyFlag = Bool.TRUE;
            //}
            // JPunza - 2013-07-24 - End

            revenueThermsFeatConfig = parameters.getREVENUE_THERMS_FC();
            revenueBillingDtmFeatConfig = parameters.getREVENUE_BILLING_DTM_FC();

            revenueRateClassCharType = parameters.getREVENUE_RATE_CLASS_CHAR_TYPE();
            revenueThermsCharType = parameters.getREVENUE_THERMS_CHAR_TYPE();
            revenueBillingDeterminantsCharType = parameters.getREVENUE_BILLING_DTM_CHAR_TYPE();

            resLpRevenueRateClassCharValue = parameters.getRES_LP_CHAR_VAL();
            comLpRevenueRateClassCharValue = parameters.getCOM_LP_CHAR_VAL();
            indLpRevenueRateClassCharValue = parameters.getIND_LP_CHAR_VAL();

            daysSqi = parameters.getDAYS_SQI();

            // Set Dates
            processDate = getProcessDateTime().getDate();
            
            // JPunza - 2013-07-24 - Start
            //if (dailyFlag.isFalse()) {
            //    Month month = processDate.getMonthValue();
            //    int year = processDate.getYear();
            //
            //    startDate = new Date(year, month, 1);
            //    endDate = new Date(year, month, month.getDaysInMonth());
            //}
            // JPunza - 2013-07-24 - End
            
            // Revenue Therms
            ExternalSystemTypeLookup extSysType = ExternalSystemTypeLookup.constants.CM_REVENUE_THERMS;

            // Block 1 Winter Therms Billed
            block1WinterThermsBilled = retrieveFeatConfigOptionValue(revenueThermsFeatConfig, 
                    CmRevenueThermsLookup.constants.BLOCK_1_WINTER_THERMS_BILLED.getLookupValue(), 
                    extSysType);

            // Block 1 Summer Therms Billed
            block1SummerThermsBilled = retrieveFeatConfigOptionValue(revenueThermsFeatConfig, 
                    CmRevenueThermsLookup.constants.BLOCK_1_SUMMER_THERMS_BILLED.getLookupValue(), 
                    extSysType);

            // Block 2 Winter Therms Billed
            block2WinterThermsBilled = retrieveFeatConfigOptionValue(revenueThermsFeatConfig, 
                    CmRevenueThermsLookup.constants.BLOCK_2_WINTER_THERMS_BILLED.getLookupValue(), 
                    extSysType);

            // Block 2 Summer Therms Billed
            block2SummerThermsBilled = retrieveFeatConfigOptionValue(revenueThermsFeatConfig, 
                    CmRevenueThermsLookup.constants.BLOCK_2_SUMMER_THERMS_BILLED.getLookupValue(), 
                    extSysType);

            // Demand Therms Billed
            demandThermsBilled = retrieveFeatConfigOptionValue(revenueThermsFeatConfig, 
                    CmRevenueThermsLookup.constants.DEMAND_THERMS_BILLED.getLookupValue(), 
                    extSysType);

            // Authorized Overrun Therms
            authorizedOverrunTherms = retrieveFeatConfigOptionValue(revenueThermsFeatConfig, 
                    CmRevenueThermsLookup.constants.AUTHORIZED_OVERRUN_THERMS.getLookupValue(), 
                    extSysType);

            // Unauthorized Overrun Therms
            unauthorizedOverrunTherms = retrieveFeatConfigOptionValue(revenueThermsFeatConfig, 
                    CmRevenueThermsLookup.constants.UNAUTHORIZED_OVERRUN_THERMS.getLookupValue(), 
                    extSysType);

            // Revenue Billing Determinants
            extSysType = ExternalSystemTypeLookup.constants.CM_REVENUE_BILLING_DETERMINANTS;

            // Block 1 Winter Revenue Billed
            block1WinterRevenueBilled = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.BLOCK_1_WINTER_REVENUE_BILLED.getLookupValue(), 
                    extSysType);

            // Block 1 Summer Revenue Billed
            block1SummerRevenueBilled = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.BLOCK_1_SUMMER_REVENUE_BILLED.getLookupValue(), 
                    extSysType);

            // Block 2 Winter Revenue Billed
            block2WinterRevenueBilled = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.BLOCK_2_WINTER_REVENUE_BILLED.getLookupValue(), 
                    extSysType);

            // Block 2 Summer Revenue Billed
            block2SummerRevenueBilled = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.BLOCK_2_SUMMER_REVENUE_BILLED.getLookupValue(), 
                    extSysType);

            // Customer Charge Billed
            customerChargeBilled = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.CUSTOMER_CHARGE_BILLED.getLookupValue(), 
                    extSysType);

            // Demand Charge Revenue
            demandChargeRevenue = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.DEMAND_CHARGE_REVENUE.getLookupValue(), 
                    extSysType);

            // ISRS Revenue Billed
            isrsRevenueBilled = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.ISRS_REVENUE_BILLED.getLookupValue(), 
                    extSysType);

            // Authorized Overrun Revenue
            authorizedOverrunRevenue = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.AUTHORIZED_OVERRUN_REVENUE.getLookupValue(), 
                    extSysType);

            // Unauthorized Overrun Revenue
            unauthorizedOverrunRevenue = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.UNAUTHORIZED_OVERRUN_REVENUE.getLookupValue(), 
                    extSysType);

            // PGA Revenue Billed
            pgaRevenueBilled = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.PGA_REVENUE_BILLED.getLookupValue(), 
                    extSysType);

            // ACA Revenue Billed
            acaRevenueBilled = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.ACA_REVENUE_BILLED.getLookupValue(), 
                    extSysType);

            // GRT in Revenue
            grtInRevenue = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.GRT_IN_REVENUE.getLookupValue(), 
                    extSysType);

            // IA Revenue
            iaRevenue = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.IA_REVENUE.getLookupValue(), 
                    extSysType);

            // Principle Refund
            principalRefund = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.PRINCIPAL_REFUND.getLookupValue(), 
                    extSysType);

            // Laclede Int Refund
            lacledeIntRefund = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.LACLEDE_INT_REFUND.getLookupValue(), 
                    extSysType);

            // GRT Refund
            grtRefund = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.GRT_REFUND.getLookupValue(), 
                    extSysType);

            // State Sales Tax
            stateSalesTax = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.STATE_SALES_TAX.getLookupValue(), 
                    extSysType);

            // City Sales Tax
            citySalesTax = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.CITY_SALES_TAX.getLookupValue(), 
                    extSysType);

            // Transportation Storage Revenue
            transportationStorageRevenue = retrieveFeatConfigOptionValue(revenueBillingDtmFeatConfig, 
                    CmRevenueBillingDeterminantsLookup.constants.TRANSPORTATION_STORAGE_REVENUE.getLookupValue(), 
                    extSysType);

            btuFactor = parameters.getBTU_FACTOR();

            transportSalesComBasicCharValue = parameters.getTRANS_SALES_COM_BASIC_CHAR_VAL();
            transportSalesComFirmCharValue = parameters.getTRANS_SALES_COM_FIRM_CHAR_VAL();
            transportSalesIndBasicCharValue = parameters.getTRANS_SALES_IND_BASIC_CHAR_VAL();
            transportSalesIndFirmCharValue = parameters.getTRANS_SALES_IND_FIRM_CHAR_VAL();
            transportationComBasicCharValue = parameters.getTRANSPORT_COM_BASIC_CHAR_VAL();
            transportationComFirmCharValue = parameters.getTRANSPORT_COM_FIRM_CHAR_VAL();
            transportationIndBasicCharValue = parameters.getTRANSPORT_IND_BASIC_CHAR_VAL();
            transportationIndFirmCharValue = parameters.getTRANSPORT_IND_FIRM_CHAR_VAL();

            // CVB - 2013-07-22 - Start
            //// Open file
            //String fileName = getParameters().getFILE_NAME();
            //if (fileName.indexOf(THREAD_PLACE_HOLDER) != -1){
            //    fileName = fileName.replace(THREAD_PLACE_HOLDER, getBatchThreadNumber().toString());
            //} 
            //
            //File file = new File(parameters.getFILE_PATH(), fileName);                        
            //try {
            //    bufferedWriter = new BufferedWriter(new FileWriter(file));
            //} catch (Exception e) {
            //    addError(CustomMessageRepositoryMDC.NI0034_1_errorWhileAccessingFile(e.getMessage()));
            //}
            // CVB - 2013-07-22 - End
        }

        /**
         * This method retrieves Feature Configuration Option Value.
         * @param featConfig - Feature Configuration
         * @param optionType - Lookup Value
         * @param extSysType - External System Type Lookup
         * @return String
         */
        private String retrieveFeatConfigOptionValue(FeatureConfiguration featConfig, LookupValue optionType, ExternalSystemTypeLookup extSysType) {

            FeatureConfigurationOptionsRetriever fcOptionsRetriever = FeatureConfigurationOptionsRetriever.Factory.newInstance();
            List<FeatureConfigurationOptionData> fcOptionData = fcOptionsRetriever.getFeatureConfigurationOptions(featConfig, 
                    optionType.fetchIdFieldValue().trim(), extSysType);

            if (fcOptionData.isEmpty()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_featConfigOptMissing(featConfig.getId().getTrimmedValue(), 
                        optionType.fetchLanguageDescription().trim()));
            }
            else if (fcOptionData.size() > 1) {
                addError(CustomMessageRepositoryMDC.NI0034_1_featConfigOptMultiple(featConfig.getId().getTrimmedValue(), 
                        optionType.fetchLanguageDescription().trim()));    
            }

            return fcOptionData.get(0).getOptionValue().trim();
        }

        @Override
        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit arg0) 
        throws ThreadAbortedException, RunAbortedException {

            // Initialize Variables           
            revenueRateClass = (String) arg0.getSupplementallData("rateClass");
            fercNumber = (String) arg0.getSupplementallData("fercNum");

            // Check for LP Revenue Rate Class
            Bool isLpRevenueRateClass = Bool.FALSE;
            if (revenueRateClass.equalsIgnoreCase(resLpRevenueRateClassCharValue) 
                    || revenueRateClass.equalsIgnoreCase(comLpRevenueRateClassCharValue)
                    || revenueRateClass.equalsIgnoreCase(indLpRevenueRateClassCharValue)) {
                isLpRevenueRateClass = Bool.TRUE;
            }

            // Check for Transport Sales
            Bool isTransportSales = Bool.FALSE;
            if (revenueRateClass.equalsIgnoreCase(transportSalesComBasicCharValue)
                    || revenueRateClass.equalsIgnoreCase(transportSalesComFirmCharValue)
                    || revenueRateClass.equalsIgnoreCase(transportSalesIndBasicCharValue)
                    || revenueRateClass.equalsIgnoreCase(transportSalesIndFirmCharValue)) {
                isTransportSales = Bool.TRUE;
            }

            // Check for Transportation
            Bool isTransportation = Bool.FALSE;
            if (revenueRateClass.equalsIgnoreCase(transportationComBasicCharValue)
                    || revenueRateClass.equalsIgnoreCase(transportationComFirmCharValue)
                    || revenueRateClass.equalsIgnoreCase(transportationIndBasicCharValue)
                    || revenueRateClass.equalsIgnoreCase(transportationIndFirmCharValue)) {
                isTransportation = Bool.TRUE;
            }

            // Determine the Transport Sales and Transportation pair
            if (isTransportSales.isTrue() || isTransportation.isTrue()) {            
                if (revenueRateClass.equalsIgnoreCase(transportSalesComBasicCharValue) 
                        || revenueRateClass.equalsIgnoreCase(transportationComBasicCharValue)) {
                    transportRateClass1 = transportSalesComBasicCharValue;
                    transportRateClass2 = transportationComBasicCharValue;
                }
                else if (revenueRateClass.equalsIgnoreCase(transportSalesComFirmCharValue) 
                        || revenueRateClass.equalsIgnoreCase(transportationComFirmCharValue)) {
                    transportRateClass1 = transportSalesComFirmCharValue;
                    transportRateClass2 = transportationComFirmCharValue;
                }
                else if (revenueRateClass.equalsIgnoreCase(transportSalesIndBasicCharValue) 
                        || revenueRateClass.equalsIgnoreCase(transportationIndBasicCharValue)) {
                    transportRateClass1 = transportSalesIndBasicCharValue;
                    transportRateClass2 = transportationIndBasicCharValue;
                }
                else if (revenueRateClass.equalsIgnoreCase(transportSalesIndFirmCharValue) 
                        || revenueRateClass.equalsIgnoreCase(transportationIndFirmCharValue)) {
                    transportRateClass1 = transportSalesIndFirmCharValue;
                    transportRateClass2 = transportationIndFirmCharValue;
                }
            }

            // Counters
            int processedRecord = 0;
            int recordInError = 0;

            saCount = 0;
            billCount = BigDecimal.ZERO;

            ServiceAgreement previousSa = null;
            ServiceAgreement currentSa = null;

            // Fields
            block1WinterThermsBilledAmt = BigDecimal.ZERO;
            block1SummerThermsBilledAmt = BigDecimal.ZERO;
            block2WinterThermsBilledAmt = BigDecimal.ZERO;
            block2SummerThermsBilledAmt = BigDecimal.ZERO;
            demandThermsBilledAmt = BigDecimal.ZERO;
            authorizedOverrunThermsAmt = BigDecimal.ZERO;
            unauthorizedOverrunThermsAmt = BigDecimal.ZERO;

            block1WinterRevenueBilledAmt = BigDecimal.ZERO;
            block1SummerRevenueBilledAmt = BigDecimal.ZERO;
            block2WinterRevenueBilledAmt = BigDecimal.ZERO;
            block2SummerRevenueBilledAmt = BigDecimal.ZERO;
            customerChargeBilledAmt = BigDecimal.ZERO;
            demandChargeRevenueAmt = BigDecimal.ZERO;
            isrsRevenueBilledAmt = BigDecimal.ZERO;
            authorizedOverrunRevenueAmt = BigDecimal.ZERO;
            unauthorizedOverrunRevenueAmt = BigDecimal.ZERO;        
            pgaRevenueBilledAmt = BigDecimal.ZERO;
            acaRevenueBilledAmt = BigDecimal.ZERO;
            grtInRevenueAmt = BigDecimal.ZERO;
            iaRevenueAmt = BigDecimal.ZERO;
            principalRefundAmt = BigDecimal.ZERO;        
            lacledeIntRefundAmt = BigDecimal.ZERO;
            grtRefundAmt = BigDecimal.ZERO;
            stateSalesTaxAmt = BigDecimal.ZERO;
            citySalesTaxAmt = BigDecimal.ZERO;
            transportationStorageRevenueAmt = BigDecimal.ZERO;

            // For each Financial Transactions
            // JPunza - 2013-07-25 - Start
            //QueryIterator<SQLResultRow> iter = getFinancialTransactions(revenueRateClass, fercNumber).iterate();
            PreparedStatement financialTransactions = getFinancialTransactions(revenueRateClass, fercNumber);
            QueryIterator<SQLResultRow> iter = financialTransactions.iterate();
            // JPunza - 2013-07-25 - End
            while (iter.hasNext()) {

                processedRecord++;

                SQLResultRow result = iter.next();
                currentSa = result.getEntity("SA_ID", ServiceAgreement.class);
                FinancialTransaction ft = result.getEntity("FT_ID", FinancialTransaction.class);

                // Check Revenue Rate Classes in FT GL
                Bool specialProcess = Bool.FALSE;                
                if (isTransportSales.isTrue() || isTransportation.isTrue()) {

                    if (checkForOtherRevenueRateClass(ft, transportRateClass1, transportRateClass2).isTrue()) {
                        logError(CustomMessageRepositoryMDC.NI0034_1_multipleRevenueRateClass(ft.getId().getTrimmedValue()));
                        recordInError++;
                        continue;
                    }

                    // Check if both Transportation and Transport Sales exist 
                    if (checkForRevenueRateClass(ft, transportRateClass1).isTrue() 
                            && checkForRevenueRateClass(ft, transportRateClass2).isTrue()) {
                        specialProcess = Bool.TRUE;
                    }                    
                }
                else if (checkForOtherRevenueRateClass(ft, revenueRateClass, revenueRateClass).isTrue()) {
                    logError(CustomMessageRepositoryMDC.NI0034_1_multipleRevenueRateClass(ft.getId().getTrimmedValue()));
                    recordInError++;
                    continue;
                }

                // Count Service Agreement
                if (!(currentSa.equals(previousSa))) {

                    // For Transport Sales, count SA only if there is no GL with Transportation  
                    if (isTransportSales.isTrue()) {
                        if (specialProcess.isFalse()) {
                            saCount++;
                        }                        
                    }
                    else {
                        saCount++; 
                    }
                    previousSa = currentSa;
                }

                // Count Bill
                //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
                //ListFilter<BillSegmentServiceQuantity> getServiceQuantities = ft.fetchSiblingBillSegment().getServiceQuantities()
                //.createFilter("where this.id.serviceQuantityIdentifier = :daysSqi");
                ListFilter<BillSegmentServiceQuantity> getServiceQuantities = ft.fetchSiblingBillSegment().getServiceQuantities()
                		.createFilter("where this.id.serviceQuantityIdentifier = :daysSqi", getClass().getName());
                //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
                getServiceQuantities.bindEntity("daysSqi", daysSqi);
                BillSegmentServiceQuantity serviceQuantity = getServiceQuantities.firstRow();
                if (notNull(serviceQuantity)) {

                    BigDecimal billServQuantity = serviceQuantity.getBillableServiceQuantity();

                    // If Billable Service Quantity is less than 26 or greater than 35
                    if (billServQuantity.compareTo(MIN_DAYS) < 0 || billServQuantity.compareTo(MAX_DAYS) > 0) {
                        // CVB - 2013-06-11 - Start
                        if (ft.getFinancialTransactionType().isBillSegment()) {
                            billCount = billCount.add(billServQuantity.divide(BILL_DAYS).setScale(2, BigDecimal.ROUND_HALF_UP));
                        }
                        if (ft.getFinancialTransactionType().isBillCancellation()) {
                            billCount = billCount.subtract(billServQuantity.divide(BILL_DAYS).setScale(2, BigDecimal.ROUND_HALF_UP));
                        }
                        // billCount = billCount.add(billServQuantity.divide(BILL_DAYS).setScale(2, BigDecimal.ROUND_HALF_UP));
                        // CVB - 2013-06-11 - End
                    }
                    else {
                        // CVB - 2013-06-11 - Start
                        if (ft.getFinancialTransactionType().isBillSegment()) {
                            billCount = billCount.add(BigDecimal.ONE);
                        }
                        if (ft.getFinancialTransactionType().isBillCancellation()) {
                            billCount = billCount.subtract(BigDecimal.ONE);
                        }
                        // billCount = billCount.add(BigDecimal.ONE);
                        // CVB - 2013-06-11 - End
                    }
                }

                // For each FT GL
                Iterator<FinancialTransactionGeneralLedger> iter2 = ft.getGeneralLedgers().iterator();                
                while (iter2.hasNext()) {

                    // Get FT GL
                    FinancialTransactionGeneralLedger ftGl = iter2.next();

                    if (specialProcess.isTrue()) {

                        // Retrieve Revenue Rate Class Characteristic
                        String rateClass = getDistCodeCharacteristic(ftGl.getDistributionCode(), revenueRateClassCharType);

                        // For Transportation, sum GL with no Revenue Rate Class only if there is no GL with Transport Sales
                        if ((isNull(rateClass) && isTransportation.isTrue()) 
                                || (notNull(rateClass) && !revenueRateClass.equalsIgnoreCase(rateClass))) {
                            continue;
                        }                        
                    }    

                    // Retrieve Revenue Therms Characteristic
                    String therms = getDistCodeCharacteristic(ftGl.getDistributionCode(), revenueThermsCharType);

                    if (notBlank(therms)) {

                        BigDecimal statisticAmount = ftGl.getStatisticAmount();

                        // Apply BTU Factor for LP Revenue Rate Class
                        if (isLpRevenueRateClass.isTrue()) {
                            statisticAmount = statisticAmount.multiply(btuFactor).setScale(1, BigDecimal.ROUND_HALF_UP);
                        }

                        if (therms.equalsIgnoreCase(block1WinterThermsBilled)) {
                            block1WinterThermsBilledAmt = block1WinterThermsBilledAmt.add(statisticAmount);
                        }
                        else if (therms.equalsIgnoreCase(block1SummerThermsBilled)) {
                            block1SummerThermsBilledAmt = block1SummerThermsBilledAmt.add(statisticAmount);
                        }
                        else if (therms.equalsIgnoreCase(block2WinterThermsBilled)) {
                            block2WinterThermsBilledAmt = block2WinterThermsBilledAmt.add(statisticAmount);                            
                        }
                        else if (therms.equalsIgnoreCase(block2SummerThermsBilled)) {
                            block2SummerThermsBilledAmt = block2SummerThermsBilledAmt.add(statisticAmount);
                        }
                        else if (therms.equalsIgnoreCase(demandThermsBilled)) {
                            demandThermsBilledAmt = demandThermsBilledAmt.add(statisticAmount);
                        }
                        else if (therms.equalsIgnoreCase(authorizedOverrunTherms)) {
                            authorizedOverrunThermsAmt = authorizedOverrunThermsAmt.add(statisticAmount);
                        }
                        else if (therms.equalsIgnoreCase(unauthorizedOverrunTherms)) {
                            unauthorizedOverrunThermsAmt = unauthorizedOverrunThermsAmt.add(statisticAmount);
                        }
                    }

                    // Retrieve Revenue Billing Determinants Characteristic
                    String billingDeterminant = getDistCodeCharacteristic(ftGl.getDistributionCode(), revenueBillingDeterminantsCharType);

                    if (notBlank(billingDeterminant)) {

                        BigDecimal amount = ftGl.getAmount().getAmount();

                        if (billingDeterminant.equalsIgnoreCase(block1WinterRevenueBilled)) {
                            block1WinterRevenueBilledAmt = block1WinterRevenueBilledAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(block1SummerRevenueBilled)) {
                            block1SummerRevenueBilledAmt = block1SummerRevenueBilledAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(block2WinterRevenueBilled)) {
                            block2WinterRevenueBilledAmt = block2WinterRevenueBilledAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(block2SummerRevenueBilled)) {
                            block2SummerRevenueBilledAmt = block2SummerRevenueBilledAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(customerChargeBilled)) {
                            customerChargeBilledAmt = customerChargeBilledAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(demandChargeRevenue)) {
                            demandChargeRevenueAmt = demandChargeRevenueAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(isrsRevenueBilled)) {
                            isrsRevenueBilledAmt = isrsRevenueBilledAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(authorizedOverrunRevenue)) {
                            authorizedOverrunRevenueAmt = authorizedOverrunRevenueAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(unauthorizedOverrunRevenue)) {
                            unauthorizedOverrunRevenueAmt = unauthorizedOverrunRevenueAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(pgaRevenueBilled)) {
                            pgaRevenueBilledAmt = pgaRevenueBilledAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(acaRevenueBilled)) {
                            acaRevenueBilledAmt = acaRevenueBilledAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(grtInRevenue)) {
                            grtInRevenueAmt = grtInRevenueAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(iaRevenue)) {
                            iaRevenueAmt = iaRevenueAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(principalRefund)) {
                            principalRefundAmt = principalRefundAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(lacledeIntRefund)) {
                            lacledeIntRefundAmt = lacledeIntRefundAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(grtRefund)) {
                            grtRefundAmt = grtRefundAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(grtInRevenue)) {
                            grtInRevenueAmt = grtInRevenueAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(stateSalesTax)) {
                            stateSalesTaxAmt = stateSalesTaxAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(citySalesTax)) {
                            citySalesTaxAmt = citySalesTaxAmt.add(amount);
                        }
                        else if (billingDeterminant.equalsIgnoreCase(transportationStorageRevenue)) {
                            transportationStorageRevenueAmt = transportationStorageRevenueAmt.add(amount);
                        }
                    }
                }
            }
            iter.close();
            // JPunza - 2013-07-25 - Start
            financialTransactions.close();
            // JPunza - 2013-07-25 - End

            // CVB - 2013-07-22 - Start
            //// Write record on File
            //writeRecord();
            insertRecord();
            // CVB - 2013-07-22 - End

            WorkUnitResult result = new WorkUnitResult(true);
            result.setUnitsProcessed(processedRecord);
            result.setUnitsInError(recordInError);

            return result;
        }

        /**
         * This method checks for Revenue Rate Class.
         * @param ft - Financial Transaction
         * @param transportRateClass - String
         * @return Bool
         */
        private Bool checkForRevenueRateClass(FinancialTransaction ft, String transportRateClass) {

            PreparedStatement checkRateClassQuery = createPreparedStatement("SELECT FG.FT_ID FROM CI_FT_GL FG " +
                    "WHERE FG.FT_ID = :ft " +
                    "AND EXISTS (SELECT 'X' FROM CI_DST_CD_CHAR DCC " +
                    "   WHERE DCC.DST_ID = FG.DST_ID " +
                    "   AND DCC.CHAR_TYPE_CD = :charType " +
                    "   AND (TRIM(DCC.CHAR_VAL) = TRIM(:charValue) " +
                    "   OR TRIM(DCC.CHAR_VAL_FK1) = TRIM(:charValueFk1) " +
                    "   OR TRIM(DCC.ADHOC_CHAR_VAL) = TRIM(:adhocCharValue)) " +
                    //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
                    //"   AND DCC.EFFDT <= :processDate)");
            		"   AND DCC.EFFDT <= :processDate)", getClass().getName());
            		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation

            checkRateClassQuery.bindEntity("ft", ft);
            checkRateClassQuery.bindEntity("charType", revenueRateClassCharType);
            checkRateClassQuery.bindStringProperty("charValue", 
                    GeneralLedgerDistributionCodeCharacteristic.properties.characteristicValue, 
                    transportRateClass);
            checkRateClassQuery.bindStringProperty("charValueFk1", 
                    GeneralLedgerDistributionCodeCharacteristic.properties.characteristicValueForeignKey1, 
                    transportRateClass); 
            checkRateClassQuery.bindStringProperty("adhocCharValue", 
                    GeneralLedgerDistributionCodeCharacteristic.properties.adhocCharacteristicValue, 
                    transportRateClass);                 
            checkRateClassQuery.bindDate("processDate", processDate);

            if (notNull(checkRateClassQuery.firstRow())) {
                checkRateClassQuery.close();
                return Bool.TRUE;
            }

            checkRateClassQuery.close();
            return Bool.FALSE;
        }

        /**
         * This method checks for other Revenue Rate Class.
         * @param ft - Financial Transaction
         * @param value1 - String
         * @param value2 - String
         * @return Bool
         */
        private Bool checkForOtherRevenueRateClass(FinancialTransaction ft, String value1, String value2) {

            PreparedStatement checkRateClassQuery = createPreparedStatement("SELECT FG.FT_ID FROM CI_FT_GL FG " +
                    "WHERE FG.FT_ID = :ft " +
                    "AND EXISTS (SELECT 'X' FROM CI_DST_CD_CHAR DCC " +
                    "   WHERE DCC.DST_ID = FG.DST_ID " +
                    "   AND DCC.CHAR_TYPE_CD = :charType " +
                    "   AND (TRIM(DCC.CHAR_VAL) NOT IN (TRIM(:charValue1), TRIM(:charValue2))" +
                    "   OR TRIM(DCC.CHAR_VAL_FK1) NOT IN (TRIM(:fkValue1), TRIM(:fkValue2)) " +
                    "   OR TRIM(DCC.ADHOC_CHAR_VAL) NOT IN (TRIM(:adhocValue1), TRIM(:adhocValue2))) " +
                    //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
                    //"   AND DCC.EFFDT <= :processDate)");
            		"   AND DCC.EFFDT <= :processDate)", getClass().getName());
            		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation

            checkRateClassQuery.bindEntity("ft", ft);
            checkRateClassQuery.bindEntity("charType", revenueRateClassCharType);
            checkRateClassQuery.bindStringProperty("charValue1", 
                    GeneralLedgerDistributionCodeCharacteristic.properties.characteristicValue, 
                    value1);
            checkRateClassQuery.bindStringProperty("charValue2", 
                    GeneralLedgerDistributionCodeCharacteristic.properties.characteristicValue, 
                    value2);
            checkRateClassQuery.bindStringProperty("fkValue1", 
                    GeneralLedgerDistributionCodeCharacteristic.properties.characteristicValueForeignKey1, 
                    value1);
            checkRateClassQuery.bindStringProperty("fkValue2", 
                    GeneralLedgerDistributionCodeCharacteristic.properties.characteristicValueForeignKey1, 
                    value2); 
            checkRateClassQuery.bindStringProperty("adhocValue1", 
                    GeneralLedgerDistributionCodeCharacteristic.properties.adhocCharacteristicValue, 
                    value1);
            checkRateClassQuery.bindStringProperty("adhocValue2", 
                    GeneralLedgerDistributionCodeCharacteristic.properties.adhocCharacteristicValue, 
                    value2); 
            checkRateClassQuery.bindDate("processDate", processDate);

            if (notNull(checkRateClassQuery.firstRow())) {
                checkRateClassQuery.close();
                return Bool.TRUE;
            }

            checkRateClassQuery.close();
            return Bool.FALSE;
        }

        /**
         * This method retrieves Distribution Code Characteristic.
         * @param distCode - General Ledger Distribution Code 
         * @param charType - Characteristic Type
         * @return String
         */
        private String getDistCodeCharacteristic(GeneralLedgerDistributionCode distCode, CharacteristicType charType) {

            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

            StringBuilder sb = new StringBuilder("SELECT ");
            if (charTypeLookup.isPredefinedValue()) {
                sb.append("DCC.CHAR_VAL AS VALUE ");
            }
            else if (charTypeLookup.isForeignKeyValue()) {
                sb.append("DCC.CHAR_VAL_FK1 AS VALUE ");
            }
            else {
                sb.append("DCC.ADHOC_CHAR_VAL AS VALUE ");
            }         

            sb.append("FROM CI_DST_CD_CHAR DCC " +
                    "WHERE DCC.DST_ID = :distCode " +
                    "AND DCC.CHAR_TYPE_CD = :charType " +
					// 2014-01-30 Neha IM-044824 Start changes
					//"AND DCC.EFFDT <= :processDate");
					"AND DCC.EFFDT = (SELECT MAX(CH.EFFDT) FROM CI_DST_CD_CHAR CH WHERE CH.DST_ID = DCC.DST_ID AND CH.EFFDT <= :processDate)");
					//2014-01-30 Neha IM-044824 End changes

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement getDistCodeChar = createPreparedStatement(sb.toString());
            PreparedStatement getDistCodeChar = createPreparedStatement(sb.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            getDistCodeChar.bindEntity("distCode", distCode);
            getDistCodeChar.bindEntity("charType", charType);
            getDistCodeChar.bindDate("processDate", processDate);

            SQLResultRow result = getDistCodeChar.firstRow();
            if (notNull(result)) {
                getDistCodeChar.close();
                return result.getString("VALUE").trim();
            }
            getDistCodeChar.close();
            return null;
        }

        /**
         * This method retrieves Financial Transaction given the Revenue Rate Class.
         * @param revenueRateClass - String
         * @param fercNumber - String
         * @return PreparedStatement
         */
        private PreparedStatement getFinancialTransactions(String revenueRateClass, String fercNumber) {

			// Start changes Neha performance fix 2014-03-02
			 StringBuilder sb = new StringBuilder("SELECT  distinct FT.SA_ID, FT.FT_ID FROM    CI_FT FT, CI_FT_GL FG,CI_DST_CODE_EFF DCE,CI_DST_CD_CHAR DCC ");
            sb.append("WHERE FT.XFER_TO_GL_DT = :processDate AND DCC.EFFDT <= :processDate ");
            sb.append(
                    "AND FT.FT_TYPE_FLG IN (:bsFtType, :bxFtType) " +
					"AND DCE.GL_ACCT LIKE :fercNumber " +
					"AND DCC.CHAR_TYPE_CD = :charType " +
                    "AND (TRIM(DCC.CHAR_VAL) = TRIM(:charValue)) " +
					"AND FG.FT_ID = FT.FT_ID "+
					"AND DCE.DST_ID = FG.DST_ID " +
					"AND DCC.DST_ID = DCE.DST_ID " +
                    "ORDER BY FT.SA_ID");
            //StringBuilder sb = new StringBuilder("SELECT FT.SA_ID, FT.FT_ID FROM CI_FT FT ");

            // JPunza - 2013-07-24 - Start
            //if (dailyFlag.isTrue()) {
            //    sb.append("WHERE FT.XFER_TO_GL_DT = :processDate ");
            //}
            //else {
            //    sb.append("WHERE FT.XFER_TO_GL_DT BETWEEN :startDate AND :endDate ");
            //}
            //sb.append("WHERE FT.XFER_TO_GL_DT = :processDate ");
            // JPunza - 2013-07-24 - End

            //sb.append(
            //        "AND FT.FT_TYPE_FLG IN (:bsFtType, :bxFtType) " +
            //        "AND EXISTS (SELECT 'X' FROM CI_FT_GL FG " +
            //        "   WHERE FG.FT_ID = FT.FT_ID " +
            //        "   AND EXISTS (SELECT 'X' FROM CI_DST_CODE_EFF DCE " +
            //        "      WHERE DCE.DST_ID = FG.DST_ID " + 
            //        "      AND DCE.GL_ACCT LIKE :fercNumber " +
            //        "      AND EXISTS (SELECT 'X' FROM CI_DST_CD_CHAR DCC " +
            //        "         WHERE DCC.DST_ID = DCE.DST_ID " +
            //        "         AND DCC.CHAR_TYPE_CD = :charType " +
                    // CVB - 2013-07-18 - Start
            //        "         AND (TRIM(DCC.CHAR_VAL) = TRIM(:charValue)) " +
                    //  "         AND (TRIM(DCC.CHAR_VAL) = TRIM(:charValue) " +
                    //  "         OR TRIM(DCC.CHAR_VAL_FK1) = TRIM(:charValueFk1) " +
                    //  "         OR TRIM(DCC.ADHOC_CHAR_VAL) = TRIM(:adhocCharValue)) " +
                    // CVB - 2013-07-18 - End

            //        "         AND DCC.EFFDT <= :processDate))) " +
            //        "ORDER BY FT.SA_ID");
			// End changes Neha performance fix 2014-03-02
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement getftQuery = createPreparedStatement(sb.toString());
            PreparedStatement getftQuery = createPreparedStatement(sb.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            getftQuery.bindDate("processDate", processDate);
            // JPunza - 2013-07-24 - Start
            //if (dailyFlag.isFalse()) {                
            //    getftQuery.bindDate("startDate", startDate);
            //    getftQuery.bindDate("endDate", endDate);
            //}
            // JPunza - 2013-07-24 - End
            getftQuery.bindLookup("bsFtType", FinancialTransactionTypeLookup.constants.BILL_SEGMENT);
            getftQuery.bindLookup("bxFtType", FinancialTransactionTypeLookup.constants.BILL_CANCELLATION);
            getftQuery.bindLikableStringProperty("fercNumber", 
                    GeneralLedgerDistributionEff.properties.glAccount , 
                    "____" + fercNumber);
            getftQuery.bindEntity("charType", revenueRateClassCharType);
            getftQuery.bindStringProperty("charValue", 
                    GeneralLedgerDistributionCodeCharacteristic.properties.characteristicValue, 
                    revenueRateClass);
            // CVB - 2013-07-18 - Start
            //getftQuery.bindStringProperty("charValueFk1", 
            //        GeneralLedgerDistributionCodeCharacteristic.properties.characteristicValueForeignKey1, 
            //        revenueRateClass); 
            //getftQuery.bindStringProperty("adhocCharValue", 
            //        GeneralLedgerDistributionCodeCharacteristic.properties.adhocCharacteristicValue, 
            //        revenueRateClass);                 
            // CVB - 2013-07-18 - End
            return getftQuery;
        }

        // JPunza - 2013-07-24 - Start
        ///**
        // * This method writes record to the extract file.
        // *
        // */
        //private void writeRecord() {
        //
        //    CmRevenueModelExtractRecord record = new CmRevenueModelExtractRecord();
        //    record.setRevenueRateClass(getDescription(revenueRateClassCharType, revenueRateClass));
        //    record.setFercNumber(fercNumber);
        //    record.setNumberOfCustomersBilled(Integer.toString(saCount));
        //    record.setNumberOfBills(billCount.toString());
        //    record.setBlock1WinterTherms(block1WinterThermsBilledAmt.toString());
        //    record.setBlock1SummerTherms(block1SummerThermsBilledAmt.toString());
        //    record.setBlock2WinterTherms(block2WinterThermsBilledAmt.toString());
        //    record.setBlock2SummerTherms(block2SummerThermsBilledAmt.toString());
        //    record.setDemandThermsBilled(demandThermsBilledAmt.toString());
        //    record.setAuthorizedOverrunTherms(authorizedOverrunThermsAmt.toString());
        //    record.setUnauthorizedOverrunTherms(unauthorizedOverrunThermsAmt.toString());
        //    record.setBlock1WinterRevenueBilled(block1WinterRevenueBilledAmt.toString());
        //    record.setBlock1SummerRevenueBilled(block1SummerRevenueBilledAmt.toString());
        //    record.setBlock2WinterRevenueBilled(block2WinterRevenueBilledAmt.toString());
        //    record.setBlock2SummerRevenueBilled(block2SummerRevenueBilledAmt.toString());
        //    record.setCustomerChargeBilled(customerChargeBilledAmt.toString());
        //    record.setDemandChargeRevenue(demandChargeRevenueAmt.toString());
        //    record.setISRSRevenueBilled(isrsRevenueBilledAmt.toString());
        //    record.setAuthorizedOverrunRevenue(authorizedOverrunRevenueAmt.toString());
        //    record.setUnauthorizedOverrunRevenue(unauthorizedOverrunRevenueAmt.toString());
        //    record.setPGARevenueBilled(pgaRevenueBilledAmt.toString());
        //    record.setACARevenueBilled(acaRevenueBilledAmt.toString());
        //    record.setGRTInRevenue(grtInRevenueAmt.toString());
        //    record.setIARevenue(iaRevenueAmt.toString());
        //    record.setPrincipalRefund(principalRefundAmt.toString());
        //    record.setLacledeIntRefund(lacledeIntRefundAmt.toString());
        //    record.setGRTRefund(grtRefundAmt.toString());
        //    record.setStateSalesTax(stateSalesTaxAmt.toString());
        //    record.setCitySalesTax(citySalesTaxAmt.toString());
        //    record.setTransportationStorageRevenue(transportationStorageRevenueAmt.toString());
        //
        //    try {
        //        bufferedWriter.write(record.createRecordString());
        //        bufferedWriter.newLine();
        //    }
        //   catch (Exception e) {
        //       addError(CustomMessageRepositoryMDC.NI0034_1_errorWhileAccessingFile(e.getMessage()));
        //    }
        //}
        // JPunza - 2013-07-24 - End
        
        // CVB - 2013-07-22 - Start
        private void insertRecord() {

            StringBuilder insertSQLString = new StringBuilder();

            insertSQLString.append(" INSERT INTO CM_REV_MODEL            ");
            insertSQLString.append("   (                                 ");
            insertSQLString.append("     CM_REV_RATE_CLASS,              ");
            insertSQLString.append("     CM_FERC_NBR,                    ");
            insertSQLString.append("     XFER_TO_GL_DT,                  ");
            insertSQLString.append("     CM_RATE_CLASS_DESCR,            ");
            insertSQLString.append("     TOTAL_CNT,                      ");
            insertSQLString.append("     CM_BILL_CNT,                    ");
            insertSQLString.append("     CM_BLK1_WNTR_THERMS,            ");
            insertSQLString.append("     CM_BLK1_SUMR_THERMS,            ");
            insertSQLString.append("     CM_BLK2_WNTR_THERMS,            ");
            insertSQLString.append("     CM_BLK2_SUMR_THERMS,            ");
            insertSQLString.append("     CM_DEMAND_THERMS,               ");
            insertSQLString.append("     CM_AUTH_OVERRUN_THERMS,         ");
            insertSQLString.append("     CM_UNAUTH_OVERRUN_THERMS,       ");
            insertSQLString.append("     CM_BLK1_WNTR_REV,               ");
            insertSQLString.append("     CM_BLK1_SUMR_REV,               ");
            insertSQLString.append("     CM_BLK2_WNTR_REV,               ");
            insertSQLString.append("     CM_BLK2_SUMR_REV,               ");
            insertSQLString.append("     CM_CUST_CHG,                    ");
            insertSQLString.append("     CM_DEMAND_CHG,                  ");
            insertSQLString.append("     CM_ISRS_REV,                    ");
            insertSQLString.append("     CM_AUTH_OVERRUN_REV,            ");
            insertSQLString.append("     CM_UNAUTH_OVERRUN_REV,          ");
            insertSQLString.append("     CM_PGA_REV,                     ");
            insertSQLString.append("     CM_ACA_REV,                     ");
            insertSQLString.append("     CM_GRT_IN_REV,                  ");
            insertSQLString.append("     CM_IA_REV,                      ");
            insertSQLString.append("     CM_PRINCIPAL_REFUND,            ");
            insertSQLString.append("     CM_LACLEDE_INT_REFUND,          ");
            insertSQLString.append("     CM_GRT_REFUND,                  ");
            insertSQLString.append("     CM_STATE_SALES_TAX,             ");
            insertSQLString.append("     CM_CITY_SALES_TAX,              ");
            insertSQLString.append("     CM_TRANSPO_STORAGE_REV,         ");
            insertSQLString.append("     VERSION                         ");
            insertSQLString.append("   )                                 ");
            insertSQLString.append("   VALUES                            ");
            insertSQLString.append("   (                                 ");
            insertSQLString.append("     :cmRevRateClass,                ");
            insertSQLString.append("     :cmFercNbr,                     ");
            insertSQLString.append("     :xferToGLDate,                  ");
            insertSQLString.append("     :cmRevRateClassDescr,           ");
            insertSQLString.append("     :nbrOfCustBilled,               ");
            insertSQLString.append("     :nbrOfBills,                    ");
            insertSQLString.append("     :block1WinterTherms,            ");
            insertSQLString.append("     :block1SummerTherms,            ");
            insertSQLString.append("     :block2WinterTherms,            ");
            insertSQLString.append("     :block2SummerTherms,            ");
            insertSQLString.append("     :demandThermsBilled,            ");
            insertSQLString.append("     :authorizedOverrunTherms,       ");
            insertSQLString.append("     :unauthorizedOverrunTherms,     ");
            insertSQLString.append("     :block1WinterRevenue,           ");
            insertSQLString.append("     :block1SummerRevenue,           ");
            insertSQLString.append("     :block2WinterRevenue,           ");
            insertSQLString.append("     :block2SummerRevenue,           ");
            insertSQLString.append("     :custChargeBilled,              ");
            insertSQLString.append("     :demandChargeRevenue,           ");
            insertSQLString.append("     :isrsRevenue,                   ");
            insertSQLString.append("     :authorizedOverrunRevenue,      ");
            insertSQLString.append("     :unauthorizedOverrunRevenue,    ");
            insertSQLString.append("     :pgaRevenue,                    ");
            insertSQLString.append("     :acaRevenue,                    ");
            insertSQLString.append("     :grtRevenue,                    ");
            insertSQLString.append("     :iaRevenue,                     ");
            insertSQLString.append("     :principalRefund,               ");
            insertSQLString.append("     :lacledeInterestRefund,         ");
            insertSQLString.append("     :grtRefund,                     ");
            insertSQLString.append("     :stateSalesTax,                 ");
            insertSQLString.append("     :citySalesTax,                  ");
            insertSQLString.append("     :transportationStorageRevenue,  ");
            insertSQLString.append("     1                               ");
            insertSQLString.append("   )                                 ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement insertCMRevenueModelEntry = createPreparedStatement(insertSQLString.toString());
            PreparedStatement insertCMRevenueModelEntry = createPreparedStatement(insertSQLString.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            insertCMRevenueModelEntry.bindString("cmRevRateClass", revenueRateClass, "CHAR_VAL");
            insertCMRevenueModelEntry.bindString("cmFercNbr", fercNumber, "WFM_OPT_VAL");
            insertCMRevenueModelEntry.bindDate("xferToGLDate", processDate);
            insertCMRevenueModelEntry.bindString("cmRevRateClassDescr", getDescription(revenueRateClassCharType, revenueRateClass), "DESCR");

            insertCMRevenueModelEntry.bindBigInteger("nbrOfCustBilled", BigInteger.valueOf(saCount));
            insertCMRevenueModelEntry.bindBigDecimal("nbrOfBills", billCount);
            insertCMRevenueModelEntry.bindBigDecimal("block1WinterTherms", block1WinterThermsBilledAmt);
            insertCMRevenueModelEntry.bindBigDecimal("block1SummerTherms", block1SummerThermsBilledAmt);
            insertCMRevenueModelEntry.bindBigDecimal("block2WinterTherms", block2WinterThermsBilledAmt);
            insertCMRevenueModelEntry.bindBigDecimal("block2SummerTherms", block2SummerThermsBilledAmt);
            insertCMRevenueModelEntry.bindBigDecimal("demandThermsBilled", demandThermsBilledAmt);
            insertCMRevenueModelEntry.bindBigDecimal("authorizedOverrunTherms", authorizedOverrunThermsAmt);
            insertCMRevenueModelEntry.bindBigDecimal("unauthorizedOverrunTherms", unauthorizedOverrunThermsAmt);      
            insertCMRevenueModelEntry.bindBigDecimal("block1WinterRevenue", block1WinterRevenueBilledAmt);
            insertCMRevenueModelEntry.bindBigDecimal("block1SummerRevenue", block1SummerRevenueBilledAmt);
            insertCMRevenueModelEntry.bindBigDecimal("block2WinterRevenue", block2WinterRevenueBilledAmt);
            insertCMRevenueModelEntry.bindBigDecimal("block2SummerRevenue", block2SummerRevenueBilledAmt);
            insertCMRevenueModelEntry.bindBigDecimal("custChargeBilled", customerChargeBilledAmt);
            insertCMRevenueModelEntry.bindBigDecimal("demandChargeRevenue", demandChargeRevenueAmt);
            insertCMRevenueModelEntry.bindBigDecimal("isrsRevenue", isrsRevenueBilledAmt);
            insertCMRevenueModelEntry.bindBigDecimal("authorizedOverrunRevenue", authorizedOverrunRevenueAmt);
            insertCMRevenueModelEntry.bindBigDecimal("unauthorizedOverrunRevenue", unauthorizedOverrunRevenueAmt);
            insertCMRevenueModelEntry.bindBigDecimal("pgaRevenue", pgaRevenueBilledAmt);
            insertCMRevenueModelEntry.bindBigDecimal("acaRevenue", acaRevenueBilledAmt);
            insertCMRevenueModelEntry.bindBigDecimal("grtRevenue", grtInRevenueAmt);
            insertCMRevenueModelEntry.bindBigDecimal("iaRevenue", iaRevenueAmt);
            insertCMRevenueModelEntry.bindBigDecimal("principalRefund", principalRefundAmt);
            insertCMRevenueModelEntry.bindBigDecimal("lacledeInterestRefund", lacledeIntRefundAmt);
            insertCMRevenueModelEntry.bindBigDecimal("grtRefund", grtRefundAmt);
            insertCMRevenueModelEntry.bindBigDecimal("stateSalesTax", stateSalesTaxAmt);
            insertCMRevenueModelEntry.bindBigDecimal("citySalesTax", citySalesTaxAmt);
            insertCMRevenueModelEntry.bindBigDecimal("transportationStorageRevenue", transportationStorageRevenueAmt);

            insertCMRevenueModelEntry.execute();
        }
        // CVB - 2013-07-22 - End

        /**
         * This method retrieves Language Description given the Characteristic Value.
         * @param charType - Characteristic Type
         * @param charValue - String
         * @return String
         */
        private String getDescription(CharacteristicType charType, String charValue) {

            CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charType, charValue);
            CharacteristicValue charValueEntity = charValueId.getEntity();
            if (notNull(charValueEntity)) {                                
                return charValueEntity.fetchLanguageDescription();
            }

            return new String();
        }

        @Override
        public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {

            // CVB - 2013-07-22 - Start
            //try {
            //    bufferedWriter.close();
            //}
            //catch (Exception e) {
            //    addError(CustomMessageRepositoryMDC.NI0034_1_errorWhileAccessingFile(e.getMessage()));
            //}
            // CVB - 2013-07-22 - End
        }
    }
    
    // CVB - 2013-07-22 - Start
    private void deleteRecordsInTempTable(){
        StringBuilder purgeString = new StringBuilder();
        purgeString.append("DELETE FROM CM_REV_MODEL WHERE XFER_TO_GL_DT = :processDate ");
        
        //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement purgePrepStmt = createPreparedStatement(purgeString.toString());
        PreparedStatement purgePrepStmt = createPreparedStatement(purgeString.toString(), getClass().getName());
        //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        purgePrepStmt.bindDate("processDate", getProcessDateTime().getDate());
        purgePrepStmt.execute();
        purgePrepStmt.close();
    }
    // CVB - 2013-07-22 - End
}
