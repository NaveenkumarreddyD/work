/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPCXCLX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      RI0016. Initial Version. 
 * 2016-05-23   MPang       Defect 3439849. Added close connection to avoid
 *                          UniversalPoolConnectionException.   
 * 2016-09-27   SFelip      Defect 3512842. Add a warning if the 
 *                          ADDRESS-FOUND-SW of Cmpcxccx returns N.
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.  
 * 2021-06-11   RDizon      CCB034.Issue2. Add COLL-DUE-DT extract field in
 *                          1200 Collection Process Record type.   
 * 2022-10-24   DLampa      E-06060. Extract the bill format flag depending 
 *                          on the account's CIS Division. 
 * 2025-11-14   EQuint      CCB25.4 Upgrade           
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.letterTemplate.algorithm.letterExtract;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.batch.batchRun.BatchRun;
import com.splwg.base.domain.common.algorithm.Algorithm;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.domain.report.reportDefinition.ReportDefinition;
import com.splwg.base.domain.report.reportDefinition.ReportDefinition_Id;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.letterTemplate.algorithm.letterExtract.LetterTemplateLetterExtractAlgorithmSpot;
import com.splwg.ccb.domain.admin.letterTemplate.entity.LetterTemplate;
import com.splwg.ccb.domain.common.fileHelper.FileHelper;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpcxclx;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = finalLoansCustomerContactType, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = nbrOfDaysGracePeriod, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = cisDivisionForFormat, required = true, type = string)})
 */
public class CmCreateCollectionEventLetterExtractAlgComp_Impl extends
		CmCreateCollectionEventLetterExtractAlgComp_Gen implements
		LetterTemplateLetterExtractAlgorithmSpot {	
	
	// hard parameters
	private BigInteger customerContactExtractedCount;
	private ReportDefinition reportDefinition;
	private BatchRun batchRun;
	private CustomerContact customerContact;
	private String extractFileName;
	private FileHelper fileHelper;
	private Bool isFieldDelimited;
	private Bool isFirstHeaderDelimited;
	private Algorithm letterExtractAlgorithm;
	private LetterTemplate letterTemplate;
	private CustomerContact toCustomerContact;
	
	// Start Add - RDizon - CCB034.Issue2 - 06-11-2021
	// Soft Parameters
	private String parmFinalLoansCustomerContactType;
	private BigInteger parmNbrOfDaysGracePeriod;
	// End Add - RDizon - CCB034.Issue2 - 06-11-2021
    // Start Add - E-06060 - DLampa - 10-24-2022
    private String parmCisDivisionsForFormat;
    // End Add - E-06060 - DLampa - 10-24-2022	
	
	private Cmpcxclx cmpcxclx;
	
	//Start Add - MPang - Defect 3439849 - 2016-05-23
    private Connection connection;
    //End Add - MPang - Defect 3439849 - 2016-05-23
    // Start Add - E-06060 - DLampa - 10-24-2022
    private ArrayList<CisDivision> wCisDivisionsForFormat = new ArrayList<CisDivision>();
    // End Add - E-06060 - DLampa - 10-24-2022     
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";

	// Start Add - RDizon - CCB034.Issue2 - 06-11-2021
	private static final DateFormat FORMAT_YYYY_MM_DD = new DateFormat("yyyy-MM-dd");
	// End Add - RDizon - CCB034.Issue2 - 06-11-2021
	
	@Override
	public BigInteger getCustomerContactExtractedCount() {
		return customerContactExtractedCount;
	}

	@Override
	public ReportDefinition getReportDefinition() {
		return reportDefinition;
	}

	@Override
	public void setBatchRun(BatchRun arg0) {
		batchRun = arg0;
	}

	@Override
	public void setCustomerContact(CustomerContact arg0) {
		customerContact = arg0;
	}

	@Override
	public void setCustomerContactExtractedCount(BigInteger arg0) {
		customerContactExtractedCount = arg0;
	}

	@Override
	public void setExtractFileName(String arg0) {
		extractFileName = arg0;
	}

	@Override
	public void setFileHelper(FileHelper arg0) {
		fileHelper = arg0;
	}

	@Override
	public void setIsFieldDelimited(Bool arg0) {
		isFieldDelimited = arg0;
	}

	@Override
	public void setIsFirstHeaderDelimited(Bool arg0) {
		isFirstHeaderDelimited = arg0;
	}

	@Override
	public void setLetterExtractAlgorithm(Algorithm arg0) {
		letterExtractAlgorithm = arg0;
	}

	@Override
	public void setLetterTemplate(LetterTemplate arg0) {
		letterTemplate = arg0;
	}

	@Override
	public void setToCustomerContact(CustomerContact arg0) {
		toCustomerContact = arg0;
	}
	
	
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		// Start Add - RDizon - CCB034.Issue2 - 06-11-2021
		// Retrieve Soft Parameters
		parmFinalLoansCustomerContactType = getFinalLoansCustomerContactType();
		parmNbrOfDaysGracePeriod = getNbrOfDaysGracePeriod();
		
		if (parmNbrOfDaysGracePeriod.compareTo(BigInteger.ZERO) <= 0) {
			addError(CustomMessageRepositorySpireOne.CCB034_AlgParmMustBePositive(
					getAlgorithm().getAlgorithmType().getParameterAt(1).fetchLanguageParameterLabel(),
					parmNbrOfDaysGracePeriod.toString()));
		}
		// End Add - RDizon - CCB034.Issue2 - 06-11-2021
		
        // Start Add - E-06060 - DLampa - 10-24-2022
        // CIS Divisions for Format
        parmCisDivisionsForFormat = getCisDivisionForFormat();
        String[] cisDivisions = parmCisDivisionsForFormat.split(",");

        for (int i=0; i < cisDivisions.length; i++){
            String cisDivStr = cisDivisions[i];
            CisDivision cisDivision = new CisDivision_Id(cisDivStr.trim()).getEntity();
            if (isNull(cisDivision)){
                addError(CustomMessageRepositorySpireOne.E06060_AlgParmContainsInvalidCisDivision(
                        getAlgorithm().getAlgorithmType().getParameterAt(2).fetchLanguageParameterLabel(),
                        cisDivStr));
            }
            wCisDivisionsForFormat.add(cisDivision);
        }
        // End Add - E-06060 - DLampa - 10-24-2022 			
		
	}

	@Override
	public void invoke() {
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			if(notNull(customerContact)) {
				cmpcxclx.setInputWrkCcId(customerContact.getId().getTrimmedValue());
			}else{
				cmpcxclx.setInputWrkCcId(CobolCode.SPACES.toString());
			}
			if(notNull(batchRun)) {
				cmpcxclx.setInputWrkBatchCd(batchRun.fetchIdBatchControl().getId().getTrimmedValue());
				cmpcxclx.setInputWrkBatchNbr(java.math.BigDecimal.valueOf(batchRun.fetchIdBatchNumber().doubleValue()));
			}else{
				cmpcxclx.setInputWrkBatchCd(CobolCode.SPACES.toString());
				cmpcxclx.setInputWrkBatchNbr(java.math.BigDecimal.ZERO);
			}
			if(notNull(letterTemplate)) {
				cmpcxclx.setInputWrkLtrTmplCd(letterTemplate.getId().getTrimmedValue());
			}else{
				cmpcxclx.setInputWrkLtrTmplCd(CobolCode.SPACES.toString());
			}
			if (notNull(letterExtractAlgorithm)) {
				cmpcxclx.setExtractAlgCd(letterExtractAlgorithm.getId().getTrimmedValue());
			}else{
				cmpcxclx.setExtractAlgCd(CobolCode.SPACES.toString());
			}
			if(notBlank(extractFileName)) {
				cmpcxclx.setExtractFileName(extractFileName.trim());
			}else{
				cmpcxclx.setExtractFileName(CobolCode.SPACES.toString());
			}
			
			if(notNull(isFieldDelimited)) {
				String isFieldDelimitedSw = (isFieldDelimited.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpcxclx.setFieldDelimSw(isFieldDelimitedSw);
			}else{
				cmpcxclx.setFieldDelimSw(CobolCode.SPACES.toString());
			}
			if(notNull(isFirstHeaderDelimited)) {
				String isFirstHeaderDelimitedSw = (isFirstHeaderDelimited.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpcxclx.setDelim_1stHeaderSw(isFirstHeaderDelimitedSw);
			}else{
				cmpcxclx.setDelim_1stHeaderSw(CobolCode.SPACES.toString());
			}
			if(notNull(toCustomerContact)) {
				cmpcxclx.setToCcId(toCustomerContact.getId().getTrimmedValue());
			}else{
				cmpcxclx.setToCcId(CobolCode.SPACES.toString());
			}
			if (notNull(customerContactExtractedCount)) {
				cmpcxclx.setCcExtractedCnt(java.math.BigDecimal.valueOf(customerContactExtractedCount.doubleValue()));
			}else{
				cmpcxclx.setCcExtractedCnt(java.math.BigDecimal.ZERO);
			}
			// Start Add - RDizon - CCB034.Issue2 - 06-11-2021
			if (customerContact.getCustomerContactType().getId().getContactType().trim().equalsIgnoreCase(parmFinalLoansCustomerContactType)){
				Date collDueDt = getSystemDateTime().getDate().addDays(parmNbrOfDaysGracePeriod.intValue());
				cmpcxclx.setCollDueDt(collDueDt.toString(FORMAT_YYYY_MM_DD));
			}
			else {
				cmpcxclx.setCollDueDt(CobolCode.SPACES.toString());
			}
			// End Add - RDizon - CCB034.Issue2 - 06-11-2021
			
	        // Start Add - E-06060 - DLampa - 10-24-2022
			cmpcxclx.setAlgParmVal(1, getBillFormatFlag());
	        // End Add - E-06060 - DLampa - 10-24-2022
			
			// invoke the main method
		    cmpcxclx.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
		    //Start Delete - MPang - Defect 3439849 - 2016-05-23
		    //ex.printStackTrace();
		    //End Delete - MPang - Defect 3439849 - 2016-05-23
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmpcxclx.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmpcxclx.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmpcxclx.getMessageParm(i);
			    			if (notBlank(cmpcxclx.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmpcxclx.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmpcxclx.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmpcxclx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmpcxclx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    	customerContactExtractedCount = cmpcxclx.getCcExtractedCnt().toBigInteger();
		    	reportDefinition = new ReportDefinition_Id(cmpcxclx.getReportCd().trim()).getEntity();
		    	
		    	// Start Add - SFelip - Defect 3512842 - 2016-09-27
                if(cmpcxclx.getIgnoreWarningSw().equals(SWITCH_NO)) {
                    if(cmpcxclx.getOutputWrkAddressFoundSw().equals(SWITCH_NO)) {
                        addWarning(CustomMessageRepository.DEFECT_3512842_addressNotFound(customerContact.getId().getTrimmedValue()));
                    }
                }
                // End Add - SFelip - Defect 3512842 - 2016-09-27
		    	
		    }
		    else {
		        //Start Add - MPang - Defect 3439849 - 2016-05-23
		        ex.printStackTrace();
		        //End Add - MPang - Defect 3439849 - 2016-05-23
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmpcxclx=Session.returnSessionAndCodeToCache(cmpcxclx);
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//			//Start Add - MPang - Defect 3439849 - 2016-05-23
//            try {
//                connection.close();
//            } catch (SQLException e) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
//            }
//            //End Add - MPang - Defect 3439849 - 2016-05-23
         // end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}

	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
        FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
        RequestContext context = session.getRequestContext();
        
        // start update - equint - 2025-11-14 - CCB25.4 Upgrade
 		session.doWork(new ConnectionWork() {
 			
 			@Override
 			public void execute(Connection connection) throws SQLException {
 				try {
 			        String username = connection.getMetaData().getUserName();
 					String url = connection.getMetaData().getURL();
 					
 					CobolSession.setLogSessionStartEnd(false);
 				    cmpcxclx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpcxclx.class);
 					
 					cmpcxclx.getSession().getDbSession().setUpdateConnection(connection);
 					cmpcxclx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
 					
 					// set ZSTAT parameters

 					cmpcxclx.setProcessDt(getProcessDateTime().getDate().toString());
 					cmpcxclx.setProcessDttmSep("-");
 					cmpcxclx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
 					
 					if (session.isOnlineConnection()) { 
 						cmpcxclx.setConnectionFlg(CONNECTION_ONLINE);
 					}
 					else {
 						cmpcxclx.setConnectionFlg(CONNECTION_BATCH);
 					}
 					
 					cmpcxclx.setUserId(context.getUserId());
 					cmpcxclx.setZstatLanguageCd(context.getLanguageCode());
 			        
 			        if (context.ignoreWarnings()) {
 			        	cmpcxclx.setIgnoreWarningSw(SWITCH_YES);
 			        }
 			        else {
 			        	cmpcxclx.setIgnoreWarningSw(SWITCH_NO);
 			        }
 			        
 			        if (session.getBatchInstanceId() != null) {
 			        	cmpcxclx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
 			        	
 					} else {
 						cmpcxclx.setSchedulerId(new BigDecimal(0).toBigDecimal());
 					}
 			        
 			        cmpcxclx.setAppSvcId(context.getSecurityServiceIdContext());
 			        
 			        DatabaseHelper dbHelper = session.getDatabaseHelper();
 			        cmpcxclx.setDbMode(dbHelper.getCobolDBMode());
 			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
 			        //cmpcxclx.setSplHighValue(cmpcxclx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
 			        //cmpcxclx.setSplLowValue(cmpcxclx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
 			        
 			        cmpcxclx.setSplHighValue(cmpcxclx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
 			        cmpcxclx.setSplLowValue(cmpcxclx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
 			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
 			        
 			        cmpcxclx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
 			        
 			        cmpcxclx.setLkExpiryDt(Date.MAX.toString());
 			        
 			        cmpcxclx.setProgramStatus(" ");
 			        
 			        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
 			        cmpcxclx.setCallSeq(";");
 			        cmpcxclx.setMessageAreaProgramName("CMPCXCLX");
 			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
 			        
 			        if (context.getRandomGeneratorSeedSet().isTrue()) {
 			        	cmpcxclx.setRandomGenSeedSw(SWITCH_YES);
 			        	cmpcxclx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
 			        	cmpcxclx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
 			        	cmpcxclx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
 			        	cmpcxclx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
 			        }
 			        else {
 			        	cmpcxclx.setRandomGenSeedSw(SWITCH_NO);
 			        }
 			        
 			        if (context.traceStandardOut()) { 
 			        	cmpcxclx.setTrcStdoutSw(SWITCH_YES);
 			        }
 			        else {
 			        	cmpcxclx.setTrcStdoutSw(SWITCH_NO);
 			        }
 			        
 			        if (context.traceProgramStart()) { 
 			        	cmpcxclx.setTrcProgStartSw(SWITCH_YES);
 			        }
 			        else {
 			        	cmpcxclx.setTrcProgStartSw(SWITCH_NO);
 			        }
 			        
 			        if (context.traceProgramExit()) { 
 			        	cmpcxclx.setTrcProgExitSw(SWITCH_YES);
 			        }
 			        else {
 			        	cmpcxclx.setTrcProgExitSw(SWITCH_NO);
 			        }
 			        
 			        if (context.traceSQL()) { 
 			        	cmpcxclx.setTrcExecSqlSw(SWITCH_YES);
 			        }
 			        else {
 			        	cmpcxclx.setTrcExecSqlSw(SWITCH_NO);
 			        }
 			        
 			        // Set ZMSGN parms
 			        BigInteger messageSequence = session.getMessageSequence();
 			        if (notNull(messageSequence)) {
 			        	cmpcxclx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
 			        }
 			        else {
 			        	cmpcxclx.setMessageSeq(new BigDecimal(0).toBigDecimal());
 			        }
 				}
 				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		 
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//		
//		//Start Change - MPang - Defect 3439849 - 2016-05-23
//        //Connection connection = implementor.getConnectionProvider().getConnection();
//        connection = implementor.getConnectionProvider().getConnection();
//        //End Change - MPang - Defect 3439849 - 2016-05-23		
//		
//        String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmpcxclx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpcxclx.class);
//		
//		cmpcxclx.getSession().getDbSession().setUpdateConnection(connection);
//		cmpcxclx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		
//		// set ZSTAT parameters
//
//		cmpcxclx.setProcessDt(getProcessDateTime().getDate().toString());
//		cmpcxclx.setProcessDttmSep("-");
//		cmpcxclx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmpcxclx.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmpcxclx.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmpcxclx.setUserId(context.getUserId());
//		cmpcxclx.setZstatLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmpcxclx.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxclx.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmpcxclx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmpcxclx.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmpcxclx.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmpcxclx.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmpcxclx.setSplHighValue(cmpcxclx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmpcxclx.setSplLowValue(cmpcxclx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmpcxclx.setSplHighValue(cmpcxclx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmpcxclx.setSplLowValue(cmpcxclx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmpcxclx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmpcxclx.setLkExpiryDt(Date.MAX.toString());
//        
//        cmpcxclx.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmpcxclx.setCallSeq(";");
//        cmpcxclx.setMessageAreaProgramName("CMPCXCLX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmpcxclx.setRandomGenSeedSw(SWITCH_YES);
//        	cmpcxclx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmpcxclx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmpcxclx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmpcxclx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmpcxclx.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmpcxclx.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxclx.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmpcxclx.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxclx.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmpcxclx.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxclx.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmpcxclx.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxclx.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmpcxclx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmpcxclx.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }
 		
 	// end update - equint - 2025-11-14 - CCB25.4 Upgrade

	}

    // Start Add - E-06060 - DLampa - 10-24-2022
    private String getBillFormatFlag() {

        String billFormatFlag = "";        

        if (notNull(customerContact.fetchAccount())) {
            Account acct = customerContact.fetchAccount();
            if (wCisDivisionsForFormat.contains(acct.getDivisionId().getEntity())){          	
                AccountPerson_Id acctPerID = new AccountPerson_Id(customerContact.getPersonId(), acct.getId());
                AccountPerson acctPer = acctPerID.getEntity();

                billFormatFlag = acctPer.getBillFormat().trimmedValue();
            }             
        }    
        
        return billFormatFlag;
    }
    // End Add - E-06060 - DLampa - 10-24-2022
    
}
