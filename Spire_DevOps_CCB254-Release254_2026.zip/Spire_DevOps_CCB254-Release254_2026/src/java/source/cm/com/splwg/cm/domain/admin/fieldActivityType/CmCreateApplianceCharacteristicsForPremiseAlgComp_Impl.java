/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm will create corresponding Premise Characteristics for 
 * the FA's Appliance Characteristics.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2013-03-22	NSiopo		NI0009.3. Initial Version.
 * 2016-01-26   MPang		Updated for CCB v2.4 compilation.
 **************************************************************************/


package com.splwg.cm.domain.admin.fieldActivityType;

import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityTypeFaCompletionAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.premise.Premise;
import com.splwg.ccb.domain.customerinfo.premise.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.PremiseCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;*/
import com.splwg.ccb.domain.admin.fieldActivityType.algorithm.faCompletion.FieldActivityTypeFaCompletionAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.api.lookup.CmPremiseAppliancesControlsLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author nsiopongco
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = applianceFieldActivityCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = featureConfiguration, required = true, type = entity)})
 */
public class CmCreateApplianceCharacteristicsForPremiseAlgComp_Impl 
        extends	CmCreateApplianceCharacteristicsForPremiseAlgComp_Gen 
        implements FieldActivityTypeFaCompletionAlgorithmSpot {

    // Hard Parameter
    private FieldActivity fieldActivity;

    // Soft Parameters
    private CharacteristicType applianceFieldActivityCharType;
    private FeatureConfiguration featureConfiguration;

    // Other variables
    private Premise premise;

    public void setFieldActivity(FieldActivity arg0) {
        this.fieldActivity = arg0;
    }

    
    /**
     * Main Processing
     */
    public void invoke() {
               
        SQLResultRow retrieveApplianceFACharsResultRow;
        String applianceTypeCharVal;
        String applianceTypeCount;
        
        List<SQLResultRow> retrievePremiseCharTypeFromFeatConfigList;
        Iterator retrievePremiseCharTypeFromFeatConfigListIter;
        SQLResultRow retrievePremiseCharTypeFromFeatConfigResultRow;
        String premiseCharTypeStr;
        CharacteristicType_Id premiseCharTypeId;
        CharacteristicEntity_Id charEntityId;
        PremiseCharacteristic premChar;
        CharacteristicType premiseCharType;
        String premCharStr;
        
        // Retrieve Appliance FA Characteristics
        List<SQLResultRow> retrieveApplianceFACharsList = retrieveApplianceFACharacteristics();
        if(retrieveApplianceFACharsList.size() > 0) {
            Iterator retrieveApplianceFACharsIter = retrieveApplianceFACharsList.iterator();

            while(retrieveApplianceFACharsIter.hasNext()) {
                retrieveApplianceFACharsResultRow = (SQLResultRow) retrieveApplianceFACharsIter.next();
                applianceTypeCharVal = (String) retrieveApplianceFACharsResultRow.getString("FACHARVAL");
                applianceTypeCount = (String) retrieveApplianceFACharsResultRow.getString("COUNT");
        
                // Get corresponding Premise Characteristic Type from Feature Configuration
                retrievePremiseCharTypeFromFeatConfigList = retrievePremiseCharTypeFromFeatConfig(applianceTypeCharVal);
                
                if(retrievePremiseCharTypeFromFeatConfigList.size() == 0){
                    addError(CustomMessageRepositoryMDC.NI0009_3_noOptValRetrievedForApplianceType(
                            featureConfiguration.getId().getTrimmedValue()
                            , CmPremiseAppliancesControlsLookup.constants.CM_PREMISE_CHARACTERISTIC_TYPE.getLookupValue().fetchLanguageDescription().trim()
                            , applianceTypeCharVal.trim()));
                }
                else if (retrievePremiseCharTypeFromFeatConfigList.size() > 1){
                    addError(CustomMessageRepositoryMDC.NI0009_3_multipleOptValRetrievedForApplainceType(
                            featureConfiguration.getId().getTrimmedValue()
                            , CmPremiseAppliancesControlsLookup.constants.CM_PREMISE_CHARACTERISTIC_TYPE.getLookupValue().fetchLanguageDescription().trim()
                            , applianceTypeCharVal.trim()));
                }
                else {
                    retrievePremiseCharTypeFromFeatConfigListIter = retrievePremiseCharTypeFromFeatConfigList.iterator();
                    retrievePremiseCharTypeFromFeatConfigResultRow = (SQLResultRow) retrievePremiseCharTypeFromFeatConfigListIter.next();
                    premiseCharTypeStr = (String) retrievePremiseCharTypeFromFeatConfigResultRow.getString("PREM_CHAR_TYPE_OPTION");

                    // Check if premiseCharTypeStr is a valid Characteristic Type
                    premiseCharTypeId = new CharacteristicType_Id(premiseCharTypeStr);
                    if(isNull(premiseCharTypeId.getEntity())) {
                        addError(CustomMessageRepositoryMDC.NI0009_3_optValNotAValidCharType(
                                featureConfiguration.getId().getTrimmedValue()
                                , CmPremiseAppliancesControlsLookup.constants.CM_PREMISE_CHARACTERISTIC_TYPE.getLookupValue().fetchLanguageDescription().trim()
                                , premiseCharTypeStr.trim()));
                    }

                    premiseCharType = premiseCharTypeId.getEntity();
                    
                    // Check if premiseCharTypeStr is valid for Premise Entity
                    charEntityId = new CharacteristicEntity_Id(premiseCharTypeId, CharacteristicEntityLookup.constants.PREMISE);
                    if(isNull(charEntityId.getEntity())) {
                        addError(CustomMessageRepositoryMDC.NI0009_3_charTypeInvalidForCharEntity(
                                premiseCharTypeId.getTrimmedValue()
                                , CharacteristicEntityLookup.constants.PREMISE.getLookupValue().fetchLanguageDescription()));
                    }

                    // Check if Premise has an effective characteristic with Characteristic Type equal to premiseCharacteristicType 
                    // and whose Characteristic Value is equal to applianceTypeCount.
                    premise = fieldActivity.getServicePoint().getPremise();
                    premChar = premise.getEffectiveCharacteristic(premiseCharType);
  
                    if(isNull(premChar)) {
                        // Create new Premise Characteristic
                        addPremiseCharacteristic(premiseCharType, applianceTypeCount);
                    }
                    else {
                        // Retrieve Premise Characteristic
                        if(premiseCharType.getCharacteristicType().isPredefinedValue()) {
                            premCharStr = premChar.getCharacteristicValue();
                        }
                        else if(premiseCharType.getCharacteristicType().isForeignKeyValue()) {
                            premCharStr = premChar.getCharacteristicValueForeignKey1();
                        }
                        else {
                            premCharStr = premChar.getAdhocCharacteristicValue();
                        }
                  
                        // If Premise Characteristic Value is not equal to applianeTypeCount
                        if(!premCharStr.trim().equalsIgnoreCase(applianceTypeCount.trim())) {

                            if(premChar.fetchIdEffectiveDate().equals(getProcessDateTime().getDate())) {                      
                                // Update Premise Characteristic
                                updatePremiseCharacteristic(premChar, premiseCharType, applianceTypeCount);
                            }
                            else {                    
                                // Add Premise Characteristic
                                addPremiseCharacteristic(premiseCharType, applianceTypeCount);
                            }
                        }
                    }
                }
            }            
        }
    }


    /**
     * Soft Parameter Validations
     */
    protected void extraSoftParameterValidations(boolean arg0) {
        applianceFieldActivityCharType = this.getApplianceFieldActivityCharacteristicType();
        featureConfiguration = this.getFeatureConfiguration();

        // Validate if Appliance Field Activity Char Type is valid for Field Activity Entity
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(applianceFieldActivityCharType
                , CharacteristicEntityLookup.constants.FIELD_ACTIVITY);
        if(isNull(charEntityId.getEntity())) {
            addError(CustomMessageRepositoryMDC.NI0009_3_charTypeInvalidForCharEntity(
                    applianceFieldActivityCharType.getId().getTrimmedValue(), CharacteristicEntityLookup.constants.FIELD_ACTIVITY.getLookupValue().fetchLanguageDescription().trim()));
        }
    }

    
    /**
     * Retrieves Appliance FA Characteristics
     * @return List of Appliance FA Characteristics
     */
    private List<SQLResultRow> retrieveApplianceFACharacteristics() {
        
        String value;
        
        if(applianceFieldActivityCharType.getCharacteristicType().isPredefinedValue()) {
            value = " FACHAR.CHAR_VAL "; 
        }
        else if(applianceFieldActivityCharType.getCharacteristicType().isForeignKeyValue()) {
            value = " FACHAR.CHAR_VAL_FK1 "; 
        }
        else {
            value = " FACHAR.ADHOC_CHAR_VAL ";
        }
        
        PreparedStatement retrieveApplianceFACharacteristicsQuery = createPreparedStatement(
                " SELECT COUNT("
                + value 
                + " ) AS COUNT , "
                + value 
                + " AS FACHARVAL "
                + " FROM "
                + " CI_FA_CHAR FACHAR "
                + " WHERE "
                + " FACHAR.FA_ID = :fieldActivityId "
                + " AND FACHAR.CHAR_TYPE_CD = :applianceCharType "
                + " GROUP BY " 
              //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
              //  + value);
              	+ value, getClass().getName());
        	 //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        
        retrieveApplianceFACharacteristicsQuery.bindId("fieldActivityId", fieldActivity.getId());
        retrieveApplianceFACharacteristicsQuery.bindEntity("applianceCharType", applianceFieldActivityCharType);

        return retrieveApplianceFACharacteristicsQuery.list();
    }
    
    
    /**
     * Retrieves Premise Char Type from Feature Configuration
     * @param applianceTypeCharVal
     * @return List of Premise Char Type
     */
    private List<SQLResultRow> retrievePremiseCharTypeFromFeatConfig(String applianceTypeCharVal) {
        
        PreparedStatement retrievePremiseCharTypeFromFeatConfigQuery = createPreparedStatement(
                " SELECT "
                + " PREMISECHARTYPEOPTION.WFM_OPT_VAL AS PREM_CHAR_TYPE_OPTION "
                + " FROM "
                + " CI_WFM_OPT APPLIANCETYPEOPTION "
                + " , CI_WFM_OPT PREMISECHARTYPEOPTION "
                + " WHERE "
                + " APPLIANCETYPEOPTION.WFM_NAME = :featureConfiguration "
                + " AND APPLIANCETYPEOPTION.EXT_OPT_TYPE = :applianceTypeOptType "
                + " AND PREMISECHARTYPEOPTION.WFM_NAME = :featureConfiguration "
                + " AND PREMISECHARTYPEOPTION.EXT_OPT_TYPE = :premiseCharTypeOptType "
                + " AND TRIM(:applianceType) = TRIM(APPLIANCETYPEOPTION.WFM_OPT_VAL) "
              //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
               // + " AND APPLIANCETYPEOPTION.SEQ_NUM = PREMISECHARTYPEOPTION.SEQ_NUM ");
        		+ " AND APPLIANCETYPEOPTION.SEQ_NUM = PREMISECHARTYPEOPTION.SEQ_NUM " , getClass().getName());
      //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        retrievePremiseCharTypeFromFeatConfigQuery.bindId("featureConfiguration", featureConfiguration.getId());
        retrievePremiseCharTypeFromFeatConfigQuery.bindLookup("applianceTypeOptType"
                , CmPremiseAppliancesControlsLookup.constants.CM_APPLIANCE_TYPE);
        retrievePremiseCharTypeFromFeatConfigQuery.bindLookup("premiseCharTypeOptType"
                , CmPremiseAppliancesControlsLookup.constants.CM_PREMISE_CHARACTERISTIC_TYPE);
        retrievePremiseCharTypeFromFeatConfigQuery.bindStringProperty("applianceType"
                , FeatureConfigurationOption.properties.value
                , applianceTypeCharVal.trim());

        return retrievePremiseCharTypeFromFeatConfigQuery.list();
    }
    
    
    /**
     * Adds Premise Characteristics
     * @param charType
     * @param charVal
     */
    private void addPremiseCharacteristic(CharacteristicType charType, String charVal) {
        PremiseCharacteristic_DTO premCharDto = premise.getCharacteristics().newChildDTO();
        if(charType.getCharacteristicType().isPredefinedValue()) {
            premCharDto.setCharacteristicValue(charVal);
        }
        else if(charType.getCharacteristicType().isForeignKeyValue()) {
            premCharDto.setCharacteristicValueForeignKey1(charVal);
        }
        else {
            premCharDto.setAdhocCharacteristicValue(charVal);
        }
        
        premise.getCharacteristics().add(premCharDto, charType.getId(), getProcessDateTime().getDate());
    }
    
    
    /**
     * Updates Premise Characteristics
     * 
     * @param premChar
     * @param charType
     * @param charVal
     */
    private void updatePremiseCharacteristic(PremiseCharacteristic premChar, CharacteristicType charType, String charVal) {
        PremiseCharacteristic_DTO premCharDto = premChar.getDTO();
        if(charType.getCharacteristicType().isPredefinedValue()) {
            premCharDto.setCharacteristicValue(charVal);
        }
        else if(charType.getCharacteristicType().isForeignKeyValue()) {
            premCharDto.setCharacteristicValueForeignKey1(charVal);
        }
        else {
            premCharDto.setAdhocCharacteristicValue(charVal);
        }
        
        premChar.setDTO(premCharDto);        
    }
}
