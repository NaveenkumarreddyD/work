/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NI0040.2 Collection Agency Financial Info (Billing)       
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2012-12-04   Arun    NI0040.2. Initial Version.
 * 2013-06-16   Murali  Fix for Defect # 2191 -  // ML20130616
 *                      For Excluding BalFwd Adj's
 * 2016-01-27	MPang	Updated for CCB v2.4 compilation.                   
 **************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.ReferralHistoryReasonLookup;
import com.splwg.ccb.api.lookup.ReferralStatusLookup;
import com.splwg.ccb.api.lookup.SpecialRoleLookup;
import com.splwg.ccb.api.lookup.WriteOffStatusLookup;
//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
/*import com.splwg.ccb.domain.admin.adjustmentType.AdjustmentType;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyHistory;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyHistory_DTO;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyHistory_Id;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral_Id;*/

import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyHistory;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyHistory_DTO;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyHistory_Id;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral_Id;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;

/**
 * @author adevaraj001
 *
 @BatchJob (modules = {}, multiThreaded = true, rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (entityName = adjustmentType, name = BAL_FWD_ADJ_TYPE_CD, required = false, type = entity)})
 */

public class CmCollectionAgencyFinancialUpdateInfo_BatchProcess extends
CmCollectionAgencyFinancialUpdateInfo_BatchProcess_Gen {

    //Soft Parameters
    private static BigInteger parmMaxErrors;

    // ML20130616 - Start    
    
    private static AdjustmentType parmBalFwdAdjType;
   
    // ML20130616 - End


    public void validateSoftParameters(boolean isNewRun){
        parmMaxErrors = getParameters().getSoftMaxErrors();
        if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
            addError(CustomMessageRepository.ni00402MaxErrorInvalid(parmMaxErrors.toString().trim()));
        }
        
        // ML20130616 - Start
        
        parmBalFwdAdjType = getParameters().getBAL_FWD_ADJ_TYPE_CD();        
        
        // ML20130616 - End
    }
    public JobWork getJobWork() {

        StringBuilder sb = new StringBuilder();

        sb.append("SELECT CR.COLL_AGY_REF_ID ");
        sb.append("FROM CI_COLL_AGY_REF CR, CI_WO_PROC WP ");        
        sb.append("WHERE CR.REF_STATUS_FLG = :activeStatus ");
        sb.append("AND CR.START_DT <= :procesingDate ");
        sb.append("AND WP.WO_STATUS_FLG = :writeOffActiveStatus ");
        sb.append("AND WP.WO_PROC_ID = CR.WO_PROC_ID ");
        //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
        //PreparedStatement ps = createPreparedStatement(sb.toString());
        PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
        //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
        ps.bindLookup("activeStatus", ReferralStatusLookup.constants.ACTIVE);
        ps.bindDate("procesingDate", getParameters().getProcessDate());
        ps.bindLookup("writeOffActiveStatus", WriteOffStatusLookup.constants.ACTIVE);

        QueryIterator mainIter = ps.iterate();       
        return createJobWorkForQueryIterator(mainIter, this);
    }

    public ThreadWorkUnit createWorkUnit(QueryResultRow row) {
        ThreadWorkUnit threadUnit = new ThreadWorkUnit();
        CollectionAgencyReferral_Id crId = (CollectionAgencyReferral_Id) row.getId("COLL_AGY_REF_ID", CollectionAgencyReferral.class); 
        threadUnit.setPrimaryId(crId);
        return threadUnit;
    }

    public Class<CmCollectionAgencyFinancialUpdateInfo_BatchProcessWorker> getThreadWorkerClass() {
        return CmCollectionAgencyFinancialUpdateInfo_BatchProcessWorker.class;
    }

    public static class CmCollectionAgencyFinancialUpdateInfo_BatchProcessWorker
    extends CmCollectionAgencyFinancialUpdateInfo_BatchProcessWorker_Gen {

        private BigInteger recordsInError = BigInteger.ZERO;

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new CommitEveryUnitStrategy(this);
        }

        public boolean executeWorkUnit(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {
            CollectionAgencyReferral collectionAgencyReferral  = ((CollectionAgencyReferral_Id )unit.getPrimaryId()).getEntity();
            processCollectionAgencyReferralRecords(collectionAgencyReferral);
            return true;
        }

        private void processCollectionAgencyReferralRecords(CollectionAgencyReferral collectionAgencyReferral){
            if(isNull(collectionAgencyReferral)){
                addError(CustomMessageRepository.ni00402collectionAgencyNotFound(collectionAgencyReferral.entityName(), collectionAgencyReferral.getAccount().toString()));
                handleMaxErrors();
                return;
            }

            List<SQLResultRow>frozenFTlist = getFrozenFTs(collectionAgencyReferral);
            if(frozenFTlist.size() > 0){
                createCollectionAgencyReferralHistoryRecord(collectionAgencyReferral);
            }
        }

        private void createCollectionAgencyReferralHistoryRecord(CollectionAgencyReferral collectionAgencyReferral){

            try{

                BigInteger seqNum = BigInteger.ZERO;
                //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
                // Query<BigInteger> retrieveMaxSeqNumQry = createQuery("FROM CollectionAgencyHistory agencyHistory WHERE agencyHistory.id.collectionReferral = :referralId");
                Query<BigInteger> retrieveMaxSeqNumQry = createQuery(
                		"FROM CollectionAgencyHistory agencyHistory WHERE agencyHistory.id.collectionReferral = :referralId", getClass().getName());
                //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
                retrieveMaxSeqNumQry.bindEntity("referralId", collectionAgencyReferral);
                retrieveMaxSeqNumQry.addResult("seqNum", "MAX(agencyHistory.id.sequence)");
                if(retrieveMaxSeqNumQry.listSize() > 0){
                    seqNum = retrieveMaxSeqNumQry.firstRow();
                }
                seqNum = seqNum.add(BigInteger.ONE);
                startChanges();
                CollectionAgencyHistory_DTO collectionAgencyHistoryDTO = createDTO(CollectionAgencyHistory.class);
                collectionAgencyHistoryDTO.setId(new CollectionAgencyHistory_Id(collectionAgencyReferral, seqNum));
                collectionAgencyHistoryDTO.setCreDt(getProcessDateTime().getDate());
                collectionAgencyHistoryDTO.setReferralAmount(retrieveSABalances(collectionAgencyReferral));
                collectionAgencyHistoryDTO.setReferralHistoryReason(ReferralHistoryReasonLookup.constants.CHANGE_REFERRAL);
                collectionAgencyHistoryDTO.setBatchControlId(collectionAgencyReferral.getCollectionAgency().getBatchControl().getId());
                collectionAgencyHistoryDTO.setBatchNumber(collectionAgencyReferral.getCollectionAgency().getBatchControl().getNextBatchNumber());
                collectionAgencyHistoryDTO.setIsSystemGenerated(Bool.TRUE);
                collectionAgencyHistoryDTO.newEntity();
                saveChanges();

            } catch(ApplicationError appError){
                logError(CustomMessageRepository.ni00402ErrorInCreatingCollectionAgencyReferralHistoryRecord(collectionAgencyReferral.getId().getTrimmedValue(), appError.getServerMessage().getMessageText())); 
            }
        }
        private void handleMaxErrors()
        {
            if(notNull(parmMaxErrors)) {
                if(recordsInError.compareTo(parmMaxErrors) > 0) {
                    throw new RunAbortedException(CustomMessageRepository.ni00402_Max_Error_Exceeded(parmMaxErrors.toString()));
                }
            }
        }

        private List<SQLResultRow> getFrozenFTs(CollectionAgencyReferral collectionAgencyReferral){

            List<SQLResultRow> frozenFTlist = new ArrayList<SQLResultRow>();
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT 'X' FROM CI_FT FT, CI_WO_PROC_SA WPSA, CI_COLL_AGY_REF CR, CI_COLL_AGY_HIS CH ");
            sb.append("WHERE CR.COLL_AGY_REF_ID = :collectionAgencyReferalId ");
            sb.append("AND WPSA.WO_PROC_ID = CR.WO_PROC_ID AND CR.COLL_AGY_REF_ID = CH.COLL_AGY_REF_ID ");
            sb.append("AND CH.CRE_DT = (SELECT MAX (CH1.CRE_DT) FROM CI_COLL_AGY_HIS CH1 WHERE CH1.COLL_AGY_REF_ID = CR.COLL_AGY_REF_ID) ");
            sb.append("AND CH.SEQ_NUM = (SELECT MAX(CH1.SEQ_NUM) FROM CI_COLL_AGY_HIS CH1 WHERE CH1.COLL_AGY_REF_ID = CR.COLL_AGY_REF_ID) ");
            sb.append("AND FT.SA_ID = WPSA.SA_ID AND TRUNC(FT.FREEZE_DTTM) > CH.CRE_DT ");
            sb.append("AND FT.FREEZE_DTTM <= :processingDateTime AND FT.FREEZE_SW = :isFrozen ");
            sb.append("AND  NOT EXISTS (SELECT 'X' FROM CI_ADJ ADJ, CI_SA SA WHERE ADJ.ADJ_ID = FT.SIBLING_ID ");
            sb.append("                 AND SA.SA_ID = ADJ.SA_ID AND ADJ.XFER_ADJ_ID IS NOT NULL ");
            sb.append("                 AND (EXISTS (SELECT 'X' FROM CI_ADJ ADJ2, CI_SA SA2 , CI_WO_PROC_SA WPSA ");
            sb.append("                              WHERE ADJ2.ADJ_ID = ADJ.XFER_ADJ_ID AND WPSA.WO_PROC_ID = CR.WO_PROC_ID ");
            sb.append("                              AND ADJ2.SA_ID = WPSA.SA_ID AND SA2.SA_ID = ADJ2.SA_ID ");
            sb.append("                              AND SA2.CHAR_PREM_ID = SA.CHAR_PREM_ID) ");
            sb.append("                   OR EXISTS (SELECT 'X' FROM CI_ADJ ADJ3, CI_SA SA3, CI_SA_TYPE STYPE ");
            sb.append("                              WHERE ADJ3.ADJ_ID = ADJ.XFER_ADJ_ID AND ADJ3.SA_ID = SA3.SA_ID ");
            sb.append("                              AND SA3.SA_TYPE_CD = STYPE.SA_TYPE_CD ");
            sb.append("                              AND STYPE.SPECIAL_ROLE_FLG = :writeOff))) "); 
            
            // ML20130616 - Start - For Exlcuding the Balance Fwd Adjuustments created as a part of Conversion
            
            if(!isNull(parmBalFwdAdjType)){
                sb.append("  AND NOT EXISTS ( SELECT 'X' FROM CI_ADJ ADJ where ADJ.ADJ_ID = FT.SIBLING_ID AND ADJ.ADJ_TYPE_CD = :balFwdAdjTypeCd )  ");
            }
            
            // ML20130616 - End
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement ps = createPreparedStatement(sb.toString());
            PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            ps.bindId("collectionAgencyReferalId", collectionAgencyReferral.getId());
            ps.bindDateTime("processingDateTime", getProcessDateTime());
            ps.bindLookup("writeOff", SpecialRoleLookup.constants.WRITE_OFF);
            ps.bindBoolean("isFrozen", Bool.TRUE);
            
            //ML20130616 - Start            
            if(!isNull(parmBalFwdAdjType)){
                ps.bindEntity("balFwdAdjTypeCd", parmBalFwdAdjType);
              
            }
            // ML20130616 - End
            
            if(!ps.list().isEmpty()){
                frozenFTlist = ps.list();
            }
            ps.close();
            return frozenFTlist;
        }

        private Money retrieveSABalances(CollectionAgencyReferral collectionAgencyReferral){

            Money saBalance = Money.ZERO;
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT SUM(FT.CUR_AMT) AS SABAL FROM CI_FT FT, CI_WO_PROC_SA WPSA, CI_COLL_AGY_REF CR , CI_WO_PROC WP ");
            sb.append("WHERE FT.SA_ID = WPSA.SA_ID AND WPSA.WO_PROC_ID = CR.WO_PROC_ID AND WPSA.WO_PROC_ID = WP.WO_PROC_ID ");
            sb.append("AND CR.COLL_AGY_REF_ID =:collectionAgencyReferalId AND WP.WO_STATUS_FLG = :writeOffActiveStatus ");
            sb.append("AND FT.REDUNDANT_SW = :isRedundant AND FT.NOT_IN_ARS_SW <> :isNotInArrears AND FT.FREEZE_SW = :isFrozen");
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement prepStmt = createPreparedStatement(sb.toString()); 
            PreparedStatement prepStmt = createPreparedStatement(sb.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            prepStmt.bindId("collectionAgencyReferalId", collectionAgencyReferral.getId());
            prepStmt.bindLookup("writeOffActiveStatus", WriteOffStatusLookup.constants.ACTIVE);
            prepStmt.bindBoolean("isRedundant", Bool.FALSE);
            prepStmt.bindBoolean("isNotInArrears", Bool.TRUE);
            prepStmt.bindBoolean("isFrozen", Bool.TRUE);

            saBalance = new Money(prepStmt.firstRow().getBigDecimal("SABAL"), collectionAgencyReferral.getAccount().getCurrency().getId());
            prepStmt.close();
            return saBalance;
        }
    }
}
