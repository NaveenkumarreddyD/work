/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Meter Read Source Feature configuration's Lookup 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2013-04-22   RaviTeja     NI028.7. Initial Version. 
 **************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author rgullapall003
 *
 @LookupFieldname (value = XMRS_OPT_TYP_FLG)
 */
public class CmInformationalMeterReadSourceOptionLookup_Impl 
extends CmInformationalMeterReadSourceOptionLookup_Gen {

}

