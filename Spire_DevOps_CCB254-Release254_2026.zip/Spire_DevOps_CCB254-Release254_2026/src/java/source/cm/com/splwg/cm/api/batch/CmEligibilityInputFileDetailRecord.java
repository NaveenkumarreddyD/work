/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Record Layout for Custom Eligibility Input File Detail Record
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-04-24   RDizon  NI0026.1 Initial Version.
 * 2017-08-30   JRoxas  SA-223039. Added Pledge Amount field.
 **************************************************************************/

package com.splwg.cm.api.batch;

import java.util.Arrays;
import java.util.List;


public class CmEligibilityInputFileDetailRecord {
    
    // Detail Record Fields
    private String fileId = "";
    private String accountId = "";
    private String applicantSSN = "";
    private String coApplicantSSN = "";
    private String eligibilityUnderReviewFlag = "";
    
    // SA-223039 - 08/30/2017 - Start Add
    private String pledgeAmount = "";
    // SA-223039 - 08/30/2017 - End Add
    
    /*
     * Constructor
     * @param record String
     */
    public CmEligibilityInputFileDetailRecord (String detailRecord){
      List<String> detailRecordFields = Arrays.asList(detailRecord.split(",", -1));
      fileId = detailRecordFields.get(0);
      accountId = detailRecordFields.get(1);
      applicantSSN = detailRecordFields.get(2);
      coApplicantSSN = detailRecordFields.get(3);
      eligibilityUnderReviewFlag = detailRecordFields.get(4);
      // SA-223039 - 08/30/2017 - Start Add
      pledgeAmount = detailRecordFields.get(5);
      // SA-223039 - 08/30/2017 - End Add
    }
    
    /**
     * Get the File ID
     * @return fileId File ID
     */
    public String getFileId(){
        return fileId;
    }
    
    
    /**
     * Get the Account ID
     * @return accountId Account ID
     */
    public String getAccountId(){
        return accountId;
    }
    
    /**
     * Get the Applicant SSN
     * @return applicantSSN Applicant SSN
     */
    public String getApplicantSSN(){
        return applicantSSN;
    }
    
    /**
     * Get the Co-Applicant SSN
     * @return coApplicantSSN Co-Applicant SSN
     */
    public String getCoApplicantSSN(){
        return coApplicantSSN;
    }
    
    /**
     * Get the Eligibility Under Review Flag
     * @return eligibilityUnderReviewFlag Eligibility Under Review Flag
     */
    public String getEligibilityUnderReviewFlag(){
        return eligibilityUnderReviewFlag;
    }
    
    // SA-223039 - 08/30/2017 - Start Add
    /**
     * Get the Pledge Amount
     * @return pledgeAmount Pledge Amount
     */
    public String getPledgeAmount(){
        return pledgeAmount;
    }
    // SA-223039 - 08/30/2017 - End Add
    
}
