/*******************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * Extract CIS Attributes
 *
 * This batch process will extract all the necessary Meter, Register, Service    
 * Point, Account, Service Agreement, and other information of all the Meters 
 * that are currently installed at a Service Point and generate the CIS
 * Attributes file for Dataraker. 
 *
 ********************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-02-21   SMiranda        NI0028.03. Initial Version.
 * 2013-03-14   SMiranda        TIR NI0028.03 - 1. Check first if SA Type's Revenue
 *                              Class is supplied before extracting Revenue Class
 *                              Code.
 * 2016-01-28  	MPang	  		Updated for CCB v2.4 compilation.                             
 ********************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.geographicType.GeographicType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.MeterOnOffStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointMeterEventTypeLookup;
//Start Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.itemType.ItemType;
import com.splwg.ccb.domain.admin.timeOfUse.TimeOfUse;
import com.splwg.ccb.domain.admin.timeOfUse.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure_Id;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.Premise;
import com.splwg.ccb.domain.customerinfo.premise.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.PremiseGeographicLocation_Id;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePointCharacteristic;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.item.Item;
import com.splwg.ccb.domain.meterread.item.ItemCharacteristic;
import com.splwg.ccb.domain.meterread.meter.Meter;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meter.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.Register;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.ServicePointMeterHistory;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.ServicePointMeterHistory_Id;
import com.splwg.cm.api.batch.CmExtractCISAttributesRecord;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;*/

import com.splwg.ccb.domain.admin.itemType.entity.ItemType;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseGeographicLocation_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.item.entity.Item;
import com.splwg.ccb.domain.meterread.item.entity.ItemCharacteristic;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory_Id;
import com.splwg.cm.api.batch.CmExtractCISAttributesRecord;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
//End Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author smiranda
 *
 @BatchJob (rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = TC_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = IUC_SA_SP_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = MTR_SIZE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = UOM_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = TOU_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = itemType, name = AMR_DEVICE_ITEM_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = geographicType, name = GRID_CODE_GEO_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = unitOfMeasure, name = UOM_CORR_REG, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = unitOfMeasure, name = UOM_UNCORR_REG, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CWR_LVL_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP1_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP2_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP3_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP4_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP5_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP6_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP7_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP8_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP9_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP10_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP11_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP12_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP13_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP14_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP15_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP16_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP17_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP18_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP19_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP20_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP21_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP22_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP23_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP24_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = APP25_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = MTR_LOC_REF_FC, required = true, type = entity)})
 */
public class CmExtractCISAttributesBatchProcess extends
        CmExtractCISAttributesBatchProcess_Gen {

    private static final String THREAD_PLACE_HOLDER = "??",
            TC_CHAR_TYPE = "TC_CHAR_TYPE",
            IUC_SA_SP_CHAR_TYPE = "IUC_SA_SP_CHAR_TYPE",
            MTR_SIZE_CHAR_TYPE = "MTR_SIZE_CHAR_TYPE",
            UOM_CHAR_TYPE = "UOM_CHAR_TYPE",
            TOU_CHAR_TYPE = "TOU_CHAR_TYPE",
            CWR_LVL_CHAR_TYPE = "CWR_LVL_CHAR_TYPE",
            APP1_CHAR_TYPE = "APP1_CHAR_TYPE",
            APP2_CHAR_TYPE = "APP2_CHAR_TYPE",
            APP3_CHAR_TYPE = "APP3_CHAR_TYPE",
            APP4_CHAR_TYPE = "APP4_CHAR_TYPE",
            APP5_CHAR_TYPE = "APP5_CHAR_TYPE",
            APP6_CHAR_TYPE = "APP6_CHAR_TYPE",
            APP7_CHAR_TYPE = "APP7_CHAR_TYPE",
            APP8_CHAR_TYPE = "APP8_CHAR_TYPE",
            APP9_CHAR_TYPE = "APP9_CHAR_TYPE",
            APP10_CHAR_TYPE = "APP10_CHAR_TYPE",
            APP11_CHAR_TYPE = "APP11_CHAR_TYPE",
            APP12_CHAR_TYPE = "APP12_CHAR_TYPE",
            APP13_CHAR_TYPE = "APP13_CHAR_TYPE",
            APP14_CHAR_TYPE = "APP14_CHAR_TYPE",
            APP15_CHAR_TYPE = "APP15_CHAR_TYPE",
            APP16_CHAR_TYPE = "APP16_CHAR_TYPE",
            APP17_CHAR_TYPE = "APP17_CHAR_TYPE",
            APP18_CHAR_TYPE = "APP18_CHAR_TYPE",
            APP19_CHAR_TYPE = "APP19_CHAR_TYPE",
            APP20_CHAR_TYPE = "APP20_CHAR_TYPE",
            APP21_CHAR_TYPE = "APP21_CHAR_TYPE",
            APP22_CHAR_TYPE = "APP22_CHAR_TYPE",
            APP23_CHAR_TYPE = "APP23_CHAR_TYPE",
            APP24_CHAR_TYPE = "APP24_CHAR_TYPE",
            APP25_CHAR_TYPE = "APP25_CHAR_TYPE";
    
    public JobWork getJobWork() {
        
        // Select all the Meters that are installed at a Service Point as of the Batch Business Date
        Query mainQuery = createQuery("FROM ServicePointMeterHistory spmh, " +
                        "ServicePointMeterEvent spme, " +
                        "MeterRead mr, " +
                        "MeterConfiguration mcfg " +
                        "WHERE (spmh.removalDateTime IS NULL " +
                        "OR TRUNC(spmh.removalDateTime) > :processDate) " +                      
                        "AND spme.id.spMeterHistory.id = spmh.id " +
                        "AND spme.spMeterEventType = :spMeterEventType " +
                        "AND mr.id = spme.meterRead.id " +
                        "AND TRUNC(mr.readDateTime) <= :processDate " +
                        //Start Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
                        //"AND mcfg.id = mr.meterConfiguration.id");
        				"AND mcfg.id = mr.meterConfiguration.id", getClass().getName());
        				//End Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
        
        mainQuery.bindLookup("spMeterEventType", ServicePointMeterEventTypeLookup.constants.INSTALL);
        mainQuery.bindDate("processDate", getProcessDateTime().getDate());
        mainQuery.addResult("meterId", "mcfg.meter.id");
        mainQuery.addResult("spMhId", "spmh.id");        
        
        // Create work units
        ArrayList<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
        QueryIterator queryIter = mainQuery.iterate();
        while (queryIter.hasNext()) {
            QueryResultRow row = (QueryResultRow) queryIter.next();            
            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId(row.getId("meterId", Meter.class));
            workUnit.addSupplementalData("spMhId",row.getId("spMhId", ServicePointMeterHistory.class));          
            workUnits.add(workUnit);              
        }
        queryIter.close();
        
        return createJobWorkForThreadWorkUnitList(workUnits);        

    }

    @Override
    public void validateSoftParameters(boolean arg0) {                
        
        // Validate that File Path is a valid directory
        if (notBlank(getParameters().getFILE_PATH())){
            File tempPath = new File(getParameters().getFILE_PATH());
            
            if (!tempPath.isDirectory()){
                addError(CustomMessageRepositoryMDC.NI0028_3_filePathInvalid(getParameters().getFILE_PATH()));
            }
        }        
        
        // If running on multiple threads, validate that File Name has place holder for thread number
        if (getParameters().getThreadCount().intValue() > 1){
            if (getParameters().getFILE_NAME().indexOf(THREAD_PLACE_HOLDER) == -1){
                addError(CustomMessageRepositoryMDC.NI0028_3_fileNamePlaceholderMiss());
            }
        }       
        
        // If Max Errors is supplied, validate that it is an integer greater than zero.
        if(notNull(getParameters().getMAX_ERRORS())){            
            if (getParameters().getMAX_ERRORS().intValue() < 0){
                addError(CustomMessageRepositoryMDC.NI0028_3_maxErrorInv());
            }
        }
        
        // Validate that Town Code Characteristic Type is valid for Premise Entity        
        validateCharForEntity(getParameters().getTC_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                TC_CHAR_TYPE);       
        
        // Validate that Irregular Use Code Characteristic Type is valid for SP Entity
        validateCharForEntity(getParameters().getIUC_SA_SP_CHAR_TYPE(), CharacteristicEntityLookup.constants.SERVICE_POINT, 
                IUC_SA_SP_CHAR_TYPE);
        
        // Validate that Irregular Use Code Characteristic Type is valid for SA Entity
        validateCharForEntity(getParameters().getIUC_SA_SP_CHAR_TYPE(), CharacteristicEntityLookup.constants.SERVICE_AGREEMENT, 
                IUC_SA_SP_CHAR_TYPE);
        
        // Validate that Meter Size Characteristic Type is valid for Meter Entity
        validateCharForEntity(getParameters().getMTR_SIZE_CHAR_TYPE(), CharacteristicEntityLookup.constants.METER, 
                MTR_SIZE_CHAR_TYPE);
        
        // Validate that Unit of Measure Characteristic Type is valid for Item Entity
        validateCharForEntity(getParameters().getUOM_CHAR_TYPE(), CharacteristicEntityLookup.constants.ITEM, 
                UOM_CHAR_TYPE);
        
        // Validate that Time of Use Characteristic Type is valid for Item Entity
        if (notNull(getParameters().getTOU_CHAR_TYPE())){
            validateCharForEntity(getParameters().getTOU_CHAR_TYPE(), CharacteristicEntityLookup.constants.ITEM, 
                    TOU_CHAR_TYPE);
        }        
        
        // Validate that CWR Level Characteristic Type is valid for SA Entity
        validateCharForEntity(getParameters().getCWR_LVL_CHAR_TYPE(), CharacteristicEntityLookup.constants.SERVICE_AGREEMENT, 
                CWR_LVL_CHAR_TYPE);
        
        // Validate that Appliance Type 1 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP1_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP1_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP1_CHAR_TYPE);
        }
        
        // Validate that Appliance Type 2 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP2_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP2_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP2_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 3 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP3_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP3_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP3_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 4 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP4_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP4_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP4_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 5 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP5_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP5_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP5_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 6 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP6_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP6_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP6_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 7 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP7_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP7_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP7_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 8 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP8_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP8_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP8_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 9 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP9_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP9_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP9_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 10 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP10_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP10_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP10_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 11 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP11_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP11_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP11_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 12 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP12_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP12_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP12_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 13 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP13_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP13_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP13_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 14 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP14_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP14_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP14_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 15 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP15_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP15_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP15_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 16 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP16_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP16_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP16_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 17 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP17_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP17_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP17_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 18 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP18_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP18_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP18_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 19 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP19_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP19_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP19_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 20 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP20_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP20_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP20_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 21 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP21_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP21_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP21_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 22 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP22_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP22_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP22_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 23 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP23_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP23_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP23_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 24 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP24_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP24_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP24_CHAR_TYPE);
        } 
        
        // Validate that Appliance Type 25 Characteristic Type is valid for Premise Entity
        if (notNull(getParameters().getAPP25_CHAR_TYPE())){
            validateCharForEntity(getParameters().getAPP25_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE, 
                    APP25_CHAR_TYPE);
        } 
        
    }
      
    private void validateCharForEntity(CharacteristicType charType, CharacteristicEntityLookup charEntity, String parmDescr) {
        
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, charEntity);
        if (isNull(charEntityId.getEntity())) {
            addError(CustomMessageRepositoryMDC.NI0028_3_batchParmInvForEntity(parmDescr, 
                    charType.getId().getIdValue().trim(), 
                    charEntity.getLookupValue().fetchLanguageDescription().trim()));
        }
        
    }

    public Class<CmExtractCISAttributesBatchProcessWorker> getThreadWorkerClass() {
        return CmExtractCISAttributesBatchProcessWorker.class;
    }

    public static class CmExtractCISAttributesBatchProcessWorker extends
            CmExtractCISAttributesBatchProcessWorker_Gen {
        
        private long numberOfRecordsProcessed = 0;
        
        // Constants
        private static final String SERVICE_TYPE = "G";
        private static final String UTIL_COMPANY = "LG";
        private static final String UNCORR_REG_MFG_CD = "U";
        private static final String NO = "N";
        private static final String YES = "Y";
        private static final String THREAD_PLACE_HOLDER = "??";               
        
        // Variables for soft parameters
        private String filePath, 
                fileName;
        private BigInteger parmMaxErrors;
        private CharacteristicType townCodeCharType, 
                iucSaSpCharType, 
                meterSizeCharType, 
                uomItemCharType, 
                touItemCharType,
                cwrLevelCharType,
                appType1CharType, 
                appType2CharType, 
                appType3CharType, 
                appType4CharType, 
                appType5CharType, 
                appType6CharType,
                appType7CharType, 
                appType8CharType, 
                appType9CharType, 
                appType10CharType, 
                appType11CharType, 
                appType12CharType,
                appType13CharType, 
                appType14CharType, 
                appType15CharType, 
                appType16CharType, 
                appType17CharType, 
                appType18CharType,
                appType19CharType, 
                appType20CharType, 
                appType21CharType, 
                appType22CharType, 
                appType23CharType, 
                appType24CharType,
                appType25CharType;                
        private ItemType amrDeviceItemType;
        private GeographicType gridCodeGeoType;
        private UnitOfMeasure uomCorrRegister,
                uomUncorrRegister;
        private FeatureConfiguration mtrLocRefFeatureConfig;
        
        // Other variables
        private BufferedWriter bufferedWriter;
        private CmExtractCISAttributesRecord record;        
        private Meter_Id meterId;
        private ServicePointMeterHistory_Id spMhId;
        private MeterConfiguration_Id mtrConfigId = null;
        private ServicePoint_Id spId = null;   
        private ServiceAgreement_Id saId = null;
        private Account_Id accountId = null;
        private Premise_Id premiseId = null;
        private Register correctedRegister = null,
                uncorrectedRegister = null;
        
        // Variables for extract file
        private String manufacturerCode = "",
                readCycle = "",
                readRoute = "",
                townCode = "",
                gridCode = "",
                landlordId = "",
                landlordAccountId = "",
                customerClassCode = "", 
                personId = "",
                revenueClass = "",
                heatGrant = "",
                billCycle = "",
                irregularUseCode = "",
                irregularUseCodeSp = "",
                irregularUseCodeSa = "",
                meterOnOffFlag = "",
                spSourceStatusFlag = "",
                meterSize = "",
                meterLocation = "",
                meterDialCount = "",
                cisDivision = "",
                saTypeCode = "",
                meterMultiplier = "",
                amrDeviceSw = "",
                numberOfApp1 = "",
                numberOfApp2 = "",
                numberOfApp3 = "",
                numberOfApp4 = "",
                numberOfApp5 = "",
                numberOfApp6 = "",
                numberOfApp7 = "",
                numberOfApp8 = "",
                numberOfApp9 = "",
                numberOfApp10 = "",
                numberOfApp11 = "",
                numberOfApp12 = "",
                numberOfApp13 = "",
                numberOfApp14 = "",
                numberOfApp15 = "",
                numberOfApp16 = "",
                numberOfApp17 = "",
                numberOfApp18 = "",
                numberOfApp19 = "",
                numberOfApp20 = "",
                numberOfApp21 = "",
                numberOfApp22 = "",
                numberOfApp23 = "",
                numberOfApp24 = "",
                numberOfApp25 = "";
                
        public ThreadExecutionStrategy createExecutionStrategy() {

            return new StandardCommitStrategy(this);
        }                

        @Override
        public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
            
            // Retrieve batch parameters
            retrieveParameters();
            
            // Replace place holder in file name with current Thread Number
            if (getParameters().getFILE_NAME().indexOf(THREAD_PLACE_HOLDER) != -1){
                fileName = fileName.replace(THREAD_PLACE_HOLDER, this.getBatchThreadNumber().toString());
            }            
            
            // Open the file
            try {
                File extractFile = new File(filePath, fileName);
                bufferedWriter = new BufferedWriter(new FileWriter(extractFile));
            }
            catch (Exception e) {
                e.printStackTrace();
                addError(CustomMessageRepositoryMDC.NI0028_3_fileOpenError());                
            }            
            
        }

        private void retrieveParameters() {
            
            filePath = getParameters().getFILE_PATH();
            fileName = getParameters().getFILE_NAME();
            parmMaxErrors = getParameters().getMAX_ERRORS();
            townCodeCharType = getParameters().getTC_CHAR_TYPE();
            iucSaSpCharType = getParameters().getIUC_SA_SP_CHAR_TYPE();
            meterSizeCharType = getParameters().getMTR_SIZE_CHAR_TYPE();
            uomItemCharType = getParameters().getUOM_CHAR_TYPE();
            touItemCharType = getParameters().getTOU_CHAR_TYPE();
            amrDeviceItemType = getParameters().getAMR_DEVICE_ITEM_TYPE();
            gridCodeGeoType = getParameters().getGRID_CODE_GEO_TYPE();
            uomCorrRegister = getParameters().getUOM_CORR_REG();
            uomUncorrRegister = getParameters().getUOM_UNCORR_REG();
            cwrLevelCharType = getParameters().getCWR_LVL_CHAR_TYPE();
            appType1CharType = getParameters().getAPP1_CHAR_TYPE();
            appType2CharType = getParameters().getAPP2_CHAR_TYPE();
            appType3CharType = getParameters().getAPP3_CHAR_TYPE();
            appType4CharType = getParameters().getAPP4_CHAR_TYPE();
            appType5CharType = getParameters().getAPP5_CHAR_TYPE();
            appType6CharType = getParameters().getAPP6_CHAR_TYPE();
            appType7CharType = getParameters().getAPP7_CHAR_TYPE();
            appType8CharType = getParameters().getAPP8_CHAR_TYPE();
            appType9CharType = getParameters().getAPP9_CHAR_TYPE();
            appType10CharType = getParameters().getAPP10_CHAR_TYPE();
            appType11CharType = getParameters().getAPP11_CHAR_TYPE();
            appType12CharType = getParameters().getAPP12_CHAR_TYPE();
            appType13CharType = getParameters().getAPP13_CHAR_TYPE();
            appType14CharType = getParameters().getAPP14_CHAR_TYPE();
            appType15CharType = getParameters().getAPP15_CHAR_TYPE();
            appType16CharType = getParameters().getAPP16_CHAR_TYPE();
            appType17CharType = getParameters().getAPP17_CHAR_TYPE();
            appType18CharType = getParameters().getAPP18_CHAR_TYPE();
            appType19CharType = getParameters().getAPP19_CHAR_TYPE();
            appType20CharType = getParameters().getAPP20_CHAR_TYPE();
            appType21CharType = getParameters().getAPP21_CHAR_TYPE();
            appType22CharType = getParameters().getAPP22_CHAR_TYPE();
            appType23CharType = getParameters().getAPP23_CHAR_TYPE();
            appType24CharType = getParameters().getAPP24_CHAR_TYPE();
            appType25CharType = getParameters().getAPP25_CHAR_TYPE();
            mtrLocRefFeatureConfig = getParameters().getMTR_LOC_REF_FC();
            
        }

        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {    
            
            numberOfRecordsProcessed = 0;
            
            // Get the Meter ID from the work unit
            meterId = (Meter_Id)unit.getPrimaryId();            
            
            // Get the Service Point Meter History ID from the work unit
            spMhId = (ServicePointMeterHistory_Id)unit.getSupplementallData("spMhId");
                        
            if (notNull(spMhId.getEntity())){
                // Get the Meter Configuration from the Service Point Meter History
                mtrConfigId = spMhId.getEntity().getMeterConfiguration().getId();
                
                // Get the Service Point Id from the Service Point Meter History
                spId = spMhId.getEntity().getServicePoint().getId();
            }                        
            
            // Get the Premise Id from the Service Point Meter History
            if (notNull(spId.getEntity())){
                premiseId = spId.getEntity().getPremise().getId();
            }
            
            // Initialize variables for corrected and uncorrected register   
            correctedRegister = null;
            uncorrectedRegister = null;          
            
            // Get effective corrected register
            Query corrRegisterQuery = retrieveRegister(uomCorrRegister);
            correctedRegister = (Register)corrRegisterQuery.firstRow();                
            
            // Get effective uncorrected register
            Query uncorrRegisterQuery = retrieveRegister(uomUncorrRegister);
            uncorrectedRegister = (Register)uncorrRegisterQuery.firstRow();                
            
            // Create extract record for each corrected and uncorrected register
            if (notNull(correctedRegister) || notNull(uncorrectedRegister)){
                
                // Get SP where meter is currently installed
                Query spQuery = retrieveSp();                                   
                ServicePoint_Id currentSpId = (ServicePoint_Id)spQuery.firstRow();
                
                if (notNull(currentSpId)){
                    // Get the Service Agreement that is currently being billed for the usage of the meter
                    Query saQuery = retrieveSa(currentSpId);
                    saId = null;
                    accountId = null;
                    QueryResultRow saQueryResult = (QueryResultRow) saQuery.firstRow();
                    if (notNull(saQueryResult)){
                        saId = (ServiceAgreement_Id) saQueryResult.getId("saId", ServiceAgreement.class);
                        accountId = (Account_Id) saQueryResult.getId("accountId", Account.class); 
                    }
                }  
                
                // Extract CIS Attributes
                extractCISAttributes();
                
                if (notNull(correctedRegister)){
                    // Extract Corrected Register Attributes
                    extractRegisterAttributes(correctedRegister);
                    // Write Record to file
                    writeExtract();
                    numberOfRecordsProcessed++;
                }                            
                if (notNull(uncorrectedRegister)){
                    // Extract Uncorrected Register Attributes
                    extractRegisterAttributes(uncorrectedRegister);
                    // Write Record to file                    
                    writeExtract();
                    numberOfRecordsProcessed++;
                }                
            }            
            
            WorkUnitResult workUnitResult = new WorkUnitResult(true);
            workUnitResult.setUnitsProcessed((int)numberOfRecordsProcessed);
            workUnitResult.setUnitsInError(0);
            
            return workUnitResult;
        }        

        private Query retrieveRegister(UnitOfMeasure uom){
            
            Query registerQuery = createQuery("FROM Register reg " +
                    "WHERE reg.meterConfiguration.meter.id = :meterId " +
                    "AND reg.meterConfiguration.effectiveDateTime = " +
                            "(SELECT MAX(reg2.meterConfiguration.effectiveDateTime) " +
                            "FROM Register reg2 " +
                            "WHERE reg2.id = reg.id " +
                            "AND TRUNC(reg2.meterConfiguration.effectiveDateTime) <= :processDate) " +
                    //Start Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
                    //"AND reg.unitOfMeasure = :uom");
        			"AND reg.unitOfMeasure = :uom", getClass().getName());
            		//End Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
        
            registerQuery.bindId("meterId", meterId);
            registerQuery.bindDate("processDate", getProcessDateTime().getDate());
            registerQuery.bindEntity("uom", uom);
            
            return registerQuery;
            
        }
        
        private Query retrieveSp() {
            
            Query spQuery = createQuery("FROM ServicePointMeterHistory spMh " +                    
                    "WHERE spMh.meterConfiguration.id = :mtrConfigId " +
                    //Start Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
                    //"AND spMh.removalDateTime IS NULL ");
            		"AND spMh.removalDateTime IS NULL ", getClass().getName());
            		//End Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
            
            spQuery.bindId("mtrConfigId", mtrConfigId);
            spQuery.addResult("spId", "spMh.servicePoint.id");
            
            return spQuery;
            
        }
        
        private Query retrieveSa(ServicePoint_Id currentSpId) {
            
            Query saQuery = createQuery("FROM ServiceAgreementServicePoint saSp, " +
                        "ServiceAgreement sa " +
                        "WHERE saSp.servicePoint.id = :spId " +
                        "AND saSp.serviceAgreement.id = sa.id " +
                        //Start Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
                        //"AND sa.status IN (:active, :pendingStop, :stopped, :reactivated)"); 
            			"AND sa.status IN (:active, :pendingStop, :stopped, :reactivated)", getClass().getName()); 
            			//End Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
            
            saQuery.bindId("spId", currentSpId);
            saQuery.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
            saQuery.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
            saQuery.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
            saQuery.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
            saQuery.addResult("saId", "sa.id");
            saQuery.addResult("accountId", "sa.account.id");           
            
            return saQuery;
        }
        
        private void extractCISAttributes(){
            
            initializeCISVariables();
            
            // Get Read Route. This is the concatenation of the SP's Meter Read Cycle and SP's Meter Read Route.
            if (notNull(spId.getEntity())){
                if (notNull(spId.getEntity().getMeterReadCycleId())){
                    readCycle = spId.getEntity().getMeterReadCycleId().getIdValue();
                }
                readRoute = readCycle.concat(spId.getEntity().getMeterReadRoute());
                
                // Get Irregular Use Code from SP
                irregularUseCodeSp = getSpChar(spId.getEntity(), iucSaSpCharType); 
                
                // SP Source Status Flag
                spSourceStatusFlag = spId.getEntity().getServicePointSourceStatus().getLookupValue().fetchIdFieldValue();
                
                // Get Meter Location
                meterLocation = getMeterLocation();
            }            
                        
            if (notNull(premiseId.getEntity())){
                // Get Town Code Premise Characteristic Value
                townCode = getPremiseChar(premiseId.getEntity(), townCodeCharType);
                
                // Get Grid Code Premise Geographic Location
                PremiseGeographicLocation_Id premGeoLocId = new PremiseGeographicLocation_Id(premiseId.getEntity(), gridCodeGeoType);
                if (notNull(premGeoLocId.getEntity())){
                    gridCode = premGeoLocId.getEntity().getGeographicValue().trim();
                }
                                
                if (notNull(premiseId.getEntity().getLandLordId())){
                    // Get Landlord ID
                    landlordId = premiseId.getEntity().getLandLordId().getIdValue().trim();
                    
                    // Get Landlord Account ID
                    landlordAccountId = premiseId.getEntity().getLandLordId().getEntity().getAccountId().getIdValue().trim();
                } 
                
                // Get Appliance Type 1
                if (notNull(appType1CharType)){
                    numberOfApp1 = getPremiseChar(premiseId.getEntity(), appType1CharType);
                }
                
                // Get Appliance Type 2
                if (notNull(appType2CharType)){               
                    numberOfApp2 = getPremiseChar(premiseId.getEntity(), appType2CharType);
                }

                // Get Appliance Type 3
                if (notNull(appType3CharType)){                
                    numberOfApp3 = getPremiseChar(premiseId.getEntity(), appType3CharType);
                }
                
                // Get Appliance Type 4
                if (notNull(appType4CharType)){
                    numberOfApp4 = getPremiseChar(premiseId.getEntity(), appType4CharType);
                }
                
                // Get Appliance Type 5
                if (notNull(appType5CharType)){
                    numberOfApp5 = getPremiseChar(premiseId.getEntity(), appType5CharType);
                }
                
                // Get Appliance Type 6
                if (notNull(appType6CharType)){
                    numberOfApp6 = getPremiseChar(premiseId.getEntity(), appType6CharType);
                }
                
                // Get Appliance Type 7
                if (notNull(appType7CharType)){
                    numberOfApp7 = getPremiseChar(premiseId.getEntity(), appType7CharType);
                }
                
                // Get Appliance Type 8
                if (notNull(appType8CharType)){
                    numberOfApp8 = getPremiseChar(premiseId.getEntity(), appType8CharType);
                }
                
                // Get Appliance Type 9
                if (notNull(appType9CharType)){
                    numberOfApp9 = getPremiseChar(premiseId.getEntity(), appType9CharType);
                }
                
                // Get Appliance Type 10
                if (notNull(appType10CharType)){
                    numberOfApp10 = getPremiseChar(premiseId.getEntity(), appType10CharType);
                }
                
                // Get Appliance Type 11
                if (notNull(appType11CharType)){
                    numberOfApp11 = getPremiseChar(premiseId.getEntity(), appType11CharType);
                }
                
                // Get Appliance Type 12
                if (notNull(appType12CharType)){
                    numberOfApp12 = getPremiseChar(premiseId.getEntity(), appType12CharType);
                }
                
                // Get Appliance Type 13
                if (notNull(appType13CharType)){
                    numberOfApp13 = getPremiseChar(premiseId.getEntity(), appType13CharType);
                }
                
                // Get Appliance Type 14
                if (notNull(appType14CharType)){
                    numberOfApp14 = getPremiseChar(premiseId.getEntity(), appType14CharType);
                }
                
                // Get Appliance Type 15
                if (notNull(appType15CharType)){
                    numberOfApp15 = getPremiseChar(premiseId.getEntity(), appType15CharType);
                }
                
                // Get Appliance Type 16
                if (notNull(appType16CharType)){
                    numberOfApp16 = getPremiseChar(premiseId.getEntity(), appType16CharType);
                }
                
                // Get Appliance Type 17
                if (notNull(appType17CharType)){
                    numberOfApp17 = getPremiseChar(premiseId.getEntity(), appType17CharType);
                }
                
                // Get Appliance Type 18
                if (notNull(appType18CharType)){
                    numberOfApp18 = getPremiseChar(premiseId.getEntity(), appType18CharType);
                }
                
                // Get Appliance Type 19
                if (notNull(appType19CharType)){               
                    numberOfApp19 = getPremiseChar(premiseId.getEntity(), appType19CharType);
                }
                
                // Get Appliance Type 20
                if (notNull(appType20CharType)){
                    numberOfApp20 = getPremiseChar(premiseId.getEntity(), appType20CharType);
                }
                
                // Get Appliance Type 21
                if (notNull(appType21CharType)){
                    numberOfApp21 = getPremiseChar(premiseId.getEntity(), appType21CharType);
                }
                
                // Get Appliance Type 22
                if (notNull(appType22CharType)){
                    numberOfApp22 = getPremiseChar(premiseId.getEntity(), appType22CharType);
                }
                
                // Get Appliance Type 23
                if (notNull(appType23CharType)){
                    numberOfApp23 = getPremiseChar(premiseId.getEntity(), appType23CharType);
                }
                
                // Get Appliance Type 24
                if (notNull(appType24CharType)){
                    numberOfApp24 = getPremiseChar(premiseId.getEntity(), appType24CharType);
                }
                
                // Get Appliance Type 25
                if (notNull(appType25CharType)){
                    numberOfApp25 = getPremiseChar(premiseId.getEntity(), appType25CharType);
                }
                
            }
            
            // If the Account Id is not blank
            if (notNull(accountId)){   
                if (notNull(accountId.getEntity())){
                    // Get the Customer Class Code
                    if (notNull(accountId.getEntity().getCustomerClass())){
                        customerClassCode = accountId.getEntity().getCustomerClass().getId().getIdValue();
                    }                   
                
                    // Get Main Person of the Account
                    //Start Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
                    //ListFilter mainPerFilter = accountId.getEntity().getPersons().createFilter("WHERE this.isMainCustomer = :true");
                    ListFilter mainPerFilter = accountId.getEntity().getPersons().createFilter("WHERE this.isMainCustomer = :true", getClass().getName());
                    //End Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
                    mainPerFilter.bindBoolean("true", Bool.TRUE);
                    AccountPerson mainPerson = (AccountPerson) mainPerFilter.firstRow();
                    personId = mainPerson.getId().getPersonId().getIdValue();
                
                    // Get the Bill Cycle
                    if (notNull(accountId.getEntity().getBillCycleId())){
                        billCycle = accountId.getEntity().getBillCycleId().getIdValue();
                    }
                }
            }
            
            // If the SA Id is not blank
            if (notNull(saId)){                
                if (notNull(saId.getEntity())){
                    // Get the revenue class from the SA's SA Type
                    // TIR NI0028.03 - 1. Start Change
                    if (notNull(saId.getEntity().getServiceAgreementType().getRevenueClassId())){
                    revenueClass = saId.getEntity().getServiceAgreementType().getRevenueClassId().getIdValue();
                    }
                    // TIR NI0028.03 - 1. End Change
                
                    // Determine if SA has Heat Grant.
                    if (getSaChar(saId.getEntity(), cwrLevelCharType) == ""){
                        heatGrant = NO;
                    }else{
                        heatGrant = YES;
                    }
                
                    // Get the CIS Division from the SA Type
                    cisDivision = saId.getEntity().getServiceAgreementType().fetchIdDivision().getId().getIdValue();
                
                    // Get the SA Type code
                    saTypeCode = saId.getEntity().getServiceAgreementType().getId().getSaType();
                
                    // Get Irregular Use Code from SA
                    irregularUseCodeSa = getSaChar(saId.getEntity(), iucSaSpCharType);
                }
            }                                    
            
            // Do not extract Irregular Use Code if it exists on both SP and SA
            if (irregularUseCodeSp != "" && irregularUseCodeSa == ""){
                irregularUseCode = irregularUseCodeSp;
            }
            
            if (irregularUseCodeSp == "" && irregularUseCodeSa != ""){
                irregularUseCode = irregularUseCodeSa;
            }
            
            // Get Meter On/Off Flag
            meterOnOffFlag = ((MeterOnOffStatusLookup) getMeterStatus().firstRow()).getLookupValue().fetchIdFieldValue();                                                
            
            if (notNull(meterId.getEntity())){
                // Get Meter Size
                meterSize = getMeterChar(meterId.getEntity(), meterSizeCharType);                
            }            
            
        }
        
        private void initializeCISVariables() {
            
            readCycle = "";
            readRoute = "";
            townCode = "";
            gridCode = "";
            landlordId = "";
            landlordAccountId = "";
            customerClassCode = ""; 
            personId = "";
            revenueClass = "";
            heatGrant = "";
            billCycle = "";
            irregularUseCode = "";
            irregularUseCodeSp = "";
            irregularUseCodeSa = "";
            meterOnOffFlag = "";
            spSourceStatusFlag = "";
            meterSize = "";
            meterLocation = "";
            cisDivision = "";
            saTypeCode = "";
            numberOfApp1 = "";
            numberOfApp2 = "";
            numberOfApp3 = "";
            numberOfApp4 = "";
            numberOfApp5 = "";
            numberOfApp6 = "";
            numberOfApp7 = "";
            numberOfApp8 = "";
            numberOfApp9 = "";
            numberOfApp10 = "";
            numberOfApp11 = "";
            numberOfApp12 = "";
            numberOfApp13 = "";
            numberOfApp14 = "";
            numberOfApp15 = "";
            numberOfApp16 = "";
            numberOfApp17 = "";
            numberOfApp18 = "";
            numberOfApp19 = "";
            numberOfApp20 = "";
            numberOfApp21 = "";
            numberOfApp22 = "";
            numberOfApp23 = "";
            numberOfApp24 = "";
            numberOfApp25 = "";
           
        }

        private void extractRegisterAttributes(Register register) {    
            
            initializeRegisterVariables();
            
            /* Get the Manufacturer Code. If the Register that is being extracted is a Corrected Register, the Manufacturer Code field 
             * of the file record is populated with the first letter of the actual Meter Manufacturer Code. If the Register that is being 
             * extracted is an Uncorrected Register, the Manufacturer Code field of the file record is populated with U.
             */
            if (register.getUnitOfMeasure().equals(uomCorrRegister)){
                if (notNull(meterId.getEntity().getModel())){
                    if (notNull(meterId.getEntity().getModel().fetchIdManufacturer())){
                        manufacturerCode = meterId.getEntity().getModel().fetchIdManufacturer().getId().getIdValue().substring(0, 1);
                    }
                }
            }
            if (register.getUnitOfMeasure().equals(uomUncorrRegister)){
                manufacturerCode = UNCORR_REG_MFG_CD;
            }                        
            
            // Get Meter Dial Count
            meterDialCount = register.getNumberOfDigitsLeft().toString();
            
            // Get the Meter Multiplier (Register's Register Constant)
            meterMultiplier = register.getRegisterConstant().toString();
            
            // Determine if AMR Device
            amrDeviceSw = getAmrDevice(register);             
            
        }
        
        private void initializeRegisterVariables() {
            
            manufacturerCode = "";
            meterDialCount = "";
            meterMultiplier = "";
            amrDeviceSw = "";
            
        }
        
        private void writeExtract(){
            
            // Create Extract Record
            record = new CmExtractCISAttributesRecord();
            record.setBadgeNumber(meterId.getEntity().getBadgeNumber().trim());
            record.setServiceType(SERVICE_TYPE);
            record.setManufacturerCode(manufacturerCode);
            record.setUtilityCompany(UTIL_COMPANY);
            record.setServicePointId(spId.getIdValue().trim());
            record.setReadRoute(readRoute);
            record.setTownCode(townCode);
            record.setGridCode(gridCode);
            record.setLandlordId(landlordId);
            record.setLandlordAccountId(landlordAccountId);
            record.setCustomerClassCode(customerClassCode);
            record.setPersonId(personId);
            if (notNull(saId)){
                record.setServiceAgreementId(saId.getIdValue());
            }else{
                record.setServiceAgreementId("");
            }
            if (notNull(accountId)){
                record.setAccountId(accountId.getIdValue());
            }else{
                record.setAccountId("");
            }            
            record.setRevenueClass(revenueClass);
            record.setHeatGrant(heatGrant);
            record.setBillCycle(billCycle);
            record.setIrregularUseCode(irregularUseCode);
            record.setMeterOnOffFlag(meterOnOffFlag);
            record.setServicePointSourceStatusFlag(spSourceStatusFlag);
            record.setMeterSize(meterSize);
            record.setMeterLocation(meterLocation);
            record.setMeterDialCount(meterDialCount);
            record.setCisDivision(cisDivision);
            record.setSaTypeCode(saTypeCode);
            record.setMeterMultiplier(meterMultiplier);
            record.setAmrDeviceSwitch(amrDeviceSw);
            
            // Set Appliance Type 1
            if (notNull(appType1CharType)){
                record.setApplianceType1(appType1CharType.getId().getIdValue());
            }else{
                record.setApplianceType1("");
            }
            record.setNumberOfApplianceType1(numberOfApp1);           
            
            // Set Appliance Type 2
            if (notNull(appType2CharType)){
                record.setApplianceType2(appType2CharType.getId().getIdValue());
            }else{
                record.setApplianceType2("");                
            } 
            record.setNumberOfApplianceType2(numberOfApp2);

            // Get Appliance Type 3
            if (notNull(appType3CharType)){
                record.setApplianceType3(appType3CharType.getId().getIdValue());
            }else{
                record.setApplianceType3("");                
            } 
            record.setNumberOfApplianceType3(numberOfApp3);
            
            // Get Appliance Type 4
            if (notNull(appType4CharType)){
                record.setApplianceType4(appType4CharType.getId().getIdValue());
            }else{
                record.setApplianceType4("");
            }
            record.setNumberOfApplianceType4(numberOfApp4);
            
            // Get Appliance Type 5
            if (notNull(appType5CharType)){
                record.setApplianceType5(appType5CharType.getId().getIdValue());
            }else{
                record.setApplianceType5("");                
            }
            record.setNumberOfApplianceType5(numberOfApp5);
            
            // Get Appliance Type 6
            if (notNull(appType6CharType)){
                record.setApplianceType6(appType6CharType.getId().getIdValue());
            }else{
                record.setApplianceType6("");                
            }
            record.setNumberOfApplianceType6(numberOfApp6);
            
            // Get Appliance Type 7
            if (notNull(appType7CharType)){
                record.setApplianceType7(appType7CharType.getId().getIdValue());
            }else{
                record.setApplianceType7("");                
            }
            record.setNumberOfApplianceType7(numberOfApp7);
            
            // Get Appliance Type 8
            if (notNull(appType8CharType)){
                record.setApplianceType8(appType8CharType.getId().getIdValue());
            }else{
                record.setApplianceType8("");                
            }
            record.setNumberOfApplianceType8(numberOfApp8);
            
            // Get Appliance Type 9
            if (notNull(appType9CharType)){
                record.setApplianceType9(appType9CharType.getId().getIdValue());
            }else{
                record.setApplianceType9("");                
            }
            record.setNumberOfApplianceType9(numberOfApp9);
            
            // Get Appliance Type 10
            if (notNull(appType10CharType)){
                record.setApplianceType10(appType10CharType.getId().getIdValue());
            }else{
                record.setApplianceType10("");                
            }
            record.setNumberOfApplianceType10(numberOfApp10);
            
            // Get Appliance Type 11
            if (notNull(appType11CharType)){
                record.setApplianceType11(appType11CharType.getId().getIdValue());
            }else{
                record.setApplianceType11("");                
            }
            record.setNumberOfApplianceType11(numberOfApp11);
            
            // Get Appliance Type 12
            if (notNull(appType12CharType)){
                record.setApplianceType12(appType12CharType.getId().getIdValue());
            }else{
                record.setApplianceType12("");                
            }
            record.setNumberOfApplianceType12(numberOfApp12);
            
            // Get Appliance Type 13
            if (notNull(appType13CharType)){
                record.setApplianceType13(appType13CharType.getId().getIdValue());
            }else{
                record.setApplianceType13("");                
            }
            record.setNumberOfApplianceType13(numberOfApp13);
            
            // Get Appliance Type 14
            if (notNull(appType14CharType)){
                record.setApplianceType14(appType14CharType.getId().getIdValue());
            }else{
                record.setApplianceType14("");                
            }
            record.setNumberOfApplianceType14(numberOfApp14);
            
            // Get Appliance Type 15
            if (notNull(appType15CharType)){
                record.setApplianceType15(appType15CharType.getId().getIdValue());
            }else{
                record.setApplianceType15("");                
            }
            record.setNumberOfApplianceType15(numberOfApp15);
            
            // Get Appliance Type 16
            if (notNull(appType16CharType)){
                record.setApplianceType16(appType16CharType.getId().getIdValue());
            }else{
                record.setApplianceType16("");                
            }
            record.setNumberOfApplianceType16(numberOfApp16);
            
            // Get Appliance Type 17
            if (notNull(appType17CharType)){
                record.setApplianceType17(appType17CharType.getId().getIdValue());
            }else{
                record.setApplianceType17("");                
            }
            record.setNumberOfApplianceType17(numberOfApp17);
            
            // Get Appliance Type 18
            if (notNull(appType18CharType)){
                record.setApplianceType18(appType18CharType.getId().getIdValue());
            }else{
                record.setApplianceType18("");                
            }
            record.setNumberOfApplianceType18(numberOfApp18);
            
            // Get Appliance Type 19
            if (notNull(appType19CharType)){
                record.setApplianceType19(appType19CharType.getId().getIdValue());           
            }else{
                record.setApplianceType19("");                
            }
            record.setNumberOfApplianceType19(numberOfApp19);
            
            // Get Appliance Type 20
            if (notNull(appType20CharType)){
                record.setApplianceType20(appType20CharType.getId().getIdValue());
            }else{
                record.setApplianceType20("");                
            }
            record.setNumberOfApplianceType20(numberOfApp20);
            
            // Get Appliance Type 21
            if (notNull(appType21CharType)){
                record.setApplianceType21(appType21CharType.getId().getIdValue());
            }else{
                record.setApplianceType21("");                
            }
            record.setNumberOfApplianceType21(numberOfApp21);
            
            // Get Appliance Type 22
            if (notNull(appType22CharType)){
                record.setApplianceType22(appType22CharType.getId().getIdValue());
            }else{
                record.setApplianceType22("");
            }
            record.setNumberOfApplianceType22(numberOfApp22);
            
            // Get Appliance Type 23
            if (notNull(appType23CharType)){
                record.setApplianceType23(appType23CharType.getId().getIdValue());
            }else{
                record.setApplianceType23("");                
            }
            record.setNumberOfApplianceType23(numberOfApp23);
            
            // Get Appliance Type 24
            if (notNull(appType24CharType)){
                record.setApplianceType24(appType24CharType.getId().getIdValue());
            }else{
                record.setApplianceType24("");                
            }
            record.setNumberOfApplianceType24(numberOfApp24);
            
            // Get Appliance Type 25
            if (notNull(appType25CharType)){
                record.setApplianceType25(appType25CharType.getId().getIdValue());
            }else{
                record.setApplianceType25("");                
            }                        
            record.setNumberOfApplianceType25(numberOfApp25);
            
            try {
                bufferedWriter.write(record.createRecordString());
                bufferedWriter.newLine();
            }
            catch (Exception e) {
                e.printStackTrace();
                addError(CustomMessageRepositoryMDC.NI0028_3_fileWriteError());                
            }
        }

        private String getPremiseChar(Premise premise, CharacteristicType charType) {
            
            String charVal = "";
            
            PremiseCharacteristic premChar = premise.getEffectiveCharacteristic(charType);
            
            if (notNull(premChar)){                     
                if (charType.getCharacteristicType().isAdhocValue())
                    charVal = premChar.getAdhocCharacteristicValue().trim();
                else if (charType.getCharacteristicType().isForeignKeyValue())
                    charVal = premChar.getCharacteristicValueForeignKey1().trim();
                else if (charType.getCharacteristicType().isPredefinedValue())
                    charVal = premChar.getCharacteristicValue().trim();
            }
            
            return charVal;
        }
        
        private String getSaChar(ServiceAgreement sa, CharacteristicType charType) {
            
            String charVal = "";
            
            ServiceAgreementCharacteristic saChar = sa.getEffectiveCharacteristic(charType);
            
            if (notNull(saChar)){                     
                if (charType.getCharacteristicType().isAdhocValue())
                    charVal = saChar.getAdhocCharacteristicValue().trim();
                else if (charType.getCharacteristicType().isForeignKeyValue())
                    charVal = saChar.getCharacteristicValueForeignKey1().trim();
                else if (charType.getCharacteristicType().isPredefinedValue())
                    charVal = saChar.getCharacteristicValue().trim();
            }
            
            return charVal;
        }
        
        private String getSpChar(ServicePoint sp, CharacteristicType charType) {
            
            String charVal = "";
            
            ServicePointCharacteristic spChar = sp.getEffectiveCharacteristic(charType);
            
            if (notNull(spChar)){                     
                if (charType.getCharacteristicType().isAdhocValue())
                    charVal = spChar.getAdhocCharacteristicValue().trim();
                else if (charType.getCharacteristicType().isForeignKeyValue())
                    charVal = spChar.getCharacteristicValueForeignKey1().trim();
                else if (charType.getCharacteristicType().isPredefinedValue())
                    charVal = spChar.getCharacteristicValue().trim();
            }
            
            return charVal;
        }
        
        private String getMeterChar(Meter meter, CharacteristicType charType) {
            
            String charVal = "";
            
            MeterCharacteristic meterChar = meter.getEffectiveCharacteristic(charType);
            
            if (notNull(meterChar)){                     
                if (charType.getCharacteristicType().isAdhocValue())
                    charVal = meterChar.getAdhocCharacteristicValue().trim();
                else if (charType.getCharacteristicType().isForeignKeyValue())
                    charVal = meterChar.getCharacteristicValueForeignKey1().trim();
                else if (charType.getCharacteristicType().isPredefinedValue())
                    charVal = meterChar.getCharacteristicValue().trim();
            }
            
            return charVal;
        }
        
        private Query getMeterStatus() {            
            
            Query meterStatusQuery = createQuery("FROM MeterConfiguration mcfg, " +
                        "ServicePointMeterHistory spMh, " +
                        "ServicePointMeterEvent spMe " +
                        "WHERE mcfg.meter.id = :meterId " +
                        "AND mcfg.id = spMh.meterConfiguration.id " +
                        "AND spMh.id = spMe.id.spMeterHistory.id " +
                        "AND spMe.id.sequence = (SELECT MAX(spMe2.id.sequence) " +
                                "FROM ServicePointMeterEvent spMe2 " +
                                //Start Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
                                //"WHERE spMe2.id.spMeterHistory.id = spMe.id.spMeterHistory.id)");
            					"WHERE spMe2.id.spMeterHistory.id = spMe.id.spMeterHistory.id)", getClass().getName());
            					//End Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
            
            meterStatusQuery.bindId("meterId",meterId);
            meterStatusQuery.addResult("meterOnOffStatus", "spMe.meterOnOffStatus");          
            
            return meterStatusQuery;       
        }
        
        private String getMeterLocation(){
            
            String meterLocation = "",
                    spMeterLoc = "";
            
            if (notNull(spId.getEntity().getMeterLocationId())){
                spMeterLoc = spId.getEntity().getMeterLocationId().getIdValue().trim();
            }
            
            if (notBlank(spMeterLoc)){
                
                // Get Meter Location Cross Reference from Feature Configuration
                CmFeatureConfigurationRetriever fcOptRet = CmFeatureConfigurationRetriever.Factory.newInstance();
                fcOptRet.setParmWFMName(mtrLocRefFeatureConfig);
                fcOptRet.setParmOptType(spMeterLoc.trim());
                meterLocation = fcOptRet.getMaxSequenceOptionValue();       
                
                // If Meter Location is blank, log warning indicating that Meter Location Cross reference was not found.
                if (meterLocation == ""){                               
                    logWarning(CustomMessageRepositoryMDC.NI0028_3_meterLocCrossRefMiss(spMeterLoc, 
                            mtrLocRefFeatureConfig.getId().getIdValue().trim()));
                }
            }                                        
            
            return meterLocation;
            
        }
         
        private String getAmrDevice(Register reg) { 
            
            String itemUOMStr = "",
                    itemTOUStr = "",
                    hasAMRDevice = NO;
            UnitOfMeasure itemUOM = null;
            TimeOfUse itemTOU = null;
            Bool amrDeviceFound = Bool.FALSE;
            
            // Check if the Register's Meter has an Item Meter Equipment with an Item Type equal to the batch parameter
            Query amrDeviceQuery = createQuery("FROM MeterEquipment meq, " +
                        "Item item " +
                        "WHERE meq.id.meter.id = :meterId " +
                        "AND (meq.removalDate IS NULL OR meq.removalDate >= :processDate) " +
                        "AND meq.id.equipment.id = item.id " +
                        //Start Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
                        //"AND item.itemType = :itemType");
            			"AND item.itemType = :itemType", getClass().getName());
            			//End Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
            
            amrDeviceQuery.bindId("meterId", meterId);
            amrDeviceQuery.bindDate("processDate", getProcessDateTime().getDate());
            amrDeviceQuery.bindEntity("itemType", amrDeviceItemType);
            amrDeviceQuery.addResult("item", "item");
            
            // If there are, loop thru the AMR Devices
            QueryIterator amrDeviceIter = amrDeviceQuery.iterate();
            while (amrDeviceIter.hasNext() && amrDeviceFound.isFalse()){
                
                Item item = (Item) amrDeviceIter.next();               
                
                // Get Item's UOM characteristic
                itemUOMStr = getItemChar(item, uomItemCharType);
                if (itemUOMStr == ""){       
                    // Log warning if item does not have an effective UOM characteristic
                    logWarning(CustomMessageRepositoryMDC.NI0028_3_amrDeviceCharMiss(meterId.getIdValue().trim(), 
                            item.getId().getIdValue().trim()));
                }else{
                    itemUOM = new UnitOfMeasure_Id(itemUOMStr).getEntity();
                }
                
                // Get Item's TOU characteristic if Item TOU Characteristic Type parameter is supplied
                if (notNull(touItemCharType)){
                    
                    itemTOUStr = getItemChar(item, touItemCharType);
                    if (itemTOUStr == ""){                        
                        // Log warning if item does not have an effective TOU characteristic
                        logWarning(CustomMessageRepositoryMDC.NI0028_3_amrDeviceCharMiss(meterId.getIdValue().trim(), 
                                item.getId().getIdValue().trim()));             
                    }else{
                        itemTOU = new TimeOfUse_Id(itemTOUStr).getEntity();
                    }                    
                }
                
                // Check if the Register's UOM is equivalent to the Item's UOM characteristic
                if (reg.getUnitOfMeasure().equals(itemUOM)){                    
                    if (notNull(touItemCharType)){                        
                        if (notNull(reg.getTimeOfUseId())){
                            // Check if the Register's TOU is equivalent to the Item's TOU characteristic
                            if (reg.getTimeOfUseId().getEntity().equals(itemTOU)){
                                hasAMRDevice = YES;
                                amrDeviceFound = Bool.TRUE;
                                amrDeviceIter.close();
                            }
                        }                                    
                    } else {
                        hasAMRDevice = YES;
                        amrDeviceFound = Bool.TRUE;
                        amrDeviceIter.close();                        
                    }
                }                
            }
                
            return hasAMRDevice;
            
        }
        
        private String getItemChar(Item item, CharacteristicType charType) {
            
            String charVal = "";
            
            ItemCharacteristic itemChar = item.getEffectiveCharacteristic(charType);
            
            if (notNull(itemChar)){                     
                if (charType.getCharacteristicType().isAdhocValue())
                    charVal = itemChar.getAdhocCharacteristicValue().trim();
                else if (charType.getCharacteristicType().isForeignKeyValue())
                    charVal = itemChar.getCharacteristicValueForeignKey1().trim();
                else if (charType.getCharacteristicType().isPredefinedValue())
                    charVal = itemChar.getCharacteristicValue().trim();
            }
            
            return charVal;
        }

        @Override
        public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
            
            // Close the file
            try {               
                bufferedWriter.close();
            }
            catch (Exception e) {
                e.printStackTrace();
                addError(CustomMessageRepositoryMDC.NI0028_3_fileCloseError());                
            }
        }             

    }

}
