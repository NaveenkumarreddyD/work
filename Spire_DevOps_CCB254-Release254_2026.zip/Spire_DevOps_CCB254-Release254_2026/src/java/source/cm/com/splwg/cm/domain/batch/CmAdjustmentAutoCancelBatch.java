/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This custom Batch Process will cancel the adjustments which are in frozen state
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2016-09-15   Psreekanth      SA-143449-001 Initial Version.
 * 2021-11-04   JVitug          Defect 4599768. Removed try catch when reading
 * 								the input file to allow it to call the specific
 * 								messages each specific error. 
 * **************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic_DTO;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_DTO;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.adjustment.common.CancelAdjustment;
import com.splwg.ccb.domain.admin.adjustmentCancelReason.entity.AdjustmentCancelReason;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author psreekan
 *
@BatchJob (multiThreaded = false, rerunnable = false,modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CHAR_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CHAR_VALUE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = adjustmentCancelReason, name = ADJ_CAN_RSN, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CUST_CONT_CL, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CUST_CONT_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)})
 */
public class CmAdjustmentAutoCancelBatch extends 
		CmAdjustmentAutoCancelBatch_Gen {

	// Start - Batch job Soft Parameters
	private String filePath;
	private String fileName;
	private CharacteristicType characteristicType;
	private String charValue;
	private AdjustmentCancelReason adjustmentCancelReason;
	private CustomerContactClass customerContactClass;
	private String customerContactTypeStr;
	
	private BufferedReader fileReader;
	
	/**
	 * This method validates the soft parameters of the batch
	 * 
	 * @param isNewRun
	 *            boolean
	 */
	public void validateSoftParameters(boolean isNewRun) {

		retrieveBatchParameters();
		validateBatchParameters();
	}

	public JobWork getJobWork() {
		List<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();

		if (!filePath.endsWith(File.separator)) {
			filePath = filePath + File.separator;
		}
		if (notNull(fileName)) {
			boolean fileExists = new File(filePath + fileName).exists();

			if (!(fileExists)) {

				 addError(CustomMessageRepositoryMGE.fileDoesNotExist(filePath,
				 fileName));

			} else {
				File file = new File(filePath + fileName);
				if (file.isFile()) {

					//Start Change - Defect 4599768 - JVitug
					//try {
						// Open upload file
						//openAndReadFile(file);
						//String line = fileReader.readLine();
						//while ((line = fileReader.readLine()) != null) {

							//Adjustment_Id adjustmentId = new Adjustment_Id(
									//line.trim());
							//if (isNull(adjustmentId.getEntity())) {
								//addError(CustomMessageRepositoryMGE
										//.adjustmetIdIsNotValid(line));
							//}
							//threadWorkUnit = new ThreadWorkUnit();
							//threadWorkUnit.setPrimaryId(adjustmentId);
							//arrayList.add(threadWorkUnit);
						//}
					//} catch (Exception e) {
					//	 addError(CustomMessageRepositoryMGE.errorReadingFile(file.getName()));
					//}
					openFile(file);
					String line = readFile(file);
					while ((line = readFile(file)) != null) {

						Adjustment_Id adjustmentId = new Adjustment_Id(line.trim());
						if (isNull(adjustmentId.getEntity())) {
							addError(CustomMessageRepositoryMGE.adjustmetIdIsNotValid(line));
						}
						threadWorkUnit = new ThreadWorkUnit();
						threadWorkUnit.setPrimaryId(adjustmentId);
						arrayList.add(threadWorkUnit);
					}
					//End Change - Defect 4599768 - JVitug
				}
			}
		}
		// Return the list to framework
		return createJobWorkForThreadWorkUnitList(arrayList);
	}
	
	/**
	 * This method retrieves all the soft Parameters of the batch
	 */
	private void retrieveBatchParameters() {

		filePath = getParameters().getFILE_PATH();
		fileName = getParameters().getFILE_NAME();
		characteristicType = getParameters().getCHAR_TYPE_CD();
		charValue = getParameters().getCHAR_VALUE();
		adjustmentCancelReason = getParameters().getADJ_CAN_RSN();
		customerContactClass = getParameters().getCUST_CONT_CL();
		customerContactTypeStr = getParameters().getCUST_CONT_TYPE();
	}

	/**
	 * This method validates all the soft Parameters of the batch
	 */
	public void validateBatchParameters() {

		/*
		 * Validate batch parameter filePath is not null and valid File Path
		 * directory. If filePath directory does not exists, then raise error
		 */
		File path = new File(filePath);
		if (!path.exists() || !path.isDirectory()) {
			 addError(CustomMessageRepositoryMGE.filePathIsNotValid(filePath));
		}
		
		CharacteristicEntity_Id characteristicId = new CharacteristicEntity_Id(
				characteristicType.getId(),
				CharacteristicEntityLookup.constants.ADJUSTMENT);
		if (characteristicType.getCharacteristicType().isPredefinedValue()) {
			
            CharacteristicValue_Id charValueId = new CharacteristicValue_Id(characteristicType,
            		charValue);
            if (isNull(charValueId.getEntity())) {
                addError(CustomMessageRepositoryMGE.invalidCharValue(charValue,
                		characteristicType.getId().getTrimmedValue()));
            }
        }
		// Validate if the Characteristic Entity is not null, else raise
		// error
		if (isNull(characteristicId.getEntity())) {
			 addError(CustomMessageRepositoryMGE.invalidCharTypeForEntity(characteristicType.getId().getTrimmedValue(), CharacteristicEntityLookup.constants.ADJUSTMENT.value()));
		}
		
		CustomerContactType_Id customerContactTypeId = new CustomerContactType_Id(
				customerContactClass, customerContactTypeStr);
		if (isNull(customerContactTypeId)
				|| isNull(customerContactTypeId.getEntity())) {
			 addError(CustomMessageRepositoryMGE.customerContactTypeIsNotValid(customerContactTypeStr));
		}
	}
	
	/**
	 * This method opens file for processing
	 * 
	 * @param uploadFile
	 *            - uploadFile
	 * @throws IOException
	 *             - IOException
	 * @throws Exception
	 *             - Exception
	 */
	//Start Change - Defect 4599768 - JVitug
	//private void openAndReadFile(File file) throws IOException, Exception {
	private void openFile(File file) {
	//End Change - Defect 4599768 - JVitug
		try {
			fileReader = new BufferedReader(new FileReader(file));
		} catch (Exception e) {
			 addError(CustomMessageRepositoryMGE.errorOpeningFile(file.getName()));
		}
	}
	
	//Start Add - Defect 4599768 - JVitug
	/**
	 * This method will return a line from a file using the 
	 * file reader created in the openFile() method
	 * @param file
	 * @return a line from a file as String
	 */
	private String readFile(File file) {
		String returnValue = "";
		
		try {
			returnValue = fileReader.readLine();
		} catch (Exception e) {
			addError(CustomMessageRepositoryMGE.errorReadingFile(file.getName()));
		}
		return returnValue;
	}
	//End Add - Defect 4599768 - JVitug
	
	public Class<CmAdjustmentAutoCancelBatchWorker> getThreadWorkerClass() {
		return CmAdjustmentAutoCancelBatchWorker.class;
	}

	public static class CmAdjustmentAutoCancelBatchWorker extends
			CmAdjustmentAutoCancelBatchWorker_Gen {
		
		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
			// TODO Auto-generated method stub
			retrieveBatchParameters();
		}

		private CharacteristicType characteristicType;
		private String charValue;
		private AdjustmentCancelReason adjustmentCancelReason;
		private CustomerContactClass customerContactClass;
		private String customerContactTypeStr;

		public ThreadExecutionStrategy createExecutionStrategy() {
			// TODO Auto-generated method stub
			return new SingleTransactionStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			// TODO Auto-generated method stub
			Adjustment_Id adjustmentId = (Adjustment_Id)unit.getPrimaryId();
			Adjustment adjustment = adjustmentId.getEntity();
			
			if(!adjustment.getAdjustmentStatus().isFrozen()){
				 addWarning(CustomMessageRepositoryMGE.adjustmentNotInFrozenStatus(adjustmentId.getTrimmedValue(), adjustment.getAdjustmentStatus().getLookupValue().fetchLanguageDescription()));
			}else{
				CancelAdjustment cancelAdjustment = CancelAdjustment.Factory.newInstance();
				cancelAdjustment.cancelAdjustment(adjustment, adjustmentCancelReason);
				
				Adjustment_DTO adjustmentDTO = adjustment.getDTO();
				adjustmentDTO.setComments(CustomMessageRepositoryMGE.adjustmentCanceled(adjustmentId.getTrimmedValue(),getProcessDateTime().toLocalizedString()).getMessageText()); 
				adjustment.setDTO(adjustmentDTO);
				
				createAdjustmentCharacteristic(adjustment);
				createCustomerContact(adjustment);
			}
			return true;
		}
		
		/**
		 * This method retrieves all the soft Parameters of the batch
		 */
		private void retrieveBatchParameters() {

			characteristicType = getParameters().getCHAR_TYPE_CD();
			charValue = getParameters().getCHAR_VALUE();
			adjustmentCancelReason = getParameters().getADJ_CAN_RSN();
			customerContactClass = getParameters().getCUST_CONT_CL();
			customerContactTypeStr = getParameters().getCUST_CONT_TYPE();
		}
		
		private void createAdjustmentCharacteristic(
				Adjustment adjustment) {

			AdjustmentCharacteristic_DTO charDto = adjustment
					.getCharacteristics().newChildDTO();
			CharacteristicTypeLookup charTypeLookup = characteristicType
					.getCharacteristicType();
			if (charTypeLookup.isAdhocValue()
					|| charTypeLookup.isFileLocationValue()) {
				charDto.setAdhocCharacteristicValue(charValue);
			} else if (charTypeLookup.isPredefinedValue()) {
				charDto.setCharacteristicValue(charValue);
			} else if (charTypeLookup.isForeignKeyValue()) {
				charDto.setCharacteristicValueForeignKey1(charValue);
			}
			adjustment.getCharacteristics().add(charDto, characteristicType.getId(), BigInteger.ONE);
		}

		private void createCustomerContact(Adjustment adjustment){
			
			CustomerContact_DTO customerContactDTO = createDTO(CustomerContact.class);
			customerContactDTO
					.setCustomerContactTypeId(new CustomerContactType_Id(customerContactClass, customerContactTypeStr));
			customerContactDTO.setPersonId(getMainPerson(adjustment.getServiceAgreement().getAccount()));
			customerContactDTO.setContactDateTime(getProcessDateTime());
			customerContactDTO.setLongDescription(CustomMessageRepositoryMGE.adjustmentCanceled(adjustment.getId().getTrimmedValue(),getProcessDateTime().toLocalizedString()).getMessageText());    
			customerContactDTO.newEntity();
		}
		
		private Person_Id getMainPerson(Account account) {
			ListFilter<AccountPerson> personFilter = account.getPersons()
					.createFilter(" WHERE this.isMainCustomer = :F1",
							getClass().getName());
			personFilter.bindBoolean("F1",Bool.TRUE);
			return personFilter.firstRow().getId().getPersonId();
		}
	}

}
