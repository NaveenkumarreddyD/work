/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Person Life Support Sensitive load Flag Lookup 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2016-05-06   equint      Initial Version. 
 **************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author equint
 *
 @LookupFieldname (value = PER_LS_SL_FLG)
 */
public class CmPersonLSSLFlagLookup_Impl 
extends CmPersonLSSLFlagLookup_Gen {

}

