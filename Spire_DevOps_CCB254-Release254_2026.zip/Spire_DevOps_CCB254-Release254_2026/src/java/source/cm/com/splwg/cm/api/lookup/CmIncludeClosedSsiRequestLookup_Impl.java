package com.splwg.cm.api.lookup;

/**
 * @author TMG02493
 *
@LookupFieldname (value = CM_INCLUDE_CLOSED_SSIRQ)
 */
public class CmIncludeClosedSsiRequestLookup_Impl extends
		CmIncludeClosedSsiRequestLookup_Gen {

}
