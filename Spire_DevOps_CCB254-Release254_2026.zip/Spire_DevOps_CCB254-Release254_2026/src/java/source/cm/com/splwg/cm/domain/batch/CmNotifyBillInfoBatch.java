/*
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Call the specified estimation algorithm to derive MR Estimates 
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:                by:                 Reason:                                                                                                   
 * YYYY-MM-DD                         
 * 2022-04-29           DLampa              B-21239.5. Initial Version. 
 * 2022-07-25           Kiran				Due date format and latest balance
 * 2022-10-27           JVitug              TBD. Initial Version.
 * 2022-11-07           DLampa              E-05275.Issue1. Updated to address 
 *                                          issues in the code related to the use 
 *                                          of createFilter 
 * 2025-06-09			CAtilano			INC0061561 - use the current amount instead of bill.getAutoPay amount for the Autopay Message                                
 *******************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.serviceScript.ServiceScriptDispatcher;
import com.splwg.base.api.serviceScript.ServiceScriptInstance;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType_Id;
import com.splwg.ccb.api.lookup.BillStatusLookup;
import com.splwg.ccb.api.lookup.BusinessObjectStatusOptionTypeLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.StateConditionLookup;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillCharacteristic;
import com.splwg.ccb.domain.billing.bill.entity.BillCharacteristic_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillCharacteristic_Id;
import com.splwg.ccb.domain.billing.bill.entity.BillCharacteristics;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.customerinfo.data.AccountFinancialBalanceData;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonContactDetail_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;

/**
 * @author dlampa
 *
 @BatchJob (multiThreaded = true, rerunnable = false,
 *      modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = BILL_DUE_CHAR_TYPE, type = entity, entityName = characteristicType, required = false)
 *                       , @BatchJobSoftParameter (name = BILL_DUE_CHAR_VAL, type = string, required = true)
 *                       , @BatchJobSoftParameter (name = BILL_DUE_NUM_DAYS, type = integer, required = true)
 *                       , @BatchJobSoftParameter (name = APAY_CHAR_TYPE, type = entity, entityName = characteristicType, required = false)
 *                       , @BatchJobSoftParameter (name = APAY_CHAR_VAL, type = string, required = true)
 *                       , @BatchJobSoftParameter (name = APAY_NUM_DAYS, type = integer, required = true)
 *                       , @BatchJobSoftParameter (name = BILL_COMPLETE_NUM_DAYS, type = integer, required = true)
 *                       , @BatchJobSoftParameter (name = DIST_THD_POOL, type = string, required = false)
 *                       , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer, required = false)})
 */

public class CmNotifyBillInfoBatch extends
        CmNotifyBillInfoBatch_Gen {
	
	// Soft parameters
	private static CharacteristicType billDueCharType;
	private static String billDueCharVal;
	private static BigInteger billDueNumDays;
	private static CharacteristicType apayCharType;
	private static String apayCharVal;
	private static BigInteger apayNumDays;	
	//Start Add JVitug - TBD - 2022-10-27
	private static BigInteger billCompletionDays;
	//End Add JVitug - TBD - 2022-10-27

	// Work variables
	private static Bill bill;
	private static String pmocEmailAddress = "";
	private static String pmocSms = "";
	//Start Add - DLampa - E-05275.Issue1 - 2022-11-07
	private static Bill_Id billId;
	//End Add - DLampa - E-05275.Issue1 - 2022-11-07

    // Constants
    private static final String CM_SAPNOTIF="CM-SAPNotif";
    private static final String SVC_TASK_TYPE = "CM-PMOC";
    private static final String BO_NAME_CM_PMOC = "CM-PreferredMethodOfContact";
    private static final String XPATH_ELEM_SVC_TASK_ID = "serviceTaskId";
    private static final String XPATH_GROUP_PMOC_DETAILS = "preferredMethodOfContactDetails";
    private static final String XPATH_GROUP_PMOC = "pmoc";
    private static final String XPATH_ELEM_EMAIL_CONTACT_ID = "emailContactId";
    private static final String XPATH_ELEM_SMS_CONTACT_ID = "smsContactId";
    private static final CharacteristicType OUTMSGCHARTYPE = new CharacteristicType_Id("F1OUTMSG").getEntity();
    private static final String SNT = "SNT";
	
    @Override
    public JobWork getJobWork() {
        
    	// Retrieve all Accounts that were billed with a non-system-estimated read during the specified period 
        StringBuilder queryStr = new StringBuilder("");

        queryStr.append("SELECT B.BILL_ID ");
        queryStr.append("FROM CI_BILL B ");     
        queryStr.append("WHERE B.BILL_STAT_FLG = :billStatFlg ");
        queryStr.append(  "AND EXISTS (SELECT 'X'  ");
        queryStr.append(              "FROM CI_BILL_CHAR BC ");
        queryStr.append(              "WHERE BC.BILL_ID = B.BILL_ID ");
        queryStr.append(                "AND BC.CHAR_TYPE_CD IN (:apay,:billDue) ");
        queryStr.append(                "AND BC.SRCH_CHAR_VAL <> :sent) ");
        //Start Add JVitug - TBD - 2022-10-27
        queryStr.append("AND B.BILL_DT BETWEEN :dateToLookBack AND :processDate ");
        //End Add JVitug - TBD - 2022-10-27
        queryStr.append("ORDER BY B.BILL_ID");
      
        PreparedStatement completedBillsQuery = createPreparedStatement(queryStr.toString(), getClass().getName());
        
        completedBillsQuery.bindLookup("billStatFlg", BillStatusLookup.constants.COMPLETE);
        completedBillsQuery.bindEntity("apay", apayCharType);
        completedBillsQuery.bindEntity("billDue", billDueCharType);
        completedBillsQuery.bindString("sent", SNT, "SENT");
        //Start Add JVitug - TBD - 2022-10-27
        //We only get Bills whose bill date is within the number of days to look back batch parameter
        completedBillsQuery.bindDate("dateToLookBack" , getProcessDateTime().getDate().addDays(billCompletionDays.negate().intValue()));
        completedBillsQuery.bindDate("processDate" , getProcessDateTime().getDate());
        //End Add JVitug - TBD - 2022-10-27

        //Start Change - DLampa - E-05275.Issue1 - 2022-11-07
        //List<ThreadWorkUnit> threadWorkUnitList = new ArrayList<ThreadWorkUnit>();
        //QueryIterator<SQLResultRow> iterator = completedBillsQuery.iterate();
        //QueryResultRow row = null;
        //ThreadWorkUnit threadWorkUnit = null;
        //while (iterator.hasNext()) {
        //    row = iterator.next();
                
        //    threadWorkUnit = new ThreadWorkUnit();
        //    threadWorkUnit.setPrimaryId(new Bill_Id(row.getString("BILL_ID")));
        //    threadWorkUnitList.add(threadWorkUnit);         
        //}
        //iterator.close();
        //completedBillsQuery.close();

        //return createJobWorkForThreadWorkUnitList(threadWorkUnitList);
		QueryIterator iterator = completedBillsQuery.iterate();
		
		return createJobWorkForQueryIterator(iterator, this);			
		//End Change - DLampa - E-05275.Issue1 - 2022-11-07
        
    }
	
	//Start Add - DLampa - E-05275.Issue1 - 2022-11-07
	@Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow queryResultRow) {
    	
    	ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
    	threadWorkUnit.setPrimaryId(new Bill_Id(queryResultRow.getString("BILL_ID")));
    	
    	return threadWorkUnit;
		
	}
	//End Add - DLampa - E-05275.Issue1 - 2022-11-07	

    public Class<CmNotifyBillInfoBatchWorker> getThreadWorkerClass() {
        return CmNotifyBillInfoBatchWorker.class;
    }

    @Override
    public void validateSoftParameters(boolean arg0){

    	billDueCharType = getParameters().getBILL_DUE_CHAR_TYPE();
    	billDueCharVal = getParameters().getBILL_DUE_CHAR_VAL();
    	billDueNumDays = getParameters().getBILL_DUE_NUM_DAYS();
    	apayCharType = getParameters().getAPAY_CHAR_TYPE();
    	apayCharVal = getParameters().getAPAY_CHAR_VAL();
    	apayNumDays = getParameters().getAPAY_NUM_DAYS();
    	//Start Add JVitug - TBD - 2022-10-27
    	billCompletionDays = getParameters().getBILL_COMPLETE_NUM_DAYS();
    	//End Add JVitug - TBD - 2022-10-27
    	
    	// Bill Due Char Type must be valid for the Bill entity
        CharacteristicEntity_Id characteristicEntityId = new CharacteristicEntity_Id(billDueCharType, CharacteristicEntityLookup.constants.BILL);
        if (isNull(characteristicEntityId.getEntity())){
            addError(CustomMessageRepositorySpireOne.B21239_5_CharTypeInvalidForEntity("BILL_DUE_CHAR_TYPE", billDueCharType.getId().getIdValue(), CharacteristicEntityLookup.constants.BILL.getConstantName()));
        }  
        
        // Bill Due Char Val must be valid for the Bill Due Char Type if the characteristic type is predefined
        if (billDueCharType.getCharacteristicType().isPredefinedValue()) {
        	CharacteristicValue_Id charValueId = new CharacteristicValue_Id(billDueCharType, billDueCharVal);
        	
        	if (isNull(charValueId.getEntity())) {
        		addError(CustomMessageRepositorySpireOne.B21239_5_CharValInvalidForCharType("BILL_DUE_CHAR_VAL", billDueCharVal, billDueCharType.getId().getIdValue()));
        	}        	
        }
    
        // Bill Due Num Days must be a positive number
        if (billDueNumDays.compareTo(BigInteger.ZERO) < 0) {
        	addError(CustomMessageRepositorySpireOne.B21239_5_NumDaysInvalid("BILL_DUE_NUM_DAYS", billDueNumDays.toString()));
        }
        
    	// Apay Due Char Type must be valid for the Bill entity    	
        characteristicEntityId = new CharacteristicEntity_Id(apayCharType, CharacteristicEntityLookup.constants.BILL);
        if (isNull(characteristicEntityId.getEntity())){
            addError(CustomMessageRepositorySpireOne.B21239_5_CharTypeInvalidForEntity(getParameters().getBILL_DUE_CHAR_TYPE().fetchLanguageDescription(), apayCharType.getId().getIdValue(), CharacteristicEntityLookup.constants.BILL.getConstantName()));
        }     	

        // Apay Char Val must be valid for the Apay Char Type if the characteristic type is predefined
        if (apayCharType.getCharacteristicType().isPredefinedValue()) {
        	CharacteristicValue_Id charValueId = new CharacteristicValue_Id(apayCharType, apayCharVal);
        	
        	if (isNull(charValueId.getEntity())) {
        		addError(CustomMessageRepositorySpireOne.B21239_5_CharValInvalidForCharType("APAY_CHAR_VAL", apayCharVal, apayCharType.getId().getIdValue()));
        	}        	
        }        
        
        // Apay Due Num Days must be a positive number
        if (apayNumDays.compareTo(BigInteger.ZERO) < 0) {
        	addError(CustomMessageRepositorySpireOne.B21239_5_NumDaysInvalid("APAY_NUM_DAYS", apayNumDays.toString()));
        }
        
        //Bill completion Days must be a positive number
        if (billCompletionDays.compareTo(BigInteger.ZERO) < 0) {
        	addError(CustomMessageRepositorySpireOne.B21239_5_NumDaysInvalid("BILL_COMPLETE_NUM_DAYS", apayNumDays.toString()));
        }
        
    }    
    
    public static class CmNotifyBillInfoBatchWorker extends
        CmNotifyBillInfoBatchWorker_Gen {    
               
        @Override
        public void initializeThreadWork(boolean initializationPreviouslySuccessful) throws ThreadAbortedException, RunAbortedException {
      	
        	billDueCharType = getParameters().getBILL_DUE_CHAR_TYPE();
        	billDueCharVal = getParameters().getBILL_DUE_CHAR_VAL();
        	billDueNumDays = getParameters().getBILL_DUE_NUM_DAYS();
        	apayCharType = getParameters().getAPAY_CHAR_TYPE();
        	apayCharVal = getParameters().getAPAY_CHAR_VAL();
        	apayNumDays = getParameters().getAPAY_NUM_DAYS();
        	
        	//Start Add JVitug - TBD - 2022-10-27
        	billCompletionDays = getParameters().getBILL_COMPLETE_NUM_DAYS();
        	//End Add JVitug - TBD - 2022-10-27
            
            super.initializeThreadWork(initializationPreviouslySuccessful);
        }

        @Override
        protected boolean executeWorkUnit(ThreadWorkUnit unit) throws ThreadAbortedException, RunAbortedException {
        	
        	//Start Change - DLampa - E-05275.Issue1 - 2022-11-07
            //Bill_Id billId = (Bill_Id) unit.getPrimaryId();
            billId = (Bill_Id) unit.getPrimaryId();
            //End Change - DLampa - E-05275.Issue1 - 2022-11-07
            bill = billId.getEntity();
                       
			// Process the bill depending on which characteristic type it is tagged with
			//Start Change - DLampa - E-05275.Issue1 - 2022-11-07			
			//List<BillCharacteristic> billCharacteristics = new ArrayList<BillCharacteristic>(bill.getCharacteristics().asSet());
			BillCharacteristics billCharacteristics = bill.getCharacteristics();
			//End Change - DLampa - E-05275.Issue1 - 2022-11-07
			for (BillCharacteristic billCharacteristic : billCharacteristics) {
				if (billCharacteristic.fetchIdCharacteristicType().getId().getTrimmedValue().equals(billDueCharType.getId().getTrimmedValue())
						&& billCharacteristic.getSearchCharacteristicValue().equalsIgnoreCase(billDueCharVal)) {
					processBillDue();
					break;
				}
				if (billCharacteristic.fetchIdCharacteristicType().getId().getTrimmedValue().equals(apayCharType.getId().getTrimmedValue())
						&& billCharacteristic.getSearchCharacteristicValue().equalsIgnoreCase(apayCharVal)) {
					processApay();
					break;
				}
			} 

            return true;
        }
        
        /**
         * Process Bill Due
         */
        private void processBillDue() {

        	if (notNull(bill.getLatePaymentChargeDate())) {
        		// If the bill has a late payment charge date, continue processing only if the current date  
        		// is exactly X days prior to the late payment charge date 
        		if (!getProcessDateTime().getDate().equals(bill.getLatePaymentChargeDate().addDays(billDueNumDays.negate().intValue()))) {
        			return;
        		}
        	} else {
        		// If the bill does not have a late payment charge date, continue processing only if the current date  
        		// is exactly X days prior to the due date
        		if (!getProcessDateTime().getDate().equals(bill.getDueDate().addDays(billDueNumDays.negate().intValue()))) {
        			return;
        		}
        	}
        	
        	// Determine if the account has a balance as of the bill completion date
        	AccountFinancialBalanceData acctFinancialBalance = bill.getAccount().getFinancialBalances(bill.getCompletedDatetime().getDate(), bill.getCompletedDatetime().getDate());
        	if (acctFinancialBalance.getCurrentAmount().isGreaterThan(Money.ZERO)) {
        		// Retrieve the main person's PMOC preference(s)
        		Bool isPmocPreferenceAvailable = getPmocPreferences();        		
        		if (isPmocPreferenceAvailable.isTrue()) {
        			createOutboundMessage(Bool.TRUE);       		    				
        		}
        	}

        }  
        
        private Bool getPmocPreferences(){
        	
        	Bool pmocPreferenceFoundSw = Bool.FALSE;
            pmocEmailAddress = "";
            pmocSms = "";
            
            // Retrieve PMOC Service Task for Person
            ServiceTask pmocServiceTask = getPmocServiceTask();
            if (notNull(pmocServiceTask)){
                // Retrieve Email Contact ID
                BusinessObject_Id boId = new BusinessObject_Id(BO_NAME_CM_PMOC);
                BusinessObjectInstance boInstance = BusinessObjectInstance.create(boId.getEntity());
                boInstance.set(XPATH_ELEM_SVC_TASK_ID, pmocServiceTask.getId().getTrimmedValue());
                boInstance = BusinessObjectDispatcher.read(boInstance); 
                
                COTSInstanceNode boGroupPmocDetails = boInstance.getGroup(XPATH_GROUP_PMOC_DETAILS);
                COTSInstanceNode boGroupPmoc = boGroupPmocDetails.getGroup(XPATH_GROUP_PMOC);
                String emailContactIdStr = boGroupPmoc.getFieldAndMDForPath(XPATH_ELEM_EMAIL_CONTACT_ID).getXMLValue();
               
                if (notBlank(emailContactIdStr)){
                    PersonContactDetail_Id  emailContactId = new PersonContactDetail_Id(emailContactIdStr);
                    pmocEmailAddress = emailContactId.getEntity().getContactDetailValue();                    
                    pmocPreferenceFoundSw = Bool.TRUE;
                }

                String smsContactIdStr = boGroupPmoc.getFieldAndMDForPath(XPATH_ELEM_SMS_CONTACT_ID).getXMLValue();                
                if (notBlank(smsContactIdStr)){
                    PersonContactDetail_Id  smsContactId = new PersonContactDetail_Id(smsContactIdStr);
                    pmocSms = smsContactId.getEntity().getContactDetailValue();
                    pmocPreferenceFoundSw = Bool.TRUE;
                }
            }
            return pmocPreferenceFoundSw;

        }        
        
        private ServiceTask getPmocServiceTask() {
        	
            ServiceTask pmocServiceTask = null;
            ServiceTaskType_Id serviceTaskTypeId = new ServiceTaskType_Id(SVC_TASK_TYPE);
            
            StringBuilder stringBuilder = new StringBuilder();      
            stringBuilder.append("SELECT ST.F1_SVC_TASK_ID ");
            stringBuilder.append("FROM F1_SVC_TASK_REL_OBJ STRO, ");
            stringBuilder.append(     "F1_SVC_TASK ST ");
            stringBuilder.append("WHERE STRO.PK_VALUE1 = :personId ");
            stringBuilder.append(  "AND STRO.MAINT_OBJ_CD = 'PERSON' ");
            stringBuilder.append(  "AND STRO.F1_SVC_TASK_ID = ST.F1_SVC_TASK_ID ");
            stringBuilder.append(  "AND ST.F1_STASK_TYPE_CD = :serviceTaskType ");
            stringBuilder.append(  "AND NOT EXISTS (SELECT BOSTO.BO_OPT_VAL ");
            stringBuilder.append(                  "FROM F1_BUS_OBJ BO, F1_BUS_OBJ_STATUS_OPT BOSTO ");
            stringBuilder.append(                  "WHERE ST.BUS_OBJ_CD = BO.BUS_OBJ_CD ");
            stringBuilder.append(                    "AND BO.LIFE_CYCLE_BO_CD = BOSTO.BUS_OBJ_CD ");
            stringBuilder.append(                    "AND ST.BO_STATUS_CD = BOSTO.BO_STATUS_CD ");
            stringBuilder.append(                    "AND BOSTO.BO_OPT_FLG = :stateCondition ");
            stringBuilder.append(                    "AND BOSTO.BO_OPT_VAL = :inactive) ");

            PreparedStatement getPmocServiceTask = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            //Start Change - DLampa - E-05275.Issue1 - 2022-11-07
            //getPmocServiceTask.bindId("personId", bill.getAccount().getMainPerson().getId());
            getPmocServiceTask.bindId("personId", getAccountMainPerson());
            //End Change - DLampa - E-05275.Issue1 - 2022-11-07 
            getPmocServiceTask.bindId("serviceTaskType", serviceTaskTypeId);
            getPmocServiceTask.bindLookup("stateCondition", BusinessObjectStatusOptionTypeLookup.constants.STATE_CONDITION);
            getPmocServiceTask.bindLookup("inactive", StateConditionLookup.constants.INACTIVE);
            
            getPmocServiceTask.setAutoclose(false);

            SQLResultRow sqlRow = getPmocServiceTask.firstRow();
            if (notNull(sqlRow)) {
                ServiceTask_Id serviceTaskId = (ServiceTask_Id) sqlRow.getId("F1_SVC_TASK_ID", ServiceTask.class);
                pmocServiceTask = serviceTaskId.getEntity();
            }
            
            getPmocServiceTask.close();
            
            return pmocServiceTask;
            
        }        

        private Money getBillEndingBalance() {
        	           
        	Money endingBalance = Money.ZERO;
        	
            StringBuilder stringBuilder = new StringBuilder();      
            stringBuilder.append("SELECT SUM(CUR_AMT) AS CUR_AMT ");
            stringBuilder.append("FROM CI_BILL_SA ");
            stringBuilder.append("WHERE BILL_ID = :billId ");

            PreparedStatement getBillEndingBal = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            getBillEndingBal.bindId("billId", bill.getId());            
            getBillEndingBal.setAutoclose(false);

            SQLResultRow sqlRow = getBillEndingBal.firstRow();
            if (notNull(sqlRow)) {
            	//Start Add - DLampa - E-05275.Issue1 - 2022-11-07
            	//Retrieve the entity again to prevent the lazy initialization exception
            	bill = billId.getEntity(); 
            	//End Add - DLampa - E-05275.Issue1 - 2022-11-07
            	endingBalance = sqlRow.getMoney("CUR_AMT", bill.getAccount().getCurrency().getId());
            }
            
            getBillEndingBal.close();
            
            return endingBalance;
            
        }  
        
        public void createOutboundMessage(Bool isBillDue) { 
        	// 05/19/2025 Kiran Begin of Changes
        	DateFormat dateFormat = new DateFormat("MM/dd/yyyy");
        	
    		com.splwg.base.api.datatypes.Date currentDate = getProcessDateTime().getDate();
    		AccountFinancialBalanceData financialBalance = bill.getAccount().getFinancialBalances(currentDate, currentDate);
    		
    		if (financialBalance.getCurrentAmount().isGreaterThan(Money.ZERO))
    		{
    		// 05/19/2025 Kiran End of Changes
	        	//Create outbound notification to SAP
				ServiceScriptInstance serviceScriptInstance = null;
				serviceScriptInstance = ServiceScriptInstance.create(CM_SAPNOTIF);
				/* Start change 2025-06-09 INC0061561 replaced bill.getAutopay amount for financialBalance.getCurrentAmount*/
				serviceScriptInstance.set("account", bill.getAccount().getId().getTrimmedValue());
				serviceScriptInstance.set("event", isBillDue.isTrue() ? "BDUE" : "APAY");       		           		
				serviceScriptInstance.set("textMessage", 
						isBillDue.isTrue() ? CustomMessageRepositorySpireOne.B21239_5_BillDue(billDueNumDays.toString()).getMessageText().trim()
										   : CustomMessageRepositorySpireOne.B21239_5_AutopayDue(financialBalance.getCurrentAmount().getAmount().toString(), bill.getDueDate().toString()).getMessageText().trim());        				
				/*End change 2025-06-09 */
				// Populate the parameters depending on the available PMOC preference 
				if (notBlank(pmocEmailAddress)){  				
					serviceScriptInstance.set("communicationType", "E");
					
					serviceScriptInstance.set("emailDestination", pmocEmailAddress);	
					serviceScriptInstance.set("emailParameter1", getBillEndingBalance().getAmount().toString());
					serviceScriptInstance.set("emailParameter2", bill.getDueDate().toString(new DateFormat("MM/dd/yyyy")));
					serviceScriptInstance.set("emailParameter3", bill.getAccount().getId().getTrimmedValue());
	    		} 
				
				if (notBlank(pmocSms)){  				
					serviceScriptInstance.set("communicationType", "T");
					
					serviceScriptInstance.set("textDestination", pmocSms);
				}
	    		
				// Update the communication type if both email and sms are available
	    		if (notBlank(pmocEmailAddress) && notBlank(pmocSms)) {
					serviceScriptInstance.set("communicationType", "A");
	    		}        		
			
				try{
					ServiceScriptDispatcher.invoke(serviceScriptInstance);	
				} catch (ApplicationError e){
					e.getServerMessage();
				}  
				
				// Add the Outbound Message Id as a Bill Characteristic
				String outboundMessageId = serviceScriptInstance.getString("outboundMessageId");
				if (!isBlankOrNull(outboundMessageId)) {
					BillCharacteristics billChars = bill.getCharacteristics();
					BillCharacteristic_DTO billCharDto = billChars.newChildDTO();
					if (OUTMSGCHARTYPE.getCharacteristicType().isAdhocValue()) {
						billCharDto.setAdhocCharacteristicValue(outboundMessageId);
					} else  if (OUTMSGCHARTYPE.getCharacteristicType().isPredefinedValue()) {
						billCharDto.setCharacteristicValue(outboundMessageId);
					} else  if (OUTMSGCHARTYPE.getCharacteristicType().isForeignKeyValue()) {
						billCharDto.setCharacteristicValueForeignKey1(outboundMessageId);
					}
					
					billChars.add(billCharDto, OUTMSGCHARTYPE.getId(), getBillCharSequence(OUTMSGCHARTYPE).add(BigInteger.ONE));
					
					// Update the existing characteristic so that the bill is not processed in the next batch run
					CharacteristicType charType = isBillDue.isTrue() ? billDueCharType : apayCharType;
					//Start Change - DLampa - E-05275.Issue1 - 2022-11-07
			        //ListFilter<BillCharacteristic> charFilter = billChars.createFilter("where this.id.characteristicType = :charType " +
			        //        "order by this.id.sequence desc" , getClass().getName());
			        //charFilter.bindEntity("charType", charType);
	
			        // BillCharacteristic billChar = charFilter.firstRow();
					BillCharacteristic_Id billCharId = new BillCharacteristic_Id(charType, bill, getBillCharSequence(charType));
					BillCharacteristic billChar = billCharId.getEntity();
					//End Change - DLampa - E-05275.Issue1 - 2022-11-07	     
			        if (notNull(billChar)) {
			        	billCharDto = billChar.getDTO();
			        	           
			            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			            if (charTypeLookup.isForeignKeyValue()) {
			            	billCharDto.setCharacteristicValueForeignKey1(SNT);		               
			            }
			            else if (charTypeLookup.isPredefinedValue()) {
			            	billCharDto.setCharacteristicValue(SNT);
			            }
			            else if (charTypeLookup.isAdhocValue()){ 
			            	billCharDto.setAdhocCharacteristicValue(SNT);
			            }
			            
			            billChar.setDTO(billCharDto);
			        }				
				}
    		}

        }
        
		public BigInteger getBillCharSequence(CharacteristicType charType){
			
			BigInteger sequence = BigInteger.ZERO;
			
			//Start Change - DLampa - E-05275.Issue1 - 2022-11-07		
			//ListFilter<BillCharacteristic> bc = bill.getCharacteristics().createFilter("WHERE this.id.characteristicType = :charType order by this.id.sequence desc", getClass().getName());
			//bc.bindEntity("charType", charType);						
			
			//if (!bc.list().isEmpty()){
			//	sequence = bc.firstRow().fetchIdSequence();
			//}
            StringBuilder stringBuilder = new StringBuilder();      
            stringBuilder.append("SELECT NVL(MAX(SEQ_NUM), 0) AS SEQ_NUM  ");
            stringBuilder.append("FROM CI_BILL_CHAR ");
            stringBuilder.append("WHERE BILL_ID = :bill ");           
            stringBuilder.append(  "AND CHAR_TYPE_CD = :charType ");

            PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==getBillCharSequence==");
            prepState.bindEntity("bill", bill);
            prepState.bindEntity("charType", charType);
            prepState.setAutoclose(false);
            prepState.execute();
            if (notNull(prepState.firstRow())) {
                SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
                sequence = sqlRow.getInteger("SEQ_NUM");          
            }
            prepState.close();
			//End Change - DLampa - E-05275.Issue1 - 2022-11-07		
			return sequence;
			
		}        
        
        /**
         * Process Autopay
         */
        private void processApay() {

        	// Determine if the account has a balance as of the bill completion date
        	AccountFinancialBalanceData acctFinancialBalance = bill.getAccount().getFinancialBalances(bill.getCompletedDatetime().getDate(), bill.getCompletedDatetime().getDate());
        	if (acctFinancialBalance.getCurrentAmount().isGreaterThan(Money.ZERO)) {
        		// Continue processing only if the current date is exactly X days prior to the due date
        		if (!getProcessDateTime().getDate().equals(bill.getDueDate().addDays(apayNumDays.negate().intValue()))) {
        			return;
        		}        		
        		
        		// Retrieve the main person's PMOC preference(s)
        		Bool isPmocPreferenceAvailable = getPmocPreferences();        		
        		if (isPmocPreferenceAvailable.isTrue()) {
        			createOutboundMessage(Bool.FALSE);
        		}
        	}

        }                  
 
        //Start Add - DLampa - E-05275.Issue1 - 2022-11-07
        private Person_Id getAccountMainPerson() {

        	Person_Id returnValue = null;

            StringBuilder stringBuilder = new StringBuilder();      
            stringBuilder.append("SELECT AP.PER_ID ");
            stringBuilder.append("FROM CI_ACCT_PER AP, CI_ACCT A ");
            stringBuilder.append("WHERE AP.ACCT_ID = :account ");
            stringBuilder.append(  "AND A.ACCT_ID = AP.ACCT_ID ");            
            stringBuilder.append(  "AND AP.MAIN_CUST_SW = 'Y' ");

            PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==getAccountMainPerson==");
            prepState.bindEntity("account", bill.getAccount());
            prepState.setAutoclose(false);
            prepState.execute();
            if (notNull(prepState.firstRow())) {
                SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
                returnValue = (Person_Id) sqlRow.getId("PER_ID", Person.class);          
            }
            prepState.close();

            return returnValue;
            
        }      
        //End Add - DLampa - E-05275.Issue1 - 2022-11-07
 
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }
    }
    
}