/* ************************************************************************                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Revenue Model Extract Batch per CIS Division
 * 
 * This batch program extracts the Revenue Rate Class data for a given 
 * CIS Division and writes that data into a custom Revenue Model table 
 * CM_REVENUE_MODEL.
 * 
 * Soft parameters are configured via the Revenue Extract Configuration 
 * Service Task Type batch parameter.
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:       Reason:
 * YYYY-MM-DD   IN        Reason text.
 *           
 * 2015-02-28   WCARAN    MGE-CCB020 Initial Version.
 *              BMarquez
 * 2015-06-17   BMarquez  SF-3237998. Revenue extract issues.
 * 2015-08-10	SMiranda  Defect 3276923. Default UOM_CD to target UOM
 * 2015-08-12   SMiranda  Defect 3277830. Booking usage and revenue to 
 * 						  transport versus transport-sales should be driven 
 * 						  by the existence of the "transport sales indicator" 
 * 						  characteristic
 * 2015-08-19   SMiranda  Defect 3289547. Do not add bill count if no usage
 * 						  or revenue was posted.
 * 2015-10-20   SMiranda  SF-58620. Also extract GRT from MGE adjustments
 * 2016-01-29  	MPang	  Updated for CCB v2.4 compilation. 
 * 2021-05-14	JMeden	  CCB040. Update to include the adjustments with
 * 						  Include in Revenue Extract Characteristic Type 
 * 2021-07-01	GCrisp	  CCB040.Issue1. Revenue Extract updates
 * 2021-08-09	GCrisp	  CCB040.Issue2. Only post the adjustment amount 
                          for non-sales transportation revenue rate class
 * 2021-10-05   GCrisp    Defect 4603727. Duplicate Bill Count issue. 
 *                        Refactor Accounting Period processing logic.
 *************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSFieldDataAndMD;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*// 2015-10.20. SMiran. SF-58620. Start Add
import com.splwg.ccb.domain.adjustment.adjustment.Adjustment_Id;
// 2015-10.20. SMiran. SF-58620. End Add
import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure;
import com.splwg.ccb.domain.billing.billSegment.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.BillSegment_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.financial.financialTransaction.FinancialTransaction;*/

import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;


/**
 *
 @BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = serviceTaskType, name = SERVICE_TASK_TYPE, required = true, type = entity)
 *                       , @BatchJobSoftParameter (entityName = characteristicType, name = ADJ_TYPE_CHAR_TYPE, required = true, type = entity)})
 */
public class CmRevenueModelExtractPerCisDivisionBatch extends
        CmRevenueModelExtractPerCisDivisionBatch_Gen {
    // Constants
    /** CM-RevenueExtractConfiguration */
    private static final BusinessObject_Id REVENUE_EXTRACT_CONFIG_BO = new BusinessObject_Id("CM-RevenueExtractConfiguration");
    /** 30 */
    private static final BigDecimal AVERAGE_BILL_DAYS = BigDecimal.valueOf(30);
    /** 26 */
    private static final BigDecimal BILL_COUNT_LOWER_THRESHOLD = BigDecimal.valueOf(26);
    /** 35 */
    private static final BigDecimal BILL_COUNT_UPPER_THRESHOLD = BigDecimal.valueOf(35);
    // enum's are not allowed on Batch Programs
    /** GENERAL */
    private static final String REVENUE_CLASS_TYPE_GENERAL = "GENERAL";
    /** TRANSPORTATION */
    private static final String REVENUE_CLASS_TYPE_TRANSPORTATION = "TRANSPORTATION";
    /** TRANSPORTATION_SALES */
    private static final String REVENUE_CLASS_TYPE_TRANSPORTATION_SALES = "TRANSPORTATION_SALES";
    
    //Start Add - JMeden - 2021-05-14 - CCB040
    private static final String CONSTANT_YES = "Y";
    //End Add - JMeden - 2021-05-14 - CCB040
	
	//Start Add - GCrisp - 2021-07-01 - CCB040.Issue1
	private static final BigDecimal BILL_COUNT_LOWER_THRESHOLD_ALGL = BigDecimal.valueOf(22);
	private static final BigDecimal BILL_COUNT_UPPER_THRESHOLD_ALGL = BigDecimal.valueOf(44);
	//End Add - GCrisp - 2021-07-01 - CCB040.Issue1
    
    @Override
    public void validateSoftParameters(boolean isJobWorkNeeded) {
        
        // Service Task Type must represent a Revenue Extract Configuration
        ServiceTaskType serviceTaskType = getParameters().getSERVICE_TASK_TYPE();
        if (!serviceTaskType.getBusinessObject().getId().equals(REVENUE_EXTRACT_CONFIG_BO)) {
            addError(CustomMessageRepositoryMGE.ccb020RvxInvalidServiceTaskTypeBusinessObject(serviceTaskType, REVENUE_EXTRACT_CONFIG_BO));
        }
        
        // Service Task Type must be Active
        if (!serviceTaskType.getServiceTaskTypeStatus().isActive()) {
            addError(CustomMessageRepositoryMGE.ccb020RvxInactiveServiceTaskType(serviceTaskType));
        }
        
        BusinessObjectInstance businessObjectInstance = BusinessObjectInstance.create(serviceTaskType.getBusinessObject());
        businessObjectInstance.set("serviceTaskType", serviceTaskType.getId().getTrimmedValue());
        businessObjectInstance = BusinessObjectDispatcher.read(businessObjectInstance);
        
        if (isNull(businessObjectInstance.getGroup("extractDetails").getEntity("cisDivision", CisDivision.class))) {
            addError(CustomMessageRepositoryMGE.ccb004MissingCisDivision(serviceTaskType));
        }
        
        super.validateSoftParameters(isJobWorkNeeded);
        
    }

    public JobWork getJobWork() {
        
        // Read the Revenue Extract Configuration Service Task Type Business Object Instance
        ServiceTaskType serviceTaskType = getParameters().getSERVICE_TASK_TYPE();
        BusinessObjectInstance businessObjectInstance = BusinessObjectInstance.create(serviceTaskType.getBusinessObject());
        businessObjectInstance.set("serviceTaskType", serviceTaskType.getId().getTrimmedValue());
        businessObjectInstance = BusinessObjectDispatcher.read(businessObjectInstance);
        
        // Retrieve the CIS Division, and use it to purge the Revenue Model
        clearRevenueModel(businessObjectInstance.getGroup("extractDetails").getEntity("cisDivision", CisDivision.class));
		
		// Start Add - GCrisp - Defect 4603727 - 2021-10-04
		List<String> accountingPeriodList = getOpenAccountingPeriods(getProcessDateTime().getDate());
		// End Add - GCrisp - Defect 4603727 - 2021-10-04
        
        // Build the list of work units
        List<ThreadWorkUnit> threadWorkUnitList = new ArrayList<ThreadWorkUnit>();  
        
        // Retrieve the entries on the Revenue Rate Class List
        COTSInstanceList revenueRateClassList = businessObjectInstance.getGroup("extractDetails").getGroup("revenueRateClassList").getList("revenueRateClass");          
        Iterator<COTSInstanceListNode> revenueRateClassListIterator = revenueRateClassList.iterator();
        while (revenueRateClassListIterator.hasNext()) {
			COTSInstanceListNode cotsInstanceListNode = revenueRateClassListIterator.next();
			// Start Change - GCrisp - Defect 4603727 - 2021-10-04
            for(int x = 0; x < accountingPeriodList.size(); x++) {
				ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
				threadWorkUnit.addSupplementalData("revenueRateClass", cotsInstanceListNode.getString("revenueRateClass").trim());
				threadWorkUnit.addSupplementalData("description", cotsInstanceListNode.getString("description").trim());
				threadWorkUnit.addSupplementalData("fercNumber", cotsInstanceListNode.getString("fercNumber").trim());
				threadWorkUnit.addSupplementalData("revenueClassType", REVENUE_CLASS_TYPE_GENERAL);
				threadWorkUnit.addSupplementalData("accountingPeriod", accountingPeriodList.get(x));
				threadWorkUnitList.add(threadWorkUnit);
			}	
            // End Change - GCrisp - Defect 4603727 - 2021-10-04
        }
        
        // Retrieve the entries on the Transportation Revenue Rate Class List
        COTSInstanceList transportationRevenueRateClassList = businessObjectInstance.getGroup("extractDetails").getGroup("transportationRevenueRateClassList").getList("transportationRevenueRateClass");
        Iterator<COTSInstanceListNode> transportationRevenueRateClassListIterator = transportationRevenueRateClassList.iterator();
        while (transportationRevenueRateClassListIterator.hasNext()) {
            COTSInstanceListNode cotsInstanceListNode = transportationRevenueRateClassListIterator.next();
            
			// Start Change - GCrisp - Defect 4603727 - 2021-10-04
            for(int x = 0; x < accountingPeriodList.size(); x++) {
				ThreadWorkUnit transportationThreadWorkUnit = new ThreadWorkUnit();
				transportationThreadWorkUnit.addSupplementalData("revenueRateClass", cotsInstanceListNode.getGroup("transportation").getString("revenueRateClass").trim());
				transportationThreadWorkUnit.addSupplementalData("description", cotsInstanceListNode.getGroup("transportation").getString("description").trim());
				transportationThreadWorkUnit.addSupplementalData("fercNumber", cotsInstanceListNode.getGroup("transportation").getString("fercNumber").trim());
				transportationThreadWorkUnit.addSupplementalData("revenueClassType", REVENUE_CLASS_TYPE_TRANSPORTATION);
				transportationThreadWorkUnit.addSupplementalData("accountingPeriod", accountingPeriodList.get(x));
				threadWorkUnitList.add(transportationThreadWorkUnit);

				ThreadWorkUnit salesThreadWorkUnit = new ThreadWorkUnit();
				salesThreadWorkUnit.addSupplementalData("revenueRateClass", cotsInstanceListNode.getGroup("sales").getString("revenueRateClass").trim());
				salesThreadWorkUnit.addSupplementalData("description", cotsInstanceListNode.getGroup("sales").getString("description").trim());
				salesThreadWorkUnit.addSupplementalData("fercNumber", cotsInstanceListNode.getGroup("sales").getString("fercNumber").trim());
				salesThreadWorkUnit.addSupplementalData("revenueClassType", REVENUE_CLASS_TYPE_TRANSPORTATION_SALES);
				salesThreadWorkUnit.addSupplementalData("accountingPeriod", accountingPeriodList.get(x));
				threadWorkUnitList.add(salesThreadWorkUnit);
			}	
            // End Change - GCrisp - Defect 4603727 - 2021-10-04
        }
        
        return createJobWorkForThreadWorkUnitList(threadWorkUnitList);
        
    }
    
    /**
     * Delete all records in the custom Revenue Model (CM_REVENUE_MODEL) with the conditions:
     * <ol>
     *  <li>Transfer to GL Date is equal to the batch process date.</li>
     *  <li>CIS Division matches the Revenue Extract Configuration's CIS Division.</li>
     * </ol>
     * @param cisDivision - CIS Division of Revenue Extract Configuration
     */
    private void clearRevenueModel(CisDivision cisDivision) {    	
    	
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DELETE FROM ");
        stringBuilder.append(    "CM_REVENUE_MODEL ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(    "XFER_TO_GL_DT = :processDate ");
        stringBuilder.append(    "AND CIS_DIVISION = :cisDivision ");  
        //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString()); 
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName()); 
        //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        preparedStatement.bindDate("processDate", getProcessDateTime().getDate());
        preparedStatement.bindId("cisDivision", cisDivision.getId());
        preparedStatement.execute();
        preparedStatement.close();
        
    }
	
	// Start Add - GCrisp - Defect 4603727 - 2021-10-04
	private List<String> getOpenAccountingPeriods(Date date) {            
		List<String> accountingPeriodList = new ArrayList<String>();
		StringBuilder stringBuilder = new StringBuilder();
		
		stringBuilder.append("SELECT ");
		stringBuilder.append(    "CPL.PERIOD_DESCR ");
		stringBuilder.append("FROM ");
		stringBuilder.append(    "CI_CAL_PERIOD CP, ");
		stringBuilder.append(    "CI_CAL_PERIOD_L CPL ");
		stringBuilder.append("WHERE ");
		stringBuilder.append(    "CP.ACCOUNTING_PERIOD = CPL.ACCOUNTING_PERIOD ");
		stringBuilder.append(    "AND CP.FISCAL_YEAR = CPL.FISCAL_YEAR ");
		stringBuilder.append(    "AND CP.OPEN_FROM_DT <= :date ");
		stringBuilder.append(    "AND CP.OPEN_TO_DT >= :date ");
		
		PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		preparedStatement.bindDate("date", date);
		
		preparedStatement.setAutoclose(false);
		preparedStatement.execute();

		if (preparedStatement.list().size() > 0) {
			Iterator<SQLResultRow> iter = preparedStatement.list().iterator();
			while (iter.hasNext()) {
				SQLResultRow sqlRow = iter.next();
				accountingPeriodList.add(sqlRow.getString("PERIOD_DESCR"));
			}
		}
		
		preparedStatement.close();
		return accountingPeriodList;
	}
	// End Add - GCrisp - Defect 4603727 - 2021-10-04

    public Class<CmRevenueModelExtractPerCisDivisionBatchWorker> getThreadWorkerClass() {
        return CmRevenueModelExtractPerCisDivisionBatchWorker.class;
    }

    public static class CmRevenueModelExtractPerCisDivisionBatchWorker extends
            CmRevenueModelExtractPerCisDivisionBatchWorker_Gen {        
        // Soft Parameters
        private ServiceTaskType serviceTaskType;
        //Start Add  - JMeden - 2021-05-14 - CCB040
        private CharacteristicType adjustmentTypeCharType;
        //End Add  - JMeden - 2021-05-14 - CCB040
        
        private CisDivision cisDivision;
        private ServiceQuantityIdentifier daysBilledSqi;
        private CharacteristicType transportSalesCharacteristicType;
        private CharacteristicType saRateClassCharacteristicType;
        private CharacteristicType usageTypeCharacteristicType;
        private CharacteristicType revenueTypeCharacteristicType;
        private UnitOfMeasure fileUom;
        
        private List<ExtractColumn> generalExtractColumnList = new ArrayList<ExtractColumn>();
        private List<ExtractColumn> usageExtractColumnList = new ArrayList<ExtractColumn>();
        private List<ExtractColumn> revenueExtractColumnList = new ArrayList<ExtractColumn>();
        
        /**
         * ExtractColumn stores information regarding the CM_REVENUE_MODEL table. These values
         * are read from the Business Object and many of them are not UI-configurable. They are
         * pre-populated via Service Script CM-RvxBoPre.<br/>
         * <br/>
         * Types of Extract Column:
         * <ol>
         *  <li>
         *      General - These fields identify the source of the row information such as Revenue
         *      Rate Class and FERC Number. Values for these fields are inserted directly.
         *  </li>
         *  <li>
         *      Usage - These fields are assigned a Usage Type via Service Script CM-RvxBoPre. Its
         *      contents are resolved dynamically as the total of the Calc Lines referencing this
         *      Usage Type.
         *  </li>
         *  <li>
         *      Revenue - These fields are assigned a Revenue Type via Service Script CM-RvxBoPre. 
         *      Its contents are resolved dynamically as the total of the Calc Lines referencing 
         *      this Revenue Type.
         *  </li>
         * </ol>
         */
        private class ExtractColumn {
            
            private BigInteger sequence;
            private String fieldName;
            private String characteristicValue;
            
            public ExtractColumn() {}
            
            public ExtractColumn(BigInteger sequence, String fieldName, String characteristicValue) {
                this.sequence = sequence; 
                this.fieldName = fieldName;
                this.characteristicValue = characteristicValue;
            }
            
            public BigInteger getSequence() {
                return sequence;
            }
            
            public String getFieldName() {
                return fieldName;
            }
            
            public String getCharacteristicValue() {
                return characteristicValue;
            }
            
            public void setSequence(BigInteger sequence) {
                this.sequence = sequence;
            }
            
            public void setFieldName(String fieldName) {
                this.fieldName = fieldName;
            }
            
            public void setCharacteristicValue(String characteristicValue) {
                this.characteristicValue = characteristicValue;
            }
            
        }
        
        /**
         * SA Type Revenue Rate stores the unique SA Type/Rate Class combination when the
         * Service Agreement Type is classified for a particular Revenue Rate Class.
         */
        private class SaTypeRevenueRate {
            
            private String saType;
            private String saRateClass;
            
            public SaTypeRevenueRate() {}
            
            public SaTypeRevenueRate(String saType, String saRateClass) {
                this.saType = saType;
                this.saRateClass = saRateClass;
            }

            public String getSaRateClass() {
                return saRateClass;
            }

            public void setSaRateClass(String saRateClass) {
                this.saRateClass = saRateClass;
            }

            public String getSaType() {
                return saType;
            }

            public void setSaType(String saType) {
                this.saType = saType;
            }
            
        }
        
        private HashMap<String, List<SaTypeRevenueRate>> revenueRateSaTypeClassifications = new HashMap<String, List<SaTypeRevenueRate>>();
        
        private HashMap<UnitOfMeasure, BigDecimal> uomConversionTable = new HashMap<UnitOfMeasure, BigDecimal>();
        
        // Hard parameters (Revenue Rate Class Thread Work Unit)
        private String revenueRateClass;
        private String description;
        private String fercNumber;
        private String revenueClassType;
        private UnitOfMeasure unitOfMeasure;
        
        // Work Variables
        private BigDecimal billCount = BigDecimal.ZERO;
        private BigInteger serviceAgreementCount = BigInteger.ZERO;
        private HashMap<ExtractColumn, BigDecimal> revenueClassTotals;
		
		// Start Add - GCrisp - Defect 4603727 - 2021-10-04
		private String accountingPeriod;
		// End Add - GCrisp - Defect 4603727 - 2021-10-04

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new CommitEveryUnitStrategy(this);
        }
        
        @Override
        public void initializeThreadWork(boolean initializationPreviouslySuccessful) 
                throws ThreadAbortedException, RunAbortedException {        	
            
            // The Service Task Type parameter provides all soft parameters for the Batch 
            serviceTaskType = getParameters().getSERVICE_TASK_TYPE();
            //Start Add - JMeden - 2021-05-14 - CCB040
            adjustmentTypeCharType = getParameters().getADJ_TYPE_CHAR_TYPE();
            //End Add - JMeden - 2021-05-14 - CCB040

            BusinessObjectInstance businessObjectInstance = BusinessObjectInstance.create(serviceTaskType.getBusinessObject());
            businessObjectInstance.set("serviceTaskType", serviceTaskType.getId().getTrimmedValue());
            businessObjectInstance = BusinessObjectDispatcher.read(businessObjectInstance);

            COTSInstanceNode extractDetails = businessObjectInstance.getGroup("extractDetails");       
            
            cisDivision = extractDetails.getEntity("cisDivision", CisDivision.class);
            daysBilledSqi = extractDetails.getEntity("daysBilledSqi", ServiceQuantityIdentifier.class);
            transportSalesCharacteristicType = extractDetails.getEntity("transportSalesCharacteristicType", CharacteristicType.class);
            saRateClassCharacteristicType = extractDetails.getEntity("saRateClassCharacteristicType", CharacteristicType.class);
            usageTypeCharacteristicType = extractDetails.getEntity("usageTypeCharacteristicType", CharacteristicType.class);
            revenueTypeCharacteristicType = extractDetails.getEntity("revenueTypeCharacteristicType", CharacteristicType.class);
            fileUom = extractDetails.getEntity("fileUom", UnitOfMeasure.class);
            
            // Retrieve and set SA Type Classifications
            COTSInstanceList saTypeRevenueRateClassificationList = extractDetails.getGroup("saTypeRateClassList").getList("saTypeRateClass");
            Iterator<COTSInstanceListNode> saTypeRevenueRateClassificationListIterator = saTypeRevenueRateClassificationList.iterator();
            
            while (saTypeRevenueRateClassificationListIterator.hasNext()) {
                
                COTSInstanceListNode cotsInstanceListNode = saTypeRevenueRateClassificationListIterator.next();
                SaTypeRevenueRate saTypeRevenueRate = new SaTypeRevenueRate();
                saTypeRevenueRate.setSaType(cotsInstanceListNode.getString("saType"));
                saTypeRevenueRate.setSaRateClass(cotsInstanceListNode.getString("saRateClass"));
                
                // Add to list of Revenue Rate Class' SA Types
                String revenueRateClass = cotsInstanceListNode.getString("revenueRateClass");
                List<SaTypeRevenueRate> saTypeRevenueRateList = revenueRateSaTypeClassifications.get(revenueRateClass);
                if (isNull(saTypeRevenueRateList)) {
                    saTypeRevenueRateList = new ArrayList<SaTypeRevenueRate>();
                }
                saTypeRevenueRateList.add(saTypeRevenueRate);
                revenueRateSaTypeClassifications.put(revenueRateClass, saTypeRevenueRateList);
                
            }
            
            // Retrieve and set Transportation and Transportation Sales SA Type Classifications
            COTSInstanceList saTypeTransportationRevenueRateClassificationList = extractDetails.getGroup("saTypeTransportationRateClassList").getList("saTypeTransportationRateClass");
            Iterator<COTSInstanceListNode> saTypeRevenueRateTransportationClassificationListIterator = saTypeTransportationRevenueRateClassificationList.iterator();
            
            while (saTypeRevenueRateTransportationClassificationListIterator.hasNext()) {
                
                COTSInstanceListNode cotsInstanceListNode = saTypeRevenueRateTransportationClassificationListIterator.next();
                SaTypeRevenueRate saTypeRevenueRate = new SaTypeRevenueRate();
                saTypeRevenueRate.setSaType(cotsInstanceListNode.getString("saType"));
                saTypeRevenueRate.setSaRateClass(cotsInstanceListNode.getString("saRateClass"));
                
                // Add to list of Transportation Revenue Rate Class' SA Types
                String revenueRateClass = cotsInstanceListNode.getString("revenueRateClass");
                List<SaTypeRevenueRate> saTypeRevenueRateList = revenueRateSaTypeClassifications.get(revenueRateClass);
                if (isNull(saTypeRevenueRateList)) {
                    saTypeRevenueRateList = new ArrayList<SaTypeRevenueRate>();
                }
                saTypeRevenueRateList.add(saTypeRevenueRate);
                revenueRateSaTypeClassifications.put(revenueRateClass, saTypeRevenueRateList);
                
                // Find Transportation Sales Revenue Rate Class
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("transportationRevenueRateClass[transportation/revenueRateClass='");
                stringBuilder.append(revenueRateClass);
                stringBuilder.append("']/sales/revenueRateClass");
                COTSFieldDataAndMD cotsFieldDataAndMd = extractDetails.getGroup("transportationRevenueRateClassList").getFieldAndMDForPath(stringBuilder.toString());
                
                // Add to list of Transportation Revenue Rate Class' SA Types
                revenueRateClass = cotsFieldDataAndMd.getValue().toString();
                saTypeRevenueRateList = revenueRateSaTypeClassifications.get(revenueRateClass);
                if (isNull(saTypeRevenueRateList)) {
                    saTypeRevenueRateList = new ArrayList<SaTypeRevenueRate>();
                }
                saTypeRevenueRateList.add(saTypeRevenueRate);
                revenueRateSaTypeClassifications.put(revenueRateClass, saTypeRevenueRateList);
                
            }
            
            // Retrieve and set Extract Column Definitions
            COTSInstanceList extractColumnDefinitionList = extractDetails.getGroup("extractColumnList").getList("extractColumn");
            Iterator<COTSInstanceListNode> extractColumnDefinitionListIterator = extractColumnDefinitionList.iterator();
            
            while (extractColumnDefinitionListIterator.hasNext()) {
                
                COTSInstanceListNode cotsInstanceListNode = extractColumnDefinitionListIterator.next();
                ExtractColumn extractColumn = new ExtractColumn();
                extractColumn.setSequence(cotsInstanceListNode.getNumber("sequence").toBigInteger());
                extractColumn.setFieldName(cotsInstanceListNode.getString("field"));
                
                String usageType = cotsInstanceListNode.getString("usageType");
                if (notBlank(usageType)) {
                    extractColumn.setCharacteristicValue(usageType);
                    usageExtractColumnList.add(extractColumn);
                }
                
                String revenueType = cotsInstanceListNode.getString("revenueType");
                if (notBlank(revenueType)) {
                    extractColumn.setCharacteristicValue(revenueType);
                    revenueExtractColumnList.add(extractColumn);
                }
                
                if (isBlankOrNull(usageType) && isBlankOrNull(revenueType)) {
                    generalExtractColumnList.add(extractColumn);
                }
                
            }
            
            // Retrieve UOM Conversion Factors
            COTSInstanceList uomConversionFactorList = extractDetails.getGroup("uomConversionFactorList").getList("uomConversionFactor");
            Iterator<COTSInstanceListNode> uomConversionFactorListIterator = uomConversionFactorList.iterator();
            while (uomConversionFactorListIterator.hasNext()) {
                COTSInstanceListNode uomConversionFactor = uomConversionFactorListIterator.next();
                uomConversionTable.put(uomConversionFactor.getEntity("sourceUom", UnitOfMeasure.class), uomConversionFactor.getNumber("conversionFactor"));
            }
            
        }
        
        /**
         * This method processes the work unit for each Revenue Rate Class and FERC Number retrieved from the Job Work
         * @param workUnit - the work unit from the Job Work
         * @return workUnitResult - the result after processing the work unit, e.g. number of records processed and number of records in error
         */
        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit workUnit)
                throws ThreadAbortedException, RunAbortedException {        	
            // Initialize some working variables
            int recordsProcessed = 0;
            int recordsInError = 0;
			
            revenueClassTotals = new HashMap<ExtractColumn, BigDecimal>();
            serviceAgreementCount = BigInteger.ZERO;
            billCount = BigDecimal.ZERO;
            
            // Retrieve Extract Details from the work unit
            revenueRateClass = workUnit.getSupplementallData("revenueRateClass").toString().trim();
            description = workUnit.getSupplementallData("description").toString().trim();
            fercNumber = workUnit.getSupplementallData("fercNumber").toString().trim(); 
            revenueClassType = workUnit.getSupplementallData("revenueClassType").toString();
			// Start Add - GCrisp - Defect 4603727 - 2021-10-04
			accountingPeriod = workUnit.getSupplementallData("accountingPeriod").toString();
			// End Add - GCrisp - Defect 4603727 - 2021-10-04
            
            unitOfMeasure = null;
            
            List<SaTypeRevenueRate> saTypeRevenueRateList = revenueRateSaTypeClassifications.get(revenueRateClass);
            
            if (notNull(saTypeRevenueRateList)) {

                for (SaTypeRevenueRate saTypeRevenueRate : saTypeRevenueRateList) {

                    // Retrieve Financial Transactions to process
                    ServiceAgreement previousServiceAgreement = null;
                    for (SQLResultRow sqlResultRow : getRevenueRateClassFinancialTransactions(saTypeRevenueRate)) {
						
                        recordsProcessed += 1;
                        
                        // Process FT record
                        FinancialTransaction financialTransaction = sqlResultRow.getEntity("FT_ID", FinancialTransaction.class);
                        ServiceAgreement serviceAgreement = sqlResultRow.getEntity("SA_ID", ServiceAgreement.class);
                        /*
                         * Start Add - Defect 3237998 - 2015-06-17
                         */
                        FinancialTransactionTypeLookup financialTransactionType = financialTransaction.getFinancialTransactionType();
                        /*
                         * End Add - Defect 3237998 - 2015-06-17
                         */
                        boolean postedAmount = false;
                        
                        // Calculate the Usage totals
                        for (ExtractColumn extractColumn : usageExtractColumnList) {
                            
                            BigDecimal usageColumnAmount = revenueClassTotals.get(extractColumn);
                            
                            if (isNull(usageColumnAmount)) {
                                usageColumnAmount = BigDecimal.ZERO;
                            }
                            BigDecimal usageAmount = getUsageAmount(financialTransaction, extractColumn.getCharacteristicValue());
                            if (usageAmount.compareTo(BigDecimal.ZERO) != 0) {
                                /*
                                 * Start Change - Defect 3237998 - 2015-06-17
                                 */
                                //usageColumnAmount = usageColumnAmount.add(usageAmount);
                                if (financialTransactionType.isBillSegment()) {
                                    usageColumnAmount = usageColumnAmount.add(usageAmount);
                                } else if (financialTransactionType.isBillCancellation()) {
                                    usageColumnAmount = usageColumnAmount.subtract(usageAmount);
                                }
                                /*
                                 * End Change - Defect 3237998 - 2015-06-17
                                 */
                                postedAmount = true;
                            }

                            revenueClassTotals.put(extractColumn, usageColumnAmount);
                            
                        }
                        
                        // Calculate the Revenue totals
                        for (ExtractColumn extractColumn : revenueExtractColumnList) {
                            BigDecimal revenueColumnAmount = revenueClassTotals.get(extractColumn);
                            if (isNull(revenueColumnAmount)) {
                                revenueColumnAmount = BigDecimal.ZERO;
                            }
                            
                            BigDecimal revenueAmount = getRevenueAmount(financialTransaction, extractColumn.getCharacteristicValue());
                            
                            if (revenueAmount.compareTo(BigDecimal.ZERO) != 0) {
                                /*
                                 * Start Change - Defect 3237998 - 2015-06-17
                                 */
                                //revenueColumnAmount = revenueColumnAmount.add(revenueAmount);
                                if (financialTransactionType.isBillSegment()) {
                                    revenueColumnAmount = revenueColumnAmount.add(revenueAmount);
                                } else if (financialTransactionType.isBillCancellation()) {
                                    revenueColumnAmount = revenueColumnAmount.subtract(revenueAmount);
                                }
                                /*
                                 * End Change - Defect 3237998 - 2015-06-17
                                 */
                                postedAmount = true;
                            }

                            revenueClassTotals.put(extractColumn, revenueColumnAmount);
                            
                        }
                        
                        // Each SA on the Revenue Rate Class must be counted only once
                        if (postedAmount && (isNull(previousServiceAgreement) || !previousServiceAgreement.equals(serviceAgreement))) {

                            serviceAgreementCount = serviceAgreementCount.add(BigInteger.ONE);
                            
                            if (REVENUE_CLASS_TYPE_TRANSPORTATION_SALES.equals(revenueClassType)) {
                                
                                // Re-queries the SA for FTs with non-zero Usage and Revenue without Sales Indicators 
                                if (transportationRevenueExistsForServiceAgreement(serviceAgreement)) {
                                    serviceAgreementCount = serviceAgreementCount.subtract(BigInteger.ONE);
                                }
                                
                            }
                            
                        }
                        
                        previousServiceAgreement = serviceAgreement;
                        
                        // 2015-08-19. SMiranda. Defect 3289547. Start Change
                        if (postedAmount){
                        	billCount = billCount.add(calculateCyclesPerBill(financialTransaction));
                        }
                        // 2015-08-19. SMiranda. Defect 3289547. End Change
                        
                    }

                    // 2015-10-20. SMiranda. SF-58620. Start Add
                    // If CIS Division is "MGE", extract GRT from Adjustments
                    // Start Delete - JMeden - 2021-05-14 - CCB040
                    //if (cisDivision.getId().getTrimmedValue().equals("MGE")){
                    // End Delete - JMeden - 2021-05-14 - CCB040
					//Start Add - GCrisp - 2021-08-09 - CCB040.Issue2
					//Only post the adjustment amount for non-sales transportation revenue rate class
					if (!REVENUE_CLASS_TYPE_TRANSPORTATION_SALES.equals(revenueClassType)) {
					//End Add - GCrisp - 2021-08-09 - CCB040.Issue2
                        for (SQLResultRow sqlResultRow : getAdjustmentFTs(saTypeRevenueRate)) {

                            recordsProcessed += 1;
                            
                            // Process FT record
                            FinancialTransaction financialTransaction = sqlResultRow.getEntity("FT_ID", FinancialTransaction.class);
                            FinancialTransactionTypeLookup financialTransactionType = financialTransaction.getFinancialTransactionType();
						    
                            // Calculate the Revenue totals
                            for (ExtractColumn extractColumn : revenueExtractColumnList) {
                                
                                BigDecimal revenueColumnAmount = revenueClassTotals.get(extractColumn);
                                if (isNull(revenueColumnAmount)) {
                                    revenueColumnAmount = BigDecimal.ZERO;
                                }
                                
                                BigDecimal revenueAmount = getAdjustmentRevenueAmount(financialTransaction, extractColumn.getCharacteristicValue());
                                
                                if (revenueAmount.compareTo(BigDecimal.ZERO) != 0) {
						    
                                    //revenueColumnAmount = revenueColumnAmount.add(revenueAmount);
                                    if (financialTransactionType.isAdjustment()) {
                                        revenueColumnAmount = revenueColumnAmount.add(revenueAmount);
                                    } else if (financialTransactionType.isAdjustmentCancellation()) {
                                        revenueColumnAmount = revenueColumnAmount.subtract(revenueAmount);
                                    }
                                }
						    
                                revenueClassTotals.put(extractColumn, revenueColumnAmount);
                                
                            }
						}
                    //Start Add - GCrisp - 2021-08-09 - CCB040.Issue2
                	}
					//End Add - GCrisp - 2021-08-09 - CCB040.Issue2
                    // Start Delete - JMeden - 2021-05-14 - CCB040
                    //}
                	// End Delete - JMeden - 2021-05-14 - CCB040
                    // 2015-10-20. SMiranda. SF-58620. End Add
                    
                }
            }
            
            // Write record to the Revenue Model table
            exportRevenueClass();
            
            // Set and return results of processing the work unit
            WorkUnitResult results = new WorkUnitResult(true);
            results.setUnitsProcessed(recordsProcessed);
            results.setUnitsInError(recordsInError);
            return results;
            
        }
        
        /**
         * This method retrieves Financial Transactions using the following conditions:
         * <ol>
         *  <li>FT's Transfer to GL Date is equal to batch process date.</li>
         *  <li>FT is either a Bill Segment or a Bill Segment Cancellation.</li>
         *  <li>FT has CIS Division from current Revenue Extract Configuration Service Task Type.</li>
         *  <li>FT's Service Agreement matches the current SA Type being processed.</li>
         *  <li>FT's Service Agreement has the SA Rate Class Characteristic value being processed.</li>
         * </ol>
         * @param SaTypeRevenueRate saTypeRevenueRate
         * @return List&lt;SQLResultRow&gt; 
         */
        private List<SQLResultRow> getRevenueRateClassFinancialTransactions(SaTypeRevenueRate saTypeRevenueRate) {
            
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT DISTINCT ");
            stringBuilder.append(    "FT.SA_ID, ");
            stringBuilder.append(    "FT.FT_ID ");
            stringBuilder.append("FROM ");
            stringBuilder.append(    "CI_FT FT, ");
            stringBuilder.append(    "CI_SA SA, ");
			// Start Change - GCrisp - Defect 4603727 - 2021-10-04
            //stringBuilder.append(    "CI_SA_CHAR SACH ");
			stringBuilder.append(    "CI_SA_CHAR SACH, ");
			stringBuilder.append(    "CI_CAL_PERIOD CP, ");
			stringBuilder.append(    "CI_CAL_PERIOD_L CPL ");
			// End Add - GCrisp - Defect 4603727 - 2021-10-04
            stringBuilder.append("WHERE ");
            stringBuilder.append(    "FT.XFER_TO_GL_DT = :transferToGLDate ");
            stringBuilder.append(    "AND FT.FT_TYPE_FLG IN (:billSegment, :billSegmentCancel) ");
            stringBuilder.append(    "AND FT.CIS_DIVISION = :cisDivision "); 
            stringBuilder.append(    "AND SA.SA_ID = FT.SA_ID ");
            stringBuilder.append(    "AND SA.CIS_DIVISION = FT.CIS_DIVISION ");
            stringBuilder.append(    "AND SA.SA_TYPE_CD = :saType ");
            stringBuilder.append(    "AND SACH.SA_ID = SA.SA_ID ");
            stringBuilder.append(    "AND SACH.CHAR_TYPE_CD = :saRateClassCharacteristicType ");
            stringBuilder.append(    "AND SACH.CHAR_VAL = :saRateClass ");
            stringBuilder.append(    "AND SACH.EFFDT = ( ");
            stringBuilder.append(        "SELECT ");
            stringBuilder.append(            "MAX(SACH2.EFFDT) ");
            stringBuilder.append(        "FROM ");
            stringBuilder.append(            "CI_SA_CHAR SACH2 ");
            stringBuilder.append(        "WHERE ");
            stringBuilder.append(            "SACH2.SA_ID = SA.SA_ID ");
            stringBuilder.append(            "AND SACH2.CHAR_TYPE_CD = SACH.CHAR_TYPE_CD ");
            stringBuilder.append(            "AND SACH2.EFFDT <= :processDate) ");
			// Start Add - GCrisp - Defect 4603727 - 2021-10-04
			stringBuilder.append(    "AND CPL.PERIOD_DESCR = :accountingPeriod ");
			stringBuilder.append(    "AND CP.ACCOUNTING_PERIOD = CPL.ACCOUNTING_PERIOD ");
			stringBuilder.append(    "AND CP.FISCAL_YEAR = CPL.FISCAL_YEAR ");
			stringBuilder.append(    "AND CP.BEGIN_DT <= FT.ACCOUNTING_DT ");
			stringBuilder.append(    "AND CP.END_DT >= FT.ACCOUNTING_DT ");
			// End Add - GCrisp - Defect 4603727 - 2021-10-04
            // 2015-08-12. SMiranda. Defect 3277830. Start Delete
            //if (REVENUE_CLASS_TYPE_TRANSPORTATION.equals(revenueClassType)) {
            //    stringBuilder.append(    "AND NOT EXISTS ( ");
            //}
            
            //if (REVENUE_CLASS_TYPE_TRANSPORTATION_SALES.equals(revenueClassType)) {
            //    stringBuilder.append(    "AND EXISTS ( ");
            //}
            
            //if (REVENUE_CLASS_TYPE_TRANSPORTATION.equals(revenueClassType) 
            //        || REVENUE_CLASS_TYPE_TRANSPORTATION_SALES.equals(revenueClassType)) {
            //    stringBuilder.append(        "SELECT ");
            //    stringBuilder.append(            "'X' ");
            //    stringBuilder.append(        "FROM ");
            //    stringBuilder.append(            "CI_BSEG_CALC_LN BSCL, ");
            //    stringBuilder.append(            "CI_BSEG_CL_CHAR CLCH ");
            //    stringBuilder.append(        "WHERE ");
            //    stringBuilder.append(            "BSCL.BSEG_ID = FT.SIBLING_ID ");
            //    stringBuilder.append(            "AND BSCL.CALC_AMT <> 0 ");
            //    stringBuilder.append(            "AND CLCH.BSEG_ID = BSCL.BSEG_ID ");
            //    stringBuilder.append(            "AND CLCH.HEADER_SEQ = BSCL.HEADER_SEQ ");
            //    stringBuilder.append(            "AND CLCH.SEQNO = BSCL.SEQNO ");
            //    stringBuilder.append(            "AND CLCH.CHAR_TYPE_CD = :transportSalesCharacteristicType) ");
            //}
            // 2015-08-12. SMiranda. Defect 3277830. End Delete
            stringBuilder.append("ORDER BY ");
            stringBuilder.append(    "FT.SA_ID ASC ");
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString()); 
            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName()); 
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            preparedStatement.bindDate("transferToGLDate", getProcessDateTime().getDate());
            preparedStatement.bindLookup("billSegment", FinancialTransactionTypeLookup.constants.BILL_SEGMENT);
            preparedStatement.bindLookup("billSegmentCancel", FinancialTransactionTypeLookup.constants.BILL_CANCELLATION);
            preparedStatement.bindId("cisDivision", cisDivision.getId());
            preparedStatement.bindString("saType", saTypeRevenueRate.getSaType(), "SA_TYPE_CD");     
            preparedStatement.bindId("saRateClassCharacteristicType", saRateClassCharacteristicType.getId());
            preparedStatement.bindString("saRateClass", saTypeRevenueRate.getSaRateClass(), "CHAR_VAL");              
            preparedStatement.bindDate("processDate", getProcessDateTime().getDate());
			// Start Add - GCrisp - Defect 4603727 - 2021-10-04
			preparedStatement.bindString("accountingPeriod", accountingPeriod, getClass().getName());  
			// End Add - GCrisp - Defect 4603727 - 2021-10-04
            // 2015-08-12. SMiranda. Defect 3277830. Start Delete
            //if (REVENUE_CLASS_TYPE_TRANSPORTATION.equals(revenueClassType) 
            //        || REVENUE_CLASS_TYPE_TRANSPORTATION_SALES.equals(revenueClassType)) {
            //    preparedStatement.bindId("transportSalesCharacteristicType", transportSalesCharacteristicType.getId());
            //}
            // 2015-08-12. SMiranda. Defect 3277830. End Delete
			
            List<SQLResultRow> list = preparedStatement.list();
			// Start Add - GCrisp - Defect 4603727 - 2021-10-04
			preparedStatement.setAutoclose(false);
			// Start Add - GCrisp - Defect 4603727 - 2021-10-04
            preparedStatement.close();
            
            return list;
            
        }
        
        // 2015-10-20. SMiran. SF-58620. Start Add
        /**
         * This method retrieves Adjustment FTs using the following conditions:
         * <ol>
         *  <li>FT's Transfer to GL Date is equal to batch process date.</li>
         *  <li>FT is either an Adjustment or an Adjustment Cancellation.</li>
         *  <li>FT has CIS Division from current Revenue Extract Configuration Service Task Type.</li>
         *  <li>FT's Service Agreement matches the current SA Type being processed.</li>
         *  <li>FT's Service Agreement has the SA Rate Class Characteristic value being processed.</li>
         * </ol>
         * @param SaTypeRevenueRate saTypeRevenueRate
         * @return List&lt;SQLResultRow&gt;
         */
        private List<SQLResultRow> getAdjustmentFTs(SaTypeRevenueRate saTypeRevenueRate) {
            
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT DISTINCT ");
            stringBuilder.append(    "FT.FT_ID ");
            stringBuilder.append("FROM ");
            stringBuilder.append(    "CI_FT FT, ");
            stringBuilder.append(    "CI_SA SA, ");
			// Start Change - GCrisp - Defect 4603727 - 2021-10-04
            //stringBuilder.append(    "CI_SA_CHAR SACH ");
			stringBuilder.append(    "CI_SA_CHAR SACH, ");
			stringBuilder.append(    "CI_CAL_PERIOD CP, ");
			stringBuilder.append(    "CI_CAL_PERIOD_L CPL ");
			// End Add - GCrisp - Defect 4603727 - 2021-10-04
            stringBuilder.append("WHERE ");
            stringBuilder.append(    "FT.XFER_TO_GL_DT = :transferToGLDate ");
            stringBuilder.append(    "AND FT.FT_TYPE_FLG IN ('AD', 'AX') ");
            stringBuilder.append(    "AND FT.CIS_DIVISION = :cisDivision "); 
            stringBuilder.append(    "AND SA.SA_ID = FT.SA_ID ");
            stringBuilder.append(    "AND SA.CIS_DIVISION = FT.CIS_DIVISION ");
            stringBuilder.append(    "AND SA.SA_TYPE_CD = :saType ");
            stringBuilder.append(    "AND SACH.SA_ID = SA.SA_ID ");
            stringBuilder.append(    "AND SACH.CHAR_TYPE_CD = :saRateClassCharacteristicType ");
            stringBuilder.append(    "AND SACH.CHAR_VAL = :saRateClass ");
            stringBuilder.append(    "AND SACH.EFFDT = ( ");
            stringBuilder.append(        "SELECT ");
            stringBuilder.append(            "MAX(SACH2.EFFDT) ");
            stringBuilder.append(        "FROM ");
            stringBuilder.append(            "CI_SA_CHAR SACH2 ");
            stringBuilder.append(        "WHERE ");
            stringBuilder.append(            "SACH2.SA_ID = SA.SA_ID ");
            stringBuilder.append(            "AND SACH2.CHAR_TYPE_CD = SACH.CHAR_TYPE_CD ");
            stringBuilder.append(            "AND SACH2.EFFDT <= :processDate) ");
            stringBuilder.append(" AND EXISTS ");
            stringBuilder.append(		"(SELECT 'X' ");
            stringBuilder.append(		" FROM CI_ADJ_CL_CHAR ACLC ");
            stringBuilder.append(		"WHERE ACLC.ADJ_ID = FT.SIBLING_ID AND ACLC.CHAR_TYPE_CD = :revenueTypeCharacteristicType)");   
            // Start Add - JMeden - 2021-05-14 - CCB040	
            stringBuilder.append(    " AND EXISTS (SELECT 'X' ");
            stringBuilder.append(                " FROM CI_ADJ_TY_CHAR CA ");
            stringBuilder.append(                " WHERE CA.ADJ_TYPE_CD = FT.PARENT_ID ");
            stringBuilder.append(                " AND CA.CHAR_TYPE_CD = :revexCharType ");
            stringBuilder.append(                " AND CA.CHAR_VAL = :trueVal ) ");
			// Start Add - GCrisp - Defect 4603727 - 2021-10-04
			stringBuilder.append(    " AND CPL.PERIOD_DESCR = :accountingPeriod ");
			stringBuilder.append(    " AND CP.ACCOUNTING_PERIOD = CPL.ACCOUNTING_PERIOD ");
			stringBuilder.append(    " AND CP.FISCAL_YEAR = CPL.FISCAL_YEAR ");
			stringBuilder.append(    " AND CP.BEGIN_DT <= FT.ACCOUNTING_DT ");
			stringBuilder.append(    " AND CP.END_DT >= FT.ACCOUNTING_DT ");
			// End Add - GCrisp - Defect 4603727 - 2021-10-04
            // End Add - JMeden - 2021-05-14 - CCB040	
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString()); 
            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName()); 
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            preparedStatement.bindDate("transferToGLDate", getProcessDateTime().getDate());
            preparedStatement.bindId("cisDivision", cisDivision.getId());
            preparedStatement.bindString("saType", saTypeRevenueRate.getSaType(), "SA_TYPE_CD"); 
            preparedStatement.bindId("saRateClassCharacteristicType", saRateClassCharacteristicType.getId());
            preparedStatement.bindString("saRateClass", saTypeRevenueRate.getSaRateClass(), "CHAR_VAL");     
            preparedStatement.bindDate("processDate", getProcessDateTime().getDate());
            preparedStatement.bindId("revenueTypeCharacteristicType", revenueTypeCharacteristicType.getId());
            // Start Add - JMeden - 2021-05-14 - CCB040
            preparedStatement.bindId("revexCharType", adjustmentTypeCharType.getId());
            preparedStatement.bindString("trueVal", CONSTANT_YES, "CHAR_VAL");  
            // End Add - JMeden - 2021-05-14 - CCB040
			// Start Add - GCrisp - Defect 4603727 - 2021-10-04
			preparedStatement.bindString("accountingPeriod", accountingPeriod, getClass().getName());  
			// End Add - GCrisp - Defect 4603727 - 2021-10-04
            List<SQLResultRow> list = preparedStatement.list();
			// Start Add - GCrisp - Defect 4603727 - 2021-10-04
			preparedStatement.setAutoclose(false);
			// End Add - GCrisp - Defect 4603727 - 2021-10-04
            preparedStatement.close();
			
            return list;
            
        }
        
        /**
         * Sums the Adjustment Financial Transaction's Adjustment Calculation Line Amounts.
         * @param financialTransaction - the Financial Transaction being processed
         * @param revenueType - the Calc Line Char Value that identifies the Revenue Type
         * @return revenueAmount - sum of Bill Segment Calc Lines' Calculated Amount
         */
        private BigDecimal getAdjustmentRevenueAmount(FinancialTransaction financialTransaction, String revenueType) {           	
            
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");  
            stringBuilder.append(    "NVL(SUM(ACL.CALC_AMT), 0) AS CALC_AMT_SUM ");         
            stringBuilder.append("FROM ");
            stringBuilder.append(    "CI_ADJ_CALC_LN ACL, ");
            stringBuilder.append(    "CI_ADJ_CL_CHAR ACLC  ");
            stringBuilder.append("WHERE ");
            stringBuilder.append(    "ACL.ADJ_ID = :adjustmentId ");
            stringBuilder.append(    "AND ACLC.ADJ_ID = ACL.ADJ_ID ");
            stringBuilder.append(    "AND ACLC.SEQNO = ACL.SEQNO ");
            stringBuilder.append(    "AND ACLC.CHAR_TYPE_CD = :revenueTypeCharacteristicType ");
            stringBuilder.append(    "AND ACLC.CHAR_VAL = :revenueType ");
            
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            preparedStatement.bindId("adjustmentId", new Adjustment_Id(financialTransaction.getSiblingId().trim()));
            preparedStatement.bindId("revenueTypeCharacteristicType", revenueTypeCharacteristicType.getId());
            preparedStatement.bindString("revenueType", revenueType.trim(), "CHAR_VAL");
            
            SQLResultRow sqlResultRow = preparedStatement.firstRow();
            preparedStatement.close();
            
            return (notNull(sqlResultRow)) ? sqlResultRow.getBigDecimal("CALC_AMT_SUM") : BigDecimal.ZERO;
            
        }
        // 2015-10-20. SMiran. SF-58620. End Add
        
        /**
         * Sums the Financial Transaction's Bill Segment's Bill Segment Calculation Line Service
         * Quantities. If the usage is found to not match the configured Unit of Measure for the 
         * file, the conversion table is used to convert the value.
         * @param financialTransaction - the Financial Transaction being processed
         * @param usageType - the Calc Line Char Value that identifies the Usage type
         * @return Converted Usage amount
         */
        private BigDecimal getUsageAmount(FinancialTransaction financialTransaction, String usageType) {
            
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");  
            stringBuilder.append(    "BSCL.UOM_CD, ");  
            stringBuilder.append(    "NVL(SUM(BSCL.BILL_SQ), 0) AS BILL_SQ_SUM ");         
            stringBuilder.append("FROM ");
            stringBuilder.append(    "CI_BSEG_CALC_LN BSCL, ");
            stringBuilder.append(    "CI_BSEG_CL_CHAR CLCH ");
            stringBuilder.append("WHERE ");
            stringBuilder.append(    "BSCL.BSEG_ID = :billSegmentId ");
            stringBuilder.append(    "AND CLCH.BSEG_ID = BSCL.BSEG_ID ");
            stringBuilder.append(    "AND CLCH.HEADER_SEQ = BSCL.HEADER_SEQ ");
            stringBuilder.append(    "AND CLCH.SEQNO = BSCL.SEQNO ");
            stringBuilder.append(    "AND CLCH.CHAR_TYPE_CD = :usageTypeCharacteristicType ");
            stringBuilder.append(    "AND CLCH.CHAR_VAL = :usageType ");
            // 2015-08-12. SMiranda. Defect 3277830. Start Add
            if (REVENUE_CLASS_TYPE_TRANSPORTATION.equals(revenueClassType)) {
                stringBuilder.append(    "AND NOT EXISTS ( ");
            }            
            if (REVENUE_CLASS_TYPE_TRANSPORTATION_SALES.equals(revenueClassType)) {
                stringBuilder.append(    "AND EXISTS ( ");
            }
            if (REVENUE_CLASS_TYPE_TRANSPORTATION.equals(revenueClassType) 
                    || REVENUE_CLASS_TYPE_TRANSPORTATION_SALES.equals(revenueClassType)) {
                stringBuilder.append(        "SELECT ");
                stringBuilder.append(            "'X' ");
                stringBuilder.append(        "FROM ");
                stringBuilder.append(            "CI_BSEG_CL_CHAR B ");
                stringBuilder.append(        "WHERE ");
                stringBuilder.append(            "B.BSEG_ID = CLCH.BSEG_ID ");
                stringBuilder.append(            "AND B.HEADER_SEQ = CLCH.HEADER_SEQ ");
                stringBuilder.append(            "AND B.SEQNO = CLCH.SEQNO ");
                stringBuilder.append(            "AND B.CHAR_TYPE_CD = :transportSalesCharacteristicType) ");
            }
            // 2015-08-12. SMiranda. Defect 3277830. End Add
            stringBuilder.append("GROUP BY ");
            stringBuilder.append(    "BSCL.UOM_CD ");
            stringBuilder.append("ORDER BY ");
            stringBuilder.append(    "BSCL.UOM_CD ");
            
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            preparedStatement.bindId("billSegmentId", new BillSegment_Id(financialTransaction.getSiblingId().trim()));
            preparedStatement.bindId("usageTypeCharacteristicType", usageTypeCharacteristicType.getId());
            preparedStatement.bindString("usageType", usageType.trim(), "CHAR_VAL");
            // 2015-08-12. SMiranda. Defect 3277830. Start Add
            if (REVENUE_CLASS_TYPE_TRANSPORTATION.equals(revenueClassType) 
                    || REVENUE_CLASS_TYPE_TRANSPORTATION_SALES.equals(revenueClassType)) {
                preparedStatement.bindId("transportSalesCharacteristicType", transportSalesCharacteristicType.getId());
            }
            // 2015-08-12. SMiranda. Defect 3277830. End Add
            
            List<SQLResultRow> results = preparedStatement.list();
            preparedStatement.close();
            
            BigDecimal usageAmount = BigDecimal.ZERO;
            for (SQLResultRow sqlResultRow : results) {
                
                UnitOfMeasure uom = sqlResultRow.getEntity("UOM_CD", UnitOfMeasure.class);
                BigDecimal amount = sqlResultRow.getBigDecimal("BILL_SQ_SUM");
                
                if (notNull(uom) && !uom.equals(fileUom)) {
                    
                    BigDecimal conversionFactor = uomConversionTable.get(uom);
                    if (isNull(conversionFactor)) {
                        addError(CustomMessageRepositoryMGE.ccb020MissingUomConversionFactor(serviceTaskType, uom, financialTransaction));
                    }
                    
                    amount = amount.multiply(conversionFactor);
                    
                }

                if (notNull(uom)) {
                    unitOfMeasure = fileUom;
                }
                
                usageAmount = usageAmount.add(amount);
                
            }

            return usageAmount;
            
        }
        
        /**
         * Determines the Number of Bills processed on a Revenue Rate Class by counting the
         * difference of the Debit and Credit Bill Segment Financial Transactions that have an
         * actual Extracted Date within the time period being extracted.
         * @param BigDecimal - the number of average Bills covered by the FT's Bill
         */
        private BigDecimal calculateCyclesPerBill(FinancialTransaction financialTransaction) {
            
            BigDecimal daysBilled = getBillableServiceQuantity(financialTransaction.fetchSiblingBillSegment(), daysBilledSqi);
			
			//Start Change - GCrisp - 2021-07-01 - CCB040.Issue1
            //boolean isDaysBilledBeyondThreshold = (daysBilled.compareTo(BILL_COUNT_LOWER_THRESHOLD) < 0)
            /*
             * Start Change - Defect 3237998 - 2015-06-17
             */
            //                                 && (daysBilled.compareTo(BILL_COUNT_UPPER_THRESHOLD) > 0);
            //                                   || (daysBilled.compareTo(BILL_COUNT_UPPER_THRESHOLD) > 0);
            /*
             * End Change - Defect 3237998 - 2015-06-17
             */
			boolean isDaysBilledBeyondThreshold;
			if(cisDivision.getId().getTrimmedValue().equals("LGC") || cisDivision.getId().getTrimmedValue().equals("MGE")){
				isDaysBilledBeyondThreshold = (daysBilled.compareTo(BILL_COUNT_LOWER_THRESHOLD) < 0)
												|| (daysBilled.compareTo(BILL_COUNT_UPPER_THRESHOLD) > 0);
			//Lower and Upper threshold values is different for Al/Gulf 
			} else{
				isDaysBilledBeyondThreshold = (daysBilled.compareTo(BILL_COUNT_LOWER_THRESHOLD_ALGL) < 0)
												|| (daysBilled.compareTo(BILL_COUNT_UPPER_THRESHOLD_ALGL) > 0);
			}
			//End Change - GCrisp - 2021-07-01 - CCB040.Issue1
            
            BigDecimal cyclesPerBill = BigDecimal.ONE;
            if (isDaysBilledBeyondThreshold) {
                cyclesPerBill = daysBilled.divide(AVERAGE_BILL_DAYS).setScale(2, BigDecimal.ROUND_HALF_UP);
            }
            
            if (financialTransaction.getFinancialTransactionType().isBillCancellation()) {
                return cyclesPerBill.negate();
            }

            return cyclesPerBill;
            
        }
        
        /**
         * Retrieve the Billable Service Quantity of a Bill Segment.
         * @param billSegment - the Financial Transaction's Bill Segment
         * @param sqi - the Service Quantity Identifier
         * @return Billable Service Quantity
         */
        private BigDecimal getBillableServiceQuantity(BillSegment billSegment, ServiceQuantityIdentifier sqi) {
            
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");
            stringBuilder.append(    "BSQ.BILL_SQ ");
            stringBuilder.append("FROM ");
            stringBuilder.append(    "CI_BSEG_SQ BSQ ");
            stringBuilder.append("WHERE ");
            stringBuilder.append(    "BSQ.BSEG_ID = :billSegment ");
            stringBuilder.append(    "AND BSQ.SQI_CD = :sqi ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());  
            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());  
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            preparedStatement.bindEntity("billSegment", billSegment);
            preparedStatement.bindEntity("sqi", sqi);
            
            SQLResultRow resultRow = preparedStatement.firstRow();
            preparedStatement.close();
            
            return (notNull(resultRow)) ? resultRow.getBigDecimal("BILL_SQ") : BigDecimal.ZERO;
            
        }
        
        /**
         * Sums the Financial Transaction's Bill Segment's Bill Segment Calculation Line Amounts.
         * @param financialTransaction - the Financial Transaction being processed
         * @param revenueType - the Calc Line Char Value that identifies the Revenue Type
         * @return revenueAmount - sum of Bill Segment Calc Lines' Calculated Amount
         */
        private BigDecimal getRevenueAmount(FinancialTransaction financialTransaction, String revenueType) {           	
            
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");  
            stringBuilder.append(    "NVL(SUM(BSCL.CALC_AMT), 0) AS CALC_AMT_SUM ");         
            stringBuilder.append("FROM ");
            stringBuilder.append(    "CI_BSEG_CALC_LN BSCL, ");
            stringBuilder.append(    "CI_BSEG_CL_CHAR CLCH ");
            stringBuilder.append("WHERE ");
            stringBuilder.append(    "BSCL.BSEG_ID = :billSegmentId ");
            stringBuilder.append(    "AND CLCH.BSEG_ID = BSCL.BSEG_ID ");
            stringBuilder.append(    "AND CLCH.HEADER_SEQ = BSCL.HEADER_SEQ ");
            stringBuilder.append(    "AND CLCH.SEQNO = BSCL.SEQNO ");
            stringBuilder.append(    "AND CLCH.CHAR_TYPE_CD = :revenueTypeCharacteristicType ");
            stringBuilder.append(    "AND CLCH.CHAR_VAL = :revenueType ");
            // 2015-08-12. SMiranda. Defect 3277830. Start Add
            if (REVENUE_CLASS_TYPE_TRANSPORTATION.equals(revenueClassType)) {
                stringBuilder.append(    "AND NOT EXISTS ( ");
            }            
            if (REVENUE_CLASS_TYPE_TRANSPORTATION_SALES.equals(revenueClassType)) {
                stringBuilder.append(    "AND EXISTS ( ");
            }
            if (REVENUE_CLASS_TYPE_TRANSPORTATION.equals(revenueClassType) 
                    || REVENUE_CLASS_TYPE_TRANSPORTATION_SALES.equals(revenueClassType)) {
                stringBuilder.append(        "SELECT ");
                stringBuilder.append(            "'X' ");
                stringBuilder.append(        "FROM ");
                stringBuilder.append(            "CI_BSEG_CL_CHAR B ");
                stringBuilder.append(        "WHERE ");
                stringBuilder.append(            "B.BSEG_ID = CLCH.BSEG_ID ");
                stringBuilder.append(            "AND B.HEADER_SEQ = CLCH.HEADER_SEQ ");
                stringBuilder.append(            "AND B.SEQNO = CLCH.SEQNO ");
                stringBuilder.append(            "AND B.CHAR_TYPE_CD = :transportSalesCharacteristicType) ");
            }
            // 2015-08-12. SMiranda. Defect 3277830. End Add
            
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            preparedStatement.bindId("billSegmentId", new BillSegment_Id(financialTransaction.getSiblingId().trim()));
            preparedStatement.bindId("revenueTypeCharacteristicType", revenueTypeCharacteristicType.getId());
            preparedStatement.bindString("revenueType", revenueType.trim(), "CHAR_VAL");
            // 2015-08-12. SMiranda. Defect 3277830. Start Add
            if (REVENUE_CLASS_TYPE_TRANSPORTATION.equals(revenueClassType) 
                    || REVENUE_CLASS_TYPE_TRANSPORTATION_SALES.equals(revenueClassType)) {
                preparedStatement.bindId("transportSalesCharacteristicType", transportSalesCharacteristicType.getId());
            }
            // 2015-08-12. SMiranda. Defect 3277830. End Add
            
            SQLResultRow sqlResultRow = preparedStatement.firstRow();
            preparedStatement.close();
            return (notNull(sqlResultRow)) ? sqlResultRow.getBigDecimal("CALC_AMT_SUM") : BigDecimal.ZERO;
            
        }
        
        /**
         * This method writes a record into the Revenue Model table by constructing the insert
         * statement from the extract column listing on the Service Task Type.
         */
        private void exportRevenueClass() { 
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("INSERT INTO CM_REVENUE_MODEL ");
            stringBuilder.append(   "(");
            
            for (int i = 0; i < generalExtractColumnList.size(); i++) {
                if (i > 0) {
                    stringBuilder.append(", ");
                }
                stringBuilder.append(generalExtractColumnList.get(i).fieldName);
            }
            
            for (int i = 0; i < usageExtractColumnList.size(); i++) {
                stringBuilder.append(", ");
                stringBuilder.append(usageExtractColumnList.get(i).fieldName);
            }
            
            for (int i = 0; i < revenueExtractColumnList.size(); i++) {
                stringBuilder.append(", ");
                stringBuilder.append(revenueExtractColumnList.get(i).fieldName);
            }
            
            stringBuilder.append(    ") ");
            stringBuilder.append("VALUES ");
            stringBuilder.append(    "( ");
            
            for (int i = 0; i < generalExtractColumnList.size(); i++) {
                if (i > 0) {
                    stringBuilder.append(", ");
                }
                stringBuilder.append(":general" + i);
            }
            
            for (int i = 0; i < usageExtractColumnList.size(); i++) {
                stringBuilder.append(", ");
                stringBuilder.append(":usage" + i);
            }
            
            for (int i = 0; i < revenueExtractColumnList.size(); i++) {
                stringBuilder.append(", ");
                stringBuilder.append(":revenue" + i);
            }
            
            stringBuilder.append(    ") ");
            
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
           
            preparedStatement.bindId("general0", cisDivision.getId());               
            preparedStatement.bindDate("general1", getProcessDateTime().getDate());
			// Start Change - GCrisp - Defect 4603727 - 2021-10-04
            //preparedStatement.bindString("general2", revenueRateClass, "CM_RVX_REV_RATE_CLASS_CD");
			preparedStatement.bindString("general2", accountingPeriod, getClass().getName());
            //preparedStatement.bindString("general3", fercNumber, "CM_RVX_FERC_NBR");
			preparedStatement.bindString("general3", revenueRateClass, "CM_RVX_REV_RATE_CLASS_CD");
			//Start Delete - GCrisp - 2021-07-01 - CCB040.Issue1
            //Start Add - JMeden - 2021-05-14 - CCB040
            //if(cisDivision.getId().getTrimmedValue().equals("LGC") || cisDivision.getId().getTrimmedValue().equals("MGE")){
            //End Add - JMeden - 2021-05-14 - CCB040
			//End Delete - GCrisp - 2021-07-01 - CCB040.Issue1
            //preparedStatement.bindString("general4", description, "CM_RVX_REV_RATE_CL_DESCR");
			preparedStatement.bindString("general4", fercNumber, "CM_RVX_FERC_NBR");
            //preparedStatement.bindBigInteger("general5", serviceAgreementCount);
			preparedStatement.bindString("general5", description, "CM_RVX_REV_RATE_CL_DESCR");
			//preparedStatement.bindBigInteger("general5", serviceAgreementCount);
            preparedStatement.bindBigInteger("general6", serviceAgreementCount);
			//preparedStatement.bindBigDecimal("general6", billCount);
			preparedStatement.bindBigDecimal("general7", billCount);
            // 2015-08-10. SMiran. Defect 3276923. Start Change
            //preparedStatement.bindString("general7", (isNull(unitOfMeasure)) ? "" : unitOfMeasure.getId().getTrimmedValue(), "UOM_CD");
            //preparedStatement.bindString("general7", 
			preparedStatement.bindString("general8", 
            		(isNull(unitOfMeasure)) ? fileUom.getId().getTrimmedValue() : unitOfMeasure.getId().getTrimmedValue(), "UOM_CD");
			// Start Change - GCrisp - Defect 4603727 - 2021-10-04
            // 2015-08-10. SMiran. Defect 3276923. End Chaenge
			//Start Delete - GCrisp - 2021-07-01 - CCB040.Issue1
            //Start Add - JMeden - 2021-05-14 - CCB040
            //} else{
            //    preparedStatement.bindBigInteger("general4", serviceAgreementCount);
            //    preparedStatement.bindBigDecimal("general5", billCount);
            //    preparedStatement.bindString("general6", 
            //    		(isNull(unitOfMeasure)) ? fileUom.getId().getTrimmedValue() : unitOfMeasure.getId().getTrimmedValue(), "UOM_CD");
            //}
            //End Add - JMeden - 2021-05-14 - CCB040
			//End Delete - GCrisp - 2021-07-01 - CCB040.Issue1
            
            for (int i = 0; i < usageExtractColumnList.size(); i++) {
                BigDecimal usageTotal = revenueClassTotals.get(usageExtractColumnList.get(i));
                preparedStatement.bindBigDecimal("usage" + i, (notNull(usageTotal)) ? usageTotal : BigDecimal.ZERO);
            }
            
            for (int i = 0; i < revenueExtractColumnList.size(); i++) {

                BigDecimal revenueTotal = revenueClassTotals.get(revenueExtractColumnList.get(i));

                /*
                 * Start Change - Defect 3237998 - 2015-06-17
                 */
                //preparedStatement.bindBigDecimal("revenue" + i, (notNull(revenueTotal)) ? revenueTotal : BigDecimal.ZERO);
                preparedStatement.bindBigDecimal("revenue" + i, (notNull(revenueTotal)) ? revenueTotal.negate() : BigDecimal.ZERO);
                /*
                 * End Change - Defect 3237998 - 2015-06-17
                 */
            }
            preparedStatement.execute();
            preparedStatement.close();
            
        }
        
        /**
         * Service Agreements with non-zero transport non-sales revenue or usage are already counted
         * by the Transportation Revenue Class and should not be re-counted. This requeries
         * indicators that the Service Agreement has already been processed. 
         * @param serviceAgreement
         * @return true if non-zero transport non-sales revenue or usage exists on Service Agreement for the process date
         */
        private boolean transportationRevenueExistsForServiceAgreement(ServiceAgreement serviceAgreement) {
            
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");
            stringBuilder.append(    "'X' ");
            stringBuilder.append("FROM ");
            stringBuilder.append(    "CI_FT FT, ");
            stringBuilder.append(    "CI_BSEG_CALC_LN BSCL ");
            stringBuilder.append("WHERE ");
            stringBuilder.append(    "FT.SA_ID = :serviceAgreement ");
            stringBuilder.append(    "AND FT.XFER_TO_GL_DT = :transferToGLDate ");
            stringBuilder.append(    "AND FT.FT_TYPE_FLG IN (:billSegment, :billSegmentCancel) ");
            stringBuilder.append(    "AND BSCL.BSEG_ID = FT.SIBLING_ID ");
            stringBuilder.append(    "AND BSCL.CALC_AMT <> 0 ");
            stringBuilder.append(    "AND EXISTS ( ");
            stringBuilder.append(        "SELECT ");
            stringBuilder.append(            "'X' ");
            stringBuilder.append(        "FROM ");
            stringBuilder.append(            "CI_BSEG_CL_CHAR CLCH ");
            stringBuilder.append(        "WHERE ");
            stringBuilder.append(            "CLCH.BSEG_ID = BSCL.BSEG_ID ");
            stringBuilder.append(            "AND CLCH.HEADER_SEQ = BSCL.HEADER_SEQ ");
            stringBuilder.append(            "AND CLCH.SEQNO = BSCL.SEQNO ");
            stringBuilder.append(            "AND CLCH.CHAR_TYPE_CD IN (:usageTypeCharacteristicType, :revenueTypeCharacteristicType) ");
            stringBuilder.append(            "AND NOT EXISTS ( ");
            stringBuilder.append(                "SELECT ");
            stringBuilder.append(                    "'X' ");
            stringBuilder.append(                "FROM ");
            stringBuilder.append(                    "CI_BSEG_CL_CHAR CLCH1 ");
            stringBuilder.append(                "WHERE ");
            stringBuilder.append(                    "CLCH1.BSEG_ID = CLCH.BSEG_ID ");
            stringBuilder.append(                    "AND CLCH1.HEADER_SEQ = CLCH.HEADER_SEQ ");
            stringBuilder.append(                    "AND CLCH1.SEQNO = CLCH.SEQNO ");
            stringBuilder.append(                    "AND CLCH1.CHAR_TYPE_CD = :transportSalesCharacteristicType)) ");
            
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            preparedStatement.bindId("serviceAgreement", serviceAgreement.getId());
            preparedStatement.bindDate("transferToGLDate", getProcessDateTime().getDate());
            preparedStatement.bindLookup("billSegment", FinancialTransactionTypeLookup.constants.BILL_SEGMENT);
            preparedStatement.bindLookup("billSegmentCancel", FinancialTransactionTypeLookup.constants.BILL_CANCELLATION);
            preparedStatement.bindId("usageTypeCharacteristicType", usageTypeCharacteristicType.getId());
            preparedStatement.bindId("revenueTypeCharacteristicType", revenueTypeCharacteristicType.getId());
            preparedStatement.bindId("transportSalesCharacteristicType", transportSalesCharacteristicType.getId());
            
            SQLResultRow sqlResultRow = preparedStatement.firstRow();
            
            preparedStatement.close();
            
            return notNull(sqlResultRow);
            
        }
    }
}
