/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Keep Over payment and Pledge Over Payment Separated Algorithm.
 * 
 * Clone (JAVA Version) of the CIPPOCSX Program with the following 
 * additional functionality:
 * 
 *     - Create a To Do Entry when Pledge Payment is applied to an in-eligible
 *       Service Agreement.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-09-30   JHERNA      SysAid#73573. Initial Version. Post v2.4 upgrade.
 * *************************************************************************                
 */
package com.splwg.cm.domain.admin.customerClass.algorithm.overpayment;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.ccb.api.lookup.CustomerReadLookup;
import com.splwg.ccb.api.lookup.PaymentStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.StartReasonLookup;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.customerClass.algorithm.overpayment.CustomerClassOverpaymentDistributionAlgorithmSpot;
import com.splwg.ccb.domain.admin.customerClass.algorithm.overpayment.CustomerClassOverpaymentDistributionData;
import com.splwg.ccb.domain.admin.depositClass.entity.DepositClass;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.common.ServiceAgreementCreator;
import com.splwg.ccb.domain.customerinfo.data.ServiceAgreementCreatorData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.ccb.domain.payment.payment.entity.PaymentSegment_DTO;
import com.splwg.ccb.domain.payment.payment.entity.Payment_DTO;
import com.splwg.ccb.domain.payment.payment.entity.Payment_Id;
import com.splwg.cm.api.lookup.CmPledgePaymentsOptionTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
import com.splwg.cm.domain.common.customBusinessComponent.CmReinstateServiceAgreementRoutine;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = cisDivision, name = cisDivisionOverpayment, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = saTypeOverpayment, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = createSeperatePayment, type = boolean)
 *            , @AlgorithmSoftParameter (name = reinstateExcessCreditServiceAgreement, type = boolean)
 *            , @AlgorithmSoftParameter (entityName = cisDivision, name = cisDivisionPledgeOverpayment, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = saTypePledgeOverpayment, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = featConfPledgePayment, required = true, type = entity)})
 */
public class CmKeepOverpaymentAndPledgeOverpaymentsSeperateAlgComp_Impl 
		extends CmKeepOverpaymentAndPledgeOverpaymentsSeperateAlgComp_Gen 
		implements CustomerClassOverpaymentDistributionAlgorithmSpot {

	// Hard Parameters
	private List<CustomerClassOverpaymentDistributionData> outputCollOfCcOverpaymentDistributionData;
	private Payment outputOverpaymentPayment;
	private Money outputTotalAmountDistributed;
	private Account inputAccount;
	private Money inputCreditAmount;
	@SuppressWarnings("unused")
	private DepositClass inputDepositClass;
	private Payment inputPayment;
	private BigInteger inputPaymentSACount;
	@SuppressWarnings("unused")
	private Date inputProcessDate;
	
	// Soft Parameters
	private ServiceAgreementType parmSaTypeOverpayment;
	private ServiceAgreementType parmSaTypePledgeOverpayment;
	private Bool parmCreateSeperatePayment;
	private Bool parmReinstateExcessCreditSA;
	private FeatureConfiguration parmFeatConfPledgePayment;
	
	// Work Variable(s)
	private Money wCreditAmount;
	private Payment_Id wOverpaymentPayID;
	private Bool wCreateOverpaymentSw;
	private Bool wReinstateSASw;
	@SuppressWarnings("unused")
	private CisDivision_Id wCisDivisionID;
	@SuppressWarnings("unused")
	private String wSaTypeID;
	private Bool wCreditSAFoundSw;
	private Bool wPaySegFndSw;
	private ServiceAgreement_Id wTempSAID;
	private ServiceAgreement_Id wSAID;
	private List<TenderSource_Id> wCollOfPledgeTenderSourceIDs;

	@Override
	public List<CustomerClassOverpaymentDistributionData> getCustomerClassOverpaymentDistributionData() {
		return outputCollOfCcOverpaymentDistributionData;
	}

	@Override
	public Payment getOverpaymentPayment() {
		return outputOverpaymentPayment;
	}

	@Override
	public Money getTotalAmountDistributed() {
		return outputTotalAmountDistributed;
	}

	@Override
	public void setAccount(Account acctID) {
		inputAccount = acctID;
	}

	@Override
	public void setCreditAmount(Money credAmt) {
		inputCreditAmount = credAmt;
	}

	@Override
	public void setDepositClass(DepositClass depositClass) {
		inputDepositClass = depositClass;
	}

	@Override
	public void setPayment(Payment payment) {
		inputPayment = payment;
	}

	@Override
	public void setPaymentServiceAgreementCount(BigInteger paymentSACount) {
		inputPaymentSACount = paymentSACount;
	}

	@Override
	public void setProcessDate(Date processDate) {
		inputProcessDate = processDate;
	}

	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {		
		
		// Retrieve Algorithm Parameters
		
		CisDivision cisDivOverpayment = this.getCisDivisionOverpayment();
		String saTypeOverpaymentStr = this.getSaTypeOverpayment();
		ServiceAgreementType_Id overpaymentSaTypeID = new ServiceAgreementType_Id(
				cisDivOverpayment.getId(), saTypeOverpaymentStr.trim());
		if (isNull(overpaymentSaTypeID.getEntity())) {
			// Algorithm %1's CIS Division parameter (%2) and SA Type parameter (%3) combination is invalid.
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterSATypeInvalid(
					this.getAlgorithmId().getTrimmedValue(),
					cisDivOverpayment.getId().getTrimmedValue(),
					saTypeOverpaymentStr.trim()));
		}
		parmSaTypeOverpayment = overpaymentSaTypeID.getEntity();
		
		parmCreateSeperatePayment = Bool.FALSE;
		if (notNull(this.getCreateSeperatePayment())) {
			parmCreateSeperatePayment = this.getCreateSeperatePayment();
		}
		
		parmReinstateExcessCreditSA = Bool.FALSE;
		if (notNull(this.getReinstateExcessCreditServiceAgreement())) {
			parmReinstateExcessCreditSA = this.getReinstateExcessCreditServiceAgreement();
		}
		
		CisDivision cisDivPledgeOverpayment = this.getCisDivisionPledgeOverpayment();
		String saTypePledgeOverpaymentStr = this.getSaTypePledgeOverpayment();
		ServiceAgreementType_Id pledgeOverpaymentSaTypeID = new ServiceAgreementType_Id(
				cisDivPledgeOverpayment.getId(), saTypePledgeOverpaymentStr.trim());
		if (isNull(pledgeOverpaymentSaTypeID.getEntity())) {
			// Algorithm %1's CIS Division parameter (%2) and SA Type parameter (%3) combination is invalid.
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterSATypeInvalid(
					this.getAlgorithmId().getTrimmedValue(),
					cisDivPledgeOverpayment.getId().getTrimmedValue(),
					saTypePledgeOverpaymentStr.trim()));
		}
		parmSaTypePledgeOverpayment = pledgeOverpaymentSaTypeID.getEntity();
		
		parmFeatConfPledgePayment = this.getFeatConfPledgePayment();
		// Retrieve Pledge Tender Source from the feature configuration.
		cmRetrievePledgeTenderSources();
	}
	
	private void cmRetrievePledgeTenderSources() {
		
		// Initialize 
		wCollOfPledgeTenderSourceIDs = new ArrayList<TenderSource_Id>();
		CmMGEFeatureConfigurationOptionsRetriever featConfRoutine = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
		// Retrieve the option value (comma delimited)		
		String optVal = featConfRoutine.cmGetFeatOptValue(parmFeatConfPledgePayment.getId(),
				CmPledgePaymentsOptionTypeLookup.constants.PLEDGE_TENDER_SOURCE,
				Bool.TRUE,
				Bool.FALSE);
		// Retrieve, Validate and Store the valid pledge tender sources
		String[] strArrayOptVal = optVal.trim().split(",");
		for (String pledgeTS : strArrayOptVal) {
			
			if (notBlank(pledgeTS)) {				
				TenderSource_Id tsID = new TenderSource_Id(pledgeTS.trim());
				if (notNull(tsID.getEntity())) {
					wCollOfPledgeTenderSourceIDs.add(tsID);
				}
			}
		}		
	}

	@Override
	public void invoke() {
		
		/*
		 * Start Base Cobol CIPPOCSX functionality
		 */
		// Initialize
		initialize();
		// Check input
		checkInput();
		// Perform Processing
		performProcessing();
		/*
		 * End Base Cobol CIPPOCSX functionality
		 */
	}
	
	private void initialize() {
		
		// Initialize
		outputOverpaymentPayment = null;
		outputTotalAmountDistributed = new Money(BigDecimal.ZERO, inputAccount.getCurrency().getId());
		outputCollOfCcOverpaymentDistributionData = new ArrayList<CustomerClassOverpaymentDistributionData>();
		
		wOverpaymentPayID = null;		
		wReinstateSASw = Bool.FALSE;
		wCreditSAFoundSw = Bool.FALSE;
		wCreateOverpaymentSw = Bool.FALSE;		
		wPaySegFndSw = Bool.FALSE;
		wCreditAmount = new Money(BigDecimal.ZERO, inputAccount.getCurrency().getId());
		wSAID = null;
		wTempSAID = null;
	}
	
	private void checkInput() {
		
		// most of base check input are already covered by framework annotation (required/optional parameter, etc.)
		wCreateOverpaymentSw = parmCreateSeperatePayment;
		wReinstateSASw = parmReinstateExcessCreditSA;
	}
	
	private void performProcessing() {
		
		wCreditAmount = inputCreditAmount;
		
		/*
		 * START - Added functionality to cater to the additional functionality
		 */
		ServiceAgreementType saTypeToUse = parmSaTypeOverpayment;
		Bool isPledgePayment = cmCheckPaymentTenderSource(inputPayment.getId());
		if (isPledgePayment.isTrue()) {
			saTypeToUse = parmSaTypePledgeOverpayment;
		}
		/*
		 * END - Added functionality to cater to the additional functionality
		 */
		
		/*
		 * Check if a non-cancelled and non-closed excess credit SA
		 * already exists.
		 */		
		if (wReinstateSASw.isTrue()) {

			getNonClosedSAs(saTypeToUse.fetchIdDivision().getId(),
					saTypeToUse.fetchIdSaType().trim());
			/*
			 * If SA is closed, reinstate the SA
			 */
			if(notNull(wTempSAID)
					&& notNull(wTempSAID.getEntity())) {
				if (wTempSAID.getEntity().getStatus().isClosed()) {

					if (areWarningsEnabled()) {
						Logger logger = LoggerFactory.getLogger(CmKeepOverpaymentAndPledgeOverpaymentsSeperateAlgComp_Impl.class);
						logger.info("REINSTATE SA: "+wTempSAID.getTrimmedValue());
					}

					reinstateSA(wTempSAID, Bool.TRUE);
					/*
					 * Call routine to move SA to stopped state.
					 */
					ServiceAgreement latestCreditSA = wTempSAID.getEntity();
					Date latestCreditSAEndDate = latestCreditSA.getEndDate();
					latestCreditSA.activateOrTerminate(latestCreditSAEndDate);
				}			
			}
		}
		else {
			getCreditSA(inputAccount.getId(),
					saTypeToUse.fetchIdDivision().getId(),
					saTypeToUse.fetchIdSaType().trim());		
		}
		/*
		 * If one exists, use this SA.
		 */
		if (wCreditSAFoundSw.isTrue()) {
			wSAID = wTempSAID;
		}
		else {
			/*
			 * If one does not exists, create one.
			 */
			ServiceAgreement newCreditSA = createCreditSA(saTypeToUse.getId());
			wSAID = newCreditSA.getId();						
		}
		/*
		 * Add the excess credit to the output total amount distributed
		 */
		outputTotalAmountDistributed = outputTotalAmountDistributed.add(wCreditAmount);
		/*
		 * Evaluate parameter to determine what to do with excess
		 * credit - create an entry in  SA collection or 
		 * create a separate payment. This is only done if over payment
		 * distribution is invoked by payment distribution, that is
		 * input pay id is populated.
		 */
		if (wCreateOverpaymentSw.isTrue()
				&& notNull(inputPayment)) {
			/*
			 * Check if the input payment has pay segments
			 */
			checkPaySegExists(inputPayment.getId());
			/*
			 * Create a new payment if input payment already
			 * has pay segments or if there is already an entry
			 * in the SA collection
			 */
			if (wPaySegFndSw.isTrue()
					|| inputPaymentSACount.intValue() > 0) {
				
				createNewPaymentForOverpayment(inputPayment);
				outputOverpaymentPayment = wOverpaymentPayID.getEntity();				
			}
			else {
				/*
				 * Create an entry in the SA collection, if SA collection
				 * is zero and input payment has no payment segments
				 */
				CustomerClassOverpaymentDistributionData ccOvrPayDistData = CustomerClassOverpaymentDistributionData.Factory.newInstance();
				ccOvrPayDistData.setCreditAmount(wCreditAmount);
				ccOvrPayDistData.setServiceAgreement(wSAID.getEntity());
				outputCollOfCcOverpaymentDistributionData.add(ccOvrPayDistData);
			}
		}
		else {
			CustomerClassOverpaymentDistributionData ccOvrPayDistData = CustomerClassOverpaymentDistributionData.Factory.newInstance();
			ccOvrPayDistData.setCreditAmount(wCreditAmount);
			ccOvrPayDistData.setServiceAgreement(wSAID.getEntity());
			outputCollOfCcOverpaymentDistributionData.add(ccOvrPayDistData);
			
		}
		
		wCreditAmount = new Money(BigDecimal.ZERO, inputAccount.getCurrency().getId());		
	}
	
	private void reinstateSA(ServiceAgreement_Id latestCreditSaID, Bool c1IgnoreWarningSw) {
		
		CmReinstateServiceAgreementRoutine reinstateSA = CmReinstateServiceAgreementRoutine.Factory.newInstance();
		reinstateSA.setIgnoreWarningSwitch(c1IgnoreWarningSw);
		reinstateSA.setServiceAgreementID(latestCreditSaID);
		reinstateSA.invoke();
	}
	
	private ServiceAgreement createCreditSA(ServiceAgreementType_Id saTypeID) {
		
		ServiceAgreementType saType = saTypeID.getEntity();
		ServiceAgreement returnValue = null;
		ServiceAgreementCreatorData saCreatorData = ServiceAgreementCreatorData.Factory.newInstance();
		ServiceAgreementCreator saCreator = ServiceAgreementCreator.Factory.newInstance();
		ServiceAgreement_DTO saDTO = new ServiceAgreement_DTO();
		
		saDTO.setAccountId(inputAccount.getId());
		saDTO.setServiceAgreementTypeId(saTypeID);
		saDTO.setStartDate(this.getProcessDateTime().getDate());
		saDTO.setCustomerRead(CustomerReadLookup.constants.NO);
		saDTO.setStatus(ServiceAgreementStatusLookup.constants.PENDING_START);
		saDTO.setAreEstimatesAllowed(saType.getAreEstimatesAllowed());
		saDTO.setStartReason(StartReasonLookup.constants.SYSTEM_GENERATED);
		saCreatorData.setServiceAgreementDTO(saDTO);
		saCreatorData.setShouldOverrideSAStatus(Bool.FALSE);
		returnValue = saCreator.addServiceAgreement(saDTO, saCreatorData);
		return returnValue;
	}
	
	private void createNewPaymentForOverpayment(Payment inputPay) {
	
		Money inputPaymentAmount = inputPay.getPaymentAmount();
		Money newPaymentAmount = inputPaymentAmount.subtract(wCreditAmount);
		/*
		 * Update payment amount
		 */
		startChanges();
		Payment_DTO inputPayDTO = inputPay.getDTO();
		inputPayDTO.setPaymentAmount(newPaymentAmount);
		inputPay.setDTO(inputPayDTO);
		saveChanges();
		/*
		 * Create new Payment for excess credit SA
		 */
		// MOVE CORR PPAYT TO INPUT-WRK OF PPAYA
		startChanges();
		Payment_DTO ppayt = inputPay.getDTO();
		Payment_DTO newPaymentDTO = new Payment_DTO();
		newPaymentDTO.setPaymentEventId(ppayt.getPaymentEventId());
		newPaymentDTO.setCancelReasonId(ppayt.getCancelReasonId());
		newPaymentDTO.setCurrencyId(ppayt.getCurrencyId());
		newPaymentDTO.setAccountId(ppayt.getAccountId());		
		newPaymentDTO.setNonCisName(ppayt.getNonCisName());
		newPaymentDTO.setReferenceNumber(ppayt.getReferenceNumber());
		newPaymentDTO.setNonCisComments(ppayt.getNonCisComments());
		newPaymentDTO.setMatchTypeId(ppayt.getMatchTypeId());
		newPaymentDTO.setMatchValue(ppayt.getMatchValue());
		newPaymentDTO.setIlmDate(ppayt.getIlmDate());
		newPaymentDTO.setIsEligibleForArchiving(ppayt.getIsEligibleForArchiving());
		newPaymentDTO.setPaymentStatus(PaymentStatusLookup.constants.FREEZABLE);
		newPaymentDTO.setPaymentAmount(wCreditAmount);
		Payment newPayment = newPaymentDTO.newEntity();
		saveChanges();
		/*
		 * Create new payment segment of excess credit SA
		 */
		startChanges();
		PaymentSegment_DTO paySegmentDTO = new PaymentSegment_DTO();
		paySegmentDTO.setPaymentId(newPayment.getId());
		paySegmentDTO.setServiceAgreementId(wSAID);
		paySegmentDTO.setPaySegmentAmount(wCreditAmount);
		paySegmentDTO.setCurrencyId(ppayt.getCurrencyId());
		paySegmentDTO.newEntity();		
		saveChanges();
		
		wOverpaymentPayID = newPayment.getId();
	}
	
	/*
	 * SQL Section
	 */
	private void getNonClosedSAs(CisDivision_Id cisDivID, String saType) {
		
		StringBuilder stringBuilder = new StringBuilder();
		
		stringBuilder.append("SELECT SA.SA_ID ");
		stringBuilder.append("FROM CI_SA SA ");
		stringBuilder.append("WHERE SA.ACCT_ID = :accountID ");
		stringBuilder.append("AND SA.CIS_DIVISION = :cisDivisionOverpayment ");
		stringBuilder.append("AND SA.SA_TYPE_CD = :saTypeOverpayment ");
		stringBuilder.append("AND SA.SA_STATUS_FLG != '70' ");
		stringBuilder.append("ORDER BY SA.END_DT DESC ");
				
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getNonClosedSAs=");
		prepState.bindId("accountID", inputAccount.getId());
		prepState.bindId("cisDivisionOverpayment", cisDivID);
		prepState.bindString("saTypeOverpayment", saType.trim(), "SA_TYPE_CD");
		prepState.setAutoclose(false);
		prepState.execute();
		
		if (prepState.list().size() > 0) {			
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			wCreditSAFoundSw = Bool.TRUE;
			wTempSAID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);					
		}
		else {
			wCreditSAFoundSw = Bool.FALSE;
		}
		
		prepState.close();
	}	
	
	private void getCreditSA(Account_Id acctID, CisDivision_Id cisDivID, String saType) {
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT SA_ID ");
		stringBuilder.append("FROM CI_SA ");
		stringBuilder.append("WHERE ACCT_ID = :acctID ");
		stringBuilder.append("AND CIS_DIVISION = :cisDivID ");
		stringBuilder.append("AND SA_TYPE_CD = :saTypeCd ");
		stringBuilder.append("AND SA_STATUS_FLG NOT IN ('60', '70') ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getCreditSA=");
		prepState.bindId("acctID", acctID);
		prepState.bindId("cisDivID", cisDivID);
		prepState.bindString("saTypeCd", saType.trim(), "SA_TYPE_CD");
		prepState.setAutoclose(false);
		prepState.execute();
		
		if (prepState.list().size() > 0) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			wTempSAID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
			wCreditSAFoundSw = Bool.TRUE;
		}
		else {
			wCreditSAFoundSw = Bool.FALSE;
		}
		prepState.close();		
	}
	
	private void checkPaySegExists(Payment_Id payID) {
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT 'X' ");
		stringBuilder.append("FROM CI_PAY_SEG ");
		stringBuilder.append("WHERE PAY_ID = :payID ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=checkPaySegExists=");
		prepState.bindId("payID", payID);
		prepState.setAutoclose(false);
		prepState.execute();
		if (prepState.list().size() > 0) {
			wPaySegFndSw = Bool.TRUE;
		}
		else {
			wPaySegFndSw = Bool.FALSE;
		}		
	}
	
	private Bool cmCheckPaymentTenderSource(Payment_Id payID) {

		Bool returnValue = Bool.FALSE;

		// transform collection of pledge tender source to one string
		String pledgeTenderSources = " ";
		Iterator<TenderSource_Id> iter = wCollOfPledgeTenderSourceIDs.iterator();
		while (iter.hasNext()) {
			TenderSource_Id tenderSourceID = iter.next();
			pledgeTenderSources = pledgeTenderSources.concat("'");
			pledgeTenderSources = pledgeTenderSources.concat(tenderSourceID.getTrimmedValue());
			pledgeTenderSources = pledgeTenderSources.concat("',");
		}
		// remove the extra comma at the end of the string
		pledgeTenderSources = pledgeTenderSources.substring(0, (pledgeTenderSources.length() - 1));

		// Check if the payment is for a pledge (checked via tender source)
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT 'X' "); 
		stringBuilder.append("FROM CI_PAY PAY, ");
		stringBuilder.append("      CI_PAY_EVENT PE, ");
		stringBuilder.append("      CI_PAY_TNDR PT, ");
		stringBuilder.append("      CI_TNDR_CTL TC ");
		stringBuilder.append("WHERE PAY.PAY_ID = :payID ");
		stringBuilder.append("AND PE.PAY_EVENT_ID = PAY.PAY_EVENT_ID ");
		stringBuilder.append("AND PT.PAY_EVENT_ID = PE.PAY_EVENT_ID ");
		stringBuilder.append("AND TC.TNDR_CTL_ID = PT.TNDR_CTL_ID ");
		stringBuilder.append("AND TC.TNDR_SOURCE_CD IN ( "+pledgeTenderSources.trim()+" ) ");

		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=cmCheckPaymentTenderSource=");
		prepState.bindId("payID", payID);
		prepState.setAutoclose(false);
		prepState.execute();

		if (prepState.list().size() > 0) {
			returnValue = Bool.TRUE;			
		}		
		prepState.close();		
		return returnValue;
	}	
}