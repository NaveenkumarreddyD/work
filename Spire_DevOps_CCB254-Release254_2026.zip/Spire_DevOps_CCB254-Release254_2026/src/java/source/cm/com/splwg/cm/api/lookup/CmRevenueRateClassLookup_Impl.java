/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Revenue Rate Class Lookup
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-04-22   JPunza  NI0034.1 Initial Version.
 *************************************************************************/

package com.splwg.cm.api.lookup;

/**
 * @author jpunzalan2
 *
 @LookupFieldname (value = XRRC_OPT_TYP_FLG)
 */
public class CmRevenueRateClassLookup_Impl 
        extends CmRevenueRateClassLookup_Gen {
}
