/* 
 *********************************************************************** 
 *                 Confidentiality Information: 
 * 
 * This module is the confidential and proprietary information of 
 * Oracle Corporation; it is not to be copied, reproduced, or 
 * transmitted in any form, by any means, in whole or in part, 
 * nor is it to be used for any purpose other than that for which 
 * it is expressly provided without the written permission of 
 * Oracle Corporation. 
 * 
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION:
 * 
 * Pledge Action Batch Process
 * 
 ********************************************************************** 
 * 
 * 
 * CHANGE HISTORY: 
 * 
 * Date:       by:       Reason:
 * YYYY-MM-DD  IN        Reason text.
 *
 * 2013-04-01  FMedin    Created. Initial Version. 
 * 2013-05-07  CVB       Removed validation of Pledge when action is New.
 * 2013-10-08  JPunza    Improve performance of the batch.
 * 2013-10-11  JPunza    Incorporate the Create Service Task logic.
 * 2013-10-22  JPunza    Log an error and create To Do if Account has no
 *                       Bill Cycle.  	
 * 2014-01-06  Ujesh     IM-044095. As requested by Rhonda Modified code to store SA's Payoffbalance 
 * 						 instead of Current balance in the Characteristic (Total SA Arrears)  
 * 2016-01-29  	MPang	 Updated for CCB v2.4 compilation.                      
 ************************************************************************ 
 */
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.datatypes.Time;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.AdjustmentStatusLookup;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.BillStatusLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.adjustmentType.AdjustmentType;
import com.splwg.ccb.domain.admin.adjustmentType.AdjustmentType_Id;
import com.splwg.ccb.domain.admin.budgetPlan.BudgetPlan;
import com.splwg.ccb.domain.admin.customerClass.CustomerClassControl_Id;
import com.splwg.ccb.domain.admin.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.Person;
import com.splwg.ccb.domain.customerinfo.premise.Premise;
import com.splwg.ccb.domain.customerinfo.premise.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementRecurringCharge;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTask;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTaskCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTaskCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTask_DTO;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTask_Id;*/

import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType_Id;
import com.splwg.ccb.domain.admin.budgetPlan.entity.BudgetPlan;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClassControl_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementRecurringCharge;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic_DTO;
import com.splwg.base.domain.serviceTask.ServiceTask_DTO;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.api.batch.CmProcessPledgeActionFileRecord;
import com.splwg.cm.api.lookup.CmArpDownPaymentLookup;
import com.splwg.cm.api.lookup.CmBpapCreditValuesLookup;
import com.splwg.cm.api.lookup.CmDiversionSaTypesLookup;
import com.splwg.cm.api.lookup.CmEligibleMajorPledgeFundingTypesLookup;
import com.splwg.cm.api.lookup.CmPaymentArrangementSaTypesLookup;
import com.splwg.cm.api.lookup.CmQuotePortalParametersLookup;
import com.splwg.cm.api.lookup.CmServiceTaskCharacteristicTypesLookup;
import com.splwg.cm.api.lookup.ExternalSystemTypeLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.cm.domain.customMessages.CustomMessagesMDC;

/**
 * Process Pledge Action File Batch
 * @author FFMEDINA
 *
 @BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = PLEDGE_SERVICE_TASK_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = businessObject, name = PLEDGE_BUSINESS_OBJECT, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = PLEDGE_BO_ACTIVE_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PLEDGE_BO_CANCELLED_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PLEDGE_BO_EXPIRED_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = QUOTE_SERVICE_TASK_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = businessObject, name = QUOTE_BUSINESS_OBJECT, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = QUOTE_BO_ACTIVE_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = QUOTE_BO_EXPIRED_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = ACCT_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = SA_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PLEDGE_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PLEDGE_AMOUNT_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PLEDGE_CONF_DATE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = FUNDING_TYPE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = AGENCY_ACCT_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = AGENCY_CODE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = WEB_TRANS_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CWR_LEVEL_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = TO_DO_TYPE, required = true, type = entity)})
 */

public class CmProcessPledgeActionFileBatch extends CmProcessPledgeActionFileBatch_Gen {

    /**
     * Retrieves the records
     */
    public JobWork getJobWork() {

        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit workUnit = new ThreadWorkUnit();
        workUnits.add(workUnit);

        return createJobWorkForThreadWorkUnitList(workUnits);
    }

    /**
     * Validates soft parameters
     */
    @Override
    public void validateSoftParameters(boolean isNewRun) {

        // Retrieve Soft Parameters
        String filePath = this.getParameters().getFILE_PATH();
        String fileName = this.getParameters().getFILE_NAME();
        BusinessObject pledgeBo = this.getParameters().getPLEDGE_BUSINESS_OBJECT();
        String pledgeBoActiveStatus = this.getParameters().getPLEDGE_BO_ACTIVE_STATUS();
        String pledgeBoCancelledStatus = this.getParameters().getPLEDGE_BO_CANCELLED_STATUS();
        String pledgeBoExpiredStatus = this.getParameters().getPLEDGE_BO_EXPIRED_STATUS();
        BusinessObject quoteBo = this.getParameters().getQUOTE_BUSINESS_OBJECT();
        String quoteBoActiveStatus = this.getParameters().getQUOTE_BO_ACTIVE_STATUS();
        String quoteBoExpiredStatus = this.getParameters().getQUOTE_BO_EXPIRED_STATUS();
        CharacteristicType accountIdCharType = this.getParameters().getACCT_ID_CHAR_TYPE();
        CharacteristicType saIdCharType = this.getParameters().getSA_ID_CHAR_TYPE();
        CharacteristicType pledgeIdCharType = this.getParameters().getPLEDGE_ID_CHAR_TYPE();
        CharacteristicType pledgeAmountCharType = this.getParameters().getPLEDGE_AMOUNT_CHAR_TYPE();
        CharacteristicType pledgeConfirmationDateCharType = this.getParameters().getPLEDGE_CONF_DATE_CHAR_TYPE();
        CharacteristicType fundingTypeCharType = this.getParameters().getFUNDING_TYPE_CHAR_TYPE();
        CharacteristicType agencyAccountIdCharType = this.getParameters().getAGENCY_ACCT_ID_CHAR_TYPE();
        CharacteristicType agencyCodeCharType = this.getParameters().getAGENCY_CODE_CHAR_TYPE();
        CharacteristicType webTransactionIdCharType = this.getParameters().getWEB_TRANS_ID_CHAR_TYPE();
        CharacteristicType cwrLevelCharType = this.getParameters().getCWR_LEVEL_CHAR_TYPE();

        // Check that filePath is a valid and existing directory.
        if (cmIsValidFilePath(filePath).isFalse()) {
            addError(CustomMessageRepositoryMDC.ni00263InvalidFilePath(filePath));
        }

        // Check that fileName is a valid filename.
        if (cmIsValidFileName(fileName).isFalse()) {
            addError(CustomMessageRepositoryMDC.ni00263InvalidFileName(fileName));
        }

        // Check that fileName exists in the filePath directory.
        if (cmIsFileExisting(filePath, fileName).isFalse()) {
            addError(CustomMessageRepositoryMDC.ni00263FileDoesNotExist(filePath + fileName));
        }

        // Check that the pledgeBusinessObjectActiveStatus, pledgeBusinessObjectCancelledStatus,
        // and pledgeBusinessObjectExpiredStatus are valid Business Object statuses for pledgeBusinessObject.
        cmValidateBoStatus(pledgeBo, pledgeBoActiveStatus);
        cmValidateBoStatus(pledgeBo, pledgeBoCancelledStatus);
        cmValidateBoStatus(pledgeBo, pledgeBoExpiredStatus);

        // Check that the quoteBusinessObjectActiveStatus and quoteBusinessObjectExpiredStatus are valid
        // Business Object statuses for quoteBusinessObject.
        cmValidateBoStatus(quoteBo, quoteBoActiveStatus);
        cmValidateBoStatus(quoteBo, quoteBoExpiredStatus);

        // Check the following Characteristic Type parameters if it is valid for the Service Task entity.
        // If not, raise error MSG15.
        cmValidateCharacteristicEntity(accountIdCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        cmValidateCharacteristicEntity(saIdCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        cmValidateCharacteristicEntity(pledgeIdCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        cmValidateCharacteristicEntity(pledgeAmountCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        cmValidateCharacteristicEntity(pledgeConfirmationDateCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        cmValidateCharacteristicEntity(fundingTypeCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        cmValidateCharacteristicEntity(agencyAccountIdCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        cmValidateCharacteristicEntity(agencyCodeCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        cmValidateCharacteristicEntity(webTransactionIdCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        cmValidateCharacteristicEntity(cwrLevelCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
    }

    /**
     * Validates Business Object Status
     * @param bo Business Object
     * @param boStatus Business Object Status
     */
    private void cmValidateBoStatus(BusinessObject bo, String boStatus) {
        BusinessObjectStatus_Id boStatusId = new BusinessObjectStatus_Id(bo.fetchLifecycleBusinessObject(), boStatus);

        if (isNull(boStatusId.getEntity())) {
            addError(CustomMessageRepositoryMDC.ni00263InvalidStatusForBo(boStatus.trim(), bo.getId().getTrimmedValue()));
        }
    }

    /**
     * Validates File Path
     * @param path File Path
     * @return True if valid, else False
     */
    private Bool cmIsValidFilePath(String path) {
        File filePath = new File(path);

        if (filePath.isDirectory()) {
            return Bool.TRUE;
        }
        return Bool.FALSE;
    }

    /**
     * Validates Characteristic Entity
     * @param charType Characteristic Type
     * @param charEntityLookup Characteristic Entity Lookup
     */
    private void cmValidateCharacteristicEntity(CharacteristicType charType, CharacteristicEntityLookup charEntityLookup) {

        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType,
                charEntityLookup);

        if (isNull(charEntityId.getEntity())) {
            addError(CustomMessageRepositoryMDC.ni00263InvalidCharTypeForEntity(charType.getId().getTrimmedValue(),
                    charEntityLookup.getLookupValue().fetchLanguageDescription().trim()));
        }
    }

    /**
     * Validates File Name
     * @param fileName File Name
     * @return True if valid, else False
     */
    public Bool cmIsValidFileName(String fileName)
    {
        File file = new File(fileName);

        try {
            file.getCanonicalPath();
            return Bool.TRUE;
        }
        catch (IOException e) {
            return Bool.FALSE;
        }
    }

    /**
     * Checks is file is existing
     * @param path File Path
     * @param fileName File Name
     * @return True if existing, else False
     */
    public Bool cmIsFileExisting(String path, String fileName)
    {
        File file = new File(path + fileName);

        if (file.exists()) {
            return Bool.TRUE;
        }
        return Bool.FALSE;
    }

    /**
     * Gets Thread Worker Class 
     */
    public Class<CmProcessPledgeActionFileBatchWorker> getThreadWorkerClass() {
        return CmProcessPledgeActionFileBatchWorker.class;
    }

    /**
     * Process Pledge Action File Batch Worker
     * @author ffmedina
     *
     */
    public static class CmProcessPledgeActionFileBatchWorker extends
    CmProcessPledgeActionFileBatchWorker_Gen {
        
        // CONSTANTS
        // CVB - 2013-05-07 - Start
        // private static final String PLEDGE = "Pledge";
        // CVB - 2013-05-07 - End
        private static final String QUOTE_SRC_AGENCY = "Agency";
        private static final String SELECTION_CWR = "CWR";
        private static final String SERVICE_AGREEMENT = "Service Agreement";
        private static final String ACCOUNT = "Account";
        private static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
        private static final String ACTION_NEW = "NEW";
        private static final String ACTION_CANCEL = "CANCEL";
        private static final String ACTION_EXPIRE = "EXPIRE";
        
        // JPunza - 2013-10-08 - Start
        private final int SESSION_FLUSH_FREQUENCY = 10;
        // JPunza - 2013-10-08 - End
                
        // BATCH SOFT PARAMETERS
        private String parmFilePath;
        private String parmFileName;
        private ServiceTaskType parmPledgeServiceTaskType;
        private BusinessObject parmPledgeBo;
        private String parmPledgeBoActiveStatus;
        private String parmPledgeBoCancelledStatus;
        private String parmPledgeBoExpiredStatus;
        private ServiceTaskType parmQuoteServiceTaskType;
        private BusinessObject parmQuoteBo;
        private String parmQuoteBoActiveStatus;
        private String parmQuoteBoExpiredStatus;
        private CharacteristicType parmAccountIdCharType;
        private CharacteristicType parmSaIdCharType;
        private CharacteristicType parmPledgeIdCharType;
        private CharacteristicType parmPledgeAmountCharType;
        private CharacteristicType parmPledgeConfirmationDateCharType;
        private CharacteristicType parmFundingTypeCharType;
        private CharacteristicType parmAgencyAccountIdCharType;
        private CharacteristicType parmAgencyCodeCharType;
        private CharacteristicType parmWebTransactionIdCharType;
        private CharacteristicType parmCwrLevelCharType;

        // CLASS VARIABLES
        private String inputFileCanonicalPath;
        private BufferedReader pledgeActionFile;
        private Bool skipRecord;
        private DateFormat yyyyMmDd = new DateFormat(DATE_FORMAT_YYYY_MM_DD);
        private String accountIdStr;
        private Account account;
        private String serviceAgreementIdStr;
        private ServiceAgreement serviceAgreement;
        private String pledgeIdStr;
        // CVB - 2013-05-07 - Start
        // private ServiceTask pledge;
        // CVB - 2013-05-07 - End
        private String pledgeAmountStr;
        private Money pledgeAmount;
        private String agencyAccountIdStr;
        private Account agencyAccount;
        private String confirmationDateStr;
        private Date confirmationDate;
        private String fundingType;
        private String webTransactionId;
        private String action;
        private Bool parseError;
        private List<String> majorFundingTypesList = new ArrayList<String>();
        private FeatureConfiguration paymentArrangementSaTypesFeatConfig;
        private String agencyCode;
        private int recordLineNum;
        
        // JPunza - 2013-10-11 - Start        
        // Constants
        private static final String SERVICE_TASK_TYPE = "Service Task Type";
        private static final String BUSINESS_OBJECT = "Business Object";
        private static final String STATUS = "Status";
        private static final String PREMISE = "Premise";
        private static final String SERVICE_TASK = "Service Task";
        private static final String DATE_FORMAT = "yyyy-MM-dd";
        private static final String CWR_SEASON_DATE_FORMAT = "MM/dd/yyyy";
        private static final String CWR_SEASON_END = "CWR Season End";
        private static final String STANDARD = "Standard";
        private static final String CCB = "CCB";
        private static final String NO = "No";
        private static final String PERCENT_12 = "12";
        private static final String PERCENT_50 = "50";
        private static final String PERCENT_80 = "80";

        // Input variables
        private ServiceTaskType serviceTaskType;
        private BusinessObject businessObject;
        private String status;
        private DateTime creationDateTime;
        private DateTime statusDateTime;
        private DateTime effectiveDateTime;
        private String selection;
        private String source;

        // Other variables
        private CharacteristicType serviceAgreementCharType;
        private CharacteristicType cisDivisionCharType;
        private CharacteristicType debtClassCharType;
        private CharacteristicType expirationDateCharType;
        private CharacteristicType cwrLevelCharType;
        private CharacteristicType totalSaArrearsCharType;
        private CharacteristicType totalDiversionCharType;
        private CharacteristicType monthlyBudgetCharType;
        private CharacteristicType standardTurnOnOrAvoidSeveranceAmountCharType;
        private CharacteristicType cwrDownPaymentCharType;
        private CharacteristicType cwrMonthlyPaymentArrangementCharType;
        private CharacteristicType bpap050MonthlyBudgetCharType;
        private CharacteristicType bpap5199MonthlyBudgetCharType;
        private CharacteristicType bpap100125MonthlyBudgetCharType;
        private CharacteristicType bpap126185MonthlyBudgetCharType;
        private CharacteristicType arp050DownPaymentCharType;
        private CharacteristicType arp5199DownPaymentCharType;
        private CharacteristicType arp100125DownPaymentCharType;
        private CharacteristicType arp126185DownPaymentCharType;    
        private CharacteristicType monthlyArp050PaymentArrangement12MonthCharType;
        private CharacteristicType monthlyArp5199PaymentArrangement12MonthCharType;
        private CharacteristicType monthlyArp100125PaymentArrangement12MonthCharType;
        private CharacteristicType monthlyArp126185PaymentArrangement12MonthCharType;
        private CharacteristicType monthlyArp050PaymentArrangement24MonthCharType;
        private CharacteristicType monthlyArp5199PaymentArrangement24MonthCharType;
        private CharacteristicType monthlyArp100125PaymentArrangement24MonthCharType;
        private CharacteristicType monthlyArp126185PaymentArrangement24MonthCharType;
        private CharacteristicType selectionCharType;
        private CharacteristicType quoteSourceCharType;
        private CharacteristicType customDownPaymentCharType;
        private CharacteristicType averageBillAmountCharType;

        private BigDecimal bpap050CreditValue;
        private BigDecimal bpap5199CreditValue;
        private BigDecimal bpap100125CreditValue;
        private BigDecimal bpap126185CreditValue;

        private BigDecimal arp050DownPaymentValue;
        private BigDecimal arp5199DownPaymentValue;
        private BigDecimal arp100125DownPaymentValue;
        private BigDecimal arp126185DownPaymentValue;

        private FeatureConfiguration diversionSaTypesFeatConfig; 
        private CharacteristicType recalculatedCharType;
        private CharacteristicType cwrPremiseCharType;
        private String recalculatedCharValue;
        private CharacteristicType brokenCharType;
        private String brokenCharValue;
        private CharacteristicType cwrCharType;
        private String cwrCharValue;
        private AdjustmentType transferAdjustmentType;
        private String cwrSeasonEnd;
        private String charPremiseIdString;
        private int roundUpUnit;
        // JPunza - 2013-10-11 - End
        
        /**
         * Creates execution strategy
         */
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new SingleTransactionStrategy(this);
        }

        /**
         * Initializes Thread Work
         */
        @Override
        public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {

            // Retrieve batch parameters
            cmRetrieveBatchParameters();

            // Open the file
            try
            {
                File file = new File(parmFilePath, parmFileName);
                inputFileCanonicalPath = file.getCanonicalPath();

                pledgeActionFile = new BufferedReader(new FileReader(file));
            }
            catch(IOException e)
            {
                throw new RunAbortedException(CustomMessageRepositoryMDC.ni00263ErrorOpeningFile(inputFileCanonicalPath));
            }
            
            // JPunza - 2013-10-11 - Start
            // Retrieve and Validate Input Parameters
            retrieveAndValidateInputParameters();

            // Retrieve and Validate Other Parameters
            retrieveAndValidateOtherParameters();
            // JPunza - 2013-10-11 - End
        }

        /**
         * Retrieves Batch Parameters
         */
        private void cmRetrieveBatchParameters() {

            parmFilePath = this.getParameters().getFILE_PATH();
            parmFileName = this.getParameters().getFILE_NAME();
            parmPledgeServiceTaskType = this.getParameters().getPLEDGE_SERVICE_TASK_TYPE();
            parmPledgeBo = this.getParameters().getPLEDGE_BUSINESS_OBJECT();
            parmPledgeBoActiveStatus = this.getParameters().getPLEDGE_BO_ACTIVE_STATUS();
            parmPledgeBoCancelledStatus = this.getParameters().getPLEDGE_BO_CANCELLED_STATUS();
            parmPledgeBoExpiredStatus = this.getParameters().getPLEDGE_BO_EXPIRED_STATUS();
            parmQuoteServiceTaskType = this.getParameters().getQUOTE_SERVICE_TASK_TYPE();
            parmQuoteBo = this.getParameters().getQUOTE_BUSINESS_OBJECT();
            parmQuoteBoActiveStatus = this.getParameters().getQUOTE_BO_ACTIVE_STATUS();
            parmQuoteBoExpiredStatus = this.getParameters().getQUOTE_BO_EXPIRED_STATUS();
            parmAccountIdCharType = this.getParameters().getACCT_ID_CHAR_TYPE();
            parmSaIdCharType = this.getParameters().getSA_ID_CHAR_TYPE();
            parmPledgeIdCharType = this.getParameters().getPLEDGE_ID_CHAR_TYPE();
            parmPledgeAmountCharType = this.getParameters().getPLEDGE_AMOUNT_CHAR_TYPE();
            parmPledgeConfirmationDateCharType = this.getParameters().getPLEDGE_CONF_DATE_CHAR_TYPE();
            parmFundingTypeCharType = this.getParameters().getFUNDING_TYPE_CHAR_TYPE();
            parmAgencyAccountIdCharType = this.getParameters().getAGENCY_ACCT_ID_CHAR_TYPE();
            parmAgencyCodeCharType = this.getParameters().getAGENCY_CODE_CHAR_TYPE();
            parmWebTransactionIdCharType = this.getParameters().getWEB_TRANS_ID_CHAR_TYPE();
            parmCwrLevelCharType = this.getParameters().getCWR_LEVEL_CHAR_TYPE();
        }
        /**
         * Executes rprocessing for each record
         */
        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit) throws ThreadAbortedException,
        RunAbortedException {

            // Initialize variables
            WorkUnitResult workUnitResult = null;
            int numOfRowsError = 0;
            int numOfRowsNoError = 0;
            recordLineNum = 0;
            ServiceTask serviceTask = null;
            Bool hasRecord = cmReadFile();
            
            // JPunza - 2013-10-08 - Start
            FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
            // JPunza - 2013-10-08 - End
            
            // If there are no records, exit program
            if (hasRecord.isFalse()) {
                workUnitResult = new WorkUnitResult(true); 
                workUnitResult.setUnitsInError(numOfRowsError);
                workUnitResult.setUnitsProcessed(numOfRowsNoError + numOfRowsError);
                return workUnitResult;
            }

            // Retrieve the Major Funding Types from the Eligible Major Pledge Funding Type Feature Configuration
            cmRetrieveMajorFundingTypes();

            // Retrieve the Payment Arrangement SA Type feature configuration 
            paymentArrangementSaTypesFeatConfig = 
                cmRetrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_PAYMENT_ARRANGEMENT_SA_TYPES);

            while (hasRecord.isTrue()) {

                if (skipRecord.isTrue()) {
                    numOfRowsError = numOfRowsError + 1;
                    hasRecord = cmReadFile();
                    continue;
                }

                // If action is NEW
                if (action.equals(ACTION_NEW)) {
                    Query serviceTaskQuery = cmRetrieveServiceTaskUsingPledgeId();

                    if (!serviceTaskQuery.list().isEmpty()) {
                        // CVB - 2013-05-07 - Start
                        // logError(CustomMessageRepositoryMDC.ni00263PledgeRecordAlreadyExists(pledge.getId().getTrimmedValue()));
                        logError(CustomMessageRepositoryMDC.ni00263PledgeRecordAlreadyExists(pledgeIdStr));
                        // CVB - 2013-05-07 - End

                        numOfRowsError = numOfRowsError + 1;
                        hasRecord = cmReadFile();
                        continue;
                    }
                    else {
                        ServiceTask_DTO newServiceTaskDTO = new ServiceTask_DTO();

                        // Set Service Task Type
                        newServiceTaskDTO.setServiceTaskTypeId(parmPledgeServiceTaskType.getId());
                        // Set Business Object
                        newServiceTaskDTO.setBusinessObjectId(parmPledgeBo.getId());
                        // Set Creation Date Time
                        newServiceTaskDTO.setCreationDateTime(this.getProcessDateTime());
                        // Set Confirmation Date Time
                        Time time = new Time(1, 1, 1);
                        DateTime confirmationDateTime = new DateTime(confirmationDate, time);
                        // Set Effective Date Time
                        newServiceTaskDTO.setEffectiveDateTime(confirmationDateTime);
                        // Set Business Object Status
                        newServiceTaskDTO.setStatus(parmPledgeBoActiveStatus.trim());
                        // Set Status Update Date Time
                        newServiceTaskDTO.setStatusDateTime(this.getProcessDateTime());
                        serviceTask = newServiceTaskDTO.newEntity();

                        // Add a new Service Agreement ID characteristic
                        cmAddServiceTaskCharacteristic(serviceTask, parmSaIdCharType, serviceAgreement.getId().getTrimmedValue(),
                                BigInteger.valueOf(10));

                        // Add a new Account ID characteristic
                        cmAddServiceTaskCharacteristic(serviceTask, parmAccountIdCharType, account.getId().getTrimmedValue(),
                                BigInteger.valueOf(10));

                        // Add a new Pledge ID characteristic
                        // CVB - 2013-05-07 - Start
                        // cmAddServiceTaskCharacteristic(serviceTask, parmPledgeIdCharType, pledge.getId().getTrimmedValue(),
                        //		BigInteger.valueOf(10));
                        cmAddServiceTaskCharacteristic(serviceTask, parmPledgeIdCharType, pledgeIdStr,
                                BigInteger.valueOf(10));
                        // CVB - 2013-05-07 - End

                        // Add a new Pledge Amount characteristic
                        cmAddServiceTaskCharacteristic(serviceTask, parmPledgeAmountCharType, pledgeAmount.getAmount().toString(),
                                BigInteger.valueOf(10));

                        // Add a new Pledge Confirmation Date characteristic
                        cmAddServiceTaskCharacteristic(serviceTask, parmPledgeConfirmationDateCharType, confirmationDate.toString(),
                                BigInteger.valueOf(10));

                        // Add a new Funding Type characteristic
                        cmAddServiceTaskCharacteristic(serviceTask, parmFundingTypeCharType, fundingType.trim(),
                                BigInteger.valueOf(10));

                        // Add a new Agency Account ID characteristic
                        cmAddServiceTaskCharacteristic(serviceTask, parmAgencyAccountIdCharType, agencyAccount.getId().getTrimmedValue(),
                                BigInteger.valueOf(10));

                        // Add a new Agency Code characteristic
                        agencyCode = cmRetrieveAgencyCode(parmAgencyCodeCharType, agencyAccount);
                        cmAddServiceTaskCharacteristic(serviceTask, parmAgencyCodeCharType, agencyCode, BigInteger.valueOf(10));

                        // Add a new Website Transaction ID characteristic
                        cmAddServiceTaskCharacteristic(serviceTask, parmWebTransactionIdCharType, webTransactionId.trim(),
                                BigInteger.valueOf(10));

                        // If fundingType is in majorFundingTypesList
                        if (majorFundingTypesList.contains(fundingType.trim())) {

                            // Retrieve all active Quote Service Tasks 
                            Query activeQuoteTaskQuery = cmRetrieveActiveQuoteServiceTask();
                            QueryIterator activeQuoteTaskQueryItr = activeQuoteTaskQuery.iterate();
                            ServiceTask_Id quoteServiceTaskId;
                            ServiceTask quoteServiceTask = null;
                            ServiceTask_DTO quoteServiceTaskDTO;

                            while (activeQuoteTaskQueryItr.hasNext()) {
                                quoteServiceTaskId = (ServiceTask_Id) activeQuoteTaskQueryItr.next();
                                quoteServiceTask = quoteServiceTaskId.getEntity();
                                quoteServiceTaskDTO = quoteServiceTask.getDTO();

                                quoteServiceTaskDTO.setStatus(parmQuoteBoExpiredStatus.trim());
                                quoteServiceTaskDTO.setStatusDateTime(this.getProcessDateTime());
                                quoteServiceTask.setDTO(quoteServiceTaskDTO);
                            }
                            // JPunza - 2013-10-08 - Start
                            activeQuoteTaskQueryItr.close();
                            // JPunza - 2013-10-08 - End

                            // Create a new Quote Service Task
                            // JPunza - 2013-10-11 - Start
                            //try {
                                
                                //CmCreateServiceTask cmCreateServiceTask = CmCreateServiceTask_Impl.class.newInstance();
                                //
                                //cmCreateServiceTask.setServiceTaskType(parmQuoteServiceTaskType);
                                //cmCreateServiceTask.setBusinessObject(parmQuoteBo);
                                //cmCreateServiceTask.setStatus(parmQuoteBoActiveStatus);
                                //cmCreateServiceTask.setCreationDateTime(this.getProcessDateTime());
                                //cmCreateServiceTask.setStatusDateTime(this.getProcessDateTime());
                                //cmCreateServiceTask.setEffectiveDateTime(this.getProcessDateTime());
                                //cmCreateServiceTask.setServiceAgreement(serviceAgreement);
                                //cmCreateServiceTask.setSelection(SELECTION_CWR);
                                //cmCreateServiceTask.setSource(QUOTE_SRC_AGENCY);
                                //
                                //ServiceTask newQuoteServiceTask = cmCreateServiceTask.createServiceTask();
                                ServiceTask_DTO serviceTaskDto = createDTO(ServiceTask.class);
                                serviceTaskDto.setServiceTaskTypeId(serviceTaskType.getId());
                                serviceTaskDto.setBusinessObjectId(businessObject.getId());
                                serviceTaskDto.setStatus(status);
                                serviceTaskDto.setCreationDateTime(creationDateTime);
                                serviceTaskDto.setStatusDateTime(statusDateTime);
    
                                if (isNull(effectiveDateTime)) {
                                    serviceTaskDto.setEffectiveDateTime(effectiveDateTime);
                                }
                                
                                ServiceTask newQuoteServiceTask = serviceTaskDto.newEntity();

                                // Create Service Task Characteristics
                                createServiceTaskCharacteristics(newQuoteServiceTask);                                
                                // JPunza - 2013-10-11 - End
                                                                
                                Query activePaymentArrangmentSasQuery = cmRetrieveActivePaymentArrangementSas();

                                if (notNull(activePaymentArrangmentSasQuery.firstRow())) {
                                    ServiceAgreement_Id activePaymentArrangementSaId = (ServiceAgreement_Id) activePaymentArrangmentSasQuery.firstRow();
                                    ServiceAgreement activePaymentArrangementSa = activePaymentArrangementSaId.getEntity();

                                    if (notNull(activePaymentArrangementSa)) {
                                        Query cwrLevelOfPreviousQuoteQuery = cmRetrieveCwrLevelOfPreviousQuote();
                                        QueryResultRow row = (QueryResultRow) cwrLevelOfPreviousQuoteQuery.firstRow();
                                        String cwrLevel = "";

                                        if (parmCwrLevelCharType.getCharacteristicType().isAdhocValue()
                                                || parmCwrLevelCharType.getCharacteristicType().isFileLocationValue()) {
                                            cwrLevel = row.getString("serviceTaskAdhocCharValue");
                                        }
                                        else if (parmCwrLevelCharType.getCharacteristicType().isForeignKeyValue()) {
                                            cwrLevel = row.getString("serviceTaskForeignKeyCharValue");
                                        }
                                        else if (parmCwrLevelCharType.getCharacteristicType().isPredefinedValue())
                                        {
                                            cwrLevel = row.getString("serviceTaskPreDefinedCharValue");
                                        }
                                        cmUpdateServiceTaskCharacteristic(newQuoteServiceTask, parmCwrLevelCharType, cwrLevel);
                                    }
                                }
                            // JPunza - 2013-10-11 - Start                            
                            //} catch (InstantiationException e) {
                            //    e.printStackTrace();
                            //} catch (IllegalAccessException e) {
                            //    e.printStackTrace();
                            //}                            
                            // JPunza - 2013-10-11 - End
                        }
                        numOfRowsNoError = numOfRowsNoError + 1;
                    }
                }

                // If action is CANCEL or EXPIRE
                if (action.equals(ACTION_CANCEL) || action.equals(ACTION_EXPIRE)) {
                    Query serviceTaskQuery = cmRetrieveServiceTaskUsingPledgeId();

                    if (serviceTaskQuery.list().isEmpty()) {
                        // CVB - 2013-05-07 - Start
                        // logError(CustomMessageRepositoryMDC.ni00263NoRecordsFoundForPledge(pledge.getId().getTrimmedValue()));
                        logError(CustomMessageRepositoryMDC.ni00263NoRecordsFoundForPledge(pledgeIdStr));
                        // CVB - 2013-05-07 - End
                        numOfRowsError = numOfRowsError + 1;
                        hasRecord = cmReadFile();
                        continue;
                    }
                    else {
                        // Update the Service Task retrieved
                        ServiceTask_Id serviceTaskId = (ServiceTask_Id) serviceTaskQuery.firstRow();
                        serviceTask = serviceTaskId.getEntity();
                        ServiceTask_DTO serviceTaskDTO = serviceTaskId.getEntity().getDTO();

                        if (action.equals(ACTION_CANCEL)) {
                            serviceTaskDTO.setStatus(parmPledgeBoCancelledStatus.trim());
                        }
                        else if (action.equals(ACTION_EXPIRE)) {
                            serviceTaskDTO.setStatus(parmPledgeBoExpiredStatus.trim());
                        }
                        // Set Confirmation Date Time
                        Time time = new Time(0, 0, 0);
                        DateTime confirmationDateTime = new DateTime(confirmationDate, time);
                        // Set Effective Date Time
                        serviceTaskDTO.setEffectiveDateTime(confirmationDateTime);
                        // Set Status Update Date Time
                        serviceTaskDTO.setStatusDateTime(this.getProcessDateTime());
                        serviceTask.setDTO(serviceTaskDTO);

                        // Get the maximum sequence number of the of the Service Task's Website Transaction ID characteristics
                        Query maxSeqNbrQuery = cmRetrieveMaximumSequenceNumber(serviceTask);
                        BigInteger seqNbr = (BigInteger) maxSeqNbrQuery.firstRow();
                        seqNbr = seqNbr.add(BigInteger.TEN);

                        // Add a new Website Transaction ID characteristic
                        cmAddServiceTaskCharacteristic(serviceTask, parmWebTransactionIdCharType, webTransactionId.trim(), seqNbr);
                        numOfRowsNoError = numOfRowsNoError + 1;
                    }
                }
                
                // JPunza - 2013-10-08 - Start
                if(numOfRowsNoError + numOfRowsError % SESSION_FLUSH_FREQUENCY == 0) {
                	//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
                    //session.flush();
                    //session.clear();
                	session.flush(session.toString().trim());
                	session.clear(session.toString().trim());
                    //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
                }  
                // JPunza - 2013-10-08 - End
                
                // Read the next line in the file
                hasRecord = cmReadFile();

            }
            
            workUnitResult = new WorkUnitResult(true);
            workUnitResult.setUnitsInError(numOfRowsError);
            workUnitResult.setUnitsProcessed(numOfRowsNoError + numOfRowsError);
            return workUnitResult;
        }

        /**
         * Read input file
         * @return True if has record, otherwise False
         */
        private Bool cmReadFile() {

            Bool hasRecord = Bool.FALSE;
            String recordLine = null;

            try {
                recordLine = pledgeActionFile.readLine();

            } catch (IOException e) {
                e.printStackTrace();
                addError(CustomMessageRepositoryMDC.ni00263ErrorReadingFile(inputFileCanonicalPath));
            }

            if (!isBlankOrNull(recordLine)) {

                hasRecord = Bool.TRUE;
                recordLineNum = recordLineNum + 1;
                cmRetrieveFields(recordLine);
                cmValidateFields();
            }

            return hasRecord;
        }

        /**
         * Validates Fields from the input file
         */
        private void cmValidateFields() {
            skipRecord = Bool.FALSE;

            if (parseError.isTrue()) {
                logError(CustomMessageRepositoryMDC.ni00263errorParsingFile(String.valueOf(recordLineNum)));
                skipRecord = Bool.TRUE;
                return;
            }
            else {
                // Check that the Account ID retrieved is a valid Account ID. If not, log error MSG4 and set skipRecord to true.
                // Exit method.
                Account_Id acctId = new Account_Id(accountIdStr);
                account = acctId.getEntity();
                if (isNull(account)) {
                    logError(CustomMessageRepositoryMDC.ni00263InvalidId(acctId.getTrimmedValue(), ACCOUNT));
                    skipRecord = Bool.TRUE;
                    return;
                }

                // Check that the SA ID retrieved is a valid Service Agreement ID. If not, log error MSG4 and set 
                // skipRecord to true. Exit method.
                ServiceAgreement_Id saId = new ServiceAgreement_Id(serviceAgreementIdStr);
                serviceAgreement = saId.getEntity();
                if (isNull(serviceAgreement)) {
                    logError(CustomMessageRepositoryMDC.ni00263InvalidId(saId.getTrimmedValue(), SERVICE_AGREEMENT));
                    skipRecord = Bool.TRUE;
                    return;
                }
                
                // JPunza - 2013-10-11 - Start
                // Account Bill Cycle is required
                if (isNull(serviceAgreement.getAccount().fetchBillCycle())) {
                    // JPunza - 2013-10-22 - Start
                    //addError(CustomMessageRepositoryMDC.np0055BillCycleMissing(serviceAgreement.getAccount().getId().getTrimmedValue()));
                    String accountStr = serviceAgreement.getAccount().getId().getTrimmedValue();
                    logError(CustomMessageRepositoryMDC.np0055BillCycleMissing(accountStr));
                    createToDo(accountStr);
                    skipRecord = Bool.TRUE;
                    return;
                    // JPunza - 2013-10-22 - End
                }
                // JPunza - 2013-10-11 - End

                /*
                 * CVB - 2013-05-07 - Start
                 * 
				// Check that the Pledge ID retrieved is a valid Service Task ID. If not, log error MSG4 and set 
				// skipRecord to true. Exit method.
				ServiceTask_Id pledgeId = new ServiceTask_Id(pledgeIdStr);
				pledge = pledgeId.getEntity();
				if (isNull(pledge)) {
					logError(CustomMessageRepositoryMDC.ni00263InvalidId(pledgeId.getTrimmedValue(), PLEDGE));
					skipRecord = Bool.TRUE;
					return;
				}
                // CVB - 2013-05-07 - End
                 */

                // Check that the Pledge Amount retrieved is a valid amount. If not, log error MSG5 and set skipRecord to true.
                // Exit method.
                try {

                    BigDecimal pledgeAmountBd = new BigDecimal(pledgeAmountStr);
                    pledgeAmount = new Money(pledgeAmountBd, serviceAgreement.getCurrencyId());

                }
                catch (NumberFormatException e) {
                    logError(CustomMessageRepositoryMDC.ni00263InvalidAmount(pledgeAmountStr));
                    skipRecord = Bool.TRUE;
                    return;
                }

                // Check that the Agency Account ID retrieved is a valid Account ID. If not, log error MSG4 and set skipRecord
                // to true. Exit method.
                Account_Id agencyAcctId = new Account_Id(agencyAccountIdStr);
                agencyAccount = agencyAcctId.getEntity();
                if (isNull(agencyAccount)) {
                    logError(CustomMessageRepositoryMDC.ni00263InvalidId(agencyAcctId.getTrimmedValue(), ACCOUNT));
                    skipRecord = Bool.TRUE;
                    return;
                }

                // Check that the Agency Account Id has an Agency Code Characteristic Type, if not, log error MSG
                // and set skipRecord to true. Exit method
                agencyCode = cmRetrieveAgencyCode(parmAgencyCodeCharType, agencyAccount);
                AccountCharacteristic acctChar = agencyAccount.getEffectiveCharacteristic(parmAgencyCodeCharType);

                if (isNull(acctChar)) {
                    logError(CustomMessageRepositoryMDC.ni00263AgencyAccountHasNoAgencyCodeCharType(agencyAcctId.getTrimmedValue(),
                            parmAgencyCodeCharType.fetchLanguageDescription().trim(), parmAgencyCodeCharType.getId().getTrimmedValue()));
                    skipRecord = Bool.TRUE;
                    return;
                }

                // Check that the Confirmation Date is a valid date. If not, log error MSG6 and set skipRecord to true.
                // Exit method.
                try {

                    confirmationDate = Date.fromString(confirmationDateStr, yyyyMmDd);

                } catch (DateFormatParseException e) {
                    e.printStackTrace();
                    logError(CustomMessageRepositoryMDC.ni00263InvalidDate(confirmationDateStr));
                    skipRecord = Bool.TRUE;
                    return;
                }

                // Check that Action is equal to "NEW", or "CANCEL", or "EXPIRE".
                // If not, log error MSG7 and set skipRecord to true. Exit method .
                if (!action.equals(ACTION_NEW) && !action.equals(ACTION_CANCEL) && !action.equals(ACTION_EXPIRE)) {
                    logError(CustomMessageRepositoryMDC.ni00263InvalidAction(action));
                    skipRecord = Bool.TRUE;
                    return;
                }
            }
        }

        /**
         * Retrieves Fields from the input file
         * @param record Record Line
         */
        private void cmRetrieveFields(String record) {
            CmProcessPledgeActionFileRecord fileRecord = new CmProcessPledgeActionFileRecord(record);

            accountIdStr = fileRecord.getAccountId();
            serviceAgreementIdStr = fileRecord.getServiceAgreementId();
            pledgeIdStr = fileRecord.getPledgeId();
            pledgeAmountStr = fileRecord.getPledgeAmount();
            agencyAccountIdStr = fileRecord.getAgencyAccountId();
            fundingType = fileRecord.getFundingType();
            confirmationDateStr = fileRecord.getConfirmationDate();
            webTransactionId = fileRecord.getWebTransactionId();
            action = fileRecord.getAction();
            parseError = fileRecord.getParseError();
        }


        /**
         * Adds Service Task Characteristic
         * @param serviceTask Service Task
         * @param charType Characteristic Type
         * @param charValue Characteristic Value
         * @param seqNbr Sequence Number
         */
        private void cmAddServiceTaskCharacteristic(ServiceTask serviceTask, CharacteristicType charType,
                String charValue, BigInteger seqNbr) {

            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

            ServiceTaskCharacteristic_DTO serviceTaskCharacteristicDto = createDTO(ServiceTaskCharacteristic.class);
            if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
                serviceTaskCharacteristicDto.setAdhocCharacteristicValue(charValue.trim());
            } 
            else if (charTypeLookup.isPredefinedValue()) {
                serviceTaskCharacteristicDto.setCharacteristicValue(charValue.trim());
            }
            else if (charTypeLookup.isForeignKeyValue()) {
                serviceTaskCharacteristicDto.setCharacteristicValueForeignKey1(charValue.trim());
            }

            serviceTask.getCharacteristics().add(serviceTaskCharacteristicDto, charType.getId(), seqNbr);

        }

        /**
         * Adds Service Task Characteristic
         * @param serviceTask Service Task
         * @param charType Characteristic Type
         * @param charValue Characteristic Value
         */
        private void cmUpdateServiceTaskCharacteristic(ServiceTask serviceTask, CharacteristicType charType,
                String charValue) {

            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation  
            //ListFilter filter = serviceTask.getCharacteristics().createFilter("WHERE this.id.characteristicType = :characteristicType");
            ListFilter filter = serviceTask.getCharacteristics().createFilter(
            		"WHERE this.id.characteristicType = :characteristicType", getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation  
            filter.bindEntity("characteristicType", charType);

            ServiceTaskCharacteristic serviceTaskChar = (ServiceTaskCharacteristic) filter.firstRow();
            ServiceTaskCharacteristic_DTO serviceTaskCharacteristicDto = serviceTaskChar.getDTO();

            if (notNull(serviceTaskChar)) {

                if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
                    serviceTaskCharacteristicDto.setAdhocCharacteristicValue(charValue.trim());
                } 
                else if (charTypeLookup.isPredefinedValue()) {
                    serviceTaskCharacteristicDto.setCharacteristicValue(charValue.trim());
                }
                else if (charTypeLookup.isForeignKeyValue()) {
                    serviceTaskCharacteristicDto.setCharacteristicValueForeignKey1(charValue.trim());
                }
                serviceTaskChar.setDTO(serviceTaskCharacteristicDto);
            }
        }

        /**
         * Retrieves Major Funding Types
         */
        private void cmRetrieveMajorFundingTypes() {
            // Retrieve the Eligible Major Pledge Funding Type feature configuration
            FeatureConfiguration eligibleMajorPledgeFundingTypeFeatConfig = 
                cmRetrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_ELIGIBLE_MAJOR_PLEDGE_FUNDING_TYPES);

            // Retrieve the Funding Types from the Feature Configuration
            LookupValue lookupValue = CmEligibleMajorPledgeFundingTypesLookup.constants.CM_ELIGIBLE_MAJOR_PLEDGE_FUNDING_TYPE.getLookupValue();
            Query query = cmRetrieveFeatureConfigurationOptionValue(eligibleMajorPledgeFundingTypeFeatConfig, lookupValue);

            QueryIterator queryItr = query.iterate();
            String fundingTypeOptVal;
            majorFundingTypesList = new ArrayList<String>();

            while (queryItr.hasNext()) {
                fundingTypeOptVal = (String) queryItr.next();
                majorFundingTypesList.add(fundingTypeOptVal);
            }
            // JPunza - 2013-10-08 - Start
            queryItr.close();
            // JPunza - 2013-10-08 - End
        }
        /**
         * Finalized thread work
         */
        @Override
        public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {

            // Close the file
            try
            {
                pledgeActionFile.close();
            }
            catch(IOException e)
            {
                throw new RunAbortedException(CustomMessageRepositoryMDC.ni00263ErrorClosingFile(inputFileCanonicalPath));
            }
        }

        /**
         * Retrieves Feature Configuration
         * @param featureType External System Feature Type
         * @return Feature Configuration
         */
        private FeatureConfiguration cmRetrieveFeatureConfiguration(ExternalSystemTypeLookup featureType) {
            FeatureConfiguration featureConfiguration = null;

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM FeatureConfiguration FEATCONFIG ");
            stringBuilder.append(" WHERE FEATCONFIG.featureType = :extSysTypeFlag ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            query.bindLookup("extSysTypeFlag", featureType);

            if (query.list().isEmpty()) {
                addError(CustomMessageRepositoryMDC.ni00263NoFeatConfigRetrieved(featureType.getLookupValue().
                        fetchLanguageDescription()));
            }
            else {
                featureConfiguration = (FeatureConfiguration) query.firstRow();
            }

            return featureConfiguration;
        }

        /**
         * Retrieves Feature Configuration Option Value
         * @param featureConfiguration Feature Configuration
         * @param lookupValue
         * @return Feature Configuration Option value query
         */
        private Query cmRetrieveFeatureConfigurationOptionValue(FeatureConfiguration featureConfiguration, LookupValue lookupValue) {

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM FeatureConfigurationOption FEATCONFIGOPTION ");
            stringBuilder.append(" WHERE FEATCONFIGOPTION.id.workforceManagementSystem = :featureConfiguration ");
            stringBuilder.append(" 	AND FEATCONFIGOPTION.id.optionType = :optionType ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            query.bindEntity("featureConfiguration", featureConfiguration);
            query.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType,
                    lookupValue.fetchIdFieldValue().trim());	
            query.addResult("value", "FEATCONFIGOPTION.value");

            if (query.list().isEmpty()) {
                addError(CustomMessageRepositoryMDC.ni00263ni00263NoFeatConfigOptionValueRetrieved(featureConfiguration.getId().getTrimmedValue(),
                        lookupValue.fetchLanguageDescription()));
            }
            return query;

        }

        /**
         * Retrieves Active Quote Service Task query
         * @return query
         */
        private Query cmRetrieveActiveQuoteServiceTask() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM ServiceTask SVCTASK, ServiceTaskCharacteristic SVCTASKCHAR ");
            stringBuilder.append(" WHERE SVCTASK.serviceTaskType = :serviceTaskType ");
            stringBuilder.append(" 	AND SVCTASK.businessObject = :businessObject ");
            stringBuilder.append(" 	AND SVCTASK.status = :activeBusinessObjectStatus ");
            stringBuilder.append(" 	AND SVCTASK.id = SVCTASKCHAR.id.serviceTask.id ");
            stringBuilder.append(" 	AND SVCTASKCHAR.id.characteristicType = :saIdCharacteristicType ");
            stringBuilder.append(" 	AND (SVCTASKCHAR.adhocCharacteristicValue = :saId ");
            stringBuilder.append("  	OR SVCTASKCHAR.characteristicValueForeignKey1 = :saId ");
            stringBuilder.append("  	OR SVCTASKCHAR.characteristicValue = :saId) ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            
            query.bindEntity("serviceTaskType", parmQuoteServiceTaskType);
            query.bindEntity("businessObject", parmQuoteBo);
            query.bindStringProperty("activeBusinessObjectStatus", ServiceTask.properties.status, parmQuoteBoActiveStatus);
            query.bindEntity("saIdCharacteristicType", parmSaIdCharType);
            query.bindId("saId", serviceAgreement.getId());

            query.addResult("serviceTask", "SVCTASK.id");

            return query;
        }

        /**
         * Retrieves Active Service Task using Pledge ID query
         * @return query
         */
        private Query cmRetrieveServiceTaskUsingPledgeId() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM ServiceTask SVCTASK, ServiceTaskCharacteristic SVCTASKCHAR ");
            stringBuilder.append(" WHERE SVCTASKCHAR.id.characteristicType = :pledgeIdCharacteristicType ");
            // CVB - 2013-05-07 - Start
            // stringBuilder.append(" 	AND (SVCTASKCHAR.adhocCharacteristicValue = :pledgeId ");
            // stringBuilder.append("      OR SVCTASKCHAR.characteristicValueForeignKey1 = :pledgeId ");
            // stringBuilder.append("      OR SVCTASKCHAR.characteristicValue = :pledgeId) ");
            stringBuilder.append("  AND (SVCTASKCHAR.adhocCharacteristicValue = :pledgeIdAdhoc ");
            stringBuilder.append("      OR SVCTASKCHAR.characteristicValueForeignKey1 = :pledgeIdFK1 ");
            stringBuilder.append("      OR SVCTASKCHAR.characteristicValue = :pledgeIdCharVal) ");
            // CVB - 2013-05-07 - End
            stringBuilder.append(" 	AND SVCTASK.id = SVCTASKCHAR.id.serviceTask.id ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            
            query.bindEntity("pledgeIdCharacteristicType", parmPledgeIdCharType);
            // CVB - 2013-05-07 - Start
            // query.bindId("pledgeId", pledge.getId());
            query.bindStringProperty("pledgeIdFK1", ServiceTaskCharacteristic.properties.characteristicValueForeignKey1, pledgeIdStr);
            query.bindStringProperty("pledgeIdAdhoc", ServiceTaskCharacteristic.properties.adhocCharacteristicValue, pledgeIdStr);
            query.bindStringProperty("pledgeIdCharVal", ServiceTaskCharacteristic.properties.characteristicValue, pledgeIdStr);
            // CVB - 2013-05-07 - End
            query.addResult("serviceTask", "SVCTASK.id");

            return query;
        }

        /**
         * Retrieves Active Payment Arrangement SAs query
         * @return query
         */
        private Query cmRetrieveActivePaymentArrangementSas() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM ServiceAgreement SA, ");
            stringBuilder.append("	FeatureConfigurationOption CISDIVOPTION, ");
            stringBuilder.append("  FeatureConfigurationOption SATYPEOPTION ");
            stringBuilder.append(" WHERE SA.account = :account");
            stringBuilder.append(" 	AND SA.status = :activeStatus");
            stringBuilder.append(" 	AND CISDIVOPTION.id.workforceManagementSystem = :featureConfiguration");
            stringBuilder.append(" 	AND CISDIVOPTION.id.optionType = :cisDivisionOptType");
            stringBuilder.append(" 	AND SATYPEOPTION.id.workforceManagementSystem = :featureConfiguration");
            stringBuilder.append(" 	AND SATYPEOPTION.id.optionType = :saTypeOptType");
            stringBuilder.append(" 	AND TRIM(SA.serviceAgreementType.id.division) = TRIM(CISDIVOPTION.value)");
            stringBuilder.append(" 	AND TRIM(SA.serviceAgreementType.id.saType) = TRIM(SATYPEOPTION.value)");
            stringBuilder.append(" 	AND CISDIVOPTION.id.sequence = SATYPEOPTION.id.sequence ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            
            query.bindEntity("account", account);
            query.bindLookup("activeStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
            query.bindEntity("featureConfiguration", paymentArrangementSaTypesFeatConfig);
            query.bindStringProperty("cisDivisionOptType", FeatureConfigurationOption.properties.optionType,
                    CmPaymentArrangementSaTypesLookup.constants.CIS_DIVISION.trimmedValue());
            query.bindStringProperty("saTypeOptType", FeatureConfigurationOption.properties.optionType,
                    CmPaymentArrangementSaTypesLookup.constants.PAYMENT_ARRANGEMENT_SA_TYPE.trimmedValue());

            query.addResult("saId", "SA.id");

            return query;
        }

        /**
         * Retrieves CWR Level of Previous Quote query
         * @return query
         */
        private Query cmRetrieveCwrLevelOfPreviousQuote() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM ServiceTask SVCTASK, ServiceTaskCharacteristic SVCTASKCHAR ");
            stringBuilder.append(" WHERE SVCTASK.serviceTaskType = :serviceTaskType ");
            stringBuilder.append(" 	AND SVCTASK.businessObject = :businessObject ");
            stringBuilder.append(" 	AND SVCTASK.status = :activeBusinessObjectStatus ");
            stringBuilder.append(" 	AND SVCTASK.id = SVCTASKCHAR.id.serviceTask.id ");
            stringBuilder.append(" 	AND SVCTASKCHAR.id.characteristicType = :cwrLevelCharacteristicType ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            
            query.bindEntity("serviceTaskType", parmQuoteServiceTaskType);
            query.bindEntity("businessObject", parmQuoteBo);
            query.bindStringProperty("activeBusinessObjectStatus", ServiceTask.properties.status, parmQuoteBoActiveStatus);
            query.bindEntity("cwrLevelCharacteristicType", parmCwrLevelCharType);

            query.addResult("serviceTaskAdhocCharValue", "SVCTASKCHAR.adhocCharacteristicValue");
            query.addResult("serviceTaskForeignKeyCharValue", "SVCTASKCHAR.characteristicValueForeignKey1");
            query.addResult("serviceTaskPreDefinedCharValue", "SVCTASKCHAR.characteristicValue");
            query.addResult("creationDateTime", "SVCTASK.creationDateTime");
            query.orderBy("creationDateTime", Query.DESCENDING);

            return query;
        }

        /**
         * RetrievesMaximum Sequence Number query
         * @return query
         */
        private Query cmRetrieveMaximumSequenceNumber(ServiceTask serviceTask) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM ServiceTaskCharacteristic SVCTASKCHAR ");
            stringBuilder.append(" WHERE SVCTASKCHAR.id.serviceTask.id = :serviceTaskId ");
            stringBuilder.append(" 	AND SVCTASKCHAR.id.characteristicType = :webTransactionIdCharacteristicType ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            
            query.bindId("serviceTaskId", serviceTask.getId());
            query.bindEntity("webTransactionIdCharacteristicType", parmWebTransactionIdCharType);

            query.addResult("sequenceNumber", "MAX(SVCTASKCHAR.id.sequence)");

            return query;
        }

        /**
         * Retrieves Agency Code
         * @param charType Agency Code Characteristic Type
         * @param account Account
         * @return Agency Code
         */
        private String cmRetrieveAgencyCode(CharacteristicType charType, Account account) {
            String agencyCode = "";
            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
            AccountCharacteristic acctChar = account.getEffectiveCharacteristic(charType);

            if (notNull(acctChar)) {
                if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
                    agencyCode = acctChar.getAdhocCharacteristicValue().trim();
                }
                else if (charTypeLookup.isForeignKeyValue()) {
                    agencyCode = acctChar.getCharacteristicValueForeignKey1().trim();
                }
                else if (charTypeLookup.isPredefinedValue()) {
                    agencyCode = acctChar.getCharacteristicValue().trim();
                }
            }
            return agencyCode.trim();
        }
        
        // JPunza - 2013-10-11 - Start
        /**
         * This method will validate input parameters
         *
         */
        private void retrieveAndValidateInputParameters() {
            
            serviceTaskType = parmQuoteServiceTaskType;
            businessObject = parmQuoteBo;
            status = parmQuoteBoActiveStatus;
            creationDateTime = getProcessDateTime();
            statusDateTime = getProcessDateTime();
            effectiveDateTime = getProcessDateTime();
            selection = SELECTION_CWR;
            source = QUOTE_SRC_AGENCY;
                            
            // Service Task Type input is required
            if (isNull(serviceTaskType)) {
                addError(CustomMessageRepositoryMDC.np0055InputMissing(SERVICE_TASK_TYPE));
            }

            // Business Object input is required
            if (isNull(businessObject)) {
                addError(CustomMessageRepositoryMDC.np0055InputMissing(BUSINESS_OBJECT));
            }

            // Status input is required
            if (isBlankOrNull(status)) {
                addError(CustomMessageRepositoryMDC.np0055InputMissing(STATUS));
            }

            // Status input must be valid for Business Object input
            BusinessObjectStatus_Id boStatusId = new BusinessObjectStatus_Id(businessObject.fetchLifecycleBusinessObject(), status);
            if (isNull(boStatusId.getEntity())) {
                addError(CustomMessageRepositoryMDC.np0055InvalidBusinessObjectStatus(status, businessObject.getId().getTrimmedValue()));
            }

            // Set creation date/time to porcess date/time if not provided
            if (isNull(creationDateTime)) {
                this.creationDateTime = this.getProcessDateTime();
            }

            // Set status date/time to porcess date/time if not provided
            if (isNull(statusDateTime)) {
                this.statusDateTime = this.getProcessDateTime();
            }

            // Set selection to Standard if not provided
            if (isBlankOrNull(selection)) {
                this.selection = STANDARD;
            }

            // Set source to CCB if not provided
            if (isBlankOrNull(source)) {
                this.source = CCB;
            }

        }

        /**
         * This method will validate other parameters
         *
         */
        private void retrieveAndValidateOtherParameters() {
            // Service Task Characteristic Types Feature Configuration
            FeatureConfiguration svcTaskCharTypeFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_SERVICE_TASK_CHARACTERISTIC_TYPES);

            // Service Agreement Characteristic Type
            LookupValue optionType = CmServiceTaskCharacteristicTypesLookup.constants.SA_ID_CHARACTERISTIC_TYPE.getLookupValue();
            String optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            serviceAgreementCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);       

            // CIS Division Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.CIS_DIVISION_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            cisDivisionCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);    

            // Debt Class Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.DEBT_CLASS_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            debtClassCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  

            // Expiration Date Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.EXPIRATION_DATE_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            expirationDateCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue); 

            // CWR Level Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.CWR_LEVEL_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            cwrLevelCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);   

            // Total SA Arrears Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.TOTAL_SA_ARREARS_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            totalSaArrearsCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue); 

            // Total Diversion Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.TOTAL_DIVERSION_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            totalDiversionCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue); 

            // Monthly Budget Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_BUDGET_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            monthlyBudgetCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  

            // Standard Turn-On or Avoid Severance Amount Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.STANDARD_TURN_ON_OR_AVOID_SEVERANCE_AMOUNT_CHAR_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            standardTurnOnOrAvoidSeveranceAmountCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);   

            // CWR Down Payment Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.CWR_DOWN_PAYMENT_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            cwrDownPaymentCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue); 

            // CWR Monthly Payment Arrangement Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.CWR_MONTHLY_PAYMENT_ARRANGEMENT_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            cwrMonthlyPaymentArrangementCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);   

            // BPAP 0-50 Monthly Budget Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.BPAP_0_5_0_MONTHLY_BUDGET_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            bpap050MonthlyBudgetCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);   

            // BPAP 51-99 Monthly Budget Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.BPAP_5_1_9_9_MONTHLY_BUDGET_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            bpap5199MonthlyBudgetCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  

            // BPAP 100-125 Monthly Budget Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.BPAP_1_0_0_1_2_5_MONTHLY_BUDGET_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            bpap100125MonthlyBudgetCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);    

            // BPAP 126-185 Monthly Budget Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.BPAP_1_2_6_1_8_5_MONTHLY_BUDGET_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            bpap126185MonthlyBudgetCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);    

            // ARP 0-50 Down Payment Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.ARP_0_5_0_DOWN_PAYMENT_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            arp050DownPaymentCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  

            // ARP 51-99 Down Payment Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.ARP_5_1_9_9_DOWN_PAYMENT_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            arp5199DownPaymentCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue); 

            // ARP 100-125 Down Payment Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.ARP_1_0_0_1_2_5_DOWN_PAYMENT_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            arp100125DownPaymentCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);   

            // ARP 126-185 Down Payment Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.ARP_1_2_6_1_8_5_DOWN_PAYMENT_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            arp126185DownPaymentCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);   

            // Monthly ARP 0-50 Payment Arrangement - 12 Month Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_0_5_0_PAYMENT_ARRANGEMENT_1_2_MONTH_CHAR_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            monthlyArp050PaymentArrangement12MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue); 

            // Monthly ARP 51-99 Payment Arrangement - 12 Month Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_5_1_9_9_PAYMENT_ARRANGEMENT_1_2_MONTH_CHAR_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            monthlyArp5199PaymentArrangement12MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);    

            // Monthly ARP 100-125 Payment Arrangement - 12 Month Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_1_0_0_1_2_5_PAYMENT_ARRANGEMENT_1_2_MONTH_CHAR_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            monthlyArp100125PaymentArrangement12MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  

            // Monthly ARP 126-185 Payment Arrangement - 12 Month Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_1_2_6_1_8_5_PAYMENT_ARRANGEMENT_1_2_MONTH_CHAR_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            monthlyArp126185PaymentArrangement12MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  

            // Monthly ARP 0-50 Payment Arrangement - 24 Month Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_0_5_0_PAYMENT_ARRANGEMENT_2_4_MONTH_CHAR_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            monthlyArp050PaymentArrangement24MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue); 

            // Monthly ARP 51-99 Payment Arrangement - 24 Month Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_5_1_9_9_PAYMENT_ARRANGEMENT_2_4_MONTH_CHAR_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            monthlyArp5199PaymentArrangement24MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);    

            // Monthly ARP 100-125 Payment Arrangement - 24 Month Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_1_0_0_1_2_5_PAYMENT_ARRANGEMENT_2_4_MONTH_CHAR_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            monthlyArp100125PaymentArrangement24MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  

            // Monthly ARP 126-185 Payment Arrangement - 24 Month Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.MONTHLY_ARP_1_2_6_1_8_5_PAYMENT_ARRANGEMENT_2_4_MONTH_CHAR_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            monthlyArp126185PaymentArrangement24MonthCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  

            // Selection Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.SELECTION_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            selectionCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  

            // Quote Source Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.QUOTE_SOURCE_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            quoteSourceCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);    

            // Custom Down Payment Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.CUSTOM_DOWN_PAYMENT_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            customDownPaymentCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  

            // BPAP Credit Values Feature Configuration
            FeatureConfiguration bpapCreditValuesFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_BPAP_CREDIT_VALUES);   

            // BPAP 0-50 Credit Value
            optionType = CmBpapCreditValuesLookup.constants.CM_BPAP_5_0_CREDIT_VALUE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(bpapCreditValuesFeatConfig, optionType);
            bpap050CreditValue = validateBigDecimalValue(bpapCreditValuesFeatConfig, optionType, optionValue);

            // BPAP 51-99 Credit Value
            optionType = CmBpapCreditValuesLookup.constants.CM_BPAP_9_9_CREDIT_VALUE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(bpapCreditValuesFeatConfig, optionType);
            bpap5199CreditValue = validateBigDecimalValue(bpapCreditValuesFeatConfig, optionType, optionValue);

            // BPAP 100-125 Credit Value
            optionType = CmBpapCreditValuesLookup.constants.CM_BPAP_1_2_5_CREDIT_VALUE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(bpapCreditValuesFeatConfig, optionType);
            bpap100125CreditValue = validateBigDecimalValue(bpapCreditValuesFeatConfig, optionType, optionValue);

            // BPAP 126-185 Credit Value
            optionType = CmBpapCreditValuesLookup.constants.CM_BPAP_1_8_5_CREDIT_VALUE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(bpapCreditValuesFeatConfig, optionType);
            bpap126185CreditValue = validateBigDecimalValue(bpapCreditValuesFeatConfig, optionType, optionValue);

            // ARP Down Payment Feature Configuration
            FeatureConfiguration arpDownPaymentFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_ARP_DOWN_PAYMENT);

            // ARP 0-50 Down Payment Value
            optionType = CmArpDownPaymentLookup.constants.ARP_0_5_0_DOWN_PAYMENT_VALUE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(arpDownPaymentFeatConfig, optionType);
            arp050DownPaymentValue = validateBigDecimalValue(arpDownPaymentFeatConfig, optionType, optionValue);

            // ARP 51-99 Down Payment Value
            optionType = CmArpDownPaymentLookup.constants.ARP_5_1_9_9_DOWN_PAYMENT_VALUE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(arpDownPaymentFeatConfig, optionType);
            arp5199DownPaymentValue = validateBigDecimalValue(arpDownPaymentFeatConfig, optionType, optionValue);

            // ARP 100-125 Down Payment Value
            optionType = CmArpDownPaymentLookup.constants.ARP_1_0_0_1_2_5_DOWN_PAYMENT_VALUE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(arpDownPaymentFeatConfig, optionType);
            arp100125DownPaymentValue = validateBigDecimalValue(arpDownPaymentFeatConfig, optionType, optionValue);

            // ARP 126-185 Down Payment Value
            optionType = CmArpDownPaymentLookup.constants.ARP_1_2_6_1_8_5_DOWN_PAYMENT_VALUE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(arpDownPaymentFeatConfig, optionType);
            arp126185DownPaymentValue = validateBigDecimalValue(arpDownPaymentFeatConfig, optionType, optionValue);

            // Diversion SA Types Feature Configuration
            diversionSaTypesFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_DIVERSION_SA_TYPES);

            // Payment Arrangement SA Types Feature Configuration
            paymentArrangementSaTypesFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_PAYMENT_ARRANGEMENT_SA_TYPES); 

            // Quote Portal Parameters Feature Configuration
            FeatureConfiguration quotePortalParmsFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_QUOTE_PORTAL_PARAMETERS); 

            // Recalculated Characteristic Type
            optionType = CmQuotePortalParametersLookup.constants.RECALCULATED_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
            recalculatedCharType = validateServiceAgreementCharacteristicType(quotePortalParmsFeatConfig, optionType, optionValue);

            // Recalculated Characteristic Value
            optionType = CmQuotePortalParametersLookup.constants.RECALCULATED_CHARACTERISTIC_VALUE.getLookupValue();
            recalculatedCharValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);

            // Broken Payment Arrangement Characteristic Type
            optionType = CmQuotePortalParametersLookup.constants.BROKEN_PAYMENT_ARRANGEMENT_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
            brokenCharType = validateServiceAgreementCharacteristicType(quotePortalParmsFeatConfig, optionType, optionValue);

            // Broken Payment Arrangement Characteristic Value
            optionType = CmQuotePortalParametersLookup.constants.BROKEN_PAYMENT_ARRANGEMENT_CHARACTERISTIC_VALUE.getLookupValue();
            brokenCharValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);

            // CWR Characteristic Type
            optionType = CmQuotePortalParametersLookup.constants.CWR_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
            cwrCharType = validateServiceAgreementCharacteristicType(quotePortalParmsFeatConfig, optionType, optionValue);

            // CWR Characteristic Value
            optionType = CmQuotePortalParametersLookup.constants.CWR_CHARACTERISTIC_VALUE.getLookupValue();
            cwrCharValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);

            // Transfer Adjustment Type
            optionType = CmQuotePortalParametersLookup.constants.TRANSFER_ADJUSTMENT_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
            transferAdjustmentType = validateAdjustmentType(quotePortalParmsFeatConfig, optionType, optionValue);

            // CWR Premise Characteristic Type
            optionType = CmQuotePortalParametersLookup.constants.CWR_PREMISE_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
            cwrPremiseCharType = validateServiceAgreementCharacteristicType(quotePortalParmsFeatConfig, optionType, optionValue);        

            // Average Bill Amount Characteristic Type
            optionType = CmServiceTaskCharacteristicTypesLookup.constants.AVERAGE_BILL_AMOUNT_CHARACTERISTIC_TYPE.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
            averageBillAmountCharType = validatePremiseCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);

            // Round Up Unit
            optionType = CmQuotePortalParametersLookup.constants.ROUND_UP_UNIT.getLookupValue();
            optionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
            roundUpUnit = validateIntegerValue(quotePortalParmsFeatConfig, optionType, optionValue);        
        }

        /**
         * This method will retrieve feature configuration
         * @param lookup ExternalSystemTypeLookup
         * @return featureConfiguration FeatureConfiguration
         */
        private FeatureConfiguration retrieveFeatureConfiguration(ExternalSystemTypeLookup featureType) {
            FeatureConfiguration featureConfiguration = null;

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM FeatureConfiguration fc ");
            stringBuilder.append(" WHERE fc.featureType = :featureType ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation	
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            query.bindLookup("featureType", featureType);

            if (query.list().isEmpty()) {
                addError(CustomMessageRepositoryMDC.np0055NoFeatureConfigurationRetrieved(featureType.getLookupValue().fetchLanguageDescription()));
            }
            else if (query.list().size() > 1) {
                addError(CustomMessageRepositoryMDC.np0055MultipleFeatureConfigurationRetrieved(featureType.getLookupValue().fetchLanguageDescription()));
            }
            else {
                featureConfiguration = (FeatureConfiguration) query.firstRow();
            }

            return featureConfiguration;
        }

        /**
         * This method will retrieve feature configuration option value
         * @param featureConfiguration FeatureConfiguration
         * @param optionType String
         * @return optionValue String
         */
        private String retrieveFeatureConfigurationOptionValue(FeatureConfiguration featureConfiguration, LookupValue lookupValue) {
            String optionValue = "";

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM FeatureConfigurationOption fco ");
            stringBuilder.append(" WHERE fco.id.workforceManagementSystem = :workforceManagementSystem ");
            stringBuilder.append(" AND fco.id.optionType = :optionType ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            query.bindEntity("workforceManagementSystem", featureConfiguration);
            query.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, lookupValue.fetchIdFieldValue().trim());   
            query.addResult("value", "fco.value");

            if (query.list().isEmpty()) {
                addError(CustomMessageRepositoryMDC.np0055NoOptionvalueRetrieved(featureConfiguration.getId().getTrimmedValue(), lookupValue.fetchLanguageDescription()));
            }
            else if (query.list().size() > 1) {
                addError(CustomMessageRepositoryMDC.np0055MultipleOptionvalueRetrieved(featureConfiguration.getId().getTrimmedValue(), lookupValue.fetchLanguageDescription()));
            }
            else {
                optionValue = (String) query.firstRow();
            }

            return optionValue;
        }

        /**
         * This method will validate Service Task Characteristic Type
         * @param featConfig FeatureConfiguration
         * @param optionType LookupValue
         * @param charTypeStr String
         * @return charType CharacteristicType
         */
        private CharacteristicType validateServiceTaskCharacteristicType(FeatureConfiguration featConfig, LookupValue optionType, String charTypeStr) {
            CharacteristicType_Id charTypeId = new CharacteristicType_Id(charTypeStr);
            CharacteristicType charType = charTypeId.getEntity();

            if (isNull(charType)) {
                addError(CustomMessageRepositoryMDC.np0055InvalidCharacteristicType(featConfig.getId().getTrimmedValue(), 
                        optionType.fetchLanguageDescription(), charTypeStr));
            }

            CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, CharacteristicEntityLookup.constants.SERVICE_TASK);
            if (isNull(charEntityId.getEntity())) {
                addError(CustomMessageRepositoryMDC.np0055InvalidCharacteristicTypeForEntity(featConfig.getId().getTrimmedValue(), 
                        optionType.fetchLanguageDescription(), charTypeStr, SERVICE_TASK));
            }

            return charType;
        }

        /**
         * This method will validate Service Agreement Characteristic Type
         * @param featConfig FeatureConfiguration
         * @param optionType LookupValue
         * @param charTypeStr String
         * @return charType CharacteristicType
         */
        private CharacteristicType validateServiceAgreementCharacteristicType(FeatureConfiguration featConfig, LookupValue optionType, String charTypeStr) {
            CharacteristicType_Id charTypeId = new CharacteristicType_Id(charTypeStr);
            CharacteristicType charType = charTypeId.getEntity();

            if (isNull(charType)) {
                addError(CustomMessageRepositoryMDC.np0055InvalidCharacteristicType(featConfig.getId().getTrimmedValue(), 
                        optionType.fetchLanguageDescription(), charTypeStr));
            }

            CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT);
            if (isNull(charEntityId.getEntity())) {
                addError(CustomMessageRepositoryMDC.np0055InvalidCharacteristicTypeForEntity(featConfig.getId().getTrimmedValue(), 
                        optionType.fetchLanguageDescription(), charTypeStr, SERVICE_AGREEMENT));
            }

            return charType;
        }

        private CharacteristicType validatePremiseCharacteristicType(FeatureConfiguration featConfig, LookupValue optionType, String charTypeStr) {
            CharacteristicType_Id charTypeId = new CharacteristicType_Id(charTypeStr);
            CharacteristicType charType = charTypeId.getEntity();

            if (isNull(charType)) {
                addError(CustomMessageRepositoryMDC.np0055InvalidCharacteristicType(featConfig.getId().getTrimmedValue(), 
                        optionType.fetchLanguageDescription(), charTypeStr));
            }

            CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, CharacteristicEntityLookup.constants.PREMISE);
            if (isNull(charEntityId.getEntity())) {
                addError(CustomMessageRepositoryMDC.np0055InvalidCharacteristicTypeForEntity(featConfig.getId().getTrimmedValue(), 
                        optionType.fetchLanguageDescription(), charTypeStr, PREMISE));
            }

            return charType;
        }

        /**
         * This method will validate Adjustment Type
         * @param featConfig FeatureConfiguration
         * @param optionType LookupValue
         * @param adjTypeStr String
         * @return adj AdjustmentType
         */
        private AdjustmentType validateAdjustmentType(FeatureConfiguration featConfig, LookupValue optionType, String adjTypeStr) {
            AdjustmentType_Id adjId = new AdjustmentType_Id(adjTypeStr);
            AdjustmentType adj = adjId.getEntity();

            if (isNull(adj)) {
                addError(CustomMessageRepositoryMDC.np0055InvalidAdjustmentType(featConfig.getId().getTrimmedValue(), 
                        optionType.fetchLanguageDescription(), adjTypeStr));
            }

            return adj;
        }

        /**
         * This method will validate BigDecimal input
         * @param featConfig FeatureConfiguration
         * @param optionType LookupValue
         * @param str String
         * @return decimal BigDecimal
         */
        private BigDecimal validateBigDecimalValue(FeatureConfiguration featConfig, LookupValue optionType, String str) {   
            BigDecimal decimal = BigDecimal.ZERO;
            try {
                decimal = BigDecimal.valueOf(Double.parseDouble(str));
            }
            catch (NumberFormatException nfe) {
                addError(CustomMessageRepositoryMDC.np0055InvalidNumber(featConfig.getId().getTrimmedValue(), 
                        optionType.fetchLanguageDescription(), str));
            }

            return decimal;
        }

        // JPunza - 2013-08-22 - Start
        /**
         * This method will validate BigInteger input
         * @param featConfig FeatureConfiguration
         * @param optionType LookupValue
         * @param str String
         * @return integer BigInteger
         */
        private int validateIntegerValue(FeatureConfiguration featConfig, LookupValue optionType, String str) {   
            int integer = 0;
            try {
                integer = Integer.parseInt(str);
            }
            catch (NumberFormatException nfe) {
                addError(CustomMessageRepositoryMDC.np0055InvalidNumber(featConfig.getId().getTrimmedValue(), 
                        optionType.fetchLanguageDescription(), str));
            }

            return integer;
        }
    
        /**
         * This method will create Service Task Characteristics
         * @param serviceTask ServiceTask
         */
        private void createServiceTaskCharacteristics(ServiceTask serviceTask) {    
            // Service Agreement Characteristic
            addServiceTaskCharacteristic(serviceTask, serviceAgreementCharType, serviceAgreement.getId().getTrimmedValue());

            // CIS Division Characteristic
            addServiceTaskCharacteristic(serviceTask, cisDivisionCharType, serviceAgreement.getServiceAgreementType().fetchIdDivision().getId().getTrimmedValue());

            // Debt Class Characteristic
            addServiceTaskCharacteristic(serviceTask, debtClassCharType, serviceAgreement.getServiceAgreementType().getDebtClass().getId().getTrimmedValue());

            // Expiration Date Characteristic
            Date nextBillDate = retrieveNextBillingWindow();
            Date expirationDate = null;

            DateFormat cwrSeasonDateFormat = new DateFormat(CWR_SEASON_DATE_FORMAT);


            if (isNull(nextBillDate)) {
                FeatureConfiguration quotePortalParmsFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_QUOTE_PORTAL_PARAMETERS); 
                // CWR Season End
                LookupValue optionType = CmQuotePortalParametersLookup.constants.CWR_SEASON_END.getLookupValue();
                cwrSeasonEnd = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);

                int systemYear = this.getProcessDateTime().getYear();

                String cwrSeasonEndStr = cwrSeasonEnd + "/" + systemYear;
                Date cwrSeasonEndDate = null;
                try {
                    cwrSeasonEndDate = Date.fromString(cwrSeasonEndStr, cwrSeasonDateFormat);
                    if (this.getProcessDateTime().getDate().isAfter(cwrSeasonEndDate)) {
                        cwrSeasonEndDate = cwrSeasonEndDate.addYears(1);
                    }
                }
                catch (Exception e) {
                    addError(CustomMessageRepositoryMDC.np0055InputInvalid(CWR_SEASON_END));
                }

                expirationDate = cwrSeasonEndDate;

            } else {
                expirationDate = nextBillDate;
            }

            if(notNull(expirationDate)) {
                addServiceTaskCharacteristic(serviceTask, expirationDateCharType, expirationDate.toString(new DateFormat(DATE_FORMAT)));
            }

            // CWR Level Characteristic
            String cwrLevel = retrieveCwrLevel();
            addServiceTaskCharacteristic(serviceTask, cwrLevelCharType, cwrLevel);

            // Total SA Arrears Characteristic
            
            /*
             * Start Change - IM-044095 - Ujesh  - 2014-02-06
             */
            
            //BigDecimal totalSaArrears = serviceAgreement.getCurrentBalance(creationDateTime.getDate(), creationDateTime.getDate(), Bool.FALSE).getAmount();
              BigDecimal totalSaArrears = serviceAgreement.getPayoffBalance(creationDateTime.getDate(), creationDateTime.getDate(), Bool.FALSE).getAmount();
            
            /*
             * End Change - IM-044095 - Ujesh  - 2014-02-06
             */
            
            addServiceTaskCharacteristic(serviceTask, totalSaArrearsCharType, totalSaArrears.toString());

            // Total Diversion Characteristic
            BigDecimal totalDiversion = retrieveTotalDiversion().getAmount();
            addServiceTaskCharacteristic(serviceTask, totalDiversionCharType, totalDiversion.toString());

            // Monthly Budget Characteristic
            BigDecimal monthlyBudget = retrieveMonthlyBudget();
            addServiceTaskCharacteristic(serviceTask, monthlyBudgetCharType, monthlyBudget.toString());

            // Standard Turn-On or Avoid Severance Amount Characteristic
            BigDecimal standardAmount = retrieveStandardAmount().add(totalDiversion);
            addServiceTaskCharacteristic(serviceTask, standardTurnOnOrAvoidSeveranceAmountCharType, standardAmount.toString());

            // CWR Down Payment Characteristic
            BigDecimal cwrDownPayment = retrieveCwrDownPayment(cwrLevel, totalSaArrears, monthlyBudget, totalDiversion).setScale(2, BigDecimal.ROUND_HALF_UP);
            addServiceTaskCharacteristic(serviceTask, cwrDownPaymentCharType, cwrDownPayment.toString());

            // CWR Monthly Payment Arrangement Characteristic
            BigDecimal cwrMonthlyPaymentArrangement = (totalSaArrears.subtract(cwrDownPayment.subtract(totalDiversion))).divide(BigDecimal.valueOf(12)).setScale(2, BigDecimal.ROUND_HALF_UP);
            addServiceTaskCharacteristic(serviceTask, cwrMonthlyPaymentArrangementCharType, cwrMonthlyPaymentArrangement.toString());

            // BPAP 0-50 Monthly Budget Characteristic
            BigDecimal bpap050MonthlyBudget = monthlyBudget.subtract(bpap050CreditValue);
            addServiceTaskCharacteristic(serviceTask, bpap050MonthlyBudgetCharType, bpap050MonthlyBudget.toString());

            // BPAP 51-99 Monthly Budget Characteristic
            BigDecimal bpap5199MonthlyBudget = monthlyBudget.subtract(bpap5199CreditValue);
            addServiceTaskCharacteristic(serviceTask, bpap5199MonthlyBudgetCharType, bpap5199MonthlyBudget.toString());

            // BPAP 100-125 Monthly Budget Characteristic
            BigDecimal bpap100125MonthlyBudget = monthlyBudget.subtract(bpap100125CreditValue);
            addServiceTaskCharacteristic(serviceTask, bpap100125MonthlyBudgetCharType, bpap100125MonthlyBudget.toString());

            // BPAP 126-185 Monthly Budget Characteristic
            BigDecimal bpap126185MonthlyBudget = monthlyBudget.subtract(bpap126185CreditValue);
            addServiceTaskCharacteristic(serviceTask, bpap126185MonthlyBudgetCharType, bpap126185MonthlyBudget.toString());

            // ARP 0-50 Down Payment Characteristic
            addServiceTaskCharacteristic(serviceTask, arp050DownPaymentCharType, arp050DownPaymentValue.toString());

            // ARP 51-99 Down Payment Characteristic
            addServiceTaskCharacteristic(serviceTask, arp5199DownPaymentCharType, arp5199DownPaymentValue.toString());

            // ARP 100-125 Down Payment Characteristic
            addServiceTaskCharacteristic(serviceTask, arp100125DownPaymentCharType, arp100125DownPaymentValue.toString());

            // ARP 126-185 Down Payment Characteristic
            addServiceTaskCharacteristic(serviceTask, arp126185DownPaymentCharType, arp126185DownPaymentValue.toString());

            // Monthly ARP 0-50 Payment Arrangement - 12 Month Characteristic
            BigDecimal monthlyArp050PaymentArrangement12Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
                    arp050DownPaymentValue, BigDecimal.valueOf(24));
            addServiceTaskCharacteristic(serviceTask, monthlyArp050PaymentArrangement12MonthCharType, monthlyArp050PaymentArrangement12Month.toString());

            // Monthly ARP 51-99 Payment Arrangement - 12 Month Characteristic
            BigDecimal monthlyArp5199PaymentArrangement12Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
                    arp5199DownPaymentValue, BigDecimal.valueOf(24));
            addServiceTaskCharacteristic(serviceTask, monthlyArp5199PaymentArrangement12MonthCharType, monthlyArp5199PaymentArrangement12Month.toString());

            // Monthly ARP 100-125 Payment Arrangement - 12 Month Characteristic
            BigDecimal monthlyArp100125PaymentArrangement12Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
                    arp100125DownPaymentValue, BigDecimal.valueOf(24));
            addServiceTaskCharacteristic(serviceTask, monthlyArp100125PaymentArrangement12MonthCharType, monthlyArp100125PaymentArrangement12Month.toString());

            // Monthly ARP 126-185 Payment Arrangement - 12 Month Characteristic
            BigDecimal monthlyArp126185PaymentArrangement12Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
                    arp126185DownPaymentValue, BigDecimal.valueOf(24));
            addServiceTaskCharacteristic(serviceTask, monthlyArp126185PaymentArrangement12MonthCharType, monthlyArp126185PaymentArrangement12Month.toString());

            // Monthly ARP 0-50 Payment Arrangement - 24 Month Characteristic
            BigDecimal monthlyArp050PaymentArrangement24Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
                    arp050DownPaymentValue, BigDecimal.valueOf(48));
            addServiceTaskCharacteristic(serviceTask, monthlyArp050PaymentArrangement24MonthCharType, monthlyArp050PaymentArrangement24Month.toString());

            // Monthly ARP 51-99 Payment Arrangement - 24 Month Characteristic
            BigDecimal monthlyArp5199PaymentArrangement24Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
                    arp5199DownPaymentValue, BigDecimal.valueOf(48));
            addServiceTaskCharacteristic(serviceTask, monthlyArp5199PaymentArrangement24MonthCharType, monthlyArp5199PaymentArrangement24Month.toString());

            // Monthly ARP 100-125 Payment Arrangement - 24 Month Characteristic
            BigDecimal monthlyArp100125PaymentArrangement24Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
                    arp100125DownPaymentValue, BigDecimal.valueOf(48));
            addServiceTaskCharacteristic(serviceTask, monthlyArp100125PaymentArrangement24MonthCharType, monthlyArp100125PaymentArrangement24Month.toString());

            // Monthly ARP 126-185 Payment Arrangement - 24 Month Characteristic
            BigDecimal monthlyArp126185PaymentArrangement24Month = computeMonthlyPaymentArrangement(totalSaArrears, totalDiversion, 
                    arp126185DownPaymentValue, BigDecimal.valueOf(48));
            addServiceTaskCharacteristic(serviceTask, monthlyArp126185PaymentArrangement24MonthCharType, monthlyArp126185PaymentArrangement24Month.toString());

            // Selection Characteristic
            addServiceTaskCharacteristic(serviceTask, selectionCharType, selection);

            // Quote Source Characteristic
            addServiceTaskCharacteristic(serviceTask, quoteSourceCharType, source);

            // Custom Down Payment Characteristic
            addServiceTaskCharacteristic(serviceTask, customDownPaymentCharType, NO);
        }
        
        /**
         * This method will add Service Task Characteristic
         * @param serviceTask ServiceTask
         * @param charType CharacteristicType
         * @param charValue String
         */
        private void addServiceTaskCharacteristic(ServiceTask serviceTask, CharacteristicType charType, String charValue) {
            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

            ServiceTaskCharacteristic_DTO serviceTaskCharacteristicDto = createDTO(ServiceTaskCharacteristic.class);
            if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
                serviceTaskCharacteristicDto.setAdhocCharacteristicValue(charValue.trim());
            } 
            else if (charTypeLookup.isPredefinedValue()) {
                serviceTaskCharacteristicDto.setCharacteristicValue(charValue.trim());
            }
            else if (charTypeLookup.isForeignKeyValue()) {
                serviceTaskCharacteristicDto.setCharacteristicValueForeignKey1(charValue.trim());
            }

            serviceTask.getCharacteristics().add(serviceTaskCharacteristicDto, charType.getId(), BigInteger.TEN);
        }
        
        /**
         * This method will retrieve Monthly Budget Amount
         * @return budgetAmount BigDecimal
         */
        private BigDecimal retrieveMonthlyBudget()  {
            BigDecimal budgetAmount = BigDecimal.ZERO;

            Account account = serviceAgreement.getAccount();

            ServiceAgreementStatusLookup saStatusLookup = serviceAgreement.getStatus();
            if (saStatusLookup.isPendingStart() || saStatusLookup.isActive() || saStatusLookup.isPendingStop()){
                BudgetPlan budgetPlan = account.fetchBudgetPlan();
                if (isNull(budgetPlan)) {
                    CustomerClassControl_Id controlId = new CustomerClassControl_Id(serviceAgreement.getAccount().getCustomerClass(), 
                            serviceAgreement.getServiceAgreementType().fetchIdDivision());
                    budgetPlan = controlId.getEntity().fetchDefaultBudgetPlan();
                }

                if (notNull(budgetPlan)) {
                    try {
                        budgetAmount = serviceAgreement.recommendBudgetAmount(creationDateTime.getDate(), budgetPlan).getAmount();
                    }
                    catch(Exception e) {
                    }
                    if (serviceAgreement.recommendBudgetAmount(creationDateTime.getDate(), budgetPlan).isEqualTo(Money.ZERO)){
                        budgetAmount = retrieveRecurringChargeAmount();
                    }
                }
                else {
                    budgetAmount = retrieveRecurringChargeAmount();
                }
            }
            else {
                budgetAmount = retrieveRecurringChargeAmount();
            }

            return budgetAmount;
        }
        
        private BigDecimal retrieveRecurringChargeAmount()  {

            BigDecimal recurChargeAmount = BigDecimal.ZERO;

            Bool saTypeBudgetEligible = serviceAgreement.getServiceAgreementType().getIsEligibleForBudget();
            if (saTypeBudgetEligible.isTrue()) {
                //Retrieve Recurring Charge
                ListFilter<ServiceAgreementRecurringCharge> recurringChargesFilter = null;
                ServiceAgreementRecurringCharge recurringCharge = null;

                //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation  
                //recurringChargesFilter = serviceAgreement.getRecurringCharges().createFilter("WHERE this.id.effectiveDate <= :processDate ORDER BY this.id.effectiveDate DESC ");
                recurringChargesFilter = serviceAgreement.getRecurringCharges().createFilter(
                		"WHERE this.id.effectiveDate <= :processDate ORDER BY this.id.effectiveDate DESC ", getClass().getName());
                //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation  
                recurringChargesFilter.bindDate("processDate", this.getProcessDateTime().getDate());

                if(recurringChargesFilter.listSize() > 0) {
                    recurringCharge = recurringChargesFilter.firstRow();
                    recurChargeAmount = recurringCharge.getRecurringChargeAmount().getAmount();
                }
                else {
                    recurChargeAmount = retrievePremiseAverageCharacteristic();
                }
            }
            else {
                recurChargeAmount = retrievePremiseAverageCharacteristic();
            }

            return roundUp(recurChargeAmount);
        }

        private BigDecimal retrievePremiseAverageCharacteristic()  {

            BigDecimal premCharAmount = BigDecimal.ZERO;

            Premise_Id saCharPremId = serviceAgreement.getPremiseId();
            Premise premise = null;
            CharacteristicType charType = averageBillAmountCharType;
            String charVal = "";

            if (notNull(saCharPremId)){
                premise = saCharPremId.getEntity();
            }

            if (notNull(premise)){
                PremiseCharacteristic premChar = premise.getEffectiveCharacteristic(charType);

                if (notNull(premChar)){                     
                    if (charType.getCharacteristicType().isAdhocValue() || charType.getCharacteristicType().isFileLocationValue()) {
                        charVal = premChar.getAdhocCharacteristicValue().trim();
                    }
                    if (charType.getCharacteristicType().isForeignKeyValue()) {
                        charVal = premChar.getCharacteristicValueForeignKey1().trim();           
                    }
                    if (charType.getCharacteristicType().isPredefinedValue()) {
                        charVal = premChar.getCharacteristicValue().trim(); 
                    }

                    try {
                        BigDecimal monthlyBudgetAmount = BigDecimal.valueOf(Double.parseDouble(charVal));
                        premCharAmount = monthlyBudgetAmount;
                    }
                    catch (Exception e) {
                    }
                }
            }

            return premCharAmount;
        }

        private BigDecimal roundUp(BigDecimal amount) {

            BigDecimal roundUpValue = BigDecimal.valueOf(roundUpUnit);
            int roundInt = amount.divide(roundUpValue).intValue();

            int roundAmount = roundInt * roundUpUnit;

            if (amount.compareTo(BigDecimal.valueOf(roundAmount)) != 0) {
                roundAmount = roundUpUnit + roundAmount;
            }

            return BigDecimal.valueOf(roundAmount);
        }    

        /**
         * This method will retrieve the next billing window
         * @return windowStartDate Date
         */
        private Date retrieveNextBillingWindow() {
            Date windowStartDate = null;

            PreparedStatement checkIfAccountDoesNotHaveBillableSAs = createPreparedStatement(
                    " SELECT ACCT_ID " +
                    " FROM CI_ACCT ACCT " +
                    " WHERE ACCT_ID = :acctId " +
                    " AND NOT EXISTS (SELECT 'X' " +
                    "                 FROM CI_SA SA " +
                    "                     ,CI_SA_TYPE SAT " +
                    "                 WHERE SA.CIS_DIVISION = SAT.CIS_DIVISION " +
                    "                   AND SA.SA_TYPE_CD = SAT.SA_TYPE_CD " +
                    "                   AND SAT.ALLOW_BILLING_SW = 'Y' " +
                    "                   AND SA.ACCT_ID = ACCT.ACCT_ID " +
                    "                   AND (SA.SA_STATUS_FLG IN (:pendingStart,:active,:pendingStop) " +
                    "                        OR  " +
                    "                       (SA.SA_STATUS_FLG = :stopped " +
                    "                        AND NOT EXISTS (SELECT 'X' " +
                    "                                        FROM CI_BSEG " +
                    "                                        WHERE SA_ID = SA.SA_ID " +
                    "                                          AND BSEG_STAT_FLG = :frozen " +
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation       
            //"                                          AND CLOSING_BSEG_SW = 'Y')))) ");
            		"                                          AND CLOSING_BSEG_SW = 'Y')))) ", getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            checkIfAccountDoesNotHaveBillableSAs.bindEntity("acctId", serviceAgreement.getAccount());
            checkIfAccountDoesNotHaveBillableSAs.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
            checkIfAccountDoesNotHaveBillableSAs.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
            checkIfAccountDoesNotHaveBillableSAs.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
            checkIfAccountDoesNotHaveBillableSAs.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
            checkIfAccountDoesNotHaveBillableSAs.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);

            if (!checkIfAccountDoesNotHaveBillableSAs.list().isEmpty()) {

                // Account Does Not have a Billable SA so next Billing Window is null
                windowStartDate = null;
                return windowStartDate;

            }

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM BillCycleSchedule bcs ");
            stringBuilder.append(" WHERE bcs.id.billCycle = :billCycle ");
            stringBuilder.append(" AND bcs.id.windowStartDate > :windowStartDate ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            query.bindEntity("billCycle", serviceAgreement.getAccount().fetchBillCycle());

            Date latestCompletedBillDate = retrieveLatestCompletedBill();
            if (this.getProcessDateTime().getDate().isAfter(latestCompletedBillDate)) {
                latestCompletedBillDate = this.getProcessDateTime().getDate();
            }
            query.bindDate("windowStartDate", latestCompletedBillDate);

            query.addResult("windowStartDate", "bcs.id.windowStartDate");
            query.orderBy("windowStartDate", Query.ASCENDING);

            if (!query.list().isEmpty()) {
                windowStartDate = (Date) query.firstRow();
            }

            return windowStartDate;
        }

        /**
         * This method will retrieve latest completed bill
         * @return
         */
        private Date retrieveLatestCompletedBill() {
            Date billDate = null;

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM Bill bill ");
            stringBuilder.append(" WHERE bill.account = :account ");
            stringBuilder.append(" AND bill.billStatus = :billStatus ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            query.bindEntity("account", serviceAgreement.getAccount());
            query.bindLookup("billStatus", BillStatusLookup.constants.COMPLETE);
            query.addResult("billDate", "bill.billDate");
            query.orderBy("billDate", Query.DESCENDING);

            billDate = (Date) query.firstRow();

            if (isNull(billDate)) {
                billDate = this.getProcessDateTime().getDate();
            }

            return billDate;
        }

        /**
         * This method will retrieve CWR Level
         * @return cwrLevel String
         */
        private String retrieveCwrLevel() {
            String cwrLevel = "";

            // Select all CWR Payment Arrangement SAs

            Query cwrPaymentArrangementSaQuery = retrieveCwrPaymentArrangementSa();
            if(cwrPaymentArrangementSaQuery.list().isEmpty()) {
                cwrLevel = PERCENT_12;
            }
            else {
                QueryResultRow cwrResult = (QueryResultRow) cwrPaymentArrangementSaQuery.firstRow();
                ServiceAgreement cwrPaymentArrangementSa = (ServiceAgreement) cwrResult.get("sa");
                // Determine if most recent CWR Payment Arrangement SA was broken
                if (isCwrPaymentArrangementSaBroken(cwrPaymentArrangementSa).isFalse()) {
                    cwrLevel = PERCENT_12;
                }
                else {
                    // Select all broken CWR Payment Arrangement SAs with CWR Char = 50
                    Query brokenCwrPaymentArrangementSaQuery = retrieveBrokenCwrPaymentArrangementSa();
                    if (brokenCwrPaymentArrangementSaQuery.list().isEmpty()) {
                        cwrLevel = PERCENT_50;
                    }
                    else {
                        QueryResultRow brokenResult = (QueryResultRow) brokenCwrPaymentArrangementSaQuery.firstRow();
                        Date startDate = (Date) brokenResult.get("startDate");
                        // Determine if start date of most recent broken CWR Payment Arrangement SA with CWR Char = 50 is greater or equal to 2 years from system date
                        if (startDate.isSameOrBefore(this.getProcessDateTime().getDate().addYears(-2))) {
                            // Determine if count of broken CWR Payment Arrangement SAs with CWR Char = 50 is greater than or equal to 3
                            if (brokenCwrPaymentArrangementSaQuery.list().size() >= 3) {
                                cwrLevel = PERCENT_80;
                            }
                            else {
                                cwrLevel = PERCENT_50;
                            }
                        }
                        else {
                            cwrLevel = PERCENT_80;
                        }
                    }
                }
            }

            return cwrLevel;
        }

        /**
         * This method will retrieve CWR Payment Arrangement SA
         * @return query Query
         */
        private Query retrieveCwrPaymentArrangementSa() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM ServiceAgreement sa, FeatureConfigurationOption fco1, FeatureConfigurationOption fco2, ServiceAgreementCharacteristic sac1 ");
            stringBuilder.append(" WHERE sa.status IN (:pendingStop, :stopped, :closed) ");
            stringBuilder.append(" AND fco1.id.workforceManagementSystem = :workforceManagementSystem ");
            stringBuilder.append(" AND fco1.id.optionType = :cisDivisionOptionType ");
            stringBuilder.append(" AND fco1.id.workforceManagementSystem = fco2.id.workforceManagementSystem ");
            stringBuilder.append(" AND fco2.id.optionType = :saTypeOptionType ");
            stringBuilder.append(" AND fco2.id.sequence = fco1.id.sequence ");
            stringBuilder.append(" AND TRIM (sa.serviceAgreementType.id.division) = TRIM (fco1.value) ");
            stringBuilder.append(" AND TRIM (sa.serviceAgreementType.id.saType) = TRIM (fco2.value) ");
            stringBuilder.append(" AND NOT EXISTS (SELECT sac.id.characteristicType ");
            stringBuilder.append("                 FROM ServiceAgreementCharacteristic sac ");
            stringBuilder.append("                 WHERE sac.id.serviceAgreement.id = sa.id ");
            stringBuilder.append("                 AND sac.id.characteristicType = :characteristicType ");
            stringBuilder.append("                 AND (sac.characteristicValue = :characteristicValue ");
            stringBuilder.append("                      OR sac.adhocCharacteristicValue = :adhocCharacteristicValue ");
            stringBuilder.append("                      OR sac.characteristicValueForeignKey1 = :characteristicValueForeignKey1))");
            stringBuilder.append(" AND sac1.id.serviceAgreement.id = sa.id ");
            stringBuilder.append(" AND sac1.id.characteristicType = :cwrPremiseCharacteristicType ");
            stringBuilder.append(" AND (sac1.characteristicValue = :premiseIdCharVal ");
            stringBuilder.append("      OR sac1.adhocCharacteristicValue = :premiseIdAdhocCharval ");
            stringBuilder.append("      OR sac1.characteristicValueForeignKey1 = :premiseIdCharValFK1)");
            stringBuilder.append(" AND sac1.id.effectiveDate = (SELECT MAX(sac2.id.effectiveDate) ");
            stringBuilder.append("                                 FROM ServiceAgreementCharacteristic sac2 ");
            stringBuilder.append("                                WHERE sac2.id.serviceAgreement.id = sa.id ");
            stringBuilder.append("                                  AND sac2.id.characteristicType = sac1.id.characteristicType ");
            stringBuilder.append("                                  AND sac2.id.effectiveDate <= :effectiveDate) ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
           
            query.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
            query.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
            query.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
            query.bindEntity("workforceManagementSystem", paymentArrangementSaTypesFeatConfig);
            query.bindStringProperty("cisDivisionOptionType", FeatureConfigurationOption.properties.optionType, 
                    CmPaymentArrangementSaTypesLookup.constants.CIS_DIVISION.getLookupValue().fetchIdFieldValue().toString());
            query.bindStringProperty("saTypeOptionType", FeatureConfigurationOption.properties.optionType, 
                    CmPaymentArrangementSaTypesLookup.constants.PAYMENT_ARRANGEMENT_SA_TYPE.getLookupValue().fetchIdFieldValue().toString());
            query.bindEntity("characteristicType", recalculatedCharType);
            query.bindStringProperty("characteristicValue", ServiceAgreementCharacteristic.properties.characteristicValue, recalculatedCharValue);
            query.bindStringProperty("adhocCharacteristicValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, recalculatedCharValue);
            query.bindStringProperty("characteristicValueForeignKey1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, recalculatedCharValue);
            query.bindEntity("cwrPremiseCharacteristicType", cwrPremiseCharType);
            if (notNull(serviceAgreement.getPremiseId())){
                charPremiseIdString = serviceAgreement.getPremiseId().getTrimmedValue();
            }

            query.bindStringProperty("premiseIdCharVal", ServiceAgreementCharacteristic.properties.characteristicValue, charPremiseIdString);
            query.bindStringProperty("premiseIdAdhocCharval", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, charPremiseIdString);
            query.bindStringProperty("premiseIdCharValFK1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, charPremiseIdString);
            query.bindDate("effectiveDate", this.getProcessDateTime().getDate());

            query.addResult("startDate", "sa.startDate");
            query.addResult("sa", "sa");

            query.orderBy("startDate", Query.DESCENDING);

            return query;
        }

        /**
         * This method will determine if CWR Payment Arrangement SA is broken
         * @param sa ServiceAgreement
         * @return isBroken Bool
         */
        private Bool isCwrPaymentArrangementSaBroken(ServiceAgreement sa) {
            Bool isBroken = Bool.FALSE;

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM ServiceAgreementCharacteristic sac ");
            stringBuilder.append(" WHERE sac.id.serviceAgreement = :serviceAgreement ");
            stringBuilder.append(" AND sac.id.characteristicType = :characteristicType ");
            stringBuilder.append(" AND (sac.characteristicValue = :characteristicValue ");
            stringBuilder.append("      OR sac.adhocCharacteristicValue = :adhocCharacteristicValue ");
            stringBuilder.append("      OR sac.characteristicValueForeignKey1 = :characteristicValueForeignKey1)");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());

            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            query.bindEntity("serviceAgreement", sa);
            query.bindEntity("characteristicType", brokenCharType);
            query.bindStringProperty("characteristicValue", ServiceAgreementCharacteristic.properties.characteristicValue, brokenCharValue);
            query.bindStringProperty("adhocCharacteristicValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, brokenCharValue);
            query.bindStringProperty("characteristicValueForeignKey1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, brokenCharValue);

            query.addResult("effectiveDate", "sac.id.effectiveDate");
            query.orderBy("effectiveDate", Query.DESCENDING);

            if (!query.list().isEmpty()) {
                isBroken = Bool.TRUE;
            }

            return isBroken;
        }

        /**
         * This method will retrieve broken CWR Payment Arrangement SA
         * @return query Query
         */
        private Query retrieveBrokenCwrPaymentArrangementSa() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM ServiceAgreement sa, FeatureConfigurationOption fco1, FeatureConfigurationOption fco2, ServiceAgreementCharacteristic sac1, ServiceAgreementCharacteristic sac2, ServiceAgreementCharacteristic sac3 ");
            stringBuilder.append(" WHERE sa.status IN (:pendingStop, :stopped, :closed) ");
            stringBuilder.append(" AND fco1.id.workforceManagementSystem = :workforceManagementSystem ");
            stringBuilder.append(" AND fco1.id.optionType = :cisDivisionOptionType ");
            stringBuilder.append(" AND fco1.id.workforceManagementSystem = fco2.id.workforceManagementSystem ");
            stringBuilder.append(" AND fco2.id.optionType = :saTypeOptionType ");
            stringBuilder.append(" AND fco2.id.sequence = fco1.id.sequence ");
            stringBuilder.append(" AND TRIM (sa.serviceAgreementType.id.division) = TRIM (fco1.value) ");
            stringBuilder.append(" AND TRIM (sa.serviceAgreementType.id.saType) = TRIM (fco2.value) ");
            stringBuilder.append(" AND NOT EXISTS (SELECT sac.id.characteristicType ");
            stringBuilder.append("                 FROM ServiceAgreementCharacteristic sac ");
            stringBuilder.append("                 WHERE sac.id.serviceAgreement.id = sa.id ");
            stringBuilder.append("                 AND sac.id.characteristicType = :characteristicType ");
            stringBuilder.append("                 AND (sac.characteristicValue = :characteristicValue ");
            stringBuilder.append("                      OR sac.adhocCharacteristicValue = :adhocCharacteristicValue ");
            stringBuilder.append("                      OR sac.characteristicValueForeignKey1 = :characteristicValueForeignKey1))");
            stringBuilder.append(" AND sac1.id.serviceAgreement.id = sa.id ");
            stringBuilder.append(" AND sac1.id.characteristicType = :brokenCharacteristicType ");
            stringBuilder.append(" AND (sac1.characteristicValue = :brokenCharacteristicValue ");
            stringBuilder.append("      OR sac1.adhocCharacteristicValue = :brokenAdhocCharacteristicValue ");
            stringBuilder.append("      OR sac1.characteristicValueForeignKey1 = :brokenCharacteristicValueForeignKey1)");
            stringBuilder.append(" AND sac2.id.serviceAgreement.id = sa.id ");
            stringBuilder.append(" AND sac2.id.characteristicType = :cwrCharacteristicType ");
            stringBuilder.append(" AND (sac2.characteristicValue = :cwrCharacteristicValue ");
            stringBuilder.append("      OR sac2.adhocCharacteristicValue = :cwrAdhocCharacteristicValue ");
            stringBuilder.append("      OR sac2.characteristicValueForeignKey1 = :cwrCharacteristicValueForeignKey1)");
            stringBuilder.append(" AND sac3.id.serviceAgreement.id = sa.id ");
            stringBuilder.append(" AND sac3.id.characteristicType = :cwrPremiseCharacteristicType ");
            stringBuilder.append(" AND (sac3.characteristicValue = :premiseIdCharVal ");
            stringBuilder.append("      OR sac3.adhocCharacteristicValue = :premiseIdAdhocCharval ");
            stringBuilder.append("      OR sac3.characteristicValueForeignKey1 = :premiseIdCharValFK1)");
            stringBuilder.append(" AND sac3.id.effectiveDate = (SELECT MAX(sac4.id.effectiveDate) ");
            stringBuilder.append("                                 FROM ServiceAgreementCharacteristic sac4 ");
            stringBuilder.append("                                WHERE sac4.id.serviceAgreement.id = sa.id ");
            stringBuilder.append("                                  AND sac4.id.characteristicType = sac3.id.characteristicType ");
            stringBuilder.append("                                  AND sac4.id.effectiveDate <= :effectiveDate) ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            query.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
            query.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
            query.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);

            query.bindEntity("workforceManagementSystem", paymentArrangementSaTypesFeatConfig);
            query.bindStringProperty("cisDivisionOptionType", FeatureConfigurationOption.properties.optionType, 
                    CmPaymentArrangementSaTypesLookup.constants.CIS_DIVISION.getLookupValue().fetchIdFieldValue().toString());
            query.bindStringProperty("saTypeOptionType", FeatureConfigurationOption.properties.optionType, 
                    CmPaymentArrangementSaTypesLookup.constants.PAYMENT_ARRANGEMENT_SA_TYPE.getLookupValue().fetchIdFieldValue().toString());

            query.bindEntity("characteristicType", recalculatedCharType);
            query.bindStringProperty("characteristicValue", ServiceAgreementCharacteristic.properties.characteristicValue, recalculatedCharValue);
            query.bindStringProperty("adhocCharacteristicValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, recalculatedCharValue);
            query.bindStringProperty("characteristicValueForeignKey1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, recalculatedCharValue);

            query.bindEntity("brokenCharacteristicType", brokenCharType);
            query.bindStringProperty("brokenCharacteristicValue", ServiceAgreementCharacteristic.properties.characteristicValue, brokenCharValue);
            query.bindStringProperty("brokenAdhocCharacteristicValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, brokenCharValue);
            query.bindStringProperty("brokenCharacteristicValueForeignKey1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, brokenCharValue);

            query.bindEntity("cwrCharacteristicType", cwrCharType);
            query.bindStringProperty("cwrCharacteristicValue", ServiceAgreementCharacteristic.properties.characteristicValue, cwrCharValue);
            query.bindStringProperty("cwrAdhocCharacteristicValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, cwrCharValue);
            query.bindStringProperty("cwrCharacteristicValueForeignKey1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, cwrCharValue);
            query.bindEntity("cwrPremiseCharacteristicType", cwrPremiseCharType);

            if (notNull(serviceAgreement.getPremiseId())){
                charPremiseIdString = serviceAgreement.getPremiseId().getTrimmedValue();
            }

            query.bindStringProperty("premiseIdCharVal", ServiceAgreementCharacteristic.properties.characteristicValue, charPremiseIdString);
            query.bindStringProperty("premiseIdAdhocCharval", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, charPremiseIdString);
            query.bindStringProperty("premiseIdCharValFK1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, charPremiseIdString);
            query.bindDate("effectiveDate", this.getProcessDateTime().getDate());


            query.addResult("startDate", "sa.startDate");
            query.addResult("sa", "sa");

            query.orderBy("startDate", Query.DESCENDING);

            return query;
        }

        /**
         * This method will retrieve CWR Down Payment
         * @param cwrLevel String
         * @param totalSaArrears BigDecimal
         * @param monthlyBudget BigDecimal
         * @param totalDiversion BigDecimal
         * @return cwrDownPayment BigDecimal
         */ 
        private BigDecimal retrieveCwrDownPayment(String cwrLevel, BigDecimal totalSaArrears, BigDecimal monthlyBudget, BigDecimal totalDiversion) {
            BigDecimal cwrDownPayment = BigDecimal.ZERO;

            if (cwrLevel.equalsIgnoreCase(PERCENT_12)) {
                cwrDownPayment = BigDecimal.valueOf(Double.parseDouble("12")).multiply(monthlyBudget)
                        .add(totalSaArrears).multiply(BigDecimal.valueOf(Double.parseDouble("0.12"))).add(totalDiversion);
            }
            else if (cwrLevel.equalsIgnoreCase(PERCENT_50)) {
                BigDecimal temp1 = totalDiversion.add(BigDecimal.valueOf(Double.parseDouble("500")));
                BigDecimal temp2 = (BigDecimal.valueOf(Double.parseDouble("0.50")).multiply(totalSaArrears)).add(totalDiversion);

                if(temp1.compareTo(temp2) > 0) {
                    cwrDownPayment = temp2;
                }
                else {
                    cwrDownPayment = temp1;
                }
            }
            else if (cwrLevel.equalsIgnoreCase(PERCENT_80)) {
                cwrDownPayment = (BigDecimal.valueOf(Double.parseDouble("0.80")).multiply(totalSaArrears)).add(totalDiversion);
            }

            return cwrDownPayment;

        }

        /**
         * This method will retrieve total diversion
         * @return totalDiversion Money
         */
        private Money retrieveTotalDiversion() {        
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM FeatureConfigurationOption fco1, FeatureConfigurationOption fco2, ServiceAgreement sa, AccountPerson ap, FinancialTransaction ft ");
            stringBuilder.append(" WHERE fco1.id.workforceManagementSystem = :workforceManagementSystem ");
            stringBuilder.append(" AND fco1.id.optionType = :cisDivisionOptionType ");
            stringBuilder.append(" AND fco1.id.workforceManagementSystem = fco2.id.workforceManagementSystem ");
            stringBuilder.append(" AND fco2.id.optionType = :saTypeOptionType ");
            stringBuilder.append(" AND fco2.id.sequence = fco1.id.sequence ");
            stringBuilder.append(" AND TRIM (fco1.value) = TRIM (sa.serviceAgreementType.id.division) ");
            stringBuilder.append(" AND TRIM (fco2.value) = TRIM (sa.serviceAgreementType.id.saType) ");
            stringBuilder.append(" AND sa.account = ap.id.account ");
            stringBuilder.append(" AND ap.id.person = :person ");
            stringBuilder.append(" AND ap.isFinanciallyResponsible = :isFinanciallyResponsible ");
            stringBuilder.append(" AND ft.serviceAgreement.id = sa.id ");
            stringBuilder.append(" AND ft.isRedundant = :isRedundant ");
            stringBuilder.append(" AND ft.shouldShowOnBill = :shouldShowOnBill ");
            stringBuilder.append(" AND ft.isFrozen = :isFrozen ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            query.bindEntity("workforceManagementSystem", diversionSaTypesFeatConfig);
            query.bindStringProperty("cisDivisionOptionType", FeatureConfigurationOption.properties.optionType, 
                    CmDiversionSaTypesLookup.constants.CIS_DIVISION.getLookupValue().fetchIdFieldValue().toString());
            query.bindStringProperty("saTypeOptionType", FeatureConfigurationOption.properties.optionType, 
                    CmDiversionSaTypesLookup.constants.DIVERSION_SA_TYPE.getLookupValue().fetchIdFieldValue().toString());

            query.bindEntity("person", retrieveAccountMainPerson(serviceAgreement.getAccount()));
            query.bindBoolean("isRedundant", Bool.FALSE);
            query.bindBoolean("isFinanciallyResponsible", Bool.TRUE);
            query.bindBoolean("shouldShowOnBill", Bool.TRUE);
            query.bindBoolean("isFrozen", Bool.TRUE);

            query.addResult("currentAmount", "SUM(ft.currentAmount)");

            return (Money) query.firstRow();
        }

        /**
         * This method will retrieve account main person
         * @param account Account
         * @return Person
         */
        private Person retrieveAccountMainPerson(Account account) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM AccountPerson ap ");
            stringBuilder.append(" WHERE ap.id.account = :account ");
            stringBuilder.append(" AND ap.isMainCustomer = :isMainCustomer ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            query.bindEntity("account", account);
            query.bindBoolean("isMainCustomer", Bool.TRUE);
            query.addResult("person", "ap.id.person");

            return (Person) query.firstRow();   
        }

        /**
         * This method will retrieve standard amount
         * @return BigDecimal
         */
        private BigDecimal retrieveStandardAmount() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM FinancialTransaction ft, Bill b ");
            stringBuilder.append(" WHERE ft.serviceAgreement = :serviceAgreement ");
            stringBuilder.append(" AND ft.isRedundant = :isRedundant ");
            stringBuilder.append(" AND ft.isFrozen = :isFrozen ");
            stringBuilder.append(" AND ft.billId = b.id ");
            stringBuilder.append(" AND b.dueDate >= :dueDate ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(),getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            query.bindEntity("serviceAgreement", serviceAgreement);
            query.bindBoolean("isRedundant", Bool.FALSE);
            query.bindBoolean("isFrozen", Bool.TRUE);
            query.bindDate("dueDate", this.getProcessDateTime().getDate());

            query.addResult("currentAmount", "SUM(ft.currentAmount)");

            Money currentAmount = (Money)query.firstRow();

            return serviceAgreement.getCurrentBalance().getAmount().subtract(currentAmount.getAmount());

        }

        /**
         * This method will compute for the monthly payment arrangement
         * @param totalSaArrears BigDecimal
         * @param totalDiversion BigDecimal
         * @param downPayment BigDecimal
         * @param months BigDecimal
         * @return monthlyPaymentArrangement BigDecimal
         */
        private BigDecimal computeMonthlyPaymentArrangement(BigDecimal totalSaArrears, BigDecimal totalDiversion, BigDecimal downPayment, BigDecimal months) {
            BigDecimal monthlyPaymentArrangement = (totalSaArrears.add(totalDiversion).add(retrievePaymentArrangemtSaPayoffBalance().getAmount()).subtract(downPayment)).divide(months);

            return monthlyPaymentArrangement;
        }

        /**
         * This method will retrieve the sum of payoff balance of any Payment Arrangement SAs associated with the Service Agreement
         * @return Money
         */
        private Money retrievePaymentArrangemtSaPayoffBalance() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" FROM FeatureConfigurationOption fco1, FeatureConfigurationOption fco2, ServiceAgreement sa, Adjustment a, FinancialTransaction ft ");
            stringBuilder.append(" WHERE fco1.id.workforceManagementSystem = :workforceManagementSystem ");
            stringBuilder.append(" AND fco1.id.optionType = :cisDivisionOptionType ");
            stringBuilder.append(" AND fco2.id.workforceManagementSystem = fco1.id.workforceManagementSystem ");
            stringBuilder.append(" AND fco2.id.optionType = :saTypeOptionType ");
            stringBuilder.append(" AND fco2.id.sequence = fco1.id.sequence ");
            stringBuilder.append(" AND TRIM (fco1.value) = TRIM (sa.serviceAgreementType.id.division) ");
            stringBuilder.append(" AND TRIM (fco2.value) = TRIM (sa.serviceAgreementType.id.saType) ");
            stringBuilder.append(" AND sa.id = a.serviceAgreement.id ");
            stringBuilder.append(" AND a.adjustmentType = :adjustmentType ");
            stringBuilder.append(" AND a.transferAdjustmentId IN (SELECT adj.id ");
            stringBuilder.append("                               FROM Adjustment adj ");
            stringBuilder.append("                               WHERE adj.adjustmentType = a.adjustmentType ");
            stringBuilder.append("                               AND adj.adjustmentStatus = :frozen ");
            stringBuilder.append("                               AND adj.serviceAgreement = :serviceAgreement) ");
            stringBuilder.append(" AND ft.serviceAgreement.id = sa.id ");
            stringBuilder.append(" AND ft.shouldShowOnBill = :shouldShowOnBill ");
            stringBuilder.append(" AND ft.isRedundant = :isRedundant ");
            stringBuilder.append(" AND ft.isFrozen = :isFrozen ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            query.bindEntity("workforceManagementSystem", paymentArrangementSaTypesFeatConfig);
            query.bindStringProperty("cisDivisionOptionType", FeatureConfigurationOption.properties.optionType, 
                    CmPaymentArrangementSaTypesLookup.constants.CIS_DIVISION.getLookupValue().fetchIdFieldValue().toString());
            query.bindStringProperty("saTypeOptionType", FeatureConfigurationOption.properties.optionType, 
                    CmPaymentArrangementSaTypesLookup.constants.PAYMENT_ARRANGEMENT_SA_TYPE.getLookupValue().fetchIdFieldValue().toString());

            query.bindEntity("adjustmentType", transferAdjustmentType);
            query.bindEntity("serviceAgreement", serviceAgreement);
            query.bindBoolean("shouldShowOnBill", Bool.TRUE);
            query.bindBoolean("isRedundant", Bool.FALSE);
            query.bindBoolean("isFrozen", Bool.TRUE);
            query.bindLookup("frozen", AdjustmentStatusLookup.constants.FROZEN);

            query.addResult("currentAmount", "SUM(ft.payoffAmount)");

            return (Money) query.firstRow();
        }
        // JPunza - 2013-10-11 - End
        
        // JPunza - 2013-10-22 - Start 
        /**
         * This method creates To Do Entry
         * @param accountStr - Account Id
         */
        private void createToDo(String accountStr) {

            ToDoType toDoType = getParameters().getTO_DO_TYPE();

            ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
            ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();
                        
            toDoEntryDTO.setCreationDateTime(getProcessDateTime());
            toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
            toDoEntryDTO.setToDoTypeId(toDoType.getId());
            
            toDoEntryDTO.setBatchControlId(getBatchControlId());
            toDoEntryDTO.setBatchNumber(getBatchNumber());

            toDoEntryDTO.setMessageId(new Message_Id(
                    new MessageCategory_Id(BigInteger.valueOf(CustomMessagesMDC.MESSAGE_CATEGORY)), 
                    BigInteger.valueOf(CustomMessagesMDC.NP0055_BILL_CYCLE_MISSING)));
            
            toDoCreator.setToDoDTO(toDoEntryDTO);
            
            // Message Parameter
            toDoCreator.addMessageParameter(accountStr);
                            
            // Sort Keys
            for (ToDoSortKeyType sortKeyType : toDoType.getSortKeyTypes()) {
                
                BigInteger sequence = sortKeyType.fetchIdSequence();
                
                if (sequence.compareTo(BigInteger.valueOf(1)) == 0) { 
                    toDoCreator.addSortKeyValue(sortKeyType, getBatchControlId().getTrimmedValue());                    
                }
                else if (sequence.compareTo(BigInteger.valueOf(2)) == 0) {
                    toDoCreator.addSortKeyValue(sortKeyType, getBatchNumber().toString());                                
                }
                else if (sequence.compareTo(BigInteger.valueOf(3)) == 0) { 
                    toDoCreator.addSortKeyValue(sortKeyType, getBatchRerunNumber().toString());                    
                }
            }
                
            // Drill Keys
            for (ToDoDrillKeyType drillKeyType : toDoType.getDrillKeyTypes()) {
                
                BigInteger sequence = drillKeyType.fetchIdSequence();
                
                if (sequence.compareTo(BigInteger.valueOf(1)) == 0) { 
                    toDoCreator.addDrillKeyValue(drillKeyType, getBatchControlId().getTrimmedValue());                    
                }
                else if (sequence.compareTo(BigInteger.valueOf(2)) == 0) {
                    toDoCreator.addDrillKeyValue(drillKeyType, getBatchNumber().toString());                                
                }
                else if (sequence.compareTo(BigInteger.valueOf(3)) == 0) { 
                    toDoCreator.addDrillKeyValue(drillKeyType, getBatchRerunNumber().toString());                    
                }
            }
                       
            toDoCreator.create();
        }
        // JPunza - 2013-10-22 - End
    }
}
