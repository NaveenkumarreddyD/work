/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm will be used to cancel stopped Dollar Help SA 
 * if no FT exists.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2019-09-16   RKing       Initial Version.                   
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.preBillCompletion;


import java.util.Iterator;

import com.splwg.base.api.Query;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.domain.admin.billCycle.entity.BillCycle;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.preBillCompletion.SaTypePreBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.domain.common.customBusinessComponent.CmDollarHelpReversalRoutine;


/**
 * @author RKing
 *
 * @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentCancelReason, name = adjCancelReason, required = true, type = entity)
 * 										 , @AlgorithmSoftParameter (entityName = paymentCancelReason, name = payCancelReason, required = true, type = entity)
 * 										 , @AlgorithmSoftParameter (entityName = billCancelReason, name = billCancelReason, required = true, type = entity)
 *            })
 */

public class CmCancelDollarHelpSAPreBillCompAlgComp_Impl extends CmCancelDollarHelpSAPreBillCompAlgComp_Gen implements SaTypePreBillCompletionAlgorithmSpot {
	
	// Hard parameters
	private ServiceAgreementType sat;
	private Bill bill;
	

	@Override
	public void invoke() {
		
		Query<BillSegment> bsegQry = createQuery("from BillSegment bs "
				+ " where bs.billId = :billId "
				+ "		and bs.billSegmentStatus in (:frozen,:freezeball) ", "bsegQry");
		
		bsegQry.bindId("billId", bill.getId());
		bsegQry.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
		bsegQry.bindLookup("freezeball", BillSegmentStatusLookup.constants.FREEZABLE);
				
		Iterator<BillSegment> iter = bsegQry.iterate();
		while(iter.hasNext()) {
			
			BillSegment bs = iter.next();
			
			if(bs.getServiceAgreement().getServiceAgreementType().equals(sat)) {
				
				ServiceAgreement sa = bs.getServiceAgreement();
			
				// If SA is stoppped and start date = end date, this means it went through customer request to stop contribution.
				if(sa.getStatus().isStopped() && sa.getStartDate().equals(sa.getEndDate())) {
				
					// Delete freezable bseg.
					if(bs.getBillSegmentStatus().isFreezable()) {
						bs.delete(Bool.TRUE);
					}
		
					// Cancel frozen bseg, other frozen FTs and SA.
					CmDollarHelpReversalRoutine rev = CmDollarHelpReversalRoutine.Factory.newInstance();
					
					rev.setAdjustmentCancelReason(getAdjCancelReason());
					rev.setPaymentCancelReason(getPayCancelReason());
					rev.setBillCancelReason(getBillCancelReason());
					rev.setServiceAgreement(sa);
					rev.execute();
				}
			}
		}
	}

	@Override
	public Bool getShouldSkipRemainingAlgorithms() {
		return Bool.TRUE;
	}

	@Override
	public void setBill(Bill arg0) {
		bill = arg0;
	}

	@Override
	public void setBillCycle(BillCycle arg0) {
	}

	@Override
	public void setEndDate(Date arg0) {
	}

	@Override
	public void setServiceAgreementType(ServiceAgreementType arg0) {
		sat = arg0;
	}

	@Override
	public void setStartDate(Date arg0) {
	}
}
