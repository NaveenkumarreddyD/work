/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Custom Postal Bill Routing Extract Batch.
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Re-coded for performance issue.
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractPrinterKeyRecord 
		extends ColumnDelimitedRecord{	
	
	// Constants
	// Printer Keys (CMCBXBKP) - Constants
	public static final String PRINTER_KEY_EXTRACT_INFO = "0010";

	public static final String PRINTER_KEY_BILL = "0100";

	public static final String PRINTER_KEY_PA_RECORD = "0150";

	public static final String PRINTER_KEY_START_CURRDC = "0200";
	public static final String PRINTER_KEY_DTL_CURRDC = "0300";

	public static final String PRINTER_KEY_DTL_CANCHG = "0310";
	public static final String PRINTER_KEY_DTL_OTHCHG = "0320";

	public static final String PRINTER_KEY_END_CURRDC = "0400";

	public static final String PRINTER_KEY_START_PAYDTL = "0500";
	public static final String PRINTER_KEY_DTL_PAYDTL = "0600";
	public static final String PRINTER_KEY_END_PAYDTL = "0700";

	public static final String PRINTER_KEY_START_PREMISE = "0800";
	public static final String PRINTER_KEY_DTL_PREMISE = "0900";

	public static final String PRINTER_KEY_START_SA = "1000";
	public static final String PRINTER_KEY_DTL_SA = "1100";

	public static final String PRINTER_KEY_START_BSEG = "1200";
	public static final String PRINTER_KEY_DTL_BSEG = "1300";

	public static final String PRINTER_KEY_START_CALCHDR = "1400";
	public static final String PRINTER_KEY_DTL_CALCHDR = "1500";

	public static final String PRINTER_KEY_START_CALCLN = "1600";
	public static final String PRINTER_KEY_DTL_CALCLN = "1700";
	public static final String PRINTER_KEY_END_CALCLN = "1800";

	public static final String PRINTER_KEY_END_CALCHDR = "1900";

	public static final String PRINTER_KEY_START_BSEGRD = "2000";
	public static final String PRINTER_KEY_DTL_BSEGRD = "2100";
	public static final String PRINTER_KEY_END_BSEGRD = "2200";

	public static final String PRINTER_KEY_START_BSEGSQ = "2300";
	public static final String PRINTER_KEY_DTL_BSEGSQ = "2400";
	public static final String PRINTER_KEY_END_BSEGSQ = "2500";

	public static final String PRINTER_KEY_START_BSEGITM = "2600";
	public static final String PRINTER_KEY_DTL_BSEGITM = "2700";
	public static final String PRINTER_KEY_END_BSEGITM = "2800";

	public static final String PRINTER_KEY_START_BSEGMSG= "2820";
	public static final String PRINTER_KEY_DTL_BSEGMSG = "2840";
	public static final String PRINTER_KEY_END_BSEGMSG = "2860";

	public static final String PRINTER_KEY_END_BSEG = "2900";

	public static final String PRINTER_KEY_START_HISTGRM = "3000";
	public static final String PRINTER_KEY_DTL_HISTGRM = "3100";
	public static final String PRINTER_KEY_END_HISTGRM = "3200";

	public static final String PRINTER_KEY_START_ADJSA = "3300";
	public static final String PRINTER_KEY_DTL_ADJSA = "3400";
	public static final String PRINTER_KEY_END_ADJSA = "3500";

	public static final String PRINTER_KEY_END_SA = "3600";
	public static final String PRINTER_KEY_END_PREMISE = "3700";

	public static final String PRINTER_KEY_START_BILLMSG = "3800";
	public static final String PRINTER_KEY_DTL_BILLMSG = "3900";
	public static final String PRINTER_KEY_END_BILLMSG = "4000";

	public static final String PRINTER_KEY_END_BILL = "9999";
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractPrinterKeyRecord() {
		super(1);
		// Initialize all fields as blank/space
		this.setPrinterKey(" ");
	}
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * Printer Key
	 */
	public void setPrinterKey(String value) {
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
}