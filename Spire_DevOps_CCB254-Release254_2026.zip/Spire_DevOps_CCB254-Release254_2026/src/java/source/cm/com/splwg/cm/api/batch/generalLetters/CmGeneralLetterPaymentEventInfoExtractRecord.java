/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Payment Event Information Extract Record                                                               
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                          
 * 2020-04-01  JHERNA      SA-322461. Initial version                 
 *                                                                
 *******************************************************************************
 */

package com.splwg.cm.api.batch.generalLetters;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmGeneralLetterPaymentEventInfoExtractRecord extends ColumnDelimitedRecord {
    
    // Mailing Information
    private static final String PAY_EVT_PRINT_KEY = "1120";
    private static final String MAIL_GRP = "20";
    private static final String BLANK = "  ";
    private static final String EMPTY_STR = "";
    
    public CmGeneralLetterPaymentEventInfoExtractRecord() {
        super(17);
        defaultPrintKey();
    }

    /* EXTRACT COMMON SECTIONS */
    private void defaultPrintKey() {
        this.rightPadColumn(1, 4, formatString(PAY_EVT_PRINT_KEY, 4));
    }
    
    public void setSortKeyLetterTemplateCode(String letterTemplateCode) {
        this.rightPadColumn(2, 12, formatString(letterTemplateCode, 12));
    }
    
    public void setSortKeyCcId(String ccId) {
        this.rightPadColumn(3, 10, formatString(ccId, 10));
        setSortKeyCcRecordGroup();
        setSortKeyCAndCRecordGroup();
    }
    
    private void setSortKeyCcRecordGroup() {
        this.rightPadColumn(4, 2, MAIL_GRP);
    }
    
    private void setSortKeyCAndCRecordGroup() {
        this.rightPadColumn(5, 2, BLANK);
    }
    
    public void setMailingKey(String mailingKey) {
        this.rightPadColumn(6, 12, formatString(mailingKey, 12));
        setFiller3Spaces();
    }
    
    private void setFiller3Spaces() {
        this.rightPadColumn(7, 3, " ");
    }
    
    /* EXTRACT DETAILS SECTION */       
    public void setFKCharType(String fkCharType) {    	
    	this.rightPadColumn(8, 8, formatString(fkCharType, 8));
    }
          
    public void setCharTypeDescr(String charTypeDescr) {    	
    	this.rightPadColumn(9, 60, formatString(charTypeDescr, 60));
    }  
    
    public void setPayEventId(String payEventID) {    	
    	this.rightPadColumn(10, 12, formatString(payEventID, 12));
    }  
  
    public void setPaymentId(String payID) {    	
    	this.rightPadColumn(11, 12, formatString(payID, 12));
    }
    
    public void setAccountId(String accountID) {    	
    	this.rightPadColumn(12, 10, formatString(accountID, 10));
    }
    
    public void setPayDate(String payDate) {    	
    	this.rightPadColumn(13, 10, formatString(payDate, 10));
    }
    
    public void setPayAmt(BigDecimal payAmt) {    	
    	this.rightPadColumn(14, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(payAmt));
    }
    
    public void setCancelReasonCd(String cancelReasonCd) {    	
    	this.rightPadColumn(15, 4, formatString(cancelReasonCd, 4));
    }
    
    public void setCancelReasonDescr(String cancelReasonDescr) {    	
    	this.rightPadColumn(16, 60, formatString(cancelReasonDescr, 60));
    	setFillerEndSpaces();
    }
    
    private void setFillerEndSpaces() {
        this.rightPadColumn(17, 1775, BLANK);
    }
    
    /**
     * Returns "" if text is null;
     * Truncates text if length exceed fieldLength;
     * @param text String variable to be formatted
     * @param fieldLength Length of Field
     * @return formatted text
     */
    private String formatString(String text, int fieldLength) {
        if(text == null) {
            text = EMPTY_STR;
        }
        else {
            text = text.trim();
            if(text.length() > fieldLength) {
                text = text.substring(0, fieldLength);
            }
        }
        return text;
    }
}
