/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This deposit recommendation algorithm calculates the amount for 
 * residential customers using the following steps: 
 *
 * 1) Determine if the customer requires an Equifax credit check. If the 
 * customer is in good standing, no deposit is recommended.
 * 2) The sum of the Premise's past year's two highest bills is considered 
 * the maximum deposit a customer can be charged. The customer should never 
 * be assessed a Deposit higher than their maximum deposit.
 * 3) If there is not enough history on the Premise, the default Deposit 
 * Amount defined on the Customer Portal Configuration is recommended as 
 * the Deposit amount.
 * 4) If the customer has been disconnected three times or more, recommend 
 * the maximum deposit amount.
 * 5) Increase the default Deposit Amount by the parameter Increase Required 
 * per Disconnection multiplied by the number of times the customer has been 
 * disconnected at the Premise.
 * This algorithm must be used on Deposit Classes with premise-oriented 
 * service agreements.
 * The system will not be able to produce a recommended deposit amount if the 
 * Equifax credit check fails (ex. Equifax server is unavailable; Customer 
 * exists in CC&B as a Business; Customer is a minor; etc).
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2021-04-30   JMeden      CCB021.05. Initial Version.  
 * 2021-06-22   DLampa      Updated to address issues with computing 
 *                          the recommended deposit.                  
 * 2021-07-19   GCrisp      CCB021.Issue1. Updates on retrieval of DNP FAs.
 *                          Updates on recommendation amount logic.
 * 2021-07-30   DLampa      CCB021.Issue2. Address issues from Kiran's review.   
 * 2022-01-18   NMendo      B-20072. Active Customer without Deposit cannot 
 *                          be charged Deposit when moving to new address.
 * 2022-02-02   DLampa      B.20072. Update to remove checking of the 
 *                          shouldAlwaysCalculateRecommendation switch.
 * 2022-08-19	EQuint		B-23457. Make sure only whole dollar amounts are
 * 							quoted with Deposits in CCB through Gold Lock
 * 2024-10-03	CAtilano	E-09284 - INC0035910 - MYA and IVR quoted Max Deposit 1st time disconnected.
 * 2025-02-14   DLampa      E-09991. Update to ignore the credit rating check 
 *                          if there has been a disconnection for non-payment 
 * 2025-05-22   DLampa      B-37557. Updated to multiply the increase required 
 *                          per disconnect by the number of disconnects   
 * *************************************************************************  
 */
package com.splwg.cm.domain.admin.depositClass.algorithm.recommendation;

import java.math.BigInteger;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.currency.Currency_Id;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.CustomerEventLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointStatusLookup;
import com.splwg.ccb.api.lookup.SpecialRoleLookup;
import com.splwg.ccb.domain.admin.depositClass.algorithm.recommendation.DepositClassDepositRecommendationAlgorithmSpot;
import com.splwg.ccb.domain.admin.depositClass.algorithm.recommendation.DepositRecommendationResult;
import com.splwg.ccb.domain.admin.depositClass.entity.DepositClass;
import com.splwg.ccb.domain.admin.fieldActivityTypeProfile.entity.FieldActivityTypeProfile_Id;
import com.splwg.ccb.domain.admin.frequency.entity.Frequency;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementTypeStartOption.entity.ServiceAgreementTypeStartOption;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.sicCode.entity.SicCode;
import com.splwg.ccb.domain.common.installation.entity.CcbInstallation_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.domain.common.customBusinessComponent.CmDepositEquifaxCreditCheck;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author OGC03758
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = serviceQuantityIdentifier, name = numberOfBillPeriodDaysSQI, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = frequency, name = freqUsedDetermineValidity, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = minNumPremBillSegAssessMaxDep, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = increaseRequiredPerDiscon, required = true, type = decimal)})
 */
public class CmIncreaseDepositCutNonPaymentAlgComp_Impl extends
        CmIncreaseDepositCutNonPaymentAlgComp_Gen implements
        DepositClassDepositRecommendationAlgorithmSpot {

    //Hard Parameters
    private Account account;
    private DepositClass depositClass;
    private Bool isGoodCustomer;
    private DepositRecommendationResult depositRecommendationResult;
    private Money recommendationAmount = null;;
    private Premise premise;
    private Money recurringChargeAmount;
    private ServiceAgreementType saType;
    private ServiceAgreementTypeStartOption saTypeStartOption;
    private Bool shouldAlwaysCalculateRecommendation;
    private SicCode sicCode;
    private Date startDate;
    private Money totalAmountToBill;
    
    //Soft Parameters
    private ServiceQuantityIdentifier numberOfBillPeriodDaysSQI;
    private Frequency freqUsedDetermineValidity;
    private BigInteger minNumPremBillSegAssessMaxDep;
    private BigDecimal increaseRequiredPerDiscon;
    
    //Other Variables
    private static final String CUST_PORTAL_CONFIG = "CM-CustomerPortalConfiguration";
    private static final String SERVICE_TASK_TYPE = "serviceTaskType";
    private static final String CUST_PORTAL_SERVICE_TASK_TYPE = "CUSTPRTL-CONFIG";
    private static final String RECONNECT_DETAILS_GRP = "reconnectDetails";
    private static final String STOPPED_SA_RANGE = "stoppedSaRange";
    private static final String DEPOSIT_AMT = "depositAmount";
    private static final String CCB_INSTALLATION = "11111";
    private static final String FA_TYPE_PROF_MTR = "MTR";
    
    private Money depositAmount = null;
    private BigInteger stoppedSARange = null;
    private Money maxDepositAmount = null;
    private Date saEndDate = null;
    private Currency_Id currencyId= null;
    // 2021-06-22 - Start Add
    private Money depositOnHandAmount = null;
    private Bool isBillingHistorySufficient = Bool.TRUE;
    private Bool doesActiveDepositExist = Bool.FALSE;
    // 2021-06-22 - End Add
    // 2021-07-30 - Start Add
    private Premise_Id latestPremiseId = null;
    // 2021-07-30 - End Add

    // Debug logger
    private Logger logger = LoggerFactory.getLogger(getClass());    
    
    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        numberOfBillPeriodDaysSQI = getNumberOfBillPeriodDaysSQI();
        freqUsedDetermineValidity = getFreqUsedDetermineValidity();
        minNumPremBillSegAssessMaxDep = getMinNumPremBillSegAssessMaxDep();
        increaseRequiredPerDiscon = getIncreaseRequiredPerDiscon();
        
        //Check if the value is positive number
        if(minNumPremBillSegAssessMaxDep.compareTo(BigInteger.ZERO) < 0){
            addError(CustomMessageRepositorySpireOne.CCB021_05_MinimumPremBillSegAssessMaxDep(minNumPremBillSegAssessMaxDep.toString()));
        }
        
        //Check if the decimal is 2 places only
        String[] splitter = increaseRequiredPerDiscon.toString().split("\\.");
        int decimalLength = splitter[1].length();  

        if (decimalLength != 2 || increaseRequiredPerDiscon.compareTo(BigDecimal.ZERO) < 0 ){
            addError(CustomMessageRepositorySpireOne.CCB021_04_IncreaseRequiredPerDisconnect(increaseRequiredPerDiscon.toString()));
        }
    }

    @Override
    public DepositClass getDepositClass() {
        return depositClass;
    }

    @Override
    public Bool getIsGoodCustomer() {
        return isGoodCustomer;
    }

    @Override
    public DepositRecommendationResult getRecommendationResult() {
        return depositRecommendationResult;
    }

    @Override
    public Money getRecommendedAmount() {
        return recommendationAmount;
    }

    @Override
    public void setAccount(Account arg0) {
        account = arg0;
    }

    @Override
    public void setDepositClass(DepositClass arg0) {
        depositClass = arg0;
    }

    @Override
    public void setPremise(Premise arg0) {
        premise = arg0;
    }

    @Override
    public void setRecurringChargeAmount(Money arg0) {
        recurringChargeAmount = arg0;
    }

    @Override
    public void setServiceAgreementType(ServiceAgreementType arg0) {
        saType = arg0;
    }

    @Override
    public void setServiceAgreementTypeStartOption(
            ServiceAgreementTypeStartOption arg0) {
        saTypeStartOption = arg0;
    }

    @Override
    public void setShouldAlwaysCalculateRecommendation(Bool arg0) {
        shouldAlwaysCalculateRecommendation = arg0;
    }

    @Override
    public void setSicCode(SicCode arg0) {
        sicCode = arg0;
    }

    @Override
    public void setStartDate(Date arg0) {
        startDate = arg0;
    }

    @Override
    public void setTotalAmountToBill(Money arg0) {
        totalAmountToBill = arg0;
    }
    
    /**
     * This method will get the Deposit AMount and Stopped SA Range
     * From the Customer Portal Config Service Task under the
     * Reconnect Details Group
     */
    private void getDepositAmtAndStoppedSARangeFromCustPortalConfig(){
        BusinessObjectInstance boInstance = BusinessObjectInstance.create(CUST_PORTAL_CONFIG);
        boInstance.set(SERVICE_TASK_TYPE, CUST_PORTAL_SERVICE_TASK_TYPE);
        boInstance = BusinessObjectDispatcher.read(boInstance);

        COTSInstanceNode reconPriorToFinalBill = boInstance.getGroup(RECONNECT_DETAILS_GRP);
        depositAmount = reconPriorToFinalBill.getMoney(DEPOSIT_AMT);
        stoppedSARange = reconPriorToFinalBill.getNumber(STOPPED_SA_RANGE).toBigInteger();
    }
    
    /**
     * This method will get the Max Deposit Amount (1st and 2nd Highest
     * Bill Segment Payoff Amount) and the Service AGreement End Date
     */
    private void getMaxDepositAmtAndSAEndDate(){
        StringBuilder strSql = new StringBuilder(); 
        // 2021-06-22 - Start Change
        //strSql.append(" WITH CM_SA_STOPPED AS (SELECT SA1.SA_ID, SA1.END_DT ");
        strSql.append(" WITH CM_SA_STOPPED AS (SELECT SA1.SA_ID, NVL(SA1.END_DT, :processDate) AS END_DT ");
        // 2021-06-22 - End Change
        strSql.append(" FROM CI_BSEG BS1, CI_SA SA1 ");
        strSql.append(" WHERE BS1.PREM_ID = :premId ");
        strSql.append(" AND BS1.START_DT = ( SELECT MAX(BS2.START_DT) ");
        strSql.append(                     " FROM CI_BSEG BS2 ");
        strSql.append(                     " WHERE BS1.PREM_ID = BS2.PREM_ID) ");
        // 2024-10-03 Start Change	E-09284			
        strSql.append(" AND BS1.BSEG_STAT_FLG = :frozenBSStatus ");
        // 2024-10-03 End Change	E-09284
        strSql.append(" AND BS1.SA_ID = SA1.SA_ID) ");
        
        strSql.append(" SELECT FT.TOT_AMT, SS.END_DT ");
        strSql.append(" FROM CI_BSEG BS, CI_SA SA, CM_SA_STOPPED SS, CI_BSEG_SQ BQ, CI_FT FT ");
        strSql.append(" WHERE BS.PREM_ID = :premId ");
        strSql.append(" AND BS.BSEG_STAT_FLG = :frozenBSStatus ");
        strSql.append(" AND SA.SA_ID = BS.SA_ID ");
        strSql.append(" AND SA.SA_ID = SS.SA_ID ");
        strSql.append(" AND BS.START_DT BETWEEN ADD_MONTHS( SS.END_DT, -(:saStoppedRange) ) AND SS.END_DT ");
        strSql.append(" AND BS.BSEG_ID = BQ.BSEG_ID ");
        strSql.append(" AND BQ.INIT_SQ BETWEEN (30 - :freqMinOffsetDays) AND (30 + :freqMaxOffsetDays) ");
        strSql.append(" AND BQ.SQI_CD = :sqiDayBp ");
        strSql.append(" AND BS.BSEG_ID = FT.SIBLING_ID ");
        strSql.append(" ORDER BY  FT.TOT_AMT DESC ");
        
        PreparedStatement getBillSegPayOffAmount = createPreparedStatement(strSql.toString(), getClass().getName());
        getBillSegPayOffAmount.bindId("sqiDayBp",numberOfBillPeriodDaysSQI.getId());
        // 2021-07-30 - Start Change
        //getBillSegPayOffAmount.bindId("premId", premise.getId());
        getBillSegPayOffAmount.bindId("premId", latestPremiseId);
        // 2021-07-30 - End Change        
        getBillSegPayOffAmount.bindLookup("frozenBSStatus", BillSegmentStatusLookup.constants.FROZEN);
        getBillSegPayOffAmount.bindBigInteger("saStoppedRange", stoppedSARange);
        getBillSegPayOffAmount.bindBigInteger("freqMinOffsetDays", freqUsedDetermineValidity.getOffsetForMinimumDays());
        getBillSegPayOffAmount.bindBigInteger("freqMaxOffsetDays", freqUsedDetermineValidity.getOffsetForMaximumDays());
        // 2021-06-22 - Start Add
        getBillSegPayOffAmount.bindDate("processDate", getProcessDateTime().getDate());
        // 2021-06-22 - End Add
        getBillSegPayOffAmount.execute();
        
        List<SQLResultRow> getBillSegPayOffAmountList = getBillSegPayOffAmount.list();
        getBillSegPayOffAmount.close(); 

        if(getBillSegPayOffAmountList.size() < minNumPremBillSegAssessMaxDep.intValue()){          
            // 2021-06-22 - Start Change
            //recommendationAmount = depositAmount;
            isBillingHistorySufficient = Bool.FALSE;
            maxDepositAmount = Money.ZERO;
            // 2021-07-30 - Start Change
            // Use the end date from the query if available. Otherwise, set the end date to the current date.
            //saEndDate = getBillSegPayOffAmount.list().get(0).getDate("END_DT");
            if(getBillSegPayOffAmountList.isEmpty()){
            	saEndDate = getProcessDateTime().getDate();
            } else {
            	saEndDate = getBillSegPayOffAmount.list().get(0).getDate("END_DT");
            }
            // 2021-07-30 - End Change      
            // 2021-06-22 - End Change
        } else {
            //Maximum Deposit Amount = Total of 2 highest Bill Segment Pay off amount  
            maxDepositAmount = getBillSegPayOffAmount.list().get(0).getMoney("TOT_AMT", currencyId);
            maxDepositAmount = maxDepositAmount.add(getBillSegPayOffAmount.list().get(1).getMoney("TOT_AMT", currencyId));
            saEndDate = getBillSegPayOffAmount.list().get(0).getDate("END_DT");
        }
        
        logDebug(logger, "Sufficient Billing History?  " + isBillingHistorySufficient.toString());
    }
    
    /**
     * This method return the Total Count of Disconnection FA
     * From Service Point.
     * @return Total Disconnection of SP
     */
    private int getTotalDisconnectionOfSP(){
        int totalDiscon = 0;
        StringBuilder strSql2 = new StringBuilder();    
		//Start Change - GCrisp - CCB021.Issue1 - 2021/07/19
        //strSql2.append(" SELECT COUNT(FA.FA_ID) AS TOTAL_NBR FROM CI_SP SP, CI_FA FA ");
        strSql2.append(" SELECT COUNT(FA.FA_ID) AS TOTAL_NBR ");
        strSql2.append(" FROM CI_SP SP, CI_FA FA, CI_SA SA, CI_SA_SP SASP ");
		//End Change - GCrisp - CCB021.Issue1 - 2021/07/19
        // 2021-07-30 - Start Change
        //strSql2.append(" WHERE SP.PREM_ID = :premId ");
        //strSql2.append(" AND  SP.SP_STATUS_FLG = :inService ");
        strSql2.append(" WHERE SP.SP_STATUS_FLG = :inService ");
        // 2021-07-30 - End Change
        strSql2.append(" AND FA.SP_ID = SP.SP_ID ");
        strSql2.append(" AND FA.FA_TYPE_CD = ( SELECT FAPR.FA_TYPE_CD ");
        strSql2.append(                      " FROM CI_FAPR_TMPL FAPR ");
        strSql2.append(                      " WHERE FAPR.CUST_EVT_FLG = :cutNonPayment ");
        strSql2.append(                      " AND FAPR.FA_TYPE_PROF_CD = :mtr ");
        strSql2.append(                      " AND FAPR.FA_TYPE_CD = FA.FA_TYPE_CD) ");
        // 2021-06-22 - Start Change
        //strSql2.append(" AND FA.CRE_DTTM BETWEEN ADD_MONTHS( :endDate, -(:saStoppedRange) ) AND :endDate ");
        strSql2.append(" AND TRUNC(FA.SCHED_DTTM) BETWEEN ADD_MONTHS( :endDate, -(:saStoppedRange) ) AND :endDate ");
        // 2021-06-22 - End Change
        strSql2.append(" AND FA.FA_STATUS_FLG = :complete ");
		//Start Add - GCrisp - CCB021.Issue1 - 2021/07/19
		strSql2.append(" AND SP.SP_ID = SASP.SP_ID ");
        strSql2.append(" AND SASP.SA_ID = SA.SA_ID ");
        strSql2.append(" AND SA.ACCT_ID = :acctId ");
        // 2024-10-03 Start Change	E-09284	
        strSql2.append(" AND SA.SA_STATUS_FLG <> :canceled ");
        // 2024-10-03 End Change	E-09284	
        // 2021-07-30 - Start Change
        //strSql2.append(" AND SA.SA_STATUS_FLG IN (:closed, :stopped) ");
        //strSql2.append(" AND FA.SCHED_DTTM BETWEEN SASP.START_DTTM AND SASP.STOP_DTTM ");
        strSql2.append(" AND FA.SCHED_DTTM > SASP.START_DTTM ");
        strSql2.append(" AND (FA.SCHED_DTTM <= SASP.STOP_DTTM OR SASP.STOP_DTTM IS NULL) ");
        // 2021-07-30 - End Change
		//End Add - GCrisp - CCB021.Issue1 - 2021/07/19

        FieldActivityTypeProfile_Id faTypeProfile = new FieldActivityTypeProfile_Id(FA_TYPE_PROF_MTR);
        PreparedStatement getTotalDisconFA = createPreparedStatement(strSql2.toString(), getClass().getName());        
        // 2021-07-30 - Start Delete
        //getTotalDisconFA.bindId("premId", premise.getId());        
        // 2021-07-30 - End Delete
        getTotalDisconFA.bindLookup("inService", ServicePointStatusLookup.constants.IN_SERVICE);
        getTotalDisconFA.bindDate("endDate", saEndDate);
        getTotalDisconFA.bindBigInteger("saStoppedRange", stoppedSARange);
        getTotalDisconFA.bindLookup("complete", FieldActivityStatusLookup.constants.COMPLETED);
        getTotalDisconFA.bindLookup("cutNonPayment", CustomerEventLookup.constants.CUTFOR_NON_PAYMENT);
        // 2024-10-03 Start Change	E-09284	
        getTotalDisconFA.bindLookup("canceled", ServiceAgreementStatusLookup.constants.CANCELED);
        // 2024-10-03 Start Change	E-09284															 
        getTotalDisconFA.bindId("mtr",faTypeProfile);
		//Start Add - GCrisp - CCB021.Issue1 - 2021/07/19
		getTotalDisconFA.bindId("acctId", account.getId());
		// 2021-07-30 - Start Delete
		//getTotalDisconFA.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
		//getTotalDisconFA.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
		// 2021-07-30 - End Delete
		//End Add - GCrisp - CCB021.Issue1 - 2021/07/19
        getTotalDisconFA.execute();
        if(notNull(getTotalDisconFA.firstRow())){
            totalDiscon = getTotalDisconFA.firstRow().getInteger("TOTAL_NBR").intValue();
            logDebug(logger, "Premise Id: " + premise.getId().getTrimmedValue());
            logDebug(logger, "SA End Date: " + saEndDate.toString());
            logDebug(logger, "Total Disconnections: " + totalDiscon);
        }
        
        getTotalDisconFA.close();
        
        return totalDiscon;
    }
    
    @Override
    public void invoke() {
        
        isGoodCustomer = Bool.FALSE;
        Bool isNeedCreditCheck = Bool.FALSE;
        Money increasedRequiredForDeposit = null;
        BigInteger accountCurrentCreditRating = null;
        BigInteger installationOptionsCreditRatingThresh = null;
        CcbInstallation_Id ccbInstallationOption = new CcbInstallation_Id(CCB_INSTALLATION);
        
        //Check Equifax Credit Check of the Customer  
        if(notNull(account) && notNull(premise)){
            currencyId = account.getCurrency().getId();
            CmDepositEquifaxCreditCheck depEquifaxCreditCheck = CmDepositEquifaxCreditCheck.Factory.newInstance();
            depEquifaxCreditCheck.callDepositEquifaxCreditCheck(account.getId(), premise.getId());
            
            isNeedCreditCheck = depEquifaxCreditCheck.isNeedCreditCheck();            
            
            logDebug(logger, "Need Credit Check? " + isNeedCreditCheck.toString());
            if(depEquifaxCreditCheck.isInError().isFalse()){
                accountCurrentCreditRating = account.getCreditRatingInfo(getProcessDateTime().getDate()).getCreditRatingPoints();
                installationOptionsCreditRatingThresh = ccbInstallationOption.getEntity().getCreditRatingThreshold();
                
                if(accountCurrentCreditRating.compareTo(installationOptionsCreditRatingThresh) >= 0
				        // Start Delete - DLampa - B-20072 - 2022-02-02
                        //&& shouldAlwaysCalculateRecommendation.isFalse()
						// End Delete - DLampa - B-20072 - 2022-02-02                		
                        && depEquifaxCreditCheck.hasDepositFlag().isFalse()){
                    isGoodCustomer = Bool.TRUE;
					// Start Delete - DLampa - E-09991 - 2025-02-14
					// Removing this snippet so that the credit rating is considered only when customer has not been disconnected for non-payment
                    //depositRecommendationResult = DepositRecommendationResult.NOT_RECOMMENDED;
                    //recommendationAmount = Money.ZERO;
                    //return;
					// End Delete - DLampa - E-09991 - 2025-02-14
                }
            }
        }
        
        // 2021-07-30 - Start Add
        latestPremiseId = getLatestSAsPremise(account.getId());
        // 2021-07-30 - End Add
        
        depositRecommendationResult = DepositRecommendationResult.RECOMMENDED;
        logDebug(logger, "Deposit Recommendation Result:  " + depositRecommendationResult.toString());
        // Read Customer Portal Configuration
        getDepositAmtAndStoppedSARangeFromCustPortalConfig();
        
        // 2021-07-30 - Start Change
        //get the Max Deposit Amount and SA End Date
        //getMaxDepositAmtAndSAEndDate();
        if (notNull(account.fetchDivision())) {
        	getMaxDepositAmtAndSAEndDate();
        } else {
            isBillingHistorySufficient = Bool.FALSE;
            maxDepositAmount = Money.ZERO;
			saEndDate = getProcessDateTime().getDate();
        }
        // 2021-07-30 - End Change
        // 2021-06-22 - Start Delete
        //if(notNull(recommendationAmount)){
        //    return;
        //}
        // 2021-06-22 - End Delete
        
        // 2021-06-22 - Start Add
        // Get the deposit on hand, if any
        // 2021-07-30 - Start Change
        //getDepositOnHand();
        if (notNull(account.fetchDivision())) {
        	getDepositOnHand();
        } else {
        	depositOnHandAmount = Money.ZERO;
        }
        // 2021-07-30 - End Change
        
        // Get the latest deposit that can be used as reference for the recommendation amount
        if (doesActiveDepositExist.isFalse()) {
            getLatestDepositOnHand();
        }        
        // 2021-06-22 - End Add
        
        //Get Total Disconnection of Service Point
        // 2021-07-30 - Start Change
        //int totalDiscon = getTotalDisconnectionOfSP();
        int totalDiscon = 0;
        if (notNull(account.fetchDivision())) {
        	totalDiscon = getTotalDisconnectionOfSP();
        }
        // 2021-07-30 - End Change
        logDebug(logger, "Number of Disconnections: " + totalDiscon);
        logDebug(logger, "Max Deposit Amount: " + maxDepositAmount);
        logDebug(logger, "Standard Deposit Amount: " + depositAmount);
        logDebug(logger, "Deposit On-Hand Amount: " + depositOnHandAmount);	
        
        //Determine the recommendation Amount
        if(totalDiscon == 0){
			//Start Change - GCrisp - CCB021.Issue1 - 2021/07/19
            //if(isNeedCreditCheck.isFalse()){
			if(isGoodCustomer.isTrue()){
			//End Change - GCrisp - CCB021.Issue1 - 2021/07/19
                depositRecommendationResult = DepositRecommendationResult.NOT_RECOMMENDED;
                recommendationAmount = Money.ZERO;
                return;
            }
			
			// Start Add - NMendo - B-20072 - 2022-01-18
			if(isNeedCreditCheck.isFalse()) {
				// If the customer has Pending Stop or Active Gas SAs
				if(hasPendingStopOrActiveGasSA(account.getId()).isTrue()) {
					depositRecommendationResult = DepositRecommendationResult.NOT_RECOMMENDED;
					recommendationAmount = Money.ZERO;
					return;
				}
				
				// If the customer has Closed/Stopped SAs with End Dates inside the last year and the 
				// Account has no Deposits in any state except Cancelled (indicating that the customer 
				// may be converted and Deposit was returned in previous system).
				Date dateLastYear = getProcessDateTime().getDate().addYears(-1);
				if(hasClosedOrStoppedGasSA(account.getId(), dateLastYear).isTrue() 
						&& hasDepositSA(account.getId()).isFalse()) {
					depositRecommendationResult = DepositRecommendationResult.NOT_RECOMMENDED;
					recommendationAmount = Money.ZERO;
					return;
				}
			}
			// End Add - NMendo - B-20072 - 2022-01-18
            
            // 2021-06-22 - Start Change
            //if (maxDepositAmount.isLessThan(depositAmount)) {
            if (isBillingHistorySufficient.isTrue() && maxDepositAmount.isLessThan(depositAmount)) {
            // 2021-06-22 - End Change
            	// start change - EQuint - B-23457 - 2022-08-19
            	// recommendationAmount = maxDepositAmount;
    			recommendationAmount = new Money(maxDepositAmount.getAmount().setScale(0, BigDecimal.ROUND_CEILING), maxDepositAmount.getCurrencyId());
    			// end change - EQuint - B-23457 - 2022-08-19
            } else {
            	// 2021-08-03 - Start Add
            	if (depositOnHandAmount.compareTo(Money.ZERO) > 0) {
                // 2021-08-03 - End Add
            		// start change - EQuint - B-23457 - 2022-08-19
                	// // 2021-07-30 - Start Change
                    // //recommendationAmount = depositAmount;
                    // recommendationAmount = depositOnHandAmount;
                    // // 2021-07-30 - End Change
                    recommendationAmount = new Money(depositOnHandAmount.getAmount().setScale(0, BigDecimal.ROUND_CEILING), depositOnHandAmount.getCurrencyId());
        			// end change - EQuint - B-23457 - 2022-08-19
                // 2021-08-03 - Start Add
            	} else {
            		 recommendationAmount = depositAmount;
            	}
            	// 2021-08-03 - End Add

            }
        } else if (totalDiscon >= 3) {
            // start change - EQuint - B-23457 - 2022-08-19
        	// recommendationAmount = maxDepositAmount;
			recommendationAmount = new Money(maxDepositAmount.getAmount().setScale(0, BigDecimal.ROUND_CEILING), maxDepositAmount.getCurrencyId());
			// end change - EQuint - B-23457 - 2022-08-19
        } else if(totalDiscon <= 2) {
            // 2021-06-22 - Start Change
            //increasedRequiredForDeposit = new Money(increaseRequiredPerDiscon.multiply(new BigDecimal(totalDiscon)),currencyId);
            //Money sumDepositAmtAndIncreaseReqDeposit = depositAmount.add(increasedRequiredForDeposit);
            //if(maxDepositAmount.isLessThan(sumDepositAmtAndIncreaseReqDeposit)){
            //    recommendationAmount = maxDepositAmount;
            //} else {
            //    recommendationAmount = sumDepositAmtAndIncreaseReqDeposit;
            //}
			//Start Change - GCrisp - CCB021.Issue1 - 2021/07/19
            //Money sumDepositAmtAndIncreaseReqDeposit = depositAmount.add(new Money(increaseRequiredPerDiscon,currencyId));
            //Money sumDepositOnHandAmtAndIncreaseReqDeposit = depositOnHandAmount.add(new Money(increaseRequiredPerDiscon,currencyId));
            //           
            //if (isBillingHistorySufficient.isTrue()) { 
            //    if (maxDepositAmount.isGreaterThan(depositAmount)) {
            //        // Determine the maximum amount between:
            //        // (1) Sum of 2 highest bills
            //        // (2) Standard Deposit + Increase, or
            //        // (3) Deposit on Hand + Increase
            //        if (sumDepositOnHandAmtAndIncreaseReqDeposit.isGreaterThan(sumDepositAmtAndIncreaseReqDeposit)
            //                && sumDepositOnHandAmtAndIncreaseReqDeposit.isGreaterThan(maxDepositAmount)) {
            //            recommendationAmount = sumDepositOnHandAmtAndIncreaseReqDeposit;
            //        }	
            //        if (sumDepositAmtAndIncreaseReqDeposit.isGreaterThan(sumDepositOnHandAmtAndIncreaseReqDeposit)
            //                && sumDepositAmtAndIncreaseReqDeposit.isGreaterThan(maxDepositAmount)) {
            //            recommendationAmount = sumDepositAmtAndIncreaseReqDeposit;
            //        }
            //        if (maxDepositAmount.isGreaterThan(sumDepositAmtAndIncreaseReqDeposit)
            //                && maxDepositAmount.isGreaterThan(sumDepositOnHandAmtAndIncreaseReqDeposit)) {
            //            recommendationAmount = maxDepositAmount;
            //        }
            //    } else {
            //        recommendationAmount = maxDepositAmount;
            //    }               
            //} else {
            //    if (sumDepositOnHandAmtAndIncreaseReqDeposit.isGreaterThan(sumDepositAmtAndIncreaseReqDeposit)) {
            //        recommendationAmount = sumDepositOnHandAmtAndIncreaseReqDeposit;
            //    } else {
            //        recommendationAmount = sumDepositAmtAndIncreaseReqDeposit;
            //    }
            //}           
            // 2021-06-22 - End Change
			if(depositOnHandAmount.isGreaterThan(depositAmount)){
				depositAmount = depositOnHandAmount;
			}
			// Start Change - DLampa - B-37557 - 2025-05-22
			//Money sumDepositAmtAndIncreaseReqDeposit = depositAmount.add(new Money(increaseRequiredPerDiscon,currencyId));
			Money sumDepositAmtAndIncreaseReqDeposit = depositAmount.add(new Money(increaseRequiredPerDiscon.multiply(new BigDecimal(totalDiscon)),currencyId));
			// End Change - DLampa - B-37557 - 2025-05-22			
			
			if(isBillingHistorySufficient.isFalse()){
				// start change - EQuint - B-23457 - 2022-08-19
				// recommendationAmount = sumDepositAmtAndIncreaseReqDeposit;
				recommendationAmount = new Money(sumDepositAmtAndIncreaseReqDeposit.getAmount().setScale(0, BigDecimal.ROUND_CEILING), sumDepositAmtAndIncreaseReqDeposit.getCurrencyId());
				// end change - EQuint - B-23457 - 2022-08-19
			} else{
				if(maxDepositAmount.isLessThan(sumDepositAmtAndIncreaseReqDeposit)){
					// start change - EQuint - B-23457 - 2022-08-19
		        	// recommendationAmount = maxDepositAmount;
					recommendationAmount = new Money(maxDepositAmount.getAmount().setScale(0, BigDecimal.ROUND_CEILING), maxDepositAmount.getCurrencyId());
					// end change - EQuint - B-23457 - 2022-08-19
				}else{
					// start change - EQuint - B-23457 - 2022-08-19
					// recommendationAmount = sumDepositAmtAndIncreaseReqDeposit;
					recommendationAmount = new Money(sumDepositAmtAndIncreaseReqDeposit.getAmount().setScale(0, BigDecimal.ROUND_CEILING), sumDepositAmtAndIncreaseReqDeposit.getCurrencyId());
					// end change - EQuint - B-23457 - 2022-08-19
				}
			}
			//End Change - GCrisp - CCB021.Issue1 - 2021/07/19
	
        }
        
    }
    
    // 2021-06-22 - Start Add
    /**
     * Checks if another Deposit SA Exists on the Account with the Characteristic Premise Id
     * @param accountId
     * @param premId
     * @return
     */
    private void getDepositOnHand(){
        Bool result = Bool.FALSE;
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append("SELECT SA.SA_ID FROM CI_SA SA ");
        strBuilder.append("WHERE SA.ACCT_ID = :accountId ");
        strBuilder.append("AND SA.CHAR_PREM_ID = :premId ");
        strBuilder.append("AND SA.SA_STATUS_FLG IN (:active, :pendingStart) ");
        // 2021-07-30 - Start Change
        //strBuilder.append("AND SA.CIS_DIVISION = :cisDivision ");
        if (notNull(account.fetchDivision())){
        	strBuilder.append("AND SA.CIS_DIVISION = :cisDivision ");
        }        
        // 2021-07-30 - End Change        
        strBuilder.append("AND SA.SA_TYPE_CD IN ");
        strBuilder.append(      "(SELECT SATY.SA_TYPE_CD ");
        strBuilder.append(      "FROM CI_SA_TYPE SATY ");
        strBuilder.append(      "WHERE SATY.SPECIAL_ROLE_FLG = :deposit) ");        
        
        PreparedStatement stmt = this.createPreparedStatement(strBuilder.toString(), getClass().getName());
        stmt.bindId("accountId", account.getId());
        // 2021-07-30 - Start Change
        //stmt.bindId("premId", premise.getId());
        stmt.bindId("premId", latestPremiseId);
        // 2021-07-30 - End Change
        stmt.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
        stmt.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
        stmt.bindLookup("deposit", SpecialRoleLookup.constants.CASH_DEPOSIT);
        // 2021-07-30 - Start Change
        //stmt.bindId("cisDivision", account.fetchDivision().getId());
        if (notNull(account.fetchDivision())){
        	stmt.bindId("cisDivision", account.fetchDivision().getId());
        }
        // 2021-07-30 - End Change
        
        // 2021-07-30 - Start Change
        //SQLResultRow row = stmt.firstRow();
        //stmt.close();

        // If an active deposit SA is found, return that SA's payoff balance as the deposit on hand amount
        //if(!isNull(row)){
        //    ServiceAgreement_Id depositSa = (ServiceAgreement_Id) row.getId("SA_ID", ServiceAgreement.class);
        //    depositOnHandAmount = new Money(depositSa.getEntity().getPayoffBalance().getAmount().abs(),currencyId);
        //    doesActiveDepositExist = Bool.TRUE;
        //} else {
        //    depositOnHandAmount = Money.ZERO;
        //}
        
        stmt.execute();
        List<SQLResultRow> depositSaList = stmt.list();
        stmt.close();
        
        depositOnHandAmount = Money.ZERO;
        
        // If an active deposit SA is found, return that SA's payoff balance as the deposit on hand amount. If there are
        // multiple deposits, tally the total payoff balances and return the sum as the deposit on hand amount.
        if (!depositSaList.isEmpty()) {
    		for(SQLResultRow row : depositSaList){
                ServiceAgreement_Id depositSa = (ServiceAgreement_Id) row.getId("SA_ID", ServiceAgreement.class);
                depositOnHandAmount = depositOnHandAmount.add(new Money(depositSa.getEntity().getPayoffBalance().getAmount().abs(),currencyId));
                doesActiveDepositExist = Bool.TRUE;
    		}        	
        }
        // 2021-07-30 - End Change        
        
    }
    
    /**
     * Checks if another Deposit SA Exists on the Account with the Characteristic Premise Id
     * @param accountId
     * @param premId
     * @return
     */
    private void getLatestDepositOnHand(){
        Bool result = Bool.FALSE;
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append("SELECT SA.SA_ID FROM CI_SA SA ");
        strBuilder.append("WHERE SA.ACCT_ID = :accountId ");
        strBuilder.append("AND SA.CHAR_PREM_ID = :premId ");
        strBuilder.append("AND SA.SA_STATUS_FLG = :closed ");
        // 2021-07-30 - Start Change
        //strBuilder.append("AND SA.CIS_DIVISION = :cisDivision ");
        if (notNull(account.fetchDivision())){
        	strBuilder.append("AND SA.CIS_DIVISION = :cisDivision ");
        }        
        // 2021-07-30 - End Change
        strBuilder.append("AND SA.SA_TYPE_CD IN ");
        strBuilder.append(      "(SELECT SATY.SA_TYPE_CD ");
        strBuilder.append(      "FROM CI_SA_TYPE SATY ");
        strBuilder.append(      "WHERE SATY.SPECIAL_ROLE_FLG = :deposit) ");
        strBuilder.append("AND SA.END_DT BETWEEN ADD_MONTHS( :processDate, -(:saStoppedRange) ) AND :processDate ");
        strBuilder.append("ORDER BY SA.END_DT DESC ");
        
        PreparedStatement stmt = this.createPreparedStatement(strBuilder.toString(), getClass().getName());
        stmt.bindId("accountId", account.getId());
        // 2021-07-30 - Start Change
        //stmt.bindId("premId", premise.getId());
        stmt.bindId("premId", latestPremiseId);
        // 2021-07-30 - End Change
        stmt.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
        stmt.bindLookup("deposit", SpecialRoleLookup.constants.CASH_DEPOSIT);
        stmt.bindDate("processDate", getProcessDateTime().getDate());
        stmt.bindBigInteger("saStoppedRange", stoppedSARange); 
        // 2021-07-30 - Start Change        
        //stmt.bindId("cisDivision", account.fetchDivision().getId());
        if (notNull(account.fetchDivision())){
        	stmt.bindId("cisDivision", account.fetchDivision().getId());
        }
        // 2021-07-30 - End Change
        
        SQLResultRow row = stmt.firstRow();
        stmt.close();
        
        if(!isNull(row)){
            ServiceAgreement_Id depositSa = (ServiceAgreement_Id) row.getId("SA_ID", ServiceAgreement.class);
            depositOnHandAmount = depositSa.getEntity().getTotalAmountToBill();
        } else {
            depositOnHandAmount = Money.ZERO;
        }
        
    }    
    // 2021-06-22 - End Add
    
    // 2021-07-30 - Start Add
    private Premise_Id getLatestSAsPremise(Account_Id acctID) {
        
        Premise_Id returnValue = null;
        StringBuilder stringBuilder = new StringBuilder();
        
        stringBuilder.append("SELECT SA.CHAR_PREM_ID ");
        stringBuilder.append("FROM CI_SA SA, CI_SA_TYPE SAT ");
        stringBuilder.append("WHERE SA.ACCT_ID = :acctID ");
        stringBuilder.append("AND SA.SA_STATUS_FLG NOT IN (:incomplete, :cancelled, :pendingStart ) ");
        stringBuilder.append("AND SAT.SA_TYPE_CD = SA.SA_TYPE_CD ");
        stringBuilder.append("AND SAT.CIS_DIVISION = SA.CIS_DIVISION ");
        stringBuilder.append("AND SAT.SVC_TYPE_CD = 'G' ");
        stringBuilder.append("ORDER BY SA.START_DT DESC ");
        
        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getLatestActiveSAsPremise=");
        prepState.setAutoclose(false);
        prepState.bindId("acctID", acctID);
        prepState.bindLookup("cancelled", ServiceAgreementStatusLookup.constants.CANCELED);
        prepState.bindLookup("incomplete", ServiceAgreementStatusLookup.constants.INCOMPLETE);
        prepState.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
        prepState.execute();
        
        if (notNull(prepState.firstRow())) {
            SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
            returnValue = (Premise_Id) sqlRow.getId("CHAR_PREM_ID", Premise.class);
        }       
        prepState.close();
        return returnValue;     
    }
    // 2021-07-30 - End Add
    
    // Start Add - NMendo - B-20072 - 2022-01-18
    /**
     * Check if Account has Pending Stop or Active Gas SA.
     * @param accountId
     * @return Bool
     */
    private Bool hasPendingStopOrActiveGasSA(Account_Id accountId) {
    	Bool returnValue = Bool.FALSE;
    	
    	StringBuilder stringBuilder = new StringBuilder();
    	stringBuilder.append("SELECT SA.SA_ID ");
        stringBuilder.append("FROM CI_SA SA, CI_SA_TYPE SAT ");
        stringBuilder.append("WHERE SA.ACCT_ID = :accountId ");
        stringBuilder.append("AND SA.SA_STATUS_FLG IN (:active, :pendingStop ) ");
        stringBuilder.append("AND SAT.SA_TYPE_CD = SA.SA_TYPE_CD ");
        stringBuilder.append("AND SAT.CIS_DIVISION = SA.CIS_DIVISION ");
        stringBuilder.append("AND SAT.SVC_TYPE_CD = 'G' ");
        
        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        prepState.setAutoclose(false);
        prepState.bindId("accountId", accountId);
        prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
        prepState.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        
        if (notNull(prepState.firstRow())) {
        	returnValue = Bool.TRUE;
        }
        prepState.close();
    	
    	return returnValue;
    }
    
    /**
     * Check if Account has Closed or Stopped Gas SA with End Date inside the last year.
     * @param accountId
     * @param endDate
     * @return Bool
     */
    private Bool hasClosedOrStoppedGasSA(Account_Id accountId, Date endDate) {
    	Bool returnValue = Bool.FALSE;
    	
    	StringBuilder stringBuilder = new StringBuilder();
    	stringBuilder.append("SELECT SA.SA_ID ");
        stringBuilder.append("FROM CI_SA SA, CI_SA_TYPE SAT ");
        stringBuilder.append("WHERE SA.ACCT_ID = :accountId ");
        stringBuilder.append("AND SA.SA_STATUS_FLG IN (:closed, :stopped ) ");
        stringBuilder.append("AND SAT.SA_TYPE_CD = SA.SA_TYPE_CD ");
        stringBuilder.append("AND SAT.CIS_DIVISION = SA.CIS_DIVISION ");
        stringBuilder.append("AND SAT.SVC_TYPE_CD = 'G' ");
        stringBuilder.append("AND SA.END_DT >= :endDate ");
        
        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        prepState.setAutoclose(false);
        prepState.bindId("accountId", accountId);
        prepState.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
        prepState.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
        prepState.bindDate("endDate", endDate);
        
        if (notNull(prepState.firstRow())) {
        	returnValue = Bool.TRUE;
        }
        prepState.close();
    	
    	return returnValue;
    }
    
    /**
     * Check if Account has non-Canceled Deposit SA.
     * @param accountId
     * @return Bool
     */
    private Bool hasDepositSA(Account_Id accountId) {
    	Bool returnValue = Bool.FALSE;
    	
    	StringBuilder stringBuilder = new StringBuilder();
    	stringBuilder.append("SELECT SA.SA_ID ");
        stringBuilder.append("FROM CI_SA SA, CI_SA_TYPE SAT ");
        stringBuilder.append("WHERE SA.ACCT_ID = :accountId ");
        stringBuilder.append("AND SA.SA_STATUS_FLG NOT IN (:canceled) ");
        stringBuilder.append("AND SAT.SA_TYPE_CD = SA.SA_TYPE_CD ");
        stringBuilder.append("AND SAT.CIS_DIVISION = SA.CIS_DIVISION ");
        stringBuilder.append("AND SAT.SPECIAL_ROLE_FLG = :deposit ");
        
        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        prepState.setAutoclose(false);
        prepState.bindId("accountId", accountId);
        prepState.bindLookup("canceled", ServiceAgreementStatusLookup.constants.CANCELED);
        prepState.bindLookup("deposit", SpecialRoleLookup.constants.CASH_DEPOSIT);
        
        if (notNull(prepState.firstRow())) {
        	returnValue = Bool.TRUE;
        }
        prepState.close();

    	return returnValue;
    }
    // End Add - NMendo - B-20072 - 2022-01-18
}
