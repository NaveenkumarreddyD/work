/* *************************************************************************************************
 * PROGRAM DESCRIPTION
 *
 * CCB219.3 - Delayed Transfer Fieldwork Creation 
 *
 * Description
 *
 * This algorithm will be used to create fieldwork for certain scenarios where a BrightLync 
 * meter/modem is installed. It will mimic the delayed transfer logic where appropriate 
 * (based on a parameter that will be populated using CIS division and SA type). For residential 
 * SA types in MO East/West, this parameter will be set to mimic delayed transfer functionality 
 * and simply request an ADDP read when stopping service. 
 * For MO East/West non-residential, and all AL/Gulf SA types, the parameter will not be set to 
 * mimic delayed transfer. 
 * For all SA types, when a BrightLync SP has a back to back request, or when a start is requested 
 * and the meter/SP are on/connected, the system will create an ADDP read request.
 *
 ***************************************************************************************************
 *
 * CHANGE HISTORY
 *
 * Date:        by:              Reason:
 * YYYY-MM-DD   IN               Reason text.
 *
 * 2023-02-10   JVitug/DLampa    CCB219.3. Initial Version.
 * 2026-08-05   EQuint           B-48320. Updated the delayed-transfer validation logic to correctly 
 *                               evaluate the mimicDelayedTransferAlgorithmFlag Boolean value rather 
 *                               than comparing it to a string constant
 *                               D-03958. the mimic delayed transfer evaluation is performed before 
 *                               any FA cancellation/consolidation logic is executed
 **************************************************************************************************/

package com.splwg.cm.domain.admin.serviceAgreementType;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.FieldActivityCreatedByLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.FieldOrderStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementSpFaTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointFieldConditionLookup;
import com.splwg.ccb.api.lookup.SeveranceStatusLookup;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.meterLocation.entity.MeterLocation;
import com.splwg.ccb.domain.admin.meterLocation.entity.MeterLocation_Id;
import com.splwg.ccb.domain.admin.meterReadCycle.entity.MeterReadRoute;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saSpFieldWorkCreation.SaTypeSaSpFieldWorkCreationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.cm.domain.common.customBusinessComponent.CmCancelUnlinkFasOfSaSp;
import com.splwg.cm.domain.common.customBusinessComponent.CmCancelUnlinkFasOfSaSpData;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author JVitug / DLampa
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = numberOfDaysLeadTime, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = backToBackThresholdDays, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = nonDispatchableFieldActivityTypeForMeterRead, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = servicePointFieldCondition, name = spsDesiredStateForMeterRead, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (name = allowedRouteTypes, type = string, required = true)
 *            , @AlgorithmSoftParameter (name = excludeMeterLocations, type = string)
 *            , @AlgorithmSoftParameter (name = immediateFaCreation, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (name = mimicDelayedTransfer, required = true, type = boolean)})
 *
 */

public class CmADDPFieldWorkCreationAlgComp_Impl extends
        CmADDPFieldWorkCreationAlgComp_Gen implements
        SaTypeSaSpFieldWorkCreationAlgorithmSpot {

	private static final Logger logger= LoggerFactory.getLogger(CmADDPFieldWorkCreationAlgComp_Impl.class); 
    // Constants
    private static final String COMMA_DELIMITER = ",";
    private static final String NO_VALUE = "N";

    // Soft parameters
    private Bool neverCreateSingleFieldActivity = Bool.FALSE;
    private BigInteger backToBackThresholdDays;
    private List<MeterReadRouteType> includedMeterRouteTypesList = new ArrayList<MeterReadRouteType>();
    private List<MeterLocation> excludedMeterLocationsList = new ArrayList<MeterLocation>();
    private Bool immediateFaCreation;
    private Bool mimicDelayedTransferAlgorithmFlag;
    
    // Hard parameters - input
    private ServiceAgreementSpFaTypeLookup saSpFieldActivityType;
    private DateTime saSpStartDateTime;
    private DateTime saSpStopDateTime;
    @SuppressWarnings("unused")
    private Date saStartDate;
    @SuppressWarnings("unused")
    private Date saStopDate;
    private ServiceAgreement serviceAgreement;
    private ServiceAgreementServicePoint serviceAgreementServicePoint;
    private ServicePoint servicePoint;
    private Bool shouldActivateManually;

    // Hard parameters - input/output
    private Bool isFaCreated;

    // Working variables
    private Bool isBackToBack = Bool.FALSE;
    private DateTime leastStopDateTime;
    private DateTime scheduleDateTime;
    private FieldActivity fa1;
    Bool hasCreatedFA2 =  Bool.FALSE;
    ServiceAgreementServicePoint futureStoppedPendingStopSASP;
    private Bool shouldContinue = Bool.TRUE;   
    
    // Common component
    private CmCancelUnlinkFasOfSaSp cancelUnlinkFasOfSaSp = CmCancelUnlinkFasOfSaSp.Factory.newInstance();

    public void setSaSpFieldActivityType(ServiceAgreementSpFaTypeLookup saSpFieldActivityType) {
        this.saSpFieldActivityType = saSpFieldActivityType;
    }

    public void setSaSpStartDateTime(DateTime saSpStartDateTime) {
        this.saSpStartDateTime = saSpStartDateTime;
    }

    public void setSaSpStopDateTime(DateTime saSpStopDateTime) {
        this.saSpStopDateTime = saSpStopDateTime;
    }

    public void setSaStartDate(Date saStartDate) {
        this.saStartDate = saStartDate;
    }

    public void setSaStopDate(Date saStopDate) {
        this.saStopDate = saStopDate;
    }

    public void setServiceAgreement(ServiceAgreement serviceAgreement) {
        this.serviceAgreement = serviceAgreement;
    }

    public void setServiceAgreementServicePoint(ServiceAgreementServicePoint serviceAgreementServicePoint) {
        this.serviceAgreementServicePoint = serviceAgreementServicePoint;
    }

    public void setServicePoint(ServicePoint servicePoint) {
        this.servicePoint = servicePoint;
    }

    public void setShouldActivateManually(Bool shouldActivateManually) {
        this.shouldActivateManually = shouldActivateManually;
    }

    public void setFaCreated(Bool isFaCreated) {
        this.isFaCreated = isFaCreated;
    }

    public Bool getIsFaCreated() {
        return this.isFaCreated;
    }

    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        
        String includedRouteTypes = getAllowedRouteTypes();
        if (notBlank(includedRouteTypes)) {

            String[] includedRouteTypesList = includedRouteTypes.split(COMMA_DELIMITER);

            for (String includedRouteType : includedRouteTypesList) {

                if (includedRouteType.trim().length() > MeterReadRouteType_Id.FIELD_SIZE) {
                    addError(CustomMessageRepository.CCB219_3_InvalidRouteType(
                            includedRouteType, getAlgorithm()));
                }

                MeterReadRouteType_Id meterReadRouteTypeId = new MeterReadRouteType_Id(includedRouteType.trim());
                if (isNull(meterReadRouteTypeId.getEntity())) {
                    addError(CustomMessageRepository.CCB219_3_InvalidRouteType(
                            includedRouteType, getAlgorithm()));
                }

                includedMeterRouteTypesList.add(meterReadRouteTypeId.getEntity());
            }
        }

        String excludeMeterLocations = getExcludeMeterLocations();
        if (notBlank(excludeMeterLocations)) {

            String[] excludeMeterLocationList = excludeMeterLocations.split(COMMA_DELIMITER);

            for (String excludedMeterLocationIdString : excludeMeterLocationList) {

                if (excludedMeterLocationIdString.trim().length() > MeterLocation_Id.FIELD_SIZE) {
                    addError(CustomMessageRepository.CCB219_3_InvalidMeterLocation(
                            excludedMeterLocationIdString, getAlgorithm()));
                }

                MeterLocation_Id meterLocationId = new MeterLocation_Id(excludedMeterLocationIdString.trim());
                if (isNull(meterLocationId.getEntity())) {
                    addError(CustomMessageRepository.CCB219_3_InvalidMeterLocation(
                            excludedMeterLocationIdString, getAlgorithm()));
                }

                excludedMeterLocationsList.add(meterLocationId.getEntity());
            }
        }

        // Back to Back Threshold Days parameter can either be a string value "N" or an integer
        String backToBackThresholdDaysString = getBackToBackThresholdDays();
        if (NO_VALUE.equals(backToBackThresholdDaysString.trim())) {
            neverCreateSingleFieldActivity = Bool.TRUE;
        } else {
            try {
                backToBackThresholdDays = BigInteger.valueOf(Integer.parseInt(backToBackThresholdDaysString));
            } catch (NumberFormatException e) {
                addError(CustomMessageRepository.CCB219_3_InvalidB2bThresholdDays(NO_VALUE, getAlgorithm()));
            }
        }

        immediateFaCreation = getImmediateFaCreation();
        
        //Mimic Delayed Transfer Flag validation
        mimicDelayedTransferAlgorithmFlag = getMimicDelayedTransfer();
        
        super.extraSoftParameterValidations(forAlgorithmValidation);
        
    }

    /**
     * GA000
     */
    public void invoke() {
    	
    	
    	MeterReadRoute meterReadRoute = servicePoint.fetchMeterReadRoute();
    //	if (notNull(meterReadRoute)
   //             && includedMeterRouteTypesList.contains(meterReadRoute.getMeterReadRouteType()))
   // 	{ // if its inside don't do anything
    		//logger.info(">>>>> 249" + meterReadRoute);
    	//	if(saSpFieldActivityType.isStopActivity())
    	//	{
    			//logger.info(">>>>> 255" + meterReadRoute);
    	            // If the SPs Meter Location is in the Exclude Meter Location list, do not continue processing
    	            if(notNull(servicePoint.fetchMeterLocation())
    	                    && excludedMeterLocationsList.contains(servicePoint.fetchMeterLocation())) {
    	            	//logger.info(">>>>> 259" + meterReadRoute);
    	             return;
    	            }
    	            
    	//            }
   // 	}
    		// if its not inside and non ADDP route dont do anything
    	    	if (notNull(meterReadRoute)
    		                && !includedMeterRouteTypesList.contains(meterReadRoute.getMeterReadRouteType()))
    		    	{
    		    		//logger.info(">>>>> 269" + meterReadRoute);
    		  //  		if(saSpFieldActivityType.isStopActivity())
    		 //   		{
    		    			//logger.info(">>>>> 272" + meterReadRoute);
    		    	            // If the SPs Meter Location is in the Exclude Meter Location list, do not continue processing
    		    	          //  if(notNull(servicePoint.fetchMeterLocation())
    		    	          //          && !excludedMeterLocationsList.contains(servicePoint.fetchMeterLocation())) {
    		    	            	//logger.info(">>>>> 277" + meterReadRoute);
    		    	             return;
    		    	         //   }
    		    	            
    		   // 	            }
    		    	}
    		    		
    	    // if the SP is disconnected and if its a start activity halt the processing.
    	    	if(saSpFieldActivityType.isStartActivity())
    	    	{
    	    		if(servicePoint.getServicePointSourceStatus().isDisconnected())
    	    		{
    	    	      //      List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, null, null
    	    	      //              , saSpStartDateTime.getDate(), saSpStartDateTime.getDate(), ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
    	    	      //      //logger.info(">>>>> 290" + servicePoint);
    	    	      //      if (!results.isEmpty()) {
    	    	      //      	//logger.info(">>>>> 292" + servicePoint);
    	    	            	return;
    	    	      //      }
    	    	        
    	    			
    	    		}
    	    		
    	    	}
    	    	
    	    	// start add - EQuint - B-48320 / D-03958 - 2026-08-26
    	    	//If the mimic Delayed transfer algorithm is parameter is set to N, do not continue processing
    	    	if(saSpFieldActivityType.isStopActivity()) {
	                if(mimicDelayedTransferAlgorithmFlag.isFalse()) {
	                    return;
	                }
    	    	}
                // end add - EQuint - B-48320 / D-03958 - 2026-08-26
    	    	
    	//logger.info(">>>>> 265" + meterReadRoute);
        // Decide if it is time to create the FA
        decideIfTooEarly();
        //logger.info(">>>>> 268" + meterReadRoute);
        // Process the pending start/stop SA/SP for the SP
        checkPendingStartStop();
        //logger.info(">>>>> 271" + meterReadRoute);
        // Process the pending start/stop SA/SP for same SP type
        checkPendingStartStopForSameSpType();
        //logger.info(">>>>> 274" + meterReadRoute);
        // Determine if Back-To-Back situation exists
        checkForBackToBack();
        //logger.info(">>>>> 277" + meterReadRoute);
        if (shouldActivateManually.isFalse()) {
            // Create Field Activity and Field Activity Steps for SA/SP
            processServiceAgreementServicePoint();
            //logger.info(">>>>> 316" + meterReadRoute);
            if(shouldContinue.isFalse()) {
            	//logger.info(">>>>> 318" + meterReadRoute);
                return;
            }

            // Link newly created pending Field Activity
            //logger.info(">>>>> 323" + meterReadRoute);
            processFieldActivity();

        } else {
            if (immediateFaCreation.isTrue()){
            	//logger.info(">>>>> 328" + meterReadRoute);
                processServiceAgreementServicePoint();
                
                if(shouldContinue.isFalse()) {
                	//logger.info(">>>>> 332" + meterReadRoute);
                    return;
                }
                //logger.info(">>>>> 335" + meterReadRoute);
                processFieldActivity();

            }else{
                if ((saSpFieldActivityType.isStartActivity()
                        && saSpStartDateTime.getDate().isSameOrBefore(getProcessDateTime().getDate()))
                     || (saSpFieldActivityType.isStopActivity()
                             && saSpStopDateTime.getDate().isSameOrBefore(getProcessDateTime().getDate()))) {
                	//logger.info(">>>>> 343" + meterReadRoute);
                    processServiceAgreementServicePoint();
                    
                    if(shouldContinue.isFalse()) {
                    	//logger.info(">>>>> 347" + meterReadRoute);
                        return;
                    }
                    //logger.info(">>>>> 350" + meterReadRoute);
                    processFieldActivity();

                }
            }
        }
        
    }

    /**
     * MA000 - If the Manual Activation switch is false and calculated days for START/STOP exceeds the Number of Days Lead Time,
     * it's too early for creating Field Activities.
     */
    private void decideIfTooEarly() {

        if (saSpFieldActivityType.isStartActivity()) {
            // Calculate Date Difference between SASP's Start Date and Business Date
            long startDays = saSpStartDateTime.getDate().difference(getProcessDateTime().getDate()).getDays();

            if (shouldActivateManually.isFalse() && startDays > getNumberOfDaysLeadTime().longValue()) {
                addError(CustomMessageRepository.CCB219_3_TooEarlyForFa(
                        serviceAgreement, servicePoint, getNumberOfDaysLeadTime(), getAlgorithm()));
            }
        }

        if (saSpFieldActivityType.isStopActivity()) {
            // Calculate Date Difference between SA/SP's Stop Date and Business Date
            long stopDays = saSpStopDateTime.getDate().difference(getProcessDateTime().getDate()).getTotalDays();

            if (shouldActivateManually.isFalse() && stopDays > getNumberOfDaysLeadTime().longValue()) {
                addError(CustomMessageRepository.CCB219_3_TooEarlyForFa(
                        serviceAgreement, servicePoint, getNumberOfDaysLeadTime(), getAlgorithm()));
            }
        }
        
    }
    
    /**
     * Check if has active severance process for SA
     * @param saId
     */
    private Bool hasActiveSevProcForSA(ServiceAgreement_Id saId){
    	
        Bool hasActiveSev = Bool.FALSE;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT SEVPROC.SA_ID ");
        stringBuilder.append("FROM CI_SEV_PROC SEVPROC ");
        stringBuilder.append("WHERE SEVPROC.SA_ID = :saId ");
        stringBuilder.append("AND SEVPROC.SEV_STATUS_FLG = :active ");
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("saId", saId);
        preparedStatement.bindLookup("active", SeveranceStatusLookup.constants.ACTIVE);
        
        if(notNull(preparedStatement.firstRow())){
            hasActiveSev = Bool.TRUE;
        }
        preparedStatement.close();
        
        return hasActiveSev;
        
    }
    
    /**
     * MC000
     */
    private void checkPendingStartStop() {
    	
        // Do not cancel if creating 2 different FAs
        if (neverCreateSingleFieldActivity.isTrue()) {
            return;
        }

        // If FA Type is Start, determine if there is a Pending Stop, Pending Start or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the PAST of the Start Date that has a
        // Non-Dispatched Pending Field Activity for Stop
        if (saSpFieldActivityType.isStartActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.negate().intValue());

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, start1Date, saSpStartDateTime.getDate()
                    , null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            
            if (!results.isEmpty()) {
                // Ensure only latest one is selected
            	//logger.info(">>>>> 395" + servicePoint);
                cancelUnlinkPendingFa(results.get(0), ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }
        }

        // If FA Type is Stop, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the FUTURE of the Stop Date that has a
        // Non-Dispatched Pending Field Activity for Start
        if (saSpFieldActivityType.isStopActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date stop2Date = saSpStopDateTime.getDate().addDays(backToBackThresholdDays.intValue());

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, null, null, saSpStopDateTime.getDate()
                    , stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            
            for (ServiceAgreementServicePoint pendingSaSp : results) {
            	//logger.info(">>>>> 411" + servicePoint);
                cancelUnlinkPendingFa(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
        }
        
    }

    /**
     * SQ010, SQ030
     * @param servicePoint
     * @param start1Date
     * @param start2Date
     * @param stop1Date
     * @param stop2Date
     * @param serviceAgreementSpFaTypeLookup
     * @return List&lt;ServiceAgreementServicePoint&gt;
     */
    private List<ServiceAgreementServicePoint> getPendingSaSp(ServicePoint servicePoint, Date start1Date, Date start2Date
            , Date stop1Date, Date stop2Date, ServiceAgreementSpFaTypeLookup serviceAgreementSpFaTypeLookup) {

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "S2.STOP_DTTM, ");
        // Selected S2.START_DTTM instead of S2.SA_ID so that query can be used when searching for either Stop or Start
        stringBuilder.append(  "S2.START_DTTM, ");
        stringBuilder.append(  "S2.SA_SP_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA S1, ");
        stringBuilder.append(  "CI_SA_SP_DT_VW S2 ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "S2.SA_ID = S1.SA_ID ");
        stringBuilder.append("AND S2.SP_ID = :servicePoint ");
        stringBuilder.append("AND S1.SA_STATUS_FLG IN (:activeSaStatus , :pendingStopSaStatus, :pendingStartSaStatus) ");
        // Cater for either stop or start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_DT BETWEEN :start1Date AND :start2Date ");
        }
        // Cater for either stop or start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_DT BETWEEN :stop1Date AND :stop2Date ");
        }
        // Cater for either stop or start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_MR_ID = ' ' ");
        }
        // Cater for either stop or start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_MR_ID = ' ' ");
        }
        stringBuilder.append("AND EXISTS ( ");
        stringBuilder.append(  "SELECT ");
        stringBuilder.append(    "S3.FA_ID ");
        stringBuilder.append(  "FROM ");
        stringBuilder.append(    "CI_SA_SP_FA S3, ");
        stringBuilder.append(    "CI_FA F1 ");
        stringBuilder.append(  "WHERE ");
        stringBuilder.append(    "S3.SA_SP_ID = S2.SA_SP_ID ");
        stringBuilder.append(  "AND F1.FA_ID = S3.FA_ID ");
        stringBuilder.append(  "AND F1.FA_STATUS_FLG = :pendingFaStatus ");
        stringBuilder.append(  "AND S3.SA_SP_FA_TYPE_FLG = :saSpFaType ");
        stringBuilder.append(  "AND F1.FA_ID = S3.FA_ID ");
        stringBuilder.append(  "AND ( ");
        stringBuilder.append(    "F1.FO_ID = ' ' ");
        stringBuilder.append(      "OR EXISTS ( ");
        stringBuilder.append(        "SELECT ");
        stringBuilder.append(          "'X' ");
        stringBuilder.append(        "FROM ");
        stringBuilder.append(          "CI_FO FO ");
        stringBuilder.append(        "WHERE ");
        stringBuilder.append(          "F1.FO_ID = FO.FO_ID ");
        stringBuilder.append(        "AND FO.FO_STATUS_FLG = :pendingFoStatus ");
        stringBuilder.append(      ") ");
        stringBuilder.append(    ") ");
        stringBuilder.append(  ") ");
        stringBuilder.append("ORDER BY ");
        // Cater for either stop or start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append(  "S2.STOP_DTTM DESC ");
        }
        // Cater for either stop or start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append(  "S2.START_DTTM DESC ");
        }

        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindLookup("activeSaStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
        preparedStatement.bindLookup("pendingStopSaStatus", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        preparedStatement.bindLookup("pendingStartSaStatus", ServiceAgreementStatusLookup.constants.PENDING_START);
        if (notNull(start1Date) && notNull(start2Date)) {
            preparedStatement.bindDate("start1Date", start1Date);
            preparedStatement.bindDate("start2Date", start2Date);
        }
        if (notNull(stop1Date) && notNull(stop2Date)) {
            preparedStatement.bindDate("stop1Date", stop1Date);
            preparedStatement.bindDate("stop2Date", stop2Date);
        }
        preparedStatement.bindLookup("saSpFaType", serviceAgreementSpFaTypeLookup);
        preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);
        preparedStatement.bindLookup("pendingFoStatus", FieldOrderStatusLookup.constants.PENDEDBY_USER);

        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<ServiceAgreementServicePoint> serviceAgreementServicePointResults = new ArrayList<ServiceAgreementServicePoint>();
        for (SQLResultRow sqlResultRow : results) {
            serviceAgreementServicePointResults.add(sqlResultRow.getEntity("SA_SP_ID", ServiceAgreementServicePoint.class));
        }

        return serviceAgreementServicePointResults;
        
    }

    /**
     * MC060
     * @param serviceAgreementServicePoint
     * @param serviceAgreementSpFaType
     */
    private void cancelUnlinkPendingFa(ServiceAgreementServicePoint serviceAgreementServicePoint
            , ServiceAgreementSpFaTypeLookup serviceAgreementSpFaType) {

        CmCancelUnlinkFasOfSaSpData data = CmCancelUnlinkFasOfSaSpData.Factory.newInstance();
        data.setServiceAgreementServicePoint(serviceAgreementServicePoint);
        data.setServiceAgreementSpFaType(serviceAgreementSpFaType);
        cancelUnlinkFasOfSaSp.cancelUnlinkFas(data);
        
    }

    /**
     * ME000
     */
    private void checkPendingStartStopForSameSpType() {

        // Do not cancel if creating 2 different FAs
        if (neverCreateSingleFieldActivity.isTrue()) {
            return;
        }

        // If FA Type is Start, determine if there is a Pending Stop, Pending Start or Active SA/SP for the SP
        // on the exact date as start date that has a Non-Dispatched Field Activity for Start
        if (saSpFieldActivityType.isStartActivity()) {

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, null, null
                    , saSpStartDateTime.getDate(), saSpStartDateTime.getDate(), ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            for (ServiceAgreementServicePoint pendingSaSp : results) {
                cancelUnlinkPendingFa(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
            
        }

        // If FA Type is Stop, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // on the exact date as stop date that has a Non-Dispatched Pending Field Activity for Stop
        if (saSpFieldActivityType.isStopActivity()) {

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, saSpStopDateTime.getDate()
                    , saSpStopDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            for (ServiceAgreementServicePoint pendingSaSp : results) {
                cancelUnlinkPendingFa(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }
        }
        
    }

    /**
     * MG000
     *
     */
    private void checkForBackToBack() {

        // There is no need to check for back to back if creating separate FAs
        if (neverCreateSingleFieldActivity.isTrue()) {
            return;
        }

        // If FA Type is Start, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the Past of the Start Date
        // without Pending, Held or Completed Field Activity for Stop
        if (saSpFieldActivityType.isStartActivity()) {

            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.negate().intValue());

            List<ServiceAgreementServicePoint> results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , start1Date, saSpStartDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY , Bool.FALSE);

            if (!results.isEmpty()) {
                // Assume back to back
                isBackToBack = Bool.TRUE;
                leastStopDateTime = results.get(0).getStopDateTime();
            }
            
            //Now check if there is a pending stop SA whose pending stop date is on a later date compared to the 
            //Start date of this new SA. This is to cater a possible back-to-back scenario
            //where a pending stop SA is linked to a SP whose end date is future dated.
            start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.intValue());
            results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint, saSpStartDateTime.getDate(), 
                    start1Date, null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY , Bool.TRUE);

            if (!results.isEmpty()) {
                // Assume back to back
                isBackToBack = Bool.TRUE;
                leastStopDateTime = results.get(0).getStopDateTime();
                futureStoppedPendingStopSASP = results.get(0);
            }
        }

        // If FA Type is Stop, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the Future of the Stop Date
        // without Pending, Held or Completed Field Activity for Start
        if (saSpFieldActivityType.isStopActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date stop2Date = saSpStopDateTime.getDate().addDays(backToBackThresholdDays.intValue());

            List<ServiceAgreementServicePoint> results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , null, null, saSpStopDateTime.getDate(), stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY, Bool.FALSE);
          

            if (!results.isEmpty()) {
                // Assume back to back
                isBackToBack = Bool.TRUE;
            }
        }
        
    }

    /**
     * SQ050, SQ070
     * @param servicePoint
     * @param serviceAgreementServicePoint
     * @param start1Date
     * @param start2Date
     * @param stop1Date
     * @param stop2Date
     * @param serviceAgreementSpFaTypeLookup
     * @return List&lt;ServiceAgreementServicePoint&gt;
     */
    private List<ServiceAgreementServicePoint> getOtherSaSpFieldActivities(ServicePoint servicePoint
            , ServiceAgreementServicePoint serviceAgreementServicePoint, Date start1Date, Date start2Date
            , Date stop1Date, Date stop2Date, ServiceAgreementSpFaTypeLookup serviceAgreementSpFaTypeLookup, 
            Bool shouldCheckForFutureDatedBackToBack) {    

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "S2.STOP_DTTM, ");
        // Selected S2.START_DTTM instead of S2.SA_ID so that query can be used when searching for either back-to-back Stop or back-to-back Start
        stringBuilder.append(  "S2.START_DTTM, ");
        stringBuilder.append(  "S2.SA_SP_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA S1, ");
        stringBuilder.append(  "CI_SA_SP_DT_VW S2 ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "S2.SA_ID = S1.SA_ID ");
        stringBuilder.append("AND S2.SP_ID = :servicePoint ");
        stringBuilder.append("AND S2.SA_SP_ID <> :serviceAgreementServicePoint ");
        stringBuilder.append("AND S1.SA_STATUS_FLG IN ");
        stringBuilder.append(  "( ");
        stringBuilder.append(    ":activeSaStatus, :pendingStopSaStatus, :pendingStartSaStatus");
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append(    ", :stoppedSaStatus");
        }
        stringBuilder.append(  ") ");
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_DT BETWEEN :start1Date AND :start2Date ");
        }
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_DT BETWEEN :stop1Date AND :stop2Date ");
        }
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_MR_ID = ' ' ");
        }
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_MR_ID = ' ' ");
        }

        if(shouldCheckForFutureDatedBackToBack.isFalse()) {
            stringBuilder.append("AND NOT EXISTS ");
            stringBuilder.append(  "( ");
            stringBuilder.append(    "SELECT ");
            stringBuilder.append(      "S3.FA_ID ");
            stringBuilder.append(    "FROM ");
            stringBuilder.append(      "CI_SA_SP_FA S3, ");
            stringBuilder.append(      "CI_FA F1 ");
            stringBuilder.append(    "WHERE ");
            stringBuilder.append(      "S3.SA_SP_ID = S2.SA_SP_ID ");
            stringBuilder.append(    "AND S3.SA_SP_FA_TYPE_FLG = :saSpFaType ");
            stringBuilder.append(    "AND F1.FA_ID = S3.FA_ID ");
            stringBuilder.append(    "AND F1.FA_STATUS_FLG IN (:heldFaStatus, :pendingFaStatus, :completedFaStatus) ");
            stringBuilder.append(  ") ");


        }
        stringBuilder.append("ORDER BY ");
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append(  "S2.STOP_DTTM DESC ");
        }
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append(  "S2.START_DTTM DESC ");
        }

        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindId("serviceAgreementServicePoint", serviceAgreementServicePoint.getId());
        preparedStatement.bindLookup("activeSaStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
        preparedStatement.bindLookup("pendingStopSaStatus", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        preparedStatement.bindLookup("pendingStartSaStatus", ServiceAgreementStatusLookup.constants.PENDING_START);
        if (notNull(start1Date) && notNull(start2Date)) {
            preparedStatement.bindLookup("stoppedSaStatus", ServiceAgreementStatusLookup.constants.STOPPED);
        }
        if (notNull(start1Date) && notNull(start2Date)) {
            preparedStatement.bindDate("start1Date", start1Date);
            preparedStatement.bindDate("start2Date", start2Date);
        }
        if (notNull(stop1Date) && notNull(stop2Date)) {
            preparedStatement.bindDate("stop1Date", stop1Date);
            preparedStatement.bindDate("stop2Date", stop2Date);
        }
        
        if(shouldCheckForFutureDatedBackToBack.isFalse()) {
            preparedStatement.bindLookup("saSpFaType", serviceAgreementSpFaTypeLookup);
            preparedStatement.bindLookup("heldFaStatus", FieldActivityStatusLookup.constants.HELD);
            preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);
            preparedStatement.bindLookup("completedFaStatus", FieldActivityStatusLookup.constants.COMPLETED);
        }

        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<ServiceAgreementServicePoint> serviceAgreementServicePointResults = new ArrayList<ServiceAgreementServicePoint>();
        for (SQLResultRow sqlResultRow : results) {
            serviceAgreementServicePointResults.add(sqlResultRow.getEntity("SA_SP_ID", ServiceAgreementServicePoint.class));
        }

        return serviceAgreementServicePointResults;
        
    }

    /**
     * Create FA based on SP condition in FA Profile
     * This is the section that was modified to cater for custom requirements for ADDP reads.
     */
    private void processServiceAgreementServicePoint() {
    	
        // Retrieve information about the Service Point
        ServicePointFieldConditionLookup spCondition = servicePoint.determineFieldCondition();
        MeterReadRoute meterReadRoute = servicePoint.fetchMeterReadRoute();
        scheduleDateTime = decideScheduleDateTime();
        //logger.info(">>>>> 803" + servicePoint);
        if (!spCondition.equals(getSpsDesiredStateForMeterRead())) {
            // If the SP's condition does not match the SP's desired State for Meter Read value, halt processing 
            shouldContinue = Bool.FALSE;
            //logger.info(">>>>> 807" + servicePoint);
            return;

        } else if (isNull(meterReadRoute)) {
            shouldContinue = Bool.FALSE;
            //logger.info(">>>>> 812" + servicePoint);
            return;
            
        } else if (notNull(meterReadRoute)
                && !includedMeterRouteTypesList.contains(meterReadRoute.getMeterReadRouteType())) {
            // If the SP's Route Type is not included in the allowed route types , halt processing
            shouldContinue = Bool.FALSE;
            //logger.info(">>>>> 819" + servicePoint);
            return;

        } 
        
        if (saSpFieldActivityType.isStopActivity()) {
            // If the SPs Meter Location is in the Exclude Meter Location list, do not continue processing
            if(notNull(servicePoint.fetchMeterLocation())
                    && excludedMeterLocationsList.contains(servicePoint.fetchMeterLocation())) {
                    shouldContinue = Bool.FALSE;
                    return;
            }

            // start delete - EQuint - B-48320 / D-03958 - 2026-08-26
            // //If the mimic Delayed transfer algorithm is parameter is set to N, do not continue processing
            // if(mimicDelayedTransferAlgorithmFlag.equals(NO_VALUE)) {
            //     shouldContinue = Bool.FALSE;
            //     return;
            // }
            // end delete  - EQuint - B-48320 / D-03958 - 2026-08-26

            //If the SA has an active Severance Process, halt processing
            if(hasActiveSevProcForSA(serviceAgreement.getId()).isTrue()) {
                shouldContinue = Bool.FALSE;
                return;
            }

            //If it reaches this point, Stop Activity is valid for processing. Create a Non-Dispatchable FA
            fa1 = createFieldActivityAndLinkToSaSp(getNonDispatchableFieldActivityTypeForMeterRead() , saSpStopDateTime);
        } else {
        	//logger.info(">>>>> 847" + servicePoint);
            //If the customer event is Start Service 
            //and the SP condition and route type do not prevent the SP from having a Non-Dispachable FA to be created
            //, create a non-dispatchable FA Type
            fa1 = createFieldActivityAndLinkToSaSp(getNonDispatchableFieldActivityTypeForMeterRead() , saSpStartDateTime);
        }
        
    }
    
    /**
     * MI040
     * @return scheduleDateTime
     */
    private DateTime decideScheduleDateTime() {

        // If it is START and there is no BACK-to-BACK situation then SCHED-DTTM will be set to START-DTTM,
        // otherwise (i.e. BACK-to-BACK) it will be set to earliest STOP-DTTM among SA/SPs
        if (saSpFieldActivityType.isStartActivity() && isBackToBack.isTrue()) {
            return leastStopDateTime;
        }

        if (saSpFieldActivityType.isStartActivity() && isBackToBack.isFalse()) {
            return saSpStartDateTime;
        }

        // If it is STOP, SCHED-DTTM will be set to STOP-DTTM of SA/SP regardless of BACK-to-BACK situation
        if (saSpFieldActivityType.isStopActivity()) {
            return saSpStopDateTime;
        }

        return null;
        
    }

    private FieldActivity createFieldActivityAndLinkToSaSp(FieldActivityType fieldActivityType , DateTime scheduleDateTime) {

        FieldActivity_DTO fieldActivityDTO = new FieldActivity_DTO();
        fieldActivityDTO.setServicePointId(servicePoint.getId());
        fieldActivityDTO.setFieldActivityTypeId(fieldActivityType.getId());
        fieldActivityDTO.setScheduleDateTimeStart(scheduleDateTime);
        fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);

        FieldActivityCreatorData data = FieldActivityCreatorData.Factory.newInstance();
        data.setFaDTO(fieldActivityDTO);

        FieldActivity fieldActivity = FieldActivityCreator.Factory.newInstance().addFieldActivity(data);

        ServiceAgreementSpFieldActivity_DTO serviceAgreementSpFieldActivityDTO = new ServiceAgreementSpFieldActivity_DTO();
        serviceAgreementSpFieldActivityDTO.setFieldActivityType(saSpFieldActivityType);
        serviceAgreementSpFieldActivityDTO.setServiceAgreementId(serviceAgreementServicePoint.getServiceAgreement().getId());
        serviceAgreementSpFieldActivityDTO.setServicePointId(serviceAgreementServicePoint.getServicePoint().getId());
        serviceAgreementServicePoint.getServiceAgreementSpFieldActivities().add(serviceAgreementSpFieldActivityDTO, fieldActivity.getId());

        isFaCreated = Bool.TRUE;

        return fieldActivity;
        
    }

    /**
     * MM000 - Retrieve newly created Pending FAs of SA/SP and link to Back-to-Back SA/SPs
     */
    private void processFieldActivity() {

        for (FieldActivity fieldActivity : getSaSpFas(serviceAgreementServicePoint)) {
            if (isBackToBack.isTrue()) {
                linkB2BSaSpFa(fieldActivity);
            }
            linkSameType(fieldActivity);
        }
        
    }

    /**
     * SQ090
     * @param serviceAgreementServicePoint
     * @return List&lt;FieldActivity&gt;
     */
    private List<FieldActivity> getSaSpFas(ServiceAgreementServicePoint serviceAgreementServicePoint) {

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "SASPFA.FA_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA_SP_FA SASPFA, ");
        stringBuilder.append(  "CI_FA FA ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "SASPFA.SA_SP_ID = :saSpId ");
        stringBuilder.append(  "AND SASPFA.SA_SP_FA_TYPE_FLG = :saSpFaType ");
        stringBuilder.append(  "AND FA.FA_ID = SASPFA.FA_ID ");
        stringBuilder.append(  "AND FA.FA_STATUS_FLG = :pendingFaStatus ");

        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("saSpId", serviceAgreementServicePoint.getId());

        preparedStatement.bindLookup("saSpFaType", saSpFieldActivityType);
        preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);

        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<FieldActivity> fieldActivityResults = new ArrayList<FieldActivity>();
        for (SQLResultRow sqlResultRow : results) {
            fieldActivityResults.add(sqlResultRow.getEntity("FA_ID", FieldActivity.class));
        }

        return fieldActivityResults;
        
    }

    /**
     * MM020 - Link the Field Activity to the Pending Start and Pending Stop SA/SPs.
     * @param fieldActivity
     */
    private void linkB2BSaSpFa(FieldActivity fieldActivity) {
    	//logger.info(">>>>> 963" + fieldActivity);
        if (saSpFieldActivityType.isStartActivity()) {
        	//logger.info(">>>>> 965" + fieldActivity);
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.negate().intValue());

            for (ServiceAgreementServicePoint pendingStopSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , start1Date, saSpStartDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY , Bool.FALSE)) {
            	//logger.info(">>>>> 971" + fieldActivity);
            	createSaSpFa(pendingStopSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);                
            }
            
            //If there is a future dated pending stop whose stop date is future dated and is within the number of back to back threshold days
            // link the FA created to the future-dated Pending Stop SA and update its end date to be equal to the 
            //start date of the new SA
            if(notNull(futureStoppedPendingStopSASP) && futureStoppedPendingStopSASP.getStopDateTime().isAfter(saStartDate)) {
                //Update the SA's end date 
                ServiceAgreement pendingStopSA = futureStoppedPendingStopSASP.getServiceAgreement();
                ServiceAgreement_DTO pendingStopSA_DTO = pendingStopSA.getDTO();
                pendingStopSA_DTO.setEndDate(saStartDate);
                pendingStopSA.setDTO(pendingStopSA_DTO);
                
                //Update the SA/SP Record of the 
                ServiceAgreementServicePoint_DTO pendingStopSaSpDto = futureStoppedPendingStopSASP.getDTO();
                
                pendingStopSaSpDto.setStopDateTime(saSpStartDateTime);
                futureStoppedPendingStopSASP.setDTO(pendingStopSaSpDto);
                
                //Cancel any pending Stop Activity FAs on the Pending Stop SA
                cancelUnlinkPendingFa(futureStoppedPendingStopSASP, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
                
                //Link the created FA to the pending stop 
                createSaSpFa(futureStoppedPendingStopSASP, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }
        }

        if (saSpFieldActivityType.isStopActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date stop2Date = saSpStopDateTime.getDate().addDays(backToBackThresholdDays.intValue());

            for (ServiceAgreementServicePoint pendingStartSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , null, null, saSpStopDateTime.getDate(), stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY , Bool.FALSE)) {
                createSaSpFa(pendingStartSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
        }
        
    }

    /**
     * MM060 - Create SA/SP/FA record using the row maintenance.
     */
    private void createSaSpFa(ServiceAgreementServicePoint serviceAgreementServicePoint, FieldActivity fieldActivity
            , ServiceAgreementSpFaTypeLookup lookup) {

        ServiceAgreementSpFieldActivity_Id serviceAgreementSpFieldActivityId = new ServiceAgreementSpFieldActivity_Id(serviceAgreementServicePoint
                , fieldActivity);
        if (isNull(serviceAgreementSpFieldActivityId.getEntity())) {

            ServiceAgreementSpFieldActivity_DTO serviceAgreementSpFieldActivityDTO = new ServiceAgreementSpFieldActivity_DTO();
            serviceAgreementSpFieldActivityDTO.setFieldActivityType(lookup);
            serviceAgreementSpFieldActivityDTO.setServiceAgreementId(serviceAgreementServicePoint.getServiceAgreement().getId());
            serviceAgreementSpFieldActivityDTO.setServicePointId(serviceAgreementServicePoint.getServicePoint().getId());
            serviceAgreementSpFieldActivityDTO.setId(serviceAgreementSpFieldActivityId);
            serviceAgreementSpFieldActivityDTO.newEntity();
        }
        
    }

    /**
     * MK040 - Link the FA to the Pending Start and Pending Stop SA/SPs
     */
    private void linkSameType(FieldActivity fieldActivity) {
    	
        if (saSpFieldActivityType.isStartActivity()) {
        	//logger.info(">>>>> 1037" + saSpFieldActivityType);
            for (ServiceAgreementServicePoint pendingStartSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , null, null, saSpStartDateTime.getDate(), saSpStartDateTime.getDate(), ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY,Bool.FALSE)) {
                // Cancel field activity and disconnect from SA/SP
                cancelUnlinkPendingFa(pendingStartSaSp, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
                //logger.info(">>>>> 1042" + saSpFieldActivityType);
                // Link new FA to SA/SP
                createSaSpFa(pendingStartSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
        }

        if (saSpFieldActivityType.isStopActivity()) {

            for (ServiceAgreementServicePoint pendingStopSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , saSpStopDateTime.getDate(), saSpStopDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY , Bool.FALSE)) {
                // Cancel field activity and disconnect from SA/SP
                cancelUnlinkPendingFa(pendingStopSaSp, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);

                // Link new FA to SA/SP
                createSaSpFa(pendingStopSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }
        }
        
    }
    
}
