/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Charity Payment Segment Type - FT Creation Algorithm 
 * 
 * Create a To Do Entry when Pledge Payment is applied to an in-eligible
 * Service Agreement.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-09-27   JHERNA      SysAid#73573. Initial Version. Post v2.4 upgrade.
 * 2017-01-05	JHERNA		SysAid#179904. Incorrect Distribution Code used 
 * 							for Cash FT GL Details.
 * 2020-10-27   DLampa      B-17434. Remove To Do Creation.
 * *************************************************************************                
 */
package com.splwg.cm.domain.admin.paymentSegmentType.algorithm.ftCreation;

import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.entity.GeneralLedgerDistributionCode;
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.entity.GeneralLedgerDistributionCode_Id;
import com.splwg.ccb.domain.admin.paymentSegmentType.algorithm.ftCreation.PaymentSegmentTypeFinancialTransactionCreationAlgorithmSpot;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.financial.data.FinancialTransactionGeneralLedgerData;
import com.splwg.ccb.domain.payment.common.PaymentSegmentFtGlCreationHelper;
import com.splwg.ccb.domain.payment.payment.entity.PaymentSegment;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;

/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = featureConfiguration, name = featConfPledgePaymentReconciliation, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = toDoType, name = tdTypeInvalidPledgePayment, required = true, type = entity)})
 */
public class CmCharityPaymentFtCreationAlgComp_Impl 
		extends CmCharityPaymentFtCreationAlgComp_Gen 
		implements PaymentSegmentTypeFinancialTransactionCreationAlgorithmSpot {

	// Hard Parameters
	private Money hpOutputCurrentAmount;
	private Money hpOutputTotalAmount;
	private List<FinancialTransactionGeneralLedgerData> hpOutputCollOfFtGlData;
	private GeneralLedgerDistributionCode hpInputGlDistributionCode;
	private PaymentSegment hpInputPaymentSegment;
	
	// Algorithm Soft Parameters
	private FeatureConfiguration parmFeatConfPledgePaymentReconciliation;
	private ToDoType parmToDoTypeInvalidPledgePayment;	
	
	// Work Variable(s)
	private List<TenderSource_Id> collOfPledgeTenderSourceIDs;
	private List<String> collOfEligibleSaTypes;
	private CmMGEFeatureConfigurationOptionsRetriever featConfRetriever;
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		
		// Initialize hard parameter current amount
		hpOutputCurrentAmount = Money.ZERO;
		// Initialize hard parameter total amount
		hpOutputTotalAmount = Money.ZERO;
		// Initialize hard parameter collection of FT GL Data
		hpOutputCollOfFtGlData = new ArrayList<FinancialTransactionGeneralLedgerData>();
		// Retrieve Algorithm Parameter 10: Pledge Payment Reconciliation Feature Configuration
		parmFeatConfPledgePaymentReconciliation = this.getFeatConfPledgePaymentReconciliation();
		// Retrieve Algorithm Parameter 20: In-Eligible Payment Segment To Do Type
		parmToDoTypeInvalidPledgePayment = this.getTdTypeInvalidPledgePayment();
		// Initialize work variable(s)
		collOfPledgeTenderSourceIDs = new ArrayList<TenderSource_Id>();
		collOfEligibleSaTypes = new ArrayList<String>();
		featConfRetriever = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
	}

	@Override
	public Money getCurrentAmount() {
		return hpOutputCurrentAmount;
	}

	@Override
	public List<FinancialTransactionGeneralLedgerData> getFinancialTransactionGeneralLedgerData() {
		return hpOutputCollOfFtGlData;
	}

	@Override
	public Money getTotalAmount() {
		return hpOutputTotalAmount;
	}

	@Override
	public void setGeneralLedgerDistributionCode(
			GeneralLedgerDistributionCode arg0) {
		hpInputGlDistributionCode = arg0;

	}

	@Override
	public void setPaymentSegment(PaymentSegment arg0) {
		hpInputPaymentSegment = arg0;

	}

	@Override
	public void invoke() {

		/*
		 * Start Base Cobol CIPPFCAX functionality
		 */
		ServiceAgreement serviceAgreement = hpInputPaymentSegment.getServiceAgreement();
		GeneralLedgerDistributionCode_Id saTypeDistributionCodeID = serviceAgreement.getServiceAgreementType().getDistributionCode().getId();
		Money paymentSegmentAmount = hpInputPaymentSegment.getPaySegmentAmount();
		// Payments are Credit
		hpOutputCurrentAmount = paymentSegmentAmount.negate();
		hpOutputTotalAmount = Money.ZERO;
		
		// Set GL Details
		PaymentSegmentFtGlCreationHelper paySegFtGlCreationHelper = PaymentSegmentFtGlCreationHelper.Factory.newInstance();
		paySegFtGlCreationHelper.validateInput(hpInputPaymentSegment);
		
		// Create "A/R" FT GL Details Entry
		FinancialTransactionGeneralLedgerData arFtGlDetails = paySegFtGlCreationHelper.createFinancialTransactionGeneralLedgerDetail(
						Bool.FALSE, 
						saTypeDistributionCodeID,
						paymentSegmentAmount.negate());
		
		hpOutputCollOfFtGlData.add(arFtGlDetails);
		
		// Create Cash FT GL Details Entry
		FinancialTransactionGeneralLedgerData cashFtGlDetails = paySegFtGlCreationHelper.createFinancialTransactionGeneralLedgerDetail(
				Bool.FALSE,
				// START CHANGE - JHERNA - 2017-01-05 - SysAid#179904
				//saTypeDistributionCodeID,
				hpInputGlDistributionCode.getId(),
				// END CHANGE - JHERNA - 2017-01-05 - SysAid#179904
				paymentSegmentAmount);	
		
		hpOutputCollOfFtGlData.add(cashFtGlDetails);
		/*
		 * End Base Cobol CIPPFCAX functionality
		 */
		// Start Delete - 2020-10-27 - DLampa - B-17434
		/*
		 * Start SysAid#73573 - new functionality
		 */
		// Check if payment's tender source is for Pledges
		//Bool isPledgePayment = cmCheckPaymentTenderSource();
		
		//if (isPledgePayment.isTrue()) {
			
			// Check if pledge payment is being applied to an eligible Service Agreement
		//	Bool isSaEligibleForPledgePay = cmCheckSaTypeOfPledgePayment(serviceAgreement);
			
		//	if (isSaEligibleForPledgePay.isFalse()) {
		//		Payment inputPayment = hpInputPaymentSegment.getPayment();
				
				// create collection of sort keys
		//		List<String> collSortKeyValues = new ArrayList<String>();
		//		collSortKeyValues.add(inputPayment.getPaymentEvent().getId().getTrimmedValue());
				
				// create collection of drill keys
		//		List<String> collDrillKeyValues = new ArrayList<String>();
		//		collDrillKeyValues.add(inputPayment.getPaymentEvent().getId().getTrimmedValue());
				
				// Prepared Message ID to be used when creating the To Do Entry
		//		Message_Id messageID = CustomMessageRepositoryMGE.sa73573ToDoMessagePledgePaymentInvalid(
		//				serviceAgreement.getServiceAgreementType().fetchIdSaType().trim(),
		//				serviceAgreement.getId().getTrimmedValue(), 
		//				serviceAgreement.getAccount().getId().getTrimmedValue())
		//					.getMessageId();
				
				// Prepare Message Parameters to be used for the To Do Entry
		//		List<String> collOfMessageParms = new ArrayList<String>();
		//		collOfMessageParms.add(serviceAgreement.getServiceAgreementType().fetchIdSaType().trim());
		//		collOfMessageParms.add(serviceAgreement.getId().getTrimmedValue());
		//		collOfMessageParms.add(serviceAgreement.getAccount().getId().getTrimmedValue());
				
				// Create a To Do Entry
		//		cmCreateToDo(parmToDoTypeInvalidPledgePayment.getId(), messageID, collOfMessageParms, collSortKeyValues, collDrillKeyValues);
		//	}						
		//}		
		/*
		 * End SysAid#73573 - new funtionality
		 */
		// End Delete - 2020-10-27 - DLampa - B-17434
	}
	
	// Start Delete - 2020-10-27 - DLampa - B-17434
	//private void cmRetrieveCollOfPledgeTenderSource() {		
		
		// Initialize 
	//	collOfPledgeTenderSourceIDs = new ArrayList<TenderSource_Id>();
	//	CmMGEFeatureConfigurationOptionsRetriever featConfRoutine = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
		// Retrieve the option value (comma delimited)		
	//	String optVal = featConfRoutine.cmGetFeatOptValue(parmFeatConfPledgePaymentReconciliation.getId(),
	//			CmPledgePaymentsOptionTypeLookup.constants.PLEDGE_TENDER_SOURCE,
	//			Bool.TRUE,
	//			Bool.FALSE);
		
		// Retrieve, Validate and Store the valid pledge tender sources
	//	String[] strArrayOptVal = optVal.split(",");

	//	for (String pledgeTS : strArrayOptVal) {

	//		if (notBlank(pledgeTS)) {				
	//			TenderSource_Id tsID = new TenderSource_Id(pledgeTS.trim());
	//			if (notNull(tsID.getEntity())) {
	//				collOfPledgeTenderSourceIDs.add(tsID);
	//			}
	//		}
	//	}		
	//}	
	
	//private Bool cmCheckPaymentTenderSource() {
		
	//	Bool returnValue = Bool.FALSE;
		
		// Retrieve Pledge Tender Source
	//	cmRetrieveCollOfPledgeTenderSource();
		// transform collection of pledge tender source to one string
	//	String pledgeTenderSources = " ";
	//	Iterator<TenderSource_Id> iter = collOfPledgeTenderSourceIDs.iterator();
	//	while (iter.hasNext()) {
	//		TenderSource_Id tenderSourceID = iter.next();
	//		pledgeTenderSources = pledgeTenderSources.concat("'");
	//		pledgeTenderSources = pledgeTenderSources.concat(tenderSourceID.getTrimmedValue());
	//		pledgeTenderSources = pledgeTenderSources.concat("',");
	//	}
		// remove the extra comma at the end of the string
	//	pledgeTenderSources = pledgeTenderSources.substring(0, (pledgeTenderSources.length() - 1));
		
		// Check if the payment is for a pledge (checked via tender source)
	//	StringBuilder stringBuilder = new StringBuilder();
		
	//	stringBuilder.append("SELECT 'X' ");
	//	stringBuilder.append("FROM CI_PAY_SEG PS, "); 
	//	stringBuilder.append("      CI_PAY PAY, ");
	//	stringBuilder.append("      CI_PAY_EVENT PE, ");
	//	stringBuilder.append("      CI_PAY_TNDR PT, ");
	//	stringBuilder.append("      CI_TNDR_CTL TC ");
	//	stringBuilder.append("WHERE PS.PAY_SEG_ID = :paySegmentID ");
	//	stringBuilder.append("AND PAY.PAY_ID = PS.PAY_ID ");
	//	stringBuilder.append("AND PE.PAY_EVENT_ID = PAY.PAY_EVENT_ID ");
	//	stringBuilder.append("AND PT.PAY_EVENT_ID = PE.PAY_EVENT_ID ");
	//	stringBuilder.append("AND TC.TNDR_CTL_ID = PT.TNDR_CTL_ID ");
	//	stringBuilder.append("AND TC.TNDR_SOURCE_CD IN ( "+pledgeTenderSources.trim()+" ) ");
		
	//	PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=Check Pay Segment's Tender Source=");
	//	prepState.bindId("paySegmentID", hpInputPaymentSegment.getId());
	//	prepState.setAutoclose(false);
	//	prepState.execute();
		
	//	if (prepState.list().size() > 0) {
	//		returnValue = Bool.TRUE;			
	//	}		
	//	prepState.close();		
	//	return returnValue;
	//}
	
	//private void cmRetrieveCollOfEligibleSaTypes() {		

	//	collOfEligibleSaTypes = featConfRetriever.getListOfFeatureOptionValues(parmFeatConfPledgePaymentReconciliation.getId(), 
	//			CmPledgePaymentsOptionTypeLookup.constants.ELIGIBLE_PLEDGE_SA_TYPES);		
		
		
		// Initialize 
	//	collOfEligibleSaTypes = new ArrayList<String>();
	//	CmMGEFeatureConfigurationOptionsRetriever featConfRoutine = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
		// Retrieve the option value (comma delimited)		
	//	String optVal = featConfRoutine.cmGetFeatOptValue(parmFeatConfPledgePaymentReconciliation.getId(),
	//			CmPledgePaymentsOptionTypeLookup.constants.ELIGIBLE_PLEDGE_SA_TYPES,
	//			Bool.TRUE,
	//			Bool.FALSE);
		
		// Retrieve, Validate and Store the valid pledge tender sources		
	//	String[] strArrayOptVal = optVal.split(",");
		
	//	for (String saTypeStr : strArrayOptVal) {

	//		if (notBlank(saTypeStr)) {				
	//			Bool isValid = cmValidateSaType(saTypeStr);
	//			if (isValid.isTrue()) {
	//				collOfEligibleSaTypes.add(saTypeStr.trim());
	//			}
	//		}
	//	}
	//}
	
	//private Bool cmValidateSaType(String saType) {
		
	//	Bool returnValue = Bool.FALSE;
	//	StringBuilder stringBuilder = new StringBuilder();		
	//	stringBuilder.append("SELECT 'X' ");
	//	stringBuilder.append("FROM CI_SA_TYPE ");
	//	stringBuilder.append("WHERE SA_TYPE_CD = :saType ");
		
	//	PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=cmValidateSaType=");
	//	prepState.bindString("saType", saType.trim(), "SA_TYPE_CD");
	//	prepState.setAutoclose(false);
	//	prepState.execute();
	//	if (prepState.list().size() > 0) {
	//		returnValue = Bool.TRUE;
	//	}
	//	prepState.close();		
	//	return returnValue;
	//}
	
	//private Bool cmCheckSaTypeOfPledgePayment(ServiceAgreement serviceAgreement) {
		
	//	Bool returnValue = Bool.FALSE;
		
	//	cmRetrieveCollOfEligibleSaTypes();
		
	//	String inputSaType = serviceAgreement.getServiceAgreementType().fetchIdSaType().trim();
		
	//	if (collOfEligibleSaTypes.contains(inputSaType)) {
	//		returnValue = Bool.TRUE;
	//	}
		
	//	return returnValue;
	//}
	
	//private ToDoEntry cmCreateToDo(ToDoType_Id tdTypeID, Message_Id msgID, List<String> listOfMsgParms, 
	//		List<String> collSortKeyValues, List<String> collDrillKeyValues) {				
		
	//	ToDoEntry returnValue = null;
		
	//	ToDoCreator tdCreator = ToDoCreator.Factory.newInstance();
	//	ToDoEntry_DTO tdEntryDTO = tdCreator.getToDoDTO();
	//	tdEntryDTO.setCreationDateTime(this.getProcessDateTime());
	//	tdEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
	//	tdEntryDTO.setToDoTypeId(tdTypeID);
	//	tdEntryDTO.setToDoRoleId(tdTypeID.getEntity().getDefaultRole().fetchIdToDoRole().getId());		
	//	tdEntryDTO.setMessageId(msgID);
	//	tdCreator.setToDoDTO(tdEntryDTO);
		//---------set message parameter---------//
	//	for (int x = 0; x < listOfMsgParms.size(); x++) {
	//		String msgParm = (String) listOfMsgParms.get(x);
	//		tdCreator.addMessageParameter(msgParm);
	//	}
		
		
	//	List<ToDoSortKeyType> collOfSortKeyTypes = cmGetSortKeyTypes(tdTypeID);
		
	//	for (int x = 0; x < collOfSortKeyTypes.size(); x++) {
			
	//		ToDoSortKeyType tdSortKeyType = collOfSortKeyTypes.get(x);
	//		tdCreator.addSortKeyValue(tdSortKeyType, collSortKeyValues.get(x));
	//	}
		
	//	List<ToDoDrillKeyType> collOfDrillKeyTypes = cmGetDrillKeyTypes(tdTypeID);
		
	//	for (int x = 0; x < collOfDrillKeyTypes.size(); x++) {
			
	//		ToDoDrillKeyType tdDrillKeyType = collOfDrillKeyTypes.get(x);
	//		tdCreator.addDrillKeyValue(tdDrillKeyType, collDrillKeyValues.get(x));				
	//	}
				
	//	returnValue = tdCreator.create();			
	//	return returnValue;
	//}
	
	//private List<ToDoSortKeyType> cmGetSortKeyTypes(ToDoType_Id tdTypeID) {
		
	//	List<ToDoSortKeyType> returnValue = new ArrayList<ToDoSortKeyType>();
		
	//	StringBuilder stringBuilder = new StringBuilder();					
	//	stringBuilder.append("SELECT TD_TYPE_CD, SEQ_NUM ");
	//	stringBuilder.append("FROM CI_TD_SRTKEY_TY ");
	//	stringBuilder.append("WHERE TD_TYPE_CD = :tdTypeID ");
		
	//	PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=GET TO DO TYPE SORT KEYS");
	//	prepState.bindId("tdTypeID", tdTypeID);
	//	prepState.execute();
		
	//	if (prepState.list().size() > 0) {
			
	//		Iterator<SQLResultRow> iter = prepState.list().iterator();
			
	//		while (iter.hasNext()) {
			
	//			SQLResultRow sqlRow = (SQLResultRow) iter.next();					
	//			BigInteger seq = (BigInteger) sqlRow.getInteger("SEQ_NUM");
	//			ToDoSortKeyType_Id tdSortKeyTypeID = new ToDoSortKeyType_Id(tdTypeID, seq);
	//			returnValue.add(tdSortKeyTypeID.getEntity());
	//		}								
	//	}			
	//	prepState.close();
	//	return returnValue;
	//}
	
	//private List<ToDoDrillKeyType> cmGetDrillKeyTypes(ToDoType_Id tdTypeID) {
		
	//	List<ToDoDrillKeyType> returnValue = new ArrayList<ToDoDrillKeyType>();
		
	//	StringBuilder stringBuilder = new StringBuilder();					
	//	stringBuilder.append("SELECT TD_TYPE_CD, SEQ_NUM ");
	//	stringBuilder.append("FROM CI_TD_DRLKEY_TY ");
	//	stringBuilder.append("WHERE TD_TYPE_CD = :tdTypeID ");
		
	//	PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=GET TO DO TYPE DRILL KEYS=");
	//	prepState.bindId("tdTypeID", tdTypeID);
	//	prepState.execute();
		
	//	if (prepState.list().size() > 0) {
			
	//		Iterator<SQLResultRow> iter = prepState.list().iterator();
			
	//		while (iter.hasNext()) {
			
	//			SQLResultRow sqlRow = (SQLResultRow) iter.next();
	//			BigInteger seq = (BigInteger) sqlRow.getInteger("SEQ_NUM");
	//			ToDoDrillKeyType_Id tdDrillKeyTypeID = new ToDoDrillKeyType_Id(tdTypeID, seq);
	//			returnValue.add(tdDrillKeyTypeID.getEntity());
	//		}								
	//	}			
	//	prepState.close();
	//	return returnValue;
		
	//}
	// End Delete - 2020-10-27 - DLampa - B-17434
}