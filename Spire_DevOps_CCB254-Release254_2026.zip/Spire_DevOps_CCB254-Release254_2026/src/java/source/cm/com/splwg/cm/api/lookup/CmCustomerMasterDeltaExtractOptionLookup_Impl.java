/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Add or Update Action Flag Lookup 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2016-02-28   MPang     NI0019.3. Initial Version. 
 **************************************************************************/
package com.splwg.cm.api.lookup;
/**
 * @author mlekkala001
 *
 @LookupFieldname (value = XMDE_OPT_TYP_FLG)
 */
public class CmCustomerMasterDeltaExtractOptionLookup_Impl extends CmCustomerMasterDeltaExtractOptionLookup_Gen {

}
