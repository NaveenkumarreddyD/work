/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Change Log Table Purge Process
 * 
 * This program uses placeholders for the Oracle base table CI_CHG_LOG. 
 * 
 * This batch process removes unneeded records from the CI_CHG_LOG table.
 * Records can be identified by age, table name, or batch process.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2015-03-04   MCruz   MGE-CCB004.005 (CR3135978) Initial Version
 * 2016-01-27	MPang	Updated for CCB v2.4 compilation. 
 **************************************************************************
 */

package com.splwg.cm.domain.batch;

import java.math.BigInteger;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadIterationStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.SingleFieldId;
import com.splwg.base.domain.batch.batchControl.BatchControl;
import com.splwg.base.domain.database.table.Table;
//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
/*import com.splwg.cm.domain.common.customBusinessComponent.ChangeLogTable;
import com.splwg.cm.domain.common.customBusinessComponent.ChangeLogTable_Id;*/
import com.splwg.cm.domain.common.customBusinessComponent.ChangeLogTable;
import com.splwg.cm.domain.common.customBusinessComponent.ChangeLogTable_Id;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.shared.common.ApplicationError;

/**
 *
 @BatchJob (modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = batchControl, name = batchControl, type = entity)
 *            , @BatchJobSoftParameter (entityName = table, name = table, type = entity)
 *            , @BatchJobSoftParameter (name = numberOfDays, type = integer)})
 */
public class CmChangeLogTablePurgeBatch extends CmChangeLogTablePurgeBatch_Gen {

    public Class<CmChangeLogTablePurgeBatchWorker> getThreadWorkerClass() {
        return CmChangeLogTablePurgeBatchWorker.class;
    }

    public static class CmChangeLogTablePurgeBatchWorker extends
            CmChangeLogTablePurgeBatchWorker_Gen {

        private DateTime criteriaDateTime;
        private Table table;
        private BatchControl batchControl;
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new ThreadIterationStrategy(this);
        }
        
        @Override
        public void initializeThreadWork(boolean initializationPreviouslySuccessful) throws ThreadAbortedException, RunAbortedException {
            table = getParameters().getTable();
            batchControl = getParameters().getBatchControl();
            BigInteger numberOfDays = getParameters().getNumberOfDays();
            if (!isNull(numberOfDays)) {
                criteriaDateTime = getProcessDateTime().addDays(numberOfDays.negate().intValue());
            } else {
                criteriaDateTime = getProcessDateTime();
            }
            startEntityQueryIteratorForThread(ChangeLogTable_Id.class);
        }

        @Override
        protected QueryIterator getQueryIteratorForThread(SingleFieldId lowId, SingleFieldId highId) {
            
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("FROM ChangeLogTable as clt ");
            stringBuilder.append("WHERE clt.changeDateTime <= :criteriaDateTime ");
            if (notNull(table)) {
                stringBuilder.append("AND clt.tableId = :table ");
            }
            if (notNull(batchControl)) {
                stringBuilder.append("AND clt.batchControlId = :batchControl ");
            }
            stringBuilder.append("AND clt.id between :lowId and :highId ");
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //Query query = createQuery(stringBuilder.toString());
            Query query = createQuery(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            
            query.bindId("lowId", new ChangeLogTable_Id(lowId.toMap()));
            query.bindId("highId", new ChangeLogTable_Id(highId.toMap()));
            query.bindDateTime("criteriaDateTime", criteriaDateTime);
            if (notNull(table)) {
                query.bindEntity("table", table);
            }
            if (notNull(batchControl)) {
                query.bindEntity("batchControl", batchControl);
            }
            
            query.addResult("id", "clt");
            query.orderBy("id", 1);
            
            return query.iterate();
            
        }

        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
            
            ChangeLogTable_Id id = (ChangeLogTable_Id) unit.getPrimaryId();
            try {
                ChangeLogTable changeLogTable = id.getEntity();
                changeLogTable.delete();
            } catch (ApplicationError applicationError) {
                throw applicationError;
            } catch (Throwable e) {
                throw new ThreadAbortedException(e);
            }
            
            return true;
            
        }

    }

}
