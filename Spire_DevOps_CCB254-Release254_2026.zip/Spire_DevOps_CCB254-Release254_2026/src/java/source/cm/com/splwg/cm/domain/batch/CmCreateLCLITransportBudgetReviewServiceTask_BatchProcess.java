/*******************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * CCB023.3 - Create Transport Budget Service Task Batch
 *
 * This batch process will attempt to create a Transport Budget Service Task
 * for all eligble Transport SAs.
 * 
 ********************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2021-03-19	JVitug		Initial Version. 
 * 2021-07-30   GCrisp      CCB023.6. Add new default budget parameter
 ********************************************************************************/
package com.splwg.cm.domain.batch;

import java.util.Iterator;

import com.splwg.base.api.Query;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author jvitug
 *
 @BatchJob (modules = {}
 *      , multiThreaded = true
 *      , rerunnable = false
 *      , softParameters = { @BatchJobSoftParameter (entityName = serviceTaskType, name = TRANSPORT_SVC_TASK_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = DEFAULT_BUDGET_SW, required = true, type = boolean)})
 */
public class CmCreateLCLITransportBudgetReviewServiceTask_BatchProcess extends
	CmCreateLCLITransportBudgetReviewServiceTask_BatchProcess_Gen {
	
	// Soft Parameters
	ServiceTaskType serviceTaskType;

	// Constants
	private final String QUOTE = "'";
	private final String COMMA = ",";

	@Override
	public void validateSoftParameters(boolean isNewRun) {
		serviceTaskType = getParameters().getTRANSPORT_SVC_TASK_TYPE();
	}

	@Override
	public JobWork getJobWork() {
		return createJobWorkForEntityQuery(retrieveEligibleSAs());
	}
	
	private Query<ServiceAgreement> retrieveEligibleSAs(){
		//Read the service Task
		BusinessObjectInstance serviceTaskTypeBOInstance = BusinessObjectInstance.create(serviceTaskType.getBusinessObject());
        serviceTaskTypeBOInstance.set("serviceTaskType", serviceTaskType.getId().getTrimmedValue());
        serviceTaskTypeBOInstance = BusinessObjectDispatcher.read(serviceTaskTypeBOInstance);
        COTSInstanceNode budgetReviewDetails = serviceTaskTypeBOInstance.getGroup("budgetReviewDetails");
        
        String saTypes = getSATypes(budgetReviewDetails);
        String cisDivisions = getCisDivision(budgetReviewDetails);
        
        Query<ServiceAgreement> query = createQuery(
        		" FROM ServiceAgreement sa " +
				" WHERE sa.serviceAgreementType.id.saType IN (" + saTypes + ") " +
				" AND sa.serviceAgreementType.id.division IN (" + cisDivisions + ") " +
				" AND sa.status IN (:activeStatus, :pendingStopStatus) ", getClass().getName());
        
        query.bindLookup("activeStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
		query.bindLookup("pendingStopStatus", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        
        return query;
	}
	
	private String getSATypes(COTSInstanceNode budgetReviewDetails) {
		String saTypes = "";
		
		COTSInstanceList saTypesList = budgetReviewDetails.getList("eligibleSATypesList");
		Iterator<COTSInstanceListNode> saTypesIterator = saTypesList.iterator();
		int saTypesLength = saTypesList.getSize();
		int counter = 1;
		while(saTypesIterator.hasNext()) {
			COTSInstanceListNode node = saTypesIterator.next();
			
			if(!saTypes.contains(node.getString("saType").trim())){
				if(counter > (saTypesLength - 1)) {
					saTypes = saTypes + QUOTE + node.getString("saType").trim() + QUOTE;
				} else {
					saTypes = saTypes + QUOTE + node.getString("saType").trim() + QUOTE + COMMA;
				}
			}
			
			counter++;
		}
		
		if(saTypes.endsWith(COMMA)) {
			saTypes = saTypes.substring(0, saTypes.length()-1);
		}
		
		return saTypes;
	}
	
	private String getCisDivision(COTSInstanceNode budgetReviewDetails) {
		String cisDivision = "";
		
		COTSInstanceList saTypesList = budgetReviewDetails.getList("eligibleSATypesList");
		Iterator<COTSInstanceListNode> saTypesIterator = saTypesList.iterator();
		int saTypesLength = saTypesList.getSize();
		int counter = 1;
		while(saTypesIterator.hasNext()) {
			COTSInstanceListNode node = saTypesIterator.next();
			
			if(!cisDivision.contains(node.getString("cisDivision").trim())){
				if(counter > (saTypesLength - 1)) {
					cisDivision = cisDivision + QUOTE + node.getString("cisDivision").trim() + QUOTE;
				} else {
					cisDivision = cisDivision + QUOTE + node.getString("cisDivision").trim() + QUOTE + COMMA;
				}
			}
			
			counter++;
		}
		
		//If the variable used to store Division ends in comma which is possible
		//if there are multiple entries for the same CIS Division with different SA types
		//remove the last COMMA
		if(cisDivision.endsWith(COMMA)) {
			cisDivision = cisDivision.substring(0, cisDivision.length()-1);
		}
		
		return cisDivision;
	}
	
	public Class<CmCreateLCLITransportBudgetReviewServiceTask_BatchProcessWorker> getThreadWorkerClass() {
		return CmCreateLCLITransportBudgetReviewServiceTask_BatchProcessWorker.class;
	}

	public static class CmCreateLCLITransportBudgetReviewServiceTask_BatchProcessWorker extends
		CmCreateLCLITransportBudgetReviewServiceTask_BatchProcessWorker_Gen {

		//Working Variables
		private int SAsRetrievedCount = 0;
		private int serviceTaskCreatedCount = 0;
		
		//Batch parms
		private ServiceTaskType serviceTaskType;
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this); 
		}

		public boolean executeWorkUnit  (ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			ServiceAgreement_Id sa = (ServiceAgreement_Id) unit.getPrimaryId();
			SAsRetrievedCount++;
			
			serviceTaskType = getParameters().getTRANSPORT_SVC_TASK_TYPE();
			BusinessObject serviceTaskBO = serviceTaskType.getRelatedTransactionBO();

			BusinessObjectInstance boInstance =  BusinessObjectInstance.create(serviceTaskBO);
			boInstance.set("serviceTaskType" , serviceTaskType);
			boInstance.set("saId", sa.getTrimmedValue());
			boInstance.set("bo" , serviceTaskBO);
			// Start Add - CCB023.6 - GCrisp - 08-02-2021
			boInstance.set("defaultBudgetSw" , getParameters().getDEFAULT_BUDGET_SW().toString());
			// End Add - CCB023.6 - GCrisp - 08-02-2021
			BusinessObjectDispatcher.add(boInstance);
			serviceTaskCreatedCount++;
			
			return true; 
		}

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
			logMessage(CustomMessageRepositorySpireOne.ccb023_3_transportSAsRetrieved(
					String.valueOf(SAsRetrievedCount)), MessageSeverityLookup.constants.INFORMATIONAL);
			logMessage(CustomMessageRepositorySpireOne.ccb023_3_transportBudgetServiceTasksCreated(
					String.valueOf(serviceTaskCreatedCount)), MessageSeverityLookup.constants.INFORMATIONAL);
		}
	}
}
