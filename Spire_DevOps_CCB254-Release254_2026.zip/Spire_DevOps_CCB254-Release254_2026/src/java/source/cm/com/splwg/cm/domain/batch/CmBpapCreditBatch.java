/* ************************************************************************
 *                Confidentiality Information:
 *
 * This module is the confidential and proprietary information of
 * Oracle Corporation; it is not to be copied, reproduced, or
 * transmitted in any form, by any means, in whole or in part,
 * nor is it to be used for any purpose other than that for which
 * it is expressly provided without the written permission of
 * Oracle Corporation.
 *
 *
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * BPAP Credit Batch Process
 *
 * This batch process will create a BPAP Adjustment on the customer's SAs
 * which are enrolled in the low income program and are eligible for a BPAP
 * credit.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:        Reason:
 * YYYY-MM-DD   IN         Reason text.
 *
 * 2013-02-26   KLanot     NB0081. Initial Version.
 * 2016-01-27	MPang	   Updated for CCB v2.4 compilation.
 * 2018-07-25   SFelip     CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                         longer needed.
 ***************************************************************************/
package com.splwg.cm.domain.batch;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.AdjustmentStatusLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
//Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
//End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author KLanot
 *
 @BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = adjustmentType, name = BPAP_ADJUSTMENT_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = BPAP_CREDIT_CHAR_TYPE, required = true, type = entity)})
 */
public class CmBpapCreditBatch
    extends CmBpapCreditBatch_Gen {
	
	// Soft Parameter
	private CharacteristicType bpapCreditCharacteristicType;
	
	// Constants
	private static final String EMPTY_STRING = "";
	private static final String ZERO = "0";
      
    public JobWork getJobWork() {
    	Query<QueryResultRow> query = cmRetrieveBpapCreditServiceAgreements();		
		QueryIterator<QueryResultRow> qIter = query.iterate();
		
		return createJobWorkForQueryIterator(qIter, this);
    }
    
    /*
     * This method will retrieve all BPAP Credit Service Agreements
     */
    private Query<QueryResultRow> cmRetrieveBpapCreditServiceAgreements() {
    	
    	StringBuilder queryBuilder = new StringBuilder();
    	queryBuilder.append("FROM ServiceAgreement sa, ServiceAgreementCharacteristic saChar ");
    	queryBuilder.append("WHERE sa.id = saChar.id.serviceAgreement.id ");
    	queryBuilder.append("AND sa.status = :activeStatus ");
    	queryBuilder.append("AND saChar.id.characteristicType.id = :bpapCreditCharacteristicTypeId ");
    	//CCB v2.6 Upgrade - 2018-07-25 - Start Change
    	//queryBuilder.append("AND (TRIM(saChar.adhocCharacteristicValue) <> :zeroValue OR ");
    	//queryBuilder.append("TRIM(saChar.characteristicValue) <> :zeroValue OR ");
    	//queryBuilder.append("TRIM(saChar.characteristicValueForeignKey1) <> :zeroValue) ");
    	queryBuilder.append("AND (saChar.adhocCharacteristicValue <> :zeroValue OR ");
        queryBuilder.append("saChar.characteristicValue <> :zeroValue OR ");
        queryBuilder.append("saChar.characteristicValueForeignKey1 <> :zeroValue) ");
    	// CCB v2.6 Upgrade - 2018-07-25 - End Change
    	queryBuilder.append("AND saChar.id.effectiveDate = ( ");
    	queryBuilder.append("	SELECT MAX(saChar1.id.effectiveDate) FROM ServiceAgreementCharacteristic saChar1 ");
    	queryBuilder.append("	WHERE saChar1.id.serviceAgreement.id = saChar.id.serviceAgreement.id ");
    	queryBuilder.append("	AND saChar1.id.characteristicType.id = saChar.id.characteristicType.id ");
    	queryBuilder.append("	AND saChar1.id.effectiveDate <= :processDate) ");
    	//Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
    	//Query<QueryResultRow> saQuery = createQuery(queryBuilder.toString());
    	Query<QueryResultRow> saQuery = createQuery(queryBuilder.toString(), getClass().getName());
    	//End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
    	saQuery.bindLookup("activeStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
    	saQuery.bindId("bpapCreditCharacteristicTypeId", bpapCreditCharacteristicType.getId());
    	saQuery.bindDate("processDate", this.getProcessDateTime().getDate());
    	
    	CharacteristicTypeLookup bpapCreditCharTypeLookup = bpapCreditCharacteristicType.getCharacteristicType();
    	
    	if(bpapCreditCharTypeLookup.isAdhocValue() || bpapCreditCharTypeLookup.isFileLocationValue()) {
    		
    		saQuery.bindStringProperty("zeroValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, ZERO);
    		
    		saQuery.addResult("charValue", "saChar.adhocCharacteristicValue");
    		
    	} else if(bpapCreditCharTypeLookup.isPredefinedValue()) {
    		
    		saQuery.bindStringProperty("zeroValue", ServiceAgreementCharacteristic.properties.characteristicValue, ZERO);
    		
    		saQuery.addResult("charValue", "saChar.characteristicValue");
    		
    	} else if(bpapCreditCharTypeLookup.isForeignKeyValue()) {
    		
    		saQuery.bindStringProperty("zeroValue", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, ZERO);
    		
    		saQuery.addResult("charValue", "saChar.characteristicValueForeignKey1");
    		
    	}
    	
    	saQuery.addResult("saId", "sa.id");
    	
    	return saQuery;
    }
    
    /*
     * This method will create the Thread Work Unit per result row
     */
    public ThreadWorkUnit createWorkUnit(QueryResultRow resultRow) {
    	
    	ServiceAgreement_Id saId = (ServiceAgreement_Id) resultRow.getId("saId", ServiceAgreement.class);
    	String characteristicValue = resultRow.getString("charValue");

        ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        threadWorkUnit.setPrimaryId(saId);
        threadWorkUnit.addSupplementalData("charValue", characteristicValue);
    		
        return threadWorkUnit;
	}
    
    public void validateSoftParameters(boolean isNewRun) {
    	
    	// Retrieve BPAP Credit Characteristic Type
    	bpapCreditCharacteristicType = this.getParameters().getBPAP_CREDIT_CHAR_TYPE();
    	
    	// Check if BPAP Credit Characteristic Type is valid for the Service Agreement entity
    	CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(bpapCreditCharacteristicType, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT);
    	if(isNull(charEntityId.getEntity())) {
    		addError(CustomMessageRepositoryMDC.nb0081CharacteristicTypeIsInvalidForSaEntity(bpapCreditCharacteristicType.getId().getIdValue()));
    	}
    }

	public Class<CmBpapCreditBatchWorker> getThreadWorkerClass() {
        return CmBpapCreditBatchWorker.class;
    }

    public static class CmBpapCreditBatchWorker extends CmBpapCreditBatchWorker_Gen {
    	
    	// Soft Parameter
    	private AdjustmentType bpapAdjustmentType;
    	
    	// Working Variables
    	private ServiceAgreement_Id saId;
    	private String characteristicValue = EMPTY_STRING;

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

        public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
        	// Retrieve BPAP Adjustment Type parameter
        	bpapAdjustmentType = this.getParameters().getBPAP_ADJUSTMENT_TYPE();
        }

		protected boolean executeWorkUnit(ThreadWorkUnit threadWorkUnit) throws ThreadAbortedException, RunAbortedException {
			
			saId = (ServiceAgreement_Id) threadWorkUnit.getPrimaryId();
			characteristicValue = (String) threadWorkUnit.getSupplementallData("charValue");
			
			// Determine if there is Frozen BPAP Adjustment for the month
			Query adjustmentQuery = cmRetrieveFrozenBpapAdjustments();
			if(adjustmentQuery.list().size() >= 1) {
				return true;
			}
			
			ServiceAgreement sa = saId.getEntity();
			Money adjustmentAmount = Money.ZERO;
			
			try {
				adjustmentAmount = new Money(characteristicValue.trim(), sa.getAccount().getCurrency().getId());
			} catch(Exception e) {
				addError(CustomMessageRepositoryMDC.nb0081CharacteristicValueIsNotNumeric(saId.getIdValue(), characteristicValue.trim()));
			}
			
			// Create Adjustment
			CreateFrozenAdjustmentData createFrozenAdj = CreateFrozenAdjustmentData.Factory.newInstance();
			createFrozenAdj.setServiceAgreement(sa);                             
			createFrozenAdj.setAdjustmentType(bpapAdjustmentType);                              
			createFrozenAdj.setAdjustmentAmount(adjustmentAmount.negate());                                     
			createFrozenAdj.setAllowZeroAmount(Bool.FALSE);                                               
			createFrozenAdj = sa.createFrozenAdjustment(createFrozenAdj);
			
			return true;
		}
        
		/*
		 * This method will retrieve the SA's frozen adjustments within the month
		 */
        private Query cmRetrieveFrozenBpapAdjustments() {
        	
        	StringBuilder queryBuilder = new StringBuilder();
        	queryBuilder.append("FROM Adjustment adj, FinancialTransaction ft ");
        	queryBuilder.append("WHERE adj.serviceAgreement.id = :saId ");
        	queryBuilder.append("AND adj.adjustmentType.id = :adjustmentTypeId ");
        	queryBuilder.append("AND adj.adjustmentStatus = :frozenStatus ");
        	queryBuilder.append("AND adj.id = ft.siblingId ");
        	queryBuilder.append("AND ft.isFrozen = :frozenSwitch ");
        	queryBuilder.append("AND ft.financialTransactionType = :adjustmentFtType ");
        	queryBuilder.append("AND ft.freezeDateTime >= :firstDayOfMonth ");
        	queryBuilder.append("AND ft.freezeDateTime <= :lastDayOfMonth ");
        	//Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
        	//Query adjustmentQuery = createQuery(queryBuilder.toString());
        	Query adjustmentQuery = createQuery(queryBuilder.toString(), getClass().getName());
        	//End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
        	adjustmentQuery.bindId("saId", saId);
        	adjustmentQuery.bindId("adjustmentTypeId", bpapAdjustmentType.getId());
        	adjustmentQuery.bindLookup("frozenStatus", AdjustmentStatusLookup.constants.FROZEN);
        	adjustmentQuery.bindBoolean("frozenSwitch", Bool.TRUE);
        	adjustmentQuery.bindLookup("adjustmentFtType", FinancialTransactionTypeLookup.constants.ADJUSTMENT);
        	Date processDate = this.getProcessDateTime().getDate();
        	adjustmentQuery.bindDateTime("firstDayOfMonth", new Date(processDate.getYear(), processDate.getMonth(), 1).startOfDay());
        	adjustmentQuery.bindDateTime("lastDayOfMonth", new Date(processDate.getYear(), processDate.getMonth(), processDate.getMonthValue().getDaysInMonth()).endOfDay());
        	
        	adjustmentQuery.addResult("adjId", "adj.id");
        	
        	return adjustmentQuery;
        }

    }

}