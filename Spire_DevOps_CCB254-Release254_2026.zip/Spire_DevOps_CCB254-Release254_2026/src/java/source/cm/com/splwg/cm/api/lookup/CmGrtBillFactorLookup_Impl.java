/*
 **************************************************************************
 *                Confidentiality Information:                    
 *                                                                
 * This module is the confidential and proprietary information of 
 * Oracle Corporation; it is not to be copied, reproduced, or         
 * transmitted in any form, by any means, in whole or in part,    
 * nor is it to be used for any purpose other than that for which 
 * it is expressly provided without the written permission of     
 * Oracle Corporation.                                                
 *                                                                
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * GRT Bill Factor Lookup
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2012-11-06   BCordo  NI006.1. Initial Version.          
 **************************************************************************
 */
package com.splwg.cm.api.lookup;

/**
 * @author 95223
 *
 @LookupFieldname (value = XGRT_OPT_TYP_FLG)
 */
public class CmGrtBillFactorLookup_Impl extends CmGrtBillFactorLookup_Gen {

}
