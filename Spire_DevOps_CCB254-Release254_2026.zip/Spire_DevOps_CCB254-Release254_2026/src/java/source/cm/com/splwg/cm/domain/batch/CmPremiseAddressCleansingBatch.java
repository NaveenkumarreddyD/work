/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Premise Address Cleansing Batch Process
 * 
 * This batch program runs Vertex Address Cleansing on all Premises (with 
 * some exceptions). A Minimum Confidence Indicator parameter can be set 
 * to update the Premise with the suggested address automatically if the 
 * returned Vertex Confidence Indicator is equal to or greater than a 
 * certain threshold. Some Premise Types do not represent real addresses, 
 * so a list parameter can exempt those Types from being processed. Other 
 * relevant parameters are stored on the Vertex Configurations Feature 
 * Configuration.
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2021-02-23   NMendo     CCB011.3. Initial version.
 * 2021-04-27   NMendo     CCB011.Issue1. Set confidence indicator to 0 if 
 *                         Address 1 is not returned by Vertex. Handle 
 *                         Vertex error in Outbound Message.Corrected the 
 *                         number of records processed and records in error.
 *                         Warning when changing Premise address to the same 
 *                         address as another Premise, do not auto correct 
 *                         these addresses and considered it as Vertex 
 *                         validation issue. Add the Tax Area Id as 
 *                         Characteristic Value to Tax Jurisdiction 
 *                         Characteristic Type.
 * 2021-04-28   BMarquez   CCB011.Issue2. Add a zero to the end of the 
 *                         Tax Area ID if 9 digits are returned by Vertex.
 * 2021-04-27   NMendo     CCB011.Issue3. Update logic in getting 
 *                         jurisdictionDescr.
 * 2021-06-02   NMendo     CCB011.Issue4. Fix issue on file created when 
 *                         thread number is more than 1 digit. Move code 
 *                         that update vertexTaxJurisdiction.  
 * 2021-06-09   NMendo     CCB011.Issue5. Exempt Premise that comprised of
 *                         only Exempt SP Types. Do not include the Exempted 
 *                         Premise Types when comparing for Duplicate Premise 
 *                         Addresses. Add Address1 column in the output file.       
 *************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControl_Id;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationMessage;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.common.message.Message;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.outboundMessage.outboundMessage.OutboundMessage;
import com.splwg.base.domain.outboundMessage.outboundMessage.OutboundMessage_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.admin.premiseType.entity.PremiseType;
import com.splwg.ccb.domain.admin.premiseType.entity.PremiseType_Id;
import com.splwg.ccb.domain.admin.servicePointType.entity.ServicePointType;
import com.splwg.ccb.domain.admin.servicePointType.entity.ServicePointType_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristics;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_DTO;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.cm.api.lookup.CmVertexConfigurationLookup;
import com.splwg.cm.api.lookup.ExternalSystemTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ServerMessage;

/**
 * @author NMendo
 *
 @BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = MINIMUM_CONFIDENCE, type = integer)
 *            , @BatchJobSoftParameter (name = EXEMPT_PREM_TYPES, type = string)
 *            , @BatchJobSoftParameter (name = EXCEPTION_MODE, type = string)
 *            , @BatchJobSoftParameter (name = FILE_PATH, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, type = string)
 *            , @BatchJobSoftParameter (name = EXEMPT_SP_TYPES, type = string)})
 */
public class CmPremiseAddressCleansingBatch 
		extends CmPremiseAddressCleansingBatch_Gen {
	
	// Batch Parameters
	private static BigInteger parmMinimumConfidence;
	private static String parmExceptionMode;
	private static String parmFilePath;
	private static String parmFileName;
	
	// Constants
	private static final String FILE_STR = "FILE";
	private static final String TODO_STR = "TODO";
	private static final String MINIMUM_CONFIDENCE_STR = "MINIMUM_CONFIDENCE";
	private static final String EXEMPT_PREM_TYPES = "EXEMPT_PREM_TYPES";
	private static final String EXCEPTION_MODE_STR = "EXCEPTION_MODE";
	private static final String FILE_PATH_STR = "FILE_PATH";
	private static final String FILE_NAME_STR = "FILE_NAME";
	private static final String COMMA = ",";
	private static final String SINGLE_QUOTE = "'";
	private static final String SPACE = " ";
	private static final String YES = "Y";
	// Start Add - NMendo - CCB011.Issue5 -  2021-06-09
	private static final String EXEMPT_SP_TYPES = "EXEMPT_SP_TYPES";
	// End Add - NMendo - CCB011.Issue5 -  2021-06-09
	
	// Work Variables
	private static String exemptPremiseTypes;
	private CharacteristicType_Id premAddrCleanseExemptCharTypeId;
	private String premAddrCleanseExemptCharVal;
	private static Bool isTaxJurisdictionCharEnabled;
	private static CharacteristicType_Id taxJurisdictionCharTypeId;
	private CharacteristicTypeLookup premAddrCleanseExemptCharTypeLookup;
	private static FeatureConfiguration_Id featConfigID;
	// Start Add - NMendo - CCB011.Issue5 -  2021-06-09
	private String exemptSpTypes;
	// End Add - NMendo - CCB011.Issue5 -  2021-06-09
	
	@Override
    public JobWork getJobWork() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT P.PREM_ID ");
        if(isTaxJurisdictionCharEnabled.isTrue()) { 
        	stringBuilder.append(", (SELECT TRIM(PC.CHAR_VAL) || TRIM(PC.ADHOC_CHAR_VAL) || TRIM(PC.CHAR_VAL_FK1) ");
        	stringBuilder.append(   "FROM CI_PREM_CHAR PC ");
        	stringBuilder.append(   "WHERE PC.PREM_ID = P.PREM_ID ");
        	stringBuilder.append(   "AND PC.CHAR_TYPE_CD = :taxJurisdictionCharTypeId ");
        	stringBuilder.append(   "AND PC.EFFDT = (SELECT MAX(PC2.EFFDT) ");
        	stringBuilder.append(                   "FROM CI_PREM_CHAR PC2 ");
        	stringBuilder.append(                   "WHERE PC2.PREM_ID = P.PREM_ID ");
        	stringBuilder.append(                   "AND PC2.EFFDT <= :processDate ");
        	stringBuilder.append(                   "AND PC2.CHAR_TYPE_CD = PC.CHAR_TYPE_CD) ");
        	stringBuilder.append(   ") AS TAX_JURISDICTION ");
        }
        stringBuilder.append("FROM CI_PREM P ");
        stringBuilder.append("WHERE P.PREM_TYPE_CD NOT IN ("+ exemptPremiseTypes +") ");
        stringBuilder.append("AND NOT EXISTS (SELECT 'X' ");
        stringBuilder.append(                "FROM CI_PREM_CHAR PC3 ");
        stringBuilder.append(                "WHERE PC3.PREM_ID = P.PREM_ID ");
    	stringBuilder.append(                "AND PC3.EFFDT = (SELECT MAX(PC4.EFFDT) ");
    	stringBuilder.append(                                 "FROM CI_PREM_CHAR PC4 ");
    	stringBuilder.append(                                 "WHERE PC4.PREM_ID = P.PREM_ID ");
    	stringBuilder.append(                                 "AND PC4.EFFDT <= :processDate ");
    	stringBuilder.append(                                 "AND PC4.CHAR_TYPE_CD = PC3.CHAR_TYPE_CD) ");
        stringBuilder.append(                "AND PC3.CHAR_TYPE_CD = :premAddrCleanseExemptCharTypeId ");
        if(premAddrCleanseExemptCharTypeLookup.isAdhocValue() || premAddrCleanseExemptCharTypeLookup.isFileLocationValue()) {
        	stringBuilder.append(            "AND PC3.ADHOC_CHAR_VAL = :premAddrCleanseExemptCharVal) ");
        } else if(premAddrCleanseExemptCharTypeLookup.isPredefinedValue()) {
        	stringBuilder.append(            "AND PC3.CHAR_VAL = :premAddrCleanseExemptCharVal) ");
        } else if(premAddrCleanseExemptCharTypeLookup.isForeignKeyValue()) {
        	stringBuilder.append(            "AND PC3.CHAR_VAL_FK1 = :premAddrCleanseExemptCharVal) ");
        }
        // Start Add - NMendo - CCB011.Issue5 -  2021-06-09
        stringBuilder.append("AND (EXISTS (SELECT 'X' ");
        stringBuilder.append(             "FROM CI_SP SP ");
        stringBuilder.append(             "WHERE SP.PREM_ID = P.PREM_ID ");
        stringBuilder.append(             "AND SP.SP_TYPE_CD NOT IN (" + exemptSpTypes + ")) ");
        stringBuilder.append(     "OR NOT EXISTS (SELECT 'X' ");
        stringBuilder.append(                    "FROM CI_SP SP2 ");
        stringBuilder.append(                    "WHERE SP2.PREM_ID = P.PREM_ID)) ");
        // End Add - NMendo - CCB011.Issue5 -  2021-06-09

        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        if(isTaxJurisdictionCharEnabled.isTrue()) { 
        	preparedStatement.bindId("taxJurisdictionCharTypeId", taxJurisdictionCharTypeId);
        }
        preparedStatement.bindId("premAddrCleanseExemptCharTypeId", premAddrCleanseExemptCharTypeId);
        if(premAddrCleanseExemptCharTypeLookup.isAdhocValue() || premAddrCleanseExemptCharTypeLookup.isFileLocationValue()) {
        	preparedStatement.bindStringProperty("premAddrCleanseExemptCharVal", PremiseCharacteristic.properties.adhocCharacteristicValue, premAddrCleanseExemptCharVal);
        } else if(premAddrCleanseExemptCharTypeLookup.isPredefinedValue()) {
        	preparedStatement.bindStringProperty("premAddrCleanseExemptCharVal", PremiseCharacteristic.properties.characteristicValue, premAddrCleanseExemptCharVal);
        } else if(premAddrCleanseExemptCharTypeLookup.isForeignKeyValue()) {
        	preparedStatement.bindStringProperty("premAddrCleanseExemptCharVal", PremiseCharacteristic.properties.characteristicValueForeignKey1, premAddrCleanseExemptCharVal);
        }
        preparedStatement.bindDate("processDate", getProcessDateTime().getDate());
        preparedStatement.setAutoclose(true);
        preparedStatement.execute();
		QueryIterator returnValue = preparedStatement.iterate();
		
		return createJobWorkForQueryIterator(returnValue, this);
    }
    
    @Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow qrw) {
		ThreadWorkUnit twu = new ThreadWorkUnit();
		Premise_Id premiseId = (Premise_Id) qrw.getId("PREM_ID", Premise.class);
		twu.setPrimaryId(premiseId);
		if(isTaxJurisdictionCharEnabled.isTrue()) { 
			twu.addSupplementalData("TAX_JURISDICTION", qrw.getString("TAX_JURISDICTION"));
		}
		return twu;
	}
    
    @Override
    public void validateSoftParameters(boolean arg0) {
    	parmMinimumConfidence = getParameters().getMINIMUM_CONFIDENCE();
    	parmExceptionMode = getParameters().getEXCEPTION_MODE();
    	parmFilePath = getParameters().getFILE_PATH();
    	parmFileName = getParameters().getFILE_NAME();
    	String parmExemptPremiseTypes = getParameters().getEXEMPT_PREM_TYPES();
    	// Start Add - NMendo - CCB011.Issue5 -  2021-06-09
    	String parmExemptSpTypes = getParameters().getEXEMPT_SP_TYPES();
    	// End Add - NMendo - CCB011.Issue5 -  2021-06-09
    	BatchControl_Id batchCd = getBatchControlId();
    	
    	if(notNull(parmMinimumConfidence) 
    			&& (parmMinimumConfidence.compareTo(BigInteger.ZERO) < 0 
    					|| parmMinimumConfidence.compareTo(BigInteger.valueOf(100)) > 0)) {
    		// Batch Parameter %1 must be a value from 0 to 100.
    		addError(CustomMessageRepositorySpireOne.CCB011_minimumConfidenceInvalid(MINIMUM_CONFIDENCE_STR));
    	}
    	
    	exemptPremiseTypes = SINGLE_QUOTE.concat(SPACE).concat(SINGLE_QUOTE);
    	if(notNull(parmExemptPremiseTypes)) {
    		String[] exemptPremiseTypesSplitted = parmExemptPremiseTypes.split(COMMA);
    		int index = 0;
    		String premiseTypeStr = null;
    		StringBuilder premiseTypeBuilder = new StringBuilder();
    		for(String exemptPremiseType : exemptPremiseTypesSplitted) {
    			index++;
    			premiseTypeStr = exemptPremiseType.trim();
    			PremiseType premiseType = new PremiseType_Id(premiseTypeStr).getEntity();
    			
    			if(isNull(premiseType)) {
    				// Batch Parameter %1 contains invalid Premise Type (%2).
    				addError(CustomMessageRepositorySpireOne.CCB011_premiseTypeInvalid(EXEMPT_PREM_TYPES, premiseTypeStr));
    			}
    			
    			if(index > 1) {
    				premiseTypeBuilder.append(COMMA);
    			}
    			
    			premiseTypeBuilder.append(SINGLE_QUOTE);
    			premiseTypeBuilder.append(premiseTypeStr);
    			premiseTypeBuilder.append(SINGLE_QUOTE);
    		}
    		exemptPremiseTypes = premiseTypeBuilder.toString();
    	}
    	
    	// Start Add - NMendo - CCB011.Issue5 -  2021-06-09
    	exemptSpTypes = SINGLE_QUOTE.concat(SPACE).concat(SINGLE_QUOTE);
    	if(notNull(parmExemptSpTypes)) {
    		String[] exemptSpTypesSplitted = parmExemptSpTypes.split(COMMA);
    		int index = 0;
    		String spTypeStr = null;
    		StringBuilder spTypeBuilder = new StringBuilder();
    		for(String exemptSpType : exemptSpTypesSplitted) {
    			index++;
    			spTypeStr = exemptSpType.trim();
    			ServicePointType spType = new ServicePointType_Id(spTypeStr).getEntity();
    			
    			if(isNull(spType)) {
    				// Batch Parameter %1 contains invalid SP Type (%2).
    				addError(CustomMessageRepositorySpireOne.CCB011_spTypeInvalid(EXEMPT_SP_TYPES, spTypeStr));
    			}
    			
    			if(index > 1) {
    				spTypeBuilder.append(COMMA);
    			}
    			
    			spTypeBuilder.append(SINGLE_QUOTE);
    			spTypeBuilder.append(spTypeStr);
    			spTypeBuilder.append(SINGLE_QUOTE);
    		}
    		exemptSpTypes = spTypeBuilder.toString();
    	}
    	// End Add - NMendo - CCB011.Issue5 -  2021-06-09
    	
    	if(notNull(parmExceptionMode)) {
    		if(parmExceptionMode.equals(FILE_STR)) {
    			if(isNull(parmFilePath)) {
    				// Batch Parameter %1 is required when Batch Parameter %2 value is 'FILE'.
    				addError(CustomMessageRepositorySpireOne.CCB011_batchParmRequired(FILE_PATH_STR, EXCEPTION_MODE_STR));
    			}
    			
    			if(isNull(parmFileName)) {
    				// Batch Parameter %1 is required when Batch Parameter %2 value is 'FILE'.
    				addError(CustomMessageRepositorySpireOne.CCB011_batchParmRequired(FILE_NAME_STR, EXCEPTION_MODE_STR));
    			}
    			
    			File fileValidator = new File(parmFilePath.trim());		
    			if (isNull(fileValidator) || !fileValidator.isDirectory()) {
    				// Batch Parameter %1 value (%2) is an invalid file path.
    				addError(CustomMessageRepositorySpireOne.CCB011_filePathInvalid(FILE_PATH_STR, parmFilePath.trim()));
    			}
    			
    		} else if(parmExceptionMode.equals(TODO_STR)) {
    			if(isNull(retrieveBatchToDoType(batchCd))) {
    				// There is no To Do Type with Batch Process %1 as its Creation Process.
        			addError(CustomMessageRepositorySpireOne.CCB011_noTodoTypeForBatchControl(batchCd.getTrimmedValue()));
    			}
    			
    		} else {
    			// Batch Parameter %1 value (%2) is invalid. Valid values are: FILE, TODO.
    			addError(CustomMessageRepositorySpireOne.CCB011_exceptionModeInvalid(EXCEPTION_MODE_STR, parmExceptionMode.trim()));
    		}
    	}
    	
    	// Retrieve Feature Configuration
    	CmMGEFeatureConfigurationOptionsRetriever featureConfigRetriever = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
    	featConfigID = featureConfigRetriever.getFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_VERTEX_CONFIGURATION);
    	
    	// Retrieve Premise Address Cleanse Exemption Char Type
    	premAddrCleanseExemptCharTypeId = featureConfigRetriever.getCharacteristicTypeFeatureOptionValue(featConfigID,
    			CmVertexConfigurationLookup.constants.CM_PREMISE_ADDRESS_CLEANSE_EXEMPTION_CHAR_TYPE, Bool.TRUE, Bool.TRUE,
    			CharacteristicEntityLookup.constants.PREMISE);
    	CharacteristicType premAddrCleanseExemptCharType = premAddrCleanseExemptCharTypeId.getEntity();
    	
    	// Retrieve Premise Address Cleanse Exemption Char Value
    	CmVertexConfigurationLookup premAddrCleanseExemptCharValOpt = CmVertexConfigurationLookup.constants.CM_PREMISE_ADDRESS_CLEANSE_EXEMPTION_CHAR_VAL;
    	premAddrCleanseExemptCharVal = featureConfigRetriever.getFeatureOptionValue(featConfigID, premAddrCleanseExemptCharValOpt, Bool.TRUE, Bool.TRUE);
    	
    	premAddrCleanseExemptCharTypeLookup = premAddrCleanseExemptCharType.getCharacteristicType();
    	if(premAddrCleanseExemptCharTypeLookup.isPredefinedValue()) {
    		// Premise Address Cleanse Exemption Char Value should be valid for Premise Address Cleanse Exemption Char Type
    		CharacteristicValue_Id premAddrCleanseExemptCharValId = new CharacteristicValue_Id(premAddrCleanseExemptCharType, premAddrCleanseExemptCharVal);
        	if(isNull(premAddrCleanseExemptCharValId.getEntity())) {
        		// Feature Configuration %1 Option % value (%3) is an invalid Characteristic Value for Characteristic Type %4.
        		addError(CustomMessageRepositorySpireOne.CCB011_featConfigCharValInvalid(featConfigID.getTrimmedValue(), 
        				premAddrCleanseExemptCharValOpt.getLookupValue().fetchLanguageDescription(), 
        				premAddrCleanseExemptCharVal, premAddrCleanseExemptCharTypeId.getTrimmedValue()));
        	}
    	}
    	
    	isTaxJurisdictionCharEnabled = Bool.FALSE;
    	String isTaxJurisdictionCharEnabledStr = featureConfigRetriever.getFeatureOptionValue(featConfigID, 
    			CmVertexConfigurationLookup.constants.CM_IS_TAX_JURISDICTION_CHAR_ENABLED, Bool.TRUE, Bool.TRUE);
    	if(isTaxJurisdictionCharEnabledStr.equalsIgnoreCase(YES)) {
    		isTaxJurisdictionCharEnabled = Bool.TRUE;
    		
    		taxJurisdictionCharTypeId = featureConfigRetriever.getCharacteristicTypeFeatureOptionValue(featConfigID,
    				CmVertexConfigurationLookup.constants.CM_TAX_JURISDICTION_CHAR_TYPE, Bool.TRUE, Bool.TRUE,
        			CharacteristicEntityLookup.constants.PREMISE);
    	}
    }
    
    /**
     * Retrieve To Do Type where Creation Batch Process is the input batchCd.
     * @param batchCd
     * @return ToDoType
     */
    private ToDoType retrieveBatchToDoType(BatchControl_Id batchCd) {
    	ToDoType batchToDoType = null;
    	
    	StringBuilder sb = new StringBuilder();
    	sb.append("SELECT TD_TYPE_CD ");
    	sb.append("FROM CI_TD_TYPE ");
    	sb.append("WHERE CRE_BATCH_CD = :batchCd ");
    	
    	PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
    	ps.bindId("batchCd", batchCd);
    	
    	SQLResultRow result = ps.firstRow();
    	ps.close();
    	
    	if(notNull(result)) {
    		String batchToDoTypeStr = result.getString("TD_TYPE_CD");
    		batchToDoType = new ToDoType_Id(batchToDoTypeStr).getEntity();
    	}
    	
    	return batchToDoType;
    }

    public Class<CmPremiseAddressCleansingBatchWorker> getThreadWorkerClass() {
        return CmPremiseAddressCleansingBatchWorker.class;
    }

    public static class CmPremiseAddressCleansingBatchWorker extends 
    		CmPremiseAddressCleansingBatchWorker_Gen {
    	
    	// Constants
    	private static final String BACKSLASH = "/";
    	private static final String FORWARDSLASH = "\\";
    	private static final String PERIOD = ".";
    	private static final String DOUBLE_QUOTE = "\"";
    	private static final String CARRIAGE_RETURN_LINE_FEED = "\r\n";
    	private static final String PREMISE_ID_HEADER = "Premise ID";
    	private static final String STATE_HEADER = "State";
    	private static final String COUNTY_HEADER = "County";
    	private static final String CONFIDENCE_INDICATOR_HEADER = "Confidence Indicator";
    	private static final String ERROR_MESSAGE_HEADER = "Error Message";
    	private static final String ADDRESS_VERIFICATION_BO = "CM-AddressVerificationVertex";
    	//Start Add - NMendo - CCB011.Issue1 - 2021-04-27
    	private static final String DUMMY_VERTEX_CODE = "E000";
    	private static final String ZERO = "0";
    	//Start Add - NMendo - CCB011.Issue1 - 2021-04-27
    	// Start Add - NMendo - CCB011.Issue5 -  2021-06-09
    	private static final String ADDRESS1_HEADER = "Address1";
    	// End Add - NMendo - CCB011.Issue5 -  2021-06-09
    	
    	// Work Variables
    	private BatchControl_Id batchControlId;
    	private String filePathName;
    	private BufferedWriter buffWriter;
    	private ToDoType toDoType;
    	private String premiseIdStr;
    	private int numberOfAddress;
    	private int numberOfFailedCall;
    	private int numberOfUpdatedPremise;
    	private int numberOfAddressRequiringAttention;
    	private String vertexAddress1;
    	private String vertexAddress2;
    	private String vertexCity;
    	private String vertexState;
    	private String vertexPostal;
    	private String vertexCounty;
    	private String vertexTaxJurisdiction;
    	private Bool shouldUpdateAddress;
    	private Bool shouldAddTaxJurisdictionChar;
    	// Start Add - NMendo - CCB011.Issue1 - 2021-04-27
    	private String jurisdictionDescr;
		private Premise_Id premiseId;
    	// End Add - NMendo - CCB011.Issue1 - 2021-04-27
        
        @Override
        public void initializeThreadWork(boolean initializationPreviouslySuccessful) throws ThreadAbortedException, RunAbortedException {
        	// Initialize variables
        	numberOfAddress = 0;
        	numberOfFailedCall = 0;
        	numberOfUpdatedPremise = 0;
        	numberOfAddressRequiringAttention = 0;
        	
        	batchControlId = getBatchControlId();
        	toDoType = getToDoTypeForBatch(batchControlId);
        	
        	if(notNull(parmExceptionMode) && parmExceptionMode.equals(FILE_STR)) {
        		// Form file path name and write file header
            	formFilePathName();
            	openFile();
            	writeFileHeader();
        	}
        }

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }
        
        @Override
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit threadWorkUnit)
				throws ThreadAbortedException, RunAbortedException {
            
        	premiseId = (Premise_Id)threadWorkUnit.getPrimaryId();
        	Premise premise = premiseId.getEntity();
        	premiseIdStr = premiseId.getTrimmedValue();
        	String currentTaxJurisdiction = (String) threadWorkUnit.getSupplementallData("TAX_JURISDICTION");
        	
        	//Start Add - NMendo - CCB011.Issue1 - 2021-04-27
        	numberOfAddress = 0;
        	numberOfFailedCall = 0;
        	//End Add - NMendo - CCB011.Issue1 - 2021-04-27
        	
        	// Use the Address Cleansing on Premise address
			procesAddress(premise.getAddress1(), premise.getAddress2(), premise.getCity(), premise.getState(), 
					premise.getPostal(), premise.getCounty(), currentTaxJurisdiction);
			
			if(shouldAddTaxJurisdictionChar.isTrue()) {
				// Add Tax Jurisdiction Characteristic to Premise
				addTaxJurisdictionChar(premise, currentTaxJurisdiction);
			}
			
			if(shouldUpdateAddress.isTrue()) {
				// Update the Premise Address with the new information
				Premise_DTO premiseDto = premise.getDTO();
				premiseDto.setAddress1(vertexAddress1);
				premiseDto.setAddress2(vertexAddress2);
				premiseDto.setCity(vertexCity);
				premiseDto.setState(vertexState);
				premiseDto.setPostal(vertexPostal);
				premiseDto.setCounty(vertexCounty);
				premise.setDTO(premiseDto);
			}
			
			if(shouldAddTaxJurisdictionChar.isTrue() || shouldUpdateAddress.isTrue()) {
				numberOfUpdatedPremise++;
			}
			
			WorkUnitResult result = new WorkUnitResult(true);
			// Records Processed is the total number of Address retrieved 
            result.setUnitsProcessed(numberOfAddress);
            // Records in Error is the count of times the Vertex call failed 
            result.setUnitsInError(numberOfFailedCall);
            
			return result;
        }
        
        /**
         * Address Cleansing Process
         * @param address1
         * @param address2
         * @param city
         * @param state
         * @param postal
         * @param county
         */
        private void procesAddress(String address1, String address2, String city, String state, String postal, 
        		String county, String currentTaxJurisdiction) {
        	numberOfAddress++;
        	shouldUpdateAddress = Bool.FALSE;
        	shouldAddTaxJurisdictionChar = Bool.FALSE;
        	vertexAddress1 = "";
        	vertexAddress2 = "";
        	vertexCity = "";
        	vertexState = "";
        	vertexPostal = "";
        	vertexCounty = "";
        	vertexTaxJurisdiction = "";
        	String confidenceIndicator = "";
    		String vertexCode = "";
    		String errorMessage = "";
        	
        	String inputAddress1 = address1.trim().toUpperCase();
        	String inputAddress2 = address2.trim().toUpperCase();
        	String inputCity = city.trim().toUpperCase();
        	String inputState = state.trim().toUpperCase();
        	String inputPostal = postal.trim().toUpperCase();
        	String inputCounty = county.trim().toUpperCase();
        	
        	// Validate the address with Vertex
        	BusinessObject_Id boId = new BusinessObject_Id(ADDRESS_VERIFICATION_BO);
        	BusinessObjectInstance vertexInput = BusinessObjectInstance.create(boId.getEntity());
        	
        	COTSInstanceNode vertexEnvelope = vertexInput.getGroup("VertexEnvelope");
        	COTSInstanceNode taxAreaRequest = vertexEnvelope.getGroup("TaxAreaRequest");
        	COTSInstanceNode taxAreaLookup = taxAreaRequest.getGroup("TaxAreaLookup");
        	COTSInstanceNode postalAddress = taxAreaLookup.getGroup("PostalAddress");
        	
        	postalAddress.set("StreetAddress1", inputAddress1);
        	postalAddress.set("StreetAddress2", inputAddress2);
        	postalAddress.set("City", inputCity);
        	postalAddress.set("MainDivision", inputState);
        	postalAddress.set("PostalCode", inputPostal);

        	BusinessObjectInstance vertexOutput = null;
    		try{
    			vertexOutput = BusinessObjectDispatcher.add(vertexInput);
    		} catch(Exception e) {
    			// Log the Application Error message as an error
    		    logError(CustomMessageRepositorySpireOne.CCB011_applicationError(e.getMessage()));
    		    numberOfFailedCall++;
    		    return;
    		}
    		
    		String outMsgId = vertexOutput.getString("outboundMsgId");
			if(notNull(outMsgId)) {
				OutboundMessage outMsg = new OutboundMessage_Id(outMsgId).getEntity();
				
				if(outMsg.getStatus().isError()) {
					//Start Change - NMendo - CCB011.Issue1 - 2021-04-27
					// Log the Outbound Message Error Details
	    		    //logError(CustomMessageRepositorySpireOne.CCB011_applicationError(outMsg.getErrorDetails()));
	    		    //numberOfFailedCall++;
	    		    //return;
					String errorDetails = outMsg.getErrorDetails();
					if(errorDetails.contains("VertexInvalidAddressException") && errorDetails.contains("fault code=") && errorDetails.contains("fault code text=")) {
						Pattern errorCodePattern = Pattern.compile("([(]fault code=).*?,");
					    Matcher errorCodeMatcher = errorCodePattern.matcher(errorDetails);
					    while (errorCodeMatcher.find()) {
					    	String errorCode = errorCodeMatcher.group();
					    	errorCode = errorCode.replaceFirst("[(]fault code=", "");
					    	errorCode = errorCode.replace(COMMA, "");
					    	vertexCode = errorCode.trim();
					    	break;
					    }
					    
					    Pattern errorMsgPattern = Pattern.compile("(, fault code text=).*?[)]");
					    Matcher errorMsgMatcher = errorMsgPattern.matcher(errorDetails);
					    while (errorMsgMatcher.find()) {
					    	String errorCodeText = errorMsgMatcher.group();
					    	errorCodeText = errorCodeText.replaceFirst(", fault code text=", "");
					    	errorCodeText = errorCodeText.replace(")", "");
					    	errorMessage = errorCodeText.trim();
					    	break;
					    }
					    
					    if(isBlankOrNull(vertexCode) || isBlankOrNull(errorMessage)) {
					    	// Log the Outbound Message Error Details
			    		    logError(CustomMessageRepositorySpireOne.CCB011_applicationError(errorDetails));
			    		    numberOfFailedCall++;
			    		    return;
					    }
					    
					} else {
						// Log the Outbound Message Error Details
		    		    logError(CustomMessageRepositorySpireOne.CCB011_applicationError(errorDetails));
		    		    numberOfFailedCall++;
		    		    return;
		    		//End Change - NMendo - CCB011.Issue1 - 2021-04-27
					}
				}
			}
    		
    		COTSInstanceNode responseDetails = vertexOutput.getGroup("responseDetails");
    		COTSInstanceNode responseVertexEnvelope = responseDetails.getGroup("VertexEnvelope");
    		COTSInstanceNode taxAreaResponse = responseVertexEnvelope.getGroup("TaxAreaResponse");
    		COTSInstanceNode taxAreaResult = taxAreaResponse.getGroup("TaxAreaResult");
    		COTSInstanceNode vertexPostalAddress = taxAreaResult.getGroup("PostalAddress");
    		
    		String vertexTaxJusrisdictionStr = taxAreaResponse.getString("taxAreaId");
    		if(notNull(vertexTaxJusrisdictionStr)) {
    			vertexTaxJurisdiction = vertexTaxJusrisdictionStr.trim();
    			
    			// Start Add - NMendo - CCB011.Issue4 -  2021-06-02
    			// For Alabama and Gulf Jurisdiction Code returned by Vertex is 8 digits
    			if(vertexTaxJurisdiction.length() == 8) {
    				// Add Leading and Trailing ZERO
    				vertexTaxJurisdiction = ZERO.concat(vertexTaxJurisdiction).concat(ZERO);
    			}
    	        
    			// When Missouri Jurisdiction Code returned by Vertex is 9 digits
                if(vertexTaxJurisdiction.length() == 9) {
                    // Add Trailing ZERO
                    vertexTaxJurisdiction = vertexTaxJurisdiction.concat(ZERO);
                }
    			// End Add - NMendo - CCB011.Issue4 -  2021-06-02
    		}
    		
    		if(isTaxJurisdictionCharEnabled.isTrue() && !isBlankOrNull(vertexTaxJurisdiction)
    				&& !vertexTaxJurisdiction.equals(currentTaxJurisdiction)) {
    			shouldAddTaxJurisdictionChar = Bool.TRUE;
    		}
    		
    		String vertexAddress1Str = vertexPostalAddress.getString("StreetAddress1");
    		String vertexAddress2Str = vertexPostalAddress.getString("StreetAddress2");
    		String vertexCityStr = vertexPostalAddress.getString("City");
    		String vertexStateStr = vertexPostalAddress.getString("MainDivision");
    		String vertexPostalStr = vertexPostalAddress.getString("PostalCode");
    		String vertexCountyStr = vertexPostalAddress.getString("SubDivision");
    		
    		if(notNull(vertexAddress1Str)) {
    			vertexAddress1 = vertexAddress1Str.trim().toUpperCase();
    		}
    		if(notNull(vertexAddress2Str)) {
    			vertexAddress2 = vertexAddress2Str.trim().toUpperCase();
    		}
    		if(notNull(vertexCityStr)) {
    			vertexCity = vertexCityStr.trim().toUpperCase();
    		}
    		if(notNull(vertexStateStr)) {
    			vertexState = vertexStateStr.trim().toUpperCase();
    		}
    		if(notNull(vertexPostalStr)) {
    			vertexPostal = vertexPostalStr.trim().toUpperCase();
    		}
    		if(notNull(vertexCountyStr)) {
    			vertexCounty = vertexCountyStr.trim().toUpperCase();
    		}
    		
    		// Start Change - NMendo - CCB011.Issue3 -  2021-05-06
    		// Start Add - NMendo - CCB011.Issue1 - 2021-04-27
    		//String stateJurisdiction = taxAreaResult.getString("stateJurisdiction");
    		//String countyJurisdiction = taxAreaResult.getString("countyJurisdiction");
    		//String cityJurisdiction = taxAreaResult.getString("cityJurisdiction");
    		//String districtJurisdiction = taxAreaResult.getString("districtJurisdiction");
    		//if(notNull(districtJurisdiction)) {
    		//	jurisdictionDescr = districtJurisdiction.trim();
    		//} else if(notNull(cityJurisdiction)) {
    		//	jurisdictionDescr = cityJurisdiction.trim();
    		//} else if(notNull(countyJurisdiction)) {
    		//	jurisdictionDescr = countyJurisdiction.trim();
    		//} else if(notNull(stateJurisdiction)) {
    		//	jurisdictionDescr = stateJurisdiction.trim();
    		//} else {
    		//	jurisdictionDescr = vertexCity;
    		//}
    		// End Add - NMendo - CCB011.Issue1 - 2021-04-27
    		
    		jurisdictionDescr = vertexCity;
    		COTSInstanceList jurisdictionsList = taxAreaResult.getList("jurisdictions");
    		
    		int lowestLevel = 100;
    		Date lowestLevelEffDate = getProcessDateTime().getDate();
    		String lowestLevelJurisdiction = null;
			Iterator<COTSInstanceListNode> jurisdictionsIter = jurisdictionsList.iterator();
			while(jurisdictionsIter.hasNext()) {
				COTSInstanceListNode jurisdictionsNode = jurisdictionsIter.next();
				String jurisdictioLevel = jurisdictionsNode.getString("level");
				Date effectiveDate = jurisdictionsNode.getDate("effectiveDate");
				String jurisdiction = jurisdictionsNode.getString("jurisdiction");
				
				int level = 0;
				if(jurisdictioLevel.equals("DISTRICT")) {
					level = 1;
				} else if(jurisdictioLevel.equals("CITY")) {
					level = 2;
				} else if(jurisdictioLevel.equals("COUNTY")) {
					level = 3;
				} else if(jurisdictioLevel.equals("STATE")) {
					level = 4;
				} else {
					level = 5;
				}
				
				if(level < lowestLevel || (level == lowestLevel && effectiveDate.isSameOrAfter(lowestLevelEffDate))) {
					lowestLevel = level;
					lowestLevelEffDate = effectiveDate;
					lowestLevelJurisdiction = jurisdiction;
				}
			}
			
			if(notNull(lowestLevelJurisdiction)) {
				jurisdictionDescr = lowestLevelJurisdiction;
			}
    		// End Change - NMendo - CCB011.Issue3 -  2021-05-06
    		
    		// Compare Address to the Vertex information, if all fields are the same
    		if(inputAddress1.equals(vertexAddress1) && inputAddress2.equals(vertexAddress2) && inputCity.equals(vertexCity)
    				&& inputState.equals(vertexState) && inputPostal.equals(vertexPostal) && inputCounty.equals(vertexCounty)) {
    			return;
    		}
    		
    		String confidenceIndicatorStr = taxAreaResponse.getString("confidenceIndicator");
    		String vertexCodeStr = taxAreaResult.getString("AddressCleansingResultMessageCode");
    		String errorMessageStr = taxAreaResult.getString("AddressCleansingResultMessage");
    		
    		if(notNull(confidenceIndicatorStr)) {
    			confidenceIndicator = confidenceIndicatorStr.trim();
    		}
    		if(notNull(vertexCodeStr)) {
    			vertexCode = vertexCodeStr.trim();
    		}
    		if(notNull(errorMessageStr)) {
    			errorMessage = errorMessageStr.trim();
    		}
    		
    		//Start Add - NMendo - CCB011.Issue1 - 2021-04-27
        	if(isBlankOrNull(vertexAddress1)) {
        		confidenceIndicator = "0";
        	}
        	//End Add - NMendo - CCB011.Issue1 - 2021-04-27
    		
    		// If MINIMIM-CONFIDENCE parameter was defined, check if Vertex response Confidence Indicator 
    		// is more than or equal to the MINIMUM-CONFIDENCE parameter
    		if(notNull(parmMinimumConfidence) && isBlankOrNull(vertexCode) && isBlankOrNull(errorMessage) && notNull(confidenceIndicator)
    				&& parmMinimumConfidence.compareTo(new BigInteger(confidenceIndicator)) <= 0 ) {
    			//Start Change - NMendo - CCB011.Issue1 - 2021-04-27
    			//shouldUpdateAddress = Bool.TRUE;
    			//return;
    			if(doesPremiseWithSameAddressExists(vertexAddress1, vertexCity).isFalse()) {
    				shouldUpdateAddress = Bool.TRUE;
        			return;
    			}
    			
    			vertexCode = DUMMY_VERTEX_CODE;
    			errorMessage = CustomMessageRepositorySpireOne.CCB011_premiseAddressAlreadyExists(vertexAddress1, vertexCity).getMessageText();
    			//End Change - NMendo - CCB011.Issue1 - 2021-04-27
    		}
    		
    		shouldAddTaxJurisdictionChar = Bool.FALSE;
    		
    		// If EXCEPTION-MODE is blank or Vertex does not return error, process next Address
    		if(isNull(parmExceptionMode) || isBlankOrNull(vertexCode)) {
    			return;
    		}
    		
        	FeatureConfiguration vertexFeatureConfig = featConfigID.getEntity();
        	
        	// If an AddressCleansingResultMessage was returned in the Vertex response, check if any of the 
        	// Feature Configuration CM_VERTEXCFG Message Feature Message Codes match the AddressCleansingResultMessage code
        	ListFilter<FeatureConfigurationMessage> featConfigMessageFilter = vertexFeatureConfig.getMessages()
        			.createFilter("where this.id.wfmMessage = :vertexCode", getClass().getName());
        	featConfigMessageFilter.bindStringProperty("vertexCode", FeatureConfigurationMessage.properties.wfmMessage, vertexCode);
        	
        	Message_Id messageId = null;
        	Bool hasMsgParm = Bool.FALSE;
        	String msgParm = null;
        	FeatureConfigurationMessage featConfigMessage = featConfigMessageFilter.firstRow();
        	if(notNull(featConfigMessage)) {
        		Message message = featConfigMessage.getMessage();
        		messageId = message.getId();
        		errorMessage = message.fetchActiveMessageText();
        	} else {
        		ServerMessage serverMsg = CustomMessageRepositorySpireOne.CCB011_applicationError(errorMessage);
        		messageId = serverMsg.getMessageId();
        		hasMsgParm = Bool.TRUE;
        		msgParm = serverMsg.getMessageText();
        	}
        	
        	if(parmExceptionMode.equals(TODO_STR)) {
        		// Create a To Do Entry 
        		createToDo(messageId, hasMsgParm, msgParm, vertexState, vertexCounty, inputCounty, confidenceIndicator);
        		
        	} else if(parmExceptionMode.equals(FILE_STR)) {
        		// Add record to the file
        		// Start Change - NMendo - CCB011.Issue5 -  2021-06-09
        		//writeFileRecord(inputState, inputCounty, confidenceIndicator, errorMessage);
        		writeFileRecord(inputState, inputCounty, confidenceIndicator, errorMessage, inputAddress1);
        		// End Change - NMendo - CCB011.Issue5 -  2021-06-09
        	}
        	
        }
        
        /**
         * Add Tax Jurisdiction Characteristic to Premise
         * @param premise
         */
        private void addTaxJurisdictionChar(Premise premise, String currentTaxJurisdiction) {
        	CharacteristicType taxJurisdictionCharType = taxJurisdictionCharTypeId.getEntity();
			CharacteristicTypeLookup taxJurisdictionCharTypeLookup = taxJurisdictionCharType.getCharacteristicType();
			
			// Start Delete - NMendo - CCB011.Issue4 -  2021-06-02
			//Start Add - NMendo - CCB011.Issue1 - 2021-04-27
			// For Alabama and Gulf Jurisdiction Code returned by Vertex is 8 digits
			//if(vertexTaxJurisdiction.length() == 8) {
				// Add Leading and Trailing ZERO
				//vertexTaxJurisdiction = ZERO.concat(vertexTaxJurisdiction).concat(ZERO);
			//}
			/*
			 * Start Add - CCB011.Issue2 - 2021-04-28
			 */
	         // When Missouri Jurisdiction Code returned by Vertex is 9 digits
            //if(vertexTaxJurisdiction.length() == 9) {
                // Add Trailing ZERO
                //vertexTaxJurisdiction = vertexTaxJurisdiction.concat(ZERO);
            //}
            /*
             * End Add - CCB011.Issue2 - 2021-04-28
             */
            // End Delete - NMendo - CCB011.Issue4 -  2021-06-02
			
			if(taxJurisdictionCharTypeLookup.isPredefinedValue()) {
				CharacteristicValue_Id taxJurisdictionCharValId = new CharacteristicValue_Id(taxJurisdictionCharType, vertexTaxJurisdiction);
	        	
				if(isNull(taxJurisdictionCharValId.getEntity())) {
	        		// Add new Characteristic Value
					addJurisdictionCharacteristicValue(vertexTaxJurisdiction, jurisdictionDescr);
	        	}
			}
			//End Add - NMendo - CCB011.Issue1 - 2021-04-27
			
			Date effectiveDate = new Date(2000,1,1);
			
			if(notNull(currentTaxJurisdiction)) {
				effectiveDate = getProcessDateTime().getDate();
			}
			
			PremiseCharacteristics premiseChars = premise.getCharacteristics();
			PremiseCharacteristic_DTO premCharDto = premiseChars.newChildDTO();
			
			if(taxJurisdictionCharTypeLookup.isAdhocValue() || taxJurisdictionCharTypeLookup.isFileLocationValue()) {
				premCharDto.setAdhocCharacteristicValue(vertexTaxJurisdiction);
			} else if(taxJurisdictionCharTypeLookup.isPredefinedValue()) {
				premCharDto.setCharacteristicValue(vertexTaxJurisdiction);
			} else if(taxJurisdictionCharTypeLookup.isForeignKeyValue()) {
				premCharDto.setAdhocCharacteristicValue(vertexTaxJurisdiction);
			}
			
			premiseChars.add(premCharDto, taxJurisdictionCharTypeId, effectiveDate);
        }
        
        /**
         * Create To Do Entry 
         * @param errorMessage
         * @param messageId
         * @param mainDivision
         * @param subDivision
         * @param county
         * @param confidenceIndicator
         */
        private void createToDo(Message_Id messageId, Bool hasMsgParm, String msgParm, String mainDivision, 
        		String subDivision, String county, String confidenceIndicator) {
        	ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
            ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();
                        
            toDoEntryDTO.setBatchControlId(batchControlId);
            toDoEntryDTO.setBatchNumber(getBatchNumber());
            toDoEntryDTO.setCreationDateTime(getProcessDateTime());
            toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
            toDoEntryDTO.setToDoTypeId(toDoType.getId());
            toDoEntryDTO.setMessageId(messageId);
                        
            toDoCreator.setToDoDTO(toDoEntryDTO);
            // If MainDivision was returned, add it as a Sort Key
            if(!isBlankOrNull(mainDivision)) {
            	toDoCreator.addSortKeyValue(new ToDoSortKeyType_Id(toDoType, BigInteger.ONE).getEntity(), mainDivision);
            }
            
            // If SubDivision was returned, add it as a Sort Key
            // If no SubDivision was returned, use the existing County
            if(!isBlankOrNull(subDivision)) {
            	toDoCreator.addSortKeyValue(new ToDoSortKeyType_Id(toDoType, BigInteger.valueOf(2)).getEntity(), subDivision);
            } else if(!isBlankOrNull(county)) {
            	toDoCreator.addSortKeyValue(new ToDoSortKeyType_Id(toDoType, BigInteger.valueOf(2)).getEntity(), county);
            }
            
            // If Confidence Indicator was returned, use it as a Sort Key
            if(!isBlankOrNull(confidenceIndicator)) {
            	toDoCreator.addSortKeyValue(new ToDoSortKeyType_Id(toDoType, BigInteger.valueOf(3)).getEntity(), confidenceIndicator);
            }
            
            // Use the Account ID and Person ID as the Drill Keys
            toDoCreator.addDrillKeyValue(new ToDoDrillKeyType_Id(toDoType, BigInteger.ONE).getEntity(), premiseIdStr);
            
            if(hasMsgParm.isTrue()) {
            	toDoCreator.addMessageParameter(msgParm);
            }
            
            toDoCreator.create();
            numberOfAddressRequiringAttention++;
        }
        
        /**
         * Form File Path Name
         */
        private void formFilePathName() {
        	String filePath = parmFilePath;
        	String fileName = parmFileName;

			// Replace all \ with / and make sure that the file path ends with a /
			if (!filePath.trim().endsWith(FORWARDSLASH)
					&& !filePath.trim().endsWith(BACKSLASH)) {
				filePath = filePath.trim().concat(BACKSLASH);
			}
			filePath = filePath.replace(FORWARDSLASH, BACKSLASH);

			// Append the thread number before the last period of the file name if there is more than one thread
			if (getParameters().getThreadCount().intValue() > 1){
				String threadNumberStr = getBatchThreadNumber().toString();
				
				if(fileName.contains(PERIOD)) {
					int lastIdx = fileName.lastIndexOf(PERIOD);
					
					StringBuilder sb = new StringBuilder();
					sb.append(fileName.substring(0, lastIdx));
					sb.append(threadNumberStr);
					// Start Change - NMendo - CCB011.Issue4 -  2021-06-02
					//sb.append(PERIOD);
					//sb.append(fileName.substring(lastIdx + threadNumberStr.length()));
					sb.append(fileName.substring(lastIdx));
					// End Change - NMendo - CCB011.Issue4 -  2021-06-02
					fileName = sb.toString();
					
				} else {
					fileName = fileName.concat(threadNumberStr);
				}
            }

			filePathName = filePath.trim().concat(fileName.trim());
		}
        
        /**
         * Write File Header
         */
        private void writeFileHeader() {
        	StringBuilder sb = new StringBuilder();
        	sb.append(PREMISE_ID_HEADER);
        	sb.append(COMMA);
        	// Start Add - NMendo - CCB011.Issue5 -  2021-06-09
        	sb.append(ADDRESS1_HEADER);
        	sb.append(COMMA);
        	// End Add - NMendo - CCB011.Issue5 -  2021-06-09
        	sb.append(STATE_HEADER);
        	sb.append(COMMA);
        	sb.append(COUNTY_HEADER);
        	sb.append(COMMA);
        	sb.append(CONFIDENCE_INDICATOR_HEADER);
        	sb.append(COMMA);
        	sb.append(ERROR_MESSAGE_HEADER);
        	
        	writeToFile(sb.toString());
        }
        
        /**
         * Write File Record
         * @param state
         * @param county
         * @param confidenceIndicator
         * @param errorMessage
         * @param address1
         */
        // Start Change - NMendo - CCB011.Issue5 -  2021-06-09
        //private void writeFileRecord(String state, String county, String confidenceIndicator, String errorMessage) {
        private void writeFileRecord(String state, String county, String confidenceIndicator, String errorMessage, String address1) {
        // End Change - NMendo - CCB011.Issue5 -  2021-06-09
        	StringBuilder sb = new StringBuilder();
        	sb.append(DOUBLE_QUOTE);
        	sb.append(premiseIdStr);
        	sb.append(DOUBLE_QUOTE);
        	sb.append(COMMA);
        	// Start Add - NMendo - CCB011.Issue5 -  2021-06-09
        	sb.append(DOUBLE_QUOTE);
        	sb.append(address1);
        	sb.append(DOUBLE_QUOTE);
        	sb.append(COMMA);
        	// End Add - NMendo - CCB011.Issue5 -  2021-06-09
        	sb.append(state);
        	sb.append(COMMA);
        	sb.append(county);
        	sb.append(COMMA);
        	sb.append(confidenceIndicator);
        	sb.append(COMMA);
        	sb.append(DOUBLE_QUOTE);
        	sb.append(errorMessage);
        	sb.append(DOUBLE_QUOTE);
        	
        	writeToFile(sb.toString());
        	numberOfAddressRequiringAttention++;
        }
        
        /**
         * Open File
         */
		private void openFile() {
			try {
				File file = new File(filePathName);
				FileWriter fileWriter = new FileWriter(file);
				buffWriter = new BufferedWriter(fileWriter);
			} catch (Exception e) { 
				// Error encountered opening file (%1%2%3%4).
				addError(CustomMessageRepositorySpireOne.CCB011_errorOpeningFile(filePathName));
			}
		}
		
		/**
		 * Write to File
		 * @param stringToWrite
		 */
		private void writeToFile(String stringToWrite) {
			try {
				buffWriter.write(stringToWrite);
				buffWriter.write(CARRIAGE_RETURN_LINE_FEED);
			} catch (Exception e) {
				// Error encountered writing to file (%1%2%3%4).
				addError(CustomMessageRepositorySpireOne.CCB011_errorWritingFile(filePathName));
			}
		}

		/**
		 * Close File
		 */
		private void closeFile() {
			try {
				buffWriter.close();
			} catch (Exception e) {
				// Error encountered closing file (%1%2%3%4).
				addError(CustomMessageRepositorySpireOne.CCB011_errorClosingFile(filePathName));
			}
		}
		
		//Start Add - NMendo - CCB011.Issue1 - 2021-04-27
		/**
		 * Check if Premise With Same Address as the input exists.
		 * @param address1
		 * @param city
		 * @return Bool
		 */
		private Bool doesPremiseWithSameAddressExists(String address1, String city) {
			Bool doesPremiseWithSameAddressExists = Bool.FALSE;
			
			StringBuilder sb = new StringBuilder();
        	sb.append("SELECT PREM_ID ");
        	sb.append("FROM CI_PREM ");
        	sb.append("WHERE ADDRESS1_UPR = :address1 ");
        	sb.append("AND CITY_UPR = :city ");
        	sb.append("AND PREM_ID <> :premiseId ");
        	// Start Add - NMendo - CCB011.Issue5 -  2021-06-09
        	sb.append("AND PREM_TYPE_CD NOT IN ("+ exemptPremiseTypes +")");
        	// End Add - NMendo - CCB011.Issue5 -  2021-06-09
        	
        	PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
        	ps.bindStringProperty("address1", Premise.properties.address1, address1);
        	ps.bindStringProperty("city", Premise.properties.city, city);
        	ps.bindId("premiseId", premiseId);
        	
        	SQLResultRow result = ps.firstRow();
        	ps.close();
        	
        	if(notNull(result)) {
        		doesPremiseWithSameAddressExists = Bool.TRUE;
        	}
			
			return doesPremiseWithSameAddressExists;
		}
		
		private void addJurisdictionCharacteristicValue(String charVal, String descr) {
			StringBuilder sb = new StringBuilder();
			sb.append("INSERT INTO CI_CHAR_VAL (CHAR_TYPE_CD,CHAR_VAL,OWNER_FLG) ");
			sb.append("VALUES (:charType,:charVal,'CM') ");
			
			PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
        	ps.bindId("charType", taxJurisdictionCharTypeId);
        	ps.bindStringProperty("charVal", CharacteristicValue.properties.characteristicValue, charVal);
        	ps.execute();
        	ps.close();
        	
        	StringBuilder sb2 = new StringBuilder();
			sb2.append("INSERT INTO CI_CHAR_VAL_L (CHAR_TYPE_CD,CHAR_VAL,DESCR,LANGUAGE_CD,OWNER_FLG) ");
			sb2.append("VALUES (:charType,:charVal,:descr,'ENG','CM') ");
			
			PreparedStatement ps2 = createPreparedStatement(sb2.toString(), getClass().getName());
        	ps2.bindId("charType", taxJurisdictionCharTypeId);
        	ps2.bindStringProperty("charVal", CharacteristicValue.properties.characteristicValue, charVal);
        	ps2.bindStringProperty("descr", CharacteristicValue.properties.languageDescription, descr);
        	ps2.execute();
        	ps2.close();
		}
		//End Add - NMendo - CCB011.Issue1 - 2021-04-27
		
		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
			if(notNull(parmExceptionMode) && parmExceptionMode.equals(FILE_STR)) {
				// Close File
				closeFile();
			}
			
			// Number of auto-updated Mailing Addresses: %1
			logInfo(CustomMessageRepositorySpireOne.CCB011_numberOfUpdatedPremise(String.valueOf(numberOfUpdatedPremise)));
			
			// Number of Mailing Addresses requiring attention: %1
            logInfo(CustomMessageRepositorySpireOne.CCB011_numberOfPremiseRequiringAttention(String.valueOf(numberOfAddressRequiringAttention)));
        }
    }
}
