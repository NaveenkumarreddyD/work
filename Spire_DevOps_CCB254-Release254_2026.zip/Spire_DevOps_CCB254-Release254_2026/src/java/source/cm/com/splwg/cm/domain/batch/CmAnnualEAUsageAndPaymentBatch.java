/**************************************************************************
* Program Name: CmAnnualEAUsageAndPaymentBatch
* Program Title: CmAnnualEAUsageAndPaymentBatch
* Author: ACasta
* Creation Date: 2017-09-22
* Purpose: This Batch Program will process the inbound DSS Request file.
* Functional Spec: SA-214976
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:         Date:         Description:
 * ----------------------------------------------------------------------------------------------
 * SA-214976          Alfonso Castano 2017-09-22    Initial Version
 ************************************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_Id;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.BillStatusLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.api.lookup.PaymentStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.entity.GeneralLedgerDistributionCode;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentEvent;
import com.splwg.cm.api.batch.CmAnnualEaUsageControlRecord;
import com.splwg.cm.api.batch.CmAnnualEaUsageRecord;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ServerMessage;

/**
 * @author ACasta
 *
@BatchJob (multiThreaded = false, rerunnable = true, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = INPUT_FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = INPUT_FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = OUTPUT_FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = OUTPUT_FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = TO_DO_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = adjustmentType, name = AP_ADJUSTMENT_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = adjustmentType, name = PLEDGE_TRANSFER_ADJ_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = serviceQuantityIdentifier, name = SQI_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = generalLedgerDistributionCode, name = DST_ID, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = START_DT, required = true, type = date)
 *            , @BatchJobSoftParameter (name = END_DT, required = true, type = date)})
 */
public class CmAnnualEAUsageAndPaymentBatch extends
        CmAnnualEAUsageAndPaymentBatch_Gen {
    
    // Soft Parameters
    private String inputFilePath;
    private String outputFilePath;
    
    public JobWork getJobWork() {
        List<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        arrayList.add(threadWorkUnit);
        return createJobWorkForThreadWorkUnitList(arrayList);
    }

    @Override
    public void validateSoftParameters(boolean isNewRun) {
        retrieveBatchParameters();
        validateBatchParameters();
    }

    /**
     * This method retrieves all the soft Parameters of the batch
     */
    private void retrieveBatchParameters() {
        inputFilePath = getParameters().getINPUT_FILE_PATH();
        outputFilePath = getParameters().getOUTPUT_FILE_PATH();
    }
    
    /**
     * This method validates all the Soft Parameters of the Batch
     */
    private void validateBatchParameters(){
        // Input File Path
        File inputPath = new File(inputFilePath);
        if (!inputPath.exists() || !inputPath.isDirectory()){
            addError(CustomMessageRepository.SA_214976_invalidInputFilePath(inputFilePath));
        }

        // Output File Path
        File outputPath= new File(outputFilePath);
        if (!outputPath.exists() || !outputPath.isDirectory()){
            addError(CustomMessageRepository.SA_214976_invalidOutputFilePath(outputFilePath));
        }
        
    }
    
    public Class<CmAnnualEAUsageAndPaymentBatchWorker> getThreadWorkerClass() {
        return CmAnnualEAUsageAndPaymentBatchWorker.class;
    }

    public static class CmAnnualEAUsageAndPaymentBatchWorker extends
            CmAnnualEAUsageAndPaymentBatchWorker_Gen {
        // Soft parameter
        private ToDoType toDoType;
        private Date startDate;
        private Date endDate;
        private AdjustmentType apAdjustmentType;
        private AdjustmentType pledgeTransferAdjustmentType;
        private ServiceQuantityIdentifier sqiCd;
        private GeneralLedgerDistributionCode glDistCd;
        
        // Counters
        private int processedRecord = 0;
        private int recordInError = 0;
        
        // Constants
        private static final BigInteger MIN_FULL_BILL_DAYS = BigInteger.valueOf(26);
        
        // Work Parameters
        private File outputFile;
        private BigInteger numberOfRecords;
        private BufferedReader reader;
        private BufferedWriter writer;
        private Account_Id accountId;
        private PaymentEvent payEvent;
        private Date paymentDate;
        private List<ServiceAgreement> serviceAgreements;
        private CmAnnualEaUsageControlRecord cmAnnualEaUsageControlRecord;
        private CmAnnualEaUsageRecord cmAnnualEaUsageRecord;
        
        private BigInteger totalRegularRecords;
        
        @Override
        public void initializeThreadWork(
                boolean initializationPreviouslySuccessful)
                throws ThreadAbortedException, RunAbortedException {
            toDoType = getParameters().getTO_DO_TYPE();
            startDate = getParameters().getSTART_DT();
            endDate = getParameters().getEND_DT();
            apAdjustmentType = getParameters().getAP_ADJUSTMENT_TYPE();
            pledgeTransferAdjustmentType = getParameters().getPLEDGE_TRANSFER_ADJ_TYPE();
            sqiCd = getParameters().getSQI_CD();
            glDistCd = getParameters().getDST_ID();
            
            // Output file
            String outputFilePath = getParameters().getOUTPUT_FILE_PATH();
            String outputFileName = getParameters().getOUTPUT_FILE_NAME();
            
            // Write to output line
            try {
                outputFile = new File(outputFilePath, outputFileName.toString().trim());
                writer = new BufferedWriter(new FileWriter(outputFile, false));
            } catch (IOException e) {
                addError(CustomMessageRepository.SA_214976_errorWritingToOutputFile(e.getMessage()));
            }
        }

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
            
            // Open input file
            String inputFilePath = getParameters().getINPUT_FILE_PATH();
            String inputFileName = getParameters().getINPUT_FILE_NAME();
            
            File file = new File(inputFilePath, inputFileName);
            List<String> fileLines = new ArrayList<String>();
            List<String> outputLines = new ArrayList<String>();
            
            try {
                reader = new BufferedReader(new FileReader(file));
                Scanner sc = new Scanner(file);
                while(sc.hasNextLine()){
                    fileLines.add(sc.nextLine());
                }
                sc.close();
            } catch (FileNotFoundException e) {
                addError(CustomMessageRepository.SA_214976_errorOpeningInputFile(e.getMessage()));
            }
            
            // Read Control
            String controlLine = fileLines.get(fileLines.size()-1);
            cmAnnualEaUsageControlRecord = new CmAnnualEaUsageControlRecord(controlLine);
            numberOfRecords = cmAnnualEaUsageControlRecord.getNumberOfRecords();
            
            totalRegularRecords = BigInteger.valueOf(fileLines.size() -1);
            if (numberOfRecords.compareTo(totalRegularRecords) != 0){
                recordInError++;
                createToDo(CustomMessageRepository.SA_214976_totalNumberOfRegularRecordsDoesNotMatch(), "");
                logError(CustomMessageRepository.SA_214976_totalNumberOfRegularRecordsDoesNotMatch());
                return new WorkUnitResult(false);
            }
            
            for (int index = 0; index < fileLines.size() - 1; index++){
                String recordLine = fileLines.get(index);
                cmAnnualEaUsageRecord = new CmAnnualEaUsageRecord(recordLine);
                processedRecord++;
                accountId = new Account_Id(cmAnnualEaUsageRecord.getApplicantsAccountNumber());
                if (isNull(accountId.getEntity())){
                    recordInError++;
                    createToDo(CustomMessageRepository.SA_214976_accountIdInvalid(accountId.getTrimmedValue()), cmAnnualEaUsageRecord.getApplicantsAccountNumber());
                    logError(CustomMessageRepository.SA_214976_accountIdInvalid(accountId.getTrimmedValue()));
                    //don't abort the job but continue processing when an account is invalid.
                    //return new WorkUnitResult(false);
                }
                
                List<CmAnnualEaUsageRecord.MonthDataElement> monthDataElementList = cmAnnualEaUsageRecord.getMonthDataElementList();
                
                List<SQLResultRow> billQueryResultList = retrieveBillDetails(accountId, startDate, endDate);
                for (SQLResultRow billQueryResult : billQueryResultList){
                    // Match the Bill to the proper month for it
                    DateTime billCreationDateTime = billQueryResult.getDateTime("CRE_DTTM");
                    int billMonth = billCreationDateTime.getMonth();
                    int billYear = billCreationDateTime.getYear() - 2000;
                    
                    for (CmAnnualEaUsageRecord.MonthDataElement monthDataElement : monthDataElementList) {
                        if (billYear != monthDataElement.getYear().intValue() || billMonth != monthDataElement.getMonth().intValue()) {
                            continue;
                        }
                        Bill_Id billId = (Bill_Id) billQueryResult.getId("BILL_ID", Bill.class);
                        
                        List<SQLResultRow> billSegmentQueryResultList = retrieveBillSegmentDetails(billId);
                        
                        if (billSegmentQueryResultList.size() == 1) {
                            monthDataElement.setBilledAmount(billSegmentQueryResultList.get(0).getBigDecimal("CALC_AMT"));
                            monthDataElement.setUsage(billSegmentQueryResultList.get(0).getBigDecimal("MSR_QTY"));
                            if (MIN_FULL_BILL_DAYS.compareTo(billSegmentQueryResultList.get(0).getInteger("BILL_SQ")) > 0) {
                                monthDataElement.setIsPartialBill(Bool.TRUE);
                            }
                        }
                        
                        if (billSegmentQueryResultList.size() > 1) {
                            
                            int activeServiceAgreements = 0;
                            for (SQLResultRow billSegmentQueryResult : billSegmentQueryResultList) {
                                
                                ServiceAgreementStatusLookup saStatus = (ServiceAgreementStatusLookup) billSegmentQueryResult.getLookup("SA_STATUS_FLG", ServiceAgreementStatusLookup.class); 
                                
                                if (saStatus.isActive()) {
                                    activeServiceAgreements = activeServiceAgreements + 1;
                                }
                            }
                            
                            if (activeServiceAgreements == 1) {
                                
                                /*
                                 * If there is a stop/start that causes 2 bill segments on the same 
                                 * SA in the same month, combine the DAYBP and USAGE and report the 
                                 * combined values and for scenario 
                                 */
                                
                                BigDecimal sumMeasuredQuantities = BigDecimal.ZERO;
                                BigDecimal sumCalculatedAmounts = BigDecimal.ZERO;
                                BigInteger sumSqi = BigInteger.ZERO;
                                
                                // get sum of bill segment MSR_QTY, SQI, etc
                                for (SQLResultRow billSegmentQueryResult : billSegmentQueryResultList) {
                                    sumMeasuredQuantities = sumMeasuredQuantities.add(billSegmentQueryResult.getBigDecimal("MSR_QTY"));
                                    sumCalculatedAmounts = sumCalculatedAmounts.add(billSegmentQueryResult.getBigDecimal("CALC_AMT"));
                                    sumSqi = sumSqi.add(billSegmentQueryResult.getInteger("BILL_SQ"));
                                }
                                
                                // Assign them
                                monthDataElement.setBilledAmount(sumCalculatedAmounts);
                                monthDataElement.setUsage(sumMeasuredQuantities);
                                if (MIN_FULL_BILL_DAYS.compareTo(sumSqi) > 0) {
                                    monthDataElement.setIsPartialBill(Bool.TRUE);
                                }
                                
                            } else if (activeServiceAgreements > 1) {
                                
                                /*
                                 * If there are 2 SA's on the account, report on just 1 SA's 
                                 * USAGE/DAYBP and BALANCES/REFUNDS (and they don't care which SA 
                                 * is selected).
                                 */
                                
                                monthDataElement.setBilledAmount(billSegmentQueryResultList.get(0).getBigDecimal("CALC_AMT"));
                                monthDataElement.setUsage(billSegmentQueryResultList.get(0).getBigDecimal("MSR_QTY"));
                                if (MIN_FULL_BILL_DAYS.compareTo(billSegmentQueryResultList.get(0).getInteger("BILL_SQ")) > 0) {
                                    monthDataElement.setIsPartialBill(Bool.TRUE);
                                }       
                            }
                        }   
                    }
                }
                
                // retrieve payment event
                SQLResultRow paymentEventQuery = retrieveAccountPaymentEvent(startDate, endDate, accountId);
                
                if (isNull(paymentEventQuery)){
                	//keep original record from the file, if there's no payment event data
                	outputLines.add(cmAnnualEaUsageRecord.createRecordString());
                    continue;
                }
                
                payEvent = paymentEventQuery.getEntity("PAY_EVENT_ID", PaymentEvent.class);
                paymentDate = paymentEventQuery.getDate("PAY_DT");
                
                // retrieve outstanding balance for account
                serviceAgreements = getServiceAgreements(accountId);
                ListIterator<ServiceAgreement> iter = serviceAgreements.listIterator();
                BigDecimal outstandingBalance = BigDecimal.ZERO;
                while (iter.hasNext()) {
                    ServiceAgreement sa = iter.next();
                    Money saBal = sa.getPayoffBalance(paymentDate.addDays(-1), paymentDate.addDays(-1), Bool.FALSE);
                    outstandingBalance = outstandingBalance.add(saBal.getAmount());
                }
                // If credit
                if (outstandingBalance.compareTo(BigDecimal.ZERO) > 0){
                    cmAnnualEaUsageRecord.setOutstandingBalanceBeforeEaPayment(outstandingBalance);
                } else if (outstandingBalance.compareTo(BigDecimal.ZERO) < 0){
                    cmAnnualEaUsageRecord.setCreditBalanceBeforeEaPayment(outstandingBalance);
                }
                
                // retrieve credit balance for account
                iter = serviceAgreements.listIterator();
                BigDecimal creditBalance = BigDecimal.ZERO;
                while (iter.hasNext()){
                    ServiceAgreement sa = iter.next();
                    creditBalance = creditBalance.add(sa.getPayoffBalance(getProcessDateTime().getDate(), getProcessDateTime().getDate(), Bool.FALSE).getAmount());
                }
                // if credit
                if (creditBalance.compareTo(BigDecimal.ZERO) < 0){
                    cmAnnualEaUsageRecord.setCreditBalanceAsOfPresent(creditBalance);
                }
                
                // Retrieve credit refund amount
                BigDecimal creditRefundAmount = retrieveAdjustmentCreditBalance(accountId, apAdjustmentType, paymentDate);
                if (creditRefundAmount.compareTo(BigDecimal.ZERO) > 0){
                    cmAnnualEaUsageRecord.setCreditBalanceRefundedToCustomer(creditRefundAmount);
                }
                
                BigDecimal creditPledgeTransferAmount = retrieveAdjustmentCreditBalance(accountId, pledgeTransferAdjustmentType, paymentDate);
                if (creditPledgeTransferAmount.compareTo(BigDecimal.ZERO) > 0){
                    cmAnnualEaUsageRecord.setCreditBalanceRefundedToDss(creditPledgeTransferAmount);
                }
                
                outputLines.add(cmAnnualEaUsageRecord.createRecordString());
            }
            
            writeLines(outputLines);
            
            WorkUnitResult result = new WorkUnitResult(true);
            result.setUnitsProcessed(processedRecord);
            result.setUnitsInError(recordInError);
            return result;
        }

        // File Handling
        private void writeLines (List<String> outputLines){
            for (String line : outputLines){
                writeOutputFile(line, writer);
            }
            writeOutputFile(cmAnnualEaUsageControlRecord.createRecordString(), writer);
            try {
                writer.close();
            } catch (IOException e){
                e.printStackTrace();
            }
        }
        
        
        /**
         * Writes to output file
         */
        private void writeOutputFile(String line, BufferedWriter bufferedWriter){
            try {
                bufferedWriter.write(line);
                if (!line.startsWith("CONTROL")){
                    bufferedWriter.newLine();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
        /**
         * This method will retrieve adjustment credit balances of the Account depending on the input Adjustment Type
         * @param accountId
         * @param adjustmentType
         */
        private BigDecimal retrieveAdjustmentCreditBalance(Account_Id accountId, AdjustmentType adjustmentType, Date paymentDate){
            BigDecimal returnValue = BigDecimal.ZERO;
            
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.append("SELECT SUM(FT.CUR_AMT) CUR_AMT ");
            strBuilder.append(" FROM CI_FT FT");
            strBuilder.append(" WHERE FT.SA_ID IN (SELECT SA.SA_ID");
            strBuilder.append(                   " FROM CI_SA SA");
            strBuilder.append(                   " WHERE SA.ACCT_ID = :accountId)");
            strBuilder.append(" AND FT.FT_TYPE_FLG = :ftTypeFlg");
            strBuilder.append(" AND EXISTS (SELECT 'X'");
            strBuilder.append(            " FROM CI_ADJ ADJ");
            strBuilder.append(            " WHERE ADJ.ADJ_ID = FT.SIBLING_ID");
            strBuilder.append(            " AND ADJ.ADJ_TYPE_CD = :adjustmentType");
            strBuilder.append(            " AND ADJ.ADJ_STATUS_FLG = '50')");
            strBuilder.append(" AND FT.FREEZE_DTTM >= :paymentDate");
            
            PreparedStatement prepStatement = createPreparedStatement(strBuilder.toString(), getClass().getName());
            prepStatement.bindId("accountId", accountId);
            prepStatement.bindLookup("ftTypeFlg", FinancialTransactionTypeLookup.constants.ADJUSTMENT);
            prepStatement.bindId("adjustmentType", adjustmentType.getId());
            prepStatement.bindDate("paymentDate", paymentDate);
            prepStatement.execute();
            
            if (prepStatement.list().size() > 0){
                SQLResultRow row = (SQLResultRow) prepStatement.firstRow();
                if (notNull(row.getBigDecimal("CUR_AMT"))){
                    returnValue = row.getBigDecimal("CUR_AMT");
                }
            } else {
                returnValue = BigDecimal.ZERO;
            }
            prepStatement.close();
            return returnValue;
        }
        
        /**
         * This method will retrieve the service agreements of the Account
         * @param accountId
         * @param paymentDate
         */
        private List<ServiceAgreement> getServiceAgreements(Account_Id accountId){
            ArrayList<ServiceAgreement> returnSAs = new ArrayList<ServiceAgreement>();
            StringBuilder queryStr = new StringBuilder();
            queryStr.append("SELECT SA.SA_ID");
            queryStr.append(" FROM CI_SA SA");
            queryStr.append(" WHERE ACCT_ID = :acctId");
            queryStr.append(" AND SA.SA_STATUS_FLG < :closedStatus");
            
            PreparedStatement getSAs = createPreparedStatement(queryStr.toString(), getClass().getName());
            getSAs.bindId("acctId", accountId);
            getSAs.bindLookup("closedStatus", ServiceAgreementStatusLookup.constants.CLOSED);
            getSAs.execute();
            
            List<SQLResultRow> resultList = getSAs.list();
            for (SQLResultRow result: resultList){
                ServiceAgreement_Id saId = (ServiceAgreement_Id) result.getId("SA_ID", ServiceAgreement.class);
                returnSAs.add(saId.getEntity());
            }
            getSAs.close();
            
            return returnSAs;
        }
        
        
        /**
         * This method will retrieve payment details for the Account
         * @param startDate
         * @param endDate
         * @param accountId
         */
        private SQLResultRow retrieveAccountPaymentEvent(Date startDate, Date endDate, Account_Id accountId){
            StringBuilder strRetQuery = new StringBuilder();
            strRetQuery.append("SELECT b.ACCT_ID, a.PAY_EVENT_ID, a.PAY_DT, d.DST_ID, b.PAY_STATUS_FLG");
            strRetQuery.append(" FROM CI_PAY_EVENT a, CI_PAY b, CI_FT c, CI_FT_GL d");
            strRetQuery.append(" WHERE a.PAY_EVENT_ID = b.PAY_EVENT_ID");
            strRetQuery.append(" AND c.PARENT_ID = b.PAY_ID");
            strRetQuery.append(" AND d.FT_ID = c.FT_ID");
            strRetQuery.append(" AND d.DST_ID = :distCd");
            strRetQuery.append(" AND b.PAY_STATUS_FLG = :payStatFlg");
            strRetQuery.append(" AND a.CRE_DTTM BETWEEN :startDate AND :endDate");
            strRetQuery.append(" AND b.ACCT_ID = :accountId");
            
            PreparedStatement query = createPreparedStatement(strRetQuery.toString(), getClass().getName());
            query.bindId("distCd", glDistCd.getId());
            query.bindLookup("payStatFlg", PaymentStatusLookup.constants.FROZEN);
            query.bindDate("startDate", startDate);
            query.bindDate("endDate", endDate);
            query.bindId("accountId", accountId);
            
            SQLResultRow queryResultRow = query.firstRow();
            query.close();
            
            return queryResultRow;
        }
        
        /**
         * This method will retrieve Bills within the input Start date and End date
         * @param startDate
         * @param endDate
         */
        private List<SQLResultRow> retrieveBillDetails(Account_Id accountId, Date startDate, Date endDate) {
            StringBuilder strQuery = new StringBuilder();
            strQuery.append("SELECT a.CRE_DTTM, a.BILL_ID ");
            strQuery.append(" FROM CI_BILL a");
            strQuery.append(" WHERE TRUNC(a.CRE_DTTM) BETWEEN :startDate AND :endDate");
            strQuery.append(" AND a.BILL_STAT_FLG = :billStatFlg");
            strQuery.append(" AND a.ACCT_ID = :account");
            strQuery.append(" ORDER BY a.CRE_DTTM");
            
            PreparedStatement prepQuery = createPreparedStatement(strQuery.toString(), getClass().getName());
            prepQuery.bindDate("startDate", startDate);
            prepQuery.bindDate("endDate", endDate);
            prepQuery.bindId("account", accountId);
            prepQuery.bindLookup("billStatFlg", BillStatusLookup.constants.COMPLETE);
            List<SQLResultRow> results = prepQuery.list();
            prepQuery.close();
            
            return results;
        }

        private List<SQLResultRow> retrieveBillSegmentDetails(Bill_Id billId) {
            StringBuilder strQuery = new StringBuilder();
            strQuery.append("SELECT c.MSR_QTY, d.CALC_AMT, e.BILL_SQ, f.SA_STATUS_FLG");
            strQuery.append(" FROM CI_BSEG b, CI_BSEG_READ c," +
                            " CI_BSEG_CALC d, CI_BSEG_SQ e, CI_SA f, CI_SA_TYPE g ");
            strQuery.append(" WHERE (b.BILL_ID = :bill)");
            strQuery.append(" AND (b.BSEG_ID = c.BSEG_ID)");
            strQuery.append(" AND (b.BSEG_ID = d.BSEG_ID)");
            strQuery.append(" AND (b.BSEG_ID = e.BSEG_ID)");
            strQuery.append(" AND b.BSEG_STAT_FLG = :bsegStatFlg");
            strQuery.append(" AND c.SEQNO = :first");
            strQuery.append(" AND e.SQI_CD = :sqiCd");
            strQuery.append(" AND f.SA_ID = b.SA_ID");
            strQuery.append(" AND f.CIS_DIVISION = g.CIS_DIVISION");
            strQuery.append(" AND f.SA_TYPE_CD = g.SA_TYPE_CD");
            strQuery.append(" AND g.ALLOW_SP_SW = :true");
            strQuery.append(" ORDER BY e.BILL_SQ");
            
            PreparedStatement prepQuery = createPreparedStatement(strQuery.toString(), getClass().getName());
            prepQuery.bindId("bill", billId);
            prepQuery.bindLookup("bsegStatFlg", BillSegmentStatusLookup.constants.FROZEN);
            prepQuery.bindBigInteger("first", BigInteger.ONE);
            prepQuery.bindId("sqiCd", sqiCd.getId());
            prepQuery.bindBoolean("true", Bool.TRUE);
            List<SQLResultRow> results = prepQuery.list();
            prepQuery.close();
            
            return results;
        }
        
        /**
         * This method creates To Do Entry
         * @param accountStr - Account Id
         */
        private void createToDo(ServerMessage serverMessage, String accountId) {
            ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
            ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();

            toDoEntryDTO.setCreationDateTime(getProcessDateTime());
            toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
            toDoEntryDTO.setToDoTypeId(toDoType.getId());

            toDoEntryDTO.setBatchControlId(getBatchControlId());
            toDoEntryDTO.setBatchNumber(getBatchNumber());

            toDoEntryDTO.setMessageId(serverMessage.getMessageId());
            
            toDoCreator.setToDoDTO(toDoEntryDTO);
            
            List<ToDoSortKeyType> collOfSortKeyTypes = cmGetSortKeyTypes(toDoType.getId());
            for (int x = 0; x < collOfSortKeyTypes.size(); x++) {
                
                ToDoSortKeyType tdSortKeyType = collOfSortKeyTypes.get(x);
                ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
                BigInteger sequence = tdSortKeyType.fetchIdSequence();
                sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, sequence));
                
                if (sequence.compareTo(BigInteger.valueOf(1)) == 0) { 
                    toDoCreator.addSortKeyValue(tdSortKeyType, getBatchControlId().getTrimmedValue());
                }
                else if (sequence.compareTo(BigInteger.valueOf(2)) == 0) {
                    toDoCreator.addSortKeyValue(tdSortKeyType, getBatchNumber().toString());    
                }
                else if (sequence.compareTo(BigInteger.valueOf(3)) == 0) {
                    toDoCreator.addSortKeyValue(tdSortKeyType, getBatchRerunNumber().toString());
                }
                //else if (sequence.compareTo(BigInteger.valueOf(4)) == 0) {
                    //toDoCreator.addSortKeyValue(tdSortKeyType, accountId);
                //}
            }

            // Drill Keys
            List<ToDoDrillKeyType> collOfDrillKeyTypes = cmGetDrillKeyTypes(toDoType.getId());
            
            for (int x = 0; x < collOfDrillKeyTypes.size(); x++) {
                ToDoDrillKeyType tdDrillKeyType = collOfDrillKeyTypes.get(x);
                BigInteger sequence = tdDrillKeyType.fetchIdSequence();
                
                if (sequence.compareTo(BigInteger.valueOf(1)) == 0) { 
                    toDoCreator.addDrillKeyValue(tdDrillKeyType, getBatchControlId().getTrimmedValue());
                }
                else if (sequence.compareTo(BigInteger.valueOf(2)) == 0) {
                    toDoCreator.addDrillKeyValue(tdDrillKeyType, getBatchNumber().toString());    
                }
                else if (sequence.compareTo(BigInteger.valueOf(3)) == 0) {
                    toDoCreator.addDrillKeyValue(tdDrillKeyType, getBatchRerunNumber().toString());
                }
                else if (sequence.compareTo(BigInteger.valueOf(4)) == 0) {
                    toDoCreator.addDrillKeyValue(tdDrillKeyType, accountId);
                }
            }
            
            // Message Parameters
            for (int index = 0; index < serverMessage.getMessageParameters().getSize(); index++){
                toDoCreator.addMessageParameter(serverMessage.getMessageParameters().getParameters().get(index).toString());
            }
            toDoCreator.create();
        }
        
        private List<ToDoSortKeyType> cmGetSortKeyTypes(ToDoType_Id tdTypeID) {
            
            List<ToDoSortKeyType> returnValue = new ArrayList<ToDoSortKeyType>();
            
            StringBuilder stringBuilder = new StringBuilder();                  
            stringBuilder.append("SELECT TD_TYPE_CD, SEQ_NUM ");
            stringBuilder.append("FROM CI_TD_SRTKEY_TY ");
            stringBuilder.append("WHERE TD_TYPE_CD = :tdTypeID ");
            
            PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            prepState.bindId("tdTypeID", tdTypeID);
            prepState.execute();
            
            if (prepState.list().size() > 0) {
                
                Iterator<SQLResultRow> iter = prepState.list().iterator();
                
                while (iter.hasNext()) {
                
                    SQLResultRow sqlRow = (SQLResultRow) iter.next();                   
                    BigInteger seq = (BigInteger) sqlRow.getInteger("SEQ_NUM");
                    ToDoSortKeyType_Id tdSortKeyTypeID = new ToDoSortKeyType_Id(tdTypeID, seq);
                    returnValue.add(tdSortKeyTypeID.getEntity());
                }                               
            }           
            prepState.close();
            return returnValue;
        }
        
        private List<ToDoDrillKeyType> cmGetDrillKeyTypes(ToDoType_Id tdTypeID) {
            
            List<ToDoDrillKeyType> returnValue = new ArrayList<ToDoDrillKeyType>();
            
            StringBuilder stringBuilder = new StringBuilder();                  
            stringBuilder.append("SELECT TD_TYPE_CD, SEQ_NUM ");
            stringBuilder.append("FROM CI_TD_DRLKEY_TY ");
            stringBuilder.append("WHERE TD_TYPE_CD = :tdTypeID ");
            
            PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            prepState.bindId("tdTypeID", tdTypeID);
            prepState.execute();
            
            if (prepState.list().size() > 0) {
                
                Iterator<SQLResultRow> iter = prepState.list().iterator();
                
                while (iter.hasNext()) {
                
                    SQLResultRow sqlRow = (SQLResultRow) iter.next();
                    BigInteger seq = (BigInteger) sqlRow.getInteger("SEQ_NUM");
                    ToDoDrillKeyType_Id tdDrillKeyTypeID = new ToDoDrillKeyType_Id(tdTypeID, seq);
                    returnValue.add(tdDrillKeyTypeID.getEntity());
                }                               
            }           
            prepState.close();
            return returnValue;
            
        }
              
    }

}
