/*
 **************************************************************************
 *
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Turn On or Avoid Severance lookup
 * 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2015-03-11   JHERNA  MGE-CCB017. Initial Version.
 **************************************************************************
 */
package com.splwg.cm.api.lookup;

/**
 * @author 90622
 *
 @LookupFieldname (value = CM_TURN_ON_OR_AVOID_SVRNCE_FLG)
 */
public class CmTurnOnOrAvoidSeveranceLookup_Impl 
		extends CmTurnOnOrAvoidSeveranceLookup_Gen {

}

