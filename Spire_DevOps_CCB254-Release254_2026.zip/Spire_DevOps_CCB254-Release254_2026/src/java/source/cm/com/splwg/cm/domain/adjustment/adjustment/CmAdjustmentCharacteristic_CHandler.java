/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Adjustment Characteristic User Exit
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2021-05-31   GCrisp          CCB041.3 Void Checking - Initial version
 * 2021-06-29   GCrisp          CCB041.Issue1. Null pointer fix
 * 2023-06-14   DLampa          E-04899.3. Updated to raise an error when
 *                              A/P Request is already escheated.
 **************************************************************************/
package com.splwg.cm.domain.adjustment.adjustment;

import com.splwg.base.api.DataTransferObject;
import com.splwg.base.api.changehandling.AbstractChangeHandler;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.security.applicationService.ApplicationService;
import com.splwg.base.domain.security.applicationService.ApplicationService_Id;
import com.splwg.base.domain.security.securityType.SecurityAuthorizationLevel;
import com.splwg.base.domain.security.securityType.SecurityAuthorizationLevel_Id;
import com.splwg.base.domain.security.securityType.SecurityType_Id;
import com.splwg.ccb.api.lookup.AdjustmentStatusLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic_DTO;
import com.splwg.ccb.domain.adjustment.adjustment.entity.ApCheckRequest;
import com.splwg.ccb.domain.admin.apRequestType.entity.ApRequestType;
import com.splwg.ccb.domain.admin.apRequestType.entity.ApRequestType_Id;
import com.splwg.cm.api.lookup.CmAdjCharChandlerParmLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever_Impl;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author GCrisp
 *
@ChangeHandler (entityName = adjustmentCharacteristic)
 */
public class CmAdjustmentCharacteristic_CHandler extends
        AbstractChangeHandler<AdjustmentCharacteristic> {
    // Constants
    private static final String XACP_FEAT_CONFG = "CM_ADJCHPRM";

    // Soft Parameters
    private String refundApReqType;
    private String voidReqAdjCharType;
    private String adjAppSvcId;
    private String adjTypeSecType;
    private String securityAuthLvl;

    @Override
    public void handleAddOrChange(AdjustmentCharacteristic adjustmentCharacteristic,
            DataTransferObject<AdjustmentCharacteristic> oldDTO) {
        retrieveAndValidateParameters();

        Adjustment adj = adjustmentCharacteristic.fetchIdAdjustment();

        // Check if Adjustment is a Refund Adjustment
        // Start Add - GCrisp - 06-29-2021 - CCB041.Issue1
        if(notNull(adj.getAdjustmentType().fetchAutopayRequestType())){
        // End Add - GCrisp - 06-29-2021 - CCB041.Issue1
            if(adj.getAdjustmentType().fetchAutopayRequestType()
                    .getId().getTrimmedValue().equalsIgnoreCase(refundApReqType)){

                // Check if Characteristic being added is Void AP Characteristic
                if(adjustmentCharacteristic.fetchIdCharacteristicType().getId().getIdValue().trim()
                    .equalsIgnoreCase(voidReqAdjCharType)){
                    // Check if the user is authorized to add the Adjustment Characteristic.

                    if(isUserAuthorized().isFalse()) {
                        // Error: You do not have security access to add/change an adjustment characteristic of type %1.
                        addError(CustomMessageRepositorySpireOne.CCB041_3_userHasNoSecurityAccess(voidReqAdjCharType));
                    }
                    // Check if Adjustment is already canceled
                    if(adj.getAdjustmentStatus()
                        .compareTo(AdjustmentStatusLookup.constants.CANCELED) == 0) {
                        // Error: Cannot mark this Adjustment as void. The Adjustment has already been canceled
                        addError(CustomMessageRepositorySpireOne.CCB041_3_adjustmentAlreadyCanceled());
                    }
                    // Check if Adjustment is not yet frozen
                    if(adj.getAdjustmentStatus()
                        .compareTo(AdjustmentStatusLookup.constants.FROZEN) != 0) {
                        // Error: Cannot mark this Adjustment as void. The Adjustment is not yet frozen
                        addError(CustomMessageRepositorySpireOne.CCB041_3_adjustmentNotYetFrozen());
                    }
                    for(ApCheckRequest apRequest : adj.getApCheckRequests()) {

                        // Check if AP Request is already paid
                        if(apRequest.getPaymentSelectionStatus().isPaid()){
                            // Error: Cannot mark this Adjustment as void. The Adjustment has already been paid
                            addError(CustomMessageRepositorySpireOne.CCB041_3_adjustmentAlreadyPaid());
                        }
                        // Check if AP Request is not selected for payment
                        if(apRequest.getPaymentSelectionStatus().isNotSelectedforPayment()){
                            // Error: The Adjustment can still be canceled, there is no need to mark this Adjustment as void.
                            addError(CustomMessageRepositorySpireOne.CCB041_3_adjustmentAlreadyCanStillBeCanceled());
                        }

                        // Start Add - DLampa - 06-14-2023 - E-04899.3
                        // Check if AP Request is escheated
                        if(apRequest.getPaymentSelectionStatus().isConvertError()){
                            // Error: Cannot mark this adjustment as void. The adjustment has already been escheated.
                            addError(CustomMessageRepositorySpireOne.E04899_3_adjustmentAlreadyEscheated());
                        }
                        // End Add - DLampa - 06-14-2023 - E-04899.3
                    }
                }
            }
        // Start Add - GCrisp - 06-29-2021 - CCB041.Issue1
        }
        // End Add - GCrisp - 06-29-2021 - CCB041.Issue1
    }

    @Override
    public void handleDelete(DataTransferObject<AdjustmentCharacteristic> oldDTO) {
        retrieveAndValidateParameters();
        if(!isNull(oldDTO)){
            AdjustmentCharacteristic_DTO adjCharDTO = (AdjustmentCharacteristic_DTO) oldDTO;
            Adjustment oldAdj = adjCharDTO.getId().getAdjustment();
            // Check if Adjustment is a Refund Adjustment
            // Start Add - GCrisp - 06-29-2021 - CCB041.Issue1
            if(notNull(oldAdj.getAdjustmentType().fetchAutopayRequestType())){
            // End Add - GCrisp - 06-29-2021 - CCB041.Issue1
                if(oldAdj.getAdjustmentType().fetchAutopayRequestType()
                            .getId().getTrimmedValue().equalsIgnoreCase(refundApReqType)){
                    // Validate if user is authorized to delete the Voiding Request Characteristic
                    if(adjCharDTO.getId().getCharacteristicTypeId().getTrimmedValue()
                            .equalsIgnoreCase(voidReqAdjCharType)){
                        if(isUserAuthorized().isFalse()) {
                            // Error: You do not have security access to add/change an adjustment characteristic of type %1.
                            addError(CustomMessageRepositorySpireOne.CCB041_3_userHasNoSecurityAccess(voidReqAdjCharType));
                        }
                    }
                }
            // Start Add - GCrisp - 06-29-2021 - CCB041.Issue1
            }
            // End Add - GCrisp - 06-29-2021 - CCB041.Issue1
        }
    }

    /**
     * This method checks if the user belongs to a user group having a specific security level on the Adjustment
     * Characteristic application service.
     * Adjustment Characteristic application service must also not be expired and have an 'Add' access mode for the user group.
     * @return Bool
     */
    private Bool isUserAuthorized() {

        Bool authFound = Bool.FALSE;

        ApplicationService_Id appServiceId = new ApplicationService_Id(adjAppSvcId);
        SecurityType_Id secTypeId = new SecurityType_Id(adjTypeSecType);
        SecurityAuthorizationLevel_Id secAuthLvlId = new SecurityAuthorizationLevel_Id(secTypeId, securityAuthLvl);

        // Check if the User has the required Authorization Level
        if(getActiveContextUser().hasAuthorization(appServiceId.getEntity(), secAuthLvlId)) {
            authFound = Bool.TRUE;
        }

        return authFound;
    }

    /**
     * Retrieve and Validate Parameters
     */
    private void retrieveAndValidateParameters() {
        CmFeatureConfigurationRetriever_Impl featConfigRetriever = new CmFeatureConfigurationRetriever_Impl();
        FeatureConfiguration_Id featConfigId = new FeatureConfiguration_Id(XACP_FEAT_CONFG);
        featConfigRetriever.setParmWFMName(featConfigId.getEntity());

        // Retrieve and validate AP Request Type value from Feature configuration
        featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_AP_REQUEST_TYPE.value());
        refundApReqType = featConfigRetriever.getMaxSequenceOptionValue().trim();
        if (isBlankOrNull(refundApReqType)){
            addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "AP Request Type"));
        }
        ApRequestType apReqType = new ApRequestType_Id(refundApReqType).getEntity();
        if(isNull(apReqType)) {
            addError(CustomMessageRepositorySpireOne.CCB041_3_invalidApReqType(refundApReqType, XACP_FEAT_CONFG));
        }

        // Retrieve and validate Characteristic Type value from Feature configuration
        featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_VOID_REQ_ADJ_CHAR_TYPE.value());
        voidReqAdjCharType = featConfigRetriever.getMaxSequenceOptionValue().trim();
        if (isBlankOrNull(voidReqAdjCharType)){
            addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Void Request Adjustment Characteristic Type"));
        }
        CharacteristicType charType = new CharacteristicType_Id(voidReqAdjCharType).getEntity();
        if(isNull(charType)) {
            addError(CustomMessageRepositorySpireOne.CCB041_3_invalidCharType(voidReqAdjCharType, XACP_FEAT_CONFG));
        }

        // Retrieve and validate Application Service value from Feature configuration
        featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_APP_SERVICE.value());
        adjAppSvcId = featConfigRetriever.getMaxSequenceOptionValue().trim();
        if (isBlankOrNull(adjAppSvcId)){
            addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Application Service"));
        }
        ApplicationService appSvc = new ApplicationService_Id(adjAppSvcId).getEntity();
        if(isNull(appSvc)) {
            addError(CustomMessageRepositorySpireOne.CCB041_3_invalidAppService(adjAppSvcId, XACP_FEAT_CONFG));
        }

        // Retrieve and validate Security Type value from Feature configuration
        featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_SEC_TYPE.value());
        adjTypeSecType = featConfigRetriever.getMaxSequenceOptionValue();
        if (isBlankOrNull(adjTypeSecType)){
            addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Security Type"));
        }
        SecurityType_Id secTypeId = new SecurityType_Id(adjTypeSecType);
        if(isNull(secTypeId.getEntity())) {
            addError(CustomMessageRepositorySpireOne.CCB041_3_invalidSecurityType(adjTypeSecType, XACP_FEAT_CONFG));
        }

        // Retrieve and validate Authorization Level value from Feature configuration
        featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_AUTH_LEVEL.value());
        securityAuthLvl = featConfigRetriever.getMaxSequenceOptionValue();
        if (isBlankOrNull(securityAuthLvl)){
            addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Authorization Level"));
        }
        SecurityAuthorizationLevel authLvl = new SecurityAuthorizationLevel_Id(secTypeId, securityAuthLvl).getEntity();
        if(isNull(authLvl)) {
            addError(CustomMessageRepositorySpireOne.CCB041_3_authorizationLevelNotValid(securityAuthLvl, XACP_FEAT_CONFG, adjTypeSecType));
        }
    }
}
