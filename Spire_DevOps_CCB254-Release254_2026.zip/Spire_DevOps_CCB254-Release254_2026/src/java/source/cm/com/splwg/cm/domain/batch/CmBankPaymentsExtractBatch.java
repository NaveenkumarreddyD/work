/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This batch will extract the bank payment details from the 
 * CM_TOP_BANK_STG table and create the file to be sent to the payment
 * processor.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2019-10-16   JLumbre     SpireOne. B-11576. Initial version.
 * 2020-02-20   JLumbre		SpireOne. B-14863. Decrypt bank account before 
 * 							extraction.
 * 2021-02-16   JLumbre 	SAP Conversion. Extract per company code.
 * 2025-11-14   EQuint      CCB25.4 Upgrade     
 * 2026-05-18	EQuint		INC0081508. Corrected get payment ID query                                                                     
 * *************************************************************************                
 */
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessService.BusinessServiceDispatcher;
import com.splwg.base.api.businessService.BusinessServiceInstance;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.PaymentStatusLookup;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.payment.payment.entity.Payment_Id;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentEvent_Id;
import com.splwg.cm.api.lookup.RecordStatusFlgLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.cm.domain.payment.payment.CmOneTimeBankPaymentsStaging;
import com.splwg.cm.domain.payment.payment.CmOneTimeBankPaymentsStaging_DTO;
import com.splwg.cm.domain.payment.payment.CmOneTimeBankPaymentsStaging_Id;
import com.splwg.shared.common.ServerMessage;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author TMG02631
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules={},
 *      softParameters = { @BatchJobSoftParameter (name = filePath, required = true, type = string)
 *            , @BatchJobSoftParameter (name = fileName, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CIS_DIVISION, type = string)})
 */
public class CmBankPaymentsExtractBatch extends CmBankPaymentsExtractBatch_Gen {

	public static Logger log = LoggerFactory.getLogger(CmBankPaymentsExtractBatch.class);
	public BigInteger parmMaxErrors;
	//Start Add - JLumbre - 2021-02-16 - SAP Conversion
	private String companyCodeStr;
	private String companyCodes = "";
	//End Add - JLumbre - 2021-02-16 - SAP Conversion

	@Override
	public void validateSoftParameters(boolean isNewRun) {
		// Validate that File Path is a valid directory
		if (notBlank(getParameters().getFilePath())){
			File tempPath = new File(getParameters().getFilePath());
			if (!tempPath.isDirectory()){
				addError(CustomMessageRepositorySpireOne.S1_FilePathInvalid(getParameters().getFilePath()));
			}
		}

		parmMaxErrors = getParameters().getSoftMaxErrors();	
		log.info(">>>>> parmMaxErrors: " + parmMaxErrors);
		if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
			addError(CustomMessageRepositorySpireOne.S1_MaxErrorCannotBeLessThanZero(parmMaxErrors.toString().trim()));
		}
		
		//Start Add - JLumbre - 2021-02-16 - SAP Conversion
		companyCodeStr = getParameters().getCIS_DIVISION();
		
		String[] companyCodes = companyCodeStr.split(",");
		for (String companyCodeDiv : companyCodes){			
			if (!isNull(new CisDivision_Id(companyCodeDiv)) && isNull(new CisDivision_Id(companyCodeDiv).getEntity())){
				addError(CustomMessageRepositorySpireOne.S1_invalidCisDivision(companyCodeDiv));
			}
		}	
		//End Add - JLumbre - 2021-02-16 - SAP Conversion
	} 
	
	//Start Add - JLumbre - 2021-02-16 - SAP Conversion
	private String encloseCompanyCodesInQuotes(String cisDivision){
        StringBuilder cisDivisionStringBuilder = new StringBuilder();
        String[] cisDivisions = cisDivision.split(",");
        
        cisDivisionStringBuilder.append("'");

        for (int i = 0; i < cisDivisions.length; i++){
        	cisDivisionStringBuilder.append(cisDivisions[i] + "'");
            if (i < cisDivisions.length - 1) {
            	cisDivisionStringBuilder.append(",'");
            }
        }
        
        return cisDivisionStringBuilder.toString();
    }
	//End Add - JLumbre - 2021-02-16 - SAP Conversion

	public JobWork getJobWork() {
		
		//Start Add - JLumbre - 2021-02-16 - SAP Conversion
		companyCodeStr = getParameters().getCIS_DIVISION();
		if(!isBlankOrNull(companyCodeStr)){
			companyCodes = encloseCompanyCodesInQuotes(companyCodeStr);
		}
		//End Add - JLumbre - 2021-02-16 - SAP Conversion
		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
		
		StringBuilder qryStr = new StringBuilder();
		qryStr.append("SELECT PAY_EVENT_ID FROM CM_TOP_BANK_PAY_STG ");
		qryStr.append("WHERE RECORD_STATUS_FLG = :pending ");
		//Start Add - JLumbre - 2021-02-16 - SAP Conversion
		if (!isBlankOrNull(companyCodeStr)){
			qryStr.append("AND TRIM(CM_CIS_DIVISION) IN (" +  companyCodes + ")");
		}
		//End Add - JLumbre - 2021-02-16 - SAP Conversion


		PreparedStatement ps = createPreparedStatement(qryStr.toString(), "getJobWork");
		ps.bindLookup("pending", RecordStatusFlgLookup.constants.PENDING);
				
		ps.setAutoclose(false);
		ps.execute();
		

		QueryIterator<SQLResultRow> row = ps.iterate();
		while (row.hasNext()){
			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId(new CmOneTimeBankPaymentsStaging_Id(row.next().getString("PAY_EVENT_ID")));
			workUnits.add(workUnit);
		}
		row.close();
		ps.close();

		return createJobWorkForThreadWorkUnitList(workUnits);
	}



	public Class<CmBankPaymentsExtractBatchWorker> getThreadWorkerClass() {
		return CmBankPaymentsExtractBatchWorker.class;
	}

	public static class CmBankPaymentsExtractBatchWorker extends
	CmBankPaymentsExtractBatchWorker_Gen {

		//soft parameters
		private String filePath;
		private String fileName;
		private BigInteger maxErrors = BigInteger.ZERO;


		// Work variables
		private File extractFile;
		private BufferedWriter extractFileWriter;
		//private PreparedStatement prepSt;

		private Money totalPaymentAmount = Money.ZERO;
		private int recordCount = 0;
		private int errorRecordCount = 0;

		private static String COMMA_SEPARATOR = ",";
		private static String DETAIL_RECORD = "D";
		private static String TRAILER_RECORD = "T";		



		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
						throws ThreadAbortedException, RunAbortedException {

			// Retrieve parameters
			filePath = getParameters().getFilePath();
			fileName = getParameters().getFileName();  
			maxErrors = getParameters().getSoftMaxErrors();
			log.info(">>>>> maxErrors:" + maxErrors);


			// Open Extract File
			try {
				extractFile = new File(filePath,fileName);   
				extractFileWriter = new BufferedWriter(new FileWriter(extractFile));     
			}
			catch(Exception e) {
				e.printStackTrace();
				throw new RunAbortedException(CustomMessageRepositorySpireOne.S1_GenericErrorOpeningFile(extractFile.getAbsolutePath()));
			}


		}
		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			CmOneTimeBankPaymentsStaging_Id bnkPayStgId = (CmOneTimeBankPaymentsStaging_Id) unit.getPrimaryId();
			CmOneTimeBankPaymentsStaging bnkPayStg = bnkPayStgId.getEntity();

			PaymentEvent_Id payEventId = new PaymentEvent_Id(bnkPayStgId.getTrimmedValue());
			if (notNull(payEventId.getEntity())){

				// start change - EQuint - INC0081508 - 2026-05-18
				// Payment_Id payId = getPayId(payEventId);
				// if (isNull(payId) || isNull (payId.getEntity())){						
				// 	logErrorMessage(CustomMessageRepositorySpireOne.S1_PaymentCannotBeExtracted(payEventId.getTrimmedValue()));
				// 	return false;
				// }
				// else{				
				// 	if (payId.getEntity().getPaymentStatus().isError() || payId.getEntity().getPaymentStatus().isCanceled()){
				// 		logErrorMessage(CustomMessageRepositorySpireOne.S1_PaymentCannotBeExtracted(payEventId.getTrimmedValue()));							
				// 		return false;
				// 	}
				// 	else{
				// 		writeToFile(bnkPayStg);
				// 		updateStagingRecord(bnkPayStg);
				// 	}
				// }
				
				Query<Payment_Id> frozenPaymentQuery = getFrozenPayment(payEventId);
				Payment_Id payId = frozenPaymentQuery.firstRow();
				if (isNull(payId) || isNull (payId.getEntity())){						
					logErrorMessage(CustomMessageRepositorySpireOne.S1_PaymentCannotBeExtracted(payEventId.getTrimmedValue()));
					return false;
				}
				else{
					writeToFile(bnkPayStg);
					updateStagingRecord(bnkPayStg);
				}
				// end change - EQuint - INC0081508 - 2026-05-18
			}
			else{				
				logErrorMessage(CustomMessageRepositorySpireOne.S1_InvalidStagingId(payEventId.getTrimmedValue()));
				return false;
			}

			return true;
		}

		private void writeToFile(CmOneTimeBankPaymentsStaging bnkPayStg){

			//Start Add - JLumbre - B-14863
			//Decrypt bank account number
			String decryptedAcctNbr;
			if (!isBlankOrNull(bnkPayStg.getCmEncryptedBankAccountNumber())){
				BusinessServiceInstance decryptBS = BusinessServiceInstance.create("F1-Decrypt");
				decryptBS.set("encrValue", bnkPayStg.getCmEncryptedBankAccountNumber());
				decryptBS.set("tableName", "CM_TOP_BANK_PAY_STG");
				decryptBS.set("fieldName", "BANK_ACCOUNT_NBR");

				BusinessServiceInstance output = BusinessServiceDispatcher.execute(decryptBS);
				decryptedAcctNbr = output.getString("plainText");
			}
			else{
				decryptedAcctNbr = bnkPayStg.getBankAccountNumber();
			}
			//End Add - JLumbre - B-14863

			StringBuilder record = new StringBuilder();	

			record.append(DETAIL_RECORD);	
			record.append(COMMA_SEPARATOR);
			record.append(bnkPayStg.getId().getTrimmedValue());
			record.append(COMMA_SEPARATOR);
			record.append(bnkPayStg.getRecordStatusFlag().getLookupValue().fetchIdFieldValue().trim());
			record.append(COMMA_SEPARATOR);
			record.append(bnkPayStg.getFirstName().trim());
			record.append(COMMA_SEPARATOR);
			record.append(bnkPayStg.getLastName().trim());
			record.append(COMMA_SEPARATOR);
			record.append(bnkPayStg.getAccountId().trim());
			record.append(COMMA_SEPARATOR);
			record.append(bnkPayStg.getPaymentAmount().getAmount());
			record.append(COMMA_SEPARATOR);
			record.append(bnkPayStg.getPaymentDate().toString());
			record.append(COMMA_SEPARATOR);
			// start update - equint - 2025-11-14 - CCB25.4 Upgrade
			// record.append(bnkPayStg.getRoutingNumber().trim());
			record.append(bnkPayStg.getRoutingNbr().trim());
			// end update - equint - 2025-11-14 - CCB25.4 Upgrade
			record.append(COMMA_SEPARATOR);
			//Start Change - JLumbre - B-14863
			//record.append(bnkPayStg.getBankAccountNumber().trim());
			record.append(decryptedAcctNbr.trim());
			//End Change - JLumbre - B-14863
			record.append(COMMA_SEPARATOR);
			record.append(bnkPayStg.getTenderType().trim());
			record.append(COMMA_SEPARATOR);
			record.append(bnkPayStg.getPaymentSource().trim());

			try {
				extractFileWriter.write(record.toString());
				extractFileWriter.newLine();

				recordCount = recordCount + 1;
				totalPaymentAmount = totalPaymentAmount.add(bnkPayStg.getPaymentAmount());
			}
			catch (Exception e) {
				e.printStackTrace();
				throw new RunAbortedException(CustomMessageRepositorySpireOne.S1_GenericErrorWritingToFile(extractFile.getAbsolutePath()));
			}

		}

		public void updateStagingRecord(CmOneTimeBankPaymentsStaging bnkPayStg){

			CmOneTimeBankPaymentsStaging_DTO dto = bnkPayStg.getDTO();
			dto.setRecordStatusFlag(RecordStatusFlgLookup.constants.COMPLETE);
			bnkPayStg.setDTO(dto);

		}
		
		// start add - EQuint - INC0081508 - 2026-05-18
		public Query<Payment_Id> getFrozenPayment(PaymentEvent_Id payEventId) {
			Query<Payment_Id> retrieveFrozenPayment =  createQuery(
				"FROM Payment pay " +
				"WHERE pay.paymentEvent.id = :payEventId " + 
				"AND pay.paymentStatus = :frozen", 
			"getFrozenPayment");
			
			retrieveFrozenPayment.bindId("payEventId", payEventId);
			retrieveFrozenPayment.bindLookup("frozen", PaymentStatusLookup.constants.FROZEN);

			retrieveFrozenPayment.addResult("payId", "pay.id");
			
			return retrieveFrozenPayment;
		}
		// end add - EQuint - INC0081508 - 2026-05-18

		public Payment_Id getPayId(PaymentEvent_Id payEventId){
			Payment_Id payId = null;

			StringBuilder getPayId = new StringBuilder();
			getPayId.append("FROM Payment pay ");
			getPayId.append("WHERE pay.paymentEvent = :payEventId ");

			Query<Payment_Id> retrievePayId =  createQuery(getPayId.toString(), "getPayId");
			retrievePayId.bindId("payEventId", payEventId);
			retrievePayId.addResult("payId", "pay.id");

			payId = retrievePayId.firstRow();		

			return payId;

		}

		public void logErrorMessage (ServerMessage msg){
			errorRecordCount = errorRecordCount +1;
			
			if (notNull(maxErrors) && errorRecordCount == maxErrors.intValue()) {

				logError(CustomMessageRepositorySpireOne.S1_maxErrorReached(maxErrors));
			}
			log.info(">>>>> errorRecordCount: " + errorRecordCount);
			logError(msg);
		}


		public void finalizeThreadWork() throws ThreadAbortedException,
		RunAbortedException {

			//Write Trailer Record
			StringBuilder trailer = new StringBuilder();
			trailer.append(TRAILER_RECORD);
			trailer.append(COMMA_SEPARATOR);
			trailer.append(String.valueOf(recordCount));
			trailer.append(COMMA_SEPARATOR);
			trailer.append(totalPaymentAmount.getAmount().toString().trim());


			// Close Extract File
			try {            	
				extractFileWriter.write(trailer.toString());
				extractFileWriter.close();   

			}
			catch(Exception e) {
				e.printStackTrace();
				throw new RunAbortedException(CustomMessageRepositorySpireOne.S1_GenericErrorClosingFile(extractFile.getAbsolutePath()));								
			}

			logMessage(CustomMessageRepositorySpireOne.S1_TotalRecordsExtracted(recordCount), MessageSeverityLookup.constants.INFORMATIONAL);
			logMessage(CustomMessageRepositorySpireOne.S1_SumOfPayAmountExtracted(totalPaymentAmount), MessageSeverityLookup.constants.INFORMATIONAL);
			logMessage(CustomMessageRepositorySpireOne.S1_TotalRecordsNotExtracted(errorRecordCount), MessageSeverityLookup.constants.INFORMATIONAL);

		}


	}

}
