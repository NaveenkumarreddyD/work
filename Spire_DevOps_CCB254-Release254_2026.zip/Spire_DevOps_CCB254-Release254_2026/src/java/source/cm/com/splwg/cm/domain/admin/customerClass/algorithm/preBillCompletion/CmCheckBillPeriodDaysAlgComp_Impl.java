/*
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                     
 * 
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * CCB204 / B-20851 - To Dos for Long and Short Bills
 * 
 * This algorithm will check the bill period days of each bill segment,
 * and either raise a warning or create an exception if the total bill 
 * days does not fall within the acceptable usage period range. 
 *
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:       by:          Reason:
 * YYYY-MM-DD  FLName
 * 2022-02-14  DLampa       CCB204/B-20851. Initial Version.
 * 2022-03-15  DLampa       CCB204/B-20851.Issue1. Exclude initial 
 *                          and closing bills from validation. 
 * 2025-06-16  Bhaskar Yerr Story B-38556. Skip Bill exception if allow long bill completion char is present on Bill
 * 
 ***********************************************************************
 */

package com.splwg.cm.domain.admin.customerClass.algorithm.preBillCompletion;

import java.math.BigInteger;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.message.MessageCategory;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.ccb.api.lookup.BillCompletionActionLookup;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.domain.admin.customerClass.algorithm.preBillCompletion.CustomerClassPreBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.frequency.entity.Frequency;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ServerMessage;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = standardBillPeriodDays, required = true, type = integer)
 *            , @AlgorithmSoftParameter (entityName = frequency, name = frequency, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = serviceQuantityIdentifier, name = billPeriodDaysSQ, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = messageCategory, name = messageCat, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = messageNbr, required = true, type = integer)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = allowBillCompChar, required = true, type = entity)})
 */
public class CmCheckBillPeriodDaysAlgComp_Impl extends
        CmCheckBillPeriodDaysAlgComp_Gen implements
        CustomerClassPreBillCompletionAlgorithmSpot {

    // Soft parameters
    private BigInteger standardBillPeriodDays;
    private Frequency frequency;
    private ServiceQuantityIdentifier billPeriodDaysSQI;
    private MessageCategory messageCategory;
    private BigInteger messageNumber;
    //B-38556 - 2025-06-16 - Start Add
    private CharacteristicType allowLongBillCompChar;
    private static final Logger logger = LoggerFactory.getLogger(CmCheckBillPeriodDaysAlgComp_Impl.class);
    //B-38556 - 2025-06-16 - End Add
    // Input hard parameters
    private Bill creditNoteForBill;
    private Bill bill;
    private Bill_Id cureBill;
    private  BillSegment_Id previousBillSegmentId;
	private Account account;
	private Date accountingDate;
	private Date billDate;
	private Date CurEndBillSegDate;
	private List<BillSegment> billSegments;
	
	// Input/Output hard parameters
	private Bool allowReopeningOfBills;

	// Output hard parameters
	private BillCompletionActionLookup billCompletionAction;
	private ServerMessage serverMessage;
    private BigInteger monthsUsed;
    private BigDecimal billSegmentAmountfromNMonthsAgo;
    private BigDecimal referenceBillSegmentAmount;
    private BigDecimal dailyAveragefromNMonthsAgo;
    private BigDecimal referenceBillDailyAverage;
    
    // Work variables
    private Message_Id messageId;
    private BigDecimal minimumPeriodDays;
    private BigDecimal maximumPeriodDays;
    
    @Override
    public void setAccount(Account account) {
	    this.account = account;
    }

    @Override
    public void setAccountingDate(Date arg0) {
    	this.accountingDate = arg0;
    }

    @Override
    public void setBill(Bill bill) {
    	this.bill = bill;
    }

    @Override
    public void setBillDate(Date arg0) {
    	this.billDate = arg0;
    }

    @Override
    public void setCreditNoteForBill(Bill creditNoteForBill) {
    	this.creditNoteForBill = creditNoteForBill;
    }

    @Override
    public void setAllowReopeningOfBills(Bool allowReopeningOfBills) {
    	this.allowReopeningOfBills = allowReopeningOfBills;
    }

	@Override
	public void setBillSegments(List<BillSegment> arg0) {
		this.billSegments = arg0;
	}

    @Override
    public Bool getAllowReopeningOfBills() {
    	return allowReopeningOfBills;
    }

    @Override
    public BillCompletionActionLookup getBillCompletionAction() {
    	return billCompletionAction;
    }

    @Override
    public ServerMessage getServerMessage() {
	    return serverMessage;
    }

    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

    	standardBillPeriodDays = getStandardBillPeriodDays();
        if (BigInteger.ZERO.compareTo(standardBillPeriodDays) >= 0) {
        	addError(CustomMessageRepositorySpireOne.CCB204_AlgorithmParmMustBeGreaterThanZero(getAlgorithmId().getTrimmedValue()
        			, getAlgorithm().getAlgorithmType().getParameterAt(0).fetchLanguageParameterLabel()
        			, standardBillPeriodDays.toString().trim()));
        }
        
        messageCategory = getMessageCat();
        messageNumber = getMessageNbr();        
        messageId = new Message_Id(messageCategory, messageNumber);
        
        if (isNull(messageId.getEntity())) {        	
            addError(CustomMessageRepositorySpireOne.CCB204_AlgorithmParmMessageNbrInvalidForCategory(getAlgorithmId().getTrimmedValue()
        			, getAlgorithm().getAlgorithmType().getParameterAt(4).fetchLanguageParameterLabel()
        			, messageNumber.toString().trim()
        			, getAlgorithm().getAlgorithmType().getParameterAt(3).fetchLanguageParameterLabel()
        			, messageCategory.getId().getIdValue().toString().trim()));
        }        
        
        billPeriodDaysSQI = getBillPeriodDaysSQ();
        frequency = getFrequency();
      //B-38556 - 2025-06-16 - Start Add
        allowLongBillCompChar = getAllowBillCompChar();
      //B-38556 - 2025-06-16 - End Add
        
  
        
        
        super.extraSoftParameterValidations(forAlgorithmValidation);

    }

    @Override
    public void invoke() {

    	// Determine the acceptable usage period days
    	minimumPeriodDays = new BigDecimal(standardBillPeriodDays.add(frequency.getOffsetForMinimumDays().negate()));
    	maximumPeriodDays = new BigDecimal(standardBillPeriodDays.add(frequency.getOffsetForMaximumDays()));
    	
    	
    	List<SQLResultRow> billSegmentsList = retrieveBillSegments();
        
    	for(SQLResultRow billSegmentResultRow: billSegmentsList){
    		BillSegment_Id billSegmentId = (BillSegment_Id) billSegmentResultRow.getId("BSEG_ID", BillSegment.class);
    		BigDecimal periodDaysSQ = billSegmentResultRow.getBigDecimal("BILL_SQ");
    		
    		// If the bill segment's period days is not within the acceptable range,
    		if (!(periodDaysSQ.compareTo(minimumPeriodDays) >= 0 && periodDaysSQ.compareTo(maximumPeriodDays) <= 0)) {
    			// Start Add - DLampa - Issue1 - 2022-03-15
    			// Proceed with the error only if the bill segment is neither an initial or closing segment
    			if (billSegmentId.getEntity().getIsClosingBillSegment().isFalse()
    					&& isInitialBillSegment(billSegmentId).isFalse()) {
    				
    			// End Add - DLampa - Issue1 - 2022-03-15
    			
		            MessageParameters messageparameters = new MessageParameters();
		            messageparameters.addRawString(bill.getId().getTrimmedValue());
		            messageparameters.addRawString(billSegmentId.getTrimmedValue());
		            messageparameters.addRawString(String.valueOf(periodDaysSQ.intValue()));
		            messageparameters.addRawString(minimumPeriodDays.toString());
		            messageparameters.addRawString(maximumPeriodDays.toString());
		            
		            serverMessage = ServerMessageFactory.Factory.newInstance().createMessage(messageCategory.getId(), messageNumber.intValue(), messageparameters);
	    			
	    	        // If the call to this routine is "Batch", create an exception. Otherwise, raise a warning.
		           
	    	        if (!isOnlineConnection()) {  
	    	        	// Start update - Bhaskar - Story B-38556 - 2025-06-16
			            //added condition to check the long bill char
			            //If long bill char is not present on bill then only create exception
	    	            //billCompletionAction = BillCompletionActionLookup.constants.CREATE_EXCEPTION;
	    	            if(getBillCharSequence(bill, allowLongBillCompChar).equals(BigInteger.ZERO)){
	    	            	billCompletionAction = BillCompletionActionLookup.constants.CREATE_EXCEPTION;
	    	            }
	    	           //End update - Bhaskar - Story B-38556 - 2025-06-16	
	    	        } else {
	    	            addWarning(serverMessage);
	    	        }
	    	        
	    	        // Exit processing, no need to loop through the rest of the segments.
		            break;
    			// Start Add - DLampa - Issue1 - 2022-03-15
    			}
    			// End Add - DLampa - Issue1 - 2022-03-15	            
    		}    		
    	}
    	
    }
    
	/**
	 * This method will retrieve all of the bill's segments  
	 * @return List<SQLResultRow>
	 */    
	private List<SQLResultRow> retrieveBillSegments(){

		List<SQLResultRow> billSegmentsList = null;
		StringBuilder billSegmentQueryString = new StringBuilder();
		billSegmentQueryString.append("SELECT BS.BSEG_ID, SQ.BILL_SQ ");
		billSegmentQueryString.append("FROM CI_BSEG BS, CI_BSEG_SQ SQ ");
		billSegmentQueryString.append("WHERE BS.BILL_ID = :billId ");
		billSegmentQueryString.append(  "AND BS.BSEG_STAT_FLG = :frozen ");
		billSegmentQueryString.append(  "AND BS.BSEG_ID = SQ.BSEG_ID ");
		billSegmentQueryString.append(  "AND SQ.SQI_CD = :billPeriodDaysSQI ");
		PreparedStatement billSegmentsPrepStmt = null;

		billSegmentsPrepStmt = createPreparedStatement(billSegmentQueryString.toString(), getClass().getName());
		billSegmentsPrepStmt.bindId("billId", bill.getId());
		billSegmentsPrepStmt.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
		billSegmentsPrepStmt.bindId("billPeriodDaysSQI", billPeriodDaysSQI.getId());

		billSegmentsList = billSegmentsPrepStmt.list();
		billSegmentsPrepStmt.close();
		return billSegmentsList;
	}    

	// Start Add - DLampa - Issue1 - 2022-03-15	
	/**
	 * This method will check if the current bill segment is the initial one for the Service Agreement  
	 * @return Bool
	 */    
	private Bool isInitialBillSegment(BillSegment_Id bsegId){
 
		BillSegment bseg = bsegId.getEntity();
		
		StringBuilder initialBillSegmentQueryString = new StringBuilder();
		initialBillSegmentQueryString.append("SELECT BS.BSEG_ID ");
		initialBillSegmentQueryString.append("FROM CI_BSEG BS, CI_SA SA ");
		initialBillSegmentQueryString.append("WHERE BS.SA_ID = SA.SA_ID ");		
		initialBillSegmentQueryString.append(  "AND SA.SA_ID = :saId ");
		initialBillSegmentQueryString.append(  "AND BS.START_DT < :currBsegStartDt ");
		initialBillSegmentQueryString.append(  "AND BS.BSEG_STAT_FLG = :frozen ");
		initialBillSegmentQueryString.append(  "AND BS.MASTER_BSEG_ID = ' ' ");
		PreparedStatement initialBillSegmentPrepStmt = null;

		initialBillSegmentPrepStmt = createPreparedStatement(initialBillSegmentQueryString.toString(), getClass().getName());
		initialBillSegmentPrepStmt.bindId("saId", bseg.getServiceAgreement().getId());
		initialBillSegmentPrepStmt.bindDate("currBsegStartDt", bseg.getStartDate());
		initialBillSegmentPrepStmt.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);		

		SQLResultRow initialBillSegment = initialBillSegmentPrepStmt.firstRow();
        if (!isNull(initialBillSegment)) {
        	return Bool.FALSE;
        }	
        		return Bool.TRUE;
		
	}
	// End Add - DLampa - Issue1 - 2022-03-15	
	
	// Start Add - Bhaskar - Story B-38556 - 2025-06-16	
	private BigInteger getBillCharSequence(Bill bill, CharacteristicType charType){

        BigInteger sequence = BigInteger.ZERO;

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT NVL(MAX(SEQ_NUM), 0) AS SEQ_NUM  ");
        stringBuilder.append("FROM CI_BILL_CHAR ");
        stringBuilder.append("WHERE BILL_ID = :bill ");
        stringBuilder.append(  "AND CHAR_TYPE_CD = :charType ");

        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==getBillCharSequence==");
        prepState.bindEntity("bill", bill);
        prepState.bindEntity("charType", charType);
        prepState.setAutoclose(false);
        prepState.execute();

        if (notNull(prepState.firstRow())) {
            SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
            sequence = sqlRow.getInteger("SEQ_NUM");
        }

        prepState.close();

        return sequence;

    }
	// End Add - Bhaskar - Story B-38556 - 2025-06-16		
}

