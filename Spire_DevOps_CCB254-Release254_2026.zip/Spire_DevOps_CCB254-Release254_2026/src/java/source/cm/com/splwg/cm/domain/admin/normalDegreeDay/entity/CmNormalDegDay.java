/****************************************************************************************
 * Program Name: CmAccumulateDegreeDaysAlgComp_Impl
 * Program Title: CmAccumulateDegreeDaysAlgComp_Impl
 * Author: Jain Akshita
 * Creation Date: 2019-05-20
 * Purpose: Maintenance object for normal degree day
 * 
 ******************************************************************************************/
/*----------------------------------------------------------------------------------------
 *-------------------------- Modification HISTORY: ---------------------------------------
 * ---------------------------------------------------------------------------------------
 * Modification ID:   CCTicket:	  Author:          Date:       Description:
.* --------------------------------------------------------------------------------------
 * CCB001  	       	   45936  	 Jain Akshita     2019-05-20   TMG02493 - Initial Version                 
 *                                                      
 *****************************************************************************************/

package com.splwg.cm.domain.admin.normalDegreeDay.entity;

/**
  *  
@EntityPageMaintenance (entity = normalDegreeDay, service = CMNORMALDEG, program = CMNORMALDEG, secured = false,
 *      body = @DataElement (contents = { @RowField (entity = normalDegreeDay, name = normalDegreeDay)}),
 *      modules = {},
 *      actions = { "add"
 *            , "read"
 *            , "change"
 *            , "delete"})
*/

public class CmNormalDegDay
    extends CmNormalDegDay_Gen {
   // empty
}
