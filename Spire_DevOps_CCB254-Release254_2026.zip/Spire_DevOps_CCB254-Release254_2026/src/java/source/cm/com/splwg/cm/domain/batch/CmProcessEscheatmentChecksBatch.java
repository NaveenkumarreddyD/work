/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Process Escheatment Checks
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 * 2023-06-05   DLampa  E-04899.1 Initial version.
 **************************************************************************
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.ccb.api.lookup.CustomerContactStatusLookup;
import com.splwg.ccb.api.lookup.PaymentSelectionStatusLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.ApCheckRequest;
import com.splwg.ccb.domain.adjustment.adjustment.entity.ApCheckRequest_DTO;
import com.splwg.ccb.domain.adjustment.adjustment.entity.ApCheckRequest_Id;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
/**
 * @author DLampa
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *                       , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *                       , @BatchJobSoftParameter (name = ESCHEATED_CUST_CONTACT_CLASS, required = true, type = entity, entityName = customerContactClass)
 *                       , @BatchJobSoftParameter (name = ESCHEATED_CUST_CONTACT_TYPE, required = true, type = string)})
 */

public class CmProcessEscheatmentChecksBatch
        extends CmProcessEscheatmentChecksBatch_Gen {
    
    // Batch Parameters
    private String parmFilePath;
    private String parmFileName;
    
    // Constants
    private String COMMA_DELIMITER = ",";

    @Override
    public void validateSoftParameters(boolean arg0) {

        // File Path must be an existing directory
        String filePath = getParameters().getFILE_PATH();
        File folder = new File(filePath);
        if (!folder.isDirectory()) {
            addError(CustomMessageRepositorySpireOne.E04899_1_InvalidFilePath("FILE_PATH"));
        }

        // Customer contact type must be valid for the customer contact class
        CustomerContactClass customerContactClass = getParameters().getESCHEATED_CUST_CONTACT_CLASS();
        String customerContactTypeStr = getParameters().getESCHEATED_CUST_CONTACT_TYPE();
        CustomerContactType_Id ccTypeId = new CustomerContactType_Id(customerContactClass , customerContactTypeStr);

        if(isNull(ccTypeId.getEntity())) {
            addError(CustomMessageRepositorySpireOne.E04899_1_InvalidCustomerContactTypeForClass("ESCHEATED_CUST_CONTACT_TYPE", customerContactTypeStr , customerContactClass.getId().getTrimmedValue()));
        }
    }

    @Override
    public JobWork getJobWork() {

        List<ThreadWorkUnit> threadWorkUnitList = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit threadWorkUnit = null;

        parmFilePath = getParameters().getFILE_PATH();
        parmFileName = getParameters().getFILE_NAME();        
        
        File file = new File(parmFilePath, parmFileName);
        BufferedReader bufferedReader = null;
        try {
			
        	bufferedReader = new BufferedReader(new FileReader(file));
			
            while (bufferedReader.ready()) {
                String record = bufferedReader.readLine();

                if (isBlankOrNull(record.trim())){
                    // Skip blank lines
                    continue;
                }

                ApCheckRequest_Id apRequestId = new ApCheckRequest_Id(record.split(COMMA_DELIMITER)[1]);                
                String accountNumber = record.split(COMMA_DELIMITER)[0];
                String paymentSelStatus = record.split(COMMA_DELIMITER)[2];
                
                threadWorkUnit = new ThreadWorkUnit();
                threadWorkUnit.setPrimaryId(apRequestId);
                threadWorkUnit.addSupplementalData("accountNumber", accountNumber);
                threadWorkUnit.addSupplementalData("paymentSelStatus", paymentSelStatus);
                threadWorkUnitList.add(threadWorkUnit);
            }
            
            bufferedReader.close();
        } catch (FileNotFoundException fe) {
            addError(CustomMessageRepositorySpireOne.E04899_1_FileNotFound());
        } catch (IOException ioe) {
             addError(CustomMessageRepositorySpireOne.E04899_1_ErrorFileReading(ioe.getMessage()));
             ioe.printStackTrace();
        }

        return createJobWorkForThreadWorkUnitList(threadWorkUnitList);
    }

    public Class<CmProcessEscheatmentChecksBatchWorker> getThreadWorkerClass() {
        return CmProcessEscheatmentChecksBatchWorker.class;
    }

    public static class CmProcessEscheatmentChecksBatchWorker extends
            CmProcessEscheatmentChecksBatchWorker_Gen {

        // Batch Parameters
        private CustomerContactClass parmCcClass;
        private String parmCcType;

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
			
            // Retrieve Batch Parameters            
            parmCcClass = getParameters().getESCHEATED_CUST_CONTACT_CLASS();
            parmCcType = getParameters().getESCHEATED_CUST_CONTACT_TYPE();
			
		}

        @Override
        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {

			String accountNumber = (String) unit.getSupplementallData("accountNumber");
			ApCheckRequest_Id apRequestId = (ApCheckRequest_Id) unit.getPrimaryId();
			String paymentSelStatus = (String) unit.getSupplementallData("paymentSelStatus");
			ApCheckRequest apCheckRequest = apRequestId.getEntity();

			if (notNull(apCheckRequest)){
				PaymentSelectionStatusLookup currPymntSelStat = apCheckRequest.getPaymentSelectionStatus();
				
				// Update the A/P Request's status
				PaymentSelectionStatusLookup pymntSelStatus = LookupHelper.getLookupInstance(PaymentSelectionStatusLookup.class, paymentSelStatus);
				ApCheckRequest_DTO apCheckRequestDto = apCheckRequest.getDTO();
				apCheckRequestDto.setPaymentSelectionStatus(pymntSelStatus);
				apCheckRequest.setDTO(apCheckRequestDto);

				// Create a Customer Contact if A/P Request Status is being updated to Eligible for Escheatment (D)
				if(paymentSelStatus.equalsIgnoreCase(PaymentSelectionStatusLookup.constants.NEGATIVE_VOUCHER_SUM.trimmedValue())
						|| (!currPymntSelStat.isNegativeVoucherSum() 
						&& paymentSelStatus.equalsIgnoreCase(PaymentSelectionStatusLookup.constants.CONVERT_ERROR.trimmedValue()))){
					CustomerContactType_Id ccTypeId = new CustomerContactType_Id(parmCcClass, parmCcType.trim());

					Account_Id acctId = new Account_Id(accountNumber);
					Account account = acctId.getEntity();
					if (notNull(account) && doesCcExist(account, ccTypeId.getEntity()).isFalse()) {
						createCustomerContact(account.getId(), ccTypeId.getEntity());
					}
				}
			}

            return true;
        }

        private void createCustomerContact(Account_Id acctId, CustomerContactType ccType) {

            CustomerContact_DTO ccDTO = new CustomerContact_DTO();
            ccDTO.setPersonId(acctId.getEntity().getMainPerson().getId());
            ccDTO.setCustomerContactTypeId(ccType.getId());
            ccDTO.setContactDateTime(this.getProcessDateTime());
            ccDTO.setCustomerContactStatus(CustomerContactStatusLookup.constants.OPEN);
            ccDTO.setUserId(this.getActiveContextUser().getId());
            ccDTO.setLongDescription("Customer is in escheatment process. Please contact the finance department to determine the status of the refund.");
            ccDTO.newEntity();

        }

        private Bool doesCcExist(Account account, CustomerContactType ccType) {

            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.append("SELECT ");
            stringBuilder.append(  "CC.CC_ID ");
            stringBuilder.append("FROM ");
            stringBuilder.append(  "CI_CC CC ");
            stringBuilder.append("WHERE ");
            stringBuilder.append(  "CC.CC_TYPE_CD = :ccType ");
            stringBuilder.append(  "AND CC.CC_CL_CD = :ccClass ");
            stringBuilder.append(  "AND CC.PER_ID = :person ");
            stringBuilder.append(  "AND CC.CC_STATUS_FLG = :open ");

            PreparedStatement prepStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());

            prepStatement.bindStringProperty("ccType", CustomerContactType.properties.contactType, ccType.fetchIdContactType().trim());
            prepStatement.bindEntity("ccClass", ccType.fetchIdContactClass());
            prepStatement.bindId("person", account.getMainPerson().getId());
            prepStatement.bindLookup("open", CustomerContactStatusLookup.constants.OPEN);

            if (prepStatement.list().size() == 0) {
                return Bool.FALSE;
            }

            return Bool.TRUE;
        }

    }
}
