/*
 ************************************************************************** 
 *
 * PROGRAM DESCRIPTION:
 *
 * This Algorithm will create a Customer Contact for the Vacant Premise 
 * with Consumption Case and will contain the following details as 
 * customer contact characteristics:
 *     1.) Premise
 *     2.) Cutoff Date
 * A characteristic which stores the customer contact id will also be 
 * created for the Vacant Premise with Consumption Case. 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2017-06-22	JHERNA			SysAid#215007. Specific Algorithm for cases
 *                              due to vacant premise with consumption. 
 **************************************************************************/
package com.splwg.cm.domain.admin.caseType;

import java.math.BigInteger;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.workCalendar.WorkCalendar;
import com.splwg.base.domain.security.user.User_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ContactMethodLookup;
import com.splwg.ccb.api.lookup.CustomerContactStatusLookup;
import com.splwg.ccb.domain.admin.caseType.algorithm.enterStatus.EnterStatusAlgorithmSpot;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author 90622
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = customerContactClass, name = customerContactClass, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = contactType, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = customerContactPremiseCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = customerContactCutoffDateCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = caseCustomerContactCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = person, name = occupantPersonId, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = contactMethod, name = contactMethod, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (name = daysToAddForCutoffDate, required = true, type = integer)})
 */
public class CmCreateCustomerContactForVacantPremiseWithConsumptionAlgComp_Impl 
		extends CmCreateCustomerContactForVacantPremiseWithConsumptionAlgComp_Gen 
		implements EnterStatusAlgorithmSpot {

    // Hard Parameter
    private ToDoCase hpCase;
    @SuppressWarnings("unused")
	private CaseStatus hpOriginalCaseStatus;

    // Soft Parameters
    private CustomerContactClass parmCustomerContactClass;
    private String parmContactType;    
    private CharacteristicType parmCharTypePremise;
    private CharacteristicType parmCharTypeCutoffDate;
    private CharacteristicType parmCharTypeCustomerContact;
    private Person parmOccupantPersonId;
    private ContactMethodLookup parmContactMethod;
    private BigInteger parmDaysToAddForCutoffDate;
    // Working Variables
    private CustomerContactType_Id wCustomerContactTypeId;
    private User_Id wUserId;

    public String getNextCaseStatus() {
        return null;
    }

    public String getNextTransCondition() {
        return null;
    }

    public Bool getShouldAutoTransition() {
        return null;
    }

    public void setCase(ToDoCase currentCase) {
        this.hpCase = currentCase;
    }

    public void setCaseOriginalStatus(CaseStatus originalStatus) {
    	hpOriginalCaseStatus = originalStatus;
    }

    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

    	parmCustomerContactClass = this.getCustomerContactClass();
    	parmContactType = this.getContactType();
        // Initialize Customer Contact Type
        wCustomerContactTypeId = new CustomerContactType_Id(parmCustomerContactClass, parmContactType);
        if(isNull(wCustomerContactTypeId.getEntity())){
            addError(CustomMessageRepository.nm0038InvalidCustContactClassAndContactType(
            		parmCustomerContactClass.getId().getTrimmedValue(),parmContactType));
        }
    	
        parmCharTypePremise = this.getCustomerContactPremiseCharType();
    	validateCharTypeEntity(parmCharTypePremise, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);
    	
    	parmCharTypeCutoffDate = this.getCustomerContactCutoffDateCharType();
    	validateCharTypeEntity(parmCharTypeCutoffDate, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);
    	
    	parmCharTypeCustomerContact = this.getCaseCustomerContactCharType();
    	validateCharTypeEntity(parmCharTypeCustomerContact, CharacteristicEntityLookup.constants.CASE);
    	
    	parmOccupantPersonId = this.getOccupantPersonId();
    	parmContactMethod = this.getContactMethod();
    	parmDaysToAddForCutoffDate = this.getDaysToAddForCutoffDate();
    	
    }

    private void validateCharTypeEntity(CharacteristicType parmCharType, CharacteristicEntityLookup parmEntityLookup){

        CharacteristicEntity_Id characteristicEntityId = new CharacteristicEntity_Id(parmCharType, parmEntityLookup);
        if (isNull(characteristicEntityId.getEntity())){
            addError(CustomMessageRepository.nm0038CharTypeInvalidForCharEntity(parmCharType.getId().getIdValue(), parmEntityLookup.getConstantName()));
        } 
    }

    /*==MAIN PROCESSING==*/
    public void invoke() {

    	/*Create Customer Contact*/
        CustomerContact customerContact = createCustomerContact(
        		hpCase, parmOccupantPersonId, wCustomerContactTypeId, this.getProcessDateTime(), parmContactMethod);
        
        /*Store Premise on the Characteristic of the Customer Contact*/
        Premise_Id premiseID = hpCase.getPremiseId();
        createCustomerContactCharacteristic(customerContact, parmCharTypePremise, premiseID.getTrimmedValue());
        
        /*Compute for the Cutoff Date*/
        DateFormat dateFormat = new DateFormat("yyyy-MM-dd");
        WorkCalendar workCalendar = premiseID.getEntity().getDivisionId().getEntity().getWorkCalendar();
        Date cutoffDate = this.getProcessDateTime().getDate().addDays(parmDaysToAddForCutoffDate.intValue());
        Bool isCutDateOnBusinessDay = Bool.FALSE;
        while (isCutDateOnBusinessDay.isFalse()) {
        	if (workCalendar.isBusinessDay(cutoffDate)) {
        		isCutDateOnBusinessDay = Bool.TRUE;
            }
        	else {
        		cutoffDate = cutoffDate.addDays(1);
        	}
        }
        /*Store Cutoff Date on the Characteristic of the Customer Contact*/
        createCustomerContactCharacteristic(customerContact, parmCharTypeCutoffDate, cutoffDate.toString(dateFormat));
        
        /*Store Customer Contact on the Characteristic of the Case*/
        createCaseCharacteristic(hpCase, parmCharTypeCustomerContact, customerContact.getId().getTrimmedValue());
    }

    private CustomerContact createCustomerContact(ToDoCase tdCase, Person person, CustomerContactType_Id custContactTypeID, 
    		DateTime contactDttm, ContactMethodLookup preferredContactMethod) {

        wUserId = tdCase.getUserId();
        
        if(isNull(wUserId)){
            addError(CustomMessageRepository.nm0038UserIdCannotBeBlank());
        }else if(isNull(wUserId.getEntity())){
            addError(CustomMessageRepository.nm0038InvalidUserValue(wUserId.getTrimmedValue()));
        }

        CustomerContact_DTO ccDTO = new CustomerContact_DTO();

        ccDTO.setPersonId(person.getId());
        ccDTO.setCustomerContactTypeId(custContactTypeID);
        ccDTO.setContactDateTime(contactDttm);
        ccDTO.setPreferredContactMethod(preferredContactMethod);
        ccDTO.setCustomerContactStatus(CustomerContactStatusLookup.constants.OPEN);
        ccDTO.setUserId(wUserId);

        /*Create customer contact record*/
        CustomerContact custContact = ccDTO.newEntity();
        return custContact;
    }

    private void createCustomerContactCharacteristic(CustomerContact customerContact, CharacteristicType charType, String charValue) {
    	
    	if (notBlank(charValue)) {
        	CustomerContactCharacteristic_Id ccCharID = new CustomerContactCharacteristic_Id(charType, customerContact);
        	CustomerContactCharacteristic_DTO ccCharDTO = new CustomerContactCharacteristic_DTO();
        	CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
        	if (charTypeLookup.isAdhocValue() 
        			|| charTypeLookup.isFileLocationValue()) {
        		ccCharDTO.setAdhocCharacteristicValue(charValue);
        	}
        	else if (charTypeLookup.isForeignKeyValue()) {
        		ccCharDTO.setCharacteristicValueForeignKey1(charValue);
        	}
        	else {
        		ccCharDTO.setCharacteristicValue(charValue);
        	}
        	ccCharDTO.setId(ccCharID);
        	ccCharDTO.newEntity();
    	}
    }
    
    private void createCaseCharacteristic(ToDoCase tdCase, CharacteristicType charType, String charValue) {
    	
    	if (notBlank(charValue)) {
    		
    		BigInteger seq = retrieveMaxSeq(tdCase, charType);
            
            CaseCharacteristic_DTO caseCharDTO = new CaseCharacteristic_DTO();
            CaseCharacteristic_Id caseCharID = new CaseCharacteristic_Id(charType, tdCase, seq);
            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
            
            if (charTypeLookup.isAdhocValue()
            		|| charTypeLookup.isFileLocationValue()) {
            	caseCharDTO.setAdhocCharacteristicValue(charValue);
            }
            else if (charTypeLookup.isPredefinedValue()) {
            	caseCharDTO.setCharacteristicValue(charValue);
            }
            else {
            	caseCharDTO.setCharacteristicValueForeignKey1(charValue);
            }
            caseCharDTO.setId(caseCharID);
            caseCharDTO.newEntity();
    	}
    	   
    }
    
    
    private BigInteger retrieveMaxSeq(ToDoCase tdCase, CharacteristicType ccCaseCharType){

        BigInteger caseSeq = BigInteger.TEN;
        
    	StringBuilder maxSeqQueryStr = new StringBuilder();
        maxSeqQueryStr.append(" SELECT MAX(SEQ_NUM) AS SEQ");
        maxSeqQueryStr.append(" FROM CI_CASE_CHAR ");
        maxSeqQueryStr.append(" WHERE CASE_ID = :caseId ");
        maxSeqQueryStr.append(" AND CHAR_TYPE_CD = :charTypeCd ");

        PreparedStatement maxSeqStmt = createPreparedStatement(maxSeqQueryStr.toString(), getClass().getName());
        maxSeqStmt.bindId("caseId", tdCase.getId());
        maxSeqStmt.bindId("charTypeCd", ccCaseCharType.getId());
        SQLResultRow maxSeqrow = maxSeqStmt.firstRow();
        
        if(notNull(maxSeqrow) && notNull(maxSeqrow.getInteger("SEQ"))){
            caseSeq = maxSeqrow.getInteger("SEQ").add(BigInteger.TEN);
        }
        maxSeqStmt.close();
        return caseSeq;
    }
}
