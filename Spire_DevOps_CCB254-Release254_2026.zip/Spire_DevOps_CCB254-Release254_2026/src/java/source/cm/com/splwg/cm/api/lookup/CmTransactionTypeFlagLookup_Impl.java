/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * New, Rescheduled and Canceled Transaction Type Flag Lookup 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2018-08-22   MPang    	SA-251520C. Initial Version. 
 **************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author mpang
 *
 @LookupFieldname (value = CM_TRX_TYPE_FLG)
 */
public class CmTransactionTypeFlagLookup_Impl 
extends CmTransactionTypeFlagLookup_Gen {

}
