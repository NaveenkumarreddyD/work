package com.splwg.cm.domain.batch;

import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.GenericBusinessComponent;
import com.splwg.base.api.datatypes.Money;
//Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;*/

import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffProcess_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
//End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
/**
 * @author sdesabhatl002
 *
@BusinessComponent (customizationCallable = true)
 */
public class CmCACIOutboundData_Impl 
		extends GenericBusinessComponent 
		implements CmCACIOutboundData {
	
	private Premise_Id premiseId;
	private Money currBalance = Money.ZERO;
	private String refferalType;
	private String premAddress;
	private String acctMailAddr;
	private Account_Id acctId;
	private String turnOnDate;
	private String turnOffDate;
	private List<ServiceAgreement_Id> saList = new ArrayList<ServiceAgreement_Id>();
	
	
	public Account_Id getAcctId() {
		return acctId;
	}
	public List<ServiceAgreement_Id> getSaList() {
		return saList;
	}
	public void setSaList(List<ServiceAgreement_Id> saList) {
		this.saList = saList;
	}
	public void setAcctId(Account_Id acctId) {
		this.acctId = acctId;
	}
	public String getTurnOnDate() {
		return turnOnDate;
	}
	public void setTurnOnDate(String turnOnDate) {
		this.turnOnDate = turnOnDate;
	}
	public String getTurnOffDate() {
		return turnOffDate;
	}
	public void setTurnOffDate(String turnOffDate) {
		this.turnOffDate = turnOffDate;
	}
	public Premise_Id getPremiseId() {
		return premiseId;
	}
	public void setPremiseId(Premise_Id premiseId) {
		this.premiseId = premiseId;
	}
	public Money getCurrBalance() {
		return currBalance;
	}
	public void setCurrBalance(Money currBalance) {
		this.currBalance = currBalance;
	}
	public String getRefferalType() {
		return refferalType;
	}
	public void setRefferalType(String refferalType) {
		this.refferalType = refferalType;
	}
	public String getPremAddress() {
		return premAddress;
	}
	public void setPremAddress(String premAddress) {
		this.premAddress = premAddress;
	}
	public String getAcctMailAddr() {
		return acctMailAddr;
	}
	public void setAcctMailAddr(String acctMailAddr) {
		this.acctMailAddr = acctMailAddr;
	}

	/* START ADD - JHERNA - 2021-11-03 - SysAid#383853 */
	// Variable
	private WriteOffProcess_Id woProcessID;
	// Setter
	public void setWriteOffProcessID(WriteOffProcess_Id woProcID) {
		this.woProcessID = woProcID;
	}
	//Getter
	public WriteOffProcess_Id getWriteOffProcessID() {
		return woProcessID;
	}
	/* END ADD - JHERNA - 2021-11-03 - SysAid#383853 */
}
