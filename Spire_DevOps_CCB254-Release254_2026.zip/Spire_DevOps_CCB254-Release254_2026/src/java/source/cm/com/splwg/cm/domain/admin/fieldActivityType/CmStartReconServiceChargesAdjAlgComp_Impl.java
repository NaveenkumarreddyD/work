/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NA0073 - Field Activity Completion - Start Service Algorithm
 * 
 * Field Activity Completion Algorithm which creates Start Service Adjustments
 * and Payment Arrangement Service Agreements to handle Start Service charges.
 * This is the first algorithm of NA0073.
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-02-04   Neha    NA0073. Initial Version.
 * 2013-04-18   Neha    Functional TIR 5: Instead of defining the FT ID on 
 *                      completed field activity for the start service 
 *                      adjustment created, define Adjustment ID on completed 
 *                      field 
 * 2013-04-18   Neha    Defect 477. Service initiation fee is being billed 
 *                      at 4 installments of $7 and should be 4 installments 
 *                      of $6.25. Changed scale value to 2.
 * 2013-04-19   Neha    Defect 490. Only current SA should be updated with 
 *                      adjustment. In case of new connection Adj Type1 
 *                      else Adj Type2.
 * 2013-05-03	Karthik	KL20130503 - Code change for Defects 491, 691 and   
 * 						482(CR72 - LandlordID Check.) 
 * 2013-06-07	Karthik	KL20130607 - Fix for defects 1781, 691 & 491.
 * 						Per Pam, modified logic to differentiate if adjustment
 * 						type 1 or adjustment type 2 should be applied. 
 * 2013-06-17	Karthik	KL20130617 - Fix for defect 691 - included severance 
 * 						activity check for SA_SP_FA_TYPE_FLG.
 * 2013-09-20	Karthik	KL20130920 - Fix for IM-035783
 * 2013-10-24	Karthik	KL20131024 - Fix for IM-035783 - Included the disconnect
 * 						date time while checking if there was any move-in 
 * 						activity that caused the voluntary disconnect.
 * 2013-10-31	Karthik	KL20131031 - CR (IM-040260) to include 3 new parameters;
 * 						Added logic to apply Flat SIC without PA creation and 
 * 						apply reconnect fee based on these new parameters. 
 * 2013-11-05	Karthik	KL20131105 - IM040260 - Rewriting logic to exclude 
 * 						Start Activity Check if  FA is manually created FA
 * 2015-04-22	JHERNA	Defect#3122894. Moved package location to the correct
 *                      directory. 
 * 						Updated code to cater for MGE requirement(s)
 *                      New parameters added:
 *                          1.) Apply charge to landlord indicator
 *                          2.) Adjustment Type to use for Landlord Reversion
 *                              connection charges
 *                          3.) Apply reconnect charges indicator for customer  
 *                              starting service at the same premise they were 
 *                              previously disconnected. (Check Service History
 *                              at same premise only)
 *                      Make existing parameters optional:
 *                          1.) Apply Flat SIC Fee Characteristic Type
 *                          2.) Apply Flat SIC Fee Characteristic Value
 * 2015-06-12	JHERNA	Defect#3224532. Ensure that once an adjustment is created
 * 						(for the landlord using landlord adjustment)the program
 * 						should terminate.   
 * 2015-06-29	JHERNA  Defect#3241226. Remove the error message being raised
 * 						when an online transaction did not have any eligible SAs
 * 						for START ACTIVITY EVENT.    
 * 2015-07-08	JHERNA	Defect#3242469. 
 * 						Updated to cater to the scenarios Ed Chipeta raised.                  
 * 2016-01-26   MPang	Updated for CCB v2.4 compilation.
 * 2016-09-20   Dhuynh  Defect# 126923:Multiple SA's/Accounts tied to a M-DISNP Field Activity.
 * 						Update query to select the right account for reconnection fee
 * 2018-07-25   SFelip  CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                      longer needed.     
 * 2019-05-22   EQuint  Defect 4253862 - ID56 (Reopen) - set prepared statement auto close     
 * 2021-05-20   Kiran   Make adjustment parameter Optional   
 * 2022-04-06   JVitug  D - 398163. Updated to always charge a reconnection fee
 * 						if the same customer is starting a new SA in its 
 * 						previous premise and whose previous SA is linked to
 * 						a M-DISNP FA   
 * 2022-05-10   JVitug  D - 03200. Updated to now always charge a 
 * 						reconnection fee if the same customer is starting a 
 * 						new SA as long as the last FA activity linked to the
 * 						account is a M-DISNP FA , regardless of premise.  
 * 2024-11-16   Kiran   INC0031998 Include Reconnect Activity for the most recent FA
 **************************************************************************/
// START CHANGE - JHERNA - 2015-04-22 - DEFECT#3122894
//package com.splwg.cm.domain.admin.faType;
package com.splwg.cm.domain.admin.fieldActivityType;
// END CHANGE - JHERNA - 2015-04-22 - DEFECT#3122894

import java.math.BigInteger;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.ibm.icu.math.MathContext;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateInterval;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.datatypes.TimeInterval;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.algorithm.Algorithm;
import com.splwg.base.domain.common.algorithmType.AlgorithmTypeParameter_Id;
import com.splwg.base.domain.common.algorithmType.AlgorithmTypeParameter_LanguageId;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.ccb.api.lookup.AdjustmentStatusLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.CopyOptionForProposalSALookup;
import com.splwg.ccb.api.lookup.CustomerReadLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementSpFaTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.SpecialRoleLookup;
import com.splwg.ccb.api.lookup.StartReasonLookup;
//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.adjustment.adjustment.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.AdjustmentCharacteristic;
import com.splwg.ccb.domain.adjustment.adjustment.AdjustmentCharacteristic_DTO;
import com.splwg.ccb.domain.adjustment.adjustment.AdjustmentCharacteristic_Id;
import com.splwg.ccb.domain.adjustment.adjustment.AdjustmentCharacteristics;
import com.splwg.ccb.domain.adjustment.adjustment.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.adjustment.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.AdjustmentType;
import com.splwg.ccb.domain.admin.adjustmentType.AdjustmentType_Id;
import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.customerClass.CustomerClass;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityTypeFaCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.serviceType.ServiceType;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.AccountPerson;
import com.splwg.ccb.domain.customerinfo.landlord.Landlord_Id;
import com.splwg.ccb.domain.customerinfo.person.Person;
import com.splwg.ccb.domain.customerinfo.premise.Premise;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCreator;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCreatorData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementRecurringCharge;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementRecurringCharge_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristics;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_Id;*/
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic_DTO;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic_Id;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristics;
import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass;
import com.splwg.ccb.domain.admin.fieldActivityType.algorithm.faCompletion.FieldActivityTypeFaCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.common.ServiceAgreementCreator;
import com.splwg.ccb.domain.customerinfo.data.ServiceAgreementCreatorData;
import com.splwg.ccb.domain.customerinfo.landlord.entity.Landlord_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementRecurringCharge;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementRecurringCharge_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristics;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.api.lookup.CmServiceHistoryAdjustmentLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

//Start Change JVitug - D - 398163 - 2022-04-06
///**
// * @author nsinha006
// *
//@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = createInstallmentsFlg, required = true, type = boolean)
// *            , @AlgorithmSoftParameter (lookupName = cmServiceHistoryAdjustment, name = serviceHistoryAdjFlg, required = true, type = lookup)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = eligibleSATypeCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = eligibleSATypeCharValue, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = startServiceAdjType1, type = entity)
// *            , @AlgorithmSoftParameter (entityName = serviceType, name = utilityServiceType1, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = serviceType, name = utilityServiceType2, type = entity)
// *            , @AlgorithmSoftParameter (entityName = cisDivision, name = installmentPaCISDivision, type = entity)
// *            , @AlgorithmSoftParameter (name = installmentPaSaType, type = string)
// *            , @AlgorithmSoftParameter (name = numInstallments, type = integer)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = serviceHistoryFACharType, type = entity)
// *            , @AlgorithmSoftParameter (name = voluntaryDisconnectCharValue, type = string)
// *            , @AlgorithmSoftParameter (name = voluntaryDisconnectNumDays, type = integer)
// *            , @AlgorithmSoftParameter (name = disconnectNonPaymentCharValue, type = string)
// *            , @AlgorithmSoftParameter (name = disconnectNonPaymentNumDays, type = integer)
// *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = startServiceAdjType2, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = premiseCharType, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = adjIdCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = customerClass, name = custClass, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = bypassStrtSrvcAdjCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = applyFlatSICFeeCharType, type = entity)
// *            , @AlgorithmSoftParameter (name = applyFlatSICFeeCharValue, type = string)
// *            , @AlgorithmSoftParameter (name = shouldApplyReconFeeFlg, required = true, type = boolean)
// *            , @AlgorithmSoftParameter (name = applyConnectionChargeToLandlord, required = true, type = boolean)
// *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = startServiceAdjustmentTypeMGE, type = entity)
// *            , @AlgorithmSoftParameter (name = checkServiceHistoryAtSamePremiseOnly, required = true, type = boolean)
// *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = alwaysReconFeeStopFAType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = stopFAType, required = true, type = entity)})
// */
//Start Change Jvitug - D - 03200 - 2022-05-13
///**
// * @author nsinha006
// *
//@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = createInstallmentsFlg, required = true, type = boolean)
// *            , @AlgorithmSoftParameter (lookupName = cmServiceHistoryAdjustment, name = serviceHistoryAdjFlg, required = true, type = lookup)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = eligibleSATypeCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = eligibleSATypeCharValue, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = startServiceAdjType1, type = entity)
// *            , @AlgorithmSoftParameter (entityName = serviceType, name = utilityServiceType1, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = serviceType, name = utilityServiceType2, type = entity)
// *            , @AlgorithmSoftParameter (entityName = cisDivision, name = installmentPaCISDivision, type = entity)
// *            , @AlgorithmSoftParameter (name = installmentPaSaType, type = string)
// *            , @AlgorithmSoftParameter (name = numInstallments, type = integer)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = serviceHistoryFACharType, type = entity)
// *            , @AlgorithmSoftParameter (name = voluntaryDisconnectCharValue, type = string)
// *            , @AlgorithmSoftParameter (name = voluntaryDisconnectNumDays, type = integer)
// *            , @AlgorithmSoftParameter (name = disconnectNonPaymentCharValue, type = string)
// *            , @AlgorithmSoftParameter (name = disconnectNonPaymentNumDays, type = integer)
// *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = startServiceAdjType2, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = premiseCharType, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = adjIdCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = customerClass, name = custClass, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = bypassStrtSrvcAdjCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = applyFlatSICFeeCharType, type = entity)
// *            , @AlgorithmSoftParameter (name = applyFlatSICFeeCharValue, type = string)
// *            , @AlgorithmSoftParameter (name = shouldApplyReconFeeFlg, required = true, type = boolean)
// *            , @AlgorithmSoftParameter (name = applyConnectionChargeToLandlord, required = true, type = boolean)
// *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = startServiceAdjustmentTypeMGE, type = entity)
// *            , @AlgorithmSoftParameter (name = checkServiceHistoryAtSamePremiseOnly, required = true, type = boolean)
// *            , @AlgorithmSoftParameter (entityName = fieldActivityType , name = alwaysReconFeeStopFAType, required = true, type = entity)})
// */
/**
 * @author nsinha006
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = createInstallmentsFlg, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (lookupName = cmServiceHistoryAdjustment, name = serviceHistoryAdjFlg, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = eligibleSATypeCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = eligibleSATypeCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = startServiceAdjType1, type = entity)
 *            , @AlgorithmSoftParameter (entityName = serviceType, name = utilityServiceType1, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = serviceType, name = utilityServiceType2, type = entity)
 *            , @AlgorithmSoftParameter (entityName = cisDivision, name = installmentPaCISDivision, type = entity)
 *            , @AlgorithmSoftParameter (name = installmentPaSaType, type = string)
 *            , @AlgorithmSoftParameter (name = numInstallments, type = integer)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = serviceHistoryFACharType, type = entity)
 *            , @AlgorithmSoftParameter (name = voluntaryDisconnectCharValue, type = string)
 *            , @AlgorithmSoftParameter (name = voluntaryDisconnectNumDays, type = integer)
 *            , @AlgorithmSoftParameter (name = disconnectNonPaymentCharValue, type = string)
 *            , @AlgorithmSoftParameter (name = disconnectNonPaymentNumDays, type = integer)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = startServiceAdjType2, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = premiseCharType, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = adjIdCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = customerClass, name = custClass, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = bypassStrtSrvcAdjCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = applyFlatSICFeeCharType, type = entity)
 *            , @AlgorithmSoftParameter (name = applyFlatSICFeeCharValue, type = string)
 *            , @AlgorithmSoftParameter (name = shouldApplyReconFeeFlg, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (name = applyConnectionChargeToLandlord, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = startServiceAdjustmentTypeMGE, type = entity)
 *            , @AlgorithmSoftParameter (name = checkServiceHistoryAtSamePremiseOnly, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityType , name = alwaysReconFeeStopFAType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityType , name = stopFAType, required = true, type = entity)})
 */
//End Change JVitug - D - 03200 - 2022-05-13
//End Change JVitug - D - 398163 - 2022-04-06
public class CmStartReconServiceChargesAdjAlgComp_Impl 
		extends CmStartReconServiceChargesAdjAlgComp_Gen 
		implements FieldActivityTypeFaCompletionAlgorithmSpot {
	// Soft parameters
	@SuppressWarnings("unused")
	private ToDoType parmToDoType;
	private Bool parmCreateInstallmentsFlg;
	private CmServiceHistoryAdjustmentLookup parmSvcHistAdjFlg;
	private CharacteristicType parmEligibleSATypeCharType;
	private String parmEligibleSATypeCharValue;
	private AdjustmentType parmStartServiceAdjType1;
	private ServiceType parmUtilityServiceType1;
	private ServiceType parmUtilityServiceType2;
	private CisDivision parmInstallmentPaCISDivision;
	private String parmInstallmentPaSaType;
	private BigInteger parmNumInstallments;
	private CharacteristicType parmServiceHistoryFACharType;
	private String parmVoluntaryDisconnectCharValue;
	private BigInteger parmVoluntaryDisconnectNumDays;
	private String parmDisconnectNonPaymentCharValue;
	private BigInteger parmDisconnectNonPaymentNumDays;    
	private AdjustmentType parmStartServiceAdjType2;
	private CharacteristicType parmPremiseCharType;
	private CharacteristicType parmAdjIdCharType;
	private CustomerClass parmLandlordCustClass;
	private CharacteristicType parmBypassStrtSrvcAdjCharType;
	//KL20131031 - Start of changes for CR - IM-040260
	private CharacteristicType parmApplyFlatSICFeeCharType;
	private String parmApplyFlatSICFeeCharVal;
	private Bool parmShouldApplyReconFeeFlg;
	//KL20131031 - End of changes for CR - IM-040260
	// START ADD - JHERNA - 2015-04-22 - DEFECT#3122894
	private Bool parmShouldApplyConnChargeToLL;
	private Bool parmShouldCheckSvcHistoryAtSamePremiseOnly;
	private AdjustmentType parmAdjTypeStartServiceMGE;
	//Start Add JVitug -  D - 398163 - 2022-04-06
	private FieldActivityType alwaysChargeReconFeeStopFAType;
	//End Add JVitug -  D - 398163 - 2022-04-06
	//Start Add JVitug - D - 03200 - 2022-05-13
	private FieldActivityType stopFAType;
	//End Add JVitug - D - 03200 - 2022-05-13
	
	// Constants
	private static final String PARMDESC250 = "Apply Connection Charge To Landlord";
	private static final String PARMDESC260 = "Start Service Adjustment Type (Landlord Reversion)";
	private Bool adjCreatedLL = Bool.FALSE;
	// END ADD - JHERNA - 2015-04-22 - DEFECT#3122894

	// Hard parameters
	private FieldActivity parmFieldActivity;
	// Working variables
	private ServiceAgreementType_Id payArrangeSATypeId;
	private ServiceAgreement currentSA;
	private Account currentAccount;
	private Premise currentPremise;
	// KL20130607 - Start - Defect Fix - 1781
	private Person currentMainPerson;
	private TimeInterval disconnectForNonPayNumDays = new TimeInterval(0);
	// KL20130607 - End - Defect Fix - 1781
	private AdjustmentType_Id transferAdjustmentTypeId;
	private boolean isCurrentAccountLandlord = false; 
	private boolean hadAppliedAdj = false;
	// KL20130920 - Start of fix for IM-035783
	private BigInteger noOfDisconnectFAs = BigInteger.ZERO;
	private Date earliestDisconnectDate = getSystemDateTime().getDate();
	// KL20130920 - End of fix for IM-035783

	public void setFieldActivity(FieldActivity fieldActivity) {

		parmFieldActivity = fieldActivity;
	}

	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

		parmToDoType = getToDoType();
		parmCreateInstallmentsFlg = getCreateInstallmentsFlg();
		parmSvcHistAdjFlg  = getServiceHistoryAdjFlg();

		parmEligibleSATypeCharType = getEligibleSATypeCharType();
		validateCharType(parmEligibleSATypeCharType, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT_TYPE, BigInteger.valueOf(40));
		parmEligibleSATypeCharValue = getEligibleSATypeCharValue();
		validateCharValue(parmEligibleSATypeCharType, parmEligibleSATypeCharValue, BigInteger.valueOf(50));

		parmStartServiceAdjType1 = getStartServiceAdjType1();
		parmUtilityServiceType1 = getUtilityServiceType1();
		parmUtilityServiceType2 = getUtilityServiceType2();

		parmInstallmentPaCISDivision = getInstallmentPaCISDivision();
		parmInstallmentPaSaType = getInstallmentPaSaType(); 
		parmNumInstallments = getNumInstallments();
		if(parmCreateInstallmentsFlg.isTrue() && (isNull(parmInstallmentPaCISDivision) || isEmptyOrNull(parmInstallmentPaSaType) ||isNull(parmNumInstallments))){
			// Installment Payment Arrangement parameters are required if create installment flag is Y 
			addError(CustomMessageRepository.na0073InstallmentParamsReqdWhnInstlmntFlgY());  
		}
		if(parmCreateInstallmentsFlg.isTrue()){
			validateSAType(parmInstallmentPaCISDivision, parmInstallmentPaSaType.trim(), BigInteger.valueOf(100));
			validateNumDaysParam(parmNumInstallments, BigInteger.valueOf(110));
		}
		parmServiceHistoryFACharType = getServiceHistoryFACharType();
		parmVoluntaryDisconnectCharValue = getVoluntaryDisconnectCharValue();
		parmVoluntaryDisconnectNumDays = getVoluntaryDisconnectNumDays();  

		parmDisconnectNonPaymentCharValue = getDisconnectNonPaymentCharValue();
		parmDisconnectNonPaymentNumDays = getDisconnectNonPaymentNumDays();  
		disconnectForNonPayNumDays = new TimeInterval(0, parmDisconnectNonPaymentNumDays.longValue(), 0, 0, 0);

		parmStartServiceAdjType2 = getStartServiceAdjType2();
		parmPremiseCharType = getPremiseCharType();

		parmAdjIdCharType = getAdjIdCharType();
		parmLandlordCustClass = getCustClass();
		parmBypassStrtSrvcAdjCharType = getBypassStrtSrvcAdjCharType();

		//KL20131031 - Start of changes for CR - IM-040260
		parmApplyFlatSICFeeCharType = getApplyFlatSICFeeCharType();
		validateCharType(parmApplyFlatSICFeeCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY, BigInteger.valueOf(220));
		parmApplyFlatSICFeeCharVal = getApplyFlatSICFeeCharValue();
		validateCharValue(parmApplyFlatSICFeeCharType, parmApplyFlatSICFeeCharVal, BigInteger.valueOf(230));
		parmShouldApplyReconFeeFlg = getShouldApplyReconFeeFlg();
		//KL20131031 - End of changes for CR - IM-040260

		if(parmSvcHistAdjFlg.isVoluntaryDisconnectAndDisconnectForNonPayment() && (isNull(parmServiceHistoryFACharType) || isEmptyOrNull(parmVoluntaryDisconnectCharValue)
				|| isNull(parmVoluntaryDisconnectNumDays) || isEmptyOrNull(parmDisconnectNonPaymentCharValue) || isNull(parmDisconnectNonPaymentNumDays) 
				|| isNull(parmStartServiceAdjType2) || isNull(parmPremiseCharType))){
			// Corresponding Service history parameters are required if the service history adjustment flag is B
			addError(CustomMessageRepository.na0073SvcHistParamsReqdWhnSvcHistFlgBOrVOrP(CmServiceHistoryAdjustmentLookup.constants.VOLUNTARY_DISCONNECT_AND_DISCONNECT_FOR_NON_PAYMENT.getLookupValue().fetchLanguageDescription())); 
		}
		if(parmSvcHistAdjFlg.isVoluntaryDisconnect() && (isNull(parmServiceHistoryFACharType) || isEmptyOrNull(parmVoluntaryDisconnectCharValue)
				|| isNull(parmVoluntaryDisconnectNumDays) || isNull(parmStartServiceAdjType2) || isNull(parmPremiseCharType))){
			// Corresponding Service history parameters are required if the service history adjustment flag is V
			addError(CustomMessageRepository.na0073SvcHistParamsReqdWhnSvcHistFlgBOrVOrP(CmServiceHistoryAdjustmentLookup.constants.VOLUNTARY_DISCONNECT.getLookupValue().fetchLanguageDescription())); 
		}
		if(parmSvcHistAdjFlg.isDisconnectForNonPayment() && (isNull(parmServiceHistoryFACharType) || isEmptyOrNull(parmDisconnectNonPaymentCharValue) 
				|| isNull(parmDisconnectNonPaymentNumDays) || isNull(parmStartServiceAdjType2) || isNull(parmPremiseCharType))){
			// Corresponding Service history parameters are required if the service history adjustment flag is P
			addError(CustomMessageRepository.na0073SvcHistParamsReqdWhnSvcHistFlgBOrVOrP(CmServiceHistoryAdjustmentLookup.constants.DISCONNECT_FOR_NON_PAYMENT.getLookupValue().fetchLanguageDescription())); 
		}
		if(notNull(parmServiceHistoryFACharType) && !isEmptyOrNull(parmVoluntaryDisconnectCharValue)){
			validateCharType(parmServiceHistoryFACharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY_TYPE, BigInteger.valueOf(120));
			validateCharValue(parmServiceHistoryFACharType, parmVoluntaryDisconnectCharValue, BigInteger.valueOf(130));
			validateNumDaysParam(parmVoluntaryDisconnectNumDays, BigInteger.valueOf(140));
		}
		if(notNull(parmServiceHistoryFACharType) && !isEmptyOrNull(parmDisconnectNonPaymentCharValue)){
			validateCharType(parmServiceHistoryFACharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY_TYPE, BigInteger.valueOf(120));
			validateCharValue(parmServiceHistoryFACharType, parmDisconnectNonPaymentCharValue, BigInteger.valueOf(150));
			validateNumDaysParam(parmDisconnectNonPaymentNumDays, BigInteger.valueOf(160));
		}
		if(notNull(parmPremiseCharType) ){
			validateCharType(parmPremiseCharType, CharacteristicEntityLookup.constants.ADJUSTMENT, BigInteger.valueOf(180));
		}
		if(notNull(parmAdjIdCharType) ){
			validateCharType(parmAdjIdCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY, BigInteger.valueOf(190));
		}
		if(notNull(parmBypassStrtSrvcAdjCharType) ){
			validateCharType(parmBypassStrtSrvcAdjCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY, BigInteger.valueOf(210));
		}
		
		// START ADD - JHERNA - 2015-04-22 - DEFECT#3122894
		parmShouldApplyConnChargeToLL = this.getApplyConnectionChargeToLandlord();
		parmAdjTypeStartServiceMGE = this.getStartServiceAdjustmentTypeMGE();
		if (notNull(parmShouldApplyConnChargeToLL)
				&& parmShouldApplyConnChargeToLL.isTrue()
				&& isNull(parmAdjTypeStartServiceMGE)) {
			
			String algorithmCode = " ";
			Algorithm algo = this.getAlgorithm();
			if (notNull(algo)) {
				algorithmCode = algo.getId().getTrimmedValue();
			}
			// Algorithm %1's parameter '%2%3' is required when parameter '%3%4' is supplied.
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterRequiredWhenSpecifiedParmIsSupplied(
					algorithmCode, PARMDESC260, PARMDESC250));
			
		}
		parmShouldCheckSvcHistoryAtSamePremiseOnly = this.getCheckServiceHistoryAtSamePremiseOnly();
		// END ADD - JHERNA - 2015-04-22 - DEFECT#3122894
		
		//Start Add JVitug -  D - 398163- 2022-04-06
		alwaysChargeReconFeeStopFAType = getAlwaysReconFeeStopFAType();
		//End Add Jvitug -  D - 398163 - 2022-04-06
		
		//Start Add Jvitug - D - 03200 - 2022-05-13
		stopFAType = getStopFAType();
		//End Add JVitug - D - 03200 - 2022-05-13
	}

	public void validateSAType(CisDivision cisdivision, String strSAType, BigInteger paramSeq){

		payArrangeSATypeId = new ServiceAgreementType_Id(cisdivision,strSAType);
		if(isNull(payArrangeSATypeId.getEntity())){
			addError(CustomMessageRepository.na0073InvalidServiceAgreementType(getAlgorithmParameterName(paramSeq), strSAType, cisdivision.getId().getTrimmedValue()));
		}
		if(!payArrangeSATypeId.getEntity().getSpecialRole().equals(SpecialRoleLookup.constants.PAYMENT_ARRANGEMENT)){
			addError(CustomMessageRepository.na0073InvalidSATypeForSpecialRole(strSAType)); 
		}
	}

	private void validateCharType(CharacteristicType charType,CharacteristicEntityLookup lookup, BigInteger seq){

		// START ADD - JHERNA - 2015-04-22 - DEFECT#3122894
		/*
		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, lookup);
		if (isNull(charEntityId.getEntity())){
			addError(CustomMessageRepository.na0073InvalidInputCharTypeForEntity(getAlgorithmParameterName(seq), charType.getId().getTrimmedValue(),lookup.getLookupValue().fetchIdFieldValue()));
		}
		*/
		if (notNull(charType)) {
			CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, lookup);
			if (isNull(charEntityId.getEntity())){
				addError(CustomMessageRepository.na0073InvalidInputCharTypeForEntity(getAlgorithmParameterName(seq), charType.getId().getTrimmedValue(),lookup.getLookupValue().fetchIdFieldValue()));
			}
		}
		// END ADD - JHERNA - 2015-04-22 - DEFECT#3122894
	}
	private void validateCharValue(CharacteristicType charType, String charVal, BigInteger seq){

		// START CHANGES - JHERNA - 2015-04-22 - DEFECT#3122894
		/*
		CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
		if(charTypeLookup.isPredefinedValue()){
			CharacteristicValue_Id charValId = new CharacteristicValue_Id(charType.getId(), charVal);
			if(isNull(charValId.getEntity())){
				addError(CustomMessageRepository.na0073InvalidInputCharVal(getAlgorithmParameterName(seq), charVal, charType.getId().getTrimmedValue()));
			}
		}
		*/
		if (notBlank(charVal)) {
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			if(charTypeLookup.isPredefinedValue()){
				CharacteristicValue_Id charValId = new CharacteristicValue_Id(charType.getId(), charVal);
				if(isNull(charValId.getEntity())){
					addError(CustomMessageRepository.na0073InvalidInputCharVal(getAlgorithmParameterName(seq), charVal, charType.getId().getTrimmedValue()));
				}
			}
		}
		// END CHANGES - JHERNA - 2015-04-22 - DEFECT#3122894
	}

	private void validateNumDaysParam(BigInteger numDays, BigInteger seq){
		if(numDays.compareTo(BigInteger.ZERO) <= 0){
			addError(CustomMessageRepository.na0073NumberShouldBGreaterThanZero(getAlgorithmParameterName(seq)));
		}
	}

	/**
	 * This method will retrieve the Parameter name for the input sequence.
	 * @param paramSeq a Big Integer 
	 * @return paramName a String value
	 */
	private String getAlgorithmParameterName(BigInteger paramSeq){

		String paramName = "";      
		AlgorithmTypeParameter_Id algorithmTypeParameterId = new AlgorithmTypeParameter_Id(getAlgorithm().getAlgorithmType(), paramSeq);        
		AlgorithmTypeParameter_LanguageId algorithmTypeParameterLanguageId = new AlgorithmTypeParameter_LanguageId(algorithmTypeParameterId, getActiveContextLanguage().getId());       
		paramName = algorithmTypeParameterLanguageId.getParent().fetchLanguageParameterLabel();
		return paramName;
	}

	public void invoke() {     

		// START ADD - JHERNA - 2015-06-12 - DEFECT#3224532
		//ServiceAgreement landlordSA = null;
		// END ADD - JHERNA - 2015-06-12 - DEFECT#3224532
		
		if(notNull(parmInstallmentPaCISDivision)){
			payArrangeSATypeId = new ServiceAgreementType_Id(parmInstallmentPaCISDivision, parmInstallmentPaSaType);
			transferAdjustmentTypeId = payArrangeSATypeId.getEntity().getAdjustmentTypeXferId();
		}

		//KL20131031 - Start changes for IM-040260
		/*
		 *** Commented this code to introduce logic to apply reconnection fees for Manually initiated reconnection FA completion
		if(!parmFieldActivity.getCreatedBy().isStartStopServiceRequest()){
			return;
		} else if(isBypassStartSrvcAdjustment()){
			return;
		}
		 */
		// Check if Bypass Start Service Adjustment Characteristics is available on FA
		if(isDesiredCharValOnFaChar(parmBypassStrtSrvcAdjCharType, null)){
			return;
		}
		if(parmShouldApplyReconFeeFlg.isFalse()){
			if(!parmFieldActivity.getCreatedBy().isStartStopServiceRequest()){
				return;
			} 
		}
		//KL20131031 - End changes for IM-040260

		if(!getEligibleSAForSP()){
			return;
		}
		// Account associated to the completed Field Activity
		currentAccount = currentSA.getAccount();
		// KL20130607 - Start of Defect Fix #1781
		for(AccountPerson acctPer: currentAccount.getPersons()){
			if(acctPer.getIsMainCustomer().isTrue()){
				// Main Person associated with the current Account
				currentMainPerson = acctPer.getId().getPerson();
			}
		}
		// KL20130607 - End of Defect Fix #1781
		currentPremise = parmFieldActivity.getServicePoint().getPremise();
		
		// START ADD - JHERNA - 2015-04-22 - DEFECT#3122894
		/*
		 * If the Apply Connection Charge to Landlord parameter is Y, check if this is a back-to-back reversion scenario, 
		 * i.e. premise has a landlord agreement (LLA) and either start or stop SA is linked to the account referenced on the LLA.
		 *      If so, create an adjustment on the start SA using the adjustment type specified on the 
		 *      Start Service Adjustment Type (Landlord Reversion) parameter.
		 */
		if (parmShouldApplyConnChargeToLL.isTrue()) {
			//landlordSA = cmCheckIfBackToBackReversion();	
			Bool isBackToBackReversion = cmCheckIfBackToBackReversion();
			//if (notNull(landlordSA)) {
			if (isBackToBackReversion.isTrue()) {

				// Create Frozen Start Service Adjustment for Landlord Reversion
				CreateFrozenAdjustmentData crFrozenAdjData = CreateFrozenAdjustmentData.Factory.newInstance();
				crFrozenAdjData.setAdjustmentType(parmAdjTypeStartServiceMGE);
				crFrozenAdjData.setAdjustmentDate(this.getProcessDateTime().getDate());
				crFrozenAdjData.setAdjustmentAmount(parmAdjTypeStartServiceMGE.getDefaultAmount());
				crFrozenAdjData.setAllowZeroAmount(Bool.FALSE);
				//crFrozenAdjData.setServiceAgreement(landlordSA);				
				crFrozenAdjData.setServiceAgreement(currentSA);
				//landlordSA.createFrozenAdjustment(crFrozenAdjData);										
				currentSA.createFrozenAdjustment(crFrozenAdjData);
				adjCreatedLL = Bool.TRUE;
			}
		}						
		// END ADD - JHERNA - 2015-04-22 - DEFECT#3122894
		//KL20131031 - Start changes for IM-040260
		// parmShouldApplyReconFeeFlg is set to true to apply Reconnection Fee during completion of 
		// manually created FAs for reconnecting from Non-Compliance or reconnecting from Non-Pay 
		if(parmShouldApplyReconFeeFlg.isTrue()){
			// START CHANGES - JHERNA - 2015-06-12 - DEFECT#3224532
			// Proceed only if the SA that is being processed is not for the Landlord
			/*
			if ((isNull(landlordSA)) 
					|| (notNull(landlordSA)
					&& currentSA.getAccount().getId().compareTo(landlordSA.getAccount().getId()) != 0)) {
			*/
			if (adjCreatedLL.isFalse()) { 
				Adjustment adjustment = createStartServiceAdjustment(currentSA, parmStartServiceAdjType2);
				createPremiseCharOnAdj(adjustment, currentPremise.getId().getTrimmedValue());
				createAdjIdCharOnFA(adjustment.getId().getTrimmedValue());
				return;				
			}
			// END CHANGES - JHERNA - 2015-06-12 - DEFECT#3224532
		}
		//KL20131031 - End changes for IM-040260

		Landlord_Id landlordId = currentPremise.getLandLordId();
		// Verifying if the current customer is a Landlord
		if((currentAccount.getCustomerClass().getId().compareTo(parmLandlordCustClass.getId()) == 0) 
				&& notNull(landlordId) && notNull(landlordId.getEntity())){
			isCurrentAccountLandlord = true;
		}
		// If Service History is not to be considered, then just apply Service Initiation Charges (Adj Type 1)
		// KL20130607 - Defect Fix for 1781 - Included checks
		//if(parmSvcHistAdjFlg.isNo() && !isCurrentAccountLandlord){
		if(!isCurrentAccountLandlord && (parmSvcHistAdjFlg.isNo() || isNull(parmServiceHistoryFACharType) || isNull(parmStartServiceAdjType2))){
			// START CHANGES - JHERNA - 2015-06-12 - DEFECT#3224532
			// Proceed only if the SA being processed is not for the landlord
			/*
			if ((isNull(landlordSA)) 
					|| (notNull(landlordSA)
							&& currentSA.getAccount().getId().compareTo(landlordSA.getAccount().getId()) != 0)) {
			*/
			if (adjCreatedLL.isFalse()) {
				processEligibleSA(currentSA);
				return;				
			}
			// END CHANGES - JHERNA - 2015-06-12 - DEFECT#3224532
		}else if(parmSvcHistAdjFlg.isVoluntaryDisconnect() || parmSvcHistAdjFlg.isDisconnectForNonPayment() 
				|| parmSvcHistAdjFlg.isVoluntaryDisconnectAndDisconnectForNonPayment()){
			// START CHANGES - JHERNA - 2015-04-22 - DEFECT#3122894
			/*
			 * If the Check Service History at Same Premise Only parameter is Y, restrict service history to the 
			 * same premise as start service only when checking if customer starting service was previously disconnected for service.
			 */
			if (parmShouldCheckSvcHistoryAtSamePremiseOnly.isFalse()) {				
				// KL20130607 - Start of Defect Fix - 1781
				// Check if the Main Person is associated to a disconnected service at another Premise
				// and if yes, apply Reconnect fee even though he is the landlord
				//			List<SQLResultRow> listOfOtherServices = getMainPersonsDisconnectedServiceAtOtherPremise();
				SQLResultRow disconnectedServiceAtOtherPremise = getMainPersonsDisconnectedServiceAtOtherPremise();
				//if(listOfOtherServices.size() > 0){
				if(notNull(disconnectedServiceAtOtherPremise)){
					
					// KL20130628 - Start of Defect Fix for 691
					//Premise_Id previousPremiseId = (Premise_Id)disconnectedServiceAtOtherPremise.getId("SP.PREM_ID", Premise.class);
					Premise_Id previousPremiseId = (Premise_Id)disconnectedServiceAtOtherPremise.getId("PREM_ID", Premise.class);
					// KL20130628 - End of Defect Fix for 691
					// KL20130920 - Start of fix for IM-035783
					noOfDisconnectFAs = noOfDisconnectFAs.add(BigInteger.ONE);
					FieldActivity disconnectFA = ((FieldActivity_Id)disconnectedServiceAtOtherPremise.getId("FA_ID", FieldActivity.class)).getEntity();
					earliestDisconnectDate = disconnectFA.getScheduleDateTimeStart().getDate();
					BigInteger adjCount = retrieveReconnectAdjForPerson(earliestDisconnectDate);
					if(adjCount.compareTo(noOfDisconnectFAs) < 0){
						// START CHANGES - JHERNA - 2015-06-12 - DEFECT#3224532
						// Proceed only if the SA being processed is not for the landlord.
						/*
						if ((isNull(landlordSA)) 
								|| (notNull(landlordSA)
										&& currentSA.getAccount().getId().compareTo(landlordSA.getAccount().getId()) != 0)) {
						*/
						if (adjCreatedLL.isFalse()) {
							// KL20130920 - End of fix for IM-035783
							Adjustment adjustment = createStartServiceAdjustment(currentSA, parmStartServiceAdjType2);
							createPremiseCharOnAdj(adjustment, previousPremiseId.getTrimmedValue());
							createAdjIdCharOnFA(adjustment.getId().getTrimmedValue());
							return;
							// KL20130920 - Start of fix for IM-035783							
						}
						// END CHANGES - JHERNA - 2015-06-12 - DEFECT#3224532
					}
				}
				// KL20130920 - End of fix for IM-035783
			}
			// END CHANGES - JHERNA - 2015-04-22 - DEFECT#3122894
			/*
			 **
			 * KL20130607 - Commented as part of Defect Fix 1781
			 * 
				ServiceAgreement_Id prevSaId = null;
				for(SQLResultRow otherService : listOfOtherServices){
					prevSaId = (ServiceAgreement_Id)otherService.getId("SA_ID", ServiceAgreement.class);
					prevSaId = checkIfSAIsEligible(prevSaId);
					if(notNull(prevSaId) && !isCurrentAccountLandlord){ // Previous Premise's SA is eligible
						// Start Defect 490
						//processEligibleSA(prevSaId.getEntity());
						processEligibleSA(currentSA);
						break;
						// End Defect 490
					}
				} //If an eligible active Service Agreement is not identified retrieve the Field Activity that stopped the previous Premise(s) service.
				if(isNull(prevSaId) && notNull(parmServiceHistoryFACharType) && notNull(parmStartServiceAdjType2) 
						&& (parmSvcHistAdjFlg.isDisconnectForNonPayment() || parmSvcHistAdjFlg.isVoluntaryDisconnectAndDisconnectForNonPayment())){
					// retrieve the disconnect for non-payment completed Field Activity history for the previous Premise in the last X number of days

					Premise_Id previousPremiseId = getDisconnectForNonPaymentFAs(listOfOtherServices); 
					//Start CR72 - KL20130503
					if(isCurrentAccountLandlord && !isDisconnectOnLandlordService){
						shouldApplyAdj = false;
					}

					if(notNull(previousPremiseId) && shouldApplyAdj){ // End CR72
						Adjustment adjustment = createStartServiceAdjustment(currentSA, parmStartServiceAdjType2);
						createPremiseCharOnAdj(adjustment, previousPremiseId.getTrimmedValue());
						// Start TIR5
						//FinancialTransaction_Id ftId = getFinancialTransaction(adjustment.getId());
                        //createFtIdCharOnFA(ftId.getTrimmedValue());

						createAdjIdCharOnFA(adjustment.getId().getTrimmedValue());
						// End TIR5
					}
				}
			 **/
			// If the main person of the account associated to the completed field activity does not have previous service at another Premise 
			//validate the current Premise associated to completed field activity
			// KL20130920 - Start of fix for IM-035783 
			// Commented out the else part of the loop
			//}else{
			// KL20130920 - End of fix for IM-035783
			/*
			 **
			 * KL20130607 - Commented as part of Defect Fix 1781
			 * 
				ServiceAgreement_Id saId = checkIfSAIsEligible(null);
				if(notNull(saId) && !isCurrentAccountLandlord){
					// If eligible SA exists on the current premise and service is not reverted back to Landlord from tenant , process Current SA
					processEligibleSA(currentSA);
				}else{

				// If Service History is disconnect due to non-pay or both, apply Reconnection Fee - Adj. Type 2
				//if(notNull(parmServiceHistoryFACharType) && notNull(parmStartServiceAdjType2)){
			 **/
			if(hadProcessedForDisconnectFAs()){
				return;
			}
			//}
			//}
			// KL20130920 - Start of fix for IM-035783
			//}
			// KL20130920 - End of fix for IM-035783
		}

		// KL20130607 - Included as part of Defect Fix 1781
		// If none of the above conditions are satisfied and current account is not Landlord, apply Service Initiation Fee 
		if(!isCurrentAccountLandlord && !hadAppliedAdj){	
			// START CHANGES - JHERNA - 2015-06-12 - DEFECT#3224532
			// Proceed only if the SA being processed is not for the Landlord	
			/*
			if ((isNull(landlordSA)) 
					|| (notNull(landlordSA)
							&& currentSA.getAccount().getId().compareTo(landlordSA.getAccount().getId()) != 0)) {
			*/	
			if (adjCreatedLL.isFalse()) {
				processEligibleSA(currentSA);				
			}
			// END CHANGES - JHERNA - 2015-06-12 - DEFECT#3224532
		}
		// KL20130607 - End of Defect Fix 1781
	}

	/*
	 **
	 * KL20131031 - Start of delete for IM-040260
	 * Commented out as a generic function has been put in place
	 * 
	 * private boolean isBypassStartSrvcAdjustment(){
		boolean isBypass = true;
		StringBuilder isBypassCharOnFAStr = new StringBuilder();
		isBypassCharOnFAStr.append("SELECT 'X' FROM CI_FA_CHAR ");
		isBypassCharOnFAStr.append("	WHERE FA_ID = :inputFAId and CHAR_TYPE_CD = :bypassCharTyp");

		PreparedStatement isBypassCharOnFAQuery = createPreparedStatement(isBypassCharOnFAStr.toString()); 
		isBypassCharOnFAQuery.bindId("inputFAId", parmFieldActivity.getId());
		isBypassCharOnFAQuery.bindId("bypassCharTyp", parmBypassStrtSrvcAdjCharType.getId());

		if(isBypassCharOnFAQuery.list().isEmpty()){
			isBypass = false;
		}
		isBypassCharOnFAQuery.close();
		return isBypass;
	}
	 * 
	 * KL20131031 - End of delete for IM-040260
	 */

	//KL20131031 - Start of change for IM-040260
	private boolean isDesiredCharValOnFaChar(CharacteristicType charType, String desiredCharVal){
		String charValStr = null;

		StringBuilder getFACharValStr = new StringBuilder();
		getFACharValStr.append("SELECT FC1.CHAR_VAL, FC1.CHAR_VAL_FK1, FC1.ADHOC_CHAR_VAL FROM CI_FA_CHAR FC1 ");
		getFACharValStr.append("WHERE FC1.FA_ID = :currentFA AND FC1.CHAR_TYPE_CD = :charType ");
		getFACharValStr.append("AND FC1.SEQ_NUM = ( SELECT MAX(FC2.SEQ_NUM) FROM CI_FA_CHAR FC2 ");
		getFACharValStr.append("					WHERE FC2.FA_ID = FC1.FA_ID AND FC2.CHAR_TYPE_CD = FC1.CHAR_TYPE_CD) ");

		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement getFACharVal = createPreparedStatement(getFACharValStr.toString());
		PreparedStatement getFACharVal = createPreparedStatement(getFACharValStr.toString(), getClass().getName());
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        getFACharVal.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		getFACharVal.bindId("currentFA", parmFieldActivity.getId());
		getFACharVal.bindId("charType", charType.getId());

		if(!getFACharVal.list().isEmpty()) {

            // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
            getFACharVal.close();
            // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
			
			if(isBlankOrNull(desiredCharVal)){
				return true;
			}

			if(parmApplyFlatSICFeeCharType.getCharacteristicType().isPredefinedValue()){
				charValStr = getFACharVal.firstRow().getString("CHAR_VAL");
			} else if(parmApplyFlatSICFeeCharType.getCharacteristicType().isForeignKeyValue()){
				charValStr = getFACharVal.firstRow().getString("CHAR_VAL_FK1");
			} else if(parmApplyFlatSICFeeCharType.getCharacteristicType().isAdhocValue() || 
					parmApplyFlatSICFeeCharType.getCharacteristicType().isAdhocValue()){
				charValStr = getFACharVal.firstRow().getString("ADHOC_CHAR_VAL");
			}

			if(desiredCharVal.equals(charValStr.trim())){
				return true;
			}
		}
		return false;
	}
	//KL20131031 - End of change for IM-040260


	private boolean getEligibleSAForSP(){
		CharacteristicTypeLookup characteristicTypeLookup = parmEligibleSATypeCharType.getCharacteristicType();

		StringBuilder getEigibleSAsString = new StringBuilder();
		/*
		 **
		 * KL20131105 - Start of delete 
		 * Rewriting the sql to exclude the Start Activity Check 
		 * if the FA is a manually created FA (Apply Reconnect Fee Flag is "Y")
		 * 
		getEigibleSAsString.append("SELECT SA.SA_ID ");
		getEigibleSAsString.append("FROM CI_FA FA, CI_SA_SP_FA SASPFA, CI_SA_SP SS, CI_SA SA, CI_SA_TYPE ST, CI_SA_TYPE_CHAR CH ");
		getEigibleSAsString.append("WHERE FA.FA_ID = :faId ");
		getEigibleSAsString.append("AND SASPFA.FA_ID = FA.FA_ID ");
		getEigibleSAsString.append("AND SASPFA.SA_SP_FA_TYPE_FLG = :startActivity ");
		getEigibleSAsString.append("AND SASPFA.SP_ID = SS.SP_ID ");
		getEigibleSAsString.append("AND FA.SCHED_DTTM >= SS.START_DTTM ");
		getEigibleSAsString.append("AND (SS.STOP_DTTM IS NULL OR SS.STOP_DTTM >= FA.SCHED_DTTM) ");
		getEigibleSAsString.append("AND SS.SA_ID = SASPFA.SA_ID ");
		getEigibleSAsString.append("AND SASPFA.SA_ID = SA.SA_ID ");
		getEigibleSAsString.append("AND SA.SA_TYPE_CD = ST.SA_TYPE_CD ");
		getEigibleSAsString.append("AND SA.CIS_DIVISION = ST.CIS_DIVISION ");
		getEigibleSAsString.append("AND SA.SA_TYPE_CD = CH.SA_TYPE_CD ");

		getEigibleSAsString.append(appendCharConditions(characteristicTypeLookup));
		getEigibleSAsString.append("AND CH.SEQ_NUM = (SELECT MAX(SEQ_NUM) FROM CI_SA_TYPE_CHAR WHERE SA_TYPE_CD = CH.SA_TYPE_CD AND CHAR_TYPE_CD = CH.CHAR_TYPE_CD) ");

		getEigibleSAsString.append("AND ST.SVC_TYPE_CD IN   (:utilityServiceType1 ");
		if(notNull(parmUtilityServiceType2)){
			getEigibleSAsString.append("                  ,:utilityServiceType2  ");
		}
		getEigibleSAsString.append(" )  ");
		getEigibleSAsString.append("AND SA.SA_STATUS_FLG IN (:pendingStart,:active) ");
		 *
		 * KL20131105 - End of delete
		 */
		// KL20131105 - Start of change for IM040260 
		// Modified SQL to not check for Start Activity flag on the SASPFA table for manually created FAs.
		getEigibleSAsString.append("SELECT SA.SA_ID ");
		getEigibleSAsString.append("FROM CI_FA FA, CI_SA_SP SS, CI_SA SA, CI_SA_TYPE SATYP, CI_SA_TYPE_CHAR CH ");
		if(parmShouldApplyReconFeeFlg.isFalse()){
			getEigibleSAsString.append(", CI_SA_SP_FA SASPFA ");
		}
		getEigibleSAsString.append("WHERE FA.FA_ID = :faId  AND FA.SP_ID = SS.SP_ID ");
		if(parmShouldApplyReconFeeFlg.isFalse()){
			getEigibleSAsString.append("AND FA.FA_ID = SASPFA.FA_ID ");
			getEigibleSAsString.append("AND SS.SP_ID = SASPFA.SP_ID ");
			getEigibleSAsString.append("AND SS.SA_ID = SASPFA.SA_ID ");
			getEigibleSAsString.append("AND SASPFA.SA_SP_FA_TYPE_FLG = :startActivity ");
		}
		getEigibleSAsString.append("AND FA.SCHED_DTTM >= SS.START_DTTM ");
		getEigibleSAsString.append("AND (SS.STOP_DTTM IS NULL OR SS.STOP_DTTM >= FA.SCHED_DTTM) ");
		getEigibleSAsString.append("AND SS.SA_ID = SA.SA_ID ");
		getEigibleSAsString.append("AND SA.SA_TYPE_CD = SATYP.SA_TYPE_CD ");
		getEigibleSAsString.append("AND SA.CIS_DIVISION = SATYP.CIS_DIVISION ");
		getEigibleSAsString.append("AND SA.SA_TYPE_CD = CH.SA_TYPE_CD ");

		getEigibleSAsString.append(appendCharConditions(characteristicTypeLookup));
		getEigibleSAsString.append("AND CH.SEQ_NUM = (SELECT MAX(SEQ_NUM) FROM CI_SA_TYPE_CHAR WHERE SA_TYPE_CD = CH.SA_TYPE_CD AND CHAR_TYPE_CD = CH.CHAR_TYPE_CD) ");

		getEigibleSAsString.append("AND SATYP.SVC_TYPE_CD IN   (:utilityServiceType1 ");
		if(notNull(parmUtilityServiceType2)){
			getEigibleSAsString.append("                  ,:utilityServiceType2  ");
		}
		getEigibleSAsString.append(" )  ");
		getEigibleSAsString.append("AND SA.SA_STATUS_FLG IN (:pendingStart,:active) ");
		// KL20131105 - End of change for IM040260 
		
		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement getEligibleSAsPrepStmt = createPreparedStatement(getEigibleSAsString.toString()); 
		PreparedStatement getEligibleSAsPrepStmt = createPreparedStatement(getEigibleSAsString.toString(), getClass().getName()); 
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        getEligibleSAsPrepStmt.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
		getEligibleSAsPrepStmt.bindId("faId", parmFieldActivity.getId());
		// KL20131105 - Start of change for IM040260 
		if(parmShouldApplyReconFeeFlg.isFalse()){
			getEligibleSAsPrepStmt.bindLookup("startActivity", ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
		}
		// KL20131105 - End of change for IM040260 
		getEligibleSAsPrepStmt.bindId("characteristicType", parmEligibleSATypeCharType.getId());
		getEligibleSAsPrepStmt.bindId("utilityServiceType1", parmUtilityServiceType1.getId());
		if(notNull(parmUtilityServiceType2)){
			getEligibleSAsPrepStmt.bindId("utilityServiceType2", parmUtilityServiceType2.getId());
		}
		if(characteristicTypeLookup.isPredefinedValue()){
			getEligibleSAsPrepStmt.bindStringProperty("charValue", ServiceAgreementCharacteristic.properties.characteristicValue ,parmEligibleSATypeCharValue.trim());    
		}else if(characteristicTypeLookup.isForeignKeyValue()){
			getEligibleSAsPrepStmt.bindStringProperty("charValue", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1,parmEligibleSATypeCharValue.trim());         
		}else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
			getEligibleSAsPrepStmt.bindStringProperty("charValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, parmEligibleSATypeCharValue.trim());
		}
		getEligibleSAsPrepStmt.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
		getEligibleSAsPrepStmt.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);

		List<SQLResultRow> resultList = getEligibleSAsPrepStmt.list();
		getEligibleSAsPrepStmt.close();

		if(resultList.isEmpty()){

			// START DELETE - JHERNA - 2015-06-29 - 3241226
			// As per Lynette, no error / to do needs to be created, simply exit the algorithm without creating any adjustments
			/*			
			if(isOnlineConnection()){
				addError(CustomMessageRepository.na0073NoEligibleSAAssociatedToSPofFA(parmFieldActivity.getId().getTrimmedValue()));
			}else{
				// Create To Do entry of Type (soft parameter - toDoType) drill key = FA Id, Sort Key=FA creation date time. Exit.
				createToDoEntry();
			}
			*/
			// END DELETE - JHERNA - 2015-06-29 - 3241226
			return false;
		}else{
			ServiceAgreement sa;
			for(SQLResultRow resultRow : resultList){
				// Eligible SA should be chosen by priority of Service Type parameters
				sa = ((ServiceAgreement_Id)resultRow.getId("SA_ID", ServiceAgreement.class)).getEntity();
				if(sa.getServiceAgreementType().getServiceType().equals(parmUtilityServiceType1)){
					currentSA = sa;
					break;
				}                
			}
			if(isNull(currentSA)){
				sa = ((ServiceAgreement_Id)resultList.iterator().next().getId("SA_ID", ServiceAgreement.class)).getEntity();
			}
			return true;
		}
	}

	private StringBuilder appendCharConditions(CharacteristicTypeLookup characteristicTypeLookup){
		StringBuilder queryString = new StringBuilder();
		queryString.append("AND CH.CHAR_TYPE_CD = :characteristicType ");
		if(characteristicTypeLookup.isPredefinedValue()){
		    // CCB v2.6 Upgrade - 2018-07-25 - Start Change
			//queryString.append("AND TRIM(CH.CHAR_VAL) = :charValue ");
		    queryString.append("AND CH.CHAR_VAL = :charValue ");
			// CCB v2.6 Upgrade - 2018-07-25 - End Change
		}else if(characteristicTypeLookup.isForeignKeyValue()){
		    // CCB v2.6 Upgrade - 2018-07-25 - Start Change
			//queryString.append("AND TRIM(CH.CHAR_VAL_FK1) = :charValue ");
		    queryString.append("AND CH.CHAR_VAL_FK1 = :charValue ");
			// CCB v2.6 Upgrade - 2018-07-25 - End Change
		}else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
		    // CCB v2.6 Upgrade - 2018-07-25 - Start Change
			//queryString.append("AND TRIM(CH.ADHOC_CHAR_VAL) = :charValue ");
		    queryString.append("AND CH.ADHOC_CHAR_VAL = :charValue ");
			// CCB v2.6 Upgrade - 2018-07-25 - End Change
		}
		return queryString;
	}


	private void createAdjIdCharOnFA(String adjIdStr){

		FieldActivityCharacteristics faCharacteristics = parmFieldActivity.getCharacteristics();
		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//ListFilter<FieldActivityCharacteristic> faCharListFilter = parmFieldActivity.getCharacteristics().createFilter(" WHERE this.id.characteristicType = :characteristicType ");
		ListFilter<FieldActivityCharacteristic> faCharListFilter = parmFieldActivity.getCharacteristics().createFilter(" WHERE this.id.characteristicType = :characteristicType ", getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		faCharListFilter.bindEntity("characteristicType",parmAdjIdCharType);

		FieldActivityCharacteristic_DTO faCharacteristicDTO = faCharacteristics.newChildDTO();
		CharacteristicTypeLookup charTypeLookup = parmAdjIdCharType.getCharacteristicType();

		faCharacteristicDTO.setId(new FieldActivityCharacteristic_Id(parmFieldActivity, parmAdjIdCharType, BigInteger.valueOf(faCharListFilter.listSize() +1)));
		if(charTypeLookup.isAdhocValue()){
			faCharacteristicDTO.setAdhocCharacteristicValue(adjIdStr);
		} else if (charTypeLookup.isPredefinedValue()){
			faCharacteristicDTO.setCharacteristicValue(adjIdStr);
		} else if (charTypeLookup.isForeignKeyValue()){
			faCharacteristicDTO.setCharacteristicValueForeignKey1(adjIdStr);
		}
		FieldActivityCharacteristic faChar = faCharacteristicDTO.newEntity();
		faCharacteristics.add(faChar);
	}

	/**
	 * This method returns the total adjustment created on the processing date on the given SA, but not yet moved to the PA
	 * @param saId
	 * @return
	 */
	private Money getTotalAdjAmtCreatedOnProcessDt(ServiceAgreement_Id saId){

		StringBuilder getAmountString = new StringBuilder();
		getAmountString.append("SELECT SUM(FT.CUR_AMT) AMT ");
		getAmountString.append("FROM CI_FT FT , CI_ADJ ADJ ");
		getAmountString.append("WHERE FT.SIBLING_ID = ADJ.ADJ_ID ");
		getAmountString.append("AND ADJ.SA_ID = :eligibleSa ");
		getAmountString.append("AND ADJ.ADJ_TYPE_CD IN (:startServiceAdjType, :xferAdjType) ");
		getAmountString.append("AND TRIM(FT.BILL_ID) IS NULL ");
		getAmountString.append("AND ADJ.CRE_DT = :processingDate ");
		getAmountString.append("AND ADJ.ADJ_STATUS_FLG = :frozen ");

		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement getAmountPrepStmt = createPreparedStatement(getAmountString.toString());
		PreparedStatement getAmountPrepStmt = createPreparedStatement(getAmountString.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        getAmountPrepStmt.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
		getAmountPrepStmt.bindId("eligibleSa", saId);
		getAmountPrepStmt.bindId("startServiceAdjType", parmStartServiceAdjType1.getId());
		getAmountPrepStmt.bindId("xferAdjType", transferAdjustmentTypeId);
		getAmountPrepStmt.bindDate("processingDate", getProcessDateTime().getDate());
		getAmountPrepStmt.bindLookup("frozen", AdjustmentStatusLookup.constants.FROZEN);

		SQLResultRow row =   getAmountPrepStmt.firstRow();
		getAmountPrepStmt.close();

		return (Money)row.getMoney("AMT");
	}

	private ServiceAgreement_Id getExistingPayArrange(ServiceAgreement eligibleSA){

		StringBuilder getPAString = new StringBuilder();
		getPAString.append("SELECT SA.SA_ID ");
		getPAString.append("FROM CI_SA SA ");
		getPAString.append("WHERE SA.ACCT_ID = :acctId ");
		// CCB v2.6 Upgrade - 2018-07-25 - Start Change
		//getPAString.append("AND TRIM(SA.SA_TYPE_CD) = :paSaTypeCd ");
		getPAString.append("AND SA.SA_TYPE_CD = :paSaTypeCd ");
		// CCB v2.6 Upgrade - 2018-07-25 - End Change
		getPAString.append("AND SA.CIS_DIVISION = :cisDivision ");
		getPAString.append("AND SA.START_DT = :processDate ");
		getPAString.append("AND SA.SA_STATUS_FLG IN (:pendingStart , :active) ");

		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement getPAPrepStmt = createPreparedStatement(getPAString.toString()); 
		PreparedStatement getPAPrepStmt = createPreparedStatement(getPAString.toString(), getClass().getName()); 
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        getPAPrepStmt.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
		getPAPrepStmt.bindId("acctId", eligibleSA.getAccount().getId());
		getPAPrepStmt.bindStringProperty("paSaTypeCd", ServiceAgreementType.properties.saType, parmInstallmentPaSaType.trim());
		getPAPrepStmt.bindId("cisDivision", parmInstallmentPaCISDivision.getId());
		getPAPrepStmt.bindDate("processDate", getProcessDateTime().getDate());
		getPAPrepStmt.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
		getPAPrepStmt.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);

		SQLResultRow row =   getPAPrepStmt.firstRow();
		getPAPrepStmt.close();
		if(isNull(row)){
			return null;
		}else{
			return (ServiceAgreement_Id)row.getId("SA_ID", ServiceAgreement.class);
		}
	}

	/**
	 * Add a payment arrangement.
	 */
	private void processPaAdd(ServiceAgreement eligibleSA, Money amount, Money recurringChargeAmount) {

		ServiceAgreementCreator saCreator = ServiceAgreementCreator.Factory.newInstance();
		ServiceAgreement_DTO saDto = (ServiceAgreement_DTO) createDTO(ServiceAgreement.class);
		ServiceAgreementCreatorData saCreatorData = ServiceAgreementCreatorData.Factory.newInstance();
		saDto.setServiceAgreementTypeId(payArrangeSATypeId);
		saCreatorData.setShouldOverrideSAStatus(Bool.FALSE);
		saDto.setStatus(ServiceAgreementStatusLookup.constants.PENDING_START);
		saDto.setAccountId(eligibleSA.getAccount().getId());
		saDto.setStartDate(getSystemDateTime().getDate());
		saDto.setAreEstimatesAllowed(Bool.FALSE);
		saDto.setCustomerRead(CustomerReadLookup.constants.NO);
		saCreatorData.setRecurringChargeAmount(recurringChargeAmount); // for Payment Arrangement, Recurring Charge Amount is Arrears amount
		saDto.setStartReason(StartReasonLookup.constants.CUSTOMER_REQUEST);
		saCreatorData.setShouldCreateFieldActivity(Bool.FALSE);
		saCreatorData.setShouldExcludeCopySASP(Bool.TRUE);
		saCreatorData.setCopyOption(CopyOptionForProposalSALookup.constants.COPY_OPTION_FOR_PROPOSAL_S_A_B_S_P);
		ServiceAgreement paSa = saCreator.addServiceAgreement(saDto, saCreatorData);

		if(notNull(transferAdjustmentTypeId) && notNull(transferAdjustmentTypeId.getEntity())){
			createAdjustment(eligibleSA, paSa, amount, transferAdjustmentTypeId.getEntity());
		}
		AdjustmentType_Id adjTypeCurrentToZero = payArrangeSATypeId.getEntity().getAdjustmentTypeCurrent0Id();
		if(notNull(adjTypeCurrentToZero) && notNull(adjTypeCurrentToZero.getEntity())){
			createAdjustment(paSa, null, amount.negate(), adjTypeCurrentToZero.getEntity());
		}
	}

	/**
	 * Create and freeze an adjustment.
	 */
	private void createAdjustment(ServiceAgreement sa, ServiceAgreement xferSa, Money adjAmount, AdjustmentType adjType) {

		CreateFrozenAdjustmentData adjustmentData = CreateFrozenAdjustmentData.Factory.newInstance();

		adjustmentData.setServiceAgreement(sa);
		adjustmentData.setTransferServiceAgreement(xferSa);
		adjustmentData.setAdjustmentAmount(adjAmount);
		adjustmentData.setAdjustmentType(adjType);

		if (!adjAmount.equals(Money.ZERO)) {
			adjustmentData.setAllowZeroAmount(Bool.FALSE);
		} else {
			adjustmentData.setAllowZeroAmount(Bool.TRUE);
		}

		CreateFrozenAdjustment createFrozenAdjustment = CreateFrozenAdjustment.Factory.newInstance();
		createFrozenAdjustment.createFrozenAdjustment(adjustmentData);
	}

	//	private List<SQLResultRow> getMainPersonsDisconnectedServiceAtOtherPremise(){
	private SQLResultRow getMainPersonsDisconnectedServiceAtOtherPremise(){
		StringBuilder getOtherServiceString = new StringBuilder();
		//KL20130607 - Start of Defect Fix #1781
		/*
		 **
		 * 
		getOtherServiceString.append("SELECT SA1.SA_ID, SA1.CHAR_PREM_ID  ");
		getOtherServiceString.append("FROM CI_ACCT_PER AP1, CI_SA SA1, CI_FA FA, CI_SP SP ");
		getOtherServiceString.append("WHERE AP1.MAIN_CUST_SW = :yes ");
		getOtherServiceString.append("AND AP1.PER_ID = (SELECT AP.PER_ID ");
		getOtherServiceString.append("                  FROM CI_ACCT_PER AP, CI_SA SA ");
		getOtherServiceString.append("                  WHERE AP.MAIN_CUST_SW = :yes ");
		getOtherServiceString.append("                  AND AP.ACCT_ID = SA.ACCT_ID ");
		getOtherServiceString.append("                  AND SA.SA_ID = :currentSA) ");
		getOtherServiceString.append("AND AP1.ACCT_ID = SA1.ACCT_ID ");
		getOtherServiceString.append("AND SA1.SA_ID != :currentSA  ");
		getOtherServiceString.append("AND TRIM(SA1.CHAR_PREM_ID) IS NOT NULL ");
		getOtherServiceString.append("AND SA1.CHAR_PREM_ID <> SP.PREM_ID ");
		getOtherServiceString.append("AND FA.FA_ID = :faId ");
		getOtherServiceString.append("AND FA.SP_ID = SP.SP_ID ");
		getOtherServiceString.append("ORDER BY SA1.START_DT DESC ");

		PreparedStatement getServicePrepStmt = createPreparedStatement(getOtherServiceString.toString()); 
		getServicePrepStmt.bindId("currentSA", currentSA.getId());
		getServicePrepStmt.bindId("faId", parmFieldActivity.getId());
		getServicePrepStmt.bindBoolean("yes", Bool.TRUE);
		 **/

		SQLResultRow firstRow = null;
		CharacteristicTypeLookup characteristicTypeLookup = parmServiceHistoryFACharType.getCharacteristicType();
		// START CHANGE - DHUYNH - 2016-09-20 - DEFECT#126923
		getOtherServiceString.append("SELECT SA.SA_ID, SA.SA_STATUS_FLG, SP.PREM_ID, FA.FA_ID ");
		getOtherServiceString.append("FROM CI_ACCT_PER AP1, CI_SA SA, CI_SP SP, CI_SA_SP SASP, CI_SA_TYPE SATY, ");
		getOtherServiceString.append("CI_SA_SP_FA SASPFA, CI_FA FA, CI_FA_TYPE_CHAR FATYCH, ");
		getOtherServiceString.append("CI_SEV_EVT_FA SEVFA, CI_SEV_PROC SEV ");
		getOtherServiceString.append("	WHERE AP1.MAIN_CUST_SW = :yes AND AP1.PER_ID = :currentMainPerson ");
		getOtherServiceString.append("	AND AP1.ACCT_ID = SA.ACCT_ID AND SA.SA_ID = SASP.SA_ID ");
		getOtherServiceString.append("	AND SASP.SP_ID = SP.SP_ID AND SP.PREM_ID <> :currentPremise ");
		// KL20130617 - Start of defect fix for 691
		getOtherServiceString.append("	AND SASP.SA_SP_ID = SASPFA.SA_SP_ID ");
		getOtherServiceString.append("	AND SEVFA.FA_ID = FA.FA_ID ");
		getOtherServiceString.append("	and SEV.SEV_PROC_ID = SEVFA.SEV_PROC_ID ");
		getOtherServiceString.append("	and SEV.SA_ID = SA.SA_ID ");		
		getOtherServiceString.append("	 AND SASPFA.SA_SP_FA_TYPE_FLG IN (:stopActivity, :severanceActivity) ");
		// KL20130617 - End of defect fix for 691
		// END CHANGE - DHUYNH - 2016-09-20 - DEFECT#126923
		getOtherServiceString.append("	AND SASPFA.FA_ID = FA.FA_ID AND FA.FA_TYPE_CD = FATYCH.FA_TYPE_CD ");
		getOtherServiceString.append("	AND FATYCH.CHAR_TYPE_CD = :serviceHistFACharType ");
		if(characteristicTypeLookup.isPredefinedValue()){
		    // CCB v2.6 Upgrade - 2018-07-25 - Start Change
			//getOtherServiceString.append("AND TRIM(FATYCH.CHAR_VAL) = :nonPayDisconnect ");
		    getOtherServiceString.append("AND FATYCH.CHAR_VAL = :nonPayDisconnect ");
			// CCB v2.6 Upgrade - 2018-07-25 - End Change
		}else if(characteristicTypeLookup.isForeignKeyValue()){
		    // CCB v2.6 Upgrade - 2018-07-25 - Start Change
			//getOtherServiceString.append("AND TRIM(FATYCH.CHAR_VAL_FK1) = :nonPayDisconnect ");
			getOtherServiceString.append("AND FATYCH.CHAR_VAL_FK1 = :nonPayDisconnect ");
			// CCB v2.6 Upgrade - 2018-07-25 - End Change
		}else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
		    // CCB v2.6 Upgrade - 2018-07-25 - Start Change
			//getOtherServiceString.append("AND TRIM(FATYCH.ADHOC_CHAR_VAL) = :nonPayDisconnect ");
		    getOtherServiceString.append("AND FATYCH.ADHOC_CHAR_VAL = :nonPayDisconnect ");
			// CCB v2.6 Upgrade - 2018-07-25 - End Change
		}
		getOtherServiceString.append("	AND FATYCH.SEQ_NUM = (SELECT MAX(SEQ_NUM) FROM CI_FA_TYPE_CHAR ");
		getOtherServiceString.append("							WHERE FA_TYPE_CD = FATYCH.FA_TYPE_CD AND CHAR_TYPE_CD = FATYCH.CHAR_TYPE_CD) ");
		getOtherServiceString.append("	AND FA.FA_STATUS_FLG = :complete AND FA.SCHED_DTTM BETWEEN :historicPeriodStartDttm AND :processingDttm ");
		getOtherServiceString.append("	AND SA.SA_TYPE_CD = SATY.SA_TYPE_CD AND SATY.SVC_TYPE_CD IN  (:utilityServiceType1 ");
		if(notNull(parmUtilityServiceType2)){
			getOtherServiceString.append(",:utilityServiceType2 ");
		}
		getOtherServiceString.append(") ");
		getOtherServiceString.append("	ORDER BY SASP.STOP_DTTM DESC");

		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement getDisconServiceAtOtherPremPrepStmt = createPreparedStatement(getOtherServiceString.toString()); 
		PreparedStatement getDisconServiceAtOtherPremPrepStmt = createPreparedStatement(getOtherServiceString.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        getDisconServiceAtOtherPremPrepStmt.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
		getDisconServiceAtOtherPremPrepStmt.bindBoolean("yes", Bool.TRUE);
		getDisconServiceAtOtherPremPrepStmt.bindId("currentMainPerson", currentMainPerson.getId());
		getDisconServiceAtOtherPremPrepStmt.bindId("currentPremise", currentPremise.getId());
		getDisconServiceAtOtherPremPrepStmt.bindLookup("stopActivity", ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
		// KL20130617 - Start of defect fix for 691
		getDisconServiceAtOtherPremPrepStmt.bindLookup("severanceActivity", ServiceAgreementSpFaTypeLookup.constants.SEVERANCE_ACTIVITY);
		// KL20130617 - End of defect fix for 691
		getDisconServiceAtOtherPremPrepStmt.bindId("serviceHistFACharType", parmServiceHistoryFACharType.getId());
		if(characteristicTypeLookup.isPredefinedValue()){
			getDisconServiceAtOtherPremPrepStmt.bindStringProperty("nonPayDisconnect", ServiceAgreementCharacteristic.properties.characteristicValue ,parmDisconnectNonPaymentCharValue.trim());
		}else if(characteristicTypeLookup.isForeignKeyValue()){
			getDisconServiceAtOtherPremPrepStmt.bindStringProperty("nonPayDisconnect", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1 ,parmDisconnectNonPaymentCharValue.trim());
		}else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
			getDisconServiceAtOtherPremPrepStmt.bindStringProperty("nonPayDisconnect", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue ,parmDisconnectNonPaymentCharValue.trim());
		}
		getDisconServiceAtOtherPremPrepStmt.bindLookup("complete", FieldActivityStatusLookup.constants.COMPLETED);
		getDisconServiceAtOtherPremPrepStmt.bindDateTime("historicPeriodStartDttm", getProcessDateTime().subtract(disconnectForNonPayNumDays));
		getDisconServiceAtOtherPremPrepStmt.bindDateTime("processingDttm", getProcessDateTime());
		getDisconServiceAtOtherPremPrepStmt.bindId("utilityServiceType1", parmUtilityServiceType1.getId());
		if(notNull(parmUtilityServiceType2)){
			getDisconServiceAtOtherPremPrepStmt.bindId("utilityServiceType2", parmUtilityServiceType2.getId());
		}
		if(!getDisconServiceAtOtherPremPrepStmt.list().isEmpty()){
			firstRow = getDisconServiceAtOtherPremPrepStmt.firstRow();
		}
		//List<SQLResultRow> list = getDisconServiceAtOtherPremPrepStmt.list();
		getDisconServiceAtOtherPremPrepStmt.close();

		//return list;
		return firstRow;
	}

	/*
	 **
	 * KL20130607 - Commented as part of Defect Fix 1781
	 *
	private ServiceAgreement_Id checkIfSAIsEligible(ServiceAgreement_Id indexSaId){

		CharacteristicTypeLookup characteristicTypeLookup = parmEligibleSATypeCharType.getCharacteristicType();

		StringBuilder getEligibleSAString = new StringBuilder();
		getEligibleSAString.append("SELECT SA1.SA_ID FROM CI_SA SA1, CI_SA_TYPE ST, CI_SA_TYPE_CHAR CH  ");
		getEligibleSAString.append("WHERE SA1.SA_TYPE_CD = ST.SA_TYPE_CD ");
		if(notNull(indexSaId)){
			getEligibleSAString.append("AND SA1.SA_ID = :indexSaId ");
		}else{
			getEligibleSAString.append("AND SA1.SA_ID <> :currentSA ");
		}
		getEligibleSAString.append("AND SA1.CIS_DIVISION = ST.CIS_DIVISION ");              
		getEligibleSAString.append("AND SA1.SA_TYPE_CD = CH.SA_TYPE_CD ");
		getEligibleSAString.append("AND SA1.CIS_DIVISION = CH.CIS_DIVISION ");

		getEligibleSAString.append(appendCharConditions(characteristicTypeLookup));
		getEligibleSAString.append("AND CH.SEQ_NUM = (SELECT MAX(SEQ_NUM) FROM CI_SA_TYPE_CHAR WHERE SA_TYPE_CD = CH.SA_TYPE_CD AND CIS_DIVISION = CH.CIS_DIVISION AND CHAR_TYPE_CD = CH.CHAR_TYPE_CD) ");

		getEligibleSAString.append("AND ST.SVC_TYPE_CD IN   (:utilityServiceType1 ");
		if(notNull(parmUtilityServiceType2)){
			getEligibleSAString.append("                  ,:utilityServiceType2  ");
		}
		getEligibleSAString.append(" )  ");
		getEligibleSAString.append("AND SA1.SA_STATUS_FLG IN (:pendingStart,:active) ");

		if(isNull(indexSaId)){
			getEligibleSAString.append("AND SA1.CHAR_PREM_ID = (SELECT SP.PREM_ID ");
			getEligibleSAString.append("                FROM CI_SP SP, CI_FA FA ");
			getEligibleSAString.append("                WHERE FA.FA_ID = :faId ");
			getEligibleSAString.append("                AND FA.SP_ID = SP.SP_ID) ");
			getEligibleSAString.append("ORDER BY SA1.END_DT DESC ");
		}

		PreparedStatement getEligibleSAsPrepStmt = createPreparedStatement(getEligibleSAString.toString()); 
		if(notNull(indexSaId)){
			getEligibleSAsPrepStmt.bindId("indexSaId", indexSaId);
		}else{
			getEligibleSAsPrepStmt.bindId("currentSA", currentSA.getId());
			getEligibleSAsPrepStmt.bindId("faId", parmFieldActivity.getId());
		}
		getEligibleSAsPrepStmt.bindId("characteristicType", parmEligibleSATypeCharType.getId());
		getEligibleSAsPrepStmt.bindId("utilityServiceType1", parmUtilityServiceType1.getId());
		if(notNull(parmUtilityServiceType2)){
			getEligibleSAsPrepStmt.bindId("utilityServiceType2", parmUtilityServiceType2.getId());
		}
		if(characteristicTypeLookup.isPredefinedValue()){
			getEligibleSAsPrepStmt.bindStringProperty("charValue", ServiceAgreementCharacteristic.properties.characteristicValue ,parmEligibleSATypeCharValue.trim());    
		}else if(characteristicTypeLookup.isForeignKeyValue()){
			getEligibleSAsPrepStmt.bindStringProperty("charValue", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1,parmEligibleSATypeCharValue.trim());         
		}else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
			getEligibleSAsPrepStmt.bindStringProperty("charValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, parmEligibleSATypeCharValue.trim());
		}
		getEligibleSAsPrepStmt.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
		getEligibleSAsPrepStmt.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);

		List<SQLResultRow> resultList = getEligibleSAsPrepStmt.list();
		getEligibleSAsPrepStmt.close();

		if(resultList.isEmpty()){
			return null;
		}else{
			ServiceAgreement_Id saId;
			for(SQLResultRow resultRow : resultList){
				// Eligible SA should be chosen by priority of Service Type parameters
				saId = (ServiceAgreement_Id)resultRow.getId("SA_ID", ServiceAgreement.class);
				if(saId.getEntity().getServiceAgreementType().getServiceType().equals(parmUtilityServiceType1)){
					return saId;
				}                
			}
			saId = (ServiceAgreement_Id)resultList.iterator().next().getId("SA_ID", ServiceAgreement.class);
			return saId;
		}
	}
	 **/

	private Adjustment createStartServiceAdjustment(ServiceAgreement sa, AdjustmentType adjType){
		// KL20130607 - Start of fix for Defect 1781
		hadAppliedAdj = true;
		// KL20130607 - End of fix for Defect 1781

		CreateFrozenAdjustmentData frozenAdjData = CreateFrozenAdjustmentData.Factory.newInstance();
		frozenAdjData.setServiceAgreement(sa);
		frozenAdjData.setAdjustmentType(adjType);
		frozenAdjData.setAllowZeroAmount(Bool.FALSE);
		CreateFrozenAdjustment frozenAdjustment =  CreateFrozenAdjustment.Factory.newInstance();
		frozenAdjData = frozenAdjustment.createFrozenAdjustment(frozenAdjData);        
		Adjustment eligibleSaAdjustment = frozenAdjData.getAdjustment();
		return eligibleSaAdjustment;
		
	}

	private void processEligibleSA(ServiceAgreement serviceAgreement){
		if (isNull(parmStartServiceAdjType1))
		{
			return;
		}
		
		Adjustment eligibleSaAdjustment = createStartServiceAdjustment(serviceAgreement, parmStartServiceAdjType1);
		// Start TIR5
		/*FinancialTransaction_Id ftId = getFinancialTransaction(eligibleSaAdjustment.getId());
        createFtIdCharOnFA(ftId.getTrimmedValue());*/

		createAdjIdCharOnFA(eligibleSaAdjustment.getId().getTrimmedValue());
		// End TIR 5

		//KL20131031 - Start of change for IM-040260
		// Check if Bypass PA Creation Characteristics is on FA with desired char value
		// START CHANGES - JHERNA - 2015-04-23 - DEFECT#3122894
		/*
		if(isDesiredCharValOnFaChar(parmApplyFlatSICFeeCharType, parmApplyFlatSICFeeCharVal)){
			return;
		}
		*/
		// Perform the check only if the Apply Flat SIC Fee Characteristic type and values are provided
		if (notNull(parmApplyFlatSICFeeCharType)
				&& notBlank(parmApplyFlatSICFeeCharVal)) {
			if(isDesiredCharValOnFaChar(parmApplyFlatSICFeeCharType, parmApplyFlatSICFeeCharVal)){
				return;
			}
		}
		
		// END CHANGES - JHERNA - 2015-04-23 - DEFECT#3122894
		//KL20131031 - End of change for IM-040260

		if(parmCreateInstallmentsFlg.isTrue()){

			Money totalAdjAmtCreatedOnProcessDt = getTotalAdjAmtCreatedOnProcessDt(serviceAgreement.getId()); // adjustments created on processing date, not yet moved to PA
			ServiceAgreement_Id existingPayArrangeSAId = getExistingPayArrange(serviceAgreement); // PA created on processing date

			if(notNull(existingPayArrangeSAId)){
				// Total amount to be on the PA will be totalAdjAmtCreatedOnProcessDt + PA's payoff balance
				Money newTotalPayArrangeAmount = totalAdjAmtCreatedOnProcessDt.add(existingPayArrangeSAId.getEntity().getPayoffBalance());
				Money recurringChargeAmt = new Money(BigDecimal.valueOf(newTotalPayArrangeAmount.getAmount().doubleValue() / parmNumInstallments.doubleValue()).setScale(
						2, MathContext.ROUND_HALF_UP), totalAdjAmtCreatedOnProcessDt.getCurrencyId());  

				// Update PA's Arrange amount with the new recurring charge amount
				ServiceAgreementRecurringCharge latestRecurringCharge = existingPayArrangeSAId.getEntity().getRecurringCharges().iterator().next();
				if (latestRecurringCharge.fetchIdEffectiveDate().equals(getProcessDateTime().getDate())) {
					//if effective date = business date, update amount
					ServiceAgreementRecurringCharge_DTO latestRecurringChargeDto = latestRecurringCharge.getDTO();
					latestRecurringChargeDto.setRecurringChargeAmount(recurringChargeAmt);
					latestRecurringCharge.setDTO(latestRecurringChargeDto);
				}else{
					//otherwise, add a new entry to the recurring charge amount history
					ServiceAgreementRecurringCharge_DTO recurringChargeDto = (ServiceAgreementRecurringCharge_DTO) createDTO(ServiceAgreementRecurringCharge.class);
					recurringChargeDto.setCurrencyId(recurringChargeAmt.getCurrencyId());
					recurringChargeDto.setRecurringChargeAmount(recurringChargeAmt);
					existingPayArrangeSAId.getEntity().getRecurringCharges().add(recurringChargeDto, getProcessDateTime().getDate());
				}
				// Create a new adjustment to transfer the new adjustment amount to PA
				if(notNull(transferAdjustmentTypeId) && notNull(transferAdjustmentTypeId.getEntity())){
					createAdjustment(serviceAgreement, existingPayArrangeSAId.getEntity(), totalAdjAmtCreatedOnProcessDt, transferAdjustmentTypeId.getEntity());                
					// Create a new adjustment to make the current balance of PA = 0
					AdjustmentType_Id curBalAdjType = payArrangeSATypeId.getEntity().getAdjustmentTypeCurrent0Id();
					if(notNull(curBalAdjType) && notNull(curBalAdjType.getEntity())){
						createAdjustment(existingPayArrangeSAId.getEntity(), null, totalAdjAmtCreatedOnProcessDt.negate(), curBalAdjType.getEntity());
					}
				}
			}else{
				// create pay arrangement with transfer adjustment created for sum amount from eligible SA to the pay arrangement
				Money recurringChargeAmt = new Money(BigDecimal.valueOf(totalAdjAmtCreatedOnProcessDt.getAmount().doubleValue() / parmNumInstallments.doubleValue()).setScale(
						2, MathContext.ROUND_HALF_UP), serviceAgreement.getCurrencyId()); 
				processPaAdd(serviceAgreement, totalAdjAmtCreatedOnProcessDt, recurringChargeAmt);
			}

		}
	}


	/*
	 **
	 * KL20130607 - Commented out as part of Defect Fix for 1781
	 * 
	private Premise_Id getDisconnectForNonPaymentFAs(List<SQLResultRow> listOfCharPremises){
		CharacteristicTypeLookup characteristicTypeLookup = parmServiceHistoryFACharType.getCharacteristicType();
		ServiceAgreement disconnectedSA;

		StringBuilder getDisconnectedFAsString = new StringBuilder();
		getDisconnectedFAsString.append("SELECT FA.FA_ID, SF.SA_ID, SP.PREM_ID  ");
		getDisconnectedFAsString.append("FROM CI_SP SP, CI_SA_SP_FA SF, CI_FA FA, CI_FA_TYPE_CHAR CH ");
		getDisconnectedFAsString.append("WHERE SP.PREM_ID IN (");
		int counter = 0;
		for (SQLResultRow row : listOfCharPremises) {
			if (counter == 0) {
				getDisconnectedFAsString.append(":premise" + ++counter);
			} else {
				getDisconnectedFAsString.append(", :premise" + ++counter);
			}
		}
		getDisconnectedFAsString.append(")");
		getDisconnectedFAsString.append("AND SP.SP_ID = SF.SP_ID ");
		getDisconnectedFAsString.append("AND SF.SA_SP_FA_TYPE_FLG = :stopActivity ");
		getDisconnectedFAsString.append("AND SF.FA_ID = FA.FA_ID ");   
		getDisconnectedFAsString.append("AND FA.FA_STATUS_FLG = :complete ");
		getDisconnectedFAsString.append("AND FA.SCHED_DTTM BETWEEN (:processDateTime - :disconnectNonPaymentNumDays) AND :processDateTime ");
		getDisconnectedFAsString.append("AND FA.FA_TYPE_CD = CH.FA_TYPE_CD ");

		getDisconnectedFAsString.append(appendCharConditions(characteristicTypeLookup));
		getDisconnectedFAsString.append("AND CH.SEQ_NUM = (SELECT MAX(SEQ_NUM) FROM CI_FA_TYPE_CHAR WHERE FA_TYPE_CD = CH.FA_TYPE_CD AND CHAR_TYPE_CD = CH.CHAR_TYPE_CD) ");

		PreparedStatement getDisconnectedFAsPrepStmt = createPreparedStatement(getDisconnectedFAsString.toString());
		counter = 0;
		Premise_Id premiseId = null;
		for (SQLResultRow row : listOfCharPremises) {
			premiseId = (Premise_Id)row.getId("CHAR_PREM_ID", Premise.class);
			getDisconnectedFAsPrepStmt.bindId("premise" + ++counter, premiseId);
		}
		getDisconnectedFAsPrepStmt.bindLookup("stopActivity", ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
		getDisconnectedFAsPrepStmt.bindLookup("complete", FieldActivityStatusLookup.constants.COMPLETED);
		getDisconnectedFAsPrepStmt.bindDateTime("processDateTime", getProcessDateTime());
		getDisconnectedFAsPrepStmt.bindBigInteger("disconnectNonPaymentNumDays", parmDisconnectNonPaymentNumDays);
		getDisconnectedFAsPrepStmt.bindId("characteristicType", parmServiceHistoryFACharType.getId());
		if(characteristicTypeLookup.isPredefinedValue()){
			getDisconnectedFAsPrepStmt.bindStringProperty("charValue", ServiceAgreementCharacteristic.properties.characteristicValue ,parmDisconnectNonPaymentCharValue.trim());    
		}else if(characteristicTypeLookup.isForeignKeyValue()){
			getDisconnectedFAsPrepStmt.bindStringProperty("charValue", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1,parmDisconnectNonPaymentCharValue.trim());         
		}else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
			getDisconnectedFAsPrepStmt.bindStringProperty("charValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, parmDisconnectNonPaymentCharValue.trim());
		}

		SQLResultRow row = getDisconnectedFAsPrepStmt.firstRow();
		premiseId = null;
		if(notNull(row)){
			premiseId = (Premise_Id)row.getId("PREM_ID", Premise.class); 
			//Start CR72 - KL20130503
			Premise disconnectedPremise = premiseId.getEntity();
			disconnectedSA = (ServiceAgreement)row.getEntity("SA_ID", ServiceAgreement.class);
			if((parmLandlordCustClass.getId().compareTo(disconnectedSA.getAccount().getCustomerClass().getId()) == 0) 
					&& (!isBlankOrNull(disconnectedPremise.getLandLordId().getTrimmedValue()))) {
				isDisconnectOnLandlordService = true;
			}
			//End CR72
		}
		getDisconnectedFAsPrepStmt.close();
		return premiseId;
	}
	 **/

	private void createPremiseCharOnAdj(Adjustment adjustment, String premiseIdStr){
		AdjustmentCharacteristics adjustmentCharacteristics = adjustment.getCharacteristics();
		AdjustmentCharacteristic_DTO adjustmentCharDTO = adjustmentCharacteristics.newChildDTO();
		adjustmentCharDTO.setId(new AdjustmentCharacteristic_Id(parmPremiseCharType, adjustment, BigInteger.valueOf(1)));

		CharacteristicTypeLookup charTypeLookup = parmPremiseCharType.getCharacteristicType();
		if(charTypeLookup.isAdhocValue()){
			adjustmentCharDTO.setAdhocCharacteristicValue(premiseIdStr);
		} else if (charTypeLookup.isPredefinedValue()){
			adjustmentCharDTO.setCharacteristicValue(premiseIdStr);
		} else if (charTypeLookup.isForeignKeyValue()){
			adjustmentCharDTO.setCharacteristicValueForeignKey1(premiseIdStr);
		}
		AdjustmentCharacteristic adjChar = adjustmentCharDTO.newEntity();
		adjustmentCharacteristics.add(adjChar); 
	}

	/*
	 **
	 * KL20130607 - Commented as part of Defect Fix 1781
	 * 
	private void  processDisconnectFAs(){
		List<SQLResultRow> faList = null;
		Premise_Id premiseId;
		SQLResultRow firstRow;
		ServiceAgreement disconnectSA;
		ServiceAgreementServicePoint disconnectSaSp;
		String srvcHistCharValOnFA = null;

		// Start - Defect 491 

		CharacteristicTypeLookup charTypeLookup = parmServiceHistoryFACharType.getCharacteristicType();
//			if(parmSvcHistAdjFlg.isVoluntaryDisconnectAndDisconnectForNonPayment()){
//			faList = getFAForGivenChar(charTypeLookup, parmDisconnectNonPaymentCharValue, parmDisconnectNonPaymentNumDays);
//			faList.addAll(getFAForGivenChar(charTypeLookup, parmVoluntaryDisconnectCharValue, parmVoluntaryDisconnectNumDays));
//		}
//		if(parmSvcHistAdjFlg.isVoluntaryDisconnect()){
//			faList = getFAForGivenChar(charTypeLookup, parmVoluntaryDisconnectCharValue, parmVoluntaryDisconnectNumDays);
//		}
//		if(parmSvcHistAdjFlg.isDisconnectForNonPayment()){
//			faList = getFAForGivenChar(charTypeLookup, parmDisconnectNonPaymentCharValue, parmDisconnectNonPaymentNumDays);
//		}        

		faList = getFAForGivenChar();
		// End - Defect 491

		if(notNull(faList) && !faList.isEmpty()){
			firstRow = faList.iterator().next();
			premiseId = (Premise_Id)firstRow.getId("PREM_ID", Premise.class);   
			disconnectSA = (ServiceAgreement)firstRow.getEntity("SA_ID", ServiceAgreement.class);
			disconnectSaSp = (ServiceAgreementServicePoint)firstRow.getEntity("SA_SP_ID", ServiceAgreementServicePoint.class);
			if(charTypeLookup.isPredefinedValue()){
				srvcHistCharValOnFA = firstRow.getString("CHAR_VAL");
			}else if(charTypeLookup.isForeignKeyValue()){
				srvcHistCharValOnFA = firstRow.getString("CHAR_VAL_FK1");
			}else if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()){
				srvcHistCharValOnFA = firstRow.getString("CH.ADHOC_CHAR_VAL");
			}

			// Start - Fix for Defect 691 - KL20130507 : New Requirement 
			// Person1 had voluntarily disconnected from SP1, followed by Person2 starting and stopping service at the same SP1.
			// Now, if Person1 again starts service on the same SP1, then this is considered as a new service initiation.
			// Person1 will be charged only $25 (Adjustment Type 1). 
			// In case Person1 is Landlord, then this charge also should not be charged.
			if((srvcHistCharValOnFA.trim().equals(parmVoluntaryDisconnectCharValue)) && !isCurrentAccountLandlord 
					&& hadAnotherServiceInitiatedAndStopped(disconnectSaSp)){
				processEligibleSA(currentSA);
				return;
			}

			//Start CR72 - KL20130503
			if((parmLandlordCustClass.getId().compareTo(disconnectSA.getAccount().getCustomerClass().getId()) == 0) 
					&& (!isBlankOrNull(premiseId.getEntity().getLandLordId().getTrimmedValue()))) {
				isDisconnectOnLandlordService = true;
			}
			if(isCurrentAccountLandlord && !isDisconnectOnLandlordService){
				shouldApplyAdj = false;
			}

			if(notNull(premiseId) && shouldApplyAdj){ // End CR72
				Adjustment adjustment = createStartServiceAdjustment(currentSA, parmStartServiceAdjType2);
				createPremiseCharOnAdj(adjustment, premiseId.getTrimmedValue());
				// Start TIR 5
				//FinancialTransaction_Id ftId = getFinancialTransaction(adjustment.getId());
              //createFtIdCharOnFA(ftId.getTrimmedValue());
				createAdjIdCharOnFA(adjustment.getId().getTrimmedValue());
				// End TIR 5
			}
		}else if (!isCurrentAccountLandlord){
			// If no disconnect FA exist on the current premise(new service) and current account is not a Landlord Account,
			// create adj type 1 on the SA linked to the SP of FA, similar to flg 'N' earlier
			processEligibleSA(currentSA);
		}
	}
	 */

	private boolean hadProcessedForDisconnectFAs(){
		SQLResultRow disconnectFACurrentPremise = null;
		ServiceAgreementServicePoint disconnectSaSp;
		boolean applyAdjType2 = false;
		FieldActivity disconFA = null;

		CharacteristicTypeLookup charTypeLookup = parmServiceHistoryFACharType.getCharacteristicType();
		if(parmSvcHistAdjFlg.isVoluntaryDisconnectAndDisconnectForNonPayment() || parmSvcHistAdjFlg.isDisconnectForNonPayment()){
			// Retrieve FA that disconnected for non-pay the Main Person's other service at current premise
			disconnectFACurrentPremise = getFAForGivenChar(charTypeLookup, parmDisconnectNonPaymentCharValue, parmDisconnectNonPaymentNumDays);
			if(notNull(disconnectFACurrentPremise)){
				// KL20130920 - Start of fix for IM-035783
				noOfDisconnectFAs = noOfDisconnectFAs.add(BigInteger.ONE);
				disconFA = ((FieldActivity_Id)disconnectFACurrentPremise.getId("FA_ID", FieldActivity.class)).getEntity();

				if(earliestDisconnectDate.compareTo(disconFA.getScheduleDateTimeStart().getDate()) > 0){
					earliestDisconnectDate = disconFA.getScheduleDateTimeStart().getDate();
				}
				if(retrieveReconnectAdjForPerson(earliestDisconnectDate).compareTo(noOfDisconnectFAs) < 0){
					// KL20130920 - End of fix for IM-035783
					applyAdjType2 = true;
					// KL20130920 - Start of fix for IM-035783
				}
				// KL20130920 - End of fix for IM-035783
			}
		}
		if(parmSvcHistAdjFlg.isVoluntaryDisconnectAndDisconnectForNonPayment() || parmSvcHistAdjFlg.isVoluntaryDisconnect()){
			// Retrieve FA that voluntarily disconnected the Main Person's other service at current premise
			disconnectFACurrentPremise = getFAForGivenChar(charTypeLookup, parmVoluntaryDisconnectCharValue, parmVoluntaryDisconnectNumDays);
			
			if(notNull(disconnectFACurrentPremise) ){
				// KL20130920 - Start of fix for IM-035783
				noOfDisconnectFAs = noOfDisconnectFAs.add(BigInteger.ONE);
				disconFA = ((FieldActivity_Id)disconnectFACurrentPremise.getId("FA_ID", FieldActivity.class)).getEntity();
				
				if(earliestDisconnectDate.compareTo(disconFA.getScheduleDateTimeStart().getDate()) > 0){
					earliestDisconnectDate = disconFA.getScheduleDateTimeStart().getDate();
				}
				
				if(retrieveReconnectAdjForPerson(earliestDisconnectDate).compareTo(noOfDisconnectFAs) < 0){
					// KL20130920 - End of fix for IM-035783
					disconnectSaSp = (ServiceAgreementServicePoint)disconnectFACurrentPremise.getEntity("SA_SP_ID", ServiceAgreementServicePoint.class);

					/* Start - Fix for Defect 691 - KL20130507 : New Requirement */
					// Person1 had voluntarily disconnected from SP1, followed by Person2 starting and stopping service at the same SP1.
					// Now, if Person1 again starts service on the same SP1, then this is considered as a new service initiation.
					// Person1 will be charged only $25 (Adjustment Type 1). 
					// In case Person1 is Landlord, then this charge also should not be charged.
					
					if(!hadAnotherServiceInitiatedAndStopped(disconnectSaSp)){
						applyAdjType2 = true;
					}
				}
			}
		}
		//Start Add JVitug -  D - 398163 - 2022-04-06
		//Check if the latest stop activity linked to the account is a Stop FA type that should always
		//charge a reconnection fee. If it is, set applyAdjType2 to true
		if(applyAdjType2 == false && shouldStillChargeReconFeeBasedOnLastFAStopActivity()) {
			applyAdjType2 = true;
		}
		
		//End Add JVitug -  D - 398163 - 2022-04-06
		if(applyAdjType2){
			Adjustment adjustment = createStartServiceAdjustment(currentSA, parmStartServiceAdjType2);
			createPremiseCharOnAdj(adjustment, currentPremise.getId().getTrimmedValue());
			// Start TIR 5
			/*FinancialTransaction_Id ftId = getFinancialTransaction(adjustment.getId());
              	createFtIdCharOnFA(ftId.getTrimmedValue());*/
			createAdjIdCharOnFA(adjustment.getId().getTrimmedValue());
			// End TIR 5
			return true;
		}
		return false;
	}


	private SQLResultRow getFAForGivenChar(CharacteristicTypeLookup charTypeLookup, String charVal, BigInteger numDays){

		SQLResultRow resultRow = null;
		StringBuilder getDisconnectFAsString = new StringBuilder();

		getDisconnectFAsString.append("SELECT SA.SA_ID, SASP.SA_SP_ID, FA.FA_ID ");
		getDisconnectFAsString.append("FROM CI_ACCT_PER AP1, CI_SA SA, CI_SP SP, CI_SA_SP SASP, CI_SA_TYPE SATY, ");
		getDisconnectFAsString.append("CI_SA_SP_FA SASPFA, CI_FA FA, CI_FA_TYPE_CHAR FATYCH ");
		getDisconnectFAsString.append("	WHERE AP1.MAIN_CUST_SW = :yes AND AP1.PER_ID = :currentMainPerson ");
		getDisconnectFAsString.append("	AND AP1.ACCT_ID = SA.ACCT_ID AND SA.SA_ID = SASP.SA_ID ");
		getDisconnectFAsString.append("	AND SASP.SP_ID = SP.SP_ID AND SP.PREM_ID = :currentPremise ");
		// KL20130617 - Start of defect fix for 691
		getDisconnectFAsString.append("	AND SASP.SA_SP_ID = SASPFA.SA_SP_ID AND SASPFA.SA_SP_FA_TYPE_FLG IN (:stopActivity, :severanceActivity) ");
		// KL20130617 - End of defect fix for 691
		getDisconnectFAsString.append("	AND SASPFA.FA_ID = FA.FA_ID AND FA.FA_TYPE_CD = FATYCH.FA_TYPE_CD ");
		getDisconnectFAsString.append("	AND FATYCH.CHAR_TYPE_CD = :serviceHistFACharType ");
		if(charTypeLookup.isPredefinedValue()){
		    // CCB v2.6 Upgrade - 2018-07-25 - Start Change
			//getDisconnectFAsString.append("AND TRIM(FATYCH.CHAR_VAL) = :charVal ");
		    getDisconnectFAsString.append("AND FATYCH.CHAR_VAL = :charVal ");
			// CCB v2.6 Upgrade - 2018-07-25 - End Change
		}else if(charTypeLookup.isForeignKeyValue()){
		    // CCB v2.6 Upgrade - 2018-07-25 - Start Change
			//getDisconnectFAsString.append("AND TRIM(FATYCH.CHAR_VAL_FK1) = :charVal ");
		    getDisconnectFAsString.append("AND FATYCH.CHAR_VAL_FK1 = :charVal ");
			// CCB v2.6 Upgrade - 2018-07-25 - End Change
		}else if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()){
		    // CCB v2.6 Upgrade - 2018-07-25 - Start Change
			//getDisconnectFAsString.append("AND TRIM(FATYCH.ADHOC_CHAR_VAL) = :charVal ");
		    getDisconnectFAsString.append("AND FATYCH.ADHOC_CHAR_VAL = :charVal ");
			// CCB v2.6 Upgrade - 2018-07-25 - End Change
		}
		getDisconnectFAsString.append("	AND FATYCH.SEQ_NUM = (SELECT MAX(SEQ_NUM) FROM CI_FA_TYPE_CHAR ");
		getDisconnectFAsString.append("							WHERE FA_TYPE_CD = FATYCH.FA_TYPE_CD AND CHAR_TYPE_CD = FATYCH.CHAR_TYPE_CD) ");
		getDisconnectFAsString.append("	AND FA.FA_STATUS_FLG = :complete AND FA.SCHED_DTTM BETWEEN :historicPeriodStartDttm AND :processingDttm ");
		getDisconnectFAsString.append("	AND SA.SA_TYPE_CD = SATY.SA_TYPE_CD AND SATY.SVC_TYPE_CD IN  (:utilityServiceType1 ");
		if(notNull(parmUtilityServiceType2)){
			getDisconnectFAsString.append(",:utilityServiceType2 ");
		}
		getDisconnectFAsString.append(") ");
		getDisconnectFAsString.append("	ORDER BY SASP.STOP_DTTM DESC");

		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement hasDisconnectFAsPrepStmt = createPreparedStatement(getDisconnectFAsString.toString());
		PreparedStatement hasDisconnectFAsPrepStmt = createPreparedStatement(getDisconnectFAsString.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        hasDisconnectFAsPrepStmt.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
		hasDisconnectFAsPrepStmt.bindBoolean("yes", Bool.TRUE);
		hasDisconnectFAsPrepStmt.bindId("currentMainPerson", currentMainPerson.getId());
		hasDisconnectFAsPrepStmt.bindId("currentPremise", currentPremise.getId());
		hasDisconnectFAsPrepStmt.bindLookup("stopActivity", ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
		// KL20130617 - Start of defect fix for 691
		hasDisconnectFAsPrepStmt.bindLookup("severanceActivity", ServiceAgreementSpFaTypeLookup.constants.SEVERANCE_ACTIVITY);
		// KL20130617 - End of defect fix for 691
		hasDisconnectFAsPrepStmt.bindId("serviceHistFACharType", parmServiceHistoryFACharType.getId());
		if(charTypeLookup.isPredefinedValue()){
			hasDisconnectFAsPrepStmt.bindStringProperty("charVal", ServiceAgreementCharacteristic.properties.characteristicValue ,charVal.trim());
		}else if(charTypeLookup.isForeignKeyValue()){
			hasDisconnectFAsPrepStmt.bindStringProperty("charVal", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1 ,charVal.trim());
		}else if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()){
			hasDisconnectFAsPrepStmt.bindStringProperty("charVal", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue ,charVal.trim());
		}
		hasDisconnectFAsPrepStmt.bindLookup("complete", FieldActivityStatusLookup.constants.COMPLETED);
		hasDisconnectFAsPrepStmt.bindDateTime("historicPeriodStartDttm", getProcessDateTime().subtract(new TimeInterval(0, numDays.longValue(), 0, 0, 0)));
		hasDisconnectFAsPrepStmt.bindDateTime("processingDttm", getProcessDateTime());
		hasDisconnectFAsPrepStmt.bindId("utilityServiceType1", parmUtilityServiceType1.getId());
		if(notNull(parmUtilityServiceType2)){
			hasDisconnectFAsPrepStmt.bindId("utilityServiceType2", parmUtilityServiceType2.getId());
		}
		if(!hasDisconnectFAsPrepStmt.list().isEmpty()){
			resultRow = hasDisconnectFAsPrepStmt.firstRow();
		}
		//List<SQLResultRow> list = getDisconServiceAtOtherPremPrepStmt.list();
		hasDisconnectFAsPrepStmt.close();
		return resultRow;
	}
	
	//Start Add JVitug - D - 398163 - 2022-04-06
	/**
	 * This function will check the latest Stop Activity FA that was completed
	 * linked to the latest SA/SP Record for the person being processed.
	 * If the FA type of the latest FA is equal to the Stop FA Type where we always
	 * charge a reconnection fee , return true as we must charge a reconnection fee. 
	 * Otherwise , return false
	 * @return
	 */
	private boolean shouldStillChargeReconFeeBasedOnLastFAStopActivity() {
		boolean shouldChargeReconFee = false;
		
		StringBuilder stringSql = new StringBuilder();

		stringSql.append("SELECT ");
		//Start Add JVitug - D - 03200 - 2022-05-13
		stringSql.append(   "SASP.SA_ID, ");
		//End Add JVitug - D - 03200 - 2022-05-13
		stringSql.append(   "SASP.STOP_DTTM, ");
		stringSql.append(   "FA.SCHED_DTTM, ");
		stringSql.append(   "FA.FA_ID ");
		stringSql.append("FROM ");
		stringSql.append(   "CI_ACCT_PER AP1, ");
		stringSql.append(   "CI_SA SA, "); 
		stringSql.append(   "CI_SP SP, "); 
		stringSql.append(   "CI_SA_SP SASP, "); 
		stringSql.append(   "CI_SA_TYPE SATY, ");
		stringSql.append(   "CI_SA_SP_FA SASPFA, "); 
		stringSql.append(   "CI_FA FA ");
		stringSql.append("WHERE ");
		stringSql.append(   "AP1.MAIN_CUST_SW = :yes ");
		stringSql.append("AND ");
		stringSql.append("  AP1.PER_ID = :currentMainPerson ");
		stringSql.append("AND ");
		stringSql.append(   "AP1.ACCT_ID = SA.ACCT_ID ");
		stringSql.append("AND ");
		stringSql.append(   "SA.SA_ID = SASP.SA_ID ");
		stringSql.append("AND ");
		stringSql.append(   "SASP.SP_ID = SP.SP_ID ");
		//Start Delete JVitug - D - 03200 - 2022-05-10
		//stringSql.append("AND ");
		//stringSql.append(   "SP.PREM_ID = :currentPremise ");
		//End Delete JVitug - D - 03200 - 2022-015-10
		stringSql.append("AND "); 
		stringSql.append(   "SASP.SA_SP_ID = SASPFA.SA_SP_ID ");
		stringSql.append("AND ");
		stringSql.append(   "SASPFA.SA_SP_FA_TYPE_FLG IN (:stopActivity, :severanceActivity, :startActivity) ");
		stringSql.append("AND ");
		stringSql.append(   "SASPFA.FA_ID = FA.FA_ID ");
		stringSql.append("AND ");
		stringSql.append(   "FA.FA_STATUS_FLG = :complete ");
		stringSql.append("AND ");
		stringSql.append(   "SA.SA_TYPE_CD = SATY.SA_TYPE_CD " );
		stringSql.append("AND ");
		stringSql.append(   "FA.FA_ID != :currentFAId ");
        stringSql.append("AND ");
		stringSql.append(   "SATY.SVC_TYPE_CD IN  (:utilityServiceType1 ");
		
		if(notNull(parmUtilityServiceType2)){
			stringSql.append(" ,:utilityServiceType2 ");
		}
		stringSql.append(") ");
		stringSql.append("AND NOT EXISTS ");
		stringSql.append("( SELECT 1 FROM CI_FA WHERE fa_type_cd = 'M-RECON' and sp_id = sp.sp_id and sched_dttm >= fa.sched_dttm) ");
		stringSql.append("ORDER BY FA.SCHED_DTTM DESC ");
		// 2024-11-16   Kiran   INC0031998 Include Reconnect Activity for the most recent FA
		PreparedStatement sql = createPreparedStatement(stringSql.toString(), getClass().getName());
		sql.bindBoolean("yes", Bool.TRUE);
		sql.bindId("currentMainPerson", currentMainPerson.getId());
		//Start Delete JVitug - D - 03200 - 2022-05-10
		//sql.bindId("currentPremise", currentPremise.getId());
		//End Delete JVitug - D - 03200 - 2022-05-10
		sql.bindLookup("startActivity", ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
		sql.bindLookup("stopActivity", ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
		sql.bindLookup("severanceActivity", ServiceAgreementSpFaTypeLookup.constants.SEVERANCE_ACTIVITY);
		sql.bindLookup("complete", FieldActivityStatusLookup.constants.COMPLETED);
		sql.bindId("currentFAId", parmFieldActivity.getId());
		
		sql.bindId("utilityServiceType1", parmUtilityServiceType1.getId());
		
		if(notNull(parmUtilityServiceType2)) {
			sql.bindId("utilityServiceType2", parmUtilityServiceType2.getId());
		}
		
		SQLResultRow result = sql.firstRow();
		sql.close();
		
		if(notNull(result)) {
			FieldActivity latestStopActivityFAForPremise = result.getEntity("FA_ID", FieldActivity.class);
			
			if(latestStopActivityFAForPremise.getFieldActivityType().getId().compareTo(alwaysChargeReconFeeStopFAType.getId()) == 0) {
				shouldChargeReconFee = true; 
			}
			//Start Add JVitug - D - 03200 - 2022-05-13
			else if(latestStopActivityFAForPremise.getFieldActivityType().getId().compareTo(stopFAType.getId()) == 0){
				//If the Stop FA type is equal to the Stop FA Type which is M-STOP, check if the premise of the FA's SP is equal to the SA's characteristic premise.
				//If yes, return true
				Premise premiseLinkedToLatestStopActivity = latestStopActivityFAForPremise.getServicePoint().getPremise();
				ServiceAgreement stopSALinkedToStopFA = result.getEntity("SA_ID", ServiceAgreement.class);
				Date endDateAfter365Days = stopSALinkedToStopFA.getEndDate().addDays(365);
				Date faScheduleDate = parmFieldActivity.getScheduleDateTimeStart().getDate();
				
				if(currentSA.fetchPremise().getId().compareTo(premiseLinkedToLatestStopActivity.getId()) == 0 && endDateAfter365Days.isSameOrAfter(faScheduleDate)) {
					shouldChargeReconFee = true;
				}
					
			}
			//End Add JVitug - D - 03200 - 2022-05-13
		}
		
		return shouldChargeReconFee;
	}
	//End Add JVitug - D - 398163 - 2022-04-06

	/**
	 * Check if the person with the current account had voluntarily disconnected a service 
	 * and if someone else had the service initiated in between
	 * @param disconnectSaSp
	 * @return
	 */
	private boolean hadAnotherServiceInitiatedAndStopped(ServiceAgreementServicePoint disconnectSaSp){
		boolean hasInbetweenService = false;
		StringBuilder retrieveServiceStr = new StringBuilder();

		//KL20130607 - Start of defect fix for 1781
		retrieveServiceStr.append("SELECT 'X' FROM CI_SP SP, CI_SA_SP SASP, CI_SP_TYPE SPTYP ");
		retrieveServiceStr.append("WHERE SP.SP_ID = SASP.SP_ID AND SP.PREM_ID = :currentPremise ");
		retrieveServiceStr.append("AND SP.SP_TYPE_CD = SPTYP.SP_TYPE_CD AND SPTYP.SVC_TYPE_CD IN  (:utilityServiceType1 ");
		if(notNull(parmUtilityServiceType2)){
			retrieveServiceStr.append(",:utilityServiceType2 ");
		}
		//KL20131024 - Start Fix for IM-035787
		retrieveServiceStr.append(") AND SASP.START_DTTM >= :prevDisconServiceStopDttm ");
		//KL20131024 - End Fix for IM-035787
		retrieveServiceStr.append("AND SASP.STOP_DTTM IS NOT NULL AND SASP.STOP_DTTM < :processingDttm ");

		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement retServicePrepStmt = createPreparedStatement(retrieveServiceStr.toString());
		PreparedStatement retServicePrepStmt = createPreparedStatement(retrieveServiceStr.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        retServicePrepStmt.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
		retServicePrepStmt.bindId("currentPremise", currentPremise.getId());
		retServicePrepStmt.bindId("utilityServiceType1", parmUtilityServiceType1.getId());
		if(notNull(parmUtilityServiceType2)){
			retServicePrepStmt.bindId("utilityServiceType2", parmUtilityServiceType2.getId());
		}
		retServicePrepStmt.bindDateTime("prevDisconServiceStopDttm", disconnectSaSp.getStopDateTime());
		retServicePrepStmt.bindDateTime("processingDttm", getProcessDateTime());

		/*
		 **
		 * KL20130607 - Commented out as part of defect fix for 1781
		 * 
		retrieveServiceStr.append("SELECT 'X' FROM CI_SA_SP SASP, CI_SA SA, CI_SA_SP_FA SSF, CI_FA FA, CI_FA_TYPE_CHAR FACH ");
		retrieveServiceStr.append("		WHERE SASP.SA_ID = SA.SA_ID AND SASP.SA_SP_ID = SSF.SA_SP_ID AND SSF.FA_ID = FA.FA_ID ");
		retrieveServiceStr.append("			AND FA.FA_TYPE_CD = FACH.FA_TYPE_CD AND FACH.CHAR_TYPE_CD = :characteristicType ");
		retrieveServiceStr.append("				AND SASP.SP_ID = :currentSP "); 
		if(charTypeLookup.isPredefinedValue()){
			retrieveServiceStr.append("AND TRIM(FACH.CHAR_VAL) = :charValue ");
		}else if(charTypeLookup.isForeignKeyValue()){
			retrieveServiceStr.append("AND TRIM(FACH.CHAR_VAL_FK1) = :charValue ");
		}else if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()){
			retrieveServiceStr.append("AND TRIM(FACH.ADHOC_CHAR_VAL) = :charValue ");
		}
		retrieveServiceStr.append("					AND SA.ACCT_ID = :currentAccount AND SSF.SA_SP_FA_TYPE_FLG = :stopActivity ");
		retrieveServiceStr.append("						AND SASP.STOP_DTTM IS NOT NULL AND SASP.STOP_DTTM < :prevSASPStopDTTM ");

		PreparedStatement retServicePrepStmt = createPreparedStatement(retrieveServiceStr.toString());
		retServicePrepStmt.bindId("characteristicType", parmServiceHistoryFACharType.getId());
		if(charTypeLookup.isPredefinedValue()){
			retServicePrepStmt.bindStringProperty("charValue", ServiceAgreementCharacteristic.properties.characteristicValue ,parmVoluntaryDisconnectCharValue.trim());
		}else if(charTypeLookup.isForeignKeyValue()){
			retServicePrepStmt.bindStringProperty("charValue", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1 ,parmVoluntaryDisconnectCharValue.trim());
		}else if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()){
			retServicePrepStmt.bindStringProperty("charValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue ,parmVoluntaryDisconnectCharValue.trim());
		}
		retServicePrepStmt.bindId("currentSP", disconnectSaSp.getServicePoint().getId());
		retServicePrepStmt.bindId("currentAccount", currentSA.getAccount().getId());
		retServicePrepStmt.bindLookup("stopActivity", ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
		retServicePrepStmt.bindDateTime("prevSASPStopDTTM", disconnectSaSp.getStopDateTime());
		 **/
		// KL20130607 - End of Defect Fix for 1781
		if(!retServicePrepStmt.list().isEmpty()){
			hasInbetweenService = true;
		}
		retServicePrepStmt.close();
		return hasInbetweenService;
	}
	
	// START DELETE - JHERNA - 2015-06-29 - 3241226
	// As per Lynette, no error / to do needs to be created, simply exit the algorithm without creating any adjustments
	///**
	// * @return void 
	// *  This method creates todo.
	// * 
	// */
	/*
	private void createToDoEntry(){
		ToDoEntry_DTO entryDto  = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
		ToDoType toDoType = parmToDoType.getId().getEntity();

		entryDto.setToDoTypeId(toDoType.getId());
		entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
		entryDto.setToDoPriority(toDoType.getToDoPriority());
		entryDto.setToDoRoleId(getDefaultToDoRole().getId());
		entryDto.setCreationDateTime(getProcessDateTime());
		entryDto.setToDoPriority(toDoType.getToDoPriority());

		ArrayList<ToDoSortKeyValue_DTO>sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();
		ToDoTypeSortKeyTypes sortKeyTypes = toDoType.getSortKeyTypes();

		for (Iterator<ToDoSortKeyType> iter = sortKeyTypes.iterator(); iter.hasNext();) {
			ToDoSortKeyType sortKeyType = (ToDoSortKeyType) iter.next();
			ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
			BigInteger seq = sortKeyType.fetchIdSequence();
			sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));

			if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(1))==0){
				sortKeyDto.setKeyValue(parmFieldActivity.getCreationDateTime().toString());
			}
			sortKeyList.add(sortKeyDto);
		}

		ArrayList<ToDoDrillKeyValue_DTO>drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
		ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO)     createDTO(ToDoDrillKeyValue.class);
		ToDoDrillKeyType drillKeyType = (ToDoDrillKeyType) toDoType.getDrillKeyTypes().iterator().next();
		BigInteger sequence = drillKeyType.fetchIdSequence();
		drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, sequence));

		drillKeyDto.setKeyValue(parmFieldActivity.getId().getTrimmedValue());
		drillKeyList.add(drillKeyDto);



		MessageCategory_Id msgCatId = new MessageCategory_Id(BigInteger.valueOf(CustomMessageRepository.MESSAGE_CATEGORY));
		Message_Id msgId = new Message_Id(msgCatId, BigInteger.valueOf(CustomMessageRepository.NA0073_NO_ELIG_SA_ASSOCIATED_TO_SP_OF_FA));
		entryDto.setMessageId(msgId);


		ArrayList <String> messageParameterList = new ArrayList<String> ();
		messageParameterList.add(0,parmFieldActivity.getId().getTrimmedValue());
		ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory.newInstance();

		toDoEntryData.setDrillKeys(drillKeyList);
		toDoEntryData.setEntryDto(entryDto);
		toDoEntryData.setSortKeys(sortKeyList);
		toDoEntryData.setMessageParams(messageParameterList);
		ArrayList <ToDoEntryCharacteristic_DTO>  charList = new ArrayList<ToDoEntryCharacteristic_DTO> ();
		toDoEntryData.setToDoCharacteristics(charList);

		ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
		toDoProcessor.addToDo(toDoEntryData);

	}
	*/

	///**
	// * @return Role 
	// * This method fetches the Default Role to create a TODO
	// * 
	// */ 
	/*
	private Role getDefaultToDoRole(){
		Role defaultRole = null;
		StringBuilder defaultRoleQueryString = new StringBuilder();
		defaultRoleQueryString.append("SELECT ROLE_ID FROM CI_TD_VAL_ROLE WHERE TD_TYPE_CD = :toDoType AND DEFAULT_SW = :yes ");

		PreparedStatement defaultRolePrepStmt = createPreparedStatement(defaultRoleQueryString.toString()); 
		defaultRolePrepStmt.bindId("toDoType", parmToDoType.getId()); 
		defaultRolePrepStmt.bindBoolean("yes", Bool.TRUE);
		defaultRole = defaultRolePrepStmt.firstRow().getEntity("ROLE_ID", Role.class);
		defaultRolePrepStmt.close();
		return defaultRole;
	}
	*/
	// END DELETE - JHERNA - 2015-06-29 - 3241226
	
	// KL20130920 - Start of fix for IM-035783
	private BigInteger retrieveReconnectAdjForPerson(Date disconnectDate){
		BigInteger count = BigInteger.ZERO;

		StringBuilder getReconAdjQueryString = new StringBuilder();
		getReconAdjQueryString.append("SELECT COUNT(1) AS CNT FROM CI_ACCT_PER AP1, CI_SA SA, CI_ADJ ADJ ");
		getReconAdjQueryString.append("WHERE AP1.MAIN_CUST_SW = :yes AND AP1.PER_ID = :currentMainPerson ");
		getReconAdjQueryString.append("AND AP1.ACCT_ID = SA.ACCT_ID AND SA.SA_ID = ADJ.SA_ID ");
		getReconAdjQueryString.append("AND ADJ.ADJ_TYPE_CD = :reconAdjFee AND ADJ.ADJ_STATUS_FLG = :frozen ");
		getReconAdjQueryString.append("AND ADJ.CRE_DT >= :disconnectDate ");
		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement getReconAdjQueryPrepStmt = createPreparedStatement(getReconAdjQueryString.toString());
		PreparedStatement getReconAdjQueryPrepStmt = createPreparedStatement(getReconAdjQueryString.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        getReconAdjQueryPrepStmt.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
		getReconAdjQueryPrepStmt.bindId("currentMainPerson", currentMainPerson.getId()); 
		getReconAdjQueryPrepStmt.bindBoolean("yes", Bool.TRUE);
		getReconAdjQueryPrepStmt.bindId("reconAdjFee", parmStartServiceAdjType2.getId());
		getReconAdjQueryPrepStmt.bindLookup("frozen", AdjustmentStatusLookup.constants.FROZEN);
		getReconAdjQueryPrepStmt.bindDate("disconnectDate", disconnectDate);

		count = getReconAdjQueryPrepStmt.firstRow().getInteger("CNT");
		getReconAdjQueryPrepStmt.close();

		return count;
	}
	// KL20130920 - End of fix for IM-035783
	// START ADD - JHERNA - 2015-04-22 - DEFECT#3122894
	//private ServiceAgreement cmCheckIfBackToBackReversion() {
	private Bool cmCheckIfBackToBackReversion() {
		//ServiceAgreement returnValue = null;
		Bool returnValue = Bool.FALSE;
		/* Premise has a landlord agreement (LLA) and either start or stop SA is linked to the account referenced on the LLA.
		 * If so, create an adjustment on the start SA using the adjustment type specified on the 
		 * Start Service Adjustment Type (Landlord Reversion) parameter.
		 */
		StringBuilder stringBuilder = new StringBuilder();				
		stringBuilder.append("SELECT SASPFA.SA_ID, SASPFA.SA_SP_FA_TYPE_FLG ");
		stringBuilder.append("FROM CI_SA_SP_FA SASPFA, CI_FA FA, CI_SA SA, CI_SP SP, CI_PREM PREM, CI_LANDLORD LL ");
		stringBuilder.append("WHERE SASPFA.SA_SP_FA_TYPE_FLG IN (:start, :stop) ");
		stringBuilder.append("AND FA.FA_ID = SASPFA.FA_ID ");
		stringBuilder.append("AND FA.FA_ID = :currentFA ");
		//stringBuilder.append("AND FA.FA_STATUS_FLG != :cancel ");
		stringBuilder.append("AND SP.SP_ID = FA.SP_ID ");
		stringBuilder.append("AND PREM.PREM_ID = :premID ");
		stringBuilder.append("AND PREM.PREM_ID = SP.PREM_ID ");
		stringBuilder.append("AND LL.LL_ID = PREM.LL_ID ");
		stringBuilder.append("AND SA.SA_ID= SASPFA.SA_ID ");
		stringBuilder.append("AND SA.ACCT_ID = LL.ACCT_ID ");
		stringBuilder.append("ORDER BY FA.CRE_DTTM DESC ");
		
		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        prepState.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
		prepState.bindLookup("start", ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
		prepState.bindLookup("stop", ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
		//prepState.bindLookup("cancel", FieldActivityStatusLookup.constants.CANCELED);
		prepState.bindId("currentFA", parmFieldActivity.getId());
		prepState.bindId("premID", currentPremise.getId());
		prepState.execute();
		
		if (prepState.list().size() > 0) {
			
			/*
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			ServiceAgreement_Id saID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
			returnValue = saID.getEntity();
			*/
			// return true only if this is not the first time that the landlord is moving into the house.
			StringBuilder stringBuilder2 = new StringBuilder();
			stringBuilder2.append("SELECT UNIQUE(SASP.SA_ID) ");
			stringBuilder2.append("FROM CI_SA_SP SASP ");
			stringBuilder2.append("WHERE SASP.SP_ID = :spID ");
			//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
			//PreparedStatement prepState2 = createPreparedStatement(stringBuilder2.toString());
			PreparedStatement prepState2 = createPreparedStatement(stringBuilder2.toString(), getClass().getName());
			//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
            // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
            prepState2.setAutoclose(false);
            // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
			prepState2.bindId("spID", parmFieldActivity.getServicePoint().getId());
			prepState2.execute();
			
			if (prepState2.list().size() > 1) {
				returnValue = Bool.TRUE;		
			}
			prepState2.close();		
		}
		
		prepState.close();				
		return returnValue;
	}
	
	// END ADD - JHERNA - 2015-04-22 - DEFECT#3122894
}