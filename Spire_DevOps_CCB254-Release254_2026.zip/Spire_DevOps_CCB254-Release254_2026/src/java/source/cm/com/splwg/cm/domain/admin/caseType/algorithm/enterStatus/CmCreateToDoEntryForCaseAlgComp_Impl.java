/**************************************************************************
* Program Name: CmCreateToDoEntryForCaseAlgComp_Impl
* Program Title: CmCreateToDoEntryForCaseAlgComp_Impl
* Author: Aya Masilang
* Creation Date: 2017-08-18
* Purpose: This algorithm is a clone of the base Algorithm Create To Do 
*          Entry - Create To Do Entry (CSEN-TD) and will be modified to 
*          add the logic of retrieving the current case's long comment 
*          value and setting this as the value for the To Do 
*          Entry's comment when creating the To Do.
* Functional Spec: SA-218915
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  SA-218915         Aya Masilang     2017-08-18    Initial Version.
 ************************************************************************************************/
package com.splwg.cm.domain.admin.caseType.algorithm.enterStatus;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.message.MessageCategory;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.role.Role_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_Id;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeSortKeyTypes;
import com.splwg.ccb.api.lookup.CaseLogTypeLookup;
import com.splwg.ccb.domain.admin.caseType.algorithm.enterStatus.EnterStatusAlgorithmSpot;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatusTransitionRule;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatusTransitionRules;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.todo.common.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.data.ToDoMaintenanceData;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author AMasil
 *
 * @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = toDoRole, type = string)
 *            , @AlgorithmSoftParameter (name = assignToRole, type = string)
 *            , @AlgorithmSoftParameter (entityName =  characteristicType, name = characteristicType, required = false, type = entity)
 *            , @AlgorithmSoftParameter (entityName =  messageCategory, name = messageCategory, required = false, type = entity)
 *            , @AlgorithmSoftParameter ( name = messageNumber, required = false, type = integer)
 *            , @AlgorithmSoftParameter (name = nextStatus, required = false, type = string)
 *            , @AlgorithmSoftParameter (name = nextTransCond, required = false, type = string)})
 */
public class CmCreateToDoEntryForCaseAlgComp_Impl extends
        CmCreateToDoEntryForCaseAlgComp_Gen implements EnterStatusAlgorithmSpot {

    //~ Static fields/initializers ---------------------------------------------------------------------------

    private static final String ASSIGN = "R";

    //~ Instance fields --------------------------------------------------------------------------------------

    private Account account;
    private ToDoCase toDoCase;
    private Role toDoRole;
    private ToDoType toDoType;
    private ToDoEntry_DTO entryDto;
    private List<ToDoSortKeyValue_DTO> sortKeyList;
    private List<ToDoDrillKeyValue_DTO> drillKeyList;
    private CharacteristicType caseChar;
    private List<String> messageParameterList;
    private List<ToDoEntryCharacteristic_DTO> charList;
    private MessageCategory msgCategory;
    private BigInteger msgNbr;
    private CharacteristicType charType;

    //~ Methods ----------------------------------------------------------------------------------------------

    public void setCase(ToDoCase toDoCase) {
        this.toDoCase = toDoCase;
    }

    public void setCaseOriginalStatus(CaseStatus caseStatus) {
    }

    public void invoke() {

        validateCharacteristicType();
        validateNextStatusNextTransitionCombination();

        setInput();
        entryDto = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
        entryDto.setToDoTypeId(toDoType.getId());
        entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
        entryDto.setToDoPriority(toDoType.getToDoPriority());
        entryDto.setMessageId(toDoType.getMessageId());
        entryDto.setComments(toDoCase.getLongComments());

        if (toDoRole != null) entryDto.setToDoRoleId(toDoRole.getId());
        if (!isBlankOrNull(getAssignToRole())) {
            if (getAssignToRole().trim().equals(ASSIGN) && toDoCase.getUserId() != null) {
                entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.BEING_WORKED_ON);
                entryDto.setAssignedToUserId(toDoCase.getUserId());
            }
        }

        createSortKeyList();
        createDrillKeyList();
        createMessageParameters();
        createToDoCharacteristics();
        ToDoEntry toDoEntry = addToDoEntry();
        addCaseLogEntry(toDoEntry);
    }

    /**
     * This method adds the Case Log Entry
     */
    private void addCaseLogEntry(ToDoEntry toDoEntry) {
        CaseLogTypeLookup caseLogType = CaseLogTypeLookup.constants.SYSTEM;

        if (msgCategory != null && msgNbr != null && charType != null) {
            toDoCase.createCaseLogEntry(caseLogType, msgCategory, msgNbr, charType, toDoEntry);
        }
    }

    /**
     * This method setup the Input values
     */
    private void setInput() {
        toDoType = getToDoType();

        caseChar = toDoType.getCaseFKCharType();
        if (caseChar == null) {
            addError(CustomMessageRepository.SA_218915_fieldMissing("CHAR_TYPE_CD"));
        }

        setupToDoRole();
    }

    /**
     * This method setups the To Do Role
     */
    private void setupToDoRole() {
        String role = getToDoRole();
        if (isBlankOrNull(role)) {
            account = toDoCase.fetchAccount();
            if (account != null) {
                toDoRole = toDoType.getDefaultRoleForAccount(account);
            }
        } else {
            Role_Id roleId = new Role_Id(role);
            toDoRole = roleId.getEntity();
            if (toDoRole == null) {
                addError(CustomMessageRepository.SA_218915_todoRoleInvalid(toDoType.getId().getIdValue(), role));
            }
        }
    }

    /**
     * This method creates the To Do Characteristics
     */
    private void createToDoCharacteristics() {
        charList = new ArrayList<ToDoEntryCharacteristic_DTO>();

        ToDoEntryCharacteristic_DTO charDto = (ToDoEntryCharacteristic_DTO) createDTO(ToDoEntryCharacteristic.class);
        charDto.setId(new ToDoEntryCharacteristic_Id(ToDoEntry_Id.NULL, caseChar.getId(), BigInteger.ONE));
        charDto.setCharacteristicValueForeignKey1(toDoCase.getId().getIdValue());

        charList.add(charDto);
    }

    /**
     * This method creates To Do Entry
     * @return ToDoEntry
     */
    private ToDoEntry addToDoEntry() {
        ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory.newInstance();
        toDoEntryData.setDrillKeys(drillKeyList);
        toDoEntryData.setEntryDto(entryDto);
        toDoEntryData.setMessageParams(messageParameterList);
        toDoEntryData.setToDoCharacteristics(charList);
        toDoEntryData.setSortKeys(sortKeyList);
        ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
        return toDoProcessor.addToDo(toDoEntryData);
    }

    /**
     * This method creates Message Parameters
     */
    private void createMessageParameters() {
        messageParameterList = new ArrayList<String>();
        messageParameterList.add(toDoCase.getCaseStatus().fetchIdCaseType().fetchLanguageDescription());
        messageParameterList.add(toDoCase.getCaseStatus().fetchLanguageStatusLabel());
        if (toDoCase.fetchUser() != null) messageParameterList.add(toDoCase.fetchUser().getFullName());
        if (toDoCase.fetchPerson() != null) messageParameterList.add(toDoCase.fetchPerson().getPersonPrimaryName());
        if (toDoCase.fetchPremise() != null) messageParameterList.add(toDoCase.fetchPremise().getAddress1());
    }

    /**
     * This method creates the To Do Drill Key List
     */
    private void createDrillKeyList() {
        drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
        ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO) createDTO(ToDoDrillKeyValue.class);

        ToDoDrillKeyType drillKeyType = toDoType.getDrillKeyTypes().iterator().next();
        BigInteger sequence = drillKeyType.fetchIdSequence();
        drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, sequence));
        drillKeyDto.setKeyValue(toDoCase.getId().getIdValue());
        drillKeyList.add(drillKeyDto);
    }

    /**
     * This method creates the To Do Sort Key List
     */
    private void createSortKeyList() {
        sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();

        ToDoTypeSortKeyTypes sortKeyTypes = toDoType.getSortKeyTypes();
        int i = 0;
        for (Iterator iter = sortKeyTypes.iterator(); iter.hasNext();) {
            i++;
            ToDoSortKeyType sortKeyType = (ToDoSortKeyType) iter.next();
            ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
            BigInteger seq = sortKeyType.fetchIdSequence();
            sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));
            if (i == 1) {
                //Sort Key 1 - Case Creation Date
                sortKeyDto.setKeyValue(toDoCase.getLogCreateDateTime().toLocalizedString());
            }
            if (i == 2) {
                //Sort Key 2 - Case Status Code
                sortKeyDto.setKeyValue(toDoCase.getCaseStatus().fetchIdStatus());
            }
            if (i == 3) {
                //Sort Key 3 - Person Id
                if (toDoCase.fetchPerson() != null) {
                    sortKeyDto.setKeyValue(toDoCase.fetchPerson().getPersonPrimaryName());
                }
            }
            if (i == 4) {
                //Sort Key 4 - Premise Address1
                if (toDoCase.fetchPremise() != null) sortKeyDto.setKeyValue(toDoCase.fetchPremise().getAddress1());
            }
            sortKeyList.add(sortKeyDto);
        }
    }

    public String getNextCaseStatus() {
        return getNextStatus();
    }

    public String getNextTransCondition() {
        return getNextTransCond();
    }

    public Bool getShouldAutoTransition() {
        if (isBlankOrNull(getNextStatus()) && (isBlankOrNull(getNextTransCond()))) {
            return Bool.FALSE;
        } else {
            return Bool.TRUE;
        }
    }

    /**
     * This method validates the To Do Characteristic Type
     */
    private void validateCharacteristicType() {
        //  If Char Type for Log Entry is populated
        //   Char Type must exist, must be of value type FK and must be linked to an FK reference for the ToDo table
        //   Message Category for Log Entry must be populated and must exist
        //   Message Number for Log Entry must be populated and must exist for the message category

        CharacteristicType characteristicType = getCharacteristicType();

        if (!isNull(characteristicType)) {
            if (!characteristicType.getCharacteristicType().isForeignKeyValue()) {
                //Char Type must be of type Foreign Key
                addError(CustomMessageRepository.SA_218915_charTypeMustBeOfTypeForeignKey(characteristicType.getId().getIdValue()));
            } else {
                if (!characteristicType.fetchForeignKeyReference().getTable().getId().getTrimmedValue().equals(
                        "CI_TD_ENTRY")) {
                    //Char Type should point to an FK reference for the ToDo Entry table
                    addError(CustomMessageRepository.SA_218915_charTypeMustBeValidForToDoEntity(characteristicType.getId().getIdValue()));
                }

                if (isNull(getMessageCategory())) {
                    //Message Category cannot be blank if Char Type is specified.
                    addError(CustomMessageRepository.SA_218915_messageCategoryReqdIfCharTypeSpecified());

                }
                if (isNull(getMessageNumber())) {
                    //Message Number cannot be blank if Char Type is specified.
                    addError(CustomMessageRepository.SA_218915_messageNumberReqdIfCharTypeSpecified());
                }
                validateMessageCategoryMessageNumber();
                charType = characteristicType;
            }
        } else {
            // If Char Type is not specified , message category and message number should be blank.       
            if (!isNull(getMessageCategory())) {
                addError(CustomMessageRepository.SA_218915_messageCategoryNotReqdIfCharTypeNotSpecified());
            }
            if (!isNull(getMessageNumber())) {
                addError(CustomMessageRepository.SA_218915_messageNumberNotReqdIfCharTypeNotSpecified());
            }
        }

    }

    /**
     * This method validates the Message Category Number
     */
    private void validateMessageCategoryMessageNumber() {
        // Check if the Message Category and Message Number combination specified is valid.
        MessageCategory msgCat = getMessageCategory();
        Message_Id msgId = new Message_Id(msgCat, getMessageNumber());

        if (isNull(msgId.getEntity())) {
            addError(CustomMessageRepository.SA_218915_messageCategoryMessageNumberCombinationInvalid(msgCat.getId().getIdValue(),
                    msgId.getMessageNumber()));
        } else {
            msgCategory = msgCat;
            msgNbr = getMessageNumber();
        }

    }

    /**
     * This method validates the Next Status Transition Combination
     */
    private void validateNextStatusNextTransitionCombination() {
        // Next transition status code or next transition condition may be populated, but not both
        String transitionCode = getNextTransCondition();
        String nextCaseStatus = getNextStatus();
        if (!isBlankOrNull(transitionCode) && !isBlankOrNull(nextCaseStatus)) {
            addError(CustomMessageRepository.SA_218915_nextTransitionStatusNextTransitionConditionBothCannotBeSpecified(
                    getNextStatus(), getNextTransCondition()));
        }
        if (!isBlankOrNull(transitionCode)) {
            validateTransitionCondition(transitionCode);
        }
        if (!isBlankOrNull(nextCaseStatus)) {
            validateNextStatus(nextCaseStatus);
        }
    }

    /**
     * This method validates Case Transition Condition
     * @param transitionCondition
     */
    private void validateTransitionCondition(String transitionCondition) {
        Boolean isValidCondition = false;
        int numberOfStatuses = 0;
        CaseStatusTransitionRules rules = toDoCase.getCaseStatus().getTransitionRules();
        for (Iterator iter = rules.iterator(); iter.hasNext();) {
            CaseStatusTransitionRule transitionRule = (CaseStatusTransitionRule) iter.next();
            if (!transitionRule.getTransitionCondition().isBlankLookupValue()) {
                if (transitionRule.getTransitionCondition().getLookupValue().fetchIdFieldValue().trim().equals(
                        transitionCondition)) {
                    isValidCondition = true;
                    numberOfStatuses++;
                }
            }
        }
        if (!isValidCondition) {
            addError(CustomMessageRepository.SA_218915_nextTranstionConditionNotValidForCurrentStatus(transitionCondition));
        } else {
            if (numberOfStatuses > 1) {
                addError(CustomMessageRepository.SA_218915_moreThanOneStatusFoundForNextTranstionCondition(transitionCondition));
            }
        }

    }

    /**
     * This method validates the Case Next Status
     * @param nextStatus
     */
    private void validateNextStatus(String nextStatus) {
        Boolean isValidStatus = false;
        String nextValidStatus = "";
        CaseStatusTransitionRules rules = toDoCase.getCaseStatus().getTransitionRules();
        for (Iterator iter = rules.iterator(); iter.hasNext();) {
            CaseStatusTransitionRule transitionRule = (CaseStatusTransitionRule) iter.next();
            nextValidStatus = transitionRule.fetchIdCaseStatus().fetchIdStatus();
            if (nextValidStatus.trim().equals(nextStatus)) {
                isValidStatus = true;
            }
        }
        if (!isValidStatus) {
            addError(CustomMessageRepository.SA_218915_nextStatusNotValidForCurrentCaseStatus(nextStatus, toDoCase.getCaseStatus()
                    .fetchIdStatus()));
            isValidStatus = false;
        }

    }

    public Bool getShouldCancelTransition() {
        return Bool.FALSE;
    }

}
