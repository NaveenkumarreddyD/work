/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPRRXRX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      NA0027. Initial Version.
 * 2016-06-01   MPang       Defect 3444302. Added connection close.
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.
 * 2025-11-14   EQuint      CCB25.4 Upgrade                        
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.registerRule;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.GenericBusinessComponent;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.datatypes.Time;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.language.Language_Id;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.api.lookup.HowToUseLookup;
import com.splwg.ccb.api.lookup.HowToUseReadLookup;
import com.splwg.ccb.api.lookup.IntervalBillingStartDayOptionLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.data.RegisterRuleComponent;
import com.splwg.ccb.domain.admin.registerRule.entity.RegisterRule;
import com.splwg.ccb.domain.admin.revenueClass.entity.RevenueClass_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentItem_DTO;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentItem_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentRegisterRead_DTO;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentRegisterRead_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity_DTO;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.billing.data.BillSegmentItemData;
import com.splwg.ccb.domain.billing.data.BillSegmentReadData;
import com.splwg.ccb.domain.billing.data.BillSegmentServiceQuantityData;
import com.splwg.ccb.domain.common.data.CharacteristicData;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.item.entity.Item_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead_Id;
import com.splwg.ccb.domain.meterread.usage.entity.Usage_Id;
import com.splwg.ccb.domain.rate.data.ApplyRateData;
import com.splwg.ccb.domain.rate.rateSchedule.entity.RateSchedule_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmprrxrx;

/**
 * @author EQuint
 *
 @BusinessComponent (customizationCallable = true)
 */
public class CmCompareMeterWithTwoRegisterReadsRuleComp_Impl extends
		GenericBusinessComponent implements
		CmCompareMeterWithTwoRegisterReadsRuleComp, RegisterRuleComponent {

	// hard parameters
	private ApplyRateData applyRateData;
	private List<BillSegmentItemData> billSegmentItemDatas = new ArrayList<BillSegmentItemData>();
	private List<BillSegmentReadData> billSegmentReadDatas = new ArrayList<BillSegmentReadData>();
	private List<BillSegmentServiceQuantityData> billSegmentServiceQuantityDatas = new ArrayList<BillSegmentServiceQuantityData>();
	private List<CharacteristicData> characteristicDatas = new ArrayList<CharacteristicData>();
	private RegisterRule registerRule;
	
	private Cmprrxrx cmprrxrx;
	private DateFormat dateFormat = new DateFormat("yyyy-MM-dd");
	private DateFormat dateTimeFormat = new DateFormat("yyyy-MM-dd-HH.mm.ss");
	private DateFormat dateTimeFormat2 = new DateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS");
	private DateFormat timeFormat = new DateFormat("HH.mm.ss");
	
	//Start Add - MPang - Defect 3444302- 2016-06-01
	private Connection connection;
	//End Add - MPang - Defect 3444302- 2016-06-01
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	
	@Override
	public ApplyRateData getApplyRateData() {
		return applyRateData;
	}

	@Override
	public List<BillSegmentItemData> getBillSegmentItemData() {
		return billSegmentItemDatas;
	}

	@Override
	public List<BillSegmentReadData> getBillSegmentReadData() {
		return billSegmentReadDatas;
	}

	@Override
	public List<BillSegmentServiceQuantityData> getBillSegmentServiceQuantityData() {
		return billSegmentServiceQuantityDatas;
	}

	@Override
	public List<CharacteristicData> getCharacteristicData() {
		return characteristicDatas;
	}

	@Override
	public void setApplyRateData(ApplyRateData applyratedata) {
		this.applyRateData = applyratedata;
	}

	@Override
	public void setBillSegmentItemData(List<BillSegmentItemData> list) {
		billSegmentItemDatas = list;
	}

	@Override
	public void setBillSegmentReadData(List<BillSegmentReadData> list) {
		billSegmentReadDatas = list;
	}

	@Override
	public void setBillSegmentServiceQuantityData(
			List<BillSegmentServiceQuantityData> list) {
		billSegmentServiceQuantityDatas = list;
	}

	@Override
	public void setCharacteristicData(List<CharacteristicData> list) {
		characteristicDatas = list;
	}

	@Override
	public void setRegisterRule(RegisterRule registerrule) {
		this.registerRule = registerrule;
	}
	
	@Override
	public void invoke() {
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			if (notNull(registerRule)) {
				cmprrxrx.setRegRuleCd(registerRule.getId().getTrimmedValue());
				cmprrxrx.setRegRuleAlgFlg(registerRule.getRegisterAlgorithm().trimmedValue());
				
				if (notBlank(registerRule.getRegisterParameter1())) {
					cmprrxrx.setRegRuleParm(1, registerRule.getRegisterParameter1());
				}else{
					cmprrxrx.setRegRuleParm(1, CobolCode.SPACES.toString());
				}
				if (notBlank(registerRule.getRegisterParameter2())) {
					cmprrxrx.setRegRuleParm(2, registerRule.getRegisterParameter2());
				}else{
					cmprrxrx.setRegRuleParm(2, CobolCode.SPACES.toString());
				}
				if (notBlank(registerRule.getRegisterParameter3())) {
					cmprrxrx.setRegRuleParm(3, registerRule.getRegisterParameter3());
				}else{
					cmprrxrx.setRegRuleParm(3, CobolCode.SPACES.toString());
				}
				if (notBlank(registerRule.getRegisterParameter4())) {
					cmprrxrx.setRegRuleParm(4, registerRule.getRegisterParameter4());
				}else{
					cmprrxrx.setRegRuleParm(4, CobolCode.SPACES.toString());
				}
				if (notBlank(registerRule.getRegisterParameter5())) {
					cmprrxrx.setRegRuleParm(5, registerRule.getRegisterParameter5());
				}else{
					cmprrxrx.setRegRuleParm(5, CobolCode.SPACES.toString());
				}
				if (notBlank(registerRule.getRegisterParameter6())) {
					cmprrxrx.setRegRuleParm(6, registerRule.getRegisterParameter6());
				}else{
					cmprrxrx.setRegRuleParm(6, CobolCode.SPACES.toString());
				}
				if (notBlank(registerRule.getRegisterParameter7())) {
					cmprrxrx.setRegRuleParm(7, registerRule.getRegisterParameter7());
				}else{
					cmprrxrx.setRegRuleParm(7, CobolCode.SPACES.toString());
				}
				if (notBlank(registerRule.getRegisterParameter8())) {
					cmprrxrx.setRegRuleParm(8, registerRule.getRegisterParameter8());
				}else{
					cmprrxrx.setRegRuleParm(8, CobolCode.SPACES.toString());
				}
				if (notBlank(registerRule.getRegisterParameter9())) {
					cmprrxrx.setRegRuleParm(9, registerRule.getRegisterParameter9());
				}else{
					cmprrxrx.setRegRuleParm(9, CobolCode.SPACES.toString());
				}
				if (notBlank(registerRule.getRegisterParameter10())) {
					cmprrxrx.setRegRuleParm(10, registerRule.getRegisterParameter10());
				}else{
					cmprrxrx.setRegRuleParm(10, CobolCode.SPACES.toString());
				}
			}
			
			if (notNull(applyRateData)) {
				if (notNull(applyRateData.getServiceAgreement())) {
					cmprrxrx.setInputWrkSaId(applyRateData.getServiceAgreement().getId().getTrimmedValue());
				}else{
					cmprrxrx.setInputWrkSaId(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getMasterServiceAgreement())) {
					cmprrxrx.setInputWrkMasterSaId(applyRateData.getMasterServiceAgreement().getId().getTrimmedValue());
				}else{
					cmprrxrx.setInputWrkMasterSaId(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getMasterBillSegment())) {
					cmprrxrx.setMasterBsegId(applyRateData.getMasterBillSegment().getId().getTrimmedValue());
				}else{
					cmprrxrx.setMasterBsegId(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getBill())) {
					cmprrxrx.setBillId(applyRateData.getBill().getId().getTrimmedValue());
				}else{
					cmprrxrx.setBillId(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getBillSegmentCreationDateTime())) {
					cmprrxrx.setBsCreDttm(applyRateData.getBillSegmentCreationDateTime().toString());
				}else{
					cmprrxrx.setBsCreDttm(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getBillSegmentPeriodEnd())) {
					cmprrxrx.setBsPeriodEndDt(applyRateData.getBillSegmentPeriodEnd().toString());
				}else{
					cmprrxrx.setBsPeriodEndDt(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getBillSegmentPeriodStart())) {
					cmprrxrx.setBsPeriodStartDt(applyRateData.getBillSegmentPeriodStart().toString());
				}else{
					cmprrxrx.setBsPeriodStartDt(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getConsumptionPeriodEnd())) {
					cmprrxrx.setConsumptionPeriodEndDt(applyRateData.getConsumptionPeriodEnd().toString());
				}else{
					cmprrxrx.setConsumptionPeriodEndDt(CobolCode.SPACES.toString());
				}
				
				if (notNull(applyRateData.getConsumptionPeriodStart())) {
					cmprrxrx.setConsumptionPeriodStartDt(applyRateData.getConsumptionPeriodStart().toString());
				}else{
					cmprrxrx.setConsumptionPeriodStartDt(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getCharacteristicServicePoint())) {
					cmprrxrx.setCharSrcAttributesSpId(applyRateData.getCharacteristicServicePoint().getId().getTrimmedValue());
				}else{
					cmprrxrx.setCharSrcAttributesSpId(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getCharacteristicPremise())) {
					cmprrxrx.setCharSrcAttributesPremId(applyRateData.getCharacteristicPremise().getId().getTrimmedValue());
				}else{
					cmprrxrx.setCharSrcAttributesPremId(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getAccountingDate())) {
					cmprrxrx.setInputWrkAccountingDt(applyRateData.getAccountingDate().toString());
				}else{
					cmprrxrx.setInputWrkAccountingDt(CobolCode.SPACES.toString());
				}
				
				if (notNull(applyRateData.getShouldRetainReadCollection())) {
					String shouldRetainReadCollectionSw = (applyRateData.getShouldRetainReadCollection().isTrue()) ? SWITCH_YES : SWITCH_NO;
					cmprrxrx.setRetainReadCollSw(shouldRetainReadCollectionSw);
				}else{
					cmprrxrx.setRetainReadCollSw(CobolCode.SPACES.toString());
				}
				
				if (notNull(applyRateData.getShouldRetainItemCollection())) {
					String shouldRetainItemCollectionSw = (applyRateData.getShouldRetainItemCollection().isTrue()) ? SWITCH_YES : SWITCH_NO;
					cmprrxrx.setRetainReadCollSw(shouldRetainItemCollectionSw);
				}else{
					cmprrxrx.setRetainReadCollSw(CobolCode.SPACES.toString());
				}
				
				if (notNull(applyRateData.getShouldRetainSqCollection())) {
					String shouldRetainSqCollectionSw = (applyRateData.getShouldRetainSqCollection().isTrue()) ? SWITCH_YES : SWITCH_NO;
					cmprrxrx.setRetainReadCollSw(shouldRetainSqCollectionSw);
				}else{
					cmprrxrx.setRetainReadCollSw(CobolCode.SPACES.toString());
				}
				
				if (notNull(applyRateData.getShouldRetainSqRules())) {
					String shouldRetainSqRuleSw = (applyRateData.getShouldRetainSqRules().isTrue()) ? SWITCH_YES : SWITCH_NO;
					cmprrxrx.setRetainSqRuleSw(shouldRetainSqRuleSw);
				}else{
					cmprrxrx.setRetainSqRuleSw(CobolCode.SPACES.toString());
				}
				
				if (notNull(applyRateData.getIsThirdParty())) {
					String thirdPartySw = (applyRateData.getIsThirdParty().isTrue()) ? SWITCH_YES : SWITCH_NO;
					cmprrxrx.setThirdPartySw(thirdPartySw);
				}else{
					cmprrxrx.setThirdPartySw(CobolCode.SPACES.toString());
				}
				
				if (notNull(applyRateData.getLanguage())) {
					cmprrxrx.setInputWrkLanguageCd(applyRateData.getLanguage().getId().getTrimmedValue());
				}else{
					cmprrxrx.setInputWrkLanguageCd(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getAdjustment())) {
					cmprrxrx.setAdjId(applyRateData.getAdjustment().getId().getTrimmedValue());
				}else{
					cmprrxrx.setAdjId(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getUsageConsumptionPeriodEnd())) {
					cmprrxrx.setUsageConsumptionPeriodEndDt(applyRateData.getUsageConsumptionPeriodEnd().toString());
				}else{
					cmprrxrx.setUsageConsumptionPeriodEndDt(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getUsageConsumptionPeriodStart())) {
					cmprrxrx.setUsageConsumptionPeriodStartDt(applyRateData.getUsageConsumptionPeriodStart().toString());
				}else{
					cmprrxrx.setUsageConsumptionPeriodStartDt(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getUsageId())) {
					cmprrxrx.setUsageId(applyRateData.getUsageId().getTrimmedValue());
				}else{
					cmprrxrx.setUsageId(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getCisDivision())) {
					cmprrxrx.setCisDivision(applyRateData.getCisDivision().getId().getTrimmedValue());
				}else{
					cmprrxrx.setCisDivision(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getServiceAgreementType())) {
					cmprrxrx.setSaTypeCd(applyRateData.getServiceAgreementType().getId().getSaType());
				}else{
					cmprrxrx.setSaTypeCd(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getRevenueClass())) {
					cmprrxrx.setRevClCd(applyRateData.getRevenueClass().getId().getTrimmedValue());
				}else{
					cmprrxrx.setRevClCd(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getRateSchedule())) {
					cmprrxrx.setRsCd(applyRateData.getRateSchedule().getId().getTrimmedValue());
				}else{
					cmprrxrx.setRsCd(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getSaPeriodEndDate())) {
					cmprrxrx.setSaPeriodEndDt(applyRateData.getSaPeriodEndDate().toString());
				}else{
					cmprrxrx.setSaPeriodEndDt(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getSaPeriodStartDate())) {
					cmprrxrx.setSaPeriodStartDt(applyRateData.getSaPeriodStartDate().toString());
				}else{
					cmprrxrx.setSaPeriodStartDt(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getStartDayOption())) {
					cmprrxrx.setIbBaseTmDayFlg(applyRateData.getStartDayOption().trimmedValue());
				}else{
					cmprrxrx.setIbBaseTmDayFlg(CobolCode.SPACES.toString());
				}
				if (notNull(applyRateData.getIntervalBillingSaCutoffTime())) {
					cmprrxrx.setIbSaCutoffDttmTm(applyRateData.getIntervalBillingSaCutoffTime().toString());
				}else{
					cmprrxrx.setIbSaCutoffDttmTm(CobolCode.SPACES.toString());
				}
			}
			
			cmprrxrx.setBillSegmentSqCnt(java.math.BigDecimal.valueOf(billSegmentServiceQuantityDatas.size()));
			int billSegmentServiceQuantityDatasSize = billSegmentServiceQuantityDatas.size();
			for (int i = 1; i <= billSegmentServiceQuantityDatasSize; i++) {
				BillSegmentServiceQuantity_DTO dto = billSegmentServiceQuantityDatas.get(i - 1).getBillSegmentServiceQuantityDto();
				if (notNull(dto.getId())) {
					if (notBlank(dto.getId().getServiceQuantityIdentifier())) {
						cmprrxrx.setBillSegmentSqSqiCd(i, dto.getId().getServiceQuantityIdentifier().trim());
					}else{
						cmprrxrx.setBillSegmentSqSqiCd(i, CobolCode.SPACES.toString());
					}
					if (notBlank(dto.getId().getTimeOfUse())) {
						cmprrxrx.setBillSegmentSqTouCd(i, dto.getId().getTimeOfUse().trim());
					}else{
						cmprrxrx.setBillSegmentSqTouCd(i, CobolCode.SPACES.toString());
					}
					if (notBlank(dto.getId().getUnitOfMeasure())) {
						cmprrxrx.setBillSegmentSqUomCd(i, dto.getId().getUnitOfMeasure().trim());
					}else{
						cmprrxrx.setBillSegmentSqUomCd(i, CobolCode.SPACES.toString());
					}
				}
				if (notNull(dto.getInitialServiceQuantity())) {
					cmprrxrx.setInitSq(i, dto.getInitialServiceQuantity().toBigDecimal());
				}else{
					cmprrxrx.setInitSq(i, java.math.BigDecimal.ZERO);
				}
				if (notNull(dto.getBillableServiceQuantity())) {
					cmprrxrx.setBillSq(i, dto.getBillableServiceQuantity().toBigDecimal());
				}else{
					cmprrxrx.setBillSq(i, java.math.BigDecimal.ZERO);
				}
			}
			
			int billSegmentReadDatasSize = billSegmentReadDatas.size();
			cmprrxrx.setBillSegmentReadCnt(java.math.BigDecimal.valueOf(billSegmentReadDatasSize));
			for(int i = 1; i <= billSegmentReadDatasSize; i++) {
				BillSegmentRegisterRead_DTO dto = billSegmentReadDatas.get(i - 1).getBillSegmentReadDto();
				if(notNull(dto.getId().getServicePointIdString())) {
					cmprrxrx.setBillSegmentReadSpId(i, dto.getId().getServicePointIdString());
				}else{
					cmprrxrx.setBillSegmentReadSpId(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getId().getSequence())) {
					cmprrxrx.setSeqno(i, java.math.BigDecimal.valueOf(dto.getId().getSequence().doubleValue()));
				}else{
					cmprrxrx.setSeqno(i, java.math.BigDecimal.ZERO);
				}
				if (notNull(dto.getRegisterConstant())) {
					cmprrxrx.setRegConst(i, dto.getRegisterConstant().toBigDecimal());
				}else{
					cmprrxrx.setRegConst(i, java.math.BigDecimal.ZERO);
				}
				if (notNull(dto.getHowToUseRead())) {
					cmprrxrx.setUsageFlg(i, dto.getHowToUseRead().trimmedValue());
				}else{
					cmprrxrx.setUsageFlg(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getUsePercent())) {
					cmprrxrx.setUsePct(i, java.math.BigDecimal.valueOf(dto.getUsePercent().doubleValue()));
				}else{
					cmprrxrx.setUsePct(i, java.math.BigDecimal.ZERO);
				}
				if (notNull(dto.getHowToUse())) {
					cmprrxrx.setHowToUseFlg(i, dto.getHowToUse().trimmedValue());
				}else{
					cmprrxrx.setHowToUseFlg(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getMeasuresPeakQuantity())) {
					String measurePeakQuantitySw = (dto.getMeasuresPeakQuantity().isTrue()) ? SWITCH_YES : SWITCH_NO;
					cmprrxrx.setBillSegmentReadMsrPeakQtySw(i, measurePeakQuantitySw);
				}else{
					cmprrxrx.setBillSegmentReadMsrPeakQtySw(i, CobolCode.SPACES.toString());
				}
				
				if (notNull(dto.getUnitOfMeasureId())) {
					cmprrxrx.setBillSegmentReadUomCd(i, dto.getUnitOfMeasureId().getTrimmedValue());
				}else{
					cmprrxrx.setBillSegmentReadUomCd(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getTimeOfUseId())) {
					cmprrxrx.setTouCd(i, dto.getTimeOfUseId().getTrimmedValue());
				}else{
					cmprrxrx.setTouCd(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getServiceQuantityIdentifierId())) {
					cmprrxrx.setSqiCd(i, dto.getServiceQuantityIdentifierId().getTrimmedValue());
				}else{
					cmprrxrx.setSqiCd(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getStartRegisterReadId())) {
					cmprrxrx.setStartRegReadId(i, dto.getStartRegisterReadId().getTrimmedValue());
				}else{
					cmprrxrx.setStartRegReadId(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getStartReadDateTime())) {
					cmprrxrx.setStartReadDttm(i, dto.getStartReadDateTime().toString());
				}else{
					cmprrxrx.setStartReadDttm(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getStartRegisterReading())) {
					cmprrxrx.setStartRegReading(i, dto.getStartRegisterReading().toBigDecimal());
				}else{
					cmprrxrx.setStartRegReading(i, java.math.BigDecimal.ZERO);
				}
				if (notNull(dto.getEndRegisterReadingId())) {
					cmprrxrx.setEndRegReadId(i, dto.getEndRegisterReadingId().getTrimmedValue());
				}else{
					cmprrxrx.setEndRegReadId(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getEndReadDateTime())) {
					cmprrxrx.setEndReadDttm(i, dto.getEndReadDateTime().toString());
				}else{
					cmprrxrx.setEndReadDttm(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getEndRegisterReading())) {
					cmprrxrx.setEndRegReading(i, dto.getEndRegisterReading().toBigDecimal());
				}else{
					cmprrxrx.setEndRegReading(i, java.math.BigDecimal.ZERO);
				}
				if (notNull(dto.getMeasuredQuantity())) {
					cmprrxrx.setMsrQty(i, dto.getMeasuredQuantity().toBigDecimal());
				}else{
					cmprrxrx.setMsrQty(i, java.math.BigDecimal.ZERO);
				}
				if (notNull(dto.getFinalUnitOfMeasureId())) {
					cmprrxrx.setFinalUomCd(i, dto.getFinalUnitOfMeasureId().getTrimmedValue());
				}else{
					cmprrxrx.setFinalUomCd(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getFinalTimeOfUseId())) {
					cmprrxrx.setFinalTouCd(i, dto.getFinalTimeOfUseId().getTrimmedValue());
				}else{
					cmprrxrx.setFinalTouCd(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getFinalServiceQuantityId())) {
					cmprrxrx.setFinalSqiCd(i, dto.getFinalServiceQuantityId().getTrimmedValue());
				}else{
					cmprrxrx.setFinalSqiCd(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getRegisterQuantity())) {
					cmprrxrx.setFinalRegQty(i, dto.getRegisterQuantity().toBigDecimal());
				}else{
					cmprrxrx.setFinalRegQty(i, java.math.BigDecimal.ZERO);
				}
			
			}
			
			int billSegmentItemDatasSize = billSegmentItemDatas.size();
			cmprrxrx.setBillSegmentItemCnt(java.math.BigDecimal.valueOf(billSegmentItemDatasSize));
			for (int i = 1; i <= billSegmentItemDatasSize; i++) {
				BillSegmentItem_DTO dto = billSegmentItemDatas.get(i - 1).getBillSegmentItemDto();
				if (notNull(dto.getId()) && notNull(dto.getId().getSequence())) {
					cmprrxrx.setBillSegmentItemSeqno(i, java.math.BigDecimal.valueOf(dto.getId().getSequence().doubleValue()));
				}else{
					cmprrxrx.setBillSegmentItemSeqno(i, java.math.BigDecimal.ZERO);
				}
				if (notBlank(dto.getItemType())) {
					cmprrxrx.setItemTypeCd(i, dto.getItemType().trim());
				}else{
					cmprrxrx.setItemTypeCd(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getItemId())) {
					cmprrxrx.setItemId(i, dto.getItemId().getTrimmedValue());
				}else{
					cmprrxrx.setItemId(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getStartDate())) {
					cmprrxrx.setBillSegmentItemStartDt(i, dto.getStartDate().toString());
				}else{
					cmprrxrx.setBillSegmentItemStartDt(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getEndDate())) {
					cmprrxrx.setBillSegmentItemEndDt(i, dto.getEndDate().toString());
				}else{
					cmprrxrx.setBillSegmentItemEndDt(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getItemCount())) {
					cmprrxrx.setItemCnt(i, dto.getItemCount().toBigDecimal());
				}else{
					cmprrxrx.setItemCnt(i, java.math.BigDecimal.ZERO);
				}
				if (notNull(dto.getUnitOfMeasureId())) {
					cmprrxrx.setBillSegmentItemUomCd(i, dto.getUnitOfMeasureId().getTrimmedValue());
				}else{
					cmprrxrx.setBillSegmentItemUomCd(i, CobolCode.SPACES.toString());
				}
				if (notNull(dto.getDailyServiceQuantity())) {
					cmprrxrx.setSvcQty(i, dto.getDailyServiceQuantity().toBigDecimal());
				}else{
					cmprrxrx.setSvcQty(i, java.math.BigDecimal.ZERO);
				}
			}
			
			int characteristicDatasSize = characteristicDatas.size();
			cmprrxrx.setCharCollCnt(java.math.BigDecimal.valueOf(characteristicDatasSize));
			for (int i = 1; i <= characteristicDatasSize; i++) {
				CharacteristicData data = characteristicDatas.get(i - 1);
				if (notNull(data.getCharacteristicType())) {
					cmprrxrx.setCharType(i, data.getCharacteristicType().getId().getTrimmedValue());
				}else{
					cmprrxrx.setCharType(i, CobolCode.SPACES.toString());
				}
				if (notBlank(data.getCharacteristicValue())) {
					cmprrxrx.setCharCollCharVal(i, data.getCharacteristicValue().trim());
				}else{
					cmprrxrx.setCharCollCharVal(i, CobolCode.SPACES.toString());
				}
				if (notBlank(data.getAdhocCharacteristicValue())) {
					cmprrxrx.setAdhocCharVal(i, data.getAdhocCharacteristicValue().trim());
				}else{
					cmprrxrx.setAdhocCharVal(i, CobolCode.SPACES.toString());
				}
			}
			
			// invoke the main method
		    cmprrxrx.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
            //Start Delete - MPang - Defect 3444302- 2016-06-01
            //ex.printStackTrace();
            //End Delete - MPang - Defect 3444302- 2016-06-01
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmprrxrx.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmprrxrx.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmprrxrx.getMessageParm(i);
			    			if (notBlank(cmprrxrx.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmprrxrx.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmprrxrx.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmprrxrx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmprrxrx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    	populateHardParameters();
		    	
		    }
		    else {
		        //Start Add- MPang - Defect 3444302- 2016-06-01
		        ex.printStackTrace();
		        //End Add- MPang - Defect 3444302- 2016-06-01
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getClass().getCanonicalName(), ex.toString()));
		        }
		    }
		}
		finally {
			cmprrxrx=Session.returnSessionAndCodeToCache(cmprrxrx);
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//	         //Start Add- MPang - Defect 3444302- 2016-06-01
//            try {
//                connection.close();
//            } catch (SQLException e) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getClass().getCanonicalName(), e.toString()));
//            }
//            //End Add- MPang - Defect 3444302- 2016-06-01
         // end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}
	}
	
	private void populateHardParameters() {
		try {
			if (notBlank(cmprrxrx.getInputWrkSaId())) {
				applyRateData.setServiceAgreement(new ServiceAgreement_Id(cmprrxrx.getInputWrkSaId()).getEntity());
			}
			if (notBlank(cmprrxrx.getMasterBsegId())) {
				applyRateData.setMasterServiceAgreement(new ServiceAgreement_Id(cmprrxrx.getMasterBsegId()).getEntity());
			}
			
			BillSegment billSegment = new BillSegment_Id(cmprrxrx.getMasterBsegId()).getEntity();
			
			if (notNull(billSegment)) {
				applyRateData.setMasterBillSegment(billSegment);
			}
			if (notBlank(cmprrxrx.getBillId())) {
				applyRateData.setBill(new Bill_Id(cmprrxrx.getBillId()).getEntity());
			}
			
			if (notBlank(cmprrxrx.getBsCreDttm())) {
				
				DateTime bsCreationDateTime;
				
				if(cmprrxrx.getBsCreDttm().matches("([0-9]{4})-([0-9]{2})-([0-9]{2})-([0-9]{2}).([0-9]{2}).([0-9]{2}).([0-9]{6})")){
					bsCreationDateTime = DateTime.fromString(cmprrxrx.getBsCreDttm(), dateTimeFormat2);
				} else {
					bsCreationDateTime = DateTime.fromString(cmprrxrx.getBsCreDttm(), dateTimeFormat);
				}
				applyRateData.setBillSegmentCreationDateTime(bsCreationDateTime);
			}
			
			if (notBlank(cmprrxrx.getBsPeriodEndDt())) {
				Date bsPeriodEndDate = Date.fromString(cmprrxrx.getBsPeriodEndDt(), dateFormat);
				applyRateData.setBillSegmentPeriodEnd(bsPeriodEndDate);
			}
			
			if (notBlank(cmprrxrx.getBsPeriodStartDt())) {
				Date bsPeriodStartDate = Date.fromString(cmprrxrx.getBsPeriodStartDt(), dateFormat);
				applyRateData.setBillSegmentPeriodStart(bsPeriodStartDate);
			}
			
			if (notBlank(cmprrxrx.getConsumptionPeriodEndDt())) {
				Date consPeriodEndDate = Date.fromString(cmprrxrx.getConsumptionPeriodEndDt(), dateFormat);
				applyRateData.setConsumptionPeriodEnd(consPeriodEndDate);
			}
			
			if (notBlank(cmprrxrx.getConsumptionPeriodEndDt())) {
				Date consPeriodStartDate = Date.fromString(cmprrxrx.getConsumptionPeriodStartDt(), dateFormat);
				applyRateData.setConsumptionPeriodStart(consPeriodStartDate);
			}
			
			if (notBlank(cmprrxrx.getCharSrcAttributesSpId())) {
				applyRateData.setCharacteristicServicePoint(new ServicePoint_Id(cmprrxrx.getCharSrcAttributesSpId()).getEntity());
			}
			
			if (notBlank(cmprrxrx.getCharSrcAttributesPremId())) {
				applyRateData.setCharacteristicPremise(new Premise_Id(cmprrxrx.getCharSrcAttributesPremId()).getEntity());
			}
			
			if (notBlank(cmprrxrx.getInputWrkAccountingDt())) {
				Date accountingDate = Date.fromString(cmprrxrx.getInputWrkAccountingDt(), dateFormat);
				applyRateData.setAccountingDate(accountingDate);
			}
			
			if (notBlank(cmprrxrx.getRetainReadCollSw())) {
				applyRateData.setShouldRetainReadCollection((cmprrxrx.getRetainReadCollSw().compareToIgnoreCase(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE);
			}
			if (notBlank(cmprrxrx.getRetainItemCollSw())) {
				applyRateData.setShouldRetainItemCollection((cmprrxrx.getRetainItemCollSw().compareToIgnoreCase(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE);
			}
			
			if (notBlank(cmprrxrx.getRetainSqCollSw())) {
				applyRateData.setShouldRetainSqCollection((cmprrxrx.getRetainSqCollSw().compareToIgnoreCase(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE);
			}
			if (notBlank(cmprrxrx.getRetainSqRuleSw())) {
				applyRateData.setShouldRetainSqRules((cmprrxrx.getRetainSqRuleSw().compareToIgnoreCase(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE);
			}
			if (notBlank(cmprrxrx.getThirdPartySw())) {
				applyRateData.setIsThirdParty((cmprrxrx.getThirdPartySw().compareToIgnoreCase(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE);
			}
			if (notBlank(cmprrxrx.getInputWrkLanguageCd())) {
				applyRateData.setLanguage(new Language_Id(cmprrxrx.getInputWrkLanguageCd()).getEntity());
			}
			
			if (notBlank(cmprrxrx.getAdjId())) {
				applyRateData.setAdjustment(new Adjustment_Id(cmprrxrx.getAdjId()).getEntity());
			}
			
			if (notBlank(cmprrxrx.getUsageConsumptionPeriodEndDt())) {
				Date usageConsPeriodEndDate = Date.fromString(cmprrxrx.getUsageConsumptionPeriodEndDt(), dateFormat);
				applyRateData.setUsageConsumptionPeriodEnd(usageConsPeriodEndDate);
			}
			
			if (notBlank(cmprrxrx.getUsageConsumptionPeriodStartDt())) {
				Date usageConsPeriodStartDate = Date.fromString(cmprrxrx.getUsageConsumptionPeriodStartDt(), dateFormat);
				applyRateData.setUsageConsumptionPeriodStart(usageConsPeriodStartDate);
			}
			
			if (notBlank(cmprrxrx.getUsageId())) {
				applyRateData.setUsageId(new Usage_Id(cmprrxrx.getUsageId()));
			}
			
			if (notBlank(cmprrxrx.getCisDivision()) && notBlank(cmprrxrx.getSaTypeCd())) {
				CisDivision cisDivision = new CisDivision_Id(cmprrxrx.getCisDivision()).getEntity();
				applyRateData.setCisDivision(cisDivision);
				applyRateData.setServiceAgreementType(new ServiceAgreementType_Id(cisDivision, cmprrxrx.getSaTypeCd()).getEntity());
			}
			
			if (notBlank(cmprrxrx.getRevClCd())) {
				applyRateData.setRevenueClass(new RevenueClass_Id(cmprrxrx.getRevClCd()).getEntity());
			}
			
			if (notBlank(cmprrxrx.getRsCd())) {
				applyRateData.setRateSchedule(new RateSchedule_Id(cmprrxrx.getRsCd()).getEntity());
			}
			
			if (notBlank(cmprrxrx.getSaPeriodEndDt())) {
				Date saPeriodEndDate = Date.fromString(cmprrxrx.getSaPeriodEndDt(), dateFormat);
				applyRateData.setSaPeriodEndDate(saPeriodEndDate);
			}
			
			if (notBlank(cmprrxrx.getSaPeriodStartDt())) {
				Date saPeriodStartDate = Date.fromString(cmprrxrx.getSaPeriodStartDt(), dateFormat);
				applyRateData.setSaPeriodStartDate(saPeriodStartDate);
			}
			
			if (notBlank(cmprrxrx.getIbBaseTmDayFlg())) {
				applyRateData.setStartDayOption(LookupHelper.getLookupInstance(IntervalBillingStartDayOptionLookup.class, cmprrxrx.getIbBaseTmDayFlg()));
			}
			if (notBlank(cmprrxrx.getIbSaCutoffDttmTm())) {
				applyRateData.setIntervalBillingSaCutoffTime(Time.fromString(cmprrxrx.getIbSaCutoffDttmTm(), timeFormat));
			}
			
			int bsSqDatasSize = cmprrxrx.getBillSegmentSqCnt().intValue();
			billSegmentServiceQuantityDatas.clear();
			for (int i = 1; i <= bsSqDatasSize; i++) {
				BillSegmentServiceQuantityData data = BillSegmentServiceQuantityData.Factory.newInstance();
				BillSegmentServiceQuantity_DTO dto = new BillSegmentServiceQuantity_DTO();
				BillSegmentServiceQuantity_Id id = new BillSegmentServiceQuantity_Id(
						billSegment, cmprrxrx.getBillSegmentSqUomCd(i), 
						cmprrxrx.getBillSegmentSqTouCd(i), cmprrxrx.getBillSegmentSqSqiCd(i));
				
				dto.setId(id);
				dto.setInitialServiceQuantity(BigDecimal.valueOf(cmprrxrx.getInitSq(i).doubleValue()));
				dto.setBillableServiceQuantity(BigDecimal.valueOf(cmprrxrx.getBillSq(i).doubleValue()));
				
				data.setBillSegmentServiceQuantityDto(dto);
				billSegmentServiceQuantityDatas.add(data);
			}
			
			int bsReadDatasSize = cmprrxrx.getBillSegmentReadCnt().intValue();
			billSegmentReadDatas.clear();
			for (int i = 1; i <= bsReadDatasSize; i++) {
				BillSegmentReadData data = BillSegmentReadData.Factory.newInstance();
				BillSegmentRegisterRead_DTO dto = new BillSegmentRegisterRead_DTO();
				BillSegmentRegisterRead_Id id = new BillSegmentRegisterRead_Id(
						billSegment, cmprrxrx.getBillSegmentReadSpId(i), cmprrxrx.getSeqno(i).toBigInteger());
				dto.setId(id);
				dto.setRegisterConstant(BigDecimal.valueOf(cmprrxrx.getRegConst(i).doubleValue()));
				dto.setHowToUseRead(LookupHelper.getLookupInstance(HowToUseReadLookup.class, cmprrxrx.getUsageFlg(i)));
				// start update - equint - 2025-11-14 - CCB25.4 Upgrade
				// dto.setUsePercent(cmprrxrx.getUsePct(i).toBigInteger());
				dto.setUsePercent(BigDecimal.valueOf(cmprrxrx.getUsePct(i).doubleValue()));
				// end update - equint - 2025-11-14 - CCB25.4 Upgrade
				dto.setHowToUse(LookupHelper.getLookupInstance(HowToUseLookup.class, cmprrxrx.getHowToUseFlg(i)));
				dto.setMeasuresPeakQuantity((cmprrxrx.getBillSegmentReadMsrPeakQtySw(i).compareToIgnoreCase(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE);
				dto.setUnitOfMeasureId(new UnitOfMeasure_Id(cmprrxrx.getBillSegmentReadUomCd(i)));
				dto.setTimeOfUseId(new TimeOfUse_Id(cmprrxrx.getTouCd(i)));
				dto.setServiceQuantityIdentifierId(new ServiceQuantityIdentifier_Id(cmprrxrx.getSqiCd(i)));
				dto.setStartRegisterReadId(new RegisterRead_Id(cmprrxrx.getStartRegReadId(i)));
				dto.setEndRegisterReadingId(new RegisterRead_Id(cmprrxrx.getEndRegReadId(i)));
				
				DateTime startReadDttm = DateTime.fromString(cmprrxrx.getStartReadDttm(i), dateTimeFormat);
				dto.setStartReadDateTime(startReadDttm);
				dto.setStartRegisterReading(BigDecimal.valueOf(cmprrxrx.getStartRegReading(i).doubleValue()));
				
				DateTime endReadDttm = DateTime.fromString(cmprrxrx.getEndReadDttm(i), dateTimeFormat);
				dto.setEndReadDateTime(endReadDttm);
				dto.setEndRegisterReading(BigDecimal.valueOf(cmprrxrx.getEndRegReading(i).doubleValue()));
				
				dto.setMeasuredQuantity(BigDecimal.valueOf(cmprrxrx.getMsrQty(i).doubleValue()));
				dto.setFinalUnitOfMeasureId(new UnitOfMeasure_Id(cmprrxrx.getFinalUomCd(i)));
				
				dto.setFinalTimeOfUseId(new TimeOfUse_Id(cmprrxrx.getFinalTouCd(i)));
				dto.setFinalServiceQuantityId(new ServiceQuantityIdentifier_Id(cmprrxrx.getFinalSqiCd(i)));
				dto.setRegisterQuantity(BigDecimal.valueOf(cmprrxrx.getFinalRegQty(i).doubleValue()));
				
				data.setBillSegmentReadDto(dto);
				billSegmentReadDatas.add(data);
			}
			
			int bsItemDatasSize = cmprrxrx.getBillSegmentItemCnt().intValue();
			billSegmentItemDatas.clear();
			for (int i = 1; i <= bsItemDatasSize; i++) {
				BillSegmentItemData data = BillSegmentItemData.Factory.newInstance();
				BillSegmentItem_DTO dto = new BillSegmentItem_DTO();
				BillSegmentItem_Id id = new BillSegmentItem_Id(billSegment, cmprrxrx.getBillSegmentItemSeqno(i).toBigInteger());
				dto.setId(id);
				dto.setItemType(cmprrxrx.getItemTypeCd(i));
				dto.setItemId(new Item_Id(cmprrxrx.getItemId(i)));
				
				Date bsItemStartDt = Date.fromString(cmprrxrx.getBillSegmentItemStartDt(i), dateFormat);
				dto.setStartDate(bsItemStartDt);
				
				Date bsItemEndDt = Date.fromString(cmprrxrx.getBillSegmentItemEndDt(i), dateFormat);
				dto.setEndDate(bsItemEndDt);
				
				dto.setItemCount(BigDecimal.valueOf(cmprrxrx.getItemCnt(i).doubleValue()));
				dto.setUnitOfMeasureId(new UnitOfMeasure_Id(cmprrxrx.getBillSegmentItemUomCd(i)));
				dto.setDailyServiceQuantity(BigDecimal.valueOf(cmprrxrx.getSvcQty(i).doubleValue()));
				
				billSegmentItemDatas.add(data);
			}
			
			int charDatasSize = cmprrxrx.getCharCollCnt().intValue();
			characteristicDatas.clear();
			for(int i = 1; i < charDatasSize ; i++) {
				CharacteristicData data = CharacteristicData.Factory.newInstance();
				data.setCharacteristicType(new CharacteristicType_Id(cmprrxrx.getCharType(i)).getEntity());
				data.setCharacteristicValue(cmprrxrx.getCharCollCharVal(i));
				data.setAdhocCharacteristicValue(cmprrxrx.getAdhocCharVal(i));
				
				characteristicDatas.add(data);
			}

	}
		catch (Exception e) {
			if (e instanceof ApplicationError) {
	        	addError(((ApplicationError)e).getServerMessage());
	        }
	        else {
	        	addError(CustomMessageRepository.JACOB_errorMessage(getClass().getCanonicalName(), e.toString()));
	        }
		}
	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
		FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
		RequestContext context = session.getRequestContext();
		
		// start update - equint - 2025-11-14 - CCB25.4 Upgrade
		session.doWork(new ConnectionWork() {
			
			@Override
			public void execute(Connection connection) throws SQLException {
				try {				        
					String username = connection.getMetaData().getUserName();
					String url = connection.getMetaData().getURL();
					
					CobolSession.setLogSessionStartEnd(false);
				    cmprrxrx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmprrxrx.class);
					
					cmprrxrx.getSession().getDbSession().setUpdateConnection(connection);
					cmprrxrx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
					
					// initialize linkage copybooks
					cmprrxrx.aa100Initialize();
					
					// set ZSTAT parameters

					cmprrxrx.setProcessDt(getProcessDateTime().getDate().toString());
					cmprrxrx.setProcessDttmSep("-");
					cmprrxrx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
					
					if (session.isOnlineConnection()) { 
						cmprrxrx.setConnectionFlg(CONNECTION_ONLINE);
					}
					else {
						cmprrxrx.setConnectionFlg(CONNECTION_BATCH);
					}
					
					cmprrxrx.setUserId(context.getUserId());
					cmprrxrx.setZstatLanguageCd(context.getLanguageCode());
			        
			        if (context.ignoreWarnings()) {
			        	cmprrxrx.setIgnoreWarningSw(SWITCH_YES);
			        }
			        else {
			        	cmprrxrx.setIgnoreWarningSw(SWITCH_NO);
			        }
			        
			        if (session.getBatchInstanceId() != null) {
			        	cmprrxrx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
			        	
					} else {
						cmprrxrx.setSchedulerId(new BigDecimal(0).toBigDecimal());
					}
			        
			        cmprrxrx.setAppSvcId(context.getSecurityServiceIdContext());
			        
			        DatabaseHelper dbHelper = session.getDatabaseHelper();
			        cmprrxrx.setDbMode(dbHelper.getCobolDBMode());
			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
			        //cmprrxrx.setSplHighValue(cmprrxrx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
			        //cmprrxrx.setSplLowValue(cmprrxrx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
			        
			        cmprrxrx.setSplHighValue(cmprrxrx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
			        cmprrxrx.setSplLowValue(cmprrxrx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
			        
			        cmprrxrx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
			        
			        cmprrxrx.setLkExpiryDt(Date.MAX.toString());
			        
			        cmprrxrx.setProgramStatus(" ");
			        
			        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
			        cmprrxrx.setCallSeq(";");
			        cmprrxrx.setMessageAreaProgramName("CMPRRXRX");
			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
			        
			        if (context.getRandomGeneratorSeedSet().isTrue()) {
			        	cmprrxrx.setRandomGenSeedSw(SWITCH_YES);
			        	cmprrxrx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
			        	cmprrxrx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
			        	cmprrxrx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
			        	cmprrxrx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
			        }
			        else {
			        	cmprrxrx.setRandomGenSeedSw(SWITCH_NO);
			        }
			        
			        if (context.traceStandardOut()) { 
			        	cmprrxrx.setTrcStdoutSw(SWITCH_YES);
			        }
			        else {
			        	cmprrxrx.setTrcStdoutSw(SWITCH_NO);
			        }
			        
			        if (context.traceProgramStart()) { 
			        	cmprrxrx.setTrcProgStartSw(SWITCH_YES);
			        }
			        else {
			        	cmprrxrx.setTrcProgStartSw(SWITCH_NO);
			        }
			        
			        if (context.traceProgramExit()) { 
			        	cmprrxrx.setTrcProgExitSw(SWITCH_YES);
			        }
			        else {
			        	cmprrxrx.setTrcProgExitSw(SWITCH_NO);
			        }
			        
			        if (context.traceSQL()) { 
			        	cmprrxrx.setTrcExecSqlSw(SWITCH_YES);
			        }
			        else {
			        	cmprrxrx.setTrcExecSqlSw(SWITCH_NO);
			        }
			        
			        // Set ZMSGN parms
			        BigInteger messageSequence = session.getMessageSequence();
			        if (notNull(messageSequence)) {
			        	cmprrxrx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
			        }
			        else {
			        	cmprrxrx.setMessageSeq(new BigDecimal(0).toBigDecimal());
			        }
				}
				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		 
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//        //Start Change - MPang - Defect 3444302- 2016-06-01
//        //Connection connection = implementor.getConnectionProvider().getConnection();
//        connection = implementor.getConnectionProvider().getConnection();
//        //End Change - MPang - Defect 3444302- 2016-06-01
//        
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmprrxrx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmprrxrx.class);
//		
//		cmprrxrx.getSession().getDbSession().setUpdateConnection(connection);
//		cmprrxrx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		
//		// initialize linkage copybooks
//		cmprrxrx.aa100Initialize();
//		
//		// set ZSTAT parameters
//
//		cmprrxrx.setProcessDt(getProcessDateTime().getDate().toString());
//		cmprrxrx.setProcessDttmSep("-");
//		cmprrxrx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmprrxrx.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmprrxrx.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmprrxrx.setUserId(context.getUserId());
//		cmprrxrx.setZstatLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmprrxrx.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmprrxrx.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmprrxrx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmprrxrx.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmprrxrx.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmprrxrx.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmprrxrx.setSplHighValue(cmprrxrx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmprrxrx.setSplLowValue(cmprrxrx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmprrxrx.setSplHighValue(cmprrxrx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmprrxrx.setSplLowValue(cmprrxrx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmprrxrx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmprrxrx.setLkExpiryDt(Date.MAX.toString());
//        
//        cmprrxrx.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmprrxrx.setCallSeq(";");
//        cmprrxrx.setMessageAreaProgramName("CMPRRXRX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmprrxrx.setRandomGenSeedSw(SWITCH_YES);
//        	cmprrxrx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmprrxrx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmprrxrx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmprrxrx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmprrxrx.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmprrxrx.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmprrxrx.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmprrxrx.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmprrxrx.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmprrxrx.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmprrxrx.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmprrxrx.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmprrxrx.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmprrxrx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmprrxrx.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }
		
		// end update - equint - 2025-11-14 - CCB25.4 Upgrade

	}

	
}
