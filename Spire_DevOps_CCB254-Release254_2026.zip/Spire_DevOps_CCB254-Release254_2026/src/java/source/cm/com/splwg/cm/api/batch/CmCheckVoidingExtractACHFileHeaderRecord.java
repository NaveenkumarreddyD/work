/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Voiding File Batch Extract - ACH File
 * Header Record
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2021-06-01   GCrisp     Initial version. CCB041.3 ACH File Header
 *                   	   Record
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmCheckVoidingExtractACHFileHeaderRecord extends ColumnDelimitedRecord{
	
	/*
	 * Constructor
	 */
	public CmCheckVoidingExtractACHFileHeaderRecord() {
		super(13);
	}

	public void setRecordTypeCode(String value) {		
		rightPadColumn(1, 1, value);
	}
	
	public void setPriorityCode(String value) {		
		rightPadColumn(2, 2, value);
	}
	
	public void setImmediateDestination(String value) {		
		rightPadColumn(3, 10, value);
	}
	
	public void setImmediateOrigin(String value) {		
		rightPadColumn(4, 10, value);
	}
	
	public void setFileCreationDate(String value) {		
		rightPadColumn(5, 6, value);
	}
	
	public void setFileCreationTime(String value) {		
		rightPadColumn(6, 4, value);
	}
	
	public void setFileIdModifier(String value) {		
		rightPadColumn(7, 1, value);
	}
	
	public void setRecordSize(String value) {		
		rightPadColumn(8, 3, value);
	}
	
	public void setBlockingFactor(String value) {		
		rightPadColumn(9, 2, value);
	}
	
	public void setFormatCode(String value) {		
		rightPadColumn(10, 1, value);
	}
	
	public void setImmediateDestinationName(String value) {		
		rightPadColumn(11, 23, value);
	}
	
	public void setImmediateOriginName(String value) {		
		rightPadColumn(12, 23, value);
	}
	
	public void setReferenceCode(String value) {		
		rightPadColumn(13, 8, value);
	}
}
