/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NA0083 - Collection Event Type Algorithm
 * 
 * Add a new effective dated SA Char using the Char Type and Char Value
 * algorithm parameters.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-03-14   MOL     NA0083.
 * 2016-01-25   MPang	Updated for CCB v2.4 compilation.
 **************************************************************************/
package com.splwg.cm.domain.admin.collectionEventType;

import java.util.Iterator;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.collectionEventType.CollectionEventTypeCollectionEventAlgorithmSpot;
import com.splwg.ccb.domain.creditcollections.collectionProcess.CollectionProcessServiceAgreement;
import com.splwg.ccb.domain.creditcollections.collectionProcess.CreditAndCollectionEvent;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCharacteristics;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;*/

import com.splwg.ccb.domain.admin.collectionEventType.algorithm.collection.CollectionEventAlgorithmSpot;
import com.splwg.ccb.domain.creditcollections.collectionProcess.entity.CollectionProcessServiceAgreement;
import com.splwg.ccb.domain.creditcollections.collectionProcess.entity.CreditAndCollectionEvent;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristics;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = saCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = saCharVal, required = true, type = decimal)
 *            , @AlgorithmSoftParameter (name = processOnlyIfSAIsInCollection, required = true, type = boolean)})
 */
public class CmAddEffectiveDatedSAChar_Impl extends
		CmAddEffectiveDatedSAChar_Gen implements
		//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
		//CollectionEventTypeCollectionEventAlgorithmSpot {
	    CollectionEventAlgorithmSpot { 
	   //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
	private static final Logger logger = LoggerFactory
	.getLogger(CmAddEffectiveDatedSAChar_Impl.class);

	private Account acct;

	private Bool addWorkDays;

	private CreditAndCollectionEvent creditAndCollEvent;

	public void setAccount(Account arg0) {
		// TODO Auto-generated method stub
		acct = arg0;
	}

	public void setAddWorkDays(Bool arg0) {
		// TODO Auto-generated method stub
		addWorkDays = arg0;
	}

	public void setCreditAndCollectionEvent(CreditAndCollectionEvent arg0) {
		// TODO Auto-generated method stub
		creditAndCollEvent = arg0;
	}
	
	protected void extraSoftParameterValidations(boolean arg0) {
		// TODO Auto-generated method stub
		
		//logger.info("Leky - inside extraSoftParameterValidations" + arg0);
		super.extraSoftParameterValidations(arg0);
		
	}

	public void invoke() {
		// TODO Auto-generated method stub

		//logger.info("Leky - inside invoke()");
		
		if (getProcessOnlyIfSAIsInCollection().isTrue()) {
			processAccountsSAsThatAreInCollectionO();
		} else {
			processAllOfTheAccountsSAs();
		}
		
	}
	
	private void processAccountsSAsThatAreInCollectionO() {
		
		// Get SAs linked to the Collection Process that are in Active status
		Iterator iter1 = creditAndCollEvent.getId().getCollectionProcess().getServiceAgreements().iterator();
		while (iter1.hasNext()) {
			CollectionProcessServiceAgreement cpSA = (CollectionProcessServiceAgreement) iter1.next();
			if (cpSA.getCollectionProcessSAstatus().isActive()) {
				processSA(cpSA.fetchIdServiceAgreement());
			}
		}

	}
	
	private void processAllOfTheAccountsSAs() {

		// Process all Active, Pending Start and Pending Stop SAs of the Account regardless of whether they are in collections or not.
		PreparedStatement getSetOfRecordsStatement = createPreparedStatement(
				" SELECT SA_ID "
						+ " FROM CI_SA "
						+ " WHERE ACCT_ID = :inAcctId "
						//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
						// + "   AND SA_STATUS_FLG IN (:inActive, :inPendingStart, :inPendingStop) "
						// );
						+ "   AND SA_STATUS_FLG IN (:inActive, :inPendingStart, :inPendingStop) ", getClass().getName());
						//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation

		getSetOfRecordsStatement.bindId("inAcctId", acct.getId());
		getSetOfRecordsStatement.bindLookup("inActive", ServiceAgreementStatusLookup.constants.ACTIVE);
		getSetOfRecordsStatement.bindLookup("inPendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
		getSetOfRecordsStatement.bindLookup("inPendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
		Iterator iter1 = getSetOfRecordsStatement.iterate();
		while (iter1.hasNext()) {
			
			SQLResultRow sqlRR = (SQLResultRow) iter1.next();
			ServiceAgreement_Id saId = new ServiceAgreement_Id(sqlRR
					.getString("SA_ID"));
			processSA(saId.getEntity());
			
		}
		
	}
	
	private void addSAChar (ServiceAgreementCharacteristics saChars, Date effDt, CharacteristicType charType, String charValue) {
		
		ServiceAgreementCharacteristic_DTO newSAChar_DTO = saChars.newChildDTO();
		
		CharacteristicTypeLookup charTypeLookUp = getSaCharType().getCharacteristicType();
		
		// File Location or Adhoc
		if (charTypeLookUp.isFileLocationValue() || charTypeLookUp.isAdhocValue()) {
			newSAChar_DTO.setAdhocCharacteristicValue(charValue);
		}
		
		// Foreign Key
		if (charTypeLookUp.isForeignKeyValue()) {
			newSAChar_DTO.setCharacteristicValueForeignKey1(charValue);
		}
		
		// File Location or Adhoc
		if (charTypeLookUp.isPredefinedValue()) {
			newSAChar_DTO.setCharacteristicValue(charValue);
		}
		
		saChars.add(newSAChar_DTO, charType.getId(), effDt);

	}
	
	private String getActualSACharValue(ServiceAgreementCharacteristic saChar) {

		String actualSACharValue = "";
		CharacteristicTypeLookup charTypeLookUp = saChar.getId().getCharacteristicType().getCharacteristicType();
		
		// File Location or Adhoc
		if (charTypeLookUp.isFileLocationValue() || charTypeLookUp.isAdhocValue()) {
			actualSACharValue = saChar.getAdhocCharacteristicValue();
		}
		
		// Foreign Key
		if (charTypeLookUp.isForeignKeyValue()) {
			actualSACharValue = saChar.getCharacteristicValueForeignKey1();
		}
		
		// File Location or Adhoc
		if (charTypeLookUp.isPredefinedValue()) {
			actualSACharValue = saChar.getCharacteristicValue();
		}
		
		return actualSACharValue;
		
	}
	
	private void updateSACharValue (ServiceAgreementCharacteristic saChar, String charValue) {

		ServiceAgreementCharacteristic_DTO saChar_DTO = saChar.getDTO();
		CharacteristicTypeLookup charTypeLookUp = saChar.getId().getCharacteristicType().getCharacteristicType();
		
		
		// File Location or Adhoc
		if (charTypeLookUp.isFileLocationValue() || charTypeLookUp.isAdhocValue()) {
			saChar_DTO.setAdhocCharacteristicValue(charValue);
		}
		
		// Foreign Key
		if (charTypeLookUp.isForeignKeyValue()) {
			saChar_DTO.setCharacteristicValueForeignKey1(charValue);
		}
		
		// File Location or Adhoc
		if (charTypeLookUp.isPredefinedValue()) {
			saChar_DTO.setCharacteristicValue(charValue);
		}
		
		saChar.setDTO(saChar_DTO);
		
	}
	
	private void processSA(ServiceAgreement sa) {
		
		// Skip processing if an SA Char does not exist
		if (doesSACharExist(sa, getSaCharType(), null).isFalse()) {
			return;
		}
		
		while (deleteFutureDatedChars(sa).isTrue()) {			
		}

		ServiceAgreementCharacteristics saChars = sa.getCharacteristics();
		
		Iterator iter1 = saChars.iterator();
		while (iter1.hasNext()) {
			ServiceAgreementCharacteristic saChar = (ServiceAgreementCharacteristic) iter1.next();
			String saCharValue = getActualSACharValue(saChar);
			CharacteristicType saCharType =  saChar.getId().getCharacteristicTypeId().getEntity();
			
			//logger.info(saChar.fetchIdEffectiveDate() + "/" + saChar.fetchIdCharacteristicType().getId().getIdValue() + "/" + saChar.getAdhocCharacteristicValue()
			//		+ "/" + saChar.getCharacteristicValue());
			
			if (saChar.fetchIdEffectiveDate().isSameOrAfter(getProcessDateTime().getDate())
					&& saChar.fetchIdCharacteristicType().equals(getSaCharType())) {
				
				// Effective Date is same as current Date
				if (saChar.fetchIdEffectiveDate().equals(getProcessDateTime().getDate())) {

					// If possible, update the exiting chars effective date to current date -1
					if (doesSACharExist(sa, saCharType, getProcessDateTime().getDate().addDays(-1)).isFalse()) {
						// logger.info("addSAChar");
						addSAChar(saChars, getProcessDateTime().getDate().addDays(-1), saCharType, saCharValue);
					}
					
					// Set the value of the the current date's char
					// logger.info("updateSACharValue");
					updateSACharValue(saChar, getSaCharVal().toString());
					return;
					
				}
				
			//	// Effective Date is in the future
			//	if (saChar.fetchIdEffectiveDate().isAfter(getProcessDateTime().getDate())) {
			//		
			//		// Delete Char
			//		logger.info("removeSAChar");
			//		saChars.remove(saChar);
			//		
			//	}
				
			}
			
		}
		
		// Add SA Char
		addSAChar(saChars, getProcessDateTime().getDate(), getSaCharType(), getSaCharVal().toString());
		return;
		
	}
	
	private Bool deleteFutureDatedChars(ServiceAgreement sa) {
		
		ServiceAgreementCharacteristics saChars = sa.getCharacteristics();
		
		Iterator iter1 = saChars.iterator();
		while (iter1.hasNext()) {
			ServiceAgreementCharacteristic saChar = (ServiceAgreementCharacteristic) iter1.next();
			String saCharValue = getActualSACharValue(saChar);
			CharacteristicType saCharType =  saChar.getId().getCharacteristicTypeId().getEntity();
			
			// logger.info(saChar.fetchIdEffectiveDate() + "/" + saChar.fetchIdCharacteristicType().getId().getIdValue() + "/" + saChar.getAdhocCharacteristicValue()
			//		+ "/" + saChar.getCharacteristicValue());
			
			if (saChar.fetchIdEffectiveDate().isSameOrAfter(getProcessDateTime().getDate())
					&& saChar.fetchIdCharacteristicType().equals(getSaCharType())) {
				
				// Effective Date is in the future
				if (saChar.fetchIdEffectiveDate().isAfter(getProcessDateTime().getDate())) {
					
					// Delete Char
					// logger.info("removeSAChar");
					saChars.remove(saChar);
					return Bool.TRUE;
					
				}
				
			}
			
		}
		
		return Bool.FALSE;
		
	}

	private Bool doesSACharExist(ServiceAgreement sa, CharacteristicType charType, Date effDate) {
		
		PreparedStatement getSetOfRecordsStatement = null;

		// Process all Active, Pending Start and Pending Stop SAs of the Account regardless of whether they are in collections or not.
		if (isNull(effDate)) {

			getSetOfRecordsStatement = createPreparedStatement(
					" SELECT SA_ID "
							+ " FROM CI_SA_CHAR "
							+ " WHERE SA_ID = :inSAId "
							//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
							//	+ "   AND CHAR_TYPE_CD = :inCharType "
							//	);
							+ "   AND CHAR_TYPE_CD = :inCharType " , getClass().getName());
							//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
			
			getSetOfRecordsStatement.bindId("inSAId", sa.getId());
			getSetOfRecordsStatement.bindString("inCharType", charType.getId().getTrimmedValue(), "CHAR_TYPE_CD");

		} else {

			getSetOfRecordsStatement = createPreparedStatement(
					" SELECT SA_ID "
							+ " FROM CI_SA_CHAR "
							+ " WHERE SA_ID = :inSAId "
							+ "   AND CHAR_TYPE_CD = :inCharType "
							//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
						//	+ "   AND EFFDT = :inEffDt "
				//	);
							+ "   AND EFFDT = :inEffDt " , getClass().getName());
			//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
			getSetOfRecordsStatement.bindId("inSAId", sa.getId());
			getSetOfRecordsStatement.bindString("inCharType", charType.getId().getTrimmedValue(), "CHAR_TYPE_CD");
			getSetOfRecordsStatement.bindDate("inEffDt", effDate);
			
		}
		
		Bool returnValue = Bool.FALSE;
		if (getSetOfRecordsStatement.list().isEmpty()) {
			returnValue = Bool.FALSE;
		} else {
			returnValue = Bool.TRUE;
		}
			
		return returnValue;

	}

}