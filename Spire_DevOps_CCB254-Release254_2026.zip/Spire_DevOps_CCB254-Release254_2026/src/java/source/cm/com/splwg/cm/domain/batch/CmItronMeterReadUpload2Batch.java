/*
 ***********************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * CCB015.1 - Itron Meter Read Upload
 *
 ***********************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2020-04-03   NMendo          CCB015.1. Initial Version.
 * 2021-03-02   NMendo          CCB015.Issue1. Create a MR Remark staging record if 
 *                              MeterSessionOutput.TroubleCode1 and/or 
 *                              MeterSessionOutput.TroubleCode1 is provided.
 * 2021-03-17   NMendo          CCB015.Issue2. Fix issue when input line ends with the delimiter.
 * 2021-03-19   NMendo          CCB015.Issue3. Do not populate Meter Configuration ID if not
 *                              provided. If the skip read is 0, 2 or 99, set Register Read value
 *                              to 0.
 * 2021-04-23   NMendo          CCB015.Issue4. Records without a Read Date is excluded from 
 *                              processing. Replace characteristic type parameters with service 
 *                              task type. Fix issue when meter does not exists.
 * 2021-04-30   NMendo          CCB015.Issue5. Fix for performance issue.
 * 2021-06-16   NMendo          CCB015.Issue6. Link associated Register Reads to Same MR Stage 
 *                              Record. Update validation in checking for existing MR Staging 
 *                              record for the same Meter Configuration ID and Read Date/Time.
 * 2021-06-21   NMendo          CCB015.Issue7. Add checking if Read Sequence exists for the 
 *                              previous MR Upload Staging.
 * 2022-04-01   ASaped          B-20753. Set the HILO_REV_SW to 'N' for specified UOM codes.
 * 2025-09-22   JVitug          E-11558. Updated to now get the meter configuration that can
 *                              handle the inbound register reading from the input file.
 ***********************************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.api.lookup.MeterReadUploadStatusLookup;
import com.splwg.ccb.api.lookup.ReadTypeLookup;
import com.splwg.ccb.domain.admin.meterReadSource.entity.MeterReadSource;
import com.splwg.ccb.domain.admin.meterReaderRemark.entity.MeterReaderRemark_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_DTO;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterReadUpload.entity.MeterReadUpload;
import com.splwg.ccb.domain.meterread.meterReadUpload.entity.MeterReadUpload_DTO;
import com.splwg.ccb.domain.meterread.meterReadUpload.entity.MeterReadUpload_Id;
import com.splwg.ccb.domain.meterread.meterReadUpload.entity.ReaderRemarkUpload;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author NMendo
 *
 @BatchJob (
 *      modules = {},    
 *      multiThreaded = false, 
 *      rerunnable = true,
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = meterReadSource, name = DEFAULT_MR_SOURCE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = ITRON_SERVICE_TASK, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = UOM_CD, required = false, type = string)})
 */
public class CmItronMeterReadUpload2Batch extends
		CmItronMeterReadUpload2Batch_Gen {
    // 2022-04-01. ASaped. B-20753. Start Add
    private String strRvwExemptUomCd;
    // 2022-04-01. ASaped. B-20753. End Add	
	@Override
	public JobWork getJobWork() {
		ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
		arrayList.add(threadWorkUnit);

		return createJobWorkForThreadWorkUnitList(arrayList);
	}

	public Class<CmItronMeterReadUpload2BatchWorker> getThreadWorkerClass() {
		return CmItronMeterReadUpload2BatchWorker.class;
	}
	
	@Override
	public void validateSoftParameters(boolean arg0){
		// Retrieve Soft Parameters
		String parmFilePath  = getParameters().getFILE_PATH().trim();
		String parmFileName = getParameters().getFILE_NAME().trim();
		// Start Delete - NMendo - CCB015.Issue4 -  2021-04-23
		//CharacteristicType parmSkipCodeCharTy = getParameters().getSKIP_CODE_CHAR_TY();
		//CharacteristicType parmTamper1CharTy = getParameters().getTAMPER1_CHAR_TY();
		//CharacteristicType parmTamper2CharTy = getParameters().getTAMPER2_CHAR_TY();
		// End Delete - NMendo - CCB015.Issue4 -  2021-04-23
		
		// Validate that the file path exist.
		File folder = new File(parmFilePath);
		if(!(folder.exists() && folder.isDirectory())) {
			addError(CustomMessageRepositorySpireOne.ccb015_1InvalidFilePath(parmFilePath));  
		}

		// Validate that the parameter FILE_NAME is a correct file name and that the corresponding file can be opened and read.
		File inputFile = new File(parmFilePath, parmFileName);
		if(!inputFile.exists() || !inputFile.canRead()){
			addError(CustomMessageRepositorySpireOne.ccb015_1InvalidFileName(parmFileName)); 
		}
		
		// Start Delete - NMendo - CCB015.Issue4 -  2021-04-23
		// Validate skip code characteristic type against meter read and meter read upload staging
		//validateCharTypeEntity(parmSkipCodeCharTy, CharacteristicEntityLookup.constants.METER_READ);
		//validateCharTypeEntity(parmSkipCodeCharTy, CharacteristicEntityLookup.constants.METER_READ_UPLOAD_STAGING);
		
		// Validate tamper1 characteristic type against meter read and meter read upload staging
		//validateCharTypeEntity(parmTamper1CharTy, CharacteristicEntityLookup.constants.METER_READ);
		//validateCharTypeEntity(parmTamper1CharTy, CharacteristicEntityLookup.constants.METER_READ_UPLOAD_STAGING);

		// Validate tamper2 characteristic type against meter read and meter read upload staging
		//validateCharTypeEntity(parmTamper2CharTy, CharacteristicEntityLookup.constants.METER_READ);
		//validateCharTypeEntity(parmTamper2CharTy, CharacteristicEntityLookup.constants.METER_READ_UPLOAD_STAGING);
		// End Delete - NMendo - CCB015.Issue4 -  2021-04-23
		
        // 2022-04-01. ASaped. B-20753. Start Add        
        // Validate review exempt UOM
        UnitOfMeasure_Id unitOfMeasureId;
        strRvwExemptUomCd = getParameters().getUOM_CD();
        for (String uomIdValue : strRvwExemptUomCd.split(",")) {
            
            if (uomIdValue.trim().length() > UnitOfMeasure_Id.FIELD_SIZE) {
                addError(CustomMessageRepositorySpireOne.ccb015_1InvalidUnitOfMeasure(uomIdValue.trim()));
            }
            
            unitOfMeasureId = new UnitOfMeasure_Id(uomIdValue.trim());
            
            if (isNull(unitOfMeasureId.getEntity())) {
                addError(CustomMessageRepositorySpireOne.ccb015_1InvalidUnitOfMeasure(unitOfMeasureId.getTrimmedValue()));
            }
        }
        // 2022-04-01. ASaped. B-20753. End Add
	}
	
	/**
	 * This method validates Characteristic Type against specific Entity
	 * @param charType
	 * @param charEntityLookup
	 */
	// Start Delete - NMendo - CCB015.Issue4 -  2021-04-23
	//private void validateCharTypeEntity(CharacteristicType charType, CharacteristicEntityLookup charEntityLookup) {
	//	CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, charEntityLookup);
	//
	//	if (isNull(charEntityId.getEntity())) {
	//		addError(CustomMessageRepositorySpireOne.ccb015_1InvalidCharTypeForEntity(charType.getId().getTrimmedValue(), 
	//				charEntityLookup.getLookupValue().fetchLanguageDescription()));
	//	}
	//}
	// End Delete - NMendo - CCB015.Issue4 -  2021-04-23

	public static class CmItronMeterReadUpload2BatchWorker extends
			CmItronMeterReadUpload2BatchWorker_Gen {
	
		// Soft Parameters
		private String parmFilePath;
		private String parmFileName;
		private MeterReadSource parmDefaultMrSourceCd;
		// Start Add - NMendo - CCB015.Issue4 -  2021-04-23
		private ServiceTaskType itronServiceTaskType;
		// End Add - NMendo - CCB015.Issue4 -  2021-04-23

		// Working Variables
		private int recordsProcessed;
		private int recordsInError;
		private File inputFile = null;
		private BufferedReader inputBufferReader = null;
		private MeterReadUpload meterReadUpload = null;
		private String lineNumStr;
		private MeterConfiguration_Id meterConfigId;
		private DateTime readDttm;
		private BigInteger readSeq;
		private UnitOfMeasure_Id uomId;
		private ReadTypeLookup readType;
		private BigDecimal registerReading;
		private BigInteger meterCycleRouteSeq;
		private Bool hasError;
		// Start Add - NMendo - 2021-03-19 - CCB015.Issue3
		private MeterConfiguration_Id derivedMeterConfigId;
		// End Add - NMendo - 2021-03-19 - CCB015.Issue3
		// Start Add - NMendo - CCB015.Issue4 -  2021-04-23
		private Bool shouldSkipRecord;
		private CharacteristicType parmSkipCodeCharTy;
		private CharacteristicType parmTamper1CharTy;
		private CharacteristicType parmTamper2CharTy;
		// End Add - NMendo - CCB015.Issue4 -  2021-04-23
		// Start Add - NMendo - CCB015.Issue5 -  2021-04-30
		private MeterReadUpload_Id meterReadUploadId;
		// Start Add - NMendo - CCB015.Issue5 -  2021-04-30
		// Start Add - NMendo - CCB015.Issue6 -  2021-06-16
		private MeterReadUpload_Id prevMeterReadUploadId;
		private String prevBadgeNumber;
		private Date prevReadDate;
		// Start Delete - NMendo - CCB015.Issue7 -  2021-06-21
		//private BigInteger prevReadSeq;
		// End Delete - NMendo - CCB015.Issue7 -  2021-06-21
		private BigDecimal maxIntervalRegReadDttm;
		// End Add - NMendo - CCB015.Issue6 -  2021-06-16
        // 2022-04-01. ASaped. B-20753. Start Add
        private String strRvwExemptUomCd;
        private List<UnitOfMeasure_Id> reviewExemptRegisterUoms = new ArrayList<UnitOfMeasure_Id>();
        // 2022-04-01. ASaped. Defect 3294833. End Add       
        //Start Add JVitug - E-11558 - 2025-09-22
        BigInteger numberOfDigitsLeft = BigInteger.ZERO;
        //End Add JVitug - E-11558 - 2025-09-22
		
		// File columns
		private String meter_MeterNumber;
		private String meter_SealNumber;
		private String meter_CustomDataField_CustomData;
		private String meterChangedFields_ChangedUtilityMeterSeqNum;
		private String meterSessionOutput_Read;
		private String meterSessionOutput_ReadDateTime;
		private String meterSessionOutput_ReadCode;
		private String meterSessionOutput_SkipCode;
		private String meterSessionOutput_DataCollectorUserID;
		private String meterSessionOutputRF_TamperCount1;
		private String meterSessionOutputRF_TamperCount2;
		private String meterSessionOutputRF_TamperCount1ChangedFlag;
		private String meterSessionOutputRF_TamperCount2ChangedFlag;
		// Start Add - NMendo - 2021-03-02 - CCB015.Issue1
		private String meterSessionOutput_TroubleCode1;
		private String meterSessionOutput_TroubleCode2;
		// End Add - NMendo - 2021-03-02 - CCB015.Issue1

		// Constants
		private static final String DELIMETER = ",";
		private static final String CONST_TRUE = "TRUE";
		private static final int COLUMN_COUNT = 62;
		private static final int METER_METERNUMBER_IDX = 6;
		private static final int METER_SEALNUMBER_IDX = 13;
		private static final int METER_CUSTOMDATAFIELD_CUSTOMDATA_IDX = 14;
		private static final int METERCHANGEDFIELDS_CHANGEDUTILITYMETERSEQNUM_IDX = 16;
		private static final int METERSESSIONOUTPUT_READ_IDX = 41;
		private static final int METERSESSIONOUTPUT_READDATETIME_IDX = 43;
		private static final int METERSESSIONOUTPUT_READCODE_IDX = 44;
		private static final int METERSESSIONOUTPUT_SKIPCODE_IDX = 47;
		// Start Add - NMendo - 2021-03-02 - CCB015.Issue1
		private static final int METERSESSIONOUTPUT_TROUBLECODE1_IDX = 49;
		private static final int METERSESSIONOUTPUT_TROUBLECODE2_IDX = 50;
		// End Add - NMendo - 2021-03-02 - CCB015.Issue1
		private static final int METERSESSIONOUTPUT_DATACOLLECTORUSERID_IDX = 52;
		private static final int METERSESSIONOUTPUTRF_TAMPERCOUNT1_IDX = 58;
		private static final int METERSESSIONOUTPUTRF_TAMPERCOUNT2_IDX = 59;
		private static final int METERSESSIONOUTPUTRF_TAMPERCOUNT1CHANGEDFLAG_IDX = 60;
		private static final int METERSESSIONOUTPUTRF_TAMPERCOUNT2CHANGEDFLAG_IDX = 61;
		private static final String ITRON_DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
		private static final String DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
		private static final String[] REGULAR_READ_CODES = {"1", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17"};
		private static final String[] NO_READ_CODES = {"0", "2", "99"};
		private static final String READ_CODE_2 = "2";
		private static final String SKIP_CODE_QR = "QR";
		private static final String METER_METERNUMBER_CONST = "Meter.MeterNumber";
		// Start Delete - NMendo - 2021-03-19 - CCB015.Issue3
		//private static final String METER_CUSTOMDATAFIELD_CUSTOMDATA_CONST = "Meter.CustomDataField.CustomData";
		// End Delete - NMendo - 2021-03-19 - CCB015.Issue3
		// Start Delete - NMendo - CCB015.Issue4 -  2021-04-23
		//private static final String METERSESSIONOUTPUT_READDATETIME_CONST= "MeterSessionOutput.ReadDateTime";
		// End Delete - NMendo - CCB015.Issue4 -  2021-04-23
		private static final String METER_SEALNUMBER_CONST = "Meter.SealNumber";
		private static final String METERSESSIONOUTPUT_READCODE_CONST = "MeterSessionOutput.ReadCode";
		private static final String METERSESSIONOUTPUT_READ_CONST = "MeterSessionOutput.Read";
		private static final String METERSESSIONOUTPUTRF_TAMPERCOUNT1_CONST = "MeterSessionOutputRF.TamperCount1";
		private static final String METERSESSIONOUTPUTRF_TAMPERCOUNT2_CONST = "MeterSessionOutputRF.TamperCount2";
		private static final String METERSESSIONOUTPUTRF_TAMPERCOUNT1CHANGEDFLAG_CONST = "MeterSessionOutputRF.TamperCount1ChangedFlag";
		private static final String METERSESSIONOUTPUTRF_TAMPERCOUNT2CHANGEDFLAG_CONST = "MeterSessionOutputRF.TamperCount2ChangedFlag";

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}
		
		@Override
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			// Initialize Soft Parameters
			initializeInputParameters();
			
			// Open the file
			openFile();
			
			// Process the file
			processFile();

			// Set units processed and in error
			WorkUnitResult workUnitResult = new WorkUnitResult(true);
			workUnitResult.setUnitsProcessed(recordsProcessed);
			workUnitResult.setUnitsInError(recordsInError);

			// Close the file
			closeFile();
			
			return workUnitResult; 
		}
		
		/**
		 * Initializing the batch input parameters
		 */
		private void initializeInputParameters() {
			parmFilePath  = getParameters().getFILE_PATH().trim();
			parmFileName = getParameters().getFILE_NAME().trim();
            // 2022-04-01. ASaped. B-20753. Start Add        
            strRvwExemptUomCd = getParameters().getUOM_CD();
            
            UnitOfMeasure_Id unitOfMeasureId;
            for (String uomIdValue : strRvwExemptUomCd.split(",")) {
                unitOfMeasureId = new UnitOfMeasure_Id(uomIdValue.trim());
                reviewExemptRegisterUoms.add(unitOfMeasureId);            
            }
            // 2022-04-01. ASaped. B-20753. End Add  
	        
			parmDefaultMrSourceCd = getParameters().getDEFAULT_MR_SOURCE_CD();
			// Start Change - NMendo - CCB015.Issue4 -  2021-04-23
			//parmSkipCodeCharTy = getParameters().getSKIP_CODE_CHAR_TY();
			//parmTamper1CharTy = getParameters().getTAMPER1_CHAR_TY();
			//parmTamper2CharTy = getParameters().getTAMPER2_CHAR_TY();
			itronServiceTaskType = getParameters().getITRON_SERVICE_TASK();
			
			BusinessObjectInstance placementBoInstance = BusinessObjectInstance.create(itronServiceTaskType.getBusinessObject());
			placementBoInstance.setXMLString("serviceTaskType",itronServiceTaskType.getId().getTrimmedValue());
			placementBoInstance = BusinessObjectDispatcher.read(placementBoInstance);	

			COTSInstanceNode itronDetailInstruction = placementBoInstance.getGroup("itronDetails");
			COTSInstanceNode mrCharTypes = itronDetailInstruction.getGroup("mrCharTypes");
			String skipCodeCharTypeStr = mrCharTypes.getString("skipCodeCharType").trim();
			String tamper1CharTypeStr = mrCharTypes.getString("tamper1CharType").trim();
			String tamper2CharTypeStr = mrCharTypes.getString("tamper2CharType").trim();
			
			parmSkipCodeCharTy = new CharacteristicType_Id(skipCodeCharTypeStr).getEntity();
			parmTamper1CharTy = new CharacteristicType_Id(tamper1CharTypeStr).getEntity();
			parmTamper2CharTy = new CharacteristicType_Id(tamper2CharTypeStr).getEntity();
			// End Change - NMendo - CCB015.Issue4 -  2021-04-23
			
			// Start Add - NMendo - CCB015.Issue6 -  2021-06-16
			COTSInstanceNode itronParameter = itronDetailInstruction.getGroup("itronParameter");
			maxIntervalRegReadDttm = itronParameter.getNumber("maxIntervalRegReadDttm");
			// End Add - NMendo - CCB015.Issue6 -  2021-06-16
			
			inputFile = new File(parmFilePath, parmFileName);
		}
		
		/**
		 * This method opens a buffered reader for input file
		 */
		private void openFile() {
			try {                          
				inputBufferReader = new BufferedReader(new FileReader(inputFile));                    
			} catch (IOException e) {                
				throw new RunAbortedException(CustomMessageRepositorySpireOne.ccb015_1ErrorInFile(e.getMessage().trim()));                                      
			} 
		}
		 
		/**
		 * This method closes a buffered reader for input file
		 */
		private void closeFile() {
			try {
				if(notNull(inputBufferReader)) {
					inputBufferReader.close();
				}
			} catch (IOException e) {
				throw new RunAbortedException(CustomMessageRepositorySpireOne.ccb015_1ErrorInFile(e.getMessage().trim()));                                        
			}
		}   

		/**
		 * This method returns the next record from the input file.
		 * @return String
		 */
		private String readRecord() {
			String record = null;
			try {
				record =  inputBufferReader.readLine();                 
			} catch (IOException exception) {
				throw new RunAbortedException(CustomMessageRepositorySpireOne.ccb015_1ErrorInFile(exception.getMessage().trim()));  
			}  
			return record;
		}
		
		/**
		 * This method will process the input file.
		 */
		private void processFile() {
			recordsProcessed = 0;
			recordsInError = 0;
			int lineNum = 1;
			// First row is the Header, skip processing
			readRecord();
			 
			String record = null;
			while(!isBlankOrNull(record = readRecord())) {
				lineNum++;
				lineNumStr = String.valueOf(lineNum);
				// Process each record
				// Start Add - NMendo - 2021-03-17 - CCB015.Issue2
				//String[] recordSplitted = record.split(DELIMETER);
				String[] recordSplitted = record.split(DELIMETER, -1);
				// End Add - NMendo - 2021-03-17 - CCB015.Issue2
				// Start Add - NMendo - CCB015.Issue4 -  2021-04-23
				recordsProcessed++;
				// End Add - NMendo - CCB015.Issue4 -  2021-04-23
				
				if(recordSplitted.length == COLUMN_COUNT) {
					hasError = Bool.FALSE;
					// Start Add - NMendo - CCB015.Issue4 -  2021-04-23
					shouldSkipRecord = Bool.FALSE;
					// End Add - NMendo - CCB015.Issue4 -  2021-04-23
					validateInput(recordSplitted);
					
					// Skip if there is an error in the record
					if(hasError.isFalse()) {
						// Start Add - NMendo - CCB015.Issue4 -  2021-04-23
						if(shouldSkipRecord.isFalse()) {
						// End Add - NMendo - CCB015.Issue4 -  2021-04-23
							
							// Start Add - NMendo - CCB015.Issue6 -  2021-06-16
							if(meter_MeterNumber.equals(prevBadgeNumber)
									&& readDttm.getDate().equals(prevReadDate)
									// Start Change - NMendo - CCB015.Issue7 -  2021-06-21
									//&& !readSeq.equals(prevReadSeq)) {
									&& isRegisterSeqExists(prevMeterReadUploadId, readSeq).isFalse()) {
									// End Change - NMendo - CCB015.Issue7 -  2021-06-21
								meterReadUploadId = prevMeterReadUploadId;
								addRegisterReadUploadStagingRecord();
							
							} else {
							// End Add - NMendo - CCB015.Issue6 -  2021-06-16
								addMeterReadUploadStagingRecord();
								addRegisterReadUploadStagingRecord();
								addMeterReadUploadChars();
								
								// Start Add - NMendo - 2021-03-02 - CCB015.Issue1
								addMeterReadRemarks();
								// End Add - NMendo - 2021-03-02 - CCB015.Issue1
								
								// Start Change - NMendo - 2021-03-19 - CCB015.Issue3
								//if(!isBlankOrNull(meterChangedFields_ChangedUtilityMeterSeqNum) {
								if(!isBlankOrNull(meterChangedFields_ChangedUtilityMeterSeqNum)
										&& (notNull(meterConfigId) || notNull(derivedMeterConfigId))) {
								// End Change - NMendo - 2021-03-19 - CCB015.Issue3
									updateMeterCycleRouteSeq();
								}
							// Start Add - NMendo - CCB015.Issue6 -  2021-06-16
							}
							
							prevMeterReadUploadId = meterReadUploadId;
							prevBadgeNumber = meter_MeterNumber;
							prevReadDate = readDttm.getDate();
							// Start Delete - NMendo - CCB015.Issue7 -  2021-06-21
							//prevReadSeq = readSeq;
							// End Delete - NMendo - CCB015.Issue7 -  2021-06-21
							// End Add - NMendo - CCB015.Issue6 -  2021-06-16
						}
						// Start Delete - NMendo - CCB015.Issue4 -  2021-04-23
						//recordsProcessed++;
						// End Delete - NMendo - CCB015.Issue4 -  2021-04-23
					} else {
						recordsInError++;
					}
					
				} else {
					recordsInError++;
					logError(CustomMessageRepositorySpireOne.ccb015_1InvalidColumnCount(lineNumStr, String.valueOf(COLUMN_COUNT))); 
				}
			}
		}
		
		/**
		 * This method will validate if the required inputs are missing
		 * @param recordSplitted
		 */
		private void validateInput(String[] recordSplitted) {
			// Initialize variables
			meter_MeterNumber = "";
			meter_SealNumber = "";
			meter_CustomDataField_CustomData = "";
			meterChangedFields_ChangedUtilityMeterSeqNum = "";
			meterSessionOutput_Read = "";
			meterSessionOutput_ReadDateTime = "";
			meterSessionOutput_ReadCode = "";
			meterSessionOutput_SkipCode = "";
			meterSessionOutput_DataCollectorUserID = "";
			meterSessionOutputRF_TamperCount1 = "";
			meterSessionOutputRF_TamperCount2 = "";
			meterSessionOutputRF_TamperCount1ChangedFlag = "";
			meterSessionOutputRF_TamperCount2ChangedFlag = "";
			// Start Add - NMendo - 2021-03-02 - CCB015.Issue1
			meterSessionOutput_TroubleCode1 = "";
			meterSessionOutput_TroubleCode2 = "";
			// End Add - NMendo - 2021-03-02 - CCB015.Issue1
			
			// Retrieve field values
			meter_MeterNumber = recordSplitted[METER_METERNUMBER_IDX].trim();
			meter_SealNumber = recordSplitted[METER_SEALNUMBER_IDX].trim();
			meter_CustomDataField_CustomData = recordSplitted[METER_CUSTOMDATAFIELD_CUSTOMDATA_IDX].trim();
			meterChangedFields_ChangedUtilityMeterSeqNum = recordSplitted[METERCHANGEDFIELDS_CHANGEDUTILITYMETERSEQNUM_IDX].trim();
			meterSessionOutput_Read = recordSplitted[METERSESSIONOUTPUT_READ_IDX].trim();
			meterSessionOutput_ReadDateTime = recordSplitted[METERSESSIONOUTPUT_READDATETIME_IDX].trim();
			meterSessionOutput_ReadCode = recordSplitted[METERSESSIONOUTPUT_READCODE_IDX].trim();
			meterSessionOutput_SkipCode = recordSplitted[METERSESSIONOUTPUT_SKIPCODE_IDX].trim();
			meterSessionOutput_DataCollectorUserID = recordSplitted[METERSESSIONOUTPUT_DATACOLLECTORUSERID_IDX].trim();
			meterSessionOutputRF_TamperCount1 = recordSplitted[METERSESSIONOUTPUTRF_TAMPERCOUNT1_IDX].trim();
			meterSessionOutputRF_TamperCount2 = recordSplitted[METERSESSIONOUTPUTRF_TAMPERCOUNT2_IDX].trim();
			meterSessionOutputRF_TamperCount1ChangedFlag = recordSplitted[METERSESSIONOUTPUTRF_TAMPERCOUNT1CHANGEDFLAG_IDX].trim();
			meterSessionOutputRF_TamperCount2ChangedFlag = recordSplitted[METERSESSIONOUTPUTRF_TAMPERCOUNT2CHANGEDFLAG_IDX].trim();
			// Start Add - NMendo - 2021-03-02 - CCB015.Issue1
			meterSessionOutput_TroubleCode1 = recordSplitted[METERSESSIONOUTPUT_TROUBLECODE1_IDX].trim();
			meterSessionOutput_TroubleCode2 = recordSplitted[METERSESSIONOUTPUT_TROUBLECODE2_IDX].trim();
			// End Add - NMendo - 2021-03-02 - CCB015.Issue1
			
			// Check if Meter.MeterNumber is blank.
			if(isBlankOrNull(meter_MeterNumber)) {
				hasError = Bool.TRUE;
				logError(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(lineNumStr, METER_METERNUMBER_CONST)); 
			}
			
			// Start Delete - NMendo - 2021-03-19 - CCB015.Issue3
			// Check if Meter.CustomDataField.CustomData is blank.
			//if(isBlankOrNull(meter_CustomDataField_CustomData)) {
				//hasError = Bool.TRUE;
				//logError(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(lineNumStr, METER_CUSTOMDATAFIELD_CUSTOMDATA_CONST)); 
			//}
			// End Delete - NMendo - 2021-03-19 - CCB015.Issue3
			
			// Check if MeterSessionOutput.ReadDateTime is blank.
			if(isBlankOrNull(meterSessionOutput_ReadDateTime)) {
				// Start Change - NMendo - CCB015.Issue4 -  2021-04-23
				//hasError = Bool.TRUE;
				//logError(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(lineNumStr, METERSESSIONOUTPUT_READDATETIME_CONST));
				shouldSkipRecord = Bool.TRUE;
				return;
				// End Change - NMendo - CCB015.Issue4 -  2021-04-23
			}
			
			// Check if Meter.SealNumber is blank.
			if(isBlankOrNull(meter_SealNumber)) {
				hasError = Bool.TRUE;
				logError(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(lineNumStr, METER_SEALNUMBER_CONST)); 
			}
			
			// Check if MeterSessionOutput.ReadCode is blank.
			if(isBlankOrNull(meterSessionOutput_ReadCode)) {
				hasError = Bool.TRUE;
				logError(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(lineNumStr, METERSESSIONOUTPUT_READCODE_CONST)); 
			}
			
			// Start Add - NMendo - 2021-03-19 - CCB015.Issue3
			List<String> noReadCodeList = Arrays.asList(NO_READ_CODES);
			if(noReadCodeList.contains(meterSessionOutput_ReadCode) && isBlankOrNull(meterSessionOutput_Read)) {
				meterSessionOutput_Read = "0";
			}
			// End Add - NMendo - 2021-03-19 - CCB015.Issue3
			
			// Check if MeterSessionOutput.Read is blank.
			if(isBlankOrNull(meterSessionOutput_Read)) {
				hasError = Bool.TRUE;
				logError(CustomMessageRepositorySpireOne.ccb015_1InputCannotBeBlank(lineNumStr, METERSESSIONOUTPUT_READ_CONST)); 
			}
			
			if(hasError.isFalse()) {
				setAndValidateFieldValues();
			}
		}

		/**
		 * This method will set and validate the record
		 */
		private void setAndValidateFieldValues() {
			// Initialize variables
			meterConfigId = null;
			uomId = null;
			readDttm = null;
			readType = null;
			readSeq = BigInteger.ZERO;
			registerReading = BigDecimal.ZERO;
			meterCycleRouteSeq = BigInteger.ZERO;
			
			//Start Add JVitug - E-11558 - 2025-09-22 
			//Relocated the reading of the register read here as it is now needed to validate the meter configuration ID
			// Set and Validate MeterSessionOutput.Read / Register Reading
			try {
				registerReading = new BigDecimal(meterSessionOutput_Read);
			} catch(NumberFormatException e) {
				hasError = Bool.TRUE;
				logError(CustomMessageRepositorySpireOne.ccb015_1RegisterReadingInvalid(lineNumStr, meterSessionOutput_Read));
			}
			
			numberOfDigitsLeft = BigInteger.valueOf(registerReading.toString().length());
			//End Add JVitug - E-11558 - 2025-09-22
			
			// Validate Meter.MeterNumber / Badge Number
			validateBadgeNumber();
			// Set and Validate Meter.CustomDataField.CustomData / Meter Configuration
			// Start Add - NMendo - 2021-03-19 - CCB015.Issue3
			if(!isBlankOrNull(meter_CustomDataField_CustomData)) {
			// End Add - NMendo - 2021-03-19 - CCB015.Issue3
				meterConfigId = new MeterConfiguration_Id(meter_CustomDataField_CustomData);
				if(isNull(meterConfigId.getEntity())) {
					hasError = Bool.TRUE;
	        		logError(CustomMessageRepositorySpireOne.ccb015_1MeterConfigInvalid(lineNumStr, meter_CustomDataField_CustomData)); 
				} else {
					validateBadgeNumberWithMeterConfig();
				}
			// Start Add - NMendo - 2021-03-19 - CCB015.Issue3
			}
			// End Add - NMendo - 2021-03-19 - CCB015.Issue3
			
			// Set and Validate Meter.SealNumber
			if(meter_SealNumber.length() > 1) {
				String readSeqStr = meter_SealNumber.substring(0, 1);
				String uomStr = meter_SealNumber.substring(1);
				
				// Set and Validate Read Sequence
				try {
					readSeq = new BigInteger(readSeqStr);
				} catch(NumberFormatException e) {
					hasError = Bool.TRUE;
	        		logError(CustomMessageRepositorySpireOne.ccb015_1ReadSeqInvalid(lineNumStr, readSeqStr)); 
				}
				
				// Set and Validate Unit of Measure
				uomId = new UnitOfMeasure_Id(uomStr);
				if(isNull(uomId.getEntity())) {
					hasError = Bool.TRUE;
	        		logError(CustomMessageRepositorySpireOne.ccb015_1UnitOfMeasureInvalid(lineNumStr, uomStr));
				}
				
			} else {
				hasError = Bool.TRUE;
				logError(CustomMessageRepositorySpireOne.ccb015_1MeterSealNumberInvalid(lineNumStr, meter_SealNumber));
			}
			
			//Start Add JVitug - E-11558 - 2025-09-22
			//We now also validate that the meter configuration from the file can handle the meter read being entered.
			//If not, we derive the meter configuration
			if(notNull(meterConfigId)) {
				validateMeterConfigCanHandleRead();
			}
			//End Add JVitug - E-11558 - 2025-09-22
			
			DateFormat itronDateTimeFormat = new DateFormat(ITRON_DATETIME_FORMAT);
			// Set and Validate MeterSessionOutput.ReadDateTime / Read Date Time
			try {
				readDttm = itronDateTimeFormat.parseDateTime(meterSessionOutput_ReadDateTime);
			} catch (DateFormatParseException e) {
				hasError = Bool.TRUE;
        		logError(CustomMessageRepositorySpireOne.ccb015_1ReadDttmInvalid(lineNumStr, meterSessionOutput_ReadDateTime, ITRON_DATETIME_FORMAT)); 
        	}
			
			// Verify there is not an existing MR Staging record for the same Meter Configuration ID and Read Date/Time.
			if(notNull(meterConfigId) && notNull(readDttm)) {
				checkForExistingMRStagingRecord();
			}
			
			// Start Add - NMendo - 2021-03-19 - CCB015.Issue3
			// Verify there is not an existing MR Staging record for the same Badge Number and Read Date/Time.
			if(isNull(meterConfigId) && notNull(readDttm)) {
				checkForExistingMRStagingRecordUsingBadgeNumber();
			}
			// End Add - NMendo - 2021-03-19 - CCB015.Issue3
			
			// Set and Validate MeterSessionOutput.ReadCode / Read Type Flag
			List<String> regularReadCodeList = Arrays.asList(REGULAR_READ_CODES);
			List<String> noReadCodeList = Arrays.asList(NO_READ_CODES);
			if(regularReadCodeList.contains(meterSessionOutput_ReadCode)) {
				readType = ReadTypeLookup.constants.REGULAR;
			} else if(meterSessionOutput_ReadCode.equals(READ_CODE_2) 
					&& meterSessionOutput_SkipCode.equals(SKIP_CODE_QR)) {
				readType = ReadTypeLookup.constants.REGULAR;
			} else if(noReadCodeList.contains(meterSessionOutput_ReadCode)) {
				readType = ReadTypeLookup.constants.NO_READ;
			} else {
				hasError = Bool.TRUE;
				logError(CustomMessageRepositorySpireOne.ccb015_1ReadCodeInvalid(lineNumStr, meterSessionOutput_ReadCode));
			}
			
			//Start delete JVitug - E-11558 - 2025-09-22
			// Set and Validate MeterSessionOutput.Read / Register Reading
			//Deleting this part as this block is relocated to the earlier parts of this method
			//try {
				//registerReading = new BigDecimal(meterSessionOutput_Read);
			//} catch(NumberFormatException e) {
				//hasError = Bool.TRUE;
				//logError(CustomMessageRepositorySpireOne.ccb015_1RegisterReadingInvalid(lineNumStr, meterSessionOutput_Read));
			//}
			//End delete JVitug - E-11558 - 2025-09-22
			
			// Set and Validate MeterChangedFields.ChangedUtilityMeterSeqNum / Meter Cycle/Route Sequence
			if(!isBlankOrNull(meterChangedFields_ChangedUtilityMeterSeqNum)) {
				try {
					meterCycleRouteSeq = new BigInteger(meterChangedFields_ChangedUtilityMeterSeqNum);
				} catch(NumberFormatException e) {
					hasError = Bool.TRUE;
					logError(CustomMessageRepositorySpireOne.ccb015_1MeterCycRouteSeqInvalid(lineNumStr, meterChangedFields_ChangedUtilityMeterSeqNum));
				}
			}
			
			// Validate MeterSessionOutput.DataCollectorUserID / Meter Reader
			if(meterSessionOutput_DataCollectorUserID.length() >= 20) {
				hasError = Bool.TRUE;
				logError(CustomMessageRepositorySpireOne.ccb015_1MeterReaderInvalid(lineNumStr, meterSessionOutput_DataCollectorUserID));
			}
			
			// Validate MeterSessionOutputRF.TamperCount1
			if(meterSessionOutputRF_TamperCount1ChangedFlag.equalsIgnoreCase(CONST_TRUE)
					&& readSeq.compareTo(BigInteger.ONE) == 0) {
				// MeterSessionOutputRF.TamperCount1 cannot be blank if MeterSessionOutputRF.TamperCount1ChangedFlag is TRUE and Read Seq is 1
				if(isBlankOrNull(meterSessionOutputRF_TamperCount1)) {
					hasError = Bool.TRUE;
					logError(CustomMessageRepositorySpireOne.ccb015_1Input1CannotBeBlankIfInput2IsTrue(lineNumStr, METERSESSIONOUTPUTRF_TAMPERCOUNT1_CONST, 
							METERSESSIONOUTPUTRF_TAMPERCOUNT1CHANGEDFLAG_CONST));
				} else {
					// Validate MeterSessionOutputRF.TamperCount1 if parmTamper1CharTy is Predefined value.
					if(parmTamper1CharTy.getCharacteristicType().isPredefinedValue()) {
						CharacteristicValue_Id tamper1CharValId = new CharacteristicValue_Id(parmTamper1CharTy, meterSessionOutputRF_TamperCount1);
						if(isNull(tamper1CharValId.getEntity())) {
							hasError = Bool.TRUE;
							logError(CustomMessageRepositorySpireOne.ccb015_1CharValInvalid(lineNumStr, parmTamper1CharTy.getId().getIdValue()
									, meterSessionOutputRF_TamperCount1));
						}
					}
				}
			}
			
			// Validate MeterSessionOutputRF.TamperCount2
			if(meterSessionOutputRF_TamperCount2ChangedFlag.equalsIgnoreCase(CONST_TRUE)
					&& readSeq.compareTo(BigInteger.ONE) == 0) {
				// MeterSessionOutputRF.TamperCount2 cannot be blank if MeterSessionOutputRF.TamperCount2ChangedFlag is TRUE and Read Seq is 1
				if(isBlankOrNull(meterSessionOutputRF_TamperCount2)) {
					hasError = Bool.TRUE;
					logError(CustomMessageRepositorySpireOne.ccb015_1Input1CannotBeBlankIfInput2IsTrue(lineNumStr, METERSESSIONOUTPUTRF_TAMPERCOUNT2_CONST, 
							METERSESSIONOUTPUTRF_TAMPERCOUNT2CHANGEDFLAG_CONST));
				} else {
					// Validate MeterSessionOutputRF.TamperCount2 if parmTamper2CharTy is Predefined value.
					if(parmTamper2CharTy.getCharacteristicType().isPredefinedValue()) {
						CharacteristicValue_Id tamper2CharValId = new CharacteristicValue_Id(parmTamper2CharTy, meterSessionOutputRF_TamperCount2);
						if(isNull(tamper2CharValId.getEntity())) {
							hasError = Bool.TRUE;
							logError(CustomMessageRepositorySpireOne.ccb015_1CharValInvalid(lineNumStr, parmTamper2CharTy.getId().getIdValue(), 
									meterSessionOutputRF_TamperCount2));
						}
					}
				}
			}
			
			// Validate MeterSessionOutput.SkipCode
			if(parmSkipCodeCharTy.getCharacteristicType().isPredefinedValue() 
					&& readSeq.compareTo(BigInteger.ONE) == 0
					&& !isBlankOrNull(meterSessionOutput_SkipCode)) {
				CharacteristicValue_Id skipCodeCharValId = new CharacteristicValue_Id(parmSkipCodeCharTy, meterSessionOutput_SkipCode);
				if(isNull(skipCodeCharValId.getEntity())) {
					hasError = Bool.TRUE;
					logError(CustomMessageRepositorySpireOne.ccb015_1CharValInvalid(lineNumStr, parmSkipCodeCharTy.getId().getIdValue(), 
							meterSessionOutput_SkipCode));
				}
			}
			
			// Start Add - NMendo - 2021-03-02 - CCB015.Issue1
			// Validate MeterSessionOutput.TroubleCode1
			if(!isBlankOrNull(meterSessionOutput_TroubleCode1)) {
				MeterReaderRemark_Id troubleCode1 = new MeterReaderRemark_Id(meterSessionOutput_TroubleCode1);
				if(isNull(troubleCode1.getEntity())) {
					hasError = Bool.TRUE;
					logError(CustomMessageRepositorySpireOne.ccb015_1MeterReaderRemarkInvalid(lineNumStr, meterSessionOutput_TroubleCode1));
				}
			}
			
			// Validate MeterSessionOutput.TroubleCode2
			if(!isBlankOrNull(meterSessionOutput_TroubleCode2)) {
				MeterReaderRemark_Id troubleCode2 = new MeterReaderRemark_Id(meterSessionOutput_TroubleCode2);
				if(isNull(troubleCode2.getEntity())) {
					hasError = Bool.TRUE;
					logError(CustomMessageRepositorySpireOne.ccb015_1MeterReaderRemarkInvalid(lineNumStr, meterSessionOutput_TroubleCode2));
				}
			}
			// End Add - NMendo - 2021-03-02 - CCB015.Issue1
			
		}
		
		/**
		 * This method will add MR Upload Staging
		 */
		private void addMeterReadUploadStagingRecord() {
			meterReadUpload = null;
			
			// Insert into Meter Read Upload Staging table
         	MeterReadUpload_DTO mtrUploadDto = new MeterReadUpload_DTO();

         	// Set the row values
            mtrUploadDto.setBadgeNumber(meter_MeterNumber);
            // Start Change - NMendo - 2021-03-19 - CCB015.Issue3
            //mtrUploadDto.setMeterConfigurationId(meterConfigId);
            if(!isBlankOrNull(meter_CustomDataField_CustomData)) {
            	mtrUploadDto.setMeterConfigurationId(meterConfigId);
            }
            // End Change - NMendo - 2021-03-19 - CCB015.Issue3
            mtrUploadDto.setCanUseOnBill(Bool.TRUE);
            mtrUploadDto.setMeterReadUploadStatus(MeterReadUploadStatusLookup.constants.PENDING);
            mtrUploadDto.setMeterReadSourceId(parmDefaultMrSourceCd.getId());
            mtrUploadDto.setReadDateTime(readDttm);
            mtrUploadDto.setMeterReaderId(meterSessionOutput_DataCollectorUserID);
            meterReadUpload = mtrUploadDto.newEntity();
            
            // Start Add - NMendo - CCB015.Issue5 -  2021-04-30
            meterReadUploadId = meterReadUpload.getId();
            // End Add - NMendo - CCB015.Issue5 -  2021-04-30
		}
		
		/**
		 * This method will add Register Read to the added MR Upload Staging
		 */
		private void addRegisterReadUploadStagingRecord() {
			// Start Change - NMendo - CCB015.Issue5 -  2021-04-30
			//MeterReadUploadReaderRemarkUploads readerRemarkUploads = meterReadUpload.getReaderRemarkUploads();
			//ReaderRemarkUpload_DTO readerRemarkUploadDTO = readerRemarkUploads.newChildDTO();
			//readerRemarkUploadDTO.setRegisterReading(registerReading);
			//readerRemarkUploadDTO.setUnitOfMeasureId(uomId);
			//readerRemarkUploadDTO.setReadType(readType);
			//readerRemarkUploadDTO.setIsHighLowReviewed(Bool.TRUE);
            //readerRemarkUploads.add(readerRemarkUploadDTO, readSeq);
            
			StringBuilder sb = new StringBuilder();
			sb.append("INSERT INTO CI_RR_STAGE_UP ( ");
			sb.append("MR_STAGE_UP_ID, ");
			sb.append("READ_SEQ, ");
            sb.append("READ_TYPE_FLG, ");
            sb.append("REG_READING, ");
            sb.append("REVIEW_HILO_SW, ");
            sb.append("UOM_CD) ");
            sb.append("VALUES ( ");
            sb.append(":meterReadUploadId, ");
            sb.append(":readSeq, ");
            sb.append(":readType, ");
            sb.append(":registerReading, ");
            sb.append(":reviewHiLoSw, ");
            sb.append(":uomId) ");
            
            PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
        	ps.bindId("meterReadUploadId", meterReadUploadId);
        	ps.bindBigInteger("readSeq", readSeq);
        	ps.bindLookup("readType", readType);
        	ps.bindBigDecimal("registerReading", registerReading);
            // 2022-04-01. ASaped. B-20753. Start Change
            //ps.bindBoolean("reviewHiLoSw", Bool.TRUE);
            if(reviewExemptRegisterUoms.contains(uomId)) {
                ps.bindBoolean("reviewHiLoSw", Bool.FALSE);
            } else {
                ps.bindBoolean("reviewHiLoSw", Bool.TRUE);
            }            
            // 2022-04-01. ASaped. B-20753. End Change
        	ps.bindId("uomId", uomId);

            ps.executeUpdate();
            ps.close();
            // End Change - NMendo - CCB015.Issue5 -  2021-04-30
		}

		/**
		 * This method will add Characteristic/s to the added MR Upload Staging
		 */
		private void addMeterReadUploadChars() {
			if(readSeq.compareTo(BigInteger.ONE) == 0) {
				if(meterSessionOutputRF_TamperCount1ChangedFlag.equalsIgnoreCase(CONST_TRUE)) {
					// Add Tamper 1 Characteristic
					addMeterReadUploadChar(parmTamper1CharTy, meterSessionOutputRF_TamperCount1);
				}
				
				if(meterSessionOutputRF_TamperCount2ChangedFlag.equalsIgnoreCase(CONST_TRUE)) {
					// Add Tamper 2 Characteristic
					addMeterReadUploadChar(parmTamper2CharTy, meterSessionOutputRF_TamperCount2);
				}
				
				if(!isBlankOrNull(meterSessionOutput_SkipCode)) {
					// Add Skip Code Characteristic
					addMeterReadUploadChar(parmSkipCodeCharTy, meterSessionOutput_SkipCode);
				}
			}
		}

		/**
		 * This method will add Characteristic to the added MR Upload Staging
		 * @param charType
		 * @param charVal
		 */
		private void addMeterReadUploadChar(CharacteristicType charType, String charVal) {
			// Start Change - NMendo - CCB015.Issue5 -  2021-04-30
			//MeterReadUploadCharacteristic mrUploadChar = meterReadUpload.getCharacteristic();
			//MeterReadStagingUploadCharacteristic_DTO mrUploadCharDTO = mrUploadChar.newChildDTO();
			
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			//if (charTypeLookup.isAdhocValue()) {
			//	mrUploadCharDTO.setAdhocCharacteristicValue(charVal);
			//} else if (charTypeLookup.isForeignKeyValue()) {
			//	mrUploadCharDTO.setCharacteristicValueForeignKey1(charVal);
			//} else if (charTypeLookup.isPredefinedValue()) {
			//	mrUploadCharDTO.setCharacteristicValue(charVal);
			//}
			
			//mrUploadChar.add(mrUploadCharDTO, charType.getId(), BigInteger.ONE);
			
			StringBuilder sb = new StringBuilder();
            sb.append("INSERT INTO CI_MR_STGUP_CHAR ( ");
            sb.append("MR_STAGE_UP_ID, ");
            sb.append("CHAR_TYPE_CD, ");
            sb.append("SEQ_NUM, ");
            if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
            	sb.append("ADHOC_CHAR_VAL, ");
			} else if (charTypeLookup.isForeignKeyValue()) {
				sb.append("CHAR_VAL_FK1, ");
			} else if (charTypeLookup.isPredefinedValue()) {
				sb.append("CHAR_VAL, ");
			}
            sb.append("SRCH_CHAR_VAL) ");
            sb.append("VALUES ( ");
            sb.append(":meterReadUploadId, ");
            sb.append(":charTypeId, ");
            sb.append(":seqNum, ");
            sb.append(":charValue, ");
            sb.append(":charValue) ");

            PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
        	ps.bindId("meterReadUploadId", meterReadUploadId);
        	ps.bindId("charTypeId", charType.getId());
        	ps.bindBigInteger("seqNum", BigInteger.ONE);
        	ps.bindString("charValue", charVal, getClass().getName());

        	ps.executeUpdate();
        	ps.close();
        	// End Change - NMendo - CCB015.Issue5 -  2021-04-30
		}
		
		/**
		 * This method will update Meter Cycle/Route Sequence of the SP
		 */
		private void updateMeterCycleRouteSeq() {
			// Get service point
        	StringBuilder sb = new StringBuilder();
        	ServicePoint_Id spId = null;

        	sb.append("SELECT SP_ID ");
        	sb.append("FROM CI_SP_MTR_HIST ");
        	sb.append("WHERE MTR_CONFIG_ID = :meterConfigId ");
        	sb.append("AND REMOVAL_DTTM IS NULL ");
        	PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
        	// Start Change - NMendo - 2021-03-19 - CCB015.Issue3
        	//ps.bindId("meterConfigId", meterConfigId);
        	if(notNull(meterConfigId)) {
        		ps.bindId("meterConfigId", meterConfigId);
        	} else {
        		ps.bindId("meterConfigId", derivedMeterConfigId);
        	}
        	// End Change - NMendo - 2021-03-19 - CCB015.Issue3
        	
        	SQLResultRow result = ps.firstRow();
        	ps.close();

        	if (notNull(result)) {
        		String spIdStr = result.getString("SP_ID");
        		spId = new ServicePoint_Id(spIdStr);

	        	// Update the sequence number
        		ServicePoint sp = spId.getEntity();
	        	ServicePoint_DTO spDTO = sp.getDTO();
	        	spDTO.setMeterReadCycleRouteSequence(meterCycleRouteSeq);
	        	sp.setDTO(spDTO);
        	}
		}
		
		/**
		 * This method will validate if the input Badge Number exists
		 */
		private void validateBadgeNumber() {
			StringBuilder sb = new StringBuilder();
			// Start Change - NMendo - 2021-03-19 - CCB015.Issue3
			//sb.append("SELECT 'X' ");
			sb.append("SELECT MTR_ID ");
			// End Change - NMendo - 2021-03-19 - CCB015.Issue3
			sb.append("FROM CI_MTR ");
			sb.append("WHERE BADGE_NBR = :badgeNumber ");
			
			PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
        	ps.bindStringProperty("badgeNumber", Meter.properties.badgeNumber, meter_MeterNumber);
        	
        	SQLResultRow result = ps.firstRow();
        	// Start Add - NMendo - 2021-03-19 - CCB015.Issue3
        	List<SQLResultRow> resultList = ps.list();
        	// End Add - NMendo - 2021-03-19 - CCB015.Issue3
        	ps.close();
        	
        	if(isNull(result)) {
        		hasError = Bool.TRUE;
        		logError(CustomMessageRepositorySpireOne.ccb015_1BadgeNumberInvalid(lineNumStr, meter_MeterNumber));
        		// Start Add - NMendo - CCB015.Issue4 -  2021-04-23
        		return;
        		// End Add - NMendo - CCB015.Issue4 -  2021-04-23
            }
        	
        	// Start Add - NMendo - 2021-03-19 - CCB015.Issue3
        	if(!isBlankOrNull(meter_CustomDataField_CustomData) ) {
        		// No need to validate further if Meter.CustomDataField.CustomData / Meter Configuration ID is provided.
        		return;
        	}
        	
        	if(resultList.size() > 1) {
        		hasError = Bool.TRUE;
        		logError(CustomMessageRepositorySpireOne.ccb015_1BadgeNumberLinkToMultipleMeters(lineNumStr, meter_MeterNumber));
        		return;
            }
        	
        	String meterIdStr = result.getString("MTR_ID");
        	Meter_Id meterId = new Meter_Id(meterIdStr);
			
			StringBuilder sb2 = new StringBuilder();
			sb2.append("SELECT MC.MTR_CONFIG_ID ");
			sb2.append("FROM CI_MTR_CONFIG MC ");
			sb2.append("WHERE MC.MTR_ID = :meterId ");
			sb2.append("AND MC.EFF_DTTM = (SELECT MAX(MC2.EFF_DTTM) ");
			sb2.append(                   "FROM CI_MTR_CONFIG MC2 ");
			sb2.append(                   "WHERE MC2.MTR_ID = MC.MTR_ID) ");

			PreparedStatement ps2 = createPreparedStatement(sb2.toString(), getClass().getName());
			ps2.bindId("meterId", meterId);
			
			SQLResultRow result2 = ps2.firstRow();
			ps2.close();
			
			if(isNull(result2)) {
				hasError = Bool.TRUE;
				logError(CustomMessageRepositorySpireOne.ccb015_1BadgeNumberNotLinkToMeterConfig(
						lineNumStr, meterIdStr, meter_MeterNumber));
				return;
			} 
			
			derivedMeterConfigId = (MeterConfiguration_Id) result2.getId("MTR_CONFIG_ID", MeterConfiguration.class);
			// End Add - NMendo - 2021-03-19 - CCB015.Issue3
		}
		
		/**
		 * This method will validate if the input Badge Number and Meter Configuration combination exists
		 */
		private void validateBadgeNumberWithMeterConfig() {
			StringBuilder sb = new StringBuilder();
			sb.append("SELECT 'X' ");
			sb.append("FROM CI_MTR M, CI_MTR_CONFIG MC ");
			sb.append("WHERE M.MTR_ID = MC.MTR_ID ");
			sb.append("AND M.BADGE_NBR = :badgeNumber ");
			sb.append("AND MC.MTR_CONFIG_ID = :meterConfigId ");
			sb.append("AND MC.EFF_DTTM = (SELECT MAX(MC2.EFF_DTTM) ");
			sb.append(                   "FROM CI_MTR_CONFIG MC2 ");
			sb.append(                   "WHERE MC2.MTR_ID = M.MTR_ID) ");
			
			PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
        	ps.bindStringProperty("badgeNumber", Meter.properties.badgeNumber, meter_MeterNumber);
        	ps.bindId("meterConfigId", meterConfigId);
        	
        	SQLResultRow result = ps.firstRow();
        	ps.close();
        	
        	if(isNull(result)) {
        		hasError = Bool.TRUE;
        		logError(CustomMessageRepositorySpireOne.ccb015_1MeterConfigBadgeNumberMismatch(lineNumStr, meter_CustomDataField_CustomData, meter_MeterNumber));
            }
		}
		
		/**
		 * This method will check if there is an existing MR Upload Staging from the record
		 */
		private void checkForExistingMRStagingRecord() {
			StringBuilder sb = new StringBuilder();

			// Start Change - NMendo - CCB015.Issue6 -  2021-06-16
			sb.append("SELECT 'X' ");
			//sb.append("FROM CI_MR_STAGE_UP ");
			//sb.append("WHERE MTR_CONFIG_ID = :meterConfigId ");
			//sb.append("AND READ_DTTM = :readDttm ");
			sb.append("FROM CI_MR_STAGE_UP MRU, CI_RR_STAGE_UP RRU ");
			sb.append("WHERE MRU.MTR_CONFIG_ID = :meterConfigId ");
			sb.append("AND MRU.READ_DTTM BETWEEN :minReadDttm AND :maxReadDttm ");
			sb.append("AND MRU.MR_STAGE_UP_ID = RRU.MR_STAGE_UP_ID ");
			sb.append("AND RRU.READ_SEQ = :readSeq ");
			
			PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
        	ps.bindId("meterConfigId", meterConfigId);
        	//ps.bindDateTime("readDttm", readDttm);
        	ps.bindDateTime("minReadDttm", readDttm.addMinutes(maxIntervalRegReadDttm.negate().intValue()));
        	ps.bindDateTime("maxReadDttm", readDttm.addMinutes(maxIntervalRegReadDttm.intValue()));
        	ps.bindBigInteger("readSeq", readSeq);
        	// End Change - NMendo - CCB015.Issue6 -  2021-06-16
        	
        	SQLResultRow result = ps.firstRow();
        	ps.close();
        	
        	if(notNull(result)) {
        		hasError = Bool.TRUE;
        		DateFormat dateTimeFormat = new DateFormat(DATETIME_FORMAT);
        		logError(CustomMessageRepositorySpireOne.ccb015_1MRStagingRecordExist(lineNumStr, meterConfigId.getIdValue(), 
        				readDttm.toString(dateTimeFormat)));
        	}
		}
		
		// Start Add - NMendo - 2021-03-02 - CCB015.Issue1
		private void addMeterReadRemarks() {
			// Start Change - NMendo - CCB015.Issue5 -  2021-04-30
			//MeterReadUploadMeterReadRemarkUploads meterReadRemarks = meterReadUpload.getMeterReadRemarkUploads();
			
			if(!isBlankOrNull(meterSessionOutput_TroubleCode1)) {
				//MeterReadRemarkUpload_DTO meterReadRemarksDto = meterReadRemarks.newChildDTO();
				//meterReadRemarks.add(meterReadRemarksDto, new MeterReaderRemark_Id(meterSessionOutput_TroubleCode1));
				addMeterReadRemark(new MeterReaderRemark_Id(meterSessionOutput_TroubleCode1));
			}
			
			if(!isBlankOrNull(meterSessionOutput_TroubleCode2) && !meterSessionOutput_TroubleCode2.equals(meterSessionOutput_TroubleCode1)) {
				//MeterReadRemarkUpload_DTO meterReadRemarksDto = meterReadRemarks.newChildDTO();
				//meterReadRemarks.add(meterReadRemarksDto, new MeterReaderRemark_Id(meterSessionOutput_TroubleCode2));
				addMeterReadRemark(new MeterReaderRemark_Id(meterSessionOutput_TroubleCode2));
			}
			// Start Change - NMendo - CCB015.Issue5 -  2021-04-30
		}
		// End Add - NMendo - 2021-03-02 - CCB015.Issue1
		
		// Start Add - NMendo - CCB015.Issue5 -  2021-04-30
		/**
		 * This method will add Reader Remark to the created MR Upload Staging
		 * @param mrRemarkId
		 */
		private void addMeterReadRemark(MeterReaderRemark_Id mrRemarkId) {
			
			StringBuilder sb = new StringBuilder();
			sb.append("INSERT INTO CI_MRR_STGE_UP (MR_STAGE_UP_ID, READER_REM_CD) ");
			sb.append("VALUES (:meterReadUploadId, :mrRemarkId) ");
			
			PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
        	ps.bindId("meterReadUploadId", meterReadUploadId);
        	ps.bindId("mrRemarkId", mrRemarkId);

            ps.executeUpdate();
            ps.close();
		}
		// End Add - NMendo - CCB015.Issue5 -  2021-04-30
		
		// Start Add - NMendo - 2021-03-19 - CCB015.Issue3
		/**
		 * This method will check if there is an existing MR Upload Staging from the record
		 */
		private void checkForExistingMRStagingRecordUsingBadgeNumber() {
			StringBuilder sb = new StringBuilder();
			
			// Start Change - NMendo - CCB015.Issue6 -  2021-06-16
			sb.append("SELECT 'X' ");
			//sb.append("FROM CI_MR_STAGE_UP ");
			//sb.append("WHERE BADGE_NBR = :badgeNumber ");
			//sb.append("AND READ_DTTM = :readDttm ");
			sb.append("FROM CI_MR_STAGE_UP MRU, CI_RR_STAGE_UP RRU ");
			sb.append("WHERE MRU.BADGE_NBR = :badgeNumber ");
			sb.append("AND MRU.READ_DTTM BETWEEN :minReadDttm AND :maxReadDttm ");
			sb.append("AND MRU.MR_STAGE_UP_ID = RRU.MR_STAGE_UP_ID ");
			sb.append("AND RRU.READ_SEQ = :readSeq ");
			
			PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
			ps.bindStringProperty("badgeNumber", Meter.properties.badgeNumber, meter_MeterNumber);
        	//ps.bindDateTime("readDttm", readDttm);
        	ps.bindDateTime("minReadDttm", readDttm.addMinutes(maxIntervalRegReadDttm.negate().intValue()));
        	ps.bindDateTime("maxReadDttm", readDttm.addMinutes(maxIntervalRegReadDttm.intValue()));
        	ps.bindBigInteger("readSeq", readSeq);
        	// End Change - NMendo - CCB015.Issue6 -  2021-06-16

        	SQLResultRow result = ps.firstRow();
        	ps.close();
        	
        	if(notNull(result)) {
        		hasError = Bool.TRUE;
        		DateFormat dateTimeFormat = new DateFormat(DATETIME_FORMAT);
        		logError(CustomMessageRepositorySpireOne.ccb015_1MRStagingRecordExistForBadgeAndReadDt(
        				lineNumStr, meter_MeterNumber, readDttm.toString(dateTimeFormat)));
        	}
		}
		// End Add - NMendo - 2021-03-19 - CCB015.Issue3
		
		// Start Add - NMendo - CCB015.Issue7 -  2021-06-21
		/**
		 * This method checks if input Read Sequence exists in input Meter Read Upload.
		 * @param meterReadUploadId
		 * @param readSeq
		 * @return Bool
		 */
		private Bool isRegisterSeqExists(MeterReadUpload_Id meterReadUploadId, BigInteger readSeq) {
			Bool isRegisterSeqExists = Bool.FALSE;
			
			if(notNull(meterReadUploadId)) {
				ListFilter<ReaderRemarkUpload> readerRemarkUploadFilter = meterReadUploadId.getEntity().getReaderRemarkUploads()
						.createFilter(" WHERE this.id.seq = :readSeq ", getClass().getName());
				readerRemarkUploadFilter.bindBigInteger("readSeq", readSeq);
				
				if(notNull(readerRemarkUploadFilter.firstRow())) {
					isRegisterSeqExists = Bool.TRUE;
				}
			}
			
			return isRegisterSeqExists;
		}
		// End Add - NMendo - CCB015.Issue7 -  2021-06-21

		//Start Add JVitug - E-11558 - 2025-09-22
		//We now also validate that the meter configuration from the file can handle the meter read being entered.
		//If not, we derive the meter configuration
		private void validateMeterConfigCanHandleRead() {
			
			StringBuilder sb = new StringBuilder();
			sb.append("SELECT 'X' ");
			sb.append("FROM CI_MTR M, CI_MTR_CONFIG MC, CI_REG R ");
			sb.append("WHERE M.MTR_ID = MC.MTR_ID ");
			sb.append("AND MC.MTR_CONFIG_ID = :meterConfigId ");
			sb.append("AND MC.EFF_DTTM = (SELECT MAX(MC2.EFF_DTTM) ");
			sb.append(                   "FROM CI_MTR_CONFIG MC2 ");
			sb.append(                   "WHERE MC2.MTR_ID = M.MTR_ID) ");
			sb.append("AND R.EFF_DTTM = MC.EFF_DTTM ");
			sb.append("AND R.MTR_ID = MC.MTR_ID ");
			sb.append("AND R.NBR_OF_DGTS_LFT >= :numberOfDigitsLeft ");
			
			PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
	    	ps.bindId("meterConfigId", meterConfigId);
	    	ps.bindBigInteger("numberOfDigitsLeft" , numberOfDigitsLeft);
	    	
	    	SQLResultRow result = ps.firstRow();
	    	ps.close();
	    	
	    	if(isNull(result)) {
	    		//If the result is null at this part, this means that the meter configuration 
	    		//received from the file cannot handle the input register reading from the same file.
	    		//It might be the case that there is another meter config for the same badge number that can handle the read , as 
	    		//MOE/MOW can have two distinct meters for the same badge number
	    		sb = new StringBuilder();
				sb.append("SELECT MC.MTR_CONFIG_ID ");
				sb.append("FROM CI_MTR M, CI_MTR_CONFIG MC, CI_REG R ");
				sb.append("WHERE M.MTR_ID = MC.MTR_ID ");
				sb.append("AND M.BADGE_NBR = :badgeNumber ");
				sb.append("AND MC.EFF_DTTM = (SELECT MAX(MC2.EFF_DTTM) ");
				sb.append(                   "FROM CI_MTR_CONFIG MC2 ");
				sb.append(                   "WHERE MC2.MTR_ID = M.MTR_ID) ");
				sb.append("AND R.EFF_DTTM = MC.EFF_DTTM ");
				sb.append("AND R.MTR_ID = MC.MTR_ID ");
				sb.append("AND R.NBR_OF_DGTS_LFT >= :numberOfDigitsLeft ");
				sb.append("AND R.UOM_CD = :unitOfMeasure ");
				
				ps = createPreparedStatement(sb.toString(), getClass().getName());
				ps.bindStringProperty("badgeNumber", Meter.properties.badgeNumber, meter_MeterNumber);
		    	ps.bindBigInteger("numberOfDigitsLeft" , numberOfDigitsLeft);
		    	ps.bindId("unitOfMeasure" , uomId);
		    	
		    	result = ps.firstRow();
		    	ps.close();
		    	
		    	//If there is a row retrieved, change the designated meter configuration ID to this new meter configuration
		    	if(notNull(result)) {
		    		meterConfigId =  (MeterConfiguration_Id) result.getId("MTR_CONFIG_ID", MeterConfiguration.class);
		    	}
	        }
		}
		//End Add JVitug - E-11558 - 2025-09-22
	}
}
