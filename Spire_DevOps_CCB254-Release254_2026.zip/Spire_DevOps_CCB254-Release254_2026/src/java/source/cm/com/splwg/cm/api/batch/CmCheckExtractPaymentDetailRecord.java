/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Column Delimited Record class for Payment Detail
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-05-27   RDizon  CCB041. Initial version.        
 **************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

/**
 * @author RDizon
 */
public class CmCheckExtractPaymentDetailRecord extends ColumnDelimitedRecord {
    
    private static final String DELIMITER = "|";
        
    public CmCheckExtractPaymentDetailRecord() {
        super(14);
    }
    
    public void setRecordType(String value) {
        this.leftPadColumn(1, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setVoucherNumber(String value) {
        this.leftPadColumn(2, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setInvoiceNumber(String value) {
        this.leftPadColumn(3, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setGrossAmount(String value) {
        this.leftPadColumn(4, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setNetAmount(String value) {
        this.leftPadColumn(5, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setDiscount(String value) {
        this.leftPadColumn(6, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setInvoiceDate(String value) {
        this.leftPadColumn(7, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setAdjustmentReasonText(String value) {
        this.leftPadColumn(8, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setEntityId(String value) {
        this.leftPadColumn(9, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setEntityName(String value) {
        this.leftPadColumn(10, value.length() + 1 , value.trim() + DELIMITER);
    }

    public void setRemitAccountNumber(String value) {
        this.leftPadColumn(11, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setSystemReference(String value) {
        this.leftPadColumn(12, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setMiscRemittanceReference(String value) {
        this.leftPadColumn(13, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setInvoiceDueDate(String value) {
        this.leftPadColumn(14, value.length() + 1, value.trim());
    }
    
}
