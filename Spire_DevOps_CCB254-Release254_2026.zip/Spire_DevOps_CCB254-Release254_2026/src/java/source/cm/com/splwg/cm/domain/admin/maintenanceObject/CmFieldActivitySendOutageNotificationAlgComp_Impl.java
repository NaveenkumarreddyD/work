/* *************************************************************************************************
 * PROGRAM DESCRIPTION
 *
 * CCB026.Issue3 - Outage Process Updates
 *
 * Description
 *
 * The CCB026 outage process logic will be removed from the FA Change Handler and moved into this new
 * FA Audit Algorithm instead.
 *
 ***************************************************************************************************
 *
 * CHANGE HISTORY
 *
 * Date:        by:			Reason:
 * YYYY-MM-DD   IN        	Reason text.
 *
 * 2021-06-22   GCrisp		CCB026.Issue3. Initial version.
 * 2021-12-20   FRoig       B-20167. Mass Outage changes (CCB200).
 *
 **************************************************************************************************/
package com.splwg.cm.domain.admin.maintenanceObject;

import java.math.BigInteger;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.EntityId;
import com.splwg.base.api.service.PageBody;
import com.splwg.base.api.service.PageHeader;
import com.splwg.base.api.service.ServiceDispatcher;
import com.splwg.base.api.serviceScript.ServiceScriptDispatcher;
import com.splwg.base.api.serviceScript.ServiceScriptInstance;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObject;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObjectAuditAlgorithmSpot;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObject_Id;
import com.splwg.base.domain.common.phoneType.PhoneType;
import com.splwg.base.domain.common.phoneType.PhoneType_Id;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.FieldActivityIntermediateStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.accountRelationshipType.entity.AccountRelationshipType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.cm.api.lookup.CmClickIntegrationParametersLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;

/**
 * @author GCrisp
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = outageDisconnectEventType, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = outageCancellationEventType, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = outageReconnectEventType, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = massOutageEventType, required = true, type = string)})
 */
public class CmFieldActivitySendOutageNotificationAlgComp_Impl  extends CmFieldActivitySendOutageNotificationAlgComp_Gen
implements MaintenanceObjectAuditAlgorithmSpot {
	private MaintenanceObject mo;
    private EntityId entityId;
	//Working variables
    private String emailAddressPMOC = "";
    private String smsNumPMOC = "";
    private static final String CM_SAPNOTIF="CM-SAPNotif";
    private static final String CM_PMOCINFO="CM-PmocInfo";
    // 2021-12-20 FRoig B-20167 Start Delete
    //private static final String EVENT_DISCONNECT="OUTD";
    //private static final String EVENT_CANCELLATION="OUTN";
    //private static final String EVENT_RECONNECT="OUTR";
    // 2021-12-20 FRoig B-20167 End Delete
    private static final String COMM_TYPE = "O";
    private static final String PMOC_GROUP_INPUT = "input";
    private static final String PMOC_GROUP_OUTPUT = "output";
    private static final String PMOC_ACCOUNT_ID = "accountId";
    private static final String SAPNOTIF_OUTBOUND_MSG_ID = "outboundMessageId";
    private static final String ACCT_REL_TYPE_MAIN = "MAIN";
    private static final String FA_LOG_TYPE_OUTB = "XOOM";
    
    private static final String CUST_PORTAL_CONFIG = "CM-CustomerPortalConfiguration";
    private static final String SERVICE_TASK_TYPE = "serviceTaskType";
    private static final String OUTAGE_ACTIVITY_FRP = "outageActivity";
    private static final String DC_FA_TYPE = "faTypeOutageDc";
    private static final String RECON_FA_TYPE = "faTypeOutageRec";
    // 2021-12-20 FRoig B-20167 Start Add
    private static final String MASS_OUTAGE_FA_TYPE = "faTypeMassOutageDc";
    // 2021-12-20 FRoig B-20167 End Add
    private static final FeatureConfiguration_Id DEFAULT_FEAT_CONFIG_PARM = new FeatureConfiguration_Id("CM-CLKMWM2");
    
    private String faTypeDisconnect = "";
    private String faTypeReconnect = "";
    // 2021-12-20 FRoig B-20167 Start Add
    private String faTypeMassOutage = "";
    private String parmOutageDisconnectEventType;
    private String parmOutageCancellationEventType;
    private String parmOutageReconnectEventType;
    private String parmMassOutageEventType;
    // 2021-12-20 FRoig B-20167 End Add
    
    private static final CmMGEFeatureConfigurationOptionsRetriever FC_HELPER = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
    private static final String CUSTOMER_PORTAL_SERVICE_TASK_TYPE = "CUSTPRTL-CONFIG"; 
	
	public void setEntityId(EntityId arg0) {
        entityId = arg0;

    }

    public void setMaintenanceObject(MaintenanceObject arg0) {
        mo = arg0;

    }
    
    // 2021-12-20 FRoig B-20167 Start Add
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
    	parmOutageDisconnectEventType = getOutageDisconnectEventType();
    	parmOutageCancellationEventType = getOutageCancellationEventType();
    	parmOutageReconnectEventType = getOutageReconnectEventType();
    	parmMassOutageEventType = getMassOutageEventType();
    }
    // 2021-12-20 FRoig B-20167 End Add

    public void invoke() {
    	MaintenanceObject_Id faMaintenanceObjectId = new MaintenanceObject_Id("FA");
        MaintenanceObject faMaintenanceObject = faMaintenanceObjectId.getEntity();
     	Bool isFAforAdd = Bool.FALSE;
		Bool isOldFAImmediateStatusNotDispatched = Bool.FALSE;
     
        if (notNull(faMaintenanceObject) && (mo.equals(faMaintenanceObject))){
            FieldActivity_Id faId = new FieldActivity_Id(entityId.getOrderedPKFieldValues().get(0).toString());
            FieldActivity fa = faId.getEntity();
     		if (notNull(fa)){
				//Retrieve Outage Disconnect and Outage Reconnect FA Types
     			getFaTypeDiconAndReconFromCustPortalConfig();
				
     			//Check if a Person is associated with the SP
     			if(notNull(getSAFromFieldActivity(fa))){
     				isFAforAdd = determineIfFAIsForAdd(fa);
					isOldFAImmediateStatusNotDispatched = determineIfOldFAImmediateStatusIsNotDispatched(fa);
					
     				if(fa.getFieldActivityType().getId().getTrimmedValue().equals(faTypeDisconnect)){
     					//create outbound if FA Type is Outage - Disconnect Service Point (SP-OUTD) and FA Status is canceled
     					if(fa.getFieldActivityStatus().isCanceled()){
     						// 2021-12-20 FRoig B-20167 Start Change
     						//createOutboundForOutageFieldActivity(fa,EVENT_CANCELLATION);
     						createOutboundForOutageFieldActivity(fa,parmOutageCancellationEventType);
     						// 2021-12-20 FRoig B-20167 End Change
     					}
     					if(isFAforAdd.isTrue()){
     						//create outbound if FA Type is Outage - Disconnect Service Point (SP-OUTD)
     						// 2021-12-20 FRoig B-20167 Start Change
     						//createOutboundForOutageFieldActivity(fa,EVENT_DISCONNECT);
     						createOutboundForOutageFieldActivity(fa,parmOutageDisconnectEventType);
     						// 2021-12-20 FRoig B-20167 End Change
     					}
     				}
     				
     				// 2021-12-20 FRoig B-20167 Start Add
     				if(fa.getFieldActivityType().getId().getTrimmedValue().equals(faTypeMassOutage)){
     					//create outbound if FA Type is Mass Outage - Disconnect Service Point (SP-MOUTD) and FA Status is canceled
     					if(fa.getFieldActivityStatus().isCanceled()){
     						createOutboundForOutageFieldActivity(fa,parmOutageCancellationEventType);
     					}
     					if(isFAforAdd.isTrue()){
     						//create outbound if FA Type is Mass Outage - Disconnect Service Point (SP-MOUTD)
     						createOutboundForOutageFieldActivity(fa,parmMassOutageEventType);
     					}
     				}
     				// 2021-12-20 FRoig B-20167 End Add
     				
     				//create outbound if FA Type is Outage - Reconnect Service Point (SP-OUTD) and Intermediate Status is Dispatched
     				if(fa.getFieldActivityType().getId().getTrimmedValue().equals(faTypeReconnect)){
     					if(fa.getIntermediateStatus().equals(FieldActivityIntermediateStatusLookup.constants.DISPATCHED.getLookupValue().fetchIdFieldValue())
							&& isOldFAImmediateStatusNotDispatched.isTrue()){
     						// 2021-12-20 FRoig B-20167 Start Change
     						//createOutboundForOutageFieldActivity(fa,EVENT_RECONNECT);
     						createOutboundForOutageFieldActivity(fa,parmOutageReconnectEventType);
     						// 2021-12-20 FRoig B-20167 End Change
     					}
     				}
     			}
     		}
     	}
    }
	
	private void createOutboundForOutageFieldActivity(FieldActivity fa, String event){
     	ServiceAgreement sa = null;
     	String outboundMessageId = "";
     
     	//Get Service Agreement from Field Activity
     	sa = getSAFromFieldActivity(fa);
     	//Get the Preferred Contact Method of the Account
     	retrievePMOC(CM_PMOCINFO, sa.getAccount().getId());
     	//Create Outbound Message and return Outbound Message Id
     	outboundMessageId = sendNotification(fa, sa, event);
     
     	if(!isBlankOrNull(outboundMessageId)){
     		//Create Field Activity Log
     		createFALog(fa, outboundMessageId);
     	}
    }
	
	private ServiceAgreement getSAFromFieldActivity(FieldActivity fa){
        ServiceAgreement sa = null;
     	//Get Service Agreement using Service Point Id to retrieve the Account Id
		StringBuilder saQuery = new StringBuilder();
		
     	saQuery.append("SELECT ");
     	saQuery.append(		"SS.SA_ID ");
     	saQuery.append("FROM ");
     	saQuery.append(		"CI_SA_SP SS, CI_SA SA ");
     	saQuery.append("WHERE ");
     	saQuery.append(		"SS.SP_ID  = :spId ");
     	saQuery.append(		"AND SS.SA_ID  = SA.SA_ID ");
     	saQuery.append(		"AND SS.START_DTTM <= :dttm ");
     	saQuery.append(		"AND (SS.STOP_DTTM is NULL OR SS.STOP_DTTM < :dttm) ");
     	saQuery.append(		"AND SA.SA_STATUS_FLG NOT IN (:closed, :canceled) ");
		
		PreparedStatement saQueryPrepStmt = createPreparedStatement(saQuery.toString(), getClass().getName());
     
     	saQueryPrepStmt.bindId("spId", fa.getServicePoint().getId());
     	saQueryPrepStmt.bindDate("dttm", this.getProcessDateTime().getDate());
     	saQueryPrepStmt.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
     	saQueryPrepStmt.bindLookup("canceled", ServiceAgreementStatusLookup.constants.CANCELED);
     
     	SQLResultRow row = saQueryPrepStmt.firstRow();
     
     	if(notNull(row)){
     		sa = row.getEntity("SA_ID", ServiceAgreement.class);
     	}
     
     	return sa;
    }
	
	private void retrievePMOC(String service, Account_Id accountId){
     	ServiceScriptInstance serviceScriptInstance = null;
     	COTSInstanceNode scriptInput = null;
     	COTSInstanceNode scriptOutput = null;
     	emailAddressPMOC = "";
     	smsNumPMOC = "";
     	// Create an instance of the service script
     	serviceScriptInstance = ServiceScriptInstance.create(service);
     
     	// Retrieve the script's input node
     	scriptInput = serviceScriptInstance.getGroup(PMOC_GROUP_INPUT);
     
     	// Account Id
     	scriptInput.set(PMOC_ACCOUNT_ID, accountId.getTrimmedValue());
     
     	// Invoke the service script
     	try {
     		ServiceScriptDispatcher.invoke(serviceScriptInstance);
     		scriptOutput = serviceScriptInstance.getGroup(PMOC_GROUP_OUTPUT);
     		if (scriptOutput.getGroup("errorInformation").getBoolean("isInError").isFalse()){
     			if (!isBlankOrNull(scriptOutput.getGroup("pmoc").getString("emailAddress"))){
     				emailAddressPMOC = scriptOutput.getGroup("pmoc").getString("emailAddress");
     			}
     
     			if (!isBlankOrNull(scriptOutput.getGroup("pmoc").getString("smsPhone"))){
     				smsNumPMOC = scriptOutput.getGroup("pmoc").getString("smsPhone");
     			}
     		}
     	} catch (ApplicationError ae){
     		ae.getServerMessage();
     	}
    }
	
	private String sendNotification(FieldActivity fa, ServiceAgreement sa, String event){
     	String primaryPhoneNum = null;
     	ServiceScriptInstance serviceScriptInstance = null;
     	serviceScriptInstance = ServiceScriptInstance.create(CM_SAPNOTIF);
     
     	serviceScriptInstance.set("account", sa.getAccount().getId().getTrimmedValue());
     	serviceScriptInstance.set("event", event);
     	serviceScriptInstance.set("communicationType", COMM_TYPE);
     
     	//check if the PMOC Email Address has value
     	if(!isBlankOrNull(emailAddressPMOC)){
     		serviceScriptInstance.set("emailDestination", emailAddressPMOC);
     	}
     
     	//check if the PMOC SMS has value
     	if(!isBlankOrNull(smsNumPMOC)){
     		serviceScriptInstance.set("textDestination", smsNumPMOC);
     	}
     
     	primaryPhoneNum = getPersonPrimaryOrPriorityPhone(sa.getAccount().getId());
     
     	if(isBlankOrNull(primaryPhoneNum)){
     		return null;
     	}
     
     	serviceScriptInstance.set("emailParameter1", primaryPhoneNum);
     	serviceScriptInstance.set("emailParameter2", fa.getId().getTrimmedValue());
     	serviceScriptInstance.set("emailParameter3", fa.getServicePoint().getId().getTrimmedValue());
     	serviceScriptInstance.set("emailParameter4", fa.getServicePoint().getPremise().fetchDivision().getId().getTrimmedValue());
     
     	try{
     		ServiceScriptDispatcher.invoke(serviceScriptInstance);
     	} catch (ApplicationError e){
     		e.getServerMessage();
     	}
     
     	return serviceScriptInstance.getString(SAPNOTIF_OUTBOUND_MSG_ID);
    }
	
	private String getPersonPrimaryOrPriorityPhone(Account_Id acctId){
     	String personPrioPhoneTypeList = FC_HELPER.getFeatureOptionValue(DEFAULT_FEAT_CONFIG_PARM, CmClickIntegrationParametersLookup.constants.PRIO_PERSON_PHONE_TYPE_LIST, Bool.FALSE, Bool.FALSE);
     	String businessPrioPhoneTypeList = FC_HELPER.getFeatureOptionValue(DEFAULT_FEAT_CONFIG_PARM, CmClickIntegrationParametersLookup.constants.PRIO_BUSINESS_PHONE_TYPE_LIST, Bool.FALSE, Bool.FALSE);
     
     	PhoneType_Id primaryPhoneTypeId = new PhoneType_Id(FC_HELPER.getFeatureOptionValue(DEFAULT_FEAT_CONFIG_PARM, CmClickIntegrationParametersLookup.constants.PERSON_PRIMARY_PHONE_TYPE, Bool.FALSE, Bool.FALSE));
     	String priorityPhoneTypeList = "";
     	String phoneNum = "";
     	PhoneType phoneType = null;
     	Person person= null;
     	String returnPhoneNum = "";
     	String tempPhoneNum = "";
     	int iCount = 1;
     
     	StringBuilder sqlQuery = new StringBuilder();
		sqlQuery.append(" FROM AccountPerson AP, PersonPhone PP ");
		sqlQuery.append(" WHERE AP.accountRelationshipType.id = :mainRelType ");
		sqlQuery.append(" AND AP.isMainCustomer = :mainCust ");
		sqlQuery.append(" AND AP.id.person.id = PP.id.person.id ");
		sqlQuery.append(" AND AP.id.account.id = :accountId ");
		
		Query<QueryResultRow> query = createQuery(sqlQuery.toString(), getClass().getName());
		AccountRelationshipType_Id acctRelId = new AccountRelationshipType_Id(ACCT_REL_TYPE_MAIN);
		
		query.bindId("mainRelType", acctRelId);
		query.bindBoolean("mainCust", Bool.TRUE);
		query.bindId("accountId", acctId);
		
		query.addResult("phoneType","PP.phoneType");
		query.addResult("phoneNum","PP.phone");
		query.addResult("sequence","PP.id.sequence");
		query.addResult("person","PP.id.person");
		query.orderBy("sequence");
		
		for (QueryResultRow qrrPersonPhone : query.list()){
			phoneNum = qrrPersonPhone.getString("phoneNum");
			phoneType = qrrPersonPhone.getEntity("phoneType", PhoneType.class);
			 
			if(iCount == BigInteger.ONE.intValue()){
				 person = qrrPersonPhone.getEntity("person", Person.class);
				if(person.getPersonOrBusiness().isPerson()){
					priorityPhoneTypeList = personPrioPhoneTypeList;
				} else {
					priorityPhoneTypeList = businessPrioPhoneTypeList;
				}
				tempPhoneNum = phoneNum;
			}
			 
			if(phoneType.getId().equals(primaryPhoneTypeId)){
				returnPhoneNum = phoneNum;
				break;
			} else if (priorityPhoneTypeList.contains(phoneType.getId().getTrimmedValue())){
				returnPhoneNum = phoneNum;
			}
			iCount++;
		}
     
     	 //if no primary contact or contact from priority list return the first contact of the person
     	if(isBlankOrNull(returnPhoneNum)){
     		return tempPhoneNum;
     	} else {
     		return returnPhoneNum;
     	}
    }
	
	private void createFALog(FieldActivity fa, String outboundMsgId){
		StringBuilder getMaxLogSeqStr = new StringBuilder();
		
		getMaxLogSeqStr.append("SELECT NVL(MAX(FAL.SEQ_NUM) + 1, 1) AS MAXSEQ ");
     	getMaxLogSeqStr.append("FROM CI_FA_LOG FAL ");
     	getMaxLogSeqStr.append("WHERE FAL.FA_ID = :faId ");
		
		PreparedStatement maxSeqPrepStmt = createPreparedStatement(getMaxLogSeqStr.toString(), getClass().getName());
     	maxSeqPrepStmt.bindId("faId", fa.getId());
     	SQLResultRow maxSeqRow = maxSeqPrepStmt.firstRow();
     	maxSeqPrepStmt.close();
     
     	// Create FA Log
		StringBuilder sqlInsert = new StringBuilder();
        sqlInsert.append(" INSERT INTO CI_FA_LOG (FA_ID,SEQ_NUM,FA_LOG_TYP_FLG,USER_ID,VERSION,FA_LOG_TEXT,LOG_DTTM) ");
     	sqlInsert.append(" VALUES ( ");
     	sqlInsert.append(" :faId, ");
     	sqlInsert.append(" :seqNum, ");
     	sqlInsert.append(" :faLogType, ");
     	sqlInsert.append(" :user, ");
     	sqlInsert.append(" 1, ");
     	sqlInsert.append(" :faLogText, ");
     	sqlInsert.append(" :logDttm ");
     	sqlInsert.append(" ) ");
		
		PreparedStatement sqlInsertPrepStmt = createPreparedStatement(sqlInsert.toString(), getClass().getName());
     	sqlInsertPrepStmt.bindId("faId", fa.getId());
     	sqlInsertPrepStmt.bindString("seqNum", maxSeqRow.getInteger("MAXSEQ").toString(), "SEQ_NUM");
     	sqlInsertPrepStmt.bindString("faLogType", FA_LOG_TYPE_OUTB, "FA_LOG_TYP_FLG");
     	sqlInsertPrepStmt.bindId("user", getActiveContextUser().getId());
     	sqlInsertPrepStmt.bindString("faLogText", CustomMessageRepositorySpireOne.CCB026_3_FaLogMessageOutboundCreated(outboundMsgId).getMessageText(), "FA_LOG_TEXT");
     	sqlInsertPrepStmt.bindDateTime("logDttm", getProcessDateTime());
     	sqlInsertPrepStmt.execute();
     	sqlInsertPrepStmt.close();
    }
	
	public void getFaTypeDiconAndReconFromCustPortalConfig(){
     	// Read Customer Portal Configuration
        BusinessObjectInstance boInstance = BusinessObjectInstance.create(CUST_PORTAL_CONFIG);
        boInstance.set(SERVICE_TASK_TYPE, CUSTOMER_PORTAL_SERVICE_TASK_TYPE);
        boInstance = BusinessObjectDispatcher.read(boInstance);
     
        COTSInstanceNode outageAct = boInstance.getGroup(OUTAGE_ACTIVITY_FRP);
        faTypeDisconnect = outageAct.getString(DC_FA_TYPE);
        faTypeReconnect = outageAct.getString(RECON_FA_TYPE);
        // 2021-12-20 FRoig B-20167 Start Add
        faTypeMassOutage = outageAct.getString(MASS_OUTAGE_FA_TYPE);
        // 2021-12-20 FRoig B-20167 End Add
    }
	
	private Bool determineIfFAIsForAdd(FieldActivity fa){
        // Check that this is for Add action
        PageHeader pageHeader = new PageHeader();
        pageHeader.put("FA_ID", fa.getId().getIdValue());

        PageBody pageBody = ServiceDispatcher.readItem("CMLONFAP", pageHeader, SessionHolder.getSession().getRequestContext(),false);

        boolean faIsBeingCreated = (boolean) pageBody.get("CREATE_SW");

        if (faIsBeingCreated){
            return Bool.TRUE;
        }
		
		return Bool.FALSE;
	}
	
	private Bool determineIfOldFAImmediateStatusIsNotDispatched(FieldActivity fa){
        PageHeader pageHeader = new PageHeader();
        pageHeader.put("FA_ID", fa.getId().getIdValue());

        PageBody pageBody = ServiceDispatcher.readItem("CMFADINT", pageHeader, SessionHolder.getSession().getRequestContext(),false);

        boolean faOldImmediateStatusIsNotDispatched = (boolean) pageBody.get("UPDATE_SW");

        if (faOldImmediateStatusIsNotDispatched){
            return Bool.TRUE;
        }
		
		return Bool.FALSE;
	}
}
