/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Customer Data Extract Record for Fidelity
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2021-05-24	NMendo			CCB031.1. Initial Version.
 **************************************************************************/
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

/**
 * @author NMendo
 */
public class CmFidelityCustomerDataExtractRecord extends ColumnDelimitedRecord{
    
    // Constants
	private static final String SPACE = " ";
	private static final String BLANK = "";
	
    public CmFidelityCustomerDataExtractRecord() {
        super(15);
    }
    
    public void setAccountNumber(String accountNumber) {
        this.rightPadColumn(1, 13, accountNumber);
        setFiller(2, 1);
    }
    
    public void setCustomerName(String customerName) {
        this.rightPadColumn(3, 26, formatString(customerName, 26));
        setFiller(4, 1);
    }
    
    public void setPremiseAddress(String premiseAddress) {
        this.rightPadColumn(5, 79, formatString(premiseAddress, 79));
        setFiller(6, 1);
    }
    
    public void setCity(String city) { 
    	this.rightPadColumn(7 , 29, formatString(city , 29));
    	setFiller(8, 1);
    }
    
    public void setState(String state) {
    	this.rightPadColumn(9, 2, formatString(state , 2));
    	setFiller(10, 1);
    }
    
    public void setZipCode(String zipCode) {
    	this.rightPadColumn(11, 5, formatString(zipCode , 5));
    	setFiller(12, 1);
    }
    
    public void setPhoneNumber(String phoneNumber) {
    	this.rightPadColumn(13, 10, formatString(phoneNumber , 10));
    	setFiller(14, 1);
    }
    
    public void setAcceptChecks(String acceptChecks) {
    	this.rightPadColumn(15, 1, acceptChecks);
    }

    /**
     * Set Filler
     * @param columnNumber
     * @param length
     */
    private void setFiller(int columnNumber , int length) {
        this.rightPadColumn(columnNumber, length, SPACE);
    }
    
    /**
     * Returns "" if text is null;
     * Truncates text if length exceed fieldLength;
     * @param text
     * @param fieldLength
     * @return String
     */
    private String formatString(String text, int fieldLength) {
        if(text == null) {
            text = BLANK;
        }
        else {
            text = text.trim();
            if(text.length() > fieldLength) {
                text = text.substring(0, fieldLength);
            }
        }
        return text;
    }
}
