/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPCXWOX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      RI0016. Initial Version.  
 * 2016-05-23   MPang       Defect 3439849. Added close connection to avoid
 *                          UniversalPoolConnectionException.      
 * 2016-09-27   SFelip      Defect 3512842. Add a warning if the 
 *                          ADDRESS-FOUND-SW of Cmpcxccx returns N.
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.    
 * 2022-10-24   DLampa      E-06060. Extract the bill format flag depending 
 *                          on the account's CIS Division. 
 * 2025-11-14   EQuint      CCB25.4 Upgrade                                           
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.letterTemplate.algorithm.letterExtract;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.batch.batchRun.BatchRun;
import com.splwg.base.domain.common.algorithm.Algorithm;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.domain.report.reportDefinition.ReportDefinition;
import com.splwg.base.domain.report.reportDefinition.ReportDefinition_Id;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.letterTemplate.algorithm.letterExtract.LetterTemplateLetterExtractAlgorithmSpot;
import com.splwg.ccb.domain.admin.letterTemplate.entity.LetterTemplate;
import com.splwg.ccb.domain.common.fileHelper.FileHelper;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpcxwox;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = cisDivisionForFormat, required = true, type = string)})
 */
public class CmCreateWriteOffEventLetterExtractAlgComp_Impl extends
		CmCreateWriteOffEventLetterExtractAlgComp_Gen implements
		LetterTemplateLetterExtractAlgorithmSpot {

	// hard parameters
	private BigInteger customerContactExtractedCount;
	private ReportDefinition reportDefinition;
	private BatchRun batchRun;
	private CustomerContact customerContact;
	private String extractFileName;
	private FileHelper fileHelper;
	private Bool isFieldDelimited;
	private Bool isFirstHeaderDelimited;
	private Algorithm letterExtractAlgorithm;
	private LetterTemplate letterTemplate;
	private CustomerContact toCustomerContact;
	
    // Start Add - E-06060 - DLampa - 10-24-2022
	// Soft parameters
    private String parmCisDivisionsForFormat;
    // End Add - E-06060 - DLampa - 10-24-2022
	
	private Cmpcxwox cmpcxwox;
	
	//Start Add - MPang - Defect 3439849 - 2016-05-23
    private Connection connection;
    //End Add - MPang - Defect 3439849 - 2016-05-23
    // Start Add - E-06060 - DLampa - 10-24-2022
    private ArrayList<CisDivision> wCisDivisionsForFormat = new ArrayList<CisDivision>();
    // End Add - E-06060 - DLampa - 10-24-2022   
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	
	
	@Override
	public BigInteger getCustomerContactExtractedCount() {
		return customerContactExtractedCount;
	}

	@Override
	public ReportDefinition getReportDefinition() {
		return reportDefinition;
	}

	@Override
	public void setBatchRun(BatchRun arg0) {
		batchRun = arg0;
	}

	@Override
	public void setCustomerContact(CustomerContact arg0) {
		customerContact = arg0;
	}

	@Override
	public void setCustomerContactExtractedCount(BigInteger arg0) {
		customerContactExtractedCount = arg0;
	}

	@Override
	public void setExtractFileName(String arg0) {
		extractFileName = arg0;
	}

	@Override
	public void setFileHelper(FileHelper arg0) {
		fileHelper = arg0;
	}

	@Override
	public void setIsFieldDelimited(Bool arg0) {
		isFieldDelimited = arg0;
	}

	@Override
	public void setIsFirstHeaderDelimited(Bool arg0) {
		isFirstHeaderDelimited = arg0;
	}

	@Override
	public void setLetterExtractAlgorithm(Algorithm arg0) {
		letterExtractAlgorithm = arg0;
	}

	@Override
	public void setLetterTemplate(LetterTemplate arg0) {
		letterTemplate = arg0;
	}

	@Override
	public void setToCustomerContact(CustomerContact arg0) {
		toCustomerContact = arg0;
	}
	
	
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		
        // Start Add - E-06060 - DLampa - 10-24-2022
        // CIS Divisions for Format
        parmCisDivisionsForFormat = getCisDivisionForFormat();
        String[] cisDivisions = parmCisDivisionsForFormat.split(",");

        for (int i=0; i < cisDivisions.length; i++){
            String cisDivStr = cisDivisions[i];
            CisDivision cisDivision = new CisDivision_Id(cisDivStr.trim()).getEntity();
            if (isNull(cisDivision)){
                addError(CustomMessageRepository.E06060_AlgParmContainsInvalidCisDivision(
                        getAlgorithm().getAlgorithmType().getParameterAt(0).fetchLanguageParameterLabel(),
                        cisDivStr));
            }
            wCisDivisionsForFormat.add(cisDivision);
        }
        // End Add - E-06060 - DLampa - 10-24-2022 
        
	}

	@Override
	public void invoke() {
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			if(notNull(customerContact)) {
				cmpcxwox.setInputWrkCcId(customerContact.getId().getTrimmedValue());
			}else{
				cmpcxwox.setInputWrkCcId(CobolCode.SPACES.toString());
			}
			if(notNull(batchRun)) {
				cmpcxwox.setInputWrkBatchCd(batchRun.fetchIdBatchControl().getId().getTrimmedValue());
				cmpcxwox.setInputWrkBatchNbr(java.math.BigDecimal.valueOf(batchRun.fetchIdBatchNumber().doubleValue()));
			}else{
				cmpcxwox.setInputWrkBatchCd(CobolCode.SPACES.toString());
				cmpcxwox.setInputWrkBatchNbr(java.math.BigDecimal.ZERO);
			}
			if(notNull(letterTemplate)) {
				cmpcxwox.setInputWrkLtrTmplCd(letterTemplate.getId().getTrimmedValue());
			}else{
				cmpcxwox.setInputWrkLtrTmplCd(CobolCode.SPACES.toString());
			}
			if (notNull(letterExtractAlgorithm)) {
				cmpcxwox.setExtractAlgCd(letterExtractAlgorithm.getId().getTrimmedValue());
			}else{
				cmpcxwox.setExtractAlgCd(CobolCode.SPACES.toString());
			}
			if(notBlank(extractFileName)) {
				cmpcxwox.setExtractFileName(extractFileName.trim());
			}else{
				cmpcxwox.setExtractFileName(CobolCode.SPACES.toString());
			}
			
			if(notNull(isFieldDelimited)) {
				String isFieldDelimitedSw = (isFieldDelimited.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpcxwox.setFieldDelimSw(isFieldDelimitedSw);
			}else{
				cmpcxwox.setFieldDelimSw(CobolCode.SPACES.toString());
			}
			if(notNull(isFirstHeaderDelimited)) {
				String isFirstHeaderDelimitedSw = (isFirstHeaderDelimited.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpcxwox.setDelim_1stHeaderSw(isFirstHeaderDelimitedSw);
			}else{
				cmpcxwox.setDelim_1stHeaderSw(CobolCode.SPACES.toString());
			}
			if(notNull(toCustomerContact)) {
				cmpcxwox.setToCcId(toCustomerContact.getId().getTrimmedValue());
			}else{
				cmpcxwox.setToCcId(CobolCode.SPACES.toString());
			}
			if (notNull(customerContactExtractedCount)) {
				cmpcxwox.setCcExtractedCnt(java.math.BigDecimal.valueOf(customerContactExtractedCount.doubleValue()));
			}else{
				cmpcxwox.setCcExtractedCnt(java.math.BigDecimal.ZERO);
			}
			
	        // Start Add - E-06060 - DLampa - 10-24-2022
			cmpcxwox.setAlgParmVal(1, getBillFormatFlag());
	        // End Add - E-06060 - DLampa - 10-24-2022
			
			// invoke the main method
		    cmpcxwox.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
		    while(ex.getCause()!=null) ex=ex.getCause();
		    if(ex instanceof Stop) {
		    	if (cmpcxwox.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmpcxwox.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmpcxwox.getMessageParm(i);
			    			if (notBlank(cmpcxwox.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmpcxwox.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmpcxwox.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmpcxwox.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmpcxwox.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    	customerContactExtractedCount = cmpcxwox.getCcExtractedCnt().toBigInteger();
		    	reportDefinition = new ReportDefinition_Id(cmpcxwox.getReportCd().trim()).getEntity();
		    	
		    	// Start Add - SFelip - Defect 3512842 - 2016-09-27
                if(cmpcxwox.getIgnoreWarningSw().equals(SWITCH_NO)) {
                    if(cmpcxwox.getOutputWrkAddressFoundSw().equals(SWITCH_NO)) {
                        addWarning(CustomMessageRepository.DEFECT_3512842_addressNotFound(customerContact.getId().getTrimmedValue()));
                    }
                }
                // End Add - SFelip - Defect 3512842 - 2016-09-27
		    	
		    }
		    else {
		        //Start Add - MPang - Defect 3439849 - 2016-05-23
		        ex.printStackTrace();
		        //End Add - MPang - Defect 3439849 - 2016-05-23
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmpcxwox=Session.returnSessionAndCodeToCache(cmpcxwox);
			
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//			//Start Add - MPang - Defect 3439849 - 2016-05-23
//            try {
//                connection.close();
//            } catch (SQLException e) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
//            }
//            //End Add - MPang - Defect 3439849 - 2016-05-23
            // end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}

	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
        FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
	    RequestContext context = session.getRequestContext();
	    
	    // start update - equint - 2025-11-14 - CCB25.4 Upgrade
  		session.doWork(new ConnectionWork() {
  			
  			@Override
  			public void execute(Connection connection) throws SQLException {
  				try {  
  					String username = connection.getMetaData().getUserName();
  					String url = connection.getMetaData().getURL();
  					
  					CobolSession.setLogSessionStartEnd(false);
  				    cmpcxwox=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpcxwox.class);
  					
  					cmpcxwox.getSession().getDbSession().setUpdateConnection(connection);
  					cmpcxwox.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
  					cmpcxwox.aa100Initialize();
  					// set ZSTAT parameters

  					cmpcxwox.setProcessDt(getProcessDateTime().getDate().toString());
  					cmpcxwox.setProcessDttmSep("-");
  					cmpcxwox.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
  					
  					if (session.isOnlineConnection()) { 
  						cmpcxwox.setConnectionFlg(CONNECTION_ONLINE);
  					}
  					else {
  						cmpcxwox.setConnectionFlg(CONNECTION_BATCH);
  					}
  					
  					cmpcxwox.setUserId(context.getUserId());
  					cmpcxwox.setZstatLanguageCd(context.getLanguageCode());
  			        
  			        if (context.ignoreWarnings()) {
  			        	cmpcxwox.setIgnoreWarningSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpcxwox.setIgnoreWarningSw(SWITCH_NO);
  			        }
  			        
  			        if (session.getBatchInstanceId() != null) {
  			        	cmpcxwox.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
  			        	
  					} else {
  						cmpcxwox.setSchedulerId(new BigDecimal(0).toBigDecimal());
  					}
  			        
  			        cmpcxwox.setAppSvcId(context.getSecurityServiceIdContext());
  			        
  			        DatabaseHelper dbHelper = session.getDatabaseHelper();
  			        cmpcxwox.setDbMode(dbHelper.getCobolDBMode());
  			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
  			        //cmpcxwox.setSplHighValue(cmpcxwox.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
  			        //cmpcxwox.setSplLowValue(cmpcxwox.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
  			        
  			        cmpcxwox.setSplHighValue(cmpcxwox.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
  			        cmpcxwox.setSplLowValue(cmpcxwox.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
  			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
  			        
  			        cmpcxwox.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
  			        
  			        cmpcxwox.setLkExpiryDt(Date.MAX.toString());
  			        
  			        cmpcxwox.setProgramStatus(" ");
  			        
  			        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
  			        cmpcxwox.setCallSeq(";");
  			        cmpcxwox.setMessageAreaProgramName("CMPCXWOX");
  			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
  			        
  			        if (context.getRandomGeneratorSeedSet().isTrue()) {
  			        	cmpcxwox.setRandomGenSeedSw(SWITCH_YES);
  			        	cmpcxwox.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
  			        	cmpcxwox.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
  			        	cmpcxwox.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
  			        	cmpcxwox.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
  			        }
  			        else {
  			        	cmpcxwox.setRandomGenSeedSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceStandardOut()) { 
  			        	cmpcxwox.setTrcStdoutSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpcxwox.setTrcStdoutSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramStart()) { 
  			        	cmpcxwox.setTrcProgStartSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpcxwox.setTrcProgStartSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramExit()) { 
  			        	cmpcxwox.setTrcProgExitSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpcxwox.setTrcProgExitSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceSQL()) { 
  			        	cmpcxwox.setTrcExecSqlSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpcxwox.setTrcExecSqlSw(SWITCH_NO);
  			        }
  			        
  			        // Set ZMSGN parms
  			        BigInteger messageSequence = session.getMessageSequence();
  			        if (notNull(messageSequence)) {
  			        	cmpcxwox.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
  			        }
  			        else {
  			        	cmpcxwox.setMessageSeq(new BigDecimal(0).toBigDecimal());
  			        }
  				}
  				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		 
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//		//Start Change - MPang - Defect 3439849 - 2016-05-23
//        //Connection connection = implementor.getConnectionProvider().getConnection();
//        connection = implementor.getConnectionProvider().getConnection();
//        //End Change - MPang - Defect 3439849 - 2016-05-23  		
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmpcxwox=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpcxwox.class);
//		
//		cmpcxwox.getSession().getDbSession().setUpdateConnection(connection);
//		cmpcxwox.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		cmpcxwox.aa100Initialize();
//		// set ZSTAT parameters
//
//		cmpcxwox.setProcessDt(getProcessDateTime().getDate().toString());
//		cmpcxwox.setProcessDttmSep("-");
//		cmpcxwox.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmpcxwox.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmpcxwox.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmpcxwox.setUserId(context.getUserId());
//		cmpcxwox.setZstatLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmpcxwox.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxwox.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmpcxwox.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmpcxwox.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmpcxwox.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmpcxwox.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmpcxwox.setSplHighValue(cmpcxwox.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmpcxwox.setSplLowValue(cmpcxwox.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmpcxwox.setSplHighValue(cmpcxwox.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmpcxwox.setSplLowValue(cmpcxwox.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmpcxwox.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmpcxwox.setLkExpiryDt(Date.MAX.toString());
//        
//        cmpcxwox.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmpcxwox.setCallSeq(";");
//        cmpcxwox.setMessageAreaProgramName("CMPCXWOX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmpcxwox.setRandomGenSeedSw(SWITCH_YES);
//        	cmpcxwox.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmpcxwox.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmpcxwox.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmpcxwox.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmpcxwox.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmpcxwox.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxwox.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmpcxwox.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxwox.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmpcxwox.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxwox.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmpcxwox.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxwox.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmpcxwox.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmpcxwox.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }
  		
  	// end update - equint - 2025-11-14 - CCB25.4 Upgrade

	}
	
    // Start Add - E-06060 - DLampa - 10-24-2022
    private String getBillFormatFlag() {

        String billFormatFlag = "";        

        if (notNull(customerContact.fetchAccount())) {
            Account acct = customerContact.fetchAccount();
            if (wCisDivisionsForFormat.contains(acct.getDivisionId().getEntity())){          	
                AccountPerson_Id acctPerID = new AccountPerson_Id(customerContact.getPersonId(), acct.getId());
                AccountPerson acctPer = acctPerID.getEntity();

                billFormatFlag = acctPer.getBillFormat().trimmedValue();
            }            
        }
        
        return billFormatFlag;
    }
    // End Add - E-06060 - DLampa - 10-24-2022  	

}
