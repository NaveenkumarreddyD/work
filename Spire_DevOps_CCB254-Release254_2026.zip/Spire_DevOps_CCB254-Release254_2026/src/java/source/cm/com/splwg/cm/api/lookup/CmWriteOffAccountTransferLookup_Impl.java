/**************************************************************************
* Program Name: CmWriteOffAccountTransferLookup_Impl
* Program Title: CmWriteOffAccountTransferLookup_Impl
* Author: ACasta
* Creation Date: 2017-07-13
* Purpose: Write Off Account Transfer Lookup
* Functional Spec: SA-68629
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:         Date:         Description:
.* ----------------------------------------------------------------------------------------------
 * SA-68629           Alfonso Castano 2017-07-13    Initial Version.
 ************************************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author ACasta
 *
@LookupFieldname (value = WOAT_OPT_TYP_FLG)
 */
public class CmWriteOffAccountTransferLookup_Impl extends
        CmWriteOffAccountTransferLookup_Gen {

}
