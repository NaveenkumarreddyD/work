/*****************************************************************************************
 * Program Name: CmAccumulateDegreeDaysAlgComp_Impl
 * Program Title: CmAccumulateDegreeDaysAlgComp_Impl
 * Author: Jain Akshita
 * Creation Date: 2019-05-20
 * Purpose: Lookup for degree day
 * 
 ******************************************************************************************/
/*----------------------------------------------------------------------------------------
 *-------------------------- Modification HISTORY: ---------------------------------------
 * ---------------------------------------------------------------------------------------
 * Modification ID:   CCTicket:	  Author:          Date:       Description:
.* --------------------------------------------------------------------------------------
 * CCB001  	       	   45936  	 Jain Akshita     2019-05-20   TMG02493 - Initial Version                 
 *                                                                                                                       
 *****************************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author TMG02493
 *
@LookupFieldname (value = CM_DEGREE_DAYS_LKP)
 */
public class CmDegreeDaysTypeLookup_Impl extends CmDegreeDaysTypeLookup_Gen {

}
