/*
 ***********************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * CCB030.2 - Payment Return for Spire AL and Gulf
 * 
 * This batch process reads and uploads payment return files from Spire AL and Gulf payment 
 * vendors that use a common file layout. It will read the inbound payment returns file and 
 * load the records into the notification upload staging table. The records will have a specific 
 * notification upload type to distinguish them from other notification upload records, 
 * as well as other return records for Spire MO, pledges, and/or collection returns.
 *
 ***********************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2021-03-30   PRavel          CCB030.2. Initial Version.
 * 2021-06-01   NMendo          CCB030.Issue1. Add logic to check if file has been processed
 * 2021-06-22   RDizon          CCB030.Issue2. Remove raising errors for invalid Account Numbers.
 * 2021-06-28   FRoig           Defect 4564480. Batch job should complete with 0 records 
 * 								when file is empty.
 * 2021-09-28   GCrisp          Defect 4599783. Fix the retrieval of Account ID.
 * 2025-12-01   EQuint      	CCB25.4 Upgrade    
 ***********************************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.lookup.NotificationUploadExtensionLookup;
import com.splwg.base.api.lookup.NotificationUploadStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.lookup.LookupField_Id;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.domain.workflow.notificationExternalId.NotificationExternalId;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadContext_DTO;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadContext_Id;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload_DTO;
import com.splwg.base.domain.workflow.notificationUploadExtensionType.NotificationUploadExtensionType;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.api.lookup.NotificationUploadContextLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

/**
 * @author PRavel
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = filePath, required = true, type = string)
 *            , @BatchJobSoftParameter (name = fileName, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = notificationExternalId, name = externalId, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = notificationUploadExtensionType, name = notificationType, required = true, type = entity)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = accountContext, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = amountContext, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = returnPayDateContext, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = returnReasonContext, required = true, type = lookup)})
 */
public class CmPayReturnAlGulfUploadBatch extends 
                CmPayReturnAlGulfUploadBatch_Gen {
  
    @Override
    public JobWork getJobWork() {
            ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
            ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
            arrayList.add(threadWorkUnit);

            return createJobWorkForThreadWorkUnitList(arrayList);
    }
    
    public Class<CmPayReturnAlGulfUploadBatchWorker> getThreadWorkerClass() {
        return CmPayReturnAlGulfUploadBatchWorker.class;
    }

    public static class CmPayReturnAlGulfUploadBatchWorker extends
            CmPayReturnAlGulfUploadBatchWorker_Gen {

        // Constants
        private static final int RECORD_SIZE = 40;
        private static final String REC_TYPE_NSF = "NSF";
        private static final String REC_TYPE_BNK = "BNK";
        private static final String REC_TYPE_TOT = "TOT";
        private static final String DATE_FORMAT = "yyyyMMdd";
        private static final String NEW_DATE_FORMAT = "MMddyy";
        private static final String ZERO = "0";
        private static final int START_INDEX_DATE = 3;
        private static final int END_INDEX_DATE = 11;
        private static final int START_INDEX_ACCT = 11;
        private static final int END_INDEX_ACCT = 23;
        private static final int START_INDEX_RET_RSN = 24;
        private static final int END_INDEX_RET_RSN = 27;
        private static final int START_INDEX_AMOUNT = 27;
        private static final int END_INDEX_AMOUNT = 36;
        private static final int START_INDEX_TOT_ITEM = 11;
        private static final int END_INDEX_TOT_ITEM = 18;
        private static final int START_INDEX_TOT_AMT = 18;
        private static final int END_INDEX_TOT_AMT = 31;
        private static final String CM_PAY_REASON_LOOKUP = "CM_PAY_CAN_RSN";
        private static final String DATE_COLUMN_NAME = "Date";
        private static final String ACCT_COLUMN_NAME = "Account";
        private static final String AMOUNT_COLUMN_NAME = "Paid Amount";
        private static final String RETURN_REASON_COLUMN_NAME = "Return Reason";
        private static final String ITEM_COLUMN_NAME = "Total Items";
        private static final String TOT_AMOUNT_COLUMN_NAME = "Total Amount";
        
        // Work Variables
        private String filePath;
        private String fileName;
        private NotificationExternalId externalId;
        private NotificationUploadExtensionType notificationType;
        private NotificationUploadContextLookup accountContext;
        private NotificationUploadContextLookup amountContext;
        private NotificationUploadContextLookup retPayDateContext;
        private NotificationUploadContextLookup retReasonContext;
        private ServerMessage serverMessage = null;
        
        // File Variables
        private File uploadFile;
        private BufferedReader uploadFileReader;
        private String fileNamePath;
        
        // Counter Variables
        private Integer recordsInError;
        private Integer recordsProcessed;
        private BigDecimal totalAmount = BigDecimal.ZERO;
        private Integer totalItems = 0;
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new SingleTransactionStrategy(this);
        }     

        @Override
        public void initializeThreadWork(boolean initializationPreviouslySuccessful)
                throws ThreadAbortedException, RunAbortedException {
            // Retrieve parameters
            filePath = getParameters().getFilePath();
            fileName = getParameters().getFileName();
            externalId = getParameters().getExternalId();
            notificationType = getParameters().getNotificationType();
            accountContext = getParameters().getAccountContext();
            amountContext = getParameters().getAmountContext();
            retPayDateContext = getParameters().getReturnPayDateContext();
            retReasonContext = getParameters().getReturnReasonContext();
            
            // Start Add - NMendo - CCB030.Issue1 -  2021-06-01
            // Check if the file has already been processed.
            checkIfFileAlreadyProcessed();
            // End Add - NMendo - CCB030.Issue1 -  2021-06-01
            
            // Open Upload File
            // Start Change - NMendo - CCB030.Issue1 -  2021-06-01
            //try {
            //    uploadFile = new File(filePath,fileName);   
            //    uploadFileReader = new BufferedReader(new FileReader(uploadFile)); 
            //}
            //catch(Exception e) {
            //    e.printStackTrace();
            //    throw new RunAbortedException(CustomMessageRepositorySpireOne.ccb030_2_errorOpeningFile(e.getLocalizedMessage()));
            //}
            openFile();
            // End Change - NMendo - CCB030.Issue1 -  2021-06-01
            
          
            fileNamePath = uploadFile.getAbsolutePath();
            
            // Initialize variables
            serverMessage = null;
            recordsInError = 0;
            recordsProcessed = 0;
        }

        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
            
            // Validate Upload File Record
            Bool isValid = processUploadFile();
            if(isValid.isFalse()) {   
                recordsInError = 1;
                recordsProcessed = 1;
                
                throw new RunAbortedException(serverMessage);
            }
            else {
                totalItems = totalItems - 1;
                recordsProcessed = totalItems;
                logMessage(CustomMessageRepositorySpireOne.ccb030_2_totalRecordProcessed(
                        totalItems.toString()), MessageSeverityLookup.constants.INFORMATIONAL);
                logMessage(CustomMessageRepositorySpireOne.ccb030_2_totalAmountProcessed(
                        totalAmount.toString()), MessageSeverityLookup.constants.INFORMATIONAL);

            }
            
            WorkUnitResult workUnitResult = new WorkUnitResult(true);
            workUnitResult.setUnitsProcessed(recordsProcessed);
            workUnitResult.setUnitsInError(recordsInError);
            
            
            return workUnitResult;
        }
        
        /**
         * Process and Read the File Record
         * @return Bool
         */
        private Bool processUploadFile() { 
            String fileRecord = "";
            String record = "";

            // Read file record
            fileRecord = readFileRecord();
            
            // Check if file is blank
            if(isBlankOrNull(fileRecord)) {
                // Start Delete - FRoig - Defect 4564480 - 2021-06-28
                //serverMessage = CustomMessageRepositorySpireOne.ccb030_2_fileIsEmpty(fileNamePath);
                //return Bool.FALSE;              
                // End Delete - FRoig - Defect 4564480 - 2021-06-28
                // Start Add - FRoig - Defect 4564480 - 2021-06-28
            	// Set total to 1, since the batch job always subtracts 1 later.
            	totalItems = 1; 
            	return Bool.TRUE;
                // End Add - FRoig - Defect 4564480 - 2021-06-28
            }
            
            // Loop through records
            while(!isNull(fileRecord)) {   
                // Increment Process Record
                totalItems = totalItems + 1;
                    
                    // Check if file line is blank
                    if(isBlankOrNull(fileRecord)) {
                        serverMessage = CustomMessageRepositorySpireOne.ccb030_2_noRecordLineFound(
                                totalItems.toString(), fileNamePath);
                        return Bool.FALSE;              
                    }

                    // Validate max record line size
                    if(fileRecord.length() != RECORD_SIZE) {
                        serverMessage = CustomMessageRepositorySpireOne.ccb030_2_fileRecordExceedsLimit(
                                totalItems.toString(), fileNamePath);
                        return Bool.FALSE;
                    }
                    
                    // Validate Record Type
                    record = readParsedRecord(fileRecord, 0, 3);
                    if(record.compareTo(REC_TYPE_NSF) != 0 && record.compareTo(REC_TYPE_BNK) != 0
                            && record.compareTo(REC_TYPE_TOT) != 0) {
                        serverMessage = CustomMessageRepositorySpireOne.ccb030_2_recordTypeIsInvalid(record, 
                                totalItems.toString(), fileNamePath);
                        return Bool.FALSE;
                    }
                    
                    if(record.compareTo(REC_TYPE_TOT) != 0) {
                        if(processDetailRecord(fileRecord).isFalse()) {
                            return Bool.FALSE;
                        }
                    }
                    else {
                        if(processTrailerRecord(fileRecord).isFalse()) {
                            return Bool.FALSE;
                        }
                    }
                    
                    // Read next file record
                    fileRecord = readFileRecord();
            }

            return Bool.TRUE;
        }
        
        /**
         * Try Reading the File Record
         * @return fileRecord
         */
        private String readFileRecord() {
            // Read file record
            String fileRecord = "";
            try {
                fileRecord = uploadFileReader.readLine();
            }
            catch(Exception e) {
                e.printStackTrace();
                throw new RunAbortedException(CustomMessageRepositorySpireOne.ccb030_2_errorReadingFile(fileNamePath));
            }
            
            return fileRecord;
        }
        
        /**
         * Read and Validate the Detail Record
         * @param fileRecord
         * @return Bool
         */
        private Bool processDetailRecord(String fileRecord) {
            // Validate Date
            String recordDate = readParsedRecord(fileRecord, START_INDEX_DATE, END_INDEX_DATE);
            if(checkIfRecordValueIsBlank(DATE_COLUMN_NAME, recordDate).isFalse()) {
                return Bool.FALSE;
            }
            
            if(isValidDate(recordDate).isFalse()) {
                serverMessage = CustomMessageRepositorySpireOne.ccb030_2_invalidRecordValueForColumn(DATE_COLUMN_NAME, 
                        recordDate, totalItems.toString(), fileNamePath);
                return Bool.FALSE;
            }
            
            recordDate = changeDateFormat(recordDate);
            
            // Validate Account 
			// Start Change - GCrisp - Defect 4599783 - 2021-09-28
			//String recordAccount = readParsedRecord(fileRecord, START_INDEX_ACCT, END_INDEX_ACCT);
			//Check if the filler column after the Account Number is populated
			String isFillerPopulated = readParsedRecord(fileRecord, END_INDEX_ACCT, END_INDEX_ACCT+1);
			String recordAccount;
			if(isBlankOrNull(isFillerPopulated)){
				recordAccount = readParsedRecord(fileRecord, START_INDEX_ACCT, END_INDEX_ACCT);
			}else {
				//If filler is populated, include it in the Account (Account becomes 13-digits)
				recordAccount = readParsedRecord(fileRecord, START_INDEX_ACCT, END_INDEX_ACCT+1);
			}
			// End Change - GCrisp - Defect 4599783 - 2021-09-28
            
            if(checkIfRecordValueIsBlank(ACCT_COLUMN_NAME, recordAccount).isFalse()) {
                return Bool.FALSE;
            }
            
            String account = getCleanAccount(recordAccount);
            // Start Delete - RDizon - CCB030.Issue2 -  2021-06-22
            // if(isValidAccount(account).isFalse()) {
            //     serverMessage = CustomMessageRepositorySpireOne.ccb030_2_invalidRecordValueForColumn(ACCT_COLUMN_NAME, 
            //             account, totalItems.toString(), fileNamePath);
            //     return Bool.FALSE;
            // }
            // End Delete - RDizon - CCB030.Issue2 -  2021-06-22
            
            // Validate Return Reason
            String returnReason = readParsedRecord(fileRecord, START_INDEX_RET_RSN, END_INDEX_RET_RSN);
            
            if(checkIfRecordValueIsBlank(RETURN_REASON_COLUMN_NAME, returnReason).isFalse()) {
                return Bool.FALSE;
            }
            
            if(isValidReturnReason(returnReason).isFalse()) {
                serverMessage = CustomMessageRepositorySpireOne.ccb030_2_invalidRecordValueForColumn(RETURN_REASON_COLUMN_NAME, 
                        returnReason, totalItems.toString(), fileNamePath);
                return Bool.FALSE;
            }
            
            LookupField_Id returnReasonLookupField = new LookupField_Id(CM_PAY_REASON_LOOKUP);
            LookupValue_Id returnReasonLookupValue = new LookupValue_Id(returnReasonLookupField.getEntity(), returnReason);
            
            // Validate Amount
            String recordAmount = readParsedRecord(fileRecord, START_INDEX_AMOUNT, END_INDEX_AMOUNT);
            if(checkIfRecordValueIsBlank(AMOUNT_COLUMN_NAME, recordAmount).isFalse()) {
                return Bool.FALSE;
            }
            
            if(isNumeric(recordAmount).isFalse()) {
                serverMessage = CustomMessageRepositorySpireOne.ccb030_2_invalidRecordValueForColumn(AMOUNT_COLUMN_NAME, 
                        recordAmount, totalItems.toString(), fileNamePath);
                return Bool.FALSE;
            }
            
            BigDecimal paidAmount = parsePaidAmount(recordAmount);
            totalAmount = totalAmount.add(paidAmount);
            
            // Upload Notification Staging
            try {
                startChanges();
                NotificationUpload notifUploadId = createNTUpload();
                createNTUploadContext(notifUploadId, accountContext, account);
                createNTUploadContext(notifUploadId, retReasonContext, returnReasonLookupValue.getEntity().fetchLanguageDescription());
                createNTUploadContext(notifUploadId, retPayDateContext, recordDate);
                createNTUploadContext(notifUploadId, amountContext, paidAmount.toString());
                saveChanges();
            } catch(ApplicationError ae) {
                serverMessage = CustomMessageRepositorySpireOne.ccb030_2_errorUpdStaging(ae.getLocalizedMessage());
             }
            return Bool.TRUE;
        }
        
        /**
         * Read and Validate Trailer Record
         * @param fileRecord
         * @return Bool
         */
        private Bool processTrailerRecord(String fileRecord) {
            // Validate date
            String trailerDate = readParsedRecord(fileRecord, START_INDEX_DATE, END_INDEX_DATE);
            if(checkIfRecordValueIsBlank(DATE_COLUMN_NAME, trailerDate).isFalse()) {
                return Bool.FALSE;
            }
            
            if(isValidDate(trailerDate).isFalse()) {
                serverMessage = CustomMessageRepositorySpireOne.ccb030_2_invalidRecordValueForColumn(DATE_COLUMN_NAME, 
                        trailerDate, totalItems.toString(), fileNamePath);
                return Bool.FALSE;
            }
            
            // Validate Number of Items
            String trailerTotalItem = readParsedRecord(fileRecord, START_INDEX_TOT_ITEM, END_INDEX_TOT_ITEM);
            if(checkIfRecordValueIsBlank(ITEM_COLUMN_NAME, trailerTotalItem).isFalse()) {
                return Bool.FALSE;
            }

            if(isNumeric(trailerTotalItem).isFalse()) {
                serverMessage = CustomMessageRepositorySpireOne.ccb030_2_invalidRecordValueForColumn(ITEM_COLUMN_NAME, 
                        trailerTotalItem, totalItems.toString(), fileNamePath);
                return Bool.FALSE;
            }
            Integer trailerNumItem = Integer.parseInt(trailerTotalItem);
            
            // Disregard Trailer Line Record
            totalItems = totalItems - 1;
           
            // Compare if Total Items and Trailer Total Items is equal
            if(totalItems.compareTo(trailerNumItem) != 0) {
                serverMessage = CustomMessageRepositorySpireOne.ccb030_2_totalItemsNotMatch(
                        totalItems.toString(), trailerNumItem.toString(), fileNamePath);
                return Bool.FALSE;
            }
            
            // Include Trailer as Line Record
            totalItems = totalItems + 1;
            
            // Validate Total Amount
            String trailerAmount = readParsedRecord(fileRecord, START_INDEX_TOT_AMT, END_INDEX_TOT_AMT);
            if(checkIfRecordValueIsBlank(TOT_AMOUNT_COLUMN_NAME, trailerAmount).isFalse()) {
                return Bool.FALSE;
            }

            if(isNumeric(trailerAmount).isFalse()) {
                serverMessage = CustomMessageRepositorySpireOne.ccb030_2_invalidRecordValueForColumn(TOT_AMOUNT_COLUMN_NAME, 
                        trailerAmount, totalItems.toString(), fileNamePath);
                return Bool.FALSE;
            }
            
            BigDecimal trailerNumAmount = parsePaidAmount(trailerAmount);
            // Compare if Total Amount and Trailer Total Amount is equal
            if(totalAmount.compareTo(trailerNumAmount) != 0) {
                serverMessage = CustomMessageRepositorySpireOne.ccb030_2_totalAmountNotMatch(
                        totalAmount.toString(), trailerNumAmount.toString(), fileNamePath);
                return Bool.FALSE;
            }
            
            
            return Bool.TRUE;
        }
        
        /**
         * Get Safely Fixed Size Record
         * @param record
         * @param start
         * @param end
         * @return record
         */
        private String readParsedRecord(String record, int start, int end) {
            return record.substring(start, end);
        }
        
        /**
         * Check if Record Value is blank
         * @param column
         * @param record
         * @return Bool
         */
        private Bool checkIfRecordValueIsBlank(String column, String record) {
            if(isBlankOrNull(record)) {
                serverMessage = CustomMessageRepositorySpireOne.ccb030_2_noRecordValueFoundOnLine(
                        column, totalItems.toString(), fileNamePath);
                return Bool.FALSE;
            }
            return Bool.TRUE;
        }
        
       /**
        * Validate Date Formatting
        * @param date
        * @return Bool
        */
        private Bool isValidDate(String date) {
            DateFormat dateFormat = new DateFormat(DATE_FORMAT);

            try {
                Date.fromString(date, dateFormat);
                
            }
            catch(DateFormatParseException e) {
                return Bool.FALSE;
            }
            
            return Bool.TRUE;
        }
        
        private String changeDateFormat(String value){
            String newDate = value;
            SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT);
            try {
                java.util.Date date = format.parse(value);
                format.applyPattern(NEW_DATE_FORMAT);
                newDate = format.format(date);
            } catch (ParseException e) {
                return newDate;
            }
            
            return newDate;
        }
        /**
         * Determine if possible Old or Current Account
         * @param account
         * @return account
         */
        private String getCleanAccount(String account) {
            // Trim leading spaces
            account = account.trim();
            
            // Start Add - GCrisp - Defect 4599783 - 2021-09-28
            if(account.length() == 13){
				String accountFirstChar = readParsedRecord(account, 0, 1);
                // Account is the next 12-digit number if first char is zero
                if(accountFirstChar.compareTo(ZERO) == 0) {
					account = readParsedRecord(account, 1, 13);
                }
			}
            // End Add - GCrisp - Defect 4599783 - 2021-09-28
            
            // If length is < 12, it is current account
            if(account.length() == 12) {
                // If first char is zero, it is current account. Else, it is old account
                String accountFirstChar = readParsedRecord(account, 0, 1);
                
                if(accountFirstChar.compareTo(ZERO) == 0) {
                    account = readParsedRecord(account, 2, 12);
                }
            }
            
            return account;
        }
        
        // Start Delete - RDizon - CCB030.Issue2 -  2021-06-22
        // /**
        //  * Check if Account is valid 
        //  * @param account
        //  * @return Bool
        //  */
        // private Bool isValidAccount(String accountStr) {
        //     // Check if valid Old Account
        //     if(accountStr.length() == 12) {
        //         String accountFirstChar = readParsedRecord(accountStr, 0, 1);
        //         if(accountFirstChar.compareTo(ZERO) != 0) {
        //             if(isOldAccount(accountStr).isFalse()) {
        //                 return Bool.FALSE;
        //             }
        //         }
        //     }
        //     else {
        //         // Check if valid current Account
        //         Account account = new Account_Id(accountStr).getEntity();
        //         if(isNull(account)) {
        //             return Bool.FALSE;
        //         }
        //     }    
        //     
        //     return Bool.TRUE;
        // }
        // End Delete - RDizon - CCB030.Issue2 -  2021-06-22
        
        /**
         * Check if account is valid Old Account
         * @param oldAccountId
         * @return Bool
         */
        private Bool isOldAccount(String oldAccountId) {
            StringBuilder oldAcctQueryStr = new StringBuilder();
            oldAcctQueryStr.append("SELECT 'X' ");
            oldAcctQueryStr.append("FROM CI_SA ");
            oldAcctQueryStr.append("WHERE OLD_ACCT_ID = :oldAccountId ");

            PreparedStatement oldAcctPrepStmt = createPreparedStatement(oldAcctQueryStr.toString(), getClass().getName()); 

            oldAcctPrepStmt.bindStringProperty("oldAccountId",ServiceAgreement.properties.oldAccountId, oldAccountId.trim()); 
            if(isNull(oldAcctPrepStmt.firstRow())) {
                return Bool.FALSE;
            }

            return Bool.TRUE;
        }
        
        /**
         * Check if record is valid number
         * @param amount
         * @return Bool
         */
        private Bool isNumeric(String amount) {
        	// start change - equint - 2025-12-01 - CCB25.4 Upgrade
            try {
            	
                // new Integer(amount);
                Double.parseDouble(amount);
            }
            // catch(Exception e) { 
            catch(NumberFormatException e) {
            // end change - equint - 2025-12-01 - CCB25.4 Upgrade
                return Bool.FALSE;
            }
            
            return Bool.TRUE;
        }
        
        /**
         * Check if Valid Return Reason Lookup
         * @param returnReason
         * @return Bool
         */
        private Bool isValidReturnReason(String returnReason) {
            LookupField_Id lookupFieldId = new LookupField_Id(CM_PAY_REASON_LOOKUP);
            LookupValue_Id lookupValueId = new LookupValue_Id(lookupFieldId.getEntity(), returnReason);
            if(isNull(lookupValueId.getEntity())) {
                return Bool.FALSE;
            }
            return Bool.TRUE;
        }
        
        /**
         * Parse to two decimal places
         * @param amount
         * @return paidAmount
         */
        private BigDecimal parsePaidAmount(String amount) {
            BigDecimal paidAmount = BigDecimal.ZERO;

            paidAmount = BigDecimal.valueOf(Integer.parseInt(amount),2);
            return paidAmount;
        }
        
        /**
         * Create Notification Upload Staging record
         * @return returnValue
         */
        private NotificationUpload createNTUpload() {
            
            NotificationUpload returnValue = null;
            NotificationUpload_DTO ntUpDTO = createDTO(NotificationUpload.class);
            ntUpDTO.setCreationDateTime(this.getProcessDateTime());
            ntUpDTO.setNotificationExternalId(externalId.getId());
            ntUpDTO.setNotificationUploadTypeId(notificationType.getId());
            ntUpDTO.setNotificationStatus(NotificationUploadStatusLookup.constants.PENDING);
            ntUpDTO.setNotificationUploadExtension(NotificationUploadExtensionLookup.constants.NO_EXTENSION);
            returnValue = ntUpDTO.newEntity();
            return returnValue;            
            
        }
        
        /**
         * Create Notification Upload Context Staging record
         * @return returnValue
         */
        private void createNTUploadContext(NotificationUpload ntUpload, NotificationUploadContextLookup notificationContextType, 
                String contextValue) {
            
            if (notBlank(contextValue)) {
                NotificationUploadContext_Id ntUpCtxtID = new NotificationUploadContext_Id(
                        ntUpload, notificationContextType, contextValue);
                NotificationUploadContext_DTO ntUpCtxtDTO = new NotificationUploadContext_DTO();
                ntUpCtxtDTO.setId(ntUpCtxtID);
                ntUpCtxtDTO.newEntity();        
            }    
        }
        
        /**
          * Perform final processing before ending the thread.
          * 
          * @throws ThreadAbortedException 
          * @throws RunAbortedException
          */
         public void finalizeThreadWork() 
         throws ThreadAbortedException, RunAbortedException {

            // Start Change - NMendo - CCB030.Issue1 -  2021-06-01
            //try {
            // if(notNull(uploadFileReader)){
            //     uploadFileReader.close();                    
            // }
            //} catch (IOException exception) {
            // throw new RunAbortedException(CustomMessageRepositorySpireOne.ccb030_2_errorClosingFile(fileNamePath));
            //}
            closeFile();
            // End Change - NMendo - CCB030.Issue1 -  2021-06-01
         }
         
         // Start Add - NMendo - CCB030.Issue1 -  2021-06-01
         /**
          * Open the File
          */
         private void openFile() {
             try {
                 uploadFile = new File(filePath,fileName);   
                 uploadFileReader = new BufferedReader(new FileReader(uploadFile)); 
             } catch(Exception e) {
                 e.printStackTrace();
                 throw new RunAbortedException(CustomMessageRepositorySpireOne.ccb030_2_errorOpeningFile(e.getLocalizedMessage()));
             }
         }
         
         /**
          * Close the File
          */
         private void closeFile() {
             try {
                 if(notNull(uploadFileReader)){
                     uploadFileReader.close();                    
                 }
             } catch (IOException exception) {
                 throw new RunAbortedException(CustomMessageRepositorySpireOne.ccb030_2_errorClosingFile(fileNamePath));
             }
         }
         
         /**
          * Check if the file has already been processed.
          */
         private void checkIfFileAlreadyProcessed() {
             // Open File
             openFile();
             
             // Get File Date
             String fileDate = "";
             String fileRecord = null;
             while(notNull(fileRecord = readFileRecord())) {
                totalItems++;
                 String recordType = readParsedRecord(fileRecord, 0, 3);
                if(recordType.equals(REC_TYPE_TOT)) {
                    fileDate = readParsedRecord(fileRecord, START_INDEX_DATE, END_INDEX_DATE);
                    if(isValidDate(fileDate).isFalse()) {
                        throw new RunAbortedException(CustomMessageRepositorySpireOne.ccb030_2_invalidRecordValueForColumn(DATE_COLUMN_NAME, 
                                fileDate, totalItems.toString(), fileNamePath));
                    }
                }
             }
             totalItems = 0;
             
             // Close File
             closeFile();
             
             // Check if there are records in the staging table matching the External ID, Notification Type, and File Date
             StringBuilder sb = new StringBuilder();
             sb.append("SELECT 'X' ");
             sb.append("FROM CI_NT_UP ");
             sb.append("WHERE NT_XID_CD = :externalId ");
             sb.append("AND NT_UP_XTYPE_CD = :notificationType ");
             sb.append("AND TO_CHAR(CRE_DTTM, 'YYYYMMDD') = :fileDate ");
             
             PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
             ps.bindId("externalId", externalId.getId());
             ps.bindId("notificationType", notificationType.getId());
             ps.bindString("fileDate", fileDate, getClass().getName());
             
             if(notNull(ps.firstRow())) {
                 throw new RunAbortedException(CustomMessageRepositorySpireOne.ccb030_fileAlreadyProcessed(uploadFile.getAbsolutePath(), 
                         externalId.getId().getTrimmedValue(), notificationType.getId().getTrimmedValue(), fileDate));
             }
         }
         // End Add - NMendo - CCB030.Issue1 -  2021-06-01
        
    }
}
