/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Process Reject File 
 * 
 * This batch process will read the information from the input file and 
 * will create customer contacts. The file contains both eligible as well 
 * as ineligible accounts. Only records whose Accepted Flag from the file 
 * = 'N' will be processed by this interface.
 *            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-04-18   JPunza  NI0026.9 Initial Version.
 * 2016-01-29  	MPang	Updated for CCB v2.4 compilation. 
 *************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.customerContactClass.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.CharacteristicTypeContactType;
import com.splwg.ccb.domain.admin.customerContactType.CustomerContactType_Id;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.Person;*/
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CharacteristicTypeContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.shared.common.ServerMessage;

/**
 * @author jpunzalan2
 *
 @BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = INPUT_FILE_PATH, type = string)
 *            , @BatchJobSoftParameter (name = INPUT_FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = DELIMITER, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = FILE_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = ACCT_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = REJECTION_REASON_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CUST_CONTACT_CLASS, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CUST_CONTACT_TYPE, required = true, type = string)})
 */
public class CmProcessRejectFileBatch extends CmProcessRejectFileBatch_Gen {

	// Constant Variables
	private final String INPUT_FILE_PATH = "INPUT_FILE_PATH";
	private final String FILE_ID_CHAR_TYPE = "FILE_ID_CHAR_TYPE";
	private final String ACCT_ID_CHAR_TYPE = "ACCT_ID_CHAR_TYPE";
	private final String REJECTION_REASON_CHAR_TYPE = "REJECTION_REASON_CHAR_TYPE";
	private final String CUST_CONTACT_TYPE = "CUST_CONTACT_TYPE";

	public JobWork getJobWork() {

		List<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
		arrayList.add(threadWorkUnit);
		return createJobWorkForThreadWorkUnitList(arrayList);
	}

	public void validateSoftParameters(boolean arg0) {

		// File Path
		String filePath = getParameters().getINPUT_FILE_PATH();        
		if (notBlank(filePath) && validateFilePath(filePath).isFalse()) {
			addError(CustomMessageRepositoryMDC.NI0026_9_filePathInvalid(INPUT_FILE_PATH, filePath));            
		}

		// File Id Characteristic Type
		CharacteristicType charType = getParameters().getFILE_ID_CHAR_TYPE();
		if (validateCharacteristicEntity(charType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT).isFalse()) {
			addError(CustomMessageRepositoryMDC.NI0026_9_charTypeInvalidForEntity(
					FILE_ID_CHAR_TYPE,
					charType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.CUSTOMER_CONTACT.getLookupValue().fetchLanguageDescription()));
		}

		// Account Id Characteristic Type
		charType = getParameters().getACCT_ID_CHAR_TYPE();
		if (validateCharacteristicEntity(charType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT).isFalse()) {
			addError(CustomMessageRepositoryMDC.NI0026_9_charTypeInvalidForEntity(
					ACCT_ID_CHAR_TYPE,
					charType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.CUSTOMER_CONTACT.getLookupValue().fetchLanguageDescription()));
		}

		// Rejection Reason Characteristic Type
		charType = getParameters().getREJECTION_REASON_CHAR_TYPE();
		if (validateCharacteristicEntity(charType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT).isFalse()) {
			addError(CustomMessageRepositoryMDC.NI0026_9_charTypeInvalidForEntity(
					REJECTION_REASON_CHAR_TYPE,
					charType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.CUSTOMER_CONTACT.getLookupValue().fetchLanguageDescription()));
		}

		CustomerContactClass customerContactClass = getParameters().getCUST_CONTACT_CLASS();

		// Customer Contact Type
		String customerContactType = getParameters().getCUST_CONTACT_TYPE();
		if (validateCustomerContactType(customerContactClass, customerContactType).isFalse()) {
			addError(CustomMessageRepositoryMDC.NI0026_9_ccTypeInvalidForCcClass(
					CUST_CONTACT_TYPE,
					customerContactType, 
					customerContactClass.getId().getTrimmedValue()));
		}
	}

	/**
	 * This method validates file path.
	 * @param filePath - String
	 * @return Bool
	 */
	private Bool validateFilePath(String filePath) {

		File folder = new File(filePath);
		if (folder.exists()) {
			return Bool.TRUE;
		}
		return Bool.FALSE;
	}

	/**
	 * This method validates if a characteristic type is valid for a specific characteristic entity.
	 * @param charType - Characteristic Type
	 * @param charEntityLookup - Characteristic Entity Lookup
	 * @return Bool
	 */
	private Bool validateCharacteristicEntity(CharacteristicType charType, CharacteristicEntityLookup charEntityLookup) {

		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType.getId(), charEntityLookup);        
		if (isNull(charEntityId.getEntity())) {
			return Bool.FALSE;
		}

		return Bool.TRUE;
	}

	/**
	 * This method validates Customer Contact Type.
	 * @param customerContactClass - Customer Contact Class
	 * @param customerContactType - String
	 * @return Bool
	 */
	private Bool validateCustomerContactType(CustomerContactClass customerContactClass, String customerContactType) {

		CustomerContactType_Id customerContactTypeId = new CustomerContactType_Id(customerContactClass, customerContactType);
		if (isNull(customerContactTypeId.getEntity())) { 
			return Bool.FALSE;
		}

		return Bool.TRUE;
	}

	public Class<CmProcessRejectFileBatchWorker> getThreadWorkerClass() {
		return CmProcessRejectFileBatchWorker.class;
	}

	public static class CmProcessRejectFileBatchWorker 
	extends CmProcessRejectFileBatchWorker_Gen {

		// Constant Variables               
		private final int FILE_ID = 0;
		private final int ACCT_ID = 1;
		private final int ACCEPT_FLG = 2;
		private final int REJ_REASON_CD = 3;
		private final String NO = "N";

		// Soft Parameters
		private String filePath;
		private String fileName;
		private String delimiter;
		private CharacteristicType fileIdCharType;
		private CharacteristicType acctIdCharType;
		private CharacteristicType rejReasonCharType;
		private CustomerContactType_Id ccTypeId;

		// Working Variables
		private BigInteger maxErrors;
		private int processedRecord;
		private int recordInError;

		private String fileId;
		private String accountIdStr;
		private String acceptedFlag;
		private String rejReasonCode; 

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		@Override
		public void initializeThreadWork(boolean arg0) 
		throws ThreadAbortedException, RunAbortedException {

			// Soft Parameters
			ThreadParameters parameters = getParameters();

			filePath = parameters.getINPUT_FILE_PATH();
			fileName = parameters.getINPUT_FILE_NAME();
			delimiter = parameters.getDELIMITER();

			fileIdCharType = parameters.getFILE_ID_CHAR_TYPE();
			acctIdCharType = parameters.getACCT_ID_CHAR_TYPE();
			rejReasonCharType = parameters.getREJECTION_REASON_CHAR_TYPE();

			ccTypeId = new CustomerContactType_Id(parameters.getCUST_CONTACT_CLASS(), parameters.getCUST_CONTACT_TYPE());

			// Counters
			processedRecord = 0;
			recordInError = 0;
		}

		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
		throws ThreadAbortedException, RunAbortedException {

			maxErrors = getParameters().getSoftMaxErrors();

			// Open file
			File file = new File(filePath, fileName);            
			BufferedReader bufferedReader = null;            
			try {
				bufferedReader = new BufferedReader(new FileReader(file));
			} catch (FileNotFoundException fe) {
				addError(CustomMessageRepositoryMDC.NI0026_9_errorWhileAccessingFile(fe.getMessage()));
			}

			try {
				while (bufferedReader.ready()) {
					String record = bufferedReader.readLine();

					// Split the record into fields
					processedRecord++;
					String[] elements = record.split(delimiter);

					if (elements.length != 4) {
						if (logErrorMessage(CustomMessageRepositoryMDC.NI0026_9_incorrectNumOfFields(processedRecord)).isTrue()) {
							break;
						}
						continue;
					}

					// Retrieve fields
					fileId = elements[FILE_ID];
					accountIdStr = elements[ACCT_ID];
					acceptedFlag = elements[ACCEPT_FLG];
					rejReasonCode = elements[REJ_REASON_CD];

					if (acceptedFlag.trim().equalsIgnoreCase(NO)) {

						// Validate Account
						Account_Id accountId = new Account_Id(accountIdStr);
						Account account = accountId.getEntity();                    
						if (isNull(account)) {
							if (logErrorMessage(CustomMessageRepositoryMDC.NI0026_9_invalidAccountId(processedRecord, accountIdStr)).isTrue()) {
								break;
							}
							continue;
						}

						// Validate Reject Reason Code
						if (rejReasonCharType.getCharacteristicType().isPredefinedValue() 
								&& validateCharTypeAndCharValue(rejReasonCharType, rejReasonCode).isFalse()) {
							if (logErrorMessage(CustomMessageRepositoryMDC.NI0026_9_invalidRejReasonCode(processedRecord, rejReasonCode)).isTrue()) {
								break;
							}
							continue;
						}



						// Get Main Customer
						//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
						//ListFilter<AccountPerson> mainCustomer = account.getPersons().createFilter("where this.isMainCustomer = :yes");
						ListFilter<AccountPerson> mainCustomer = account.getPersons().createFilter(
								"where this.isMainCustomer = :yes", getClass().getName());
						//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
						mainCustomer.bindBoolean("yes", Bool.TRUE);

						// Create Customer Contact
						createCustomerContact(mainCustomer.firstRow().fetchIdPerson());
					}

				}
				bufferedReader.close();
			} catch (IOException ioe) {
				addError(CustomMessageRepositoryMDC.NI0026_9_errorWhileAccessingFile(ioe.getMessage()));
			}


			WorkUnitResult results = new WorkUnitResult(true);
			results.setUnitsInError(recordInError);
			results.setUnitsProcessed(processedRecord);
			return results;
		}

		/**
		 * This method validates if characteristic value is valid for a given characteristic type. 
		 * @param charType - Characteristic Type
		 * @param charValue - String
		 * @return Bool
		 */
		private Bool validateCharTypeAndCharValue(CharacteristicType charType, String charValue) {

			CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charType, charValue);
			if (isNull(charValueId.getEntity())) {
				return Bool.FALSE;
			}

			return Bool.TRUE;
		}

		/**
		 * This method creates Customer Contact.
		 * @param person - Person
		 */
		private void createCustomerContact(Person person) {

			if (checkForExistingCustomerContact(person).isTrue()) {
				return;
			}

			// Create Customer Contact
			CustomerContact_DTO ccDTO = (CustomerContact_DTO) createDTO(CustomerContact.class);

			ccDTO.setContactDateTime(getProcessDateTime());
			ccDTO.setCustomerContactTypeId(ccTypeId);
			ccDTO.setPersonId(person.getId());
			ccDTO.setShouldPrintLetter(Bool.FALSE);

			CustomerContact customerContact = ccDTO.newEntity();

			// Set characteristics for Customer Contact    
			for (Iterator<CharacteristicTypeContactType> iter = ccTypeId.getEntity().getCharacteristicTypeContactTypes().iterator(); iter.hasNext();) {

				CharacteristicTypeContactType ccTypeCharType = (CharacteristicTypeContactType) iter.next();
				CharacteristicType charType = ccTypeCharType.getId().getCharacteristicType();

				if (charType.equals(fileIdCharType)) {                
					createCustomerContactCharacteristic(customerContact, fileIdCharType, fileId);
				}
				else if (charType.equals(acctIdCharType)) {                
					createCustomerContactCharacteristic(customerContact, acctIdCharType, accountIdStr);
				}
				else if (charType.equals(rejReasonCharType)) {                
					createCustomerContactCharacteristic(customerContact, rejReasonCharType, rejReasonCode);
				}
			}                       
		}

		/**
		 * This method checks for existing Customer Contact.
		 * @param person - Person
		 * @return Bool
		 */
		private Bool checkForExistingCustomerContact(Person person) {

			PreparedStatement getCustomerContact = createPreparedStatement("SELECT CC.CC_ID " +
					"FROM CI_CC CC " +
					"WHERE CC.PER_ID = :person " +
					"AND EXISTS (SELECT 'X' FROM CI_CC_CHAR CCC1 " +
					"   WHERE CCC1.CC_ID = CC.CC_ID " +
					"   AND CCC1.CHAR_TYPE_CD = :charType1 " +
					"   AND (TRIM(CCC1.CHAR_VAL) = TRIM(:charValue1) " +
					"   OR TRIM(CCC1.ADHOC_CHAR_VAL) = TRIM(:adhocCharValue1) " +
					"   OR TRIM(CCC1.CHAR_VAL_FK1) = TRIM(:charValueFk1))) " +
					"AND EXISTS (SELECT 'X' FROM CI_CC_CHAR CCC2 " +
					"   WHERE CCC2.CC_ID = CC.CC_ID " +
					"   AND CCC2.CHAR_TYPE_CD = :charType2 " +
					"   AND (TRIM(CCC2.CHAR_VAL) = TRIM(:charValue2) " +
					"   OR TRIM(CCC2.ADHOC_CHAR_VAL) = TRIM(:adhocCharValue2) " +
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation		
			//"   OR TRIM(CCC2.CHAR_VAL_FK1) = TRIM(:charValueFk2)))");
			"   OR TRIM(CCC2.CHAR_VAL_FK1) = TRIM(:charValueFk2)))", getClass().getName());
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation

			getCustomerContact.bindEntity("person", person);
			getCustomerContact.bindEntity("charType1", fileIdCharType);
			getCustomerContact.bindStringProperty("charValue1", CustomerContactCharacteristic.properties.characteristicValue, fileId);
			getCustomerContact.bindStringProperty("adhocCharValue1", CustomerContactCharacteristic.properties.adhocCharacteristicValue, fileId);
			getCustomerContact.bindStringProperty("charValueFk1", CustomerContactCharacteristic.properties.characteristicValueForeignKey1, fileId);
			getCustomerContact.bindEntity("charType2", acctIdCharType);
			getCustomerContact.bindStringProperty("charValue2", CustomerContactCharacteristic.properties.characteristicValue, accountIdStr);
			getCustomerContact.bindStringProperty("adhocCharValue2", CustomerContactCharacteristic.properties.adhocCharacteristicValue, accountIdStr);
			getCustomerContact.bindStringProperty("charValueFk2", CustomerContactCharacteristic.properties.characteristicValueForeignKey1, accountIdStr);

			if (notNull(getCustomerContact.firstRow())) {
				return Bool.TRUE;
			}

			return Bool.FALSE; 
		}

		/**
		 * This method creates Customer Contact Characteristic.
		 * @param customerContact - Customer Contact
		 * @param charType - Characteristic Type 
		 * @param charValue - String
		 */
		private void createCustomerContactCharacteristic(CustomerContact customerContact, CharacteristicType charType, String charValue) {

			CustomerContactCharacteristic_DTO ccCharDto = (CustomerContactCharacteristic_DTO) createDTO(CustomerContactCharacteristic.class);
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

			if (charTypeLookup.isPredefinedValue()) {
				ccCharDto.setCharacteristicValue(charValue);
			}
			else if (charTypeLookup.isForeignKeyValue()) {
				ccCharDto.setCharacteristicValueForeignKey1(charValue);
			}
			else {
				ccCharDto.setAdhocCharacteristicValue(charValue);
			}

			ccCharDto.setId(new CustomerContactCharacteristic_Id(charType, customerContact));
			ccCharDto.newEntity();
		}

		/**
		 * This method logs message and checks if the max error has been reached.
		 * @param message - ServerMessage
		 */
		private Bool logErrorMessage(ServerMessage message) {

			logError(message);
			recordInError++;

			if (notNull(maxErrors) && recordInError == maxErrors.intValue()) {
				logError(CustomMessageRepositoryMDC.NI0026_9_maxErrorReached(maxErrors));
				return Bool.TRUE;
			}

			return Bool.FALSE;
		}
	}
}
