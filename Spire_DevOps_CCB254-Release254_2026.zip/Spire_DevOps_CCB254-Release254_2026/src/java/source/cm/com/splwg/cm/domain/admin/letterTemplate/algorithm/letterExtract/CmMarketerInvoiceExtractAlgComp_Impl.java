/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm extracts the required information for the Marketer Invoice
 * Letter.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      MGE-CCB011. Initial Version. 
 * 2016-05-23   MPang       Defect 3439849. Added close connection to avoid
 *                          UniversalPoolConnectionException.
 * 2018-06-07   SFelip      CCB v2.6 Upgrade. 
 * 2019-12-19   JVitug      SA-315895. Updated to now process
 *                          letter extract instead of calling the custom
 *                          COBOL     
 * 2020-02-03   JVitug      SA-315895 Issue 1. Corrected the value being
 * 							retrieved for the Account Entity name
 * 							and the Bill Routing mailing entity name  
 * 2020-04-14	JHERNA		331145.	Handle scenario when Bill is already canceled
 * 							which means, the service date cannot be retrieved
 * 							and causes a null pointer exception.
 * 							This is something that is already handled by the
 * 							original cobol version of this program but was 
 * 							missed when this was converted to java.                                                               
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.letterTemplate.algorithm.letterExtract;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchRun.BatchRun;
import com.splwg.base.domain.common.algorithm.Algorithm;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.report.reportDefinition.ReportDefinition;
import com.splwg.ccb.domain.admin.billRouteType.entity.BillRouteType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.letterTemplate.algorithm.letterExtract.LetterTemplateLetterExtractAlgorithmSpot;
import com.splwg.ccb.domain.admin.letterTemplate.entity.LetterTemplate;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillRouting;
import com.splwg.ccb.domain.billing.bill.entity.BillRoutings;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.common.currency.entity.Currency;
import com.splwg.ccb.domain.common.fileHelper.FileHelper;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.cm.api.batch.CmEndOfLetterExtractRecord;
import com.splwg.cm.api.batch.CmInvoiceLineRecord;
import com.splwg.cm.api.batch.CmInvoiceRecord;
import com.splwg.cm.api.batch.CmLetterExtractRecord;
import com.splwg.cm.api.batch.CmMailingInformationExtractRecord;
import com.splwg.cm.domain.common.customBusinessComponent.CmAccountCheckDigitRetriever;
import com.splwg.cm.domain.constants.CustomConstantsRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = billRouteType, name = billRouteType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = billLinePriorityCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = taxCommunityCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = remitToCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = defaultRemitToCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = latePaymentCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = townCodeCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = billIDCustomerContactCharType, required = true, type = entity)})
 */
public class CmMarketerInvoiceExtractAlgComp_Impl extends
        CmMarketerInvoiceExtractAlgComp_Gen implements
        LetterTemplateLetterExtractAlgorithmSpot {

    // hard parameters
    private BigInteger customerContactExtractedCount;
    private ReportDefinition reportDefinition;
    private BatchRun batchRun;
    private CustomerContact customerContact;
    private String extractFileName;
    private FileHelper fileHelper;
    private Bool isFieldDelimited;
    private Bool isFirstHeaderDelimited;
    private Algorithm letterExtractAlgorithm;
    private LetterTemplate letterTemplate;
    private CustomerContact toCustomerContact;
    
    // soft parameters
    private BillRouteType billRouteType;
    private CharacteristicType billLinePriorityCharType;
    private CharacteristicType taxCommunityCharType;
    private CharacteristicType remitToCharType;
    private String defaultRemitToCharValue;
    private CharacteristicType latePaymentCharType;
    private CharacteristicType townCodeCharType;
    private CharacteristicType billIDCustomerContactCharType;
    
    //Start Delete - JVitug - SA-315895 - 2019-12-19
    //private Cmpcxmix cmpcxmix;
    //End Delete - JVitug - SA-315895 - 2019-12-19
    
    //Start Delete - JVitug - SA-315895 - 2019-12-27
    //Start Add - MPang - Defect 3439849 - 2016-05-23
    //private Connection connection;
    //End Add - MPang - Defect 3439849 - 2016-05-23
   //End Delete - JVitug - SA-315895 - 2019-12-27
    
    //Start Add - JVitug - SA-315895 - 2019-12-19
    // Work variables
    private BufferedWriter bufferedWriter;
    File extractFile;
    private Bill bill;
    Date serviceDate;
    Date scheduledExtractDate;
    BigDecimal currentBalance = BigDecimal.ZERO;
    BigDecimal currentChargeAmount = BigDecimal.ZERO;
    BigDecimal currentCorrectionAmount = BigDecimal.ZERO;
    BigDecimal currentAdjustmentAmount = BigDecimal.ZERO;
    BigDecimal currentPayAmount = BigDecimal.ZERO;
    BigDecimal currentPreviousBalance = BigDecimal.ZERO;
    BigDecimal totalBalance = BigDecimal.ZERO;
    BigDecimal totalChargeAmount = BigDecimal.ZERO;
    BigDecimal totalCorrectionAmount = BigDecimal.ZERO;
    BigDecimal totalAdjustmentAmount = BigDecimal.ZERO;
    BigDecimal totalPayAmount = BigDecimal.ZERO;
    BigDecimal totalPreviousBalance = BigDecimal.ZERO;
    BigDecimal delinquentAmount = BigDecimal.ZERO;
    BigDecimal totalLatePaymentCharge = BigDecimal.ZERO;
    BigDecimal calcAmount = BigDecimal.ZERO;
    BigDecimal exemptAmount = BigDecimal.ZERO;
    BigDecimal billSq = BigDecimal.ZERO;
    BigDecimal installMinimumBillPrtAmt;
    UnitOfMeasure unitOfMeasure;
    TimeOfUse timeOfUse;
    ServiceQuantityIdentifier sqi;
    Currency currency;
    Currency installationCurrency;
    Bool finalBillSwitch;
    Bool skipBillSwitch;
    List<SQLResultRow> invoiceLineDetails = null;
    String remitToFlag;
    String appInSummarySw;
    String descriptionOnBill;
    String checkDigit;
    
    // Address Information
    private String addressLine1;
    private String addressLine2;
    private String addressLine3;
    private String addressLine4;
    private String houseType;
    private String city;
    private String state;
    private String postal;
    private String geoCode;
    private String county;
    private String country;
    private String num1;
    private String num2;
    private String inCityLimit;
    private String custPOId;
    private String accountEntityName;
    private String entityNameFromBillRouting;
    private String entityName1;
    private String entityName2;
    private String entityName3;
    //End Add - JVitug - SA-315895 - 2019-12-19
    
    
    // CONSTANTS
    //Start Delete - JVitug - SA-315895 - 2019-12-19
//  private static final String CONNECTION_ONLINE = "O";
//  private static final String CONNECTION_BATCH = "B";
    //End Delete - JVitug - SA-315895 - 2019-12-19
    private static final String SWITCH_YES = "Y";
    private static final String SWITCH_NO = "N";
    
    
    @Override
    public BigInteger getCustomerContactExtractedCount() {
        return customerContactExtractedCount;
    }

    @Override
    public ReportDefinition getReportDefinition() {
        return reportDefinition;
    }

    @Override
    public void setBatchRun(BatchRun arg0) {
        batchRun = arg0;
    }

    @Override
    public void setCustomerContact(CustomerContact arg0) {
        customerContact = arg0;
    }

    @Override
    public void setCustomerContactExtractedCount(BigInteger arg0) {
        customerContactExtractedCount = arg0;
    }

    @Override
    public void setExtractFileName(String arg0) {
        extractFileName = arg0;
    }

    @Override
    public void setFileHelper(FileHelper arg0) {
        fileHelper = arg0;
    }

    @Override
    public void setIsFieldDelimited(Bool arg0) {
        isFieldDelimited = arg0;
    }

    @Override
    public void setIsFirstHeaderDelimited(Bool arg0) {
        isFirstHeaderDelimited = arg0;
    }

    @Override
    public void setLetterExtractAlgorithm(Algorithm arg0) {
        letterExtractAlgorithm = arg0;
    }

    @Override
    public void setLetterTemplate(LetterTemplate arg0) {
        letterTemplate = arg0;
    }

    @Override
    public void setToCustomerContact(CustomerContact arg0) {
        toCustomerContact = arg0;
    }
    
    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        
        billRouteType = getBillRouteType();
        billLinePriorityCharType = getBillLinePriorityCharType();
        taxCommunityCharType = getTaxCommunityCharType();
        remitToCharType = getRemitToCharType();
        defaultRemitToCharValue =  getDefaultRemitToCharValue();
        latePaymentCharType = getLatePaymentCharType();
        townCodeCharType = getTownCodeCharType();
        billIDCustomerContactCharType = getBillIDCustomerContactCharType();
    }

    @Override
    public void invoke() {
        //Start Change - JVitug - SA-315895
        openExtractFile();
        if(isFieldDelimited.isTrue() && isFirstHeaderDelimited.isTrue()){
            writeDelimitedHeaders();
        }
        getMinimumBillAmountFromInstallationRecord();
        List<SQLResultRow> billsFromCCChar = retrieveBillFromCustomerContactChar(customerContact);

        //Initialize the skipBillSwitch
        skipBillSwitch = Bool.FALSE;
        
        for(SQLResultRow billFromCCChar : billsFromCCChar){
            printMarketerInvoiceLetterLetterExtract(billFromCCChar);
        }
        closeExtractFile();
//      try { 
//          initializeCobolProgram();
//          
//          // set cobol program's hard parameters
//          if(notNull(customerContact)) {
//              cmpcxmix.setInputWrkCcId(customerContact.getId().getTrimmedValue());
//          }else{
//              cmpcxmix.setInputWrkCcId(CobolCode.SPACES.toString());
//          }
//          if(notNull(batchRun)) {
//              cmpcxmix.setInputWrkBatchCd(batchRun.fetchIdBatchControl().getId().getTrimmedValue());
//              cmpcxmix.setInputWrkBatchNbr(java.math.BigDecimal.valueOf(batchRun.fetchIdBatchNumber().doubleValue()));
//          }else{
//              cmpcxmix.setInputWrkBatchCd(CobolCode.SPACES.toString());
//              cmpcxmix.setInputWrkBatchNbr(java.math.BigDecimal.ZERO);
//          }
//          if(notNull(letterTemplate)) {
//              cmpcxmix.setInputWrkLtrTmplCd(letterTemplate.getId().getTrimmedValue());
//          }else{
//              cmpcxmix.setInputWrkLtrTmplCd(CobolCode.SPACES.toString());
//          }
//          if (notNull(letterExtractAlgorithm)) {
//              cmpcxmix.setInputWrkExtractAlgCd(letterExtractAlgorithm.getId().getTrimmedValue());
//          }else{
//              cmpcxmix.setInputWrkExtractAlgCd(CobolCode.SPACES.toString());
//          }
//          if(notBlank(extractFileName)) {
//              cmpcxmix.setExtractFileName(extractFileName.trim());
//          }else{
//              cmpcxmix.setExtractFileName(CobolCode.SPACES.toString());
//          }
//          
//          if(notNull(isFieldDelimited)) {
//              String isFieldDelimitedSw = (isFieldDelimited.isTrue()) ? SWITCH_YES : SWITCH_NO;
//              cmpcxmix.setFieldDelimSw(isFieldDelimitedSw);
//          }else{
//              cmpcxmix.setFieldDelimSw(CobolCode.SPACES.toString());
//          }
//          if(notNull(isFirstHeaderDelimited)) {
//              String isFirstHeaderDelimitedSw = (isFirstHeaderDelimited.isTrue()) ? SWITCH_YES : SWITCH_NO;
//              cmpcxmix.setDelim_1stHeaderSw(isFirstHeaderDelimitedSw);
//          }else{
//              cmpcxmix.setDelim_1stHeaderSw(CobolCode.SPACES.toString());
//          }
//          if(notNull(toCustomerContact)) {
//              cmpcxmix.setToCcId(toCustomerContact.getId().getTrimmedValue());
//          }else{
//              cmpcxmix.setToCcId(CobolCode.SPACES.toString());
//          }
//          if (notNull(customerContactExtractedCount)) {
//              cmpcxmix.setCcExtractedCnt(java.math.BigDecimal.valueOf(customerContactExtractedCount.doubleValue()));
//          }else{
//              cmpcxmix.setCcExtractedCnt(java.math.BigDecimal.ZERO);
//          }
//          
//          // soft parameters
//          cmpcxmix.setAlgParmVal(1, billRouteType.getId().getTrimmedValue()); 
//          cmpcxmix.setAlgParmVal(2, billLinePriorityCharType.getId().getTrimmedValue()); 
//          cmpcxmix.setAlgParmVal(3, taxCommunityCharType.getId().getTrimmedValue());
//          cmpcxmix.setAlgParmVal(4, remitToCharType.getId().getTrimmedValue()); 
//          cmpcxmix.setAlgParmVal(5, defaultRemitToCharValue.trim()); 
//          cmpcxmix.setAlgParmVal(6, latePaymentCharType.getId().getTrimmedValue()); 
//          cmpcxmix.setAlgParmVal(7, townCodeCharType.getId().getTrimmedValue()); 
//          cmpcxmix.setAlgParmVal(8, billIDCustomerContactCharType.getId().getTrimmedValue()); 
//          
//          // invoke the main method
//          cmpcxmix.cobolMain(); 
//      } 
//      catch(Exception _ex) {
//          Throwable ex=_ex;
//          
//          //Start Delete - MPang - Defect 3439849 - 2016-05-23
//          //ex.printStackTrace();
//          //End Delete - MPang - Defect 3439849 - 2016-05-23
//          while(ex.getCause()!=null) ex=ex.getCause();
//          
//          if(ex instanceof Stop) {
//              if (cmpcxmix.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
//                      && cmpcxmix.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
//                  
//                  MessageParameters messageparameters = new MessageParameters();
//                  for (int i = 1; i <= 9; i++) {
//                      try {
//                          String parmValue = cmpcxmix.getMessageParm(i);
//                          if (notBlank(cmpcxmix.getMessageParm(i))) {
//                              messageparameters.addRawString(parmValue.trim());
//                          }
//                      }
//                      catch(IndexOutOfBounds e) {
//                          break;
//                      }
//                      
//                  }
//                  
//                  MessageCategory_Id categoryId = new MessageCategory_Id(cmpcxmix.getZmsgnMessageCatNbr().toBigInteger());
//                  ServerMessage serverMessage = 
//                          ServerMessageFactory.Factory.newInstance().createMessage(
//                                  categoryId, cmpcxmix.getMessageNbr().intValue(), messageparameters);
//                  
//                  // info
//                  if (cmpcxmix.getMessageSeverity().compareTo(
//                          MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
//                      logInfo(serverMessage);
//                  }
//                  // warning
//                  else if (cmpcxmix.getMessageSeverity().compareTo(
//                          MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
//                      addWarning(serverMessage);
//                  }
//                  // error
//                  else {
//                      addError(serverMessage);
//                  }
//                  
//              }
//              
//              customerContactExtractedCount = cmpcxmix.getCcExtractedCnt().toBigInteger();
//              reportDefinition = new ReportDefinition_Id(cmpcxmix.getReportCd().trim()).getEntity();
//              
//          }
//          else {
//              //Start Add - MPang - Defect 3439849 - 2016-05-23
//              ex.printStackTrace();
//              //End Add - MPang - Defect 3439849 - 2016-05-23
//              if (ex instanceof ApplicationError) {
//                  addError(((ApplicationError)ex).getServerMessage());
//              }
//              else {
//                  addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
//              }
//          }
//      }
//      finally {
//          cmpcxmix=Session.returnSessionAndCodeToCache(cmpcxmix);
//          //Start Add - MPang - Defect 3439849 - 2016-05-23
//            try {
//                connection.close();
//            } catch (SQLException e) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
//            }
//            //End Add - MPang - Defect 3439849 - 2016-05-23
//      }
        //End Change - JVitug - SA-315895
    }
    
    private void writeDelimitedHeaders(){
        StringBuilder delimitedHeader = new StringBuilder();
        delimitedHeader.append(CustomConstantsRepository.BILL_ID);
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.ACCOUNT_ID);
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.BILL_DATE );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.DUE_DATE);
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.SERVICE_DATE);
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.CURRENT_BALANCE);
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.CURRENT_CHARGE_AMOUNT);
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.CURRENT_CORRECTION_AMOUNT);
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.CURRENT_ADJUSTMENT_AMOUNT);
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.CURRENT_PAYMENT_AMOUNT);
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.CURRENT_PREVIOUS_BALANCE);
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.TOTAL_BALANCE);
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.TOTAL_CHARGE_AMOUNT);
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.TOTAL_CORRECTION_AMOUNT);
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.TOTAL_ADJUSTMENT_AMOUNT );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.TOTAL_PAYMENT_AMOUNT );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.TOTAL_PREVIOUS_BALANCE );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.CURRENCY );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.DELINQUENT_AMOUNT );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.CUSTOMERPOID );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.ACCOUNT_ENTITY_NAME );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.ENTITY_NAME );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.COUNTRY );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.ADDRESS1 );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.ADDRESS2 );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.ADDRESS3 );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.ADDRESS4 );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.CITY );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.NUM1 );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.NUM2 );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.HOUSETYPE );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.COUNTY );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.STATE );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.GEOCODE );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.IN_CITY_LIMIT );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.FINAL_BILL );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.APAY_SCHED_DATE );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.ENTITY_NAME_1 );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.ENTITY_NAME_2 );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.ENTITY_NAME_3 );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.ACCOUNT_CURRENCY );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.TOTAL_LATE_PAY_CHARGE );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.REMIT_TO );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.CHECK_DIGIT );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.APPEARS_IN_SUMMARY );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.CALCULATED_AMOUNT );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.EXEMPT_AMOUNT );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.UOM );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.TOU );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.SQI );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.BILL_SQ );
        delimitedHeader.append(CustomConstantsRepository.TILDE);
        delimitedHeader.append(CustomConstantsRepository.DESC_ON_BILL); 
        
        writeToExtractFile(delimitedHeader.toString());
    }
    
    private void getMinimumBillAmountFromInstallationRecord(){
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT MIN_BILL_PRT_AMT, CURRENCY_CD ");
        stringBuilder.append("FROM CI_INSTALLATION ");
        
        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getInstallation=");
        prepState.execute();
        prepState.setAutoclose(false);
        SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
        installMinimumBillPrtAmt = sqlRow.getBigDecimal("MIN_BILL_PRT_AMT");
        installationCurrency = sqlRow.getEntity("CURRENCY_CD", Currency.class);
        prepState.close();
    }
    
    //Start Add - JVitug - SA-315895
    private void printMarketerInvoiceLetterLetterExtract(SQLResultRow billFromCCChar){
        SQLResultRow billBalances = null;
        //get the address information either by the Primary Person linked to CC or via account of active SA
        bill = new Bill_Id(billFromCCChar.getString("BILL_ID")).getEntity();
        getAddressInformation();
        finalBillSwitch = checkIfBillIsFinalBill();
        billBalances = retrieveBillBalances();
        
        if(notNull(billBalances)){
            currentBalance = billBalances.getBigDecimal("CUR_AMT");
            totalBalance = billBalances.getBigDecimal("TOT_AMT");
            currency = bill.getAccount().getCurrency();
            if(currency.getId().compareTo(installationCurrency.getId()) == 0){
                if((totalBalance.compareTo(installMinimumBillPrtAmt) < 0 && currentBalance.
                        compareTo(installMinimumBillPrtAmt) < 0) && finalBillSwitch.isTrue()){
                    skipBillSwitch = Bool.TRUE;
                }
            }
        }
        
        if(skipBillSwitch.isTrue()){
            return;
        }
        else {
            //Prepare all the information needed for the invoice record
            prepareInvoiceInformation();
            //Write the Extract
            if(isFieldDelimited.isTrue()){
                writeDelimitedRecord();
            } else {
                writeLetterRecord(extractFileName);
                writeMailingInfoRecord(extractFileName);
                writeInvoiceRecord(extractFileName);
                writeInvoiceLineRecord(extractFileName);
                writeEndDetailRecord(extractFileName);
            }
        }
            
    }
    /**
     * Gets the address Information from the Bill Id characteristic
     */
    private void getAddressInformation() {
        //Get the address from the main person
        getAddressInformationFromBillRouting(bill);
    }
    
    private void prepareInvoiceInformation(){
        SQLResultRow billCurrentChargeAmounts = null;
        SQLResultRow billCorrectionAmounts = null;
        SQLResultRow billAdjustmentAmounts = null;
        SQLResultRow billPaymentAmounts = null;
        
        //Get Check Digit
        CmAccountCheckDigitRetriever acctCheckDigitRetriever = CmAccountCheckDigitRetriever.Factory.newInstance();
        acctCheckDigitRetriever.inputAccount(bill.getAccount().getId().getTrimmedValue());
        acctCheckDigitRetriever.execute();
        checkDigit = acctCheckDigitRetriever.getCheckDigit();
         
        //Get the entity name from the Main person of the account linked to the Bill
        //Start Change JVitug - SA 315895 - Issue 1 - 2020-02-03
        //accountEntityName = bill.getAccount().entityName();
        accountEntityName = bill.getAccount().getMainPerson().getPersonPrimaryName();
        //End Change JVitug - SA 315895 - Issue 1 - 2020-02-03
        currency = bill.getAccount().getCurrency();
                
        serviceDate = retrieveServiceDate();
        billCurrentChargeAmounts = retrieveBillCurrentChargeAmounts();
        billCorrectionAmounts = retrieveBillCorrectionAmounts();
        billAdjustmentAmounts = retrieveBillAdjustmentAmounts();
        billPaymentAmounts = retrieveBillPaymentAmounts();
        
        if(notNull(billCurrentChargeAmounts)){
            currentChargeAmount = billCurrentChargeAmounts.getBigDecimal("CUR_AMT");
            totalChargeAmount = billCurrentChargeAmounts.getBigDecimal("TOT_AMT");
        }else {
            currentChargeAmount = BigDecimal.ZERO;
            totalChargeAmount = BigDecimal.ZERO;
        }
        
        if(notNull(billCorrectionAmounts)){
            currentCorrectionAmount = billCorrectionAmounts.getBigDecimal("CUR_AMT");
            totalCorrectionAmount = billCorrectionAmounts.getBigDecimal("TOT_AMT");
        }else {
            currentCorrectionAmount = BigDecimal.ZERO;
            totalCorrectionAmount = BigDecimal.ZERO;
        }
        
        if(notNull(billAdjustmentAmounts)){
            currentAdjustmentAmount = billAdjustmentAmounts.getBigDecimal("CUR_AMT");
            totalAdjustmentAmount = billAdjustmentAmounts.getBigDecimal("TOT_AMT");
        }else {
            currentAdjustmentAmount = BigDecimal.ZERO;
            totalAdjustmentAmount = BigDecimal.ZERO;
        }
        
        if(notNull(billPaymentAmounts)){
            currentPayAmount = billPaymentAmounts.getBigDecimal("CUR_AMT");
            totalPayAmount = billPaymentAmounts.getBigDecimal("TOT_AMT");
        }else {
            currentPayAmount = BigDecimal.ZERO;
            totalPayAmount = BigDecimal.ZERO;
        }
        
        
        currentPreviousBalance = currentBalance.subtract(currentChargeAmount
                                    .add(currentAdjustmentAmount)
                                    .add(currentPayAmount)
                                    .add(currentCorrectionAmount));
        
        totalPreviousBalance = totalBalance.subtract(totalChargeAmount
                                    .add(totalAdjustmentAmount)
                                    .add(totalPayAmount)
                                    .add(totalCorrectionAmount));
        
        delinquentAmount = currentPreviousBalance.add(currentPayAmount);
        
        scheduledExtractDate = retrieveScheduledDate();
        
        totalLatePaymentCharge = retrieveTotalLatePaymentCharge();
        if(isNull(totalLatePaymentCharge)){
            totalLatePaymentCharge = BigDecimal.ZERO;
        }
        
        remitToFlag = retrieveRemitToCharVal();
        
        invoiceLineDetails = retrieveInvoiceLineDetails();
    }
    /**
     * Get the address information from the Bill Routing table of the Bill
     * @param bill
     */
    private void getAddressInformationFromBillRouting(Bill bill){
        BillRoutings billRoutings = bill.getRoutings();
        
        for(BillRouting billRoute : billRoutings){
            //Only get the address from the the bill route 
            //whose Bill Route Type is the same as the Bill Route soft Parameter
            if(billRoute.getBillRouteTypeId().getTrimmedValue()
                    .compareTo(billRouteType.getId().getTrimmedValue()) == 0){
                addressLine1 = billRoute.getAddress1().trim();
                addressLine2 = billRoute.getAddress2().trim();
                addressLine3 = billRoute.getAddress3().trim();
                addressLine4 = billRoute.getAddress4().trim();
                houseType = billRoute.getHouseType().trimmedValue();
                city = billRoute.getCity().trim();
                state = billRoute.getState().trim();
                postal = billRoute.getPostal().trim();
                county = billRoute.getCounty().trim();
                if(notNull(billRoute.getCountryId())){
                    country = billRoute.getCountryId().getTrimmedValue();
                }
                geoCode = billRoute.getTaxVendorGeographicalCode().trim();
                num1 = billRoute.getStreetNumber1().trim();
                num2 = billRoute.getStreetNumber2().trim();
                if(billRoute.getIsInCityLimit().isTrue()){
                    inCityLimit = SWITCH_YES;
                } else {
                    inCityLimit = SWITCH_NO;
                }
                custPOId = billRoute.getCustomerPOId().trim();
                //Start Change JVitug - SA 315895 Issue 1 - 2020-02-03
                //entityNameFromBillRouting = billRoute.entityName();
                entityNameFromBillRouting = billRoute.getPerson().getPersonPrimaryName();
                //End Change JVitug - SA 315895 Issue 1 - 2020-02-03
                entityName1 = billRoute.getEntityName1();
                entityName2 = billRoute.getEntityName2();
                entityName3 = billRoute.getEntityName3();
                
                //Break from the loop since we do not need to process the other
                //Bill routings
                break;
            }
        }
    }
    
    private void writeDelimitedRecord(){
        
        Iterator<SQLResultRow> iterator = invoiceLineDetails.iterator();
        
        //For every Calculation line , write it into an invoice Line Detail Record
        //In the extract file
        while(iterator.hasNext()){
            SQLResultRow invoiceLineDetail = iterator.next();
            appInSummarySw = invoiceLineDetail.getString("APP_IN_SUMM_SW");
            if(notNull(invoiceLineDetail.getBigDecimal("CALC_AMT"))){
                calcAmount = invoiceLineDetail.getBigDecimal("CALC_AMT");
            } else {
                calcAmount = BigDecimal.ZERO;
            }
            if(notNull(invoiceLineDetail.getBigDecimal("EXEMPT_AMT"))){
                exemptAmount = invoiceLineDetail.getBigDecimal("EXEMPT_AMT");
            } else {
                exemptAmount = BigDecimal.ZERO;
            }
            unitOfMeasure = new UnitOfMeasure_Id(invoiceLineDetail.getString("UOM_CD")).getEntity();
            timeOfUse = new TimeOfUse_Id(invoiceLineDetail.getString("TOU_CD")).getEntity();
            sqi = new ServiceQuantityIdentifier_Id(invoiceLineDetail.getString("SQI_CD")).getEntity();
            if(notNull(invoiceLineDetail.getBigDecimal("BILL_SQ"))) {
                billSq = invoiceLineDetail.getBigDecimal("BILL_SQ");
            } else {
                billSq = BigDecimal.ZERO;
            }
            descriptionOnBill = invoiceLineDetail.getString("DESCR_ON_BILL");
            
            writeLineRecord();
        }
    }
    
    private void writeLineRecord(){
        StringBuilder record = new StringBuilder();
        // START CHANGE - JHERNA - 2020-04-14 - SysAid#331145 
        String SERVICE_DATE = " ";
        if (notNull(serviceDate)) {
        	SERVICE_DATE = serviceDate.toString().trim();
        }
        record.append(bill.getId().getTrimmedValue());
        record.append(CustomConstantsRepository.TILDE);
        record.append(bill.getAccount().getId().getTrimmedValue());
        record.append(CustomConstantsRepository.TILDE);
        record.append(bill.getBillDate().toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(bill.getDueDate().toString());
        record.append(CustomConstantsRepository.TILDE);
//        record.append(serviceDate.toString());
        record.append(SERVICE_DATE);
        // END CHANGE - JHERNA - 2020-04-14 - SysAid#331145
        record.append(CustomConstantsRepository.TILDE);
        record.append(currentBalance.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(currentChargeAmount.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(currentCorrectionAmount.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(currentAdjustmentAmount.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(currentPayAmount.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(currentPreviousBalance.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(totalBalance.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(totalChargeAmount.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(totalCorrectionAmount.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(totalAdjustmentAmount.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(totalPayAmount.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(totalPreviousBalance.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(currency.getId().getTrimmedValue());
        record.append(CustomConstantsRepository.TILDE);
        record.append(delinquentAmount.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(custPOId.trim());
        record.append(CustomConstantsRepository.TILDE);
        record.append(accountEntityName.trim());
        record.append(CustomConstantsRepository.TILDE);
        record.append(entityNameFromBillRouting.trim());
        record.append(CustomConstantsRepository.TILDE);
        record.append(country);
        record.append(CustomConstantsRepository.TILDE);
        record.append(addressLine1);
        record.append(CustomConstantsRepository.TILDE);
        record.append(addressLine2);
        record.append(CustomConstantsRepository.TILDE);
        record.append(addressLine3);
        record.append(CustomConstantsRepository.TILDE);
        record.append(addressLine4);
        record.append(CustomConstantsRepository.TILDE);
        record.append(city);
        record.append(CustomConstantsRepository.TILDE);
        record.append(num1);
        record.append(CustomConstantsRepository.TILDE);
        record.append(num2);
        record.append(CustomConstantsRepository.TILDE);
        record.append(houseType);
        record.append(CustomConstantsRepository.TILDE);
        record.append(county);
        record.append(CustomConstantsRepository.TILDE);
        record.append(state);
        record.append(CustomConstantsRepository.TILDE);
        record.append(geoCode);
        record.append(CustomConstantsRepository.TILDE);
        record.append(inCityLimit);
        record.append(CustomConstantsRepository.TILDE);
        if(finalBillSwitch.isTrue()) {
            record.append(SWITCH_YES);
        } else {
            record.append(SWITCH_NO);
        }
        record.append(CustomConstantsRepository.TILDE);
        if(notNull(scheduledExtractDate)){
            record.append(scheduledExtractDate.toString());
        } else {
            record.append("");
        }
        record.append(CustomConstantsRepository.TILDE);
        record.append(entityName1.trim());
        record.append(CustomConstantsRepository.TILDE);
        record.append(entityName2.trim());
        record.append(CustomConstantsRepository.TILDE);
        record.append(entityName3.trim());
        record.append(CustomConstantsRepository.TILDE);
        record.append(currency.getCurrencySymbol().trim());
        record.append(CustomConstantsRepository.TILDE);
        record.append(totalLatePaymentCharge.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(remitToFlag);
        record.append(CustomConstantsRepository.TILDE);
        record.append(checkDigit);
        record.append(CustomConstantsRepository.TILDE);
        record.append(appInSummarySw);
        record.append(CustomConstantsRepository.TILDE);
        record.append(calcAmount.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(exemptAmount.toString());
        record.append(CustomConstantsRepository.TILDE);
        if(notNull(unitOfMeasure)){
            record.append(unitOfMeasure.getId().getTrimmedValue());
        }else {
            record.append("");
        }
        record.append(CustomConstantsRepository.TILDE);
        if(notNull(timeOfUse)){
            record.append(timeOfUse.getId().getTrimmedValue());
        } else {
            record.append("");
        }
        record.append(CustomConstantsRepository.TILDE);
        if(notNull(sqi)){
            record.append(sqi.getId().getTrimmedValue());
        }else {
            record.append("");
        }
        
        record.append(CustomConstantsRepository.TILDE);
        record.append(billSq.toString());
        record.append(CustomConstantsRepository.TILDE);
        record.append(descriptionOnBill);
        
        writeToExtractFile(record.toString());
    }
    
    /**
     * Writes the Letter Record in the extract file
     * @param fileName
     */
    private void writeLetterRecord(String fileName){
        CmLetterExtractRecord letterRecord = new CmLetterExtractRecord();
        
        letterRecord.setSortKeyLetterTemplateCode(customerContact.getLetterTemplateId().getTrimmedValue());
        letterRecord.setSortKeyCcId(customerContact.getId().getTrimmedValue());
        letterRecord.setMailingKey(postal);
        letterRecord.setCcId(customerContact.getId().getTrimmedValue());
        letterRecord.setPersonId(customerContact.getPerson().getId().getTrimmedValue());
        letterRecord.setCreateDate(customerContact.getContactDateTime().getDate().toString());
        letterRecord.setCreateTime(customerContact.getContactDateTime().getTime().toString());
        letterRecord.setCcClass(customerContact.getCustomerContactType().fetchIdContactClass().getId().getTrimmedValue());
        letterRecord.setCcType(customerContact.getCustomerContactType().fetchIdContactType().trim());
        letterRecord.setLetterTemplateCode(customerContact.getLetterTemplateId().getTrimmedValue());
        letterRecord.setLetterDate(this.getProcessDateTime().getDate().toString());
        
        //Write to the file
        writeToExtractFile(letterRecord.createRecordString());
    }
    /**
     * Writes the Mailing Information Record in the extract file
     * @param fileName
     */
    private void writeMailingInfoRecord(String fileName){
        CmMailingInformationExtractRecord mailingRecord = new CmMailingInformationExtractRecord();
        mailingRecord.setSortKeyLetterTemplateCode(customerContact.getLetterTemplateId().getTrimmedValue());
        mailingRecord.setSortKeyCcId(customerContact.getId().getTrimmedValue());
        mailingRecord.setMailingKey(postal);
        mailingRecord.setEntityName1(entityName1);
        mailingRecord.setEntityName2(entityName2);
        mailingRecord.setEntityName3(entityName3);
        mailingRecord.setCountry(country);
        mailingRecord.setAddress1(addressLine1);
        mailingRecord.setAddress2(addressLine2);
        mailingRecord.setAddress3(addressLine3);
        mailingRecord.setAddress4(addressLine4);
        mailingRecord.setCity(city);
        mailingRecord.setNum1(num1);
        mailingRecord.setNum2(num2);
        mailingRecord.setHouseType(houseType);
        mailingRecord.setCounty(county);
        mailingRecord.setState(state);
        mailingRecord.setPostal(postal);
        mailingRecord.setGeoCode(geoCode);
        mailingRecord.setInCityLimit(inCityLimit);
        mailingRecord.setCisDivision(bill.getAccount().getDivisionId().getTrimmedValue());
        
        writeToExtractFile(mailingRecord.createRecordString());
    }
    
    private void writeInvoiceRecord(String fileName){
        CmInvoiceRecord invoice = new CmInvoiceRecord();
        // START CHANGE - JHERNA - 2020-04-14 - SysAid#331145 
        String SERVICE_DATE = " ";
        if (notNull(serviceDate)) {
        	SERVICE_DATE = serviceDate.toString().trim();
        }
        
        invoice.setSortKeyLetterTemplateCode(customerContact.getLetterTemplateId().getTrimmedValue());
        invoice.setSortKeyCcId(customerContact.getId().getTrimmedValue());
        invoice.setMailingKey(postal);
        invoice.setBillId(bill.getId().getTrimmedValue());
        invoice.setAccountId(bill.getAccount().getId().getTrimmedValue());
        invoice.setBillDate(bill.getBillDate().toString());
        invoice.setDueDate(bill.getDueDate().toString());
//        invoice.setServiceDate(serviceDate.toString());
        invoice.setServiceDate(SERVICE_DATE);
        // END CHANGE - JHERNA - 2020-04-14 - SysAid#331145
        invoice.setCurrentBalance(currentBalance);
        invoice.setCurrentChargeAmount(currentChargeAmount);
        invoice.setCurrentCorrAmount(currentCorrectionAmount);
        invoice.setCurrentAdjustmentAmount(currentAdjustmentAmount);
        invoice.setCurrentPayAmount(currentPayAmount);
        invoice.setCurrentPreviousBalance(currentPreviousBalance);
        invoice.setTotalBalance(totalBalance);
        invoice.setTotalChargeAmount(totalChargeAmount);
        invoice.setTotalCorrAmount(totalCorrectionAmount);
        invoice.setTotalAdjAmount(totalAdjustmentAmount);
        invoice.setTotalPayAmount(totalPayAmount);
        invoice.setTotalPreviousBalance(totalPreviousBalance);
        invoice.setCurrencyCode(currency.getId().getTrimmedValue());
        invoice.setDelinquentAmount(delinquentAmount);
        invoice.setCustomerPOId(custPOId);
        invoice.setAccountEntityName(accountEntityName);
        invoice.setEntityName(entityNameFromBillRouting);
        invoice.setAddressSbr(country,
                              addressLine1,
                              addressLine2,
                              addressLine3,
                              addressLine4,
                              city,
                              num1,
                              num2,
                              houseType,
                              county,
                              state,
                              postal,
                              geoCode,
                              inCityLimit);
        if(finalBillSwitch.isTrue()){
            invoice.setFinalBillSwitch(SWITCH_YES);
        } else {
            invoice.setFinalBillSwitch(SWITCH_NO);
        }
        if(notNull(scheduledExtractDate)){
            invoice.setScheduledExtractDate(scheduledExtractDate.toString());
        } else {
            invoice.setScheduledExtractDate("");
        }
        invoice.setEntityName1(entityName1);
        invoice.setEntityName2(entityName2);
        invoice.setEntityName3(entityName3);
        invoice.setAccountCurrencySymbol(currency.getCurrencySymbol());
        invoice.setTotalLatePaymentCharge(totalLatePaymentCharge);
        invoice.setRemitToFlag(remitToFlag);
        invoice.setCheckDigit(checkDigit);
        
        writeToExtractFile(invoice.createRecordString());
    }
    
    private void writeInvoiceLineRecord(String fileName){

        Iterator<SQLResultRow> iterator = invoiceLineDetails.iterator();
        
        //For every Calculation line , write it into an invoice Line Detail Record
        //In the extract file
        while(iterator.hasNext()){
            SQLResultRow invoiceLineDetail = iterator.next();
            CmInvoiceLineRecord invoiceLine = new CmInvoiceLineRecord();
            
            appInSummarySw = invoiceLineDetail.getString("APP_IN_SUMM_SW");
            if(notNull(invoiceLineDetail.getBigDecimal("CALC_AMT"))){
                calcAmount = invoiceLineDetail.getBigDecimal("CALC_AMT");
            } else {
                calcAmount = BigDecimal.ZERO;
            }
            if(notNull(invoiceLineDetail.getBigDecimal("EXEMPT_AMT"))){
                exemptAmount = invoiceLineDetail.getBigDecimal("EXEMPT_AMT");
            } else {
                exemptAmount = BigDecimal.ZERO;
            }
            unitOfMeasure = new UnitOfMeasure_Id(invoiceLineDetail.getString("UOM_CD")).getEntity();
            timeOfUse = new TimeOfUse_Id(invoiceLineDetail.getString("TOU_CD")).getEntity();
            sqi = new ServiceQuantityIdentifier_Id(invoiceLineDetail.getString("SQI_CD")).getEntity();
            if(notNull(invoiceLineDetail.getBigDecimal("BILL_SQ"))) {
                billSq = invoiceLineDetail.getBigDecimal("BILL_SQ");
            } else {
                billSq = BigDecimal.ZERO;
            }
            descriptionOnBill = invoiceLineDetail.getString("DESCR_ON_BILL");
            
            invoiceLine.setSortKeyLetterTemplateCode(customerContact.getLetterTemplateId().getTrimmedValue());
            invoiceLine.setSortKeyCcId(customerContact.getId().getTrimmedValue());
            invoiceLine.setMailingKey(postal);
            invoiceLine.setAppInSummarySwitch(appInSummarySw);
            invoiceLine.setCalcAmount(calcAmount);
            invoiceLine.setExemptAmount(exemptAmount);
            if(notNull(unitOfMeasure)){
                invoiceLine.setUnitOfMeasure(unitOfMeasure.getId().getTrimmedValue());
            } else {
                invoiceLine.setUnitOfMeasure("");
            }
            if(notNull(timeOfUse)){
                invoiceLine.setTimeOfUse(timeOfUse.getId().getTrimmedValue());
            } else {
                invoiceLine.setTimeOfUse("");
            }
            if(notNull(sqi)){
                invoiceLine.setServiceQuantityIdentifier(sqi.getId().getTrimmedValue());
            } else {
                invoiceLine.setServiceQuantityIdentifier("");
            }
            invoiceLine.setBillSQ(billSq);
            invoiceLine.setBillDescription(descriptionOnBill);
            
            writeToExtractFile(invoiceLine.createRecordString());
        }
    
    }
    
    /**
     * Writes the End Detail Record in the Extract File
     * @param fileName
     */
    private void writeEndDetailRecord(String fileName){
        CmEndOfLetterExtractRecord endRecord = new CmEndOfLetterExtractRecord();
        
        endRecord.setSortKeyLetterTemplateCode(customerContact.getLetterTemplateId().getTrimmedValue());
        endRecord.setSortKeyCcId(customerContact.getId().getTrimmedValue());
        endRecord.setMailingKey(postal);
        
        writeToExtractFile(endRecord.createRecordString());
    }
    
    /**
     * Method that opens the file
     */
    private void openExtractFile(){
        try {
            extractFile = new File(extractFileName.trim());
            bufferedWriter = new BufferedWriter(new FileWriter(extractFile,true));
        }
        catch(Exception e) {
            //Add Error
            addError(CustomMessageRepository.SA_315895_ErrorInOpeningFile(extractFileName.trim(), e.getLocalizedMessage()));
        }
    }
    
    /**
     * Method that closes the file
     */
    private void closeExtractFile(){
        try {
            bufferedWriter.close();
        } catch (IOException e) {
            addError(CustomMessageRepository.SA_315895_ErrorInClosingFile(extractFileName.trim(), e.getLocalizedMessage()));
        }
    }
    
    /**
     * Write to extract File
     * @param record
     */
    private void writeToExtractFile(String record) {
        try {
            bufferedWriter.write(record);
            bufferedWriter.newLine();
        }
        catch(Exception e) {
            //Add Error
            addError(CustomMessageRepository.SA_315895_ErrorInWritingToFile(extractFileName.trim(), e.getLocalizedMessage()));
        }
    }
    
    private Bool checkIfBillIsFinalBill(){
        Bool result = Bool.FALSE;
        
        //Check if no Pending Start or active SAs in the account
        if(checkCountOfPendingStartOrActiveSA().compareTo(BigInteger.ONE) < 0){
            if(checkCountOfCancelledOrClosedSA().compareTo(BigInteger.ONE) < 0) {
                result = Bool.TRUE;
            }
        }
        
        return result;
    }
    
    private String retrieveRemitToCharVal() {
        String result = "";
        
        if(notNull(bill.getAccount().getEffectiveCharacteristic(remitToCharType))){
            //Get the Remit To Characteristic Value from the Account linked to the bill
            result = bill.getAccount().getEffectiveCharacteristic(remitToCharType).getSearchCharacteristicValue();
        } else {
            //If Account has no Remit To Characteristic Type, get the Remit Characteristic Value from the Account's CIS Division Characteristics
            CisDivision cisDivision = bill.getAccount().fetchDivision();
            if(notNull(cisDivision.getEffectiveCharacteristic(remitToCharType))){
                if(cisDivision.getEffectiveCharacteristic(remitToCharType).getId().getCharacteristicType().getCharacteristicType().isAdhocValue()){
                    result = cisDivision.getEffectiveCharacteristic(remitToCharType).getAdhocCharacteristicValue();
                } else if (cisDivision.getEffectiveCharacteristic(remitToCharType).getId().getCharacteristicType().getCharacteristicType().isPredefinedValue()){
                    result = cisDivision.getEffectiveCharacteristic(remitToCharType).getCharacteristicValue();
                } else if (cisDivision.getEffectiveCharacteristic(remitToCharType).getId().getCharacteristicType().getCharacteristicType().isForeignKeyValue()) {
                    result = cisDivision.getEffectiveCharacteristic(remitToCharType).getCharacteristicValueForeignKey1();
                }
            } else {
                //If CIS Division still does not have the Remit To Characteristic Type, 
                // default the value to the Default Remit Characteristic Value Parameter
                result = defaultRemitToCharValue;
            }
        }
    
        return result;
    }
    
    private List<SQLResultRow> retrieveBillFromCustomerContactChar(CustomerContact cc){
        StringBuilder stringRetrieveBillIdFromCCChar = new StringBuilder();
        PreparedStatement queryRetrieveBillIdFromCCChar;
        List <SQLResultRow> result = null;
        
        stringRetrieveBillIdFromCCChar.append("SELECT ");
        stringRetrieveBillIdFromCCChar.append(   "CC.SRCH_CHAR_VAL AS BILL_ID ");
        stringRetrieveBillIdFromCCChar.append("FROM ");
        stringRetrieveBillIdFromCCChar.append(    "CI_CC_CHAR CC ");
        stringRetrieveBillIdFromCCChar.append("WHERE ");
        stringRetrieveBillIdFromCCChar.append(    "CC.CC_ID = :customerContactId ");
        stringRetrieveBillIdFromCCChar.append( "AND CC.CHAR_TYPE_CD = :billCCCharType ");
        
        queryRetrieveBillIdFromCCChar = createPreparedStatement(stringRetrieveBillIdFromCCChar.toString(), getClass().getName());
        queryRetrieveBillIdFromCCChar.bindId("customerContactId", cc.getId());
        queryRetrieveBillIdFromCCChar.bindEntity("billCCCharType", billIDCustomerContactCharType);
        
        result = queryRetrieveBillIdFromCCChar.list();
        queryRetrieveBillIdFromCCChar.close();
        
        return result;
    }
    
    private Date retrieveServiceDate(){
        StringBuilder stringRetrieveServiceDate = new StringBuilder();
        PreparedStatement queryRetrieveServiceDate = null;
        SQLResultRow result = null;
        Date serviceDate = null;
        
        stringRetrieveServiceDate.append("SELECT MIN(BS.START_DT) AS SERVICE_DT ");
        stringRetrieveServiceDate.append("FROM ");
        stringRetrieveServiceDate.append(   "CI_BSEG BS ");
        stringRetrieveServiceDate.append("WHERE ");
        stringRetrieveServiceDate.append(   "BS.BILL_ID = :billId ");
        stringRetrieveServiceDate.append("AND ");
        stringRetrieveServiceDate.append(   "BS.BSEG_STAT_FLG= '50' ");
        
        queryRetrieveServiceDate = createPreparedStatement(stringRetrieveServiceDate.toString(), getClass().getName());
        queryRetrieveServiceDate.bindId("billId", bill.getId());
        
        result = queryRetrieveServiceDate.firstRow();
        if(notNull(result)){
            serviceDate = result.getDate("SERVICE_DT");
        }
        
        queryRetrieveServiceDate.close();
        
        return serviceDate;
    }
    
    private SQLResultRow retrieveBillBalances() {
        SQLResultRow result = null;
        StringBuilder stringRetrieveBillBalances = new StringBuilder();
        PreparedStatement queryRetrieveBillBalances = null;
        
        stringRetrieveBillBalances.append("SELECT ");
        stringRetrieveBillBalances.append(    "CURRENCY_CD, ");
        stringRetrieveBillBalances.append(    "SUM(CUR_AMT) AS CUR_AMT, ");
        stringRetrieveBillBalances.append(    "SUM(TOT_AMT) AS TOT_AMT ");
        stringRetrieveBillBalances.append("FROM ");
        stringRetrieveBillBalances.append(    "CI_BILL_SA ");
        stringRetrieveBillBalances.append("WHERE ");
        stringRetrieveBillBalances.append(    "BILL_ID = :billId ");
        stringRetrieveBillBalances.append("GROUP BY CURRENCY_CD ");
        
        queryRetrieveBillBalances = createPreparedStatement(stringRetrieveBillBalances.toString(), getClass().getName());
        queryRetrieveBillBalances.bindId("billId" , bill.getId());
        
        result = queryRetrieveBillBalances.firstRow();
        
        queryRetrieveBillBalances.close();
        
        return result;
    }
    
    private SQLResultRow retrieveBillCurrentChargeAmounts() {
        SQLResultRow result = null;
        StringBuilder stringRetrieveBillCurrentChargeAmounts = new StringBuilder();
        PreparedStatement queryRetrieveBillCurrentChargeAmounts = null;
        
        stringRetrieveBillCurrentChargeAmounts.append("SELECT ");
        stringRetrieveBillCurrentChargeAmounts.append(    "CURRENCY_CD, ");
        stringRetrieveBillCurrentChargeAmounts.append(    "SUM(CUR_AMT) AS CUR_AMT, ");
        stringRetrieveBillCurrentChargeAmounts.append(    "SUM(TOT_AMT) AS TOT_AMT ");
        stringRetrieveBillCurrentChargeAmounts.append("FROM ");
        stringRetrieveBillCurrentChargeAmounts.append(    "CI_FT ");
        stringRetrieveBillCurrentChargeAmounts.append("WHERE ");
        stringRetrieveBillCurrentChargeAmounts.append(    "BILL_ID = :billId ");
        stringRetrieveBillCurrentChargeAmounts.append("AND ");
        stringRetrieveBillCurrentChargeAmounts.append(    "FT_TYPE_FLG IN ('BS','BX') ");
        stringRetrieveBillCurrentChargeAmounts.append("AND ");
        stringRetrieveBillCurrentChargeAmounts.append(    "CORRECTION_SW = 'N' ");
        stringRetrieveBillCurrentChargeAmounts.append("AND ");
        stringRetrieveBillCurrentChargeAmounts.append(    "SHOW_ON_BILL_SW = 'Y' ");
        stringRetrieveBillCurrentChargeAmounts.append("GROUP BY CURRENCY_CD ");
        
        queryRetrieveBillCurrentChargeAmounts = createPreparedStatement(stringRetrieveBillCurrentChargeAmounts.toString(), getClass().getName());
        queryRetrieveBillCurrentChargeAmounts.bindId("billId" , bill.getId());
        
        result = queryRetrieveBillCurrentChargeAmounts.firstRow();
        
        queryRetrieveBillCurrentChargeAmounts.close();
        
        return result;
    }
    
    private SQLResultRow retrieveBillCorrectionAmounts(){
        SQLResultRow result = null;
        StringBuilder stringRetrieveBillCorrectionAmounts = new StringBuilder();
        PreparedStatement queryRetrieveBillCorrectionAmounts = null;
        
        stringRetrieveBillCorrectionAmounts.append("SELECT ");
        stringRetrieveBillCorrectionAmounts.append(    "CURRENCY_CD, ");
        stringRetrieveBillCorrectionAmounts.append(    "SUM(CUR_AMT) AS CUR_AMT, ");
        stringRetrieveBillCorrectionAmounts.append(    "SUM(TOT_AMT) AS TOT_AMT ");
        stringRetrieveBillCorrectionAmounts.append("FROM ");
        stringRetrieveBillCorrectionAmounts.append(    "CI_FT ");
        stringRetrieveBillCorrectionAmounts.append("WHERE ");
        stringRetrieveBillCorrectionAmounts.append(    "BILL_ID = :billId ");
        stringRetrieveBillCorrectionAmounts.append("AND ");
        stringRetrieveBillCorrectionAmounts.append(    "FT_TYPE_FLG IN ('BS','BX') ");
        stringRetrieveBillCorrectionAmounts.append("AND ");
        stringRetrieveBillCorrectionAmounts.append(    "CORRECTION_SW = 'Y' ");
        stringRetrieveBillCorrectionAmounts.append("AND ");
        stringRetrieveBillCorrectionAmounts.append(    "SHOW_ON_BILL_SW = 'Y' ");
        stringRetrieveBillCorrectionAmounts.append("GROUP BY CURRENCY_CD ");
        
        queryRetrieveBillCorrectionAmounts = createPreparedStatement(stringRetrieveBillCorrectionAmounts.toString(), getClass().getName());
        queryRetrieveBillCorrectionAmounts.bindId("billId" , bill.getId());
        
        result = queryRetrieveBillCorrectionAmounts.firstRow();
        
        queryRetrieveBillCorrectionAmounts.close();
        
        return result;
    }
    
    private SQLResultRow retrieveBillAdjustmentAmounts() {
        SQLResultRow result = null;
        StringBuilder stringRetrieveBillAdjustmentAmounts = new StringBuilder();
        PreparedStatement queryRetrieveBillAdjustmentAmounts = null;
        
        stringRetrieveBillAdjustmentAmounts.append("SELECT ");
        stringRetrieveBillAdjustmentAmounts.append(    "CURRENCY_CD, ");
        stringRetrieveBillAdjustmentAmounts.append(    "SUM(CUR_AMT) AS CUR_AMT, ");
        stringRetrieveBillAdjustmentAmounts.append(    "SUM(TOT_AMT) AS TOT_AMT ");
        stringRetrieveBillAdjustmentAmounts.append("FROM ");
        stringRetrieveBillAdjustmentAmounts.append(    "CI_FT ");
        stringRetrieveBillAdjustmentAmounts.append("WHERE ");
        stringRetrieveBillAdjustmentAmounts.append(    "BILL_ID = :billId ");
        stringRetrieveBillAdjustmentAmounts.append("AND ");
        stringRetrieveBillAdjustmentAmounts.append(    "FT_TYPE_FLG IN ('AD','AX') ");
        stringRetrieveBillAdjustmentAmounts.append("AND ");
        stringRetrieveBillAdjustmentAmounts.append(    "SHOW_ON_BILL_SW = 'Y' ");
        stringRetrieveBillAdjustmentAmounts.append("GROUP BY CURRENCY_CD ");
        
        queryRetrieveBillAdjustmentAmounts = createPreparedStatement(stringRetrieveBillAdjustmentAmounts.toString(), getClass().getName());
        queryRetrieveBillAdjustmentAmounts.bindId("billId" , bill.getId());
        
        result = queryRetrieveBillAdjustmentAmounts.firstRow();
        
        queryRetrieveBillAdjustmentAmounts.close();
        
        return result;
    }
    
    private SQLResultRow retrieveBillPaymentAmounts() {
        SQLResultRow result = null;
        StringBuilder stringRetrieveBillPaymentAmounts = new StringBuilder();
        PreparedStatement queryRetrieveBillPaymentAmounts = null;
        
        stringRetrieveBillPaymentAmounts.append("SELECT ");
        stringRetrieveBillPaymentAmounts.append(    "CURRENCY_CD, ");
        stringRetrieveBillPaymentAmounts.append(    "SUM(CUR_AMT) AS CUR_AMT, ");
        stringRetrieveBillPaymentAmounts.append(    "SUM(TOT_AMT) AS TOT_AMT ");
        stringRetrieveBillPaymentAmounts.append("FROM ");
        stringRetrieveBillPaymentAmounts.append(    "CI_FT ");
        stringRetrieveBillPaymentAmounts.append("WHERE ");
        stringRetrieveBillPaymentAmounts.append(    "BILL_ID = :billId ");
        stringRetrieveBillPaymentAmounts.append("AND ");
        stringRetrieveBillPaymentAmounts.append(     "FT_TYPE_FLG IN ('PS','PX') ");
        stringRetrieveBillPaymentAmounts.append("AND ");
        stringRetrieveBillPaymentAmounts.append(    "SHOW_ON_BILL_SW = 'Y' ");
        stringRetrieveBillPaymentAmounts.append("GROUP BY CURRENCY_CD ");
        
        queryRetrieveBillPaymentAmounts = createPreparedStatement(stringRetrieveBillPaymentAmounts.toString(), getClass().getName());
        queryRetrieveBillPaymentAmounts.bindId("billId" , bill.getId());
        
        result = queryRetrieveBillPaymentAmounts.firstRow();
        
        queryRetrieveBillPaymentAmounts.close();
        
        return result;
    }
    
    private BigInteger checkCountOfPendingStartOrActiveSA() {
        BigInteger result = null;
        StringBuilder stringCheckCountOfPendingStartOrActiveSA = new StringBuilder();
        PreparedStatement queryCheckCountOfPendingStartOrActiveSA = null;
        SQLResultRow row = null;
        
        stringCheckCountOfPendingStartOrActiveSA.append("SELECT ");
        stringCheckCountOfPendingStartOrActiveSA.append(    "COUNT(*) AS COUNT ");
        stringCheckCountOfPendingStartOrActiveSA.append("FROM ");
        stringCheckCountOfPendingStartOrActiveSA.append(    "CI_SA A, ");
        stringCheckCountOfPendingStartOrActiveSA.append(    "CI_SA_TYPE B ");
        stringCheckCountOfPendingStartOrActiveSA.append("WHERE ");
        stringCheckCountOfPendingStartOrActiveSA.append(    "A.ACCT_ID = :accountId ");
        stringCheckCountOfPendingStartOrActiveSA.append(    "AND A.SA_STATUS_FLG IN ('10','20') ");
        stringCheckCountOfPendingStartOrActiveSA.append(    "AND B.CIS_DIVISION = A.CIS_DIVISION ");
        stringCheckCountOfPendingStartOrActiveSA.append(    "AND B.SA_TYPE_CD = A.SA_TYPE_CD ");
        stringCheckCountOfPendingStartOrActiveSA.append(    "AND B.ALLOW_BILLING_SW = 'Y' ");
        
        queryCheckCountOfPendingStartOrActiveSA = createPreparedStatement(stringCheckCountOfPendingStartOrActiveSA.toString() , getClass().getName());
        queryCheckCountOfPendingStartOrActiveSA.bindId("accountId" , bill.getAccount().getId());
        
        row = queryCheckCountOfPendingStartOrActiveSA.firstRow();
        queryCheckCountOfPendingStartOrActiveSA.close();
        
        result = row.getInteger("COUNT");
        
        return result;
    }
    
    private BigInteger checkCountOfCancelledOrClosedSA() {
        BigInteger result = null;
        StringBuilder stringCheckCountOfCancelledOrClosedSA = new StringBuilder();
        PreparedStatement queryCheckCountOfCancelledOrClosedSA = null;
        SQLResultRow row = null;
        
        stringCheckCountOfCancelledOrClosedSA.append("SELECT ");
        stringCheckCountOfCancelledOrClosedSA.append(    "COUNT(*) AS COUNT ");
        stringCheckCountOfCancelledOrClosedSA.append("FROM ");
        stringCheckCountOfCancelledOrClosedSA.append(    "CI_SA SA, ");
        stringCheckCountOfCancelledOrClosedSA.append(    "CI_SA_TYPE SAT ");
        stringCheckCountOfCancelledOrClosedSA.append("WHERE ");
        stringCheckCountOfCancelledOrClosedSA.append(    "SA.ACCT_ID = :accountId ");
        stringCheckCountOfCancelledOrClosedSA.append(    "AND SA.SA_STATUS_FLG NOT IN ('60','70') ");
        stringCheckCountOfCancelledOrClosedSA.append(    "AND SAT.CIS_DIVISION = SA.CIS_DIVISION ");
        stringCheckCountOfCancelledOrClosedSA.append(    "AND SAT.SA_TYPE_CD = SA.SA_TYPE_CD ");
        stringCheckCountOfCancelledOrClosedSA.append(    "AND SAT.ALLOW_BILLING_SW = 'Y' ");
        stringCheckCountOfCancelledOrClosedSA.append(    "AND NOT EXISTS ");
        stringCheckCountOfCancelledOrClosedSA.append(         "(SELECT BS.SA_ID ");
        stringCheckCountOfCancelledOrClosedSA.append(         "FROM CI_BSEG BS ");
        stringCheckCountOfCancelledOrClosedSA.append(         "WHERE BS.SA_ID = SA.SA_ID ");
        stringCheckCountOfCancelledOrClosedSA.append(         "AND BS.BSEG_STAT_FLG = '50' ");
        stringCheckCountOfCancelledOrClosedSA.append(         "AND BS.CLOSING_BSEG_SW = 'Y') ");
        
        queryCheckCountOfCancelledOrClosedSA = createPreparedStatement(stringCheckCountOfCancelledOrClosedSA.toString() , getClass().getName());
        queryCheckCountOfCancelledOrClosedSA.bindId("accountId" , bill.getAccount().getId());
        
        row = queryCheckCountOfCancelledOrClosedSA.firstRow();
        queryCheckCountOfCancelledOrClosedSA.close();
        
        result = row.getInteger("COUNT");
        
        return result;
    }
    
    private Date retrieveScheduledDate(){
        Date result = null;
        StringBuilder stringRetrieveScheduledDate = new StringBuilder();
        PreparedStatement queryRetrieveScheduledDate = null;
        SQLResultRow row = null;
        
        stringRetrieveScheduledDate.append("SELECT ");
        stringRetrieveScheduledDate.append(      "ST.SCHED_EXTRACT_DT, ");
        stringRetrieveScheduledDate.append(      "AP.START_DT, ");
        stringRetrieveScheduledDate.append(      "AP.END_DT, ");
        stringRetrieveScheduledDate.append(      "AP.EXPIRE_DT, ");
        stringRetrieveScheduledDate.append(      "AP.EXT_ACCT_ID ");
        stringRetrieveScheduledDate.append("FROM ");
        stringRetrieveScheduledDate.append(      "CI_APAY_CLR_STG ST, ");
        stringRetrieveScheduledDate.append(      "CI_ACCT_APAY AP ");
        stringRetrieveScheduledDate.append("WHERE ");
        stringRetrieveScheduledDate.append(    "ST.BILL_ID = :billId ");
        stringRetrieveScheduledDate.append("AND ");
        stringRetrieveScheduledDate.append(    "ST.ACCT_APAY_ID = AP.ACCT_APAY_ID ");
        stringRetrieveScheduledDate.append("UNION SELECT ");
        stringRetrieveScheduledDate.append(    "BILL.APAY_CRE_DT ");
        stringRetrieveScheduledDate.append(    ", AP.START_DT ");
        stringRetrieveScheduledDate.append(    ", AP.END_DT ");
        stringRetrieveScheduledDate.append(    ", AP.EXPIRE_DT ");
        stringRetrieveScheduledDate.append(    ", AP.EXT_ACCT_ID ");
        stringRetrieveScheduledDate.append("FROM ");
        stringRetrieveScheduledDate.append(    "CI_BILL BILL ");
        stringRetrieveScheduledDate.append(    ", CI_ACCT_APAY AP ");
        stringRetrieveScheduledDate.append("WHERE ");
        stringRetrieveScheduledDate.append(    "BILL.BILL_ID = :billId ");
        stringRetrieveScheduledDate.append("AND ");
        stringRetrieveScheduledDate.append(    "BILL.APAY_CRE_DT IS NOT NULL ");
        stringRetrieveScheduledDate.append("AND ");
        stringRetrieveScheduledDate.append(    "BILL.ACCT_ID = AP.ACCT_ID ");
        stringRetrieveScheduledDate.append("AND ");
        stringRetrieveScheduledDate.append(    "AP.START_DT <= BILL.DUE_DT ");
        stringRetrieveScheduledDate.append("AND ");
        stringRetrieveScheduledDate.append(    "(AP.END_DT >= BILL.DUE_DT ");
        stringRetrieveScheduledDate.append(     "OR AP.END_DT IS NULL) ");
        
        queryRetrieveScheduledDate = createPreparedStatement(stringRetrieveScheduledDate.toString(), getClass().getName());
        queryRetrieveScheduledDate.bindId("billId", bill.getId());
        
        row = queryRetrieveScheduledDate.firstRow();
        queryRetrieveScheduledDate.close();
        
        if(notNull(row)){
            result = row.getDate("SCHED_EXTRACT_DT");
        }
        
        return result;
    }
    
    private BigDecimal retrieveTotalLatePaymentCharge() {
        BigDecimal result = null;
        StringBuilder stringRetrieveLPC = new StringBuilder();
        PreparedStatement queryRetrieveLPC = null;
        SQLResultRow row = null;
        
        stringRetrieveLPC.append("SELECT ");
        stringRetrieveLPC.append(    "SUM(FT.CUR_AMT) AS CUR_AMT, ");
        stringRetrieveLPC.append(    "SUM(FT.TOT_AMT) AS TOT_AMT ");
        stringRetrieveLPC.append("FROM ");
        stringRetrieveLPC.append(    "CI_FT FT, ");
        stringRetrieveLPC.append(    "CI_ADJ ADJ, ");
        stringRetrieveLPC.append(    "CI_ADJ_TYPE ADJTYPE ");
        stringRetrieveLPC.append("WHERE ");
        stringRetrieveLPC.append(    "FT.BILL_ID = :billId ");
        stringRetrieveLPC.append("AND ");
        stringRetrieveLPC.append("    FT.SHOW_ON_BILL_SW = 'Y' ");
        stringRetrieveLPC.append("AND ");
        stringRetrieveLPC.append(     "FT.FT_TYPE_FLG IN ('AD','AX') ");
        stringRetrieveLPC.append("AND ");
        stringRetrieveLPC.append(     "FT.SIBLING_ID = ADJ.ADJ_ID  ");
        stringRetrieveLPC.append("AND ");
        stringRetrieveLPC.append(    "ADJ.ADJ_TYPE_CD = ADJTYPE.ADJ_TYPE_CD ");
        stringRetrieveLPC.append("AND EXISTS ");
        stringRetrieveLPC.append(     "(SELECT 'X' ");
        stringRetrieveLPC.append(      "FROM CI_ADJ_TY_CHAR ADJTYCHAR  ");
        stringRetrieveLPC.append(      "WHERE ");
        stringRetrieveLPC.append(           "ADJTYCHAR.ADJ_TYPE_CD = ADJTYPE.ADJ_TYPE_CD ");
        stringRetrieveLPC.append(      "AND ");
        stringRetrieveLPC.append(           "ADJTYCHAR.CHAR_TYPE_CD = :lpcCharType)    ");
        
        queryRetrieveLPC = createPreparedStatement(stringRetrieveLPC.toString(),getClass().getName());
        queryRetrieveLPC.bindId("billId", bill.getId());
        queryRetrieveLPC.bindEntity("lpcCharType", latePaymentCharType);

        row = queryRetrieveLPC.firstRow();
        queryRetrieveLPC.close();
        
        if(notNull(row)) {
            result = row.getBigDecimal("TOT_AMT");
        } 
        
        return result;
    }
    
    private List<SQLResultRow> retrieveInvoiceLineDetails(){
        List<SQLResultRow> result = null;
        StringBuilder stringInvoiceLine = new StringBuilder();
        PreparedStatement queryInvoiceLine = null;
            
        stringInvoiceLine.append("SELECT ");
        stringInvoiceLine.append(   "BC.BSEG_ID , ");
        stringInvoiceLine.append(   "BC.HEADER_SEQ ,  ");
        stringInvoiceLine.append(   "TO_NUMBER(NVL( ");
        stringInvoiceLine.append(                  "(  ");
        stringInvoiceLine.append(                     "SELECT ");
        stringInvoiceLine.append(                           "CC.CHAR_VAL  ");
        stringInvoiceLine.append(                     "FROM ");
        stringInvoiceLine.append(                           "CI_BSEG_CL_CHAR CC ");
        stringInvoiceLine.append(                     "WHERE ");
        stringInvoiceLine.append(                           "CC.BSEG_ID= BC.BSEG_ID ");
        stringInvoiceLine.append(                     "AND ");
        stringInvoiceLine.append(                           "CC.HEADER_SEQ = BC.HEADER_SEQ  ");
        stringInvoiceLine.append(                     "AND ");
        stringInvoiceLine.append(                           "CC.SEQNO= BC.SEQNO ");
        stringInvoiceLine.append(                     "AND ");
        stringInvoiceLine.append(                           "CC.CHAR_TYPE_CD = :sequenceCharType  ");
        stringInvoiceLine.append(                    ") ");
        stringInvoiceLine.append(    ", BC.SEQNO)) AS SEQNO ,  ");
        stringInvoiceLine.append(    "BC.RC_SEQ ,  ");
        stringInvoiceLine.append(    "BC.PRT_SW ,  ");
        stringInvoiceLine.append(    "BC.APP_IN_SUMM_SW ,  ");
        stringInvoiceLine.append(    "BC.CALC_AMT ,  ");
        stringInvoiceLine.append(    "BC.EXEMPT_AMT ,  ");
        stringInvoiceLine.append(    "BC.BASE_AMT ,  ");
        stringInvoiceLine.append(    "BC.CURRENCY_CD , ");
        stringInvoiceLine.append(    "BC.DST_ID ,  ");
        stringInvoiceLine.append(    "BC.CHAR_TYPE_CD ,  ");
        stringInvoiceLine.append(    "BC.CHAR_VAL ,  ");
        stringInvoiceLine.append(    "BC.UOM_CD ,  ");
        stringInvoiceLine.append(    "BC.TOU_CD ,  ");
        stringInvoiceLine.append(    "BC.SQI_CD ,  ");
        stringInvoiceLine.append(    "BC.BILL_SQ , ");
        stringInvoiceLine.append(    "BC.MSR_PEAK_QTY_SW , ");
        stringInvoiceLine.append(    "NVL( ");
        stringInvoiceLine.append(           "(  ");
        stringInvoiceLine.append(             "SELECT ");
        stringInvoiceLine.append(             "TRIM(PC.ADHOC_CHAR_VAL)  ");
        stringInvoiceLine.append(             "|| TRIM(PC.CHAR_VAL_FK1) ");
        stringInvoiceLine.append(             "|| ");
        stringInvoiceLine.append(                 "(  ");
        stringInvoiceLine.append(                     "SELECT ");
        stringInvoiceLine.append(                           "TRIM(CV.DESCR) ");
        stringInvoiceLine.append(                     "FROM ");
        stringInvoiceLine.append(                           "CI_CHAR_VAL_L CV ");
        stringInvoiceLine.append(                     "WHERE  ");
        stringInvoiceLine.append(                         "CV.CHAR_TYPE_CD= PC.CHAR_TYPE_CD ");
        stringInvoiceLine.append(                     "AND CV.CHAR_VAL= PC.CHAR_VAL ");
        stringInvoiceLine.append(                     "AND CV.LANGUAGE_CD = :language ");
        stringInvoiceLine.append(                 ")||' ' ");
        stringInvoiceLine.append(              "FROM ");
        stringInvoiceLine.append(                  "CI_BSEG_CL_CHAR CC,  ");
        stringInvoiceLine.append(                  "CI_BSEG BS,  ");
        stringInvoiceLine.append(                  "CI_PREM_CHAR PC  ");
        stringInvoiceLine.append(              "WHERE  ");
        stringInvoiceLine.append(                  "CC.BSEG_ID= BC.BSEG_ID ");
        stringInvoiceLine.append(              "AND CC.HEADER_SEQ = BC.HEADER_SEQ  ");
        stringInvoiceLine.append(              "AND CC.SEQNO= BC.SEQNO ");
        stringInvoiceLine.append(              "AND CC.CHAR_TYPE_CD = :taxCharType ");
        stringInvoiceLine.append(              "AND BS.BSEG_ID= CC.BSEG_ID ");
        stringInvoiceLine.append(              "AND PC.PREM_ID= BS.PREM_ID ");
        stringInvoiceLine.append(              "AND PC.CHAR_TYPE_CD =  ");
        stringInvoiceLine.append(                   ":townCodeCharType  ");
        stringInvoiceLine.append(              "AND PC.EFFDT= ");
        stringInvoiceLine.append(                             "(  ");
        stringInvoiceLine.append(                                "SELECT ");
        stringInvoiceLine.append(                                      "MAX(PC1.EFFDT) ");
        stringInvoiceLine.append(                                "FROM ");
        stringInvoiceLine.append(                                      "CI_PREM_CHAR PC1 ");
        stringInvoiceLine.append(                                "WHERE  ");
        stringInvoiceLine.append(                                     "PC1.PREM_ID= PC.PREM_ID  ");
        stringInvoiceLine.append(                                 "AND PC1.CHAR_TYPE_CD = PC.CHAR_TYPE_CD ");
        stringInvoiceLine.append(                                 "AND PC1.EFFDT <= :processDate  ");
        stringInvoiceLine.append(                             ") ");
        stringInvoiceLine.append(            ") ");
        stringInvoiceLine.append(    ", '') ");
        stringInvoiceLine.append(    "|| BC.DESCR_ON_BILL AS DESCR_ON_BILL ");
        stringInvoiceLine.append("FROM ");
        stringInvoiceLine.append(    "CI_BSEG_CALC_LN BC,  ");
        stringInvoiceLine.append(    "CI_BSEG BS ");
        stringInvoiceLine.append("WHERE  ");
        stringInvoiceLine.append(    "BS.BILL_ID = :billId ");
        stringInvoiceLine.append("AND BC.BSEG_ID = BS.BSEG_ID  ");
        stringInvoiceLine.append("AND BC.PRT_SW= 'Y' ");
        stringInvoiceLine.append("ORDER BY ");
        stringInvoiceLine.append(    "BSEG_ID, ");
        stringInvoiceLine.append(    "HEADER_SEQ,  ");
        stringInvoiceLine.append(    "SEQNO  ");
        
        queryInvoiceLine = createPreparedStatement(stringInvoiceLine.toString(), getClass().getName());
        queryInvoiceLine.bindId("billId", bill.getId());
        queryInvoiceLine.bindDate("processDate", getProcessDateTime().getDate());
        queryInvoiceLine.bindEntity("townCodeCharType", townCodeCharType);
        queryInvoiceLine.bindEntity("language", getActiveContextLanguage());
        queryInvoiceLine.bindEntity("taxCharType", taxCommunityCharType);
        queryInvoiceLine.bindEntity("sequenceCharType" , billLinePriorityCharType);
        
        result = queryInvoiceLine.list();
        
        return result;
    }
    //End Add - JVitug - SA-315895
    
    //Start Delete - JVitug - SA-315895
    /*
     * Initialize Cobol Program
     */
//  @SuppressWarnings("deprecation")
//  private void initializeCobolProgram() throws Exception {
//  
//      FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
//      RequestContext context = session.getRequestContext();
//       
//      SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//      //Start Change - MPang - Defect 3439849 - 2016-05-23
//      //Connection connection = implementor.getConnectionProvider().getConnection();
//      connection = implementor.getConnectionProvider().getConnection();
//      //End Change - MPang - Defect 3439849 - 2016-05-23
//      String username = connection.getMetaData().getUserName();
//      String url = connection.getMetaData().getURL();
//      
//      CobolSession.setLogSessionStartEnd(false);
//      cmpcxmix=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpcxmix.class);
//      
//      cmpcxmix.getSession().getDbSession().setUpdateConnection(connection);
//      cmpcxmix.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//      
//      // set ZSTAT parameters
//
//      cmpcxmix.setProcessDttmProcessDt(getProcessDateTime().getDate().toString());
//      cmpcxmix.setProcessDttmSep("-");
//      cmpcxmix.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//      
//      if (session.isOnlineConnection()) { 
//          cmpcxmix.setConnectionFlg(CONNECTION_ONLINE);
//      }
//      else {
//          cmpcxmix.setConnectionFlg(CONNECTION_BATCH);
//      }
//      
//      cmpcxmix.setUserId(context.getUserId());
//      cmpcxmix.setZstatLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//          cmpcxmix.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//          cmpcxmix.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//          cmpcxmix.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//          
//      } else {
//          cmpcxmix.setSchedulerId(new BigDecimal(0).toBigDecimal());
//      }
//        
//        cmpcxmix.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmpcxmix.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmpcxmix.setSplHighValue(cmpcxmix.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmpcxmix.setSplLowValue(cmpcxmix.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//
//        cmpcxmix.setSplHighValue(cmpcxmix.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmpcxmix.setSplLowValue(cmpcxmix.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmpcxmix.setEnvInfoEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmpcxmix.setLkExpiryDt(Date.MAX.toString());
//        
//        cmpcxmix.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmpcxmix.setCallSeq(";");
//        cmpcxmix.setMessageAreaProgramName("CMPCXMIX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//          cmpcxmix.setRandomGenSeedSw(SWITCH_YES);
//          cmpcxmix.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//          cmpcxmix.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//          cmpcxmix.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//          cmpcxmix.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//          cmpcxmix.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//          cmpcxmix.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//          cmpcxmix.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//          cmpcxmix.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//          cmpcxmix.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//          cmpcxmix.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//          cmpcxmix.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//          cmpcxmix.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//          cmpcxmix.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//          cmpcxmix.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//          cmpcxmix.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }
//
//  }
    //End Delete - JVitug - SA-315895
    
}
