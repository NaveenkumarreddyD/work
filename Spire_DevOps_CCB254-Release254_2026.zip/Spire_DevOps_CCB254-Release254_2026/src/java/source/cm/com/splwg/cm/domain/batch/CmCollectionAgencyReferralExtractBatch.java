/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Collection Agency Referral Extract Batch
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                                                                
 * 2015-07-15  SMiran      Defect 3198240. Initial version
 * 2015-09-28  SMiran      SF-3311570. Change batch program
 * 						   - Removed ACCT_ID_HIGH and ACCT_ID_LOW parameters
 * 						   - Get CIS Division from CM_COLL_AGY_REF_STG_TMP 
 * 2016-01-27  MPang	   Updated for CCB v2.4 compilation.
 * 2016-05-27  EQuint	   Defect 3444457. Updated getjobwork and createworkunit  
 * 2021-06-15  EQuint      SA-368912. Add premise ID in staging table       
 * 2021-12-16  JHERNA      Mercury#47161 / B-20309. Add data status field                                                      
 *******************************************************************************
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
// 2015-09-28. SMiran. SF-3311570. Start Delete
//import com.splwg.ccb.domain.customerinfo.account.Account_Id;
// 2015-09-28. SMiran. SF-3311570. End Delete
//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
/*import com.splwg.cm.api.batch.CmCollectionAgencyReferralExtractRecord;
import com.splwg.cm.domain.creditcollections.writeOffProcess.CmCollectionAgencyReferralStaging;
import com.splwg.cm.domain.creditcollections.writeOffProcess.CmCollectionAgencyReferralStaging_Id;*/
import com.splwg.cm.api.batch.CmCollectionAgencyReferralExtractRecord;
import com.splwg.cm.domain.creditcollections.writeOffProcess.CmCollectionAgencyReferralStaging;
import com.splwg.cm.domain.creditcollections.writeOffProcess.CmCollectionAgencyReferralStaging_Id;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 90723
 *
@BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)})
 */
public class CmCollectionAgencyReferralExtractBatch extends
		CmCollectionAgencyReferralExtractBatch_Gen {
	
    // Constants
    private final String PARM_FILE_PATH = "File Path";
    private final String FILE_NAME_PLACE_HOLDER = "?";
	// 2015-09-28. SMiran. SF-3311570. Start Delete
	//private String accountIdLow = "";
	//private String accountIdHigh = "";
	// 2015-09-28. SMiran. SF-3311570. End Delete
    
    @Override
	public void validateSoftParameters(boolean isNewRun) {
        // Validate that File Path is a valid directory
        if (notBlank(getParameters().getFILE_PATH())){
            File tempPath = new File(getParameters().getFILE_PATH());
            if (!tempPath.isDirectory()){
                addError(CustomMessageRepositoryMGE.commBatchParameterIsNotValidFilePath(PARM_FILE_PATH, getParameters().getFILE_PATH()));
            }
        }
        // Validate if file name has a place holder for thread number (for multi-threaded run).
        if(getParameters().getThreadCount().intValue() > 1) {
        	if(!getParameters().getFILE_NAME().contains(FILE_NAME_PLACE_HOLDER)) {
        		addError(CustomMessageRepositoryMGE.sf3198240PlaceHolderMiss());
        	}
        }
	}

	public JobWork getJobWork() {
		
		// 2015-09-28. SMiran. SF-3311570. Start Delete
    	//accountIdLow = getParameters().getACCT_ID_LOW();
    	//accountIdHigh = getParameters().getACCT_ID_HIGH();
    	 
    	//if (isEmptyOrNull(accountIdLow)){
    	//	accountIdLow = "0000000000";
    	//}
    	//if (isEmptyOrNull(accountIdHigh)){
    	//	accountIdHigh = "9999999999";
    	//}
    	// 2015-09-28. SMiran. SF-3311570. Start Delete
    	 // Retrieve Staging Records
		
		/*
    	 * Start Change - EQuint - Defect 3444457 - 05-27-2016
    	 */
    	// Query<CmCollectionAgencyReferralStaging_Id> query = retrieveStagingRecords();
    	 
        // return createJobWorkForEntityIdQuery(query);
		
		// Start Update - EQuint - SA-368912 - 2021-06-15
//		PreparedStatement getMainPreparedStatement = createPreparedStatement(
//				"SELECT ACCT_ID, COLL_AGY_REF_ID_NEW FROM CM_COLL_AGY_REF_STG_TMP ", getClass().getName());
		PreparedStatement getMainPreparedStatement = createPreparedStatement(
				"SELECT ACCT_ID, COLL_AGY_REF_ID_NEW, PREM_ID FROM CM_COLL_AGY_REF_STG_TMP ", getClass().getName());
		// End Update - EQuint - SA-368912 - 2021-06-15
		
		QueryIterator iterator = getMainPreparedStatement.iterate();
		
		return createJobWorkForQueryIterator(iterator, this);	
		
		/*
    	 * End Change - EQuint - Defect 3444457 - 05-27-2016
    	 */
    }
    
	/*
	 * Start Delete - EQuint - Defect 3444457 - 05-27-2016
	 */
    // /**
    //  * This method will retrieve account
    //  * @return query
    //  */
    // private Query<CmCollectionAgencyReferralStaging_Id> retrieveStagingRecords() {
    // 	
    // 	StringBuilder strBuilder = new StringBuilder();
    // 	
    // 	strBuilder.append(" FROM CmCollectionAgencyReferralStaging stg ");
    // 	// 2015-09-28. SMiran. SF-3311570. Start Delete
    // 	//strBuilder.append(" WHERE stg.id.account.id >= :accountIdLow AND stg.id.account.id <= :accountIdHigh ");
    // 	// 2015-09-28. SMiran. SF-3311570. End Delete
    // 	//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
    // 	//Query<CmCollectionAgencyReferralStaging_Id> query = createQuery(strBuilder.toString());
    // 	Query<CmCollectionAgencyReferralStaging_Id> query = createQuery(strBuilder.toString(), getClass().getName());
    // 	//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
    // 	// 2015-09-28. SMiran. SF-3311570. Start Delete
    // 	//query.bindId("accountIdLow", new Account_Id(accountIdLow));
    // 	//query.bindId("accountIdHigh", new Account_Id(accountIdHigh));
    // 	// 2015-09-28. SMiran. SF-3311570. End Delete
    // 	
    // 	query.addResult("stgId", "stg.id");
    // 	
    // 	return query;
    // }
    /*
	 * End Delete - EQuint - Defect 3444457 - 05-27-2016
	 */

    @Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow queryResultRow) {
    	/*
    	 * Start Change - EQuint - Defect 3444457 - 05-27-2016
    	 */
    	// CmCollectionAgencyReferralStaging_Id stagingId = (CmCollectionAgencyReferralStaging_Id) queryResultRow.get("stgId");
    	String referralIdString = (String)queryResultRow.get("COLL_AGY_REF_ID_NEW");
    	CollectionAgencyReferral_Id referralId = new CollectionAgencyReferral_Id(referralIdString);
    	String acctIdString = (String)queryResultRow.get("ACCT_ID");
    	Account_Id id = new Account_Id(acctIdString);
    	// Start Update - EQuint - SA-368912 - 2021-06-15
    	// CmCollectionAgencyReferralStaging_Id stagingId = new CmCollectionAgencyReferralStaging_Id(referralId, id);
    	String premIdString = (String)queryResultRow.get("PREM_ID");
    	Premise_Id premId = new Premise_Id(premIdString);
    	CmCollectionAgencyReferralStaging_Id stagingId = new CmCollectionAgencyReferralStaging_Id(premId, referralId, id);
    	// End Update - EQuint - SA-368912 - 2021-06-15
    	/*
    	 * End Change - EQuint - Defect 3444457 - 05-27-2016
    	 */
    	
    	ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
    	threadWorkUnit.setPrimaryId(stagingId);
    	
    	return threadWorkUnit;
	}

	public Class<CmCollectionAgencyReferralExtractBatchWorker> getThreadWorkerClass() {
        return CmCollectionAgencyReferralExtractBatchWorker.class;
    }

    public static class CmCollectionAgencyReferralExtractBatchWorker extends
    	CmCollectionAgencyReferralExtractBatchWorker_Gen {
    	
        // Constant
    	private final String FILE_NAME_PLACE_HOLDER = "?";
    	
    	// Batch Parameters
        private String filePath;
        private String fileName;       
        
        // Work variables
        private File extractFile;
        private BufferedWriter extractFileWriter;
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }     

        @Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
        	
        	// Retrieve parameters
        	filePath = getParameters().getFILE_PATH();
        	fileName = getParameters().getFILE_NAME();
        	
            // Check if file name has place holder for thread number.
            if(fileName.contains(FILE_NAME_PLACE_HOLDER)) {
            	fileName = fileName.replace(FILE_NAME_PLACE_HOLDER, getBatchThreadNumber().toString().trim());
            }
        	
            // Open Extract File
            try {
            	extractFile = new File(filePath,fileName);   
            	extractFileWriter = new BufferedWriter(new FileWriter(extractFile));     
            }
            catch(Exception e) {
                e.printStackTrace();
                throw new RunAbortedException(CustomMessageRepositoryMGE.commGenericErrorOpeningFile(extractFile.getAbsolutePath()));
            }

		}

        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
        	
        	CmCollectionAgencyReferralStaging_Id stagingId = (CmCollectionAgencyReferralStaging_Id) unit.getPrimaryId();
        	CmCollectionAgencyReferralStaging stagingRecord = stagingId.getEntity();
        	
        	// Write Information to extract file
        	writeInformationToExtractFile(stagingRecord);

            return true;
        }
                        
        
        /**
         * This method will write information retrieved to extract file
         */
        private void writeInformationToExtractFile(CmCollectionAgencyReferralStaging stagingRecord) {
        	
        	CmCollectionAgencyReferralExtractRecord record = new CmCollectionAgencyReferralExtractRecord();
        	// 2015-09-28. SMiran. SF-3311570. Start Change
        	// Set Reference Id
        	//record.setReferenceId(stagingRecord.getId().getCmCollAgyRefIdOld());
        	record.setReferenceId("");
        	// Set Referral Id
        	//record.setReferralId(stagingRecord.getCmCollAgyRefIdNew().getId().getTrimmedValue());
        	record.setReferralId(stagingRecord.getId().getCmCollAgyRefIdNewId().getTrimmedValue());
        	// 2015-09-28. SMiran. SF-3311570. End Change
        	// Set Account Id
        	record.setAccountId(stagingRecord.getId().getAccountId().getTrimmedValue());
        	// Start Add - EQuint - SA-368912 - 2021-06-15
        	record.setPremiseId(stagingRecord.getId().getPremiseId().getTrimmedValue());
        	// End Add - EQuint - SA-368912 - 2021-06-15
        	// Set Collection Agency
        	record.setCollectionAgency(stagingRecord.getCollectionAgency());
        	// Set Date Placed
        	record.setDatePlaced(stagingRecord.getStartDate().toString().trim());
        	// Set WO Balance
        	record.setWoBalance(stagingRecord.getArrearsAmount().getAmount());
        	// 2015-09-28. SMiran. SF-3311570. Start Change
        	// Set CIS Division
        	//String cisDivisionStr = "";
        	//if (notNull(stagingRecord.getId().getAccount().getDivisionId())){
        	//	cisDivisionStr = stagingRecord.getId().getAccount().getDivisionId().getTrimmedValue();
        	//}
        	//record.setCisDivision(cisDivisionStr);
        	record.setCisDivision(stagingRecord.getDivisionId().getTrimmedValue());
        	// 2015-09-28. SMiran. SF-3311570. End Change
        	// START ADD - JHERNA - 2021-12-16 - Mercury#47161
        	record.setDataStatus(stagingRecord.getDataStatus());
        	// END ADD - JHERNA - 2021-12-16 - Mercury#47161
            try {
            	extractFileWriter.write(record.createRecordString());
            	extractFileWriter.newLine();
            }
            catch (Exception e) {
                e.printStackTrace();
                throw new RunAbortedException(CustomMessageRepositoryMGE.commGenericErrorWritingToFile(extractFile.getAbsolutePath()));
            }
        }       

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException,
				RunAbortedException {
            // Close Extract File
            try {
            	extractFileWriter.close();    
            }
            catch(Exception e) {
                e.printStackTrace();
                throw new RunAbortedException(CustomMessageRepositoryMGE.commGenericErrorClosingFile(extractFile.getAbsolutePath()));
            }
		}            
    }
}
