/**************************************************************************
* Program Name: CmCheckfreeDeenrollBatch
* Program Title: CmCheckfreeDeenrollBatch
* Author: Sharmayne Felipe
* Creation Date: 2017-04-17
* Purpose: This Batch program will create the Checkfree deenrollment file  
*          to be transmitted to Kubra.
* Functional Spec: CCB-CC-005.7
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  CCB-CC-005.7      Sharmayne Felipe 2017-04-17    Initial Version
 ************************************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author Administrator
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CHECKFREE_EBILL_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = PENDING_DEACTIVATION_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = DEACTIVATED_CHAR_VAL, required = true, type = string)})
 */
public class CmCheckfreeDeenrollBatch extends CmCheckfreeDeenrollBatch_Gen {
    
    // Batch parameters
    private String filePath;
    private CharacteristicType checkfreeEbillCharType;
    private String pendingDeactivationCharVal;
    private String deactivatedCharVal;
    
    /**
     * This method will contain the logic used to validate the batch soft parameters.
     * @param boolean
     */
    public void validateSoftParameters(boolean isNewRun) {
       
        filePath = getParameters().getFILE_PATH();
        checkfreeEbillCharType = getParameters().getCHECKFREE_EBILL_CHAR_TYPE();
        pendingDeactivationCharVal = getParameters().getPENDING_DEACTIVATION_CHAR_VAL();
        deactivatedCharVal = getParameters().getDEACTIVATED_CHAR_VAL();
        
        // Validate that the file path is valid.
        File folder = new File(filePath);

        if (!(folder.exists() && folder.isDirectory())) {
            addError(CustomMessageRepository.CC_005_7_FilePathInvalid(filePath));          
        }
        
        // Validate that the Checkfree Ebill Characteristic Type is valid for the Account entity.
        CharacteristicEntity checkFreeCharEntity = new CharacteristicEntity_Id(checkfreeEbillCharType, 
                CharacteristicEntityLookup.constants.ACCOUNT).getEntity();
        
        if(isNull(checkFreeCharEntity)) {
            addError(CustomMessageRepository.CC_005_7_InvalidForEntity(checkfreeEbillCharType.getId().getTrimmedValue(), 
                    CharacteristicEntityLookup.constants.ACCOUNT.getLookupValue().fetchLanguageDescription()));
        }
        
        // Validate that the Pending Deactivation Char Value is valid for the Checkfree Ebill Characteristic Type.
        CharacteristicValue checkFreeCharVal = new CharacteristicValue_Id(checkfreeEbillCharType, 
                pendingDeactivationCharVal).getEntity();
        
        if(isNull(checkFreeCharVal)) {
            addError(CustomMessageRepository.CC_005_7_InvalidValueForCharType(
                    checkfreeEbillCharType.getId().getTrimmedValue(), pendingDeactivationCharVal));
        }
        
        // Validate that the Deactivated Char Value is valid for the Checkfree Ebill Characteristic Type.
        checkFreeCharVal = new CharacteristicValue_Id(checkfreeEbillCharType, 
                deactivatedCharVal).getEntity();
        
        if(isNull(checkFreeCharVal)) {
            addError(CustomMessageRepository.CC_005_7_InvalidValueForCharType(
                    checkfreeEbillCharType.getId().getTrimmedValue(), deactivatedCharVal));
        }
    }
    
    /**
     * This method will retrieve all Accounts that will be processed by the Batch program.
     */
    public JobWork getJobWork() {
        
        // Retrieve all Accounts with effective Checkfree Ebill Characteristic Type with value equal to Y.
        StringBuilder getAccountsSb = new StringBuilder();
        getAccountsSb.append("SELECT AC.ACCT_ID ");
        getAccountsSb.append("FROM CI_ACCT_CHAR AC ");
        getAccountsSb.append("WHERE AC.CHAR_TYPE_CD =:checkFreeCharType ");
        getAccountsSb.append("AND AC.SRCH_CHAR_VAL =:pendingDeactivationCharVal ");
        getAccountsSb.append("AND AC.EFFDT = (SELECT MAX(AC2.EFFDT) ");
        getAccountsSb.append("                FROM CI_ACCT_CHAR AC2 ");
        getAccountsSb.append("                WHERE AC2.ACCT_ID = AC.ACCT_ID ");
        getAccountsSb.append("                AND AC2.CHAR_TYPE_CD = AC.CHAR_TYPE_CD ");
        getAccountsSb.append("                AND AC2.EFFDT <=:processDate) ");
        
        PreparedStatement getAccounts = createPreparedStatement(getAccountsSb.toString(), getClass().getName());
        getAccounts.bindEntity("checkFreeCharType", checkfreeEbillCharType);
        getAccounts.bindStringProperty("pendingDeactivationCharVal", AccountCharacteristic.properties.searchCharacteristicValue, 
                pendingDeactivationCharVal);
        getAccounts.bindDate("processDate", getProcessDateTime().getDate());
        
        // Build the Worklist
        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
        
        QueryIterator<SQLResultRow> iter = getAccounts.iterate();
        
        while (iter.hasNext()) {
            SQLResultRow row = iter.next();
            
            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId((Account_Id) row.getId("ACCT_ID", Account.class));
            workUnits.add(workUnit);              
        }
        iter.close();  
     
        return createJobWorkForThreadWorkUnitList(workUnits);  
    }

    /**
     * This method will return the Batch Worker class.
     */
    public Class<CmCheckfreeDeenrollBatchWorker> getThreadWorkerClass() {
        return CmCheckfreeDeenrollBatchWorker.class;
    }

    /**
     * Inner Class
     * @author Administrator
     */
    public static class CmCheckfreeDeenrollBatchWorker extends
            CmCheckfreeDeenrollBatchWorker_Gen {
        
        // Constants
        private static final String DELIMITER = "|";
        private static final String HEADER = "H";
        private static final String DETAIL = "D";
        private static final String TRAILER = "T";
        private static final String CHG_REQ = "CHG_REQ";
        private static final String I = "I";
        private static final String CHECKFREE = "CHECKFREE";
        private static final String DATE_FORMAT = "yyyyMMdd";
        private static final String FILE_EXTENSION = ".txt";
        
        // Batch parameters
        private String filePath;
        private String fileName;
        private CharacteristicType checkfreeEbillCharType;
        private String deactivatedCharVal;
        
        // Work variables
        private File file;
        private BufferedWriter outputWriter;
        private BigInteger recordCounter;

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

        /** 
         * Base method which is invoked once per thread (executed before the main processing).
         */
        public void initializeThreadWork(boolean initializationPreviouslySuccessful)
                throws ThreadAbortedException, RunAbortedException {
            
            // Retrieve the Batch parameters.
            filePath = getParameters().getFILE_PATH();
            fileName = getParameters().getFILE_NAME();
            checkfreeEbillCharType = getParameters().getCHECKFREE_EBILL_CHAR_TYPE();
            deactivatedCharVal = getParameters().getDEACTIVATED_CHAR_VAL();
            
            // Check if the file name parameter has an extension. If none is found, append extension.
            if(fileName.lastIndexOf(".") == -1){
                fileName = fileName.concat(FILE_EXTENSION);
            }
            
            // Initialize counter.
            recordCounter = BigInteger.ZERO;
            
            // Open file.
            file = new File(filePath, fileName);            
            
            try {
                outputWriter = new BufferedWriter(new FileWriter(file));
            } catch (IOException ioe) {
                addError(CustomMessageRepository.CC_005_7_FileOpenError(file.toString()));
            }
            
            // Write the header record.
            writeLine(HEADER.concat(DELIMITER).concat(CHG_REQ).concat(DELIMITER).concat(
                    getProcessDateTime().getDate().toString(new DateFormat(DATE_FORMAT))));
        }

        /**
         * This method contains the main processing of the program. 
         */
        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
            
            Account_Id accountId = (Account_Id)unit.getPrimaryId();
            
            // Write the detailed record.
            writeLine(DETAIL.concat(DELIMITER).concat(I).concat(DELIMITER).concat(
                    accountId.getTrimmedValue().concat(DELIMITER).concat(DELIMITER).concat(CHECKFREE)));
            
            // Update the Checkfree Characteristic of the Account.
            updateAccountChar(accountId, checkfreeEbillCharType, deactivatedCharVal);
            
            // Add one to the counter.
            recordCounter = recordCounter.add(BigInteger.ONE);
            
            return true;
        }
        
        /**
         * This method will write the input string to the file.
         * @param recordLine
         */
        private void writeLine(String recordLine){   
            
            try {
                outputWriter.write(recordLine);
                outputWriter.newLine();
            } catch (IOException e) {
                addError(CustomMessageRepository.CC_005_7_FileWriteError(file.toString()));
            }
        }
        
        /**
         * This method will update the Characteristic value of an Account.
         * @param accountId
         * @param charType
         * @param charVal
         */
        private void updateAccountChar(Account_Id accountId, CharacteristicType charType, String charVal) {
            
            AccountCharacteristic accountChar = accountId.getEntity().getEffectiveCharacteristicAsOfDate(
                    charType, getProcessDateTime().getDate());
            AccountCharacteristic_DTO accountCharDto = accountChar.getDTO();
            
            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
            
            if (charTypeLookup.isAdhocValue() 
                    || charTypeLookup.isFileLocationValue()) {
                accountCharDto.setAdhocCharacteristicValue(charVal.trim());
            } 
            else if (charTypeLookup.isPredefinedValue()) {
                accountCharDto.setCharacteristicValue(charVal.trim());
            }
            else if (charTypeLookup.isForeignKeyValue()) {
                accountCharDto.setCharacteristicValueForeignKey1(charVal.trim());
            }
            
            accountChar.setDTO(accountCharDto);
        }

        /**
         * Base method which is called at the end after processing all records for each thread.
         */
        public void finalizeThreadWork() throws ThreadAbortedException,
                RunAbortedException {
            
            String recordCounterStr = String.format("%06d", recordCounter);
           
            // Write the Trailer record.
            writeLine(TRAILER.concat(DELIMITER).concat(recordCounterStr));
            
            // Close the file.
            try {
                outputWriter.close();
            }
            catch (Exception e) {
                addError(CustomMessageRepository.CC_005_7_FileCloseError(file.toString()));
            }
        }
    }
}
