/*
 **************************************************************************
 *                Confidentiality Information:
 *
 * This module is the confidential and proprietary information of
 * Oracle Corporation; it is not to be copied, reproduced, or
 * transmitted in any form, by any means, in whole or in part,
 * nor is it to be used for any purpose other than that for which
 * it is expressly provided without the written permission of
 * Oracle Corporation.
 *
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Eligible Major Pledge Funding Types Lookup
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 * 
 * 2013-04-03   FMedin      NI0026.3. Initial Version.  
 * *************************************************************************                
 */

package com.splwg.cm.api.lookup;

/**
 * @author FFMEDINA
 *
 @LookupFieldname (value = XMPF_OPT_TYP_FLG)
 */
public class CmEligibleMajorPledgeFundingTypesLookup_Impl  extends
        CmEligibleMajorPledgeFundingTypesLookup_Gen {

}
