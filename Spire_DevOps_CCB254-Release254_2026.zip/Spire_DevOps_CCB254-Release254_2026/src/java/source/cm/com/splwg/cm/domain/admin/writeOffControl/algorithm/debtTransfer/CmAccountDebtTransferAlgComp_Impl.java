/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm will attempt to transfer debt in the following order:
 *   1. Active billable SA in same WO Debt Class
 *   2. Overpayment SA on Account
 *   3. (If Transfer Balance Switch is Y) Other Stopped SA
 * 
 * Attempt to transfer credit in the following order:
 *   1. Active SAs with debt
 *   2. (On inactive Accounts) WO SAs
 *   3. Existing Overpayment SA
 *   4. New Overpayment SA
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *   
 * 2020-08-31   BMarquez    CCB009.4/D-02142. Initial version.
 *              AVitug
 * *************************************************************************                
 */
package com.splwg.cm.domain.admin.writeOffControl.algorithm.debtTransfer;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.CustomerReadLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.writeOffControl.algorithm.debtTransfer.DebtTransferAlgorithmSpot;
import com.splwg.ccb.domain.admin.writeOffDebtClass.entity.WriteOffDebtClass;
import com.splwg.ccb.domain.admin.writeOffDebtClass.entity.WriteOffDebtClass_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ServerMessage;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = doNotTransferCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = doNotTransferCharacteristicValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = overpaymentSATypeCode, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = role, name = toDoRole, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = transferAdjustmentTypeSameAccount, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = transferBalanceSwitch, type = boolean)
 *            , @AlgorithmSoftParameter (name = writeOffDebtClasses, type = string)})
 */
public class CmAccountDebtTransferAlgComp_Impl
        extends CmAccountDebtTransferAlgComp_Gen
        implements DebtTransferAlgorithmSpot {
    
    // Hard Parameters
    private Bool areSAsClosed = Bool.FALSE;
    private ServiceAgreement woServiceAgreement;
    private WriteOffDebtClass woDebtClass;
    private Money woDebtClassTotalBalance;

    // Soft Parameters
    private CharacteristicType parmDoNotTransferCharType;
    private String parmDoNotTransferCharValue;
    private String parmOverpaymentSATypeCode;
    private ToDoType parmToDoType;
    private Role parmToDoRole;
    private AdjustmentType parmAdjustmentTypeForSameAccount;
    private Bool parmTransferBalanceSw;

    // Work Variables
    private Account woAccount;
    private Money woSaBalance;
    private String woDebtClassesInQuotes = "";
    
    //Constants
    private static final String COMMA = ",";
    
    Logger logger = LoggerFactory.getLogger(getClass().getName());
    
    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        
        // Retrieve Soft Parameters
        parmDoNotTransferCharType = getDoNotTransferCharacteristicType();
        parmDoNotTransferCharValue = getDoNotTransferCharacteristicValue();
        parmOverpaymentSATypeCode = getOverpaymentSATypeCode();
        parmToDoType = getToDoType();
        parmToDoRole = getToDoRole();
        parmAdjustmentTypeForSameAccount = getTransferAdjustmentTypeSameAccount();
        parmTransferBalanceSw = getTransferBalanceSwitch();
        String woDebtClasses = getWriteOffDebtClasses();

        // Validate the Do Not Transfer Characteristic Type
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(parmDoNotTransferCharType, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT);
        if(isNull(charEntityId.getEntity())){
            addError(CustomMessageRepositorySpireOne.CCB009_4_algParmInvalidCharacteristTypeForEntity(
                    getAlgorithmId().getTrimmedValue(),
                    getAlgorithm().getAlgorithmType().getParameterAt(0).fetchLanguageParameterLabel(),
                    parmDoNotTransferCharType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().fetchLanguageDescription().trim()));
        }
        charEntityId = new CharacteristicEntity_Id(parmDoNotTransferCharType, CharacteristicEntityLookup.constants.ACCOUNT);
        if(isNull(charEntityId.getEntity())){
            addError(CustomMessageRepositorySpireOne.CCB009_4_algParmInvalidCharacteristTypeForEntity(
                    getAlgorithmId().getTrimmedValue(),
                    getAlgorithm().getAlgorithmType().getParameterAt(0).fetchLanguageParameterLabel(),
                    parmDoNotTransferCharType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.ACCOUNT.getLookupValue().fetchLanguageDescription().trim()));
        }
        charEntityId = new CharacteristicEntity_Id(parmDoNotTransferCharType, CharacteristicEntityLookup.constants.PERSON);
        if(isNull(charEntityId.getEntity())){
            addError(CustomMessageRepositorySpireOne.CCB009_4_algParmInvalidCharacteristTypeForEntity(
                    getAlgorithmId().getTrimmedValue(),
                    getAlgorithm().getAlgorithmType().getParameterAt(0).fetchLanguageParameterLabel(),
                    parmDoNotTransferCharType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.PERSON.getLookupValue().fetchLanguageDescription().trim()));
        }

        // Validate the Do Not Transfer Characteristic Value
        if (parmDoNotTransferCharType.getCharacteristicType().isPredefinedValue()){
            CharacteristicValue_Id charValueId = new CharacteristicValue_Id(parmDoNotTransferCharType, parmDoNotTransferCharValue);

            if (isNull(charValueId.getEntity())) {
                addError(CustomMessageRepositorySpireOne.CCB009_4_algParmInvalidCharacteristValueForCharacteristicType(
                        getAlgorithmId().getTrimmedValue(),
                        getAlgorithm().getAlgorithmType().getParameterAt(0).fetchLanguageParameterLabel(),
                        parmDoNotTransferCharValue.trim(),
                        parmDoNotTransferCharType.getId().getTrimmedValue()));
            }
        }

        // Validate the To Do Role against the To Do Type
        if (notNull(parmToDoRole)) {
            ToDoTypeRole_Id toDoTypeRoleId = new ToDoTypeRole_Id(parmToDoType, parmToDoRole);

            if (isNull(toDoTypeRoleId.getEntity())) {
                addError(CustomMessageRepositorySpireOne.CCB009_4_algParmInvalidRoleForToDoType(
                        getAlgorithmId().getTrimmedValue(),
                        getAlgorithm().getAlgorithmType().getParameterAt(5).fetchLanguageParameterLabel(),
                        parmToDoRole.getId().getTrimmedValue(),
                        parmToDoType.getId().getTrimmedValue()));
            }
        } else {
            parmToDoRole = parmToDoType.getDefaultRole().fetchIdToDoRole();
        }
        
        // Default the Transfer Balance Switch if not provided
        if (isNull(parmTransferBalanceSw)){
            parmTransferBalanceSw = Bool.FALSE;
        }
        
        // Validate the write off debt classes in the writeOffDebtClasses algorithm parameter if supplied
        if(!isBlankOrNull(woDebtClasses)) {
            String[] woDebtClassArray = woDebtClasses.split(COMMA);
            for(int index = 0 ; index < woDebtClassArray.length ; index++) {
                WriteOffDebtClass_Id woDebtClass = new WriteOffDebtClass_Id(woDebtClassArray[index]);
                
                if(isNull(woDebtClass.getEntity())) {
                    addError(CustomMessageRepositorySpireOne.CCB009_4_writeOffDebtClassIsInvalid(getAlgorithmId().getTrimmedValue(), 
                            getAlgorithm().getAlgorithmType().getParameterAt(9).fetchLanguageParameterLabel(), 
                            woDebtClassArray[index]));
                }
            }
        }
        
        //Enclose each WO Debt class in the Algorithm WO debt class parameter 
        //in quotes if the WO Debt classes were supplied
        if(!isBlankOrNull(woDebtClasses)) {
            StringBuilder woDebtClassStringBuilder = new StringBuilder();
            String[] woDebtClassArray = woDebtClasses.split(COMMA);
            
            woDebtClassStringBuilder.append("'");

            for (int i = 0; i < woDebtClassArray.length; i++){
                woDebtClassStringBuilder.append(woDebtClassArray[i] + "'");
                if (i < woDebtClassArray.length - 1) {
                    woDebtClassStringBuilder.append(",'");
                }
            }
            woDebtClassesInQuotes = woDebtClassStringBuilder.toString();
        }
        
        
    }

    @Override
    public Bool getAreServiceAgreementsClosed() {
        return areSAsClosed;
    }

    @Override
    public void setServiceAgreement(ServiceAgreement sa) {
        this.woServiceAgreement = sa;
    }

    @Override
    public void setWriteOffDebtClass(WriteOffDebtClass woDebtClass) {
        this.woDebtClass = woDebtClass;
    }

    @Override
    public void setWriteOffDebtClassTotalBalance(Money money) {
        this.woDebtClassTotalBalance = money;
    }

    @Override
    public void invoke() { 
        
        woAccount = woServiceAgreement.getAccount();
        woSaBalance = woServiceAgreement.getFinancialBalances().getTotalAmount();
        
        logger.debug("Account being processed : " + woAccount);
        logger.debug("SA being processed : " + woServiceAgreement.getId() + " SA Type : " + woServiceAgreement.getServiceAgreementType().getId().getSaType());
        
        // Validate the SA Type Code Parameter
        CisDivision cisDivision = woServiceAgreement.getServiceAgreementType().getId().getDivision();
        ServiceAgreementType_Id overpaymentSATypeId = new ServiceAgreementType_Id(cisDivision, parmOverpaymentSATypeCode);
        if (isNull(overpaymentSATypeId.getEntity())){
            addError(CustomMessageRepositorySpireOne.CCB009_4_algParmInvalidSATypeForCISDivision(
                    getAlgorithmId().getTrimmedValue(),
                    getAlgorithm().getAlgorithmType().getParameterAt(3).fetchLanguageParameterLabel(),
                    parmOverpaymentSATypeCode,
                    cisDivision.getId().getTrimmedValue()));
        }
        
        if (hasExistingRefundToDoEntry().isTrue()){ 
            return;
        }

        if (woSaBalance.isGreaterThan(Money.ZERO)){
            
            processDebitBalance();
            
        } else {
            
            processCreditBalance();
            
        }
        
    }

    /**
     * This method determines the processing for the WO SA's debit balance
     */
    private void processDebitBalance(){
        
        // Transfer debt to another active SA
        List<ServiceAgreement> otherSAsList = retrieveOtherAccountSAs(
                woAccount,
                ServiceAgreementStatusLookup.constants.ACTIVE,
                ServiceAgreementStatusLookup.constants.PENDING_STOP);
        
        if (!otherSAsList.isEmpty()){
            createXferAdjustment(otherSAsList.get(0), woServiceAgreement.getPayoffBalance());
            areSAsClosed = Bool.TRUE;
            return;
        }
        
        // Transfer credit from another stopped SA
        List<ServiceAgreement> otherStoppedSAsList = retrieveOtherAccountSAs(
                woAccount,
                ServiceAgreementStatusLookup.constants.STOPPED,
                ServiceAgreementStatusLookup.constants.REACTIVATED);
        
        for (ServiceAgreement otherStoppedSa : otherStoppedSAsList) {
            
            Money creditBalance = otherStoppedSa.getPayoffBalance();
            if (creditBalance.isPositive()) {
                continue;
            }
            
            // If the absolute balance of Stopped SA is larger than the absolute balance of the SA with debt
            if (woSaBalance.isLessThanOrEqual(creditBalance.negate())) {
                // Transfer full debt to Stopped SA
                createXferAdjustment(otherStoppedSa, woSaBalance);
                areSAsClosed = Bool.TRUE;
                return;
            } else {
                // Transfer debt equal to the balance of the Stopped SA
                createXferAdjustment(otherStoppedSa, creditBalance.negate());
            }
            
        }
        
        // Transfer credit from an Overpayment SA
        List<ServiceAgreement> overpaymentSaList = retrieveOverpaymentSAs(woAccount);
        for (ServiceAgreement overpaymentSa : overpaymentSaList) {
            
            Money creditBalance = overpaymentSa.getPayoffBalance();
            if (creditBalance.isPositive()) {
                continue;
            }
            
            // If the absolute balance of Overpayment SA is larger than the absolute balance of the SA with debt
            if (woSaBalance.isLessThanOrEqual(creditBalance.negate())) {
                // Transfer full debt to Overpayment SA
                createXferAdjustment(overpaymentSa, woSaBalance);
                areSAsClosed = Bool.TRUE;
                return;
            } else {
                // Transfer debt equal to the balance of the Overpayment SA
                createXferAdjustment(overpaymentSa, creditBalance.negate());
            }
            
        }
        
        if (parmTransferBalanceSw.isFalse()) {
            // Do not consolidate SA debt
            return;
        }
        
        // Transfer all SA debt to an open SA
        List<ServiceAgreement> stoppedSAsList;
        stoppedSAsList = retrieveOtherAccountSAs(woAccount, ServiceAgreementStatusLookup.constants.STOPPED);
        
        for (ServiceAgreement stoppedSA : stoppedSAsList) {
            ServiceAgreementType stoppedSaType = stoppedSA.getServiceAgreementType();
            if (stoppedSA.determineEligibilityForWriteOff(stoppedSaType.getSpecialRole(),
                    stoppedSaType.getIsSubServiceAgreement(),
                    stoppedSaType.getIsEligibleForBilling()).isFalse()) {

                if (stoppedSA.getPayoffBalance().isPositive()) {
                    
                    createXferAdjustment(stoppedSA, woSaBalance);
                    areSAsClosed = Bool.TRUE;
                    return;
                    
                } else {
                    
                    Money creditBalance = stoppedSA.getPayoffBalance();
                    
                    // If the absolute balance of the other SA is larger than the absolute balance of the SA with debt
                    if (woSaBalance.isLessThanOrEqual(creditBalance.negate())) {
                        // Transfer full debt
                        createXferAdjustment(stoppedSA, woSaBalance);
                        areSAsClosed = Bool.TRUE;
                        return;
                    } else {
                        // Transfer debt equal to the balance of the credit
                        createXferAdjustment(stoppedSA, creditBalance.negate());
                    }
                    
                }
                
            }
        }

    }
    
    /**
     * This method processes the credit balance for an active account 
     */    
    private void processCreditBalance(){
        ServiceAgreementCharacteristic saDNTChar = woServiceAgreement.getEffectiveCharacteristic(parmDoNotTransferCharType);
        if (notNull(saDNTChar) && saDNTChar.getSearchCharacteristicValue().equalsIgnoreCase(parmDoNotTransferCharValue.trim())){
            createToDo(CustomMessageRepositorySpireOne.CCB009_4_ToDoErrorServiceAgreementHasDoNotTransfer(
                    woSaBalance.getAmount().abs().toString(),
                    woServiceAgreement.getId().getTrimmedValue()));
            return;
        }
        
        List<ServiceAgreement> otherActiveSAsList = retrieveOtherAccountSAs(
                woAccount,
                ServiceAgreementStatusLookup.constants.ACTIVE,
                ServiceAgreementStatusLookup.constants.PENDING_STOP);
        
        for (ServiceAgreement otherSA : otherActiveSAsList) {
            
            Money debtBalance = otherSA.getPayoffBalance();
            
            if (debtBalance.isPositive()) {
                if (debtBalance.isLessThanOrEqual(woSaBalance.negate())) {
                    createXferAdjustment(otherSA, debtBalance.negate());
                } else {
                    createXferAdjustment(otherSA, woSaBalance);
                    areSAsClosed = Bool.TRUE;
                    return;
                }
            }
            
        }
        
        // If the Account is inactive, credit can be transferred to other valid WO Debt Classes with debt
        if (isAccountActive(woAccount).isFalse()) {
            Money remainingBalance = woServiceAgreement.getPayoffBalance();
            
            List<ServiceAgreement> otherSAsList = retrieveOtherSAOfAccountWithDifferentWO(woAccount);
            for (ServiceAgreement otherSA : otherSAsList) {
                
                Money debtBalance = otherSA.getPayoffBalance();
                if (debtBalance.isPositive()) {
                    if (debtBalance.isLessThanOrEqual(remainingBalance.negate())) {
                        createXferAdjustment(otherSA, debtBalance.negate());
                        remainingBalance = remainingBalance.subtract(debtBalance.negate());
                    } else {
                        createXferAdjustment(otherSA, remainingBalance);
                        areSAsClosed = Bool.TRUE;
                        return;
                    }
                }
                
            }
            
        }
        
        // Otherwise, put the credit on an overpayment
        List<ServiceAgreement> overpaymentSaList = retrieveOverpaymentSAs(woAccount);
        if (!overpaymentSaList.isEmpty()) {
            createXferAdjustment(overpaymentSaList.get(0), woServiceAgreement.getPayoffBalance());
            areSAsClosed = Bool.TRUE;
        } else {
            createXferAdjustment(createOverpaymentSA(woAccount), woServiceAgreement.getPayoffBalance());
            areSAsClosed = Bool.TRUE;
        }
        
    }
    
    /**
     * This method creates the transfer adjustment between the appropriate SAs 
     * @param xferSA
     */
    private void createXferAdjustment(ServiceAgreement xferSA, Money amount) {
        CreateFrozenAdjustmentData data = CreateFrozenAdjustmentData.Factory.newInstance();
        data.setServiceAgreement(woServiceAgreement);
        data.setTransferServiceAgreement(xferSA);
        data.setAdjustmentType(parmAdjustmentTypeForSameAccount);
        data.setAdjustmentAmount(amount);
        data.setAllowZeroAmount(Bool.FALSE);
        woServiceAgreement.createFrozenAdjustment(data);
        
        woSaBalance = woSaBalance.subtract(amount.negate());
    }

    /**
     * This method creates the appropriate To Do Entry 
     * @param serverMessage
     */
    private void createToDo(ServerMessage serverMessage){ 
        // Create the To Do
        ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
        ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();
        toDoEntryDTO.setCreationDateTime(getProcessDateTime());
        toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
        toDoEntryDTO.setToDoTypeId(parmToDoType.getId());
        toDoEntryDTO.setToDoRoleId(parmToDoRole.getId());
        toDoEntryDTO.setMessageId(serverMessage.getMessageId());
        toDoCreator.setToDoDTO(toDoEntryDTO);

        // Add Drill Key
        Iterator<ToDoDrillKeyType> itrToDoDrillKeyType = parmToDoType.getId().getEntity().getDrillKeyTypes().iterator();
        while (itrToDoDrillKeyType.hasNext()){
            ToDoDrillKeyType drillKeyType = itrToDoDrillKeyType.next();
            toDoCreator.addDrillKeyValue(drillKeyType, woServiceAgreement.getId().getTrimmedValue());
        }

        // Add Sort Keys
        for (ToDoSortKeyType sortKeyType : parmToDoType.getSortKeyTypes()) {
            BigInteger sequence = sortKeyType.fetchIdSequence();
            // Sort Key - Credit Refund Amount
            if (sequence.compareTo(BigInteger.valueOf(10)) == 0) { 
                toDoCreator.addSortKeyValue(sortKeyType, woSaBalance.getAmount().abs().toString());
            }

            // Sort Key - Error Message Number
            if (sequence.compareTo(BigInteger.valueOf(20)) == 0) { 
                toDoCreator.addSortKeyValue(sortKeyType, serverMessage.getNumber().toString());
            }
        }

        // Add Message Parameters
        for (int index = 0; index < serverMessage.getMessageParameters().getSize(); index++){
            toDoCreator.addMessageParameter(serverMessage.getMessageParameters().getParameters().get(index).toString());
        }

        // Create the To Do Entry
        toDoCreator.create(); 
    }

    /**
     * This method creates an overpayment SA for the account 
     * @param account
     * @return ServiceAgreement_DTO
     */
    private ServiceAgreement createOverpaymentSA(Account account){
        ServiceAgreementType_Id overpaymentSaTypeId = new ServiceAgreementType_Id(account.getDivisionId(), parmOverpaymentSATypeCode);
        ServiceAgreement_DTO overpaymentSaDto = new ServiceAgreement_DTO();
        overpaymentSaDto.setAccountId(account.getId());
        overpaymentSaDto.setServiceAgreementTypeId(overpaymentSaTypeId);
        overpaymentSaDto.setStatus(ServiceAgreementStatusLookup.constants.PENDING_START);
        overpaymentSaDto.setStartDate(getProcessDateTime().getDate());
        overpaymentSaDto.setCustomerRead(CustomerReadLookup.constants.NO);
        
        return overpaymentSaDto.newEntity();
    }
    
    private String encloseSATypesInQuotes(ServiceAgreementStatusLookup... saStatusList){
        StringBuilder saStatuses = new StringBuilder();

        saStatuses.append("'");

        for (int i = 0; i < saStatusList.length; i++){
            saStatuses.append(saStatusList[i] + "'");
            if (i < saStatusList.length - 1) {
                saStatuses.append(",'");
            }
        }
        return saStatuses.toString();
    }

    /**
     * This method checks if there are other active SAs for the account 
     * @param account
     * @return Bool
     */
    private Bool isAccountActive(Account account){
        Query<ServiceAgreement> query = createQuery("FROM ServiceAgreement SA "
                + "WHERE SA.status IN (:activeStatus, :pendingStopStatus) "
                + "AND SA.account = :account "
                + "AND SA.id <> :saId ",
                "isAccountActive");
        query.bindEntity("account", account);
        query.bindId("saId", woServiceAgreement.getId());
        query.bindLookup("activeStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
        query.bindLookup("pendingStopStatus", ServiceAgreementStatusLookup.constants.PENDING_STOP);

        query.addResult("sa", "SA");
        if (notNull(query.firstRow())) {
            return Bool.TRUE;
        }
        
        return Bool.FALSE;
    }

    /**
     * This method retrieves other SAs of the account 
     * @param account
     * @param saStatList
     * @return saList
     */
    private List<ServiceAgreement> retrieveOtherAccountSAs(Account account, ServiceAgreementStatusLookup... saStatList) {
        List<ServiceAgreement> saList = new ArrayList<>();

        String saStatusesInQuotes = encloseSATypesInQuotes(saStatList);

        Query<QueryResultRow> query = createQuery("FROM ServiceAgreement SA, ServiceAgreementType SAT "
                + "WHERE SA.status IN (" + saStatusesInQuotes + ") "
                + "AND SA.account.id = :accountId "
                + "AND SA.serviceAgreementType.id.division = SAT.id.division  "
                + "AND SA.serviceAgreementType.id.saType = SAT.id.saType "
                + "AND SAT.writeOffDebtClass.id = :woDebtClassCode "
                + "AND SA.id <> :saId "
                
                + "AND SAT.paymentPriority IS NOT NULL  ",
                "retrieveOtherAccountSAs");

        query.bindId("accountId", account.getId());
        query.bindId("woDebtClassCode", woDebtClass.getId());
        query.bindId("saId", woServiceAgreement.getId());
        
        query.addResult("sa", "SA");
        query.addResult("paymentPriority", "SAT.paymentPriority");
        query.orderBy("paymentPriority");

        for(QueryResultRow resultRow : query.list()) {
            saList.add(resultRow.getEntity("sa", ServiceAgreement.class));
        }

        return saList;
    }
    
    /**
     * This method checks if the SA has an open Refund To Do Entry
     * @return Bool
     */
    private Bool hasExistingRefundToDoEntry(){
        Bool refundToDoExists = Bool.FALSE;
        Query<ToDoEntry> query = createQuery("FROM ServiceAgreement SA, ToDoEntry TDE, ToDoDrillKeyValue TDK "
                + "WHERE SA.id = :saId "
                + "AND SA.id = TDK.keyValue "
                + "AND TDK.id.toDo = TDE.id "
                + "AND TDE.toDoType = :toDoType "
                + "AND TDE.toDoEntryStatus <> :completedStatus",
                "hasExistingRefundToDoEntry");
        query.bindId("saId", woServiceAgreement.getId());
        query.bindId("toDoType", parmToDoType.getId());
        query.bindLookup("completedStatus", ToDoEntryStatusLookup.constants.COMPLETED);
        query.addResult("toDoEntry", "TDE");

        if (notNull(query.firstRow())) {
            refundToDoExists = Bool.TRUE;
        }
        return refundToDoExists;

    }
    
    /**
     * This method retrieves all overpayment SAs for the account
     * @param account
     * @return ServiceAgreement
     */
    private List<ServiceAgreement> retrieveOverpaymentSAs(Account account){
        
        Query<ServiceAgreement> query = createQuery("FROM ServiceAgreement SA "
                + "WHERE SA.status NOT IN (:closedStatus, :cancelledStatus) "
                + "AND SA.account = :accountId "
                + "AND SA.serviceAgreementType.id.saType = :overpaymentSaType "
                + "AND SA.serviceAgreementType.id.division = :cisDivisionId  "
                + "AND SA.id <> :saId ",
                "retrieveOverpaymentSA");
        query.bindLookup("closedStatus", ServiceAgreementStatusLookup.constants.CLOSED);
        query.bindLookup("cancelledStatus", ServiceAgreementStatusLookup.constants.CANCELED);
        query.bindId("accountId", account.getId());
        query.bindStringProperty("overpaymentSaType", ServiceAgreementType.properties.saType, parmOverpaymentSATypeCode.trim());
        query.bindId("cisDivisionId", account.getDivisionId());
        query.bindId("saId", woServiceAgreement.getId());

        query.addResult("sa", "SA");
                
        return query.list();
    }
    
    /**
     * Retrieve other SAs under the same account which has a different
     * WO Debt class from the finalized SA but whose WO debt class
     * is equal to one of the WO Debt Class of the WO Debt Class
     * Algorithm parameter
     * @param account
     * @param saStatList
     * @return list of eligible SAs 
     */
    private List<ServiceAgreement> retrieveOtherSAOfAccountWithDifferentWO(Account account) {
        List<ServiceAgreement> saList = new ArrayList<>();
        
        Query<QueryResultRow> query = createQuery("FROM ServiceAgreement SA, ServiceAgreementType SAT "
                + "WHERE SA.status IN (:active , :pendingStop , :stopped , :reactivated ) " 
                + "AND SA.account.id = :accountId "
                + "AND SA.serviceAgreementType.id.division = SAT.id.division  "
                + "AND SA.serviceAgreementType.id.saType = SAT.id.saType "
                + "AND SAT.writeOffDebtClass.id IN (" + woDebtClassesInQuotes + ") "
                + "AND SA.id <> :saId "
                + "AND SAT.paymentPriority IS NOT NULL  ",
                "retrieveOtherAccountSAsWithDifferentWO");

        query.bindId("accountId", account.getId());
        query.bindId("saId", woServiceAgreement.getId());
        query.bindLookup("active" , ServiceAgreementStatusLookup.constants.ACTIVE);
        query.bindLookup("pendingStop" , ServiceAgreementStatusLookup.constants.PENDING_STOP);
        query.bindLookup("stopped" , ServiceAgreementStatusLookup.constants.STOPPED);
        query.bindLookup("reactivated" , ServiceAgreementStatusLookup.constants.REACTIVATED);
        
        query.addResult("sa", "SA");
        query.addResult("paymentPriority", "SAT.paymentPriority");
        query.orderBy("paymentPriority");

        for(QueryResultRow resultRow : query.list()) {
            saList.add(resultRow.getEntity("sa", ServiceAgreement.class));
        }

        return saList;
    }

}
