package com.splwg.cm.api.lookup;

/**
 * @author TMG02493
 *
@LookupFieldname (value = CM_RECIPIENT_REL_STATUS)
 */
public class CmRecipientRelStatusLookup_Impl extends
		CmRecipientRelStatusLookup_Gen {

}
