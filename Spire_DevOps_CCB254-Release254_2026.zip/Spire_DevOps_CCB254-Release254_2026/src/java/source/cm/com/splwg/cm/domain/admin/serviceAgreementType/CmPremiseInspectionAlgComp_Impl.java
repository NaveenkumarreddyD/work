/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Premise Inspection SA Creation Algorithm
 * 
 * Prevent users from starting new service at a Premise if a pending 
 * inspection Field Activity is found.
 * 
 * The full process is described in the MGE-CCB033 design.
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2015-06-24   BMARQUEZ   MGE-CCB033. Initial version.
 * 2016-01-26   MPang	   Updated for CCB v2.4 compilation.             
 *************************************************************************/
package com.splwg.cm.domain.admin.serviceAgreementType;

import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.serviceAgreementType.SaTypeSaCreationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;*/
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saCreation.SaTypeSaCreationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 90725
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = fieldActivityType, name = premiseInspectionFaType, required = true, type = entity)})
 */
public class CmPremiseInspectionAlgComp_Impl 
		extends CmPremiseInspectionAlgComp_Gen 
		implements SaTypeSaCreationAlgorithmSpot {
    
	// Hard parameters
    private ServiceAgreement serviceAgreement;

    public void setServiceAgreement(ServiceAgreement serviceAgreement) {
        this.serviceAgreement = serviceAgreement;
    }

    public void invoke() {
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT FA.FA_ID ");
        stringBuilder.append("FROM CI_FA FA, CI_SP SP ");
        stringBuilder.append("WHERE SP.PREM_ID = :premise ");
        stringBuilder.append("AND FA.SP_ID = SP.SP_ID ");
        stringBuilder.append("AND FA.FA_TYPE_CD = :fieldActivityType ");
        stringBuilder.append("AND FA.FA_STATUS_FLG = :fieldActivityStatusPending ");
        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        preparedStatement.bindId("fieldActivityType", getPremiseInspectionFaType().getId());
        preparedStatement.bindId("premise", serviceAgreement.getPremiseId());
        preparedStatement.bindLookup("fieldActivityStatusPending", FieldActivityStatusLookup.constants.PENDING);
        
        SQLResultRow sqlResultRow = preparedStatement.firstRow();
        
        preparedStatement.close();
        
        if (notNull(sqlResultRow)) {
            addError(CustomMessageRepositoryMGE.ccb033NoStart(sqlResultRow.getEntity("FA_ID", FieldActivity.class)));
        }
        
    }

}
