/*
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                
 *    
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * MGE-CCB004.002 - Collection Agency Payment Notification
 * 
 * This algorithm will create a collection agency referral history record 
 * to notify DebtNext of any debits/credits applied to a WO SA after the 
 * WO Process becomes inactive. It should be referenced on WO SA Types.
 * 
 * Note: This algorithm replaces the existing CMCAFUB (Daily Collection 
 * Agency Financial Updates) NewBlue batch process. 
 *
 * 
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:       by:          Reason:
 * YYYY-MM-DD  FLName
 * 2014-12-09  MCRUZ     	MGE-CCB004.002 Initial Version.
 * 2015-08-31  SMiranda		Defect 3294942. Do not create additional referral
 *    						history record if there is already an existing one
 *    						for the freeze date. Just update the existing one.
 * 2015-11-18  SMiranda		SF-68527. Do not override referral history reason.
 * 2015-12-02  SMiranda     SF-70684. Find SAs with trailing spaces
 * 2015-12-04  SMiranda     SF-70597. Use FT Freeze Date on history Creation Date
 * 2016-02-18  MPang		Updated for CCB v2.4 compilation.
 * 2020-06-26  JHERNA       SysAid#335440. Update Collection Agency Referral when 
 *                          billing related financial transaction happens.
 **************************************************************************************************
 */

package com.splwg.cm.domain.admin.serviceAgreementType;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.BusinessObjectStatusConditionLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObject_Id;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.api.lookup.ReferralHistoryReasonLookup;
import com.splwg.ccb.api.lookup.ReferralStatusLookup;

//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.adjustmentType.AdjustmentType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.SaTypeFtFreezeAlgorithmSpot;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyHistory_DTO;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferralCollectionAgencyHistories;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral_DTO;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.financial.financialTransaction.FinancialTransaction;*/

import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.ftFreeze.SaTypeFtFreezeAlgorithmSpot;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyHistory_DTO;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferralCollectionAgencyHistories;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral_DTO;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation

import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author mcruz
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = adjustmentTypesToExclude, type = string)})
 */
public class CmCollectionAgencyPaymentNotificationAlgComp_Impl extends
		CmCollectionAgencyPaymentNotificationAlgComp_Gen implements
		SaTypeFtFreezeAlgorithmSpot {

	private String[] parmAdjustmentTypesToExclude = null;
	private List<AdjustmentType_Id> adjustmentTypes = null;
	
	private FinancialTransaction parmFinancialTransaction;
	private FinancialTransactionTypeLookup parmFinancialTransactionType;
	private ServiceAgreement sa;
	
	private List<SQLResultRow> collectionAgencyReferrals = new ArrayList<SQLResultRow>();
	private ReferralHistoryReasonLookup referralHistoryReason = null;
	private BigDecimal remainingFtAmount = null;
	
    // Constants
	private static final MaintenanceObject_Id COLL_AGY_REF_MO = new MaintenanceObject_Id("COLL AGY REF");
    private static final CharacteristicType_Id RELATED_SA_CHAR_TYPE = new CharacteristicType_Id("C1-SA");
	private static final String COMMA_DELIMITER = ",";
	private static final String PARM_10_DESCR = "Adjustment Types to Exclude";
		
	public Bool getWasFinancialProcessAdded() {
		return null;
	}

	public void setFinancialTransaction(FinancialTransaction financialTransaction) {
		parmFinancialTransaction = financialTransaction;
	}

	public void setFinancialTransactionType(FinancialTransactionTypeLookup financialTransactionType) {
		parmFinancialTransactionType = financialTransactionType;
	}

	public void setRegularFinancialTransaction(FinancialTransaction arg0) {
		
	}

	@Override
	protected void extraSoftParameterValidations(boolean arg0) {
		
		// Validate the list of Adjustments to Exclude parameter
		if(!isBlankOrNull(getAdjustmentTypesToExclude())) {
			
			parmAdjustmentTypesToExclude = getAdjustmentTypesToExclude().split(COMMA_DELIMITER);
			adjustmentTypes = new ArrayList<AdjustmentType_Id>();
			
			for(int i = 0; i < parmAdjustmentTypesToExclude.length; i++) {				
			
				String adjTypeStr = parmAdjustmentTypesToExclude[i].trim();
				if(adjTypeStr.length() <= AdjustmentType_Id.FIELD_SIZE) {
					
					AdjustmentType_Id adjustmentTypeId = new AdjustmentType_Id(adjTypeStr);
					
					if(isNull(adjustmentTypeId.getEntity())) {
						// Add error:
						addError(CustomMessageRepositoryMGE.commAlgorithmParameterIsInvalid(getAlgorithm().getId().getTrimmedValue(), 
								PARM_10_DESCR, parmAdjustmentTypesToExclude[i]));
					}
					
					adjustmentTypes.add(adjustmentTypeId);
					
				} else {
					// Add error:
					addError(CustomMessageRepositoryMGE.commAlgorithmParameterIsInvalid(getAlgorithm().getId().getTrimmedValue(), 
							PARM_10_DESCR, parmAdjustmentTypesToExclude[i]));
				}
			}
		}
        
	}
	
	

	public void invoke() {
		/* *****************************************************/
		/* START CHANGES - JHERNA - 2020-06-26 - SysAid#335440 */
		/*                                                     */
		/* Terminate processing if the FT is for an adjustment */
		/* whose adjustment type matches the list of excluded  */
		/* adjustment type parameter                           */
		/*                                                     */
		/* *****************************************************/
		// Exit if the FT is not a Payment, or if the FT is an Adjustment having an excluded adjustment type.
		/*
		if(parmFinancialTransactionType.isBillCancellation() 
				|| parmFinancialTransactionType.isBillSegment()
				|| (parmFinancialTransactionType.isAdjustment() 
						&& notNull(adjustmentTypes) && adjustmentTypes.contains(parmFinancialTransaction.fetchParentAdjustmentType().getId()))
				|| (parmFinancialTransactionType.isAdjustmentCancellation() 
						&& notNull(adjustmentTypes) && adjustmentTypes.contains(parmFinancialTransaction.fetchParentAdjustmentType().getId()))) {
			
			return;
		}
		*/
		if ((parmFinancialTransactionType.isAdjustment() || parmFinancialTransactionType.isAdjustmentCancellation())
				&& adjustmentTypes.contains(parmFinancialTransaction.fetchParentAdjustmentType().getId())) {
			return;
		}
		/* ***************************************************/
		/* END CHANGES - JHERNA - 2020-06-26 - SysAid#335440 */
		/* ***************************************************/
		
		// Get the SA
		sa = parmFinancialTransaction.getServiceAgreement();

		// Get the Active Collection Agency Referrals associated with the Account and SA
		collectionAgencyReferrals = getReferralWithPlacementForSa();
				
		// Exit if no Active Collection Agency Referral is found
		if(isNull(collectionAgencyReferrals) || collectionAgencyReferrals.isEmpty()) {
			return;
		}

		// Set FT Amount as the initial value of the Remaining FT Amount
		remainingFtAmount = parmFinancialTransaction.getCurrentAmount().getAmount();

		// Raise an error if current amount retrieved is zero
		if(remainingFtAmount.equals(BigDecimal.ZERO)){
			addError(CustomMessageRepositoryMGE.ccb004FtCurrentBalanceCannotBeZero(this.getAlgorithm().getId().getIdValue().trim(),
					sa.getId().getIdValue().trim(), 
					parmFinancialTransaction.getId().getIdValue().trim()));
		}

		// Process the FT according to its Type and prepare the Referral History Reason
		// Adjustment/Adjustment Cancellation
		if(parmFinancialTransactionType.isAdjustment() || parmFinancialTransactionType.isAdjustmentCancellation()) {
		
			referralHistoryReason = ReferralHistoryReasonLookup.constants.CHANGE_REFERRAL;				
			
			// Perform processing for debit if the FT amount is greater than 0
			if(remainingFtAmount.compareTo(BigDecimal.ZERO) > 0) {
				processDebitAdjustmentOrPaymentCancel();
			}
			
			// Perform processing for credit if the FT amount is less than 0
			if(remainingFtAmount.compareTo(BigDecimal.ZERO) < 0) {		
				processCreditAdjustmentOrPayment();
			}		
			
		// Payment
		} else if(parmFinancialTransactionType.isPaySegment()) {
			referralHistoryReason = ReferralHistoryReasonLookup.constants.REFERRAL_PAID;
			processCreditAdjustmentOrPayment();
			
		// Payment Cancellation
		} else if(parmFinancialTransactionType.isPayCancellation()) {
			referralHistoryReason = ReferralHistoryReasonLookup.constants.CHANGE_REFERRAL;
			processDebitAdjustmentOrPaymentCancel();
		}
		
		/* ***************************************************/
		/* START ADD - JHERNA - 2020-06-26 - SysAid#335440   */
		/*                                                   */
		/* Update the collection agency referral for billing */
		/* transactions                                      */
		/* ***************************************************/
		else if (parmFinancialTransactionType.isBillSegment()) {
			referralHistoryReason = ReferralHistoryReasonLookup.constants.CHANGE_REFERRAL;
			processDebitAdjustmentOrPaymentCancel();
		}
		else if (parmFinancialTransactionType.isBillCancellation()) {
			referralHistoryReason = ReferralHistoryReasonLookup.constants.CHANGE_REFERRAL;
			processCreditAdjustmentOrPayment();
		}
		
		/* ***********************************************/
		/* END ADD - JHERNA - 2020-06-26 - SysAid#335440 */
		/* ***********************************************/
	}
	
	/**
	 * This method gets all active collection agency referrals on the account that have collection agency placements associated with the FT SA
	 * @return
	 */
	private List<SQLResultRow> getReferralWithPlacementForSa() {

		List<SQLResultRow> referralList = new ArrayList<SQLResultRow>();
		
		// Get the SA associated with the FT
		String saIdStr = sa.getId().getIdValue().trim();
				
		PreparedStatement getReferrals = createPreparedStatement("SELECT " +
				"	CAR.COLL_AGY_REF_ID " +
				"FROM " +
				"	CI_COLL_AGY_REF CAR, " +
				"	F1_SVC_TASK_REL_OBJ STRO, " +
				"	F1_SVC_TASK STASK, " +
				"	F1_SVC_TASK_CHAR STCH, " +
				"   F1_BUS_OBJ_STATUS BOS " +
				"WHERE " +
				// 2015-08-31. SMiranda. Defect 3294942. Start Change
				//"	STCH.CHAR_TYPE_CD = :relSaCharType " +
				//"	AND (TRIM(STCH.ADHOC_CHAR_VAL) = :relSaIdAdhoc " +
				//"			OR TRIM(STCH.CHAR_VAL) = :relSaIdPredef " +
				//"			OR  TRIM(STCH.CHAR_VAL_FK1) = :relSaIdFk1 " +
				//"		) " +
				//"	AND STCH.F1_SVC_TASK_ID = STASK.F1_SVC_TASK_ID " +
				// 2015-12-02. SMiranda. SF-68113. Start Change
				//" 	STCH.SRCH_CHAR_VAL = :relSaId " +	
				" 	(STCH.SRCH_CHAR_VAL = :relSaId OR STCH.SRCH_CHAR_VAL = :relSaId2) " +
				// 2015-12-02. SMiranda. SF-68113. End Change
				" 	AND STCH.CHAR_TYPE_CD = :relSaCharType " +
				"	AND STASK.F1_SVC_TASK_ID = STCH.F1_SVC_TASK_ID " +
				// 2015-08-31. SMiranda. Defect 3294942. End Change
				"   AND BOS.BUS_OBJ_CD = STASK.BUS_OBJ_CD " +
				"	AND BOS.BO_STATUS_CD = STASK.BO_STATUS_CD " +
                "   AND BOS.BO_STATUS_COND_FLG <> :finalBoStatusCondition " +
				"	AND STRO.F1_SVC_TASK_ID = STASK.F1_SVC_TASK_ID " +
				"	AND STRO.MAINT_OBJ_CD = :collAgyRefMaintObj " +
				"	AND CAR.COLL_AGY_REF_ID = TRIM(STRO.PK_VALUE1) " +
				//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
				//"	AND CAR.REF_STATUS_FLG = :referralStatus ");
				"	AND CAR.REF_STATUS_FLG = :referralStatus ", getClass().getName());
				//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		
		getReferrals.bindLookup("referralStatus", ReferralStatusLookup.constants.ACTIVE);
		getReferrals.bindId("collAgyRefMaintObj", COLL_AGY_REF_MO);
		getReferrals.bindLookup("finalBoStatusCondition", BusinessObjectStatusConditionLookup.constants.FINAL);
		getReferrals.bindId("relSaCharType", RELATED_SA_CHAR_TYPE);
		// 2015-08-31. SMiranda. Defect 3294942. Start Change
		//getReferrals.bindString("relSaIdAdhoc", saIdStr, "ADHOC_CHAR_VAL");
		//getReferrals.bindString("relSaIdPredef", saIdStr, "CHAR_VAL");
		//getReferrals.bindString("relSaIdFk1", saIdStr, "CHAR_VAL_FK1");
		getReferrals.bindString("relSaId", saIdStr, "SRCH_CHAR_VAL");
		// 2015-08-31. SMiranda. Defect 3294942. End Change
		// 2015-12-02. SMiranda. SF-68113. Start Add
		String saIdStr2 = saIdStr + "                                        ";
		getReferrals.bindString("relSaId2", saIdStr2, "SRCH_CHAR_VAL");
		// 2015-12-02. SMiranda. SF-68113. End Add
		
		referralList = getReferrals.list();
		
		if(referralList.size() == 0) {
			referralList = null;
		}
		
		getReferrals.close();
		
		return referralList;		

	}
	
	/**
	 * This method processes Debit Adjustments and Payment Cancellations
	 *
	 */
	private void processDebitAdjustmentOrPaymentCancel() {

		SQLResultRow row = (SQLResultRow) collectionAgencyReferrals.get(0);
		CollectionAgencyReferral collectionAgencyReferral = row.getEntity("COLL_AGY_REF_ID", CollectionAgencyReferral.class);
			
		// Get the latest Referral Amount from the Collection Agency Referral History
		BigDecimal referralBalanceAmount = getReferralBalanceAmount(collectionAgencyReferral);
		
		// Add the FT Amount to the Referral Amount
		referralBalanceAmount = referralBalanceAmount.add(remainingFtAmount.abs());
		
		// 2015-08-31. SMiranda. Defect 3294942. Start Change
		SQLResultRow existingCarHistRow = existingCarHist(collectionAgencyReferral, referralHistoryReason);
		
		if (notNull(existingCarHistRow)){
			CollectionAgencyReferral_Id carId = (CollectionAgencyReferral_Id)existingCarHistRow.getId("COLL_AGY_REF_ID", CollectionAgencyReferral.class);
			BigInteger seqNum = existingCarHistRow.getInteger("SEQ_NUM");
			updateCollectionAgencyReferralHistory(carId, seqNum, referralBalanceAmount);
		}else{
			// Create a Referral History on the first Collection Agency Referral
			createCollectionAgencyReferralHistory(collectionAgencyReferral, referralBalanceAmount);
		}
		// 2015-08-31. SMiranda. Defect 3294942. End Change
		
	}
	
	/**
	 * This method processes Credit Adjustments and Payments
	 *
	 */
	@SuppressWarnings("rawtypes")
	private void processCreditAdjustmentOrPayment() {

		Iterator collectionAgencyReferralIter = collectionAgencyReferrals.iterator();

		// Offset the balance of each active referrals until credit is depleted
		while(collectionAgencyReferralIter.hasNext() && !remainingFtAmount.equals(BigDecimal.ZERO)) {

			SQLResultRow row = (SQLResultRow) collectionAgencyReferralIter.next();
			CollectionAgencyReferral collectionAgencyReferral = row.getEntity("COLL_AGY_REF_ID", CollectionAgencyReferral.class);
			
			BigDecimal referralBalanceAmount = getReferralBalanceAmount(collectionAgencyReferral);
			
			// If the Remaining FT Amount is enough to pay for the Referral Balance
			if(remainingFtAmount.abs().compareTo(referralBalanceAmount) >= 0) {

				// Reduce the Remaining FT Amount by the Referral Balance Amount
				// This amount will be used for succeeding passes through this condition
				remainingFtAmount = remainingFtAmount.abs().subtract(referralBalanceAmount);
				
				// 2015-11-18. SMiranda. SF-68527. Start Delete
				/// Set the Referral Reason to 'Paid'
				//referralHistoryReason = ReferralHistoryReasonLookup.constants.REFERRAL_PAID;
				// 2015-11-18. SMiranda. SF-68527. End Delete	
				
				// 2015-08-31. SMiranda. Defect 3294942. Start Change
				SQLResultRow existingCarHistRow = existingCarHist(collectionAgencyReferral, referralHistoryReason);
				
				if (notNull(existingCarHistRow)){
					CollectionAgencyReferral_Id carId = (CollectionAgencyReferral_Id)existingCarHistRow.getId("COLL_AGY_REF_ID", CollectionAgencyReferral.class);
					BigInteger seqNum = existingCarHistRow.getInteger("SEQ_NUM");
					updateCollectionAgencyReferralHistory(carId, seqNum, BigDecimal.ZERO);
				}else{
					// Create a Referral History on the Collection Agency Referral
					// Set the referral amount to zero, since the FT amount was able to pay it off
					createCollectionAgencyReferralHistory(collectionAgencyReferral, BigDecimal.ZERO);
				}
					
				// 2015-08-31. SMiranda. Defect 3294942. End Change
				
				// Close the Collection Agency Referral
				closeCollectionAgencyReferral(collectionAgencyReferral);
				
			} else if(remainingFtAmount.abs().compareTo(referralBalanceAmount) < 0) {				

				// Reduce the Remaining FT Amount by the Referral Balance Amount
				referralBalanceAmount = referralBalanceAmount.subtract(remainingFtAmount.abs());	

				// Zero out the Remaining FT Amount
				remainingFtAmount = BigDecimal.ZERO;

				// 2015-08-31. SMiranda. Defect 3294942. Start Change
				SQLResultRow existingCarHistRow = existingCarHist(collectionAgencyReferral, referralHistoryReason);
				
				if (notNull(existingCarHistRow)){
					CollectionAgencyReferral_Id carId = (CollectionAgencyReferral_Id)existingCarHistRow.getId("COLL_AGY_REF_ID", CollectionAgencyReferral.class);
					BigInteger seqNum = existingCarHistRow.getInteger("SEQ_NUM");
					updateCollectionAgencyReferralHistory(carId, seqNum, referralBalanceAmount);
				}else{
					// Create a Referral History on the Collection Agency Referral
					createCollectionAgencyReferralHistory(collectionAgencyReferral, referralBalanceAmount);
				}
				// 2015-08-31. SMiranda. Defect 3294942. End Change
			}
		}
	}

	// 2015-08-31. SMiranda. Defect 3294942. Start Add
	private SQLResultRow existingCarHist(CollectionAgencyReferral collectionAgencyReferral, ReferralHistoryReasonLookup refHistRsnFlg) {

		StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("	SELECT ");
        stringBuilder.append("		HIST.COLL_AGY_REF_ID, ");
        stringBuilder.append("		HIST.SEQ_NUM, ");
        stringBuilder.append("		HIST.REF_HIST_RSN_FLG ");
        stringBuilder.append("	FROM	 ");
        stringBuilder.append("		CI_COLL_AGY_HIS HIST ");
        stringBuilder.append("	WHERE	 ");
        stringBuilder.append("		HIST.COLL_AGY_REF_ID = :collectionAgencyReferralId ");
        stringBuilder.append("		AND HIST.CRE_DT = :processDate ");
        stringBuilder.append("		AND HIST.REF_HIST_RSN_FLG = :refHistRsnFlg ");
      
        //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
        //PreparedStatement preparedStatement =  createPreparedStatement(stringBuilder.toString());
        PreparedStatement preparedStatement =  createPreparedStatement(stringBuilder.toString(), getClass().getName());
        //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
        preparedStatement.bindId("collectionAgencyReferralId", collectionAgencyReferral.getId());
        preparedStatement.bindLookup("refHistRsnFlg", refHistRsnFlg);
        // 2015-12-04. SMiranda. SF-70597. Start Change
        //preparedStatement.bindDate("processDate", getProcessDateTime().getDate());
        preparedStatement.bindDate("processDate", parmFinancialTransaction.getFreezeDateTime().getDate());
        // 2015-12-04. SMiranda. SF-70597. End Change
        
        SQLResultRow sqlResultRow = preparedStatement.firstRow();
        preparedStatement.close();
        
        return sqlResultRow;
	}
	
	private void updateCollectionAgencyReferralHistory(CollectionAgencyReferral_Id carId, BigInteger seqNum, BigDecimal referralBalanceAmount) {

		StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("	UPDATE ");
        stringBuilder.append("		CI_COLL_AGY_HIS HIST ");
        stringBuilder.append("	SET ");
        stringBuilder.append("		HIST.REF_AMT = :referralBalanceAmount ");
        stringBuilder.append("	WHERE ");
        stringBuilder.append("		HIST.COLL_AGY_REF_ID = :carId ");
        stringBuilder.append("		AND HIST.SEQ_NUM = :seqNum ");
        //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
        //PreparedStatement preparedStatement =  createPreparedStatement(stringBuilder.toString());
        PreparedStatement preparedStatement =  createPreparedStatement(stringBuilder.toString(), getClass().getName());
        //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
        preparedStatement.bindId("carId", carId);
        preparedStatement.bindBigInteger("seqNum", seqNum);
        preparedStatement.bindBigDecimal("referralBalanceAmount", referralBalanceAmount);
        preparedStatement.executeUpdate();
        preparedStatement.close();
        
	}
	// 2015-08-31. SMiranda. Defect 3294942. End Add
	
	/**
	 * This method gets the latest referral amount posted on the history
	 * @param CollectionAgencyReferral collectionAgencyReferral
	 * @return BigDecimal referralAmount
	 */
	private BigDecimal getReferralBalanceAmount(CollectionAgencyReferral collectionAgencyReferral) {
		
		BigDecimal referralAmount = null;
		
		PreparedStatement getReferralBalance = createPreparedStatement("SELECT " +
				"	REF_AMT " +
				"FROM " +
				"	CI_COLL_AGY_HIS " +
				"WHERE " +
				"	COLL_AGY_REF_ID = :collectionAgencyReferral " +
				"ORDER BY " +
				//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
				//"	SEQ_NUM DESC");
				"	SEQ_NUM DESC", getClass().getName());
				//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		
		getReferralBalance.bindEntity("collectionAgencyReferral", collectionAgencyReferral);
		
		SQLResultRow getReferralBalanceRow = getReferralBalance.firstRow();
		if(notNull(getReferralBalanceRow)) {
			referralAmount = getReferralBalanceRow.getBigDecimal("REF_AMT");
		}
		
		getReferralBalance.close();
		
		return referralAmount;
	}
	
	/**
	 * This method create a Collection Agency Referral History
	 * @param collectionAgencyReferral
	 * @param referralBalanceAmount
	 */
	private void createCollectionAgencyReferralHistory(CollectionAgencyReferral collectionAgencyReferral, BigDecimal referralBalanceAmount) {
		
		CollectionAgencyReferralCollectionAgencyHistories collectionAgencyReferralHistories = collectionAgencyReferral.getCollectionAgencyHistories();
		Money referralAmount = new Money(referralBalanceAmount, parmFinancialTransaction.getCurrency().getId());
		BigInteger sequence = new BigInteger("10");
		
		CollectionAgencyHistory_DTO collectionAgencyHistoryDto = collectionAgencyReferralHistories.newChildDTO();
		// 2015-12-04. SMiranda. SF-70597. Start Change
		//collectionAgencyHistoryDto.setCreDt(getProcessDateTime().getDate());
		collectionAgencyHistoryDto.setCreDt(parmFinancialTransaction.getFreezeDateTime().getDate());
		// 2015-12-04. SMiranda. SF-70597. End Change
		collectionAgencyHistoryDto.setReferralHistoryReason(referralHistoryReason);
		collectionAgencyHistoryDto.setReferralAmount(referralAmount);
		collectionAgencyHistoryDto.setBatchControlId(collectionAgencyReferral.getCollectionAgency().getBatchControl().getId());
		collectionAgencyHistoryDto.setBatchNumber(collectionAgencyReferral.getCollectionAgency().getBatchControl().getNextBatchNumber());
		collectionAgencyHistoryDto.setIsSystemGenerated(Bool.TRUE);
		collectionAgencyHistoryDto.setTriggerBusinessProcess(Bool.TRUE);
		
		// Determine the next sequence
		PreparedStatement getMaxSequence = createPreparedStatement("SELECT " +
				"	MAX(SEQ_NUM) " +
				"FROM " +
				"	CI_COLL_AGY_HIS " +
				"WHERE " +
				//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
				//"	COLL_AGY_REF_ID = :collectionAgencyReferral");
				"	COLL_AGY_REF_ID = :collectionAgencyReferral", getClass().getName());
				//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		
		getMaxSequence.bindEntity("collectionAgencyReferral", collectionAgencyReferral);
		
		SQLResultRow resultRow = getMaxSequence.firstRow();
		if(notNull(resultRow)) {
			sequence = resultRow.getInteger("MAX(SEQ_NUM)");
			sequence = sequence.add(new BigInteger("10"));
		}
		
		collectionAgencyReferralHistories.add(collectionAgencyHistoryDto, sequence);

		getMaxSequence.close();	
	}
	
	/**
	 * This method closes the active Collection Agency Referral
	 * @param collectionAgencyReferral
	 */
	private void closeCollectionAgencyReferral(CollectionAgencyReferral collectionAgencyReferral) {
			
		CollectionAgencyReferral_DTO collectionAgencyReferralDto = collectionAgencyReferral.getDTO();
		collectionAgencyReferralDto.setReferralStatus(ReferralStatusLookup.constants.CLOSED);
		collectionAgencyReferral.setDTO(collectionAgencyReferralDto);
	}
	
}
