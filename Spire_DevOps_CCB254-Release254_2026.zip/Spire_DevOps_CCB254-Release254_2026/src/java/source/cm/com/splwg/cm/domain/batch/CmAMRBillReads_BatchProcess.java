/**********************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NI0007.4 AMR Bill Reads
 *
 **********************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2012-11-12   Arun    	NI0007.4. Initial Version.
 * 2012-12-17   Arun    	NI0007.4. Review Comments Incorporated.
 * 2013-03-06   MOL     	MOL20130306. Fixed defects found during alpha test
 *                      	and made some changes to the logic after discussing
 *                      	with the FS designer.
 * 2013-03-27   MOL     	Temporary Performance fixes. Adjusted the code
 *                      	to allow for the standard commit strategy
 * 2013-04-01   MOL     	Put back the functionality to derive and populate
 *                      	the Register Read Staging record's read sequence
 *                      	from the Meter Configuration.
 * 2013-04-15	Karthik		Included Trim as without it, the query is returning 
 * 							an empty list for valid badge number values.
 * 							Also, commented the code which set null to meter
 *							configuration after setting the right value.
 * 2013-04-16	Karthik		KL20130416 - To improve performance, TRIM() was removed and 
 * 							BadgeNumber padded with spaces to right in SQLs
 * 2013-05-03  Srikanth     SD20130502 - Date compare instead of time stamp compare to determine if the previous read
 *                          belong to Same Meter as the current register read
 * 2015-08-27  SMiranda	    Defect 3294833. Remove static variables
 * 2016-01-22  MPang		Updated for CCB v2.4 compilation.
 * 2022-04-01  DLampa       B-20753. Set the HILO_REV_SW to 'N' for specified UOM code.
 * 2023-05-10  Darryl H		SA429644 -meter read upload using the wrong meter config id
 **********************************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.MeterReadUploadStatusLookup;
import com.splwg.ccb.api.lookup.ReadTypeLookup;

//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
//import com.splwg.ccb.domain.admin.meterReadSource.MeterReadSource_Id;
//import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure;
//import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure_Id;
//import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
//import com.splwg.ccb.domain.meterread.meter.Meter;
//import com.splwg.ccb.domain.meterread.meter.Meter_Id;
//import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration;
//import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration_Id;
//import com.splwg.ccb.domain.meterread.meterConfiguration.Register;
//import com.splwg.ccb.domain.meterread.meterReadUpload.MeterReadStagingUploadCharacteristic_DTO;
//import com.splwg.ccb.domain.meterread.meterReadUpload.MeterReadUpload;
//import com.splwg.ccb.domain.meterread.meterReadUpload.MeterReadUploadCharacteristic;
//import com.splwg.ccb.domain.meterread.meterReadUpload.MeterReadUpload_DTO;
//import com.splwg.ccb.domain.meterread.meterReadUpload.MeterReadUpload_Id;
//import com.splwg.ccb.domain.meterread.meterReadUpload.ReaderRemarkUpload;

import com.splwg.ccb.domain.admin.meterReadSource.entity.MeterReadSource_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.meterReadUpload.entity.MeterReadStagingUploadCharacteristic_DTO;
import com.splwg.ccb.domain.meterread.meterReadUpload.entity.MeterReadUpload;
import com.splwg.ccb.domain.meterread.meterReadUpload.entity.MeterReadUploadCharacteristic;
import com.splwg.ccb.domain.meterread.meterReadUpload.entity.MeterReadUpload_DTO;
import com.splwg.ccb.domain.meterread.meterReadUpload.entity.MeterReadUpload_Id;
import com.splwg.ccb.domain.meterread.meterReadUpload.entity.ReaderRemarkUpload;

//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ServerMessage;
import com.splwg.shared.common.StringUtilities;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;


/**
 * @author leky
 *
 @BatchJob (modules = { }
 *      , multiThreaded = false
 *      , rerunnable = true
 *      , softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = UNCORRECTED_UOM_CHAR, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = SP_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = UOM_CD, required = false, type = string)})
 */
public class CmAMRBillReads_BatchProcess extends
CmAMRBillReads_BatchProcess_Gen {
	// 2015-08-27. SMiran. Defect 3294833. Start Change
    //private static String strFilePath;
    //private static String strFileName;
    //private static CharacteristicType spIdCharType;
    //private static MeterReadSource_Id defaultMRSourceId;
    private static final String DATE_FORMAT = "yyyy-MM-dd-HH.mm.ss";
    //private static String unCorrectedUomChar;
    private String strFilePath;
    private String strFileName;
    private CharacteristicType spIdCharType;
	// 2015-08-27. SMiran. Defect 3294833. End Change
    // 2022-04-01. DLampa. B-20753. Start Add
    private String strRvwExemptUomCd;
    // 2022-04-01. DLampa. B-20753. End Add
    private static final char READ_TYPE_CHAR = 'B';
    private static final char UNCORR_UOM_CHAR = 'U';
    
    

	private static final Logger logger = LoggerFactory
	.getLogger(CmAMRBillReads_BatchProcess.class);

	// 2015-08-27. SMiran. Defect 3294833. Start Change
    //private static File inputFilePathAndName;
    //private static BufferedReader inputFile;
    private File inputFilePathAndName;
    private BufferedReader inputFile;
	// 2015-08-27. SMiran. Defect 3294833. End Change

	public void validateSoftParameters(boolean isNewRun){
        initializeSoftParams();
        BigInteger parmMaxErrors = getParameters().getSoftMaxErrors();
        if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
            addError(CustomMessageRepository.ni00074IntegerParamCannotBeNegative(parmMaxErrors.toString().trim()));
        }

        File folder = new File(strFilePath);

        if(!(folder.exists() && folder.isDirectory())){
            addError(CustomMessageRepository.ni00074FilePathInvalid(strFilePath));
        }

        // MOL20130306 Begin

        // SP Id Char Type must be an Adhoc Char
        if (!spIdCharType.getCharacteristicType().isAdhocValue()) {
        	addError(CustomMessageRepository.ni00074SPIdCharTypeMustBeAnAdhocCharValue(spIdCharType.getId().toString().trim()));
        }

        Iterator iter = spIdCharType.getEntities().iterator();
        Bool validForMRUpStaging = Bool.FALSE;
        while (iter.hasNext()) {
			CharacteristicEntity charEntity = (CharacteristicEntity) iter.next();
		    if (charEntity.getId().getCharacteristicEntity().equals(CharacteristicEntityLookup.constants.METER_READ_UPLOAD_STAGING)) {
				validForMRUpStaging = Bool.TRUE;
			}
		}

        // SP Id Char Type must be allowed for MR Upload Staging
        if (validForMRUpStaging.isFalse()) {
        	addError(CustomMessageRepository.ni00074SPIdCharTypeNotAllowedForMRUp(spIdCharType.getId().toString().trim()));
		}

        // MOL20130306 End

        // 2022-04-01. DLampa. B-20753. Start Add        
        // Validate review exempt UOM
        UnitOfMeasure_Id unitOfMeasureId;
        for (String uomIdValue : strRvwExemptUomCd.split(",")) {
            
            if (uomIdValue.trim().length() > UnitOfMeasure_Id.FIELD_SIZE) {
                addError(CustomMessageRepository.ni00074invalidUnitOfMeasure(uomIdValue.trim()));
            }
            
            unitOfMeasureId = new UnitOfMeasure_Id(uomIdValue.trim());
            
            if (isNull(unitOfMeasureId.getEntity())) {
                addError(CustomMessageRepository.ni00074invalidUnitOfMeasure(unitOfMeasureId.getTrimmedValue()));
            }
        }
        // 2022-04-01. DLampa. B-20753. End Add
        
    }

	// 2015-08-27. SMiran. Defect 3294833. Start Change
    //private static void openFile(){
    private void openFile(){
	// 2015-08-27. SMiran. Defect 3294833. End Change
        //if(isNull(strFileName)) {
        //    strFileName = null;
        //}    
    	inputFilePathAndName = new File(strFilePath, strFileName);
    	
        try{
            inputFile = new BufferedReader(new FileReader(inputFilePathAndName));
        }
        catch(IOException e){
            throw new RunAbortedException(CustomMessageRepository.ni00074FileOpenError(inputFilePathAndName.toString()));
        }
    }
	// 2015-08-27. SMiran. Defect 3294833. Start Change
    //private static String readFileLine(){
    private String readFileLine(){
    // 2015-08-27. SMiran. Defect 3294833. End Change

        try {
            return inputFile.readLine();
        }
        catch(IOException e) {
            throw new RunAbortedException(CustomMessageRepository.ni00074FileReadError(inputFilePathAndName.toString(), e.getMessage()));
        }
    }
	// 2015-08-27. SMiran. Defect 3294833. Start Change
    //private static void closeFile(){
    private void closeFile(){
    // 2015-08-27. SMiran. Defect 3294833. End Change

        try {
            inputFile.close();
        }
        catch(IOException e) {
            throw new RunAbortedException(CustomMessageRepository.ni00074FileClosingError(inputFilePathAndName.toString()));
        }
    }

    /**
     * @return void
     *  This method retrieves Batch Param varaibles and initializes the class variables
     */
    private void initializeSoftParams(){
        strFilePath = getParameters().getFILE_PATH();
        strFileName = getParameters().getFILE_NAME();
    	// 2015-08-27. SMiran. Defect 3294833. Start Delete
        //unCorrectedUomChar =  getParameters().getUNCORRECTED_UOM_CHAR();
    	// 2015-08-27. SMiran. Defect 3294833. End Delete
        // MOL20130306 Begin

        spIdCharType = getParameters().getSP_ID_CHAR_TYPE();
    	// 2015-08-27. SMiran. Defect 3294833. Start Delete
        // Populate Default MR Source
        //StringBuilder getMRSource = new StringBuilder();
        //SQLResultRow resultRow = null;

        //getMRSource.append("SELECT MR_SOURCE_CD ");
        //getMRSource.append("FROM CI_MR_SOURCE  ");

        //PreparedStatement pstmt =  createPreparedStatement(getMRSource.toString());
        //resultRow = pstmt.firstRow();

        //defaultMRSourceId = new MeterReadSource_Id(resultRow.getString("MR_SOURCE_CD"));
    	// 2015-08-27. SMiran. Defect 3294833. End Delete
        
        // 2022-04-01. DLampa. B-20753. Start Add        
        // Validate review exempt UOM
        strRvwExemptUomCd = getParameters().getUOM_CD();
        // 2022-04-01. DLampa. B-20753. End Add        
    }

    public JobWork getJobWork() {
        String strRecordLine = " ";
        Integer lineCount = 0;
        

        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();

        openFile();
        strRecordLine = readFileLine();

        while (notNull(strRecordLine)){
        	lineCount = lineCount + 1;
        	ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.addSupplementalData("FILE_RECORD", strRecordLine);
            workUnits.add(workUnit);

            strRecordLine = readFileLine();

        }

        closeFile();
        return createJobWorkForThreadWorkUnitList(workUnits);
    }

    public Class<CmAMRBillReads_BatchProcessWorker> getThreadWorkerClass() {
        return CmAMRBillReads_BatchProcessWorker.class;
    }

    public static class CmAMRBillReads_BatchProcessWorker extends
    CmAMRBillReads_BatchProcessWorker_Gen {


        private int maxErrors;
        private int errRecCnt = 0;
        private Integer recordCounter = 0;
        private Integer lineCounter = 0;
        private Integer duplInvalidBadgeNumCounter = 0;
        private Integer duplReadTypCharCounter = 0;
        private Integer duplReadDttmCounter = 0;
        private Integer duplReadValueCounter = 0;
        private Integer duplEmptyLineCounter = 0;
        private Integer duplRecordCounter = 0;
        private Integer duplLineLengthCounter = 0;
        private String strFileBadgeNumber = null;
        private String strBadgeNumber = null;
        private String strBadgeNumberForSQL = null;
        // MOL20130306 - Added
        private String previousBadgeNumber = " ";
        private Bool sameMeterAsPreviousRecord = Bool.FALSE;
        private BigInteger mrStageIdValue = BigInteger.ZERO;
        private String previousSPId =  " ";
        private MeterConfiguration_Id currentMeterConfigId = null;
        private String strUtilityId = " ";
        private String strReadDateTime =  " ";
        private String strReadValue = " ";
        private String strSPId =  " ";
        private String previousStrReadDateTime =  " ";
        private List<SQLResultRow> uomReadList = new ArrayList<SQLResultRow>();
        private List<SQLResultRow> previousUomReadList = null;



        private String strReadMethod = null;
        private UnitOfMeasure_Id currentRegUOMId = null;
        private DateTime meterReadDateTime = null;
        private ServicePoint_Id spId = null;
        private BigInteger readSeq = BigInteger.ZERO;
        private BigDecimal readValue = null;
        private MeterReadUpload_Id mrStageId = null;

        private final Integer MFR_CODE_LENGTH = 4;
        private final Integer MTR_NBR_START = 1;
        private final Integer MTR_NBR_LENGTH = 20;
        private final Integer UTLTY_NBR_START = 21;
        private final Integer UTLTY_NBR_LENGTH = 25;
        private final Integer SP_NBR_LENGTH =10;
        private final Integer START_POS =0;
        private final Integer READ_DATE_START = 77;
        private final Integer READ_DATE_LENGTH = 14;
        private final Integer READ_VALUE_START = 91;
        private final Integer READ_VALUE_LENGTH = 12;
        private final Integer READ_METHOD_START = 112;
        private final Integer READ_METHOD_LENGTH = 1;
        private final Integer TIME_LENGTH = 6;
        private final Integer BILL_READ_START = 75;
        
        private final Integer MAX_ERROR_TOLERANCE = 5;
        private  final Integer RECORD_LINE_LENGTH = 153;
        
        // 2015-08-27. SMiran. Defect 3294942. Start Add
        private MeterReadSource_Id defaultMRSourceId;
        private String unCorrectedUomChar;
        private CharacteristicType spIdCharType;
        // 2015-08-27. SMiran. Defect 3294942. End Add

        // 2022-04-01. DLampa. B-20753. Start Add
        private String strRvwExemptUomCd;
        private List<UnitOfMeasure_Id> reviewExemptRegisterUoms = new ArrayList<UnitOfMeasure_Id>();
        // 2022-04-01. DLampa. Defect 3294833. End Add        
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

        public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
            maxErrors = getParameters().getSoftMaxErrors().intValue();
            // 2015-08-27. SMiran. Defect 3294942. Start Add
            
            unCorrectedUomChar = getParameters().getUNCORRECTED_UOM_CHAR();
            
            spIdCharType = getParameters().getSP_ID_CHAR_TYPE();
            
            // 2022-04-01. DLampa. Defect 3294833. Start Add
            UnitOfMeasure_Id unitOfMeasureId;
            strRvwExemptUomCd = getParameters().getUOM_CD();
            for (String uomIdValue : strRvwExemptUomCd.split(",")) {
                
                if (uomIdValue.trim().length() > UnitOfMeasure_Id.FIELD_SIZE) {
                    addError(CustomMessageRepository.NA_86246_invalidUnitOfMeasure(uomIdValue.trim()));
                }
                
                unitOfMeasureId = new UnitOfMeasure_Id(uomIdValue.trim());
                
                if (isNull(unitOfMeasureId.getEntity())) {
                    addError(CustomMessageRepository.NA_86246_invalidUnitOfMeasure(unitOfMeasureId.getTrimmedValue()));
                }
                
                reviewExemptRegisterUoms.add(unitOfMeasureId);            
            }
            // 2022-04-01. DLampa. Defect 3294833. End Add            
            
            // Populate Default MR Source
            StringBuilder getMRSource = new StringBuilder();
            SQLResultRow resultRow = null;

            getMRSource.append("SELECT MR_SOURCE_CD ");
            getMRSource.append("FROM CI_MR_SOURCE  ");
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement pstmt =  createPreparedStatement(getMRSource.toString());
            PreparedStatement pstmt =  createPreparedStatement(getMRSource.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            resultRow = pstmt.firstRow();

            defaultMRSourceId = new MeterReadSource_Id(resultRow.getString("MR_SOURCE_CD"));
            // 2015-08-27. SMiran. Defect 3294942. End Add
        }

        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {

        	String strRecordLine = "";
        	strRecordLine = unit.getSupplementallData("FILE_RECORD").toString();
        	processRecord(strRecordLine);
        	return super.executeWorkUnitDetailedResult(unit);
        }

        private void processRecord(String strRecordLine){
            strUtilityId = null;
            strReadDateTime =  null;
            strReadValue = null;
            strSPId =  null;

            //initialize record values
            strFileBadgeNumber = null;
            strBadgeNumber = null;
            meterReadDateTime = null;
            strReadMethod = null;
            currentRegUOMId = null;
                        
            String strMtrCmpPreviousDt = " ";
        	lineCounter = lineCounter+1;
        	           
            if(parseLineAndRetrieveValues(strRecordLine).isFalse()){
                if(MAX_ERROR_TOLERANCE == lineCounter)
             	   validateFileLayoutAndDuplicates();
            	return;
            }
               
             if(!previousStrReadDateTime.trim().equals(""))
               strMtrCmpPreviousDt = previousStrReadDateTime.trim().substring(0, 8);//Extract Date from Date time

            // MOL20130306 - Check if processing file record for the same meter
            if (strBadgeNumber.trim().equals(previousBadgeNumber.trim())
            		&& strSPId.trim().equals(previousSPId.trim())
            		&& strReadDateTime.trim().substring(0, 8).equals(strMtrCmpPreviousDt)) {
            	sameMeterAsPreviousRecord = Bool.TRUE;
                // MOL20130306 for debugging
            	
            } else {
            	sameMeterAsPreviousRecord = Bool.FALSE;
                // MOL20130306 for debugging
            	previousBadgeNumber = strBadgeNumber;
            	previousSPId = strSPId;
            	previousStrReadDateTime = strReadDateTime;
            	mrStageIdValue = BigInteger.ZERO;
            	mrStageId  = null;
            	uomReadList = new ArrayList<SQLResultRow>();
            	previousUomReadList = null;
            	
            }

             
            // MOL20130306 - Processing a new Badge Number
            if (sameMeterAsPreviousRecord.isFalse()) {
            	currentMeterConfigId = deriveTheMeterConfiguration();
            }
            deriveUOMAndReadSeq();
          	//Check for the Duplicate entries in the Staging, only for the first few records.
            if(lineCounter <= MAX_ERROR_TOLERANCE && checkIfDuplicateRecord().isTrue()){
       	        duplRecordCounter++;
       	       if(duplRecordCounter == MAX_ERROR_TOLERANCE) 
       	    	   abortRead(CustomMessageRepository.ni00074FileAlreadyProcessed(MAX_ERROR_TOLERANCE.toString())); //TODO change Message
       	        return; 
            }
            	
            if (sameMeterAsPreviousRecord.isFalse()) {
                	 addMRStagingRecord();
            }


            // MOL20130306 - Add Register Read Record
            addRRStaging();

        }
        
        private Bool parseLineAndRetrieveValues(String strRecordLine){

            
        	if(strRecordLine.trim().length() != 0 && strRecordLine.length() != RECORD_LINE_LENGTH){
        		duplLineLengthCounter++;
        		logError(CustomMessageRepository.ni00074LineLengthInvalid(lineCounter.toString().trim()));
                handleMaxErrors();
        		return Bool.FALSE;
        	}
        	

        	
            if(strRecordLine.length() == 0){
            	duplEmptyLineCounter++;
            	return Bool.FALSE;
            }
            
            if(strRecordLine.charAt(BILL_READ_START)== ' '){
            	duplReadTypCharCounter++;
            	logError(CustomMessageRepository.ni00074ReadCharIsMissing(lineCounter.toString().trim()));
            	handleMaxErrors();
            	return Bool.FALSE;
            }
            
            if(strRecordLine.charAt(BILL_READ_START) != READ_TYPE_CHAR){
            	return Bool.FALSE;
            }
            

            strFileBadgeNumber = getSubString(strRecordLine,MTR_NBR_START,MTR_NBR_LENGTH);
            // SD20130520 - If Badge number is Empty, though loaded to staging, this cannot be resolved. So Log error 
            if(isEmptyOrNull(strFileBadgeNumber)){
            	duplInvalidBadgeNumCounter++;
            	logError(CustomMessageRepository.ni00074BadgeNumberNotExists(lineCounter.toString().trim() ));
            	handleMaxErrors();
            	return Bool.FALSE;
            }
            
            strBadgeNumber = strFileBadgeNumber.substring(START_POS,((strFileBadgeNumber.length())- MFR_CODE_LENGTH)).trim();
            //KL20130416 - To avoid using TRIM() in query, padding input BadgeNumber with spaces to right and use it in SQLs
            strBadgeNumberForSQL = StringUtilities.padRight(strBadgeNumber, 30);
            strUtilityId  = getSubString(strRecordLine,UTLTY_NBR_START,UTLTY_NBR_LENGTH);
            strSPId = strUtilityId.substring(START_POS,SP_NBR_LENGTH);
            strReadDateTime = getSubString(strRecordLine,READ_DATE_START,READ_DATE_LENGTH);
            
            meterReadDateTime = convertToDateTime(strReadDateTime);
            // MOL20130306 - If MR Read Date/Time is invalid, error message is already logged
            //               so just skip processing the current file record
            if(isNull(meterReadDateTime)){
            	duplReadDttmCounter++;
            	return Bool.FALSE;
            }

            strReadValue = getSubString(strRecordLine,READ_VALUE_START,READ_VALUE_LENGTH);
            if(isEmptyOrNull(strReadValue)){
            	duplReadValueCounter++;
            	logError(CustomMessageRepository.ni00074ReadValueIsMissing(lineCounter.toString().trim()));
            	handleMaxErrors();
            	return Bool.FALSE;
            }
            strReadMethod = getSubString(strRecordLine,READ_METHOD_START,READ_METHOD_LENGTH);
            return Bool.TRUE;
        	
        }
        
       private void validateFileLayoutAndDuplicates(){
    	   if(duplRecordCounter == MAX_ERROR_TOLERANCE){
    		   abortRead(CustomMessageRepository.ni00074FileAlreadyProcessed(lineCounter.toString().trim()));
    	   }
    	   if(duplEmptyLineCounter == MAX_ERROR_TOLERANCE){
    		   //addError - Empty File is being processed
    		   abortRead(CustomMessageRepository.ni00074EmptyFile());
    	   }
    	   if(duplReadTypCharCounter == MAX_ERROR_TOLERANCE ){
    		   abortRead(CustomMessageRepository.ni00074FileIsMissingReadTypeChar());
    	   }
    	   if(duplInvalidBadgeNumCounter == MAX_ERROR_TOLERANCE){
    		   abortRead(CustomMessageRepository.ni00074FileIsMissingBadgeNumber());
    		}
    	   if(duplReadDttmCounter == MAX_ERROR_TOLERANCE){
    		   abortRead(CustomMessageRepository.ni00074FileIsMissingReadDttm());
    	   }
    	   if(duplReadValueCounter == MAX_ERROR_TOLERANCE){
    		   abortRead(CustomMessageRepository.ni00074FileIsMissingReadValue());
    	   }
    	   if(duplLineLengthCounter == MAX_ERROR_TOLERANCE){
    		   abortRead(CustomMessageRepository.ni00074InvalidRecordLineLength()); 
    	   }
    	    
    		   
       } 
        private List<SQLResultRow> retrieveUOMAndReadSequence(Meter_Id mtrId, DateTime mtrCfgEffDttm){
            StringBuilder getReadSeqQuery = new StringBuilder();
            List<SQLResultRow> resultRow = null;

            getReadSeqQuery.append("SELECT UOM_CD, READ_SEQ ");
            getReadSeqQuery.append("FROM CI_REG WHERE MTR_ID = :meterId  ");
            getReadSeqQuery.append("AND EFF_DTTM = :meterConfigDateTime ");
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement pstmt =  createPreparedStatement(getReadSeqQuery.toString());
            PreparedStatement pstmt =  createPreparedStatement(getReadSeqQuery.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            pstmt.bindId("meterId", mtrId);
            pstmt.bindDateTime("meterConfigDateTime", mtrCfgEffDttm);
            
            resultRow = pstmt.list();  
            pstmt.close();
            return resultRow;
        }

        // MOL20130306 - Derive Meter Config
        private MeterConfiguration_Id deriveTheMeterConfiguration() {

        	// Derive Meter Configuration
        	List<SQLResultRow> resultRowList = retrieveMeterDetails();
        	if(resultRowList.size() == 0){
        		logWarning(CustomMessageRepository.ni00074MeterNotFound(strFileBadgeNumber, meterReadDateTime.toString(), lineCounter.toString().trim()));
        		return null;
        	}

        	// Exact Meter Configuration Match found
        	if (resultRowList.size() == 1){
                SQLResultRow sqlRow = resultRowList.get(0);
                //CR To Derive UOM SD05142013
                uomReadList = retrieveUOMAndReadSequence(((Meter_Id)sqlRow.getId("MTR_ID", Meter.class)),sqlRow.getDateTime("EFF_DTTM"));
                return (MeterConfiguration_Id)sqlRow.getId("MTR_CONFIG_ID", MeterConfiguration.class);
        	}

        	// More than one Meter Configuration found - duplicate badge number
        	if (resultRowList.size() > 1){
                spId = new ServicePoint_Id(strSPId);

                if(isNull(spId.getEntity())){
                	// Leky To Do - Allow MR Staging to be inserted but with an SP Id MR Upload Char
                    logWarning(CustomMessageRepository.ni00074RecordValueInvalidSP(strSPId, strFileBadgeNumber, lineCounter.toString().trim()));
                }

                // Resolve the duplicate badge number. Derive the appropriate Meter Config using the SP Id.
                List<SQLResultRow> resultRowMtrList = retrieveEffectiveMeterData();
                if (resultRowMtrList.size() == 0) {
                    // Meter with Badge Number is not installed at the SP
					return null;
				} else {
					// Meter with Badge Number is installed at the SP
                    SQLResultRow sqlRow = resultRowMtrList.get(0);
                    //CR To Derive UOM SD05142013
                    uomReadList = retrieveUOMAndReadSequence(((Meter_Id)sqlRow.getId("MTR_ID", Meter.class)),sqlRow.getDateTime("EFF_DTTM"));
                    return (MeterConfiguration_Id)sqlRow.getId("MTR_CONFIG_ID", MeterConfiguration.class);
				}
            }

        	return null;

        }


        private DateTime convertToDateTime(String strReadDateTime){

            String strDate  = strReadDateTime.substring(0,(strReadDateTime.length()-TIME_LENGTH));
            String hour = strReadDateTime.substring(strDate.length());
            String dateFormat = strDate.substring(0,4)+"-" +strDate.substring(4,6)+"-" +strDate.substring(6,8);
            String timeFormat = hour.substring(0,2)+ "." + hour.substring(2,4) + "." + hour.substring(4,6);
            String mrReadDateTime = dateFormat + "-" + timeFormat;
            DateFormat df = new DateFormat(DATE_FORMAT);

            try{
                meterReadDateTime = df.parseDateTime(mrReadDateTime);
            }catch(DateFormatParseException e){
                logError(CustomMessageRepository.ni00074RecordValueDateInvalidDTTM(mrReadDateTime, DATE_FORMAT, lineCounter.toString().trim(),strFileBadgeNumber ));
                handleMaxErrors();
            }
            return meterReadDateTime;
        }

        // MOL20130306 - Add MR Staging
        private void addMRStagingRecord() {

        	// Add the MR Upload Staging Record
        	MeterReadUpload_DTO mtrUploadDto =(MeterReadUpload_DTO)createDTO(MeterReadUpload.class);
            mtrUploadDto.setBadgeNumber(strBadgeNumber);
            mtrUploadDto.setMeterReadSourceId(defaultMRSourceId);
            // mtrUploadDto.setMeterReadSourceId(new MeterReadSource_Id(strReadMethod));
            mtrUploadDto.setMeterReadUploadStatus(MeterReadUploadStatusLookup.constants.PENDING);

            mtrUploadDto.setMeterConfigurationId(currentMeterConfigId);
			// KL20130415 - Commented out the below line to prevent overriding the assignment done by line above
            //mtrUploadDto.setMeterConfigurationId(null); 

            mtrUploadDto.setReadDateTime(meterReadDateTime);
            mtrUploadDto.setCanUseOnBill(Bool.TRUE);
            mtrUploadDto.setVersion(1);
            MeterReadUpload_Id mrStagingId = mtrUploadDto.newEntity().getId();  
                        
           // MeterReadUpload_Id mrStagingId = new MeterReadUpload_Id(BigInteger.valueOf(999));
            // insertIntoStagingRegister(mrStagingId);
            mrStageIdValue = mrStagingId.getIdValue();
            mrStageId = mrStagingId;

            // Add MR Upload Staging Char to store the SP Id 
            
           
            MeterReadUploadCharacteristic mrUploadChar = mrStagingId.getEntity().getCharacteristic(); 
            MeterReadStagingUploadCharacteristic_DTO mrStageUpChar_DTO = mrUploadChar.newChildDTO();
            mrStageUpChar_DTO.setAdhocCharacteristicValue(strSPId);
            mrUploadChar.add(mrStageUpChar_DTO, spIdCharType.getId(), BigInteger.ZERO);

            // Log warning if MR Source Code in the file is invalid
            if(isNull(new MeterReadSource_Id(strReadMethod).getEntity())){
            	logWarning(CustomMessageRepository.ni00074RecordValueInvalid(strReadMethod, strFileBadgeNumber,lineCounter.toString().trim()));
            }

            // Update MR Source Code directly to bypass Base validation in case of an invalid value from the file
            StringBuilder updateMRSource = new StringBuilder();

            updateMRSource.append("UPDATE CI_MR_STAGE_UP ");
            updateMRSource.append("SET MR_SOURCE_CD = :inputMRSourceCode ");
            updateMRSource.append("WHERE MR_STAGE_UP_ID = :inputMRStageUpId ");
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement pstmt2 =  createPreparedStatement(updateMRSource.toString());
            PreparedStatement pstmt2 =  createPreparedStatement(updateMRSource.toString(),getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            pstmt2.bindId("inputMRStageUpId", mrStagingId);
            pstmt2.bindString("inputMRSourceCode", strReadMethod.trim(), "MR_SOURCE_CD");

            pstmt2.executeUpdate();
            pstmt2.close();

        }

        // MOL20130306 - Add RR Staging
        private void addRRStaging() {
        	
            // Check to see if current Register Read Record needs to be skipped
            try{
                // MOL20130306 for debugging
            	// logger.info("strReadValue=" + strReadValue);
                BigDecimal rawReadValue = new BigDecimal(strReadValue);
                // Convert the Read Value - last 3 digits to the right are after the decimal point
                // readValue = rawReadValue.divide(new BigDecimal(1000), 3, BigDecimal.ROUND_FLOOR);
                readValue = rawReadValue;
                // MOL20130306 for debugging
                // logger.info("readValue=" + readValue);
            }catch(NumberFormatException e){
                logWarning(CustomMessageRepository.ni00074InvalidRegisterReadValue(strReadValue, strFileBadgeNumber,lineCounter.toString().trim()));
                return;
            }

            // Derive the Read Sequence 
          //CR To Derive UOM SD05142013
/*            if (currentRegUOMId.equals(correctedUom.getId())) {
            	readSeq = BigInteger.ONE;
			} else {
				readSeq = BigInteger.valueOf(2);
			}*/

            // Add the RR Staging Record
            StringBuilder insertRRStagingRecord = new StringBuilder();

            insertRRStagingRecord.append(" INSERT INTO CI_RR_STAGE_UP ( ");
            insertRRStagingRecord.append("   mr_stage_up_id ");
            insertRRStagingRecord.append(" , read_seq ");
            insertRRStagingRecord.append(" , read_type_flg ");
            insertRRStagingRecord.append(" , reg_reading ");
            insertRRStagingRecord.append(" , review_hilo_sw ");
            insertRRStagingRecord.append(" , tou_cd ");
            insertRRStagingRecord.append(" , uom_cd ");
            insertRRStagingRecord.append(" , version ");
            insertRRStagingRecord.append(" ) VALUES ( ");
            insertRRStagingRecord.append("   :MRStageUpId ");
            insertRRStagingRecord.append(" , :ReadSeq ");
            insertRRStagingRecord.append(" , :ReadTypeFlg ");
            insertRRStagingRecord.append(" , :RegReading ");
            insertRRStagingRecord.append(" , :ReviewHiLoSw ");
            insertRRStagingRecord.append(" , ' ' ");
            if(notNull(currentRegUOMId))
               insertRRStagingRecord.append(" , :UomCd ");
            else
               insertRRStagingRecord.append(" , ' ' ");
            insertRRStagingRecord.append(" , :Version ");
            insertRRStagingRecord.append(" ) ");
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement pstmt =  createPreparedStatement(insertRRStagingRecord.toString());
            PreparedStatement pstmt =  createPreparedStatement(insertRRStagingRecord.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            pstmt.bindBigInteger("MRStageUpId", mrStageId.getIdValue());
            pstmt.bindBigInteger("ReadSeq", readSeq);
            pstmt.bindBigDecimal("RegReading", readValue);
            if(notNull(currentRegUOMId))
                pstmt.bindId("UomCd", currentRegUOMId);
            pstmt.bindLookup("ReadTypeFlg", ReadTypeLookup.constants.REGULAR);
            // 2022-04-01. DLampa. B-20753. Start Change
            //pstmt.bindBoolean("ReviewHiLoSw", Bool.TRUE);
            if(reviewExemptRegisterUoms.contains(currentRegUOMId)) {
            	pstmt.bindBoolean("ReviewHiLoSw", Bool.FALSE);
            } else {
            	pstmt.bindBoolean("ReviewHiLoSw", Bool.TRUE);
            }
            
            // 2022-04-01. DLampa. B-20753. End Change
            pstmt.bindBigInteger("Version", BigInteger.ONE);

            pstmt.executeUpdate();
            pstmt.close();

            /*
            ReaderRemarkUpload_Id rrUploadId;
            ReaderRemarkUpload_DTO registerReadDTO;
            rrUploadId = new ReaderRemarkUpload_Id(mrStageId, readSeq);
            registerReadDTO =  rrUploadId.newDTO();
            registerReadDTO.setRegisterReading(readValue);
            registerReadDTO.setUnitOfMeasureId(currentRegUOMId);
            registerReadDTO.setReadType(ReadTypeLookup.constants.REGULAR);
            registerReadDTO.setIsHighLowReviewed(Bool.TRUE);
            registerReadDTO.setVersion(1);
            registerReadDTO.newEntity();
            */

            recordCounter = recordCounter+1;
        }



       private void deriveUOMAndReadSeq(){
    	    String strBadgeExt = strFileBadgeNumber.substring((strFileBadgeNumber.length())-4);
                      
            if(strBadgeExt.charAt(1)== UNCORR_UOM_CHAR){
            	setUncorrectedUOMAndReadSeq();
            }
            else{
            	 setCorrectedUOMAndReadSeq();
            }
            previousUomReadList = uomReadList;
        }
        
        private void setUncorrectedUOMAndReadSeq(){
        	int count = 0;       
        	UnitOfMeasure_Id uomCd = null;
        	List<SQLResultRow> currUomReadList = null;

            if (sameMeterAsPreviousRecord.isFalse()) 
            	currUomReadList = uomReadList;
            else
            	currUomReadList = previousUomReadList;
        	//Check all UOMs that end with character 'U' (UnCorrected UOM Char)
        	for(SQLResultRow resultRow : currUomReadList){
        		uomCd = (UnitOfMeasure_Id)resultRow.getId("UOM_CD",UnitOfMeasure.class);
        		if(uomCd.getIdValue().endsWith(unCorrectedUomChar)){
        			currentRegUOMId =  uomCd;
        			readSeq = resultRow.getInteger("READ_SEQ");
        			count++;
        		}
        	}
        	
        	//if more than one Uncorrected register exists for the meter, set the UOM to default and read seq to a Max value
        	if(count != 1){
            	currentRegUOMId = null;  
            	readSeq = BigInteger.valueOf(99);
         	}
        	

        }
        
        private void setCorrectedUOMAndReadSeq(){
            int count = 0;       
        	UnitOfMeasure_Id uomCd = null;
        	List<SQLResultRow> currUomReadList = null;
        	
            if (sameMeterAsPreviousRecord.isFalse()) 
            	currUomReadList = uomReadList;
            else
            	currUomReadList = previousUomReadList;
            
        	for(SQLResultRow resultRow : currUomReadList){
        		uomCd = (UnitOfMeasure_Id)resultRow.getId("UOM_CD",UnitOfMeasure.class);
        		if(!uomCd.getIdValue().endsWith(unCorrectedUomChar)){
        			currentRegUOMId =  uomCd;
        			readSeq = resultRow.getInteger("READ_SEQ");
        			count++;
        		}
        	}
        
        	//if more than one Corrected register exists for the meter, set the UOM to default and read seq to a Max value
        	if(count != 1){
            	currentRegUOMId = null;
            	readSeq = BigInteger.valueOf(98);
        	}
        	
        	

        }

        private String getSubString(String strRecord,int intStartPos, int strLength){
            intStartPos--;
            int intEndPos = intStartPos + strLength;
            return strRecord.substring(intStartPos, intEndPos).trim();
        }

        private List<SQLResultRow> retrieveMeterDetails(){

            List<SQLResultRow> resultList = null;

            StringBuilder getMeterDetailsQuery = new StringBuilder();
            getMeterDetailsQuery.append(" SELECT MTR.MTR_ID ");
            getMeterDetailsQuery.append("       ,MTRCFG.MTR_CONFIG_ID ");
            getMeterDetailsQuery.append("       ,MTRCFG.EFF_DTTM ");
            getMeterDetailsQuery.append(" FROM CI_MTR MTR, CI_MTR_CONFIG MTRCFG "); 
            // KL20130416 - Removed Trim and right paded BadgeNumber with spaces
            getMeterDetailsQuery.append(" WHERE MTR.BADGE_NBR = :badgeNum "); 
            getMeterDetailsQuery.append(" AND MTR.MTR_ID = MTRCFG.MTR_ID ");
            getMeterDetailsQuery.append(" AND MTRCFG.EFF_DTTM = (SELECT  MAX(EFF_DTTM) ");
            getMeterDetailsQuery.append("                        FROM CI_MTR_CONFIG B ");
            getMeterDetailsQuery.append("                        WHERE B.MTR_ID = MTR.MTR_ID ");
            getMeterDetailsQuery.append("                          AND B.EFF_DTTM <= :mtrReadDateTime) ");
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement pstmt =  createPreparedStatement(getMeterDetailsQuery.toString());
            PreparedStatement pstmt =  createPreparedStatement(getMeterDetailsQuery.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            pstmt.bindStringProperty("badgeNum", Meter.properties.badgeNumber, strBadgeNumberForSQL);
            pstmt.bindDateTime("mtrReadDateTime", meterReadDateTime);

            resultList = pstmt.list();
            pstmt.close();

            return resultList;
        }


        private Bool checkIfDuplicateRecord(){

            if(checkIfMeterStagingExists().isTrue())
                return Bool.TRUE;
            else
                return Bool.FALSE;
        }
        


        private Bool checkIfMeterStagingExists(){

            Bool isExists = Bool.FALSE;
            MeterReadUpload_Id mrUploadId = null;

            StringBuilder getMeterStagingQuery = new StringBuilder();
            getMeterStagingQuery.append("SELECT CMSU.MR_STAGE_UP_ID FROM CI_MR_STAGE_UP CMSU  ");
            getMeterStagingQuery.append("WHERE CMSU.BADGE_NBR = :badgeNum  ");
            getMeterStagingQuery.append("AND CMSU.MR_UP_STATUS_FLG = :pending ");
            getMeterStagingQuery.append("AND CMSU.READ_DTTM = :readDttm ");
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement pstmt =  createPreparedStatement(getMeterStagingQuery.toString());
            PreparedStatement pstmt =  createPreparedStatement(getMeterStagingQuery.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            pstmt.bindStringProperty("badgeNum", Meter.properties.badgeNumber, strBadgeNumberForSQL);
            pstmt.bindLookup("pending", MeterReadUploadStatusLookup.constants.PENDING);
            pstmt.bindDateTime("readDttm", meterReadDateTime);

            int intResultSize = pstmt.list().size();
            if(intResultSize == 0 ){
                pstmt.close();
                return isExists;
            }

            if(intResultSize == 1 ){
            	mrUploadId = (MeterReadUpload_Id)pstmt.firstRow().getId("MR_STAGE_UP_ID", MeterReadUpload.class);
                if(checkIfRegisterReadExists(mrUploadId).isTrue())
                    isExists = Bool.TRUE;
            }else{
                logWarning(CustomMessageRepository.ni00074DuplicateRecord(strFileBadgeNumber,lineCounter.toString().trim()));
                isExists = Bool.TRUE;
            }
            pstmt.close();
            return isExists;

        }
        



        private Bool checkIfRegisterReadExists(MeterReadUpload_Id mrUploadId){
            Bool isExists = Bool.FALSE;

            StringBuilder getRegisterStagingQuery = new StringBuilder();
            getRegisterStagingQuery.append("SELECT COUNT(*) COUNT FROM CI_RR_STAGE_UP CRSU  ");
            getRegisterStagingQuery.append("WHERE CRSU.MR_STAGE_UP_ID = :mrStgId  ");
            if(notNull(currentRegUOMId))
               getRegisterStagingQuery.append("AND CRSU.UOM_CD = :uomId ");
            else
            	getRegisterStagingQuery.append("AND CRSU.UOM_CD = ' ' ");
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement pstmt =  createPreparedStatement(getRegisterStagingQuery.toString());
            PreparedStatement pstmt =  createPreparedStatement(getRegisterStagingQuery.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            pstmt.bindId("mrStgId", mrUploadId);
            if(notNull(currentRegUOMId))
               pstmt.bindId("uomId", currentRegUOMId);
            BigInteger count =  pstmt.firstRow().getInteger("COUNT");
             if(count.compareTo(BigInteger.ZERO) == 1 ){
                isExists = Bool.TRUE;
                logWarning(CustomMessageRepository.ni00074RegisterReadAlreadyExists(strFileBadgeNumber,currentRegUOMId.getIdValue(),meterReadDateTime.toString(),lineCounter.toString().trim()));
            }
            pstmt.close();
            return isExists;
        }
        

        private List<SQLResultRow> retrieveEffectiveMeterData(){

            List<SQLResultRow> resultList = null;
            StringBuilder getSAQuery = new StringBuilder();

            getSAQuery.append("SELECT MTR.MTR_ID,MTRCFG.MTR_CONFIG_ID,MTRCFG.EFF_DTTM  ");
            getSAQuery.append("FROM CI_MTR MTR, CI_MTR_CONFIG MTRCFG , CI_SP_MTR_HIST HIST ");
			// KL20130416 - Removed Trim and right paded BadgeNumber with spaces
            getSAQuery.append("WHERE MTR.BADGE_NBR = :badgeNumber ");
            getSAQuery.append("AND HIST.SP_ID = :servicePointId ");
            getSAQuery.append("AND MTR.MTR_ID = MTRCFG.MTR_ID ");
            getSAQuery.append("AND HIST.MTR_CONFIG_ID = MTRCFG.MTR_CONFIG_ID ");
            getSAQuery.append("AND TRUNC(MTRCFG.EFF_DTTM) <= :readDateTime ");
            //Start Add: SA429644 -2023-05-10 DarrylH.
            getSAQuery.append("ORDER BY MTRCFG.EFF_DTTM DESC ");
            //End Add SA429644 -2023-05-10 DarrylH.
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement pstmt =  createPreparedStatement(getSAQuery.toString());
            PreparedStatement pstmt =  createPreparedStatement(getSAQuery.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            pstmt.bindStringProperty("badgeNumber", Meter.properties.badgeNumber, strBadgeNumberForSQL);
            pstmt.bindDateTime("readDateTime", meterReadDateTime);
            pstmt.bindId("servicePointId",spId);

            int intResultSize = pstmt.list().size();
            if(intResultSize == 0 ){
                logWarning(CustomMessageRepository.ni00074MeterServicePointCombinationNotExists(strFileBadgeNumber,spId.getIdValue(),meterReadDateTime.toString(),lineCounter.toString().trim()));
            }
            resultList = pstmt.list();
            pstmt.close();
            return resultList;
        }

        private void handleMaxErrors(){
            errRecCnt = errRecCnt + 1;
            if(notNull(maxErrors)){
                if(errRecCnt > maxErrors){
                    throw new RunAbortedException(CustomMessageRepository.ni00074_Max_Error_Exceeded(String.valueOf(maxErrors)));
                }
            }
        }
        
        private void abortRead(ServerMessage message){
               throw new RunAbortedException(message);
           
        }
    }
}
