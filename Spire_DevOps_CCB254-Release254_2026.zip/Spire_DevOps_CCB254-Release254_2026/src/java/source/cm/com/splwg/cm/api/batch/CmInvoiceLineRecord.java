/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Letter Extract Record                                                               
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                          
 * 2019-12-27  JVitug      SA-315895. Initial version                    
 *                                                                
 *******************************************************************************
 */

package com.splwg.cm.api.batch;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmInvoiceLineRecord extends ColumnDelimitedRecord {
    // Letter Record
    private static final String GLOBAL_INFORMATION_RECORD_PRINT_KEY = "2010";
    private static final String LETTER_RECORD_GRP = "61";
    private static final String BLANK = "  ";
    private static final String EMPTY_STR = "";
    
    public CmInvoiceLineRecord() {
        super(15);  
        defaultPrintKey();
    }
    
    private void defaultPrintKey() {
        this.rightPadColumn(1, 4, formatString(GLOBAL_INFORMATION_RECORD_PRINT_KEY, 4));
    }
    
    public void setSortKeyLetterTemplateCode(String letterTemplateCode) {
        this.rightPadColumn(2, 12, formatString(letterTemplateCode, 12));
    }
    
    public void setSortKeyCcId(String ccId) {
        this.rightPadColumn(3, 10, formatString(ccId, 10));
        setSortKeyCcRecordGroup();
        setSortKeyCAndCRecordGroup();
    }
    
    private void setSortKeyCcRecordGroup() {
        this.rightPadColumn(4, 2, LETTER_RECORD_GRP);
    }
    
    private void setSortKeyCAndCRecordGroup() {
        this.rightPadColumn(5, 2, BLANK);
    }
    
    public void setMailingKey(String mailingKey) {
        this.rightPadColumn(6, 12, formatString(mailingKey, 12));
        setFiller3Spaces();
    }
    
    private void setFiller3Spaces() {
        this.rightPadColumn(7, 3, " ");
    }
    
    public void setAppInSummarySwitch(String appInSummarySw) {
        this.rightPadColumn(8, 1, formatString(appInSummarySw, 1));
    }
    
    public void setCalcAmount(BigDecimal calcAmount) {
        this.rightPadColumn(9, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(calcAmount));
    }
    
    public void setExemptAmount(BigDecimal exemptAmount) {
        this.rightPadColumn(10, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(exemptAmount));
    }
    
    public void setUnitOfMeasure(String unitOfMeasure) {
        this.rightPadColumn(11, 4, formatString(unitOfMeasure, 4));
    }
    
    public void setTimeOfUse(String timeOfUse) {
        this.rightPadColumn(12, 8, formatString(timeOfUse, 8));
    }
    
    public void setServiceQuantityIdentifier(String sqi) {
        this.rightPadColumn(13, 8, formatString(sqi , 8));
    }
    
    public void setBillSQ(BigDecimal billSq) {
        this.rightPadColumn(14, 19, formatAsS9zV9z(billSq, 12, 6));
    }
    
    public void setBillDescription(String description) {
        this.rightPadColumn(15, 80, formatString(description, 80));
    }
   
    
    /**
     * Returns "" if text is null;
     * Truncates text if length exceed fieldLength;
     * @param text String variable to be formatted
     * @param fieldLength Length of Field
     * @return formatted text
     */
    private String formatString(String text, int fieldLength) {
        if(text == null) {
            text = EMPTY_STR;
        }
        else {
            text = text.trim();
            if(text.length() > fieldLength) {
                text = text.substring(0, fieldLength);
            }
        }
        return text;
    }
}
