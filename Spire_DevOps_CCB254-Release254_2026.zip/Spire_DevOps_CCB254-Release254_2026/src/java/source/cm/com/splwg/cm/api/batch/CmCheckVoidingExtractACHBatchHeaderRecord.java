/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Voiding File Batch Extract - ACH 
 * Batch Header Record
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2021-06-01   GCrisp     Initial version. CCB041.3 ACH Batch Header
 *                   	   Record
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmCheckVoidingExtractACHBatchHeaderRecord extends ColumnDelimitedRecord{
	
	/*
	 * Constructor
	 */
	public CmCheckVoidingExtractACHBatchHeaderRecord() {
		super(13);

	}

	public void setRecordTypeCode(String value) {		
		rightPadColumn(1, 1, value);
	}
	
	public void setServiceClassCode(String value) {		
		rightPadColumn(2, 3, value);
	}
	
	public void setCompanyName(String value) {		
		rightPadColumn(3, 16, value);
	}
	
	public void setDiscretionaryData(String value) {		
		rightPadColumn(4, 20, value);
	}
	
	public void setCompanyIdentification(String value) {		
		rightPadColumn(5, 10, value);
	}
	
	public void setStandardEntryClass(String value) {		
		rightPadColumn(6, 3, value);
	}
	
	public void setCompanyEntryDescription(String value) {		
		rightPadColumn(7, 10, value);
	}
	
	public void setCompanyDescriptiveDate(String value) {		
		rightPadColumn(8, 6, value);
	}
	
	public void setEffectiveEntryDate(String value) {		
		rightPadColumn(9, 6, value);
	}
	
	public void setReservedField(String value) {		
		rightPadColumn(10, 3, value);
	}
	
	public void setOriginatorStatusCode(String value) {		
		rightPadColumn(11, 1, value);
	}
	
	public void setOriginatingFinancialInstitution(String value) {		
		rightPadColumn(12, 8, value);
	}
	
	public void setBatchNumber(String value) {		
		rightPadColumn(13, 7, value);
	}
}
