/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 2024-07-30   DLampa     INC0037039. Updated field lengths to match 
 *                         the file layout extracted by the CM-BILEXTR 
 *                         algorithm 
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractDetailsAdjustmentDetailsRecord 
		extends ColumnDelimitedRecord{	
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractDetailsAdjustmentDetailsRecord() {
		super(15);		
		// Initialize all fields as blank/spaces
		this.setBPPrinterKey(" ");		
		this.setBPSortKey(" ");
		this.setBPMailingKey(" ");	
		this.setAdjDt(" ");
		this.setFtTypeFlg(" ");
		this.setCurAmt(BigDecimal.ZERO, "0");
		this.setTotAmt(BigDecimal.ZERO, "0");
		this.setAdjTypeCd(" ");
		this.setAdjTypeDescr(" ");
		this.setDescrOnBill(" ");
		this.setCanRsnCd(" ");
		this.setCanRsnDescr(" ");
		this.setFiller();
	}
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * 
	 */
	public void setBPPrinterKey(String value) {		
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
	public void setBPSortKey(String value) {
		rightPadColumn(2, 184, truncateInput(value, 184));
	}
	public void setBPMailingKey(String value) {
		rightPadColumn(3, 15, truncateInput(value, 15));
	}	
	/*
	 * Adjustment Details (List)
	 */
	public void setAdjDt(String value) {
		rightPadColumn(4, 10, truncateInput(value, 10));
	}
	public void setFtTypeFlg(String value) {
		rightPadColumn(5, 2, truncateInput(value, 2));
	}
	public void setCurAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(6, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(7, 15, truncateInput(value, 15));
	}
	public void setTotAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(8, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(9, 15, truncateInput(value, 15));
	}
	public void setAdjTypeCd(String value) {
		rightPadColumn(10, 8, truncateInput(value, 8));
	}
	public void setAdjTypeDescr(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(11, 30, truncateInput(value, 30));
		rightPadColumn(11, 60, truncateInput(value, 60));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setDescrOnBill(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(12, 80, truncateInput(value, 80));
		rightPadColumn(12, 254, truncateInput(value, 254));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setCanRsnCd(String value) {
		rightPadColumn(13, 4, truncateInput(value, 4));
	}
	public void setCanRsnDescr(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(14, 30, truncateInput(value, 30));
		rightPadColumn(14, 60, truncateInput(value, 60));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setFiller() {
		//rightPadColumn(13, 3250, " ");
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(15, 3045, " ");
		rightPadColumn(15, 2811, " ");
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
}