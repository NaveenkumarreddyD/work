/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Record Layout for Custom Eligibility Account Detail Record
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-04-24   RDizon  NI0026.1 Initial Version.
 **************************************************************************/

package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmEligibilityAccountDetailRecord
extends ColumnDelimitedRecord {

    public CmEligibilityAccountDetailRecord() {
        super(3);
    }

    public void setAccountId(String accountId) {
        String string = "<AccountID>" + accountId + "</AccountID>" + "\n";
        this.rightPadColumn(1, string.length(), string);
    }
    
    public void setCisDivision(String cisDivision) {
        String string = "<CISDivision>" + cisDivision + "</CISDivision>" + "\n";
        this.rightPadColumn(2, string.length(), string);
    }

    public void setCustomerClass(String customerClass) {
        String string = "<CustClass>" + customerClass + "</CustClass>" + "\n";
        this.rightPadColumn(3, string.length(), string);
    }
}
