/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Check Extract A/P Download Batch Process
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 * 2021-05-27   RDizon  CCB041.1. Initial version.
 * 2021-07-26 	JLumbre	CCB041. Update on the return address values.
 * 2021-09-09 	JLumbre	QAC#4595520. Update on the AL Origin ID.
 * 2023-11-10   DLampa  E-08140. Update to ensure the space is retained
 *                      between the house number and street name when the
 *                      street name also begins with a number.
 **************************************************************************
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.ccb.api.lookup.PaymentSelectionStatusLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.ApCheckRequest;
import com.splwg.ccb.domain.adjustment.adjustment.entity.ApCheckRequest_DTO;
import com.splwg.ccb.domain.adjustment.adjustment.entity.ApCheckRequest_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivisionCharacteristic;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.cm.api.batch.CmCheckExtractACHBatchControlRecord;
import com.splwg.cm.api.batch.CmCheckExtractACHBatchHeaderRecord;
import com.splwg.cm.api.batch.CmCheckExtractACHFileControlRecord;
import com.splwg.cm.api.batch.CmCheckExtractACHFileHeaderRecord;
import com.splwg.cm.api.batch.CmCheckExtractACHPPDEntryDetailRecord;
import com.splwg.cm.api.batch.CmCheckExtractBatchControlTotalRecord;
import com.splwg.cm.api.batch.CmCheckExtractBatchHeaderRecord;
import com.splwg.cm.api.batch.CmCheckExtractFileHeaderRecord;
import com.splwg.cm.api.batch.CmCheckExtractFileTrailerRecord;
import com.splwg.cm.api.batch.CmCheckExtractOriginBankingRecord;
import com.splwg.cm.api.batch.CmCheckExtractPaymentDetailRecord;
import com.splwg.cm.api.batch.CmCheckExtractPaymentHeaderRecord;
import com.splwg.cm.api.batch.CmCheckExtractReturnAddressRecord;
import com.splwg.cm.api.batch.CmCheckExtractTransactionHeaderRecord;
import com.splwg.cm.api.lookup.CmAdjCharChandlerParmLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever_Impl;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.StringUtilities;

/**
 * @author RDizon
 *
@BatchJob (multiThreaded = false, rerunnable = false,  modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MISSOURI_EP1_FILENAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MISSOURI_EPC_FILENAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = ALABAMA_EP1_FILENAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = ALABAMA_EPC_FILENAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = ALABAMA_ACH_FILENAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = GULF_EP1_FILENAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = GULF_EPC_FILENAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = GULF_ACH_FILENAME, required = true, type = string)})
 */
public class CmCheckExtractAPDownloadBatch extends
        CmCheckExtractAPDownloadBatch_Gen {

    // Batch Parameters
    private String parmFilePath;
    //private static Logger log = LoggerFactory.getLogger(CmCheckExtractAPDownloadBatch.class);

    public void validateSoftParameters(boolean isJobWorkNeeded) {

        // Retrieve Batch Parameters
        parmFilePath = getParameters().getFILE_PATH();

        File folder = new File(parmFilePath);

        if (!folder.isDirectory()) {
            addError(CustomMessageRepositorySpireOne.CCB041_1_InvalidFilePath("File Path"));
        }

    }

    public JobWork getJobWork() {
        StringBuilder queryString = new StringBuilder();
        queryString.append("SELECT");
        queryString.append("    AAP.AP_REQ_ID APREQID, ");
        queryString.append("    SA.CIS_DIVISION CISDIVISION ");
        queryString.append("FROM CI_ADJ_APREQ AAP, ");
        queryString.append("    CI_ADJ ADJ, ");
        queryString.append("    CI_SA SA ");
        queryString.append("WHERE ");
        queryString.append("    AAP.BATCH_CD = :batchCode ");
        queryString.append("    AND AAP.BATCH_NBR = :batchNumber ");
        queryString.append("    AND AAP.PYMNT_SEL_STAT_FLG = 'N' ");
        queryString.append("    AND AAP.ADJ_ID = ADJ.ADJ_ID ");
        queryString.append("    AND ADJ.SA_ID = SA.SA_ID ");

        PreparedStatement getApAdjustments = createPreparedStatement(queryString.toString(), getClass().getName());
        getApAdjustments.bindId("batchCode", getBatchControlId());
        getApAdjustments.bindBigInteger("batchNumber", getBatchNumber());

        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();

        QueryIterator<SQLResultRow> iterator = getApAdjustments.iterate();
        while (iterator.hasNext()){
            SQLResultRow resultRow = iterator.next();

            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId(resultRow.getId("APREQID", ApCheckRequest.class));
            workUnit.addSupplementalData("CISDIVISION", resultRow.getId("CISDIVISION", CisDivision.class));
            workUnits.add(workUnit);

        }

        iterator.close();
        getApAdjustments.close();
        return createJobWorkForThreadWorkUnitList(workUnits);

    }

    public Class<CmCheckExtractAPDownloadBatchWorker> getThreadWorkerClass() {
        return CmCheckExtractAPDownloadBatchWorker.class;
    }

    public static class CmCheckExtractAPDownloadBatchWorker extends
            CmCheckExtractAPDownloadBatchWorker_Gen {

        // Batch Parameters
        private String parmFilePath;
        private String parmMissouriEp1FileName;
        private String parmMissouriEpcFileName;
        private String parmAlabamaEp1FileName;
        private String parmAlabamaEpcFileName;
        private String parmAlabamaAchFileName;
        private String parmGulfEp1FileName;
        private String parmGulfEpcFileName;
        private String parmGulfAchFileName;

        // Work variables
        private File ep1FileMissouri;
        private File ep1FileAlabama;
        private File ep1FileGulf;
        private File epcFileMissouri;
        private File epcFileAlabama;
        private File epcFileGulf;
        private File achFileAlabama;
        private File achFileGulf;
        private BufferedWriter bwEP1Missouri;
        private BufferedWriter bwEP1Alabama;
        private BufferedWriter bwEP1Gulf;
        private BufferedWriter bwEPCMissouri;
        private BufferedWriter bwEPCAlabama;
        private BufferedWriter bwEPCGulf;
        private BufferedWriter bwACHAlabama;
        private BufferedWriter bwACHGulf;

        private int mNumberOfChecks;
        private BigDecimal mTotalCheckAmount;
        private int mNumberOfLines;
        private int aNumberOfChecks;
        private BigDecimal aTotalCheckAmount;
        private int aNumberOfLines;
        private int gNumberOfChecks;
        private BigDecimal gTotalCheckAmount;
        private int gNumberOfLines;

        private BigInteger checkNumber;
        private int initializeMoFiles;
        private int initializeAlFiles;
        private int initializeGlFiles;
        private CharacteristicType companyCodeCharType;
        private String lgcCompanyCode;
        private String mgeCompanyCode;
        private String alCompanyCode;
        private String glCompanyCode;

        private CmCheckExtractFileHeaderRecord mEP1FileHeader;
        private CmCheckExtractBatchHeaderRecord mEP1BatchHeader;
        private CmCheckExtractReturnAddressRecord mEP1ReturnAddress;
        private CmCheckExtractOriginBankingRecord mEP1OriginBanking;
        private CmCheckExtractTransactionHeaderRecord mEP1TransactionHeader;
        private CmCheckExtractPaymentHeaderRecord mEP1PaymentHeader;
        private CmCheckExtractPaymentDetailRecord mEP1PaymentDetail;
        private CmCheckExtractBatchControlTotalRecord mEP1BatchControlTotal;
        private CmCheckExtractFileTrailerRecord mEP1FileTrailer;

        private CmCheckExtractFileHeaderRecord aEP1FileHeader;
        private CmCheckExtractBatchHeaderRecord aEP1BatchHeader;
        private CmCheckExtractReturnAddressRecord aEP1ReturnAddress;
        private CmCheckExtractOriginBankingRecord aEP1OriginBanking;
        private CmCheckExtractTransactionHeaderRecord aEP1TransactionHeader;
        private CmCheckExtractPaymentHeaderRecord aEP1PaymentHeader;
        private CmCheckExtractPaymentDetailRecord aEP1PaymentDetail;
        private CmCheckExtractBatchControlTotalRecord aEP1BatchControlTotal;
        private CmCheckExtractFileTrailerRecord aEP1FileTrailer;
        private CmCheckExtractACHFileHeaderRecord aACHFileHeader;
        private CmCheckExtractACHBatchHeaderRecord aACHBatchHeader;
        private CmCheckExtractACHPPDEntryDetailRecord aACHPPDEntryDetail;
        private CmCheckExtractACHBatchControlRecord aACHBatchControl;
        private CmCheckExtractACHFileControlRecord aACHFileControl;

        private CmCheckExtractFileHeaderRecord gEP1FileHeader;
        private CmCheckExtractBatchHeaderRecord gEP1BatchHeader;
        private CmCheckExtractReturnAddressRecord gEP1ReturnAddress;
        private CmCheckExtractOriginBankingRecord gEP1OriginBanking;
        private CmCheckExtractTransactionHeaderRecord gEP1TransactionHeader;
        private CmCheckExtractPaymentHeaderRecord gEP1PaymentHeader;
        private CmCheckExtractPaymentDetailRecord gEP1PaymentDetail;
        private CmCheckExtractBatchControlTotalRecord gEP1BatchControlTotal;
        private CmCheckExtractFileTrailerRecord gEP1FileTrailer;
        private CmCheckExtractACHFileHeaderRecord gACHFileHeader;
        private CmCheckExtractACHBatchHeaderRecord gACHBatchHeader;
        private CmCheckExtractACHPPDEntryDetailRecord gACHPPDEntryDetail;
        private CmCheckExtractACHBatchControlRecord gACHBatchControl;
        private CmCheckExtractACHFileControlRecord gACHFileControl;

        // Constants
        private static final String CM_COMP_CHAR_TYPE = "CM-COMP";
        private static final String FILE_EXT_EP1 = ".ep1";
        private static final String FILE_EXT_EPC = ".epc";
        private static final String FILE_EXT_ACH = ".ach";
        private static final String CIS_DIVISION_LGC = "LGC";
        private static final String CIS_DIVISION_MGE = "MGE";
        private static final String CIS_DIVISION_AL = "200";
        private static final String CIS_DIVISION_GL = "203";
        private static final String RECORD_TYPE_EP1_BATCH_HEADER = "10";
        private static final String RECORD_TYPE_EP1_RETURN_ADDRESS = "21";
        private static final String RECORD_TYPE_EP1_ORIGIN_BANKING = "30";
        private static final String RECORD_TYPE_EP1_TRANSACTION_HEADER = "31";
        private static final String RECORD_TYPE_EP1_PAYMENT_HEADER = "40";
        private static final String RECORD_TYPE_EP1_PAYMENT_DETAIL = "70";
        private static final String RECORD_TYPE_EP1_BATCH_CONTROL_TOTAL = "90";
        private static final String RECORD_TYPE_ACH_FILE_HEADER = "1";
        private static final String RECORD_TYPE_ACH_BATCH_HEADER = "5";
        private static final String RECORD_TYPE_ACH_PPD_ENTRY_DETAIL = "6";
        private static final String RECORD_TYPE_ACH_BATCH_CONTROL = "8";
        private static final String RECORD_TYPE_ACH_FILE_CONTROL = "9";

        private static final String BLANK = "";
        private static final String HRVALD = "H!R!VALD";
        private static final String SPIRE_MISSOURI_INC = "SPIRE MISSOURI INC.";
        private static final String SPIRE_ALABAMA_INC = "Spire Alabama Inc.";
        private static final String SPIRE_GULF_INC = "Spire Gulf Inc.";
        private String SPIRE_ALABAMA_INC_RA = "";
        private String SPIRE_ALABAMA_INC_GF_RA = "";
        private static final String C2090 = "2090";
        private static final String YES = "Y";
        //private static String SPIRE_INC = "SPIRE INC.";
        private String SPIRE_INC = "";
        //private static final String C700_MARKET = "700 MARKET";
        private String C700_MARKET = "";
        //private static final String CUSTOMER_EXPERIENCE= "Customer Experience";
        private String CUSTOMER_EXPERIENCE= "";
        private String CUSTOMER_EXPERIENCE_AL= "";
        private String CUSTOMER_EXPERIENCE_GF= "";
        private String ADDRESS3= "";
        private String ADDRESS3_AL= "";
        private String ADDRESS3_GF= "";
        private String CSZC_CODE = "";
        private String CSZC_CODE_AL = "";
        private String CSZC_CODE_GF = "";
        //private static final String C2101_6TH_AVENUE_NORTH = "2101 6th Avenue North";
        private String C2101_6TH_AVENUE_NORTH = "";
        private String C2101_6TH_AVENUE_NORTH_GF = "";
        //private static final String SAINT_LOUIS = "SAINT LOUIS";
        private String SAINT_LOUIS = "";
        //private static final String BIRMINGHAM = "Birmingham";
        private String BIRMINGHAM = "";
        private String BIRMINGHAM_GF = "";
        private static final String MO = "MO";
        private String MO_RA = "";
        //private static final String AL_GULF = "AL";
        private String AL_RA = "";
        private String GF_RA = "";
        //private static final String MO_ZIP = "63101";
        private String MO_ZIP = "";
        //private static final String AL_GULF_ZIP = "35203";
        private String AL_ZIP_RA = "";
        private String GF_ZIP_RA = "";
        private static final String ABA_NUMBER = "101000019";
        private static final String MO_ABA_NUMBER = "081500493";
        private static final String COMMERCE_BANK = "Commerce Bank";
        private static final String COMMERCE_BANK_FED_TAX_ID = "43-0368139";
        private static String SPIRE_ACCT_NO_AL = "";
        private static String SPIRE_ACCT_NO_GF = "";
        private static String SPIRE_ACCT_NO_MO = "";
        private static final String C8000_FORSYTH = "8000 Forsyth Blvd";
        private static final String CLAYTON = "Clayton";
        private static final String ODFI_POSTAL = "63105-1707";
        private static final String ODFI_BANK_FRAC = "18-1/1010";
        private static final String REFERENCE_NO = "Reference No";
        private static final String ACCOUNT_NO = "Account No";
        private static final String DESCRIPTION = "Description";
        private static final String AMOUNT = "Amount";
        private static final String C2091_1 = "2091_1";
        private static final String NOR = "NOR";
        private static final String PBC = "PBC";
        private static final String CHK = "CHK";
        private static final String S = "S";
        private static final String ADR = "ADR";
        //private static final String NOT_APPLICABLE = "N/A";
        private static final String CREDIT_BALANCE_REFUND = "Customer Refund";
        private static final String TRVALD = "T!R!VALD";
        private static final String PRIORITY_CODE = "01";
        private static final String DEST_BANK_ROUTING_NBR = " 062000019";
        private static final String COMPANY_NBR_ALABAMA = "1630022000";
        private static final String COMPANY_NBR_GULF = "1630142930";
        private static final String A = "A";
        private static final String C094 = "094";
        private static final String C10 = "10";
        private static final String C1 = "1";
        private static final String REGIONS_BANK = "REGIONS BANK";
        private static final String SPIRE_ALABAMA = "SPIRE ALABAMA";
        private static final String SPIRE_GULF = "SPIRE GULF";
        private static final String SVC_CLASS_200 = "200";
        private static final String COMPANY_NAME_ALABAMA = "Spire Alabama";
        private static final String COMPANY_NAME_GULF = "Spire Gulf";
        private static final String PPD = "PPD";
        private static final String PAYABLE = "PAYABLE";
        private static final String C06200001 = "06200001";
        private static final String C0000001 = "0000001";
        private static final String C10100001 = "10100001";
        private static final String C22 = "22";
        private static final String C9 = "9";
        private static final String C000001 = "000001";
        private static final String C000010 = "000010";
        private static final String ALABAMA_DFI_ACCT_NBR = "165516195";
        private static final String GULF_DFI_ACCT_NBR = "174301207";
        private static final String ALABAMA_IDENT_NBR = "183555";
        private static final String GULF_IDENT_NBR = "101903780";
        private static final String C000000000000001 = "000000000000001";
        private static final String C000000000000 = "000000000000";
        private static final String ADDENDA_COUNT = "000001";
        private static final String HASH_COUNT = "0010100001";
        private static final String ZERO = "0";

        private static final DateFormat FORMAT_YYYYMMDD = new DateFormat("yyyyMMdd");
        private static final DateFormat FORMAT_MMDDYY = new DateFormat("MMddyy");
        private static final DateFormat FORMAT_MMDDYY_WITH_SLASH = new DateFormat("MM/dd/yy");
        private static final DateFormat FORMAT_YYMMDD = new DateFormat("yyMMdd");
        private static final DateFormat FORMAT_HHMMSS = new DateFormat("hh:mm:ss");
        private static final DateFormat FORMAT_HHMM = new DateFormat("hhmm");
        private static final DateFormat FORMAT_HH = new DateFormat("hh");
        private static final DateFormat FORMAT_MM = new DateFormat("mm");

        // Constants
        private static final String XACP_FEAT_CONFG = "CM_ADJCHPRM";


        public ThreadExecutionStrategy createExecutionStrategy() {
            return new SingleTransactionStrategy(this);
        }

        public void initializeThreadWork(
                boolean initializationPreviouslySuccessful){

        	// Retrieve Batch Parameters
            parmFilePath = getParameters().getFILE_PATH();
            parmMissouriEp1FileName = getParameters().getMISSOURI_EP1_FILENAME();
            parmMissouriEpcFileName = getParameters().getMISSOURI_EPC_FILENAME();
            parmAlabamaEp1FileName = getParameters().getALABAMA_EP1_FILENAME();
            parmAlabamaEpcFileName = getParameters().getALABAMA_EPC_FILENAME();
            parmAlabamaAchFileName = getParameters().getALABAMA_ACH_FILENAME();
            parmGulfEp1FileName = getParameters().getGULF_EP1_FILENAME();
            parmGulfEpcFileName = getParameters().getGULF_EPC_FILENAME();
            parmGulfAchFileName = getParameters().getGULF_ACH_FILENAME();

            initializeMoFiles = 0;
            initializeAlFiles = 0;
            initializeGlFiles = 0;

            // Retrieve Company Codes
            companyCodeCharType = new CharacteristicType_Id(CM_COMP_CHAR_TYPE).getEntity();

            CisDivision cisDivision = new CisDivision_Id(CIS_DIVISION_LGC).getEntity();
            CisDivisionCharacteristic companyCodeChar = cisDivision.getEffectiveCharacteristic(companyCodeCharType);
            lgcCompanyCode = companyCodeChar.getCharacteristicValue().trim();

            cisDivision = new CisDivision_Id(CIS_DIVISION_MGE).getEntity();
            companyCodeChar = cisDivision.getEffectiveCharacteristic(companyCodeCharType);
            mgeCompanyCode = companyCodeChar.getCharacteristicValue().trim();

            cisDivision = new CisDivision_Id(CIS_DIVISION_AL).getEntity();
            companyCodeChar = cisDivision.getEffectiveCharacteristic(companyCodeCharType);
            alCompanyCode = companyCodeChar.getCharacteristicValue().trim();

            cisDivision = new CisDivision_Id(CIS_DIVISION_GL).getEntity();
            companyCodeChar = cisDivision.getEffectiveCharacteristic(companyCodeCharType);
            glCompanyCode = companyCodeChar.getCharacteristicValue().trim();

            // Create Files
            ep1FileMissouri = new File(parmFilePath, parmMissouriEp1FileName + FILE_EXT_EP1);
            epcFileMissouri = new File(parmFilePath, parmMissouriEpcFileName + FILE_EXT_EPC);

            ep1FileAlabama = new File(parmFilePath, parmAlabamaEp1FileName + FILE_EXT_EP1);
            epcFileAlabama = new File(parmFilePath, parmAlabamaEpcFileName + FILE_EXT_EPC);
            achFileAlabama = new File(parmFilePath, parmAlabamaAchFileName + FILE_EXT_ACH);

            ep1FileGulf = new File(parmFilePath, parmGulfEp1FileName + FILE_EXT_EP1);
            epcFileGulf = new File(parmFilePath, parmGulfEpcFileName + FILE_EXT_EPC);
            achFileGulf = new File(parmFilePath, parmGulfAchFileName + FILE_EXT_ACH);

            // Initialize Records
            mEP1FileHeader = new CmCheckExtractFileHeaderRecord();
            mEP1BatchHeader = new CmCheckExtractBatchHeaderRecord();
            mEP1ReturnAddress = new CmCheckExtractReturnAddressRecord();
            mEP1OriginBanking = new CmCheckExtractOriginBankingRecord();
            mEP1TransactionHeader = new CmCheckExtractTransactionHeaderRecord();
            mEP1PaymentHeader = new CmCheckExtractPaymentHeaderRecord();
            mEP1PaymentDetail = new CmCheckExtractPaymentDetailRecord();
            mEP1BatchControlTotal = new CmCheckExtractBatchControlTotalRecord();
            mEP1FileTrailer = new CmCheckExtractFileTrailerRecord();

            aEP1FileHeader = new CmCheckExtractFileHeaderRecord();
            aEP1BatchHeader = new CmCheckExtractBatchHeaderRecord();
            aEP1ReturnAddress = new CmCheckExtractReturnAddressRecord();
            aEP1OriginBanking = new CmCheckExtractOriginBankingRecord();
            aEP1TransactionHeader = new CmCheckExtractTransactionHeaderRecord();
            aEP1PaymentHeader = new CmCheckExtractPaymentHeaderRecord();
            aEP1PaymentDetail = new CmCheckExtractPaymentDetailRecord();
            aEP1BatchControlTotal = new CmCheckExtractBatchControlTotalRecord();
            aEP1FileTrailer = new CmCheckExtractFileTrailerRecord();
            aACHFileHeader = new CmCheckExtractACHFileHeaderRecord();
            aACHBatchHeader = new CmCheckExtractACHBatchHeaderRecord();
            aACHPPDEntryDetail = new CmCheckExtractACHPPDEntryDetailRecord();
            aACHBatchControl = new CmCheckExtractACHBatchControlRecord();
            aACHFileControl = new CmCheckExtractACHFileControlRecord();

            gEP1FileHeader = new CmCheckExtractFileHeaderRecord();
            gEP1BatchHeader = new CmCheckExtractBatchHeaderRecord();
            gEP1ReturnAddress = new CmCheckExtractReturnAddressRecord();
            gEP1OriginBanking = new CmCheckExtractOriginBankingRecord();
            gEP1TransactionHeader = new CmCheckExtractTransactionHeaderRecord();
            gEP1PaymentHeader = new CmCheckExtractPaymentHeaderRecord();
            gEP1PaymentDetail = new CmCheckExtractPaymentDetailRecord();
            gEP1BatchControlTotal = new CmCheckExtractBatchControlTotalRecord();
            gEP1FileTrailer = new CmCheckExtractFileTrailerRecord();
            gACHFileHeader = new CmCheckExtractACHFileHeaderRecord();
            gACHBatchHeader = new CmCheckExtractACHBatchHeaderRecord();
            gACHPPDEntryDetail = new CmCheckExtractACHPPDEntryDetailRecord();
            gACHBatchControl = new CmCheckExtractACHBatchControlRecord();
            gACHFileControl = new CmCheckExtractACHFileControlRecord();

            mNumberOfChecks = 0;
            mTotalCheckAmount = BigDecimal.ZERO;
            mNumberOfLines = 0;
            aNumberOfChecks = 0;
            aTotalCheckAmount = BigDecimal.ZERO;
            aNumberOfLines = 0;
            gNumberOfChecks = 0;
            gTotalCheckAmount = BigDecimal.ZERO;
            gNumberOfLines = 0;
        }

        private void retrieveAddressVariables(){
        	CmFeatureConfigurationRetriever_Impl featConfigRetriever = new CmFeatureConfigurationRetriever_Impl();
    		FeatureConfiguration_Id featConfigId = new FeatureConfiguration_Id(XACP_FEAT_CONFG);
    		featConfigRetriever.setParmWFMName(featConfigId.getEntity());

    		// Retrieve and validate MO values from Feature configuration
    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_MO_RETURN_ADDRESS_NAME.value());
    		SPIRE_INC = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(SPIRE_INC)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Missouri - Return Address Name"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_MO_RETURN_ADDRESS_1.value());
    		CUSTOMER_EXPERIENCE = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(CUSTOMER_EXPERIENCE)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Missouri - Return Address 1"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_MO_RETURN_ADDRESS_2.value());
    		C700_MARKET = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(C700_MARKET)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Missouri - Return Address 2"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_MO_RETURN_ADDRESS_3.value());
    		ADDRESS3 = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		/*if (isBlankOrNull(ADDRESS3)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Missouri - Return Address 3"));
    		}*/

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_MO_RETURN_CSZ_CODE.value());
    		CSZC_CODE = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(CSZC_CODE)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Missouri - Return Csz Code"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_MO_CITY.value());
    		SAINT_LOUIS = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(SAINT_LOUIS)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Missouri - City"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_MO_STATE.value());
    		MO_RA = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(MO_RA)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Missouri - State"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_MO_ZIP_CODE.value());
    		MO_ZIP = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(MO_ZIP)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Missouri - Zip Code"));
    		}

    		// Retrieve and validate AL values from Feature configuration
    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_AL_RETURN_ADDRESS_NAME.value());
    		SPIRE_ALABAMA_INC_RA = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(SPIRE_ALABAMA_INC_RA)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Alabama - Return Address Name"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_AL_RETURN_ADDRESS_1.value());
    		CUSTOMER_EXPERIENCE_AL = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(CUSTOMER_EXPERIENCE_AL)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Alabama - Return Address 1"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_AL_RETURN_ADDRESS_2.value());
    		C2101_6TH_AVENUE_NORTH = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(C2101_6TH_AVENUE_NORTH)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Alabama - Return Address 2"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_AL_RETURN_ADDRESS_3.value());
    		ADDRESS3_AL = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		/*if (isBlankOrNull(ADDRESS3_AL)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Alabama - Return Address 3"));
    		}*/

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_AL_RETURN_CSZ_CODE.value());
    		CSZC_CODE_AL = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(CSZC_CODE_AL)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Alabama - Return Csz Code"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_AL_CITY.value());
    		BIRMINGHAM = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(BIRMINGHAM)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Alabama - City"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_AL_STATE.value());
    		AL_RA = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(AL_RA)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Alabama - State"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_AL_ZIP_CODE.value());
    		AL_ZIP_RA = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(AL_ZIP_RA)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Alabama - Zip Code"));
    		}

    		// Retrieve and validate Gulf values from Feature configuration
    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_GF_RETURN_ADDRESS_NAME.value());
    		SPIRE_ALABAMA_INC_GF_RA = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(SPIRE_ALABAMA_INC_GF_RA)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Gulf - Return Address Name"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_GF_RETURN_ADDRESS_1.value());
    		CUSTOMER_EXPERIENCE_GF = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(CUSTOMER_EXPERIENCE_GF)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Gulf - Return Address 1"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_GF_RETURN_ADDRESS_2.value());
    		C2101_6TH_AVENUE_NORTH_GF = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(C2101_6TH_AVENUE_NORTH_GF)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Gulf - Return Address 2"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_GF_RETURN_ADDRESS_3.value());
    		ADDRESS3_GF = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		/*if (isBlankOrNull(ADDRESS3_GF)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Gulf - Return Address 3"));
    		}*/

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_GF_CSZ_CODE.value());
    		CSZC_CODE_GF = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(CSZC_CODE_GF)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Gulf - Return Csz Code"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_GF_CITY.value());
    		BIRMINGHAM_GF = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(BIRMINGHAM_GF)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Gulf - City"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_GF_STATE.value());
    		GF_RA = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(AL_RA)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Gulf - State"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_GF_ZIP_CODE.value());
    		GF_ZIP_RA = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(AL_ZIP_RA)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Gulf - Zip Code"));
    		}

    		//Bank Details
    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_MO_BANK_ACCOUNT_NO.value());
    		SPIRE_ACCT_NO_MO = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(SPIRE_ACCT_NO_MO)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Missouri Bank Account Number"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_AL_BANK_ACCOUNT_NO.value());
    		SPIRE_ACCT_NO_AL = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(SPIRE_ACCT_NO_AL)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Alabama Bank Account Number"));
    		}

    		featConfigRetriever.setParmOptType(CmAdjCharChandlerParmLookup.constants.CM_GF_BANK_ACCOUNT_NO.value());
    		SPIRE_ACCT_NO_GF = featConfigRetriever.getMaxSequenceOptionValue().trim();
    		if (isBlankOrNull(SPIRE_ACCT_NO_GF)){
    			addError(CustomMessageRepositorySpireOne.CCB041_3_fcOptionMissing(XACP_FEAT_CONFG, "Gulf Bank Account Number"));
    		}

        }


        private void initializeMissouriFiles(){
        	try {

        		bwEP1Missouri = new BufferedWriter(new FileWriter(ep1FileMissouri));
        		mEP1FileHeader.setHRVald(HRVALD);
        		mEP1FileHeader.setFileGenerationDate(getSystemDateTime().getDate().toString(FORMAT_YYYYMMDD));
        		mEP1FileHeader.setFileGenerationTimestamp(getSystemDateTime().getTime().toString(FORMAT_HHMMSS));
        		bwEP1Missouri.write(mEP1FileHeader.createRecordString());
        		bwEP1Missouri.newLine();
        		mNumberOfLines++;

        		mEP1BatchHeader.setRecordType(RECORD_TYPE_EP1_BATCH_HEADER);
        		mEP1BatchHeader.setDisbursementSiteId(BLANK);
        		mEP1BatchHeader.setOriginName(SPIRE_MISSOURI_INC);
        		mEP1BatchHeader.setTransmissionDate(getSystemDateTime().getDate().toString(FORMAT_MMDDYY));
        		mEP1BatchHeader.setTransmissionTimeHH(getSystemDateTime().getTime().toString(FORMAT_HH));
        		mEP1BatchHeader.setTransmissionTimeMM(getSystemDateTime().getTime().toString(FORMAT_MM));
        		mEP1BatchHeader.setControlNumber(getBatchNumber().toString(), getBatchRerunNumber().toString());
        		mEP1BatchHeader.setPMTFormateCode(C2090);
        		mEP1BatchHeader.setPOSPayIndicator(YES);
        		mEP1BatchHeader.setSpecialProcessing(BLANK);
        		bwEP1Missouri.write(mEP1BatchHeader.createRecordString());
        		bwEP1Missouri.newLine();
        		mNumberOfLines++;

        		mEP1ReturnAddress.setRecordType(RECORD_TYPE_EP1_RETURN_ADDRESS);
        		mEP1ReturnAddress.setReturnAddressName(SPIRE_INC);//
        		mEP1ReturnAddress.setReturnAddress1(CUSTOMER_EXPERIENCE);//
        		mEP1ReturnAddress.setReturnAddress2(C700_MARKET);//
        		mEP1ReturnAddress.setReturnAddress3(ADDRESS3);//
        		mEP1ReturnAddress.setReturnCszcCode(CSZC_CODE);//
        		mEP1ReturnAddress.setCity(SAINT_LOUIS);//
        		mEP1ReturnAddress.setState(MO_RA);//
        		mEP1ReturnAddress.setZipCode(MO_ZIP);//MO, AL, GF
        		mEP1ReturnAddress.setReturnCountryCode(BLANK);
        		bwEP1Missouri.write(mEP1ReturnAddress.createRecordString());
        		bwEP1Missouri.newLine();
        		mNumberOfLines++;

        		mEP1OriginBanking.setRecordType(RECORD_TYPE_EP1_ORIGIN_BANKING);
        		mEP1OriginBanking.setSenderId(BLANK);
        		mEP1OriginBanking.setUserId(BLANK);
        		mEP1OriginBanking.setAbaNumber(MO_ABA_NUMBER);
        		mEP1OriginBanking.setCustomerName(COMMERCE_BANK);
        		mEP1OriginBanking.setCustomerFederalTaxId(COMMERCE_BANK_FED_TAX_ID);
        		mEP1OriginBanking.setFileSequenceId(C1);
        		mEP1OriginBanking.setAccountNumberQual(BLANK);
        		mEP1OriginBanking.setAccountNumber(SPIRE_ACCT_NO_MO);
        		mEP1OriginBanking.setDiscretionaryData(BLANK);
        		mEP1OriginBanking.setDescriptionDate(BLANK);
        		mEP1OriginBanking.setPaymentsDescription(BLANK);;
        		mEP1OriginBanking.setBankName(COMMERCE_BANK);
        		mEP1OriginBanking.setAddress1(C8000_FORSYTH);
        		mEP1OriginBanking.setCity(CLAYTON);
        		mEP1OriginBanking.setState(MO);
        		mEP1OriginBanking.setPostCode(ODFI_POSTAL);
        		mEP1OriginBanking.setCountry(BLANK);
        		mEP1OriginBanking.setFractionalRoutingCode(ODFI_BANK_FRAC);
        		mEP1OriginBanking.setStaleDateMessage(BLANK);
        		bwEP1Missouri.write(mEP1OriginBanking.createRecordString());
        		bwEP1Missouri.newLine();
        		mNumberOfLines++;

        		mEP1TransactionHeader.setRecordType(RECORD_TYPE_EP1_TRANSACTION_HEADER);
        		mEP1TransactionHeader.setTransactionHeader1(REFERENCE_NO);;
        		mEP1TransactionHeader.setTransactionHeader2(ACCOUNT_NO);
        		mEP1TransactionHeader.setTransactionHeader3(DESCRIPTION);
        		mEP1TransactionHeader.setTransactionHeader4(AMOUNT);
        		mEP1TransactionHeader.setTransactionHeader5(BLANK);
        		mEP1TransactionHeader.setTransactionHeader6(BLANK);
        		mEP1TransactionHeader.setTransactionHeader7(BLANK);
        		mEP1TransactionHeader.setTransactionHeader8(BLANK);
        		mEP1TransactionHeader.setSignatureCode1(C2091_1);
        		mEP1TransactionHeader.setSignatureCode2(BLANK);
        		mEP1TransactionHeader.setStubLogoCode(BLANK);
        		mEP1TransactionHeader.setCheckLogoCode(BLANK);
        		bwEP1Missouri.write(mEP1TransactionHeader.createRecordString());
        		bwEP1Missouri.newLine();
        		mNumberOfLines++;

        	} catch (IOException e) {
        		addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileWriting(e.getMessage()));
        		e.printStackTrace();
        	}
        }

        private void initializeAlabamaFiles(){
        	try {
        		bwEP1Alabama = new BufferedWriter(new FileWriter(ep1FileAlabama));

        		aEP1FileHeader.setHRVald(HRVALD);
        		aEP1FileHeader.setFileGenerationDate(getSystemDateTime().getDate().toString(FORMAT_YYYYMMDD));
        		aEP1FileHeader.setFileGenerationTimestamp(getSystemDateTime().getTime().toString(FORMAT_HHMMSS));
        		bwEP1Alabama.write(aEP1FileHeader.createRecordString());
        		bwEP1Alabama.newLine();
        		aNumberOfLines++;

        		aEP1BatchHeader.setRecordType(RECORD_TYPE_EP1_BATCH_HEADER);
        		aEP1BatchHeader.setDisbursementSiteId(BLANK);
        		aEP1BatchHeader.setOriginName(SPIRE_ALABAMA_INC);
        		aEP1BatchHeader.setTransmissionDate(getSystemDateTime().getDate().toString(FORMAT_MMDDYY));
        		aEP1BatchHeader.setTransmissionTimeHH(getSystemDateTime().getTime().toString(FORMAT_HH));
        		aEP1BatchHeader.setTransmissionTimeMM(getSystemDateTime().getTime().toString(FORMAT_MM));
        		aEP1BatchHeader.setControlNumber(getBatchNumber().toString(), getBatchRerunNumber().toString());
        		aEP1BatchHeader.setPMTFormateCode(C2090);
        		aEP1BatchHeader.setPOSPayIndicator(YES);
        		aEP1BatchHeader.setSpecialProcessing(BLANK);
        		bwEP1Alabama.write(aEP1BatchHeader.createRecordString());
        		bwEP1Alabama.newLine();
        		aNumberOfLines++;

        		aEP1ReturnAddress.setRecordType(RECORD_TYPE_EP1_RETURN_ADDRESS);
        		aEP1ReturnAddress.setReturnAddressName(SPIRE_ALABAMA_INC_RA);
        		aEP1ReturnAddress.setReturnAddress1(CUSTOMER_EXPERIENCE_AL);
        		aEP1ReturnAddress.setReturnAddress2(C2101_6TH_AVENUE_NORTH);
        		aEP1ReturnAddress.setReturnAddress3(ADDRESS3_AL);
        		aEP1ReturnAddress.setReturnCszcCode(CSZC_CODE_AL);
        		aEP1ReturnAddress.setCity(BIRMINGHAM);
        		aEP1ReturnAddress.setState(AL_RA);
        		aEP1ReturnAddress.setZipCode(AL_ZIP_RA);
        		aEP1ReturnAddress.setReturnCountryCode(BLANK);
        		bwEP1Alabama.write(aEP1ReturnAddress.createRecordString());
        		bwEP1Alabama.newLine();
        		aNumberOfLines++;

        		aEP1OriginBanking.setRecordType(RECORD_TYPE_EP1_ORIGIN_BANKING);
        		aEP1OriginBanking.setSenderId(BLANK);
        		aEP1OriginBanking.setUserId(BLANK);
        		aEP1OriginBanking.setAbaNumber(ABA_NUMBER);
        		aEP1OriginBanking.setCustomerName(COMMERCE_BANK);
        		aEP1OriginBanking.setCustomerFederalTaxId(COMMERCE_BANK_FED_TAX_ID);
        		aEP1OriginBanking.setFileSequenceId(C1);
        		aEP1OriginBanking.setAccountNumberQual(BLANK);
        		aEP1OriginBanking.setAccountNumber(SPIRE_ACCT_NO_AL);
        		aEP1OriginBanking.setDiscretionaryData(BLANK);
        		aEP1OriginBanking.setDescriptionDate(BLANK);
        		aEP1OriginBanking.setPaymentsDescription(BLANK);;
        		aEP1OriginBanking.setBankName(COMMERCE_BANK);
        		aEP1OriginBanking.setAddress1(C8000_FORSYTH);
        		aEP1OriginBanking.setCity(CLAYTON);
        		aEP1OriginBanking.setState(MO);
        		aEP1OriginBanking.setPostCode(ODFI_POSTAL);
        		aEP1OriginBanking.setCountry(BLANK);
        		aEP1OriginBanking.setFractionalRoutingCode(ODFI_BANK_FRAC);
        		aEP1OriginBanking.setStaleDateMessage(BLANK);
        		bwEP1Alabama.write(aEP1OriginBanking.createRecordString());
        		bwEP1Alabama.newLine();
        		aNumberOfLines++;

        		aEP1TransactionHeader.setRecordType(RECORD_TYPE_EP1_TRANSACTION_HEADER);
        		aEP1TransactionHeader.setTransactionHeader1(REFERENCE_NO);;
        		aEP1TransactionHeader.setTransactionHeader2(ACCOUNT_NO);
        		aEP1TransactionHeader.setTransactionHeader3(DESCRIPTION);
        		aEP1TransactionHeader.setTransactionHeader4(AMOUNT);
        		aEP1TransactionHeader.setTransactionHeader5(BLANK);
        		aEP1TransactionHeader.setTransactionHeader6(BLANK);
        		aEP1TransactionHeader.setTransactionHeader7(BLANK);
        		aEP1TransactionHeader.setTransactionHeader8(BLANK);
        		aEP1TransactionHeader.setSignatureCode1(C2091_1);
        		aEP1TransactionHeader.setSignatureCode2(BLANK);
        		aEP1TransactionHeader.setStubLogoCode(BLANK);
        		aEP1TransactionHeader.setCheckLogoCode(BLANK);
        		bwEP1Alabama.write(aEP1TransactionHeader.createRecordString());
        		bwEP1Alabama.newLine();
        		aNumberOfLines++;

        	} catch (IOException e) {
        		addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileWriting(e.getMessage()));
        		e.printStackTrace();
        	}
        }

        private void initializeGulfFiles(){
        	try {
        		bwEP1Gulf = new BufferedWriter(new FileWriter(ep1FileGulf));

        		gEP1FileHeader.setHRVald(HRVALD);
        		gEP1FileHeader.setFileGenerationDate(getSystemDateTime().getDate().toString(FORMAT_YYYYMMDD));
        		gEP1FileHeader.setFileGenerationTimestamp(getSystemDateTime().getTime().toString(FORMAT_HHMMSS));
        		bwEP1Gulf.write(gEP1FileHeader.createRecordString());
        		bwEP1Gulf.newLine();
        		gNumberOfLines++;

        		gEP1BatchHeader.setRecordType(RECORD_TYPE_EP1_BATCH_HEADER);
        		gEP1BatchHeader.setDisbursementSiteId(BLANK);
        		gEP1BatchHeader.setOriginName(SPIRE_GULF_INC);
        		gEP1BatchHeader.setTransmissionDate(getSystemDateTime().getDate().toString(FORMAT_MMDDYY));
        		gEP1BatchHeader.setTransmissionTimeHH(getSystemDateTime().getTime().toString(FORMAT_HH));
        		gEP1BatchHeader.setTransmissionTimeMM(getSystemDateTime().getTime().toString(FORMAT_MM));
        		gEP1BatchHeader.setControlNumber(getBatchNumber().toString(), getBatchRerunNumber().toString());
        		gEP1BatchHeader.setPMTFormateCode(C2090);
        		gEP1BatchHeader.setPOSPayIndicator(YES);
        		gEP1BatchHeader.setSpecialProcessing(BLANK);
        		bwEP1Gulf.write(gEP1BatchHeader.createRecordString());
        		bwEP1Gulf.newLine();
        		gNumberOfLines++;

        		gEP1ReturnAddress.setRecordType(RECORD_TYPE_EP1_RETURN_ADDRESS);
        		gEP1ReturnAddress.setReturnAddressName(SPIRE_ALABAMA_INC_GF_RA);
        		gEP1ReturnAddress.setReturnAddress1(CUSTOMER_EXPERIENCE);
        		gEP1ReturnAddress.setReturnAddress2(C2101_6TH_AVENUE_NORTH_GF);
        		gEP1ReturnAddress.setReturnAddress3(ADDRESS3_GF);
        		gEP1ReturnAddress.setReturnCszcCode(CSZC_CODE_GF);
        		gEP1ReturnAddress.setCity(BIRMINGHAM_GF);
        		gEP1ReturnAddress.setState(GF_RA);
        		gEP1ReturnAddress.setZipCode(GF_ZIP_RA);
        		gEP1ReturnAddress.setReturnCountryCode(BLANK);
        		bwEP1Gulf.write(gEP1ReturnAddress.createRecordString());
        		bwEP1Gulf.newLine();
        		gNumberOfLines++;

        		gEP1OriginBanking.setRecordType(RECORD_TYPE_EP1_ORIGIN_BANKING);
        		gEP1OriginBanking.setSenderId(BLANK);
        		gEP1OriginBanking.setUserId(BLANK);
        		gEP1OriginBanking.setAbaNumber(ABA_NUMBER);
        		gEP1OriginBanking.setCustomerName(COMMERCE_BANK);
        		gEP1OriginBanking.setCustomerFederalTaxId(COMMERCE_BANK_FED_TAX_ID);
        		gEP1OriginBanking.setFileSequenceId(C1);
        		gEP1OriginBanking.setAccountNumberQual(BLANK);
        		gEP1OriginBanking.setAccountNumber(SPIRE_ACCT_NO_GF);
        		gEP1OriginBanking.setDiscretionaryData(BLANK);
        		gEP1OriginBanking.setDescriptionDate(BLANK);
        		gEP1OriginBanking.setPaymentsDescription(BLANK);;
        		gEP1OriginBanking.setBankName(COMMERCE_BANK);
        		gEP1OriginBanking.setAddress1(C8000_FORSYTH);
        		gEP1OriginBanking.setCity(CLAYTON);
        		gEP1OriginBanking.setState(MO);
        		gEP1OriginBanking.setPostCode(ODFI_POSTAL);
        		gEP1OriginBanking.setCountry(BLANK);
        		gEP1OriginBanking.setFractionalRoutingCode(ODFI_BANK_FRAC);
        		gEP1OriginBanking.setStaleDateMessage(BLANK);
        		bwEP1Gulf.write(gEP1OriginBanking.createRecordString());
        		bwEP1Gulf.newLine();
        		gNumberOfLines++;

        		gEP1TransactionHeader.setRecordType(RECORD_TYPE_EP1_TRANSACTION_HEADER);
        		gEP1TransactionHeader.setTransactionHeader1(REFERENCE_NO);;
        		gEP1TransactionHeader.setTransactionHeader2(ACCOUNT_NO);
        		gEP1TransactionHeader.setTransactionHeader3(DESCRIPTION);
        		gEP1TransactionHeader.setTransactionHeader4(AMOUNT);
        		gEP1TransactionHeader.setTransactionHeader5(BLANK);
        		gEP1TransactionHeader.setTransactionHeader6(BLANK);
        		gEP1TransactionHeader.setTransactionHeader7(BLANK);
        		gEP1TransactionHeader.setTransactionHeader8(BLANK);
        		gEP1TransactionHeader.setSignatureCode1(C2091_1);
        		gEP1TransactionHeader.setSignatureCode2(BLANK);
        		gEP1TransactionHeader.setStubLogoCode(BLANK);
        		gEP1TransactionHeader.setCheckLogoCode(BLANK);
        		bwEP1Gulf.write(gEP1TransactionHeader.createRecordString());
        		bwEP1Gulf.newLine();
        		gNumberOfLines++;

        	} catch (IOException e) {
        		addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileWriting(e.getMessage()));
        		e.printStackTrace();
        	}
        }


        public boolean executeWorkUnit(ThreadWorkUnit threadWorkUnit)
                throws ThreadAbortedException, RunAbortedException {

            ApCheckRequest_Id apRequestId = (ApCheckRequest_Id) threadWorkUnit.getPrimaryId();
            ApCheckRequest apRequest = apRequestId.getEntity();

            CisDivision_Id cisDivisionId = (CisDivision_Id) threadWorkUnit.getSupplementallData("CISDIVISION");
            BigDecimal adjustmentAmount = apRequest.getAdjustmentId().getEntity().getCurrentAmount().getAmount();

            retrieveAddressVariables();
            if (cisDivisionId.getTrimmedValue().equalsIgnoreCase(CIS_DIVISION_LGC)
                    || cisDivisionId.getTrimmedValue().equalsIgnoreCase(CIS_DIVISION_MGE)){

            	initializeMoFiles++;
            	if (initializeMoFiles == 1){
            		initializeMissouriFiles();
            	}

                try{
                    mEP1PaymentHeader.setRecordType(RECORD_TYPE_EP1_PAYMENT_HEADER);
                    mEP1PaymentHeader.setProcessCode(NOR);
                    mEP1PaymentHeader.setPayMethod(PBC);
                    mEP1PaymentHeader.setRmtMethod(CHK);
                    mEP1PaymentHeader.setCheckEftOrgDate(apRequest.getScheduledToPayDate().toString(FORMAT_MMDDYY));
                    mEP1PaymentHeader.setPaymentAmount(adjustmentAmount.toString());

                    String paddedCheckNumber = "";
                    if (cisDivisionId.getTrimmedValue().equalsIgnoreCase(CIS_DIVISION_LGC)){
                    	checkNumber = getNextCheckNumberSequence("CM_LGC_CHECK_NUMBER_SEQ");
                    	paddedCheckNumber = lgcCompanyCode + padLeftZeros(checkNumber.toString(), 7);
                    }
                    else {
                    	checkNumber = getNextCheckNumberSequence("CM_MGE_CHECK_NUMBER_SEQ");
                    	paddedCheckNumber = mgeCompanyCode + padLeftZeros(checkNumber.toString(), 7);
                    }
                    mEP1PaymentHeader.setReferenceNumber(paddedCheckNumber);

                    mEP1PaymentHeader.setPayeeName(apRequest.getEntityName());
                    //Start Change - DLampa - 2023-11-10 - E-08140
                    //mEP1PaymentHeader.setPayeeAddress1(StringUtilities.camelCaseToWords(StringUtilities.wordsToCamelCase(apRequest.getAddress1())));
                    String houseNumber = apRequest.getAddress1().substring(0, apRequest.getAddress1().indexOf(' ') + 1);
                    mEP1PaymentHeader.setPayeeAddress1(houseNumber.concat(StringUtilities.camelCaseToWords(StringUtilities.wordsToCamelCase(apRequest.getAddress1().substring(apRequest.getAddress1().indexOf(' ') + 1, apRequest.getAddress1().length())))));
                    //End Change - DLampa - 2023-11-10 - E-08140
                    mEP1PaymentHeader.setPayeeCszcCode(S);
                    mEP1PaymentHeader.setPayeeCity(StringUtilities.camelCaseToWords(StringUtilities.wordsToCamelCase(apRequest.getCity())));
                    mEP1PaymentHeader.setPayeeState(apRequest.getState().trim());
                    //Start Change - JLumbre - 2021-07-26
                    //mEP1PaymentHeader.setPayeePostal(apRequest.getPostal().replaceAll(" ",""));
                    mEP1PaymentHeader.setPayeePostal(apRequest.getPostal().replaceAll("-","").trim());
                    //End Change - JLumbre - 2021-07-26
                    mEP1PaymentHeader.setPayeeCountryCode(BLANK);
                    mEP1PaymentHeader.setNumberOfInvoicesPaid(ZERO);
                    mEP1PaymentHeader.setPOSPaymentReferenceNumber(BLANK);
                    mEP1PaymentHeader.setAccountReference(BLANK);
                    mEP1PaymentHeader.setNextFieldQualifier(ADR);
                    mEP1PaymentHeader.setQualifiedField(BLANK);
                    mEP1PaymentHeader.setPayeeExtraAddress(BLANK);
                    mEP1PaymentHeader.setRunCode1(YES);
                    mEP1PaymentHeader.setInquiryTelephoneNumber(BLANK);
                    mEP1PaymentHeader.setSpecialBatchNumber(BLANK);
                    mEP1PaymentHeader.setDocumentId(BLANK);
                    mEP1PaymentHeader.setReceivedABA(BLANK);
                    mEP1PaymentHeader.setReceivedAccount(BLANK);
                    mEP1PaymentHeader.setPaymentGUID(paddedCheckNumber);
                    mEP1PaymentHeader.setPayeeCountryName(BLANK);
                    bwEP1Missouri.write(mEP1PaymentHeader.createRecordString());
                    bwEP1Missouri.newLine();
                    mNumberOfLines++;

                    mEP1PaymentDetail.setRecordType(RECORD_TYPE_EP1_PAYMENT_DETAIL);
                    //Start Change - JLumbre - 2021-07-26
                    //mEP1PaymentDetail.setVoucherNumber(apRequest.getAdjustmentId().getEntity().getServiceAgreement().getAccount().getId().getTrimmedValue());
                    //mEP1PaymentDetail.setInvoiceNumber(NOT_APPLICABLE);
                    mEP1PaymentDetail.setVoucherNumber(apRequest.getAdjustmentId().getTrimmedValue());
                    mEP1PaymentDetail.setInvoiceNumber(apRequest.getAdjustmentId().getEntity().getServiceAgreement().getAccount().getId().getTrimmedValue());
                    //End Change - JLumbre - 2021-07-26
                    mEP1PaymentDetail.setGrossAmount(adjustmentAmount.toString());
                    mEP1PaymentDetail.setNetAmount(BLANK);
                    mEP1PaymentDetail.setDiscount(BLANK);
                    mEP1PaymentDetail.setInvoiceDate(BLANK);
                    mEP1PaymentDetail.setAdjustmentReasonText(CREDIT_BALANCE_REFUND);
                    mEP1PaymentDetail.setEntityId(BLANK);
                    mEP1PaymentDetail.setEntityName(BLANK);
                    mEP1PaymentDetail.setRemitAccountNumber(BLANK);
                    mEP1PaymentDetail.setSystemReference(BLANK);
                    mEP1PaymentDetail.setMiscRemittanceReference(BLANK);
                    mEP1PaymentDetail.setInvoiceDueDate(BLANK);
                    bwEP1Missouri.write(mEP1PaymentDetail.createRecordString());
                    bwEP1Missouri.newLine();
                    mNumberOfLines++;

                    mTotalCheckAmount = mTotalCheckAmount.add(adjustmentAmount);
                    mNumberOfChecks++;

                    // Update A/P Request Status
                    ApCheckRequest_DTO apRequestDto = apRequest.getDTO();
                    apRequestDto.setPaymentSelectionStatus(PaymentSelectionStatusLookup.constants.REQUESTED_FOR_PAYMENT);
                    apRequestDto.setPaymentNumber(paddedCheckNumber);
                    apRequest.setDTO(apRequestDto);

                } catch (IOException e) {
                    addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileWriting(e.getMessage()));
                    e.printStackTrace();
                }


            }
            else if (cisDivisionId.getTrimmedValue().equalsIgnoreCase(CIS_DIVISION_AL)){

            	initializeAlFiles++;
            	if (initializeAlFiles == 1){
            		initializeAlabamaFiles();
            	}

                try{
                    aEP1PaymentHeader.setRecordType(RECORD_TYPE_EP1_PAYMENT_HEADER);
                    aEP1PaymentHeader.setProcessCode(NOR);
                    aEP1PaymentHeader.setPayMethod(PBC);
                    aEP1PaymentHeader.setRmtMethod(CHK);
                    aEP1PaymentHeader.setCheckEftOrgDate(apRequest.getScheduledToPayDate().toString(FORMAT_MMDDYY));
                    aEP1PaymentHeader.setPaymentAmount(adjustmentAmount.toString());

                 	checkNumber = getNextCheckNumberSequence("CM_AL_CHECK_NUMBER_SEQ");
                 	String paddedCheckNumber = alCompanyCode + padLeftZeros(checkNumber.toString(), 7);
                    aEP1PaymentHeader.setReferenceNumber(paddedCheckNumber);

                    aEP1PaymentHeader.setPayeeName(apRequest.getEntityName());
                    //Start Change - DLampa - 2023-11-10 - E-08140
                    //aEP1PaymentHeader.setPayeeAddress1(StringUtilities.camelCaseToWords(StringUtilities.wordsToCamelCase(apRequest.getAddress1())));
                    String houseNumber = apRequest.getAddress1().substring(0, apRequest.getAddress1().indexOf(' ') + 1);
                    aEP1PaymentHeader.setPayeeAddress1(houseNumber.concat(StringUtilities.camelCaseToWords(StringUtilities.wordsToCamelCase(apRequest.getAddress1().substring(apRequest.getAddress1().indexOf(' ') + 1, apRequest.getAddress1().length())))));
                    //End Change - DLampa - 2023-11-10 - E-08140
                    aEP1PaymentHeader.setPayeeCszcCode(S);
                    aEP1PaymentHeader.setPayeeCity(StringUtilities.camelCaseToWords(StringUtilities.wordsToCamelCase(apRequest.getCity())));
                    aEP1PaymentHeader.setPayeeState(apRequest.getState().trim());
                    //Start Change - JLumbre - 2021-07-26
                    //aEP1PaymentHeader.setPayeePostal(apRequest.getPostal().replaceAll(" ",""));
                    aEP1PaymentHeader.setPayeePostal(apRequest.getPostal().replaceAll("-","").trim());
                    //End Change - JLumbre - 2021-07-26
                    aEP1PaymentHeader.setPayeeCountryCode(BLANK);
                    aEP1PaymentHeader.setNumberOfInvoicesPaid(ZERO);
                    aEP1PaymentHeader.setPOSPaymentReferenceNumber(BLANK);
                    aEP1PaymentHeader.setAccountReference(BLANK);
                    aEP1PaymentHeader.setNextFieldQualifier(ADR);
                    aEP1PaymentHeader.setQualifiedField(BLANK);
                    aEP1PaymentHeader.setPayeeExtraAddress(BLANK);
                    aEP1PaymentHeader.setRunCode1(YES);
                    aEP1PaymentHeader.setInquiryTelephoneNumber(BLANK);
                    aEP1PaymentHeader.setSpecialBatchNumber(BLANK);
                    aEP1PaymentHeader.setDocumentId(BLANK);
                    aEP1PaymentHeader.setReceivedABA(BLANK);
                    aEP1PaymentHeader.setReceivedAccount(BLANK);
                    aEP1PaymentHeader.setPaymentGUID(paddedCheckNumber);
                    aEP1PaymentHeader.setPayeeCountryName(BLANK);
                    bwEP1Alabama.write(aEP1PaymentHeader.createRecordString());
                    bwEP1Alabama.newLine();
                    aNumberOfLines++;

                    aEP1PaymentDetail.setRecordType(RECORD_TYPE_EP1_PAYMENT_DETAIL);
                    //Start Change - JLumbre - 2021-07-26
                    //aEP1PaymentDetail.setVoucherNumber(apRequest.getAdjustmentId().getEntity().getServiceAgreement().getAccount().getId().getTrimmedValue());
                    //aEP1PaymentDetail.setInvoiceNumber(NOT_APPLICABLE);
                    aEP1PaymentDetail.setVoucherNumber(apRequest.getAdjustmentId().getTrimmedValue());
                    aEP1PaymentDetail.setInvoiceNumber(apRequest.getAdjustmentId().getEntity().getServiceAgreement().getAccount().getId().getTrimmedValue());
                    //End Change - JLumbre - 2021-07-26
                    aEP1PaymentDetail.setGrossAmount(adjustmentAmount.toString());
                    aEP1PaymentDetail.setNetAmount(BLANK);
                    aEP1PaymentDetail.setDiscount(BLANK);
                    aEP1PaymentDetail.setInvoiceDate(BLANK);
                    aEP1PaymentDetail.setAdjustmentReasonText(CREDIT_BALANCE_REFUND);
                    aEP1PaymentDetail.setEntityId(BLANK);
                    aEP1PaymentDetail.setEntityName(BLANK);
                    aEP1PaymentDetail.setRemitAccountNumber(BLANK);
                    aEP1PaymentDetail.setSystemReference(BLANK);
                    aEP1PaymentDetail.setMiscRemittanceReference(BLANK);
                    aEP1PaymentDetail.setInvoiceDueDate(BLANK);
                    bwEP1Alabama.write(aEP1PaymentDetail.createRecordString());
                    bwEP1Alabama.newLine();
                    aNumberOfLines++;

                    aTotalCheckAmount = aTotalCheckAmount.add(adjustmentAmount);
                    aNumberOfChecks++;

                    // Update A/P Request Status
                    ApCheckRequest_DTO apRequestDto = apRequest.getDTO();
                    apRequestDto.setPaymentSelectionStatus(PaymentSelectionStatusLookup.constants.REQUESTED_FOR_PAYMENT);
                    apRequestDto.setPaymentNumber(paddedCheckNumber);
                    apRequest.setDTO(apRequestDto);

                } catch (IOException e) {
                	addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileWriting(e.getMessage()));
                    e.printStackTrace();
                }
            }
            else if (cisDivisionId.getTrimmedValue().equalsIgnoreCase(CIS_DIVISION_GL)){

            	initializeGlFiles++;
            	if (initializeGlFiles == 1){
            		initializeGulfFiles();
            	}

                try{
                    gEP1PaymentHeader.setRecordType(RECORD_TYPE_EP1_PAYMENT_HEADER);
                    gEP1PaymentHeader.setProcessCode(NOR);
                    gEP1PaymentHeader.setPayMethod(PBC);
                    gEP1PaymentHeader.setRmtMethod(CHK);
                    gEP1PaymentHeader.setCheckEftOrgDate(apRequest.getScheduledToPayDate().toString(FORMAT_MMDDYY));
                    gEP1PaymentHeader.setPaymentAmount(adjustmentAmount.toString());

                    checkNumber = getNextCheckNumberSequence("CM_GL_CHECK_NUMBER_SEQ");
                    String paddedCheckNumber = glCompanyCode + padLeftZeros(checkNumber.toString(), 7);
                    gEP1PaymentHeader.setReferenceNumber(paddedCheckNumber);

                    gEP1PaymentHeader.setPayeeName(apRequest.getEntityName());
                    //Start Change - DLampa - 2023-11-10 - E-08140
                    //gEP1PaymentHeader.setPayeeAddress1(StringUtilities.camelCaseToWords(StringUtilities.wordsToCamelCase(apRequest.getAddress1())));
                    String houseNumber = apRequest.getAddress1().substring(0, apRequest.getAddress1().indexOf(' ') + 1);
                    gEP1PaymentHeader.setPayeeAddress1(houseNumber.concat(StringUtilities.camelCaseToWords(StringUtilities.wordsToCamelCase(apRequest.getAddress1().substring(apRequest.getAddress1().indexOf(' ') + 1, apRequest.getAddress1().length())))));
                    //End Change - DLampa - 2023-11-10 - E-08140
                    gEP1PaymentHeader.setPayeeCszcCode(S);
                    gEP1PaymentHeader.setPayeeCity(StringUtilities.camelCaseToWords(StringUtilities.wordsToCamelCase(apRequest.getCity())));
                    gEP1PaymentHeader.setPayeeState(apRequest.getState().trim());
                    //Start Change - JLumbre - 2021-07-26
                    //gEP1PaymentHeader.setPayeePostal(apRequest.getPostal().replaceAll(" ",""));
                    gEP1PaymentHeader.setPayeePostal(apRequest.getPostal().replaceAll("-","").trim());
                    //End Change - JLumbre - 2021-07-26
                    gEP1PaymentHeader.setPayeeCountryCode(BLANK);
                    gEP1PaymentHeader.setNumberOfInvoicesPaid(ZERO);
                    gEP1PaymentHeader.setPOSPaymentReferenceNumber(BLANK);
                    gEP1PaymentHeader.setAccountReference(BLANK);
                    gEP1PaymentHeader.setNextFieldQualifier(ADR);
                    gEP1PaymentHeader.setQualifiedField(BLANK);
                    gEP1PaymentHeader.setPayeeExtraAddress(BLANK);
                    gEP1PaymentHeader.setRunCode1(YES);
                    gEP1PaymentHeader.setInquiryTelephoneNumber(BLANK);
                    gEP1PaymentHeader.setSpecialBatchNumber(BLANK);
                    gEP1PaymentHeader.setDocumentId(BLANK);
                    gEP1PaymentHeader.setReceivedABA(BLANK);
                    gEP1PaymentHeader.setReceivedAccount(BLANK);
                    gEP1PaymentHeader.setPaymentGUID(paddedCheckNumber);
                    gEP1PaymentHeader.setPayeeCountryName(BLANK);
                    bwEP1Gulf.write(gEP1PaymentHeader.createRecordString());
                    bwEP1Gulf.newLine();
                    gNumberOfLines++;

                    gEP1PaymentDetail.setRecordType(RECORD_TYPE_EP1_PAYMENT_DETAIL);
                    //Start Change - JLumbre - 2021-07-26
                    //gEP1PaymentDetail.setVoucherNumber(apRequest.getAdjustmentId().getEntity().getServiceAgreement().getAccount().getId().getTrimmedValue());
                    //gEP1PaymentDetail.setInvoiceNumber(NOT_APPLICABLE);
                    gEP1PaymentDetail.setVoucherNumber(apRequest.getAdjustmentId().getTrimmedValue());
                    gEP1PaymentDetail.setInvoiceNumber(apRequest.getAdjustmentId().getEntity().getServiceAgreement().getAccount().getId().getTrimmedValue());
                    //End Change - JLumbre - 2021-07-26
                    gEP1PaymentDetail.setGrossAmount(adjustmentAmount.toString());
                    gEP1PaymentDetail.setNetAmount(BLANK);
                    gEP1PaymentDetail.setDiscount(BLANK);
                    gEP1PaymentDetail.setInvoiceDate(BLANK);
                    gEP1PaymentDetail.setAdjustmentReasonText(CREDIT_BALANCE_REFUND);
                    gEP1PaymentDetail.setEntityId(BLANK);
                    gEP1PaymentDetail.setEntityName(BLANK);
                    gEP1PaymentDetail.setRemitAccountNumber(BLANK);
                    gEP1PaymentDetail.setSystemReference(BLANK);
                    gEP1PaymentDetail.setMiscRemittanceReference(BLANK);
                    gEP1PaymentDetail.setInvoiceDueDate(BLANK);
                    bwEP1Gulf.write(gEP1PaymentDetail.createRecordString());
                    bwEP1Gulf.newLine();
                    gNumberOfLines++;

                    gTotalCheckAmount = gTotalCheckAmount.add(adjustmentAmount);
                    gNumberOfChecks++;

                    // Update A/P Request Status
                    ApCheckRequest_DTO apRequestDto = apRequest.getDTO();
                    apRequestDto.setPaymentSelectionStatus(PaymentSelectionStatusLookup.constants.REQUESTED_FOR_PAYMENT);
                    apRequestDto.setPaymentNumber(paddedCheckNumber);
                    apRequest.setDTO(apRequestDto);

                } catch (IOException e) {
                	addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileWriting(e.getMessage()));
                    e.printStackTrace();
                }
            }

            return true;
        }

        @Override
        public void finalizeThreadWork() throws ThreadAbortedException,
                RunAbortedException {

        	if (initializeMoFiles > 0){
        		try {
        			mEP1BatchControlTotal.setRecordType(RECORD_TYPE_EP1_BATCH_CONTROL_TOTAL);
        			mEP1BatchControlTotal.setControlNumber(getBatchNumber().toString(), getBatchRerunNumber().toString());
        			mEP1BatchControlTotal.setTotalAmount(mTotalCheckAmount.toString());
        			mEP1BatchControlTotal.setNumberOfCheckPayments(String.valueOf(mNumberOfChecks));
        			mEP1BatchControlTotal.setNumberOfACHPayments(BLANK);
        			mEP1BatchControlTotal.setNumberOfWirePayments(BLANK);
        			mEP1BatchControlTotal.setNumberOfCardPayments(BLANK);
        			mEP1BatchControlTotal.setNumberOfVoidRecords(BLANK);
        			mEP1BatchControlTotal.setNumberOfPPORecords(BLANK);
        			bwEP1Missouri.write(mEP1BatchControlTotal.createRecordString());
        			bwEP1Missouri.newLine();
        			mNumberOfLines++;

        			mEP1FileTrailer.setTRVald(TRVALD);
        			mEP1FileTrailer.setFileGenerationDate(getSystemDateTime().getDate().toString(FORMAT_YYYYMMDD));
        			mEP1FileTrailer.setFileGenerationTimestamp(getSystemDateTime().getTime().toString(FORMAT_HHMMSS));
        			mNumberOfLines++;
        			mEP1FileTrailer.setNumberOfLines(String.valueOf(mNumberOfLines));
        			mEP1FileTrailer.setSequence(BLANK);
        			bwEP1Missouri.write(mEP1FileTrailer.createRecordString());


        		} catch (IOException e) {
        			addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileWriting(e.getMessage()));
        			e.printStackTrace();
        		}
        		finally {
        			if (bwEP1Missouri != null) {
        				try {
        					bwEP1Missouri.close();
        				} catch (IOException e) {
        					addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileClosing(e.getMessage()));
        					e.printStackTrace();
        				}
        			}
        		}
        	}

        	if (initializeAlFiles > 0){
        		try {
        			aEP1BatchControlTotal.setRecordType(RECORD_TYPE_EP1_BATCH_CONTROL_TOTAL);
        			aEP1BatchControlTotal.setControlNumber(getBatchNumber().toString(), getBatchRerunNumber().toString());
        			aEP1BatchControlTotal.setTotalAmount(aTotalCheckAmount.toString());
        			aEP1BatchControlTotal.setNumberOfCheckPayments(String.valueOf(aNumberOfChecks));
        			aEP1BatchControlTotal.setNumberOfACHPayments(BLANK);
        			aEP1BatchControlTotal.setNumberOfWirePayments(BLANK);
        			aEP1BatchControlTotal.setNumberOfCardPayments(BLANK);
        			aEP1BatchControlTotal.setNumberOfVoidRecords(BLANK);
        			aEP1BatchControlTotal.setNumberOfPPORecords(BLANK);
        			bwEP1Alabama.write(aEP1BatchControlTotal.createRecordString());
        			bwEP1Alabama.newLine();
        			aNumberOfLines++;

        			aEP1FileTrailer.setTRVald(TRVALD);
        			aEP1FileTrailer.setFileGenerationDate(getSystemDateTime().getDate().toString(FORMAT_YYYYMMDD));
        			aEP1FileTrailer.setFileGenerationTimestamp(getSystemDateTime().getTime().toString(FORMAT_HHMMSS));
        			aNumberOfLines++;
        			aEP1FileTrailer.setNumberOfLines(String.valueOf(aNumberOfLines));
        			aEP1FileTrailer.setSequence(BLANK);
        			bwEP1Alabama.write(aEP1FileTrailer.createRecordString());


        		} catch (IOException e) {
        			addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileWriting(e.getMessage()));
        			e.printStackTrace();
        		}
        		finally {
        			if (bwEP1Alabama != null) {
        				try {
        					bwEP1Alabama.close();
        				} catch (IOException e) {
        					addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileClosing(e.getMessage()));
        					e.printStackTrace();
        				}
        			}
        		}
        	}

        	if (initializeGlFiles > 0){
        		try {
        			gEP1BatchControlTotal.setRecordType(RECORD_TYPE_EP1_BATCH_CONTROL_TOTAL);
        			gEP1BatchControlTotal.setControlNumber(getBatchNumber().toString(), getBatchRerunNumber().toString());
        			gEP1BatchControlTotal.setTotalAmount(gTotalCheckAmount.toString());
        			gEP1BatchControlTotal.setNumberOfCheckPayments(String.valueOf(gNumberOfChecks));
        			gEP1BatchControlTotal.setNumberOfACHPayments(BLANK);
        			gEP1BatchControlTotal.setNumberOfWirePayments(BLANK);
        			gEP1BatchControlTotal.setNumberOfCardPayments(BLANK);
        			gEP1BatchControlTotal.setNumberOfVoidRecords(BLANK);
        			gEP1BatchControlTotal.setNumberOfPPORecords(BLANK);
        			bwEP1Gulf.write(gEP1BatchControlTotal.createRecordString());
        			bwEP1Gulf.newLine();
        			gNumberOfLines++;

        			gEP1FileTrailer.setTRVald(TRVALD);
        			gEP1FileTrailer.setFileGenerationDate(getSystemDateTime().getDate().toString(FORMAT_YYYYMMDD));
        			gEP1FileTrailer.setFileGenerationTimestamp(getSystemDateTime().getTime().toString(FORMAT_HHMMSS));
        			gNumberOfLines++;
        			gEP1FileTrailer.setNumberOfLines(String.valueOf(gNumberOfLines));
        			gEP1FileTrailer.setSequence(BLANK);
        			bwEP1Gulf.write(gEP1FileTrailer.createRecordString());


        		} catch (IOException e) {
        			addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileWriting(e.getMessage()));
        			e.printStackTrace();
        		}
        		finally {
        			if (bwEP1Gulf != null) {
        				try {
        					bwEP1Gulf.close();
        				} catch (IOException e) {
        					addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileClosing(e.getMessage()));
        					e.printStackTrace();
        				}
        			}
        		}
        	}

            // Control Files
        	if (initializeMoFiles > 0) {
        		try {
        			bwEPCMissouri = new BufferedWriter(new FileWriter(epcFileMissouri));
        			bwEPCMissouri.write("[docTypes]" + "\n");
        			bwEPCMissouri.write("Number=1" + "\n");
        			bwEPCMissouri.write("Type1=c07" + "\n");
        			bwEPCMissouri.write("\n");
        			bwEPCMissouri.write("[c07]" + "\n");
        			bwEPCMissouri.write("Documents Number=" + mNumberOfChecks  + "\n");
        			bwEPCMissouri.write("Date=" + getSystemDateTime().getDate().toString(FORMAT_MMDDYY_WITH_SLASH)  + "\n");
        			bwEPCMissouri.write("Dollar Amount=" + mTotalCheckAmount.toString());
        		} catch (IOException e) {
        			addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileWriting(e.getMessage()));
        			e.printStackTrace();
        		}
        		finally {
        			if (bwEPCMissouri != null) {
        				try {
        					bwEPCMissouri.close();
        				} catch (IOException e) {
        					addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileClosing(e.getMessage()));
        					e.printStackTrace();
        				}
        			}
        		}
        	}

        	if (initializeAlFiles > 0){
        		try {
        			bwEPCAlabama = new BufferedWriter(new FileWriter(epcFileAlabama));
        			bwEPCAlabama.write("[docTypes]" + "\n");
        			bwEPCAlabama.write("Number=1" + "\n");
        			bwEPCAlabama.write("Type1=c07" + "\n");
        			bwEPCAlabama.write("\n");
        			bwEPCAlabama.write("[c07]" + "\n");
        			bwEPCAlabama.write("Documents Number=" + aNumberOfChecks + "\n");
        			bwEPCAlabama.write("Date=" + getSystemDateTime().getDate().toString(FORMAT_MMDDYY_WITH_SLASH) + "\n");
        			bwEPCAlabama.write("Dollar Amount=" + aTotalCheckAmount.toString());
        		} catch (IOException e) {
        			addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileWriting(e.getMessage()));
        			e.printStackTrace();
        		}
        		finally {
        			if (bwEPCAlabama != null) {
        				try {
        					bwEPCAlabama.close();
        				} catch (IOException e) {

        				}
        			}
        		}
        	}

        	if (initializeGlFiles > 0){
        		try {
        			bwEPCGulf = new BufferedWriter(new FileWriter(epcFileGulf));
        			bwEPCGulf.write("[docTypes]" + "\n");
        			bwEPCGulf.write("Number=1" + "\n");
        			bwEPCGulf.write("Type1=c07" + "\n");
        			bwEPCGulf.write("\n");
        			bwEPCGulf.write("[c07]" + "\n");
        			bwEPCGulf.write("Documents Number=" + gNumberOfChecks + "\n");
        			bwEPCGulf.write("Date=" + getSystemDateTime().getDate().toString(FORMAT_MMDDYY_WITH_SLASH) + "\n");
        			bwEPCGulf.write("Dollar Amount=" + gTotalCheckAmount.toString());
        		} catch (IOException e) {
        			addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileWriting(e.getMessage()));
        			e.printStackTrace();
        		}
        		finally {
        			if (bwEPCGulf != null) {
        				try {
        					bwEPCGulf.close();
        				} catch (IOException e) {
        					addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileClosing(e.getMessage()));
        					e.printStackTrace();
        				}
        			}
        		}
        	}

        	if (initializeAlFiles > 0){
        		try {
        			bwACHAlabama = new BufferedWriter(new FileWriter(achFileAlabama));

        			aACHFileHeader.setRecordType(RECORD_TYPE_ACH_FILE_HEADER);
        			aACHFileHeader.setPriorityCode(PRIORITY_CODE);
        			aACHFileHeader.setImmediateDestination(DEST_BANK_ROUTING_NBR);
        			aACHFileHeader.setImmediateOrigin(COMPANY_NBR_ALABAMA);
        			aACHFileHeader.setFileCreationDate(getSystemDateTime().getDate().toString(FORMAT_YYMMDD));
        			aACHFileHeader.setFileCreationTime(getSystemDateTime().getTime().toString(FORMAT_HHMM));
        			aACHFileHeader.setFileIdModifier(A);
        			aACHFileHeader.setRecordSize(C094);
        			aACHFileHeader.setBlockingFactor(C10);
        			aACHFileHeader.setFormatCode(C1);
        			aACHFileHeader.setImmediateDestinationName(REGIONS_BANK);
        			aACHFileHeader.setImmediateOriginName(SPIRE_ALABAMA);
        			aACHFileHeader.setReferenceCode(BLANK);
        			bwACHAlabama.write(aACHFileHeader.createRecordString());
        			bwACHAlabama.newLine();

        			aACHBatchHeader.setRecordType(RECORD_TYPE_ACH_BATCH_HEADER);
        			aACHBatchHeader.setServiceClassCode(SVC_CLASS_200);
        			aACHBatchHeader.setCompanyName(COMPANY_NAME_ALABAMA);
        			aACHBatchHeader.setDiscretionaryData(BLANK);
        			aACHBatchHeader.setCompanyId(COMPANY_NBR_ALABAMA);
        			aACHBatchHeader.setStandardEntryClass(PPD);
        			aACHBatchHeader.setCompanyEntryDescrtiption(PAYABLE);
        			aACHBatchHeader.setCompanyDescriptiveDate(getSystemDateTime().getDate().toString(FORMAT_YYMMDD));
        			aACHBatchHeader.setEffectiveEntryDate(getSystemDateTime().getDate().toString(FORMAT_YYMMDD));
        			aACHBatchHeader.setReserved(BLANK);
        			aACHBatchHeader.setOriginatorStatusCode(C1);
        			aACHBatchHeader.setOriginatingFinancialInstitution(C06200001);
        			aACHBatchHeader.setBatchNumber(C0000001);
        			bwACHAlabama.write(aACHBatchHeader.createRecordString());
        			bwACHAlabama.newLine();

        			aACHPPDEntryDetail.setRecordType(RECORD_TYPE_ACH_PPD_ENTRY_DETAIL);
        			aACHPPDEntryDetail.setTransactionCode(C22);
        			aACHPPDEntryDetail.setReceivingDFIiIdentification(C10100001);
        			aACHPPDEntryDetail.setCheckDigit(C9);
        			aACHPPDEntryDetail.setDFIAccountNumber(ALABAMA_DFI_ACCT_NBR);
        			aACHPPDEntryDetail.setAmount(aTotalCheckAmount.toString().replace(".", ""));
        			aACHPPDEntryDetail.setIndividualIdNumber(ALABAMA_IDENT_NBR);
        			aACHPPDEntryDetail.setIndividualName(SPIRE_ALABAMA);
        			aACHPPDEntryDetail.setDiscretionaryData(BLANK);
        			aACHPPDEntryDetail.setAddendaRecordIndicator(ZERO);
        			aACHPPDEntryDetail.setTraceNumber(C000000000000001);
        			bwACHAlabama.write(aACHPPDEntryDetail.createRecordString());
        			bwACHAlabama.newLine();

        			aACHBatchControl.setRecordType(RECORD_TYPE_ACH_BATCH_CONTROL);
        			aACHBatchControl.setServiceClassCode(SVC_CLASS_200);
        			aACHBatchControl.setEntryCount(ADDENDA_COUNT);
        			aACHBatchControl.setEntryHash(HASH_COUNT);
        			aACHBatchControl.setTotalDebitEntryDollarAmount(C000000000000);
        			aACHBatchControl.setTotalCreditEntryDollarAmount(aTotalCheckAmount.toString().replace(".", ""));
        			aACHBatchControl.setCompanyId(COMPANY_NBR_ALABAMA);
        			aACHBatchControl.setMessageAuthenticationCode(BLANK);
        			aACHBatchControl.setReserved(BLANK);
        			aACHBatchControl.setOriginatingDFIId(C06200001);
        			aACHBatchControl.setBatchNumber(C0000001);
        			bwACHAlabama.write(aACHBatchControl.createRecordString());
        			bwACHAlabama.newLine();

        			aACHFileControl.setRecordType(RECORD_TYPE_ACH_FILE_CONTROL);
        			aACHFileControl.setBatchCount(C000001);
        			aACHFileControl.setBlockCount(C000010);
        			aACHFileControl.setEntryCount(ADDENDA_COUNT);
        			aACHFileControl.setEntryHash(HASH_COUNT);
        			aACHFileControl.setTotalDebitEntryDollarAmount(C000000000000);
        			aACHFileControl.setTotalCreditEntryDollarAmount(aTotalCheckAmount.toString().replace(".", ""));
        			aACHFileControl.setReserved(BLANK);
        			bwACHAlabama.write(aACHFileControl.createRecordString());
        			bwACHAlabama.newLine();
        		}
        		catch (IOException e) {
        			addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileWriting(e.getMessage()));
        			e.printStackTrace();
        		}
        		finally {
        			if (bwACHAlabama != null) {
        				try {
        					bwACHAlabama.close();
        				} catch (IOException e) {
        					addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileClosing(e.getMessage()));
        					e.printStackTrace();
        				}
        			}
        		}
        	}

        	if (initializeGlFiles > 0){
        		try {
        			bwACHGulf = new BufferedWriter(new FileWriter(achFileGulf));

        			gACHFileHeader.setRecordType(RECORD_TYPE_ACH_FILE_HEADER);
        			gACHFileHeader.setPriorityCode(PRIORITY_CODE);
        			gACHFileHeader.setImmediateDestination(DEST_BANK_ROUTING_NBR);
        			//Start Change - JLumbre - 2021-09-09 - QAC#4444595520
        			//gACHFileHeader.setImmediateOrigin(COMPANY_NBR_GULF);COMPANY_NBR_ALABAMA
        			gACHFileHeader.setImmediateOrigin(COMPANY_NBR_ALABAMA);
        			//End Change - JLumbre - 2021-09-09 - QAC#4444595520
        			gACHFileHeader.setFileCreationDate(getSystemDateTime().getDate().toString(FORMAT_YYMMDD));
        			gACHFileHeader.setFileCreationTime(getSystemDateTime().getTime().toString(FORMAT_HHMM));
        			gACHFileHeader.setFileIdModifier(A);
        			gACHFileHeader.setRecordSize(C094);
        			gACHFileHeader.setBlockingFactor(C10);
        			gACHFileHeader.setFormatCode(C1);
        			gACHFileHeader.setImmediateDestinationName(REGIONS_BANK);
        			gACHFileHeader.setImmediateOriginName(SPIRE_GULF);
        			gACHFileHeader.setReferenceCode(BLANK);
        			bwACHGulf.write(gACHFileHeader.createRecordString());
        			bwACHGulf.newLine();

        			gACHBatchHeader.setRecordType(RECORD_TYPE_ACH_BATCH_HEADER);
        			gACHBatchHeader.setServiceClassCode(SVC_CLASS_200);
        			gACHBatchHeader.setCompanyName(COMPANY_NAME_GULF);
        			gACHBatchHeader.setDiscretionaryData(BLANK);
        			gACHBatchHeader.setCompanyId(COMPANY_NBR_GULF);
        			gACHBatchHeader.setStandardEntryClass(PPD);
        			gACHBatchHeader.setCompanyEntryDescrtiption(PAYABLE);
        			gACHBatchHeader.setCompanyDescriptiveDate(getSystemDateTime().getDate().toString(FORMAT_YYMMDD));
        			gACHBatchHeader.setEffectiveEntryDate(getSystemDateTime().getDate().toString(FORMAT_YYMMDD));
        			gACHBatchHeader.setReserved(BLANK);
        			gACHBatchHeader.setOriginatorStatusCode(C1);
        			gACHBatchHeader.setOriginatingFinancialInstitution(C06200001);
        			gACHBatchHeader.setBatchNumber(C0000001);
        			bwACHGulf.write(gACHBatchHeader.createRecordString());
        			bwACHGulf.newLine();

        			gACHPPDEntryDetail.setRecordType(RECORD_TYPE_ACH_PPD_ENTRY_DETAIL);
        			gACHPPDEntryDetail.setTransactionCode(C22);
        			gACHPPDEntryDetail.setReceivingDFIiIdentification(C10100001);
        			gACHPPDEntryDetail.setCheckDigit(C9);
        			gACHPPDEntryDetail.setDFIAccountNumber(GULF_DFI_ACCT_NBR);
        			gACHPPDEntryDetail.setAmount(gTotalCheckAmount.toString().replace(".", ""));
        			gACHPPDEntryDetail.setIndividualIdNumber(GULF_IDENT_NBR);
        			gACHPPDEntryDetail.setIndividualName(SPIRE_GULF);
        			gACHPPDEntryDetail.setDiscretionaryData(BLANK);
        			gACHPPDEntryDetail.setAddendaRecordIndicator(ZERO);
        			gACHPPDEntryDetail.setTraceNumber(C000000000000001);
        			bwACHGulf.write(gACHPPDEntryDetail.createRecordString());
        			bwACHGulf.newLine();

        			gACHBatchControl.setRecordType(RECORD_TYPE_ACH_BATCH_CONTROL);
        			gACHBatchControl.setServiceClassCode(SVC_CLASS_200);
        			gACHBatchControl.setEntryCount(ADDENDA_COUNT);
        			gACHBatchControl.setEntryHash(HASH_COUNT);
        			gACHBatchControl.setTotalDebitEntryDollarAmount(C000000000000);
        			gACHBatchControl.setTotalCreditEntryDollarAmount(gTotalCheckAmount.toString().replace(".", ""));
        			gACHBatchControl.setCompanyId(COMPANY_NBR_GULF);
        			gACHBatchControl.setMessageAuthenticationCode(BLANK);
        			gACHBatchControl.setReserved(BLANK);
        			gACHBatchControl.setOriginatingDFIId(C06200001);
        			gACHBatchControl.setBatchNumber(C0000001);
        			bwACHGulf.write(gACHBatchControl.createRecordString());
        			bwACHGulf.newLine();

        			gACHFileControl.setRecordType(RECORD_TYPE_ACH_FILE_CONTROL);
        			gACHFileControl.setBatchCount(C000001);
        			gACHFileControl.setBlockCount(C000010);
        			gACHFileControl.setEntryCount(ADDENDA_COUNT);
        			gACHFileControl.setEntryHash(HASH_COUNT);
        			gACHFileControl.setTotalDebitEntryDollarAmount(C000000000000);
        			gACHFileControl.setTotalCreditEntryDollarAmount(gTotalCheckAmount.toString().replace(".", ""));
        			gACHFileControl.setReserved(BLANK);
        			bwACHGulf.write(gACHFileControl.createRecordString());
        			bwACHGulf.newLine();
        		}
        		catch (IOException e) {
        			addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileWriting(e.getMessage()));
        			e.printStackTrace();
        		}
        		finally {
        			if (bwACHGulf != null) {
        				try {
        					bwACHGulf.close();
        				} catch (IOException e) {
        					addError(CustomMessageRepositorySpireOne.CCB041_1_ErrorFileClosing(e.getMessage()));
        					e.printStackTrace();
        				}
        			}
        		}
        	}
        }

        private String padLeftZeros(String inputString, int length) {
            if (inputString.length() >= length) {
                return inputString;
            }
            StringBuilder sb = new StringBuilder();
            while (sb.length() < length - inputString.length()) {
                sb.append('0');
            }
            sb.append(inputString);

            return sb.toString();
        }

        private BigInteger getNextCheckNumberSequence(String dbSequence){

        	BigInteger returnValue = null;

            StringBuilder queryString = new StringBuilder();
            queryString.append("SELECT ");
            queryString.append(    dbSequence + ".NEXTVAL ");
            queryString.append(    "AS CHECK_NUMBER ");
            queryString.append("FROM DUAL ");

            PreparedStatement getNextSequenceSQL = createPreparedStatement(queryString.toString(), "getNextCheckNumberSequence");
            returnValue = getNextSequenceSQL.firstRow().getInteger("CHECK_NUMBER");
            getNextSequenceSQL.close();

            return returnValue;

        }

    }

}

