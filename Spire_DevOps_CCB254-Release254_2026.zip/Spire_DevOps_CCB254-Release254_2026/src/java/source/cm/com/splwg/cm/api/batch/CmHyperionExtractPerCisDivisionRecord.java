/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Colum Delimited Record for Hyperion Extract Batch per CIS Division. 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:       Reason:                                     
 * YYYY-MM-DD   IN        Reason text.                                
 *           
 * 2015-02-21   WCARAN    MGE-CCB020 Initial Version.
 *              BMARQUEZ
 * 2016-01-28  	MPang	  Updated for CCB v2.4 compilation.          
 * 2021-08-19  	GCrisp	  CCB040.Issue3. Add new field for Accounting Period    
 *************************************************************************/
package com.splwg.cm.api.batch;

import java.math.BigInteger;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.common.NullHelper;
//Start Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure;*/
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
//End Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
import com.splwg.shared.common.StringUtilities;

public class CmHyperionExtractPerCisDivisionRecord 
		extends ColumnDelimitedRecord {

	// Constants
    /** , */
    private final String COMMA = ",";
    /** "" */
    private final String BLANK = "";
    /** " " */
    private final String SPACE = " ";
    /** " */
    private final String QUOTE_MARK = "\"";
    /** MM-dd-yyyy */
    private static final DateFormat DATE_FORMAT = new DateFormat("MM-dd-yyyy");
    
	public CmHyperionExtractPerCisDivisionRecord(int numberOfExpectedColumns) {
		super(numberOfExpectedColumns);
	}

	private String formatString(String text, boolean isLineBeginning) {
		if (StringUtilities.isEmptyOrNull(text)) {
			text = BLANK;
		}
        if (isLineBeginning) {
            text = QUOTE_MARK + text.replaceAll(COMMA, SPACE).trim() + QUOTE_MARK;
        } else {
            text = COMMA + QUOTE_MARK + text.replaceAll(COMMA, SPACE).trim() + QUOTE_MARK;
        }

		return text;
	}
    
	private void setColumn(int i, String str) {
	    str = formatString(str, i == 1);
	    rightPadColumn(i, str.length(), str);
	}
    
    public void setHeaderColumn(int i, String headerDescription) {
        setColumn(i, headerDescription);
    }
    
    public void setCisDivision(CisDivision cisDivision) {
        setColumn(1, cisDivision.getId().getTrimmedValue());
    }
    
    public void setExtractDate(Date processDate) {
        setColumn(2, processDate.toString(DATE_FORMAT));
    }
    
	// Start Change - GCrisp - 2021-08-19 - CCB040.Issue3
    //public void setFercNumber(String fercNumber) {
    //    setColumn(3, fercNumber);
    //}
    //
    //public void setRateClassDescription(String rateClassDescription) {
    //    setColumn(4, rateClassDescription);
    //}
	//
    //public void setServiceAgreementCount(BigInteger bigInteger) {
    //    setColumn(5, bigInteger.toString());
    //}
    //
    //public void setBillCount(BigDecimal bigDecimal) {
    //    setColumn(6, bigDecimal.toString());
    //}
    //
    //public void setUnitOfMeasure(UnitOfMeasure unitOfMeasure) {
    //    if (NullHelper.notNull(unitOfMeasure)) {
    //        setColumn(7, unitOfMeasure.getId().getTrimmedValue());
    //    } else {
    //        setColumn(7, "");
    //    }
    //}
	public void setAccountingPeriod(String accountingPeriod) {
        setColumn(3, accountingPeriod);
    }
	
    public void setFercNumber(String fercNumber) {
        setColumn(4, fercNumber);
    }
    
    public void setRateClassDescription(String rateClassDescription) {
        setColumn(5, rateClassDescription);
    }

    public void setServiceAgreementCount(BigInteger bigInteger) {
        setColumn(6, bigInteger.toString());
    }
    
    public void setBillCount(BigDecimal bigDecimal) {
        setColumn(7, bigDecimal.toString());
    }
    
    public void setUnitOfMeasure(UnitOfMeasure unitOfMeasure) {
        if (NullHelper.notNull(unitOfMeasure)) {
            setColumn(8, unitOfMeasure.getId().getTrimmedValue());
        } else {
            setColumn(8, "");
        }
    }
	// End Change - GCrisp - 2021-08-19 - CCB040.Issue3
    
    public void setUsageColumn(int i, BigDecimal bigDecimal) {        
        setColumn(i, bigDecimal.toString());
    }
    
    public void setRevenueColumn(int i, BigDecimal bigDecimal) {        
        setColumn(i, bigDecimal.toString());
    }
}
