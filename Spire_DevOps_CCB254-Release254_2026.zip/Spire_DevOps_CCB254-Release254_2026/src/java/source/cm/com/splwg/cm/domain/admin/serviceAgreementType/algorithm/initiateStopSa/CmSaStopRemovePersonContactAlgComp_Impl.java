/*
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                     
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * This SA Stop Initiation Algorithm will remove data from the person table, 
 * as well as the person contact table, in the address/phone tab, 
 * of a pending stop.
 * 
 * Note: An identical version of this algorithm was created for the SA 
 * Creation plug-in point
 * 
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:       by:          Reason:
 * YYYY-MM-DD  FLName
 * 2021-12-14  DLampa       B-20286. Initial Version.
 * 
 ***********************************************************************
 */
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.initiateStopSa;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.initiateStopSa.SaTypeInitiateStopSaAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_DTO;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;

/**
 * @author dlampa
 *
@AlgorithmComponent ()
 */
public class CmSaStopRemovePersonContactAlgComp_Impl 
        extends CmSaStopRemovePersonContactAlgComp_Gen 
        implements SaTypeInitiateStopSaAlgorithmSpot {

    // Hard Parameters
    @SuppressWarnings("unused")
    private Bool shouldCreateFA;
    @SuppressWarnings("unused")
    private Date stopDate;
    @SuppressWarnings("unused")
    private Premise premise;
    private ServiceAgreement sa;
    private ServiceType serviceType;            
    @SuppressWarnings("unused")
    private String revertToLandLord, stopRequestedBy;
    
    @Override
    public ServiceType getServiceType() {
        return serviceType;
    }

    @Override
    public void setPremise(Premise arg0) {
        premise = arg0;
    }

    @Override
    public void setRevertToLandlord(String arg0) {
        revertToLandLord = arg0;
    }

    @Override
    public void setServiceAgreement(ServiceAgreement arg0) {
        sa = arg0;
    }

    @Override
    public void setServiceType(ServiceType arg0) {
        serviceType = arg0;
    }

    @Override
    public void setShouldCreateFieldActivity(Bool arg0) {
        shouldCreateFA = arg0;
    }

    @Override
    public void setStopDate(Date arg0) {
        stopDate = arg0;
    }

    @Override
    public void setStopRequestedBy(String arg0) {
        stopRequestedBy = arg0;
    }
        
    
    @Override
    public void invoke() {
        
        // Clear entries from the Start/Stop Contact Override table (C1_SS_CONT_OVRD)
        processContactOverride();                   
        
        // Clear the Person Data Area
        Person person = sa.getAccount().getMainPerson();
        Person_DTO personDto = person.getDTO();
        personDto.setPersonDataArea("");
        person.setDTO(personDto);       

        
    }
    
    /**
     * Check if there are existing entries in the Start/Stop Contact Override
     */
    private void processContactOverride(){
        
        //Check if active accounts exists for Person Id
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT C1_SS_CONTACT_ID ");
        stringBuilder.append("FROM C1_SS_CONT_OVRD ");
        stringBuilder.append("WHERE PER_ID = :person ");
        stringBuilder.append("AND ACCT_ID = :account ");    
        
        PreparedStatement retrieveContactOverride = createPreparedStatement(stringBuilder.toString(), this.getClass().getName());
        retrieveContactOverride.bindId("account", sa.getAccount().getId());
        retrieveContactOverride.bindId("person", sa.getAccount().getMainPerson().getId());       
        
        // If an override contact is found, delete it
        if(retrieveContactOverride.list().size() > 0){
            deleteContactOverride();                        
        }
        
        retrieveContactOverride.close();
        
    }   
    
    private void deleteContactOverride() {

        StringBuilder stringBuilder = new StringBuilder();              
        stringBuilder.append("DELETE FROM C1_SS_CONT_OVRD ");
        stringBuilder.append("WHERE PER_ID = :person ");
        stringBuilder.append("  AND ACCT_ID = :account ");

        PreparedStatement deleteContactOverride = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        deleteContactOverride.bindId("account", sa.getAccount().getId());
        deleteContactOverride.bindId("person", sa.getAccount().getMainPerson().getId());
        deleteContactOverride.execute();
        deleteContactOverride.close();

    }
    
}
