/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Algorithm - Completed Bill Message
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-04-04   RDizon  NM0079. Initial Version.
 * 2013-06-07   CVB     Add Bill Message only if it does not exist yet.
 * 2013-06-11   CVB     Fixed issue on Ebill, Autopay and Corrected Messages.
 * 2015-02-19	Rahul	IM-046010 - final billmessage not coming on few account.
 * 2016-01-25   MPang	Updated for CCB v2.4 compilation.
 **************************************************************************/

package com.splwg.cm.domain.admin.customerClass;

import com.splwg.base.api.Query;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.BillFormatLookup;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.billMessage.BillMessageType;
import com.splwg.ccb.domain.admin.customerClass.CustomerClassPostBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.Bill;
import com.splwg.ccb.domain.billing.bill.BillMessage;
import com.splwg.ccb.domain.billing.bill.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.BillMessage_Id;
import com.splwg.ccb.domain.customerinfo.account.Account;*/

import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.customerClass.algorithm.postBillCompletion.CustomerClassPostBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author redizon
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = billMessageType, name = duplicateBillMessageCode, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = autopayBillMessageCode, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = correctedBillMessageCode, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = finalBillMessageCode, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = correctedFinalBillMessageCode, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = billFormat, name = billFormat, type = lookup)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = businessReplyEnvelopeBillMessageCode, type = entity)})
 */
public class CmCompletedBillMessageAlgComp_Impl 
        extends CmCompletedBillMessageAlgComp_Gen 
        implements CustomerClassPostBillCompletionAlgorithmSpot {

    // Soft Parameters
    private BillMessageType parmDuplicateBillMessageCode;
    private BillMessageType parmAutopayBillMessageCode;
    private BillMessageType parmCorrectedBillMessageCode;
    private BillMessageType parmFinalBillMessageCode;
    private BillMessageType parmCorrectedFinalBillMessageCode;
    private BillFormatLookup parmBillFormat;
    private BillMessageType parmBusinessReplyEnvelopeBillMessageCode;

    // Hard Parameters
    private Bill bill;

    // Properties
    private Account account;

    public void setBill(Bill bill) {
        this.bill = bill;

    }

    public void invoke() {
        account = bill.getAccount();

        if (notNull(parmDuplicateBillMessageCode)){
            Query getBillRouteReprintFlag = cmGetBillRouteReprintFlag();

            // Create Bill Message if a reprint Bill Message that has not been extracted yet exists
            if (getBillRouteReprintFlag.listSize() > 0){
                cmCreateBillMessage(parmDuplicateBillMessageCode);
            }
        }

        if (notNull(parmAutopayBillMessageCode)){
            Query getActiveAccountAutopay = cmGetActiveAccountAutopay();

            // Create Bill Message if the Account has an active Autopay
            if (getActiveAccountAutopay.listSize() > 0){
                cmCreateBillMessage(parmAutopayBillMessageCode);
            }
        }

        // 2013-06-11 - CVB - Start
        Bool isAccountFinal = checkIfAccountIsFinal(bill.getAccount());

        Query getExistingBillCorrection = cmGetExistingBillCorrection();
        long existingBsegCorrCount = getExistingBillCorrection.listSize();

        if (notNull(parmCorrectedBillMessageCode)){
            // Create Bill Message if all Bill Segments are not "Closed" and Bill Corrections exist
            if ((isAccountFinal.isFalse()) && (existingBsegCorrCount > 0)) {
                cmCreateBillMessage(parmCorrectedBillMessageCode);
            }

        }
        if (notNull(parmFinalBillMessageCode)){
            // Create Bill Message if all Bill Segments are "Closed" and Bill Corrections do not exist
            if ((isAccountFinal.isTrue()) && (existingBsegCorrCount == 0)) {
                cmCreateBillMessage(parmFinalBillMessageCode);
            }
        }

        if (notNull(parmCorrectedFinalBillMessageCode)){
            // Create Bill Message if all Bill Segments are "Closed" and Bill Corrections do not exist
            if ((isAccountFinal.isTrue()) && (existingBsegCorrCount > 0)) {
                cmCreateBillMessage(parmCorrectedFinalBillMessageCode);
            }
        }

        if (notNull(parmBusinessReplyEnvelopeBillMessageCode)){

            Query getActiveAccountAutopay = cmGetActiveAccountAutopay();
            long acctApayCount = getActiveAccountAutopay.listSize();

            Query getBillRouteFormat = cmGetBillRouteFormat();
            long nonEbillFormatCount = getBillRouteFormat.listSize();

            // Do not Create Bill Message if the Account is on autopay and or on E-bill
            if (!(acctApayCount > 0) || (nonEbillFormatCount == 0)){
                cmCreateBillMessage(parmBusinessReplyEnvelopeBillMessageCode);
            }
        }

        // if (notNull(parmCorrectedBillMessageCode)){
        //     Query getExistingClosedBillSegment = cmGetExistingClosedBillSegment();
        //     
        //     // Create Bill Message if all Bill Segments are not "Closed" and Bill Corrections exist
        //     if (getExistingClosedBillSegment.listSize() == 0){
        //         Query getExistingBillCorrection = cmGetExistingBillCorrection();
        //         if (getExistingBillCorrection.listSize() > 0){
        //             cmCreateBillMessage(parmCorrectedBillMessageCode);
        //         }
        //     }
        // }

        // if (notNull(parmFinalBillMessageCode)){
        //     Query getExistingNonClosedBillSegment = cmGetExistingNonClosedBillSegment();
        //     
        //     // Create Bill Message if all Bill Segments are "Closed" and Bill Corrections do not exist
        //     if (getExistingNonClosedBillSegment.listSize() == 0){
        //         Query getExistingBillCorrection = cmGetExistingBillCorrection();
        //         if (getExistingBillCorrection.listSize() == 0){
        //             cmCreateBillMessage(parmFinalBillMessageCode);
        //         }
        //     }
        // }

        // if (notNull(parmCorrectedFinalBillMessageCode)){
        //     Query getExistingNonClosedBillSegment = cmGetExistingNonClosedBillSegment();
        //     
        //     // Create Bill Message if all Bill Segments are "Closed" and Bill Corrections exist
        //     if (getExistingNonClosedBillSegment.listSize() == 0){
        //         Query getExistingBillCorrection = cmGetExistingBillCorrection();
        //         if (getExistingBillCorrection.listSize() > 0){
        //             cmCreateBillMessage(parmCorrectedFinalBillMessageCode);
        //         }
        //     }
        // }

        // if (notNull(parmBusinessReplyEnvelopeBillMessageCode)){
        //     Query getActiveAccountAutopay = cmGetActiveAccountAutopay();
        //     
        //     // Create Bill Message if the Account has no active Autopay
        //     if (getActiveAccountAutopay.listSize() == 0){
        //         cmCreateBillMessage(parmBusinessReplyEnvelopeBillMessageCode);
        //     }
        //     else {
        //         Query getBillRouteFormat = cmGetBillRouteFormat();
        //         
        //         // Create Bill Message if the Bill Route Format is not "E-Bill"
        //         if (getBillRouteFormat.listSize() > 0){
        //             cmCreateBillMessage(parmBusinessReplyEnvelopeBillMessageCode);
        //         }
        //     }
        // }

        // 2013-06-11 - CVB - End
    }

    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        parmDuplicateBillMessageCode = getDuplicateBillMessageCode();
        parmAutopayBillMessageCode = getAutopayBillMessageCode();
        parmCorrectedBillMessageCode = getCorrectedBillMessageCode();
        parmFinalBillMessageCode = getFinalBillMessageCode();
        parmCorrectedFinalBillMessageCode = getCorrectedFinalBillMessageCode();
        parmBillFormat = getBillFormat();
        parmBusinessReplyEnvelopeBillMessageCode = getBusinessReplyEnvelopeBillMessageCode();

        if (notNull(parmBusinessReplyEnvelopeBillMessageCode) && isNull(parmBillFormat)){
            addError(CustomMessageRepositoryMDC.nm0079_EBillBillFormatIsRequired());
        }
    }

    /**
     * Create a Bill Message that is of a specific Bill Message Type
     * @param billMessageType BillMessageType
     */
    private void cmCreateBillMessage(BillMessageType billMessageType) {

        // CVB - 2013-06-07 - Start
        BillMessage_Id existingBillMessageId = new BillMessage_Id(billMessageType, bill);
        BillMessage existingBillMessage = existingBillMessageId.getEntity();
        if (isNull(existingBillMessage)){
            // CVB - 2013-06-07 - End
            bill.getMessages().add(new BillMessage_DTO(), billMessageType.getId());
        }
    }

    /**
     * Get the unextracted reprint Bill Routings
     * @return query Query
     */
    private Query cmGetBillRouteReprintFlag(){
        Query query = createQuery("FROM BillRouting BR "
                + "WHERE BR.id.bill.id = :billId "
                + "AND BR.shouldReprint = :yes "
              //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
              //  + "AND BR.extractDateTime IS NULL");
              + "AND BR.extractDateTime IS NULL", getClass().getName());
        	 //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        query.bindId("billId", bill.getId());
        query.bindBoolean("yes", Bool.TRUE);
        query.addResult("billRouting", "BR.id");

        return query;
    }

    /**
     * Get the Bill Routing with the specified Bill Format
     * @return query Query
     */
    private Query cmGetBillRouteFormat(){
        Query query = createQuery("FROM BillRouting BR "
                + "WHERE BR.id.bill.id = :billId "
                //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                // + "AND BR.billFormat <> :billFormat");
                + "AND BR.billFormat <> :billFormat", getClass().getName());
        		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        query.bindId("billId", bill.getId());
        query.bindLookup("billFormat", parmBillFormat);
        query.addResult("billRouting", "BR.id");

        return query;
    }

    /**
     * Get the active Autopay of the Account
     * @return query Query
     */
    private Query cmGetActiveAccountAutopay() {
        Query query = createQuery("FROM AccountAutopay AA "
                + "WHERE AA.account = :account "
                + "AND AA.startDate <= :processDate "
                + "AND (AA.endDate IS NULL "
                //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                // + "OR AA.endDate > :processDate)");
                + "OR AA.endDate > :processDate)",getClass().getName());
        		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        query.bindEntity("account", account);
        query.bindDate("processDate", getProcessDateTime().getDate());
        query.addResult("accountAutopay", "AA.id");

        return query;
    }

    /**
     * Get the existing "Closed" Bill Segments
     * @return query Query
     */
    private Query cmGetExistingClosedBillSegment() {
        Query query = createQuery("FROM BillSegment BS "
                + "WHERE BS.billId = :billId "
                + "AND BS.isClosingBillSegment = :yes "
                //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                // + "AND BS.billSegmentStatus = :frozen");
                + "AND BS.billSegmentStatus = :frozen" , getClass().getName());
        		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        query.bindId("billId", bill.getId());
        query.bindBoolean("yes", Bool.TRUE);
        query.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
        query.addResult("billSegment", "BS.id");

        return query;
    }

    /**
     * Get the existing Bill Corrections
     * @return query Query
     */
    private Query cmGetExistingBillCorrection() {
        Query query = createQuery("FROM FinancialTransaction FT "
                + "WHERE FT.billId = :billId "
                + "AND FT.financialTransactionType IN (:billCancellation, :billSegment) "
                + "AND FT.isCorrection = :yes "
                //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                // + "AND FT.isFrozen = :yes");
                + "AND FT.isFrozen = :yes" , getClass().getName());
        		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        query.bindId("billId", bill.getId());
        query.bindLookup("billCancellation", FinancialTransactionTypeLookup.constants.BILL_CANCELLATION);
        query.bindLookup("billSegment", FinancialTransactionTypeLookup.constants.BILL_SEGMENT);
        query.bindBoolean("yes", Bool.TRUE);
        query.addResult("ftId", "FT.id");

        return query;
    }

    /**
     * Get the existing non-"Closed" Bill Segments
     * @return query Query
     */
    private Query cmGetExistingNonClosedBillSegment() {
        Query query = createQuery("FROM BillSegment BS "
                + "WHERE BS.billId = :billId "
                + "AND BS.isClosingBillSegment = :no "
                //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                // + "AND BS.billSegmentStatus = :frozen");
                + "AND BS.billSegmentStatus = :frozen" , getClass().getName());
        		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        query.bindId("billId", bill.getId());
        query.bindBoolean("no", Bool.FALSE);
        query.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
        query.addResult("billSegment", "BS.id");

        return query;
    }
    // 2013-06-11 - CVB - Start

    private Bool checkIfAccountIsFinal(Account account) {

        Bool accountIsFinal = Bool.TRUE;

        StringBuilder strBldr = new StringBuilder();
        // Start IM-046010 Rahul Change
/*        strBldr.append(" SELECT SA.SA_ID                                       ");
        strBldr.append("   FROM CI_SA SA                                       ");
        strBldr.append("  WHERE SA.ACCT_ID = :account                          ");
        strBldr.append("    AND SA.SA_STATUS_FLG <> '70'                       ");
        strBldr.append("    AND NOT EXISTS (SELECT 'X'                         ");
        strBldr.append("                      FROM CI_BSEG BSEG                ");
        strBldr.append("                     WHERE BSEG.SA_ID = SA.SA_ID       ");
        strBldr.append("                       AND BSEG.BSEG_STAT_FLG = '50'   ");
        strBldr.append("                       AND BSEG.CLOSING_BSEG_SW = 'Y') ");

        PreparedStatement qry = createPreparedStatement(strBldr.toString()); 
        qry.bindEntity("account", account);*/
        strBldr.append(" SELECT SA.SA_ID                                        ");
        strBldr.append("   FROM CI_SA SA, CI_SA_TYPE SATYP                      ");
        strBldr.append("  WHERE SA.ACCT_ID = :account                           ");
        strBldr.append("    AND SA.SA_STATUS_FLG NOT IN ( :closed , :cancelled) ");
        strBldr.append("    AND SA.SA_TYPE_CD = SATYP.SA_TYPE_CD                ");
        strBldr.append(" 	AND SATYP.ALLOW_BILLING_SW = 'Y'					");
        strBldr.append("    AND NOT EXISTS (SELECT 'X'                          ");
        strBldr.append("                      FROM CI_BSEG BSEG                 ");
        strBldr.append("                     WHERE BSEG.SA_ID = SA.SA_ID        ");
        strBldr.append("                       AND BSEG.BSEG_STAT_FLG = :frozen ");
        strBldr.append("                       AND BSEG.CLOSING_BSEG_SW = 'Y')  ");
        //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement qry = createPreparedStatement(strBldr.toString());
        PreparedStatement qry = createPreparedStatement(strBldr.toString(), getClass().getName());
        //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        qry.bindEntity("account", account);
        qry.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
        qry.bindLookup("cancelled", ServiceAgreementStatusLookup.constants.CANCELED);
        qry.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
        
        // End IM-046010 Rahul Change
        
        SQLResultRow row = qry.firstRow();

        if(notNull(row)){
            accountIsFinal = Bool.FALSE;
        }

        qry.close();

        return accountIsFinal;
    }   
    // 2013-06-11 - CVB - End
}
