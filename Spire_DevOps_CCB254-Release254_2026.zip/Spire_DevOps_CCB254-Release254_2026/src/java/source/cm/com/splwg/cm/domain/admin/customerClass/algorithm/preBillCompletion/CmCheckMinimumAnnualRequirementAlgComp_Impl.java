/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm will check total consumption against the Minimum Annual
 * Requirement for the Account.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *   
 * 2020-02-24   RDizon      CCB 004.4. Initial version.
 * 2020-06-26   NMendo      CCB004_Defect1. Check only if the customer has 
 *                          met their MAR after the annual period is elapsed
 *                          and within the bill period.                           
 * *************************************************************************                
 */
package com.splwg.cm.domain.admin.customerClass.algorithm.preBillCompletion;

import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.BillCompletionActionLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.admin.contractQuantityType.entity.ContractQuantityType;
import com.splwg.ccb.domain.admin.customerClass.algorithm.preBillCompletion.CustomerClassPreBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ServerMessage;

/**
 * @author RDizon
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = unitOfMeasure, name = consumptionUOM, type = entity)
 *            , @AlgorithmSoftParameter (entityName = timeOfUse, name = consumptionTOU, type = entity)
 *            , @AlgorithmSoftParameter (entityName = serviceQuantityIdentifier, name = consumptionSQI, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = rCTCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = contractQuantityType, name = mARContractQuantityType, required = true, type = entity)})
 */
public class CmCheckMinimumAnnualRequirementAlgComp_Impl
        extends CmCheckMinimumAnnualRequirementAlgComp_Gen
        implements CustomerClassPreBillCompletionAlgorithmSpot {

    // Soft Parameters
    private UnitOfMeasure parmConsumptionUOM;
    private TimeOfUse parmConsumptionTOU;
    private ServiceQuantityIdentifier parmConsumptionSQI;
    private CharacteristicType parmRCTCharacteristicType;
    private ContractQuantityType parmMARContractQuantityType;
    
    // Hard Parameters
    private Bill bill;
    private Account account;
    private Bool allowReopeningOfBills;
    private BillCompletionActionLookup billCompletionAction;
    private ServerMessage serverMessage;

    // Work Variables
    private List<ServiceAgreement> bsegSAs = new ArrayList<ServiceAgreement>();
    private List<ServiceAgreement> serviceAgreementsThatShareMAR = new ArrayList<ServiceAgreement>(); 
    private Date billPeriodStartDate;
    private Date billPeriodEndDate;
    private Date annualPeriodStartDate;
    private Date annualPeriodEndDate;
    private BigDecimal sumUsage = BigDecimal.ZERO;
    private Date cqEffDt;
    private BigDecimal cqNumber;
    private Bool checkMAR = Bool.FALSE;
    
    // Constants
    private final static String CHAR_VALUE_YES = "Y";
    
    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        parmConsumptionUOM = getConsumptionUOM();
        parmConsumptionTOU = getConsumptionTOU();
        parmConsumptionSQI = getConsumptionSQI();
        parmRCTCharacteristicType = getRCTCharacteristicType();
        parmMARContractQuantityType = getMARContractQuantityType();
        
        // Validate UOM / TOU / SQI 
        if (isNull(getConsumptionUOM()) && isNull(getConsumptionSQI())){
            addError(CustomMessageRepositorySpireOne.CCB004_4_algParmUOMorSQIRequired(getAlgorithmId().getTrimmedValue()));
        }
        
        if (notNull(getConsumptionTOU()) && isNull(getConsumptionUOM())){
            addError(CustomMessageRepositorySpireOne.CCB004_4_algParmUOMRequiredIfTOUProvided(getAlgorithmId().getTrimmedValue()));
        }
        
        // Validate RCT Characteristic Type
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(parmRCTCharacteristicType, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT);
        if(isNull(charEntityId.getEntity())){
            addError(CustomMessageRepositorySpireOne.CCB004_4_algParmInvalidCharacteristTypeForEntity(
                    getAlgorithmId().getTrimmedValue(),
                    getAlgorithm().getAlgorithmType().getParameterAt(3).fetchLanguageParameterLabel(),
                    parmRCTCharacteristicType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().fetchLanguageDescription().trim()));
        }
    }

    @Override
    public void invoke() {
        // Retrieve SAs for this Bill
        bsegSAs = retrieveBillSegmentSAs();
        
        // Check if MAR is applicable for the Account
        for (ServiceAgreement serviceAgreement : bsegSAs){
            // Check for RCT characteristic = Y
            ServiceAgreementCharacteristic saChar = serviceAgreement.getEffectiveCharacteristicAsOfDate(parmRCTCharacteristicType, billPeriodEndDate);
            
            if (notNull(saChar)
                    && saChar.getSearchCharacteristicValue().trim().equalsIgnoreCase(CHAR_VALUE_YES.trim())){
                // Retrieve applicable consumption
                checkMAR = Bool.TRUE;
                break;
            }
        }
    
        if (checkMAR.isFalse()){
            return;
        }
        
        // Derive the effective MAR Contract Quantity
        retrieveContractQuantityDetails();
        if (isNull(cqEffDt)){
            return;
        }
        
        // Start Change - NMendo - 2020-06-26 - CCB004_Defect1
        // Check only if the customer has met their MAR after the annual period is elapsed.
        int marYear = cqEffDt.getYear();
        int marMonth = cqEffDt.getMonth();
        int marDay = cqEffDt.getDay();
        if (billPeriodEndDate.isBefore(new Date(marYear+1, marMonth, marDay))) {
        	return;
        }
        
        // Derive the MAR Annual Period
        //annualPeriodStartDate = new Date(billPeriodEndDate.getYear(), cqEffDt.getMonth(), cqEffDt.getDay());;
        
        //if (billPeriodEndDate.getMonth() < cqEffDt.getMonth() 
        //        || (billPeriodEndDate.getMonth() == cqEffDt.getMonth() && billPeriodEndDate.getDay() <= cqEffDt.getDay())){
        //    annualPeriodEndDate = new Date(billPeriodEndDate.getYear() - 1, cqEffDt.getMonth(), cqEffDt.getDay());
        //}
        //else {
        //    annualPeriodEndDate = new Date(billPeriodEndDate.getYear() + 1, cqEffDt.getMonth(), cqEffDt.getDay());
        //}
        
        // Check if the MAR contract quantity effective MM/DD falls within the bill period
        int billPeriodEndYear = billPeriodEndDate.getYear();
        annualPeriodEndDate = new Date(billPeriodEndYear, marMonth, marDay);
        if (annualPeriodEndDate.isAfter(billPeriodStartDate) 
        		&& annualPeriodEndDate.isSameOrBefore(billPeriodEndDate)) {
        	annualPeriodStartDate = new Date(billPeriodEndYear-1, marMonth, marDay);
        } else {
        	return;
        }
        // End Change - NMendo - 2020-06-26 - CCB004_Defect1
        
        // Compute total consumption for all SAs that contribute to the MAR
        for (ServiceAgreement currentSa : serviceAgreementsThatShareMAR){
            ServiceAgreementCharacteristic currentSaChar = currentSa.getEffectiveCharacteristicAsOfDate(parmRCTCharacteristicType, billPeriodEndDate);
            
            if (notNull(currentSaChar)
                    && currentSaChar.getSearchCharacteristicValue().trim().equalsIgnoreCase(CHAR_VALUE_YES.trim())){
                List<BillSegment> currentSaBsegs = retrieveSABillSegments(currentSa.getId());
                
                for (BillSegment currentSaBseg : currentSaBsegs){
                    // Retrieve consumption for this SA
                    sumUsage = sumUsage.add(getBsegServiceQuantity(currentSaBseg));
                }
            }
        }
        
        // Check total Consumption against the MAR
        if (sumUsage.compareTo(cqNumber) < 0){
        	// Start Change - NMendo - 2020-06-26 - CCB004_Defect1
        	//addError(CustomMessageRepositorySpireOne.CCB004_4_marNotMetForAccount(cqNumber.toString(), account.getId().getTrimmedValue()));
            if (isOnlineConnection()) {
        		addWarning(CustomMessageRepositorySpireOne.CCB004_4_marNotMetForAccount(cqNumber.toString(), account.getId().getTrimmedValue()));
            } else {
            	billCompletionAction = BillCompletionActionLookup.constants.CREATE_EXCEPTION;
            	serverMessage = CustomMessageRepositorySpireOne.CCB004_4_marNotMetForAccount(cqNumber.toString(), account.getId().getTrimmedValue());
            }
        	// End Change - NMendo - 2020-06-26 - CCB004_Defect1
        }
    }

    @Override
    public Bool getAllowReopeningOfBills() {
        return allowReopeningOfBills;
    }

    @Override
    public BillCompletionActionLookup getBillCompletionAction() {
        return billCompletionAction;
    }

    @Override
    public ServerMessage getServerMessage() {
        return serverMessage;
    }

    @Override
    public void setAccount(Account account) {
        this.account = account; 
    }

    @Override
    public void setAccountingDate(Date accountingDate) {
    }

    @Override
    public void setAllowReopeningOfBills(Bool allowReopeningOfBills) {
        this.allowReopeningOfBills = allowReopeningOfBills;
    }

    @Override
    public void setBill(Bill bill) {
        this.bill = bill;
    }

    @Override
    public void setBillDate(Date billDate) {
    }

    @Override
    public void setBillSegments(List<BillSegment> billSegments) {
    }

    @Override
    public void setCreditNoteForBill(Bill creditNoteForBill) {
    }
    
    /**
     * This method encloses SA IDs inside single quotes
     * @param saList - SA ID List
     * @return String
     */
    private String encloseSAIdsInQuotes(List<ServiceAgreement> saList){
        StringBuilder saIds = new StringBuilder();

        saIds.append("'");

        for (int i = 0; i < saList.size(); i++){
            saIds.append(saList.get(i).getId().getTrimmedValue() + "'");
            if (i < saList.size() - 1) {
                saIds.append(",'");
            }
        }
        return saIds.toString();
    }
    
    /**
     * This method retrieves the SAs in the Bill's Bill Segments
     * @return List<ServiceAgreement>
     */
    private List<ServiceAgreement> retrieveBillSegmentSAs() {
        List<SQLResultRow> resultRows = null;

        StringBuilder strBldrBsegSAs = new StringBuilder();
        strBldrBsegSAs.append("SELECT ");
        strBldrBsegSAs.append(    "BSEG.SA_ID, ");
        strBldrBsegSAs.append(    "BSEG.START_DT, ");
        strBldrBsegSAs.append(    "BSEG.END_DT ");
        strBldrBsegSAs.append("FROM ");
        strBldrBsegSAs.append(    "CI_BSEG BSEG ");
        strBldrBsegSAs.append("WHERE ");
        strBldrBsegSAs.append(    "BSEG.BILL_ID = :bill ");
        strBldrBsegSAs.append(    "AND BSEG.BSEG_STAT_FLG IN ('30', '50') ");

        PreparedStatement prepStmtBsegSAs = createPreparedStatement(strBldrBsegSAs.toString(), getClass().getName());
        prepStmtBsegSAs.bindEntity("bill", bill);
        
        resultRows = prepStmtBsegSAs.list();
        prepStmtBsegSAs.close();
        
        Bool isFirstRow = Bool.TRUE;
        for (SQLResultRow resultRow : resultRows){
            ServiceAgreement_Id saId = (ServiceAgreement_Id) resultRow.getId("SA_ID", ServiceAgreement.class);
            Date bsegStartDate = (Date) resultRow.getDate("START_DT");
            Date bsegEndDate = (Date) resultRow.getDate("END_DT");
            
            // Determine maximum Bseg End Date and minimum Bseg Start Date
            if (isFirstRow.isFalse()){
                if (bsegStartDate.isBefore(billPeriodStartDate)){
                    billPeriodStartDate = bsegStartDate;
                }
                if (bsegEndDate.isAfter(billPeriodEndDate)){
                    billPeriodEndDate = bsegEndDate;
                }
            }
            else {
                billPeriodStartDate = bsegStartDate;
                billPeriodEndDate = bsegEndDate;
                isFirstRow = Bool.FALSE;
            }
            
            bsegSAs.add(saId.getEntity());
        }

        return bsegSAs;
    }
    
    /**
     * This method retrieves the effective Contract Quantity Details
     */
    private void retrieveContractQuantityDetails(){
        retrieveSAsThatShareCost();
        String saIds = encloseSAIdsInQuotes(serviceAgreementsThatShareMAR);

        SQLResultRow resultRow = null;
        
        StringBuilder strBldrContractTermDate = new StringBuilder();
        strBldrContractTermDate.append("SELECT ");
        strBldrContractTermDate.append(    "SCQ1.EFFDT, ");
        strBldrContractTermDate.append(    "SCQ1.CONT_QTY ");
        strBldrContractTermDate.append("FROM ");
        strBldrContractTermDate.append(    "CI_SA_CONT_QTY SCQ1 ");
        strBldrContractTermDate.append("WHERE ");
        strBldrContractTermDate.append(    "SCQ1.SA_ID IN (" + saIds + ") ");
        strBldrContractTermDate.append(    "AND SCQ1.CONT_QTY_TYPE_CD = :contractQuantityType ");
        strBldrContractTermDate.append(    "AND SCQ1.EFFDT = (SELECT MAX(EFFDT) FROM CI_SA_CONT_QTY SQC2 ");
        strBldrContractTermDate.append(                "WHERE SCQ1.SA_ID = SQC2.SA_ID ");
        strBldrContractTermDate.append(                "AND SCQ1.CONT_QTY_TYPE_CD = SQC2.CONT_QTY_TYPE_CD ");
        strBldrContractTermDate.append(                "AND SQC2.EFFDT <= :bsegEndDate)");
        
        PreparedStatement prepStmtContractTermDate = createPreparedStatement(strBldrContractTermDate.toString(), getClass().getName());
        prepStmtContractTermDate.bindId("contractQuantityType", parmMARContractQuantityType.getId());
        prepStmtContractTermDate.bindDate("bsegEndDate", billPeriodEndDate);
        
        resultRow = prepStmtContractTermDate.firstRow();
        if (notNull(resultRow)){
            cqEffDt = (Date) resultRow.getDate("EFFDT");
            cqNumber = (BigDecimal) resultRow.getBigDecimal("CONT_QTY");
        }
        prepStmtContractTermDate.close();
    }
    
    /**
     * This method retrieves the SAs that share cost
     */
    private void retrieveSAsThatShareCost(){
        List<SQLResultRow> resultRows = null;

        StringBuilder strBldrSharedCostSAs = new StringBuilder();
        strBldrSharedCostSAs.append("SELECT ");
        strBldrSharedCostSAs.append(    "SA.SA_ID ");
        strBldrSharedCostSAs.append("FROM ");
        strBldrSharedCostSAs.append(    "CI_SA SA, ");
        strBldrSharedCostSAs.append(    "CI_SA_CHAR SAC1 ");
        strBldrSharedCostSAs.append("WHERE ");
        strBldrSharedCostSAs.append(    "SA.ACCT_ID = :accountId ");
        strBldrSharedCostSAs.append(    "AND SA.SA_STATUS_FLG IN ('20','30','40','50') ");
        strBldrSharedCostSAs.append(    "AND (SA.END_DT IS NULL OR SA.END_DT > :bsegStartDate)   ");
        strBldrSharedCostSAs.append(    "AND SA.SA_ID = SAC1.SA_ID ");
        strBldrSharedCostSAs.append(    "AND SAC1.CHAR_TYPE_CD = :rctCharType ");
        strBldrSharedCostSAs.append(    "AND SAC1.EFFDT = (SELECT MAX(EFFDT) FROM CI_SA_CHAR SAC2 ");
        strBldrSharedCostSAs.append(                    "WHERE SAC1.SA_ID = SAC2.SA_ID ");
        strBldrSharedCostSAs.append(                    "AND SAC2.CHAR_TYPE_CD = SAC1.CHAR_TYPE_CD ");
        strBldrSharedCostSAs.append(                    "AND SAC2.EFFDT <= :bsegEndDate) ");

        PreparedStatement prepStmtSharedCostSAs = createPreparedStatement(strBldrSharedCostSAs.toString(), getClass().getName());
        prepStmtSharedCostSAs.bindId("accountId", account.getId());
        prepStmtSharedCostSAs.bindId("rctCharType", parmRCTCharacteristicType.getId());
        prepStmtSharedCostSAs.bindDate("bsegStartDate", billPeriodStartDate);
        prepStmtSharedCostSAs.bindDate("bsegEndDate", billPeriodEndDate);

        resultRows = prepStmtSharedCostSAs.list();
        prepStmtSharedCostSAs.close();
        
        for (SQLResultRow resultRow : resultRows){
            ServiceAgreement_Id currentSaId = (ServiceAgreement_Id) resultRow.getId("SA_ID", ServiceAgreement.class);
            serviceAgreementsThatShareMAR.add(currentSaId.getEntity());
        }
        
    }
    
    /**
     * This method retrieves applicable Bill Segments for the SA
     * @param serviceAgreementId - Service Agreement ID
     * @return List<BillSegment>
     */
    private List<BillSegment> retrieveSABillSegments(ServiceAgreement_Id serviceAgreementId){
        List<SQLResultRow> resultRows = null;
        List<BillSegment> saBsegs = new ArrayList<BillSegment>();

        StringBuilder strBldrSABillSegment = new StringBuilder();
        strBldrSABillSegment.append("SELECT ");
        strBldrSABillSegment.append(    "BSEG.BSEG_ID ");
        strBldrSABillSegment.append("FROM ");
        strBldrSABillSegment.append(    "CI_BSEG BSEG ");
        strBldrSABillSegment.append("WHERE ");
        strBldrSABillSegment.append(    "BSEG.SA_ID = :saId ");
        // Start Change - NMendo - 2020-06-26 - CCB004_Defect1
        //strBldrSABillSegment.append(    "AND BSEG.START_DT <= :annualPeriodEndDate ");
        strBldrSABillSegment.append(    "AND BSEG.START_DT < :annualPeriodEndDate ");
        // End Change - NMendo - 2020-06-26 - CCB004_Defect1
        strBldrSABillSegment.append(    "AND BSEG.END_DT >= :annualPeriodStartDate ");
        strBldrSABillSegment.append(    "AND BSEG.BSEG_STAT_FLG IN ('30','50') ");

        PreparedStatement prepStmtSABillSegments = createPreparedStatement(strBldrSABillSegment.toString(), getClass().getName());
        prepStmtSABillSegments.bindId("saId", serviceAgreementId);
        prepStmtSABillSegments.bindDate("annualPeriodStartDate", annualPeriodStartDate);
        prepStmtSABillSegments.bindDate("annualPeriodEndDate", annualPeriodEndDate);

        resultRows = prepStmtSABillSegments.list();
        prepStmtSABillSegments.close();
        
        for (SQLResultRow resultRow : resultRows){
            BillSegment_Id bsegId = (BillSegment_Id) resultRow.getId("BSEG_ID", BillSegment.class);
            
            saBsegs.add(bsegId.getEntity());
        }
        
        return saBsegs;
    }

    /**
     * This method gets the consumption amount for the Bill Segment
     * @param billSegment - Bill Segment
     * @return BigDecimal
     */
    private BigDecimal getBsegServiceQuantity(BillSegment billSegment){
        BigDecimal bsqConsumption = BigDecimal.ZERO;
        SQLResultRow resultRow = null;
        
        StringBuilder strBldrBsegServiceQuantity = new StringBuilder();
        strBldrBsegServiceQuantity.append("SELECT ");
        strBldrBsegServiceQuantity.append(    "SUM(BSQ.BILL_SQ) ");
        strBldrBsegServiceQuantity.append("FROM ");
        strBldrBsegServiceQuantity.append(    "CI_BSEG_SQ BSQ ");
        strBldrBsegServiceQuantity.append("WHERE ");
        strBldrBsegServiceQuantity.append(    "BSQ.BSEG_ID = :billSegmentId ");
        if (notNull(parmConsumptionUOM)){
            strBldrBsegServiceQuantity.append(    "AND BSQ.UOM_CD = :uom ");
        }
        else {
            strBldrBsegServiceQuantity.append(    "AND BSQ.UOM_CD = ' ' ");
        }
        if (notNull(parmConsumptionTOU)){
            strBldrBsegServiceQuantity.append(    "AND BSQ.TOU_CD = :tou ");
        }
        else {
            strBldrBsegServiceQuantity.append(    "AND BSQ.TOU_CD = ' ' ");
        }
        if (notNull(parmConsumptionSQI)){
            strBldrBsegServiceQuantity.append(    "AND BSQ.SQI_CD = :sqi ");
        }
        else {
            strBldrBsegServiceQuantity.append(    "AND BSQ.SQI_CD = ' ' ");
        }
        
        PreparedStatement prepStmtBsegServiceQuantity = createPreparedStatement(strBldrBsegServiceQuantity.toString(), getClass().getName());
        prepStmtBsegServiceQuantity.bindId("billSegmentId", billSegment.getId());
        if (notNull(parmConsumptionUOM)){
            prepStmtBsegServiceQuantity.bindId("uom", parmConsumptionUOM.getId());
        }
        if (notNull(parmConsumptionTOU)){
            prepStmtBsegServiceQuantity.bindId("tou", parmConsumptionTOU.getId());
        }
        if (notNull(parmConsumptionSQI)){
            prepStmtBsegServiceQuantity.bindId("sqi", parmConsumptionSQI.getId());
        }

        resultRow = prepStmtBsegServiceQuantity.firstRow();
        prepStmtBsegServiceQuantity.close();
        if (notNull(resultRow)){
            BigDecimal billSQ = (BigDecimal) resultRow.getBigDecimal("SUM(BSQ.BILL_SQ)");
            if (notNull(billSQ)){
                bsqConsumption = bsqConsumption.add(billSQ);    
            }
        }

        return bsqConsumption;
    }
}
