/*
 ***************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Severance Event Algorithm which creates a To Do Entry. This is a generic 
 * To Do Creation algorithm (no sort key; drill key is severance process id)
 *      
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2018-04-16   JHERNA  SysAid#235527. Initial Version.
 * 
 **************************************************************************/
package com.splwg.cm.domain.admin.severanceEventType.algorithm.event;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.message.MessageCategory;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.ccb.domain.admin.severanceEventType.algorithm.event.SeveranceEventTypeEventAlgorithmSpot;
import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceEvent;
import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceProcess;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = role, name = toDoRole, type = entity)
 *            , @AlgorithmSoftParameter (entityName = messageCategory, name = messageCategory, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = messageNumber, required = true, type = integer)})
 */
public class CmCreateToDoEntryEventAlgComp_Impl 
		extends CmCreateToDoEntryEventAlgComp_Gen 
		implements SeveranceEventTypeEventAlgorithmSpot {

	
	// HARD PARAMETERS
	@SuppressWarnings("unused")
	private ServiceAgreement hpSA;
	@SuppressWarnings("unused")
	private SeveranceEvent hpSevEvt;	
	
	// SOFT PARAMETERS
	private ToDoType parmTdType;
	private Role parmTdRole;
	private MessageCategory parmMessageCat;
	private BigInteger parmMessageNbr;
	
	// Work Variable(s)
	private SeveranceProcess wSevProcess;
	private Message_Id wMessageID;
	private DateTime wProcessDttm;
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		
		parmTdType = this.getToDoType();
		
		if (notNull(this.getToDoRole())) {
			parmTdRole = this.getToDoRole();
			ToDoTypeRole_Id tdTypeRoleID = new ToDoTypeRole_Id(parmTdType, parmTdRole);
			if (isNull(tdTypeRoleID.getEntity())) {
				// Algorithm (%1)'s To Do Role parameter (%2) is not valid for To Do Type parameter (%3)
				addError(CustomMessageRepositoryMGE.commAlgorithmParameterToDoRoleNotValidForParameterToDoType(this.getAlgorithmId().getTrimmedValue(),
						parmTdRole.getId().getTrimmedValue(), parmTdRole.getId().getTrimmedValue()));
			}
		}
		else {
			parmTdRole = parmTdType.getDefaultRole().fetchIdToDoRole();
		}		
		
		parmMessageCat = this.getMessageCategory();
		parmMessageNbr = this.getMessageNumber();
		
		wMessageID = new Message_Id(parmMessageCat, parmMessageNbr);
		if (isNull(wMessageID.getEntity())) {
			addError(CustomMessageRepositoryMGE.commGenericError("Algorithm Parameter Message Category ("+
						parmMessageCat.getId().getIdValue().toString().trim()+") and Algorithm Parameter Message Number ("+
						parmMessageNbr.toString().trim()+") is an invalid combination for Message Entity."));
		}
		wProcessDttm = this.getProcessDateTime();
	}

	@Override
	public void setServiceAgreement(ServiceAgreement sa) {
		hpSA = sa;
	}

	@Override
	public void setSeveranceEvent(SeveranceEvent se) {
		hpSevEvt = se;
		wSevProcess = se.fetchIdSeveranceProcess();
	}
	
	@Override
	public void invoke() {

		// initialize Drill Keys
		List<String> collDrillKeyValues = new ArrayList<String>();
		collDrillKeyValues.add(wSevProcess.getId().getTrimmedValue());
		// initialize Sort Keys
		List<String> collSortKeyValues = new ArrayList<String>();
		collSortKeyValues.add(wSevProcess.getId().getTrimmedValue());
		// initialize Message Parameters
		List<String> collMessageParms = new ArrayList<String>();
		// Create To Do Entry
		cmCreateToDo(collSortKeyValues, collDrillKeyValues, collMessageParms);
	}


	private void cmCreateToDo(List<String> collSortKeyValues, List<String> collDrillKeyValues, List<String> collMessageParms) {		
		
		Logger lg = LoggerFactory.getLogger(CmCreateToDoEntryEventAlgComp_Impl.class);

		try {
			ToDoCreator tdCreator = ToDoCreator.Factory.newInstance();
			ToDoEntry_DTO tdEntryDTO = tdCreator.getToDoDTO();
			tdEntryDTO.setCreationDateTime(wProcessDttm);
			tdEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
			tdEntryDTO.setToDoTypeId(parmTdType.getId());
			tdEntryDTO.setToDoRoleId(parmTdRole.getId());
			tdEntryDTO.setMessageId(wMessageID);
			tdCreator.setToDoDTO(tdEntryDTO);
			
			/* 
			// Removed because this severance event algorithm is created to be generic To Do Creation algorithm. 
			// The only consistent thing is the drill key which is supposed to be the severance process
			List<ToDoSortKeyType> collOfSortKeyTypes = cmGetSortKeyTypes(parmTdType.getId());			
			  
			for (int x = 0; x < collOfSortKeyTypes.size(); x++) {
				
				ToDoSortKeyType tdSortKeyType = collOfSortKeyTypes.get(x);
				tdCreator.addSortKeyValue(tdSortKeyType, collSortKeyValues.get(x));
			}
			*/
			
			List<ToDoDrillKeyType> collOfDrillKeyTypes = cmGetDrillKeyTypes(parmTdType.getId());			
			/*
			for (int x = 0; x < collOfDrillKeyTypes.size(); x++) {
				
				ToDoDrillKeyType tdDrillKeyType = collOfDrillKeyTypes.get(x);
				tdCreator.addDrillKeyValue(tdDrillKeyType, collDrillKeyValues.get(x));				
			}
			*/
			ToDoDrillKeyType tdDrillKeyType = collOfDrillKeyTypes.get(0);
			tdCreator.addDrillKeyValue(tdDrillKeyType, collDrillKeyValues.get(0));
			
			for (int x = 0; x < collMessageParms.size(); x++) {
				tdCreator.addMessageParameter(collMessageParms.get(x));
			}
			
			ToDoEntry tdEntry = tdCreator.create();			
			lg.info("\n==Created To Do Entry:"+tdEntry.getId().getTrimmedValue()+"==\n");
		}
		catch (Exception e) {
			e.printStackTrace();
			lg.info(e.getMessage());
		}				
	}
	/*
	private List<ToDoSortKeyType> cmGetSortKeyTypes(ToDoType_Id tdTypeID) {
		
		List<ToDoSortKeyType> returnValue = new ArrayList<ToDoSortKeyType>();
		
		StringBuilder stringBuilder = new StringBuilder();					
		stringBuilder.append("SELECT TD_TYPE_CD, SEQ_NUM ");
		stringBuilder.append("FROM CI_TD_SRTKEY_TY ");
		stringBuilder.append("WHERE TD_TYPE_CD = :tdTypeID ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=GET TO DO TYPE SORT KEYS");
		prepState.bindId("tdTypeID", tdTypeID);
		prepState.execute();
		
		if (prepState.list().size() > 0) {
			
			Iterator<SQLResultRow> iter = prepState.list().iterator();
			
			while (iter.hasNext()) {
			
				SQLResultRow sqlRow = (SQLResultRow) iter.next();					
				BigInteger seq = (BigInteger) sqlRow.getInteger("SEQ_NUM");
				ToDoSortKeyType_Id tdSortKeyTypeID = new ToDoSortKeyType_Id(tdTypeID, seq);
				returnValue.add(tdSortKeyTypeID.getEntity());
			}								
		}			
		prepState.close();
		return returnValue;
	}
	*/
	private List<ToDoDrillKeyType> cmGetDrillKeyTypes(ToDoType_Id tdTypeID) {
		
		List<ToDoDrillKeyType> returnValue = new ArrayList<ToDoDrillKeyType>();
		
		StringBuilder stringBuilder = new StringBuilder();					
		stringBuilder.append("SELECT TD_TYPE_CD, SEQ_NUM ");
		stringBuilder.append("FROM CI_TD_DRLKEY_TY ");
		stringBuilder.append("WHERE TD_TYPE_CD = :tdTypeID ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=GET TO DO TYPE DRILL KEYS=");
		prepState.bindId("tdTypeID", tdTypeID);
		prepState.execute();
		
		if (prepState.list().size() > 0) {
			
			Iterator<SQLResultRow> iter = prepState.list().iterator();
			
			while (iter.hasNext()) {
			
				SQLResultRow sqlRow = (SQLResultRow) iter.next();
				BigInteger seq = (BigInteger) sqlRow.getInteger("SEQ_NUM");
				ToDoDrillKeyType_Id tdDrillKeyTypeID = new ToDoDrillKeyType_Id(tdTypeID, seq);
				returnValue.add(tdDrillKeyTypeID.getEntity());
			}								
		}			
		prepState.close();
		return returnValue;
		
	}
}
