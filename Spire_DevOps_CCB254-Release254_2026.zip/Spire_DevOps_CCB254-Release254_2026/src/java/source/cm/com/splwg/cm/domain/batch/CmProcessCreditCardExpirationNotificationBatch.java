/*
 ***************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Credit Card Expiration Date Notification Batch
 * 
 * This batch program checks the credit card payment methods' expiration
 * date and notifies customer that their payment method is expired.
 *            
 ****************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2020-01-13   JLumbre SpireOne.Initial Version.
 *  
 ****************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.serviceScript.ServiceScriptDispatcher;
import com.splwg.base.api.serviceScript.ServiceScriptInstance;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.CardTypeLookup;
import com.splwg.ccb.api.lookup.ExternalTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.autopaySource.entity.AutopaySource_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountAutopay;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountAutopay_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactLog_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonPaymentOption;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonPaymentOption_Id;
import com.splwg.cm.api.lookup.CmServiceEventFlgLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author TMG02631
 *
@BatchJob (rerunnable = false, modules= {},
 *      softParameters = { @BatchJobSoftParameter (name = DAYS_TO_EXPIRE_DATE, required = true, type = integer)
 *            , @BatchJobSoftParameter (name = DAYS_SINCE_EXPIRE_DATE, required = true, type = integer)
 *            , @BatchJobSoftParameter (name = REMOVE_AUTOPAY_IF_EXPIRED, required = true, type = boolean)})
 */
public class CmProcessCreditCardExpirationNotificationBatch extends
CmProcessCreditCardExpirationNotificationBatch_Gen {

	private static final Logger log = LoggerFactory.getLogger(CmProcessCreditCardExpirationNotificationBatch.class);
	private BigInteger daysToExpireDt;
	private BigInteger daysSinceExpireDt;


	@Override
	public void validateSoftParameters(boolean isNewRun) {
		daysToExpireDt = getParameters().getDAYS_TO_EXPIRE_DATE();
		String daysToExpireDtDescr = "Number of Days to Expire Date";
		String daysSinceExpireDtDescr = "Number of Days Since Expire Date";

		if (daysToExpireDt.intValue() < 0){
			addError(CustomMessageRepositorySpireOne.S1_batchParmCannotBeLessThanZero(daysToExpireDtDescr));			
		}
		daysSinceExpireDt = getParameters().getDAYS_SINCE_EXPIRE_DATE();
		if (daysSinceExpireDt.intValue() < 0){
			addError(CustomMessageRepositorySpireOne.S1_batchParmCannotBeLessThanZero(daysSinceExpireDtDescr));	
		}
	}

	public JobWork getJobWork() {
		/*SELECT DISTINCT SS.PER_PAY_OPT_ID, AC.ACCT_ID
		FROM C1_PER_SS_PAYOPT SS, CI_ACCT_PER AP, CI_ACCT AC, CI_SA SA, CI_SA_TYPE SAT
		WHERE 1=1
		AND SS.EXT_TYPE_FLG='47'
		AND SS.PER_ID=AP.PER_ID
		AND AP.MAIN_CUST_SW='Y'
		AND AP.ACCT_ID=AC.ACCT_ID
		AND AC.ACCT_ID=SA.ACCT_ID
		AND SA.SA_TYPE_CD=SAT.SA_TYPE_CD
		AND SA.CIS_DIVISION=SAT.CIS_DIVISION
		AND SAT.SVC_TYPE_CD='G'
		AND SA.SA_STATUS_FLG='20'
		ORDER BY AC.ACCT_ID;*/

		StringBuilder mainStr = new StringBuilder();
		mainStr.append("SELECT DISTINCT SS.PER_PAY_OPT_ID, AC.ACCT_ID ");
		mainStr.append("FROM C1_PER_SS_PAYOPT SS, CI_ACCT_PER AP, CI_ACCT AC, CI_SA SA, CI_SA_TYPE SAT ");
		mainStr.append("WHERE ");
		mainStr.append("SS.EXT_TYPE_FLG= :47 ");
		mainStr.append("AND SS.PER_ID=AP.PER_ID ");
		mainStr.append("AND AP.MAIN_CUST_SW='Y' ");
		mainStr.append("AND AP.ACCT_ID=AC.ACCT_ID ");
		mainStr.append("AND AC.ACCT_ID=SA.ACCT_ID ");
		mainStr.append("AND SA.SA_TYPE_CD=SAT.SA_TYPE_CD ");
		mainStr.append("AND SA.CIS_DIVISION=SAT.CIS_DIVISION ");
		mainStr.append("AND SAT.SVC_TYPE_CD='G' ");
		mainStr.append("AND SA.SA_STATUS_FLG NOT IN (:60, :70) ");
		mainStr.append("ORDER BY AC.ACCT_ID ");

		PreparedStatement  mainQry = createPreparedStatement(mainStr.toString(), "getJobWork");
		mainQry.bindLookup("47", ExternalTypeLookup.constants.CREDIT_CARD_WITHDRAWAL);
		mainQry.bindLookup("60", ServiceAgreementStatusLookup.constants.CLOSED);
		mainQry.bindLookup("70", ServiceAgreementStatusLookup.constants.CANCELED);

		mainQry.execute();
		mainQry.setAutoclose(false);

		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();

		QueryIterator<SQLResultRow> iter = mainQry.iterate();

		while (iter.hasNext()) {
			SQLResultRow row = iter.next();

			ThreadWorkUnit workUnit = new ThreadWorkUnit();

			workUnit.setPrimaryId((PersonPaymentOption_Id) row.getId("PER_PAY_OPT_ID", PersonPaymentOption.class));
			workUnit.addSupplementalData("ACCT_ID", row.getString("ACCT_ID"));		

			workUnits.add(workUnit);              
		}
		iter.close();  
		mainQry.close();

		return createJobWorkForThreadWorkUnitList(workUnits);

	}

	public Class<CmProcessCreditCardExpirationNotificationBatchWorker> getThreadWorkerClass() {
		return CmProcessCreditCardExpirationNotificationBatchWorker.class;
	}

	public static class CmProcessCreditCardExpirationNotificationBatchWorker
	extends CmProcessCreditCardExpirationNotificationBatchWorker_Gen{

		//Date Variables
		private Date expirationDate = null;
		private Date processDate = null;		
		private String mmYy = "";

		//Pay Option Variables
		private String personName;
		private String cardType;
		private String cardTypeDescr;
		private String cardNbr;
		private String cardNbrLast4;

		private String expMonth;
		private String expYear;

		//PMOC Variables
		private String emailPmoc;
		private String smsPmoc;

		//Message Variables
		String emailMessage;
		String txtMessage;

		//Work Variables
		private PersonPaymentOption personPaymentOption = null;
		private Account_Id accountId = null;
		private AccountAutopay apay = null;
		private ServiceScriptInstance serviceScriptInstance;
		private COTSInstanceNode scriptInput;
		private COTSInstanceNode scriptOutput;
		private Bool hasPMOC = Bool.FALSE;
		private Bool isUsedOnApay = Bool.FALSE;

		//Constants
		private static final String eventAuto = "CARD_EXP_AUTO";
		private static final String event = "CARD_EXP";
		private static final String emailCommType = "E";
		private static final String textCommType = "T";
		private static final String SLASH = "/";
		private static final String CM_PmocInfo = "CM-PmocInfo";
		private static final String INPUT = "input";
		private static final String OUTPUT = "output";
		private static final String CM_SAPNotif = "CM-SAPNotif";
		private static final String CM_CrePrtlCC = "CM-CrePrtlCC";
		private static final String CM_AutoPayMa = "CM-AutoPayMa";

		//soft parameters
		private BigInteger noOfdaysToExpireDate;
		private BigInteger noOfDaysSinceExpiredDate;
		private Bool removeApayIfExpired;

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		public void initializeThreadWork(boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException
		{
			noOfdaysToExpireDate = getParameters().getDAYS_TO_EXPIRE_DATE();
			noOfDaysSinceExpiredDate = getParameters().getDAYS_SINCE_EXPIRE_DATE();
			removeApayIfExpired = getParameters().getREMOVE_AUTOPAY_IF_EXPIRED();
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			//initialize variables

			/*//Pay Option Variables
			personName="";
			cardType = "";
			cardTypeDescr = "";
			cardNbr = "";
			cardNbrLast4 = "";
			expMonth = "";
			expYear = "";
			mmYy = "";*/

			//PMOC Variables
			emailPmoc = "";
			smsPmoc = "";

			//Message Variables
			emailMessage = "";
			txtMessage = "";

			//Query Result
			PersonPaymentOption_Id ppId =  (PersonPaymentOption_Id) unit.getPrimaryId();
			accountId = new Account_Id((String) unit.getSupplementallData("ACCT_ID"));

			//Entities
			personPaymentOption = ppId.getEntity();	
			if (isNull(personPaymentOption)){
				log.debug(">>>>> WARNING: PersonPaymentOption not found");
				return false;
			}

			log.debug(">>>>> pp: " + personPaymentOption.getId().getTrimmedValue());
			log.debug(">>>>> acct: " + accountId.getTrimmedValue());

			//Pay Option Details
			personName =personPaymentOption.getPerson().getPersonPrimaryName().toUpperCase();
			cardType = personPaymentOption.getCardType().getLookupValue().fetchIdFieldValue();
			cardNbr = personPaymentOption.getCreditCardNumber().trim();
			cardTypeDescr = getCardDescription();
			cardNbrLast4 = getCcLast4Digits(cardNbr, 4);			
			log.debug(">>>>> personName: " + personName);
			log.debug(">>>>> cardType: " + cardType);
			log.debug(">>>>> cardNbr: " + cardNbr);
			log.debug(">>>>> cardTypeDescr: " + cardTypeDescr);
			log.debug(">>>>> cardNbrLast4: " + cardNbrLast4);

			//Date Info
			processDate = getProcessDateTime().getDate();
			expirationDate = buildExpireDate();

			if (isNull(expirationDate)){
				expirationDate = processDate;
			}
			log.debug(">>>>> expirationDate: " + expirationDate);

			isUsedOnApay = isPayMethodOnAutoPay(accountId, cardType, cardNbr);

			//Main processing
			//If CC expires in X days (X = parm 1)
			if (processDate.equals(expirationDate.addDays(-noOfdaysToExpireDate.intValue()))){
				log.debug(">>>>> today.equals(expirationDate.addDays(-noOfdaysToExpireDate))");
				notifyCustomerMAIN(Bool.FALSE);

			}

			//If CC is expired X days (X = parm 2)
			if (processDate.equals(expirationDate.addDays(noOfDaysSinceExpiredDate.intValue()))){
				log.debug(">>>>> today.isAfter(expirationDate.addDays(noOfDaysSinceExpiredDate))");
				notifyCustomerMAIN(Bool.TRUE);
				//if CC is expired and used on Auto pay, cancel auto pay
				if (removeApayIfExpired.isTrue()){
					//Parm 3 is True
					if(!isNull(apay)){
						cancelAutopay(CM_AutoPayMa, accountId);
					}
				}

			}

			return true;
		}

		private String getCardDescription(){
			String cardDescription = "";
			CardTypeLookup cardType = personPaymentOption.getCardType();
			cardDescription = cardType.getLookupValue().fetchLanguageDescription().toUpperCase();
			return cardDescription;
		}

		public String getCcLast4Digits(String ccNbr, int digit){
			int length = ccNbr.length();
			if(length <= digit){
				return ccNbr;
			}
			int startIndex = length-digit;
			return ccNbr.substring(startIndex);
		}

		public Date buildExpireDate(){
			Date expireDate = null;
			int month = 0;
			int year = 0;
			int day = 31;

			expMonth = personPaymentOption.getExpirationMonth();
			expYear = personPaymentOption.getExpirationYear();
			month = Integer.parseInt(expMonth);
			year = Integer.parseInt(expYear);
			mmYy = expMonth.concat(SLASH).concat(expYear);

			if (month == 2){
				if (year%4==0){
					day = 29;
				}
				else{
					day = 28;
				}
			}

			if (month == 4 || month == 6 || month == 9 || month == 11){
				day = 30;
			}

			try{
				expireDate = new Date(year, month, day);
			}
			catch(ApplicationError e){
				e.getServerMessage();
			}

			return expireDate;
		}

		public void notifyCustomerMAIN(Bool isExpired){
			log.debug(">>>>> notifyCustomerMAIN");
			retrievePMOC(CM_PmocInfo,accountId);
			if (hasPMOC.isTrue()){
				sendNotification(isExpired);	
				createCustomerContact(CM_CrePrtlCC,accountId);
			}			
		}

		public void retrievePMOC(String service, Account_Id accountId){
			log.debug(">>>>> START retrievePMOC ");
			serviceScriptInstance = null;
			scriptInput = null;
			scriptOutput = null;
			hasPMOC = Bool.FALSE;
			// Create an instance of the service script
			serviceScriptInstance = ServiceScriptInstance.create(service);
			// Retrieve the script's input node
			scriptInput = serviceScriptInstance.getGroup(INPUT);
			// Account Id
			scriptInput.set("accountId", accountId.getTrimmedValue());
			// Invoke the service script
			try {
				ServiceScriptDispatcher.invoke(serviceScriptInstance);
				scriptOutput = serviceScriptInstance.getGroup(OUTPUT);
				if (scriptOutput.getGroup("errorInformation").getBoolean("isInError").isFalse()){
					if (!isBlankOrNull(scriptOutput.getGroup("pmoc").getString("emailAddress"))){						
						emailPmoc = scriptOutput.getGroup("pmoc").getString("emailAddress");
						log.debug(">>>>> emailPmoc: " + emailPmoc);
						hasPMOC = Bool.TRUE;
					}

					if (!isBlankOrNull(scriptOutput.getGroup("pmoc").getString("smsPhone"))){					
						smsPmoc = scriptOutput.getGroup("pmoc").getString("smsPhone");
						log.debug(">>>>> smsPmoc: " + smsPmoc);
						hasPMOC = Bool.TRUE;								
					}
				}
			} catch (ApplicationError ae){
				ae.getServerMessage();
			}
			log.debug(">>>>> END retrievePMOC ");
		}

		public void sendNotification(Bool isExpired){
			log.debug(">>>>> START sendNotification");		
			serviceScriptInstance = null;
			scriptInput = null;
			scriptOutput = null;

			//is card used on auto pay
			//Bool isUsedOnApay = isPayMethodOnAutoPay(accountId, cardType, cardNbr);
			log.debug(">>>>> isUsedOnApay: " + isUsedOnApay);
			serviceScriptInstance = ServiceScriptInstance.create(CM_SAPNotif);
			// Account Id
			serviceScriptInstance.set("account", accountId.getTrimmedValue());

			if (!isBlankOrNull(emailPmoc)){					
				log.debug(">>>>> sendNotification emailPmoc");
				if (isExpired.isTrue()){
					log.debug(">>>>> sendNotification isExpired");
					emailMessage = "expired on " + mmYy; 
				}
				else{
					log.debug(">>>>> sendNotification isExpired false");
					emailMessage = "expires on " + mmYy;
				}
				serviceScriptInstance.set("communicationType", emailCommType);
				serviceScriptInstance.set("emailDestination", emailPmoc);
				serviceScriptInstance.set("emailParameter1", personName);
				serviceScriptInstance.set("emailParameter2", cardTypeDescr);
				serviceScriptInstance.set("emailParameter3", cardNbrLast4);
				serviceScriptInstance.set("emailParameter4", emailMessage);

				if (isUsedOnApay.isTrue()){
					serviceScriptInstance.set("event", eventAuto);
				}
				else{
					serviceScriptInstance.set("event", event);
				}

				try{
					ServiceScriptDispatcher.invoke(serviceScriptInstance);	
				}
				catch (ApplicationError e){
					log.debug(">>>>> ERROR sendNotification");
					e.getServerMessage();
				}
			}

			serviceScriptInstance = null;
			scriptInput = null;
			scriptOutput = null;

			serviceScriptInstance = ServiceScriptInstance.create(CM_SAPNotif);
			// Account Id
			serviceScriptInstance.set("account", accountId.getTrimmedValue());

			if (!isBlankOrNull(smsPmoc)){	
				log.debug(">>>>> sendNotification smsPmoc");
				if (isExpired.isTrue()){
					if(isUsedOnApay.isFalse()){
						txtMessage = CustomMessageRepositorySpireOne.S1_ccExpiredNotAutoPay(cardTypeDescr, cardNbrLast4, mmYy).getMessageText();
					}
					else{
						txtMessage = CustomMessageRepositorySpireOne.S1_ccExpiredAutoPay(cardTypeDescr, cardNbrLast4, mmYy).getMessageText();
					}
				}
				else{
					if(isUsedOnApay.isFalse()){
						txtMessage = CustomMessageRepositorySpireOne.S1_ccExpiresNotAutoPay(cardTypeDescr, cardNbrLast4, mmYy).getMessageText();
					}
					else{
						txtMessage = CustomMessageRepositorySpireOne.S1_ccExpiresAutoPay(cardTypeDescr, cardNbrLast4, mmYy).getMessageText();
					}
				}
				serviceScriptInstance.set("communicationType", textCommType);
				serviceScriptInstance.set("textDestination", smsPmoc);
				serviceScriptInstance.set("textMessage", txtMessage);


				if (isUsedOnApay.isTrue()){
					serviceScriptInstance.set("event", eventAuto);
				}
				else{
					serviceScriptInstance.set("event", event);
				}

				try{
					ServiceScriptDispatcher.invoke(serviceScriptInstance);	
				}
				catch (ApplicationError e){
					log.debug(">>>>> ERROR sendNotification");
					e.getServerMessage();
				}
			}
			log.debug(">>>>> END sendNotification");
		}

		public Bool isPayMethodOnAutoPay(Account_Id accountId, String cardType, String cardNbr){
			Bool isUsed = Bool.FALSE;
			String apayIdStr = "";
			log.debug(">>>>> isPayMethodOnAutoPay ");
			log.debug(">>>>> cardType " +cardType);
			log.debug(">>>>> cardNbr " +cardNbr);
			StringBuilder apayStr = new StringBuilder();
			apayStr.append("SELECT ");
			apayStr.append("AP.ACCT_APAY_ID, AP.APAY_SRC_CD, AP.EXT_ACCT_ID ");
			apayStr.append("FROM CI_ACCT_APAY AP,  CI_APAY_SRC APS,  CI_TENDER_TYPE TT ");
			apayStr.append("WHERE AP.ACCT_ID = :accountId ");
			apayStr.append("AND APS.APAY_SRC_CD   = AP.APAY_SRC_CD ");
			apayStr.append("AND TT.TENDER_TYPE_CD = APS.TENDER_TYPE_CD ");
			apayStr.append("AND TT.EXT_TYPE_FLG = :47 ");
			apayStr.append("AND AP.START_DT <= :processDate ");
			apayStr.append("AND (AP.END_DT IS NULL ");
			apayStr.append("OR AP.END_DT > SYSDATE) ");
			apayStr.append("AND AP.APAY_SRC_CD = :cardType ");
			apayStr.append("AND AP.EXT_ACCT_ID = :cardNbr ");
			apayStr.append("ORDER BY AP.START_DT DESC ");

			PreparedStatement apayQry = createPreparedStatement(apayStr.toString(), "isPayMethodOnAutoPay");
			apayQry.bindId("accountId", accountId);
			apayQry.bindDate("processDate", getProcessDateTime().getDate());
			apayQry.bindLookup("47", ExternalTypeLookup.constants.CREDIT_CARD_WITHDRAWAL);
			apayQry.bindEntity("cardType",new AutopaySource_Id(cardType).getEntity());
			apayQry.bindString("cardNbr",cardNbr, "AP.EXT_ACCT_ID");

			apayQry.execute();	
			apayQry.setAutoclose(false);

			if (apayQry.list().size() > 0){				
				SQLResultRow row = apayQry.firstRow();
				apayIdStr = (String) row.get("ACCT_APAY_ID");
				apay = new AccountAutopay_Id(apayIdStr).getEntity();
				log.debug(">>>>> auto pay true");				
				isUsed = Bool.TRUE;
			}
			apayQry.close();

			return isUsed;
		}

		private void cancelAutopay(String service, Account_Id accountId) {
			log.debug(">>>>> START cancelAutopay");

			serviceScriptInstance = null;
			scriptInput = null;
			
			serviceScriptInstance = ServiceScriptInstance.create(service);
			// Retrieve the script's input node
			scriptInput = serviceScriptInstance.getGroup(INPUT);
			// Account Id
			scriptInput.set("accountId", accountId.getTrimmedValue());

			// Set APAY as event
			scriptInput.set("cmAutopayActionFlag", "X");
			
			try {
				ServiceScriptDispatcher.invoke(serviceScriptInstance);
			} catch (ApplicationError ae){
				ae.getServerMessage();
			}			
			log.debug(">>>>> END cancelAutopay");
		}

		private void createCustomerContact(String service, Account_Id accountId){
			log.debug(">>>>> START createCustomerContact");
			serviceScriptInstance = null;
			scriptInput = null;
			scriptOutput = null;

			// Create an instance of the service script
			serviceScriptInstance = ServiceScriptInstance.create(service);
			// Retrieve the script's input node
			scriptInput = serviceScriptInstance.getGroup(INPUT);
			// Account Id
			scriptInput.set("accountId", accountId.getTrimmedValue());

			// Set APAY as event
			scriptInput.set("event", CmServiceEventFlgLookup.constants.PAYMENT_OPTION_MAINTENANCE);

			// Invoke the service script
			try {
				ServiceScriptDispatcher.invoke(serviceScriptInstance);
				scriptOutput = serviceScriptInstance.getGroup(OUTPUT);
				String ccIdStr = scriptOutput.getString("customerContacId");
				CustomerContact_Id ccId = new CustomerContact_Id(ccIdStr);
				if (!isNull(ccId)){
					CustomerContact cc = ccId.getEntity();
					addCcLog(cc);					
				}
			} catch (ApplicationError ae){
				ae.getServerMessage();
			}
			log.debug(">>>>> END createCustomerContact");
		}

		private void addCcLog(CustomerContact customerContact){
			log.debug(">>>>> START addCcLog");
			String logEntry = "";
			if (!isBlankOrNull(emailPmoc)){
				logEntry= CustomMessageRepositorySpireOne.S1_ccEmailMessage(emailPmoc, personName, cardTypeDescr, cardNbrLast4, emailMessage).getMessageText();	
				if (!isNull(customerContact)){
					CustomerContactLog_DTO cclDTO = new CustomerContactLog_DTO();
					cclDTO.setCustomerContactId(customerContact.getId());
					cclDTO.setCreationDateTime(getProcessDateTime());
					cclDTO.setUserId(getActiveContextUser().getId());
					cclDTO.setLogEntry(logEntry);

					cclDTO.newEntity();
				}
			}

			if(!isBlankOrNull(smsPmoc)){				
				logEntry = CustomMessageRepositorySpireOne.S1_ccTextMessage(smsPmoc, txtMessage).getMessageText();
				if (!isNull(customerContact)){
					CustomerContactLog_DTO cclDTO = new CustomerContactLog_DTO();
					cclDTO.setCustomerContactId(customerContact.getId());
					cclDTO.setCreationDateTime(getProcessDateTime());
					cclDTO.setUserId(getActiveContextUser().getId());
					cclDTO.setLogEntry(logEntry);

					cclDTO.newEntity();
				}
			}
			log.debug(">>>>> END addCcLog");
		}
	}
}

