/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * General Letter Extract
 *
 * This is basically a clone of the base generic letter extract algorithm
 * and extending it to include some more details which are important for
 * Spire customers.
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2020-03-25   JHERNA  SysAid#322461. Re-coded to full java for better
 *                      performance and readability for easier future
 *                      maintenance.
 * 2020-06-11   RDizon  CCB034.Issue2. Print LPC Date only for CIS Divisions
 *                      that do not implement Late Payment Charge.
 * 2022-10-24   DLampa  E-06060. Extract the bill format flag depending
 *                      on the account's CIS Division.
 * 2023-03-23   DLampa  E-06267.Issue1. Handle null pointer exception when
 *                      a CIS Division cannot be retrieved.
 * 2024-02-06	IReyes	E-08254. Extract the High Bill Reviewed (CMHBLINQ) 
 * 						letter 2 business days after it was created        
 * 2024-10-25   DLampa  E-09710. Update query that retrieves accounts 
 *                      to filter those without CIS Divisions     
 * 2024-12-13   DLampa  E-09710.Issue1. Do not increment the count of    
 *                      extracted customer contacts for delayed High 
 *                      Bill Reviewed customer contacts        
 **************************************************************************/
package com.splwg.cm.domain.admin.letterTemplate.algorithm.letterExtract;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchRun.BatchRun;
import com.splwg.base.domain.common.algorithm.Algorithm;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.common.workCalendar.WorkCalendar;
import com.splwg.base.domain.report.reportDefinition.ReportDefinition;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.ccb.api.lookup.BillingAddressSourceLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.letterTemplate.algorithm.letterExtract.LetterTemplateLetterExtractAlgorithmSpot;
import com.splwg.ccb.domain.admin.letterTemplate.entity.LetterTemplate;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.common.fileHelper.FileHelper;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.data.AccountMailingAddressData;
import com.splwg.ccb.domain.customerinfo.paymentPlan.entity.PaymentPlan;
import com.splwg.ccb.domain.customerinfo.paymentPlan.entity.PaymentPlanScheduledPayment;
import com.splwg.ccb.domain.customerinfo.paymentPlan.entity.PaymentPlanScheduledPayment_Id;
import com.splwg.ccb.domain.customerinfo.paymentPlan.entity.PaymentPlan_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonCharacteristic;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.ccb.domain.payment.payment.entity.Payment_Id;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentEvent;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentEvent_Id;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
import com.splwg.cm.api.batch.generalLetters.CmGeneralLetterAccountPersonExtractRecord;
import com.splwg.cm.api.batch.generalLetters.CmGeneralLetterAdjustmentInfoExtractRecord;
import com.splwg.cm.api.batch.generalLetters.CmGeneralLetterBillInformationExtractRecord;
import com.splwg.cm.api.batch.generalLetters.CmGeneralLetterEndOfLetterExtractRecord;
import com.splwg.cm.api.batch.generalLetters.CmGeneralLetterExtractRecord;
import com.splwg.cm.api.batch.generalLetters.CmGeneralLetterFaInfoExtractRecord;
import com.splwg.cm.api.batch.generalLetters.CmGeneralLetterMailingInfoExtractRecord;
import com.splwg.cm.api.batch.generalLetters.CmGeneralLetterOtherCharacteristicInfoExtractRecord;
import com.splwg.cm.api.batch.generalLetters.CmGeneralLetterPayPlanInfoExtractRecord;
import com.splwg.cm.api.batch.generalLetters.CmGeneralLetterPaymentEventInfoExtractRecord;
import com.splwg.cm.api.batch.generalLetters.CmGeneralLetterPremiseInfoExtractRecord;
import com.splwg.cm.domain.common.customBusinessComponent.CmAccountCheckDigitRetriever;
import com.splwg.cm.domain.constants.CustomConstantsRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author blu02772
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = accountIDCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = prefMethodOfContactCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = prefMethodOfEmailCharVal, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = prefMethodOfContactCharVal, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = mailToMultipleCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = mailToMultipleCharVal, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = premiseIDCharType, type = entity)
 *            , @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = role, name = toDoRole, type = entity)
 *            , @AlgorithmSoftParameter (name = cisDivisionsWithoutLPC, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = cisDivisionForFormat, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = ccTypeForLetterDelay, required = true, type = string)})
 */
public class CmGeneralLetterExtractAlgComp_Impl
        extends CmGeneralLetterExtractAlgComp_Gen
        implements LetterTemplateLetterExtractAlgorithmSpot {	
	
    /* *****************s
     * Hard Parameters *
     * *****************/
    private BigInteger hpCcExtractedCount;
    private ReportDefinition hpReportDefinition;
    @SuppressWarnings("unused")
    private BatchRun hpBatchRun;
    private CustomerContact hpCustomerContact;
    private String hpExtractFilename;
    @SuppressWarnings("unused")
    private FileHelper hpFileHelper;
    private Bool hpIsFieldDelimited;
    private Bool hpIsFirstHeaderDelimited;
    @SuppressWarnings("unused")
    private Algorithm hpLetterExtractAlgorithm;
    private LetterTemplate hpLetterTemplate;
    @SuppressWarnings("unused")
    private CustomerContact hpToCustomerContact;

    /* *****************
     * Soft Parameters *
     * *****************/
    private CharacteristicType parmCharTypeAcctID, parmCharTypePrefMethodOfContact, parmCharTypeMailToMultiple, parmCharTypePremID;
    private String parmCharValMethodOfEmail, parmCharValMethodOfContact, parmCharValMailToMultiple;
    private ToDoType parmTdType;
    private Role parmRole;
    // Start Add - RDizon - CCB034.Issue2 - 06-11-2021
    private String parmCisDivisionsWithoutLPC;
    // End Add - RDizon - CCB034.Issue2 - 06-11-2021
    // Start Add - E-06060 - DLampa - 10-24-2022
    private String parmCisDivisionsForFormat;
    // End Add - E-06060 - DLampa - 10-24-2022
    // Start Add - E-08254 - IReyes - 02-06-2024
    private String parmCcTypeForLetterDelay;
    // End Add - E-08254 - IReyes - 02-06-2024

    /* ****************
     * Work Variables *
     * ****************/
    private ToDoTypeRole_Id wTDTypeRoleID;
    private String wAlgoCode;
    private File wExtractFile;
    private BufferedWriter wBufferedWriter;
    private StringBuilder wDelimitedHeader;
    private Bool wHasMailingAddress;
    private String wCcId, wAcctId, wEmail, wPrefMethodOfContact,
        wLetterTemplate, wPerson;
    private DateTime wContactDttm;
    private CustomerContactType wCustomerContactType;
    private Date wProcessDate;
    // Start Add - RDizon - CCB034.Issue2 - 06-11-2021
    private ArrayList<CisDivision> wCisDivisions = new ArrayList<CisDivision>();
    // End Add  - RDizon - CCB034.Issue2 - 06-11-2021
    // Start Add - E-06060 - DLampa - 10-24-2022
    private ArrayList<CisDivision> wCisDivisionsForFormat = new ArrayList<CisDivision>();
    // End Add - E-06060 - DLampa - 10-24-2022

    /* Mailing Address Information */
    private String wCountry, wAddress1, wAddress2, wAddress3, wAddress4,
        wCity, wNum1, wNum2, wHouseType, wCounty, wState,
        wPostal, wGeoCode, wInCityLimit, wEntityName1,
        wEntityName2, wEntityName3;

    /* Billing Information */
    private SQLResultRow wBillInfo;

    /* Payment Event Information */
    private Iterator<SQLResultRow> wPayEvtColl;

    /* Pay Plan Information */
    private Iterator<SQLResultRow> wPayPlanColl;

    /* Adjustment Information */
    private SQLResultRow wAdjInfo;

    /* Field Activity Information */
    private SQLResultRow wFaInfo;

    /* Premise Information */
    private SQLResultRow wPremInfo;

    /* Characteristic Information */
    private Iterator<SQLResultRow> wCharColl;

    @Override
    public BigInteger getCustomerContactExtractedCount() {
        return hpCcExtractedCount;
    }

    @Override
    public ReportDefinition getReportDefinition() {
        // TODO Auto-generated method stub
        return hpReportDefinition;
    }

    @Override
    public void setBatchRun(BatchRun arg0) {
        hpBatchRun = arg0;
    }

    @Override
    public void setCustomerContact(CustomerContact arg0) {
        hpCustomerContact = arg0;
        wCcId = hpCustomerContact.getId().getTrimmedValue();
        wPerson = hpCustomerContact.getPersonId().getTrimmedValue();
        wCustomerContactType = hpCustomerContact.getCustomerContactType();
        wContactDttm = hpCustomerContact.getContactDateTime();
    }

    @Override
    public void setCustomerContactExtractedCount(BigInteger arg0) {
        hpCcExtractedCount = arg0;
    }

    @Override
    public void setExtractFileName(String arg0) {
        hpExtractFilename = arg0;
    }

    @Override
    public void setFileHelper(FileHelper arg0) {
        hpFileHelper = arg0;
    }

    @Override
    public void setIsFieldDelimited(Bool arg0) {
        hpIsFieldDelimited = arg0;
    }

    @Override
    public void setIsFirstHeaderDelimited(Bool arg0) {
        hpIsFirstHeaderDelimited = arg0;
    }

    @Override
    public void setLetterExtractAlgorithm(Algorithm arg0) {
        hpLetterExtractAlgorithm = arg0;
    }

    @Override
    public void setLetterTemplate(LetterTemplate arg0) {
        hpLetterTemplate = arg0;
        wLetterTemplate = hpLetterTemplate.getId().getTrimmedValue();
    }

    @Override
    public void setToCustomerContact(CustomerContact arg0) {
        hpToCustomerContact = arg0;
    }

    /* **********************************
     * Retrieve and Validate Parameters *
     * **********************************/
    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

        wAlgoCode = this.getAlgorithmId().getTrimmedValue();
        wProcessDate = this.getProcessDateTime().getDate();
        wDelimitedHeader = new StringBuilder();

        // Parameter 10
        parmCharTypeAcctID = this.getAccountIDCharType();
        validateCharTypeForEntity(parmCharTypeAcctID, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT, "Account ID Characteristic Type");
        // Parameter 20
        parmCharTypePrefMethodOfContact = this.getPrefMethodOfContactCharType();
        validateCharTypeForEntity(parmCharTypePrefMethodOfContact, CharacteristicEntityLookup.constants.PERSON, "Preferred Method of Contact Characteristic Type");
        // Parameter 30
        parmCharValMethodOfEmail = this.getPrefMethodOfEmailCharVal();
        validateCharValForCharType(parmCharTypePrefMethodOfContact, parmCharValMethodOfEmail, "Preferred Method of E-mail Characteristic Type");
        // Parameter 40
        parmCharValMethodOfContact = this.getPrefMethodOfContactCharVal();
        validateCharValForCharType(parmCharTypePrefMethodOfContact, parmCharValMethodOfContact, "Preferred Method of Contact Characteristic Value");
        // Parameter 50
        parmCharTypeMailToMultiple = this.getMailToMultipleCharType();
        validateCharTypeForEntity(parmCharTypeMailToMultiple, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT, "Mail to Multiple Address Characteristic Type");
        // Parameter 60
        parmCharValMailToMultiple = this.getMailToMultipleCharVal();
        validateCharValForCharType(parmCharTypeMailToMultiple, parmCharValMailToMultiple, "");
        // Parameter 70
        parmCharTypePremID = this.getPremiseIDCharType();
        validateCharTypeForEntity(parmCharTypePremID, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT, "Premise ID Characteistic Type");
        // Parameter 80
        parmTdType = this.getToDoType();
        // Parameter 90
        parmRole = this.getToDoRole();

        if (isNull(parmRole)) {
            parmRole = parmTdType.getDefaultRole().fetchIdToDoRole();
        }
        wTDTypeRoleID = new ToDoTypeRole_Id(parmTdType, parmRole);

        // Start Add - RDizon - CCB034.Issue2 - 06-11-2021
        // Parameter 100
        parmCisDivisionsWithoutLPC = getCisDivisionsWithoutLPC();
        String[] cisDivisions = parmCisDivisionsWithoutLPC.split(",");

        for (int i=0; i < cisDivisions.length; i++){
            String cisDivStr = cisDivisions[i];
            CisDivision cisDivision = new CisDivision_Id(cisDivStr.trim()).getEntity();
            if (isNull(cisDivision)){
                addError(CustomMessageRepositoryMGE.CCB034_AlgParmContainsInvalidCisDivision(
                        getAlgorithm().getAlgorithmType().getParameterAt(9).fetchLanguageParameterLabel(),
                        cisDivStr));
            }
            wCisDivisions.add(cisDivision);
        }
        // End Add - RDizon - CCB034.Issue2 - 06-11-2021

        // Start Add - E-06060 - DLampa - 10-24-2022
        // Parameter 110
        parmCisDivisionsForFormat = getCisDivisionForFormat();
        cisDivisions = parmCisDivisionsForFormat.split(",");

        for (int i=0; i < cisDivisions.length; i++){
            String cisDivStr = cisDivisions[i];
            CisDivision cisDivision = new CisDivision_Id(cisDivStr.trim()).getEntity();
            if (isNull(cisDivision)){
                addError(CustomMessageRepositoryMGE.CCB034_AlgParmContainsInvalidCisDivision(
                        getAlgorithm().getAlgorithmType().getParameterAt(13).fetchLanguageParameterLabel(),
                        cisDivStr));
            }
            wCisDivisionsForFormat.add(cisDivision);
        }
        // End Add - E-06060 - DLampa - 10-24-2022
        
        // Start Add - E-08254 - IReyes - 02-06-2024
        parmCcTypeForLetterDelay = getCcTypeForLetterDelay();
        // End Add - E-08254 - IReyes - 02-06-2024

    }

    // Start Add - E-06267.Issue1 - DLampa - 03-23-2023
    private void completeToDo() {

        // Retrieve open To Do entries linked to the Customer Contact
        StringBuilder queryStr = new StringBuilder("");

        queryStr.append("SELECT TD.TD_ENTRY_ID ");
        queryStr.append("FROM CI_TD_ENTRY TD, CI_TD_DRLKEY DRL ");
        queryStr.append("WHERE TD.ENTRY_STATUS_FLG <> :entryStatusComplete ");
        queryStr.append(  "AND TD.TD_TYPE_CD = :toDoType ");
        queryStr.append(  "AND TD.TD_ENTRY_ID = DRL.TD_ENTRY_ID ");
        queryStr.append(  "AND DRL.KEY_VALUE = :customerContact ");
        queryStr.append("ORDER BY TD.TD_ENTRY_ID ASC");

        PreparedStatement openToDoEntriesQuery = createPreparedStatement(queryStr.toString(), getClass().getName());

        openToDoEntriesQuery.bindLookup("entryStatusComplete", ToDoEntryStatusLookup.constants.COMPLETED);
        openToDoEntriesQuery.bindId("toDoType", wTDTypeRoleID.getToDoTypeId());
        openToDoEntriesQuery.bindEntity("customerContact", hpCustomerContact);

        QueryIterator<SQLResultRow> iterator = openToDoEntriesQuery.iterate();
        QueryResultRow row = null;
        while (iterator.hasNext()) {
            // If open to do entries are found, complete them
            row = iterator.next();
            ToDoEntry_Id tdEntryID = (ToDoEntry_Id) row.getId("TD_ENTRY_ID", ToDoEntry.class);
            tdEntryID.getEntity().complete();
        }
        iterator.close();
        openToDoEntriesQuery.close();

    }
    // End Add - E-06267.Issue1 - DLampa - 03-23-2023

    private void initializeMailingAddressInfo() {
        wCountry = " ";
        wAddress1 = " ";
        wAddress2 = " ";
        wAddress3 = " ";
        wAddress4 = " ";
        wCity = " ";
        wNum1 = " ";
        wNum2 = " ";
        wHouseType = " ";
        wCounty = " ";
        wState = " ";
        wPostal = " ";
        wGeoCode = " ";
        wInCityLimit = " ";
        wEntityName1 = " ";
        wEntityName2 = " ";
        wEntityName3 = " ";
    }

    private void initBillingInfo() {
        wBillInfo = null;
    }

    private void initPayEventInfo() {
        wPayEvtColl = new ArrayList<SQLResultRow>().iterator();
    }

    private void initPayPlanInfo() {
        wPayPlanColl = new ArrayList<SQLResultRow>().iterator();
    }

    private void initAdjInfo() {
        wAdjInfo = null;
    }

    private void initFaInfo() {
        wFaInfo = null;
    }

    private void initPremInfo() {
        wPremInfo = null;
    }

    private void initCharInfo() {
        wCharColl = new ArrayList<SQLResultRow>().iterator();
    }

    private void validateCharTypeForEntity(CharacteristicType charType, CharacteristicEntityLookup entityLookup, String parameterDescr) {
        CharacteristicEntity_Id charEntityID = new CharacteristicEntity_Id(charType, entityLookup);
        if (isNull(charEntityID.getEntity())) {
            // Algorithm %1's parameter '%2%3' value (%4) is not a valid char type for %5%6 entity
            addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharTypeNotValidForEntity(wAlgoCode,
                    parameterDescr,
                    charType.getId().getTrimmedValue(),
                    entityLookup.trimmedValue()));
        }
    }

    private void validateCharValForCharType(CharacteristicType charType, String charVal, String parameterDescr) {
        CharacteristicTypeLookup charValueType = charType.getCharacteristicType();
        if (notBlank(charVal)
                && charValueType.isPredefinedValue()) {
            CharacteristicValue_Id charValueID = new CharacteristicValue_Id(charType, charVal);
            if (isNull(charValueID.getEntity())) {
                // Algorithm %1's parameter '%2%3' value (%4) is not a valid char value for %5 char type.
                addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharValueNotValidForCharType(wAlgoCode,
                        parameterDescr,
                        charVal,
                        charType.getId().getTrimmedValue()));
            }
        }
    }

    /* *************
     * Main Method *
     * *************/
    @Override
    public void invoke() {
        openFile();

        // Start Add - E-06267.Issue1 - DLampa - 03-23-2023
        // Complete To Dos linked to the customer contact
        completeToDo();
        // End Add - E-06267.Issue1 - DLampa - 03-23-2023

        initializeMailingAddressInfo();
        initBillingInfo();
        initPayEventInfo();
        initPayPlanInfo();
        initAdjInfo();
        initFaInfo();
        initPremInfo();
        initCharInfo();

        if (hpIsFieldDelimited.isTrue()
                && hpIsFirstHeaderDelimited.isTrue()) {
            compressGenericHeadings();
            compressDetailHeadings();
            writetoFile(wDelimitedHeader.toString());
        }
        
        prepareLetterForExtract();

        closeFile();
    }

    private void openFile() {
        try {
            wExtractFile = new File(hpExtractFilename.trim());
            wBufferedWriter = new BufferedWriter(new FileWriter(wExtractFile, true));
        }
        catch (Exception e) {
            addError(CustomMessageRepositoryMGE.commGenericErrorOpeningFile(hpExtractFilename.trim()));
        }
    }

    private void writetoFile(String recordline) {
        try {
            wBufferedWriter.write(recordline);
            wBufferedWriter.newLine();
        }
        catch (Exception e) {
            addError(CustomMessageRepositoryMGE.commGenericErrorWritingToFile(hpExtractFilename.trim()));
        }
    }

    private void closeFile() {
        try {
            wBufferedWriter.close();
        }
        catch (Exception e) {
            addError(CustomMessageRepositoryMGE.commGenericErrorClosingFile(hpExtractFilename.trim()));
        }
    }

    private void compressGenericHeadings() {

        wDelimitedHeader.append(CustomConstantsRepository.GH_POSTAL);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_NAME1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_NAME2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_NAME3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_COUNTRY);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_ADDR1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_ADDR2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_ADDR3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_ADDR4);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_CITY);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_NUM1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_NUM2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_HOUSE_TYPE);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_COUNTY);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_STATE);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_GEO_CD);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_IN_CITY_LMT);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_CC_ID);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_PER_ID);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_CC_DT);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_CC_TM);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_CC_CL);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_CC_TY);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_LTR_TMPL);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.GH_SYS_DT);
    }

    private void compressDetailHeadings() {

        wDelimitedHeader.append(CustomConstantsRepository.BLANKS);
        wDelimitedHeader.append(CustomConstantsRepository.DH_BILL_CHAR_TYPE);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_BILL_CHAR_TYPE_DESC);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_BILL_ID);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ACCT_ID);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_APAY_AMT);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_BILL_DT);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_BILL_DUE_DT);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_LPC_DT);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_BILL_AMT);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_EVT_CHAR_TYPE);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_EVT_CHAR_TYPE_DESC);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_EVT_ID);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_DT);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_ID1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ACCT_ID1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_AMT1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CANC_RSN1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CANC_RSN_DESC1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_ID2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ACCT_ID2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_AMT2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CANC_RSN2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CANC_RSN_DESC2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_ID3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ACCT_ID3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_AMT3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CANC_RSN3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CANC_RSN_DESC3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_ID4);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ACCT_ID4);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_AMT4);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CANC_RSN4);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CANC_RSN_DESC4);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_ID5);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ACCT_ID5);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_AMT5);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CANC_RSN5);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CANC_RSN_DESC5);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_CHAR_TYPE);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_CHAR_TYPE_DESC);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_ID);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_ACCT_ID);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_TYPE);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_TYPE_DESC);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_START_DT);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_STAT);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_DT1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_AMT1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_DT2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_AMT2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_DT3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_AMT3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_DT4);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_AMT4);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_DT5);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_AMT5);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_DT6);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_AMT6);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_DT7);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_AMT7);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_DT8);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_AMT8);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_DT9);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_AMT8_2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PAN_SCHED_DT9_2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_AMT9);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_DT10);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_AMT10);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_DT11);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_AMT11);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_DT12);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PAY_PLAN_SCHED_AMT12);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ADJ_CHAR_TYPE);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ADJ_CHAR_TYPE_DESC);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ADJ_ID);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ADJ_ACCT_ID);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ADJ_TYPE);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ADJ_TYPE_DESC);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ADJ_AMT);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_FA_CHAR_TYPE);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_FA_CHAR_TYPE_DESC);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_FA_SCHD_DTTM);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_FA_STAT);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_FA_CANC_RSN);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_FA_CANC_RSN_DESC);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_FA_RESC_RSN);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_FA_RESC_RSN_DESC);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PREM_CHAR_TYPE);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PREM_CHAR_TYPE_DESC);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_PREM_ID);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_COUNTY);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ADD1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ADD2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ADD3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_ADD4);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CITY);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_NUM1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_NUM2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_HOUSE_TYPE);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_COUNTY);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_STATE);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_POSTAL);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_GEO_CD);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_IN_CITY_LIMIT);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_MAIL_MULTI);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_DESC1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL_DESC1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_ADHOC_VAL1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_DESC2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL_DESC2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_ADHOC_VAL2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_DESC3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL_DESC3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_ADHOC_VAL3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE4);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_DESC4);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL4);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL_DESC4);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_ADHOC_VAL4);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE5);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_DESC5);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL5);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL_DESC5);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_ADHOC_VAL5);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE6);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_DESC6);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL6);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL_DESC6);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_ADHOC_VAL6);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE7);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_DESC7);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL7);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL_DESC7);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_ADHOC_VAL7);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE8);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_DESC8);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL8);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL_DESC8);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_ADHOC_VAL8);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE9);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_DESC9);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL9);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL_DESC9);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_ADHOC_VAL9);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE10);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_DESC10);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL10);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL_DESC10);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_ADHOC_VAL10);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE11);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_DESC11);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL11);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL_DESC11);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_ADHOC_VAL11);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE12);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_DESC12);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL12);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL_DESC12);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_ADHOC_VAL12);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE13);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_DESC13);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL13);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL_DESC13);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_ADHOC_VAL13);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE14);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_DESC14);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL14);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL_DESC14);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_ADHOC_VAL14);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE15);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_DESC15);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL15);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_VAL_DESC15);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CustomConstantsRepository.DH_CHAR_TYPE_ADHOC_VAL15);
    }

    private void prepareLetterForExtract() {

        Person person = hpCustomerContact.getPerson();
        // Get Mailing Address Information
        getMailingAddressInfo(person);
        // Proceed processing only if a mailing address is successfully retrieved
        if (wHasMailingAddress.isTrue()) {
            // Extract Additional Fields
            extractAdditionalFields(person);
            
            // Start Add - E-08254 - IReyes - 02-06-2024
            //Extract the High Bill Reviewed (CMHBLINQ) letter 2 business days after it was created
            if(wCustomerContactType.getId().getContactType().trim().equalsIgnoreCase(parmCcTypeForLetterDelay.trim())){
            	//Add 2 business days to the customer contact date        
                Account_Id accountId = new Account_Id(wAcctId);
            	WorkCalendar workCalendar = accountId.getEntity().fetchDivision().getWorkCalendar();
            	Date delayedLetterDate = workCalendar.addBusinessDays(wContactDttm.getDate(), 2);
            	
            	if(!wProcessDate.equals(delayedLetterDate)){
        	        CustomerContact_DTO ccDto = hpCustomerContact.getDTO();
        	        ccDto.setLetterPrintDateTime(null);
        	        ccDto.setBatchNumber(hpCustomerContact.getBatchNumber().add(BigInteger.ONE));
        	        hpCustomerContact.setDTO(ccDto);    
        	        // Start Delete - E-09710.Issue1 - DLampa - 12-13-2024
        	        //hpCcExtractedCount = BigInteger.ONE;
        	        // End Delete - E-09710.Issue1 - DLampa - 12-13-2024
            		return;
            	}
            }
    	    // End Add - E-08254 - IReyes - 02-06-2024 

            if (hpIsFieldDelimited.isTrue()){

                wDelimitedHeader = new StringBuilder();
                compressMailInfo();
                compressCCInfo();
                compressDetailRec();
                writetoFile(wDelimitedHeader.toString());
            }
            else {

                writeLetterRec();
                writeMailingInfoRec();
                writeAcctPerRec();
                writeDetailRec();
                writeEndLetterRec();
            }
            
            // add 1 to extracted customer contact count
            hpCcExtractedCount = hpCcExtractedCount.add(BigInteger.ONE);
            
        }
    }

    private void getMailingAddressInfo(Person person) {

        wHasMailingAddress = Bool.FALSE;

        /// Get Active SA of person and use the account on the active SA.
        Account_Id acctID = getLatestActiveSaOfPerson(person);
        if (notNull(acctID)
                && notNull(acctID.getEntity())) {

            Account account = acctID.getEntity();
            AccountMailingAddressData mailingData = person.fetchMailingAddress(account);

            if (notNull(mailingData)
                    && notBlank(mailingData.getAddress1())) {

                wHasMailingAddress = Bool.TRUE;
                wCountry = mailingData.getCountry().getId().getTrimmedValue();
                wAddress1 = mailingData.getAddress1();
                wAddress2 = mailingData.getAddress2();
                wAddress3 = mailingData.getAddress3();
                wAddress4 = mailingData.getAddress4();
                wCity = mailingData.getCity();
                wNum1 = mailingData.getNum1();
                wNum2 = mailingData.getNum2();
                wHouseType = mailingData.getHouseType().trimmedValue();
                wCounty = mailingData.getCounty();
                wState = mailingData.getState().fetchIdState();
                wPostal = mailingData.getPostalCode();
                wGeoCode = mailingData.getGeographicCode();
                if (mailingData.getIsInCityLimit().isTrue()) {
                    wInCityLimit = "Y";
                }
                else {
                    wInCityLimit = "N";
                }
                wEntityName1 = mailingData.getEntityName1();
                wEntityName2 = mailingData.getEntityName2();
                wEntityName3 = mailingData.getEntityName3();
            }
        }
        // If there are no active SA for the person, get the mailing address out of the CC Premise Characteristic (NOT the CC Premise)
        else {
            String premChar = retrieveCCChar(hpCustomerContact, parmCharTypePremID);
            Premise_Id premID = new Premise_Id(premChar);

            if (notBlank(premChar)
                    && notNull(premID.getEntity())) {

                wHasMailingAddress = Bool.TRUE;
                Premise mailingAddress = premID.getEntity();
                wCountry = mailingAddress.getCountryId().getTrimmedValue();
                wAddress1 = mailingAddress.getAddress1();
                wAddress2 = mailingAddress.getAddress2();
                wAddress3 = mailingAddress.getAddress3();
                wAddress4 = mailingAddress.getAddress4();
                wCity = mailingAddress.getCity();
                wNum1 = mailingAddress.getStreetNumber1();
                wNum2 = mailingAddress.getStreetNumber2();
                wHouseType = mailingAddress.getHouseType().trimmedValue();
                wCounty = mailingAddress.getCounty();
                wState = mailingAddress.getState();
                wPostal = mailingAddress.getPostal();
                wGeoCode = mailingAddress.getTaxVendorGeographicalCode();
                if (mailingAddress.getIsInCityLimit().isTrue()) {
                    wInCityLimit = "Y";
                }
                else {
                    wInCityLimit = "N";
                }
            }
            else {
                // When no premise characteristic exists for the customer contact get any account linked to the person as it's main customer.
                acctID = getAccountLinkedToPerson(person);
                if (notNull(acctID)
                        && notNull(acctID.getEntity())) {

                    Account account = acctID.getEntity();
                    AccountMailingAddressData mailingData = person.fetchMailingAddress(account);

                    if (notNull(mailingData)
                            && notBlank(mailingData.getAddress1())) {

                        wHasMailingAddress = Bool.TRUE;
                        wCountry = mailingData.getCountry().getId().getTrimmedValue();
                        wAddress1 = mailingData.getAddress1();
                        wAddress2 = mailingData.getAddress2();
                        wAddress3 = mailingData.getAddress3();
                        wAddress4 = mailingData.getAddress4();
                        wCity = mailingData.getCity();
                        wNum1 = mailingData.getNum1();
                        wNum2 = mailingData.getNum2();
                        wHouseType = mailingData.getHouseType().trimmedValue();
                        wCounty = mailingData.getCounty();
                        wState = mailingData.getState().fetchIdState();
                        wPostal = mailingData.getPostalCode();
                        wGeoCode = mailingData.getGeographicCode();
                        if (mailingData.getIsInCityLimit().isTrue()) {
                            wInCityLimit = "Y";
                        }
                        else {
                            wInCityLimit = "N";
                        }
                        wEntityName1 = mailingData.getEntityName1();
                        wEntityName2 = mailingData.getEntityName2();
                        wEntityName3 = mailingData.getEntityName3();
                    }
                }
            }
        }

        if (isBlankOrNull(wEntityName1)) {
            wEntityName1 = hpCustomerContact.getPerson().getPersonPrimaryName().trim();
        }

        if (wHasMailingAddress.isFalse()) {

            // Create To Do if there are no available mailing address for this customer
            // create collection of sort keys
            List<String> collSortKeyValues = new ArrayList<String>();
            collSortKeyValues.add(wCcId);

            // create collection of drill keys
            List<String> collDrillKeyValues = new ArrayList<String>();
            collDrillKeyValues.add(wCcId);

            // Create a To Do Entry
            // Start Change - E-06267.Issue1 - DLampa - 03-23-2023
            //createToDo(collSortKeyValues, collDrillKeyValues);
            createToDo(collSortKeyValues, collDrillKeyValues, Bool.TRUE);
            // End Change - E-06267.Issue1 - DLampa - 03-23-2023
            // MESSAGE: A valid address was not found for letter printing of customer contact %1.
            addError(CustomMessageRepositoryMGE.sa322461_noMailingAddress(wCcId));
        }
    }

    private Account_Id getAccountLinkedToPerson(Person person) {

        Account_Id returnValue = null;

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ACCT.ACCT_ID ");
        stringBuilder.append("FROM CI_ACCT_PER APER, CI_ACCT ACCT ");
        stringBuilder.append("WHERE APER.PER_ID = :perID ");
        stringBuilder.append("AND APER.MAIN_CUST_SW = 'Y' ");
        stringBuilder.append("AND ACCT.ACCT_ID = APER.ACCT_ID ");
        stringBuilder.append("ORDER BY ACCT.SETUP_DT DESC ");

        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==getAccountLinkedToPerson==");
        prepState.bindId("perID", person.getId());
        prepState.setAutoclose(false);
        prepState.execute();
        if (notNull(prepState.firstRow())) {
            SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
            returnValue = (Account_Id) sqlRow.getId("ACCT_ID", Account.class);
        }
        prepState.close();

        return returnValue;
    }

    // Start Change - E-06267.Issue1 - DLampa - 03-23-2023
    //private void createToDo(List<String> collSortKeyValues, List<String> collDrillKeyValues) {

        //Message_Id msgID = CustomMessageRepositoryMGE.sa322461_noMailingAddress(wCcId).getMessageId();
    private void createToDo(List<String> collSortKeyValues, List<String> collDrillKeyValues, Bool createForMailingAddress) {

        Message_Id msgID = null;

        if (createForMailingAddress.isTrue()) {
            msgID = CustomMessageRepositoryMGE.sa322461_noMailingAddress(wCcId).getMessageId();
        } else {
            msgID = CustomMessageRepositoryMGE.E06267_noCisDivision(wCcId).getMessageId();
        }
    // End Change - E-06267.Issue1 - DLampa - 03-23-2023


        ToDoCreator tdCreator = ToDoCreator.Factory.newInstance();
        ToDoEntry_DTO tdEntryDTO = tdCreator.getToDoDTO();
        tdEntryDTO.setCreationDateTime(this.getProcessDateTime());
        tdEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
        tdEntryDTO.setToDoTypeId(wTDTypeRoleID.getToDoTypeId());
        tdEntryDTO.setToDoRoleId(wTDTypeRoleID.getToDoRoleId());
        tdEntryDTO.setMessageId(msgID);
        tdCreator.setToDoDTO(tdEntryDTO);
        //---------set message parameter---------//
        tdCreator.addMessageParameter(wCcId);

        List<ToDoSortKeyType> collOfSortKeyTypes = getSortKeyTypes(wTDTypeRoleID.getToDoTypeId());

        for (int x = 0; x < collOfSortKeyTypes.size(); x++) {

            ToDoSortKeyType tdSortKeyType = collOfSortKeyTypes.get(x);
            tdCreator.addSortKeyValue(tdSortKeyType, collSortKeyValues.get(x));
        }

        List<ToDoDrillKeyType> collOfDrillKeyTypes = getDrillKeyTypes(wTDTypeRoleID.getToDoTypeId());

        for (int x = 0; x < collOfDrillKeyTypes.size(); x++) {

            ToDoDrillKeyType tdDrillKeyType = collOfDrillKeyTypes.get(x);
            tdCreator.addDrillKeyValue(tdDrillKeyType, collDrillKeyValues.get(x));
        }

        @SuppressWarnings("unused")
        ToDoEntry tdEntry = tdCreator.create();
    }

    private List<ToDoSortKeyType> getSortKeyTypes(ToDoType_Id tdTypeID) {

        List<ToDoSortKeyType> returnValue = new ArrayList<ToDoSortKeyType>();

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT TD_TYPE_CD, SEQ_NUM ");
        stringBuilder.append("FROM CI_TD_SRTKEY_TY ");
        stringBuilder.append("WHERE TD_TYPE_CD = :tdTypeID ");

        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=GET TO DO TYPE SORT KEYS");
        prepState.bindId("tdTypeID", tdTypeID);
        prepState.setAutoclose(false);
        prepState.execute();

        if (prepState.list().size() > 0) {

            Iterator<SQLResultRow> iter = prepState.list().iterator();

            while (iter.hasNext()) {

                SQLResultRow sqlRow = (SQLResultRow) iter.next();
                BigInteger seq = (BigInteger) sqlRow.getInteger("SEQ_NUM");
                ToDoSortKeyType_Id tdSortKeyTypeID = new ToDoSortKeyType_Id(tdTypeID, seq);
                returnValue.add(tdSortKeyTypeID.getEntity());
            }
        }
        prepState.close();
        return returnValue;
    }

    private List<ToDoDrillKeyType> getDrillKeyTypes(ToDoType_Id tdTypeID) {

        List<ToDoDrillKeyType> returnValue = new ArrayList<ToDoDrillKeyType>();

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT TD_TYPE_CD, SEQ_NUM ");
        stringBuilder.append("FROM CI_TD_DRLKEY_TY ");
        stringBuilder.append("WHERE TD_TYPE_CD = :tdTypeID ");

        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=GET TO DO TYPE DRILL KEYS=");
        prepState.bindId("tdTypeID", tdTypeID);
        prepState.setAutoclose(false);
        prepState.execute();

        if (prepState.list().size() > 0) {

            Iterator<SQLResultRow> iter = prepState.list().iterator();

            while (iter.hasNext()) {

                SQLResultRow sqlRow = (SQLResultRow) iter.next();
                BigInteger seq = (BigInteger) sqlRow.getInteger("SEQ_NUM");
                ToDoDrillKeyType_Id tdDrillKeyTypeID = new ToDoDrillKeyType_Id(tdTypeID, seq);
                returnValue.add(tdDrillKeyTypeID.getEntity());
            }
        }
        prepState.close();
        return returnValue;
    }

    private Account_Id getLatestActiveSaOfPerson(Person person) {

        Account_Id returnValue = null;

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT SA.ACCT_ID ");
        stringBuilder.append("FROM CI_ACCT_PER APER, CI_SA SA ");
        stringBuilder.append("WHERE APER.PER_ID = :perID ");
        stringBuilder.append("AND APER.MAIN_CUST_SW = 'Y' ");
        stringBuilder.append("AND APER.ACCT_ID = SA.ACCT_ID ");
        stringBuilder.append("AND SA.SA_STATUS_FLG = :active ");
        stringBuilder.append("ORDER BY SA.START_DT DESC ");

        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getLatestActiveSaOfPerson=");
        prepState.bindId("perID", person.getId());
        prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
        prepState.setAutoclose(false);
        prepState.execute();
        if (notNull(prepState.firstRow())) {
            SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
            returnValue = (Account_Id) sqlRow.getId("ACCT_ID", Account.class);
        }
        return returnValue;
    }

    private String retrieveCCChar(CustomerContact cc, CharacteristicType charType) {

        String returnValue = "";
        CharacteristicTypeLookup charValType = charType.getCharacteristicType();
        CustomerContactCharacteristic ccChar = cc.getEffectiveCharacteristic(charType);

        if (notNull(ccChar)) {
            if (charValType.isAdhocValue()
                    || charValType.isFileLocationValue()) {
                returnValue = ccChar.getAdhocCharacteristicValue().trim();
            }
            else if (charValType.isPredefinedValue()) {
                returnValue = ccChar.getCharacteristicValue().trim();
            }
            else {
                returnValue = ccChar.getCharacteristicValueForeignKey1().trim();
            }
        }

        return returnValue;
    }

    private Iterator<SQLResultRow> retrieveCustomerContactFKChar(String tableName) {

        Iterator<SQLResultRow> returnValue = new ArrayList<SQLResultRow>().iterator();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append("  CH.CHAR_TYPE_CD, ");
        stringBuilder.append("  CH.CHAR_VAL_FK1 ");
        stringBuilder.append("FROM CI_CC_CHAR CH, ");
        stringBuilder.append("  CI_CHAR_TYPE CT, ");
        stringBuilder.append("  CI_FK_REF FK ");
        stringBuilder.append("WHERE ");
        stringBuilder.append("  CH.CC_ID = :ccID ");
        stringBuilder.append("  AND CT.CHAR_TYPE_CD = CH.CHAR_TYPE_CD ");
        stringBuilder.append("  AND CT.CHAR_TYPE_FLG = 'FKV' ");
        stringBuilder.append("  AND FK.FK_REF_CD = CT.FK_REF_CD ");
        stringBuilder.append("  AND FK.TBL_NAME = '"+tableName+"' ");

        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=retrieve FK Chars=");
        prepState.bindId("ccID", hpCustomerContact.getId());
        prepState.setAutoclose(false);
        prepState.execute();
        if (prepState.list().size() > 0) {
            returnValue = prepState.list().iterator();
        }
        prepState.close();
        return returnValue;
    }

    private String retrievePersonChar(Person person, CharacteristicType charType) {

        String returnValue = "";
        CharacteristicTypeLookup charValType = charType.getCharacteristicType();
        PersonCharacteristic perChar = person.getEffectiveCharacteristic(charType);

        if (notNull(perChar)) {
            if (charValType.isAdhocValue()
                    || charValType.isFileLocationValue()) {
                returnValue = perChar.getAdhocCharacteristicValue().trim();
            }
            else if (charValType.isPredefinedValue()) {
                returnValue = perChar.getCharacteristicValue().trim();
            }
            else {
                returnValue = perChar.getCharacteristicValueForeignKey1().trim();
            }
        }

        return returnValue;
    }

    private void extractAdditionalFields(Person person) {

        // Retrieve account customer contact characteristic
        String acctChar = retrieveCCChar(hpCustomerContact, parmCharTypeAcctID);
        if (notBlank(acctChar)) {
            wAcctId = acctChar;
        }
        else {

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ACCT.ACCT_ID ");
            stringBuilder.append("FROM CI_ACCT_PER APER, CI_ACCT ACCT ");
            stringBuilder.append("WHERE APER.PER_ID = :perID ");
            stringBuilder.append("AND APER.MAIN_CUST_SW = 'Y' ");
            stringBuilder.append("AND ACCT.ACCT_ID = APER.ACCT_ID ");
            // Start Add - E-09710 - DLampa - 10-25-2024
            stringBuilder.append("AND ACCT.CIS_DIVISION <> ' ' ");
            // End Add - E-09710 - DLampa - 10-25-2024
            stringBuilder.append("ORDER BY ACCT.SETUP_DT DESC ");

            PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=Get Main Account Of Person=");
            prepState.setAutoclose(false);
            prepState.bindId("perID", person.getId());
            prepState.execute();
            if (notNull(prepState.firstRow())) {
                SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
                wAcctId = (String) sqlRow.getString("ACCT_ID");
            }
            prepState.close();            
        }

        // Retrieve preferred method of contact person characteristic
        wPrefMethodOfContact = retrievePersonChar(person, parmCharTypePrefMethodOfContact);

        if (notBlank(wPrefMethodOfContact)
                && wPrefMethodOfContact.trim().compareTo(parmCharValMethodOfEmail.trim()) == 0
                ) {
            // Retrieve email.
            wEmail = person.getEmailAddress();
        }
        else {
            wPrefMethodOfContact = parmCharValMethodOfContact;
        }
    }

    private void compressMailInfo() {

        wDelimitedHeader.append(wPostal.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wEntityName1.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wEntityName2.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wEntityName3.trim());
        wDelimitedHeader.append(wCountry.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wAddress1.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wAddress2.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wAddress3.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wAddress4.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wCity.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wNum1.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wNum2.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wHouseType.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wCounty.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wState.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wPostal.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wGeoCode.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wInCityLimit.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
    }

    private void compressCCInfo() {

        wDelimitedHeader.append(wCcId.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(hpCustomerContact.getPersonId().getTrimmedValue());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(hpCustomerContact.getContactDateTime().getDate().toString().trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(hpCustomerContact.getContactDateTime().getTime().toString().trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(hpCustomerContact.getCustomerContactType().fetchIdContactClass().getId().getTrimmedValue());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(hpCustomerContact.getCustomerContactType().fetchIdContactType().trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(hpLetterTemplate.getId().getTrimmedValue());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(wProcessDate.toString().trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
    }

    private void compressDetailRec() {

        compressBillInfo();
        compressPayEvtInfo();
        compressPayPlanInfo();
        compressAdjInfo();
        compressFaInfo();
        compressPremInfo();
        compressCharInfo();
        writetoFile(wDelimitedHeader.toString());
    }


    private Payment getPayment(PaymentEvent_Id payEvtID) {

        Payment returnValue = null;
        StringBuilder stringBuilder = new StringBuilder();
        // These are based on the SQL from CMPXCXCCX
        stringBuilder.append("SELECT ");
        stringBuilder.append("  PE.PAY_EVENT_ID, ");
        stringBuilder.append("  PE.PAY_DT, ");
        stringBuilder.append("  PY.PAY_ID, ");
        stringBuilder.append("  PY.PAY_AMT, ");
        stringBuilder.append("  PY.CAN_RSN_CD, ");
        stringBuilder.append("  PY.ACCT_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append("  CI_PAY_EVENT PE, ");
        stringBuilder.append("  CI_PAY PY ");
        stringBuilder.append("WHERE ");
        stringBuilder.append("  PE.PAY_EVENT_ID = :payEvtID ");
        stringBuilder.append("  AND PE.PAY_EVENT_ID = PY.PAY_EVENT_ID ");

        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getPayment=");
        prepState.bindId("payEvtID", payEvtID);
        prepState.setAutoclose(false);
        prepState.execute();
        if (notNull(prepState.firstRow())) {
            SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
            Payment_Id payID = (Payment_Id) sqlRow.getId("PAY_ID", Payment.class);
            returnValue = payID.getEntity();
        }
        prepState.close();
        return returnValue;
    }

    private PaymentPlanScheduledPayment getPayPlanSchedPay(PaymentPlan_Id payPlanID) {

        PaymentPlanScheduledPayment returnValue = null;
        StringBuilder stringBuilder = new StringBuilder();
        // These are based on the SQL from CMPCXCCX
        stringBuilder.append("SELECT ");
        stringBuilder.append("  PPSCH.PP_SCHED_DT, ");
        stringBuilder.append("  PPSCH.PP_SCHED_AMT ");
        stringBuilder.append("FROM ");
        stringBuilder.append("  CI_PP_SCHED_PAY PPSCH ");
        stringBuilder.append("WHERE ");
        stringBuilder.append("  PPSCH.PP_ID = :payPlanID ");
        stringBuilder.append("ORDER BY PPSCH.PP_SCHED_DT ");

        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getPayPlanSchedPay=");
        prepState.bindId("payPlanID", payPlanID);
        prepState.setAutoclose(false);
        if (notNull(prepState.firstRow())) {
            SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
            Date payPlanSchedDate = sqlRow.getDate("PP_SCHED_DT");
            PaymentPlanScheduledPayment_Id ppSchedPayID = new PaymentPlanScheduledPayment_Id(payPlanID, payPlanSchedDate);
            returnValue = ppSchedPayID.getEntity();
        }
        prepState.close();
        return returnValue;
    }

    private BigDecimal getBillAmount(Bill_Id billID) {

        BigDecimal returnValue = BigDecimal.ZERO;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append("  SUM(BSA.CUR_AMT) BILL_AMT ");
        stringBuilder.append("FROM ");
        stringBuilder.append("  CI_BILL_SA BSA ");
        stringBuilder.append("WHERE ");
        stringBuilder.append("  BSA.BILL_ID = :billID ");

        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getBillAmount=");
        prepState.bindId("billID", billID);
        prepState.setAutoclose(false);
        prepState.execute();
        if (notNull(prepState.firstRow())) {
            SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
            returnValue = (BigDecimal) sqlRow.getBigDecimal("BILL_AMT");
        }
        prepState.close();

        return returnValue;
    }

    private void compressBillInfo() {

        String FK_CHAR_TYPE_CD = " ";
        String CHAR_TYPE_DESCR = " ";
        String BILL_ID = " ";
        String ACCT_ID = " ";
        BigDecimal APAY_AMT = BigDecimal.ZERO;
        String BILL_DT = " ";
        String DUE_DT = " ";
        String LATE_PAY_CHRG_DT = " ";
        BigDecimal BILL_AMT = BigDecimal.ZERO;

        if(notNull(wBillInfo)) {
            CharacteristicType_Id charTypeID = (CharacteristicType_Id) wBillInfo.getId("CHAR_TYPE_CD", CharacteristicType.class);
            CharacteristicType charType = charTypeID.getEntity();
            String billStr = wBillInfo.getString("CHAR_VAL_FK1");
            Bill_Id billID = new Bill_Id(billStr.trim());
            Bill bill = billID.getEntity();

            FK_CHAR_TYPE_CD = charTypeID.getTrimmedValue();
            CHAR_TYPE_DESCR = charType.fetchLanguageDescription().trim();
            BILL_ID = billStr.trim();
            ACCT_ID = bill.getAccount().getId().getTrimmedValue();
            APAY_AMT = bill.getAutopayAmount().getAmount();
            BILL_DT = bill.getBillDate().toString().trim();
            DUE_DT = bill.getDueDate().toString().trim();
            LATE_PAY_CHRG_DT = bill.getLatePaymentChargeDate().toString().trim();
            BILL_AMT = getBillAmount(billID);
        }

        wDelimitedHeader.append(FK_CHAR_TYPE_CD.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CHAR_TYPE_DESCR.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(BILL_ID.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(ACCT_ID.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(ColumnDelimitedRecord.formatAsS9999999999999V99(APAY_AMT));
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(BILL_DT.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(DUE_DT.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(LATE_PAY_CHRG_DT.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(ColumnDelimitedRecord.formatAsS9999999999999V99(BILL_AMT));
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
    }

    private void compressPayEvtInfo() {

        // Extract first 5 contents of the pay event info collection
        int counter = 0;

        while(counter < 5) {

            counter++;

            String FK_CHAR_TYPE_CD = " ";
            String CHAR_TYPE_DESCR = " ";
            String PAY_EVENT_ID = " ";
            String PAY_DT = " ";
            String PAYMENT_ID = " ";
            String ACCT_ID = " ";
            String PAY_AMT = " ";
            String CAN_RSN_CD = " ";
            String CAN_RSN_DESCR = " ";

            if (notNull(wPayEvtColl)
                    && wPayEvtColl.hasNext()) {

                SQLResultRow sqlRow = (SQLResultRow) wPayEvtColl.next();
                CharacteristicType_Id charTypeID = (CharacteristicType_Id) sqlRow.getId("CHAR_TYPE_CD", CharacteristicType.class);
                CharacteristicType charType = charTypeID.getEntity();
                String payEvtStr = sqlRow.getString("CHAR_VAL_FK1");
                PaymentEvent_Id payEventID = new PaymentEvent_Id(payEvtStr.trim());
                PaymentEvent payEvent = payEventID.getEntity();
                Payment payment = getPayment(payEventID);

                FK_CHAR_TYPE_CD = charTypeID.getTrimmedValue();
                CHAR_TYPE_DESCR = charType.fetchLanguageDescription().trim();
                PAY_EVENT_ID = payEvtStr.trim();
                PAY_DT = payEvent.getPaymentDate().toString().trim();
                PAYMENT_ID = payment.getId().getTrimmedValue();
                ACCT_ID = payment.getAccount().getId().getTrimmedValue();
                PAY_AMT = payment.getPaymentAmount().getAmount().toString().trim();
                CAN_RSN_CD = payment.getCancelReasonId().getTrimmedValue();
                CAN_RSN_DESCR = payment.fetchCancelReason().fetchLanguageDescription().trim();
            }

            if (counter == 1){
                wDelimitedHeader.append(FK_CHAR_TYPE_CD.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(CHAR_TYPE_DESCR.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(PAY_EVENT_ID.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(PAY_DT.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(PAYMENT_ID.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(ACCT_ID.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(PAY_AMT.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(CAN_RSN_CD.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(CAN_RSN_DESCR.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
            }
            else {
                wDelimitedHeader.append(PAYMENT_ID.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(ACCT_ID.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(PAY_AMT.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(CAN_RSN_CD.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(CAN_RSN_DESCR.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
            }
        }
    }


    private void compressPayPlanInfo() {

        // Extract first 12 records of the pay plan collection
        int counter = 0;

        while(counter < 12) {

            counter++;

            String FK_CHAR_TYPE_CD = " ";
            String CHAR_TYPE_DESCR = " ";
            String PP_ID = " ";
            String ACCT_ID = " ";
            String PP_TYPE_CD = " ";
            String PP_DESCR = " ";
            String PP_START_DT = " ";
            String PP_STATUS = " ";
            String PP_SCHED_DT = " ";
            String PP_AMT = " ";

            if (notNull(wPayPlanColl)
                    && wPayPlanColl.hasNext()) {

                SQLResultRow sqlRow = (SQLResultRow) wPayPlanColl.next();
                CharacteristicType_Id charTypeID = (CharacteristicType_Id) sqlRow.getId("CHAR_TYPE_CD", CharacteristicType.class);
                CharacteristicType charType = charTypeID.getEntity();
                String payPlanStr = sqlRow.getString("CHAR_VAL_FK1");
                PaymentPlan_Id payPlanID = new PaymentPlan_Id(payPlanStr.trim());
                PaymentPlan payPlan = payPlanID.getEntity();
                PaymentPlanScheduledPayment payPlanSched = getPayPlanSchedPay(payPlanID);

                FK_CHAR_TYPE_CD = charTypeID.getTrimmedValue();
                CHAR_TYPE_DESCR = charType.fetchLanguageDescription().trim();
                PP_ID = payPlanStr.trim();
                ACCT_ID = payPlan.getAccount().getId().getTrimmedValue();
                PP_TYPE_CD = payPlan.getPaymentPlanType().getId().getTrimmedValue();
                PP_DESCR = payPlan.getPaymentPlanType().fetchLanguageDescription().trim();
                PP_START_DT = payPlan.getStartDate().toString().trim();
                PP_STATUS = payPlan.getPaymentPlanStatus().getLookupValue().fetchLanguageDescription().trim();
                PP_SCHED_DT = payPlanSched.fetchIdScheduledDate().toString().trim();
                PP_AMT = payPlanSched.getScheduledAmount().getAmount().toString().trim();
            }

            if (counter == 1) {
                wDelimitedHeader.append(FK_CHAR_TYPE_CD.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(CHAR_TYPE_DESCR.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(PP_ID.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(ACCT_ID.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(PP_TYPE_CD.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(PP_DESCR.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(PP_START_DT.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(PP_STATUS.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(PP_SCHED_DT.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(PP_AMT.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
            }
            else {
                wDelimitedHeader.append(PP_SCHED_DT.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
                wDelimitedHeader.append(PP_AMT.trim());
                wDelimitedHeader.append(CustomConstantsRepository.TILDE);
            }
        }
    }

    private void compressAdjInfo() {

        String FK_CHAR_TYPE_CD = " ";
        String CHAR_TYPE_DESCR = " ";
        String ADJ_ID = " ";
        String ACCT_ID = " ";
        String ADJ_TYPE_CD = " ";
        String ADJ_DESCR = " ";
        String ADJ_AMT = " ";

        if (notNull(wAdjInfo)) {

            CharacteristicType_Id charTypeID = (CharacteristicType_Id) wAdjInfo.getId("CHAR_TYPE_CD", CharacteristicType.class);
            CharacteristicType charType = charTypeID.getEntity();
            String adjStr = wAdjInfo.getString("CHAR_VAL_FK1");
            Adjustment_Id adjID = new Adjustment_Id(adjStr.trim());
            Adjustment adj = adjID.getEntity();
            AdjustmentType adjType = adj.getAdjustmentType();

            FK_CHAR_TYPE_CD = charTypeID.getTrimmedValue();
            CHAR_TYPE_DESCR = charType.fetchLanguageDescription().trim();
            ADJ_ID = adjStr.trim();
            ACCT_ID = adj.getServiceAgreement().getAccount().getId().getTrimmedValue();
            ADJ_TYPE_CD = adjType.getId().getTrimmedValue();
            ADJ_DESCR = adjType.fetchLanguageDescription().trim();
            ADJ_AMT = adj.getCurrentAmount().getAmount().toString().trim();
        }

        wDelimitedHeader.append(FK_CHAR_TYPE_CD.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CHAR_TYPE_DESCR.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(ADJ_ID.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(ACCT_ID.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(ADJ_TYPE_CD.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(ADJ_DESCR.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(ADJ_AMT.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
    }

    private void compressFaInfo() {

        String FK_CHAR_TYPE_CD = " ";
        String CHAR_TYPE_DESCR = " ";
        String FA_ID = " ";
        String FA_TYPE_CD = " ";
        String FA_TYPE_DESCR = " ";
        String FA_SCHED_DTTM = " ";
        String FA_STATUS = " ";
        String FA_CAN_RSN_CD = " ";
        String FA_CAN_DESCR = " ";
        String FA_RESCHD_RSN_CD = " ";
        String FA_RESCHD_RSN_DESC = " ";

        if (notNull(wFaInfo)) {
            CharacteristicType_Id charTypeID = (CharacteristicType_Id) wFaInfo.getId("CHAR_TYPE_CD", CharacteristicType.class);
            CharacteristicType charType = charTypeID.getEntity();
            String faStr = wFaInfo.getString("CHAR_VAL_FK1");
            FieldActivity_Id faID = new FieldActivity_Id(faStr.trim());
            FieldActivity fa = faID.getEntity();
            FieldActivityType faType = fa.getFieldActivityType();

            FK_CHAR_TYPE_CD = charTypeID.getTrimmedValue();
            CHAR_TYPE_DESCR = charType.fetchLanguageDescription().trim();
            FA_ID = faStr.trim();
            FA_TYPE_CD = faType.getId().getTrimmedValue();
            FA_TYPE_DESCR = faType.fetchLanguageDescription().trim();
            FA_SCHED_DTTM = fa.getScheduleDateTimeStart().toString().trim();
            FA_STATUS = fa.getFieldActivityStatus().getLookupValue().fetchLanguageDescription().trim();
            if (notNull(fa.getCancelReasonId())) {
                FA_CAN_RSN_CD = fa.getCancelReasonId().getTrimmedValue();
                FA_CAN_DESCR = fa.getCancelReasonId().getEntity().fetchLanguageDescription().trim();
            }
            if (notNull(fa.getFieldworkRescheduleReasonId())) {
                FA_RESCHD_RSN_CD = fa.getFieldworkRescheduleReasonId().getTrimmedValue();
                FA_RESCHD_RSN_DESC = fa.getFieldworkRescheduleReasonId().getEntity().fetchLanguageDescription().trim();
            }
        }

        wDelimitedHeader.append(FK_CHAR_TYPE_CD.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CHAR_TYPE_DESCR.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(FA_ID.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(FA_TYPE_CD.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(FA_TYPE_DESCR.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(FA_SCHED_DTTM.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(FA_STATUS.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(FA_CAN_RSN_CD.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(FA_CAN_DESCR.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(FA_RESCHD_RSN_CD.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(FA_RESCHD_RSN_DESC.trim());
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
    }

    private void compressPremInfo() {

        String FK_CHAR_TYPE_CD = " ";
        String CHAR_TYPE_DESCR = " ";
        String PREMISE_ID = " ";
        String COUNTRY = " ";
        String ADDRESS1 = " ";
        String ADDRESS2 = " ";
        String ADDRESS3 = " ";
        String ADDRESS4 = " ";
        String CITY = " ";
        String NUM1 = " ";
        String NUM2 = " ";
        String HOUSE_TYPE = " ";
        String COUNTY = " ";
        String STATE = " ";
        String POSTAL = " ";
        String IN_CITY_LIMIT = " ";
        String MAIL_MULTI = " ";

        if (notNull(wPremInfo)) {

            CharacteristicType_Id charTypeID = (CharacteristicType_Id) wPremInfo.getId("CHAR_TYPE_CD", CharacteristicType.class);
            CharacteristicType charType = charTypeID.getEntity();
            String premStr = wPremInfo.getString("CHAR_VAL_FK1");
            Premise_Id premID = new Premise_Id(premStr.trim());
            Premise prem = premID.getEntity();

            FK_CHAR_TYPE_CD = charTypeID.getTrimmedValue();
            CHAR_TYPE_DESCR = charType.fetchLanguageDescription().trim();
            PREMISE_ID = premStr.trim();
            COUNTRY = prem.getCountryId().getTrimmedValue();
            ADDRESS1 = prem.getAddress1();
            ADDRESS2 = prem.getAddress2();
            ADDRESS3 = prem.getAddress3();
            ADDRESS4 = prem.getAddress4();
            CITY = prem.getCity();
            NUM1 = prem.getStreetNumber1();
            NUM2 = prem.getStreetNumber2();
            HOUSE_TYPE = prem.getHouseType().trimmedValue();
            COUNTY = prem.getCounty();
            STATE = prem.getState().trim();
            POSTAL = prem.getPostal();
            IN_CITY_LIMIT = "N";
            if (prem.getIsInCityLimit().isTrue()) {
                IN_CITY_LIMIT = "Y";
            }
            MAIL_MULTI = "N";
            if (getMailToMultipleAddressSw().isTrue()) {
                MAIL_MULTI = "Y";
            }
        }

        wDelimitedHeader.append(FK_CHAR_TYPE_CD);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CHAR_TYPE_DESCR);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(PREMISE_ID);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(COUNTRY);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(ADDRESS1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(ADDRESS2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(ADDRESS3);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(ADDRESS4);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(CITY);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(NUM1);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(NUM2);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(HOUSE_TYPE);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(COUNTY);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(STATE);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(POSTAL);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(IN_CITY_LIMIT);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        wDelimitedHeader.append(MAIL_MULTI);
        wDelimitedHeader.append(CustomConstantsRepository.TILDE);
    }

    private void compressCharInfo() {

        // Extract first 15 records of the characteristic collection
        int counter = 0;

        while(counter < 15) {

            counter++;

            String CHAR_TYPE_CD = " ";
            String CHAR_TYPE_DESCR = " ";
            String CHAR_VAL = " ";
            String CHAR_VAL_DESCR =  " ";
            String ADHOC_CHAR_VAL = " ";

            if (notNull(wCharColl)
                    && wCharColl.hasNext()) {

                SQLResultRow sqlRow = (SQLResultRow) wCharColl.next();
                CharacteristicType_Id charTypeID = (CharacteristicType_Id) sqlRow.getId("CHAR_TYPE_CD", CharacteristicType.class);
                CharacteristicType charType = charTypeID.getEntity();
                String charValStr = sqlRow.getString("CHAR_VAL");
                String adhocCharVal = sqlRow.getString("ADHOC_CHAR_VAL");
                CharacteristicValue_Id charValID = new CharacteristicValue_Id(charTypeID, charValStr);
                CharacteristicValue charVal = charValID.getEntity();

                CHAR_TYPE_CD = charTypeID.getTrimmedValue();
                CHAR_TYPE_DESCR = charType.fetchLanguageDescription().trim();
                if (notBlank(charValStr)){
                    CHAR_VAL = charValStr.trim();
                    CHAR_VAL_DESCR = charVal.fetchLanguageDescription().trim();
                }
                if (notBlank(adhocCharVal)) {
                    ADHOC_CHAR_VAL = adhocCharVal.trim();
                }
            }

            wDelimitedHeader.append(CHAR_TYPE_CD.trim());
            wDelimitedHeader.append(CustomConstantsRepository.TILDE);
            wDelimitedHeader.append(CHAR_TYPE_DESCR.trim());
            wDelimitedHeader.append(CustomConstantsRepository.TILDE);
            wDelimitedHeader.append(CHAR_VAL.trim());
            wDelimitedHeader.append(CustomConstantsRepository.TILDE);
            wDelimitedHeader.append(CHAR_VAL_DESCR.trim());
            wDelimitedHeader.append(CustomConstantsRepository.TILDE);
            wDelimitedHeader.append(ADHOC_CHAR_VAL.trim());
            wDelimitedHeader.append(CustomConstantsRepository.TILDE);
        }
    }

    private void writeLetterRec(){

        CmGeneralLetterExtractRecord letterRecord = new CmGeneralLetterExtractRecord();

        letterRecord.setSortKeyLetterTemplateCode(wLetterTemplate);
        letterRecord.setSortKeyCcId(wCcId);
        letterRecord.setMailingKey(wPostal);
        letterRecord.setCcId(wCcId);
        letterRecord.setPersonId(wPerson);
        letterRecord.setCreateDate(wContactDttm.getDate().toString().trim());
        letterRecord.setCreateTime(wContactDttm.getTime().toString().trim());
        letterRecord.setCcClass(wCustomerContactType.fetchIdContactClass().getId().getTrimmedValue());
        letterRecord.setCcType(wCustomerContactType.fetchIdContactType().trim());
        letterRecord.setLetterTemplateCode(wLetterTemplate);
        letterRecord.setLetterDate(wProcessDate.toString().trim());
        // Start Add - E-06060 - DLampa - 10-24-2022
        letterRecord.setBillFormatFlag(getBillFormatFlag());
        // End Add - E-06060 - DLampa - 10-24-2022

        writetoFile(letterRecord.createRecordString());
    }

    // Start Add - E-06060 - DLampa - 10-24-2022
    private String getBillFormatFlag() {

        String billFormatFlag = "";

        Account_Id acctId = new Account_Id(wAcctId);
        Person_Id personId = new Person_Id(wPerson);
        Account acct = null;

        if (notBlank(wAcctId)) {
            acct = acctId.getEntity();
        } else {
            // Retrieve account linked to the person
            acct = getAccountLinkedToPerson(personId.getEntity()).getEntity();
        }

        // Start Add - E-06267.Issue1 - DLampa - 03-23-2023
        if (isNull(acct.getDivisionId())) {
            // Create To Do if account has no CIS Division
            // create collection of sort keys
            List<String> collSortKeyValues = new ArrayList<String>();
            collSortKeyValues.add(wCcId);

            // create collection of drill keys
            List<String> collDrillKeyValues = new ArrayList<String>();
            collDrillKeyValues.add(wCcId);

            // Create a To Do Entry
            createToDo(collSortKeyValues, collDrillKeyValues, Bool.FALSE);
            // MESSAGE: CIS Division was not found for letter printing of customer contact %1.
            addError(CustomMessageRepositoryMGE.E06267_noCisDivision(wCcId));
        }
        // End Add - E-06267.Issue1 - DLampa - 03-23-2023

        if (wCisDivisionsForFormat.contains(acct.getDivisionId().getEntity())){
            AccountPerson_Id acctPerID = new AccountPerson_Id(personId, acctId);
            AccountPerson acctPer = acctPerID.getEntity();

            billFormatFlag = acctPer.getBillFormat().trimmedValue();
        }

        return billFormatFlag;
    }
    // End Add - E-06060 - DLampa - 10-24-2022

    private void writeMailingInfoRec() {

        CmGeneralLetterMailingInfoExtractRecord mailingRecord = new CmGeneralLetterMailingInfoExtractRecord();

        mailingRecord.setSortKeyLetterTemplateCode(wLetterTemplate);
        mailingRecord.setSortKeyCcId(wCcId);
        mailingRecord.setMailingKey(wPostal);
        mailingRecord.setEntityName1(wEntityName1);
        mailingRecord.setEntityName2(wEntityName2);
        mailingRecord.setEntityName3(wEntityName3);
        mailingRecord.setCountry(wCountry);
        mailingRecord.setAddress1(wAddress1);
        mailingRecord.setAddress2(wAddress2);
        mailingRecord.setAddress3(wAddress3);
        mailingRecord.setAddress4(wAddress4);
        mailingRecord.setCity(wCity);
        mailingRecord.setNum1(wNum1);
        mailingRecord.setNum2(wNum2);
        mailingRecord.setHouseType(wHouseType);
        mailingRecord.setCounty(wCounty);
        mailingRecord.setState(wState);
        mailingRecord.setPostal(wPostal);
        mailingRecord.setGeoCode(wGeoCode);
        mailingRecord.setInCityLimit(wInCityLimit);
        mailingRecord.setCisDivision(getCisDivision());

        writetoFile(mailingRecord.createRecordString());
    }

    private String getCisDivision() {

        String returnValue = "LGC";
        CisDivision_Id cisDivID = null;
        // Retrieve Premise ID CC Char
        String premChar = retrieveCCChar(hpCustomerContact, parmCharTypePremID);
        Premise_Id premID = new Premise_Id(premChar);

        if (notBlank(premChar)
                && notNull(premID.getEntity())) {
            Premise prem = premID.getEntity();
            cisDivID = prem.getDivisionId();
            // Start Delete - E-06267.Issue1 - DLampa - 03-23-2023
            //returnValue = cisDivID.getTrimmedValue();
            // End Delete - E-06267.Issue1 - DLampa - 03-23-2023
        }
        else {
            Account_Id acctID = new Account_Id(wAcctId);

            if (notBlank(wAcctId)
                    && notNull(acctID.getEntity()) ) {
                Account acct = acctID.getEntity();
                cisDivID = acct.getDivisionId();
                // Start Delete - E-06267.Issue1 - DLampa - 03-23-2023
                //returnValue = cisDivID.getTrimmedValue();
                // End Delete - E-06267.Issue1 - DLampa - 03-23-2023
            }
        }

        // Start Add - E-06267.Issue1 - DLampa - 03-23-2023
        if (isNull(cisDivID)) {
            // Create To Do if the CIS Division is not configured on the account
            // create collection of sort keys
            List<String> collSortKeyValues = new ArrayList<String>();
            collSortKeyValues.add(wCcId);

            // create collection of drill keys
            List<String> collDrillKeyValues = new ArrayList<String>();
            collDrillKeyValues.add(wCcId);

            // Create a To Do Entry
            createToDo(collSortKeyValues, collDrillKeyValues, Bool.FALSE);
            // MESSAGE: CIS Division was not found for letter printing of customer contact %1.
            addError(CustomMessageRepositoryMGE.E06267_noCisDivision(wCcId));
        } else {
            returnValue = cisDivID.getTrimmedValue();
        }
        // End Add - E-06267.Issue1 - DLampa - 03-23-2023


        return returnValue;
    }

    private void writeAcctPerRec() {

        CmGeneralLetterAccountPersonExtractRecord acctPerRecord = new CmGeneralLetterAccountPersonExtractRecord();

        acctPerRecord.setSortKeyLetterTemplateCode(wLetterTemplate);
        acctPerRecord.setSortKeyCcId(wCcId);
        acctPerRecord.setMailingKey(wPostal);
        acctPerRecord.setPreferredContactMethod(wPrefMethodOfContact);
        acctPerRecord.setEmailId(wEmail);
        acctPerRecord.setCheckDigit(getAcctCheckDigit());
        acctPerRecord.setAcctId(" ");

        if (notBlank(wAcctId)) {
            acctPerRecord.setAcctId(wAcctId);
        }

        writetoFile(acctPerRecord.createRecordString());
    }

    private String getAcctCheckDigit() {

        String returnValue = " ";
        if (notBlank(wAcctId)) {
            CmAccountCheckDigitRetriever acctCheckDigitRetriever = CmAccountCheckDigitRetriever.Factory.newInstance();
            acctCheckDigitRetriever.inputAccount(wAcctId);
            acctCheckDigitRetriever.execute();
            returnValue = acctCheckDigitRetriever.getCheckDigit();
        }
        return returnValue;
    }

    private void writeDetailRec() {

        // Extract Bill FK Characteristics
        Iterator<SQLResultRow> billColl = retrieveCustomerContactFKChar(CustomConstantsRepository.TBL_BILL);
        while (billColl.hasNext()) {

            wBillInfo = billColl.next();
            writeBillInfo(wBillInfo);
        }

        // Extract Payment Event FK Characteristics
        wPayEvtColl = retrieveCustomerContactFKChar(CustomConstantsRepository.TBL_PAY_EVT);
        while (wPayEvtColl.hasNext()) {

            SQLResultRow sqlRowPayEvt = wPayEvtColl.next();
            writePayEventInfo(sqlRowPayEvt);
        }

        // Extract Pay Plan FK Characteristics
        wPayPlanColl = retrieveCustomerContactFKChar(CustomConstantsRepository.TBL_PAY_PLAN);
        while (wPayPlanColl.hasNext()) {

            SQLResultRow sqlRowPayPlan = wPayPlanColl.next();
            writePayPlanInfo(sqlRowPayPlan);
        }

        // Extract Adjustment FK Characteristics
        Iterator<SQLResultRow> adjColl = retrieveCustomerContactFKChar(CustomConstantsRepository.TBL_ADJ);
        while (adjColl.hasNext()) {

            wAdjInfo = adjColl.next();
            writeAdjInfo(wAdjInfo);
        }

        // Extract FA FK Characteristics
        Iterator<SQLResultRow> faColl = retrieveCustomerContactFKChar(CustomConstantsRepository.TBL_FA);
        while (faColl.hasNext()) {

            wFaInfo = faColl.next();
            writeFaInfo(wFaInfo);
        }

        // Extract Premise FK Characteristics
        Iterator<SQLResultRow> premColl = retrieveCustomerContactFKChar(CustomConstantsRepository.TBL_PREM);
        while (premColl.hasNext()) {

            wPremInfo = premColl.next();
            writePremInfo(wPremInfo);
        }

        // Extract other characteristics
        Iterator<SQLResultRow> otherCharsColl = getOtherChars();
        while (otherCharsColl.hasNext()) {

            SQLResultRow otherCharsInfo = otherCharsColl.next();
            writeOtherCharsInfo(otherCharsInfo);
        }
    }

    private void writeBillInfo(SQLResultRow sqlRow) {

        String FK_CHAR_TYPE_CD = " ";
        String CHAR_TYPE_DESCR = " ";
        String BILL_ID = " ";
        String ACCT_ID = " ";
        BigDecimal APAY_AMT = BigDecimal.ZERO;
        String BILL_DT = " ";
        String DUE_DT = " ";
        String LATE_PAY_CHRG_DT = " ";
        BigDecimal BILL_AMT = BigDecimal.ZERO;

        if(notNull(sqlRow)) {
            CharacteristicType_Id charTypeID = (CharacteristicType_Id) sqlRow.getId("CHAR_TYPE_CD", CharacteristicType.class);
            CharacteristicType charType = charTypeID.getEntity();
            String billStr = sqlRow.getString("CHAR_VAL_FK1");
            Bill_Id billID = new Bill_Id(billStr.trim());
            Bill bill = billID.getEntity();

            FK_CHAR_TYPE_CD = charTypeID.getTrimmedValue();
            CHAR_TYPE_DESCR = charType.fetchLanguageDescription().trim();
            BILL_ID = billStr.trim();
            ACCT_ID = bill.getAccount().getId().getTrimmedValue();
            APAY_AMT = bill.getAutopayAmount().getAmount();
            BILL_DT = bill.getBillDate().toString().trim();
            DUE_DT = bill.getDueDate().toString().trim();
            // Start Change - RDizon - CCB034.Issue2 - 06-11-2021
            // LATE_PAY_CHRG_DT = bill.getLatePaymentChargeDate().toString().trim();{
            if (!wCisDivisions.contains(bill.getAccount().getDivisionId().getEntity())){
                LATE_PAY_CHRG_DT = bill.getLatePaymentChargeDate().toString().trim();
            }
            // End CHange - RDizon - CCB034.Issue2 - 06-11-2021
            BILL_AMT = getBillAmount(billID);
        }

        CmGeneralLetterBillInformationExtractRecord billInfoRecord = new CmGeneralLetterBillInformationExtractRecord();

        billInfoRecord.setSortKeyLetterTemplateCode(wLetterTemplate);
        billInfoRecord.setSortKeyCcId(wCcId);
        billInfoRecord.setMailingKey(wPostal);
        billInfoRecord.setFKCharType(FK_CHAR_TYPE_CD);
        billInfoRecord.setCharTypeDescr(CHAR_TYPE_DESCR);
        billInfoRecord.setBillId(BILL_ID);
        billInfoRecord.setAcctId(ACCT_ID);
        billInfoRecord.setApayAmt(APAY_AMT);
        billInfoRecord.setBillDate(BILL_DT);
        billInfoRecord.setDueDate(DUE_DT);
        billInfoRecord.setLpcDate(LATE_PAY_CHRG_DT);
        billInfoRecord.setBillAmt(BILL_AMT);

        writetoFile(billInfoRecord.createRecordString());
    }

    private void writePayEventInfo(SQLResultRow sqlRow) {

        String FK_CHAR_TYPE_CD = " ";
        String CHAR_TYPE_DESCR = " ";
        String PAY_EVENT_ID = " ";
        String PAY_DT = " ";
        String PAYMENT_ID = " ";
        String ACCT_ID = " ";
        BigDecimal PAY_AMT = BigDecimal.ZERO;
        String CAN_RSN_CD = " ";
        String CAN_RSN_DESCR = " ";

        if (notNull(sqlRow)) {

            CharacteristicType_Id charTypeID = (CharacteristicType_Id) sqlRow.getId("CHAR_TYPE_CD", CharacteristicType.class);
            CharacteristicType charType = charTypeID.getEntity();
            String payEvtStr = sqlRow.getString("CHAR_VAL_FK1");
            PaymentEvent_Id payEventID = new PaymentEvent_Id(payEvtStr.trim());
            PaymentEvent payEvent = payEventID.getEntity();
            Payment payment = getPayment(payEventID);

            FK_CHAR_TYPE_CD = charTypeID.getTrimmedValue();
            CHAR_TYPE_DESCR = charType.fetchLanguageDescription().trim();
            PAY_EVENT_ID = payEvtStr.trim();
            PAY_DT = payEvent.getPaymentDate().toString().trim();
            PAYMENT_ID = payment.getId().getTrimmedValue();
            ACCT_ID = payment.getAccount().getId().getTrimmedValue();
            PAY_AMT = payment.getPaymentAmount().getAmount();
            CAN_RSN_CD = payment.getCancelReasonId().getTrimmedValue();
            CAN_RSN_DESCR = payment.fetchCancelReason().fetchLanguageDescription().trim();
        }

        CmGeneralLetterPaymentEventInfoExtractRecord payEventInfoRecord = new CmGeneralLetterPaymentEventInfoExtractRecord();

        payEventInfoRecord.setSortKeyLetterTemplateCode(wLetterTemplate);
        payEventInfoRecord.setSortKeyCcId(wCcId);
        payEventInfoRecord.setMailingKey(wPostal);
        payEventInfoRecord.setFKCharType(FK_CHAR_TYPE_CD);
        payEventInfoRecord.setCharTypeDescr(CHAR_TYPE_DESCR);
        payEventInfoRecord.setPayEventId(PAY_EVENT_ID);
        payEventInfoRecord.setPayDate(PAY_DT);
        payEventInfoRecord.setPaymentId(PAYMENT_ID);
        payEventInfoRecord.setAccountId(ACCT_ID);
        payEventInfoRecord.setPayAmt(PAY_AMT);
        payEventInfoRecord.setCancelReasonCd(CAN_RSN_CD);
        payEventInfoRecord.setCancelReasonDescr(CAN_RSN_DESCR);

        writetoFile(payEventInfoRecord.createRecordString());
    }

    private void writePayPlanInfo(SQLResultRow sqlRow) {

        String FK_CHAR_TYPE_CD = " ";
        String CHAR_TYPE_DESCR = " ";
        String PP_ID = " ";
        String ACCT_ID = " ";
        String PP_TYPE_CD = " ";
        String PP_DESCR = " ";
        String PP_START_DT = " ";
        String PP_STATUS = " ";
        String PP_SCHED_DT = " ";
        BigDecimal PP_AMT = BigDecimal.ZERO;

        if (notNull(sqlRow)) {

            CharacteristicType_Id charTypeID = (CharacteristicType_Id) sqlRow.getId("CHAR_TYPE_CD", CharacteristicType.class);
            CharacteristicType charType = charTypeID.getEntity();
            String payPlanStr = sqlRow.getString("CHAR_VAL_FK1");
            PaymentPlan_Id payPlanID = new PaymentPlan_Id(payPlanStr.trim());
            PaymentPlan payPlan = payPlanID.getEntity();
            Iterator<PaymentPlanScheduledPayment> payPlanSchedColl = payPlan.getScheduledPayments().iterator();
            while (payPlanSchedColl.hasNext()) {

                PaymentPlanScheduledPayment payPlanSched = payPlanSchedColl.next();

                FK_CHAR_TYPE_CD = charTypeID.getTrimmedValue();
                CHAR_TYPE_DESCR = charType.fetchLanguageDescription().trim();
                PP_ID = payPlanStr.trim();
                ACCT_ID = payPlan.getAccount().getId().getTrimmedValue();
                PP_TYPE_CD = payPlan.getPaymentPlanType().getId().getTrimmedValue();
                PP_DESCR = payPlan.getPaymentPlanType().fetchLanguageDescription().trim();
                PP_START_DT = payPlan.getStartDate().toString().trim();
                PP_STATUS = payPlan.getPaymentPlanStatus().getLookupValue().fetchLanguageDescription().trim();
                PP_SCHED_DT = payPlanSched.fetchIdScheduledDate().toString().trim();
                PP_AMT = payPlanSched.getScheduledAmount().getAmount();

                CmGeneralLetterPayPlanInfoExtractRecord payPlanInfoRecord = new CmGeneralLetterPayPlanInfoExtractRecord();

                payPlanInfoRecord.setSortKeyLetterTemplateCode(wLetterTemplate);
                payPlanInfoRecord.setSortKeyCcId(wCcId);
                payPlanInfoRecord.setMailingKey(wPostal);
                payPlanInfoRecord.setFKCharType(FK_CHAR_TYPE_CD);
                payPlanInfoRecord.setCharTypeDescr(CHAR_TYPE_DESCR);
                payPlanInfoRecord.setPayPlanId(PP_ID);
                payPlanInfoRecord.setAccountId(ACCT_ID);
                payPlanInfoRecord.setPayPlanType(PP_TYPE_CD);
                payPlanInfoRecord.setPayPlanDescr(PP_DESCR);
                payPlanInfoRecord.setPpStartDt(PP_START_DT);
                payPlanInfoRecord.setPpStatus(PP_STATUS);
                payPlanInfoRecord.setPpSchedDt(PP_SCHED_DT);
                payPlanInfoRecord.setPpAmt(PP_AMT);

                writetoFile(payPlanInfoRecord.createRecordString());
            }
        }
    }

    private void writeAdjInfo(SQLResultRow sqlRow) {

        String FK_CHAR_TYPE_CD = " ";
        String CHAR_TYPE_DESCR = " ";
        String ADJ_ID = " ";
        String ACCT_ID = " ";
        String ADJ_TYPE_CD = " ";
        String ADJ_DESCR = " ";
        BigDecimal ADJ_AMT = BigDecimal.ZERO;

        if (notNull(sqlRow)) {

            CharacteristicType_Id charTypeID = (CharacteristicType_Id) sqlRow.getId("CHAR_TYPE_CD", CharacteristicType.class);
            CharacteristicType charType = charTypeID.getEntity();
            String adjStr = sqlRow.getString("CHAR_VAL_FK1");
            Adjustment_Id adjID = new Adjustment_Id(adjStr.trim());
            Adjustment adj = adjID.getEntity();
            AdjustmentType adjType = adj.getAdjustmentType();

            FK_CHAR_TYPE_CD = charTypeID.getTrimmedValue();
            CHAR_TYPE_DESCR = charType.fetchLanguageDescription().trim();
            ADJ_ID = adjStr.trim();
            ACCT_ID = adj.getServiceAgreement().getAccount().getId().getTrimmedValue();
            ADJ_TYPE_CD = adjType.getId().getTrimmedValue();
            ADJ_DESCR = adjType.fetchLanguageDescription().trim();
            ADJ_AMT = adj.getCurrentAmount().getAmount();
        }

        CmGeneralLetterAdjustmentInfoExtractRecord adjInfoRecord = new CmGeneralLetterAdjustmentInfoExtractRecord();

        adjInfoRecord.setSortKeyLetterTemplateCode(wLetterTemplate);
        adjInfoRecord.setSortKeyCcId(wCcId);
        adjInfoRecord.setMailingKey(wPostal);
        adjInfoRecord.setFKCharType(FK_CHAR_TYPE_CD);
        adjInfoRecord.setCharTypeDescr(CHAR_TYPE_DESCR);
        adjInfoRecord.setAdjId(ADJ_ID);
        adjInfoRecord.setAcctId(ACCT_ID);
        adjInfoRecord.setAdjTypeCd(ADJ_TYPE_CD);
        adjInfoRecord.setAdjDescr(ADJ_DESCR);
        adjInfoRecord.setAdjAmt(ADJ_AMT);

        writetoFile(adjInfoRecord.createRecordString());
    }

    private void writeFaInfo(SQLResultRow sqlRow) {

        String FK_CHAR_TYPE_CD = " ";
        String CHAR_TYPE_DESCR = " ";
        String FA_ID = " ";
        String FA_TYPE_CD = " ";
        String FA_TYPE_DESCR = " ";
        String FA_SCHED_DTTM = " ";
        String FA_STATUS = " ";
        String FA_CAN_RSN_CD = " ";
        String FA_CAN_DESCR = " ";
        String FA_RESCHD_RSN_CD = " ";
        String FA_RESCHD_RSN_DESC = " ";

        if (notNull(sqlRow)) {
            CharacteristicType_Id charTypeID = (CharacteristicType_Id) sqlRow.getId("CHAR_TYPE_CD", CharacteristicType.class);
            CharacteristicType charType = charTypeID.getEntity();
            String faStr = sqlRow.getString("CHAR_VAL_FK1");
            FieldActivity_Id faID = new FieldActivity_Id(faStr.trim());
            FieldActivity fa = faID.getEntity();
            FieldActivityType faType = fa.getFieldActivityType();

            FK_CHAR_TYPE_CD = charTypeID.getTrimmedValue();
            CHAR_TYPE_DESCR = charType.fetchLanguageDescription().trim();
            FA_ID = faStr.trim();
            FA_TYPE_CD = faType.getId().getTrimmedValue();
            FA_TYPE_DESCR = faType.fetchLanguageDescription().trim();
            FA_SCHED_DTTM = fa.getScheduleDateTimeStart().toString().trim();
            FA_STATUS = fa.getFieldActivityStatus().getLookupValue().fetchLanguageDescription().trim();
            if (notNull(fa.getCancelReasonId())) {
                FA_CAN_RSN_CD = fa.getCancelReasonId().getTrimmedValue();
                FA_CAN_DESCR = fa.getCancelReasonId().getEntity().fetchLanguageDescription().trim();
            }
            if (notNull(fa.getFieldworkRescheduleReasonId())) {
                FA_RESCHD_RSN_CD = fa.getFieldworkRescheduleReasonId().getTrimmedValue();
                FA_RESCHD_RSN_DESC = fa.getFieldworkRescheduleReasonId().getEntity().fetchLanguageDescription().trim();
            }
        }

        CmGeneralLetterFaInfoExtractRecord faInfoRecord = new CmGeneralLetterFaInfoExtractRecord();

        faInfoRecord.setSortKeyLetterTemplateCode(wLetterTemplate);
        faInfoRecord.setSortKeyCcId(wCcId);
        faInfoRecord.setMailingKey(wPostal);
        faInfoRecord.setFKCharType(FK_CHAR_TYPE_CD);
        faInfoRecord.setCharTypeDescr(CHAR_TYPE_DESCR);
        faInfoRecord.setFaId(FA_ID);
        faInfoRecord.setFaTypeCd(FA_TYPE_CD);
        faInfoRecord.setFaTypeDescr(FA_TYPE_DESCR);
        faInfoRecord.setFaSchedDttm(FA_SCHED_DTTM);
        faInfoRecord.setFaStatus(FA_STATUS);
        faInfoRecord.setFaCanRsnCd(FA_CAN_RSN_CD);
        faInfoRecord.setFaCanRsnDescr(FA_CAN_DESCR);
        faInfoRecord.setFaReschedRsnCd(FA_RESCHD_RSN_CD);
        faInfoRecord.setFaReschedRsnDescr(FA_RESCHD_RSN_DESC);

        writetoFile(faInfoRecord.createRecordString());
    }

    private void writePremInfo(SQLResultRow sqlRow) {

        String FK_CHAR_TYPE_CD = " ";
        String CHAR_TYPE_DESCR = " ";
        String PREMISE_ID = " ";
        String COUNTRY = " ";
        String ADDRESS1 = " ";
        String ADDRESS2 = " ";
        String ADDRESS3 = " ";
        String ADDRESS4 = " ";
        String CITY = " ";
        String NUM1 = " ";
        String NUM2 = " ";
        String HOUSE_TYPE = " ";
        String COUNTY = " ";
        String STATE = " ";
        String POSTAL = " ";
        String GEO_CODE = " ";
        String IN_CITY_LIMIT = " ";
        String MAIL_MULTI = " ";

        if (notNull(sqlRow)) {

            CharacteristicType_Id charTypeID = (CharacteristicType_Id) sqlRow.getId("CHAR_TYPE_CD", CharacteristicType.class);
            CharacteristicType charType = charTypeID.getEntity();
            String premStr = sqlRow.getString("CHAR_VAL_FK1");
            Premise_Id premID = new Premise_Id(premStr.trim());
            Premise prem = premID.getEntity();

            FK_CHAR_TYPE_CD = charTypeID.getTrimmedValue();
            CHAR_TYPE_DESCR = charType.fetchLanguageDescription().trim();
            PREMISE_ID = premStr.trim();
            COUNTRY = prem.getCountryId().getTrimmedValue();
            ADDRESS1 = prem.getAddress1();
            ADDRESS2 = prem.getAddress2();
            ADDRESS3 = prem.getAddress3();
            ADDRESS4 = prem.getAddress4();
            CITY = prem.getCity();
            NUM1 = prem.getStreetNumber1();
            NUM2 = prem.getStreetNumber2();
            HOUSE_TYPE = prem.getHouseType().trimmedValue();
            COUNTY = prem.getCounty();
            STATE = prem.getState().trim();
            POSTAL = prem.getPostal();
            GEO_CODE = prem.getTaxVendorGeographicalCode();
            IN_CITY_LIMIT = "N";
            if (prem.getIsInCityLimit().isTrue()) {
                IN_CITY_LIMIT = "Y";
            }
            MAIL_MULTI = "N";
            if (getMailToMultipleAddressSw().isTrue()) {
                MAIL_MULTI = "Y";
            }
        }

        CmGeneralLetterPremiseInfoExtractRecord premInfoRecord = new CmGeneralLetterPremiseInfoExtractRecord();

        premInfoRecord.setSortKeyLetterTemplateCode(wLetterTemplate);
        premInfoRecord.setSortKeyCcId(wCcId);
        premInfoRecord.setMailingKey(wPostal);
        premInfoRecord.setFKCharType(FK_CHAR_TYPE_CD);
        premInfoRecord.setCharTypeDescr(CHAR_TYPE_DESCR);
        premInfoRecord.setPremId(PREMISE_ID);
        premInfoRecord.setCountry(COUNTRY);
        premInfoRecord.setAddress1(ADDRESS1);
        premInfoRecord.setAddress2(ADDRESS2);
        premInfoRecord.setAddress3(ADDRESS3);
        premInfoRecord.setAddress4(ADDRESS4);
        premInfoRecord.setCity(CITY);
        premInfoRecord.setNum1(NUM1);
        premInfoRecord.setNum2(NUM2);
        premInfoRecord.setHouseType(HOUSE_TYPE);
        premInfoRecord.setCounty(COUNTY);
        premInfoRecord.setState(STATE);
        premInfoRecord.setPostal(POSTAL);
        premInfoRecord.setGeoCode(GEO_CODE);
        premInfoRecord.setInCityLimit(IN_CITY_LIMIT);
        premInfoRecord.setMailToMulti(MAIL_MULTI);

        writetoFile(premInfoRecord.createRecordString());
    }

    private Bool getMailToMultipleAddressSw() {

        Bool returnValue = Bool.FALSE;

        // If account is populated, retrieve the bill address source
        if (notBlank(wAcctId)) {

            Account_Id acctID = new Account_Id(wAcctId);
            Person_Id perID = hpCustomerContact.getPersonId();
            BillingAddressSourceLookup addressSource = getAddressSource(acctID, perID);

            if (addressSource.isMailingPremiseOnAccount()) {
                String charValMailToMultiple = retrieveCCChar(hpCustomerContact, parmCharTypeMailToMultiple);

                if (charValMailToMultiple.trim().compareTo(
                        parmCharValMailToMultiple.trim()) == 0) {
                    returnValue = Bool.TRUE;
                }
            }
        }
        return returnValue;
    }

    private BillingAddressSourceLookup getAddressSource(Account_Id acctID, Person_Id perID) {

        AccountPerson_Id acctPerID = new AccountPerson_Id(perID, acctID);
        AccountPerson acctPer = acctPerID.getEntity();
        BillingAddressSourceLookup addressSource = acctPer.getBillAddressSource();
        return addressSource;
    }

    /**
     * This SQL is based on CMPCXCCX XQ180-GET-CC-OTHERS-CHARS
     *
     * @return CollectionOfOtherCcChars
     */
    private Iterator<SQLResultRow> getOtherChars() {

        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append("SELECT ");
        stringBuilder.append("    CCCH.CHAR_TYPE_CD, ");
        stringBuilder.append("    CTYP.CHAR_TYPE_FLG, ");
        stringBuilder.append("    CCCH.CHAR_VAL, ");
        stringBuilder.append("    CCCH.ADHOC_CHAR_VAL, ");
        stringBuilder.append("    CCCH.CHAR_VAL_FK1 ");
        stringBuilder.append("FROM ");
        stringBuilder.append("    CI_CC_CHAR CCCH, ");
        stringBuilder.append("    CI_CHAR_TYPE CTYP ");
        stringBuilder.append("WHERE ");
        stringBuilder.append("    CCCH.CC_ID = :ccID ");
        stringBuilder.append("    AND CCCH.CHAR_TYPE_CD = CTYP.CHAR_TYPE_CD ");
        stringBuilder.append("    AND ( ");
        stringBuilder.append("          (CTYP.CHAR_TYPE_FLG IN ('DFV', 'ADV')) ");
        stringBuilder.append("          OR ");
        stringBuilder.append("          (CTYP.CHAR_TYPE_FLG = 'FKV' ");
        stringBuilder.append("           AND NOT EXISTS (SELECT 'X' ");
        stringBuilder.append("                           FROM CI_FK_REF FKRF ");
        stringBuilder.append("                           WHERE FKRF.FK_REF_CD = CTYP.FK_REF_CD ");
        stringBuilder.append("                           AND FKRF.TBL_NAME IN ('CI_BILL', ");
        stringBuilder.append("                                              'CI_PAY_EVENT', ");
        stringBuilder.append("                                              'CI_PP', ");
        stringBuilder.append("                                              'CI_ADJ', ");
        stringBuilder.append("                                              'CI_FA', ");
        stringBuilder.append("                                              'CI_PREM') ");
        stringBuilder.append("                          ) ");
        stringBuilder.append("          ) ");
        stringBuilder.append("        ) ");

        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getOtherChars=");
        prepState.bindId("ccID", hpCustomerContact.getId());
        prepState.setAutoclose(false);
        prepState.execute();
        Iterator<SQLResultRow> returnValue = prepState.list().iterator();
        prepState.close();
        return returnValue;
    }

    private void writeOtherCharsInfo(SQLResultRow sqlRow) {

        String CHAR_TYPE_CD = " ";
        String CHAR_TYPE_DESCR = " ";
        String CHAR_VAL = " ";
        String CHAR_VAL_DESCR = " ";
        String ADHOC_CHAR_VAL = " ";

        if (notNull(sqlRow)) {

            CharacteristicType_Id charTypeID = (CharacteristicType_Id) sqlRow.getId("CHAR_TYPE_CD", CharacteristicType.class);
            CharacteristicType charType = charTypeID.getEntity();
            CharacteristicTypeLookup charTypeValueType =
                    (CharacteristicTypeLookup) sqlRow.getLookup("CHAR_TYPE_FLG", CharacteristicTypeLookup.class);

            if (charTypeValueType.isPredefinedValue()) {
                String charValStr = sqlRow.getString("CHAR_VAL");
                CharacteristicValue_Id charValID = new CharacteristicValue_Id(charTypeID, charValStr);
                CharacteristicValue charVal = charValID.getEntity();

                CHAR_VAL = charValStr.trim();
                CHAR_VAL_DESCR = charVal.fetchLanguageDescription().trim();
            }
            else {
                if (charTypeValueType.isForeignKeyValue()) {
                    ADHOC_CHAR_VAL = sqlRow.getString("CHAR_VAL_FK1");
                }
                else {
                    ADHOC_CHAR_VAL = sqlRow.getString("ADHOC_CHAR_VAL");
                }
            }

            CHAR_TYPE_CD = charTypeID.getTrimmedValue();
            CHAR_TYPE_DESCR = charType.fetchLanguageDescription().trim();
        }

        CmGeneralLetterOtherCharacteristicInfoExtractRecord otherCharInfoRecord = new CmGeneralLetterOtherCharacteristicInfoExtractRecord();

        otherCharInfoRecord.setSortKeyLetterTemplateCode(wLetterTemplate);
        otherCharInfoRecord.setSortKeyCcId(wCcId);
        otherCharInfoRecord.setMailingKey(wPostal);
        otherCharInfoRecord.setCharTypeCd(CHAR_TYPE_CD);
        otherCharInfoRecord.setCharTypeDescr(CHAR_TYPE_DESCR);
        otherCharInfoRecord.setCharVal(CHAR_VAL);
        otherCharInfoRecord.setCharValDescr(CHAR_VAL_DESCR);
        otherCharInfoRecord.setAdhocCharVal(ADHOC_CHAR_VAL);

        writetoFile(otherCharInfoRecord.createRecordString());
    }

    private void writeEndLetterRec() {

        CmGeneralLetterEndOfLetterExtractRecord endOfLetterRecord = new CmGeneralLetterEndOfLetterExtractRecord();
        endOfLetterRecord.setSortKeyLetterTemplateCode(wLetterTemplate);
        endOfLetterRecord.setSortKeyCcId(wCcId);
        endOfLetterRecord.setMailingKey(wPostal);

        writetoFile(endOfLetterRecord.createRecordString());
    }
}
