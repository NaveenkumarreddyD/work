/**************************************************************************
* Program Name: CmPaymentDistributionAlgComp_Impl
* Program Title: CmPaymentDistributionAlgComp_Impl
* Author: Sharmayne Felipe
* Creation Date: 2017-05-29
* Purpose: This algorithm is a clone of the base Payment Distribution 
*          Algorithm - Distribute by Payment Priority (CIPPDDPX). The 
*          base Algorithm attempts to pay off all aged debt before 
*          applying to current charges on an SA through Payment Priority. 
*          This algorithm will modify the base payment distribution to 
*          apply payments to current charges. New charges will be paid to 
*          the SA by payment hierarchy once all Aged and Current debt is 
*          paid across all SAs.
* Functional Spec: NA-198216
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 * NA-198216          Sharmayne Felipe 2017-05-29    Initial Version
 * B-28203      	  EQuint           2023-05-24    consider debt age when distributing payment 
 * 													 to SA with same priority
 * D-03403			  EQuint		   2023-07-20	 make sure to update the full amount paid
 * 													 and partial amount paid variable after
 * 										    	     processing each SA
 * D-03534			  EQuint		   2023-12-14	 make sure comparator implementation 
 * 													 is transitive
 ************************************************************************************************/
package com.splwg.cm.domain.admin.customerClass.algorithm.payDistribution;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.installation.InstallationHelper;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.currency.Currency_Id;
import com.splwg.ccb.api.lookup.ArrearsCollectionLimitOptionLookup;
import com.splwg.ccb.api.lookup.ArrearsInformationSourceLookup;
import com.splwg.ccb.api.lookup.DebitCreditFlagLookup;
import com.splwg.ccb.api.lookup.DistributionAlgorithmStatusLookup;
import com.splwg.ccb.api.lookup.PaymentPriorityLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.SpecialRoleLookup;
import com.splwg.ccb.domain.admin.customerClass.algorithm.payDistribution.CustomerClassPaymentDistributionAlgorithmSpot;
import com.splwg.ccb.domain.admin.customerClass.algorithm.payDistribution.CustomerClassPaymentDistributionData;
import com.splwg.ccb.domain.admin.depositClass.entity.DepositClass;
import com.splwg.ccb.domain.admin.matchType.algorithm.payDistributionOverride.PaymentDistributionOverrideAlgorithmData;
import com.splwg.ccb.domain.admin.matchType.algorithm.payDistributionOverride.PaymentDistributionOverrideIOData;
import com.splwg.ccb.domain.admin.matchType.entity.MatchType;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.data.ArrearsInfoArrearsCollection;
import com.splwg.ccb.domain.customerinfo.data.ArrearsInfoParameters;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.financial.matchEvent.entity.MatchEvent;
import com.splwg.ccb.domain.payment.data.DetermineSaCreditAmountData;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.cm.domain.payment.data.CmCategorizeAccountCreditData;

/**
 * @author Administrator
 *
 @AlgorithmComponent ()
 */

public class CmPaymentDistributionAlgComp_Impl 
        extends CmPaymentDistributionAlgComp_Gen
        implements CustomerClassPaymentDistributionAlgorithmSpot {    
    
	// Work Variables
    private Currency_Id currencyId = new Currency_Id(InstallationHelper.getCurrencyCode());
    private Bool isDepositClass;
    private PaymentPriorityLookup payPriorityFlgOld; 
    private PaymentPriorityLookup payPriorityFlg;
    private CmCategorizeAccountCreditData categorizeAccountCredit = null;
    private BigDecimal arrearsDaysNotPaid = BigDecimal.ZERO;
    private Money nonDelinquentPayAmount = new Money(BigDecimal.ZERO, currencyId);
    private Money payAmountOnNewDebits = new Money(BigDecimal.ZERO, currencyId);
    private Money fullPaymentAmount = new Money(BigDecimal.ZERO, currencyId);
    private Money partialPaymentAmount = new Money(BigDecimal.ZERO, currencyId);
    private Money remainingAmountForDistribution = new Money(BigDecimal.ZERO, currencyId);
    
    // Hard Parameters
    private Money excessCreditAmountPaid = Money.ZERO;
    private DebitCreditFlagLookup isDebitOrCredit;
    private MatchEvent matchEvent;
    private List<CustomerClassPaymentDistributionData> paymentDistributions = new ArrayList<CustomerClassPaymentDistributionData>();
    private DistributionAlgorithmStatusLookup processingStatus;
    private Bool shouldDistribute;
    private Bill startBill;
    private MatchEvent startMatchEvent;
    private ServiceAgreement startServiceAgreement;
    private Money totalAmountDistributed = Money.ZERO;
    private Account account;
    private DepositClass depositClass;
    private MatchType matchType;
    private String matchValue;
    private Payment payment;
    private Date processDate;
    private Money creditAmount = Money.ZERO;  
    
    // Soft Parameters
    
    // Getters and Setters
    public Money getExcessCreditAmountPaid() {
        return excessCreditAmountPaid;
    }

    public DebitCreditFlagLookup getIsDebitOrCredit() {
        return isDebitOrCredit;
    }

    public MatchEvent getMatchEvent() {
        return matchEvent;
    }

    public List<CustomerClassPaymentDistributionData> getPaymentDistributions() {
        return paymentDistributions;
    }

    public DistributionAlgorithmStatusLookup getProcessingStatus() {
        return processingStatus;
    }

    public Bool getShouldDistribute() {
        return shouldDistribute;
    }

    public Bill getStartBill() {
       return startBill;
    }

    public MatchEvent getStartMatchEvent() {
        return startMatchEvent;
    }

    public ServiceAgreement getStartServiceAgreement() {
        return startServiceAgreement;
    }

    public Money getTotalAmountDistributed() {
        return totalAmountDistributed;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public void setCreditAmount(Money creditAmount) {
        this.creditAmount = creditAmount;
    }

    public void setDepositClass(DepositClass depositClass) {
        this.depositClass = depositClass;   
    }

    public void setIsDebitOrCredit(DebitCreditFlagLookup isDebitOrCredit) {
        this.isDebitOrCredit = isDebitOrCredit;    
    }

    public void setMatchEvent(MatchEvent matchEvent) {
        this.matchEvent = matchEvent; 
    }

    public void setMatchType(MatchType matchType) {
        this.matchType = matchType;
    }

    public void setMatchValue(String matchValue) {
        this.matchValue = matchValue;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }

    public void setProcessDate(Date processDate) {
       this.processDate = processDate;
    }

    public void setProcessingStatus(DistributionAlgorithmStatusLookup processingStatus) {
        this.processingStatus = processingStatus;
        
    }

    public void setShouldDistribute(Bool shouldDistribute) {
        this.shouldDistribute = shouldDistribute; 
    }

    public void setStartBill(Bill startBill) {
        this.startBill = startBill;        
    }

    public void setStartMatchEvent(MatchEvent startMatchEvent) {
        this.startMatchEvent = startMatchEvent;   
    }

    public void setStartServiceAgreement(ServiceAgreement startServiceAgreement) {
        this.startServiceAgreement = startServiceAgreement;
    }
  
    
    /**
     * This method initializes parameters.
     */
    protected void initialize() {  
    	
        
        // If a deposit class is entered, switch to proper SQL.
        if (isNull(depositClass)) {
            isDepositClass = Bool.FALSE;
        } else {
            isDepositClass = Bool.TRUE;
        }
        
        if (isNull(processDate)) {
            setProcessDate(getProcessDateTime().getDate());
        }
    }  
    
    /**
     * This method invokes main processing.
     */
    public void invoke() {
	
        initialize();
        
        // First, distribute using the override distribution algorithm if specified
        if(notNull(matchType)){
            matchTypePayDistributionOverride();      

            if (shouldDistribute.isTrue()) {
                return;
            }
        }
        
        distributePayment();

    }
    
    /**
     * This method will distribute payment using the override distribution algorithm.
     */
    private void matchTypePayDistributionOverride () {
        
        PaymentDistributionOverrideAlgorithmData paymentDistributionOverrideAlgo = PaymentDistributionOverrideAlgorithmData.Factory.newInstance(); 
        paymentDistributionOverrideAlgo.setAccount(account);
        paymentDistributionOverrideAlgo.setCreditAmount(creditAmount.getAmount());
        paymentDistributionOverrideAlgo.setDepositClass(depositClass);
        paymentDistributionOverrideAlgo.setMatchValue(matchValue);
        paymentDistributionOverrideAlgo.setPayment(payment);
        paymentDistributionOverrideAlgo.setProcessDate(processDate);
        paymentDistributionOverrideAlgo.setStartBill(startBill);
        paymentDistributionOverrideAlgo.setStartServiceAgreement(startServiceAgreement);

        PaymentDistributionOverrideIOData paymentDistributionOverrideIOData = PaymentDistributionOverrideIOData.Factory.newInstance();
        paymentDistributionOverrideIOData.setDebitCreditFlag(isDebitOrCredit);
        paymentDistributionOverrideIOData.setMatchEvent(matchEvent);
        paymentDistributionOverrideIOData.setShouldDistribute(shouldDistribute);
        
        paymentDistributionOverrideAlgo.setDistributionOverrideInputOutput(paymentDistributionOverrideIOData);
        
        matchType.overridePaymentDistribution(paymentDistributionOverrideAlgo);
        
        // Pass the values from paymentDistributionOverrideAlgo to hard parameters.
        if (!isNull(paymentDistributionOverrideAlgo.getExcessCreditPaid())) {
            excessCreditAmountPaid = new Money (paymentDistributionOverrideAlgo.getExcessCreditPaid(), currencyId);
        }        
        if (!isNull(paymentDistributionOverrideAlgo.getTotalDistributedAmount())) {
            totalAmountDistributed = new Money (paymentDistributionOverrideAlgo.getTotalDistributedAmount(), currencyId);
        }
        startServiceAgreement = paymentDistributionOverrideAlgo.getStartServiceAgreement();        
        startBill = paymentDistributionOverrideAlgo.getStartBill();
        if (!isNull(paymentDistributionOverrideAlgo.getDistributionOverrideInputOutput())) {
            isDebitOrCredit = paymentDistributionOverrideAlgo.getDistributionOverrideInputOutput().getDebitCreditFlag();
            matchEvent = paymentDistributionOverrideAlgo.getDistributionOverrideInputOutput().getMatchEvent();
            shouldDistribute = paymentDistributionOverrideAlgo.getDistributionOverrideInputOutput().getShouldDistribute();
            startMatchEvent = paymentDistributionOverrideAlgo.getDistributionOverrideInputOutput().getStartMatchEvent();             
        }
       
        if (!isNull(paymentDistributionOverrideAlgo.getPaymentDistributionServiceAgreementList())) {
            for (int i = 0; i < paymentDistributionOverrideAlgo.getPaymentDistributionServiceAgreementList().size(); i++) {              
                Money creditAmt = new Money(paymentDistributionOverrideAlgo.getPaymentDistributionServiceAgreementList().get(i).getCreditAmount(), currencyId);
                MatchEvent me = paymentDistributionOverrideAlgo.getPaymentDistributionServiceAgreementList().get(i).getMatchEvent();
                ServiceAgreement sa = paymentDistributionOverrideAlgo.getPaymentDistributionServiceAgreementList().get(i).getServiceAgreement();
                
                CustomerClassPaymentDistributionData addSaToCollection = CustomerClassPaymentDistributionData.Factory.newInstance();
                addSaToCollection.setCreditAmount(creditAmt);
                addSaToCollection.setMatchEvent(me);
                addSaToCollection.setServiceAgreement(sa);
                paymentDistributions.add(addSaToCollection);
            }           
        }
    }    
    
    /**
     * This method will distribute payment amount.
     */
    private void distributePayment() {
        
        //Evaluate where the credit can be applied at an account level.
        categorizeAccountCredit = categorizeAccountCredit();
        
        //Move excess credits from categorize account credit to excessCreditAmountPaid.
        excessCreditAmountPaid = categorizeAccountCredit.getExcessCreditAmount();                
        
        //Select Service Agreements in the Account by Payment Priority.        
        Iterator<SQLResultRow> accountSasIterator = getAccountSas().iterator();
        remainingAmountForDistribution = creditAmount;
         
        while (accountSasIterator.hasNext()) {       
            //Process SA. Add an occurrence to the collection if there are credits which should be applied to the SA.
            SQLResultRow resultRow = accountSasIterator.next(); 
            processSa(resultRow);
            
            payPriorityFlgOld = payPriorityFlg;
        }
    }
    
    /**
     * This method will determine the effect that the credit will have on the account as a whole.
     * @return CategorizeAccountCreditData
     */
    private CmCategorizeAccountCreditData categorizeAccountCredit() {
        CmCategorizeAccountCreditData categorizeAccountCreditData = CmCategorizeAccountCreditData.Factory.newInstance();
        categorizeAccountCreditData.setCreditAmount(creditAmount);
        categorizeAccountCreditData.setProcessDate(processDate);
        categorizeAccountCreditData.setAccount(account);
        
        if (isDepositClass.isTrue()) {
            categorizeAccountCreditData.setDepositClass(depositClass);
        }
        
        categorizeAccountCreditData.categorizeAccountCredit();
        
        return categorizeAccountCreditData;
    }

    /**
     * This method will process the SA retrieved.
     * @param accountSa, as SQLResultRow
     */
    private void processSa(SQLResultRow accountSa) {

        payPriorityFlg = accountSa.getLookup("PAY_PRIORITY_FLG", PaymentPriorityLookup.class);        
        ServiceAgreement sa = accountSa.getEntity("SA_ID", ServiceAgreement.class);  
        
        if (remainingAmountForDistribution.isGreaterThan(Money.ZERO)) {
            Bool isPriorityFound = Bool.TRUE;

            /*
             * Check for new payment priority. If so we need to move the credits categories for this priority into the IO area
             * for CIPPCREN so that SAs from this priority can deduct from the correct category.
             */
            if (!payPriorityFlg.equals(payPriorityFlgOld)) {                
                
                int i = 0;
                int y = 0;                 
                isPriorityFound = Bool.FALSE;
                 
                if (!isNull(categorizeAccountCredit.getCategorizeCreditPaymentPriorityDataList())) {                	
                    //Find the appropriate index to the payment priorities array.
                    for (i = 0; i < categorizeAccountCredit.getCategorizeCreditPaymentPriorityDataList().size(); i++) {
                        if (payPriorityFlg.trimmedValue().equals(categorizeAccountCredit.getCategorizeCreditPaymentPriorityDataList()
                                .get(i).getPaymentPriority().trimmedValue())) {      
                            
                            //This means that there are some amounts in the occurrence for this priority.
                            isPriorityFound = Bool.TRUE;
                            y=i;
                            break;
                        }
                    }
                } 
                
                if (isPriorityFound.isTrue()) {
                    arrearsDaysNotPaid = new BigDecimal (categorizeAccountCredit.getCategorizeCreditPaymentPriorityDataList().get(y).getArrearDaysofUnpaidAmount());
                    payAmountOnNewDebits = categorizeAccountCredit.getCategorizeCreditPaymentPriorityDataList().get(y).getPaymentAmountOnNewDebits();
                    fullPaymentAmount = categorizeAccountCredit.getCategorizeCreditPaymentPriorityDataList().get(y).getFullPaymentAmount();
                    partialPaymentAmount = categorizeAccountCredit.getCategorizeCreditPaymentPriorityDataList().get(y).getPartialPaymentAmount();
                }
            }
            
            if (isPriorityFound.isTrue()) {
                /*
                 * Call Determine SA Credit Amount Routine. This should determine the payment amount to be distributed
                 * to the current SA.
                 */                      
                DetermineSaCreditAmountData determineSaCreditAmountData = DetermineSaCreditAmountData.Factory.newInstance();            
                determineSaCreditAmountData.setServiceAgreement(sa);
                determineSaCreditAmountData.setProcessDate(processDate);
                determineSaCreditAmountData.setArrearDaysOfDelinquent(categorizeAccountCredit.getArrearDaysofDelinquentAmount());
                determineSaCreditAmountData.setAmountPaidOnNewDebits(payAmountOnNewDebits);
                determineSaCreditAmountData.setNonDeliquentAmountPaid(nonDelinquentPayAmount);
                determineSaCreditAmountData.setArrearDaysOfUnpaid(arrearsDaysNotPaid.toBigInteger());  
                determineSaCreditAmountData.setFullAmountPaid(fullPaymentAmount);
                determineSaCreditAmountData.setPartialAmountPaid(partialPaymentAmount);
                determineSaCreditAmountData.setExcessCreditAmount(Money.ZERO);
                
                determineSaCreditAmountData = sa.determineSaCreditAmount(determineSaCreditAmountData);

                CustomerClassPaymentDistributionData addToSaCollection = CustomerClassPaymentDistributionData.Factory.newInstance();  
                
                if (remainingAmountForDistribution.isGreaterThan(determineSaCreditAmountData.getCreditAmount())) {
                    if (determineSaCreditAmountData.getCreditAmount().isGreaterThan(Money.ZERO)){
                        addToSaCollection.setServiceAgreement(sa);
                        addToSaCollection.setCreditAmount(determineSaCreditAmountData.getCreditAmount());
                        
                        paymentDistributions.add(addToSaCollection);

                        totalAmountDistributed = totalAmountDistributed.add(determineSaCreditAmountData.getCreditAmount()); 
                        remainingAmountForDistribution = remainingAmountForDistribution.subtract(determineSaCreditAmountData.getCreditAmount());
                    }
                    
                } else {
                    if (remainingAmountForDistribution.isGreaterThan(Money.ZERO)) {
                        addToSaCollection.setServiceAgreement(sa);
                        addToSaCollection.setCreditAmount(remainingAmountForDistribution);
                        paymentDistributions.add(addToSaCollection);
                            
                        totalAmountDistributed = totalAmountDistributed.add(remainingAmountForDistribution);
                        remainingAmountForDistribution = Money.ZERO;
                    }                   
                }
                
	             // start add - D-03403 - equint - 07-20-2023
                fullPaymentAmount = determineSaCreditAmountData.getFullAmountPaid();
                partialPaymentAmount = determineSaCreditAmountData.getPartialAmountPaid();
	             // end add - D-03403 - equint - 07-20-2023
            }
        }
    }

    /**
     * This method will retrieve the SA Type payment priority flag.
     * @return List<QueryResultRow>
     */
    private List<SQLResultRow> getAccountSas() {
        
        List<SQLResultRow> saList;
        StringBuilder strBuilder = new StringBuilder();
        
        if (isDepositClass.isFalse()) {
            strBuilder.append("SELECT SA.SA_ID, SAT.PAY_PRIORITY_FLG, SAT.SVC_TYPE_CD ");
            strBuilder.append("FROM CI_SA SA, CI_SA_TYPE SAT ");
            strBuilder.append("WHERE SA.ACCT_ID =:account ");
            strBuilder.append("AND SA.SA_STATUS_FLG NOT IN (:cancelledStatus, :closedStatus) ");
            strBuilder.append("AND SA.SA_TYPE_CD = SAT.SA_TYPE_CD ");
            strBuilder.append("AND SA.CIS_DIVISION = SAT.CIS_DIVISION ");
            strBuilder.append("AND SAT.PAY_PRIORITY_FLG <> ' ' ");
            strBuilder.append("ORDER BY SAT.PAY_PRIORITY_FLG, SA.SA_ID ");
        } else {
            strBuilder.append("SELECT SA.SA_ID, SAT.PAY_PRIORITY_FLG, SAT.SVC_TYPE_CD ");
            strBuilder.append("FROM CI_SA SA, CI_SA_TYPE SAT ");
            strBuilder.append("WHERE SA.ACCT_ID =:account ");
            strBuilder.append("AND SA.SA_STATUS_FLG NOT IN (:cancelledStatus, :closedStatus) ");
            strBuilder.append("AND SA.SA_TYPE_CD = SAT.SA_TYPE_CD ");
            strBuilder.append("AND SA.CIS_DIVISION = SAT.CIS_DIVISION ");
            strBuilder.append("AND SAT.PAY_PRIORITY_FLG <> ' ' ");
            strBuilder.append("AND SAT.SPECIAL_ROLE_FLG <> :cashDeposit ");
            strBuilder.append("AND SAT.DEP_CL_CD =:depositClass ");
            strBuilder.append("ORDER BY SAT.PAY_PRIORITY_FLG, SA.SA_ID ");
        }
        
        PreparedStatement getSAs = createPreparedStatement(strBuilder.toString(), getClass().getName());
        getSAs.bindEntity("account", account);
        getSAs.bindLookup("cancelledStatus", ServiceAgreementStatusLookup.constants.CANCELED);
        getSAs.bindLookup("closedStatus", ServiceAgreementStatusLookup.constants.CLOSED);
        
        if(isDepositClass.isTrue()) {
            getSAs.bindEntity("depositClass", depositClass);
            getSAs.bindLookup("cashDeposit", SpecialRoleLookup.constants.CASH_DEPOSIT);
        }
        
        saList = getSAs.list();
        getSAs.close();
        
        // start add - B-28203 - equint - 2023-05-24
        // sort the list further by age debt if SA has the same priority
        Collections.sort(saList, new Comparator<SQLResultRow>() {
        	@Override
            public int compare(SQLResultRow row1, SQLResultRow row2) {
        		
        		PaymentPriorityLookup payPriorityFlg1 = row1.getLookup("PAY_PRIORITY_FLG", PaymentPriorityLookup.class);    
                PaymentPriorityLookup payPriorityFlg2 = row2.getLookup("PAY_PRIORITY_FLG", PaymentPriorityLookup.class);
                
                int payPriorityCompareTo = payPriorityFlg1.compareTo(payPriorityFlg2);
                // if payment priority is not the same, then sort by payment priority (higher priority first)
                if (payPriorityCompareTo != 0) {
                	return payPriorityCompareTo;
                } else {
                	// else get the arrears info both SAs
                	ServiceAgreement sa1 = row1.getEntity("SA_ID", ServiceAgreement.class);  
                    ServiceAgreement sa2 = row2.getEntity("SA_ID", ServiceAgreement.class);  
                    
                    ArrearsInfoParameters arrearsInfoParms = ArrearsInfoParameters.Factory.newInstance();
                    arrearsInfoParms.setArrearsSource(ArrearsInformationSourceLookup.constants.SERVICE_AGREEMENT);
                    arrearsInfoParms.setReferenceDate(processDate);
                    
                    try {
                        arrearsInfoParms.setCreditReferenceDate(Date.fromString("4712-12-31", new DateFormat("yyyy-MM-dd")));
                    } catch (DateFormatParseException e) {
                        e.printStackTrace();
                    }
                    
                    arrearsInfoParms.setOldestBucketAgeDays(new BigInteger("79999"));
                    arrearsInfoParms.setMustReturnCumulativeArrears(Bool.FALSE);
                    arrearsInfoParms.setMustReturnTotalAmount(Bool.FALSE);
                    arrearsInfoParms.setMustReturnNewDebits(Bool.TRUE);
                    arrearsInfoParms.setCollectionLimitOption(ArrearsCollectionLimitOptionLookup.constants.LUMP_ARREARS);

                    // get the max day aged of SA1
                    List<ArrearsInfoArrearsCollection> arrearsInfoCollection1 = sa1.fetchArrearsInfo(arrearsInfoParms).getArrearsDetails();
                    BigInteger daysAged1;
					try {
						Optional<ArrearsInfoArrearsCollection> optArrearsInfo = arrearsInfoCollection1.stream().max(Comparator.comparing(ArrearsInfoArrearsCollection::getDaysAged));
						if (optArrearsInfo.isPresent()) {
							ArrearsInfoArrearsCollection maxArrears = optArrearsInfo.get();
							daysAged1 = maxArrears.getDaysAged();
						} else {
							daysAged1 = BigInteger.ZERO;
						}
					} catch (Exception e) {
						e.printStackTrace();
						daysAged1 = BigInteger.ZERO;
					}
                    
					// get the max day aged of SA2
                    List<ArrearsInfoArrearsCollection> arrearsInfoCollection2 = sa2.fetchArrearsInfo(arrearsInfoParms).getArrearsDetails();
                    BigInteger daysAged2;
					try {
						Optional<ArrearsInfoArrearsCollection> optArrearsInfo = arrearsInfoCollection2.stream().max(Comparator.comparing(ArrearsInfoArrearsCollection::getDaysAged));
						if (optArrearsInfo.isPresent()) {
							ArrearsInfoArrearsCollection maxArrears = optArrearsInfo.get();
							daysAged2 = maxArrears.getDaysAged();
						} else {
							daysAged2 = BigInteger.ZERO;
						}
					} catch (Exception e) {
						e.printStackTrace();
						daysAged2 = BigInteger.ZERO;
					}
                	
					// sort by max day aged (higher day aged first)
					// start edit - D-03534 - 2023-12-14 - EQuint
                    // return (daysAged1.compareTo(daysAged2) > 0) ? -1 : 1;
					return daysAged1.compareTo(daysAged2) * -1;
                    // end edit - D-03534 - 2023-12-14 - EQuint
                }
        		
            }
		});
        
        // end add - B-28203 - equint - 2023-05-24
        
        return saList;
    }	
}
