/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 2022-06-03   JTiozon    CCB047. Added additional fields for bill messages.
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractDetailsBillMessageRecord 
		extends ColumnDelimitedRecord{		
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractDetailsBillMessageRecord() {
		// Start Change CCB047 -JTiozon
        //super(8);
        super(16);
		// End Change CCB047 -JTiozon
		// Initialize all fields as blank/spaces
		this.setBPPrinterKey(" ");		
		this.setBPSortKey(" ");
		this.setBPMailingKey(" ");
		this.setBillMsgCd(" ");
		this.setMsgPriorityFlg(" ");
		this.setInsertCd(" ");
		this.setMsgOnBill(" ");	
        /*
        * Start Add CCB047 -JTiozon
        */
		this.setCutDate(" ");
		this.setSeveranceAmount(BigDecimal.ZERO,"0");
		this.setCWRflag(" ");
		this.setDelinquentDate(" ");
		this.setDelinquentAmount(BigDecimal.ZERO,"0");	
		this.setFiller(" ");		
        /*
        * End Add CCB047 -JTiozon
        */        
		this.setFiller();
	}
	private String truncateInput(String value, int maxLength) {
		
		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * 
	 */
	public void setBPPrinterKey(String value) {		
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
	public void setBPSortKey(String value) {
		rightPadColumn(2, 184, truncateInput(value, 184));
	}
	public void setBPMailingKey(String value) {
		rightPadColumn(3, 15, truncateInput(value, 15));
	}	
	/*
	 * Bill Message (List)
	 */
	public void setBillMsgCd(String value) {
		rightPadColumn(4, 4, truncateInput(value, 4));
	}
	public void setMsgPriorityFlg(String value) {
		rightPadColumn(5, 2, truncateInput(value, 2));
	}
	public void setInsertCd(String value) {
		rightPadColumn(6, 8, truncateInput(value, 8));
	}
	public void setMsgOnBill(String value) {
		rightPadColumn(7, 254, truncateInput(value, 254));
	}
	/*
	 * Start Add CCB047 -JTiozon
	 */
	public void setCutDate(String value) {
		rightPadColumn(8, 10, truncateInput(value, 10));
	}

	public void setSeveranceAmount(BigDecimal bdVal, String value) { 
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(9, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(10, 15, truncateInput(value, 15));
	}
	public void setCWRflag(String value) {
		rightPadColumn(11, 1, truncateInput(value, 1));
	}
	public void setDelinquentDate(String value) {
		rightPadColumn(12, 10, truncateInput(value, 10));
	}
	
	public void setDelinquentAmount(BigDecimal bdVal, String value) {	
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(13, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(14, 15, truncateInput(value, 15));
	}
	/*This method is used as another filler after column 14 
	to make Delinquent Amount (column 14) left padded with zeroes.*/
	public void setFiller(String value) {
		rightPadColumn(15, 1, truncateInput(value, 1));
	}
	/*
	 * End Add CCB047 -JTiozon
	 */
	public void setFiller() {
		//rightPadColumn(8, 3176, " ");
        // Start Change CCB047 -JTiozon
		//rightPadColumn(8, 2973, " ");
        // End Change CCB047 -JTiozon
        rightPadColumn(16, 2919, " ");
	}
}