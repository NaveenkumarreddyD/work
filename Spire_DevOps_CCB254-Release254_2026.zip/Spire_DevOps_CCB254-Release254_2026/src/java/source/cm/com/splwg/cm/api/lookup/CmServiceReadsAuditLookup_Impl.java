package com.splwg.cm.api.lookup;

/**
 * @author sdesabhatl002
 * 
 * @LookupFieldname (value = XSVA_OPT_TYP_FLG)
 */

public class CmServiceReadsAuditLookup_Impl 
  extends CmServiceReadsAuditLookup_Gen{

}