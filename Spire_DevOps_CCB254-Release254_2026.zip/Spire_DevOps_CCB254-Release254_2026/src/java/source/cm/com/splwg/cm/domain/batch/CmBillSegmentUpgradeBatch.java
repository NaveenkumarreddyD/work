/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Bill Segment Upgrade Batch
 * 
 * Select all bill segments that references a rate component with any of the 
 * following characteristics: 'REVBLDTM','REVTH', and 'CM-TRSLI'. Copy the 
 * characteristic type and characteristic value from the rate component to  
 * the Bill Segment Calc Line Characteristic.
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2015-08-03   SMiranda   Defect 3253800. Initial version.
 * 2015-08-17   SMiranda   Defect 3290694. Select bill segments in main query, 
 * 						   then filter characteristics in thread worker 
 * 2016-01-27	MPang	   Updated for CCB v2.4 compilation.            
 *************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadIterationStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.StringId;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
//Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.billing.billSegment.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentCalculationHeader;
import com.splwg.ccb.domain.billing.billSegment.BillSegment_Id;
import com.splwg.ccb.domain.rate.rateVersion.RateVersion_Id;*/
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentCalculationHeader;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.rate.rateVersion.entity.RateVersion_Id;
//End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 90723
 *
 @BatchJob (rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = characteristicType, name = REVBLDTM_CHAR_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = REVTH_CHAR_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = TRSLI_CHAR_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity)})
 */
public class CmBillSegmentUpgradeBatch 
		extends CmBillSegmentUpgradeBatch_Gen {	

	public Class<CmBillSegmentUpgradeBatchWorker> getThreadWorkerClass() {
        return CmBillSegmentUpgradeBatchWorker.class;
    }

    public static class CmBillSegmentUpgradeBatchWorker extends
    		CmBillSegmentUpgradeBatchWorker_Gen {
    	
    	private int maxErrors = 0;
    	private int errorCount = 0;

    	// Soft parameters
    	private CharacteristicType revenueCharType;
    	private CharacteristicType usageCharType;
    	private CharacteristicType transportSalesIndicatorCharType; 	
    	        
        @Override
        public void initializeThreadWork(boolean initializationPreviouslySuccessful) throws ThreadAbortedException, RunAbortedException {
        	maxErrors = this.getParameters().getSoftMaxErrors().intValue();        	
        	revenueCharType = this.getParameters().getREVBLDTM_CHAR_TYPE_CD();
        	usageCharType = this.getParameters().getREVTH_CHAR_TYPE_CD();
        	transportSalesIndicatorCharType = this.getParameters().getTRSLI_CHAR_TYPE_CD();
        	
        	startEntityQueryIteratorForThread(BillSegment_Id.class);
        }

        public ThreadExecutionStrategy createExecutionStrategy() {
        	return new ThreadIterationStrategy(this);
        }
        
        protected QueryIterator getQueryIteratorForThread(StringId lowId, StringId highId) {
        	
        	Query<BillSegment> bsegQuery = createQuery(" from BillSegment bseg " +
        			", Bill bill, Account account " +
        			"where bseg.id between :low and :high " +
        			"and bseg.billSegmentStatus = :frozen " +
        			"and bill.id = bseg.billId " +
        			"and account.id = bill.account.id " +
        			//Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
        			// "and account.divisionId = :cisDivision ");
        			"and account.divisionId = :cisDivision ", getClass().getName());
        			//End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
        	bsegQuery.bindId("low", lowId);
        	bsegQuery.bindId("high", highId);
        	bsegQuery.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
        	bsegQuery.bindId("cisDivision", this.getParameters().getCIS_DIVISION().getId());
        	
        	bsegQuery.addResult("bseg", "bseg");
        	bsegQuery.orderBy("bseg");

        	return bsegQuery.iterate();

        }

        public boolean executeWorkUnit(ThreadWorkUnit threadWorkUnit)
                throws ThreadAbortedException, RunAbortedException {
        	
        	// Get primary Id
        	BillSegment_Id bsegId = (BillSegment_Id)threadWorkUnit.getPrimaryId();
        	BillSegment bseg = bsegId.getEntity();
        	
        	// Check if calc lines exist. If none found, move to the next bill segment
        	Iterator<BillSegmentCalculationHeader> bsegCalcHeaderIter = bseg.getCalculationHeaders().iterator();
        	
        	while (bsegCalcHeaderIter.hasNext()){
        		
        		BillSegmentCalculationHeader bsegCalcHeader = bsegCalcHeaderIter.next();
        		
        		// Check if the calc header is linked to a rate. If none found, move to the next bill segment
        		if (notNull(bsegCalcHeader.getRateVersionId())){    

        			RateVersion_Id rateVersionId = bsegCalcHeader.getRateVersionId();
        			
        			StringBuilder stringBuilder = new StringBuilder();
        			stringBuilder.append("SELECT ");
        			stringBuilder.append("	B.HEADER_SEQ, B.SEQNO, D.CHAR_TYPE_CD, D.CHAR_VAL ");
        			stringBuilder.append("FROM ");
        			stringBuilder.append("	CI_BSEG_CALC_LN B, ");
        			stringBuilder.append("	CI_RC C, ");
        			stringBuilder.append("	CI_RC_CHAR D ");
        			stringBuilder.append("WHERE ");
        			stringBuilder.append("	B.BSEG_ID = :bsegId ");
        			stringBuilder.append("	AND B.HEADER_SEQ = :headerSeq ");
        			stringBuilder.append("	AND C.RS_CD = :rsCode ");
        			stringBuilder.append("	AND C.EFFDT = :effDt ");
        			stringBuilder.append("	AND C.RC_SEQ = B.RC_SEQ ");
		            stringBuilder.append("	AND D.RS_CD = C.RS_CD ");
		            stringBuilder.append("	AND D.EFFDT = C.EFFDT ");
		            stringBuilder.append("	AND D.RC_SEQ = C.RC_SEQ ");
		            stringBuilder.append("	AND D.CHAR_TYPE_CD IN (:REVBLDTM,:REVTH,:CMTRSLI) "); 
		            //Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
		            //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
		            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		            //End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
		            preparedStatement.bindId("bsegId", bsegId);
		            preparedStatement.bindBigInteger("headerSeq", bsegCalcHeader.fetchIdHeaderSequence());
		            preparedStatement.bindId("rsCode", rateVersionId.getRateScheduleId());
		            preparedStatement.bindDate("effDt", rateVersionId.getEffectiveDate());
		            preparedStatement.bindEntity("REVBLDTM", revenueCharType);
		            preparedStatement.bindEntity("REVTH", usageCharType);
		            preparedStatement.bindEntity("CMTRSLI", transportSalesIndicatorCharType); 
		            
		            List<SQLResultRow> bsegCalcLnList = preparedStatement.list();
		            
		            preparedStatement.close();
            
		            if (bsegCalcLnList.size() > 0){
		            	
		            	// Delete chars from bseg calc line
		            	StringBuilder deleteString = new StringBuilder("");
	        			deleteString.append("DELETE ");
	        			deleteString.append("  CI_BSEG_CL_CHAR ");
	        			deleteString.append("WHERE ");
	        			deleteString.append("  BSEG_ID = :bsegId ");
	        			deleteString.append("  AND HEADER_SEQ = :headerSeq ");
	        			deleteString.append("  AND CHAR_TYPE_CD IN (:REVBLDTM,:REVTH,:CMTRSLI) ");
	        			//Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
	        			//PreparedStatement deleteSQL = createPreparedStatement(deleteString.toString());
	        			PreparedStatement deleteSQL = createPreparedStatement(deleteString.toString(), getClass().getName());
	        			//End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
	        			deleteSQL.bindId("bsegId", bsegId);
	        			deleteSQL.bindBigInteger("headerSeq", bsegCalcHeader.fetchIdHeaderSequence());
	        			deleteSQL.bindEntity("REVBLDTM", revenueCharType);
	        			deleteSQL.bindEntity("REVTH", usageCharType);
	        			deleteSQL.bindEntity("CMTRSLI", transportSalesIndicatorCharType);
	        			
	        			deleteSQL.execute();
	        			deleteSQL.close();
	        			
		            }
		            		            
		            Iterator<SQLResultRow> bsegCalcLnListIter = bsegCalcLnList.iterator();

		            while (bsegCalcLnListIter.hasNext()){
		            	
		            	SQLResultRow bsegCalcLnRow = bsegCalcLnListIter.next();
		            	BigInteger headerSeq = bsegCalcLnRow.getInteger("HEADER_SEQ");
		            	BigInteger seqNo = bsegCalcLnRow.getInteger("SEQNO");        		
		            	CharacteristicType_Id charTypeId = (CharacteristicType_Id) bsegCalcLnRow.getId("CHAR_TYPE_CD",CharacteristicType.class);
		            	String charValue = bsegCalcLnRow.getString("CHAR_VAL");				            	
        		
		            	// Insert into CI_BSEG_CL_CHAR
		            	try{
		            		StringBuilder insertString = new StringBuilder("");
		        			insertString.append("INSERT INTO ");
		        			insertString.append(  "CI_BSEG_CL_CHAR ");
		        			insertString.append(  "( ");
		        			insertString.append(    "BSEG_ID ");
		        			insertString.append(    ", HEADER_SEQ ");
		        			insertString.append(    ", SEQNO ");
		        			insertString.append(    ", CHAR_TYPE_CD ");
		        			insertString.append(    ", CHAR_VAL ");
		        			insertString.append(  ") VALUES ( ");
		        			insertString.append(    " :bsegId ");
		        			insertString.append(    ", :headerSeq ");
		        			insertString.append(    ", :seqNo ");    	        
		        			insertString.append(    ", :charTypeId ");
		        			insertString.append(    ", :charValue ");
		        			insertString.append(  ")");
		        			//Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
		        			//PreparedStatement insertSQL = createPreparedStatement(insertString.toString());
		        			PreparedStatement insertSQL = createPreparedStatement(insertString.toString(), getClass().getName());
		        			//End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
		        			insertSQL.bindId("bsegId", bsegId);
		        			insertSQL.bindBigInteger("headerSeq", headerSeq);
		        			insertSQL.bindBigInteger("seqNo", seqNo);
		        			insertSQL.bindId("charTypeId", charTypeId);
		        			insertSQL.bindString("charValue", charValue.trim(), "CHAR_VAL");
    	        
		        			insertSQL.execute();
		        			insertSQL.close();
    	        
		        		}catch(Exception e){
		    			
		        			errorCount++;
		    			
		        			if (errorCount > maxErrors){
		        				throw new RunAbortedException(CustomMessageRepositoryMGE.commMaxErrorLimitExceeded(String.valueOf(maxErrors)));
		        			}else{
		        				addError(CustomMessageRepositoryMGE.commGenericError(e.getMessage()));
		        			}    			  			    			 			    	
		    			
		        		}
		            }
        		}
        		
            }
            	 
        	return true;
                        
        }
        

    }

}
