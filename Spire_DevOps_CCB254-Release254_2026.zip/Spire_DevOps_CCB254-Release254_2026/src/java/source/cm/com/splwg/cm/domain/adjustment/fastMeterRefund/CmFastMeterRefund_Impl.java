/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Fast Meter Refund Business Entity
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2019-11-11	RDizon			CCB-007.5. Initial version.
 **************************************************************************/
package com.splwg.cm.domain.adjustment.fastMeterRefund;

/**
  *  
@BusinessEntity (tableName = CM_FAST_METER_REFUND)
*/

public class CmFastMeterRefund_Impl
    extends CmFastMeterRefund_Gen {
   
}
