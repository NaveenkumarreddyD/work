/*
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Batch process to tag all existing open To Do Entries with a CIS Division 
 * characteristic 
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:                by:                 Reason:                                                                                                   
 * YYYY-MM-DD                         
 * 2021-03-16           DLampa              B-17782. Initial Version.
 * 2021-07-01           DLampa              Updated to correctly populate the use 
 *                                          on bill switch for failed reads
 * 2021-07-07           DLampa              Updated to catch the error for setting 
 *                                          the use on bill switch to no for reads
 *                                          that are used for meter exchanges or 
 *                                          start/stops.                                          
 * 2021-09-14           DLampa              Defect 4595590. Updated to add a final 
 *                                          hi/lo validation of the reads before  
 *                                          creating a To Do Entry. 
 *******************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.ccb.api.lookup.NumberTypeLookup;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.servicePointType.entity.ServicePointType_Id;
import com.splwg.ccb.domain.common.common.NumberHelper;
import com.splwg.ccb.domain.common.data.NumberHelperData;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_DTO;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead_DTO;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author dlampa
 *
 @BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *           softParameters = { @BatchJobSoftParameter (name = USE_ON_BILL_FAILED_READS, type = string, required = true)  
 *                            , @BatchJobSoftParameter (name = TD_TYPE_CD, type = entity, required = true, entityName = toDoType) 
 *                            , @BatchJobSoftParameter (name = CIS_DIVISION, type = string, required = true)})
 */

public class CmCustomToDoHiLoBatch extends CmCustomToDoHiLoBatch_Gen {

    // Logger
    private static final Logger logger = LoggerFactory.getLogger(CmCustomToDoHiLoBatch.class);

    // Soft parameters
    private static Bool useOnBillFailedReads;
    private static ToDoType hiLoToDoType;
    private static String cisDivision;

    // Constants
    private static final String SWITCH_YES = "Y";
    private static final String SWITCH_NO = "N";
    private static final int TD_HILO_MSG_CAT = 15; 
    private static final int TD_HILO_MSG_NBR = 17361;
    private static final String COMMA = ", ";
    private static final String SINGLE_QUOTE = "'";
    private static final String DATE_FORMAT = "yyyy-MM-dd-HH.mm.ss";    
    private static final DateFormat dateFormat = new DateFormat(DATE_FORMAT);
    private static final String MTRCONFIG_ID = "C1_T_MTR_CONFIG_ID";
    
    // Work variables
    private static String useOnBillFailedReadsStr;
    
    @Override
    public JobWork getJobWork() {

        String cisDivisions = createCisDivisionString(cisDivision);
        
        // Retrieve all register reads with the REVIEW_HILO_SW set to Y installed on premises where the CIS Division matches the input
        StringBuilder queryStr = new StringBuilder("");

        queryStr.append("SELECT DISTINCT MR.MR_ID, MR.USE_ON_BILL_SW, MR.MTR_CONFIG_ID, MR.READ_DTTM, RR.REG_READ_ID, PREM.CIS_DIVISION ");
        queryStr.append("FROM CI_MR MR, CI_REG_READ RR, CI_MTR_CONFIG CFG, CI_MTR MTR, CI_MTR_TYPE MTRTY, CI_CFG_SPMR_VW SPMR, CI_SP SP, CI_PREM PREM ");
        queryStr.append("WHERE MR.MR_ID = RR.MR_ID ");
        queryStr.append("AND RR.REVIEW_HILO_SW = :reviewHiLoSw ");
        queryStr.append("AND MR.MTR_CONFIG_ID = CFG.MTR_CONFIG_ID ");
        queryStr.append("AND CFG.MTR_ID = MTR.MTR_ID ");
        queryStr.append("AND MTRTY.PPM_SW = :prepaidMtrSw ");
        queryStr.append("AND CFG.MTR_CONFIG_ID = SPMR.MTR_CONFIG_ID ");
        queryStr.append("AND MR.READ_DTTM > SPMR.INSTALL_DTTM ");
        queryStr.append("AND (MR.READ_DTTM <= SPMR.REMOVAL_DTTM OR SPMR.REMOVAL_DTTM IS NULL) ");
        queryStr.append("AND SPMR.SP_ID = SP.SP_ID ");
        queryStr.append("AND SP.PREM_ID = PREM.PREM_ID ");
        queryStr.append("AND PREM.CIS_DIVISION IN (" + cisDivisions + ") ");           
        queryStr.append("ORDER BY MR.MR_ID ");

        PreparedStatement openToDoEntriesQuery = createPreparedStatement(queryStr.toString(), getClass().getName());

        openToDoEntriesQuery.bindString("reviewHiLoSw", SWITCH_YES, "REVIEW_HILO_SW");
        openToDoEntriesQuery.bindString("prepaidMtrSw", SWITCH_NO, "PPM_SW");

        List<ThreadWorkUnit> threadWorkUnitList = new ArrayList<ThreadWorkUnit>();
        QueryIterator<SQLResultRow> iterator = openToDoEntriesQuery.iterate();
        QueryResultRow row = null;
        ThreadWorkUnit threadWorkUnit = null;
        while (iterator.hasNext()) {
            row = iterator.next();

            threadWorkUnit = new ThreadWorkUnit();
            threadWorkUnit.setPrimaryId(new MeterRead_Id(row.getString("MR_ID")));
            threadWorkUnit.addSupplementalData("USE_ON_BILL_SW", row.getString("USE_ON_BILL_SW"));
            threadWorkUnit.addSupplementalData("MTR_CONFIG_ID", row.getString("MTR_CONFIG_ID"));
            threadWorkUnit.addSupplementalData("READ_DTTM", row.getString("READ_DTTM"));
            threadWorkUnit.addSupplementalData("REG_READ_ID", row.getString("REG_READ_ID"));            
            threadWorkUnit.addSupplementalData("CIS_DIVISION", row.getString("CIS_DIVISION"));

            threadWorkUnitList.add(threadWorkUnit);
        }
        iterator.close();
        openToDoEntriesQuery.close();

        return createJobWorkForThreadWorkUnitList(threadWorkUnitList);

    }
    
    /**
     * This method builds the CIS Division string for the main query.
     * @param cisDivisionStr
     * @return String
     */
    private String createCisDivisionString(String cisDivisionStr) {
        
        StringTokenizer strTokenizer = new StringTokenizer(cisDivisionStr, COMMA);
        StringBuilder strBuilder = new StringBuilder();

        while (strTokenizer.hasMoreElements()) {
            strBuilder.append(SINGLE_QUOTE);
            strBuilder.append(strTokenizer.nextToken().trim());
            strBuilder.append(SINGLE_QUOTE);

            if (strTokenizer.hasMoreTokens()) {
                strBuilder.append(COMMA);
            }
        }

        return strBuilder.toString();
    }    

    public Class<CmCustomToDoHiLoBatchWorker> getThreadWorkerClass() {
        return CmCustomToDoHiLoBatchWorker.class;
    }

    @Override
    public void validateSoftParameters(boolean arg0) {

        useOnBillFailedReadsStr = getParameters().getUSE_ON_BILL_FAILED_READS();
        hiLoToDoType = getParameters().getTD_TYPE_CD();
        cisDivision = getParameters().getCIS_DIVISION();       

        // Use On Bill Switches must be either Y or N
        if (!useOnBillFailedReadsStr.equalsIgnoreCase(SWITCH_YES) && !useOnBillFailedReadsStr.equalsIgnoreCase(SWITCH_NO)) {
            addError(CustomMessageRepositorySpireOne.CCB036_useOnBillSwitchInvalid());
        }
        
        // CIS Division must be valid
        StringTokenizer strTokenizer = new StringTokenizer(cisDivision, ",");
        int cisDivisionCount = strTokenizer.countTokens();

        if(cisDivisionCount < 1) {
            addError(CustomMessageRepositorySpireOne.CCB036_cisDivisionInvalid());
        }
        
        for(int i = 0; i < cisDivisionCount; i++) {
            String cisDivisionStr = strTokenizer.nextToken().trim();
            CisDivision_Id cisDivisionId = new CisDivision_Id(cisDivisionStr);
            CisDivision cisDivisionEntity = cisDivisionId.getEntity();
            
            // Raise an error if the CIS Division is invalid
            if (isNull(cisDivisionEntity)) {
                addError(CustomMessageRepositorySpireOne.CCB036_cisDivisionInvalid());
            }
        }
        
    }    

    public static class CmCustomToDoHiLoBatchWorker extends
            CmCustomToDoHiLoBatchWorker_Gen {

        // Work variables
        private MeterRead meterRead;
        private String useOnBillSw;
        private MeterConfiguration_Id meterConfigId;
        private DateTime readDateTime;
        private RegisterRead_Id registerReadId;
        private CisDivision_Id cisDivisionId;
        
        @Override
        public void initializeThreadWork (boolean initializationPreviouslySuccessful)
                throws ThreadAbortedException, RunAbortedException {

        	useOnBillFailedReadsStr = getParameters().getUSE_ON_BILL_FAILED_READS();
            hiLoToDoType = getParameters().getTD_TYPE_CD();
            cisDivision = getParameters().getCIS_DIVISION();

            if (useOnBillFailedReadsStr.equalsIgnoreCase(SWITCH_YES)) {
                useOnBillFailedReads = Bool.TRUE;
            } else {
                useOnBillFailedReads = Bool.FALSE;
            }            
            
            super.initializeThreadWork(initializationPreviouslySuccessful);
        }

        @Override
        protected boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
            
            MeterRead_Id meterReadId = (MeterRead_Id) unit.getPrimaryId();
            meterRead = meterReadId.getEntity();

            useOnBillSw = (String) unit.getSupplementallData("USE_ON_BILL_SW");
            meterConfigId = new MeterConfiguration_Id(unit.getSupplementallData("MTR_CONFIG_ID").toString());            
            registerReadId = new RegisterRead_Id(unit.getSupplementallData("REG_READ_ID").toString());
            cisDivisionId = new CisDivision_Id(unit.getSupplementallData("CIS_DIVISION").toString());
            try {
                readDateTime = DateTime.fromString(unit.getSupplementallData("READ_DTTM").toString(), dateFormat);
            } catch (DateFormatParseException e) {
                addError(CustomMessageRepositorySpireOne.CCB036_errorParsingDate(unit.getSupplementallData("READ_DTTM").toString()));
            }
            
            // 2021-09-14 - Defect 4595590 - Start Change
            // Create a To Do Entry for all the register readings that were tagged for Hi/Lo review
            // Note: Reads that passed the Hi/Lo review will have the switch already set to 'N' so all reads with the switch
            // set to 'Y' indicates hi/lo validation failure.
            //createToDo();                                 

            // Update the Review Hi/Lo Switch on the failed read
            //RegisterRead registerRead = registerReadId.getEntity();
            //RegisterRead_DTO registerReadDto = registerRead.getDTO();
            //registerReadDto.setIsHighLowReviewed(Bool.FALSE);
            //registerReadDto.setExtraTCopybookFieldValue(MTRCONFIG_ID, meterConfigId.getTrimmedValue());
            //registerRead.setDTO(registerReadDto);
            
            // Update the Use on Bill Switch of the failed read                        
            //MeterRead_DTO meterReadDto = meterRead.getDTO();            
            //meterReadDto.setCanUseOnBill(useOnBillFailedReads);
            // 2021-07-07 - Start Change
            //meterRead.setDTO(meterReadDto);
            //try {
            //	meterRead.setDTO(meterReadDto);
            //} catch (ApplicationError e) {
            //	addError(CustomMessageRepositorySpireOne.CCB036_errorUpdatingUseOnBillSwitch(meterReadId.getTrimmedValue()));
            //}
            // 2021-07-07 - End Change
            
            // Validate the read against the hi/lo limits and determine if a To Do should be created
            RegisterRead registerRead = registerReadId.getEntity();
            RegisterRead_DTO registerReadDto = registerRead.getDTO();
            Bool createToDoForHiLoFailureSw = Bool.FALSE;
            logger.info("Register Read: " + registerReadId);
            logger.info("Low Limit: " + registerRead.getLowLimit());
            logger.info("Hi Limit: " + registerRead.getHighLimit());
    		if (registerRead.getLowLimit().compareTo(BigDecimal.ZERO) == 0 && registerRead.getHighLimit().compareTo(BigDecimal.ZERO) == 0) {
    			logger.info("Limits not found!! No To Do needed.");
    			createToDoForHiLoFailureSw = Bool.FALSE;
    		} else {
    			if (registerRead.getHighLimit().compareTo(registerRead.getLowLimit()) >= 0) {
    				if (registerRead.getRegisterReading().compareTo(registerRead.getHighLimit()) <= 0 
    						&& registerRead.getRegisterReading().compareTo(registerRead.getLowLimit()) >= 0) {
    					createToDoForHiLoFailureSw = Bool.FALSE;
    				} else {
    					createToDoForHiLoFailureSw = Bool.TRUE;
    				}
    			} else {
    				if (registerRead.getRegisterReading().compareTo(registerRead.getHighLimit()) > 0 
    						&& registerRead.getRegisterReading().compareTo(registerRead.getLowLimit()) < 0) {
    					createToDoForHiLoFailureSw = Bool.TRUE;
    				} else {
    					createToDoForHiLoFailureSw = Bool.FALSE;
    				}
    			}
    		}
    		logger.info("Create To Do For Hi/Lo Failure? " + createToDoForHiLoFailureSw);
    		if (createToDoForHiLoFailureSw.isTrue()) {
                createToDo();
                
                // Update the Use on Bill Switch of the failed read                        
                MeterRead_DTO meterReadDto = meterRead.getDTO();            
                meterReadDto.setCanUseOnBill(useOnBillFailedReads);

                try {
                	meterRead.setDTO(meterReadDto);
                } catch (ApplicationError e) {
                	addError(CustomMessageRepositorySpireOne.CCB036_errorUpdatingUseOnBillSwitch(meterReadId.getTrimmedValue()));
                }                
    		}    	
    		            
            // Update the Review Hi/Lo Switch on the processed read so that it is not processed again
    		registerRead = registerReadId.getEntity();    		
            registerReadDto.setIsHighLowReviewed(Bool.FALSE);
            registerReadDto.setExtraTCopybookFieldValue(MTRCONFIG_ID, meterConfigId.getTrimmedValue());
            registerRead.setDTO(registerReadDto);
            // 2021-09-14 - Defect 4595590 - End Change
            
            return true;
        }
        
        /**
         * Create To Do Entry 
         */
        private void createToDo() {
            
            ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
            ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();
                        
            toDoEntryDTO.setBatchControlId(getBatchControlId());
            toDoEntryDTO.setBatchNumber(getBatchNumber());
            toDoEntryDTO.setCreationDateTime(getProcessDateTime());
            toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
            toDoEntryDTO.setToDoTypeId(hiLoToDoType.getId());
            toDoEntryDTO.setMessageId(new Message_Id(new MessageCategory_Id(BigInteger.valueOf(TD_HILO_MSG_CAT)), BigInteger.valueOf(TD_HILO_MSG_NBR)));
                        
            toDoCreator.setToDoDTO(toDoEntryDTO);
                        
            // Use the Meter Read ID as the Drill Key            
			List<ToDoDrillKeyType> drillKeyTypes = getDrillKeyTypes(hiLoToDoType.getId());
			for (ToDoDrillKeyType drillKeyType : drillKeyTypes) {
				toDoCreator.addDrillKeyValue(drillKeyType, meterRead.getId().getTrimmedValue());
			}            
                        
            RegisterRead registerRead = registerReadId.getEntity();
            String uom = registerRead.getRegister().getUnitOfMeasure().getId().getTrimmedValue();
            String tou = "";
            if (!isNull(registerRead.getRegister().getTimeOfUseId())) {
                tou = registerRead.getRegister().getTimeOfUseId().getTrimmedValue();
            }            
            ServicePointType_Id servicePointTypeID = getSpType();
            toDoCreator.addMessageParameter(servicePointTypeID.getTrimmedValue().concat(COMMA).concat(uom).concat(COMMA).concat(tou));
            toDoCreator.addMessageParameter(formatReading(registerRead.getRegisterReading()));
                
            toDoCreator.addMessageParameter(formatReading(registerReadId.getEntity().getLowLimit()));
            toDoCreator.addMessageParameter(formatReading(registerReadId.getEntity().getHighLimit()));
            
            toDoCreator.create();
        }

		/**
		 * This method derives the service point type of the SP where the meter read is installed.
		 * @return ServicePointType_Id
		 */
        public ServicePointType_Id getSpType() {
 
            // Retrieve all open To Do entries
            StringBuilder queryStr = new StringBuilder("");

            queryStr.append("SELECT DISTINCT SP.SP_TYPE_CD ");
            queryStr.append("FROM CI_CFG_SPMR_VW CFG, CI_SP SP ");
            queryStr.append("WHERE CFG.MTR_CONFIG_ID = :mtrConfigId ");
            queryStr.append(  "AND CFG.INSTALL_DTTM = (SELECT MAX(CFG2.INSTALL_DTTM) ");            
            queryStr.append(                          "FROM CI_CFG_SPMR_VW CFG2 ");
            queryStr.append(                          "WHERE CFG2.MTR_CONFIG_ID = CFG.MTR_CONFIG_ID ");
            queryStr.append(                            "AND CFG2.INSTALL_DTTM <= :mrDttm) ");
            queryStr.append(  "AND SP.SP_ID = CFG.SP_ID ");
            queryStr.append(  "AND SP.SP_STATUS_FLG = 'R' ");
            
            PreparedStatement openToDoEntriesQuery = createPreparedStatement(queryStr.toString(), getClass().getName());

            openToDoEntriesQuery.bindId("mtrConfigId", meterConfigId);
            openToDoEntriesQuery.bindDateTime("mrDttm", readDateTime);

            SQLResultRow sqlRow = openToDoEntriesQuery.firstRow();
            openToDoEntriesQuery.close();
            
            if (notNull(sqlRow)) {
                return new ServicePointType_Id(sqlRow.getString("SP_TYPE_CD").trim());
            } 
            
            return null;
            
        }

		/**
		 * This method formats the supplied read.
		 * @param read
		 * @return ServicePointType_Id
		 */        
        public String formatReading(BigDecimal read) {

            NumberHelperData inputData = NumberHelperData.Factory.newInstance();
            
            inputData.setNumberType(NumberTypeLookup.constants.GENERAL);                       
            
            BigInteger decimalPlaces = registerReadId.getEntity().getRegister().getNumberOfDigitsRight();
            inputData.setNumberToFormat(read.setScale(decimalPlaces.intValue()));

            if (decimalPlaces.compareTo(BigInteger.ZERO) < 0) {
                inputData.setNumberOfDecimalIn(BigInteger.ZERO);
                inputData.setNumberOfDecimalOut(BigInteger.ZERO); 
            } else if (decimalPlaces.compareTo(BigInteger.valueOf(6)) > 0) {
                inputData.setNumberToFormat(read.setScale(6));
                inputData.setNumberOfDecimalIn(BigInteger.valueOf(6));    
                inputData.setNumberOfDecimalOut(BigInteger.valueOf(6)); 
            } else {
                inputData.setNumberOfDecimalIn(decimalPlaces);    
                inputData.setNumberOfDecimalOut(decimalPlaces);     
            } 
            inputData.setIsNumberOnly(Bool.TRUE);    
            inputData.setShouldFormatAsAmount(Bool.FALSE);
            inputData.setShouldRemoveTrailingZeroes(Bool.FALSE);
            inputData.setShouldRetainDecimalPosition(Bool.TRUE);
            
            NumberHelper numberHelper = NumberHelper.Factory.newInstance();
            NumberHelperData outputData = numberHelper.formatNumber(inputData);
            
            return outputData.getFormattedAmount();            
            
        }
        
        private List<ToDoDrillKeyType> getDrillKeyTypes(ToDoType_Id tdTypeID) {
            
            List<ToDoDrillKeyType> returnValue = new ArrayList<ToDoDrillKeyType>();
            
            StringBuilder stringBuilder = new StringBuilder();                  
            stringBuilder.append("SELECT TD_TYPE_CD, SEQ_NUM ");
            stringBuilder.append("FROM CI_TD_DRLKEY_TY ");
            stringBuilder.append("WHERE TD_TYPE_CD = :tdTypeID ");
            
            PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=CmCustomToDoHiLoBatch.getDrillKeyTypes=");
            prepState.bindId("tdTypeID", tdTypeID);
            prepState.setAutoclose(false);
            prepState.execute();
            
            if (prepState.list().size() > 0) {
                
                Iterator<SQLResultRow> iter = prepState.list().iterator();
                
                while (iter.hasNext()) {
                
                    SQLResultRow sqlRow = (SQLResultRow) iter.next();
                    BigInteger seq = (BigInteger) sqlRow.getInteger("SEQ_NUM");
                    ToDoDrillKeyType_Id tdDrillKeyTypeID = new ToDoDrillKeyType_Id(tdTypeID, seq);
                    returnValue.add(tdDrillKeyTypeID.getEntity());
                }                               
            }           
            prepState.close();
            return returnValue;         
        }        

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }
    }
}