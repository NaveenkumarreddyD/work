/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPGCBAX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      Initial Version.    
 * 2016-05-30   MPang       Defect 3444302. Added close connection
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.    
 * 2025-11-14   EQuint      CCB25.4 Upgrade                
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.budgetPlan.algorithm.budgetCalculation;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.admin.budgetPlan.algorithm.budgetCalculation.BudgetCalculationAlgorithmSpot;
import com.splwg.ccb.domain.admin.budgetPlan.entity.BudgetPlan;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpgcbax;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = budgetAdjustmentPercentage, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = billingHistoryPeriod, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = minimumBillHistory, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = subtractCurrentBalance, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (name = roundUpUnit, required = true, type = integer)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = averageBillAmountCharType, type = entity)})
 */
public class CmBudgetCalculationAlgComp_Impl extends
		CmBudgetCalculationAlgComp_Gen implements
		BudgetCalculationAlgorithmSpot {
	
	// hard parameters
	private Money recommendedBudgetAmount;
	private Account account;
	private Date budgetDate;
	private BudgetPlan budgetPlan;
	private ServiceAgreement serviceAgreement;
	
	// soft parameters
	private BigInteger budgetAdjustmentPercentage;
	private BigInteger billingHistoryPeriod;
	private BigInteger minimumBillHistory;
	private Bool subtractCurrentBalance;
	private BigInteger roundUpUnit;
	private CharacteristicType averageBillAmountCharType;

	private Cmpgcbax cmpgcbax;
	//Start Add - MPang - Defect 3444302- 2016-05-30
	private Connection connection;
	//End Add - MPang - Defect 3444302- 2016-05-30
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	
	@Override
	public Money getRecommendedBudgetAmount() {
		return recommendedBudgetAmount;
	}

	@Override
	public void setAccount(Account arg0) {
		account = arg0;
	}

	@Override
	public void setBudgetDate(Date arg0) {
		budgetDate = arg0;
	}

	@Override
	public void setBudgetPlan(BudgetPlan arg0) {
		budgetPlan = arg0;
	}

	@Override
	public void setServiceAgreement(ServiceAgreement arg0) {
		serviceAgreement = arg0;
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		budgetAdjustmentPercentage = getBudgetAdjustmentPercentage();
		billingHistoryPeriod = getBillingHistoryPeriod();
		minimumBillHistory = getMinimumBillHistory();
		subtractCurrentBalance = getSubtractCurrentBalance();
		roundUpUnit = getRoundUpUnit();
		averageBillAmountCharType = getAverageBillAmountCharType();
	}

	@Override
	public void invoke() {
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			if (notNull(account)) {
				cmpgcbax.setInputWrkAcctId(account.getId().getTrimmedValue());
			}else{
				cmpgcbax.setInputWrkAcctId(CobolCode.SPACES.toString());
			}
			if (notNull(serviceAgreement)) {
				cmpgcbax.setGcdrxInputWrkSaId(serviceAgreement.getId().getTrimmedValue());
			}else{
				cmpgcbax.setGcdrxInputWrkSaId(CobolCode.SPACES.toString());
			}
			if (notNull(budgetDate)) {
				cmpgcbax.setInputWrkBudDt(budgetDate.toString());
			}else{
				cmpgcbax.setInputWrkBudDt(CobolCode.SPACES.toString());
			}
			if (notNull(budgetPlan)) {
				cmpgcbax.setInputWrkBudPlanCd(budgetPlan.getId().getTrimmedValue());
			}else{
				cmpgcbax.setInputWrkBudPlanCd(CobolCode.SPACES.toString());
			}

			// soft parameters
			cmpgcbax.setAlgParmVal(1, budgetAdjustmentPercentage.toString()); 
			cmpgcbax.setAlgParmVal(2, billingHistoryPeriod.toString()); 
			cmpgcbax.setAlgParmVal(3, minimumBillHistory.toString());
			
			String subtractCurrentBalanceSw = (subtractCurrentBalance.isTrue()) ? SWITCH_YES : SWITCH_NO;
			cmpgcbax.setAlgParmVal(4, subtractCurrentBalanceSw);
			
			cmpgcbax.setAlgParmVal(5, roundUpUnit.toString());
			
			if (notNull(averageBillAmountCharType)) {
				cmpgcbax.setAlgParmVal(6, averageBillAmountCharType.getId().getTrimmedValue());
			}else{
				cmpgcbax.setAlgParmVal(6, CobolCode.SPACES.toString());
			}
			
			// invoke the main method
		    cmpgcbax.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
		    
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmpgcbax.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmpgcbax.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmpgcbax.getMessageParm(i);
			    			if (notBlank(cmpgcbax.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmpgcbax.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmpgcbax.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmpgcbax.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmpgcbax.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    	recommendedBudgetAmount = new Money(cmpgcbax.getOutputWrkSugBudAmt().toString(), account.getCurrency().getId());
		    }
		    else {
		        //Start Add - MPang - Defect 3444302- 2016-05-30
		        ex.printStackTrace();
		        //End Add - MPang - Defect 3444302- 2016-05-30
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmpgcbax=Session.returnSessionAndCodeToCache(cmpgcbax);
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//			//Start Add - MPang - Defect 3444302- 2016-05-30
//			try {
//			    connection.close();
//			} catch (SQLException e) {
//			    addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
//			}
//			//End Add - MPang - Defect 3444302- 2016-05-30
			// end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}

	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
		FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
		RequestContext context = session.getRequestContext();
		
		// start update - equint - 2025-11-14 - CCB25.4 Upgrade
		session.doWork(new ConnectionWork() {
			
			@Override
			public void execute(Connection connection) throws SQLException {
				try {	
					String username = connection.getMetaData().getUserName();
					String url = connection.getMetaData().getURL();
					
					CobolSession.setLogSessionStartEnd(false);
				    cmpgcbax=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpgcbax.class);
					
					cmpgcbax.getSession().getDbSession().setUpdateConnection(connection);
					cmpgcbax.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
					cmpgcbax.aa100Initialize();
					// set ZSTAT parameters

					cmpgcbax.setProcessDt(getProcessDateTime().getDate().toString());
					cmpgcbax.setProcessDttmSep("-");
					cmpgcbax.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
					
					if (session.isOnlineConnection()) { 
						cmpgcbax.setConnectionFlg(CONNECTION_ONLINE);
					}
					else {
						cmpgcbax.setConnectionFlg(CONNECTION_BATCH);
					}
					
					cmpgcbax.setUserId(context.getUserId());
					cmpgcbax.setZstatLanguageCd(context.getLanguageCode());
			        
			        if (context.ignoreWarnings()) {
			        	cmpgcbax.setIgnoreWarningSw(SWITCH_YES);
			        }
			        else {
			        	cmpgcbax.setIgnoreWarningSw(SWITCH_NO);
			        }
			        
			        if (session.getBatchInstanceId() != null) {
			        	cmpgcbax.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
			        	
					} else {
						cmpgcbax.setSchedulerId(new BigDecimal(0).toBigDecimal());
					}
			        
			        cmpgcbax.setAppSvcId(context.getSecurityServiceIdContext());
			        
			        DatabaseHelper dbHelper = session.getDatabaseHelper();
			        cmpgcbax.setDbMode(dbHelper.getCobolDBMode());
			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
			        //cmpgcbax.setSplHighValue(cmpgcbax.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
			        //cmpgcbax.setSplLowValue(cmpgcbax.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
			        
			        cmpgcbax.setSplHighValue(cmpgcbax.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
			        cmpgcbax.setSplLowValue(cmpgcbax.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
			        
			        cmpgcbax.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
			        
			        cmpgcbax.setLkExpiryDt(Date.MAX.toString());
			        
			        cmpgcbax.setProgramStatus(" ");
			        
			        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
			        cmpgcbax.setCallSeq(";");
			        cmpgcbax.setMessageAreaProgramName("CMPGCBAX");
			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
			        
			        if (context.getRandomGeneratorSeedSet().isTrue()) {
			        	cmpgcbax.setRandomGenSeedSw(SWITCH_YES);
			        	cmpgcbax.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
			        	cmpgcbax.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
			        	cmpgcbax.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
			        	cmpgcbax.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
			        }
			        else {
			        	cmpgcbax.setRandomGenSeedSw(SWITCH_NO);
			        }
			        
			        if (context.traceStandardOut()) { 
			        	cmpgcbax.setTrcStdoutSw(SWITCH_YES);
			        }
			        else {
			        	cmpgcbax.setTrcStdoutSw(SWITCH_NO);
			        }
			        
			        if (context.traceProgramStart()) { 
			        	cmpgcbax.setTrcProgStartSw(SWITCH_YES);
			        }
			        else {
			        	cmpgcbax.setTrcProgStartSw(SWITCH_NO);
			        }
			        
			        if (context.traceProgramExit()) { 
			        	cmpgcbax.setTrcProgExitSw(SWITCH_YES);
			        }
			        else {
			        	cmpgcbax.setTrcProgExitSw(SWITCH_NO);
			        }
			        
			        if (context.traceSQL()) { 
			        	cmpgcbax.setTrcExecSqlSw(SWITCH_YES);
			        }
			        else {
			        	cmpgcbax.setTrcExecSqlSw(SWITCH_NO);
			        }
			        
			        // Set ZMSGN parms
			        BigInteger messageSequence = session.getMessageSequence();
			        if (notNull(messageSequence)) {
			        	cmpgcbax.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
			        }
			        else {
			        	cmpgcbax.setMessageSeq(new BigDecimal(0).toBigDecimal());
			        }
				}
				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		 
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//        //Start Change - MPang - Defect 3444302- 2016-05-30
//        //Connection connection = implementor.getConnectionProvider().getConnection();
//        connection = implementor.getConnectionProvider().getConnection();
//        //End Change - MPang - Defect 3444302- 2016-05-30
//        
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmpgcbax=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpgcbax.class);
//		
//		cmpgcbax.getSession().getDbSession().setUpdateConnection(connection);
//		cmpgcbax.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		cmpgcbax.aa100Initialize();
//		// set ZSTAT parameters
//
//		cmpgcbax.setProcessDt(getProcessDateTime().getDate().toString());
//		cmpgcbax.setProcessDttmSep("-");
//		cmpgcbax.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmpgcbax.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmpgcbax.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmpgcbax.setUserId(context.getUserId());
//		cmpgcbax.setZstatLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmpgcbax.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmpgcbax.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmpgcbax.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmpgcbax.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmpgcbax.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmpgcbax.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmpgcbax.setSplHighValue(cmpgcbax.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmpgcbax.setSplLowValue(cmpgcbax.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmpgcbax.setSplHighValue(cmpgcbax.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmpgcbax.setSplLowValue(cmpgcbax.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmpgcbax.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmpgcbax.setLkExpiryDt(Date.MAX.toString());
//        
//        cmpgcbax.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmpgcbax.setCallSeq(";");
//        cmpgcbax.setMessageAreaProgramName("CMPGCBAX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmpgcbax.setRandomGenSeedSw(SWITCH_YES);
//        	cmpgcbax.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmpgcbax.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmpgcbax.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmpgcbax.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmpgcbax.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmpgcbax.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmpgcbax.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmpgcbax.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmpgcbax.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmpgcbax.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmpgcbax.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmpgcbax.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmpgcbax.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmpgcbax.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmpgcbax.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }
		
		// end update - equint - 2025-11-14 - CCB25.4 Upgrade

	}

}
