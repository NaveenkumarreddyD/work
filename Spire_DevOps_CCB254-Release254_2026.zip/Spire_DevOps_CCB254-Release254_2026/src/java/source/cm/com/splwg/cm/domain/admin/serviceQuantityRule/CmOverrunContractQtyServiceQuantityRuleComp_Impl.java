/* 
 *********************************************************************** 
 *                 Confidentiality Information: 
 * 
 * This module is the confidential and proprietary information of 
 * Oracle Corporation; it is not to be copied, reproduced, or 
 * transmitted in any form, by any means, in whole or in part, 
 * nor is it to be used for any purpose other than that for which 
 * it is expressly provided without the written permission of 
 * Oracle Corporation. 
 * 
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * The algorithm will calculate a Service Agreement's overrun of a 
 * daily Contract Quantity effective during the Bill Period.
 * 
 * 
 *********************************************************************** 
 * 
 * 
 * CHANGE HISTORY: 
 * 
 * Date:       by:       Reason: 
 * 2013-02-04  AGambo    NA0089. Initial Version. 
 * 2013-02-13  AGambo    TIR_NA0089. Exclude Bill Segment Period End
 * 						 Date in computation. Set parameter 2 as SQI
 * 2013-02-20  CVB       Added defaulting if computation yields 0. Added
 *                       error validation if no Bill Segment SQ found.
 * 2013-02-22  CVB       Remove functionality to only create Bseg SQ
 *                       if computed value is not zero.  
 * 2016-01-26   MPang	 Updated for CCB v2.4 compilation.                                         
 *********************************************************************** 
 */

package com.splwg.cm.domain.admin.serviceQuantityRule;

import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.GenericBusinessComponent;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.ccb.api.lookup.ServiceQuantityLookup;
//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.contractQuantityType.ContractQuantityType;
import com.splwg.ccb.domain.admin.contractQuantityType.ContractQuantityType_Id;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.admin.serviceQuantityRule.ServiceQuantityRuleComponent;
import com.splwg.ccb.domain.admin.timeOfUse.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure_Id;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentItemData;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentReadData;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantity;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantityData;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantity_DTO;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantity_Id;
import com.splwg.ccb.domain.billing.billSegment.BillSegment_Id;
import com.splwg.ccb.domain.common.characteristic.CharacteristicData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.rate.ApplyRateData;*/
import com.splwg.ccb.domain.admin.contractQuantityType.entity.ContractQuantityType;
import com.splwg.ccb.domain.admin.contractQuantityType.entity.ContractQuantityType_Id;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.admin.data.ServiceQuantityRuleComponent;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.billing.data.BillSegmentItemData;
import com.splwg.ccb.domain.billing.data.BillSegmentReadData;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity;
import com.splwg.ccb.domain.billing.data.BillSegmentServiceQuantityData;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity_DTO;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.common.data.CharacteristicData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.rate.data.ApplyRateData;
//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author AAGAMBOA
 *
 @BusinessComponent (customizationCallable = true)
 */
public class CmOverrunContractQtyServiceQuantityRuleComp_Impl 
		extends GenericBusinessComponent 
		implements CmOverrunContractQtyServiceQuantityRuleComp, ServiceQuantityRuleComponent {
    // Constants
    private static final String ALG_DESC = "Overrun Contract Quantity";
    private static final String PARM1_DESC = "Contract Quantity Type";
    private static final String PARM2_DESC = "Contract Quantity Maximum SQI";
    private static final String PARM3_DESC = "Default SQ Value";

    // Hard Parameters
    private ApplyRateData applyRateData;
    private List<BillSegmentItemData> billSegmentItemData;
    private List<BillSegmentReadData> billSegmentReadData;
    private List<BillSegmentServiceQuantityData> billSegmentServiceQuantityData;
    private List<CharacteristicData> characteristicData;
    private String parameter1;
    private String parameter2;
    private String parameter3;
    private String parameter4;
    private String parameter5;
    private String parameter6;
    private String parameter7;
    private String parameter8;
    private String parameter9;
    private String parameter10;
    private ServiceQuantityIdentifier_Id serviceQuantityIdentifierId;
    private ServiceQuantityLookup serviceQuantityLookup;
    private Bool shouldCreateBillingError;
    private TimeOfUse_Id timeOfUseId;
    private UnitOfMeasure_Id unitOfMeasureId;

    // Program variables
    private ContractQuantityType contractQuantityType;
    /*
     * Start Change - AGambo - 2013-02-13 - TIR_NA0089
     */
    //private ContractQuantityType contractQuantityMaximumSqi;
    private ServiceQuantityIdentifier contractQuantityMaximumSqi;
    /*
     * End Change - AGambo - 2013-02-13 - TIR_NA0089
     */

    private BigDecimal defaultSQValue = BigDecimal.ZERO;

    private ServiceAgreement serviceAgreement;
    private Bool isErrorEncountered;

    public ApplyRateData getApplyRateData() {
        return applyRateData;
    }

    public List<BillSegmentItemData> getBillSegmentItemData() {
        return billSegmentItemData;
    }

    public List<BillSegmentReadData> getBillSegmentReadData() {
        return billSegmentReadData;
    }

    public List<BillSegmentServiceQuantityData> getBillSegmentServiceQuantityData() {
        return billSegmentServiceQuantityData;
    }

    public List<CharacteristicData> getCharacteristicData() {
        return characteristicData;
    }

    public String getSQRuleParameter1() {
        return parameter1;
    }

    public String getSQRuleParameter10() {
        return parameter10;
    }

    public String getSQRuleParameter2() {
        return parameter2;
    }

    public String getSQRuleParameter3() {
        return parameter3;
    }

    public String getSQRuleParameter4() {
        return parameter4;
    }

    public String getSQRuleParameter5() {
        return parameter5;
    }

    public String getSQRuleParameter6() {
        return parameter6;
    }

    public String getSQRuleParameter7() {
        return parameter7;
    }

    public String getSQRuleParameter8() {
        return parameter8;
    }

    public String getSQRuleParameter9() {
        return parameter9;
    }

    public ServiceQuantityIdentifier_Id getServiceQuantityIdentifierId() {
        return serviceQuantityIdentifierId;
    }

    public ServiceQuantityLookup getServiceQuantityLookup() {
        return serviceQuantityLookup;
    }

    public Bool getShouldCreateBillingError() {
        return shouldCreateBillingError;
    }

    public TimeOfUse_Id getTimeOfUseId() {
        return timeOfUseId;
    }

    public UnitOfMeasure_Id getUnitOfMeasureId() {
        return unitOfMeasureId;
    }

    public void setApplyRateData(ApplyRateData applyRateData) {
        this.applyRateData = applyRateData;
    }

    public void setBillSegmentItemData(List<BillSegmentItemData> billSegmentItemData) {
        this.billSegmentItemData = billSegmentItemData;
    }

    public void setBillSegmentReadData(List<BillSegmentReadData> billSegmentReadData) {
        this.billSegmentReadData = billSegmentReadData;
    }

    public void setBillSegmentServiceQuantityData(List<BillSegmentServiceQuantityData> billSegmentServiceQuantityData) {
        this.billSegmentServiceQuantityData = billSegmentServiceQuantityData;
    }

    public void setCharacteristicData(List<CharacteristicData> characteristicData) {
        this.characteristicData = characteristicData;
    }

    public void setSQRuleParameter1(String parameter1) {
        this.parameter1 = parameter1;
    }

    public void setSQRuleParameter10(String parameter10) {
        this.parameter10 = parameter10;
    }

    public void setSQRuleParameter2(String parameter2) {
        this.parameter2 = parameter2;
    }

    public void setSQRuleParameter3(String parameter3) {
        this.parameter3 = parameter3;
    }

    public void setSQRuleParameter4(String parameter4) {
        this.parameter4 = parameter4;
    }

    public void setSQRuleParameter5(String parameter5) {
        this.parameter5 = parameter5;
    }

    public void setSQRuleParameter6(String parameter6) {
        this.parameter6 = parameter6;
    }

    public void setSQRuleParameter7(String parameter7) {
        this.parameter7 = parameter7;
    }

    public void setSQRuleParameter8(String parameter8) {
        this.parameter8 = parameter8;
    }

    public void setSQRuleParameter9(String parameter9) {
        this.parameter9 = parameter9;
    }

    public void setServiceQuantityIdentifierId(ServiceQuantityIdentifier_Id serviceQuantityIdentifierId) {
        this.serviceQuantityIdentifierId = serviceQuantityIdentifierId;
    }

    public void setServiceQuantityLookup(ServiceQuantityLookup serviceQuantityLookup) {
        this.serviceQuantityLookup = serviceQuantityLookup;
    }

    public void setShouldCreateBillingError(Bool shouldCreateBillingError) {
        this.shouldCreateBillingError = shouldCreateBillingError;
    }

    public void setTimeOfUseId(TimeOfUse_Id timeOfUseId) {
        this.timeOfUseId = timeOfUseId;
    }

    public void setUnitOfMeasureId(UnitOfMeasure_Id unitOfMeasureId) {
        this.unitOfMeasureId = unitOfMeasureId;
    }

    public void invoke() {
        isErrorEncountered = Bool.FALSE;

        // Retrieve and validate parameters
        retrieveAndValidateParameters();

        // Perform processing rules
        if(isErrorEncountered.isFalse()) {
            performProcessingRules();
        }
    }

    /**
     * This method will retrieve and validate parameters
     *
     */
    private void retrieveAndValidateParameters() {
        // Check if SQ Rule Algorithm Parameter 1 is not empty
        if (isBlankOrNull(parameter1)) {
            if (shouldCreateBillingError.isTrue()) {
                addError(CustomMessageRepositoryMDC.na0089c_ParameterMissing(ALG_DESC, PARM1_DESC));
            }
            else {
                isErrorEncountered = Bool.TRUE;
                return;
            }
        }

        // Check if SQ Rule Algorithm Parameter 1 is a valid Contract Quantity Type
        ContractQuantityType_Id contractQuantityTypeId = new ContractQuantityType_Id(parameter1);
        contractQuantityType = contractQuantityTypeId.getEntity();
        if (isNull(contractQuantityType)) {
            if (shouldCreateBillingError.isTrue()) {
                addError(CustomMessageRepositoryMDC.na0089c_ContractQuantityInvalid(ALG_DESC, parameter1));
            }
            else {
                isErrorEncountered = Bool.TRUE;
                return;
            }
        }

        // Check if SQ Rule Algorithm Parameter 2 is not empty
        if (isBlankOrNull(parameter2)) {
            if (shouldCreateBillingError.isTrue()) {
                addError(CustomMessageRepositoryMDC.na0089c_ParameterMissing(ALG_DESC, PARM2_DESC));
            }
            else {
                isErrorEncountered = Bool.TRUE;
                return;
            }
        }

        /*
         * Start Change - AGambo - 2013-02-13 - TIR_NA0089
         */
        //// Check if SQ Rule Algorithm Parameter 2 is a valid Contract Quantity Type 
        //ContractQuantityType_Id contractQuantityMaximumSqiId = new ContractQuantityType_Id(parameter2);
        // Check if SQ Rule Algorithm Parameter 2 is a valid Service Quantity Identifier
        ServiceQuantityIdentifier_Id contractQuantityMaximumSqiId = new ServiceQuantityIdentifier_Id(parameter2);
        /*
         * End Change - AGambo - 2013-02-13 - TIR_NA0089
         */
        contractQuantityMaximumSqi = contractQuantityMaximumSqiId.getEntity();
        if (isNull(contractQuantityMaximumSqi)) {
            if (shouldCreateBillingError.isTrue()) {
                addError(CustomMessageRepositoryMDC.na0089c_ContractQuantityInvalid(ALG_DESC, parameter2));
            }
            else {
                isErrorEncountered = Bool.TRUE;
                return;
            }
        }

        // Check if SQ Rule Algorithm Parameter 3 is not empty
        if (isBlankOrNull(parameter3)) {
            if (shouldCreateBillingError.isTrue()) {
                addError(CustomMessageRepositoryMDC.na0089c_ParameterMissing(ALG_DESC, PARM3_DESC));
            }
            else {
                isErrorEncountered = Bool.TRUE;
                return;
            }
        }
        // Check if SQ Rule Algorithm Parameter 3 is numeric decimal
        try {
            defaultSQValue = new BigDecimal(parameter3.trim());

        }
        catch(NumberFormatException e) {
            if (shouldCreateBillingError.isTrue()) {
                addError(CustomMessageRepositoryMDC.na0089c_ValueNotNumeric(ALG_DESC, PARM3_DESC, parameter3));
            }
            else {
                isErrorEncountered = Bool.TRUE;
                return;
            }

        }
    }

    /**
     * This method will perform algorithm processing rules
     *
     */
    private void performProcessingRules() {
        Date startDate = applyRateData.getBillSegmentPeriodStart();
        Date endDate = applyRateData.getBillSegmentPeriodEnd();
        serviceAgreement = applyRateData.getServiceAgreement();

        boolean isBsegSQRetrieved = false;

        /*
         * Start Add - AGambo - 2013-02-13 - TIR_NA0089
         */
        // Retrieve Maximum Contract Quantity SQI 
        BigDecimal cntQtyAmt2 = BigDecimal.ZERO;
        Iterator<BillSegmentServiceQuantityData> itr = billSegmentServiceQuantityData.iterator();
        while(itr.hasNext()) {
            BillSegmentServiceQuantityData data = itr.next();
            ServiceQuantityIdentifier sqi = data.getBillSegmentServiceQuantityDto().getId().fetchServiceQuantityIdentifier();
            if(contractQuantityMaximumSqi.equals(sqi)) {
                cntQtyAmt2 = data.getBillSegmentServiceQuantityDto().getBillableServiceQuantity();
                isBsegSQRetrieved = true;
                break;
            }
        }
        /*
         * End Add - AGambo - 2013-02-13 - TIR_NA0089
         */

        if (!isBsegSQRetrieved) {
            if (shouldCreateBillingError.isTrue()) {
                addError(CustomMessageRepositoryMDC.na0089c_SQINotFound(parameter2));
            }
            else {
                isErrorEncountered = Bool.TRUE;
                return;
            }
        }

        Date tempDate = startDate;
        Bool stopFlag = Bool.FALSE;
        Bool saFound = Bool.FALSE;
        BigDecimal totalAmount = BigDecimal.ZERO;

        while (stopFlag.isFalse()) {
            BigDecimal cntQtyAmt1 = BigDecimal.ZERO;
            /*
             * Start Delete - AGambo - 2013-02-13 - TIR_NA0089
             */
            //BigDecimal cntQtyAmt2 = BigDecimal.ZERO;
            /*
             * End Delete - AGambo - 2013-02-13 - TIR_NA0089
             */

            // Retrieve the effective Contract Quantity for the day 
            Query contractQuantity1Query = getContractQuantity(tempDate, contractQuantityType); 
            if (!contractQuantity1Query.list().isEmpty()) {
                saFound = Bool.TRUE;

                QueryResultRow result1 = (QueryResultRow) contractQuantity1Query.firstRow();
                cntQtyAmt1 = result1.getBigDecimal("contractQuantity");
            }

            /*
             * Start Delete - AGambo - 2013-02-13 - TIR_NA0089
             */
            //// Retrieve the effective Contract Quantity for the day 
            //Query contractQuantity2Query = getContractQuantity(tempDate, contractQuantityMaximumSqi); 
            //if (!contractQuantity2Query.list().isEmpty()) {
            //	QueryResultRow result2 = (QueryResultRow) contractQuantity2Query.firstRow();
            //	cntQtyAmt2 = result2.getBigDecimal("contractQuantity");
            //}
            /*
             * End Delete - AGambo - 2013-02-13 - TIR_NA0089
             */

            if(cntQtyAmt1.compareTo(cntQtyAmt2) > 0) {
                BigDecimal cntQtyAmt = cntQtyAmt1.subtract(cntQtyAmt2);
                totalAmount = totalAmount.add(cntQtyAmt);
            }

            tempDate = tempDate.addDays(1);

            /*
             * Start Change - AGambo - 2013-02-13 - TIR_NA0089
             */
            //if (tempDate.isAfter(endDate)) {
            if (tempDate.isSameOrAfter(endDate)) {
                /*
                 * End Change - AGambo - 2013-02-13 - TIR_NA0089
                 */
                stopFlag = Bool.TRUE;
            }
        }

        if (saFound.isFalse()) {
            if (shouldCreateBillingError.isTrue()) {
                addError(CustomMessageRepositoryMDC.na0089c_ContractQuantityMissing(serviceAgreement.getId().getTrimmedValue(), 
                        contractQuantityType.getId().getTrimmedValue(), startDate.toString(), endDate.toString()));
            }
            else {
                isErrorEncountered = Bool.TRUE;
                return;
            }
        }

        if(totalAmount.equals(BigDecimal.ZERO)) {

            totalAmount = defaultSQValue;

        }
        // Add a new entry using the totalAmount as the Initial SQ and Bill SQ

        /*
         * Start Change - CVB - 2013-02-13 
         */

        // if(totalAmount.compareTo(BigDecimal.ZERO) > 0) {

        /*
         * End Change - AGambo - 2013-02-13
         */

        BillSegmentServiceQuantity_Id bsegSQId = new BillSegmentServiceQuantity_Id(unitOfMeasureId, timeOfUseId, serviceQuantityIdentifierId, BillSegment_Id.NULL);

        BillSegmentServiceQuantity_DTO billSegmentServiceQuantityDto = createDTO(BillSegmentServiceQuantity.class);
        billSegmentServiceQuantityDto.setInitialServiceQuantity(totalAmount);
        billSegmentServiceQuantityDto.setBillableServiceQuantity(totalAmount);
        billSegmentServiceQuantityDto.setId(bsegSQId);

        BillSegmentServiceQuantityData bsSqData = BillSegmentServiceQuantityData.Factory.newInstance();
        bsSqData.setBillSegmentServiceQuantityDto(billSegmentServiceQuantityDto);

        billSegmentServiceQuantityData.add(bsSqData);

        /*
         * Start Change - CVB - 2013-02-13 
         */

        // }

        /*
         * End Change - CVB - 2013-02-13 
         */
    }

    /**
     * This method will retrieve contract quantity
     * @param tempDate
     * @param cntQtyType
     * @return query
     */
    private Query getContractQuantity(Date tempDate, ContractQuantityType cntQtyType) {
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append(" FROM ServiceAgreementContractQuantity sacq ");
        strBuilder.append(" WHERE sacq.id.serviceAgreement = :serviceAgreement ");
        strBuilder.append(" AND sacq.id.contractQuantityType = :contractQuantityType ");
        strBuilder.append(" AND sacq.id.effectiveDate <= :effectiveDate ");
        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //Query query = createQuery(strBuilder.toString());
        Query query = createQuery(strBuilder.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation

        query.addResult("contractQuantity", "sacq.contractQuantity");
        query.addResult("effectiveDate", "sacq.id.effectiveDate");

        query.bindEntity("serviceAgreement", serviceAgreement);
        query.bindEntity("contractQuantityType", cntQtyType);
        query.bindDate("effectiveDate", tempDate);

        query.orderBy("effectiveDate", Query.DESCENDING);

        return query;
    }

}
