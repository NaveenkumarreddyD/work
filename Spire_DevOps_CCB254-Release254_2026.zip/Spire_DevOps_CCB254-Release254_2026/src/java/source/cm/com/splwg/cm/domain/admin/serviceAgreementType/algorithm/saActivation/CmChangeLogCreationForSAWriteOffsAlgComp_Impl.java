/**************************************************************************
* Program Name: CmChangeLogCreationForSAWriteOffsAlgComp_Impl
* Program Title: CmChangeLogCreationForSAWriteOffsAlgComp_Impl
* Author: LBallo
* Creation Date: 2017-07-05 
* Purpose: This Algorithm's purpose in the Write Off Transfer Process is 
* 	to check the Main Person on an Account starting service and search 
* 	for a matching Person ID in the Custom Write Off Table CM_WO_XFERS. 
* 	A change log record will be created if the Person ID is found 
* 	for the CM_WOXFER batch process to attempt the transfer.
* Functional Spec: SA-68623.2
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:         Date:         Description:
 * ----------------------------------------------------------------------------------------------
 * SA-68623.2         Louis Ballon    2017-07-05    Initial Version
 ************************************************************************************************/


package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.saActivation;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControl;
import com.splwg.base.domain.batch.batchControl.BatchControl_Id;
import com.splwg.base.domain.database.table.Table_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saActivation.SaTypeSaActivationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.domain.common.customBusinessComponent.ChangeLogTable_DTO;
import com.splwg.cm.domain.common.customBusinessComponent.ChangeLogTable_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author LBallo
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = batchControl, name = CHANGE_LOG_BATCH_CD, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = CHANGE_LOG_TYPE, required = true, type = string)})
 */
public class CmChangeLogCreationForSAWriteOffsAlgComp_Impl extends 
		CmChangeLogCreationForSAWriteOffsAlgComp_Gen implements
		SaTypeSaActivationAlgorithmSpot {
	
	// Constant Variables
	private static final String CM_WO_XFERS = "CM_WO_XFERS";
	
	// Work Variables
	private ServiceAgreement sa;
	
	public void setServiceAgreement(ServiceAgreement serviceAgreement) {
		this.sa = serviceAgreement;
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

		String changeLogTypeStr = getCHANGE_LOG_TYPE();
		
		if(changeLogTypeStr.length() > 4) {
			addError(CustomMessageRepository.SA_68623_2_InvalidChangeLogTypeParameter());
		}
		
		super.extraSoftParameterValidations(forAlgorithmValidation);
	}
	
	@Override
	public void invoke() {
		// Get Main Person of Service Agreement's Account
		Account account = sa.getAccount();
		Person mainPerson = account.getMainPerson();
		
		//Get all the SAs in CM_WO_XFER with the Person
		for(SQLResultRow row : retrieveRecordsFromWoXferTableWithPerson(mainPerson)) {
			
			String saIdFromWoXferTableStr = row.getString("WO_SA_ID");
			String accountIdFromWoXferTableStr = row.getString("WO_ACCT_ID");
			
			BatchControl batchControl = getCHANGE_LOG_BATCH_CD();
			BatchControl_Id batchControldId = batchControl.getId();
			Table_Id tableId = new Table_Id(CM_WO_XFERS);
			
			// Check for existing records in CI_CHG_LOG with the same batch code and SA Id
			if(isRecordWithSameBatchAndPKVal1Exist(batchControldId,sa.getId()).isFalse()) {
				
				// Generate a unique Change Log Table Id
				ChangeLogTable_Id changeLogId = null;
				Bool isUniqueId = Bool.FALSE;
				while(isUniqueId.isFalse()) {
					
					BigInteger genId = generateChangeLogId();
					
					if(isUniqueChangeLogId(genId).isTrue()) {
						changeLogId = new ChangeLogTable_Id(genId);
						isUniqueId = Bool.TRUE;
						break;
					}
				}
				
				// Create a Change Log record
				ChangeLogTable_DTO changeLogDto = new ChangeLogTable_DTO();
				changeLogDto.setId(changeLogId);
				changeLogDto.setBatchControlId(batchControl.getId());
				changeLogDto.setBatchNumber(batchControl.getNextBatchNumber());
				changeLogDto.setChangeDateTime(getProcessDateTime());
				changeLogDto.setChangeType(getCHANGE_LOG_TYPE());
				changeLogDto.setTableId(tableId);
				changeLogDto.setPkVal1(saIdFromWoXferTableStr.trim());
				changeLogDto.setPkVal2(accountIdFromWoXferTableStr.trim());
				
				changeLogDto.newEntity();
			}
		}
	}

	private List<SQLResultRow> retrieveRecordsFromWoXferTableWithPerson(Person person) {
		
		StringBuilder retrieveRecordsFromWoXferTableWithPersonStr = new StringBuilder();
		
		retrieveRecordsFromWoXferTableWithPersonStr.append("SELECT ");
		retrieveRecordsFromWoXferTableWithPersonStr.append(  "DISTINCT ");
		retrieveRecordsFromWoXferTableWithPersonStr.append(  "A.WO_SA_ID, ");
		retrieveRecordsFromWoXferTableWithPersonStr.append(  "A.WO_ACCT_ID ");
		retrieveRecordsFromWoXferTableWithPersonStr.append("FROM ");
		retrieveRecordsFromWoXferTableWithPersonStr.append(  "CM_WO_XFERS A ");
		retrieveRecordsFromWoXferTableWithPersonStr.append("WHERE ");
		retrieveRecordsFromWoXferTableWithPersonStr.append(  "A.MAIN_PER_ID = :personId ");
		retrieveRecordsFromWoXferTableWithPersonStr.append(  "OR A.FR_PER_ID1 = :personId ");
		retrieveRecordsFromWoXferTableWithPersonStr.append(  "OR A.FR_PER_ID2 = :personId ");
		retrieveRecordsFromWoXferTableWithPersonStr.append(  "OR A.FR_PER_ID3 = :personId ");
		retrieveRecordsFromWoXferTableWithPersonStr.append(  "OR A.FR_PER_ID4 = :personId ");
		retrieveRecordsFromWoXferTableWithPersonStr.append(  "OR A.FR_PER_ID5 = :personId ");
		
		PreparedStatement retrieveRecordsFromWoXferTableWithPerson = createPreparedStatement(retrieveRecordsFromWoXferTableWithPersonStr.toString(), getClass().getName());
		retrieveRecordsFromWoXferTableWithPerson.bindId("personId", person.getId());
		
		List<SQLResultRow> rowList = new ArrayList<SQLResultRow>();
		
		for(SQLResultRow row : retrieveRecordsFromWoXferTableWithPerson.list()) {
			rowList.add(row);
		}
		
		retrieveRecordsFromWoXferTableWithPerson.close();
		return rowList;

	}
	
	private Bool isRecordWithSameBatchAndPKVal1Exist(BatchControl_Id batchId, ServiceAgreement_Id saId) {
		
		StringBuilder isRecordWithSameBatchAndPKVal1ExistStr = new StringBuilder();
		
		isRecordWithSameBatchAndPKVal1ExistStr.append("SELECT ");
		isRecordWithSameBatchAndPKVal1ExistStr.append(  "A.CHG_LOG_ID ");
		isRecordWithSameBatchAndPKVal1ExistStr.append("FROM ");
		isRecordWithSameBatchAndPKVal1ExistStr.append(  "CI_CHG_LOG A ");
		isRecordWithSameBatchAndPKVal1ExistStr.append("WHERE ");
		isRecordWithSameBatchAndPKVal1ExistStr.append(  "A.BATCH_CD = :batchId ");
		isRecordWithSameBatchAndPKVal1ExistStr.append(  "AND A.PK_VAL1 = :saId ");
		
		PreparedStatement isRecordWithSameBatchAndPKVal1Exist = createPreparedStatement(isRecordWithSameBatchAndPKVal1ExistStr.toString(), getClass().getName());
		isRecordWithSameBatchAndPKVal1Exist.bindId("batchId", batchId);
		isRecordWithSameBatchAndPKVal1Exist.bindId("saId", saId);
		
		SQLResultRow row = isRecordWithSameBatchAndPKVal1Exist.firstRow();
		isRecordWithSameBatchAndPKVal1Exist.close();
		
		if(notNull(row)) {
			return Bool.TRUE;
		} else {
			return Bool.FALSE;
		}
	}
	
	private BigInteger generateChangeLogId() {

		PreparedStatement createId = createPreparedStatement("SELECT " +
				"	(TO_NUMBER(ROUND(DBMS_RANDOM.VALUE(1,99999999999999),0))) AS CHG_LOG_ID " +
				" FROM " +
				"	DUAL ", getClass().getName());

		SQLResultRow row = createId.firstRow();
		BigInteger intId = row.getInteger("CHG_LOG_ID");

		createId.close();

		return intId;
	}

	private Bool isUniqueChangeLogId(BigInteger changeLogId) {

		Bool isUnique = Bool.FALSE;

		PreparedStatement checkId = createPreparedStatement("SELECT " +
				"	CHG_LOG_ID " +
				" FROM " +
				"	CI_CHG_LOG " +
				" WHERE " +
				"	CHG_LOG_ID = :changeLogId", getClass().getName());

		checkId.bindId("changeLogId", new ChangeLogTable_Id(changeLogId));

		List<SQLResultRow> checkIdList = checkId.list();

		if(notNull(checkIdList) || !checkIdList.isEmpty()) {
			isUnique = Bool.TRUE;
		}

		checkId.close();

		return isUnique;
	}
	
}
