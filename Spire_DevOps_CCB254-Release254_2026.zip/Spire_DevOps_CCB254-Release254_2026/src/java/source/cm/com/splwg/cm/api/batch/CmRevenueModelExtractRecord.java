/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Revenue Model Extract Record
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-04-22   JPunza  NI0034.1 Initial Version.
 *************************************************************************/

package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmRevenueModelExtractRecord 
        extends ColumnDelimitedRecord {
    
    private final static int TOTAL_COLUMNS = 30;
    private final String COMMA = ",";
    private final String BLANK = "";
    private final String SPACE = " ";
    private final String QUOTE_MARK = "\"";
    private final String ZERO = "0";

    public CmRevenueModelExtractRecord() {
        
        super(TOTAL_COLUMNS);        
        
        // Initialize the extract fields
        setRevenueRateClass(null);
        setFercNumber(null);
        setNumberOfCustomersBilled(ZERO);
        setNumberOfBills(ZERO);
        setBlock1WinterTherms(ZERO);
        setBlock1SummerTherms(ZERO);
        setBlock2WinterTherms(ZERO);
        setBlock2SummerTherms(ZERO);
        setDemandThermsBilled(ZERO);
        setAuthorizedOverrunTherms(ZERO);
        setUnauthorizedOverrunTherms(ZERO);
        setBlock1WinterRevenueBilled(ZERO);
        setBlock1SummerRevenueBilled(ZERO);
        setBlock2WinterRevenueBilled(ZERO);
        setBlock2SummerRevenueBilled(ZERO);
        setCustomerChargeBilled(ZERO);
        setDemandChargeRevenue(ZERO);
        setISRSRevenueBilled(ZERO);
        setAuthorizedOverrunRevenue(ZERO);
        setUnauthorizedOverrunRevenue(ZERO);
        setPGARevenueBilled(ZERO);
        setACARevenueBilled(ZERO);
        setGRTInRevenue(ZERO);
        setIARevenue(ZERO);
        setPrincipalRefund(ZERO);
        setLacledeIntRefund(ZERO);
        setGRTRefund(ZERO);
        setStateSalesTax(ZERO);
        setCitySalesTax(ZERO);
        setTransportationStorageRevenue(ZERO);
    }
    
    private String formatString(String text) {
        
        if (StringUtilities.isEmptyOrNull(text)) {
            text = BLANK;
        }
        text = QUOTE_MARK + text.replaceAll(COMMA, SPACE).trim() + QUOTE_MARK + COMMA;
        
        return text;
    }
    
    public void setRevenueRateClass(String str) {
        
        str = formatString(str);
        rightPadColumn(1, str.length(), str);
    }
    
    public void setFercNumber(String str) {
        
        str = formatString(str);
        rightPadColumn(2, str.length(), str);
    }
    
    public void setNumberOfCustomersBilled(String str) {
        
        str = formatString(str);
        rightPadColumn(3, str.length(), str);
    }
    
    public void setNumberOfBills(String str) {
        
        str = formatString(str);
        rightPadColumn(4, str.length(), str);
    }
    
    public void setBlock1WinterTherms(String str) {
        
        str = formatString(str);
        rightPadColumn(5, str.length(), str);
    }
    
    public void setBlock1SummerTherms(String str) {
        
        str = formatString(str);
        rightPadColumn(6, str.length(), str);
    }
    
    public void setBlock2WinterTherms(String str) {
        
        str = formatString(str);
        rightPadColumn(7, str.length(), str);
    }
    
    public void setBlock2SummerTherms(String str) {
        
        str = formatString(str);
        rightPadColumn(8, str.length(), str);
    }
    
    public void setDemandThermsBilled(String str) {
        
        str = formatString(str);
        rightPadColumn(9, str.length(), str);
    }
    
    public void setAuthorizedOverrunTherms(String str) {
        
        str = formatString(str);
        rightPadColumn(10, str.length(), str);
    }
    
    public void setUnauthorizedOverrunTherms(String str) {
        
        str = formatString(str);
        rightPadColumn(11, str.length(), str);
    }
    
    public void setBlock1WinterRevenueBilled(String str) {
        
        str = formatString(str);
        rightPadColumn(12, str.length(), str);
    }
    
    public void setBlock1SummerRevenueBilled(String str) {
        
        str = formatString(str);
        rightPadColumn(13, str.length(), str);
    }
    
    public void setBlock2WinterRevenueBilled(String str) {
        
        str = formatString(str);
        rightPadColumn(14, str.length(), str);
    }
    
    public void setBlock2SummerRevenueBilled(String str) {
        
        str = formatString(str);
        rightPadColumn(15, str.length(), str);
    }
    
    public void setCustomerChargeBilled(String str) {
        
        str = formatString(str);
        rightPadColumn(16, str.length(), str);
    }
    
    public void setDemandChargeRevenue(String str) {
        
        str = formatString(str);
        rightPadColumn(17, str.length(), str);
    }
    
    public void setISRSRevenueBilled(String str) {
        
        str = formatString(str);
        rightPadColumn(18, str.length(), str);
    }
    
    public void setAuthorizedOverrunRevenue(String str) {
        
        str = formatString(str);
        rightPadColumn(19, str.length(), str);
    }
    
    public void setUnauthorizedOverrunRevenue(String str) {
        
        str = formatString(str);
        rightPadColumn(20, str.length(), str);
    }
    
    public void setPGARevenueBilled(String str) {
        
        str = formatString(str);
        rightPadColumn(21, str.length(), str);
    }
    
    public void setACARevenueBilled(String str) {
        
        str = formatString(str);
        rightPadColumn(22, str.length(), str);
    }
    
    public void setGRTInRevenue(String str) {
        
        str = formatString(str);
        rightPadColumn(23, str.length(), str);
    }
    
    public void setIARevenue(String str) {
        
        str = formatString(str);
        rightPadColumn(24, str.length(), str);
    }
    
    public void setPrincipalRefund(String str) {
        
        str = formatString(str);
        rightPadColumn(25, str.length(), str);
    }
    
    public void setLacledeIntRefund(String str) {
        
        str = formatString(str);
        rightPadColumn(26, str.length(), str);
    }
    
    public void setGRTRefund(String str) {
        
        str = formatString(str);
        rightPadColumn(27, str.length(), str);
    }
    
    public void setStateSalesTax(String str) {
        
        str = formatString(str);
        rightPadColumn(28, str.length(), str);
    }
    
    public void setCitySalesTax(String str) {
        
        str = formatString(str);
        rightPadColumn(29, str.length(), str);
    }
        
    public void setTransportationStorageRevenue(String str) {
        
        if (StringUtilities.isEmptyOrNull(str)) {
            str = SPACE;
        }
        str = QUOTE_MARK + str.replaceAll(COMMA, SPACE).trim() + QUOTE_MARK;
        rightPadColumn(30, str.length(), str.trim());
    }    
}
