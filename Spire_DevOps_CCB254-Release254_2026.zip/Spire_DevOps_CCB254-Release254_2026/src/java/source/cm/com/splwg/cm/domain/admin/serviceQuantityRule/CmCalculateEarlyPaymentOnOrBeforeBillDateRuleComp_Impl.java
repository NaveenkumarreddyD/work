/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPRQXPX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      RA0032. Initial Version.
 * 2016-06-01   MPang       Defect 3444302. Added connection close.
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.
 * 2025-11-14   EQuint      CCB25.4 Upgrade                         
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.serviceQuantityRule;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.GenericBusinessComponent;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.datatypes.Time;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.language.Language_Id;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.api.lookup.HowToUseLookup;
import com.splwg.ccb.api.lookup.HowToUseReadLookup;
import com.splwg.ccb.api.lookup.IntervalBillingStartDayOptionLookup;
import com.splwg.ccb.api.lookup.ServiceQuantityLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.data.ServiceQuantityRuleComponent;
import com.splwg.ccb.domain.admin.revenueClass.entity.RevenueClass_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentItem_DTO;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentItem_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentRegisterRead_DTO;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentRegisterRead_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity_DTO;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.billing.data.BillSegmentItemData;
import com.splwg.ccb.domain.billing.data.BillSegmentReadData;
import com.splwg.ccb.domain.billing.data.BillSegmentServiceQuantityData;
import com.splwg.ccb.domain.common.data.CharacteristicData;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.item.entity.Item_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead_Id;
import com.splwg.ccb.domain.meterread.usage.entity.Usage_Id;
import com.splwg.ccb.domain.rate.data.ApplyRateData;
import com.splwg.ccb.domain.rate.rateSchedule.entity.RateSchedule_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmprqxpx;

/**
 * @author EQuint
 *
 @BusinessComponent (customizationCallable = true)
 */
public class CmCalculateEarlyPaymentOnOrBeforeBillDateRuleComp_Impl extends
		GenericBusinessComponent implements
		CmCalculateEarlyPaymentOnOrBeforeBillDateRuleComp, ServiceQuantityRuleComponent {

	// hard parameters
	private ApplyRateData applyRateData;
	private List<BillSegmentItemData> billSegmentItemDatas = new ArrayList<BillSegmentItemData>();
	private List<BillSegmentReadData> billSegmentReadDatas = new ArrayList<BillSegmentReadData>();
	private List<BillSegmentServiceQuantityData> billSegmentServiceQuantityDatas = new ArrayList<BillSegmentServiceQuantityData>();
	private List<CharacteristicData> characteristicDatas = new ArrayList<CharacteristicData>();
	private String sqRuleParameter1;
	private String sqRuleParameter2;
	private String sqRuleParameter3;
	private String sqRuleParameter4;
	private String sqRuleParameter5;
	private String sqRuleParameter6;
	private String sqRuleParameter7;
	private String sqRuleParameter8;
	private String sqRuleParameter9;
	private String sqRuleParameter10;
	private ServiceQuantityIdentifier_Id serviceQuantityIdentifierId;
	private ServiceQuantityLookup serviceQuantityLookup;
	private Bool shouldCreateBillingError;
	private TimeOfUse_Id timeOfUseId;
	private UnitOfMeasure_Id unitOfMeasureId;
	
	private Cmprqxpx cmprqxpx;
	private DateFormat dateFormat = new DateFormat("yyyy-MM-dd");
	private DateFormat dateTimeFormat = new DateFormat("yyyy-MM-dd-HH.mm.ss");
	private DateFormat dateTimeFormat2 = new DateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS");
	
	private DateFormat timeFormat = new DateFormat("HH:MM:SS.FF");
	//Start Add - MPang - Defect 3444302- 2016-06-01
	private Connection connection;
	//End Add - MPang - Defect 3444302- 2016-06-01
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	
	@Override
	public ApplyRateData getApplyRateData() {
		return applyRateData;
	}

	@Override
	public List<BillSegmentItemData> getBillSegmentItemData() {
		return billSegmentItemDatas;
	}

	@Override
	public List<BillSegmentReadData> getBillSegmentReadData() {
		return billSegmentReadDatas;
	}

	@Override
	public List<BillSegmentServiceQuantityData> getBillSegmentServiceQuantityData() {
		return billSegmentServiceQuantityDatas;
	}

	@Override
	public List<CharacteristicData> getCharacteristicData() {
		return characteristicDatas;
	}

	@Override
	public String getSQRuleParameter1() {
		return sqRuleParameter1;
	}

	@Override
	public String getSQRuleParameter10() {
		return sqRuleParameter10;
	}

	@Override
	public String getSQRuleParameter2() {
		return sqRuleParameter2;
	}

	@Override
	public String getSQRuleParameter3() {
		return sqRuleParameter3;
	}

	@Override
	public String getSQRuleParameter4() {
		return sqRuleParameter4;
	}

	@Override
	public String getSQRuleParameter5() {
		return sqRuleParameter5;
	}

	@Override
	public String getSQRuleParameter6() {
		return sqRuleParameter6;
	}

	@Override
	public String getSQRuleParameter7() {
		return sqRuleParameter7;
	}

	@Override
	public String getSQRuleParameter8() {
		return sqRuleParameter8;
	}

	@Override
	public String getSQRuleParameter9() {
		return sqRuleParameter9;
	}

	@Override
	public ServiceQuantityIdentifier_Id getServiceQuantityIdentifierId() {
		return serviceQuantityIdentifierId;
	}

	@Override
	public ServiceQuantityLookup getServiceQuantityLookup() {
		return serviceQuantityLookup;
	}

	@Override
	public Bool getShouldCreateBillingError() {
		return shouldCreateBillingError;
	}

	@Override
	public TimeOfUse_Id getTimeOfUseId() {
		return timeOfUseId;
	}

	@Override
	public UnitOfMeasure_Id getUnitOfMeasureId() {
		return unitOfMeasureId;
	}

	@Override
	public void setApplyRateData(ApplyRateData arg0) {
		applyRateData = arg0;
	}

	@Override
	public void setBillSegmentItemData(List<BillSegmentItemData> arg0) {
		billSegmentItemDatas = arg0;
	}

	@Override
	public void setBillSegmentReadData(List<BillSegmentReadData> arg0) {
		billSegmentReadDatas = arg0;
	}

	@Override
	public void setBillSegmentServiceQuantityData(
			List<BillSegmentServiceQuantityData> arg0) {
		billSegmentServiceQuantityDatas = arg0;
	}

	@Override
	public void setCharacteristicData(List<CharacteristicData> arg0) {
		characteristicDatas = arg0;
	}

	@Override
	public void setSQRuleParameter1(String arg0) {
		sqRuleParameter1 = arg0;
	}

	@Override
	public void setSQRuleParameter10(String arg0) {
		sqRuleParameter10 = arg0;
	}

	@Override
	public void setSQRuleParameter2(String arg0) {
		sqRuleParameter2 = arg0;
	}

	@Override
	public void setSQRuleParameter3(String arg0) {
		sqRuleParameter3 = arg0;
	}

	@Override
	public void setSQRuleParameter4(String arg0) {
		sqRuleParameter4 = arg0;
	}

	@Override
	public void setSQRuleParameter5(String arg0) {
		sqRuleParameter5 = arg0;
	}

	@Override
	public void setSQRuleParameter6(String arg0) {
		sqRuleParameter6 = arg0;
	}

	@Override
	public void setSQRuleParameter7(String arg0) {
		sqRuleParameter7 = arg0;
	}

	@Override
	public void setSQRuleParameter8(String arg0) {
		sqRuleParameter8 = arg0;
	}

	@Override
	public void setSQRuleParameter9(String arg0) {
		sqRuleParameter9 = arg0;
	}

	@Override
	public void setServiceQuantityIdentifierId(ServiceQuantityIdentifier_Id arg0) {
		serviceQuantityIdentifierId = arg0;
	}

	@Override
	public void setServiceQuantityLookup(ServiceQuantityLookup arg0) {
		serviceQuantityLookup = arg0;
	}

	@Override
	public void setShouldCreateBillingError(Bool arg0) {
		shouldCreateBillingError = arg0;
	}

	@Override
	public void setTimeOfUseId(TimeOfUse_Id arg0) {
		timeOfUseId = arg0;
	}

	@Override
	public void setUnitOfMeasureId(UnitOfMeasure_Id arg0) {
		unitOfMeasureId = arg0;
	}


	@Override
	public void invoke() {
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			if(notNull(unitOfMeasureId)) {
				cmprqxpx.setUomCd(unitOfMeasureId.getTrimmedValue());
			}else{
				cmprqxpx.setUomCd(CobolCode.SPACES.toString());
			}
			if(notNull(timeOfUseId)) {
				cmprqxpx.setTouCd(timeOfUseId.getTrimmedValue());
			}else{
				cmprqxpx.setTouCd(CobolCode.SPACES.toString());
			}
			if(notNull(serviceQuantityIdentifierId)) {
				cmprqxpx.setSqiCd(serviceQuantityIdentifierId.getTrimmedValue());
			}else{
				cmprqxpx.setSqiCd(CobolCode.SPACES.toString());
			}
			if(notNull(serviceQuantityLookup)) {
				cmprqxpx.setSqQtyFlg(serviceQuantityLookup.trimmedValue());
			}else{
				cmprqxpx.setSqQtyFlg(CobolCode.SPACES.toString());
			}
			
			if(notNull(shouldCreateBillingError)) {
				String shouldCreateBillingErrorSw = (shouldCreateBillingError.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmprqxpx.setCrtErrSw(shouldCreateBillingErrorSw);
			}else{
				cmprqxpx.setCrtErrSw(CobolCode.SPACES.toString());
			}
			
			if(notNull(applyRateData)) {
				if(notNull(applyRateData.getServiceAgreement())) {
					cmprqxpx.setRrtanInputWrkSaId(applyRateData.getServiceAgreement().getId().getTrimmedValue());
				}else{
					cmprqxpx.setRrtanInputWrkSaId(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getMasterServiceAgreement())) {
					cmprqxpx.setMasterSaId(applyRateData.getMasterServiceAgreement().getId().getTrimmedValue());
				}else{
					cmprqxpx.setMasterSaId(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getMasterBillSegment())) {
					cmprqxpx.setMasterBsegId(applyRateData.getMasterBillSegment().getId().getTrimmedValue());
				}else{
					cmprqxpx.setMasterBsegId(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getBill())) {
					cmprqxpx.setInputWrkBillId(applyRateData.getBill().getId().getTrimmedValue());
				}else{
					cmprqxpx.setInputWrkBillId(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getBillSegmentCreationDateTime())) {
					cmprqxpx.setBsCreDttm(applyRateData.getBillSegmentCreationDateTime().toString());
				}else{
					cmprqxpx.setBsCreDttm(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getBillSegmentPeriodEnd())) {
					cmprqxpx.setBsPeriodEndDt(applyRateData.getBillSegmentPeriodEnd().toString());
				}else{
					cmprqxpx.setBsPeriodEndDt(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getBillSegmentPeriodStart())) {
					cmprqxpx.setStartDt(applyRateData.getBillSegmentPeriodStart().toString());
				}else{
					cmprqxpx.setStartDt(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getConsumptionPeriodEnd())) {
					cmprqxpx.setConsumptionPeriodEndDt(applyRateData.getConsumptionPeriodEnd().toString());
				}else{
					cmprqxpx.setConsumptionPeriodEndDt(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getConsumptionPeriodStart())) {
					cmprqxpx.setConsumptionPeriodStartDt(applyRateData.getConsumptionPeriodStart().toString());
				}else{
					cmprqxpx.setConsumptionPeriodStartDt(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getCharacteristicServicePoint())) {
					cmprqxpx.setSpId(applyRateData.getCharacteristicServicePoint().getId().getTrimmedValue());
				}else{
					cmprqxpx.setSpId(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getCharacteristicPremise())) {
					cmprqxpx.setPremId(applyRateData.getCharacteristicPremise().getId().getTrimmedValue());
				}else{
					cmprqxpx.setPremId(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getAccountingDate())) {
					cmprqxpx.setAccountingDt(applyRateData.getAccountingDate().toString());
				}else{
					cmprqxpx.setAccountingDt(CobolCode.SPACES.toString());
				}
				
				if(notNull(applyRateData.getShouldRetainReadCollection())) {
					String shouldRetainReadCollectionSw = (applyRateData.getShouldRetainReadCollection().isTrue()) ? SWITCH_YES : SWITCH_NO;
					cmprqxpx.setRetainReadCollSw(shouldRetainReadCollectionSw);
				}else{
					cmprqxpx.setRetainReadCollSw(CobolCode.SPACES.toString());
				}
				
				if(notNull(applyRateData.getShouldRetainItemCollection())) {
					String shouldRetainItemCollectionSw = (applyRateData.getShouldRetainItemCollection().isTrue()) ? SWITCH_YES : SWITCH_NO;
					cmprqxpx.setRetainItemCollSw(shouldRetainItemCollectionSw);
				}else{
					cmprqxpx.setRetainItemCollSw(CobolCode.SPACES.toString());
				}
				
				if(notNull(applyRateData.getShouldRetainSqCollection())) {
					String shouldRetainSqCollectionSw = (applyRateData.getShouldRetainSqCollection().isTrue()) ? SWITCH_YES : SWITCH_NO;
					cmprqxpx.setRetainSqCollSw(shouldRetainSqCollectionSw);
				}else{
					cmprqxpx.setRetainSqCollSw(CobolCode.SPACES.toString());
				}
				
				if(notNull(applyRateData.getShouldRetainSqRules())) {
					String shouldRetainSqRuleSw = (applyRateData.getShouldRetainSqRules().isTrue()) ? SWITCH_YES : SWITCH_NO;
					cmprqxpx.setRetainSqRuleSw(shouldRetainSqRuleSw);
				}else{
					cmprqxpx.setRetainSqRuleSw(CobolCode.SPACES.toString());
				}
				
				if(notNull(applyRateData.getIsThirdParty())) {
					String thirdPartySw = (applyRateData.getIsThirdParty().isTrue()) ? SWITCH_YES : SWITCH_NO;
					cmprqxpx.setThirdPartySw(thirdPartySw);
				}else{
					cmprqxpx.setThirdPartySw(CobolCode.SPACES.toString());
				}
				
				if(notNull(applyRateData.getLanguage())) {
					cmprqxpx.setLanguageCd(applyRateData.getLanguage().getId().getTrimmedValue());
				}else{
					cmprqxpx.setLanguageCd(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getAdjustment())) {
					cmprqxpx.setAdjId(applyRateData.getAdjustment().getId().getTrimmedValue());
				}else{
					cmprqxpx.setAdjId(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getUsageConsumptionPeriodEnd())) {
					cmprqxpx.setUsageConsumptionPeriodEndDt(applyRateData.getUsageConsumptionPeriodEnd().toString());
				}else{
					cmprqxpx.setUsageConsumptionPeriodEndDt(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getUsageConsumptionPeriodStart())) {
					cmprqxpx.setUsageConsumptionPeriodStartDt(applyRateData.getUsageConsumptionPeriodStart().toString());
				}else{
					cmprqxpx.setUsageConsumptionPeriodStartDt(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getUsageId())) {
					cmprqxpx.setUsageId(applyRateData.getUsageId().getTrimmedValue());
				}else{
					cmprqxpx.setUsageId(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getCisDivision())) {
					cmprqxpx.setInputOutputWrkCisDivision(applyRateData.getCisDivision().getId().getTrimmedValue());
				}else{
					cmprqxpx.setInputOutputWrkCisDivision(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getServiceAgreementType())) {
					cmprqxpx.setSaTypeCd(applyRateData.getServiceAgreementType().getId().getSaType());
				}else{
					cmprqxpx.setSaTypeCd(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getRevenueClass())) {
					cmprqxpx.setRevClCd(applyRateData.getRevenueClass().getId().getTrimmedValue());
				}else{
					cmprqxpx.setRevClCd(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getRateSchedule())) {
					cmprqxpx.setRsCd(applyRateData.getRateSchedule().getId().getTrimmedValue());
				}else{
					cmprqxpx.setRsCd(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getSaPeriodEndDate())) {
					cmprqxpx.setSaPeriodEndDt(applyRateData.getSaPeriodEndDate().toString());
				}else{
					cmprqxpx.setSaPeriodEndDt(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getSaPeriodStartDate())) {
					cmprqxpx.setSaPeriodStartDt(applyRateData.getSaPeriodStartDate().toString());
				}else{
					cmprqxpx.setSaPeriodStartDt(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getStartDayOption())) {
					cmprqxpx.setIbBaseTmDayFlg(applyRateData.getStartDayOption().trimmedValue());
				}else{
					cmprqxpx.setIbBaseTmDayFlg(CobolCode.SPACES.toString());
				}
				if(notNull(applyRateData.getIntervalBillingSaCutoffTime())) {
					cmprqxpx.setIbSaCutoffDttmTm(applyRateData.getIntervalBillingSaCutoffTime().toString());
				}else{
					cmprqxpx.setIbSaCutoffDttmTm(CobolCode.SPACES.toString());
				}
			}
			
			cmprqxpx.setBillSegmentSqCnt(java.math.BigDecimal.valueOf(billSegmentServiceQuantityDatas.size()));
			int billSegmentServiceQuantityDatasSize = billSegmentServiceQuantityDatas.size();
			for (int i = 1; i <= billSegmentServiceQuantityDatasSize; i++) {
				BillSegmentServiceQuantity_DTO dto = billSegmentServiceQuantityDatas.get(i - 1).getBillSegmentServiceQuantityDto();
				if(notNull(dto.getId())) {
					if(notNull(dto.getId().getServiceQuantityIdentifier())) {
						cmprqxpx.setBillSegmentSqSqiCd(i, dto.getId().getServiceQuantityIdentifier().trim());
					}else{
						cmprqxpx.setBillSegmentSqSqiCd(i, CobolCode.SPACES.toString());
					}
					if(notNull(dto.getId().getTimeOfUse())) {
						cmprqxpx.setBillSegmentSqTouCd(i, dto.getId().getTimeOfUse().trim());
					}else{
						cmprqxpx.setBillSegmentSqTouCd(i, CobolCode.SPACES.toString());
					}
					if(notNull(dto.getId().getUnitOfMeasure())) {
						cmprqxpx.setBillSegmentSqUomCd(i, dto.getId().getUnitOfMeasure().trim());
					}else{
						cmprqxpx.setBillSegmentSqUomCd(i, CobolCode.SPACES.toString());
					}
				}
				if(notNull(dto.getInitialServiceQuantity())) {
					cmprqxpx.setInitSq(i, dto.getInitialServiceQuantity().toBigDecimal());
				}else{
					cmprqxpx.setInitSq(i, java.math.BigDecimal.ZERO);
				}
				if(notNull(dto.getBillableServiceQuantity())) {
					cmprqxpx.setBillSq(i, dto.getBillableServiceQuantity().toBigDecimal());
				}else{
					cmprqxpx.setBillSq(i, java.math.BigDecimal.ZERO);
				}
			}
			
			int billSegmentReadDatasSize = billSegmentReadDatas.size();
			cmprqxpx.setBillSegmentReadCnt(java.math.BigDecimal.valueOf(billSegmentReadDatasSize));
			for(int i = 1; i <= billSegmentReadDatasSize; i++) {
				BillSegmentRegisterRead_DTO dto = billSegmentReadDatas.get(i - 1).getBillSegmentReadDto();
				if(notNull(dto.getId())) {
					if(notNull(dto.getId().getServicePointIdString())) {
						cmprqxpx.setBillSegmentReadSpId(i, dto.getId().getServicePointIdString());
					}else{
						cmprqxpx.setBillSegmentReadSpId(i, CobolCode.SPACES.toString());
					}
					if(notNull(dto.getId().getSequence())) {
						cmprqxpx.setBillSegmentReadSeqno(i, java.math.BigDecimal.valueOf(dto.getId().getSequence().doubleValue()));
					}else{
						cmprqxpx.setBillSegmentReadSeqno(i, java.math.BigDecimal.ZERO);
					}
				}
				if(notNull(dto.getRegisterConstant())) {
					cmprqxpx.setRegConst(i, dto.getRegisterConstant().toBigDecimal());
				}else{
					cmprqxpx.setRegConst(i, java.math.BigDecimal.ZERO);
				}
				if(notNull(dto.getHowToUseRead())) {
					cmprqxpx.setUsageFlg(i, dto.getHowToUseRead().trimmedValue());
				}else{
					cmprqxpx.setUsageFlg(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getUsePercent())) {
					cmprqxpx.setUsePct(i, java.math.BigDecimal.valueOf(dto.getUsePercent().doubleValue()));
				}else{
					cmprqxpx.setUsePct(i, java.math.BigDecimal.ZERO);
				}
				if(notNull(dto.getHowToUse())) {
					cmprqxpx.setHowToUseFlg(i, dto.getHowToUse().trimmedValue());
				}else{
					cmprqxpx.setHowToUseFlg(i, CobolCode.SPACES.toString());
				}
				
				if(notNull(dto.getMeasuresPeakQuantity())) {
					String measurePeakQuantitySw = (dto.getMeasuresPeakQuantity().isTrue()) ? SWITCH_YES : SWITCH_NO;
					cmprqxpx.setMsrPeakQtySw(i, measurePeakQuantitySw);
				}else{
					cmprqxpx.setMsrPeakQtySw(i, CobolCode.SPACES.toString());
				}
				
				if(notNull(dto.getUnitOfMeasureId())) {
					cmprqxpx.setBillSegmentReadUomCd(i, dto.getUnitOfMeasureId().getTrimmedValue());
				}else{
					cmprqxpx.setBillSegmentReadUomCd(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getTimeOfUseId())) {
					cmprqxpx.setBillSegmentReadTouCd(i, dto.getTimeOfUseId().getTrimmedValue());
				}else{
					cmprqxpx.setBillSegmentReadTouCd(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getServiceQuantityIdentifierId())) {
					cmprqxpx.setBillSegmentReadSqiCd(i, dto.getServiceQuantityIdentifierId().getTrimmedValue());
				}else{
					cmprqxpx.setBillSegmentReadSqiCd(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getStartRegisterReadId())) {
					cmprqxpx.setStartRegReadId(i, dto.getStartRegisterReadId().getTrimmedValue());
				}else{
					cmprqxpx.setStartRegReadId(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getStartReadDateTime())) {
					cmprqxpx.setStartReadDttm(i, dto.getStartReadDateTime().toString());
				}else{
					cmprqxpx.setStartReadDttm(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getStartRegisterReading())) {
					cmprqxpx.setStartRegReading(i, dto.getStartRegisterReading().toBigDecimal());
				}else{
					cmprqxpx.setStartRegReading(i, java.math.BigDecimal.ZERO);
				}
				if(notNull(dto.getEndRegisterReadingId())) {
					cmprqxpx.setEndRegReadId(i, dto.getEndRegisterReadingId().getTrimmedValue());
				}else{
					cmprqxpx.setEndRegReadId(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getEndReadDateTime())) {
					cmprqxpx.setEndReadDttm(i, dto.getEndReadDateTime().toString());
				}else{
					cmprqxpx.setEndReadDttm(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getEndRegisterReading())) {
					cmprqxpx.setEndRegReading(i, dto.getEndRegisterReading().toBigDecimal());
				}else{
					cmprqxpx.setEndRegReading(i, java.math.BigDecimal.ZERO);
				}
				if(notNull(dto.getMeasuredQuantity())) {
					cmprqxpx.setMsrQty(i, dto.getMeasuredQuantity().toBigDecimal());
				}else{
					cmprqxpx.setMsrQty(i, java.math.BigDecimal.ZERO);
				}
				if(notNull(dto.getFinalUnitOfMeasureId())) {
					cmprqxpx.setFinalUomCd(i, dto.getFinalUnitOfMeasureId().getTrimmedValue());
				}else{
					cmprqxpx.setFinalUomCd(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getFinalTimeOfUseId())) {
					cmprqxpx.setFinalTouCd(i, dto.getFinalTimeOfUseId().getTrimmedValue());
				}else{
					cmprqxpx.setFinalTouCd(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getFinalServiceQuantityId())) {
					cmprqxpx.setFinalSqiCd(i, dto.getFinalServiceQuantityId().getTrimmedValue());
				}else{
					cmprqxpx.setFinalSqiCd(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getRegisterQuantity())) {
					cmprqxpx.setFinalRegQty(i, dto.getRegisterQuantity().toBigDecimal());
				}else{
					cmprqxpx.setFinalRegQty(i, java.math.BigDecimal.ZERO);
				}
			
			}
			
			int billSegmentItemDatasSize = billSegmentItemDatas.size();
			cmprqxpx.setBillSegmentItemCnt(java.math.BigDecimal.valueOf(billSegmentItemDatasSize));
			for (int i = 1; i <= billSegmentItemDatasSize; i++) {
				BillSegmentItem_DTO dto = billSegmentItemDatas.get(i - 1).getBillSegmentItemDto();
				if(notNull(dto.getId()) && notNull(dto.getId().getSequence())) {
					cmprqxpx.setBillSegmentItemSeqno(i, java.math.BigDecimal.valueOf(dto.getId().getSequence().doubleValue()));
				}else{
					cmprqxpx.setBillSegmentItemSeqno(i, java.math.BigDecimal.ZERO);
				}
				if(notNull(dto.getItemType())) {
					cmprqxpx.setItemTypeCd(i, dto.getItemType().trim());
				}else{
					cmprqxpx.setItemTypeCd(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getItemId())) {
					cmprqxpx.setItemId(i, dto.getItemId().getTrimmedValue());
				}else{
					cmprqxpx.setItemId(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getStartDate())) {
					cmprqxpx.setBillSegmentItemStartDt(i, dto.getStartDate().toString());
				}else{
					cmprqxpx.setBillSegmentItemStartDt(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getEndDate())) {
					cmprqxpx.setBillSegmentItemEndDt(i, dto.getEndDate().toString());
				}else{
					cmprqxpx.setBillSegmentItemEndDt(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getItemCount())) {
					cmprqxpx.setItemCnt(i, dto.getItemCount().toBigDecimal());
				}else{
					cmprqxpx.setItemCnt(i, java.math.BigDecimal.ZERO);
				}
				if(notNull(dto.getUnitOfMeasureId())) {
					cmprqxpx.setBillSegmentItemUomCd(i, dto.getUnitOfMeasureId().getTrimmedValue());
				}else{
					cmprqxpx.setBillSegmentItemUomCd(i, CobolCode.SPACES.toString());
				}
				if(notNull(dto.getDailyServiceQuantity())) {
					cmprqxpx.setSvcQty(i, dto.getDailyServiceQuantity().toBigDecimal());
				}else{
					cmprqxpx.setSvcQty(i, java.math.BigDecimal.ZERO);
				}
			}
			
			int characteristicDatasSize = characteristicDatas.size();
			cmprqxpx.setCharCollCnt(java.math.BigDecimal.valueOf(characteristicDatasSize));
			for (int i = 1; i <= characteristicDatasSize; i++) {
				CharacteristicData data = characteristicDatas.get(i - 1);
				if(notNull(data.getCharacteristicType())) {
					cmprqxpx.setCharType(i, data.getCharacteristicType().getId().getTrimmedValue());
				}else{
					cmprqxpx.setCharType(i, CobolCode.SPACES.toString());
				}
				if(notNull(data.getCharacteristicValue())) {
					cmprqxpx.setCharCollCharVal(i, data.getCharacteristicValue().trim());
				}else{
					cmprqxpx.setCharCollCharVal(i, CobolCode.SPACES.toString());
				}
				if(notNull(data.getAdhocCharacteristicValue())) {
					cmprqxpx.setAdhocCharVal(i, data.getAdhocCharacteristicValue().trim());
				}else{
					cmprqxpx.setAdhocCharVal(i, CobolCode.SPACES.toString());
				}
			}

			if(notBlank(sqRuleParameter1)) {
				cmprqxpx.setSqRuleParm(1, sqRuleParameter1);
			}else{
				cmprqxpx.setSqRuleParm(1, CobolCode.SPACES.toString());
			}
			if(notBlank(sqRuleParameter2)) {
				cmprqxpx.setSqRuleParm(2, sqRuleParameter2);
			}else{
				cmprqxpx.setSqRuleParm(2, CobolCode.SPACES.toString());
			}
			if(notBlank(sqRuleParameter3)) {
				cmprqxpx.setSqRuleParm(3, sqRuleParameter3);
			}else{
				cmprqxpx.setSqRuleParm(3, CobolCode.SPACES.toString());
			}
			if(notBlank(sqRuleParameter4)) {
				cmprqxpx.setSqRuleParm(4, sqRuleParameter4);
			}else{
				cmprqxpx.setSqRuleParm(4, CobolCode.SPACES.toString());
			}
			if(notBlank(sqRuleParameter5)) {
				cmprqxpx.setSqRuleParm(5, sqRuleParameter5);
			}else{
				cmprqxpx.setSqRuleParm(5, CobolCode.SPACES.toString());
			}
			if(notBlank(sqRuleParameter6)) {
				cmprqxpx.setSqRuleParm(6, sqRuleParameter6);
			}else{
				cmprqxpx.setSqRuleParm(6, CobolCode.SPACES.toString());
			}
			if(notBlank(sqRuleParameter7)) {
				cmprqxpx.setSqRuleParm(7, sqRuleParameter7);
			}else{
				cmprqxpx.setSqRuleParm(7, CobolCode.SPACES.toString());
			}
			if(notBlank(sqRuleParameter8)) {
				cmprqxpx.setSqRuleParm(8, sqRuleParameter8);
			}else{
				cmprqxpx.setSqRuleParm(8, CobolCode.SPACES.toString());
			}
			if(notBlank(sqRuleParameter9)) {
				cmprqxpx.setSqRuleParm(9, sqRuleParameter9);
			}else{
				cmprqxpx.setSqRuleParm(9, CobolCode.SPACES.toString());
			}
			if(notBlank(sqRuleParameter10)) {
				cmprqxpx.setSqRuleParm(10, sqRuleParameter10);
			}else{
				cmprqxpx.setSqRuleParm(10, CobolCode.SPACES.toString());
			}

			// invoke the main method
		    cmprqxpx.cobolMain(); 
		    // test
		    BillSegment billSegment = new BillSegment_Id(cmprqxpx.getMasterBsegId()).getEntity();
			applyRateData.setMasterBillSegment(billSegment);
			applyRateData.setBill(new Bill_Id(cmprqxpx.getInputWrkBillId()).getEntity());
			
			int bsSqDatasSize = cmprqxpx.getBillSegmentSqCnt().intValue();
			
			for (int i = 1; i <= bsSqDatasSize; i++) {
				BillSegmentServiceQuantity_Id id = new BillSegmentServiceQuantity_Id(
						billSegment, cmprqxpx.getBillSegmentSqUomCd(i), 
						cmprqxpx.getBillSegmentSqTouCd(i), cmprqxpx.getBillSegmentSqSqiCd(i));
				
				Bool addToCollection = Bool.TRUE;
		        
				for (int sqIndex = 0 ; sqIndex < billSegmentServiceQuantityDatas.size() ; sqIndex++){
					UnitOfMeasure uom = new UnitOfMeasure_Id(billSegmentServiceQuantityDatas.get(sqIndex).getBillSegmentServiceQuantityDto().getId().getUnitOfMeasure().toString()).getEntity();
			        TimeOfUse tou = new TimeOfUse_Id(billSegmentServiceQuantityDatas.get(sqIndex).getBillSegmentServiceQuantityDto().getId().getTimeOfUse().toString()).getEntity();
			        ServiceQuantityIdentifier sqi = new ServiceQuantityIdentifier_Id(billSegmentServiceQuantityDatas.get(sqIndex).getBillSegmentServiceQuantityDto().getId().getServiceQuantityIdentifier().toString()).getEntity();
			        
			        UnitOfMeasure uom2 = new UnitOfMeasure_Id(id.getUnitOfMeasure()).getEntity();
			        TimeOfUse tou2 = new TimeOfUse_Id(id.getTimeOfUse()).getEntity();
			        ServiceQuantityIdentifier sqi2 = new ServiceQuantityIdentifier_Id(id.getServiceQuantityIdentifier()).getEntity();
			        
					if(equalsWithNulls(sqi,sqi2)
							&& equalsWithNulls(tou,tou2)
							&& equalsWithNulls(uom,uom2)){
						addToCollection = Bool.FALSE;
					}
				}
				if(addToCollection.isTrue()){
					BillSegmentServiceQuantityData data = BillSegmentServiceQuantityData.Factory.newInstance();
					BillSegmentServiceQuantity_DTO dto = new BillSegmentServiceQuantity_DTO();
					
					UnitOfMeasure uom4 = new UnitOfMeasure_Id(cmprqxpx.getBillSegmentSqUomCd(i)).getEntity();
			        TimeOfUse tou4 = new TimeOfUse_Id(cmprqxpx.getBillSegmentSqTouCd(i)).getEntity();
			        ServiceQuantityIdentifier sqi4 = new ServiceQuantityIdentifier_Id(cmprqxpx.getBillSegmentSqSqiCd(i)).getEntity();
					
			        dto.setId(id);
					dto.setInitialServiceQuantity(BigDecimal.valueOf(cmprqxpx.getInitSq(i).doubleValue()));
					dto.setBillableServiceQuantity(BigDecimal.valueOf(cmprqxpx.getBillSq(i).doubleValue()));
					
					data.setBillSegmentServiceQuantityDto(dto);
					if (isNull(sqi4)&&isNull(tou4)&&isNull(uom4)){
						continue;
					}else{
						billSegmentServiceQuantityDatas.add(data);
					}
				}
			}
			
			int charDatasSize = cmprqxpx.getCharCollCnt().intValue();
			for(int i = 1 ; i <= charDatasSize ; i++) {
				Bool addToCollection = Bool.TRUE;
				
				for (int charIndex = 0 ; charIndex < characteristicDatas.size() ; charIndex++){
					
					CharacteristicType_Id collCharId = characteristicDatas.get(charIndex).getCharacteristicType().getId();
					CharacteristicType_Id tempCharId = new CharacteristicType_Id(cmprqxpx.getCharType(i)).getEntity().getId();
					
					if(collCharId.compareTo(tempCharId) == 0){
						addToCollection = Bool.FALSE;
					}
				}
				if(addToCollection.isTrue()){
					CharacteristicData data = CharacteristicData.Factory.newInstance();
					data.setCharacteristicType(new CharacteristicType_Id(cmprqxpx.getCharType(i)).getEntity());
					data.setCharacteristicValue(cmprqxpx.getCharCollCharVal(i));
					data.setAdhocCharacteristicValue(cmprqxpx.getAdhocCharVal(i));
				
					characteristicDatas.add(data);
				}
			}
			// test end
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
		    
            //Start Delete - MPang - Defect 3444302- 2016-06-01
            //ex.printStackTrace();
            //End Delete - MPang - Defect 3444302- 2016-06-01
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmprqxpx.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmprqxpx.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmprqxpx.getMessageParm(i);
			    			if (notBlank(cmprqxpx.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmprqxpx.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmprqxpx.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmprqxpx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmprqxpx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    	populateHardParameters();
		    	
		    }
		    else {
	            //Start Add- MPang - Defect 3444302- 2016-06-01
                ex.printStackTrace();
                //End Add- MPang - Defect 3444302- 2016-06-01
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getClass().getCanonicalName(), ex.toString()));
		        }
		    }
		}
		finally {
 			cmprqxpx=Session.returnSessionAndCodeToCache(cmprqxpx);
 		// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//            //Start Add- MPang - Defect 3444302- 2016-06-01
//           try {
//               connection.close();
//           } catch (SQLException e) {
//               addError(CustomMessageRepository.JACOB_errorMessage(getClass().getCanonicalName(), e.toString()));
//           }
//           //End Add- MPang - Defect 3444302- 2016-06-01
        // end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}
	}
	
	private void populateHardParameters() {
		try {
			unitOfMeasureId = new UnitOfMeasure_Id(cmprqxpx.getUomCd());
			timeOfUseId = new TimeOfUse_Id(cmprqxpx.getTouCd());
			serviceQuantityIdentifierId = new ServiceQuantityIdentifier_Id(cmprqxpx.getSqiCd());
			serviceQuantityLookup = LookupHelper.getLookupInstance(ServiceQuantityLookup.class, cmprqxpx.getSqQtyFlg());
			shouldCreateBillingError = (cmprqxpx.getCrtErrSw().compareToIgnoreCase(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE;
			
			applyRateData.setServiceAgreement(new ServiceAgreement_Id(cmprqxpx.getRrtanInputWrkSaId()).getEntity());
			applyRateData.setMasterServiceAgreement(new ServiceAgreement_Id(cmprqxpx.getMasterBsegId()).getEntity());
			
			BillSegment billSegment = new BillSegment_Id(cmprqxpx.getMasterBsegId()).getEntity();
			applyRateData.setMasterBillSegment(billSegment);
			applyRateData.setBill(new Bill_Id(cmprqxpx.getInputWrkBillId()).getEntity());
			
			if (notBlank(cmprqxpx.getBsCreDttm())){
				DateTime bsCreationDateTime; 
				if(cmprqxpx.getBsCreDttm().matches("([0-9]{4})-([0-9]{2})-([0-9]{2})-([0-9]{2}).([0-9]{2}).([0-9]{2}).([0-9]{6})")){
					bsCreationDateTime = DateTime.fromString(cmprqxpx.getBsCreDttm(), dateTimeFormat2);
				} else {
					bsCreationDateTime = DateTime.fromString(cmprqxpx.getBsCreDttm(), dateTimeFormat);
				}
				 
				applyRateData.setBillSegmentCreationDateTime(bsCreationDateTime);
			}
			
			if (notBlank(cmprqxpx.getBsPeriodEndDt())){
				Date bsPeriodEndDate = Date.fromString(cmprqxpx.getBsPeriodEndDt(), dateFormat);
				applyRateData.setBillSegmentPeriodEnd(bsPeriodEndDate);
			}
			
			if (notBlank(cmprqxpx.getStartDt())){
				Date bsPeriodStartDate = Date.fromString(cmprqxpx.getStartDt(), dateFormat);
				applyRateData.setBillSegmentPeriodStart(bsPeriodStartDate);
			}
			
			if (notBlank(cmprqxpx.getConsumptionPeriodEndDt())){
				Date consPeriodEndDate = Date.fromString(cmprqxpx.getConsumptionPeriodEndDt(), dateFormat);
				applyRateData.setConsumptionPeriodEnd(consPeriodEndDate);
			}
			
			if (notBlank(cmprqxpx.getConsumptionPeriodStartDt())){
				Date consPeriodStartDate = Date.fromString(cmprqxpx.getConsumptionPeriodStartDt(), dateFormat);
				applyRateData.setConsumptionPeriodStart(consPeriodStartDate);
			}
			applyRateData.setCharacteristicServicePoint(new ServicePoint_Id(cmprqxpx.getSpId()).getEntity());
			applyRateData.setCharacteristicPremise(new Premise_Id(cmprqxpx.getPremId()).getEntity());
			
			if (notBlank(cmprqxpx.getAccountingDt())){
				Date accountingDate = Date.fromString(cmprqxpx.getAccountingDt(), dateFormat);
				applyRateData.setAccountingDate(accountingDate);
			}
			applyRateData.setShouldRetainReadCollection((cmprqxpx.getRetainReadCollSw().compareToIgnoreCase(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE);
			applyRateData.setShouldRetainItemCollection((cmprqxpx.getRetainItemCollSw().compareToIgnoreCase(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE);
			applyRateData.setShouldRetainSqCollection((cmprqxpx.getRetainSqCollSw().compareToIgnoreCase(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE);
			applyRateData.setShouldRetainSqRules((cmprqxpx.getRetainSqRuleSw().compareToIgnoreCase(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE);
			applyRateData.setIsThirdParty((cmprqxpx.getThirdPartySw().compareToIgnoreCase(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE);
			applyRateData.setLanguage(new Language_Id(cmprqxpx.getLanguageCd()).getEntity());
			applyRateData.setAdjustment(new Adjustment_Id(cmprqxpx.getAdjId()).getEntity());
			
			if (notBlank(cmprqxpx.getUsageConsumptionPeriodEndDt())){
				Date usageConsPeriodEndDate = Date.fromString(cmprqxpx.getUsageConsumptionPeriodEndDt(), dateFormat);
				applyRateData.setUsageConsumptionPeriodEnd(usageConsPeriodEndDate);
			}
			
			if (notBlank(cmprqxpx.getUsageConsumptionPeriodStartDt())){ 
				Date usageConsPeriodStartDate = Date.fromString(cmprqxpx.getUsageConsumptionPeriodStartDt(), dateFormat);
				applyRateData.setUsageConsumptionPeriodStart(usageConsPeriodStartDate);
			}
			applyRateData.setUsageId(new Usage_Id(cmprqxpx.getUsageId()));
			
			CisDivision cisDivision = new CisDivision_Id(cmprqxpx.getInputOutputWrkCisDivision()).getEntity();
			applyRateData.setCisDivision(cisDivision);
			applyRateData.setServiceAgreementType(new ServiceAgreementType_Id(cisDivision, cmprqxpx.getSaTypeCd()).getEntity());
			
			applyRateData.setRevenueClass(new RevenueClass_Id(cmprqxpx.getRevClCd()).getEntity());
			applyRateData.setRateSchedule(new RateSchedule_Id(cmprqxpx.getRsCd()).getEntity());
			
			if (notBlank(cmprqxpx.getSaPeriodEndDt())){ 
				Date saPeriodEndDate = Date.fromString(cmprqxpx.getSaPeriodEndDt(), dateFormat);
				applyRateData.setSaPeriodEndDate(saPeriodEndDate);
			}
			if (notBlank(cmprqxpx.getSaPeriodStartDt())){
				Date saPeriodStartDate = Date.fromString(cmprqxpx.getSaPeriodStartDt(), dateFormat);
				applyRateData.setSaPeriodStartDate(saPeriodStartDate);
			}
			applyRateData.setStartDayOption(LookupHelper.getLookupInstance(IntervalBillingStartDayOptionLookup.class, cmprqxpx.getIbBaseTmDayFlg()));
			if (notBlank(cmprqxpx.getIbSaCutoffDttmTm())){
				applyRateData.setIntervalBillingSaCutoffTime(Time.fromString(cmprqxpx.getIbSaCutoffDttmTm(), timeFormat));
			}
			int bsSqDatasSize = cmprqxpx.getBillSegmentSqCnt().intValue();
			billSegmentServiceQuantityDatas.clear();
			for (int i = 1; i <= bsSqDatasSize; i++) {
				BillSegmentServiceQuantityData data = BillSegmentServiceQuantityData.Factory.newInstance();
				BillSegmentServiceQuantity_DTO dto = new BillSegmentServiceQuantity_DTO();
				BillSegmentServiceQuantity_Id id = new BillSegmentServiceQuantity_Id(
						billSegment, cmprqxpx.getBillSegmentSqUomCd(i), 
						cmprqxpx.getBillSegmentSqTouCd(i), cmprqxpx.getBillSegmentSqSqiCd(i));
				
				dto.setId(id);
				dto.setInitialServiceQuantity(BigDecimal.valueOf(cmprqxpx.getInitSq(i).doubleValue()));
				dto.setBillableServiceQuantity(BigDecimal.valueOf(cmprqxpx.getBillSq(i).doubleValue()));
				
				data.setBillSegmentServiceQuantityDto(dto);
				billSegmentServiceQuantityDatas.add(data);
			}
			
			int bsReadDatasSize = cmprqxpx.getBillSegmentReadCnt().intValue();
			billSegmentReadDatas.clear();
			for (int i = 1; i <= bsReadDatasSize; i++) {
				BillSegmentReadData data = BillSegmentReadData.Factory.newInstance();
				BillSegmentRegisterRead_DTO dto = new BillSegmentRegisterRead_DTO();
				BillSegmentRegisterRead_Id id = new BillSegmentRegisterRead_Id(
						billSegment, cmprqxpx.getBillSegmentReadSpId(i), cmprqxpx.getBillSegmentReadSeqno(i).toBigInteger());
				dto.setId(id);
				dto.setRegisterConstant(BigDecimal.valueOf(cmprqxpx.getRegConst(i).doubleValue()));
				dto.setHowToUseRead(LookupHelper.getLookupInstance(HowToUseReadLookup.class, cmprqxpx.getUsageFlg(i)));
				// start update - equint - 2025-11-14 - CCB25.4 Upgrade
				//dto.setUsePercent(cmprqxpx.getUsePct(i).toBigInteger());
				dto.setUsePercent(BigDecimal.valueOf(cmprqxpx.getUsePct(i).doubleValue()));
				// End update - equint - 2025-11-14 - CCB25.4 Upgrade
				dto.setHowToUse(LookupHelper.getLookupInstance(HowToUseLookup.class, cmprqxpx.getHowToUseFlg(i)));
				dto.setMeasuresPeakQuantity((cmprqxpx.getMsrPeakQtySw(i).compareToIgnoreCase(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE);
				dto.setUnitOfMeasureId(new UnitOfMeasure_Id(cmprqxpx.getBillSegmentReadUomCd(i)));
				dto.setTimeOfUseId(new TimeOfUse_Id(cmprqxpx.getBillSegmentReadTouCd(i)));
				dto.setServiceQuantityIdentifierId(new ServiceQuantityIdentifier_Id(cmprqxpx.getBillSegmentReadSqiCd(i)));
				dto.setStartRegisterReadId(new RegisterRead_Id(cmprqxpx.getStartRegReadId(i)));
				if (notBlank(cmprqxpx.getStartReadDttm(i))){
					DateTime startReadDttm = DateTime.fromString(cmprqxpx.getStartReadDttm(i), dateTimeFormat);
					dto.setStartReadDateTime(startReadDttm);
				}
				dto.setStartRegisterReading(BigDecimal.valueOf(cmprqxpx.getStartRegReading(i).doubleValue()));
				if (notBlank(cmprqxpx.getEndReadDttm(i))){
					DateTime endReadDttm = DateTime.fromString(cmprqxpx.getEndReadDttm(i), dateTimeFormat);
					dto.setEndReadDateTime(endReadDttm);
				}
				dto.setEndRegisterReading(BigDecimal.valueOf(cmprqxpx.getEndRegReading(i).doubleValue()));
				
				dto.setMeasuredQuantity(BigDecimal.valueOf(cmprqxpx.getMsrQty(i).doubleValue()));
				dto.setFinalUnitOfMeasureId(new UnitOfMeasure_Id(cmprqxpx.getFinalUomCd(i)));
				
				dto.setFinalTimeOfUseId(new TimeOfUse_Id(cmprqxpx.getFinalTouCd(i)));
				dto.setFinalServiceQuantityId(new ServiceQuantityIdentifier_Id(cmprqxpx.getFinalSqiCd(i)));
				dto.setRegisterQuantity(BigDecimal.valueOf(cmprqxpx.getFinalRegQty(i).doubleValue()));
				
				data.setBillSegmentReadDto(dto);
				billSegmentReadDatas.add(data);
			}
			
			int bsItemDatasSize = cmprqxpx.getBillSegmentItemCnt().intValue();
			billSegmentItemDatas.clear();
			for (int i = 1; i <= bsItemDatasSize; i++) {
				BillSegmentItemData data = BillSegmentItemData.Factory.newInstance();
				BillSegmentItem_DTO dto = new BillSegmentItem_DTO();
				BillSegmentItem_Id id = new BillSegmentItem_Id(billSegment, cmprqxpx.getBillSegmentItemSeqno(i).toBigInteger());
				dto.setId(id);
				dto.setItemType(cmprqxpx.getItemTypeCd(i));
				dto.setItemId(new Item_Id(cmprqxpx.getItemId(i)));
				if (notBlank(cmprqxpx.getBillSegmentItemStartDt(i))){
					Date bsItemStartDt = Date.fromString(cmprqxpx.getBillSegmentItemStartDt(i), dateFormat);
					dto.setStartDate(bsItemStartDt);
				}
				
				if (notBlank(cmprqxpx.getBillSegmentItemEndDt(i))){
					Date bsItemEndDt = Date.fromString(cmprqxpx.getBillSegmentItemEndDt(i), dateFormat);
					dto.setEndDate(bsItemEndDt);
				}
				dto.setItemCount(BigDecimal.valueOf(cmprqxpx.getItemCnt(i).doubleValue()));
				dto.setUnitOfMeasureId(new UnitOfMeasure_Id(cmprqxpx.getBillSegmentItemUomCd(i)));
				dto.setDailyServiceQuantity(BigDecimal.valueOf(cmprqxpx.getSvcQty(i).doubleValue()));
				
				data.setBillSegmentItemDto(dto);
				billSegmentItemDatas.add(data);
			}
			
			int charDatasSize = cmprqxpx.getCharCollCnt().intValue();
			characteristicDatas.clear();
			for(int i = 1 ; i <= charDatasSize ; i++) {
				CharacteristicData data = CharacteristicData.Factory.newInstance();
				data.setCharacteristicType(new CharacteristicType_Id(cmprqxpx.getCharType(i)).getEntity());
				data.setCharacteristicValue(cmprqxpx.getCharCollCharVal(i));
				data.setAdhocCharacteristicValue(cmprqxpx.getAdhocCharVal(i));
				
				characteristicDatas.add(data);
			}
			
			sqRuleParameter1 = cmprqxpx.getSqRuleParm(1);
			sqRuleParameter2 = cmprqxpx.getSqRuleParm(2);
			sqRuleParameter3 = cmprqxpx.getSqRuleParm(3);
			sqRuleParameter4 = cmprqxpx.getSqRuleParm(4);
			sqRuleParameter5 = cmprqxpx.getSqRuleParm(5);
			sqRuleParameter6 = cmprqxpx.getSqRuleParm(6);
			sqRuleParameter7 = cmprqxpx.getSqRuleParm(7);
			sqRuleParameter8 = cmprqxpx.getSqRuleParm(8);
			sqRuleParameter9 = cmprqxpx.getSqRuleParm(9);
			sqRuleParameter10 = cmprqxpx.getSqRuleParm(10);
		}
		catch (Exception e) {
			if (e instanceof ApplicationError) {
	        	addError(((ApplicationError)e).getServerMessage());
	        }
	        else {
	        	addError(CustomMessageRepository.JACOB_errorMessage(getClass().getCanonicalName(), e.toString()));
	        }
		}
	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
		FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
		RequestContext context = session.getRequestContext();
		
		// start update - equint - 2025-11-14 - CCB25.4 Upgrade
		session.doWork(new ConnectionWork() {
			
			@Override
			public void execute(Connection connection) throws SQLException {
				try {		
					String username = connection.getMetaData().getUserName();
					String url = connection.getMetaData().getURL();
					
					CobolSession.setLogSessionStartEnd(false);
				    cmprqxpx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmprqxpx.class);
					
					cmprqxpx.getSession().getDbSession().setUpdateConnection(connection);
					cmprqxpx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
					
					// Initialize linkage copybooks
					//cmprqxpx.aa100Initialize();
					
					// set ZSTAT parameters
					
					cmprqxpx.setProcessDt(getProcessDateTime().getDate().toString());
					cmprqxpx.setProcessDttmSep("-");
					cmprqxpx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
					
					if (session.isOnlineConnection()) { 
						cmprqxpx.setConnectionFlg(CONNECTION_ONLINE);
					}
					else {
						cmprqxpx.setConnectionFlg(CONNECTION_BATCH);
					}
					
					cmprqxpx.setUserId(context.getUserId());
					cmprqxpx.setLanguageCd(context.getLanguageCode());
			        
			        if (context.ignoreWarnings()) {
			        	cmprqxpx.setIgnoreWarningSw(SWITCH_YES);
			        }
			        else {
			        	cmprqxpx.setIgnoreWarningSw(SWITCH_NO);
			        }
			        
			        if (session.getBatchInstanceId() != null) {
			        	cmprqxpx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
			        	
					} else {
						cmprqxpx.setSchedulerId(new BigDecimal(0).toBigDecimal());
					}
			        
			        cmprqxpx.setAppSvcId(context.getSecurityServiceIdContext());
			        
			        DatabaseHelper dbHelper = session.getDatabaseHelper();
			        cmprqxpx.setDbMode(dbHelper.getCobolDBMode());
			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
			        //cmprqxpx.setSplHighValue(cmprqxpx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
			        //cmprqxpx.setSplLowValue(cmprqxpx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
			        
			        cmprqxpx.setSplHighValue(cmprqxpx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
			        cmprqxpx.setSplLowValue(cmprqxpx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
			        
			        cmprqxpx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
			        
			        cmprqxpx.setLkExpiryDt(Date.MAX.toString());
			        
			        cmprqxpx.setProgramStatus(" ");
			        
			        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
			        cmprqxpx.setCallSeq(";");
			        cmprqxpx.setMessageAreaProgramName("CMPRQXRX");
			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
			        
			        if (context.getRandomGeneratorSeedSet().isTrue()) {
			        	cmprqxpx.setRandomGenSeedSw(SWITCH_YES);
			        	cmprqxpx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
			        	cmprqxpx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
			        	cmprqxpx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
			        	cmprqxpx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
			        }
			        else {
			        	cmprqxpx.setRandomGenSeedSw(SWITCH_NO);
			        }
			        
			        if (context.traceStandardOut()) { 
			        	cmprqxpx.setTrcStdoutSw(SWITCH_YES);
			        }
			        else {
			        	cmprqxpx.setTrcStdoutSw(SWITCH_NO);
			        }
			        
			        if (context.traceProgramStart()) { 
			        	cmprqxpx.setTrcProgStartSw(SWITCH_YES);
			        }
			        else {
			        	cmprqxpx.setTrcProgStartSw(SWITCH_NO);
			        }
			        
			        if (context.traceProgramExit()) { 
			        	cmprqxpx.setTrcProgExitSw(SWITCH_YES);
			        }
			        else {
			        	cmprqxpx.setTrcProgExitSw(SWITCH_NO);
			        }
			        
			        if (context.traceSQL()) { 
			        	cmprqxpx.setTrcExecSqlSw(SWITCH_YES);
			        }
			        else {
			        	cmprqxpx.setTrcExecSqlSw(SWITCH_NO);
			        }
			        
			        // Set ZMSGN parms
			        BigInteger messageSequence = session.getMessageSequence();
			        if (notNull(messageSequence)) {
			        	cmprqxpx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
			        }
			        else {
			        	cmprqxpx.setMessageSeq(new BigDecimal(0).toBigDecimal());
			        }
				}
				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		 
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//        //Start Change - MPang - Defect 3444302- 2016-06-01
//        //Connection connection = implementor.getConnectionProvider().getConnection();
//        connection = implementor.getConnectionProvider().getConnection();
//        //End Change - MPang - Defect 3444302- 2016-06-01		
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmprqxpx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmprqxpx.class);
//		
//		cmprqxpx.getSession().getDbSession().setUpdateConnection(connection);
//		cmprqxpx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		
//		// Initialize linkage copybooks
//		//cmprqxpx.aa100Initialize();
//		
//		// set ZSTAT parameters
//		
//		cmprqxpx.setProcessDt(getProcessDateTime().getDate().toString());
//		cmprqxpx.setProcessDttmSep("-");
//		cmprqxpx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmprqxpx.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmprqxpx.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmprqxpx.setUserId(context.getUserId());
//		cmprqxpx.setLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmprqxpx.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmprqxpx.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmprqxpx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmprqxpx.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmprqxpx.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmprqxpx.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmprqxpx.setSplHighValue(cmprqxpx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmprqxpx.setSplLowValue(cmprqxpx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmprqxpx.setSplHighValue(cmprqxpx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmprqxpx.setSplLowValue(cmprqxpx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmprqxpx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmprqxpx.setLkExpiryDt(Date.MAX.toString());
//        
//        cmprqxpx.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmprqxpx.setCallSeq(";");
//        cmprqxpx.setMessageAreaProgramName("CMPRQXRX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmprqxpx.setRandomGenSeedSw(SWITCH_YES);
//        	cmprqxpx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmprqxpx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmprqxpx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmprqxpx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmprqxpx.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmprqxpx.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmprqxpx.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmprqxpx.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmprqxpx.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmprqxpx.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmprqxpx.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmprqxpx.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmprqxpx.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmprqxpx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmprqxpx.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }
		
		// end update - equint - 2025-11-14 - CCB25.4 Upgrade
         
	}
    /**
     * @param a - Object
     * @param b - Object
     * @return
     */
    private boolean equalsWithNulls(Object a, Object b) {
        if (a==b) return true;
        if ((a==null)||(b==null)) return false;
        return a.equals(b);
    }
}
