/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 2024-07-30   DLampa     INC0037039. Updated field lengths to match 
 *                         the file layout extracted by the CM-BILEXTR 
 *                         algorithm 
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractDetailsPaymentDetailsRecord 
		extends ColumnDelimitedRecord{	
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractDetailsPaymentDetailsRecord() {
		super(14);
		
		// Initialize all fields as blank/spaces
		this.setBPPrinterKey(" ");		
		this.setBPSortKey(" ");
		this.setBPMailingKey(" ");		
		this.setFtTypeFlg(" ");
		this.setPayDt(" ");
		this.setCanRsnCd(" ");
		this.setCanRsnDescr(" ");
		this.setCurPayAmt(BigDecimal.ZERO, "0");
		this.setTotPayAmt(BigDecimal.ZERO, "0");
		this.setPledgePayFlg(" ");
		this.setPledgeTenderDescr(" ");	
		this.setFiller();
	}
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * 
	 */
	public void setBPPrinterKey(String value) {		
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
	public void setBPSortKey(String value) {
		rightPadColumn(2, 184, truncateInput(value, 184));
	}
	public void setBPMailingKey(String value) {
		rightPadColumn(3, 15, truncateInput(value, 15));
	}	
	/*
	 * Payment (List)
	 */
	public void setFtTypeFlg(String value) {
		rightPadColumn(4, 2, truncateInput(value, 2));
	}
	public void setPayDt(String value) {
		rightPadColumn(5, 10, truncateInput(value, 10));
	}
	public void setCanRsnCd(String value) {
		rightPadColumn(6, 4, truncateInput(value, 4));
	}
	public void setCanRsnDescr(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(7, 30, truncateInput(value, 30));
		rightPadColumn(7, 60, truncateInput(value, 60));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setCurPayAmt(BigDecimal bdVal, String value) {		
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(8, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(9, 15, truncateInput(value, 15));
	}
	public void setTotPayAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(10, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(11, 15, truncateInput(value, 15));		
	}
	public void setPledgePayFlg(String value) {
		rightPadColumn(12, 1, truncateInput(value, 1));
	}
	public void setPledgeTenderDescr(String value) {
		rightPadColumn(13, 60, truncateInput(value, 60));
	}
	private void setFiller() {
		//rightPadColumn(12, 3307, " ");
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(14, 3102, " ");
		rightPadColumn(14, 3072, " ");
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
}