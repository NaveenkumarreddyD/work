package com.splwg.cm.api.lookup;

/**
 * @author sdesabhatl002
 * 
 * @LookupFieldname (value = XBDC_OPT_TYP_FLG)
 */

public class CmBankDistributionCodeLookup_Impl 
  extends CmBankDistributionCodeLookup_Gen{

}