/*******************************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * E-08144 - NEWCST Customer Contact and Bill Message 
 *
 *******************************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2024-03-21   CAtilano 	E-08144. Initial Version.
 * 
 ******************************************************************************************************/
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.saActivation;

import java.util.ArrayList;
import java.util.List;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.BillMessageTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saActivation.SaTypeSaActivationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountMessage_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author OGC04023
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = newCustomerCCType, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = customerContactClass, name = contactClass, type = entity, required = true)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = billMessageCharacteristicType, type = entity, required = true)          
 *            , @AlgorithmSoftParameter (name = customerContactCharactristicValue, type = string, required = true)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = accountCustomerContactCharType, type = entity, required = true)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = premiseCustomerContactCharType, type = entity, required = true)
 *            , @AlgorithmSoftParameter (name = mOEBillMesage, entityName = billMessageType, type = entity, required = true)
 *            , @AlgorithmSoftParameter (name = mOWBillMesage, entityName = billMessageType, type = entity, required = true)
 *            , @AlgorithmSoftParameter (name = sECISDivisions, type = string, required = true)
 *            , @AlgorithmSoftParameter (name = sEBillMessage, entityName = billMessageType, type = entity, required = true)})
 */
public class CmCreateNewCustomerContactAlgComp_Impl extends
		CmCreateNewCustomerContactAlgComp_Gen implements
		SaTypeSaActivationAlgorithmSpot {
	
	public ServiceAgreement sa;
	public Account acct;
	public static String MOE_DIVISION = "LGC";
	public static String MOW_DIVISION = "MGE";
	public String contactType; 
	public CustomerContactType newCustCCType;
	public CustomerContactClass contactClass;
	public String charValue;
	public CharacteristicType billMessageCharType;
	public CharacteristicType acctCCCharType;
	public CharacteristicType premCCCharType;
	public BillMessageType moEBillMessage;
	public BillMessageType moWBillMessage;
	public BillMessageType seBillMessage;
	public List<CisDivision> seDivisions;
	
	@Override
	public void invoke() {

		//validate if there is an existing gas metered SA. Exit if found
		if(checkForAccountGasSA(null))
			return;
		
		//validate if Customer Contact Type of NEWCST  was ever created on the Person Record. If so then end processing
		if(checkforCC())
			return;
		
		//Determine if that person record is tied to any other account as the Main Person. 
		//If so, determine if there is an existing gas metered SA for such accounts. Exit if found
		if(checkForOtherAccounts())
			return;
		
		//Create CC
		cmCreateCustomerContact();
		
		//Add Bill Message
		addBillMessage();

	}

	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		// TODO Auto-generated method stub
		super.extraSoftParameterValidations(forAlgorithmValidation);
		contactType = getNewCustomerCCType();
		billMessageCharType = getBillMessageCharacteristicType();
		charValue = getCustomerContactCharactristicValue();
		acctCCCharType = getAccountCustomerContactCharType();
		premCCCharType = getPremiseCustomerContactCharType();
		moEBillMessage = getMOEBillMesage();
		moWBillMessage = getMOWBillMesage();
		seBillMessage = getSEBillMessage();
        contactClass = getContactClass();
        newCustCCType = new CustomerContactType_Id(contactClass, contactType).getEntity();
        seDivisions = new ArrayList<CisDivision>();
        
        /*for (int i=0; i < parmMOCisDivisions.length; i++){
            String cisDivStr = parmMOCisDivisions[i];
            CisDivision cisDivision = new CisDivision_Id(cisDivStr.trim()).getEntity();
            if (isNull(cisDivision))
            	addError(CustomMessageRepositorySpireOne.B18265_invalidSaType(cisDivStr));
            else 
            	moDivisions.add(cisDivision);
        }*/
        String[] parmSECisDivisions = getSECISDivisions().split(",");

        for (int i=0; i < parmSECisDivisions.length; i++){
            String cisDivStr = parmSECisDivisions[i];
            CisDivision cisDivision = new CisDivision_Id(cisDivStr.trim()).getEntity();
            if (isNull(cisDivision))
            	addError(CustomMessageRepositorySpireOne.B18265_invalidSaType(cisDivStr));
            else 
            	seDivisions.add(cisDivision);
        }
	}

	@Override
	public void setServiceAgreement(ServiceAgreement arg0) {
		sa = arg0;
		acct = sa.getAccount();
	}

	public Boolean checkForAccountGasSA(Account account){
		Boolean result = false;
		String query = "SELECT SA.SA_ID FROM"
				+ " CI_SA SA"
				+ " , CI_SA_TYPE SAT"
				+ " , CI_SA_SP_TYPE SASPT"
				+ " , CI_SP_TYPE SPT"
				+ " WHERE SASPT.SA_TYPE_CD = SAT.SA_TYPE_CD"
				+ " AND SAT.CIS_DIVISION = SASPT. CIS_DIVISION"
				+ " AND SASPT.SP_TYPE_CD = SPT.SP_TYPE_CD"
				+ " AND SPT.SVC_TYPE_CD = 'G'"
				+ " AND SA.ACCT_ID = :acctId"
				+ " AND SA.CIS_DIVISION = SAT.CIS_DIVISION"
				+ " AND SA.SA_TYPE_CD = SAT.SA_TYPE_CD"
				+ " AND SA.SA_STATUS_FLG IN (:active,:pendingStop,:stopped,:closed)"
				+ " AND SA.SA_ID <> :saId ";
		
		PreparedStatement ps = createPreparedStatement(query,"hasAccountGasSA");
		if(!isNull(account))
			ps.bindEntity("acctId", account);
		else 
			ps.bindEntity("acctId", acct);
		ps.bindEntity("saId", sa);
		ps.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
		ps.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
		ps.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
		ps.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
		
		if (!isNull(ps.firstRow()))
			result = true;
		ps.close();

		return result;
	}
	
	public Boolean checkforCC(){
		Boolean result = false;
		String qry = "SELECT CC.CC_ID FROM "
				+ " CI_ACCT_PER AP"
				+ " , CI_CC CC"
				+ " WHERE AP.ACCT_ID = :acctId"
				+ " AND AP.MAIN_CUST_SW = 'Y'"
				+ " AND AP.PER_ID = CC.PER_ID"
				+ " AND CC.CC_TYPE_CD = :ccType";
		PreparedStatement ps = createPreparedStatement(qry,"checkforCC");
		ps.bindEntity("acctId", acct);
		ps.bindString("ccType", newCustCCType.fetchIdContactType().trim(), "CC_TYPE_CD");
		
		if (!isNull(ps.firstRow()))
			result = true;
		ps.close();

		return result;
	}
	
	public Boolean checkForOtherAccounts(){
		Boolean result = false;
		String perAccts = "SELECT AP.ACCT_ID"
				+ " FROM CI_ACCT_PER AP"
				+ " WHERE AP.MAIN_CUST_SW = 'Y'"
				+ " AND AP.PER_ID = :perId"
				+ " AND AP.ACCT_ID <> :acctId";
		PreparedStatement ps = createPreparedStatement(perAccts,"perAccts");
		ps.bindEntity("perId", acct.getMainPerson());
		ps.bindEntity("acctId", acct);
		
		QueryIterator<SQLResultRow> iterator = ps.iterate();
		while(iterator.hasNext()){
			if(checkForAccountGasSA(new Account_Id(iterator.nextRow().getString("ACCT_ID")).getEntity())){
				result = true;
				break;
			}		
		}
		iterator.close();
		ps.close();
		return result;
	}

	private void cmCreateCustomerContact() {

		// Retrieve Main Person where the customer contact would be created for

		CustomerContact_DTO contactDto = new CustomerContact_DTO();
		contactDto.setCustomerContactTypeId(newCustCCType.getId());
		contactDto.setPersonId(acct.getMainPerson().getId());
		contactDto.setContactDateTime(getProcessDateTime());
		contactDto.setAccountId(acct.getId());
		if(!isNull(sa.fetchPremise().getId()))
			contactDto.setPremiseId(sa.fetchPremise().getId());
		CustomerContact newCC = contactDto.newEntity();
		
		// Create Characteristics
		cmCreateCustomerContactCharacteristics(newCC, acctCCCharType, acct.getId().getIdValue());
		cmCreateCustomerContactCharacteristics(newCC, premCCCharType, sa.fetchPremise().getId().getIdValue());
		cmCreateCustomerContactCharacteristics(newCC, billMessageCharType, charValue);
	
	}		
	
	private void cmCreateCustomerContactCharacteristics(CustomerContact cc, CharacteristicType charType, String charVal) {		
		if (notBlank(charVal)) {
			
			CustomerContactCharacteristic_DTO ccCharDTO = cc.getCharacteristics().newChildDTO();			
			if (charType.getCharacteristicType().isAdhocValue()
					|| charType.getCharacteristicType().isFileLocationValue()) {
						
				ccCharDTO.setAdhocCharacteristicValue(charVal.trim());
			}
			else if (charType.getCharacteristicType().isForeignKeyValue()) {
				
				ccCharDTO.setCharacteristicValueForeignKey1(charVal.trim());
			}
			else {
				
				ccCharDTO.setCharacteristicValue(charVal.trim());
			}	
			cc.getCharacteristics().add(ccCharDTO, charType.getId());
		}
	}
	
	private void addBillMessage(){
		AccountMessage_DTO msgDTO = acct.getMessages().newChildDTO();
		CisDivision_Id moeDiv = new CisDivision_Id(MOE_DIVISION);
		CisDivision_Id mowDiv = new CisDivision_Id(MOW_DIVISION);
		msgDTO.setBillMessageType(BillMessageTypeLookup.constants.TEMPORARY);
		if(seDivisions.contains(acct.getDivisionId().getEntity())){
			acct.getMessages().add(msgDTO, seBillMessage.getId());
			return;
		}	
		if(acct.getDivisionId().equals(moeDiv)){
			acct.getMessages().add(msgDTO, moEBillMessage.getId());
			return;
		}
		if(acct.getDivisionId().equals(mowDiv)){
			acct.getMessages().add(msgDTO, moWBillMessage.getId());
		}
	}

}
