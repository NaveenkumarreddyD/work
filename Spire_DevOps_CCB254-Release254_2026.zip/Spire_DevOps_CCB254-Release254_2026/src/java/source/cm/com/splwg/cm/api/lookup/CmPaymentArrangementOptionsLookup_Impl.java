/*
 ************************************************************************ 
 *                 Confidentiality Information: 
 * 
 ************************************************************************
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * Payment Arrangement Options Lookup
 * 
 ************************************************************************ 
 * CHANGE HISTORY: 
 * 
 * Date:        by:         Reason: 
 * YYYY-MM-DD   FLName
 * 2014-10-02   WCARANDA    Initial Version. MGE-CCB008.
 ************************************************************************
 */
package com.splwg.cm.api.lookup;

/**
 * @LookupFieldname (value = XXPA_OPT_TYP_FLG)
 */

@SuppressWarnings("serial")
public class CmPaymentArrangementOptionsLookup_Impl 
		extends CmPaymentArrangementOptionsLookup_Gen{

}
