/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Batch - Process EA Eligibility File
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-04-29   RDizon  NI0026.1 Initial Version.
 * 2013-05-08   SMiran  NI0026.1 Changed the following batch parameters:
 *                      TONN_FA_TYPE to FA_TYPE_TONN_CHAR_TYPE
 *                      TOFF_FA_TYPE to FA_TYPE_TOFF_CHAR_TYPE
 * 2013-05-15   SMiran  Bug 1248. Added file validation
 * 2013-05-20   SMiran  Bug 1248. Open file using absolute path instead of
 *                      file path and file name concatenation   
 * 2013-08-16   MOL     MOL-IM-036193. Skip Account if it is invalid.
 *                      Added OK_TO_TONN_CONTACT_CLASS batch parameter.
 *                      Change the logic to always create a new file output
 *                      and not append to an existing one.
 * 2013-08-21   MOL     MOL-20130821. Fix null pointer error.
 * 2013-09-05   CVB     Try to add quote and activate it to eligible SA.
 *                      Add Downpayment Remaining tag to SA detail.  
 * 2013-11-06   CVB     Create To Do when no mailing address was found for the account.
 *                      Moved some logic from common routine to improve performance.                                                       
 * 2013-11-07   Neha    IM-039396 XML parser error
 * 2016-01-29  	MPang	Updated for CCB v2.4 compilation.
 * 2016-11-14  	RGoke	Updated for Incident# 160127. 
 * 2017-08-30   JRoxas  SA-223039. Added Pledge Amount to Customer Contact
 *                      comments.
 * 2018-10-15   LBallo  Defect 4136779. Changed cmCheckExistingCustomerContact query
 * 						to Prepared Statement due to hibernate issues.
 * 2018-10-18   LBallo  Defect 4136779 reopen. Changed other queries to Prepared
 * 						Statement due to hibernate issues.
 * 2020-10-20   JLumbre CCB-017. Encryption.
 **************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
//MOL-IM-036193
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessService.BusinessServiceDispatcher;
import com.splwg.base.api.businessService.BusinessServiceInstance;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.encryption.DecryptedValue;
/* MOL-IM-036193 Begin */
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
/* MOL-IM-036193 End */
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.MeterOnOffStatusLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseType_Id;
import com.splwg.ccb.domain.admin.customerClass.CustomerClass_Id;
import com.splwg.ccb.domain.admin.customerContactClass.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.CustomerContactType_Id;
//2013-05-08 SMiran Start Delete
//import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType;
//2013-05-08 SMiran End Delete
import com.splwg.ccb.domain.admin.idType.IdType;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.Person;
import com.splwg.ccb.domain.customerinfo.person.PersonId;
import com.splwg.ccb.domain.customerinfo.person.PersonIds;
import com.splwg.ccb.domain.customerinfo.person.PersonName;
import com.splwg.ccb.domain.customerinfo.person.PersonNames;
import com.splwg.ccb.domain.customerinfo.person.Person_Id;
import com.splwg.ccb.domain.customerinfo.premise.AccountMailingAddressData;
import com.splwg.ccb.domain.customerinfo.premise.AccountMailingAddressRetriever;
import com.splwg.ccb.domain.customerinfo.premise.Premise;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTask_Id;*/
import com.splwg.ccb.domain.admin.caseType.entity.CaseType_Id;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass_Id;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.idType.entity.IdType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.common.AccountMailingAddressRetriever;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.data.AccountMailingAddressData;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonId;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonIds;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonName;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonNames;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.security.common.FieldEncryptionDecryption;
import com.splwg.ccb.domain.security.data.FieldEncryptionDecryptionData;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.api.batch.CmEligibilityAccountDetailRecord;
import com.splwg.cm.api.batch.CmEligibilityAccountPersonDetailRecord;
import com.splwg.cm.api.batch.CmEligibilityInputFileDetailRecord;
import com.splwg.cm.api.batch.CmEligibilityMailingAddressDetailRecord;
import com.splwg.cm.api.batch.CmEligibilityPremiseDetailRecord;
import com.splwg.cm.api.batch.CmEligibilityServiceAgreementDetailRecord;
import com.splwg.cm.api.batch.CmEligibilityServicePointDetailRecord;
import com.splwg.cm.api.lookup.CmEAEligibilityLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmQuotePledgeRoutine;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.customMessages.CustomMessagesMDC;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author redizon
 *
 * @BatchJob (multiThreaded = true, rerunnable = false, modules = {}, 
 *      softParameters = { @BatchJobSoftParameter (name = INPUT_FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = INPUT_FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = OUTPUT_FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = OUTPUT_FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, required = false, type = integer)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = FEATURE_CONFIG, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = idType, name = SSN_ID_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = FA_TYPE_TONN_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = FA_TYPE_TOFF_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = FILE_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = ACCT_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = OK_TO_TONN_CONTACT_CLASS, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CONTACT_CLASS, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CONTACT_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = TO_DO_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PLEDGE_AMT_CHAR_TYPE, required = true, type = entity)})
 */

public class CmProcessEAEligibilityFileBatch extends
CmProcessEAEligibilityFileBatch_Gen {
	
	//Start Add - JLumbre - 2020-10-20 - CCB-017
	private static final Logger log = LoggerFactory.getLogger(CmProcessEAEligibilityFileBatch.class);
	//End Add - JLumbre - 2020-10-20 - CCB-017
	// Batch Parameters
	private String parmInputFilePath;
	private String parmInputFileName;
	private String parmOutputFilePath;
	private String parmOutputFileName;
	// 2013-05-08 SMiran Start Add
	private CharacteristicType parmFaTypeTurnOnCharType;
	private CharacteristicType parmFaTypeTurnOffCharType;
	// 2013-05-08 SMiran End Add
	private CharacteristicType parmFileIdCharType;
	private CharacteristicType parmAccountIdCharType;
	private CustomerContactClass parmContactClass;
	private String parmContactType;
	// SA-223039 - 08/30/2017 - Start Add
    private CharacteristicType parmPledgeAmountCharType;
    // SA-223039 - 08/30/2017 - End Add

	/* MOL-IM-036193 Begin */
	private CustomerContactClass parmOkToTurnOnContactClass;
	/* MOL-IM-036193 End */

	// Work Variables

	private FeatureConfiguration parmFeatureConfiguration;
	private List<String> customerClassOptions = new ArrayList<String>();
	private CaseType_Id diversionCaseTypeId;
	private IdType parmSsnIdType;
	private File inputFile;
	private BufferedReader bufferedReader;
	/* MOL-IM-036193 Begin */
	private String lineRead = null;
	private String fileIdStr;
	private String accountIdStr;
	private String applicantSSNStr;
	private String coApplicantSSNStr;
	// SA-223039 - 08/30/2017 - Start Add
	private String pledgeAmount;
	// SA-223039 - 08/30/2017 - End Add
	private int lineNumber = 0;
	/* MOL-IM-036193 End */

	private List<Account_Id> accountIds = new ArrayList<Account_Id>();
	private List<String> fileIds = new ArrayList<String>();
	private List<Bool> isSpecified = new ArrayList<Bool>();
	// SA-223039 - 08/30/2017 - Start Add
	private List<String> pledgeAmounts = new ArrayList<String>();
	// SA-223039 - 08/30/2017 - End Add

	// Constants
	private static String INPUT_FILE_PATH = "INPUT_FILE_PATH";
	private static String OUTPUT_FILE_PATH = "OUTPUT_FILE_PATH";
	// 2013-05-08 SMiran Start Add
	private static String FA_TYPE_TONN_CHAR_TYPE = "FA_TYPE_TONN_CHAR_TYPE";
	private static String FA_TYPE_TOFF_CHAR_TYPE = "FA_TYPE_TOFF_CHAR_TYPE";
	// 2013-05-08 SMiran End Add
	private static String FILE_ID_CHAR_TYPE = "FILE_ID_CHAR_TYPE";
	private static String ACCT_ID_CHAR_TYPE = "ACCT_ID_CHAR_TYPE";
	private static String CONTACT_TYPE = "CONTACT_TYPE";
	// SA-223039 - 08/30/2017 - Start Add
	private static String PLEDGE_AMT_CHAR_TYPE = "PLEDGE_AMT_CHAR_TYPE";
	// SA-223039 - 08/30/2017 - End Add
	
	public JobWork getJobWork() {

		// Open file
		parmInputFilePath = this.getParameters().getINPUT_FILE_PATH();
		parmInputFileName = this.getParameters().getINPUT_FILE_NAME();

		// Open the Input File
		try {
			inputFile = new File(parmInputFilePath, parmInputFileName);
			bufferedReader = (BufferedReader) openBufferedFile(inputFile.getAbsolutePath(), Bool.TRUE);
		} catch (Exception e){
			addError(CustomMessageRepositoryMDC.ni0026_1_ErrorInOpeningFile(inputFile.getAbsolutePath()));
		}

		retrieveAndValidateInputFileDetailRecord();
		
		// Close the Input file
		try{
			bufferedReader.close();
		} 
		catch(IOException e){
			addError(CustomMessageRepositoryMDC.ni0026_1_ErrorInClosingFile(inputFile.getAbsolutePath()));
		}

		// Build Worklist
		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();

		for (int i = 0; i < accountIds.size(); i++){

			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			Account_Id accountId = accountIds.get(i);
			String fileId = fileIds.get(i);
			Bool isSpecifiedBool = isSpecified.get(i);
			// SA-223039 - 08/30/2017 - Start Add
			String pledgeAmount = pledgeAmounts.get(i);
			// SA-223039 - 08/30/2017 - Start Add
			
			workUnit.setPrimaryId(accountId);
			workUnit.addSupplementalData("fileId", fileId);
			workUnit.addSupplementalData("isSpecifiedAccount", isSpecifiedBool);
			// SA-223039 - 08/30/2017 - Start Add
			workUnit.addSupplementalData("pledgeAmount", pledgeAmount);
			// SA-223039 - 08/30/2017 - Start Add

			workUnits.add(workUnit);  
		}
		return createJobWorkForThreadWorkUnitList(workUnits);  
	}

	/**
	 * Open the Buffered File
	 * @param filepath String
	 * @param isInputFile Bool 
	 * @return object Object
	 */
	private Object openBufferedFile(String filePath, Bool isInputFile){
		try {
			if (isInputFile.isTrue()){
				return new BufferedReader(new FileReader(filePath));
			}
			else {
				return new BufferedWriter(new FileWriter(filePath, true));
			}
		} catch (IOException e) {
			throw new RunAbortedException(CustomMessageRepositoryMDC.ni0026_1_ErrorInOpeningFile(filePath));
		}

	}

	/**
	 * Read a line from the Buffered Reader
	 * @param bufferedReader BufferedReader
	 * @return string String
	 */
	private String readLine(BufferedReader bufferedReader){
		String string = "";
		try {
			string = bufferedReader.readLine();
		} catch(IOException ioe){
			ioe.printStackTrace();
			addError(CustomMessageRepositoryMDC.ni0026_1_ErrorInReadingFile(inputFile.getAbsolutePath()));
		}
		return string;
	}

	@Override
	public void validateSoftParameters(boolean isNewRun) {
		// Retrieve Batch Parameters
		parmInputFilePath = this.getParameters().getINPUT_FILE_PATH();
		parmInputFileName = this.getParameters().getINPUT_FILE_NAME();
		parmOutputFilePath = this.getParameters().getOUTPUT_FILE_PATH();
		parmOutputFileName = this.getParameters().getOUTPUT_FILE_NAME();
		// 2013-05-08 SMiran Start Add
		parmFaTypeTurnOnCharType = this.getParameters().getFA_TYPE_TONN_CHAR_TYPE();
		parmFaTypeTurnOffCharType = this.getParameters().getFA_TYPE_TOFF_CHAR_TYPE();
		// 2013-05-08 SMiran End Add
		parmFileIdCharType = this.getParameters().getFILE_ID_CHAR_TYPE();
		parmAccountIdCharType = this.getParameters().getACCT_ID_CHAR_TYPE();
		parmContactClass = this.getParameters().getCONTACT_CLASS();
		parmContactType = this.getParameters().getCONTACT_TYPE();
		// SA-223039 - 08/30/2017 - Start Add
		parmPledgeAmountCharType = this.getParameters().getPLEDGE_AMT_CHAR_TYPE();
		// SA-223039 - 08/30/2017 - End Add

		/* MOL-IM-036193 Begin */
		parmOkToTurnOnContactClass = this.getParameters().getOK_TO_TONN_CONTACT_CLASS();
		/* MOL-IM-036193 End */

		File inputFolder = new File(parmInputFilePath);

		if(!(inputFolder.exists() && inputFolder.isDirectory())){
			addError(CustomMessageRepositoryMDC.ni0026_1_BatchParameterInvalidFilePath(INPUT_FILE_PATH, parmInputFilePath));
		}

		File outputFolder = new File(parmOutputFilePath);

		if(!(outputFolder.exists() && outputFolder.isDirectory())){
			addError(CustomMessageRepositoryMDC.ni0026_1_BatchParameterInvalidFilePath(OUTPUT_FILE_PATH, parmOutputFilePath));
		}
		
		// Validate that output file name has enough ? symbols
		
		Bool isValidOutputFileName = fileNameIsValid(parmOutputFileName);
		if (isValidOutputFileName.isFalse()) {
			addError(CustomMessageRepositoryMDC.commFileNameThreadDigitMissing());
		}

		// 2013-05-08 SMiran Start Add
		// Batch parameter FA Type Turn On Characteristic Type must be a valid characteristic for FA Type entity
		CharacteristicEntity_Id faTypeTurnOnCharTypeCharEntityId = new CharacteristicEntity_Id(parmFaTypeTurnOnCharType, 
				CharacteristicEntityLookup.constants.FIELD_ACTIVITY_TYPE);
		if (isNull(faTypeTurnOnCharTypeCharEntityId.getEntity())){
			addError(CustomMessageRepositoryMDC.ni0026_1_BatchParameterInvalidCharTypeForEntity(FA_TYPE_TONN_CHAR_TYPE, 
					parmFaTypeTurnOnCharType.getId().getIdValue(),
					CharacteristicEntityLookup.constants.FIELD_ACTIVITY_TYPE.getLookupValue().fetchLanguageDescription()));
		}

		// Batch parameter FA Type Turn Off Characteristic Type must be a valid characteristic for FA Type entity
		CharacteristicEntity_Id faTypeTurnOffCharTypeCharEntityId = new CharacteristicEntity_Id(parmFaTypeTurnOffCharType, 
				CharacteristicEntityLookup.constants.FIELD_ACTIVITY_TYPE);
		if (isNull(faTypeTurnOffCharTypeCharEntityId.getEntity())){
			addError(CustomMessageRepositoryMDC.ni0026_1_BatchParameterInvalidCharTypeForEntity(FA_TYPE_TOFF_CHAR_TYPE, 
					parmFaTypeTurnOffCharType.getId().getIdValue(),
					CharacteristicEntityLookup.constants.FIELD_ACTIVITY_TYPE.getLookupValue().fetchLanguageDescription()));
		}
		// 2013-05-08 SMiran End Add

		// Batch parameter File ID Characteristic Type must be a valid characteristic for Customer Contact entity
		CharacteristicEntity_Id fileIdCharEntityId = new CharacteristicEntity_Id(parmFileIdCharType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);
		if (isNull(fileIdCharEntityId.getEntity())){
			addError(CustomMessageRepositoryMDC.ni0026_1_BatchParameterInvalidCharTypeForEntity(FILE_ID_CHAR_TYPE, parmFileIdCharType.getId().getIdValue(),
					CharacteristicEntityLookup.constants.CUSTOMER_CONTACT.getLookupValue().fetchLanguageDescription()));
		}

		// Batch parameter Account ID Characteristic Type must be a valid characteristic for Customer Contact entity
		CharacteristicEntity_Id accountIdCharEntityId = new CharacteristicEntity_Id(parmAccountIdCharType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);
		if (isNull(accountIdCharEntityId.getEntity())){
			addError(CustomMessageRepositoryMDC.ni0026_1_BatchParameterInvalidCharTypeForEntity(ACCT_ID_CHAR_TYPE, parmAccountIdCharType.getId().getIdValue(),
					CharacteristicEntityLookup.constants.CUSTOMER_CONTACT.getLookupValue().fetchLanguageDescription()));
		}

		// Batch parameter Contact Type must be a valid contact type for batch parameter Contact Class
		CustomerContactType_Id customerContactTypeId = new CustomerContactType_Id(parmContactClass, parmContactType.trim());
		if (isNull(customerContactTypeId.getEntity())){
			addError(CustomMessageRepositoryMDC.ni0026_1_BatchParameterInvalidContactTypeForContactClass(CONTACT_TYPE, 
					parmContactType.trim(), parmContactClass.getId().getIdValue()));
		}
		
		// SA-223039 - 08/30/2017 - Start Add
	    // Batch parameter Pledge Amount Characteristic Type must be a valid characteristic for Customer Contact entity
        CharacteristicEntity_Id pledgeAmtCharEntityId = new CharacteristicEntity_Id(parmPledgeAmountCharType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);
        if (isNull(pledgeAmtCharEntityId.getEntity())){
            addError(CustomMessageRepository.SA_223039_invalidCharTypeForEntity(PLEDGE_AMT_CHAR_TYPE, parmPledgeAmountCharType.getId().getIdValue(),
                    CharacteristicEntityLookup.constants.CUSTOMER_CONTACT.getLookupValue().fetchLanguageDescription()));
        }
        // SA-223039 - 08/30/2017 - End Add
        
		// Retrieve and validate Feature Configuration values
		retrieveAndValidateFeatureConfiguration();

	}
	
	private Bool fileNameIsValid(String fileName) {
		
		int fileNameLength = fileName.length();
		int threadNumber = 0;
		int wpos1 = 0;
		int wpos2 = 0;
		
		for (wpos1 = fileNameLength - 1; wpos1 >= 0; wpos1--){
		    if (fileName.charAt(wpos1) == '?') {
		    	threadNumber = this.getParameters().getThreadCount().intValue();
		    	for (wpos2 = wpos1; wpos2 >= 0; wpos2--){
		    		if (fileName.charAt(wpos2) != '?') {
		    			break;
		    		}
		    	    threadNumber = threadNumber / 10;
		    	}
	    	    if (threadNumber != 0) {
	    	    	return Bool.FALSE;
	    	    }
	    	    wpos1 = wpos2;
		    }
		}
		return Bool.TRUE;
	}
	


	private void retrieveAndValidateFeatureConfiguration(){

		parmFeatureConfiguration = this.getParameters().getFEATURE_CONFIG();

		// Retrieve and validate Customer Class Code Feature Option
		Query getCustomerClassCode = cmGetFeatureConfigurationOptionValue(parmFeatureConfiguration,
				CmEAEligibilityLookup.constants.CUSTOMER_CLASS.getLookupValue().fetchIdFieldValue());

		// 2013-11-06 - CVB - Start
		Long getCustomerClassCodeListSize = getCustomerClassCode.listSize();
		// Check if Option Value exists
		// if (getCustomerClassCode.listSize() == 0){
		if (getCustomerClassCodeListSize == 0){
			// 2013-11-06 - CVB - End
			addError(CustomMessageRepositoryMDC.ni0026_1_FeatureConfigurationOptionValueIsRequired(parmFeatureConfiguration.getId().getIdValue(),
					CmEAEligibilityLookup.constants.CUSTOMER_CLASS.toLocalizedString()));
		}

		// Check if multiple Option Values exist
		// 2013-11-06 - CVB - Start
		// if (getCustomerClassCode.listSize() > 1){
		if (getCustomerClassCodeListSize > 1){
			// 2013-11-06 - CVB - End
			addError(CustomMessageRepositoryMDC.ni0026_1_FeatureConfigurationMultipleOptionValues(parmFeatureConfiguration.getId().getIdValue(),
					CmEAEligibilityLookup.constants.CUSTOMER_CLASS.toLocalizedString()));
		}


		// Check if each Option Value is a valid Customer Class
		customerClassOptions = Arrays.asList(((String) getCustomerClassCode.firstRow()).split(",")); 

		Iterator itrCustomerClassoptions = customerClassOptions.iterator();
		while(itrCustomerClassoptions.hasNext()){
			String customerClassIdStr = (String) itrCustomerClassoptions.next();
			CustomerClass_Id customerClassId = new CustomerClass_Id(customerClassIdStr);
			if (isNull(customerClassId.getEntity())){
				addError(CustomMessageRepositoryMDC.ni0026_1_FeatureConfigurationInvalidCustomerClass(parmFeatureConfiguration.getId().getIdValue(),
						customerClassIdStr));
			}
		}

		// Retrieve and validate Diversion Case Type Code Feature Option
		Query getDiversionCaseType = cmGetFeatureConfigurationOptionValue(parmFeatureConfiguration,
				CmEAEligibilityLookup.constants.CASE_TYPE.getLookupValue().fetchIdFieldValue());

		// 2013-11-06 - CVB - Start
		Long getDiversionCaseTypeListSize = getDiversionCaseType.listSize();

		// Check if Option Value exists
		// if (getDiversionCaseType.listSize() == 0){
		if (getDiversionCaseTypeListSize == 0){
			// 2013-11-06 - CVB - End
			addError(CustomMessageRepositoryMDC.ni0026_1_FeatureConfigurationOptionValueIsRequired(parmFeatureConfiguration.getId().getIdValue(),
					CmEAEligibilityLookup.constants.CASE_TYPE.toLocalizedString()));
		}

		// Check if multiple Option Values exist
		// 2013-11-06 - CVB - Start
		// if (getDiversionCaseType.listSize() > 1){
		if (getDiversionCaseTypeListSize > 1){
			// 2013-11-06 - CVB - End
			addError(CustomMessageRepositoryMDC.ni0026_1_FeatureConfigurationMultipleOptionValues(parmFeatureConfiguration.getId().getIdValue(),
					CmEAEligibilityLookup.constants.CASE_TYPE.toLocalizedString()));
		}

		// Check if Option Value is a valid Case Type
		String caseTypeIdStr = (String) getDiversionCaseType.firstRow();
		diversionCaseTypeId = new CaseType_Id(caseTypeIdStr);
		if (isNull(diversionCaseTypeId.getEntity())){
			addError(CustomMessageRepositoryMDC.ni0026_1_FeatureConfigurationInvalidCaseType(parmFeatureConfiguration.getId().getIdValue(),
					caseTypeIdStr));
		}

	}

	/**
	 * Get the Feature Configuration Option Value
	 * @param featureConfiguration FeatureConfiguration
	 * @param optionType String
	 * @return query Query
	 */
	private Query cmGetFeatureConfigurationOptionValue(FeatureConfiguration featureConfiguration, String optionType) {
		Query query = createQuery("FROM FeatureConfigurationOption FCO "
				+ "WHERE FCO.id.workforceManagementSystem = :featConfName "
				//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				//+ "AND FCO.id.optionType = :optionType ");
				+ "AND FCO.id.optionType = :optionType ", getClass().getName());
				//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		query.bindEntity("featConfName", featureConfiguration);
		query.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, optionType);
		query.addResult("optionValue", "FCO.value");

		return query;
	}

	/**
	 * Get Account using the Person's Social Security Number
	 * @param idNumber String
	 * @return query Query
	 */
	private Query cmGetAccountsFromSSN(String idNumber) {
		//Start Add - JLumbre - 2020-10-20 - CCB-017
		Query query;
		String personIdStr = checkSSNForEncryption(idNumber, parmSsnIdType.getId().getTrimmedValue());
		Person_Id personId = new Person_Id(personIdStr);
		Person person = personId.getEntity();
		if (!isNull(person)){
			StringBuilder queryStringBuilder = new StringBuilder();
			queryStringBuilder.append("FROM PersonId PID, AccountPerson AP, Account A ");
			queryStringBuilder.append("WHERE PID.id.person = :personId ");			
			queryStringBuilder.append("AND PID.id.person = AP.id.person ");
			queryStringBuilder.append("AND AP.isFinanciallyResponsible = :yes ");
			queryStringBuilder.append("AND AP.id.account = A.id ");
			queryStringBuilder.append("AND A.customerClass IN (");
			for (int i = 0; i < customerClassOptions.size(); i++){
				queryStringBuilder.append(":customerClass" + i);

				if (i < customerClassOptions.size() - 1){
					queryStringBuilder.append(", ");
				}
			}
			queryStringBuilder.append(")");

			query = createQuery(queryStringBuilder.toString(), getClass().getName());
			query.bindId("personId", person.getId());
			//query.bindStringProperty("ssnIdNumber", PersonId.properties.personIdNumber, idNumber);
			query.bindBoolean("yes", Bool.TRUE);
			for (int i = 0; i < customerClassOptions.size(); i++){
				query.bindEntity("customerClass" + i, new CustomerClass_Id(customerClassOptions.get(i)).getEntity());
			}
			query.addResult("accountId", "AP.id.account");
		}
		else{
			//End Add - JLumbre - 2020-10-20 - CCB-017
			StringBuilder queryStringBuilder = new StringBuilder();
			queryStringBuilder.append("FROM PersonId PID, AccountPerson AP, Account A ");
			queryStringBuilder.append("WHERE PID.id.idType = :ssnIdType ");
			queryStringBuilder.append("AND PID.personIdNumber = :ssnIdNumber ");
			queryStringBuilder.append("AND PID.id.person = AP.id.person ");
			queryStringBuilder.append("AND AP.isFinanciallyResponsible = :yes ");
			queryStringBuilder.append("AND AP.id.account = A.id ");
			queryStringBuilder.append("AND A.customerClass IN (");
			for (int i = 0; i < customerClassOptions.size(); i++){
				queryStringBuilder.append(":customerClass" + i);

				if (i < customerClassOptions.size() - 1){
					queryStringBuilder.append(", ");
				}
			}
			queryStringBuilder.append(")");

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//Query query = createQuery(queryStringBuilder.toString());
			//Start Change - JLumbre - 2020-10-20 - CCB-017
			//Query query = createQuery(queryStringBuilder.toString(), getClass().getName());
			query = createQuery(queryStringBuilder.toString(), getClass().getName());
			//End Change - JLumbre - 2020-10-20 - CCB-017
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			query.bindId("ssnIdType", parmSsnIdType.getId());
			query.bindStringProperty("ssnIdNumber", PersonId.properties.personIdNumber, idNumber);
			query.bindBoolean("yes", Bool.TRUE);
			for (int i = 0; i < customerClassOptions.size(); i++){
				query.bindEntity("customerClass" + i, new CustomerClass_Id(customerClassOptions.get(i)).getEntity());
			}
			query.addResult("accountId", "AP.id.account");
			//Start Add - JLumbre - 2020-10-20 - CCB-017
		}
		//End Add - JLumbre - 2020-10-20 - CCB-017
		return query;
	}
	
	//Start Add - JLumbre - 2020-10-20 - CCB-017
	private String checkSSNForEncryption(String idNumber, String idType){
		log.debug(">>>>> idNumber: " + idNumber);
		String personId ="";
		
		BusinessServiceInstance getPerId = BusinessServiceInstance.create("CM-GetPersonByPerIdNumber");
		getPerId.set("idType", idType.trim());
		getPerId.set("perIdNbr", idNumber.trim());
		

		BusinessServiceInstance output = BusinessServiceDispatcher.execute(getPerId);
		Iterator<COTSInstanceListNode> resultList = output.getList("results").iterator();
		COTSInstanceListNode result;
		while (resultList.hasNext()){
			result = resultList.next();
			personId = result.getString("personId");
			log.debug(">>>>> encryptedPerIdNbr: " + personId);
		}
		log.debug(">>>>> outside encryptedPerIdNbr: " + personId);
		return personId;
		
	}
	//End Add - JLumbre - 2020-10-20 - CCB-017
	/**
	 * Retrieve and validate Input File Detail Record
	 */
	private void retrieveAndValidateInputFileDetailRecord(){

		parmSsnIdType = this.getParameters().getSSN_ID_TYPE();

		// Process each line of the file
		lineRead = readLine(bufferedReader);

		while (!isBlankOrNull(lineRead)) {

			procesInputFileRecord();
			lineRead = readLine(bufferedReader);
		}
		
	}

	/*
	 * MOL-IM-036193 Begin
	 */
	private void procesInputFileRecord(){

		lineNumber++;
		int num = lineRead.replaceAll("[^,]","").length();
		if (num < 4){
			addError(CustomMessageRepositoryMDC.ni0026_1_detailRecIncomplete(String.valueOf(lineNumber)));
		}

		CmEligibilityInputFileDetailRecord inputRecord = new CmEligibilityInputFileDetailRecord(lineRead);
		fileIdStr = inputRecord.getFileId();
		accountIdStr = inputRecord.getAccountId();
		applicantSSNStr = inputRecord.getApplicantSSN();
		coApplicantSSNStr = inputRecord.getCoApplicantSSN();
		// SA-223039 - 08/30/2017 - Start Add
		pledgeAmount = inputRecord.getPledgeAmount();
		// SA-223039 - 08/30/2017 - End Add
		
		// Process input Account ID, if provided
		if (notBlank(accountIdStr)){
			Account_Id accountId = new Account_Id(accountIdStr);
			//Start Change - RGoke - Defect 160127 - 2016-11-14
			Account account = null;
			try{
				account = accountId.getEntity();
			} catch (Exception e) {

				logInfo(CustomMessageRepositoryMGE
						.sa160127_accountIdArchived(accountIdStr));
				return;

			}
			//if (notNull(accountId.getEntity())){
			if (notNull(account)){
			//End Change - RGoke - Defect 160127 - 2016-11-14
			
				// If there isn't a duplicate, add the Account ID in the array
				if (!accountIds.contains(accountId)){
					accountIds.add(accountId);
					fileIds.add(fileIdStr);
					isSpecified.add(Bool.TRUE);
					// SA-223039 - 08/30/2017 - Start Add
					pledgeAmounts.add(pledgeAmount);
					// SA-223039 - 08/30/2017 - End Add
				}
			}
			else {
				/* MOL-IM-036193 Begin */
				// addError(CustomMessageRepositoryMDC.ni0026_1_InvalidInputAccountId(accountIdStr));
				return;
				/* MOL-IM-036193 End */
			}
		}

		// Process Account ID of Applicant SSN, if provided
		if (notBlank(applicantSSNStr)){
			Query getAccountsFromSSN = cmGetAccountsFromSSN(applicantSSNStr);

			if (notNull(getAccountsFromSSN)){
				QueryIterator itrAccounts = getAccountsFromSSN.iterate();
				while (itrAccounts.hasNext()){
					Account account = (Account) itrAccounts.next();

					// If there isn't a duplicate, add the Account ID in the array
					if (!accountIds.contains(account.getId())){
						accountIds.add(account.getId());
						fileIds.add(fileIdStr);
						isSpecified.add(Bool.FALSE);
						// SA-223039 - 08/30/2017 - Start Add
	                    pledgeAmounts.add(pledgeAmount);
	                    // SA-223039 - 08/30/2017 - End Add
					}
				}
			}
		}

		// Process Account ID of Co-Applicant SSN, if provided
		if (notBlank(coApplicantSSNStr)){
			Query getAccountsFromSSN = cmGetAccountsFromSSN(coApplicantSSNStr);

			if (notNull(getAccountsFromSSN)){
				QueryIterator itrAccounts = getAccountsFromSSN.iterate();
				while (itrAccounts.hasNext()){
					Account account = (Account) itrAccounts.next();

					// If there isn't a duplicate, add the Account ID in the array
					if (!accountIds.contains(account.getId())){
						accountIds.add(account.getId());
						fileIds.add(fileIdStr);
						isSpecified.add(Bool.FALSE);
						// SA-223039 - 08/30/2017 - Start Add
	                    pledgeAmounts.add(pledgeAmount);
	                    // SA-223039 - 08/30/2017 - End Add
					}
				}
			}
		}

	}

	public Class<CmProcessEAEligibilityFileBatchWorker> getThreadWorkerClass() {
		return CmProcessEAEligibilityFileBatchWorker.class;
	}

	public static class CmProcessEAEligibilityFileBatchWorker extends
	CmProcessEAEligibilityFileBatchWorker_Gen {

		// Batch Parameters
		private String parmInputFilePath;
		private String parmInputFileName;
		private String parmOutputFilePath;
		private String parmOutputFileName;
		private IdType parmSsnIdType;

		// 2013-05-08 SMiran Start Change
		//private FieldActivityType parmTurnOnFieldActivityType;
		//private FieldActivityType parmTurnOffFieldActivityType;
		private CharacteristicType parmFaTypeTurnOnCharType;
		private CharacteristicType parmFaTypeTurnOffCharType;
		// 2013-05-08 SMiran End Change
		private CharacteristicType parmFileIdCharType;
		private CharacteristicType parmAccountIdCharType;
		private CustomerContactClass parmContactClass;
		private String parmContactType;
		// SA-223039 - 08/30/2017 - Start Add
	    private CharacteristicType parmPledgeAmountCharType;
	    // SA-223039 - 08/30/2017 - End Add
	    
		// Work variables
		private BufferedReader bufferedReader;
		private BufferedWriter bufferedWriter;
		private File inputFile;
		private File outputFile;
		private String completeInputFileName;

		// 2013-11-06 - CVB - Start
		CmQuotePledgeRoutine quotePledgeRoutine = null;
		// 2013-11-06 - CVB - End

		private FeatureConfiguration parmFeatureConfiguration;
		private CaseType_Id diversionCaseTypeId;

		// String Constants
		private String DATE_FORMAT = "yyyy-MM-dd";
		private String METER_ON = "ON";
		private String METER_OFF = "OFF";
		private String METER_INSTALLED = "I";
		private String METER_UNINSTALLED = "R";
		private String YES_FLAG = "Y";
		private String NO_FLAG = "N";
		private String BLANK = "";
		private String FILE_HEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "\n"+ "<EaEligibility target = \"~server\" xmlns = \"\">";
		private String FILE_FOOTER = "</EaEligibility> ";
		private String ACCOUNT_LIST_HEADER = "<AccountList>";
		private String ACCOUNT_LIST_FOOTER = "</AccountList>";
		private String ACCOUNT_MAINT_HEADER = "<AccountMaintenance>";
		private String ACCOUNT_MAINT_FOOTER = "</AccountMaintenance>";
		private String ACCOUNT_PERSON_LIST_HEADER = "<AcctPersonList>";
		private String ACCOUNT_PERSON_LIST_FOOTER = "</AcctPersonList>";
		private String ACCOUNT_PERSON_HEADER = "<AcctPerson>";
		private String ACCOUNT_PERSON_FOOTER = "</AcctPerson>";
		private String MAILING_ADDRESS_HEADER = "<MailingAddress>";
		private String MAILING_ADDRESS_FOOTER = "</MailingAddress>";
		private String SA_LIST_HEADER = "<ServiceAgreementList>";
		private String SA_LIST_FOOTER = "</ServiceAgreementList>";
		private String SA_HEADER = "<ServiceAgreement>";
		private String SA_FOOTER = "</ServiceAgreement>";
		private String PREMISE_HEADER = "<Premise>";
		private String PREMISE_FOOTER = "</Premise>";
		private String SP_LIST_HEADER = "<ServicePointList>";
		private String SP_LIST_FOOTER = "</ServicePointList>";
		private String SP_HEADER = "<ServicePoint>";
		private String SP_FOOTER = "</ServicePoint>";
		private String CUSTOMER_CONTACT_DESCRIPTION = "Eligibility Under Review";

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
			// Retrieve Batch Parameters

			parmInputFilePath = this.getParameters().getINPUT_FILE_PATH();
			parmInputFileName = this.getParameters().getINPUT_FILE_NAME();
			parmOutputFilePath = this.getParameters().getOUTPUT_FILE_PATH();
			parmOutputFileName = this.getParameters().getOUTPUT_FILE_NAME();
			parmFeatureConfiguration = this.getParameters().getFEATURE_CONFIG();
			parmSsnIdType = this.getParameters().getSSN_ID_TYPE();
			// 2013-05-08 SMiran Start Change
			//parmTurnOnFieldActivityType = this.getParameters().getTONN_FA_TYPE();
			//parmTurnOffFieldActivityType = this.getParameters().getTOFF_FA_TYPE();
			parmFaTypeTurnOnCharType = this.getParameters().getFA_TYPE_TONN_CHAR_TYPE();
			parmFaTypeTurnOffCharType = this.getParameters().getFA_TYPE_TOFF_CHAR_TYPE();
			// 2013-05-08 SMiran End Change
			parmFileIdCharType = this.getParameters().getFILE_ID_CHAR_TYPE();
			parmAccountIdCharType = this.getParameters().getACCT_ID_CHAR_TYPE();
			parmContactClass = this.getParameters().getCONTACT_CLASS();
			parmContactType = this.getParameters().getCONTACT_TYPE();
			// SA-223039 - 08/30/2017 - Start Add
		    parmPledgeAmountCharType = this.getParameters().getPLEDGE_AMT_CHAR_TYPE();
		    // SA-223039 - 08/30/2017 - End Add
			
			// Setup variables
			bufferedReader = null;
			bufferedWriter = null;
			completeInputFileName = parmInputFilePath.concat(parmInputFileName);
			BigInteger threadNumber = this.getBatchThreadNumber();
			
			StringBuilder threadedOutputFileName = fileNameProcessing(parmOutputFileName);
			
			// Create the Output File
			try {
				outputFile = new File(parmOutputFilePath, threadedOutputFileName.toString().trim());
				/*
				 * MOL-IM-036193 Begin
				 * Do not append to file. Discard contents of existing file.
				 * */
				// bufferedWriter = new BufferedWriter(new FileWriter(outputFile.toString(), true));
				bufferedWriter = new BufferedWriter(new FileWriter(outputFile.toString(), false));
				/* MOL-IM-036193 End */
			} catch (IOException e) {
				e.printStackTrace();
			}

			if (threadNumber.equals(BigInteger.ONE)){
				// Print File Header
				writeLine(FILE_HEADER + "\n", bufferedWriter);

				// Print Account List Header
				writeLine(ACCOUNT_LIST_HEADER + "\n", bufferedWriter);
			}


			// 2013-11-06 - CVB - Start
			quotePledgeRoutine = CmQuotePledgeRoutine.Factory.newInstance();
			// 2013-11-06 - CVB - End

			// Retrieve and validate Diversion Case Type Code Feature Option
			Query getDiversionCaseType = cmGetFeatureConfigurationOptionValue(parmFeatureConfiguration,
					CmEAEligibilityLookup.constants.CASE_TYPE.getLookupValue().fetchIdFieldValue());

			// 2013-11-06 - CVB - Start
			Long getDiversionCaseTypeListSize = getDiversionCaseType.listSize();

			// Check if Option Value exists
			// if (getDiversionCaseType.listSize() == 0){
			if (getDiversionCaseTypeListSize == 0){
				// 2013-11-06 - CVB - End
				addError(CustomMessageRepositoryMDC.ni0026_1_FeatureConfigurationOptionValueIsRequired(parmFeatureConfiguration.getId().getIdValue(),
						CmEAEligibilityLookup.constants.CASE_TYPE.toLocalizedString()));
			}

			// Check if multiple Option Values exist
			// 2013-11-06 - CVB - Start
			// if (getDiversionCaseType.listSize() > 1){
			if (getDiversionCaseTypeListSize > 1){
				// 2013-11-06 - CVB - End
				addError(CustomMessageRepositoryMDC.ni0026_1_FeatureConfigurationMultipleOptionValues(parmFeatureConfiguration.getId().getIdValue(),
						CmEAEligibilityLookup.constants.CASE_TYPE.toLocalizedString()));
			}

			// Check if Option Value is a valid Case Type
			String caseTypeIdStr = (String) getDiversionCaseType.firstRow();
			diversionCaseTypeId = new CaseType_Id(caseTypeIdStr);
			if (isNull(diversionCaseTypeId.getEntity())){
				addError(CustomMessageRepositoryMDC.ni0026_1_FeatureConfigurationInvalidCaseType(parmFeatureConfiguration.getId().getIdValue(),
						caseTypeIdStr));
			}
		}
		
		private StringBuilder fileNameProcessing(String fileName) {
			
			StringBuilder newFileName = new StringBuilder(fileName);
			
			int fileNameLength = fileName.length();
			int threadNumber = 0;
			int threadDigit = 0;
			int wpos1 = 0;
			int wpos2 = 0;
			
			for (wpos1 = fileNameLength - 1; wpos1 >= 0; wpos1--){
			    if (fileName.charAt(wpos1) == '?') {
			    	//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			    	//threadNumber = this.getActiveBatchThread().getThreadNumber();
			    	threadNumber = getBatchThreadNumber().intValue();
			    	//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			    	for (wpos2 = wpos1; wpos2 >= 0; wpos2--){
			    		if (fileName.charAt(wpos2) != '?') {
			    			break;
			    		}
			    		threadDigit = threadNumber % 10;
			    	    threadNumber = threadNumber / 10;
			    	    newFileName.setCharAt(wpos2, Character.forDigit(threadDigit, 10) );
			    	}
		    	    if (threadNumber != 0) {
		    	    	addError(CustomMessageRepositoryMDC.commFileNameThreadDigitMissing());
		    	    }
		    	    wpos1 = wpos2;
			    }
			}
			return newFileName;
		}

		/*
		 * MOL-IM-036193 Begin
		 */
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
		throws ThreadAbortedException, RunAbortedException
		{

			// Initialize Variables      

			Account_Id accountId = (Account_Id) unit.getPrimaryId();
			String fileId = (String) unit.getSupplementallData("fileId");
			Bool isSpecified = (Bool) unit.getSupplementallData("isSpecifiedAccount");
			// SA-223039 - 08/30/2017 - Start Add
			String pledgeAmount = (String) unit.getSupplementallData("pledgeAmount");
			// SA-223039 - 08/30/2017 - End Add
			
			WorkUnitResult results = new WorkUnitResult(true);

			// Process Account details
			CmEligibilityAccountDetailRecord accountRecord = new CmEligibilityAccountDetailRecord();
			accountRecord.setAccountId(accountId.getTrimmedValue());
			// 2013-05-15 SMiran Start
			if (notNull(accountId.getEntity().fetchDivision())){
				accountRecord.setCisDivision(accountId.getEntity().fetchDivision().getId().getTrimmedValue());
			}else{
				accountRecord.setCisDivision("");
			}
			// 2013-05-15 SMiran End
			accountRecord.setCustomerClass(accountId.getEntity().getCustomerClass().getId().getTrimmedValue());

			// Write Account details
			writeLine(ACCOUNT_MAINT_HEADER + "\n", bufferedWriter);
			writeLine(accountRecord.createRecordString(), bufferedWriter);
			writeLine(ACCOUNT_PERSON_LIST_HEADER + "\n", bufferedWriter);

			// Process Account Persons
			processAccountPersons(accountId.getEntity());

			writeLine(ACCOUNT_PERSON_LIST_FOOTER + "\n", bufferedWriter);

			writeLine(SA_LIST_HEADER + "\n", bufferedWriter);
			processServiceAgreements(accountId.getEntity());
			writeLine(SA_LIST_FOOTER + "\n", bufferedWriter);

			writeLine(ACCOUNT_MAINT_FOOTER + "\n", bufferedWriter);

			// Check for the existence of Customer Contact for specified Account IDs only
			if (notBlank(fileId) && isSpecified.isTrue()){
				/*
				 * Defect 4136779 - 2018-10-15 - Start Change
				 */
				//Query checkExistingCustomerContact = cmCheckExistingCustomerContact(accountId.getEntity(), fileId);
				//
				//if (checkExistingCustomerContact.listSize() == 0){
				PreparedStatement checkExistingCustomerContact = cmCheckExistingCustomerContact(accountId.getEntity(), fileId);
				
				if(checkExistingCustomerContact.list().size() == 0){
				/*
				 * Defect 4136779 - 2018-10-15 - Start Change
				 */
					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					//ListFilter<AccountPerson> getMainAccountPerson = accountId.getEntity().getPersons().createFilter("WHERE this.isMainCustomer = :yes");
					ListFilter<AccountPerson> getMainAccountPerson = accountId.getEntity().getPersons().createFilter(
							"WHERE this.isMainCustomer = :yes", getClass().getName());
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					getMainAccountPerson.bindBoolean("yes", Bool.TRUE);
					AccountPerson mainAccountPerson = getMainAccountPerson.firstRow();

					// If none exists yet, create a new Customer Contact
					// SA-223039 - 08/30/2017 - Start Change
					//addCustomerContact(accountId.getEntity(), mainAccountPerson.fetchIdPerson().getId(), fileId);
					addCustomerContact(accountId.getEntity(), mainAccountPerson.fetchIdPerson().getId(), fileId, pledgeAmount);
					// SA-223039 - 08/30/2017 - End Change
				}
			}

			results.setUnitsProcessed(1);
			results.setUnitsInError(0);

			return results;
		}
		/*
		 * MOL-IM-036193 End
		 */

		//TODO Need extra testing for Zero Functionality Upgrade.
		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//int threadCount = this.getActiveBatchThread().getThreadCount();
			//int threadNumber = this.getActiveBatchThread().getThreadNumber();
			int threadCount = this.getParameters().getThreadCount().intValue();
			int threadNumber = getBatchThreadNumber().intValue();
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			
			if (threadNumber == threadCount){
				// Account List Footer
				writeLine(ACCOUNT_LIST_FOOTER + "\n", bufferedWriter);

				// Print File Footer
				writeLine(FILE_FOOTER, bufferedWriter);
			}
			
			// Close the Output file
			try{
				bufferedWriter.close();
			} 
			catch(IOException e){
				addError(CustomMessageRepositoryMDC.ni0026_1_ErrorInClosingFile(outputFile.getAbsolutePath()));
			}

		}

		/**
		 * Get the Feature Configuration Option Value
		 * @param featureConfiguration FeatureConfiguration
		 * @param optionType String
		 * @return query Query
		 */
		private Query cmGetFeatureConfigurationOptionValue(FeatureConfiguration featureConfiguration, String optionType) {
			Query query = createQuery("FROM FeatureConfigurationOption FCO "
					+ "WHERE FCO.id.workforceManagementSystem = :featConfName "
					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					//+ "AND FCO.id.optionType = :optionType ");
					+ "AND FCO.id.optionType = :optionType ", getClass().getName());
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			query.bindEntity("featConfName", featureConfiguration);
			query.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, optionType);
			query.addResult("optionValue", "FCO.value");

			return query;
		}



		private ServiceAgreement getRelatedSPBasedSA(ServiceAgreement sa){

			// Retrieve open Cases
			PreparedStatement getRelatedSA = createPreparedStatement(
					" SELECT SA2.SA_ID " +
					" FROM CI_SA SA1 " +
					"     ,CI_SA SA2 " +
					" WHERE SA1.char_prem_id = sa2.char_prem_id " +
					"   AND SA1.ACCT_ID = SA2.ACCT_ID " +
					"   AND EXISTS (SELECT 'X' " +
					"               FROM CI_SA_SP SASP " +
					"               WHERE SASP.SA_ID = SA2.SA_ID) " +
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//"   AND SA1.SA_ID = :sa ");
			"   AND SA1.SA_ID = :sa ",  getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			
			getRelatedSA.bindEntity("sa", sa);

			SQLResultRow sqlRR = getRelatedSA.firstRow();
			if (notNull(sqlRR)) {
				return sqlRR.getEntity("SA_ID", ServiceAgreement.class);
			} else {
				return null;
			}

		}
		/*
		 * MOL-IM-036193 End
		 */

		/**
		 * Process Account Persons
		 * @param account Account
		 */
		private void processAccountPersons(Account account){
			// Retrieve Account Persons of the Account
			Iterator itrAccountPersons = account.getPersons().iterator();

			while (itrAccountPersons.hasNext()){
				AccountPerson accountPerson = (AccountPerson) itrAccountPersons.next();
				Person person = accountPerson.fetchIdPerson();

				// Retrieve Primary Name
				//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				//ListFilter<PersonNames> listFilterPrimaryName = person.getNames().createFilter("WHERE this.isPrimaryName = :yes");
				ListFilter<PersonNames> listFilterPrimaryName = person.getNames().createFilter("WHERE this.isPrimaryName = :yes", getClass().getName());
				//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				listFilterPrimaryName.bindBoolean("yes", Bool.TRUE);
				String personPrimaryName = ((PersonName) listFilterPrimaryName.firstRow()).getEntityName();

				// Retrieve Social Security Number
				//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				//ListFilter<PersonIds> listFilterSsnId = person.getIds().createFilter("WHERE this.id.idType = :ssnId");
				ListFilter<PersonIds> listFilterSsnId = person.getIds().createFilter("WHERE this.id.idType = :ssnId", getClass().getName());
				//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				listFilterSsnId.bindId("ssnId", parmSsnIdType.getId());
				String ssn = BLANK;
				if (listFilterSsnId.listSize() != 0){
					//Start Change - JLumbre - 2020-10-20 - CCB-017
					//ssn = ((PersonId) listFilterSsnId.firstRow()).getPersonIdNumber();
					String encrPerId =  ((PersonId) listFilterSsnId.firstRow()).getEncryptedIdNumber();
					if (!isBlankOrNull(encrPerId)){
	                	String plainPerId = "";
	                	try {
	                            FieldEncryptionDecryptionData decryptData = FieldEncryptionDecryptionData.Factory.newInstance();
	                            decryptData.setTableName("CI_PER_ID");
	                            decryptData.setFieldName("PER_ID_NBR");
	                            decryptData.setCipherText(encrPerId);
	                            decryptData.setFilterField("ID_TYPE_CD");
	                            decryptData.setFilterValue(parmSsnIdType.getId().getTrimmedValue());

	                            FieldEncryptionDecryption decrypt = FieldEncryptionDecryption.Factory.newInstance(); 
	                            DecryptedValue decryptedValue = decrypt.decrypt(decryptData); 

	                            plainPerId = decryptedValue.getBuffer().toString().trim(); 
	                            ssn = plainPerId;

	                        } catch (Exception e) {
	                        	 ssn = plainPerId;
	                        }	                	
	                }
					else{
						ssn = ((PersonId) listFilterSsnId.firstRow()).getPersonIdNumber();
					}
					//End Change - JLumbre - 2020-10-20 - CCB-017 					
				}

				CmEligibilityAccountPersonDetailRecord accountPersonRecord = new CmEligibilityAccountPersonDetailRecord();
				accountPersonRecord.setPersonId(person.getId().getTrimmedValue());
				accountPersonRecord.setPersonName(personPrimaryName.trim());
				accountPersonRecord.setAccountRelationshipType(accountPerson.getAccountRelationshipType().getId().getTrimmedValue());
				accountPersonRecord.setSSN(ssn);              

				// Write Account Person details
				writeLine(ACCOUNT_PERSON_HEADER + "\n", bufferedWriter);
				writeLine(accountPersonRecord.createRecordString(), bufferedWriter);
				processMailingAddress(accountPerson);
				writeLine(ACCOUNT_PERSON_FOOTER + "\n", bufferedWriter);
			}

		}

		/**
		 * Process Service Agreements
		 * @param account Account
		 */
		private void processServiceAgreements(Account account){
			Query getServiceAgreementsOfAccount = cmGetServiceAgrementsOfAccount(account);
			Iterator itrAccountSas = getServiceAgreementsOfAccount.iterate();
			while (itrAccountSas.hasNext()){
				ServiceAgreement_Id saId = (ServiceAgreement_Id) itrAccountSas.next();
				ServiceAgreement sa = saId.getEntity();

				// Retrieve Write-Off Amount, if applicable
				Money writeOffAmount = Money.ZERO;
				if (cmGetWriteOffAmountOfSa(account, sa).listSize() != 0){
					writeOffAmount = (Money) cmGetWriteOffAmountOfSa(account, sa).firstRow();
				}

				// Retrieve existing Customer Contact, if applicable
				String okToTONN = NO_FLAG;
				/*
				 * MOL-IM-036193 Begin
				 * Note: Converted Write Off SAs are not eligible for EA so okToTONN will always be N for them.
				 */
				//
				// SA has Premise
				/* MOL-20130821 Begin */
				if (notNull(sa.getPremiseId())) {
					/* MOL-20130821 End */

					Date stopDate = null;

					try {
						// SA does not have an SA/SP
						if (sa.getServicePoints().isEmpty()) {
							ServiceAgreement otherSA = getRelatedSPBasedSA(sa);
							if (notNull(otherSA)) {
								stopDate = otherSA.getEndDate();
							}
						} else {
							stopDate = sa.getEndDate();
						}
					} catch (Exception e) {
						stopDate = null;
					}
					/* MOL-20130821  End */

					if (notNull(stopDate)) {
						/*
						 * Defect 4136779 reopen - 2018-10-18 - Start Change
						 */
						//Query getCustomerContactAfterStopDateOfSa = cmGetCustomerContactAfterStopDateOfSa(account, stopDate);
						//if (getCustomerContactAfterStopDateOfSa.listSize() > 0){
						PreparedStatement getCustomerContactAfterStopDateOfSa = cmGetCustomerContactAfterStopDateOfSa(account, stopDate);
						if (getCustomerContactAfterStopDateOfSa.list().size() > 0){
						/*
						 * Defect 4136779 reopen - 2018-10-18 - End Change
						 */
							okToTONN = YES_FLAG;
						}
					}
				}
				/*
				 * MOL-IM-036193 End
				 */

				// Retrieve Back-To-Back SA, if applicable
				String backToBack = NO_FLAG;
				Query checkBackToBackSa = cmCheckBackToBackSa(account, sa); 
				if (checkBackToBackSa.listSize() > 0){
					backToBack = YES_FLAG;
				}

				// CVB - 2013-09-05 - Start

				// Check if SA is eligible and try to activate a quote

				// 2013-11-06 - CVB - Start
				// CmQuotePledgeRoutine quotePledgeRoutine = CmQuotePledgeRoutine.Factory.newInstance();
				// 2013-11-06 - CVB - End
				quotePledgeRoutine.setServiceAgreement(sa);
				Bool saIsEligible = Bool.FALSE;

				try {
					saIsEligible = quotePledgeRoutine.checkIfSAIsEligibleForQuote();
				}
				catch (Exception e) {
				}

				Money downpaymentRemaining = Money.ZERO;
				Money unpaidPledgeAmount = Money.ZERO;
				Bool downpaymentRemainingComputed = Bool.FALSE;
				ServiceTask_Id quoteServiceTaskId = null;
				DateTime quoteCreDttm = null;

				if (saIsEligible.isTrue()){
					// Create and Activate Quote
					try {
						quotePledgeRoutine.activateQuoteIfNoneExists();
						quoteServiceTaskId = quotePledgeRoutine.getQuoteServiceTaskId();
						quoteCreDttm = quotePledgeRoutine.getQuoteCreationDateTime();
					}
					catch (Exception e) {
					}
				}

				if (notNull(quoteServiceTaskId) && notNull(quoteCreDttm) ){
					try {
						downpaymentRemaining = quotePledgeRoutine.calculateDownpaymentRemaining(quoteServiceTaskId, quoteCreDttm);
						downpaymentRemainingComputed = Bool.TRUE;		
					}
					catch (Exception e){
					}
				}

				if (downpaymentRemainingComputed.isFalse()){
					try {
						unpaidPledgeAmount = quotePledgeRoutine.getUnpaidPledgeAmount(saId);
					}
					catch (Exception e) {
					}
					downpaymentRemaining = sa.getCurrentBalance().subtract(unpaidPledgeAmount);
					downpaymentRemainingComputed = Bool.TRUE;
				}

				// CVB - 2013-09-05 - End

				CmEligibilityServiceAgreementDetailRecord saRecord = new CmEligibilityServiceAgreementDetailRecord();
				saRecord.setServiceAgreementId(saId.getTrimmedValue());
				saRecord.setCisDivision(sa.getServiceAgreementType().fetchIdDivision().getId().getTrimmedValue());
				saRecord.setCurrentBalance(sa.getFinancialBalances().getCurrentAmount().getAmount().toString().trim());
				saRecord.setPayoffBalance(sa.getFinancialBalances().getTotalAmount().getAmount().toString().trim());
				saRecord.setWriteOffAmount(writeOffAmount.getAmount().toString().trim());
				saRecord.setSAType(sa.getServiceAgreementType().getId().getSaType().trim());
				saRecord.setSATypeDescription(sa.getServiceAgreementType().fetchLanguageDescription().trim());
				saRecord.setSAStatus(sa.getStatus().getLookupValue().fetchIdFieldValue().trim());
				saRecord.setSAStatusDescription(sa.getStatus().getLookupValue().fetchLanguageDescription().trim());
				saRecord.setStartDate(sa.getStartDate().toLocalizedString().trim());
				if (notNull(sa.getEndDate())){
					saRecord.setEndDate(sa.getEndDate().toLocalizedString().trim());    
				}
				else {
					saRecord.setEndDate(BLANK);
				}
				saRecord.setOldAccountId(sa.getOldAccountId().trim());
				saRecord.setOKToTONN(okToTONN);
				saRecord.setBackToBack(backToBack);

				// CVB - 2013-09-05 - Start
				saRecord.setDownpaymentRemainingAmount(downpaymentRemaining.getAmount().toString().trim());
				// CVB - 2013-09-05 - End

				// Write Service Agreement details
				writeLine(SA_HEADER + "\n", bufferedWriter);
				writeLine(saRecord.createRecordString(), bufferedWriter);

				if (backToBack.equalsIgnoreCase(NO_FLAG)){
					processPremise(sa);
					writeLine(SP_LIST_HEADER + "\n", bufferedWriter);
					processServicePoint(sa);
					writeLine(SP_LIST_FOOTER + "\n", bufferedWriter);
				}

				writeLine(SA_FOOTER + "\n", bufferedWriter);
			}
		}

		/**
		 * Process Mailing Address
		 * @param person Person
		 */
		private void processMailingAddress(AccountPerson accountPerson){
			CmEligibilityMailingAddressDetailRecord mailingAddressRecord = new CmEligibilityMailingAddressDetailRecord();

			AccountMailingAddressRetriever amar = AccountMailingAddressRetriever.Factory.newInstance();

			// 2013-11-06 - CVB - Start
			// Create a To Do if Mailing Address was not found for the Account.

			AccountMailingAddressData amad = null;
			try {
				amad = amar.getAccountMailingAddress(accountPerson.fetchIdAccount(), accountPerson.fetchIdPerson());

				mailingAddressRecord.setAddress1(amad.getAddress1().trim());
				mailingAddressRecord.setAddress2(amad.getAddress2().trim());
				mailingAddressRecord.setCity(amad.getCity().trim());
				if (notNull(amad.getState())){
					mailingAddressRecord.setState(amad.getState().getId().getState().trim());
				}
				else {
					mailingAddressRecord.setState(BLANK);
				}
				mailingAddressRecord.setPostalCode(amad.getPostalCode().trim());    

			}
			catch (ApplicationError ae) {
				createToDo(accountPerson.fetchIdAccount().getId().getTrimmedValue());

				mailingAddressRecord.setAddress1(BLANK);
				mailingAddressRecord.setAddress2(BLANK);
				mailingAddressRecord.setCity(BLANK);
				mailingAddressRecord.setState(BLANK);
				mailingAddressRecord.setPostalCode(BLANK);    

			}

			// 2013-11-06 - CVB - End

			writeLine(MAILING_ADDRESS_HEADER + "\n", bufferedWriter);
			writeLine(mailingAddressRecord.createRecordString(), bufferedWriter);
			writeLine(MAILING_ADDRESS_FOOTER + "\n", bufferedWriter);
		}

		/**
		 * Process Premise
		 * @param sa ServiceAgreement
		 */
		private void processPremise(ServiceAgreement sa){
			QueryResultRow qrrMostRecentPremise = (QueryResultRow) cmGetMostRecentPremise(sa).firstRow();

			if (notNull(qrrMostRecentPremise)){
				Premise premise = (Premise) qrrMostRecentPremise.getEntity("premise", Premise.class);

				// Retrieve Diverson Case on Premise, if applicable
				Query getOpenDiversionCaseOnPremise = cmGetOpenDiversionCaseOnPremise(premise.getId());
				String diversionCase = NO_FLAG;
				if (getOpenDiversionCaseOnPremise.listSize() > 0){
					diversionCase = YES_FLAG;
				}

				CmEligibilityPremiseDetailRecord premiseRecord = new CmEligibilityPremiseDetailRecord();
				premiseRecord.setPremiseId(premise.getId().getTrimmedValue());
				premiseRecord.setAddress1(premise.getAddress1().trim());
				premiseRecord.setAddress2(premise.getAddress2().trim());
				premiseRecord.setCity(premise.getCity().trim());
				premiseRecord.setState(premise.getState().trim());
				premiseRecord.setPostalCode(premise.getPostal().trim());
				premiseRecord.setDiversionCase(diversionCase);

				writeLine(PREMISE_HEADER + "\n", bufferedWriter);
				writeLine(premiseRecord.createRecordString(), bufferedWriter);
				writeLine(PREMISE_FOOTER + "\n", bufferedWriter);
			}
		}

		/**
		 * Process Service Point
		 * @param sa ServiceAgreement
		 */
		private void processServicePoint(ServiceAgreement sa){
			Iterator itrSaServicePoints = sa.getServicePoints().iterator();
			while (itrSaServicePoints.hasNext()){
				ServiceAgreementServicePoint saSp = (ServiceAgreementServicePoint) itrSaServicePoints.next();
				ServicePoint sp = saSp.getServicePoint();

				// Retrieve Field Activites, if applicable                
				// 2013-05-08 SMiran Start Change
				//Query getLatestTONNDate = cmGetFieldActivityOnSP(sp, parmTurnOnFieldActivityType);
				Query getLatestTONNDate = cmGetFieldActivityOnSP(sp, parmFaTypeTurnOnCharType);
				// 2013-05-08 SMiran End Change
				DateTime latestTONNDttm = (DateTime) getLatestTONNDate.firstRow();
				// 2013-05-08 SMiran Start Change
				//Query getLatestTOFFDate = cmGetFieldActivityOnSP(sp, parmTurnOffFieldActivityType);
				Query getLatestTOFFDate = cmGetFieldActivityOnSP(sp, parmFaTypeTurnOffCharType);
				// 2013-05-08 SMiran End Change
				DateTime latestTOFFDttm = (DateTime) getLatestTOFFDate.firstRow();

				DateFormat dateFormat = new DateFormat(DATE_FORMAT);
				String latestTONNDate = BLANK;
				String latestTOFFDate = BLANK;
				if (notNull(latestTONNDttm)){
					latestTONNDate = latestTONNDttm.toString(dateFormat);    
				}
				if (notNull(latestTOFFDttm)){
					latestTOFFDate = latestTOFFDttm.toString(dateFormat);
				}

				// Retrieve Meter information
				String meterStatus;
				String meterInstallStatus;
				Query queryMeterInstallStatus = cmGetMeterInstallStatus(sp);
				if (queryMeterInstallStatus.listSize() == 0){
					meterStatus = METER_OFF;
					meterInstallStatus = METER_UNINSTALLED;
				}
				else {
					meterInstallStatus = METER_INSTALLED;

					QueryResultRow qrrSPMeterHistory = (QueryResultRow) cmGetSPMeterHistory(sp).firstRow();

					MeterOnOffStatusLookup meterOnOffStatus = (MeterOnOffStatusLookup) qrrSPMeterHistory.getLookup("meterOnOffStatus", MeterOnOffStatusLookup.class);

					if (meterOnOffStatus.getLookupValue().equals(MeterOnOffStatusLookup.constants.ON.getLookupValue())){
						meterStatus = METER_ON;
					} 
					else {
						meterStatus = METER_OFF; 
					}
				}

				CmEligibilityServicePointDetailRecord spRecord = new CmEligibilityServicePointDetailRecord();
				spRecord.setServicePointId(sp.getId().getTrimmedValue());
				spRecord.setServicePointStatus(sp.getServicePointStatus().getLookupValue().fetchIdFieldValue().trim());
				spRecord.setServicePointStatusDescription(sp.getServicePointStatus().getLookupValue().fetchLanguageDescription().trim());
				spRecord.setServicePointSourceStatus(sp.getServicePointSourceStatus().getLookupValue().fetchIdFieldValue().trim());
				spRecord.setLatestTONNDate(latestTONNDate);
				spRecord.setLatestTOFFDate(latestTOFFDate);
				spRecord.setMeterStatus(meterStatus);
				spRecord.setMeterInstallStatus(meterInstallStatus);

				writeLine(SP_HEADER + "\n", bufferedWriter);
				writeLine(spRecord.createRecordString(), bufferedWriter);
				writeLine(SP_FOOTER + "\n", bufferedWriter);  

			}
		}

		/**
		 * Write a line to the Buffered Reader
		 * @param data String
		 * @param bufferedWriter BufferedWriter
		 */
		private void writeLine(String data, BufferedWriter bufferedWriter){
			try {
				if (isBlankOrNull(data)){
					bufferedWriter.newLine();
				}
				else {
					bufferedWriter.write(data);
				}                
			} catch(IOException ioe){
				addError(CustomMessageRepositoryMDC.ni0026_1_ErrorInWritingFile(outputFile.getAbsolutePath()));
			}
		}

		/**
		 * Add a new Customer Contact
		 * @param account Account
		 * @param personId Person_Id
		 * @param fileId String
		 * @param pledgeAmount String
		 */
		// SA-223039 - 08/30/2017 - Start Change
		//private void addCustomerContact(Account account, Person_Id personId, String fileId){
		private void addCustomerContact(Account account, Person_Id personId, String fileId, String pledgeAmount){
		// SA-223039 - 08/30/2017 - End Change
		    
			CustomerContact_DTO customerContactDto = (CustomerContact_DTO) createDTO(CustomerContact.class);
			customerContactDto.setCustomerContactTypeId(new CustomerContactType_Id(parmContactClass, parmContactType));
			customerContactDto.setLongDescription(CUSTOMER_CONTACT_DESCRIPTION);
			customerContactDto.setPersonId(personId);
			customerContactDto.setContactDateTime(getProcessDateTime());
			// SA-223039 - 08/30/2017 - Start Add
			customerContactDto.setLongDescription(CustomMessageRepository.SA_223039_eligibilityUnderReview(pledgeAmount).getMessageText());
			// SA-223039 - 08/30/2017 - End Add
			CustomerContact newCustomerContact = customerContactDto.newEntity();

			// Add File ID Customer Contact Characteristic
			CustomerContactCharacteristic_Id ccFileIdCharId = new CustomerContactCharacteristic_Id(parmFileIdCharType.getId(), newCustomerContact.getId());
			CustomerContactCharacteristic_DTO ccFileIdCharDto = new CustomerContactCharacteristic_DTO();   
			ccFileIdCharDto.setId(ccFileIdCharId);
			if (parmFileIdCharType.getCharacteristicType().isAdhocValue()){
				ccFileIdCharDto.setAdhocCharacteristicValue(fileId);
			}
			else if (parmFileIdCharType.getCharacteristicType().isForeignKeyValue()){
				ccFileIdCharDto.setCharacteristicValueForeignKey1(fileId);
			}
			else if (parmFileIdCharType.getCharacteristicType().isPredefinedValue()){
				ccFileIdCharDto.setCharacteristicValue(fileId);
			}
			ccFileIdCharDto.newEntity();

			// Add Account ID Customer Contact Characteristic
			CustomerContactCharacteristic_Id ccAccountIdCharId = new CustomerContactCharacteristic_Id(parmAccountIdCharType.getId(), newCustomerContact.getId());
			CustomerContactCharacteristic_DTO ccAccountIdCharDto = new CustomerContactCharacteristic_DTO();
			ccAccountIdCharDto.setId(ccAccountIdCharId);
			if (parmAccountIdCharType.getCharacteristicType().isAdhocValue()){
				ccAccountIdCharDto.setAdhocCharacteristicValue(account.getId().getTrimmedValue());
			}
			else if (parmAccountIdCharType.getCharacteristicType().isForeignKeyValue()){
				ccAccountIdCharDto.setCharacteristicValueForeignKey1(account.getId().getTrimmedValue());
			}
			else if (parmAccountIdCharType.getCharacteristicType().isPredefinedValue()){
				ccAccountIdCharDto.setCharacteristicValue(account.getId().getTrimmedValue());
			}
			ccAccountIdCharDto.newEntity();
			
			// SA-223039 - 08/30/2017 - Start Add
			// Add Plege Amount Customer Contact Characteristic
            CustomerContactCharacteristic_Id ccPledgeAmtIdCharId = new CustomerContactCharacteristic_Id(parmPledgeAmountCharType.getId(), newCustomerContact.getId());
            CustomerContactCharacteristic_DTO ccPledgeAmtIdCharDto = new CustomerContactCharacteristic_DTO();
            ccPledgeAmtIdCharDto.setId(ccPledgeAmtIdCharId);
            if (parmPledgeAmountCharType.getCharacteristicType().isAdhocValue()){
                ccPledgeAmtIdCharDto.setAdhocCharacteristicValue(pledgeAmount);
            }
            else if (parmPledgeAmountCharType.getCharacteristicType().isForeignKeyValue()){
                ccPledgeAmtIdCharDto.setCharacteristicValueForeignKey1(pledgeAmount);
            }
            else if (parmPledgeAmountCharType.getCharacteristicType().isPredefinedValue()){
                ccPledgeAmtIdCharDto.setCharacteristicValue(pledgeAmount);
            }
            ccPledgeAmtIdCharDto.newEntity();
            // SA-223039 - 08/30/2017 - End Add
		}

		/**
		 * Get the SAs of the Account
		 * @param account Account
		 * @return query Query
		 */
		private Query cmGetServiceAgrementsOfAccount(Account account) {
			Query query = createQuery("FROM ServiceAgreement SA "
					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					//+ "WHERE SA.account = :account");
					+ "WHERE SA.account = :account", getClass().getName());
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			query.bindEntity("account", account);
			query.addResult("saId", "SA.id");

			return query;
		}

		/**
		 * Get the Write-Off Amount of the SA
		 * @param account Account
		 * @param sa ServiceAgreement
		 * @return query Query
		 */
		private Query cmGetWriteOffAmountOfSa(Account account, ServiceAgreement sa) {
			Query query = createQuery("FROM WriteOffProcess WP, WriteOffProcessServiceAgreement WPSA "
					+ "WHERE WP.account = :account "
					+ "AND WP.id = WPSA.id.writeOffProcess "
					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					//+ "AND WPSA.id.serviceAgreement = :sa");
					+ "AND WPSA.id.serviceAgreement = :sa", getClass().getName());
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			query.bindEntity("account", account);
			query.bindEntity("sa", sa);
			query.addResult("writeOffAmount", "WPSA.arrearsAmount");

			return query;
		}

		/**
		 * Get the Customer Contact after a specified Date
		 * @param account Account
		 * @param endDate Date
		 * @return query Query
		 */
		/*
		 * Defect 4136779 reopen - 2018-10-18 - Start Change
		 */
		//private Query cmGetCustomerContactAfterStopDateOfSa(Account account, Date endDate) {
		//	Query query = createQuery("FROM CustomerContact CC, AccountPerson AP "
		//			+ "WHERE CC.contactDateTime > :endDate "
		//			+ "AND CC.person = AP.id.person "
		//			/* MOL-IM-036193 Begin */
		//			+ "AND CC.customerContactType.id.contactClass = :okToTurnOnCustomerContactClass "
		//			/* MOL-IM-036193 End */
		//			+ "AND AP.id.account = :account "
		//			+ "AND AP.isMainCustomer = :yes "
		//			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//			//+ "AND AP.isFinanciallyResponsible = :yes");
		//			+ "AND AP.isFinanciallyResponsible = :yes", getClass().getName());
		//			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//	query.bindDate("endDate", endDate);
		//	query.bindEntity("account", account);
		//	query.bindBoolean("yes", Bool.TRUE);
		//	/* MOL-IM-036193 Begin */
		//	query.bindEntity("okToTurnOnCustomerContactClass", getParameters().getOK_TO_TONN_CONTACT_CLASS());
		//	/* MOL-IM-036193 End */
		//	query.addResult("ccId", "CC.id");
		//
		//	return query;
		//}
		private PreparedStatement cmGetCustomerContactAfterStopDateOfSa(Account account, Date endDate) {
			StringBuilder cmGetCustomerContactAfterStopDateOfSaStr = new StringBuilder();
			cmGetCustomerContactAfterStopDateOfSaStr.append("SELECT ");
			cmGetCustomerContactAfterStopDateOfSaStr.append(  "CC.CC_ID ");
			cmGetCustomerContactAfterStopDateOfSaStr.append("FROM ");
			cmGetCustomerContactAfterStopDateOfSaStr.append(  "CI_CC CC, ");
			cmGetCustomerContactAfterStopDateOfSaStr.append(  "CI_ACCT_PER AP ");
			cmGetCustomerContactAfterStopDateOfSaStr.append("WHERE ");
			cmGetCustomerContactAfterStopDateOfSaStr.append(  "CC.CC_DTTM > :endDate ");
			cmGetCustomerContactAfterStopDateOfSaStr.append(  "AND CC.PER_ID = AP.PER_ID ");
			cmGetCustomerContactAfterStopDateOfSaStr.append(  "AND CC.CC_CL_CD = :okToTurnOnCustomerContactClass ");
			cmGetCustomerContactAfterStopDateOfSaStr.append(  "AND AP.ACCT_ID = :account ");
			cmGetCustomerContactAfterStopDateOfSaStr.append(  "AND AP.MAIN_CUST_SW = :yes ");
			cmGetCustomerContactAfterStopDateOfSaStr.append(  "AND AP.FIN_RESP_SW = :yes ");
			
			PreparedStatement cmGetCustomerContactAfterStopDateOfSaStrQuery = createPreparedStatement(cmGetCustomerContactAfterStopDateOfSaStr.toString()
					, getClass().getName());
			
			cmGetCustomerContactAfterStopDateOfSaStrQuery.bindDate("endDate", endDate);
			cmGetCustomerContactAfterStopDateOfSaStrQuery.bindEntity("account", account);
			cmGetCustomerContactAfterStopDateOfSaStrQuery.bindBoolean("yes", Bool.TRUE);
			cmGetCustomerContactAfterStopDateOfSaStrQuery.bindEntity("okToTurnOnCustomerContactClass", getParameters().getOK_TO_TONN_CONTACT_CLASS());

			return cmGetCustomerContactAfterStopDateOfSaStrQuery;
		}
		/*
		 * Defect 4136779 reopen - 2018-10-18 - End Change
		 */

		/**
		 * Get the Back-To-Back SA 
		 * @param account Account
		 * @param sa ServiceAgreement
		 * @return query Query
		 */
		private Query cmCheckBackToBackSa(Account account, ServiceAgreement sa) {
			Query query = createQuery("FROM ServiceAgreementServicePoint SASP, ServiceAgreementServicePoint SASP1, ServiceAgreement SA "
					+ "WHERE SASP.serviceAgreement = :sa "
					+ "AND SASP.startDateTime = (SELECT MAX(SASP2.startDateTime) "
					+ "FROM ServiceAgreementServicePoint SASP2 "
					+ "WHERE SASP.serviceAgreement = SASP2.serviceAgreement "
					+ "AND SASP2.startDateTime <= :processDateTime) "
					+ "AND SASP.stopDateTime IS NOT NULL "
					+ "AND SASP.servicePoint = SASP1.servicePoint "
					+ "AND SASP1.serviceAgreement = SA.id "
					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					//+ "AND SA.account != :account");
					+ "AND SA.account != :account", getClass().getName());
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			query.bindEntity("sa", sa);
			query.bindDateTime("processDateTime", getProcessDateTime());
			query.bindEntity("account", account);
			query.addResult("saId", "SA.id");

			return query;
		}

		/**
		 * Get the most recent Premise of an SA
		 * @param sa ServiceAgreement
		 * @return query Query
		 */
		private Query cmGetMostRecentPremise(ServiceAgreement sa) {
			Query query = createQuery("FROM ServicePoint SP, ServiceAgreementServicePoint SASP "
					+ "WHERE SASP.serviceAgreement = :sa  "
					+ "AND SASP.startDateTime <= :processDateTime "
					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					//+ "AND SASP.servicePoint = SP.id");
					+ "AND SASP.servicePoint = SP.id", getClass().getName());
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			query.bindEntity("sa", sa);
			query.bindDateTime("processDateTime", getProcessDateTime());
			query.addResult("premise", "SP.premise");
			query.addResult("startDateTime", "SASP.startDateTime");
			query.orderBy("startDateTime", Query.DESCENDING);

			return query;
		}

		/**
		 * Get the open Diversion Case on a Premise 
		 * @param premiseId Premise_Id
		 * @return query Query
		 */
		private Query cmGetOpenDiversionCaseOnPremise(Premise_Id premiseId) {
			Query query = createQuery("FROM ToDoCase C "
					+ "WHERE C.premiseId = :premiseId "
					+ "AND C.caseCondition = :open "
					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					//+ "AND C.caseStatus.id.caseType.id = :caseTypeId");
					+ "AND C.caseStatus.id.caseType.id = :caseTypeId", getClass().getName());
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			query.bindId("premiseId", premiseId);
			query.bindLookup("open", CaseConditionLookup.constants.OPEN);
			query.bindId("caseTypeId", diversionCaseTypeId);
			query.addResult("premise", "SP.premise");

			return query;
		}

		/**
		 * Get the Field Activity on the SP
		 * @param sp ServicePoint
		 * @param faType FieldActivityType
		 * @return query Query
		 */
		// 2013-05-08 SMiran Start Change
		//private Query cmGetFieldActivityOnSP(ServicePoint sp, FieldActivityType faType) {
		private Query cmGetFieldActivityOnSP(ServicePoint sp, CharacteristicType faTypeCharType) {
			// 2013-05-08 SMiran End Change            
			Query query = createQuery("FROM FieldActivity FA "
					+ "WHERE FA.servicePoint = :sp "
					// 2013-05-08 SMiran Start Change
					//+ "AND FA.fieldActivityType = :faType");
					+ "AND FA.fieldActivityType IN (SELECT FATC.id.fieldActivityType " +
					"FROM FieldActivityTypeCharacteristic FATC " +
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//"WHERE FATC.id.characteristicType = :charType)");
					"WHERE FATC.id.characteristicType = :charType)", getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			// 2013-05-08 SMiran End Change
			query.bindEntity("sp", sp);
			// 2013-05-08 SMiran Start Change
			//query.bindEntity("faType", faType);
			query.bindEntity("charType", faTypeCharType);
			// 2013-05-08 SMiran End Change
			query.addResult("creationDateTime", "FA.creationDateTime");
			query.orderBy("creationDateTime", Query.DESCENDING);

			return query;
		}

		/**
		 * Get the SP-Meter Installation History
		 * @param sp ServicePoint
		 * @return query Query
		 */
		private Query cmGetSPMeterHistory(ServicePoint sp) {
			Query query = createQuery("FROM ServicePointMeterHistory SPMH, ServicePointMeterEvent SPME "
					+ "WHERE SPMH.servicePoint = :sp "
					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					//+ "AND SPMH.id = SPME.id.spMeterHistory");
					+ "AND SPMH.id = SPME.id.spMeterHistory", getClass().getName());
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			query.bindEntity("sp", sp);
			query.addResult("meterOnOffStatus", "SPME.meterOnOffStatus");
			query.addResult("sequence", "SPME.id.sequence");
			query.orderBy("sequence", Query.DESCENDING);

			return query;
		}

		/**
		 * Get the installation status of the Meters on the SP 
		 * @param sp ServicePoint
		 * @return query Query
		 */
		private Query cmGetMeterInstallStatus(ServicePoint sp) {
			Query query = createQuery("FROM ServicePointMeterHistory SPMH "
					+ "WHERE SPMH.servicePoint = :sp  "
					+ "AND (SPMH.removalDateTime IS NULL " 
					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					//+ "OR SPMH.removalDateTime > :processDateTime)");
					+ "OR SPMH.removalDateTime > :processDateTime)", getClass().getName());
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			query.bindEntity("sp", sp);
			query.bindDateTime("processDateTime", getProcessDateTime());
			query.addResult("meterConfiguration", "SPMH.meterConfiguration");

			return query;
		}

		/**
		 * Get the existing Customer Contact
		 * @param account Account
		 * @param fileId String
		 * @return query Query
		 */
		/*
		 * Defect 4136779 - 2018-10-15 - Start Change
		 */
		//private Query cmCheckExistingCustomerContact(Account account, String fileId) {
		//	Query query = createQuery("FROM CustomerContact CC, AccountPerson AP, "
		//			+ "CustomerContactCharacteristic CCC1, CustomerContactCharacteristic CCC2 "
		//			+ "WHERE CC.customerContactType.id.contactType = :contactType "
		//			+ "AND CC.customerContactType.id.contactClass = :contactClass "
		//			+ "AND CC.person = AP.id.person "
		//			+ "AND AP.id.account = :account "
		//			+ "AND AP.isMainCustomer = :yes "
		//			+ "AND AP.isFinanciallyResponsible = :yes "
		//			+ "AND CC.id = CCC1.id.customerContact "
		//			+ "AND CCC1.id.characteristicType = :fileIdCharType "
		//			+ "AND (CCC1.characteristicValue = :charValue1 "
		//			+ "OR CCC1.adhocCharacteristicValue = :adhocCharValue1 "
		//			+ "OR CCC1.characteristicValueForeignKey1 = :fkCharValue1) "
		//			+ "AND CC.id = CCC2.id.customerContact "
		//			+ "AND CCC2.id.characteristicType = :accountIdCharType "
		//			+ "AND (CCC2.characteristicValue = :charValue2 "
		//			+ "OR CCC2.adhocCharacteristicValue = :adhocCharValue2 "
		//			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//			//+ "OR CCC2.characteristicValueForeignKey1 = :fkCharValue2)");
		//			+ "OR CCC2.characteristicValueForeignKey1 = :fkCharValue2)", getClass().getName());
		//			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//	query.bindStringProperty("contactType", CustomerContactType.properties.contactType, parmContactType.trim());
		//	query.bindEntity("contactClass", parmContactClass);
		//	query.bindEntity("account", account);
		//	query.bindBoolean("yes", Bool.TRUE);
		//	query.bindEntity("fileIdCharType", parmFileIdCharType);
		//	query.bindStringProperty("charValue1", CustomerContactCharacteristic.properties.characteristicValue, fileId);
		//	query.bindStringProperty("adhocCharValue1", CustomerContactCharacteristic.properties.adhocCharacteristicValue, fileId);
		//	query.bindStringProperty("fkCharValue1", CustomerContactCharacteristic.properties.characteristicValueForeignKey1, fileId);
		//	query.bindEntity("accountIdCharType", parmAccountIdCharType);
		//	query.bindStringProperty("charValue2", CustomerContactCharacteristic.properties.characteristicValue, account.getId().getTrimmedValue());
		//	query.bindStringProperty("adhocCharValue2", CustomerContactCharacteristic.properties.adhocCharacteristicValue, account.getId().getTrimmedValue());
		//	query.bindStringProperty("fkCharValue2", CustomerContactCharacteristic.properties.characteristicValueForeignKey1, account.getId().getTrimmedValue());
		//	query.addResult("ccId", "CC.id");
		//
		//	return query;
		//}
		private PreparedStatement cmCheckExistingCustomerContact(Account account, String fileId) {
			StringBuilder cmCheckExistingCustomerContactStr = new StringBuilder();
			
			cmCheckExistingCustomerContactStr.append("SELECT ");
			cmCheckExistingCustomerContactStr.append(  "CC.CC_ID ");
			cmCheckExistingCustomerContactStr.append("FROM ");
			cmCheckExistingCustomerContactStr.append(  "CI_CC CC, ");
			cmCheckExistingCustomerContactStr.append(  "CI_ACCT_PER AP, ");
			cmCheckExistingCustomerContactStr.append(  "CI_CC_CHAR CCC1, ");
			cmCheckExistingCustomerContactStr.append(  "CI_CC_CHAR CCC2 ");
			cmCheckExistingCustomerContactStr.append("WHERE ");
			cmCheckExistingCustomerContactStr.append(  "CC.CC_TYPE_CD = :contactType ");
			cmCheckExistingCustomerContactStr.append(  "AND CC.CC_CL_CD = :contactClass ");
			cmCheckExistingCustomerContactStr.append(  "AND CC.PER_ID = AP.PER_ID ");
			cmCheckExistingCustomerContactStr.append(  "AND AP.ACCT_ID = :account ");
			cmCheckExistingCustomerContactStr.append(  "AND AP.MAIN_CUST_SW = :yes ");
			cmCheckExistingCustomerContactStr.append(  "AND AP.FIN_RESP_SW = :yes ");
			cmCheckExistingCustomerContactStr.append(  "AND CC.CC_ID = CCC1.CC_ID ");
			cmCheckExistingCustomerContactStr.append(  "AND CCC1.CHAR_TYPE_CD = :fileIdCharType ");
			cmCheckExistingCustomerContactStr.append(  "AND (CCC1.CHAR_VAL = :charValue1 ");
			cmCheckExistingCustomerContactStr.append(        "OR CCC1.ADHOC_CHAR_VAL = :adhocCharValue1 ");
			cmCheckExistingCustomerContactStr.append(        "OR CCC1.CHAR_VAL_FK1 = :fkCharValue1) ");
			cmCheckExistingCustomerContactStr.append(  "AND CC.CC_ID = CCC2.CC_ID ");
			cmCheckExistingCustomerContactStr.append(  "AND CCC2.CHAR_TYPE_CD = :accountIdCharType ");
			cmCheckExistingCustomerContactStr.append(  "AND (CCC2.CHAR_VAL = :charValue2 ");
			cmCheckExistingCustomerContactStr.append(        "OR CCC2.ADHOC_CHAR_VAL = :adhocCharValue2 ");
			cmCheckExistingCustomerContactStr.append(        "OR CCC2.CHAR_VAL_FK1 = :fkCharValue2) ");

			PreparedStatement cmCheckExistingCustomerContactQuery = createPreparedStatement(cmCheckExistingCustomerContactStr.toString()
					, getClass().getName());
			
			cmCheckExistingCustomerContactQuery.bindStringProperty("contactType", CustomerContactType.properties.contactType, parmContactType.trim());
			cmCheckExistingCustomerContactQuery.bindEntity("contactClass", parmContactClass);
			cmCheckExistingCustomerContactQuery.bindEntity("account", account);
			cmCheckExistingCustomerContactQuery.bindBoolean("yes", Bool.TRUE);
			cmCheckExistingCustomerContactQuery.bindEntity("fileIdCharType", parmFileIdCharType);
			cmCheckExistingCustomerContactQuery.bindStringProperty("charValue1", CustomerContactCharacteristic.properties.characteristicValue, fileId);
			cmCheckExistingCustomerContactQuery.bindStringProperty("adhocCharValue1", CustomerContactCharacteristic.properties.adhocCharacteristicValue, fileId);
			cmCheckExistingCustomerContactQuery.bindStringProperty("fkCharValue1", CustomerContactCharacteristic.properties.characteristicValueForeignKey1, fileId);
			cmCheckExistingCustomerContactQuery.bindEntity("accountIdCharType", parmAccountIdCharType);
			cmCheckExistingCustomerContactQuery.bindStringProperty("charValue2", CustomerContactCharacteristic.properties.characteristicValue, account.getId().getTrimmedValue());
			cmCheckExistingCustomerContactQuery.bindStringProperty("adhocCharValue2", CustomerContactCharacteristic.properties.adhocCharacteristicValue, account.getId().getTrimmedValue());
			cmCheckExistingCustomerContactQuery.bindStringProperty("fkCharValue2", CustomerContactCharacteristic.properties.characteristicValueForeignKey1, account.getId().getTrimmedValue());
			
			return cmCheckExistingCustomerContactQuery;
		}
		/*
		 * Defect 4136779 - 2018-10-15 - End Change
		 */
		// 2013-11-06 - CVB - Start

		/**
		 * This method creates To Do Entry
		 * @param accountStr - Account Id
		 */
		private void createToDo(String accountStr) {

			ToDoType toDoType = getParameters().getTO_DO_TYPE();

			ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
			ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();

			toDoEntryDTO.setCreationDateTime(getProcessDateTime());
			toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
			toDoEntryDTO.setToDoTypeId(toDoType.getId());

			toDoEntryDTO.setBatchControlId(getBatchControlId());
			toDoEntryDTO.setBatchNumber(getBatchNumber());

			toDoEntryDTO.setMessageId(new Message_Id(
					new MessageCategory_Id(BigInteger.valueOf(CustomMessagesMDC.MESSAGE_CATEGORY)), 
					BigInteger.valueOf(CustomMessagesMDC.NI0026_1_MAILING_ADDRESS_MISSING)));

			toDoCreator.setToDoDTO(toDoEntryDTO);

			// Message Parameter
			toDoCreator.addMessageParameter(accountStr);

			// Sort Keys
			for (ToDoSortKeyType sortKeyType : toDoType.getSortKeyTypes()) {

				BigInteger sequence = sortKeyType.fetchIdSequence();

				if (sequence.compareTo(BigInteger.valueOf(1)) == 0) { 
					toDoCreator.addSortKeyValue(sortKeyType, getBatchControlId().getTrimmedValue());                    
				}
				else if (sequence.compareTo(BigInteger.valueOf(2)) == 0) {
					toDoCreator.addSortKeyValue(sortKeyType, getBatchNumber().toString());                                
				}
				else if (sequence.compareTo(BigInteger.valueOf(3)) == 0) { 
					toDoCreator.addSortKeyValue(sortKeyType, getBatchRerunNumber().toString());                    
				}
			}

			// Drill Keys
			for (ToDoDrillKeyType drillKeyType : toDoType.getDrillKeyTypes()) {

				BigInteger sequence = drillKeyType.fetchIdSequence();

				if (sequence.compareTo(BigInteger.valueOf(1)) == 0) { 
					toDoCreator.addDrillKeyValue(drillKeyType, accountStr);                    
				}
			}
			toDoCreator.create();
		}
		// 2013-11-06 - CVB - End
	}
}
