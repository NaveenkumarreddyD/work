/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Meter In-bound Parameters  Lookup 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2013-03-08   RaviTeja     NI0018.2. Initial Version. 
 **************************************************************************/

package com.splwg.cm.api.lookup;

/**
 * 
 * @author rp014
 * @LookupFieldname (value = XMTR_OPT_TYP_FLG)
 *
 */


public class CmMeterInboundParametersLookup_Impl
	extends CmMeterInboundParametersLookup_Gen {
}