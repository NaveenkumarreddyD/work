/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Column Delimited Record class for ACH Batch Header
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-05-27   RDizon  CCB041. Initial version.        
 **************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

/**
 * @author RDizon
 */
public class CmCheckExtractACHBatchHeaderRecord extends ColumnDelimitedRecord {
    
    private static final String DELIMITER = "|";
        
    public CmCheckExtractACHBatchHeaderRecord() {
        super(13);
    }

    public void setRecordType(String value) {
        this.rightPadColumn(1, 1, value);
    }

    public void setServiceClassCode(String value) {
        this.rightPadColumn(2, 3, value);
    }

    public void setCompanyName(String value) {
        this.rightPadColumn(3, 16, value);
    }

    public void setDiscretionaryData(String value) {
        this.rightPadColumn(4, 20, value);
    }

    public void setCompanyId(String value) {
        this.rightPadColumn(5, 10, value);
    }

    public void setStandardEntryClass(String value) {
        this.rightPadColumn(6, 3, value);
    }

    public void setCompanyEntryDescrtiption(String value) {
        this.rightPadColumn(7, 10, value);
    }

    public void setCompanyDescriptiveDate(String value) {
        this.rightPadColumn(8, 6, value);
    }

    public void setEffectiveEntryDate(String value) {
        this.rightPadColumn(9, 6, value);
    }

    public void setReserved(String value) {
        this.rightPadColumn(10, 3, value);
    }

    public void setOriginatorStatusCode(String value) {
        this.rightPadColumn(11, 1, value);
    }

    public void setOriginatingFinancialInstitution(String value) {
        this.rightPadColumn(12, 8, value);
    }

    public void setBatchNumber(String value) {
        this.rightPadColumn(13, 7, value);
    }

}
