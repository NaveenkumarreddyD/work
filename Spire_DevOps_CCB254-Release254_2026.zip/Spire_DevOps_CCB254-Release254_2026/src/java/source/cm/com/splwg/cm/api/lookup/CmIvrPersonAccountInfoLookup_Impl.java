package com.splwg.cm.api.lookup;

/**
 * @author kloganatha001
 *
 * @LookupFieldname (value = XIVR_OPT_TYP_FLG)
 */

public class CmIvrPersonAccountInfoLookup_Impl extends
		CmIvrPersonAccountInfoLookup_Gen {

}
