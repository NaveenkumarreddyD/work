/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Payment Plan Information Extract Record                                                               
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                          
 * 2020-04-01  JHERNA      SA-322461. Initial version                 
 *                                                                
 *******************************************************************************
 */

package com.splwg.cm.api.batch.generalLetters;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmGeneralLetterPayPlanInfoExtractRecord extends ColumnDelimitedRecord {
    
    // Mailing Information
    private static final String PAY_PLAN_PRINT_KEY = "1130";
    private static final String MAIL_GRP = "20";
    private static final String BLANK = "  ";
    private static final String EMPTY_STR = "";
    
    public CmGeneralLetterPayPlanInfoExtractRecord() {
        super(18);
        defaultPrintKey();
    }

    /* EXTRACT COMMON SECTIONS */
    private void defaultPrintKey() {
        this.rightPadColumn(1, 4, formatString(PAY_PLAN_PRINT_KEY, 4));
    }
    
    public void setSortKeyLetterTemplateCode(String letterTemplateCode) {
        this.rightPadColumn(2, 12, formatString(letterTemplateCode, 12));
    }
    
    public void setSortKeyCcId(String ccId) {
        this.rightPadColumn(3, 10, formatString(ccId, 10));
        setSortKeyCcRecordGroup();
        setSortKeyCAndCRecordGroup();
    }
    
    private void setSortKeyCcRecordGroup() {
        this.rightPadColumn(4, 2, MAIL_GRP);
    }
    
    private void setSortKeyCAndCRecordGroup() {
        this.rightPadColumn(5, 2, BLANK);
    }
    
    public void setMailingKey(String mailingKey) {
        this.rightPadColumn(6, 12, formatString(mailingKey, 12));
        setFiller3Spaces();
    }
    
    private void setFiller3Spaces() {
        this.rightPadColumn(7, 3, " ");
    }
    
    /* EXTRACT DETAILS SECTION */       
    public void setFKCharType(String fkCharType) {    	
    	this.rightPadColumn(8, 8, formatString(fkCharType, 8));
    }
          
    public void setCharTypeDescr(String charTypeDescr) {    	
    	this.rightPadColumn(9, 60, formatString(charTypeDescr, 60));
    }  
    
    public void setPayPlanId(String payPlanID) {    	
    	this.rightPadColumn(10, 12, formatString(payPlanID, 12));
    }  
    
    public void setAccountId(String acctID) {    	
    	this.rightPadColumn(11, 10, formatString(acctID, 10));
    }
    
    public void setPayPlanType(String payPlanType) {    	
    	this.rightPadColumn(12, 8, formatString(payPlanType, 8));
    }
    
    public void setPayPlanDescr(String payPlanDescr) {    	
    	this.rightPadColumn(13, 60, formatString(payPlanDescr, 60));
    }
    
    public void setPpStartDt(String ppStartDate) {    	
    	this.rightPadColumn(14, 10, formatString(ppStartDate, 10));
    }
    
    public void setPpStatus(String ppStatus) {    	
    	this.rightPadColumn(15, 2, formatString(ppStatus, 2));
    }
    
    public void setPpSchedDt(String ppSchedDt) {    	
    	this.rightPadColumn(16, 10, formatString(ppSchedDt, 10));
    }
    
    public void setPpAmt(BigDecimal ppAmt) {    	
    	this.rightPadColumn(17, 16, ColumnDelimitedRecord.formatAsS9999999999999V99(ppAmt));
    	setFillerEndSpaces();
    }
    
    private void setFillerEndSpaces() {
        this.rightPadColumn(18, 1768, BLANK);
    }
    
    /**
     * Returns "" if text is null;
     * Truncates text if length exceed fieldLength;
     * @param text String variable to be formatted
     * @param fieldLength Length of Field
     * @return formatted text
     */
    private String formatString(String text, int fieldLength) {
        if(text == null) {
            text = EMPTY_STR;
        }
        else {
            text = text.trim();
            if(text.length() > fieldLength) {
                text = text.substring(0, fieldLength);
            }
        }
        return text;
    }
}
