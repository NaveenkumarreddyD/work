/*
 *************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * MGE-CCB009: Vacant Premise With Consumption
 * 	- Monitor Vacant Disconnected Premise Batch
 * 
 * This Background Process will monitor the disconnected Service Points
 * on a premise under the specified Cis Division and would create a Case 
 * for the SPs in the event that there was a meter read after the SP's 
 * service was stopped and the calculated consumption exceeded the 
 * Consumption Threshold batch parameter.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2014-09-24   JHERNA          MGE-CCB009: Initial Version.    
 * 2015-06-22	JHERNA			3225275. Update parameter 90 to cater to 
 * 								multiple Disconnect FA Types (comma 
 * 								delimited.) Also updated, the start of the
 * 								period to check for consumptions, the 
 * 								consumption period now is the latest read
 * 								after the SA/SP was stopped (or the SP was
 * 								disconnected) and whatever is the previous 
 * 								read of that Meter Reading.
 * 2016-01-29  	MPang			Updated for CCB v2.4 compilation. 
 * 2016-05-31	EQuint			Defect 3443970. Optimize SQL
 * 2023-05-26 	Darryl H		B28222:Modified parm CNSMPTN_UOM to include
 * 								more UOMs like ccfc..etc.	
 * 2025-03-18	CAtilano		E-09999 CM_LOCK Cases continue to reopen.  							
 **************************************************************************
 */
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.ProgramTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControl;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.FieldActivityStepTypeActionLookup;
import com.splwg.ccb.api.lookup.ReadTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointMeterEventTypeLookup;
import com.splwg.ccb.api.lookup.ServicePointSourceStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointStatusLookup;
import com.splwg.ccb.api.lookup.StatusConditionLookup;
import com.splwg.ccb.cobol.mr.CobolCopybookCICMDBRN;
import com.splwg.ccb.cobol.mr.CobolProgramCIPMDBRN;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.CaseType;
import com.splwg.ccb.domain.admin.caseType.CaseType_Id;
import com.splwg.ccb.domain.admin.caseType.CharacteristicTypeCaseType_Id;
import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.Register;
import com.splwg.ccb.domain.meterread.meterConfiguration.Register_Id;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseCreator;
import com.splwg.ccb.domain.todo.toDoCase.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_Id;*/
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType_Id;
import com.splwg.ccb.domain.admin.caseType.entity.CharacteristicTypeCaseType_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_Id;
import com.splwg.ccb.domain.todo.common.CaseCreator;
import com.splwg.ccb.domain.todo.data.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

//START CHANGE - PSREEKAN - 2016-09-26 - DEFECT#82480
///**
// * @author JHERNA
// *
// @BatchJob (modules = {}, rerunnable = false,
// *      softParameters = { @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = unitOfMeasure, name = CNSMPTN_UOM, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = CNSMPTN_THRSHLD, required = true, type = decimal)
// *            , @BatchJobSoftParameter (entityName = caseType, name = CASE_TYPE_CD, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = BADGE_NBR_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_SP_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_SRCE_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = CASE_SRCE_CHAR_VAL, required = true, type = string)
// *            , @BatchJobSoftParameter (name = FA_TYPE_CD, required = true, type = string)
// *            , @BatchJobSoftParameter (name = MAX-ERRORS, type = integer)})
// */
/**
 * @author JHERNA
 *
 @BatchJob (modules = {}, rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CNSMPTN_UOM, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CNSMPTN_THRSHLD, required = true, type = decimal)
 *            , @BatchJobSoftParameter (entityName = caseType, name = CASE_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = BADGE_NBR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_SP_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_SRCE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CASE_SRCE_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FA_TYPE_CD, required = true, type = string)
 *            , @BatchJobSoftParameter (name = DISC_FA_TYPE_CD, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAX-ERRORS, type = integer)})
 */
//END CHANGE - PSREEKAN - 2016-09-26 - DEFECT#82480
public class CmMonitorVacantDisconnectedPremiseBatch 
		extends	CmMonitorVacantDisconnectedPremiseBatch_Gen {
	// Parameters
	private CisDivision parmCisDivision;
	@SuppressWarnings("unused")
	// START DELETE - DarrylH-2023-05-26 -B28222
	//private UnitOfMeasure parmConsumptionUOM;
	// END DELETE - DarrylH-2023-05-26 -B28222
	private BigDecimal parmConsumptionThreshold;
	@SuppressWarnings("unused")
	private CaseType parmCaseType;
	private CharacteristicType parmCharTypeBadgeNbr;
	private CharacteristicType parmCharTypeCaseSP;
	private CharacteristicType parmCharTypeCaseSource;
	private String parmCharValCaseSource;
	// START DELETE - JHERNA - 2015-06-22 - 3225275
	//@SuppressWarnings("unused")
	//private FieldActivityType parmFaType;	
	// END DELETE - JHERNA - 2015-06-22 - 3225275
	
	// Constant
	private static final String PROG_NAME = "com.splwg.cm.domain.batch.CmMonitorVacantDisconnectedPremiseBatch";
	
	@Override
	public void validateSoftParameters(boolean arg0) {
        
		// Retrieve Parameter 10: CIS Division
		parmCisDivision = this.getParameters().getCIS_DIVISION();
		// Retrieve Parameter 20: Consumption UOM 
		// START DELETE - DarrylH-2023-05-26 -B28222
		//parmConsumptionUOM = this.getParameters().getCNSMPTN_UOM();
		// END DELETE - DarrylH-2023-05-26 -B28222
		// Retrieve Parameter 30: Consumption Threshold
		parmConsumptionThreshold = this.getParameters().getCNSMPTN_THRSHLD();
		String parm30Desc = cmOutRetrieveBatchParameterDescription(PROG_NAME, BigInteger.valueOf(30));
		cmValidateParmDecimalGreaterThanZero(parmConsumptionThreshold, parm30Desc);
		// Retrieve Parameter 40: Case Type
		parmCaseType = this.getParameters().getCASE_TYPE_CD();
		// Retrieve Parameter 50: Badge Number Characteristic Type
		parmCharTypeBadgeNbr = this.getParameters().getBADGE_NBR_CHAR_TYPE();
		String parm50Desc = cmOutRetrieveBatchParameterDescription(PROG_NAME, BigInteger.valueOf(50));
		cmValidateCharType(parmCharTypeBadgeNbr, CharacteristicEntityLookup.constants.CASE, parm50Desc);		
		cmValidateCharTypeValidForCaseType(parm50Desc, parmCharTypeBadgeNbr, parmCaseType);
		// Retrieve Parameter 60: Case SP Characteristic Type
		parmCharTypeCaseSP = this.getParameters().getCASE_SP_CHAR_TYPE();
		String parm60Desc = cmOutRetrieveBatchParameterDescription(PROG_NAME, BigInteger.valueOf(60));
		cmValidateCharType(parmCharTypeCaseSP, CharacteristicEntityLookup.constants.CASE, parm60Desc);
		cmValidateCharTypeValidForCaseType(parm60Desc, parmCharTypeCaseSP, parmCaseType);
		// Retrieve Parameter 70: Case Source Characteristic Type
		parmCharTypeCaseSource = this.getParameters().getCASE_SRCE_CHAR_TYPE();
		String parm70Desc = cmOutRetrieveBatchParameterDescription(PROG_NAME, BigInteger.valueOf(70));
		cmValidateCharType(parmCharTypeCaseSource, CharacteristicEntityLookup.constants.CASE, parm70Desc);
		cmValidateCharTypeValidForCaseType(parm70Desc, parmCharTypeCaseSource, parmCaseType);
		// Retrieve Parameter 80: Case Source Characteristic Value
		parmCharValCaseSource = this.getParameters().getCASE_SRCE_CHAR_VAL();
		String parm80Desc = cmOutRetrieveBatchParameterDescription(PROG_NAME, BigInteger.valueOf(80));
		cmValidateCharVal(parmCharTypeCaseSource, parmCharValCaseSource, parm80Desc);
		// START CHANGES - JHERNA - 2015-06-22 - 3225275
		// Retrieve Parameter 90: Field Activity Type
		//parmFaType = this.getParameters().getFA_TYPE_CD();
		cmValidateFaTypes();				
		// END CHANGES - JHERNA - 2015-06-22 - 3225275
	}	
	// START ADD - JHERNA - 2015-06-22 - 3225275
	private void cmValidateFaTypes() {
		
		String parm90 = this.getParameters().getFA_TYPE_CD();
		String[] splitParms = parm90.split(",");
		for (int x = 0; x < splitParms.length; x++) {
			FieldActivityType_Id faTypeID = new FieldActivityType_Id(splitParms[x].trim());
			if (isNull(faTypeID.getEntity())) {
				String parm90Desc = cmOutRetrieveBatchParameterDescription(PROG_NAME, BigInteger.valueOf(90));
				addError(CustomMessageRepositoryMGE.commBatchParameterInvalid(parm90Desc, splitParms[x]));
			}
		}
		
		//START ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
		String parm100 = this.getParameters().getDISC_FA_TYPE_CD();
		String[] splitParms100 = parm100.split(",");
		for (int x = 0; x < splitParms100.length; x++) {
			FieldActivityType_Id faTypeID = new FieldActivityType_Id(splitParms100[x].trim());
			if (isNull(faTypeID.getEntity())) {
				String parm100Desc = cmOutRetrieveBatchParameterDescription(PROG_NAME, BigInteger.valueOf(100));
				addError(CustomMessageRepositoryMGE.commBatchParameterInvalid(parm100Desc, splitParms100[x]));
			}
		}
		//END ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
		
		// START ADD - DarrylH-2023-05-26 -B28222		
        String tempConsumtionUOM = this.getParameters().getCNSMPTN_UOM();
        String[] tempUomList = tempConsumtionUOM.split(",");
        for (int i=0; i<tempUomList.length; i++){
            String uom = tempUomList[i];
            UnitOfMeasure unitOfMeasure = new UnitOfMeasure_Id(uom.trim()).getEntity();
            if (isNull(unitOfMeasure)){
                addError(CustomMessageRepository.NA_86246_invalidUnitOfMeasure
                        (uom.trim()));
            }
        }		
        // END ADD - DarrylH-2023-05-26 -B28222			
	}
	// END ADD - JHERNA - 2015-06-22 - 3225275
	/**
	 * Custom method that would validate if the characteristic type is valid for the specified case type
	 * @param parmDesc the parameter description of the characteristic type being validated
	 * @param charType the characteristic type being validated
	 * @param caseType the case type in which the characteristic type would be validated against.
	 */
	private void cmValidateCharTypeValidForCaseType(String parmDesc, CharacteristicType charType, CaseType caseType) {
		
		CharacteristicTypeCaseType_Id charTypeCaseTypeID = new CharacteristicTypeCaseType_Id(charType, caseType);
		if (isNull(charTypeCaseTypeID.getEntity())) {
			// Batch Parameter '%1%2' value (%3) is not valid for Case Type (%4).
			addError(CustomMessageRepositoryMGE.commBatchParameterCharTypeInvalidForCaseType(parmDesc.trim(), 
					charType.getId().getTrimmedValue(), caseType.getId().getTrimmedValue()));
		}
	}
	/**
	 * Custom method which validates that the BigDecimal value is greater than zero
	 * @param parmVal the value that is being validated
	 * @param parmDesc the parameter's description (will be used in case that validation failed for the value)
	 */
	private void cmValidateParmDecimalGreaterThanZero(BigDecimal parmVal, String parmDesc) {
		
		if (parmVal.compareTo(BigDecimal.ZERO) <= 0) {
			// Batch parameter '%1%2' value (%3) must be greater than zero.
			addError(CustomMessageRepositoryMGE.commBatchParameterMustBeGreaterThanZero(parmDesc.trim(), parmVal.toString().trim()));
		}		
	}
	
		/**
	 * Custom method which retrieves the Batch Parameter Description
	 * @param progName the programe and the package where the program is located
	 * @param parmSeq the parameter sequence
	 * @return returnValue the parameter description
	 */
	private String cmOutRetrieveBatchParameterDescription(String progName, BigInteger parmSeq) {
		
		String returnValue = " ";		
		StringBuilder stringBuilder = new StringBuilder();				
		stringBuilder.append("SELECT BCPL.DESCR50 ");
		stringBuilder.append("FROM CI_BATCH_CTRL_P_L BCPL, CI_BATCH_CTRL BC ");
		stringBuilder.append("WHERE BC.PROGRAM_NAME = :progName ");
		stringBuilder.append("AND BC.PGM_TYPE_FLG = :javaType ");
		stringBuilder.append("AND BCPL.BATCH_CD = BC.BATCH_CD ");
		stringBuilder.append("AND BCPL.LANGUAGE_CD = :language ");
		stringBuilder.append("AND BCPL.SEQ_NUM = :parmSeq ");
				
		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		prepState.bindStringProperty("progName", BatchControl.properties.programName, progName);
		prepState.bindLookup("javaType", ProgramTypeLookup.constants.JAVA);
		prepState.bindId("language", this.getActiveContextLanguage().getId());
		prepState.bindBigInteger("parmSeq", parmSeq);
		prepState.execute();
		/*
		 * start Change - EQuint - Defect 3443970 - 2016-05-31
		 */
		// if (prepState.list().size() > 0) {
		//	SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
		SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
		if (notNull(sqlRow)) {
		/*
		 * end Change - EQuint - Defect 3443970 - 2016-05-31
		 */
			returnValue = (String) sqlRow.get("DESCR50");
		}
		prepState.close();
		return returnValue;
	}
	
	private void cmValidateCharType(CharacteristicType charType, CharacteristicEntityLookup charTypeEntity, String parmDesc) {
		
		CharacteristicEntity_Id charEntityID = new CharacteristicEntity_Id(charType, charTypeEntity);
		if (isNull(charEntityID.getEntity())) {
			// Batch parameter '%1%2' value (%3) is not a valid char type for %4%5 entity.
			addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharTypeForEntity(
					parmDesc.trim(), charType.getId().getTrimmedValue(),
					charTypeEntity.getLookupValue().fetchLanguageDescription().trim()));
		}
	}
	
	private void cmValidateCharVal(CharacteristicType charType, String charVal, String parmDesc) {
		// Validate only if the characteristic type is of predefined char value type
		if (charType.getCharacteristicType().isPredefinedValue()) {
			CharacteristicValue_Id charValID = new CharacteristicValue_Id(charType, charVal.trim());
			if (isNull(charValID.getEntity())) {
				// Batch parameter '%1%2' value (%3) is not a valid char value for %4 char type.
				addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharValueForCharType(
						parmDesc.trim(), charVal.trim(), charType.getId().getTrimmedValue()));
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	public JobWork getJobWork() {
		
		/*
		 * Main Criteria
		 * 
		 * Select all Service Points (inService - not abolished) disconnected into a premise with the specified CIS Division
		 * that does not have any active (billable) Service Agreements. 
		 */
		StringBuilder stringBuilder = new StringBuilder();				
		stringBuilder.append("SELECT SP.SP_ID ");
		/*
		 * start Change - EQuint - Defect 3443970 - 2016-05-31
		 */
		// stringBuilder.append("FROM CI_SP SP, CI_PREM PREM ");
		stringBuilder.append("FROM CI_PREM PREM, CI_SP SP ");
		/*
		 * end Change - EQuint - Defect 3443970 - 2016-05-31
		 */
		// Criteria: Cis Division as specified
		stringBuilder.append("WHERE PREM.CIS_DIVISION = :cisDivision ");
		/*
		 * start Change - EQuint - Defect 3443970 - 2016-05-31
		 */
		// stringBuilder.append("AND SP.PREM_ID = PREM.PREM_ID ");
		stringBuilder.append("AND PREM.PREM_ID = SP.PREM_ID ");
		/*
		 * end Change - EQuint - Defect 3443970 - 2016-05-31
		 */
		// Criteria: SP must be disconnected
		stringBuilder.append("AND SP.SP_SRC_STATUS_FLG = :spSourceStatus ");
		// Criteria: SP is still InService / Not Abolished
		stringBuilder.append("AND (SP.SP_STATUS_FLG = :spStatus ");
			// Criteria: SP is Not Abolished as of processing date
		stringBuilder.append("    OR (SP.ABOLISH_DT IS NULL OR SP.ABOLISH_DT > :processDate) ");                   
		stringBuilder.append("    ) ");
		    // Criteria: SP does not have any Actively Billable SA
		stringBuilder.append("AND SP.SP_ID NOT IN (SELECT SASP.SP_ID ");
				             // Inner Select: List of SPs that contains Active Services
		stringBuilder.append("                     FROM CI_SA_SP SASP, CI_SA SA ");                               
		stringBuilder.append("                     WHERE SASP.SP_ID IN (SELECT SP2.SP_ID ");
		stringBuilder.append("                                          FROM CI_SP SP2 ");
		stringBuilder.append("                                          WHERE SP2.PREM_ID = PREM.PREM_ID ");
		stringBuilder.append("                                          AND SP2.SP_SRC_STATUS_FLG = :spSourceStatus ");
		stringBuilder.append("                                          AND SP2.SP_STATUS_FLG = :spStatus ");
		stringBuilder.append("                                          AND (SP2.ABOLISH_DT IS NULL OR SP2.ABOLISH_DT > :processDate) ");                                          
		stringBuilder.append("                                         ) ");
		stringBuilder.append("                     AND SA.SA_ID = SASP.SA_ID ");
		stringBuilder.append("                     AND SA.SA_STATUS_FLG IN (:pendingStart, :active, :pendingStop, :reactivated) ");
		stringBuilder.append("                    ) ");


		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		prepState.bindId("cisDivision", parmCisDivision.getId());
		prepState.bindLookup("spSourceStatus", ServicePointSourceStatusLookup.constants.DISCONNECTED);
		prepState.bindLookup("spStatus", ServicePointStatusLookup.constants.IN_SERVICE);
		prepState.bindDate("processDate", this.getProcessDateTime().getDate());
		prepState.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
		prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
		prepState.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
		prepState.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
		prepState.bindLookup("pending", FieldActivityStatusLookup.constants.PENDING);
		prepState.execute();
		QueryIterator queryIter = prepState.iterate();
		return createJobWorkForQueryIterator(queryIter, this);
	}

	@Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow qrw) {
		
		ThreadWorkUnit twu = new ThreadWorkUnit();
		ServicePoint_Id spID = (ServicePoint_Id) qrw.getId("SP_ID", ServicePoint.class); 
		twu.setPrimaryId(spID);
		return twu;
	}
	
	public Class<CmMonitorVacantDisconnectedPremiseBatchWorker> getThreadWorkerClass() {
		return CmMonitorVacantDisconnectedPremiseBatchWorker.class;
	}

	public static class CmMonitorVacantDisconnectedPremiseBatchWorker extends
			CmMonitorVacantDisconnectedPremiseBatchWorker_Gen {
		// Parameter
		@SuppressWarnings("unused")
		private CisDivision parmCisDivision;
		// START CHANGE - DarrylH-2023-05-26 -B28222
		private String parmConsumptionUOM;
		//private UnitOfMeasure parmConsumptionUOM;
		// END CHANGE - DarrylH-2023-05-26 -B28222
		private BigDecimal parmConsumptionThreshold;
		private CaseType parmCaseType;
		private CharacteristicType parmCharTypeBadgeNbr;
		private CharacteristicType parmCharTypeCaseSP;
		private CharacteristicType parmCharTypeCaseSource;
		private String parmCharValCaseSource;
		// START CHANGES - JHERNA - 2015-06-22 - 3225275
		//private FieldActivityType parmFaType;
		private List<FieldActivityType_Id> collOfDiscFaTypeID = new ArrayList<FieldActivityType_Id>();
		
		// Work Variable(s)
		//private DateTime consumptionStartReadDttm;
		private DateTime saspStopReadDttmOrSpDiscReadDttm;
		// END CHANGES - JHERNA - 2015-06-22 - 3225275
		
		//START ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
		private List<FieldActivityType_Id> disconnectedFaTypeID = new ArrayList<FieldActivityType_Id>();
		//END ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {

			// Retrieve Parameter 10: CIS Division
			parmCisDivision = this.getParameters().getCIS_DIVISION();
			// Retrieve Parameter 20: Consumption UOM 
			//START DELETE - DarrylH-2023-05-26 -B28222
			//parmConsumptionUOM = this.getParameters().getCNSMPTN_UOM();
			//END DELETE - DarrylH-2023-05-26 -B28222
			// Retrieve Parameter 30: Consumption Threshold
			parmConsumptionThreshold = this.getParameters().getCNSMPTN_THRSHLD();
			// Retrieve Parameter 40: Case Type
			parmCaseType = this.getParameters().getCASE_TYPE_CD();
			// Retrieve Parameter 50: Badge Number Characteristic Type
			parmCharTypeBadgeNbr = this.getParameters().getBADGE_NBR_CHAR_TYPE();
			// Retrieve Parameter 60: Case SP Characteristic Type
			parmCharTypeCaseSP = this.getParameters().getCASE_SP_CHAR_TYPE();
			// Retrieve Parameter 70: Case Source Characteristic Type
			parmCharTypeCaseSource = this.getParameters().getCASE_SRCE_CHAR_TYPE();
			// Retrieve Parameter 80: Case Source Characteristic Value
			parmCharValCaseSource = this.getParameters().getCASE_SRCE_CHAR_VAL();
			// START CHANGES - JHERNA - 2015-06-22 - 3225275
			// Retrieve Parameter 90: Field Activity Type
			//parmFaType = this.getParameters().getFA_TYPE_CD();
			cmRetrieveDiscFaTypes();
			// END CHANGES - JHERNA - 2015-06-22 - 3225275
			
			//START ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
			cmRetrieveDisconnectedFaTypes();
			//END ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
			
			//START ADD - DarrylH-2023-05-26 -B28222
			cmRetrieveUOM();
			// END ADD - DarrylH-2023-05-26 -B28222						
		}
		// START ADD - DarrylH-2023-05-26 -B28222
		private void cmRetrieveUOM() {			
	       // put this parm to the right format for sql selection later ('CCF','CCFC')			
	        String tempParmConsumptionUOM = this.getParameters().getCNSMPTN_UOM();	        
	        String[] uomList = tempParmConsumptionUOM.split(",");
	        parmConsumptionUOM = "";
	        for (int i=0; i<uomList.length; i++){
	            parmConsumptionUOM = parmConsumptionUOM + "'" + uomList[i] + "' , "; 
	        }
	        parmConsumptionUOM = parmConsumptionUOM.substring(0, parmConsumptionUOM.lastIndexOf(","));
		}
		// END ADD - DarrylH-2023-05-26 -B28222
		
		// START ADD - JHERNA - 2015-06-22 - 3225275
		private void cmRetrieveDiscFaTypes() {
			
			String parm90 = this.getParameters().getFA_TYPE_CD();
			String[] splitParms = parm90.split(",");
			for (int x = 0; x < splitParms.length; x++) {
				FieldActivityType_Id faTypeID = new FieldActivityType_Id(splitParms[x].trim());
				collOfDiscFaTypeID.add(faTypeID);
			}
		}
		// END ADD - JHERNA - 2015-06-22 - 3225275
		
		//START ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
		private void cmRetrieveDisconnectedFaTypes() {

			String parm100 = this.getParameters().getDISC_FA_TYPE_CD();
			String[] splitParms = parm100.split(",");
			for (int x = 0; x < splitParms.length; x++) {
				FieldActivityType_Id faTypeID = new FieldActivityType_Id(
						splitParms[x].trim());
				disconnectedFaTypeID.add(faTypeID);
			}
		}
		//END ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
		
		public ThreadExecutionStrategy createExecutionStrategy() {

			return new StandardCommitStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			
			ServicePoint_Id spID = (ServicePoint_Id) unit.getPrimaryId();
			// Process Service Points only if there are no open Case of type Batch Parameter 40: Case Type
			// currently existing for this SP
			Bool isOpenCaseExists = cmCheckForOpenCase(parmCaseType, parmCharTypeCaseSP, spID.getTrimmedValue());
			if (isOpenCaseExists.isFalse()) {					
				// Further processing for the SPs
				cmProcessServicePoints(spID);					
			}	
			return true;
		}

		/**
		 * Custom method which checks of open cases which matches the characteristic type / value combination
		 * @param caseType the case type to be searched
		 * @param charType the case' char type to be searched
		 * @param charVal the case' char value to be searched
		 * @return returnValue True whcen there is an existing open case which matches the char type/value, otherwise False
		 */
		private Bool cmCheckForOpenCase(CaseType caseType, CharacteristicType charType, String charVal) {
			
			Bool returnValue = Bool.FALSE;
			
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT tdCase.CASE_ID "); 
			stringBuilder.append("FROM CI_CASE tdCase, CI_CASE_CHAR tdCaseChar ");
			stringBuilder.append("WHERE tdCase.CASE_TYPE_CD = :caseTypeCd ");
			stringBuilder.append("AND tdCase.CASE_COND_FLG = :openCondition ");
			stringBuilder.append("AND tdCaseChar.CASE_ID = tdCase.CASE_ID ");
			stringBuilder.append("AND tdCaseChar.CHAR_TYPE_CD = :charType ");	
			/*
			 * start Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			// stringBuilder.append("AND (tdCaseChar.CHAR_VAL_FK1 = '"+charVal.trim()+"' ");
			// stringBuilder.append("     OR tdCaseChar.ADHOC_CHAR_VAL = '"+charVal.trim()+"' ");
			// stringBuilder.append("     OR tdCaseChar.CHAR_VAL = '"+charVal.trim()+"' ) ");
			
			stringBuilder.append("AND tdCaseChar.SRCH_CHAR_VAL = '"+charVal.trim()+"' ");
			/*
			 * end Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("caseTypeCd", caseType.getId());
			prepState.bindLookup("openCondition", CaseConditionLookup.constants.OPEN);
			prepState.bindId("charType", charType.getId());
			prepState.execute();
			/*
			 * start Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			// if (prepState.list().size() > 0) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			if (notNull(sqlRow)) {
			/*
			 * end Change - EQuint - Defect 3443970 - 2016-05-31
			 */
				returnValue = Bool.TRUE;
			}
			prepState.close();
			return returnValue;
		}
		/**
		 * Custom method which processes the service points 
		 * 	(checks for the consumption and verifies if a case needs to be created
		 * @param spID the service point to be processed
		 */
		private void cmProcessServicePoints(ServicePoint_Id spID) {
			/*E-09999 Start Change CAtilano*/
			// Retrieve the meter configuration and the stop date of the latest SA/SP that had service at the premise.
			/*StringBuilder stringBuilder = new StringBuilder();						
			stringBuilder.append("SELECT MR.READ_DTTM, MR.MTR_CONFIG_ID, MR.MR_ID ");
			stringBuilder.append("FROM CI_SA_SP SASP, CI_MR MR ");
			stringBuilder.append("WHERE SASP.SP_ID = :spID ");
			stringBuilder.append("AND SASP.STOP_DTTM = (SELECT MAX(SASP2.STOP_DTTM) ");
			stringBuilder.append("                      FROM CI_SA_SP SASP2 ");
			stringBuilder.append("                      WHERE SASP2.SP_ID = SASP.SP_ID ");
			stringBuilder.append("                      ) ");
			/*
			 * start Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			// stringBuilder.append("AND MR.MR_ID = SASP.STOP_MR_ID ");
			//stringBuilder.append("AND SASP.STOP_MR_ID = MR.MR_ID ");
			/*
			 * end Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			
			// Find the latest SA on SP, if the SA is not Pending Stopped, Stopped or Closed skip it*/
			String qry = "SELECT SASP.START_DTTM, SASP.STOP_MR_ID, MH.REMOVAL_MR_ID, MR.MTR_CONFIG_ID, MR.READ_DTTM "
					+ " FROM CI_SA_SP SASP, CI_SA SA, CI_SP_MTR_HIST MH, CI_MR MR "
					+ " WHERE SASP.SA_ID = SA.SA_ID "
					+ " AND SA.SA_STATUS_FLG IN ('30','40','60') "
					+ " AND MH.SP_ID = SASP.SP_ID "
					+ " AND STOP_MR_ID <> '            ' "
					+ " AND SASP.SP_ID = :spId "
					+ " AND SASP.STOP_MR_ID = MR.MR_ID "
					+ " AND MR.MTR_CONFIG_ID = MH.MTR_CONFIG_ID "
					+ " ORDER BY SASP.START_DTTM DESC ";
			PreparedStatement prepState = createPreparedStatement(qry, getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("spId", spID);
			/*E-09999 End Change CAtilano*/
			prepState.execute();
			/*
			 * start Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			// if (prepState.list().size() > 0) {
				
				// SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();	
			
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			if (notNull(sqlRow)) {
			/*
			 * end Change - EQuint - Defect 3443970 - 2016-05-31
			 */
				DateTime stopMRDateTime = sqlRow.getDateTime("READ_DTTM");
				MeterConfiguration_Id mtrConfigID = (MeterConfiguration_Id) sqlRow.getId("MTR_CONFIG_ID", MeterConfiguration.class);
				/*E-09999 the stop read will be used as Consumption Start Read*/
				MeterRead_Id stopMeterReadID = (MeterRead_Id) sqlRow.getId("STOP_MR_ID", MeterRead.class); 
				MeterRead_Id removalMeterReadID = (MeterRead_Id) sqlRow.getId("REMOVAL_MR_ID", MeterRead.class);
			
				// Check (and retrieve) if the meter has been removed after stopMRDateTime
				DateTime meterRemovedDttm = cmRetrieveMeterRemovalDate(mtrConfigID, spID, stopMRDateTime);	
				
				// START CHANGES - JHERNA - 2015-06-22 - 3225275
				// Retrieve the starting read of the consumption
				//BigDecimal startingRead = cmRetrieveConsumptionStartRead(parmFaType, spID, stopMeterReadID, parmConsumptionUOM, stopMRDateTime);
				MeterRead_Id saspStopReadOrSpDiscRead = cmRetrieveSaSpStopReadOrSpDisconnectRead(spID, stopMeterReadID, parmConsumptionUOM, stopMRDateTime);
				
				// Retrieve the latest meter read id after the service was stopped
				//MeterRead_Id latestMeterReadIdAfterStop = cmRetrieveLatestMeterReadAfterServiceStop(mtrConfigID, consumptionStartReadDttm, meterRemovedDttm);
				MeterRead_Id latestMeterReadIdAfterStop = cmRetrieveLatestMeterReadAfterServiceStop(saspStopReadOrSpDiscRead, 
						mtrConfigID, saspStopReadDttmOrSpDiscReadDttm, meterRemovedDttm);
				
				// In the event that there are no reads / consumption after the service was stopped, exit this method and stop processing.
				if (isNull(latestMeterReadIdAfterStop)) {
					prepState.close();
					return;
				}
				
				Register register = cmRetrieveRegister(mtrConfigID, parmConsumptionUOM);
				BigDecimal prevReadingOfLatestMRAfterStop = cmRetrievePreviousRegisterReading(latestMeterReadIdAfterStop, register, mtrConfigID);
				
				// Retrieve the ending read of the consumption
				//BigDecimal endingRead = cmRetrieveRead(latestMeterReadIdAfterStop, parmConsumptionUOM); 
				BigDecimal latestReadingAfterStop = cmRetrieveRead(latestMeterReadIdAfterStop, parmConsumptionUOM);
				BigDecimal stopMeterReadIDReading = cmRetrieveRead(stopMeterReadID, parmConsumptionUOM);
				BigDecimal removalMeterReadIDReading = cmRetrieveRead(removalMeterReadID, parmConsumptionUOM);
				// Compute for the consumption
				//Register register = cmRetrieveRegister(mtrConfigID, parmConsumptionUOM);
				//BigDecimal consumption = cmComputeConsumption(startingRead, endingRead, register);
				BigDecimal consumption;
				/*E-09999 Start Change CAtilano*/
				//If removal read exists, use it to calculate consumption, else use the last billable read. 
				if(removalMeterReadID.isNull())
					consumption = cmComputeConsumption(stopMeterReadIDReading, latestReadingAfterStop, register);
				else
					consumption = cmComputeConsumption(stopMeterReadIDReading, removalMeterReadIDReading, register);
				/*E-09999 End Change CAtilano*/
				// Used the starting read (a.k.a. stop meter read) to get the scale to use
				//int scaleValue = startingRead.scale();
				int scaleValue = prevReadingOfLatestMRAfterStop.scale();				
				// END CHANGES - JHERNA - 2015-06-22 - 3225275
				
				consumption = consumption.setScale(scaleValue, BigDecimal.ROUND_HALF_UP);
				BigDecimal consumptionThreshold = parmConsumptionThreshold.setScale(scaleValue, BigDecimal.ROUND_HALF_UP);

				// In the event that the consumption exceeds the threshold parameter, create case.
				if (consumption.compareTo(consumptionThreshold) > 0) {
					
					//START ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
					if(isCompletedDisconnectedFAExists(spID, saspStopReadOrSpDiscRead)){
						
						prepState.close();
						return;
					}
					//START ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
					
					// Create the collection of the characteristics to be created for the Case
					String badgeNbr = mtrConfigID.getEntity().getMeter().getBadgeNumber().trim();
					List<CaseCharacteristic_DTO> charDTOList = new ArrayList<CaseCharacteristic_DTO>();
					// Characteristic for Case SP
					CaseCharacteristic_DTO charForCaseSP = cmFormCaseCharacteristicDTO(parmCharTypeCaseSP, spID.getTrimmedValue(), BigInteger.TEN);
					charDTOList.add(charForCaseSP);
					// Characteristic for Badge Number
					CaseCharacteristic_DTO charForBadgeNumber = cmFormCaseCharacteristicDTO(parmCharTypeBadgeNbr, badgeNbr.trim(), BigInteger.valueOf(20));
					charDTOList.add(charForBadgeNumber);
					// Characteristic For Case Source
					CaseCharacteristic_DTO charForCaseSource = cmFormCaseCharacteristicDTO(parmCharTypeCaseSource, parmCharValCaseSource.trim(), BigInteger.valueOf(30));
					charDTOList.add(charForCaseSource);
					// Create Case					
					cmCreateCase(parmCaseType, charDTOList, spID.getEntity().getPremise().getId());
				}
			}
			prepState.close();
		}
				
		/**
		 * Custom method which retrieves the actual Register Reading of the correct UOM from the Meter Read ID 
		 * @param mrID the meter read
		 * @param readUOM the UOM 
		 * @return the register reading 
		 */
		 // START CHANGE - DarrylH-2023-05-26 -B28222
		//private BigDecimal cmRetrieveRead(MeterRead_Id mrID, UnitOfMeasure readUOM) {
		  private BigDecimal cmRetrieveRead(MeterRead_Id mrID, String readUOM) {
		// END CHANGE - DarrylH-2023-05-26 -B28222	
			BigDecimal returnValue = BigDecimal.ZERO;			
			
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT RR.REG_READING ");
			stringBuilder.append("FROM CI_REG_READ RR, CI_REG REG ");
			stringBuilder.append("WHERE RR.MR_ID = :mrID ");
			stringBuilder.append("AND REG.REG_ID = RR.REG_ID ");
			/*
			 * start Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			// stringBuilder.append("AND REG.UOM_CD = :uomCd ");
			// stringBuilder.append("AND RR.READ_SEQ = REG.READ_SEQ ");
			stringBuilder.append("AND RR.READ_SEQ = REG.READ_SEQ ");
			// START CHANGE - DarrylH-2023-05-26 -B28222
			stringBuilder.append("AND REG.UOM_CD IN (" + readUOM + ") ");
			//stringBuilder.append("AND REG.UOM_CD = :uomCd ");
			// END CHANGE - DarrylH-2023-05-26 -B28222
			/*
			 * end Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("mrID", mrID);
			// START DELETE - DarrylH-2023-05-26 -B28222
			//prepState.bindId("uomCd", readUOM.getId());
			// START DELETE - DarrylH-2023-05-26 -B28222
			prepState.execute();
			
			/*
			 * start Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			// if (prepState.list().size() > 0) {
			// 	// Program is already using the specific Meter Read ID, so program needs to retrieve only one row
			// 	SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			if (notNull(sqlRow)) {
			/*
			 * end Change - EQuint - Defect 3443970 - 2016-05-31
			 */
				returnValue = (BigDecimal) sqlRow.getBigDecimal("REG_READING");
			}					
			prepState.close();
			
			return returnValue;
			
		}
		// START CHANGES - JHERNA - 2015-06-22 - 3225275
		///**
		// * Custom method which retrieves the Start Read for the consumption calculation
		// * @param faType the Field Activity Type
		// * @param spID the service point ID
		// * @param stopMeterReadID the Stop Meter Read ID
		// * @param uom the unit of measure 
		// * @param stopMrDttm the Stop Meter Read Date Time
		// * @return returnValue BigDecimal value of the register reading to be used as the star read of the consumption calculation
		// */
		/*
		private BigDecimal cmRetrieveConsumptionStartRead(FieldActivityType faType, ServicePoint_Id spID, 
				MeterRead_Id stopMeterReadID, UnitOfMeasure uom, DateTime stopMrDttm) {
		*/
		// START CHANGE - DarrylH-2023-05-26 -B28222
		//private MeterRead_Id cmRetrieveSaSpStopReadOrSpDisconnectRead(ServicePoint_Id spID, MeterRead_Id stopMeterReadID, 
		//UnitOfMeasure uom, DateTime stopMrDttm) {
		private MeterRead_Id cmRetrieveSaSpStopReadOrSpDisconnectRead(ServicePoint_Id spID, MeterRead_Id stopMeterReadID, 
				String uom, DateTime stopMrDttm) {
		// START CHANGE - DarrylH-2023-05-26 -B28222	
			MeterRead_Id returnValue = null;
			String disconnectFATypes = "";
			Iterator<FieldActivityType_Id> iter = collOfDiscFaTypeID.iterator();
			while (iter.hasNext()) {
				FieldActivityType_Id faTypeID = iter.next();
				disconnectFATypes = disconnectFATypes.concat("'");
				disconnectFATypes = disconnectFATypes.concat(faTypeID.getTrimmedValue());
				disconnectFATypes = disconnectFATypes.concat("'");
				disconnectFATypes = disconnectFATypes.concat(",");
			}
			disconnectFATypes = disconnectFATypes.substring(0, disconnectFATypes.length() - 1);
			
			//BigDecimal returnValue = BigDecimal.ZERO;
			// Find the earliest completed disconect FA for the FA
			StringBuilder stringBuilder = new StringBuilder();		
			stringBuilder.append("SELECT FAS.MR_ID MREAD, MR.READ_DTTM MR_DTTM ");
			stringBuilder.append("FROM CI_FA_STEP FAS, CI_FA FA, CI_MR MR ");
			stringBuilder.append("WHERE FA.SP_ID = :spID ");
			// Changed to multiple FA Types
			//stringBuilder.append("AND FA.FA_TYPE_CD = :faTypeCd ");
			stringBuilder.append("AND FA.FA_TYPE_CD IN ( ");
			stringBuilder.append("                      "+disconnectFATypes+" ");
			stringBuilder.append("                      ) ");						
			stringBuilder.append("AND FA.FA_STATUS_FLG = :faStatus ");
			//stringBuilder.append("AND FA.CRE_DTTM = (SELECT MIN(FA2.CRE_DTTM) ");
			stringBuilder.append("AND FA.CRE_DTTM = (SELECT MAX(FA2.CRE_DTTM) ");
			stringBuilder.append("                   FROM CI_FA FA2 ");
			stringBuilder.append("                   WHERE FA2.SP_ID = FA.SP_ID ");
			stringBuilder.append("                   AND FA2.FA_TYPE_CD = FA.FA_TYPE_CD ");
			stringBuilder.append("                   AND FA2.FA_STATUS_FLG = :faStatus ");
			stringBuilder.append("                   AND FA2.CRE_DTTM <= :processDttm ");
			stringBuilder.append("                   ) ");
			stringBuilder.append("AND FAS.FA_ID = FA.FA_ID ");
			stringBuilder.append("AND FAS.FA_STEP_TY_ACT_FLG = :faStepType ");
			stringBuilder.append("AND MR.MR_ID = FAS.MR_ID ");			

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("spID", spID);
			//prepState.bindId("faTypeCd", faType.getId());
			prepState.bindLookup("faStatus", FieldActivityStatusLookup.constants.COMPLETED);
			prepState.bindLookup("faStepType", FieldActivityStepTypeActionLookup.constants.READ_METER);
			prepState.bindDateTime("processDttm", this.getProcessDateTime());			
			prepState.execute();
			/*
			 * start Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			// if (prepState.list().size() > 0) {
				
				// SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			if (notNull(sqlRow)) {
				
			/*
			 * end Change - EQuint - Defect 3443970 - 2016-05-31
			 */
				MeterRead_Id mrID = (MeterRead_Id) sqlRow.getId("MREAD", MeterRead.class);
				DateTime mrDttm = sqlRow.getDateTime("MR_DTTM");
				// Retrieve the actual register reading if the meter read was retrieved successfully (not null)
				if (notNull(mrID)) {
					//consumptionStartReadDttm = mrDttm;
					saspStopReadDttmOrSpDiscReadDttm = mrDttm;
					//returnValue = cmRetrieveRead(mrID, uom);
					returnValue = mrID;
				}
				// In the event that Meter Read was not retrieved succesfully, get the stop meter read's register reading and return it
				// as the consumption start read
				else {
					//consumptionStartReadDttm = stopMrDttm;
					saspStopReadDttmOrSpDiscReadDttm = stopMrDttm;
					//returnValue = cmRetrieveRead(stopMeterReadID, uom);
					returnValue = stopMeterReadID;
				}
			}
			// In the event that there were no completed disconnect FA retrieved, get the stop meter read's register reading and return it
			// as the consumption start read
			else {				
				//consumptionStartReadDttm = stopMrDttm;
				saspStopReadDttmOrSpDiscReadDttm = stopMrDttm;
				//returnValue = cmRetrieveRead(stopMeterReadID, uom);
				returnValue = stopMeterReadID;
			}						
			prepState.close();
			return returnValue;
		}
		// END CHANGES - JHERNA - 2015-06-22 - 3225275
		
		//START ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
		private boolean isCompletedDisconnectedFAExists(ServicePoint_Id spID, MeterRead_Id stopMeterReadID) {
			
			boolean returnValue = false;
			String disconnectFATypes = "";
			Iterator<FieldActivityType_Id> iter = disconnectedFaTypeID.iterator();
			while (iter.hasNext()) {
				FieldActivityType_Id faTypeID = iter.next();
				disconnectFATypes = disconnectFATypes.concat("'");
				disconnectFATypes = disconnectFATypes.concat(faTypeID.getTrimmedValue());
				disconnectFATypes = disconnectFATypes.concat("'");
				disconnectFATypes = disconnectFATypes.concat(",");
			}
			disconnectFATypes = disconnectFATypes.substring(0, disconnectFATypes.length() - 1);
			
			// Find the completed disconnect FA for the SP
			StringBuilder stringBuilder = new StringBuilder();		
			stringBuilder.append(" SELECT FA.FA_ID");
			stringBuilder.append(" FROM CI_FA FA");
			stringBuilder.append(" WHERE FA.SP_ID = :spID ");
			stringBuilder.append(" AND FA.FA_TYPE_CD IN ( ");
			stringBuilder.append("                      "+disconnectFATypes+" ");
			stringBuilder.append("                      ) ");						
			stringBuilder.append(" AND FA.FA_STATUS_FLG = :faStatus ");
			stringBuilder.append(" AND FA.SCHED_DTTM > :stopReadDateTime ");

			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			prepState.bindId("spID", spID);
			prepState.bindLookup("faStatus", FieldActivityStatusLookup.constants.COMPLETED);
			prepState.bindDateTime("stopReadDateTime", stopMeterReadID.getEntity().getReadDateTime());
			prepState.execute();
			
			if(notNull(prepState.firstRow())){
				
				returnValue = true;
			}
			prepState.close();
			return returnValue;
		}
		//END ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
		
		// START ADD - JHERNA - 2015-06-22 - 3225275
		private BigDecimal cmRetrievePreviousRegisterReading(MeterRead_Id excludeMRID, Register reg, MeterConfiguration_Id meterConfigID) {

			BigDecimal returnValue = BigDecimal.ZERO;
			
			// Retrieve the Previous Register Reading
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT RR.REG_READING, MR.READ_DTTM ");
			stringBuilder.append("FROM CI_MR MR, CI_REG_READ RR ");
			/*
			 * start Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			// stringBuilder.append("WHERE MR.MR_ID != :excludeMRID ");
			// stringBuilder.append("AND MR.MTR_CONFIG_ID = :mtrConfigId ");
			// stringBuilder.append("AND MR.USE_ON_BILL_SW = :useOnBillSw ");
			// stringBuilder.append("AND MR.READ_DTTM < :excludeMRDttm ");
			// stringBuilder.append("AND RR.MR_ID = MR.MR_ID ");
			stringBuilder.append("WHERE MR.MTR_CONFIG_ID = :mtrConfigId ");
			stringBuilder.append("AND MR.USE_ON_BILL_SW = :useOnBillSw ");
			stringBuilder.append("AND MR.MR_ID != :excludeMRID ");
			stringBuilder.append("AND MR.READ_DTTM < :excludeMRDttm ");
			stringBuilder.append("AND MR.MR_ID = RR.MR_ID ");
			/*
			 * end Change - EQuint - Defect 3443970 - 2016-05-31
			 */
            // Condition for None Estimate Reads only (no need to use feature configuration as it is overkill. Read Type Flag lookup is owned by product and cannot be modified)
			stringBuilder.append("AND RR.READ_TYPE_FLG NOT IN (:systemEstimate, :serviceProviderEstimate, :officeEstimate) ");
			stringBuilder.append("ORDER BY MR.READ_DTTM DESC ");

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("mtrConfigId", meterConfigID);
			prepState.bindId("excludeMRID", excludeMRID);
			prepState.bindBoolean("useOnBillSw", Bool.TRUE);
			prepState.bindDateTime("excludeMRDttm", excludeMRID.getEntity().getReadDateTime());			
			prepState.bindLookup("systemEstimate", ReadTypeLookup.constants.SYSTEM_ESTIMATE);
			prepState.bindLookup("serviceProviderEstimate", ReadTypeLookup.constants.SERVICE_PROVIDER_ESTIMATE);
			prepState.bindLookup("officeEstimate", ReadTypeLookup.constants.OFFICE_ESTIMATE);
			prepState.execute();

			/*
			 * start Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			// if (prepState.list().size() > 0) {
			// 	SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			if (notNull(sqlRow)) {
			/*
			 * end Change - EQuint - Defect 3443970 - 2016-05-31
			 */
				BigDecimal prevRegReadBD = (BigDecimal) sqlRow.getBigDecimal("REG_READING");
				@SuppressWarnings("unused")
				DateTime prevRegReadDttm = (DateTime) sqlRow.getDateTime("READ_DTTM");
				returnValue = prevRegReadBD;
			}

			prepState.close();
			return returnValue;
		}
		// END ADD - JHERNA - 2015-06-22 - 3225275
		
		/**
		 * Custom method which retrieves the earliest non-estimated read after the service was stopped. 
		 * Note: The selected read cannot be future dated.  
		 * @param meterConfigID the meter configuration
		 * @param stopMRDateTime the stop Meter Read Date Time
		 * @return the latest Meter Read ID after the service was stopped
		 */
		private MeterRead_Id cmRetrieveLatestMeterReadAfterServiceStop(MeterRead_Id saspStopReadOrSpDiscRead, MeterConfiguration_Id meterConfigID, DateTime stopMRDateTime,
				DateTime meterRemovedDttm) {
			
			MeterRead_Id returnValue = null;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT MR.READ_DTTM, MR.MR_ID ");
			stringBuilder.append("FROM CI_MR MR ");
			stringBuilder.append("WHERE MR.MTR_CONFIG_ID = :meterConfigID ");
			stringBuilder.append("AND MR.USE_ON_BILL_SW = :yesUseOnBill ");
			// START ADD - JHERNA - 2015-06-22 - 3225275
			if (notNull(saspStopReadOrSpDiscRead)) {
				stringBuilder.append("AND MR.MR_ID != :excludeMRID ");
			}
			// END ADD - JHERNA - 2015-06-22 - 3225275
			if (isNull(meterRemovedDttm)) {
				// Meter Reads after the Stop Read
				stringBuilder.append("AND READ_DTTM > :stopMRDateTime ");				
			}
			else {
				// Meter Reads after the Stop Read and before the Meter Removal
				stringBuilder.append("AND READ_DTTM BETWEEN :stopMRDateTime AND :meterRemovedDttm ");
			}

			stringBuilder.append("AND MR.MR_ID IN (SELECT RR.MR_ID ");
			stringBuilder.append("                 FROM CI_REG_READ RR ");
			stringBuilder.append("                 WHERE RR.MR_ID = MR.MR_ID ");
			                      // Condition for None Estimate Reads only (no need to use feature configuration as it is overkill. Read Type Flag lookup is owned by product and cannot be modified)
			stringBuilder.append("                 AND RR.READ_TYPE_FLG NOT IN (:systemEstimate, :serviceProviderEstimate, :officeEstimate) ");
			stringBuilder.append("                ) ");
			// Condition to restrict future dated reads                
			stringBuilder.append("AND MR.READ_DTTM <= :processDateTime ");
			stringBuilder.append("ORDER BY MR.READ_DTTM DESC ");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("meterConfigID", meterConfigID);
			prepState.bindBoolean("yesUseOnBill", Bool.TRUE);
			
			// START ADD - JHERNA - 2015-06-22 - 3225275
			if (notNull(saspStopReadOrSpDiscRead)) {
				prepState.bindId("excludeMRID", saspStopReadOrSpDiscRead);
			}
			// END ADD - JHERNA - 2015-06-22 - 3225275
			
			if (isNull(meterRemovedDttm)) {
				prepState.bindDateTime("stopMRDateTime", stopMRDateTime);
			}
			else {
				prepState.bindDateTime("stopMRDateTime", stopMRDateTime);
				prepState.bindDateTime("meterRemovedDttm", meterRemovedDttm);
			}
			
			prepState.bindLookup("systemEstimate", ReadTypeLookup.constants.SYSTEM_ESTIMATE);
			prepState.bindLookup("serviceProviderEstimate", ReadTypeLookup.constants.SERVICE_PROVIDER_ESTIMATE);
			prepState.bindLookup("officeEstimate", ReadTypeLookup.constants.OFFICE_ESTIMATE);
			prepState.bindDateTime("processDateTime", this.getProcessDateTime());
			prepState.execute();
			
			/*
			 * start Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			// if (prepState.list().size() > 0) {
			// 	SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			if (notNull(sqlRow)) {
			/*
			 * end Change - EQuint - Defect 3443970 - 2016-05-31
			 */
				@SuppressWarnings("unused")
				DateTime mrDttm = (DateTime) sqlRow.getDateTime("READ_DTTM");				
				returnValue = (MeterRead_Id) sqlRow.getId("MR_ID", MeterRead.class);
			}			
			prepState.close();
			return returnValue;
		}
		/**
		 * Custom method which calls the base routine to calculate the consumption given 2 reads and the register's number of digits left
		 * and taking into account the dial rollover.
		 * @param startReading the starting read
		 * @param endReading the ending read
		 * @param register the register to retrieve the number of digits left value
		 * @return BigDecimal value of the consumption between two reads
		 */
		private BigDecimal cmComputeConsumption(BigDecimal startReading, BigDecimal endReading, Register register) {
			
			BigDecimal returnValue = BigDecimal.ZERO;			
			try {
				/*
				 * Use the base routine CIPMDBRN which calculates the difference (a.k.a. consumption)
				 * between two register reads by taking the dial rollover into account.
				 */			
				CobolProgramCIPMDBRN cobolRoutine = CobolProgramCIPMDBRN.Factory.newInstance();
				CobolCopybookCICMDBRN cobolCopybook = cobolRoutine.getCobolCopybookCICMDBRN();
				// Set the input of the routine
				cobolCopybook.get_INPUT_WRK().set_START_READING(startReading);
				cobolCopybook.get_INPUT_WRK().set_END_READING(endReading);
				cobolCopybook.get_INPUT_WRK().set_NBR_OF_DGTS_LFT(register.getNumberOfDigitsLeft());			
				// Execute the routine
				cobolRoutine.callCobol();
				// Retrieve the ouput of the routine
				returnValue = cobolCopybook.get_OUTPUT_WRK().get_DIFFERENCE();
				
			}
			catch (Exception e) {
				// Error encountered while invoking base routine %1.
				addError(CustomMessageRepositoryMGE.commGenericErrorEncounteredInvokingBaseRoutine("CIPMDBRN"));
			}
			return returnValue;
		}
		/**
		 * Custom method which retrieves the correct register (of the specified UOM type) from the meter configuration 
		 * @param mtrConfigID the meter configuration id
		 * @param uom the unit of measure of the register to be retrieved
		 * @return the register which has the correct unit of measure from the meter configuration
		 */
		 	// START CHANGE - DarrylH-2023-05-26 -B28222
			//private Register cmRetrieveRegister(MeterConfiguration_Id mtrConfigID, UnitOfMeasure uom) {
			private Register cmRetrieveRegister(MeterConfiguration_Id mtrConfigID, String uom) {
			// END CHANGE - DarrylH-2023-05-26 -B28222	
			Register returnValue = null;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT REG_ID ");
			stringBuilder.append("FROM CI_REG REG ");
			stringBuilder.append("WHERE REG.MTR_ID = :mtrID ");
			// START CHANGE - DarrylH-2023-05-26 -B28222
			stringBuilder.append("AND REG.UOM_CD  IN (" + uom + ")");
			//stringBuilder.append("AND REG.UOM_CD = :uomCd ");
			// START CHANGE - DarrylH-2023-05-26 -B28222
			stringBuilder.append("AND REG.EFF_DTTM = (SELECT MAX(REG2.EFF_DTTM) ");
			stringBuilder.append("                    FROM CI_REG REG2 ");
			stringBuilder.append("                    WHERE REG2.MTR_ID = REG.MTR_ID ");
			stringBuilder.append("                    AND REG2.UOM_CD = REG.UOM_CD ");
			stringBuilder.append("                    AND TO_DATE(REG2.EFF_DTTM) <= :procDt ");
			stringBuilder.append("                    ) ");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("mtrID", mtrConfigID.getEntity().getMeter().getId());
			// START DELETE - DarrylH-2023-05-26 -B28222
			//prepState.bindId("uomCd", uom.getId());
			// END DELETE - DarrylH-2023-05-26 -B28222
			prepState.bindDate("procDt", this.getProcessDateTime().getDate());
			prepState.execute();
			/*
			 * start Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			// if (prepState.list().size() > 0) {
			// 	SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			if (notNull(sqlRow)) {
			/*
			 * end Change - EQuint - Defect 3443970 - 2016-05-31
			 */
				Register_Id regID = (Register_Id) sqlRow.getId("REG_ID", Register.class);
				returnValue = regID.getEntity();
			}
			else {
				// Failed to retrieve effective register with (%1) UOM for Meter Configuration (%2)
				// START CHANGE - DarrylH-2023-05-26 -B28222
	    		//addError(CustomMessageRepositoryMGE.ccb009FailedToRetrieveRegisterOfMeterConfig(mtrConfigID.getTrimmedValue(), uom.getId().getTrimmedValue()));
				addError(CustomMessageRepositoryMGE.ccb009FailedToRetrieveRegisterOfMeterConfig(mtrConfigID.getTrimmedValue(), uom));
				// End CHANGE - DarrylH-2023-05-26 -B28222
			}
			prepState.close();
			return returnValue;
		}
		/**
		 * Custom method to create the case
		 * @param caseType the case type of the case to be created
		 * @param charDTOList the list of case characteristics (DTO) to be created along with the case
		 * @param premID the premise id of the case (it is assumed that this is the only required usage for the case type)
		 */
		private void cmCreateCase(CaseType caseType, List<CaseCharacteristic_DTO> charDTOList, Premise_Id premID) {

			CaseStatus_Id caseStatusID = cmRetrieveInitialCaseStatus(caseType.getId());

			ToDoCase_DTO toDoCaseDTO = new ToDoCase_DTO();
			toDoCaseDTO.setCaseStatusId(caseStatusID);
			toDoCaseDTO.setPremiseId(premID);
			toDoCaseDTO.setUserId(getActiveContextUser().getId());

			CaseCreatorData caseCreatorData = CaseCreatorData.Factory.newInstance();
			caseCreatorData.setToDoCaseDTO(toDoCaseDTO); 
			caseCreatorData.setCaseCharacteristics(charDTOList);
			CaseCreator caseCreator = CaseCreator.Factory.newInstance();
			caseCreatorData = caseCreator.createCase(caseCreatorData);
			@SuppressWarnings("unused")
			ToDoCase_Id caseID = caseCreatorData.getCaseId();
			
		}
		/**
		 * Custom method to retrieve the Initial Case Status of the Case Type 
		 * @param caseTypeID the Case Type
		 * @return the Initial Case Status
		 */
		private CaseStatus_Id cmRetrieveInitialCaseStatus(CaseType_Id caseTypeID) {
			CaseStatus_Id returnValue = null;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT CASE_STATUS_CD ");
			stringBuilder.append("FROM CI_CASE_STATUS "); 
			stringBuilder.append("WHERE CASE_TYPE_CD = :caseTypeCd ");
			stringBuilder.append("AND STATUS_COND_FLG = :initialCond ");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("caseTypeCd", caseTypeID);
			prepState.bindLookup("initialCond", StatusConditionLookup.constants.INITIAL);
			prepState.execute();
			/*
			 * start Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			// if (prepState.list().size() > 0) {
			// 	SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			if (notNull(sqlRow)) {
			/*
			 * end Change - EQuint - Defect 3443970 - 2016-05-31
			 */
				String caseStatusCd = (String) sqlRow.get("CASE_STATUS_CD");
				returnValue = new CaseStatus_Id(caseTypeID, caseStatusCd.trim());
			}
			prepState.close();			
			return returnValue;
		}
		/**
		 * Custom method to form the Case Characteristic DTO
		 * @param charType the characteristic type for the case
		 * @param charValue the characteristic value
		 * @param charSeq the characteristic sequence
		 * @return returns the Case Characteristic Data Transfer Object
		 */
		private CaseCharacteristic_DTO cmFormCaseCharacteristicDTO(CharacteristicType charType, String charValue, BigInteger charSeq) {
			
			CaseCharacteristic_DTO returnValue;
			CaseCharacteristic_Id caseCharID = new CaseCharacteristic_Id(charType.getId(), ToDoCase_Id.NULL, charSeq);
			returnValue = caseCharID.newDTO();
			
			if (charType.getCharacteristicType().isPredefinedValue()) {
				returnValue.setCharacteristicValue(charValue);
			}
			else if (charType.getCharacteristicType().isForeignKeyValue()) {
				returnValue.setCharacteristicValueForeignKey1(charValue);
			}
			else {
				returnValue.setAdhocCharacteristicValue(charValue);
			}
			return returnValue;
		}
		/**
		 * Custom method which retrieves the meter's removal date time (if any) after the service has been stopped.
		 * @param mtrConfigID meter configuration id
		 * @param spID service point 
		 * @param stopMRDttm the service's stop meter read date time
		 * @return returnValue the meter's removal date time (if any) after the service has been stopped.
		 */
		private DateTime cmRetrieveMeterRemovalDate(MeterConfiguration_Id mtrConfigID, ServicePoint_Id spID, DateTime stopMRDttm) {
			DateTime returnValue = null;
			
			StringBuilder stringBuilder = new StringBuilder();						
			stringBuilder.append("SELECT MAX(EVT1.READ_DTTM) RMV_DTTM ");
			stringBuilder.append("FROM CI_SP_MTR_EV_VW EVT1 ");
			stringBuilder.append("WHERE EVT1.MTR_CONFIG_ID = :mtrConfigID "); 
			stringBuilder.append("AND EVT1.SP_ID = :spID ");
			stringBuilder.append("AND EVT1.READ_DTTM >= :stopMRDttm ");
			stringBuilder.append("AND EVT1.SP_MTR_EVT_FLG = :removalEvent ");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("mtrConfigID", mtrConfigID);
			prepState.bindId("spID", spID);
			prepState.bindDateTime("stopMRDttm", stopMRDttm);
			prepState.bindLookup("removalEvent", ServicePointMeterEventTypeLookup.constants.REMOVAL);
			prepState.execute();
			
			/*
			 * start Change - EQuint - Defect 3443970 - 2016-05-31
			 */
			// if (prepState.list().size() > 0) {				
			// 	SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			if (notNull(sqlRow)) {				
			/*
			 * end Change - EQuint - Defect 3443970 - 2016-05-31
			 */
				returnValue = (DateTime) sqlRow.getDateTime("RMV_DTTM");
			}
			
			prepState.close();
			return returnValue;
		}
	}
}
