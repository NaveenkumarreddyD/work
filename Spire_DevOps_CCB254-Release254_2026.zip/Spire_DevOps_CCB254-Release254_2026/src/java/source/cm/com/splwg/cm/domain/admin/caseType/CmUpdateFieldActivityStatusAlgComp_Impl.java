/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Update Field Activity Status 
 * 
 * This algorithm will either complete or cancel any Field Activities 
 * dispatched to L + G for the service point tied to the Case.
 *            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-04-05   JPunza  NI0007.5 Initial Version.
 * 2016-01-25   MPang	Updated for CCB v2.4 compilation.
 *************************************************************************/

package com.splwg.cm.domain.admin.caseType;

import java.math.BigInteger;
import java.util.Iterator;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseTypeEnterStatusAlgorithmSpot;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.FieldActivityCancelReason;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCancelProcessorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristics;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCaseCharacteristics;*/

import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.algorithm.enterStatus.EnterStatusAlgorithmSpot;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.entity.FieldActivityCancelReason;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCancelProcessorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristics;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCaseCharacteristics;
//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.shared.common.ApplicationError;

/**
 * @author jpunzalan2
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = servicePointIdCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = dispatchGroup, name = lgDispatchGroup, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = fieldActivityStatus, name = newFieldActivityStatus, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityCancelReason, name = cancelReason, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = fieldCodeCharacteristicType, type = entity)})
 */
public class CmUpdateFieldActivityStatusAlgComp_Impl 
        extends CmUpdateFieldActivityStatusAlgComp_Gen 
        //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        // implements CaseTypeEnterStatusAlgorithmSpot {
        //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation	
		implements EnterStatusAlgorithmSpot {
    // Constant Variable
    private final String SP_ID = "Service Point Id";
    private final String CANCEL_REASON = "Cancel Reason";
    private final String FIELD_CODE_CHAR = "Field Code Characteristic Type";
    private final String FIELD_CODE = "Field Code";
    
    // Soft Parameters
    private CharacteristicType spIdCharType;
    private FieldActivityStatusLookup newFaStatus;
    private FieldActivityCancelReason cancelReason;
    private CharacteristicType fieldCodeCharType;
    
    // Hard Parameter
    private ToDoCase toDoCase;
    
    public String getNextCaseStatus() {
        return null;
    }

    public String getNextTransCondition() {
        return null;
    }

    public Bool getShouldAutoTransition() {
        return null;
    }

    public void setCase(ToDoCase arg0) {
        toDoCase = arg0;
    }

    public void setCaseOriginalStatus(CaseStatus arg0) {

    }
    
    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        
        // Service Point Id Characteristic Type
        spIdCharType = getServicePointIdCharacteristicType();
        if (validateCharacteristicEntity(spIdCharType, CharacteristicEntityLookup.constants.CASE).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0007_5_ufasCharTypeInvalidForEntity(
                    getAlgorithm().getId().getTrimmedValue(),
                    SP_ID,
                    spIdCharType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.CASE.getLookupValue().fetchLanguageDescription()));
        }
                
        // New Field Activity Status
        newFaStatus = getNewFieldActivityStatus();
        if (!(newFaStatus.isCanceled() || newFaStatus.isCompleted())) {
            addError(CustomMessageRepositoryMDC.NI0007_5_faStatusEitherCompleteOrCancel(
                    getAlgorithm().getId().getTrimmedValue(),
                    newFaStatus.trimmedValue()));            
        }
          
        if (newFaStatus.isCanceled()) {
            
            // Field Activity Cancel Reason         
            cancelReason = getCancelReason(); 
            if (isNull(cancelReason)) {
                addError(CustomMessageRepositoryMDC.NI0007_5_requiredIfFieldStatusIsCancel(
                        getAlgorithm().getId().getTrimmedValue(),
                        CANCEL_REASON));
            }
            
            // Field Code Characteristic Type            
            fieldCodeCharType = getFieldCodeCharacteristicType();
            if (isNull(fieldCodeCharType)) {
                addError(CustomMessageRepositoryMDC.NI0007_5_requiredIfFieldStatusIsCancel(
                        getAlgorithm().getId().getTrimmedValue(),
                        FIELD_CODE_CHAR));
            }
            
            if (validateCharacteristicEntity(fieldCodeCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0007_5_ufasCharTypeInvalidForEntity(
                        getAlgorithm().getId().getTrimmedValue(),
                        FIELD_CODE,
                        fieldCodeCharType.getId().getTrimmedValue(),
                        CharacteristicEntityLookup.constants.FIELD_ACTIVITY.getLookupValue().fetchLanguageDescription()));
            }
        }
    }
    
    /**
     * This method validates if a characteristic type is valid for a specific characteristic entity.
     * @param charType - Characteristic Type
     * @param charEntityLookup - Characteristic Entity Lookup
     * @return Bool
     */
    private Bool validateCharacteristicEntity(CharacteristicType charType, CharacteristicEntityLookup charEntityLookup) {
        
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType.getId(), charEntityLookup);        
        if (isNull(charEntityId.getEntity())) {
            return Bool.FALSE;
        }
        
        return Bool.TRUE;
    }

    public void invoke() {

        // Retrieve Case Characteristics with a given Characteristic Type
        ToDoCaseCharacteristics caseChars = toDoCase.getCharacteristics();
        //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        //ListFilter<CaseCharacteristic> charFilter = caseChars.createFilter("where this.id.characteristicType = :charType " +
        //        "order by this.id.sequence desc");
        ListFilter<CaseCharacteristic> charFilter = caseChars.createFilter("where this.id.characteristicType = :charType " +
                "order by this.id.sequence desc" , getClass().getName());
       //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        charFilter.bindEntity("charType", spIdCharType);
        
        CaseCharacteristic caseChar = charFilter.firstRow();       
        if (notNull(caseChar)) {
            
            // Retrieve SP Id from characteristic           
            CharacteristicTypeLookup charTypeLookup = spIdCharType.getCharacteristicType();
            String spIdString = ""; 
            if (charTypeLookup.isForeignKeyValue()) {
                spIdString = caseChar.getCharacteristicValueForeignKey1().trim();
            }
            else if (charTypeLookup.isPredefinedValue()) {
                spIdString = caseChar.getCharacteristicValue().trim();
            }
            else {            
                spIdString = caseChar.getAdhocCharacteristicValue().trim();
            }
            
            ServicePoint sp = (new ServicePoint_Id(spIdString)).getEntity();
            if (isNull(sp)) {
                addError(CustomMessageRepositoryMDC.NI0007_5_spIdInvalid(
                        spIdCharType.getId().getTrimmedValue(), 
                        caseChar.fetchIdSequence().toString(),
                        spIdString));
            }
            
            // Get Field Code
            String fieldCode = "";
            if (newFaStatus.isCanceled()) {
                
                SQLResultRow caseLog = getLatestCaseLog().firstRow();                 
                if (notNull(caseLog)) {
                    fieldCode = caseLog.getString("VALUE").trim();
                }
            }
                
            // Get Field Activities
            Iterator<SQLResultRow> iter = retrieveFieldActivities(sp).list().iterator();
            while (iter.hasNext()) {
                
                SQLResultRow result = iter.next();
                FieldActivity fa = result.getEntity("FA_ID", FieldActivity.class);
                
                if (newFaStatus.isCompleted()) {
                    try {     
                        fa.complete();
                    }
                    catch (ApplicationError ae) {
                        addError(CustomMessageRepositoryMDC.NI0007_5_ufasUnableToCompleteFa(fa.getId().getTrimmedValue()));
                    }   
                }
                else {
                    
                    // Add Field Code Characteristic
                    if (notBlank(fieldCode)) {
                        addFaCharacteristic(fa, fieldCode);
                    }
                    
                    // Cancel FA
                    FieldActivityCancelProcessorData faCancelData = FieldActivityCancelProcessorData.Factory.newInstance();
                    faCancelData.setFieldActivity(fa);
                    faCancelData.setMustCancelDispatchedFa(Bool.TRUE);
                    faCancelData.setCancelReason(cancelReason);                
                    fa.cancel(faCancelData);
                }
            }          
        }
    }
    
    /**
     * This method retrieves Field Activities linked to given Service Point.
     * @return PreparedStatement
     */
    private PreparedStatement retrieveFieldActivities(ServicePoint sp) {
        
        PreparedStatement getFieldActivities = createPreparedStatement("SELECT FA.FA_ID " +
                "FROM CI_FA FA " +
                "WHERE FA.SP_ID = :sp " +
                "AND FA.FA_STATUS_FLG NOT IN (:completed, :canceled) " +
              //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
               //"AND FA.DISP_GRP_CD = :dispatchGroup");
    			"AND FA.DISP_GRP_CD = :dispatchGroup", getClass().getName());
        	//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        
        getFieldActivities.bindEntity("sp", sp);
        getFieldActivities.bindLookup("completed", FieldActivityStatusLookup.constants.COMPLETED);
        getFieldActivities.bindLookup("canceled", FieldActivityStatusLookup.constants.CANCELED);
        getFieldActivities.bindEntity("dispatchGroup", getLgDispatchGroup());
        
        return getFieldActivities;
    }
    
    /**
     * This method retrieves the latest Case Log a given the Characteristic Type.
     * @return PreparedStatement
     */
    private PreparedStatement getLatestCaseLog() {
        
        StringBuilder sb = new StringBuilder("SELECT ");
        CharacteristicTypeLookup charTypeLookup = fieldCodeCharType.getCharacteristicType();
        if (charTypeLookup.isForeignKeyValue()) {
            sb.append("CL.CHAR_VAL_FK1 AS VALUE ");
        }
        else if (charTypeLookup.isPredefinedValue()) {
            sb.append("CL.CHAR_VAL AS VALUE ");
        }
        else {            
            sb.append("CL.ADHOC_CHAR_VAL AS VALUE ");
        }
        sb.append("FROM CI_CASE_LOG CL " +
                "WHERE CL.CASE_ID = :case " +
                "AND CL.CHAR_TYPE_CD = :charType " +
                "AND CL.SEQ_NUM = (SELECT MAX(CL2.SEQ_NUM) FROM CI_CASE_LOG CL2 " +
                "       WHERE CL2.CASE_ID = CL.CASE_ID " +
                "       AND CL2.CHAR_TYPE_CD = CL.CHAR_TYPE_CD)");
       //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
       // PreparedStatement getCaseLog = createPreparedStatement(sb.toString());
        PreparedStatement getCaseLog = createPreparedStatement(sb.toString(), getClass().getName());
      //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        getCaseLog.bindEntity("case", toDoCase);
        getCaseLog.bindEntity("charType", fieldCodeCharType);
        
        return getCaseLog;
    }
    
    /**
     * This method adds Field Activity Characteristic.
     * @param fa - Field Activity
     * @param charValue - Characteristic Value
     */
    private void addFaCharacteristic(FieldActivity fa, String charValue) {
        
        CharacteristicTypeLookup charTypeLookup = fieldCodeCharType.getCharacteristicType(); 
        FieldActivityCharacteristics faChars = fa.getCharacteristics();
        
        // Determine sequence
        BigInteger sequence = BigInteger.ONE;     
       //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
       // ListFilter<FieldActivityCharacteristic> faCharFilter = faChars.createFilter("where this.id.characteristicType = :charType " +
       //         "order by this.id.sequence desc");
        
        ListFilter<FieldActivityCharacteristic> faCharFilter = faChars.createFilter("where this.id.characteristicType = :charType " +
                "order by this.id.sequence desc" , getClass().getName());
      //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        faCharFilter.bindEntity("charType", fieldCodeCharType);
        
        FieldActivityCharacteristic faChar = faCharFilter.firstRow();
        if (notNull(faChar)) {
            sequence = sequence.add(faChar.fetchIdSequence());
        }
        
        // Add FA Characteristic
        FieldActivityCharacteristic_DTO faCharDto = faChars.newChildDTO();
        
        if (charTypeLookup.isForeignKeyValue()) {
            faCharDto.setCharacteristicValueForeignKey1(charValue);
        }
        else if (charTypeLookup.isPredefinedValue()) {
            faCharDto.setCharacteristicValue(charValue); 
        } 
        else { 
            faCharDto.setAdhocCharacteristicValue(charValue);
        }
                
        faChars.add(faCharDto, fieldCodeCharType.getId(), sequence);         
    }
}
