/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Column Delimited Record class for Payment Header
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-05-27   RDizon  CCB041. Initial version.        
 **************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

/**
 * @author RDizon
 */
public class CmCheckExtractPaymentHeaderRecord extends ColumnDelimitedRecord {
    private static final String DELIMITER = "|";
        
    public CmCheckExtractPaymentHeaderRecord() {
        super(28);
    }
    
    public void setRecordType(String value) {
        this.leftPadColumn(1, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setProcessCode(String value) {
        this.leftPadColumn(2, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPayMethod(String value) {
        this.leftPadColumn(3, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setRmtMethod(String value) {
        this.leftPadColumn(4, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setCheckEftOrgDate(String value) {
        this.leftPadColumn(5, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setPaymentAmount(String value) {
        this.leftPadColumn(6, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setReferenceNumber(String value) {
        this.leftPadColumn(7, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPayeeName(String value) {
        this.leftPadColumn(8, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPayeeAddress1(String value) {
        this.leftPadColumn(9, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPayeeCszcCode(String value) {
        this.leftPadColumn(10, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPayeeCity(String value) {
        this.leftPadColumn(11, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPayeeState(String value) {
        this.rightPadColumn(12, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPayeePostal(String value) {
        this.rightPadColumn(13, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPayeeCountryCode(String value) {
        this.leftPadColumn(14, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setNumberOfInvoicesPaid(String value) {
        this.leftPadColumn(15, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPOSPaymentReferenceNumber(String value) {
        this.leftPadColumn(16, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setAccountReference(String value) {
        this.leftPadColumn(17, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setNextFieldQualifier(String value) {
        this.leftPadColumn(18, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setQualifiedField(String value) {
        this.leftPadColumn(19, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPayeeExtraAddress(String value) {
        this.leftPadColumn(20, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setRunCode1(String value) {
        this.leftPadColumn(21, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setInquiryTelephoneNumber(String value) {
        this.leftPadColumn(22, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setSpecialBatchNumber(String value) {
        this.leftPadColumn(23, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setDocumentId(String value) {
        this.leftPadColumn(24, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setReceivedABA(String value) {
        this.leftPadColumn(25, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setReceivedAccount(String value) {
        this.leftPadColumn(26, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPaymentGUID(String value) {
        this.leftPadColumn(27, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPayeeCountryName(String value) {
        this.leftPadColumn(28, value.length() + 1, value.trim());
    }
    
}
