/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPDRBAX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-11   EQuint      MGE-CCB003. Initial Version.
 * 2016-05-30   MPang       Defect 3444302. Added close connection
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.  
 * 2022-11-09	EQuint		B-24230. add Equifax logic checking     
 * 2023-04-19   DLampa      E-06734. Add a parameter to indicate if 
 *                          a deposit should always be recommended     
 * 2025-11-14   EQuint      CCB25.4 Upgrade
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.depositClass.algorithm.recommendation;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.admin.depositClass.algorithm.recommendation.DepositClassDepositRecommendationAlgorithmSpot;
import com.splwg.ccb.domain.admin.depositClass.algorithm.recommendation.DepositRecommendationResult;
import com.splwg.ccb.domain.admin.depositClass.entity.DepositClass;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementTypeStartOption.entity.ServiceAgreementTypeStartOption;
import com.splwg.ccb.domain.admin.sicCode.entity.SicCode;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpdrbax;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = depositMultiplier, required = true, type = decimal)
 *            , @AlgorithmSoftParameter (name = billHistoryPeriod, required = true, type = decimal)
 *            , @AlgorithmSoftParameter (name = minBillHistory, required = true, type = decimal)
 *            , @AlgorithmSoftParameter (name = defaultDepositAmount, type = decimal)
 *            , @AlgorithmSoftParameter (name = thresholdDepositAmount, type = decimal)
 *            , @AlgorithmSoftParameter (name = equifaxCheck, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (name = requireDeposit, required = true, type = boolean)})
 */
public class CmUseAveBillAmountThresholdAlgComp_Impl extends
		CmUseAveBillAmountThresholdAlgComp_Gen implements
		DepositClassDepositRecommendationAlgorithmSpot {

	// hard parameters
	private DepositClass depositClass;
	private Bool isGoodCusomer;
	private DepositRecommendationResult depositRecommendationResult;
	private Money recommendationAmount;
	private Account account;
	private Premise premise;
	private Money recurringChargeAmount;
	private ServiceAgreementType saType;
	private ServiceAgreementTypeStartOption saTypeStartOption;
	private Bool shouldAlwaysCalculateRecommendation;
	private SicCode sicCode;
	private Date startDate;
	private Money totalAmountToBill;
	
	// soft parameters
	private BigDecimal depositMultiplier;
	private BigDecimal billHistoryPeriod;
	private BigDecimal minBillHistory;
	private BigDecimal defaultDepositAmount;
	private BigDecimal thresholdDepositAmount;
	// start add - EQuint - B-24230 - 2022-11-09
	private Bool equifaxCheck;
	// end add - EQuint - B-24230 - 2022-11-09
	// Start Add - DLampa - E-06734 - 2023-04-19
	private Bool requireDeposit;
	// End Add - DLampa - E-06734 - 2023-04-19	
	
	// Work variables
	private Cmpdrbax cmpdrbax;
	//Start Add - MPang - Defect 3444302- 2016-05-30
	private Connection connection;
	//End Add - MPang - Defect 3444302- 2016-05-30
	
	// Debug logger
    private Logger logger = LoggerFactory.getLogger(getClass());  
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";

	@Override
	public DepositClass getDepositClass() {
		return depositClass;
	}

	@Override
	public Bool getIsGoodCustomer() {
		return isGoodCusomer;
	}

	@Override
	public DepositRecommendationResult getRecommendationResult() {
		return depositRecommendationResult;
	}

	@Override
	public Money getRecommendedAmount() {
		return recommendationAmount;
	}

	@Override
	public void setAccount(Account arg0) {
		this.account = arg0;
	}

	@Override
	public void setDepositClass(DepositClass arg0) {
		this.depositClass = arg0; 
	}

	@Override
	public void setPremise(Premise arg0) {
		this.premise = arg0;
	}

	@Override
	public void setRecurringChargeAmount(Money arg0) {
		this.recurringChargeAmount = arg0;
	}

	@Override
	public void setServiceAgreementType(ServiceAgreementType arg0) {
		this.saType = arg0;
	}

	@Override
	public void setServiceAgreementTypeStartOption(
			ServiceAgreementTypeStartOption arg0) {
		this.saTypeStartOption = arg0;
	}

	@Override
	public void setShouldAlwaysCalculateRecommendation(Bool arg0) {
		this.shouldAlwaysCalculateRecommendation = arg0;
	}

	@Override
	public void setSicCode(SicCode arg0) {
		this.sicCode = arg0;
	}

	@Override
	public void setStartDate(Date arg0) {
		this.startDate = arg0;
	}

	@Override
	public void setTotalAmountToBill(Money arg0) {
		this.totalAmountToBill = arg0;
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		depositMultiplier = getDepositMultiplier();
		billHistoryPeriod = getBillHistoryPeriod();
		minBillHistory = getMinBillHistory();
		defaultDepositAmount = getDefaultDepositAmount();
		thresholdDepositAmount = getThresholdDepositAmount();
		// start add - EQuint - B-24230 - 2022-11-09
		equifaxCheck = getEquifaxCheck();
		// end add - EQuint - B-24230 - 2022-11-09
		// Start Add - DLampa - E-06734 - 2023-04-19
		requireDeposit = getRequireDeposit();
		// End Add - DLampa - E-06734 - 2023-04-19
		
		
	}
	
	@Override
	public void invoke() {
		
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			if (notNull(account)) {
				cmpdrbax.setDrdrxInputWrkAcctId(account.getId().getTrimmedValue());
			}else{
				cmpdrbax.setDrdrxInputWrkAcctId(CobolCode.SPACES.toString());
			}
			if (notNull(premise)) {
				cmpdrbax.setInputWrkPremId(premise.getId().getTrimmedValue());
			}else{
				cmpdrbax.setInputWrkPremId(CobolCode.SPACES.toString());
			}
			if (notNull(depositClass)) {
				cmpdrbax.setDrdrxInputWrkDepClCd(depositClass.getId().getTrimmedValue());
			}else{
				cmpdrbax.setDrdrxInputWrkDepClCd(CobolCode.SPACES.toString());
			}
			if (notNull(shouldAlwaysCalculateRecommendation)) {
				String alwaysCalcRcmdnSw = (shouldAlwaysCalculateRecommendation.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpdrbax.setAlwaysCalcRcmndSw(alwaysCalcRcmdnSw);
			}else{
				cmpdrbax.setAlwaysCalcRcmndSw(CobolCode.SPACES.toString());
			}
			if (notNull(saType)) {
				cmpdrbax.setDrdrxInputWrkCisDivision(saType.getId().getDivision().getId().getTrimmedValue());
			}else{
				cmpdrbax.setDrdrxInputWrkCisDivision(CobolCode.SPACES.toString());
			}
			if (notNull(saType)) {
				cmpdrbax.setSaTypeCd(saType.getId().getSaType().trim());
			}else{
				cmpdrbax.setSaTypeCd(CobolCode.SPACES.toString());
			}
			if (notNull(saTypeStartOption)) {
				cmpdrbax.setStartOptCd(saTypeStartOption.getId().getStartOption().trim());
			}else{
				cmpdrbax.setStartOptCd(CobolCode.SPACES.toString());
			}
			if (notNull(startDate)) {
				cmpdrbax.setInputWrkStartDt(startDate.toString());
			}else{
				cmpdrbax.setInputWrkStartDt(CobolCode.SPACES.toString());
			}
			if (notNull(sicCode)) {
				cmpdrbax.setSicCd(sicCode.getId().getTrimmedValue());
			}else{
				cmpdrbax.setSicCd(CobolCode.SPACES.toString());
			}
			if (notNull(totalAmountToBill)) {
				cmpdrbax.setTotToBillAmt(totalAmountToBill.getAmount().toBigDecimal());
			}else{
				cmpdrbax.setTotToBillAmt(java.math.BigDecimal.ZERO);
			}
			if (notNull(recurringChargeAmount)) {
				cmpdrbax.setRcrChgAmt(recurringChargeAmount.getAmount().toBigDecimal());
			}else{
				cmpdrbax.setRcrChgAmt(java.math.BigDecimal.ZERO);
			}
			
			// set cobol program's soft parameters
			cmpdrbax.setAlgParmVal(1, depositMultiplier.toString()); 
			cmpdrbax.setAlgParmVal(2, billHistoryPeriod.toString()); 
			cmpdrbax.setAlgParmVal(3, minBillHistory.toString()); 
			if (notNull(defaultDepositAmount)) {
				cmpdrbax.setAlgParmVal(4, defaultDepositAmount.toString()); 
			}else{
				cmpdrbax.setAlgParmVal(4, CobolCode.SPACES.toString());
			}
			if (notNull(thresholdDepositAmount)) {
				cmpdrbax.setAlgParmVal(5, thresholdDepositAmount.toString());
			}else{
				cmpdrbax.setAlgParmVal(5, CobolCode.SPACES.toString());
			}
			
			// start add - EQuint - B-24230 - 2022-11-09
			cmpdrbax.setEquifaxCheck(equifaxCheck);
			// end add - EQuint - B-24230 - 2022-11-09

			// Start Add - DLampa - E-06734 - 2023-04-19
			cmpdrbax.setRequireDeposit(requireDeposit);
			// End Add - DLampa - E-06734 - 2023-04-19		
			
			// invoke the main method
		    cmpdrbax.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
		    //Start Delete - MPang - Defect 3444302- 2016-05-30
		    //ex.printStackTrace();
		    //End Delete - MPang - Defect 3444302- 2016-05-30
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmpdrbax.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmpdrbax.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmpdrbax.getMessageParm(i);
			    			if (notBlank(cmpdrbax.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmpdrbax.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmpdrbax.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmpdrbax.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmpdrbax.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    	recommendationAmount = new Money(cmpdrbax.getRcmendAmt().toPlainString(), account.getCurrency().getId());
		    	isGoodCusomer = Bool.valueOf(Boolean.valueOf(cmpdrbax.getOutputWrkGdCustSw()));
		    	depositRecommendationResult = new DepositRecommendationResult(cmpdrbax.getRcmendFlg());
		    }
		    else {
		        //Start Add - MPang - Defect 3444302- 2016-05-30
		        ex.printStackTrace();
		        //End Add - MPang - Defect 3444302- 2016-05-30
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmpdrbax=Session.returnSessionAndCodeToCache(cmpdrbax);
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
			// //Start Add - MPang - Defect 3444302- 2016-05-30
			// try {
			//     connection.close();
			// } catch (SQLException e) {
			//     addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
			// }
			//End Add - MPang - Defect 3444302- 2016-05-30
			// end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}

	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
		FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
		RequestContext context = session.getRequestContext();
		
		// start update - equint - 2025-11-14 - CCB25.4 Upgrade
  		session.doWork(new ConnectionWork() {
  			
  			@Override
  			public void execute(Connection connection) throws SQLException {
  				try {   				
  					String username = connection.getMetaData().getUserName();
  					String url = connection.getMetaData().getURL();
  					
  					CobolSession.setLogSessionStartEnd(false);
  				    cmpdrbax=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpdrbax.class);
  					
  					cmpdrbax.getSession().getDbSession().setUpdateConnection(connection);
  					cmpdrbax.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
  					
  					// set ZSTAT parameters

  					cmpdrbax.setProcessDttmProcessDt(getProcessDateTime().getDate().toString());
  					cmpdrbax.setProcessDttmSep("-");
  					cmpdrbax.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
  					
  					if (session.isOnlineConnection()) { 
  						cmpdrbax.setConnectionFlg(CONNECTION_ONLINE);
  					}
  					else {
  						cmpdrbax.setConnectionFlg(CONNECTION_BATCH);
  					}
  					
  			        cmpdrbax.setUserId(context.getUserId()); 
  			        cmpdrbax.setLanguageCd(context.getLanguageCode());
  			        
  			        if (context.ignoreWarnings()) {
  			        	cmpdrbax.setIgnoreWarningSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpdrbax.setIgnoreWarningSw(SWITCH_NO);
  			        }
  			        
  			        if (session.getBatchInstanceId() != null) {
  			        	cmpdrbax.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
  			        	
  					} else {
  						cmpdrbax.setSchedulerId(new BigDecimal(0).toBigDecimal());
  					}
  			        
  			        cmpdrbax.setAppSvcId(context.getSecurityServiceIdContext());
  			        
  			        DatabaseHelper dbHelper = session.getDatabaseHelper();
  			        cmpdrbax.setDbMode(dbHelper.getCobolDBMode());
  			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
  			        //cmpdrbax.setSplHighValue(cmpdrbax.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
  			        //cmpdrbax.setSplLowValue(cmpdrbax.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
  			        
  			        cmpdrbax.setSplHighValue(cmpdrbax.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
  			        cmpdrbax.setSplLowValue(cmpdrbax.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
  			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
  			        
  			        cmpdrbax.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
  			        
  			        cmpdrbax.setLkExpiryDt(Date.MAX.toString());
  			        
  			        cmpdrbax.setProgramStatus(" ");
  			        
  			        if (context.getRandomGeneratorSeedSet().isTrue()) {
  			        	cmpdrbax.setRandomGenSeedSw(SWITCH_YES);
  			        	cmpdrbax.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
  			        	cmpdrbax.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
  			        	cmpdrbax.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
  			        	cmpdrbax.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
  			        }
  			        else {
  			        	cmpdrbax.setRandomGenSeedSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceStandardOut()) { 
  			        	cmpdrbax.setTrcStdoutSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpdrbax.setTrcStdoutSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramStart()) { 
  			        	cmpdrbax.setTrcProgStartSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpdrbax.setTrcProgStartSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramExit()) { 
  			        	cmpdrbax.setTrcProgExitSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpdrbax.setTrcProgExitSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceSQL()) { 
  			        	cmpdrbax.setTrcExecSqlSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpdrbax.setTrcExecSqlSw(SWITCH_NO);
  			        }
  			        
  			        // Set ZMSGN parms
  			        BigInteger messageSequence = session.getMessageSequence();
  			        if (notNull(messageSequence)) {
  			        	cmpdrbax.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
  			        }
  			        else {
  			        	cmpdrbax.setMessageSeq(new BigDecimal(0).toBigDecimal());
  			        }
  				}
  				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		 
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//		//Start Change - MPang - Defect 3444302- 2016-05-30
//		//Connection connection = implementor.getConnectionProvider().getConnection();
//		connection = implementor.getConnectionProvider().getConnection();
//		//End Change - MPang - Defect 3444302- 2016-05-30
//		
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmpdrbax=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpdrbax.class);
//		
//		cmpdrbax.getSession().getDbSession().setUpdateConnection(connection);
//		cmpdrbax.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		
//		// set ZSTAT parameters
//
//		cmpdrbax.setProcessDttmProcessDt(getProcessDateTime().getDate().toString());
//		cmpdrbax.setProcessDttmSep("-");
//		cmpdrbax.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmpdrbax.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmpdrbax.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//        cmpdrbax.setUserId(context.getUserId()); 
//        cmpdrbax.setLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmpdrbax.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmpdrbax.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmpdrbax.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmpdrbax.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmpdrbax.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmpdrbax.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmpdrbax.setSplHighValue(cmpdrbax.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmpdrbax.setSplLowValue(cmpdrbax.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmpdrbax.setSplHighValue(cmpdrbax.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmpdrbax.setSplLowValue(cmpdrbax.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmpdrbax.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmpdrbax.setLkExpiryDt(Date.MAX.toString());
//        
//        cmpdrbax.setProgramStatus(" ");
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmpdrbax.setRandomGenSeedSw(SWITCH_YES);
//        	cmpdrbax.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmpdrbax.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmpdrbax.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmpdrbax.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmpdrbax.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmpdrbax.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmpdrbax.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmpdrbax.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmpdrbax.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmpdrbax.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmpdrbax.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmpdrbax.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmpdrbax.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmpdrbax.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmpdrbax.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }
  		
  	// end update - equint - 2025-11-14 - CCB25.4 Upgrade

	}

}
