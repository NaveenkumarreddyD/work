/*
 *************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Automatic De-enrollment from FCAP Batch 
 * 
 * This Batch Program will check for accounts that have FCAP customer class
 * or FCAP collection class or FCAP Budget Plan and de-enroll the customer.
 * 
 * 	- break the FCAP Payment Arrangements (if any) 
 *  - cancel customer's budget
 *  - revert the customer class, collection class and budget plan to 
 *    pre-FCAP enrollment values.
 *  - remove old customer class and federal poverty level Account
 *    Characteristics
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2019-05-10	JHERNA          Change Request (SysAid#293190).
 * 2020-01-06   JHERNA          SysAid#307713. Create Customer Contact.
 *                              New Parameters:
 *                                - CC_CLASS
 *                                - CC_TYPE
 *                                - CONTACT_STATUS_OPEN
 *                                - CC_COMMENTS
 *                              
 **************************************************************************
 */
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadIterationStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.StringId;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.CustomerContactStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.adjustmentCancelReason.entity.AdjustmentCancelReason;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.budgetPlan.entity.BudgetPlan;
import com.splwg.ccb.domain.admin.budgetPlan.entity.BudgetPlan_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.collectionClass.entity.CollectionClass_Id;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClassControl;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClassControl_Id;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass_Id;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristics;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.api.lookup.CmLowIncomeProgramConfigurationsOptionTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 90622
 *
@BatchJob (modules = {}, softParameters = { @BatchJobSoftParameter (name = AGE_DAYS_TO_DE_ENROLL, required = true, type = integer)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = FCAP_FEAT_CONF, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = FCAP_SA_TYPES, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CHAR_TYPE_BROKEN_PA, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CHAR_VAL_BROKEN_PA, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = adjustmentType, name = ADJ_TYPE_SYNC, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = adjustmentCancelReason, name = ADJ_CAN_RSN_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CC_CLASS, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CC_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CONTACT_STATUS_OPEN, required = true, type = boolean)
 *            , @BatchJobSoftParameter (name = CC_COMMENTS, required = false, type = string)})
 */
public class CmFCAPAutomaticDeEnrollmentBatch 
		extends CmFCAPAutomaticDeEnrollmentBatch_Gen {

	public Class<CmFCAPAutomaticDeEnrollmentBatchWorker> getThreadWorkerClass() {
		return CmFCAPAutomaticDeEnrollmentBatchWorker.class;
	}

	@Override
	public void validateSoftParameters(boolean isNewRun) {
		
		// Validate parameter age days to de enroll
		BigInteger ageDays = this.getParameters().getAGE_DAYS_TO_DE_ENROLL();
		if (ageDays.compareTo(BigInteger.ZERO) <= 0) {
			addError(CustomMessageRepositoryMGE.commBatchParameterMustBeGreaterThanZero("Age Days To De-enroll", ageDays.toString().trim()));
		}
		// Validate parameter fcap SA Types
		String fcapSaTypes = this.getParameters().getFCAP_SA_TYPES();
		StringTokenizer st = new StringTokenizer(fcapSaTypes, ","); 
		while (st.hasMoreTokens()) {
			validateSaType(st.nextToken(), "List of FCAP SA Types");
		}
		// Validate parameter char type broken pay arrangement
		CharacteristicType charTypeBrokenPA = this.getParameters().getCHAR_TYPE_BROKEN_PA();
		CharacteristicEntity_Id charEntityID = new CharacteristicEntity_Id(charTypeBrokenPA, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT);
		if (isNull(charEntityID.getEntity())) {
			// Algorithm %1's parameter '%2%3' value (%4) is not a valid char type for %5%6 entity
			addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharTypeForEntity("Broken payment arrangement characteristic type", 
					charTypeBrokenPA.getId().getTrimmedValue(),
					"Service Agreement"));					
		}
		
		// Validate parameter char value broken pay arrangement
		String charValBrokenPA = this.getParameters().getCHAR_VAL_BROKEN_PA();
		// Validate that the characteristic value is valid for the characteristic type retrieved for algorithm parameter 10
		CharacteristicValue_Id charValID = new CharacteristicValue_Id(charTypeBrokenPA, charValBrokenPA.trim());
		if (isNull(charValID.getEntity())) {
			// Algorithm %1's parameter '%2%3' value (%4) is not a valid char value for %5 char type.
			addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharValueForCharType("Broken payment arrangement characteristic value", 
					charValBrokenPA.trim(), charTypeBrokenPA.getId().getTrimmedValue()));					
		}	
		
		// START ADD - JHERNA - 2020-01-06 - SysAid#307713
		CustomerContactClass ccClass = this.getParameters().getCC_CLASS();
		String ccType = this.getParameters().getCC_TYPE();
		CustomerContactType_Id ccTypeID = new CustomerContactType_Id(ccClass, ccType.trim());
		if (isNull(ccTypeID)
				|| isNull(ccTypeID.getEntity())) {
			// Batch %1 parameter '%2%3' is an invalid Contact Type (%4) for Contact Class (%5)
			addError(CustomMessageRepositoryMGE.commBatchParameterContactTypeInvalidForContactClass(
					this.getBatchControlId().getTrimmedValue(), 
					"Customer Contact Type", 
					ccType.trim(),
					ccClass.getId().getTrimmedValue()));
		}
		// END ADD - JHERNA - 2020-01-06 - SysAid#307713
	}
	
	private void validateSaType(String saType, String parmDesc) {
		
		if (notBlank(saType)) {
			
			PreparedStatement prepState = createPreparedStatement(
					"SELECT 'X' " +
					"FROM CI_SA_TYPE " +
					"WHERE SA_TYPE_CD = '"+saType.trim()+"' "
					, 
					"==validateSaType==");
			prepState.setAutoclose(false);
			prepState.execute();
			
			if (isNull(prepState.firstRow())) {
				prepState.close();
				// Algorithm %1's parameter '%2%3' has an invalid value (%4).
				addError(CustomMessageRepositoryMGE.commBatchParameterInvalid(parmDesc, saType));
			}
			prepState.close();
		}
	}

	/*=============*/
	/* INNER CLASS */
	/*=============*/
	public static class CmFCAPAutomaticDeEnrollmentBatchWorker 
			extends CmFCAPAutomaticDeEnrollmentBatchWorker_Gen {
		/*================*/
		/* Soft Parameters*/
		/*================*/
		private BigInteger parmAgeDaysToDeEnroll;
		private FeatureConfiguration parmFeatConfFCAP;
		private String parmFcapSaTypes;
		private CharacteristicType parmCharTypeBrokenPayArrangement;
		private String parmCharValBrokenPayArrangement;
		private AdjustmentType parmAdjTypeSync;
		private AdjustmentCancelReason parmAdjCancelReason;
		// START ADD - JHERNA - 2020-01-06 - SysAid#307713
		private Bool parmIsCcStatusOpen;
		private String parmCcComments;
		// END ADD - JHERNA - 2020-01-06 - SysAid#307713
		/*================*/
		/* Work Variables */
		/*================*/
		private Date wProcessDate;
		private CharacteristicValue wCharValueBrokenPA;
		private CharacteristicType_Id wCharTypeIdOldCustomerClass;
		private CharacteristicType_Id wCharTypeIdFederalPovertyLevel;		
		private BudgetPlan_Id wBudPlanIdFCAP;
		private CustomerClass_Id wCustClassIdFCAP;
		private CollectionClass_Id wCollClassIdFCAP;	
		private String wFcapSaTypes;
		private static final CmMGEFeatureConfigurationOptionsRetriever FC_HELPER = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();		
		// START ADD - JHERNA - 2020-01-06 - SysAid#307713
		private CustomerContactType wCustomerContactType;
		// END ADD - JHERNA - 2020-01-06 - SysAid#307713
		
		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful, ThreadWorkUnit lastWorkUnit) 
				throws ThreadAbortedException, RunAbortedException {
			
			// Retrieve soft parameters
			parmAgeDaysToDeEnroll = this.getParameters().getAGE_DAYS_TO_DE_ENROLL();
			parmFeatConfFCAP = this.getParameters().getFCAP_FEAT_CONF();
			parmFcapSaTypes = this.getParameters().getFCAP_SA_TYPES();
			
			// Retrieve Old Customer Class characteristic type
			wCharTypeIdOldCustomerClass = FC_HELPER.getCharacteristicTypeFeatureOptionValue(parmFeatConfFCAP.getId(),
					CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.OLD_CUSTOMER_CLASS_CHARACTERISTIC_TYPE,
					Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.ACCOUNT);
			
			// Retrieve Federal Poverty Level characteristic type
			wCharTypeIdFederalPovertyLevel = FC_HELPER.getCharacteristicTypeFeatureOptionValue(parmFeatConfFCAP.getId(), 
					CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FPL_CHARACTERISTIC_TYPE, 
					Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.ACCOUNT);
			
			parmCharTypeBrokenPayArrangement = this.getParameters().getCHAR_TYPE_BROKEN_PA();
			parmCharValBrokenPayArrangement = this.getParameters().getCHAR_VAL_BROKEN_PA();
			parmAdjTypeSync = this.getParameters().getADJ_TYPE_SYNC();
			parmAdjCancelReason = this.getParameters().getADJ_CAN_RSN_CD();
			
			wProcessDate = this.getProcessDateTime().getDate();
			wCharValueBrokenPA = new CharacteristicValue_Id(parmCharTypeBrokenPayArrangement, parmCharValBrokenPayArrangement.trim()).getEntity();			
			
			String fcapBudPlanStr = FC_HELPER.getMaximumSequenceFeatureOptionValue(parmFeatConfFCAP.getId(), CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_BUDGET_PLAN, Bool.TRUE).trim();
			BudgetPlan_Id budPlanId = new BudgetPlan_Id(fcapBudPlanStr);
			if (isNull(budPlanId.getEntity())) {
				addError(CustomMessageRepositoryMGE.commFeatConfOptIsNotTheExpectedEntity(parmFeatConfFCAP.getId().getTrimmedValue(),
						CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_BUDGET_PLAN.getLookupValue().fetchLanguageDescription().trim(),
						fcapBudPlanStr, "Budget Plan"));
			}
			wBudPlanIdFCAP = budPlanId;
			
			String fcapCustomerClassStr = FC_HELPER.getMaximumSequenceFeatureOptionValue(parmFeatConfFCAP.getId(), CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_CUSTOMER_CLASS, Bool.TRUE).trim();
			CustomerClass_Id custClassId = new CustomerClass_Id(fcapCustomerClassStr);
			if (isNull(custClassId.getEntity())) {
				addError(CustomMessageRepositoryMGE.commFeatConfOptIsNotTheExpectedEntity(parmFeatConfFCAP.getId().getTrimmedValue(),
						CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_CUSTOMER_CLASS.getLookupValue().fetchLanguageDescription().trim(),
						fcapCustomerClassStr, "Customer Class"));
			}
			wCustClassIdFCAP = custClassId;
			
			String fcapCollectionClassStr = FC_HELPER.getMaximumSequenceFeatureOptionValue(parmFeatConfFCAP.getId(), CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_COLLECTION_CLASS, Bool.TRUE).trim();
			CollectionClass_Id collClassId = new CollectionClass_Id(fcapCollectionClassStr);
			if (isNull(collClassId.getEntity())) {
				addError(CustomMessageRepositoryMGE.commFeatConfOptIsNotTheExpectedEntity(parmFeatConfFCAP.getId().getTrimmedValue(),
						CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_COLLECTION_CLASS.getLookupValue().fetchLanguageDescription().trim(),
						fcapCustomerClassStr, "Collection Class"));
			}
			wCollClassIdFCAP = collClassId;
			
			// build sa types
			wFcapSaTypes = " ";
			StringTokenizer st = new StringTokenizer(parmFcapSaTypes, ",");
			while (st.hasMoreTokens()) {
				String saType = st.nextToken();
				
				wFcapSaTypes = wFcapSaTypes.trim().concat("'");
				wFcapSaTypes = wFcapSaTypes.trim().concat(saType);
				wFcapSaTypes = wFcapSaTypes.trim().concat("'");
				wFcapSaTypes = wFcapSaTypes.trim().concat(",");				
			}
			wFcapSaTypes = wFcapSaTypes.trim();
			wFcapSaTypes = wFcapSaTypes.substring(0, (wFcapSaTypes.length() - 1));			
			
			// START ADD - JHERNA - 2020-01-06 - SysAid#307713
			CustomerContactClass ccClass = this.getParameters().getCC_CLASS();
			String ccType = this.getParameters().getCC_TYPE().trim();
			CustomerContactType_Id cccTypeID = new CustomerContactType_Id(ccClass, ccType);
			wCustomerContactType = cccTypeID.getEntity();
			
			parmIsCcStatusOpen = this.getParameters().getCONTACT_STATUS_OPEN();
			parmCcComments = this.getParameters().getCC_COMMENTS();
			// END ADD - JHERNA - 2020-01-06 - SysAid#307713
			
			this.startResultRowQueryIteratorForThread(Account_Id.class);
		}
		
		@SuppressWarnings("rawtypes")
		@Override
		protected QueryIterator getQueryIteratorForThread(StringId lowId,
				StringId highId) {
						
			StringBuilder mainSelect = new StringBuilder();
			
			/* Selection 1: All Accounts with Pending Start or Active FCAP PA SAs whose age exceeds or reached the age days to deenroll */
			mainSelect.append("SELECT UNIQUE(SA.ACCT_ID), 'PASA' SEL ");  
			mainSelect.append("FROM CI_SA SA ");   
			mainSelect.append("WHERE SA.SA_STATUS_FLG IN (:pendingStart, :active) ");   
			mainSelect.append("AND SA.SA_TYPE_CD IN ("+wFcapSaTypes+") ");   
			mainSelect.append("AND (:processDate - SA.START_DT) >= :ageDaysToDeenroll "); 
			mainSelect.append("AND SA.ACCT_ID BETWEEN :lowID AND :highID "); 
			/* UNION */
			mainSelect.append("UNION ");
			/* Selection 2: All accounts which have either FCAP customer class, collection class or budget plan whose most effective  */
			/*              Old Customer Class characteristic's effective date exceeds or reached the age days to deenroll parameter  */
			/*              Making sure that this account does not have any pending start or active FCAP PA SA (since that should      */
			/*              fall on Selection 1 above already).                                                                       */
			mainSelect.append("SELECT ACCT.ACCT_ID, 'ACCT' SEL "); 
			mainSelect.append("FROM CI_ACCT ACCT ");  
			mainSelect.append("WHERE (ACCT.CUST_CL_CD = :fcapCustClass ");  
			mainSelect.append("	     OR ACCT.COLL_CL_CD = :fcapCollClass ");  
			mainSelect.append("	     OR ACCT.BUD_PLAN_CD = :fcapBudPlan "); 
			mainSelect.append("       ) ");  
			mainSelect.append("AND EXISTS (SELECT 'X' ");  
			mainSelect.append("				    FROM CI_ACCT_CHAR AC ");  
			mainSelect.append("				    WHERE AC.ACCT_ID = ACCT.ACCT_ID ");  
			mainSelect.append("				    AND AC.CHAR_TYPE_CD = :charTypeOldCustClass ");  
			mainSelect.append("				    AND AC.EFFDT = (SELECT MAX(AC2.EFFDT) ");  
			mainSelect.append("								            FROM CI_ACCT_CHAR AC2 ");  
			mainSelect.append("								            WHERE AC2.ACCT_ID = AC.ACCT_ID ");  
			mainSelect.append("								            AND AC2.CHAR_TYPE_CD = AC.CHAR_TYPE_CD ");  
			mainSelect.append("								            AND AC2.EFFDT <= :processDate ");  
			mainSelect.append("								           ) ");  
			mainSelect.append("				    AND (:processDate - AC.EFFDT) >= :ageDaysToDeenroll ");  
			mainSelect.append("           ) "); 
			mainSelect.append("AND NOT EXISTS (SELECT 'X' "); 
			mainSelect.append("                FROM CI_SA SA "); 
			mainSelect.append("                WHERE SA.ACCT_ID = ACCT.ACCT_ID "); 
			mainSelect.append("                AND SA.SA_STATUS_FLG IN (:pendingStart, :active) "); 
			mainSelect.append("                AND SA.SA_TYPE_CD IN ("+wFcapSaTypes+") "); 
			mainSelect.append("                ) "); 
			mainSelect.append("AND ACCT.ACCT_ID BETWEEN :lowID AND :highID "); 
			mainSelect.append("ORDER BY ACCT_ID "); 

			PreparedStatement prepState = createPreparedStatement(mainSelect.toString(), 
					"===CmFCAPAutomaticDeEnrollmentBatch.Main Selection Criteria===");
			prepState.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
			prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);			
			prepState.bindDate("processDate", wProcessDate);
			prepState.bindBigInteger("ageDaysToDeenroll", parmAgeDaysToDeEnroll);	
			prepState.bindId("charTypeOldCustClass", wCharTypeIdOldCustomerClass);
			prepState.bindId("fcapCustClass", wCustClassIdFCAP);
			prepState.bindId("fcapCollClass", wCollClassIdFCAP);
			prepState.bindId("fcapBudPlan", wBudPlanIdFCAP);					
			prepState.bindId("lowID", lowId);
			prepState.bindId("highID", highId);
			prepState.setAutoclose(false);
			prepState.execute();
			QueryIterator<SQLResultRow> returnValue = prepState.iterate(); 			
			return returnValue;
		}

		@Override
		protected ThreadWorkUnit getNextWorkUnit(QueryResultRow row) {

			ThreadWorkUnit twu = new ThreadWorkUnit(row.getId("ACCT_ID", Account.class));
			twu.addSupplementalData("selectedFrom", row.getString("SEL"));
			return twu;
		}  
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new ThreadIterationStrategy(this);
		}
 
		@SuppressWarnings("unused")
		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			Account_Id acctID = (Account_Id) unit.getPrimaryId();
			String selectedFrom = (String) unit.getSupplementallData("selectedFrom");

			/*==================================*/
			/*Break the FCAP Payment Arrangement*/
			/*==================================*/
			Iterator<ServiceAgreement_Id> collFCAPSas = getActiveFCAPSas(acctID);

			while (collFCAPSas.hasNext()) {
	
				ServiceAgreement_Id fcapSAID = (ServiceAgreement_Id) collFCAPSas.next();
				ServiceAgreement fcapSA = fcapSAID.getEntity();
				
				try {
					fcapSA.cancelPaymentArrangement(wCharValueBrokenPA, parmAdjTypeSync, parmAdjCancelReason, null);
				}
				catch (Exception e) {
					// Since the account has multiple FCAP SA, it is possible that the first fcap sa broken would have 
					// already reverted the account to pre enrollment values via the initiate stop algorithm
					// So if the next fcap sa is broken then an error might be thrown stating that there are no
					// old customer class characteristic existing.
					e.printStackTrace();
				}				
			}		
			/*=============================================*/
			/* Revert the customer class, collection class */
			/* and budget plan to pre-FCAP values as well  */
			/* as cancel the budgets of the account        */
			/*=============================================*/
			Account account = acctID.getEntity();
			CharacteristicType charTypeOldCustomerClass = wCharTypeIdOldCustomerClass.getEntity();			
			AccountCharacteristic acctChar = account.getEffectiveCharacteristic(charTypeOldCustomerClass);
			
			if (notNull(acctChar)) {
				
				String charValue = " ";
				CharacteristicTypeLookup charTypeValueType = charTypeOldCustomerClass.getCharacteristicType();
				
				if (charTypeValueType.isPredefinedValue()) {
					charValue = acctChar.getCharacteristicValue().trim();
				}
				else if (charTypeValueType.isForeignKeyValue()) {
					charValue = acctChar.getCharacteristicValueForeignKey1().trim();
				} else {
					charValue = acctChar.getAdhocCharacteristicValue().trim();
				}
				CustomerClass_Id custClassID = new CustomerClass_Id(charValue);
				if (isNull(custClassID.getEntity())) {
					addError(CustomMessageRepositoryMGE.commGenericError(
							"Cannot revert account "+acctID.getTrimmedValue()+
							" to pre-FCAP because account char "+wCharTypeIdOldCustomerClass.getTrimmedValue()+
							" is an invalid customer class"));
				}
				
				CustomerClass prevCustClass = custClassID.getEntity();
				CollectionClass_Id prevCollClassID = prevCustClass.getCollectionClassId();
				BudgetPlan prevDefaultBudgetPlan = retrieveDefaultBudgetPlan(prevCustClass, account.fetchDivision());
				
				revertToPreFcapValues(account, prevCustClass, prevCollClassID, prevDefaultBudgetPlan);				
			}
			// START ADD - JHERNA - 2020-01-06 - SysAid#307713
			CustomerContact newCC = createCustomerContact(acctID, wCustomerContactType);
			// END ADD - JHERNA - 2020-01-06 - SysAid#307713
			return true;
		}
		
		private Iterator<ServiceAgreement_Id> getActiveFCAPSas(Account_Id acctID) {
			
			List<ServiceAgreement_Id> collOfSaId = new ArrayList<ServiceAgreement_Id>();
		
			StringBuilder stringBuilder = new StringBuilder();			
			stringBuilder.append("SELECT "); 
			stringBuilder.append("  SA.SA_ID ");
			stringBuilder.append("FROM "); 
			stringBuilder.append("  CI_SA SA ");
			stringBuilder.append("WHERE "); 
			stringBuilder.append("  SA.ACCT_ID = :acctID ");
			stringBuilder.append("  AND SA.SA_TYPE_CD IN ("+wFcapSaTypes+") ");
			stringBuilder.append("  AND SA.SA_STATUS_FLG IN (:pendingStart, :active) ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), 
					"===CmFCAPAutomaticDeEnrollmentBatch.Get Active FCAP SAs===");
			prepState.bindId("acctID", acctID);
			prepState.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
			prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
			prepState.setAutoclose(false);
			prepState.execute();

			if (prepState.list().size() > 0) {
				
				List<SQLResultRow> listOfSAs = prepState.list();
				for (int x = 0; x < listOfSAs.size(); x++) {

					SQLResultRow sqlRow = (SQLResultRow) listOfSAs.get(x);
					ServiceAgreement_Id saID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
					collOfSaId.add(saID);
				}				
			}
			prepState.close();
			return collOfSaId.iterator();			
		}
		
		private BudgetPlan retrieveDefaultBudgetPlan(CustomerClass custClass, CisDivision cisDivision) {
			
			BudgetPlan returnValue = null;
			
			CustomerClassControl_Id custClassControlID = new CustomerClassControl_Id(custClass, cisDivision);
			if (notNull(custClassControlID.getEntity())) {
				CustomerClassControl custClassControl = custClassControlID.getEntity();
				returnValue = custClassControl.fetchDefaultBudgetPlan();
			}
			
			return returnValue;
		}
		
		private void deleteAccountChar(Account account, CharacteristicType_Id charTypeID) {
			
			AccountCharacteristics acctChars = account.getCharacteristics();
			if (notNull(acctChars)) {
				Iterator<AccountCharacteristic> iter = acctChars.iterator();
				while (iter.hasNext()) {
					AccountCharacteristic acctChar = iter.next();
					CharacteristicType acctCharType = acctChar.fetchIdCharacteristicType();
					if (acctCharType.getId().compareTo(charTypeID) == 0) {
						iter.remove();
					}
				}
			}		
		}
		
		private void revertToPreFcapValues(Account account, CustomerClass prevCustClass, CollectionClass_Id prevCollClassID, BudgetPlan prevDefaultBudgetPlan) {
			
			Bool shouldUpdate = Bool.FALSE;
			Account_DTO acctDTO = account.getDTO();
			
			// Revert customer class if the current customer class is FCAP
			CustomerClass currentCustomerClass = account.getCustomerClass();
			String fcapCustClassStr = FC_HELPER.getMaximumSequenceFeatureOptionValue(parmFeatConfFCAP.getId(), 
					CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_CUSTOMER_CLASS, Bool.TRUE);
			
			if (currentCustomerClass.getId().getTrimmedValue().compareTo(fcapCustClassStr.trim()) == 0) {			
				shouldUpdate = Bool.TRUE;
				acctDTO.setCustomerClassId(prevCustClass.getId());						
			}
			
			// Revert collection class if the current collection class is FCAP
			CollectionClass_Id currentCollectionClassID = account.getCollectionClassId();
			String fcapCollClassStr = FC_HELPER.getMaximumSequenceFeatureOptionValue(parmFeatConfFCAP.getId(), 
					CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_COLLECTION_CLASS, Bool.TRUE);
			
			if (currentCollectionClassID.getTrimmedValue().compareTo(fcapCollClassStr.trim()) == 0) {
				shouldUpdate = Bool.TRUE;
				acctDTO.setCollectionClassId(prevCollClassID);
			}
			
			// Revert budget plan if the current budget plan is FCAP
			BudgetPlan_Id currentBudPlanID = account.getBudgetPlanId();
			String fcapBudPlanStr = FC_HELPER.getMaximumSequenceFeatureOptionValue(parmFeatConfFCAP.getId(), 
					CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_BUDGET_PLAN, Bool.TRUE);
			
			if (isNull(currentBudPlanID) ||
					currentBudPlanID.getTrimmedValue().compareTo(fcapBudPlanStr.trim()) == 0) {
				shouldUpdate = Bool.TRUE;
				acctDTO.setBudgetPlanId(prevDefaultBudgetPlan.getId());
			}
			
			if (shouldUpdate.isTrue()) {
				account.setDTO(acctDTO);		
			}			
			
			// Remove Old Customer Class characteristic
			deleteAccountChar(account, wCharTypeIdOldCustomerClass);
			
			// Remove Federal Poverty Level characteristic
			deleteAccountChar(account, wCharTypeIdFederalPovertyLevel);
			
			// Cancel Account's all Budget Amount
			account.cancelBudget(this.getProcessDateTime().getDate());		
		}
		// START ADD - JHERNA - 2020-01-06 - SysAid#307713
		private CustomerContact createCustomerContact(Account_Id acctID, CustomerContactType custContactType) {
			
			CustomerContact returnValue = null;			
	        CustomerContact_DTO ccDTO = new CustomerContact_DTO();        	        
	        ccDTO.setPersonId(acctID.getEntity().getMainPerson().getId());
	        ccDTO.setCustomerContactTypeId(custContactType.getId());
	        ccDTO.setContactDateTime(this.getProcessDateTime());
	        if (parmIsCcStatusOpen.isTrue()) {
	        	ccDTO.setCustomerContactStatus(CustomerContactStatusLookup.constants.OPEN);
	        }
	        ccDTO.setUserId(this.getActiveContextUser().getId());
	        if (notBlank(parmCcComments)) {
	        	ccDTO.setLongDescription(parmCcComments);
	        }
	        
	        returnValue = ccDTO.newEntity();
			
			return returnValue;
		}
		// END ADD - JHERNA - 2020-01-06 - SysAid#307713
	}
}
