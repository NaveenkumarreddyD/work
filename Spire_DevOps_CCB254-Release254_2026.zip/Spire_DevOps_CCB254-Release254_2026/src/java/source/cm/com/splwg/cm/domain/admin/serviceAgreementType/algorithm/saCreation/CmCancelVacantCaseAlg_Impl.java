package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.saCreation;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.Query;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.lookup.LookupField_Id;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CaseLogTypeLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.entity.FieldActivityCancelReason;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saCreation.SaTypeSaCreationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.common.ServerMessage;

/**
 * @author psreekan
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = caseType, name = caseTypeCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = caseStatus, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = faTypeCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityCancelReason, name = faCancelReason, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, type = entity)
 *            , @AlgorithmSoftParameter (name = faIntStatuses, required = true, type = string)})
 */
public class CmCancelVacantCaseAlg_Impl extends CmCancelVacantCaseAlg_Gen
		implements SaTypeSaCreationAlgorithmSpot {

	private CaseType parmCaseType;
	private String parmCaseStatus;
	private FieldActivityType parmFieldActivityType;
	private FieldActivityCancelReason parmFieldActivityCancelReason;
	private ToDoType parmToDoType;
	private ServiceAgreement parmServiceAgreement;
	// SA-219208 - 08/25/2017 - Start Add
	private List<String> faIntStatList = new ArrayList<String>();
	private static final String COMMA = ",";
	private static final LookupField_Id faIntStatusLookup = new LookupField_Id("FA_INT_STATUS_FLG");
	// SA-219208 - 08/25/2017 - End Add
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		
		parmCaseType = getCaseTypeCode();
		parmCaseStatus = getCaseStatus();
		parmFieldActivityType = getFaTypeCode();
		parmFieldActivityCancelReason = getFaCancelReason();
		parmToDoType = getToDoType();
		
		CaseStatus_Id caseStatusId = new CaseStatus_Id(parmCaseType, parmCaseStatus);
        CaseStatus caseStatus = caseStatusId.getEntity();
        if (isNull(caseStatus)) {              
            addError(CustomMessageRepository.nm0038InvalidCaseStatus(parmCaseStatus,parmCaseType.getId().getTrimmedValue()));
        }
        // SA-219208 - 08/25/2017 - Start Add
        String rawFaIntList = getFaIntStatuses();
        String[] faIntArr = rawFaIntList.split(COMMA);
        LookupValue_Id lookUpVal_Id;
        LookupValue lookUpVal;
        for (String faIntStat : faIntArr) {
            lookUpVal_Id = new LookupValue_Id(faIntStatusLookup, faIntStat);
            lookUpVal = lookUpVal_Id.getEntity();
            if (notNull(lookUpVal)) {
                faIntStatList.add(faIntStat);
            } else {
                addError(CustomMessageRepository.SA_219208_invalidLookUpValue(faIntStatusLookup.getIdValue(), faIntStat));
            }
        }
        // SA-219208 - 08/25/2017 - End Add
	}

	@Override
	public void invoke() {
	    
	    // SA-219208 - 08/25/2017 - Start Add
	    ListFilter<ServiceAgreementServicePoint> saSpFilter = parmServiceAgreement.getServicePoints()
	            .createFilter("where this.stopDateTime is null or this.stopDateTime > :processDttm ", getClass().getName());
	    saSpFilter.bindDateTime("processDttm", getProcessDateTime());
	    
	    ServicePoint_Id spId;
	    //Process active SP's linked to the current SA
	    for(ServiceAgreementServicePoint saSp : saSpFilter.list()) {
	        spId = saSp.getServicePoint().getId();
	        if (saSp.getServicePoint().getPremise().getId().equals(parmServiceAgreement.getPremiseId())) {
	            if (isPendingFAFound(spId).isTrue()) {
	                addError(CustomMessageRepository.SA_219208_unableToStartService(spId.getIdValue()));
	            }
	        }
	        
	    }
	    // SA-219208 - 08/25/2017 - End Add
		
		ToDoCase openCase = getOpenCase();
		if(notNull(openCase)){
			
			ToDoCase_DTO caseDTO = openCase.getDTO();
			caseDTO.setCaseCondition(CaseConditionLookup.constants.CLOSED);
			caseDTO.setCaseStatusId(new CaseStatus_Id(parmCaseType, parmCaseStatus));
			openCase.setDTO(caseDTO);
			addCaseLog(openCase);
		}else{
			
			FieldActivity pendingFA = getPendingFA();
			if(notNull(pendingFA)){
				
				try{
					
					FieldActivity_DTO faDTO = pendingFA.getDTO();
					faDTO.setCancelReasonId(parmFieldActivityCancelReason.getId());
					faDTO.setFieldActivityStatus(FieldActivityStatusLookup.constants.CANCELED);
					pendingFA.setDTO(faDTO);
				}catch(Exception e){
					
					if(notNull(parmToDoType)){
						
						createToDoEntry(pendingFA);
					}
				}
			}
		}
	}

	@Override
	public void setServiceAgreement(ServiceAgreement arg0) {

		this.parmServiceAgreement = arg0;
	}
	
	private ToDoCase getOpenCase(){
		
		ToDoCase returnValue = null;
		StringBuilder queryString = new StringBuilder();
		queryString.append("SELECT toDoCase.CASE_ID");
		queryString.append(" FROM CI_CASE toDoCase");
		queryString.append(" WHERE CASE_TYPE_CD = :caseTypeCode");
		queryString.append(" AND CASE_COND_FLG = :conditionalFlag");
		queryString.append(" AND PREM_ID = :charPremiseId");
		
		PreparedStatement prepStatement = createPreparedStatement(queryString.toString(), getClass().getName());
		// Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
		prepStatement.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
		prepStatement.bindEntity("caseTypeCode", parmCaseType);
		prepStatement.bindLookup("conditionalFlag", CaseConditionLookup.constants.OPEN);
		prepStatement.bindId("charPremiseId", parmServiceAgreement.getPremiseId());
		prepStatement.execute();
		
		SQLResultRow sqlRow = (SQLResultRow) prepStatement.firstRow();
		if(notNull(sqlRow)){
			ToDoCase_Id toDoCaseId = (ToDoCase_Id) sqlRow.getId("CASE_ID", ToDoCase.class);
			if(notNull(toDoCaseId)){
				returnValue = toDoCaseId.getEntity();
			}
		}
		// Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
		prepStatement.close();
		// End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
		
		return returnValue;
	}

	/**
	 * Adds a Case Log when transitioning to the next state.
	 *
	 */
	private void addCaseLog(ToDoCase toDoCase) {
    	
        // Create a log entry 
        CaseLog_DTO caseLogDTO = new CaseLog_DTO();
        caseLogDTO.setCaseStatusId(toDoCase.getCaseStatus().getId());
        caseLogDTO.setLogType(CaseLogTypeLookup.constants.STATUS_TRANSITION);
        caseLogDTO.setLogDateTime(getProcessDateTime());
        caseLogDTO.setUserId(getActiveContextUser().getId());

        //Retrieve the next SEQUENCE ID 
        Query query = createQuery("FROM CaseLog caseLog WHERE caseLog.id.toDoCase = :toDoCase", getClass().getName());
        query.bindId("toDoCase", toDoCase.getId());
        query.addResult("maxResult", "MAX(caseLog.id.sequence)");

        BigInteger seq = (BigInteger) query.firstRow();
        toDoCase.getLogs().add(caseLogDTO, seq.add(BigInteger.ONE));
    }
	
	private FieldActivity getPendingFA(){
		
		FieldActivity returnValue = null;
		
		ServicePoint activeSp = getActiveSP();
		if(notNull(activeSp)){
			
			StringBuilder queryString = new StringBuilder();
			queryString.append("SELECT FA.FA_ID");
			queryString.append(" FROM CI_FA FA");
			queryString.append(" WHERE FA.FA_TYPE_CD= :faTypeCode");
			queryString.append(" AND FA.SP_ID = :sp");
			queryString.append(" AND FA.FA_STATUS_FLG= :faStatusFlag");
			
			PreparedStatement prepStatement = createPreparedStatement(queryString.toString(), getClass().getName());
			// Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
			prepStatement.setAutoclose(false);
	        // End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
			prepStatement.bindEntity("faTypeCode", parmFieldActivityType);
			prepStatement.bindId("sp", activeSp.getId());
			prepStatement.bindLookup("faStatusFlag", FieldActivityStatusLookup.constants.PENDING);
			prepStatement.execute();
			
			SQLResultRow sqlRow = (SQLResultRow) prepStatement.firstRow();
			if(notNull(sqlRow)){
				
				FieldActivity_Id faId = (FieldActivity_Id) sqlRow.getId("FA_ID", FieldActivity.class);
				if(notNull(faId)){
					
					returnValue = faId.getEntity();
				}
			}
			// Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
			prepStatement.close();
			// End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
		}
		return returnValue;
	}
	
	private ServicePoint getActiveSP(){
		
		ServicePoint returnValue = null;
		
		StringBuilder queryString = new StringBuilder();
		queryString.append("SELECT SASP.SP_ID");
		queryString.append(" FROM CI_SA_SP SASP");
		queryString.append(" WHERE SASP.STOP_DTTM IS NULL");
		queryString.append(" AND SA_ID = :serviceAgreement");
		
		PreparedStatement prepStatement = createPreparedStatement(queryString.toString(), getClass().getName());
		// Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
		prepStatement.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
		prepStatement.bindId("serviceAgreement", parmServiceAgreement.getId());
		prepStatement.execute();
		
		SQLResultRow sqlRow = (SQLResultRow) prepStatement.firstRow();
		if(notNull(sqlRow)){
			
			ServicePoint_Id spId = (ServicePoint_Id) sqlRow.getId("SP_ID", ServicePoint.class);
			if(notNull(spId)){
				
				returnValue = spId.getEntity();
			}
		}
		// Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
		prepStatement.close();
		// End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
		return returnValue;
	}
	
	private void createToDoEntry(FieldActivity fa) {
		startChanges();

		ServerMessage message = CustomMessageRepositoryMGE
				.ccb009faCannotBeCanceled(fa.getId().getTrimmedValue(), fa
						.getServicePoint().getId().getTrimmedValue());

		ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
		ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();

		toDoEntryDTO.setCreationDateTime(getProcessDateTime());
		toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
		toDoEntryDTO.setToDoTypeId(parmToDoType.getId());
		toDoEntryDTO.setMessageId(message.getMessageId());

		toDoCreator.setToDoDTO(toDoEntryDTO);
		toDoCreator.addSortKeyValue(parmToDoType.getSortKeyTypes().iterator()
				.next(), fa.getId().getTrimmedValue());
		toDoCreator.addDrillKeyValue(parmToDoType.getDrillKeyTypes().iterator()
				.next(), fa.getId().getTrimmedValue());

		toDoCreator.create();
		saveChanges();
	}
	
    // SA-219208 - 08/25/2017 - Start Add
    /**
     * This method determines if there is a pending FA
     * linked to the SP parameter.
     * @param spId
     * @return Bool
     */
    private Bool isPendingFAFound (ServicePoint_Id spId) {
        
        Bool isFound = Bool.FALSE;
        
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT FA.FA_ID ");
        sb.append(  "FROM CI_FA FA ");
        sb.append( "WHERE FA.SP_ID = :spId ");
        sb.append(   "AND FA.FA_TYPE_CD = :faType ");
        sb.append(   "AND FA.FA_STATUS_FLG = :pending ");
        sb.append(   "AND FA.FA_INT_STATUS_FLG IN ( ");
        for (int i = 0; i < faIntStatList.size(); i++) {
            if (i == 0){
                sb.append("'"+faIntStatList.get(i).trim()+"' ");
            } else if (i > 0){
                sb.append(",'"+faIntStatList.get(i).trim()+"' ");
            }
        }
        sb.append(") ");
        
        PreparedStatement statement = createPreparedStatement(sb.toString(), getClass().getName());
        // Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
        statement.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
        
        statement.bindId("spId", spId);
        statement.bindId("faType", parmFieldActivityType.getId());
        statement.bindLookup("pending", FieldActivityStatusLookup.constants.PENDING);
        
        if (notNull(statement.firstRow())) {
            isFound = Bool.TRUE;
        }
        // Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
        statement.close();
 		// End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
        
        return isFound;
    }
    // SA-219208 - 08/25/2017 - End Add
	
}
