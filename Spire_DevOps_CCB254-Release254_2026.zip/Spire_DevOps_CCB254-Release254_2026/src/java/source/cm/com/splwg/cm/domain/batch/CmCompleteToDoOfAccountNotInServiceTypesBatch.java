/*
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                     
 * 
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * SA-364029 - TD-NOBC batch enhancement
 * 
 * The main purpose of this batch is to execute the post-processing 
 * batch algorithm to complete to dos created by TD-NOBC depending on 
 * the criteria set on the configured algorithm.
 *
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:       by:          Reason:
 * YYYY-MM-DD  Name
 * 2021-04-28  EQuint       SA 364029. Initial Version.
 ***********************************************************************
 */
package com.splwg.cm.domain.batch;

import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;

/**
 * @author OGC02353
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules = {})
 */
public class CmCompleteToDoOfAccountNotInServiceTypesBatch extends
		CmCompleteToDoOfAccountNotInServiceTypesBatch_Gen {

	public JobWork getJobWork() {
		// Create Dummy Job Work
		List<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
		arrayList.add(threadWorkUnit);
		return createJobWorkForThreadWorkUnitList(arrayList);
	}

	public Class<CmCompleteToDoOfAccountNotInServiceTypesBatchWorker> getThreadWorkerClass() {
		return CmCompleteToDoOfAccountNotInServiceTypesBatchWorker.class;
	}

	public static class CmCompleteToDoOfAccountNotInServiceTypesBatchWorker
			extends CmCompleteToDoOfAccountNotInServiceTypesBatchWorker_Gen {

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			return true;
		}

	}

}
