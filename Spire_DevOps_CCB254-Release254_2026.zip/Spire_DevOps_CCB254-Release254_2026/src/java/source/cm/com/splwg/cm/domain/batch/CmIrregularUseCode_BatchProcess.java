/*******************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * NA0002 - Irregular Use Codes
 *
 * This batch process retrieves To Dos created as part of TD-HILO review 
 * batch process that are in Open State. Each To Do is processed based on  
 * the Irregular Use Code configured on the Feature Configuration Options. 
 * These To Do entries that have a valid Irregular use code defined on either 
 * SA/SP Characteristics will be auto-completed & Meter Read marked as billable.
 * 
 ********************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2012-08-29	Srikanth	NA0002. Initial Version.
 * 2012-09-16	Karthik		NA0002. Review comments incorporation.
 * 2016-01-29  	MPang		Updated for CCB v2.4 compilation. 
 * 2021-07-14	Ravi		46714 Remove static variables and code cleanup
 ********************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.LogTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryTransactionHistory_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryTransactionHistory_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointStatusLookup;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_DTO;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_Id;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
import com.splwg.cm.api.lookup.CmIrregularUseCodeLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author sdesabhatl002
 *
 @BatchJob (modules = {}
 *      , multiThreaded = true
 *      , rerunnable = false
 *      , softParameters = { @BatchJobSoftParameter (entityName = featureConfiguration, name = WFM_NAME, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CHAR_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = TD_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = role, name = ROLE_ID, type = entity)})
 */
public class CmIrregularUseCode_BatchProcess extends
CmIrregularUseCode_BatchProcess_Gen {

	// class variables

	private  List<SQLResultRow> todoEntryList;
	private FeatureConfiguration featureConfiguration;
	private CharacteristicType charType;
	private ToDoType toDoType;
	private Role toDoRole;

	// Constants
	private final String DELIMITER =";";
	private final String DATE_DELIMITER = "/";
	private final String TOKEN_SA ="SA";
	private final String TOKEN_SP ="SP";
	private final String TOKEN_LOW ="LOW";
	private final String TOKEN_HIGH ="HIGH";
	private final String DATE_FORMAT = "MM/dd/yyyy";


	public void validateSoftParameters(boolean isNewRun){
		initializeSoftParams();
		validateToDoRole();
		validateCharacteristicEntity();
		validateFeatureConfigIRUString();
		BigInteger parmMaxErrors = getParameters().getSoftMaxErrors();
		// Check if the override maximum errors is less than 0 
		if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
			addError(CustomMessageRepository.na0002IntegerParamCannotBeNegative(parmMaxErrors.toString().trim()));
		}
	}

	/**
	 * @return void
	 *  This method retrieves Batch Param variables and initializes the class variables
	 */   
	private void initializeSoftParams(){
		featureConfiguration = getParameters().getWFM_NAME();
		charType = getParameters().getCHAR_TYPE_CD();
		toDoType = getParameters().getTD_TYPE_CD();
		toDoRole = getParameters().getROLE_ID();

	}
	/**
	 * @return void
	 *  if the Role is specified this method Validates if it is Valid for the ToDo Type.
	 *  If Role is not specified, Default Role of the To DO Type is assigned
	 */ 
	private void validateToDoRole(){

		boolean exists = false;
		if(notNull(toDoRole)){
			for(ToDoTypeRole todoTypeRole: toDoType.getRoles()){
				if(todoTypeRole.fetchIdToDoRole().getId().equals(toDoRole.getId())){
					exists = true;
					break;
				}
			}
			if(!exists){
				addError(CustomMessageRepository.na0002ToDoRoleInvalidForToDoType(toDoRole.getId().getIdValue(),toDoType.getId().getIdValue()));
			}
		}else{
			toDoRole = toDoType.getDefaultRole().fetchIdToDoRole();

		}
	}

	/**
	 * @return void
	 * Validates if the input Char Typde code is valid either on Service Agreement or Service Point.
	 */
	private void validateCharacteristicEntity() {
		CharacteristicEntity charEntity = null;
		charEntity = new CharacteristicEntity_Id(charType, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT).getEntity();
		if(isNull(charEntity)){
			charEntity = new CharacteristicEntity_Id(charType, CharacteristicEntityLookup.constants.SERVICE_POINT).getEntity();
		}
		if(isNull(charEntity)){
			addError(CustomMessageRepository.na0002CharTypeInvalidForEntity(charType.getId()));
		}
	}

	/**
	 * @return void
	 * Retrieves and validates all Feature Configuration option value IRU Codes  in the Feature Configuration
	 */
	private void validateFeatureConfigIRUString(){
		String strIRUCode = null;

		for( FeatureConfigurationOption featureConfigurationOption : featureConfiguration.getOptions()){
			if(CmIrregularUseCodeLookup.constants.IRU_CODE.trimmedValue().equals(featureConfigurationOption.fetchIdOptionType().trim())){
				strIRUCode = featureConfigurationOption.getValue();
				validateIRUCode(strIRUCode,featureConfiguration.getId().getIdValue());
			}
		} 
	}
	/**
	 * @return void
	 * @param String strIRUCode, String Feature Config Name
	 * Validates the Tokens in IRU Code defined in the Feature Configuration
	 */  
	private void validateIRUCode(String strIRUCode, String fcName){
		StringTokenizer strTokenizer = new StringTokenizer(strIRUCode,DELIMITER);
		String strIRUCodeToken = null;
		String strStartDate = null;
		String strEndDate = null;
		String strLowHighTkn = null;
		String strSASP = null;


		if(strTokenizer.countTokens()!=5){
			addError(CustomMessageRepository.na0002InvalidIRUCodeConfig(strIRUCode,fcName));
			return;
		}

		strIRUCodeToken = strTokenizer.nextToken();
		strStartDate = strTokenizer.nextToken();
		strEndDate   = strTokenizer.nextToken();
		strLowHighTkn   = strTokenizer.nextToken();
		strSASP = strTokenizer.nextToken();

		CharacteristicValue_Id iruCharValId = new CharacteristicValue_Id(charType.getId(),strIRUCodeToken.trim());
		CharacteristicValue iruCharVal = iruCharValId.getEntity();
		if(isNull(iruCharVal)) {
			addError(CustomMessageRepository.na0002InvalidIRUCodeConfig(strIRUCode,fcName));
		}

		if(validateDateString(strStartDate).isFalse()){
			addError(CustomMessageRepository.na0002InvalidIRUCodeConfig(strIRUCode,fcName));
		}
		if(validateDateString(strEndDate).isFalse()){
			addError(CustomMessageRepository.na0002InvalidIRUCodeConfig(strIRUCode,fcName));
		}
		if(!((strLowHighTkn.equalsIgnoreCase(TOKEN_LOW))|| (strLowHighTkn.equalsIgnoreCase(TOKEN_HIGH)))){
			addError(CustomMessageRepository.na0002InvalidIRUCodeConfig(strIRUCode,fcName));
		}

		if(!((strSASP.equalsIgnoreCase(TOKEN_SP))|| (strSASP.equalsIgnoreCase(TOKEN_SA)))){
			addError(CustomMessageRepository.na0002InvalidIRUCodeConfig(strIRUCode,fcName));
		}
	}
	/**
	 * @return Bool
	 * @param String strDate
	 * Validates the  is in the MM/DD format and determines if is a valid Date 
	 */   
	private Bool validateDateString(String strDate){
		Bool isValid = Bool.FALSE;
		String strDateString = null;
		StringTokenizer strTokenizer = new StringTokenizer(strDate,DATE_DELIMITER);
		if(strTokenizer.countTokens()!=2){
			return isValid;
		}

		SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT);
		formatter.setLenient(false);
		strDateString= strDate.concat( DATE_DELIMITER+ getProcessDateTime().getYear());

		try{
			java.util.Date date = formatter.parse(strDateString);

			if (!formatter.format(date).equals(strDateString)){
				return isValid;
			} 

		}catch(ParseException e){
			return isValid;
		}
		return Bool.TRUE;
	}


	public JobWork getJobWork() {
		getEligibleToDoEntryRecords();
		ArrayList <ThreadWorkUnit> workUnitList = new ArrayList<ThreadWorkUnit>();
		for(SQLResultRow resultRow:todoEntryList){
			ToDoEntry_Id toDoId = (ToDoEntry_Id)resultRow.getId("TD_ENTRY_ID", ToDoEntry.class);
			ThreadWorkUnit workUnit =  new ThreadWorkUnit(toDoId);
			workUnitList.add(workUnit);
		}
		//REC_COUNT = workUnitList.size();
		return createJobWorkForThreadWorkUnitList(workUnitList);

	}
	/**
	 * @return void
	 * This method retrieves  the ToDo's of the given To Do Type and Role as of process Date time
	 */   	
	private void getEligibleToDoEntryRecords(){
		StringBuilder getToDoEntriesQuery = new StringBuilder();

		getToDoEntriesQuery.append("SELECT TD_ENTRY_ID FROM CI_TD_ENTRY ");
		getToDoEntriesQuery.append("WHERE TD_TYPE_CD = :toDoType ");
		getToDoEntriesQuery.append("AND ENTRY_STATUS_FLG = :entryStatus ");
		getToDoEntriesQuery.append("AND CRE_DTTM <= :processDateTime ");
		getToDoEntriesQuery.append("AND ROLE_ID = :toDoRole ");	

		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement toDoEntriesPrepStmt = createPreparedStatement(getToDoEntriesQuery.toString()); 
		PreparedStatement toDoEntriesPrepStmt = createPreparedStatement(getToDoEntriesQuery.toString(), getClass().getName()); 
		System.out.println("query used - >"+toDoEntriesPrepStmt);
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		toDoEntriesPrepStmt.bindEntity("toDoType", toDoType);
		toDoEntriesPrepStmt.bindLookup("entryStatus", ToDoEntryStatusLookup.constants.OPEN);
		toDoEntriesPrepStmt.bindDateTime("processDateTime", getProcessDateTime());
		toDoEntriesPrepStmt.bindEntity("toDoRole", toDoRole);
		toDoEntriesPrepStmt.setAutoclose(false);

		todoEntryList = toDoEntriesPrepStmt.list();     
		toDoEntriesPrepStmt.close();
	}

	public Class<CmIrregularUseCode_BatchProcessWorker> getThreadWorkerClass() {
		return CmIrregularUseCode_BatchProcessWorker.class;
	}

	public static class CmIrregularUseCode_BatchProcessWorker extends
	CmIrregularUseCode_BatchProcessWorker_Gen {

		private FeatureConfiguration featureConfiguration;
		private CharacteristicType charType;

		ToDoEntry_Id toDoId =null;
		int intTotalRecordCount =0;
		int intCompletedToDoCount=0;

		// Constants
		private final String DELIMITER =";";
		private final String DATE_DELIMITER = "/";
		private final String TOKEN_SA ="SA";
		private final String TOKEN_SP ="SP";
		private final String TOKEN_LOW ="LOW";
		private final String TOKEN_HIGH ="HIGH";
		private final String SP_CHAR ="C1-SP";
		private final int ZERO = BigInteger.ZERO.intValue();
		private final int ONE = BigInteger.ONE.intValue();
		private final int TWO_INT = 2;
		private final String TWO = "2";
		private final String FOUR = "4";
		private final String FIVE ="5";
		private final int TWELVE = 12;
		private final int THIRTY_ONE = 31;
		private final String[] infoPurposeIRU = new String[]{"P","G","O"};

		/**
		 * This method identifies the execution strategy to be used for the thread.
		 * 
		 * @return an instance of ThreadExecutionStrategy that governs how this ThreadWorker will be executed at runtime.
		 * @see com.splwg.base.api.batch.ThreadWorker#createExecutionStrategy()
		 */

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new CommitEveryUnitStrategy(this); 
		}

		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
						throws ThreadAbortedException, RunAbortedException {
			intTotalRecordCount = 0;
		}

		/**
		 * Execute a WorkUnit and provide result details.
		 * 
		 * @param unit - a ThreadWorkUnit
		 * @return a boolean that describes the success or failure of the work unit processing.
		 * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
		 * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
		 * @see com.splwg.base.api.batch.ThreadWorker#executeWorkUnit(com.splwg.base.api.batch.ThreadWorkUnit)
		 */

		public boolean executeWorkUnit  (ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			featureConfiguration = getParameters().getWFM_NAME();
			charType = getParameters().getCHAR_TYPE_CD();

			intTotalRecordCount++;
			toDoId = (ToDoEntry_Id)unit.getPrimaryId();
			ToDoEntryTransactionHistory_DTO toDoLogDTO = new ToDoEntryTransactionHistory_DTO();
			ServicePoint_Id spId = getServicePoint();
			if(isNull(spId)){
				return true;
			}
			MeterRead_Id mreadId = getMeterReadDetails();
			if(isNull(mreadId)){
				return true;
			}
			MeterRead meterRead = mreadId.getEntity();
			ServiceAgreement_Id saId = getActiveSAfromSP(spId,meterRead);

			if(isNull(saId)){
				String logMessage = CustomMessageRepository.na0002SPIsLinkedToMoreThanOneSA(spId.getIdValue(), meterRead.getReadDateTime().toString()).getMessageText();
				createToDoLogEntry(toDoLogDTO,logMessage);
				return true;
			}

			if(isSALinkedToMultipleSPs(saId,meterRead).isTrue()){
				String logMessage = CustomMessageRepository.na0002SAIsLinkedToMoreThanOneSP(saId.getIdValue(), meterRead.getReadDateTime().toString()).getMessageText();
				createToDoLogEntry(toDoLogDTO,logMessage);
				return true;
			}

			String strSPCharVal = retrieveEffectiveIRUCodeCharValueonSP(spId,meterRead);
			String strSACharVal = retrieveEffectiveIRUCodeCharValueonSA(saId,meterRead);

			// char value not exists on both SA and SP - No Processing required.
			if(isBlankOrNull(strSPCharVal) && isBlankOrNull(strSACharVal)){
				return true;
			}
			//	 char value exists on both - Log Message and return.
			if((!isBlankOrNull(strSPCharVal)) && (!isBlankOrNull(strSACharVal))){
				String logMessage = CustomMessageRepository.na0002charValIRUExistsOnBothSAAndSP(saId.getIdValue(), spId.getIdValue()).getMessageText();
				createToDoLogEntry(toDoLogDTO,logMessage);
				return true;
			}
			// Process only if the char value is on SP

			if(!isBlankOrNull(strSPCharVal)){
				processCharValIRUCode(strSPCharVal.trim(),toDoLogDTO,meterRead,spId,null);
			}

			// Process only if the char value is on SA
			if(!isBlankOrNull(strSACharVal)){
				processCharValIRUCode(strSACharVal.trim(),toDoLogDTO,meterRead,null,saId);
			}
			//Ravi - 19/07/2021 - Start - moved processing info logging to thread level
			/*if(REC_COUNT ==intTotalRecordCount)  {
				logInfo(CustomMessageRepository.na0002TotalRecordsProcessed(BigInteger.valueOf(REC_COUNT)));
				logInfo(CustomMessageRepository.na0002TotalRecordsToDoCompleted(BigInteger.valueOf(intCompletedToDoCount)));
			} */
			//Ravi - 19/07/2021 - end - moved processing info logging to thread level
			return true;
		}

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException,
		RunAbortedException {
			logInfo(CustomMessageRepository.na0002TotalRecordsProcessed(BigInteger.valueOf(intTotalRecordCount)));
			logInfo(CustomMessageRepository.na0002TotalRecordsToDoCompleted(BigInteger.valueOf(intCompletedToDoCount)));
		}

		/**
		 * @return void
		 * @param String strCharVal ,ToDoEntryTransactionHistory_DTO toDoLogDTO to Log the To Do Entry
		 * @param MeterRead_Id mreadId to determine the Meter Read Date, ServiceAgreement_Id saId, ServicePoint_Id spId
		 * This method compeletes a ToDo if the Meter Read Date is between the IRU String Start And End Dates 
		 * and allowed on SA/SP  and failed HIGH/LOW as configured in the Feature Configuration IRU Code.
		 * Validates the date is in the MM/DD format and determines if is a valid Date 
		 */   	
		private void processCharValIRUCode(String strCharVal,ToDoEntryTransactionHistory_DTO toDoLogDTO,MeterRead meterRead,
				ServicePoint_Id spId,ServiceAgreement_Id saId ){
			StringTokenizer strTokenizer = null;
			String strStartDate = null;
			String strEndDate = null;
			String strLowHighTkn = null;
			String strSASP = null;
			String strMeterHighorLowFail = null;
			String logMessage = null;

			String strIRUCode = retrieveFeatureConfigIRUCode(strCharVal);

			if(strCharVal.equalsIgnoreCase(infoPurposeIRU[ZERO]) || strCharVal.equalsIgnoreCase(infoPurposeIRU[ONE]) || strCharVal.equalsIgnoreCase(infoPurposeIRU[TWO_INT])|| isBlankOrNull(strIRUCode)){

				if(notNull(spId)){
					logMessage = CustomMessageRepository.na0002IRUOnSPisInfoOnly(strCharVal,spId.getIdValue()).getMessageText();
				}else{
					logMessage = CustomMessageRepository.na0002IRUOnSAisInfoOnly(strCharVal,saId.getIdValue()).getMessageText();  
				}
				createToDoLogEntry(toDoLogDTO,logMessage);
				return;
			}

			strTokenizer = new StringTokenizer(strIRUCode,DELIMITER);

			strTokenizer.nextToken();
			strStartDate = strTokenizer.nextToken();
			strEndDate   = strTokenizer.nextToken();
			strLowHighTkn   = strTokenizer.nextToken();
			strSASP = strTokenizer.nextToken();

			if(notNull(spId)){
				if(!strSASP.equals(TOKEN_SP)){
					logMessage = CustomMessageRepository.na0002IRUIsNotAllowedonSP(strIRUCode,spId.getIdValue()).getMessageText();
					createToDoLogEntry(toDoLogDTO,logMessage);
					return;
				}
			}else{
				if(!strSASP.equals(TOKEN_SA)){
					logMessage = CustomMessageRepository.na0002IRUIsNotAllowedonSA(strIRUCode,saId.getIdValue()).getMessageText();
					createToDoLogEntry(toDoLogDTO,logMessage);
					return;
				}
			}

			if(isMeterReadDateBetweenStartAndEndDates(strStartDate,strEndDate,meterRead.getReadDateTime()).isFalse()){
				logMessage = CustomMessageRepository.na0002IRUNotEffectiveOnMeterReadDate(strIRUCode,meterRead.getReadDateTime().getDate().toString()).getMessageText();
				createToDoLogEntry(toDoLogDTO,logMessage);
				return;
			}

			strMeterHighorLowFail = getMeterReadHighOrLowFailed();

			if(!strLowHighTkn.equalsIgnoreCase(strMeterHighorLowFail)){
				logMessage = CustomMessageRepository.na0002IRUByPassesOnlySpecificHighOrLowFails(strIRUCode,strLowHighTkn).getMessageText();
				createToDoLogEntry(toDoLogDTO,logMessage);
				return;
			}

			//update meter read to Billabe and complete the ToDo.
			MeterRead_DTO mreadDTO = meterRead.getDTO();
			mreadDTO.setCanUseOnBill(Bool.TRUE);
			meterRead.setDTO(mreadDTO);
			toDoId.getEntity().complete();
			intCompletedToDoCount++;

		}
		/**
		 * @return Bool 
		 * @param String Start Date (MM/DD), String End Date(MM/DD) and Meter Read Date
		 * This method returns true if the Meter Read date falls between the Start and End Dates.
		 * 
		 */     
		private Bool isMeterReadDateBetweenStartAndEndDates(String strStartDate,String strEndDate,DateTime meterReadDttm){
			Date startDateIRU = null;
			Date endDateIRU = null;

			int startMonth = Integer.parseInt(strStartDate.substring(ZERO, strStartDate.indexOf(DATE_DELIMITER)));
			int startDate = Integer.parseInt(strStartDate.substring(strStartDate.indexOf(DATE_DELIMITER) + 1));

			int endMonth = Integer.parseInt(strEndDate.substring(ZERO, strEndDate.indexOf(DATE_DELIMITER)));
			int endDate = Integer.parseInt(strEndDate.substring(strEndDate.indexOf(DATE_DELIMITER) + 1));

			int currentYearInt = meterReadDttm.getYear();
			int nextYearInt = currentYearInt + 1;

			if (startMonth <= endMonth) {
				startDateIRU = new Date(currentYearInt, startMonth, startDate);
				endDateIRU = new Date(currentYearInt, endMonth, endDate);

				if (isInputDateInTheRange(startDateIRU, endDateIRU,meterReadDttm.getDate()).isTrue()) return Bool.TRUE;
			} else {
				startDateIRU = new Date(currentYearInt, startMonth, startDate);
				endDateIRU = new Date(currentYearInt, TWELVE, THIRTY_ONE);

				if (isInputDateInTheRange(startDateIRU, endDateIRU,meterReadDttm.getDate()).isTrue()) return Bool.TRUE;

				startDateIRU = new Date(nextYearInt, ONE, ONE);
				endDateIRU = new Date(nextYearInt, endMonth, endDate);
				meterReadDttm = meterReadDttm.addYears(1);

				if (isInputDateInTheRange(startDateIRU, endDateIRU,meterReadDttm.getDate()).isTrue()) return Bool.TRUE;
			}

			return Bool.FALSE;
		}
		/**
		 * @return Bool 
		 * @param Date Start Date , Date End Date and Meter Read Date
		 * This method returns true if the Meter Read date falls between the Start and End Dates.
		 * 
		 */     	        

		private Bool isInputDateInTheRange(Date startDate, Date endDate, Date meterReadDate) {
			int intStartVal = meterReadDate.compareTo(startDate);
			int intEndVal = meterReadDate.compareTo(endDate);
			if ((intStartVal >= ZERO) && (intEndVal <= ZERO)) {
				return Bool.TRUE;
			}
			return Bool.FALSE;
		}

		/**
		 * @return ServicePoint_Id 
		 *  This method retrieves a ServicePoint from the ToDo Entry Characteristics.
		 * 
		 */  
		private ServicePoint_Id getServicePoint(){
			String strServicePointId=null;

			for(ToDoEntryCharacteristic todoChar: toDoId.getEntity().getCharacteristics()){
				if(SP_CHAR.trim().equals(todoChar.fetchIdCharacteristicType().getId().getIdValue().trim())){
					strServicePointId = todoChar.getCharacteristicValueForeignKey1();
					break;
				}
			}

			if(notNull(strServicePointId))
				return new ServicePoint_Id(strServicePointId);
			else
				return null;
		}

		/**
		 * @return MeterRead_Id 
		 *  This method retrieves a MeterRead from the ToDo Entry Drill Key.
		 * 
		 */  
		private MeterRead_Id getMeterReadDetails(){
			String strMeterReadId = null;
			for (ToDoDrillKeyValue drillKeyVal:toDoId.getEntity().getDrillKeyValues()){
				strMeterReadId =drillKeyVal.getKeyValue();
			}

			if(notNull(strMeterReadId))
				return new MeterRead_Id(strMeterReadId);
			else
				return null;

		}

		/**
		 * @return ServiceAgreement_Id 
		 * @param ServicePoint_Id spId, MeterRead_Id mreadId
		 *  This method retrieves a ServiceAgreement for the given ServicePoint as of Meter Read Date
		 * 
		 */ 
		private ServiceAgreement_Id getActiveSAfromSP(ServicePoint_Id spId, MeterRead meterRead){
			StringBuilder getSAQuery = new StringBuilder();

			getSAQuery.append("SELECT SA.SA_ID FROM CI_SA_SP SASP, CI_SA SA ");
			getSAQuery.append("WHERE SASP.SP_ID = :spId ");
			getSAQuery.append("AND SASP.SA_ID =  SA.SA_ID ");
			getSAQuery.append("AND SA.SA_STATUS_FLG Not In (:incomplete, :closed, :canceled) ");
			getSAQuery.append("AND SASP.START_DTTM < :meterReadDttm ");
			getSAQuery.append("AND (SASP.STOP_DTTM >= :meterReadDttm OR SASP.STOP_DTTM IS NULL) ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement pstmt =  createPreparedStatement(getSAQuery.toString());
			PreparedStatement pstmt =  createPreparedStatement(getSAQuery.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//pstmt.bindEntity("spId", spId.getEntity());
			pstmt.bindId("spId", spId);
			pstmt.bindLookup("incomplete", ServiceAgreementStatusLookup.constants.INCOMPLETE);
			pstmt.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
			pstmt.bindLookup("canceled", ServiceAgreementStatusLookup.constants.CANCELED);
			pstmt.bindDateTime("meterReadDttm", meterRead.getReadDateTime());
			pstmt.setAutoclose(false);
			SQLResultRow firstRow = pstmt.firstRow();

			pstmt.close();
			//if(pstmt.list().size() == 1 )
			if(notNull(firstRow))
				return (ServiceAgreement_Id)firstRow.getId("SA_ID", ServiceAgreement.class)	;
			else
				return null;


		}

		/**
		 * @return Bool 
		 * @param ServiceAgreement_Id saId,MeterRead_Id mreadId
		 *  This method returns Bool as of Meter Read Dateif SA is linked to Multiple Service Points as of Meter Read Date.
		 */ 
		private Bool isSALinkedToMultipleSPs(ServiceAgreement_Id saId,MeterRead meterRead){
			StringBuilder getSPQuery = new StringBuilder();

			getSPQuery.append("SELECT SP.SP_ID FROM CI_SA_SP SASP, CI_SP SP ");
			getSPQuery.append("WHERE SASP.SA_ID = :saId ");
			getSPQuery.append("AND SASP.SP_ID =  SP.SP_ID ");
			getSPQuery.append("AND SP.SP_STATUS_FLG = :statusFlg ");
			getSPQuery.append("AND SASP.START_DTTM < :meterReadDttm ");
			getSPQuery.append("AND (SASP.STOP_DTTM >= :meterReadDttm OR SASP.STOP_DTTM IS NULL) ");

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement pstmt =  createPreparedStatement(getSPQuery.toString());
			PreparedStatement pstmt =  createPreparedStatement(getSPQuery.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//pstmt.bindEntity("saId", saId.getEntity());
			pstmt.bindId("saId", saId);
			pstmt.bindLookup("statusFlg", ServicePointStatusLookup.constants.IN_SERVICE);
			pstmt.bindDateTime("meterReadDttm", meterRead.getReadDateTime());
			pstmt.setAutoclose(false);

			if(pstmt.list().size() > 1 ){
				pstmt.close();
				return Bool.TRUE;
			}else{
				pstmt.close();
				return Bool.FALSE;
			}

		}

		/**
		 * @return String 
		 * @param ServicePoint_Id spId,MeterRead_Id mreadId
		 *  This method returns Characteristic Value effective on Service Point as of Meter Read Date.
		 */ 	
		private String retrieveEffectiveIRUCodeCharValueonSP(ServicePoint_Id spId,MeterRead meterRead ){
			//StringBuilder getSPCharValQuery = new StringBuilder();

			ServicePointCharacteristic spChar = spId.getEntity().getEffectiveCharacteristicAsOfDate(charType, meterRead.getReadDateTime().getDate());
			if(isNull(spChar)){
				return null;
			}else{
				CharacteristicTypeLookup lookup = charType.getCharacteristicType();
				String charValue = null;
				if(lookup.isPredefinedValue()){
					charValue = spChar.getCharacteristicValue();
				} else if (lookup.isAdhocValue() || lookup.isFileLocationValue()){
					charValue = spChar.getAdhocCharacteristicValue();
				} else if (lookup.isForeignKeyValue()){
					charValue =  spChar.getCharacteristicValueForeignKey1();
				}
				return charValue;
			}

			//Ravi - Start - 19/07/2021 - Used the base method to fetch the value
			/*getSPCharValQuery.append("SELECT CHAR_VAL FROM CI_SP_CHAR ");
			getSPCharValQuery.append("WHERE SP_ID = :spId " );
			getSPCharValQuery.append("AND CHAR_TYPE_CD = :charTypeCd " );
			getSPCharValQuery.append("AND EFFDT IN ");
			getSPCharValQuery.append("( SELECT MAX(EFFDT) FROM CI_SP_CHAR ");
			getSPCharValQuery.append("WHERE SP_ID = :spId ");
			getSPCharValQuery.append("AND CHAR_TYPE_CD = :charTypeCd ");
			getSPCharValQuery.append("AND EFFDT <= :meterReadDate ) ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement pstmt =  createPreparedStatement(getSPCharValQuery.toString());
			PreparedStatement pstmt =  createPreparedStatement(getSPCharValQuery.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//pstmt.bindEntity("spId", spId.getEntity());
			pstmt.bindId("spId", spId);
			pstmt.bindEntity("charTypeCd", charType);
			pstmt.bindDate("meterReadDate", meterRead.getReadDateTime().getDate());
			pstmt.setAutoclose(false);
			SQLResultRow firstRow = pstmt.firstRow();

			//if(pstmt.list().size() > 1 )
			if(notNull(firstRow))

				//return pstmt.firstRow().getString("CHAR_VAL");
				return firstRow.getString("CHAR_VAL");
			else
				return null;	*/
			//Ravi - End - 19/07/2021 - Used the base method to fetch the value

		}

		/**
		 * @return String 
		 * @param ServiceAgreement_Id saId,MeterRead_Id mreadId
		 *  This method returns Characteristic Value effective on Service Agreement as of Meter Read Date.
		 */ 		
		private String retrieveEffectiveIRUCodeCharValueonSA(ServiceAgreement_Id saId,MeterRead meterRead ){
			//StringBuilder getSACharValQuery = new StringBuilder();

			ServiceAgreementCharacteristic saChar = saId.getEntity().getEffectiveCharacteristicAsOfDate(charType, meterRead.getReadDateTime().getDate());
			if(isNull(saChar)){
				return null;
			}else{
				CharacteristicTypeLookup lookup = charType.getCharacteristicType();
				String charValue = null;
				if(lookup.isPredefinedValue()){
					charValue = saChar.getCharacteristicValue();
				} else if (lookup.isAdhocValue() || lookup.isFileLocationValue()){
					charValue = saChar.getAdhocCharacteristicValue();
				} else if (lookup.isForeignKeyValue()){
					charValue =  saChar.getCharacteristicValueForeignKey1();
				}
				return charValue;
			}

			//Ravi - Start - 19/07/2021 - Used the base method to fetch the value
			/*getSACharValQuery.append("SELECT CHAR_VAL FROM CI_SA_CHAR ");
			getSACharValQuery.append("WHERE SA_ID = :saId ");
			getSACharValQuery.append("AND CHAR_TYPE_CD = :charTypeCd ");
			getSACharValQuery.append("AND EFFDT IN ");
			getSACharValQuery.append("( SELECT MAX(EFFDT) FROM CI_SA_CHAR ");
			getSACharValQuery.append("WHERE SA_ID = :saId ");
			getSACharValQuery.append("AND CHAR_TYPE_CD = :charTypeCd ");
			getSACharValQuery.append("AND EFFDT <= :meterReadDate ) ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement pstmt =  createPreparedStatement(getSACharValQuery.toString());
			PreparedStatement pstmt =  createPreparedStatement(getSACharValQuery.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			pstmt.bindEntity("saId", saId.getEntity());
			pstmt.bindEntity("charTypeCd", charType);
			pstmt.bindDate("meterReadDate", meterRead.getReadDateTime().getDate());
			pstmt.setAutoclose(false);
			SQLResultRow firstRow = pstmt.firstRow();

			//if(pstmt.list().size() > 1 )
			if(notNull(firstRow))

				//return (String)pstmt.firstRow().get("CHAR_VAL");
				return firstRow.getString("CHAR_VAL");
			else
				return null;*/
			//Ravi - End - 19/07/2021 - Used the base method to fetch the value

		}

		/**
		 * @return String 
		 * @param String strCharVal
		 *  This method returns IRU Code that starts with the given input.
		 */ 
		private String retrieveFeatureConfigIRUCode(String strCharVal){
			String strIRUCode = null;


			//for( FeatureConfigurationOption featureConfigurationOption : featureConfiguration.getOptions()){
			for( FeatureConfigurationOption featureConfigurationOption : featureConfiguration.getOptions(CmIrregularUseCodeLookup.constants.IRU_CODE)){
				//if(featureConfigurationOption.fetchIdOptionType().trim().equals(CmIrregularUseCodeLookup.constants.IRU_CODE.trimmedValue())){
				strIRUCode = featureConfigurationOption.getValue();

				if(strIRUCode.startsWith(strCharVal, 0))
					break;

				//}
			}
			return strIRUCode;
		}

		/**
		 * @return String 
		 *  This method returns if Meter read is HIGH/LOW failed determined from the ToDO Entry SortKeys.
		 */  
		private String getMeterReadHighOrLowFailed(){
			String strlowHighFail = null;
			for(ToDoSortKeyValue sortKeyVal :toDoId.getEntity().getSortKeyValues()){
				if(sortKeyVal.fetchIdSequence().equals(BigInteger.ONE) ||sortKeyVal.fetchIdSequence().equals(new BigInteger(TWO)) ){
					strlowHighFail =  TOKEN_LOW;
					break;
				}
				if(sortKeyVal.fetchIdSequence().equals(new BigInteger(FOUR)) ||sortKeyVal.fetchIdSequence().equals(new BigInteger(FIVE)) ){
					strlowHighFail =  TOKEN_HIGH;
					break;
				}
			}

			return strlowHighFail;
		}

		/**
		 * @return void
		 * @param  ToDoEntryTransactionHistory_DTO toDoLogDTO,String logMsg
		 *  This method logs a message in the ToDo.
		 */ 
		private void createToDoLogEntry(ToDoEntryTransactionHistory_DTO toDoLogDTO,String logMsg){
			toDoLogDTO.setId(new ToDoEntryTransactionHistory_Id(toDoId,toDoId.getEntity().getNextLogEntrySequence()));
			toDoLogDTO.setLogDateTime(getProcessDateTime());
			toDoLogDTO.setLongDescription(logMsg);
			toDoLogDTO.setLogType(LogTypeLookup.constants.USER_DETAILS);
			toDoLogDTO.newEntity(); 
		}

	}//Inner

}
