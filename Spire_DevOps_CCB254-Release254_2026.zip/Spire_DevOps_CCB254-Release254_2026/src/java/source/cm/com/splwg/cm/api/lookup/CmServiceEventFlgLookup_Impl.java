/**************************************************************************
* Program Name: CmServiceEventFlgLookup_Impl
* Program Title: CmServiceEventFlgLookup_Impl
* Author: Gerard Cinco
* Creation Date: 2017-01-23
* Purpose: Lookup for Service Events 
* Functional Spec: CCB-CC-015.1
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:         Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  CCB-CC-015        Gerard Cinco    2017-01-30    Initial Version
 ************************************************************************************************/

/**
 * @author gcinco
 *
 @LookupFieldname (value = CM_SERVICE_EVENT_FLG)
 */
package com.splwg.cm.api.lookup;

public class CmServiceEventFlgLookup_Impl extends CmServiceEventFlgLookup_Gen {

}
