/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Generate Adjustment and Apply Rate to Adjustment Amount
 *
 * This algorithm is a clone of GenerateAdjustmentApplyRateAlgComp from algorithm type
 * ADJG-RT , with an added functionality to update SA's characteristic premise to
 * the Premise from the SA's characteristics or from a particular adjustment transferred 
 * to this SA via update statement prior to applying the rate. This is to allow the 
 * rate schedule that references a Bill factor that looks into a SA's Premise to be 
 * able to process the SA without calling an error.
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2024-07-22   JVitug          B-32269  - Initial Version.
 * 2025-02-13   JVitug          B-32269.Issue2. Updated to also check the CWRPXFER adjustment
 *                              type. Added additional handling to not proceed if no Premise 
 *                              was retrieved from both avenues.
 * 2025-03-11   JVitug          B-32269.Issue3. Added null check on SQL when attempting to update
 *                              premise ID on SA. Added logic to now skip LPC generation 
 *                              if no premise ID can be derived.
 ******************************************************************************************/
package com.splwg.cm.domain.admin.adjustmentType.algorithm.generate;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.SimpleKeyedBusinessEntity;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.EntityId;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.language.Language;
import com.splwg.ccb.api.lookup.AdjustmentStatusLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic_Id;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristics;
import com.splwg.ccb.domain.admin.adjustmentType.algorithm.generate.CustomCommonData;
import com.splwg.ccb.domain.admin.adjustmentType.algorithm.generate.GenerateAdjustmentAlgorithmSpot;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity_DTO;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.billing.data.BillSegmentCalculationHeaderData;
import com.splwg.ccb.domain.billing.data.BillSegmentServiceQuantityData;
import com.splwg.ccb.domain.common.data.CharacteristicData;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.data.SADistributionOverrideData;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.rate.common.RateApplicationProcessor;
import com.splwg.ccb.domain.rate.data.ApplyRateData;
import com.splwg.ccb.domain.rate.data.RateApplicationProcessorData;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;

//Start Change JVitug - B-32269.Issue2 - 2025-02-13
///**
// * @author JVitug
// *
//@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = rateSchedule, name = rateSchedule, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = serviceQuantityIdentifier, name = SQI, type = entity)
// *            , @AlgorithmSoftParameter (entityName = unitOfMeasure, name = UOM, type = entity)
// *            , @AlgorithmSoftParameter (entityName = timeOfUse, name = TOU, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = taxNotApplicableCharType, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = taxDiscrepancyAmountSQICharType, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = taxDiscrepancyAmountCharType, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = premiseCharType, type = entity , required = true)
// *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = gpasicAdjustmentType, type = entity , required = true)})
// */
/**
 * @author JVitug
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = rateSchedule, name = rateSchedule, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = serviceQuantityIdentifier, name = SQI, type = entity)
 *            , @AlgorithmSoftParameter (entityName = unitOfMeasure, name = UOM, type = entity)
 *            , @AlgorithmSoftParameter (entityName = timeOfUse, name = TOU, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = taxNotApplicableCharType, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = taxDiscrepancyAmountSQICharType, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = taxDiscrepancyAmountCharType, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = premiseCharType, type = entity , required = true)
 *            , @AlgorithmSoftParameter (name = paAdjustmentTypes, type = string , required = true)})
 */
//End Change JVitug - B-32269.Issue2 - 2025-02-13
public class CmGenerateAdjustmentApplyRateAlgComp_Impl extends CmGenerateAdjustmentApplyRateAlgComp_Gen 
implements GenerateAdjustmentAlgorithmSpot {
	
	private Account account;
	private Adjustment adjustment;
	private AdjustmentType adjustmentType;
	private ServiceAgreement sa;
	private ServiceAgreementType saType;
	private Date accountingDate;
	private Date calculationDate;
	private Money baseAmount;
	private BigDecimal taxRoundingAmount;
	private ServiceQuantityIdentifier_Id taxRoundingAmountSQIId;
	private CustomCommonData customCommonData;
	private SADistributionOverrideData saDistributionOverrideData;
	private List<BillSegmentCalculationHeaderData> billSegmentCalculationHeaderData;
	private List<CharacteristicData> characteristicData;
	private List<BillSegmentServiceQuantityData> billSegmentServiceQuantityData;
	private List<AdjustmentCharacteristic> adjustmentCharacteristicList = new ArrayList<>();
	private String glDetailsDataArea;
	
	//Soft parameters
	private CharacteristicType taxNotApplicableCharType;
	private CharacteristicType taxRoundingAmountSQICharType;
	private CharacteristicType taxRoundingAmountCharType;
	private CharacteristicType premiseCharType;
	//Start Change JVitug - B-32269.Issue2 - 2025-02-13
	//private AdjustmentType gpasicAdjustmentType;
	private String paAdjustmentTypes;
	//End Change JVitug - B-32269.Issue2 - 2025-02-13
	
	//Start Add JVitug - B-32269.Issue3 - 2025-03-11
	private Premise premise;
	//End Add JVitug - B-32269.Issue3 - 2025-03-11
	
	//Start Add JVitug - B-32269.Issue2 - 2025-02-13
	//Constants
	private final String COMMA = ",";
    private final String QUOTE = "'"; 
	//End Add JVitug - B-32269.Issue2 - 2025-02-13
    
	public void invoke() {
		initialize();
		processCharacteristics();
//		//Start Add JVitug - B-32269.Issue3 - 2025-03-11
		//Derive the premise using the adjustment created on start of the Payment Arrangement. Only do this if the 
		//Service Agreement's Characteristic premise is blank.
		if(isNull(sa.fetchPremise())) {
			premise = getPremiseFromSACharacteristic();
			
			//If Premise couldn't be derived from the SA Characteristic, attempt to derive the premise from the
			//initial PA Adjustment created when activating a Payment Arrangement SA
			if(isNull(premise)) {
				premise = getPremiseFromSICAdjustment();
				
				//If no Premise was still derived, do not proceed in applying the rate, as it will cause an error
				if(isNull(premise)) {
					return;
				}
			}
		}
		//End Add JVitug - B-32269.Issue3 - 2025-03-11
		applyRate(populateRateApplicationProcessorData());
		removeAdjustmentCharacteristic();
	}

	private void initialize() {
		if (isNull(calculationDate))
			calculationDate = getSystemDateTime().getDate(); 
	}

	@Override
	protected void extraSoftParameterValidations(boolean isValid) {
		taxNotApplicableCharType = getTaxNotApplicableCharType();
		taxRoundingAmountSQICharType = getTaxDiscrepancyAmountSQICharType();
		taxRoundingAmountCharType = getTaxDiscrepancyAmountCharType();
		premiseCharType = getPremiseCharType();
		//Start Change JVitug - B-32269.Issue2 - 2025-02-13
		//gpasicAdjustmentType = getGpasicAdjustmentType();
		paAdjustmentTypes = getPaAdjustmentTypes();
		//End Change JVitug - B-32269.Issue2 - 2025-02-13
		
		if (isNull(getSQI()) && isNull(getUOM()))
			addError(CustomMessageRepository.B32269_sqiOrUomisMissing()); 
		if ((taxRoundingAmountSQICharType != null && taxRoundingAmountCharType == null) 
				|| (taxRoundingAmountSQICharType == null && taxRoundingAmountCharType != null))
			addError(CustomMessageRepository.B32269_taxRoundingAmtTaxRoundingSqiAmountMissing()); 
		
		//Start Add JVitug - B-32269.Issue2 - 2025-02-13
		String[] adjustmentTypesStr = paAdjustmentTypes.split(COMMA);
		
		AdjustmentType adjTypeVal = null;
		for(String adjTypeStr : adjustmentTypesStr) {
			adjTypeVal = new AdjustmentType_Id(adjTypeStr.trim()).getEntity();
			
			if(isNull(adjTypeVal))
				addError(CustomMessageRepository.B32269_invalidAdjustmentType("Payment Arrangement Transfer Adjustment Types", adjTypeStr.trim()));
		}
		//End Add JVitug - B-32269.Issue2 - 2025-02-13
	}

	private void processCharacteristics() {
		if (getTaxNotApplicableCharType() != null)
			populateCharacteristicData(getTaxNotApplicableCharType()); 
		if (taxRoundingAmountSQICharType != null && taxRoundingAmountCharType != null) {
			if ((hasCharType(taxRoundingAmountSQICharType) && !hasCharType(taxRoundingAmountCharType)) || (
					!hasCharType(taxRoundingAmountSQICharType) && hasCharType(taxRoundingAmountCharType)))
				addError(CustomMessageRepository.B32269_adjTaxRoundingAmtTaxRoundingSqiAmountMissing(taxRoundingAmountSQICharType.fetchLanguageDescription(), 
						taxRoundingAmountCharType.fetchLanguageDescription(), adjustment.getId().getTrimmedValue())); 
			if (hasCharType(taxRoundingAmountSQICharType) && hasCharType(taxRoundingAmountCharType)) {
				taxRoundingAmount = getRoundingAmount(taxRoundingAmountCharType);
				taxRoundingAmountSQIId = new ServiceQuantityIdentifier_Id(getTaxRoundingAmountSqi(taxRoundingAmountSQICharType));
				adjustmentCharacteristicList.add((new AdjustmentCharacteristic_Id(taxRoundingAmountSQICharType.getId(), adjustment
						.getId(), BigInteger.ONE)).getEntity());
				adjustmentCharacteristicList.add((new AdjustmentCharacteristic_Id(taxRoundingAmountCharType.getId(), adjustment
						.getId(), BigInteger.ONE)).getEntity());
			} 
		} 
	}

	private void populateCharacteristicData(CharacteristicType characteristicType) {
		characteristicData = new ArrayList<>();
		ListFilter filter = retrieveCharacteristic(characteristicType);
		if (filter.listSize() > 0L) {
			for (QueryIterator iter = filter.iterate(); iter.hasNext(); ) {
				AdjustmentCharacteristic row = (AdjustmentCharacteristic)iter.next();
				adjustmentCharacteristicList.add(row);
			} 
			AdjustmentCharacteristic adjustmentCharacteristic = (AdjustmentCharacteristic)filter.firstRow();
			CharacteristicData charData = CharacteristicData.Factory.newInstance();
			charData.setCharacteristicType(getTaxNotApplicableCharType());
			charData.setCharacteristicValue(adjustmentCharacteristic.fetchCharacteristicValue()
					.fetchIdCharacteristicValue());
			characteristicData.add(charData);
		} 
	}

	private ListFilter retrieveCharacteristic(CharacteristicType characteristicType) {
		ListFilter filter = adjustment.getCharacteristics().createFilter("where this.id.characteristicType = :characteristicType order by id.sequence desc", "retrieve characteristics");
		filter.bindEntity("characteristicType", (SimpleKeyedBusinessEntity)characteristicType);
		return filter;
	}

	private boolean hasCharType(CharacteristicType characteristicType) {
		return (retrieveCharacteristic(characteristicType).listSize() > 0L);
	}

	private BigDecimal getRoundingAmount(CharacteristicType characteristicType) {
		ListFilter filter = retrieveCharacteristic(characteristicType);
		AdjustmentCharacteristic adjustmentCharacteristic = (AdjustmentCharacteristic)filter.firstRow();
		return new BigDecimal(adjustmentCharacteristic.getAdhocCharacteristicValue());
	}

	private void removeAdjustmentCharacteristic() {
		for (AdjustmentCharacteristic adjChar : adjustmentCharacteristicList) {
			AdjustmentCharacteristics adjustmentCharacteristics = adjustment.getCharacteristics();
			adjustmentCharacteristics.remove(adjChar);
		} 
	}

	private BillSegmentServiceQuantityData createBillSegmentServiceQuantityData(ServiceQuantityIdentifier serviceQuantityIdentifier, Money baseAmt) {
		BillSegmentServiceQuantityData billSegmentSqData = BillSegmentServiceQuantityData.Factory.newInstance();
		BillSegmentServiceQuantity_DTO billSegmentSqDto = (BillSegmentServiceQuantity_DTO)createDTO(BillSegmentServiceQuantity.class);
		String uom = new String();
		String tou = new String();
		String sqi = new String();
		if (getUOM() != null)
			uom = getUOM().getId().getTrimmedValue(); 
		if (getTOU() != null)
			tou = getTOU().getId().getTrimmedValue(); 
		if (serviceQuantityIdentifier != null)
			sqi = serviceQuantityIdentifier.getId().getTrimmedValue(); 
		BillSegmentServiceQuantity_Id billSegmentSqId = new BillSegmentServiceQuantity_Id(BillSegment_Id.NULL, uom, tou, sqi);
		billSegmentSqDto.setId((EntityId)billSegmentSqId);
		billSegmentSqDto.setBillableServiceQuantity(baseAmt.getAmount());
		billSegmentSqDto.setInitialServiceQuantity(baseAmt.getAmount());
		billSegmentSqData.setBillSegmentServiceQuantityDto(billSegmentSqDto);
		return billSegmentSqData;
	}

	private BillSegmentServiceQuantityData createBillSegmentServiceQuantityDataRounding(ServiceQuantityIdentifier serviceQuantityIdentifier, BigDecimal roundingAmount) {
		BillSegmentServiceQuantityData billSegmentSqData = BillSegmentServiceQuantityData.Factory.newInstance();
		BillSegmentServiceQuantity_DTO billSegmentSqDto = (BillSegmentServiceQuantity_DTO)createDTO(BillSegmentServiceQuantity.class);
		BillSegmentServiceQuantity_Id billSegmentSqId = new BillSegmentServiceQuantity_Id(getUOM(), getTOU(), serviceQuantityIdentifier, null);
		billSegmentSqDto.setId((EntityId)billSegmentSqId);
		billSegmentSqDto.setBillableServiceQuantity(roundingAmount);
		billSegmentSqDto.setInitialServiceQuantity(roundingAmount);
		billSegmentSqData.setBillSegmentServiceQuantityDto(billSegmentSqDto);
		return billSegmentSqData;
	}

	private ApplyRateData prepareApplyRateData() {
		//Run update statement backend to bypass validation
		updatePremiseOnSA(1);
		
		billSegmentCalculationHeaderData = new ArrayList<>();
		billSegmentServiceQuantityData = new ArrayList<>();
		ApplyRateData applyRateData = ApplyRateData.Factory.newInstance();
		applyRateData.setServiceAgreement(sa);
		applyRateData.setBillSegmentCreationDateTime(calculationDate.startOfDay());
		applyRateData.setBillSegmentPeriodStart(calculationDate);
		applyRateData.setBillSegmentPeriodEnd(calculationDate);
		applyRateData.setAccountingDate(accountingDate);
		applyRateData.setConsumptionPeriodStart(calculationDate);
		applyRateData.setConsumptionPeriodEnd(calculationDate);
		applyRateData.setShouldRetainReadCollection(Bool.FALSE);
		applyRateData.setShouldRetainItemCollection(Bool.FALSE);
		applyRateData.setShouldRetainSqCollection(Bool.TRUE);
		applyRateData.setShouldRetainSqRules(Bool.TRUE);
		applyRateData.setThirdParty("");
		applyRateData.setLanguage(determineLanguageForRateApplication());
		applyRateData.setCisDivision(saType.getId().getDivision());
		applyRateData.setServiceAgreementType(saType);
		applyRateData.setRateSchedule(getRateSchedule());
		applyRateData.setAdjustment(adjustment);
		billSegmentServiceQuantityData.add(createBillSegmentServiceQuantityData(getSQI(), baseAmount));
		if (taxRoundingAmountSQICharType != null && taxRoundingAmountCharType != null && 
				hasCharType(taxRoundingAmountSQICharType) && hasCharType(taxRoundingAmountCharType))
			billSegmentServiceQuantityData.add(createBillSegmentServiceQuantityDataRounding((ServiceQuantityIdentifier)taxRoundingAmountSQIId
					.getEntity(), taxRoundingAmount)); 
		if (saType.getSpecialRole().isBillDeterminantsRequired()) {
			applyRateData.setUsageConsumptionPeriodStart(calculationDate);
			applyRateData.setUsageConsumptionPeriodEnd(calculationDate);
		} 
		
		return applyRateData;
	}

	private String getTaxRoundingAmountSqi(CharacteristicType characteristicType) {
		ListFilter filter = retrieveCharacteristic(characteristicType);
		AdjustmentCharacteristic adjustmentCharacteristic = (AdjustmentCharacteristic)filter.firstRow();
		return adjustmentCharacteristic.getAdhocCharacteristicValue();
	}

	private Language determineLanguageForRateApplication() {
		Person person = getMainCustomerOnAccount();
		return (person != null && person.getLanguage() != null) ? person.getLanguage() : getActiveContextLanguage();
	}

	private Person getMainCustomerOnAccount() {
		Query<AccountPerson> query = createQuery(" from AccountPerson as acctper  where acctper.id.account.id = :account and acctper.isMainCustomer = 'Y' ", "retrieve main customer");
		query.addResult("acctper", "acctper");
		query.bindEntity("account", (SimpleKeyedBusinessEntity)account);
		return (query.firstRow() != null) ? ((AccountPerson)query.firstRow()).getId().getPerson() : null;
	}

	private void applyRate(RateApplicationProcessorData rateApplicationProcessorData) {
		RateApplicationProcessor rateApplicationProcessor = RateApplicationProcessor.Factory.newInstance();
		try {
			rateApplicationProcessor.applyRate(rateApplicationProcessorData);
			billSegmentCalculationHeaderData = rateApplicationProcessorData.getCalculationHeaderDataList();
			characteristicData = rateApplicationProcessorData.getCharacteristicDataList();
			billSegmentServiceQuantityData = rateApplicationProcessorData.getServiceQuantityDataList();
			setGlDetailsDataArea(rateApplicationProcessorData.getApplyRateData().getGlDetailsDataArea());
		} catch (ApplicationError e) {
			billSegmentCalculationHeaderData = rateApplicationProcessorData.getCalculationHeaderDataList();
			characteristicData = rateApplicationProcessorData.getCharacteristicDataList();
			billSegmentServiceQuantityData = rateApplicationProcessorData.getServiceQuantityDataList();
			throw e;
		} 
		
		//Remove the premise from the SA
		updatePremiseOnSA(2);
	}

	private RateApplicationProcessorData populateRateApplicationProcessorData() {
		ApplyRateData applyRateData = prepareApplyRateData();
		RateApplicationProcessorData rateApplicationProcessorData = RateApplicationProcessorData.Factory.newInstance();
		rateApplicationProcessorData.setApplyRateData(applyRateData);
		rateApplicationProcessorData.setCalculationHeaderDataList(billSegmentCalculationHeaderData);
		rateApplicationProcessorData.setCharacteristicDataList(characteristicData);
		rateApplicationProcessorData.setServiceQuantityDataList(billSegmentServiceQuantityData);
		return rateApplicationProcessorData;
	}

	public Account getAccount() {
		return this.account;
	}

	public Date getAccountingDate() {
		return this.accountingDate;
	}

	public AdjustmentType getAdjustmentType() {
		return this.adjustmentType;
	}

	public Money getBaseAmount() {
		return this.baseAmount;
	}

	public List<BillSegmentCalculationHeaderData> getBillSegmentCalculationHeaderData() {
		return this.billSegmentCalculationHeaderData;
	}

	public Date getCalculationDate() {
		return this.calculationDate;
	}

	public List<CharacteristicData> getCharacteristicData() {
		return this.characteristicData;
	}

	public ServiceAgreement getServiceAgreement() {
		return this.sa;
	}

	public ServiceAgreementType getServiceAgreementType() {
		return this.saType;
	}

	public String getGlDetailsDataArea() {
		return this.glDetailsDataArea;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public void setAccountingDate(Date accountingDate) {
		this.accountingDate = accountingDate;
	}

	public void setAdjustment(Adjustment adjustment) {
		this.adjustment = adjustment;
	}

	public void setAdjustmentType(AdjustmentType adjType) {
		this.adjustmentType = adjType;
	}

	public void setBaseAmount(Money baseAmount) {
		this.baseAmount = baseAmount;
	}

	public void setBillSegmentCalculationHeaderData(List<BillSegmentCalculationHeaderData> billSegmentCalculationHeaderData) {
		this.billSegmentCalculationHeaderData = billSegmentCalculationHeaderData;
	}

	public void setCalculationDate(Date calculationDate) {
		this.calculationDate = calculationDate;
	}

	public void setCharacteristicData(List<CharacteristicData> characteristicData) {
		this.characteristicData = characteristicData;
	}

	public void setCustomCommonData(CustomCommonData customCommonData) {
		this.customCommonData = customCommonData;
	}

	public void setSADistributionOverrideData(SADistributionOverrideData saDistributionOverrideData) {
		this.saDistributionOverrideData = saDistributionOverrideData;
	}

	public void setServiceAgreement(ServiceAgreement serviceAgreement) {
		this.sa = serviceAgreement;
	}

	public void setServiceAgreementType(ServiceAgreementType serviceAgreementType) {
		this.saType = serviceAgreementType;
	}

	public void setGlDetailsDataArea(String glDetailsDataArea) {
		this.glDetailsDataArea = glDetailsDataArea;
	}
	
	private void updatePremiseOnSA(int action) {
		
		if(isNull(sa.fetchPremise())) {
			//Start Change JVitug - B-32269.Issue2 - 2025-02-13
			//PreparedStatement sql;
			PreparedStatement sql = null;
			//End Change JVitug - B-32269.Issue2 - 2025-02-13
			StringBuilder stringSql = new StringBuilder();

			if(action == 1) {
				//Start Delete JVitug - B-32269.Issue3 - 2025-03-11
				//Relocated at the invoke() method to add functionality to halt processing
				//when Premise could not be derived, as per onshore comment
				//Premise premise = getPremiseFromSACharacteristic();
				
				//if(isNull(premise)) {
					//If no premise can be derived from the SA's characteristics, it might be the case 
					//that the adjustment being generated is for a SIC SA. Check the SIC SA's adjustment
					//to get the Premise from the Utility SA from where the SIC adjustment came from.
					//premise = getPremiseFromSICAdjustment();
				//}
				//End Delete JVitug - B-32269.Issue3 - 2025-03-11
				
				//Start Add JVitug - B-32269.Issue2 - 2025-02-13
				//Only continue if a Premise was retrieved either from the CWR Adjustment created at the start of the Payment Arrangement
				//or from the CWR SA's Premise Characteristic
				if(notNull(premise)) {
					//End Add JVitug - B-32269.Issue2 - 2025-02-13
					stringSql.append("UPDATE CI_SA ");
					stringSql.append("SET CHAR_PREM_ID = :premiseID ");
					stringSql.append("WHERE SA_ID = :saID ");

					sql = createPreparedStatement(stringSql.toString() , getClass().getName());
					sql.bindId("premiseID" , premise.getId());
					sql.bindId("saID", sa.getId());
				//Start Add JVitug - B-32269.Issue2 - 2025-02-13
				}
				//End Add JVitug - B-32269.Issue2 - 2025-02-13
			} else {
				stringSql.append("UPDATE CI_SA ");
				stringSql.append("SET CHAR_PREM_ID = ' ' ");
				stringSql.append("WHERE SA_ID = :saID ");

				sql = createPreparedStatement(stringSql.toString() , getClass().getName());
				sql.bindId("saID", sa.getId());
			}
			//Start Add JVitug - B-32269.Issue3 - 2025-03-11
			if(notNull(sql)) {
			//End Add JVitug - B-32269.Issue3 - 2025-03-11
				sql.execute();
				sql.close();
			//Start Add JVitug - B-32269.Issue3 - 2025-03-11
			}
			//End Add JVitug - B-32269.Issue3 - 2025-03-11
		}
	}
	
	/**
	 * Get the premise from this SA's CWR Premise ID Characteristic
	 * @return Premise ID
	 */
	private Premise getPremiseFromSACharacteristic() {
		PreparedStatement sql;
		StringBuilder stringSql = new StringBuilder();
		SQLResultRow result; 
		Premise returnValue = null;
		
		stringSql.append("SELECT ");
		stringSql.append(   "SAC.SRCH_CHAR_VAL ");
		stringSql.append("FROM ");
		stringSql.append(   "CI_SA_CHAR SAC ");
		stringSql.append("WHERE ");
		stringSql.append(   "SAC.SA_ID = :saID ");
		stringSql.append("AND ");
		stringSql.append(   "SAC.CHAR_TYPE_CD = :characteristicType ");
		
		sql = createPreparedStatement(stringSql.toString() , getClass().getName());
		sql.bindId("saID" , sa.getId());
		sql.bindId("characteristicType", premiseCharType.getId());
		
		result = sql.firstRow();
		sql.close();
		
		if(notNull(result)){
			returnValue = result.getEntity("SRCH_CHAR_VAL" , Premise.class);
		}
		
		return returnValue;
	}
	
	/**
	 * Get the Premise from the Utility SA using the PA SIC Adjustment 
	 * created when starting SIC SAs, since part of the balance of an
	 * account's utility SA is passed to the SIC SA. 
	 * @return Premise ID
	 */
	private Premise getPremiseFromSICAdjustment() {
		PreparedStatement sql;
		StringBuilder stringSql = new StringBuilder();
		SQLResultRow result; 
		Premise returnValue = null;
		
		stringSql.append("SELECT ");
		stringSql.append(   "SA.CHAR_PREM_ID  ");
		stringSql.append("FROM ");
		stringSql.append(   "CI_SA SA, ");
		stringSql.append(   "CI_ADJ A1, ");
		stringSql.append(   "CI_ADJ A2 ");
		stringSql.append("WHERE ");
		stringSql.append(   "A1.SA_ID = :saID ");
		stringSql.append("AND ");
		//Start Change JVitug - B-32269.Issue2 - 2025-02-13
		//stringSql.append(   "A1.ADJ_TYPE_CD = :adjustmentType ");
		stringSql.append(   "A1.ADJ_TYPE_CD IN ( "+ encloseAdjustmentTypesInQuotes(paAdjustmentTypes) + " ) ");
		//End Change JVitug - B-32269.Issue2 - 2025-02-13
		//Start Delete JVitug - B-32269.Issue2 - 2025-02-13
		stringSql.append("AND ");
		stringSql.append(   "A1.ADJ_STATUS_FLG = :frozen ");
		//End Delete JVitug - B-32269.Issue2 - 2025-02-13
		stringSql.append("AND ");
		stringSql.append(   "A1.XFER_ADJ_ID = A2.ADJ_ID ");
		stringSql.append("AND ");
		stringSql.append(   "A2.ADJ_TYPE_CD = A1.ADJ_TYPE_CD ");
		stringSql.append("AND ");
		stringSql.append(   "A2.SA_ID <> A1.SA_ID ");
		stringSql.append("AND ");
		stringSql.append(   "A2.SA_ID = SA.SA_ID ");
		//Start Add JVitug - B-32269.Issue3 - 2025-03-11
		stringSql.append("AND ");
		stringSql.append(   "SA.CHAR_PREM_ID != ' '");
		//End Add JVitug - B-32269.Issue3 - 2025-03-11
		
		sql = createPreparedStatement(stringSql.toString() , getClass().getName());
		sql.bindId("saID" , sa.getId());
		//Start Delete JVitug - B-32269.Issue2 - 2025-02-13
		//sql.bindId("adjustmentType", gpasicAdjustmentType.getId());
		//End Delete JVitug - B-32269.Issue2 - 2025-02-13
		sql.bindLookup("frozen" , AdjustmentStatusLookup.constants.FROZEN);
		
		result = sql.firstRow();
		sql.close();
		
		if(notNull(result)){
			returnValue = result.getEntity("CHAR_PREM_ID" , Premise.class);
		}
		
		return returnValue;
	}
	//Start Add JVitug - B-32269.Issue2 - 2025-02-13
	private String encloseAdjustmentTypesInQuotes(String adjListStr) {
		String stringInQuotes = "";
		
		//Separate the SA Types in an array
		String[] adjTypes = adjListStr.split(COMMA);
		
		for(int i = 0 ; i < adjTypes.length ; i ++) {
			
			if(isBlankOrNull(adjTypes[i])) {
				continue;
			}
			
			String adjType = adjTypes[i];
			
			//If this is the first instance, put quotes before and after the sa Type
			// string
			stringInQuotes = stringInQuotes + QUOTE + adjType + QUOTE;
			
			//If this is the last one, do not append a comma
			if(i < adjTypes.length - 1) {
				stringInQuotes = stringInQuotes + COMMA;
			} 
		}
		
		return stringInQuotes;
	}
	//End Add JVitug - B-32269.Issue2 - 2025-02-13
}
