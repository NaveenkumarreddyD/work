/*******************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * Metering Exception Case - Auto-Transition Based on Field Codes
 *
 * This algorithm will first evaluate the "inbound" field code and exception 
 * status Characteristics and update the "permanent" characteristics if   
 * necessary. The "inbound" Characteristics will be deleted after this  
 * evaluation. It will then evaluate the "permanent" field code and exception   
 * status Characteristics. If the values are populated and both registers have  
 * the same value, the algorithm will use Feature Configuration to retrieve the  
 * appropriate transition condition. If there are mismatching field code or  
 * exception status Characteristic values on the registers, the algorithm will  
 * return a transition condition for a manual review status for a Laclede  
 * resource to investigate the scenario and update the Case accordingly. 
 *
 ********************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-04-12   SMiranda        NI0007.5. Initial Version.
 * 2013-04-29   SMiranda        TIR5. Transition Condition parameters must be 
 *                              optional.
 * 2013-04-30   SMiranda        TIR6. Add, Update, Delete of characteristics will
 *                              be done in Case Exit Status processing     
 * 2015-01-07	Rahul           IM-064446 Close all open prepared statements   
 * 2016-01-25   MPang			Updated for CCB v2.4 compilation.                                        
 ********************************************************************************/
package com.splwg.cm.domain.admin.caseType;

import java.util.List;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.lookup.LookupField_Id;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;

//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseType;
import com.splwg.ccb.domain.admin.caseType.CaseTypeAutoTransitionAlgorithmSpot;
import com.splwg.ccb.domain.admin.itemType.ItemType;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.Meter;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meter.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration_Id;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;*/

import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.caseType.algorithm.autoTransition.AutoTransitionAlgorithmSpot;
import com.splwg.ccb.domain.admin.itemType.entity.ItemType;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;

//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.cm.api.lookup.TransitionConditionLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author smiranda
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForInboundCorrectedFieldCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundCorrectedExceptionStatus)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForInboundUncorrectedFieldCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundUncorrectedExceptionStatus)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForCorrectedFieldCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForCorrectedExceptionStatus, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForUncorrectedFieldCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForUncorrectedExceptionStatus, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForMainFieldCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForMainExceptionStatus, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = fieldCodeFeatureConfigurationType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (required = true, type = string, name = fieldCodeTransitionConditionFeatureConfigurationOptionType)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = statusDTransitionCondition, type = lookup)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = status6TransitionCondition, type = lookup)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = manualReviewTransitionCondition, type = lookup)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = transitionConditionForMetersWithCorrectors, type = lookup)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = transitionConditionForLargeMeters, type = lookup)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = featureConfigurationTypeForLargeMeterSize, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = featureConfigurationOptionTypeForLargeMeterSize, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = fieldCodeValueForCompletedWork, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = dExceptionStatus, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = 6ExceptionStatus, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForServicePointId, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = itemType, name = itemTypeForCorrector, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForMeterSize, required = true, type = entity)})
 */
public class CmMeterExceptionCaseAutoTransFieldCodeAlgComp_Impl extends
        CmMeterExceptionCaseAutoTransFieldCodeAlgComp_Gen implements
        //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        //CaseTypeAutoTransitionAlgorithmSpot {  
        AutoTransitionAlgorithmSpot { 
		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
    
	// Constants
    private final String _OPT_TYP_FLG = "_OPT_TYP_FLG";
    // TIR6. Start Delete
    /*
    private final String CASE_LOG_ADD = "ADD";
    private final String CASE_LOG_UPDATE = "UPDATE";
    private final String CASE_LOG_DELETE = "DELETE";
    private final MessageCategory_Id MESSAGE_CAT = new MessageCategory_Id(BigInteger.valueOf(CustomMessagesMDC.MESSAGE_CATEGORY));
    private final BigInteger CASE_CHAR_ADDED_MSG_NUM = BigInteger.valueOf(CustomMessageRepositoryMDC.NI0007_5_4_CASE_CHAR_ADDED);
    private final BigInteger CASE_CHAR_UPDATED_MSG_NUM = BigInteger.valueOf(CustomMessageRepositoryMDC.NI0007_5_4_CASE_CHAR_UPDATED);
    private final BigInteger CASE_CHAR_DELETED_MSG_NUM = BigInteger.valueOf(CustomMessageRepositoryMDC.NI0007_5_4_CASE_CHAR_DELETED);
    */
    // TIR6. End Delete
    
    // Variables for Hard Parameters
    private String nextTransitionCondition;
    private Bool shouldAutoTransition;
    private ToDoCase toDoCase;
    
    // Variables for Soft Parameters
    private CharacteristicType inboundCorrectedFieldCodeCharType,
            inboundCorrectedExceptionStatusCharType,
            // TIR6. Start Delete
            //inboundCorrectedExceptionStatusDateCharType,
            // TIR6. End Delete
            inboundUncorrectedFieldCodeCharType,
            inboundUncorrectedExceptionStatusCharType,
            // TIR6. Start Delete
            //inboundUncorrectedExceptionStatusDateCharType,
            // TIR6. End Delete
            correctedFieldCodeCharType,
            correctedExceptionStatusCharType,
            // TIR6. Start Delete
            //correctedExceptionStatusDateCharType,
            // TIR6. End Delete
            uncorrectedFieldCodeCharType,
            uncorrectedExceptionStatusCharType,
            // TIR6. Start Delete
            //uncorrectedExceptionStatusDateCharType,
            // TIR6. End Delete
            mainFieldCodeCharType,
            mainExceptionStatusCharType,
            // TIR6. Start Delete
            //mainExceptionStatusDateCharType,
            // TIR6. End Delete
            characteristicTypeForServicePointId,
            characteristicTypeForMeterSize;
    private FeatureConfiguration fieldCodeFeatureConfigurationType,
            featureConfigurationTypeForLargeMeterSize;
    private TransitionConditionLookup statusDTransitionCondition,
            status6TransitionCondition,
            manualReviewTransitionCondition,
            transitionConditionForMetersWithCorrectors,
            transitionConditionForLargeMeters;
    private String fieldCodeTransitionConditionFeatureConfigurationOptionType, 
            featureConfigurationOptionTypeForLargeMeterSize,
            fieldCodeValueForCompletedWork,
            dExceptionStatus,
            _6ExceptionStatus;
    private ItemType itemTypeForCorrector;
    
    // Other work variables
    private CaseType caseType;
    private String caseStatus = "",
            algCodeStr = "",
            servicePointIdStr = "",
            meterSize = "";
    private SQLResultRow caseCharSQLResult = null,
            meterSQLResult,
            correctorSQLResult,
            meterSizeOptValSQLResult;
    private Bool mainExceptionStatusUpdatedSw,
            mainFieldCodeUpdatedSw;    
    private ServicePoint_Id servicePointId;
    private Meter_Id meterId;
    private MeterConfiguration_Id meterConfigId;
    
    // Corrected
    private String inboundCorrectedExceptionStatus = "",
            // TIR6. Start Delete
            //inboundCorrectedExceptionStatusDate = "",
            // TIR6. End Delete
            inboundCorrectedFieldCode = "",
            correctedExceptionStatus = "",
            // TIR6. Start Delete
            //correctedExceptionStatusDate = "",
            // TIR6. End Delete
            correctedFieldCode = "";
            // TIR6. Start Delete
            /*
    private BigInteger inboundCorrectedExceptionStatusSeq = BigInteger.ZERO,
            inboundCorrectedExceptionStatusDateSeq = BigInteger.ZERO,
            inboundCorrectedFieldCodeSeq = BigInteger.ZERO,
            correctedExceptionStatusSeq = BigInteger.ZERO,
            correctedExceptionStatusDateSeq = BigInteger.ZERO,
            correctedFieldCodeSeq = BigInteger.ZERO;
            */
            // TIR6. End Delete
    // Uncorrected 
    private String inboundUncorrectedExceptionStatus = "",
            // TIR6. Start Delete
            //inboundUncorrectedExceptionStatusDate = "",
            // TIR6. End Delete
            inboundUncorrectedFieldCode = "",
            uncorrectedExceptionStatus = "",
            // TIR6. Start Delete
            //uncorrectedExceptionStatusDate = "",
            // TIR6. End Delete
            uncorrectedFieldCode = "";
            // TIR6. Start Delete
            /*
    private BigInteger inboundUncorrectedExceptionStatusSeq = BigInteger.ZERO,
            inboundUncorrectedExceptionStatusDateSeq = BigInteger.ZERO,
            inboundUncorrectedFieldCodeSeq = BigInteger.ZERO,
            uncorrectedExceptionStatusSeq = BigInteger.ZERO,
            uncorrectedExceptionStatusDateSeq = BigInteger.ZERO,
            uncorrectedFieldCodeSeq = BigInteger.ZERO;
            */
            // TIR6. End Delete
    // Permanent
    private String permanentExceptionStatus = "",
            // TIR6. Start Delete
            //permanentExceptionStatusDate = "",
            // TIR6. End Delete
            permanentFieldCode = "";
    // Main
    private String mainExceptionStatus = "",
            // TIR6. Start Delete
            //mainExceptionStatusDate = "",
            // TIR6. End Delete
            mainFieldCode = "";
            // TIR6. Start Delete
            /*
    private BigInteger mainExceptionStatusSeq = BigInteger.ZERO,
            mainExceptionStatusDateSeq = BigInteger.ZERO,
            mainFieldCodeSeq = BigInteger.ZERO;
            */
            // TIR6. End Delete
    // TIR5. Start Add
    FrameworkSession session;
    private Bool correctedExceptionStatusUpdatedSw,
            uncorrectedExceptionStatusUpdatedSw,
            correctedFieldCodeUpdatedSw,
            uncorrectedFieldCodeUpdatedSw;
    // TIR5. End Add

    public CaseStatus getNextCaseStatus() {
        
        return null;
    }

    public String getNextTransCondition() {
        
        return nextTransitionCondition;
    }

    public Bool getShouldAutoTransition() {
        
        return shouldAutoTransition;
    }

    public void setCase(ToDoCase arg0) {        
        toDoCase = arg0;
    }

    public void invoke() {
        
        // TIR5. Start Add
        session = (FrameworkSession) SessionHolder.getSession();
        // TIR5. End Add
        
        // Set the following variables to FALSE
        shouldAutoTransition = Bool.FALSE;
        
        // Get Case Type
        caseType = toDoCase.getCaseStatus().fetchIdCaseType();        
        
        // Get current Case status
        caseStatus = toDoCase.getCaseStatus().fetchIdStatus();
        
        // Validate transition condition soft parameters
        validateTransConditionParameters();
        
        // Determine whether a new exception status has been sent
        evaluateCorrectedExceptionStatus();         
        evaluateUncorrectedExceptionStatus();
        
        // TIR6. Start Delete
        // Determine whether a field code has been sent
        //evaluateCorrectedFieldCode();
        //evaluateUncorrectedFieldCode();
        // TIR6. End Delete
        
        // Process status updates
        // TIR6. Start Change
        if (correctedExceptionStatusUpdatedSw.isTrue() || uncorrectedExceptionStatusUpdatedSw.isTrue()){
            processStatusUpdates();
        }
        // TIR6. End Change

        if (shouldAutoTransition.isTrue()){
            return;
        }
        
        // TIR6. Start Add
        // Determine whether a field code has been sent
        evaluateCorrectedFieldCode();
        evaluateUncorrectedFieldCode();
        // TIR6. End Add
        
        // Process field code updates
        // TIR6. Start Change
        if (correctedFieldCodeUpdatedSw.isTrue() || uncorrectedFieldCodeUpdatedSw.isTrue()){
            processFieldCodeUpdates();
        }
        
    }

    private void validateTransConditionParameters() {
        
        // TIR5. Start Change
        // Status D Transition Condition
        if (notNull(statusDTransitionCondition)){
            validateTransCondition(statusDTransitionCondition.getLookupValue().fetchIdFieldValue().trim(), 
                    "Status D Transition Condition");
        }
        
        // Status 6 Transition Condition
        if (notNull(status6TransitionCondition)){
            validateTransCondition(status6TransitionCondition.getLookupValue().fetchIdFieldValue().trim(), 
                    "Status 6 Transition Condition");
        }
        
        // Manual Review Transition Condition
        if (notNull(manualReviewTransitionCondition)){
                validateTransCondition(manualReviewTransitionCondition.getLookupValue().fetchIdFieldValue().trim(), 
                    "Manual Review Transition Condition");
        }
        
        // Transition Condition for Meters With Correctors
        if (notNull(transitionConditionForMetersWithCorrectors)){
            validateTransCondition(transitionConditionForMetersWithCorrectors.getLookupValue().fetchIdFieldValue().trim(), 
                    "Transition Condition for Meters With Correctors");
        }

        // Transition Condition for Large Meters
        if (notNull(transitionConditionForLargeMeters)){
            validateTransCondition(transitionConditionForLargeMeters.getLookupValue().fetchIdFieldValue().trim(), 
                    "Transition Condition for Large Meters");         
        }
        // TIR5. End Change
    }
    
    private void validateTransCondition(String transCondition, String parmDescr) {
        
        PreparedStatement checkTransCondition
                = createPreparedStatement(
                        "SELECT " +
                            "TR.NEXT_STATUS_CD " +
                        "FROM " +
                            "CI_CASE_TR_RULE TR " +
                        "WHERE " +
                            "TR.CASE_TYPE_CD = :caseTypeCd " +
                            "AND TR.CASE_STATUS_CD = :caseStatusCd " +
                            //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                            //"AND TR.TR_COND_FLG = :transitionCondition");  
                			"AND TR.TR_COND_FLG = :transitionCondition", getClass().getName());  
        					//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        
        checkTransCondition.bindId("caseTypeCd", caseType.getId());
        checkTransCondition.bindString("caseStatusCd", caseStatus, "CASE_STATUS_CD");
        checkTransCondition.bindString("transitionCondition", transCondition, "TR_COND_FLG");
        
        if (checkTransCondition.list().size() == 0){
            if (parmDescr != ""){
            	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                // TIR5. Start Add
                //session.clear();
                // TIR5. End Add
            	session.clear(session.toString().trim());
                //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                addError(CustomMessageRepositoryMDC.NI0007_5_4_transCondParmInv(
                        algCodeStr, 
                        parmDescr, 
                        transCondition, 
                        caseStatus.trim()));
            }else{
                // TIR5. Start Delete
                //FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
                // TIR5. End Delete
            	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            	//session.clear();
            	session.clear(session.toString().trim());
                //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            	addError(CustomMessageRepositoryMDC.NI0007_5_4_transCondInv(
                        algCodeStr, 
                        transCondition, 
                        caseStatus.trim()));
            }
        }
        //Start Add for IM-064446    2015-01-07	   Rahul  
        checkTransCondition.close();
        //End   Add for IM-064446    2015-01-07	   Rahul    
        
    }

    private void evaluateCorrectedExceptionStatus() {      
        
        // TIR6. Start Add
        correctedExceptionStatusUpdatedSw = Bool.TRUE;
        // TIR6. End Add

        // Determine whether an Inbound Corrected Exception Status Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            // TIR6. Start Delete
            //inboundCorrectedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");
            // TIR6. End Delete
        }   
        
        // TIR6. Start Delete
        /*
        // Determine whether an Inbound Corrected Exception Status Date Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            inboundCorrectedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        */
        // TIR6. End Delete
        
        // Retrieve the value for the Permanent Corrected Exception Status Characteristic.
        caseCharSQLResult = getCaseChar(correctedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            correctedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            // TIR6. Start Delete
            //correctedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");
            // TIR6. End Delete
        }     
        
        // TIR6. Start Delete
        /*
        // Retrieve the value for the Permanent Corrected Exception Status Date Characteristic.
        caseCharSQLResult = getCaseChar(correctedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            correctedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            correctedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        */
        // TIR6. End Delete
        
        // If the Inbound Corrected Exception Status and the Permanent Corrected Exception Status are different
        if (inboundCorrectedExceptionStatus != "" && (!inboundCorrectedExceptionStatus.equals(correctedExceptionStatus))){
            // TIR6. Start Change
            /*
            // Update the Permanent Corrected Exception Status Characteristic using the value from the Inbound Corrected Exception Status
            if (correctedExceptionStatus != ""){
                updateChar(inboundCorrectedExceptionStatus, correctedExceptionStatusCharType, correctedExceptionStatusSeq);
                correctedExceptionStatus = inboundCorrectedExceptionStatus;
            }
            // Update the Permanent Corrected Exception Status Date Characteristic using the value from 
            // the Inbound Corrected Exception Status Date.
            if (correctedExceptionStatusDate != ""){
                if (inboundCorrectedExceptionStatusDate != ""){
                    updateChar(inboundCorrectedExceptionStatusDate, correctedExceptionStatusDateCharType, correctedExceptionStatusDateSeq);                   
                }
            }
            */
            correctedExceptionStatus = inboundCorrectedExceptionStatus;
            correctedExceptionStatusUpdatedSw = Bool.TRUE;
            // TIR6. End Change
        }
        
        // TIR6. Start Delete
        /*
        // Delete the Inbound Corrected Exception Status Characteristic
        if (inboundCorrectedExceptionStatus != ""){
            deleteCaseChar(inboundCorrectedExceptionStatusCharType, inboundCorrectedExceptionStatusSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedExceptionStatusCharType, 
                    inboundCorrectedExceptionStatusSeq, 
                    inboundCorrectedExceptionStatus, 
                    CASE_LOG_DELETE);                         
        }

        // Delete the Inbound Corrected Exception Status Date Characteristic
        if (inboundCorrectedExceptionStatusDate != ""){
            deleteCaseChar(inboundCorrectedExceptionStatusDateCharType, inboundCorrectedExceptionStatusDateSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedExceptionStatusDateCharType, 
                    inboundCorrectedExceptionStatusDateSeq, 
                    inboundCorrectedExceptionStatusDate, 
                    CASE_LOG_DELETE); 
        }
        */
        // TIR6. End Delete
        
    }
    
    private void evaluateUncorrectedExceptionStatus() {  
        
        // TIR6. Start Add
        uncorrectedExceptionStatusUpdatedSw = Bool.TRUE;
        // TIR6. End Add

        // Determine whether an Inbound Uncorrected Exception Status Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            // TIR6. Start Delete
            //inboundUncorrectedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");
            // TIR6. End Delete
        }   
        
        // TIR6. Start Delete
        /*
        // Determine whether an Inbound Uncorrected Exception Status Date Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            inboundUncorrectedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }  
        */
        // TIR6. End Delete
        
        // Retrieve the value for the Permanent Uncorrected Exception Status Characteristic.
        caseCharSQLResult = getCaseChar(uncorrectedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            uncorrectedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            // TIR6. Start Delete
            //uncorrectedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");
            // TIR6. End Delete
        }     
        
        // TIR6. Start Delete
        /*
        // Retrieve the value for the Permanent Uncorrected Exception Status Date Characteristic.
        caseCharSQLResult = getCaseChar(uncorrectedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            uncorrectedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            uncorrectedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        } 
        */
        // TIR6. End Delete
        
        // If the Inbound Uncorrected Exception Status and the Permanent Uncorrected Exception Status are different
        if (inboundUncorrectedExceptionStatus != "" && (!inboundUncorrectedExceptionStatus.equals(uncorrectedExceptionStatus))){
            // TIR6. Start Change
            /*
            // Update the Permanent Uncorrected Exception Status Characteristic using the value from 
            // the Inbound Uncorrected Exception Status
            if (uncorrectedExceptionStatus != ""){
                updateChar(inboundUncorrectedExceptionStatus, uncorrectedExceptionStatusCharType, uncorrectedExceptionStatusSeq);
                uncorrectedExceptionStatus = inboundUncorrectedExceptionStatus;
            }
            // Update the Permanent Uncorrected Exception Status Date Characteristic using the value from 
            // the Inbound Uncorrected Exception Status Date.
            if (uncorrectedExceptionStatusDate != ""){
                if (inboundUncorrectedExceptionStatusDate != ""){
                    updateChar(inboundUncorrectedExceptionStatusDate, uncorrectedExceptionStatusDateCharType, 
                            uncorrectedExceptionStatusDateSeq);
                }                
            }
            */
            uncorrectedExceptionStatus = inboundUncorrectedExceptionStatus;
            uncorrectedExceptionStatusUpdatedSw = Bool.TRUE;
            // TIR6. End Change
        }
        
        // TIR6. Start Delete
        /*
        // Delete the Inbound Uncorrected Exception Status Characteristic
        if (inboundUncorrectedExceptionStatus != ""){
            deleteCaseChar(inboundUncorrectedExceptionStatusCharType, inboundUncorrectedExceptionStatusSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedExceptionStatusCharType, 
                    inboundUncorrectedExceptionStatusSeq, 
                    inboundUncorrectedExceptionStatus, 
                    CASE_LOG_DELETE); 
        }

        // Delete the Inbound Uncorrected Exception Status Date Characteristic
        if (inboundUncorrectedExceptionStatusDate != ""){
            deleteCaseChar(inboundUncorrectedExceptionStatusDateCharType, inboundUncorrectedExceptionStatusDateSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedExceptionStatusDateCharType, 
                    inboundUncorrectedExceptionStatusDateSeq, 
                    inboundUncorrectedExceptionStatusDate, 
                    CASE_LOG_DELETE); 
        }
        */
        // TIR6. End Delete
    }
    
    private void evaluateCorrectedFieldCode() {        
        
        // TIR6. Start Add
        correctedFieldCodeUpdatedSw = Bool.FALSE;
        // TIR6. End Add
        
        // Determine whether an Inbound Corrected Field Code Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedFieldCodeCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedFieldCode = caseCharSQLResult.getString("CHARVAL");
            // TIR6. Start Delete
            //inboundCorrectedFieldCodeSeq = caseCharSQLResult.getInteger("SEQNUM");
            // TIR6. End Delete
        }         
        
        // Retrieve the value for the Permanent Corrected Field Code Characteristic.
        caseCharSQLResult = getCaseChar(correctedFieldCodeCharType);
        if (notNull(caseCharSQLResult)){
            correctedFieldCode = caseCharSQLResult.getString("CHARVAL");
            // TIR6. Start Delete
            //correctedFieldCodeSeq = caseCharSQLResult.getInteger("SEQNUM");  
            // TIR6. End Delete
        }
        
        if (inboundCorrectedFieldCode != "" && (!inboundCorrectedFieldCode.equals(correctedFieldCode))){
            // Create or update the Permanent Corrected Field Code Characteristic using the value from the Inbound Corrected Field Code.
            // TIR6. Start Change
            /*
            if (correctedFieldCode == ""){
                createPermChar(correctedFieldCodeCharType,inboundCorrectedFieldCode);     
                correctedFieldCode = inboundCorrectedFieldCode;
            }else{               
                updateChar(inboundCorrectedFieldCode, correctedFieldCodeCharType, correctedFieldCodeSeq);
                correctedFieldCode = inboundCorrectedFieldCode;
            }
            */
            correctedFieldCode = inboundCorrectedFieldCode;
            correctedFieldCodeUpdatedSw = Bool.TRUE;
            // TIR6. End Change
        }
        
        // TIR6. Start Delete
        /*
        if (inboundCorrectedFieldCode != "") {
            // Delete the Inbound Corrected Field Code Characteristic
            deleteCaseChar(inboundCorrectedFieldCodeCharType, inboundCorrectedFieldCodeSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedFieldCodeCharType, 
                    inboundCorrectedFieldCodeSeq, 
                    inboundCorrectedFieldCode, 
                    CASE_LOG_DELETE); 
        }  
        */
        // TIR6. End Delete
    }
    
    private void evaluateUncorrectedFieldCode() {     
        
        // TIR6. Start Add
        uncorrectedFieldCodeUpdatedSw = Bool.FALSE;
        // TIR6. End Add
        
        // Determine whether an Inbound Uncorrected Field Code Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedFieldCodeCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedFieldCode = caseCharSQLResult.getString("CHARVAL");
            // TIR6. Start Delete
            //inboundUncorrectedFieldCodeSeq = caseCharSQLResult.getInteger("SEQNUM");
            // TIR6. End Delete
        }         
        
        // Retrieve the value for the Permanent Uncorrected Field Code Characteristic.
        caseCharSQLResult = getCaseChar(uncorrectedFieldCodeCharType);
        if (notNull(caseCharSQLResult)){
            uncorrectedFieldCode = caseCharSQLResult.getString("CHARVAL");
            // TIR6. Start Delete
            //uncorrectedFieldCodeSeq = caseCharSQLResult.getInteger("SEQNUM");
            // TIR6. End Delete
        }
        
        if (inboundUncorrectedFieldCode != "" && (!inboundUncorrectedFieldCode.equals(uncorrectedFieldCode))){
            // Create or update the Permanent Uncorrected Field Code Characteristic using the value from the Inbound Uncorrected Field Code
            // TIR6. Start Change
            /*
            if (uncorrectedFieldCode == ""){
                createPermChar(uncorrectedFieldCodeCharType,inboundUncorrectedFieldCode);    
                uncorrectedFieldCode = inboundUncorrectedFieldCode;
            }else{
                updateChar(inboundUncorrectedFieldCode, uncorrectedFieldCodeCharType, uncorrectedFieldCodeSeq);
                uncorrectedFieldCode = inboundUncorrectedFieldCode;
            }
            */
            uncorrectedFieldCode = inboundUncorrectedFieldCode;
            uncorrectedFieldCodeUpdatedSw = Bool.TRUE;
            // TIR6. End Change
            
        }
        
        // TIR6. Start Delete
        /*
        if (inboundUncorrectedFieldCode != ""){
            // Delete the Inbound Uncorrected Field Code Characteristic
            deleteCaseChar(inboundUncorrectedFieldCodeCharType, inboundUncorrectedFieldCodeSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedFieldCodeCharType, 
                    inboundUncorrectedFieldCodeSeq, 
                    inboundUncorrectedFieldCode, 
                    CASE_LOG_DELETE); 
        }       
        */
        // TIR6. End Delete
    }
    
    private void processStatusUpdates() {        
        
        mainExceptionStatusUpdatedSw = Bool.FALSE;
        
        // If both Permanent Corrected Exception Status Characteristic and Permanent Uncorrected Exception Status Characteristic exist
        if (correctedExceptionStatus != "" && uncorrectedExceptionStatus !=""){
            // But the Characteristics have different values
            // TIR5. Start Change
            if (notNull(manualReviewTransitionCondition) && !correctedExceptionStatus.equals(uncorrectedExceptionStatus)){
            // TIR5. End Change
                // Return a transition condition equal to the value of the Manual Review Transition Condition parameter.
                shouldAutoTransition = Bool.TRUE;
                nextTransitionCondition = manualReviewTransitionCondition.getLookupValue().fetchIdFieldValue().trim();
                return;
            }else{
                // Both Characteristics exist and have the same value
                permanentExceptionStatus = correctedExceptionStatus;
                // TIR6. Start Delete
                //permanentExceptionStatusDate = correctedExceptionStatusDate;
                // TIR6. End Delete
            }
        }else{
            if (correctedExceptionStatus != ""){
                permanentExceptionStatus = correctedExceptionStatus;
                // TIR6. Start Delete
                //permanentExceptionStatusDate = correctedExceptionStatusDate;
                // TIR6. End Delete
            }
            if (uncorrectedExceptionStatus != ""){
                permanentExceptionStatus = uncorrectedExceptionStatus;
                // TIR6. Start Delete
                //ermanentExceptionStatusDate = uncorrectedExceptionStatusDate;
                // TIR6. End Delete
            }
        }
        
        // If only one of the Characteristics exist, or if both Characteristics exist and have the same value
        if (permanentExceptionStatus != ""){
            // Retrieve the Main Exception Status Characteristic value
            caseCharSQLResult = getCaseChar(mainExceptionStatusCharType);
            if (notNull(caseCharSQLResult)){
                mainExceptionStatus = caseCharSQLResult.getString("CHARVAL");
                // TIR6. Start Delete
                //mainExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");
                // TIR6. End Delete
            }
            // TIR6. Start Delete
            /*
            // Retrieve the Main Exception Status Date Characteristic value
            caseCharSQLResult = getCaseChar(mainExceptionStatusDateCharType);
            if (notNull(caseCharSQLResult)){
                mainExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
                mainExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
            }
            */
            // TIR6. End Delete
            
            // TIR6. Start Delete
            //if (mainExceptionStatus != ""){
            // TIR6. End Delete
                // If the value for the "permanent" Characteristics is different from the Main Exception Status
                if (!permanentExceptionStatus.equals(mainExceptionStatus)){
                    // TIR6. Start Delete
                    // Update the Main Exception Status Characteristic using the value from the Permanent Exception Status Characteristic.
                    //updateChar(permanentExceptionStatus, mainExceptionStatusCharType, mainExceptionStatusSeq);
                    // TIR6. End Delete
                    mainExceptionStatus = permanentExceptionStatus;
                    
                    // TIR6. Start Delete
                    /*
                    if (mainExceptionStatusDate != ""){
                        // Update the Main Exception Status Date Characteristic using the value from the Permanent Exception Status Date
                        updateChar(permanentExceptionStatusDate, mainExceptionStatusDateCharType, mainExceptionStatusDateSeq);
                    }
                    */
                    // TIR6. End Delete
                    mainExceptionStatusUpdatedSw = Bool.TRUE;
                }
            // TIR6. Start Delete    
            //}
            // TIR6. End Delete    
        }
        
        // If update was performed on the Main Exception Status
        if (mainExceptionStatusUpdatedSw.isTrue()){
            /* If the Main Exception Status was updated to 'D', return a transition condition equal to the value of the 
             * Status D Transition Condition parameter. */
            // TIR5. Start Change
            if (notNull(statusDTransitionCondition)){
                if (mainExceptionStatus.trim().equals(dExceptionStatus.trim())){
                    shouldAutoTransition = Bool.TRUE;
                    nextTransitionCondition = statusDTransitionCondition.getLookupValue().fetchIdFieldValue().trim();
                    return;
                }
            }
            
            /* If the Main Exception Status was updated to '6', return a transition condition equal to the value of the
             * Status 6 Transition Condition parameter. */  
            if (notNull(status6TransitionCondition)){
                if (mainExceptionStatus.trim().equals(_6ExceptionStatus.trim())){
                    shouldAutoTransition = Bool.TRUE;
                    nextTransitionCondition = status6TransitionCondition.getLookupValue().fetchIdFieldValue().trim();
                    return;
                }
            }
            // TIR5. End Change
        }                
        
    }
    
    private void processFieldCodeUpdates() {        
        
        mainFieldCodeUpdatedSw = Bool.FALSE;
        
        // If both Permanent Corrected Field Code Characteristic and Permanent Uncorrected Field Code Characteristic exist
        if (correctedFieldCode != "" && uncorrectedFieldCode !=""){
            // But the Characteristics have different values
            // TIR5. Start Change
            if (notNull(manualReviewTransitionCondition) && !correctedFieldCode.equals(uncorrectedFieldCode)){
            // TIR5. End Change
                // Return a transition condition equal to the value of the Manual Review Transition Condition parameter.
                shouldAutoTransition = Bool.TRUE;
                nextTransitionCondition = manualReviewTransitionCondition.getLookupValue().fetchIdFieldValue().trim();
                return;
            }else{
                // Both Characteristics exist and have the same value
                permanentFieldCode = correctedFieldCode;
            }
        }else{            
            if (correctedFieldCode != ""){
                permanentFieldCode = correctedFieldCode;
            }
            if (uncorrectedFieldCode != ""){
                permanentFieldCode = uncorrectedFieldCode;
            }
        }

        // If only one of the Characteristics exist, or if both Characteristics exist and have the same value
        if (permanentFieldCode != ""){
            // Retrieve the Main Field Code Characteristic value
            caseCharSQLResult = getCaseChar(mainFieldCodeCharType);
            if (notNull(caseCharSQLResult)){
                mainFieldCode = caseCharSQLResult.getString("CHARVAL");
                // TIR6. Start Delete
                //mainFieldCodeSeq = caseCharSQLResult.getInteger("SEQNUM"); 
                // TIR6. End Delete          
            }
            
            // TIR6. Start Change
            //if (mainFieldCode != ""){
            // If the value for the "permanent" Characteristics is different from the Main Exception Status
            if (!permanentFieldCode.equals(mainFieldCode)){
                // TIR6. Start Delete
                // Update the Main Field Code Characteristic using the value from the Permanent Field Code Characteristic.
                //updateChar(permanentFieldCode, mainFieldCodeCharType, mainFieldCodeSeq);
                // TIR6. End Delete
                mainFieldCode = permanentFieldCode;
                mainFieldCodeUpdatedSw = Bool.TRUE;
            }
            //}     
            // TIR6. End Change
        }
        
        // If update was performed on the Main Field Code
        if (mainFieldCodeUpdatedSw.isTrue()){
            // Determine whether the new value is the same as the parameter for "Field Code Value for Completed Work".
            if (mainFieldCode.trim().equals(fieldCodeValueForCompletedWork.trim())){
                // If the new field code value is the same as the parameter, skip to "Return transition condition based on field code"
                shouldAutoTransition = Bool.TRUE;
                nextTransitionCondition = determineTransitionCondition(mainFieldCode);
                validateTransCondition(nextTransitionCondition,"");
                return;
            }
            
            // Process Meter
            // TIR5. Start Change 
            if (notNull(transitionConditionForMetersWithCorrectors) || notNull(transitionConditionForLargeMeters)){
                processMeter();     
            }
            // TIR5. End Change
            
            if (shouldAutoTransition.isTrue()){
                return;
            }
            
            /* Using the Field Code Transition Condition Feature Configuration, retrieve and return the transition condition associated  
            with the Main Field Code Characteristic */
            shouldAutoTransition = Bool.TRUE;
            nextTransitionCondition = determineTransitionCondition(mainFieldCode);
            validateTransCondition(nextTransitionCondition,"");
            
        }        
        
    }
    
    private void processMeter(){       
        // TIR5. Start Delete
        //FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
        // TIR5. End Delete        
       
        // Get the Service Point from Case characteristics
        caseCharSQLResult = getCaseChar(characteristicTypeForServicePointId);
        if (isNull(caseCharSQLResult)){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        	//session.clear();
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        	addError(CustomMessageRepositoryMDC.NI0007_5_4_spIdCharMiss(
                    algCodeStr, 
                    characteristicTypeForServicePointId.getId().getIdValue().trim()));
        }
        servicePointIdStr = caseCharSQLResult.getString("CHARVAL");
        servicePointId = new ServicePoint_Id(servicePointIdStr);           
        if (isNull(servicePointId.getEntity())){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        	//session.clear();
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_4_spIdInv(
                    algCodeStr, 
                    servicePointIdStr.trim()));
        }       
        
        // Get meter currently installed at the Service Point
        meterSQLResult = getMeter(servicePointId);
        if (isNull(meterSQLResult)){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        	//session.clear();
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_4_spNoMeter(
                    algCodeStr, 
                    servicePointId.getIdValue().trim()));
        }
        meterId = (Meter_Id)meterSQLResult.getId("MTR", Meter.class);                
        meterConfigId = (MeterConfiguration_Id)meterSQLResult.getId("MCFG", MeterConfiguration.class);
        
        if (isNull(meterId.getEntity())){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        	//session.clear();
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_4_mtrIdInv(
                    algCodeStr, 
                    meterId.getIdValue().trim(),
                    meterConfigId.getIdValue().trim()));
        }                
        
        // Determine whether corrector is installed on the current meter
        if (notNull(transitionConditionForMetersWithCorrectors)){
            correctorSQLResult = getCorrector(meterId);
            if (notNull(correctorSQLResult)){
                // If a corrector is installed, return the transition condition for meters with correctors and exit processing.
                shouldAutoTransition = Bool.TRUE;
                nextTransitionCondition = transitionConditionForMetersWithCorrectors.getLookupValue().fetchIdFieldValue().trim();
                return;
            }
        }
        
        // Retrieve value of the Meter Size Characteristic
        if (notNull(transitionConditionForLargeMeters)){
            meterSize = getMeterChar(characteristicTypeForMeterSize);
            if (meterSize == ""){        
            	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            	//session.clear();
            	session.clear(session.toString().trim());
                //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                addError(CustomMessageRepositoryMDC.NI0007_5_4_noMeterSize(
                        algCodeStr, 
                        meterId.getIdValue().trim()));
            }
        
            // Determine whether the Meter Size Characteristic Value is included in the Feature Configuration list of Large Meter Sizes.
            meterSizeOptValSQLResult = getMeterSizeOptVal(meterSize);        
            if (notNull(meterSizeOptValSQLResult)){
                /* If the Characteristic Value is included in the Feature Configuration, return the transition condition for large meters
                and exit processing. */
                shouldAutoTransition = Bool.TRUE;
                nextTransitionCondition = transitionConditionForLargeMeters.getLookupValue().fetchIdFieldValue().trim();
                return;
            }           
        }
        
    }
    
    private SQLResultRow getMeter(ServicePoint_Id servicePointId) {

        SQLResultRow meterSQLResult = null;
        
        PreparedStatement getMeter 
                = createPreparedStatement(
                        "SELECT " +
                            "MC.MTR_CONFIG_ID AS MCFG, " +
                            "MC.MTR_ID AS MTR " +
                        "FROM " +
                            "CI_SP_MTR_HIST SPMH, " +
                            "CI_MTR_CONFIG MC " +
                        "WHERE " +
                            "SPMH.SP_ID = :spId " +
                            "AND SPMH.REMOVAL_MR_ID = ' '" +
                            "AND SPMH.MTR_CONFIG_ID = MC.MTR_CONFIG_ID " +
                            //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                            //"AND TRUNC(MC.EFF_DTTM) <= :effDttm");
                			"AND TRUNC(MC.EFF_DTTM) <= :effDttm", getClass().getName());
        					//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        
        getMeter.bindId("spId", servicePointId);
        getMeter.bindDateTime("effDttm", this.getProcessDateTime());
        
        meterSQLResult = getMeter.firstRow();
        //Start Add for IM-064446    2015-01-07	   Rahul  
        getMeter.close();
        //End   Add for IM-064446    2015-01-07	   Rahul 
        return meterSQLResult;
    }
    
    private SQLResultRow getCorrector(Meter_Id meterId) {
        
        SQLResultRow correctorSQLResult = null;
        
        PreparedStatement getCorrector 
                = createPreparedStatement(
                        "SELECT " +
                            "MEQ.MTR_ID " +
                        "FROM " + 
                            "CI_MTR_EQ MEQ, " +
                            "CI_ITEM ITM " +    
                        "WHERE " +
                            "MEQ.MTR_ID = :mtrId " +
                            // TIR5. Start Add
                            "AND MEQ.INSTALL_DT <= :installDate " +
                            // TIR5. End Add
                            "AND (MEQ.REMOVAL_DT IS NULL OR MEQ.REMOVAL_DT >= :removalDate) " +
                            "AND MEQ.ITEM_ID_EQ = ITM.ITEM_ID " +
                            //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                            //"AND ITM.ITEM_TYPE_CD = :itemTypeCd");
                			"AND ITM.ITEM_TYPE_CD = :itemTypeCd", getClass().getName());	
        					//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        
        getCorrector.bindId("mtrId", meterId);
        getCorrector.bindDate("removalDate", this.getProcessDateTime().getDate());
        getCorrector.bindId("itemTypeCd", itemTypeForCorrector.getId());
        // TIR5. Start Add
        getCorrector.bindDate("installDate", this.getProcessDateTime().getDate());
        // TIR5. End Add
        
        correctorSQLResult = getCorrector.firstRow();
        //Start Add for IM-064446    2015-01-07	   Rahul  
        getCorrector.close();
        //End   Add for IM-064446    2015-01-07	   Rahul 
        return correctorSQLResult;
    }
    
    private String getMeterChar(CharacteristicType charType) {
        
        String charVal = "";
        
        MeterCharacteristic meterChar = meterId.getEntity().getEffectiveCharacteristic(charType);
        
        if (notNull(meterChar)){                     
            if (charType.getCharacteristicType().isAdhocValue())
                charVal = meterChar.getAdhocCharacteristicValue().trim();
            else if (charType.getCharacteristicType().isForeignKeyValue())
                charVal = meterChar.getCharacteristicValueForeignKey1().trim();
            else if (charType.getCharacteristicType().isPredefinedValue())
                charVal = meterChar.getCharacteristicValue().trim();
        }
        
        return charVal;
    }
    
    private SQLResultRow getMeterSizeOptVal(String meterSize) {

        SQLResultRow meterSizeOptValSQLResult = null;
        
        PreparedStatement getMeterSizeOptVal 
                = createPreparedStatement(
                        "SELECT " +
                            "OPT.WFM_OPT_VAL " +
                        "FROM " + 
                            "CI_WFM_OPT OPT " +    
                        "WHERE " +
                            "OPT.WFM_NAME = :wfmName " +
                            "AND OPT.EXT_OPT_TYPE = :optType " +
                            //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                            //"AND OPT.WFM_OPT_VAL = :optVal");
                			"AND OPT.WFM_OPT_VAL = :optVal", getClass().getName());
        					//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        
        getMeterSizeOptVal.bindId("wfmName", featureConfigurationTypeForLargeMeterSize.getId());
        getMeterSizeOptVal.bindString("optType", featureConfigurationOptionTypeForLargeMeterSize, "EXT_OPT_TYPE");
        getMeterSizeOptVal.bindString("optVal", meterSize, "WFM_OPT_VAL");               
        
        meterSizeOptValSQLResult = getMeterSizeOptVal.firstRow();  
        //Start Add for IM-064446    2015-01-07	   Rahul  
        getMeterSizeOptVal.close();
        //End   Add for IM-064446    2015-01-07	   Rahul 
        return meterSizeOptValSQLResult;
    }
    
    private String determineTransitionCondition(String fieldCode) {
        
        FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
        
        String fieldCodeTransCondition = "",
                transCondOptVal = "",
                optVal = "";
        String[] transCondArray;
        SQLResultRow transCondSQLResult = null;
        List<SQLResultRow> transCondList;       
        
        optVal = fieldCode.trim() + ",";
        
        PreparedStatement getTransCond 
                = createPreparedStatement(
                        "SELECT " +
                            "OPT.WFM_OPT_VAL AS OPTVAL " +
                        "FROM " +
                            "CI_WFM_OPT OPT " +
                        "WHERE " +
                            "OPT.WFM_NAME = :wfmName " +
                            "AND OPT.EXT_OPT_TYPE = :optType " +
                            //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                            //"AND OPT.WFM_OPT_VAL LIKE :optVal");
                			"AND OPT.WFM_OPT_VAL LIKE :optVal", getClass().getName());
        					//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        
        getTransCond.bindId("wfmName", fieldCodeFeatureConfigurationType.getId());
        getTransCond.bindString("optType", fieldCodeTransitionConditionFeatureConfigurationOptionType, "EXT_OPT_TYPE");
        getTransCond.bindLikableString("optVal", optVal, "WFM_OPT_VAL"); 
        
        transCondList = getTransCond.list();       
        
        // Raise error message if the Field Code has no entry in the Feature Configuration
        if (transCondList.size() == 0){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        	//session.clear();
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_4_fieldCodeNotFound(
                    algCodeStr, 
                    fieldCode.trim(),
                    fieldCodeFeatureConfigurationType.getId().getIdValue().trim()));
        }
        
        // Raise error message if the Field Code has mutliple entries in the Feature Configuration
        if (transCondList.size() > 1){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        	//session.clear();
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_4_fieldCodeMultiFound(
                    algCodeStr, 
                    fieldCode.trim(),
                    fieldCodeFeatureConfigurationType.getId().getIdValue().trim()));
        }
        
        // Retrieve option value if there is exactly one row retrieved
        transCondSQLResult = transCondList.get(0);
        transCondOptVal = transCondSQLResult.getString("OPTVAL");        
        transCondArray = transCondOptVal.split(",");       
        
        try{
            fieldCodeTransCondition = transCondArray[1];
        }catch(ArrayIndexOutOfBoundsException e){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        	//session.clear();
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_4_noTransCondFound(
                    algCodeStr, 
                    fieldCode.trim(), 
                    fieldCodeFeatureConfigurationType.getId().getIdValue().trim()));
        }
        //Start Add for IM-064446    2015-01-07	   Rahul  
        getTransCond.close();
        //End   Add for IM-064446    2015-01-07	   Rahul 
        return fieldCodeTransCondition;
    }

    private SQLResultRow getCaseChar(CharacteristicType charType){
        
        SQLResultRow caseCharSQLResult = null;        
        String charVal = "";
        
        if (charType.getCharacteristicType().isPredefinedValue()){
            charVal = "CACH.CHAR_VAL ";
        }        
        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            charVal = "CACH.ADHOC_CHAR_VAL ";
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            charVal = "CACH.CHAR_VAL_FK1 ";
        }
        
        PreparedStatement getCaseChar 
                = createPreparedStatement(
                        "SELECT " +
                            charVal + "AS CHARVAL, " +
                            "CACH.SEQ_NUM AS SEQNUM " +
                        "FROM " +
                            "CI_CASE_CHAR CACH " +
                        "WHERE " +
                            "CACH.CASE_ID = :caseId " +
                            "AND CACH.CHAR_TYPE_CD = :charTypeCd " +
                            "AND CACH.SEQ_NUM = (SELECT MAX(CACH2.SEQ_NUM) " +
                                                "FROM CI_CASE_CHAR CACH2 " +
                                                "WHERE CACH2.CASE_ID = CACH.CASE_ID " +
                                                //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                                                //"AND CACH2.CHAR_TYPE_CD = CACH.CHAR_TYPE_CD)");
                								"AND CACH2.CHAR_TYPE_CD = CACH.CHAR_TYPE_CD)", getClass().getName());
        										//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        
        getCaseChar.bindId("caseId", toDoCase.getId());
        getCaseChar.bindId("charTypeCd", charType.getId());
        caseCharSQLResult = getCaseChar.firstRow();                        
        //Start Add for IM-064446    2015-01-07	   Rahul  
        getCaseChar.close();
        //End   Add for IM-064446    2015-01-07	   Rahul 
        return caseCharSQLResult;
    }

    // TIR6. Start Delete
    /*
    private void createPermChar(CharacteristicType charType, String charValue) {

        BigInteger newCarSeq = BigInteger.ZERO;
        
        // Create the Permanent characteristic
        newCarSeq = createCaseChar(charType, charValue);
        
        // Create case log for added characteristic
        createCaseLog(charType, newCarSeq, charValue, CASE_LOG_ADD); 
        
    }
    */
    // TIR6. End Delete
    // TIR6. Start Delete
    /*
    private void updateChar(String newCharValue, CharacteristicType charType, BigInteger seqNum) {
        
        // Update the Permanent characteristic
        updateCaseChar(charType, seqNum, newCharValue);
        
        // Create case log for updated characteristic
        createCaseLog(charType, seqNum, newCharValue, CASE_LOG_UPDATE);        
    }
    */
    // TIR6. End Delete
    // TIR6. Start Delete
    /*
    private BigInteger createCaseChar(CharacteristicType charType, String charValue){                  

        CaseCharacteristic_DTO caseCharDTO = new CaseCharacteristic_DTO();
        caseCharDTO.setId(new CaseCharacteristic_Id(charType, toDoCase, null));
        
        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            caseCharDTO.setAdhocCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isPredefinedValue()){
            caseCharDTO.setCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            caseCharDTO.setCharacteristicValueForeignKey1(charValue.trim());
        }
        
        CaseCharacteristic caseChar = caseCharDTO.newEntity();
        return caseChar.fetchIdSequence();
  
    }
    */
    // TIR6. End Delete
    // TIR6. Start Delete
    /*
    private void updateCaseChar(CharacteristicType charType, BigInteger seqNum, String newCharValue) {
        
        CaseCharacteristic_Id charChar_Id = new CaseCharacteristic_Id(charType, toDoCase, seqNum);
        CaseCharacteristic_DTO caseCharDTO = charChar_Id.getEntity().getDTO();
        
        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            caseCharDTO.setAdhocCharacteristicValue(newCharValue.trim());
        }
        if (charType.getCharacteristicType().isPredefinedValue()){
            caseCharDTO.setCharacteristicValue(newCharValue.trim());
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            caseCharDTO.setCharacteristicValueForeignKey1(newCharValue.trim());
        }
        
        charChar_Id.getEntity().setDTO(caseCharDTO);
        
    }
    */
    // TIR6. End Delete
    // TIR6. Start Delete
    /*
    private void deleteCaseChar(CharacteristicType charType, BigInteger seqNum) {

        CaseCharacteristic_Id charChar_Id = new CaseCharacteristic_Id(charType, toDoCase, seqNum);
        toDoCase.getCharacteristics().remove(charChar_Id);
        
    }
    */
    // TIR6. End Delete
    // TIR6. Start Delete
    /*
    private void createCaseLog(CharacteristicType charType, BigInteger seqNum, String charValue, String action){     
           
        CaseLog_DTO caseLogDto = new CaseLog_DTO();
        caseLogDto.setCaseStatusId(toDoCase.getCaseStatus().getId());
        caseLogDto.setCharacteristicTypeId(charType.getId());
        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            caseLogDto.setAdhocCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isPredefinedValue()){
            caseLogDto.setCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            caseLogDto.setCharacteristicValueForeignKey1(charValue.trim());
        }
        // Set Message Id depending on Action
        if (action == CASE_LOG_ADD){
            caseLogDto.setMessageId(new Message_Id(MESSAGE_CAT, CASE_CHAR_ADDED_MSG_NUM));
        }
        if (action == CASE_LOG_UPDATE){
            caseLogDto.setMessageId(new Message_Id(MESSAGE_CAT, CASE_CHAR_UPDATED_MSG_NUM));
        }
        if (action == CASE_LOG_DELETE){
            caseLogDto.setMessageId(new Message_Id(MESSAGE_CAT, CASE_CHAR_DELETED_MSG_NUM));
        }        
        caseLogDto.setLogType(CaseLogTypeLookup.constants.SYSTEM);
        
        // Get newly created Case Log
        CaseLog caseLog = toDoCase.getLogs().add(caseLogDto, null);             

        // Add message parameter for characteristic type
        CaseLogMessageParameter_DTO caseLogMsgParmDto = new CaseLogMessageParameter_DTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.ONE));
        caseLogMsgParmDto.setMessageParameter(charType.getId().getIdValue().trim());        
        caseLog.getMessageParameters().add(caseLogMsgParmDto, BigInteger.ONE);
        
        // Add message parameter for characteristic sequence number
        caseLogMsgParmDto = new CaseLogMessageParameter_DTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.valueOf(2)));
        caseLogMsgParmDto.setMessageParameter(seqNum.toString().trim());        
        caseLog.getMessageParameters().add(caseLogMsgParmDto, BigInteger.valueOf(2));
        
        // Add message parameter for characteristic value
        int counter = 0;
        String[] charVal = new String[]{"","","","","","",""};        
        
        for(int i = 0; i <= charValue.length() && counter < 7; i = i + 30){            
            if( i + 30 > charValue.length()){
                charVal[counter] = (charValue.substring(i, charValue.length()));
            }else{
                charVal[counter] = (charValue.substring(i, i + 30));                
                counter++;
            }
        }
        
        BigInteger charValParmSeq = BigInteger.valueOf(3);
        for (int i = 0; i < 7; i++) {            
            if (StringUtilities.notEmptyOrBlank(charVal[i])) {
                caseLogMsgParmDto = new CaseLogMessageParameter_DTO();
                caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, charValParmSeq));
                caseLogMsgParmDto.setMessageParameter(charVal[i].trim());        
                caseLog.getMessageParameters().add(caseLogMsgParmDto, charValParmSeq);
            }
            charValParmSeq = charValParmSeq.add(BigInteger.ONE);
        }
        
    }   
    */
    // TIR6. End Delete

    @Override
    protected void extraSoftParameterValidations(boolean arg0) {

        // Get algorithm code
        algCodeStr = this.getAlgorithm().getId().getIdValue().trim();
        
        // Characteristic Type for Inbound Corrected Field Code
        inboundCorrectedFieldCodeCharType = this.getCharacteristicTypeForInboundCorrectedFieldCode();
        validateChar(inboundCorrectedFieldCodeCharType, 
                "Characteristic Type for Inbound Corrected Field Code", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Inbound Corrected Exception Status
        inboundCorrectedExceptionStatusCharType = this.getCharacteristicTypeForInboundCorrectedExceptionStatus();
        validateChar(inboundCorrectedExceptionStatusCharType, 
                "Characteristic Type for Inbound Corrected Exception Status", 
                CharacteristicEntityLookup.constants.CASE);
        
        // TIR6. Start Delete
        /*
        // Characteristic Type for Inbound Corrected Exception Status Date
        inboundCorrectedExceptionStatusDateCharType = this.getCharacteristicTypeForInboundCorrectedExceptionStatusDate();
        validateChar(inboundCorrectedExceptionStatusDateCharType, 
                "Characteristic Type for Inbound Corrected Exception Status Date", 
                CharacteristicEntityLookup.constants.CASE);
        */
        // TIR6. End Delete
        
        // Characteristic Type for Inbound Uncorrected Field Code
        inboundUncorrectedFieldCodeCharType = this.getCharacteristicTypeForInboundUncorrectedFieldCode();
        validateChar(inboundUncorrectedFieldCodeCharType, 
                "Characteristic Type for Inbound Uncorrected Field Code", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Inbound Uncorrected Exception Status
        inboundUncorrectedExceptionStatusCharType = this.getCharacteristicTypeForInboundUncorrectedExceptionStatus();
        validateChar(inboundUncorrectedExceptionStatusCharType, 
                "Characteristic Type for Inbound Uncorrected Exception Status", 
                CharacteristicEntityLookup.constants.CASE);
        
        // TIR6. Start Delete
        /*
        // Characteristic Type for Inbound Uncorrected Exception Status Date
        inboundUncorrectedExceptionStatusDateCharType = this.getCharacteristicTypeForInboundUncorrectedExceptionStatusDate();
        validateChar(inboundUncorrectedExceptionStatusDateCharType, 
                "Characteristic Type for Inbound Uncorrected Exception Status Date", 
                CharacteristicEntityLookup.constants.CASE);
        */
        // TIR6. End Delete
        
        // Characteristic Type for Corrected Field Code
        correctedFieldCodeCharType = this.getCharacteristicTypeForCorrectedFieldCode();
        validateChar(correctedFieldCodeCharType, 
                "Characteristic Type for Corrected Field Code", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Corrected Exception Status
        correctedExceptionStatusCharType = this.getCharacteristicTypeForCorrectedExceptionStatus();
        validateChar(correctedExceptionStatusCharType, 
                "Characteristic Type for Corrected Exception Status", 
                CharacteristicEntityLookup.constants.CASE);
        
        // TIR6. Start Delete
        /*
        // Characteristic Type for Corrected Exception Status Date
        correctedExceptionStatusDateCharType = this.getCharacteristicTypeForCorrectedExceptionStatusDate();
        validateChar(correctedExceptionStatusDateCharType, 
                "Characteristic Type for Corrected Exception Status Date", 
                CharacteristicEntityLookup.constants.CASE);
        */
        // TIR6. End Delete
        
        // Characteristic Type for Uncorrected Field Code
        uncorrectedFieldCodeCharType = this.getCharacteristicTypeForUncorrectedFieldCode();
        validateChar(uncorrectedFieldCodeCharType, 
                "Characteristic Type for Uncorrected Field Code", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Uncorrected Exception Status
        uncorrectedExceptionStatusCharType = this.getCharacteristicTypeForUncorrectedExceptionStatus();
        validateChar(uncorrectedExceptionStatusCharType, 
                "Characteristic Type for Uncorrected Exception Status", 
                CharacteristicEntityLookup.constants.CASE);
        
        // TIR6. Start Delete
        /*
        // Characteristic Type for Uncorrected Exception Status Date                
        uncorrectedExceptionStatusDateCharType = this.getCharacteristicTypeForUncorrectedExceptionStatusDate();
        validateChar(uncorrectedExceptionStatusDateCharType, 
                "Characteristic Type for Uncorrected Exception Status Date", 
                CharacteristicEntityLookup.constants.CASE);
        */
        // TIR6. End Delete
        
        // Characteristic Type for Main Field Code
        mainFieldCodeCharType = this.getCharacteristicTypeForMainFieldCode();
        validateChar(mainFieldCodeCharType, 
                "Characteristic Type for Main Field Code", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Main Exception Status
        mainExceptionStatusCharType = this.getCharacteristicTypeForMainExceptionStatus();
        validateChar(mainExceptionStatusCharType, 
                "Characteristic Type for Main Exception Status", 
                CharacteristicEntityLookup.constants.CASE);
        
        // TIR6. Start Delete
        /*
        // Characteristic Type for Main Exception Status Date        
        mainExceptionStatusDateCharType = this.getCharacteristicTypeForMainExceptionStatusDate();
        validateChar(mainExceptionStatusDateCharType, 
                "Characteristic Type for Main Exception Status Date", 
                CharacteristicEntityLookup.constants.CASE);
        */
        // TIR6. End Delete
        
        // Field Code Feature Configuration Type
        fieldCodeFeatureConfigurationType = this.getFieldCodeFeatureConfigurationType();
        
        // Field Code Transition Condition Feature Configuration Option Type
        fieldCodeTransitionConditionFeatureConfigurationOptionType = this.getFieldCodeTransitionConditionFeatureConfigurationOptionType();
        
        /* Field Code Transition Condition Feature Configuration Option Type must be a valid option type 
        for Field Code Feature Configuration Type */
        validateOptionType(fieldCodeFeatureConfigurationType,
                "Field Code Transition Condition Feature Configuration Option Type",
                fieldCodeTransitionConditionFeatureConfigurationOptionType);
        
        // Status D Transition Condition
        statusDTransitionCondition = (TransitionConditionLookup) this.getStatusDTransitionCondition();
        
        // Status 6 Transition Condition
        status6TransitionCondition = (TransitionConditionLookup) this.getStatus6TransitionCondition();
        
        // Manual Review Transition Condition
        manualReviewTransitionCondition = (TransitionConditionLookup) this.getManualReviewTransitionCondition();
        
        // Transition Condition for Meters With Correctors
        transitionConditionForMetersWithCorrectors = (TransitionConditionLookup) this.getTransitionConditionForMetersWithCorrectors();
        
        // Transition Condition for Large Meters
        transitionConditionForLargeMeters = (TransitionConditionLookup) this.getTransitionConditionForLargeMeters();
        
        // Feature Configuration Type for Large Meter Size
        featureConfigurationTypeForLargeMeterSize = this.getFeatureConfigurationTypeForLargeMeterSize();
        
        // Feature Configuration Option Type for Large Meter Size
        featureConfigurationOptionTypeForLargeMeterSize = this.getFeatureConfigurationOptionTypeForLargeMeterSize();
        
        /* Feature Configuration Option Type for Large Meter Size must be a valid option type 
        for Feature Configuration Type for Large Meter Size */
        validateOptionType(featureConfigurationTypeForLargeMeterSize,
                "Feature Configuration Option Type for Large Meter Size",
                featureConfigurationOptionTypeForLargeMeterSize);
        
        // Field Code Value for Completed Work
        fieldCodeValueForCompletedWork = this.getFieldCodeValueForCompletedWork();
        
        // D Exception Status
        dExceptionStatus = this.getDExceptionStatus();
        
        // 6 Exception Status
        _6ExceptionStatus = this.get6ExceptionStatus();
        
        // Characteristic Type for Service Point ID
        characteristicTypeForServicePointId = this.getCharacteristicTypeForServicePointId();
        validateChar(characteristicTypeForServicePointId, 
                "Characteristic Type for Service Point Id", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Item Type for Corrector
        itemTypeForCorrector = this.getItemTypeForCorrector();
        
        // Characteristic Type for Meter Size
        characteristicTypeForMeterSize = this.getCharacteristicTypeForMeterSize();
        validateChar(characteristicTypeForMeterSize, 
                "Characteristic Type for Meter Size", 
                CharacteristicEntityLookup.constants.METER);
        
    }
    
    private void validateChar(CharacteristicType charType, String parmDescr, CharacteristicEntityLookup entity) {

        CharacteristicEntity_Id charEntity_Id = new CharacteristicEntity_Id(charType, entity);
        if (isNull(charEntity_Id.getEntity())){
            addError(CustomMessageRepositoryMDC.NI0007_5_4_charTypeInvForEntity(
                    algCodeStr, 
                    parmDescr, 
                    charType.getId().getIdValue().trim(), 
                    entity.getLookupValue().fetchLanguageDescription().trim()));
        }
    }
    
    private void validateOptionType(FeatureConfiguration wfmName, String parmDescr, String optType) {

        String extSysTypStr = wfmName.getFeatureType().getLookupValue().fetchIdFieldValue().trim();
        extSysTypStr = extSysTypStr.concat(_OPT_TYP_FLG);
        LookupField_Id lookupField_Id = new LookupField_Id(extSysTypStr);
        LookupValue_Id lookupValue_Id = new LookupValue_Id(lookupField_Id, optType.trim());
        if (isNull(lookupValue_Id.getEntity())){
            addError(CustomMessageRepositoryMDC.NI0007_5_4_optTypeInvForWFM(
                    algCodeStr, 
                    parmDescr, 
                    optType.trim(), 
                    wfmName.getId().getIdValue().trim()));
        }
    }

}
