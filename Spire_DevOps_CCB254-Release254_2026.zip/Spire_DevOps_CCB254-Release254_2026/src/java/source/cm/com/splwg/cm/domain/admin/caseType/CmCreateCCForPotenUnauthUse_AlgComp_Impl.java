/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This Algorithm will create a Customer Contact for the unauthorised 
 * usage with the premiseId, for a Specific PersonId.
 * 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-03-04   bsoundaraj002   NM0038 Initial Version.
 * 2016-01-22   MPang			Updated for CCB v2.4 compilation
 **************************************************************************/
package com.splwg.cm.domain.admin.caseType;

import java.math.BigInteger;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.security.user.User_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ContactMethodLookup;
import com.splwg.ccb.api.lookup.CustomerContactStatusLookup;
//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseTypeEnterStatusAlgorithmSpot;
import com.splwg.ccb.domain.admin.customerContactClass.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.CustomerContactType_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristics;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact_Id;
import com.splwg.ccb.domain.customerinfo.person.Person;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;*/

import com.splwg.ccb.domain.admin.caseType.algorithm.enterStatus.EnterStatusAlgorithmSpot;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.algorithm.enterStatus.EnterStatusAlgorithmSpot;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristics;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author bsoundaraj002
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = customerContactClass, name = customerContactClass, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = contactType, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = customerContactPremiseCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = customerContactCaseCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = caseCustomerContactCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = person, name = occupantPersonId, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = contactMethod, name = contactMethod, required = true, type = lookup)})
 */
public class CmCreateCCForPotenUnauthUse_AlgComp_Impl extends
CmCreateCCForPotenUnauthUse_AlgComp_Gen implements
	//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
	//CaseTypeEnterStatusAlgorithmSpot {
	 EnterStatusAlgorithmSpot {
	//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
    // Hard Parameter
    private ToDoCase currentCase;

    // Soft Parameters
    private CustomerContactClass custContactClass;
    private String contactType;    
    private CharacteristicType ccPremiseCharType;
    private CharacteristicType caseCharType;
    private CharacteristicType ccCaseCharType;
    private Person occupantPersonId;
    private ContactMethodLookup contactMethod;

    // Working Variables
    private CustomerContactType_Id custContactTypeId;
    private User_Id userId;

    private void initializeSoftParams(){

        custContactClass = getCustomerContactClass();
        contactType = getContactType();
        ccPremiseCharType = getCustomerContactPremiseCharType();
        caseCharType = getCustomerContactCaseCharType();
        ccCaseCharType = getCaseCustomerContactCharType();
        occupantPersonId = getOccupantPersonId();
        contactMethod = getContactMethod();
    }

    public String getNextCaseStatus() {
        return null;
    }

    public String getNextTransCondition() {
        return null;
    }

    public Bool getShouldAutoTransition() {
        return null;
    }

    public void setCase(ToDoCase currentCase) {
        this.currentCase = currentCase;
    }

    public void setCaseOriginalStatus(CaseStatus arg0) { }

    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

        initializeSoftParams();
        validateSoftParameters();
    }

    private void validateSoftParameters() {

        // Initialize Customer Contact Type
        custContactTypeId = new CustomerContactType_Id(custContactClass, contactType);
        if(isNull(custContactTypeId.getEntity())){
            addError(CustomMessageRepository.nm0038InvalidCustContactClassAndContactType(custContactClass.getId().getTrimmedValue(),contactType));
        }

        validateCharTypeEntity(ccPremiseCharType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);

        validateCharTypeEntity(ccCaseCharType, CharacteristicEntityLookup.constants.CASE);

        validateCharTypeEntity(caseCharType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);
    }

    private void validateCharTypeEntity(CharacteristicType parmCharType, CharacteristicEntityLookup parmEntityLookup){

        CharacteristicEntity_Id characteristicEntityId = new CharacteristicEntity_Id(parmCharType, parmEntityLookup);
        if (isNull(characteristicEntityId.getEntity())){
            addError(CustomMessageRepository.nm0038CharTypeInvalidForCharEntity(parmCharType.getId().getIdValue(), parmEntityLookup.getConstantName()));
        } 
    }

    public void invoke() {

        startChanges();
        createCustomerContact();
        saveChanges();
    }

    private void createCustomerContact() {

        userId = currentCase.getUserId();
        if(isNull(userId)){
            addError(CustomMessageRepository.nm0038UserIdCannotBeBlank());
        }else if(isNull(userId.getEntity())){
            addError(CustomMessageRepository.nm0038InvalidUserValue(userId.getTrimmedValue()));
        }

        CustomerContact_DTO ccDTO = new CustomerContact_DTO();

        ccDTO.setPersonId(occupantPersonId.getId());
        ccDTO.setCustomerContactTypeId(custContactTypeId);
        ccDTO.setContactDateTime(getProcessDateTime());
        ccDTO.setPreferredContactMethod(contactMethod);
        ccDTO.setCustomerContactStatus(CustomerContactStatusLookup.constants.OPEN);
        ccDTO.setUserId(userId);

        CustomerContact custContact = ccDTO.newEntity();

        CustomerContact_Id custContactId = custContact.getId();

        CustomerContactCharacteristics ccCharacteristics =  custContact.getCharacteristics();

        // Create a new Characteristic for Customer Contact - PremiseId
        CustomerContactCharacteristic_DTO custContactCharacteristicDTO = ccCharacteristics.newChildDTO();
        CustomerContactCharacteristic_Id ccPremiseCharId = new CustomerContactCharacteristic_Id(ccPremiseCharType, custContact);

        custContactCharacteristicDTO.setId(ccPremiseCharId);
        CharacteristicTypeLookup premiseCharTypeLookup = ccPremiseCharType.getCharacteristicType();
        String premiseIdValue = currentCase.getPremiseId().getTrimmedValue();

        if(premiseCharTypeLookup.isAdhocValue() || premiseCharTypeLookup.isFileLocationValue()){
            custContactCharacteristicDTO.setAdhocCharacteristicValue(premiseIdValue);
        } else if (premiseCharTypeLookup.isPredefinedValue()){
            custContactCharacteristicDTO.setCharacteristicValue(premiseIdValue);
        } else if (premiseCharTypeLookup.isForeignKeyValue()){
            custContactCharacteristicDTO.setCharacteristicValueForeignKey1(premiseIdValue);
        }        

        custContactCharacteristicDTO.newEntity();

        // Create a new Characteristic for Customer Contact - CaseId
        custContactCharacteristicDTO = ccCharacteristics.newChildDTO();        
        CustomerContactCharacteristic_Id custContactCaseCharId = new CustomerContactCharacteristic_Id(caseCharType, custContact);

        custContactCharacteristicDTO.setId(custContactCaseCharId);
        CharacteristicTypeLookup caseCharTypeLookup = caseCharType.getCharacteristicType();
        String caseIdValue = currentCase.getId().getTrimmedValue();

        if(caseCharTypeLookup.isAdhocValue() || caseCharTypeLookup.isFileLocationValue()){
            custContactCharacteristicDTO.setAdhocCharacteristicValue(caseIdValue);
        } else if (caseCharTypeLookup.isPredefinedValue()){
            custContactCharacteristicDTO.setCharacteristicValue(caseIdValue);
        } else if (caseCharTypeLookup.isForeignKeyValue()){
            custContactCharacteristicDTO.setCharacteristicValueForeignKey1(caseIdValue);
        }

        custContactCharacteristicDTO.newEntity();

        // Create a new Customer Contact Case Characterisitc - CustomerContactId
        BigInteger caseSeq = BigInteger.TEN;
        SQLResultRow maxSeqRow = retrieveMaxSeq(ccCaseCharType);
        
        if(notNull(maxSeqRow) && notNull(maxSeqRow.getInteger("SEQ"))){
            caseSeq = maxSeqRow.getInteger("SEQ").add(BigInteger.TEN);
        }
        
        CaseCharacteristic_DTO caseCharacteristicDTO = new CaseCharacteristic_DTO();
        CaseCharacteristic_Id caseCharId = new CaseCharacteristic_Id(ccCaseCharType, currentCase, BigInteger.valueOf(caseSeq.intValue()));
        caseCharacteristicDTO.setId(caseCharId);
        CharacteristicTypeLookup custContactCharTypeLookup = ccCaseCharType.getCharacteristicType();
        String custContactIdValue = custContactId.getTrimmedValue();

        if(custContactCharTypeLookup.isAdhocValue() || custContactCharTypeLookup.isFileLocationValue()){
            caseCharacteristicDTO.setAdhocCharacteristicValue(custContactIdValue);
        } else if (custContactCharTypeLookup.isPredefinedValue()){
            caseCharacteristicDTO.setCharacteristicValue(custContactIdValue);
        } else if (custContactCharTypeLookup.isForeignKeyValue()){
            caseCharacteristicDTO.setCharacteristicValueForeignKey1(custContactIdValue);
        }

        caseCharacteristicDTO.newEntity();
    }

    private SQLResultRow retrieveMaxSeq(CharacteristicType ccCaseCharType){
        StringBuilder maxSeqQueryStr = new StringBuilder();
        maxSeqQueryStr.append(" SELECT MAX(SEQ_NUM) AS SEQ");
        maxSeqQueryStr.append(" FROM CI_CASE_CHAR ");
        maxSeqQueryStr.append(" WHERE CASE_ID = :caseId ");
        maxSeqQueryStr.append(" AND CHAR_TYPE_CD = :charTypeCd ");
        //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement maxSeqStmt = createPreparedStatement(maxSeqQueryStr.toString());
        PreparedStatement maxSeqStmt = createPreparedStatement(maxSeqQueryStr.toString(), getClass().getName());
        //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        maxSeqStmt.bindId("caseId", currentCase.getId());
        maxSeqStmt.bindId("charTypeCd", ccCaseCharType.getId());
        SQLResultRow maxSeqrow = maxSeqStmt.firstRow();
        maxSeqStmt.close();
        return maxSeqrow;
    }

}
