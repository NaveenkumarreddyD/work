/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Algorithm - Credit and Collection Bill Message
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-04-04   RDizon  NM0079. Initial Version.
 * 2013-05-24   SMiran  Defect #1561. Set Allow Bill Reopen to true
 * 2013-06-07   CVB     Add Bill Message only if it does not exist yet.
 * 2016-01-25   MPang	Updated for CCB v2.4 compilation.
 **************************************************************************/

package com.splwg.cm.domain.admin.customerClass;

import java.math.BigInteger;

import com.splwg.base.api.Query;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.domain.common.currency.Currency;
import com.splwg.ccb.api.lookup.CollectionStatusLookup;
import com.splwg.ccb.api.lookup.SeveranceEventStatusLookup;
import com.splwg.ccb.api.lookup.SeveranceStatusLookup;
//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.billMessage.BillMessageType;
import com.splwg.ccb.domain.admin.customerClass.CustomerClassBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.severanceEventType.SeveranceEventType;
import com.splwg.ccb.domain.billing.bill.BillData;
import com.splwg.ccb.domain.billing.bill.BillMessage;
import com.splwg.ccb.domain.billing.bill.BillMessageParameter_DTO;
import com.splwg.ccb.domain.billing.bill.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.BillMessage_Id;
import com.splwg.ccb.domain.creditcollections.collectionProcess.CollectionProcess_Id;
import com.splwg.ccb.domain.creditcollections.severanceProcess.SeveranceProcess_Id;
import com.splwg.ccb.domain.customerinfo.account.Account;*/

import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.customerClass.algorithm.billCompletion.CustomerClassBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.severanceEventType.entity.SeveranceEventType;
import com.splwg.ccb.domain.billing.data.BillData;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage;
import com.splwg.ccb.domain.billing.bill.entity.BillMessageParameter_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_Id;
import com.splwg.ccb.domain.creditcollections.collectionProcess.entity.CollectionProcess_Id;
import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceProcess_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author redizon
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = billMessageType, name = collectionBillMessageCode, type = entity)
 *            , @AlgorithmSoftParameter (name = severanceNumberOfDays, type = integer)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = singleSeveranceBillMessageCode, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = multipleSeveranceBillMessageCode, type = entity)
 *            , @AlgorithmSoftParameter (entityName = severanceEventType, name = severanceEventType, type = entity)})
 */
public class CmCreditAndCollectionBillMessageAlgComp_Impl 
		extends CmCreditAndCollectionBillMessageAlgComp_Gen 
		implements CustomerClassBillCompletionAlgorithmSpot {

    // Soft Parameters
    private BillMessageType parmCollectionBillMessageCode;
    private BigInteger parmSeveranceNumberOfDays;
    private BillMessageType parmSingleSeveranceBillMessageCode;
    private BillMessageType parmMultipleSeveranceBillMessageCode;
    private SeveranceEventType parmSeveranceEventType;

    // Hard Parameters
    private Date accountingDate;
    private BillData billData;
    private Date billDate;
    private Currency currency;
    //2013-05-24 SMiran Start
    private Bool shouldAllowBillReopen;
    //2013-05-24 SMiran End    

    // Properties
    private Account account;

    public Bool getAllowBillReopen() {
        //2013-05-24 SMiran Start
        //return null;
        return shouldAllowBillReopen;
        //2013-05-24 SMiran End
    }

    public BillData getBillData() {
        return billData;
    }

    public void setAccountingDate(Date accountingDate) {
        this.accountingDate = accountingDate;
    }

    public void setBillData(BillData billData) {
        this.billData = billData;
    }

    public void setBillDate(Date billDate) {
        this.billDate = billDate;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public void invoke() {
        //2013-05-24 SMiran Start
        shouldAllowBillReopen = Bool.TRUE;
        //2013-05-24 SMiran End        
        account = billData.getBillDTO().fetchAccount();

        if (notNull(parmCollectionBillMessageCode)){
            CollectionProcess_Id collProcessId = (CollectionProcess_Id) cmGetActiveCollectionProcess().firstRow();

            // Create Bill Message if Account has an active Collection Process
            if (notNull(collProcessId)){
                cmCreateBillMessage(parmCollectionBillMessageCode, null, null);
            }
        }

        if (notNull(parmSingleSeveranceBillMessageCode)){
            Query getActiveSeveranceProcesses = cmGetActiveSeveranceProcess();

            // Create Bill Message if Account has an active Severance Process with pending Severance Event
            if (getActiveSeveranceProcesses.listSize() == 1){
                SeveranceProcess_Id severanceProcessId = (SeveranceProcess_Id) getActiveSeveranceProcesses.firstRow();
                Money arrearsMoney = severanceProcessId.getEntity().getArrearsAmount();
                Date creationDate = severanceProcessId.getEntity().getCreationDateTime().getDate();
                if (notNull(parmSeveranceNumberOfDays)){
                    creationDate = creationDate.addDays(parmSeveranceNumberOfDays.intValue());
                }
                cmCreateBillMessage(parmSingleSeveranceBillMessageCode, arrearsMoney.toPlainString(), creationDate);                
            }
        }

        if (notNull(parmMultipleSeveranceBillMessageCode)){
            Query getActiveSeveranceProcesses = cmGetActiveSeveranceProcess();

            // Create Bill Message if Account has multiple active Severance Processes with pending Severance Event
            if (getActiveSeveranceProcesses.listSize() > 1){
                cmCreateBillMessage(parmMultipleSeveranceBillMessageCode, null, null);                
            }
        }
    }

    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        // Retrieve the Algorithm Parameters
        parmCollectionBillMessageCode = getCollectionBillMessageCode();
        parmSeveranceNumberOfDays = getSeveranceNumberOfDays();
        parmSingleSeveranceBillMessageCode = getSingleSeveranceBillMessageCode();
        parmMultipleSeveranceBillMessageCode = getMultipleSeveranceBillMessageCode();
        parmSeveranceEventType = getSeveranceEventType();

        if (notNull(parmSingleSeveranceBillMessageCode) || notNull(parmMultipleSeveranceBillMessageCode)){
            if(isNull(parmSeveranceEventType)){
                addError(CustomMessageRepositoryMDC.nm0079_SeveranceTypeIsRequired());
            }
        }
    }

    /**
     * Create a Bill Message that is of a specific Bill Message Type
     * @param billMessageType BillMessageType
     * @param arrearsAmount String
     * @param creationDate Date
     */
    private void cmCreateBillMessage(BillMessageType billMessageType, String arrearsAmount, Date creationDate) {

        // CVB - 2013-06-07 - Start
        BillMessage_Id existingBillMessageId = new BillMessage_Id(billMessageType, billData.getBillDTO().getEntity());
        BillMessage existingBillMessage = existingBillMessageId.getEntity();
        if (isNull(existingBillMessage)){
            // CVB - 2013-06-07 - End
            BillMessage billMessage = billData.getBillDTO().getEntity().getMessages().add(new BillMessage_DTO(), billMessageType.getId());

            if (!isBlankOrNull(arrearsAmount)){
                BigInteger sequence = BigInteger.ONE;
                BillMessageParameter_DTO parameterDTO = billMessage.getParameters().newChildDTO();
                parameterDTO.setMessageParameterValue(arrearsAmount);
                billMessage.getParameters().add(parameterDTO, sequence);                
                parameterDTO.setMessageParameterValue(creationDate.toLocalizedString());
                billMessage.getParameters().add(parameterDTO, sequence.add(BigInteger.ONE));
            }
        }
    }

    /**
     * Get the Active Collection Process of the Account
     * @return query Query
     */
    private Query cmGetActiveCollectionProcess() {
        Query query = createQuery("FROM CollectionProcess CP "
                + "WHERE CP.account = :account "
                //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                // + "AND CP.collectionProcessStatus = :active");
                + "AND CP.collectionProcessStatus = :active", getClass().getName());
        		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        query.bindEntity("account", account);
        query.bindLookup("active", CollectionStatusLookup.constants.ACTIVE);
        query.addResult("collectionProcessId", "CP.id");

        return query;
    }

    /**
     * Get the Active Severance Process/es of the Account
     * @return query Query
     */
    private Query cmGetActiveSeveranceProcess() {
        Query query = createQuery("FROM SeveranceProcess SP "
                + "WHERE SP.severanceStatus = :activeStatus "
                + "AND EXISTS (SELECT SA.id FROM ServiceAgreement SA "
                + "WHERE SP.serviceAgreement = SA.id "
                + "AND SA.account = :account) "
                + "AND EXISTS (SELECT SE.id.severanceProcess FROM SeveranceEvent SE "
                + "WHERE SE.id.severanceProcess = SP.id "
                + "AND SE.severanceEventType = :severanceEventType " 
                //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
               // + "AND SE.severanceEventStatus = :pendingStatus)");
               + "AND SE.severanceEventStatus = :pendingStatus)", getClass().getName());
        		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        query.bindLookup("activeStatus", SeveranceStatusLookup.constants.ACTIVE);
        query.bindEntity("account", account);
        query.bindEntity("severanceEventType", parmSeveranceEventType);
        query.bindLookup("pendingStatus", SeveranceEventStatusLookup.constants.PENDING);
        query.addResult("severanceProcessId", "SP.id");

        return query;
    }
}