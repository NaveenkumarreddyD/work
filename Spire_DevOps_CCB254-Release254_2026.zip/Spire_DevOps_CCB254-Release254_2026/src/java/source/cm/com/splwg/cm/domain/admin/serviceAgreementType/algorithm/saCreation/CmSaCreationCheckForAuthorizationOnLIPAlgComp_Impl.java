/*
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                     
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * This SA Creation Algorithm validates if the user creating the 
 * Service Agreement has sufficient authorization to do so.
 * 
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:       by:          Reason:
 * YYYY-MM-DD  FLName
 * 2018-09-07  JHERNA		SysAid#245408 Initial Version.
 * 
 ***********************************************************************
 */
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.saCreation;

import com.splwg.base.domain.security.applicationService.ApplicationService;
import com.splwg.base.domain.security.securityType.SecurityAuthorizationLevel_Id;
import com.splwg.base.domain.security.securityType.SecurityType;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saCreation.SaTypeSaCreationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = applicationService, name = applicationService, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = securityType, name = securityType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = adminAccessLevel, required = true, type = string)})
 */
public class CmSaCreationCheckForAuthorizationOnLIPAlgComp_Impl 
		extends CmSaCreationCheckForAuthorizationOnLIPAlgComp_Gen 
		implements SaTypeSaCreationAlgorithmSpot {

	/*Hard Parameter*/
	private ServiceAgreement hpSA;
	
	/*Soft Parameters*/
	private ApplicationService parmApplicationServiceAccount;
	private SecurityType parmSecurityTypeBudgetPlanSelectionAuthorization;
	private String parmAdminAccessLevel;	
	
	/*Work Variables*/
	private SecurityAuthorizationLevel_Id wSecAuthLevelID;
	private String wAlgorithmCode;
	
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

		wAlgorithmCode = this.getAlgorithmId().getTrimmedValue();
		
		parmApplicationServiceAccount = this.getApplicationService();
		parmSecurityTypeBudgetPlanSelectionAuthorization = this.getSecurityType();
		parmAdminAccessLevel = this.getAdminAccessLevel();
		wSecAuthLevelID = new SecurityAuthorizationLevel_Id(parmSecurityTypeBudgetPlanSelectionAuthorization, parmAdminAccessLevel.trim());
		if (isNull(wSecAuthLevelID.getEntity())) {
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterIsInvalid(wAlgorithmCode, "Admin Access Level", parmAdminAccessLevel.trim()));
		}
	}

	@Override
	public void invoke() {
		
		boolean canCreateSA = this.getActiveContextUser().hasAuthorization(parmApplicationServiceAccount, wSecAuthLevelID);
		if (!canCreateSA) {
			// User %1 has no authorization to create Service Agreement of type %2.
			addError(CustomMessageRepositoryMGE.sa245408Lip9SaCreationNotAllowed(this.getActiveContextUser().getId().getTrimmedValue(), hpSA.getServiceAgreementType().fetchIdSaType().trim()));
		}
	}

	@Override
	public void setServiceAgreement(ServiceAgreement arg0) {
		hpSA = arg0;
	}
}
