/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractMailingKeyRecord 
		extends ColumnDelimitedRecord{	
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractMailingKeyRecord() {
		super(2);
		// Initialize all fields as blank/space
		this.setPostal(" ");
		this.setFiller();
	}
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * Mailing Key
	 */
	public void setPostal(String value) {
		rightPadColumn(1, 12, truncateInput(value, 12));
	}
	public void setFiller() {
		rightPadColumn(2, 3, " ");
	}
}