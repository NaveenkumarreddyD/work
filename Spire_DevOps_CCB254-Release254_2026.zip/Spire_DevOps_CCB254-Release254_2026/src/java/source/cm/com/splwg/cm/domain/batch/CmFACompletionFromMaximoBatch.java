/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * CINT01810 - This batch process will evaluate the inbound staging records 
 * from MAXIMO and complete the field activities accordingly. This batch 
 * process will also make appropriate changes to the meter and item objects
 * in CC&B. 
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2015-03-09   SMiran        	CINT01810 - Initial Version.
 * 2015-05-26   SMiran			Defect 3223676. Ensure uniqueness of meters
 * 								by searching by badge number, manufacturer,
 * 								and site number. Also ensure that meters are 
 * 								processed first before items
 * 								Defect 3220374. Fix Retiring/Removal of
 * 								meters - no need to validate meter config
 * 								Defect 3226032. Allow meter configuration
 * 								changes on meter install.
 * 								Defect 3227823. Do not validate meter config
 * 								changes on meter removal
 * 2015-06-17   SMiran			Defect 3236052. Added SITEID column to FA
 * 								Item interface table.
 * 2015-06-18   SMiran			Defect 3236175. Added SERIAL_NBR_FOUND,
 * 								SERIAL_NBR_LEFT, and SITEID columns to FA
 * 								interface table. Also fixed FA completion to
 * 								ensure correct Meter is processed.
 * 2015-07-06   SMiran			Defect 3233441. Retire Item after processing
 * 								removal.
 * 2015-07-09	SMiran			Defect 3249308. Check for errors after
 * 								attempting to complete FA.
 * 2015-07-17	SMiran			Defect 3249536. Validate Manufacturer and
 * 								Model only when supplied.
 * 2015-07-21	SMiran			Defect 3249477. For Installs and Exchange,
 * 								if the Work Date/Time is before
 * 								the Meter's effective configuration date/time,
 * 								set the Meter Config effective date/time to
 * 								Work Date/Time
 * 2015-08-04	SMiran			Defect 3266831. Search for SP Meter history
 *								using Serial Number and SP Id
 * 2015-08-05	SMiran			Defect 3269634. Trim serialNumberFound and
 * 								serialNumberLeft
 * 2015-08-14	SMiran			Defect 3272953. Check first if Meter Config
 * 								has 2 registers before adding 2nd register read
 * 2015-08-21   SMiran			Defect 3292618. Fix nullPointerException on 
 * 								Index Reset
 * 2016-01-29  	MPang			Updated for CCB v2.4 compilation.
 * 2016-03-10   JHERNA          SysAid#68431. When completing a Field Activity
 *                              which needs to create/update meter(s) from 
 *                              Maximo, ensure that it is unique given their 
 *                              CC&B Badge Number, Manufacturer and Site Number
 *                              combination.
 * 2016-04-25   BMarquez        Merged with production version. Updated
 *                              for CCB v2.4 compilation
 * 2020-08-07   BMarquez        Defect 4465518. When removal step is optional, do
 *                              not remove the meter/fill out the removal step.
 *                              Cleaned up imports.
 * 2020-07-07   JVitug          B-13084. Added additional step to default the values
 *                              of the second register if the meter configuration
 *                              type in CCB is '001' and no second register was
 *                              found.
 * 2020-08-13   JVitug          B-13084. Added additional step to default the values
 *                              of the second register if the meter configuration
 *                              type in CCB is '001' and no second register was
 *                              found for the _found columns.
 * 2020-09-16   JVitug          B-13084 - Reopened. Added defaulting value 
 * 								of the second register in the processMeterData()
 * 								function.
 * 2020-10-20   JVitug          Defect 42690. added null check when querying
 * 								the Inbound FA Meter Characteristics Table
 * 2026-08-07   DLampa          E-13304. Updated to allow multiple configuration 
 *                              types for defaulting the value of the second register
 **************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.businessService.BusinessServiceDispatcher;
import com.splwg.base.api.businessService.BusinessServiceInstance;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Id;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.lookup.MessageParameterTypeLookup;
import com.splwg.base.api.lookup.YesNoOptionLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.lookup.LookupField_Id;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.domain.common.message.MessageBuilder;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.api.lookup.ConsumptionTypeLookup;
import com.splwg.ccb.api.lookup.FieldActivityStepTypeActionLookup;
import com.splwg.ccb.api.lookup.FieldActivityStepUploadStatusLookup;
import com.splwg.ccb.api.lookup.FieldActivityUploadStatusLookup;
import com.splwg.ccb.api.lookup.HowToUseLookup;
import com.splwg.ccb.api.lookup.ItemStatusLookup;
import com.splwg.ccb.api.lookup.OnOffStatusLookup;
import com.splwg.ccb.api.lookup.ReadTypeLookup;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityTypeCharacteristicType_Id;
import com.splwg.ccb.domain.admin.intervalRegisterType.entity.IntervalRegisterType_Id;
import com.splwg.ccb.domain.admin.itemType.entity.CharacteristicTypeItemType_Id;
import com.splwg.ccb.domain.admin.itemType.entity.ItemType;
import com.splwg.ccb.domain.admin.itemType.entity.ItemType_Id;
import com.splwg.ccb.domain.admin.manufacturer.entity.Manufacturer_Id;
import com.splwg.ccb.domain.admin.manufacturer.entity.Model_Id;
import com.splwg.ccb.domain.admin.meterConfigurationType.entity.MeterConfigurationType;
import com.splwg.ccb.domain.admin.meterConfigurationType.entity.MeterConfigurationType_Id;
import com.splwg.ccb.domain.admin.meterReadSource.entity.MeterReadSource_Id;
import com.splwg.ccb.domain.admin.meterType.entity.CharacteristicTypeMeterType_Id;
import com.splwg.ccb.domain.admin.meterType.entity.MeterType_Id;
import com.splwg.ccb.domain.admin.protocol.entity.Protocol_Id;
import com.splwg.ccb.domain.admin.readOutType.entity.ReadOutType_Id;
import com.splwg.ccb.domain.admin.representative.entity.Representative_Id;
import com.splwg.ccb.domain.admin.retireReason.entity.RetireReason_Id;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityLog;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityLog_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityLog_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivityUpload.entity.FieldActivityStepUpload;
import com.splwg.ccb.domain.fieldorder.fieldActivityUpload.entity.FieldActivityStepUpload_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivityUpload.entity.FieldActivityStepUpload_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivityUpload.entity.FieldActivityUpload;
import com.splwg.ccb.domain.fieldorder.fieldActivityUpload.entity.FieldActivityUploadCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivityUpload.entity.FieldActivityUploadCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivityUpload.entity.FieldActivityUploadCharacteristic_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivityUpload.entity.FieldActivityUpload_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivityUpload.entity.FieldActivityUpload_Id;
import com.splwg.ccb.domain.meterread.common.MeterReadCreator;
import com.splwg.ccb.domain.meterread.data.MeterReadCreatorData;
import com.splwg.ccb.domain.meterread.data.MeterReadCreatorRegisterReadData;
import com.splwg.ccb.domain.meterread.item.entity.Item;
import com.splwg.ccb.domain.meterread.item.entity.Item_Id;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_DTO;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfigurationRegisters;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_DTO;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory_DTO;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory_Id;
import com.splwg.cm.api.lookup.CmInterfaceStatusLookup;
import com.splwg.cm.api.lookup.MeterStatusLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMeterValidationForUniquenessRoutine;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.interfaceStaging.CmCharacteristicTempData;
import com.splwg.cm.domain.interfaceStaging.CmInterfaceErrorLogMaintenance;
import com.splwg.cm.domain.interfaceStaging.CmItemData;
import com.splwg.cm.domain.interfaceStaging.CmItemHelper;
import com.splwg.cm.domain.interfaceStaging.CmMeterData;
import com.splwg.cm.domain.interfaceStaging.CmMeterHelper;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

/**
 * @author 90723
 *
 @BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = serviceTaskType, name = SERVICE_TASK_TYPE, required = true, type = entity)})
 */
public class CmFACompletionFromMaximoBatch extends
	CmFACompletionFromMaximoBatch_Gen {
	
	// Batch parameters
	private ServiceTaskType parmServiceTaskType;
	
	// Service Task parameters
	private String parmSourceSystemName;
	private String parmTargetSystemName;
	
	// Id class for the Staging Key
	private static class CmInboundInterfaceStaging_Id implements Id {
		
		private static final long serialVersionUID = 1L;		
		private String stagingKey;
		
		public CmInboundInterfaceStaging_Id(String stagingKey) {
			setStagingKey(stagingKey);
		}
		
		public String getStagingKey() {
			return stagingKey;
		}
		
		private void setStagingKey(String stagingKey) {
			this.stagingKey = stagingKey;
		}
		
		public boolean isNull() {
			return false;
		}
		
		public void appendContents(StringBuilder arg0) {
			
		}
		
	}
	
	@Override
	public void validateSoftParameters(boolean arg0) {
				
		// Get soft parameters
		parmServiceTaskType = this.getParameters().getSERVICE_TASK_TYPE();
		
		BusinessObject serviceTaskTypeBo = parmServiceTaskType.getBusinessObject();
		BusinessObjectInstance serviceTaskType = BusinessObjectInstance.create(serviceTaskTypeBo);
		serviceTaskType.set("serviceTaskType", parmServiceTaskType.getId().getTrimmedValue()); 
		serviceTaskType = BusinessObjectDispatcher.read(serviceTaskType);		
				
		parmSourceSystemName = serviceTaskType.getString("sourceSystem");
		parmTargetSystemName = serviceTaskType.getString("targetSystem");
		
	}

	public JobWork getJobWork() {

        ArrayList<ThreadWorkUnit> workUnitList =  new ArrayList<ThreadWorkUnit>();
        List<SQLResultRow> inboundStagingRow = null;
        // Get inbound staging records to process
        inboundStagingRow = getInboundStagingRecords();

        // Create work unit for each record in result set
        for(SQLResultRow row : inboundStagingRow){
            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId(new CmInboundInterfaceStaging_Id(row.getString("STAGING_KEY")));
            workUnit.addSupplementalData("logicalTransactionNumber", row.getString("LOGICAL_TRX_NUMBER"));
            workUnit.addSupplementalData("creationDateTime", row.getDateTime("CREATION_DATETIME"));
            workUnit.addSupplementalData("originatingKey", row.getString("ORIGINATING_KEY")); 
            workUnitList.add(workUnit);
        }

        return createJobWorkForThreadWorkUnitList(workUnitList);

	}
	
	private List<SQLResultRow> getInboundStagingRecords() {
		
		/*
		 * Interface Name must be equal to Interface Name batch parameter
		 * Status Flag must be "N"
		 * Source System Name must be equal to Source System Name batch parameter
		 * Target System Name must be equal to Target System Name batch parameter
		 */
		StringBuilder createUpdateMeterItemQueryStr = new StringBuilder();
		createUpdateMeterItemQueryStr.append(" SELECT ");
		createUpdateMeterItemQueryStr.append("	 STAGING_KEY ");
		createUpdateMeterItemQueryStr.append("   , LOGICAL_TRX_NUMBER ");
		createUpdateMeterItemQueryStr.append("   , CREATION_DATETIME ");
		createUpdateMeterItemQueryStr.append("   , ORIGINATING_KEY ");
		createUpdateMeterItemQueryStr.append(" FROM ");
		createUpdateMeterItemQueryStr.append("   XXL_INT_INBOUND_STG ");
		createUpdateMeterItemQueryStr.append(" WHERE ");
		createUpdateMeterItemQueryStr.append("   INTERFACE_NAME = :interfaceName ");
		createUpdateMeterItemQueryStr.append("   AND STATUS_FLAG = :statusFlag ");
		createUpdateMeterItemQueryStr.append("   AND SOURCE_SYSTEM_NAME = :sourceSystemName ");
		createUpdateMeterItemQueryStr.append("   AND TARGET_SYSTEM_NAME = :targetSystemName ");
		createUpdateMeterItemQueryStr.append(" ORDER BY STAGING_KEY ASC ");
		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement inboundStagingPrepStmt = createPreparedStatement(createUpdateMeterItemQueryStr.toString());	
		PreparedStatement inboundStagingPrepStmt = createPreparedStatement(createUpdateMeterItemQueryStr.toString(), getClass().getName());	
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		inboundStagingPrepStmt.bindString("interfaceName", parmServiceTaskType.getId().getTrimmedValue(), "INTERFACE_NAME");
		inboundStagingPrepStmt.bindString("statusFlag", CmInterfaceStatusLookup.constants.NEW.trimmedValue(), "STATUS_FLG");
		inboundStagingPrepStmt.bindString("sourceSystemName", parmSourceSystemName.trim(), "SOURCE_SYSTEM_NAME");
		inboundStagingPrepStmt.bindString("targetSystemName", parmTargetSystemName.trim(), "TARGET_SYSTEM_NAME");
		
		List<SQLResultRow> inboundStagingRow = inboundStagingPrepStmt.list();
		
		inboundStagingPrepStmt.close();
		
		return inboundStagingRow;
	}

	public Class<CmFACompletionFromMaximoBatchWorker> getThreadWorkerClass() {
		return CmFACompletionFromMaximoBatchWorker.class;
	}

	public static class CmFACompletionFromMaximoBatchWorker extends
			CmFACompletionFromMaximoBatchWorker_Gen {		
		
		// Constants
		private final String BLANK_VALUE = " ";
		private final String ERROR_CODE_DELIMITER = "-";
		private final String ERROR_SOURCE = "Logged by Target System";
		private final String XXL_INT_FA_IN_STG = "XXL_INT_FA_IN_STG";
		private final String XXL_INT_FA_CHAR_IN_STG = "XXL_INT_FA_CHAR_IN_STG";
		private final String XXL_INT_FA_MTR_IN_STG = "XXL_INT_FA_MTR_IN_STG";	
		private final String XXL_INT_FA_MTR_CHAR_IN_STG = "XXL_INT_FA_MTR_CHAR_IN_STG";
		private final String XXL_INT_FA_ITEM_IN_STG = "XXL_INT_FA_ITEM_IN_STG";
		private final String XXL_INT_FA_ITEM_CHAR_IN_STG = "XXL_INT_FA_ITEM_CHAR_IN_STG";
		// 2015-06-18. SMiran. Defect 3236175. Start Change
		//private final String CM_FA_COMPLETION_BS = "CmFACompletionFromMaximo";
		private final String CM_FA_COMPLETION_BS = "CmCompleteFA";
		// 2015-06-18. SMiran. Defect 3236175. End Change
		
		// Soft parameters
		private ServiceTaskType parmServiceTaskType;
		private String parmSourceSystemName;
		private String parmTargetSystemName;
		private ItemType parmRegulatorItemType;
		// 2015-05-26. SMiran. Defect 3223676. Start Add
		private CharacteristicType parmMeterSiteCharType;
		// 2015-05-26. SMiran. Defect 3223676. End Add
		
		// Work Variables
		private CmInboundInterfaceStaging_Id stagingKey = null;
		private String logicalTransactionNumber = BLANK_VALUE;
		private String originationTable = BLANK_VALUE;		
		private SQLResultRow faCompRow = null;	
		private List<CmMeterData> meterDataList = new ArrayList<CmMeterData>();
		private List<CmItemData> itemDataList = new ArrayList<CmItemData>();
		private FieldActivityType faType;
		private ServicePointMeterHistory spMeterHistFound;
		private Bool newMeterConfigNeeded;
		private Bool isRealMeterExchange;
		// 2015-06-18. SMiran. Defect 3236175. Start Add
		private int errorCount = 0;
		private int maxErrors = 0;
		// 2015-06-18. SMiran. Defect 3236175. End Add
		// Start Change DLampa E-13304 - 2026-08-07
	    // Start Add JVitug - B-13084 - 2020-07-07
        //private  MeterConfigurationType defaultSecondRegisterMeterConfigType;
        // End Add JVitug - B-13084 - 2020-07-07
        private ArrayList<MeterConfigurationType> defaultSecondRegisterMeterConfigType = new ArrayList<MeterConfigurationType>();;
        // End Change DLampa E-13304 - 2026-08-07
		
		// FA Variables
		private FieldActivity_Id faId;
		private ServicePoint_Id spId;
		private DateTime workDateTime;
		private Representative_Id workedById;
		private String faComments;
		// Found Fields
		private String badgeNumberFound = BLANK_VALUE;
		private Manufacturer_Id manufacturerIdFound = null;
		private YesNoOptionLookup useOnBillFound = null;
		private MeterReadSource_Id meterReadSourceFound = null;
		// Found Register 1
		private BigInteger reg1SeqFound = BigInteger.ZERO;
		private ReadTypeLookup reg1ReadTypeFound = null;
		private BigDecimal reg1ReadingFound = BigDecimal.ZERO;
		private YesNoOptionLookup reg1ReviewHiLoFound = null;
		// Found Register 2
		private BigInteger reg2SeqFound = BigInteger.ZERO;
		private ReadTypeLookup reg2ReadTypeFound = null;
		private BigDecimal reg2ReadingFound = BigDecimal.ZERO;
		private YesNoOptionLookup reg2ReviewHiLoFound = null;
		// Left Fields
		private String badgeNumberLeft = BLANK_VALUE;
		private Manufacturer_Id manufacturerIdLeft = null;
		private YesNoOptionLookup useOnBillLeft = null;
		private MeterReadSource_Id meterReadSourceLeft = null;
		// Left Register 1
		private BigInteger reg1SeqLeft = BigInteger.ZERO;
		private ReadTypeLookup reg1ReadTypeLeft = null;
		private BigDecimal reg1ReadingLeft = BigDecimal.ZERO;
		private YesNoOptionLookup reg1ReviewHiLoLeft = null;
		// Left Register 2
		private BigInteger reg2SeqLeft = BigInteger.ZERO;
		private ReadTypeLookup reg2ReadTypeLeft = null;
		private BigDecimal reg2ReadingLeft = BigDecimal.ZERO;
		private YesNoOptionLookup reg2ReviewHiLoLeft = null;	
		// 2015-06-18. SMiran. Defect 3236175. Start Add
		private String serialNumberFound = BLANK_VALUE;
		private String serialNumberLeft = BLANK_VALUE;
		private String siteNumber = BLANK_VALUE;
		// 2015-06-18. SMiran. Defect 3236175. End Add
		// FA Characteristics
		private List<CmCharacteristicTempData> faCharList = new ArrayList<CmCharacteristicTempData>();
		
		// 2015-05-26. SMiran. Defect 3223676. Start Add
		private MeterConfiguration_Id meterConfigIdFound;
		private MeterConfiguration_Id meterConfigIdLeft;
		// 2015-05-26. SMiran. Defect 3223676. End Add
		
		// Meter Variables
		private String meterBadgeNumber = BLANK_VALUE;		
		private MeterType_Id meterTypeId = null;
		private MeterStatusLookup meterStatus = null;
		private String meterSerialNumber = BLANK_VALUE;
		private Manufacturer_Id meterManufacturerId = null;
		private Model_Id meterModelId = null;
		private RetireReason_Id meterRetireReasonId = null;
		private String meterLongDescription = BLANK_VALUE;
		private Date meterReceiveDate = null;
		private Date meterRetireDate = null;
		
		// Meter Configuration Variables
		private DateTime meterConfigEffectiveDateTime = null;
		private MeterConfigurationType_Id meterConfigTypeId = null;
		
		// Register 1 Variables
		private BigInteger reg1NumberDigitsLeft = BigInteger.ZERO;
		private BigInteger reg1NumberDigitsRight = BigInteger.ZERO;
		private BigInteger reg1ReadSeq = BigInteger.ZERO;
		private UnitOfMeasure_Id reg1UomId = null;
		private TimeOfUse_Id reg1TouId = null;
		private BigDecimal reg1RegConst = BigDecimal.ZERO;
		private ConsumptionTypeLookup reg1ConsType = null;
		private HowToUseLookup reg1HowToUse = null;
		private BigDecimal reg1FullScale = BigDecimal.ZERO;
		private ReadOutType_Id reg1ReadOutTypeId = null;
		private Protocol_Id reg1ProtocolId = null;
		private BigDecimal reg1Tolerance = BigDecimal.ZERO;
		private String reg1VirtualChannelStr = BLANK_VALUE;
		private IntervalRegisterType_Id reg1IntRegisterTypeId = null;
		
		// Register 2 Variables
		private BigInteger reg2NumberDigitsLeft = BigInteger.ZERO;
		private BigInteger reg2NumberDigitsRight = BigInteger.ZERO;
		private BigInteger reg2ReadSeq = BigInteger.ZERO;
		private UnitOfMeasure_Id reg2UomId = null;
		private TimeOfUse_Id reg2TouId = null;
		private BigDecimal reg2RegConst = BigDecimal.ZERO;
		private ConsumptionTypeLookup reg2ConsType = null;
		private HowToUseLookup reg2HowToUse = null;
		private BigDecimal reg2FullScale = BigDecimal.ZERO;
		private ReadOutType_Id reg2ReadOutTypeId = null;
		private Protocol_Id reg2ProtocolId = null;
		private BigDecimal reg2Tolerance = BigDecimal.ZERO;
		private String reg2VirtualChannelStr = BLANK_VALUE;
		private IntervalRegisterType_Id reg2IntRegisterTypeId = null;
		
		// Meter Characteristics
		private List<CmCharacteristicTempData> meterCharList = new ArrayList<CmCharacteristicTempData>();
		
        // START DELETE - JHERNA - 2016-03-10 - SysAid#68431
        // Not used anymore.
        // 2015-05-26. SMiran. Defect 3223676. Start Add
        //private String meterSiteNumber = "";
        // 2015-05-26. SMiran. Defect 3223676. End Add
        // END DELETE - JHERNA - 2016-03-10 - SysAid#68431
		
		// Item Variables
		private String itemBadgeNumber = BLANK_VALUE;		
		private ItemType_Id itemTypeId = null;
		private ItemStatusLookup itemStatus = null;
		private Manufacturer_Id itemManufacturerId = null;
		private Model_Id itemModelId = null;
		private String itemSerialNumber = BLANK_VALUE;
		private RetireReason_Id itemRetireReasonId = null;
		private String itemParentMeterSerialNumber = "";
		private String itemLongDescription = BLANK_VALUE;
		private Date itemReceiveDate = null;
		private Date itemRetireDate = null;
		private ServicePoint_Id itemParentSpId = null;
		// 2015-06-17. SMiran. Defect 3236052. Start Add
		private String itemSiteNumber = "";
		// 2015-06-17. SMiran. Defect 3236052. End Add
		
		// Item Characteristics
		private List<CmCharacteristicTempData> itemCharList = new ArrayList<CmCharacteristicTempData>();
		
		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
			
			// Get soft parameters
			parmServiceTaskType = this.getParameters().getSERVICE_TASK_TYPE();
			
			// Get BO elements
			BusinessObject serviceTaskTypeBo = parmServiceTaskType.getBusinessObject();
			BusinessObjectInstance serviceTaskType = BusinessObjectInstance.create(serviceTaskTypeBo);
			serviceTaskType.set("serviceTaskType", parmServiceTaskType.getId().getTrimmedValue()); 
			serviceTaskType = BusinessObjectDispatcher.read(serviceTaskType);	
			
			// Source System Name
			parmSourceSystemName = serviceTaskType.getString("sourceSystem");
			// Target System Name
			parmTargetSystemName = serviceTaskType.getString("targetSystem");
			// Regulator Item Type
			parmRegulatorItemType = new ItemType_Id(serviceTaskType.getGroup("stagingInterfaceDetails").getString("regulatorItemType")).getEntity();
			
			// 2015-05-26. SMiran. Defect 3223676. Start Add
			parmMeterSiteCharType = new CharacteristicType_Id(serviceTaskType.getGroup("stagingInterfaceDetails")
					.getString("meterSiteCharType")).getEntity();
			// 2015-05-26. SMiran. Defect 3223676. End Add
			
			// Start Change DLampa - E-13304 - 2026-08-07
	        // Start Add JVitug - B-13084 - 2020-07-07
            //defaultSecondRegisterMeterConfigType = new MeterConfigurationType_Id(serviceTaskType.getGroup("stagingInterfaceDetails")
            //        .getString("meterConfigTypeToDefaultReg")).getEntity();
            // End Add JVitug - B-13084 - 2020-07-07
            COTSInstanceList meterConfigTypeList = serviceTaskType.getGroup("stagingInterfaceDetails").getList("meterConfigTypeToDefaultReg");
            Iterator<COTSInstanceListNode> meterConfigTypeListIter = meterConfigTypeList.iterator();            
            COTSInstanceListNode cotsInstanceListNode;
            
            while (meterConfigTypeListIter.hasNext()) {
                cotsInstanceListNode = meterConfigTypeListIter.next();            
                MeterConfigurationType meterConfigType = new MeterConfigurationType_Id(cotsInstanceListNode.getString("meterConfigType")).getEntity();
                defaultSecondRegisterMeterConfigType.add(meterConfigType);
            }   
            // End Change DLampa - E-13304 - 2026-08-07
			
			// 2015-06-18. SMiran. Defect 3236175. Start Add
			maxErrors = this.getParameters().getSoftMaxErrors().intValue();
			// 2015-06-18. SMiran. Defect 3236175. End Add
			
		}

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new CommitEveryUnitStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			// Get Staging Key
			stagingKey = (CmInboundInterfaceStaging_Id) unit.getPrimaryId();			
			// Get Logical Transaction Number
			logicalTransactionNumber = unit.getSupplementallData("logicalTransactionNumber").toString();
			
			// 2015-07-09. SMiran. Defect 3249308. Start Add
			meterDataList = new ArrayList<CmMeterData>();
			itemDataList = new ArrayList<CmItemData>();
			// 2015-07-09. SMiran. Defect 3249308. End Add
			
			try{
				// Search record from FA completion table
				getFaCompRecord();
				// Validate inbound FA completion details	
				validateInboundData();
				// Set Main table
				originationTable = XXL_INT_FA_IN_STG;
				// 2015-05-26. SMiran. Defect 3223676. Start Change
				//// Process Items
				//processItems();
				// Process Meters
				processMeters();
				// Process Items
				processItems();
				// 2015-05-26. SMiran. Defect 3223676. End Change
				// Once all item and meter updates are completed, process the step by step field activity completion
				processFA();
				// 2015-07-06. SMiran. Defect 3233441. Start Add
				retireMeters();
				// 2015-07-06. SMiran. Defect 3233441. End Add
			}catch(ApplicationError e){
				addError(CustomMessageRepositoryMGE.cint01810ErrorMessage(stagingKey.getStagingKey()
						, logicalTransactionNumber, e.getServerMessage().getMessageText()));
			}
			
			// Update Inbound Staging record to Complete
			updateInboundInterfaceStagingStatus(
					stagingKey.getStagingKey().trim()
					, CmInterfaceStatusLookup.constants.COMPLETE
					, this.getProcessDateTime());
			
			return true;
		}

		private void initializeFAWorkVariables() {
	
			// FA Variables
			faId = null;
			spId = null;
			workDateTime = null;
			workedById = null;
			faComments = null;
			// Found Fields
			badgeNumberFound = BLANK_VALUE;
			manufacturerIdFound = null;
			useOnBillFound = null;
			meterReadSourceFound = null;
			// Found Register 1
			reg1SeqFound = BigInteger.ZERO;
			reg1ReadTypeFound = null;
			reg1ReadingFound = null;
			reg1ReviewHiLoFound = null;
			// Found Register 2
			reg2SeqFound = BigInteger.ZERO;
			reg2ReadTypeFound = null;
			reg2ReadingFound = null;
			reg2ReviewHiLoFound = null;
			// Left Fields
			badgeNumberLeft = BLANK_VALUE;
			manufacturerIdLeft = null;
			useOnBillLeft = null;
			meterReadSourceLeft = null;
			// Left Register 1
			reg1SeqLeft = BigInteger.ZERO;
			reg1ReadTypeLeft = null;
			reg1ReadingLeft = null;
			reg1ReviewHiLoLeft = null;
			// Left Register 2
			reg2SeqLeft = BigInteger.ZERO;
			reg2ReadTypeLeft = null;
			reg2ReadingLeft = null;
			reg2ReviewHiLoLeft = null;		
			// 2015-06-18. SMiran. Defect 3236175. Start Add
			serialNumberFound = BLANK_VALUE;
			serialNumberLeft = BLANK_VALUE;
			siteNumber = BLANK_VALUE;
			// 2015-06-18. SMiran. Defect 3236175. End Add
			// FA Characteristics
			faCharList = new ArrayList<CmCharacteristicTempData>();
			
			// 2015-05-26. SMiran. Defect 3198933. Start Add
			meterConfigIdFound = null;
			meterConfigIdLeft = null;
			// 2015-05-26. SMiran. Defect 3198933. End Add
		}
		
		private void initializeMeterWorkVariables(){
			
			// Meter Variables
			meterBadgeNumber = BLANK_VALUE;		
			meterTypeId = null;
			meterStatus = null;
			meterSerialNumber = BLANK_VALUE;
			meterManufacturerId = null;
			meterModelId = null;
			meterRetireReasonId = null;
			meterLongDescription = BLANK_VALUE;
			meterReceiveDate = null;
			meterRetireDate = null;
			
			// Meter Configuration Variables
			meterConfigEffectiveDateTime = null;
			meterConfigTypeId = null;
			
			// Register 1 Variables
			reg1NumberDigitsLeft = BigInteger.ZERO;
			reg1NumberDigitsRight = BigInteger.ZERO;
			reg1ReadSeq = BigInteger.ZERO;
			reg1UomId = null;
			reg1TouId = null;
			reg1RegConst = BigDecimal.ZERO;
			reg1ConsType = null;
			reg1HowToUse = null;
			reg1FullScale = BigDecimal.ZERO;
			reg1ReadOutTypeId = null;
			reg1ProtocolId = null;
			reg1Tolerance = BigDecimal.ZERO;
			reg1VirtualChannelStr = BLANK_VALUE;
			reg1IntRegisterTypeId = null;
			
			// Register 2 Variables
			reg2NumberDigitsLeft = BigInteger.ZERO;
			reg2NumberDigitsRight = BigInteger.ZERO;
			reg2ReadSeq = BigInteger.ZERO;
			reg2UomId = null;
			reg2TouId = null;
			reg2RegConst = BigDecimal.ZERO;
			reg2ConsType = null;
			reg2HowToUse = null;
			reg2FullScale = BigDecimal.ZERO;
			reg2ReadOutTypeId = null;
			reg2ProtocolId = null;
			reg2Tolerance = BigDecimal.ZERO;
			reg2VirtualChannelStr = BLANK_VALUE;
			reg2IntRegisterTypeId = null;
			
			// Meter Characteristics
			meterCharList = new ArrayList<CmCharacteristicTempData>();
			
            // START DELETE - JHERNA - 2016-03-10 - SysAid#68431
            // Not used anymore
            // 2015-05-26. SMiran. Defect 3223676. Start Add
            //meterSiteNumber = "";
            // 2015-05-26. SMiran. Defect 3223676. End Add
            // END DELETE - JHERNA - 2016-03-10 - SysAid#68431
			
		}
		
		private void initializeItemWorkVariables(){
			
			// Item Variables
			itemBadgeNumber = BLANK_VALUE;		
			itemTypeId = null;
			itemStatus = null;
			itemManufacturerId = null;
			itemModelId = null;
			itemSerialNumber = BLANK_VALUE;
			itemRetireReasonId = null;
			itemParentMeterSerialNumber = "";
			itemLongDescription = BLANK_VALUE;
			itemReceiveDate = null;
			itemRetireDate = null;
			itemParentSpId = null;
			
			// 2015-06-17. SMiran. Defect 3236052. Start Add
			itemSiteNumber = "";
			// 2015-06-17. SMiran. Defect 3236052. End Add
			
			// Item Characteristics
			itemCharList = new ArrayList<CmCharacteristicTempData>();
		}

		private void getFaCompRecord() {
			
			originationTable = XXL_INT_FA_IN_STG;

			// Get record from FA Completion Inbound Staging Table
			StringBuilder getFaQueryStr = new StringBuilder();
			getFaQueryStr.append(" SELECT ");
			getFaQueryStr.append(" 	FA_ID ");
			getFaQueryStr.append(" 	,WORK_DTTM ");
			getFaQueryStr.append(" 	,NVL(WORKED_BY,' ') WORKED_BY ");
			getFaQueryStr.append(" 	,NVL(COMMENTS,' ') COMMENTS ");
			getFaQueryStr.append(" 	,NVL(BADGE_NBR_FOUND,' ') BADGE_NBR_FOUND ");
			getFaQueryStr.append(" 	,NVL(MTR_MFG_FOUND,' ') MTR_MFG_FOUND ");
			getFaQueryStr.append(" 	,NVL(USE_ON_BILL_FOUND,' ') USE_ON_BILL_FOUND ");
			getFaQueryStr.append(" 	,NVL(MR_SOURCE_FOUND,' ') MR_SOURCE_FOUND ");
			getFaQueryStr.append(" 	,NVL(REG1_SEQ_FOUND,0) REG1_SEQ_FOUND ");
			getFaQueryStr.append(" 	,NVL(REG1_READ_TYPE_FOUND,' ') REG1_READ_TYPE_FOUND ");
			getFaQueryStr.append(" 	,REG1_READING_FOUND ");
			getFaQueryStr.append(" 	,NVL(REG1_RVW_HILO_FOUND,' ') REG1_RVW_HILO_FOUND ");
			getFaQueryStr.append(" 	,NVL(REG2_SEQ_FOUND,0) REG2_SEQ_FOUND ");
			getFaQueryStr.append(" 	,NVL(REG2_READ_TYPE_FOUND,' ') REG2_READ_TYPE_FOUND ");
			getFaQueryStr.append(" 	,REG2_READING_FOUND ");
			getFaQueryStr.append(" 	,NVL(REG2_RVW_HILO_FOUND,' ') REG2_RVW_HILO_FOUND ");
			getFaQueryStr.append(" 	,NVL(BADGE_NBR_LEFT,' ') BADGE_NBR_LEFT ");
			getFaQueryStr.append(" 	,NVL(MTR_MFG_LEFT,' ') MTR_MFG_LEFT ");
			getFaQueryStr.append(" 	,NVL(USE_ON_BILL_LEFT,' ') USE_ON_BILL_LEFT ");
			getFaQueryStr.append(" 	,NVL(MR_SOURCE_LEFT,' ') MR_SOURCE_LEFT ");
			getFaQueryStr.append(" 	,NVL(REG1_SEQ_LEFT,0) REG1_SEQ_LEFT ");
			getFaQueryStr.append(" 	,NVL(REG1_READ_TYPE_LEFT,' ') REG1_READ_TYPE_LEFT ");
			getFaQueryStr.append(" 	,REG1_READING_LEFT ");
			getFaQueryStr.append(" 	,NVL(REG1_RVW_HILO_LEFT,' ') REG1_RVW_HILO_LEFT ");
			getFaQueryStr.append(" 	,NVL(REG2_SEQ_LEFT,0) REG2_SEQ_LEFT ");
			getFaQueryStr.append(" 	,NVL(REG2_READ_TYPE_LEFT,' ') REG2_READ_TYPE_LEFT ");
			getFaQueryStr.append(" 	,REG2_READING_LEFT ");
			getFaQueryStr.append(" 	,NVL(REG2_RVW_HILO_LEFT,' ') REG2_RVW_HILO_LEFT ");
			getFaQueryStr.append(" 	,SP_ID ");
			// 2015-06-18. SMiran. Defect 3236175. Start Add
			getFaQueryStr.append(" 	,NVL(SERIAL_NBR_FOUND,' ') SERIAL_NBR_FOUND ");
			getFaQueryStr.append(" 	,NVL(SERIAL_NBR_LEFT,' ') SERIAL_NBR_LEFT ");
			getFaQueryStr.append(" 	,NVL(SITEID,' ') SITEID ");
			// 2015-06-18. SMiran. Defect 3236175. End Add			
			getFaQueryStr.append(" FROM ");
			getFaQueryStr.append(" 	XXL_INT_FA_IN_STG ");
			getFaQueryStr.append(" WHERE ");
			getFaQueryStr.append("   LOGICAL_TRX_NUMBER = :logicalTransactionNumber ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement faPrepStmt = createPreparedStatement(getFaQueryStr.toString());
			PreparedStatement faPrepStmt = createPreparedStatement(getFaQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			faPrepStmt.bindString("logicalTransactionNumber", logicalTransactionNumber, "LOGICAL_TRX_NUMBER");
			
			List<SQLResultRow> faStagingList = faPrepStmt.list();			
			faPrepStmt.close();
			
			if (faStagingList.size() == 0){
				// Raise error if no FA staging record found
				addError(CustomMessageRepositoryMGE.cint01810noFaStgRec(originationTable));
			}else if (faStagingList.size() == 1){
				// If exactly one FA Staging record found for Logical Transaction Number
				faCompRow = faStagingList.get(0);
			}
			
		}
		
		private void validateInboundData() {

			// Validate FA Staging Table (XXL_INT_FA_IN_STG)
			validateInboundFa();
			
			// Validate FA Char Staging Table (XXL_INT_FA_CHAR_IN_STG)
			validateInboundFaChar();
			
			// Validate FA Meter Staging Table (XXL_INT_FA_MTR_IN_STG)
			validateInboundFaMeter();
			
			// Validate FA Item Staging Table (XXL_INT_FA_ITEM_IN_STG)
			validateInboundFaItem();
			
		}

		private void validateInboundFa() {
			
			initializeFAWorkVariables();
			
			// FA_ID
			String faIdStr = faCompRow.getString("FA_ID").trim();
			if (isEmptyOrNull(faIdStr)){
				// FA ID must be supplied
				addError(CustomMessageRepositoryMGE.cint01810tblFldMiss(originationTable, "FA_ID"));
			}else{
				// FA ID must be valid
				faId = new FieldActivity_Id(faIdStr);
				if (isNull(faId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "FA_ID", faIdStr));
				}
				// FA must be in pending status
				if (!faId.getEntity().getFieldActivityStatus().isPending()){
					addError(CustomMessageRepositoryMGE.cint01810faNotPending(originationTable, faIdStr));
				}
			}
			// Store the Field Activity Type
			faType = faId.getEntity().getFieldActivityType();
			
			// WORK_DTTM
			workDateTime = faCompRow.getDateTime("WORK_DTTM");
			if (isNull(workDateTime)){
				addError(CustomMessageRepositoryMGE.cint01810tblFldMiss(originationTable, "WORK_DTTM"));
			}
			
			// WORKED_BY
			String workedByStr = faCompRow.getString("WORKED_BY").trim();
			if (!isEmptyOrNull(workedByStr)){
				// If supplied, Worked By must be valid
				workedById = new Representative_Id(workedByStr);
				if (isNull(workedById.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "WORKED_BY", workedByStr));
				}
			}
			
			// COMMENTS
			faComments = faCompRow.getString("COMMENTS");
			
			// BADGE_NBR_FOUND
			badgeNumberFound = faCompRow.getString("BADGE_NBR_FOUND").trim();
			
			if (!isEmptyOrNull(badgeNumberFound)){
				// If BADGE_NBR_FOUND is supplied, validate "FOUND" fields
				validateFoundFields();
			}
			
			// BADGE_NBR_LEFT
			badgeNumberLeft = faCompRow.getString("BADGE_NBR_LEFT").trim();
			
			if (!isEmptyOrNull(badgeNumberLeft)){
				// Validate "LEFT" fields
				validateLeftFields();
			}
			
			// 2015-06-18. SMiran. Defect 3236175. Start Add
			siteNumber = faCompRow.getString("SITEID");
			if (isEmptyOrNull(siteNumber)){
				addError(CustomMessageRepositoryMGE.cint01810tblFldMiss(originationTable, "SITEID"));
			}
			// 2015-06-18. SMiran. Defect 3236175. End Add
			
			// SP_ID
			String spIdStr = faCompRow.getString("SP_ID").trim();
			if (isEmptyOrNull(spIdStr)){
				addError(CustomMessageRepositoryMGE.cint01810tblFldMiss(originationTable, "SP_ID"));
			}else{
				spId = new ServicePoint_Id(spIdStr);
				if (isNull(spId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "SP_ID", spIdStr));
				}
			}
			
			// SP ID must be the same as the FA's SP ID
			if (!spId.equals(faId.getEntity().getServicePoint().getId())){
				addError(CustomMessageRepositoryMGE.cint01810spNotFaSp(originationTable, spId.getIdValue()));
			}
			
			// If FA's FA type has a required Read Meter or Remove Meter step, the "as found" badge number and reading must not be null
			BigInteger readRemoveMeterCount = countRequiredReadRemove();
			if (readRemoveMeterCount.intValue() > 0){
				if (isEmptyOrNull(badgeNumberFound) || isNull(reg1ReadingFound)){
					addError(CustomMessageRepositoryMGE.cint01810bdgNbrRdgFoundMiss(originationTable, "BADGE_NBR_FOUND", "REG1_READING_FOUND"));
				}
			}
			
			// If FA's FA type has a required Install Meter step, the "as left" badge number and reading must not be null
			BigInteger installMeterCount = countRequiredInstall();
			if (installMeterCount.intValue() > 0){
				if (isEmptyOrNull(badgeNumberLeft) || isNull(reg1ReadingLeft)){
					addError(CustomMessageRepositoryMGE.cint01810bdgNbrRdgLeftMiss(originationTable, "BADGE_NBR_LEFT", "REG1_READING_LEFT"));
				}
			}
			
			// If FA's FA type has optional Remove and Install Meter steps, "as found" badge number must be supplied if "as left" badge number is supplied
			BigInteger optionalRmImCount = countOptionalRmIm();
			if (optionalRmImCount.intValue() == 2){
				if (!isEmptyOrNull(badgeNumberLeft)){
					if (isEmptyOrNull(badgeNumberFound)){
						addError(CustomMessageRepositoryMGE.cint01810bdgNbrFoundMiss(originationTable, "BADGE_NBR_FOUND", "BADGE_NBR_LEFT"));
					}
				}
			}
		}

		private BigInteger countRequiredReadRemove() {

			StringBuilder countRMMRQueryStr = new StringBuilder();
			countRMMRQueryStr.append(" SELECT ");
			countRMMRQueryStr.append(" 	COUNT(FST.FA_TYPE_CD) MRRMCNT ");
			countRMMRQueryStr.append(" FROM ");
			countRMMRQueryStr.append(" 	CI_FA_STEP_TYPE FST ");
			countRMMRQueryStr.append(" WHERE ");
			countRMMRQueryStr.append("   FST.FA_TYPE_CD = :faTypeCd ");
			countRMMRQueryStr.append("   AND FST.FA_STEP_TY_ACT_FLG IN (:readMeter,:removeMeter) ");
			countRMMRQueryStr.append("   AND FST.OPTIONAL_SW <> 'Y' ");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement countRMMRPrepStmt = createPreparedStatement(countRMMRQueryStr.toString());
			PreparedStatement countRMMRPrepStmt = createPreparedStatement(countRMMRQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			countRMMRPrepStmt.bindId("faTypeCd", faType.getId());
			countRMMRPrepStmt.bindLookup("readMeter", FieldActivityStepTypeActionLookup.constants.READ_METER);
			countRMMRPrepStmt.bindLookup("removeMeter", FieldActivityStepTypeActionLookup.constants.REMOVE_METER);
			SQLResultRow stepCountRow = countRMMRPrepStmt.firstRow();			
			countRMMRPrepStmt.close();
			return stepCountRow.getInteger("MRRMCNT");
			
		}		

		private BigInteger countRequiredInstall() {

			StringBuilder countIMQueryStr = new StringBuilder();
			countIMQueryStr.append(" SELECT ");
			countIMQueryStr.append(" 	COUNT(FST.FA_TYPE_CD) IMCNT ");
			countIMQueryStr.append(" FROM ");
			countIMQueryStr.append(" 	CI_FA_STEP_TYPE FST ");
			countIMQueryStr.append(" WHERE ");
			countIMQueryStr.append("   FST.FA_TYPE_CD = :faTypeCd ");
			countIMQueryStr.append("   AND FST.FA_STEP_TY_ACT_FLG = :installMeter ");
			countIMQueryStr.append("   AND FST.OPTIONAL_SW <> 'Y' ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement countIMPrepStmt = createPreparedStatement(countIMQueryStr.toString());
			PreparedStatement countIMPrepStmt = createPreparedStatement(countIMQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			countIMPrepStmt.bindId("faTypeCd", faType.getId());
			countIMPrepStmt.bindLookup("installMeter", FieldActivityStepTypeActionLookup.constants.INSTALL_METER);
			SQLResultRow stepCountRow = countIMPrepStmt.firstRow();			
			countIMPrepStmt.close();
			return stepCountRow.getInteger("IMCNT");
			
		}
		
		private BigInteger countOptionalRmIm() {

			StringBuilder countOptRmImQueryStr = new StringBuilder();
			countOptRmImQueryStr.append(" SELECT ");
			countOptRmImQueryStr.append(" 	COUNT(FST.FA_TYPE_CD) OPRMIMCNT ");
			countOptRmImQueryStr.append(" FROM ");
			countOptRmImQueryStr.append(" 	CI_FA_STEP_TYPE FST ");
			countOptRmImQueryStr.append(" WHERE ");
			countOptRmImQueryStr.append("   FST.FA_TYPE_CD = :faTypeCd ");
			countOptRmImQueryStr.append("   AND FST.FA_STEP_TY_ACT_FLG IN (:removeMeter,:installMeter) ");
			countOptRmImQueryStr.append("   AND FST.OPTIONAL_SW = 'Y' ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement countOptRmImPrepStmt = createPreparedStatement(countOptRmImQueryStr.toString());
			PreparedStatement countOptRmImPrepStmt = createPreparedStatement(countOptRmImQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			countOptRmImPrepStmt.bindId("faTypeCd", faType.getId());
			countOptRmImPrepStmt.bindLookup("removeMeter", FieldActivityStepTypeActionLookup.constants.REMOVE_METER);
			countOptRmImPrepStmt.bindLookup("installMeter", FieldActivityStepTypeActionLookup.constants.INSTALL_METER);
			SQLResultRow stepCountRow = countOptRmImPrepStmt.firstRow();			
			countOptRmImPrepStmt.close();
			return stepCountRow.getInteger("OPRMIMCNT");
			
		}

		private void validateFoundFields() {
			
			// Method variables
			LookupField_Id lookupFieldId;
			LookupValue_Id lookupValueId;

			// MTR_MFG_FOUND
			String meterMfgFoundStr = faCompRow.getString("MTR_MFG_FOUND").trim();
			if (isEmptyOrNull(meterMfgFoundStr)){
				addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "BADGE_NBR_FOUND", "MTR_MFG_FOUND"));
			}else{
				manufacturerIdFound = new Manufacturer_Id(meterMfgFoundStr);
				if (isNull(manufacturerIdFound.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "MTR_MFG_FOUND", meterMfgFoundStr));
				}
			}
			
			// 2015-08-04. SMiran. Defect 3266831. Start Delete
			//// If BADGE_NBR_FOUND is populated, the badge number must be the same as the meter currently installed on the service point.  
			//// The manufacturer code must also match (badge number and manufacturer combine to uniquely identify a meter).
			//spMeterHistFound = getSpMeterHistory(badgeNumberFound,manufacturerIdFound);
			
			//if(isNull(spMeterHistFound)){
			//	// Add Error - The Badge Number and Manufacturer code must be the same as the meter currently installed on the SP.
			//	addError(CustomMessageRepositoryMGE.cint01810badgeNbrMfgFoundInv(
			//			originationTable
			//			,"BADGE_NBR_FOUND"
			//			, badgeNumberFound
			//			,"MTR_MFG_FOUND"
			//			, meterMfgFoundStr));
			//}
														
			// USE_ON_BILL_FOUND
			String useOnBillFoundStr = faCompRow.getString("USE_ON_BILL_FOUND").trim();
			if (isEmptyOrNull(useOnBillFoundStr)){
				addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "BADGE_NBR_FOUND", "USE_ON_BILL_FOUND"));
			}else{
				lookupFieldId = new LookupField_Id("F1_YESNO_FLG");
				lookupValueId = new LookupValue_Id(lookupFieldId, useOnBillFoundStr);					
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "USE_ON_BILL_FOUND", useOnBillFoundStr));
				}else{
					useOnBillFound = (YesNoOptionLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}					
			}
			
			// MR_SOURCE_FOUND
			String mrSourceFoundStr = faCompRow.getString("MR_SOURCE_FOUND").trim();
			if (!isEmptyOrNull(mrSourceFoundStr)){
				meterReadSourceFound = new MeterReadSource_Id(mrSourceFoundStr);
				if (isNull(meterReadSourceFound.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "MR_SOURCE_FOUND", mrSourceFoundStr));
				}
			}			
			
			// REG1_SEQ_FOUND
			reg1SeqFound = faCompRow.getInteger("REG1_SEQ_FOUND");
			if (reg1SeqFound.intValue() == 0){
				addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "BADGE_NBR_FOUND", "REG1_SEQ_FOUND"));
			}else{
				// REG1_SEQ_FOUND must be equal to 1
				if (reg1SeqFound.intValue() != 1){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "REG1_SEQ_FOUND", reg1SeqFound.toString()));
				}
			}
			
			// REG1_READ_TYPE_FOUND
			String reg1ReadTypeFoundStr = faCompRow.getString("REG1_READ_TYPE_FOUND").trim();
			if (isEmptyOrNull(reg1ReadTypeFoundStr)){
				addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "BADGE_NBR_FOUND", "REG1_READ_TYPE_FOUND"));
			}else{
				lookupFieldId = new LookupField_Id("READ_TYPE_FLG");
				lookupValueId = new LookupValue_Id(lookupFieldId, reg1ReadTypeFoundStr);					
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "REG1_READ_TYPE_FOUND", reg1ReadTypeFoundStr));
				}else{
					reg1ReadTypeFound = (ReadTypeLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
			}
			
			// REG1_READING_FOUND
			reg1ReadingFound = faCompRow.getBigDecimal("REG1_READING_FOUND");
			if (isNull(reg1ReadingFound)){
				addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "BADGE_NBR_FOUND", "REG1_READING_FOUND"));
			}else{
				reg1ReadingFound = reg1ReadingFound.setScale(6);
			}
						
			// REG1_RVW_HILO_FOUND
			String reg1RvwHiloFoundStr = faCompRow.getString("REG1_RVW_HILO_FOUND").trim();
			if (isEmptyOrNull(reg1RvwHiloFoundStr)){
				addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "BADGE_NBR_FOUND", "REG1_RVW_HILO_FOUND"));
			}else{
				lookupFieldId = new LookupField_Id("F1_YESNO_FLG");
				lookupValueId = new LookupValue_Id(lookupFieldId, reg1RvwHiloFoundStr);					
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "REG1_RVW_HILO_FOUND", reg1RvwHiloFoundStr));
				}else{
					reg1ReviewHiLoFound = (YesNoOptionLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
			}
			
			// REG2_SEQ_FOUND
			reg2SeqFound = faCompRow.getInteger("REG2_SEQ_FOUND");
			if (reg2SeqFound.intValue() != 0){				
				
				// REG2_SEQ_FOUND must be equal to 2
				if (reg2SeqFound.intValue() != 2){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "REG2_SEQ_FOUND", reg2SeqFound.toString()));
				}
				
				// REG2_READ_TYPE_FOUND
				String reg2ReadTypeFoundStr = faCompRow.getString("REG2_READ_TYPE_FOUND").trim();
				if (isEmptyOrNull(reg2ReadTypeFoundStr)){
					addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "REG2_SEQ_FOUND", "REG2_READ_TYPE_FOUND"));
				}else{
					lookupFieldId = new LookupField_Id("READ_TYPE_FLG");
					lookupValueId = new LookupValue_Id(lookupFieldId, reg2ReadTypeFoundStr);					
					if(isNull(lookupValueId.getEntity())){
						addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "REG2_READ_TYPE_FOUND", reg2ReadTypeFoundStr));
					}else{
						reg2ReadTypeFound = (ReadTypeLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
					}
				}

				// REG2_READING_FOUND
				reg2ReadingFound = faCompRow.getBigDecimal("REG2_READING_FOUND");
				if (isNull(reg2ReadingFound)){
					addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "REG2_SEQ_FOUND", "REG2_READING_FOUND"));
				}else{
					reg2ReadingFound = reg2ReadingFound.setScale(6);
				}
				
				
				// REG2_RVW_HILO_FOUND
				String reg2RvwHiloFoundStr = faCompRow.getString("REG2_RVW_HILO_FOUND").trim();
				if (isEmptyOrNull(reg2RvwHiloFoundStr)){
					addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "REG2_SEQ_FOUND", "REG2_RVW_HILO_FOUND"));
				}else{
					lookupFieldId = new LookupField_Id("F1_YESNO_FLG");
					lookupValueId = new LookupValue_Id(lookupFieldId, reg2RvwHiloFoundStr);					
					if(isNull(lookupValueId.getEntity())){
						addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "REG2_RVW_HILO_FOUND", reg2RvwHiloFoundStr));
					}else{
						reg2ReviewHiLoFound = (YesNoOptionLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
					}
				}
			}
			
			// 2015-06-18. SMiran. Defect 3236175. Start Add
			serialNumberFound = faCompRow.getString("SERIAL_NBR_FOUND").trim();
			if (isEmptyOrNull(serialNumberFound)){
				addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "BADGE_NBR_FOUND", "SERIAL_NBR_FOUND"));
			}
			// 2015-06-18. SMiran. Defect 3236175. End Add
			
		}
		
		private void validateLeftFields() {
			
			// Method variables
			LookupField_Id lookupFieldId;
			LookupValue_Id lookupValueId;

			// MTR_MFG_LEFT
			String meterMfgLeftStr = faCompRow.getString("MTR_MFG_LEFT").trim();
			if (isEmptyOrNull(meterMfgLeftStr)){
				// Add Error - Manufacturer left must be supplied if Badge Number Left is supplied
				addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "BADGE_NBR_LEFT", "MTR_MFG_LEFT"));
			}else{
				manufacturerIdLeft = new Manufacturer_Id(meterMfgLeftStr);
				if (isNull(manufacturerIdLeft.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "MTR_MFG_LEFT", meterMfgLeftStr));
				}
			}
														
			// USE_ON_BILL_LEFT
			String useOnBillLeftStr = faCompRow.getString("USE_ON_BILL_LEFT").trim();
			if (isEmptyOrNull(useOnBillLeftStr)){
				addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "BADGE_NBR_LEFT", "USE_ON_BILL_LEFT"));
			}else{
				lookupFieldId = new LookupField_Id("F1_YESNO_FLG");
				lookupValueId = new LookupValue_Id(lookupFieldId, useOnBillLeftStr);					
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "USE_ON_BILL_LEFT", useOnBillLeftStr));
				}else{
					useOnBillLeft = (YesNoOptionLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}					
			}
			
			// MR_SOURCE_LEFT
			String mrSourceLeftStr = faCompRow.getString("MR_SOURCE_LEFT").trim();
			if (!isEmptyOrNull(mrSourceLeftStr)){
				meterReadSourceLeft = new MeterReadSource_Id(mrSourceLeftStr);
				if (isNull(meterReadSourceLeft.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "MR_SOURCE_LEFT", mrSourceLeftStr));
				}
			}			
			
			// REG1_SEQ_LEFT
			reg1SeqLeft = faCompRow.getInteger("REG1_SEQ_LEFT");
			if (reg1SeqLeft.intValue() == 0){
				addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "BADGE_NBR_LEFT", "REG1_SEQ_LEFT"));
			}else{
				// REG1_SEQ_LEFT must be equal to 1
				if (reg1SeqLeft.intValue() != 1){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "REG1_SEQ_LEFT", reg1SeqLeft.toString()));
				}
			}
			
			// REG1_READ_TYPE_LEFT
			String reg1ReadTypeLeftStr = faCompRow.getString("REG1_READ_TYPE_LEFT").trim();
			if (isEmptyOrNull(reg1ReadTypeLeftStr)){
				addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "BADGE_NBR_LEFT", "REG1_READ_TYPE_LEFT"));
			}else{
				lookupFieldId = new LookupField_Id("READ_TYPE_FLG");
				lookupValueId = new LookupValue_Id(lookupFieldId, reg1ReadTypeLeftStr);					
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "REG1_READ_TYPE_LEFT", reg1ReadTypeLeftStr));
				}else{
					reg1ReadTypeLeft = (ReadTypeLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
			}
			
			// REG1_READING_LEFT
			reg1ReadingLeft = faCompRow.getBigDecimal("REG1_READING_LEFT");
			if (isNull(reg1ReadingLeft)){
				addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "BADGE_NBR_LEFT", "REG1_READING_LEFT"));
			}else{
				reg1ReadingLeft = reg1ReadingLeft.setScale(6);
			}
			
			
			// REG1_RVW_HILO_LEFT
			String reg1RvwHiloLeftStr = faCompRow.getString("REG1_RVW_HILO_LEFT").trim();
			if (isEmptyOrNull(reg1RvwHiloLeftStr)){
				addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "BADGE_NBR_LEFT", "REG1_RVW_HILO_LEFT"));
			}else{
				lookupFieldId = new LookupField_Id("F1_YESNO_FLG");
				lookupValueId = new LookupValue_Id(lookupFieldId, reg1RvwHiloLeftStr);					
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "REG1_RVW_HILO_LEFT", reg1RvwHiloLeftStr));
				}else{
					reg1ReviewHiLoLeft = (YesNoOptionLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
			}
			
			// REG2_SEQ_LEFT
			reg2SeqLeft = faCompRow.getInteger("REG2_SEQ_LEFT");
			if (reg2SeqLeft.intValue() != 0){				
				
				// REG2_SEQ_LEFT must be equal to 2
				if (reg2SeqLeft.intValue() != 2){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "REG2_SEQ_LEFT", reg2SeqLeft.toString()));
				}
				
				// REG2_READ_TYPE_LEFT
				String reg2ReadTypeLeftStr = faCompRow.getString("REG2_READ_TYPE_LEFT").trim();
				if (isEmptyOrNull(reg2ReadTypeLeftStr)){
					addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "REG2_SEQ_LEFT", "REG2_READ_TYPE_LEFT"));
				}else{
					lookupFieldId = new LookupField_Id("READ_TYPE_FLG");
					lookupValueId = new LookupValue_Id(lookupFieldId, reg2ReadTypeLeftStr);					
					if(isNull(lookupValueId.getEntity())){
						addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "REG2_READ_TYPE_LEFT", reg2ReadTypeLeftStr));
					}else{
						reg2ReadTypeLeft = (ReadTypeLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
					}
				}

				// REG2_READING_LEFT
				reg2ReadingLeft = faCompRow.getBigDecimal("REG2_READING_LEFT");
				if (isNull(reg2ReadingLeft)){
					addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "REG2_SEQ_LEFT", "REG2_READING_LEFT"));
				}else{
					reg2ReadingLeft = reg2ReadingLeft.setScale(6);
				}
				
				
				// REG2_RVW_HILO_LEFT
				String reg2RvwHiloLeftStr = faCompRow.getString("REG2_RVW_HILO_LEFT").trim();
				if (isEmptyOrNull(reg2RvwHiloLeftStr)){
					addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "REG2_SEQ_LEFT", "REG2_RVW_HILO_LEFT"));
				}else{
					lookupFieldId = new LookupField_Id("F1_YESNO_FLG");
					lookupValueId = new LookupValue_Id(lookupFieldId, reg2RvwHiloLeftStr);					
					if(isNull(lookupValueId.getEntity())){
						addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "REG2_RVW_HILO_LEFT", reg2RvwHiloLeftStr));
					}else{
						reg2ReviewHiLoLeft = (YesNoOptionLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
					}
				}
			}
			
			// 2015-06-18. SMiran. Defect 3236175. Start Add
			serialNumberLeft = faCompRow.getString("SERIAL_NBR_LEFT").trim();
			if (isEmptyOrNull(serialNumberLeft)){
				// 2015-08-14. SMiran. Defect 3272953. Start Change
				//addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "BADGE_NBR_FOUND", "SERIAL_NBR_LEFT"));
				addError(CustomMessageRepositoryMGE.cint01810fieldCombInv(originationTable, "BADGE_NBR_LEFT", "SERIAL_NBR_LEFT"));
				// 2015-08-14. SMiran. Defect 3272953. End Change
			}
			// 2015-06-18. SMiran. Defect 3236175. End Add

		}

		// 2015-08-04. SMiran. Defect 3266831. Start Change
		//private ServicePointMeterHistory getSpMeterHistory(String badgeNumber, Manufacturer_Id mfgCd) {
		private ServicePointMeterHistory getSpMeterHistory(String serialNumber) {
		// 2015-08-04. SMiran. Defect 3266831. End Change
			
			// Check if meter with supplied badge number and manufacturer is currently installed on the SP
			StringBuilder getCurrSpMtrHistQueryStr = new StringBuilder();
			getCurrSpMtrHistQueryStr.append(" SELECT ");
			getCurrSpMtrHistQueryStr.append(" 	SPMH.SP_MTR_HIST_ID ");
			getCurrSpMtrHistQueryStr.append(" FROM ");
			getCurrSpMtrHistQueryStr.append(" 	CI_MTR MTR ");
			getCurrSpMtrHistQueryStr.append(" 	,CI_MTR_CONFIG MCFG ");
			getCurrSpMtrHistQueryStr.append(" 	,CI_SP_MTR_HIST SPMH ");
			getCurrSpMtrHistQueryStr.append(" WHERE ");
			// 2015-08-04. SMiran. Defect 3266831. Start Change
			//getCurrSpMtrHistQueryStr.append("   MTR.BADGE_NBR = :badgeNumber ");
			getCurrSpMtrHistQueryStr.append("   MTR.SERIAL_NBR = :serialNumber ");
			// 2015-08-04. SMiran. Defect 3266831. End Change
			// 2015-08-04. SMiran. Defect 3266831. Start Delete
			//getCurrSpMtrHistQueryStr.append("   AND MTR.MFG_CD = :mfgCd ");
			// 2015-08-04. SMiran. Defect 3266831. End Delete
			getCurrSpMtrHistQueryStr.append("   AND MCFG.MTR_ID = MTR.MTR_ID ");
			getCurrSpMtrHistQueryStr.append("   AND SPMH.MTR_CONFIG_ID = MCFG.MTR_CONFIG_ID ");
			getCurrSpMtrHistQueryStr.append("   AND (SPMH.REMOVAL_DTTM IS NULL OR SPMH.REMOVAL_DTTM > :processDateTime) ");			
			// 2015-08-04. SMiran. Defect 3266831. Start Add
			getCurrSpMtrHistQueryStr.append("   AND SPMH.SP_ID = :spId ");
			// 2015-08-04. SMiran. Defect 3266831. End Add
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement currSpMtrHistPrepStmt = createPreparedStatement(getCurrSpMtrHistQueryStr.toString());
			PreparedStatement currSpMtrHistPrepStmt = createPreparedStatement(getCurrSpMtrHistQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			// 2015-08-04. SMiran. Defect 3266831. Start Change
			//currSpMtrHistPrepStmt.bindString("badgeNumber", badgeNumber, "BADGE_NBR");
			//currSpMtrHistPrepStmt.bindId("mfgCd", mfgCd);
			currSpMtrHistPrepStmt.bindString("serialNumber", serialNumber, "SERIAL_NBR");
			currSpMtrHistPrepStmt.bindId("spId", spId);
			// 2015-08-04. SMiran. Defect 3266831. End Change
			currSpMtrHistPrepStmt.bindDateTime("processDateTime", this.getProcessDateTime());
			SQLResultRow spMeterHistRow = currSpMtrHistPrepStmt.firstRow();
			currSpMtrHistPrepStmt.close();
			
			if (notNull(spMeterHistRow)){
				return ((ServicePointMeterHistory_Id)spMeterHistRow.getId("SP_MTR_HIST_ID", ServicePointMeterHistory.class)).getEntity();
			}
			// 2015-08-04. SMiran. Defect 3266831. Start Add
			else{
				addError(CustomMessageRepositoryMGE.cint01810spInstallNotFound(serialNumber, spId.getTrimmedValue()));
			}
			// 2015-08-04. SMiran. Defect 3266831. End Add
			
			return null;
		}

		private void validateInboundFaChar() {
			
			originationTable = XXL_INT_FA_CHAR_IN_STG;
			
			// Get record from FA Characteristic Inbound Staging Table
			StringBuilder getFaCharQueryStr = new StringBuilder();
			getFaCharQueryStr.append(" SELECT ");
			getFaCharQueryStr.append(" 	CHAR_TYPE ");
			getFaCharQueryStr.append(" 	,CHAR_VAL ");
			getFaCharQueryStr.append(" FROM ");
			getFaCharQueryStr.append(" 	XXL_INT_FA_CHAR_IN_STG ");
			getFaCharQueryStr.append(" WHERE ");
			getFaCharQueryStr.append("   LOGICAL_TRX_NUMBER = :logicalTransactionNumber ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement faCharPrepStmt = createPreparedStatement(getFaCharQueryStr.toString());
			PreparedStatement faCharPrepStmt = createPreparedStatement(getFaCharQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			faCharPrepStmt.bindString("logicalTransactionNumber", logicalTransactionNumber, "LOGICAL_TRX_NUMBER");
			List<SQLResultRow> faQueryList = faCharPrepStmt.list();
			faCharPrepStmt.close();
			
			Iterator<SQLResultRow> faCharQueryIter = faQueryList.iterator();
			while (faCharQueryIter.hasNext()){
				
				SQLResultRow faCharRow = faCharQueryIter.next();
				String charTypeStr = faCharRow.getString("CHAR_TYPE").trim();
				String charValStr = faCharRow.getString("CHAR_VAL").trim();
				
				// Characteristic Type must be supplied
				if (isEmptyOrNull(charTypeStr)){
					addError(CustomMessageRepositoryMGE.cint01810tblFldMiss(originationTable, "CHAR_TYPE"));
				}
				// Characteristic Type must be valid
				CharacteristicType_Id charTypeId = new CharacteristicType_Id(charTypeStr);
				if (isNull(charTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810tblFldInv(originationTable, "CHAR_TYPE", charTypeStr));
				}
				
				// Characteristic Type must be valid for FA Type
				FieldActivityTypeCharacteristicType_Id faTypeCharTypeId = new FieldActivityTypeCharacteristicType_Id(
						faId.getEntity().getFieldActivityType(),charTypeId.getEntity());
				if (isNull(faTypeCharTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810charTypeInv(originationTable, charTypeStr, "FA Type", faType.getId().getIdValue()));
				}
				
				// Characteristic Value must be supplied
				if (isEmptyOrNull(charValStr)){
					addError(CustomMessageRepositoryMGE.cint01810tblFldMiss(originationTable, "CHAR_VAL"));
				}
				
				// If Char Type is Predefined, Char Type and Char Value combination must be valid
				if (charTypeId.getEntity().getCharacteristicType().isPredefinedValue()){
					CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charTypeId, charValStr);
					if (isNull(charValueId.getEntity())){
						addError(CustomMessageRepositoryMGE.cint01810charValInv(originationTable, charValStr, charTypeStr));
					}
				}
					
				CmCharacteristicTempData faCharTempData = CmCharacteristicTempData.Factory.newInstance();
				faCharTempData.setCharacteristicType(charTypeId.getEntity());
				faCharTempData.setCharVal(charValStr);
				faCharList.add(faCharTempData);			
				
			}

		}

		private void validateInboundFaMeter() {
			
			originationTable = XXL_INT_FA_MTR_IN_STG;
			
			// Get record from Meter Inbound Staging Table
			StringBuilder getMeterQueryStr = new StringBuilder();
			getMeterQueryStr.append(" SELECT ");
			getMeterQueryStr.append(" 	BADGE_NBR ");
			getMeterQueryStr.append(" 	,MTR_TYPE ");
			getMeterQueryStr.append(" 	,MTR_STATUS ");
			getMeterQueryStr.append(" 	,MFG_CD ");
			getMeterQueryStr.append(" 	,MODEL_CD ");
			getMeterQueryStr.append(" 	,SERIAL_NBR ");
			getMeterQueryStr.append(" 	,RECEIVE_DATE ");
			getMeterQueryStr.append(" 	,RETIRE_DATE ");
			getMeterQueryStr.append(" 	,NVL(LONG_DESCR,' ') LONG_DESCR ");
			getMeterQueryStr.append(" 	,NVL(RETIRE_REASON,' ') RETIRE_REASON ");
			getMeterQueryStr.append(" 	,EFF_DTTM ");
			getMeterQueryStr.append(" 	,MTR_CONFIG_TYPE ");
			getMeterQueryStr.append(" 	,REG1_NBR_DGTS_LEFT ");
			getMeterQueryStr.append(" 	,NVL(REG1_NBR_DGTS_RIGHT,0) REG1_NBR_DGTS_RIGHT ");
			getMeterQueryStr.append(" 	,REG1_READ_SEQ ");
			getMeterQueryStr.append(" 	,REG1_UOM ");
			getMeterQueryStr.append(" 	,NVL(REG1_TOU,' ') REG1_TOU ");
			getMeterQueryStr.append(" 	,REG1_REG_CONST ");
			getMeterQueryStr.append(" 	,REG1_CONS_TYPE ");
			getMeterQueryStr.append(" 	,REG1_HOW_TO_USE ");
			getMeterQueryStr.append(" 	,NVL(REG1_FULL_SCALE,0) REG1_FULL_SCALE ");
			getMeterQueryStr.append(" 	,NVL(REG1_READ_OUT_TYPE,' ') REG1_READ_OUT_TYPE ");
			getMeterQueryStr.append(" 	,NVL(REG1_PROTOCOL,' ') REG1_PROTOCOL ");
			getMeterQueryStr.append(" 	,NVL(REG1_TOLERANCE,0) REG1_TOLERANCE ");
			getMeterQueryStr.append(" 	,NVL(REG1_VIRTUAL_CHANNEL,' ') REG1_VIRTUAL_CHANNEL ");
			getMeterQueryStr.append(" 	,NVL(REG1_INT_REGISTER,' ') REG1_INT_REGISTER ");
			getMeterQueryStr.append(" 	,NVL(REG2_NBR_DGTS_LEFT,0) REG2_NBR_DGTS_LEFT ");
			getMeterQueryStr.append(" 	,NVL(REG2_NBR_DGTS_RIGHT,0) REG2_NBR_DGTS_RIGHT ");
			getMeterQueryStr.append(" 	,NVL(REG2_READ_SEQ,0) REG2_READ_SEQ ");
			getMeterQueryStr.append(" 	,NVL(REG2_UOM,' ') REG2_UOM ");
			getMeterQueryStr.append(" 	,NVL(REG2_TOU,' ') REG2_TOU ");
			getMeterQueryStr.append(" 	,NVL(REG2_REG_CONST,0) REG2_REG_CONST ");
			getMeterQueryStr.append(" 	,NVL(REG2_CONS_TYPE,' ') REG2_CONS_TYPE ");
			getMeterQueryStr.append(" 	,NVL(REG2_HOW_TO_USE,' ') REG2_HOW_TO_USE ");
			getMeterQueryStr.append(" 	,NVL(REG2_FULL_SCALE,0) REG2_FULL_SCALE ");
			getMeterQueryStr.append(" 	,NVL(REG2_READ_OUT_TYPE,' ') REG2_READ_OUT_TYPE ");
			getMeterQueryStr.append(" 	,NVL(REG2_PROTOCOL,' ') REG2_PROTOCOL ");
			getMeterQueryStr.append(" 	,NVL(REG2_TOLERANCE,0) REG2_TOLERANCE ");
			getMeterQueryStr.append(" 	,NVL(REG2_VIRTUAL_CHANNEL,' ') REG2_VIRTUAL_CHANNEL ");
			getMeterQueryStr.append(" 	,NVL(REG2_INT_REGISTER,' ') REG2_INT_REGISTER ");
			getMeterQueryStr.append(" FROM ");
			getMeterQueryStr.append(" 	XXL_INT_FA_MTR_IN_STG ");
			getMeterQueryStr.append(" WHERE ");
			getMeterQueryStr.append("   LOGICAL_TRX_NUMBER = :logicalTransactionNumber ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement meterPrepStmt = createPreparedStatement(getMeterQueryStr.toString());
			PreparedStatement meterPrepStmt = createPreparedStatement(getMeterQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			meterPrepStmt.bindString("logicalTransactionNumber", logicalTransactionNumber, "LOGICAL_TRX_NUMBER");
			List<SQLResultRow> meterRowList = meterPrepStmt.list();
			meterPrepStmt.close();
			
			Iterator<SQLResultRow> meterRowListIter = meterRowList.iterator();
			while (meterRowListIter.hasNext()){
				SQLResultRow meterRow = meterRowListIter.next();
				// Validate Meter Row
				validateInboundFaMeterData(meterRow);
				// If the meter row and meter char row are valid, add to List of Meters to be Processed
				meterDataList.add(addMeterToProcess());
			}
			
		}

		private void validateInboundFaMeterData(SQLResultRow meterRow) {
			
			// Validate Meter fields
			validateMeterFields(meterRow);

			// 2015-05-26. SMiran. Defect 3220374. Start Change
			if (meterStatus.isActive()){
				// Validate Meter Configuration fields
				validateMeterConfigFields(meterRow);				
			
				// Validate REG1 fields
				validateRegister1Fields(meterRow);
			
				// Validate REG2 fields if populated
				validateRegister2Fields(meterRow);
			}
			// 2015-05-26. SMiran. Defect 3220374. End Change
							
			// Validate data in XXL_INT_FA_MTR_CHAR_IN_STG table
			validateInboundFaMeterCharData();
			
		}

		private void validateMeterFields(SQLResultRow meterRow) {
			
			initializeMeterWorkVariables();
			
			// BADGE_NBR is required
			meterBadgeNumber = meterRow.getString("BADGE_NBR").trim();
			if (isEmptyOrNull(meterBadgeNumber)){
				addError(CustomMessageRepositoryMGE.cint01810tblFldMiss(originationTable, "BADGE_NBR"));
			}
			
			// SERIAL_NBR is required
			meterSerialNumber = meterRow.getString("SERIAL_NBR").trim();
			if (isEmptyOrNull(meterSerialNumber)){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "SERIAL_NBR"));
			}

			// MTR_TYPE is required		
			String meterTypeStr = meterRow.getString("MTR_TYPE").trim();
			if (isEmptyOrNull(meterTypeStr)){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "MTR_TYPE"));
			}else{
				meterTypeId = new MeterType_Id(meterTypeStr.trim());
				if (isNull(meterTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "MTR_TYPE", meterTypeStr));
				}
			}
							
			// MTR_STATUS is required
			String meterStatusStr = meterRow.getString("MTR_STATUS").trim();
			if (isEmptyOrNull(meterStatusStr)){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "MTR_STATUS"));
			}else{
				LookupField_Id lookupFieldId = new LookupField_Id("MTR_STATUS_FLG");
				LookupValue_Id lookupValueId = new LookupValue_Id(lookupFieldId, meterStatusStr);					
				if (isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "MTR_STATUS", meterStatusStr));
				}else{
					meterStatus = (MeterStatusLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
			}
			
			// MFG_CD is required
			String manufacturerStr = meterRow.getString("MFG_CD").trim();
			if (isEmptyOrNull(manufacturerStr)){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "MFG_CD"));
			}else{
				meterManufacturerId = new Manufacturer_Id(manufacturerStr);
				if (isNull(meterManufacturerId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "MFG_CD", manufacturerStr));
				}
			}
			
			// MODEL_CD is required	
			String modelStr = meterRow.getString("MODEL_CD").trim();
			if (isEmptyOrNull(modelStr)){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "MODEL_CD"));
			}else{
				meterModelId = new Model_Id(meterManufacturerId, modelStr.trim());
				if (isNull(meterModelId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "MODEL_CD", modelStr));
				}
			}
			
			// RECEIVE_DATE is required
			meterReceiveDate = meterRow.getDate("RECEIVE_DATE");
			
			// RETIRE_DATE
			meterRetireDate = meterRow.getDate("RETIRE_DATE");
			if (isNull(meterRetireDate)){
				if (meterStatus.isRetired()){
					// Retire Date must be supplied if Meter Status is Retired
					addError(CustomMessageRepositoryMGE.cint01810mtrRetiredFldMiss(originationTable, meterBadgeNumber, "RETIRE_DATE","MTR_STATUS","R"));
				}
			}
			
			// LONG_DESCR
			meterLongDescription = meterRow.getString("LONG_DESCR");
			
			// RETIRE_REASON must be valid if supplied
			String meterRetireReasonStr = meterRow.getString("RETIRE_REASON").trim();
			if (!isEmptyOrNull(meterRetireReasonStr)){
				meterRetireReasonId = new RetireReason_Id(meterRetireReasonStr);
				if (isNull(meterRetireReasonId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "RETIRE_REASON", meterRetireReasonStr));
				}
			}else{
				if (meterStatus.isRetired()){
					// Retire Reason must be supplied if Meter Status is Retired
					addError(CustomMessageRepositoryMGE.cint01810mtrRetiredFldMiss(originationTable, meterBadgeNumber, "RETIRE_REASON","MTR_STATUS","R"));
				} 
			}
			
		}		

		private void validateMeterConfigFields(SQLResultRow meterRow) {

			// EFF_DTTM is required
			meterConfigEffectiveDateTime = meterRow.getDateTime("EFF_DTTM");
			if (isNull(meterConfigEffectiveDateTime)){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "EFF_DTTM"));
			}
			
			// MTR_CONFIG_TYPE is required
			String meterConfigTypeStr = meterRow.getString("MTR_CONFIG_TYPE").trim();
			if (isEmptyOrNull(meterConfigTypeStr)){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "MTR_CONFIG_TYPE"));
			}else{
				meterConfigTypeId = new MeterConfigurationType_Id(meterConfigTypeStr);
				if (isNull(meterConfigTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "MTR_CONFIG_TYPE", meterConfigTypeStr));
				}
			}
			
		}

		private void validateRegister1Fields(SQLResultRow meterRow) {
			
			// REG1_READ_SEQ is required
			reg1ReadSeq = meterRow.getInteger("REG1_READ_SEQ");
			if (reg1ReadSeq.intValue() != 1){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "REG1_READ_SEQ"));
			}
			
			// REG1_NBR_DGTS_LEFT is required
			reg1NumberDigitsLeft = meterRow.getInteger("REG1_NBR_DGTS_LEFT");
			if (reg1NumberDigitsLeft.intValue() == 0){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "REG1_NBR_DGTS_LEFT"));
			}
			 
			// REG1_NBR_DGTS_RIGHT
			reg1NumberDigitsRight = meterRow.getInteger("REG1_NBR_DGTS_RIGHT");
			
			// REG1_UOM is required
			String reg1UomStr = meterRow.getString("REG1_UOM").trim();
			if (isEmptyOrNull(reg1UomStr)){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "REG1_UOM"));
			}else{
				reg1UomId = new UnitOfMeasure_Id(reg1UomStr);
				if(isNull(reg1UomId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "REG1_UOM", reg1UomStr));
				}
			}
			 
			// REG1_TOU must be valid if supplied
			String reg1TouStr = meterRow.getString("REG1_TOU").trim();
			if (!isEmptyOrNull(reg1TouStr)){
				reg1TouId = new TimeOfUse_Id(reg1TouStr);
				if(isNull(reg1TouId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "REG1_TOU", reg1TouStr));
				}
			}
			
			// REG1_REG_CONST is required
			reg1RegConst = meterRow.getBigDecimal("REG1_REG_CONST");
			if (reg1RegConst.compareTo(BigDecimal.ZERO) == 0){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "REG1_REG_CONST"));
			}
			
			// REG1_CONS_TYPE is required
			String reg1ConsTypeStr = meterRow.getString("REG1_CONS_TYPE").trim();
			if (isEmptyOrNull(reg1ConsTypeStr)){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "REG1_CONS_TYPE"));
			}else{
				LookupField_Id lookupFieldId = new LookupField_Id("CONSUM_SUB_FLG");
				LookupValue_Id lookupValueId = new LookupValue_Id(lookupFieldId, reg1ConsTypeStr);					
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "REG1_CONS_TYPE", reg1ConsTypeStr));
				}else{
					reg1ConsType = (ConsumptionTypeLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
			}
			
			// REG1_HOW_TO_USE is required
			String reg1HowToUseStr = meterRow.getString("REG1_HOW_TO_USE").trim();
			if (isEmptyOrNull(reg1HowToUseStr)){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "REG1_HOW_TO_USE"));
			}else{
				LookupField_Id lookupFieldId = new LookupField_Id("HOW_TO_USE_FLG");
				LookupValue_Id lookupValueId = new LookupValue_Id(lookupFieldId, reg1HowToUseStr);					
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "REG1_HOW_TO_USE", reg1HowToUseStr));
				}else{
					reg1HowToUse = (HowToUseLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
			}
			
			// REG1_FULL_SCALE
			reg1FullScale = meterRow.getBigDecimal("REG1_FULL_SCALE");
			
			// REG1_READ_OUT_TYPE must be valid if supplied
			String reg1ReadOutTypeStr = meterRow.getString("REG1_READ_OUT_TYPE").trim();
			if (!isEmptyOrNull(reg1ReadOutTypeStr)){
				reg1ReadOutTypeId = new ReadOutType_Id(reg1ReadOutTypeStr);
				if (isNull(reg1ReadOutTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "REG1_READ_OUT_TYPE", reg1ReadOutTypeStr));
				}
			}
			
			// REG1_PROTOCOL must be valid if supplied
			String reg1ProtocolStr = meterRow.getString("REG1_PROTOCOL").trim();
			if (!isEmptyOrNull(reg1ProtocolStr)){
				reg1ProtocolId = new Protocol_Id(reg1ProtocolStr);
				if (isNull(reg1ProtocolId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "REG1_PROTOCOL", reg1ProtocolStr));
				}
			}
			
			// REG1_TOLERANCE 
			reg1Tolerance = meterRow.getBigDecimal("REG1_TOLERANCE");
			
			// REG1_VIRTUAL_CHANNEL
			reg1VirtualChannelStr = meterRow.getString("REG1_VIRTUAL_CHANNEL").trim();
			
			// REG1_INT_REGISTER must be valid if supplied
			String reg1IntRegisterStr = meterRow.getString("REG1_INT_REGISTER").trim();
			if (!isEmptyOrNull(reg1IntRegisterStr)){
				reg1IntRegisterTypeId = new IntervalRegisterType_Id(reg1IntRegisterStr.trim());
				if (isNull(reg1IntRegisterTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "REG1_INT_REGISTER", reg1IntRegisterStr));
				}
			}
			
		}
		
		private void validateRegister2Fields(SQLResultRow meterRow) {
			
			reg2ReadSeq = meterRow.getInteger("REG2_READ_SEQ");
			if (reg2ReadSeq.intValue() != 0){					
				// REG2_READ_SEQ value should always be 2
				if (reg2ReadSeq.intValue() != 2){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "REG2_READ_SEQ", reg2ReadSeq.toString()));
				}
				// REG2_NBR_DGTS_LEFT is required
				reg2NumberDigitsLeft = meterRow.getInteger("REG2_NBR_DGTS_LEFT");
				if (reg2NumberDigitsLeft.intValue() == 0){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "REG2_NBR_DGTS_LEFT"));
				}
			 
				// REG2_NBR_DGTS_RIGHT
				reg2NumberDigitsRight = meterRow.getInteger("REG2_NBR_DGTS_RIGHT");
				
				// REG2_UOM is required
				String reg2UomStr = meterRow.getString("REG2_UOM").trim();
				if (isEmptyOrNull(reg2UomStr)){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "REG2_UOM"));
				}else{
					reg2UomId = new UnitOfMeasure_Id(reg2UomStr);
					if(isNull(reg2UomId.getEntity())){
						addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "REG2_UOM", reg2UomStr));
					}
				}
				 
				// REG2_TOU must be valid if supplied
				String reg2TouStr = meterRow.getString("REG2_TOU").trim();
				if (!isEmptyOrNull(reg2TouStr)){
					reg2TouId = new TimeOfUse_Id(reg2TouStr);
					if(isNull(reg2TouId.getEntity())){
						addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "REG2_TOU", reg2TouStr));
					}
				}
				
				// REG2_REG_CONST is required
				reg2RegConst = meterRow.getBigDecimal("REG2_REG_CONST");
				if (reg2RegConst.compareTo(BigDecimal.ZERO) == 0){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "REG2_REG_CONST"));
				}
				
				// REG2_CONS_TYPE is required
				String reg2ConsTypeStr = meterRow.getString("REG2_CONS_TYPE").trim();
				if (isEmptyOrNull(reg2ConsTypeStr)){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "REG2_CONS_TYPE"));
				}else{
					LookupField_Id lookupFieldId = new LookupField_Id("CONSUM_SUB_FLG");
					LookupValue_Id lookupValueId = new LookupValue_Id(lookupFieldId, reg2ConsTypeStr);						
					if(isNull(lookupValueId.getEntity())){
						addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "REG2_CONS_TYPE", reg2ConsTypeStr));
					}else{
						reg2ConsType = (ConsumptionTypeLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
					}
				}
				
				// REG2_HOW_TO_USE is required
				String reg2HowToUseStr = meterRow.getString("REG2_HOW_TO_USE").trim();
				if (isEmptyOrNull(reg2HowToUseStr)){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "REG2_HOW_TO_USE"));
				}else{
					LookupField_Id lookupFieldId = new LookupField_Id("HOW_TO_USE_FLG");
					LookupValue_Id lookupValueId = new LookupValue_Id(lookupFieldId, reg2HowToUseStr);						
					if(isNull(lookupValueId.getEntity())){
						addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "REG2_HOW_TO_USE", reg2HowToUseStr));
					}else{
						reg2HowToUse = (HowToUseLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
					}
				}
				
				// REG2_FULL_SCALE
				reg2FullScale = meterRow.getBigDecimal("REG2_FULL_SCALE");
				
				// REG2_READ_OUT_TYPE must be valid if supplied
				String reg2ReadOutTypeStr = meterRow.getString("REG2_READ_OUT_TYPE").trim();
				if (!isEmptyOrNull(reg2ReadOutTypeStr)){
					reg2ReadOutTypeId = new ReadOutType_Id(reg2ReadOutTypeStr);
					if (isNull(reg2ReadOutTypeId.getEntity())){
						addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "REG2_READ_OUT_TYPE", reg2ReadOutTypeStr));
					}
				}
				
				// REG2_PROTOCOL must be valid if supplied
				String reg2ProtocolStr = meterRow.getString("REG2_PROTOCOL").trim();
				if (!isEmptyOrNull(reg2ProtocolStr)){
					reg2ProtocolId = new Protocol_Id(reg2ProtocolStr);
					if (isNull(reg2ProtocolId.getEntity())){
						addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "REG2_PROTOCOL", reg2ProtocolStr));
					}
				}
				
				// REG2_TOLERANCE
				reg2Tolerance = meterRow.getBigDecimal("REG2_TOLERANCE");
				
				// REG2_VIRTUAL_CHANNEL
				reg2VirtualChannelStr = meterRow.getString("REG2_VIRTUAL_CHANNEL").trim();
				
				// REG2_INT_REGISTER must be valid if supplied
				String reg2IntRegisterStr = meterRow.getString("REG2_INT_REGISTER").trim();
	
				if (!isEmptyOrNull(reg2IntRegisterStr)){
					reg2IntRegisterTypeId = new IntervalRegisterType_Id(reg2IntRegisterStr.trim());
					if (isNull(reg2IntRegisterTypeId.getEntity())){
						addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber, "REG2_INT_REGISTER", reg2IntRegisterStr));
					}
				}
			}			
		}
		
		private void validateInboundFaMeterCharData() {

			originationTable = XXL_INT_FA_MTR_CHAR_IN_STG;
			
			// Initialize Meter Characteristics List
			meterCharList = new ArrayList<CmCharacteristicTempData>();
			
			// Get record from Item Inbound Staging Table
			StringBuilder getMeterCharQueryStr = new StringBuilder();
			getMeterCharQueryStr.append(" SELECT ");
			getMeterCharQueryStr.append(" 	CHAR_TYPE ");
			getMeterCharQueryStr.append(" 	,EFFDT ");
			getMeterCharQueryStr.append(" 	,CHAR_VAL ");
			getMeterCharQueryStr.append(" FROM ");
			getMeterCharQueryStr.append(" 	XXL_INT_FA_MTR_CHAR_IN_STG ");
			getMeterCharQueryStr.append(" WHERE ");
			getMeterCharQueryStr.append("   LOGICAL_TRX_NUMBER = :logicalTransactionNumber ");
			getMeterCharQueryStr.append("   AND BADGE_NBR = :meterBadgeNumber ");
			getMeterCharQueryStr.append("   AND MFG_CD = :mfgCd ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement meterCharPrepStmt = createPreparedStatement(getMeterCharQueryStr.toString());
			PreparedStatement meterCharPrepStmt = createPreparedStatement(getMeterCharQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			meterCharPrepStmt.bindString("logicalTransactionNumber", logicalTransactionNumber, "LOGICAL_TRX_NUMBER");
			meterCharPrepStmt.bindString("meterBadgeNumber", meterBadgeNumber.trim(), "BADGE_NBR");
			meterCharPrepStmt.bindId("mfgCd", meterManufacturerId);
			List<SQLResultRow> meterCharQueryList = meterCharPrepStmt.list();			
			meterCharPrepStmt.close();
			
			Iterator<SQLResultRow> meterCharQueryIter = meterCharQueryList.iterator();
			while (meterCharQueryIter.hasNext()){
				
				SQLResultRow meterCharRow = meterCharQueryIter.next();
				String charTypeStr = meterCharRow.getString("CHAR_TYPE").trim();
				String charValStr = meterCharRow.getString("CHAR_VAL").trim();
				Date effectiveDate = meterCharRow.getDate("EFFDT");
				
				// Characteristic Type is required
				if (isEmptyOrNull(charTypeStr)){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "CHAR_TYPE"));
				}
				// Characteristic Type must be valid
				CharacteristicType_Id charTypeId = new CharacteristicType_Id(charTypeStr);
				if (isNull(charTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, meterBadgeNumber,"CHAR_TYPE",charTypeStr));
				}
				// Characteristic Type must be valid for Meter Type
				CharacteristicTypeMeterType_Id charTypeMeterTypeId = new CharacteristicTypeMeterType_Id(meterTypeId,charTypeId);
				if (isNull(charTypeMeterTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmCharTypeInv(originationTable, meterBadgeNumber, charTypeStr, "Meter Type", meterTypeId.getIdValue()));
				}
				
				// Characteristic Value must be supplied
				if (isEmptyOrNull(charValStr)){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "CHAR_VAL"));
				}
				
				// If Char Type is Predefined, Char Type and Char Value combination must be valid
				if (charTypeId.getEntity().getCharacteristicType().isPredefinedValue()){
					CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charTypeId, charValStr);
					if (isNull(charValueId.getEntity())){
						addError(CustomMessageRepositoryMGE.cint01810mtrItmCharValInv(originationTable, meterBadgeNumber, charValStr, charTypeStr));
					}
				}
				
				// Effective Date must be supplied
				if (isNull(effectiveDate)){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, meterBadgeNumber, "EFFDT"));
				}
				CmCharacteristicTempData meterCharTempData = CmCharacteristicTempData.Factory.newInstance();
				meterCharTempData.setCharacteristicType(charTypeId.getEntity());
				meterCharTempData.setCharVal(charValStr);
				meterCharTempData.setEffectiveDate(effectiveDate);
				meterCharList.add(meterCharTempData);
				
                // START DELETE - JHERNA - 2016-03-10 - SysAid#68431
                // Not used anymore
                // 2015-05-26. SMiran. Defect 3223676. Start Add
                //if (charTypeId.equals(parmMeterSiteCharType.getId())){
                //  meterSiteNumber = charValStr;
                //}

                // 2015-05-26. SMiran. Defect 3223676. End Add
                // END DELETE - JHERNA - 2016-03-10 - SysAid#68431
				
			}

		}

		private void validateInboundFaItem() {
			
			originationTable = XXL_INT_FA_ITEM_IN_STG;
			
			// Get record from FA Item Inbound Staging Table
			StringBuilder getItemQueryStr = new StringBuilder();
			getItemQueryStr.append(" SELECT ");
			getItemQueryStr.append(" 	BADGE_NBR ");
			getItemQueryStr.append(" 	,ITEM_TYPE ");
			getItemQueryStr.append(" 	,ITEM_STATUS ");
			getItemQueryStr.append(" 	,MFG_CD ");
			getItemQueryStr.append(" 	,MODEL_CD ");
			getItemQueryStr.append(" 	,SERIAL_NBR ");
			getItemQueryStr.append(" 	,RECEIVE_DATE ");
			getItemQueryStr.append(" 	,RETIRE_DATE ");
			getItemQueryStr.append(" 	,NVL(LONG_DESCR,' ') LONG_DESCR ");
			getItemQueryStr.append(" 	,NVL(RETIRE_REASON,' ') RETIRE_REASON ");
			getItemQueryStr.append(" 	,NVL(PARENT_MTR,' ') PARENT_MTR ");
			getItemQueryStr.append(" 	,NVL(PARENT_SP,' ') PARENT_SP ");
			// 2015-06-17. SMiran. Defect 3236052. Start Add
			getItemQueryStr.append(" 	,NVL(SITEID,' ') SITEID ");
			// 2015-06-17. SMiran. Defect 3236052. End Add
			getItemQueryStr.append(" FROM ");
			getItemQueryStr.append(" 	XXL_INT_FA_ITEM_IN_STG ");
			getItemQueryStr.append(" WHERE ");
			getItemQueryStr.append("   LOGICAL_TRX_NUMBER = :logicalTransactionNumber ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement itemPrepStmt = createPreparedStatement(getItemQueryStr.toString());
			PreparedStatement itemPrepStmt = createPreparedStatement(getItemQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			itemPrepStmt.bindString("logicalTransactionNumber", logicalTransactionNumber, "LOGICAL_TRX_NUMBER");
			List<SQLResultRow> itemRowList = itemPrepStmt.list();
			itemPrepStmt.close();
			
			Iterator<SQLResultRow> itemRowListIter = itemRowList.iterator();
			while (itemRowListIter.hasNext()){
				SQLResultRow itemRow = itemRowListIter.next();
				// Validate Item Row
				validateInboundFaItemData(itemRow);
				// If the meter row and meter char row are valid, add to List of Meters to be Processed
				itemDataList.add(addItemToProcess());
			}
			
		}

		private void validateInboundFaItemData(SQLResultRow itemRow) {

			// Validate Item fields
			validateFaItemFields(itemRow);
			
			// Validate data in XXL_INT_FA_ITEM_CHAR_IN_STG table
			validateInboundFaItemCharData();	
			
		}
		
		private void validateFaItemFields(SQLResultRow itemRow) {
			
			initializeItemWorkVariables();

			// BADGE_NBR is required
			itemBadgeNumber = itemRow.getString("BADGE_NBR").trim();
			if (isEmptyOrNull(itemBadgeNumber)){
				addError(CustomMessageRepositoryMGE.cint01810tblFldMiss(originationTable, "BADGE_NBR"));
			}
			
			// SERIAL_NBR is required
			itemSerialNumber = itemRow.getString("SERIAL_NBR").trim();
			if (isEmptyOrNull(itemSerialNumber)){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, itemBadgeNumber, "SERIAL_NBR"));
			}
			
			// ITEM_TYPE is required
			String itemTypeStr = itemRow.getString("ITEM_TYPE").trim();
			if (isEmptyOrNull(itemTypeStr)){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, itemBadgeNumber, "ITEM_TYPE"));
			}else{
				itemTypeId = new ItemType_Id(itemTypeStr);
				if (isNull(itemTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, itemBadgeNumber, "ITEM_TYPE", itemTypeStr));
				}
			}
			
			// ITEM_STATUS is required
			String itemStatusStr = itemRow.getString("ITEM_STATUS").trim();
			if (isEmptyOrNull(itemStatusStr)){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, itemBadgeNumber, "ITEM_STATUS"));
			}else{
				LookupField_Id lookupFieldId = new LookupField_Id("ITEM_STATUS_FLG");
				LookupValue_Id lookupValueId = new LookupValue_Id(lookupFieldId, itemStatusStr);					
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, itemBadgeNumber, "ITEM_STATUS", itemStatusStr));
				}else{
					itemStatus = (ItemStatusLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
			}
			
			// MFG_CD is required
			String itemManufacturerStr = itemRow.getString("MFG_CD").trim();
			// 2015-07-17. SMiran. Defect 3249536. Start Change
			//if (isEmptyOrNull(itemManufacturerStr)){
			//	addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, itemBadgeNumber, "MFG_CD"));
			//}else{
			if (!isEmptyOrNull(itemManufacturerStr)){
			// 2015-07-17. SMiran. Defect 3249536. End Change
				itemManufacturerId = new Manufacturer_Id(itemManufacturerStr);
				if (isNull(itemManufacturerId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, itemBadgeNumber, "MFG_CD", itemManufacturerStr));
				}
			}
			
			// MODEL_CD is required
			// 2015-07-17. SMiran. Defect 3249536. Start Change
			if (notNull(itemManufacturerId)){
				String itemModelStr = itemRow.getString("MODEL_CD").trim();
				if (isEmptyOrNull(itemModelStr)){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, itemBadgeNumber, "MODEL_CD"));
				}else{
					itemModelId = new Model_Id(itemManufacturerId, itemModelStr.trim());
					if (isNull(itemModelId.getEntity())){
						addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, itemBadgeNumber, "MODEL_CD", itemModelStr));
					}
				}
			}
			// 2015-07-17. SMiran. Defect 3249536. End Change
			
			// RECEIVE DATE
			itemReceiveDate = itemRow.getDate("RECEIVE_DATE");
			
			// RETIRE DATE
			itemRetireDate = itemRow.getDate("RETIRE_DATE");
			if (isNull(itemRetireDate)){
				// Retire Date must be supplid if Item Status is Retired
				if (itemStatus.isRetired()){
					addError(CustomMessageRepositoryMGE.cint01810mtrRetiredFldMiss(originationTable, itemBadgeNumber, "RETIRE_DATE","ITEM_STATUS","R"));
				}
			}
			
			// LONG DESCRIPTION
			itemLongDescription = itemRow.getString("LONG_DESCR");	
			
			// RETIRE_REASON must be valid if supplied
			String itemRetireReasonStr = itemRow.getString("RETIRE_REASON").trim();
			if (!isEmptyOrNull(itemRetireReasonStr)){
				itemRetireReasonId = new RetireReason_Id(itemRetireReasonStr);
				if (isNull(itemRetireReasonId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, itemBadgeNumber, "RETIRE_REASON", itemRetireReasonStr));
				}
			}else{
				// Retire Reason must be supplied if Item Status is Retired
				if (itemStatus.isRetired()){
					addError(CustomMessageRepositoryMGE.cint01810mtrRetiredFldMiss(originationTable, itemBadgeNumber, "RETIRE_REASON","ITEM_STATUS","R"));
				}
			}
			
			// PARENT_MTR
			itemParentMeterSerialNumber = itemRow.getString("PARENT_MTR").trim();
			
			// PARENT_SP must be valid if supplied
			String itemParentSpStr = itemRow.getString("PARENT_SP").trim();
			if (!isEmptyOrNull(itemParentSpStr)){
				itemParentSpId = new ServicePoint_Id(itemParentSpStr);
				if (isNull(itemParentSpId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, itemBadgeNumber, "PARENT_SP", itemParentSpStr));
				}
			}
			
			// If item type is regulator, PARENT_MTR should not be populated.
			if (itemTypeId.equals(parmRegulatorItemType.getId()) && !isEmptyOrNull(itemParentMeterSerialNumber)){
				addError(CustomMessageRepositoryMGE.cint01810parentMtrInv(originationTable, itemBadgeNumber, "PARENT_MTR"));
			}
			
			// If item type is not regulator, PARENT_SP should not be populated.
			if (!itemTypeId.equals(parmRegulatorItemType.getId()) && !isEmptyOrNull(itemParentSpStr)){
				addError(CustomMessageRepositoryMGE.cint01810parentSpInv(originationTable, itemBadgeNumber, "PARENT_SP"));
			}			
			
			// 2015-06-17. SMiran. Defect 3236052. Start Add
			itemSiteNumber = itemRow.getString("SITEID").trim();
			if (isEmptyOrNull(itemSiteNumber)){
				addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, itemBadgeNumber, "SITEID"));
			}
			// 2015-06-17. SMiran. Defect 3236052. End Add
			
		}
		
		private void validateInboundFaItemCharData() {			
			
			originationTable = XXL_INT_FA_ITEM_CHAR_IN_STG;
			
			// Initialize Item Characteristics List
			itemCharList = new ArrayList<CmCharacteristicTempData>();
			
			// Get record from Item Characteristic Inbound Staging Table
			StringBuilder getItemCharQueryStr = new StringBuilder();
			getItemCharQueryStr.append(" SELECT ");
			getItemCharQueryStr.append(" 	CHAR_TYPE ");
			getItemCharQueryStr.append(" 	,EFFDT ");
			getItemCharQueryStr.append(" 	,CHAR_VAL ");
			getItemCharQueryStr.append(" FROM ");
			getItemCharQueryStr.append(" 	XXL_INT_FA_ITEM_CHAR_IN_STG ");
			getItemCharQueryStr.append(" WHERE ");
			getItemCharQueryStr.append("   LOGICAL_TRX_NUMBER = :logicalTransactionNumber ");
			getItemCharQueryStr.append("   AND BADGE_NBR = :itemBadgeNumber ");	
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement itemCharPrepStmt = createPreparedStatement(getItemCharQueryStr.toString());
			PreparedStatement itemCharPrepStmt = createPreparedStatement(getItemCharQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			itemCharPrepStmt.bindString("logicalTransactionNumber", logicalTransactionNumber, "LOGICAL_TRX_NUMBER");
			itemCharPrepStmt.bindString("itemBadgeNumber", itemBadgeNumber.trim(), "BADGE_NBR");
			List<SQLResultRow> itemCharQueryList = itemCharPrepStmt.list();
			itemCharPrepStmt.close();
			Iterator<SQLResultRow> itemCharQueryListIter = itemCharQueryList.iterator();
			while (itemCharQueryListIter.hasNext()){
				SQLResultRow itemCharRow = itemCharQueryListIter.next();
				String charTypeStr = itemCharRow.getString("CHAR_TYPE").trim();
				String charValStr = itemCharRow.getString("CHAR_VAL").trim();
				Date effectiveDate = itemCharRow.getDate("EFFDT");
				
				// Characteristic Type must be supplied
				if (isEmptyOrNull(charTypeStr)){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, itemBadgeNumber, "CHAR_TYPE"));
				}
				// Characteristic Type must be valid
				CharacteristicType_Id charTypeId = new CharacteristicType_Id(charTypeStr);
				if (isNull(charTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldInv(originationTable, itemBadgeNumber,"CHAR_TYPE",charTypeStr));
				}
				
				// Characteristic Type must be valid for Item Type
				CharacteristicTypeItemType_Id charTypeItemTypeId = new CharacteristicTypeItemType_Id(itemTypeId,charTypeId);
				if (isNull(charTypeItemTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmCharTypeInv(originationTable, itemBadgeNumber, charTypeStr, "Item Type", itemTypeId.getIdValue()));
				}
				
				// Characteristic Value must be supplied
				if (isEmptyOrNull(charValStr)){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, itemBadgeNumber, "CHAR_VAL"));
				}
				
				// If Char Type is Predefined, Char Type and Char Value combination must be valid
				if (charTypeId.getEntity().getCharacteristicType().isPredefinedValue()){
					CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charTypeId, charValStr);
					if (isNull(charValueId.getEntity())){
						addError(CustomMessageRepositoryMGE.cint01810mtrItmCharValInv(originationTable, itemBadgeNumber, charValStr, charTypeStr));
					}
				}
				
				// Effective Date must be supplied
				if (isNull(effectiveDate)){
					addError(CustomMessageRepositoryMGE.cint01810mtrItmFldMiss(originationTable, itemBadgeNumber, "EFFDT"));
				}	
				
				CmCharacteristicTempData itemCharTempData = CmCharacteristicTempData.Factory.newInstance();
				itemCharTempData.setCharacteristicType(charTypeId.getEntity());
				itemCharTempData.setCharVal(charValStr);
				itemCharTempData.setEffectiveDate(effectiveDate);
				itemCharList.add(itemCharTempData);			
				
			}
			
		}

		private CmMeterData addMeterToProcess() {

			CmMeterData cmMeterData = CmMeterData.Factory.newInstance();
			// Meter
			cmMeterData.setBadgeNumber(meterBadgeNumber);
			cmMeterData.setMeterTypeId(meterTypeId);
			cmMeterData.setStatus(meterStatus);
			cmMeterData.setSerialNumber(meterSerialNumber);
			cmMeterData.setModelId(meterModelId);
			cmMeterData.setRetireReasonId(meterRetireReasonId);
			cmMeterData.setLongDescription(meterLongDescription);
			cmMeterData.setReceiveDate(meterReceiveDate);
			cmMeterData.setRetireDate(meterRetireDate);
			// Meter Configuration
			cmMeterData.setEffectiveDateTime(meterConfigEffectiveDateTime);
			cmMeterData.setMeterConfigurationType(meterConfigTypeId);
			// Register 1
			cmMeterData.setReg1NumberDigitsLeft(reg1NumberDigitsLeft);
			cmMeterData.setReg1NumberDigitsRight(reg1NumberDigitsRight);
			cmMeterData.setReg1ReadSeq(reg1ReadSeq);
			cmMeterData.setReg1UomId(reg1UomId);
			cmMeterData.setReg1TouId(reg1TouId);
			cmMeterData.setReg1RegConst(reg1RegConst);
			cmMeterData.setReg1ConsType(reg1ConsType);
			cmMeterData.setReg1HowToUse(reg1HowToUse);
			cmMeterData.setReg1FullScale(reg1FullScale);
			cmMeterData.setReg1ReadOutTypeId(reg1ReadOutTypeId);
			cmMeterData.setReg1ProtocolId(reg1ProtocolId);
			cmMeterData.setReg1Tolerance(reg1Tolerance);
			cmMeterData.setReg1VirtualChannelStr(reg1VirtualChannelStr);
			cmMeterData.setReg1IntRegisterTypeId(reg1IntRegisterTypeId);
			// Register 2
			cmMeterData.setReg2NumberDigitsLeft(reg2NumberDigitsLeft);
			cmMeterData.setReg2NumberDigitsRight(reg2NumberDigitsRight);
			cmMeterData.setReg2ReadSeq(reg2ReadSeq);
			cmMeterData.setReg2UomId(reg2UomId);
			cmMeterData.setReg2TouId(reg2TouId);
			cmMeterData.setReg2RegConst(reg2RegConst);
			cmMeterData.setReg2ConsType(reg2ConsType);
			cmMeterData.setReg2HowToUse(reg2HowToUse);
			cmMeterData.setReg2FullScale(reg2FullScale);
			cmMeterData.setReg2ReadOutTypeId(reg2ReadOutTypeId);
			cmMeterData.setReg2ProtocolId(reg2ProtocolId);
			cmMeterData.setReg2Tolerance(reg2Tolerance);
			cmMeterData.setReg2VirtualChannelStr(reg2VirtualChannelStr);
			cmMeterData.setReg2IntRegisterTypeId(reg2IntRegisterTypeId);
			// Meter Characteristics
			cmMeterData.setMeterCharacteristics(meterCharList);
			// 2015-05-26. SMiran. Defect 3223676. Start Add
	         
            // START CHANGE - JHERNA - 2016-03-10 - SysAid#68431
            // Retrieve the correct meter site number on the staging table
            // for the meter badge / manufacturer being processed
            //cmMeterData.setMeterSiteNumber(meterSiteNumber);          
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(" SELECT ");
            stringBuilder.append("  CHAR_VAL ");
            stringBuilder.append(" FROM ");
            stringBuilder.append("  XXL_INT_FA_MTR_CHAR_IN_STG ");
            stringBuilder.append(" WHERE ");
            stringBuilder.append("   LOGICAL_TRX_NUMBER = :logicalTransactionNumber ");
            stringBuilder.append("   AND BADGE_NBR = :meterBadgeNumber ");
            stringBuilder.append("   AND MFG_CD = :mfgCd ");
            stringBuilder.append("   AND CHAR_TYPE = :siteNbrCharType ");
            
            /*
             * Start Change - 2016-04-25 - Updated for CCB v2.4 compilation
             */
            //PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
            PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            /*
             * End Change - 2016-04-25 - Updated for CCB v2.4 compilation
             */
            prepState.bindString("logicalTransactionNumber", logicalTransactionNumber, "LOGICAL_TRX_NUMBER");
            prepState.bindString("meterBadgeNumber", meterBadgeNumber.trim(), "BADGE_NBR");
            prepState.bindId("mfgCd", meterManufacturerId);
            prepState.bindId("siteNbrCharType", parmMeterSiteCharType.getId());
            prepState.execute();
            SQLResultRow sqlRow = prepState.firstRow();
            
            //Start Add JVitug - Defect 42690 - 2020-10-20
            //if no record in Inbound FA Meter Characteristics Staging Table, call an error
            if(isNull(sqlRow)) {
            	addError(CustomMessageRepositoryMGE.cint01810noRecordInFAMeterCharStaging(XXL_INT_FA_MTR_CHAR_IN_STG));
            }
            //End Add JVitug - Defect 42690 - 2020-10-20
            
            String correctMeterSiteNumber = sqlRow.getString("CHAR_VAL");
            
            cmMeterData.setMeterSiteNumber(correctMeterSiteNumber);
                        
            // END CHANGE - JHERNA - 2016-03-10 - SysAid#68431
			// 2015-05-26. SMiran. Defect 3223676. End Add
			
			return cmMeterData;
			
		}
		
		private CmItemData addItemToProcess() {

			CmItemData cmItemData = CmItemData.Factory.newInstance();
			// Item
			cmItemData.setItemBadgeNumber(itemBadgeNumber);
			cmItemData.setItemTypeId(itemTypeId );
			cmItemData.setItemStatus(itemStatus);
			cmItemData.setItemModelId(itemModelId);
			cmItemData.setItemSerialNumber(itemSerialNumber);
			cmItemData.setItemRetireReasonId(itemRetireReasonId);
			cmItemData.setItemParentMeterSeriaNumber(itemParentMeterSerialNumber);
			cmItemData.setItemLongDescription(itemLongDescription);
			cmItemData.setItemReceiveDate(itemReceiveDate);
			cmItemData.setItemRetireDate(itemRetireDate);
			cmItemData.setItemParentSpId(itemParentSpId);
			// Item Characteristics
			cmItemData.setItemCharList(itemCharList);
						
			return cmItemData;
			
		}
		
		private void processItems() {

			// Retrieve each associated item from the FA item interface table
			Iterator<CmItemData> itemDataListIter = itemDataList.iterator();
			while (itemDataListIter.hasNext()){
				CmItemData itemData = itemDataListIter.next();
				processItemData(itemData);
			}
		}
		
		private void processItemData(CmItemData itemData) {
			
			// Check to see if the item exists in CC&B
			CmItemHelper itemHelper = CmItemHelper.Factory.newInstance();
			itemHelper.setItemBadgeNumber(itemData.getItemBadgeNumber());
			itemHelper.setItemTypeId(itemData.getItemTypeId());
			itemHelper.setItemStatus(itemData.getItemStatus());
			itemHelper.setItemModelId(itemData.getItemModelId());
			itemHelper.setItemSerialNumber(itemData.getItemSerialNumber());
			itemHelper.setItemReceiveDate(itemData.getItemReceiveDate());
			itemHelper.setItemLongDescription(itemData.getItemLongDescription());
			itemHelper.setItemCharList(itemData.getItemCharList());
			itemHelper.setItemParentMeterSeriaNumber(itemData.getitemParentMeterSerialNumber());
			itemHelper.setItemParentSpId(itemData.getItemParentSpId());
			itemHelper.setStagingKey(stagingKey.getStagingKey());			
			itemHelper.setLogicalTransactionNumber(logicalTransactionNumber);
			// 2015-05-26. SMiran. Defect 3220374. Start Add
			itemHelper.setItemRetireDate(itemData.getItemRetireDate());
			itemHelper.setItemRetireReasonId(itemData.getItemRetireReasonId());
			// 2015-05-26. SMiran. Defect 3220374. End Add
			// 2015-06-17. SMiran. Defect 3236052. Start Add
			itemHelper.setMeterSiteCharType(parmMeterSiteCharType);
			itemHelper.setItemSiteNumber(itemSiteNumber);
			// 2015-06-17. SMiran. Defect 3236052. Start Add
			
			Item_Id itemIdInCCB = itemHelper.itemExists();
			// If the item does not exist
			if (isNull(itemIdInCCB)){
				// Create the item
				Item newlyCreatedItem = itemHelper.createItem();
				// Create associated item characteristics
				itemHelper.createOrUpdateItemChar(newlyCreatedItem);
				// Store newly created item Id
				itemIdInCCB = newlyCreatedItem.getId();
			}else{
				// If the item does exist, compare each attribute in the staging table to the corresponding element in CC&B
				// Any attribute of the item (except receive date) that has changed should be updated in CC&B
				itemHelper.updateItem(itemIdInCCB);
				// Each characteristic value that has changed should result in a new characteristic record in CC&B
				itemHelper.createOrUpdateItemChar(itemIdInCCB.getEntity());
			}

			// Determine whether the item's parent meter or service point has been changed:
			// If item type is AMR, ERT, CNI2, or CORR (corrector), check the parent meter field. If the parent meter in the staging table is different from the  
			// meter in CC&B that has the item listed as equipment, process an equipment change. Populate the end date on the existing  
			// meter equipment record associated with the item and add a new equipment record on the new parent meter.
			if (!itemData.getItemTypeId().equals(parmRegulatorItemType.getId())){
				itemHelper.checkItemEq(itemIdInCCB);
				itemHelper.processItemMeter(itemIdInCCB);
			}else{
				// If item type is Regulator, check the parent SP field. If the parent SP in the staging table is different from the service point in CC&B 
				// that has the item listed as equipment, process an equipment change. Populate the end date on the existing SP equipment record associated 
				// with the item and add a new equipment record on the new parent SP.
				itemHelper.processItemSp(itemIdInCCB);
			}
			
			// 2015-07-06. SMiran. Defect 3233441. Start Add
			if (itemData.getItemStatus().isRetired()){
				itemHelper.retireItem(itemIdInCCB);
			}
			// 2015-07-06. SMiran. Defect 3233441. End Add			
		}

		private void processMeters() {
			
			// Set flag to indicate real meter exchange
			isRealMeterExchange = Bool.TRUE;

			// Retrieve each associated meter from the FA item interface table
			Iterator<CmMeterData> meterDataListIter = meterDataList.iterator();
			while (meterDataListIter.hasNext()){
				CmMeterData meterData = meterDataListIter.next();
				processMeterData(meterData);
			}
			
			// 2015-06-18. SMiran. Defect 3236175. Start Add
			if (meterDataList.size() == 0){
				// If no Meter Data was sent, we need to get the Meter Configuration using the Serial Number and Site Number.
				// We will need the Meter Configuration to add the meter read to be able to complete the FA.
				CmMeterHelper meterHelper = CmMeterHelper.Factory.newInstance();
				meterHelper.setMeterSiteCharType(parmMeterSiteCharType);
				meterHelper.setMeterSiteNumber(siteNumber);				
				// If the serial number found is populated, get the meter and meter config
				// 2015-08-05. SMiran. Defect 3269634. Start Change
				//if (!isEmptyOrNull(serialNumberFound)){
				if (!isEmptyOrNull(serialNumberFound.trim())){
				// 2015-08-05. SMiran. Defect 3269634. End Change
					meterHelper.setSerialNumber(serialNumberFound);
					// Get the correct Meter Id using Serial Number and Site Number
					Meter_Id meterIdInCCB = meterHelper.meterExists();
					// Get the correct effective Meter Configuration
					// 2015-07-21. SMiran. Defect 3249477. Start Change
					//meterConfigIdFound = meterHelper.getEffectiveMeterConfig(meterIdInCCB,workDateTime);
					
					if (isNull(meterIdInCCB)){
						addError(CustomMessageRepositoryMGE.cint01810mtrNotFound(serialNumberFound,siteNumber));
					}
					
					meterConfigIdFound = meterHelper.getEffectiveMeterConfig(meterIdInCCB,getProcessDateTime());
					
					if (isNull(meterConfigIdFound)){
						addError(CustomMessageRepositoryMGE.cint01810mtrConfigNotFound(serialNumberFound,siteNumber));
					}
					
					// 2015-07-21. SMiran. Defect 3249477. End Change
				}
				// If the serial number left is populated, get the meter and meter config
				// 2015-08-05. SMiran. Defect 3269634. Start Change
				//if (!isEmptyOrNull(serialNumberLeft)){
				if (!isEmptyOrNull(serialNumberLeft.trim())){
				// 2015-08-05. SMiran. Defect 3269634. End Change					
					meterHelper.setSerialNumber(serialNumberLeft);
					// Get the correct Meter Id using Serial Number and Site Number
					Meter_Id meterIdInCCB = meterHelper.meterExists();
					// Get the correct effective Meter Configuration
					// 2015-07-21. SMiran. Defect 3249477. Start Change
					//meterConfigIdLeft = meterHelper.getEffectiveMeterConfig(meterIdInCCB,workDateTime);
					
					if (isNull(meterIdInCCB)){
						addError(CustomMessageRepositoryMGE.cint01810mtrNotFound(serialNumberLeft,siteNumber));
					}
					
					meterConfigIdLeft = meterHelper.getEffectiveMeterConfig(meterIdInCCB,getProcessDateTime());
					
					if (isNull(meterConfigIdLeft)){
						addError(CustomMessageRepositoryMGE.cint01810mtrConfigNotFound(serialNumberLeft,siteNumber));
					}
					
					// 2015-07-21. SMiran. Defect 3249477. End Change
				}
			}
			// 2015-06-18. SMiran. Defect 3236175. End Add
			
		}
		
		// 2015-07-06. SMiran. Defect 3233441. Start Add
		private void retireMeters() {

			Iterator<CmMeterData> meterDataListIter = meterDataList.iterator();
			while (meterDataListIter.hasNext()){
				CmMeterData meterData = meterDataListIter.next();
				if (meterData.getStatus().isRetired()){
					CmMeterHelper meterHelper = CmMeterHelper.Factory.newInstance();
					meterHelper.setMeterSiteCharType(parmMeterSiteCharType);
					meterHelper.setMeterSiteNumber(siteNumber);
					meterHelper.setSerialNumber(meterData.getSerialNumber());
					Meter_Id meterIdInCCB = meterHelper.meterExists();
					Meter_DTO meterDTO = meterIdInCCB.getEntity().getDTO();
					meterDTO.setMeterStatus(meterData.getStatus());
					meterDTO.setRetiredDate(meterData.getRetireDate());			
					meterDTO.setRetireReasonId(meterData.getRetireReasonId());
					meterIdInCCB.getEntity().setDTO(meterDTO);
				}
			}
			
		}
		// 2015-07-06. SMiran. Defect 3233441. End Add
		
		private void processMeterData(CmMeterData meterData) {
			
			CmMeterHelper meterHelper = CmMeterHelper.Factory.newInstance();
			// Meter
			meterHelper.setBadgeNumber(meterData.getBadgeNumber());
			meterHelper.setMeterTypeId(meterData.getMeterTypeId());
			meterHelper.setStatus(meterData.getStatus());
			meterHelper.setModelId(meterData.getModelId());
			meterHelper.setSerialNumber(meterData.getSerialNumber());
			meterHelper.setReceiveDate(meterData.getReceiveDate());
			meterHelper.setLongDescription(meterData.getLongDescription());
			meterHelper.setRetireDate(meterData.getRetireDate());
			meterHelper.setRetireReasonId(meterData.getRetireReasonId());
			//Meter Characteristics
			meterHelper.setMeterCharacteristics(meterData.getMeterCharacteristics());
			//Meter Configuration
			meterHelper.setEffectiveDateTime(meterData.getEffectiveDateTime());
			meterHelper.setMeterConfigurationType(meterData.getMeterConfigurationType());			
			//Register 1
			meterHelper.setReg1ReadSeq(meterData.getReg1ReadSeq());
			meterHelper.setReg1UomId(meterData.getReg1UomId());
			meterHelper.setReg1RegConst(meterData.getReg1RegConst());
			meterHelper.setReg1HowToUse(meterData.getReg1HowToUse());
			meterHelper.setReg1ConsType(meterData.getReg1ConsType());
			meterHelper.setReg1NumberDigitsLeft(meterData.getReg1NumberDigitsLeft());				
			meterHelper.setReg1NumberDigitsRight(meterData.getReg1NumberDigitsRight());
			meterHelper.setReg1TouId(meterData.getReg1TouId());
			meterHelper.setReg1FullScale(meterData.getReg1FullScale());
			meterHelper.setReg1ReadOutTypeId(meterData.getReg1ReadOutTypeId());
			meterHelper.setReg1ProtocolId(meterData.getReg1ProtocolId());
			meterHelper.setReg1Tolerance(meterData.getReg1Tolerance());
			meterHelper.setReg1VirtualChannelStr(meterData.getReg1VirtualChannelStr());
			meterHelper.setReg1IntRegisterTypeId(meterData.getReg1IntRegisterTypeId());
			//Register 2
			meterHelper.setReg2ReadSeq(meterData.getReg2ReadSeq());
			meterHelper.setReg2UomId(meterData.getReg2UomId());
			meterHelper.setReg2RegConst(meterData.getReg2RegConst());
			meterHelper.setReg2HowToUse(meterData.getReg2HowToUse());
			meterHelper.setReg2ConsType(meterData.getReg2ConsType());
			meterHelper.setReg2NumberDigitsLeft(meterData.getReg2NumberDigitsLeft());				
			meterHelper.setReg2NumberDigitsRight(meterData.getReg2NumberDigitsRight());
			meterHelper.setReg2TouId(meterData.getReg2TouId());
			meterHelper.setReg2FullScale(meterData.getReg2FullScale());
			meterHelper.setReg2ReadOutTypeId(meterData.getReg2ReadOutTypeId());
			meterHelper.setReg2ProtocolId(meterData.getReg2ProtocolId());
			meterHelper.setReg2Tolerance(meterData.getReg2Tolerance());
			meterHelper.setReg2VirtualChannelStr(meterData.getReg2VirtualChannelStr());
			meterHelper.setReg2IntRegisterTypeId(meterData.getReg2IntRegisterTypeId());
			
			//Staging Key, Logical Transaction Number
			meterHelper.setStagingKey(stagingKey.getStagingKey());
			meterHelper.setLogicalTransactionNumber(logicalTransactionNumber);
			
			// 2015-05-26. SMiran. Defect 3223676. Start Add
			meterHelper.setMeterSiteCharType(parmMeterSiteCharType);
			// START CHANGES - JHERNA - 2016-03-10 - SysAid#68431
            //meterHelper.setMeterSiteNumber(meterSiteNumber);
            meterHelper.setMeterSiteNumber(meterData.getMeterSiteNumber());
            // END CHANGES - JHERNA - 2016-03-10 - SysAid#68431
			// 2015-05-26. SMiran. Defect 3223676. End Add
			
			// Check to see if the meter exists in CC&B
			Meter_Id meterIdInCCB = meterHelper.meterExists();
			
			// If the meter does not exist
			if (isNull(meterIdInCCB)){
			    
	             // START ADD - JHERNA - 2016-03-10 - SysAid#68431
                CmMeterValidationForUniquenessRoutine mtrValRoutine = CmMeterValidationForUniquenessRoutine.Factory.newInstance();
                mtrValRoutine.validateMeterUniqueness(parmMeterSiteCharType.getId(), meterData.getMeterSiteNumber().trim(), 
                        meterData.getBadgeNumber().trim(), meterData.getModelId().getManufacturerId());
                // END ADD - JHERNA - 2016-03-10 - SysAid#68431
                
				// Create Meter
				Meter newlyCreatedMeter = meterHelper.createMeter();
				// Create associated meter Characteristics
				meterHelper.createOrUpdateMeterChar(newlyCreatedMeter);
				// Create Meter Configuration
				MeterConfiguration newlyCreatedMeterConfig = meterHelper.createMeterConfiguration(newlyCreatedMeter);
				// Create Register(s)
				meterHelper.createRegisters(newlyCreatedMeterConfig);
				// 2015-05-26. SMiran. Defect 3227823. Start Add
				if (meterData.getBadgeNumber().trim().equals(badgeNumberFound)){
					meterConfigIdFound = newlyCreatedMeterConfig.getId();
				}else if (meterData.getBadgeNumber().trim().equals(badgeNumberLeft)){
					meterConfigIdLeft = newlyCreatedMeterConfig.getId();
				}
				// 2015-05-26. SMiran. Defect 3227823. End Add
			}else{
				// If the meter does exist, compare each attribute in the staging table to the corresponding element in CC&B.
				// Any attribute of the meter (except receive date) that has changed should be updated in CC&B.
				meterHelper.updateMeter(meterIdInCCB);
				// Each characteristic staging record should also be compared. Each characteristic value that has changed should 
				// result in a new characteristic record in CC&B.
				meterHelper.createOrUpdateMeterChar(meterIdInCCB.getEntity());
				// Get effective meter configuration
				// 2015-07-21. SMiran. Defect 3249477. Start Change
				//MeterConfiguration_Id effectiveMeterConfigId = meterHelper.getEffectiveMeterConfig(meterIdInCCB,workDateTime);
				MeterConfiguration_Id effectiveMeterConfigId = meterHelper.getEffectiveMeterConfig(meterIdInCCB,getProcessDateTime());
				// 2015-07-21. SMiran. Defect 3249477. End Change
				// 2015-05-26. SMiran. Defect 3223676. Start Add
				if (meterData.getBadgeNumber().trim().equals(badgeNumberFound)){
					meterConfigIdFound = effectiveMeterConfigId;
				}else if (meterData.getBadgeNumber().trim().equals(badgeNumberLeft)){
					meterConfigIdLeft = effectiveMeterConfigId;
				}
				
				// 2015-08-21. SMiran. Start Add
				// If meter data badge number is equal to both badge number found and badge number left, there is only one data sent.
				// Set both meter config found and left to the effective meter configuration found in CCB.
				if (meterData.getBadgeNumber().trim().equals(badgeNumberFound)
						&& meterData.getBadgeNumber().trim().equals(badgeNumberLeft)){
					meterConfigIdFound = effectiveMeterConfigId;
					meterConfigIdLeft = effectiveMeterConfigId;
				}
				// 2015-08-21. SMiran. End Add
				
				// 2015-05-26. SMiran. Defect 3223676. End Add
				// Any attribute of the meter configuration (or associated register) should result in a new meter configuration with the current information, 
				// but only if the effective date provided is later than the current meter configuration's effective date in CC&B.
				// 2015-05-29. SMiran. Defect 3227823. Start Change
				//if (meterConfigEffectiveDateTime.isAfter(effectiveMeterConfigId.getEntity().getEffectiveDateTime())){
				// 2015-07-21. SMiran. Defect 3249477. Start Change
				//if (meterData.getStatus().isActive() && meterConfigEffectiveDateTime.isAfter(effectiveMeterConfigId.getEntity().getEffectiveDateTime())){
				if (meterData.getStatus().isActive() 
						&& meterData.getEffectiveDateTime().isAfter(effectiveMeterConfigId.getEntity().getEffectiveDateTime())){
				// 2015-07-21. SMiran. Defect 3249477. End Change
				// 2015-05-29. SMiran. Defect 3227823. End Change
					newMeterConfigNeeded = meterHelper.checkIfMeterConfigChanged(effectiveMeterConfigId);
					if (newMeterConfigNeeded.isTrue()){	
						// Log error if this is a non-exchange FA Type
						checkExchangeFaType();
						
						// If the meter is currently installed
						if (meterData.getBadgeNumber().trim().equals(badgeNumberFound)){
							// Add Meter Removal Read for meter configuration currently installed
							// 2015-06-18. SMiran. Defect 3236175. Start Change
							//MeterRead removalRead = addMeterRemovalRead(effectiveMeterConfigId);	
							
							//Start Add JVitug - B-13084 Reopened - 2020-09-16
							// Start Change DLampa - E13304 - 2026-08-07
							//if(effectiveMeterConfigId.getEntity().getMeterConfigurationType().getId().getTrimmedValue().
			                //        equalsIgnoreCase(defaultSecondRegisterMeterConfigType.getId().getTrimmedValue())
			                if (defaultSecondRegisterMeterConfigType.contains(effectiveMeterConfigId.getEntity().getMeterConfigurationType())
			                // End Change DLampa - E13304 - 2026-08-07			                		)
			                        && reg2SeqFound.compareTo(BigInteger.ONE) < 0) {
			                    reg2SeqFound = BigInteger.ONE.add(BigInteger.ONE);
			                    reg2ReadTypeFound = ReadTypeLookup.constants.REGULAR;
			                    //Calculate register reading
			                     reg2ReadingFound = retrieveQuotientBetweenPriorReadingCCFUAndPriorReadingCCFC(meterConfigIdFound,
			                            reg1SeqFound, 
			                            reg1ReadTypeFound,
			                            reg1ReadingFound,
			                            reg2SeqFound,
			                            reg2ReadTypeFound);
			                     
			                     reg2ReviewHiLoFound = YesNoOptionLookup.constants.NO;
			                }
							//End Add JVitug - B-13084 Reopened - 2020-09-16
							
							MeterRead removalRead = createMeterReadForStep(effectiveMeterConfigId
									, meterReadSourceFound, useOnBillFound, Bool.FALSE, workDateTime
									, reg1SeqFound, reg1ReadTypeFound, reg1ReadingFound, reg1ReviewHiLoFound
									, reg2SeqFound, reg2ReadTypeFound, reg2ReadingFound, reg2ReviewHiLoFound);
							// 2015-06-18. SMiran. Defect 3236175. End Change
							
							// 2015-08-04. SMiran. Defect 3266831. Start Add
							spMeterHistFound = getSpMeterHistory(serialNumberFound);
							// 2015-08-04. SMiran. Defect 3266831. End Add
							
							// Remove the meter from SP
							ServicePointMeterHistory_DTO spMhDTO = spMeterHistFound.getDTO();
							spMhDTO.setRemovalMeterReadId(removalRead.getId());
							spMhDTO.setRemovalDateTime(removalRead.getReadDateTime());
							spMeterHistFound.setDTO(spMhDTO);														
							// Set flag to indicate real meter exchange
							isRealMeterExchange = Bool.FALSE;
						}
												
						// Create the new meter configuration
						// 2015-08-14. SMiran. Defect 3272953. Start Change
						//// 2015-07-21. SMiran. Defect 3249477. Start Add
						//// If the meterConfigIdLeft's effective date time is after the workDateTime, set it to workDateTime
						// Use the Work Date Time when adding the new meter configuration
						//if (meterData.getEffectiveDateTime().isAfter(workDateTime)){
						meterHelper.setEffectiveDateTime(workDateTime);						
						//}	
						//// 2015-07-21. SMiran. Defect 3249477. End Add
						// 2015-08-14. SMiran. Defect 3272953. End Change
						
						MeterConfiguration newlyCreatedMeterConfig = meterHelper.createMeterConfiguration(meterIdInCCB.getEntity());
							
						// Create the registers
						meterHelper.createRegisters(newlyCreatedMeterConfig);
						
						// 2015-05-26. SMiran. Defect 3223676. Start Add
						if (meterData.getBadgeNumber().trim().equals(badgeNumberFound)
								&& meterData.getBadgeNumber().trim().equals(badgeNumberLeft)){
							meterConfigIdFound = newlyCreatedMeterConfig.getId();
							meterConfigIdLeft = newlyCreatedMeterConfig.getId();
						}else if (meterData.getBadgeNumber().trim().equals(badgeNumberFound)){
							meterConfigIdFound = newlyCreatedMeterConfig.getId();
						}else if (meterData.getBadgeNumber().trim().equals(badgeNumberLeft)){
							meterConfigIdLeft = newlyCreatedMeterConfig.getId();
						}
						// 2015-05-26. SMiran. Defect 3223676. End Add
					}
				}
			}
		}
		
		private void checkExchangeFaType() {
			
			StringBuilder checkExchFaTypeQueryStr = new StringBuilder();
			checkExchFaTypeQueryStr.append(" SELECT ");
			checkExchFaTypeQueryStr.append(" 	COUNT(FST.FA_TYPE_CD) RMIMCNT ");
			checkExchFaTypeQueryStr.append(" FROM ");
			checkExchFaTypeQueryStr.append(" 	CI_FA_STEP_TYPE FST ");
			checkExchFaTypeQueryStr.append(" WHERE ");
			checkExchFaTypeQueryStr.append("    FST.FA_TYPE_CD = :faTypeCd ");
			checkExchFaTypeQueryStr.append("   AND FST.FA_STEP_TY_ACT_FLG IN (:removeMeter,:installMeter) ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement checkExchFaTypePrepStmt = createPreparedStatement(checkExchFaTypeQueryStr.toString());
			PreparedStatement checkExchFaTypePrepStmt = createPreparedStatement(checkExchFaTypeQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			checkExchFaTypePrepStmt.bindId("faTypeCd", faType.getId());
			checkExchFaTypePrepStmt.bindLookup("removeMeter", FieldActivityStepTypeActionLookup.constants.REMOVE_METER);
			checkExchFaTypePrepStmt.bindLookup("installMeter", FieldActivityStepTypeActionLookup.constants.INSTALL_METER);
			SQLResultRow stepCountRow = checkExchFaTypePrepStmt.firstRow();			
			checkExchFaTypePrepStmt.close();
			
			BigInteger stepCount = stepCountRow.getInteger("RMIMCNT");
			// 2015-05-26. SMiran. Defect 3226032. Start Change
			//if (stepCount.intValue() < 2){
			if (stepCount.intValue() < 1){
			// 2015-05-26. SMiran. Defect 3226032. End Change
				addError(CustomMessageRepositoryMGE.cint01810mtrCfgChgNonExchFa(faId.getTrimmedValue(), faType.getId().getIdValue()));
			}
			
			
		}

		// 2015-06-18. SMiran. Defect 3236175. Start Delete
		//private MeterRead addMeterRemovalRead(MeterConfiguration_Id effectiveMeterConfigId) {
		//	
		//	MeterReadCreator mrCreator = MeterReadCreator.Factory.newInstance();
		//	MeterReadCreatorData mrCreatorData = MeterReadCreatorData.Factory.newInstance(); 
		//	mrCreatorData.setCanStoreEstimatedRead(Bool.FALSE);
		//	mrCreatorData.setCanUseOnBill(Bool.TRUE);
		//	mrCreatorData.setIsInstallationRead(Bool.FALSE);
		//	mrCreatorData.setIsTrended(Bool.FALSE);
		//	if (notNull(meterReadSourceFound)){
		//		mrCreatorData.setMeterReadSource(meterReadSourceFound.getEntity());
		//	}
		//	mrCreatorData.setReadDateTime(workDateTime);
		//	List<MeterReadCreatorRegisterReadData> regReadDataList = new ArrayList<MeterReadCreatorRegisterReadData>();
		//	MeterReadCreatorRegisterReadData regReadData = MeterReadCreatorRegisterReadData.Factory.newInstance();
		//	regReadData.setReadSequence(reg1SeqFound);
		//	regReadData.setIsHighLowReviewed(Bool.TRUE);
		//	regReadData.setReadType(reg1ReadTypeFound);
		//	regReadData.setRegisterReading(reg1ReadingFound);
		//	regReadDataList.add(regReadData);
		//	if (reg2SeqFound.intValue() > 0){
		//		MeterReadCreatorRegisterReadData regReadData2 = MeterReadCreatorRegisterReadData.Factory.newInstance();
		//		regReadData2.setReadSequence(reg2SeqFound);
		//		regReadData2.setIsHighLowReviewed(Bool.TRUE);
		//		regReadData2.setReadType(reg2ReadTypeFound);
		//				regReadData2.setRegisterReading(reg2ReadingFound);
		//		regReadDataList.add(regReadData2);
		//	}
		//			mrCreatorData.setRegisterReadDataList(regReadDataList);
		//	MeterRead removalRead = mrCreator.addMeterRead(effectiveMeterConfigId.getEntity(), mrCreatorData);
		//	return removalRead;
		//}
		// 2015-06-18. SMiran. Defect 3236175. End Delete

		private void processFA() {
			
			// 2015-06-18. SMiran. Defect 3236175. Start Delete
			
			//Bool addMRSw;			
			
			//BusinessServiceInstance bsInstance = BusinessServiceInstance.create(CM_FA_COMPLETION_BS);
			//COTSInstanceNode C1FACompletionWithStepsGroup = bsInstance.getGroup("C1FACompletionWithSteps");
			//COTSInstanceNode C1FACompletionWithStepsServiceGroup = C1FACompletionWithStepsGroup.getGroup("C1FACompletionWithStepsService");
			//// Get Header Group
			//COTSInstanceNode headerGroup = C1FACompletionWithStepsServiceGroup.getGroup("C1FACompletionWithStepsHeader");
			//// Set Header
			//headerGroup.set("PageReadSW", Bool.FALSE);
			//headerGroup.set("FieldActivityID", faId.getTrimmedValue());
			//// Set Details
			//COTSInstanceNode detailsGroup = C1FACompletionWithStepsServiceGroup.getGroup("C1FACompletionWithStepsDetails");
			//detailsGroup.set("ActivityType", faType.getId().getTrimmedValue());
			//detailsGroup.set("ServicePointID", spId.getTrimmedValue());
			//detailsGroup.set("UploadStatus", FieldActivityUploadStatusLookup.constants.PENDING);
			//detailsGroup.set("WorkDateTime", workDateTime);
			//// Set Worked By if supplied
			//if (notNull(workedById)){
			//	detailsGroup.set("Workedby", workedById.getTrimmedValue());
			//}
			//// Set FA Comments if supplied
			//if (!isEmptyOrNull(faComments)){
			//	detailsGroup.set("LongDescription", faComments);
			//}			
						
			//// Set FA Steps
			//COTSInstanceNode stepsGroup = detailsGroup.getGroup("FASteps");
			//COTSInstanceNode stepsHeaderGroup = stepsGroup.getGroup("FAStepsHeader");
			//stepsHeaderGroup.set("FieldActivityID", faId.getTrimmedValue());
			//stepsHeaderGroup.set("ServicePointID", spId.getTrimmedValue());
			//// FA Step Node
			//COTSInstanceList faStepList = stepsGroup.getList("FAStepsRow");			
			
			//// Determine whether an "as found" meter reading was obtained. This will be used to complete either a read meter or remove meter step.
			//if (notNull(reg1ReadingFound)){
			//	// If the staging record contains an "as found" reading, create the meter read. If the FA type being completed has a "read meter" step,
			//	// this reading should be used to complete that step.
			//	BigDecimal readStepSequence = getStepSequence(FieldActivityStepTypeActionLookup.constants.READ_METER);
			//	if (readStepSequence.compareTo(BigDecimal.ZERO) == 1){
					
			//		// Set Add Meter Read Switch to True
			//		addMRSw = Bool.TRUE;
			//		// Add the FA Step					
			//		COTSInstanceListNode faStepListNode = addFAStep(
			//				faStepList
			//				,readStepSequence
			//				,FieldActivityStepTypeActionLookup.constants.READ_METER
			//				,badgeNumberFound
			//				,workDateTime
			//				,addMRSw
			//				,useOnBillFound
			//				,meterReadSourceFound
			//				);	
			//		// Create meter read
			//		createMeterReadForStep(
			//				faStepListNode
			//				// 2015-05-26. SMiran. Defect 3223676. Start Change
			//				//,badgeNumberFound
			//				,meterConfigIdFound
			//				// 2015-05-26. SMiran. Defect 3223676. End Change
			//				,BigDecimal.valueOf(reg1SeqFound.longValue())
			//				,reg1ReadTypeFound
			//				,reg1ReadingFound
			//				,reg1ReviewHiLoFound
			//				,BigDecimal.valueOf(reg2SeqFound.longValue())
			//				,reg2ReadTypeFound
			//				,reg2ReadingFound
			//				,reg2ReviewHiLoFound
			//				);
			//	}
				
			//	// If the FA type has a "remove meter" step, then the reading should be used to update the SP meter installation record 
			//	// and complete that step.
			//	BigDecimal removeStepSequence = getStepSequence(FieldActivityStepTypeActionLookup.constants.REMOVE_METER);
			//	if (removeStepSequence.compareTo(BigDecimal.ZERO) == 1){					
					
			//		// Set Add Meter Read Switch
			//		if (isRealMeterExchange.isFalse()){
			//			addMRSw = Bool.FALSE;
			//		}else{
			//			addMRSw = Bool.TRUE;
			//		}
			//		// Add the FA Step
			//		COTSInstanceListNode faStepListNode = addFAStep(
			//				faStepList
			//				,removeStepSequence
			//				,FieldActivityStepTypeActionLookup.constants.REMOVE_METER
			//				,badgeNumberFound
			//				,workDateTime
			//				,addMRSw
			//				,useOnBillFound
			//				,meterReadSourceFound
			//				);
			//		// Create meter read
			//		if (addMRSw.isTrue()){
			//			createMeterReadForStep(
			//					faStepListNode
			//					// 2015-05-26. SMiran. Defect 3223676. Start Change
			//					//,badgeNumberFound
			//					,meterConfigIdFound
			//					// 2015-05-26. SMiran. Defect 3223676. End Change
			//					,BigDecimal.valueOf(reg1SeqFound.longValue())
			//					,reg1ReadTypeFound
			//					,reg1ReadingFound
			//					,reg1ReviewHiLoFound
			//					,BigDecimal.valueOf(reg2SeqFound.longValue())
			//					,reg2ReadTypeFound
			//					,reg2ReadingFound
			//					,reg2ReviewHiLoFound
			//					);
			//		}
			//	}
			//}
			
			//// Determine whether an "as left" meter reading was obtained. This will be used to complete an install meter step. 
			//if (notNull(reg1ReadingLeft)){
			//	// If the FA type has an "install meter" step, then the reading should be used to add a new SP meter installation record to complete that step.
			//	BigDecimal installStepSequence = getStepSequence(FieldActivityStepTypeActionLookup.constants.INSTALL_METER);
			//	if (installStepSequence.compareTo(BigDecimal.ZERO) == 1){					
					
			//		if (notNull(reg1ReadingFound)){
			//			//Add 1 second to Work Date Time
			//			workDateTime = workDateTime.addSeconds(1);
			//		}
					
			//		// Set Add Meter Read Switch to True
			//		addMRSw = Bool.TRUE;
			//		// Add the FA Step
			//		COTSInstanceListNode faStepListNode = addFAStep(
			//				faStepList
			//				,installStepSequence
			//				,FieldActivityStepTypeActionLookup.constants.INSTALL_METER
			//				,badgeNumberLeft
			//				,workDateTime
			//				,addMRSw
			//				,useOnBillLeft
			//				,meterReadSourceLeft
			//				);
			//		// Create meter read
			//		createMeterReadForStep(
			//				faStepListNode
			//				// 2015-05-26. SMiran. Defect 3223676. Start Change
			//				//,badgeNumberLeft
			//				,meterConfigIdLeft
			//				// 2015-05-26. SMiran. Defect 3223676. End Change
			//				,BigDecimal.valueOf(reg1SeqLeft.longValue())
			//				,reg1ReadTypeLeft
			//				,reg1ReadingLeft
			//				,reg1ReviewHiLoLeft
			//				,BigDecimal.valueOf(reg2SeqLeft.longValue())
			//				,reg2ReadTypeLeft
			//				,reg2ReadingLeft
			//				,reg2ReviewHiLoLeft
			//				);
			//	}
			//}
			
			//// Add FA Characteristics
			//if (faCharList.size() > 0){
			//	COTSInstanceNode faCharGroup = detailsGroup.getGroup("FAUploadCharacteristics");
			//	COTSInstanceList faCharsList = faCharGroup.getList("FAUploadCharacteristicsRow");
			//	Iterator<CmCharacteristicTempData> faCharListIter = faCharList.iterator();
			//	while (faCharListIter.hasNext()){
			//		CmCharacteristicTempData tempData = faCharListIter.next();
			//		CharacteristicType charType = tempData.getCharType();
			//		String charVal = tempData.getCharVal();
			//		// Get Maximum sequence for FA ID and Char Type combination
			//		BigInteger maxSeq = getMaxSeq(charType);
			//		COTSInstanceListNode faCharsListNode = faCharsList.newChild();
			//		faCharsListNode.set("FieldActivityID", faId.getTrimmedValue());
			//		faCharsListNode.set("CharacteristicType", charType.getId().getTrimmedValue());
			//		faCharsListNode.set("Sequence", BigDecimal.valueOf(maxSeq.longValue()));
			//		if (charType.getCharacteristicType().isPredefinedValue()){
			//			faCharsListNode.set("CharacteristicValue", charVal.trim());
			//		}else if (charType.getCharacteristicType().isForeignKeyValue()){
			//			faCharsListNode.set("CharacteristicValueFK1", charVal.trim());
			//		}else{
			//			faCharsListNode.set("AdhocCharacteristicValue", charVal.trim());
			//		}
			//	}
			//}			
			
			//BusinessServiceDispatcher.execute(bsInstance);			
			
			// 2015-06-18. SMiran. Defect 3236175. End Delete
			
			// 2015-06-18. SMiran. Defect 3236175. Start Add
			
			// We can't use the base FA Completion service because it overrides the Meter Configuration Id
			// The base FA Completion service searches for the Meter Configuration Id using the Badge Number. We need to find
			// it by using the Serial Number because there are duplicate badge numbers
			FieldActivityUpload_DTO faUploadDto = createDTO(FieldActivityUpload.class);
			faUploadDto.setId(new FieldActivityUpload_Id(faId));
			faUploadDto.setUploadStatus(FieldActivityUploadStatusLookup.constants.PENDING);
			faUploadDto.setLongDescription(faComments);
			faUploadDto.setWorkDateTime(workDateTime);
			faUploadDto.setWorkedById(workedById);
			FieldActivityUpload faUpload = faUploadDto.newEntity();
			
			// Determine whether an "as found" meter reading was obtained. 
			// This will be used to complete either a read meter or remove meter step.
			if (notNull(reg1ReadingFound)){
				
	            //Start Add JVitug - B-13084 - 2020-08-13
                // If Meter Configuration is 001 and there is no Register 2 sequence found
                // e.g register 2 sequence found is zero, default the value of the 
                // second register
				// Start Change DLampa - E-13304 - 2026-08-07
                //if(meterConfigIdFound.getEntity().getMeterConfigurationType().getId().getTrimmedValue().
                //        equalsIgnoreCase(defaultSecondRegisterMeterConfigType.getId().getTrimmedValue())
                if (defaultSecondRegisterMeterConfigType.contains(meterConfigIdFound.getEntity().getMeterConfigurationType())
                // End Change DLampa - E-13304 - 2026-08-07
                        && reg2SeqFound.compareTo(BigInteger.ONE) < 0) {
                    reg2SeqFound = BigInteger.ONE.add(BigInteger.ONE);
                    reg2ReadTypeFound = ReadTypeLookup.constants.REGULAR;
                    //Calculate register reading
                     reg2ReadingFound = retrieveQuotientBetweenPriorReadingCCFUAndPriorReadingCCFC(meterConfigIdFound,
                            reg1SeqFound, 
                            reg1ReadTypeFound,
                            reg1ReadingFound,
                            reg2SeqFound,
                            reg2ReadTypeFound);
                     
                     reg2ReviewHiLoFound = YesNoOptionLookup.constants.NO;
                }
                //End Add JVitug - B-13084 - 2020-08-13
			    
				// If the staging record contains an "as found" reading, create the meter read. 
				// If the FA type being completed has a "read meter" step, this reading should be used to complete that step.
				BigInteger readStepSequence = getStepSequence(FieldActivityStepTypeActionLookup.constants.READ_METER);
				if (readStepSequence.intValue() > 0){
					
					// Add the meter read
					createMeterReadForStep(meterConfigIdFound
							, meterReadSourceFound, useOnBillFound, Bool.FALSE, workDateTime
							, reg1SeqFound, reg1ReadTypeFound, reg1ReadingFound, reg1ReviewHiLoFound
							, reg2SeqFound, reg2ReadTypeFound, reg2ReadingFound, reg2ReviewHiLoFound);
					
					// Create FA Step Upload
					FieldActivityStepUpload_DTO faStepUploadDto = createDTO(FieldActivityStepUpload.class);
					faStepUploadDto.setBadgeNumber(badgeNumberFound);
					faStepUploadDto.setEventDateTime(workDateTime);
					faStepUploadDto.setFaStepTypeAction(FieldActivityStepTypeActionLookup.constants.READ_METER);
					faStepUploadDto.setId(new FieldActivityStepUpload_Id(faUpload,readStepSequence));
					faStepUploadDto.setReadDateTime(workDateTime);
					faStepUploadDto.setStepUploadStatus(FieldActivityStepUploadStatusLookup.constants.PENDING);
					faStepUploadDto.newEntity();
				}
				
				/*
				 * Start Change - Defect 4465518 - 2020-08-07
				 */
				//// If the FA type has a "remove meter" step, then the reading should be used to update the SP meter installation record 
				//// and complete that step.
				//BigInteger removeStepSequence = getStepSequence(FieldActivityStepTypeActionLookup.constants.REMOVE_METER);
				
                // If the FA type has a required "remove meter" step, then the reading should be used to update the SP meter installation record 
                // and complete that step.
                BigInteger removeStepSequence = getRequiredStepSequence(FieldActivityStepTypeActionLookup.constants.REMOVE_METER);
                /*
                 * End Change - Defect 4465518 - 2020-08-07
                 */
                 
				if (removeStepSequence.intValue() > 0){
					
					if (isRealMeterExchange.isTrue()){					
						// Add the meter read
						createMeterReadForStep(meterConfigIdFound
								, meterReadSourceFound, useOnBillFound, Bool.FALSE, workDateTime
								, reg1SeqFound, reg1ReadTypeFound, reg1ReadingFound, reg1ReviewHiLoFound
								, reg2SeqFound, reg2ReadTypeFound, reg2ReadingFound, reg2ReviewHiLoFound);
					}
					
					// Create FA Step Upload
					FieldActivityStepUpload_DTO faStepUploadDto = createDTO(FieldActivityStepUpload.class);
					faStepUploadDto.setBadgeNumber(badgeNumberFound);
					faStepUploadDto.setEventDateTime(workDateTime);
					faStepUploadDto.setFaStepTypeAction(FieldActivityStepTypeActionLookup.constants.REMOVE_METER);
					faStepUploadDto.setId(new FieldActivityStepUpload_Id(faUpload,removeStepSequence));
					faStepUploadDto.setReadDateTime(workDateTime);
					faStepUploadDto.setStepUploadStatus(FieldActivityStepUploadStatusLookup.constants.PENDING);
					faStepUploadDto.newEntity();

				}
			}
			
			// Determine whether an "as left" meter reading was obtained. This will be used to complete an install meter step. 
			if (notNull(reg1ReadingLeft)){
				
				// If the FA type has an "install meter" step, then the reading should be used to add a new SP meter installation record 
				// to complete that step.
				BigInteger installStepSequence = getStepSequence(FieldActivityStepTypeActionLookup.constants.INSTALL_METER);
				if (installStepSequence.intValue() > 0){
					
					// Adjust Read Date Time for Exchange
					if (notNull(reg1ReadingFound)){
						//Add 1 second to Work Date Time
						workDateTime = workDateTime.addSeconds(1);
					}
					
					// 2015-07-21. SMiran. Defect 3249477. Start Add					
					// If the meterConfigIdLeft's effective date time is after the workDateTime, set it to workDateTime
					if (meterConfigIdLeft.getEntity().getEffectiveDateTime().isAfter(workDateTime)){
						Iterator<Register> regIter = meterConfigIdLeft.getEntity().getRegisters().iterator();
						while (regIter.hasNext()){
							// Update Register Effective Date Time
							Register reg = regIter.next();
							StringBuilder updateRegEffDttmStr = new StringBuilder("");
							updateRegEffDttmStr.append(" UPDATE CI_REG REG ");
							updateRegEffDttmStr.append(" SET REG.EFF_DTTM = :effDttm ");
							updateRegEffDttmStr.append(" WHERE REG.REG_ID = :regId ");
							//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
							//PreparedStatement updateSQL = createPreparedStatement(updateRegEffDttmStr.toString());
							PreparedStatement updateSQL = createPreparedStatement(updateRegEffDttmStr.toString(), getClass().getName());
							//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
							updateSQL.bindDateTime("effDttm", workDateTime);
							updateSQL.bindId("regId", reg.getId());
							updateSQL.execute();
							updateSQL.close();
						}
						// Update Meter Configuration Effective Date Time
						MeterConfiguration_DTO meterConfigDTO = meterConfigIdLeft.getEntity().getDTO();
						meterConfigDTO.setEffectiveDateTime(workDateTime);
						meterConfigIdLeft.getEntity().setDTO(meterConfigDTO);						
					}
					// 2015-07-21. SMiran. Defect 3249477. End Add
					
					//Start Add JVitug - B-13084 - 2020-07-07
                    // If Meter Configuration is 001 and there is no Reguster 2 sequence found
                    // e.g register 2 sequence found is zero, default the value of the 
                    // second register
					// Start Change DLampa - E-13304 - 2026-08-07
                    //Start Change JVitug - B-13084 - 2020-08-14
                    //if(meterConfigIdLeft.getEntity().getMeterConfigurationType().getId().getTrimmedValue().compareTo(
                            //defaultSecondRegisterMeterConfigType.getId().getTrimmedValue()) == 0
                            //&& reg2SeqLeft.compareTo(BigInteger.ONE) < 0) {
                    //if(meterConfigIdLeft.getEntity().getMeterConfigurationType().getId().getTrimmedValue().equalsIgnoreCase(
                    //        defaultSecondRegisterMeterConfigType.getId().getTrimmedValue())
                	if (defaultSecondRegisterMeterConfigType.contains(meterConfigIdLeft.getEntity().getMeterConfigurationType())		
                    // End CHange DLampa - E-13304 - 2026-08-07		
                            && reg2SeqLeft.compareTo(BigInteger.ONE) < 0) {
                    //End Change JVitug - B-13084 - 2020-08-14
                        reg2SeqLeft = BigInteger.ONE.add(BigInteger.ONE);
                        reg2ReadTypeLeft = ReadTypeLookup.constants.REGULAR;
                        //Calculate register reading
                         reg2ReadingLeft = retrieveQuotientBetweenPriorReadingCCFUAndPriorReadingCCFC(meterConfigIdLeft,
                                reg1SeqLeft, 
                                reg1ReadTypeLeft,
                                reg1ReadingLeft,
                                reg2SeqLeft,
                                reg2ReadTypeLeft);
                         
                         reg2ReviewHiLoLeft = YesNoOptionLookup.constants.NO;
                    }
                    //End Add JVitug - B-13084 - 2020-07-07
					
					// Add the meter read
					createMeterReadForStep(meterConfigIdLeft
							, meterReadSourceLeft, useOnBillLeft, Bool.TRUE, workDateTime
							, reg1SeqLeft, reg1ReadTypeLeft, reg1ReadingLeft, reg1ReviewHiLoLeft
							, reg2SeqLeft, reg2ReadTypeLeft, reg2ReadingLeft, reg2ReviewHiLoLeft);
					
					// Create FA Step Upload
					FieldActivityStepUpload_DTO faStepUploadDto = createDTO(FieldActivityStepUpload.class);
					faStepUploadDto.setBadgeNumber(badgeNumberLeft);
					faStepUploadDto.setEventDateTime(workDateTime);
					faStepUploadDto.setFaStepTypeAction(FieldActivityStepTypeActionLookup.constants.INSTALL_METER);
					faStepUploadDto.setId(new FieldActivityStepUpload_Id(faUpload,installStepSequence));
					faStepUploadDto.setReadDateTime(workDateTime);
					faStepUploadDto.setStepUploadStatus(FieldActivityStepUploadStatusLookup.constants.PENDING);
					faStepUploadDto.setOnOffStatus(OnOffStatusLookup.constants.ON);
					faStepUploadDto.newEntity();
					
				}
			}
			
			// Add FA Characteristics
			if (faCharList.size() > 0){
				Iterator<CmCharacteristicTempData> faCharListIter = faCharList.iterator();
				while (faCharListIter.hasNext()){
					CmCharacteristicTempData tempData = faCharListIter.next();
					CharacteristicType charType = tempData.getCharType();
					String charVal = tempData.getCharVal();
					// Get Maximum sequence for FA ID and Char Type combination
					BigInteger maxSeq = getMaxSeq(charType);
					FieldActivityUploadCharacteristic_Id faCharId = new FieldActivityUploadCharacteristic_Id(faUpload,charType,maxSeq);
					FieldActivityUploadCharacteristic_DTO faCharDto = createDTO(FieldActivityUploadCharacteristic.class);
					faCharDto.setId(faCharId);
					if (charType.getCharacteristicType().isPredefinedValue()){
						faCharDto.setCharacteristicValue(charVal.trim());
					}else if (charType.getCharacteristicType().isForeignKeyValue()){
						faCharDto.setCharacteristicValueForeignKey1(charVal.trim());
					}else{
						faCharDto.setAdhocCharacteristicValue(charVal.trim());
					}
					faCharDto.newEntity();
				}
			}	
			
			// If the FAs Dispatch Group is linked to an external system, set the Intermediate Status and set up log entry			
			if (notNull(faId.getEntity().getDispatchGroupId())){
				if (notNull(faId.getEntity().getDispatchGroupId().getEntity().getWorkforceManagementSystemId())){
					
					// Update the field activity row intermediate status to complete. Use SQL, do not trigger alg call.
					StringBuilder updateFaIntString = new StringBuilder("");
					updateFaIntString.append(" UPDATE ");
					updateFaIntString.append("	CI_FA FA ");
					updateFaIntString.append(" SET ");
					updateFaIntString.append("	FA.FA_INT_STATUS_FLG = :comp ");
					updateFaIntString.append(" WHERE ");
					updateFaIntString.append("	FA.FA_ID = :faId ");
					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					//PreparedStatement updateSQL = createPreparedStatement(updateFaIntString.toString());	
					PreparedStatement updateSQL = createPreparedStatement(updateFaIntString.toString(), getClass().getName());	
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					updateSQL.bindString("comp", "COMP", "FA_INT_STATUS_FLG");
					updateSQL.bindId("faId", faId);
					updateSQL.execute();
					updateSQL.close();
					
					// Create FA Log - FA is completed by external system.
					List<String> parmList = new ArrayList<String>();
					List<MessageParameterTypeLookup> messageParmTypeList = new ArrayList<MessageParameterTypeLookup>();
					MessageBuilder messageBuilder = MessageBuilder.Factory.newInstance();
					ServerMessage serverMessage = messageBuilder.buildMessage(BigInteger.valueOf(9), BigInteger.valueOf(16765)
							, parmList, messageParmTypeList);
					FieldActivityLog_DTO faLogDto = createDTO(FieldActivityLog.class);
					faLogDto.setId(new FieldActivityLog_Id(faId,getMaxLogSeq()));
					faLogDto.setLogType("EXCM");
					faLogDto.setUser(this.getActiveContextUser().getId().getTrimmedValue());
					faLogDto.setLogDateTime(this.getProcessDateTime());
					faLogDto.setDetails(serverMessage.getMessageText().trim());
					faLogDto.newEntity();
				}
			}
			
			// Complete the FA
			BusinessServiceInstance bsInstance = BusinessServiceInstance.create(CM_FA_COMPLETION_BS);
			COTSInstanceNode CmCompleteFADetails = bsInstance.getGroup("CmCompleteFADetails");
			CmCompleteFADetails.set("FieldActivityId", faId.getTrimmedValue());
			CmCompleteFADetails.set("FAUploadStagingId", faId.getTrimmedValue());
			CmCompleteFADetails.set("ActionCompleteSw", Bool.TRUE);
			BusinessServiceDispatcher.execute(bsInstance);
			
			// 2015-06-18. SMiran. Defect 3236175. End Add
			
			// 2015-07-09. SMiran. Defect 3249308. Start Add
			StringBuilder getStepError = new StringBuilder();
			getStepError.append(" SELECT ");
			getStepError.append(" 	EXP_MSG ");
			getStepError.append(" FROM ");
			getStepError.append(" 	CI_FA_STGUP_EXC ");
			getStepError.append(" WHERE ");
			getStepError.append("	FA_ID = :faId ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement stepErrorPrepStmt = createPreparedStatement(getStepError.toString());
			PreparedStatement stepErrorPrepStmt = createPreparedStatement(getStepError.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			stepErrorPrepStmt.bindId("faId", faId);
			SQLResultRow expMsg = stepErrorPrepStmt.firstRow();
			stepErrorPrepStmt.close();
			
			if (notNull(expMsg)){
				addError(CustomMessageRepositoryMGE.cint01810faComplError(faId.getTrimmedValue()
						, expMsg.getString("EXP_MSG")));
			}
			// 2015-07-09. SMiran. Defect 3249308. Start Add
		}

		// 2015-06-18. SMiran. Defect 3236175. Start Add
		private BigInteger getMaxLogSeq() {
			
			StringBuilder getMaxLogSeqStr = new StringBuilder();
			getMaxLogSeqStr.append(" SELECT ");
			getMaxLogSeqStr.append(" 	MAX(FAL.SEQ_NUM) + 1 AS MAXSEQ ");
			getMaxLogSeqStr.append(" FROM ");
			getMaxLogSeqStr.append(" 	CI_FA_LOG FAL ");
			getMaxLogSeqStr.append(" WHERE ");
			getMaxLogSeqStr.append("	FAL.FA_ID = :faId ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement maxSeqPrepStmt = createPreparedStatement(getMaxLogSeqStr.toString());
			PreparedStatement maxSeqPrepStmt = createPreparedStatement(getMaxLogSeqStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			maxSeqPrepStmt.bindId("faId", faId);
			SQLResultRow maxSeqRow = maxSeqPrepStmt.firstRow();
			maxSeqPrepStmt.close();
			
			return maxSeqRow.getInteger("MAXSEQ");
		}
		// 2015-06-18. SMiran. Defect 3236175. Start Add

		// 2015-06-18. SMiran. Defect 3236175. Start Change
		//private BigDecimal getStepSequence(FieldActivityStepTypeActionLookup stepType) {
		private BigInteger getStepSequence(FieldActivityStepTypeActionLookup stepType) {
		// 2015-06-18. SMiran. Defect 3236175. End Change

			StringBuilder getStepSequenceQueryStr = new StringBuilder();
			getStepSequenceQueryStr.append(" SELECT ");
			getStepSequenceQueryStr.append(" 	FST.STEP_SEQ_NBR ");
			getStepSequenceQueryStr.append(" FROM ");
			getStepSequenceQueryStr.append(" 	CI_FA_STEP_TYPE FST ");
			getStepSequenceQueryStr.append(" WHERE ");
			getStepSequenceQueryStr.append("    FST.FA_TYPE_CD = :faTypeCd ");
			getStepSequenceQueryStr.append("   AND FST.FA_STEP_TY_ACT_FLG = :faStepTypeActFlg ");	
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement stepSequencePrepStmt = createPreparedStatement(getStepSequenceQueryStr.toString());
			PreparedStatement stepSequencePrepStmt = createPreparedStatement(getStepSequenceQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			stepSequencePrepStmt.bindId("faTypeCd", faType.getId());
			stepSequencePrepStmt.bindLookup("faStepTypeActFlg", stepType);
			SQLResultRow stepSeqRow = stepSequencePrepStmt.firstRow();
			stepSequencePrepStmt.close();
			if (notNull(stepSeqRow)){
				// 2015-06-18. SMiran. Defect 3236175. Start Change
				//return stepSeqRow.getBigDecimal("STEP_SEQ_NBR");
				return stepSeqRow.getInteger("STEP_SEQ_NBR");
				// 2015-06-18. SMiran. Defect 3236175. End Change
			}
			
			// 2015-06-18. SMiran. Defect 3236175. Start Change
			//return BigDecimal.ZERO;
			return BigInteger.ZERO;
			//2015-06-18. SMiran. Defect 3236175. End Change
		}
		
        /*
         * Start Add - Defect 4465518 - 2020-08-07
         */
        private BigInteger getRequiredStepSequence(FieldActivityStepTypeActionLookup stepType) {
            StringBuilder getStepSequenceQueryStr = new StringBuilder();
            getStepSequenceQueryStr.append(" SELECT ");
            getStepSequenceQueryStr.append("    FST.STEP_SEQ_NBR ");
            getStepSequenceQueryStr.append(" FROM ");
            getStepSequenceQueryStr.append("    CI_FA_STEP_TYPE FST ");
            getStepSequenceQueryStr.append(" WHERE ");
            getStepSequenceQueryStr.append("    FST.FA_TYPE_CD = :faTypeCd ");
            getStepSequenceQueryStr.append("   AND FST.FA_STEP_TY_ACT_FLG = :faStepTypeActFlg ");   
            getStepSequenceQueryStr.append("   AND FST.OPTIONAL_SW = :false ");
            PreparedStatement stepSequencePrepStmt = createPreparedStatement(getStepSequenceQueryStr.toString(), getClass().getName());
            stepSequencePrepStmt.bindId("faTypeCd", faType.getId());
            stepSequencePrepStmt.bindLookup("faStepTypeActFlg", stepType);
            stepSequencePrepStmt.bindBoolean("false", Bool.FALSE);
            SQLResultRow stepSeqRow = stepSequencePrepStmt.firstRow();
            stepSequencePrepStmt.close();
            if (notNull(stepSeqRow)){
                return stepSeqRow.getInteger("STEP_SEQ_NBR");
            }
            
            return BigInteger.ZERO;
        }
        /*
         * End Add - Defect 4465518 - 2020-08-07
         */
         
		// 2015-06-18. SMiran. Defect 3236175. Start Delete
		//private COTSInstanceListNode addFAStep(COTSInstanceList faStepList, BigDecimal stepSeq, FieldActivityStepTypeActionLookup stepType
		//		, String badgeNumber, DateTime readDateTime, Bool addMrSw, YesNoOptionLookup useOnBill, MeterReadSource_Id meterReadSourceId) {
		//					
		//	Bool useOnBillSw = null;
		//	if (useOnBill.isNo()){
		//		useOnBillSw = Bool.FALSE;
		//	}else{
		//		useOnBillSw = Bool.TRUE;
		//	}
		//
		//	COTSInstanceListNode faStepListNode = faStepList.newChild();
		//	faStepListNode.set("FieldActivityID", faId.getTrimmedValue());
		//	faStepListNode.set("StepSequence", stepSeq);
		//	faStepListNode.set("StepUploadStatusFlag", FieldActivityStepUploadStatusLookup.constants.PENDING);
		//	faStepListNode.set("FAStepTypeAction", stepType);
		//	faStepListNode.set("BadgeNumber", badgeNumber);
		//	faStepListNode.set("StepMeterConfigId", meterConfigIdLeft.getTrimmedValue());
		//	faStepListNode.set("ReadDateTime", readDateTime);
		//	faStepListNode.set("ADDMRSW", addMrSw);
		//	faStepListNode.set("UseOnBill", useOnBillSw);
		//	if (notNull(meterReadSourceId)){
		//		faStepListNode.set("MeterReadSource", meterReadSourceId.getTrimmedValue());
		//	}
		//	if (stepType.isInstallMeter()){
		//		faStepListNode.set("OnOffStatus", MeterOnOffStatusLookup.constants.ON);
		//	}
		//	
		//	return faStepListNode;
		//	
		//}
		
		// 2015-05-26. SMiran. Defect 3223676. Start Change
		//private void createMeterReadForStep(COTSInstanceListNode faStepListNode, String badgeNumber
		// 2015-06-18. SMiran. Defect 3236175. Start Change
		//private void createMeterReadForStep(COTSInstanceListNode faStepListNode, MeterConfiguration_Id meterConfigId
		private MeterRead createMeterReadForStep(MeterConfiguration_Id meterConfigId
				, MeterReadSource_Id meterReadSourceId, YesNoOptionLookup useOnBill, Bool isInstallRead, DateTime readDateTime
		// 2015-06-18. SMiran. Defect 3236175. End Change
		// 2015-05-26. SMiran. Defect 3223676. End Change
				, BigInteger reg1Seq, ReadTypeLookup reg1ReadType, BigDecimal reg1Reading, YesNoOptionLookup reg1ReviewHiLo
				, BigInteger reg2Seq, ReadTypeLookup reg2ReadType, BigDecimal reg2Reading, YesNoOptionLookup reg2ReviewHiLo) {
			
			Bool reg1ReviewHiLoSw = Bool.FALSE;
			Bool reg2ReviewHiLoSw = Bool.FALSE;
			if (reg1ReviewHiLo.isYes()){
				reg1ReviewHiLoSw = Bool.TRUE;
			}
			if (notNull(reg2ReviewHiLo)){
				if (reg2ReviewHiLo.isYes()){
					reg2ReviewHiLoSw = Bool.TRUE;
				}
			}
			// 2015-06-18. SMiran. Defect 3236175. Start Add
			Bool useOnBillSw = Bool.FALSE;
			if (useOnBill.isYes()){
				useOnBillSw = Bool.TRUE;
			}
			// 2015-06-18. SMiran. Defect 3236175. End Add
			
			// 2015-06-18. SMiran. Defect 3236175. Start Delete
			//// 2015-05-26. SMiran. Defect 3223676. Start Change
			//// Get Register Id for Register 1
			////Register_Id registerId1 = getRegisterForSequence(badgeNumber, reg1Seq);		
			//Register_Id registerId1 = getRegisterForSequence(meterConfigId, reg1Seq);
			//// 2015-05-26. SMiran. Defect 3223676. End Change
			
			//// Register Reading
			//COTSInstanceNode registerReadingGroup = faStepListNode.getGroup("RegisterReading");
			//COTSInstanceList registerReadingList = registerReadingGroup.getList("RegisterReadingRow");
			//// Register Reading Node
			//COTSInstanceListNode register1ReadingListNode = registerReadingList.newChild();
			//register1ReadingListNode.set("Seq", reg1Seq);
			//register1ReadingListNode.set("RegisterID", registerId1.getTrimmedValue());
			//register1ReadingListNode.set("ReadType", reg1ReadType);
			//register1ReadingListNode.set("RegisterReading", reg1Reading);
			//register1ReadingListNode.set("ReviewHighLow", reg1ReviewHiLoSw);
			//register1ReadingListNode.set("Trended", Bool.FALSE);
			
			//// Register 2
			//if (reg2Seq.compareTo(BigDecimal.ZERO) == 1){
			//	// Get Register Id for Register 2
			//	// 2015-05-26. SMiran. Defect 3223676. Start Change
			//	//Register_Id registerId2 = getRegisterForSequence(badgeNumber, reg2Seq);
			//	Register_Id registerId2 = getRegisterForSequence(meterConfigId, reg2Seq);
			//	// 2015-05-26. SMiran. Defect 3223676. End Change
			//	if (isNull(registerId2)){
			//		addError(CustomMessageRepositoryMGE.cint01810readSeqNotFound(reg2Seq.toString()));
			//	}
			//	// Register Reading Node
			//	COTSInstanceListNode register2ReadingListNode = registerReadingList.newChild();
			//	register2ReadingListNode.set("Seq", reg2Seq);
			//	register2ReadingListNode.set("RegisterID", registerId2.getTrimmedValue());
			//	register2ReadingListNode.set("ReadType", reg2ReadType);
			//	register2ReadingListNode.set("RegisterReading", reg2Reading);
			//	register2ReadingListNode.set("ReviewHighLow", reg2ReviewHiLoSw);
			//	register2ReadingListNode.set("Trended", Bool.FALSE);
			//}
			// 2015-06-18. SMiran. Defect 3236175. End Delete
			
			// 2015-06-18. SMiran. Defect 3236175. Start Add
			MeterReadCreator mrCreator = MeterReadCreator.Factory.newInstance();
			MeterReadCreatorData mrCreatorData = MeterReadCreatorData.Factory.newInstance(); 
			mrCreatorData.setCanStoreEstimatedRead(Bool.FALSE);
			mrCreatorData.setCanUseOnBill(useOnBillSw);
			mrCreatorData.setIsInstallationRead(isInstallRead);
			mrCreatorData.setIsTrended(Bool.FALSE);
			if (notNull(meterReadSourceId)){
				mrCreatorData.setMeterReadSource(meterReadSourceId.getEntity());
			}
			mrCreatorData.setReadDateTime(readDateTime);
			List<MeterReadCreatorRegisterReadData> regReadDataList = new ArrayList<MeterReadCreatorRegisterReadData>();
			MeterReadCreatorRegisterReadData regReadData = MeterReadCreatorRegisterReadData.Factory.newInstance();
			regReadData.setReadSequence(reg1Seq);
			regReadData.setIsHighLowReviewed(reg1ReviewHiLoSw);
			regReadData.setReadType(reg1ReadType);
			regReadData.setRegisterReading(reg1Reading);
			regReadDataList.add(regReadData);
			// 2015-08-14. SMiranda. Defect 3272953. Start Change
			if (meterConfigId.getEntity().getRegisters().size() > 1){
				if (reg2Seq.intValue() > 0){
					MeterReadCreatorRegisterReadData regReadData2 = MeterReadCreatorRegisterReadData.Factory.newInstance();
					regReadData2.setReadSequence(reg2Seq);
					regReadData2.setIsHighLowReviewed(reg2ReviewHiLoSw);
					regReadData2.setReadType(reg2ReadType);
					regReadData2.setRegisterReading(reg2Reading);
					regReadDataList.add(regReadData2);
				}
			}
			// 2015-08-14. SMiranda. Defect 3272953. End Change
			mrCreatorData.setRegisterReadDataList(regReadDataList);
			MeterRead meterRead = mrCreator.addMeterRead(meterConfigId.getEntity(), mrCreatorData);
			return meterRead;
			// 2015-06-18. SMiran. Defect 3236175. End Add
		}

		// 2015-06-18. SMiran. Defect 3236175. Start Delete
		//// 2015-05-26. SMiran. Defect 3223676. Start Change
		////private Register_Id getRegisterForSequence(String badgeNumber, BigDecimal readSeq) {
		//private Register_Id getRegisterForSequence(MeterConfiguration_Id meterConfigId, BigDecimal readSeq) {
		//// 2015-05-26. SMiran. Defect 3223676. End Change
		//	StringBuilder getRegisterIdQueryStr = new StringBuilder();
		//	getRegisterIdQueryStr.append(" SELECT ");
		//	getRegisterIdQueryStr.append(" 	REG.REG_ID ");
		//	getRegisterIdQueryStr.append(" FROM ");
		//	// 2015-05-26. SMiran. Defect 3223676. Start Add
		//	getRegisterIdQueryStr.append(" 	CI_MTR_CONFIG MC, ");
		//	// 2015-05-26. SMiran. Defect 3223676. End Add
		//	getRegisterIdQueryStr.append(" 	CI_MTR MTR, ");
		//	getRegisterIdQueryStr.append(" 	CI_REG REG ");
		//	getRegisterIdQueryStr.append(" WHERE ");
		//	// 2015-05-26. SMiran. Defect 3223676. Start Change
		//	//getRegisterIdQueryStr.append("	MTR.BADGE_NBR = :badgeNumber ");
		//	getRegisterIdQueryStr.append("	MC.MTR_CONFIG_ID = :meterConfigId ");
		//	getRegisterIdQueryStr.append("	AND MTR.MTR_ID = MC.MTR_ID ");
		//	// 2015-05-26. SMiran. Defect 3223676. End Change
		//	getRegisterIdQueryStr.append("	AND REG.MTR_ID = MTR.MTR_ID ");
		//	getRegisterIdQueryStr.append("	AND REG.READ_SEQ = :readSeq ");
		//	getRegisterIdQueryStr.append("	AND REG.EFF_DTTM =  ");
		//	getRegisterIdQueryStr.append("	(SELECT MAX(REG2.EFF_DTTM) ");
		//	getRegisterIdQueryStr.append("	FROM CI_REG REG2 ");
		//	getRegisterIdQueryStr.append("	WHERE REG2.MTR_ID = REG.MTR_ID) ");
		//	
		//	PreparedStatement registerPrepStmt = createPreparedStatement(getRegisterIdQueryStr.toString());
		//	// 2015-05-26. SMiran. Defect 3223676. Start Change
		//	//registerPrepStmt.bindString("badgeNumber", badgeNumber, "BADGE_NBR");
		//	registerPrepStmt.bindId("meterConfigId", meterConfigId);
		//	// 2015-05-26. SMiran. Defect 3223676. End Change
		//	registerPrepStmt.bindBigInteger("readSeq", readSeq.toBigInteger());
		//	if (notNull(registerPrepStmt.firstRow())){
		//		Register_Id registerId = (Register_Id)registerPrepStmt.firstRow().getId("REG_ID", Register.class);
		//		registerPrepStmt.close();
		//		return registerId;
		//	}else{
		//		return null;				
		//	}
		//}
		// 2015-06-18. SMiran. Defect 3236175. End Delete

		private BigInteger getMaxSeq(CharacteristicType charType) {

			StringBuilder getMaxSeqNumQueryStr = new StringBuilder();
			getMaxSeqNumQueryStr.append(" SELECT ");
			getMaxSeqNumQueryStr.append(" 	NVL(MAX(SEQ_NUM),0) + 1 MAXSEQ ");
			getMaxSeqNumQueryStr.append(" FROM ");
			getMaxSeqNumQueryStr.append(" 	CI_FA_CHAR ");
			getMaxSeqNumQueryStr.append(" WHERE ");
			getMaxSeqNumQueryStr.append("	FA_ID = :faId ");
			getMaxSeqNumQueryStr.append("	AND CHAR_TYPE_CD = :charTypeCd ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement maxSeqPrepStmt = createPreparedStatement(getMaxSeqNumQueryStr.toString());
			PreparedStatement maxSeqPrepStmt = createPreparedStatement(getMaxSeqNumQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			maxSeqPrepStmt.bindId("faId", faId);
			maxSeqPrepStmt.bindId("charTypeCd", charType.getId());
			SQLResultRow maxSeqRow = maxSeqPrepStmt.firstRow();
			maxSeqPrepStmt.close();
			
			return maxSeqRow.getInteger("MAXSEQ");
		}

		@Override
		public boolean handleApplicationError(ApplicationError applicationError, ThreadWorkUnit unit) {
			
			// 2015-06-18. SMiran. Defect 3236175. Start Add
			errorCount++;
			if (errorCount > maxErrors){
				throw new RunAbortedException(CustomMessageRepositoryMGE.commMaxErrorLimitExceeded(String.valueOf(maxErrors)));
			}
			// 2015-06-18. SMiran. Defect 3236175. End Add
			
			CmInboundInterfaceStaging_Id inboundInterfaceStagingId = (CmInboundInterfaceStaging_Id) unit.getPrimaryId();
			String inboundInterfaceStagingKey = inboundInterfaceStagingId.getStagingKey();
			
			// Inboun Interface Staging record update date time
			DateTime stagingUpdateDateTime = this.getProcessDateTime();
			
			// Update Inbound Interface Staging record to Error status.
			updateInboundInterfaceStagingStatus(inboundInterfaceStagingKey.trim(), CmInterfaceStatusLookup.constants.ERROR, stagingUpdateDateTime);
			
			// Retrieve details of the error encountered.
			String errorCategory = BLANK_VALUE;
			String errorNumber = BLANK_VALUE;
			String errorCode = BLANK_VALUE;
			String errorDescription = BLANK_VALUE;
			String additionalInfo = BLANK_VALUE;
			if(notNull(applicationError)){
				ServerMessage serverMessage = applicationError.getServerMessage();
				if(notNull(serverMessage)){
					errorCategory = serverMessage.getCategory().toString().trim();
					errorNumber = serverMessage.getNumber().toString().trim();
					errorCode = errorCategory.concat(ERROR_CODE_DELIMITER).concat(errorNumber);
					errorDescription = serverMessage.getMessageText().trim();
					if (serverMessage.getLongDescription().length() > 0){
						if (serverMessage.getLongDescription().length() > 200){
							additionalInfo = serverMessage.getLongDescription().substring(0, 200);
						}else{
							additionalInfo = serverMessage.getLongDescription();
						}
					}					
				}
			}
			
			// Create a new Interface Error Log record for the error encountered.
			DateTime stagingCreationDateTime = (DateTime) unit.getSupplementallData("creationDateTime");			
			String logicalTransactionNumber = (String) unit.getSupplementallData("logicalTransactionNumber");
			String originatingKey = (String) unit.getSupplementallData("originatingKey");
			CmInterfaceErrorLogMaintenance interfaceErrorLogMaintenance = CmInterfaceErrorLogMaintenance.Factory.newInstance();
			interfaceErrorLogMaintenance.createInterfaceErrorLog(
					parmSourceSystemName, 
					parmTargetSystemName, 
					logicalTransactionNumber, 
					originationTable, 
					parmServiceTaskType.getId().getTrimmedValue(), 
					errorCode,
					errorDescription, 
					stagingCreationDateTime, 
					stagingUpdateDateTime, 
					parmTargetSystemName, 
					originatingKey, 
					additionalInfo, 
					ERROR_SOURCE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE);
			
			return true;
			
		}
		
		private void updateInboundInterfaceStagingStatus(String stagingKey, CmInterfaceStatusLookup status, DateTime dateTime){
			StringBuilder updateString = new StringBuilder("");
			updateString.append(" UPDATE ");
			updateString.append("	XXL_INT_INBOUND_STG IB ");
			updateString.append(" SET ");
			updateString.append("	IB.STATUS_FLAG = :status ");
			updateString.append("   , IB.UPDATE_DATETIME = :processDateTime ");
			updateString.append(" WHERE ");
			updateString.append("	IB.STAGING_KEY = :stagingKey ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement updateSQL = createPreparedStatement(updateString.toString());	
			PreparedStatement updateSQL = createPreparedStatement(updateString.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			updateSQL.bindString("stagingKey", stagingKey, "STAGING_KEY");
			updateSQL.bindDateTime("processDateTime", dateTime);
			updateSQL.bindString("status", status.trimmedValue(), "STATUS_FLAG");
			updateSQL.execute();
			updateSQL.close();		
		}

		//Start Add JVitug - B-13084 - 2020-07-07
        /**
         * Calculate the quotient between the Prior CCFU and the Prior CCFC
         * @param meterConfigIdLeft
         * @param reg1SeqLeft
         * @param reg1ReadTypeLeft
         * @param reg1ReadingLeft
         * @param reg2SeqLeft
         * @param reg2ReadTypeLeft
         * @return quotient
         */
        private BigDecimal retrieveQuotientBetweenPriorReadingCCFUAndPriorReadingCCFC(MeterConfiguration_Id meterConfigIdLeft,
                BigInteger reg1SeqLeft, 
                ReadTypeLookup reg1ReadTypeLeft,
                BigDecimal reg1ReadingLeft,
                BigInteger reg2SeqLeft,
                ReadTypeLookup reg2ReadTypeLeft) {
            BigDecimal returnValue = BigDecimal.ZERO;
            
            //The Meter configuration 001's setup is that the first register's for the CCFC and the 
            //second register is for CCFU
            BigDecimal priorCCFC = retrievePriorRead(meterConfigIdLeft, reg1SeqLeft, reg1ReadTypeLeft);
            BigDecimal priorCCFU = retrievePriorRead(meterConfigIdLeft, reg2SeqLeft, reg2ReadTypeLeft);
            
            //if PriorCCFC is not zero, calculate the quotient of the 
            //priorCCFU and priorCCFC
            if(notNull(priorCCFC) && notNull(priorCCFU) && priorCCFC.compareTo(BigDecimal.ZERO) != 0) {
                BigDecimal quotient = priorCCFU.divide(priorCCFC);
                returnValue = reg1ReadingLeft.multiply(quotient);
                
                //Scale the register read
                MeterConfigurationRegisters registers = meterConfigIdLeft.getEntity().getRegisters();
                for (Register register : registers) {
                    if(register.getSeq().compareTo(BigInteger.ONE.add(BigInteger.ONE)) == 0) {
                        returnValue = returnValue.setScale(register.getNumberOfDigitsRight().intValue(), BigDecimal.ROUND_HALF_UP);
                    }
                }
                
            }
            
            return returnValue;
        }
        
        /**
         * Retrieve the  meter read prior to the latest meter read of the meter configuration 
         * @param meterConfigId
         * @param registerSeq
         * @param readType
         * @return Prior Meter Read
         */
        private BigDecimal retrievePriorRead(MeterConfiguration_Id meterConfigId , BigInteger registerSeq , 
                ReadTypeLookup readType) {
            BigDecimal result = BigDecimal.ZERO;
            
            StringBuilder stringSql = new StringBuilder();

            stringSql.append("SELECT ");
            stringSql.append(    "MR.MTR_CONFIG_ID , ");
            stringSql.append(    "MR.MR_ID , ");
            stringSql.append(    "MR.READ_DTTM , ");
            stringSql.append(    "REG.READ_SEQ, ");
            stringSql.append(    "REG.READ_TYPE_FLG , ");
            stringSql.append(    "REG.REG_READING ");
            stringSql.append("FROM ");
            stringSql.append(    "CI_MR MR , ");
            stringSql.append(    "CI_REG_READ REG ");
            stringSql.append("WHERE MR.MTR_CONFIG_ID = :meterConfig ");
            stringSql.append("AND REG.MR_ID = MR.MR_ID "); 
            stringSql.append("AND REG.READ_SEQ = :registerSeq "); 
            stringSql.append("AND REG.READ_TYPE_FLG = :readType "); 
            stringSql.append("AND MR.READ_DTTM < ( ");
            stringSql.append(   "SELECT ");
            stringSql.append(       "MAX(MR2.READ_DTTM) ");
            stringSql.append(   "FROM ");
            stringSql.append(       "CI_MR MR2, ");
            stringSql.append(       "CI_REG_READ REG2 ");
            stringSql.append(   "WHERE MR2.MTR_CONFIG_ID = MR.MTR_CONFIG_ID  ");
            stringSql.append(   "AND MR2.MR_ID = REG2.MR_ID ");
            stringSql.append(   "AND REG2.READ_SEQ = REG.READ_SEQ ");
            stringSql.append(") ");
            stringSql.append("ORDER BY READ_DTTM DESC ");
            
            PreparedStatement sql = createPreparedStatement(stringSql.toString(), "Retrieve Prior Read");
            sql.bindId("meterConfig" , meterConfigId);
            sql.bindBigInteger("registerSeq", registerSeq);
            sql.bindLookup("readType", readType);
            
            SQLResultRow resultSet = sql.firstRow();
            sql.close();
            
            if(notNull(resultSet)) {
                result = resultSet.getBigDecimal("REG_READING");
            }
            
            
            return result;
        }
        //End Add JVitug - B-13084 - 2020-07-07

	}

}
