/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Algorithm - E-Bill Bill Message
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-04-04   RDizon  NM0079. Initial Version.
 * 2013-06-07   CVB     Add Bill Message only if it does not exist yet.
 * 2016-01-25   MPang	Updated for CCB v2.4 compilation.
 **************************************************************************/

package com.splwg.cm.domain.admin.customerClass;

import java.util.Iterator;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryResultRow;
import com.splwg.ccb.api.lookup.BillFormatLookup;
import com.splwg.ccb.api.lookup.BillStatusLookup;
//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.billMessage.BillMessageType;
import com.splwg.ccb.domain.admin.customerClass.CustomerClassPostBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.Bill;
import com.splwg.ccb.domain.billing.bill.BillMessage;
import com.splwg.ccb.domain.billing.bill.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.BillMessage_Id;
import com.splwg.ccb.domain.billing.bill.BillRouting;
import com.splwg.ccb.domain.billing.bill.BillRouting_DTO;
import com.splwg.ccb.domain.billing.bill.BillRouting_Id;
import com.splwg.ccb.domain.billing.bill.Bill_Id;
import com.splwg.ccb.domain.customerinfo.account.Account;*/
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.customerClass.algorithm.postBillCompletion.CustomerClassPostBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_Id;
import com.splwg.ccb.domain.billing.bill.entity.BillRouting;
import com.splwg.ccb.domain.billing.bill.entity.BillRouting_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillRouting_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation

/**
 * @author redizon
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (lookupName = billFormat, name = billFormat, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = billMessageCode, required = true, type = entity)})
 */
public class CmEBillBillMessageAlgComp_Impl 
		extends CmEBillBillMessageAlgComp_Gen 
		implements CustomerClassPostBillCompletionAlgorithmSpot {

    // Soft Parameters
    private BillFormatLookup parmBillFormat;
    private BillMessageType parmBillMessageCode;

    // Hard Parameters
    private Bill bill;

    // Properties
    private Account account;

    public void setBill(Bill bill) {
        this.bill = bill;
    }

    public void invoke() {
        // Retrieve the Algorithm Parameters
        parmBillFormat = getBillFormat();
        parmBillMessageCode = getBillMessageCode();

        account = bill.getAccount();

        // Check Current Bill's Bill Routing
        Query getCurrentBillRouting = cmGetExistingBillRouting(bill.getId());
        if (getCurrentBillRouting.listSize() > 0){

            // Retrieve Previous Bill
            QueryResultRow getPreviousBill = (QueryResultRow) cmGetPreviousBill().firstRow();

            if (notNull(getPreviousBill)){
                Bill_Id previousBillId = (Bill_Id) getPreviousBill.getId("billId", Bill.class);

                // Check Previous Bill's Bill Routing
                Query getPreviousBillRouting = cmGetExistingBillRouting(previousBillId);
                if (getPreviousBillRouting.listSize() == 0){

                    // Check if Previous Bill has existing Bill Message 
                    Query getExistingBillMessageOnPreviousBill = cmGetExistingBillMessage(previousBillId);
                    if (getExistingBillMessageOnPreviousBill.listSize() == 0){

                        // Retrieve previous Bill's Bill Format
                    	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                        // ListFilter listFilterBillFormatOfPreviousBill = previousBillId.getEntity().getRoutings().createFilter("ORDER BY this.id.sequence ASC");
                    	ListFilter listFilterBillFormatOfPreviousBill = previousBillId.getEntity().getRoutings().createFilter("ORDER BY this.id.sequence ASC", getClass().getName());
                    	//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                        BillRouting previousBillRouting = (BillRouting) listFilterBillFormatOfPreviousBill.firstRow();

                        // CVB - 2013-05-06 - Start
                        if (notNull(previousBillRouting)) {
                            // CVB - 2013-05-06 - End 


                            // Iterate through the Current Bill's Bill Routings with Bill Format
                            Iterator itrCurrentBillRouting = getCurrentBillRouting.iterate();
                            while(itrCurrentBillRouting.hasNext()){
                                BillRouting_Id billRoutingId = (BillRouting_Id) itrCurrentBillRouting.next();
                                BillRouting billRouting = billRoutingId.getEntity();

                                // Replace Current Routing's Bill Format with Previous Routing's Bill Format
                                BillRouting_DTO billRoutingDto = billRouting.getDTO();
                                billRoutingDto.setBillFormat(previousBillRouting.getBillFormat());
                                billRouting.setDTO(billRoutingDto);
                            }


                            // Create Bill Message if this is the first Bill after the Customer switched to "E-Bill" Format
                            // CVB - 2013-05-06 - Start
                            Query getExistingBillMessageOnCurrentBill = cmGetExistingBillMessage(bill.getId());
                            if (getExistingBillMessageOnCurrentBill.listSize() == 0){
                                cmCreateBillMessage(parmBillMessageCode);
                            }
                        }
                        // CVB - 2013-05-06 - End
                    }
                }
            }
        }
    }

    /**
     * Create a Bill Message that is of a specific Bill Message Type
     * @param billMessageType BillMessageType
     */
    private void cmCreateBillMessage(BillMessageType billMessageType) {
        // CVB - 2013-06-07 - Start
        BillMessage_Id existingBillMessageId = new BillMessage_Id(billMessageType, bill);
        BillMessage existingBillMessage = existingBillMessageId.getEntity();
        if (isNull(existingBillMessage)){
            // CVB - 2013-06-07 - End
            bill.getMessages().add(new BillMessage_DTO(), billMessageType.getId());
        }
    }

    /**
     * Get the existing Bill Message with the specified Bill Message Type
     * @param billId Bill_Id
     * @return query Query
     */
    private Query cmGetExistingBillMessage(Bill_Id billId) {
        Query query = createQuery("FROM BillMessage BM "
                + "WHERE BM.id.bill.id = :billId "
                //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                // + "AND BM.id.billMessage = :billMessageType");
                + "AND BM.id.billMessage = :billMessageType", getClass().getName());
        		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        query.bindId("billId", billId);
        query.bindId("billMessageType", parmBillMessageCode.getId());
        query.addResult("billMessage", "BM.id.billMessage");

        return query;
    }

    /**
     * Get the existing Bill Routing with the specified Bill Format
     * @param billId Bill_Id
     * @return query Query
     */
    private Query cmGetExistingBillRouting(Bill_Id billId) {
        Query query = createQuery("FROM BillRouting BR "
                + "WHERE BR.id.bill.id = :billId "
                //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                // + "AND BR.billFormat = :billFormat");
                + "AND BR.billFormat = :billFormat", getClass().getName());
        		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        query.bindId("billId", billId);
        query.bindLookup("billFormat", parmBillFormat);
        query.addResult("billRouting", "BR.id");

        return query;
    }

    /**
     * Get the previous Bill
     * @return query Query
     */
    private Query cmGetPreviousBill() {
        Query query = createQuery("FROM Bill B "
                + "WHERE B.account = :account "
                + "AND B.id <> :billId "
                //Start Change - 2016-01-25 - MPang -Updated for CCB v2.4 compilation
                // + "AND B.billStatus = :completeStatus");
                + "AND B.billStatus = :completeStatus", getClass().getName());
                //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        query.bindEntity("account", account);
        query.bindId("billId", bill.getId());
        query.bindLookup("completeStatus", BillStatusLookup.constants.COMPLETE);
        query.addResult("billId", "B.id");
        query.addResult("billDate", "B.billDate");        
        query.orderBy("billDate", Query.DESCENDING);

        return query;
    }
}
