/**************************************************************************
* Program Name: CmProcessPaymentArrangementAlgComp_Impl
* Program Title: CmProcessPaymentArrangementAlgComp_Impl
* Author: Alfonso Castano
* Creation Date: 2017-03-08
* Purpose: This algorithm will check if a self-service quote exists for 
*          the customer and if found, it will compare the payment amount
*          to the requested down payment amount. If the down payment
*          amount is satisfied, the necessary payment arrangement is
*          created for the customer.
*  
* Functional Spec: CCB-CC-002
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  CCB-CC-002.2      Alfonso Castano  2017-03-08    Initial Version
 *  Defect 3789264	  Marianne Pango   2017-07-04    Modified retrieveStandardSelfServiceQuote to
 *  												 handle multiple payment segments. 
 *  Defect 3793715    Alfonso Castano  2017-07-20    Modified to handle CWR 12 and CWR 50 
 *                                                   differently.  
 *  Defect 3814453    Justine Roxas    2017-08-01    Deferred raising "No downpayment" error until
 *                                                   after both char types sources are checked.
 *  Defect 3828670    Justine Roxas    2017-08-22    Added filter for process date + 1 when getting
 *                                                   the total payment made for the day.   
 *  Defect 3828670    Justine Roxas    2017-08-24    Changed service task retrieval to use the 
 *                                                   Payment Event creation date instead of the
 *                                                   process date.
 *  Defect 3843433    Sharmayne Felipe 2017-09-08    Call the CM-QuotePortalCWRQuoteInfo Business
 *                                                   Service to retrieve the reinstatement amount
 *                                                   instead of CmPledgeInfoByPerson.
 *  Defect 3855588    Sharmayne Felipe 2017-09-19    Call the CM-CWRGPAQuoteInfo BS 
 *                                                   instead of CM-QuotePortalCWRQuoteInfo BS.
 *  Defect 3843433    Sharmayne Felipe 2017-10-04    Updated the query used to retrieve existing
 *                                                   active quotes.
 *  CCB v2.6 Upgrade  Sharmayne Felipe 2018-07-25	 Remove trim from SQLS that are no longer
 *                                                   needed.                                                                          
 *  CCB-CC-023B-2     Kiran		       2018-08-29    Add a char CM-SSTSK  IF THE PAY AMOUNT IS < DOWN PAYMENT      
 *  Defect 4111822    Kiran            2018-09-12	 Deduct active pledge amount from down payment amount
 *  CCB v2.6 Upgrade  Sarah Romano	   2018-12-11	 1. Merged the changes from Spire PRD version for 
 *  												 the 2.4 to 2.6 Upgrade Activity.
 *  												 2. Removed unused imports
 *  											     3. Change the getMoney(string) deprecated method  
 *  Defect 4253862/   EQuint           2019-05-22    set prepared statement auto close  
 *  ID56 (Reopen)                                                                                                                                                                                                                                                                                         
 ************************************************************************************************/
package com.splwg.cm.domain.admin.customerClass.algorithm.payFreeze;

import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.businessService.BusinessServiceDispatcher;
import com.splwg.base.api.businessService.BusinessServiceInstance;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus_Id;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.currency.Currency_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristics;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.PaymentStatusLookup;
import com.splwg.ccb.domain.admin.customerClass.algorithm.payFreeze.CustomerClassPayFreezeAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.cm.api.lookup.CmQuotePortalParametersLookup;
import com.splwg.cm.api.lookup.CmServiceTaskCharacteristicTypesLookup;
import com.splwg.cm.api.lookup.ExternalSystemTypeLookup;
import com.splwg.cm.domain.common.businessService.CmPayOptionSelectionProcessingService;

/**
 * @author ACastano
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = selfServicePayOptionCharType, required = true, type = entity)})
 */
public class CmProcessPaymentArrangementAlgComp_Impl extends
        CmProcessPaymentArrangementAlgComp_Gen implements
        CustomerClassPayFreezeAlgorithmSpot {

    // Hard Parameters
    private Payment payment;
    
    // Soft Parameters
    private CharacteristicType selfServicePayOptionCharType;
    
    // Work Variable
    private ServiceTaskType quoteServiceTaskType;
    private BusinessObject quoteBo;
    private BusinessObjectStatus quoteActiveStatus;
    private CharacteristicType saCharType;
    private CharacteristicType selCharType;
    private CharacteristicType quoteSrcCharType;
    private CharacteristicType cwrDpCharType;
    private Money totalPayAmtForSaOnProcessDt;
    private String selfServicePayOptionCharVal;
    private Money downPaymentReinstatementAmt;
    // Defect 3793715 - 2017-07-20 - Start Add
    private CharacteristicType customDownPaymentCharType;
    private static final CharacteristicType_Id charTypeSerTask = new CharacteristicType_Id("CM-SSTSK");
    
    private Currency_Id currencyId;
    // Defect 3793715 - 2017-07-20 - End Add
    
    private CharacteristicType_Id StopSaCharType; 
    // Constants
    private static final String PAY_ARR_PROC_BUS_SVC = "CM-ProcPayArr";
    /*
     * Defect 3843433 (Reopen) - 2017-09-06 - Start Change
     */
    //private static final String PLEDGE_INFO_BY_PERSON_BUS_SVC = "CmPledgeInfoByPerson";
    /*
     * Defect 3855588 - 2017-09-19 - Start Change
     */
    //private static final String QUOTE_PORTAL_BS = "CM-QuotePortalCWRQuoteInfo";
    private static final String QUOTE_INFO_BS = "CM-CWRGPAQuoteInfo";
    /*
     * Defect 3855588 - 2017-09-19 - End Change
     */
    /*
     * Defect 3843433 (Reopen) - 2017-09-06 - End Change
     */
    // Defect 3793715 - 2017-07-20 - Start Add
    private static final String NO = "NO";
    // Defect 3793715 - 2017-07-20 - End Add

	private static final int CM = 0;


    
    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        selfServicePayOptionCharType = getSelfServicePayOptionCharType();
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(selfServicePayOptionCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        if (isNull(charEntityId.getEntity())) {
       //     addError(CustomMessageRepository.CC_002_2_invalidCharTypeForEntity(selfServicePayOptionCharType.getId().getTrimmedValue()
        //            , CharacteristicEntityLookup.constants.SERVICE_TASK.getLookupValue().fetchLanguageDescription().trim()));
        }
        
        // Quote Portal Parameters Feature Configuration
        FeatureConfiguration quotePortalParmsFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_QUOTE_PORTAL_PARAMETERS); 

        // Quote Service Task Type
        LookupValue optionType = CmQuotePortalParametersLookup.constants.QUOTE_SERVICE_TASK_TYPE.getLookupValue();
        String optionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
        ServiceTaskType_Id quoteServiceTaskTypeId = new ServiceTaskType_Id(optionValue);
        quoteServiceTaskType = quoteServiceTaskTypeId.getEntity();
        
        // Quote Business Object
        optionType = CmQuotePortalParametersLookup.constants.QUOTE_BUSINESS_OBJECT.getLookupValue();
        optionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
        BusinessObject_Id quoteBoId = new BusinessObject_Id(optionValue);
        quoteBo = quoteBoId.getEntity();
        
        // Quote Active Status
        optionType = CmQuotePortalParametersLookup.constants.QUOTE_BUSINESS_OBJECT_ACTIVE_STATUS.getLookupValue();
        optionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, optionType);
        BusinessObjectStatus_Id boStatusId = new BusinessObjectStatus_Id(quoteBo, optionValue);
        quoteActiveStatus = boStatusId.getEntity();
        
        // Service Task Characteristic Types Feature Configuration
        FeatureConfiguration svcTaskCharTypeFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_SERVICE_TASK_CHARACTERISTIC_TYPES);

        // Service Agreement Characteristic Type
        optionType = CmServiceTaskCharacteristicTypesLookup.constants.SA_ID_CHARACTERISTIC_TYPE.getLookupValue();
        optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
        saCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);  

        // Quote Source Characteristic Type
        optionType = CmServiceTaskCharacteristicTypesLookup.constants.QUOTE_SOURCE_CHARACTERISTIC_TYPE.getLookupValue();
        optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
        quoteSrcCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);
        
        // Selection Characteristic Type
        optionType = CmServiceTaskCharacteristicTypesLookup.constants.SELECTION_CHARACTERISTIC_TYPE.getLookupValue();
        optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
        selCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);
        
        // CWR Downpayment Characteristic Type
        optionType = CmServiceTaskCharacteristicTypesLookup.constants.CWR_DOWN_PAYMENT_CHARACTERISTIC_TYPE.getLookupValue();
        optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
        cwrDpCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);
        
        // Defect 3793715 - 2017-07-20 - Start Add
        // Custom Down Payment Characteristic Type
        optionType = CmServiceTaskCharacteristicTypesLookup.constants.CUSTOM_DOWN_PAYMENT_CHARACTERISTIC_TYPE.getLookupValue();
        optionValue = retrieveFeatureConfigurationOptionValue(svcTaskCharTypeFeatConfig, optionType);
        customDownPaymentCharType = validateServiceTaskCharacteristicType(svcTaskCharTypeFeatConfig, optionType, optionValue);
        // Defect 3793715 - 2017-07-20 - End Add
    }

    @Override
    public void invoke() {
        if (!this.isOnlineConnection()){
            return;
        }
        List selfServiceQuoteResult = retrieveStandardSelfServiceQuote(payment, quoteServiceTaskType, 
                        quoteActiveStatus, saCharType, quoteSrcCharType, selCharType);
        //Defect 3814453 - 2017-08-01 - Start Change
        //BigDecimal tempAmt = null;
        BigDecimal tempAmt = BigDecimal.ZERO;
        //Defect 3814453 - 2017-08-01 - End Change
        
        if (selfServiceQuoteResult.size() > 0){
            // Get first row
            QueryResultRow quoteResultRow = (QueryResultRow) selfServiceQuoteResult.get(0);
            ServiceTask_Id quoteServiceTaskId = (ServiceTask_Id)quoteResultRow.getId("SERVICETASKID", ServiceTask.class);
            ServiceAgreement_Id quoteSA = (ServiceAgreement_Id)quoteResultRow.getId("QUOTESA", ServiceAgreement.class);
            
            String quoteSrc = quoteResultRow.getString("QUOTESRC");
            ServiceTaskCharacteristics svcTaskChars = quoteServiceTaskId.getEntity().getCharacteristics();

            ListFilter<ServiceTaskCharacteristic> charFilter = svcTaskChars.createFilter("where this.id.characteristicType = :charType" 
                    , getClass().getName());
            charFilter.bindEntity("charType", selfServicePayOptionCharType);
            
            QueryIterator<ServiceTaskCharacteristic> iter = charFilter.iterate();
            if (iter.hasNext()) {
                ServiceTaskCharacteristic svcTaskChar = iter.next();                                
                selfServicePayOptionCharVal = svcTaskChar.getSearchCharacteristicValue();
                // Defect 3828670 - 2017-08-24 - Start Change
                //totalPayAmtForSaOnProcessDt = getTotalPayAmtForSaOnProcessDt(quoteSA);
                totalPayAmtForSaOnProcessDt = getTotalPayAmtForSaOnProcessDt(quoteSA, quoteServiceTaskId.getEntity().getCreationDateTime());
                // Defect 3828670 - 2017-08-24 - End Change
                //Defect 3814453 - 2017-08-01 - Start Add
                String downPaymentAmount;
                //Defect 3814453 - 2017-08-01 - End Add
                if (CmPayOptionSelectionProcessingService.NEW.equals(selfServicePayOptionCharVal)){
                    // Defect 3793715 - 2017-07-20 - Start Change
                    //tempAmt = getDownPaymentAmount(quoteServiceTaskId, cwrDpCharType);
                    //Defect 3814453 - 2017-08-01 - Start Change
                    //String downPaymentAmount = getDownPaymentAmount(quoteServiceTaskId, 
                    //        customDownPaymentCharType);
                    downPaymentAmount = getDownPaymentAmount(quoteServiceTaskId, 
                            customDownPaymentCharType);
                    //Defect 3814453 - 2017-08-01 - End Change
                    if (!isBlankOrNull(downPaymentAmount)){
                        if (!downPaymentAmount.toUpperCase().equals(NO)){
                            tempAmt = BigDecimal.valueOf(Double.parseDouble(downPaymentAmount));
                        }else{
                            downPaymentAmount = getDownPaymentAmount(quoteServiceTaskId, cwrDpCharType);
                            if (!isBlankOrNull(downPaymentAmount)){
                                tempAmt = BigDecimal.valueOf(Double.parseDouble(downPaymentAmount));
                            //Defect 3814453 - 2017-08-01 - Start Add
                            }else {
                              //  addError(CustomMessageRepository.CC_002_2_downpaymentAmtMissing(quoteServiceTaskId.getTrimmedValue()));
                            }
                            //Defect 3814453 - 2017-08-01 - End Add
                        }
                    //Defect 3814453 - 2017-08-01 - Start Add
                    }else { //Try retrieving the downpayment using the CWRDP char type instead
                        downPaymentAmount = getDownPaymentAmount(quoteServiceTaskId, cwrDpCharType);
                        if (!isBlankOrNull(downPaymentAmount)){
                            tempAmt = BigDecimal.valueOf(Double.parseDouble(downPaymentAmount));
                        }else {
                        //    addError(CustomMessageRepository.CC_002_2_downpaymentAmtMissing(quoteServiceTaskId.getTrimmedValue()));
                        }
                    //Defect 3814453 - 2017-08-01 - End Add
                    }
                    // Defect 3793715 - 2017-07-20 - End Change
                    downPaymentReinstatementAmt = new Money(tempAmt, totalPayAmtForSaOnProcessDt.getCurrencyId());
                }
                else if (CmPayOptionSelectionProcessingService.REINST.equals(selfServicePayOptionCharVal)){
                    /*
                     * Defect 3855588 - 2017-09-19 - Start Change
                     */
                    //downPaymentReinstatementAmt = retrieveReinstatementAmount(quoteSA.getEntity().getAccount().getMainPerson().getId(), quoteSA);
                    downPaymentReinstatementAmt = retrieveReinstatementAmount(quoteSA.getEntity().getAccount().getMainPerson().getId(), quoteSA, quoteServiceTaskId);
                    /*
                     * Defect 3855588 - 2017-09-19 - End Change
                     */
                    
                }
          // get the active pledge amount 4111822 Kiran 09/12/2018
                 
                
                StringBuilder activePledgeAmt = new StringBuilder();
                activePledgeAmt.append(" select NVL(SUM(ADHOC_CHAR_VAL), 0) ACTIVEPLEDGE FROM f1_svc_task_char WHERE CHAR_TYPE_CD = 'PLDGAMT' AND  ");
                activePledgeAmt.append(" F1_SVC_TASK_ID IN (select distinct a.F1_SVC_TASK_ID from f1_svc_task a, F1_SVC_TASK_CHAR b ");
                activePledgeAmt.append(" where a.F1_SVC_TASK_ID = b.F1_SVC_TASK_ID ");
                activePledgeAmt.append(" and b.CHAR_VAL_fk1 = :pledgeAccount ");
                activePledgeAmt.append(" and a.F1_STASK_TYPE_CD = 'PLEDGE' and a.BUS_OBJ_CD = 'CMPLEDGE' and a.F1_STASK_TYPE_CD = 'PLEDGE' ");
                activePledgeAmt.append(" and a.BO_STATUS_CD = 'ACTIVE' ");
                activePledgeAmt.append(" and b.CHAR_TYPE_CD = 'ACCOUNT' ) ");
              
                PreparedStatement pledgeAccount = createPreparedStatement(activePledgeAmt.toString(), getClass().getName());
                
                // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
                pledgeAccount.setAutoclose(false);
                // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
                
                pledgeAccount.bindId("pledgeAccount", quoteSA.getEntity().getAccount().getId());
                
                
                List<SQLResultRow> sqlResultRowList = pledgeAccount.list();
                
                pledgeAccount.close();
                Money totalActivePledges = Money.ZERO;
                if (sqlResultRowList.size() == 0) {
                	totalActivePledges = Money.ZERO;
                }
                else
                {
                	SQLResultRow sqlResultRow = sqlResultRowList.get(0);
                	BigDecimal referralAmount = sqlResultRow.getBigDecimal("ACTIVEPLEDGE");
                    // Retrieve the Account's Currency.
                    currencyId = quoteSA.getEntity().getAccount().getCurrency().getId();
                    
                	totalActivePledges = new Money(referralAmount, currencyId);
                	downPaymentReinstatementAmt = downPaymentReinstatementAmt.subtract(totalActivePledges);
                } 
 
                
                if (totalPayAmtForSaOnProcessDt.isGreaterThanOrEqual(downPaymentReinstatementAmt)){
                	// CCB-CC-023B-2 check the SA status
                	if (quoteSA.getEntity().getStatus().isStopped() || 
                			quoteSA.getEntity().getStatus().isPendingStop() || 
                			quoteSA.getEntity().getStatus().isClosed() ||
                	        quoteSA.getEntity().getServiceAgreementType().equals("WOGAS") )
                	{
                		
                        StringBuilder getSACharString = new StringBuilder();
                     // CCB-CC-023B-2 check if SA has Char already
                        getSACharString.append("SELECT 'X' FROM CI_SA_CHAR CH ");
                        getSACharString.append("WHERE CH.SA_ID = :saID ");
                        getSACharString.append("AND CH.CHAR_TYPE_CD = :serviceTask ");
                        getSACharString.append("AND CH.EFFDT = :serviceTaskDate ");
                      
                        
                        PreparedStatement prepState = createPreparedStatement(getSACharString.toString(), getClass().getName());
                        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
                        prepState.setAutoclose(false);
                        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
                        prepState.bindId("saID", quoteSA.getEntity().getId());
                        prepState.bindDate("serviceTaskDate",getProcessDateTime().getDate());
                        prepState.bindId("serviceTask", charTypeSerTask);	
                        
                        
                        List<SQLResultRow> resultList = prepState.list();
                        prepState.close();
                        if(resultList.isEmpty()){
                        	
                    // CCB-CC-023B-2 if not then create one    
                		startChanges();
                		CharacteristicType_Id  saStopcharTypeId = new CharacteristicType_Id("CM-SSTSK");
                		CharacteristicType  saStopcharType = saStopcharTypeId.getEntity();
                		CharacteristicTypeLookup saStopcharValueType = saStopcharType.getCharacteristicType();
       
                		
                        ServiceAgreementCharacteristic_DTO saChar_DTO = new ServiceAgreementCharacteristic_DTO();
                        ServiceAgreementCharacteristic_Id saCharId = new ServiceAgreementCharacteristic_Id(quoteSA.getEntity(), saStopcharType, getProcessDateTime().getDate());
                        
                        //ServiceAgreementCharacteristic_Id saCharId = new ServiceAgreementCharacteristic_Id(quoteSA.getEntity().getId(),StopSaCharType, getProcessDateTime().getDate());
                        
                        saChar_DTO.setId(saCharId);
                        
                        if (saStopcharValueType.isAdhocValue() || saStopcharValueType.isFileLocationValue()){
                        	saChar_DTO.setAdhocCharacteristicValue(quoteServiceTaskId.getTrimmedValue());
                        }
                        else if (saStopcharValueType.isPredefinedValue()){
                        	saChar_DTO.setCharacteristicValue(quoteServiceTaskId.getTrimmedValue());
						}
                        
            			else {
            				saChar_DTO.setCharacteristicValueForeignKey1(quoteServiceTaskId.getTrimmedValue());
						}
                        
                        saChar_DTO.newEntity();
                        saveChanges();
                        }
                        
                	}
                	else
                	{
                    BusinessServiceInstance busSvcInstance = BusinessServiceInstance.create(PAY_ARR_PROC_BUS_SVC);
                    busSvcInstance.set("selfServicePayOptionCharVal", selfServicePayOptionCharVal);
                    busSvcInstance.set("quoteSrc", quoteSrc);
                    busSvcInstance.set("quoteSA", quoteSA.getTrimmedValue());
                    BusinessServiceDispatcher.execute(busSvcInstance);
                	}
                }
            }
            iter.close();
        }
    }

    @Override
    public void setPayment(Payment arg0) {
        this.payment = arg0;
    }

    public Payment getPayment() {
        return payment;
    }

    /**
     * This method will retrieve the Standard Self Service Quote created for the Account on Process Date.
     * @param payment Payment
     * @param serviceTaskType QuoteServiceTaskType
     * @param businessObjectStatus ActiveQuoteStatus
     * @param characteristicType SaCharType
     * @param characteristicType QuoteSrcCharType
     * @param characteristicType SelCharType
     * @return list QuoteDetails
     */
    private List retrieveStandardSelfServiceQuote(Payment payment, ServiceTaskType quoteServiceTaskType,
                    BusinessObjectStatus activeQuoteStatus, CharacteristicType saCharType, 
                    CharacteristicType quoteSrcCharType, CharacteristicType selCharType){
        List result;
        StringBuilder str = new StringBuilder();
        str.append("SELECT A.F1_SVC_TASK_ID AS SERVICETASKID, D.SRCH_CHAR_VAL AS QUOTESA, C.SRCH_CHAR_VAL AS QUOTESRC ");
        str.append("FROM F1_SVC_TASK A, F1_SVC_TASK_CHAR B, F1_SVC_TASK_CHAR C, F1_SVC_TASK_CHAR D ");
        str.append("WHERE A.F1_STASK_TYPE_CD = :quoteServiceTaskType ");
        // Defect 3789264  - 2017-07-04 - Start Change
        // str.append(  "AND D.SRCH_CHAR_VAL = (SELECT SA_ID FROM CI_PAY_SEG WHERE PAY_ID = :paymentId) ");
        str.append(  "AND D.SRCH_CHAR_VAL IN (SELECT SA_ID FROM CI_PAY_SEG WHERE PAY_ID = :paymentId) ");
        // Defect 3789264  - 2017-07-04 - End Change
        // CCB v2.6 Upgrade - 2018-07-25 - Start Change
        //str.append(  "AND TRIM(A.BO_STATUS_CD) = :quoteActiveBo ");
        str.append(  "AND A.BO_STATUS_CD = :quoteActiveBo ");
        // CCB v2.6 Upgrade - 2018-07-25 - End Change
        str.append(  "AND TRUNC(A.CRE_DTTM) = :creDt ");
        str.append(  "AND A.F1_SVC_TASK_ID = B.F1_SVC_TASK_ID ");
        str.append(  "AND B.CHAR_TYPE_CD = :selCharType ");
        str.append(  "AND B.SRCH_CHAR_VAL = :standard ");
        str.append(  "AND B.F1_SVC_TASK_ID = c.F1_SVC_TASK_ID ");
        str.append(  "AND C.CHAR_TYPE_CD = :quoteSrcCharType ");
        str.append(  "AND C.SRCH_CHAR_VAL in (:cssCwr, :cssGpa) "); 
        str.append(  "AND C.F1_SVC_TASK_ID = d.F1_SVC_TASK_ID ");
        str.append(  "AND d.CHAR_TYPE_CD = :saCharType ");
        /*
         * Defect 3843433(Reopen) - 2017-10-04 - Start Add
         */
        str.append(  "ORDER BY A.CRE_DTTM DESC ");
        /*
         * Defect 3843433(Reopen) - 2017-10-04 - End Add
         */
        
        PreparedStatement retStdSelfServiceQuote = createPreparedStatement(str.toString(), 
                getClass().getName());
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        retStdSelfServiceQuote.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        retStdSelfServiceQuote.bindEntity("quoteServiceTaskType", quoteServiceTaskType);
        retStdSelfServiceQuote.bindId("paymentId", payment.getId());
        retStdSelfServiceQuote.bindStringProperty("quoteActiveBo", ServiceTask.properties.status, 
                activeQuoteStatus.getId().getStatus().trim());
        retStdSelfServiceQuote.bindDate("creDt", this.getProcessDateTime().getDate());
        retStdSelfServiceQuote.bindEntity("selCharType", selCharType);
        retStdSelfServiceQuote.bindStringProperty("standard", 
                ServiceTaskCharacteristic.properties.searchCharacteristicValue, 
                CmPayOptionSelectionProcessingService.STANDARD);
        retStdSelfServiceQuote.bindEntity("quoteSrcCharType", quoteSrcCharType);
        retStdSelfServiceQuote.bindStringProperty("cssCwr", 
                ServiceTaskCharacteristic.properties.searchCharacteristicValue, 
                CmPayOptionSelectionProcessingService.CWR);
        retStdSelfServiceQuote.bindStringProperty("cssGpa", 
                ServiceTaskCharacteristic.properties.searchCharacteristicValue, 
                CmPayOptionSelectionProcessingService.GPA);
        retStdSelfServiceQuote.bindEntity("saCharType", saCharType);
        retStdSelfServiceQuote.execute();   
        result = retStdSelfServiceQuote.list();
        retStdSelfServiceQuote.close();
        return result;
    }
    
    /**
     * This method will retrieve the Total Payment Amount made for a Service Agreement on the Process Date.
     * @param serviceAgreement_Id ServiceAgreementId
     * @return money ReinstatementAmount
     */
    // Defect 3828670 - 2017-08-24 - Start Change
    //private Money getTotalPayAmtForSaOnProcessDt(ServiceAgreement_Id saId){
    private Money getTotalPayAmtForSaOnProcessDt(ServiceAgreement_Id saId, DateTime svcTaskCreDttm){
    // Defect 3828670 - 2017-08-24 - End Change
        Money totalAmount = Money.ZERO;
        StringBuilder getAmountString = new StringBuilder();
        getAmountString.append("SELECT SUM(SEG.PAY_SEG_AMT) AMT ");
        getAmountString.append("FROM CI_PAY PAY, CI_PAY_SEG SEG, CI_PAY_EVENT EVT ");
        getAmountString.append("WHERE SEG.SA_ID = :saId ");
        // Defect 3828670 - 2017-08-22 - Start Change
        //getAmountString.append("AND EVT.PAY_DT = :processDt ");
        // Defect 3828670 - 2017-08-24 - Start Change
        //getAmountString.append("AND (EVT.PAY_DT = :processDt OR EVT.PAY_DT = :processDtPlusOne) ");
        getAmountString.append("AND EVT.CRE_DTTM > :svcTaskCreDttm ");
        // Defect 3828670 - 2017-08-24 - End Change
        // Defect 3828670 - 2017-08-22 - End Change
        getAmountString.append("AND SEG.PAY_ID = PAY.PAY_ID  ");
        getAmountString.append("AND PAY.PAY_EVENT_ID = EVT.PAY_EVENT_ID ");
        getAmountString.append("AND PAY.PAY_STATUS_FLG = :frozen ");

        PreparedStatement getAmountPrepStmt = createPreparedStatement(getAmountString.toString(), getClass().getName());
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        getAmountPrepStmt.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        getAmountPrepStmt.bindId("saId", saId);
        // Defect 3828670 - 2017-08-24 - Start Delete
        //getAmountPrepStmt.bindDate("processDt", getProcessDateTime().getDate());
        // Defect 3828670 - 2017-08-24 - End Delete
        // Defect 3828670 - 2017-08-22 - Start Add
        // Defect 3828670 - 2017-08-24 - Start Change
        //getAmountPrepStmt.bindDate("processDtPlusOne", getProcessDateTime().getDate().addDays(1));
        getAmountPrepStmt.bindDateTime("svcTaskCreDttm", svcTaskCreDttm);
        // Defect 3828670 - 2017-08-24 - End Change
        // Defect 3828670 - 2017-08-22 - End Add
        getAmountPrepStmt.bindLookup("frozen", PaymentStatusLookup.constants.FROZEN);
        getAmountPrepStmt.execute();
        
        SQLResultRow row = getAmountPrepStmt.firstRow();
        getAmountPrepStmt.close();

        if (notNull(row)){
        	// CCB v2.6 Upgrade - 2018-12-11 - Start Change
            //totalAmount = row.getMoney("AMT");
            totalAmount = row.getMoney("AMT", saId.getEntity().getAccount().getCurrency().getId());
            // CCB v2.6 Upgrade - 2018-12-11 - End Change
        }
        
        return totalAmount;
    }
    
    /**
     * This method will retrieve the Down payment Amount on the Quote.
     * @param serviceTaskId Service Task Id
     * @param characteristicType CwrDpCharType
     * @return String DownpaymentAmount
     */
    // Defect 3793715 - 2017-07-20 - Start Change
    //private BigDecimal getDownPaymentAmount(ServiceTask_Id svcTaskId, CharacteristicType cwrDpCharType){
    //    BigDecimal returnAmt = null;
    private String getDownPaymentAmount(ServiceTask_Id svcTaskId, CharacteristicType cwrDpCharType){
        String returnAmt = null;
    // Defect 3793715 - 2017-07-20 - End Change        
        
        StringBuilder getAmountString = new StringBuilder();
        getAmountString.append("SELECT SRCH_CHAR_VAL AS DOWNPAYAMT ");
        getAmountString.append("FROM F1_SVC_TASK_CHAR ");
        getAmountString.append("WHERE F1_SVC_TASK_ID = :svcTaskId ");
        getAmountString.append("AND CHAR_TYPE_CD = :dpCharType ");

        PreparedStatement getAmountPrepStmt = createPreparedStatement(getAmountString.toString(), getClass().getName());
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        getAmountPrepStmt.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        getAmountPrepStmt.bindId("svcTaskId", svcTaskId);
        getAmountPrepStmt.bindEntity("dpCharType", cwrDpCharType);
        getAmountPrepStmt.execute();
        SQLResultRow row = getAmountPrepStmt.firstRow();
        getAmountPrepStmt.close();

        //Defect 3814453 - 2017-08-01 - Start Delete 
        //if (isNull(row)){
        //    addError(CustomMessageRepository.CC_002_2_downpaymentAmtMissing(svcTaskId.getTrimmedValue()));
        //}
        //Defect 3814453 - 2017-08-01 - End Delete
        
        // Defect 3793715 - 2017-07-20 - Start Change        
        //returnAmt = BigDecimal.valueOf(Double.parseDouble(row.getString("DOWNPAYAMT")));
        //Defect 3814453 - 2017-08-01 - Start Change 
        if (notNull(row)) {
            returnAmt = row.getString("DOWNPAYAMT");
        }
        //Defect 3814453 - 2017-08-01 - End Change
        return returnAmt;
    }
    
    /**
     * This method will retrieve the Reinstatement Amount for the Service Agreement.
     * @param person_id Person Id
     * @param serviceAgreement_Id ServiceAgreement
     * @return money ReinstatementAmount
     */
    /*
     * Defect 3855588 - 2017-09-19 - Start Change
     */
    //private Money retrieveReinstatementAmount(Person_Id personId, ServiceAgreement_Id quoteSA) {
    private Money retrieveReinstatementAmount(Person_Id personId, ServiceAgreement_Id quoteSA, ServiceTask_Id serviceTaskId) {
    /*
     * Defect 3855588 - 2017-09-19 - End Change
     */
        /*
         * Defect 3843433 (Reopen) - 2017-09-06 - Start Delete
         */
        //Money reinstatementAmt = null;
        //BusinessServiceInstance busSvcInstance = BusinessServiceInstance.create(PLEDGE_INFO_BY_PERSON_BUS_SVC);
        //busSvcInstance.set("personId", personId.getTrimmedValue());
        //BusinessServiceInstance result = BusinessServiceDispatcher.execute(busSvcInstance);
        //COTSInstanceList accounts = result.getList("accounts");
        //Iterator<COTSInstanceListNode> accountList = accounts.iterator();
        //
        //while (accountList.hasNext()){
        //    COTSInstanceListNode account = accountList.next();
        //    COTSInstanceList serviceAgreements = account.getList("serviceAgreements");
        //    Iterator<COTSInstanceListNode> saList = serviceAgreements.iterator();
        //    while (saList.hasNext()){
        //        COTSInstanceListNode saListNode = saList.next();
        //        ServiceAgreement_Id saId = new ServiceAgreement_Id(saListNode.getString("serviceAgreement"));
        //        if (saId.equals(quoteSA)){
        //            reinstatementAmt = saListNode.getMoney("saReinstatementAmount");
        //        }
        //    }
        //}
        /*
         * Defect 3843433 (Reopen) - 2017-09-06 - End Delete
         */
        /*
         * Defect 3843433 (Reopen) - 2017-09-06 - Start Add
         */
        Money reinstatementAmt = Money.ZERO;
        
        /*
         * Defect 3855588 - 2017-09-19 - Start Change
         */
        //BusinessServiceInstance bsInstance = BusinessServiceInstance.create(QUOTE_PORTAL_BS);
        //bsInstance.set("sa", quoteSA.getTrimmedValue());
        //bsInstance.set("person", personId.getTrimmedValue());
        //bsInstance.set("cisDivision", quoteSA.getEntity().getServiceAgreementType().fetchIdDivision().getId().getTrimmedValue());
        //bsInstance.set("debtClass", quoteSA.getEntity().getServiceAgreementType().getDebtClass().getId().getTrimmedValue());
        //BusinessServiceInstance result = BusinessServiceDispatcher.execute(bsInstance);
        
        // Call the Quote Info Business Service.
        BusinessServiceInstance bsInstance = BusinessServiceInstance.create(QUOTE_INFO_BS);
        bsInstance.set("sa", quoteSA.getTrimmedValue());
        bsInstance.set("quote", serviceTaskId.getTrimmedValue());
        BusinessServiceInstance result = BusinessServiceDispatcher.execute(bsInstance);
        /*
         * Defect 3855588 - 2017-09-19 - End Change
         */
        
        // Reinstatement Amount
        if(notNull(result.getMoney("reinstatementAmount"))) {
            reinstatementAmt = result.getMoney("reinstatementAmount");
        }
        /*
         * Defect 3843433 (Reopen) - 2017-09-06 - End Add
         */
        return reinstatementAmt;
    }
    
    /**
     * This method will retrieve feature configuration
     * @param lookup ExternalSystemTypeLookup
     * @return featureConfiguration FeatureConfiguration
     */
    private FeatureConfiguration retrieveFeatureConfiguration(ExternalSystemTypeLookup featureType) {
        FeatureConfiguration featureConfiguration = null;

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" FROM FeatureConfiguration fc ");
        stringBuilder.append(" WHERE fc.featureType = :featureType ");

        Query query = createQuery(stringBuilder.toString(), getClass().getName());
        query.bindLookup("featureType", featureType);

        if (query.list().isEmpty()) {
       //     addError(CustomMessageRepository.CC_002_2_noFeatureConfigurationRetrieved(featureType.getLookupValue().fetchLanguageDescription()));
        }
        else if (query.list().size() > 1) {
       //     addError(CustomMessageRepository.CC_002_2_multipleFeatureConfigurationRetrieved(featureType.getLookupValue().fetchLanguageDescription()));
        }
        else {
            featureConfiguration = (FeatureConfiguration) query.firstRow();
        }

        return featureConfiguration;
    }
    
    /**
     * This method will retrieve feature configuration option value
     * @param featureConfiguration FeatureConfiguration
     * @param optionType String
     * @return optionValue String
     */
    private String retrieveFeatureConfigurationOptionValue(FeatureConfiguration featureConfiguration, LookupValue lookupValue) {
        String optionValue = "";

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" FROM FeatureConfigurationOption fco ");
        stringBuilder.append(" WHERE fco.id.workforceManagementSystem = :workforceManagementSystem ");
        stringBuilder.append(" AND fco.id.optionType = :optionType ");

        Query query = createQuery(stringBuilder.toString(), getClass().getName());
        
        query.bindEntity("workforceManagementSystem", featureConfiguration);
        query.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, lookupValue.fetchIdFieldValue().trim());   
        query.addResult("value", "fco.value");

        if (query.list().isEmpty()) {
     //       addError(CustomMessageRepository.CC_002_2_noOptionvalueRetrieved(featureConfiguration.getId().getTrimmedValue(), lookupValue.fetchLanguageDescription()));
        }
        else if (query.list().size() > 1) {
       //     addError(CustomMessageRepository.CC_002_2_multipleOptionvalueRetrieved(featureConfiguration.getId().getTrimmedValue(), lookupValue.fetchLanguageDescription()));
        }
        else {
            optionValue = (String) query.firstRow();
        }

        return optionValue.trim();
    }
    
    /**
     * This method will validate Service Task Characteristic Type
     * @param featConfig FeatureConfiguration
     * @param optionType LookupValue
     * @param charTypeStr String
     * @return charType CharacteristicType
     */
    private CharacteristicType validateServiceTaskCharacteristicType(FeatureConfiguration featConfig, LookupValue optionType, String charTypeStr) {
        CharacteristicType_Id charTypeId = new CharacteristicType_Id(charTypeStr);
        CharacteristicType charType = charTypeId.getEntity();

        if (isNull(charType)) {
       //     addError(CustomMessageRepository.CC_002_2_invalidCharType(optionType.fetchLanguageDescription(), charTypeStr));
        }

        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        if (isNull(charEntityId.getEntity())) {
        //    addError(CustomMessageRepository.CC_002_2_invalidCharTypeForEntity(charTypeStr, "Service Task"));
        }

        return charType;
    }
}
