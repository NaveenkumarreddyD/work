/**************************************************************************
* Program Name: CmBudgetChangeBillTrueUpAlgComp_Impl
* Program Title: CmBudgetChangeBillTrueUpAlgComp_Impl
* Author: Marianne Pango
* Creation Date: 2017-09-07
* Purpose: This algorithm is a Clone and convert to java base COBOL code 
* CIPGTTUX and add new functionality when the budget is trued up. 
* This algorithm will create a temporary message on the Account that have 
* been trued-up.  
*  
* Functional Spec: SA-69274
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  SA-69274          Marianne Pango   2017-09-07    Initial Version
 *  
 ************************************************************************************************/
package com.splwg.cm.domain.admin.budgetPlan.algorithm.budgetTrueUp;

import java.math.BigInteger;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.algorithmType.AlgorithmTypeParameter_Id;
import com.splwg.base.domain.common.algorithmType.AlgorithmTypeParameter_LanguageId;
import com.splwg.ccb.api.lookup.BillMessageTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.budgetPlan.algorithm.budgetTrueUp.BudgetTrueUpAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountMessage_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountMessages;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author MPang
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = tolerancePercentage, required = true, type = integer)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = budgetTruedUpBillMessage, required = true, type = entity)
 *            })
 */
public class CmBudgetChangeBillTrueUpAlgComp_Impl extends
		CmBudgetChangeBillTrueUpAlgComp_Gen implements
		BudgetTrueUpAlgorithmSpot {

	// Hard Parameter
	private Bool isTruedUp;
	private Money suggestedBudgetAmount, totalBudgetAmount;
	private Account account;
	private Date budgetDate;
	
	// Soft Parameter
	private BigInteger tolerancePercentage;
	private BillMessageType budgetTruedUpBillMessage;
	
	// Work Variable
	private Bool isBudgetUpdated = Bool.FALSE;
	
	@Override
	public Bool getIsTruedUp() {
		return isTruedUp;
	}

	@Override
	public Money getSuggestedBudgetAmount() {
		return suggestedBudgetAmount;
	}

	@Override
	public Money getTotalBudgetAmount() {
		return totalBudgetAmount;
	}

	@Override
	public void setAccount(Account arg0) {
		account = arg0;
	}

	@Override
	public void setBudgetDate(Date arg0) {
		budgetDate = arg0;
	}
	
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		tolerancePercentage = getTolerancePercentage();
		if(tolerancePercentage.compareTo(BigInteger.ZERO) <= 0 || tolerancePercentage.compareTo(BigInteger.valueOf(999)) >= 0) {
			// Add error
			addError(CustomMessageRepository.SA_69274_parameterMustBeBetweenZeroAnd999(this.getAlgorithm().getId().getTrimmedValue()
					, getAlgorithmParameterName(10), tolerancePercentage.toString()));
		}
		
		budgetTruedUpBillMessage = getBudgetTruedUpBillMessage();
		
	}
	@Override
	public void invoke() {
		// Get Account's Suggested Budget Amount
		suggestedBudgetAmount = account.recommendBudgetAmount(budgetDate, account.getBudgetPlanId().getEntity());
		// Get the Account's Total Budget Amount
		totalBudgetAmount = account.calculateTotalBudgetAmount(budgetDate);
		// Calculate the variance between the total budget amount and the suggested budget amount
		BigDecimal variancePercentage = suggestedBudgetAmount.getAmount().subtract(totalBudgetAmount.getAmount()).abs().divide(totalBudgetAmount.getAmount()).multiply(BigDecimal.valueOf(BigInteger.valueOf(100).longValue()));
		// If variance percentage is greater than the input threshold then true up the budgets
		if (variancePercentage.longValue() > tolerancePercentage.longValue()) {
			// Perform budget true up method
			budgetTrueUp();
			isTruedUp = Bool.TRUE;
		} else {
			isTruedUp = Bool.FALSE;
		}
	}
	
	/**
	 * This method will determine the SAs eligibility, 
	 * if eligible bill message will be added to account
	 */
	private void budgetTrueUp() {
		
		// Retrieve all Budgetable SAs
		List<SQLResultRow> budgetableSasList;
        
		StringBuilder str = new StringBuilder();
        str.append("SELECT SA.SA_ID ");
        str.append("FROM CI_SA SA, CI_SA_TYPE SATY ");
        str.append("WHERE SA.CIS_DIVISION = SATY.CIS_DIVISION ");
        str.append("AND SA.SA_TYPE_CD = SATY.SA_TYPE_CD ");
        str.append("AND SA.SA_STATUS_FLG < :stopped ");
        str.append("AND SATY.ELIG_BUDGET_SW = :true ");
        str.append("AND (SA.START_DT <= :budgetDate ");
        str.append(		"AND (SA.END_DT IS NULL ");
        str.append(		"OR (SA.END_DT IS NOT NULL ");
        str.append(		"AND SA.END_DT >= :budgetDate))) ");
        str.append("AND SA.ACCT_ID = :acctId ");
        
        PreparedStatement budgetableSasPs = createPreparedStatement(str.toString(), getClass().getName());
        budgetableSasPs.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
        budgetableSasPs.bindBoolean("true", Bool.TRUE);
        budgetableSasPs.bindDate("budgetDate", budgetDate);
        budgetableSasPs.bindEntity("acctId", account);
        
        budgetableSasPs.execute();   
        budgetableSasList = budgetableSasPs.list();
        budgetableSasPs.close();
        
        if(budgetableSasList.size() == 0) {
        	// Add error
        	addError(CustomMessageRepository.SA_69274_noBudgetableSAFound(account.getId().getIdValue()));
        	
        }
        
        ServiceAgreement sa = null;
        for(SQLResultRow row:budgetableSasList) {
        	sa = row.getEntity("SA_ID", ServiceAgreement.class);
        	// Check if budget eligibility is overridden
        	Bool isBudgetEligibilityOverriden = sa.determineBudgetEligibilityOverride(budgetDate);
        	// If the determineBudgetEligibilityOverride method returns false, it means that the SA is eligible for budget
        	if(isBudgetEligibilityOverriden.isFalse()) {
        		// Get Suggested budget Amount for this SA
        		Money recommendedBugetAmount = sa.recommendBudgetAmount(budgetDate, account.getBudgetPlanId().getEntity());
        		// Add  the Suggested budget Amount for this SA
        		sa.turnOnBudgetForServiceAgreement(budgetDate, recommendedBugetAmount);
        		
				isBudgetUpdated = Bool.TRUE;
        		
        	}
        }
		
		if (isBudgetUpdated.isTrue()) {
			// Add temporary bill message on the Account for a budget that's been trued up
        		AccountMessages acctMessages = account.getMessages();
        		AccountMessage_DTO acctMessageDTO = acctMessages.newChildDTO();
        		acctMessageDTO.setBillMessageType(BillMessageTypeLookup.constants.TEMPORARY);
        		acctMessages.add(acctMessageDTO, budgetTruedUpBillMessage.getId());
		}
	}
	
	 /**
     * Get Algorithm Parameter Name
     * @param paramSeq
     * @return paramName - Algorithm Parameter Name
     */
	private String getAlgorithmParameterName(int paramSeq){

		String paramName = "";
		AlgorithmTypeParameter_Id algorithmTypeParameterId = new AlgorithmTypeParameter_Id(getAlgorithm().getAlgorithmType(), BigInteger.valueOf(paramSeq));
		AlgorithmTypeParameter_LanguageId algorithmTypeParameterLanguageId = new AlgorithmTypeParameter_LanguageId(
				algorithmTypeParameterId, getActiveContextLanguage().getId());
		paramName = algorithmTypeParameterLanguageId.getParent().fetchLanguageParameterLabel();

		return paramName;
	}

}
