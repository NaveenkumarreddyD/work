/*
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Batch process to tag all existing open To Do Entries with a CIS Division 
 * characteristic 
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:                by:                 Reason:                                                                                                   
 * YYYY-MM-DD                         
 * 2021-02-06           DLampa              B-17517.6. Initial Version. 
 * 
 *******************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristics;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;


/**
 * @author dlampa
 *
 @BatchJob (multiThreaded = true, rerunnable = false,
 *      modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = ACCT_ID_CHAR_TYPE, type = entity, entityName = characteristicType, required = true)
 *                       , @BatchJobSoftParameter (name = PREM_ID_CHAR_TYPE, type = entity, entityName = characteristicType, required = true)
 *                       , @BatchJobSoftParameter (name = PER_ID_CHAR_TYPE, type = entity, entityName = characteristicType, required = true)
 *                       , @BatchJobSoftParameter (name = SA_ID_CHAR_TYPE, type = entity, entityName = characteristicType, required = true)
 *                       , @BatchJobSoftParameter (name = SP_ID_CHAR_TYPE, type = entity, entityName = characteristicType, required = true)
 *                       , @BatchJobSoftParameter (name = CIS_DIV_CHAR_TYPE, type = entity, entityName = characteristicType, required = true)})
 */

public class CmDefaultToDoCisDivBatch extends
        CmDefaultToDoCisDivBatch_Gen {  

    //Logger
    private static final Logger logger= LoggerFactory.getLogger(CmDefaultToDoCisDivBatch.class);    

    // Soft parameters
    private static CharacteristicType accountIdCharType;
    private static CharacteristicType premiseIdCharType;
    private static CharacteristicType personIdCharType;
    private static CharacteristicType saIdCharType;
    private static CharacteristicType spIdCharType;
    private static CharacteristicType cisDivisionCharType;
        
    @Override
    public JobWork getJobWork() {
        
        // Retrieve all open To Do entries 
        StringBuilder queryStr = new StringBuilder("");

        queryStr.append("SELECT TD.TD_ENTRY_ID ");
        queryStr.append("FROM CI_TD_ENTRY TD ");              
        queryStr.append("WHERE TD.ENTRY_STATUS_FLG <> :entryStatusComplete ");
        queryStr.append(  "AND NOT EXISTS (SELECT 'X' ");
        queryStr.append(                  "FROM CI_TD_ENTRY_CHA TC ");
        queryStr.append(                  "WHERE TC.TD_ENTRY_ID = TD.TD_ENTRY_ID  ");
        queryStr.append(                    "AND TC.CHAR_TYPE_CD = :cisDivCharType) ");
        queryStr.append("ORDER BY TD.TD_ENTRY_ID ASC");
      
        PreparedStatement openToDoEntriesQuery = createPreparedStatement(queryStr.toString(), getClass().getName());
        
        openToDoEntriesQuery.bindLookup("entryStatusComplete", ToDoEntryStatusLookup.constants.COMPLETED);
        openToDoEntriesQuery.bindEntity("cisDivCharType", cisDivisionCharType);

        List<ThreadWorkUnit> threadWorkUnitList = new ArrayList<ThreadWorkUnit>();
        QueryIterator<SQLResultRow> iterator = openToDoEntriesQuery.iterate();
        QueryResultRow row = null;
        ThreadWorkUnit threadWorkUnit = null;
        while (iterator.hasNext()) {
            row = iterator.next();
                
            threadWorkUnit = new ThreadWorkUnit();
            threadWorkUnit.setPrimaryId(new ToDoEntry_Id(row.getString("TD_ENTRY_ID")));
            threadWorkUnitList.add(threadWorkUnit);         
        }
        iterator.close();
        openToDoEntriesQuery.close();

        return createJobWorkForThreadWorkUnitList(threadWorkUnitList);
        
    }

    public Class<CmDefaultToDoCisDivBatchWorker> getThreadWorkerClass() {
        return CmDefaultToDoCisDivBatchWorker.class;
    }

    @Override
    public void validateSoftParameters(boolean arg0){
        
        accountIdCharType = getParameters().getACCT_ID_CHAR_TYPE();
        premiseIdCharType = getParameters().getPREM_ID_CHAR_TYPE();
        personIdCharType = getParameters().getPER_ID_CHAR_TYPE();
        saIdCharType = getParameters().getSA_ID_CHAR_TYPE();
        spIdCharType = getParameters().getSP_ID_CHAR_TYPE();
        cisDivisionCharType = getParameters().getCIS_DIV_CHAR_TYPE();   
        
		CharacteristicEntity_Id charEntity = new CharacteristicEntity_Id(accountIdCharType, CharacteristicEntityLookup.constants.TO_DO_ENTRY);
		if(isNull(charEntity.getEntity())){
		  addError(CustomMessageRepositorySpireOne.B17517_InvalidCharType(accountIdCharType.getId().getIdValue().trim()));
		}
		
		charEntity = new CharacteristicEntity_Id(premiseIdCharType, CharacteristicEntityLookup.constants.TO_DO_ENTRY);
		if(isNull(charEntity.getEntity())){
		  addError(CustomMessageRepositorySpireOne.B17517_InvalidCharType(premiseIdCharType.getId().getIdValue().trim()));
		}

		charEntity = new CharacteristicEntity_Id(personIdCharType, CharacteristicEntityLookup.constants.TO_DO_ENTRY);
		if(isNull(charEntity.getEntity())){
		  addError(CustomMessageRepositorySpireOne.B17517_InvalidCharType(personIdCharType.getId().getIdValue().trim()));
		}		

		charEntity = new CharacteristicEntity_Id(saIdCharType, CharacteristicEntityLookup.constants.TO_DO_ENTRY);
		if(isNull(charEntity.getEntity())){
		  addError(CustomMessageRepositorySpireOne.B17517_InvalidCharType(saIdCharType.getId().getIdValue().trim()));
		}
		
		charEntity = new CharacteristicEntity_Id(spIdCharType, CharacteristicEntityLookup.constants.TO_DO_ENTRY);
		if(isNull(charEntity.getEntity())){
		  addError(CustomMessageRepositorySpireOne.B17517_InvalidCharType(spIdCharType.getId().getIdValue().trim()));
		}
		
		charEntity = new CharacteristicEntity_Id(cisDivisionCharType, CharacteristicEntityLookup.constants.TO_DO_ENTRY);
		if(isNull(charEntity.getEntity())){
		  addError(CustomMessageRepositorySpireOne.B17517_InvalidCharType(cisDivisionCharType.getId().getIdValue().trim()));
		}

    }    
    
    public static class CmDefaultToDoCisDivBatchWorker extends
        CmDefaultToDoCisDivBatchWorker_Gen {        
        
        // Work variables
        private ToDoEntry toDoEntry;
        private ToDoEntryCharacteristics toDoChars;  

        @Override
        public void initializeThreadWork(boolean initializationPreviouslySuccessful) throws ThreadAbortedException, RunAbortedException {

            accountIdCharType = getParameters().getACCT_ID_CHAR_TYPE();
            premiseIdCharType = getParameters().getPREM_ID_CHAR_TYPE();
            personIdCharType = getParameters().getPER_ID_CHAR_TYPE();
            saIdCharType = getParameters().getSA_ID_CHAR_TYPE();
            spIdCharType = getParameters().getSP_ID_CHAR_TYPE();
            cisDivisionCharType = getParameters().getCIS_DIV_CHAR_TYPE();   
            
            super.initializeThreadWork(initializationPreviouslySuccessful);
        }

        @Override
        protected boolean executeWorkUnit(ThreadWorkUnit unit) throws ThreadAbortedException, RunAbortedException {            
            ToDoEntry_Id toDoEntryId = (ToDoEntry_Id) unit.getPrimaryId();
            toDoEntry = toDoEntryId.getEntity();
            toDoChars = toDoEntry.getCharacteristics();      
            
            // Process only those To Do Entries that are not yet tagged with a CIS Division characteristic
            CisDivision cisDivision = getDivisionId();
            
            if (notNull(cisDivision)) {
                ToDoEntryCharacteristic_DTO toDoEntryCharDto = toDoEntry.getCharacteristics().newChildDTO();

                if(cisDivisionCharType.getCharacteristicType().isAdhocValue()) {
                    toDoEntryCharDto.setAdhocCharacteristicValue(cisDivision.getId().getTrimmedValue());
                } else if(cisDivisionCharType.getCharacteristicType().isForeignKeyValue()) {
                    toDoEntryCharDto.setCharacteristicValueForeignKey1(cisDivision.getId().getTrimmedValue());
                } else {
                    toDoEntryCharDto.setCharacteristicValue(cisDivision.getId().getTrimmedValue());
                }
                
                toDoEntryCharDto.setSearchCharacteristicValue(cisDivision.getId().getTrimmedValue());
                
                toDoChars.add(toDoEntryCharDto, cisDivisionCharType.getId(), BigInteger.ONE);                                        
            }
            
            return true;
        }
        
        /**
         * Retrieve the CIS Division from the entities in the existing To Do Characteristics
         * @param person
         * @return Account
         */        
        private CisDivision getDivisionId(){

            CisDivision cisDiv = null;
            ToDoEntryCharacteristic_DTO dto;
            CharacteristicType charType;
            
            for (ToDoEntryCharacteristic characteristicData : toDoChars){
                dto = characteristicData.getDTO();
                if (dto.getId() == null) {
                    return null;
                }
                
                charType = dto.getId().getCharacteristicType();
                if (isNull(charType)) {
                    return null;
                }
               
                if ((isNull(cisDiv)) && (charType.getId().getIdValue().equals(accountIdCharType.getId().getIdValue())) && 
                    (charType.getCharacteristicType().isForeignKeyValue())) {
                    Account account = (Account)new Account_Id(dto.getCharacteristicValueForeignKey1()).getEntity();

                    if (notNull(account)) {
                        cisDiv = account.fetchDivision();
                        break;
                    }
                }
                
                if ((isNull(cisDiv)) && (charType.getId().getIdValue().equals(premiseIdCharType.getId().getIdValue())) && 
                        (charType.getCharacteristicType().isForeignKeyValue())) {
                    Premise premise = (Premise)new Premise_Id(dto.getCharacteristicValueForeignKey1()).getEntity();

                    if (notNull(premise)) {
                        cisDiv = premise.fetchDivision();
                        break;
                    }
                }
                
                if ((isNull(cisDiv)) && (charType.getId().getIdValue().equals(personIdCharType.getId().getIdValue())) && 
                        (charType.getCharacteristicType().isForeignKeyValue())) {
                    Person person = (Person)new Person_Id(dto.getCharacteristicValueForeignKey1()).getEntity();

                    if (notNull(person)) {
                        Account account = getAccount(person);
                        if (notNull(account)){
                            cisDiv = account.fetchDivision();
                            break;                      
                        }
                    }
                }           

                if ((isNull(cisDiv)) && (charType.getId().getIdValue().equals(saIdCharType.getId().getIdValue())) && 
                        (charType.getCharacteristicType().isForeignKeyValue())) {
                    ServiceAgreement sa = (ServiceAgreement)new ServiceAgreement_Id(dto.getCharacteristicValueForeignKey1()).getEntity();

                    if (notNull(sa)) {
                        cisDiv = sa.getAccount().fetchDivision();
                        break;
                    }
                }           

                if ((isNull(cisDiv)) && (charType.getId().getIdValue().equals(spIdCharType.getId().getIdValue())) && 
                        (charType.getCharacteristicType().isForeignKeyValue())) {
                    ServicePoint sp = (ServicePoint)new ServicePoint_Id(dto.getCharacteristicValueForeignKey1()).getEntity();
        
                    if (notNull(sp)) {
                        cisDiv = sp.getPremise().fetchDivision();
                        break;
                    }
                }                       
            }
            
            return cisDiv;
            
        }
        
        /**
         * Retrieve the account where the input person is the main customer
         * @param person
         * @return Account
         */
        private Account getAccount(Person per){
            
            Account account = null;
            
            //Check if active accounts exists for Person Id
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT DISTINCT ACCT_ID ");
            stringBuilder.append("FROM CI_ACCT_PER  ");
            stringBuilder.append("WHERE PER_ID = :personId ");
            stringBuilder.append("AND MAIN_CUST_SW = :mainCustomerSw ");    
            
            PreparedStatement retrieveAccount = createPreparedStatement(stringBuilder.toString(), this.getClass().getName());
            retrieveAccount.bindBoolean("mainCustomerSw", Bool.TRUE);
            retrieveAccount.bindId("personId", per.getId());
            
            SQLResultRow sqlResultRow = retrieveAccount.firstRow();
            retrieveAccount.close();
            
            if(!isNull(sqlResultRow)){
                account = (Account)new Account_Id(sqlResultRow.getString("ACCT_ID")).getEntity();                       
            }
            
            return account;
        }
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }
    }
}