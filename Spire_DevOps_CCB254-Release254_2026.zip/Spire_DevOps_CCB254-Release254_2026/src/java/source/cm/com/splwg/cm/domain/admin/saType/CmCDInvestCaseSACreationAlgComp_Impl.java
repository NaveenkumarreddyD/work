/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NA0014 - CD Invest Case Algorithm
 *
 * SA creation algorithm which determines whether CD Invest needs to be
 * created before SA creation.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-01-17   Neha    NA0014. Initial Version.
 * 2013-02-07   MOL     TIR_FS_NA0014_20130207. Fixed Null pointer 
 *                      exception error. Commented out all System.out 
 *                      statements.
 * 2013-06-08    Murali  Defect1990. Calculation of Current balance
 * 2014-02-06    Neha	IM-042215 Change Last party query to get the same 
 * 				      	account when last service was on same account on the premise
 * 2014-07-09	Rahul   IM-042215 Chaged Last party query to exclude SA started on same date
 * 2016-01-26   MPang	Updated for CCB v2.4 compilation.
 * 2018-07-25   SFelip  CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                      longer needed.    
 **************************************************************************/

package com.splwg.cm.domain.admin.saType;

import java.math.BigInteger;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.SpecialRoleLookup;
//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.CaseType;
import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.serviceAgreementType.SaTypeSaCreationAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.serviceType.ServiceType;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.Person;
import com.splwg.ccb.domain.customerinfo.person.Person_Id;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_Id;*/

import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saCreation.SaTypeSaCreationAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_Id;
//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author nsinha006
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = caseType, name = cdInvestCaseType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = caseType, name = suspiciousActivityCaseType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = suspiciousCaseOpenState, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = cdInvestCaseApproveState, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = cdInvestCaseOverrideState, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = cdInvestCaseNonApprState1, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = cdInvestCaseNonApprState2, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = maxAllowedBalance, required = true, type = decimal)
 *            , @AlgorithmSoftParameter (name = prevSAAllowedDays, required = false, type = integer)
 *            , @AlgorithmSoftParameter (name = ageOfDebt, required = true, type = integer)
 *            , @AlgorithmSoftParameter (entityName = serviceType, name = gasServiceType1, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = serviceType, name = gasServiceType2, required = false, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = specialRole, name = saTypeSpecialRole, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (name = gasWriteOffSATypeNetRevenue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = gasWriteOffSATypeGRTTax, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = gasWriteOffSATypeSalesTax, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = gasWriteOffSATypeCityTax, required = true, type = string)
 *            }
)
 */
public class CmCDInvestCaseSACreationAlgComp_Impl
extends CmCDInvestCaseSACreationAlgComp_Gen
implements SaTypeSaCreationAlgorithmSpot {

    // Soft parameters
    private CaseType parmCDInvestCaseType;
    private CaseType parmSuspiciousActivityCaseType;
    private String parmSuspiciousCaseOpenState;
    private String parmCDInvestCaseApproveState;
    private String parmCDInvestCaseOverrideState;
    private String parmCDInvestCaseNonApprState1;
    private String parmCDInvestCaseNonApprState2;
    private BigDecimal parmMaxAllowedBalance;
    private BigInteger parmPrevSAAllowedDays;
    private BigInteger parmAgeOfDebt;
    private ServiceType parmGasServiceType1;
    private ServiceType parmGasServiceType2;
    private SpecialRoleLookup parmSaTypeSpecialRole;
    private String parmGasWriteOffSATypeNetRevenue;
    private String parmGasWriteOffSATypeSalesTax;
    private String parmGasWriteOffSATypeCityTax;
    private String parmGasWriteOffSATypeGRTTax;

    // Hard parameters
    private ServiceAgreement parmServiceAgreement;
    // Working variables
    private CisDivision cisdivision;
    private Account account;
    private Premise_Id premiseId;
    private Account_Id previousAccountId;

    public void setServiceAgreement(ServiceAgreement arg0) {
        parmServiceAgreement = arg0;
    }

    public void invoke() {

        Money credit = Money.ZERO;
        Money debit = Money.ZERO;
        Money totalBalance = Money.ZERO;

        cisdivision = parmServiceAgreement.getServiceAgreementType().getId().getDivision();
        account = parmServiceAgreement.getAccount();
        premiseId = parmServiceAgreement.getPremiseId();

        validateInputParameters();

        getSuspiciousActivityCase();
        if(notNull(premiseId.getEntity().fetchLandLord()) && premiseId.getEntity().fetchLandLord().getAccountId().equals(account.getId())){
            return;
        }
        ToDoCase_Id existingCDInvestCase = null;
        Person_Id personId = null;
        List<SQLResultRow> resultList = getCDInvestCase(parmCDInvestCaseNonApprState1, parmCDInvestCaseNonApprState2);
        if(!resultList.isEmpty()){
            existingCDInvestCase = (ToDoCase_Id)resultList.iterator().next().getId("CASE_ID", ToDoCase.class);
            personId = (Person_Id)resultList.iterator().next().getId("PER_ID", Person.class);

            //A Pending CD Invest Case already exists
            addError(CustomMessageRepository.na0014PendingCDCaseExists(getAlgorithm().getId().getTrimmedValue(), existingCDInvestCase.getTrimmedValue(), premiseId.getTrimmedValue(),personId.getTrimmedValue()));
        }
        if(!(getCDInvestCase(parmCDInvestCaseApproveState, parmCDInvestCaseOverrideState).isEmpty())){
            return;
        }
        if(getLastPartyOfRecord().isFalse()){
            return;
        }
        // Get credit balance
        credit = getAccountBalance(true);
        debit = getAccountBalance(false);
        totalBalance = credit.add(debit);
        if(totalBalance.getAmount().compareTo(parmMaxAllowedBalance) >= 0){
            // Total Amount Owed is greater than or equal to  maximum allowed balance parameter and Age of Debt is more than param,
            // hence CD Invest Case is required to start Service on the Premise Id
           // addError(CustomMessageRepository.na0014CDDebtFoundSoInvestCaseReqd(getAlgorithm().getId().getTrimmedValue(), totalBalance.getAmount().toString(), account.getId().getTrimmedValue(),parmMaxAllowedBalance.toString(),parmAgeOfDebt.toString(),premiseId.getTrimmedValue()));
            
            addError(CustomMessageRepository.na0014CDDebtFoundSoInvestCaseReqd(getAlgorithm().getId().getTrimmedValue(), totalBalance.getAmount().toString(), previousAccountId.getTrimmedValue(),parmMaxAllowedBalance.toString(),parmAgeOfDebt.toString(),premiseId.getTrimmedValue()));
            
                      
        }

    }
    private void validateInputParameters() {
        parmCDInvestCaseType = getCdInvestCaseType();
        parmSuspiciousActivityCaseType = getSuspiciousActivityCaseType();
        parmSuspiciousCaseOpenState = getSuspiciousCaseOpenState();
        validateCaseState(parmSuspiciousActivityCaseType, parmSuspiciousCaseOpenState.trim());

        parmCDInvestCaseApproveState = getCdInvestCaseApproveState();
        validateCaseState(parmCDInvestCaseType, parmCDInvestCaseApproveState.trim());

        parmCDInvestCaseOverrideState = getCdInvestCaseOverrideState();
        validateCaseState(parmCDInvestCaseType, parmCDInvestCaseOverrideState.trim());

        parmCDInvestCaseNonApprState1 = getCdInvestCaseNonApprState1();
        validateCaseState(parmCDInvestCaseType, parmCDInvestCaseNonApprState1.trim());

        parmCDInvestCaseNonApprState2 = getCdInvestCaseNonApprState2();
        validateCaseState(parmCDInvestCaseType, parmCDInvestCaseNonApprState2.trim());

        parmMaxAllowedBalance = getMaxAllowedBalance();
        if(parmMaxAllowedBalance.compareTo(BigDecimal.ZERO) < 0){
            addError(CustomMessageRepository.na0014MaxAllowedBalShouldBGreaterOrEqualToZero(getAlgorithm().getId().getTrimmedValue(), parmMaxAllowedBalance.toString()));
        }
        parmPrevSAAllowedDays = getPrevSAAllowedDays();
        if(notNull(parmPrevSAAllowedDays) && parmPrevSAAllowedDays.compareTo(BigInteger.ZERO) < 0){
            addError(CustomMessageRepository.na0014PrevSADaysShouldBGreaterOrEqualToZero(getAlgorithm().getId().getTrimmedValue(), parmPrevSAAllowedDays.toString()));
        }
        parmAgeOfDebt = getAgeOfDebt();
        if(parmAgeOfDebt.compareTo(BigInteger.ZERO) < 0){
            addError(CustomMessageRepository.na0014AgeOfDebtShouldBGreaterOrEqualToZero(getAlgorithm().getId().getTrimmedValue(), parmAgeOfDebt.toString()));
        }
        parmGasServiceType1 = getGasServiceType1();
        parmGasServiceType2 = getGasServiceType2();

        parmSaTypeSpecialRole = getSaTypeSpecialRole();

        parmGasWriteOffSATypeNetRevenue = getGasWriteOffSATypeNetRevenue();
        validateSAType(cisdivision, parmGasWriteOffSATypeNetRevenue.trim());

        parmGasWriteOffSATypeGRTTax = getGasWriteOffSATypeGRTTax();
        validateSAType(cisdivision, parmGasWriteOffSATypeGRTTax.trim());

        parmGasWriteOffSATypeSalesTax = getGasWriteOffSATypeSalesTax();
        validateSAType(cisdivision, parmGasWriteOffSATypeSalesTax.trim());

        parmGasWriteOffSATypeCityTax = getGasWriteOffSATypeCityTax();
        validateSAType(cisdivision, parmGasWriteOffSATypeCityTax.trim());

    }

    public void validateCaseState(CaseType caseType, String strCaseStatus){
        CaseStatus status =  new CaseStatus_Id(caseType,strCaseStatus).getEntity();
        if(isNull(status)){
            addError(CustomMessageRepository.na0014InvalidCaseStatusForCaseType(getAlgorithm().getId().getTrimmedValue(), strCaseStatus, caseType.getId().getTrimmedValue()));
        }
    }

    public void validateSAType(CisDivision cisdivision, String strSAType){
        ServiceAgreementType saType = new ServiceAgreementType_Id(cisdivision,strSAType).getEntity();
        if(isNull(saType)){
            addError(CustomMessageRepository.na0014InvalidSATypeForCisDivision(getAlgorithm().getId().getTrimmedValue(), strSAType, cisdivision.getId().getTrimmedValue()));
        }
        if(!saType.getSpecialRole().equals(parmSaTypeSpecialRole)){
            addError(CustomMessageRepository.na0014InvalidSATypeForSpecialRole(getAlgorithm().getId().getTrimmedValue(), strSAType, parmSaTypeSpecialRole.getLookupValue().getId().getFieldValue()));
        }
    }

    private void getSuspiciousActivityCase(){
        StringBuilder getSuspiciousActCaseString = new StringBuilder();
        getSuspiciousActCaseString.append("SELECT CASE_ID FROM CI_CASE ");
        getSuspiciousActCaseString.append("WHERE CASE_TYPE_CD = :suspiciousCaseType ");
        getSuspiciousActCaseString.append("AND PREM_ID = :premId ");
        // CCB v2.6 Upgrade - 2018-07-25 - Start Change
        //getSuspiciousActCaseString.append("AND @trim(CASE_STATUS_CD) = :statusCd ");
        getSuspiciousActCaseString.append("AND CASE_STATUS_CD = :statusCd ");
        // CCB v2.6 Upgrade - 2018-07-25 - End Change
        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement getSuspiciousActCasePrepStmt = createPreparedStatement(getSuspiciousActCaseString.toString());
        PreparedStatement getSuspiciousActCasePrepStmt = createPreparedStatement(getSuspiciousActCaseString.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        getSuspiciousActCasePrepStmt.bindId("suspiciousCaseType", parmSuspiciousActivityCaseType.getId());
        getSuspiciousActCasePrepStmt.bindId("premId", premiseId);
        getSuspiciousActCasePrepStmt.bindStringProperty("statusCd", CaseStatus.properties.status, parmSuspiciousCaseOpenState.trim());

        List<SQLResultRow> resultList = getSuspiciousActCasePrepStmt.list();
        getSuspiciousActCasePrepStmt.close();

        if(!resultList.isEmpty()){
            ToDoCase_Id caseId = (ToDoCase_Id)resultList.iterator().next().getId("CASE_ID", ToDoCase.class);
            //Suspicious Activity Case , so CD Invest Case is required to start service
            addError(CustomMessageRepository.na0014SuspiciousActitvityCaseExistsCDReqd(caseId.getTrimmedValue(), premiseId.getTrimmedValue()));
        }
        return;
    }

    private List<SQLResultRow> getCDInvestCase(String caseStatus1, String caseStatus2){
        StringBuilder getCDInvestCaseString = new StringBuilder();
        getCDInvestCaseString.append("SELECT CSE.CASE_ID,CSE.PER_ID FROM CI_ACCT_PER ACTPER,CI_CASE CSE ");
        getCDInvestCaseString.append("WHERE CSE.CASE_TYPE_CD = :cdInvestCaseType ");
        getCDInvestCaseString.append("AND CSE.PREM_ID = :premId ");
        getCDInvestCaseString.append("AND ACTPER.ACCT_ID = :acctId ");
        getCDInvestCaseString.append("AND CSE.PER_ID = ACTPER.PER_ID ");
        // CCB v2.6 Upgrade - 2018-07-25 - Start Change
        //getCDInvestCaseString.append("AND @trim(CSE.CASE_STATUS_CD) IN (:caseState1,:caseState2) ");
        getCDInvestCaseString.append("AND CSE.CASE_STATUS_CD IN (:caseState1,:caseState2) ");
        // CCB v2.6 Upgrade - 2018-07-25 - End Change
      //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
       // PreparedStatement getCDInvestCasePrepStmt = createPreparedStatement(getCDInvestCaseString.toString());
        PreparedStatement getCDInvestCasePrepStmt = createPreparedStatement(getCDInvestCaseString.toString(), getClass().getName());
      //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        getCDInvestCasePrepStmt.bindId("cdInvestCaseType", parmCDInvestCaseType.getId());
        getCDInvestCasePrepStmt.bindId("premId", premiseId);
        getCDInvestCasePrepStmt.bindId("acctId", account.getId());
        getCDInvestCasePrepStmt.bindStringProperty("caseState1", CaseStatus.properties.status, caseStatus1.trim());
        getCDInvestCasePrepStmt.bindStringProperty("caseState2", CaseStatus.properties.status, caseStatus2.trim());

        List<SQLResultRow> resultList = getCDInvestCasePrepStmt.list();
        getCDInvestCasePrepStmt.close();

        return resultList;
    }

    private Bool getLastPartyOfRecord(){
        StringBuilder getLastSAorAcctDataString = new StringBuilder();
        getLastSAorAcctDataString.append("SELECT SA.ACCT_ID, SA.SA_ID FROM CI_SA SA,CI_SA_TYPE SATYPE ");
        getLastSAorAcctDataString.append("WHERE SA.CHAR_PREM_ID = :premId ");
        // CCB v2.6 Upgrade - 2018-07-25 - Start Change
        //getLastSAorAcctDataString.append("AND @trim(SA.SA_TYPE_CD) = @trim(SATYPE.SA_TYPE_CD) ");
        getLastSAorAcctDataString.append("AND SA.SA_TYPE_CD = SATYPE.SA_TYPE_CD ");
        // CCB v2.6 Upgrade - 2018-07-25 - End Change
        getLastSAorAcctDataString.append("AND SA.CIS_DIVISION = SATYPE.CIS_DIVISION ");
        // CCB v2.6 Upgrade - 2018-07-25 - Start Change
        //getLastSAorAcctDataString.append("AND( @trim(SA.SA_TYPE_CD) IN (:newRevenue,:salesTax,:cityTax,:grtTax) OR SATYPE.SVC_TYPE_CD IN (:srvcType1");
        getLastSAorAcctDataString.append("AND( SA.SA_TYPE_CD IN (:newRevenue,:salesTax,:cityTax,:grtTax) OR SATYPE.SVC_TYPE_CD IN (:srvcType1");
        // CCB v2.6 Upgrade - 2018-07-25 - End Change
        if(notNull(parmGasServiceType2)){
            getLastSAorAcctDataString.append("                  ,:srvcType2  ");
        }
        getLastSAorAcctDataString.append("                  )) ");
	// Start delete 2014-02-06    Neha	IM-042215
        //getLastSAorAcctDataString.append("AND SA.ACCT_ID NOT IN (:currentAcct");
        //if(notNull(premiseId.getEntity().fetchLandLord())){
        //    getLastSAorAcctDataString.append("              , :landLordAcct");
        //}	
        //getLastSAorAcctDataString.append("              ) ");
        // End delete 2014-02-06    Neha        IM-042215
        getLastSAorAcctDataString.append("AND SA.SA_STATUS_FLG NOT IN (:incomplete,:cancelled) ");
	// Start Change IM-042215 Rahul	2014-07-09
        //getLastSAorAcctDataString.append("AND SA.START_DT <= :startDt ");
		getLastSAorAcctDataString.append("AND SA.START_DT < :startDt ");
	// End Change IM-042215 Rahul 2014-07-09
        if(notNull(parmPrevSAAllowedDays)){		
            getLastSAorAcctDataString.append("AND (SA.END_DT IS NULL OR (SA.END_DT BETWEEN :prvSADatePeriod AND  :startDt)) ");						
        }
        getLastSAorAcctDataString.append("ORDER BY SA.END_DT DESC ");

        // TIR_FS_NA0014_20130207 - Commented out System.out
        // System.out.println(" Query" + getLastSAorAcctDataString.toString());
        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
       // PreparedStatement getLastSAorAcctDataPrepStmt = createPreparedStatement(getLastSAorAcctDataString.toString());
        PreparedStatement getLastSAorAcctDataPrepStmt = createPreparedStatement(getLastSAorAcctDataString.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        getLastSAorAcctDataPrepStmt.bindId("premId", premiseId);
        getLastSAorAcctDataPrepStmt.bindStringProperty("newRevenue", ServiceAgreementType.properties.saType, parmGasWriteOffSATypeNetRevenue.trim());
        getLastSAorAcctDataPrepStmt.bindStringProperty("salesTax", ServiceAgreementType.properties.saType, parmGasWriteOffSATypeSalesTax.trim());
        getLastSAorAcctDataPrepStmt.bindStringProperty("cityTax", ServiceAgreementType.properties.saType, parmGasWriteOffSATypeCityTax.trim());
        getLastSAorAcctDataPrepStmt.bindStringProperty("grtTax", ServiceAgreementType.properties.saType, parmGasWriteOffSATypeGRTTax.trim());
        getLastSAorAcctDataPrepStmt.bindId("srvcType1",  parmGasServiceType1.getId());
        if(notNull(parmGasServiceType2)){
            getLastSAorAcctDataPrepStmt.bindId("srvcType2",  parmGasServiceType2.getId());
        }
		// Start delete 2014-02-06    Neha	IM-042215
        //getLastSAorAcctDataPrepStmt.bindId("currentAcct",  account.getId());
        //if(notNull(premiseId.getEntity().fetchLandLord())){
        //    getLastSAorAcctDataPrepStmt.bindId("landLordAcct",  premiseId.getEntity().fetchLandLord().getAccountId());
        //}
		// End delete 2014-02-06    Neha	IM-042215
        getLastSAorAcctDataPrepStmt.bindLookup("incomplete", ServiceAgreementStatusLookup.constants.INCOMPLETE);
        getLastSAorAcctDataPrepStmt.bindLookup("cancelled", ServiceAgreementStatusLookup.constants.CANCELED);

        if(notNull(parmPrevSAAllowedDays)){

            //getLastSAorAcctDataPrepStmt.bindDate("prvSADatePeriod", getProcessDateTime().getDate().addDays(parmPrevSAAllowedDays.negate().intValue()));
            getLastSAorAcctDataPrepStmt.bindDate("prvSADatePeriod", parmServiceAgreement.getStartDate().addDays(parmPrevSAAllowedDays.negate().intValue()));
        }
        //getLastSAorAcctDataPrepStmt.bindDate("processDt", getProcessDateTime().getDate());
        getLastSAorAcctDataPrepStmt.bindDate("startDt",parmServiceAgreement.getStartDate());

        // TIR_FS_NA0014_20130207 - Commented out System.out
        // System.out.println(" VALUES 1 PREM " + premiseId);
        // System.out.println(" VALUES 1 srvcType1 " + parmGasServiceType1.getId());
        // System.out.println(" VALUES 1 landLordAcct " +  premiseId.getEntity().fetchLandLord().getAccountId());
        // System.out.println(" VALUES 1 prvSADatePeriod " +  parmServiceAgreement.getStartDate().addDays(parmPrevSAAllowedDays.negate().intValue()));
        // System.out.println(" VALUES 1 prvSADatePeriod " +  parmServiceAgreement.getStartDate());


        List<SQLResultRow> resultList = getLastSAorAcctDataPrepStmt.list();
        // TIR_FS_NA0014_20130207 - Commented out System.out
        // System.out.println("List Size " + resultList.size());
        getLastSAorAcctDataPrepStmt.close();
        // TIR_FS_NA0014_20130207 - Commented out System.out
        // System.out.println("List isEmpty " + resultList.isEmpty());
        if(resultList.isEmpty()){
            return Bool.FALSE;
        }else{
            SQLResultRow resultRow = resultList.iterator().next();
            previousAccountId = (Account_Id) resultRow.getId("ACCT_ID", Account.class);
            // Start add 2014-02-06    Neha	IM-042215
            if(previousAccountId.equals(account.getId())){
                return  Bool.FALSE;
            }
            if(notNull(premiseId.getEntity().fetchLandLord()) && previousAccountId.equals(premiseId.getEntity().fetchLandLord().getAccountId())){
                return  Bool.FALSE;
            }
            // End add 2014-02-06    Neha	IM-042215
            return Bool.TRUE;
        }

    }

    private Money getAccountBalance(boolean isCredit){
        Money bal = Money.ZERO;
        StringBuilder getAccountBalanceString = new StringBuilder();
        getAccountBalanceString.append("SELECT SUM(FT.CUR_AMT) CUR_AMT FROM CI_FT FT ");
        getAccountBalanceString.append("WHERE FT.SA_ID IN (SELECT SA.SA_ID FROM  CI_SA SA,CI_SA_TYPE SATYPE  ");
        getAccountBalanceString.append("                   WHERE SA.ACCT_ID = :lastPartyAcctId ");
        getAccountBalanceString.append("                   AND SA.CHAR_PREM_ID = :premId ");
        getAccountBalanceString.append("                   AND SA.SA_TYPE_CD = SATYPE.SA_TYPE_CD ");
        getAccountBalanceString.append("                   AND SA.CIS_DIVISION = SATYPE.CIS_DIVISION ");
        getAccountBalanceString.append("                   AND SA.SA_STATUS_FLG NOT IN (:incomplete,:cancelled) ");
        getAccountBalanceString.append("                   AND SA.START_DT <= :startDt ");
        // CCB v2.6 Upgrade - 2018-07-25 - Start Change
        //getAccountBalanceString.append("                   AND( @trim(SA.SA_TYPE_CD) IN (:newRevenue,:salesTax,:cityTax,:grtTax) OR SATYPE.SVC_TYPE_CD IN (:srvcType1");
        getAccountBalanceString.append("                   AND( SA.SA_TYPE_CD IN (:newRevenue,:salesTax,:cityTax,:grtTax) OR SATYPE.SVC_TYPE_CD IN (:srvcType1");
        // CCB v2.6 Upgrade - 2018-07-25 - End Change
        if(notNull(parmGasServiceType2)){
            getAccountBalanceString.append("                  ,:srvcType2  ");
        }
        getAccountBalanceString.append("                  )) ");
        if(notNull(parmPrevSAAllowedDays)){
            getAccountBalanceString.append("AND (SA.END_DT IS NULL OR (SA.END_DT BETWEEN :prvSADatePeriod AND  :startDt)) ");
        }
        getAccountBalanceString.append("                   ) ");
        getAccountBalanceString.append("AND FT.FREEZE_SW = 'Y' ");
        getAccountBalanceString.append("AND FT.REDUNDANT_SW = 'N' ");
        if(isCredit == true){
            // ML20130608 - Start 
            /* getAccountBalanceString.append("AND FT.CUR_AMT > 0 ");           
            getAccountBalanceString.append("AND ( (FT.ARS_DT IS NOT NULL AND FT.ARS_DT < :ageOfDebtDt) OR FT.ARS_DT IS NULL ) ");
             */
            getAccountBalanceString.append("AND FT.CUR_AMT <= 0 ");// Payments and bill cancellations
            getAccountBalanceString.append("AND ( TRUNC(FT.FREEZE_DTTM) <= :processDt OR(FT.ARS_DT IS NOT NULL AND FT.ARS_DT <= :processDt)) ");
            // ML20130608 - End 
        }else{
            // ML20130608 - Start 
            getAccountBalanceString.append("AND FT.CUR_AMT > 0 ");
            getAccountBalanceString.append("AND (  TRUNC(FT.FREEZE_DTTM) < :ageOfDebtDt OR (FT.ARS_DT IS NOT NULL AND FT.ARS_DT < :ageOfDebtDt) ) ");
           /* getAccountBalanceString.append("AND FT.CUR_AMT > 0 ");
            getAccountBalanceString.append("AND FT.ARS_DT IS NOT NULL ");
            getAccountBalanceString.append("AND FT.ARS_DT <= :processDt ");*/
        }

        // TIR_FS_NA0014_20130207 - Commented out System.out
        // System.out.println("ACCOUNT QUery " + getAccountBalanceString.toString()  );
      //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
       // PreparedStatement getAccountBalancePrepStmt = createPreparedStatement(getAccountBalanceString.toString());
        PreparedStatement getAccountBalancePrepStmt = createPreparedStatement(getAccountBalanceString.toString(), getClass().getName());
      //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        getAccountBalancePrepStmt.bindId("lastPartyAcctId", previousAccountId);
        getAccountBalancePrepStmt.bindId("premId", premiseId);
        getAccountBalancePrepStmt.bindLookup("incomplete", ServiceAgreementStatusLookup.constants.INCOMPLETE);
        getAccountBalancePrepStmt.bindLookup("cancelled", ServiceAgreementStatusLookup.constants.CANCELED);
        getAccountBalancePrepStmt.bindStringProperty("newRevenue", ServiceAgreementType.properties.saType, parmGasWriteOffSATypeNetRevenue.trim());
        getAccountBalancePrepStmt.bindStringProperty("salesTax", ServiceAgreementType.properties.saType, parmGasWriteOffSATypeSalesTax.trim());
        getAccountBalancePrepStmt.bindStringProperty("cityTax", ServiceAgreementType.properties.saType, parmGasWriteOffSATypeCityTax.trim());
        getAccountBalancePrepStmt.bindStringProperty("grtTax", ServiceAgreementType.properties.saType, parmGasWriteOffSATypeGRTTax.trim());
        getAccountBalancePrepStmt.bindId("srvcType1",  parmGasServiceType1.getId());
        if(notNull(parmGasServiceType2)){
            getAccountBalancePrepStmt.bindId("srvcType2",  parmGasServiceType2.getId());
        }
        if(notNull(parmPrevSAAllowedDays)){

            //getAccountBalancePrepStmt.bindDate("prvSADatePeriod", getProcessDateTime().getDate().addDays(parmPrevSAAllowedDays.negate().intValue()));
            getAccountBalancePrepStmt.bindDate("prvSADatePeriod", parmServiceAgreement.getStartDate().addDays(parmPrevSAAllowedDays.negate().intValue()));
        }
        if(isCredit == true){
            //ML20130610 - Start
            getAccountBalancePrepStmt.bindDate("processDt", getProcessDateTime().getDate());
            //ML20130610 - End
           // getAccountBalancePrepStmt.bindDate("ageOfDebtDt", getProcessDateTime().getDate().addDays(parmAgeOfDebt.negate().intValue()));
        }else{
            //ML20130610 - Start
            getAccountBalancePrepStmt.bindDate("ageOfDebtDt", getProcessDateTime().getDate().addDays(parmAgeOfDebt.negate().intValue()));
            //ML20130610 - End
                       
          //  getAccountBalancePrepStmt.bindDate("processDt", getProcessDateTime().getDate());
        }
        getAccountBalancePrepStmt.bindDate("startDt",parmServiceAgreement.getStartDate());

        List<SQLResultRow> resultList = getAccountBalancePrepStmt.list();
        getAccountBalancePrepStmt.close();

        if(!resultList.isEmpty()){
            bal =  resultList.iterator().next().getMoney("CUR_AMT");
        }
        return isNull(bal)? Money.ZERO : bal;
    }
}