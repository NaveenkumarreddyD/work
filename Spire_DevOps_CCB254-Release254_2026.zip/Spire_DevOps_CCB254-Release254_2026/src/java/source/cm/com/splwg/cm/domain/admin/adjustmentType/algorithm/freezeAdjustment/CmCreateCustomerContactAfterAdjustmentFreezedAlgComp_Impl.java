package com.splwg.cm.domain.admin.adjustmentType.algorithm.freezeAdjustment;
/*
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                     
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * Adjustment Type - FT Freeze
 * 
 * This program will automatically create a customer contact for the 
 * main person linked to the SA's Account that the adjustment was
 * created for at the time when the adjustment was freezed.
 * 
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:        by:          Reason:
 * YYYY-MM-DD   FLName
 * 
 * 2020-12-09    JHERNA    SysAid#354158. Initial Version.  
 ***********************************************************************
 */
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.admin.adjustmentType.algorithm.freezeAdjustment.AdjustmentFreezeAlgorithmSpot;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author blu02772
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = customerContactClass, name = customerContactClass, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = contactType, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = comments, type = string)
 *            , @AlgorithmSoftParameter (name = isOneTimeContact, required = true, type = boolean)})
 */
public class CmCreateCustomerContactAfterAdjustmentFreezedAlgComp_Impl 
		extends	CmCreateCustomerContactAfterAdjustmentFreezedAlgComp_Gen 
		implements AdjustmentFreezeAlgorithmSpot {

	
	private Adjustment hpAdjustment;
	
	private CustomerContactClass parmContClass;
	private String parmContactType;
	private String parmComments;
	private Bool parmIsOneTimeContact;
	
	private String wAlgCode;
	private CustomerContactType_Id wCCTypeID;
	
	@Override
	public void invoke() {

		ServiceAgreement sa = hpAdjustment.getServiceAgreement();
		Account account = sa.getAccount();		
		String comments = " ";
		if (notBlank(parmComments)) {
			comments = parmComments;
		}
		// check if for one time contact creation only.
		if (parmIsOneTimeContact.isTrue()) {
			if (hasContact(account).isFalse()) {
				createCustomerContact(sa, comments);
			}			
		}	
		else {
			createCustomerContact(sa, comments);
		}
	}

	@Override
	public void setAdjustment(Adjustment arg0) {
		hpAdjustment = arg0;
	}

	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		
		wAlgCode = this.getAlgorithmId().getTrimmedValue();
		parmContClass = this.getCustomerContactClass();
		parmContactType = this.getContactType();
		parmComments = this.getComments();
		parmIsOneTimeContact = this.getIsOneTimeContact();
		
		CustomerContactType_Id ccTypeID = new CustomerContactType_Id(parmContClass, parmContactType.trim());
		if (isNull(ccTypeID.getEntity())) {
			// Algorithm %1 parameter '%2%3' is an invalid Contact Type (%4) for Contact Class (%5)
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterContactTypeInvalidForContactClass(wAlgCode, 
					"Contact Type", parmContactType.trim(), parmContClass.getId().getTrimmedValue()));
		}
		wCCTypeID = ccTypeID;
	}	
	
	private Bool hasContact(Account account) {
		
		Bool returnValue = Bool.FALSE;
		
		StringBuilder stringBuilder = new StringBuilder();
		
		stringBuilder.append("SELECT CC_ID ");
		stringBuilder.append("FROM CI_CC ");
		stringBuilder.append("WHERE PER_ID = :mainPerID ");
		stringBuilder.append("AND ACCT_ID = :accountID ");
		stringBuilder.append("AND CC_CL_CD = :ccClass ");
		stringBuilder.append("AND CC_TYPE_CD = :ccType ");

		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==hasContact()==");
		prepState.setAutoclose(false);
		prepState.bindId("mainPerID", account.getMainPerson().getId());
		prepState.bindId("accountID", account.getId());
		prepState.bindId("ccClass", wCCTypeID.getContactClassId());
		prepState.bindString("ccType", wCCTypeID.getContactType().trim(), "CC_TYPE_CD");
		prepState.execute();		
		if (prepState.list().size() > 0) {
			returnValue = Bool.TRUE;
		}		
		prepState.close();
		return returnValue;		
	}
	
	private void createCustomerContact(ServiceAgreement sa, String comments) {
		
		Account account = sa.getAccount();
		Person_Id perID = account.getMainPerson().getId();
		Premise_Id premID =  account.getMailingPremiseId();
		
		CustomerContact_DTO contactDTO = new CustomerContact_DTO();
		contactDTO.setCustomerContactTypeId(wCCTypeID);
		contactDTO.setPersonId(perID);
		contactDTO.setAccountId(account.getId());
		contactDTO.setLongDescription(comments);
		contactDTO.setContactDateTime(this.getProcessDateTime());
		contactDTO.setUserId(this.getActiveContextUser().getId());
		if (notNull(premID)) {
			contactDTO.setPremiseId(premID);
		}		
		contactDTO.newEntity();
	}
}
