/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Add or Update Action Flag Lookup 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2013-03-08   RaviTeja     NI0018.2. Initial Version. 
 **************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author mlekkala001
 *
 @LookupFieldname (value = CM_ACT_FLG)
 */
public class CmActionFlagLookup_Impl 
extends CmActionFlagLookup_Gen {

}

