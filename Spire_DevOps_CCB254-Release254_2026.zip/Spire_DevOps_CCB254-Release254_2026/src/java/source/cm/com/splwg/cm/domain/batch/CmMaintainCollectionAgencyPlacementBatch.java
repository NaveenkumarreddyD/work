/*
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                     
 * 
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * MGE-CCB004.004 - Maintain Collection Agency Placement
 * 
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:       by:          Reason:
 * YYYY-MM-DD  FLName
 * 
 * 2015-01-11  MCRUZ		MGE-CCB004.004 Initial Version
 * 2015-07-15  JHERNA		3247212. Add error handling when the 
 * 							collection agency placement cannot be
 * 							retrieved.
 * 2015-11-11  SMiranda     SF-55416. Pass each record line as work unit 
 * 							and use commit every unit strategy.
 * 2016-01-29  MPang		Updated for CCB v2.4 compilation. 
 * 2017-05-26  JTiozon      Added changes for defect #193290
 * 							(Deceased Case Removal)
 * 2018-01-15  Kiran M		SA 81472 Show actual error instead of JAVA EXCEPTION.
 * 							If the collection agency placement status is not active show the staus not java 
 * 							error.
 * 2021-04-05  EQuint       SA 363689. Update to consume flat file change (added prem ID). Removed logic of adding
 * 							new agency as char. Save the corresponding premise to collection agency referral to 
 * 							the placement's BO data area
 * 2021-05-05  EQuint       SA 368134. Fixed NPE
 * 2021-09-22  GCrisp       Defect 4596386. Add the To Do Characteristics before To Do creation
 **********************************************************************
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
//2015-11-11. SMiranda. SF-55416. Start Change
//import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.CommitEveryUnitStrategy;
//2015-11-11. SMiranda. SF-55416. End Change
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.BusinessObjectStatusConditionLookup;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.LogTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.maintenanceObject.MaintenanceObjectLogHelper;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObject_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristics;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ContactMethodLookup;
import com.splwg.ccb.api.lookup.CustomerReadLookup;
import com.splwg.ccb.api.lookup.LogEntryTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.StartReasonLookup;
import com.splwg.ccb.api.lookup.StatusConditionLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.CaseType;
import com.splwg.ccb.domain.admin.caseType.CharacteristicTypeCaseType_Id;
import com.splwg.ccb.domain.admin.collectionAgency.CollectionAgency_Id;
import com.splwg.ccb.domain.admin.customerContactClass.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.CustomerContactType_Id;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.Person;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTask;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTaskCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTaskLog;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseCreator;
import com.splwg.ccb.domain.todo.toDoCase.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_Id;
import com.splwg.ccb.domain.todo.toDoType.ToDoType;*/

import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.accountRelationshipType.entity.AccountRelationshipType_Id;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.caseType.entity.CharacteristicTypeCaseType_Id;
import com.splwg.ccb.domain.admin.collectionAgency.entity.CollectionAgency_Id;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.debtClass.entity.DebtClass_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.common.ServiceAgreementCreator;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.data.ServiceAgreementCreatorData;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic_DTO;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristics;
import com.splwg.base.domain.serviceTask.ServiceTaskLog;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.common.CaseCreator;
import com.splwg.ccb.domain.todo.data.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_Id;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author mcruz
 *
 @BatchJob (multiThreaded = false, modules = { },
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = AGY_UPD_CC_CLASS, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = AGY_UPD_CC_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = caseType, name = BNKRPT_CASE_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = BNKRPT_TD_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = BNKRPT_BCLMN_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = BNKRPT_BCDATE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = BNKRPT_BCPET_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = caseType, name = DECEASD_CASE_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PER_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = ACCT_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CREDIT_COLL_CASE_SRC_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CREDIT_COLL_CASE_SRC_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = DEBT_CL_CD_TO_SKIP, required = true, type = string)
 *            , @BatchJobSoftParameter (name = DECEASED_SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = adjustmentType, name = DECEASED_ADJT, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = AGY_UPD_DCS_CC_CLASS, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = AGY_UPD_DCS_CC_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)})
 */
public class CmMaintainCollectionAgencyPlacementBatch extends
		CmMaintainCollectionAgencyPlacementBatch_Gen {

	//Constants
	private static final String PARM_10_DESCR = "Inbound File Path Location";
	private static final String PARM_30_DESCR = "Customer Contact Class";
	private static final String PARM_40_DESCR = "Customer Contact Type";
	private static final String PARM_70_DESCR = "Bankruptcy Case Claim Number Characteristic Type";
	private static final String PARM_80_DESCR = "Bankruptcy Case Petition Date Characteristic Type";
	private static final String PARM_90_DESCR = "Bankruptcy Case Petition Number Characteristic Type";
	private static final String PARM_110_DESCR = "Person ID Characteristic Type";
	private static final String PARM_120_DESCR = "Account ID Characteristic Type";
	private static final String PARM_130_DESCR = "Case ID Characteristic Type";
	private static final String PARM_140_DESCR = "Credit and Collection Case Source Characteristic Type";
	private static final String PARM_150_DESCR = "Credit and Collection Case Source Characteristic Value";
	//Start Add 5/26/2017 - JTiozon - Defect 193290
	private static final String PARM_160_DESCR = "Debt Class Code to Skip";
	private static final String PARM_170_DESCR = "Deceased SA Type";
	private static final String PARM_190_DESCR = "Customer Contact Class for Deceased Case";
	private static final String PARM_200_DESCR = "Customer Contact Type for Deceased Case";
	private static final String DECEASED = "DECEASED";
	//End Add 5/26/2017 - JTiozon - Defect 193290

	public JobWork getJobWork() { 
		// 2015-11-11. SMiranda. SF-55416. Start Change
		//List<ThreadWorkUnit> dummyList = new ArrayList<ThreadWorkUnit>();
		//ThreadWorkUnit workUnit = new ThreadWorkUnit();
		//dummyList.add(workUnit);
		//return createJobWorkForThreadWorkUnitList(dummyList);
		
		// Get file path and file name
		String filePathStr = getParameters().getFILE_PATH();
		String fileNameStr = getParameters().getFILE_NAME();
		File file = new File(filePathStr, fileNameStr);
		BufferedReader inputFile = null;
		
		// Open the file
		try{
			inputFile = new BufferedReader(new FileReader(file));
		}catch(Exception exception){
			addError(CustomMessageRepositoryMGE.ccb004FileOpenError(file.getPath().trim(), file.getName().trim()));
		}
		
		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
		String strRecordLine = " ";
		
		// Read the file
		try {
			strRecordLine = inputFile.readLine();
		
			// Create work units
			while (notNull(strRecordLine)){
				ThreadWorkUnit workUnit = new ThreadWorkUnit();
				workUnit.addSupplementalData("FILE_RECORD", strRecordLine);
				workUnits.add(workUnit);
				strRecordLine = inputFile.readLine();
			}		
		} catch (Exception exception) {
			addError(CustomMessageRepositoryMGE.ccb004FileReadError());
		}
		
		// Close the file
		try{
			inputFile.close();
		}catch (Exception exception){
			addError(CustomMessageRepositoryMGE.ccb004ErrorClosingFile(filePathStr,fileNameStr));
		}
		
		return createJobWorkForThreadWorkUnitList(workUnits);
		// 2015-11-11. SMiranda. SF-55416. End Change
	}

	@Override
	public void validateSoftParameters(boolean arg0) { 

		String parmInputFilePath;
		CustomerContactClass parmAgencyUpdateCustomerContactClass;
		String parmAgencyUpdateCustomerContactType;
		CaseType parmBankruptCaseType;
		CaseType parmDeceasedCaseType;
		
		CharacteristicType parmBankruptCaseClaimNbrCharType;
		CharacteristicType parmBankruptCasePetNbrCharType;
		CharacteristicType parmBankruptCasePetDtCharType;
		CharacteristicType parmPersonCharType;
		CharacteristicType parmAccountCharType;
		CharacteristicType parmCaseCharType;
		CharacteristicType parmCreditCollCaseSourceCharType;
		String parmCreditCollCaseSourceCharVal;
		//Start Add 5/26/2017 - JTiozon - Defect 193290
		String debtClassCodeToSkip[];
		CustomerContactClass ccClassForDeceasedCase;
		String ccTypeForDeceasedCase;
		String deceasedSaType;
		//End Add 5/26/2017 - JTiozon - Defect 193290
		parmInputFilePath = this.getParameters().getFILE_PATH().trim();
		parmBankruptCaseType = this.getParameters().getBNKRPT_CASE_TYPE();
		parmDeceasedCaseType = this.getParameters().getDECEASD_CASE_TYPE();
		
		//File Path parameter must be an existing and valid file path
		File fileValidator = new File(parmInputFilePath);		
		if (isNull(fileValidator)
				|| !fileValidator.isDirectory()) {
			// Batch parameter '%1%2' value (%3%4) is not a valid file path.
			addError(CustomMessageRepositoryMGE.commBatchParameterIsNotValidFilePath(PARM_10_DESCR, parmInputFilePath));
		}
		
		//Customer Contact Type must be valid for Customer Class.
		parmAgencyUpdateCustomerContactClass = this.getParameters().getAGY_UPD_CC_CLASS();
		parmAgencyUpdateCustomerContactType = this.getParameters().getAGY_UPD_CC_TYPE().trim();
		
		CustomerContactType_Id ccTypeId = new CustomerContactType_Id(parmAgencyUpdateCustomerContactClass, parmAgencyUpdateCustomerContactType);
		if (isNull(ccTypeId.getEntity())) {
			addError(CustomMessageRepositoryMGE.ccb004BatchParameterCCTypeInvalid(PARM_40_DESCR, 
					parmAgencyUpdateCustomerContactType.trim(), 
					PARM_30_DESCR,
					parmAgencyUpdateCustomerContactClass.getId().getTrimmedValue()));
		}
		
		// Bankruptcy Case Claim Characteristic Type must be valid for Bankruptcy Case Type
		parmBankruptCaseClaimNbrCharType = this.getParameters().getBNKRPT_BCLMN_CHAR_TYPE();
		validateCharacteristic(PARM_70_DESCR, parmBankruptCaseClaimNbrCharType, CharacteristicEntityLookup.constants.CASE);
		validateCaseCharacteristic(PARM_70_DESCR, parmBankruptCaseClaimNbrCharType, parmBankruptCaseType);

		// Bankruptcy Case Petition Date Characteristic Type must be valid for Bankruptc Case Type 
		parmBankruptCasePetDtCharType = this.getParameters().getBNKRPT_BCDATE_CHAR_TYPE();
		validateCharacteristic(PARM_80_DESCR, parmBankruptCasePetDtCharType, CharacteristicEntityLookup.constants.CASE);
		validateCaseCharacteristic(PARM_80_DESCR, parmBankruptCasePetDtCharType, parmBankruptCaseType);
		
		// Bankruptcy Case Petition Number Characteristic Type must be valid for Bankruptcy Case Type
		parmBankruptCasePetNbrCharType = this.getParameters().getBNKRPT_BCPET_CHAR_TYPE();
		validateCharacteristic(PARM_90_DESCR, parmBankruptCasePetNbrCharType, CharacteristicEntityLookup.constants.CASE);
		validateCaseCharacteristic(PARM_90_DESCR, parmBankruptCasePetNbrCharType, parmBankruptCaseType);
		
		//Person ID Characteristic Type must be valid for Bankruptcy To Do
		parmPersonCharType = this.getParameters().getPER_ID_CHAR_TYPE();
		validateCharacteristic(PARM_110_DESCR, parmPersonCharType, CharacteristicEntityLookup.constants.TO_DO_ENTRY);
		
		//Account ID Characteristic Type must be valid for Bankruptcy To Do
		parmAccountCharType = this.getParameters().getACCT_ID_CHAR_TYPE();
		validateCharacteristic(PARM_120_DESCR, parmAccountCharType, CharacteristicEntityLookup.constants.TO_DO_ENTRY);
		
		//Case ID Characteristic Type must be valid for Bankruptcy To Do
		parmCaseCharType = this.getParameters().getCASE_ID_CHAR_TYPE();
		validateCharacteristic(PARM_130_DESCR, parmCaseCharType, CharacteristicEntityLookup.constants.TO_DO_ENTRY);
		
		//Credit & Collection Case Source Characteristic Type must be valid for Bankruptcy and Deceased Case Types
		parmCreditCollCaseSourceCharType = this.getParameters().getCREDIT_COLL_CASE_SRC_CHAR_TYPE();
		validateCharacteristic(PARM_140_DESCR, parmCreditCollCaseSourceCharType, CharacteristicEntityLookup.constants.CASE);
		validateCaseCharacteristic(PARM_140_DESCR, parmCreditCollCaseSourceCharType, parmBankruptCaseType);
		validateCaseCharacteristic(PARM_140_DESCR, parmCreditCollCaseSourceCharType, parmDeceasedCaseType);
		
		//Credit & Collection Case Source Value must be valid if above char type is pre-defined
		parmCreditCollCaseSourceCharVal = this.getParameters().getCREDIT_COLL_CASE_SRC_CHAR_VAL();
		validatePredefinedCharacteristic(PARM_150_DESCR, parmCreditCollCaseSourceCharType, parmCreditCollCaseSourceCharVal);
		
		//Start Add 5/26/2017 - JTiozon - Defect 193290
		//Validate Debt Class Code to Skip
		debtClassCodeToSkip = this.getParameters().getDEBT_CL_CD_TO_SKIP().trim().split(",");
		
		for(String debtClass : debtClassCodeToSkip){
			DebtClass_Id debtClassId = new DebtClass_Id(debtClass.toUpperCase());
			
			if(isNull(debtClassId.getEntity())){ 
				addError(CustomMessageRepositoryMGE.ccb004invalidDebtClassCode(PARM_160_DESCR, debtClass));				
			}
		
		}	
		
		//Agency Update for Deceased Case Customer Contact Type must be valid for Customer Class.
		ccClassForDeceasedCase = this.getParameters().getAGY_UPD_DCS_CC_CLASS();
		ccTypeForDeceasedCase = this.getParameters().getAGY_UPD_DCS_CC_TYPE();
				
		CustomerContactType_Id ccTypeDCS = new CustomerContactType_Id(ccClassForDeceasedCase, ccTypeForDeceasedCase);
		if (isNull(ccTypeDCS.getEntity())) { 
			addError(CustomMessageRepositoryMGE.ccb004CCTypeInvalid(PARM_200_DESCR, 
					ccTypeForDeceasedCase.trim(), 
					PARM_190_DESCR,
					ccClassForDeceasedCase.getId().getTrimmedValue()));
		}		
		
		deceasedSaType = this.getParameters().getDECEASED_SA_TYPE().trim();
		if(!isSaTypeValid(deceasedSaType)){
			addError(CustomMessageRepositoryMGE.ccb004invalidSaTypeParm(PARM_170_DESCR, deceasedSaType));
		}
		//End Add 5/26/2017 - JTiozon - Defect 193290
		

    }
	
	private void validateCharacteristic(String parmDescr, CharacteristicType charType, CharacteristicEntityLookup charEntity) {
		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, charEntity);
		if(isNull(charEntityId.getEntity())) {
			addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharTypeForEntity(parmDescr, 
					charType.getId().getTrimmedValue(), 
					charEntity.getLookupValue().fetchLanguageDescription()));
		}
	}
	
	private void validateCaseCharacteristic(String parmDescr, CharacteristicType charType, CaseType caseType) {
		CharacteristicTypeCaseType_Id charTypeCaseTypeId = new CharacteristicTypeCaseType_Id(charType, caseType);
		if(isNull(charTypeCaseTypeId.getEntity())) {
			addError(CustomMessageRepositoryMGE.commBatchParameterCharTypeInvalidForCaseType(parmDescr, 
					charType.getId().getTrimmedValue(),
					caseType.getId().getTrimmedValue()));
		}
	}
	
	private void validatePredefinedCharacteristic(String parmDescr, CharacteristicType charType, String charVal) {
		CharacteristicValue_Id  charValId = new CharacteristicValue_Id(charType, charVal);
		if(isNull(charValId.getEntity())) {
			addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharValueForCharType(parmDescr,
					charVal.trim(),
					charType.getId().getTrimmedValue()));
		}
	}
	//Start Add 5/26/2017 - JTiozon - Defect 193290
	/**
	 * This method validates a SA Type parameter
	 * @return
	 */
	private boolean isSaTypeValid(String saType){
		
		boolean isSaTypeValid = false;
	
		String sql = "SELECT " +
					 "	SA_TYPE_CD " +
					 "FROM " +
					 "	CI_SA_TYPE " +
					 "WHERE " +
					 "	SA_TYPE_CD = :saType";
	
		PreparedStatement prepStmt = createPreparedStatement(sql, getClass().getName());
		prepStmt.bindStringProperty("saType", ServiceAgreementType.properties.saType, saType);
		
		List<SQLResultRow> resultRow = prepStmt.list();
		
		if(resultRow.size() >0){
			isSaTypeValid = true;
		}
		
		prepStmt.close();
		
		return isSaTypeValid;
	}
	//End Add 5/26/2017 - JTiozon - Defect 193290
	
	public Class<CmMaintainCollectionAgencyPlacementBatchWorker> getThreadWorkerClass() {
		return CmMaintainCollectionAgencyPlacementBatchWorker.class;
	}

	public static class CmMaintainCollectionAgencyPlacementBatchWorker extends
			CmMaintainCollectionAgencyPlacementBatchWorker_Gen {
		
		//Delimiter
		private static final String DELIMITER = ",";
		private static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
		private static final String ACTION_AGY = "AGY";
		private static final String ACTION_BNK= "BNK";
		private static final String ACTION_DEC = "DCS";
		private static final String ACCT_FIELD_DESCR = "Account ID";
		/*
		 * Start Add - EQuint - 2021-04-05 - SA 363689
		 */
		private static final String PREM_FIELD_DESCR = "Premise ID";
		/*
		 * End Add - EQuint - 2021-04-05 - SA 363689
		 */
		private static final String COLL_AGY_REF_FIELD_DESCR = "Collection Agency Referral ID";
		private static final String ACTION_FIELD_DESCR = "Action";
		private static final String NEW_COL_AGY_FIELD_DESCR = "New Collection Agency ID";
		private static final String OLD_COL_AGY_FIELD_DESCR = "Old Collection Agency ID";
		private static final String PLACE_DATE_FIELD_DESCR = "Placement Date";
		private static final String BKRPT_PET_NBR_FIELD_DESCR = "Bankruptcy Petition Number";
		private static final String BKRPT_PET_DATE_FIELD_DESCR = "Bankruptcy Petition Date";
		private static final String PET_NBR_C7 = "C7";
		private static final String PET_NBR_C9 = "C9";
		private static final String PET_NBR_C11 = "C11";
		private static final String PET_NBR_C12 = "C12";
		private static final String PET_NBR_C13 = "C13";
		private static final String DRILL_KEY_CASE = "CASE_ID";
		private static final BusinessObject_Id  COLL_AGY_PLACE_TYPE_BO = new BusinessObject_Id("CM-CollAgencyPlacementType");
		private static final MaintenanceObject_Id COLL_AGY_REF_MO = new MaintenanceObject_Id("COLL AGY REF");
        private final static CharacteristicType_Id CURRENT_COLL_AGY_CHAR_TYPE = new CharacteristicType_Id("CM-CAGCY");
        private static final CharacteristicType_Id CUSTOMER_CONTACT_SVC_TASK_LOG_CHAR_TYPE = new CharacteristicType_Id("C1-CC");
        private final static CharacteristicType_Id RELATED_SA_CHAR_TYPE = new CharacteristicType_Id("C1-SA");
        private static final CharacteristicType_Id CASE_SVC_TASK_LOG_CHAR_TYPE = new CharacteristicType_Id("CASE");
        
		//Soft Parameters
        // 2015-11-11. SMiranda. SF-55416. Start Delete
		//private String parmInputFileName;
		//private String parmInputFilePath;
        // 2015-11-11. SMiranda. SF-55416. End Delete
		private CustomerContactClass parmAgencyUpdateCustomerContactClass;
		private String parmAgencyUpdateCustomerContactType;
		private CaseType parmBankruptCaseType;
		private ToDoType parmBankruptToDoType;
		private CaseType parmDeceasedCaseType;
		private CharacteristicType parmBankruptCaseClaimNbrCharType;
		private CharacteristicType parmBankruptCasePetNbrCharType;
		private CharacteristicType parmBankruptCasePetDtCharType;
		private CharacteristicType parmPersonCharType;
		private CharacteristicType parmAccountCharType;
		private CharacteristicType parmCaseCharType;
		private CharacteristicType parmCreditCollCaseSourceCharType;
		private String parmCreditCollCaseSourceCharVal;
		//Start Add 5/26/2017 - JTiozon - Defect 193290
		private	String debtClassCodeToSkip[];
		private	String deceasedSaType;
		private AdjustmentType deceasedAdjustmentType;
		private CustomerContactClass ccClassForDeceasedCase;
		private String ccTypeForDeceasedCase;
		private List<String> debtClassList = new ArrayList<String>();	
		//End Add 5/26/2017 - JTiozon - Defect 193290
		//Input Field Values
		private String accountIdStr;
		/*
		 * Start Add - EQuint - 2021-04-05 - SA 363689
		 */
		private String premiseIdStr;
		/*
		 * End Add - EQuint - 2021-04-05 - SA 363689
		 */		
		private String collAgyRefIdStr;
		private String action;
		private String oldCollAgyCdStr;
		private String newCollAgyCdStr;
		private String datePlacedStr;
		private String bkrptClaimNbrStr;
		private String bkrptPetNbrStr;
		private String bkrptPetDateStr;

		//Work Variables
		private Account account;
		private CollectionAgencyReferral collAgyRef;
		private int processedRecord = 0;
        private int recordInError = 0;
        private int recordLineNbr = 0;
	    // START ADD - JHERNA - 2015-07-15 - 3247212
	    private Bool failedToRetrieveCollAgyPlacement = Bool.FALSE;
	    // END ADD - JHERNA - 2015-07-15 - 3247212

	    /*
		 * Start Add - EQuint - 2021-04-05 - SA 363689
		 */
	    private ServiceTask collectionAgencyPlacement;
	    /*
		 * End Add - EQuint - 2021-04-05 - SA 363689
		 */
        
		public ThreadExecutionStrategy createExecutionStrategy() {
	        // 2015-11-11. SMiranda. SF-55416. Start Change
			//return new SingleTransactionStrategy(this);
			return new CommitEveryUnitStrategy(this);
	        // 2015-11-11. SMiranda. SF-55416. End Delete
		}
		//Start Add 5/26/2017 - JTiozon - Defect 193290
		@Override
		public void initializeThreadWork(boolean bool) {	
			
			debtClassCodeToSkip = this.getParameters().getDEBT_CL_CD_TO_SKIP().trim().split(",");
			for(String debtClass : debtClassCodeToSkip){
				debtClassList.add(debtClass.toUpperCase().trim());			
			}
			
		}
		//End Add 5/26/2017 - JTiozon - Defect 193290
		
		@Override
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit arg0) throws ThreadAbortedException, RunAbortedException {
			
			// Get the parameters.
			getSoftParameters();
			// 2015-11-11. SMiranda. SF-55416. Start Delete
			//Open the input file.
			//File inputFile = new File (parmInputFilePath, parmInputFileName);
			//BufferedReader bufferedReader = openFile(inputFile);	
			// 2015-11-11. SMiranda. SF-55416. End Delete
			String recordLine = "";
			// 2015-11-11. SMiranda. SF-55416. Start Add
			recordLine = (String) arg0.getSupplementallData("FILE_RECORD"); 
			// 2015-11-11. SMiranda. SF-55416. End Add
			Bool errorEncountered = Bool.FALSE;
			// 2015-11-11. SMiranda. SF-55416. Start Delete
			//while (!isBlankOrNull(recordLine = readFile(bufferedReader))) {
			// 2015-11-11. SMiranda. SF-55416. End Delete	
				processedRecord++;
				
				// 2015-11-11. SMiranda. SF-55416. Start Add
				recordLineNbr++;
				// 2015-11-11. SMiranda. SF-55416. End Add
				
				//Retrieve a row from the input file.
				// 2015-11-11. SMiranda. SF-55416. Start Change
				//errorEncountered = retrieveDataFromRecord(recordLine, inputFile);
				errorEncountered = retrieveDataFromRecord(recordLine);
				// 2015-11-11. SMiranda. SF-55416. End Change
								
				//Process only if there are no records encountered.
				if(errorEncountered.isFalse()) {

					/*
					 * Start Delete - EQuint - 2021-04-05 - SA 363689
					 */
				    // // Find the active collection agency placement record using the collection agency referral ID
					// ServiceTask collectionAgencyPlacement = getCollectionAgencyPlacement(collAgyRef); 
					/*
					 * End Delete - EQuint - 2021-04-05 - SA 363689
					 */

				    // START ADD - JHERNA - 2015-07-15 - 3247212
					if (failedToRetrieveCollAgyPlacement.isTrue()) {
				    	// add to the records in error count
						recordInError++;
						// 2015-11-11. SMiranda. SF-55416. Start Change
				    	// skip processing this record and proceed to the next record line on the file
				    	//continue;
						// 2015-11-11. SMiranda. SF-55416. End Change
					//  81472 kiran 01/12/2018
						WorkUnitResult result = new WorkUnitResult(true);

						//result.setUnitsProcessed(1);
						
						result.setUnitsInError(1);
						

						
						return result;
					//  81472 kiran 01/12/2018
					}
				    // END ADD - JHERNA - 2015-07-15 - 3247212
				    
                    // Action is Agency Update
					if(action.equals(ACTION_AGY)) {
						
						// Update the customer's current collection agency with the new agency
						/*
						 * Start Change - EQuint - 2021-04-05 - SA 363689
						 */
						// updateCurrentAgency(collectionAgencyPlacement, newCollAgyCdStr);
						// // Create a log record to note the new agency placement
						// createCollectionAgencyPlacementLog(collectionAgencyPlacement);
						 updateCurrentAgency(collectionAgencyPlacement, premiseIdStr, newCollAgyCdStr);
						/*
						 * End Change - EQuint - 2021-04-05 - SA 363689
						 */
						
						// Create a customer contact using the AGY-CL and AGY-CC parameters
						CustomerContact agencyUpdateCustomerContact = createCustomerContact(parmAgencyUpdateCustomerContactClass, parmAgencyUpdateCustomerContactType);
                        
                        // Create a log record to note the new customer contact
						createCustomerContactCollectionAgencyPlacementLog(collectionAgencyPlacement, CUSTOMER_CONTACT_SVC_TASK_LOG_CHAR_TYPE.getEntity(), agencyUpdateCustomerContact);
						
					} else if(action.equals(ACTION_BNK)) { // If Action is Bankrupt
						
						// Create a case for follow up using the Bankrupt Case Type parameter
						ToDoCase bankruptCase = createCase(parmBankruptCaseType);
						
						// Create a todo using the Bankrupt To Do Type parameter
						createToDo(parmBankruptToDoType, bankruptCase);
                        
                        // Create a log record to note the new Bankruptcy case
						createCaseCollectionAgencyPlacementLog(collectionAgencyPlacement, CASE_SVC_TASK_LOG_CHAR_TYPE.getEntity(), bankruptCase);
						
					} else if(action.equals(ACTION_DEC)) { // If Action is Deceased
						//Start Change 5/26/2017 - JTiozon - Defect 193290						
						Bool isCaseCreated = Bool.FALSE;
						Person person = getFinanciallyResponsiblePerson();
						
						//If Person is linked to multiple account, create a case for manual follow up.						
						int personLinkedToMultiAccount = checkPersonLinkedToMultiAccount(person).size();
						if(personLinkedToMultiAccount > 1){ 
							// Create a case for follow up using the Deceased Case Type parameter
							ToDoCase deceasedCase = createCase(parmDeceasedCaseType);	
						
							// Create a log record to note the new Deceased case
							createCaseCollectionAgencyPlacementLog(collectionAgencyPlacement, CASE_SVC_TASK_LOG_CHAR_TYPE.getEntity(), deceasedCase);
							isCaseCreated = Bool.TRUE;
						}						
						
						if(isCaseCreated.isFalse()){
							//If there are other persons on the account, create a case for manual follow up.
							int acctPer = account.getPersons().size();
							if(acctPer > 1){ 
								// Create a case for follow up using the Deceased Case Type parameter
								ToDoCase deceasedCase = createCase(parmDeceasedCaseType);	
								
								// Create a log record to note the new Deceased case
								createCaseCollectionAgencyPlacementLog(collectionAgencyPlacement, CASE_SVC_TASK_LOG_CHAR_TYPE.getEntity(), deceasedCase);
								isCaseCreated = Bool.TRUE;
							}
						}
						
						if(isCaseCreated.isFalse()){
							/*
							 * Review the ACCOUNT for SA's to exclude by DEBT_CL_CD values
							 * If any SA's exist on the ACCOUNT that have this DEBT_CL_CD, create a case for manual follow up 
							 */
							Bool accountHasSaByDebtClass = Bool.FALSE;
							
							int acctSaByDebtClass = retrieveAccountSaByDebtClass().size();
							
							if(acctSaByDebtClass > 0){ 
								accountHasSaByDebtClass = Bool.TRUE;
									
								// Create a case for follow up using the Deceased Case Type parameter
								ToDoCase deceasedCase = createCase(parmDeceasedCaseType);	
								
								// Create a log record to note the new Deceased case
								createCaseCollectionAgencyPlacementLog(collectionAgencyPlacement, CASE_SVC_TASK_LOG_CHAR_TYPE.getEntity(), deceasedCase);
								isCaseCreated = Bool.TRUE;
							}
							
							if(accountHasSaByDebtClass.isFalse()){
								List<SQLResultRow> sqlResultRow = retrieveAccountSAs();			
									
								/*
								 * Transfer the Debit or Credit balance of this SA(s) to the new Deceased SA
								 */								
								ServiceAgreement deceasedSa = null;	
								for(SQLResultRow resultRow : sqlResultRow){
									
									ServiceAgreement sa = resultRow.getEntity("SA_ID", ServiceAgreement.class);
									
									Money saCurrentBalance = sa.getCurrentBalance();									
									
									if(!saCurrentBalance.isZero()){
										if(isNull(deceasedSa)){
											deceasedSa = createDeceasedSA();
										}
										CreateFrozenAdjustmentData frozenAdjData = CreateFrozenAdjustmentData.Factory.newInstance();
										frozenAdjData.setServiceAgreement(sa);
										frozenAdjData.setAdjustmentType(deceasedAdjustmentType);	
										frozenAdjData.setAllowZeroAmount(Bool.FALSE);									
										frozenAdjData.setTransferServiceAgreement(deceasedSa);
										frozenAdjData.setAdjustmentAmount(saCurrentBalance);
										CreateFrozenAdjustment frozenAdjustment = CreateFrozenAdjustment.Factory.newInstance();
										frozenAdjData = frozenAdjustment.createFrozenAdjustment(frozenAdjData);	
									}
								
								}
								
								if(notNull(deceasedSa)){
									//Create a customer contact on the account's main person
									createCustomerContact(ccClassForDeceasedCase, ccTypeForDeceasedCase);
										
									//Change the account's main person relationship type to "DECEASED"
									Person mainPerson = getMainAccountPerson(account);
									AccountPerson_Id acctPerId = new AccountPerson_Id(mainPerson, account);
									AccountPerson acctPerson = acctPerId.getEntity();
										
									AccountPerson_DTO acctPerDTO = acctPerson.getDTO();
									acctPerDTO.setAccountRelationshipTypeId(new AccountRelationshipType_Id(DECEASED));
									acctPerson.setDTO(acctPerDTO);
								}
								
							}
							
						}
						//End Change 5/26/2017 - JTiozon - Defect 193290
												
					}
					
				} else {
					
					recordInError++;
				}
			// 2015-11-11. SMiranda. SF-55416. Start Delete
			//}
			// 2015-11-11. SMiranda. SF-55416. End Delete
			WorkUnitResult result = new WorkUnitResult(true);
			// 2015-11-11. SMiran. SF-55416. Start Change
			//result.setUnitsProcessed(processedRecord);
			//result.setUnitsInError(recordInError);
			result.setUnitsProcessed(1);
			if(errorEncountered.isTrue()){
				result.setUnitsInError(1);
			}
			// 2015-11-11. SMiran. SF-55416. End Change
			
			return result;
		}
		
		// 2015-11-11. SMiranda. SF-55416. Start Delete
		///**
		// * Batch Worker: Open File
		// */
		//private BufferedReader openFile(File file){
		
		//	// Open the file. If an error was encountered, log File Open Error 
		//	BufferedReader bufferedReader = null;
		//	try {
		//		bufferedReader = new BufferedReader(new FileReader(file));                    
		//	} catch (Exception exception) {
				
		//		// Raise an error
		//		addError(CustomMessageRepositoryMGE.ccb004FileOpenError(file.getPath().trim(), file.getName().trim()));
		//	}
		//	return bufferedReader; 
		//}		
		
		///**
		// * Batch Worker: Read File
		// */
		//private String readFile(BufferedReader bufferedReader){
		//	// Read from the file. If an error was encountered, log File Read Error
		//	String record = null;
		//	try {                           
		//		record =  bufferedReader.readLine();
		//		recordLineNbr++;
		//	} catch (Exception exception) {
		//		addError(CustomMessageRepositoryMGE.ccb004FileReadError());
		//	}
		//	return record;
		//}
		// 2015-11-11. SMiranda. SF-55416. End Delete
		/**
		 * Method which would retrieve the data from the input file's record line
		 * @param recordLine the record line
		 * @param file the input file
		 * @return hasError True if an error is encountered while retrieving data, otherwise false is returned
		 */
		//private Bool retrieveDataFromRecord(String recordLine, File file) {
		private Bool retrieveDataFromRecord(String recordLine) {
			
			Bool hasError = Bool.FALSE;
			Bool isInvalidLength = Bool.FALSE;
			
			/*
			 * Start Change - EQuint - 2021-04-05 - SA 363689
			 */
			// String[] record = recordLine.split(DELIMITER, 9);
			String[] record = recordLine.split(DELIMITER, 10);
			/*
			 * End Change - EQuint - 2021-04-05 - SA 363689
			 */
			DateFormat dateFormat = new DateFormat(DATE_FORMAT_YYYY_MM_DD);
			
			// Get the data to be used from the file (data delimiter is a comma and maximum number or field is sixteen (16)
			accountIdStr = record[0].trim();
			collAgyRefIdStr = record[1].trim();
			/*
			 * Start Change - EQuint - 2021-04-05 - SA 363689
			 */
//			action = record[2].trim();
//			oldCollAgyCdStr = record[3].trim();
//			newCollAgyCdStr = record[4].trim();
//			datePlacedStr = record[5].trim();
//			bkrptClaimNbrStr = record[6].trim();
//			bkrptPetDateStr = record[7].trim();
//			bkrptPetNbrStr = record[8].trim();
			
			premiseIdStr = record[2].trim();
			action = record[3].trim();
			oldCollAgyCdStr = record[4].trim();
			newCollAgyCdStr = record[5].trim();
			datePlacedStr = record[6].trim();
			bkrptClaimNbrStr = record[7].trim();
			bkrptPetDateStr = record[8].trim();
			bkrptPetNbrStr = record[9].trim();
			/*
			 * End Add - EQuint - 2021-04-05 - SA 363689
			 */

			// Check the Account ID field length
			isInvalidLength = checkValueLength(accountIdStr, Account_Id.FIELD_SIZE, ACCT_FIELD_DESCR);
			
			if(isInvalidLength.isFalse()) {
				// Check if the Account ID exists in CC&B
				Account_Id acctId = new Account_Id(accountIdStr);
				if (isNull(acctId.getEntity())) {
					logError(CustomMessageRepositoryMGE.ccb004InvalidValue(String.valueOf(recordLineNbr), ACCT_FIELD_DESCR, accountIdStr));
					hasError = Bool.TRUE;
				} else {
					account = acctId.getEntity();
				}
			} else {
				hasError = Bool.TRUE;
			}
			
			/*
			 * Start Add - EQuint - 2021-04-05 - SA 363689
			 */
			Bool isPremiseError = Bool.FALSE;
			isInvalidLength = checkValueLength(premiseIdStr, Premise_Id.FIELD_SIZE, PREM_FIELD_DESCR);
			if(isInvalidLength.isFalse()) {
				// check if premise exists
				Premise prem = new Premise_Id(premiseIdStr).getEntity();
				if (isNull(prem)) {
					logError(CustomMessageRepositoryMGE.ccb004InvalidValue(String.valueOf(recordLineNbr), PREM_FIELD_DESCR, premiseIdStr));
					hasError = Bool.TRUE;
					isPremiseError = Bool.TRUE;
				}
			} else {
				hasError = Bool.TRUE;
			}
			/*
			 * End Add - EQuint - 2021-04-05 - SA 363689
			 */
			
			// Check the Collection Agency Referral ID field length
			isInvalidLength = checkValueLength(collAgyRefIdStr, CollectionAgencyReferral_Id.FIELD_SIZE, COLL_AGY_REF_FIELD_DESCR);
			
			if(isInvalidLength.isFalse()) {
				// Check if the Collection Agency Referral ID exists in CC&B
				CollectionAgencyReferral_Id collAgyRefId = new CollectionAgencyReferral_Id(collAgyRefIdStr);
				if(isNull(collAgyRefId.getEntity())) {
					logError(CustomMessageRepositoryMGE.ccb004InvalidValue(String.valueOf(recordLineNbr), COLL_AGY_REF_FIELD_DESCR, collAgyRefIdStr));
					hasError = Bool.TRUE;
				} else {
					collAgyRef = collAgyRefId.getEntity(); 
					/* 
					 * Start Add - EQuint - 2021-04-05 - SA 363689
					 */
					// Get the related SAs on service task and check if there's SA with the provided premise ID
					if (isPremiseError.isFalse()) {
						collectionAgencyPlacement = getCollectionAgencyPlacement(collAgyRef); 
						/*
						 * Start Add - EQuint - 2021-05-05 - SA 368134
						 */
						if (notNull(collectionAgencyPlacement)) {
						/*
						 * End Add - EQuint - 2021-05-05 - SA 368134
						 */
							String filterStr = "WHERE this.id.characteristicType.id = :charTypeId ";
							CharacteristicType charType = RELATED_SA_CHAR_TYPE.getEntity();
							if (charType.getCharacteristicType().isPredefinedValue()) {
								filterStr += " AND this.characteristicValue IN ";
							} else if (charType.getCharacteristicType().isForeignKeyValue()) {
								filterStr += " AND this.characteristicValueForeignKey1 IN ";
							} else {
								filterStr += " AND this.adhocCharacteristicValue IN ";
							}
							filterStr += " (SELECT sa.id FROM ServiceAgreement sa"
									+ " WHERE sa.premiseId = :premId"
									+ " AND sa.account.id = :acctId ) ";
							ListFilter<ServiceTaskCharacteristic> stCharsFilter = collectionAgencyPlacement.getCharacteristics().createFilter(filterStr, getClass().getName());
							stCharsFilter.bindId("charTypeId", RELATED_SA_CHAR_TYPE);
							stCharsFilter.bindId("premId", new Premise_Id(premiseIdStr));
							stCharsFilter.bindId("acctId", account.getId());
							
							if (stCharsFilter.listSize() == 0) {
								BusinessObjectInstance boInstance = BusinessObjectInstance.create(collectionAgencyPlacement.getBusinessObject());
								boInstance.set("serviceTaskId", collectionAgencyPlacement.getId().getTrimmedValue());
								boInstance = BusinessObjectDispatcher.read(boInstance);
								String woId = boInstance.getString("relatedWriteOffProcess");
								logError(CustomMessageRepositoryMGE.ccb004UnableToFindWOSAwithPremise(String.valueOf(recordLineNbr), premiseIdStr, woId));
								hasError = Bool.TRUE;
							}
						/*
						 * Start Add - EQuint - 2021-05-05 - SA 368134
						 */
						} else {
							hasError = Bool.TRUE;
						}
						/*
						 * End Add - EQuint - 2021-05-05 - SA 368134
						 */
					}
					/*
					 * End Add - EQuint - 2021-04-05 - SA 363689
					 */
				}
			} else {
				hasError = Bool.TRUE;
			}
			
			// Check if the Action is valid
			if(!action.equalsIgnoreCase(ACTION_AGY) 
					&& !action.equalsIgnoreCase(ACTION_BNK) 
					&& !action.equalsIgnoreCase(ACTION_DEC)) {
				logError(CustomMessageRepositoryMGE.ccb004InvalidValue(String.valueOf(recordLineNbr), ACTION_FIELD_DESCR, action));
				hasError = Bool.TRUE;
			}
			
			// Check the Old Collection Agency Code field length
			isInvalidLength = checkValueLength(oldCollAgyCdStr, CollectionAgency_Id.FIELD_SIZE, OLD_COL_AGY_FIELD_DESCR);
			
			if(isInvalidLength.isFalse()) {
				// Check if the Old Collection Agency Code exists in CC&B
				CollectionAgency_Id collAgyId = new CollectionAgency_Id(oldCollAgyCdStr);
				if(isNull(collAgyId.getEntity())) {
					logError(CustomMessageRepositoryMGE.ccb004InvalidValue(String.valueOf(recordLineNbr), OLD_COL_AGY_FIELD_DESCR, oldCollAgyCdStr));
					hasError = Bool.TRUE;
				} 
			} else {
				hasError = Bool.TRUE;
			}
			
			// Check the New Collection Agency Code field length
			isInvalidLength = checkValueLength(newCollAgyCdStr, CollectionAgency_Id.FIELD_SIZE, NEW_COL_AGY_FIELD_DESCR);
			
			if(isInvalidLength.isFalse()) {
				// Check if the New Collection Agency Code exists in CC&B
				CollectionAgency_Id collAgyId = new CollectionAgency_Id(newCollAgyCdStr);
				if(isNull(collAgyId.getEntity())) {
					logError(CustomMessageRepositoryMGE.ccb004InvalidValue(String.valueOf(recordLineNbr), NEW_COL_AGY_FIELD_DESCR, newCollAgyCdStr));
					hasError = Bool.TRUE;
				}
			} else {
				hasError = Bool.TRUE;
			}
			
			// Check if the dates are in the correct format
			// Placement Date
			try {
				dateFormat.parseDate(datePlacedStr);
			} catch (DateFormatParseException e) {
				logError(CustomMessageRepositoryMGE.ccb004InvalidFormat(String.valueOf(recordLineNbr), PLACE_DATE_FIELD_DESCR, datePlacedStr, DATE_FORMAT_YYYY_MM_DD));
				hasError = Bool.TRUE;
			}
            
            if (action.equalsIgnoreCase(ACTION_BNK)) {
    			// Petition Date
    			try {
    				dateFormat.parseDate(bkrptPetDateStr);
    			} catch (DateFormatParseException e) {
    				logError(CustomMessageRepositoryMGE.ccb004InvalidFormat(String.valueOf(recordLineNbr), BKRPT_PET_DATE_FIELD_DESCR, bkrptPetDateStr, DATE_FORMAT_YYYY_MM_DD));
    				hasError = Bool.TRUE;
    			}
    			
    			// Check if the Petition Number is valid
    			if(!(bkrptPetNbrStr.equalsIgnoreCase(PET_NBR_C7) 
    					|| bkrptPetNbrStr.equalsIgnoreCase(PET_NBR_C9) 
    					|| bkrptPetNbrStr.equalsIgnoreCase(PET_NBR_C11)
    					|| bkrptPetNbrStr.equalsIgnoreCase(PET_NBR_C12)
    					|| bkrptPetNbrStr.equalsIgnoreCase(PET_NBR_C13))){
    				logError(CustomMessageRepositoryMGE.ccb004InvalidValue(String.valueOf(recordLineNbr), BKRPT_PET_NBR_FIELD_DESCR, bkrptPetNbrStr));
    				hasError = Bool.TRUE;
    			} 
            }
			
			return hasError;			
		}
		

		private void getSoftParameters() {
	        // 2015-11-11. SMiranda. SF-55416. Start Delete
			//parmInputFilePath = this.getParameters().getFILE_PATH();
			//parmInputFileName = this.getParameters().getFILE_NAME();
	        // 2015-11-11. SMiranda. SF-55416. Start Delete
			parmAgencyUpdateCustomerContactClass = this.getParameters().getAGY_UPD_CC_CLASS();
			parmAgencyUpdateCustomerContactType = this.getParameters().getAGY_UPD_CC_TYPE();
			parmBankruptCaseType = this.getParameters().getBNKRPT_CASE_TYPE();
			parmBankruptToDoType = this.getParameters().getBNKRPT_TD_TYPE();
			parmDeceasedCaseType = this.getParameters().getDECEASD_CASE_TYPE();
			parmBankruptCaseClaimNbrCharType = this.getParameters().getBNKRPT_BCLMN_CHAR_TYPE();
			parmBankruptCasePetNbrCharType = this.getParameters().getBNKRPT_BCPET_CHAR_TYPE();
			parmBankruptCasePetDtCharType = this.getParameters().getBNKRPT_BCDATE_CHAR_TYPE();
			parmPersonCharType = this.getParameters().getPER_ID_CHAR_TYPE();
			parmAccountCharType = this.getParameters().getACCT_ID_CHAR_TYPE();
			parmCaseCharType = this.getParameters().getCASE_ID_CHAR_TYPE();
			parmCreditCollCaseSourceCharType = this.getParameters().getCREDIT_COLL_CASE_SRC_CHAR_TYPE();
			parmCreditCollCaseSourceCharVal = this.getParameters().getCREDIT_COLL_CASE_SRC_CHAR_VAL();
			//Start Add 5/26/2017 - JTiozon - Defect 193290
			debtClassCodeToSkip = this.getParameters().getDEBT_CL_CD_TO_SKIP().trim().split(",");
			deceasedSaType = this.getParameters().getDECEASED_SA_TYPE();
			deceasedAdjustmentType = this.getParameters().getDECEASED_ADJT();
			ccClassForDeceasedCase = this.getParameters().getAGY_UPD_DCS_CC_CLASS();
			ccTypeForDeceasedCase = this.getParameters().getAGY_UPD_DCS_CC_TYPE();
			//End Add 5/26/2017 - JTiozon - Defect 193290
        }
		
		/**
		 * This method checks if the length of the given string matches the expected field size.
		 * @param fieldValue
		 * @param fieldLength
		 * @param fieldDescr
		 * @return
		 */
		private Bool checkValueLength(String fieldValue, int fieldLength, String fieldDescr) {
			
			Bool isError = Bool.FALSE;
			int valueLength = fieldValue.length();
			
			if(valueLength > fieldLength) {
				logError(CustomMessageRepositoryMGE.ccb004InvalidValue(String.valueOf(recordLineNbr), fieldDescr, fieldValue));
				isError = Bool.TRUE;
			}
			
			return isError;
		}
		
		/**
		 * This method retrieves the active collection agency placement associated with the collection agency referral.
		 * @param collAgyReferral
		 * @return ServiceTask
		 */
		private ServiceTask getCollectionAgencyPlacement(CollectionAgencyReferral collAgyReferral) {
			
			ServiceTask serviceTask = null;
		    // START ADD - JHERNA - 2015-07-15 - 3247212
		    // Re-initialize flag
			failedToRetrieveCollAgyPlacement = Bool.FALSE;
		    // END ADD - JHERNA - 2015-07-15 - 3247212
			PreparedStatement getServiceTask = createPreparedStatement("SELECT " +	
					"	ST.F1_SVC_TASK_ID " +
					"FROM " +
					"	F1_SVC_TASK_TYPE STT, " +
					"	F1_SVC_TASK ST, " +
					"	F1_SVC_TASK_REL_OBJ STR, " +
					"   F1_BUS_OBJ_STATUS BOS " +
				    "WHERE " +
				    " 	STT.BUS_OBJ_CD = :taskTypeBo " +
				    "  	AND ST.BUS_OBJ_CD = STT.TRANS_BUS_OBJ_CD " +
				    "  	AND ST.F1_STASK_TYPE_CD = STT.F1_STASK_TYPE_CD " +
				    "   AND BOS.BUS_OBJ_CD = ST.BUS_OBJ_CD " +
				    "  	AND BOS.BO_STATUS_CD = ST.BO_STATUS_CD " +
                    "   AND BOS.BO_STATUS_COND_FLG <> :finalBoStatusCondition " +
				    "  	AND STR.F1_SVC_TASK_ID = ST.F1_SVC_TASK_ID " +
				    "  	AND STR.MAINT_OBJ_CD = :mo " +
				    //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				    //"  	AND STR.PK_VALUE1 = :referral ");
					"  	AND STR.PK_VALUE1 = :referral ", getClass().getName());
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			
			getServiceTask.bindId("mo", COLL_AGY_REF_MO);
			getServiceTask.bindEntity("referral", collAgyReferral);
            getServiceTask.bindLookup("finalBoStatusCondition", BusinessObjectStatusConditionLookup.constants.FINAL);
			getServiceTask.bindId("taskTypeBo", COLL_AGY_PLACE_TYPE_BO);
			
			List<SQLResultRow> serviceTaskList = getServiceTask.list();
			
			if(serviceTaskList.size() > 0) {
				SQLResultRow resultRow = serviceTaskList.get(0);
				serviceTask = resultRow.getEntity("F1_SVC_TASK_ID", ServiceTask.class);
			}
					
			getServiceTask.close();
            
            if (isNull(serviceTask)) {
    		    // START CHANGE - JHERNA - 2015-07-15 - 3247212    			
                //addError(CustomMessageRepositoryMGE.ccb004NoCollectionAgencyPlacementFound(String.valueOf(recordLineNbr), collAgyReferral));
            	failedToRetrieveCollAgyPlacement = Bool.TRUE;
            	logError(CustomMessageRepositoryMGE.ccb004NoCollectionAgencyPlacementFound(String.valueOf(recordLineNbr), collAgyReferral));
    		    // END CHANGE - JHERNA - 2015-07-15 - 3247212
            }
			
			return serviceTask;	
		}
		
		/*
		 * Start Change - EQuint - 2021-04-05 - SA 363689
		 */
		
//		/**
//		 * This method updates the current agency on the collection agency placement.
//		 * @param serviceTask
//		 * @param currentAgency
//		 */
//		private void updateCurrentAgency(ServiceTask serviceTask, String currentAgency) {
//			
//			ServiceTaskCharacteristic_DTO currentAgencyCharDto = serviceTask.getCharacteristics().newChildDTO();
//            
//            CharacteristicTypeLookup characteristicType = CURRENT_COLL_AGY_CHAR_TYPE.getEntity().getCharacteristicType();
//            if (characteristicType.isForeignKeyValue()) {
//                currentAgencyCharDto.setCharacteristicValueForeignKey1(currentAgency.trim());
//            } else if (characteristicType.isPredefinedValue()) {
//                currentAgencyCharDto.setCharacteristicValue(currentAgency.trim());
//            } else {
//                currentAgencyCharDto.setAdhocCharacteristicValue(currentAgency.trim());
//            }
//			
//			PreparedStatement getMaxCharSequence = createPreparedStatement("SELECT " +
//					"	NVL(MAX(SEQ_NUM),0) " +
//					"FROM " +
//					"	F1_SVC_TASK_CHAR " +
//					"WHERE " +
//					"	F1_SVC_TASK_ID = :serviceTask " +
//					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
//					//"	AND CHAR_TYPE_CD = :charType");
//					"	AND CHAR_TYPE_CD = :charType", getClass().getName());
//					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
//					
//			getMaxCharSequence.bindEntity("serviceTask", serviceTask);
//			getMaxCharSequence.bindEntity("charType", CURRENT_COLL_AGY_CHAR_TYPE.getEntity());
//			
//			SQLResultRow charSequenceRow = getMaxCharSequence.firstRow();
//			BigInteger charSequence = charSequenceRow.getInteger("NVL(MAX(SEQ_NUM),0)");
//			charSequence = charSequence.add(BigInteger.ONE);
//			
//			serviceTask.getCharacteristics().add(currentAgencyCharDto, CURRENT_COLL_AGY_CHAR_TYPE, charSequence);
//			
//			getMaxCharSequence.close();
//						
//		}
		
		/**
		 * Update premise referral placement agency
		 * @param serviceTask
		 * @param premId
		 * @param currentAgency
		 */
		private void updateCurrentAgency(ServiceTask serviceTask, String premId, String currentAgency) {
			BusinessObjectInstance boInstance = BusinessObjectInstance.create(serviceTask.getBusinessObject());
			boInstance.set("serviceTaskId", serviceTask.getId().getTrimmedValue());
			
			boInstance = BusinessObjectDispatcher.read(boInstance);
			COTSInstanceList cotsInstanceList = boInstance.getGroup("premiseReferralPlacements").getList("premiseReferralPlacement");
			
			if (cotsInstanceList.isEmpty()) {
				COTSInstanceListNode newNode = cotsInstanceList.newChild();
				newNode.set("premise", premId);
				newNode.set("collectionAgency", currentAgency);
				createCollectionAgencyPlacementLog(premId, collectionAgencyPlacement);
			} else {
				// find referral placement record with premise ID
				for (COTSInstanceListNode node : cotsInstanceList) {
					Premise prem = node.getEntity("premise", Premise.class);
					if (notNull(prem) && prem.getId().getTrimmedValue().compareTo(premId) == 0) {
						String agencyStr = node.getString("collectionAgency");
						if (agencyStr.compareTo(currentAgency) != 0) {
							node.set("collectionAgency", currentAgency);
							createCollectionAgencyPlacementLog(premId, collectionAgencyPlacement);
						}
						break;
					}
				}
			}
			BusinessObjectDispatcher.update(boInstance);
		}
		/*
		 * End Change - EQuint - 2021-04-05 - SA 363689
		 */
		
		/*
		 * Start Change - EQuint - 2021-04-05 - SA 363689
		 */
//		/**
//		 * This method creates a log to denote the update made to the collection agency placement.
//		 * @param collectionAgencyPlacement
//		 */
//		private void createCollectionAgencyPlacementLog(ServiceTask collectionAgencyPlacement) {
//			
//			MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog> logHelper = 
//				new MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog>(collectionAgencyPlacement.getBusinessObject().getMaintenanceObject(), 
//						collectionAgencyPlacement, collectionAgencyPlacement.getBusinessObject().getId());
//			
//	        logHelper.addLogEntry(LogEntryTypeLookup.constants.SYSTEM, CustomMessageRepositoryMGE.ccb004PlacementUpdated(new CollectionAgency_Id(oldCollAgyCdStr).getEntity(), new CollectionAgency_Id(newCollAgyCdStr).getEntity()), null);
//			
//		}
		
		/**
		 * Create collection agency placement log
		 * @param premId
		 * @param collectionAgencyPlacement
		 */
		private void createCollectionAgencyPlacementLog(String premId, ServiceTask collectionAgencyPlacement) {
			
			MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog> logHelper = 
				new MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog>(collectionAgencyPlacement.getBusinessObject().getMaintenanceObject(), 
						collectionAgencyPlacement, collectionAgencyPlacement.getBusinessObject().getId());
			
	        logHelper.addLogEntry(LogEntryTypeLookup.constants.SYSTEM, CustomMessageRepositoryMGE.ccb004PlacementUpdated(premId, new CollectionAgency_Id(oldCollAgyCdStr).getEntity(), new CollectionAgency_Id(newCollAgyCdStr).getEntity()), null);
			
		}
		/*
		 * End Change - EQuint - 2021-04-05 - SA 363689
		 */
        
        /**
         * This method creates a FK Char log to denote the object created for the Collection Agency Placement.
         * @param collectionAgencyPlacement
         * @param characteristicType
         * @param toDoCase
         */
        private void createCaseCollectionAgencyPlacementLog(ServiceTask collectionAgencyPlacement, CharacteristicType characteristicType, ToDoCase toDoCase) {
            
            MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog> logHelper = 
                new MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog>(collectionAgencyPlacement.getBusinessObject().getMaintenanceObject(), 
                        collectionAgencyPlacement, collectionAgencyPlacement.getBusinessObject().getId());
            
            logHelper.addLogEntry(
                    LogEntryTypeLookup.constants.SYSTEM, 
                    CustomMessageRepositoryMGE.ccb004CaseCreated(), 
                    null,
                    characteristicType,
                    toDoCase);
            
        }
        
        /**
         * This method creates a FK Char log to denote the object created for the Collection Agency Placement.
         * @param collectionAgencyPlacement
         * @param characteristicType
         * @param customerContact
         */
        private void createCustomerContactCollectionAgencyPlacementLog(ServiceTask collectionAgencyPlacement, CharacteristicType characteristicType, CustomerContact customerContact) {
            
            MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog> logHelper = 
                new MaintenanceObjectLogHelper<ServiceTask, ServiceTaskLog>(collectionAgencyPlacement.getBusinessObject().getMaintenanceObject(), 
                        collectionAgencyPlacement, collectionAgencyPlacement.getBusinessObject().getId());
            
            logHelper.addLogEntry(
                    LogEntryTypeLookup.constants.SYSTEM, 
                    CustomMessageRepositoryMGE.ccb004CustomerContactCreated(), 
                    null,
                    characteristicType,
                    customerContact);
            
        }
		
		/**
		 * This method creates a customer contact.
		 * @param customerContactClass
		 * @param customerContactType
         * @return CustomerContact
		 */
		private CustomerContact createCustomerContact(CustomerContactClass customerContactClass, String customerContactType) {
			
			CustomerContact_DTO customerContactDto = new CustomerContact_DTO();
			CustomerContactType_Id customerContactTypeId = new CustomerContactType_Id(customerContactClass, customerContactType);
	
			customerContactDto.setCustomerContactTypeId(customerContactTypeId);
			customerContactDto.setUserId(getActiveContextUser().getId());
			customerContactDto.setBatchControlId(getBatchControlId());
			customerContactDto.setBatchNumber(getBatchNumber());
			customerContactDto.setContactDateTime(getProcessDateTime());
			customerContactDto.setPersonId(getMainAccountPerson(account).getId());
			customerContactDto.setPreferredContactMethod(ContactMethodLookup.constants.NOT_APPLICABLE);
			customerContactDto.setShouldPrintLetter(Bool.FALSE);
			
			return customerContactDto.newEntity();			
		}
		
		/**
		 * This method creates a case.
		 * @param caseType
		 * @return
		 */
		private ToDoCase createCase(CaseType caseType) {
			
			ToDoCase_DTO toDoCaseDto = null;
			ToDoCase toDoCase = null;
					
			toDoCaseDto = (ToDoCase_DTO) createDTO(ToDoCase.class);

			// Get the Initial Status
			PreparedStatement getInitialStatus = createPreparedStatement("SELECT " +
					"	CASE_STATUS_CD " +
					"FROM " +
					"	CI_CASE_STATUS " +
					"WHERE " +
					"	CASE_TYPE_CD = :caseType " +
					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					//"	AND STATUS_COND_FLG IN (:statusCondition)");
					"	AND STATUS_COND_FLG IN (:statusCondition)", getClass().getName());
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			getInitialStatus.bindEntity("caseType", caseType);
			getInitialStatus.bindLookup("statusCondition", StatusConditionLookup.constants.INITIAL);
			
			SQLResultRow statusRow = getInitialStatus.firstRow();
			String initialStatus = statusRow.getString("CASE_STATUS_CD");
			
			getInitialStatus.close();
			
			CaseStatus_Id statusId = new CaseStatus_Id(caseType, initialStatus);
			
			// Set the Case Status
			toDoCaseDto.setCaseStatusId(statusId);
			
			// Set the Account Usage
			if(caseType.getAccountUsage().isRequired()) {
				toDoCaseDto.setAccountId(account.getId());				
			}
			
			// Set the Person Usage
			if(caseType.getPersonUsage().isRequired()) {
				toDoCaseDto.setPersonId(getMainAccountPerson(account).getId());
			}
		
			// Set the Responsible User
			if(caseType.getResponsibleUserUsage().isRequired()) {
				toDoCaseDto.setUserId(getActiveContextUser().getId());				
			}
			
			// Create Characteristics
			ArrayList <CaseCharacteristic_DTO> charDtoList = new ArrayList<CaseCharacteristic_DTO>();
			CaseCharacteristic_DTO caseSourceChar = createCaseCharacteristic(parmCreditCollCaseSourceCharType, parmCreditCollCaseSourceCharVal);
			charDtoList.add(caseSourceChar);
			
			// Add the following characteristics if the action is Bankrupt:
			if(action.equalsIgnoreCase(ACTION_BNK)) {
				// Bankrupt Case Claim Number
				CaseCharacteristic_DTO claimNumberChar = createCaseCharacteristic(parmBankruptCaseClaimNbrCharType, bkrptClaimNbrStr);
				charDtoList.add(claimNumberChar);
				
				// Bankrupt Petition Date
				CaseCharacteristic_DTO petitionDateChar = createCaseCharacteristic(parmBankruptCasePetDtCharType, bkrptPetDateStr);
				charDtoList.add(petitionDateChar);
				
				// Bankrupt Petition Number
				CaseCharacteristic_DTO petitionNumberChar = createCaseCharacteristic(parmBankruptCasePetNbrCharType, bkrptPetNbrStr);
				charDtoList.add(petitionNumberChar);				
			}
			
			CaseCreatorData caseCreatorData = CaseCreatorData.Factory.newInstance();
			caseCreatorData.setToDoCaseDTO(toDoCaseDto);
			caseCreatorData.setCaseCharacteristics(charDtoList);
			
			CaseCreator caseCreator = CaseCreator.Factory.newInstance();
			CaseCreatorData newCaseCreatorData = caseCreator.createCase(caseCreatorData);
			toDoCase = newCaseCreatorData.getCaseId().getEntity();
			
			return toDoCase;			
		}
		
		/**
		 * This method creates a case characteristic.
		 * @param charType
		 * @param charVal
		 * @return
		 */
		private CaseCharacteristic_DTO createCaseCharacteristic(CharacteristicType charType, String charVal) {
			
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			
			CaseCharacteristic_DTO caseCharDto;
			CaseCharacteristic_Id caseCharId = new CaseCharacteristic_Id(charType.getId(), ToDoCase_Id.NULL, BigInteger.ONE);
			caseCharDto = caseCharId.newDTO();
			
			if(charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
				caseCharDto.setAdhocCharacteristicValue(charVal);
			} else if(charTypeLookup.isPredefinedValue()) {
				caseCharDto.setCharacteristicValue(charVal);
			} else if(charTypeLookup.isForeignKeyValue()) {
				caseCharDto.setCharacteristicValueForeignKey1(charVal);
			}
			
			return caseCharDto;
		}
		
		/**
		 * This method creates a to do entry.
		 * @param toDoType
		 * @param toDoCase
		 */
		private void createToDo(ToDoType toDoType, ToDoCase toDoCase) {
			
			ToDoEntry toDoEntry = null;
			
			ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
			ToDoEntry_DTO toDoEntryDto = toDoCreator.getToDoDTO();
			
			toDoEntryDto.setCreationDateTime(getProcessDateTime());
			toDoEntryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
			toDoEntryDto.setToDoTypeId(toDoType.getId());
			
			toDoEntryDto.setBatchControlId(getBatchControlId());
			toDoEntryDto.setBatchNumber(getBatchNumber());
			
			toDoCreator.setToDoDTO(toDoEntryDto);
			
			// Create the Sort Keys
			if(notNull(toDoType.getSortKeyTypes()) && !toDoType.getSortKeyTypes().isEmpty()) {
				Iterator sortKeyTypeIter = toDoType.getSortKeyTypes().iterator();
				while(sortKeyTypeIter.hasNext()) {
					
					
					ToDoSortKeyType sortKeyType = (ToDoSortKeyType) sortKeyTypeIter.next();
					
					// Sort Key #1 - Account Name
					if(sortKeyType.fetchIdSequence().equals(BigInteger.valueOf(1))) {
						toDoCreator.addSortKeyValue(sortKeyType, getMainAccountPerson(account).getPersonPrimaryName().trim());
					}
					
					// Sort Key #2 - Account ID
					if(sortKeyType.fetchIdSequence().equals(BigInteger.valueOf(2))) {
						toDoCreator.addSortKeyValue(sortKeyType, accountIdStr);
					}
				}
				
			}
			
			// Create the Drill Keys
			if(notNull(toDoType.getDrillKeyTypes()) && !toDoType.getDrillKeyTypes().isEmpty()) {
				Iterator drillKeyTypeIter = toDoType.getDrillKeyTypes().iterator();
				while (drillKeyTypeIter.hasNext()) {
					ToDoDrillKeyType drillKeyType = (ToDoDrillKeyType) drillKeyTypeIter.next();
					
					// Case ID
					if(drillKeyType.getField().getId().getTrimmedValue().equalsIgnoreCase(DRILL_KEY_CASE)) {
						toDoCreator.addDrillKeyValue(drillKeyType, toDoCase.getId().getTrimmedValue());
					}
				}
			}
			
			// Message
			toDoCreator.addMessageParameter(accountIdStr);
			toDoCreator.addMessageParameter(collAgyRefIdStr);
			
			// History
			toDoCreator.addTransactionHistory(LogTypeLookup.constants.CREATED, null, null);
			// Start Add - GCrisp - Defect 4596386 - 2021-09-22
			// Create To Do Characteristic (Account) if Case does not have an Account
			if(isNull(toDoCase.getAccountId())){
				toDoCreator.addForeignKeyCharacteristic(parmAccountCharType, account);
			}
			// End Add - GCrisp - Defect 4596386 - 2021-09-22
			// Create the To Do Entry
			toDoEntry = toDoCreator.create();
			
			// Create To Do Characteristics
			// Account
			createToDoCharacteristic(toDoEntry, parmAccountCharType, account.getId().getTrimmedValue());
			// Person
			createToDoCharacteristic(toDoEntry, parmPersonCharType, getMainAccountPerson(account).getId().getTrimmedValue());
			// Case
			createToDoCharacteristic(toDoEntry, parmCaseCharType, toDoCase.getId().getTrimmedValue());
		
		}
		
		/**
		 * This method creates a to do characteristic.
		 * @param toDoEntry
		 * @param charType
		 * @param charValue
		 */
		private void createToDoCharacteristic(ToDoEntry toDoEntry, CharacteristicType charType, String charValue) {
			// Add Characteristic only if it does not yet exists
			ToDoEntryCharacteristic_Id tdEntryCharID = new ToDoEntryCharacteristic_Id(toDoEntry, charType, BigInteger.ONE);
			if (isNull(tdEntryCharID.getEntity())) {
				ToDoEntryCharacteristics toDoEntryChars = toDoEntry.getCharacteristics();
				ToDoEntryCharacteristic_DTO toDoEntryCharDto = toDoEntryChars.newChildDTO();
				
				if(charType.getCharacteristicType().isAdhocValue() || charType.getCharacteristicType().isFileLocationValue()) {
					toDoEntryCharDto.setAdhocCharacteristicValue(charValue);
				} else if(charType.getCharacteristicType().isForeignKeyValue()) {
					toDoEntryCharDto.setCharacteristicValueForeignKey1(charValue);	
				} else if(charType.getCharacteristicType().isPredefinedValue()) {
					toDoEntryCharDto.setCharacteristicValue(charValue);
				}
				
				toDoEntryChars.add(toDoEntryCharDto, charType.getId(), BigInteger.ONE);
			}
			// Update the characteristic value
			else {
				ToDoEntryCharacteristic tdEntryChar = tdEntryCharID.getEntity();
				ToDoEntryCharacteristic_DTO toDoEntryCharDto = tdEntryChar.getDTO();
				if(charType.getCharacteristicType().isAdhocValue() || charType.getCharacteristicType().isFileLocationValue()) {
					toDoEntryCharDto.setAdhocCharacteristicValue(charValue);
				} else if(charType.getCharacteristicType().isForeignKeyValue()) {
					toDoEntryCharDto.setCharacteristicValueForeignKey1(charValue);	
				} else if(charType.getCharacteristicType().isPredefinedValue()) {
					toDoEntryCharDto.setCharacteristicValue(charValue);
				}
				tdEntryChar.setDTO(toDoEntryCharDto);
			}
		}
		
		/**
		 * This method retrieves the main person of an account.
		 * @param account
		 * @return Person
		 */
		private Person getMainAccountPerson(Account account) {
			
			Person person;
			
			PreparedStatement getPerson = createPreparedStatement("SELECT " +
					"	PER_ID " +
					"FROM " +
					"	CI_ACCT_PER " +
					"WHERE" +
					"	ACCT_ID = :account " +
					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					//"	AND MAIN_CUST_SW = :isMainCustomer");
					"	AND MAIN_CUST_SW = :isMainCustomer", getClass().getName());
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			
			getPerson.bindEntity("account", account);
			getPerson.bindBoolean("isMainCustomer", Bool.TRUE);
					
			SQLResultRow resultRow = getPerson.firstRow();
			person = resultRow.getEntity("PER_ID", Person.class);
			
			getPerson.close();
			
			return person;
		}
		
		//Start Add 5/26/2017 - JTiozon - Defect 193290
		/**
		 * This method retrieves the Main Person that
		 * is Financially Responsible
		 * @return Person
		 */
		private Person getFinanciallyResponsiblePerson(){			
			
			String sql = "SELECT " +
						 "	PER_ID " +
						 "FROM " +
						 "	CI_ACCT_PER " +
						 "WHERE " +
						 "	ACCT_ID = :account " +
						 "AND MAIN_CUST_SW = :isMainCust " +
						 "AND FIN_RESP_SW = :isFinResp";
			
			PreparedStatement prepStmt = createPreparedStatement(sql, getClass().getName());
			prepStmt.bindEntity("account", account);
			prepStmt.bindBoolean("isMainCust", Bool.TRUE);
			prepStmt.bindBoolean("isFinResp", Bool.TRUE);
			
			SQLResultRow resultRow = prepStmt.firstRow();
			Person person = resultRow.getEntity("PER_ID", Person.class);
			
			prepStmt.close();
			
			return person;
			
		}
		
		/**
		 * This method check if Person is linked to Multiple Account
		 * @param person
		 * @return Accounts
		 */
		private List<SQLResultRow> checkPersonLinkedToMultiAccount(Person person){
			
			String sql = "SELECT " +
						 "	ACCT_ID " +
						 "FROM " +
						 "	CI_ACCT_PER " +
						 "WHERE " +
						 "	PER_ID = :person";
			
			PreparedStatement prepStmt = createPreparedStatement(sql, getClass().getName());
			prepStmt.bindEntity("person", person);
			
			List<SQLResultRow> resultRow = prepStmt.list();
			
			prepStmt.close();
			
			return resultRow;
		}
		/**
		 * This method returns account's Service Agreement(s)
		 * @return Service Agreements
		 */
		private List<SQLResultRow> retrieveAccountSAs(){
			
			String sql = "SELECT " +
						 "	SA_ID " +
						 "FROM " +
						 "	CI_SA " +
						 "WHERE " +
						 "	ACCT_ID = :account " +
						 "AND SA_STATUS_FLG IN (:pendingStart,:active,:pendingStop,:stopped,:reactivated)";
			
			PreparedStatement prepStmt = createPreparedStatement(sql, getClass().getName());
			prepStmt.bindEntity("account", account);
			prepStmt.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
			prepStmt.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
			prepStmt.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
			prepStmt.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
			prepStmt.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
			
			List<SQLResultRow> resultRow = prepStmt.list();
			
			prepStmt.close();
			
			return resultRow;
			
		}
		
		/**
		 * This method return list of SA by Debt Class
		 * @return Service Agreements
		 */
		private List<SQLResultRow> retrieveAccountSaByDebtClass(){
			String bindStr = null;
			for(int i=0;i<debtClassList.size();i++){
				if(isNull(bindStr)){
					bindStr = ":debtClass" + i;
				}else{
					bindStr += ", :debtClass" +i;
				}
			}
			
			String sql = "SELECT" +
						 "	SA.SA_ID, " +
						 "	ST.DEBT_CL_CD " +
						 "FROM " +
						 "	CI_SA SA, " +
						 "	CI_SA_TYPE ST " +
						 "WHERE " +
						 "	SA.ACCT_ID = :account " +
						 "AND SA.CIS_DIVISION = ST.CIS_DIVISION " +
						 "AND SA.SA_TYPE_CD = ST.SA_TYPE_CD " +
						 "AND ST.DEBT_CL_CD IN ( "+bindStr+ ") " +
						 "AND SA.SA_STATUS_FLG NOT IN (:closed,:cancelled)";
			
			PreparedStatement prepStmt = createPreparedStatement(sql, getClass().getName());
			prepStmt.bindEntity("account", account);
			prepStmt.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
			prepStmt.bindLookup("cancelled", ServiceAgreementStatusLookup.constants.CANCELED);
			for(int i=0;i<debtClassList.size();i++){
				prepStmt.bindId("debtClass"+i,  new DebtClass_Id(debtClassList.get(i)));				
			}
			
			List<SQLResultRow> resultRow = prepStmt.list();
			
			prepStmt.close();

			return resultRow;
		}	
		/**
		 * This method create a Deceased SA
		 * @return Service Agreement
		 */
		private ServiceAgreement createDeceasedSA(){			
			
			ServiceAgreement serviceAgreement = null;
			
			//Create Deceased SA
			ServiceAgreementType_Id saTypeId = new ServiceAgreementType_Id(account.fetchDivision(), deceasedSaType);
			//Validate Deceased SA Type batch parameter is valid for Account's CIS Division.
			if(isNull(saTypeId.getEntity())){
				addError(CustomMessageRepositoryMGE.ccb004invalidSaType(PARM_170_DESCR, deceasedSaType, account.fetchDivision().getId().getIdValue()));
			}
			
			ServiceAgreementCreator saCreator = ServiceAgreementCreator.Factory.newInstance();
			ServiceAgreement_DTO saDto = (ServiceAgreement_DTO) createDTO(ServiceAgreement.class);
			ServiceAgreementCreatorData saCreatorData = ServiceAgreementCreatorData.Factory.newInstance();
				
			saDto.setServiceAgreementTypeId(saTypeId);
			saDto.setStatus(ServiceAgreementStatusLookup.constants.PENDING_START);
			saDto.setAccountId(account.getId());
			saDto.setStartDate(getProcessDateTime().getDate());
			saDto.setAreEstimatesAllowed(Bool.FALSE);
			saDto.setCustomerRead(CustomerReadLookup.constants.NO);
			saDto.setStartReason(StartReasonLookup.constants.SYSTEM_GENERATED);
			saCreatorData.setShouldCreateFieldActivity(Bool.FALSE);								
				
			serviceAgreement = saCreator.addServiceAgreement(saDto, saCreatorData);	
			return serviceAgreement;
		}		
		//End Add 5/26/2017 - JTiozon - Defect 193290
	
	}

}
