/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Hyperion Extract Batch per CIS Division.
 * 
 * This batch program extracts the Revenue Model (CM_REVENUE_MODEL) records 
 * for a given CIS Division and write those data into an output file.
 * 
 * The CIS Division is taken from the given Hyperion Configuration Service  
 * Task Type batch parameter.
 * 
 * This can be run either Daily or Monthly:
 * - For a Daily run, extract only records with a Transfer to GL Date equal 
 *   to the batch processing date.
 * - For a Monthly run, extract all records with a Transfer to GL Date that 
 *   falls within the batch processing date's month.
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2015-02-28   WCARAN     MGE-CCB020. Initial version.
 *              BMARQUEZ
 * 2015-06-15   BMARQUEZ   SF-3233711. Corrected Service Task Type
 *                         initialization.
 * 2015-08-26	SMiran	   Defect 3275998. Count distinct SA only when
 * 						   total SA count is greater than zero to reduce
 * 						   SQL call. 
 * 2015-10-15   SMiran     SF-59496. Exclude redundant FTs from customer
 * 						   count.
 * 2015-11-25   SMiran     SF-69280. Exclude MGE Industrial - Heating Cl 3
 * 						   from Monthly/Daily customer count.
 * 2016-04-25	JHerna	   IM-107918. Update the SQL for Customer Count.   
 * 2016-01-29  	MPang	   Updated for CCB v2.4 compilation.   
 * 2018-04-16	JHERNA	   SysAid#250378. Update Monthly Customer Count.
 * 2021-08-03	GCrisp	   CCB040.Issue3. Add new Accounting Period column
 *                         in the extract. Extract separate files per 
 *                         Accounting Period, for same xfer_to_gl_dt.
 * 2021-09-01  	GCrisp	   Defect 4588292. Extract file name updates.
 * 2022-07-08   JHERNA     B-20848 / SysAid#386111. Always set the customer 
 *                         count (saCount) to zero for LGC Marketers.
 * 2023-03-23   CAtilano   B-26423-Customer Count differences with OBIEE. Changed
 * 						   filer from xfer to GL date to accounting to match OBIEE
 *************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSFieldDataAndMD;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.MonthInYear;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure;*/
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.api.batch.CmHyperionExtractPerCisDivisionRecord;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;


/**
 *
 @BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = DAILY_OR_MONTHLY_SW, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = SERVICE_TASK_TYPE, required = true, type = entity)})
 */

public class CmHyperionExtractPerCisDivisionBatch 
        extends CmHyperionExtractPerCisDivisionBatch_Gen {
    // Constants
    /** CM-RevenueExtractConfiguration */
    private static final BusinessObject_Id REVENUE_EXTRACT_CONFIG_BO = new BusinessObject_Id("CM-RevenueExtractConfiguration");
    /** D */
    private static final String DAILY_RUN = "D";
    /** M */
    private static final String MONTHLY_RUN = "M";
    /** CM_REV_RATE_CLASS */
    private static final String FIELD_CM_REV_RATE_CLASS = "CM_REV_RATE_CLASS";
    
    @Override
    public void validateSoftParameters(boolean isJobWorkNeeded) {
        
        // File Path must be a valid directory.
        String filePath = getParameters().getFILE_PATH().trim();

        File folder = new File(filePath);
        if (!folder.isDirectory()) {
            addError(CustomMessageRepositoryMGE.commBatchParameterIsNotValidFilePath("FILE_PATH", filePath));
        }

        // Daily Or Monthly Switch must be D or M
        String isDailyRunValue = getParameters().getDAILY_OR_MONTHLY_SW().trim();
        if (!isDailyRunValue.equalsIgnoreCase(DAILY_RUN) && 
                !isDailyRunValue.equalsIgnoreCase(MONTHLY_RUN)) {
            addError(CustomMessageRepositoryMGE.ccb020HypInvalidBatchParameterDailyOrMonthlySwitch());
        }
        
        // Service Task Type must represent a Revenue Extract Configuration
        ServiceTaskType serviceTaskType = getParameters().getSERVICE_TASK_TYPE();
        if (!serviceTaskType.getBusinessObject().getId().equals(REVENUE_EXTRACT_CONFIG_BO)) {
            addError(CustomMessageRepositoryMGE.ccb020HypInvalidServiceTaskTypeBusinessObject(serviceTaskType, REVENUE_EXTRACT_CONFIG_BO));
        }
        
        // Service Task Type must be Active
        if (!serviceTaskType.getServiceTaskTypeStatus().isActive()) {
            addError(CustomMessageRepositoryMGE.ccb020HypInactiveServiceTaskType(serviceTaskType));
        }
            
        super.validateSoftParameters(isJobWorkNeeded);
        
    }   
    
    public JobWork getJobWork() {
        
        // Create Job Work with dummy work unit
        List<ThreadWorkUnit> threadWorkUnitList = new ArrayList<ThreadWorkUnit>();
        threadWorkUnitList.add(new ThreadWorkUnit());
        return createJobWorkForThreadWorkUnitList(threadWorkUnitList);
        
    }

    public Class<CmHyperionExtractPerCisDivisionBatchWorker> getThreadWorkerClass() {
        return CmHyperionExtractPerCisDivisionBatchWorker.class;
    }

    public static class CmHyperionExtractPerCisDivisionBatchWorker
            extends CmHyperionExtractPerCisDivisionBatchWorker_Gen {
        
        // Soft Parameters
        private boolean isDailyRun;
        private ServiceTaskType serviceTaskType;
        private int numberOfOutputColumns;
        private CisDivision cisDivision;
        private File outputFile;
        private BufferedWriter bufferedWriter;
        
        private List<ExtractColumn> generalExtractColumnList = new ArrayList<ExtractColumn>();
        private List<ExtractColumn> usageExtractColumnList = new ArrayList<ExtractColumn>();
        private List<ExtractColumn> revenueExtractColumnList = new ArrayList<ExtractColumn>();
        
        /**
         * ExtractColumn stores information regarding the CM_REVENUE_MODEL table. These values
         * are read from the Business Object and many of them are not UI-configurable. They are
         * pre-populated via Service Script CM-RvxBoPre.<br/>
         * <br/>
         * Types of Extract Column:
         * <ol>
         *  <li>
         *      General - These fields identify the source of the row information such as Revenue
         *      Rate Class and FERC Number. Values for these fields are inserted directly.
         *  </li>
         *  <li>
         *      Usage - These fields are assigned a Usage Type via Service Script CM-RvxBoPre. Its
         *      contents are resolved dynamically as the total of the Calc Lines referencing this
         *      Usage Type.
         *  </li>
         *  <li>
         *      Revenue - These fields are assigned a Revenue Type via Service Script CM-RvxBoPre. 
         *      Its contents are resolved dynamically as the total of the Calc Lines referencing 
         *      this Revenue Type.
         *  </li>
         * </ol>
         */
        private class ExtractColumn {
            
            private BigInteger sequence;
            private String fieldName;
            private String description;
            
            public ExtractColumn() {}
            
            public ExtractColumn(BigInteger sequence, String fieldName, String description) {
                this.sequence = sequence; 
                this.description = description;
                this.fieldName = fieldName;
            }
            
            public BigInteger getSequence() {
                return sequence;
            }
            
            public String getFieldName() {
                return fieldName;
            }
            
            public String getDescription() {
                return description;
            }
            
            public void setSequence(BigInteger sequence) {
                this.sequence = sequence;
            }
            
            public void setFieldName(String fieldName) {
                this.fieldName = fieldName;
            }
            
            public void setDescription(String description) {
                this.description = description;
            }
            
        }
        
        // Soft Parameters for monthly runs
        private CharacteristicType saRateClassCharacteristicType;
        private CharacteristicType transportSalesCharacteristicType;
        private CharacteristicType usageTypeCharacteristicType;
        private CharacteristicType revenueTypeCharacteristicType;
        private HashMap<String, RevenueRateClass> revenueRateClassMap;

        /**
         * RevenueRateClass stores the Revenue Rate Classes configured on the Revenue Extract 
         * Service Task Type. These values are read from the Business Object.
         */
        private class RevenueRateClass {
            
            private String revenueRateClass;
            private String revenueClassType;
            private List<SaTypeRevenueRate> saTypeRevenueRateClassifications = new ArrayList<SaTypeRevenueRate>();
            
            // This could be an enum, but following the Revenue Model Extract batch
            /** GENERAL */
            public static final String REVENUE_CLASS_TYPE_GENERAL = "GENERAL";
            /** TRANSPORTATION */
            public static final String REVENUE_CLASS_TYPE_TRANSPORTATION = "TRANSPORTATION";
            /** TRANSPORTATION_SALES */
            public static final String REVENUE_CLASS_TYPE_TRANSPORTATION_SALES = "TRANSPORTATION_SALES"; 
            
            public RevenueRateClass() {}
            
            public RevenueRateClass(String revenueRateClass, String revenueClassType) {
                this.revenueRateClass = revenueRateClass;
                this.revenueClassType = revenueClassType;
            }

            public String getRevenueClassType() {
                return revenueClassType;
            }

            public void setRevenueClassType(String revenueClassType) {
                this.revenueClassType = revenueClassType;
            }

            public String getRevenueRateClass() {
                return revenueRateClass;
            }

            public void setRevenueRateClass(String revenueRateClass) {
                this.revenueRateClass = revenueRateClass;
            }
            
            public boolean isGeneralRevenueClassType() {
                return REVENUE_CLASS_TYPE_GENERAL.equals(this.revenueClassType);
            }
            
            public boolean isTransportationRevenueClassType() {
                return REVENUE_CLASS_TYPE_TRANSPORTATION.equals(this.revenueClassType);
            }
            
            public boolean isTransportationSalesRevenueClassType() {
                return REVENUE_CLASS_TYPE_TRANSPORTATION_SALES.equals(this.revenueClassType);
            }
            
            public void addSaTypeRevenueRateClassifications(SaTypeRevenueRate saTypeRevenueRate) {
                saTypeRevenueRateClassifications.add(saTypeRevenueRate);
            }
            
            public List<SaTypeRevenueRate> getSaTypeRevenueRateClassifications() {
                return saTypeRevenueRateClassifications;
            }
            
        }
        
        /**
         * SA Type Revenue Rate stores the unique SA Type/Rate Class combination when the
         * Service Agreement Type is classified for a particular Revenue Rate Class.
         */
        private class SaTypeRevenueRate {
            
            private String saType;
            private String saRateClass;
            
            public SaTypeRevenueRate() {}
            
            public SaTypeRevenueRate(String saType, String saRateClass) {
                this.saType = saType;
                this.saRateClass = saRateClass;
            }

            public String getSaRateClass() {
                return saRateClass;
            }

            public void setSaRateClass(String saRateClass) {
                this.saRateClass = saRateClass;
            }

            public String getSaType() {
                return saType;
            }

            public void setSaType(String saType) {
                this.saType = saType;
            }
            
        }

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new SingleTransactionStrategy(this);
        }

        @Override
        public void initializeThreadWork(boolean initializationPreviouslySuccessful) 
                throws ThreadAbortedException, RunAbortedException {
        
            // Compare to "D"
            isDailyRun = DAILY_RUN.equals(getParameters().getDAILY_OR_MONTHLY_SW());
            
            // The Service Task Type parameter provides the extract column definition for the Batch 
            serviceTaskType = getParameters().getSERVICE_TASK_TYPE();       

            BusinessObjectInstance businessObjectInstance = BusinessObjectInstance.create(serviceTaskType.getBusinessObject());
            businessObjectInstance.set("serviceTaskType", serviceTaskType.getId().getTrimmedValue());
            businessObjectInstance = BusinessObjectDispatcher.read(businessObjectInstance);

            COTSInstanceNode extractDetails = businessObjectInstance.getGroup("extractDetails");       
            
            cisDivision = extractDetails.getEntity("cisDivision", CisDivision.class);
            
            if (isNull(cisDivision)) {
                addError(CustomMessageRepositoryMGE.ccb004MissingCisDivision2(serviceTaskType));
            }
            
            // Retrieve and set Extract Column Definitions
            COTSInstanceList extractColumnDefinitionList = extractDetails.getGroup("extractColumnList").getList("extractColumn");
            Iterator<COTSInstanceListNode> extractColumnDefinitionListIterator = extractColumnDefinitionList.iterator();
            
            while (extractColumnDefinitionListIterator.hasNext()) {
                
                COTSInstanceListNode cotsInstanceListNode = extractColumnDefinitionListIterator.next();

                // CM_REV_RATE_CLASS from the General Extract Column list will not be extracted
                if (FIELD_CM_REV_RATE_CLASS.equals(cotsInstanceListNode.getString("field").trim())) {
                    continue;
                }
                
                ExtractColumn extractColumn = new ExtractColumn();
                extractColumn.setSequence(cotsInstanceListNode.getNumber("sequence").toBigInteger());
                extractColumn.setFieldName(cotsInstanceListNode.getString("field"));
                extractColumn.setDescription(cotsInstanceListNode.getString("description"));
                
                String usageType = cotsInstanceListNode.getString("usageType");
                if (notBlank(usageType)) {
                    usageExtractColumnList.add(extractColumn);
                }
                
                String revenueType = cotsInstanceListNode.getString("revenueType");
                if (notBlank(revenueType)) {
                    revenueExtractColumnList.add(extractColumn);
                }
                
                if (isBlankOrNull(usageType) && isBlankOrNull(revenueType)) {
                    generalExtractColumnList.add(extractColumn);
                }
                
            }
            // Start Delete - GCrisp - 2021-08-19 - CCB040.Issue3
            // Create output file
            //outputFile = new File(getParameters().getFILE_PATH(), getParameters().getFILE_NAME());
            //try {
            //    
            //    bufferedWriter = new BufferedWriter(new FileWriter(outputFile));
            //    
            //} catch (IOException e) {
            //    addError(CustomMessageRepositoryMGE.commGenericErrorOpeningFile(outputFile.getAbsolutePath()));
            //}
            //
            //// Write header to file
            //List<ExtractColumn> list = new ArrayList<ExtractColumn>();
            //list.addAll(generalExtractColumnList);
            //list.addAll(usageExtractColumnList);
            //list.addAll(revenueExtractColumnList);
			//
            //numberOfOutputColumns = generalExtractColumnList.size() + usageExtractColumnList.size() + revenueExtractColumnList.size();
            //CmHyperionExtractPerCisDivisionRecord header = new CmHyperionExtractPerCisDivisionRecord(numberOfOutputColumns);
            //
            //int i = 0;
            //for (ExtractColumn extractColumn : list) {
            //    i += 1;
            //    header.setHeaderColumn(i, extractColumn.getDescription()); 
            //}
            //
            //try {
            //    
            //    bufferedWriter.write(header.createRecordString());
            //    
            //} catch (IOException e) {
            //    addError(CustomMessageRepositoryMGE.commGenericErrorWritingToFile(outputFile.getAbsolutePath()));
            //}            
            // End Delete - GCrisp - 2021-08-19 - CCB040.Issue3
            // For a Monthly Run, extract the Revenue Rate Class information from the Service Task Type
            if (!isDailyRun) {
                
                saRateClassCharacteristicType = extractDetails.getEntity("saRateClassCharacteristicType", CharacteristicType.class);
                transportSalesCharacteristicType = extractDetails.getEntity("transportSalesCharacteristicType", CharacteristicType.class);
                usageTypeCharacteristicType = extractDetails.getEntity("usageTypeCharacteristicType", CharacteristicType.class);
                revenueTypeCharacteristicType = extractDetails.getEntity("revenueTypeCharacteristicType", CharacteristicType.class);
                
                revenueRateClassMap = new HashMap<String, RevenueRateClass>();
                
                // Retrieve the entries on the Revenue Rate Class List
                COTSInstanceList revenueRateClassList = businessObjectInstance.getGroup("extractDetails").getGroup("revenueRateClassList").getList("revenueRateClass");          
                Iterator<COTSInstanceListNode> revenueRateClassListIterator = revenueRateClassList.iterator();
                while (revenueRateClassListIterator.hasNext()) {
                    
                    COTSInstanceListNode cotsInstanceListNode = revenueRateClassListIterator.next();
                    String revenueRateClassCode = cotsInstanceListNode.getString("revenueRateClass").trim();

                    RevenueRateClass revenueRateClass = new RevenueRateClass();
                    revenueRateClass.setRevenueRateClass(revenueRateClassCode);
                    revenueRateClass.setRevenueClassType(RevenueRateClass.REVENUE_CLASS_TYPE_GENERAL);
                    revenueRateClassMap.put(revenueRateClassCode, revenueRateClass);
                    
                }
                
                // Retrieve the entries on the Transportation Revenue Rate Class List
                COTSInstanceList transportationRevenueRateClassList = businessObjectInstance.getGroup("extractDetails").getGroup("transportationRevenueRateClassList").getList("transportationRevenueRateClass");
                Iterator<COTSInstanceListNode> transportationRevenueRateClassListIterator = transportationRevenueRateClassList.iterator();
                while (transportationRevenueRateClassListIterator.hasNext()) {
                    
                    COTSInstanceListNode cotsInstanceListNode = transportationRevenueRateClassListIterator.next();
                    
                    String transportationRevenueRateClassCode = cotsInstanceListNode.getGroup("transportation").getString("revenueRateClass").trim();
                    RevenueRateClass transportationRevenueRateClass = new RevenueRateClass();
                    transportationRevenueRateClass.setRevenueRateClass(transportationRevenueRateClassCode);
                    transportationRevenueRateClass.setRevenueClassType(RevenueRateClass.REVENUE_CLASS_TYPE_TRANSPORTATION);
                    revenueRateClassMap.put(transportationRevenueRateClassCode, transportationRevenueRateClass);
                    
                    String transportationSalesRevenueRateClassCode = cotsInstanceListNode.getGroup("sales").getString("revenueRateClass").trim();
                    RevenueRateClass transportationSalesRevenueRateClass = new RevenueRateClass();
                    transportationSalesRevenueRateClass.setRevenueRateClass(transportationSalesRevenueRateClassCode);
                    transportationSalesRevenueRateClass.setRevenueClassType(RevenueRateClass.REVENUE_CLASS_TYPE_TRANSPORTATION_SALES);
                    revenueRateClassMap.put(transportationSalesRevenueRateClassCode, transportationSalesRevenueRateClass);
                    
                }
                
                /*
                 * Start Add - Defect 3233711 - 2015-06-15
                 */
                // Retrieve and set SA Type Classifications
                COTSInstanceList saTypeRevenueRateClassificationList = extractDetails.getGroup("saTypeRateClassList").getList("saTypeRateClass");
                Iterator<COTSInstanceListNode> saTypeRevenueRateClassificationListIterator = saTypeRevenueRateClassificationList.iterator();
                
                while (saTypeRevenueRateClassificationListIterator.hasNext()) {
                    
                    COTSInstanceListNode cotsInstanceListNode = saTypeRevenueRateClassificationListIterator.next();
                    SaTypeRevenueRate saTypeRevenueRate = new SaTypeRevenueRate();
                    saTypeRevenueRate.setSaType(cotsInstanceListNode.getString("saType"));
                    saTypeRevenueRate.setSaRateClass(cotsInstanceListNode.getString("saRateClass"));
                    
                    // Add to list of Revenue Rate Class' SA Types
                    revenueRateClassMap.get(cotsInstanceListNode.getString("revenueRateClass")).addSaTypeRevenueRateClassifications(saTypeRevenueRate);
                    
                }
                
                // Retrieve and set Transportation and Transportation Sales SA Type Classifications
                COTSInstanceList saTypeTransportationRevenueRateClassificationList = extractDetails.getGroup("saTypeTransportationRateClassList").getList("saTypeTransportationRateClass");
                Iterator<COTSInstanceListNode> saTypeRevenueRateTransportationClassificationListIterator = saTypeTransportationRevenueRateClassificationList.iterator();
                
                while (saTypeRevenueRateTransportationClassificationListIterator.hasNext()) {
                    
                    COTSInstanceListNode cotsInstanceListNode = saTypeRevenueRateTransportationClassificationListIterator.next();
                    SaTypeRevenueRate saTypeRevenueRate = new SaTypeRevenueRate();
                    saTypeRevenueRate.setSaType(cotsInstanceListNode.getString("saType"));
                    saTypeRevenueRate.setSaRateClass(cotsInstanceListNode.getString("saRateClass"));
                    
                    // Add to list of Transportation Revenue Rate Class' SA Types
                    String revenueRateClass = cotsInstanceListNode.getString("revenueRateClass");
                    revenueRateClassMap.get(revenueRateClass).addSaTypeRevenueRateClassifications(saTypeRevenueRate);
                    
                    // Find Transportation Sales Revenue Rate Class
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("transportationRevenueRateClass[transportation/revenueRateClass='");
                    stringBuilder.append(revenueRateClass);
                    stringBuilder.append("']/sales/revenueRateClass");
                    COTSFieldDataAndMD cotsFieldDataAndMd = extractDetails.getGroup("transportationRevenueRateClassList").getFieldAndMDForPath(stringBuilder.toString());
                    
                    // Add to list of Transportation Revenue Rate Class' SA Types
                    revenueRateClass = cotsFieldDataAndMd.getValue().toString();
                    revenueRateClassMap.get(revenueRateClass).addSaTypeRevenueRateClassifications(saTypeRevenueRate);
                    
                }
                /*
                 * End Add - Defect 3233711 - 2015-06-15
                 */
            }

            /*
             * Start Delete - Defect 3233711 - 2015-06-15
             */
            //// Retrieve and set SA Type Classifications
            //COTSInstanceList saTypeRevenueRateClassificationList = extractDetails.getGroup("saTypeRateClassList").getList("saTypeRateClass");
            //Iterator<COTSInstanceListNode> saTypeRevenueRateClassificationListIterator = saTypeRevenueRateClassificationList.iterator();
            //
            //while (saTypeRevenueRateClassificationListIterator.hasNext()) {
            //    
            //    COTSInstanceListNode cotsInstanceListNode = saTypeRevenueRateClassificationListIterator.next();
            //    SaTypeRevenueRate saTypeRevenueRate = new SaTypeRevenueRate();
            //    saTypeRevenueRate.setSaType(cotsInstanceListNode.getString("saType"));
            //    saTypeRevenueRate.setSaRateClass(cotsInstanceListNode.getString("saRateClass"));
            //    
            //    // Add to list of Revenue Rate Class' SA Types
            //    revenueRateClassMap.get(cotsInstanceListNode.getString("revenueRateClass")).addSaTypeRevenueRateClassifications(saTypeRevenueRate);
            //    
            //}
            //
            //// Retrieve and set Transportation and Transportation Sales SA Type Classifications
            //COTSInstanceList saTypeTransportationRevenueRateClassificationList = extractDetails.getGroup("saTypeTransportationRateClassList").getList("saTypeTransportationRateClass");
            //Iterator<COTSInstanceListNode> saTypeRevenueRateTransportationClassificationListIterator = saTypeTransportationRevenueRateClassificationList.iterator();
            //
            //while (saTypeRevenueRateTransportationClassificationListIterator.hasNext()) {
            //    
            //    COTSInstanceListNode cotsInstanceListNode = saTypeRevenueRateTransportationClassificationListIterator.next();
            //    SaTypeRevenueRate saTypeRevenueRate = new SaTypeRevenueRate();
            //    saTypeRevenueRate.setSaType(cotsInstanceListNode.getString("saType"));
            //    saTypeRevenueRate.setSaRateClass(cotsInstanceListNode.getString("saRateClass"));
            //    
            //    // Add to list of Transportation Revenue Rate Class' SA Types
            //    String revenueRateClass = cotsInstanceListNode.getString("revenueRateClass");
            //    revenueRateClassMap.get(revenueRateClass).addSaTypeRevenueRateClassifications(saTypeRevenueRate);
            //    
            //    // Find Transportation Sales Revenue Rate Class
            //    StringBuilder stringBuilder = new StringBuilder();
            //    stringBuilder.append("transportationRevenueRateClass[transportation/revenueRateClass='");
            //    stringBuilder.append(revenueRateClass);
            //    stringBuilder.append("']/sales/revenueRateClass");
            //    COTSFieldDataAndMD cotsFieldDataAndMd = extractDetails.getGroup("transportationRevenueRateClassList").getFieldAndMDForPath(stringBuilder.toString());
            //    
            //    // Add to list of Transportation Revenue Rate Class' SA Types
            //    revenueRateClass = cotsFieldDataAndMd.getValue().toString();
            //    revenueRateClassMap.get(revenueRateClass).addSaTypeRevenueRateClassifications(saTypeRevenueRate);
            //    
            //}
            /*
             * End Delete - Defect 3233711 - 2015-06-15
             */

        }
        
        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit threadWorkUnit)
                throws ThreadAbortedException, RunAbortedException {
            
            // Initialize work unit result counters.
            int recordsProcessed = 0;
            int recordsInError = 0;
			
			// Start Change - GCrisp - 2021-08-19 - CCB040.Issue3
			//Processing for monthly run
			if(!isDailyRun){
				String accountingPeriod = getAccountingPeriodForTheMonth(getProcessDateTime().getDate());
				initializeNewOutputFile(accountingPeriod);
				// Retrieve Revenue Model data
				for (SQLResultRow sqlResultRow : getRevenueModelTableRows(accountingPeriod)) { 
				// End Change - GCrisp - 2021-08-19 - CCB040.Issue3
					
					// Increment number of records processed
					recordsProcessed += 1;
					
					BigInteger saCount = sqlResultRow.getInteger("TOTAL_CNT_SUM");
	
					if (saCount.intValue() > 0){
						saCount = getDistinctServiceAgreementCount(revenueRateClassMap.get(sqlResultRow.getString("CM_REV_RATE_CLASS").trim()));
					}

					/* START CHANGES - JHERNA - 2022-02-08 - B-20848 */
					/*
					if (cisDivision.getId().getIdValue().trim().equals("MGE")
							&& sqlResultRow.getString("CM_REV_RATE_CLASS").trim().equals("IND_HEAT_CL3")){
						saCount = BigInteger.ZERO;
					}
					*/
					String cisDivStr = cisDivision.getId().getTrimmedValue();
					String revenueTypeStr = sqlResultRow.getString("CM_REV_RATE_CLASS").trim();
					/*
					 * Set SA Count to ZERO for following conditions:
					 *  1.) MGE and revenue type is IND_HEAT_CL3
					 *  2.) LGC and revenue type is MRKTRS
					 * */
					
					if ((cisDivStr.equals("MGE") && revenueTypeStr.equals("IND_HEAT_CL3"))
							|| (cisDivStr.equals("LGC") && revenueTypeStr.equals("MRKTRS"))							
							) {
						saCount = BigInteger.ZERO;
					}
					/* END CHANGES - JHERNA - 2022-02-08 - B-20848 */
					
					// Populate record
					CmHyperionExtractPerCisDivisionRecord record = new CmHyperionExtractPerCisDivisionRecord(numberOfOutputColumns);
					record.setCisDivision(cisDivision);
					record.setExtractDate(getProcessDateTime().getDate());
					record.setAccountingPeriod(sqlResultRow.getString("ACCOUNTING_PERIOD").trim());
					record.setFercNumber(sqlResultRow.getString("CM_FERC_NBR").trim());
					record.setRateClassDescription(sqlResultRow.getString("CM_RATE_CLASS_DESCR").trim());
					record.setServiceAgreementCount(saCount);
					record.setBillCount(sqlResultRow.getBigDecimal("CM_BILL_CNT_SUM"));
					record.setUnitOfMeasure(sqlResultRow.getEntity("UOM_CD", UnitOfMeasure.class));
					
					int i = generalExtractColumnList.size();
					for (ExtractColumn extractColumn : usageExtractColumnList) {
						i += 1;
						record.setUsageColumn(i, sqlResultRow.getBigDecimal(extractColumn.getFieldName() + "_SUM"));
					}
					
					for (ExtractColumn extractColumn : revenueExtractColumnList) {
						i += 1;
						record.setRevenueColumn(i, sqlResultRow.getBigDecimal(extractColumn.getFieldName() + "_SUM"));
					}
					
					// Write to file
					try {
						
						bufferedWriter.newLine();
						bufferedWriter.write(record.createRecordString());
						
					} catch (IOException e) {
						addError(CustomMessageRepositoryMGE.commGenericErrorWritingToFile(outputFile.getAbsolutePath()));
					}
					
				}
				
				try {
					bufferedWriter.close();
				} catch (IOException e) {
					addError(CustomMessageRepositoryMGE.commGenericErrorClosingFile(outputFile.getAbsolutePath()));
				}
			//Processing for daily run
			} else {
				// Create separate extract file per Accounting Period
				for (SQLResultRow accountingPeriodResultRow : getRevenueModelTableAccountingPeriods()){
					String accountingPeriod = accountingPeriodResultRow.getString("ACCOUNTING_PERIOD");
					initializeNewOutputFile(accountingPeriod);
					// Retrieve Revenue Model data
					for (SQLResultRow sqlResultRow : getRevenueModelTableRows(accountingPeriod)) { 
					// End Change - GCrisp - 2021-08-19 - CCB040.Issue3
						
						// Increment number of records processed
						recordsProcessed += 1;
						
						BigInteger saCount = sqlResultRow.getInteger("TOTAL_CNT_SUM");
		
						/* START CHANGES - JHERNA - 2022-02-08 - B-20848 */
						/*
						// 2016-10-04. DarrylH. SF-69280. Start Add
						if (cisDivision.getId().getIdValue().trim().equals("MGE")
								&& sqlResultRow.getString("CM_REV_RATE_CLASS").trim().equals("IND_HEAT_CL3")){
							saCount = BigInteger.ZERO;
						}
						// 2016-10-04. DarrylH. SF-69280. End Add
						*/
						
						String cisDivStr = cisDivision.getId().getTrimmedValue();
						String revenueTypeStr = sqlResultRow.getString("CM_REV_RATE_CLASS").trim();
						/*
						 * Set SA Count to ZERO for following conditions:
						 *  1.) MGE and revenue type is IND_HEAT_CL3
						 *  2.) LGC and revenue type is MRKTRS
						 * */
						
						if ((cisDivStr.equals("MGE") && revenueTypeStr.equals("IND_HEAT_CL3"))
								|| (cisDivStr.equals("LGC") && revenueTypeStr.equals("MRKTRS"))							
								) {
							saCount = BigInteger.ZERO;
						}
						/* END CHANGES - JHERNA - 2022-02-08 - B-20848 */
						
						// Populate record
						CmHyperionExtractPerCisDivisionRecord record = new CmHyperionExtractPerCisDivisionRecord(numberOfOutputColumns);
						record.setCisDivision(cisDivision);
						record.setExtractDate(getProcessDateTime().getDate());
						// Start Add - GCrisp - 2021-08-19 - CCB040.Issue3
						record.setAccountingPeriod(sqlResultRow.getString("ACCOUNTING_PERIOD").trim());
						// End Add - GCrisp - 2021-08-19 - CCB040.Issue3
						record.setFercNumber(sqlResultRow.getString("CM_FERC_NBR").trim());
						record.setRateClassDescription(sqlResultRow.getString("CM_RATE_CLASS_DESCR").trim());
						record.setServiceAgreementCount(saCount);
						record.setBillCount(sqlResultRow.getBigDecimal("CM_BILL_CNT_SUM"));
						record.setUnitOfMeasure(sqlResultRow.getEntity("UOM_CD", UnitOfMeasure.class));
						
						int i = generalExtractColumnList.size();
						for (ExtractColumn extractColumn : usageExtractColumnList) {
							i += 1;
							record.setUsageColumn(i, sqlResultRow.getBigDecimal(extractColumn.getFieldName() + "_SUM"));
						}
						
						for (ExtractColumn extractColumn : revenueExtractColumnList) {
							i += 1;
							record.setRevenueColumn(i, sqlResultRow.getBigDecimal(extractColumn.getFieldName() + "_SUM"));
						}
						
						// Write to file
						try {
							
							bufferedWriter.newLine();
							bufferedWriter.write(record.createRecordString());
							
						} catch (IOException e) {
							addError(CustomMessageRepositoryMGE.commGenericErrorWritingToFile(outputFile.getAbsolutePath()));
						}
						
					}
					// Start Add - GCrisp - 2021-08-19 - CCB040.Issue3
					try {
						bufferedWriter.close();
					} catch (IOException e) {
						addError(CustomMessageRepositoryMGE.commGenericErrorClosingFile(outputFile.getAbsolutePath()));
					}
				}
			}
			// End Add - GCrisp - 2021-08-19 - CCB040.Issue3
            
            // Set and return results of processing the work unit
            WorkUnitResult results = new WorkUnitResult(true);
            results.setUnitsProcessed(recordsProcessed);
            results.setUnitsInError(recordsInError);

            return results;
            
        }
        
        /**
         * Retrieve the CIS Division's Revenue Model Table data as summations over the Day or Month 
         * (according to the Batch parameter), grouped by the Revenue Rate Class.
         * @return List&lt;SQLResultRow&gt;
         */
		// Start Change - GCrisp - 2021-08-19 - CCB040.Issue3
        //private List<SQLResultRow> getRevenueModelTableRows() {
		private List<SQLResultRow> getRevenueModelTableRows(String accountingPeriod) {
        // End Change - GCrisp - 2021-08-19 - CCB040.Issue3
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");
            stringBuilder.append(    "CM_REV_RATE_CLASS, ");
            stringBuilder.append(    "CM_RATE_CLASS_DESCR, ");
            stringBuilder.append(    "CM_FERC_NBR, ");
            stringBuilder.append(    "NVL(SUM(TOTAL_CNT), 0) AS TOTAL_CNT_SUM, "); 
            stringBuilder.append(    "NVL(SUM(CM_BILL_CNT), 0) AS CM_BILL_CNT_SUM, ");
            stringBuilder.append(    "UOM_CD ");
			// Start Add - GCrisp - 2021-08-19 - CCB040.Issue3
			stringBuilder.append(    ", ACCOUNTING_PERIOD ");
			// End Add - GCrisp - 2021-08-19 - CCB040.Issue3
            
            for (ExtractColumn extractColumn : usageExtractColumnList) {
                stringBuilder.append(    ", NVL(SUM("+ extractColumn.getFieldName() + "), 0) AS " + extractColumn.getFieldName() + "_SUM ");
            }
            
            for (ExtractColumn extractColumn : revenueExtractColumnList) {
                stringBuilder.append(    ", NVL(SUM("+ extractColumn.getFieldName() + "), 0) AS " + extractColumn.getFieldName() + "_SUM ");
            }
            
            stringBuilder.append("FROM ");
            stringBuilder.append(    "CM_REVENUE_MODEL ");
            stringBuilder.append("WHERE ");

            if (isDailyRun) {
            // Start Change - GCrisp - 2021-08-19 - CCB040.Issue3
                //stringBuilder.append(    "XFER_TO_GL_DT = :processDate ");
				stringBuilder.append(    "XFER_TO_GL_DT = :processDate AND ");
			
            //} else {
            //    stringBuilder.append(    "XFER_TO_GL_DT >= :firstDayOfMonth ");
            //    stringBuilder.append(    "AND XFER_TO_GL_DT <= :lastDayOfMonth ");
            // End Change - GCrisp - 2021-08-19 - CCB040.Issue3
            }
            
			// Start Change - GCrisp - 2021-08-19 - CCB040.Issue3
            //stringBuilder.append(    "AND CIS_DIVISION = :cisDivision ");
			stringBuilder.append(    "CIS_DIVISION = :cisDivision ");
			stringBuilder.append(    "AND ACCOUNTING_PERIOD = :accountingPeriod ");
			// End Change - GCrisp - 2021-08-19 - CCB040.Issue3
			
            stringBuilder.append("GROUP BY ");
			// Start Change - GCrisp - 2021-08-19 - CCB040.Issue3
            //stringBuilder.append(    "CM_REV_RATE_CLASS, CM_RATE_CLASS_DESCR, CM_FERC_NBR, UOM_CD ");       
			stringBuilder.append(    "CM_REV_RATE_CLASS, CM_RATE_CLASS_DESCR, CM_FERC_NBR, ACCOUNTING_PERIOD, UOM_CD "); 
			// End Change - GCrisp - 2021-08-19 - CCB040.Issue3			
            stringBuilder.append("ORDER BY ");
            stringBuilder.append(    "CM_FERC_NBR ");
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            if (isDailyRun) {
                preparedStatement.bindDate("processDate", getProcessDateTime().getDate());
            // Start Delete - GCrisp - 2021-08-19 - CCB040.Issue3
            //} else {
            //    MonthInYear monthInYear = new MonthInYear(getProcessDateTime().getDate());
            //    preparedStatement.bindDate("firstDayOfMonth", monthInYear.dateForDay(1));
            //    preparedStatement.bindDate("lastDayOfMonth", monthInYear.dateForDay(monthInYear.getDaysInMonth()));
            // End Delete - GCrisp - 2021-08-19 - CCB040.Issue3// Start Delete - GCrisp - 2021-08-19 - CCB040.Issue3
            }
            
            preparedStatement.bindId("cisDivision", cisDivision.getId());
			// Start Add - GCrisp - 2021-08-19 - CCB040.Issue3
			preparedStatement.bindString("accountingPeriod", accountingPeriod.trim(), getClass().getName());
			// End Add - GCrisp - 2021-08-19 - CCB040.Issue3
            
            List<SQLResultRow> resultList = preparedStatement.list();
            
            preparedStatement.close();
            
            return resultList;
            
        }
        
        private BigInteger getDistinctServiceAgreementCount(RevenueRateClass revenueRateClass) {

        	Logger lg = LoggerFactory.getLogger(CmHyperionExtractPerCisDivisionBatch.class);
        	lg.info("\n==GET DISTINCT SERVICE AGREEMENT FOR: "+revenueRateClass.revenueRateClass+"==\n");
            if (revenueRateClass.getSaTypeRevenueRateClassifications().size() == 0) {
                return BigInteger.ZERO;
            }
            
			/* START CHANGES - JHERNA - 2022-02-08 - B-20848 */			
            // 2015-11-25. SMiran. SF-69280. Start Add
            /*
            if (cisDivision.getId().getIdValue().trim().equals("MGE")
            		&& revenueRateClass.getRevenueRateClass().trim().equals("IND_HEAT_CL3")){
            	return BigInteger.ZERO;
            }
            */
            // 2015-11-25. SMiran. SF-69280. End Add
            
			String cisDivStr = cisDivision.getId().getTrimmedValue();
			String revenueTypeStr = revenueRateClass.getRevenueRateClass().trim();
			/*
			 * Set SA Count to ZERO for following conditions:
			 *  1.) MGE and revenue type is IND_HEAT_CL3
			 *  2.) LGC and revenue type is MRKTRS
			 * */
			
			if ((cisDivStr.equals("MGE") && revenueTypeStr.equals("IND_HEAT_CL3"))
					|| (cisDivStr.equals("LGC") && revenueTypeStr.equals("MRKTRS"))							
					) {
				return BigInteger.ZERO;
			}
			/* END CHANGES - JHERNA - 2022-02-08 - B-20848 */
            
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT COUNT ( ");
            stringBuilder.append(    "DISTINCT FT.SA_ID) AS SA_ID_CNT ");
            stringBuilder.append("FROM ");
            stringBuilder.append(    "CI_FT FT, ");
            stringBuilder.append(    "CI_SA SA, ");
            stringBuilder.append(    "CI_SA_CHAR SACH ");
            stringBuilder.append("WHERE ");
            stringBuilder.append(    "FT.ACCOUNTING_DT >= :firstDayOfMonth ");
            stringBuilder.append(    "AND FT.ACCOUNTING_DT <= :lastDayOfMonth ");
            stringBuilder.append(    "AND FT.FT_TYPE_FLG IN (:billSegment, :billSegmentCancel) ");
            stringBuilder.append(    "AND FT.CIS_DIVISION = :cisDivision ");
            // 2015-10-15. SMiran. SF-59496. Start Add
            stringBuilder.append(    "AND FT.REDUNDANT_SW = 'N' ");
            // 2015-10-15. SMiran. SF-59496. End Add
            stringBuilder.append(    "AND SA.SA_ID = FT.SA_ID ");
            stringBuilder.append(    "AND SA.CIS_DIVISION = FT.CIS_DIVISION ");
            stringBuilder.append(    "AND SACH.SA_ID = SA.SA_ID ");
            stringBuilder.append(    "AND SACH.CHAR_TYPE_CD = :saRateClassCharacteristicType ");
            stringBuilder.append(    "AND (");
            
            for (int i = 0; i < revenueRateClass.getSaTypeRevenueRateClassifications().size(); i++) {
                if (i != 0) {
                    stringBuilder.append(" OR ");
                }
                stringBuilder.append(    "(SA.SA_TYPE_CD = :saType" + i + " ");
                stringBuilder.append(    "AND SACH.CHAR_VAL = :saRateClass" + i + ")");
            }
            
            stringBuilder.append(    ") ");
                        
            stringBuilder.append(    "AND SACH.EFFDT = ( ");
            stringBuilder.append(        "SELECT ");
            stringBuilder.append(            "MAX(SACH2.EFFDT) ");
            stringBuilder.append(        "FROM ");
            stringBuilder.append(            "CI_SA_CHAR SACH2 ");
            stringBuilder.append(        "WHERE ");
            stringBuilder.append(            "SACH2.SA_ID = SA.SA_ID ");
            stringBuilder.append(            "AND SACH2.CHAR_TYPE_CD = SACH.CHAR_TYPE_CD ");
            // START CHANGES - JHERNA - 2018-04-16 - SysAid#250378
            //stringBuilder.append(            "AND SACH2.EFFDT <= :processDate) ");
            stringBuilder.append(            "AND SACH2.EFFDT <= FT.XFER_TO_GL_DT) ");            
            // END CHANGES - JHERNA - 2018-04-16 - SysAid#250378
            
            
            if (revenueRateClass.isTransportationRevenueClassType()) {
                // START CHANGES - JHERNA - 2016-04-27 - IM-107918
            	//stringBuilder.append(    "AND NOT EXISTS ( ");
            	stringBuilder.append(    "AND (NOT EXISTS ( ");
                // END CHANGES - JHERNA - 2016-04-27 - IM-107918
            }
            
            if (revenueRateClass.isTransportationSalesRevenueClassType()) {
                stringBuilder.append(    "AND EXISTS ( ");
            }
            
            if (revenueRateClass.isTransportationRevenueClassType()
                    || revenueRateClass.isTransportationSalesRevenueClassType()) {
                stringBuilder.append(        "SELECT ");
                stringBuilder.append(            "'X' ");
                stringBuilder.append(        "FROM ");
                stringBuilder.append(            "CI_BSEG_CALC_LN BSCL, ");
                stringBuilder.append(            "CI_BSEG_CL_CHAR CLCH ");
                stringBuilder.append(        "WHERE ");
                stringBuilder.append(            "BSCL.BSEG_ID = FT.SIBLING_ID ");
                stringBuilder.append(            "AND BSCL.CALC_AMT <> 0 ");
                stringBuilder.append(            "AND CLCH.BSEG_ID = BSCL.BSEG_ID ");
                stringBuilder.append(            "AND CLCH.HEADER_SEQ = BSCL.HEADER_SEQ ");
                stringBuilder.append(            "AND CLCH.SEQNO = BSCL.SEQNO ");
                stringBuilder.append(            "AND CLCH.CHAR_TYPE_CD = :transportSalesCharType) ");
            }
            
            if (revenueRateClass.isTransportationSalesRevenueClassType()) {
                stringBuilder.append(    "AND NOT EXISTS ( ");
                stringBuilder.append(        "SELECT ");
                stringBuilder.append(            "'X' ");
                stringBuilder.append(        "FROM ");
                stringBuilder.append(            "CI_BSEG_CALC_LN BSCL, ");
                stringBuilder.append(            "CI_BSEG_CL_CHAR CLCH ");
                stringBuilder.append(        "WHERE ");
                stringBuilder.append(            "BSCL.BSEG_ID = FT.SIBLING_ID ");
                stringBuilder.append(            "AND BSCL.CALC_AMT <> 0 ");
                stringBuilder.append(            "AND CLCH.BSEG_ID = BSCL.BSEG_ID ");
                stringBuilder.append(            "AND CLCH.HEADER_SEQ = BSCL.HEADER_SEQ ");
                stringBuilder.append(            "AND CLCH.SEQNO = BSCL.SEQNO ");
                stringBuilder.append(            "AND CLCH.CHAR_TYPE_CD IN (:usageTypeCharacteristicType, :revenueTypeCharacteristicType) ");
                stringBuilder.append(            "AND NOT EXISTS ( ");
                stringBuilder.append(                "SELECT ");
                stringBuilder.append(                    "'X' ");
                stringBuilder.append(                "FROM ");
                stringBuilder.append(                    "CI_BSEG_CL_CHAR CLCH1 ");
                stringBuilder.append(                "WHERE ");
                stringBuilder.append(                    "CLCH1.BSEG_ID = CLCH.BSEG_ID ");
                stringBuilder.append(                    "AND CLCH1.HEADER_SEQ = CLCH.HEADER_SEQ ");
                stringBuilder.append(                    "AND CLCH1.SEQNO = CLCH.SEQNO ");
                stringBuilder.append(                    "AND CLCH1.CHAR_TYPE_CD = :transportSalesCharType)) ");
            }
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            // START ADD - JHERNA - 2016-04-27 - IM-107918
            else if (revenueRateClass.isTransportationRevenueClassType()) {
            	
            	stringBuilder.append(" OR   (EXISTS (SELECT 'X' FROM CI_BSEG_CALC_LN BSCL, CI_BSEG_CL_CHAR CLCH ");
            	stringBuilder.append("               WHERE BSCL.BSEG_ID = FT.SIBLING_ID ");
            	stringBuilder.append("               AND BSCL.CALC_AMT <> 0 ");
            	stringBuilder.append("               AND CLCH.BSEG_ID = BSCL.BSEG_ID ");
            	stringBuilder.append("               AND CLCH.HEADER_SEQ = BSCL.HEADER_SEQ ");
            	stringBuilder.append("               AND CLCH.SEQNO = BSCL.SEQNO ");
            	stringBuilder.append("               AND CLCH.CHAR_TYPE_CD = :transportSalesCharType ");
            	stringBuilder.append("               ) ");      
            	stringBuilder.append("        AND EXISTS (SELECT 'X' FROM CI_BSEG_CALC_LN BSCL, CI_BSEG_CL_CHAR CLCH ");
            	stringBuilder.append("                    WHERE BSCL.BSEG_ID = FT.SIBLING_ID ");
            	stringBuilder.append("                    AND BSCL.CALC_AMT <> 0 ");
            	stringBuilder.append("                    AND CLCH.BSEG_ID = BSCL.BSEG_ID ");
            	stringBuilder.append("                    AND CLCH.HEADER_SEQ = BSCL.HEADER_SEQ ");
            	stringBuilder.append("                    AND CLCH.SEQNO = BSCL.SEQNO ");
            	stringBuilder.append("                    AND CLCH.CHAR_TYPE_CD IN (:usageTypeCharacteristicType, :revenueTypeCharacteristicType) ");
            	stringBuilder.append("                    AND NOT EXISTS (SELECT 'X' FROM CI_BSEG_CL_CHAR CLCH1 ");
            	stringBuilder.append("                                    WHERE CLCH1.BSEG_ID = CLCH.BSEG_ID ");
            	stringBuilder.append("                                    AND CLCH1.HEADER_SEQ = CLCH.HEADER_SEQ ");
            	stringBuilder.append("                                    AND CLCH1.SEQNO = CLCH.SEQNO ");
            	stringBuilder.append("                                    AND CLCH1.CHAR_TYPE_CD = :transportSalesCharType ");
            	stringBuilder.append("                                    ) ");
            	stringBuilder.append("                    ) ");                   	
            	stringBuilder.append("      ) ");                   
            	stringBuilder.append(" ) ");
            }            
            // END ADD - JHERNA - 2016-04-27 - IM-107918
            
            //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            MonthInYear monthInYear = new MonthInYear(getProcessDateTime().getDate());
            preparedStatement.bindDate("firstDayOfMonth", monthInYear.dateForDay(1));
            preparedStatement.bindDate("lastDayOfMonth", monthInYear.dateForDay(monthInYear.getDaysInMonth()));
            preparedStatement.bindLookup("billSegment", FinancialTransactionTypeLookup.constants.BILL_SEGMENT);
            preparedStatement.bindLookup("billSegmentCancel", FinancialTransactionTypeLookup.constants.BILL_CANCELLATION);
            preparedStatement.bindId("cisDivision", cisDivision.getId());
            preparedStatement.bindId("saRateClassCharacteristicType", saRateClassCharacteristicType.getId());
           
            // START DELETE -
            //preparedStatement.bindDate("processDate", getProcessDateTime().getDate());
            // END DELETE - 
            
            int i = 0;
            for (SaTypeRevenueRate saTypeRevenueRate : revenueRateClass.getSaTypeRevenueRateClassifications()) {
                preparedStatement.bindString("saType" + i, saTypeRevenueRate.getSaType(), "SA_TYPE_CD");     
                preparedStatement.bindString("saRateClass" + i, saTypeRevenueRate.getSaRateClass(), "CHAR_VAL");
                i += 1;
            }
            
            if (revenueRateClass.isTransportationRevenueClassType()
                    || revenueRateClass.isTransportationSalesRevenueClassType()) {
                preparedStatement.bindId("transportSalesCharType", transportSalesCharacteristicType.getId());
            // START DELETE - JHERNA - 2016-04-27 - IM-107918
            //}
            
            //if (revenueRateClass.isTransportationSalesRevenueClassType()) {
            // END DELETE - JHERNA - 2016-04-27 - IM-107918
                preparedStatement.bindId("usageTypeCharacteristicType", usageTypeCharacteristicType.getId());
                preparedStatement.bindId("revenueTypeCharacteristicType", revenueTypeCharacteristicType.getId());
            }
            
            SQLResultRow sqlResultRow = preparedStatement.firstRow();
            preparedStatement.close();
            
            return sqlResultRow.getInteger("SA_ID_CNT");
            
        }
        // Start Delete - GCrisp - 2021-08-19 - CCB040.Issue3
        //@Override
        //public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
        //    
        //    try {
        //        
        //        bufferedWriter.close();
        //        
        //    } catch (IOException e) {
        //        addError(CustomMessageRepositoryMGE.commGenericErrorClosingFile(outputFile.getAbsolutePath()));
        //    }
        //    
        //}
		// End Delete - GCrisp - 2021-08-19 - CCB040.Issue3
		// Start Add - GCrisp - 2021-08-19 - CCB040.Issue3
        private List<SQLResultRow> getRevenueModelTableAccountingPeriods() {
            
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");
            stringBuilder.append(    "DISTINCT ACCOUNTING_PERIOD ");
            stringBuilder.append("FROM ");
            stringBuilder.append(    "CM_REVENUE_MODEL ");
            stringBuilder.append("WHERE ");
            stringBuilder.append(    "XFER_TO_GL_DT = :processDate ");
            stringBuilder.append(    "AND CIS_DIVISION = :cisDivision ");

            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			
            preparedStatement.bindDate("processDate", getProcessDateTime().getDate());
            preparedStatement.bindId("cisDivision", cisDivision.getId());
            
            List<SQLResultRow> resultList = preparedStatement.list();
            
            preparedStatement.close();
            
            return resultList;
            
        }
		
		private void initializeNewOutputFile(String accountingPeriod) {
			// Start Add - GCrisp - Defect 4588292 - 2021-09-01
			DateFormat FORMAT_YYYYMMDD = new DateFormat("yyyyMMdd");
			// End Add - GCrisp - Defect 4588292 - 2021-09-01
			String fileExtension = "";
			String fileNameWithoutExtension = "";
			String fileNameParm = getParameters().getFILE_NAME();
			Integer index = fileNameParm.indexOf(".");
			if(index > 0){
				fileNameWithoutExtension = fileNameParm.substring(0,index).trim();
				fileExtension = fileNameParm.substring(index+1).trim();
			}
			// Start Change - GCrisp - Defect 4588292 - 2021-09-01
			//outputFile = new File(getParameters().getFILE_PATH(), fileNameWithoutExtension.concat("_")
			//	.concat(accountingPeriod.trim()).concat(".").concat(fileExtension));
			outputFile = new File(getParameters().getFILE_PATH(), fileNameWithoutExtension.concat("_")
				.concat(accountingPeriod.trim().replaceAll("\\s", "")).concat("_").concat(getParameters().getProcessDate().toString(FORMAT_YYYYMMDD))
				.concat(".").concat(fileExtension));
			// End Change - GCrisp - Defect 4588292 - 2021-09-01
            try {
                
                bufferedWriter = new BufferedWriter(new FileWriter(outputFile));
                
            } catch (IOException e) {
                addError(CustomMessageRepositoryMGE.commGenericErrorOpeningFile(outputFile.getAbsolutePath()));
            }
            
            // Write header to file
            List<ExtractColumn> list = new ArrayList<ExtractColumn>();
            list.addAll(generalExtractColumnList);
            list.addAll(usageExtractColumnList);
            list.addAll(revenueExtractColumnList);

            numberOfOutputColumns = generalExtractColumnList.size() + usageExtractColumnList.size() + revenueExtractColumnList.size();
            CmHyperionExtractPerCisDivisionRecord header = new CmHyperionExtractPerCisDivisionRecord(numberOfOutputColumns);
            
            int i = 0;
            for (ExtractColumn extractColumn : list) {
                i += 1;
                header.setHeaderColumn(i, extractColumn.getDescription()); 
            }
            
            try {
                
                bufferedWriter.write(header.createRecordString());
                
            } catch (IOException e) {
                addError(CustomMessageRepositoryMGE.commGenericErrorWritingToFile(outputFile.getAbsolutePath()));
            }            
            
        }
		
		private String getAccountingPeriodForTheMonth(Date date) {            
			StringBuilder stringBuilder = new StringBuilder();
			
			stringBuilder.append("SELECT ");
			stringBuilder.append(    "CPL.PERIOD_DESCR ");
			stringBuilder.append("FROM ");
			stringBuilder.append(    "CI_CAL_PERIOD CP, ");
			stringBuilder.append(    "CI_CAL_PERIOD_L CPL ");
			stringBuilder.append("WHERE ");
			stringBuilder.append(    "CP.ACCOUNTING_PERIOD = CPL.ACCOUNTING_PERIOD ");
			stringBuilder.append(    "AND CP.FISCAL_YEAR = CPL.FISCAL_YEAR ");
			stringBuilder.append(    "AND CP.BEGIN_DT <= :date ");
			stringBuilder.append(    "AND CP.END_DT >= :date ");
			
			PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			
			preparedStatement.bindDate("date", date);
			
			SQLResultRow sqlResultRow = preparedStatement.firstRow();
			preparedStatement.close();
			
			return sqlResultRow.getString("PERIOD_DESCR");
        }
        // End Add - GCrisp - 2021-08-19 - CCB040.Issue3
    }
    
}
