/*
 ***************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Bill is Ready File Upload (E-bill) from FirsTech
 * 
 *            
 ****************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2020-03-12   JLumbre SpireOne. CCB-108. Initial Version.
 *  
 ****************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.batch.file.csv.CSVRecord;
import com.splwg.base.api.batch.file.csv.StandardCSVRecordReader;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.currency.Currency_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.common.currency.entity.Currency;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.cm.domain.customerinfo.cmFirsTechCustomerData.CmBillIsReady;
import com.splwg.cm.domain.customerinfo.cmFirsTechCustomerData.CmBillIsReady_DTO;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author TMG02631
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules={},
 *      softParameters = { @BatchJobSoftParameter (name = fileName, required = true, type = string)
 *            , @BatchJobSoftParameter (name = filePath, type = string)
 *            , @BatchJobSoftParameter (name = DIST-THD-POOL, type = string)
 *            , @BatchJobSoftParameter (name = maxErrors, type = integer)})
 */
public class CmBillIsReadyUploadBatch extends CmBillIsReadyUploadBatch_Gen {

	public static final Logger log = LoggerFactory.getLogger(CmBillIsReadyUploadBatch.class);
	public BigInteger parmMaxErrors;
	
	@Override
	public void validateSoftParameters(boolean isNewRun) {
		// Validate that File Path is a valid directory
		if (notBlank(getParameters().getFilePath())){
			File tempPath = new File(getParameters().getFilePath());
			if (!tempPath.isDirectory()){
				addError(CustomMessageRepositorySpireOne.S1_FilePathInvalid(getParameters().getFilePath()));
			}
		}

		parmMaxErrors = getParameters().getMaxErrors();	
		log.info(">>>>> parmMaxErrors: " + parmMaxErrors);
		if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
			addError(CustomMessageRepositorySpireOne.S1_MaxErrorCannotBeLessThanZero(parmMaxErrors.toString().trim()));
		}
	} 

	public JobWork getJobWork() {
		log.info(">>>>> get job work 1");
		ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
		arrayList.add(threadWorkUnit);

		return createJobWorkForThreadWorkUnitList(arrayList);
	}

	public Class<CmBillIsReadyUploadBatchWorker> getThreadWorkerClass() {
		log.info(">>>>> get job work 2");
		return CmBillIsReadyUploadBatchWorker.class;
	}

	public static class CmBillIsReadyUploadBatchWorker extends
	CmBillIsReadyUploadBatchWorker_Gen {

		private String filePath;
		private String fileName;

		private int recordsProcessed = 0;
		private int recordsInserted = 0;
		private int lineCounter = 0;

		private BufferedReader bufferedReader = null;

		public ThreadExecutionStrategy createExecutionStrategy() {
			log.info(">>>>> get job work 3");
			return new SingleTransactionStrategy(this);
		}

		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
						throws ThreadAbortedException, RunAbortedException {
			log.info(">>>>> get job work 4");

			filePath = getParameters().getFilePath();
			fileName = getParameters().getFileName();

			File file = new File(filePath, fileName);  

			log.info(">>>>> file: " + file);

			try {				
				bufferedReader = new BufferedReader(new FileReader(file));
				log.info(">>>>> bufferedReader: " + bufferedReader);
			} catch (FileNotFoundException fe) {
				throw new RunAbortedException(CustomMessageRepositorySpireOne.S1_errorWhileAccessingFile(fe.getMessage()));
			}

		}

		@Override
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			log.info(">>>>executeWorkUnitDetailedResult");

			Bool isFirst = Bool.FALSE;
			//Purge records in table
			purgeTable();

			//Get Currency values
			Currency_Id currencyId = getCurrency();	
			//Get Date values
			DateFormat dateFormat = new DateFormat("MM/dd/yyyy");

			StandardCSVRecordReader inputReader = new StandardCSVRecordReader();
			CSVRecord csvRecord;
			try {
				while ((csvRecord = inputReader.read(bufferedReader)) != null){
					
					lineCounter++;
					log.info(">>>>lineCounter: " + lineCounter);
					if (lineCounter == 1){
						isFirst = Bool.TRUE;
					}
					else{
						isFirst = Bool.FALSE;
					}

					if (isFirst.isFalse()){
						recordsProcessed++;
						String ACCT_ID = csvRecord.getString(1);
						String CM_CUST_NAME = csvRecord.getString(3);
						String CM_ADDRESS = csvRecord.getString(4);
						String NEW_TOTAL_BAL = csvRecord.getString(8);
						String AMT_DUE = csvRecord.getString(9);
						String DUE_DT = csvRecord.getString(10);
						String BILL_DT = csvRecord.getString(11);
						String LATE_PAY_CHARGE_DT = csvRecord.getString(12);
						String BILL_ID = csvRecord.getString(28);
						
						log.info(">>>>> test: " + BILL_ID);
						log.info(">>>>> DUE_DT: " + DUE_DT);
						

						Bill_Id billId = new Bill_Id(BILL_ID);
						try{
							log.info(">>>>billId");
							if (isNull(billId.getEntity())){
								log.info(">>>>billId not exists 1");
								logInfo(CustomMessageRepositorySpireOne.S1_unableToAdd(
										recordsProcessed, "Bill ID: " + BILL_ID + "does not exist."));
								continue;
							}
						} catch (Exception e) {  
							logInfo(CustomMessageRepositorySpireOne.S1_unableToAdd(
									recordsProcessed, "Bill ID: " + BILL_ID + "does not exist."));
							continue;
						}

						
						Money payoffBalance = new Money(NEW_TOTAL_BAL, currencyId);
						Money currentBalance = new Money(AMT_DUE, currencyId);
						
						Date dueDate = Date.fromString(DUE_DT, dateFormat);
						Date billDate = Date.fromString(BILL_DT, dateFormat);
						Date latePayChargeDate = Date.fromString(LATE_PAY_CHARGE_DT, dateFormat);

						try{
							CmBillIsReady_DTO dto = new CmBillIsReady_DTO();
							dto.setAccountId(ACCT_ID);
							dto.setCmCustomerName(CM_CUST_NAME);
							dto.setCmAddress(CM_ADDRESS);
							dto.setCmPayoffBalance(payoffBalance);
							dto.setCmCurrentBalance(currentBalance);
							dto.setDueDate(dueDate);
							dto.setBillDate(billDate);
							dto.setLatePaymentChargeDate(latePayChargeDate);
							dto.setBillId(BILL_ID);

							CmBillIsReady billIsReady = dto.newEntity();
							if(notNull(billIsReady)){
								recordsInserted++;
							}
						}
						catch  (ApplicationError e){
							logError(CustomMessageRepositorySpireOne.S1_unableToAdd(
									recordsProcessed, e.getServerMessage().getMessageText()));	
						}			
					}
				}
				bufferedReader.close();
			} catch (IOException e) {
				throw new RunAbortedException(CustomMessageRepositorySpireOne.S1_errorWhileAccessingFile(e.getMessage().trim()));
			} catch (DateFormatParseException e1) {
				throw new RunAbortedException(CustomMessageRepositorySpireOne.S1_errorWhileAccessingFile(e1.getMessage().trim()));
			}

			WorkUnitResult result = new WorkUnitResult(true);
			result.setUnitsProcessed(recordsProcessed);

			logInfo(CustomMessageRepositorySpireOne.S1_totalRecordsInserted(recordsInserted));

			log.info(">>>>recordsProcessed: " + recordsProcessed);
			log.info(">>>>recordsInserted: " + recordsInserted);
			return result;

		}		

		private void purgeTable(){
			log.info(">>>>> purgeTable: ");
			PreparedStatement purgeTable = createPreparedStatement("DELETE FROM CM_FIRSTECH_BILL_RDY", getClass().getName()); 

			purgeTable.execute();
			purgeTable.close();
		}

		private Currency_Id getCurrency(){
			log.info(">>>>> getCurrency: ");
			Currency_Id currencyId = null;

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT CURRENCY_CD ");
			stringBuilder.append("FROM CI_INSTALLATION ");
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "getCurrency");
			prepState.execute();
			prepState.setAutoclose(false);
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			currencyId = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
			log.info(">>>>> getCurrency: " + currencyId);
			prepState.close();
			
			if (isNull(currencyId)){
				currencyId = new Currency_Id("USD");
			}
			return currencyId;
		}

	}

}
