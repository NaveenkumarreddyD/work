/*****************************************************************************************
 * Program Name: CmAccumulateDegreeDaysAlgComp_Impl
 * Program Title: CmAccumulateDegreeDaysAlgComp_Impl
 * Author: Jain Akshita
 * Creation Date: 2019-05-20
 * Purpose: Entity for normal degree day
 * 
 ******************************************************************************************/
/*----------------------------------------------------------------------------------------
 *-------------------------- Modification HISTORY: ---------------------------------------
 * ---------------------------------------------------------------------------------------
 * Modification ID:   CCTicket:	  Author:          Date:       Description:
.* --------------------------------------------------------------------------------------
 * CCB001  	       	   45936  	 Jain Akshita     2019-05-20   TMG02493 - Initial Version                 
 *                                                      
 *****************************************************************************************/
package com.splwg.cm.domain.admin.normalDegreeDay.entity;

/**
  *  
@BusinessEntity (tableName = CM_NORM_DEG_DAY)
*/

public class NormalDegreeDay_Impl
    extends NormalDegreeDay_Gen {
   // empty
}
