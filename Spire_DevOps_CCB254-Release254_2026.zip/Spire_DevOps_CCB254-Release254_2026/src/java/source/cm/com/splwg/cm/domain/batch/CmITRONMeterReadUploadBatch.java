/*
 ***************************************************************************
 *                                                                         *
 * PROGRAM DESCRIPTION:                                                    *
 *                                                                         *
 * This custom batch program will process a file of meter readings         *
 * uploaded from ITRON MVRS for MGE meters.                                *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * CHANGE HISTORY:                                                         *
 *                                                                         *
 * Date:        by:             Reason:                                    *
 * YYYY-MM-DD   IN              Reason text.                               *
 *                                                                         *
 * 2014-09-22   Ted Schmidt     CCB002 Initial Version.                    *
 * 2015-04-08   Ted Schmidt     Code Review Changes - Round 1              *
 * 2015-04-14   Ted Schmidt     Code Review Changes - Round 2              *
 * 2015-05-07   Ted Schmidt     Not going to use read sequence number      *
 *                              as that is the sequence read within the    *
 *                              OMR route, not within the meter.  Also,    *
 *                              changed parameter error checking to not    *
 *                              throw a Java exception.                    *
 * 2015-05-13   Ted Schmidt     Added optional parameter to display        *
 *                              a logger message after that many records   *
 *                              have been processed                        *
 * 2015-05-14   Ted Schmidt     Removed the Register Read and Char DTO     *
 *                              child processes and replaced them with     *
 *                              SQL inserts for performance reasons        *
 *                              Also added a database commit for testing   *
 * 2015-05-15   Ted Schmidt     Removed database commit                    *
 * 2015-05-19   Ted Schmidt     Added warning message if DTO meter upload  *
 *                              fails                                      *
 * 2015-05-21   Ted Schmidt     Fixed parameter DISPLAY_PROGRESS_NUM so    *
 *                              the program can handle if it is empty or   *
 *                              not even included (since it is optional)   *
 * 2016-01-29  	MPang			Updated for CCB v2.4 compilation. 		   *
 * 2018-05-23 	DarryH			sa225593 Modify logic to allow skip code
 * 								'S' position 62 and 'QR' at position63-64 to
 * 								consider as 'regular read'
 * 2021-03-18   JRGoco			46635 Retrieve corresponding UOM for MR    * 
 * 								upload.                                    *
 ***************************************************************************
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.MeterReadUploadStatusLookup;
import com.splwg.ccb.api.lookup.ReadTypeLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.meterReadSource.MeterReadSource;
import com.splwg.ccb.domain.admin.meterReadSource.MeterReadSource_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_DTO;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterReadUpload.MeterReadUpload_DTO;
import com.splwg.ccb.domain.meterread.meterReadUpload.MeterReadUpload_Id;*/

import com.splwg.ccb.domain.admin.meterReadSource.entity.MeterReadSource;
import com.splwg.ccb.domain.admin.meterReadSource.entity.MeterReadSource_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_DTO;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.meterReadUpload.entity.MeterReadUpload_DTO;
import com.splwg.ccb.domain.meterread.meterReadUpload.entity.MeterReadUpload_Id;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.common.ApplicationException;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author 20404
 *
 @BatchJob (modules = {}, multiThreaded = false, rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = meterReadSource, name = READ_SOURCE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = unitOfMeasure, name = UOM_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = TAMPER_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = SKIP_REASON_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = DISPLAY_PROGRESS_NUM, required = false, type = string)})
 */
public class CmITRONMeterReadUploadBatch extends
		CmITRONMeterReadUploadBatch_Gen {
	// Constants
	private static final String FILE_PATH = "File Path";
	private static final String DISPLAY_PROGRESS_NUM = "DISPLAY_PROGRESS_NUM";

	// Soft Parameters
	private String parmFilePath;
	@SuppressWarnings("unused")
	private String parmFileName;
	@SuppressWarnings("unused")
	private MeterReadSource parmReadSource;
	@SuppressWarnings("unused")
	private UnitOfMeasure parmUOMCd;
	private CharacteristicType parmTamperCharType;
	private CharacteristicType parmSkipReasonCharType;
	private String parmDisplayProgressNum;

	@Override
	public void validateSoftParameters(boolean arg0) {
		// Retrieve soft parameters
		parmFilePath = this.getParameters().getFILE_PATH().trim();
		parmFileName = this.getParameters().getFILE_NAME().trim();
		parmReadSource = this.getParameters().getREAD_SOURCE();
		parmUOMCd = this.getParameters().getUOM_CD();
		parmTamperCharType = this.getParameters().getTAMPER_CHAR_TYPE();
		parmSkipReasonCharType = this.getParameters().getSKIP_REASON_CHAR_TYPE();
		parmDisplayProgressNum = this.getParameters().getDISPLAY_PROGRESS_NUM();

		// Validate file path
		cmValidateFilePath(parmFilePath);

		// Validate tamper characteristic type against meter read and meter read upload staging
		cmValidateMeterReadCharType(parmTamperCharType, CharacteristicEntityLookup.constants.METER_READ);
		cmValidateMeterReadCharType(parmTamperCharType, CharacteristicEntityLookup.constants.METER_READ_UPLOAD_STAGING);

		// Validate skip reason characteristic type against meter read and meter read upload staging
		cmValidateMeterReadCharType(parmSkipReasonCharType, CharacteristicEntityLookup.constants.METER_READ);
		cmValidateMeterReadCharType(parmSkipReasonCharType, CharacteristicEntityLookup.constants.METER_READ_UPLOAD_STAGING);

		// Validate display progress number
		cmValidateDisplayProgressNumber(parmDisplayProgressNum);

	}

	private void cmValidateFilePath(String filePath) {
		// Verify it is a folder and validate directory
		File folder = new File(filePath);
		if (this.isNull(folder) || !folder.isDirectory()) {
			addError(CustomMessageRepositoryMGE.commBatchParameterIsNotValidFilePath(FILE_PATH, filePath.trim()));
		}
	}

	private void cmValidateMeterReadCharType(CharacteristicType meterReadCharType, CharacteristicEntityLookup charEntityLookup) {
		// Make sure it is a valid characteristic for meter read upload staging
		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(meterReadCharType,
				charEntityLookup);

		if (isNull(charEntityId.getEntity())) {
			addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharTypeForEntity(meterReadCharType.toString().trim(),
					meterReadCharType.getId().getTrimmedValue(), charEntityLookup.getConstantName().trim()));
		}
	}

	private void cmValidateDisplayProgressNumber(String displayProgressNum) {
		// Verify, if included, it is an integer greater than zero
    	int numberValue = 0;

    	// Optional field
    	if (!(displayProgressNum == null)) {
        	// Returns a zero if there was only blanks in the field
	    	if (!(displayProgressNum.length() == 0)) {
	        	// Attempt to convert the string to an integer
	        	try {
	        		numberValue = Integer.parseInt(displayProgressNum);
	        		if (!(numberValue > 0)) {
	        			addError(CustomMessageRepositoryMGE.commBatchParameterMustBeGreaterThanZero(DISPLAY_PROGRESS_NUM, displayProgressNum));
	        		}
	        	}
	        	catch (NumberFormatException e) {
	        		addError(CustomMessageRepositoryMGE.commBatchParameterIsNotValidInteger(DISPLAY_PROGRESS_NUM, displayProgressNum));
	        	}
	    	}
    	}
	}

	public JobWork getJobWork() {
		// Create Dummy Job Work
		List<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
		arrayList.add(threadWorkUnit);
		return createJobWorkForThreadWorkUnitList(arrayList);
	}

	public Class<CmITRONMeterReadUploadBatchWorker> getThreadWorkerClass() {
		return CmITRONMeterReadUploadBatchWorker.class;
	}

	public static class CmITRONMeterReadUploadBatchWorker extends
			CmITRONMeterReadUploadBatchWorker_Gen {
		// Constants
		// Itron File Common Record Layout
		private static final int COMMON_REC_ID_START = 1;
		private static final int COMMON_REC_ID_LENGTH = 3;
		private static final int COMMON_DATA_START = COMMON_REC_ID_START + COMMON_REC_ID_LENGTH;
		private static final int COMMON_DATA_LENGTH = 123;
		private static final int COMMON_END_START = COMMON_DATA_START + COMMON_DATA_LENGTH;
		private static final int COMMON_END_LENGTH = 2;

		// Itron Common Route Number
		// This information is on all records but the file header and file trailer
		private static final int COMMON_CYCLE_START = COMMON_REC_ID_START + COMMON_REC_ID_LENGTH;
		private static final int COMMON_CYCLE_LENGTH = 2;
		private static final int COMMON_ROUTE_TYPE_START = COMMON_CYCLE_START + COMMON_CYCLE_LENGTH;
		private static final int COMMON_ROUTE_TYPE_LENGTH = 1;
		private static final int COMMON_ROUTE_ID_START = COMMON_ROUTE_TYPE_START + COMMON_ROUTE_TYPE_LENGTH;
		private static final int COMMON_ROUTE_ID_LENGTH = 5;
		private static final int COMMON_ROUTE_INFO_START = COMMON_CYCLE_START;
		private static final int COMMON_ROUTE_INFO_LENGTH = COMMON_CYCLE_LENGTH + COMMON_ROUTE_TYPE_LENGTH + COMMON_ROUTE_ID_LENGTH;

		// Itron File Length
		private static final int ITRON_FILE_LENGTH = COMMON_END_START + COMMON_END_LENGTH;

		// Itron File Record Types
		private static final String REC_ID_FILE_HEADER = "FHD";        // Only one record of this type per file, always the first record
		private static final String REC_ID_ROUTE_HEADER = "ERH";       // A record for the start of each route in the file
		private static final String REC_ID_CUSTOMER = "CUS";           // The customer record which signifies a new record set
		private static final String REC_ID_METER = "MTR";              // The meter information for the customer (there can be multiple per customer)
		private static final String REC_ID_METER_CHANGE = "MTC";       // Meter changes are not performed through Itron - this is not used
		private static final String REC_ID_METER_EXTRA = "MTX";        // Latitude and longitude information for meter
		private static final String REC_ID_METER_SPECIAL_TEXT = "MTS"; // Meter location details for meter
		private static final String REC_ID_READ = "RDG";               // The reading information for each meter record above
		private static final String REC_ID_RADIO = "RFF";              // The ERT information for each radio (not key punch) read record
		private static final String REC_ID_ROUTE_TRAILER = "ERT";      // A record for the end of the route information
		private static final String REC_ID_FILE_TRAILER = "FTR";       // Only one record of this type per file, always the last record

		// Itron File Header Record Layout REC_ID_FILE_HEADER
		// New Service Indicator
		private static final int FILE_HEADER_NEW_IND_START = COMMON_REC_ID_START + COMMON_REC_ID_LENGTH;
		private static final int FILE_HEADER_NEW_IND_LENGTH = 1;
		private static final int FILE_HEADER_FILLER_1_START = FILE_HEADER_NEW_IND_START + FILE_HEADER_NEW_IND_LENGTH;
		private static final int FILE_HEADER_FILLER_1_LENGTH = 1;
		// Change Meter (MTC) Record Indicator
		private static final int FILE_HEADER_CHG_IND_START = FILE_HEADER_FILLER_1_START + FILE_HEADER_FILLER_1_LENGTH;
		private static final int FILE_HEADER_CHG_IND_LENGTH = 1;
		private static final int FILE_HEADER_FILLER_2_START = FILE_HEADER_CHG_IND_START + FILE_HEADER_CHG_IND_LENGTH;
		private static final int FILE_HEADER_FILLER_2_LENGTH = 1;
		private static final int FILE_HEADER_NUM_ROUTES_START = FILE_HEADER_FILLER_2_START + FILE_HEADER_FILLER_2_LENGTH;
		private static final int FILE_HEADER_NUM_ROUTES_LENGTH = 3;
		private static final int FILE_HEADER_NUM_CUSTOMERS_START = FILE_HEADER_NUM_ROUTES_START + FILE_HEADER_NUM_ROUTES_LENGTH;
		private static final int FILE_HEADER_NUM_CUSTOMERS_LENGTH = 6;
		private static final int FILE_HEADER_NUM_METERS_START = FILE_HEADER_NUM_CUSTOMERS_START + FILE_HEADER_NUM_CUSTOMERS_LENGTH;
		private static final int FILE_HEADER_NUM_METERS_LENGTH = 6;
		private static final int FILE_HEADER_NUM_READINGS_START = FILE_HEADER_NUM_METERS_START + FILE_HEADER_NUM_METERS_LENGTH;
		private static final int FILE_HEADER_NUM_READINGS_LENGTH = 6;
		// Extended Route Format Indicator
		private static final int FILE_HEADER_ERH_FMT_START = FILE_HEADER_NUM_READINGS_START + FILE_HEADER_NUM_READINGS_LENGTH;
		private static final int FILE_HEADER_ERH_FMT_LENGTH = 1;
		private static final int FILE_HEADER_FILLER_3_START = FILE_HEADER_ERH_FMT_START + FILE_HEADER_ERH_FMT_LENGTH;
		private static final int FILE_HEADER_FILLER_3_LENGTH = 91;
		private static final int FILE_HEADER_NUM_RECORDS_START = FILE_HEADER_FILLER_3_START + FILE_HEADER_FILLER_3_LENGTH;
		private static final int FILE_HEADER_NUM_RECORDS_LENGTH = 6;

		// Itron Route Header Record Layout REC_ID_ROUTE_HEADER
		private static final int ROUTE_HEADER_ROUTE_NUM_START = COMMON_REC_ID_START + COMMON_REC_ID_LENGTH;
		private static final int ROUTE_HEADER_ROUTE_NUM_LENGTH = COMMON_ROUTE_INFO_LENGTH;
		// Survey (RTS) Record Indicator
		private static final int ROUTE_HEADER_SRVY_IND_START = ROUTE_HEADER_ROUTE_NUM_START + ROUTE_HEADER_ROUTE_NUM_LENGTH;
		private static final int ROUTE_HEADER_SRVY_IND_LENGTH = 1;
		// Route Message (RTM) Record Indicator
		private static final int ROUTE_HEADER_MSG_IND_START = ROUTE_HEADER_SRVY_IND_START + ROUTE_HEADER_SRVY_IND_LENGTH;
		private static final int ROUTE_HEADER_MSG_IND_LENGTH = 1;
		// Number of Keys (for example, keys for locks)
		private static final int ROUTE_HEADER_NUM_KEYS_START = ROUTE_HEADER_MSG_IND_START + ROUTE_HEADER_MSG_IND_LENGTH;
		private static final int ROUTE_HEADER_NUM_KEYS_LENGTH = 4;
		private static final int ROUTE_HEADER_NUM_READ_RECS_START = ROUTE_HEADER_NUM_KEYS_START + ROUTE_HEADER_NUM_KEYS_LENGTH;
		private static final int ROUTE_HEADER_NUM_READ_RECS_LENGTH = 5;
		private static final int ROUTE_HEADER_NUM_DEM_METERS_START = ROUTE_HEADER_NUM_READ_RECS_START + ROUTE_HEADER_NUM_READ_RECS_LENGTH;
		private static final int ROUTE_HEADER_NUM_DEM_METERS_LENGTH = 5;
		// Number of Manual Reads
		private static final int ROUTE_HEADER_NUM_KEY_READS_START = ROUTE_HEADER_NUM_DEM_METERS_START + ROUTE_HEADER_NUM_DEM_METERS_LENGTH;
		private static final int ROUTE_HEADER_NUM_KEY_READS_LENGTH = 5;
		private static final int ROUTE_HEADER_NUM_PROBE_READS_2_START = ROUTE_HEADER_NUM_KEY_READS_START + ROUTE_HEADER_NUM_KEY_READS_LENGTH;
		private static final int ROUTE_HEADER_NUM_PROBE_READS_2_LENGTH = 5;
		// Number of Off-Site ERT Reads
		private static final int ROUTE_HEADER_NUM_OS_READS_START = ROUTE_HEADER_NUM_PROBE_READS_2_START + ROUTE_HEADER_NUM_PROBE_READS_2_LENGTH;
		private static final int ROUTE_HEADER_NUM_OS_READS_LENGTH = 5;
		private static final int ROUTE_HEADER_NUM_CUSTOMER_RECS_START = ROUTE_HEADER_NUM_OS_READS_START + ROUTE_HEADER_NUM_OS_READS_LENGTH;
		private static final int ROUTE_HEADER_NUM_CUSTOMER_RECS_LENGTH = 5;
		private static final int ROUTE_HEADER_NUM_METER_RECS_START = ROUTE_HEADER_NUM_CUSTOMER_RECS_START + ROUTE_HEADER_NUM_CUSTOMER_RECS_LENGTH;
		private static final int ROUTE_HEADER_NUM_METER_RECS_LENGTH = 5;
		private static final int ROUTE_HEADER_ROUTE_TIME_START = ROUTE_HEADER_NUM_METER_RECS_START + ROUTE_HEADER_NUM_METER_RECS_LENGTH;
		private static final int ROUTE_HEADER_ROUTE_TIME_LENGTH = 6;
		// Resequence Indicator
		private static final int ROUTE_HEADER_RESEQ_IND_START = ROUTE_HEADER_ROUTE_TIME_START + ROUTE_HEADER_ROUTE_TIME_LENGTH;
		private static final int ROUTE_HEADER_RESEQ_IND_LENGTH = 1;
		// Route In Original Sequence Indicator
		private static final int ROUTE_HEADER_SEQ_IND_START = ROUTE_HEADER_RESEQ_IND_START + ROUTE_HEADER_RESEQ_IND_LENGTH;
		private static final int ROUTE_HEADER_SEQ_IND_LENGTH = 1;
		private static final int ROUTE_HEADER_NUM_CUSTOMERS_START = ROUTE_HEADER_SEQ_IND_START + ROUTE_HEADER_SEQ_IND_LENGTH;
		private static final int ROUTE_HEADER_NUM_CUSTOMERS_LENGTH = 5;
		private static final int ROUTE_HEADER_NUM_METERS_START = ROUTE_HEADER_NUM_CUSTOMERS_START + ROUTE_HEADER_NUM_CUSTOMERS_LENGTH;
		private static final int ROUTE_HEADER_NUM_METERS_LENGTH = 5;
		private static final int ROUTE_HEADER_NUM_READS_START = ROUTE_HEADER_NUM_METERS_START + ROUTE_HEADER_NUM_METERS_LENGTH;
		private static final int ROUTE_HEADER_NUM_READS_LENGTH = 5;
		private static final int ROUTE_HEADER_NUM_MISSED_START = ROUTE_HEADER_NUM_READS_START + ROUTE_HEADER_NUM_READS_LENGTH;
		private static final int ROUTE_HEADER_NUM_MISSED_LENGTH = 5;
		private static final int ROUTE_HEADER_NUM_SKIPPED_START = ROUTE_HEADER_NUM_MISSED_START + ROUTE_HEADER_NUM_MISSED_LENGTH;
		private static final int ROUTE_HEADER_NUM_SKIPPED_LENGTH = 5;
		private static final int ROUTE_HEADER_NUM_GAS_START = ROUTE_HEADER_NUM_SKIPPED_START + ROUTE_HEADER_NUM_SKIPPED_LENGTH;
		private static final int ROUTE_HEADER_NUM_GAS_LENGTH = 5;
		private static final int ROUTE_HEADER_NUM_WATER_START = ROUTE_HEADER_NUM_GAS_START + ROUTE_HEADER_NUM_GAS_LENGTH;
		private static final int ROUTE_HEADER_NUM_WATER_LENGTH = 5;
		private static final int ROUTE_HEADER_NUM_ELEC_START = ROUTE_HEADER_NUM_WATER_START + ROUTE_HEADER_NUM_WATER_LENGTH;
		private static final int ROUTE_HEADER_NUM_ELEC_LENGTH = 5;
		// Region
		private static final int ROUTE_HEADER_REG_START = ROUTE_HEADER_NUM_ELEC_START + ROUTE_HEADER_NUM_ELEC_LENGTH;
		private static final int ROUTE_HEADER_REG_LENGTH = 2;
		private static final int ROUTE_HEADER_ZONE_START = ROUTE_HEADER_REG_START + ROUTE_HEADER_REG_LENGTH;
		private static final int ROUTE_HEADER_ZONE_LENGTH = 2;
		private static final int ROUTE_HEADER_OFFICE_START = ROUTE_HEADER_ZONE_START + ROUTE_HEADER_ZONE_LENGTH;
		private static final int ROUTE_HEADER_OFFICE_LENGTH = 2;
		// Scheduled Read Date
		private static final int ROUTE_HEADER_SCH_READ_START = ROUTE_HEADER_OFFICE_START + ROUTE_HEADER_OFFICE_LENGTH;
		private static final int ROUTE_HEADER_SCH_READ_LENGTH = 8;
		// Reader Statistics (RMR) Record Indicator
		private static final int ROUTE_HEADER_STATS_IND_START = ROUTE_HEADER_SCH_READ_START + ROUTE_HEADER_SCH_READ_LENGTH;
		private static final int ROUTE_HEADER_STATS_IND_LENGTH = 1;
		// Route Was Forced Complete Indicator
		private static final int ROUTE_HEADER_FORCE_IND_START = ROUTE_HEADER_STATS_IND_START + ROUTE_HEADER_STATS_IND_LENGTH;
		private static final int ROUTE_HEADER_FORCE_IND_LENGTH = 1;
		// Force Complete Code
		private static final int ROUTE_HEADER_FORCE_CODE_START = ROUTE_HEADER_FORCE_IND_START + ROUTE_HEADER_FORCE_IND_LENGTH;
		private static final int ROUTE_HEADER_FORCE_CODE_LENGTH = 2;
		private static final int ROUTE_HEADER_NUM_PROBE_READS_START = ROUTE_HEADER_FORCE_CODE_START + ROUTE_HEADER_FORCE_CODE_LENGTH;
		private static final int ROUTE_HEADER_NUM_PROBE_READS_LENGTH = 5;
		// Type of Route
		private static final int ROUTE_HEADER_ROUTE_TYPE_START = ROUTE_HEADER_NUM_PROBE_READS_START + ROUTE_HEADER_NUM_PROBE_READS_LENGTH;
		private static final int ROUTE_HEADER_ROUTE_TYPE_LENGTH = 1;
		// Type of Resequence Flag
		private static final int ROUTE_HEADER_TYPE_RESEQ_FLAG_START = ROUTE_HEADER_ROUTE_TYPE_START + ROUTE_HEADER_ROUTE_TYPE_LENGTH;
		private static final int ROUTE_HEADER_TYPE_RESEQ_FLAG_LENGTH = 1;
		@SuppressWarnings("unused")
		private static final int ROUTE_HEADER_FILLER_START = ROUTE_HEADER_TYPE_RESEQ_FLAG_START + ROUTE_HEADER_TYPE_RESEQ_FLAG_LENGTH;
		@SuppressWarnings("unused")
		private static final int ROUTE_HEADER_FILLER_LENGTH = 1;

		// Itron Customer Record Layout REC_ID_CUSTOMER
		private static final int CUSTOMER_ROUTE_NUM_START = COMMON_REC_ID_START + COMMON_REC_ID_LENGTH;
		private static final int CUSTOMER_ROUTE_NUM_LENGTH = COMMON_ROUTE_INFO_LENGTH;
		private static final int CUSTOMER_NUM_METERS_START = CUSTOMER_ROUTE_NUM_START + CUSTOMER_ROUTE_NUM_LENGTH;
		private static final int CUSTOMER_NUM_METERS_LENGTH = 3;
		private static final int CUSTOMER_ACCOUNT_START = CUSTOMER_NUM_METERS_START + CUSTOMER_NUM_METERS_LENGTH;
		private static final int CUSTOMER_ACCOUNT_LENGTH = 20;
		private static final int CUSTOMER_NAME_START = CUSTOMER_ACCOUNT_START + CUSTOMER_ACCOUNT_LENGTH;
		private static final int CUSTOMER_NAME_LENGTH = 20;
		private static final int CUSTOMER_ADDR_LINE_1_START = CUSTOMER_NAME_START + CUSTOMER_NAME_LENGTH;
		private static final int CUSTOMER_ADDR_LINE_1_LENGTH = 20;
		private static final int CUSTOMER_ADDR_LINE_2_START = CUSTOMER_ADDR_LINE_1_START + CUSTOMER_ADDR_LINE_1_LENGTH;
		private static final int CUSTOMER_ADDR_LINE_2_LENGTH = 20;
		private static final int CUSTOMER_FILLER_START = CUSTOMER_ADDR_LINE_2_START + CUSTOMER_ADDR_LINE_2_LENGTH;
		private static final int CUSTOMER_FILLER_LENGTH = 2;
		private static final int CUSTOMER_GROUP_CODE_START = CUSTOMER_FILLER_START + CUSTOMER_FILLER_LENGTH;
		private static final int CUSTOMER_GROUP_CODE_LENGTH = 1;
		// Customer Extra (CSX) Record Indicator
		private static final int CUSTOMER_XT_REC_START = CUSTOMER_GROUP_CODE_START + CUSTOMER_GROUP_CODE_LENGTH;
		private static final int CUSTOMER_XT_REC_LENGTH = 1;
		// Exception Code
		private static final int CUSTOMER_EXCP_CODE_START = CUSTOMER_XT_REC_START + CUSTOMER_XT_REC_LENGTH;
		private static final int CUSTOMER_EXCP_CODE_LENGTH = 1;
		private static final int CUSTOMER_SEGMENT_CODE_START = CUSTOMER_EXCP_CODE_START + CUSTOMER_EXCP_CODE_LENGTH;
		private static final int CUSTOMER_SEGMENT_CODE_LENGTH = 4;
		// Utility ID
		private static final int CUSTOMER_UTIL_ID_START = CUSTOMER_SEGMENT_CODE_START + CUSTOMER_SEGMENT_CODE_LENGTH;
		private static final int CUSTOMER_UTIL_ID_LENGTH = 2;
		private static final int CUSTOMER_PASS_DATA_START = CUSTOMER_UTIL_ID_START + CUSTOMER_UTIL_ID_LENGTH;
		private static final int CUSTOMER_PASS_DATA_LENGTH = 1;
		// Begin CSS Specific Definition
		// CSS Premise
		private static final int CUSTOMER_CSS_ID_PREM_START = CUSTOMER_PASS_DATA_START + CUSTOMER_PASS_DATA_LENGTH;
		private static final int CUSTOMER_CSS_ID_PREM_LENGTH = 9;
		@SuppressWarnings("unused")
		private static final int CUSTOMER_FILLER_CSS_START = CUSTOMER_CSS_ID_PREM_START + CUSTOMER_CSS_ID_PREM_LENGTH;
		@SuppressWarnings("unused")
		private static final int CUSTOMER_FILLER_CSS_LENGTH = 11;
		// End CSS Specific Definition
		// Begin CC&B Specific Definition (for same space used by CSS Definition)
		// CC&B Premise
		private static final int CUSTOMER_CCB_PREM_ID_START = CUSTOMER_PASS_DATA_START + CUSTOMER_PASS_DATA_LENGTH;
		private static final int CUSTOMER_CCB_PREM_ID_LENGTH = 10;
		@SuppressWarnings("unused")
		private static final int CUSTOMER_FILLER_CCB_START = CUSTOMER_CCB_PREM_ID_START + CUSTOMER_CCB_PREM_ID_LENGTH;
		@SuppressWarnings("unused")
		private static final int CUSTOMER_FILLER_CCB_LENGTH = 10;
		// End CC&B Specific Definition

		// Itron Meter Record Layout REC_ID_METER
		private static final int METER_ROUTE_NUM_START = COMMON_REC_ID_START + COMMON_REC_ID_LENGTH;
		private static final int METER_ROUTE_NUM_LENGTH = COMMON_ROUTE_INFO_LENGTH;
		private static final int METER_NUM_READS_START = METER_ROUTE_NUM_START + METER_ROUTE_NUM_LENGTH;
		private static final int METER_NUM_READS_LENGTH = 3;
		private static final int METER_GROUP_CODE_START = METER_NUM_READS_START + METER_NUM_READS_LENGTH;
		private static final int METER_GROUP_CODE_LENGTH = 1;
		private static final int METER_FILLER_START = METER_GROUP_CODE_START + METER_GROUP_CODE_LENGTH;
		private static final int METER_FILLER_LENGTH = 10;
		// Survey Code 1 Indicator
		private static final int METER_SURVEY_CODE_1_START = METER_FILLER_START + METER_FILLER_LENGTH;
		private static final int METER_SURVEY_CODE_1_LENGTH = 1;
		private static final int METER_FILLER_2_START = METER_SURVEY_CODE_1_START + METER_SURVEY_CODE_1_LENGTH;
		private static final int METER_FILLER_2_LENGTH = 2;
		// Survey Code 2 Indicator
		private static final int METER_SURVEY_CODE_2_START = METER_FILLER_2_START + METER_FILLER_2_LENGTH;
		private static final int METER_SURVEY_CODE_2_LENGTH = 1;
		private static final int METER_BILL_CODE_START = METER_SURVEY_CODE_2_START + METER_SURVEY_CODE_2_LENGTH;
		private static final int METER_BILL_CODE_LENGTH = 1;
		private static final int METER_STATUS_START = METER_BILL_CODE_START + METER_BILL_CODE_LENGTH;
		private static final int METER_STATUS_LENGTH = 1;
		// Optical ID
		private static final int METER_OPT_ID_START = METER_STATUS_START + METER_STATUS_LENGTH;
		private static final int METER_OPT_ID_LENGTH = 14;
		// Meter Badge
		private static final int METER_NUMBER_START = METER_OPT_ID_START + METER_OPT_ID_LENGTH;
		private static final int METER_NUMBER_LENGTH = 12;
		private static final int METER_FILLER_3_START = METER_NUMBER_START + METER_NUMBER_LENGTH;
		private static final int METER_FILLER_3_LENGTH = 2;
		private static final int METER_TYPE_START = METER_FILLER_3_START + METER_FILLER_3_LENGTH;
		private static final int METER_TYPE_LENGTH = 2;
		// Reading Sequence Number
		private static final int METER_READ_SEQ_START = METER_TYPE_START + METER_TYPE_LENGTH;
		private static final int METER_READ_SEQ_LENGTH = 8;
		// New Reading Sequence Number
		private static final int METER_NEW_SEQ_START = METER_READ_SEQ_START + METER_READ_SEQ_LENGTH;
		private static final int METER_NEW_SEQ_LENGTH = 8;
		private static final int METER_FILLER_4_START = METER_NEW_SEQ_START + METER_NEW_SEQ_LENGTH;
		private static final int METER_FILLER_4_LENGTH = 1;
		private static final int METER_LOCATION_START = METER_FILLER_4_START + METER_FILLER_4_LENGTH;
		private static final int METER_LOCATION_LENGTH = 2;
		private static final int METER_FILLER_5_START = METER_LOCATION_START + METER_LOCATION_LENGTH;
		private static final int METER_FILLER_5_LENGTH = 1;
		private static final int METER_INSTRUCTION_1_START = METER_FILLER_5_START + METER_FILLER_5_LENGTH;
		private static final int METER_INSTRUCTION_1_LENGTH = 2;
		private static final int METER_FILLER_6_START = METER_INSTRUCTION_1_START + METER_INSTRUCTION_1_LENGTH;
		private static final int METER_FILLER_6_LENGTH = 1;
		private static final int METER_INSTRUCTION_2_START = METER_FILLER_6_START + METER_FILLER_6_LENGTH;
		private static final int METER_INSTRUCTION_2_LENGTH = 2;
		// Special Message Display Indicator
		private static final int METER_SPECIAL_MSG_START = METER_INSTRUCTION_2_START + METER_INSTRUCTION_2_LENGTH;
		private static final int METER_SPECIAL_MSG_LENGTH = 1;
		// Special Message (MTS) Record Indicator
		private static final int METER_DISP_IND_START = METER_SPECIAL_MSG_START + METER_SPECIAL_MSG_LENGTH;
		private static final int METER_DISP_IND_LENGTH = 1;
		// Trouble Message (MTM) Record Indicator
		private static final int METER_TROUBLE_MSG_START = METER_DISP_IND_START + METER_DISP_IND_LENGTH;
		private static final int METER_TROUBLE_MSG_LENGTH = 1;
		// Survey Response 1
		private static final int METER_SURVEY_1_START = METER_TROUBLE_MSG_START + METER_TROUBLE_MSG_LENGTH;
		private static final int METER_SURVEY_1_LENGTH = 1;
		// Survey Response 2
		private static final int METER_SURVEY_2_START = METER_SURVEY_1_START + METER_SURVEY_1_LENGTH;
		private static final int METER_SURVEY_2_LENGTH = 1;
		// Meter Change Out Indicator
		private static final int METER_CHANGE_OUT_START = METER_SURVEY_2_START + METER_SURVEY_2_LENGTH;
		private static final int METER_CHANGE_OUT_LENGTH = 1;
		// Change Meter (MTC) Record Indicator
		private static final int METER_CHANGE_REC_START = METER_CHANGE_OUT_START + METER_CHANGE_OUT_LENGTH;
		private static final int METER_CHANGE_REC_LENGTH = 1;
		private static final int METER_CATEGORY_START = METER_CHANGE_REC_START + METER_CHANGE_REC_LENGTH;
		private static final int METER_CATEGORY_LENGTH = 1;
		// L for Location Meter or E for Extra Meter
		private static final int METER_LOC_XTR_START = METER_CATEGORY_START + METER_CATEGORY_LENGTH;
		private static final int METER_LOC_XTR_LENGTH = 1;
		private static final int METER_TIME_MIN_START = METER_LOC_XTR_START + METER_LOC_XTR_LENGTH;
		private static final int METER_TIME_MIN_LENGTH = 3;
		private static final int METER_FILLER_7_START = METER_TIME_MIN_START + METER_TIME_MIN_LENGTH;
		private static final int METER_FILLER_7_LENGTH = 3;
		// Begin CSS Specific Definition
		// CSS Manufacturer Code
		private static final int METER_CSS_MANUFACTURER_START = METER_FILLER_7_START + METER_FILLER_7_LENGTH;
		private static final int METER_CSS_MANUFACTURER_LENGTH = 2;
		// CSS Service Point
		private static final int METER_CSS_SERVICE_POINT_START = METER_CSS_MANUFACTURER_START + METER_CSS_MANUFACTURER_LENGTH;
		private static final int METER_CSS_SERVICE_POINT_LENGTH = 4;
		// CSS Filler
		@SuppressWarnings("unused")
		private static final int METER_CSS_FILLER_START = METER_CSS_SERVICE_POINT_START + METER_CSS_SERVICE_POINT_LENGTH;
		@SuppressWarnings("unused")
		private static final int METER_CSS_FILLER_LENGTH = 14;
		// End CSS Specific Definition
		// Begin CC&B Specific Definition
		// CC&B Meter Configuration ID
		private static final int METER_CCB_MTR_CONFIG_ID_START = METER_FILLER_7_START + METER_FILLER_7_LENGTH;
		private static final int METER_CCB_MTR_CONFIG_ID_LENGTH = 10;
		// CC&B Service Point
		private static final int METER_CCB_MANUFACTURER_START = METER_CCB_MTR_CONFIG_ID_START + METER_CCB_MTR_CONFIG_ID_LENGTH;
		private static final int METER_CCB_MANUFACTURER_LENGTH = 8;
		// CC&B Unused Space
		private static final int METER_CCB_FILLER_START = METER_CCB_MANUFACTURER_START + METER_CCB_MANUFACTURER_LENGTH;
		private static final int METER_CCB_FILLER_LENGTH = 2;
		// End CC&B Specific Definition
		// Meter Extra Record Indicator
		private static final int METER_MTX_IND_START = METER_CCB_FILLER_START + METER_CCB_FILLER_LENGTH;
		private static final int METER_MTX_IND_LENGTH = 1;
		@SuppressWarnings("unused")
		private static final int METER_FILLER_8_START = METER_MTX_IND_START + METER_MTX_IND_LENGTH;
		@SuppressWarnings("unused")
		private static final int METER_FILLER_8_LENGTH = 4;

		// Itron Meter Change Record Layout REC_ID_METER_CHANGE
		private static final int METER_CHANGE_ROUTE_NUM_START = COMMON_REC_ID_START + COMMON_REC_ID_LENGTH;
		private static final int METER_CHANGE_ROUTE_NUM_LENGTH = COMMON_ROUTE_INFO_LENGTH;
		private static final int METER_CHANGE_OLD_NUMBER_START = METER_CHANGE_ROUTE_NUM_START + METER_CHANGE_ROUTE_NUM_LENGTH;
		private static final int METER_CHANGE_OLD_NUMBER_LENGTH = 12;
		private static final int METER_CHANGE_NEW_NUMBER_START = METER_CHANGE_OLD_NUMBER_START + METER_CHANGE_OLD_NUMBER_LENGTH;
		private static final int METER_CHANGE_NEW_NUMBER_LENGTH = 12;
		private static final int METER_CHANGE_FILLER_START = METER_CHANGE_NEW_NUMBER_START + METER_CHANGE_NEW_NUMBER_LENGTH;
		private static final int METER_CHANGE_FILLER_LENGTH = 2;
		private static final int METER_CHANGE_NEW_TYPE_START = METER_CHANGE_FILLER_START + METER_CHANGE_FILLER_LENGTH;
		private static final int METER_CHANGE_NEW_TYPE_LENGTH = 2;
		// Begin CC&B Specific Definition
		private static final int METER_CHANGE_NEW_CCB_MTR_CONFIG_ID_START = METER_CHANGE_NEW_TYPE_START + METER_CHANGE_NEW_TYPE_LENGTH;
		private static final int METER_CHANGE_NEW_CCB_MTR_CONFIG_ID_LENGTH = 10;
		private static final int METER_CHANGE_NEW_CCB_SERVICE_POINT_START = METER_CHANGE_NEW_CCB_MTR_CONFIG_ID_START + METER_CHANGE_NEW_CCB_MTR_CONFIG_ID_LENGTH;
		private static final int METER_CHANGE_NEW_CCB_SERVICE_POINT_LENGTH = 10;
		private static final int METER_CHANGE_FILLER_2_START = METER_CHANGE_NEW_CCB_SERVICE_POINT_START + METER_CHANGE_NEW_CCB_SERVICE_POINT_LENGTH;
		private static final int METER_CHANGE_FILLER_2_LENGTH = 0;
		// End CC&B Specific Definition
		private static final int METER_CHANGE_FILLER_3_START = METER_CHANGE_FILLER_2_START + METER_CHANGE_FILLER_2_LENGTH;
		private static final int METER_CHANGE_FILLER_3_LENGTH = 1;
		private static final int METER_CHANGE_NEW_LOCATION_START = METER_CHANGE_FILLER_3_START + METER_CHANGE_FILLER_3_LENGTH;
		private static final int METER_CHANGE_NEW_LOCATION_LENGTH = 2;
		private static final int METER_CHANGE_FILLER_4_START = METER_CHANGE_NEW_LOCATION_START + METER_CHANGE_NEW_LOCATION_LENGTH;
		private static final int METER_CHANGE_FILLER_4_LENGTH = 1;
		private static final int METER_CHANGE_NEW_INSTRUCTION_1_START = METER_CHANGE_FILLER_4_START + METER_CHANGE_FILLER_4_LENGTH;
		private static final int METER_CHANGE_NEW_INSTRUCTION_1_LENGTH = 2;
		private static final int METER_CHANGE_FILLER_5_START = METER_CHANGE_NEW_INSTRUCTION_1_START + METER_CHANGE_NEW_INSTRUCTION_1_LENGTH;
		private static final int METER_CHANGE_FILLER_5_LENGTH = 1;
		private static final int METER_CHANGE_NEW_INSTRUCTION_2_START = METER_CHANGE_FILLER_5_START + METER_CHANGE_FILLER_5_LENGTH;
		private static final int METER_CHANGE_NEW_INSTRUCTION_2_LENGTH = 2;
		private static final int METER_CHANGE_AUD_1_START = METER_CHANGE_NEW_INSTRUCTION_2_START + METER_CHANGE_NEW_INSTRUCTION_2_LENGTH;
		private static final int METER_CHANGE_AUD_1_LENGTH = 2;
		private static final int METER_CHANGE_NEW_AUD_1_START = METER_CHANGE_AUD_1_START + METER_CHANGE_AUD_1_LENGTH;
		private static final int METER_CHANGE_NEW_AUD_1_LENGTH = 2;
		private static final int METER_CHANGE_AUD_2_START = METER_CHANGE_NEW_AUD_1_START + METER_CHANGE_NEW_AUD_1_LENGTH;
		private static final int METER_CHANGE_AUD_2_LENGTH = 2;
		private static final int METER_CHANGE_NEW_AUD_2_START = METER_CHANGE_AUD_2_START + METER_CHANGE_AUD_2_LENGTH;
		private static final int METER_CHANGE_NEW_AUD_2_LENGTH = 2;
		private static final int METER_CHANGE_AUD_3_START = METER_CHANGE_NEW_AUD_2_START + METER_CHANGE_NEW_AUD_2_LENGTH;
		private static final int METER_CHANGE_AUD_3_LENGTH = 1;
		private static final int METER_CHANGE_NEW_AUD_3_START = METER_CHANGE_AUD_3_START + METER_CHANGE_AUD_3_LENGTH;
		private static final int METER_CHANGE_NEW_AUD_3_LENGTH = 1;
		private static final int METER_CHANGE_AUD_4_START = METER_CHANGE_NEW_AUD_3_START + METER_CHANGE_NEW_AUD_3_LENGTH;
		private static final int METER_CHANGE_AUD_4_LENGTH = 1;
		private static final int METER_CHANGE_NEW_AUD_4_START = METER_CHANGE_AUD_4_START + METER_CHANGE_AUD_4_LENGTH;
		private static final int METER_CHANGE_NEW_AUD_4_LENGTH = 1;
		private static final int METER_CHANGE_NEW_RDG_RECS_START = METER_CHANGE_NEW_AUD_4_START + METER_CHANGE_NEW_AUD_4_LENGTH;
		private static final int METER_CHANGE_NEW_RDG_RECS_LENGTH = 2;
		private static final int METER_CHANGE_FUNCT_START = METER_CHANGE_NEW_RDG_RECS_START + METER_CHANGE_NEW_RDG_RECS_LENGTH;
		private static final int METER_CHANGE_FUNCT_LENGTH = 1;
		@SuppressWarnings("unused")
		private static final int METER_CHANGE_FILLER_6_START = METER_CHANGE_FUNCT_START + METER_CHANGE_FUNCT_LENGTH;
		@SuppressWarnings("unused")
		private static final int METER_CHANGE_FILLER_6_LENGTH = 43;

		// Itron Meter Extra Record Layout REC_ID_METER_EXTRA
		private static final int METER_EXTRA_ROUTE_NUM_START = COMMON_REC_ID_START + COMMON_REC_ID_LENGTH;
		private static final int METER_EXTRA_ROUTE_NUM_LENGTH = COMMON_ROUTE_INFO_LENGTH;
		private static final int METER_EXTRA_NUMBER_START = METER_EXTRA_ROUTE_NUM_START + METER_EXTRA_ROUTE_NUM_LENGTH;
		private static final int METER_EXTRA_NUMBER_LENGTH = 12;
		private static final int METER_EXTRA_ORG_LATITUDE_START = METER_EXTRA_NUMBER_START + METER_EXTRA_NUMBER_LENGTH;
		private static final int METER_EXTRA_ORG_LATITUDE_LENGTH = 17;
		private static final int METER_EXTRA_ORG_LONGITUDE_START = METER_EXTRA_ORG_LATITUDE_START + METER_EXTRA_ORG_LATITUDE_LENGTH;
		private static final int METER_EXTRA_ORG_LONGITUDE_LENGTH = 17;
		private static final int METER_EXTRA_FILLER_START = METER_EXTRA_ORG_LONGITUDE_START + METER_EXTRA_ORG_LONGITUDE_LENGTH;
		private static final int METER_EXTRA_FILLER_LENGTH = 12;
		private static final int METER_EXTRA_NEW_LATITUDE_START = METER_EXTRA_FILLER_START + METER_EXTRA_FILLER_LENGTH;
		private static final int METER_EXTRA_NEW_LATITUDE_LENGTH = 17;
		private static final int METER_EXTRA_NEW_LONGITUDE_START = METER_EXTRA_NEW_LATITUDE_START + METER_EXTRA_NEW_LATITUDE_LENGTH;
		private static final int METER_EXTRA_NEW_LONGITUDE_LENGTH = 17;
		@SuppressWarnings("unused")
		private static final int METER_EXTRA_FILLER_2_START = METER_EXTRA_NEW_LONGITUDE_START + METER_EXTRA_NEW_LONGITUDE_LENGTH;
		@SuppressWarnings("unused")
		private static final int METER_EXTRA_FILLER_2_LENGTH = 23;

		// Itron Meter Special Text Record Layout REC_ID_METER_SPECIAL_TEXT
		private static final int METER_SPECIAL_TEXT_ROUTE_NUM_START = COMMON_REC_ID_START + COMMON_REC_ID_LENGTH;
		private static final int METER_SPECIAL_TEXT_ROUTE_NUM_LENGTH = COMMON_ROUTE_INFO_LENGTH;
		private static final int METER_SPECIAL_TEXT_NUMBER_START = METER_SPECIAL_TEXT_ROUTE_NUM_START + METER_SPECIAL_TEXT_ROUTE_NUM_LENGTH;
		private static final int METER_SPECIAL_TEXT_NUMBER_LENGTH = 12;
		// Meter location details
		private static final int METER_SPECIAL_TEXT_MESSAGE_START = METER_SPECIAL_TEXT_NUMBER_START + METER_SPECIAL_TEXT_NUMBER_LENGTH;
		private static final int METER_SPECIAL_TEXT_MESSAGE_LENGTH = 100;
		@SuppressWarnings("unused")
		private static final int METER_SPECIAL_TEXT_FILLER_START = METER_SPECIAL_TEXT_MESSAGE_START + METER_SPECIAL_TEXT_MESSAGE_LENGTH;
		@SuppressWarnings("unused")
		private static final int METER_SPECIAL_TEXT_FILLER_LENGTH = 3;

		// Itron Read Record Layout REC_ID_READ
		private static final int READ_ROUTE_NUM_START = COMMON_REC_ID_START + COMMON_REC_ID_LENGTH;
		private static final int READ_ROUTE_NUM_LENGTH = COMMON_ROUTE_INFO_LENGTH;
		private static final int READ_TEXT_PROMPT_START = READ_ROUTE_NUM_START + READ_ROUTE_NUM_LENGTH;
		private static final int READ_TEXT_PROMPT_LENGTH = 4;
		// Read Direction
		private static final int READ_DIR_START = READ_TEXT_PROMPT_START + READ_TEXT_PROMPT_LENGTH;
		private static final int READ_DIR_LENGTH = 1;
		private static final int READ_COMPARE_CODE_START = READ_DIR_START + READ_DIR_LENGTH;
		private static final int READ_COMPARE_CODE_LENGTH = 3;
		// Validation Code
		private static final int READ_VAL_CODE_START = READ_COMPARE_CODE_START + READ_COMPARE_CODE_LENGTH;
		private static final int READ_VAL_CODE_LENGTH = 3;
		private static final int READ_FILLER_START = READ_VAL_CODE_START + READ_VAL_CODE_LENGTH;
		private static final int READ_FILLER_LENGTH = 1;
		// Channel Number
		private static final int READ_CHAN_NUMBER_START = READ_FILLER_START + READ_FILLER_LENGTH;
		private static final int READ_CHAN_NUMBER_LENGTH = 2;
		// Radio (R) or Key Punch (K)
		private static final int READ_METHOD_START = READ_CHAN_NUMBER_START + READ_CHAN_NUMBER_LENGTH;
		private static final int READ_METHOD_LENGTH = 1;
		private static final int READ_METER_CONSTANT_START = READ_METHOD_START + READ_METHOD_LENGTH;
		private static final int READ_METER_CONSTANT_LENGTH = 6;
		private static final int READ_CONST_FLAG_START = READ_METER_CONSTANT_START + READ_METER_CONSTANT_LENGTH;
		private static final int READ_CONST_FLAG_LENGTH = 1;
		private static final int READ_CURRENT_READ_START = READ_CONST_FLAG_START + READ_CONST_FLAG_LENGTH;
		private static final int READ_CURRENT_READ_LENGTH = 10;
		private static final int READ_ORDER_START = READ_CURRENT_READ_START + READ_CURRENT_READ_LENGTH;
		private static final int READ_ORDER_LENGTH = 4;
		private static final int READ_DATE_START = READ_ORDER_START + READ_ORDER_LENGTH;
		private static final int READ_DATE_LENGTH = 8;
		private static final int READ_TIME_START = READ_DATE_START + READ_DATE_LENGTH;
		private static final int READ_TIME_LENGTH = 6;
		private static final int READ_CODE_START = READ_TIME_START + READ_TIME_LENGTH;
		private static final int READ_CODE_LENGTH = 1;
		private static final int READ_FILLER_2_START = READ_CODE_START + READ_CODE_LENGTH;
		private static final int READ_FILLER_2_LENGTH = 1;
		private static final int READ_REASON_START = READ_FILLER_2_START + READ_FILLER_2_LENGTH;
		private static final int READ_REASON_LENGTH = 2;
		private static final int READ_AUDIT_START = READ_REASON_START + READ_REASON_LENGTH;
		private static final int READ_AUDIT_LENGTH = 1;
		private static final int READ_FILLER_3_START = READ_AUDIT_START + READ_AUDIT_LENGTH;
		private static final int READ_FILLER_3_LENGTH = 1;
		private static final int READ_TROUBLE_1_START = READ_FILLER_3_START + READ_FILLER_3_LENGTH;
		private static final int READ_TROUBLE_1_LENGTH = 2;
		private static final int READ_FILLER_4_START = READ_TROUBLE_1_START + READ_TROUBLE_1_LENGTH;
		private static final int READ_FILLER_4_LENGTH = 1;
		private static final int READ_TROUBLE_2_START = READ_FILLER_4_START + READ_FILLER_4_LENGTH;
		private static final int READ_TROUBLE_2_LENGTH = 2;
		private static final int READ_AUDIT_COUNT_START = READ_TROUBLE_2_START + READ_TROUBLE_2_LENGTH;
		private static final int READ_AUDIT_COUNT_LENGTH = 1;
		private static final int READ_CLEAR_COUNT_START = READ_AUDIT_COUNT_START + READ_AUDIT_COUNT_LENGTH;
		private static final int READ_CLEAR_COUNT_LENGTH = 1;
		// Unprocessed Read Flag
		private static final int READ_UNPRO_START = READ_CLEAR_COUNT_START + READ_CLEAR_COUNT_LENGTH;
		private static final int READ_UNPRO_LENGTH = 1;
		// Reader ID
		private static final int READ_RDR_ID_START = READ_UNPRO_START + READ_UNPRO_LENGTH;
		private static final int READ_RDR_ID_LENGTH = 9;
		private static final int READ_ELAPSED_START = READ_RDR_ID_START + READ_RDR_ID_LENGTH;
		private static final int READ_ELAPSED_LENGTH = 5;
		private static final int READ_NEW_DIALS_START = READ_ELAPSED_START + READ_ELAPSED_LENGTH;
		private static final int READ_NEW_DIALS_LENGTH = 2;
		private static final int READ_NEW_DEC_START = READ_NEW_DIALS_START + READ_NEW_DIALS_LENGTH;
		private static final int READ_NEW_DEC_LENGTH = 2;
		private static final int READ_NEW_METHOD_START = READ_NEW_DEC_START + READ_NEW_DEC_LENGTH;
		private static final int READ_NEW_METHOD_LENGTH = 1;
		// Meter Constant Verified
		private static final int READ_CONS_VER_START = READ_NEW_METHOD_START + READ_NEW_METHOD_LENGTH;
		private static final int READ_CONS_VER_LENGTH = 1;
		// HHF Position
		private static final int READ_HHF_POS_START = READ_CONS_VER_START + READ_CONS_VER_LENGTH;
		private static final int READ_HHF_POS_LENGTH = 1;
		// New Meter Constant
		private static final int READ_NEW_CONS_START = READ_HHF_POS_START + READ_HHF_POS_LENGTH;
		private static final int READ_NEW_CONS_LENGTH = 6;
		private static final int READ_FILLER_5_START = READ_NEW_CONS_START + READ_NEW_CONS_LENGTH;
		private static final int READ_FILLER_5_LENGTH = 1;
		private static final int READ_TYPE_READ_START = READ_FILLER_5_START + READ_FILLER_5_LENGTH;
		private static final int READ_TYPE_READ_LENGTH = 2;
		private static final int READ_PREV_READ_START = READ_TYPE_READ_START + READ_TYPE_READ_LENGTH;
		private static final int READ_PREV_READ_LENGTH = 10;
		@SuppressWarnings("unused")
		private static final int READ_FILLER_6_START = READ_PREV_READ_START + READ_PREV_READ_LENGTH;
		@SuppressWarnings("unused")
		private static final int READ_FILLER_6_LENGTH = 11;

		// Itron Radio Record Layout REC_ID_RADIO
		private static final int RADIO_ROUTE_NUM_START = COMMON_REC_ID_START + COMMON_REC_ID_LENGTH;
		private static final int RADIO_ROUTE_NUM_LENGTH = COMMON_ROUTE_INFO_LENGTH;
		private static final int RADIO_ERT_ID_START = RADIO_ROUTE_NUM_START + RADIO_ROUTE_NUM_LENGTH;
		private static final int RADIO_ERT_ID_LENGTH = 10;
		private static final int RADIO_FILLER_START = RADIO_ERT_ID_START + RADIO_ERT_ID_LENGTH;
		private static final int RADIO_FILLER_LENGTH = 4;
		private static final int RADIO_RF_PROG_START = RADIO_FILLER_START + RADIO_FILLER_LENGTH;
		private static final int RADIO_RF_PROG_LENGTH = 4;
		private static final int RADIO_FILLER_2_START = RADIO_RF_PROG_START + RADIO_RF_PROG_LENGTH;
		private static final int RADIO_FILLER_2_LENGTH = 7;
		private static final int RADIO_AREA_START = RADIO_FILLER_2_START + RADIO_FILLER_2_LENGTH;
		private static final int RADIO_AREA_LENGTH = 2;
		private static final int RADIO_RF_FREQ_START = RADIO_AREA_START + RADIO_AREA_LENGTH;
		private static final int RADIO_RF_FREQ_LENGTH = 12;
		private static final int RADIO_RF_TONE_START = RADIO_RF_FREQ_START + RADIO_RF_FREQ_LENGTH;
		private static final int RADIO_RF_TONE_LENGTH = 4;
		private static final int RADIO_TAMPER_START = RADIO_RF_TONE_START + RADIO_RF_TONE_LENGTH;
		private static final int RADIO_TAMPER_LENGTH = 4;
		private static final int RADIO_READ_DATE_START = RADIO_TAMPER_START + RADIO_TAMPER_LENGTH;
		private static final int RADIO_READ_DATE_LENGTH = 8;
		private static final int RADIO_READ_TIME_START = RADIO_READ_DATE_START + RADIO_READ_DATE_LENGTH;
		private static final int RADIO_READ_TIME_LENGTH = 6;
		private static final int RADIO_CURRENT_READ_START = RADIO_READ_TIME_START + RADIO_READ_TIME_LENGTH;
		private static final int RADIO_CURRENT_READ_LENGTH = 10;
		private static final int RADIO_ERT_TYPE_START = RADIO_CURRENT_READ_START + RADIO_CURRENT_READ_LENGTH;
		private static final int RADIO_ERT_TYPE_LENGTH = 8;
		private static final int RADIO_FILLER_4_START = RADIO_ERT_TYPE_START + RADIO_ERT_TYPE_LENGTH;
		private static final int RADIO_FILLER_4_LENGTH = 4;
		private static final int RADIO_VISUAL_READ_START = RADIO_FILLER_4_START + RADIO_FILLER_4_LENGTH;
		private static final int RADIO_VISUAL_READ_LENGTH = 1;
		private static final int RADIO_433_PROTOCOL_START = RADIO_VISUAL_READ_START + RADIO_VISUAL_READ_LENGTH;
		private static final int RADIO_433_PROTOCOL_LENGTH = 1;
		private static final int RADIO_IWN_ENCODER_START = RADIO_433_PROTOCOL_START + RADIO_433_PROTOCOL_LENGTH;
		private static final int RADIO_IWN_ENCODER_LENGTH = 1;
		@SuppressWarnings("unused")
		private static final int RADIO_FILLER_5_START = RADIO_IWN_ENCODER_START + RADIO_IWN_ENCODER_LENGTH;
		@SuppressWarnings("unused")
		private static final int RADIO_FILLER_5_LENGTH = 29;

		// Itron Route Trailer Record Layout REC_ID_ROUTE_TRAILER (same layout as REC_ID_ROUTE_HEADER)
		private static final int ROUTE_TRAILER_ROUTE_NUM_START = COMMON_REC_ID_START + COMMON_REC_ID_LENGTH;
		private static final int ROUTE_TRAILER_ROUTE_NUM_LENGTH = ROUTE_HEADER_ROUTE_NUM_LENGTH;
		private static final int ROUTE_TRAILER_SRVY_IND_START = ROUTE_TRAILER_ROUTE_NUM_START + ROUTE_TRAILER_ROUTE_NUM_LENGTH;
		private static final int ROUTE_TRAILER_SRVY_IND_LENGTH = ROUTE_HEADER_SRVY_IND_LENGTH;
		private static final int ROUTE_TRAILER_MSG_IND_START = ROUTE_TRAILER_SRVY_IND_START + ROUTE_TRAILER_SRVY_IND_LENGTH;
		private static final int ROUTE_TRAILER_MSG_IND_LENGTH = ROUTE_HEADER_MSG_IND_LENGTH;
		private static final int ROUTE_TRAILER_NUM_KEYS_START = ROUTE_TRAILER_MSG_IND_START + ROUTE_TRAILER_MSG_IND_LENGTH;
		private static final int ROUTE_TRAILER_NUM_KEYS_LENGTH = ROUTE_HEADER_NUM_KEYS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_READ_RECS_START = ROUTE_TRAILER_NUM_KEYS_START + ROUTE_TRAILER_NUM_KEYS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_READ_RECS_LENGTH = ROUTE_HEADER_NUM_READ_RECS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_DEM_METERS_START = ROUTE_TRAILER_NUM_READ_RECS_START + ROUTE_TRAILER_NUM_READ_RECS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_DEM_METERS_LENGTH = ROUTE_HEADER_NUM_DEM_METERS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_KEY_READS_START = ROUTE_TRAILER_NUM_DEM_METERS_START + ROUTE_TRAILER_NUM_DEM_METERS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_KEY_READS_LENGTH = ROUTE_HEADER_NUM_KEY_READS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_PROBE_READS_2_START = ROUTE_TRAILER_NUM_KEY_READS_START + ROUTE_TRAILER_NUM_KEY_READS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_PROBE_READS_2_LENGTH = ROUTE_HEADER_NUM_PROBE_READS_2_LENGTH;
		private static final int ROUTE_TRAILER_NUM_OS_READS_START = ROUTE_TRAILER_NUM_PROBE_READS_2_START + ROUTE_TRAILER_NUM_PROBE_READS_2_LENGTH;
		private static final int ROUTE_TRAILER_NUM_OS_READS_LENGTH = ROUTE_HEADER_NUM_OS_READS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_CUSTOMER_RECS_START = ROUTE_TRAILER_NUM_OS_READS_START + ROUTE_TRAILER_NUM_OS_READS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_CUSTOMER_RECS_LENGTH = ROUTE_HEADER_NUM_CUSTOMER_RECS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_METER_RECS_START = ROUTE_TRAILER_NUM_CUSTOMER_RECS_START + ROUTE_TRAILER_NUM_CUSTOMER_RECS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_METER_RECS_LENGTH = ROUTE_HEADER_NUM_METER_RECS_LENGTH;
		private static final int ROUTE_TRAILER_ROUTE_TIME_START = ROUTE_TRAILER_NUM_METER_RECS_START + ROUTE_TRAILER_NUM_METER_RECS_LENGTH;
		private static final int ROUTE_TRAILER_ROUTE_TIME_LENGTH = ROUTE_HEADER_ROUTE_TIME_LENGTH;
		private static final int ROUTE_TRAILER_RESEQ_IND_START = ROUTE_TRAILER_ROUTE_TIME_START + ROUTE_TRAILER_ROUTE_TIME_LENGTH;
		private static final int ROUTE_TRAILER_RESEQ_IND_LENGTH = ROUTE_HEADER_RESEQ_IND_LENGTH;
		private static final int ROUTE_TRAILER_SEQ_IND_START = ROUTE_TRAILER_RESEQ_IND_START + ROUTE_TRAILER_RESEQ_IND_LENGTH;
		private static final int ROUTE_TRAILER_SEQ_IND_LENGTH = ROUTE_HEADER_SEQ_IND_LENGTH;
		private static final int ROUTE_TRAILER_NUM_CUSTOMERS_START = ROUTE_TRAILER_SEQ_IND_START + ROUTE_TRAILER_SEQ_IND_LENGTH;
		private static final int ROUTE_TRAILER_NUM_CUSTOMERS_LENGTH = ROUTE_HEADER_NUM_CUSTOMERS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_METERS_START = ROUTE_TRAILER_NUM_CUSTOMERS_START + ROUTE_TRAILER_NUM_CUSTOMERS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_METERS_LENGTH = ROUTE_HEADER_NUM_METERS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_READS_START = ROUTE_TRAILER_NUM_METERS_START + ROUTE_TRAILER_NUM_METERS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_READS_LENGTH = ROUTE_HEADER_NUM_READS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_MISSED_START = ROUTE_TRAILER_NUM_READS_START + ROUTE_TRAILER_NUM_READS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_MISSED_LENGTH = ROUTE_HEADER_NUM_MISSED_LENGTH;
		private static final int ROUTE_TRAILER_NUM_SKIPPED_START = ROUTE_TRAILER_NUM_MISSED_START + ROUTE_TRAILER_NUM_MISSED_LENGTH;
		private static final int ROUTE_TRAILER_NUM_SKIPPED_LENGTH = ROUTE_HEADER_NUM_SKIPPED_LENGTH;
		private static final int ROUTE_TRAILER_NUM_GAS_START = ROUTE_TRAILER_NUM_SKIPPED_START + ROUTE_TRAILER_NUM_SKIPPED_LENGTH;
		private static final int ROUTE_TRAILER_NUM_GAS_LENGTH = ROUTE_HEADER_NUM_GAS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_WATER_START = ROUTE_TRAILER_NUM_GAS_START + ROUTE_TRAILER_NUM_GAS_LENGTH;
		private static final int ROUTE_TRAILER_NUM_WATER_LENGTH = ROUTE_HEADER_NUM_WATER_LENGTH;
		private static final int ROUTE_TRAILER_NUM_ELEC_START = ROUTE_TRAILER_NUM_WATER_START + ROUTE_TRAILER_NUM_WATER_LENGTH;
		private static final int ROUTE_TRAILER_NUM_ELEC_LENGTH = ROUTE_HEADER_NUM_ELEC_LENGTH;
		private static final int ROUTE_TRAILER_REG_START = ROUTE_TRAILER_NUM_ELEC_START + ROUTE_TRAILER_NUM_ELEC_LENGTH;
		private static final int ROUTE_TRAILER_REG_LENGTH = ROUTE_HEADER_REG_LENGTH;
		private static final int ROUTE_TRAILER_ZONE_START = ROUTE_TRAILER_REG_START + ROUTE_TRAILER_REG_LENGTH;
		private static final int ROUTE_TRAILER_ZONE_LENGTH = ROUTE_HEADER_ZONE_LENGTH;
		private static final int ROUTE_TRAILER_OFFICE_START = ROUTE_TRAILER_ZONE_START + ROUTE_TRAILER_ZONE_LENGTH;
		private static final int ROUTE_TRAILER_OFFICE_LENGTH = ROUTE_HEADER_OFFICE_LENGTH;
		private static final int ROUTE_TRAILER_SCH_READ_START = ROUTE_TRAILER_OFFICE_START + ROUTE_TRAILER_OFFICE_LENGTH;
		private static final int ROUTE_TRAILER_SCH_READ_LENGTH = ROUTE_HEADER_SCH_READ_LENGTH;
		private static final int ROUTE_TRAILER_STATS_IND_START = ROUTE_TRAILER_SCH_READ_START + ROUTE_TRAILER_SCH_READ_LENGTH;
		private static final int ROUTE_TRAILER_STATS_IND_LENGTH = ROUTE_HEADER_STATS_IND_LENGTH;
		private static final int ROUTE_TRAILER_FORCE_IND_START = ROUTE_TRAILER_STATS_IND_START + ROUTE_TRAILER_STATS_IND_LENGTH;
		private static final int ROUTE_TRAILER_FORCE_IND_LENGTH = ROUTE_HEADER_FORCE_IND_LENGTH;
		private static final int ROUTE_TRAILER_FORCE_CODE_START = ROUTE_TRAILER_FORCE_IND_START + ROUTE_TRAILER_FORCE_IND_LENGTH;
		private static final int ROUTE_TRAILER_FORCE_CODE_LENGTH = ROUTE_HEADER_FORCE_CODE_LENGTH;
		private static final int ROUTE_TRAILER_NUM_PROBE_READS_START = ROUTE_TRAILER_FORCE_CODE_START + ROUTE_TRAILER_FORCE_CODE_LENGTH;
		private static final int ROUTE_TRAILER_NUM_PROBE_READS_LENGTH = ROUTE_HEADER_NUM_PROBE_READS_LENGTH;
		private static final int ROUTE_TRAILER_ROUTE_TYPE_START = ROUTE_TRAILER_NUM_PROBE_READS_START + ROUTE_TRAILER_NUM_PROBE_READS_LENGTH;
		private static final int ROUTE_TRAILER_ROUTE_TYPE_LENGTH = ROUTE_HEADER_ROUTE_TYPE_LENGTH;
		private static final int ROUTE_TRAILER_TYPE_RESEQ_FLAG_START = ROUTE_TRAILER_ROUTE_TYPE_START + ROUTE_TRAILER_ROUTE_TYPE_LENGTH;
		private static final int ROUTE_TRAILER_TYPE_RESEQ_FLAG_LENGTH = ROUTE_HEADER_TYPE_RESEQ_FLAG_LENGTH;
		@SuppressWarnings("unused")
		private static final int ROUTE_TRAILER_FILLER_START = ROUTE_TRAILER_TYPE_RESEQ_FLAG_START + ROUTE_TRAILER_TYPE_RESEQ_FLAG_LENGTH;
		@SuppressWarnings("unused")
		private static final int ROUTE_TRAILER_FILLER_LENGTH = ROUTE_HEADER_FILLER_LENGTH;

		// Itron File Trailer Record Layout REC_ID_FILE_TRAILER (same layout as REC_ID_FILE_HEADER)
		private static final int FILE_TRAILER_NEW_IND_START = COMMON_REC_ID_START + COMMON_REC_ID_LENGTH;
		private static final int FILE_TRAILER_NEW_IND_LENGTH = FILE_HEADER_NEW_IND_LENGTH;
		private static final int FILE_TRAILER_FILLER_1_START = FILE_TRAILER_NEW_IND_START + FILE_TRAILER_NEW_IND_LENGTH;
		private static final int FILE_TRAILER_FILLER_1_LENGTH = FILE_HEADER_FILLER_1_LENGTH;
		private static final int FILE_TRAILER_CHG_IND_START = FILE_TRAILER_FILLER_1_START + FILE_TRAILER_FILLER_1_LENGTH;
		private static final int FILE_TRAILER_CHG_IND_LENGTH = FILE_HEADER_CHG_IND_LENGTH;
		private static final int FILE_TRAILER_FILLER_2_START = FILE_TRAILER_CHG_IND_START + FILE_TRAILER_CHG_IND_LENGTH;
		private static final int FILE_TRAILER_FILLER_2_LENGTH = FILE_HEADER_FILLER_2_LENGTH;
		private static final int FILE_TRAILER_NUM_ROUTES_START = FILE_TRAILER_FILLER_2_START + FILE_TRAILER_FILLER_2_LENGTH;
		private static final int FILE_TRAILER_NUM_ROUTES_LENGTH = FILE_HEADER_NUM_ROUTES_LENGTH;
		private static final int FILE_TRAILER_NUM_CUSTOMERS_START = FILE_TRAILER_NUM_ROUTES_START + FILE_TRAILER_NUM_ROUTES_LENGTH;
		private static final int FILE_TRAILER_NUM_CUSTOMERS_LENGTH = FILE_HEADER_NUM_CUSTOMERS_LENGTH;
		private static final int FILE_TRAILER_NUM_METERS_START = FILE_TRAILER_NUM_CUSTOMERS_START + FILE_TRAILER_NUM_CUSTOMERS_LENGTH;
		private static final int FILE_TRAILER_NUM_METERS_LENGTH = FILE_HEADER_NUM_METERS_LENGTH;
		private static final int FILE_TRAILER_NUM_READINGS_START = FILE_TRAILER_NUM_METERS_START + FILE_TRAILER_NUM_METERS_LENGTH;
		private static final int FILE_TRAILER_NUM_READINGS_LENGTH = FILE_HEADER_NUM_READINGS_LENGTH;
		private static final int FILE_TRAILER_ERH_FMT_START = FILE_TRAILER_NUM_READINGS_START + FILE_TRAILER_NUM_READINGS_LENGTH;
		private static final int FILE_TRAILER_ERH_FMT_LENGTH = FILE_HEADER_ERH_FMT_LENGTH;
		private static final int FILE_TRAILER_FILLER_3_START = FILE_TRAILER_ERH_FMT_START + FILE_TRAILER_ERH_FMT_LENGTH;
		private static final int FILE_TRAILER_FILLER_3_LENGTH = FILE_HEADER_FILLER_3_LENGTH;
		@SuppressWarnings("unused")
		private static final int FILE_TRAILER_NUM_RECORDS_START = FILE_TRAILER_FILLER_3_START + FILE_TRAILER_FILLER_3_LENGTH;
		@SuppressWarnings("unused")
		private static final int FILE_TRAILER_NUM_RECORDS_LENGTH = FILE_HEADER_NUM_RECORDS_LENGTH;

		// Other Constants
		@SuppressWarnings("unused")
		private static final String ROUTE_TYPE_AMR = "A";
		private static final String ROUTE_TYPE_OMR = "O";
		@SuppressWarnings("unused")
		private static final String ROUTE_TYPE_SUCCESSION = "S";
		private static final String YES_CHAR = "Y";
		private static final String NO_CHAR = "N";
		private static final String READ_METHOD_RADIO = "R";
		@SuppressWarnings("unused")
		private static final String READ_METHOD_KEYPUNCH = "K";
		private static final String READ_CODE_NORMAL = "N";
		@SuppressWarnings("unused")
		private static final String READ_CODE_MISSED = " ";
		private static final String READ_CODE_SKIPPED_WITH_REASON = "S";
		//Start Add-2018-05-23-DarrylH -sa225593
		private static final String READ_CODE_SKIPPED_WITH_REASON_TEXT = "QR";
		//End Add-2018-05-23-DarrylH - sa225593
		private static final String ITRON_DATE_FORMAT = "MMddyyyy";
		private static final String ITRON_TIME_FORMAT = "HHmmss";
		private static final String ITRON_DATE_TIME_FORMAT = ITRON_DATE_FORMAT.concat(ITRON_TIME_FORMAT);
		private static final String ROUTE_CUSTOMERS = "Route Customers";
		private static final String ROUTE_METERS = "Route Meters";
		private static final String ROUTE_METER_READS = "Route Meter Reads";
		private static final String ROUTE_SKIPPED_READS = "Route Skipped Reads";
		private static final String ROUTE_MISSED_READS = "Route Missed Reads";
		private static final String ROUTE_RADIO_READS = "Route Radio Reads";
		private static final String TOTAL_ROUTE_HEADERS = "Total Route Headers";
		private static final String TOTAL_CUSTOMERS = "Total Customers";
		private static final String TOTAL_METERS = "Total Meters";
		private static final String TOTAL_METER_READS = "Total Meter Reads";
		private static final String TOTAL_RECORDS = "Total Records";
		private static final String TOTAL_ROUTE_TRAILERS = "Total Route Trailers";
		private static final String METERS_AT_CUSTOMER = "Meters At Customer";
		private static final String READS_AT_METER = "Reads At Meter";
		private static final String ITRON_NUMBER = "Itron Number";
		private static final String ITRON_DATE = "Itron Date";
		private static final String ITRON_DATETIME = "Itron Date Time";

		// Local variables
		private String fullFileNameItron;
		private File fileItron;
		private BufferedReader bufferedReaderItron;
		private String currentItronRecord = "";
		private String currentRecId = "";
		private String currentCycle = "";
		private String currentRouteType = "";
		private String currentRouteId = "";
		private String currentRouteInfo = "";
		private Date currentScheduledDate;
		private Boolean resequenceFlag = false;
		private String currentBadgeNbr = "";
		@SuppressWarnings("unused")
		private BigInteger currentReadSeq = BigInteger.ZERO;
		private BigInteger currentNewSeq = BigInteger.ZERO;
		private String currentMeterConfig = "";
		private String currentTamperCode = "";
		private MeterConfiguration_Id currentMeterConfigId = null;
		@SuppressWarnings("unused")
		private String currentMeterMfg = "";
		private int currentReadOrder = 0;
		private String currentReaderId = "";
		@SuppressWarnings("unused")
		private String currentCCBPremId = "";
		private BigDecimal currentReading = null;
		private DateTime currentReadingDateTime = this.getProcessDateTime();
		private ReadTypeLookup currentReadType = ReadTypeLookup.constants.REGULAR;
		private String currentItronReadCode = "";
		private MeterReadUpload_Id mrStageId = null;
		private Boolean errorWithReading = false;
		private Boolean errorWithMeter = false;
		private Boolean uploadSuccessful = true;
		private MeterReadSource_Id defaultReadSource = null;
		private UnitOfMeasure_Id defaultUnitOfMeasure = null;
		private CharacteristicType tamperCharType = null;
		private CharacteristicType skipReasonCharType = null;
		private int displayLoggerCount = 0;

		// Record counts, both expected (passed in Itron file) and actual (tracked in program)
		private int recordsProcessed = 0;
		private int recordsInError = 0;
		private int recordsExpTotal = 0;
		private int recordsActTotal = 0;
		private int recordsExpRoutes = 0;
		private int recordsActRouteHeaders = 0;
		private int recordsExpTotalCustomers = 0;
		private int recordsActTotalCustomers = 0;
		private int recordsExpRouteCustomers = 0;
		private int recordsActRouteCustomers = 0;
		private int recordsExpMetersAtCustomer = 0;
		private int recordsActMetersAtCustomer = 0;
		private int recordsExpTotalMeters = 0;
		private int recordsActTotalMeters = 0;
		private int recordsExpTotalExtraMeters = 0;
		private int recordsActTotalExtraMeters = 0;
		private int recordsExpTotalSpecialTextMeters = 0;
		private int recordsActTotalSpecialTextMeters = 0;
		private int recordsExpRouteMeters = 0;
		private int recordsActRouteMeters = 0;
		private int recordsExpRouteExtraMeters = 0;
		private int recordsActRouteExtraMeters = 0;
		private int recordsExpRouteSpecialTextMeters = 0;
		private int recordsActRouteSpecialTextMeters = 0;
		private int recordsExpReadsAtMeter = 0;
		private int recordsActReadsAtMeter = 0;
		private int recordsActTotalMeterChanges = 0;
		private int recordsExpTotalMeterReads = 0;
		private int recordsActTotalMeterReads = 0;
		private int recordsExpRouteMeterReads = 0;
		private int recordsActRouteMeterReads = 0;
		private int recordsExpRouteMissedReads = 0;
		private int recordsActRouteMissedReads = 0;
		private int recordsExpRouteSkippedReads = 0;
		private int recordsActRouteSkippedReads = 0;
		private int recordsExpRouteRadioReads = 0;
		private int recordsActRouteRadioReads = 0;
		private int recordsExpRadioAtReads = 0;
		private int recordsActRadioAtReads = 0;
		private int recordsActRouteTrailers = 0;

		// Upload counts
		private int readingsUploaded = 0;
		private int readingsInError = 0;
		private int readingsErrorRecord = 0;
		private int readingsErrorDuplicate = 0;
		private int readingsErrorLoading = 0;

		// Logger Messages
		private static Logger logger = LoggerFactory.getLogger(CmITRONMeterReadUploadBatchWorker.class);

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
			// Get soft parameters
			cmGetParameters();

			// Open Itron input file
			cmOpenItronInputFile();

			// Read file header record - always the first record of the file
			cmProcessItronFileHeaderRecord();

			// Priming read for process (which is actually second record on the file)
			currentItronRecord = cmReadItronInputFile();
		}

		private void cmGetParameters() {

			String parmFilePath = this.getParameters().getFILE_PATH().trim();
			String parmFileName = this.getParameters().getFILE_NAME().trim();
			MeterReadSource parmReadSource = this.getParameters().getREAD_SOURCE();
			UnitOfMeasure parmUnitOfMeasure = this.getParameters().getUOM_CD();
			CharacteristicType parmTamperCharType = this.getParameters().getTAMPER_CHAR_TYPE();
			CharacteristicType parmSkipReasonCharType = this.getParameters().getSKIP_REASON_CHAR_TYPE();
			String parmDisplayProgressNum = this.getParameters().getDISPLAY_PROGRESS_NUM();

			fullFileNameItron = parmFilePath.trim().concat(parmFileName.trim());
			defaultReadSource = parmReadSource.getId();
			defaultUnitOfMeasure = parmUnitOfMeasure.getId();
			tamperCharType = parmTamperCharType;
			skipReasonCharType = parmSkipReasonCharType;

			if (!(parmDisplayProgressNum == null)) {
				if (!(parmDisplayProgressNum.length() == 0)) {
					displayLoggerCount = Integer.parseInt(parmDisplayProgressNum);
				} else {
					displayLoggerCount = 0;
				}
			} else {
				displayLoggerCount = 0;
			}
		}

		private void cmOpenItronInputFile() {
			// Open file
			try {
				fileItron = new File(fullFileNameItron);
				bufferedReaderItron = new BufferedReader(new FileReader(fileItron));
			} catch (IOException e) {
				throw new RunAbortedException(CustomMessageRepositoryMGE.commGenericErrorOpeningFile(fullFileNameItron));
			}
		}

	    private String cmReadItronInputFile(){
	    	// Temporary storage for read line
	    	String recordLine;

	    	// Read line from file
	        try {
	            recordLine = bufferedReaderItron.readLine();
	        }
	        catch(IOException e) {
	        	// need new error message for read, not write
				throw new RunAbortedException(CustomMessageRepositoryMGE.ccb002ErrorReadingFile(fullFileNameItron));
	        }

	        // Make sure we are not at the end of the file
	        if (notNull(recordLine)) {
		        // Pad any missing spaces to the right so the record length is always consistent
		        if (recordLine.length() < ITRON_FILE_LENGTH) {
		        	// Concatenate spaces
		        	recordLine = recordLine.concat(String.format("%" + (ITRON_FILE_LENGTH - recordLine.length()) + "s", ""));
		        }

		        recordsActTotal++;

		        // Set the record type
		        currentRecId = cmGetItronString(recordLine, COMMON_REC_ID_START, COMMON_REC_ID_LENGTH);

		        // Display record information
				if (displayLoggerCount > 0) {
					if (recordsActTotal % displayLoggerCount == 0) {
						logger.info("\n *** Processing Type "+currentRecId+" Record Number             |"+recordsActTotal+"|");
					}
				}
	        } else {
	        	// End of file
	        	currentRecId = "";
	        }

	        return recordLine;
	    }

	    private void cmCloseItronInputFile(){
	    	// Close file
	        try {
	        	bufferedReaderItron.close();
	        }
	        catch(IOException e) {
				throw new RunAbortedException(CustomMessageRepositoryMGE.commGenericErrorClosingFile(fullFileNameItron));
	        }
	    }

	    public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
	    throws ThreadAbortedException, RunAbortedException {
	    	// create work unit
	    	WorkUnitResult results = new WorkUnitResult(true);

			// Loop through all the records in the file
			while (notNull(currentItronRecord)) {
				// Evaluate record type to determine course of action
				if (currentRecId.compareTo(REC_ID_ROUTE_HEADER) == 0) {
					// Process route header record
					cmProcessItronRouteHeaderRecord();

				} else if (currentRecId.compareTo(REC_ID_CUSTOMER) == 0) {
					// Process customer record
					cmProcessItronCustomerRecord();

				} else if (currentRecId.compareTo(REC_ID_METER) == 0) {
					// Process meter record
					cmProcessItronMeterRecord();

				} else if (currentRecId.compareTo(REC_ID_METER_EXTRA) == 0) {
					// Process meter extra record
					cmProcessItronMeterExtraRecord();

				} else if (currentRecId.compareTo(REC_ID_METER_SPECIAL_TEXT) == 0) {
					// Process meter special text record
					cmProcessItronMeterSpecialTextRecord();

				} else if (currentRecId.compareTo(REC_ID_METER_CHANGE) == 0) {
					// Process meter change record
					cmProcessItronMeterChangeRecord();

				} else if (currentRecId.compareTo(REC_ID_READ) == 0) {
					// Process reading
					cmProcessItronReadRecord();

				} else if (currentRecId.compareTo(REC_ID_RADIO) == 0) {
					// Process ERT information
					cmProcessItronRadioRecord();

				} else if (currentRecId.compareTo(REC_ID_ROUTE_TRAILER) == 0) {
					// Process route trailer record
					cmProcessItronRouteTrailerRecord();

				} else if (currentRecId.compareTo(REC_ID_FILE_TRAILER) == 0) {
					// Process file trailer record
					cmProcessItronFileTrailerRecord();

				} else {
					// Unknown record
					addWarning(CustomMessageRepositoryMGE.ccb002InvalidRecord(currentRecId.trim(), String.valueOf(recordsActTotal)));
					recordsInError++;
				}

				// Get next record
				currentItronRecord = cmReadItronInputFile();
			}

	    	// Results will reflect the number of readings uploaded to the staging tables and how many did not make it
			// Results holds the logical amount of work instead of the actual number of records in the file
			results.setUnitsInError(readingsInError);
	    	results.setUnitsProcessed(readingsUploaded);

	    	return results;
	    }

		private void cmProcessItronFileHeaderRecord() {
			// Read the File Header Record (since it is the first record in the file)
			currentItronRecord = cmReadItronInputFile();

			// Make sure it is a file header record
			if (!(currentRecId.compareTo(REC_ID_FILE_HEADER) == 0)) {
				throw new RunAbortedException(CustomMessageRepositoryMGE.ccb002RecordNotFound(REC_ID_FILE_HEADER, String.valueOf(recordsActTotal)));
			}

			// Set the expected totals for the file from the file header
			recordsExpRoutes = cmGetItronNumber(currentItronRecord, FILE_HEADER_NUM_ROUTES_START, FILE_HEADER_NUM_ROUTES_LENGTH);
			recordsExpTotalCustomers = cmGetItronNumber(currentItronRecord, FILE_HEADER_NUM_CUSTOMERS_START, FILE_HEADER_NUM_CUSTOMERS_LENGTH);
			recordsExpTotalMeters = cmGetItronNumber(currentItronRecord, FILE_HEADER_NUM_METERS_START, FILE_HEADER_NUM_METERS_LENGTH);
			recordsExpTotalMeterReads = cmGetItronNumber(currentItronRecord, FILE_HEADER_NUM_READINGS_START, FILE_HEADER_NUM_READINGS_LENGTH);
			recordsExpTotal = cmGetItronNumber(currentItronRecord, FILE_HEADER_NUM_RECORDS_START, FILE_HEADER_NUM_RECORDS_LENGTH);

			recordsProcessed++;
		}

		private void cmProcessItronRouteHeaderRecord() {
			// Set the route information
			currentCycle = cmGetItronString(currentItronRecord, COMMON_CYCLE_START, COMMON_CYCLE_LENGTH);
			currentRouteType = cmGetItronString(currentItronRecord, COMMON_ROUTE_TYPE_START, COMMON_ROUTE_TYPE_LENGTH);
			currentRouteId = cmGetItronString(currentItronRecord, COMMON_ROUTE_ID_START, COMMON_ROUTE_ID_LENGTH);
			currentRouteInfo = cmGetItronString(currentItronRecord, ROUTE_HEADER_ROUTE_NUM_START, ROUTE_HEADER_ROUTE_NUM_LENGTH);

			// Determine if we received resequence information (for OMR handheld routes only)
			if (currentRouteType.compareTo(ROUTE_TYPE_OMR) == 0 &&
				cmGetItronString(currentItronRecord, ROUTE_HEADER_RESEQ_IND_START, ROUTE_HEADER_RESEQ_IND_LENGTH).compareTo(YES_CHAR) == 0 &&
				cmGetItronString(currentItronRecord, ROUTE_HEADER_SEQ_IND_START, ROUTE_HEADER_SEQ_IND_LENGTH).compareTo(NO_CHAR) == 0) {
				resequenceFlag = true;
			} else {
				resequenceFlag = false;
			}

			// Get the scheduled read date of this route
			currentScheduledDate = cmGetItronDate(currentItronRecord, ROUTE_HEADER_SCH_READ_START, ROUTE_HEADER_SCH_READ_LENGTH);

			// Set the expected totals for this route and initialize the actual totals for the route
			recordsExpRouteCustomers = cmGetItronNumber(currentItronRecord, ROUTE_HEADER_NUM_CUSTOMER_RECS_START, ROUTE_HEADER_NUM_CUSTOMER_RECS_LENGTH);
			recordsActRouteCustomers = 0;
			recordsExpRouteMeters = cmGetItronNumber(currentItronRecord, ROUTE_HEADER_NUM_METER_RECS_START, ROUTE_HEADER_NUM_METER_RECS_LENGTH);
			recordsActRouteMeters = 0;
			recordsActRouteExtraMeters = 0;
			recordsExpRouteMeterReads = cmGetItronNumber(currentItronRecord, ROUTE_HEADER_NUM_READ_RECS_START, ROUTE_HEADER_NUM_READ_RECS_LENGTH);
			recordsActRouteMeterReads = 0;
			recordsExpRouteMissedReads = cmGetItronNumber(currentItronRecord, ROUTE_HEADER_NUM_MISSED_START, ROUTE_HEADER_NUM_MISSED_LENGTH);
			recordsActRouteMissedReads = 0;
			recordsExpRouteSkippedReads = cmGetItronNumber(currentItronRecord, ROUTE_HEADER_NUM_SKIPPED_START, ROUTE_HEADER_NUM_SKIPPED_LENGTH);
			recordsActRouteSkippedReads = 0;
			recordsExpRouteRadioReads = cmGetItronNumber(currentItronRecord, ROUTE_HEADER_NUM_OS_READS_START, ROUTE_HEADER_NUM_OS_READS_LENGTH);
			recordsActRouteRadioReads = 0;

			// Display Route Information
			if (displayLoggerCount > 0) {
	        	logger.info("\n *** Route Cycle                                   |"+currentCycle+"|");
	        	logger.info("\n *** Route Type                                    |"+currentRouteType+"|");
	        	logger.info("\n *** Route Number                                  |"+currentRouteId+"|");
	        	logger.info("\n *** Resequence                                    |"+resequenceFlag+"|");
	        	logger.info("\n *** Scheduled Read                                |"+currentScheduledDate+"|");
			}

        	// Update counters
			recordsActRouteHeaders++;
			recordsProcessed++;
		}

		private void cmProcessItronCustomerRecord() {
			// Reset error flags
			errorWithMeter = false;
			errorWithReading = false;

			// Make sure route information is the expected values for this record
			cmValidRouteInfo();

			// Get CC&B Premise Id
			currentCCBPremId = cmGetItronString(currentItronRecord, CUSTOMER_CCB_PREM_ID_START, CUSTOMER_CCB_PREM_ID_LENGTH);

			// Make sure all the meters for the previous customer were all processed
			cmValidNumberMetersAtCustomer();

			// Get the number of meters expected for this customer
			recordsExpMetersAtCustomer = cmGetItronNumber(currentItronRecord, CUSTOMER_NUM_METERS_START, CUSTOMER_NUM_METERS_LENGTH);
			recordsActMetersAtCustomer = 0;

			// Update counters
			recordsActTotalCustomers++;
			recordsActRouteCustomers++;
			recordsProcessed++;
		}

		private void cmProcessItronMeterRecord() {
			// Reset error flags
			errorWithMeter = false;
			errorWithReading = false;

			// Make sure route information is the expected values for this record
			cmValidRouteInfo();

			// Make sure all the readings for the last meter were all processed
			cmValidNumberReadsAtMeter();

			// Get the number of readings expected at this meter
			recordsExpReadsAtMeter = cmGetItronNumber(currentItronRecord, METER_NUM_READS_START, METER_NUM_READS_LENGTH);
			recordsActReadsAtMeter = 0;

			// Get meter information
			currentBadgeNbr = cmGetItronString(currentItronRecord, METER_NUMBER_START, METER_NUMBER_LENGTH);

			if (currentBadgeNbr.length() == 0) {
				// Skip this meter read because of invalid badge number
				errorWithMeter = true;
				addWarning(CustomMessageRepositoryMGE.ccb002InvalidBadgeNumber(currentBadgeNbr.trim(), String.valueOf(recordsActTotal)));
			}

			// get meter sequence
			currentReadSeq = BigInteger.valueOf(cmGetItronNumber(currentItronRecord, METER_READ_SEQ_START, METER_READ_SEQ_LENGTH));

			// get meter resequence
			currentNewSeq = BigInteger.valueOf(cmGetItronNumber(currentItronRecord, METER_NEW_SEQ_START, METER_NEW_SEQ_LENGTH));

			// get meter configuration id
			currentMeterConfig = cmGetItronString(currentItronRecord, METER_CCB_MTR_CONFIG_ID_START, METER_CCB_MTR_CONFIG_ID_LENGTH);

			if (currentMeterConfig.length() == 0) {
				// Skip this meter read because of invalid meter configuation id
				currentMeterConfigId = null;
				errorWithMeter = true;
				addWarning(CustomMessageRepositoryMGE.ccb002InvalidMeterConfig(currentMeterConfig.trim(), String.valueOf(recordsActTotal)));
			} else {
				// populate meter configuration id
				currentMeterConfigId = new MeterConfiguration_Id(currentMeterConfig);
				
				// Start Change 46635 JRGoco
				// Retrieve UOM of read sequence 1 
				for (Register each : currentMeterConfigId.getEntity().getRegisters()) {
					if (each.getSeq().compareTo(BigInteger.ONE) == 0 ){
						// Set the default UOM to Register 1 UOM
						defaultUnitOfMeasure = each.getUnitOfMeasure().getId();						
					}
				}
				// End Change 46635 JRGoco					
				
			}

			// get meter manufacturer
			currentMeterMfg = cmGetItronString(currentItronRecord, METER_CCB_MANUFACTURER_START, METER_CCB_MANUFACTURER_LENGTH);

			// See if a meter special text record is included
			if (cmGetItronString(currentItronRecord, METER_DISP_IND_START, METER_DISP_IND_LENGTH).compareTo(YES_CHAR) == 0) {
				recordsExpTotalSpecialTextMeters++;
				recordsExpRouteSpecialTextMeters++;
			}

			// See if a meter extra record is included
			if (cmGetItronString(currentItronRecord, METER_MTX_IND_START, METER_MTX_IND_LENGTH).compareTo(YES_CHAR) == 0) {
				recordsExpTotalExtraMeters++;
				recordsExpRouteExtraMeters++;
			}

			// Update counters
			recordsActMetersAtCustomer++;
			recordsActTotalMeters++;
			recordsActRouteMeters++;

			// Update records processed
			cmUpdateRecordsProcessed();
		}

		private void cmProcessItronMeterExtraRecord() {
			// Make sure route information is the expected values for this record
			cmValidRouteInfo();

			// Update counters
			recordsActRouteExtraMeters++;
			recordsActTotalExtraMeters++;

			// Update records processed
			cmUpdateRecordsProcessed();
		}

		private void cmProcessItronMeterSpecialTextRecord() {
			// Make sure route information is the expected values for this record
			cmValidRouteInfo();

			// Update counters
			recordsActRouteSpecialTextMeters++;
			recordsActTotalSpecialTextMeters++;

			// Update records processed
			cmUpdateRecordsProcessed();
		}

		private void cmProcessItronMeterChangeRecord() {
			// Make sure route information is the expected values for this record
			cmValidRouteInfo();

			// Update counters
			recordsActTotalMeterChanges++;

			// This functionality is currently not in use
			addWarning(CustomMessageRepositoryMGE.ccb002InvalidRecord(currentRecId.trim(), String.valueOf(recordsActTotal)));
			recordsInError++;
			//recordsProcessed++;
		}

		private void cmProcessItronReadRecord() {
			// Reset reading error flag
			errorWithReading = false;

			// Make sure route information is the expected values for this record
			cmValidRouteInfo();

			// Initialize read code
			currentItronReadCode = "";

			// Determine if regular read, missed read or skip read
			//Start Change-2018-05-23-DarrylH -sa225593
			if (   (cmGetItronString(currentItronRecord, READ_CODE_START, READ_CODE_LENGTH).compareTo(READ_CODE_NORMAL) == 0)
				|| ((cmGetItronString(currentItronRecord, READ_CODE_START, READ_CODE_LENGTH).compareTo(READ_CODE_SKIPPED_WITH_REASON) == 0)
					&& (cmGetItronString(currentItronRecord, READ_REASON_START, READ_REASON_LENGTH).compareTo(READ_CODE_SKIPPED_WITH_REASON_TEXT) == 0))
					)
			//End Add-2018-05-23-DarrylH -sa225593
			{
				currentReadType = ReadTypeLookup.constants.REGULAR;
			} else {
				currentReadType = ReadTypeLookup.constants.NO_READ;
				if (cmGetItronString(currentItronRecord, READ_CODE_START, READ_CODE_LENGTH).compareTo(READ_CODE_SKIPPED_WITH_REASON) == 0) {
					currentItronReadCode = cmGetItronString(currentItronRecord, READ_REASON_START, READ_REASON_LENGTH);

					recordsActRouteSkippedReads++;
				} else {
					recordsActRouteMissedReads++;
				}
			}

			// Get reading information
			currentReading = new BigDecimal(String.valueOf(cmGetItronNumber(currentItronRecord, READ_CURRENT_READ_START, READ_CURRENT_READ_LENGTH)));
			currentReadingDateTime = cmGetItronDateTime(currentItronRecord, READ_DATE_START, READ_DATE_LENGTH, READ_TIME_START, READ_TIME_LENGTH);

			// Determine if there is a radio read (additional record) or manual read
			if (cmGetItronString(currentItronRecord, READ_METHOD_START, READ_METHOD_LENGTH).compareTo(READ_METHOD_RADIO) == 0) {
				recordsExpRadioAtReads = 1;
			} else {
				recordsExpRadioAtReads = 0;

				// This is the last record for this read since it was manual
				cmUploadMeterReading();
			}
			recordsActRadioAtReads = 0;

			// Update counters
			recordsActTotalMeterReads++;
			recordsActRouteMeterReads++;
			recordsActReadsAtMeter++;

			// Sequence number for reading upload
			currentReadOrder = recordsActReadsAtMeter;

			// Update records processed
			cmUpdateRecordsProcessed();
		}

		private void cmProcessItronRadioRecord() {
			// Make sure route information is the expected values for this record
			cmValidRouteInfo();

			// Update counters
			recordsActRouteRadioReads++;
			recordsActRadioAtReads++;

			// Get tamper code
			currentTamperCode = cmGetItronString(currentItronRecord, RADIO_TAMPER_START, RADIO_TAMPER_LENGTH);

			// There can only be a maximum of one Radio (ERT) record per reading
			if (recordsExpRadioAtReads == recordsActRadioAtReads) {
				cmUploadMeterReading();
			} else {
				throw new RunAbortedException(CustomMessageRepositoryMGE.ccb002InvalidRecord(currentRecId.trim(), String.valueOf(recordsActTotal)));
			}

			// Update records processed
			cmUpdateRecordsProcessed();
		}

		private void cmProcessItronRouteTrailerRecord() {
			// Make sure route information is the expected values for this record
			cmValidRouteInfo();

			// Make sure all the meters for the last customer of the route were all processed
			cmValidNumberMetersAtCustomer();

			// Make sure all the readings for the last meter of the route were all processed
			cmValidNumberReadsAtMeter();

			// Validate record counts for this route
			if (!(recordsExpRouteCustomers == recordsActRouteCustomers)) {
				addWarning(CustomMessageRepositoryMGE.ccb002ExpectedVsActualCount(String.valueOf(recordsExpRouteCustomers),
						ROUTE_CUSTOMERS, currentRecId.trim(), String.valueOf(recordsActRouteCustomers), String.valueOf(recordsActTotal)));
			} else if (!(recordsExpRouteMeters == recordsActRouteMeters)) {
				addWarning(CustomMessageRepositoryMGE.ccb002ExpectedVsActualCount(String.valueOf(recordsExpRouteMeters),
						ROUTE_METERS, currentRecId.trim(), String.valueOf(recordsActRouteMeters), String.valueOf(recordsActTotal)));
			} else if (!(recordsExpRouteMeterReads == recordsActRouteMeterReads)) {
				addWarning(CustomMessageRepositoryMGE.ccb002ExpectedVsActualCount(String.valueOf(recordsExpRouteMeterReads),
						ROUTE_METER_READS, currentRecId.trim(), String.valueOf(recordsActRouteMeterReads), String.valueOf(recordsActTotal)));
			} else if (!(recordsExpRouteSkippedReads == recordsActRouteSkippedReads)) {
				addWarning(CustomMessageRepositoryMGE.ccb002ExpectedVsActualCount(String.valueOf(recordsExpRouteSkippedReads),
						ROUTE_SKIPPED_READS, currentRecId.trim(), String.valueOf(recordsActRouteSkippedReads), String.valueOf(recordsActTotal)));
			} else if (!(recordsExpRouteMissedReads == recordsActRouteMissedReads)) {
				addWarning(CustomMessageRepositoryMGE.ccb002ExpectedVsActualCount(String.valueOf(recordsExpRouteMissedReads),
						ROUTE_MISSED_READS, currentRecId.trim(), String.valueOf(recordsActRouteMissedReads), String.valueOf(recordsActTotal)));
			} else if (!(recordsExpRouteRadioReads == recordsActRouteRadioReads)) {
				addWarning(CustomMessageRepositoryMGE.ccb002ExpectedVsActualCount(String.valueOf(recordsExpRouteRadioReads),
						ROUTE_RADIO_READS, currentRecId.trim(), String.valueOf(recordsActRouteRadioReads), String.valueOf(recordsActTotal)));
			}

			// Display totals for route
			if (displayLoggerCount > 0) {
	        	logger.info("\n *** Expected Customers For Route                  |"+recordsExpRouteCustomers+"|");
	        	logger.info("\n *** Actual Customers For Route                    |"+recordsActRouteCustomers+"|");
	        	logger.info("\n *** Expected Meters For Route                     |"+recordsExpRouteMeters+"|");
	        	logger.info("\n *** Actual Meters For Route                       |"+recordsActRouteMeters+"|");
	        	logger.info("\n *** Expected Extra Meter Recs For Route           |"+recordsExpRouteExtraMeters+"|");
	        	logger.info("\n *** Actual Extra Meter Recs For Route             |"+recordsActRouteExtraMeters+"|");
	        	logger.info("\n *** Expected Special Text Meter Recs For Route    |"+recordsExpRouteSpecialTextMeters+"|");
	        	logger.info("\n *** Actual Special Text Meter Recs For Route      |"+recordsActRouteSpecialTextMeters+"|");
	        	logger.info("\n *** Expected Meter Readings For Route             |"+recordsExpRouteMeterReads+"|");
	        	logger.info("\n *** Actual Meter Readings For Route               |"+recordsActRouteMeterReads+"|");
	        	logger.info("\n *** Expected Skipped Readings For Route           |"+recordsExpRouteSkippedReads+"|");
	        	logger.info("\n *** Actual Skipped Readings For Route             |"+recordsActRouteSkippedReads+"|");
	        	logger.info("\n *** Expected Missed Readings For Route            |"+recordsExpRouteMissedReads+"|");
	        	logger.info("\n *** Actual Missed Readings For Route              |"+recordsActRouteMissedReads+"|");
	        	logger.info("\n *** Expected Radio Reads For Route                |"+recordsExpRouteRadioReads+"|");
	        	logger.info("\n *** Actual Radio Reads For Route                  |"+recordsActRouteRadioReads+"|");
			}

			// Update counters
			recordsActRouteTrailers++;
			recordsProcessed++;
		}

		private void cmProcessItronFileTrailerRecord() {
			// Validate record counts for this file
			if (!(recordsExpRoutes == recordsActRouteHeaders)) {
				addWarning(CustomMessageRepositoryMGE.ccb002ExpectedVsActualCount(String.valueOf(recordsExpRoutes),
						TOTAL_ROUTE_HEADERS, currentRecId.trim(), String.valueOf(recordsActRouteHeaders), String.valueOf(recordsActTotal)));
			} else if (!(recordsExpTotalCustomers == recordsActTotalCustomers)) {
				addWarning(CustomMessageRepositoryMGE.ccb002ExpectedVsActualCount(String.valueOf(recordsExpTotalCustomers),
						TOTAL_CUSTOMERS, currentRecId.trim(), String.valueOf(recordsActTotalCustomers), String.valueOf(recordsActTotal)));
			} else if (!(recordsExpTotalMeters == recordsActTotalMeters)) {
				addWarning(CustomMessageRepositoryMGE.ccb002ExpectedVsActualCount(String.valueOf(recordsExpTotalMeters),
						TOTAL_METERS, currentRecId.trim(), String.valueOf(recordsActTotalMeters), String.valueOf(recordsActTotal)));
			} else if (!(recordsExpTotalMeterReads == recordsActTotalMeterReads)) {
				addWarning(CustomMessageRepositoryMGE.ccb002ExpectedVsActualCount(String.valueOf(recordsExpTotalMeterReads),
						TOTAL_METER_READS, currentRecId.trim(), String.valueOf(recordsActTotalMeterReads), String.valueOf(recordsActTotal)));
			} else if (!(recordsExpTotal == recordsActTotal)) {
				addWarning(CustomMessageRepositoryMGE.ccb002ExpectedVsActualCount(String.valueOf(recordsExpTotal),
						TOTAL_RECORDS, currentRecId.trim(), String.valueOf(recordsActTotal), String.valueOf(recordsActTotal)));
			} else if (!(recordsExpRoutes == recordsActRouteTrailers)) {
				addWarning(CustomMessageRepositoryMGE.ccb002ExpectedVsActualCount(String.valueOf(recordsExpRoutes),
						TOTAL_ROUTE_TRAILERS, currentRecId.trim(), String.valueOf(recordsActRouteTrailers), String.valueOf(recordsActTotal)));
			}

			// Display totals for file
			if (displayLoggerCount > 0) {
		       	logger.info("\n *** Expected Route Headers                        |"+recordsExpRoutes+"|");
		       	logger.info("\n *** Actual Route Headers                          |"+recordsActRouteHeaders+"|");
		       	logger.info("\n *** Expected Total Customers                      |"+recordsExpTotalCustomers+"|");
		       	logger.info("\n *** Actual Total Customers                        |"+recordsActTotalCustomers+"|");
		       	logger.info("\n *** Expected Total Meters                         |"+recordsExpTotalMeters+"|");
		       	logger.info("\n *** Actual Total Meters                           |"+recordsActTotalMeters+"|");
		       	logger.info("\n *** Expected Total Extra Meter Records            |"+recordsExpTotalExtraMeters+"|");
		       	logger.info("\n *** Actual Total Extra Meter Records              |"+recordsActTotalExtraMeters+"|");
		       	logger.info("\n *** Expected Total Special Text Meter Records     |"+recordsExpTotalSpecialTextMeters+"|");
		       	logger.info("\n *** Actual Total Special Text Meter Records       |"+recordsActTotalSpecialTextMeters+"|");
		       	logger.info("\n *** Expected Total Meter Reads                    |"+recordsExpTotalMeterReads+"|");
		       	logger.info("\n *** Actual Total Meter Reads                      |"+recordsActTotalMeterReads+"|");
		       	logger.info("\n *** Expected Total Records                        |"+recordsExpTotal+"|");
		       	logger.info("\n *** Actual Total Records                          |"+recordsActTotal+"|");
		       	logger.info("\n *** Expected Route Trailers                       |"+recordsExpRoutes+"|");
		       	logger.info("\n *** Actual Route Trailers                         |"+recordsActRouteTrailers+"|");
			}

			// Update counters
			recordsProcessed++;
		}
		private void cmUpdateRecordsProcessed() {
			// Update either the record as processed or in error based on flags

			if (errorWithMeter || errorWithReading) {
				recordsInError++;
			} else {
				recordsProcessed++;
			}
		}

		private void cmValidRouteInfo() {
			// Make sure the cycle, route type and/or route number have not changed unexpectedly
			if (!(currentRouteInfo.compareTo(cmGetItronString(currentItronRecord, COMMON_ROUTE_INFO_START, COMMON_ROUTE_INFO_LENGTH)) == 0)) {
				recordsInError++;
				throw new RunAbortedException(CustomMessageRepositoryMGE.ccb002InvalidRouteInfo(currentRouteInfo.trim(), String.valueOf(recordsActTotal)));
			}
		}

		private void cmValidNumberMetersAtCustomer() {
			// Make sure all meters for the customer have been processed
			if (!(recordsExpMetersAtCustomer == recordsActMetersAtCustomer)) {
				addWarning(CustomMessageRepositoryMGE.ccb002ExpectedVsActualCount(String.valueOf(recordsExpMetersAtCustomer),
						METERS_AT_CUSTOMER, currentRecId.trim(), String.valueOf(recordsActMetersAtCustomer), String.valueOf(recordsActTotal)));
			}
		}

		private void cmValidNumberReadsAtMeter() {
			// Make sure all reads for the meter have been processed
			if (!(recordsExpReadsAtMeter == recordsActReadsAtMeter)) {
				addWarning(CustomMessageRepositoryMGE.ccb002ExpectedVsActualCount(String.valueOf(recordsExpReadsAtMeter),
						READS_AT_METER, currentRecId.trim(), String.valueOf(recordsActReadsAtMeter), String.valueOf(recordsActTotal)));
			}
		}

        private String cmGetItronString(String fileRecord, int startPos, int length){
        	// Returns an Itron string field based on the starting position and length of the field in the fixed width format

        	// Java string pointer starts at 0, not 1
            startPos--;

            // Calculate end position
            int endPos = startPos + length;

            // Record has been verified to at least have spaces in all fields
            return fileRecord.substring(startPos, endPos).trim();
        }

        private int cmGetItronNumber(String fileRecord, int startPos, int length){
        	// Returns an integer based on an Itron numeric field with the starting position and length of the field in the fixed width format
        	int numberValue = 0;
        	String stringValue = cmGetItronString(fileRecord, startPos, length);

        	// Returns a zero if there was only blanks in the field
        	if (!(stringValue.length() == 0)) {
            	// Attempt to convert the string to an integer
            	try {
            		numberValue = Integer.parseInt(stringValue);
            	}
            	catch (NumberFormatException e) {
            		throw new RunAbortedException(CustomMessageRepositoryMGE.ccb002InvalidItronElement(ITRON_NUMBER, stringValue,
    						String.valueOf(startPos), String.valueOf(length), String.valueOf(recordsActTotal)));
            	}
        	}

        	return numberValue;
        }

        private Date cmGetItronDate(String fileRecord, int startPos, int length){
        	// Returns a date based on an Itron date field with the starting position and length of the field in the fixed width format
         	Date dateValue = this.getProcessDateTime().getDate();
         	String stringValue = cmGetItronString(fileRecord, startPos, length);

         	// Set the format
        	DateFormat dateFormat = new DateFormat(ITRON_DATE_FORMAT);

        	// Error if the date is not completely filled in
        	if (stringValue.length() == length) {
             	// Attempt to convert the string to a date
            	try {
            		dateValue = dateFormat.parseDate(stringValue);
            	}
            	catch (DateFormatParseException e) {
            		throw new RunAbortedException(CustomMessageRepositoryMGE.ccb002InvalidItronElement(ITRON_DATE, stringValue,
    						String.valueOf(startPos), String.valueOf(length), String.valueOf(recordsActTotal)));
            	}
        	} else {
				addWarning(CustomMessageRepositoryMGE.ccb002InvalidItronElement(ITRON_DATE, stringValue,
						String.valueOf(startPos), String.valueOf(length), String.valueOf(recordsActTotal)));
        	}

        	return dateValue;
        }

        private DateTime cmGetItronDateTime(String fileRecord, int startPosDate, int lengthDate, int startPosTime, int lengthTime){
        	// Returns a date based on Itron date and time fields with the starting position and length of each field in the fixed width format
         	DateTime dateTimeValue = this.getProcessDateTime();
         	String stringDateValue = cmGetItronString(fileRecord, startPosDate, lengthDate);
         	String stringTimeValue = cmGetItronString(fileRecord, startPosTime, lengthTime);

         	// Set the format
        	DateFormat dateTimeFormat = new DateFormat(ITRON_DATE_TIME_FORMAT);
        	DateFormat dateFormat = new DateFormat(ITRON_DATE_FORMAT);

         	// Only in the case of missed reads, we need to use the route scheduled date since no date is provided
         	if ((stringDateValue.compareTo(String.format("%" + lengthDate + "s", "").replace(' ', '0')) == 0) &&
         		(currentRecId.compareTo(REC_ID_READ) == 0) &&
         		(startPosDate == READ_DATE_START) &&
         		(currentReadType.isNoRead())) {

         		stringDateValue = currentScheduledDate.toString(dateFormat);
          	}

        	// Error if either date or time is not filled in
        	if (stringDateValue.length() == lengthDate) {
        		if (stringTimeValue.length() == lengthTime) {
                 	// Attempt to convert the string to a date time
                	try {
                		dateTimeValue = dateTimeFormat.parseDateTime(stringDateValue.concat(stringTimeValue));
                	}
                	catch (DateFormatParseException e) {
                		throw new RunAbortedException(CustomMessageRepositoryMGE.ccb002InvalidItronElement(ITRON_DATETIME, stringDateValue.concat(stringTimeValue),
        						String.valueOf(startPosDate), String.valueOf(lengthDate + lengthTime),
        						String.valueOf(recordsActTotal)));
                	}
        		} else {
    				addWarning(CustomMessageRepositoryMGE.ccb002InvalidItronElement(ITRON_DATETIME, stringDateValue.concat(stringTimeValue),
    						String.valueOf(startPosDate), String.valueOf(lengthDate + lengthTime),
    						String.valueOf(recordsActTotal)));
        		}
        	} else {
				addWarning(CustomMessageRepositoryMGE.ccb002InvalidItronElement(ITRON_DATETIME, stringDateValue.concat(stringTimeValue),
						String.valueOf(startPosDate), String.valueOf(lengthDate + lengthTime),
						String.valueOf(recordsActTotal)));
        	}

        	return dateTimeValue;
        }

        private void cmUploadMeterReading() {
        	// Do not upload if there is an error
        	if (!(errorWithMeter) && !(errorWithReading)) {
            	// Make sure this reading has not been previously uploaded
            	if (cmNoPreviousUpload()) {
            		// Initialize flag
            		uploadSuccessful = true;

            		// Load staging tables
            		cmMeterReadUploadStaging();

            		if (uploadSuccessful) {
            			cmRegisterReadUploadStaging();
            		}

            		// Load skip read code if applicable
            		if ((!(currentItronReadCode.length() == 0)) && uploadSuccessful) {
            			cmAddCharacteristicUploadStaging(skipReasonCharType, currentItronReadCode);
            		}

            		// Load tamper code if applicable
            		if ((!(currentTamperCode.length() == 0)) && uploadSuccessful) {
            			cmAddCharacteristicUploadStaging(tamperCharType, currentTamperCode);
            		}

        			if (resequenceFlag && uploadSuccessful) {
        				// perform resequence logic
        				cmResequenceMeter();
        			}

            		if (uploadSuccessful) {
            			readingsUploaded++;
            		} else {
            			readingsInError++;
            			readingsErrorLoading++;
            		}
            	} else {
            		// throw error
            		readingsInError++;
            		readingsErrorDuplicate++;
            	}
        	} else {
        		readingsInError++;
        		readingsErrorRecord++;
        	}
        }

        private boolean cmNoPreviousUpload() {
        	// See if reading has already been uploaded
            boolean noUploadFoundFlag = false;

            // Build query to look for existing row
            StringBuilder getMeterStagingQuery = new StringBuilder();
            getMeterStagingQuery.append("SELECT CMSU.MR_STAGE_UP_ID ");
            getMeterStagingQuery.append("FROM CI_MR_STAGE_UP CMSU ");
            getMeterStagingQuery.append("WHERE CMSU.MTR_CONFIG_ID = :mtrConfigId ");
            getMeterStagingQuery.append("AND CMSU.MR_UP_STATUS_FLG = :pending ");
            getMeterStagingQuery.append("AND CMSU.READ_DTTM = :readDttm ");

            // Bind SQL variables
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement pstmt =  createPreparedStatement(getMeterStagingQuery.toString());
            PreparedStatement pstmt =  createPreparedStatement(getMeterStagingQuery.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            pstmt.bindId("mtrConfigId", currentMeterConfigId);
            pstmt.bindLookup("pending", MeterReadUploadStatusLookup.constants.PENDING);
            pstmt.bindDateTime("readDttm", currentReadingDateTime);

            // See if anything is found
            int intResultSize = pstmt.list().size();
            if(intResultSize == 0 ){
                noUploadFoundFlag = true;
            } else if(intResultSize == 1 ){
				addWarning(CustomMessageRepositoryMGE.ccb002ReadingAlreadyStaged(currentMeterConfigId.getIdValue().trim()));
				noUploadFoundFlag = false;
            } else {
				addWarning(CustomMessageRepositoryMGE.ccb002StageUploadLookupError(currentMeterConfigId.getIdValue().trim(),
						String.valueOf(recordsActTotal)));
        		noUploadFoundFlag = true;
            }

            // Close SQL and return result
            pstmt.close();
            return noUploadFoundFlag;

        }

        private void cmMeterReadUploadStaging() {
        	// Insert into Meter Read Upload Staging table
         	MeterReadUpload_DTO mtrUploadDto = new MeterReadUpload_DTO();

         	// Set the row values
            mtrUploadDto.setBadgeNumber(currentBadgeNbr);
            mtrUploadDto.setMeterReadSourceId(defaultReadSource);
            mtrUploadDto.setMeterReadUploadStatus(MeterReadUploadStatusLookup.constants.PENDING);
            mtrUploadDto.setMeterConfigurationId(currentMeterConfigId);
            mtrUploadDto.setMeterReaderId(currentReaderId);
            mtrUploadDto.setReadDateTime(currentReadingDateTime);
            mtrUploadDto.setCanUseOnBill(Bool.TRUE);
            mtrUploadDto.setVersion(1);

            try {
            	MeterReadUpload_Id mrStagingId = mtrUploadDto.newEntity().getId();
                // Get the Stage Id to use for other tables
                mrStageId = mrStagingId;
            }
            catch (ApplicationException e) {
            	// Meter read upload was unsuccessful
            	addWarning(CustomMessageRepositoryMGE.ccb002StagingUploadError(currentMeterConfigId.getIdValue().trim(), e.getMessage().trim()));
             	uploadSuccessful = false;
            }
        }

        private void cmRegisterReadUploadStaging() {

        	// Commented out DTO for performance issues
        	/*
         	// DTO Insert into Register Read Upload Staging table
            ReaderRemarkUpload_DTO registerReadDTO = mrStageId.getEntity().getReaderRemarkUploads().newChildDTO();

            registerReadDTO.setRegisterReading(currentReading);
            registerReadDTO.setUnitOfMeasureId(defaultUnitOfMeasure);
            registerReadDTO.setReadType(currentReadType);
            registerReadDTO.setIsHighLowReviewed(Bool.TRUE);
            registerReadDTO.setVersion(1);
            mrStageId.getEntity().getReaderRemarkUploads().add(registerReadDTO, BigInteger.valueOf(currentReadOrder));
            */

        	// Direct Insert into Register Read Upload Staging table
            StringBuilder insertRegisterRead = new StringBuilder();

            insertRegisterRead.append("INSERT INTO CI_RR_STAGE_UP ( ");
            insertRegisterRead.append("MR_STAGE_UP_ID, ");
            insertRegisterRead.append("READ_SEQ, ");
            insertRegisterRead.append("READ_TYPE_FLG, ");
            insertRegisterRead.append("REG_READING, ");
            insertRegisterRead.append("REVIEW_HILO_SW, ");
            insertRegisterRead.append("UOM_CD, ");
            insertRegisterRead.append("VERSION) ");
            insertRegisterRead.append("VALUES ( ");
            insertRegisterRead.append(":MRStageUpId, ");
            insertRegisterRead.append(":ReadSeq, ");
            insertRegisterRead.append(":ReadTypeFlg, ");
            insertRegisterRead.append(":RegReading, ");
            insertRegisterRead.append(":ReviewHiLoSw, ");
            insertRegisterRead.append(":UomCd, ");
            insertRegisterRead.append(":Version) ");
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        	//PreparedStatement pInsertRegisterRead = createPreparedStatement(insertRegisterRead.toString());
            PreparedStatement pInsertRegisterRead = createPreparedStatement(insertRegisterRead.toString(), getClass().getName());
        	//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        	pInsertRegisterRead.bindId("MRStageUpId", mrStageId);
        	pInsertRegisterRead.bindBigInteger("ReadSeq", BigInteger.valueOf(currentReadOrder));
        	pInsertRegisterRead.bindLookup("ReadTypeFlg", currentReadType);
        	pInsertRegisterRead.bindBigDecimal("RegReading", currentReading);
        	pInsertRegisterRead.bindBoolean("ReviewHiLoSw", Bool.TRUE);
        	pInsertRegisterRead.bindId("UomCd", defaultUnitOfMeasure);
        	pInsertRegisterRead.bindBigInteger("Version", BigInteger.ONE);

            pInsertRegisterRead.executeUpdate();
            pInsertRegisterRead.close();

        }

        private void cmResequenceMeter() {
        	// Resequence the meter if requested

        	// Get service point
        	StringBuilder getServicePoint = new StringBuilder();
        	SQLResultRow resultRow = null;
        	ServicePoint_Id servicePointId = null;

        	getServicePoint.append("SELECT SP_ID ");
        	getServicePoint.append("FROM CI_SP_MTR_HIST ");
        	getServicePoint.append("WHERE MTR_CONFIG_ID = :mtrConfigId ");
        	getServicePoint.append("AND REMOVAL_DTTM IS NULL ");
        	//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        	//PreparedStatement pGetServicePoint = createPreparedStatement(getServicePoint.toString());
        	PreparedStatement pGetServicePoint = createPreparedStatement(getServicePoint.toString(), getClass().getName());
        	//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        	pGetServicePoint.bindId("mtrConfigId", currentMeterConfigId);

        	if (pGetServicePoint.list().size() == 1) {

	        	resultRow = pGetServicePoint.firstRow();
	        	servicePointId = new ServicePoint_Id(resultRow.getString("SP_ID"));

	        	// Update the sequence number
	        	ServicePoint_DTO servicePointDTO = servicePointId.getEntity().getDTO();
	        	servicePointDTO.setMeterReadCycleRouteSequence(currentNewSeq);
	        	servicePointId.getEntity().setDTO(servicePointDTO);
        	} else {
        		// Resequence not done
        		addWarning(CustomMessageRepositoryMGE.ccb002InvalidNumberOfServicePoints(currentMeterConfigId.getIdValue().trim(),
        				String.valueOf(pGetServicePoint.list().size()).trim()));
        	}

        	pGetServicePoint.close();

        }

        private void cmAddCharacteristicUploadStaging(CharacteristicType meterReadCharType, String value) {
        	// Upload Meter Read Characteristic

            // Commented DTO out for performance concerns
            /*
            // Upload Meter Read Characteristic To Staging Using DTO
            MeterReadUploadCharacteristic mrUploadChar = mrStageId.getEntity().getCharacteristic();
            MeterReadStagingUploadCharacteristic_DTO mrStageUpChar_DTO = mrUploadChar.newChildDTO();

			// adhoc and file location value use the same field
			if (meterReadCharType.getCharacteristicType().isAdhocValue()) {
				mrStageUpChar_DTO.setAdhocCharacteristicValue(value);
			} else if (meterReadCharType.getCharacteristicType().isForeignKeyValue()) {
				mrStageUpChar_DTO.setCharacteristicValueForeignKey1(value);
			} else if (meterReadCharType.getCharacteristicType().isFileLocationValue()){
				mrStageUpChar_DTO.setAdhocCharacteristicValue(value);
			} else {
				// isPredefinedValue()
				mrStageUpChar_DTO.setCharacteristicValue(value);
			}

			mrStageUpChar_DTO.setSearchCharacteristicValue(value);
            mrUploadChar.add(mrStageUpChar_DTO, meterReadCharType.getId(), BigInteger.TEN);
            */

            // Upload Meter Read Characteristics To Staging Using Direct SQL
            StringBuilder insertCharacteristic = new StringBuilder();

            insertCharacteristic.append("INSERT INTO CI_MR_STGUP_CHAR ( ");
            insertCharacteristic.append("MR_STAGE_UP_ID, ");
            insertCharacteristic.append("CHAR_TYPE_CD, ");
            insertCharacteristic.append("SEQ_NUM, ");

			// adhoc and file location value use the same field
			if (meterReadCharType.getCharacteristicType().isAdhocValue()) {
				insertCharacteristic.append("ADHOC_CHAR_VAL, ");
			} else if (meterReadCharType.getCharacteristicType().isForeignKeyValue()) {
				insertCharacteristic.append("CHAR_VAL_FK1, ");
			} else if (meterReadCharType.getCharacteristicType().isFileLocationValue()){
				insertCharacteristic.append("ADHOC_CHAR_VAL, ");
			} else {
				// isPredefinedValue()
				insertCharacteristic.append("CHAR_VAL, ");
			}

            insertCharacteristic.append("SRCH_CHAR_VAL, ");
            insertCharacteristic.append("VERSION) ");
            insertCharacteristic.append("VALUES ( ");
            insertCharacteristic.append(":MRStageUpId, ");
            insertCharacteristic.append(":CharTypeCd, ");
            insertCharacteristic.append(":SeqNum, ");

			// adhoc and file location value use the same field
			if (meterReadCharType.getCharacteristicType().isAdhocValue()) {
				insertCharacteristic.append(":AdhocCharVal, ");
			} else if (meterReadCharType.getCharacteristicType().isForeignKeyValue()) {
				insertCharacteristic.append(":CharValFK1, ");
			} else if (meterReadCharType.getCharacteristicType().isFileLocationValue()){
				insertCharacteristic.append(":AdhocCharVal, ");
			} else {
				// isPredefinedValue()
				insertCharacteristic.append(":CharVal, ");
			}

            insertCharacteristic.append(":SrchCharVal, ");
            insertCharacteristic.append(":Version) ");
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        	//PreparedStatement pInsertCharacteristic = createPreparedStatement(insertCharacteristic.toString());
            PreparedStatement pInsertCharacteristic = createPreparedStatement(insertCharacteristic.toString(), getClass().getName());
        	//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        	pInsertCharacteristic.bindId("MRStageUpId", mrStageId);
        	pInsertCharacteristic.bindId("CharTypeCd", meterReadCharType.getId());
        	pInsertCharacteristic.bindBigInteger("SeqNum", BigInteger.TEN);

			// adhoc and file location value use the same field
			if (meterReadCharType.getCharacteristicType().isAdhocValue()) {
				pInsertCharacteristic.bindString("AdhocCharVal", value, "ADHOC_CHAR_VAL");
			} else if (meterReadCharType.getCharacteristicType().isForeignKeyValue()) {
				pInsertCharacteristic.bindString("CharValFK1", value, "CHAR_VAL_FK1");
			} else if (meterReadCharType.getCharacteristicType().isFileLocationValue()){
				pInsertCharacteristic.bindString("AdhocCharVal", value, "ADHOC_CHAR_VAL");
			} else {
				// isPredefinedValue()
				pInsertCharacteristic.bindString("CharVal", value, "CHAR_VAL");
			}

        	pInsertCharacteristic.bindString("SrchCharVal", value, "SRCH_CHAR_VAL");
        	pInsertCharacteristic.bindBigInteger("Version", BigInteger.ONE);

        	pInsertCharacteristic.executeUpdate();
        	pInsertCharacteristic.close();

        }

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
			// Close Itron Input File
			cmCloseItronInputFile();

			// Display Record Counts
			if (displayLoggerCount > 0) {
		       	logger.info("\n *** Records Processed                             |"+recordsProcessed+"|");
		       	logger.info("\n *** Records In Error                              |"+recordsInError+"|");
		       	logger.info("\n *** Readings Uploaded                             |"+readingsUploaded+"|");
		       	logger.info("\n *** Readings In Error                             |"+readingsInError+"|");
		       	logger.info("\n *** Readings With Input Record Error              |"+readingsErrorRecord+"|");
		       	logger.info("\n *** Duplicate Readings Error                      |"+readingsErrorDuplicate+"|");
		       	logger.info("\n *** Readings With Loading Error                   |"+readingsErrorLoading+"|");
			}

		}

	}

}
