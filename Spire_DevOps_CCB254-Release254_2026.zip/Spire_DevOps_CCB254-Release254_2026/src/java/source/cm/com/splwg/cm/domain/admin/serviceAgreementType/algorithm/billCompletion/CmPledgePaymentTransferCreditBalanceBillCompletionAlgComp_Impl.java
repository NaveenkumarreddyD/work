/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Pledge Payment Transfer Credit Balance to other Service Agreement
 * 
 * This Algorithm transfers credits on an Overpayment SA to other SAs
 * with a Current Balance at the time of Bill Completion. Credits applied
 * to SA Types in-eligible to receive Pledge Payments will have a 
 * To Do Generated.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-09-27   JHERNA      SysAid#73573. Initial Version. Post v2.4 upgrade.
 * *************************************************************************                
 */
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.billCompletion;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.StandardMessages;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentCancelReason.entity.AdjustmentCancelReason;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.billCompletion.SaTypeBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.billing.data.BillData;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.common.CreditAmountAutoDistribution;
import com.splwg.ccb.domain.customerinfo.data.CreditAmountAutoDistributionInputData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.api.lookup.CmPledgePaymentsOptionTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;

/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentType, name = adjTypeSyncUp, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = adjTypeTransfer, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = adjTypeRefundAP, type = entity)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = featConfPledgePaymentReconciliation, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentCancelReason, name = adjCnclRsnIneligibleSaTypeForPledge, required = true, type = entity)})
 */
public class CmPledgePaymentTransferCreditBalanceBillCompletionAlgComp_Impl
		extends CmPledgePaymentTransferCreditBalanceBillCompletionAlgComp_Gen
		implements SaTypeBillCompletionAlgorithmSpot {

	/*
	 * Hard Parameters
	 */
	// Output 
	private Bool outputAllowBillReopening;
	private BillData outputBillData;
	private Bool outputDoMultipleBillingRelationshipsExist;
	private Bool outputIsFtProcessAdded;
	private Bool outputIsFtTransferred;
	// Input
	@SuppressWarnings("unused")
	private Date inputAcctDate;
	private BillData inputBillData;
	@SuppressWarnings("unused")
	private Date inputBillDate;
	private ServiceAgreement inputSA;
	/*
	 * Soft Parameters
	 */
	private AdjustmentType parmAdjTypeSyncUp;
	private AdjustmentType parmAdjTypeTransfer;
	private AdjustmentType parmAdjTypeRefundAP;
	private FeatureConfiguration parmFeatConfPledgePay;
	private AdjustmentCancelReason parmAdjCancelReasonIneligibleSaTypeForPledge;
	/*
	 * Work Variables
	 */
	private List<String> wCollOfEligibleSaTypes;
	
	@Override
	public void setAccountingDate(Date acctngDate) {
		inputAcctDate = acctngDate;
	}

	@Override
	public void setBillData(BillData billData) {
		inputBillData = billData;
	}

	@Override
	public void setBillDate(Date billDate) {
		inputBillDate = billDate;
	}

	@Override
	public void setServiceAgreement(ServiceAgreement sa) {
		inputSA = sa;
	}
	
	@Override
	public Bool getAllowBillReopening() {
		return outputAllowBillReopening;
	}

	@Override
	public BillData getBillData() {
		outputBillData = inputBillData;
		return outputBillData;
	}

	@Override
	public Bool getDoMultipleBillingRelationshipsExist() {
		return outputDoMultipleBillingRelationshipsExist;
	}

	@Override
	public Bool getIsFtProcessAdded() {
		return outputIsFtProcessAdded;
	}

	@Override
	public Bool getIsFtTransferred() {
		return outputIsFtTransferred;
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

		// Retrieve Algorithm Parameters and store to variables
		parmAdjTypeSyncUp = this.getAdjTypeSyncUp();
		parmAdjTypeTransfer = this.getAdjTypeTransfer();
		parmAdjTypeRefundAP = this.getAdjTypeRefundAP();
		parmFeatConfPledgePay = this.getFeatConfPledgePaymentReconciliation();
		parmAdjCancelReasonIneligibleSaTypeForPledge = this.getAdjCnclRsnIneligibleSaTypeForPledge();
	}

	/*
	 * Main Section
	 */
	@Override
	public void invoke() {

		// Initialize
		initialize();
		// Check Input
		checkInput();
		// Perform Processing
		performProcess();
	}
	
	private void initialize() {
		
		outputAllowBillReopening = Bool.TRUE;
		/**/
		outputDoMultipleBillingRelationshipsExist = Bool.FALSE;
		outputIsFtProcessAdded = Bool.FALSE;
		outputIsFtProcessAdded = Bool.FALSE;
		/**/
	}
	
	private void checkInput() {
		
		/*
		 * SA ID is required
		 */
		if (isNull(inputSA)) {
			addError(StandardMessages.fieldMissing("SA_ID"));
		}
		/*
		 * BILL ID is required
		 */
		if (isNull(inputBillData)
				|| isNull(inputBillData.getBillDTO())
				|| isNull(inputBillData.getBillDTO().getEntity())) {
			addError(StandardMessages.fieldMissing("BILL_ID"));
		}
	}
	
	private void performProcess() {
		
		/*
		 * Create a frozen adjustment using the sync up adjustment type
		 */
		createSyncUpAdjustment(inputSA, parmAdjTypeSyncUp, Bool.FALSE);
		/*
		 * Create the transfer adjustment
		 */
		distributeCredit();
		/*
		 * If the Adjustment Type Refund A/P (parameter 30) is provided, 
		 * Check to see if a refund needs to be issue for this SA.
		 */
		if (notNull(parmAdjTypeRefundAP)) {
			checkForRefund();
		}
	}
	
	private void createSyncUpAdjustment(ServiceAgreement sa, AdjustmentType adjType, Bool shouldAllowZeroAmount) {
		
		/*
		 * If the payoff and current balance are not equal, create a 
		 * frozen adjustment to synch the SA.
		 */
		Money currentBalance = sa.getCurrentBalance();
		Money payoffBalance = sa.getPayoffBalance();
		if (!(currentBalance.isEqualTo(payoffBalance))){

			CreateFrozenAdjustmentData adjData = CreateFrozenAdjustmentData.Factory.newInstance();
			adjData.setServiceAgreement(sa);
			adjData.setAdjustmentType(adjType);
			adjData.setAdjustmentDate(this.getProcessDateTime().getDate());
			adjData.setAllowZeroAmount(Bool.FALSE);
			createAdjustment(adjData);
		}
	}
	
	private void createAdjustment(CreateFrozenAdjustmentData adjustmentData) {
		
		// Use Java Enabled class (CIPAAFZN)
		CreateFrozenAdjustment createFrozenAdjustmentRoutine = CreateFrozenAdjustment.Factory.newInstance();
		createFrozenAdjustmentRoutine.createFrozenAdjustment(adjustmentData);
	}
	
	private void distributeCredit() {
		
		// Get the SA's account to pass to CIPADCCN
		Account account = inputSA.getAccount();
		// SA Payoff Balance is the SA's TOT_AMT
		Money saPayoffBalance = inputSA.getPayoffBalance(); 
		
		if (saPayoffBalance.isLessThan(Money.ZERO)) {
			
			CreditAmountAutoDistributionInputData dccnData = CreditAmountAutoDistributionInputData.Factory.newInstance();
			dccnData.setProcessDate(this.getProcessDateTime().getDate());
			dccnData.setTransferFromSa(inputSA);
			dccnData.setAdjustmentType(parmAdjTypeTransfer);
			dccnData.setCreditAmount(saPayoffBalance.negate());
			dccnData.setShouldApplyExcessCredit(Bool.FALSE);

			/*
			 * Base program has this as false but we would need the adjustment collection 
			 * to interrogate if a transfer to an SA with in-eligible SA Type was done 
			 */
			//dccnData.setShouldReturnAdjustmentCollection(Bool.FALSE);
			dccnData.setShouldReturnAdjustmentCollection(Bool.TRUE);
	
			CreditAmountAutoDistribution cipadccn = CreditAmountAutoDistribution.Factory.newInstance();
			List<Adjustment> listOfAdj = cipadccn.autoDistribute(account, dccnData);

			/*
			 * START NEW FUNCTIONALITY
			 */
			Iterator<Adjustment> collOfAdj = listOfAdj.iterator();
			
			while (collOfAdj.hasNext()) {
				
				Adjustment adj = collOfAdj.next();

				// Get the SA where the adjustment was transferred into.
				ServiceAgreement xferToSA = adj.getServiceAgreement();							
				Bool isSaTypeEligible = cmCheckSaTypeOfXferToSA(xferToSA);				

				// If the SA Type of the SA where the credit is transferred to is an in-eligible SA Type, create To Do Entry
				if (isSaTypeEligible.isFalse()) {

					// Cancel the adjustment since they are created on in-eligible SA Type for Pledge
					adj.cancel(parmAdjCancelReasonIneligibleSaTypeForPledge);
				}				
			}
			/*
			 * END NEW FUNCTIONALITY
			 */
		}
	}
	
	private void checkForRefund() {
		
		/*
		 * Get the SA balance after the credit has been distributed
		 */
		Account account = inputSA.getAccount();
		Money saPayoffBalance = inputSA.getPayoffBalance(); 
		if (saPayoffBalance.isLessThan(Money.ZERO)) {
			
			/*
			 * Determine whether any SAs exists for the account that
			 * are not closed, canceled or reactivated.
			 */
			Bool hasOtherSAsToReceiveCredit = checkOtherSAs(
					account.getId(),
					inputSA.getId(),
					Bool.TRUE);
			/*
			 * If no SAs exists that can receive the remaining credit, 
			 * create an A/P refund adjustment for the SA.
			 */
			if (hasOtherSAsToReceiveCredit.isFalse()) {
				createRefundAdjustment(inputSA, parmAdjTypeRefundAP, Bool.FALSE);
			}
		}
	}
	
	private void createRefundAdjustment(ServiceAgreement sa, AdjustmentType adjType, Bool shouldAllowZeroAmount) {
		
		CreateFrozenAdjustmentData adjData = CreateFrozenAdjustmentData.Factory.newInstance();
		adjData.setServiceAgreement(sa);
		adjData.setAdjustmentType(adjType);
		/*
		 * Adjustment Amount must be the opposite of the SA's total 
		 * balance.
		 */
		adjData.setAdjustmentAmount(sa.getPayoffBalance().negate());
		adjData.setAllowZeroAmount(shouldAllowZeroAmount);
		createAdjustment(adjData);				
	}	
	
	/*
	 * START NEW FUNCTIONALITY METHODS
	 */
	private Bool cmCheckSaTypeOfXferToSA(ServiceAgreement xferToSA) {
		
		Bool returnValue = Bool.FALSE;
		
		cmRetrieveCollOfEligibleSaTypes();
		
		String inputSaType = xferToSA.getServiceAgreementType().fetchIdSaType().trim();		
		
		if (wCollOfEligibleSaTypes.contains(inputSaType)) {
			returnValue = Bool.TRUE;
		}
		return returnValue;
	}

	private void cmRetrieveCollOfEligibleSaTypes() {		

		CmMGEFeatureConfigurationOptionsRetriever featConfRoutine = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
				
		// Initialize 
		wCollOfEligibleSaTypes = new ArrayList<String>();

		// Retrieve the option value (comma delimited)		
		String optVal = featConfRoutine.cmGetFeatOptValue(parmFeatConfPledgePay.getId(),
				CmPledgePaymentsOptionTypeLookup.constants.ELIGIBLE_PLEDGE_SA_TYPES,
				Bool.TRUE,
				Bool.FALSE);
		
		// Retrieve, Validate and Store the valid pledge tender sources		
		String[] strArrayOptVal = optVal.split(",");
		
		for (String saTypeStr : strArrayOptVal) {

			if (notBlank(saTypeStr)) {				
				Bool isValid = cmValidateSaType(saTypeStr);
				if (isValid.isTrue()) {
					wCollOfEligibleSaTypes.add(saTypeStr.trim());
				}
			}
		}
	}
	
	private Bool cmValidateSaType(String saType) {
		
		Bool returnValue = Bool.FALSE;
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT 'X' ");
		stringBuilder.append("FROM CI_SA_TYPE ");
		stringBuilder.append("WHERE SA_TYPE_CD = :saType ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=cmValidateSaType=");
		prepState.bindString("saType", saType.trim(), "SA_TYPE_CD");
		prepState.setAutoclose(false);
		prepState.execute();
		if (prepState.list().size() > 0) {
			returnValue = Bool.TRUE;
		}
		prepState.close();		
		return returnValue;
	}
	
	/*
	 * END NEW FUNCTIONALITY METHODS
	 */
	
	/*
	 * SQL Section
	 */
	private Bool checkOtherSAs(Account_Id acctID, ServiceAgreement_Id saID, Bool allowBillingSw) {
		// pendingStart, active, pendingStop, stop
		Bool returnValue = Bool.FALSE;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT 'X' ");
		stringBuilder.append("FROM CI_SA SA, CI_SA_TYPE SAT ");
		stringBuilder.append("WHERE SA.ACCT_ID = :acctID ");
		stringBuilder.append("AND SA.SA_ID != :saID ");
		stringBuilder.append("AND SA.SA_STATUS_FLG IN (:pendingStart, :active, :pendingStop, :stopped) ");
		stringBuilder.append("AND SA.CIS_DIVISION = SAT.CIS_DIVISION ");
		stringBuilder.append("AND SA.SA_TYPE_CD = SAT.SA_TYPE_CD ");
		stringBuilder.append("AND SAT.ALLOW_BILLING_SW = :allowBillingSw ");   
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=checkOtherSAs=");
		prepState.bindId("acctID", acctID);
		prepState.bindId("saID", saID);
		prepState.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
		prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
		prepState.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
		prepState.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
		prepState.bindBoolean("allowBillingSw", allowBillingSw);
		prepState.setAutoclose(false);
		prepState.execute();
		if (prepState.list().size() > 0) {
			returnValue = Bool.TRUE;
		}
		prepState.close();
		return returnValue;
	}
}
