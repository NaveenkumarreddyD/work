/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Meter Exception Routing 
 * 
 * The batch process will update the To Do Role of meter exception to do entries  
 * if the Meter connected to the To Do has a Meter Configuration Type
 * defined in the feature configuration.
 * 
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-10-04   CVB     Initial Version.
 * 2013-10-31   CVB     Fixed defect for null pointer when MR Stage Upload
 *                      does not have a Meter Configuration specified.
 * 2016-01-29  	MPang	Updated for CCB v2.4 compilation.                      
 *************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.LogTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.meterConfigurationType.MeterConfigurationType;
import com.splwg.ccb.domain.admin.meterConfigurationType.MeterConfigurationType_Id;
import com.splwg.ccb.domain.common.featureConfiguration.FeatureConfigurationOptionData;*/

import com.splwg.ccb.domain.admin.meterConfigurationType.entity.MeterConfigurationType;
import com.splwg.ccb.domain.admin.meterConfigurationType.entity.MeterConfigurationType_Id;
import com.splwg.ccb.domain.common.data.FeatureConfigurationOptionData;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.ccb.domain.common.featureConfiguration.FeatureConfigurationOptionsRetriever;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.meterread.meter.Meter;
import com.splwg.ccb.domain.meterread.meter.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead_Id;
import com.splwg.ccb.domain.meterread.meterReadUpload.MeterReadUpload;
import com.splwg.ccb.domain.meterread.meterReadUpload.MeterReadUpload_Id;*/

import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_Id;
import com.splwg.ccb.domain.meterread.meterReadUpload.entity.MeterReadUpload;
import com.splwg.ccb.domain.meterread.meterReadUpload.entity.MeterReadUpload_Id;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.api.lookup.CmMeterToDoExceptionOptionTypeFlagLookup;
import com.splwg.cm.api.lookup.ExternalSystemTypeLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author cborbon001
 *
 @BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = featureConfiguration, name = METER_TO_DO_EXCEPTIONS_FC, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = role, name = TODO_ROLE, required = true, type = entity)})
 */

public class CmMeterExceptionRouting_BatchProcess extends
CmMeterExceptionRouting_BatchProcess_Gen {
	
	private final static String METER_TABLE_NAME = "CI_MTR";
	private final static String METERREAD_TABLE_NAME = "CI_MR";
	private final static String MRSTAGEUP_TABLE_NAME = "CI_MR_STAGE_UP";

	public JobWork getJobWork() {

		StringBuilder strBldr = new StringBuilder();

		strBldr.append(" SELECT TDENTRY.TD_ENTRY_ID                                                 ");
		strBldr.append("       ,DRILLKEYTYPE.TBL_NAME                                               ");
		strBldr.append("       ,DRILLKEY.KEY_VALUE                                                  ");
		strBldr.append("   FROM CI_TD_ENTRY TDENTRY                                                 ");
		strBldr.append("       ,CI_TD_DRLKEY_TY DRILLKEYTYPE                                        ");
		strBldr.append("       ,CI_TD_DRLKEY DRILLKEY                                               ");
		strBldr.append("  WHERE TDENTRY.ENTRY_STATUS_FLG = :entryStatusOpen                         ");
		strBldr.append("    AND TRUNC(TDENTRY.CRE_DTTM) = :createDate                               ");
		strBldr.append("    AND EXISTS (SELECT 'X'                                                  ");
		strBldr.append("                  FROM CI_WFM_OPT WFMOPT                                    ");
		strBldr.append("                 WHERE WFMOPT.WFM_NAME = :featCfg                           ");
		strBldr.append("                   AND WFMOPT.EXT_OPT_TYPE = :todoTypeOptionType            ");
		strBldr.append("                   AND TRIM(WFMOPT.WFM_OPT_VAL) = TRIM(TDENTRY.TD_TYPE_CD)) ");
		strBldr.append("    AND TDENTRY.TD_TYPE_CD = DRILLKEYTYPE.TD_TYPE_CD                        ");
		strBldr.append("    AND ((DRILLKEYTYPE.TBL_NAME = 'CI_MR'                                   ");
		strBldr.append("      AND DRILLKEYTYPE.FLD_NAME = 'MR_ID')                                  ");
		strBldr.append("      OR (DRILLKEYTYPE.TBL_NAME = 'CI_MTR'                                  ");
		strBldr.append("      AND DRILLKEYTYPE.FLD_NAME = 'MTR_ID')                                 ");
		strBldr.append("      OR (DRILLKEYTYPE.TBL_NAME = 'CI_MR_STAGE_UP'                          ");
		strBldr.append("      AND DRILLKEYTYPE.FLD_NAME = 'MR_STAGE_UP_ID')                         ");
		strBldr.append("         )                                                                  ");
		strBldr.append("    AND DRILLKEY.TD_ENTRY_ID = TDENTRY.TD_ENTRY_ID                          ");
		strBldr.append("    AND DRILLKEY.SEQ_NUM = DRILLKEYTYPE.SEQ_NUM                             ");
		strBldr.append("    AND NOT EXISTS(SELECT 'X'                                               ");
		strBldr.append("                     FROM CI_TD_LOG TDLOG                                   ");
		strBldr.append("                    WHERE TDLOG.TD_ENTRY_ID = TDENTRY.TD_ENTRY_ID           ");
		strBldr.append("                      AND TDLOG.LOG_TYPE_FLG = :forwardedLogType)           ");

		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement getToDoEntries = createPreparedStatement(strBldr.toString()); 
		PreparedStatement getToDoEntries = createPreparedStatement(strBldr.toString(), getClass().getName()); 
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		getToDoEntries.bindLookup("entryStatusOpen", ToDoEntryStatusLookup.constants.OPEN);
		getToDoEntries.bindDate("createDate", this.getProcessDateTime().getDate());
		getToDoEntries.bindEntity("featCfg", getParameters().getMETER_TO_DO_EXCEPTIONS_FC());
		getToDoEntries.bindLookup("todoTypeOptionType", CmMeterToDoExceptionOptionTypeFlagLookup.constants.TODO_TYPE);
		getToDoEntries.bindLookup("forwardedLogType", LogTypeLookup.constants.FORWARDED);

		// Build Worklist
		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();

		QueryIterator<SQLResultRow> iter = getToDoEntries.iterate();
		while (iter.hasNext()) {
			SQLResultRow row = iter.next();

			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId((ToDoEntry_Id) row.getId("TD_ENTRY_ID", ToDoEntry.class));
			workUnit.addSupplementalData("tableName", row.getString("TBL_NAME"));
			workUnit.addSupplementalData("keyValue", row.getString("KEY_VALUE"));

			workUnits.add(workUnit);              
		}
		iter.close();  
		
		getToDoEntries.close();

		return createJobWorkForThreadWorkUnitList(workUnits);  

	}

	public void validateSoftParameters(boolean arg0) {

		JobParameters parameters = getParameters();

		FeatureConfiguration meterToDoExceptionFeatCfg = parameters.getMETER_TO_DO_EXCEPTIONS_FC();
		Role toDoRole = parameters.getTODO_ROLE();

		ExternalSystemTypeLookup extSysType = ExternalSystemTypeLookup.constants.CM_METER_TO_DO_EXCEPTIONS;
		LookupValue optionType = CmMeterToDoExceptionOptionTypeFlagLookup.constants.TODO_TYPE.getLookupValue();

		FeatureConfigurationOptionsRetriever fcOptionsRetriever = FeatureConfigurationOptionsRetriever.Factory.newInstance();
		List<FeatureConfigurationOptionData> fcOptionData = fcOptionsRetriever.getFeatureConfigurationOptions(meterToDoExceptionFeatCfg, 
				optionType.fetchIdFieldValue().trim(), extSysType);

		if (fcOptionData.size() > 0) {
			Iterator fcOptionIter = fcOptionData.iterator();	
			while (fcOptionIter.hasNext()){

				// Validate that the To Do Role is valid for all the To Do Types defined on the Feature Configuration
				FeatureConfigurationOptionData featureConfigOptionData = (FeatureConfigurationOptionData) fcOptionIter.next();
				String toDoTypeOption = featureConfigOptionData.getOptionValue().trim();
				ToDoType_Id toDoTypeId = new ToDoType_Id(toDoTypeOption);
				ToDoType toDoType = toDoTypeId.getEntity();
				if (isNull(toDoType)){
					// Issue an error that the To Do Type is not valid.
					addError(CustomMessageRepositoryMDC.NM0104_2_toDoTypeOptionValueInvalid(meterToDoExceptionFeatCfg.getId().getTrimmedValue(), optionType.fetchLanguageDescription(),toDoTypeId.getTrimmedValue()));
				}
				else {
					ToDoTypeRole_Id toDoTypeRoleId = new ToDoTypeRole_Id(toDoType,toDoRole);
					ToDoTypeRole toDoTypeRole = toDoTypeRoleId.getEntity();
					if (isNull(toDoTypeRole)){
						// Issue an error that the To Do Role is not valid for the To Do Type.
						addError(CustomMessageRepositoryMDC.NM0104_2_toDoRoleInvalidForToDoType(toDoTypeId.getTrimmedValue(), toDoRole.getId().getTrimmedValue()));
					}
				}
			}
		}
	}

	public Class<CmMeterExceptionRouting_BatchProcessWorker> getThreadWorkerClass() {
		return CmMeterExceptionRouting_BatchProcessWorker.class;
	}

	public static class CmMeterExceptionRouting_BatchProcessWorker extends
	CmMeterExceptionRouting_BatchProcessWorker_Gen {

		// Batch Parameters

		FeatureConfiguration meterToDoExceptionFeatCfg;
		Role toDoRole;

		// Working variables

		private String tableName;
		private String keyValue;
		private ToDoEntry_Id toDoEntryId;

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		public void initializeThreadWork(boolean arg0) 
		throws ThreadAbortedException, RunAbortedException {

			// Get batch parameters
			ThreadParameters parameters = getParameters();
			meterToDoExceptionFeatCfg = parameters.getMETER_TO_DO_EXCEPTIONS_FC();
			toDoRole = parameters.getTODO_ROLE();
		}

		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
		throws ThreadAbortedException, RunAbortedException
		{
			// Initialize Variables           
			tableName = (String) unit.getSupplementallData("tableName");
			keyValue = (String) unit.getSupplementallData("keyValue");
			toDoEntryId = (ToDoEntry_Id) unit.getPrimaryId();
			
			WorkUnitResult workUnitResult = new WorkUnitResult(true);

			if (tableName.trim().equalsIgnoreCase(METER_TABLE_NAME)){
				Meter_Id meterId = new Meter_Id(keyValue);
				Meter meter = meterId.getEntity();
				if (notNull(meter)){
					SQLResultRow result = getMeterConfigurationOfMeter(meterId);
					if (notNull(result)) {
						MeterConfigurationType_Id meterConfigTypeId = (MeterConfigurationType_Id)result.getId("MTR_CONFIG_TY_CD",MeterConfigurationType.class);
						Bool shouldOverrideToDoRole = checkIfMeterConfigTypeIsInList(meterConfigTypeId);
						if (shouldOverrideToDoRole.isTrue()){
							overrideToDoRole(toDoEntryId,toDoRole);
							workUnitResult.setUnitsProcessed(1);
							workUnitResult.setUnitsInError(0);
							return workUnitResult;
						}
					}
				}
			}

			if (tableName.trim().equalsIgnoreCase(METERREAD_TABLE_NAME)){
				
				MeterRead_Id mrId = new MeterRead_Id(keyValue);
				MeterRead mr = mrId.getEntity();
				if (notNull(mr)){
					MeterConfigurationType mtrConfigType = mr.getMeterConfiguration().getMeterConfigurationType();
					MeterConfigurationType_Id meterConfigTypeId = mtrConfigType.getId();
					Bool shouldOverrideToDoRole = checkIfMeterConfigTypeIsInList(meterConfigTypeId);
					if (shouldOverrideToDoRole.isTrue()){
						overrideToDoRole(toDoEntryId,toDoRole);
						workUnitResult.setUnitsProcessed(1);
						workUnitResult.setUnitsInError(0);
						return workUnitResult;
					}
				}
			}

			if (tableName.trim().equalsIgnoreCase(MRSTAGEUP_TABLE_NAME)){

				BigInteger mrUploadIdBigInteger = BigInteger.ZERO;

				try {
					mrUploadIdBigInteger = BigInteger.valueOf(Long.valueOf(keyValue));	
				}
				catch (NumberFormatException nfe){
					
					workUnitResult.setUnitsProcessed(0);
					workUnitResult.setUnitsInError(0);
					return workUnitResult;
				}


				MeterReadUpload_Id mrUploadId = new MeterReadUpload_Id(mrUploadIdBigInteger);

				MeterReadUpload mrUpload = mrUploadId.getEntity();
				if (notNull(mrUpload)){
					// CVB - 2013-10-31 - Start
					MeterConfiguration_Id mtrConfigId = mrUpload.getMeterConfigurationId();
					if (isNull(mtrConfigId)){
						workUnitResult.setUnitsProcessed(0);
						workUnitResult.setUnitsInError(0);
						return workUnitResult;
					}
					// MeterConfigurationType mtrConfigType = mrUpload.getMeterConfigurationId().getEntity().getMeterConfigurationType();
					MeterConfigurationType mtrConfigType = mtrConfigId.getEntity().getMeterConfigurationType();
					// CVB - 2013-10-31 - End
					MeterConfigurationType_Id meterConfigTypeId = mtrConfigType.getId();
					Bool shouldOverrideToDoRole = checkIfMeterConfigTypeIsInList(meterConfigTypeId);
					if (shouldOverrideToDoRole.isTrue()){
						overrideToDoRole(toDoEntryId,toDoRole);
						workUnitResult.setUnitsProcessed(1);
						workUnitResult.setUnitsInError(0);
						return workUnitResult;
					}
				}

			}

			// If code has reached to this point, it means we do not need to override anything on the record returned by SQL so we set the Units
			// procesed to zero so as not to increment counter for Processed Records.

			workUnitResult.setUnitsProcessed(0);
			workUnitResult.setUnitsInError(0);
			return workUnitResult;
		}

		private SQLResultRow getMeterConfigurationOfMeter(Meter_Id meterId) {

			StringBuilder strBldr = new StringBuilder();

			strBldr.append("SELECT MC.MTR_CONFIG_ID                                ");          
			strBldr.append("      ,MC.MTR_CONFIG_TY_CD                             ");
			strBldr.append("  FROM CI_MTR_CONFIG MC                                ");
			strBldr.append(" WHERE MC.MTR_ID = :meterId                            ");
			strBldr.append("   AND MC.EFF_DTTM = (SELECT MAX(MC2.EFF_DTTM)         ");
			strBldr.append("                        FROM CI_MTR_CONFIG MC2         ");
			strBldr.append("                       WHERE MC.MTR_ID = MC2.MTR_ID    ");
			strBldr.append("                         AND MC2.EFF_DTTM <= :effDttm) ");    

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement getMeterConfig = createPreparedStatement(strBldr.toString()); 
			PreparedStatement getMeterConfig = createPreparedStatement(strBldr.toString(), getClass().getName()); 
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			getMeterConfig.bindId("meterId", meterId);
			getMeterConfig.bindDateTime("effDttm", this.getProcessDateTime());

			SQLResultRow result = getMeterConfig.firstRow();
			getMeterConfig.close();
			return result;
		}

		private Bool checkIfMeterConfigTypeIsInList(MeterConfigurationType_Id meterCfgTypeId){
			
			LookupValue optionType = CmMeterToDoExceptionOptionTypeFlagLookup.constants.METER_CONFIGURATION_TYPE.getLookupValue();
			Bool meterConfigTypeInList = Bool.FALSE;

			StringBuilder strBldr = new StringBuilder();

			strBldr.append("SELECT 'X'                                            ");
			strBldr.append("  FROM CI_WFM_OPT WFMOPT                              ");
			strBldr.append(" WHERE WFMOPT.WFM_NAME = :featCfgName                 ");
			strBldr.append("   AND WFMOPT.EXT_OPT_TYPE = :meterCfgTypeOptionType  ");
			strBldr.append("   AND TRIM(WFMOPT.WFM_OPT_VAL) = TRIM(:meterCfgType) ");  

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement checkMeterConfigType = createPreparedStatement(strBldr.toString());
			PreparedStatement checkMeterConfigType = createPreparedStatement(strBldr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			checkMeterConfigType.bindEntity("featCfgName", meterToDoExceptionFeatCfg);
			checkMeterConfigType.bindString("meterCfgTypeOptionType", optionType.fetchIdFieldValue().trim(), "EXT_OPT_TYPE");
			checkMeterConfigType.bindString("meterCfgType", meterCfgTypeId.getTrimmedValue(),"WFM_OPT_VAL");
			
			if(notNull(checkMeterConfigType.firstRow())){
				meterConfigTypeInList = Bool.TRUE;
			}
			
			checkMeterConfigType.close();
			
			return meterConfigTypeInList;
		}

		private void overrideToDoRole(ToDoEntry_Id toDoEntryId, Role toDoRole) {

			String userComments = "by Batch Control " + this.getBatchControlId().getTrimmedValue() + ".";
			toDoEntryId.getEntity().forwardToRole(toDoRole.getId(), userComments);
			
		}
		
	}

}