/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * CCB010 - This batch process will monitor incoming reads and complete the
 * non-dispatchable field activity when a read is received. This process is
 * very similar to the base FANMRCO batch process. It can prorate the 
 * consumption if the scheduled read is not on the same date as the start or
 * stop. It can also cancel the non-dispatchable field activity and create a
 * dispatchable field activity if no scheduled read arrives within a defined
 * window of time.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2015-05-05   SMiran        	CCB010. Initial Version.
 * 2015-07-24	SMiran			Defect 3255269. When canceling I-READ and
 * 								creating M-READ, the M-READ should be 
 * 								scheduled on the next work day.
 * 2015-08-26   SMiran			Defect 3290686. When inserting in MR Download
 * 								Staging, check first if Selection Date exists
 * 								in MR Schedule table. If yes, subtract 1 day
 * 								until the Selection Date does not exist in
 * 								MR Schedule table.
 * 2015-09-02	SMiran			Defect 3296586. Succession Reads - Changes 
 * 								to MDL
 * 								- The Cycle Number must be entered as 99
 * 								- Instead of the route number, we must have 
 * 								two fields: 
 *								1. The first two digits is the day of the 
 *								month we need the successions read
 *								2. Then the last field needs to be the 
 *								succession territory 
 *								Also added soft parameters for Town Code
 *								Charateristic Type and Grid Code Geo Type Code   
 * 2016-01-27	MPang	 		Updated for CCB v2.4 compilation. 
 * 
 * 2018-01-22	Kiran Machavarapu	SA-81481 Catch SQL exception
 **************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Time;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControl;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.geographicType.GeographicType;
//2015-07-24. SMiran. Defect 3255269. Start Add
import com.splwg.base.domain.common.workCalendar.WorkCalendar;
//2015-07-24. SMiran. Defect 3255269. End Add
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityCreatedByLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.FieldActivitySystemDefaultLookup;
import com.splwg.ccb.api.lookup.MeterReadRemarkStatusLookup;
import com.splwg.ccb.api.lookup.ReadTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementSpFaTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointFieldConditionLookup;
//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
// 2015-07-24. SMiran. Defect 3255269. Start Add
/*import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
// 2015-07-24. SMiran. Defect 3255269. End Add
import com.splwg.ccb.domain.admin.cisDivision.CisDivision_Id;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.FieldActivityCancelReason;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.FieldActivityCancelReason_Id;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType;
import com.splwg.ccb.domain.admin.meterReadCycle.MeterReadCycle_Id;
import com.splwg.ccb.domain.admin.meterReaderRemark.MeterReaderRemark;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
//2015-07-24. SMiran. Defect 3255269. Start Add
import com.splwg.ccb.domain.customerinfo.premise.Premise;
import com.splwg.ccb.domain.customerinfo.premise.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.PremiseGeographicLocation;
//2015-07-24. SMiran. Defect 3255269. End Add
import com.splwg.ccb.domain.customerinfo.serviceAgreement.SaSpFieldActivityCreatorData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementServicePoint_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementServicePoint_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementSpFieldActivity;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementSpFieldActivity_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementSpFieldActivity_Id;
//2015-07-24. SMiran. Defect 3255269. Start Add
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
//2015-07-24. SMiran. Defect 3255269. End Add
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCancelProcessor;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCancelProcessorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityStep;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityStep_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterRead.DifferenceBetweenRegisterReadsResults;
import com.splwg.ccb.domain.meterread.meterRead.DifferenceBetweenRegisterReadsRetriever;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.MeterReadCreator;
import com.splwg.ccb.domain.meterread.meterRead.MeterReadCreatorData;
import com.splwg.ccb.domain.meterread.meterRead.MeterReadCreatorRegisterReadData;
import com.splwg.ccb.domain.meterread.meterRead.MeterReadRemark;
import com.splwg.ccb.domain.meterread.meterRead.MeterReadRemark_DTO;
import com.splwg.ccb.domain.meterread.meterRead.MeterReadRemark_Id;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead_Id;
import com.splwg.ccb.domain.meterread.meterRead.RegisterRead;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.ServicePointMeterHistory;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.ServicePointMeterHistory_Id;*/

import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.entity.FieldActivityCancelReason;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.entity.FieldActivityCancelReason_Id;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.meterReadCycle.entity.MeterReadCycle_Id;
import com.splwg.ccb.domain.admin.meterReaderRemark.entity.MeterReaderRemark;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseGeographicLocation;
import com.splwg.ccb.domain.customerinfo.data.SaSpFieldActivityCreatorData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCancelProcessor;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCancelProcessorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_Id;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityStep;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityStep_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.data.DifferenceBetweenRegisterReadsResults;
import com.splwg.ccb.domain.meterread.common.DifferenceBetweenRegisterReadsRetriever;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.common.MeterReadCreator;
import com.splwg.ccb.domain.meterread.data.MeterReadCreatorData;
import com.splwg.ccb.domain.meterread.data.MeterReadCreatorRegisterReadData;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterReadRemark;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterReadRemark_DTO;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterReadRemark_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory_Id;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.

import com.splwg.cm.api.lookup.CustomerEventLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.meterread.meterRead.CmAmrSegment;
import com.splwg.cm.domain.meterread.meterRead.CmAmrSegment_Id;

/**
 * @author 90723
 *
 @BatchJob (modules={},rerunnable = false,
 *      toDoCreation = @ToDoCreation (drillKeyEntity = fieldActivity,
 *            sortKeys = { "BATCH_NBR"
 *                  , "FA_ID"
 *                  , "ACCT_NAME"}),
 *      softParameters = { @BatchJobSoftParameter (entityName = fieldActivityType, name = NONDISP_FA_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = ADV_DWNLD_DAYS, required = true, type = integer)
 *            , @BatchJobSoftParameter (entityName = fieldActivityType, name = DISP_FA_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = NO_OF_DAYS, required = true, type = integer)
 *            , @BatchJobSoftParameter (entityName = meterReaderRemark, name = READER_REM_CD, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = READ_SRCE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = SCHED_READ_SRCE_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = SUCC_READ_SRCE_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = MRDWNSTG_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = MRDWNSTG_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = batchControl, name = SUCC_BATCH_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (lookupName = servicePointFieldCondition, name = SP_DESIRED_STATE_FOR_MR, required = true, type = lookup)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = TOWN_CODE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = geographicType, name = GRID_CODE_GEO_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)})
 */
public class CmCompleteFAUsingSuccessionReadsBatch extends
		CmCompleteFAUsingSuccessionReadsBatch_Gen {
	
	// Soft parameters
	private FieldActivityType parmNonDispFaType;
	private BigInteger parmAdvanceDownloadDays;
	@SuppressWarnings("unused")
	private FieldActivityType parmDispFaType;
	private BigInteger parmNumberOfDays;
	@SuppressWarnings("unused")
	private MeterReaderRemark parmMeterReadRemarkCode;
	private CharacteristicType parmReadSourceCharType;
	private String parmSchedReadSourceCharVal;
	private String parmSuccReadSourceCharVal;
	private CharacteristicType parmMRDownloadStagingCharType;
	private String parmMRDownloadStagingCharVal;
	@SuppressWarnings("unused")
	private BatchControl parmSuccessionReadBatchCode;
	@SuppressWarnings("unused")
	private ServicePointFieldConditionLookup parmSpDesiredStateForMR;
	private BigInteger parmMaxErrors;
	
	@Override
	public void validateSoftParameters(boolean arg0) {
		
		// Non-dispatchable FA Type
		parmNonDispFaType = this.getParameters().getNONDISP_FA_TYPE_CD();
		
		// Advance Download Days
		parmAdvanceDownloadDays = this.getParameters().getADV_DWNLD_DAYS();
		
		// Advance Download Days must be a number greater than zero
		if (parmAdvanceDownloadDays.intValue() <= 0){
			addError(CustomMessageRepositoryMGE.commBatchParameterMustBeGreaterThanZero("Advance Download Days", parmAdvanceDownloadDays.toString()));
		}
		
		// Dispatchable FA Type
		parmDispFaType = this.getParameters().getDISP_FA_TYPE_CD();
		
		// Number of Days
		parmNumberOfDays = this.getParameters().getNO_OF_DAYS();
		
		// Number of Days must be a positive number
		if (parmNumberOfDays.intValue() < 0){
			addError(CustomMessageRepositoryMGE.commBatchParameterMustBeAPositiveNumberorDecimal("Number of Days", parmNumberOfDays.toString()));
		}
		
		// Meter Read Remark Code
		parmMeterReadRemarkCode = this.getParameters().getREADER_REM_CD();
		
		// Read Source Characteristic Type
		parmReadSourceCharType = this.getParameters().getREAD_SRCE_CHAR_TYPE();
		
		// Read Source Characteristic Type must be valid for FA entity
		validateCharTypeForEntity("Read Source Characteristic Type",parmReadSourceCharType,CharacteristicEntityLookup.constants.FIELD_ACTIVITY);
		
		// Scheduled Read Source Characteristic Value
		parmSchedReadSourceCharVal = this.getParameters().getSCHED_READ_SRCE_CHAR_VAL();
		
		// Scheduled Read Source Char Value must be valid for Read Source Char Type
		validateCharValueForCharType("Scheduled Read Source Char Val",parmSchedReadSourceCharVal,parmReadSourceCharType);
		
		// Succession Read Source Characteristic Value
		parmSuccReadSourceCharVal = this.getParameters().getSUCC_READ_SRCE_CHAR_VAL();
		
		// Succession Read Source Char Value must be valid for Read Source Char Type
		validateCharValueForCharType("Succession Read Source Char Val",parmSuccReadSourceCharVal,parmReadSourceCharType);
		
		// MR Download Staging created Char Type (Y/N)
		parmMRDownloadStagingCharType = this.getParameters().getMRDWNSTG_CHAR_TYPE();
		
		// MR Download Staging created Char Type must be valid for FA entity
		validateCharTypeForEntity("MR Download Staging created Char Type",parmMRDownloadStagingCharType,CharacteristicEntityLookup.constants.FIELD_ACTIVITY);
		
		// MR Download Staging created Char Value
		parmMRDownloadStagingCharVal = this.getParameters().getMRDWNSTG_CHAR_VAL();
		
		// MR Download Staging created Char Value must be valid for MR Download Staging created Char Type
		validateCharValueForCharType("MR Download Staging created Char Value",parmMRDownloadStagingCharVal,parmMRDownloadStagingCharType);
		
		// Succession Read Batch Code
		parmSuccessionReadBatchCode = this.getParameters().getSUCC_BATCH_CD();
		
		// SP's desired state for Meter Read
		parmSpDesiredStateForMR = this.getParameters().getSP_DESIRED_STATE_FOR_MR();
		
		// Max Errors
		parmMaxErrors = this.getParameters().getMAX_ERRORS();
		
		if (notNull(parmMaxErrors)){
			if (parmMaxErrors.intValue() <= 0){
				addError(CustomMessageRepositoryMGE.commBatchParameterMustBeGreaterThanZero("Max Errors", parmMaxErrors.toString()));
			}
		}
	}

	/**
	 * Check if Characteristic Type is valid for given Entity 
	 * @param parmDesc
	 * @param charType
	 * @param charEntity
	 */
	private void validateCharTypeForEntity(String parmDesc, CharacteristicType charType, CharacteristicEntityLookup charEntity) {

		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType,charEntity);
		if (isNull(charEntityId.getEntity())){
			addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharTypeForEntity(
					parmDesc,charType.getId().getTrimmedValue(),charEntity.getLookupValue().fetchLanguageDescription()));
		}
	}
	
	/**
	 * Check if Characteristic Value is valid for given Characteristic Type
	 * @param parmDesc
	 * @param charVal
	 * @param charType
	 */
	private void validateCharValueForCharType(String parmDesc, String charVal, CharacteristicType charType) {

		CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charType,charVal);
		if (isNull(charValueId.getEntity())){
			addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharValueForCharType(
					parmDesc, charVal, charType.getId().getTrimmedValue()));
		}
	}

	public JobWork getJobWork() {
		
		ArrayList<ThreadWorkUnit> workUnitList =  new ArrayList<ThreadWorkUnit>();
		
		StringBuilder mainQueryStr = new StringBuilder();
		mainQueryStr.append(" SELECT ");
		mainQueryStr.append("	 FA.FA_ID ");
		mainQueryStr.append(" FROM ");
		mainQueryStr.append("   CI_FA FA ");
		mainQueryStr.append(" WHERE ");
		mainQueryStr.append("   FA.FA_TYPE_CD = :faTypeCd ");
		//5482079440
	//	mainQueryStr.append("   AND FA.FA_ID like '%5479710273'  ");
		mainQueryStr.append("   AND FA.FA_STATUS_FLG = :pending ");
		mainQueryStr.append(" ORDER BY FA.FA_ID ");
		//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
		//PreparedStatement mainPrepStmt = createPreparedStatement(mainQueryStr.toString());
		PreparedStatement mainPrepStmt = createPreparedStatement(mainQueryStr.toString(), getClass().getName());
		//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
		mainPrepStmt.bindLookup("pending", FieldActivityStatusLookup.constants.PENDING);
		mainPrepStmt.bindId("faTypeCd", parmNonDispFaType.getId());
		
        // Create work unit for each record in result set
        for(SQLResultRow row : mainPrepStmt.list()){
            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId(row.getId("FA_ID", FieldActivity.class));
            workUnitList.add(workUnit);
        }
        mainPrepStmt.close();
		return createJobWorkForThreadWorkUnitList(workUnitList);
		
	}

	public Class<CmCompleteFAUsingSuccessionReadsBatchWorker> getThreadWorkerClass() {
		return CmCompleteFAUsingSuccessionReadsBatchWorker.class;
	}

	public static class CmCompleteFAUsingSuccessionReadsBatchWorker extends
			CmCompleteFAUsingSuccessionReadsBatchWorker_Gen {
		
		// Soft parameters
		private BigInteger parmAdvanceDownloadDays;
		private FieldActivityType parmDispFaType;
		private BigInteger parmNumberOfDays;
		private MeterReaderRemark parmMeterReaderRemarkCode;
		private CharacteristicType parmReadSourceCharType;
		private String parmSchedReadSourceCharVal;
		private String parmSuccReadSourceCharVal;
		private CharacteristicType parmMRDownloadStagingCharType;
		private String parmMRDownloadStagingCharVal;
		private BatchControl parmSuccessionReadBatchCode;
		private ServicePointFieldConditionLookup parmSpDesiredStateForMR;
		private BigInteger parmMaxErrors;
		// 2015-09-09. SMiran. Defect 3296586. Start Add
		private CharacteristicType parmTownCodeCharType;
		private GeographicType parmGridCodeGeoType;
		// 2015-09-09. SMiran. Defect 3296586. End Add
		
		// Work Variables		
		private FieldActivityCancelReason_Id defaultFaCancelReasonId;
		private FieldActivity_Id faId;
		private MeterConfiguration_Id meterConfigId;
		private DateTime meterConfigInstallDateTime;
		// 2015-07-24. SMiran. Defect 3255269 Start Change
		//private DateTime earliestEventDateTime;
		private DateTime dispFaSchedDateTime;
		// 2015-07-24. SMiran. Defect 3255269 End Change

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new CommitEveryUnitStrategy(this);
		}
				
		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {			
			// Get batch soft parameters
			getBatchParameters();
			// Get the FA Cancel Reason Code for Near Meter Read FA Completion
			getDefaultFaCancelReason();
		}

		private void getBatchParameters() {

			// Advance Download Days
			parmAdvanceDownloadDays = this.getParameters().getADV_DWNLD_DAYS();			
			// Dispatchable FA Type
			parmDispFaType = this.getParameters().getDISP_FA_TYPE_CD();			
			// Number of Days
			parmNumberOfDays = this.getParameters().getNO_OF_DAYS();			
			// Meter Read Remark Code
			parmMeterReaderRemarkCode = this.getParameters().getREADER_REM_CD();			
			// Read Source Characteristic Type
			parmReadSourceCharType = this.getParameters().getREAD_SRCE_CHAR_TYPE();
			// Scheduled Read Source Characteristic Value
			parmSchedReadSourceCharVal = this.getParameters().getSCHED_READ_SRCE_CHAR_VAL();
			// Succession Read Source Characteristic Value
			parmSuccReadSourceCharVal = this.getParameters().getSUCC_READ_SRCE_CHAR_VAL();
			// MR Download Staging created Char Type (Y/N)
			parmMRDownloadStagingCharType = this.getParameters().getMRDWNSTG_CHAR_TYPE();	
			// MR Download Staging Char Value
			parmMRDownloadStagingCharVal = this.getParameters().getMRDWNSTG_CHAR_VAL();
			// Succession Read Batch Code
			parmSuccessionReadBatchCode = this.getParameters().getSUCC_BATCH_CD();	
			// SP's desired state for Meter Read
			parmSpDesiredStateForMR = this.getParameters().getSP_DESIRED_STATE_FOR_MR();
			// 2015-09-09. SMiran. Defect 3296586. Start Add
			// Town Code Characteristic Type
			parmTownCodeCharType = this.getParameters().getTOWN_CODE_CHAR_TYPE();
			// Grid Code Geo Type
			parmGridCodeGeoType = this.getParameters().getGRID_CODE_GEO_TYPE();
			// 2015-09-09. SMiran. Defect 3296586. End Add
			// MAX Errors
			parmMaxErrors = this.getParameters().getMAX_ERRORS();	
			if (isNull(parmMaxErrors)){
				parmMaxErrors = this.getParameters().getSoftMaxErrors();
			}

		}
		
		private void getDefaultFaCancelReason() {
			
			StringBuilder defaultFaCancelReasonQueryStr = new StringBuilder();
			defaultFaCancelReasonQueryStr.append(" SELECT ");
			defaultFaCancelReasonQueryStr.append("	 FA_CAN_RSN_CD ");
			defaultFaCancelReasonQueryStr.append(" FROM ");
			defaultFaCancelReasonQueryStr.append("   CI_FA_CAN_RSN ");
			defaultFaCancelReasonQueryStr.append(" WHERE ");
			defaultFaCancelReasonQueryStr.append("   FACAN_SYS_DFLT_FLG = :nearMRFACompletionCanceled ");
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			//PreparedStatement defaultFaCancelReasonPrepStmt = createPreparedStatement(defaultFaCancelReasonQueryStr.toString());
			PreparedStatement defaultFaCancelReasonPrepStmt = createPreparedStatement(defaultFaCancelReasonQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			defaultFaCancelReasonPrepStmt.bindLookup("nearMRFACompletionCanceled", FieldActivitySystemDefaultLookup.constants.NEAR_MRFA_COMPLETION_CANCELED);
			SQLResultRow row = defaultFaCancelReasonPrepStmt.firstRow();
			if (isNull(row)){
				// Default Fieldwork Cancel Reason for "Near MR FA Completion canceled" is not configured.
				addError(CustomMessageRepositoryMGE.ccb010_3_defaultNmrfaFaCancelRsnMiss());
			}else{
				defaultFaCancelReasonId = (FieldActivityCancelReason_Id)row.getId("FA_CAN_RSN_CD", FieldActivityCancelReason.class);
			}
			defaultFaCancelReasonPrepStmt.close();
			
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			// Get the primary Id
			faId = (FieldActivity_Id)unit.getPrimaryId();
			
			// Check which condition the FA meets and process accordingly:
			// Either the FA Schedule date is in the future and can be skipped for now (A)
			Bool skipFA = checkIfFaIsInFuture();		
			
			if (skipFA.isFalse()){
				// Or the wait period has elapsed and we need to cancel the non-dispatchable FA and create an FA to route to G4 (B)
				Bool waitPeriodElapsed = checkWaitPeriodElapsed();
				
				if (waitPeriodElapsed.isFalse()){
					// Or we're within the wait period; check if a read exists to complete the FA (C)
					Bool faCompleted = checkWithinWaitPeriod();
					
					if (faCompleted.isFalse()){
						// Or the schedule date is within download timeframe (FA Schedule date - DWNLD-DAYS-IN-ADV) 
						// and we want to ensure that a MR download staging record exists for the FA (D)
						createDownloadStagingReadRequest();
						
				
						
					}
				}
			}
        
            return true;
		}

		private Bool checkIfFaIsInFuture() {
			
			// Calculate the scheduled download date by subtracting the number of days specified in the Advance Download Days parameter
			// from the FA's schedule date (i.e. Schedule Download Date = FA Schedule Date - P20)
			Date scheduleDownloadDate = faId.getEntity().getScheduleDateTimeStart().getDate().addDays(parmAdvanceDownloadDays.negate().intValue());
			
			// If the resultant Schedule Download Date is greater than the current batch process date, it's a future-dated FA that can be 
			// ignored; too early to create a download staging request for ITRON. Skip the FA and select the next FA to process
			if (scheduleDownloadDate.isAfter(this.getParameters().getProcessDate())){
				return Bool.TRUE;
			}
			
			return Bool.FALSE;
		}
		
		private Bool checkWaitPeriodElapsed() {
			
			Bool waitPeriodElapsed = Bool.FALSE;

			// Calculate the wait period by adding the number of days specified in the Number of Days parameter to the FA's schedule date
			// (i.e. Wait-Until Date = FA Scheduled Date + P40)
			Date waitUntilDate = faId.getEntity().getScheduleDateTimeStart().getDate().addDays(parmNumberOfDays.intValue());
			
			// If the current batch process date is greater than the resultant Wait-Until Date, the wait period has elapsed.
			// Check if a read exists to complete the FA, otherwise cancel the non-dispatchable FA and create a dispatchable FA as follows:
			if (this.getParameters().getProcessDate().isAfter(waitUntilDate)){
				// Wait Period has elapsed
				waitPeriodElapsed = Bool.TRUE;
				// Get Meter Configuration Id as of FA Schedule Date/Time
				getMeterConfig();
				// Check if a read exists between the FA Schedule Date and the Wait-Until Date 
				// (logic to check for a billable read already exists in the base batch process, MI000-GET-BILLABLE-METER-READ in CIPOSSRN)
				MeterRead_Id billableMeterReadId = getBillableMeterRead(waitUntilDate);
				
				// If a read is found and the read date does not match the FA Scheduled Date, create a prorated read (and add a meter read
				// remark to the read if P50 is provided). If the read date is the same as the FA schedule date, no prorated read is required.
				if (notNull(billableMeterReadId)){
					if (!billableMeterReadId.getEntity().getReadDateTime().getDate().equals(faId.getEntity().getScheduleDateTimeStart().getDate())){
						billableMeterReadId = createProratedMeterRead(billableMeterReadId);
					}
					if (notNull(billableMeterReadId)){ // This contains either billable read or the prorated read 
						// Complete the non-dispatchable FA using the read.
						completeFa(billableMeterReadId);
					}else{// Prorated read is null. No previous read or Register count is not the same between current and previous read
						cancelNonDispatchableFA();
						createDispatchableFA();
					}
				}else{
					// If a read is not found, cancel the non-dispatchable FA using the FA cancel reason linked to the "Near MR FA Completion canceled"
					// system event...
					cancelNonDispatchableFA();
					// ... and create a dispatchable FA using similar logic as in the fieldwork creation algorithm
					createDispatchableFA();					
				}								
			}
			
			return waitPeriodElapsed;
		}
		
		private Bool checkWithinWaitPeriod() {
			
			Bool faCompleted = Bool.FALSE;

			// Calculate the wait period by adding the number of days specified in the Number of Days parameter to the FA's schedule date
			// (i.e. Wait-Until Date = FA Scheduled Date + P40)
			Date waitUntilDate = faId.getEntity().getScheduleDateTimeStart().getDate().addDays(parmNumberOfDays.intValue());
			
			// If the current batch process date is equal to or less than the resultant Wait-Until Date, we're within the wait period.
			if (this.getParameters().getProcessDate().isSameOrBefore(waitUntilDate)){
				// Get Meter Configuration Id as of FA Schedule Date/Time
				getMeterConfig();
				// Check if a billable read exists to complete the FA 
				MeterRead_Id billableMeterReadId = getBillableMeterRead(waitUntilDate);

				if (notNull(billableMeterReadId)){
					completeFa(billableMeterReadId);
					faCompleted = Bool.TRUE;
				}							
			}
			
			return faCompleted;
		}
		
		private void getMeterConfig() {
			
			StringBuilder meterConfigQueryStr = new StringBuilder();
			meterConfigQueryStr.append(" SELECT ");
			meterConfigQueryStr.append("   VW.MTR_CONFIG_ID ");
			meterConfigQueryStr.append("   , VW.INSTALL_DTTM ");
			meterConfigQueryStr.append(" FROM ");
			meterConfigQueryStr.append("   CI_CFG_SPMR_VW VW ");
			meterConfigQueryStr.append(" WHERE ");
			meterConfigQueryStr.append("   VW.SP_ID = :spId ");
			meterConfigQueryStr.append("   AND VW.INSTALL_DTTM = ");
			meterConfigQueryStr.append("   		(SELECT MAX (INSTALL_DTTM) ");
			meterConfigQueryStr.append("		 FROM CI_CFG_SPMR_VW CFG ");
			meterConfigQueryStr.append("		 WHERE CFG.SP_ID = :spId ");
			meterConfigQueryStr.append("		 AND CFG.INSTALL_DTTM <= :installDateTime) ");
			meterConfigQueryStr.append("   AND (VW.REMOVAL_DTTM IS NULL OR VW.REMOVAL_DTTM = ");
			meterConfigQueryStr.append("		(SELECT MIN (REMOVAL_DTTM) ");
			meterConfigQueryStr.append("		 FROM CI_CFG_SPMR_VW CFG ");
			meterConfigQueryStr.append("		 WHERE CFG.SP_ID = :spId ");
			meterConfigQueryStr.append("		 AND CFG.REMOVAL_DTTM >= :removalDateTime)) ");
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			//PreparedStatement meterConfigPrepStmt = createPreparedStatement(meterConfigQueryStr.toString());
			PreparedStatement meterConfigPrepStmt = createPreparedStatement(meterConfigQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			meterConfigPrepStmt.bindId("spId", faId.getEntity().getServicePoint().getId());
			// Use FA Schedule Date and MAX Time for :installDateTime
			meterConfigPrepStmt.bindDateTime("installDateTime", new DateTime(faId.getEntity().getScheduleDateTimeStart().getDate(),Time.MAX));
			// Use FA Schedule Date and MIN Time for :removalDateTime			
			meterConfigPrepStmt.bindDateTime("removalDateTime", new DateTime(faId.getEntity().getScheduleDateTimeStart().getDate(),Time.MIN));
			
			SQLResultRow row = meterConfigPrepStmt.firstRow();
			if (isNull(row)){
				// Meter Configuration not found for Field Activity (%1).
				//addError(CustomMessageRepositoryMGE.ccb010_3_mtrConfigMiss(faId.getTrimmedValue()),FieldActivity.properties.getReferencingProperty());
				meterConfigId = null;
				meterConfigInstallDateTime = null;
			}else{
				meterConfigId = (MeterConfiguration_Id)row.getId("MTR_CONFIG_ID", MeterConfiguration.class);
				meterConfigInstallDateTime = row.getDateTime("INSTALL_DTTM");
			}
			meterConfigPrepStmt.close();

		}
		
		private MeterRead_Id getBillableMeterRead(Date waitUntilDate) {
			
			// Return Meter Read Id
			MeterRead_Id meterReadId = null;
			
			StringBuilder billableMeterReadQueryStr = new StringBuilder();
			billableMeterReadQueryStr.append(" SELECT ");
			billableMeterReadQueryStr.append("	 MR.MR_ID ");
			billableMeterReadQueryStr.append(" FROM ");
			billableMeterReadQueryStr.append("   CI_MR MR ");
			billableMeterReadQueryStr.append(" WHERE ");
			billableMeterReadQueryStr.append("   MR.MTR_CONFIG_ID = :meterConfigId ");
			billableMeterReadQueryStr.append("	 AND MR.USE_ON_BILL_SW = :useOnBillSw ");
			billableMeterReadQueryStr.append("	 AND MR.READ_DTTM = ");
			billableMeterReadQueryStr.append("		(SELECT MIN (READ_DTTM) ");
			billableMeterReadQueryStr.append("		 FROM CI_MR MRV ");
			billableMeterReadQueryStr.append("		 WHERE MRV.MTR_CONFIG_ID = :meterConfigId ");
			billableMeterReadQueryStr.append("		 AND MRV.USE_ON_BILL_SW = :useOnBillSw ");
			billableMeterReadQueryStr.append("		 AND MRV.READ_DTTM BETWEEN :startReadDttm AND :endReadDttm ");
			billableMeterReadQueryStr.append("		 AND EXISTS ");
			billableMeterReadQueryStr.append("			(SELECT 'X' ");
			billableMeterReadQueryStr.append("			 FROM CI_REG_READ RGRD ");
			billableMeterReadQueryStr.append("			 WHERE RGRD.MR_ID = MRV.MR_ID ");
			billableMeterReadQueryStr.append("			 AND RGRD.READ_TYPE_FLG IN (:verified, :regular, :customer)) ");
			billableMeterReadQueryStr.append("		 AND NOT EXISTS ");
			billableMeterReadQueryStr.append("			(SELECT 'X' ");
			billableMeterReadQueryStr.append("			 FROM CI_REG_READ RGRD ");
			billableMeterReadQueryStr.append("			 WHERE RGRD.MR_ID = MRV.MR_ID ");
			billableMeterReadQueryStr.append("			 AND RGRD.READ_TYPE_FLG NOT IN (:verified, :regular, :customer)))");
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			//PreparedStatement billableMeterReadPrepStmt = createPreparedStatement(billableMeterReadQueryStr.toString());
			PreparedStatement billableMeterReadPrepStmt = createPreparedStatement(billableMeterReadQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			billableMeterReadPrepStmt.bindId("meterConfigId", meterConfigId);
			billableMeterReadPrepStmt.bindBoolean("useOnBillSw", Bool.TRUE);
			// Look for billable meter read between FA Schedule Date
			billableMeterReadPrepStmt.bindDateTime("startReadDttm", new DateTime(faId.getEntity().getScheduleDateTimeStart().getDate(),Time.MIN));	
			// ... and Wait Until Date
			billableMeterReadPrepStmt.bindDateTime("endReadDttm", new DateTime(waitUntilDate,Time.MAX));
			billableMeterReadPrepStmt.bindLookup("verified", ReadTypeLookup.constants.VERIFIED);
			billableMeterReadPrepStmt.bindLookup("regular", ReadTypeLookup.constants.REGULAR);
			billableMeterReadPrepStmt.bindLookup("customer", ReadTypeLookup.constants.CUSTOMER_READ);
			
			SQLResultRow row = billableMeterReadPrepStmt.firstRow();
			if (notNull(row)){
				meterReadId = (MeterRead_Id)row.getId("MR_ID", MeterRead.class);
			}
			billableMeterReadPrepStmt.close();
			
			return meterReadId;
		}		
		
		private MeterRead_Id createProratedMeterRead(MeterRead_Id billableMeterReadId) {

			MeterRead_Id proratedMeterReadId = null;
			
			// Retrieve Previous Billable Meter Read
			MeterRead_Id previousMeterReadId = getPreviousMeterRead();
			
			// If no previous read was found
			if (isNull(previousMeterReadId)){
				return null;
			}		
			
			// If number of registers between current and previous reads is not the same
			if (billableMeterReadId.getEntity().getRegisterReadList().size() 
					!= previousMeterReadId.getEntity().getRegisterReadList().size()){
				return null;
			}
			
			// Compute Number of Days from Previous read to FA Schedule Date Time
			int daysDiffPrevAndFA = (int)previousMeterReadId.getEntity().getReadDateTime().getDate()
					.difference(faId.getEntity().getScheduleDateTimeStart().getDate()).getDays();
			if (daysDiffPrevAndFA > 1){
				daysDiffPrevAndFA = daysDiffPrevAndFA - 1;
			}
			
			// Compute Number of Days difference between previous and current reads
			int daysDiffPrevAndCurr = (int)previousMeterReadId.getEntity().getReadDateTime().getDate()
					.difference(billableMeterReadId.getEntity().getReadDateTime().getDate()).getDays();
			if (daysDiffPrevAndCurr > 1){
				daysDiffPrevAndCurr = daysDiffPrevAndCurr - 1;
			}
			
			// Prepare Register Read Collection
			List<MeterReadCreatorRegisterReadData> regReadDataList = new ArrayList<MeterReadCreatorRegisterReadData>();
			
			// Prorate each register read
			Iterator<RegisterRead> currReadIter = billableMeterReadId.getEntity().getRegisterReads().iterator();
			while (currReadIter.hasNext()){
				RegisterRead currRegRead = currReadIter.next();
				Iterator<RegisterRead> prevReadIter = previousMeterReadId.getEntity().getRegisterReads().iterator();
				while (prevReadIter.hasNext()){
					RegisterRead prevRegRead = prevReadIter.next();
					if (currRegRead.getRegister().getId().equals(prevRegRead.getRegister().getId())){
						if (prevRegRead.getRegisterReading().compareTo(currRegRead.getRegisterReading()) == 1){
							// Proration is not allowed if a rollover occurs
							// System Prorated meter read cannot be created. Field Activity (%1) is not complete.
							addError(CustomMessageRepositoryMGE.ccb010_3_proratedReadInv(faId.getTrimmedValue())
									,FieldActivity.properties.getReferencingProperty());
						//  81481 kiran 01/12/2018
							logError(CustomMessageRepositoryMGE.ccb010_3_proratedReadInv(faId.getTrimmedValue()));							
						//  81481 kiran 01/12/2018
						}
						// Compute usage
						DifferenceBetweenRegisterReadsRetriever diff = DifferenceBetweenRegisterReadsRetriever.Factory.newInstance();
						DifferenceBetweenRegisterReadsResults diffResult 
								= diff.retrieveDifferenceBetweenRegisterReads(
										currRegRead.getRegister()
										, prevRegRead.getRegisterReading()
										, currRegRead.getRegisterReading()
										, currRegRead.getRegister().getNumberOfDigitsLeft()
										, BigDecimal.ZERO);
						// Prorate Usage = (Difference of reads * Nbr of days from Prev Read to FA Sched Date) / Nbr of days from Prev Read to Curr Read
						BigDecimal proratedUsage = diffResult.getDifference().multiply(BigDecimal.valueOf(daysDiffPrevAndFA))
								.divide(BigDecimal.valueOf(daysDiffPrevAndCurr));
						// Prorated Read
						BigDecimal proratedReading = currRegRead.getRegister().calculateEndRegisterRead(
								prevRegRead.getRegisterReading()
								, proratedUsage
								, currRegRead.getRegister().getRegisterConstant());
						// Store prorated read to local collection
						MeterReadCreatorRegisterReadData regReadData = MeterReadCreatorRegisterReadData.Factory.newInstance();
						regReadData.setIsHighLowReviewed(Bool.FALSE);
						regReadData.setReadType(ReadTypeLookup.constants.SYSTEM_PRORATE);
						regReadData.setReadSequence(currRegRead.getRegister().getSeq());
						regReadData.setRegisterReading(proratedReading);
						regReadDataList.add(regReadData);						
					}
				}
			}
			
			// Add prorated meter read
			MeterReadCreator mrCreator = MeterReadCreator.Factory.newInstance();
			MeterReadCreatorData mrCreatorData = MeterReadCreatorData.Factory.newInstance(); 
			mrCreatorData.setCanStoreEstimatedRead(Bool.FALSE);
			mrCreatorData.setCanUseOnBill(Bool.TRUE);
			mrCreatorData.setIsInstallationRead(Bool.FALSE);
			mrCreatorData.setIsTrended(Bool.FALSE);
			mrCreatorData.setReadDateTime(faId.getEntity().getScheduleDateTimeStart());
			mrCreatorData.setRegisterReadDataList(regReadDataList);
			MeterRead proratedRead = mrCreator.addMeterRead(meterConfigId.getEntity(), mrCreatorData);
			proratedMeterReadId = proratedRead.getId();
			
			// Add a meter read remark if P50 is supplied
			if (notNull(parmMeterReaderRemarkCode)){
				MeterReadRemark_Id meterReadRemarkId = new MeterReadRemark_Id(parmMeterReaderRemarkCode.getId(),proratedMeterReadId);
				MeterReadRemark_DTO mrRDto = createDTO(MeterReadRemark.class);
				mrRDto.setId(meterReadRemarkId);
				if (parmMeterReaderRemarkCode.getIsEligibleForProcessing().isTrue()){
					mrRDto.setIsEligibleForProcessing(Bool.TRUE);
					mrRDto.setMeterReadRemarkStatus(MeterReadRemarkStatusLookup.constants.PENDING);
				}
				mrRDto.newEntity();
			}
			
			return proratedMeterReadId;
		}
		
		private MeterRead_Id getPreviousMeterRead() {
			
			// Return Meter Read Id
			MeterRead_Id meterReadId = null;
			
			StringBuilder previousMeterReadQueryStr = new StringBuilder();
			previousMeterReadQueryStr.append(" SELECT ");
			previousMeterReadQueryStr.append("	 MR.MR_ID ");
			previousMeterReadQueryStr.append(" FROM ");
			previousMeterReadQueryStr.append("   CI_MR MR ");
			previousMeterReadQueryStr.append(" WHERE ");
			previousMeterReadQueryStr.append("   MR.MTR_CONFIG_ID = :meterConfigId ");
			previousMeterReadQueryStr.append("	 AND MR.USE_ON_BILL_SW = :useOnBillSw ");
			previousMeterReadQueryStr.append("	 AND MR.READ_DTTM = ");
			previousMeterReadQueryStr.append("		(SELECT MAX (READ_DTTM) ");
			previousMeterReadQueryStr.append("		 FROM CI_MR MRV ");
			previousMeterReadQueryStr.append("		 WHERE MRV.MTR_CONFIG_ID = :meterConfigId ");
			previousMeterReadQueryStr.append("		 AND MRV.USE_ON_BILL_SW = :useOnBillSw ");
			previousMeterReadQueryStr.append("		 AND MRV.READ_DTTM BETWEEN :startReadDttm AND :endReadDttm ");
			previousMeterReadQueryStr.append("		 AND EXISTS ");
			previousMeterReadQueryStr.append("			(SELECT 'X' ");
			previousMeterReadQueryStr.append("			 FROM CI_REG_READ RGRD ");
			previousMeterReadQueryStr.append("			 WHERE RGRD.MR_ID = MRV.MR_ID ");
			previousMeterReadQueryStr.append("			 AND RGRD.READ_TYPE_FLG IN (:verified, :regular, :customer)) ");
			previousMeterReadQueryStr.append("		 AND NOT EXISTS ");
			previousMeterReadQueryStr.append("			(SELECT 'X' ");
			previousMeterReadQueryStr.append("			 FROM CI_REG_READ RGRD ");
			previousMeterReadQueryStr.append("			 WHERE RGRD.MR_ID = MRV.MR_ID ");
			previousMeterReadQueryStr.append("			 AND RGRD.READ_TYPE_FLG NOT IN (:verified, :regular, :customer)))");
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			//PreparedStatement previousMeterReadPrepStmt = createPreparedStatement(previousMeterReadQueryStr.toString());
			PreparedStatement previousMeterReadPrepStmt = createPreparedStatement(previousMeterReadQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			previousMeterReadPrepStmt.bindId("meterConfigId", meterConfigId);
			previousMeterReadPrepStmt.bindBoolean("useOnBillSw", Bool.TRUE);
			// Meter Config Install Date Time and MIN Time
			previousMeterReadPrepStmt.bindDateTime("startReadDttm", new DateTime(meterConfigInstallDateTime.getDate(),Time.MIN));
			// FA Schedule Date and MAX Time
			previousMeterReadPrepStmt.bindDateTime("endReadDttm", new DateTime(faId.getEntity().getScheduleDateTimeStart().getDate(),Time.MAX));
			previousMeterReadPrepStmt.bindLookup("verified", ReadTypeLookup.constants.VERIFIED);
			previousMeterReadPrepStmt.bindLookup("regular", ReadTypeLookup.constants.REGULAR);
			previousMeterReadPrepStmt.bindLookup("customer", ReadTypeLookup.constants.CUSTOMER_READ);
			
			SQLResultRow row = previousMeterReadPrepStmt.firstRow();
			if (notNull(row)){
				meterReadId = (MeterRead_Id)row.getId("MR_ID", MeterRead.class);
			}
			previousMeterReadPrepStmt.close();
			return meterReadId;
		}
		
		private void completeFa(MeterRead_Id billableMeterReadId) {

			// Update SA_SP with Meter Read. Get all start/stop SA_SP that is linked to this FA
			List<SQLResultRow> saSpFaList = getSaSpFa();
			Iterator<SQLResultRow> saSpFaListIter = saSpFaList.iterator();
			while (saSpFaListIter.hasNext()){
				SQLResultRow saSpFaRow = saSpFaListIter.next();
				// Get SA_SP_ID
				ServiceAgreementServicePoint_Id saSpId = (ServiceAgreementServicePoint_Id)saSpFaRow.getId("SA_SP_ID", ServiceAgreementServicePoint.class);
				// Get SA SP FA Type
				ServiceAgreementSpFaTypeLookup saSpFaType = saSpFaRow.getLookup("SA_SP_FA_TYPE_FLG", ServiceAgreementSpFaTypeLookup.class);
				// Update SA_SP
				ServiceAgreementServicePoint_DTO saSpDTO = saSpId.getEntity().getDTO();
				if (saSpFaType.isStartActivity()){
					saSpDTO.setStartMeterReadId(billableMeterReadId);
				}
				if (saSpFaType.isStopActivity()){
					saSpDTO.setStopMeterReadId(billableMeterReadId);
				}			
				saSpId.getEntity().setDTO(saSpDTO);
			}
			
			// Update FA Step
	        for (FieldActivityStep fieldActivityStep : faId.getEntity().getSteps()) {
	            if (fieldActivityStep.getFaStepTypeAction().isReadMeter()) {
	                FieldActivityStep_DTO faStepDTO = fieldActivityStep.getDTO();
	                faStepDTO.setMeterReadId(billableMeterReadId);
	                faStepDTO.setExtraTCopybookFieldValue("C1_T_FA_TYPE_CD", faId.getEntity().getFieldActivityType().getId().getTrimmedValue());
	                fieldActivityStep.setDTO(faStepDTO);
	                break;
	            }
	        }
			
			// Complete the FA
	        faId.getEntity().complete();
			
		}		

		private List<SQLResultRow> getSaSpFa() {

			StringBuilder saSpFaQueryStr = new StringBuilder();
			saSpFaQueryStr.append(" SELECT ");
			saSpFaQueryStr.append("   SASPFA.SA_SP_ID ");
			saSpFaQueryStr.append("   , SASPFA.SA_SP_FA_TYPE_FLG ");
			saSpFaQueryStr.append("   , SASP.SA_ID ");
			saSpFaQueryStr.append("   , SASP.START_DTTM ");
			saSpFaQueryStr.append(" FROM ");
			saSpFaQueryStr.append("   CI_SA_SP_FA SASPFA ");
			saSpFaQueryStr.append("   , CI_SA_SP SASP ");
			saSpFaQueryStr.append("   , CI_FA FA ");
			saSpFaQueryStr.append(" WHERE ");
			saSpFaQueryStr.append("   SASPFA.FA_ID = :faId ");
			saSpFaQueryStr.append("   AND SASPFA.SA_SP_FA_TYPE_FLG = :saSpFaTypeFlag1 ");
			saSpFaQueryStr.append("   AND FA.FA_ID = SASPFA.FA_ID ");
			saSpFaQueryStr.append("	AND FA.FA_TYPE_CD = :faTypeCd ");
			saSpFaQueryStr.append("	AND SASP.SA_SP_ID = SASPFA.SA_SP_ID ");
			saSpFaQueryStr.append("	UNION SELECT SASPFA.SA_SP_ID ");
			saSpFaQueryStr.append("   , SASPFA.SA_SP_FA_TYPE_FLG ");
			saSpFaQueryStr.append("   , SASP.SA_ID ");
			saSpFaQueryStr.append("   , SASP.STOP_DTTM ");
			saSpFaQueryStr.append(" FROM ");
			saSpFaQueryStr.append("   CI_SA_SP_FA SASPFA ");
			saSpFaQueryStr.append("   , CI_SA_SP SASP ");
			saSpFaQueryStr.append("   , CI_FA FA ");
			saSpFaQueryStr.append(" WHERE ");
			saSpFaQueryStr.append("   SASPFA.FA_ID = :faId ");
			saSpFaQueryStr.append("   AND SASPFA.SA_SP_FA_TYPE_FLG = :saSpFaTypeFlag2 ");
			saSpFaQueryStr.append("   AND FA.FA_ID = SASPFA.FA_ID ");
			saSpFaQueryStr.append("	AND FA.FA_TYPE_CD = :faTypeCd ");
			saSpFaQueryStr.append("	AND SASP.SA_SP_ID = SASPFA.SA_SP_ID ");
			saSpFaQueryStr.append("	ORDER BY 4 DESC ");
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			//PreparedStatement saSpFaPrepStmt = createPreparedStatement(saSpFaQueryStr.toString());
			PreparedStatement saSpFaPrepStmt = createPreparedStatement(saSpFaQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			saSpFaPrepStmt.bindId("faId", faId);
			saSpFaPrepStmt.bindId("faTypeCd", faId.getEntity().getFieldActivityType().getId());
			saSpFaPrepStmt.bindLookup("saSpFaTypeFlag1", ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
			saSpFaPrepStmt.bindLookup("saSpFaTypeFlag2", ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
			List<SQLResultRow> rowList = saSpFaPrepStmt.list();
			saSpFaPrepStmt.close();
			
			return rowList;
		}

		private void cancelNonDispatchableFA() {		
			
			// Cancel FA
			FieldActivityCancelProcessorData faCanProcData = FieldActivityCancelProcessorData.Factory.newInstance();
			faCanProcData.setFieldActivity(faId.getEntity());
			// Set Cancel Reason to system default for "Near MR FA Completion canceled"
			faCanProcData.setCancelReason(defaultFaCancelReasonId.getEntity());
			// Set switch to check intermediate status to Prevent Cancellation
			faCanProcData.setMustIgnoreExternalSystemCheck(Bool.TRUE);
			FieldActivityCancelProcessor faCanProcessor = FieldActivityCancelProcessor.Factory.newInstance();
			faCanProcessor.cancel(faCanProcData);
			
		}
		
		private void createDispatchableFA() {
			
			// 2015-07-24. SMiran. Defect 3255269. Start Change
			//// Get Earliest Event Date Time
			//earliestEventDateTime = getEarliestEventDateTime();
			// Instead of using the Earliest Event Date/Time, set the Dispatchable FA's scheduled date to the next work date
			CisDivision premCisDivision = faId.getEntity().getServicePoint().getPremise().fetchDivision();
			if (isNull(premCisDivision)){
				ServicePoint faSp = faId.getEntity().getServicePoint();
				Premise faPremise = faSp.getPremise();
				addError(CustomMessageRepositoryMGE.ccb010_3_cisDivisionMiss(faId.getTrimmedValue()
						, faSp.getId().getTrimmedValue()
						, faPremise.getId().getTrimmedValue()));
			}
			WorkCalendar workCalendar = premCisDivision.getWorkCalendar();
			dispFaSchedDateTime = new DateTime(workCalendar.addBusinessDays(getProcessDateTime().getDate(), 1),Time.MIN);
			// 2015-07-24. SMiran. Defect 3255269. End Change

			// Check if the SP's condition still matches the SP's desired state for Meter Read
			ServicePointFieldConditionLookup spCondition = faId.getEntity().getServicePoint().determineFieldCondition();				
			
			// ...if not, create a dispatchable FA using the FA Type Profile
	        if (!spCondition.equals(parmSpDesiredStateForMR)) {	      
	            createFieldActivityViaFieldActivityTypeProfile();
	        }
			// Otherwise, create an FA with necessary steps using the Dispatchable FA Type (P30) and link the newly created FA to the SA/SP
	        else{
	        	createFieldActivityAndLinkToSaSp();
	        }
	            
		}
		
		// 2015-07-24. SMiran. Defect 3255269. Start Delete
		//private DateTime getEarliestEventDateTime() {
		//	
		//	StringBuilder earliestEventDttmQueryStr = new StringBuilder();
		//	earliestEventDttmQueryStr.append(" SELECT ");
		//	earliestEventDttmQueryStr.append("   SASP.START_DTTM ");
		//	earliestEventDttmQueryStr.append(" FROM ");
		//	earliestEventDttmQueryStr.append("   CI_SA_SP_FA SASPFA ");
		//	earliestEventDttmQueryStr.append("   , CI_SA_SP SASP ");
		//	earliestEventDttmQueryStr.append(" WHERE ");
		//	earliestEventDttmQueryStr.append("   SASPFA.FA_ID = :faId ");
		//	earliestEventDttmQueryStr.append("   AND SASPFA.SA_SP_FA_TYPE_FLG = :saSpFaTypeFlag1 ");
		//	earliestEventDttmQueryStr.append("   AND SASP.SA_SP_ID = SASPFA.SA_SP_ID ");
		//	earliestEventDttmQueryStr.append("   UNION SELECT SASP.STOP_DTTM ");
		//	earliestEventDttmQueryStr.append("   FROM CI_SA_SP_FA SASPFA ");
		//	earliestEventDttmQueryStr.append("   ,  CI_SA_SP SASP ");
		//	earliestEventDttmQueryStr.append("   WHERE SASPFA.FA_ID = :faId ");
		//	earliestEventDttmQueryStr.append("   AND SASPFA.SA_SP_FA_TYPE_FLG = :saSpFaTypeFlag2 ");
		//	earliestEventDttmQueryStr.append("   AND SASP.SA_SP_ID = SASPFA.SA_SP_ID ");
		//	earliestEventDttmQueryStr.append("   ORDER BY 1 ");
		//	
		//	PreparedStatement earliestPrepStmt = createPreparedStatement(earliestEventDttmQueryStr.toString());
		//	earliestPrepStmt.bindId("faId", faId);
		//	earliestPrepStmt.bindLookup("saSpFaTypeFlag1", ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
		//	earliestPrepStmt.bindLookup("saSpFaTypeFlag2", ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
		//	SQLResultRow row = earliestPrepStmt.firstRow();
		//	earliestPrepStmt.close();
		//	if (isNull(row)){
		//		// If there is no earliest event date, this means that the FA is not linked to any SA/SP Start or Stop - show an error.
		//		// Field activity %1 is not linked to any SA/SP start or stop.
		//		addError(CustomMessageRepositoryMGE.ccb010_3_faNoSaSp(faId.getTrimmedValue()),FieldActivity.properties.getReferencingProperty());
		//	}
		//	
		//	return row.getDateTime("START_DTTM");
		//}
		// 2015-07-24. SMiran. Defect 3255269. End Delete

		private void createFieldActivityViaFieldActivityTypeProfile() {

			// Determine if back-to-back
			Bool isBackToBack = Bool.FALSE;
			
			// Count Start
			int startCount = checkBackToBack(ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
			
			// Count Stop
			int stopCount = checkBackToBack(ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
			
			if (startCount > 0 && stopCount > 0){
				isBackToBack = Bool.TRUE;
			}		
			
			// Get the SA/SPs where the canceled FA was linked to. These are the same SA/SPs that the new FA will be linked to
			Bool isFaCreated = Bool.FALSE;
			ServiceAgreementServicePoint_Id previousSaSpId = null;
			ServiceAgreementSpFaTypeLookup previousSaSpFaType = null;
			List<SQLResultRow> saSpFaList = getSaSpFa();
			Iterator<SQLResultRow> saSpFaListIter = saSpFaList.iterator();
			while (saSpFaListIter.hasNext()){
				SQLResultRow currentSaSpFaRow = saSpFaListIter.next();
				// Get SA_SP_ID
				ServiceAgreementServicePoint_Id saSpId 
						= (ServiceAgreementServicePoint_Id)currentSaSpFaRow.getId("SA_SP_ID", ServiceAgreementServicePoint.class);
				// Get SA SP FA Type
				ServiceAgreementSpFaTypeLookup saSpFaType 
						= currentSaSpFaRow.getLookup("SA_SP_FA_TYPE_FLG", ServiceAgreementSpFaTypeLookup.class);
				if (isFaCreated.isTrue()){
					linkFa(previousSaSpId, previousSaSpFaType, saSpId, saSpFaType);
				}else{
			    	SaSpFieldActivityCreatorData data = SaSpFieldActivityCreatorData.Factory.newInstance();
			        data.setServiceAgreementSpFaType(saSpFaType);
			        data.setIsBackToBack(isBackToBack);
			        if (saSpFaType.isStartActivity()){
			        	data.setCustomerEvent(CustomerEventLookup.constants.START_SERVICE);
			        }
			        if (saSpFaType.isStopActivity()){
			        	data.setCustomerEvent(CustomerEventLookup.constants.STOP_SERVICE);
			        }
			        if (isBackToBack.isTrue()){
			        	data.setCustomerEvent(CustomerEventLookup.constants.START_STOP);
			        }
					// 2015-07-24. SMiran. Defect 3255269. Start Change
			        //data.setScheduledDateTime(earliestEventDateTime);
			        data.setScheduledDateTime(dispFaSchedDateTime);
					// 2015-07-24. SMiran. Defect 3255269. End Change
			        data.setFieldActivityCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);        
			        data.setIsFaCollectionRequired(Bool.FALSE);		        
			        saSpId.getEntity().addFieldActivity(data);
			        isFaCreated = data.getIsFaCreated();
				}
				previousSaSpId = saSpId;
				previousSaSpFaType = saSpFaType;
			}
			
		}			

		private void linkFa(ServiceAgreementServicePoint_Id previousSaSpId, ServiceAgreementSpFaTypeLookup previousSaSpFaType
				, ServiceAgreementServicePoint_Id currentSaSpId, ServiceAgreementSpFaTypeLookup currentSaSpFaType) {

			List<SQLResultRow> faRows = getPendingFAs(previousSaSpId, previousSaSpFaType); 
			Iterator<SQLResultRow> faRowsIter = faRows.iterator();
			while (faRowsIter.hasNext()){
				// Get FA Id
				SQLResultRow row = faRowsIter.next();
				FieldActivity_Id faId = (FieldActivity_Id)row.getId("FA_ID", FieldActivity.class);
				ServiceAgreementSpFieldActivity_DTO saSpFaDto = createDTO(ServiceAgreementSpFieldActivity.class);
				ServiceAgreementSpFieldActivity_Id saSpFaId = new ServiceAgreementSpFieldActivity_Id(currentSaSpId, faId);
				saSpFaDto.setId(saSpFaId);
				saSpFaDto.setFieldActivityType(currentSaSpFaType);
				saSpFaDto.setServiceAgreementId(currentSaSpId.getEntity().getServiceAgreement().getId());
				saSpFaDto.setServicePointId(currentSaSpId.getEntity().getServicePoint().getId());
				saSpFaDto.newEntity();
			}			
			
		}

		private List<SQLResultRow> getPendingFAs(ServiceAgreementServicePoint_Id saSpId, ServiceAgreementSpFaTypeLookup saSpFaType) {

			StringBuilder faQueryStr = new StringBuilder();
			faQueryStr.append(" SELECT ");
			faQueryStr.append("   SASPFA.FA_ID ");
			faQueryStr.append(" FROM ");
			faQueryStr.append("   CI_SA_SP_FA SASPFA ");
			faQueryStr.append("   , CI_FA FA ");
			faQueryStr.append(" WHERE ");
			faQueryStr.append("   SASPFA.SA_SP_ID = :saSpId ");
			faQueryStr.append("   AND SASPFA.SA_SP_FA_TYPE_FLG = :saSpFaTypeFlag ");
			faQueryStr.append("   AND FA.FA_ID = SASPFA.FA_ID ");
			faQueryStr.append("   AND FA.FA_STATUS_FLG = :faStatusFlag ");
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			//PreparedStatement faPrepStmt = createPreparedStatement(faQueryStr.toString());
			PreparedStatement faPrepStmt = createPreparedStatement(faQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			faPrepStmt.bindId("saSpId", saSpId);
			faPrepStmt.bindLookup("saSpFaTypeFlag", saSpFaType);
			faPrepStmt.bindLookup("faStatusFlag", FieldActivityStatusLookup.constants.PENDING);
			List<SQLResultRow> rowList = faPrepStmt.list();
			faPrepStmt.close();
			
			return rowList;
		}

		private int checkBackToBack(ServiceAgreementSpFaTypeLookup saSpFaTypeFlag) {

			StringBuilder bToBQueryStr = new StringBuilder();
			bToBQueryStr.append(" SELECT ");
			bToBQueryStr.append("   COUNT(*) SASPCNT ");
			bToBQueryStr.append(" FROM ");
			bToBQueryStr.append("   CI_SA_SP_FA SASPFA ");
			bToBQueryStr.append(" WHERE ");
			bToBQueryStr.append("   SASPFA.FA_ID = :faId ");
			bToBQueryStr.append("   AND SASPFA.SA_SP_FA_TYPE_FLG = :saSpFaTypeFlag ");
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			//PreparedStatement bToBPrepStmt = createPreparedStatement(bToBQueryStr.toString());
			PreparedStatement bToBPrepStmt = createPreparedStatement(bToBQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			bToBPrepStmt.bindId("faId", faId);
			bToBPrepStmt.bindLookup("saSpFaTypeFlag", saSpFaTypeFlag);
			
			SQLResultRow row = bToBPrepStmt.firstRow();
			bToBPrepStmt.close();
			
			return row.getInteger("SASPCNT").intValue();
		}

		private void createFieldActivityAndLinkToSaSp() {

	    	FieldActivity_DTO fieldActivityDTO = new FieldActivity_DTO();
	        fieldActivityDTO.setServicePointId(faId.getEntity().getServicePoint().getId());
	        fieldActivityDTO.setFieldActivityTypeId(parmDispFaType.getId());
			// 2015-07-24. SMiran. Defect 3255269. Start Change
	        //fieldActivityDTO.setScheduleDateTimeStart(earliestEventDateTime);
	        fieldActivityDTO.setScheduleDateTimeStart(dispFaSchedDateTime);
			// 2015-07-24. SMiran. Defect 3255269. End Change
	        fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);
	        
	        FieldActivityCreatorData data = FieldActivityCreatorData.Factory.newInstance();
	        data.setFaDTO(fieldActivityDTO);
	        
	        FieldActivity fieldActivity = FieldActivityCreator.Factory.newInstance().addFieldActivity(data);
	        
			List<SQLResultRow> saSpFaList = getSaSpFa();
			Iterator<SQLResultRow> saSpFaListIter = saSpFaList.iterator();
			while (saSpFaListIter.hasNext()){
				SQLResultRow saSpFaRow = saSpFaListIter.next();
				// Get SA_SP_ID
				ServiceAgreementServicePoint_Id saSpId = (ServiceAgreementServicePoint_Id)saSpFaRow.getId("SA_SP_ID", ServiceAgreementServicePoint.class);
				// Get SA SP FA Type
				ServiceAgreementSpFaTypeLookup saSpFaType = saSpFaRow.getLookup("SA_SP_FA_TYPE_FLG", ServiceAgreementSpFaTypeLookup.class);
				// Link FA
				ServiceAgreementSpFieldActivity_DTO saSpFaDto = createDTO(ServiceAgreementSpFieldActivity.class);
				ServiceAgreementSpFieldActivity_Id saSpFaId = new ServiceAgreementSpFieldActivity_Id(saSpId, fieldActivity.getId());
				saSpFaDto.setId(saSpFaId);
				saSpFaDto.setFieldActivityType(saSpFaType);
				saSpFaDto.setServiceAgreementId(saSpId.getEntity().getServiceAgreement().getId());
				saSpFaDto.setServicePointId(saSpId.getEntity().getServicePoint().getId());
				saSpFaDto.newEntity();
			}
			
		}
		
		private void createDownloadStagingReadRequest() {
			
			Bool skipFA = Bool.FALSE;

			// Calculate the earliest day we can send the read request as (Earliest Download Date = FA Schedule Date - ADV-DWNLD-DAYS).
			Date earliestDownloadDate = faId.getEntity().getScheduleDateTimeStart().getDate().addDays(parmAdvanceDownloadDays.negate().intValue());
			
			// Get the CIS Division
			CisDivision_Id cisDivisionId = faId.getEntity().getServicePoint().getPremise().getDivisionId();
			if (isNull(cisDivisionId)){
				// CIS Division not found for Field Activity (%1); Service Point Id %2, Premise ID %3.
				addError(CustomMessageRepositoryMGE.ccb010_3_cisDivisionMiss(
						faId.getTrimmedValue()
						, faId.getEntity().getServicePoint().getId().getTrimmedValue()
						, faId.getEntity().getServicePoint().getPremise().getId().getTrimmedValue()),FieldActivity.properties.getReferencingProperty());
			}
			
			Bool isEarliestDLDateWorkDay = Bool.FALSE;
			// If this is not a work day for the CIS Division use the work day prior to this date.
			while (isEarliestDLDateWorkDay.isFalse()){
				if (!cisDivisionId.getEntity().getWorkCalendar().isBusinessDay(earliestDownloadDate)){
					earliestDownloadDate = earliestDownloadDate.addDays(BigInteger.ONE.negate().intValue());
				}else{
					isEarliestDLDateWorkDay = Bool.TRUE;
				}
			}
			
			// Check if the process date is within the download timeframe, i.e. process date >= Earliest Download Date
			if (this.getParameters().getProcessDate().isSameOrAfter(earliestDownloadDate)){
				// If so, we want to ensure that a MR download staging record exists for the FA. 
				// Check first the non-dispatchable FA's read source, i.e. characteristic on FA that matches characteristic type defined in 
				// batch parameter P60. If the read source characteristic value is "Schedule Route Read", there's no need to create a download
				// staging record. This will be created by the standard MR download batch jobs. Skip the FA and select the next FA to process.
				String readSourceCharVal = getFaChar(parmReadSourceCharType);
				if (readSourceCharVal.trim().equals(parmSchedReadSourceCharVal.trim())){
					skipFA = Bool.TRUE;
				}
				
				if (skipFA.isFalse()){
					// If the read source characteristic value is "Succession Read", 
					if (readSourceCharVal.trim().equals(parmSuccReadSourceCharVal.trim())){
						// Check if MR download staging record has already been created for the FA
						int countMR = countMRDownloadStagingChar();
						// If a download staging record does not exist for the FA, create one.
						if (countMR == 0){
																			
							
							createMRDownloadStaging();

							// Add the char to indicate the MR download staging record has already been created for the FA
							addFAChar(parmMRDownloadStagingCharType,parmMRDownloadStagingCharVal);
							
						}
					}
				}
			}
			
		}

		private String getFaChar(CharacteristicType parmReadSourceCharType) {
			
			String charVal = "";
			
			StringBuilder faCharQueryStr = new StringBuilder();
			faCharQueryStr.append(" SELECT ");
			faCharQueryStr.append("   FAC.SRCH_CHAR_VAL ");
			faCharQueryStr.append(" FROM ");
			faCharQueryStr.append("   CI_FA_CHAR FAC ");
			faCharQueryStr.append(" WHERE ");
			faCharQueryStr.append("   FAC.FA_ID = :faId ");
			faCharQueryStr.append("   AND FAC.CHAR_TYPE_CD = :charTypeCd ");
			faCharQueryStr.append("   AND SEQ_NUM = (SELECT MAX(FAC2.SEQ_NUM) ");
			faCharQueryStr.append("		 FROM CI_FA_CHAR FAC2 ");
			faCharQueryStr.append("		 WHERE FAC2.FA_ID = FAC.FA_ID ");
			faCharQueryStr.append("		 AND FAC2.CHAR_TYPE_CD = FAC.CHAR_TYPE_CD) ");
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			//PreparedStatement faCharPrepStmt = createPreparedStatement(faCharQueryStr.toString());
			PreparedStatement faCharPrepStmt = createPreparedStatement(faCharQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			faCharPrepStmt.bindId("faId", faId);
			faCharPrepStmt.bindId("charTypeCd", parmReadSourceCharType.getId());
			
			SQLResultRow row = faCharPrepStmt.firstRow();
			faCharPrepStmt.close();
			
			if (notNull(row)){
				charVal = row.getString("SRCH_CHAR_VAL");
			}
			
			return charVal;
			
		}
		
		
		private int countMRDownloadStagingChar() {

			StringBuilder countMRQueryStr = new StringBuilder();
			countMRQueryStr.append(" SELECT ");
			countMRQueryStr.append("   NVL(COUNT(*),0) AS MRCOUNT ");
			countMRQueryStr.append(" FROM ");
			countMRQueryStr.append("   CI_FA_CHAR FAC ");
			countMRQueryStr.append(" WHERE ");
			countMRQueryStr.append("   FAC.FA_ID = :faId ");
			countMRQueryStr.append("   AND FAC.CHAR_TYPE_CD = :charTypeCd ");
			countMRQueryStr.append("   AND FAC.CHAR_VAL = :charVal ");
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			//PreparedStatement countMRPrepStmt = createPreparedStatement(countMRQueryStr.toString());
			PreparedStatement countMRPrepStmt = createPreparedStatement(countMRQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			countMRPrepStmt.bindId("faId", faId);
			countMRPrepStmt.bindId("charTypeCd", parmMRDownloadStagingCharType.getId());
			countMRPrepStmt.bindString("charVal", parmMRDownloadStagingCharVal.trim(), "CHAR_VAL");
			
			SQLResultRow row = countMRPrepStmt.firstRow();
			countMRPrepStmt.close();
			return row.getInteger("MRCOUNT").intValue();
			
		}
		
		private void createMRDownloadStaging() {
			String error = null;
			// Scheduled Selection Date
			Date scheduledSelectionDate = faId.getEntity().getScheduleDateTimeStart().getDate().addDays(parmAdvanceDownloadDays.negate().intValue());			
			
			// Get meter read cycle from SP
			MeterReadCycle_Id mrCycleId = faId.getEntity().getServicePoint().getMeterReadCycleId();
			if (isNull(mrCycleId)){
				// Meter Read Cycle not found for Field Activity (%1); Service Point Id %2.
				addError(CustomMessageRepositoryMGE.ccb010_3_mrCycleMiss(faId.getTrimmedValue()
						, faId.getEntity().getServicePoint().getId().getTrimmedValue())
						, FieldActivity.properties.getReferencingProperty());
			}
			
			// 2015-08-26. SMiran. Defect 3290686. Start Add
			// Verify that the calculated selection date does not exist on the MR Schedule Table
			scheduledSelectionDate = verifySelectionDate(mrCycleId, scheduledSelectionDate);
			// 2015-08-26. SMiran. Defect 3290686. End Add
			
			// Get meter read route from SP
			String meterReadRoute = faId.getEntity().getServicePoint().getMeterReadRoute();
			if (isEmptyOrNull(meterReadRoute.trim())){
				// Meter Read Route not found for Field Activity (%1); Service Point Id %2.
				addError(CustomMessageRepositoryMGE.ccb010_3_mrRouteMiss(faId.getTrimmedValue()
						, faId.getEntity().getServicePoint().getId().getTrimmedValue())
						, FieldActivity.properties.getReferencingProperty());
			}
			
	        // 2015-09-02. SMiran. Defect 3296586. Start Change
			// Override meter read route with day of month + succession territory
			// Day of month
			int dayOfMonth = faId.getEntity().getScheduleDateTimeStart().getDate().getDay();
			String dayOfMonthStr = String.valueOf(dayOfMonth);
			if (dayOfMonth < 10){
				dayOfMonthStr = "0" + dayOfMonthStr;
			}
			// Succession Territory
			String successionTerritory = getSuccessionTerritory();
			
			// Format Sucession Territory
			if (successionTerritory.length() == 1){
				successionTerritory = "00" + successionTerritory;
			}else if (successionTerritory.length() == 2){
				successionTerritory = "0" + successionTerritory;
			}
			
			// Concatenate day of month and succession territory
			meterReadRoute = dayOfMonthStr + successionTerritory;
	        // 2015-09-02. SMiran. Defect 3296586. End Change
			
			// Get SP Meter History Id
			ServicePointMeterHistory_Id spMeterHistoryId = getSpMeterHistoryId();
			if (isNull(spMeterHistoryId)){
				// SP Meter History not found for Field Activity (%1); Service Point Id %2.
				addError(CustomMessageRepositoryMGE.ccb010_3_spmhMiss(faId.getTrimmedValue()
						, faId.getEntity().getServicePoint().getId().getTrimmedValue())
						, FieldActivity.properties.getReferencingProperty());
			}
			
			//try{

			
			// Kiran try to check if the record already exists
			
/*			StringBuilder countMRStage = new StringBuilder();
			
			countMRStage.append(" SELECT ");
			countMRStage.append("   CI_MR.MR_CYC_CD ");
			countMRStage.append(" FROM ");
			countMRStage.append("   CI_MR_STAGE_DWN CI_MR ");
			countMRStage.append(" WHERE ");
			countMRStage.append("   CI_MR.MR_CYC_CD = :mrCycCd ");
			countMRStage.append("   AND CI_MR.SCHED_SEL_DT = :schedSelDt ");
			countMRStage.append("   AND CI_MR.MR_RTE_CD = :mrRteCd ");
			countMRStage.append("   AND CI_MR.SP_MTR_HIST_ID = :spMtrHistId ");	
				// Insert into MR Download Staging table
			PreparedStatement countMRStagePrepStmt = createPreparedStatement(countMRStage.toString(), getClass().getName());

			countMRStagePrepStmt.bindString("mrCycCd", "99", "MR_CYC_CD");

			countMRStagePrepStmt.bindDate("schedSelDt", scheduledSelectionDate);
			countMRStagePrepStmt.bindString("mrRteCd", meterReadRoute.trim(),"MR_RTE_CD");
			countMRStagePrepStmt.bindId("spMtrHistId", spMeterHistoryId);
			
			SQLResultRow row = countMRStagePrepStmt.firstRow();
			countMRStagePrepStmt.close();
			//Kiran
			if (notNull(row)){
				failedToInsert = Bool.TRUE;
				//logError(CustomMessageRepositoryMGE.commGenericError("Error"));
				logMessage(CustomMessageRepositoryMGE.commGenericError("Error"), MessageSeverityLookup.constants.WARNING);
			} //kiran
*/			

			try{
				StringBuilder insertString = new StringBuilder("");
				insertString.append("INSERT INTO ");
				insertString.append(  "CI_MR_STAGE_DWN ");
				insertString.append(  "( ");
				insertString.append(    "MR_CYC_CD ");
				insertString.append(    ", SCHED_SEL_DT ");
				insertString.append(    ", MR_RTE_CD ");
				insertString.append(    ", SP_MTR_HIST_ID ");
				insertString.append(    ", BATCH_CD ");
				insertString.append(    ", BATCH_NBR ");
				insertString.append(  ") VALUES ( ");
				insertString.append(    ":mrCycCd ");
				insertString.append(    ", :schedSelDt ");
				insertString.append(    ", :mrRteCd ");
				insertString.append(    ", :spMtrHistId ");
				insertString.append(    ", :batchCd ");
				insertString.append(    ", :batchNbr ");
				insertString.append(  ")");
				//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
				//PreparedStatement insertSQL = createPreparedStatement(insertString.toString());
				PreparedStatement insertSQL = createPreparedStatement(insertString.toString(), getClass().getName());
				//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
				// 2015-09-02. SMiran. Defect 3296586. Start Change
				//insertSQL.bindId("mrCycCd", mrCycleId);
				insertSQL.bindString("mrCycCd", "99", "MR_CYC_CD");
				// 2015-09-02. SMiran. Defect 3296586. End Change
				insertSQL.bindDate("schedSelDt", scheduledSelectionDate);
				insertSQL.bindString("mrRteCd", meterReadRoute.trim(),"MR_RTE_CD");
				insertSQL.bindId("spMtrHistId", spMeterHistoryId);
				insertSQL.bindId("batchCd", parmSuccessionReadBatchCode.getId());
				insertSQL.bindBigInteger("batchNbr", parmSuccessionReadBatchCode.getNextBatchNumber());
				insertSQL.execute();
				insertSQL.close();
			}
		
			
			catch(Exception e)
			{
				//  81481 kiran 01/12/2018 Instead of throwing JAVA Exception error raise actual error.
				
				String error_insert;
				
				error_insert = "Error executing INSERT into CI_MR_STAGE_DWN for" + " mrCycCd : 99," + "schedSelDt : " + scheduledSelectionDate + ",mrRteCd:" + meterReadRoute.trim() + ",spMtrHistId" + spMeterHistoryId;
			//	logMessage(error_insert, MessageSeverityLookup.constants.ERROR);
			//	logMessage(CustomMessageRepositoryMGE.commGenericError(error_insert), MessageSeverityLookup.constants.ERROR);
			//	logMessage(CustomMessageRepositoryMGE.commGenericError(e.getMessage().substring(261,550)), MessageSeverityLookup.constants.ERROR);
			//	logMessage(CustomMessageRepositoryMGE.commGenericError(e.getMessage().substring(551,800)), MessageSeverityLookup.constants.ERROR);
				logMessage(CustomMessageRepository.nm0049ApplicationError(error_insert), MessageSeverityLookup.constants.ERROR);
			//ni0011_4_ErrorInFile
			}
		}
		//  81481 kiran 01/12/2018
        // 2015-09-02. SMiran. Defect 3296586. Start Add
		private String getSuccessionTerritory() {

			String townCodeStr = "";
			String gridCodeStr = "";
			String successionTerritoryStr = "";
			
			// Get FA's premise
			Premise premise = faId.getEntity().getServicePoint().getPremise();
			
			// Raise error if premise does not have town code
			PremiseCharacteristic premTownCodeChar = premise.getEffectiveCharacteristic(parmTownCodeCharType);
			if (isNull(premTownCodeChar)){
				addError(CustomMessageRepositoryMGE.ccb010_3_premTownCodeMiss(premise.getId().getTrimmedValue()));
			}else{
				CharacteristicTypeLookup charTypeFlag = parmTownCodeCharType.getCharacteristicType();
				if (charTypeFlag.isPredefinedValue()){
					townCodeStr = premTownCodeChar.getCharacteristicValue().trim();
				}else if (charTypeFlag.isForeignKeyValue()){
					townCodeStr = premTownCodeChar.getCharacteristicValueForeignKey1().trim();
				}else{
					townCodeStr = premTownCodeChar.getAdhocCharacteristicValue().trim();
				}
			}
			
			// Raise error if premise does not have grid code
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			//ListFilter listFilter = premise.getGeographicLocations().createFilter("WHERE this.id.geographicType = :gridCodeGeoType ");
			ListFilter listFilter = premise.getGeographicLocations().createFilter(
					"WHERE this.id.geographicType = :gridCodeGeoType ", getClass().getName());
			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			listFilter.bindEntity("gridCodeGeoType", parmGridCodeGeoType);
			PremiseGeographicLocation premGeoLoc = (PremiseGeographicLocation)listFilter.firstRow();
			
			if (isNull(premGeoLoc)){
				addError(CustomMessageRepositoryMGE.ccb010_3_premGridCodeMiss(premise.getId().getTrimmedValue()));
			}else{
				gridCodeStr = premGeoLoc.getGeographicValue().trim();
			}
			
			// Get succession territory from CM_AMR_SEGMENT table using the premise town code and premise grid code
			CmAmrSegment_Id cmAmrSegmentId = new CmAmrSegment_Id(townCodeStr, gridCodeStr);
			
			// Set succession territory to zero if the town code and grid code does not exist in AMR Segment Table or if the combination does not have
			// Succession Territory
			CmAmrSegment cmAmrSegment = cmAmrSegmentId.getEntity();
			if (isNull(cmAmrSegment) || isNull(cmAmrSegment.getCmSuccessionTerritory()) || cmAmrSegment.getCmSuccessionTerritory().intValue() == 0){
				successionTerritoryStr = "0";
			}else{
				successionTerritoryStr = cmAmrSegment.getCmSuccessionTerritory().toString().trim();
			}
			
			return successionTerritoryStr;
		}
        // 2015-09-02. SMiran. Defect 3296586. End Add

		// 2015-08-26. SMiran. Defect 3290686. Start Add
		private Date verifySelectionDate(MeterReadCycle_Id mrCycleId, Date scheduledSelectionDate) {			

			Bool selectionDateExistsInMrSched = Bool.TRUE;
			
			// Subtract 1 day while this selection date exists in the MR Schedule table
			do{
		    	StringBuilder stringBuilder = new StringBuilder();
		        stringBuilder.append("SELECT ");
		        stringBuilder.append(  "MR.MR_CYC_CD ");
		        stringBuilder.append("FROM ");
		        stringBuilder.append(  "CI_MR_SCHED MR ");
		        stringBuilder.append("WHERE ");
		        stringBuilder.append(  "MR.MR_CYC_CD = :meterCycleId ");
		        stringBuilder.append(  "AND MR.SCHED_SEL_DT = :selectionDate ");
		        //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
		        //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
		        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		        //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
		        preparedStatement.bindId("meterCycleId", mrCycleId);
		        preparedStatement.bindDate("selectionDate", scheduledSelectionDate);
		        
		        SQLResultRow sqlResultRow = preparedStatement.firstRow();		        
		        preparedStatement.close();
		        
		        if (notNull(sqlResultRow)){
		        	scheduledSelectionDate = scheduledSelectionDate.addDays(-1);
		        }else{
		        	selectionDateExistsInMrSched = Bool.FALSE;
		        }		        
				
			}while(selectionDateExistsInMrSched.isTrue());
			
			return scheduledSelectionDate;
		}
		// 2015-08-26. SMiran. Defect 3290686. End Add

		private ServicePointMeterHistory_Id getSpMeterHistoryId() {

			ServicePointMeterHistory_Id spMhId = null;
			
			StringBuilder spMhQueryStr = new StringBuilder();
			spMhQueryStr.append(" SELECT ");
			spMhQueryStr.append("   SPMH.SP_MTR_HIST_ID ");
			spMhQueryStr.append(" FROM ");
			spMhQueryStr.append("   CI_SP_MTR_HIST SPMH ");
			spMhQueryStr.append(" WHERE ");
			spMhQueryStr.append("   SPMH.SP_ID = :spId ");
			spMhQueryStr.append("   AND (SPMH.REMOVAL_DTTM IS NULL OR SPMH.REMOVAL_DTTM >= :processDateTime) ");
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			//PreparedStatement spMhPrepStmt = createPreparedStatement(spMhQueryStr.toString());
			PreparedStatement spMhPrepStmt = createPreparedStatement(spMhQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			spMhPrepStmt.bindId("spId", faId.getEntity().getServicePoint().getId());
			spMhPrepStmt.bindDateTime("processDateTime", this.getProcessDateTime());
			SQLResultRow row = spMhPrepStmt.firstRow();
			spMhPrepStmt.close();
			
			if (notNull(row)){
				spMhId = (ServicePointMeterHistory_Id)row.getId("SP_MTR_HIST_ID", ServicePointMeterHistory.class);
			}
			
			return spMhId;
		}		
		

		private void addFAChar(CharacteristicType charType, String charVal) {

			FieldActivityCharacteristic_DTO faCharDto = createDTO(FieldActivityCharacteristic.class);
			FieldActivityCharacteristic_Id faCharId = new FieldActivityCharacteristic_Id(faId,charType.getId(),BigInteger.ONE);
			faCharDto.setId(faCharId);
			CharacteristicTypeLookup charTypeFlag = charType.getCharacteristicType();
			if (charTypeFlag.isForeignKeyValue()){
				faCharDto.setCharacteristicValue(charVal.trim());
			}else if (charTypeFlag.isPredefinedValue()){
				faCharDto.setCharacteristicValue(charVal.trim());
			}else{
				faCharDto.setAdhocCharacteristicValue(charVal.trim());
			}
			faCharDto.newEntity();
			
		}
        
		public ToDoProperties createToDoProperties(ThreadWorkUnit unit) {

			FieldActivity_Id faId = (FieldActivity_Id)unit.getPrimaryId();
			String accountNameStr = "";
			Account_Id accountId = getSaSpAccount(faId);			
			if (notNull(accountId)){
				accountNameStr = accountId.getEntity().fetchInformation();
			}
			ToDoProperties toDoProperties = new ToDoProperties(faId);
			toDoProperties.setBATCH_NBR(this.getBatchNumber().toString());
			toDoProperties.setFA_ID(faId.getTrimmedValue());
			toDoProperties.setACCT_NAME(accountNameStr);
			
			return toDoProperties;
		}

		private Account_Id getSaSpAccount(FieldActivity_Id faId) {
			
			StringBuilder acctSaSpQueryStr = new StringBuilder();
			acctSaSpQueryStr.append(" SELECT ");
			acctSaSpQueryStr.append("   DISTINCT SA.ACCT_ID ");
			acctSaSpQueryStr.append(" FROM ");
			acctSaSpQueryStr.append("   CI_SA SA ");
			acctSaSpQueryStr.append("   ,CI_SA_SP_FA SASPFA ");
			acctSaSpQueryStr.append("   ,CI_FA FA ");
			acctSaSpQueryStr.append(" WHERE ");
			acctSaSpQueryStr.append("   FA.FA_ID = :faId ");
			acctSaSpQueryStr.append("   AND SASPFA.FA_ID = FA.FA_ID ");
			acctSaSpQueryStr.append("   AND SA.SA_ID = SASPFA.SA_ID ");
			acctSaSpQueryStr.append("   AND SA.SA_STATUS_FLG = :saStatusFlag ");
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			//PreparedStatement acctSaSpPrepStmt = createPreparedStatement(acctSaSpQueryStr.toString());
			PreparedStatement acctSaSpPrepStmt = createPreparedStatement(acctSaSpQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			acctSaSpPrepStmt.bindId("faId", faId);
			acctSaSpPrepStmt.bindLookup("saStatusFlag", ServiceAgreementStatusLookup.constants.ACTIVE);
			SQLResultRow row = acctSaSpPrepStmt.firstRow();
			acctSaSpPrepStmt.close();

			if (notNull(row)){
				return (Account_Id)row.getId("ACCT_ID", Account.class);
			}else{
				return null;
			}			
			
		}        

	}

}
