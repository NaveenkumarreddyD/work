/*
 **************************************************************************
 *                Confidentiality Information:                    
 *                                                                
 * This module is the confidential and proprietary information of 
 * Oracle Corporation; it is not to be copied, reproduced, or         
 * transmitted in any form, by any means, in whole or in part,    
 * nor is it to be used for any purpose other than that for which 
 * it is expressly provided without the written permission of     
 * Oracle Corporation.                                                
 *                                                                
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Mass Quote Cancellation Batch Process
 * 
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 201?-??-??   Srikanth Initial Version.  
 * 2013-09-17   CVB     Modified validation of characteristic value.      
 * 2013-10-29   Neha    Selection char type change to adhoc from predefined 
 * 2016-01-29  	MPang	Updated for CCB v2.4 compilation.
 * 2018-07-25   SFelip  CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                      longer needed. 
 * 2019-05-09	JHERNA	Overhaul and completely redo all coding for the 
 * 						following reasons:
 * 							- 288862. Resolve issue regarding coding standard
 * 							  for global static variable usage.
 * 							- use the BO to update the Quote (instead of
 * 							  directly updating the table via DTO which would
 * 							  prevent triggering the BO lifecycle algorithms).
 * 							- various updates for performance improvement.
 **************************************************************************
 */

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadIterationStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.BusinessObjectStatusCode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.StringId;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus_Id;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.support.schema.BusinessObjectInfo;
import com.splwg.base.support.schema.BusinessObjectInfoCache;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType_Id;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

//START CHANGES - JHERNA - 2019-05-09 - SysAid#288862
///**
// * @author sdesabhatl002
// *
// @BatchJob (multiThreaded = true, 
// *      rerunnable = false, 
// *      modules={},
// *      softParameters = { @BatchJobSoftParameter (entityName = serviceTaskType, name = QUOTE_SERVICE_TASK_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = QUOTE_ACTIVE_STATUS, required = true, type = string)
// *            , @BatchJobSoftParameter (name = QUOTE_EXPIRE_STATUS, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = TASK_SELECTION_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = TASK_SELECTION_CHAR_VALUE, required = true, type = string)})
// */
/*
public class CmMassQuoteCancellation_BatchProcess extends
CmMassQuoteCancellation_BatchProcess_Gen {

    private static ServiceTaskType quoteServiceTaskType;
    private static CharacteristicType quoteSelectionCharType;
    private static String activeStatus ;
    private static String expireStatus;
    private static String quoteSelectionCharVal;
    private static final String TASK_ID = "F1_SVC_TASK_ID";
    private static final String BO = "BUS_OBJ_CD";

    public JobWork getJobWork() {
        ServiceTask_Id svcTaskId = null;
        List<SQLResultRow> activeServiceTasks = getActiveCWRQuotes();
        ArrayList<ThreadWorkUnit> workUnitList = new ArrayList<ThreadWorkUnit>();
        for(SQLResultRow resultRow:activeServiceTasks){
            svcTaskId = (ServiceTask_Id)resultRow.getId(TASK_ID, ServiceTask.class);
            ThreadWorkUnit workUnit =  new ThreadWorkUnit(svcTaskId);
            workUnitList.add(workUnit);
        }
        return createJobWorkForThreadWorkUnitList(workUnitList);
    }

    public void validateSoftParameters(boolean isValid){
        initilaizeSoftParams();
        BigInteger parmMaxErrors = getParameters().getSoftMaxErrors();

        if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
            addError(CustomMessageRepository.na0086IntegerParamCannotBeNegative(parmMaxErrors.toString().trim()));
        }
        
        // 2013-09-17 - CVB - Start
        if (quoteSelectionCharType.getCharacteristicType().isPredefinedValue()) {
        	// 2013-09-17 - CVB - End
        	CharacteristicValue_Id quoteCharValId = new CharacteristicValue_Id(quoteSelectionCharType.getId(),quoteSelectionCharVal.trim());
        	if(isNull(quoteCharValId.getEntity())){
                addError(CustomMessageRepository.na0086InvalidCharEntity(quoteSelectionCharType.getId().getIdValue(),quoteSelectionCharVal.trim()));  
            }
        	// 2013-09-17 - CVB - Start
        }
        // 2013-09-17 - CVB - End
        
        validateInputBOStatus();
    }

    private void validateInputBOStatus(){
        List<SQLResultRow> resultBOList = getValidBOForTaskType();
        BusinessObject_Id boId =null;
        for(SQLResultRow resultRow : resultBOList){
            boId = (BusinessObject_Id)resultRow.getId(BO, BusinessObject.class);
            validateInputStatus(boId);
        }
    }

    private void validateInputStatus(BusinessObject_Id boId){
        boolean isExists = false;
        BusinessObjectStatus quoteActiveStatus = new BusinessObjectStatus_Id(boId,activeStatus).getEntity();
        if(isNull(quoteActiveStatus)){
            addError(CustomMessageRepository.na0086InvalidInputBOStatus(activeStatus,boId.getIdValue()));
        }
        BusinessObjectStatus quoteExpireStatus = new BusinessObjectStatus_Id(boId,expireStatus).getEntity();
        if(isNull(quoteExpireStatus)){
            addError(CustomMessageRepository.na0086InvalidInputBOStatus(expireStatus,boId.getIdValue()));
        }
        BusinessObjectInfo info = BusinessObjectInfoCache.getBusinessObjectInfo(boId.getIdValue());
        Set<BusinessObjectStatusCode> nextStates = info.getAllowedStatusTransitionsFrom(new BusinessObjectStatusCode(quoteActiveStatus));
        for(BusinessObjectStatusCode statusCode :nextStates){
            if(statusCode.getStatusString().trim().equalsIgnoreCase(expireStatus)){
                isExists = true;
                break;
            }
        }
        if(!isExists)
            addError(CustomMessageRepository.na0086InvalidNextStatusSpecified(activeStatus,expireStatus,boId.getIdValue()));
    }

    private List<SQLResultRow> getValidBOForTaskType(){
        List<SQLResultRow> resultRow = null;
        StringBuilder validTaskBOQuery = new StringBuilder();
        validTaskBOQuery.append("SELECT DISTINCT TASK.BUS_OBJ_CD ") ;
        validTaskBOQuery.append("FROM F1_SVC_TASK TASK , F1_SVC_TASK_TYPE TASKTYPE ");
        validTaskBOQuery.append("WHERE  TASK.F1_STASK_TYPE_CD = :taskTypeCd ");
        validTaskBOQuery.append("AND TASK.F1_STASK_TYPE_CD = TASKTYPE.F1_STASK_TYPE_CD ");
        //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement validTaskPrepStmt = createPreparedStatement(validTaskBOQuery.toString());
        PreparedStatement validTaskPrepStmt = createPreparedStatement(validTaskBOQuery.toString(), getClass().getName());
        //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        validTaskPrepStmt.bindId("taskTypeCd", quoteServiceTaskType.getId());
        resultRow = validTaskPrepStmt.list();
        validTaskPrepStmt.close();
        return resultRow; 
    }

    private void initilaizeSoftParams(){
        quoteServiceTaskType = getParameters().getQUOTE_SERVICE_TASK_TYPE();
        quoteSelectionCharType = getParameters().getTASK_SELECTION_CHAR_TYPE();
        quoteSelectionCharVal = getParameters().getTASK_SELECTION_CHAR_VALUE().trim();
        activeStatus = getParameters().getQUOTE_ACTIVE_STATUS().trim();
        expireStatus = getParameters().getQUOTE_EXPIRE_STATUS().trim();
    }

    private List<SQLResultRow> getActiveCWRQuotes(){
        List<SQLResultRow> resultRow = null;
        StringBuilder activeSvcTaskQuery = new StringBuilder();
        activeSvcTaskQuery.append("SELECT TASK.F1_SVC_TASK_ID ") ;
        activeSvcTaskQuery.append("FROM F1_SVC_TASK TASK,F1_SVC_TASK_CHAR TASKCHAR ");
        activeSvcTaskQuery.append("WHERE TASK.F1_STASK_TYPE_CD = :taskTypeCd ");
        // CCB v2.6 Upgrade - 2018-07-25 - Start Change
        //activeSvcTaskQuery.append("AND TRIM(TASK.BO_STATUS_CD) = :activeStatus ");
        activeSvcTaskQuery.append("AND TASK.BO_STATUS_CD = :activeStatus ");
        // CCB v2.6 Upgrade - 2018-07-25 - End Change
        activeSvcTaskQuery.append("AND TASK.F1_SVC_TASK_ID = TASKCHAR.F1_SVC_TASK_ID ");
        activeSvcTaskQuery.append("AND TASKCHAR.CHAR_TYPE_CD = :inputCharType ");
		// 2013-10-29 Neha Start
        //activeSvcTaskQuery.append("AND TRIM(TASKCHAR.CHAR_VAL) = :inputCharVal ");
        // CCB v2.6 Upgrade - 2018-07-25 - Start Change
		//activeSvcTaskQuery.append("AND TRIM(TASKCHAR.ADHOC_CHAR_VAL) = :inputCharVal ");
        activeSvcTaskQuery.append("AND TASKCHAR.ADHOC_CHAR_VAL = :inputCharVal ");
		// CCB v2.6 Upgrade - 2018-07-25 - End Change
		// 2013-10-29 Neha End
		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement svcTaskPrepStmt = createPreparedStatement(activeSvcTaskQuery.toString());
		PreparedStatement svcTaskPrepStmt = createPreparedStatement(activeSvcTaskQuery.toString(), getClass().getName());
        //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        svcTaskPrepStmt.bindId("taskTypeCd", quoteServiceTaskType.getId());
        svcTaskPrepStmt.bindStringProperty("activeStatus", ServiceTask.properties.status , activeStatus);
        svcTaskPrepStmt.bindStringProperty("inputCharVal",ServiceTaskCharacteristic.properties.adhocCharacteristicValue,quoteSelectionCharVal );
        svcTaskPrepStmt.bindEntity("inputCharType",quoteSelectionCharType);

        resultRow = svcTaskPrepStmt.list();
        svcTaskPrepStmt.close();
        return resultRow;
    }

    public Class<CmMassQuoteCancellation_BatchProcessWorker> getThreadWorkerClass() {
        return CmMassQuoteCancellation_BatchProcessWorker.class;
    }

    public static class CmMassQuoteCancellation_BatchProcessWorker
    extends	CmMassQuoteCancellation_BatchProcessWorker_Gen {

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }
*/
//        /**
//         * Execute a WorkUnit and provide result details.
//         * 
//         * @param unit - a ThreadWorkUnit
//         * @return a boolean that describes the success or failure of the work unit processing.
//         * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
//         * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
//         * This work unit creates the Field Activity.
//         */
/*
        public boolean executeWorkUnit(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {

            ServiceTask_Id svcTaskId  = (ServiceTask_Id)unit.getPrimaryId();
            ServiceTask svcTask = svcTaskId.getEntity();
            ServiceTask_DTO svcTaskdto = null;
            startChanges();
            svcTaskdto = svcTask.getDTO();
            svcTaskdto.setStatus(expireStatus);
            svcTask.setDTO(svcTaskdto);
            saveChanges();
            return true;
        }
    }
}
*/
/**
 * @author sdesabhatl002
 *
 @BatchJob (multiThreaded = true, 
 *      rerunnable = false, 
 *      modules={},
 *      softParameters = { @BatchJobSoftParameter (entityName = serviceTaskType, name = QUOTE_SERVICE_TASK_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = QUOTE_ACTIVE_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = QUOTE_EXPIRE_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = TASK_SELECTION_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = TASK_SELECTION_CHAR_VALUE, required = true, type = string)})
 */
public class CmMassQuoteCancellation_BatchProcess 
		extends CmMassQuoteCancellation_BatchProcess_Gen {

	@Override
	public void validateSoftParameters(boolean isNewRun) {

		// Retrieve parameter Quote Service Task Type
		ServiceTaskType serviceTaskType = this.getParameters().getQUOTE_SERVICE_TASK_TYPE();
		
		Iterator<SQLResultRow> collOfBOs = getValidBOForTaskType(serviceTaskType.getId());
		
		while (collOfBOs.hasNext()) {
			
			SQLResultRow sqlRow = (SQLResultRow) collOfBOs.next();
			BusinessObject_Id quoteBOID = (BusinessObject_Id) sqlRow.getId("BUS_OBJ_CD", BusinessObject.class);
			
			// Validate parameter Quote Active Status
			String quoteActiveStatus = this.getParameters().getQUOTE_ACTIVE_STATUS();
			if (isBoStatusValid(quoteBOID, quoteActiveStatus).isFalse()) {
				addError(CustomMessageRepository.na0086InvalidInputBOStatus(quoteActiveStatus, quoteBOID.getTrimmedValue()));
			}
			// Validate parameter Quote Expired Status
			String quoteExpiredStatus = this.getParameters().getQUOTE_EXPIRE_STATUS();
			if (isBoStatusValid(quoteBOID, quoteExpiredStatus).isFalse()) {
				addError(CustomMessageRepository.na0086InvalidInputBOStatus(quoteExpiredStatus, quoteBOID.getTrimmedValue()));
			}
			// Ensure that expire status is a valid next state of the active status
			Bool isValidNextStatus = Bool.FALSE;
			BusinessObjectInfo info = BusinessObjectInfoCache.getBusinessObjectInfo(quoteBOID.getTrimmedValue());
			Set<BusinessObjectStatusCode> nextStates = info.getAllowedStatusTransitionsFrom(new BusinessObjectStatusCode(new BusinessObjectStatus_Id(quoteBOID, quoteActiveStatus)));
			for(BusinessObjectStatusCode statusCode :nextStates){
				if(statusCode.getStatusString().trim().equalsIgnoreCase(quoteExpiredStatus)){
					isValidNextStatus = Bool.TRUE;
					break;
				}
			}
			if(isValidNextStatus.isFalse()) {
				addError(CustomMessageRepository.na0086InvalidNextStatusSpecified(quoteActiveStatus,quoteExpiredStatus, quoteBOID.getTrimmedValue()));
			}     
		}
		  
		// Validate parameter Selection Char Type
		CharacteristicType selectionCharType = this.getParameters().getTASK_SELECTION_CHAR_TYPE();
		CharacteristicEntity_Id charEntityID = new CharacteristicEntity_Id(selectionCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
		if (isNull(charEntityID.getEntity())) {
			addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharTypeForEntity("Selection Char Type", selectionCharType.getId().getTrimmedValue(), "Service Task"));
		}
		// Validate parameter Selection Char Value only if the batch parameter selection char type is a predefined characteristic
		if (selectionCharType.getCharacteristicType().isPredefinedValue()) {
			String selectionCharValue = this.getParameters().getTASK_SELECTION_CHAR_VALUE();
			CharacteristicValue_Id charValueID = new CharacteristicValue_Id(selectionCharType, selectionCharValue.trim());
			if (isNull(charValueID.getEntity())) {
				addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharValueForCharType("Selection Char Value", selectionCharValue, selectionCharType.getId().getTrimmedValue()));
			}
		}
		// Validate maxErrors parameter
        BigInteger parmMaxErrors = getParameters().getSoftMaxErrors();

        if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
            addError(CustomMessageRepository.na0086IntegerParamCannotBeNegative(parmMaxErrors.toString().trim()));
        }
	}    
	
    private Iterator<SQLResultRow> getValidBOForTaskType(ServiceTaskType_Id serviceTaskTypeID){

    	Iterator<SQLResultRow> returnValue = new ArrayList<SQLResultRow>().iterator();
    	
    	StringBuilder stringBuilder = new StringBuilder();
    	stringBuilder.append("SELECT DISTINCT TASK.BUS_OBJ_CD ");
    	stringBuilder.append("FROM F1_SVC_TASK TASK , F1_SVC_TASK_TYPE TASKTYPE ");
    	stringBuilder.append("WHERE  TASK.F1_STASK_TYPE_CD = :taskTypeCd ");
    	stringBuilder.append("AND TASK.F1_STASK_TYPE_CD = TASKTYPE.F1_STASK_TYPE_CD ");
    	PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==getValidBOForTaskType==");
    	prepState.bindId("taskTypeCd", serviceTaskTypeID);
    	prepState.setAutoclose(false);
    	prepState.execute();
    	if (notNull(prepState.firstRow())) {
    		returnValue = prepState.list().iterator();
    	}
    	prepState.close();
    	return returnValue;
    }
	
	private Bool isBoStatusValid(BusinessObject_Id boID, String status) {

		Bool returnValue = Bool.FALSE;
		if (notNull(boID)
				&& notBlank(status)){

			PreparedStatement prepState = createPreparedStatement(
					"SELECT 'X' " +
							"FROM F1_BUS_OBJ_STATUS " +
							"WHERE BUS_OBJ_CD = :boID " +
							"AND BO_STATUS_CD = '"+status.trim()+"' " 
							,"==validateBoStatus==");
			prepState.bindId("boID", boID);
			prepState.setAutoclose(false);
			prepState.execute();
			if (notNull(prepState.firstRow())) {
				returnValue = Bool.TRUE;
			}
			prepState.close();
		}
		return returnValue;
	}

	public Class<CmMassQuoteCancellation_BatchProcessWorker> getThreadWorkerClass() {
		return CmMassQuoteCancellation_BatchProcessWorker.class;
	}

	/*===========*/
	/*INNER CLASS*/
	/*===========*/
	public static class CmMassQuoteCancellation_BatchProcessWorker
			extends	CmMassQuoteCancellation_BatchProcessWorker_Gen {
		/*=================*/
		/* Soft Parameters */
		/*=================*/
		private ServiceTaskType parmQuoteServiceTaskType;
		private String parmActiveStatus;
		private String parmExpireStatus;
		private CharacteristicType parmCharTypeSelection;
		private String parmCharValSelection;

		public ThreadExecutionStrategy createExecutionStrategy() {
			//return new StandardCommitStrategy(this);
			return new ThreadIterationStrategy(this);
		}        
    	
		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful,
				ThreadWorkUnit lastWorkUnit) throws ThreadAbortedException,
				RunAbortedException {

			parmQuoteServiceTaskType = this.getParameters().getQUOTE_SERVICE_TASK_TYPE();
			parmActiveStatus = this.getParameters().getQUOTE_ACTIVE_STATUS();
			parmExpireStatus = this.getParameters().getQUOTE_EXPIRE_STATUS();
			parmCharTypeSelection = this.getParameters().getTASK_SELECTION_CHAR_TYPE();
			parmCharValSelection = this.getParameters().getTASK_SELECTION_CHAR_VALUE();

			this.startResultRowQueryIteratorForThread(ServiceTask_Id.class);
		}    	

		@SuppressWarnings("rawtypes")
		@Override
		protected QueryIterator getQueryIteratorForThread(StringId lowID,
				StringId highID) {

			PreparedStatement prepState = createPreparedStatement(
					"SELECT QUOTE.F1_SVC_TASK_ID, QUOTE.BUS_OBJ_CD " +
							"FROM F1_SVC_TASK QUOTE, F1_SVC_TASK_CHAR QC " +
							"WHERE QUOTE.F1_STASK_TYPE_CD = :quoteSvcTaskType " + 
							"AND QUOTE.BO_STATUS_CD = '"+parmActiveStatus.trim()+"' " + 
							"AND QC.F1_SVC_TASK_ID = QUOTE.F1_SVC_TASK_ID " + 
							"AND QC.CHAR_TYPE_CD = :charTypeSelection " + 
							"AND QC.SRCH_CHAR_VAL = UPPER('"+parmCharValSelection.trim()+"') " +
							"AND QUOTE.F1_SVC_TASK_ID BETWEEN :lowID AND :highID " +							
							"ORDER BY QUOTE.F1_SVC_TASK_ID", 
					"==Main Selection Criteria==");
			prepState.bindId("quoteSvcTaskType", parmQuoteServiceTaskType.getId());
			prepState.bindId("charTypeSelection", parmCharTypeSelection.getId());
			prepState.bindId("lowID", lowID);
			prepState.bindId("highID", highID);
			prepState.setAutoclose(false);
			prepState.execute();
			return prepState.iterate();			
		}

		@Override
		protected ThreadWorkUnit getNextWorkUnit(QueryResultRow row) {

			ThreadWorkUnit twu = new ThreadWorkUnit(row.getId("F1_SVC_TASK_ID", ServiceTask.class));
			twu.addSupplementalData("quoteBOID", row.getId("BUS_OBJ_CD", BusinessObject.class));
			return twu;
		}    	               
		/*=============*/
		/* MAIN METHOD */
		/*=============*/
		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			ServiceTask_Id quoteID = (ServiceTask_Id) unit.getPrimaryId();
			BusinessObject_Id quoteBOID = (BusinessObject_Id) unit.getSupplementallData("quoteBOID");

			/*==================*/
			/* Expire the Quote */
			/*==================*/				

			// Retrieve the Quote BO Instance											
			BusinessObjectInstance boInstance = BusinessObjectInstance.create(quoteBOID.getEntity());
			boInstance.setXMLString("serviceTaskId", quoteID.getTrimmedValue());
			
			// Update the status of the quote bo instance
			BusinessObjectInstance quoteBO = BusinessObjectDispatcher.read(boInstance);
			quoteBO.setXMLString("status", parmExpireStatus.trim());

			// Commit the update
			BusinessObjectDispatcher.update(quoteBO);

			return true;
		}
	}
}
//END CHANGES - JHERNA - 2019-05-09 - SysAid#288862