/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractDetailsSADetailsRecord 
		extends ColumnDelimitedRecord{	
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractDetailsSADetailsRecord() {
		super(25);
		this.setBPPrinterKey(" ");		
		this.setBPSortKey(" ");
		this.setBPMailingKey(" ");	
		this.setSAID(" ");
		this.setOldAcctID(" ");
		this.setCustReadFlg(" ");
		this.setSicCd(" ");
		this.setSicDescr(" ");
		this.setCisDivision(" ");
		this.setSaTypeCd(" ");
		this.setSaTypeDescr(" ");
		this.setSaTypeDfltDescr(" ");
		this.setSvcTypeCd(" ");
		this.setSvcTypeDescr(" ");
		this.setRevClCd(" ");
		this.setCharPremID(" ");
		this.setSaRelID(" ");
		this.setSaRelTypeCd(" ");
		this.setSaRelTypeDescr(" ");
		this.setSprCd(" ");
		this.setSprDescr(" ");
		this.setSprEntityName(" ");
		this.setRevClDescr(" ");
		this.setContractNum(" ");
		this.setFiller();
	}
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * 
	 */
	public void setBPPrinterKey(String value) {		
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
	public void setBPSortKey(String value) {
		rightPadColumn(2, 184, truncateInput(value, 184));
	}
	public void setBPMailingKey(String value) {
		rightPadColumn(3, 15, truncateInput(value, 15));
	}	
	/*
	 * Service Agreement (List)
	 */
	public void setSAID(String value) {
		rightPadColumn(4, 10, truncateInput(value, 10));
	}
	public void setOldAcctID(String value) {
		rightPadColumn(5, 15, truncateInput(value, 15));
	}
	public void setCustReadFlg(String value) {
		rightPadColumn(6, 2, truncateInput(value, 2));
	}
	public void setSicCd(String value) {
		rightPadColumn(7, 4, truncateInput(value, 4));
	}
	public void setSicDescr(String value) {
		rightPadColumn(8, 30, truncateInput(value, 30));
	}
	public void setCisDivision(String value) {
		rightPadColumn(9, 10, truncateInput(value, 10));
	}
	public void setSaTypeCd(String value) {
		rightPadColumn(10,  8, truncateInput(value, 8));
	}
	public void setSaTypeDescr(String value) {
		rightPadColumn(11, 30, truncateInput(value, 30));
	}
	public void setSaTypeDfltDescr(String value) {
		rightPadColumn(12, 80, truncateInput(value, 80));
	}
	public void setSvcTypeCd(String value) {
		rightPadColumn(13, 2, truncateInput(value, 2));
	}
	public void setSvcTypeDescr(String value) {
		rightPadColumn(14,  30, truncateInput(value, 30));
	}
	public void setRevClCd(String value) {
		rightPadColumn(15, 8, truncateInput(value, 8));
	}
	public void setCharPremID(String value) {
		rightPadColumn(16, 10, truncateInput(value, 10));
	}
	public void setSaRelID(String value) {
		rightPadColumn(17, 10, truncateInput(value, 10));
	}
	public void setSaRelTypeCd(String value) {
		rightPadColumn(18,  8, truncateInput(value, 8));
	}
	public void setSaRelTypeDescr(String value) {
		rightPadColumn(19, 30, truncateInput(value, 30));
	}
	public void setSprCd(String value) {
		rightPadColumn(20, 12, truncateInput(value, 12));
	}
	public void setSprDescr(String value) {
		rightPadColumn(21, 50, truncateInput(value, 50));
	}
	public void setSprEntityName(String value) {
		rightPadColumn(22, 254, truncateInput(value, 254));
	}
	public void setRevClDescr(String value) {
		rightPadColumn(23, 60, truncateInput(value, 60));
	}
	public void setContractNum(String value) {
		rightPadColumn(24, 16, truncateInput(value, 16));
	}
	private void setFiller() {
		/*For some reason OLD version has this field to be only 2562 characters long; We are going to follow this instead of using base field length of 2765*/
		//rightPadColumn(25, 2765, " ");
		rightPadColumn(25, 2562, " ");
	}
}
