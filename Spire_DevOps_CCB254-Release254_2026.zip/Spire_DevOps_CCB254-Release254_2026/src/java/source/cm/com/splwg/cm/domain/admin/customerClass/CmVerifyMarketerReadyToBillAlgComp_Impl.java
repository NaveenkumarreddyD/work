/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * MGE-CCB011.002 - Transportation Billing - Verify Marketer Ready To Bill
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2015-04-08   DHUYNH          MGE-CCB011.002 Initial Version.
 * 2015-10-30	Dhuynh			SF#63955 - modify pogram to use different logic for 
 * 									startPeriodDate and endPeriodDate
 * 2016-01-25   MPang	        Updated for CCB v2.4 compilation.
 * 2017-03-23	JHERNA			SysAid#93194.
 ******************************************************************************************/
package com.splwg.cm.domain.admin.customerClass;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.ccb.api.lookup.BillEligibilityLookup;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
//Start Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.billCycle.BillCycle;
import com.splwg.ccb.domain.admin.customerClass.CustomerClass;
import com.splwg.ccb.domain.admin.customerClass.CustomerClassBillEligibilityAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementRelationshipType.ServiceAgreementRelationshipType;
import com.splwg.ccb.domain.admin.serviceProvider.ServiceProvider_Id;
import com.splwg.ccb.domain.billing.bill.Bill; 
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;*/

import com.splwg.ccb.domain.admin.billCycle.entity.BillCycle;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass;
import com.splwg.ccb.domain.admin.customerClass.algorithm.billEligibility.CustomerClassBillEligibilityAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementRelationshipType.entity.ServiceAgreementRelationshipType;
import com.splwg.ccb.domain.admin.serviceProvider.entity.ServiceProvider_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill; 
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
//End Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.common.customBusinessComponent.CmTransportationBillingRoutine;

/**
 * @author 08831
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = serviceAgreementRelationshipType, name = saRelationshipType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = marketPoolCharType, required = true, type = entity)                         
 *                             })
 */
public class CmVerifyMarketerReadyToBillAlgComp_Impl 
		extends CmVerifyMarketerReadyToBillAlgComp_Gen 
		implements CustomerClassBillEligibilityAlgorithmSpot {
	//Soft Parameters
	private ServiceAgreementRelationshipType parmSaRelationshipType;
	private CharacteristicType parmMarketPoolCharType;

	//Hard Parameters
	private Account_Id accountId;
	private Date endPeriodDate;
	private Date startPeriodDate;
	private Date cutoffDate;
	private final static CmTransportationBillingRoutine cmTransportationBillingRoutine = CmTransportationBillingRoutine.Factory.newInstance();

	protected void extraSoftParameterValidations(boolean arg0) {
		// Retrieve the Algorithm Parameters

		parmSaRelationshipType = getSaRelationshipType();
		parmMarketPoolCharType = getMarketPoolCharType();

	}

	public BillEligibilityLookup getBillEligibility() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setAccount(Account acctId) {
		// TODO Auto-generated method stub
		this.accountId = acctId.getId();
	}

	public void setAccountingDate(Date arg0) {
		// TODO Auto-generated method stub

	}

	public void setAllowEstimation(Bool arg0) {
		// TODO Auto-generated method stub

	}

	public void setBill(Bill arg0) {
		// TODO Auto-generated method stub
	}

	public void setBillCycle(BillCycle arg0) {
		// TODO Auto-generated method stub

	}

	public void setBillDate(Date arg0) {
		// TODO Auto-generated method stub

	}

	public void setBillProcessSequence(BigInteger arg0) {
		// TODO Auto-generated method stub

	}

	public void setCustomerClass(CustomerClass arg0) {
		// TODO Auto-generated method stub

	}

	public void setCutoffDate(Date arg0) {
		// TODO Auto-generated method stub
		this.cutoffDate = arg0;
	}

	public void setEstimateDate(Date arg0) {
		// TODO Auto-generated method stub

	}

	public void setServiceAgreement(ServiceAgreement sa) {
		// TODO Auto-generated method stub

	}

	public void setShouldAssignSequenceNumber(Bool arg0) {
		// TODO Auto-generated method stub

	}

	public void setShouldFreezeCompleteBill(Bool arg0) {
		// TODO Auto-generated method stub

	}

	public void setUseCutoffDate(Bool arg0) {
		// TODO Auto-generated method stub

	}

	public void setWindowEndDate(Date endPeriodDate) {
		// TODO Auto-generated method stub
		this.endPeriodDate = endPeriodDate;
	}

	public void setWindowStartDate(Date startPeriodDate) {
		// TODO Auto-generated method stub
		this.startPeriodDate = startPeriodDate;
	}

	public void invoke() {
		//get Marketer's service agreement Id (a list if its has more than one SaId)
		//for using to pass to common routine (saId is required)
		
		List<ServiceAgreement_Id> collOfMarketerSaId = getMarketerSA(accountId, parmMarketPoolCharType.getId());
		
		Iterator<ServiceAgreement_Id> iterMarketer = collOfMarketerSaId.iterator();
		
		//loop through all marketer SaId(s) to check if any endcustomer of 
		//each marketerSaId did not have frozen bill during billing period. 
		while (iterMarketer.hasNext()) {
			
			ServiceAgreement_Id saIDInCollMarketer = (ServiceAgreement_Id) iterMarketer.next();
			
			//call common routine to retrieve service provider
			ServiceProvider_Id serviceProviderID = cmTransportationBillingRoutine.getMarketerServiceProvider(saIDInCollMarketer,parmMarketPoolCharType.getId());
		
			String charValueMarketersPool = cmTransportationBillingRoutine.getCustomerPool(saIDInCollMarketer, parmMarketPoolCharType.getId());

			//call common routine to retrieve a list of endcustomer saId
			List<ServiceAgreement_Id> collectionSaId = cmTransportationBillingRoutine
				.retrieveServiceProviderEndCustomersPerPool(serviceProviderID,parmSaRelationshipType.getId(), parmMarketPoolCharType.getId(), charValueMarketersPool, 
			// START CHANGE - JHERNA - 2017-03-23 - SysAid#93194
			//			.getProcessDateTime().getDate());
						this.getProcessDateTime().getDate(),
						this.startPeriodDate,
						this.endPeriodDate);
			// END CHANGE - JHERNA - 2017-03-23 - SysAid#93194
			
			//set iter and loop all endcustomer's saIds to check if is there frozen bill during billing period?
			Iterator<ServiceAgreement_Id> iter = collectionSaId.iterator();
			while (iter.hasNext()) {				
				ServiceAgreement_Id saIDInColl = (ServiceAgreement_Id) iter.next();
				//2015-10-30. Dhuynh. SF-63955. Start Add 
				
				//get the last bill date of this marketer to use for starting period
				startPeriodDate = getLastBillEndDate(saIDInCollMarketer);
				
				//check there is a date exist otherwise using SA startdate
				if (isNull(startPeriodDate)) {
					startPeriodDate = getSaStartDateFromSA(saIDInCollMarketer);	
				}
				
				//get SA enddate to use for ending period date
				Date saEndDate = getSaEndDate (saIDInCollMarketer);		
				
				//compare SA end date and cut off date. whichever greater we will use that date for ending period date.
				if (isNull(saEndDate)) {
					endPeriodDate = cutoffDate;					
				}else{					
					if (saEndDate.compareTo(cutoffDate) > 0)
					{
						endPeriodDate = cutoffDate;
					}else{
						endPeriodDate = saEndDate;
					}													
				}
				//2015-10-30. Dhuynh. SF-63955. End Add 

				Bool continueProcess = isFrozenBillFound(saIDInColl,startPeriodDate, endPeriodDate);								
				if (continueProcess.isFalse()) {
					addError(CustomMessageRepositoryMGE.ccb011_MarketerIsNotReadyToBill(accountId.getTrimmedValue(), saIDInColl.getTrimmedValue()));
				}
			}		
	    }					
	}
	
	/** 
	 * Custom method which retrieves the marketer's service agreement's Id
	 * @param marketer account id: marketerAcctID
	 * @param parameter marketer pool char sa type: marketerPoolCharSaType
	 * @return the service agreement's Id: ServiceAgreement_Id
	 */
	public List<ServiceAgreement_Id> getMarketerSA(Account_Id marketerAcctID, CharacteristicType_Id marketerPoolCharSaType) {

		//ServiceAgreement_Id returnValue = null;
		List<ServiceAgreement_Id> returnValue = new ArrayList<ServiceAgreement_Id>();
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT SA.SA_ID								 ");
		stringBuilder.append("FROM CI_SA SA, CI_SA_CHAR SAC 				 ");
		stringBuilder.append("WHERE SA.ACCT_ID = :acctID 					 ");
		stringBuilder.append("AND (SA.SA_STATUS_FLG = :saStatusAtive		 ");
		stringBuilder.append("OR SA.SA_STATUS_FLG = :saStatusPendingStop	 ");
		stringBuilder.append("OR SA.SA_STATUS_FLG = :saStatusStopped 		 ");
		stringBuilder.append("OR SA.SA_STATUS_FLG = :saStatusReactivated) 	 ");
		stringBuilder.append("AND SA.SA_ID = SAC.SA_ID						 ");
		stringBuilder.append("AND SAC.CHAR_TYPE_CD = :marketerPoolCharSaType ");
		
		//Start Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
		prepState.bindId("acctID", marketerAcctID);
		prepState.bindId("marketerPoolCharSaType", marketerPoolCharSaType);
		prepState.bindLookup("saStatusAtive",ServiceAgreementStatusLookup.constants.ACTIVE);
		prepState.bindLookup("saStatusPendingStop",ServiceAgreementStatusLookup.constants.PENDING_STOP);
		prepState.bindLookup("saStatusStopped",ServiceAgreementStatusLookup.constants.STOPPED);
		prepState.bindLookup("saStatusReactivated",ServiceAgreementStatusLookup.constants.REACTIVATED);
		prepState.execute();
		if (prepState.list().size() > 0) {

			Iterator<SQLResultRow> iter = prepState.list().iterator();
			while (iter.hasNext()) {
				SQLResultRow sqlRow = (SQLResultRow) iter.next();
				ServiceAgreement_Id saID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
				// Add the unique SA to the collection
				if (!returnValue.contains(saID)) {
					returnValue.add(saID);
				}
			}
		} else {
			addError(CustomMessageRepositoryMGE.ccb011_UnableToFindMarketerSaidFromAcct(marketerAcctID.toString(),marketerPoolCharSaType.toString()));
		}
		prepState.close();
		return returnValue;
	}

	/** 
	 * Custom method which retrieves the service agreement's frozen bill segments
	 * which spans the period that the marketer is being billed for.
	 * @param saIdInColl service agreement
	 * @param startPeriodDate marketer's bill period start date
	 * @param endPeriodDate marketer's bill period end date
	 * @return returnValue collection of the retrieved bill segments which passes the criteria.
	 */
	private Bool isFrozenBillFound(ServiceAgreement_Id saIdInColl,
			Date startPeriodDate, Date endPeriodDate) {

		Bool isFrozenBillFound = Bool.FALSE;

		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT BSEG.BSEG_ID ");
		stringBuilder.append("FROM CI_BSEG BSEG ");
		stringBuilder.append("WHERE BSEG.SA_ID = :saIdInColl ");
		stringBuilder.append("AND BSEG.BSEG_STAT_FLG = :frozen ");
		stringBuilder.append("AND BSEG.END_DT > :startPeriodDate ");
		stringBuilder.append("AND BSEG.END_DT <= :endPeriodDate ");

		//Start Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
		prepState.bindId("saIdInColl", saIdInColl);
		prepState.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
		prepState.bindDate("startPeriodDate", startPeriodDate);
		prepState.bindDate("endPeriodDate", endPeriodDate);
		prepState.execute();

		if (prepState.list().size() > 0) {
			isFrozenBillFound = Bool.TRUE;
		}
		prepState.close();
		return isFrozenBillFound;
	}
	//	 2015-10-30. Dhuynh. SF-63955. Start Add 
	/** 
	 * Custom method which retrieves the frozen bill segments(end_date)base on marketerSaID
	 * @param marketerSaID service agreement
	 * @return returnValue last bill end_date
	 */
	private Date getLastBillEndDate(ServiceAgreement_Id marketerSaID) 
	{
		Date wStartPeriodDateBillEnd = null;
	
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT BSEG.END_DT ");
		stringBuilder.append("FROM CI_BSEG BSEG ");
		stringBuilder.append("WHERE BSEG.SA_ID = :marketerSaID ");
		stringBuilder.append("AND BSEG.BSEG_STAT_FLG = :frozen ");
		stringBuilder.append("ORDER BY BSEG.END_DT DESC ");

		//Start Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
		prepState.bindId("marketerSaID", marketerSaID);
		prepState.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
		prepState.execute();
		
		if (prepState.list().size() > 0) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			wStartPeriodDateBillEnd = (Date) sqlRow.getDate("END_DT");
			prepState.close();
		}
		
		
		return wStartPeriodDateBillEnd;
	}
	/** 
	 * Custom method which retrieves the frozen bill segments(end_date)base on marketerSaID
	 * @param marketerSaID
	 * @return returnValue SA start date.
	 */
	private Date getSaStartDateFromSA(ServiceAgreement_Id marketerSaID) 
	{
		Date wStartPeriodDateStartSa = null;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT SA.START_DT ");
		stringBuilder.append("FROM CI_SA SA ");
		stringBuilder.append("WHERE SA.SA_ID = :marketerSaID ");
		stringBuilder.append("AND SA.SA_STATUS_FLG = :active ");

		//Start Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
		prepState.bindId("marketerSaID", marketerSaID);
		prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);

		prepState.execute();

		if (prepState.list().size() > 0) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			wStartPeriodDateStartSa = (Date) sqlRow.getDate("START_DT");
			prepState.close();
		}
		
		prepState.close();
		return wStartPeriodDateStartSa;
	}
	
	/** 
	 * Custom method which retrieves the SA end date
	 * @param marketerSaID service agreement
	 * @return service aagrement end date.
	 */
	private Date getSaEndDate(ServiceAgreement_Id marketerSaID) 
	{
		Date wEndPeriodDateSaEndDate = null;

		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT SA.END_DT ");
		stringBuilder.append("FROM CI_SA SA ");
		stringBuilder.append("WHERE SA.SA_ID = :marketerSaID ");

		//Start Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
		prepState.bindId("marketerSaID", marketerSaID);

		prepState.execute();

		if (prepState.list().size() > 0) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			wEndPeriodDateSaEndDate = (Date) sqlRow.getDate("END_DT");
		}
		prepState.close();
		return wEndPeriodDateSaEndDate;
		
	}
	//	 2015-10-30. Dhuynh. SF-63955. End Add 
}
