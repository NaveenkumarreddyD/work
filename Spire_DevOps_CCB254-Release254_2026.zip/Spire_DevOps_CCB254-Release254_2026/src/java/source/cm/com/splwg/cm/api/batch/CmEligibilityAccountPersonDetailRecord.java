/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Record Layout for Custom Eligibility Account Person Detail Record
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-04-24   RDizon  NI0026.1 Initial Version.
 **************************************************************************/

package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmEligibilityAccountPersonDetailRecord
extends ColumnDelimitedRecord {

	public CmEligibilityAccountPersonDetailRecord() {
		super(4);
	}

	public void setPersonId(String personId) {
		String string = "<PersonID>" + personId + "</PersonID>" + "\n";
		this.rightPadColumn(1, string.length(), string);        
	}

	public void setPersonName(String personName) {
		// String string = "<PersonName>" + personName + "</PersonName>" + "\n";
		String string = "<PersonName>" + "<![CDATA[" + personName + "]]>" + "</PersonName>" + "\n";
		this.rightPadColumn(2, string.length(), string);
	}

	public void setAccountRelationshipType(String accountRelationshipType) {
		String string = "<AcctRelationType>" + accountRelationshipType + "</AcctRelationType>" + "\n";
		this.rightPadColumn(3, string.length(), string);
	}

	public void setSSN(String ssn) {
		String string = "<SSN>" + ssn + "</SSN>" + "\n";
		this.rightPadColumn(4, string.length(), string);
	}


}
