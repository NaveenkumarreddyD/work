/**************************************************************************
* Program Name: CmPaymentArrangementActionFlagLookup_Impl
* Program Title: CmPaymentArrangementActionFlagLookup_Impl
* Author: Sharmayne Felipe
* Creation Date: 2017-03-07
* Purpose: Lookup for Autopay Maintenance Actions
*  
* Functional Spec: CCB-CC-002
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  CCB-CC-002.1      Sharmayne Felipe 2017-03-08    Initial Version
 ************************************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author SFelip
 *
 @LookupFieldname (value = CM_PA_ACT_FLG)
 */
public class CmPaymentArrangementActionFlagLookup_Impl 
    extends CmPaymentArrangementActionFlagLookup_Gen{

}
