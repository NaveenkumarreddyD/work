/**************************************************************************
* Program Name: CmRecurringPaymentMaintenanceBatch
* Program Title: CmRecurringPaymentMaintenanceBatch
* Author: AMasil
* Creation Date: 2017-04-24
* Purpose: Process the records in the staging table to add remove recurring
*          payment registrants in CCB. It also is used to detect recurring 
*          payment deenrollment.
* Functional Spec: CCB-CC-005.6
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:         Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  CCB-CC-005.6      Aya Masilang    2017-04-24    Initial Version
 *  Defect 3753240    Louis Ballon    2017-05-16    Updated main processing due to update on
 *                                                  design specifications
 *  Defect 3855022    Jerald Tiozon   2017-09-13    Check existence of the account characteristic
 *                                                  before removing.   
 *  Defect 3887568    Gerard Cinco    2017-10-19    For accounts both in CCB and staging, update 
 *                                                  only when any of the characteristic values 
 *                                                  differ from staging record values. Account has
 *                                                  no eBillChar if it does not exist                                                                                              
 *  Defect 3887568    Louis Ballon    2017-11-03    (Reopen) - Trimmed the String from CCB Account
 *                                                  Characteristic and staging record values
 *                                                  before comparing.
 *  Defect 3915441    Aya Masilang    2017-11-10    If the Payment Schedule value is not 1,2 or 3
 *                                                  then the Payment Type will be sourced from the
 *                                                  Payment Frequency field in the staging table.
 *  Defect 3915441    Gerard Cinco    2017-12-12    (Reopen) - Processing for when payment 
 *                                                  schedule is 4 should also update Kubra 
 *                                                  Recurring Payment       
 *  Defect 3915441    Aya Masilang    2018-01-18    Updated the logic in checking the changes of
 *                                                  the payment schedule against the payment
 *                                                  frequency if the payment schedule is FOUR.
 ************************************************************************************************/
package com.splwg.cm.domain.batch;

import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristics;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactLog_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.cm.api.lookup.CmRecurringPaymentCCLookup;
import com.splwg.cm.api.lookup.CmRecurringPaymentFlagLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author AMasil
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = characteristicType, name = RECR_PAY, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = RECR_PAY_METH, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = RECR_PAY_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = EBILL_REG_KUBRA, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = TOKEN_1, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = RECR_ID, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CUST_CONTACT_CLASS, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CUST_CONTACT_TYPE, required = true, type = string)})
 */
public class CmRecurringPaymentMaintenanceBatch extends
        CmRecurringPaymentMaintenanceBatch_Gen {
    
    // Constant Variables
    private static final String YES = "Y";
    private static final String NO = "N";
    private static final String RECR_PAY = "RECR_PAY";
    private static final String RECR_PAY_METH = "RECR_PAY_METH";
    private static final String RECR_PAY_TYPE = "RECR_PAY_TYPE";
    private static final String EBILL_REG_KUBRA = "EBILL_REG_KUBRA";
    private static final String TOKEN_1 = "TOKEN_1";
    private static final String RECR_ID = "RECR_ID";
    private static final String CUST_CONTACT_TYPE = "CUST_CONTACT_TYPE";
    
    public JobWork getJobWork() {
    	
        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
        StringBuilder recurringPaymentsQueryString = new StringBuilder();
        
        recurringPaymentsQueryString.append("SELECT ");
        /*	
         * Defect 3753240 - 2017-05-16 - Start Add
         */
        recurringPaymentsQueryString.append( "DISTINCT ");
        /*
         * Defect 3753240 - 2017-05-16 - End Add
         */
        recurringPaymentsQueryString.append( "RP.ACCT_ID, ");
        recurringPaymentsQueryString.append( ":stage AS TABLE_FLAG, ");
        /*
         * Defect 3753240 - 2017-05-16 - Start Change
         */
        //recurringPaymentsQueryString.append( "RP.RECR_PAY_METH, ");
        recurringPaymentsQueryString.append( "RP.RECR_PAY_SCHEDULE, ");
        /*
         * Defect 3753240 - 2017-05-16 - End Change
         */
        /*
         * Defect 3915441 - 2017-11-10 - Start Add
         */
        recurringPaymentsQueryString.append( "RP.RECR_PAY_FREQUENCY, ");
        /*
         * Defect 3915441 - 2017-11-10 - End Add
         */
        recurringPaymentsQueryString.append( "RP.RECR_PAY_TYPE, ");
        recurringPaymentsQueryString.append( "RP.RECR_ID, ");
        recurringPaymentsQueryString.append( "KAU.CM_TOKEN1 ");
        recurringPaymentsQueryString.append("FROM ");
        recurringPaymentsQueryString.append( "CM_RECR_PAY RP, ");
        recurringPaymentsQueryString.append( "CM_KUBRA_ALL_USER KAU ");
        recurringPaymentsQueryString.append("WHERE ");
        recurringPaymentsQueryString.append( "RP.ACCT_ID = KAU.ACCT_ID ");
        recurringPaymentsQueryString.append( "AND KAU.CM_ENROLLED_VIA = 'SSO' ");
        recurringPaymentsQueryString.append( "AND NOT EXISTS (SELECT 'X' ");
        recurringPaymentsQueryString.append(  "FROM CI_ACCT_CHAR ACH ");
        recurringPaymentsQueryString.append(  "WHERE ACH.ACCT_ID = RP.ACCT_ID ");
        recurringPaymentsQueryString.append(   "AND ACH.CHAR_TYPE_CD = 'RECRPAY' ");
        recurringPaymentsQueryString.append(   "AND ACH.SRCH_CHAR_VAL = 'Y' ");
        recurringPaymentsQueryString.append(  ") ");
        recurringPaymentsQueryString.append("UNION ALL ");
        recurringPaymentsQueryString.append("SELECT ");
        /*
         * Defect 3753240 - 2017-05-16 - Start Add
         */
        recurringPaymentsQueryString.append( "DISTINCT ");
        /*
         * Defect 3753240 - 2017-05-16 - End Add
         */
        recurringPaymentsQueryString.append( "RP.ACCT_ID, ");
        recurringPaymentsQueryString.append( ":both AS TABLE_FLAG, ");
        /*
         * Defect 3753240 - 2017-05-16 - Start Change
         */
        //recurringPaymentsQueryString.append( "RP.RECR_PAY_METH, ");
        recurringPaymentsQueryString.append( "RP.RECR_PAY_SCHEDULE, ");
        /*
         * Defect 3753240 - 2017-05-16 - End Change
         */
        /*
         * Defect 3915441 - 2017-11-10 - Start Add
         */
        recurringPaymentsQueryString.append( "RP.RECR_PAY_FREQUENCY, ");
        /*
         * Defect 3915441 - 2017-11-10 - End Add
         */
        recurringPaymentsQueryString.append( "RP.RECR_PAY_TYPE, ");
        recurringPaymentsQueryString.append( "RP.RECR_ID, ");
        /*
         * Defect 3753240 - 2017-05-16 - Start Change
         */
        //recurringPaymentsQueryString.append( "' ' ");
        recurringPaymentsQueryString.append( "KAU.CM_TOKEN1 ");
        /*
         * Defect 3753240 - 2017-05-16 - End Change
         */
        recurringPaymentsQueryString.append("FROM ");
        recurringPaymentsQueryString.append( "CM_RECR_PAY RP, ");
        recurringPaymentsQueryString.append( "CM_KUBRA_ALL_USER KAU ");
        recurringPaymentsQueryString.append("WHERE ");
        recurringPaymentsQueryString.append( "RP.ACCT_ID = KAU.ACCT_ID ");
        recurringPaymentsQueryString.append( "AND KAU.CM_ENROLLED_VIA = 'SSO' ");
        recurringPaymentsQueryString.append( "AND EXISTS (SELECT 'X' ");
        recurringPaymentsQueryString.append(  "FROM CI_ACCT_CHAR ACH ");
        recurringPaymentsQueryString.append(  "WHERE ACH.ACCT_ID = RP.ACCT_ID ");
        recurringPaymentsQueryString.append(   "AND ACH.CHAR_TYPE_CD = 'RECRPAY' ");
        recurringPaymentsQueryString.append(   "AND ACH.SRCH_CHAR_VAL = 'Y' ");
        recurringPaymentsQueryString.append(  ") ");
        recurringPaymentsQueryString.append("UNION ALL ");
        recurringPaymentsQueryString.append("SELECT ");
        recurringPaymentsQueryString.append( "AC.ACCT_ID, ");
        recurringPaymentsQueryString.append( ":acct AS TABLE_FLAG, ");
        recurringPaymentsQueryString.append( "' ', ");
        recurringPaymentsQueryString.append( "' ', ");
        recurringPaymentsQueryString.append( "' ', ");
        /*
         * Defect 3915441 - 2017-11-10 - Start Add
         */
        recurringPaymentsQueryString.append( "' ', ");
        /*
         * Defect 3915441 - 2017-11-10 - End Add
         */
        recurringPaymentsQueryString.append( "' '  ");
        recurringPaymentsQueryString.append("FROM CI_ACCT AC ");
        recurringPaymentsQueryString.append("WHERE ");
        recurringPaymentsQueryString.append( "EXISTS (SELECT 'X' ");
        recurringPaymentsQueryString.append(  "FROM CI_ACCT_CHAR ACH ");
        recurringPaymentsQueryString.append(  "WHERE ACH.ACCT_ID = AC.ACCT_ID ");
        recurringPaymentsQueryString.append(   "AND ACH.CHAR_TYPE_CD = 'RECRPAY' ");
        recurringPaymentsQueryString.append(   "AND ACH.SRCH_CHAR_VAL = 'Y' ");
        recurringPaymentsQueryString.append(  ") ");
        recurringPaymentsQueryString.append( "AND NOT EXISTS (SELECT 'X' ");
        recurringPaymentsQueryString.append(  "FROM ");
        recurringPaymentsQueryString.append(   "CM_RECR_PAY RP, ");
        recurringPaymentsQueryString.append(   "CM_KUBRA_ALL_USER KAU ");
        recurringPaymentsQueryString.append(  "WHERE ");
        recurringPaymentsQueryString.append(   "RP.ACCT_ID = AC.ACCT_ID ");
        recurringPaymentsQueryString.append(   "AND KAU.ACCT_ID = RP.ACCT_ID ");
        recurringPaymentsQueryString.append(   "AND KAU.CM_ENROLLED_VIA = 'SSO') ");
        
        PreparedStatement recurringPaymentsQuery = createPreparedStatement(recurringPaymentsQueryString.toString(), getClass().getName());
        recurringPaymentsQuery.bindString("stage", CmRecurringPaymentFlagLookup.constants.CM_STAGE.trimmedValue(), "TABLE_FLAG");
        recurringPaymentsQuery.bindString("both", CmRecurringPaymentFlagLookup.constants.CM_BOTH.trimmedValue(), "TABLE_FLAG");
        recurringPaymentsQuery.bindString("acct", CmRecurringPaymentFlagLookup.constants.CM_ACCOUNT.trimmedValue(), "TABLE_FLAG");
        
        QueryIterator<SQLResultRow> recurPaymentsIter = recurringPaymentsQuery.iterate();
        while(recurPaymentsIter.hasNext()){
            SQLResultRow row = recurPaymentsIter.next();
            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId(new Account_Id(row.getString("ACCT_ID")));
            workUnit.addSupplementalData("TABLE_FLAG", row.getString("TABLE_FLAG"));
            /*
             * Defect 3753240 - 2017-05-16 - Start Change
             */
            //workUnit.addSupplementalData("RECR_PAY_METH", row.getString("RECR_PAY_METH"));
            workUnit.addSupplementalData("RECR_PAY_SCHEDULE", row.getString("RECR_PAY_SCHEDULE"));
            /*
             * Defect 3753240 - 2017-05-16 - End Change
             */
            /*
             * Defect 3915441 - 2017-11-10 - Start Add
             */
            workUnit.addSupplementalData("RECR_PAY_FREQUENCY", row.getString("RECR_PAY_FREQUENCY"));
            /*
             * Defect 3915441 - 2017-11-10 - End Add
             */
            
            workUnit.addSupplementalData("RECR_PAY_TYPE", row.getString("RECR_PAY_TYPE"));
            workUnit.addSupplementalData("RECR_ID", row.getString("RECR_ID"));
            workUnit.addSupplementalData("CM_TOKEN1", row.getString("CM_TOKEN1"));
            workUnits.add(workUnit);
        }
        
        recurPaymentsIter.close();
        recurringPaymentsQuery.close();
        return createJobWorkForThreadWorkUnitList(workUnits);
    }
    
    @Override
    public void validateSoftParameters(boolean isNewRun) {
        // Kubra Recurring Payments Flag Characteristic Type
        CharacteristicType charType = getParameters().getRECR_PAY();
        if (validateCharacteristicEntity(charType, CharacteristicEntityLookup.constants.ACCOUNT).isFalse()) {
            addError(CustomMessageRepository.CC_005_6_InvalidForEntity(
                    RECR_PAY,
                    charType.getId().getTrimmedValue(), 
                    CharacteristicEntityLookup.constants.ACCOUNT.getLookupValue().fetchLanguageDescription()));
        }

        // Kubra Recurring Payment Method Characteristic Type
        charType = getParameters().getRECR_PAY_METH();
        if (validateCharacteristicEntity(charType, CharacteristicEntityLookup.constants.ACCOUNT).isFalse()) {
            addError(CustomMessageRepository.CC_005_6_InvalidForEntity(
                    RECR_PAY_METH,
                    charType.getId().getTrimmedValue(), 
                    CharacteristicEntityLookup.constants.ACCOUNT.getLookupValue().fetchLanguageDescription()));
        }

        // Kubra Recurring Payment Type Characteristic Type
        charType = getParameters().getRECR_PAY_TYPE();
        if (validateCharacteristicEntity(charType, CharacteristicEntityLookup.constants.ACCOUNT).isFalse()) {
            addError(CustomMessageRepository.CC_005_6_InvalidForEntity(
                    RECR_PAY_TYPE,
                    charType.getId().getTrimmedValue(), 
                    CharacteristicEntityLookup.constants.ACCOUNT.getLookupValue().fetchLanguageDescription()));
        }
        
        // Kubra Ebill Flag Characteristic Type
        charType = getParameters().getEBILL_REG_KUBRA();
        if (validateCharacteristicEntity(charType, CharacteristicEntityLookup.constants.ACCOUNT).isFalse()) {
            addError(CustomMessageRepository.CC_005_6_InvalidForEntity(
                    EBILL_REG_KUBRA,
                    charType.getId().getTrimmedValue(), 
                    CharacteristicEntityLookup.constants.ACCOUNT.getLookupValue().fetchLanguageDescription()));
        }
        
        // Kubra Token1 Characteristic Type
        charType = getParameters().getTOKEN_1();
        if (validateCharacteristicEntity(charType, CharacteristicEntityLookup.constants.ACCOUNT).isFalse()) {
            addError(CustomMessageRepository.CC_005_6_InvalidForEntity(
                    TOKEN_1,
                    charType.getId().getTrimmedValue(), 
                    CharacteristicEntityLookup.constants.ACCOUNT.getLookupValue().fetchLanguageDescription()));
        }
        
        // Kubra Recurring ID Characteristic Type
        charType = getParameters().getRECR_ID();
        if (validateCharacteristicEntity(charType, CharacteristicEntityLookup.constants.ACCOUNT).isFalse()) {
            addError(CustomMessageRepository.CC_005_6_InvalidForEntity(
                    RECR_ID,
                    charType.getId().getTrimmedValue(), 
                    CharacteristicEntityLookup.constants.ACCOUNT.getLookupValue().fetchLanguageDescription()));
        }
        
        // Customer Contact Type
        CustomerContactClass custContactClass = getParameters().getCUST_CONTACT_CLASS();
        String custContactType = getParameters().getCUST_CONTACT_TYPE();
        if (validateCustomerContactType(custContactClass, custContactType).isFalse()) {
            addError(CustomMessageRepository.CC_005_6_InvalidCCTypeForCCClass(
                    CUST_CONTACT_TYPE,
                    custContactType, 
                    custContactClass.getId().getTrimmedValue()));
        }
    }
    
    /**
     * This method validates if a characteristic type is valid for a specific characteristic entity.
     * @param charType - Characteristic Type
     * @param charEntityLookup - Characteristic Entity Lookup
     * @return Bool
     */
    private Bool validateCharacteristicEntity(CharacteristicType charType, CharacteristicEntityLookup charEntityLookup) {

        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType.getId(), charEntityLookup);        
        if (isNull(charEntityId.getEntity())) {
            return Bool.FALSE;
        }

        return Bool.TRUE;
    }

    /**
     * This method validates Customer Contact Type.
     * @param customerContactClass - Customer Contact Class
     * @param customerContactType - String
     * @return Bool
     */
    private Bool validateCustomerContactType(CustomerContactClass customerContactClass, String customerContactType) {

        CustomerContactType_Id customerContactTypeId = new CustomerContactType_Id(customerContactClass, customerContactType);
        if (isNull(customerContactTypeId.getEntity())) { 
            return Bool.FALSE;
        }

        return Bool.TRUE;
    }


    public Class<CmRecurringPaymentMaintenanceBatchWorker> getThreadWorkerClass() {
        return CmRecurringPaymentMaintenanceBatchWorker.class;
    }

    public static class CmRecurringPaymentMaintenanceBatchWorker extends
            CmRecurringPaymentMaintenanceBatchWorker_Gen {

    	/*
         * Defect 3753240 - 2017-05-16 - Start Add
         */
    	//Constant Variables
    	private String ONE = "1";
    	private String TWO = "2";
    	private String THREE = "3";
    	private String FIXED = "FIXED";
    	private String RECEIVED = "RECEIVED";
    	private String DUE = "DUE";
    	/*
         * Defect 3753240 - 2017-05-16 - End Add
         */
        // Defect 3915441 - 2017-11-10 - Start Add
    	private String FOUR = "4";
        // Defect 3915441 - 2017-11-10 - Start Add
        //Working Variables
        private Account account;
        private String tableFlag;
    	/*
         * Defect 3753240 - 2017-05-16 - Start Change
         */
        //private String recrPayMethod;
        //private String recrPayType;
        private String recrPaySchedule;
        private String recrPayAccountType;
    	/*
         * Defect 3753240 - 2017-05-16 - End Change	
         */
        /*
         * Defect 3915441 - 2017-11-10 - Start Add
         */
        private String recrPayFrequency;
        /*
         * Defect 3915441 - 2017-11-10 - End Add
         */
        private String recrId;
        private String token1;
        private Date processDate;
        
        //Soft Parameters
        private CharacteristicType recPayCharType;
        private CharacteristicType recPayMethodCharType;
        private CharacteristicType recPayTypeCharType;
        private CharacteristicType ebillCharType;
        private CharacteristicType token1CharType;
        private CharacteristicType recrdIdCharType;
        private CustomerContactClass customerClass;
        private CustomerContactType_Id customerContactTypeId;
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }
        public void initializeThreadWork(
                boolean initializationPreviouslySuccessful)
                        throws ThreadAbortedException, RunAbortedException {
            recPayCharType = getParameters().getRECR_PAY();
            recPayMethodCharType = getParameters().getRECR_PAY_METH();
            recPayTypeCharType = getParameters().getRECR_PAY_TYPE();
            ebillCharType = getParameters().getEBILL_REG_KUBRA();
            token1CharType = getParameters().getTOKEN_1();
            recrdIdCharType = getParameters().getRECR_ID();
            customerClass = getParameters().getCUST_CONTACT_CLASS();
            customerContactTypeId = new CustomerContactType_Id(customerClass, getParameters().getCUST_CONTACT_TYPE());
            processDate = getProcessDateTime().getDate();
        }

        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {

            account = ((Account_Id) unit.getPrimaryId()).getEntity();
            tableFlag = (String) unit.getSupplementallData("TABLE_FLAG");
            /*
             * Defect 3753240 - 2017-05-16 - Start Change
             */
            //recrPayMethod = (String) unit.getSupplementallData("RECR_PAY_METH");
            //recrPayType = (String) unit.getSupplementallData("RECR_PAY_TYPE");
            recrPaySchedule = (String) unit.getSupplementallData("RECR_PAY_SCHEDULE");
            recrPayAccountType = (String) unit.getSupplementallData("RECR_PAY_TYPE");
            /*
             * Defect 3753240 - 2017-05-16 - End Change
             */
            /*
             * Defect 3915441 - 2017-11-10 - Start Add
             */
            recrPayFrequency = (String) unit.getSupplementallData("RECR_PAY_FREQUENCY");
            /*
             * Defect 3915441 - 2017-11-10 - End Add
             */
            recrId = (String) unit.getSupplementallData("RECR_ID");
            token1 = (String) unit.getSupplementallData("CM_TOKEN1");

            Person mainPerson = account.getMainPerson();
            
            if(tableFlag.equals(CmRecurringPaymentFlagLookup.constants.CM_STAGE.trimmedValue())){
                //Process Recurring Payment Enrollment
                addUpdateAccountCharacteristic(account, recPayCharType, YES);
                /*
                 * Defect 3753240 - 2017-05-16 - Start Change
                 */
                //addUpdateAccountCharacteristic(account, recPayMethodCharType, recrPayMethod);
                //addUpdateAccountCharacteristic(account, recPayTypeCharType, recrPayType);
                if(recrPaySchedule.trim().compareTo(ONE) == 0) {
                	addUpdateAccountCharacteristic(account, recPayTypeCharType, FIXED);
                } else if(recrPaySchedule.trim().compareTo(TWO) == 0) {
                	addUpdateAccountCharacteristic(account, recPayTypeCharType, RECEIVED);
                } else if(recrPaySchedule.trim().compareTo(THREE) == 0) {
                	addUpdateAccountCharacteristic(account, recPayTypeCharType, DUE);
                } else {
                    /*
                     * Defect 3915441 - 2017-11-10 - Start Change
                     */
                    //addUpdateAccountCharacteristic(account, recPayTypeCharType, recrPaySchedule);
                    addUpdateAccountCharacteristic(account, recPayTypeCharType, recrPayFrequency);
                    /*
                     * Defect 3915441 - 2017-11-10 - End Change
                     */
                }
                addUpdateAccountCharacteristic(account, recPayMethodCharType, recrPayAccountType);
                /*
                 * Defect 3753240 - 2017-05-16 - End Change
                 */

                if(accountHasNoEbill(account)){
                    addUpdateAccountCharacteristic(account, token1CharType, token1);
                }
                addUpdateAccountCharacteristic(account, recrdIdCharType, recrId);

                createCustomerContact(mainPerson, CmRecurringPaymentCCLookup.constants.CM_RECURRING_PAY_ENROLLMENT.getLookupValue().fetchLanguageDescription());
            /*
             * Defect 3887568 - 2017-10-19 - Start Change
             */
            //} else if(tableFlag.equals(CmRecurringPaymentFlagLookup.constants.CM_BOTH.trimmedValue())){
            // Defect 3915441 - 2018-01-18 - Start Change
            //} else if(tableFlag.equals(CmRecurringPaymentFlagLookup.constants.CM_BOTH.trimmedValue()) && areAccountCharsDifferentFromStaging(account,recrPayAccountType,recrPaySchedule, recrId)){
            } else if(tableFlag.equals(CmRecurringPaymentFlagLookup.constants.CM_BOTH.trimmedValue()) && areAccountCharsDifferentFromStaging(account,recrPayAccountType,recrPaySchedule, recrPayFrequency, recrId)){
            // Defect 3915441 - 2018-01-18 - End Change
            /*
             * Defect 3887568 - 2017-10-19 - End Change
             */
                //Process Recurring Payment Update
                /*
                 * Defect 3753240 - 2017-05-16 - Start Change
                 */
                //addUpdateAccountCharacteristic(account, recPayMethodCharType, recrPayMethod);
            	//addUpdateAccountCharacteristic(account, recPayTypeCharType, recrPayType);
                if(recrPaySchedule.trim().compareTo(ONE) == 0) {
                	addUpdateAccountCharacteristic(account, recPayTypeCharType, FIXED);
                } else if(recrPaySchedule.trim().compareTo(TWO) == 0) {
                	addUpdateAccountCharacteristic(account, recPayTypeCharType, RECEIVED);
                } else if(recrPaySchedule.trim().compareTo(THREE) == 0) {
                	addUpdateAccountCharacteristic(account, recPayTypeCharType, DUE);
                } else {
                    /*
                     * Defect 3915441 - 2017-11-10 - Start Change
                     */
                    //addUpdateAccountCharacteristic(account, recPayTypeCharType, recrPaySchedule);
                	addUpdateAccountCharacteristic(account, recPayTypeCharType, recrPayFrequency);
                	/*
                     * Defect 3915441 - 2017-11-10 - End Change
                     */
                }
                addUpdateAccountCharacteristic(account, recPayMethodCharType, recrPayAccountType);
                /*
                 * Defect 3753240 - 2017-05-16 - End Change
                 */
                
                /*
                 * Defect 3753240 - 2017-05-16 - Start Add
                 */
                if(accountHasNoEbill(account)){
                    addUpdateAccountCharacteristic(account, token1CharType, token1);
                }
                addUpdateAccountCharacteristic(account, recrdIdCharType, recrId);
                /*
                 * Defect 3753240 - 2017-05-16 - End Add
                 */
                
                createCustomerContact(mainPerson, CmRecurringPaymentCCLookup.constants.CM_RECURRING_PAY_UPDATE.getLookupValue().fetchLanguageDescription());
            } else if(tableFlag.equals(CmRecurringPaymentFlagLookup.constants.CM_ACCOUNT.trimmedValue())){
                //Process Recurring Payment De enrollment
                addUpdateAccountCharacteristic(account, recPayCharType, NO);
                AccountCharacteristics acctChars = account.getCharacteristics();
                /*
                 * Defect 3855022 - 2017-09-13 - Start Add
                 */
                AccountCharacteristic recPayMethodChar = account.getEffectiveCharacteristicAsOfDate(recPayMethodCharType, processDate);
                AccountCharacteristic recPayTypeChar = account.getEffectiveCharacteristicAsOfDate(recPayTypeCharType, processDate);
                AccountCharacteristic token1Char = account.getEffectiveCharacteristicAsOfDate(token1CharType, processDate);
                AccountCharacteristic recrdIdChar = account.getEffectiveCharacteristicAsOfDate(recrdIdCharType, processDate);
                /*
                 * Defect 3855022 - 2017-09-13 - End Add
                 */                
                /*
                 * Defect 3855022 - 2017-09-13 - Start Change
                 */                
                //acctChars.remove(account.getEffectiveCharacteristicAsOfDate(recPayMethodCharType, processDate));
                //acctChars.remove(account.getEffectiveCharacteristicAsOfDate(recPayTypeCharType, processDate));
                //if(accountHasNoEbill(account)){
                    //acctChars.remove(account.getEffectiveCharacteristicAsOfDate(token1CharType, processDate));
                //}
                //acctChars.remove(account.getEffectiveCharacteristicAsOfDate(recrdIdCharType, processDate));
                if(notNull(recPayMethodChar)){
                	acctChars.remove(recPayMethodChar);
                }
                if(notNull(recPayTypeChar)){
                	acctChars.remove(recPayTypeChar);
                }
                if(accountHasNoEbill(account)){
                	if(notNull(token1Char)){
                    	acctChars.remove(token1Char);
                    }
                }
                if(notNull(recrdIdChar)){
                	acctChars.remove(recrdIdChar);
                }
                /*
                 * Defect 3855022 - 2017-09-13 - End Change
                 */
                createCustomerContact(mainPerson, CmRecurringPaymentCCLookup.constants.CM_RECURRING_PAY_DE_ENROLLMENT.getLookupValue().fetchLanguageDescription());
            }
            return true;
        }
        
        /**
         * This method checks if the account is not registered to EBill.
         * @param Account - account
         * @return Boolean
         */
        private Boolean accountHasNoEbill(Account account){
            CharacteristicTypeLookup charTypeLookup = ebillCharType.getCharacteristicType();
            AccountCharacteristic ebillAcctChar = account.getEffectiveCharacteristicAsOfDate(ebillCharType, processDate);
            Boolean accountHasNoEbill = Boolean.FALSE;
            
            if(notNull(ebillAcctChar)){
                String ebillAcctCharValue = "";
                if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
                    ebillAcctCharValue = ebillAcctChar.getAdhocCharacteristicValue().trim();
                } 
                else if (charTypeLookup.isPredefinedValue()) {
                    ebillAcctCharValue = ebillAcctChar.getCharacteristicValue().trim();
                }
                else if (charTypeLookup.isForeignKeyValue()) {
                    ebillAcctCharValue = ebillAcctChar.getCharacteristicValueForeignKey1().trim();
                }  

                if(ebillAcctCharValue.equals(NO)){
                    accountHasNoEbill = Boolean.TRUE;
                }
            /*
             * Defect 3887568 - 2017-10-19 - Start Edit
             */
            //}
            } else {
            	// Account has no char if it does not exist
                accountHasNoEbill = Boolean.TRUE;
            }
            /*
             * Defect 3887568 - 2017-10-19 - End Edit
             */

            return accountHasNoEbill;                    
        }

        /**
         * This method adds or update an existing account characteristic.
         * @param Account - account
         * @param CharacteristicType - charType
         * @param String - charValue
         */
        private void addUpdateAccountCharacteristic(Account account, CharacteristicType charType, String charValue) {
            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
            StringBuilder acctCharQueryString = new StringBuilder();
            
            acctCharQueryString.append("WHERE this.id.characteristicType = :characteristicType ");
            acctCharQueryString.append( "AND this.id.effectiveDate <= :processDate ");
            acctCharQueryString.append("ORDER BY this.id.effectiveDate DESC ");
            
            ListFilter<AccountCharacteristic> accountCharFilter = account.getCharacteristics().createFilter(acctCharQueryString.toString(), getClass().getName());
            accountCharFilter.bindEntity("characteristicType", charType);
            accountCharFilter.bindDate("processDate", processDate);

            if (accountCharFilter.list().isEmpty()) {
                AccountCharacteristic_DTO acctCharDTO = createDTO(AccountCharacteristic.class);
                if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
                    acctCharDTO.setAdhocCharacteristicValue(charValue.trim());
                } 
                else if (charTypeLookup.isPredefinedValue()) {
                    acctCharDTO.setCharacteristicValue(charValue.trim());
                }
                else if (charTypeLookup.isForeignKeyValue()) {
                    acctCharDTO.setCharacteristicValueForeignKey1(charValue.trim());
                }

                account.getCharacteristics().add(acctCharDTO, charType.getId(), processDate);
            }
            else {
                AccountCharacteristic accountCharacteristic = (AccountCharacteristic) accountCharFilter.firstRow();

                AccountCharacteristic_DTO acctCharDTO = accountCharacteristic.getDTO();
                if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
                    acctCharDTO.setAdhocCharacteristicValue(charValue.trim());
                } 
                else if (charTypeLookup.isPredefinedValue()) {
                    acctCharDTO.setCharacteristicValue(charValue.trim());
                }
                else if (charTypeLookup.isForeignKeyValue()) {
                    acctCharDTO.setCharacteristicValueForeignKey1(charValue.trim());
                }
                accountCharacteristic.setDTO(acctCharDTO);
            }
        }
        
        /**
         * This method creates Customer Contact.
         * @param Person - person
         * @param String - logEntry
         */
        private void createCustomerContact(Person person, String logEntry) {
            if (checkForExistingCustomerContact(person)) {
                return;
            }
            
            // Create Customer Contact
            CustomerContact_DTO ccDTO = (CustomerContact_DTO) createDTO(CustomerContact.class);
            
            ccDTO.setContactDateTime(getProcessDateTime());
            ccDTO.setCustomerContactTypeId(customerContactTypeId);
            ccDTO.setPersonId(person.getId());
            ccDTO.setShouldPrintLetter(Bool.FALSE);
            CustomerContact customerContact = ccDTO.newEntity();
            
            //Adds customer contact logs
            CustomerContactLog_DTO ccLogDTO = customerContact.getLogs().newChildDTO();
            ccLogDTO.setCustomerContactId(customerContact.getId());
            ccLogDTO.setLogEntry(logEntry);
            ccLogDTO.setCreationDateTime(getProcessDateTime());
            ccLogDTO.setUserId(getActiveContextUser().getId());
            ccLogDTO.newEntity();  
                   
        }
        
        /**
         * This method checks for existing Customer Contact.
         * @param person - Person
         * @return Boolean
         */
        private Boolean checkForExistingCustomerContact(Person person) {
            
            StringBuilder recurringPaymentsQueryString = new StringBuilder();
            
            recurringPaymentsQueryString.append("SELECT CC_ID ");
            recurringPaymentsQueryString.append("FROM CI_CC ");
            recurringPaymentsQueryString.append("WHERE PER_ID = :person ");
            recurringPaymentsQueryString.append( "AND CC_TYPE_CD = :ccType ");
            recurringPaymentsQueryString.append( "AND TRUNC(CC_DTTM) = :processDate ");
            
            PreparedStatement getCustomerContact = createPreparedStatement(recurringPaymentsQueryString.toString(), getClass().getName());
            getCustomerContact.bindEntity("person", person);
            getCustomerContact.bindStringProperty("ccType", CustomerContactType.properties.contactType, customerContactTypeId.getContactType());
            getCustomerContact.bindDate("processDate", processDate);

            if (notNull(getCustomerContact.firstRow())) {
                return true;
            }

            return false; 
        }
        /*
         * Defect 3887568 - 2017-10-19 - Start Add
         */
        // Defect 3915441 - 2018-01-18 - Start Change
        //private Boolean areAccountCharsDifferentFromStaging(Account account, String payMethodCharValue, String payTypeCharValue, String recordIdCharValue){
        private Boolean areAccountCharsDifferentFromStaging(Account account, String payMethodCharValue, String payTypeCharValue, String payFrequency, String recordIdCharValue){
         // Defect 3915441 - 2018-01-18 - End Change
            
            Boolean theyAreDifferent = Boolean.TRUE;
            
        	// Check if Pay Method from CCB is equal to Staging value
            String acctPayMethodValue = getCharValue(recPayMethodCharType);
            if (acctPayMethodValue.isEmpty()){
            	return theyAreDifferent;
            } else {
            	// Defect 3887568 - 2017-11-03 - Start Change
            	//if (!(payMethodCharValue.compareToIgnoreCase(acctPayMethodValue)==0)){
        		if (!(payMethodCharValue.trim().compareToIgnoreCase(acctPayMethodValue.trim())==0)){
        		// Defect 3887568 - 2017-11-03 - End Change
            		return theyAreDifferent;
            	}
            }
            
            // Check if Pay Type From CCB is equal to Staging value
            String acctPayTypeValue = getCharValue(recPayTypeCharType);
            if (acctPayTypeValue.isEmpty()){
            	return theyAreDifferent;
            } else {
	            if (payTypeCharValue.trim().compareTo(ONE)==0){
	            	payTypeCharValue = FIXED;
	            } else if (payTypeCharValue.trim().compareTo(TWO)==0){
	            	payTypeCharValue = RECEIVED;
	            }else if (payTypeCharValue.trim().compareTo(THREE)==0){
	            	payTypeCharValue = DUE;
	            }
	            // Defect 3915441 - 2018-01-18 - Start Delete
	            //// Defect 3887568 - 2017-11-03 - Start Change
	            ////if (!(payTypeCharValue.compareToIgnoreCase(acctPayTypeValue)==0)){
            	//if (!(payTypeCharValue.trim().compareToIgnoreCase(acctPayTypeValue.trim())==0)){
            	//// Defect 3887568 - 2017-11-03 - End Change
            	//	return theyAreDifferent;
                //// Defect 3915441 - 2017-12-12 - Start Edit
                ////}
            	//} else if (payTypeCharValue.trim().compareTo(FOUR)==0){
            	//	// Proceed to update if values are both 4. 
            	//	return theyAreDifferent;
            	//}
                // Defect 3915441 - 2017-12-12 - End Edit
            	// Defect 3915441 - 2018-01-18 - End Delete
	            
	            // Defect 3915441 - 2018-01-18 - Start Add
	            if(payTypeCharValue.trim().equalsIgnoreCase(FOUR)){
	                if(!acctPayTypeValue.trim().equalsIgnoreCase(payFrequency.trim())){
	                    return theyAreDifferent;
	                }
	            } else if(!payTypeCharValue.trim().equalsIgnoreCase(acctPayTypeValue.trim())){
	                return theyAreDifferent;
	            }
	            // Defect 3915441 - 2018-01-18 - End Add
            }
            
            // Check if Record Id from CCB is Equal to Staging value
            String acctRecordIdValue = getCharValue(recrdIdCharType);
            if (acctRecordIdValue.isEmpty()){
            	return theyAreDifferent;
            } else {
            	// Defect 3887568 - 2017-11-03 - End Change
            	//if (!(recordIdCharValue.compareToIgnoreCase(acctRecordIdValue)==0)){
        		if (!(recordIdCharValue.trim().compareToIgnoreCase(acctRecordIdValue.trim())==0)){
        		// Defect 3887568 - 2017-11-03 - End Change
            		return theyAreDifferent;
            	}
            }
            
            // Char Values are not different
            theyAreDifferent = Boolean.FALSE;
        	return theyAreDifferent;
        }
        
        private String getCharValue(CharacteristicType charType){
        	String value = "";
        	CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
            StringBuilder acctCharQueryString = new StringBuilder();
            
            acctCharQueryString.append("WHERE this.id.characteristicType = :characteristicType ");
            acctCharQueryString.append( "AND this.id.effectiveDate <= :processDate ");
            acctCharQueryString.append("ORDER BY this.id.effectiveDate DESC ");
            
            ListFilter<AccountCharacteristic> accountCharFilter = account.getCharacteristics().createFilter(acctCharQueryString.toString(), getClass().getName());
            accountCharFilter.bindEntity("characteristicType", charType);
            accountCharFilter.bindDate("processDate", processDate);

            if (accountCharFilter.list().isEmpty()) {
            	return value;
            }
            else {
                AccountCharacteristic accountCharacteristic = (AccountCharacteristic) accountCharFilter.firstRow();

                if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
                    value = accountCharacteristic.getAdhocCharacteristicValue();
                } 
                else if (charTypeLookup.isPredefinedValue()) {
                	value = accountCharacteristic.getCharacteristicValue();
                }
                else if (charTypeLookup.isForeignKeyValue()) {
                	value = accountCharacteristic.getCharacteristicValueForeignKey1();
                }
            }        	
        	return value;
        }
        /*
         * Defect 3887568 - 2017-10-19 - End Add
         */

    }

}
