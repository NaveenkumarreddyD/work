/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Adjustment Or Billable Charge Lookup
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-01-25   Rakesh    NA0073. Initial Version.
 **************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * 
 * @LookupFieldname (value = CM_ADJ_BILLABLE_CHG)
 */
public class CmAdjOrBillableChargeLookup_Impl 
extends CmAdjOrBillableChargeLookup_Gen {

}
