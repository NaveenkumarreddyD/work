/* ***************************************************************************
 * PROGRAM DESCRIPTION: 
 * 
 * Regions Bank Payment Upload for Spire AL and Gulf Batch Process
 * 
 * This batch process reads and uploads payment files from Regions Bank for 
 * Spire AL and Gulf.
 *                                                  
 ******************************************************************************                                                                 
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:             Reason:                                     
 * YYYY-MM-DD   IN              Reason text.                                
 *           
 * 2021-04-05   SRoman          CCB029.2. Initial Version.
 * 2021-05-12   NMendo          CCB029.Issue1. Update logic on retrieving 
 *                              Tender Source. Added Dollar Help processing. 
 *                              Update Parsing of Account Number field. Fix 
 *                              issue on incorrect Total Tenders Amount and 
 *                              Total Number of Tenders.
 * 2021-06-21   RDizon          CCB029.Issue2. Post 13-digit input Account 
 *                              Numbers to Suspense.
 * 2021-06-22   NMendo          CCB029.Issue3. Fix issue when the file contains 
 *                              payments from multiple batches.
 * 2021-07-16   FRoig           Defect 4572037. If Tender Source is not found,
 *                              treat the payment as a Suspense payment instead
 *                              of aborting.      
 * 2021-09-17   NMendo          Defect 4595996. Added default payment batch 
 *                              number parameter.     
 * 2021-10-02   FRoig           Defect 4602770. Fix for 10 digit account numbers
 * 								going to Suspense.
 *****************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.lookup.LookupField_Id;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.domain.common.masterConfiguration.MasterConfiguration_Id;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.CopyOptionForProposalSALookup;
import com.splwg.ccb.api.lookup.CustomerReadLookup;
import com.splwg.ccb.api.lookup.DepositControlStagingStatusLookup;
import com.splwg.ccb.api.lookup.PaymentTenderStagingStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.StartReasonLookup;
import com.splwg.ccb.api.lookup.TenderControlStatusLookup;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource_Id;
import com.splwg.ccb.domain.admin.tenderType.entity.TenderType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.common.ServiceAgreementCreator;
import com.splwg.ccb.domain.customerinfo.data.ServiceAgreementCreatorData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementRecurringCharge;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementRecurringCharge_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging_Id;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging_Id;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentTenderUpload_DTO;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentTenderUpload_Id;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author SRoman
 *
@BatchJob (modules = {}, multiThreaded = false, rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PAY_PROC_NM_LB, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PAY_PROC_NM_CIE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = tenderSource, name = TENDER_SOURCE_CD_LB_DEFAULT, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = tenderSource, name = TENDER_SOURCE_CD_CIE_DEFAULT, required = true, type = entity)            
 *            , @BatchJobSoftParameter (entityName = tenderType, name = TENDER_TYPE_CD_LOCKBOX, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = tenderType, name = TENDER_TYPE_CD_CIE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = businessObject, name = TNDR_SRC_MASTER_CONFIG_BO, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = FEATURE_CFG_DOLLAR_HELP, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = SA_TYPE_CD_DOLLAR_HELP, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PYMT_BATCH_NBR, required = true, type = string)})
 */
public class CmRegionsBankPaymentUploadForAlabamaGulfBatch extends
        CmRegionsBankPaymentUploadForAlabamaGulfBatch_Gen {
	
	// Start Add - NMendo - CCB029.Issue1 -  2021-05-12
    // Constants
    private static final String PAY_PROCESS_NAMES_LOOKUP = "CM_PAY_PROC_NM_FLG";
    private static final String BATCH_PARM_NAME_PAY_PROC_NM_LB = "PAY_PROC_NM_LB";
    private static final String BATCH_PARM_NAME_PAY_PROC_NM_CIE = "PAY_PROC_NM_CIE";
    private static final String BATCH_PARM_NAME_TNDR_SRC_MASTER_CONFIG_BO = "TNDR_SRC_MASTER_CONFIG_BO";
    private static final String BATCH_PARM_NAME_SA_TYPE_CD_DOLLAR_HELP = "SA_TYPE_CD_DOLLAR_HELP";
    // End Add - NMendo - CCB029.Issue1 -  2021-05-12
    
    private static final Logger logger = LoggerFactory.getLogger(CmRegionsBankPaymentUploadForAlabamaGulfBatch_Gen.class);
    
    public JobWork getJobWork() {
        ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        arrayList.add(threadWorkUnit);
        return createJobWorkForThreadWorkUnitList(arrayList);
    }
    
    @Override
    public void validateSoftParameters(boolean isNewRun) {
        String parmFilePath = getParameters().getFILE_PATH().trim();
        String parmFileName = getParameters().getFILE_NAME().trim();
        // Start Change - NMendo - CCB029.Issue1 -  2021-05-12
        //LookupField cisTenderSrceLookupForLB = getParameters().getCIS_DIV_TNDR_SRCE_LB_LOOKUP();
        //LookupField cisTenderSrceLookupForCIE = getParameters().getCIS_DIV_TNDR_SRCE_CIE_LOOKUP();
        String parmPayProcessNameLB = getParameters().getPAY_PROC_NM_LB().trim();
        String parmPayProcessNameCIE = getParameters().getPAY_PROC_NM_CIE().trim();
        BusinessObject parmMasterConfigBO = getParameters().getTNDR_SRC_MASTER_CONFIG_BO();
        String parmDollarHelpSAType = getParameters().getSA_TYPE_CD_DOLLAR_HELP().trim();
        // End Change - NMendo - CCB029.Issue1 -  2021-05-12
        
        // Validate if the file path parameter exists
        File folder = new File(parmFilePath);
        if(!(folder.exists() && folder.isDirectory())) {
            addError(CustomMessageRepositorySpireOne.CCB029_1_invalidFilePath(parmFilePath));  
        }
        
        // Validate if the file exists in the file path parameter
        File inputFile = new File(parmFilePath, parmFileName);
        if(!inputFile.exists() || !inputFile.canRead()) {
            addError(CustomMessageRepositorySpireOne.CCB029_1_invalidFileName(parmFileName)); 
        }
        
        // Start Change - NMendo - CCB029.Issue1 -  2021-05-12
        // Validate that each CIS Division in the Lookup Value is a valid CIS Division
        //validateCisDivisionInLookup(cisTenderSrceLookupForLB);
        //validateCisDivisionInLookup(cisTenderSrceLookupForCIE);
        
        // Validate that each Tender Source in the Lookup Value Description is a valid Tender Source
        //validateTenderSourceInLookup(cisTenderSrceLookupForLB);
        //validateTenderSourceInLookup(cisTenderSrceLookupForCIE);
        
        // Pay Process Name LB must be a valid value for the CM_PAY_PROC_NM_FLG lookup
        LookupValue_Id lbLookupValueID = new LookupValue_Id(new LookupField_Id(PAY_PROCESS_NAMES_LOOKUP), parmPayProcessNameLB);
        if(isNull(lbLookupValueID.getEntity())) {
             addError(CustomMessageRepositorySpireOne.CCB029_invalidLookupValue(BATCH_PARM_NAME_PAY_PROC_NM_LB, parmPayProcessNameLB, PAY_PROCESS_NAMES_LOOKUP));
        }
        
        // Pay Process Name CIE must be a valid value for the CM_PAY_PROC_NM_FLG lookup
        LookupValue_Id cieLookupValueID = new LookupValue_Id(new LookupField_Id(PAY_PROCESS_NAMES_LOOKUP), parmPayProcessNameCIE);
        if(isNull(cieLookupValueID.getEntity())) {
             addError(CustomMessageRepositorySpireOne.CCB029_invalidLookupValue(BATCH_PARM_NAME_PAY_PROC_NM_CIE, parmPayProcessNameCIE, PAY_PROCESS_NAMES_LOOKUP));
        }
        
        // Tender Source Master Configuration BO must be a valid Master Configuration BO
        MasterConfiguration_Id masterConfigId = new MasterConfiguration_Id(parmMasterConfigBO.getId());
        if (isNull(masterConfigId.getEntity())) {
            addError(CustomMessageRepositorySpireOne.CCB029_invalidMasterConfigBO(BATCH_PARM_NAME_TNDR_SRC_MASTER_CONFIG_BO, parmMasterConfigBO.getId().getTrimmedValue()));
        }
        
        // Dollar Help SA Type should be a valid SA Type for all CIS Divisions indicated in the 
        // Tender Source Master Config for the Lockbox and CIE Processes. 
        BusinessObjectInstance masterConfigBoInstance = BusinessObjectInstance.create(parmMasterConfigBO);
        masterConfigBoInstance.set("bo", parmMasterConfigBO);
        masterConfigBoInstance = BusinessObjectDispatcher.read(masterConfigBoInstance);
        
        COTSInstanceNode masterConfigData = masterConfigBoInstance.getGroup("masterConfigData");
        COTSInstanceList payTenderSrcMapping = masterConfigData.getList("payTenderSrcMapping");
        Iterator<COTSInstanceListNode> payTenderSrcMappingIter = payTenderSrcMapping.iterator();
        
        COTSInstanceListNode paySourceMappingNode = null;
        while(payTenderSrcMappingIter.hasNext()) {
            paySourceMappingNode = payTenderSrcMappingIter.next();
            String paySource = paySourceMappingNode.getLookup("paySource").value().trim();
            
            if (parmPayProcessNameLB.equals(paySource) || parmPayProcessNameCIE.equals(paySource)) {
                String cisDivisionStr = paySourceMappingNode.getString("cisDivision").trim();
                CisDivision cisDivision = new CisDivision_Id(cisDivisionStr).getEntity();
                ServiceAgreementType_Id saTypeId = new ServiceAgreementType_Id(cisDivision, parmDollarHelpSAType);
                
                if(isNull(saTypeId.getEntity())) {
                    addError(CustomMessageRepositorySpireOne.CCB029_invalidSATypeForCisDivision(
                            BATCH_PARM_NAME_SA_TYPE_CD_DOLLAR_HELP, parmDollarHelpSAType, cisDivisionStr));
                }
            } 
        }
        // End Change - NMendo - CCB029.Issue1 -  2021-05-12
    }
    
    // Start Delete - NMendo - CCB029.Issue1 -  2021-05-12
    //private void validateCisDivisionInLookup(LookupField cisTenderSrceLookup) {
    //    StringBuilder validateCisDiv = new StringBuilder();
    //    String cisDivStr;
    //    CisDivision_Id lookupCisDivId = null;
    //    
    //    validateCisDiv.append("SELECT FIELD_VALUE FROM CI_LOOKUP_VAL WHERE FIELD_NAME = :lookupField ");
    //    PreparedStatement validateCisDivQry = createPreparedStatement(validateCisDiv.toString(), getClass().getName());
    //    validateCisDivQry.bindEntity("lookupField", cisTenderSrceLookup);
    //    
    //    if(validateCisDivQry.list().size() == 0) {
    //        addError(CustomMessageRepositorySpireOne.CCB029_1_emptyLookup(cisTenderSrceLookup.getId().getTrimmedValue()));
    //    }
    //    
    //    for(SQLResultRow row : validateCisDivQry.list()) {
    //        cisDivStr = row.getString("FIELD_VALUE").trim();
    //        lookupCisDivId = new CisDivision_Id(cisDivStr);
    //        if(isNull(lookupCisDivId.getEntity())){
    //            addError(CustomMessageRepositorySpireOne.CCB029_1_invalidCisDivision(cisTenderSrceLookup.getId().getTrimmedValue(), cisDivStr));
    //        }
    //    }
    //    validateCisDivQry.close();
    //}
    //
    //private void validateTenderSourceInLookup(LookupField cisTenderSrceLookup) {
    //    StringBuilder validateTenderSrc = new StringBuilder();
    //    String tenderSrcStr;
    //    TenderSource_Id lookupTndrSrcId = null;
    //    
    //    validateTenderSrc.append("SELECT DESCR FROM CI_LOOKUP_VAL_L WHERE FIELD_NAME = :lookupField ");
    //    PreparedStatement validateTenderSrcQry = createPreparedStatement(validateTenderSrc.toString(), getClass().getName());
    //    validateTenderSrcQry.bindEntity("lookupField", cisTenderSrceLookup);
    //    
    //    for(SQLResultRow row : validateTenderSrcQry.list()) {
    //        tenderSrcStr = row.getString("DESCR").trim();
    //        lookupTndrSrcId = new TenderSource_Id(tenderSrcStr);
    //        if(isNull(lookupTndrSrcId.getEntity())) {
    //            addError(CustomMessageRepositorySpireOne.CCB029_1_invalidTenderSource(cisTenderSrceLookup.getId().getTrimmedValue(), tenderSrcStr));
    //        }
    //    }
    //    validateTenderSrcQry.close();
    //}
    // End Delete - NMendo - CCB029.Issue1 -  2021-05-12

    public Class<CmRegionsBankPaymentUploadForAlabamaGulfBatchWorker> getThreadWorkerClass() {
        return CmRegionsBankPaymentUploadForAlabamaGulfBatchWorker.class;
    }

    public static class CmRegionsBankPaymentUploadForAlabamaGulfBatchWorker
            extends CmRegionsBankPaymentUploadForAlabamaGulfBatchWorker_Gen {
    	 
        // Constant Variables
        private static final String BLANK = "";
        private static final String DASH = "-";
        private static final String TRAILER_LBL = "TOT";
        private static final String IDENTIFIER1_VALUE = "MP";
        // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
        private static final String COMMA = ",";
        private static final String DATE_FORMAT = "yyyyMMdd";
          // End Add - NMendo - CCB029.Issue1 -  2021-05-12
        
        // Batch Parameter Variables
        private String parmFilePath;
        private String parmFileName;
        // Start Change - NMendo - CCB029.Issue1 -  2021-05-12
        //private LookupField cisTenderSrceLookupForLB;
        //private LookupField cisTenderSrceLookupForCIE;
        private String parmPayProcessNameLB;
        private String parmPayProcessNameCIE;
        private BusinessObject parmMasterConfigBO;
        private FeatureConfiguration parmDollarHelpFeatConfig;
        private String parmDollarHelpSAType;
        // End Change - NMendo - CCB029.Issue1 -  2021-05-12
        private TenderSource defaultTenderSourceForLB;
        private TenderSource defaultTenderSourceForCIE;
        private TenderType tenderTypeLB;
        private TenderType tenderTypeCIE;
		// Start Add - NMendo - Defect 4595996 - 2021-09-17
        private String parmPaymentBatchNumber;
        // End Add - NMendo - Defect 4595996 - 2021-09-17
        
        // Working Variables
        private BufferedReader bufferedReader;
        private String recordLine;
        private CisDivision_Id tempCisDivId = null;
        
        private int totalNbrOfPaymentsFrmFile = 0;
        private BigDecimal totalAmountFrmFile = BigDecimal.ZERO;
        private BigDecimal totalAmountProcessed = BigDecimal.ZERO;
        // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
        private Map<String, String> tenderSourceMap = null;
        private TenderSource tenderSource;
        // End Add - NMendo - CCB029.Issue1 -  2021-05-12

        // Record Value Holder
        private String dateStr;
        private String accountNbrStr;
        private String amountStr;
        private String identifier_1;
        private String identifier_2;
        private String batchNbrStr;
        private String batchSeqStr;
        private String externalTransmitId;
        // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
        private String dollarHelpIndicator;
        private Date startDate;
        // End Add - NMendo - CCB029.Issue1 -  2021-05-12
        
        private String totalNbrOfPaymentsFrmFileStr;
        private String totalAmountFrmFileStr;
        
        private BigInteger lineCounter = BigInteger.ZERO;
        private BigDecimal amount;
        private Bool isSuspenseAccount = Bool.FALSE;
        private String newAccountNbrStr;
        
        // Detail Record
        private static final int ACCOUNT_NBR_INDEX = 1 - 1;
        private static final int AMOUNT_INDEX = 14 - 1;
        private static final int IDENTIFIER_1_INDEX = 23 -1;
        private static final int IDENTIFIER_2_INDEX = 25 - 1;
        private static final int BATCH_NBR_INDEX = 37 - 1;
        private static final int BATCH_SEQ_INDEX = 40 - 1;
        // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
        private static final int DOLLAR_HELP_INDICATOR_INDEX = 44 - 1;
        // End Add - NMendo - CCB029.Issue1 -  2021-05-12
        
        private static final int ACCOUNT_NBR_LENGTH = 13;
        private static final int AMOUNT_LENGTH = 9;
        private static final int IDENTIFIER_1_LENGTH = 2;
        private static final int IDENTIFIER_2_LENGTH = 12;
        private static final int BATCH_NBR_LENGTH = 3;
        private static final int BATCH_SEQ_LENGTH = 4;
        // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
        private static final int DOLLAR_HELP_INDICATOR_LENGTH = 2;
        // End Add - NMendo - CCB029.Issue1 -  2021-05-12
        
        // Trailer Record
        private static final int TOTAL_LBL_INDEX = 1 - 1;
        private static final int DATE_INDEX = 4 - 1;
        private static final int TOTAL_NBR_PAYMENTS_INDEX = 12 - 1;
        private static final int TOTAL_AMT_PAYMENTS_INDEX = 19 - 1;
        
        private static final int TOTAL_LBL_LENGTH = 3;
        private static final int DATE_LENGTH = 8;
        private static final int TOTAL_NBR_PAYMENTS_LENGTH = 7;
        private static final int TOTAL_AMT_PAYMENTS_LENGTH = 13;
        
        
        private static final int CCB_ACCOUNT_NBR_LENGTH = 10;
        private static final String SAVE_POINT = "SAVE_POINT";
        private FrameworkSession session;
                
        private int totalRecordCount = 0;
        private int numberOfRecordsInError = 0;

        // Start Add - FRoig - Defect 4572037 -  2021-07-16
        private Bool isTenderSourceNotFound = Bool.FALSE;
        // End Add - FRoig - Defect 4572037 -  2021-07-16

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new SingleTransactionStrategy(this);
        }
        
        @Override
        public void initializeThreadWork(
                boolean initializationPreviouslySuccessful)
                throws ThreadAbortedException, RunAbortedException {
            
            parmFilePath = getParameters().getFILE_PATH().trim();
            parmFileName = getParameters().getFILE_NAME().trim();
            // Start Change - NMendo - CCB029.Issue1 -  2021-05-12
            //cisTenderSrceLookupForLB = getParameters().getCIS_DIV_TNDR_SRCE_LB_LOOKUP();
            //cisTenderSrceLookupForCIE = getParameters().getCIS_DIV_TNDR_SRCE_CIE_LOOKUP();
            parmPayProcessNameLB = getParameters().getPAY_PROC_NM_LB().trim();
            parmPayProcessNameCIE = getParameters().getPAY_PROC_NM_CIE().trim();
            parmMasterConfigBO = getParameters().getTNDR_SRC_MASTER_CONFIG_BO();
            parmDollarHelpFeatConfig = getParameters().getFEATURE_CFG_DOLLAR_HELP();
            parmDollarHelpSAType = getParameters().getSA_TYPE_CD_DOLLAR_HELP().trim();
            // End Change - NMendo - CCB029.Issue1 -  2021-05-12
            defaultTenderSourceForLB = getParameters().getTENDER_SOURCE_CD_LB_DEFAULT();
            defaultTenderSourceForCIE = getParameters().getTENDER_SOURCE_CD_CIE_DEFAULT();
            tenderTypeLB = getParameters().getTENDER_TYPE_CD_LOCKBOX();
            tenderTypeCIE = getParameters().getTENDER_TYPE_CD_CIE();
            // Start Add - NMendo - Defect 4595996 - 2021-09-17
            parmPaymentBatchNumber = getParameters().getPYMT_BATCH_NBR().trim();
            // End Add - NMendo - Defect 4595996 - 2021-09-17

            accountNbrStr = BLANK;
            amountStr = BLANK;
            amount = BigDecimal.ZERO;
            identifier_1 = BLANK;
            identifier_2 = BLANK;
            batchNbrStr = BLANK;
            batchSeqStr = BLANK;
            externalTransmitId = BLANK;
            dateStr = BLANK;
            
            isSuspenseAccount = Bool.FALSE;
            tempCisDivId = null;
        }

        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
            
            // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
            // Read Master Configuration BO
            BusinessObjectInstance masterConfigBoInstance = BusinessObjectInstance.create(parmMasterConfigBO);
            masterConfigBoInstance.set("bo", parmMasterConfigBO);
            masterConfigBoInstance = BusinessObjectDispatcher.read(masterConfigBoInstance);
            
            COTSInstanceNode masterConfigData = masterConfigBoInstance.getGroup("masterConfigData");
            COTSInstanceList payTenderSrcMapping = masterConfigData.getList("payTenderSrcMapping");
            Iterator<COTSInstanceListNode> payTenderSrcMappingIter = payTenderSrcMapping.iterator();
            
            tenderSourceMap = new ConcurrentHashMap<>();
            String mapKey = null;
            COTSInstanceListNode paySourceMappingNode = null;
            while(payTenderSrcMappingIter.hasNext()) {
                paySourceMappingNode = payTenderSrcMappingIter.next();
                String paySource = paySourceMappingNode.getLookup("paySource").value().trim();
                String cisDivision = paySourceMappingNode.getString("cisDivision").trim();
                mapKey = paySource.concat(COMMA).concat(cisDivision);
                
                if (isNull(tenderSourceMap.get(mapKey))) {
                	logger.info("mapKey: " + mapKey);
                    tenderSourceMap.put(mapKey, paySourceMappingNode.getString("tenderSource"));
                } 
            }
            logger.info("tenderSourceMap.keySet(): " + tenderSourceMap.keySet());
            logger.info("tenderSourceMap.size(): " + tenderSourceMap.size());
            // End Add - NMendo - CCB029.Issue1 -  2021-05-12
            
            processFile();
            
            // Log Total Number of Records Processed and Total Amount of Payment Processed
            logMessage(CustomMessageRepositorySpireOne.CCB029_1_totalNbrOfPaymentRecordsProcessed(totalRecordCount), MessageSeverityLookup.constants.INFORMATIONAL);
            logMessage(CustomMessageRepositorySpireOne.CCB029_1_totalPaymentAmountProcessed(totalAmountProcessed.toString()), MessageSeverityLookup.constants.INFORMATIONAL);  

            // Set Batch Run Totals
            WorkUnitResult workUnitResult = new WorkUnitResult(true);
            workUnitResult.setUnitsProcessed(totalRecordCount);
            workUnitResult.setUnitsInError(numberOfRecordsInError);
            return workUnitResult;
        }
        
        /**
         * This method will process the file.
         */
        private void processFile() {
            openFile();

            session = (FrameworkSession)SessionHolder.getSession();
            session.setSavepoint(SAVE_POINT);

            // Read Input File
            recordLine = null;
            
            // Open File to read the trailer record for the externalTransmitId
            String trailerRecord = null;
            while(notNull(trailerRecord = readLineFromFile())) {
                String recordType = getFieldValue(trailerRecord, TOTAL_LBL_INDEX, TOTAL_LBL_LENGTH);
                if(recordType.equalsIgnoreCase(TRAILER_LBL)) {
                    externalTransmitId = trailerRecord;
                    // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
                    String startDateStr = getFieldValue(trailerRecord, DATE_INDEX, DATE_LENGTH);
                    try {
                        DateFormat dateFormat = new DateFormat(DATE_FORMAT);
                        startDate = dateFormat.parseDate(startDateStr);
                    } catch (DateFormatParseException e) {
                        addError(CustomMessageRepositorySpireOne.CCB029_invalidTrailerDate(startDateStr, DATE_FORMAT));
                    }
                    // End Add - NMendo - CCB029.Issue1 -  2021-05-12
                }
            }
            
           closedFile();

           // Open File to read detail records.
           openFile();
           
            while (!isBlankOrNull(recordLine = readLineFromFile())) {
                lineCounter = lineCounter.add(BigInteger.ONE);

                try {
                    processRecords();
                } catch(ApplicationError ae) {
                    session.rollbackToSavepoint(SAVE_POINT);
                    numberOfRecordsInError  = numberOfRecordsInError + 1;
                    addError(CustomMessageRepositorySpireOne.CCB029_1_errorInFile(ae.getServerMessage().getMessageText().trim()));
                }
            }
            closedFile();
        }
        
        /**
         * This method will open the file in preparation for Read.
         */
        private void openFile() {
            // Local variables
            File fileForRead = new File(parmFilePath, parmFileName);
            BufferedReader tempBufferedReader = null;
    
            try {
                // Open file
                tempBufferedReader = new BufferedReader(new FileReader(fileForRead));
            } catch (IOException e) {
                addError(CustomMessageRepositorySpireOne.CCB029_1_fileOpenError(parmFileName));
            }
    
            this.bufferedReader = tempBufferedReader;
        }
        
        /**
         * This method will read a line in the file.
         * @return String - the line read from the file.
         */
        private String readLineFromFile() {
            try {
                return bufferedReader.readLine();
            } catch (IOException e) {
                throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB029_1_FileReadError(parmFileName));
            }
        }
        
        /**
         * This method will closed the file.
         */
        private void closedFile() {
            try {
                if (notNull(bufferedReader)) {
                    this.bufferedReader.close();
                }
            } catch (IOException e) {
                addError(CustomMessageRepositorySpireOne.CCB029_1_FileClosingError(parmFileName));
            }
        }

        /**
         * This method will process each record present in the payment file.
         */
        private void processRecords(){
            String recordType = getFieldValue(recordLine, TOTAL_LBL_INDEX, TOTAL_LBL_LENGTH);
            
            if(recordType.equalsIgnoreCase(TRAILER_LBL)) {
                processTrailer();
            } else {
                processDetailsRecord();
            }
        }
        
        /**
         * This method will process each payment record in the payment file.
         */
        private void processDetailsRecord() {
            // Validate each field in the file
            validateInputFields();

            // Start Change - NMendo - CCB029.Issue1 -  2021-05-12
            // Remove leading zeroes from the account number string.
            //String strPattern = "^0+(?!$)";
            //newAccountNbrStr = accountNbrStr.replaceAll(strPattern, "");
            
            Account_Id acctId = null;
            //if(newAccountNbrStr.length() > CCB_ACCOUNT_NBR_LENGTH) {
                //acctId = new Account_Id(newAccountNbrStr.substring(0, 2));
            //} else {
                //acctId = new Account_Id(newAccountNbrStr);
            //}
            
            String accountNbr12Digit = null;
            String accountNbr10Digit = null;
            // Start Add - FRoig - 4602770 - 2021-10-02
            isTenderSourceNotFound = Bool.FALSE;
            // End Add - FRoig - 4602770 - 2021-10-02
            logger.info("isTenderSourceNotFound value before account processing: " + isTenderSourceNotFound.toString());
            
            accountNbrStr = accountNbrStr.trim();
            logger.info("accountNbrStr: " + accountNbrStr);
            if(accountNbrStr.trim().length() == 13) {
            	// Start Add - RDizon - CCB029.Issue2 - 2021-06-21
                if(accountNbrStr.charAt(0) != '0') {
                    isSuspenseAccount = Bool.TRUE;
                    logger.info("account is 13 digit. isSuspenseAccount: " + isSuspenseAccount.toString());
                }
                // End Add - RDizon - CCB029.Issue2 - 2021-06-21
                accountNbr12Digit = accountNbrStr.substring(1);
            } else {
            	// Start Add - RDizon - CCB029.Issue2 - 2021-06-21
                if (accountNbrStr.trim().length() != 12 && accountNbrStr.trim().length() != 10) {
                    isSuspenseAccount = Bool.TRUE;
                    logger.info("account is neither 12 nor 10 digit. isSuspenseAccount: " + isSuspenseAccount.toString());
                }
                // End Add - RDizon - CCB029.Issue2 - 2021-06-21
                accountNbr12Digit = accountNbrStr;
            }
            
            if(accountNbr12Digit.substring(0, 2).equals("00")) {
                accountNbr10Digit = accountNbr12Digit.substring(2);
                logger.info("account is 10 digit (left zero padded 12 digit). accountNbr10Digit: " + accountNbr10Digit);
            }

            if(notNull(accountNbr10Digit)) {
                acctId = new Account_Id(accountNbr10Digit);
            }
            
            // If Account was found using the 10-digit number
            if(notNull(acctId) && notNull(acctId.getEntity())) {
                tempCisDivId = acctId.getEntity().getDivisionId();
                newAccountNbrStr = acctId.getTrimmedValue();
                logger.info("account was found in CCB. newAccountNbrStr: " + newAccountNbrStr + " tempCisDivId: " + tempCisDivId.getIdValue());
            } else {
                // Otherwise, Check the OLD_ACCT_ID from the CI_SA table
                //acctId = retrieveOldAccount(newAccountNbrStr);
                // Check if the 12 digit Account Number exists as Old Account ID
            	logger.info("checking for old account id. accountNbr12Digit: " + accountNbr12Digit);
            	acctId = retrieveOldAccount(accountNbr12Digit);
                
                if(isNull(acctId) || isNull(acctId.getEntity())) {
                    isSuspenseAccount = Bool.TRUE;
                    newAccountNbrStr = accountNbr12Digit;
                    logger.info("old account not found. newAccountNbrStr: " + newAccountNbrStr);
                } else {
                    tempCisDivId = acctId.getEntity().getDivisionId();
                    newAccountNbrStr = acctId.getTrimmedValue();
                    logger.info("old account **FOUND**. newAccountNbrStr: " + newAccountNbrStr + " tempCisDivId: " + tempCisDivId.getIdValue());
                }
            }
            logger.info("End of acct check. isSuspenseAccount: " + isSuspenseAccount.toString());
            // End Change - NMendo - CCB029.Issue1 -  2021-05-12
            if(isSuspenseAccount.isFalse()) {
                // Process Payment for identified account
                processPayment();
                
                // Start Change - FRoig - Defect 4572037 - 2021-07-16
                // If no tender source was found or configured, treat the payment like a suspense payment
                if (isTenderSourceNotFound.isTrue()) {
                    isSuspenseAccount = Bool.TRUE;
                    newAccountNbrStr = accountNbrStr;
                    logger.info("processing as suspense payment, tender source not found. newAccountNbrStr: " + newAccountNbrStr);
                	processSuspensePayment();
                } else {
	                // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
	                // Process Dollar Help
	                if(!isBlankOrNull(dollarHelpIndicator.trim())) {
	                    processDollarHelp(acctId);
	                }
	                // End Add - NMendo - CCB029.Issue1 -  2021-05-12
                }
                // End Change - FRoig - Defect 4572037 - 2021-07-16
                
            } else {
                // Process Suspense Payment
            	// Start Add - RDizon - CCB029.Issue2 - 2021-06-21
            	newAccountNbrStr = accountNbrStr;
            	// End Add - RDizon - CCB029.Issue2 - 2021-06-21
                processSuspensePayment();
            }
            
            totalAmountProcessed = totalAmountProcessed.add(amount);
            totalRecordCount = totalRecordCount + 1;

            // Reset Record Value Holder Variables
            accountNbrStr = BLANK;
            amountStr = BLANK;
            amount = BigDecimal.ZERO;
            identifier_1 = BLANK;
            identifier_2 = BLANK;
            batchNbrStr = BLANK;
            batchSeqStr = BLANK;
            // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
            dollarHelpIndicator = BLANK;
            // End Add - NMendo - CCB029.Issue1 -  2021-05-12
            isSuspenseAccount = Bool.FALSE;
            tempCisDivId = null;
            newAccountNbrStr = BLANK;
        }

        /**
         * This method will retrieve the trimmed field value from the record starting 
         * from the startPos and of the given length.
         * @param record - String
         * @param startPos - int
         * @param length - int
         * @return value - String
         */
        private String getFieldValue(String record, int startPos, int length) {
            String value = null;
            if(record.length() >= startPos+length) {
                value = record.substring(startPos, startPos+length).trim();
            } else {
                value = record.substring(startPos, record.length()).trim();
            }
        
            return value;
        }
        
        /**
         * This method will retrieve and validate each field in the file.
         */
        private void validateInputFields() {
            accountNbrStr = getFieldValue(recordLine, ACCOUNT_NBR_INDEX, ACCOUNT_NBR_LENGTH);
            amountStr = getFieldValue(recordLine, AMOUNT_INDEX, AMOUNT_LENGTH);
            identifier_1 = getFieldValue(recordLine, IDENTIFIER_1_INDEX, IDENTIFIER_1_LENGTH);
            identifier_2 = getFieldValue(recordLine, IDENTIFIER_2_INDEX, IDENTIFIER_2_LENGTH);
            batchNbrStr = getFieldValue(recordLine, BATCH_NBR_INDEX, BATCH_NBR_LENGTH);
            batchSeqStr = getFieldValue(recordLine, BATCH_SEQ_INDEX, BATCH_SEQ_LENGTH);
            // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
            dollarHelpIndicator = getFieldValue(recordLine, DOLLAR_HELP_INDICATOR_INDEX, DOLLAR_HELP_INDICATOR_LENGTH);
            // End Add - NMendo - CCB029.Issue1 -  2021-05-12
            // Validate if the Account Number is numeric. 
            validateAccountNumber();
            
            // Validate if the Amount is numeric.
            amount = validateAmount(amountStr);
            
            // Validate if the Identifier 1 is MP or Blank
            if(!identifier_1.equalsIgnoreCase(IDENTIFIER1_VALUE) && !isBlankOrNull(identifier_1)) {
                addError(CustomMessageRepositorySpireOne.CCB029_2_invalidIdentifier1(lineCounter.toString()));
            }
            
            // Validate if the Batch Number is numeric.
            if(!isNumeric(batchNbrStr)) {
                addError(CustomMessageRepositorySpireOne.CCB029_2_invalidBatchNumber(lineCounter.toString()));
            }
            
            // Validate if the Batch Sequence is numeric.
            if(!isNumeric(batchSeqStr)) {
                addError(CustomMessageRepositorySpireOne.CCB029_2_invalidBatchSequence(lineCounter.toString()));
            }
        }

        /**
         * This method will validate the account number in the file.
         */
        private void validateAccountNumber() {
            // Validate if Account Number field is numeric
            if(!isNumeric(accountNbrStr)) {
                addError(CustomMessageRepositorySpireOne.CCB029_1_invalidAccountNumber(lineCounter.toString()));
            }
            
            // Start Delete - RDizon - CCB029.Issue2 - 2021-06-21
            // If Account Number length is 13 and first character is a non-zero, raise an error.
            // if(accountNbrStr.length() == ACCOUNT_NBR_LENGTH) {
            //    if(accountNbrStr.charAt(0) != '0') {
            //        addError(CustomMessageRepositorySpireOne.CCB029_1_invalidAccountNumber(lineCounter.toString()));
            //     }
            // }
            // End Delete - RDizon - CCB029.Issue2 - 2021-06-21
        }
        
        /**
         * This method will validate if each character in a string is numeric.
         * @param amount - String
         * @return isNumeric - Boolean 
         */
        private Boolean isNumeric(String amount) {
            boolean isNumeric = amount.chars().allMatch(x -> Character.isDigit(x));
            return isNumeric;
        }
        
        /**
         * This method checks if the amount string is convertible to BigDecimal.
         * @param amount - String
         * @return tempAmount - BigDecimal 
         */
        private BigDecimal validateAmount(String amount) {
            // Validate if Amount field is numeric
            if(!isNumeric(amount)) {
                addError(CustomMessageRepositorySpireOne.CCB029_1_invalidAmount(lineCounter.toString()));
            }
                
            String decimalStr =  amount.substring(amount.length() - 2, amount.length());
            String wholeNbrStr = amount.substring(0, amount.length() - 2);
            BigDecimal tempAmount = BigDecimal.ZERO;
            
            try {
                tempAmount = new BigDecimal (wholeNbrStr.concat(".").concat(decimalStr));
            }
            catch (NumberFormatException nfe) {
                addError(CustomMessageRepositorySpireOne.CCB029_1_invalidAmount(lineCounter.toString()));
            }
            return tempAmount;
        }    
        
        /**
         * This method will retrieve the account id from old account id in the CI_SA.
         * @param acctStr - String
         * @return accountId - Account_Id          
         */
        private Account_Id retrieveOldAccount(String acctStr) {
            SQLResultRow firstRow = null;
            Account_Id accountId = null;
            
            StringBuilder retrieveOldAcctFromSA = new StringBuilder();
            retrieveOldAcctFromSA.append("SELECT DISTINCT SA.ACCT_ID ");
            retrieveOldAcctFromSA.append("FROM ");
            retrieveOldAcctFromSA.append(        "CI_SA SA ");
            retrieveOldAcctFromSA.append("WHERE ");
            retrieveOldAcctFromSA.append(    "SA.OLD_ACCT_ID = :oldAccountId ");
            
            PreparedStatement retrieveOldAcctFromSAQry = createPreparedStatement(retrieveOldAcctFromSA.toString(), getClass().getName()); 
            retrieveOldAcctFromSAQry.bindStringProperty("oldAccountId", ServiceAgreement.properties.oldAccountId, acctStr); 
            
           if(retrieveOldAcctFromSAQry.list().size() == 1) {
               firstRow = retrieveOldAcctFromSAQry.firstRow();
               accountId = (Account_Id) firstRow.getId("ACCT_ID", Account.class);
           }
           
           retrieveOldAcctFromSAQry.close();
           
           return accountId;
        }
        
        /**
         * This method will validate the date in the file.
         */
        private void validateDate() {
            String year = dateStr.substring(0, 4);
            String month = dateStr.substring(4, 6);
            String day = dateStr.substring(6, 8);

            String newDateStr = year.concat(DASH).concat(month).concat(DASH).concat(day);

            try {
                Date.fromString(newDateStr, new DateFormat("yyyy-MM-dd"));
            } catch (DateFormatParseException ex) {
                addError(CustomMessageRepositorySpireOne.CCB029_1_invalidDateFormat(lineCounter.toString()));
            }
        }

        /**
         * This method will process trailer fields.
         */
        private void processTrailer() {

            retrieveAndValidateTrailerFields();
            
            totalNbrOfPaymentsFrmFile = Integer.valueOf(totalNbrOfPaymentsFrmFileStr);
            
            if(totalNbrOfPaymentsFrmFile != totalRecordCount){
                addError(CustomMessageRepositorySpireOne.CCB029_2_trailerTotalRecordsAndTotalNbrOfRecProcNotSame(String.valueOf(totalNbrOfPaymentsFrmFile), String.valueOf(totalRecordCount)));
            }
            
            if(totalAmountFrmFile.compareTo(totalAmountProcessed) != 0) {
                addError(CustomMessageRepositorySpireOne.CCB029_2_trailerTotalAmountAndTotalAmountProcNotSame(totalAmountFrmFile.toString(), totalAmountProcessed.toString()));
            }
        }
        
        /**
         * This method will retrieve and validate trailer fields.
         */
        private void retrieveAndValidateTrailerFields() {
            dateStr = getFieldValue(recordLine, DATE_INDEX, DATE_LENGTH);
            totalNbrOfPaymentsFrmFileStr = getFieldValue(recordLine, TOTAL_NBR_PAYMENTS_INDEX, TOTAL_NBR_PAYMENTS_LENGTH);
            totalAmountFrmFileStr = getFieldValue(recordLine, TOTAL_AMT_PAYMENTS_INDEX, TOTAL_AMT_PAYMENTS_LENGTH);
            
            // Validate if the date from the file is in YYYYMMDD format.
            validateDate();
            
            // Validate if Total Number of Payments is numeric.
            if(!isNumeric(totalNbrOfPaymentsFrmFileStr)) {
                addError(CustomMessageRepositorySpireOne.CCB029_2_invalidTotalNumberOfPayments(lineCounter.toString()));
            }
            
            // Validate if the Total Amount in trailer is convertible to Big Decimal.
            String decimalStr =  totalAmountFrmFileStr.substring(totalAmountFrmFileStr.length() - 2, totalAmountFrmFileStr.length());
            String wholeNbrStr = totalAmountFrmFileStr.substring(0, totalAmountFrmFileStr.length() - 2);
            BigDecimal tempAmount = BigDecimal.ZERO;
            
            try {
                tempAmount = new BigDecimal (wholeNbrStr.concat(".").concat(decimalStr));
            }
            catch (NumberFormatException nfe) {
                addError(CustomMessageRepositorySpireOne.CCB029_2_invalidTotalAmountOfPayments(lineCounter.toString()));
            }
            
            totalAmountFrmFile = tempAmount;
        }    
        
        /**
         * This method will retrieve the Tender Source mapped to the CIS Division from the 
         * CIS Division and Tender Source Lookup.
         * @param tempCisDivId - CisDivision_Id
         * @param cisTenderSrceLookup - LookupField
         * @return tenderSrcStr - Lookup Value Description          
         */
        // Start Change - NMendo - CCB029.Issue1 -  2021-05-12
        //private String retrieveTenderSource(CisDivision_Id tempCisDivId, LookupField cisTenderSrceLookup) {
        private String retrieveTenderSource(CisDivision_Id tempCisDivId, String payProcessName) {
        // End Change - NMendo - CCB029.Issue1 -  2021-05-12
            // Start Change - NMendo - CCB029.Issue1 -  2021-05-12
            //StringBuilder retrieveTenderSourceFromLookup = new StringBuilder();
            //
            //retrieveTenderSourceFromLookup.append("SELECT DESCR ");
            //retrieveTenderSourceFromLookup.append("FROM ");
            //retrieveTenderSourceFromLookup.append(        "CI_LOOKUP_VAL_L ");
            //retrieveTenderSourceFromLookup.append("WHERE ");
            //retrieveTenderSourceFromLookup.append(        "FIELD_NAME = :lookupField ");
            //retrieveTenderSourceFromLookup.append("AND FIELD_VALUE = :lookupValue ");
            //
            //PreparedStatement retrieveTenderSourceFromLookupQry = createPreparedStatement(retrieveTenderSourceFromLookup.toString(), getClass().getName());
            //retrieveTenderSourceFromLookupQry.bindEntity("lookupField", cisTenderSrceLookup);
            //retrieveTenderSourceFromLookupQry.bindStringProperty("lookupValue", com.splwg.base.domain.common.lookup.LookupValue.properties.fieldValue, tempCisDivId.getTrimmedValue());
            //
            //if(retrieveTenderSourceFromLookupQry.list().size() == 0) {
            //    addError(CustomMessageRepositorySpireOne.CCB029_1_tenderSourceIsMissing(tempCisDivId.getTrimmedValue()));
            //} 
            //
            //SQLResultRow firstRow = null;
            //firstRow = retrieveTenderSourceFromLookupQry.firstRow();
            //String tenderSrcStr = firstRow.getString("DESCR").trim();
            
            String cisDivisionStr = tempCisDivId.getTrimmedValue();
            logger.info("cisDivisionStr: " + cisDivisionStr);
            String mapKey = payProcessName.concat(COMMA).concat(cisDivisionStr);
            logger.info("mapKey: " + mapKey);
            String tenderSrcStr = tenderSourceMap.get(mapKey);
            
            if(isNull(tenderSrcStr)) {
                // Start Change - FRoig - Defect 4572037 -  2021-07-16
                //addError(CustomMessageRepositorySpireOne.CCB029_1_tenderSourceIsMissing(cisDivisionStr));
                isTenderSourceNotFound = Bool.TRUE;
                // End Change - FRoig - Defect 4572037 -  2021-07-16
            }
            // End Change - NMendo - CCB029.Issue1 -  2021-05-12
            
            return tenderSrcStr;
        }

        /**
         * This method will process payment based on the mapping of the CIS Division and Tender Source.
         */
        private void processPayment() {
            TenderType tenderType = null;
            String tenderSrcStr = "";
            // Start Add - FRoig - Defect 4572037 - 2021-07-16
            isSuspenseAccount = Bool.FALSE;
            // End Add - FRoig - Defect 4572037 - 2021-07-16
            
            // Check if the payment is Lockbox or CIE
            if(identifier_1.equalsIgnoreCase(IDENTIFIER1_VALUE)) {
                // Get Tender Source from the CIS Division and Tender Source Lookup
                // Start Change - NMendo - CCB029.Issue1 -  2021-05-12
                //tenderSrcStr = retrieveTenderSource(tempCisDivId, cisTenderSrceLookupForLB);
                tenderSrcStr = retrieveTenderSource(tempCisDivId, parmPayProcessNameLB);
                // End Change - NMendo - CCB029.Issue1 -  2021-05-12
                // Start Add - FRoig - Defect 4572037 - 2021-07-16
                // If Tender Source is not found, return and process the payment as a suspense payment instead.
                if (isTenderSourceNotFound.isTrue()) {
                	logger.info("LOCKBOX. isTenderSourceNotFound: " + isTenderSourceNotFound.toString());
                	return;
                }
                // End Add - FRoig - Defect 4572037 - 2021-07-16
                tenderType = tenderTypeLB;
            } else if (isBlankOrNull(identifier_1)) {
                // Get Tender Source from the CIS Division and Tender Source Lookup
                // Start Change - NMendo - CCB029.Issue1 -  2021-05-12
                //tenderSrcStr = retrieveTenderSource(tempCisDivId, cisTenderSrceLookupForCIE);
                tenderSrcStr = retrieveTenderSource(tempCisDivId, parmPayProcessNameCIE);
                // End Change - NMendo - CCB029.Issue1 -  2021-05-12
                // Start Add - FRoig - Defect 4572037 - 2021-07-16
                // If Tender Source is not found, return and process the payment as a suspense payment instead.
                if (isTenderSourceNotFound.isTrue()) {
                	logger.info("CIE. isTenderSourceNotFound: " + isTenderSourceNotFound.toString());
                	return;
                }
                // End Add - FRoig - Defect 4572037 - 2021-07-16
                tenderType = tenderTypeCIE;
            }
    
            tenderSource = new TenderSource_Id(tenderSrcStr).getEntity();
            
            // Check if Deposit Control for the CIS Division Tender Source is already created
            DepositControlStaging_Id depositCntlStgId = new DepositControlStaging_Id(tenderSource.getExternalSourceId(), externalTransmitId);
            
            if(isNull(depositCntlStgId.getEntity())) {
                // Create Staging Records for the CIS Division.
                DepositControlStaging newDepositControlStaging = createDepositControlStagingRecord(tenderSource, new Money(amount.toString(), tenderSource.getCurrency().getId()));
                createTenderControlStagingRecord(newDepositControlStaging, new Money(amount.toString(), tenderSource.getCurrency().getId()));
                createPaymentTenderStagingRecord(newDepositControlStaging, tenderType);
            } else {
                // Otherwise, Update existing Deposit and Tender Control Staging Records
                DepositControlStaging_DTO depositControlStagingDTO = depositCntlStgId.getEntity().getDTO();
                // Start Change - NMendo - Defect 4595996 - 2021-09-17
                //TenderControlStaging_Id tenderCntlStgId = new TenderControlStaging_Id(depositCntlStgId, batchNbrStr);
                TenderControlStaging_Id tenderCntlStgId = new TenderControlStaging_Id(depositCntlStgId, parmPaymentBatchNumber);
                // End Change - NMendo - Defect 4595996 - 2021-09-17
                
                // Start Change - NMendo - CCB029.Issue3 -  2021-06-22
                if(isNull(tenderCntlStgId.getEntity())) {
                	// Update Deposit Control Staging
                	Money tempMoney = depositCntlStgId.getEntity().getTenderControlTotalAmount();
                	tempMoney = tempMoney.add(new Money(amount.toString(), tenderSource.getCurrency().getId()));
                	BigInteger tempCtr = depositCntlStgId.getEntity().getTotalTenderControl();
                	tempCtr = tempCtr.add(BigInteger.ONE);
                	depositControlStagingDTO.setTenderControlTotalAmount(tempMoney);
                	depositControlStagingDTO.setTotalTenderControl(tempCtr);
                	depositCntlStgId.getEntity().setDTO(depositControlStagingDTO);
                	
                	// Create Tender Control Staging Record
                	createTenderControlStagingRecord(depositCntlStgId.getEntity(), new Money(amount.toString(), tenderSource.getCurrency().getId())).getId();
                
                } else {
                	// Update Deposit Control Staging
                	Money tempMoney = depositCntlStgId.getEntity().getTenderControlTotalAmount();
                	tempMoney = tempMoney.add(new Money(amount.toString(), tenderSource.getCurrency().getId()));
                	depositControlStagingDTO.setTenderControlTotalAmount(tempMoney);
                	depositCntlStgId.getEntity().setDTO(depositControlStagingDTO);
                	
                	// Update Tender Control Staging
                	TenderControlStaging_DTO tenderControlStagingDTO = tenderCntlStgId.getEntity().getDTO();
                	Money totalTenderAmount = tenderCntlStgId.getEntity().getTotalTendersAmount();
                	totalTenderAmount = totalTenderAmount.add(new Money(amount.toString(), tenderSource.getCurrency().getId()));
                    BigInteger tempCtr = tenderCntlStgId.getEntity().getTotalNumberOfTender();
                    tempCtr = tempCtr.add(BigInteger.ONE);
                    tenderControlStagingDTO.setTotalTendersAmount(totalTenderAmount);
                    tenderControlStagingDTO.setTotalNumberOfTender(tempCtr);
                    tenderCntlStgId.getEntity().setDTO(tenderControlStagingDTO);
            	}
                // End Change - NMendo - CCB029.Issue3 -  2021-06-22
                
                createPaymentTenderStagingRecord(depositCntlStgId.getEntity(), tenderType);
                logger.info("create Payment tender staging record processPayment().");
            }
        }
        
        /**
         * This method will process suspense payment.
         */
        private void processSuspensePayment() {
            TenderSource defaultTenderSource = null;
            TenderType tenderType = null;
            
            // Check if the payment is Lockbox or CIE
            if(identifier_1.equalsIgnoreCase(IDENTIFIER1_VALUE)) {
                defaultTenderSource = defaultTenderSourceForLB;
                tenderType = tenderTypeLB;
            } else if (isBlankOrNull(identifier_1)) {
                defaultTenderSource = defaultTenderSourceForCIE;
                tenderType = tenderTypeCIE;
            }
            
            // Check if Deposit Control for the Default Tender Source is already created
            DepositControlStaging_Id depositCntlStgId = new DepositControlStaging_Id(defaultTenderSource.getExternalSourceId(), externalTransmitId);
            
            if(isNull(depositCntlStgId.getEntity())) {    
                // Create Deposit Control for the Suspense Tender Source Default
                DepositControlStaging newDepositControlStaging = createDepositControlStagingRecord(defaultTenderSource, new Money(amount.toString(), defaultTenderSource.getCurrency().getId()));
                createTenderControlStagingRecord(newDepositControlStaging, new Money(amount.toString(), defaultTenderSource.getCurrency().getId()));
                createPaymentTenderStagingRecord(newDepositControlStaging, tenderType);
            } else {
                DepositControlStaging_DTO depositControlStagingDTO = depositCntlStgId.getEntity().getDTO();
                // Start Change - NMendo - Defect 4595996 - 2021-09-17
                //TenderControlStaging_Id tenderCntlStgId = new TenderControlStaging_Id(depositCntlStgId, batchNbrStr);
                TenderControlStaging_Id tenderCntlStgId = new TenderControlStaging_Id(depositCntlStgId, parmPaymentBatchNumber);
                // End Change - NMendo - Defect 4595996 - 2021-09-17
                
                // Start Change - NMendo - CCB029.Issue3 -  2021-06-22
                if(isNull(tenderCntlStgId.getEntity())) {
                	// Update Deposit Control Staging
                	Money tempMoney = depositCntlStgId.getEntity().getTenderControlTotalAmount();
                	tempMoney = tempMoney.add(new Money(amount.toString(), defaultTenderSource.getCurrency().getId()));
                	BigInteger tempCtr = depositCntlStgId.getEntity().getTotalTenderControl();
                	tempCtr = tempCtr.add(BigInteger.ONE);
                	depositControlStagingDTO.setTenderControlTotalAmount(tempMoney);
                	depositControlStagingDTO.setTotalTenderControl(tempCtr);
                	depositCntlStgId.getEntity().setDTO(depositControlStagingDTO);

                	// Create Tender Control Staging Record
                	createTenderControlStagingRecord(depositCntlStgId.getEntity(), new Money(amount.toString(), defaultTenderSource.getCurrency().getId())).getId();
                	
                } else {
                	// Update Deposit Control Staging
                	Money tempMoney = depositCntlStgId.getEntity().getTenderControlTotalAmount();
                	tempMoney = tempMoney.add(new Money(amount.toString(), defaultTenderSource.getCurrency().getId()));
                	depositControlStagingDTO.setTenderControlTotalAmount(tempMoney);
                	depositCntlStgId.getEntity().setDTO(depositControlStagingDTO);
                	
                	// Update Tender Control Staging
                	TenderControlStaging_DTO tenderControlStagingDTO = tenderCntlStgId.getEntity().getDTO();
                	Money totalTenderAmount = tenderCntlStgId.getEntity().getTotalTendersAmount();
                	totalTenderAmount = totalTenderAmount.add(new Money(amount.toString(), defaultTenderSource.getCurrency().getId()));
                    BigInteger tempCtr = tenderCntlStgId.getEntity().getTotalNumberOfTender();
                    tempCtr = tempCtr.add(BigInteger.ONE);
                    tenderControlStagingDTO.setTotalTendersAmount(totalTenderAmount);
                    tenderControlStagingDTO.setTotalNumberOfTender(tempCtr);
                    tenderCntlStgId.getEntity().setDTO(tenderControlStagingDTO);
            	}
                // End Change - NMendo - CCB029.Issue3 -  2021-06-22
                
                createPaymentTenderStagingRecord(depositCntlStgId.getEntity(), tenderType);
            }
        }
        
        /**
         * This method creates and inserts Deposit Control Staging record.
         * @param tenderSource - TenderSource
         * @param totTenderCtlAmount - Money
         * return depositControlStaging - DepositControlStaging
         */
        private DepositControlStaging createDepositControlStagingRecord (TenderSource tenderSource, Money totTenderCtlAmount) {
            startChanges();
            DepositControlStaging depositControlStaging = null;
            DepositControlStaging_Id depositControlStagingId = new DepositControlStaging_Id(tenderSource.getExternalSourceId(), externalTransmitId);                                                
            DepositControlStaging_DTO depositControlStagingDTO = depositControlStagingId.newDTO();                                                                                 
            depositControlStagingDTO.setDepositControlStagingStatus(DepositControlStagingStatusLookup.constants.PENDING);
            depositControlStagingDTO.setTransmissionDateTime(getProcessDateTime());                                                                       
            depositControlStagingDTO.setCurrencyId(tenderSource.getCurrency().getId());                                                                  
            depositControlStagingDTO.setTenderControlTotalAmount(totTenderCtlAmount);
            depositControlStagingDTO.setTotalTenderControl(BigInteger.ONE);
            depositControlStaging = depositControlStagingDTO.newEntity();
            saveChanges();
            
            return depositControlStaging;
        }
        
        /**
         * This method creates and inserts Tender Control Staging record.
         * @param depositControlStaging - DepositControlStaging
         * @param totTenderCtlAmount - Money
         * return tenderControlStaging - TenderControlStaging
         */ 
        private TenderControlStaging createTenderControlStagingRecord(DepositControlStaging depositControlStaging, Money totTenderCtlAmount) {
            startChanges();
            TenderControlStaging tenderControlStaging = null;
            TenderControlStaging_Id tenderControlStagingId = null;
            // Start Change - NMendo - Defect 4595996 - 2021-09-17
            //tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, batchNbrStr);
            tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, parmPaymentBatchNumber);
            // End Change - NMendo - Defect 4595996 - 2021-09-17
            TenderControlStaging_DTO tenderControlStagingDTO = tenderControlStagingId.newDTO();
            tenderControlStagingDTO.setTenderControlStatus(TenderControlStatusLookup.constants.PENDING);                                             
            tenderControlStagingDTO.setTotalTendersAmount(totTenderCtlAmount);
            tenderControlStagingDTO.setTotalNumberOfTender(BigInteger.ONE);
            tenderControlStaging = tenderControlStagingDTO.newEntity();
            saveChanges();
            
            return tenderControlStaging;
        }
        
        /**
         * This method creates and inserts Payment Tender Staging record.
         * @param depositControlStaging - DepositControlStaging
         * @param tenderType - TenderType
         */ 
        private void createPaymentTenderStagingRecord(DepositControlStaging depositControlStaging, TenderType tenderType) {
            startChanges();
            // Start Change - NMendo - Defect 4595996 - 2021-09-17
            //TenderControlStaging_Id tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, batchNbrStr);
            TenderControlStaging_Id tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, parmPaymentBatchNumber); 
            //PaymentTenderUpload_Id paymentTenderUploadId = new PaymentTenderUpload_Id(tenderControlStagingId, batchSeqStr);
            PaymentTenderUpload_Id paymentTenderUploadId = new PaymentTenderUpload_Id(tenderControlStagingId, batchNbrStr.concat(batchSeqStr));
            // End Change - NMendo - Defect 4595996 - 2021-09-17
            PaymentTenderUpload_DTO paymentTenderUploadDTO = paymentTenderUploadId.newDTO(); 
            paymentTenderUploadDTO.setPaymentTenderStagingStatus(PaymentTenderStagingStatusLookup.constants.PENDING);  
            paymentTenderUploadDTO.setTenderAmount(new Money (amount.toString(), depositControlStaging.getCurrency().getId()));               
            paymentTenderUploadDTO.setAccountingDate(getProcessDateTime().getDate());
            paymentTenderUploadDTO.setTenderTypeId(tenderType.getId());

            paymentTenderUploadDTO.setCustomerId(newAccountNbrStr);
            logger.info("createPaymentTenderStagingRecord newAccountNbrStr: " + newAccountNbrStr);
            paymentTenderUploadDTO.setMicrId(BLANK);                        
            paymentTenderUploadDTO.setName(BLANK);
            paymentTenderUploadDTO.setCheckNumber(BLANK);
            paymentTenderUploadDTO.newEntity();
            saveChanges();
        }
        
        // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
        /**
         * Process Dollar Help
         * @param accountId
         */
        private void processDollarHelp(Account_Id accountId) {
            // Retrieve Recurring Charge
            CmFeatureConfigurationRetriever featureConfigurationRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
            featureConfigurationRetriever.setParmWFMName(parmDollarHelpFeatConfig);
            featureConfigurationRetriever.setParmOptType("X".concat(dollarHelpIndicator.trim()));
            String strRecurringCharge = featureConfigurationRetriever.getMaxSequenceOptionValue();
            
            if(isBlankOrNull(strRecurringCharge)) {
                addError(CustomMessageRepositorySpireOne.CCB029_invalidDollarHelpIndicator(dollarHelpIndicator.trim(), parmDollarHelpFeatConfig.getId().getTrimmedValue()));
            }
            
            Money recurringCharge = new Money(strRecurringCharge, tenderSource.getCurrency().getId());
            
            // Retrieve Dollar Help SA of Account
            ServiceAgreement_Id dollarHelpSAId =  retrieveDollarHelpSA(accountId);
            
            // If no active Dollar Help SA was found
            if(isNull(dollarHelpSAId)) {
                // create a new Dollar Help SA
                createSA(accountId, recurringCharge);
            } else {
                // add recurring charge
                addRecurringCharge(dollarHelpSAId.getEntity(), recurringCharge);
            }
        }
        
        /**
         * Retrieve Dollar Help SA of Account
         * @param accountId
         * @return ServiceAgreement_Id
         */
        private ServiceAgreement_Id retrieveDollarHelpSA(Account_Id accountId) {
            ServiceAgreement_Id dollarHelpSAId = null;
            
            StringBuilder sb = new StringBuilder();
            sb.append("SELECT SA_ID ");
            sb.append("FROM CI_SA ");
            sb.append("WHERE ACCT_ID = :accountId ");
            sb.append("AND CIS_DIVISION = :cisDivision ");
            sb.append("AND SA_TYPE_CD = :saType ");
            sb.append("AND SA_STATUS_FLG IN (:pendingStart, :active) ");
            
            PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
            ps.bindId("accountId", accountId);
            ps.bindId("cisDivision", tempCisDivId);
            ps.bindStringProperty("saType",  ServiceAgreementType.properties.saType, parmDollarHelpSAType);
            ps.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
            ps.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
            
            SQLResultRow result = ps.firstRow();
            if(notNull(result)) {
                dollarHelpSAId = (ServiceAgreement_Id) result.getId("SA_ID", ServiceAgreement.class);
            }
            
            return dollarHelpSAId;
        }
        
        /**
         * Create Dollar Help SA
         * @param accountId
         * @param recurringCharge
         * @return ServiceAgreement
         */
        private ServiceAgreement createSA(Account_Id accountId, Money recurringCharge) {
            ServiceAgreementCreator saCreator = ServiceAgreementCreator.Factory.newInstance();
            ServiceAgreement_DTO saDto = (ServiceAgreement_DTO) createDTO(ServiceAgreement.class);
            ServiceAgreementCreatorData saCreatorData = ServiceAgreementCreatorData.Factory.newInstance();
            saDto.setServiceAgreementTypeId(new ServiceAgreementType_Id(tempCisDivId, parmDollarHelpSAType));
            saDto.setStatus(ServiceAgreementStatusLookup.constants.PENDING_START);
            saDto.setAccountId(accountId);
            saDto.setStartDate(startDate);
            saDto.setAreEstimatesAllowed(Bool.FALSE);
            saDto.setCustomerRead(CustomerReadLookup.constants.NO);
            saDto.setStartReason(StartReasonLookup.constants.CUSTOMER_REQUEST);
            saCreatorData.setRecurringChargeAmount(recurringCharge);
            saCreatorData.setShouldCreateFieldActivity(Bool.FALSE);
            saCreatorData.setShouldExcludeCopySASP(Bool.TRUE);
            saCreatorData.setCopyOption(CopyOptionForProposalSALookup.constants.COPY_OPTION_FOR_PROPOSAL_S_A_B_S_P);

            return saCreator.addServiceAgreement(saDto, saCreatorData);
        }
        
        /**
         * Add Recurring Charge to Dollar Help SA
         * @param sa
         * @param recurringChargeAmt
         */
        private void addRecurringCharge(ServiceAgreement sa, Money recurringChargeAmt){
            if(!sa.getRecurringCharges().isEmpty()){
                // Check for recurring charge with effective date = trailer date
                ListFilter<ServiceAgreementRecurringCharge> saRecurringChargeFilter = sa.getRecurringCharges().createFilter("where this.id.effectiveDate = :effDate", getClass().getName());
                saRecurringChargeFilter.bindDate("effDate", startDate);
                ServiceAgreementRecurringCharge saRecurringCharge = saRecurringChargeFilter.firstRow();
                
                if(notNull(saRecurringCharge)) {
                    if(!recurringChargeAmt.equals(saRecurringCharge.getRecurringChargeAmount())) {
                        // Update Recurring Charge Amount
                        ServiceAgreementRecurringCharge_DTO recurringChargeDto = saRecurringCharge.getDTO();
                        recurringChargeDto.setRecurringChargeAmount(recurringChargeAmt);
                        saRecurringCharge.setDTO(recurringChargeDto);
                    }
                    return;
                }
            }
            
            // Add Recurring Charge
            ServiceAgreementRecurringCharge_DTO recurringChargeDto = (ServiceAgreementRecurringCharge_DTO) createDTO(ServiceAgreementRecurringCharge.class);
            recurringChargeDto.setCurrencyId(recurringChargeAmt.getCurrencyId());
            recurringChargeDto.setRecurringChargeAmount(recurringChargeAmt);
            sa.getRecurringCharges().add(recurringChargeDto, startDate);
        }
        // End Add - NMendo - CCB029.Issue1 -  2021-05-12
    }

}
