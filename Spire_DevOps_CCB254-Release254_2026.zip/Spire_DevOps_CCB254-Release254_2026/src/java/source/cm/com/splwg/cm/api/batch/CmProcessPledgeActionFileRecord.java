/* 
 *********************************************************************** 
 *                 Confidentiality Information: 
 * 
 * This module is the confidential and proprietary information of 
 * Oracle Corporation; it is not to be copied, reproduced, or 
 * transmitted in any form, by any means, in whole or in part, 
 * nor is it to be used for any purpose other than that for which 
 * it is expressly provided without the written permission of 
 * Oracle Corporation. 
 * 
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION:
 * 
 * Pledge Action Input File
 * 
 ********************************************************************** 
 * 
 * 
 * CHANGE HISTORY: 
 * 
 * Date:       by:       Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-04-01  FMedin    Created. Initial Version. 
 ************************************************************************ 
 */
package com.splwg.cm.api.batch;


import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.base.api.datatypes.Bool;

/**
 * Process Pledge Action File Record
 * @author ffmedina
 *
 */
public class CmProcessPledgeActionFileRecord extends ColumnDelimitedRecord{

	// CONSTANT
	private static final String BLANK = "";
	
	// FIELDS
	private String accountId;
	private String serviceAgreementId;
	private String pledgeId;
	private String pledgeAmount;
	private String agencyAccountId;
	private String fundingType;
	private String confirmationDate;
	private String webTransactionId;
	private String action;
	private Bool parseError;
	
	private static final String DELIMITER = ",";
	private static int INPUT_FILE_RECORD_LINE_NBR_OF_TOKENS = 9;
	
	public CmProcessPledgeActionFileRecord(String recordLine) {
		super(1);

		String[] record = recordLine.split(DELIMITER);
		
		// Initialize fields
		parseError = Bool.TRUE;
		accountId = BLANK;
		serviceAgreementId = BLANK;
		pledgeId = BLANK;
		pledgeAmount = BLANK;
		agencyAccountId = BLANK;
		fundingType = BLANK;
		confirmationDate = BLANK;
		webTransactionId = BLANK;
		action = BLANK;
		
		// If the data tokens are complete
		if (record.length == INPUT_FILE_RECORD_LINE_NBR_OF_TOKENS) {
			accountId = record[0].trim();
			serviceAgreementId = record[1].trim();
			pledgeId = record[2].trim();
			pledgeAmount = record[3].trim();
			agencyAccountId = record[4].trim();
			fundingType = record[5].trim();
			confirmationDate = record[6].trim();
			webTransactionId = record[7].trim();
			action = record[8].trim();
			parseError = Bool.FALSE;
		}
	}

	public String getAccountId() {
		return accountId;
	}

	public String getAction() {
		return action;
	}

	public String getAgencyAccountId() {
		return agencyAccountId;
	}

	public String getConfirmationDate() {
		return confirmationDate;
	}

	public String getFundingType() {
		return fundingType;
	}

	public String getPledgeAmount() {
		return pledgeAmount;
	}

	public String getPledgeId() {
		return pledgeId;
	}

	public String getServiceAgreementId() {
		return serviceAgreementId;
	}

	public String getWebTransactionId() {
		return webTransactionId;
	}

	public Bool getParseError() {
		return parseError;
	}
}
