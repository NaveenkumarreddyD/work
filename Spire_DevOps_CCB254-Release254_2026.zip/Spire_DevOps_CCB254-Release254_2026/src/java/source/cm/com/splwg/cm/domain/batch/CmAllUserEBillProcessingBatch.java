/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * All User E-Bill Processing 
 * 
 * This Batch Process will read the records from the custom All User table.  
 * For each record, batch will determine whether the associated CCB Account 
 * currently reflects e-bill enrollment.
 * 
 * In addition to processing the e-bill enrollments above, batch will also 
 * process e-bill de-enrollments. Batch will check each CCB Account that 
 * reflects e-bill enrollment and determine whether the Account has a 
 * corresponding record in the custom All User table.
 *            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-02-12   JPunza  NI0019.1 Initial Version.
 * 2013-05-15   JPunza  Defect 1201. Skip record is Account Id is invalid
 *                      and ignore Account-Person without Bill Format.
 * 2013-08-30   SrikanthIM-34846. Change Parameter usage.
 * 2016-01-22   MPang   Updated for CCB v2.4 compilation
 * 2017-04-19   LBallo  CCB-CC-005.5.
 * 2017-08-22   LBallo  Defect 3828741. Remove the adding/updating of
 * 						Kubra Token 1 Account Characteristic for 
 * 						condition when the Account is in Kubra staging
 * 						table and Account in CCB bill format is E-Bill
 *                      and SSO/Checkfree flag exists with values Y or D
 *                      Adds an Account Characteristic filter 
 *                      in the deenrollment count.
 * 2017-09-15   GCinco  Defect 3855582. Add account characteristics even 
 *                      if account is already EBill for Checkfree 
 *                      processing      
 * 2017-09-26   SFelip  Defect 3870793. Return the logic which checks if 
 *                      an Account already has a Person whose Bill Format 
 *                      is 'E-Bill', process next record.                       
 *************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_Id;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_LanguageId;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CharacteristicTypeContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.cm.api.lookup.BillFormatLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.cm.domain.customerinfo.cmKubraAllUser.CmKubraAllUser;
import com.splwg.cm.domain.customerinfo.cmKubraAllUser.CmKubraAllUser_Id;

/**
 * @author jpunzalan2
 *
 @BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = toDoType, name = TO_DO_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CUSTOMER_CONTACT_CLASS, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CUSTOMER_CONTACT_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CC_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = MAX_UPDATES, required = true, type = integer)
 *            , @BatchJobSoftParameter (name = CC_CHAR_VALUE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = ENROLLED_VIA, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = EBILL_REG_KUBRA_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = EBILL_REG_CHECKFREE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = RECRPAY_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = TOKEN1_CHAR_TYPE, required = true, type = entity)})
 */
public class CmAllUserEBillProcessingBatch 
        extends CmAllUserEBillProcessingBatch_Gen {
    
    private static BigInteger enrollCount = BigInteger.ZERO;
    private static BigInteger deEnrollCount= BigInteger.ZERO;
    
    /*
     * CCB-CC-005.5 - 207-04-20 - End Add
     */
    private final String SSO = "SSO";
    private final String CHECKFREE = "CHECKFREE";
    
    private String enrolledViaStr;
    /*
     * CCB-CC-005.5 - 207-04-20 - End Add
     */
    
    public JobWork getJobWork() {
        
        //IM-34846. Change Parameter usage. Start

        // Count CC&B Accounts on e-bill 
/*        PreparedStatement countAccountsOnEbill = createPreparedStatement(
                "SELECT COUNT(AC.ACCT_ID) AS TALLY " +
                "FROM CI_ACCT AC " +
                "WHERE EXISTS (SELECT 'X' FROM CI_ACCT_PER AP " +
                "       WHERE AP.ACCT_ID = AC.ACCT_ID " +
                "       AND AP.BILL_FORMAT_FLG = :billFormat)");
        
        countAccountsOnEbill.bindLookup("billFormat", BillFormatLookup.constants.EBILL);
        
        SQLResultRow result = countAccountsOnEbill.firstRow();
        BigInteger numOfAccountsOnEbill = result.getInteger("TALLY");
        
        // Count Accounts on All User File
        PreparedStatement countAccountsOnAllUserFile = createPreparedStatement(
                "SELECT COUNT(KAU.ACCT_ID) AS TALLY " +
                "FROM CM_KUBRA_ALL_USER KAU");
        
        result = countAccountsOnAllUserFile.firstRow();
        BigInteger numOfAccountsOnAllUserFile = result.getInteger("TALLY");

        // Compare difference with the given Max Updates
        BigInteger difference = numOfAccountsOnEbill.subtract(numOfAccountsOnAllUserFile).abs();*/

        /*
         * CCB-CC-005.5 - 2017-04-20 - Start Add
         */
        enrolledViaStr = getParameters().getENROLLED_VIA();
        /*
         * CCB-CC-005.5 - 2017-04-20 - End Add
         */
        
         enrollCount = getEnrollmentCountToProcess();
         deEnrollCount = getDeEnrollmentCountToProcess();
         BigInteger totalCount = enrollCount.add(deEnrollCount);
        
        
       // IM-34846. Change Parameter usage. End
        
        BigInteger maxUpdates = getParameters().getMAX_UPDATES();
        
         //IM-34846. Change Parameter usage. Start
            // if (difference.compareTo(maxUpdates) > 0) { 
          if (totalCount.compareTo(maxUpdates) > 0) {
              
           /* 
            List<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
            ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
            arrayList.add(threadWorkUnit);
            
            return createJobWorkForThreadWorkUnitList(arrayList);
            */
              addError(CustomMessageRepositoryMDC.NI0019_1_numOfChangesExceeds(getParameters().getMAX_UPDATES()));  
          //IM-34846. Change Parameter usage. End
              
        }
          
        /*
         * CCB-CC-005.5 - 2017-04-20 - Start Add
         */
        CharacteristicType eBillKubra = getParameters().getEBILL_REG_KUBRA_CHAR_TYPE();
        CharacteristicType eBillCheckfree = getParameters().getEBILL_REG_CHECKFREE_CHAR_TYPE();
        String ccbSelectionAdditionalFilterStr = "";
        String tableSelectionAdditionalFilterStr = "";
        if(SSO.trim().compareTo(enrolledViaStr.trim()) ==  0) {
            ccbSelectionAdditionalFilterStr = "AND ACH.CHAR_TYPE_CD = :charType AND ACH.SRCH_CHAR_VAL = 'Y' )";
            tableSelectionAdditionalFilterStr = "WHERE KAU.CM_ENROLLED_VIA = :enrolledVia " +
                                                "AND NOT EXISTS " +
                                                " (SELECT 'X' FROM CM_RECR_PAY RP " +
                                                " WHERE RP.ACCT_ID = KAU.ACCT_ID ) ";
        } else if (CHECKFREE.trim().compareTo(enrolledViaStr.trim()) ==  0) {
            ccbSelectionAdditionalFilterStr = "AND ACH.CHAR_TYPE_CD = :charType AND (ACH.SRCH_CHAR_VAL = 'Y' OR ACH.SRCH_CHAR_VAL = 'D' )) ";
            tableSelectionAdditionalFilterStr = "WHERE KAU.CM_ENROLLED_VIA = :enrolledVia";
        }
        /*
         * CCB-CC-005.5 - 2017-04-20 - End Add
         */
        
        // Select Accounts to be processed from CI_ACCT and CM_KUBRA_ALL_USER
        PreparedStatement getAccounts = createPreparedStatement(
                // CCB-CC-005.5 - 2017-04-20 - Start Change
                //"SELECT AC.ACCT_ID, 'CI_ACCT' AS TABLE_FLAG " +
                "SELECT AC.ACCT_ID, 'CI_ACCT' AS TABLE_FLAG, '' AS CM_TOKEN1 " +
                // CCB-CC-005.5 - 2017-04-20 - End Change
                "FROM CI_ACCT AC " +
                "WHERE EXISTS (SELECT 'X' FROM CI_ACCT_PER AP " +
                "       WHERE AP.ACCT_ID = AC.ACCT_ID " +
                "       AND AP.BILL_FORMAT_FLG = :billFormat) " +
                "AND NOT EXISTS (SELECT 'X' FROM CM_KUBRA_ALL_USER AU " +
                "       WHERE AU.ACCT_ID = AC.ACCT_ID) " +
                /*
                 * CCB-CC-005.5 - 2017-04-20 - Start Add
                 */
                "AND EXISTS (SELECT 'X' FROM CI_ACCT_CHAR ACH " +
                       "WHERE ACH.ACCT_ID = AC.ACCT_ID " +
                       ccbSelectionAdditionalFilterStr +
                /*
                 * CCB-CC-005.5 - 2017-04-20 - End Add
                 */
                "UNION ALL " +
                //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
                //"SELECT KAU.ACCT_ID, KAU.CM_ENROLLED_VIA AS TABLE_FLAG FROM CM_KUBRA_ALL_USER KAU");
                // CCB-CC-005.5 - 2017-04-20 - Start Change
                //"SELECT KAU.ACCT_ID, KAU.CM_ENROLLED_VIA AS TABLE_FLAG FROM CM_KUBRA_ALL_USER KAU", getClass().getName());
                "SELECT KAU.ACCT_ID, KAU.CM_ENROLLED_VIA AS TABLE_FLAG, KAU.CM_TOKEN1 FROM CM_KUBRA_ALL_USER KAU " 
                + tableSelectionAdditionalFilterStr, getClass().getName());
        		// CCB-CC-005.5 - 2017-04-20 - End Change
                //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        getAccounts.bindLookup("billFormat", BillFormatLookup.constants.EBILL);
        /*
         * CCB-CC-005.5 - 2017-04-20 - Start Add
         */
        if(SSO.trim().compareTo(enrolledViaStr.trim()) ==  0) {
            getAccounts.bindEntity("charType", eBillKubra);
        } else if (CHECKFREE.trim().compareTo(enrolledViaStr.trim()) ==  0) {
            getAccounts.bindEntity("charType", eBillCheckfree);
        }
        getAccounts.bindStringProperty("enrolledVia", CmKubraAllUser.properties.enrolledVia, enrolledViaStr);
        /*
         * CCB-CC-005.5 - 2017-04-20 - Start Add
         */
        // Build Worklist
        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
            
        QueryIterator<SQLResultRow> iter = getAccounts.iterate();
        while (iter.hasNext()) {
            SQLResultRow row = iter.next();
            
            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId((Account_Id) row.getId("ACCT_ID", Account.class));
            workUnit.addSupplementalData("tableFlag", row.getString("TABLE_FLAG"));
            /*
             * CCB-CC-005.5 - 2017-04-20 - Start Add
             */
            workUnit.addSupplementalData("token1", row.getString("CM_TOKEN1"));
            /*
             * CCB-CC-005.5 - 2017-04-20 - End Add
             */
            workUnits.add(workUnit);              
        }
        iter.close();  
     
        return createJobWorkForThreadWorkUnitList(workUnits);  
    }

    public Class<CmAllUserEBillProcessingBatchWorker> getThreadWorkerClass() {
        return CmAllUserEBillProcessingBatchWorker.class;
    }
     
    public void validateSoftParameters(boolean arg0) {
        
        CustomerContactClass customerContactClass = getParameters().getCUSTOMER_CONTACT_CLASS();
        
        
        // Customer Contact Type
        String customerContactType = getParameters().getCUSTOMER_CONTACT_TYPE();
        if (validateCustomerContactType(customerContactClass, customerContactType).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0019_1_batchParmCcTypeInvalid(
                    customerContactType, 
                    customerContactClass.getId().getTrimmedValue()));
        }
        
        // CC Characteristic Type
        CharacteristicType charType = getParameters().getCC_CHAR_TYPE();
        if (validateCharacteristicEntity(charType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0019_1_charTypeInvalidForEntity(
                    charType.getId().getTrimmedValue(), 
                    CharacteristicEntityLookup.constants.CUSTOMER_CONTACT.getLookupValue().fetchLanguageDescription()));
        }
        
        // CC Characteristic Value
        String charValue = getParameters().getCC_CHAR_VALUE().trim();
        if (charType.getCharacteristicType().isPredefinedValue() && validateCharTypeAndCharValue(charType, charValue).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0019_1_charValueInvalidForCharType(charValue, charType.getId().getTrimmedValue()));
        }
        
        /*
         * CCB-CC-005.5 - 2017-04-20 - Start Add 
         */
        CharacteristicType eBillKubraCharType = getParameters().getEBILL_REG_KUBRA_CHAR_TYPE();
        if(validateCharacteristicEntity(eBillKubraCharType, CharacteristicEntityLookup.constants.ACCOUNT).isFalse()) {
            addError(CustomMessageRepository.CCB_CC_005_5_BatchParameterInvalidForAccountEntity(
            		eBillKubraCharType.getId().getTrimmedValue(), 
            		getBatchParameterName(90)));
        }
        
        CharacteristicType eBillKCheckfreeCharType = getParameters().getEBILL_REG_CHECKFREE_CHAR_TYPE();
        if(validateCharacteristicEntity(eBillKCheckfreeCharType, CharacteristicEntityLookup.constants.ACCOUNT).isFalse()) {
            addError(CustomMessageRepository.CCB_CC_005_5_BatchParameterInvalidForAccountEntity(
            		eBillKCheckfreeCharType.getId().getTrimmedValue(), 
            		getBatchParameterName(100)));
        }
        
        CharacteristicType RecurringPayCharType = getParameters().getRECRPAY_CHAR_TYPE();
        if(validateCharacteristicEntity(RecurringPayCharType, CharacteristicEntityLookup.constants.ACCOUNT).isFalse()) {
            addError(CustomMessageRepository.CCB_CC_005_5_BatchParameterInvalidForAccountEntity(
            		RecurringPayCharType.getId().getTrimmedValue(), 
            		getBatchParameterName(110)));
        }
        
        CharacteristicType token1CharType = getParameters().getTOKEN1_CHAR_TYPE();
        if(validateCharacteristicEntity(token1CharType, CharacteristicEntityLookup.constants.ACCOUNT).isFalse()) {
            addError(CustomMessageRepository.CCB_CC_005_5_BatchParameterInvalidForAccountEntity(
            		token1CharType.getId().getTrimmedValue(), 
            		getBatchParameterName(120)));
        }
        
        /*
         * CCB-CC-005.5 - 2017-04-20 - End Add 
         */
    }

    /*
     * CCB-CC-005.5 - 2017-04-20 - Start Add 
     */
    private String getBatchParameterName(int numSeq){

        String parmName = "";
        
        BatchControlParameter_Id batchControlParameter_Id = 
                new BatchControlParameter_Id(this.getBatchControlId(), BigInteger.valueOf(numSeq));        
        BatchControlParameter_LanguageId batchControlParameterLanguageId = 
                new BatchControlParameter_LanguageId(batchControlParameter_Id, getActiveContextLanguage().getId());
        parmName = batchControlParameterLanguageId.getParent().fetchLanguageDescription();
        
        return parmName;
    }
    /*
     * CCB-CC-005.5 - 2017-04-20 - End Add 
     */
  
 // IM-34846. Change Parameter usage. Start
    private BigInteger getEnrollmentCountToProcess(){
        SQLResultRow resultRow = null;
        BigInteger count  = BigInteger.ZERO;

        StringBuilder enrollCountQry = new StringBuilder();
        enrollCountQry.append("SELECT COUNT(1) COUNT  ");
        enrollCountQry.append("FROM CM_KUBRA_ALL_USER B ");
        /*
         * CCB-CC-005.5 - 2017-04-20 - Start Change 
         */
        //enrollCountQry.append("WHERE EXISTS ");
        enrollCountQry.append("WHERE ");
        enrollCountQry.append("  B.CM_ENROLLED_VIA = :enrolledVia ");
        enrollCountQry.append("AND EXISTS ");
        /* 
         * CCB-CC-005.5 - 2017-04-20 - End Change 
         */
        enrollCountQry.append(" ( SELECT 'x' FROM CI_ACCT_PER A1 WHERE A1.ACCT_ID = B.ACCT_ID ) ");
        enrollCountQry.append("AND NOT EXISTS ");
        enrollCountQry.append(" ( SELECT 'x' ");
        enrollCountQry.append("FROM CI_ACCT_PER A ");
        enrollCountQry.append(" WHERE A.ACCT_ID = B.ACCT_ID ");
        enrollCountQry.append("AND A.RECEIVE_COPY_SW = 'Y' ");
        enrollCountQry.append("AND A.BILL_FORMAT_FLG = :billFormat ) ");
        //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement enrollCountPrepStmt = createPreparedStatement(enrollCountQry.toString()); 
        PreparedStatement enrollCountPrepStmt = createPreparedStatement(enrollCountQry.toString(), getClass().getName()); 
        //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        /*
         * CCB-CC-005.5  - 2017-04-20 - Start Add 
         */
        enrollCountPrepStmt.bindStringProperty("enrolledVia", CmKubraAllUser.properties.enrolledVia, enrolledViaStr);
        /* 
         * CCB-CC-005.5  - 2017-04-20 - End Add 
         */
        enrollCountPrepStmt.bindLookup("billFormat", BillFormatLookup.constants.EBILL);
        resultRow = enrollCountPrepStmt.firstRow();
        if(notNull(resultRow))
            count = resultRow.getInteger("COUNT");
        
        enrollCountPrepStmt.close();
        return count;
    }
    
    private BigInteger getDeEnrollmentCountToProcess(){
        SQLResultRow resultRow = null;
        BigInteger count  = BigInteger.ZERO;

        StringBuilder deEnrollCountQry = new StringBuilder();
        deEnrollCountQry.append("SELECT COUNT(1) COUNT  ");
        deEnrollCountQry.append("FROM CI_ACCT_PER A ");
        deEnrollCountQry.append("WHERE A.RECEIVE_COPY_SW = 'Y' ");
        deEnrollCountQry.append("AND A.BILL_FORMAT_FLG = :billFormat ");
        deEnrollCountQry.append("AND NOT EXISTS ");
        /*
         * CCB-CC-005.5 - 2017-04-20 - Start Change
         */
        //deEnrollCountQry.append(" ( SELECT 'x' FROM CM_KUBRA_ALL_USER B WHERE A.ACCT_ID = B.ACCT_ID ) ");
        deEnrollCountQry.append(" ( SELECT 'X' FROM CM_KUBRA_ALL_USER B WHERE A.ACCT_ID = B.ACCT_ID ");
        deEnrollCountQry.append("   AND B.CM_ENROLLED_VIA = :enrolledVia ) ");
        // Defect 3828741 - 2017-08-22 - Start Add
        deEnrollCountQry.append("AND EXISTS ");
        deEnrollCountQry.append( "( SELECT ");
        deEnrollCountQry.append(     "'X' ");
        deEnrollCountQry.append(   "FROM ");
        deEnrollCountQry.append(     "CI_ACCT_CHAR C ");
        deEnrollCountQry.append(   "WHERE ");
        deEnrollCountQry.append(     "A.ACCT_ID = C.ACCT_ID ");
        deEnrollCountQry.append(     "AND C.CHAR_TYPE_CD = :charType ");
        deEnrollCountQry.append(     "AND ( C.CHAR_VAL = 'Y' OR C.CHAR_VAL = 'D' ) ) ");
        // Defect 3828741 - 2017-08-22 - End Add
        /*
         * CCB-CC-005.5  - 2017-04-20 - End Change
         */
        //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement deEnrollCountPrepStmt = createPreparedStatement(deEnrollCountQry.toString()); 
        PreparedStatement deEnrollCountPrepStmt = createPreparedStatement(deEnrollCountQry.toString(), getClass().getName()); 
        //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        deEnrollCountPrepStmt.bindLookup("billFormat", BillFormatLookup.constants.EBILL);
        /*
         * CCB-CC-005.5  - 2017-04-20 - Start Add
         */
        deEnrollCountPrepStmt.bindStringProperty("enrolledVia", CmKubraAllUser.properties.enrolledVia, enrolledViaStr);
        /*
         * CCB-CC-005.5  - 2017-04-20 - End Add
         */
        // Defect 3828741 - 2017-08-22 - Start Add
        deEnrollCountPrepStmt.bindEntity("charType", getParameters().getEBILL_REG_CHECKFREE_CHAR_TYPE());
        // Defect 3828741 - 2017-08-22 - End Add
        
        resultRow = deEnrollCountPrepStmt.firstRow();
        if(notNull(resultRow))
            count = resultRow.getInteger("COUNT");
        
        deEnrollCountPrepStmt.close();
        return count;
    }
    
    
 // IM-34846. Change Parameter usage. End
    
    /**
     * This method validates Customer Contact Type.
     * @param customerContactClass - Customer Contact Class
     * @param customerContactType - String
     * @return Bool
     */
    private Bool validateCustomerContactType(CustomerContactClass customerContactClass, String customerContactType) {
        
        CustomerContactType_Id customerContactTypeId = new CustomerContactType_Id(customerContactClass, customerContactType);
        if (isNull(customerContactTypeId.getEntity())) { 
            return Bool.FALSE;
        }
        
        return Bool.TRUE;
    }
    
    /**
     * This method validates if a characteristic type is valid for a specific characteristic entity.
     * @param charType - Characteristic Type
     * @param charEntityLookup - Characteristic Entity Lookup
     * @return Bool
     */
    private Bool validateCharacteristicEntity(CharacteristicType charType, CharacteristicEntityLookup charEntityLookup) {
        
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType.getId(), charEntityLookup);        
        if (isNull(charEntityId.getEntity())) {
            return Bool.FALSE;
        }
        
        return Bool.TRUE;
    }
    
    /**
     * This method validates if characteristic value is valid for a given characteristic type. 
     * @param charType - Characteristic Type
     * @param charValue - String
     * @return Bool
     */
    private Bool validateCharTypeAndCharValue(CharacteristicType charType, String charValue) {

        CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charType, charValue);
        if (isNull(charValueId.getEntity())) {
            return Bool.FALSE;
        }
        
        return Bool.TRUE;
    }

    public static class CmAllUserEBillProcessingBatchWorker 
            extends CmAllUserEBillProcessingBatchWorker_Gen {
        
        // Constant Variables
        private final String PROCESS_DATE = getProcessDateTime().getDate().toString(new DateFormat("MM/dd/yyyy"));
        private final String TABLE_FLAG_AC = "CI_ACCT";
        private final String SPACE = " ";
        /*
         * CCB-CC-005.5 - 2017-04-20 - Start Add
         */
        private final String SSO = "SSO";
        private final String CHECKFREE = "CHECKFREE";
        private final String NO_CHAR_VAL = "N";
        private final String YES_CHAR_VAL = "Y";
        /*
         * CCB-CC-005.5 - 2017-04-20 - End Add
         */
        
        // Working Variables
        private CustomerContactType_Id ccTypeId;
        private CharacteristicType ccCharType;
        private String ccCharValue;
        private String comment1 = "De-enrollment per %s All User file from KUBRA";
        private String comment2 = "E-bill enrollment per %s All User file from KUBRA";
        private String comment3 = "E-bill enrollment (%s All User file from KUBRA) - multiple Persons receiving bill. Name on All User file: %s";
        /*
         * CCB-CC-005.5 - 2017-04-20 - Start Add
         */
        private String enrolledViaStr;
        private String token1;
        private CharacteristicType eBillKubraCharType;
        private CharacteristicType eBillCheckfreeCharType;
        private CharacteristicType recrPayCharType;
        private CharacteristicType token1CharType;
        /*
         * CCB-CC-005.5 - 2017-04-20 - End Add
         */
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }
        
        public void initializeThreadWork(boolean arg0) 
                throws ThreadAbortedException, RunAbortedException {
            
            // Set Customer Contact Type
            ccTypeId = new CustomerContactType_Id(getParameters().getCUSTOMER_CONTACT_CLASS(), getParameters().getCUSTOMER_CONTACT_TYPE());
            
            ccCharType = getParameters().getCC_CHAR_TYPE();
            ccCharValue = getParameters().getCC_CHAR_VALUE().trim();
            
            // Insert Process Date in Comments                        
            comment1 = String.format(comment1, PROCESS_DATE);
            comment2 = String.format(comment2, PROCESS_DATE);
            
            /*
             * CCB-CC-005.5 - 2017-04-20 - Start Add
             */
            enrolledViaStr = getParameters().getENROLLED_VIA();
            eBillKubraCharType = getParameters().getEBILL_REG_KUBRA_CHAR_TYPE();
            eBillCheckfreeCharType = getParameters().getEBILL_REG_CHECKFREE_CHAR_TYPE();
            recrPayCharType = getParameters().getRECRPAY_CHAR_TYPE();
            token1CharType = getParameters().getTOKEN1_CHAR_TYPE();
            /*
             * CCB-CC-005.5 - 2017-04-20 - End Add
             */
        }
        
        protected boolean executeWorkUnit(ThreadWorkUnit arg0) 
                throws ThreadAbortedException, RunAbortedException {
            
            // Maximum Update limit was exceeded
            
            //IM-34846. Change Parameter usage. Start
            
            /*  if (isNull(arg0.getPrimaryId())) {               
                addError(CustomMessageRepositoryMDC.NI0019_1_numOfChangesExceeds(getParameters().getMAX_UPDATES()));
            }*/
            
          //IM-34846. Change Parameter usage. End
            
            // Retrieve Account
            Account_Id accountId = (Account_Id) arg0.getPrimaryId();
            String tableFlag = (String) arg0.getSupplementallData("tableFlag");
            /*
             * CCB-CC-005.5 - 2017-04-20 - Start Add
             */
            token1 = (String) arg0.getSupplementallData("token1");
            /*
             * CCB-CC-005.5 - 2017-04-20 - End Add
             */
            // Determine whether Account is from the CI_ACCT table or CM_KUBRA_ALL_USER table
            if (tableFlag.equalsIgnoreCase(TABLE_FLAG_AC)) {
                processAccountsFromCCB(accountId.getEntity());
            }
            else {
                
                // Check if Account Id is valid
                Account account = accountId.getEntity();
                if (isNull(account)) {
                    /*
                     * Start Change - JPunza - Defect 1201
                     */
                    //addError(CustomMessageRepositoryMDC.NI0019_1_accountNotFoundInCcb(accountId.getTrimmedValue()));
                    return true;
                    /*
                     * End Change - JPunza - Defect 1201
                     */
                }
           
                processAccountsFromAllUserFileTable(account, tableFlag);
            }
            
            return true;
        }

        /**
         * This method process Accounts from CC&B.
         * @param account - Account
         */
        private void processAccountsFromCCB(Account account) {
                                            
            // Retrieve all persons on the account with e-bill bill format
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
            //ListFilter<AccountPerson> getAccountPersons = account.getPersons().createFilter("WHERE this.billFormat = :billFormat");
            ListFilter<AccountPerson> getAccountPersons = account.getPersons().createFilter(
                    "WHERE this.billFormat = :billFormat", getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
            getAccountPersons.bindLookup("billFormat", BillFormatLookup.constants.EBILL);
            
            
            /*
             * CCB-CC-005.5 - 2017-04-20 - Start Add
             */
            AccountCharacteristic ebillKubraChar = account.getEffectiveCharacteristic(eBillKubraCharType);
            AccountCharacteristic ebillCheckfreeChar = account.getEffectiveCharacteristic(eBillCheckfreeCharType);
            AccountCharacteristic recrPayChar = account.getEffectiveCharacteristic(recrPayCharType);
            AccountCharacteristic token1Char = account.getEffectiveCharacteristic(token1CharType);
            /*
             * CCB-CC-005.5 - 2017-04-20 - End Add
             */
            
            QueryIterator<AccountPerson> iter = getAccountPersons.iterate();                
            while (iter.hasNext()) {
                AccountPerson ap = iter.next();
                
                /*
                 * CCB-CC-005.5 - 2017-04-20 - Start Change
                 */
                // Update Bill Format to Detailed 
                //AccountPerson_DTO dto = ap.getDTO();
                //dto.setBillFormat(BillFormatLookup.constants.DETAILED);
                //ap.setDTO(dto);
                AccountPerson_DTO apDto = ap.getDTO();
                
                if (SSO.trim().compareTo(enrolledViaStr.trim()) == 0) {
                    if (isNull(ebillCheckfreeChar) || NO_CHAR_VAL.compareTo(ebillCheckfreeChar.getCharacteristicValue().trim()) == 0) {
                        apDto.setBillFormat(BillFormatLookup.constants.DETAILED);
                    }
                } else if (CHECKFREE.trim().compareTo(enrolledViaStr.trim()) == 0) {
                    if (isNull(ebillKubraChar) || NO_CHAR_VAL.compareTo(ebillKubraChar.getCharacteristicValue().trim()) == 0) {
                        apDto.setBillFormat(BillFormatLookup.constants.DETAILED);
                    }
                }
                ap.setDTO(apDto);
                /*
                 * CCB-CC-005.5 - 2017-04-20 - End Change
                 */
                // Create Customer Contact
                createCustomerContact(ap.fetchIdPerson(), comment1);
            }
            iter.close();
            
            /*
             * CCB-CC-005.5 - 2017-04-20 - Start Add
             */

            AccountCharacteristic_DTO acDto;
            
            if (SSO.trim().compareTo(enrolledViaStr.trim()) == 0) {

                if (notNull(ebillKubraChar)) {
                    acDto = ebillKubraChar.getDTO();
                    acDto.setCharacteristicValue(NO_CHAR_VAL);
                    ebillKubraChar.setDTO(acDto);
                } else {
                    AccountCharacteristic_Id acctCharId = new AccountCharacteristic_Id(eBillCheckfreeCharType, account, getProcessDateTime().getDate());
                    acDto = new AccountCharacteristic_DTO();
                    acDto.setId(acctCharId);
                    acDto.setCharacteristicValue(NO_CHAR_VAL);
                    acDto.newEntity();
                }
                
                if(notNull(recrPayChar) && NO_CHAR_VAL.compareTo(recrPayChar.getCharacteristicValue().trim()) == 0) {
                    if(notNull(token1Char)) {
                        account.getCharacteristics().remove(token1Char);
                    }
                }
                
            } else if (CHECKFREE.trim().compareTo(enrolledViaStr.trim()) == 0) {
                
                if (notNull(ebillCheckfreeChar)) {
                    acDto = ebillCheckfreeChar.getDTO();
                    acDto.setCharacteristicValue(NO_CHAR_VAL);
                    ebillCheckfreeChar.setDTO(acDto);
                } else {
                    AccountCharacteristic_Id acctCharId = new AccountCharacteristic_Id(eBillCheckfreeCharType, account, getProcessDateTime().getDate());
                    acDto = new AccountCharacteristic_DTO();
                    acDto.setId(acctCharId);
                    acDto.setCharacteristicValue(NO_CHAR_VAL);
                    acDto.newEntity();
                }
            }
            /*
             * CCB-CC-005.5 - 2017-04-20 - End Add
             */
        }
        
        /**
         * This method process Accounts from All User File table. 
         * @param account - Account
         * @param eBiller - String
         */
        private void processAccountsFromAllUserFileTable(Account account, String eBiller) {
            
        	/*
        	 * CCB-CC-005.5 - 2017-04-26 - Start Add
        	 */
        	// Check if the Account is in both table selection and ccb selection
        	AccountCharacteristic token1Char = account.getEffectiveCharacteristic(token1CharType);
        	// Defect 3828741 - 2017-08-22 - Start Delete
        	//StringBuilder queryStr = new StringBuilder();
        	//queryStr.append("SELECT AC.ACCT_ID ");
        	//queryStr.append("FROM CI_ACCT AC ");
        	//queryStr.append("WHERE AC.ACCT_ID = :accountId "); 
        	//queryStr.append("AND EXISTS (SELECT 'X' FROM CI_ACCT_PER AP ");
        	//queryStr.append(               "WHERE AP.ACCT_ID = AC.ACCT_ID ");
        	//queryStr.append(               "AND AP.BILL_FORMAT_FLG = :billFormat ) ");
        	//queryStr.append("AND EXISTS (SELECT 'X' ");
        	//queryStr.append(               "FROM CI_ACCT_CHAR ACH ");
        	//queryStr.append(               "WHERE ACH.ACCT_ID = AC.ACCT_ID ");
        	//if (SSO.compareTo(enrolledViaStr.trim()) == 0) {
            //    queryStr.append(           "AND ACH.CHAR_TYPE_CD = 'EBLKUBRA' ");
            //    queryStr.append(           "AND ACH.SRCH_CHAR_VAL = 'Y' )");
        	//} else if (CHECKFREE.compareTo(enrolledViaStr.trim()) == 0) {
            //    queryStr.append(           "AND ACH.CHAR_TYPE_CD = 'EBLCHKFR' ");
            //    queryStr.append(           "AND (ACH.SRCH_CHAR_VAL = 'Y' OR ACH.SRCH_CHAR_VAL = 'D' ) ) ");
        	//}
        	//
        	//PreparedStatement ccbSelectionQuery = createPreparedStatement(queryStr.toString(), getClass().getName());
        	//ccbSelectionQuery.bindId("accountId", account.getId());
        	//ccbSelectionQuery.bindLookup("billFormat", BillFormatLookup.constants.EBILL);
        	//
        	//SQLResultRow row = ccbSelectionQuery.firstRow();
        	//ccbSelectionQuery.close();
        	//
        	//if(notNull(row)) {
        	//	String accountIdStrFromCCBSelection = (String) row.getString("ACCT_ID");
	    	//	if(accountIdStrFromCCBSelection.compareTo(account.getId().getTrimmedValue()) == 0) {
	    	//		AccountCharacteristic_DTO acDto;
	    	//		if(notNull(token1Char)) {
	    	//			if(token1Char.getAdhocCharacteristicValue().compareTo(token1) != 0) {
	    	//				acDto = token1Char.getDTO();
	    	//				acDto.setAdhocCharacteristicValue(token1);
	    	//				token1Char.setDTO(acDto);
	    	//			}
	    	//		} else {
	        //           acDto = new AccountCharacteristic_DTO();
	        //          AccountCharacteristic_Id acctCharId = new AccountCharacteristic_Id(token1CharType, account, getProcessDateTime().getDate());
	        //         acDto.setId(acctCharId);
	        //            acDto.setAdhocCharacteristicValue(token1);
	        //            acDto.newEntity();
	    	//		}
	    	//	}
        	//}
        	// Defect 3828741 - 2017-08-22 - End Delete
        	/*
        	 * CCB-CC-005.5 - 2017-04-26 - End Add
        	 */
        	// Defect 3855582 - 2017-09-15 - Start Delete
            // Retrieve all persons on the account with e-bill bill format
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
            //ListFilter<AccountPerson> getAccPersonsInEBill = account.getPersons().createFilter("WHERE this.billFormat = :billFormat");
            //ListFilter<AccountPerson> getAccPersonsInEBill = account.getPersons().createFilter(
            //        "WHERE this.billFormat = :billFormat", getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
            //getAccPersonsInEBill.bindLookup("billFormat", BillFormatLookup.constants.EBILL);
            //getAccPersonsInEBill.listSize();
            //if (getAccPersonsInEBill.listSize() > 0) {
            //    return;
            //}
        	// Defect 3855582 - 2017-09-15 - End Delete
        	/*
             * Defect 3870793 - 2017-09-26 - Start Add
             */
            AccountCharacteristic_DTO acDto;
            if (SSO.trim().compareTo(enrolledViaStr.trim()) == 0) {
                
                AccountCharacteristic ebillKubraChar = account.getEffectiveCharacteristic(eBillKubraCharType);

                if(notNull(token1Char)) {
                    acDto = token1Char.getDTO();
                    acDto.setAdhocCharacteristicValue(token1);
                    token1Char.setDTO(acDto);
                } else {
                    acDto = new AccountCharacteristic_DTO();
                    AccountCharacteristic_Id acctCharId = new AccountCharacteristic_Id(token1CharType, account, getProcessDateTime().getDate());
                    acDto.setId(acctCharId);
                    acDto.setAdhocCharacteristicValue(token1);
                    acDto.newEntity();
                }
                
                if(notNull(ebillKubraChar)) {
                    acDto = ebillKubraChar.getDTO();
                    acDto.setCharacteristicValue(YES_CHAR_VAL);
                    ebillKubraChar.setDTO(acDto);
                } else {
                    acDto = new AccountCharacteristic_DTO();
                    AccountCharacteristic_Id acctCharId = new AccountCharacteristic_Id(eBillKubraCharType, account, getProcessDateTime().getDate());
                    acDto.setId(acctCharId);
                    acDto.setCharacteristicValue(YES_CHAR_VAL);
                    acDto.newEntity();
                }
            } else if (CHECKFREE.trim().compareTo(enrolledViaStr.trim()) == 0) {
                
                AccountCharacteristic ebillCheckfreeChar = account.getEffectiveCharacteristic(eBillCheckfreeCharType);
                
                if(notNull(ebillCheckfreeChar)) {
                    acDto = ebillCheckfreeChar.getDTO();
                    acDto.setCharacteristicValue(YES_CHAR_VAL);
                    ebillCheckfreeChar.setDTO(acDto);
                } else {
                    acDto = new AccountCharacteristic_DTO();
                    AccountCharacteristic_Id acctCharId = new AccountCharacteristic_Id(eBillCheckfreeCharType, account, getProcessDateTime().getDate());
                    acDto.setId(acctCharId);
                    acDto.setCharacteristicValue(YES_CHAR_VAL);
                    acDto.newEntity();
                }
            }
        	
        	// Retrieve all persons on the account with e-bill bill format
            ListFilter<AccountPerson> getAccPersonsInEBill = account.getPersons().createFilter(
                    "WHERE this.billFormat = :billFormat", getClass().getName());
            getAccPersonsInEBill.bindLookup("billFormat", BillFormatLookup.constants.EBILL);
            getAccPersonsInEBill.listSize();
            if (getAccPersonsInEBill.listSize() > 0) {
                return;
            }
            /*
             * Defect 3870793 - 2017-09-26 - End Add
             */
            
            // Retrieve all persons on the account without e-bill bill format
            /*
             * Start Change - JPunza - Defect 1201
             */
            //ListFilter<AccountPerson> getAccPersonsNotInEBill = account.getPersons().createFilter("WHERE this.billFormat <> :billFormat");
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
            //ListFilter<AccountPerson> getAccPersonsNotInEBill = account.getPersons().createFilter("WHERE this.shouldReceiveCopyOfBill = :yes " +
                    //"AND this.billFormat <> :billFormat");
            ListFilter<AccountPerson> getAccPersonsNotInEBill = account.getPersons().createFilter("WHERE this.shouldReceiveCopyOfBill = :yes " +
                    "AND this.billFormat <> :billFormat", getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
            getAccPersonsNotInEBill.bindBoolean("yes", Bool.TRUE);
            /*
             * End Change - JPunza - Defect 1201
             */
            getAccPersonsNotInEBill.bindLookup("billFormat", BillFormatLookup.constants.EBILL);

            if (getAccPersonsNotInEBill.listSize() == 1) {                                       
                
                AccountPerson ap = getAccPersonsNotInEBill.firstRow();
                
                // Update Bill Format to E-bill
                AccountPerson_DTO dto = ap.getDTO();
                dto.setBillFormat(BillFormatLookup.constants.EBILL);
                ap.setDTO(dto);
                
                // Create Customer Contact
                createCustomerContact(ap.fetchIdPerson(), comment2);
            }
            else {
                
                String accountStr = account.getId().getTrimmedValue();
                
                CmKubraAllUser_Id allUserId = new CmKubraAllUser_Id(accountStr, eBiller); 
                CmKubraAllUser allUser = allUserId.getEntity();
                
                // Create To Do
                String fullName = allUser.getFirstName() + SPACE + allUser.getLastName();
                createToDo(accountStr, String.format(comment3, PROCESS_DATE, fullName));
            } 
            /*
             * Defect 3870793 - 2017-09-26 - Start Delete
             */
            ///*
            // * CCB-CC-005.5 - 2017-04-20 - Start Add
            // */
            //AccountCharacteristic_DTO acDto;
            //if (SSO.trim().compareTo(enrolledViaStr.trim()) == 0) {
            //    
            //    AccountCharacteristic ebillKubraChar = account.getEffectiveCharacteristic(eBillKubraCharType);
            //
            //    if(notNull(token1Char)) {
            //        acDto = token1Char.getDTO();
            //        acDto.setAdhocCharacteristicValue(token1);
            //        token1Char.setDTO(acDto);
            //    } else {
            //        acDto = new AccountCharacteristic_DTO();
            //        AccountCharacteristic_Id acctCharId = new AccountCharacteristic_Id(token1CharType, account, getProcessDateTime().getDate());
            //        acDto.setId(acctCharId);
            //        acDto.setAdhocCharacteristicValue(token1);
            //        acDto.newEntity();
            //    }
            //    
            //    if(notNull(ebillKubraChar)) {
            //        acDto = ebillKubraChar.getDTO();
            //        acDto.setCharacteristicValue(YES_CHAR_VAL);
            //        ebillKubraChar.setDTO(acDto);
            //    } else {
            //        acDto = new AccountCharacteristic_DTO();
            //        AccountCharacteristic_Id acctCharId = new AccountCharacteristic_Id(eBillKubraCharType, account, getProcessDateTime().getDate());
            //        acDto.setId(acctCharId);
            //        acDto.setCharacteristicValue(YES_CHAR_VAL);
            //        acDto.newEntity();
            //    }
            //} else if (CHECKFREE.trim().compareTo(enrolledViaStr.trim()) == 0) {
            //    
            //    AccountCharacteristic ebillCheckfreeChar = account.getEffectiveCharacteristic(eBillCheckfreeCharType);
            //    
            //    if(notNull(ebillCheckfreeChar)) {
            //        acDto = ebillCheckfreeChar.getDTO();
            //        acDto.setCharacteristicValue(YES_CHAR_VAL);
            //        ebillCheckfreeChar.setDTO(acDto);
            //    } else {
            //        acDto = new AccountCharacteristic_DTO();
            //        AccountCharacteristic_Id acctCharId = new AccountCharacteristic_Id(eBillCheckfreeCharType, account, getProcessDateTime().getDate());
            //        acDto.setId(acctCharId);
            //        acDto.setCharacteristicValue(YES_CHAR_VAL);
            //        acDto.newEntity();
            //    }
            //}
            ///*
            // * CCB-CC-005.5 - 2017-04-20 - End Add
            // */
            /*
             * Defect 3870793 - 2017-09-26 - End Delete
             */
        }
        
        /**
         * This method creates Customer Contact.
         * @param person - Person
         * @param comments - String
         */
        private void createCustomerContact(Person person, String comments) {
            
            CustomerContact_DTO ccDTO = (CustomerContact_DTO) createDTO(CustomerContact.class);
            
            ccDTO.setContactDateTime(getProcessDateTime());
            ccDTO.setCustomerContactTypeId(ccTypeId);
            ccDTO.setLongDescription(comments);
            ccDTO.setPersonId(person.getId());
            ccDTO.setShouldPrintLetter(Bool.FALSE);

            CustomerContact customerContact = ccDTO.newEntity();
                        
            // Set characteristics for Customer Contact    
            for (Iterator<CharacteristicTypeContactType> iter = ccTypeId.getEntity().getCharacteristicTypeContactTypes().iterator(); iter.hasNext();) {
                
                CharacteristicTypeContactType ccTypeCharType = (CharacteristicTypeContactType) iter.next();
                CharacteristicType charType = ccTypeCharType.getId().getCharacteristicType();
 
                CustomerContactCharacteristic_DTO ccCharDto = (CustomerContactCharacteristic_DTO) createDTO(CustomerContactCharacteristic.class);
                CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
                
                if (charType.equals(ccCharType)) {                
                    if (charTypeLookup.isPredefinedValue()) {
                        ccCharDto.setCharacteristicValue(ccCharValue);
                    }
                    else if (charTypeLookup.isForeignKeyValue()) {
                        ccCharDto.setCharacteristicValueForeignKey1(ccCharValue);
                    }
                    else {
                        ccCharDto.setAdhocCharacteristicValue(ccCharValue);
                    }
                    
                    ccCharDto.setId(new CustomerContactCharacteristic_Id(charType, customerContact));
                    ccCharDto.newEntity();
                }
            }                       
        }
               
        /**
         * This method creates To Do Entry.
         * @param accountId - String
         * @param comments - String
         */
        private void createToDo(String accountId, String comments) {
                        
            ToDoType toDoType = getParameters().getTO_DO_TYPE();
            
            ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
            ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();
                        
            toDoEntryDTO.setBatchControlId(getBatchControlId());
            toDoEntryDTO.setBatchNumber(getBatchNumber());            
            toDoEntryDTO.setComments(comments);
            toDoEntryDTO.setCreationDateTime(getProcessDateTime());
            toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
            toDoEntryDTO.setToDoTypeId(toDoType.getId());
                        
            toDoCreator.setToDoDTO(toDoEntryDTO);            
            toDoCreator.addSortKeyValue(new ToDoSortKeyType_Id(toDoType, BigInteger.ONE).getEntity(), accountId);
            toDoCreator.addDrillKeyValue(new ToDoDrillKeyType_Id(toDoType, BigInteger.ONE).getEntity(), accountId);
            
            toDoCreator.create();
        } 
        
        @Override
        public void finalizeThreadWork() throws ThreadAbortedException,
                RunAbortedException {
            logInfo(CustomMessageRepositoryMDC.NI0019_1_numOfEnrollRecords(enrollCount));
            logInfo(CustomMessageRepositoryMDC.NI0019_1_numOfDeEnrollRecords(deEnrollCount));
        }
    }
}
