/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPQMBPN Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-02-10   EQuint      NB0082. Initial Version. 
 * 2016-05-31   MPang       Defect 3441549. Change the Soft Parameter
 *                          (HAS_QUOTE_CHAR_TYPE) from characteristic type
 *                          to String. Added else statement to
 *                          retrieve Parameter 30 if it is blank. Added
 *                          finalizeThreadWork() to close the connection.
 * 2016-06-22   SMiran      Defect 3459051. Count number of records in error 
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.       
 * 2018-11-06   EQuint      Defect 4146452. Catch application error from 
 *                          JACOB call and throw to raise as normal CCB error 
 * 2025-11-14   EQuint      CCB25.4 Upgrade
 * *************************************************************************                
 */

package com.splwg.cm.domain.batch;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.admin.adjustmentCancelReason.entity.AdjustmentCancelReason;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.budgetPlan.entity.BudgetPlan;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpqmbpn;

/**
 * @author Administrator
 *
@BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = serviceTaskType, name = QUOTE_SVC_TASK_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = QUOTE_SVC_TASK_ACTIVE_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = CWR_PA_CIS_DIVISION, type = entity)
 *            , @BatchJobSoftParameter (name = CWR_PA_SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = ARP_PA_CIS_DIVISION, type = entity)
 *            , @BatchJobSoftParameter (name = ARP_PA_SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = budgetPlan, name = LOW_INCOME_BUDGET_PLAN, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = budgetPlan, name = CWR_BUDGET_PLAN, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = BPAP_CRED_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = PLEDGE_SVC_TASK_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = PLEDGE_SVC_TASK_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = SELECTION_WFM_NAME, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = DIVERSION_SA_WFM_NAME, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = PA_SA_WFM_NAME, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CWR_SA_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = QUOTE_ID_SA_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = QUOTE_SVC_TASK_EXPIRED_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = RECALC_SA_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = RECALC_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = adjustmentType, name = XFER_ADJ_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = adjustmentCancelReason, name = ADJ_CAN_RSN_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = BPAP_CRED_VAL_WFM_NAME, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = SVC_TASK_CHAR_WFM_NAME, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PREM_ID_SA_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = adjustmentType, name = ZERO_ADJ_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = MAJOR_PLED_FUND_TYP_WFM_NAME, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = HAS_QUOTE_CHAR_TYPE, required = true, type = string)})
 */
public class CmQuoteMonitoringBatch extends CmQuoteMonitoringBatch_Gen {

	// CONSTANTS
	private static final String SA_ID_OPT_TYPE = "XS01";

	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";

	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";

	public JobWork getJobWork() {

		Query<QueryResultRow> query = createQuery(" FROM ServiceTask st, ServiceTaskCharacteristic stc " +
				" WHERE st.serviceTaskType = :svcTaskType " +
				" AND st.status = :stat " +
				" AND st.id = stc.id.serviceTask " +
				" AND stc.id.characteristicType.id = :charTypeCd " +
				" AND stc.id.sequence = (SELECT MAX(stc2.id.sequence) FROM ServiceTaskCharacteristic stc2 " +
				" WHERE stc2.id.serviceTask = stc.id.serviceTask " +
				" AND stc2.id.characteristicType.id = stc.id.characteristicType.id ) "
				, "getJobWork");

		query.bindEntity("svcTaskType", getParameters().getQUOTE_SVC_TASK_TYPE());
		query.bindStringProperty("stat", ServiceTask.properties.status, getParameters().getQUOTE_SVC_TASK_ACTIVE_STATUS());

		// get sa id char type from feature configuration
		FeatureConfiguration configuration = getParameters().getSVC_TASK_CHAR_WFM_NAME();
		CmFeatureConfigurationRetriever configurationRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
		configurationRetriever.setParmWFMName(configuration);
		configurationRetriever.setParmOptType(SA_ID_OPT_TYPE);

		CharacteristicType_Id charTypeId = new CharacteristicType_Id(configurationRetriever.getMinSequenceOptionValue());
		query.bindId("charTypeCd", charTypeId);

		query.addResult("svcTaskId", "st.id");
		query.addResult("creDttm", "st.creationDateTime");
		query.addResult("charVal", "stc.characteristicValueForeignKey1");

		query.orderBy("svcTaskId");

		return createJobWorkForQueryIterator(query.iterate(), this);
	}

	/*
	 * This method will create the Thread Work Unit per result row
	 */
	public ThreadWorkUnit createWorkUnit(QueryResultRow resultRow) {

		ServiceTask_Id svcTaskId = (ServiceTask_Id) resultRow.getId("svcTaskId", ServiceTask.class);
		DateTime createDateTime = resultRow.getDateTime("creDttm");
		String charValue = resultRow.getString("charVal");

		ThreadWorkUnit unit = new ThreadWorkUnit();
		unit.setPrimaryId(svcTaskId);
		unit.addSupplementalData("creDttm", createDateTime);
		unit.addSupplementalData("charVal", charValue);

		return unit;
	}

	public Class<CmQuoteMonitoringBatchWorker> getThreadWorkerClass() {
		return CmQuoteMonitoringBatchWorker.class;
	}

	public static class CmQuoteMonitoringBatchWorker extends
	CmQuoteMonitoringBatchWorker_Gen {

		// work variable
		private Cmpqmbpn cmpqmbpn;
		//Start Add - MPang - Defect 3441549 - 2016-05-31
		private Connection connection;
		//End Add - MPang - Defect 3441549 - 2016-05-31

		// batch parameters
		private ServiceTaskType quoteServiceTaskType;
		private String quoteServiceTaskActiveStatus;
		private CisDivision cwrPaCisDivision;
		private String cwrPaSaType;
		private CisDivision arpPaCisDivision;
		private String arpPaSaType;
		private BudgetPlan lowIncomeBudgetPlan;
		private BudgetPlan cwrBudgetPlan;
		private CharacteristicType bpapCredCharType;
		private ServiceTaskType pledgeServiceTaskType;
		private String pledgeServiceTaskStatus;
		private FeatureConfiguration selectionFeatureConfiguration;
		private FeatureConfiguration diversionFeatureConfiguration;
		private FeatureConfiguration paSAFeatureConfiguration;
		private CharacteristicType cwrSaCharType;
		private CharacteristicType quoteIdSaCharType;
		private String quoteServiceTaskExpiredStatus;
		private CharacteristicType reCalcSaCharType;
		private String recalcCharVal;
		private AdjustmentType xferAdjType;
		private AdjustmentCancelReason adjustmentCancelReason;
		private FeatureConfiguration bpapCredFeatureConfiguration;
		private FeatureConfiguration serviceTaskCharFeatureConfiguration;
		private CharacteristicType premiseIdSaCharType;
		private AdjustmentType zeroAdjType;
		private FeatureConfiguration majorPledFundTypeFeatureConfiguration;
		//Start Change - MPang - Defect 3441549 - 2016-05-31
		//private CharacteristicType hasQuoteCharType;
		private String hasQuoteCharType;
		//End Change - MPang - Defect 3441549 - 2016-05-31
		// unit variables
		private ServiceTask_Id serviceTaskId;
		private DateTime createDateTime;
		private String charVal;
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			serviceTaskId = (ServiceTask_Id) unit.getPrimaryId();
			createDateTime = (DateTime) unit.getSupplementallData("creDttm");
			charVal = (String) unit.getSupplementallData("charVal");

			// reset program status and message numbers every unit
			cmpqmbpn.setProgramStatus(" ");
			cmpqmbpn.setMessageNbr(BigDecimal.ZERO);
			cmpqmbpn.setZmsgnMessageCatNbr(BigDecimal.ZERO);

			// set unit parameters
			cmpqmbpn.setQmbpnF1SvcTaskId(serviceTaskId.getTrimmedValue());
			cmpqmbpn.setCreDttm(createDateTime.toString());
			cmpqmbpn.setQmbpnCharValFk1(charVal.trim());

			// set batch parameters
			cmpqmbpn.setQuoteSvcTaskType(quoteServiceTaskType.getId().getTrimmedValue());
			cmpqmbpn.setQuoteSvcTaskActiveStatus(quoteServiceTaskActiveStatus.trim());

			if (notNull(cwrPaCisDivision)) {
				cmpqmbpn.setCwrPaCisDivision(cwrPaCisDivision.getId().getTrimmedValue());
			//Start Add - MPang - Defect 3441549 - 2016-05-31
			} else {
			    cmpqmbpn.setCwrPaCisDivision(CobolCode.SPACES.toString());
			}
			//End Add - MPang - Defect 3441549 - 2016-05-31
			cmpqmbpn.setCwrPaSaType(cwrPaSaType.trim());

			if (notNull(arpPaCisDivision)) {
				cmpqmbpn.setArpPaCisDivision(arpPaCisDivision.getId().getTrimmedValue());
			}

			cmpqmbpn.setArpPaSaType(arpPaSaType.trim());
			cmpqmbpn.setLowIncomeBudgetPlan(lowIncomeBudgetPlan.getId().getTrimmedValue());
			cmpqmbpn.setCwrBudgetPlan(cwrBudgetPlan.getId().getTrimmedValue());
			cmpqmbpn.setBpapCredCharType(bpapCredCharType.getId().getTrimmedValue());
			cmpqmbpn.setPledgeSvcTaskType(pledgeServiceTaskType.getId().getTrimmedValue());
			cmpqmbpn.setPledgeSvcTaskStatus(pledgeServiceTaskStatus.trim());
			cmpqmbpn.setSelectionWfmName(selectionFeatureConfiguration.getId().getTrimmedValue());
			cmpqmbpn.setDiversionSaWfmName(diversionFeatureConfiguration.getId().getTrimmedValue());
			cmpqmbpn.setPaSaWfmName(paSAFeatureConfiguration.getId().getTrimmedValue());
			cmpqmbpn.setCwrSaCharType(cwrSaCharType.getId().getTrimmedValue());
			cmpqmbpn.setQuoteIdSaCharType(quoteIdSaCharType.getId().getTrimmedValue());
			cmpqmbpn.setQuoteSvcTaskExpiredStatus(quoteServiceTaskExpiredStatus.trim());
			cmpqmbpn.setRecalcSaCharType(reCalcSaCharType.getId().getTrimmedValue());
			cmpqmbpn.setRecalcCharVal(recalcCharVal.trim());
			cmpqmbpn.setXferAdjType(xferAdjType.getId().getTrimmedValue());
			cmpqmbpn.setAdjCanRsnCd(adjustmentCancelReason.getId().getTrimmedValue());
			cmpqmbpn.setBpapCredValWfmName(bpapCredFeatureConfiguration.getId().getTrimmedValue());
			cmpqmbpn.setSvcTaskCharWfmName(serviceTaskCharFeatureConfiguration.getId().getTrimmedValue());
			cmpqmbpn.setPremIdSaCharType(premiseIdSaCharType.getId().getTrimmedValue());
			cmpqmbpn.setZeroAdjType(zeroAdjType.getId().getTrimmedValue());
			cmpqmbpn.setMajorPledFundTypWfmName(majorPledFundTypeFeatureConfiguration.getId().getTrimmedValue());
			//Start Change - MPang - Defect 3441549 - 2016-05-31
			//cmpqmbpn.setHasQuoteCharType(hasQuoteCharType.getId().getTrimmedValue());
			cmpqmbpn.setHasQuoteCharType(hasQuoteCharType.trim());
			//End Change - MPang - Defect 3441549 - 2016-05-31
			callCobol();

			return true;
		}
		
		@Override
		public void initializeThreadWork(boolean flag)
				throws ThreadAbortedException, RunAbortedException {

			quoteServiceTaskType = getParameters().getQUOTE_SVC_TASK_TYPE();
			quoteServiceTaskActiveStatus = getParameters().getQUOTE_SVC_TASK_ACTIVE_STATUS();
			cwrPaCisDivision = getParameters().getCWR_PA_CIS_DIVISION();
			cwrPaSaType = getParameters().getCWR_PA_SA_TYPE();
			arpPaCisDivision = getParameters().getARP_PA_CIS_DIVISION();
			arpPaSaType = getParameters().getARP_PA_SA_TYPE();
			lowIncomeBudgetPlan = getParameters().getLOW_INCOME_BUDGET_PLAN();
			cwrBudgetPlan = getParameters().getCWR_BUDGET_PLAN();
			bpapCredCharType = getParameters().getBPAP_CRED_CHAR_TYPE();
			pledgeServiceTaskType = getParameters().getPLEDGE_SVC_TASK_TYPE();
			pledgeServiceTaskStatus = getParameters().getPLEDGE_SVC_TASK_STATUS();
			selectionFeatureConfiguration = getParameters().getSELECTION_WFM_NAME();
			diversionFeatureConfiguration = getParameters().getDIVERSION_SA_WFM_NAME();
			paSAFeatureConfiguration = getParameters().getPA_SA_WFM_NAME();
			cwrSaCharType = getParameters().getCWR_SA_CHAR_TYPE();
			quoteIdSaCharType = getParameters().getQUOTE_ID_SA_CHAR_TYPE();
			quoteServiceTaskExpiredStatus = getParameters().getQUOTE_SVC_TASK_EXPIRED_STATUS();
			reCalcSaCharType = getParameters().getRECALC_SA_CHAR_TYPE();
			recalcCharVal = getParameters().getRECALC_CHAR_VAL();
			xferAdjType = getParameters().getXFER_ADJ_TYPE();
			adjustmentCancelReason = getParameters().getADJ_CAN_RSN_CD();
			bpapCredFeatureConfiguration = getParameters().getBPAP_CRED_VAL_WFM_NAME();
			serviceTaskCharFeatureConfiguration = getParameters().getSVC_TASK_CHAR_WFM_NAME();
			premiseIdSaCharType = getParameters().getPREM_ID_SA_CHAR_TYPE();
			zeroAdjType = getParameters().getZERO_ADJ_TYPE();
			majorPledFundTypeFeatureConfiguration = getParameters().getMAJOR_PLED_FUND_TYP_WFM_NAME();
			hasQuoteCharType = getParameters().getHAS_QUOTE_CHAR_TYPE();

			try {
				// initialize program
				initializeCobolProgram();
			}
			catch(Exception err) {
				addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), err.toString()));
			} 	
		}

		//Start Add - MPang - Defect 3441549 - 2016-05-31
		@Override
        public void finalizeThreadWork() throws ThreadAbortedException,
                RunAbortedException {
			// start update - equint - 2025-11-14 - CCB25.4 Upgrade
			cmpqmbpn=Session.returnSessionAndCodeToCache(cmpqmbpn);
//            try {
//                cmpqmbpn=Session.returnSessionAndCodeToCache(cmpqmbpn);
//                connection.close();
//            } catch(SQLException se) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getIdValue(), se.getMessage()));
//            }
         // end update - equint - 2025-11-14 - CCB25.4 Upgrade
        }
		//End Add - MPang - Defect 3441549 - 2016-05-31
		
		/*
		 * Initialize cobol program
		 */
		@SuppressWarnings("deprecation")
		private void initializeCobolProgram() throws Exception {
			FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
			RequestContext context = session.getRequestContext();
			
			// start update - equint - 2025-11-14 - CCB25.4 Upgrade
      		session.doWork(new ConnectionWork() {
      			
      			@Override
      			public void execute(Connection connection) throws SQLException {
      				try { 
      					String username = connection.getMetaData().getUserName();
      					String url = connection.getMetaData().getURL();

      					CobolSession.setLogSessionStartEnd(false);
      					cmpqmbpn=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpqmbpn.class);

      					cmpqmbpn.getSession().getDbSession().setUpdateConnection(connection);
      					cmpqmbpn.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");

      					// set ZSTAT parameters

      					cmpqmbpn.setProcessDttmProcessDt(getProcessDateTime().getDate().toString());
      					cmpqmbpn.setProcessDttmSep("-");
      					cmpqmbpn.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");

      					if (session.isOnlineConnection()) { 
      						cmpqmbpn.setConnectionFlg(CONNECTION_ONLINE);
      					}
      					else {
      						cmpqmbpn.setConnectionFlg(CONNECTION_BATCH);
      					}

      					cmpqmbpn.setUserId(context.getUserId()); 
      					cmpqmbpn.setZstatLanguageCd(context.getLanguageCode());

      					if (context.ignoreWarnings()) {
      						cmpqmbpn.setIgnoreWarningSw(SWITCH_YES);
      					}
      					else {
      						cmpqmbpn.setIgnoreWarningSw(SWITCH_NO);
      					}

      					if (session.getBatchInstanceId() != null) {
      						cmpqmbpn.setZstatSchedulerId(new BigDecimal(session.getBatchInstanceId()));
      						cmpqmbpn.setSchedulerId(new BigDecimal(session.getBatchInstanceId()));

      					} else {
      						cmpqmbpn.setZstatSchedulerId(new BigDecimal(0));
      						cmpqmbpn.setSchedulerId(new BigDecimal(0));
      					}

      					cmpqmbpn.setAppSvcId(context.getSecurityServiceIdContext());

      					DatabaseHelper dbHelper = session.getDatabaseHelper();
      					cmpqmbpn.setDbMode(dbHelper.getCobolDBMode());
      					// CCB v2.6 Upgrade - 2018-05-31 - Start Change
      					//cmpqmbpn.setSplHighValue(cmpqmbpn.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
      					//cmpqmbpn.setSplLowValue(cmpqmbpn.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
      					
      					cmpqmbpn.setSplHighValue(cmpqmbpn.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
      		            cmpqmbpn.setSplLowValue(cmpqmbpn.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
      					// CCB v2.6 Upgrade - 2018-05-31 - End Change

      					cmpqmbpn.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()));

      					cmpqmbpn.setLkExpiryDt(Date.MAX.toString());

      					cmpqmbpn.setProgramStatus(" ");
      					
      					// CCB v2.6 Upgrade - 2018-08-02 - Start Add
      			        cmpqmbpn.setCallSeq(";");
      			        cmpqmbpn.setMessageAreaProgramName("CMPQMBPN");
      			        // CCB v2.6 Upgrade - 2018-08-02 - End Add

      					if (context.getRandomGeneratorSeedSet().isTrue()) {
      						cmpqmbpn.setRandomGenSeedSw(SWITCH_YES);
      						cmpqmbpn.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()));
      						cmpqmbpn.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()));
      						cmpqmbpn.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()));
      						cmpqmbpn.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()));
      					}
      					else {
      						cmpqmbpn.setRandomGenSeedSw(SWITCH_NO);
      					}

      					if (context.traceStandardOut()) { 
      						cmpqmbpn.setTrcStdoutSw(SWITCH_YES);
      					}
      					else {
      						cmpqmbpn.setTrcStdoutSw(SWITCH_NO);
      					}

      					if (context.traceProgramStart()) { 
      						cmpqmbpn.setTrcProgStartSw(SWITCH_YES);
      					}
      					else {
      						cmpqmbpn.setTrcProgStartSw(SWITCH_NO);
      					}

      					if (context.traceProgramExit()) { 
      						cmpqmbpn.setTrcProgExitSw(SWITCH_YES);
      					}
      					else {
      						cmpqmbpn.setTrcProgExitSw(SWITCH_NO);
      					}

      					if (context.traceSQL()) { 
      						cmpqmbpn.setTrcExecSqlSw(SWITCH_YES);
      					}
      					else {
      						cmpqmbpn.setTrcExecSqlSw(SWITCH_NO);
      					} 
      				}
      				catch(Exception e) {
    					throw new SQLException(e.getCause());
    				}
    				
    			}
    		});

//			SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//			//Start Change - MPang - Defect 3441549 - 2016-05-31
//			//Connection connection = implementor.getConnectionProvider().getConnection();
//			connection = implementor.getConnectionProvider().getConnection();
//			//End Change - MPang - Defect 3441549 - 2016-05-31
//
//			String username = connection.getMetaData().getUserName();
//			String url = connection.getMetaData().getURL();
//
//			CobolSession.setLogSessionStartEnd(false);
//			cmpqmbpn=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpqmbpn.class);
//
//			cmpqmbpn.getSession().getDbSession().setUpdateConnection(connection);
//			cmpqmbpn.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//
//			// set ZSTAT parameters
//
//			cmpqmbpn.setProcessDttmProcessDt(getProcessDateTime().getDate().toString());
//			cmpqmbpn.setProcessDttmSep("-");
//			cmpqmbpn.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//
//			if (session.isOnlineConnection()) { 
//				cmpqmbpn.setConnectionFlg(CONNECTION_ONLINE);
//			}
//			else {
//				cmpqmbpn.setConnectionFlg(CONNECTION_BATCH);
//			}
//
//			cmpqmbpn.setUserId(context.getUserId()); 
//			cmpqmbpn.setZstatLanguageCd(context.getLanguageCode());
//
//			if (context.ignoreWarnings()) {
//				cmpqmbpn.setIgnoreWarningSw(SWITCH_YES);
//			}
//			else {
//				cmpqmbpn.setIgnoreWarningSw(SWITCH_NO);
//			}
//
//			if (session.getBatchInstanceId() != null) {
//				cmpqmbpn.setZstatSchedulerId(new BigDecimal(session.getBatchInstanceId()));
//				cmpqmbpn.setSchedulerId(new BigDecimal(session.getBatchInstanceId()));
//
//			} else {
//				cmpqmbpn.setZstatSchedulerId(new BigDecimal(0));
//				cmpqmbpn.setSchedulerId(new BigDecimal(0));
//			}
//
//			cmpqmbpn.setAppSvcId(context.getSecurityServiceIdContext());
//
//			DatabaseHelper dbHelper = session.getDatabaseHelper();
//			cmpqmbpn.setDbMode(dbHelper.getCobolDBMode());
//			// CCB v2.6 Upgrade - 2018-05-31 - Start Change
//			//cmpqmbpn.setSplHighValue(cmpqmbpn.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//			//cmpqmbpn.setSplLowValue(cmpqmbpn.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//			
//			cmpqmbpn.setSplHighValue(cmpqmbpn.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//            cmpqmbpn.setSplLowValue(cmpqmbpn.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//			// CCB v2.6 Upgrade - 2018-05-31 - End Change
//
//			cmpqmbpn.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()));
//
//			cmpqmbpn.setLkExpiryDt(Date.MAX.toString());
//
//			cmpqmbpn.setProgramStatus(" ");
//			
//			// CCB v2.6 Upgrade - 2018-08-02 - Start Add
//	        cmpqmbpn.setCallSeq(";");
//	        cmpqmbpn.setMessageAreaProgramName("CMPQMBPN");
//	        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//
//			if (context.getRandomGeneratorSeedSet().isTrue()) {
//				cmpqmbpn.setRandomGenSeedSw(SWITCH_YES);
//				cmpqmbpn.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()));
//				cmpqmbpn.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()));
//				cmpqmbpn.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()));
//				cmpqmbpn.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()));
//			}
//			else {
//				cmpqmbpn.setRandomGenSeedSw(SWITCH_NO);
//			}
//
//			if (context.traceStandardOut()) { 
//				cmpqmbpn.setTrcStdoutSw(SWITCH_YES);
//			}
//			else {
//				cmpqmbpn.setTrcStdoutSw(SWITCH_NO);
//			}
//
//			if (context.traceProgramStart()) { 
//				cmpqmbpn.setTrcProgStartSw(SWITCH_YES);
//			}
//			else {
//				cmpqmbpn.setTrcProgStartSw(SWITCH_NO);
//			}
//
//			if (context.traceProgramExit()) { 
//				cmpqmbpn.setTrcProgExitSw(SWITCH_YES);
//			}
//			else {
//				cmpqmbpn.setTrcProgExitSw(SWITCH_NO);
//			}
//
//			if (context.traceSQL()) { 
//				cmpqmbpn.setTrcExecSqlSw(SWITCH_YES);
//			}
//			else {
//				cmpqmbpn.setTrcExecSqlSw(SWITCH_NO);
//			} 
      		
      	// end update - equint - 2025-11-14 - CCB25.4 Upgrade

		}

		private void callCobol() {
			try {
				cmpqmbpn.cobolMain();
			}catch(Exception _ex) {
				Throwable ex=_ex;
				while(ex.getCause()!=null) ex=ex.getCause();
				// Start Update - Equint - Defect 4146452 - 2018-11-06
				// if(ex instanceof Stop) {
				if(ex instanceof Stop || ex instanceof ApplicationError) {
				// End Update - Equint - Defect 4146452 - 2018-11-06

					// if message number and category are not 0, meaning a server message is passed from the jacob code
					if (cmpqmbpn.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
							&& cmpqmbpn.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {

						// pass the parameter to the server message
						MessageParameters messageparameters = new MessageParameters();
						for (int i = 1; i <= 9; i++) {
							try { 
								String parmValue = cmpqmbpn.getMessageParm(i);
								if (notBlank(parmValue)) {
									messageparameters.addRawString(parmValue.trim());
								}
							}
							catch(IndexOutOfBounds e) {
								break;
							}

						}
						MessageCategory_Id categoryId = new MessageCategory_Id(cmpqmbpn.getZmsgnMessageCatNbr().toBigInteger());
						ServerMessage serverMessage = 
								ServerMessageFactory.Factory.newInstance().createMessage(
										categoryId, cmpqmbpn.getMessageNbr().intValue(), messageparameters);

						// check the message severity so we'll know what type of message to raise

						// info
						if (cmpqmbpn.getMessageSeverity().compareTo(
								MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
							logInfo(serverMessage);
						}
						// warning
						else if (cmpqmbpn.getMessageSeverity().compareTo(
								MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
							logWarning(serverMessage);
						}
						// error
						else {
							// 2016-06-22 SMiran Defect 3459051 Start Change
							//logError(serverMessage);
							addError(serverMessage, MessageSeverityLookup.constants.SEVERE);
							// 2016-06-22 SMiran Defect 3459051 End Change
						}
					}
				}
				else  {
				    //Start Add - MPang - Defect 3441549 - 2016-05-31
				    ex.printStackTrace();
				    //End Add - MPang - Defect 3441549 - 2016-05-31
					addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), _ex.toString()));
				}
			}

		}


	}

	@Override
	public void validateSoftParameters(boolean flag) {

		BusinessObject quoteBo = getParameters().getQUOTE_SVC_TASK_TYPE().getRelatedTransactionBO();
		BusinessObjectStatus_Id quoteServiceTaskActiveStatusId = new BusinessObjectStatus_Id(quoteBo, getParameters().getQUOTE_SVC_TASK_ACTIVE_STATUS());
		if (isNull(quoteServiceTaskActiveStatusId.getEntity())) {
			CustomMessageRepository.JACOB_boStatusNotValidForBo(
					getParameters().getQUOTE_SVC_TASK_ACTIVE_STATUS(), quoteBo.getId().getTrimmedValue());
		}
		
		if (notNull(getParameters().getCWR_PA_CIS_DIVISION())){
			CisDivision cwrPaCisDivision = getParameters().getCWR_PA_CIS_DIVISION();
			String cwrPaSaType = getParameters().getCWR_PA_SA_TYPE();
			ServiceAgreementType saType = new ServiceAgreementType_Id(cwrPaCisDivision, cwrPaSaType).getEntity();
			if (isNull(saType)) {
				addError(CustomMessageRepository.JACOB_saTypeNotValidForCisDivision(
						cwrPaSaType, cwrPaCisDivision.getId().getTrimmedValue()));
			}
		}
		
		if (notNull(getParameters().getARP_PA_CIS_DIVISION())) {
			CisDivision arpPaCisDivision = getParameters().getARP_PA_CIS_DIVISION();
			String arpPaSaType = getParameters().getARP_PA_SA_TYPE();
			ServiceAgreementType saType = new ServiceAgreementType_Id(arpPaCisDivision, arpPaSaType).getEntity();
			if (isNull(saType)) {
				addError(CustomMessageRepository.JACOB_saTypeNotValidForCisDivision(
						arpPaSaType, arpPaCisDivision.getId().getTrimmedValue()));
			}
		}
		
		CharacteristicType bpapCredCharType = getParameters().getBPAP_CRED_CHAR_TYPE();
		CharacteristicEntity charEntity = new CharacteristicEntity_Id(bpapCredCharType, 
				CharacteristicEntityLookup.constants.SERVICE_AGREEMENT).getEntity();
		if (isNull(charEntity)) {
			addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
					bpapCredCharType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().getEffectiveDescription()));
		}
		
		BusinessObject pledgeBo = getParameters().getPLEDGE_SVC_TASK_TYPE().getRelatedTransactionBO();
		BusinessObjectStatus_Id pledgeServiceTaskStatusId = new BusinessObjectStatus_Id(pledgeBo, getParameters().getPLEDGE_SVC_TASK_STATUS());
		if (isNull(pledgeServiceTaskStatusId.getEntity())) {
			CustomMessageRepository.JACOB_boStatusNotValidForBo(
					getParameters().getPLEDGE_SVC_TASK_STATUS(), pledgeBo.getId().getTrimmedValue());
		}

		CharacteristicType cwrSaCharType = getParameters().getCWR_SA_CHAR_TYPE();
		charEntity = new CharacteristicEntity_Id(cwrSaCharType, 
				CharacteristicEntityLookup.constants.SERVICE_AGREEMENT).getEntity();
		if (isNull(charEntity)) {
			addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
					cwrSaCharType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().getEffectiveDescription()));
		}

		CharacteristicType quoteIdSaCharType = getParameters().getQUOTE_ID_SA_CHAR_TYPE();
		charEntity = new CharacteristicEntity_Id(quoteIdSaCharType, 
				CharacteristicEntityLookup.constants.SERVICE_AGREEMENT).getEntity();
		if (isNull(charEntity)) {
			addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
					quoteIdSaCharType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().getEffectiveDescription()));
		}
		
		BusinessObjectStatus_Id quoteServiceTaskExpiredStatusId = new BusinessObjectStatus_Id(quoteBo, getParameters().getQUOTE_SVC_TASK_EXPIRED_STATUS());
		if (isNull(quoteServiceTaskExpiredStatusId.getEntity())) {
			CustomMessageRepository.JACOB_boStatusNotValidForBo(
					getParameters().getQUOTE_SVC_TASK_EXPIRED_STATUS(), quoteBo.getId().getTrimmedValue());
		}

		CharacteristicType reCalcSaCharType = getParameters().getRECALC_SA_CHAR_TYPE();
		charEntity = new CharacteristicEntity_Id(reCalcSaCharType, 
				CharacteristicEntityLookup.constants.SERVICE_AGREEMENT).getEntity();
		if (isNull(charEntity)) {
			addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
					reCalcSaCharType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().getEffectiveDescription()));
		}

		CharacteristicType premiseIdSaCharType = getParameters().getPREM_ID_SA_CHAR_TYPE();
		charEntity = new CharacteristicEntity_Id(premiseIdSaCharType, 
				CharacteristicEntityLookup.constants.SERVICE_AGREEMENT).getEntity();
		if (isNull(charEntity)) {
			addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
					premiseIdSaCharType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().getEffectiveDescription()));
		}
		//Start Delete - MPang - Defect 3441549 - 2016-05-31
//		CharacteristicType hasQuoteCharType = getParameters().getHAS_QUOTE_CHAR_TYPE();
//		charEntity = new CharacteristicEntity_Id(hasQuoteCharType, 
//				CharacteristicEntityLookup.constants.SERVICE_AGREEMENT).getEntity();
//		if (isNull(charEntity)) {
//			addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
//					hasQuoteCharType.getId().getTrimmedValue(), 
//					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().getEffectiveDescription()));
//		}
		//End Delete - MPang - Defect 3441549 - 2016-05-31

	}

}
