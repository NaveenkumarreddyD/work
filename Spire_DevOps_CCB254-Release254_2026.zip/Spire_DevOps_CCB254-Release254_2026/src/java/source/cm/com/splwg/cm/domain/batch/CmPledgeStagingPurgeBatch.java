/* 
 *********************************************************************** 
 *                 Confidentiality Information: 
 * 
 * This module is the confidential and proprietary information of 
 * Oracle Corporation; it is not to be copied, reproduced, or 
 * transmitted in any form, by any means, in whole or in part, 
 * nor is it to be used for any purpose other than that for which 
 * it is expressly provided without the written permission of 
 * Oracle Corporation. 
 * 
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION:
 * 
 * Pledge Staging Records Purge Batch Process
 * This Batch Process receives a cutoff date as batchParameter 
 * And Purges all records in staging table (CM_PLDG_ACTN_FILE_STG_UP)
 * on or before the cutoff date.
 ********************************************************************** 
 * 
 * 
 * CHANGE HISTORY: 
 * 
 * Date:       by:       Reason:
 * YYYY-MM-DD  IN        Reason text.
 *
 * 2015-01-27  Rahul     (IM-062090)Created. Initial Version. 
 * 2016-01-29  MPang	  Updated for CCB v2.4 compilation.                     
 ************************************************************************ 
 */
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
//import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.common.CmPledgeActionFileStgUp_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author rsaran003
 *
@BatchJob (multiThreaded = true, rerunnable = true, modules = {},
 *		softParameters = { @BatchJobSoftParameter (name = PurgeCutOffDate, required = true, type = date)})
 */
public class CmPledgeStagingPurgeBatch extends CmPledgeStagingPurgeBatch_Gen {
	private Date purgeCutoffDate;
	public JobWork getJobWork() {
		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
		PreparedStatement recordsToPurgeStmt = createPreparedStatement(" SELECT CM_PLEDGE_ID, ACCT_ID, SA_ID, BATCH_CD, BATCH_NBR, CM_PLDG_ACTION " + 
																		" FROM CM_PLDG_ACTN_FILE_STG_UP " +
																		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
																		//" WHERE PROCESS_DT <= :purgeCutoffDate");
																		" WHERE PROCESS_DT <= :purgeCutoffDate", getClass().getName());
																		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		recordsToPurgeStmt.bindDate("purgeCutoffDate", purgeCutoffDate);
		
		QueryIterator<SQLResultRow> recordsToPurgeIter = recordsToPurgeStmt.iterate();
		while(recordsToPurgeIter.hasNext()){
			SQLResultRow row = recordsToPurgeIter.next();
			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId(new ServiceTask_Id(row.getString("CM_PLEDGE_ID")));
			workUnit.addSupplementalData("ACCT_ID", row.getString("ACCT_ID"));
			workUnit.addSupplementalData("SA_ID", row.getString("SA_ID"));
			workUnit.addSupplementalData("BATCH_CD", row.getString("BATCH_CD"));
			workUnit.addSupplementalData("BATCH_NBR", row.getString("BATCH_NBR"));
			workUnit.addSupplementalData("CM_PLDG_ACTION", row.getString("CM_PLDG_ACTION"));
			workUnits.add(workUnit);
		}
		
		recordsToPurgeIter.close();
		recordsToPurgeStmt.close();
		return createJobWorkForThreadWorkUnitList(workUnits);

	}

	@Override
	public void validateSoftParameters(boolean isNewRun) {
		// TODO Auto-generated method stub
		purgeCutoffDate = this.getParameters().getPurgeCutOffDate();
	}

	public Class<CmPledgeStagingPurgeBatchWorker> getThreadWorkerClass() {
		return CmPledgeStagingPurgeBatchWorker.class;
	}

	public static class CmPledgeStagingPurgeBatchWorker extends
			CmPledgeStagingPurgeBatchWorker_Gen {
		
		private String AccountId;
		private BigInteger pledgeId;
		private String serviceAgreementId;
		private String batchControlCode;
		private BigInteger batchNumber;
		private String action;
		private BigInteger numOfRecordsProcessed;
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			// TODO Auto-generated method stub
			return new StandardCommitStrategy(this);
		}

		@Override
		public void initializeThreadWork(
				boolean arg0)
				throws ThreadAbortedException, RunAbortedException {
			numOfRecordsProcessed = BigInteger.ZERO;
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			pledgeId = new BigInteger(((ServiceTask_Id)unit.getPrimaryId()).getTrimmedValue());
			AccountId = (String) unit.getSupplementallData("ACCT_ID");
			serviceAgreementId = (String) unit.getSupplementallData("SA_ID");
			batchControlCode = (String) unit.getSupplementallData("BATCH_CD");
			batchNumber = new BigInteger((String) unit.getSupplementallData("BATCH_NBR"));
			action = (String) unit.getSupplementallData("CM_PLDG_ACTION");
			CmPledgeActionFileStgUp_Id pledgeStageUpRecordId = new CmPledgeActionFileStgUp_Id(pledgeId, AccountId, serviceAgreementId, batchControlCode	, batchNumber, action);
			pledgeStageUpRecordId.getEntity().delete();
			numOfRecordsProcessed = numOfRecordsProcessed.add(BigInteger.ONE);
			return true;
		}
		
		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
			logInfo(CustomMessageRepository.na0002TotalRecordsProcessed(numOfRecordsProcessed));
		}

	}

}
