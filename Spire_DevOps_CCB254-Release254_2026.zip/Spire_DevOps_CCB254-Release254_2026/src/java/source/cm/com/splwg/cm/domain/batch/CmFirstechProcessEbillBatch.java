/*
 ***************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * FirsTech Process Paperless Billing Inconsistencies
 * This batch process will identify paperless billing inconsistencies between 
 * CCB and FirsTech.  CCB accounts will be compared to the FirsTech customer 
 * data, and an output file will be generated with corrections to be 
 * made by FirsTech.
 *            
 ****************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2020-01-04   JLumbre SpireOne. CCB-107. Initial Version.
 * 2020-05-06   JLumbre SpireOne. Updated getjobWork criteria.
 *  
 ****************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.lookup.LookupField;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.cm.api.lookup.BillFormatLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author TMG02631
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules={},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = lookupField, name = BILL_FORMAT_LOOKUP_FIELD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = PAPERLESS_BILL_FORMAT_FLG, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)})
 */
public class CmFirstechProcessEbillBatch extends
CmFirstechProcessEbillBatch_Gen {

	private static final Logger log = LoggerFactory.getLogger(CmFirstechProcessEbillBatch.class);
	private String parmFilePath;
	private BigInteger parmMaxErrors;
	private LookupField parmLookup;
	private String parmPaperlessBillFormatFlag;
	//Start Add - JLumbre - 2020-05-06
	private BillFormatLookup lookup;
	//End Add - JLumbre - 2020-05-06

	public JobWork getJobWork() {
		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();

		StringBuilder qryStr = new StringBuilder();
		qryStr.append("SELECT AP.ACCT_ID, AP.BILL_FORMAT_FLG, 'XE_CCB' AS FLG ");
		qryStr.append("FROM CI_ACCT_PER AP ");
		qryStr.append("WHERE AP.MAIN_CUST_SW='Y' ");
		qryStr.append("AND AP.BILL_FORMAT_FLG = :xe ");
		qryStr.append("AND (EXISTS (SELECT 'X' FROM CM_FIRSTECH_CUST_IN FT ");
		qryStr.append("WHERE FT.ACCT_ID=AP.ACCT_ID ");
		qryStr.append("AND FT.CM_PAPERLESS_FLG ='N') ");
		qryStr.append("OR NOT EXISTS (SELECT 'X' FROM CM_FIRSTECH_CUST_IN FT  ");
		qryStr.append("WHERE FT.ACCT_ID=AP.ACCT_ID )) ");
		qryStr.append("UNION ALL ");
		qryStr.append("SELECT AP1.ACCT_ID, AP1.BILL_FORMAT_FLG, 'XE_FT' AS FLG ");
		qryStr.append("FROM CI_ACCT_PER AP1 ");
		qryStr.append("WHERE AP1.MAIN_CUST_SW='Y' ");
		qryStr.append("AND AP1.BILL_FORMAT_FLG <> :xe ");
		qryStr.append("AND EXISTS (SELECT 'X' FROM CM_FIRSTECH_CUST_IN FT1 ");
		qryStr.append("WHERE FT1.ACCT_ID=AP1.ACCT_ID ");
		qryStr.append("AND FT1.CM_PAPERLESS_FLG ='Y') ");


		PreparedStatement ps = createPreparedStatement(qryStr.toString(), "getJobWork");
		
		//Start Change - JLumbre - 2020-05-06
		//ps.bindString("xe","BILL_FORMAT_FLG", parmPaperlessBillFormatFlag);
		ps.bindLookup("xe", lookup);
		//End Change - JLumbre - 2020-05-06
		ps.setAutoclose(false);
		ps.execute();


		QueryIterator<SQLResultRow> row = ps.iterate();
		while (row.hasNext()){
			SQLResultRow rec = row.next();
			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId(rec.getId("ACCT_ID", Account.class));			
			workUnit.addSupplementalData("FLG", rec.getString("FLG"));
			workUnits.add(workUnit);
		}
		log.info(">>>>> parmPaperlessBillFormatFlag : " + parmPaperlessBillFormatFlag );
		log.info(">>>>> count: " + workUnits.size()) ;
		row.close();
		ps.close();

		return createJobWorkForThreadWorkUnitList(workUnits);
	}

	@Override
	public void validateSoftParameters(boolean isNewRun) {
		// Parameter FILE_PATH
		parmFilePath = getParameters().getFILE_PATH();        
		if (notBlank(parmFilePath) && validateFilePath(parmFilePath).isFalse()) {
			addError(CustomMessageRepositorySpireOne.S1_FilePathInvalid(parmFilePath));            
		}

		parmMaxErrors = getParameters().getMAX_ERRORS();
		if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0){
			addError(CustomMessageRepositorySpireOne.S1_MaxErrorCannotBeLessThanZero(parmMaxErrors.toString()));
		}

		parmLookup = getParameters().getBILL_FORMAT_LOOKUP_FIELD();
		parmPaperlessBillFormatFlag = getParameters().getPAPERLESS_BILL_FORMAT_FLG();
		validateLookupValue(parmLookup, parmPaperlessBillFormatFlag);
		
		//Start Add - JLumbre - 2020-05-06
		if (parmPaperlessBillFormatFlag.compareTo(BillFormatLookup.constants.EBILL.value()) == 0){
			lookup = BillFormatLookup.constants.EBILL;
		}
		else if (parmPaperlessBillFormatFlag.compareTo(BillFormatLookup.constants.DETAILED.value()) == 0){
			lookup = BillFormatLookup.constants.DETAILED;
		}
		else if (parmPaperlessBillFormatFlag.compareTo(BillFormatLookup.constants.SUMMARY.value()) == 0){
			lookup = BillFormatLookup.constants.SUMMARY;
		}
		else if (parmPaperlessBillFormatFlag.compareTo(BillFormatLookup.constants.LARGE.value()) == 0){
			lookup = BillFormatLookup.constants.LARGE;
		}
		else {
			lookup = BillFormatLookup.constants.BRAILLE;
		}
		//End Add - JLumbre - 2020-05-06

	}

	/**
	 * This method validates file path
	 * @param filePath - String
	 * @return Bool
	 */
	private Bool validateFilePath(String filePath) {

		File folder = new File(filePath);
		if (folder.exists()) {
			return Bool.TRUE;
		}
		return Bool.FALSE;
	}

	private void validateLookupValue(LookupField lookupField, String lookupValue) {

		LookupValue_Id lookupValueID = new LookupValue_Id(lookupField, lookupValue);
		if (isNull(lookupValueID.getEntity())) {
			addError(CustomMessageRepositorySpireOne.S1_lookupValueInvalidForLookupField(lookupValue.trim(), lookupField.getId().getTrimmedValue()));
		}		
	}

	public Class<CmFirstechProcessEbillBatchWorker> getThreadWorkerClass() {
		return CmFirstechProcessEbillBatchWorker.class;
	}

	public static class CmFirstechProcessEbillBatchWorker extends
	CmFirstechProcessEbillBatchWorker_Gen {

		//soft parameters
		private String filePath;
		private String fileName;		

		// Work variables
		private File extractFile;
		private BufferedWriter extractFileWriter;

		private int recordCountPaperless = 0;
		private int recordCountNotPaperless = 0;

		private static String COMMA_SEPARATOR = ",";
		private static String YES = "Y";
		private static String NO = "N";
		private static String XE_CCB = "XE_CCB";


		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			Account_Id acctId = (Account_Id) unit.getPrimaryId();
			String ftFlag = (String) unit.getSupplementallData("FLG");

			if (!isBlankOrNull(ftFlag) && ftFlag.compareTo(XE_CCB) == 0){
				//if present, and not paperless, write to file
				writeToFile(acctId, YES);
				recordCountPaperless = recordCountPaperless + 1;
			}
			else{					
				//Not paperless, write to file
				writeToFile(acctId, NO);
				recordCountNotPaperless = recordCountNotPaperless + 1;
			}		

			return true;
		}


		public void writeToFile(Account_Id accountId, String switchYN){

			StringBuilder record = new StringBuilder();	

			record.append(accountId.getTrimmedValue());	
			record.append(COMMA_SEPARATOR);
			record.append(switchYN.trim());

			try {
				extractFileWriter.write(record.toString());
				extractFileWriter.newLine();						
			}
			catch (Exception e) {				
				throw new RunAbortedException(CustomMessageRepositorySpireOne.S1_GenericErrorWritingToFile(extractFile.getAbsolutePath()));
			}

		}

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException,
		RunAbortedException {
			try {            					
				extractFileWriter.close();  

				logInfo(CustomMessageRepositorySpireOne.S1_totalRecordsPaperless(recordCountPaperless));
				logInfo(CustomMessageRepositorySpireOne.S1_totalRecordsNotPaperless(recordCountNotPaperless));
			}
			catch(Exception e) {				
				throw new RunAbortedException(CustomMessageRepositorySpireOne.S1_GenericErrorClosingFile(extractFile.getAbsolutePath()));								
			}
		}

		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
						throws ThreadAbortedException, RunAbortedException {

			fileName = getParameters().getFILE_NAME();
			filePath = getParameters().getFILE_PATH();

			// Open Extract File
			try {
				extractFile = new File(filePath,fileName);   
				extractFileWriter = new BufferedWriter(new FileWriter(extractFile));     
			}
			catch(Exception e) {				
				throw new RunAbortedException(CustomMessageRepositorySpireOne.S1_GenericErrorOpeningFile(extractFile.getAbsolutePath()));
			}
		}

	}

}
