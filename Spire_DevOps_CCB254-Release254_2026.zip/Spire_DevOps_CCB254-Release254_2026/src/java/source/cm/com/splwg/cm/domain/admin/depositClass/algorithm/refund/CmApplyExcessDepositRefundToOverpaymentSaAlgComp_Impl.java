/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPDMDCX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      NA0102. Initial Version.  
 * 2016-05-30   MPang       Defect 3444302. Added close connection
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.
 * 2025-11-14   EQuint      CCB25.4 Upgrade                      
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.depositClass.algorithm.refund;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.depositClass.algorithm.refund.DepositClassRefundAlgorithmSpot;
import com.splwg.ccb.domain.admin.depositClass.entity.DepositClass;
import com.splwg.ccb.domain.admin.depositClass.entity.DepositClass_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpdmdcx;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentType, name = syncAdjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = transferAdjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = cisDivision, name = overpaymentCisDivision, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = overpaymentSaType, required = true, type = string)})
 */
public class CmApplyExcessDepositRefundToOverpaymentSaAlgComp_Impl extends
		CmApplyExcessDepositRefundToOverpaymentSaAlgComp_Gen implements
		DepositClassRefundAlgorithmSpot {

	// hard parameters
	private DepositClass depositClass;
	private ServiceAgreement serviceAgreement;
	
	// soft parameters
	private AdjustmentType syncAdjustmentType;
	private AdjustmentType transferAdjustmentType;
	private CisDivision overpaymentCisDivision;
	private String overpaymentSaType;

	private Cmpdmdcx cmpdmdcx;
	//Start Add - MPang - Defect 3444302- 2016-05-30
	private Connection connection;
	//End Add - MPang - Defect 3444302- 2016-05-30
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	
	@Override
	public DepositClass getDepositClass() {
		return depositClass;
	}

	@Override
	public void setDepositClass(DepositClass arg0) {
		depositClass = arg0;
	}

	@Override
	public void setServiceAgreement(ServiceAgreement arg0) {
		serviceAgreement = arg0;
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		syncAdjustmentType = getSyncAdjustmentType();
		transferAdjustmentType = getTransferAdjustmentType();
		overpaymentCisDivision = getOverpaymentCisDivision();
		overpaymentSaType = getOverpaymentSaType();
	}

	@Override
	public void invoke() {
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			if (notNull(serviceAgreement)) {
				cmpdmdcx.setDmdrxInputWrkSaId(serviceAgreement.getId().getTrimmedValue());
			}else{
				cmpdmdcx.setDmdrxInputWrkSaId(CobolCode.SPACES.toString());
			}
			if (notNull(depositClass)) {
				cmpdmdcx.setIoWrkDepClCd(depositClass.getId().getTrimmedValue());
			}else{
				cmpdmdcx.setIoWrkDepClCd(CobolCode.SPACES.toString());
			}
			
			// soft parameters
			cmpdmdcx.setAlgParmVal(1, syncAdjustmentType.getId().getTrimmedValue()); 
			cmpdmdcx.setAlgParmVal(2, transferAdjustmentType.getId().getTrimmedValue()); 
			cmpdmdcx.setAlgParmVal(3, overpaymentCisDivision.getId().getTrimmedValue());
			cmpdmdcx.setAlgParmVal(4, overpaymentSaType); 
			
			// invoke the main method
		    cmpdmdcx.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;

		    //Start Delete - MPang - Defect 3444302- 2016-05-30
		    //ex.printStackTrace();
		    //End Delete - MPang - Defect 3444302- 2016-05-30
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmpdmdcx.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmpdmdcx.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmpdmdcx.getMessageParm(i);
			    			if (notBlank(cmpdmdcx.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmpdmdcx.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmpdmdcx.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmpdmdcx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmpdmdcx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    	depositClass = new DepositClass_Id(cmpdmdcx.getIoWrkDepClCd().trim()).getEntity();
		    }
		    else {
		        //Start Add - MPang - Defect 3444302- 2016-05-30
		        ex.printStackTrace();
		        //End Add - MPang - Defect 3444302- 2016-05-30
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmpdmdcx=Session.returnSessionAndCodeToCache(cmpdmdcx);
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//			//Start Add - MPang - Defect 3444302- 2016-05-30
//			try {
//                connection.close();
//            } catch (SQLException e) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
//            }
//			//End Add - MPang - Defect 3444302- 2016-05-30
			// end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}

	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
		FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
		RequestContext context = session.getRequestContext();
				
		// start update - equint - 2025-11-14 - CCB25.4 Upgrade
		session.doWork(new ConnectionWork() {
			
			@Override
			public void execute(Connection connection) throws SQLException {
				try {	
					String username = connection.getMetaData().getUserName();
					String url = connection.getMetaData().getURL();
					
					CobolSession.setLogSessionStartEnd(false);
				    cmpdmdcx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpdmdcx.class);
					
					cmpdmdcx.getSession().getDbSession().setUpdateConnection(connection);
					cmpdmdcx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
					
					// set ZSTAT parameters

					cmpdmdcx.setProcessDttmProcessDt(getProcessDateTime().getDate().toString());
					cmpdmdcx.setProcessDttmSep("-");
					cmpdmdcx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
					
					if (session.isOnlineConnection()) { 
						cmpdmdcx.setConnectionFlg(CONNECTION_ONLINE);
					}
					else {
						cmpdmdcx.setConnectionFlg(CONNECTION_BATCH);
					}
					
					cmpdmdcx.setUserId(context.getUserId());
					cmpdmdcx.setZstatLanguageCd(context.getLanguageCode());
			        
			        if (context.ignoreWarnings()) {
			        	cmpdmdcx.setIgnoreWarningSw(SWITCH_YES);
			        }
			        else {
			        	cmpdmdcx.setIgnoreWarningSw(SWITCH_NO);
			        }
			        
			        if (session.getBatchInstanceId() != null) {
			        	cmpdmdcx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
			        	
					} else {
						cmpdmdcx.setSchedulerId(new BigDecimal(0).toBigDecimal());
					}
			        
			        cmpdmdcx.setAppSvcId(context.getSecurityServiceIdContext());
			        
			        DatabaseHelper dbHelper = session.getDatabaseHelper();
			        cmpdmdcx.setDbMode(dbHelper.getCobolDBMode());
			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
			        //cmpdmdcx.setSplHighValue(cmpdmdcx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
			        //cmpdmdcx.setSplLowValue(cmpdmdcx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
			        
			        cmpdmdcx.setSplHighValue(cmpdmdcx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
			        cmpdmdcx.setSplLowValue(cmpdmdcx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
			        
			        cmpdmdcx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
			        
			        cmpdmdcx.setLkExpiryDt(Date.MAX.toString());
			        
			        cmpdmdcx.setProgramStatus(" ");
			        
			        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
			        cmpdmdcx.setCallSeq(";");
			        cmpdmdcx.setMessageAreaProgramName("CMPDMDCX");
			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
			        
			        if (context.getRandomGeneratorSeedSet().isTrue()) {
			        	cmpdmdcx.setRandomGenSeedSw(SWITCH_YES);
			        	cmpdmdcx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
			        	cmpdmdcx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
			        	cmpdmdcx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
			        	cmpdmdcx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
			        }
			        else {
			        	cmpdmdcx.setRandomGenSeedSw(SWITCH_NO);
			        }
			        
			        if (context.traceStandardOut()) { 
			        	cmpdmdcx.setTrcStdoutSw(SWITCH_YES);
			        }
			        else {
			        	cmpdmdcx.setTrcStdoutSw(SWITCH_NO);
			        }
			        
			        if (context.traceProgramStart()) { 
			        	cmpdmdcx.setTrcProgStartSw(SWITCH_YES);
			        }
			        else {
			        	cmpdmdcx.setTrcProgStartSw(SWITCH_NO);
			        }
			        
			        if (context.traceProgramExit()) { 
			        	cmpdmdcx.setTrcProgExitSw(SWITCH_YES);
			        }
			        else {
			        	cmpdmdcx.setTrcProgExitSw(SWITCH_NO);
			        }
			        
			        if (context.traceSQL()) { 
			        	cmpdmdcx.setTrcExecSqlSw(SWITCH_YES);
			        }
			        else {
			        	cmpdmdcx.setTrcExecSqlSw(SWITCH_NO);
			        }
			        
			        // Set ZMSGN parms
			        BigInteger messageSequence = session.getMessageSequence();
			        if (notNull(messageSequence)) {
			        	cmpdmdcx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
			        }
			        else {
			        	cmpdmdcx.setMessageSeq(new BigDecimal(0).toBigDecimal());
			        }
				}
				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		 
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//        //Start Change - MPang - Defect 3444302- 2016-05-30
//        //Connection connection = implementor.getConnectionProvider().getConnection();
//        connection = implementor.getConnectionProvider().getConnection();
//        //End Change - MPang - Defect 3444302- 2016-05-30
//		
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmpdmdcx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpdmdcx.class);
//		
//		cmpdmdcx.getSession().getDbSession().setUpdateConnection(connection);
//		cmpdmdcx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		
//		// set ZSTAT parameters
//
//		cmpdmdcx.setProcessDttmProcessDt(getProcessDateTime().getDate().toString());
//		cmpdmdcx.setProcessDttmSep("-");
//		cmpdmdcx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmpdmdcx.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmpdmdcx.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmpdmdcx.setUserId(context.getUserId());
//		cmpdmdcx.setZstatLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmpdmdcx.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmpdmdcx.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmpdmdcx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmpdmdcx.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmpdmdcx.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmpdmdcx.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmpdmdcx.setSplHighValue(cmpdmdcx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmpdmdcx.setSplLowValue(cmpdmdcx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmpdmdcx.setSplHighValue(cmpdmdcx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmpdmdcx.setSplLowValue(cmpdmdcx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmpdmdcx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmpdmdcx.setLkExpiryDt(Date.MAX.toString());
//        
//        cmpdmdcx.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmpdmdcx.setCallSeq(";");
//        cmpdmdcx.setMessageAreaProgramName("CMPDMDCX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmpdmdcx.setRandomGenSeedSw(SWITCH_YES);
//        	cmpdmdcx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmpdmdcx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmpdmdcx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmpdmdcx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmpdmdcx.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmpdmdcx.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmpdmdcx.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmpdmdcx.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmpdmdcx.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmpdmdcx.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmpdmdcx.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmpdmdcx.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmpdmdcx.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmpdmdcx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmpdmdcx.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }
		
		// end update - equint - 2025-11-14 - CCB25.4 Upgrade

	}

}
