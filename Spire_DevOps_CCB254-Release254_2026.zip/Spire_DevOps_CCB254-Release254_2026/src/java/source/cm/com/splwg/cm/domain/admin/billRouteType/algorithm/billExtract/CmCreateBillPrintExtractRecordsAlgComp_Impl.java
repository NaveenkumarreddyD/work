/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for Cmpbxblx Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      RI0008. Initial Version.
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.  
 * 2025-11-14   EQuint      CCB25.4 Upgrade                        
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.billRouteType.algorithm.billExtract;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.batch.batchControl.BatchControl;
import com.splwg.base.domain.common.algorithm.Algorithm;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.lookup.LookupField;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.domain.report.reportDefinition.ReportDefinition;
import com.splwg.base.domain.report.reportDefinition.ReportDefinition_Id;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.admin.billRouteType.algorithm.billExtract.BillExtractAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.common.fileHelper.FileHelper;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpbxblx;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = validateParameterSwitch, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (entityName = lookupField, name = billPrintHeaderDescriptionsLookupFieldName, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = billCorrectionPeriodHeaderLookupValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = otherChargesHeaderLookupValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = customerPaymentHeaderLookupValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = pledgePaymentHeaderLookupValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = remitToCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = defaultRemitTo, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = serviceQuantityIdentifier, name = btuFactorSQI, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = rateClassDescriptionCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = utilityChargesHeadersCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = taxingCommunityPremiseCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = taxingCommunityBillLineCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = grossAmountCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = latePaymentAdjustmentCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = pledgePaymentCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = serviceType, name = serviceTypeforMetered, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = serviceType, name = serviceTypeforUnmetered, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = dollarHelpSACharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = billCalcLinePriorityCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = additionalHistogramUOMSATypeCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = additionalHistogramSQISATypeCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = contractNumberSACharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = unitOfMeasure, name = propaneBillableUOM, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = schoolAggregationAccountCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = schoolAggregationAccountCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = budgetPaymentArrangementCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = rateClassCharacteristicType, required = true, type = entity)})
 */
public class CmCreateBillPrintExtractRecordsAlgComp_Impl extends
		CmCreateBillPrintExtractRecordsAlgComp_Gen implements
		BillExtractAlgorithmSpot {


	// hard parameter
	private Bool isBillSkipped;
	private Bool isXMLFile;
	private ReportDefinition reportDefinition;
	private BigInteger returnCode;
	private BatchControl batchControl;
	private BigInteger batchNumber;
	private BigInteger batchRerunNumber;
	private BigInteger batchThreadCount;
	private BigInteger batchThreadNumber;
	private Bill bill;
	private BigInteger billCount;
	private String endBillId;
	private Algorithm extractAlgorithm;
	private DateTime extractDateTime;
	private String extractFileName;
	private FileHelper fileHelper;
	private Bool isWriteSummary;
	private BigInteger numberOfCopies;
	private BigInteger sequenceNumber;
	private String startBillId;
	private Bill toBill;
	
	// soft parameter
	private Bool validateParameterSwitch;
	private LookupField billPrintHeaderDescriptionsLookupFieldName;
	private LookupValue billCorrectionPeriodHeaderLookupValue;
	private LookupValue otherChargesHeaderLookupValue;
	private LookupValue customerPaymentHeaderLookupValue;
	private LookupValue pledgePaymentHeaderLookupValue;
	private CharacteristicType remitToCharType;
	private String defaultRemitTo;
	private ServiceQuantityIdentifier btuFactorSQI;
	private CharacteristicType rateClassDescriptionCharType;
	private CharacteristicType utilityChargesHeadersCharType;
	private CharacteristicType taxingCommunityPremiseCharType;
	private CharacteristicType taxingCommunityBillLineCharType;
	private CharacteristicType grossAmountCharType;
	private CharacteristicType latePaymentAdjustmentCharType;
	private CharacteristicType pledgePaymentCharType;
	private ServiceType serviceTypeforMetered;
	private ServiceType serviceTypeforUnmetered;
	private CharacteristicType dollarHelpSACharType;
	private CharacteristicType billCalcLinePriorityCharType;
	private CharacteristicType additionalHistogramUOMSATypeCharType;
	private CharacteristicType additionalHistogramSQISATypeCharType;
	private CharacteristicType contractNumberSACharType;
	private UnitOfMeasure propaneBillableUOM;
	private CharacteristicType schoolAggregationAccountCharType;
	private String schoolAggregationAccountCharValue;
	private CharacteristicType budgetPaymentArrangementCharType;
	private CharacteristicType rateClassCharacteristicType;
	 

	
	// Work variables
	private Cmpbxblx cmpbxblx;
    private Connection connection;	
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	
	
	
	@Override
	public Bool getIsBillSkipped() {
		return isBillSkipped;
	}

	@Override
	public Bool getIsXmlFile() {
		return isXMLFile;
	}

	@Override
	public ReportDefinition getReportDefinition() {
		return reportDefinition;
	}

	@Override
	public BigInteger getReturnCode() {
		return returnCode;
	}

	@Override
	public void setBatchControl(BatchControl arg0) {
		batchControl = arg0;
	}

	@Override
	public void setBatchNumber(BigInteger arg0) {
		batchNumber = arg0;
	}

	@Override
	public void setBatchRerunNumber(BigInteger arg0) {
		batchRerunNumber = arg0;
	}

	@Override
	public void setBatchThreadCount(BigInteger arg0) {
		batchThreadCount = arg0;
	}

	@Override
	public void setBatchThreadNumber(BigInteger arg0) {
		batchThreadNumber = arg0;
	}

	@Override
	public void setBill(Bill arg0) {
		bill = arg0;
	}

	@Override
	public void setBillCount(BigInteger arg0) {
		billCount = arg0;
	}

	@Override
	public void setEndBillId(String arg0) {
		endBillId = arg0;
	}

	@Override
	public void setExtractAlgorithm(Algorithm arg0) {
		extractAlgorithm = arg0;
	}

	@Override
	public void setExtractDateTime(DateTime arg0) {
		extractDateTime = arg0;
	}

	@Override
	public void setExtractFileName(String arg0) {
		extractFileName = arg0;
	}

	@Override
	public void setFileHelper(FileHelper arg0) {
		fileHelper = arg0;
	}

	@Override
	public void setIsWriteSummary(Bool arg0) {
		isWriteSummary = arg0;
	}

	@Override
	public void setNumberOfCopies(BigInteger arg0) {
		numberOfCopies = arg0;
	}

	@Override
	public void setSequenceNumber(BigInteger arg0) {
		sequenceNumber = arg0;
	}

	@Override
	public void setStartBillId(String arg0) {
		startBillId = arg0;
	}

	@Override
	public void setToBill(Bill arg0) {
		toBill = arg0;
	}


	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		
		billPrintHeaderDescriptionsLookupFieldName = getBillPrintHeaderDescriptionsLookupFieldName();
		billCorrectionPeriodHeaderLookupValue = new LookupValue_Id(billPrintHeaderDescriptionsLookupFieldName, getBillCorrectionPeriodHeaderLookupValue()).getEntity();
		otherChargesHeaderLookupValue = new LookupValue_Id(billPrintHeaderDescriptionsLookupFieldName, getOtherChargesHeaderLookupValue()).getEntity();
		customerPaymentHeaderLookupValue = new LookupValue_Id(billPrintHeaderDescriptionsLookupFieldName, getCustomerPaymentHeaderLookupValue()).getEntity();
		pledgePaymentHeaderLookupValue = new LookupValue_Id(billPrintHeaderDescriptionsLookupFieldName, getPledgePaymentHeaderLookupValue()).getEntity();
		remitToCharType = getRemitToCharType();
		defaultRemitTo = getDefaultRemitTo();
		btuFactorSQI = getBtuFactorSQI();
		rateClassDescriptionCharType = getRateClassDescriptionCharType();
		utilityChargesHeadersCharType = getUtilityChargesHeadersCharType();
		taxingCommunityPremiseCharType = getTaxingCommunityPremiseCharType();
		taxingCommunityBillLineCharType = getTaxingCommunityBillLineCharType();
		grossAmountCharType = getGrossAmountCharType();
		latePaymentAdjustmentCharType = getLatePaymentAdjustmentCharType();
		pledgePaymentCharType = getPledgePaymentCharType();
		serviceTypeforMetered = getServiceTypeforMetered();
		serviceTypeforUnmetered = getServiceTypeforUnmetered();
		dollarHelpSACharType = getDollarHelpSACharType();
		billCalcLinePriorityCharType = getBillCalcLinePriorityCharType();
		additionalHistogramUOMSATypeCharType = getAdditionalHistogramUOMSATypeCharType();
		additionalHistogramSQISATypeCharType = getAdditionalHistogramSQISATypeCharType();
		contractNumberSACharType = getContractNumberSACharType();
		propaneBillableUOM = getPropaneBillableUOM();
		schoolAggregationAccountCharType = getSchoolAggregationAccountCharType();
		schoolAggregationAccountCharValue = getSchoolAggregationAccountCharValue();
		budgetPaymentArrangementCharType = getBudgetPaymentArrangementCharType();
		rateClassCharacteristicType = getRateClassCharacteristicType();

	}

	@Override
	public void invoke() {
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			if (notNull(bill)) {
				cmpbxblx.setBxzzxInputWrkBillId(bill.getId().getTrimmedValue());
			}else{
				cmpbxblx.setBxzzxInputWrkBillId(CobolCode.SPACES.toString());
			}
			if (notNull(sequenceNumber)) {
				cmpbxblx.setInputWrkSeqno(java.math.BigDecimal.valueOf(sequenceNumber.doubleValue()));
			}else{
				cmpbxblx.setInputWrkSeqno(java.math.BigDecimal.ZERO);
			}
			if (notNull(numberOfCopies)) {
				cmpbxblx.setCopyCnt(java.math.BigDecimal.valueOf(numberOfCopies.doubleValue()));
			}else{
				cmpbxblx.setCopyCnt(java.math.BigDecimal.ZERO);
			}
			if (notBlank(extractFileName)) {
				cmpbxblx.setInputWrkExtractFileName(extractFileName);
			}else{
				cmpbxblx.setInputWrkExtractFileName(CobolCode.SPACES.toString());
			}
			if (notNull(toBill)) {
				cmpbxblx.setToBillId(toBill.getId().getTrimmedValue());
			}else{
				cmpbxblx.setToBillId(CobolCode.SPACES.toString());
			}
			if (notNull(batchControl)) {
				cmpbxblx.setInputWrkBatchCd(batchControl.getId().getTrimmedValue());
			}else{
				cmpbxblx.setInputWrkBatchCd(CobolCode.SPACES.toString());
			}
			if (notNull(batchNumber)) {
				cmpbxblx.setInputWrkBatchNbr(java.math.BigDecimal.valueOf(batchNumber.doubleValue()));
			}else{
				cmpbxblx.setInputWrkBatchNbr(java.math.BigDecimal.ZERO);
			}
			if (notNull(extractAlgorithm)) {
				cmpbxblx.setExtractAlgCd(extractAlgorithm.getId().getTrimmedValue());
			}else{
				cmpbxblx.setExtractAlgCd(CobolCode.SPACES.toString());
			}
			
			
			// set cobol program's soft parameters
			String validateParameterSwitchStr = (validateParameterSwitch.isTrue()) ? SWITCH_YES : SWITCH_NO;
			cmpbxblx.setAlgParmVal(1, validateParameterSwitchStr); 
			
			cmpbxblx.setAlgParmVal(2, billPrintHeaderDescriptionsLookupFieldName.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(3, billCorrectionPeriodHeaderLookupValue.getId().getFieldValue()); 
			cmpbxblx.setAlgParmVal(4, otherChargesHeaderLookupValue.getId().getFieldValue());
			cmpbxblx.setAlgParmVal(5, customerPaymentHeaderLookupValue.getId().getFieldValue()); 
			cmpbxblx.setAlgParmVal(6, pledgePaymentHeaderLookupValue.getId().getFieldValue()); 
			cmpbxblx.setAlgParmVal(7, remitToCharType.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(8, defaultRemitTo.trim());
			cmpbxblx.setAlgParmVal(9, btuFactorSQI.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(10, rateClassDescriptionCharType.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(11, utilityChargesHeadersCharType.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(12, taxingCommunityPremiseCharType.getId().getTrimmedValue());
			cmpbxblx.setAlgParmVal(13, taxingCommunityBillLineCharType.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(14, grossAmountCharType.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(15, latePaymentAdjustmentCharType.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(16, pledgePaymentCharType.getId().getTrimmedValue());
			cmpbxblx.setAlgParmVal(17, serviceTypeforMetered.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(18, serviceTypeforUnmetered.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(19, dollarHelpSACharType.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(20, billCalcLinePriorityCharType.getId().getTrimmedValue());
			cmpbxblx.setAlgParmVal(21, additionalHistogramUOMSATypeCharType.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(22, additionalHistogramSQISATypeCharType.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(23, contractNumberSACharType.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(24, propaneBillableUOM.getId().getTrimmedValue());
			cmpbxblx.setAlgParmVal(25, schoolAggregationAccountCharType.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(26, schoolAggregationAccountCharValue.trim()); 
			cmpbxblx.setAlgParmVal(27, budgetPaymentArrangementCharType.getId().getTrimmedValue()); 
			cmpbxblx.setAlgParmVal(28, rateClassCharacteristicType.getId().getTrimmedValue());
			
			// invoke the main method
		    cmpbxblx.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
		    
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmpbxblx.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmpbxblx.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmpbxblx.getParmCollMessageParm(i);
			    			if (notBlank(cmpbxblx.getParmCollMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmpbxblx.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmpbxblx.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmpbxblx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmpbxblx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    	isBillSkipped = (cmpbxblx.getSkipBillSw() == SWITCH_YES) ? Bool.TRUE : Bool.FALSE;
		    	reportDefinition = new ReportDefinition_Id(cmpbxblx.getReportCd().trim()).getEntity();
		    	returnCode = BigInteger.valueOf(cmpbxblx.getOutCode().longValue());
		    	
		    }
		    else {
		        ex.printStackTrace();
		          
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmpbxblx=Session.returnSessionAndCodeToCache(cmpbxblx);
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//            try {
//                connection.close();
//            } catch (SQLException e) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
//            }
         // end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}

	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
		FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
		RequestContext context = session.getRequestContext();
		
		// start update - equint - 2025-11-14 - CCB25.4 Upgrade
		session.doWork(new ConnectionWork() {
			
			@Override
			public void execute(Connection connection) throws SQLException {
				try {
					String username = connection.getMetaData().getUserName();
					String url = connection.getMetaData().getURL();
					
					CobolSession.setLogSessionStartEnd(false);
				    cmpbxblx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpbxblx.class);
					
					cmpbxblx.getSession().getDbSession().setUpdateConnection(connection);
					cmpbxblx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
					
					// set ZSTAT parameters

					cmpbxblx.setProcessDt(getProcessDateTime().getDate().toString());
					cmpbxblx.setProcessDttmSep("-");
					cmpbxblx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
					
					if (session.isOnlineConnection()) { 
						cmpbxblx.setConnectionFlg(CONNECTION_ONLINE);
					}
					else {
						cmpbxblx.setConnectionFlg(CONNECTION_BATCH);
					}
					
					cmpbxblx.setUserId(context.getUserId());
					cmpbxblx.setZstatLanguageCd(context.getLanguageCode());
			        
			        if (context.ignoreWarnings()) {
			        	cmpbxblx.setIgnoreWarningSw(SWITCH_YES);
			        }
			        else {
			        	cmpbxblx.setIgnoreWarningSw(SWITCH_NO);
			        }
			        
			        if (session.getBatchInstanceId() != null) {
			        	cmpbxblx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
			        	
					} else {
						cmpbxblx.setSchedulerId(new BigDecimal(0).toBigDecimal());
					}
			        
			        cmpbxblx.setAppSvcId(context.getSecurityServiceIdContext());
			        
			        DatabaseHelper dbHelper = session.getDatabaseHelper();
			        cmpbxblx.setDbMode(dbHelper.getCobolDBMode());
			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
			        //cmpbxblx.setSplHighValue(cmpbxblx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
			        //cmpbxblx.setSplLowValue(cmpbxblx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
			        
			        cmpbxblx.setSplHighValue(cmpbxblx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
			        cmpbxblx.setSplLowValue(cmpbxblx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
			        
			        cmpbxblx.setEnvInfoEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
			        
			        cmpbxblx.setLkExpiryDt(Date.MAX.toString());
					
			        cmpbxblx.setProgramStatus(" ");
			        
			        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
			        cmpbxblx.setCallSeq(";");
			        cmpbxblx.setMessageAreaProgramName("CMPBXBLX");
			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
			        
			        if (context.getRandomGeneratorSeedSet().isTrue()) {
			        	cmpbxblx.setRandomGenSeedSw(SWITCH_YES);
			        	cmpbxblx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
			        	cmpbxblx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
			        	cmpbxblx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
			        	cmpbxblx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
			        }
			        else {
			        	cmpbxblx.setRandomGenSeedSw(SWITCH_NO);
			        }
			        
			        if (context.traceStandardOut()) { 
			        	cmpbxblx.setTrcStdoutSw(SWITCH_YES);
			        }
			        else {
			        	cmpbxblx.setTrcStdoutSw(SWITCH_NO);
			        }
			        
			        if (context.traceProgramStart()) { 
			        	cmpbxblx.setTrcProgStartSw(SWITCH_YES);
			        }
			        else {
			        	cmpbxblx.setTrcProgStartSw(SWITCH_NO);
			        }
			        
			        if (context.traceProgramExit()) { 
			        	cmpbxblx.setTrcProgExitSw(SWITCH_YES);
			        }
			        else {
			        	cmpbxblx.setTrcProgExitSw(SWITCH_NO);
			        }
			        
			        if (context.traceSQL()) { 
			        	cmpbxblx.setTrcExecSqlSw(SWITCH_YES);
			        }
			        else {
			        	cmpbxblx.setTrcExecSqlSw(SWITCH_NO);
			        }
			        
			        // Set ZMSGN parms
			        BigInteger messageSequence = session.getMessageSequence();
			        if (notNull(messageSequence)) {
			        	cmpbxblx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
			        }
			        else {
			        	cmpbxblx.setMessageSeq(new BigDecimal(0).toBigDecimal());
			        }
				}
				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		 
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//		connection = implementor.getConnectionProvider().getConnection();
//		
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmpbxblx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpbxblx.class);
//		
//		cmpbxblx.getSession().getDbSession().setUpdateConnection(connection);
//		cmpbxblx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		
//		// set ZSTAT parameters
//
//		cmpbxblx.setProcessDt(getProcessDateTime().getDate().toString());
//		cmpbxblx.setProcessDttmSep("-");
//		cmpbxblx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmpbxblx.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmpbxblx.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmpbxblx.setUserId(context.getUserId());
//		cmpbxblx.setZstatLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmpbxblx.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmpbxblx.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmpbxblx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmpbxblx.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmpbxblx.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmpbxblx.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmpbxblx.setSplHighValue(cmpbxblx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmpbxblx.setSplLowValue(cmpbxblx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmpbxblx.setSplHighValue(cmpbxblx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmpbxblx.setSplLowValue(cmpbxblx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmpbxblx.setEnvInfoEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmpbxblx.setLkExpiryDt(Date.MAX.toString());
//		
//        cmpbxblx.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmpbxblx.setCallSeq(";");
//        cmpbxblx.setMessageAreaProgramName("CMPBXBLX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmpbxblx.setRandomGenSeedSw(SWITCH_YES);
//        	cmpbxblx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmpbxblx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmpbxblx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmpbxblx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmpbxblx.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmpbxblx.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmpbxblx.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmpbxblx.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmpbxblx.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmpbxblx.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmpbxblx.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmpbxblx.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmpbxblx.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmpbxblx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmpbxblx.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }
		
		// end update - equint - 2025-11-14 - CCB25.4 Upgrade

	}

}
