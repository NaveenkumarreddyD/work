/*******************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * Metering Exception Case - Evaluate Inbound Characteristics
 *
 * This algorithm will perform the evaluation of the "inbound" Characteristics and 
 * make the appropriate changes to the "permanent" Characteristics on the Case. 
 * Once this evaluation is complete, the algorithm will delete the "inbound" 
 * Characteristics. 
 * 
 * Once this is complete, the "permanent" Characteristics will be evaluated to 
 * determine whether the "main" Characteristics should be updated with the information.  
 * The "main" characteristics are used to drive the lifecycle of the Case. 
 * In the event that the "main" exception code Characteristic on the Case is updated, 
 * this algorithm will transition the Case to the "New Exception" status (supplied
 * as parameter to this algorithm). 
 *
 ********************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-04-26   SMiranda        NI0007.5. Initial Version.    
 * 2016-01-22   MPang			Updated for CCB v2.4 compilation.                          
 ********************************************************************************/
package com.splwg.cm.domain.admin.caseType;

import java.math.BigInteger;
import java.util.List;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.lookup.LookupField_Id;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.CaseLogTypeLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseTypeExitStatusAlgorithmSpot;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameter_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameter_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseLog_DTO;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;*/

import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.algorithm.exitStatus.ExitStatusAlgorithmSpot;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameter_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameter_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.cm.domain.customMessages.CustomMessagesMDC;
import com.splwg.shared.common.StringUtilities;

/**
 * @author smiranda
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForInboundCorrectedExceptionCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundCorrectedExceptionRequestDate)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundCorrectedExceptionRequester)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundCorrectedExceptionStatus)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundCorrectedExceptionStatusDate)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundUncorrectedExceptionCode)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundUncorrectedExceptionRequestDate)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundUncorrectedExceptionRequester)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundUncorrectedExceptionStatus)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundUncorrectedExceptionStatusDate)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForCorrectedExceptionCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForCorrectedExceptionRequestDate, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForCorrectedExceptionRequester, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForCorrectedExceptionStatus, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForCorrectedExceptionStatusDate, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForUncorrectedExceptionCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForUncorrectedExceptionRequestDate)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForUncorrectedExceptionRequester, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForUncorrectedExceptionStatus, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForUncorrectedExceptionStatusDate)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForMainExceptionCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForMainExceptionRequestDate, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForMainExceptionRequester, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForMainExceptionStatus, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForMainExceptionStatusDate, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = exceptionCodeFeatureConfigurationType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = exceptionPriorityFeatureConfigurationOptionType, required = true, type = string)})
 */
public class CmEvaluateInboundCharsExitStatusAlgComp_Impl extends
        CmEvaluateInboundCharsExitStatusAlgComp_Gen implements
        //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
        //CaseTypeExitStatusAlgorithmSpot {
        ExitStatusAlgorithmSpot {
	   //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
    
    // Constants
    private final String _OPT_TYP_FLG = "_OPT_TYP_FLG";
    private final String CASE_LOG_ADD = "ADD";
    private final String CASE_LOG_UPDATE = "UPDATE";
    private final String CASE_LOG_DELETE = "DELETE";
    private final MessageCategory_Id MESSAGE_CAT = new MessageCategory_Id(BigInteger.valueOf(CustomMessagesMDC.MESSAGE_CATEGORY));
    private final BigInteger CASE_CHAR_ADDED_MSG_NUM = BigInteger.valueOf(CustomMessageRepositoryMDC.NI0007_5_1_CASE_CHAR_ADDED);
    private final BigInteger CASE_CHAR_UPDATED_MSG_NUM = BigInteger.valueOf(CustomMessageRepositoryMDC.NI0007_5_1_CASE_CHAR_UPDATED);
    private final BigInteger CASE_CHAR_DELETED_MSG_NUM = BigInteger.valueOf(CustomMessageRepositoryMDC.NI0007_5_1_CASE_CHAR_DELETED);
    
    // Variables for Hard Parameters
    private ToDoCase toDoCase;
    
    // Variables for Soft Parameters
    private CharacteristicType inboundCorrectedExceptionCodeCharType,
            inboundCorrectedExceptionRequestDateCharType,
            inboundCorrectedExceptionRequesterCharType,
            inboundCorrectedExceptionStatusCharType,
            inboundCorrectedExceptionStatusDateCharType,
            inboundUncorrectedExceptionCodeCharType,
            inboundUncorrectedExceptionRequestDateCharType,
            inboundUncorrectedExceptionRequesterCharType,
            inboundUncorrectedExceptionStatusCharType,
            inboundUncorrectedExceptionStatusDateCharType,
            permanentCorrectedExceptionCodeCharType,
            permanentCorrectedExceptionRequestDateCharType,
            permanentCorrectedExceptionRequesterCharType,
            permanentCorrectedExceptionStatusCharType,
            permanentCorrectedExceptionStatusDateCharType,
            permanentUncorrectedExceptionCodeCharType,
            permanentUncorrectedExceptionRequestDateCharType,
            permanentUncorrectedExceptionRequesterCharType,
            permanentUncorrectedExceptionStatusCharType,
            permanentUncorrectedExceptionStatusDateCharType,
            mainExceptionCodeCharType,
            mainExceptionRequestDateCharType,
            mainExceptionRequesterCharType,
            mainExceptionStatusCharType,
            mainExceptionStatusDateCharType;
    private FeatureConfiguration exceptionCodeFeatureConfigurationType;
    private String exceptionPriorityFeatureConfigurationOptionType;
    
    // Other work variables
    private String algCodeStr;    
    private Bool permanentExceptionCodeUpdatedSw,
            mainExceptionCodeUpdatedSw,
            mainExceptionRequestDateUpdatedSw,
            mainExceptionRequesterUpdatedSw,
            mainExceptionStatusDateUpdatedSw,
            mainExceptionStatusUpdatedSw;            
    
    private SQLResultRow caseCharSQLResult = null;
    
    private String inboundCorrectedExceptionCode = "",
            permanentCorrectedExceptionCode = "",
            inboundCorrectedExceptionRequestDate = "",
            permanentCorrectedExceptionRequestDate = "",
            inboundCorrectedExceptionRequester = "",
            permanentCorrectedExceptionRequester = "",
            inboundCorrectedExceptionStatus = "",
            permanentCorrectedExceptionStatus = "",
            inboundCorrectedExceptionStatusDate = "",
            permanentCorrectedExceptionStatusDate = "",
            // Uncorrected
            inboundUncorrectedExceptionCode = "",
            permanentUncorrectedExceptionCode = "",
            inboundUncorrectedExceptionRequestDate = "",
            permanentUncorrectedExceptionRequestDate = "",
            inboundUncorrectedExceptionRequester = "",
            permanentUncorrectedExceptionRequester = "",
            inboundUncorrectedExceptionStatus = "",
            permanentUncorrectedExceptionStatus = "",
            inboundUncorrectedExceptionStatusDate = "",
            permanentUncorrectedExceptionStatusDate = "",
            // Main
            mainExceptionCode = "",
            mainExceptionRequestDate = "",
            mainExceptionRequester = "",
            mainExceptionStatus = "",
            mainExceptionStatusDate = "",
            origMainExceptionCode = "",
            origMainExceptionRequestDate = "",
            origMainExceptionRequester = "",
            origMainExceptionStatus = "",
            origMainExceptionStatusDate = "";
    private BigInteger inboundCorrectedExceptionCodeSeq = BigInteger.ZERO,
            inboundCorrectedExceptionCodePriority = BigInteger.valueOf(-1),
            permanentCorrectedExceptionCodeSeq = BigInteger.ZERO,
            permanentCorrectedExceptionCodePriority = BigInteger.valueOf(-1),
            inboundCorrectedExceptionRequestDateSeq = BigInteger.ZERO,
            permanentCorrectedExceptionRequestDateSeq = BigInteger.ZERO,
            inboundCorrectedExceptionRequesterSeq = BigInteger.ZERO,
            permanentCorrectedExceptionRequesterSeq = BigInteger.ZERO,
            inboundCorrectedExceptionStatusSeq = BigInteger.ZERO,
            permanentCorrectedExceptionStatusSeq = BigInteger.ZERO,
            inboundCorrectedExceptionStatusDateSeq = BigInteger.ZERO,
            permanentCorrectedExceptionStatusDateSeq = BigInteger.ZERO,
            // Uncorrected
            inboundUncorrectedExceptionCodeSeq = BigInteger.ZERO,
            inboundUncorrectedExceptionCodePriority = BigInteger.valueOf(-1),
            permanentUncorrectedExceptionCodeSeq = BigInteger.ZERO,
            permanentUncorrectedExceptionCodePriority = BigInteger.valueOf(-1),
            inboundUncorrectedExceptionRequestDateSeq = BigInteger.ZERO,
            permanentUncorrectedExceptionRequestDateSeq = BigInteger.ZERO,
            inboundUncorrectedExceptionRequesterSeq = BigInteger.ZERO,
            permanentUncorrectedExceptionRequesterSeq = BigInteger.ZERO,
            inboundUncorrectedExceptionStatusSeq = BigInteger.ZERO,
            permanentUncorrectedExceptionStatusSeq = BigInteger.ZERO,
            inboundUncorrectedExceptionStatusDateSeq = BigInteger.ZERO,
            permanentUncorrectedExceptionStatusDateSeq = BigInteger.ZERO,
            // Main
            mainExceptionCodeSeq = BigInteger.ZERO,
            mainExceptionCodePriority = BigInteger.valueOf(-1),
            mainExceptionRequestDateSeq = BigInteger.ZERO,
            mainExceptionRequesterSeq = BigInteger.ZERO,
            mainExceptionStatusSeq = BigInteger.ZERO,
            mainExceptionStatusDateSeq = BigInteger.ZERO;          

    public String getNextCaseStatus() {
        return null;
    }

    public String getNextTransCondition() {
        return null;
    }

    public Bool getShouldAutoTransition() {
        return null;
    }

    public void setCaseOriginalStatus(CaseStatus arg0) {
        
    }

    public void setNextCaseStatus(CaseStatus arg0) {
        
    }
    
    public void setCase(ToDoCase arg0) {
        // Get Case
        toDoCase = arg0;
    }

    public void invoke() {           
        
        // Set the following variables to FALSE
        permanentExceptionCodeUpdatedSw = Bool.FALSE;
        
        // Evaluate Inbound Corrected Characteristics and update the Permanent Corrected Characteristics as needed
        evaluateInboundCorrectedCharacteristics();   
        
        // Evaluate Inbound Uncorrected Characteristics and update the Permanent Uncorrected Characteristics as needed
        evaluateInboundUncorrectedCharacteristics();
        
        if (permanentExceptionCodeUpdatedSw.isTrue()){
            
            // Set the following variables to FALSE
            mainExceptionCodeUpdatedSw = Bool.FALSE;
            mainExceptionRequestDateUpdatedSw = Bool.FALSE;
            mainExceptionRequesterUpdatedSw = Bool.FALSE;
            mainExceptionStatusDateUpdatedSw = Bool.FALSE;
            mainExceptionStatusUpdatedSw = Bool.FALSE;
            
            // Evaluate Permanent Corrected Characteristics and update the Main Characteristics as needed
            evaluatePermanentCorrectedCharacteristics();
        
            // Evaluate Permanent Uncorrected Characteristics and update the Main Characteristics as needed
            evaluatePermanentUncorrectedCharacteristics();
            
            // Create or Update Main Characteristics
            createOrUpdateMainCharacteristics(); 
            
        }
    }

    private void evaluateInboundCorrectedCharacteristics(){      
        
        // Get Inbound Corrected Characteristics
        getInboundCorrectedCharacteristics();
        
        // Get Permanent Corrected Characteristics
        getPermanentCorrectedCharacteristics();               
        
        /* 
         * If there is no Permanent Corrected Exception Code Characteristic, or if the Inbound Corrected Exception Code 
         * has a higher priority than the Permanent Corrected Exception Code, create or update the Permanent Characteristics.
         */
        if (permanentCorrectedExceptionCode == ""
                || (inboundCorrectedExceptionCodePriority.intValue() != -1 && 
                        (inboundCorrectedExceptionCodePriority.intValue() < permanentCorrectedExceptionCodePriority.intValue()))){
            
            // Create or Update Permanent Corrected Exception Code
            if (inboundCorrectedExceptionCode != ""){
                createOrUpdatePermChar(inboundCorrectedExceptionCode,
                        permanentCorrectedExceptionCodeCharType,
                        permanentCorrectedExceptionCodeSeq,
                        permanentCorrectedExceptionCode);
                permanentCorrectedExceptionCode = inboundCorrectedExceptionCode;
                permanentCorrectedExceptionCodePriority = inboundCorrectedExceptionCodePriority;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }                        
            
            // Create or update Permanent Corrected Exception Request Date characteristic             
            if (inboundCorrectedExceptionRequestDate != ""){                                
                createOrUpdatePermChar(inboundCorrectedExceptionRequestDate,
                        permanentCorrectedExceptionRequestDateCharType,
                        permanentCorrectedExceptionRequestDateSeq,
                        permanentCorrectedExceptionRequestDate);
                permanentCorrectedExceptionRequestDate = inboundCorrectedExceptionRequestDate;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }                        
                         
            // Create or update Permanent Corrected Exception Requester characteristic             
            if (inboundCorrectedExceptionRequester != ""){                                
                createOrUpdatePermChar(inboundCorrectedExceptionRequester,
                        permanentCorrectedExceptionRequesterCharType,
                        permanentCorrectedExceptionRequesterSeq,
                        permanentCorrectedExceptionRequester);
                permanentCorrectedExceptionRequester = inboundCorrectedExceptionRequester;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }                      
            
             
            // Create or update Permanent Corrected Exception Status characteristic             
            if (inboundCorrectedExceptionStatus != ""){                                
                createOrUpdatePermChar(inboundCorrectedExceptionStatus,
                        permanentCorrectedExceptionStatusCharType,
                        permanentCorrectedExceptionStatusSeq,
                        permanentCorrectedExceptionStatus);
                permanentCorrectedExceptionStatus = inboundCorrectedExceptionStatus;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }                       
                         
            // Create or update Permanent Corrected Exception Status Date characteristic             
            if (inboundCorrectedExceptionStatusDate != ""){                                
                createOrUpdatePermChar(inboundCorrectedExceptionStatusDate,
                        permanentCorrectedExceptionStatusDateCharType,
                        permanentCorrectedExceptionStatusDateSeq,
                        permanentCorrectedExceptionStatusDate);
                permanentCorrectedExceptionStatusDate = inboundCorrectedExceptionStatusDate;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }                                    
        }
        
        // Delete the Inbound Corrected Exception Code Characteristic
        if (inboundCorrectedExceptionCode != ""){
            deleteCaseChar(inboundCorrectedExceptionCodeCharType, 
                    inboundCorrectedExceptionCodeSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedExceptionCodeCharType, 
                    inboundCorrectedExceptionCodeSeq, 
                    inboundCorrectedExceptionCode, 
                    CASE_LOG_DELETE); 
        }
        
        // Delete the Inbound Corrected Exception Request Date Characteristic
        if (inboundCorrectedExceptionRequestDate != ""){
            deleteCaseChar(inboundCorrectedExceptionRequestDateCharType, 
                    inboundCorrectedExceptionRequestDateSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedExceptionRequestDateCharType, 
                    inboundCorrectedExceptionRequestDateSeq, 
                    inboundCorrectedExceptionRequestDate, 
                    CASE_LOG_DELETE); 
        }
        
        // Delete the Inbound Corrected Exception Requester Characteristic
        if (inboundCorrectedExceptionRequester != ""){
            deleteCaseChar(inboundCorrectedExceptionRequesterCharType, 
                    inboundCorrectedExceptionRequesterSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedExceptionRequesterCharType, 
                    inboundCorrectedExceptionRequesterSeq, 
                    inboundCorrectedExceptionRequester, 
                    CASE_LOG_DELETE); 
        }
        
        // Delete the Inbound Corrected Exception Status Characteristic
        if (inboundCorrectedExceptionStatus != ""){
            deleteCaseChar(inboundCorrectedExceptionStatusCharType, 
                    inboundCorrectedExceptionStatusSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedExceptionStatusCharType, 
                    inboundCorrectedExceptionStatusSeq, 
                    inboundCorrectedExceptionStatus, 
                    CASE_LOG_DELETE); 
        }

        // Delete the Inbound Corrected Exception Status Date Characteristic
        if (inboundCorrectedExceptionStatusDate != ""){
            deleteCaseChar(inboundCorrectedExceptionStatusDateCharType, 
                    inboundCorrectedExceptionStatusDateSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedExceptionStatusDateCharType, 
                    inboundCorrectedExceptionStatusDateSeq, 
                    inboundCorrectedExceptionStatusDate, 
                    CASE_LOG_DELETE); 
        }
        
    }    

    private void getInboundCorrectedCharacteristics() {

        // Determine whether an Inbound Corrected Exception Code Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedExceptionCodeCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedExceptionCode = caseCharSQLResult.getString("CHARVAL");
            inboundCorrectedExceptionCodeSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }    
        
        // If so, retrieve the exception priority using Feature Configuration for the exception code.
        if (inboundCorrectedExceptionCode != ""){
            inboundCorrectedExceptionCodePriority = getExceptionPriority(inboundCorrectedExceptionCode);                    
        }
        
        // Determine whether an Inbound Corrected Exception Request Date Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedExceptionRequestDateCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedExceptionRequestDate = caseCharSQLResult.getString("CHARVAL");
            inboundCorrectedExceptionRequestDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
        // Determine whether an Inbound Corrected Exception Requester Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedExceptionRequesterCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedExceptionRequester = caseCharSQLResult.getString("CHARVAL");
            inboundCorrectedExceptionRequesterSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
        // Determine whether an Inbound Corrected Exception Status Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            inboundCorrectedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
        // Determine whether an Inbound Corrected Exception Status Date Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            inboundCorrectedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
    }
    
    private void getPermanentCorrectedCharacteristics() {

        // Determine whether a Permanent Corrected Exception Code Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentCorrectedExceptionCodeCharType);
        if (notNull(caseCharSQLResult)){
            permanentCorrectedExceptionCode = caseCharSQLResult.getString("CHARVAL");
            permanentCorrectedExceptionCodeSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
        // If so, retrieve the exception priority using Feature Configuration for the exception code.
        if (permanentCorrectedExceptionCode != ""){
            permanentCorrectedExceptionCodePriority = getExceptionPriority(permanentCorrectedExceptionCode);                    
        }
        
        // Determine whether a Permanent Corrected Exception Request Date Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentCorrectedExceptionRequestDateCharType);
        if (notNull(caseCharSQLResult)){
            permanentCorrectedExceptionRequestDate = caseCharSQLResult.getString("CHARVAL");
            permanentCorrectedExceptionRequestDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
        // Determine whether a Permanent Corrected Exception Requester Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentCorrectedExceptionRequesterCharType);
        if (notNull(caseCharSQLResult)){
            permanentCorrectedExceptionRequester = caseCharSQLResult.getString("CHARVAL");
            permanentCorrectedExceptionRequesterSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
        // Determine whether a Permanent Corrected Exception Status Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentCorrectedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            permanentCorrectedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            permanentCorrectedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
        // Determine whether a Permanent Corrected Exception Status Date Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentCorrectedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            permanentCorrectedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            permanentCorrectedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
    }

    private void evaluateInboundUncorrectedCharacteristics(){    
        
        // Get Inbound Uncorrected Characteristics
        getInboundUncorrectedCharacteristics();
        
        // Get Permanent Uncorrected Characteristics
        getPermanentUncorrectedCharacteristics();        
        
        /* 
         * If there is no Permanent Uncorrected Exception Code Characteristic, or if the Inbound Uncorrected Exception Code 
         * has a higher priority than the Permanent Uncorrected Exception Code, create or update the Permanent Characteristics.
         */
        if (permanentUncorrectedExceptionCode == ""
                || (inboundUncorrectedExceptionCodePriority.intValue() != -1 && 
                        (inboundUncorrectedExceptionCodePriority.intValue() < permanentUncorrectedExceptionCodePriority.intValue()))){
            
            // Create or Update Permanent Uncorrected Exception Code
            if (inboundUncorrectedExceptionCode != ""){
                createOrUpdatePermChar(inboundUncorrectedExceptionCode,
                        permanentUncorrectedExceptionCodeCharType,
                        permanentUncorrectedExceptionCodeSeq,
                        permanentUncorrectedExceptionCode);
                permanentUncorrectedExceptionCode = inboundUncorrectedExceptionCode;
                permanentUncorrectedExceptionCodePriority = inboundUncorrectedExceptionCodePriority;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }            
            
            /* 
             * If Inbound Uncorrected Exception Request Date Characteristic exists, 
             * create or update Permanent Uncorrected Exception Request Date characteristic
             */
            if (inboundUncorrectedExceptionRequestDate != ""){                                
                createOrUpdatePermChar(inboundUncorrectedExceptionRequestDate,
                        permanentUncorrectedExceptionRequestDateCharType,
                        permanentUncorrectedExceptionRequestDateSeq,
                        permanentUncorrectedExceptionRequestDate);
                permanentUncorrectedExceptionRequestDate = inboundUncorrectedExceptionRequestDate;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }            
            
            /* 
             * If Inbound Uncorrected Exception Requester Characteristic exists, 
             * create or update Permanent Uncorrected Exception Requester characteristic
             */
            if (inboundUncorrectedExceptionRequester != ""){                                
                createOrUpdatePermChar(inboundUncorrectedExceptionRequester,
                        permanentUncorrectedExceptionRequesterCharType,
                        permanentUncorrectedExceptionRequesterSeq,
                        permanentUncorrectedExceptionRequester);
                permanentUncorrectedExceptionRequester = inboundUncorrectedExceptionRequester;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }            
            
            /* 
             * If Inbound Uncorrected Exception Status Characteristic exists, 
             * create or update Permanent Uncorrected Exception Status characteristic
             */
            if (inboundUncorrectedExceptionStatus != ""){                                
                createOrUpdatePermChar(inboundUncorrectedExceptionStatus,
                        permanentUncorrectedExceptionStatusCharType,
                        permanentUncorrectedExceptionStatusSeq,
                        permanentUncorrectedExceptionStatus);
                permanentUncorrectedExceptionStatus = inboundUncorrectedExceptionStatus;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }            
            
            /* 
             * If Inbound Uncorrected Exception Status Date Characteristic exists, 
             * create or update Permanent Uncorrected Exception Status Date characteristic
             */
            if (inboundUncorrectedExceptionStatusDate != ""){                                
                createOrUpdatePermChar(inboundUncorrectedExceptionStatusDate,
                        permanentUncorrectedExceptionStatusDateCharType,
                        permanentUncorrectedExceptionStatusDateSeq,
                        permanentUncorrectedExceptionStatusDate);
                permanentUncorrectedExceptionStatusDate = inboundUncorrectedExceptionStatusDate;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }                    
                        
        }
        
        // Delete the Inbound Uncorrected Exception Code Characteristic
        if (inboundUncorrectedExceptionCode != ""){
            deleteCaseChar(inboundUncorrectedExceptionCodeCharType, 
                    inboundUncorrectedExceptionCodeSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedExceptionCodeCharType, 
                    inboundUncorrectedExceptionCodeSeq, 
                    inboundUncorrectedExceptionCode, 
                    CASE_LOG_DELETE); 
        }
        
        // Delete the Inbound Uncorrected Exception Request Date Characteristic
        if (inboundUncorrectedExceptionRequestDate != ""){
            deleteCaseChar(inboundUncorrectedExceptionRequestDateCharType, 
                    inboundUncorrectedExceptionRequestDateSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedExceptionRequestDateCharType, 
                    inboundUncorrectedExceptionRequestDateSeq, 
                    inboundUncorrectedExceptionRequestDate, 
                    CASE_LOG_DELETE); 
        }
        
        // Delete the Inbound Uncorrected Exception Requester Characteristic
        if (inboundUncorrectedExceptionRequester != ""){
            deleteCaseChar(inboundUncorrectedExceptionRequesterCharType, 
                    inboundUncorrectedExceptionRequesterSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedExceptionRequesterCharType, 
                    inboundUncorrectedExceptionRequesterSeq, 
                    inboundUncorrectedExceptionRequester, 
                    CASE_LOG_DELETE); 
        }
        
        // Delete the Inbound Uncorrected Exception Status Characteristic
        if (inboundUncorrectedExceptionStatus != ""){
            deleteCaseChar(inboundUncorrectedExceptionStatusCharType, 
                    inboundUncorrectedExceptionStatusSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedExceptionStatusCharType, 
                    inboundUncorrectedExceptionStatusSeq, 
                    inboundUncorrectedExceptionStatus, 
                    CASE_LOG_DELETE); 
        }

        // Delete the Inbound Uncorrected Exception Status Date Characteristic
        if (inboundUncorrectedExceptionStatusDate != ""){
            deleteCaseChar(inboundUncorrectedExceptionStatusDateCharType, 
                    inboundUncorrectedExceptionStatusDateSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedExceptionStatusDateCharType, 
                    inboundUncorrectedExceptionStatusDateSeq, 
                    inboundUncorrectedExceptionStatusDate, 
                    CASE_LOG_DELETE); 
        }
        
    }
    
    private void getInboundUncorrectedCharacteristics() {

        // Determine whether an Inbound Uncorrected Exception Code Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedExceptionCodeCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedExceptionCode = caseCharSQLResult.getString("CHARVAL");
            inboundUncorrectedExceptionCodeSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }    
        
        // If so, retrieve the exception priority using Feature Configuration for the exception code.
        if (inboundUncorrectedExceptionCode != ""){
            inboundUncorrectedExceptionCodePriority = getExceptionPriority(inboundUncorrectedExceptionCode);                    
        }
        
        // Determine whether an Inbound Uncorrected Exception Request Date Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedExceptionRequestDateCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedExceptionRequestDate = caseCharSQLResult.getString("CHARVAL");
            inboundUncorrectedExceptionRequestDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
        // Determine whether an Inbound Uncorrected Exception Requester Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedExceptionRequesterCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedExceptionRequester = caseCharSQLResult.getString("CHARVAL");
            inboundUncorrectedExceptionRequesterSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
        // Determine whether an Inbound Uncorrected Exception Status Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            inboundUncorrectedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }       

        // Determine whether an Inbound Uncorrected Exception Status Date Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            inboundUncorrectedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }        
        
    }
    
    private void getPermanentUncorrectedCharacteristics() {

        // Determine whether a Permanent Uncorrected Exception Code Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentUncorrectedExceptionCodeCharType);
        if (notNull(caseCharSQLResult)){
            permanentUncorrectedExceptionCode = caseCharSQLResult.getString("CHARVAL");
            permanentUncorrectedExceptionCodeSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
        // If so, retrieve the exception priority using Feature Configuration for the exception code.
        if (permanentUncorrectedExceptionCode != ""){
            permanentUncorrectedExceptionCodePriority = getExceptionPriority(permanentUncorrectedExceptionCode);                    
        }
        
        // Determine whether a Permanent Uncorrected Exception Request Date Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentUncorrectedExceptionRequestDateCharType);
        if (notNull(caseCharSQLResult)){
            permanentUncorrectedExceptionRequestDate = caseCharSQLResult.getString("CHARVAL");
            permanentUncorrectedExceptionRequestDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
        // Determine whether a Permanent Uncorrected Exception Requester Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentUncorrectedExceptionRequesterCharType);
        if (notNull(caseCharSQLResult)){
            permanentUncorrectedExceptionRequester = caseCharSQLResult.getString("CHARVAL");
            permanentUncorrectedExceptionRequesterSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
        // Determine whether a Permanent Uncorrected Exception Status Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentUncorrectedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            permanentUncorrectedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            permanentUncorrectedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
        // Determine whether a Permanent Uncorrected Exception Status Date Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentUncorrectedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            permanentUncorrectedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            permanentUncorrectedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
    }

    private void evaluatePermanentCorrectedCharacteristics(){
        
        // Get Main characteristics
        getMainCharacteristics();  
        
        /* 
         * If there is no Main Exception Code Characteristic, or if the Permanent Corrected Exception Code 
         * has a higher priority than the Main Exception Code, create or update the Main Characteristics.
         */
        if (mainExceptionCode == ""
                || (permanentCorrectedExceptionCodePriority.intValue() != -1 && 
                        (permanentCorrectedExceptionCodePriority.intValue() < mainExceptionCodePriority.intValue()))){
                        
            // Create or Update the Main Exception Code
            if (permanentCorrectedExceptionCode != ""){               
                mainExceptionCode = permanentCorrectedExceptionCode;
                mainExceptionCodePriority = permanentCorrectedExceptionCodePriority;
                mainExceptionCodeUpdatedSw = Bool.TRUE; 
            }                      
                        
            // Create or Update the Main Exception Request Date
            if (permanentCorrectedExceptionRequestDate != ""){
                mainExceptionRequestDateUpdatedSw = Bool.TRUE;
                mainExceptionRequestDate = permanentCorrectedExceptionRequestDate;                
            }       
                        
            // Create or Update the Main Exception Requester
            if (permanentCorrectedExceptionRequester != ""){
                mainExceptionRequesterUpdatedSw = Bool.TRUE;
                mainExceptionRequester = permanentCorrectedExceptionRequester;
            }                        
            
            // Create or Update the Main Exception Status
            if (permanentCorrectedExceptionStatus != ""){
                mainExceptionStatusUpdatedSw = Bool.TRUE;
                mainExceptionStatus = permanentCorrectedExceptionStatus;
            }                                   

            // Create or Update the Main Exception Status Date
            if (permanentCorrectedExceptionStatusDate != ""){
                mainExceptionStatusDateUpdatedSw = Bool.TRUE;
                mainExceptionStatusDate = permanentCorrectedExceptionStatusDate;
            }
            
        }
        
    }

    private void getMainCharacteristics() {
        
        // Determine whether a Main Exception Code Characteristic exists.
        caseCharSQLResult = getCaseChar(mainExceptionCodeCharType);
        if (notNull(caseCharSQLResult)){
            mainExceptionCode = caseCharSQLResult.getString("CHARVAL");
            mainExceptionCodeSeq = caseCharSQLResult.getInteger("SEQNUM"); 
            origMainExceptionCode = mainExceptionCode;
        }
        
        // If so, retrieve the exception priority using Feature Configuration for the exception code.
        if (mainExceptionCode != ""){
            mainExceptionCodePriority = getExceptionPriority(mainExceptionCode);                    
        }
        
        // Determine whether a Main Exception Request Date Characteristic exists.
        caseCharSQLResult = getCaseChar(mainExceptionRequestDateCharType);
        if (notNull(caseCharSQLResult)){
            mainExceptionRequestDate = caseCharSQLResult.getString("CHARVAL");
            mainExceptionRequestDateSeq = caseCharSQLResult.getInteger("SEQNUM");    
            origMainExceptionRequestDate = mainExceptionRequestDate;
        }
        
        // Determine whether a Main Exception Requester Characteristic exists.
        caseCharSQLResult = getCaseChar(mainExceptionRequesterCharType);
        if (notNull(caseCharSQLResult)){
            mainExceptionRequester = caseCharSQLResult.getString("CHARVAL");
            mainExceptionRequesterSeq = caseCharSQLResult.getInteger("SEQNUM");
            origMainExceptionRequester = mainExceptionRequester;
        }
        
        // Determine whether a Main Exception Status Characteristic exists.
        caseCharSQLResult = getCaseChar(mainExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            mainExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            mainExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");   
            origMainExceptionStatus = mainExceptionStatus;
        }
        
        // Determine whether a Main Exception Status Date Characteristic exists.
        caseCharSQLResult = getCaseChar(mainExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            mainExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            mainExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");     
            origMainExceptionStatusDate = mainExceptionStatusDate;
        }        
        
    }
    
    private void evaluatePermanentUncorrectedCharacteristics(){
        /* 
         * If there is no Main Exception Code Characteristic, or if the Permanent Uncorrected Exception Code 
         * has a higher priority than the Main Exception Code, create or update the Main Characteristics.
         */
        if (mainExceptionCode == ""
                || (permanentUncorrectedExceptionCodePriority.intValue() != -1 && 
                        (permanentUncorrectedExceptionCodePriority.intValue() < mainExceptionCodePriority.intValue()))){
            
            // Create or Update the Main Exception Code
            if (permanentUncorrectedExceptionCode != ""){
                mainExceptionCode = permanentUncorrectedExceptionCode;
                mainExceptionCodeUpdatedSw = Bool.TRUE;
            }                       
            
            // Create or Update the Main Exception Request Date
            if (permanentUncorrectedExceptionRequestDate != ""){
                mainExceptionRequestDateUpdatedSw = Bool.TRUE;
                mainExceptionRequestDate = permanentUncorrectedExceptionRequestDate;
            }            
            
            // Create or Update the Main Exception Requester
            if (permanentUncorrectedExceptionRequester != ""){
                mainExceptionRequesterUpdatedSw = Bool.TRUE;
                mainExceptionRequester = permanentUncorrectedExceptionRequester;
            }            
            
            // Create or Update the Main Exception Status
            if (permanentUncorrectedExceptionStatus != ""){
                mainExceptionStatusUpdatedSw = Bool.TRUE;
                mainExceptionStatus = permanentUncorrectedExceptionStatus;
            }            

            // Create or Update the Main Exception Status Date
            if (permanentUncorrectedExceptionStatusDate != ""){
                mainExceptionStatusDateUpdatedSw = Bool.TRUE;
                mainExceptionStatusDate = permanentUncorrectedExceptionStatusDate;
            }
            
        }
        
    }
    
    private void createOrUpdateMainCharacteristics() {

        // Create or Update Main Exception Code
        if (mainExceptionCodeUpdatedSw.isTrue()){
            createOrUpdateMainChar(mainExceptionCodeCharType,
                    mainExceptionCodeSeq,
                    mainExceptionCode,
                    origMainExceptionCode);
        }
        
        // Create or Update Main Exception Request Date
        if (mainExceptionRequestDateUpdatedSw.isTrue()){
            createOrUpdateMainChar(mainExceptionRequestDateCharType,
                    mainExceptionRequestDateSeq,
                    mainExceptionRequestDate,
                    origMainExceptionRequestDate);
        }
        
        // Create or Update Main Exception Requester
        if (mainExceptionRequesterUpdatedSw.isTrue()){
            createOrUpdateMainChar(mainExceptionRequesterCharType,
                    mainExceptionRequesterSeq,
                    mainExceptionRequester,
                    origMainExceptionRequester);
        }
        
        // Create or Update Main Exception Status Date
        if (mainExceptionStatusDateUpdatedSw.isTrue()){
            createOrUpdateMainChar(mainExceptionStatusDateCharType,
                    mainExceptionStatusDateSeq,
                    mainExceptionStatusDate,
                    origMainExceptionStatusDate);
        }
        
        // Create or Update Main Exception Status
        if (mainExceptionStatusUpdatedSw.isTrue()){
            createOrUpdateMainChar(mainExceptionStatusCharType,
                    mainExceptionStatusSeq,
                    mainExceptionStatus,
                    origMainExceptionStatus);
        }

    }

    private SQLResultRow getCaseChar(CharacteristicType charType){
        
        SQLResultRow caseCharSQLResult = null;        
        String charVal = "";
        
        if (charType.getCharacteristicType().isPredefinedValue()){
            charVal = "CACH.CHAR_VAL ";
        }        
        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            charVal = "CACH.ADHOC_CHAR_VAL ";
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            charVal = "CACH.CHAR_VAL_FK1 ";
        }
        
        PreparedStatement getCaseChar 
                = createPreparedStatement(
                        "SELECT " +
                            charVal + "AS CHARVAL, " +
                            "CACH.SEQ_NUM AS SEQNUM " +
                        "FROM " +
                            "CI_CASE_CHAR CACH " +
                        "WHERE " +
                            "CACH.CASE_ID = :caseId " +
                            "AND CACH.CHAR_TYPE_CD = :charTypeCd " +
                            "AND CACH.SEQ_NUM = (SELECT MAX(CACH2.SEQ_NUM) " +
                                                "FROM CI_CASE_CHAR CACH2 " +
                                                "WHERE CACH2.CASE_ID = CACH.CASE_ID " +
                                                //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
                                                //"AND CACH2.CHAR_TYPE_CD = CACH.CHAR_TYPE_CD)");
                								"AND CACH2.CHAR_TYPE_CD = CACH.CHAR_TYPE_CD)", getClass().getName());
        										//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
        
        getCaseChar.bindId("caseId", toDoCase.getId());
        getCaseChar.bindId("charTypeCd", charType.getId());
        caseCharSQLResult = getCaseChar.firstRow();                        
        
        return caseCharSQLResult;
    }
    
    private BigInteger getExceptionPriority(String exceptionCode){        
    
        FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
        
        String exceptionPriorityOptVal = "",
                exceptionPriorityStr = "",
                nfeMessage = "";
        BigInteger exceptionPriority = BigInteger.ZERO;
        SQLResultRow exceptionPrioritySQLResult = null;
        List<SQLResultRow> excPriorityList;
        
        PreparedStatement getExcPriority
                = createPreparedStatement(
                        "SELECT " +
                            "OPT.WFM_OPT_VAL AS OPTVAL " +
                        "FROM " +
                            "CI_WFM_OPT OPT " +
                        "WHERE " +
                            "OPT.WFM_NAME = :wfmName " +
                            "AND OPT.EXT_OPT_TYPE = :optType " +
                            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
                            //"AND OPT.WFM_OPT_VAL LIKE :optVal");
                			"AND OPT.WFM_OPT_VAL LIKE :optVal", getClass().getName());
        					//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
        
        getExcPriority.bindId("wfmName", exceptionCodeFeatureConfigurationType.getId());
        getExcPriority.bindString("optType", exceptionPriorityFeatureConfigurationOptionType, "EXT_OPT_TYPE");
        getExcPriority.bindLikableString("optVal", exceptionCode.trim(), "WFM_OPT_VAL");  
        
        excPriorityList = getExcPriority.list();
        
        // Raise error message if Exception Code has no entry in the Feature Configuration
        if (excPriorityList.size() == 0){
        	//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
        	//session.clear();
            session.clear(session.toString().trim());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_1_excpCodeNotFound(
                    algCodeStr, 
                    exceptionCode.trim(), 
                    exceptionCodeFeatureConfigurationType.getId().getIdValue().trim()));
        }
        
        // Raise error message if Exception Code has multiple entries in the Feature Configuration        
        if (excPriorityList.size() > 1){  
        	//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //session.clear();
            session.clear(session.toString().trim());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_1_excpCodeMultiFound(
                    algCodeStr, 
                    exceptionCode.trim(), 
                    exceptionCodeFeatureConfigurationType.getId().getIdValue().trim()));
        }
        
        // Retrieve option value if there is exactly one row retrieved
        exceptionPrioritySQLResult = excPriorityList.get(0);
        exceptionPriorityOptVal = exceptionPrioritySQLResult.getString("OPTVAL");
                
        // Get the characters after the first comma
        if (exceptionPriorityOptVal.indexOf(",") == -1){ 
        	//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //session.clear();
            session.clear(session.toString().trim());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_1_excpCodeNoPriority(
                    algCodeStr, 
                    exceptionCode.trim(), 
                    exceptionCodeFeatureConfigurationType.getId().getIdValue().trim()));
        }
        exceptionPriorityStr = exceptionPriorityOptVal.substring(exceptionPriorityOptVal.indexOf(",") + 1).trim();                        
        
        // Convert the string Priority value to an integer value
        try{
            exceptionPriority = BigInteger.valueOf(Integer.parseInt(exceptionPriorityStr));
        }catch(NumberFormatException nfe){
            nfeMessage = nfe.getMessage();            
        }finally{
            if (nfeMessage != "" || exceptionPriority.intValue() < 0){
            	//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
                //session.clear();
                session.clear(session.toString().trim());
                //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
                addError(CustomMessageRepositoryMDC.NI0007_5_1_excpPriorityInvalid(
                        algCodeStr, 
                        exceptionCode.trim(), 
                        exceptionPriorityStr.trim(),
                        exceptionCodeFeatureConfigurationType.getId().getIdValue().trim()));
            }
        }
        
        return exceptionPriority;
    }
    
    /**
     * 
     * @param inboundCharType - The 'Inbound' characteristic type. Will be passed to deleteCaseChar() method
     * @param inboundCharSeq - The 'Inbound' characteristic sequence
     * @param inboundCharValue - The 'Inbound' characteristic value
     * @param permanentCharType - The 'Permanent' Characteristic Type
     * @param permanentCharSeq - The 'Permanent' Characteristic Sequence
     * @param permanentCharValue - The 'Permanent' characteristic value. Will determine if action is add or update.
     */
    private void createOrUpdatePermChar(String inboundCharValue, CharacteristicType permanentCharType, 
            BigInteger permanentCharSeq, String permanentCharValue) {

        if (permanentCharValue == ""){
            // Create the Permanent characteristic
            permanentCharSeq = createCaseChar(permanentCharType, inboundCharValue);
            // Create case log for added characteristic
            createCaseLog(permanentCharType, permanentCharSeq, inboundCharValue, CASE_LOG_ADD); 
        }else{
            if (!permanentCharValue.equals(inboundCharValue)){
                // Update the Permanent characteristic
                updateCaseChar(permanentCharType, permanentCharSeq, inboundCharValue);
                // Create case log for updated characteristic
                createCaseLog(permanentCharType, permanentCharSeq, inboundCharValue, CASE_LOG_UPDATE);
            }                 
        }               
        
    }
    
    /**
     * 
     * @param permanentCharValue - The 'Permanent' characteristic value
     * @param mainCharType - The 'Main' characteristic type 
     * @param mainCharSeq - The 'Main' characteristic sequence
     * @param mainCharValue - The 'Main' characteristic value. Will determine if action is add or update.
     */
    private void createOrUpdateMainChar(CharacteristicType mainCharType, BigInteger mainCharSeq, 
            String mainCharValue, String origMainCharValue) {

        BigInteger newCharSeq = BigInteger.ZERO;
        
        if (mainCharSeq.intValue() == 0){
            // Create the Main characteristic
            newCharSeq = createCaseChar(mainCharType, mainCharValue);
            // Create case log for added characteristic
            createCaseLog(mainCharType, newCharSeq, mainCharValue, CASE_LOG_ADD); 
        }else{
            if (!mainCharValue.equals(origMainCharValue)){
                // Update the Main characteristic
                updateCaseChar(mainCharType, mainCharSeq, mainCharValue);
                // Create case log for updated characteristic
                createCaseLog(mainCharType, mainCharSeq, mainCharValue, CASE_LOG_UPDATE);
            }             
        }        
    }
    
    /**
     * 
     * @param charType - The type of characteristic to create
     * @param charValue - The value of the characteristic that will be created
     * @return Returns the sequence number of the newly created characteristic
     */
    private BigInteger createCaseChar(CharacteristicType charType, String charValue){                  

        CaseCharacteristic_DTO caseCharDTO = new CaseCharacteristic_DTO();
        caseCharDTO.setId(new CaseCharacteristic_Id(charType, toDoCase, null));
        
        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            caseCharDTO.setAdhocCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isPredefinedValue()){
            caseCharDTO.setCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            caseCharDTO.setCharacteristicValueForeignKey1(charValue.trim());
        }
        
        CaseCharacteristic caseChar = caseCharDTO.newEntity();
        return caseChar.fetchIdSequence();
  
    }
    
    /**
     * 
     * @param charType - Characteristic type of characteristic that will be updated
     * @param seqNum - Sequence of the characteristic that will be udpated
     * @param newCharValue - New Characteristic value
     */
    private void updateCaseChar(CharacteristicType charType, BigInteger seqNum, String newCharValue) {
        
        CaseCharacteristic_Id charChar_Id = new CaseCharacteristic_Id(charType, toDoCase, seqNum);
        CaseCharacteristic_DTO caseCharDTO = charChar_Id.getEntity().getDTO();
        
        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            caseCharDTO.setAdhocCharacteristicValue(newCharValue.trim());
        }
        if (charType.getCharacteristicType().isPredefinedValue()){
            caseCharDTO.setCharacteristicValue(newCharValue.trim());
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            caseCharDTO.setCharacteristicValueForeignKey1(newCharValue.trim());
        }
        
        charChar_Id.getEntity().setDTO(caseCharDTO);
        
    }
    
    /**
     * 
     * @param charType - Characteristic type of characteristic that will be deleted
     * @param seqNum - Sequence of the characteristic that will be deleted
     */
    private void deleteCaseChar(CharacteristicType charType, BigInteger seqNum) {

        CaseCharacteristic_Id charChar_Id = new CaseCharacteristic_Id(charType, toDoCase, seqNum);
        toDoCase.getCharacteristics().remove(charChar_Id);
        
    }
    
    /**
     * 
     * @param charType - Characteristic Type of the added/updated/deleted characteristic
     * @param seqNum - Sequence number of the added/updated/deleted characteristic
     * @param charValue - Value of the added/updated/deleted characteristic
     * @param action - Will determine the correct Message to use
     */
    private void createCaseLog(CharacteristicType charType, BigInteger seqNum, String charValue, String action){
        
        // Create Case Log Entry
        CaseLog_DTO caseLogDto = new CaseLog_DTO();
        caseLogDto.setCaseStatusId(toDoCase.getCaseStatus().getId());
        caseLogDto.setCharacteristicTypeId(charType.getId());
        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            caseLogDto.setAdhocCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isPredefinedValue()){
            caseLogDto.setCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            caseLogDto.setCharacteristicValueForeignKey1(charValue.trim());
        }
        // Set Message Id depending on Action
        if (action == CASE_LOG_ADD){
            caseLogDto.setMessageId(new Message_Id(MESSAGE_CAT, CASE_CHAR_ADDED_MSG_NUM));
        }
        if (action == CASE_LOG_UPDATE){
            caseLogDto.setMessageId(new Message_Id(MESSAGE_CAT, CASE_CHAR_UPDATED_MSG_NUM));
        }
        if (action == CASE_LOG_DELETE){
            caseLogDto.setMessageId(new Message_Id(MESSAGE_CAT, CASE_CHAR_DELETED_MSG_NUM));
        }        
        caseLogDto.setLogType(CaseLogTypeLookup.constants.SYSTEM);
        
        // Get newly created Case Log
        CaseLog caseLog = toDoCase.getLogs().add(caseLogDto, null);                    

        // Add message parameter for characteristic type
        CaseLogMessageParameter_DTO caseLogMsgParmDto = new CaseLogMessageParameter_DTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.ONE));
        caseLogMsgParmDto.setMessageParameter(charType.getId().getIdValue().trim());        
        caseLog.getMessageParameters().add(caseLogMsgParmDto, BigInteger.ONE);
        
        // Add message parameter for characteristic sequence number
        caseLogMsgParmDto = new CaseLogMessageParameter_DTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.valueOf(2)));
        caseLogMsgParmDto.setMessageParameter(seqNum.toString().trim());        
        caseLog.getMessageParameters().add(caseLogMsgParmDto, BigInteger.valueOf(2));
        
        // Add message parameter for characteristic value
        int counter = 0;
        String[] charVal = new String[]{"","","","","","",""};        
        
        for(int i = 0; i <= charValue.length() && counter < 7; i = i + 30){            
            if( i + 30 > charValue.length()){
                charVal[counter] = (charValue.substring(i, charValue.length()));
            }else{
                charVal[counter] = (charValue.substring(i, i + 30));                
                counter++;
            }
        }
        
        BigInteger charValParmSeq = BigInteger.valueOf(3);
        for (int i = 0; i < 7; i++) {            
            if (StringUtilities.notEmptyOrBlank(charVal[i])) {
                caseLogMsgParmDto = new CaseLogMessageParameter_DTO();
                caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, charValParmSeq));
                caseLogMsgParmDto.setMessageParameter(charVal[i].trim());        
                caseLog.getMessageParameters().add(caseLogMsgParmDto, charValParmSeq);
            }
            charValParmSeq = charValParmSeq.add(BigInteger.ONE);
        }
        
    }
        
    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        
        // Get algorithm code
        algCodeStr = this.getAlgorithm().getId().getIdValue().trim();
        
        // Characteristic Type for Inbound Corrected Exception Code
        inboundCorrectedExceptionCodeCharType = this.getCharacteristicTypeForInboundCorrectedExceptionCode();
        validateCaseChar(inboundCorrectedExceptionCodeCharType, "Characteristic Type for Inbound Corrected Exception Code");
        
        // Characteristic Type for Inbound Corrected Exception Request Date
        inboundCorrectedExceptionRequestDateCharType = this.getCharacteristicTypeForInboundCorrectedExceptionRequestDate();
        validateCaseChar(inboundCorrectedExceptionRequestDateCharType, "Characteristic Type for Inbound Corrected Exception Request Date");
        
        // Characteristic Type for Inbound Corrected Exception Requester
        inboundCorrectedExceptionRequesterCharType = this.getCharacteristicTypeForInboundCorrectedExceptionRequester();
        validateCaseChar(inboundCorrectedExceptionRequesterCharType, "Characteristic Type for Inbound Corrected Exception Requester");
        
        // Characteristic Type for Inbound Corrected Exception Status
        inboundCorrectedExceptionStatusDateCharType = this.getCharacteristicTypeForInboundCorrectedExceptionStatusDate();
        validateCaseChar(inboundCorrectedExceptionStatusDateCharType, "Characteristic Type for Inbound Corrected Exception Status");
        
        // Characteristic Type for Inbound Corrected Exception Status Date
        inboundCorrectedExceptionStatusCharType = this.getCharacteristicTypeForInboundCorrectedExceptionStatus();
        validateCaseChar(inboundCorrectedExceptionStatusCharType, "Characteristic Type for Inbound Corrected Exception Status Date");
        
        // Characteristic Type for Inbound Uncorrected Exception Code
        inboundUncorrectedExceptionCodeCharType = this.getCharacteristicTypeForInboundUncorrectedExceptionCode();
        validateCaseChar(inboundUncorrectedExceptionCodeCharType, "Characteristic Type for Inbound Uncorrected Exception Code");
        
        // Characteristic Type for Inbound Uncorrected Exception Request Date
        inboundUncorrectedExceptionRequestDateCharType = this.getCharacteristicTypeForInboundUncorrectedExceptionRequestDate();
        validateCaseChar(inboundUncorrectedExceptionRequestDateCharType, "Characteristic Type for Inbound Uncorrected Exception Request Date");
        
        // Characteristic Type for Inbound Uncorrected Exception Requester
        inboundUncorrectedExceptionRequesterCharType = this.getCharacteristicTypeForInboundUncorrectedExceptionRequester();
        validateCaseChar(inboundUncorrectedExceptionRequesterCharType, "Characteristic Type for Inbound Uncorrected Exception Requester");
        
        // Characteristic Type for Inbound Uncorrected Exception Status
        inboundUncorrectedExceptionStatusDateCharType = this.getCharacteristicTypeForInboundUncorrectedExceptionStatusDate();
        validateCaseChar(inboundUncorrectedExceptionStatusDateCharType, "Characteristic Type for Inbound Uncorrected Exception Status");
        
        // Characteristic Type for Inbound Uncorrected Exception Status Date
        inboundUncorrectedExceptionStatusCharType = this.getCharacteristicTypeForInboundUncorrectedExceptionStatus();
        validateCaseChar(inboundUncorrectedExceptionStatusCharType, "Characteristic Type for Inbound Uncorrected Exception Status Date");
        
        // Characteristic Type for Corrected Exception Code
        permanentCorrectedExceptionCodeCharType = this.getCharacteristicTypeForCorrectedExceptionCode();
        validateCaseChar(permanentCorrectedExceptionCodeCharType, "Characteristic Type for Corrected Exception Code");
        
        // Characteristic Type for Corrected Exception Request Date
        permanentCorrectedExceptionRequestDateCharType = this.getCharacteristicTypeForCorrectedExceptionRequestDate();
        validateCaseChar(permanentCorrectedExceptionRequestDateCharType, "Characteristic Type for Corrected Exception Request Date");
        
        // Characteristic Type for Corrected Exception Requester
        permanentCorrectedExceptionRequesterCharType = this.getCharacteristicTypeForCorrectedExceptionRequester();
        validateCaseChar(permanentCorrectedExceptionRequesterCharType, "Characteristic Type for Corrected Exception Requester");
        
        // Characteristic Type for Corrected Exception Status
        permanentCorrectedExceptionStatusDateCharType = this.getCharacteristicTypeForCorrectedExceptionStatusDate();
        validateCaseChar(permanentCorrectedExceptionStatusDateCharType, "Characteristic Type for Corrected Exception Status");
        
        // Characteristic Type for Corrected Exception Status Date
        permanentCorrectedExceptionStatusCharType = this.getCharacteristicTypeForCorrectedExceptionStatus();
        validateCaseChar(permanentCorrectedExceptionStatusCharType, "Characteristic Type for Corrected Exception Status Date");
        
        // Characteristic Type for Uncorrected Exception Code
        permanentUncorrectedExceptionCodeCharType = this.getCharacteristicTypeForUncorrectedExceptionCode();
        validateCaseChar(permanentUncorrectedExceptionCodeCharType, "Characteristic Type for Uncorrected Exception Code");
        
        // Characteristic Type for Uncorrected Exception Request Date
        permanentUncorrectedExceptionRequestDateCharType = this.getCharacteristicTypeForUncorrectedExceptionRequestDate();
        validateCaseChar(permanentUncorrectedExceptionRequestDateCharType, "Characteristic Type for Uncorrected Exception Request Date");
        
        // Characteristic Type for Uncorrected Exception Requester
        permanentUncorrectedExceptionRequesterCharType = this.getCharacteristicTypeForUncorrectedExceptionRequester();
        validateCaseChar(permanentUncorrectedExceptionRequesterCharType, "Characteristic Type for Uncorrected Exception Requester");
        
        // Characteristic Type for Uncorrected Exception Status
        permanentUncorrectedExceptionStatusDateCharType = this.getCharacteristicTypeForUncorrectedExceptionStatusDate();
        validateCaseChar(permanentUncorrectedExceptionStatusDateCharType, "Characteristic Type for Uncorrected Exception Status");
        
        // Characteristic Type for Uncorrected Exception Status Date
        permanentUncorrectedExceptionStatusCharType = this.getCharacteristicTypeForUncorrectedExceptionStatus();
        validateCaseChar(permanentUncorrectedExceptionStatusCharType, "Characteristic Type for Uncorrected Exception Status Date");
        
        // Characteristic Type for Main Exception Code
        mainExceptionCodeCharType = this.getCharacteristicTypeForMainExceptionCode();
        validateCaseChar(mainExceptionCodeCharType, "Characteristic Type for Main Exception Code");
        
        // Characteristic Type for Main Exception Request Date
        mainExceptionRequestDateCharType = this.getCharacteristicTypeForMainExceptionRequestDate();
        validateCaseChar(mainExceptionRequestDateCharType, "Characteristic Type for Main Exception Request Date");
        
        // Characteristic Type for Main Exception Requester
        mainExceptionRequesterCharType = this.getCharacteristicTypeForMainExceptionRequester();
        validateCaseChar(mainExceptionRequesterCharType, "Characteristic Type for Main Exception Requester");
        
        // Characteristic Type for Main Exception Status
        mainExceptionStatusDateCharType = this.getCharacteristicTypeForMainExceptionStatusDate();
        validateCaseChar(mainExceptionStatusDateCharType, "Characteristic Type for Main Exception Status");
        
        // Characteristic Type for Main Exception Status Date
        mainExceptionStatusCharType = this.getCharacteristicTypeForMainExceptionStatus();
        validateCaseChar(mainExceptionStatusCharType, "Characteristic Type for Main Exception Status Date");
        
        // Exception Code Feature Configuration Type
        exceptionCodeFeatureConfigurationType = this.getExceptionCodeFeatureConfigurationType();
        
        // Exception Priority Feature Configuration Option Type
        exceptionPriorityFeatureConfigurationOptionType = this.getExceptionPriorityFeatureConfigurationOptionType();
        
        // Exception Priority Feature Configuration Option Type must be valid a valid option type for Exception Code Feature Configuration Type
        String extSysTypStr = exceptionCodeFeatureConfigurationType.getFeatureType().getLookupValue().fetchIdFieldValue().trim();
        extSysTypStr = extSysTypStr.concat(_OPT_TYP_FLG);
        LookupField_Id lookupField_Id = new LookupField_Id(extSysTypStr);
        LookupValue_Id lookupValue_Id = new LookupValue_Id(lookupField_Id, exceptionPriorityFeatureConfigurationOptionType.trim());
        if (isNull(lookupValue_Id.getEntity())){
            addError(CustomMessageRepositoryMDC.NI0007_5_1_optTypeInvForWFM(
                    algCodeStr, 
                    "Exception Priority Feature Configuration Option Type", 
                    exceptionPriorityFeatureConfigurationOptionType.trim(), 
                    exceptionCodeFeatureConfigurationType.getId().getIdValue().trim()));
        }
        
    }
    
    private void validateCaseChar(CharacteristicType charType, String parmDescr) {
        CharacteristicEntity_Id charEntity_Id = new CharacteristicEntity_Id(charType, CharacteristicEntityLookup.constants.CASE);
        if (isNull(charEntity_Id.getEntity())){
            addError(CustomMessageRepositoryMDC.NI0007_5_1_charTypeInvForEntity(
                    algCodeStr, 
                    parmDescr, 
                    charType.getId().getIdValue().trim(), 
                    CharacteristicEntityLookup.constants.CASE.getLookupValue().fetchLanguageDescription().trim()));
        }        
    }

}
