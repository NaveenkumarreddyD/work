/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Create To Do For Electronic Estimated Bills Batch
 * 
 * The batch process will create To Do Entries for estimated completed 
 * bills for Accounts that are currently set up for Autopay or E-bill.  
 *            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-10-07   JPunza  NM0104 Initial Version.
 * 2013-11-19   JPunza  Addendum. Add To Do Log.
 * 2016-01-27	MPang	Updated for CCB v2.4 compilation. 
 *************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.LogTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption_Id;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
/*import com.splwg.ccb.domain.admin.billCycle.BillCycleSchedule;
import com.splwg.ccb.domain.billing.bill.Bill;
import com.splwg.ccb.domain.billing.bill.BillRouting;
import com.splwg.ccb.domain.billing.bill.Bill_Id;
import com.splwg.ccb.domain.customerinfo.account.Account;*/
import com.splwg.ccb.domain.admin.billCycle.entity.BillCycleSchedule;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillRouting;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.cm.api.lookup.BillFormatLookup;
import com.splwg.cm.api.lookup.CmEstimatedReadTypesLookup;
import com.splwg.cm.api.lookup.CmThresholdRulesLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author jpunzalan001
 *
 @BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = featureConfiguration, name = EST_READ_TYPES_FC, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = AUTOPAY_THRESHOLD_RULES_FC, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = EBILL_THRESHOLD_RULES_FC, required = true, type = entity)})
 */
public class CmCreateToDoForElectronicEstimatedBillsBatch 
    extends CmCreateToDoForElectronicEstimatedBillsBatch_Gen {

    public JobWork getJobWork() {
           
        PreparedStatement getCompletedBills = createPreparedStatement("SELECT B.BILL_ID FROM CI_BILL B " +
                "WHERE B.COMPLETE_DTTM IS NOT NULL AND TRUNC(B.COMPLETE_DTTM) = :processDt " +
                "AND (EXISTS (SELECT 'X' FROM CI_ACCT_APAY AA " +
                "   WHERE AA.ACCT_ID = B.ACCT_ID " +
                "   AND AA.START_DT <= B.DUE_DT " +
                "   AND (AA.END_DT >= B.DUE_DT OR AA.END_DT IS NULL)) " +
                "OR EXISTS (SELECT 'X' FROM CI_BILL_ROUTING BR " +
                "   WHERE BR.BILL_ID = B.BILL_ID " +
                //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
                //"   AND BR.BILL_FORMAT_FLG = :ebill))");
    			"   AND BR.BILL_FORMAT_FLG = :ebill))", getClass().getName());
        		//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
        
        getCompletedBills.bindDate("processDt", getProcessDateTime().getDate());
        getCompletedBills.bindLookup("ebill", BillFormatLookup.constants.EBILL);
        
        // Build Worklist
        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();

        QueryIterator<SQLResultRow> iter = getCompletedBills.iterate();
        while (iter.hasNext()) {
            SQLResultRow row = iter.next();

            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId(row.getId("BILL_ID", Bill.class));
            workUnits.add(workUnit);              
        }
        iter.close();  
        
        getCompletedBills.close();

        return createJobWorkForThreadWorkUnitList(workUnits); 
    }

    public Class<CmCreateToDoForElectronicEstimatedBillsBatchWorker> getThreadWorkerClass() {
        return CmCreateToDoForElectronicEstimatedBillsBatchWorker.class;
    }

    public static class CmCreateToDoForElectronicEstimatedBillsBatchWorker
            extends CmCreateToDoForElectronicEstimatedBillsBatchWorker_Gen {
        
        private final String MANUAL = "Manual";
        
        private FeatureConfiguration thresholdRulesFeatConfig;
        private BigInteger sequence, existingToDo, createdToDo;
        private BigDecimal threshold1, threshold2, threshold3;
        private ToDoType toDoType1, toDoType2, toDoType3;
                
        public ThreadExecutionStrategy createExecutionStrategy() {

            return new StandardCommitStrategy(this);
        }
        
        @Override
        public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
            
            createdToDo = BigInteger.ZERO;
            existingToDo = BigInteger.ZERO;
        }
                        
        @Override
        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit arg0) throws ThreadAbortedException, RunAbortedException {
            
            WorkUnitResult result = new WorkUnitResult(true);
            result.setUnitsProcessed(0);
                        
            Bill_Id billId = (Bill_Id) arg0.getPrimaryId();
            Bill bill = billId.getEntity();
            
            PreparedStatement checkEstimatedBillSegment = createPreparedStatement("SELECT COUNT(BS.BSEG_ID) AS CNT FROM CI_BSEG BS " +
                    "WHERE BS.BILL_ID = :billId " +
                    "AND (BS.EST_SW = :yes " +
                    "OR EXISTS (SELECT 'X' FROM CI_BSEG_READ BR, CI_REG_READ RR " +
                    "   WHERE BR.BSEG_ID = BS.BSEG_ID " +
                    "   AND BR.END_REG_READ_ID = RR.REG_READ_ID " +
                    "   AND EXISTS (SELECT 'X' FROM CI_WFM_OPT WO " +
                    "       WHERE WO.WFM_NAME = :featConfig " +
                    "       AND WO.EXT_OPT_TYPE = :optionType " +
                    //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
                    //"       AND TRIM(WO.WFM_OPT_VAL) = TRIM(RR.READ_TYPE_FLG))))");
        			"       AND TRIM(WO.WFM_OPT_VAL) = TRIM(RR.READ_TYPE_FLG))))", getClass().getName());
            		//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            checkEstimatedBillSegment.bindId("billId", billId);
            checkEstimatedBillSegment.bindBoolean("yes", Bool.TRUE);
            checkEstimatedBillSegment.bindEntity("featConfig", getParameters().getEST_READ_TYPES_FC());
            checkEstimatedBillSegment.bindLookup("optionType", CmEstimatedReadTypesLookup.constants.ESTIMATED_READ_TYPE);
            
            SQLResultRow row = checkEstimatedBillSegment.firstRow();
            checkEstimatedBillSegment.close();
                        
            BigInteger bsCount = row.getInteger("CNT");
            if (bsCount.compareTo(BigInteger.ZERO) > 0) {
                
                getThresholdValues(bill);
                
                PreparedStatement getBillAmount = createPreparedStatement("SELECT SUM(FT.CUR_AMT) AS TOTAL FROM CI_FT FT " +
                		//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
                		//"WHERE FT.BILL_ID = :billId");
            			"WHERE FT.BILL_ID = :billId", getClass().getName());
                		//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
                getBillAmount.bindId("billId", billId);
                
                row = getBillAmount.firstRow();
                getBillAmount.close();
                
                BigDecimal billAmount = row.getBigDecimal("TOTAL");
                
                if (billAmount.compareTo(threshold1) >= 0) {
                    createToDo(toDoType1, bill, 1);
                }
                else if (notNull(threshold2) && billAmount.compareTo(threshold2) >= 0) {
                    createToDo(toDoType2, bill, 2);
                }                
                else if (notNull(threshold3) && billAmount.compareTo(threshold3) >= 0) {
                    createToDo(toDoType3, bill, 3);
                }
                result.setUnitsProcessed(1);
            }

            return result;
        }
        
        @Override
        public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {

           logInfo(CustomMessageRepositoryMDC.NM0104_numberOfCreatedToDo(createdToDo));
           logInfo(CustomMessageRepositoryMDC.NM0104_numberOfExistingToDo(existingToDo));
        }
        
        /**
         * This method retrieves the Threshold Values
         * @param bill - Bill
         */
        private void getThresholdValues(Bill bill) {
            
            // Determine if Autopay or eBill 
        	//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            // ListFilter<BillRouting> routings = bill.getRoutings().createFilter("WHERE this.billFormat = :ebill");
        	ListFilter<BillRouting> routings = bill.getRoutings().createFilter("WHERE this.billFormat = :ebill", getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            routings.bindLookup("ebill", BillFormatLookup.constants.EBILL);
            
            if (notNull(routings.firstRow())) {
                thresholdRulesFeatConfig = getParameters().getEBILL_THRESHOLD_RULES_FC();
            }
            else {
                thresholdRulesFeatConfig = getParameters().getAUTOPAY_THRESHOLD_RULES_FC();
            }
                   
            // Retrieve the Threshold Rules given the CIS Division and Customer Class
            Account account = bill.getAccount();
            
            PreparedStatement getSequenceNumber = createPreparedStatement("SELECT WO.SEQ_NUM FROM CI_WFM_OPT WO " +
                    "WHERE WO.WFM_NAME = :featConfig " +
                    "AND WO.EXT_OPT_TYPE = :optionType1 " +
                    "AND TRIM(WO.WFM_OPT_VAL) = TRIM(:cisDivisionId) " +
                    "AND EXISTS (SELECT 'X' FROM CI_WFM_OPT WO2 " +
                    "   WHERE WO2.WFM_NAME = WO.WFM_NAME " +
                    "   AND WO2.EXT_OPT_TYPE = :optionType2 " +
                    //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
                    //"   AND TRIM(WO2.WFM_OPT_VAL) = TRIM(:customerClass))");
        			"   AND TRIM(WO2.WFM_OPT_VAL) = TRIM(:customerClass))", getClass().getName());
            		//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
           
            getSequenceNumber.bindEntity("featConfig", thresholdRulesFeatConfig);
            getSequenceNumber.bindLookup("optionType1", CmThresholdRulesLookup.constants.CIS_DIVISION);
            getSequenceNumber.bindId("cisDivisionId", account.getDivisionId());
            getSequenceNumber.bindLookup("optionType2", CmThresholdRulesLookup.constants.CUSTOMER_CLASS);
            getSequenceNumber.bindEntity("customerClass", account.getCustomerClass());
            
            SQLResultRow row = getSequenceNumber.firstRow();
            getSequenceNumber.close();
            
            if (isNull(row)) {
                addError(CustomMessageRepositoryMDC.NM0104_cisAndCustomerClassMissing(
                        account.getDivisionId().getTrimmedValue(), 
                        account.getCustomerClass().getId().getTrimmedValue(), 
                        thresholdRulesFeatConfig.getId().getTrimmedValue()));
            }
            
            sequence = row.getInteger("SEQ_NUM");
                        
            // Threshold 1
            LookupValue lookupValue = CmThresholdRulesLookup.constants.THRESHOLD_1.getLookupValue();
            String featConfigValue = retrieveFeatConfigOptionValue(lookupValue, Bool.TRUE);
            threshold1 = convertToBigDecimal(featConfigValue, lookupValue.fetchLanguageDescription().trim());
            
            // Threshold 1 To Do Type
            lookupValue = CmThresholdRulesLookup.constants.THRESHOLD_1_TO_DO_TYPE.getLookupValue();
            featConfigValue = retrieveFeatConfigOptionValue(lookupValue, Bool.TRUE);
            toDoType1 = convertToToDoType(featConfigValue, lookupValue.fetchLanguageDescription().trim());
            
            // Threshold 2
            lookupValue = CmThresholdRulesLookup.constants.THRESHOLD_2.getLookupValue();
            featConfigValue = retrieveFeatConfigOptionValue(lookupValue, Bool.FALSE);
            
            if (notBlank(featConfigValue)) {
                
                threshold2 = convertToBigDecimal(featConfigValue, lookupValue.fetchLanguageDescription().trim());
                
                // Threshold 2 To Do Type
                lookupValue = CmThresholdRulesLookup.constants.THRESHOLD_2_TO_DO_TYPE.getLookupValue();
                featConfigValue = retrieveFeatConfigOptionValue(lookupValue, Bool.TRUE);
                toDoType2 = convertToToDoType(featConfigValue, lookupValue.fetchLanguageDescription().trim());
            }
            else {
                threshold2 = null;
            }
                        
            // Threshold 3
            lookupValue = CmThresholdRulesLookup.constants.THRESHOLD_3.getLookupValue();
            featConfigValue = retrieveFeatConfigOptionValue(lookupValue, Bool.FALSE);
            
            if (notBlank(featConfigValue)) {
                
                threshold3 = convertToBigDecimal(featConfigValue, lookupValue.fetchLanguageDescription().trim());
            
                // Threshold 3 To Do Type
                lookupValue = CmThresholdRulesLookup.constants.THRESHOLD_3_TO_DO_TYPE.getLookupValue();
                featConfigValue = retrieveFeatConfigOptionValue(lookupValue, Bool.TRUE);
                toDoType3 = convertToToDoType(featConfigValue, lookupValue.fetchLanguageDescription().trim());
            }
            else {
                threshold3 = null;
            }
        }

        /**
         * This method retrieves Feature Configuration Option Value
         * @param optionType - Lookup Value
         * @return String
         */
        private String retrieveFeatConfigOptionValue(LookupValue optionType, Bool validateOption) {

            FeatureConfigurationOption_Id featConfigOptionId = new FeatureConfigurationOption_Id(thresholdRulesFeatConfig, 
                    optionType.fetchIdFieldValue().trim(), 
                    sequence);
            FeatureConfigurationOption featConfigOption = featConfigOptionId.getEntity();
            
            if (isNull(featConfigOption)) {
                if (validateOption.isTrue()) {                
                    addError(CustomMessageRepositoryMDC.NM0104_optionTypeAndSequenceMissing(
                            optionType.fetchLanguageDescription().trim(), 
                            sequence.toString(), 
                            thresholdRulesFeatConfig.getId().getTrimmedValue()));
                }
            }
            else {
                return featConfigOption.getValue().trim();
            }
            
            return new String();
        }
                        
        /**
         * This method will convert string to BigDecimal
         * @param str - String
         * @param optionType - String
         * @return BigDecimal
         */
        private BigDecimal convertToBigDecimal(String str, String optionType) {    
            
            BigDecimal decimal = BigDecimal.ZERO;

            try {
                decimal = BigDecimal.valueOf(Double.parseDouble(str));
            }
            catch (NumberFormatException nfe) {
                addError(CustomMessageRepositoryMDC.NM0104_nonNumericValueFound(
                        str,
                        optionType, 
                        sequence.toString(), 
                        thresholdRulesFeatConfig.getId().getTrimmedValue()));
            }

            return decimal;
        }
        
        /**
         * This method will convert string to To Do Type
         * @param str - String
         * @param optionType - String
         * @return ToDoType
         */
        private ToDoType convertToToDoType(String str, String optionType) {    

            ToDoType_Id toDoTypeId = new ToDoType_Id(str);
            ToDoType toDoType = toDoTypeId.getEntity();

            if (isNull(toDoType)) {
                addError(CustomMessageRepositoryMDC.NM0104_invalidToDoTypeFound(
                        str,
                        optionType, 
                        sequence.toString(), 
                        thresholdRulesFeatConfig.getId().getTrimmedValue()));
            }
            
            return toDoType;
        }
        
        /**
         * This method creates To Do Entry
         * @param toDoType - ToDoType
         * @param bill - Bill
         * @param threshold - BigDecimal
         */
        private void createToDo(ToDoType toDoType, Bill bill, int threshold) {
            
            if (isExistingToDo(toDoType, bill).isTrue()) {
                existingToDo = existingToDo.add(BigInteger.ONE);
                return;
            }
            
            ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
            ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();
                        
            toDoEntryDTO.setCreationDateTime(getProcessDateTime());
            toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
            toDoEntryDTO.setToDoTypeId(toDoType.getId());
            
            toDoEntryDTO.setBatchControlId(getBatchControlId());
            toDoEntryDTO.setBatchNumber(getBatchNumber());
                                
            toDoCreator.setToDoDTO(toDoEntryDTO);
                            
            // Sort Keys
            for (ToDoSortKeyType sortKeyType : toDoType.getSortKeyTypes()) {
                
                BigInteger sequence = sortKeyType.fetchIdSequence();
                
                if (sequence.compareTo(BigInteger.valueOf(1)) == 0) { // Customer Class
                    toDoCreator.addSortKeyValue(sortKeyType, bill.getAccount().getCustomerClass().getId().getTrimmedValue());                    
                }
                else if (sequence.compareTo(BigInteger.valueOf(2)) == 0) { // Bill Cycle
                    BillCycleSchedule billCycleSchedule = bill.fetchBillCycleSchedule();
                    if (isNull(billCycleSchedule)) {
                        toDoCreator.addSortKeyValue(sortKeyType, MANUAL);     
                    }
                    else {
                        toDoCreator.addSortKeyValue(sortKeyType, billCycleSchedule.fetchIdBillCycle().getId().getTrimmedValue()); 
                    }                            
                }
                else if (sequence.compareTo(BigInteger.valueOf(3)) == 0) { // Threshold
                    toDoCreator.addSortKeyValue(sortKeyType, String.valueOf(threshold));                    
                }
            }
                
            // Drill Keys
            for (ToDoDrillKeyType drillKeyType : toDoType.getDrillKeyTypes()) {
                toDoCreator.addDrillKeyValue(drillKeyType, bill.getId().getTrimmedValue());
            }
            
            // Message Parameter (optional)
            toDoCreator.addMessageParameter(bill.getAccount().getId().getTrimmedValue());
            
            // JPunza - 2013-11-19 - Start
            toDoCreator.addTransactionHistory(LogTypeLookup.constants.CREATED, null, null);
            // JPunza - 2013-11-19 - End
            
            toDoCreator.create();
            createdToDo = createdToDo.add(BigInteger.ONE);
        }
        
        /**
         * This method checks for existing To Do
         * @param toDoType - To Do Type
         * @param bill - Bill
         * @return Bool
         */
        private Bool isExistingToDo(ToDoType toDoType, Bill bill) {
            
            PreparedStatement checkExistingToDo = createPreparedStatement("SELECT TDE.TD_ENTRY_ID FROM CI_TD_ENTRY TDE " +
                    "WHERE TDE.TD_TYPE_CD = :toDoType " +
                    "AND TDE.ENTRY_STATUS_FLG IN (:open, :beingWorkedOn) " +
                    "AND EXISTS (SELECT 'X' FROM CI_TD_DRLKEY TDD " +
                    "   WHERE TDD.TD_ENTRY_ID = TDE.TD_ENTRY_ID " +
                    //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
                    //"AND TRIM(TDD.KEY_VALUE) = TRIM(:bill))");
        			"AND TRIM(TDD.KEY_VALUE) = TRIM(:bill))", getClass().getName());
            		//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            checkExistingToDo.bindEntity("toDoType", toDoType);
            checkExistingToDo.bindLookup("open", ToDoEntryStatusLookup.constants.OPEN);
            checkExistingToDo.bindLookup("beingWorkedOn", ToDoEntryStatusLookup.constants.BEING_WORKED_ON);
            checkExistingToDo.bindEntity("bill", bill);
            
            SQLResultRow row = checkExistingToDo.firstRow();
            checkExistingToDo.close();
            
            if (notNull(row)) {
                return Bool.TRUE;
            }

            return Bool.FALSE;
        }
    }
}
