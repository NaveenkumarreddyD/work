/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * CINT00181 - Maximo CCB Create/Update Meter Item
 *
 * For any change to a meter in Maximo where the meter does not have a 
 * Service Point, a WO is not required and the update will be driven  
 * though this Create/Update Meter interface process.
 * 
 * Any change to an item in Maximo will cause the updates to be sent to 
 * CC&B via this interface. This interface will also create the Meter/Item
 * link in CC&B.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2015-01-23   SMiran        	CINT00181.Initial Version.
 * 2015-05-26   SMiran			Defect 3223676. Ensure uniqueness of meters
 * 								by searching by badge number, manufacturer,
 * 								and site number.
 * 								Defect 3220374. Ignore updates to meter
 * 								configuration if Meter is going to be Retired
 * 2015-06-16   SMiran          Defect 3236635. Prevent null pointer 
 * 								exception when Max Error is reached.
 * 2015-06-17   SMiran          Defect 3236052. Added SITEID column to 
 * 								Item interface table.
 * 2016-01-29  	MPang			Updated for CCB v2.4 compilation. 
 **************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Id;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.lookup.LookupField_Id;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.ccb.api.lookup.ConsumptionTypeLookup;
import com.splwg.ccb.api.lookup.HowToUseLookup;
import com.splwg.ccb.api.lookup.ItemStatusLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.intervalRegisterType.IntervalRegisterType_Id;
import com.splwg.ccb.domain.admin.itemType.CharacteristicTypeItemType_Id;
import com.splwg.ccb.domain.admin.itemType.ItemType;
import com.splwg.ccb.domain.admin.itemType.ItemType_Id;
import com.splwg.ccb.domain.admin.manufacturer.Manufacturer_Id;
import com.splwg.ccb.domain.admin.manufacturer.Model_Id;
import com.splwg.ccb.domain.admin.meterConfigurationType.MeterConfigurationType_Id;
import com.splwg.ccb.domain.admin.meterType.CharacteristicTypeMeterType_Id;
import com.splwg.ccb.domain.admin.meterType.MeterType_Id;
import com.splwg.ccb.domain.admin.protocol.Protocol_Id;
import com.splwg.ccb.domain.admin.readOutType.ReadOutType_Id;
import com.splwg.ccb.domain.admin.retireReason.RetireReason_Id;
import com.splwg.ccb.domain.admin.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.admin.timeOfUse.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;*/
import com.splwg.ccb.domain.admin.intervalRegisterType.entity.IntervalRegisterType_Id;
import com.splwg.ccb.domain.admin.itemType.entity.CharacteristicTypeItemType_Id;
import com.splwg.ccb.domain.admin.itemType.entity.ItemType;
import com.splwg.ccb.domain.admin.itemType.entity.ItemType_Id;
import com.splwg.ccb.domain.admin.manufacturer.entity.Manufacturer_Id;
import com.splwg.ccb.domain.admin.manufacturer.entity.Model_Id;
import com.splwg.ccb.domain.admin.meterConfigurationType.entity.MeterConfigurationType_Id;
import com.splwg.ccb.domain.admin.meterType.entity.CharacteristicTypeMeterType_Id;
import com.splwg.ccb.domain.admin.meterType.entity.MeterType_Id;
import com.splwg.ccb.domain.admin.protocol.entity.Protocol_Id;
import com.splwg.ccb.domain.admin.readOutType.entity.ReadOutType_Id;
import com.splwg.ccb.domain.admin.retireReason.entity.RetireReason_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.api.lookup.CmActionFlagLookup;
import com.splwg.cm.api.lookup.CmInterfaceStatusLookup;
import com.splwg.cm.api.lookup.MeterStatusLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.interfaceStaging.CmCharacteristicTempData;
import com.splwg.cm.domain.interfaceStaging.CmInterfaceErrorLogMaintenance;
import com.splwg.cm.domain.interfaceStaging.CmItemHelper;
import com.splwg.cm.domain.interfaceStaging.CmMeterHelper;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

/**
 * @author 90723
 *
 @BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = serviceTaskType, name = SERVICE_TASK_TYPE, required = true, type = entity)})
 */
public class CmMeterItemCreateUpdateFromMaximoBatch extends
		CmMeterItemCreateUpdateFromMaximoBatch_Gen {	

	// Batch parameters
	private ServiceTaskType parmServiceTaskType;
	
	// Service Task parameters
	private String parmSourceSystemName;
	private String parmTargetSystemName;

	// Id class for the Staging Key
	private static class CmInboundInterfaceStaging_Id implements Id {
		private static final long serialVersionUID = 1L;		
		private String stagingKey;
		
		public CmInboundInterfaceStaging_Id(String stagingKey) {
			setStagingKey(stagingKey);
		}
		
		public String getStagingKey() {
			return stagingKey;
		}
		
		private void setStagingKey(String stagingKey) {
			this.stagingKey = stagingKey;
		}
		// Unused method
		public boolean isNull() {
			return false;
		}
		// Unused method
		public void appendContents(StringBuilder arg0) {
		}
	}
	
	@Override
	public void validateSoftParameters(boolean arg0) {
				
		// Get soft parameters
		parmServiceTaskType = this.getParameters().getSERVICE_TASK_TYPE();
		
		BusinessObject serviceTaskTypeBo = parmServiceTaskType.getBusinessObject();
		BusinessObjectInstance serviceTaskType = BusinessObjectInstance.create(serviceTaskTypeBo);
		serviceTaskType.set("serviceTaskType", parmServiceTaskType.getId().getTrimmedValue()); 
		serviceTaskType = BusinessObjectDispatcher.read(serviceTaskType);		
				
		parmSourceSystemName = serviceTaskType.getString("sourceSystem");
		parmTargetSystemName = serviceTaskType.getString("targetSystem");
		
	}
	
	@Override
	public JobWork getJobWork() {
		
        ArrayList<ThreadWorkUnit> workUnitList =  new ArrayList<ThreadWorkUnit>();
        List<SQLResultRow> inboundStagingRow = null;
        // Get inbound staging records to process
        inboundStagingRow = getInboundStagingRecords();

        // Create work unit for each record in result set
        for(SQLResultRow row : inboundStagingRow){
            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId(new CmInboundInterfaceStaging_Id(row.getString("STAGING_KEY")));
            workUnit.addSupplementalData("logicalTransactionNumber", row.getString("LOGICAL_TRX_NUMBER"));
            workUnit.addSupplementalData("creationDateTime", row.getDateTime("CREATION_DATETIME"));
            workUnit.addSupplementalData("originatingKey", row.getString("ORIGINATING_KEY")); 
            workUnitList.add(workUnit);
        }

        return createJobWorkForThreadWorkUnitList(workUnitList);
	}		

	private List<SQLResultRow> getInboundStagingRecords() {
		
		/*
		 * Interface Name must be equal to Interface Name batch parameter
		 * Status Flag must be "N"
		 * Source System Name must be equal to Source System Name batch parameter
		 * Target System Name must be equal to Target System Name batch parameter
		 */
		StringBuilder createUpdateMeterItemQueryStr = new StringBuilder();
		createUpdateMeterItemQueryStr.append(" SELECT ");
		createUpdateMeterItemQueryStr.append("	 STAGING_KEY ");
		createUpdateMeterItemQueryStr.append("   , LOGICAL_TRX_NUMBER ");
		createUpdateMeterItemQueryStr.append("   , CREATION_DATETIME ");
		createUpdateMeterItemQueryStr.append("   , ORIGINATING_KEY ");
		createUpdateMeterItemQueryStr.append(" FROM ");
		createUpdateMeterItemQueryStr.append("   XXL_INT_INBOUND_STG ");
		createUpdateMeterItemQueryStr.append(" WHERE ");
		createUpdateMeterItemQueryStr.append("   INTERFACE_NAME = :interfaceName ");
		createUpdateMeterItemQueryStr.append("   AND STATUS_FLAG = :statusFlag ");
		createUpdateMeterItemQueryStr.append("   AND SOURCE_SYSTEM_NAME = :sourceSystemName ");
		createUpdateMeterItemQueryStr.append("   AND TARGET_SYSTEM_NAME = :targetSystemName ");
		createUpdateMeterItemQueryStr.append(" ORDER BY STAGING_KEY ASC ");
		
		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement inboundStagingPrepStmt = createPreparedStatement(createUpdateMeterItemQueryStr.toString());
		PreparedStatement inboundStagingPrepStmt = createPreparedStatement(createUpdateMeterItemQueryStr.toString(), getClass().getName());
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		inboundStagingPrepStmt.bindString("interfaceName", parmServiceTaskType.getId().getTrimmedValue(), "INTERFACE_NAME");
		inboundStagingPrepStmt.bindString("statusFlag", CmInterfaceStatusLookup.constants.NEW.trimmedValue(), "STATUS_FLG");
		inboundStagingPrepStmt.bindString("sourceSystemName", parmSourceSystemName.trim(), "SOURCE_SYSTEM_NAME");
		inboundStagingPrepStmt.bindString("targetSystemName", parmTargetSystemName.trim(), "TARGET_SYSTEM_NAME");
		
		List<SQLResultRow> inboundStagingRow = inboundStagingPrepStmt.list();
		
		inboundStagingPrepStmt.close();
		
		return inboundStagingRow;
	}

	public Class<CmMeterItemCreateUpdateFromMaximoBatchWorker> getThreadWorkerClass() {
		return CmMeterItemCreateUpdateFromMaximoBatchWorker.class;
	}

	public static class CmMeterItemCreateUpdateFromMaximoBatchWorker extends
			CmMeterItemCreateUpdateFromMaximoBatchWorker_Gen {	
		
		// Constants
		private final String BLANK_VALUE = " ";
		private final String ERROR_CODE_DELIMITER = "-";
		private final String ERROR_SOURCE = "Logged by Target System";
		private final String XXL_INT_INBOUND_STG = "XXL_INT_INBOUND_STG";
		private final String XXL_INT_MTR_IN_STG = "XXL_INT_MTR_IN_STG";	
		private final String XXL_INT_MTR_CHAR_IN_STG = "XXL_INT_MTR_CHAR_IN_STG";
		private final String XXL_INT_ITEM_IN_STG = "XXL_INT_ITEM_IN_STG";
		private final String XXL_INT_ITEM_CHAR_IN_STG = "XXL_INT_ITEM_CHAR_IN_STG";
		
		// Soft parameters
		private ServiceTaskType parmServiceTaskType;
		private String parmSourceSystemName;
		private String parmTargetSystemName;
		private ItemType parmRegulatorItemType;
		private List<CharacteristicType_Id> meterCharTypeList = new ArrayList<CharacteristicType_Id>();
		// 2015-05-26. SMiran. Defect 3223676. Start Add
		private CharacteristicType parmMeterSiteCharType;
		// 2015-05-26. SMiran. Defect 3223676. End Add
				
		// Work Variables
		private CmInboundInterfaceStaging_Id stagingKey = null;
		private String logicalTransactionNumber = BLANK_VALUE;
		private DateTime stagingCreationDateTime = null;
		private SQLResultRow meterRow = null;
		private SQLResultRow itemRow = null;	
		private String originationTable = BLANK_VALUE;
		Bool childRecordFound = Bool.FALSE;		
		// 2015-06-16. SMiran. Defect 3236635. Start Add
		private int errorCount = 0;
		private int maxErrors = 0;
		// 2015-06-16. SMiran. Defect 3236635. End Add
		
		// Meter Variables
		private CmActionFlagLookup meterAction = null;
		private String meterBadgeNumber = BLANK_VALUE;		
		private MeterType_Id meterTypeId = null;
		private MeterStatusLookup meterStatus = null;
		private String meterSerialNumber = BLANK_VALUE;
		private Manufacturer_Id meterManufacturerId = null;
		private Model_Id meterModelId = null;
		private RetireReason_Id meterRetireReasonId = null;
		private String meterLongDescription = BLANK_VALUE;
		private Date meterReceiveDate = null;
		private Date meterRetireDate = null;
		
		// Meter Configuration Variables
		private DateTime meterConfigEffectiveDateTime = null;
		private MeterConfigurationType_Id meterConfigTypeId = null;
		
		// Register 1 Variables
		private BigInteger reg1NumberDigitsLeft = BigInteger.ZERO;
		private BigInteger reg1NumberDigitsRight = BigInteger.ZERO;
		private BigInteger reg1ReadSeq = BigInteger.ZERO;
		private UnitOfMeasure_Id reg1UomId = null;
		private TimeOfUse_Id reg1TouId = null;
		private BigDecimal reg1RegConst = BigDecimal.ZERO;
		private ConsumptionTypeLookup reg1ConsType = null;
		private HowToUseLookup reg1HowToUse = null;
		private BigDecimal reg1FullScale = BigDecimal.ZERO;
		private ReadOutType_Id reg1ReadOutTypeId = null;
		private Protocol_Id reg1ProtocolId = null;
		private BigDecimal reg1Tolerance = BigDecimal.ZERO;
		private String reg1VirtualChannelStr = BLANK_VALUE;
		private IntervalRegisterType_Id reg1IntRegisterTypeId = null;
		
		// Register 2 Variables
		private BigInteger reg2NumberDigitsLeft = BigInteger.ZERO;
		private BigInteger reg2NumberDigitsRight = BigInteger.ZERO;
		private BigInteger reg2ReadSeq = BigInteger.ZERO;
		private UnitOfMeasure_Id reg2UomId = null;
		private TimeOfUse_Id reg2TouId = null;
		private BigDecimal reg2RegConst = BigDecimal.ZERO;
		private ConsumptionTypeLookup reg2ConsType = null;
		private HowToUseLookup reg2HowToUse = null;
		private BigDecimal reg2FullScale = BigDecimal.ZERO;
		private ReadOutType_Id reg2ReadOutTypeId = null;
		private Protocol_Id reg2ProtocolId = null;
		private BigDecimal reg2Tolerance = BigDecimal.ZERO;
		private String reg2VirtualChannelStr = BLANK_VALUE;
		private IntervalRegisterType_Id reg2IntRegisterTypeId = null;
		
		// Meter Characteristics
		private List<CmCharacteristicTempData> meterCharList = new ArrayList<CmCharacteristicTempData>();
		
		// 2015-05-26. SMiran. Defect 3223676. Start Add
		private String meterSiteNumber = "";
		// 2015-05-26. SMiran. Defect 3223676. End Add
		
		// Item Variables
		private CmActionFlagLookup itemAction = null;
		private String itemBadgeNumber = BLANK_VALUE;		
		private ItemType_Id itemTypeId = null;
		private ItemStatusLookup itemStatus = null;
		private Manufacturer_Id itemManufacturerId = null;
		private Model_Id itemModelId = null;
		private String itemSerialNumber = BLANK_VALUE;
		private RetireReason_Id itemRetireReasonId = null;
		private String itemParentMeterSerialNumber = "";
		private String itemLongDescription = BLANK_VALUE;
		private Date itemReceiveDate = null;
		private Date itemRetireDate = null;
		private ServicePoint_Id itemParentSpId = null;
		// 2015-06-17. SMiran. Defect 3236052. Start Add
		private String itemSiteNumber = "";
		// 2015-06-17. SMiran. Defect 3236052. End Add
		
		// Item Characteristics
		private List<CmCharacteristicTempData> itemCharList = new ArrayList<CmCharacteristicTempData>();
		
		// Meter Helper
		CmMeterHelper meterHelper = CmMeterHelper.Factory.newInstance();
		// Item Helper
		CmItemHelper itemHelper = CmItemHelper.Factory.newInstance();	
		
		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
			
			// Get soft parameters
			parmServiceTaskType = this.getParameters().getSERVICE_TASK_TYPE();
			
			// Get BO elements
			BusinessObject serviceTaskTypeBo = parmServiceTaskType.getBusinessObject();
			BusinessObjectInstance serviceTaskType = BusinessObjectInstance.create(serviceTaskTypeBo);
			serviceTaskType.set("serviceTaskType", parmServiceTaskType.getId().getTrimmedValue()); 
			serviceTaskType = BusinessObjectDispatcher.read(serviceTaskType);	
			
			// Source System Name
			parmSourceSystemName = serviceTaskType.getString("sourceSystem");
			// Target System Name
			parmTargetSystemName = serviceTaskType.getString("targetSystem");
			// Regulator Item Type
			parmRegulatorItemType = new ItemType_Id(serviceTaskType.getGroup("stagingInterfaceDetails").getString("regulatorItemType")).getEntity();
			// Meter Characteristic Types
			COTSInstanceList meterCharTypesListStr = serviceTaskType.getGroup("stagingInterfaceDetails").getList("meterCharType");
			Iterator<COTSInstanceListNode> meterCharTypesListNodeIter = meterCharTypesListStr.iterator();
			while (meterCharTypesListNodeIter.hasNext()){
				COTSInstanceListNode charTypeNode = meterCharTypesListNodeIter.next();
				CharacteristicType_Id charTypeId = new CharacteristicType_Id(charTypeNode.getString("meterCharTypeCd"));
				meterCharTypeList.add(charTypeId);
			}
			// 2015-05-26. SMiran. Defect 3223676. Start Add
			parmMeterSiteCharType = new CharacteristicType_Id(serviceTaskType.getGroup("stagingInterfaceDetails")
					.getString("meterSiteCharType")).getEntity();
			// 2015-05-26. SMiran. Defect 3223676. End Add
			// 2015-06-16. SMiran. Defect 3236635. Start Add
			maxErrors = this.getParameters().getSoftMaxErrors().intValue();
			// 2015-06-16. SMiran. Defect 3236635. End Add
		}

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new CommitEveryUnitStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			// Initialize work variables
			initializeWorkVariables();
			
			// Get Staging Key
			stagingKey = (CmInboundInterfaceStaging_Id) unit.getPrimaryId();			
			// Get Logical Transaction Number
			logicalTransactionNumber = unit.getSupplementallData("logicalTransactionNumber").toString();			
			// Get Staging Record Creation Date Time
			stagingCreationDateTime = (DateTime)unit.getSupplementallData("creationDateTime");
			
			// Prior to processing any staging records, the batch process should validate the inbound data.
			validateInboundData();
			
			try{
				// Process Meter
				if (notNull(meterRow)){
					processMeter();
				}			
				// Process Item
				if (notNull(itemRow)){
					processItem();
				}
			}catch(ApplicationError e){
				addError(CustomMessageRepositoryMGE.cin181BaseError(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, e.getServerMessage().getMessageText()));
			}
			
			// Update Inbound Staging record to Complete
			updateInboundInterfaceStagingStatus(
					stagingKey.getStagingKey().trim()
					, CmInterfaceStatusLookup.constants.COMPLETE
					, this.getProcessDateTime());
			
			return true;
		}

		private void validateInboundData() {
			
			// Validate data in XXL_INT_MTR_IN_STG table
			validateInboundMeterData();
			
			// Validate data in XXL_INT_ITEM_IN_STG table
			validateInboundItemData();								
			
			if (childRecordFound.isFalse()){
				originationTable = XXL_INT_INBOUND_STG;
				addError(CustomMessageRepositoryMGE.cin181NoChildRecordsFound(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						));
			}
			
		}
		
		private void validateInboundMeterData(){			
			
			// Get record from Meter Inbound Staging Table
			StringBuilder getMeterQueryStr = new StringBuilder();
			getMeterQueryStr.append(" SELECT ");
			getMeterQueryStr.append(" 	ACTION ");
			getMeterQueryStr.append(" 	,BADGE_NBR ");
			getMeterQueryStr.append(" 	,MTR_TYPE ");
			getMeterQueryStr.append(" 	,MTR_STATUS ");
			getMeterQueryStr.append(" 	,MFG_CD ");
			getMeterQueryStr.append(" 	,MODEL_CD ");
			getMeterQueryStr.append(" 	,SERIAL_NBR ");
			getMeterQueryStr.append(" 	,RECEIVE_DATE ");
			getMeterQueryStr.append(" 	,RETIRE_DATE ");
			getMeterQueryStr.append(" 	,NVL(LONG_DESCR,' ') LONG_DESCR ");
			getMeterQueryStr.append(" 	,NVL(RETIRE_REASON,' ') RETIRE_REASON ");
			getMeterQueryStr.append(" 	,EFF_DTTM ");
			getMeterQueryStr.append(" 	,MTR_CONFIG_TYPE ");
			getMeterQueryStr.append(" 	,REG1_NBR_DGTS_LEFT ");
			getMeterQueryStr.append(" 	,NVL(REG1_NBR_DGTS_RIGHT,0) REG1_NBR_DGTS_RIGHT ");
			getMeterQueryStr.append(" 	,REG1_READ_SEQ ");
			getMeterQueryStr.append(" 	,REG1_UOM ");
			getMeterQueryStr.append(" 	,NVL(REG1_TOU,' ') REG1_TOU ");
			getMeterQueryStr.append(" 	,REG1_REG_CONST ");
			getMeterQueryStr.append(" 	,REG1_CONS_TYPE ");
			getMeterQueryStr.append(" 	,REG1_HOW_TO_USE ");
			getMeterQueryStr.append(" 	,NVL(REG1_FULL_SCALE,0) REG1_FULL_SCALE ");
			getMeterQueryStr.append(" 	,NVL(REG1_READ_OUT_TYPE,' ') REG1_READ_OUT_TYPE ");
			getMeterQueryStr.append(" 	,NVL(REG1_PROTOCOL,' ') REG1_PROTOCOL ");
			getMeterQueryStr.append(" 	,NVL(REG1_TOLERANCE,0) REG1_TOLERANCE ");
			getMeterQueryStr.append(" 	,NVL(REG1_VIRTUAL_CHANNEL,' ') REG1_VIRTUAL_CHANNEL ");
			getMeterQueryStr.append(" 	,NVL(REG1_INT_REGISTER,' ') REG1_INT_REGISTER ");
			getMeterQueryStr.append(" 	,NVL(REG2_NBR_DGTS_LEFT,0) REG2_NBR_DGTS_LEFT ");
			getMeterQueryStr.append(" 	,NVL(REG2_NBR_DGTS_RIGHT,0) REG2_NBR_DGTS_RIGHT ");
			getMeterQueryStr.append(" 	,NVL(REG2_READ_SEQ,0) REG2_READ_SEQ ");
			getMeterQueryStr.append(" 	,NVL(REG2_UOM,' ') REG2_UOM ");
			getMeterQueryStr.append(" 	,NVL(REG2_TOU,' ') REG2_TOU ");
			getMeterQueryStr.append(" 	,NVL(REG2_REG_CONST,0) REG2_REG_CONST ");
			getMeterQueryStr.append(" 	,NVL(REG2_CONS_TYPE,' ') REG2_CONS_TYPE ");
			getMeterQueryStr.append(" 	,NVL(REG2_HOW_TO_USE,' ') REG2_HOW_TO_USE ");
			getMeterQueryStr.append(" 	,NVL(REG2_FULL_SCALE,0) REG2_FULL_SCALE ");
			getMeterQueryStr.append(" 	,NVL(REG2_READ_OUT_TYPE,' ') REG2_READ_OUT_TYPE ");
			getMeterQueryStr.append(" 	,NVL(REG2_PROTOCOL,' ') REG2_PROTOCOL ");
			getMeterQueryStr.append(" 	,NVL(REG2_TOLERANCE,0) REG2_TOLERANCE ");
			getMeterQueryStr.append(" 	,NVL(REG2_VIRTUAL_CHANNEL,' ') REG2_VIRTUAL_CHANNEL ");
			getMeterQueryStr.append(" 	,NVL(REG2_INT_REGISTER,' ') REG2_INT_REGISTER ");
			getMeterQueryStr.append(" FROM ");
			getMeterQueryStr.append(" 	XXL_INT_MTR_IN_STG ");
			getMeterQueryStr.append(" WHERE ");
			getMeterQueryStr.append("   LOGICAL_TRX_NUMBER = :logicalTransactionNumber ");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement meterPrepStmt = createPreparedStatement(getMeterQueryStr.toString());
			PreparedStatement meterPrepStmt = createPreparedStatement(getMeterQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			meterPrepStmt.bindString("logicalTransactionNumber", logicalTransactionNumber, "LOGICAL_TRX_NUMBER");
			
			meterRow = meterPrepStmt.firstRow();
			meterPrepStmt.close();
			
			if (notNull(meterRow)){			
				
				childRecordFound = Bool.TRUE;
				originationTable = XXL_INT_MTR_IN_STG;
								
				// Validate Meter fields
				validateMeterFields();
				
				// 2015-05-26. SMiran. Defect 3220374. Start Change
				if (!meterStatus.isRetired()){
					// Validate Meter Configuration fields
					validateMeterConfigFields();				
				
					// Validate REG1 fields
					validateRegister1Fields();
				
					// Validate REG2 fields if populated
					reg2ReadSeq = meterRow.getInteger("REG2_READ_SEQ");
					if (reg2ReadSeq.intValue() != 0){					
						validateRegister2Fields();
					}
				}
				// 2015-05-26. SMiran. Defect 3220374. End Change
				
				// Validate data in XXL_INT_MTR_CHAR_IN_STG table
				validateInboundMeterCharData();
				
			}
		}

		private void validateMeterFields() {

			// ACTION is required
			String meterActionStr = meterRow.getString("ACTION").trim();
			if (isEmptyOrNull(meterActionStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "ACTION"));
			}else{
				// ACTION must be either "A" or "U"
				LookupField_Id lookupFieldId = new LookupField_Id("CM_ACT_FLG");
				LookupValue_Id lookupValueId = new LookupValue_Id(lookupFieldId, meterActionStr);					
				if (isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "ACTION"
							, meterActionStr));
				}else{
					meterAction = (CmActionFlagLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
			}
			
			// BADGE_NBR is required
			meterBadgeNumber = meterRow.getString("BADGE_NBR").trim();
			if (isEmptyOrNull(meterBadgeNumber)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "BADGE_NBR"));
			}

			// MTR_TYPE is required		
			String meterType = meterRow.getString("MTR_TYPE").trim();
			if (isEmptyOrNull(meterType)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "MTR_TYPE"));
			}else{
				meterTypeId = new MeterType_Id(meterType.trim());
				if (isNull(meterTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "MTR_TYPE"
							, meterType));
				}
			}
							
			// MTR_STATUS is required
			String meterStatusStr = meterRow.getString("MTR_STATUS").trim();
			if (isEmptyOrNull(meterStatusStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "MTR_STATUS"));
			}else{
				LookupField_Id lookupFieldId = new LookupField_Id("MTR_STATUS_FLG");
				LookupValue_Id lookupValueId = new LookupValue_Id(lookupFieldId, meterStatusStr);					
				if (isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "MTR_STATUS"
							, meterStatusStr));
				}else{
					meterStatus = (MeterStatusLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());					
				}
			}
			
			// MFG_CD is required
			String manufacturerStr = meterRow.getString("MFG_CD").trim();
			if (isEmptyOrNull(manufacturerStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "MFG_CD"));
			}else{
				meterManufacturerId = new Manufacturer_Id(manufacturerStr);
				if (isNull(meterManufacturerId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "MFG_CD"
							, manufacturerStr));
				}
			}
			
			// MODEL_CD is required	
			String modelStr = meterRow.getString("MODEL_CD").trim();
			if (isEmptyOrNull(modelStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "MODEL_CD"));
			}else{
				meterModelId = new Model_Id(meterManufacturerId, modelStr.trim());
				if (isNull(meterModelId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "MODEL_CD"
							, modelStr));
				}
			}
			
			// SERIAL_NBR is required
			meterSerialNumber = meterRow.getString("SERIAL_NBR").trim();
			if (isEmptyOrNull(meterSerialNumber)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "SERIAL_NBR"));
			}
			
			// RECEIVE_DATE is required
			meterReceiveDate = meterRow.getDate("RECEIVE_DATE");
			
			// RETIRE_DATE
			meterRetireDate = meterRow.getDate("RETIRE_DATE");
			if (meterStatus.isRetired()){
				if (isNull(meterRetireDate)){
					addError(CustomMessageRepositoryMGE.cin181Fld2ReqIfFld1(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, "RETIRE_DATE"
							, "MTR_STATUS"
							, "R"));
				}
			}
			
			// LONG_DESCR
			meterLongDescription = meterRow.getString("LONG_DESCR");
			
			// RETIRE_REASON must be valid if supplied
			String meterRetireReasonStr = meterRow.getString("RETIRE_REASON").trim();
			if (!isEmptyOrNull(meterRetireReasonStr)){
				meterRetireReasonId = new RetireReason_Id(meterRetireReasonStr);
				if (isNull(meterRetireReasonId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "RETIRE_REASON"
							, meterRetireReasonStr));
				}
			}else{
				if (meterStatus.isRetired()){
					addError(CustomMessageRepositoryMGE.cin181Fld2ReqIfFld1(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, "RETIRE_REASON"
							, "MTR_STATUS"
							, "R"));
				} 
			}
			
		}		

		private void validateMeterConfigFields() {

			// EFF_DTTM is required
			meterConfigEffectiveDateTime = meterRow.getDateTime("EFF_DTTM");
			if (isNull(meterConfigEffectiveDateTime)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "EFF_DTTM"));
			}
			
			// MTR_CONFIG_TYPE is required
			String meterConfigTypeStr = meterRow.getString("MTR_CONFIG_TYPE").trim();
			if (isEmptyOrNull(meterConfigTypeStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "MTR_CONFIG_TYPE"));
			}else{
				meterConfigTypeId = new MeterConfigurationType_Id(meterConfigTypeStr);
				if (isNull(meterConfigTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "MTR_CONFIG_TYPE"
							, meterConfigTypeStr));
				}
			}
			
		}

		private void validateRegister1Fields() {
			
			// REG1_READ_SEQ is required
			reg1ReadSeq = meterRow.getInteger("REG1_READ_SEQ");
			if (reg1ReadSeq.intValue() != 1){
				addError(CustomMessageRepositoryMGE.cin181fieldValueInv(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "REG1_READ_SEQ"
						, "1"));
			}
			
			// REG1_NBR_DGTS_LEFT is required
			reg1NumberDigitsLeft = meterRow.getInteger("REG1_NBR_DGTS_LEFT");
			if (reg1NumberDigitsLeft.intValue() == 0){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable	
						, "REG1_NBR_DGTS_LEFT"));
			}
			 
			// REG1_NBR_DGTS_RIGHT
			reg1NumberDigitsRight = meterRow.getInteger("REG1_NBR_DGTS_RIGHT");
			
			// REG1_UOM is required
			String reg1UomStr = meterRow.getString("REG1_UOM").trim();
			if (isEmptyOrNull(reg1UomStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "REG1_UOM"));
			}else{
				reg1UomId = new UnitOfMeasure_Id(reg1UomStr);
				if(isNull(reg1UomId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "REG1_UOM"
							, reg1UomStr));
				}
			}
			 
			// REG1_TOU must be valid if supplied
			String reg1TouStr = meterRow.getString("REG1_TOU").trim();
			if (!isEmptyOrNull(reg1TouStr)){
				reg1TouId = new TimeOfUse_Id(reg1TouStr);
				if(isNull(reg1TouId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "REG1_TOU"
							, reg1TouStr));
				}
			}
			
			// REG1_REG_CONST is required
			reg1RegConst = meterRow.getBigDecimal("REG1_REG_CONST");
			if (reg1RegConst.compareTo(BigDecimal.ZERO) == 0){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "REG1_REG_CONST"));
			}
			
			// REG1_CONS_TYPE is required
			String reg1ConsTypeStr = meterRow.getString("REG1_CONS_TYPE").trim();
			if (isEmptyOrNull(reg1ConsTypeStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "REG1_CONS_TYPE"));
			}else{
				LookupField_Id lookupFieldId = new LookupField_Id("CONSUM_SUB_FLG");
				LookupValue_Id lookupValueId = new LookupValue_Id(lookupFieldId, reg1ConsTypeStr);					
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "REG1_CONS_TYPE"
							, reg1ConsTypeStr));
				}else{
					reg1ConsType = (ConsumptionTypeLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
			}
			
			// REG1_HOW_TO_USE is required
			String reg1HowToUseStr = meterRow.getString("REG1_HOW_TO_USE").trim();
			if (isEmptyOrNull(reg1HowToUseStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "REG1_HOW_TO_USE"));
			}else{
				LookupField_Id lookupFieldId = new LookupField_Id("HOW_TO_USE_FLG");
				LookupValue_Id lookupValueId = new LookupValue_Id(lookupFieldId, reg1HowToUseStr);					
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "REG1_HOW_TO_USE"
							, reg1HowToUseStr));
				}else{
					reg1HowToUse = (HowToUseLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
			}
			
			// REG1_FULL_SCALE
			reg1FullScale = meterRow.getBigDecimal("REG1_FULL_SCALE");
			
			// REG1_READ_OUT_TYPE is required
			String reg1ReadOutTypeStr = meterRow.getString("REG1_READ_OUT_TYPE").trim();
			if (!isEmptyOrNull(reg1ReadOutTypeStr)){
				reg1ReadOutTypeId = new ReadOutType_Id(reg1ReadOutTypeStr);
				if (isNull(reg1ReadOutTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "REG1_READ_OUT_TYPE"
							, reg1ReadOutTypeStr));
				}
			}
			
			// REG1_PROTOCOL is required
			String reg1ProtocolStr = meterRow.getString("REG1_PROTOCOL").trim();
			if (!isEmptyOrNull(reg1ProtocolStr)){
				reg1ProtocolId = new Protocol_Id(reg1ProtocolStr);
				if (isNull(reg1ProtocolId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "REG1_PROTOCOL"
							, reg1ProtocolStr));
				}
			}
			
			// REG1_TOLERANCE
			reg1Tolerance = meterRow.getBigDecimal("REG1_TOLERANCE");
			
			// REG1_VIRTUAL_CHANNEL
			reg1VirtualChannelStr = meterRow.getString("REG1_VIRTUAL_CHANNEL").trim();
			
			// REG1_INT_REGISTER must be valid if supplied
			String reg1IntRegisterStr = meterRow.getString("REG1_INT_REGISTER").trim();
			if (!isEmptyOrNull(reg1IntRegisterStr)){
				reg1IntRegisterTypeId = new IntervalRegisterType_Id(reg1IntRegisterStr.trim());
				if (isNull(reg1IntRegisterTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "REG1_INT_REGISTER"
							, reg1IntRegisterStr));
				}
			}
			
		}
		
		private void validateRegister2Fields() {
			
			// REG2_READ_SEQ value should always be 2
			if (reg2ReadSeq.intValue() != 2){
				addError(CustomMessageRepositoryMGE.cin181fieldValueInv(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "REG2_READ_SEQ"
						, "2"));
			}
			
			// REG2_NBR_DGTS_LEFT is required
			reg2NumberDigitsLeft = meterRow.getInteger("REG2_NBR_DGTS_LEFT");
			if (reg2NumberDigitsLeft.intValue() == 0){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "REG2_NBR_DGTS_LEFT"));
			}
			 
			// REG2_NBR_DGTS_RIGHT
			reg2NumberDigitsRight = meterRow.getInteger("REG2_NBR_DGTS_RIGHT");
			
			// REG2_UOM is required
			String reg2UomStr = meterRow.getString("REG2_UOM").trim();
			if (isEmptyOrNull(reg2UomStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "REG2_UOM"));
			}else{
				reg2UomId = new UnitOfMeasure_Id(reg2UomStr);
				if(isNull(reg2UomId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "REG2_UOM"
							, reg2UomStr));
				}
			}
			 
			// REG2_TOU must be valid if supplied
			String reg2TouStr = meterRow.getString("REG2_TOU").trim();
			if (!isEmptyOrNull(reg2TouStr)){
				reg2TouId = new TimeOfUse_Id(reg2TouStr);
				if(isNull(reg2TouId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "REG2_TOU"
							, reg2TouStr));
				}
			}
			
			// REG2_REG_CONST is required
			reg2RegConst = meterRow.getBigDecimal("REG2_REG_CONST");
			if (reg2RegConst.compareTo(BigDecimal.ZERO) == 0){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "REG2_REG_CONST"));
			}
			
			// REG2_CONS_TYPE is required
			String reg2ConsTypeStr = meterRow.getString("REG2_CONS_TYPE").trim();
			if (isEmptyOrNull(reg2ConsTypeStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "REG2_CONS_TYPE"));
			}else{
				LookupField_Id lookupFieldId = new LookupField_Id("CONSUM_SUB_FLG");
				LookupValue_Id lookupValueId = new LookupValue_Id(lookupFieldId, reg2ConsTypeStr);						
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "REG2_CONS_TYPE"
							, reg2ConsTypeStr));
				}else{
					reg2ConsType = (ConsumptionTypeLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
			}
			
			// REG2_HOW_TO_USE is required
			String reg2HowToUseStr = meterRow.getString("REG2_HOW_TO_USE").trim();
			if (isEmptyOrNull(reg2HowToUseStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "REG2_HOW_TO_USE"));
			}else{
				LookupField_Id lookupFieldId = new LookupField_Id("HOW_TO_USE_FLG");
				LookupValue_Id lookupValueId = new LookupValue_Id(lookupFieldId, reg2HowToUseStr);						
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "REG2_HOW_TO_USE"
							, reg2HowToUseStr));
				}else{
					reg2HowToUse = (HowToUseLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
			}
			
			// REG2_FULL_SCALE
			reg2FullScale = meterRow.getBigDecimal("REG2_FULL_SCALE");
			
			// REG2_READ_OUT_TYPE is required
			String reg2ReadOutTypeStr = meterRow.getString("REG2_READ_OUT_TYPE").trim();
			if (!isEmptyOrNull(reg2ReadOutTypeStr)){
				reg2ReadOutTypeId = new ReadOutType_Id(reg2ReadOutTypeStr);
				if (isNull(reg2ReadOutTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "REG2_READ_OUT_TYPE"
							, reg2ReadOutTypeStr));
				}
			}
			
			// REG2_PROTOCOL is required
			String reg2ProtocolStr = meterRow.getString("REG2_PROTOCOL").trim();
			if (!isEmptyOrNull(reg2ProtocolStr)){
				reg2ProtocolId = new Protocol_Id(reg2ProtocolStr);
				if (isNull(reg2ProtocolId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "REG2_PROTOCOL"
							, reg2ProtocolStr));
				}
			}
			
			// REG2_TOLERANCE
			reg2Tolerance = meterRow.getBigDecimal("REG2_TOLERANCE");
			
			// REG2_VIRTUAL_CHANNEL
			reg2VirtualChannelStr = meterRow.getString("REG2_VIRTUAL_CHANNEL").trim();
			
			// REG2_INT_REGISTER must be valid if supplied
			String reg2IntRegisterStr = meterRow.getString("REG2_INT_REGISTER").trim();

			if (!isEmptyOrNull(reg2IntRegisterStr)){
				reg2IntRegisterTypeId = new IntervalRegisterType_Id(reg2IntRegisterStr.trim());
				if (isNull(reg2IntRegisterTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "REG2_INT_REGISTER"
							, reg2IntRegisterStr));
				}
			}
			
		}

		private void validateInboundMeterCharData(){
			
			originationTable = XXL_INT_MTR_CHAR_IN_STG;
			
			// Get record from Item Inbound Staging Table
			StringBuilder getMeterCharQueryStr = new StringBuilder();
			getMeterCharQueryStr.append(" SELECT ");
			getMeterCharQueryStr.append(" 	CHAR_TYPE ");
			getMeterCharQueryStr.append(" 	,EFFDT ");
			getMeterCharQueryStr.append(" 	,CHAR_VAL ");
			getMeterCharQueryStr.append(" FROM ");
			getMeterCharQueryStr.append(" 	XXL_INT_MTR_CHAR_IN_STG ");
			getMeterCharQueryStr.append(" WHERE ");
			getMeterCharQueryStr.append("   LOGICAL_TRX_NUMBER = :logicalTransactionNumber ");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement meterCharPrepStmt = createPreparedStatement(getMeterCharQueryStr.toString());
			PreparedStatement meterCharPrepStmt = createPreparedStatement(getMeterCharQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			meterCharPrepStmt.bindString("logicalTransactionNumber", logicalTransactionNumber, "LOGICAL_TRX_NUMBER");
			
			QueryIterator<SQLResultRow> meterCharQueryIter = meterCharPrepStmt.iterate();
			while (meterCharQueryIter.hasNext()){
				
				SQLResultRow meterCharRow = meterCharQueryIter.next();
				String charTypeStr = meterCharRow.getString("CHAR_TYPE").trim();
				String charValStr = meterCharRow.getString("CHAR_VAL").trim();
				Date effectiveDate = meterCharRow.getDate("EFFDT");
				
				// Characteristic Type is required
				if (isEmptyOrNull(charTypeStr)){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "CHAR_TYPE"));
				}
				// Characteristic Type must be valid
				CharacteristicType_Id charTypeId = new CharacteristicType_Id(charTypeStr);
				if (isNull(charTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "CHAR_TYPE"
							, charTypeStr));
				}
				// Characteristic Type must be valid for Meter Type
				CharacteristicTypeMeterType_Id charTypeMeterTypeId = new CharacteristicTypeMeterType_Id(meterTypeId,charTypeId);
				if (isNull(charTypeMeterTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181CharTypeInvForType(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, charTypeId.getIdValue().trim()
							, "Meter Type"
							, meterTypeId.getIdValue().trim()));
				}
				
				// Characteristic Value must be supplied
				if (isEmptyOrNull(charValStr)){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "CHAR_VAL"));
				}
				
				// If Char Type is Predefined, Char Type and Char Value combination must be valid
				if (charTypeId.getEntity().getCharacteristicType().isPredefinedValue()){
					CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charTypeId, charValStr);
					if (isNull(charValueId.getEntity())){
						addError(CustomMessageRepositoryMGE.cin181CharTypeValInv(
								stagingKey.getStagingKey().trim()
								, logicalTransactionNumber
								, charTypeStr.trim()
								, charValStr.trim()));
					}
				}
				
				// Effective Date must be supplied
				if (isNull(effectiveDate)){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "EFFDT"));
				}
				CmCharacteristicTempData meterCharTempData = CmCharacteristicTempData.Factory.newInstance();
				meterCharTempData.setCharacteristicType(charTypeId.getEntity());
				meterCharTempData.setCharVal(charValStr);
				meterCharTempData.setEffectiveDate(effectiveDate);
				meterCharList.add(meterCharTempData);
				
				// 2015-05-26. SMiran. Defect 3223676. Start Add
				if (charTypeId.equals(parmMeterSiteCharType.getId())){
					meterSiteNumber = charValStr;
				}
				// 2015-05-26. SMiran. Defect 3223676. End Add
			}
			
			meterCharPrepStmt.close();
			meterCharQueryIter.close();
		}
		
		private void validateInboundItemData(){
			
			// Get record from Item Inbound Staging Table
			StringBuilder getItemQueryStr = new StringBuilder();
			getItemQueryStr.append(" SELECT ");
			getItemQueryStr.append(" 	ACTION ");
			getItemQueryStr.append(" 	,BADGE_NBR ");
			getItemQueryStr.append(" 	,ITEM_TYPE ");
			getItemQueryStr.append(" 	,ITEM_STATUS ");
			getItemQueryStr.append(" 	,MFG_CD ");
			getItemQueryStr.append(" 	,MODEL_CD ");
			getItemQueryStr.append(" 	,SERIAL_NBR ");
			getItemQueryStr.append(" 	,RECEIVE_DATE ");
			getItemQueryStr.append(" 	,RETIRE_DATE ");
			getItemQueryStr.append(" 	,NVL(LONG_DESCR,' ') LONG_DESCR ");
			getItemQueryStr.append(" 	,NVL(RETIRE_REASON,' ') RETIRE_REASON ");
			getItemQueryStr.append(" 	,NVL(PARENT_MTR,' ') PARENT_MTR ");
			getItemQueryStr.append(" 	,NVL(PARENT_SP,' ') PARENT_SP ");
			// 2015-06-17. SMiran. Defect 3236052. Start Add
			getItemQueryStr.append(" 	,NVL(SITEID,' ') SITEID ");
			// 2015-06-17. SMiran. Defect 3236052. End Add			
			getItemQueryStr.append(" FROM ");
			getItemQueryStr.append(" 	XXL_INT_ITEM_IN_STG ");
			getItemQueryStr.append(" WHERE ");
			getItemQueryStr.append("   LOGICAL_TRX_NUMBER = :logicalTransactionNumber ");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement itemPrepStmt = createPreparedStatement(getItemQueryStr.toString());
			PreparedStatement itemPrepStmt = createPreparedStatement(getItemQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			itemPrepStmt.bindString("logicalTransactionNumber", logicalTransactionNumber, "LOGICAL_TRX_NUMBER");
			
			itemRow = itemPrepStmt.firstRow();
			itemPrepStmt.close();
			
			if (notNull(itemRow)){
				childRecordFound = Bool.TRUE;
				originationTable = XXL_INT_ITEM_IN_STG;								

				// Validate Item fields
				validateItemFields();
				
				// Validate data in XXL_INT_ITEM_CHAR_IN_STG table
				validateInboundItemCharData();	

			}
		}
		
		private void validateItemFields() {

			// ACTION is required
			String itemActionStr = itemRow.getString("ACTION").trim();
			if (isEmptyOrNull(itemActionStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "ACTION"));
			}else{
				// ACTION must either be "A" or "U"
				LookupField_Id lookupFieldId = new LookupField_Id("CM_ACT_FLG");
				LookupValue_Id lookupValueId = new LookupValue_Id(lookupFieldId, itemActionStr);					
				if (isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "ACTION"
							, itemActionStr));
				}else{
					itemAction = (CmActionFlagLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
			}
			
			// BADGE_NBR is required
			itemBadgeNumber = itemRow.getString("BADGE_NBR").trim();
			if (isEmptyOrNull(itemBadgeNumber)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "BADGE_NBR"));
			}
			
			// ITEM_TYPE is required
			String itemTypeStr = itemRow.getString("ITEM_TYPE").trim();
			if (isEmptyOrNull(itemTypeStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "ITEM_TYPE"));
			}else{
				itemTypeId = new ItemType_Id(itemTypeStr);
				if (isNull(itemTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "ITEM_TYPE"
							, itemTypeStr));
				}
			}
			
			// ITEM_STATUS is required
			String itemStatusStr = itemRow.getString("ITEM_STATUS").trim();
			if (isEmptyOrNull(itemStatusStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "ITEM_STATUS"));
			}else{
				LookupField_Id lookupFieldId = new LookupField_Id("ITEM_STATUS_FLG");
				LookupValue_Id lookupValueId = new LookupValue_Id(lookupFieldId, itemStatusStr);					
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "ITEM_STATUS"
							, itemStatusStr));
				}else{
					itemStatus = (ItemStatusLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
			}
			
			// MFG_CD is required
			String itemManufacturerStr = itemRow.getString("MFG_CD").trim();
			if (isEmptyOrNull(itemManufacturerStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "MFG_CD"));
			}else{
				itemManufacturerId = new Manufacturer_Id(itemManufacturerStr);
				if (isNull(itemManufacturerId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "MFG_CD"
							, itemManufacturerStr));
				}
			}
			
			// MODEL_CD is required	
			String itemModelStr = itemRow.getString("MODEL_CD").trim();
			if (isEmptyOrNull(itemModelStr)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "MODEL_CD"));
			}else{
				itemModelId = new Model_Id(itemManufacturerId, itemModelStr.trim());
				if (isNull(itemModelId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "MODEL_CD"
							, itemModelStr));
				}
			}
			
			// SERIAL_NBR is required
			itemSerialNumber = itemRow.getString("SERIAL_NBR").trim();
			if (isEmptyOrNull(itemSerialNumber)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "SERIAL_NBR"));
			}
			
			// RECEIVE DATE
			itemReceiveDate = itemRow.getDate("RECEIVE_DATE");
			
			// RETIRE DATE
			itemRetireDate = itemRow.getDate("RETIRE_DATE");
			if (itemStatus.isRetired()){
				if (isNull(itemRetireDate)){
					addError(CustomMessageRepositoryMGE.cin181Fld2ReqIfFld1(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, "RETIRE_DATE"
							, "ITEM_STATUS"
							, "R"));
				}
			}
			
			// LONG DESCRIPTION
			itemLongDescription = itemRow.getString("LONG_DESCR");	
			
			// RETIRE_REASON must be valid if supplied
			String itemRetireReasonStr = itemRow.getString("RETIRE_REASON").trim();
			if (!isEmptyOrNull(itemRetireReasonStr)){
				itemRetireReasonId = new RetireReason_Id(itemRetireReasonStr);
				if (isNull(itemRetireReasonId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "RETIRE_REASON"
							, itemRetireReasonStr));
				}
			}else{
				if (itemStatus.isRetired()){
					addError(CustomMessageRepositoryMGE.cin181Fld2ReqIfFld1(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, "RETIRE_REASON"
							, "ITEM_STATUS"
							, "R"));
				}
			}
			
			// PARENT_MTR
			itemParentMeterSerialNumber = itemRow.getString("PARENT_MTR").trim();
			
			// PARENT_SP must be valid if supplied
			String itemParentSpStr = itemRow.getString("PARENT_SP").trim();
			if (!isEmptyOrNull(itemParentSpStr)){
				itemParentSpId = new ServicePoint_Id(itemParentSpStr);
				if (isNull(itemParentSpId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "PARENT_SP"
							, itemParentSpStr));
				}
			}
			
			// If item type is regulator, PARENT_MTR should not be populated.
			if (itemTypeId.equals(parmRegulatorItemType.getId()) && !isEmptyOrNull(itemParentMeterSerialNumber)){
				addError(CustomMessageRepositoryMGE.cin181ItemIsRegulator(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, "PARENT_MTR"));
			}
			
			// If item type is not regulator, PARENT_SP should not be populated.
			if (!itemTypeId.equals(parmRegulatorItemType.getId()) && !isEmptyOrNull(itemParentSpStr)){
				addError(CustomMessageRepositoryMGE.cin181ItemIsNotRegulator(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, "PARENT_SP"));
			}
			
			// 2015-06-17. SMiran. Defect 3236052. Start Add
			itemSiteNumber = itemRow.getString("SITEID").trim();
			if (isEmptyOrNull(itemSiteNumber)){
				addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
						stagingKey.getStagingKey().trim()
						, logicalTransactionNumber
						, originationTable
						, "SITEID"));
			}
			// 2015-06-17. SMiran. Defect 3236052. End Add			
		}

		private void validateInboundItemCharData(){
			
			originationTable = XXL_INT_ITEM_CHAR_IN_STG;
			
			// Get record from Item Characteristic Inbound Staging Table
			StringBuilder getItemCharQueryStr = new StringBuilder();
			getItemCharQueryStr.append(" SELECT ");
			getItemCharQueryStr.append(" 	CHAR_TYPE ");
			getItemCharQueryStr.append(" 	,EFFDT ");
			getItemCharQueryStr.append(" 	,CHAR_VAL ");
			getItemCharQueryStr.append(" FROM ");
			getItemCharQueryStr.append(" 	XXL_INT_ITEM_CHAR_IN_STG ");
			getItemCharQueryStr.append(" WHERE ");
			getItemCharQueryStr.append("   LOGICAL_TRX_NUMBER = :logicalTransactionNumber ");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement itemCharPrepStmt = createPreparedStatement(getItemCharQueryStr.toString());
			PreparedStatement itemCharPrepStmt = createPreparedStatement(getItemCharQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			itemCharPrepStmt.bindString("logicalTransactionNumber", logicalTransactionNumber, "LOGICAL_TRX_NUMBER");
			
			QueryIterator<SQLResultRow> itemCharQueryIter = itemCharPrepStmt.iterate();
			while (itemCharQueryIter.hasNext()){
				SQLResultRow itemCharRow = itemCharQueryIter.next();
				String charTypeStr = itemCharRow.getString("CHAR_TYPE").trim();
				String charValStr = itemCharRow.getString("CHAR_VAL").trim();
				Date effectiveDate = itemCharRow.getDate("EFFDT");
				
				// Characteristic Type must be supplied
				if (isEmptyOrNull(charTypeStr)){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "CHAR_TYPE"));
				}
				// Characteristic Type must be valid
				CharacteristicType_Id charTypeId = new CharacteristicType_Id(charTypeStr);
				if (isNull(charTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValInv(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "CHAR_TYPE"
							, charTypeStr));
				}
				
				// Characteristic Type must be valid for Item Type
				CharacteristicTypeItemType_Id charTypeItemTypeId = new CharacteristicTypeItemType_Id(itemTypeId,charTypeId);
				if (isNull(charTypeItemTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cin181CharTypeInvForType(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, charTypeId.getIdValue().trim()
							, "Item Type"
							, itemTypeId.getIdValue().trim()));
				}
				
				// Characteristic Value must be supplied
				if (isEmptyOrNull(charValStr)){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "CHAR_VAL"));
				}
				
				// If Char Type is Predefined, Char Type and Char Value combination must be valid
				if (charTypeId.getEntity().getCharacteristicType().isPredefinedValue()){
					CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charTypeId, charValStr);
					if (isNull(charValueId.getEntity())){
						addError(CustomMessageRepositoryMGE.cin181CharTypeValInv(
								stagingKey.getStagingKey().trim()
								, logicalTransactionNumber
								, charTypeStr.trim()
								, charValStr.trim()));
					}
				}
				
				// Effective Date must be supplied
				if (isNull(effectiveDate)){
					addError(CustomMessageRepositoryMGE.cin181TableFieldValMiss(
							stagingKey.getStagingKey().trim()
							, logicalTransactionNumber
							, originationTable
							, "EFFDT"));
				}	
				CmCharacteristicTempData itemCharTempData = CmCharacteristicTempData.Factory.newInstance();
				itemCharTempData.setCharacteristicType(charTypeId.getEntity());
				itemCharTempData.setCharVal(charValStr);
				itemCharTempData.setEffectiveDate(effectiveDate);
				itemCharList.add(itemCharTempData);			
				
			}
			itemCharPrepStmt.close();
			itemCharQueryIter.close();
			
		}
		
		private void processMeter() {
		
			originationTable = XXL_INT_MTR_IN_STG;
			
			// Action
			meterHelper.setMeterAction(meterAction);
			
			// Meter Variables
			meterHelper.setBadgeNumber(meterBadgeNumber);		
			meterHelper.setMeterTypeId(meterTypeId);
			meterHelper.setStatus(meterStatus);
			meterHelper.setSerialNumber(meterSerialNumber);
			meterHelper.setModelId(meterModelId);
			meterHelper.setRetireReasonId(meterRetireReasonId);
			meterHelper.setLongDescription(meterLongDescription);
			meterHelper.setReceiveDate(meterReceiveDate);
			meterHelper.setRetireDate(meterRetireDate);
			
			// Meter Configuration Variables
			meterHelper.setEffectiveDateTime(meterConfigEffectiveDateTime);
			meterHelper.setMeterConfigurationType(meterConfigTypeId);
			
			// Register 1 Variables
			meterHelper.setReg1NumberDigitsLeft(reg1NumberDigitsLeft);
			meterHelper.setReg1NumberDigitsRight(reg1NumberDigitsRight);
			meterHelper.setReg1ReadSeq(reg1ReadSeq);
			meterHelper.setReg1UomId(reg1UomId);
			meterHelper.setReg1TouId(reg1TouId);
			meterHelper.setReg1RegConst(reg1RegConst);
			meterHelper.setReg1ConsType(reg1ConsType);
			meterHelper.setReg1HowToUse(reg1HowToUse);
			meterHelper.setReg1FullScale(reg1FullScale);
			meterHelper.setReg1ReadOutTypeId(reg1ReadOutTypeId);
			meterHelper.setReg1ProtocolId(reg1ProtocolId);
			meterHelper.setReg1Tolerance(reg1Tolerance);
			meterHelper.setReg1VirtualChannelStr(reg1VirtualChannelStr);
			meterHelper.setReg1IntRegisterTypeId(reg1IntRegisterTypeId);
			
			// Register 2 Variables
			meterHelper.setReg2NumberDigitsLeft(reg2NumberDigitsLeft);
			meterHelper.setReg2NumberDigitsRight(reg2NumberDigitsRight);
			meterHelper.setReg2ReadSeq(reg2ReadSeq);
			meterHelper.setReg2UomId(reg2UomId);
			meterHelper.setReg2TouId(reg2TouId);
			meterHelper.setReg2RegConst(reg2RegConst);
			meterHelper.setReg2ConsType(reg2ConsType);
			meterHelper.setReg2HowToUse(reg2HowToUse);
			meterHelper.setReg2FullScale(reg2FullScale);
			meterHelper.setReg2ReadOutTypeId(reg2ReadOutTypeId);
			meterHelper.setReg2ProtocolId(reg2ProtocolId);
			meterHelper.setReg2Tolerance(reg2Tolerance);
			meterHelper.setReg2VirtualChannelStr(reg2VirtualChannelStr);
			meterHelper.setReg2IntRegisterTypeId(reg2IntRegisterTypeId);
			
			// Meter Characteristics
			meterHelper.setMeterCharacteristics(meterCharList);
			
			// 2015-05-26. SMiran. Defect 3223676. Start Add
			meterHelper.setMeterSiteCharType(parmMeterSiteCharType);
			meterHelper.setMeterSiteNumber(meterSiteNumber);
			// 2015-05-26. SMiran. Defect 3223676. End Add
			
			// Staging Key and Logical Transaction Number
			meterHelper.setStagingKey(stagingKey.getStagingKey().trim());
			meterHelper.setLogicalTransactionNumber(logicalTransactionNumber);
			meterHelper.setStagingCreationDateTime(stagingCreationDateTime);
			
			// Set Meter Char Types
			meterHelper.setMeterCharTypeList(meterCharTypeList);
			
			// Call routine
			meterHelper.createOrUpdateMeter();
			
		}
		
		private void processItem() {
			
			originationTable = XXL_INT_ITEM_IN_STG;
			
			itemHelper.setItemAction(itemAction);			
			itemHelper.setItemBadgeNumber(itemBadgeNumber);
			itemHelper.setItemTypeId(itemTypeId);
			itemHelper.setItemStatus(itemStatus);
			itemHelper.setItemModelId(itemModelId);
			itemHelper.setItemSerialNumber(itemSerialNumber);
			itemHelper.setItemRetireReasonId(itemRetireReasonId);			
			itemHelper.setItemParentMeterSeriaNumber(itemParentMeterSerialNumber);
			itemHelper.setItemLongDescription(itemLongDescription);
			itemHelper.setItemReceiveDate(itemReceiveDate);
			itemHelper.setItemRetireDate(itemRetireDate);
			itemHelper.setItemParentSpId(itemParentSpId);
			itemHelper.setItemCharList(itemCharList);
			
			// 2015-06-17. SMiran. Defect 3236052. Start Add
			itemHelper.setMeterSiteCharType(parmMeterSiteCharType);
			itemHelper.setItemSiteNumber(itemSiteNumber);
			// 2015-06-17. SMiran. Defect 3236052. End Add
			
			// Pass Regulator Item Type
			itemHelper.setRegulatorItemType(parmRegulatorItemType);
			
			// Staging Key and Logical Transaction Number
			itemHelper.setStagingKey(stagingKey.getStagingKey().trim());
			itemHelper.setLogicalTransactionNumber(logicalTransactionNumber);
			itemHelper.setStagingCreationDateTime(stagingCreationDateTime);
			
			itemHelper.createOrUpdateItem();
		}
		
		@Override
		public boolean handleApplicationError(ApplicationError applicationError, ThreadWorkUnit unit) {
			
			// 2015-06-16. SMiran. Defect 3236635. Start Add
			errorCount++;
			if (errorCount > maxErrors){
				throw new RunAbortedException(CustomMessageRepositoryMGE.commMaxErrorLimitExceeded(String.valueOf(maxErrors)));
			}
			// 2015-06-16. SMiran. Defect 3236635. End Add
			
			CmInboundInterfaceStaging_Id inboundInterfaceStagingId = (CmInboundInterfaceStaging_Id) unit.getPrimaryId();
			String inboundInterfaceStagingKey = inboundInterfaceStagingId.getStagingKey();
			
			// Inboun Interface Staging record update date time
			DateTime stagingUpdateDateTime = this.getProcessDateTime();
			
			// Update Inbound Interface Staging record to Error status.
			updateInboundInterfaceStagingStatus(inboundInterfaceStagingKey.trim(), CmInterfaceStatusLookup.constants.ERROR, stagingUpdateDateTime);
			
			// Retrieve details of the error encountered.
			String errorCategory = BLANK_VALUE;
			String errorNumber = BLANK_VALUE;
			String errorCode = BLANK_VALUE;
			String errorDescription = BLANK_VALUE;
			String additionalInfo = BLANK_VALUE;
			if(notNull(applicationError)){
				ServerMessage serverMessage = applicationError.getServerMessage();
				if(notNull(serverMessage)){
					errorCategory = serverMessage.getCategory().toString().trim();
					errorNumber = serverMessage.getNumber().toString().trim();
					errorCode = errorCategory.concat(ERROR_CODE_DELIMITER).concat(errorNumber);
					errorDescription = serverMessage.getMessageText().trim();
					if (serverMessage.getLongDescription().length() > 0){
						if (serverMessage.getLongDescription().length() > 200){
							additionalInfo = serverMessage.getLongDescription().substring(0, 200);
						}else{
							additionalInfo = serverMessage.getLongDescription();
						}
					}					
				}
			}
			
			// Create a new Interface Error Log record for the error encountered.
			DateTime stagingCreationDateTime = (DateTime) unit.getSupplementallData("creationDateTime");			
			String logicalTransactionNumber = (String) unit.getSupplementallData("logicalTransactionNumber");
			String originatingKey = (String) unit.getSupplementallData("originatingKey");
			CmInterfaceErrorLogMaintenance interfaceErrorLogMaintenance = CmInterfaceErrorLogMaintenance.Factory.newInstance();
			interfaceErrorLogMaintenance.createInterfaceErrorLog(
					parmSourceSystemName, 
					parmTargetSystemName, 
					logicalTransactionNumber, 
					originationTable, 
					parmServiceTaskType.getId().getTrimmedValue(), 
					errorCode,
					errorDescription, 
					stagingCreationDateTime, 
					stagingUpdateDateTime, 
					parmTargetSystemName, 
					originatingKey, 
					additionalInfo, 
					ERROR_SOURCE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE);
			
			return true;
			
		}
		
		private void updateInboundInterfaceStagingStatus(String stagingKey, CmInterfaceStatusLookup status, DateTime dateTime){
			StringBuilder updateString = new StringBuilder("");
			updateString.append(" UPDATE ");
			updateString.append("	XXL_INT_INBOUND_STG IB ");
			updateString.append(" SET ");
			updateString.append("	IB.STATUS_FLAG = :status ");
			updateString.append("   , IB.UPDATE_DATETIME = :processDateTime ");
			updateString.append(" WHERE ");
			updateString.append("	IB.STAGING_KEY = :stagingKey ");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement updateSQL = createPreparedStatement(updateString.toString());
			PreparedStatement updateSQL = createPreparedStatement(updateString.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			updateSQL.bindString("stagingKey", stagingKey, "STAGING_KEY");
			updateSQL.bindDateTime("processDateTime", dateTime);
			updateSQL.bindString("status", status.trimmedValue(), "STATUS_FLAG");
			updateSQL.execute();
			updateSQL.close();		
		}
		
		private void initializeWorkVariables() {

			// Work Variables
			stagingKey = null;
			logicalTransactionNumber = BLANK_VALUE;
			stagingCreationDateTime = null;
			meterRow = null;
			itemRow = null;	
			originationTable = BLANK_VALUE;
			childRecordFound = Bool.FALSE;
			
			// Meter Variables
			meterAction = null;
			meterBadgeNumber = BLANK_VALUE;		
			meterTypeId = null;
			meterStatus = null;
			meterSerialNumber = BLANK_VALUE;
			meterManufacturerId = null;
			meterModelId = null;
			meterRetireReasonId = null;
			meterLongDescription = BLANK_VALUE;
			meterReceiveDate = null;
			meterRetireDate = null;
			
			// Meter Configuration Variables
			meterConfigEffectiveDateTime = null;
			meterConfigTypeId = null;
			
			// Register 1 Variables
			reg1NumberDigitsLeft = BigInteger.ZERO;
			reg1NumberDigitsRight = BigInteger.ZERO;
			reg1ReadSeq = BigInteger.ZERO;
			reg1UomId = null;
			reg1TouId = null;
			reg1RegConst = BigDecimal.ZERO;
			reg1ConsType = null;
			reg1HowToUse = null;
			reg1FullScale = BigDecimal.ZERO;
			reg1ReadOutTypeId = null;
			reg1ProtocolId = null;
			reg1Tolerance = BigDecimal.ZERO;
			reg1VirtualChannelStr = BLANK_VALUE;
			reg1IntRegisterTypeId = null;
			
			// Register 2 Variables
			reg2NumberDigitsLeft = BigInteger.ZERO;
			reg2NumberDigitsRight = BigInteger.ZERO;
			reg2ReadSeq = BigInteger.ZERO;
			reg2UomId = null;
			reg2TouId = null;
			reg2RegConst = BigDecimal.ZERO;
			reg2ConsType = null;
			reg2HowToUse = null;
			reg2FullScale = BigDecimal.ZERO;
			reg2ReadOutTypeId = null;
			reg2ProtocolId = null;
			reg2Tolerance = BigDecimal.ZERO;
			reg2VirtualChannelStr = BLANK_VALUE;
			reg2IntRegisterTypeId = null;
			
			// Meter Characteristics
			meterCharList = new ArrayList<CmCharacteristicTempData>();
			
			// 2015-05-26. SMiran. Defect 3223676. Start Add
			meterSiteNumber = "";
			// 2015-05-26. SMiran. Defect 3223676. End Add
			
			// Item Variables
			itemAction = null;
			itemBadgeNumber = BLANK_VALUE;		
			itemTypeId = null;
			itemStatus = null;
			itemManufacturerId = null;
			itemModelId = null;
			itemSerialNumber = BLANK_VALUE;
			itemRetireReasonId = null;
			itemParentMeterSerialNumber = "";
			itemLongDescription = BLANK_VALUE;
			itemReceiveDate = null;
			itemRetireDate = null;
			itemParentSpId = null;
			// 2015-06-17. SMiran. Defect 3236052. Start Add
			itemSiteNumber = "";
			// 2015-06-17. SMiran. Defect 3236052. End Add
			
			// Item Characteristics
			itemCharList = new ArrayList<CmCharacteristicTempData>();
			
			// Meter Helper
			meterHelper = CmMeterHelper.Factory.newInstance();
			// Item Helper
			itemHelper = CmItemHelper.Factory.newInstance();
			
		}

	}

}