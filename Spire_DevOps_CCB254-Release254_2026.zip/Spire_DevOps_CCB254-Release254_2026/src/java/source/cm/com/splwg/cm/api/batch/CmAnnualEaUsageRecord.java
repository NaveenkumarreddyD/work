package com.splwg.cm.api.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.shared.common.StringUtilities;

public class CmAnnualEaUsageRecord {

    // Constants
    private static final String IS_PARTIAL_BILL_CHECKMARK = "X";
    private static final BigDecimal ONE_HUNDRED = new BigDecimal(100);
    
    // Values
    private String reportInfo1;
    private String applicantsAccountNumber;
    private String reportInfo2;
    private List<MonthDataElement> monthDataElementList = new ArrayList<MonthDataElement>();
    private BigDecimal outstandingBalanceBeforeEaPayment;
    private String filler1;
    private BigDecimal creditBalanceAsOfPresent;
    private String filler2;
    private BigDecimal creditBalanceBeforeEaPayment;
    private String filler3;
    private BigDecimal creditBalanceRefundedToCustomer;
    private String filler4;
    private BigDecimal creditBalanceRefundedToDss;
    private String filler5;
    
    public class MonthDataElement {
        
        // Values
        private BigInteger year;
        private BigInteger month;
        private BigDecimal usage;
        private String filler1;
        private BigDecimal billedAmount;
        private String filler2;
        private Bool isPartialBill;
        
        public MonthDataElement(String rawMonthDataElement) {
            
            year = new BigInteger(rawMonthDataElement.substring(0, 2));
            month = new BigInteger(rawMonthDataElement.substring(2, 4));
            usage = new BigDecimal(rawMonthDataElement.substring(4, 12));
            filler1 = rawMonthDataElement.substring(12, 13);
            billedAmount = new BigDecimal(rawMonthDataElement.substring(13, 19));
            filler2 = rawMonthDataElement.substring(19, 20);
            isPartialBill = (StringUtilities.isBlankOrNull(rawMonthDataElement.substring(20))) ? Bool.FALSE : Bool.TRUE;
            
        }
        
        public BigInteger getYear() {
            return year;
        }

        public BigInteger getMonth() {
            return month;
        }

        public void setUsage(BigDecimal usage) {
            this.usage = usage;
        }
        
        public void setBilledAmount(BigDecimal billedAmount) {
            this.billedAmount = billedAmount;
        }
        
        public void setIsPartialBill(Bool isPartialBill) {
            this.isPartialBill = isPartialBill;
        }
        
    }
    
    public CmAnnualEaUsageRecord(String rawUsageRecord) {
        
        reportInfo1 = rawUsageRecord.substring(0, 122);
        applicantsAccountNumber = rawUsageRecord.substring(122, 132);
        reportInfo2 = rawUsageRecord.substring(132, 234);
        monthDataElementList.add(new MonthDataElement(rawUsageRecord.substring(234, 255)));
        monthDataElementList.add(new MonthDataElement(rawUsageRecord.substring(255, 276)));
        monthDataElementList.add(new MonthDataElement(rawUsageRecord.substring(276, 297)));
        monthDataElementList.add(new MonthDataElement(rawUsageRecord.substring(297, 318)));
        monthDataElementList.add(new MonthDataElement(rawUsageRecord.substring(318, 339)));
        monthDataElementList.add(new MonthDataElement(rawUsageRecord.substring(339, 360)));
        monthDataElementList.add(new MonthDataElement(rawUsageRecord.substring(360, 381)));
        monthDataElementList.add(new MonthDataElement(rawUsageRecord.substring(381, 402)));
        monthDataElementList.add(new MonthDataElement(rawUsageRecord.substring(402, 423)));
        monthDataElementList.add(new MonthDataElement(rawUsageRecord.substring(423, 444)));
        monthDataElementList.add(new MonthDataElement(rawUsageRecord.substring(444, 465)));
        monthDataElementList.add(new MonthDataElement(rawUsageRecord.substring(465, 486)));
        outstandingBalanceBeforeEaPayment = new BigDecimal(rawUsageRecord.substring(486, 492));
        filler1 = rawUsageRecord.substring(492, 493);
        creditBalanceAsOfPresent = new BigDecimal(rawUsageRecord.substring(493, 499));
        filler2 = rawUsageRecord.substring(499, 500);
        creditBalanceBeforeEaPayment = new BigDecimal(rawUsageRecord.substring(500, 506));
        filler3 = rawUsageRecord.substring(506, 507);
        creditBalanceRefundedToCustomer = new BigDecimal(rawUsageRecord.substring(507, 513));
        filler4 = rawUsageRecord.substring(513, 514);
        creditBalanceRefundedToDss = new BigDecimal(rawUsageRecord.substring(514, 520));
        filler5 = rawUsageRecord.substring(520);
        
    }
    
    public String getApplicantsAccountNumber() {
        return applicantsAccountNumber;
    }
    
    public List<MonthDataElement> getMonthDataElementList() {
        return monthDataElementList;
    }
    
    public void setMonthDataElementList(List<MonthDataElement> monthDataElementList) {
        this.monthDataElementList = monthDataElementList;
    }

    public void setOutstandingBalanceBeforeEaPayment(
            BigDecimal outstandingBalanceBeforeEaPayment) {
    	//Since DSS accepts only 6 positions, default any balance >= 10,000.00 to 9999.99
    	if(outstandingBalanceBeforeEaPayment.abs().compareTo(BigDecimal.valueOf(10000)) >= 0)
    		outstandingBalanceBeforeEaPayment = BigDecimal.valueOf(9999.99);
        this.outstandingBalanceBeforeEaPayment = outstandingBalanceBeforeEaPayment;
    }
    
    public void setCreditBalanceAsOfPresent(BigDecimal creditBalanceAsOfPresent) {
    	//Since DSS accepts only 6 positions, default any balance >= 10,000.00 to 9999.99
    	if(creditBalanceAsOfPresent.abs().compareTo(BigDecimal.valueOf(10000)) >= 0)
    		creditBalanceAsOfPresent = BigDecimal.valueOf(9999.99);
        this.creditBalanceAsOfPresent = creditBalanceAsOfPresent;
    }
    
    public void setCreditBalanceBeforeEaPayment(
            BigDecimal creditBalanceBeforeEaPayment) {
    	//Since DSS accepts only 6 positions, default any balance >= 10,000.00 to 9999.99
    	if(creditBalanceBeforeEaPayment.abs().compareTo(BigDecimal.valueOf(10000)) >= 0)
    		creditBalanceBeforeEaPayment = BigDecimal.valueOf(9999.99);
        this.creditBalanceBeforeEaPayment = creditBalanceBeforeEaPayment;
    }
    
    public void setCreditBalanceRefundedToCustomer(
            BigDecimal creditBalanceRefundedToCustomer) {
    	//Since DSS accepts only 6 positions, default any balance >= 10,000.00 to 9999.99
    	if(creditBalanceRefundedToCustomer.abs().compareTo(BigDecimal.valueOf(10000)) >= 0)
    		creditBalanceRefundedToCustomer = BigDecimal.valueOf(9999.99);
        this.creditBalanceRefundedToCustomer = creditBalanceRefundedToCustomer;
    }
    
    public void setCreditBalanceRefundedToDss(BigDecimal creditBalanceRefundedToDss) {
    	//Since DSS accepts only 6 positions, default any balance >= 10,000.00 to 9999.99
    	if(creditBalanceRefundedToDss.abs().compareTo(BigDecimal.valueOf(10000)) >= 0)
    		creditBalanceRefundedToDss = BigDecimal.valueOf(9999.99);
        this.creditBalanceRefundedToDss = creditBalanceRefundedToDss;
    }

    public class CmAnnualEaUsageOutputRecord extends ColumnDelimitedRecord {

        public CmAnnualEaUsageOutputRecord() {
            
            super(97);
            
            rightPadColumn(1, 122, reportInfo1);
            rightPadColumn(2, 10, applicantsAccountNumber);
            rightPadColumn(3, 102, reportInfo2);
            
            int index = 4;
            for (MonthDataElement monthDataElement : monthDataElementList) {
                
                leftPadColumnWithZeros(index, 2, monthDataElement.getYear().toString());
                leftPadColumnWithZeros(index + 1, 2, monthDataElement.getMonth().toString());
                leftPadColumnWithZeros(index + 2, 8, monthDataElement.usage.multiply(BigDecimal.TEN).format(8, 0).trim());
                rightPadColumn(index + 3, 1, monthDataElement.filler1);
                leftPadColumnWithZeros(index + 4, 6, monthDataElement.billedAmount.multiply(ONE_HUNDRED).format(6, 0).trim());
                rightPadColumn(index + 5, 1, monthDataElement.filler2);
                rightPadColumn(index + 6, 1, (monthDataElement.isPartialBill.isTrue()) ? IS_PARTIAL_BILL_CHECKMARK : " ");
                index = index + 7;
                
            }
            
            leftPadColumnWithZeros(88, 6, outstandingBalanceBeforeEaPayment.multiply(ONE_HUNDRED).abs().format(6, 0).trim());
            rightPadColumn(89, 1, filler1);
            leftPadColumnWithZeros(90, 6, creditBalanceAsOfPresent.multiply(ONE_HUNDRED).abs().format(6, 0).trim());
            rightPadColumn(91, 1, filler2);
            leftPadColumnWithZeros(92, 6, creditBalanceBeforeEaPayment.multiply(ONE_HUNDRED).abs().format(6, 0).trim());
            rightPadColumn(93, 1, filler3);
            leftPadColumnWithZeros(94, 6, creditBalanceRefundedToCustomer.multiply(ONE_HUNDRED).abs().format(6, 0).trim());
            rightPadColumn(95, 1, filler4);
            leftPadColumnWithZeros(96, 6, creditBalanceRefundedToDss.multiply(ONE_HUNDRED).abs().format(6, 0).trim());
            rightPadColumn(97, 1, filler5);
            
        }
        
    }
    
    public String createRecordString() {
        
        return new CmAnnualEaUsageOutputRecord().createRecordString();
        
    }
    
}
