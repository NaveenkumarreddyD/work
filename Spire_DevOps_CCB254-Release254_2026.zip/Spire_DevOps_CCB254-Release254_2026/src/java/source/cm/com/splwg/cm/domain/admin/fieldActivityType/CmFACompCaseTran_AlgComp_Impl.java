/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * FA Completion Case Transition Algorithm
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-04-08   Jagadeesh	NM0101 Initial Version.
 * 2013-05-29   SMiran          NM0101 TIR5. Case must not transition to Review Status if 
 *                              Disconnect SP Step was not completed.
 * 2016-01-26   MPang		Updated for CCB v2.4 compilation.
 ******************************************************************************************/
package com.splwg.cm.domain.admin.fieldActivityType;

import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CaseLogTypeLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityStepTypeActionLookup;
import com.splwg.ccb.api.lookup.FieldActivityStepUploadStatusLookup;
import com.splwg.ccb.api.lookup.TransitionConditionLookup;
//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseType;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityTypeFaCompletionAlgorithmSpot;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityStep;
import com.splwg.ccb.domain.todo.toDoCase.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCaseAutoTransitionInfo;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_Id;*/

import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.fieldActivityType.algorithm.faCompletion.FieldActivityTypeFaCompletionAlgorithmSpot;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityStep;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.data.ToDoCaseAutoTransitionInfo;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_Id;
//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author jgali001
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = caseType, name = caseACIType, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = caseSPCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = tranCondClose, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = tranCondReview, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (lookupName = fieldActivityStepTypeAction, name = faStepTypeAction, required = true, type = lookup)})
 */
public class CmFACompCaseTran_AlgComp_Impl extends CmFACompCaseTran_AlgComp_Gen
        implements FieldActivityTypeFaCompletionAlgorithmSpot {
    
    private CaseType parmCaseACIType;
    private CharacteristicType parmCaseSPCharType;
    private TransitionConditionLookup parmTranCode = null;
    private FieldActivityStepTypeActionLookup parmFAStepTypeAction ;
    private FieldActivity inpFA ;

        
    protected void extraSoftParameterValidations(boolean arg0) {
        parmCaseSPCharType = getCaseSPCharType();
        parmFAStepTypeAction = getFaStepTypeAction();
        CharacteristicEntity charEntity = new CharacteristicEntity_Id(parmCaseSPCharType, CharacteristicEntityLookup.constants.CASE).getEntity();
        if(isNull(charEntity)){
            addError(CustomMessageRepository.nm0101InvalidCharEntity(parmCaseSPCharType.getId().getIdValue()));
        }
    }
    
    
    public void invoke() {
        ToDoCase_Id openToDoCaseId;
        openToDoCaseId = getOpenToDoCase();
        if (isNull(openToDoCaseId)){
            return;
        }
        
        ToDoCase openCase = openToDoCaseId.getEntity();
        Date caseCreationDate = null;
        for (CaseLog clog:openCase.getLogs()){
            if (clog.getLogType().equals(CaseLogTypeLookup.constants.CREATED)){
                caseCreationDate = clog.getLogDateTime().getDate();
                break;
            }
        }
        
        if(inpFA.getCreationDateTime().getDate().isSameOrAfter(caseCreationDate)){
            for(FieldActivityStep faStep:inpFA.getSteps()){
                if(faStep.getFaStepTypeAction().equals(parmFAStepTypeAction)){
                    //2013-05-29 SMiran Start
                    if (isDisconnectCompleted().isTrue()){
                        parmTranCode = getTranCondReview();
                        break;
                    }
                    //2013-05-29 SMiran End
                }
            }
            if(isNull(parmTranCode)) parmTranCode = getTranCondClose();            
        }
        
        if(notNull(parmTranCode)){
            ToDoCaseAutoTransitionInfo openCaseTranInfo = null;
            openCaseTranInfo = openCase.autoTransitionCase(null, parmTranCode, Bool.TRUE);
            if(openCaseTranInfo.getAutoTransErrSw().isTrue()){                 
                addError(CustomMessageRepository.nm0101CaseTranError(openCase.getId().getIdValue(), openCaseTranInfo.getAutoTransErrMsg()));
            }
        }


    }

    //2013-05-29 SMiran Start
    private Bool isDisconnectCompleted() {
        Bool isDiscCompleted = Bool.FALSE;
        SQLResultRow faStepRow = null;

        PreparedStatement getFaStep 
                = createPreparedStatement(
                        "SELECT " +
                            "FA_STP_UP_STAT_FLG " +
                        "FROM " +
                            "CI_FA_STP_STGUP " +
                        "WHERE " +
                            "FA_ID = :faId " +
                          //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
                          //  "AND FA_STEP_TY_ACT_FLG = :ds");
                		"AND FA_STEP_TY_ACT_FLG = :ds", getClass().getName());
        				//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation

        getFaStep.bindId("faId", inpFA.getId());     
        getFaStep.bindLookup("ds", FieldActivityStepTypeActionLookup.constants.DISCONNECT_SERVICE_POINT);
        faStepRow = getFaStep.firstRow();
        
        if (notNull(faStepRow)){
            FieldActivityStepUploadStatusLookup faStepStat = faStepRow.getLookup("FA_STP_UP_STAT_FLG"
                    , FieldActivityStepUploadStatusLookup.class);
            if (faStepStat.isComplete()){
                isDiscCompleted = Bool.TRUE;
            }
        }
        
        getFaStep.close();
        return isDiscCompleted;
    }
    //2013-05-29 SMiran End

    public void setFieldActivity(FieldActivity arg0) {
        inpFA = arg0;
    }
    
    private ToDoCase_Id getOpenToDoCase(){
        parmCaseACIType = getCaseACIType();
        ToDoCase_Id openToDoCaseId;
        
        StringBuilder getOpenToDoCaseString = new StringBuilder();
        getOpenToDoCaseString.append("SELECT C.CASE_ID FROM CI_CASE C ,CI_CASE_CHAR CC , CI_FA FA ");
        getOpenToDoCaseString.append("WHERE C.CASE_COND_FLG = :openCond ");
        getOpenToDoCaseString.append("AND C.CASE_ID = CC.CASE_ID ");
        getOpenToDoCaseString.append("AND CC.CHAR_TYPE_CD = :caseSPCharType ");
        getOpenToDoCaseString.append("AND CC.CHAR_VAL_FK1 = FA.SP_ID " );
        getOpenToDoCaseString.append("AND FA.FA_ID = :inpFAId " );
        if(notNull(parmCaseACIType)){
            getOpenToDoCaseString.append("AND C.CASE_TYPE_CD = :caseACIType ");;
        }
        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement getOpenToDoCasePrepStmt = createPreparedStatement(getOpenToDoCaseString.toString()); 
        PreparedStatement getOpenToDoCasePrepStmt = createPreparedStatement(getOpenToDoCaseString.toString(), getClass().getName()); 
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        getOpenToDoCasePrepStmt.bindLookup("openCond", CaseConditionLookup.constants.OPEN);
        getOpenToDoCasePrepStmt.bindId("caseSPCharType", parmCaseSPCharType.getId());
        getOpenToDoCasePrepStmt.bindId("inpFAId", inpFA.getId());
        if(notNull(parmCaseACIType)){
            getOpenToDoCasePrepStmt.bindId("caseACIType", parmCaseACIType.getId());
        }
        List<SQLResultRow> resultList = getOpenToDoCasePrepStmt.list();

        getOpenToDoCasePrepStmt.close();
        if(resultList.isEmpty()){
            return null;
        }else{
            SQLResultRow resultRow = resultList.iterator().next();            
            openToDoCaseId = (ToDoCase_Id) resultRow.getId("CASE_ID", ToDoCase.class);     
            return openToDoCaseId;
        }
    }
    
    

}
