/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Column Delimited Record class for ACH File Control
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-05-27   RDizon  CCB041. Initial version.        
 **************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

/**
 * @author RDizon
 */
public class CmCheckExtractACHFileControlRecord extends ColumnDelimitedRecord {

	private static final String DELIMITER = "|";

	public CmCheckExtractACHFileControlRecord() {
		super(8);
	}

	public void setRecordType(String value) {
		this.rightPadColumn(1, 1, value);
	}

	public void setBatchCount(String value) {
		this.rightPadColumn(2, 6, value);
	}

	public void setBlockCount(String value) {
		this.rightPadColumn(3, 6, value);
	}

	public void setEntryCount(String value) {
		this.rightPadColumn(4, 8, StringUtilities.leftPadWithZeros(value, 8));
	}

	public void setEntryHash(String value) {
		this.rightPadColumn(5, 10, value);
	}

	public void setTotalDebitEntryDollarAmount(String value) {
		this.rightPadColumn(6, 12, StringUtilities.leftPadWithZeros(value, 12));
	}

	public void setTotalCreditEntryDollarAmount(String value) {
		this.rightPadColumn(7, 12, StringUtilities.leftPadWithZeros(value, 12));
	}

	public void setReserved(String value) {
		this.rightPadColumn(8, 39, value);
	}

}
