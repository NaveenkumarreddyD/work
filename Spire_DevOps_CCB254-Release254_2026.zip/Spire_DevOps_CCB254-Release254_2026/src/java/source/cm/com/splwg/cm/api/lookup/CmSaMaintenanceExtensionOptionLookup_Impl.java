/* **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * Service Agreement Maintenance Extension Option Lookup
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:        	Reason:
 * YYYY-MM-DD   IN         	Reason text.
 *
 * 2018-10-04   MPang     	SA-241631B. Initial Version.
 * ************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author MPang
 *
@LookupFieldname (value = XSMP_OPT_TYP_FLG)
 */
public class CmSaMaintenanceExtensionOptionLookup_Impl extends
	CmSaMaintenanceExtensionOptionLookup_Gen {

}
