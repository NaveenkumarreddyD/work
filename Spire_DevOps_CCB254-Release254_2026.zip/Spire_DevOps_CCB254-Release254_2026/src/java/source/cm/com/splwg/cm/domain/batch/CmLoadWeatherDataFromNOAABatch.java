/**************************************************************************
* Program Name: CmLoadWeatherDataFromNOAABatch
* Program Title: CmLoadWeatherDataFromNOAABatch
* Author: ACasta
* Creation Date: 2017-08-30
* Purpose: This Batch Program will load weather data from NOAA 
* automatically to eliminate manual process. This will download Daily 
* Climate Report and load temperature data.
* Functional Spec: SA-214110
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:         Date:         Description:
 * ----------------------------------------------------------------------------------------------
 * SA-214110          Alfonso Castano 2017-08-30    Initial Version
 * Defect 3873649     Sharmayne Felipe2017-10-02    Use the City, Weather Date and Status columns  
 *                                                  only as filters when trying to update the
 *                                                  record's status and update date columns.
 ************************************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.cm.domain.common.customBusinessComponent.CmCreateUpdateHeatingDegreeDaysRoutine;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author ACasta
 *
@BatchJob (modules= {}, 
           rerunnable = true,
           multiThreaded = false)
 */
public class CmLoadWeatherDataFromNOAABatch extends
        CmLoadWeatherDataFromNOAABatch_Gen {

    // Soft Parameter
    private BigInteger paramMaxErrors;
    
    // Constants
    private static String ERROR_STATUS = "E";
    private static String COMPLETE_STATUS = "C";
    
    public JobWork getJobWork() {
        StringBuilder strQuery = new StringBuilder();
        strQuery.append("SELECT CITY, WEATHER_DATE, MAX_TEMP, MIN_TEMP, AVE_TEMP, ");
        /*
         * Defect 3873649 - 2017-10-02 - Start Change
         */
        //strQuery.append("CREATION_DATE, UPDATE_DATE, STATUS ");
        strQuery.append("UPDATE_DATE, STATUS ");
        /*
         * Defect 3873649 - 2017-10-02 - End Change
         */
        strQuery.append("FROM XXL_SOA_WEATHER_RPT_TAB ");
        strQuery.append("WHERE STATUS = 'N'");
        
        PreparedStatement mainQuery = 
                createPreparedStatement(strQuery.toString(), getClass().getName());
        mainQuery.execute();
        
        QueryIterator qIter = mainQuery.iterate();
        return createJobWorkForQueryIterator(qIter, this);
    }
    
    public ThreadWorkUnit createWorkUnit(QueryResultRow row) {
        ThreadWorkUnit threadUnit = new ThreadWorkUnit();
        threadUnit.addSupplementalData("city", row.getString("CITY"));
        threadUnit.addSupplementalData("weatherDate", row.getString("WEATHER_DATE"));
        threadUnit.addSupplementalData("maxTemp", row.getString("MAX_TEMP"));
        threadUnit.addSupplementalData("minTemp", row.getString("MIN_TEMP"));
        threadUnit.addSupplementalData("avgTemp", row.getString("AVE_TEMP"));
        /*
         * Defect 3873649 - 2017-10-02 - Start Delete
         */
        //threadUnit.addSupplementalData("creationDate", row.getDate("CREATION_DATE"));
        /*
         * Defect 3873649 - 2017-10-02 - End Delete
         */
        threadUnit.addSupplementalData("updateDate", row.getDate("UPDATE_DATE"));
        threadUnit.addSupplementalData("status", row.getString("STATUS"));
        return threadUnit;
    }

    public void validateSoftParameters(boolean arg0) {
        paramMaxErrors = getParameters().getSoftMaxErrors();
        if (notNull(paramMaxErrors) && paramMaxErrors.intValue() < 0) {
            addError(CustomMessageRepository.nm0101MaxErrorCannotBeLessThanZero(
                    paramMaxErrors.toString().trim()));
        }
    }

    public Class<CmLoadWeatherDataFromNOAABatchWorker> getThreadWorkerClass() {
        return CmLoadWeatherDataFromNOAABatchWorker.class;
    }

    public static class CmLoadWeatherDataFromNOAABatchWorker extends
            CmLoadWeatherDataFromNOAABatchWorker_Gen {
        
        // Work variables
        CmCreateUpdateHeatingDegreeDaysRoutine degreeDaysRoutine = null;
        
        private int maxErrors = 0;
        private int errorCount = 0;
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

        @Override
        public void initializeThreadWork(
                boolean initializationPreviouslySuccessful)
                throws ThreadAbortedException, RunAbortedException {
            maxErrors = this.getParameters().getSoftMaxErrors().intValue();   
        }

        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
            
            // Initialize variables
            String city = (String) unit.getSupplementallData("city");
            String weatherDate = (String) unit.getSupplementallData("weatherDate");
            String maxTemp = (String) unit.getSupplementallData("maxTemp");
            String minTemp = (String) unit.getSupplementallData("minTemp");
            String aveTemp = (String) unit.getSupplementallData("avgTemp");
            /*
             * Defect 3873649 - 2017-10-02 - Start Delete
             */
            //Date creationDate = (Date) unit.getSupplementallData("creationDate");
            /*
             * Defect 3873649 - 2017-10-02 - End Delete
             */
            
            // Call CmCreateUpdateHeatingDegreeDaysRoutine to process records
            degreeDaysRoutine = CmCreateUpdateHeatingDegreeDaysRoutine.Factory.newInstance();
            degreeDaysRoutine.setCity(city);
            degreeDaysRoutine.setWeatherDate(weatherDate);
            degreeDaysRoutine.setMaxTemp(maxTemp);
            degreeDaysRoutine.setMinTemp(minTemp);
            degreeDaysRoutine.setAveTemp(aveTemp);
            
            try {
                degreeDaysRoutine.processNOAAData();
                /*
                 * Defect 3873649 - 2017-10-02 - Start Change
                 */
                //updateWeatherDataStatus(COMPLETE_STATUS, city, weatherDate, maxTemp, minTemp, aveTemp, creationDate);
                updateWeatherDataStatus(COMPLETE_STATUS, city, weatherDate);
                /*
                 * Defect 3873649 - 2017-10-02 - End Change
                 */
            } catch (Exception e){
                errorCount++;
                if (errorCount > maxErrors){
                    throw new RunAbortedException(CustomMessageRepositoryMGE.commMaxErrorLimitExceeded(String.valueOf(maxErrors)));
                }else{
                    logError(degreeDaysRoutine.getErrorMessage());
                    /*
                     * Defect 3873649 - 2017-10-02 - Start Change
                     */
                    //updateWeatherDataStatus(ERROR_STATUS, city, weatherDate, maxTemp, minTemp, aveTemp, creationDate);
                    updateWeatherDataStatus(ERROR_STATUS, city, weatherDate);
                    /*
                     * Defect 3873649 - 2017-10-02 - End Change
                     */
                } 
                return false;
            } 
            
            return true;
        }

        /**
         * This method will update the Status and Update Date of the record from NOAA
         * @param city
         * @param status
         * @param weatherDate
         */
        /*
         * Defect 3873649 - 2017-10-02 - Start Change
         */
        //public void updateWeatherDataStatus(String newStatus, String city, String weatherDate, 
        //        String maxTemp, String minTemp, String aveTemp, Date creationDate){
        public void updateWeatherDataStatus(String newStatus, String city, String weatherDate){
        /*
         * Defect 3873649 - 2017-10-02 - End Change
         */
            StringBuilder strUpdQuery = new StringBuilder();
            strUpdQuery.append("UPDATE XXL_SOA_WEATHER_RPT_TAB ");
            strUpdQuery.append("SET STATUS = TRIM(:status), ");
            strUpdQuery.append("UPDATE_DATE = :processDate ");
            strUpdQuery.append("WHERE CITY = :city ");
            strUpdQuery.append("AND WEATHER_DATE = :weatherDate ");
            /*
             * Defect 3873649 - 2017-10-02 - Start Delete
             */
            //strUpdQuery.append("AND MAX_TEMP = TRIM(:maxTemp) ");
            //strUpdQuery.append("AND MIN_TEMP = TRIM(:minTemp) ");
            //strUpdQuery.append("AND AVE_TEMP = TRIM(:aveTemp) ");
            //strUpdQuery.append("AND CREATION_DATE = :creationDate " );
            /*
             * Defect 3873649 - 2017-10-02 - End Delete
             */
            strUpdQuery.append("AND STATUS = 'N' ");
            
            PreparedStatement prepStatement = 
                    createPreparedStatement(strUpdQuery.toString(), getClass().getName());
            
            prepStatement.bindString("status", newStatus.trim(), "STATUS");
            /*
             * Defect 3873649 - 2017-10-02 - Start Change
             */
            //prepStatement.bindDate("processDate", getProcessDateTime().getDate());
            prepStatement.bindDateTime("processDate", getProcessDateTime());
            /*
             * Defect 3873649 - 2017-10-02 - End Change
             */
            prepStatement.bindString("city", city, "CITY");
            prepStatement.bindString("weatherDate", weatherDate, "WEATHER_DATE");
            /*
             * Defect 3873649 - 2017-10-02 - Start Delete
             */
            //prepStatement.bindString("maxTemp", maxTemp, "MAX_TEMP");
            //prepStatement.bindString("minTemp", minTemp, "MIN_TEMP");
            //prepStatement.bindString("aveTemp", aveTemp, "AVE_TEMP");
            //prepStatement.bindDate("creationDate", creationDate);
            /*
             * Defect 3873649 - 2017-10-02 - End Delete
             */
            prepStatement.executeUpdate();
            prepStatement.close();
        }
        
    }

}
