/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Pledge Payment Reconciliation Option Type Lookup
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-09-28   JHERNA      SysAid#73573. Initial Version. Post v2.4 upgrade.
 * *************************************************************************                
 */
package com.splwg.cm.api.lookup;

/**
 * @author 90622
 *
@LookupFieldname (value = XPPY_OPT_TYP_FLG)
 */
public class CmPledgePaymentsOptionTypeLookup_Impl 
		extends CmPledgePaymentsOptionTypeLookup_Gen {

}
