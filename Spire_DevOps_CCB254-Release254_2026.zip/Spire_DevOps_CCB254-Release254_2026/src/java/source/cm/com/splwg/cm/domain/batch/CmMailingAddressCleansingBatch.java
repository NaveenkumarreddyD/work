/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Mailing Address Cleansing Batch Process
 * 
 * This batch program runs Vertex Address Cleansing on specified Mailing 
 * Addresses. A Minimum Confidence Indicator parameter can be set to update 
 * the Mailing Address with the suggested address automatically if the 
 * returned Vertex Confidence Indicator is equal to or greater than a 
 * certain threshold. 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2021-02-19   NMendo     CCB011.2. Initial version.
 * 2021-04-27   NMendo     CCB011.Issue1. Set confidence indicator to 0 if 
 *                         Address 1 is not returned by Vertex. Handle 
 *                         Vertex error in Outbound Message.Corrected the 
 *                         number of records processed and records in error.
 * 2021-06-02   NMendo     CCB011.Issue4. Fix issue on file created when 
 *                         thread number is more than 1 digit.
 * 2021-06-09   NMendo     CCB011.Issue5. Exempt inactive Account in processing.
 *                         Add Address1 column in the output file.
 *************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControl_Id;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationMessage;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.outboundMessage.outboundMessage.OutboundMessage;
import com.splwg.base.domain.outboundMessage.outboundMessage.OutboundMessage_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.ccb.api.lookup.BillingAddressSourceLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.debtClass.entity.DebtClass;
import com.splwg.ccb.domain.admin.debtClass.entity.DebtClass_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.PersonAddressOverride;
import com.splwg.ccb.domain.customerinfo.account.entity.PersonAddressOverride_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonSeasonalAddress;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonSeasonalAddress_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ServerMessage;

/**
 * @author NMendo
 *
 @BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = MINIMUM_CONFIDENCE, type = integer)
 *            , @BatchJobSoftParameter (name = EXCEPTION_MODE, type = string)
 *            , @BatchJobSoftParameter (name = FILE_PATH, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, type = string)
 *            , @BatchJobSoftParameter (name = EXEMPT_SA_DEBT_CLASS, type = string)})
 */
public class CmMailingAddressCleansingBatch 
		extends CmMailingAddressCleansingBatch_Gen {
	
	// Constants
	private static final String FILE_STR = "FILE";
	private static final String TODO_STR = "TODO";
	private static final String MINIMUM_CONFIDENCE_STR = "MINIMUM_CONFIDENCE";
	private static final String EXCEPTION_MODE_STR = "EXCEPTION_MODE";
	private static final String FILE_PATH_STR = "FILE_PATH";
	private static final String FILE_NAME_STR = "FILE_NAME";
	// Start Add - NMendo - CCB011.Issue5 -  2021-06-09
	private static final String EXEMPT_SA_DEBT_CLASS_STR = "EXEMPT_SA_DEBT_CLASS";
	private static final String COMMA = ",";
	private static final String SINGLE_QUOTE = "'";
	private static final String SPACE = " ";
	
	// Work Variables
	private String exemptSaDebtClasses;
	// End Add - NMendo - CCB011.Issue5 -  2021-06-09
	
	@Override
    public JobWork getJobWork() {
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ACCT_ID ");
        stringBuilder.append("FROM CI_ACCT AC ");
        stringBuilder.append("WHERE 0 < (SELECT COUNT('X') ");
        stringBuilder.append(           "FROM CI_ACCT_PER AP ");
        stringBuilder.append(           "WHERE AP.ACCT_ID = AC.ACCT_ID ");
        // Start Change - NMendo - CCB011.Issue5 -  2021-06-09
        //stringBuilder.append(           "AND AP.BILL_ADDR_SRCE_FLG <> :premiseFlg) ");
        stringBuilder.append(           "AND AP.BILL_ADDR_SRCE_FLG IN (:personFlg, :acovFlg)) ");
        stringBuilder.append("AND EXISTS (SELECT 'X' ");
        stringBuilder.append(            "FROM CI_SA SA, CI_SA_TYPE SAT ");
        stringBuilder.append(            "WHERE SA.ACCT_ID = AC.ACCT_ID ");
        stringBuilder.append(            "AND SA.SA_STATUS_FLG < :closed ");
        stringBuilder.append(            "AND SA.SA_TYPE_CD = SAT.SA_TYPE_CD ");
        stringBuilder.append(            "AND SA.CIS_DIVISION = SAT.CIS_DIVISION ");
        stringBuilder.append(            "AND SAT.DEBT_CL_CD NOT IN (" + exemptSaDebtClasses + ")) ");
        // End Change - NMendo - CCB011.Issue5 -  2021-06-09
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        // Start Change - NMendo - CCB011.Issue5 -  2021-06-09
        //preparedStatement.bindLookup("premiseFlg", BillingAddressSourceLookup.constants.MAILING_PREMISE_ON_ACCOUNT);
        preparedStatement.bindLookup("personFlg", BillingAddressSourceLookup.constants.PERSON);
        preparedStatement.bindLookup("acovFlg", BillingAddressSourceLookup.constants.ACCOUNT_OVERRIDE);
        preparedStatement.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
        // End Change - NMendo - CCB011.Issue5 -  2021-06-09
        preparedStatement.setAutoclose(true);
        preparedStatement.execute();
		QueryIterator returnValue = preparedStatement.iterate();
		
		return createJobWorkForQueryIterator(returnValue, this);
    }
    
    @Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow qrw) {
		ThreadWorkUnit twu = new ThreadWorkUnit();
		Account_Id accountId = (Account_Id) qrw.getId("ACCT_ID", Account.class);
		twu.setPrimaryId(accountId);		
		return twu;
	}
    
    @Override
    public void validateSoftParameters(boolean arg0) {
    	BigInteger parmMinimumConfidence = getParameters().getMINIMUM_CONFIDENCE();
    	String parmExceptionMode = getParameters().getEXCEPTION_MODE();
    	String parmFilePath = getParameters().getFILE_PATH();
    	String parmFileName = getParameters().getFILE_NAME();
    	// Start Add - NMendo - CCB011.Issue5 -  2021-06-09
    	String parmExemptSaDebtClass = getParameters().getEXEMPT_SA_DEBT_CLASS();
    	// End Add - NMendo - CCB011.Issue5 -  2021-06-09
    	BatchControl_Id batchCd = getBatchControlId();
    	
    	if(notNull(parmMinimumConfidence) 
    			&& (parmMinimumConfidence.compareTo(BigInteger.ZERO) < 0 
    					|| parmMinimumConfidence.compareTo(BigInteger.valueOf(100)) > 0)) {
    		// Batch Parameter %1 must be a value from 0 to 100.
    		addError(CustomMessageRepositorySpireOne.CCB011_minimumConfidenceInvalid(MINIMUM_CONFIDENCE_STR));
    	}
    	
    	if(notNull(parmExceptionMode)) {
    		if(parmExceptionMode.equals(FILE_STR)) {
    			if(isNull(parmFilePath)) {
    				// Batch Parameter %1 is required when Batch Parameter %2 value is 'FILE'.
    				addError(CustomMessageRepositorySpireOne.CCB011_batchParmRequired(FILE_PATH_STR, EXCEPTION_MODE_STR));
    			}
    			
    			if(isNull(parmFileName)) {
    				// Batch Parameter %1 is required when Batch Parameter %2 value is 'FILE'.
    				addError(CustomMessageRepositorySpireOne.CCB011_batchParmRequired(FILE_NAME_STR, EXCEPTION_MODE_STR));
    			}
    			
    			File fileValidator = new File(parmFilePath.trim());		
    			if (isNull(fileValidator) || !fileValidator.isDirectory()) {
    				// Batch Parameter %1 value (%2) is an invalid file path.
    				addError(CustomMessageRepositorySpireOne.CCB011_filePathInvalid(FILE_PATH_STR, parmFilePath.trim()));
    			}
    			
    		} else if(parmExceptionMode.equals(TODO_STR)) {
    			if(isNull(retrieveBatchToDoType(batchCd))) {
    				// There is no To Do Type with Batch Process %1 as its Creation Process.
        			addError(CustomMessageRepositorySpireOne.CCB011_noTodoTypeForBatchControl(batchCd.getTrimmedValue()));
    			}
    			
    		} else {
    			// Batch Parameter %1 value (%2) is invalid. Valid values are: FILE, TODO.
    			addError(CustomMessageRepositorySpireOne.CCB011_exceptionModeInvalid(EXCEPTION_MODE_STR, parmExceptionMode.trim()));
    		}
    	}
    	
    	// Start Add - NMendo - CCB011.Issue5 -  2021-06-09
    	exemptSaDebtClasses = SINGLE_QUOTE.concat(SPACE).concat(SINGLE_QUOTE);
    	if(notNull(parmExemptSaDebtClass)) {
    		String[] exemptSaDebtClassSplitted = parmExemptSaDebtClass.split(COMMA);
    		int index = 0;
    		String debtClassStr = null;
    		StringBuilder saDebtClassBuilder = new StringBuilder();
    		for(String exemptSaDebtClass : exemptSaDebtClassSplitted) {
    			index++;
    			debtClassStr = exemptSaDebtClass.trim();
    			DebtClass debtClass = new DebtClass_Id(debtClassStr).getEntity();
    			
    			if(isNull(debtClass)) {
    				// Batch Parameter %1 contains invalid Debt Class (%2).
    				addError(CustomMessageRepositorySpireOne.CCB011_debtClassInvalid(EXEMPT_SA_DEBT_CLASS_STR, debtClassStr));
    			}
    			
    			if(index > 1) {
    				saDebtClassBuilder.append(COMMA);
    			}
    			
    			saDebtClassBuilder.append(SINGLE_QUOTE);
    			saDebtClassBuilder.append(debtClassStr);
    			saDebtClassBuilder.append(SINGLE_QUOTE);
    		}
    		exemptSaDebtClasses = saDebtClassBuilder.toString();
    	}
    	// End Add - NMendo - CCB011.Issue5 -  2021-06-09
    	
    }
    
    /**
     * Retrieve To Do Type where Creation Batch Process is the input batchCd.
     * @param batchCd
     * @return ToDoType
     */
    private ToDoType retrieveBatchToDoType(BatchControl_Id batchCd) {
    	ToDoType batchToDoType = null;
    	
    	StringBuilder sb = new StringBuilder();
    	sb.append("SELECT TD_TYPE_CD ");
    	sb.append("FROM CI_TD_TYPE ");
    	sb.append("WHERE CRE_BATCH_CD = :batchCd ");
    	
    	PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
    	ps.bindId("batchCd", batchCd);
    	
    	SQLResultRow result = ps.firstRow();
    	ps.close();
    	
    	if(notNull(result)) {
    		String batchToDoTypeStr = result.getString("TD_TYPE_CD");
    		batchToDoType = new ToDoType_Id(batchToDoTypeStr).getEntity();
    	}
    	
    	return batchToDoType;
    }

    public Class<CmMailingAddressCleansingBatchWorker> getThreadWorkerClass() {
        return CmMailingAddressCleansingBatchWorker.class;
    }

    public static class CmMailingAddressCleansingBatchWorker extends 
    		CmMailingAddressCleansingBatchWorker_Gen {
        
    	// Batch Parameters
    	private BigInteger parmMinimumConfidence;
    	private String parmExceptionMode;
    	private String parmFilePath;
    	private String parmFileName;
    	
    	// Constants
    	private static final String BACKSLASH = "/";
    	private static final String FORWARDSLASH = "\\";
    	private static final String PERIOD = ".";
    	private static final String DOUBLE_QUOTE = "\"";
    	private static final String COMMA = ",";
    	private static final String CARRIAGE_RETURN_LINE_FEED = "\r\n";
    	private static final String ACCOUNT_ID_HEADER = "Account ID";
    	private static final String PERSON_ID_HEADER = "Person ID";
    	private static final String STATE_HEADER = "State";
    	private static final String COUNTY_HEADER = "County";
    	private static final String CONFIDENCE_INDICATOR_HEADER = "Confidence Indicator";
    	private static final String ERROR_MESSAGE_HEADER = "Error Message";
    	private static final String ADDRESS_VERIFICATION_BO = "CM-AddressVerificationVertex";
    	private static final String VERTEX_FEATURE_CONFIG = "CM_VERTEXCFG";
    	// Start Add - NMendo - CCB011.Issue5 -  2021-06-09
    	private static final String ADDRESS1_HEADER = "Address1";
    	// End Add - NMendo - CCB011.Issue5 -  2021-06-09
    	
    	// Work Variables
    	private BatchControl_Id batchControlId;
    	private String filePathName;
    	private BufferedWriter buffWriter;
    	private ToDoType toDoType;
    	private String accountIdStr;
    	private String personIdStr;
    	private int numberOfAddress;
    	private int numberOfFailedCall;
    	private int numberOfUpdatedAddress;
    	private int numberOfAddressRequiringAttention;
    	private String vertexAddress1;
    	private String vertexAddress2;
    	private String vertexCity;
    	private String vertexState;
    	private String vertexPostal;
    	private String vertexCounty;
    	private Bool shouldUpdateAddress;
        
        @Override
        public void initializeThreadWork(boolean initializationPreviouslySuccessful) throws ThreadAbortedException, RunAbortedException {
        	// Get parameters
        	parmMinimumConfidence = getParameters().getMINIMUM_CONFIDENCE();
        	parmExceptionMode = getParameters().getEXCEPTION_MODE();
        	parmFilePath = getParameters().getFILE_PATH();
        	parmFileName = getParameters().getFILE_NAME();
        	
        	numberOfAddress = 0;
        	numberOfFailedCall = 0;
        	numberOfUpdatedAddress = 0;
        	numberOfAddressRequiringAttention = 0;
        	
        	batchControlId = getBatchControlId();
        	toDoType = getToDoTypeForBatch(batchControlId);
        	
        	if(notNull(parmExceptionMode) && parmExceptionMode.equals(FILE_STR)) {
        		// Form file path name and write file header
            	formFilePathName();
            	openFile();
            	writeFileHeader();
        	}
        }

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }
        
        @Override
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit threadWorkUnit)
				throws ThreadAbortedException, RunAbortedException {
            
        	Account_Id accountId = (Account_Id)threadWorkUnit.getPrimaryId();
        	Account account = accountId.getEntity();
        	accountIdStr = accountId.getTrimmedValue();
        	
        	//Start Add - NMendo - CCB011.Issue1 - 2021-04-27
        	numberOfAddress = 0;
        	numberOfFailedCall = 0;
        	//End Add - NMendo - CCB011.Issue1 - 2021-04-27
        	
        	Iterator<AccountPerson> accountPersonIter = account.getPersons().iterator();
        	AccountPerson accountPerson = null;
        	BillingAddressSourceLookup addressSource = null;
        	while(accountPersonIter.hasNext()) {
        		accountPerson = accountPersonIter.next();
        		addressSource = accountPerson.getBillAddressSource();
        		Person person = accountPerson.fetchIdPerson();
        		Person_Id personId = person.getId();
        		personIdStr = personId.getTrimmedValue();
        		
        		// If Account Person Address Source is Account Override
        		if(addressSource.isAccountOverride()) {
        			Iterator<PersonAddressOverride> addressOvrdIter = accountPerson.getPersonAddressOverrides().iterator();
        			PersonAddressOverride addressOvrd = null;
        			while(addressOvrdIter.hasNext()) {
        				addressOvrd = addressOvrdIter.next();
        				// Use the Address Cleansing on Account Override address
        				procesAddress(addressOvrd.getAddress1(), addressOvrd.getAddress2(), addressOvrd.getCity(), 
        						addressOvrd.getState(), addressOvrd.getPostal(), addressOvrd.getCounty());
        				
        				if(shouldUpdateAddress.isTrue()) {
        					// Update the Address with the new information
        					PersonAddressOverride_DTO addressOvrdDto = addressOvrd.getDTO();
        					addressOvrdDto.setAddress1(vertexAddress1);
        					addressOvrdDto.setAddress2(vertexAddress2);
        					addressOvrdDto.setCity(vertexCity);
        					addressOvrdDto.setState(vertexState);
        					addressOvrdDto.setPostal(vertexPostal);
        					addressOvrdDto.setCounty(vertexCounty);
        					addressOvrd.setDTO(addressOvrdDto);
        					numberOfUpdatedAddress++;
        				}
        			}
        		}
        		
        		// If Account Person Address Source is Person
        		if(addressSource.isPerson()) {
        			// Use the Address Cleansing on Person address
        			procesAddress(person.getAddress1(), person.getAddress2(), person.getCity(), 
        					person.getState(), person.getPostal(), person.getCounty());
        			
        			if(shouldUpdateAddress.isTrue()) {
        				// Update the Address with the new information
    					Person_DTO personDto = person.getDTO();
    					personDto.setAddress1(vertexAddress1);
    					personDto.setAddress2(vertexAddress2);
    					personDto.setCity(vertexCity);
    					personDto.setState(vertexState);
    					personDto.setPostal(vertexPostal);
    					personDto.setCounty(vertexCounty);
    					person.setDTO(personDto);
    					numberOfUpdatedAddress++;
    				}
        			
        			Iterator<PersonSeasonalAddress> seasonalAddressIter = person.getSeasonalAddresses().iterator();
        			PersonSeasonalAddress seasonalAddress = null;
        			while(seasonalAddressIter.hasNext()) {
        				seasonalAddress = seasonalAddressIter.next();
        				// Use the Address Cleansing on Person Seasonal address
        				procesAddress(seasonalAddress.getAddress1(), seasonalAddress.getAddress2(), seasonalAddress.getCity(), 
        						seasonalAddress.getState(), seasonalAddress.getPostal(), seasonalAddress.getCounty());
        				
        				if(shouldUpdateAddress.isTrue()) {
        					// Update the Address with the new information
        					PersonSeasonalAddress_DTO seasonalAddressDto = seasonalAddress.getDTO();
        					seasonalAddressDto.setAddress1(vertexAddress1);
        					seasonalAddressDto.setAddress2(vertexAddress2);
        					seasonalAddressDto.setCity(vertexCity);
        					seasonalAddressDto.setState(vertexState);
        					seasonalAddressDto.setPostal(vertexPostal);
        					seasonalAddressDto.setCounty(vertexCounty);
        					seasonalAddress.setDTO(seasonalAddressDto);
        					numberOfUpdatedAddress++;
        				}
        			}
        		}
        	}
			
			WorkUnitResult result = new WorkUnitResult(true);
			// Records Processed is the total number of Address retrieved 
            result.setUnitsProcessed(numberOfAddress);
            // Records in Error is the count of times the Vertex call failed 
            result.setUnitsInError(numberOfFailedCall);
            
			return result;
        }
        
        /**
         * Address Cleansing Process
         * @param address1
         * @param address2
         * @param city
         * @param state
         * @param postal
         * @param county
         */
        private void procesAddress(String address1, String address2, String city, String state, String postal, String county) {
        	numberOfAddress++;
        	shouldUpdateAddress = Bool.FALSE;
        	vertexAddress1 = "";
        	vertexAddress2 = "";
        	vertexCity = "";
        	vertexState = "";
        	vertexPostal = "";
        	vertexCounty = "";
        	String confidenceIndicator = "";
    		String vertexCode = "";
    		String errorMessage = "";
        	
        	String inputAddress1 = address1.trim().toUpperCase();
        	String inputAddress2 = address2.trim().toUpperCase();
        	String inputCity = city.trim().toUpperCase();
        	String inputState = state.trim().toUpperCase();
        	String inputPostal = postal.trim().toUpperCase();
        	String inputCounty = county.trim().toUpperCase();
        	
        	// Check if the Address is on the Mailing Address Cleansing Exception table
        	Bool isExempted = isAddressExempted(inputAddress1, inputCity, inputState);
        	if(isExempted.isTrue()) {
        		return;
        	}
        	
        	// Validate the address with Vertex
        	BusinessObject_Id boId = new BusinessObject_Id(ADDRESS_VERIFICATION_BO);
        	BusinessObjectInstance vertexInput = BusinessObjectInstance.create(boId.getEntity());
        	
        	COTSInstanceNode vertexEnvelope = vertexInput.getGroup("VertexEnvelope");
        	COTSInstanceNode taxAreaRequest = vertexEnvelope.getGroup("TaxAreaRequest");
        	COTSInstanceNode taxAreaLookup = taxAreaRequest.getGroup("TaxAreaLookup");
        	COTSInstanceNode postalAddress = taxAreaLookup.getGroup("PostalAddress");
        	
        	postalAddress.set("StreetAddress1", inputAddress1);
        	postalAddress.set("StreetAddress2", inputAddress2);
        	postalAddress.set("City", inputCity);
        	postalAddress.set("MainDivision", inputState);
        	postalAddress.set("PostalCode", inputPostal);

        	BusinessObjectInstance vertexOutput = null;
    		try{
    			vertexOutput = BusinessObjectDispatcher.add(vertexInput);
    		} catch(Exception e) {
    			// Log the Application Error message as an error
    		    logError(CustomMessageRepositorySpireOne.CCB011_applicationError(e.getMessage()));
    		    numberOfFailedCall++;
    		    return;
    		}
    		
    		String outMsgId = vertexOutput.getString("outboundMsgId");
			if(notNull(outMsgId)) {
				OutboundMessage outMsg = new OutboundMessage_Id(outMsgId).getEntity();
				
				if(outMsg.getStatus().isError()) {
					//Start Change - NMendo - CCB011.Issue1 - 2021-04-27
					// Log the Outbound Message Error Details
	    		    //logError(CustomMessageRepositorySpireOne.CCB011_applicationError(outMsg.getErrorDetails()));
	    		    //numberOfFailedCall++;
	    		    //return;
					String errorDetails = outMsg.getErrorDetails();
					if(errorDetails.contains("VertexInvalidAddressException") && errorDetails.contains("fault code=") && errorDetails.contains("fault code text=")) {
						Pattern errorCodePattern = Pattern.compile("([(]fault code=).*?,");
					    Matcher errorCodeMatcher = errorCodePattern.matcher(errorDetails);
					    while (errorCodeMatcher.find()) {
					    	String errorCode = errorCodeMatcher.group();
					    	errorCode = errorCode.replaceFirst("[(]fault code=", "");
					    	errorCode = errorCode.replace(COMMA, "");
					    	vertexCode = errorCode.trim();
					    	break;
					    }
					    
					    Pattern errorMsgPattern = Pattern.compile("(, fault code text=).*?[)]");
					    Matcher errorMsgMatcher = errorMsgPattern.matcher(errorDetails);
					    while (errorMsgMatcher.find()) {
					    	String errorCodeText = errorMsgMatcher.group();
					    	errorCodeText = errorCodeText.replaceFirst(", fault code text=", "");
					    	errorCodeText = errorCodeText.replace(")", "");
					    	errorMessage = errorCodeText.trim();
					    	break;
					    }
					    
					    if(isBlankOrNull(vertexCode) || isBlankOrNull(errorMessage)) {
					    	// Log the Outbound Message Error Details
			    		    logError(CustomMessageRepositorySpireOne.CCB011_applicationError(errorDetails));
			    		    numberOfFailedCall++;
			    		    return;
					    }
					    
					} else {
						// Log the Outbound Message Error Details
		    		    logError(CustomMessageRepositorySpireOne.CCB011_applicationError(errorDetails));
		    		    numberOfFailedCall++;
		    		    return;
		    		//End Change - NMendo - CCB011.Issue1 - 2021-04-27
					}
				}
			}
    		
    		COTSInstanceNode responseDetails = vertexOutput.getGroup("responseDetails");
    		COTSInstanceNode responseVertexEnvelope = responseDetails.getGroup("VertexEnvelope");
    		COTSInstanceNode taxAreaResponse = responseVertexEnvelope.getGroup("TaxAreaResponse");
    		COTSInstanceNode taxAreaResult = taxAreaResponse.getGroup("TaxAreaResult");
    		COTSInstanceNode vertexPostalAddress = taxAreaResult.getGroup("PostalAddress");
    		
    		String vertexAddress1Str = vertexPostalAddress.getString("StreetAddress1");
    		String vertexAddress2Str = vertexPostalAddress.getString("StreetAddress2");
    		String vertexCityStr = vertexPostalAddress.getString("City");
    		String vertexStateStr = vertexPostalAddress.getString("MainDivision");
    		String vertexPostalStr = vertexPostalAddress.getString("PostalCode");
    		String vertexCountyStr = vertexPostalAddress.getString("SubDivision");
    		
    		if(notNull(vertexAddress1Str)) {
    			vertexAddress1 = vertexAddress1Str.trim().toUpperCase();
    		}
    		if(notNull(vertexAddress2Str)) {
    			vertexAddress2 = vertexAddress2Str.trim().toUpperCase();
    		}
    		if(notNull(vertexCityStr)) {
    			vertexCity = vertexCityStr.trim().toUpperCase();
    		}
    		if(notNull(vertexStateStr)) {
    			vertexState = vertexStateStr.trim().toUpperCase();
    		}
    		if(notNull(vertexPostalStr)) {
    			vertexPostal = vertexPostalStr.trim().toUpperCase();
    		}
    		if(notNull(vertexCountyStr)) {
    			vertexCounty = vertexCountyStr.trim().toUpperCase();
    		}
    		
    		// Compare Address to the Vertex information, if all fields are the same
    		if(inputAddress1.equals(vertexAddress1) && inputAddress2.equals(vertexAddress2) && inputCity.equals(vertexCity)
    				&& inputState.equals(vertexState) && inputPostal.equals(vertexPostal) && inputCounty.equals(vertexCounty)) {
    			return;
    		}
    		
    		String confidenceIndicatorStr = taxAreaResponse.getString("confidenceIndicator");
    		String vertexCodeStr = taxAreaResult.getString("AddressCleansingResultMessageCode");
    		String errorMessageStr = taxAreaResult.getString("AddressCleansingResultMessage");
    		
    		if(notNull(confidenceIndicatorStr)) {
    			confidenceIndicator = confidenceIndicatorStr.trim();
    		}
    		if(notNull(vertexCodeStr)) {
    			vertexCode = vertexCodeStr.trim();
    		}
    		if(notNull(errorMessageStr)) {
    			errorMessage = errorMessageStr.trim();
    		}
    		
    		//Start Add - NMendo - CCB011.Issue1 - 2021-04-27
        	if(isBlankOrNull(vertexAddress1)) {
        		confidenceIndicator = "0";
        	}
        	//End Add - NMendo - CCB011.Issue1 - 2021-04-27
    		
    		// If MINIMIM-CONFIDENCE parameter was defined, check if Vertex response Confidence Indicator 
    		// is more than or equal to the MINIMUM-CONFIDENCE parameter
    		if(notNull(parmMinimumConfidence) && isBlankOrNull(vertexCode) && isBlankOrNull(errorMessage) && notNull(confidenceIndicator)
    				&& parmMinimumConfidence.compareTo(new BigInteger(confidenceIndicator)) <= 0 ) {
    			shouldUpdateAddress = Bool.TRUE;
    			return;
    		}
    		
    		// If EXCEPTION-MODE is blank or Vertex does not return error, process next Address
    		if(isNull(parmExceptionMode) || isBlankOrNull(vertexCode)) {
    			return;
    		}
    		
        	FeatureConfiguration_Id vertexFeatureConfigId = new FeatureConfiguration_Id(VERTEX_FEATURE_CONFIG);
        	FeatureConfiguration vertexFeatureConfig = vertexFeatureConfigId.getEntity();
        	
        	// If an AddressCleansingResultMessage was returned in the Vertex response, check if any of the 
        	// Feature Configuration CM_VERTEXCFG Message Feature Message Codes match the AddressCleansingResultMessage code
        	ListFilter<FeatureConfigurationMessage> featConfigMessageFilter = vertexFeatureConfig.getMessages()
        			.createFilter("where this.id.wfmMessage = :vertexCode", getClass().getName());
        	featConfigMessageFilter.bindStringProperty("vertexCode", FeatureConfigurationMessage.properties.wfmMessage, vertexCode);
        	
        	Message_Id messageId = null;
        	Bool hasMsgParm = Bool.FALSE;
        	String msgParm = null;
        	FeatureConfigurationMessage featConfigMessage = featConfigMessageFilter.firstRow();
        	if(notNull(featConfigMessage)) {
        		messageId = featConfigMessage.getMessage().getId();
        		errorMessage = featConfigMessage.getMessage().fetchActiveMessageText();
        	} else {
        		ServerMessage serverMsg = CustomMessageRepositorySpireOne.CCB011_applicationError(errorMessage);
        		messageId = serverMsg.getMessageId();
        		hasMsgParm = Bool.TRUE;
        		msgParm = serverMsg.getMessageText();
        	}
        	
        	if(parmExceptionMode.equals(TODO_STR)) {
        		// Create a To Do Entry 
        		createToDo(messageId, hasMsgParm, msgParm, vertexState, vertexCounty, inputCounty, confidenceIndicator);
        		
        	} else if(parmExceptionMode.equals(FILE_STR)) {
        		// Add record to the file
        		// Start Change - NMendo - CCB011.Issue5 -  2021-06-09
        		//writeFileRecord(inputState, inputCounty, confidenceIndicator, errorMessage);
        		writeFileRecord(inputState, inputCounty, confidenceIndicator, errorMessage, inputAddress1);
        		// End Change - NMendo - CCB011.Issue5 -  2021-06-09
        	}
        	
        }
        
        /**
         * Create To Do Entry 
         * @param errorMessage
         * @param messageId
         * @param mainDivision
         * @param subDivision
         * @param county
         * @param confidenceIndicator
         */
        private void createToDo(Message_Id messageId, Bool hasMsgParm, String msgParm, String mainDivision, 
        		String subDivision, String county, String confidenceIndicator) {
        	ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
            ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();
                        
            toDoEntryDTO.setBatchControlId(batchControlId);
            toDoEntryDTO.setBatchNumber(getBatchNumber());
            toDoEntryDTO.setCreationDateTime(getProcessDateTime());
            toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
            toDoEntryDTO.setToDoTypeId(toDoType.getId());
            toDoEntryDTO.setMessageId(messageId);
                        
            toDoCreator.setToDoDTO(toDoEntryDTO);
            // If MainDivision was returned, add it as a Sort Key
            if(!isBlankOrNull(mainDivision)) {
            	toDoCreator.addSortKeyValue(new ToDoSortKeyType_Id(toDoType, BigInteger.ONE).getEntity(), mainDivision);
            }
            
            // If SubDivision was returned, add it as a Sort Key
            // If no SubDivision was returned, use the existing County
            if(!isBlankOrNull(subDivision)) {
            	toDoCreator.addSortKeyValue(new ToDoSortKeyType_Id(toDoType, BigInteger.valueOf(2)).getEntity(), subDivision);
            } else if(!isBlankOrNull(county)) {
            	toDoCreator.addSortKeyValue(new ToDoSortKeyType_Id(toDoType, BigInteger.valueOf(2)).getEntity(), county);
            }
            
            // If Confidence Indicator was returned, use it as a Sort Key
            if(!isBlankOrNull(confidenceIndicator)) {
            	toDoCreator.addSortKeyValue(new ToDoSortKeyType_Id(toDoType, BigInteger.valueOf(3)).getEntity(), confidenceIndicator);
            }
            
            // Use the Account ID and Person ID as the Drill Keys
            toDoCreator.addDrillKeyValue(new ToDoDrillKeyType_Id(toDoType, BigInteger.ONE).getEntity(), accountIdStr);
            toDoCreator.addDrillKeyValue(new ToDoDrillKeyType_Id(toDoType, BigInteger.valueOf(2)).getEntity(), personIdStr);
            
            if(hasMsgParm.isTrue()) {
            	toDoCreator.addMessageParameter(msgParm);
            }
            
            toDoCreator.create();
            numberOfAddressRequiringAttention++;
        }
        
        /**
         * This method check if the Address is in the Mailing Address Cleansing Exception table.
         * @param address1
         * @param city
         * @param state
         * @return
         */
        private Bool isAddressExempted(String address1, String city, String state) {
        	Bool isExempted = Bool.FALSE;
        	
        	StringBuilder sb = new StringBuilder();
        	sb.append("SELECT CM_LAST_USED_DT ");
        	sb.append("FROM CM_ADDR_VAL_EXEMPT ");
        	sb.append("WHERE UPPER(ADDRESS1) = :address1 ");
        	sb.append("AND UPPER(CITY) = :city ");
        	sb.append("AND UPPER(STATE) = :state ");
        	sb.append("AND ACTIVE_SW = :activeSw ");
        	
        	PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
        	ps.bindStringProperty("address1", Premise.properties.address1, address1);
        	ps.bindStringProperty("city", Premise.properties.city, city);
        	ps.bindStringProperty("state", Premise.properties.state, state);
        	ps.bindBoolean("activeSw", Bool.TRUE);
        	
        	SQLResultRow result = ps.firstRow();
        	ps.close();
        	
        	if(notNull(result)) {
        		isExempted = Bool.TRUE;
        		Date lastUsedDate = result.getDate("CM_LAST_USED_DT");
        		Date processDate = getProcessDateTime().getDate();
        		
        		// If the Last Used Date of the record is earlier than the Batch Business Date
        		if(lastUsedDate.isBefore(processDate)) {
        			// Update the record's Last Used Date with Batch Business Date
        			StringBuilder sb2 = new StringBuilder();
                	sb2.append("UPDATE CM_ADDR_VAL_EXEMPT ");
                	sb2.append("SET CM_LAST_USED_DT = :processDate ");
                	sb2.append("WHERE UPPER(ADDRESS1) = :address1 ");
                	sb2.append("AND UPPER(CITY) = :city ");
                	sb2.append("AND UPPER(STATE) = :state ");
                	sb2.append("AND ACTIVE_SW = :activeSw ");
                	
                	PreparedStatement ps2 = createPreparedStatement(sb2.toString(), getClass().getName());
                	ps2.bindStringProperty("address1", Premise.properties.address1, address1);
                	ps2.bindStringProperty("city", Premise.properties.city, city);
                	ps2.bindStringProperty("state", Premise.properties.state, state);
                	ps2.bindBoolean("activeSw", Bool.TRUE);
                	ps2.bindDate("processDate", processDate);
                	ps2.executeUpdate();
                	ps2.close();
        		}
        	}
        	
        	return isExempted;
        }
        
        /**
         * Form File Path Name
         */
        private void formFilePathName() {
        	String filePath = parmFilePath;
        	String fileName = parmFileName;

			// Replace all \ with / and make sure that the file path ends with a /
			if (!filePath.trim().endsWith(FORWARDSLASH)
					&& !filePath.trim().endsWith(BACKSLASH)) {
				filePath = filePath.trim().concat(BACKSLASH);
			}
			filePath = filePath.replace(FORWARDSLASH, BACKSLASH);

			// Append the thread number before the last period of the file name if there is more than one thread
			if (getParameters().getThreadCount().intValue() > 1){
				String threadNumberStr = getBatchThreadNumber().toString();
				
				if(fileName.contains(PERIOD)) {
					int lastIdx = fileName.lastIndexOf(PERIOD);
					
					StringBuilder sb = new StringBuilder();
					sb.append(fileName.substring(0, lastIdx));
					sb.append(threadNumberStr);
					// Start Change - NMendo - CCB011.Issue4 -  2021-06-02
					//sb.append(PERIOD);
					//sb.append(fileName.substring(lastIdx + threadNumberStr.length()));
					sb.append(fileName.substring(lastIdx));
					// End Change - NMendo - CCB011.Issue4 -  2021-06-02
					fileName = sb.toString();
					
				} else {
					fileName = fileName.concat(threadNumberStr);
				}
            }

			filePathName = filePath.trim().concat(fileName.trim());
		}
        
        /**
         * Write File Header
         */
        private void writeFileHeader() {
        	StringBuilder sb = new StringBuilder();
        	sb.append(ACCOUNT_ID_HEADER);
        	sb.append(COMMA);
        	sb.append(PERSON_ID_HEADER);
        	sb.append(COMMA);
        	// Start Add - NMendo - CCB011.Issue5 -  2021-06-09
        	sb.append(ADDRESS1_HEADER);
        	sb.append(COMMA);
        	// End Add - NMendo - CCB011.Issue5 -  2021-06-09
        	sb.append(STATE_HEADER);
        	sb.append(COMMA);
        	sb.append(COUNTY_HEADER);
        	sb.append(COMMA);
        	sb.append(CONFIDENCE_INDICATOR_HEADER);
        	sb.append(COMMA);
        	sb.append(ERROR_MESSAGE_HEADER);
        	
        	writeToFile(sb.toString());
        }
        
        /**
         * Write File Record
         * @param state
         * @param county
         * @param confidenceIndicator
         * @param errorMessage
         * @param address1
         */
        // Start Change - NMendo - CCB011.Issue5 -  2021-06-09
        //private void writeFileRecord(String state, String county, String confidenceIndicator, String errorMessage) {
        private void writeFileRecord(String state, String county, String confidenceIndicator, String errorMessage, String address1) {
        // End Change - NMendo - CCB011.Issue5 -  2021-06-09
        	StringBuilder sb = new StringBuilder();
        	sb.append(DOUBLE_QUOTE);
        	sb.append(accountIdStr);
        	sb.append(DOUBLE_QUOTE);
        	sb.append(COMMA);
        	sb.append(DOUBLE_QUOTE);
        	sb.append(personIdStr);
        	sb.append(DOUBLE_QUOTE);
        	sb.append(COMMA);
        	// Start Add - NMendo - CCB011.Issue5 -  2021-06-09
        	sb.append(DOUBLE_QUOTE);
        	sb.append(address1);
        	sb.append(DOUBLE_QUOTE);
        	sb.append(COMMA);
        	// End Add - NMendo - CCB011.Issue5 -  2021-06-09
        	sb.append(state);
        	sb.append(COMMA);
        	sb.append(county);
        	sb.append(COMMA);
        	sb.append(confidenceIndicator);
        	sb.append(COMMA);
        	sb.append(DOUBLE_QUOTE);
        	sb.append(errorMessage);
        	sb.append(DOUBLE_QUOTE);
        	
        	writeToFile(sb.toString());
        	numberOfAddressRequiringAttention++;
        }
        
        /**
         * Open File
         */
		private void openFile() {
			try {
				File file = new File(filePathName);
				FileWriter fileWriter = new FileWriter(file);
				buffWriter = new BufferedWriter(fileWriter);
			} catch (Exception e) { 
				// Error encountered opening file (%1%2%3%4).
				addError(CustomMessageRepositorySpireOne.CCB011_errorOpeningFile(filePathName));
			}
		}
		
		/**
		 * Write to File
		 * @param stringToWrite
		 */
		private void writeToFile(String stringToWrite) {
			try {
				buffWriter.write(stringToWrite);
				buffWriter.write(CARRIAGE_RETURN_LINE_FEED);
			} catch (Exception e) {
				// Error encountered writing to file (%1%2%3%4).
				addError(CustomMessageRepositorySpireOne.CCB011_errorWritingFile(filePathName));
			}
		}

		/**
		 * Close File
		 */
		private void closeFile() {
			try {
				buffWriter.close();
			} catch (Exception e) {
				// Error encountered closing file (%1%2%3%4).
				addError(CustomMessageRepositorySpireOne.CCB011_errorClosingFile(filePathName));
			}
		}
		
		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
			if(notNull(parmExceptionMode) && parmExceptionMode.equals(FILE_STR)) {
				// Close File
				closeFile();
			}
			
			// Number of auto-updated Mailing Addresses: %1
			logInfo(CustomMessageRepositorySpireOne.CCB011_numberOfUpdatedAddress(String.valueOf(numberOfUpdatedAddress)));
			
			// Number of Mailing Addresses requiring attention: %1
            logInfo(CustomMessageRepositorySpireOne.CCB011_numberOfAddressRequiringAttention(String.valueOf(numberOfAddressRequiringAttention)));
		}
    }
}
