/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Delete Case Characteristics 
 * 
 * This algorithm will delete any Case Characteristics given the 
 * Characteristic Type. 
 *            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-04-04   JPunza  NI0007.5 Initial Version.
 * 2016-01-22   MPang	Updated for CCB v2.4 compilation
 *************************************************************************/

package com.splwg.cm.domain.admin.caseType;

import java.math.BigInteger;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.ccb.api.lookup.CaseLogTypeLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;

//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseTypeEnterStatusAlgorithmSpot;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameter_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameter_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameters;
import com.splwg.ccb.domain.todo.toDoCase.CaseLog_DTO;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCaseCharacteristics;*/

import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.algorithm.enterStatus.EnterStatusAlgorithmSpot;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameter_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameter_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameters;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCaseCharacteristics;

//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.cm.domain.customMessages.CustomMessagesMDC;

/**
 * @author jpunzalan2
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeToDelete, required = true, type = entity)})
 */
public class CmDeleteCaseCharacteristicAlgComp_Impl 
        extends CmDeleteCaseCharacteristicAlgComp_Gen 
      //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        // implements CaseTypeEnterStatusAlgorithmSpot {
	implements EnterStatusAlgorithmSpot {
	//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
    // Soft Parameter
    private CharacteristicType charTypeToDelete;
    
    // Hard Parameter
    private ToDoCase toDoCase;
    
    public String getNextCaseStatus() {
        return null;
    }

    public String getNextTransCondition() {
        return null;
    }

    public Bool getShouldAutoTransition() {
        return null;
    }

    public void setCase(ToDoCase arg0) {
        toDoCase = arg0;
    }

    public void setCaseOriginalStatus(CaseStatus arg0) {

    }
    
    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        
        // Characteristic Type To Delete
        charTypeToDelete = getCharacteristicTypeToDelete();
        if (validateCharacteristicEntity(charTypeToDelete, CharacteristicEntityLookup.constants.CASE).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0007_5_charTypeToDelInvalidForEntity(
                    getAlgorithm().getId().getTrimmedValue(),
                    charTypeToDelete.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.CASE.getLookupValue().fetchLanguageDescription()));
        }
        
        if (validateCharacteristicEntity(charTypeToDelete, CharacteristicEntityLookup.constants.CASE_LOG).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0007_5_charTypeToDelInvalidForEntity(
                    getAlgorithm().getId().getTrimmedValue(),
                    charTypeToDelete.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.CASE_LOG.getLookupValue().fetchLanguageDescription()));
        }
    }
    
    /**
     * This method validates if a characteristic type is valid for a specific characteristic entity.
     * @param charType - Characteristic Type
     * @param charEntityLookup - Characteristic Entity Lookup
     * @return Bool
     */
    private Bool validateCharacteristicEntity(CharacteristicType charType, CharacteristicEntityLookup charEntityLookup) {
        
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType.getId(), charEntityLookup);        
        if (isNull(charEntityId.getEntity())) {
            return Bool.FALSE;
        }
        
        return Bool.TRUE;
    }

    public void invoke() {
                
        // Check if characteristic is required on Case Type
        SQLResultRow result = checkIfCharIsRequiredOnCaseType().firstRow();
        if (notNull(result)) {
            addError(CustomMessageRepositoryMDC.NI0007_5_charTypeRequiredOnCaseType(
                    charTypeToDelete.getId().getTrimmedValue(),
                    result.getString("CASE_TYPE_CD")));
        }
        
        // Check if characteristic is required on Case Status
        result = checkIfCharIsRequiredOnCaseStatus().firstRow();
        if (notNull(result)) {
            addError(CustomMessageRepositoryMDC.NI0007_5_charTypeRequiredOnCaseStatus(
                    charTypeToDelete.getId().getTrimmedValue(),
                    result.getString("CASE_TYPE_CD"),
                    result.getString("CASE_STATUS_CD")));
        }
        
        // Retrieve Case Characteristics with a given Characteristic Type
        ToDoCaseCharacteristics caseChars = toDoCase.getCharacteristics();
        //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        //ListFilter<CaseCharacteristic> charFilter = caseChars.createFilter("where this.id.characteristicType = :charType");
        ListFilter<CaseCharacteristic> charFilter = caseChars.createFilter("where this.id.characteristicType = :charType" , getClass().getName());
        //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        charFilter.bindEntity("charType", charTypeToDelete);
        
        QueryIterator<CaseCharacteristic> iter = charFilter.iterate();
        while (iter.hasNext()) {
            
            // Delete Characteristic
            CaseCharacteristic caseChar = iter.next();                                
            caseChars.remove(caseChar);
            
            // Create Case Log
            CharacteristicTypeLookup charTypeLookup = charTypeToDelete.getCharacteristicType();
            String charValue = new String();
            if (charTypeLookup.isForeignKeyValue()) {
                charValue = caseChar.getCharacteristicValueForeignKey1().trim();
            }
            else if (charTypeLookup.isPredefinedValue()) {
                charValue = caseChar.getCharacteristicValue().trim();
            } 
            else { 
                charValue = caseChar.getAdhocCharacteristicValue().trim();
            }
            createCaseLog(caseChar.fetchIdSequence(), charValue);
        }
        iter.close();
    }
    
    /**
     * This method creates Case Log.
     * @param seqNum - Sequence Number
     * @param charValue - Characteristic Value
     */
    private void createCaseLog(BigInteger seqNum, String charValue) {
        
        // Create Case Log Entry
        CaseLog_DTO caseLogDto = new CaseLog_DTO();
        caseLogDto.setCaseStatusId(toDoCase.getCaseStatus().getId());
        caseLogDto.setCharacteristicTypeId(charTypeToDelete.getId());
        
        CharacteristicTypeLookup charTypeLookup = charTypeToDelete.getCharacteristicType();
        if (charTypeLookup.isForeignKeyValue()) {
            caseLogDto.setCharacteristicValueForeignKey1(charValue);
        }
        else if (charTypeLookup.isPredefinedValue()) {
            caseLogDto.setCharacteristicValue(charValue);
        }
        else {
            caseLogDto.setAdhocCharacteristicValue(charValue);
        }
        
        caseLogDto.setLogType(CaseLogTypeLookup.constants.SYSTEM);
        
        // Set Message Id
        MessageCategory_Id messageCategoryId = new MessageCategory_Id(BigInteger.valueOf(CustomMessagesMDC.MESSAGE_CATEGORY));
        caseLogDto.setMessageId(new Message_Id(messageCategoryId, BigInteger.valueOf(CustomMessagesMDC.NI0007_5_DCC_CASE_CHAR_DELETE)));
                
        // Get newly created Case Log
        CaseLog caseLog = toDoCase.getLogs().add(caseLogDto, null);                    

        CaseLogMessageParameters messageParms = caseLog.getMessageParameters();
        
        // Add message parameter for characteristic type
        CaseLogMessageParameter_DTO caseLogMsgParmDto = messageParms.newChildDTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.ONE));
        caseLogMsgParmDto.setMessageParameter(charTypeToDelete.getId().getTrimmedValue());        
        messageParms.add(caseLogMsgParmDto, BigInteger.ONE);
        
        // Add message parameter for sequence number
        caseLogMsgParmDto = messageParms.newChildDTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.valueOf(2)));
        caseLogMsgParmDto.setMessageParameter(seqNum.toString().trim());        
        messageParms.add(caseLogMsgParmDto, BigInteger.valueOf(2));
        
        // Add message parameter for characteristic value
        BigInteger sequence = BigInteger.valueOf(3);
        for (int i = 0; i <= charValue.length(); i = i + 29) {
                       
            caseLogMsgParmDto = messageParms.newChildDTO();
            caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, sequence));
            
            if (i + 29 > charValue.length()) {
                caseLogMsgParmDto.setMessageParameter(charValue.substring(i, charValue.length()));     
            }
            else {
                caseLogMsgParmDto.setMessageParameter(charValue.substring(i, i + 29));
            }
            messageParms.add(caseLogMsgParmDto, sequence); 
            sequence = sequence.add(BigInteger.ONE);
        }               
    }
    
    /**
     * This method checks if given Characteristic Type is required in Case Type.
     * @return PreparedStatement
     */
    private PreparedStatement checkIfCharIsRequiredOnCaseType() {
        
        PreparedStatement checkCharacteristic = createPreparedStatement("SELECT CHTY.CASE_TYPE_CD " +
                "FROM CI_CASE CS, CI_CHTY_CASETY CHTY " +
                "WHERE CS.CASE_ID = :case " +
                "AND CHTY.CASE_TYPE_CD = CS.CASE_TYPE_CD " +
                "AND CHTY.CHAR_TYPE_CD = :charType " +
              //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
              // "AND CHTY.REQUIRED_SW = :required");
        		"AND CHTY.REQUIRED_SW = :required", getClass().getName());
        	//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        
        checkCharacteristic.bindEntity("case", toDoCase);
        checkCharacteristic.bindEntity("charType", charTypeToDelete);
        checkCharacteristic.bindBoolean("required", Bool.TRUE);
        
        return checkCharacteristic;
    }
    
    /**
     * This method checks if given Characteristic Type is required in Case Status.
     * @return PreparedStatement
     */
    private PreparedStatement checkIfCharIsRequiredOnCaseStatus() {
        
        PreparedStatement checkCharacteristic = createPreparedStatement("SELECT CSTY.CASE_TYPE_CD, CSTY.CASE_STATUS_CD " +
                "FROM CI_CASE CS, CI_CASE_ST_CHTY CSTY " +
                "WHERE CS.CASE_ID = :case " +
                "AND CSTY.CASE_STATUS_CD = CS.CASE_STATUS_CD " +
              //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
              //  "AND CSTY.CHAR_TYPE_CD = :charType");
        		"AND CSTY.CHAR_TYPE_CD = :charType", getClass().getName());
        	 //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        checkCharacteristic.bindEntity("case", toDoCase);
        checkCharacteristic.bindEntity("charType", charTypeToDelete);
        
        return checkCharacteristic;
    }
}
