/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Column Delimited Record class for ACH Transaction Header
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-05-27   RDizon  CCB041. Initial version.        
 **************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

/**
 * @author RDizon
 */
public class CmCheckExtractTransactionHeaderRecord extends ColumnDelimitedRecord {
    
    private static final String DELIMITER = "|";
        
    public CmCheckExtractTransactionHeaderRecord() {
        super(13);
    }
    
    public void setRecordType(String value) {
        this.leftPadColumn(1, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setTransactionHeader1(String value) {
        this.leftPadColumn(2, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setTransactionHeader2(String value) {
        this.leftPadColumn(3, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setTransactionHeader3(String value) {
        this.leftPadColumn(4, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setTransactionHeader4(String value) {
        this.leftPadColumn(5, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setTransactionHeader5(String value) {
        this.leftPadColumn(6, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setTransactionHeader6(String value) {
        this.leftPadColumn(7, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setTransactionHeader7(String value) {
        this.leftPadColumn(8, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setTransactionHeader8(String value) {
        this.leftPadColumn(9, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setSignatureCode1(String value) {
        this.leftPadColumn(10, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setSignatureCode2(String value) {
        this.leftPadColumn(11, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setStubLogoCode(String value) {
        this.leftPadColumn(12, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setCheckLogoCode(String value) {
        this.leftPadColumn(13, value.length() + 1, value.trim());
    }
    
}
