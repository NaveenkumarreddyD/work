/**************************************************************************
* Program Name: CmTransferOldBalanceToNewGasSAAlgComp_Impl
* Program Title: CmTransferOldBalanceToNewGasSAAlgComp_Impl
* Author: Joshua Ace Vitug
* Creation Date: 2018-03-02
* Purpose: When a new gas SA is activated, if the account has any stopped 
*          gas SAs, this algorithm will transfer the balance from the 
*          stopped SA to the newly activated one.
* Functional Spec: CCB-CC-022-2.6
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  CCB-CC-022-2.6    JVitug           2018-03-02    CCB-CC-022-2.6. Initial Version                
 *  CCB-CC-023B-2     Kiran			   2018-08-29	 Add SA type WOTAXC','WOGAS','WOTAXS','WOTAXG'
 *  Defect 4143525	  Kiran			   2018-10-30    Process WOGAS adjustment at the end
 *  CCB v2.6 Upgrade  SRoman		   2018-12-11	 Merged the changes from Spire PRD version for 
 *  												 the 2.4 to 2.6 Upgrade Activity   
 *  47167_S1_CS_B19796 Kiran		   2022-01-06    add Pending STOP SA status                                                                                                                                                                                                                                                      
 ************************************************************************************************/
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.saActivation;

import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saActivation.SaTypeSaActivationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author JVitug
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentType, name = syncAdjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = transferAdjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = customerClassToExclude, required = true, type = string)})
 */
public class CmTransferOldBalanceToNewGasSAAlgComp_Impl 
		extends CmTransferOldBalanceToNewGasSAAlgComp_Gen 
		implements SaTypeSaActivationAlgorithmSpot {
    
	// Hard parameters
    private ServiceAgreement newServiceAgreement;
    
    //Soft parameters
    AdjustmentType syncAdjustmentType;
    AdjustmentType transferAdjustmentType;
    String customerClassToExclude;
    String[] customerClassToExcludeArray;
    
    //Constants
    private String GAS_SERVICE_TYPE = "G";
    
    public void setServiceAgreement(ServiceAgreement serviceAgreement) {
        this.newServiceAgreement = serviceAgreement;
    }

    @Override
    protected void extraSoftParameterValidations() {
        syncAdjustmentType = getSyncAdjustmentType();
        transferAdjustmentType = getTransferAdjustmentType();
        customerClassToExclude = getCustomerClassToExclude().trim();
        
        customerClassToExcludeArray = customerClassToExclude.split(",");
        
        if(customerClassToExcludeArray.length < 1){
            addError(CustomMessageRepository.CCB_CC_022_24_custClassParmIsEmpty());
        }
        
        //validate each customer class Id in the string if it exists
        for(int i = 0 ; i < customerClassToExcludeArray.length ; i ++){
            CustomerClass_Id ccId = new CustomerClass_Id(customerClassToExcludeArray[i].trim());
            if(isNull(ccId.getEntity())){
                addError(CustomMessageRepository.CCB_CC_022_24_custClassDoesNotExist(ccId.getIdValue().toString().trim()));
            }
        }
    }
    
    public void invoke() {
        String accountCustomerClass;
        Account account;
        accountCustomerClass = newServiceAgreement.getAccount().getCustomerClass().getId().toString().trim();
        account = newServiceAgreement.getAccount();
        List<ServiceAgreement_Id> saList = new ArrayList<ServiceAgreement_Id>();
        Bool shouldExcludeAccount = Bool.FALSE;
        
        // If the customer class of the account linked to this service agreement
        // is not included in the list of Customer Classes to be excluded, 
        // continue processing
        for(int i = 0 ; i < customerClassToExcludeArray.length ; i++){
            CustomerClass_Id custClass = new CustomerClass_Id(customerClassToExcludeArray[i].trim());
            if(accountCustomerClass.compareTo(custClass.toString().trim()) == 0){
                shouldExcludeAccount = Bool.TRUE;
                break;
            }
        }
        
        if(shouldExcludeAccount.isFalse()){
            saList = retrieveServiceAgreementsOfAccount(account);
            for(ServiceAgreement_Id saId : saList){
                //If this SA's pay off balance is not zero, continue processing
                if(!saId.getEntity().getPayoffBalance().isZero()){
                    //If this SA's current and payoff balance are not equal to each other, we first 
                    //create a sync adjustment
                    if(!saId.getEntity().getCurrentBalance().isEqualTo(saId.getEntity().getPayoffBalance())){
                        createSynchAdjustment(syncAdjustmentType, saId.getEntity());
                    }
                    //Transfer the remaining balance to the new SA
                    createTransferAdjustment(saId.getEntity(), newServiceAgreement, saId.getEntity().getPayoffBalance(),transferAdjustmentType);
                }
            }
        }
    }
    /**
     * Create synch adjustment
     * @param synchAdjustmentType
     * @param sa
     */
    private void createSynchAdjustment(AdjustmentType synchAdjustmentType, ServiceAgreement sa){
        
        CreateFrozenAdjustmentData adjData = CreateFrozenAdjustmentData.Factory.newInstance();
        CreateFrozenAdjustment createFrozenAdjustmentRoutine = CreateFrozenAdjustment.Factory.newInstance();
        
        adjData.setServiceAgreement(sa);
        adjData.setAdjustmentType(synchAdjustmentType);
        adjData.setAdjustmentDate(this.getProcessDateTime().getDate());
        adjData.setAllowZeroAmount(Bool.FALSE);
        
     // Use Java Enabled class (CIPAAFZN)
        createFrozenAdjustmentRoutine.createFrozenAdjustment(adjData);
    }
    /**
     * Create a transfer adjustment
     * @param sa
     * @param xferSa
     * @param adjAmount
     * @param adjType
     */
    private void createTransferAdjustment(ServiceAgreement sa, ServiceAgreement xferSa, Money adjAmount, AdjustmentType adjType) {

        CreateFrozenAdjustmentData adjustmentData = CreateFrozenAdjustmentData.Factory.newInstance();

        adjustmentData.setServiceAgreement(sa);
        adjustmentData.setTransferServiceAgreement(xferSa);
        adjustmentData.setAdjustmentAmount(adjAmount);
        adjustmentData.setAdjustmentType(adjType);
        adjustmentData.setAllowZeroAmount(Bool.FALSE);

        CreateFrozenAdjustment createFrozenAdjustment = CreateFrozenAdjustment.Factory.newInstance();
        createFrozenAdjustment.createFrozenAdjustment(adjustmentData);
    }
    /**
     * Retrieve stopped gas service agreements of account
     * @param account
     * @return
     */
    private List<ServiceAgreement_Id> retrieveServiceAgreementsOfAccount(Account account){
        StringBuilder stringGetSa = new StringBuilder();
        PreparedStatement queryGetSa;
        List<ServiceAgreement_Id> saList = new ArrayList<ServiceAgreement_Id>();
        
        stringGetSa.append("SELECT A.SA_ID AS SA_ID ");
        stringGetSa.append("FROM CI_SA A, CI_SA_TYPE B ");
        stringGetSa.append("WHERE A.ACCT_ID = :acctId ");
        stringGetSa.append(  "AND A.SA_STATUS_FLG IN (:stopped, :pendStop) ");
        stringGetSa.append(  "AND A.SA_TYPE_CD = B.SA_TYPE_CD ");
        stringGetSa.append(  "AND A.CIS_DIVISION = B.CIS_DIVISION ");
        stringGetSa.append(  "AND ( B.SVC_TYPE_CD = :gasServiceType OR ");
        // CCB-CC-023B-2	 Start of change
        stringGetSa.append(  "B.SA_TYPE_CD  IN ('WOTAXC','WOTAXS','WOTAXG') )");
        // CCB-CC-023B-2	 End of change 
        queryGetSa = createPreparedStatement(stringGetSa.toString(), this.getClass().getName());
        queryGetSa.bindEntity("acctId", account);
        queryGetSa.bindLookup("stopped",ServiceAgreementStatusLookup.constants.STOPPED);
        queryGetSa.bindLookup("pendStop",ServiceAgreementStatusLookup.constants.PENDING_STOP);
        queryGetSa.bindString("gasServiceType", GAS_SERVICE_TYPE, "SVC_TYPE_CD");
        
        for(SQLResultRow sqlRow : queryGetSa.list()){
            saList.add(new ServiceAgreement_Id(sqlRow.getString("SA_ID").trim()));
        }
        
        queryGetSa.close();
        
        // Defect 4143525	  Kiran		2018-10-30    process WOGAS adjustment at the end 
        StringBuilder stringGetSa1 = new StringBuilder();
        PreparedStatement queryGetSa1;
       
        stringGetSa1.append("SELECT A.SA_ID AS SA_ID ");
        stringGetSa1.append("FROM CI_SA A, CI_SA_TYPE B ");
        stringGetSa1.append("WHERE A.ACCT_ID = :acctId ");
        stringGetSa1.append(  "AND A.SA_STATUS_FLG IN (:stopped, :pendStop) ");
        stringGetSa1.append(  "AND A.SA_TYPE_CD = B.SA_TYPE_CD ");
        stringGetSa1.append(  "AND A.CIS_DIVISION = B.CIS_DIVISION ");
        stringGetSa1.append(  "AND ( B.SVC_TYPE_CD = :gasServiceType OR ");
        //CCB-CC-023B-2	  Start of change
        stringGetSa1.append(  "B.SA_TYPE_CD  IN ('WOGAS') )");
        // CCB-CC-023B-2	 end of change 
        queryGetSa1 = createPreparedStatement(stringGetSa1.toString(), this.getClass().getName());
        queryGetSa1.bindEntity("acctId", account);
        queryGetSa1.bindLookup("stopped",ServiceAgreementStatusLookup.constants.STOPPED);
        queryGetSa1.bindLookup("pendStop",ServiceAgreementStatusLookup.constants.PENDING_STOP);
        queryGetSa1.bindString("gasServiceType", GAS_SERVICE_TYPE, "SVC_TYPE_CD");
        
        for(SQLResultRow sqlRow : queryGetSa1.list()){
            saList.add(new ServiceAgreement_Id(sqlRow.getString("SA_ID").trim()));
        }
        
        queryGetSa1.close();
        
        return saList;
    }

}