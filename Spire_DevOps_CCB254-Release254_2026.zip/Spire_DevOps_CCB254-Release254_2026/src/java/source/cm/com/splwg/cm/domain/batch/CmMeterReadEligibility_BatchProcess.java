/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NB0059 -  Meter Read Eligibility
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2012-12-03   Rakesh          NB0059. Initial Version.
 * 2013-11-06   Neha            IM-040516 check for Case Condition Flag instead of Case status
 * 2016-01-29  	MPang			Updated for CCB v2.4 compilation. 
 * 2021-07-12	Ravi			46714 Static variable removal and code cleanup and updating
 * 								logic to fetch only meter reads to be updated in main query
 ******************************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.ThreadWorker;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterReadRegisterReads;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_DTO;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead_DTO;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 *
@BatchJob (
 *                      modules = {},
 *                      multiThreaded = true,
 *              rerunnable = false,
 *                      softParameters = { @BatchJobSoftParameter (entityName = caseType, name = METER_EXCEPTION_CASE_TYPE, required = true, type = entity)
 *                                         , @BatchJobSoftParameter (name = CASE_COND_FLG, required = true, type = lookup, lookupName=caseCondition)
 *                                         , @BatchJobSoftParameter (entityName = characteristicType, name = SPID_CASE_CHAR_TYPE, required = true, type = entity)})
 */

public class CmMeterReadEligibility_BatchProcess extends
CmMeterReadEligibility_BatchProcess_Gen {

	//  Soft Parameters
	private CaseType parmMeterExceptionCaseType;
	private CaseConditionLookup parmCaseCondLookup;
	private CharacteristicType parmCharType;
	private BigInteger parmMaxErrors;

	public JobWork getJobWork() {

		StringBuilder getMeterReadsString = new StringBuilder();
		getMeterReadsString.append("SELECT DISTINCT MR1.MR_ID ");
		getMeterReadsString.append("FROM CI_MR MR1, CI_REG_READ RR ");
		getMeterReadsString.append("WHERE RR.REVIEW_HILO_SW =:reviewHighLowSwitch ");
		getMeterReadsString.append("AND RR.MR_ID = MR1.MR_ID ");
		getMeterReadsString.append("AND EXISTS (");
		getMeterReadsString.append(" SELECT 'X' ");
		getMeterReadsString.append("FROM CI_MR MR, CI_SP_MTR_HIST MH, ");
		getMeterReadsString.append( "CI_CASE CASE, CI_CASE_CHAR CCHAR ");
		getMeterReadsString.append( "WHERE MH.MTR_CONFIG_ID = MR.MTR_CONFIG_ID ");
		getMeterReadsString.append( "AND (MH.REMOVAL_DTTM IS NULL OR MH.REMOVAL_DTTM >= MR.READ_DTTM) ");
		getMeterReadsString.append( "AND MR.MR_ID = MR1.MR_ID ");
		getMeterReadsString.append( " AND CASE.CASE_TYPE_CD= :caseType ");
		getMeterReadsString.append( " AND CASE.CASE_COND_FLG = :caseCondFlg ");
		getMeterReadsString.append( "AND CASE.CASE_ID = CCHAR.CASE_ID ");
		getMeterReadsString.append( "AND CCHAR.CHAR_TYPE_CD = :caseCharTypeCD ");
		getMeterReadsString.append( "AND CCHAR.CHAR_VAL_FK1 = MH.SP_ID ");
		getMeterReadsString.append( " ) ");

		PreparedStatement meterReadsPrepStmt = createPreparedStatement(getMeterReadsString.toString(), getClass().getName()); 
		meterReadsPrepStmt.bindBoolean("reviewHighLowSwitch", Bool.TRUE);  
		meterReadsPrepStmt.bindId("caseType", parmMeterExceptionCaseType.getId());
		meterReadsPrepStmt.bindLookup("caseCondFlg", parmCaseCondLookup);
		meterReadsPrepStmt.bindId("caseCharTypeCD",parmCharType.getId());

		QueryIterator mainIter = meterReadsPrepStmt.iterate();

		return createJobWorkForQueryIterator(mainIter, this);
	}

	public ThreadWorkUnit createWorkUnit(QueryResultRow row) {

		ThreadWorkUnit threadUnit = new ThreadWorkUnit();
		MeterRead_Id meterReadId = (MeterRead_Id) row.getId("MR_ID", MeterRead.class);
		threadUnit.setPrimaryId(meterReadId);
		return threadUnit;
	}

	public Class<CmMeterReadEligibility_BatchProcessWorker> getThreadWorkerClass() {
		return CmMeterReadEligibility_BatchProcessWorker.class;
	}

	/**
	 * @return void
	 *  This method retrieves Batch Param varaibles and validates them
	 */  
	public void validateSoftParameters(boolean isNewRun){

		parmMeterExceptionCaseType = getParameters().getMETER_EXCEPTION_CASE_TYPE();
		parmCaseCondLookup = getParameters().getCASE_COND_FLG();
		parmCharType = getParameters().getSPID_CASE_CHAR_TYPE();
		parmMaxErrors = getParameters().getSoftMaxErrors();

		// Validate Case Characteristic Type
		validateCharactersticType(parmCharType,CharacteristicEntityLookup.constants.CASE,CharacteristicEntityLookup.constants.CASE.toString());

		// Check if the override maximum errors is less than 0 
		if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
			addError(CustomMessageRepository.nb059MaxErrorIsInvalid(parmMaxErrors.toString().trim()));
		}
	}

	/**
	 * @return void 
	 * @param CharacteristicType parmCharType, CharacteristicEntityLookup parmEntityLookup,String parmEntityName
	 * This method Processes Eligible Meter Reads
	 * 
	 */ 
	public void validateCharactersticType(CharacteristicType parmCharType, CharacteristicEntityLookup parmEntityLookup,String parmEntityName){
		CharacteristicEntity_Id characteristicEntityId = new CharacteristicEntity_Id(parmCharType, parmEntityLookup);
		if (isNull(characteristicEntityId.getEntity())){
			addError(CustomMessageRepository.nb0059BatchParmCharTypeInvalid(parmCharType.getId().getTrimmedValue(),parmEntityName));
		} 
	}


	public static class CmMeterReadEligibility_BatchProcessWorker
	extends
	CmMeterReadEligibility_BatchProcessWorker_Gen {

		private final String MTRCONFIG_ID = "C1_T_MTR_CONFIG_ID";


		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy ((ThreadWorker) this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			startChanges();
			MeterRead_Id meterReadId  = (MeterRead_Id )unit.getPrimaryId();
			processEligibleMeterReadRecords(meterReadId);
			saveChanges();
			return true;
		}

		/**
		 * @return void 
		 * @param Meter Read Id
		 * This method Processes Eligible Meter Reads
		 * 
		 */ 
		public void processEligibleMeterReadRecords(MeterRead_Id mrId){
			updateUseOnBill(mrId.getEntity());
		}

		/**
		 * @return void 
		 * @param Meter Read
		 * This method updates Use On Bill Flag on Meter Read and High Low Review Flag on Register Read 
		 * 
		 */ 
		private void updateUseOnBill(MeterRead meterRead){

			RegisterRead_DTO regDTO;
			MeterReadRegisterReads meterRegReads  = meterRead.getRegisterReads();
			String mtrConfig =  meterRead.getMeterConfiguration().getId().getIdValue();

			for (RegisterRead registerRead : meterRegReads) {
				regDTO = registerRead.getDTO();
				regDTO.setIsHighLowReviewed(Bool.FALSE);
				regDTO.setExtraTCopybookFieldValue(MTRCONFIG_ID, mtrConfig);					
				registerRead.setDTO(regDTO);
			}
			MeterRead_DTO meterReadDTO = meterRead.getDTO();
			meterReadDTO.setCanUseOnBill(Bool.FALSE);
			meterRead.setDTO(meterReadDTO);
		}

	}

}