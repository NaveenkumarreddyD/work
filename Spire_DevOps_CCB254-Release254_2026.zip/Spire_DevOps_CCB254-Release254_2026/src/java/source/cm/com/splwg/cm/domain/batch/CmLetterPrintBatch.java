/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Letter Extract Batch Job.
 * 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2020-04-06   JHERNA  SysAid#322461. Initial Version.
 * 2021-04-14   RDizon  CCB034. Added Separate CIS Divisions batch parameter.
 * 2021-09-16   RDizon  CCB034.Issue4. For every file produced, write their
 *                          own 0010 record with the correct record count.
 * 2021-09-29   RDizon  Defect 4599345  Modify logic in checking the 
 *                      CIS Divisions.
 * 2024-04-10	IReyes	E-08254. Populate the Customer Contact Letter Print
 * 						Date Time field only when Customer Contact is
 * 						extracted on the file.  
 * 2024-11-06   DLampa  E-09710. Update how the extracted count is tallied.     
 * 2024-12-13   DLampa  E-09710.Issue1. Update the criterion for updating 
 *                      the print letter date/time on the customer contact 
 *                      record.                                             
 **************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.algorithm.Algorithm;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.letterTemplate.algorithm.letterExtract.LetterTemplateLetterExtractAlgorithmSpot;
import com.splwg.ccb.domain.admin.letterTemplate.entity.LetterTemplate;
import com.splwg.ccb.domain.admin.letterTemplate.entity.LetterTemplate_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.cm.api.batch.generalLetters.CmGeneralLetterControlRecord;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.common.ApplicationError;

/**
 * @author blu02772
 *
@BatchJob (modules = {}, softParameters = { @BatchJobSoftParameter (name = FILE_PATH, type = string)
 *            , @BatchJobSoftParameter (name = FIELD_DELIM_SW, type = boolean)
 *            , @BatchJobSoftParameter (name = CNTL_REC_SW, type = boolean)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)
 *            , @BatchJobSoftParameter (name = CIS_DIVISIONS, type = string)})
 */
public class CmLetterPrintBatch 
        extends CmLetterPrintBatch_Gen {
    
	@Override
    public void validateSoftParameters(boolean isNewRun) {
        
        if (this.getParameters().getFIELD_DELIM_SW().isTrue()) {
            addError(CustomMessageRepository.RI0016_delimNotAllowedOnLetterPrint());
        }
        
        // Start Add - CCB034 - RDizon - 04-14-2021
        if (notNull(this.getParameters().getCIS_DIVISIONS())){
            String[] parmCisDivisions = this.getParameters().getCIS_DIVISIONS().split(",");
            
            for (int i=0; i < parmCisDivisions.length; i++){
                String cisDivStr = parmCisDivisions[i];
                CisDivision cisDivision = new CisDivision_Id(cisDivStr.trim()).getEntity();
                if (isNull(cisDivision)){
                    addError(CustomMessageRepository.CCB034_BatchParameterContainsInvalidCisDivision(
                            "Separate CIS Divisions",
                            cisDivStr));
                }
            }
        }
        // End Add - CCB034 - RDizon - 04-14-2021
    }
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public JobWork getJobWork() {
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT CC_ID, LTR_TMPL_CD ");
        stringBuilder.append("FROM CI_CC ");
        stringBuilder.append("WHERE BATCH_CD = :batchCd ");
        stringBuilder.append("AND BATCH_NBR = :batchNbr ");
        stringBuilder.append("AND PRINT_LETTER_SW = :printLetterSw ");
        stringBuilder.append("ORDER BY LTR_TMPL_CD ASC ");
        
        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==Main Selection==");
        prepState.bindId("batchCd", this.getBatchControlId());
        prepState.bindBigInteger("batchNbr", this.getBatchNumber());
        prepState.bindBoolean("printLetterSw", Bool.TRUE);
        
        prepState.setAutoclose(true);
        prepState.execute();
        QueryIterator returnValue = prepState.iterate();
        return createJobWorkForQueryIterator(returnValue, this);        
    }

    @Override
    public ThreadWorkUnit createWorkUnit(QueryResultRow queryResultRow) {
        ThreadWorkUnit twu = new ThreadWorkUnit();
        CustomerContact_Id ccID = (CustomerContact_Id) queryResultRow.getId("CC_ID", CustomerContact.class);
        LetterTemplate_Id letterTemplateID = (LetterTemplate_Id) queryResultRow.getId("LTR_TMPL_CD", LetterTemplate.class);                
        twu.setPrimaryId(ccID);
        twu.addSupplementalData("LTR_TMPL_CD", letterTemplateID);
        return twu;
    }    

    public Class<CmLetterPrintBatchWorker> getThreadWorkerClass() {
        return CmLetterPrintBatchWorker.class;
    }

    public static class CmLetterPrintBatchWorker extends
            CmLetterPrintBatchWorker_Gen {

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new CommitEveryUnitStrategy(this);
        }
        
        /* *****************/
        /* SOFT PARAMETERS */
        /* *****************/
        
        private String parmFilePath;
        private Bool parmFieldDelimiterSw;
        private Bool parmControlRecordSwitch;
        // Start Add - CCB034 - RDizon - 04-14-2021
        private String parmCisDivisions;
        // End Add - CCB034 - RDizon - 04-14-2021

        /* ****************/
        /* WORK VARIABLES */
        /* ****************/        
        private BigInteger wCcExtractedCount;
        private BigInteger wPrevCount;
        private LetterTemplate_Id wPrevLetterTemplateID;
        private String wPrevFile;
        // Start Add - CCB034 - RDizon - 04-14-2021
        private Bool wSeparateCisDivisionSw = Bool.FALSE;
        // End Add - CCB034 - RDizon - 04-14-2021
        
        /* ********************/
        /* CONSTANT VARIABLES */
        /* ********************/
        private static final String LETTER_EXT = "LTR"; 
        private static final String PERIOD = ".";
        private static final String BLANK = " ";
        // Start Add - CCB034 - RDizon - 04-14-2021
        private static final String AL_GC_CIS_DIVISION = "AL_GC";
        // End Add - CCB034 - RDizon - 04-14-2021
        
        // Start Add - Defect 4599345 - RDizon - 09-29-2021
        private static final String ACCOUNT = "ACCOUNT";

        private Map<String,  BigInteger> extractFileMap = new HashMap<String,  BigInteger>();
        // End Add - Defect 4599345 - RDizon - 09-29-2021
        
        @Override
        public void initializeThreadWork(
                boolean initializationPreviouslySuccessful)
                throws ThreadAbortedException, RunAbortedException {
            parmFilePath = this.getParameters().getFILE_PATH();
            if (isBlankOrNull(parmFilePath)) {
                parmFilePath = new File("").getAbsolutePath();
            }
            
            parmFieldDelimiterSw = this.getParameters().getFIELD_DELIM_SW();
            parmControlRecordSwitch = this.getParameters().getCNTL_REC_SW();
            
            // Start Add - CCB034 - RDizon - 04-14-2021
            parmCisDivisions = this.getParameters().getCIS_DIVISIONS();
            // End Add - CCB034 - RDizon - 04-14-2021
            
			// Start Delete - Defect 4599345 - RDizon - 09-29-2021
            // wPrevFile = " ";  
            // wCcExtractedCount = BigInteger.ZERO;
            // wPrevCount = BigInteger.ZERO;
            // wPrevLetterTemplateID = null;
			// End Delete - Defect 4599345 - RDizon - 09-29-2021
        }

        @SuppressWarnings("deprecation")
        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {

            CustomerContact_Id ccID = (CustomerContact_Id) unit.getPrimaryId();
            LetterTemplate_Id letterTemplateID = (LetterTemplate_Id) unit.getSupplementallData("LTR_TMPL_CD");
            CustomerContact cc = ccID.getEntity();
            
            if (isNull(letterTemplateID)
                    || isNull(letterTemplateID.getEntity())) {
                addError(CustomMessageRepositoryMGE.commGenericError(cc.getCustomerContactType().fetchIdContactType().trim()
                        + " does not have a letter template. "));
                return false;
            }
            
            LetterTemplate letterTemplate = letterTemplateID.getEntity();
            if (isNull(letterTemplate.fetchExtractAlgorithm())) {
                addError(CustomMessageRepositoryMGE.commGenericError(letterTemplateID.getTrimmedValue() 
                        + " does not have an extract algorithm. "));
                return false;
            }
            // Start Delete - CCB034.Issue4 - RDizon - 09-16-2021
            // // Re-initialize the CC Extracted Count if this is for a different letter template
            // if (notNull(wPrevLetterTemplateID)
            //         && letterTemplateID.compareTo(wPrevLetterTemplateID) != 0) {
            //     wCcExtractedCount = BigInteger.ZERO;
            // }
            // End Delete - CCB034.Issue4 - RDizon - 09-16-2021
            
            // Start Add - CCB034 - RDizon - 04-14-2021
            if (notNull(parmCisDivisions)){
                
                String cisDivisionsInQuotes = "'" + parmCisDivisions.replaceAll(",", "','") + "'";
                
                // Start Add - Defect 4599345 - RDizon - 09-29-2021
                Account account = cc.fetchAccount();
                if (notNull(account)){
                    // Call query with specified Account ID
                    wSeparateCisDivisionSw = checkMainPersonCisDivisionWithAccount(cc.fetchPerson(),
                                                                                account,
                                                                                cisDivisionsInQuotes);
                }
                else {
                    CharacteristicType_Id charTypeId = new CharacteristicType_Id(ACCOUNT);
                    CustomerContactCharacteristic accountIdChar =  cc.getEffectiveCharacteristic(charTypeId.getEntity());

                    if (notNull(accountIdChar)){
                        // Call query with specified Account ID
                        wSeparateCisDivisionSw = checkMainPersonCisDivisionWithAccount(cc.fetchPerson(),
                                new Account_Id(accountIdChar.getCharacteristicValueForeignKey1().trim()).getEntity(),
                                cisDivisionsInQuotes);
                    }
                    else {
                        wSeparateCisDivisionSw = checkMainPersonCisDivision(cc.fetchPerson(), cisDivisionsInQuotes);
                    }
                }
                
                //wSeparateCisDivisionSw = checkMainPersonCisDivision(cc.fetchPerson(), cisDivisionsInQuotes);
                // End Add - Defect 4599345 - RDizon - 09-29-2021
            }
            // End Add - CCB034 - RDizon - 04-14-2021
            
            String fullPathName = createPathName(parmFilePath.trim(), letterTemplateID.getTrimmedValue());
            
            // Start Delete - Defect 4599345 - RDizon - 09-29-2021
            // Start Add - CCB034.Issue4 - RDizon - 09-16-2021
            // Re-initialize the CC Extracted Count if this is for a different file
            // if (notBlank(wPrevFile)
            //        && !fullPathName.equalsIgnoreCase(wPrevFile)) {
            //        wCcExtractedCount = BigInteger.ZERO;
            // }
            // End Add - CCB034.Issue4 - RDizon - 09-16-2021
            // End Delete - Defect 4599345 - RDizon - 09-29-2021
            
            Algorithm extractAlgo = letterTemplate.fetchExtractAlgorithm();
            
            LetterTemplateLetterExtractAlgorithmSpot algorithmComponent = extractAlgo.getAlgorithmComponent(LetterTemplateLetterExtractAlgorithmSpot.class);
            
            algorithmComponent.setCustomerContact(cc);
            algorithmComponent.setLetterTemplate(letterTemplate);
            
            // Start Change - Defect 4599345 - RDizon - 09-29-2021
            // algorithmComponent.setCustomerContactExtractedCount(wCcExtractedCount);
            algorithmComponent.setCustomerContactExtractedCount(BigInteger.valueOf(extractFileMap.get(fullPathName).longValue()));
            // End Change - Defect 4599345 - RDizon - 09-29-2021
            
            algorithmComponent.setExtractFileName(fullPathName);
            algorithmComponent.setIsFieldDelimited(parmFieldDelimiterSw);
            algorithmComponent.setIsFirstHeaderDelimited(parmControlRecordSwitch);
            algorithmComponent.setLetterExtractAlgorithm(extractAlgo);
            
            try {
                algorithmComponent.invoke();
                wCcExtractedCount = algorithmComponent.getCustomerContactExtractedCount();        
                
                // Start Delete - Defect 4599345 - RDizon - 09-29-2021
                // if (parmControlRecordSwitch.isTrue()) {
                //     // Start Change - CCB034.Issue4 - RDizon - 09-16-2021
                //     // Write to the previous file its control record.
                //       if (notNull(wPrevLetterTemplateID)
                //               && letterTemplateID.compareTo(wPrevLetterTemplateID) != 0) {
                //     if (notBlank(wPrevFile) 
                //             && !fullPathName.equalsIgnoreCase(wPrevFile)){       
                //     // End Change - CCB034.Issue4 - RDizon - 09-16-2021
                //         CmGeneralLetterControlRecord controlRecord = new CmGeneralLetterControlRecord();
                //         
                //         controlRecord.setMailingKey(BLANK);
                //         controlRecord.setSortKeyCcId(ccID.getTrimmedValue());
                //         controlRecord.setSortKeyLetterTemplateCode(letterTemplateID.getTrimmedValue());
                //         
                //         controlRecord.setBatchControl(this.getBatchControlId().getTrimmedValue());
                //         controlRecord.setBatchNbr(this.getBatchNumber().toString().trim());
                //         controlRecord.setBatchRerunNbr(this.getBatchRerunNumber().toString().trim());
                //         controlRecord.setExtractedCCCount(wPrevCount.toString().trim());
                //         controlRecord.setExtractDttm(this.getProcessDateTime().toString().trim());
                //         controlRecord.setCCIDStart(this.getLowIdForThread(CustomerContact_Id.FIELD_SIZE));
                //         controlRecord.setCCIDEnd(this.getHighIdForThread(CustomerContact_Id.FIELD_SIZE));                    
                //         controlRecord.setThreadNumber(this.getBatchThreadNumber().toString().trim());    
                //         controlRecord.setThreadCnt(this.getParameters().getThreadCount().toString().trim());
                //                                             
                //         try {
                //             BufferedWriter buffWriter = new BufferedWriter(new FileWriter(new File(fullPathName), true));
                //             buffWriter.write(controlRecord.createRecordString());
                //             buffWriter.close();
                //         }
                //         catch (IOException e) {
                //             addError(CustomMessageRepositoryMGE.commGenericErrorWritingToFile(wPrevFile));
                //             e.printStackTrace();
                //         }
                //     }
                // }            
                            
                // wPrevFile = fullPathName;
                // wPrevLetterTemplateID = letterTemplateID;
                // wPrevCount = wCcExtractedCount;
                // End Delete - Defect 4599345 - RDizon - 09-29-2021
                
                // Start Add - E-09710 - DLampa - 11-06-2024
                BigInteger currentCount = extractFileMap.get(fullPathName);
                // Start Delete - E-09710.Issue1 - DLampa - 12-13-2024
                // Move incrementing the count after confirming that the extracted count has increased from previous run
                //extractFileMap.put(fullPathName, currentCount.add(BigInteger.ONE));
                // End Delete - E-09710.Issue1 - DLampa - 12-13-2024
                // End Add - E-09710 - DLampa - 11-06-2024                  
                
                // Start Change - E-08254 - IReyes - 04-10-2024
                // Stamp the customer contact with the print date time only when the record is extracted
                // Note: The wCcExtractedCount starts with a value of 1 and adds 1 when a customer
                // contact record is extracted  
                // Start Change - E-09710.Issue1 - DLampa - 12-13-2024
                //if(wCcExtractedCount.compareTo(BigInteger.ONE) > 0){
                if(wCcExtractedCount.compareTo(BigInteger.ZERO) > 0
                		&& wCcExtractedCount.compareTo(currentCount) > 0){                    
                    extractFileMap.put(fullPathName, currentCount.add(BigInteger.ONE));                	
               	// End Change - E-09710.Issue1 - DLampa - 12-13-2024                	
                	stampCustomerContactWithPrintDttm(cc, this.getProcessDateTime());
                }
                // End Change - E-08254 - IReyes - 04-10-2024
            }
            catch(ApplicationError ae) {                
                addWarning(ae.getServerMessage());
                return false;
            }
            
            return true;
        }

        private String createPathName(String filePath, String letterTemplateStr){
            // Start Change - CCB034 - RDizon - 04-14-2021
            // generate filename
            // String fileName = getBatchControlId().getTrimmedValue() + String.format("%010d", getBatchNumber())
            //         + String.format("%010d", getBatchThreadNumber()) + letterTemplateStr + PERIOD + LETTER_EXT;

            
            String fileName = getBatchControlId().getTrimmedValue() + String.format("%010d", getBatchNumber())
                            + String.format("%010d", getBatchThreadNumber()) + letterTemplateStr;
            if (wSeparateCisDivisionSw.isTrue()){
                 fileName = fileName + AL_GC_CIS_DIVISION + PERIOD + LETTER_EXT;
            }
            else {
                 fileName = fileName + PERIOD + LETTER_EXT;
            }
            // End Change - CCB034 - RDizon - 04-14-2021

            // replace spaces with underscore
            fileName = fileName.replaceAll("\\s+", "_");
            
            // check if file exist
            String fullPath = filePath + fileName;
            File file = new File(fullPath);
            if(!file.exists() || file.isDirectory()) { 
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    addError(CustomMessageRepositoryMGE.commGenericErrorOpeningFile(fileName));
                }

                // close file
                FileOutputStream oFile;
                try {
                    oFile = new FileOutputStream(file, false);
                    oFile.close();
                } catch (FileNotFoundException e) {
                    addError(CustomMessageRepositoryMGE.commGenericErrorOpeningFile(fileName));
                } catch (IOException e) {
                    addError(CustomMessageRepositoryMGE.commGenericErrorClosingFile(fileName));
                } 
            }
            
            // Start Add - Defect 4599345 - RDizon - 09-29-2021
            BigInteger currentCount = extractFileMap.get(fullPath);
            if (isNull(currentCount)) {
            	// Start Change - E-09710 - DLampa - 11-06-2024
            	// Initialize the count at zero for a new file that's just been created 
                //extractFileMap.put(fullPath, BigInteger.ONE);
                extractFileMap.put(fullPath, BigInteger.ZERO);
                // Start Change - E-09710 - DLampa - 11-06-2024
            }
            // Start Delete - E-09710 - DLampa - 11-06-2024
            // Move incrementing the extracted count to after the customer contact has actually been extracted successfully            
            //else {
            //    extractFileMap.put(fullPath, currentCount.add(BigInteger.ONE));
            //}
            // End Delete - E-09710 - DLampa - 11-06-2024            
            // End Add - Defect 4599345 - RDizon - 09-29-2021
            
            return fullPath;
        }
        
        private void stampCustomerContactWithPrintDttm(CustomerContact cc, DateTime printDttm) {
            
            startChanges();
            CustomerContact_DTO ccDTO = cc.getDTO();
            ccDTO.setLetterPrintDateTime(printDttm);
            cc.setDTO(ccDTO);            
            saveChanges();
        }
        
        // Start Add - CCB034 - RDizon - 04-14-2021
        private Bool checkMainPersonCisDivision(Person person, String cisDivisions) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("FROM AccountPerson AP, ");
            stringBuilder.append("    Account ACCT ");
            stringBuilder.append("WHERE AP.id.person = :person ");
            stringBuilder.append(    "AND AP.isMainCustomer = :isMainCustomer ");
            stringBuilder.append(    "AND AP.id.account = ACCT.id ");
            stringBuilder.append(    "AND ACCT.divisionId IN (" + cisDivisions + ")");
            
            Query query = createQuery(stringBuilder.toString(), "=getMainPersonAccount=");
            query.bindEntity("person", person);
            query.bindBoolean("isMainCustomer", Bool.TRUE);
            query.addResult("account", "ACCT.id");
            
            if (notNull(query.firstRow())){
                return Bool.TRUE;
            }
            else {
                return Bool.FALSE;   
            }
        }
        // End Add - CCB034 - RDizon - 04-14-2021

        // Start Add - Defect 4599345 - RDizon - 09-29-2021
        private Bool checkMainPersonCisDivisionWithAccount(Person person, Account account, String cisDivisions) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("FROM AccountPerson AP, ");
            stringBuilder.append("    Account ACCT ");
            stringBuilder.append("WHERE AP.id.person = :person ");
            stringBuilder.append(    "AND AP.isMainCustomer = :isMainCustomer ");
            stringBuilder.append(    "AND AP.id.account = ACCT.id ");
            stringBuilder.append(    "AND ACCT.id = :account ");
            stringBuilder.append(    "AND ACCT.divisionId IN (" + cisDivisions + ")");

            Query query = createQuery(stringBuilder.toString(), "=getMainPersonAccount=");
            query.bindEntity("person", person);
            query.bindEntity("account", account);
            query.bindBoolean("isMainCustomer", Bool.TRUE);
            query.addResult("cisDivision", "ACCT.divisionId");
            
            if (notNull(query.firstRow())){
                return Bool.TRUE;
            }
            else {
                return Bool.FALSE;   
            }
        }
        // End Add - Defect 4599345 - RDizon - 09-29-2021
        
        @Override
        public void finalizeThreadWork() throws ThreadAbortedException,
                RunAbortedException {
            if (parmControlRecordSwitch.isTrue()) {
                // Start Change - Defect 4599345 - RDizon - 09-29-2021
                // // Start Change - CCB034.Issue4 - RDizon - 09-16-2021
                // // Write to the last file its control record.
                // // if (notNull(wPrevLetterTemplateID)) {
                // if (notBlank(wPrevFile)) {
                // // End Change - CCB034.Issue4 - RDizon - 09-16-2021
                //     CmGeneralLetterControlRecord controlRecord = new CmGeneralLetterControlRecord();
                //     
                //     controlRecord.setMailingKey(BLANK);
                //     controlRecord.setSortKeyCcId(BLANK);
                //     controlRecord.setSortKeyLetterTemplateCode(BLANK);
                //     
                //     controlRecord.setBatchControl(this.getBatchControlId().getTrimmedValue());
                //     controlRecord.setBatchNbr(this.getBatchNumber().toString().trim());
                //     controlRecord.setBatchRerunNbr(this.getBatchRerunNumber().toString().trim());
                //     controlRecord.setExtractedCCCount(wPrevCount.toString().trim());
                //     controlRecord.setExtractDttm(this.getProcessDateTime().toString().trim());
                //     controlRecord.setCCIDStart(this.getLowIdForThread(CustomerContact_Id.FIELD_SIZE));
                //     controlRecord.setCCIDEnd(this.getHighIdForThread(CustomerContact_Id.FIELD_SIZE));                    
                //     controlRecord.setThreadNumber(this.getBatchThreadNumber().toString().trim());    
                //     controlRecord.setThreadCnt(this.getParameters().getThreadCount().toString().trim());
                //                                         
                //     try {
                //         BufferedWriter buffWriter = new BufferedWriter(new FileWriter(new File(wPrevFile), true));
                //         buffWriter.write(controlRecord.createRecordString());
                //         buffWriter.close();
                //     }
                //     catch (IOException e) {
                //         addError(CustomMessageRepositoryMGE.commGenericErrorWritingToFile(wPrevFile));
                //         e.printStackTrace();
                //     }                    
                // }
                
                Iterator<String> iterator = extractFileMap.keySet().iterator();
                while(iterator.hasNext()) {
                    String currentFilename = iterator.next();
                    BigInteger count = extractFileMap.get(currentFilename);
                    
                    CmGeneralLetterControlRecord controlRecord = new CmGeneralLetterControlRecord();

                    controlRecord.setMailingKey(BLANK);
                    controlRecord.setSortKeyCcId(BLANK);
                    controlRecord.setSortKeyLetterTemplateCode(BLANK);

                    controlRecord.setBatchControl(this.getBatchControlId().getTrimmedValue());
                    controlRecord.setBatchNbr(this.getBatchNumber().toString().trim());
                    controlRecord.setBatchRerunNbr(this.getBatchRerunNumber().toString().trim());
                    // controlRecord.setExtractedCCCount(wPrevCount.toString().trim());
                    controlRecord.setExtractedCCCount(count.toString().trim());
                    controlRecord.setExtractDttm(this.getProcessDateTime().toString().trim());
                    controlRecord.setCCIDStart(this.getLowIdForThread(CustomerContact_Id.FIELD_SIZE));
                    controlRecord.setCCIDEnd(this.getHighIdForThread(CustomerContact_Id.FIELD_SIZE));                    
                    controlRecord.setThreadNumber(this.getBatchThreadNumber().toString().trim());    
                    controlRecord.setThreadCnt(this.getParameters().getThreadCount().toString().trim());

                    try {
                        BufferedWriter buffWriter = new BufferedWriter(new FileWriter(new File(currentFilename), true));
                        buffWriter.write(controlRecord.createRecordString());
                        buffWriter.close();
                    }
                    catch (IOException e) {
                        addError(CustomMessageRepositoryMGE.commGenericErrorWritingToFile(currentFilename));
                        e.printStackTrace();
                    } 
                    
                }
                // End Change - Defect 4599345 - RDizon - 09-29-2021
            }
        }
    }
}
