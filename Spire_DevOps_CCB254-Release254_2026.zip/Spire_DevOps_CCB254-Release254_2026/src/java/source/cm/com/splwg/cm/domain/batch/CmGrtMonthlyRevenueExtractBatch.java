/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPRTREB Algorithm.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *
 * 2016-02-29   EQuint      NI0006.2. Initial Version.
 * 2016-06-01   MPang       Defect 3444302. Added connection close.
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.
 * 2021-10-01   JHERNA      SysAid#382665. Ensure that only LGC and MGE is
 *                          processed (Missouri East and West).
 * 2022-01-04  Darryl H -B-20223:Process only CIS_DIVISION from parameter
 * 2024-05-03   DLampa      E-08803. Update the end date in the main query
 *                          to consider leap years when deriving the number
 *                          of days in February.
 * 2005-04-08   DLampa      E-10570. Update to also extract adjustments.
 * 2025-10-01   DLampa      E-10570.Issue2 - Updated to trim the adjustment
 *                          characteristic type and value criteria in the
 *                          main SQL to ensure that adjustments are derived.
 * 2025-11-14   EQuint      CCB25.4 Upgrade
 * 2026-03-05   DLampa      Defect 5155433. Updated to address the java heap
 *                          space issue.
 * *************************************************************************
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmprtren;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.StandardMessages;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCalculationLineCharacteristic;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ServerMessage;

/**
 * @author Administrator
 *
@BatchJob (multiThreaded = true, rerunnable = false, modules={},
 * softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = NETREV_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = GRTTAX_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PRCPINT_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = GRTREF_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = IAREVENUE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = IAGRT_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = USAGE_UOM_OR_SQI1, required = true, type = string)
 *            , @BatchJobSoftParameter (name = USAGE_UOM_OR_SQI2, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = AREA_NBR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = TOWN_CD_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = serviceType, name = UTIL_SVC_TYPE1, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = serviceType, name = UTIL_SVC_TYPE2, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = REVCL_STASK_TYPE_LGC, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = REVCL_STASK_TYPE_MGE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CIS_DIVISIONS, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = REV_BLD_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = REV_BLD_CHAR_VAL, required = true, type = string)})
 */
public class CmGrtMonthlyRevenueExtractBatch extends
CmGrtMonthlyRevenueExtractBatch_Gen {

    // CONSTANTS
    private static final String THREAD_NUMBER_DESC = "Thread Number";
    private static final String FILE_NAME_DATE_FORMAT_MMDDYY = "MMDDYY";
    private static final String DATE_FORMAT_MMDDYY = "MMddyy";
    private static final String DATE_FORMAT_YYYYMM = "yyyyMM";
    private static final String FILE_HEADER = "\"RECTYPE\",\"DATE\",\"AREANBR\",\"TOWNCODE\",\"REVENUECLASS\",\"PREMISE\",\"ACCOUNT\",\"NETREVENUE\",\"GRTTAX\",\"PRINPLUSINT\",\"GRTREF\",\"IAREVENUE\",\"IAGRT\",\"EXEMPTREV\",\"USAGE\",\"MTRCNT\",\"CISDIVISION\",\"UOM\"";

    private static final String CONNECTION_ONLINE = "O";
    private static final String CONNECTION_BATCH = "B";

    private static final String SWITCH_YES = "Y";
    private static final String SWITCH_NO = "N";
    // START ADD - Darryl H - 2022-01-04 - B20223
    private static final String COMMA = ", ";
    private static final String SINGLE_QUOTE = "'";
    private String wDivision;
    // END ADD - Darryl H - 2022-01-04 - B20223
    // Start Add - DLampa - 2025-04-08 - E-10570
    private CharacteristicType revBldCharType;
    private String revBldCharVal;
    // End Add - DLampa - 2025-04-08 - E-10570

    @Override
    public JobWork getJobWork() {

        // START ADD - Darryl H - 2022-01-04 - B20223
        String cisDivisions = createCisDivisionString(wDivision);
        // END ADD - Darryl H - 2022-01-04 - B20223
        // Start Change - DLampa - 2025-04-08 - E-10570
        //Query<QueryResultRow> query = createQuery(" FROM FinancialTransaction FT " +
        //      " WHERE FT.accountingDate >= :startDate " +
        //      " AND FT.accountingDate <= :endDate " +
        //      " AND FT.financialTransactionType IN (:f1, :f2) " +
        //      " AND FT.isFrozen = :frozen " +
        //      " AND FT.isRedundant = :redundant "
                // START ADD - JHERNA - 2021-10-01 - SysAid#382665
                //+ "AND FT.division IN (:lgc, :mge) "
                // START ADD - Darryl H - 2022-01-04 - B20223
        //        + "AND FT.division IN (" + cisDivisions + ") "
                // END ADD - Darryl H - 2022-01-04 - B20223
                // END ADD - JHERNA - 2021-10-01 - SysAid#382665
        //      , getClass().getName());

        StringBuilder getFTsString = new StringBuilder();
        getFTsString.append(" SELECT FT.FT_ID, FT.SA_ID ");
        getFTsString.append(" FROM CI_FT FT ");
        getFTsString.append(" WHERE FT.ACCOUNTING_DT >= :startDate ");
        getFTsString.append(  " AND FT.ACCOUNTING_DT <= :endDate  ");
        getFTsString.append(  " AND FT.FREEZE_SW = :frozen ");
        getFTsString.append(  " AND FT.REDUNDANT_SW = :redundant ");
        getFTsString.append(  " AND FT.CIS_DIVISION IN (" + cisDivisions + ") ");
        getFTsString.append(  " AND (FT.FT_TYPE_FLG IN (:f1, :f2) ");
        getFTsString.append(  " OR (FT.FT_TYPE_FLG IN (:f3, :f4) ");
        getFTsString.append(  " AND EXISTS (SELECT 'X' ");
        getFTsString.append(              " FROM CI_ADJ ADJ, ");
        getFTsString.append(                   " CI_ADJ_CALC_LN ACL, ");
        getFTsString.append(                   " CI_ADJ_CL_CHAR ACLC ");
        getFTsString.append(              " WHERE ADJ.ADJ_ID = FT.SIBLING_ID ");
        getFTsString.append(                " AND ACL.ADJ_ID = ADJ.ADJ_ID ");
        getFTsString.append(                " AND ACLC.ADJ_ID = ACL.ADJ_ID ");
        getFTsString.append(                " AND ACLC.SEQNO = ACL.SEQNO ");
        // Start Change - DLampa - 2025-10-01 - E-10570.Issue2
        //getFTsString.append(                " AND ACLC.CHAR_TYPE_CD = :revBldCharType ");
        //getFTsString.append(                " AND TRIM(ACLC.CHAR_VAL) = :revBldCharVal ))) ");
        getFTsString.append(                " AND TRIM(ACLC.CHAR_TYPE_CD) = TRIM(:revBldCharType) ");
        getFTsString.append(                " AND TRIM(ACLC.CHAR_VAL) = TRIM(:revBldCharVal) ))) ");
        // End Change - DLampa - 2025-10-01 - E-10570.Issue2
        getFTsString.append(" ORDER BY FT.SA_ID ");

        PreparedStatement query = createPreparedStatement(getFTsString.toString(), getClass().getName());
        // End Change - DLampa - 2025-04-08 - E-10570

        // Subtract a month from the process date.
        // Start Date = 1st Day of Batch Run Date's Previous Month
        // End Date = Last Day of Batch Run Date's Previous Month
        Date previousMonthDate = getProcessDateTime().getDate().addMonths(-1);
        Date previousMonthStartDate = new Date(previousMonthDate.getYear(),previousMonthDate.getMonth(),1);
        // Start Change - DLampa - 2024-05-03 - E-08803
        //Date previousMonthEndDate = new Date(previousMonthDate.getYear(),previousMonthDate.getMonth(),
        //      previousMonthDate.getMonthValue().getDaysInMonth());
        Date previousMonthEndDate = previousMonthDate.isLeapYear() ? new Date(previousMonthDate.getYear(),previousMonthDate.getMonth(),
                 previousMonthDate.getMonthValue().getLeapYearDaysInMonth()) : new Date(previousMonthDate.getYear(),previousMonthDate.getMonth(), previousMonthDate.getMonthValue().getDaysInMonth());
        // End Change - DLampa - 2024-05-03 - E-08803

        query.bindDate("startDate", previousMonthStartDate);
        query.bindDate("endDate", previousMonthEndDate);
        query.bindLookup("f1", FinancialTransactionTypeLookup.constants.BILL_SEGMENT);
        query.bindLookup("f2", FinancialTransactionTypeLookup.constants.BILL_CANCELLATION);
        // Start Add - DLampa - 2025-04-08 - E-10570
        query.bindLookup("f3", FinancialTransactionTypeLookup.constants.ADJUSTMENT);
        query.bindLookup("f4", FinancialTransactionTypeLookup.constants.ADJUSTMENT_CANCELLATION);
        query.bindId("revBldCharType", revBldCharType.getId());
        query.bindStringProperty("revBldCharVal", AdjustmentCalculationLineCharacteristic.properties.characteristicValue, revBldCharVal);
        // End Add - DLampa - 2025-04-08 - E-10570
        query.bindBoolean("frozen", Bool.TRUE);
        query.bindBoolean("redundant", Bool.FALSE);

        // START ADD - Darryl H - 2022-01-04 - B20223
        // START ADD - JHERNA - 2021-10-01 - SysAid#382665
        //CisDivision_Id lgcID = new CisDivision_Id("LGC");
        //CisDivision_Id mgeID = new CisDivision_Id("MGE");
        //query.bindId("lgc", lgcID);
        //query.bindId("mge", mgeID);
        // END ADD - JHERNA - 2021-10-01 - SysAid#382665
        // START ADD - Darryl H - 2022-01-04 - B20223

        // Start Delete - DLampa - 2025-04-08 - E-10570
        //query.addResult("ftId", "FT.id");
        //query.addResult("saId", "FT.serviceAgreement.id");
        //query.addResult("ftTypeFlag", "FT.financialTransactionType");
        //query.addResult("showOnBillSw", "FT.shouldShowOnBill");
        //query.addResult("correctionSw", "FT.isCorrection");
        //query.addResult("siblingId", "FT.siblingId");

        //query.orderBy("saId", Query.ASCENDING);
        // End Delete - DLampa - 2025-04-08 - E-10570

        // Start Change - DLampa - 2025-04-08 - E-10570
        //return createJobWorkForQueryIterator(query.iterate(), this);
        // Build Worklist
        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
        QueryIterator<SQLResultRow> iter = query.iterate();
        ThreadWorkUnit workUnit = null;
        SQLResultRow row = null;
        while (iter.hasNext()) {
            row = iter.next();

            workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId(row.getId("FT_ID", FinancialTransaction.class));
            workUnit.addSupplementalData("saId", row.getId("SA_ID", ServiceAgreement.class));
            workUnits.add(workUnit);
        }
        iter.close();
        query.close();

        return createJobWorkForThreadWorkUnitList(workUnits);
        // End Change - DLampa - 2025-04-08 - E-10570

    }
    // START ADD - Darryl H - 2022-01-04 - B20223
    /**
     * This method builds the CIS Division string for the main query.
     * @param cisDivisionStr
     * @return String
     */
    private String createCisDivisionString(String cisDivisionStr) {

        StringTokenizer strTokenizer = new StringTokenizer(cisDivisionStr, COMMA);
        StringBuilder strBuilder = new StringBuilder();

        while (strTokenizer.hasMoreElements()) {
            strBuilder.append(SINGLE_QUOTE);
            strBuilder.append(strTokenizer.nextToken().trim());
            strBuilder.append(SINGLE_QUOTE);

            if (strTokenizer.hasMoreTokens()) {
                strBuilder.append(COMMA);
            }
        }

        return strBuilder.toString();
    }
    // END ADD - Darryl H - 2022-01-04 - B20223

    // Start Delete - DLampa - 2025-04-08 - E-10570
    /*
     * This method will create the Thread Work Unit per result row
     */
    //public ThreadWorkUnit createWorkUnit(QueryResultRow resultRow) {

    //  FinancialTransaction_Id ftId = (FinancialTransaction_Id) resultRow.getId("ftId", FinancialTransaction.class);
    //  ServiceAgreement_Id saId = (ServiceAgreement_Id) resultRow.getId("saId", ServiceAgreement.class);
    //  FinancialTransactionTypeLookup ftTypeFlag = resultRow.getLookup("ftTypeFlag", FinancialTransactionTypeLookup.class);
    //  Bool showOnBillSw = resultRow.getBoolean("showOnBillSw");
    //  Bool correctionSw = resultRow.getBoolean("correctionSw");
    //  String siblingId = resultRow.getString("siblingId");

    //  ThreadWorkUnit unit = new ThreadWorkUnit();
    //  unit.setPrimaryId(ftId);
    //  unit.addSupplementalData("saId", saId);
    //  unit.addSupplementalData("ftTypeFlag", ftTypeFlag);
    //  unit.addSupplementalData("showOnBillSw",showOnBillSw);
    //  unit.addSupplementalData("correctionSw", correctionSw);
    //  unit.addSupplementalData("siblingId", siblingId);

    //  return unit;
    //}
    // End Delete - DLampa - 2025-04-08 - E-10570

    public Class<CmGrtMonthlyRevenueExtractBatchWorker> getThreadWorkerClass() {
        return CmGrtMonthlyRevenueExtractBatchWorker.class;
    }

    @Override
    public void validateSoftParameters(boolean isNewRun) {
        // START ADD - Darryl H - 2022-01-04 - B20223
          wDivision = getParameters().getCIS_DIVISIONS();
       // END ADD - Darryl H - 2022-01-04 - B20223
        // check if char type is valid for entity
        CharacteristicType charType = getParameters().getNETREV_CHAR_TYPE();
        CharacteristicEntity charEntity = new CharacteristicEntity_Id(charType,
                CharacteristicEntityLookup.constants.DISTRIBUTION_CODE).getEntity();
        if (isNull(charEntity)) {
            addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
                    charType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.DISTRIBUTION_CODE.getLookupValue().getEffectiveDescription()));
        }

        charType = getParameters().getGRTTAX_CHAR_TYPE();
        charEntity = new CharacteristicEntity_Id(charType,
                CharacteristicEntityLookup.constants.DISTRIBUTION_CODE).getEntity();
        if (isNull(charEntity)) {
            addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
                    charType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.DISTRIBUTION_CODE.getLookupValue().getEffectiveDescription()));
        }

        charType = getParameters().getPRCPINT_CHAR_TYPE();
        charEntity = new CharacteristicEntity_Id(charType,
                CharacteristicEntityLookup.constants.DISTRIBUTION_CODE).getEntity();
        if (isNull(charEntity)) {
            addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
                    charType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.DISTRIBUTION_CODE.getLookupValue().getEffectiveDescription()));
        }

        charType = getParameters().getGRTREF_CHAR_TYPE();
        charEntity = new CharacteristicEntity_Id(charType,
                CharacteristicEntityLookup.constants.DISTRIBUTION_CODE).getEntity();
        if (isNull(charEntity)) {
            addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
                    charType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.DISTRIBUTION_CODE.getLookupValue().getEffectiveDescription()));
        }

        charType = getParameters().getIAREVENUE_CHAR_TYPE();
        charEntity = new CharacteristicEntity_Id(charType,
                CharacteristicEntityLookup.constants.DISTRIBUTION_CODE).getEntity();
        if (isNull(charEntity)) {
            addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
                    charType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.DISTRIBUTION_CODE.getLookupValue().getEffectiveDescription()));
        }

        charType = getParameters().getIAGRT_CHAR_TYPE();
        charEntity = new CharacteristicEntity_Id(charType,
                CharacteristicEntityLookup.constants.DISTRIBUTION_CODE).getEntity();
        if (isNull(charEntity)) {
            addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
                    charType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.DISTRIBUTION_CODE.getLookupValue().getEffectiveDescription()));
        }

        // check if valid UOM or SQI
        String usageUomOrSqi1 = getParameters().getUSAGE_UOM_OR_SQI1();
        String usageUomOrSqi2 = getParameters().getUSAGE_UOM_OR_SQI2();

        if (isNull(new UnitOfMeasure_Id(usageUomOrSqi1).getEntity())) {
            if (isNull(new ServiceQuantityIdentifier_Id(usageUomOrSqi1).getEntity())) {
                addError(CustomMessageRepository.JACOB_valueInvalidUomSqi(usageUomOrSqi1));
            }
        }

        if (isNull(new UnitOfMeasure_Id(usageUomOrSqi2).getEntity())) {
            if (isNull(new ServiceQuantityIdentifier_Id(usageUomOrSqi2).getEntity())) {
                addError(CustomMessageRepository.JACOB_valueInvalidUomSqi(usageUomOrSqi2));
            }
        }

        // check if char type is valid for entity
        charType = getParameters().getAREA_NBR_CHAR_TYPE();
        charEntity = new CharacteristicEntity_Id(charType,
                CharacteristicEntityLookup.constants.PREMISE).getEntity();
        if (isNull(charEntity)) {
            addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
                    charType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.PREMISE.getLookupValue().getEffectiveDescription()));
        }

        charType = getParameters().getTOWN_CD_CHAR_TYPE();
        charEntity = new CharacteristicEntity_Id(charType,
                CharacteristicEntityLookup.constants.PREMISE).getEntity();
        if (isNull(charEntity)) {
            addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
                    charType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.PREMISE.getLookupValue().getEffectiveDescription()));
        }

        if (notNull(this.getParameters().getCIS_DIVISIONS())){
            String[] parmCisDivisions = this.getParameters().getCIS_DIVISIONS().split(",");

            for (int i=0; i < parmCisDivisions.length; i++){
                String cisDivStr = parmCisDivisions[i];
                CisDivision cisDivision = new CisDivision_Id(cisDivStr.trim()).getEntity();
                if (isNull(cisDivision)){
                    addError(CustomMessageRepository.CCB034_BatchParameterContainsInvalidCisDivision(
                            "Separate CIS Divisions",
                            cisDivStr));
                }
            }
        }

        // Start Add - DLampa - 2025-04-08 - E-10570
        charType = getParameters().getREV_BLD_CHAR_TYPE();
        charEntity = new CharacteristicEntity_Id(charType,
                CharacteristicEntityLookup.constants.ADJUSTMENT_CALC_LINE).getEntity();
        if (isNull(charEntity)) {
            addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
                    charType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.ADJUSTMENT_CALC_LINE.getLookupValue().getEffectiveDescription()));
        }
        revBldCharType = charType;

        String charVal = getParameters().getREV_BLD_CHAR_VAL();
        if (revBldCharType.getCharacteristicType().isPredefinedValue()) {
            CharacteristicValue_Id charValueId = new CharacteristicValue_Id(revBldCharType, charVal);

            if (isNull(charValueId.getEntity())) {
                addError(CustomMessageRepository.JACOB_charValueInvalidForCharType(charVal, charType.getId().getTrimmedValue()));
            }
        }
        revBldCharVal = charVal;
        // End Add - DLampa - 2025-04-08 - E-10570

    }

    public static class CmGrtMonthlyRevenueExtractBatchWorker extends
    CmGrtMonthlyRevenueExtractBatchWorker_Gen {

        // parameters
        private String filePath;
        private String fileName;
        private CharacteristicType netrevCharType;
        private CharacteristicType grttaxCharType;
        private CharacteristicType prcpintCharType;
        private CharacteristicType grtrefCharType;
        private CharacteristicType iarevenueCharType;
        private CharacteristicType iagrtCharType;
        private String usageUomOrSqi1;
        private String usageUomOrSqi2;
        private CharacteristicType areanbrCharType;
        private CharacteristicType towncdCharType;
        private ServiceType utilSvcType1;
        private ServiceType utilSvcType2;
        private ServiceTaskType lgcSvcTaskType;
        private ServiceTaskType mgeSvcTaskType;

        // work variables
        private BufferedWriter outputWriter;
        private Cmprtren cmprtren;
        private File extractFile;
        private FinancialTransaction_Id ftId;
        private ServiceAgreement_Id saId;
        private FinancialTransactionTypeLookup ftTypeFlag;
        private String siblingId;
        private String uomSw1;
        private String sqiSw1;
        private String uomSw2;
        private String sqiSw2;
        private Date previousMonthDate;
        private Date previousMonthStartDate;
        private Date previousMonthEndDate;
        private DateFormat dateFormatYYYYMM;

        //Start Add - MPang - Defect 3444302 - 2016-06-01
        private Connection connection;
        //End Add - MPang - Defect 3444302 - 2016-06-01

        // Start Add - DLampa - 2026-03-05 - Defect 5155433
        private FrameworkSession session;
        private RequestContext context;
        // End Add - DLampa - 2026-03-05 - Defect 5155433

        @Override
        public void initializeThreadWork(
                boolean initializationPreviouslySuccessful)
                        throws ThreadAbortedException, RunAbortedException {

            filePath = getParameters().getFILE_PATH();
            fileName = getParameters().getFILE_NAME();
            netrevCharType = getParameters().getNETREV_CHAR_TYPE();
            grttaxCharType = getParameters().getGRTTAX_CHAR_TYPE();
            prcpintCharType = getParameters().getPRCPINT_CHAR_TYPE();
            grtrefCharType = getParameters().getGRTREF_CHAR_TYPE();
            iarevenueCharType = getParameters().getIAREVENUE_CHAR_TYPE();
            iagrtCharType = getParameters().getIAGRT_CHAR_TYPE();
            usageUomOrSqi1 = getParameters().getUSAGE_UOM_OR_SQI1();
            usageUomOrSqi2 = getParameters().getUSAGE_UOM_OR_SQI2();

            uomSw1 = SWITCH_NO;
            sqiSw1 = SWITCH_NO;
            if (notNull(new UnitOfMeasure_Id(usageUomOrSqi1).getEntity())) {
                uomSw1 = SWITCH_YES;
            } else if (isNull(new ServiceQuantityIdentifier_Id(usageUomOrSqi1).getEntity())) {
                sqiSw1 = SWITCH_YES;
            }

            uomSw2 = SWITCH_NO;
            sqiSw2 = SWITCH_NO;
            if (notNull(new UnitOfMeasure_Id(usageUomOrSqi2).getEntity())) {
                uomSw2 = SWITCH_YES;
            } else if (isNull(new ServiceQuantityIdentifier_Id(usageUomOrSqi2).getEntity())) {
                sqiSw2 = SWITCH_YES;
            }

            areanbrCharType = getParameters().getAREA_NBR_CHAR_TYPE();
            towncdCharType = getParameters().getTOWN_CD_CHAR_TYPE();
            utilSvcType1 = getParameters().getUTIL_SVC_TYPE1();
            utilSvcType2 = getParameters().getUTIL_SVC_TYPE2();
            lgcSvcTaskType = getParameters().getREVCL_STASK_TYPE_LGC();
            mgeSvcTaskType = getParameters().getREVCL_STASK_TYPE_MGE();

            // Prepare Extract File Name
            // replace spaces with underscore
            fileName = fileName.replaceAll("\\s+", "_");

            // replace MMDDYY with process date
            DateFormat dateFormat = new DateFormat(DATE_FORMAT_MMDDYY);
            fileName = fileName.replace(FILE_NAME_DATE_FORMAT_MMDDYY, dateFormat.format(getProcessDateTime().getDate()));

            // if ?? is present in the file name, replace it with the thread number
            if (fileName.indexOf("??") >= 0) {
                fileName = fileName.replace("??", String.format("%02d", getBatchThreadNumber()));
            }
            else if (fileName.indexOf("?") >= 0) {
                if (getBatchThreadNumber().compareTo(BigInteger.valueOf(9)) > 0) {
                    addError(StandardMessages.fieldMissing(THREAD_NUMBER_DESC));
                }
                fileName = fileName.replace("?", String.format("%01d", getBatchThreadNumber()));
            }

            // Open Extract File
            extractFile = new File(filePath, fileName);

            try {
                outputWriter = new BufferedWriter(new FileWriter(extractFile));
            }
            catch(IOException ioe) {
                //If an error is encountered while opening the file, raise an error
                addError(CustomMessageRepository.JACOB_FileOpenError(ioe.getMessage()));
            }

            // Write Header Record
            if (getBatchThreadNumber().intValue() <= 1) {
                writeLine(FILE_HEADER);
            }

            // Get Start and End Previous Dates
            // Subtract a month from the process date.
            // Start Date = 1st Day of Batch Run Date's Previous Month
            // End Date = Last Day of Batch Run Date's Previous Month
            previousMonthDate = getProcessDateTime().getDate().addMonths(-1);
            previousMonthStartDate = new Date(previousMonthDate.getYear(),previousMonthDate.getMonth(),1);
            previousMonthEndDate = new Date(previousMonthDate.getYear(),previousMonthDate.getMonth(),
                    previousMonthDate.getMonthValue().getDaysInMonth());
            dateFormatYYYYMM = new DateFormat(DATE_FORMAT_YYYYMM);

            try {
                // initialize program
                initializeCobolProgram();
            }
            catch(Exception err) {
                addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), err.toString()));
            }

        }

        public ThreadExecutionStrategy createExecutionStrategy() {
            // Start Change - DLampa - 2025-04-08 - E-10570
            //return new StandardCommitStrategy(this);
            return new SingleTransactionStrategy(this);
            // End Change - DLampa - 2025-04-08 - E-10570
        }

        @Override
        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {

            ftId = (FinancialTransaction_Id) unit.getPrimaryId();
            saId = (ServiceAgreement_Id) unit.getSupplementallData("saId");
            // Start Change - DLampa - 2025-04-08 - E-10570
            //ftTypeFlag = (FinancialTransactionTypeLookup) unit.getSupplementallData("ftTypeFlag");
            //siblingId = (String) unit.getSupplementallData("siblingId");
            FinancialTransaction ft = ftId.getEntity();
            ftTypeFlag = ft.getFinancialTransactionType();
            siblingId = ft.getSiblingId();
            // End Change - DLampa - 2025-04-08 - E-10570

            // Start Change - DLampa - 2026-03-05 - Defect 5155433
            // start add - equint - 2025-11-14 - CCB25.4 Upgrade
            //try {
                // initialize program
            //    initializeCobolProgram();
            //}
            //catch(Exception err) {
            //    logError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), err.toString()));
            //    WorkUnitResult workUnitResult = new WorkUnitResult(true);
            //    workUnitResult.setUnitsProcessed(0);
            //    return workUnitResult;
            //}
            // end add - equint - 2025-11-14 - CCB25.4 Upgrade
            try {
                session = (FrameworkSession) SessionHolder.getSession();
                session.doWork(new ConnectionWork() {

                    @Override
                    public void execute(Connection connection) throws SQLException {
                        try {
                            // assign new connection as it closes per work unit
                            cmprtren.getSession().getDbSession().setUpdateConnection(connection);
                        }
                        catch(Exception e) {
                            throw new SQLException(e.getCause());
                        }

                    }
                });
            } catch(Exception err) {
                addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), err.toString()));
            }
            // End Change - DLampa - 2026-03-05 - Defect 5155433

            // reset program status and message numbers every unit
            cmprtren.setProgramStatus(" ");
            cmprtren.setMessageNbr(BigDecimal.ZERO);
            cmprtren.setZmsgnMessageCatNbr(BigDecimal.ZERO);

            // Pass the unit record and corresponding values for processing
            cmprtren.setInputWrkFtId(ftId.getTrimmedValue());
            cmprtren.setSiblingId(siblingId.trim());
            cmprtren.setInputWrkSaId(saId.getTrimmedValue());
            cmprtren.setFtTypeFlg(ftTypeFlag.trimmedValue());
            cmprtren.setUtilSvcType1(utilSvcType1.getId().getTrimmedValue());
            cmprtren.setUtilSvcType2(utilSvcType2.getId().getTrimmedValue());
            cmprtren.setRevclStaskTypeLgc(lgcSvcTaskType.getId().getTrimmedValue());
            cmprtren.setRevclStaskTypeMge(mgeSvcTaskType.getId().getTrimmedValue());
            cmprtren.setAreaNbrCharType(areanbrCharType.getId().getTrimmedValue());
            cmprtren.setTownCdCharType(towncdCharType.getId().getTrimmedValue());
            cmprtren.setUsageUomOrSqi1(usageUomOrSqi1);
            cmprtren.setUsageUomOrSqi2(usageUomOrSqi2);
            cmprtren.setNetrevCharType(netrevCharType.getId().getTrimmedValue());
            cmprtren.setGrttaxCharType(grttaxCharType.getId().getTrimmedValue());
            cmprtren.setPrcpintCharType(prcpintCharType.getId().getTrimmedValue());
            cmprtren.setGrtrefCharType(grtrefCharType.getId().getTrimmedValue());
            cmprtren.setIarevenueCharType(iarevenueCharType.getId().getTrimmedValue());
            cmprtren.setIagrtCharType(iagrtCharType.getId().getTrimmedValue());
            cmprtren.setInputWrkRunDate(dateFormatYYYYMM.format(previousMonthDate));
            cmprtren.setStartDt(previousMonthStartDate.toString());
            cmprtren.setEndDt(previousMonthEndDate.toString());
            cmprtren.setAreanbrCharTypeFlg(areanbrCharType.getCharacteristicType().trimmedValue());
            cmprtren.setTwncdCharTypeFlg(towncdCharType.getCharacteristicType().trimmedValue());
            cmprtren.setUsageUomSw(uomSw1);
            cmprtren.setUsageUomSw2(uomSw2);
            cmprtren.setUsageSqiSw(sqiSw1);
            cmprtren.setUsageSqiSw2(sqiSw2);

            callCobol();

            WorkUnitResult workUnitResult = new WorkUnitResult(true);
            if (cmprtren.getRecCnt().intValue() > 0) {
                workUnitResult.setUnitsProcessed(1);
            } else {
                workUnitResult.setUnitsProcessed(0);
            }

            return workUnitResult;
        }

        @Override
        public void finalizeThreadWork() throws ThreadAbortedException,
        RunAbortedException {
            try {
                outputWriter.close();
                // start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//                //Start Add - MPang - Defect 3444302 - 2016-06-01
//                connection.close();
//                //End Add - MPang - Defect 3444302 - 2016-06-01
                // end delete - equint - 2025-11-14 - CCB25.4 Upgrade
            }
            catch(IOException ioe) {
                //If an error is encountered while opening the file, raise an error
                addError(CustomMessageRepository.JACOB_FileCloseError(ioe.getMessage()));
            }
            // start delete - equint - 2025-11-14 - CCB25.4 Upgrade
            //Start Add - MPang - Defect 3444302 - 2016-06-01
//            catch(SQLException se) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getIdValue(), se.getMessage()));
//            }
            //End Add - MPang - Defect 3444302 - 2016-06-01
            // end delete - equint - 2025-11-14 - CCB25.4 Upgrade
        }

        /*
         * Initialize cobol program
         */
        @SuppressWarnings("deprecation")
        private void initializeCobolProgram() throws Exception {

            // Start Change - DLampa - 2026-03-05 - Defect 5155433
            //FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
            //RequestContext context = session.getRequestContext();
            session = (FrameworkSession) SessionHolder.getSession();
            context = session.getRequestContext();
            // End Change - DLampa - 2026-03-05 - Defect 5155433

            // start update - equint - 2025-11-14 - CCB25.4 Upgrade
            session.doWork(new ConnectionWork() {

                @Override
                public void execute(Connection connection) throws SQLException {
                    try {
                        String username = connection.getMetaData().getUserName();
                        String url = connection.getMetaData().getURL();

                        CobolSession.setLogSessionStartEnd(false);
                        cmprtren=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmprtren.class);

                        cmprtren.getSession().getDbSession().setUpdateConnection(connection);
                        cmprtren.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");

                        // Initialize linkage copybook
                        cmprtren.aa100Initialize();

                        // set ZSTAT parameters

                        cmprtren.setProcessDt(getProcessDateTime().getDate().toString());
                        cmprtren.setProcessDttmSep("-");
                        cmprtren.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");

                        if (session.isOnlineConnection()) {
                            cmprtren.setConnectionFlg(CONNECTION_ONLINE);
                        }
                        else {
                            cmprtren.setConnectionFlg(CONNECTION_BATCH);
                        }

                        cmprtren.setUserId(context.getUserId());
                        cmprtren.setLanguageCd(context.getLanguageCode());

                        if (context.ignoreWarnings()) {
                            cmprtren.setIgnoreWarningSw(SWITCH_YES);
                        }
                        else {
                            cmprtren.setIgnoreWarningSw(SWITCH_NO);
                        }

                        if (session.getBatchInstanceId() != null) {
                            cmprtren.setZstatSchedulerId(new BigDecimal(session.getBatchInstanceId()));
                            cmprtren.setSchedulerId(new BigDecimal(session.getBatchInstanceId()));

                        } else {
                            cmprtren.setZstatSchedulerId(new BigDecimal(0));
                            cmprtren.setSchedulerId(new BigDecimal(0));
                        }

                        cmprtren.setAppSvcId(context.getSecurityServiceIdContext());

                        DatabaseHelper dbHelper = session.getDatabaseHelper();
                        cmprtren.setDbMode(dbHelper.getCobolDBMode());
                        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
                        //cmprtren.setSplHighValue(cmprtren.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
                        //cmprtren.setSplLowValue(cmprtren.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));

                        cmprtren.setSplHighValue(cmprtren.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
                        cmprtren.setSplLowValue(cmprtren.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
                        // CCB v2.6 Upgrade - 2018-05-31 - End Change

                        cmprtren.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()));

                        cmprtren.setLkExpiryDt(Date.MAX.toString());

                        cmprtren.setProgramStatus(" ");

                        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
                        cmprtren.setCallSeq(";");
                        cmprtren.setMessageAreaProgramName("CMPRTREN");
                        // CCB v2.6 Upgrade - 2018-08-02 - End Add

                        if (context.getRandomGeneratorSeedSet().isTrue()) {
                            cmprtren.setRandomGenSeedSw(SWITCH_YES);
                            cmprtren.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()));
                            cmprtren.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()));
                            cmprtren.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()));
                            cmprtren.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()));
                        }
                        else {
                            cmprtren.setRandomGenSeedSw(SWITCH_NO);
                        }

                        if (context.traceStandardOut()) {
                            cmprtren.setTrcStdoutSw(SWITCH_YES);
                        }
                        else {
                            cmprtren.setTrcStdoutSw(SWITCH_NO);
                        }

                        if (context.traceProgramStart()) {
                            cmprtren.setTrcProgStartSw(SWITCH_YES);
                        }
                        else {
                            cmprtren.setTrcProgStartSw(SWITCH_NO);
                        }

                        if (context.traceProgramExit()) {
                            cmprtren.setTrcProgExitSw(SWITCH_YES);
                        }
                        else {
                            cmprtren.setTrcProgExitSw(SWITCH_NO);
                        }

                        if (context.traceSQL()) {
                            cmprtren.setTrcExecSqlSw(SWITCH_YES);
                        }
                        else {
                            cmprtren.setTrcExecSqlSw(SWITCH_NO);
                        }
                    }
                    catch(Exception e) {
                        throw new SQLException(e.getCause());
                    }

                }
            });

//          SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//          //Start Change - MPang - Defect 3444302 - 2016-06-01
//            //Connection connection = implementor.getConnectionProvider().getConnection();
//            connection = implementor.getConnectionProvider().getConnection();
//            //End Change - MPang - Defect 3444302 - 2016-06-01
//
//          String username = connection.getMetaData().getUserName();
//          String url = connection.getMetaData().getURL();
//
//          CobolSession.setLogSessionStartEnd(false);
//          cmprtren=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmprtren.class);
//
//          cmprtren.getSession().getDbSession().setUpdateConnection(connection);
//          cmprtren.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//
//          // Initialize linkage copybook
//          cmprtren.aa100Initialize();
//
//          // set ZSTAT parameters
//
//          cmprtren.setProcessDt(getProcessDateTime().getDate().toString());
//          cmprtren.setProcessDttmSep("-");
//          cmprtren.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//
//          if (session.isOnlineConnection()) {
//              cmprtren.setConnectionFlg(CONNECTION_ONLINE);
//          }
//          else {
//              cmprtren.setConnectionFlg(CONNECTION_BATCH);
//          }
//
//          cmprtren.setUserId(context.getUserId());
//          cmprtren.setLanguageCd(context.getLanguageCode());
//
//          if (context.ignoreWarnings()) {
//              cmprtren.setIgnoreWarningSw(SWITCH_YES);
//          }
//          else {
//              cmprtren.setIgnoreWarningSw(SWITCH_NO);
//          }
//
//          if (session.getBatchInstanceId() != null) {
//              cmprtren.setZstatSchedulerId(new BigDecimal(session.getBatchInstanceId()));
//              cmprtren.setSchedulerId(new BigDecimal(session.getBatchInstanceId()));
//
//          } else {
//              cmprtren.setZstatSchedulerId(new BigDecimal(0));
//              cmprtren.setSchedulerId(new BigDecimal(0));
//          }
//
//          cmprtren.setAppSvcId(context.getSecurityServiceIdContext());
//
//          DatabaseHelper dbHelper = session.getDatabaseHelper();
//          cmprtren.setDbMode(dbHelper.getCobolDBMode());
//          // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//          //cmprtren.setSplHighValue(cmprtren.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//          //cmprtren.setSplLowValue(cmprtren.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//
//          cmprtren.setSplHighValue(cmprtren.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//            cmprtren.setSplLowValue(cmprtren.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//          // CCB v2.6 Upgrade - 2018-05-31 - End Change
//
//          cmprtren.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()));
//
//          cmprtren.setLkExpiryDt(Date.MAX.toString());
//
//          cmprtren.setProgramStatus(" ");
//
//          // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//          cmprtren.setCallSeq(";");
//          cmprtren.setMessageAreaProgramName("CMPRTREN");
//          // CCB v2.6 Upgrade - 2018-08-02 - End Add
//
//          if (context.getRandomGeneratorSeedSet().isTrue()) {
//              cmprtren.setRandomGenSeedSw(SWITCH_YES);
//              cmprtren.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()));
//              cmprtren.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()));
//              cmprtren.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()));
//              cmprtren.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()));
//          }
//          else {
//              cmprtren.setRandomGenSeedSw(SWITCH_NO);
//          }
//
//          if (context.traceStandardOut()) {
//              cmprtren.setTrcStdoutSw(SWITCH_YES);
//          }
//          else {
//              cmprtren.setTrcStdoutSw(SWITCH_NO);
//          }
//
//          if (context.traceProgramStart()) {
//              cmprtren.setTrcProgStartSw(SWITCH_YES);
//          }
//          else {
//              cmprtren.setTrcProgStartSw(SWITCH_NO);
//          }
//
//          if (context.traceProgramExit()) {
//              cmprtren.setTrcProgExitSw(SWITCH_YES);
//          }
//          else {
//              cmprtren.setTrcProgExitSw(SWITCH_NO);
//          }
//
//          if (context.traceSQL()) {
//              cmprtren.setTrcExecSqlSw(SWITCH_YES);
//          }
//          else {
//              cmprtren.setTrcExecSqlSw(SWITCH_NO);
//          }

        // end update - equint - 2025-11-14 - CCB25.4 Upgrade

        }

        /**
         * Write Line to File
         */
        private void writeLine(String recordline){
            try {
                outputWriter.write(recordline);
                outputWriter.newLine();
            } catch (IOException e) {
                addError(CustomMessageRepository.JACOB_FileWriteError(e.getMessage()));
            }
        }

        private void callCobol() {
            try {
                cmprtren.cobolMain();
            }catch(Exception _ex) {
                Throwable ex=_ex;
                while(ex.getCause()!=null) ex=ex.getCause();
                if(ex instanceof Stop) {

                    // if message number and category are not 0, meaning a server message is passed from the jacob code
                    if (cmprtren.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0
                            && cmprtren.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {

                        // pass the parameter to the server message
                        MessageParameters messageparameters = new MessageParameters();
                        for (int i = 1; i <= 9; i++) {
                            try {
                                String parmValue = cmprtren.getMessageParm(i);
                                if (notBlank(parmValue)) {
                                    messageparameters.addRawString(parmValue.trim());
                                }
                            }
                            catch(IndexOutOfBounds e) {
                                break;
                            }

                        }
                        MessageCategory_Id categoryId = new MessageCategory_Id(cmprtren.getZmsgnMessageCatNbr().toBigInteger());
                        ServerMessage serverMessage =
                                ServerMessageFactory.Factory.newInstance().createMessage(
                                        categoryId, cmprtren.getMessageNbr().intValue(), messageparameters);


                        // check the message severity so we'll know what type of message to raise

                        // info
                        if (cmprtren.getMessageSeverity().compareTo(
                                MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
                            logInfo(serverMessage);
                        }
                        // warning
                        else if (cmprtren.getMessageSeverity().compareTo(
                                MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
                            logWarning(serverMessage);
                        }
                        // error
                        else {
                            logError(serverMessage);
                        }
                    }

                    if (cmprtren.getRecCnt().intValue() > 0) {
                        // Write Extract Line to file
                        writeLine(cmprtren.getFileRec());
                    }

                }
                else  {
                    //Start Add - MPang - Defect 3444302 - 2016-06-01
                    ex.printStackTrace();
                    //End Add - MPang - Defect 3444302 - 2016-06-01
                    addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), _ex.toString()));
                }
            }
        }

    }

}
