/*
 **************************************************************************
 *                Confidentiality Information:
 *
 * This module is the confidential and proprietary information of
 * Oracle Corporation; it is not to be copied, reproduced, or
 * transmitted in any form, by any means, in whole or in part,
 * nor is it to be used for any purpose other than that for which
 * it is expressly provided without the written permission of
 * Oracle Corporation.
 *
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Extract Letters Batch
 *
 * This batch process will create an output file with Bad Debt financial
 * information. The process will gather information for those accounts
 * that have write off SA's during extract period. This process will also
 * gather payment information for accounts that have had payments applied
 * to active write off SA's.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2012-11-15   BCordo  NI006.3. Initial Version.
 * 2013-05-13   CVB     Create header even if no records were extraced.
 * 2013-06-27   CVB     Modified code to improve performance and prevent
 *                      heap space memory error.
 * 2013-10-23   CVB     Modified logic for Processing Window Start
 *                      and End Dates.
 * 2014-09-24	DHuynh	MGE-CCB007
 * 						-Add logic to include CIS Division output column
 * 						 to differentiate between MGE and LGC.
 * 2015-04-20 	DHuynh 	Defect#3163951: Single extract file that will 
 *                      include both MGE and LGC bad debt information
 * 2015-11-23   SMiran	SF-66226. Get Revenue Class from Service Task Type.
 * 						Removed the following parameter:
 * 						- REV_CLASS_LOOKUP
 * 						Added the following parameters:
 * 						- REVCL_STASK_TYPE_LGC
 * 						- REVCL_STASK_TYPE_MGE
 * 2016-02-18   MPang	Updated for CCB v2.4 compilation.
 * 2021-10-01   JHERNA  SysAid#382665. Ensure that only LGC and MGE is
 *                      processed (Missouri East and West). 
 * 2022-01-04  Darryl H -B-20223:Process only CIS_DIVISION from parameter
 **************************************************************************
 */
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import java.util.StringTokenizer;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;

// 2015-11-23. SMiran. SF-66226. Start Delete
//import com.splwg.base.domain.common.lookup.LookupField;
//import com.splwg.base.domain.common.lookup.LookupValue;
// 2015-11-23. SMiran. SF-66226. End Delete

import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.SpecialRoleLookup;
//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.adjustment.adjustment.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.Adjustment_Id;
import com.splwg.ccb.domain.admin.adjustmentType.AdjustmentType;
import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.revenueClass.RevenueClass_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType_Id;
// 2015-11-23. SMiran. SF-66226. Start Add
import com.splwg.ccb.domain.admin.serviceTaskType.ServiceTaskType;
// 2015-11-23. SMiran. SF-66226. End Add
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.premise.Premise;
import com.splwg.ccb.domain.customerinfo.premise.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;*/

import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.revenueClass.entity.RevenueClass_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.api.batch.CmBadDebtExtractHeaderRecord;
import com.splwg.cm.api.batch.CmBadDebtExtractRecord;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author 95223
 *
 @BatchJob (multiThreaded = false, rerunnable = false, modules={},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (lookupName = specialRole, name = SA_SPECIAL_ROLE_FLAG, required = true, type = lookup)
 *            , @BatchJobSoftParameter (name = NETREV_SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = NETREV_CIS_DIVISION,  type = entity)
 *            , @BatchJobSoftParameter (name = STATETAX_SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = STATETAX_CIS_DIVISION,  type = entity)
 *            , @BatchJobSoftParameter (name = CITYTAX_SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = CITYTAX_CIS_DIVISION,  type = entity)
 *            , @BatchJobSoftParameter (name = GRTTAX_SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = GRTTAX_CIS_DIVISION,  type = entity)
 *            , @BatchJobSoftParameter (name = MERCHANDISE_SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = MERCHANDISE_CIS_DIVISION,  type = entity)
 *            , @BatchJobSoftParameter (name = REMOTE_SA_TYPE,  type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = REMOTE_CIS_DIVISION,  type = entity)
 *            , @BatchJobSoftParameter (name = JOBBING_SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = JOBBING_CIS_DIVISION,  type = entity)
 *            , @BatchJobSoftParameter (name = INSULATION_SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = INSULATION_CIS_DIVISION,  type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = TOWN_CODE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = adjustmentType, name = ADJ_TYPE_FOR_XFER, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = REVCL_STASK_TYPE_LGC, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = REVCL_STASK_TYPE_MGE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = INITIAL_START_DATE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CIS_DIVISIONS, required = true, type = string)
 *            })
 */
public class CmGRTBadDebtExtractBatch extends CmGRTBadDebtExtractBatch_Gen {
    // Local Constants
    private static final String FILE_PATH = "File Path";
    private static final String FILE_NAME = "File Name";
    private static final String TOWN_CODE = "Town Code";
    private static final String INITIAL_START_DATE = "Initial Start Date";
    private static final String MMDDYY = "MMDDYY";
    private static final DateFormat mmDdYyyyFormat = new DateFormat("MM-dd-yyyy");
    private static final String NETREV = "Net Revenue";
    private static final String STATETAX = "State Tax";
    private static final String CITYTAX = "City Tax";
    private static final String GRTTAX = "Grt Tax";
    private static final String MERCHANDISE = "Merchandise";
    private static final String REMOTE = "Remote";
    private static final String JOBBING = "Jobbing";
    private static final String INSULATION = "Insulation";
    private static final String CHARGEOFF_RECTYPE = "C";
    private static final String PAYMENT_RECTYPE = "P";
    private static final String CISDIVISION = "CisDivision";
    
    // Local variables
    private SpecialRoleLookup parmServiceAgreementSpecialRoleFlag;
    private String parmNetRevSaTypeCode;
    private String parmStateTaxSaTypeCode;
    private String parmCityTaxSaTypeCode;
    private String parmGrtTaxSaTypeCode;
    private String parmMerchandiseSaTypeCode;
    private String parmRemoteSaTypeCode;
    private String parmJobbingSaTypeCode;
    private String parmInsulationSaTypeCode;
    private CisDivision parmNetRevCisDivision;
    private CisDivision parmStateTaxCisDivision;
    private CisDivision parmCityTaxCisDivision;
    private CisDivision parmGrtTaxCisDivision;
    private CisDivision parmMerchandiseCisDivision;
    private CisDivision parmRemoteCisDivision;
    private CisDivision parmJobbingCisDivision;
    private CisDivision parmInsulationCisDivision;
    private Date parmInitialStartDate;
	// START ADD - Darryl H - 2022-01-04 - B20223
	private String parmDivision;
    private static final String COMMA = ", ";
    private static final String SINGLE_QUOTE = "'";
	// END ADD - Darryl H - 2022-01-04 - B20223
    public void validateSoftParameters(boolean arg0) {

        parmServiceAgreementSpecialRoleFlag = getParameters().getSA_SPECIAL_ROLE_FLAG();
        parmNetRevSaTypeCode = getParameters().getNETREV_SA_TYPE();
        parmStateTaxSaTypeCode = getParameters().getSTATETAX_SA_TYPE();
        parmCityTaxSaTypeCode = getParameters().getCITYTAX_SA_TYPE();
        parmGrtTaxSaTypeCode = getParameters().getGRTTAX_SA_TYPE();
        parmMerchandiseSaTypeCode = getParameters().getMERCHANDISE_SA_TYPE();
        parmRemoteSaTypeCode = getParameters().getREMOTE_SA_TYPE();
        parmJobbingSaTypeCode = getParameters().getJOBBING_SA_TYPE();
        parmInsulationSaTypeCode = getParameters().getINSULATION_SA_TYPE();
        parmNetRevCisDivision = getParameters().getNETREV_CIS_DIVISION();
        parmStateTaxCisDivision = getParameters().getSTATETAX_CIS_DIVISION();
        parmCityTaxCisDivision = getParameters().getCITYTAX_CIS_DIVISION();
        parmGrtTaxCisDivision = getParameters().getGRTTAX_CIS_DIVISION();
        parmMerchandiseCisDivision = getParameters().getMERCHANDISE_CIS_DIVISION();
        parmRemoteCisDivision = getParameters().getREMOTE_CIS_DIVISION();
        parmJobbingCisDivision = getParameters().getJOBBING_CIS_DIVISION();
        parmInsulationCisDivision = getParameters().getINSULATION_CIS_DIVISION();
        // START ADD - Darryl H - 2022-01-04 - B20223
        parmDivision = getParameters().getCIS_DIVISIONS();  

        // END ADD - Darryl H - 2022-01-04 - B20223
        // Validate Parameter File Path
        File tempPathFolder = new File(getParameters().getFILE_PATH());

        if (!tempPathFolder.isDirectory()){
            addError(CustomMessageRepositoryMDC.commBatchParmFilePathInvalid(this.getBatchControlId().getIdValue()
                    .trim(), FILE_PATH, getParameters().getFILE_PATH()));
        }

        // Validate that Town Code characteristic Type is valid for Premise Entity
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(getParameters()
		        .getTOWN_CODE_CHAR_TYPE(), CharacteristicEntityLookup.constants.PREMISE);
        if (isNull(charEntityId.getEntity())) {
            addError(CustomMessageRepositoryMDC.commBatchParmCharTypeInvalid(this.getBatchControlId().getIdValue()
                    .trim(), TOWN_CODE, getParameters().getTOWN_CODE_CHAR_TYPE().getId().getIdValue().trim(), CharacteristicEntityLookup
                    .constants.PREMISE.getLookupValue().fetchLanguageDescription()));
        }

        // Validate that file name batch parameter contains explicit string 'MMDDYY'
        if (!getParameters().getFILE_NAME().contains(MMDDYY)){
            addError(CustomMessageRepositoryMDC.commBatchParmFileNameInvalid(this.getBatchControlId().getIdValue()
                    .trim(), FILE_NAME, getParameters().getFILE_NAME()));
        }

        // Validate that initial start date batch parameter is in MM-DD-YYYY format
        try {
            parmInitialStartDate = Date.fromString(getParameters().getINITIAL_START_DATE(), mmDdYyyyFormat);
        }
        catch (Exception e) {
            addError(CustomMessageRepositoryMDC.commBatchParmDateFormatInvalid(this.getBatchControlId().getIdValue()
                    .trim(), INITIAL_START_DATE, getParameters().getINITIAL_START_DATE().trim()));
        }

        // Start Change - DHuynh - 2015-04-20 - Defect#3163951
        
        // Validate that parameters 40 to 110 are valid SA Types
        validateServiceAgreementType(parmNetRevSaTypeCode,  NETREV);
        validateServiceAgreementType(parmStateTaxSaTypeCode,  STATETAX);
        validateServiceAgreementType(parmCityTaxSaTypeCode,  CITYTAX);
        validateServiceAgreementType(parmGrtTaxSaTypeCode,  GRTTAX);
        validateServiceAgreementType(parmMerchandiseSaTypeCode,  MERCHANDISE);
        if (!isBlankOrNull(parmRemoteSaTypeCode)){
        	validateServiceAgreementType(parmRemoteSaTypeCode,  REMOTE);
        }       
        validateServiceAgreementType(parmJobbingSaTypeCode,  JOBBING);
        validateServiceAgreementType(parmInsulationSaTypeCode,  INSULATION);
        // End Change - DHuynh - 2015-04-20 - Defect#3163951
        // START ADD - Darryl H - 2022-01-04 - B20223
        if (notNull(this.getParameters().getCIS_DIVISIONS())){
            String[] parmCisDivisions = this.getParameters().getCIS_DIVISIONS().split(",");

            for (int i=0; i < parmCisDivisions.length; i++){
                String cisDivStr = parmCisDivisions[i];
                CisDivision cisDivision = new CisDivision_Id(cisDivStr.trim()).getEntity();
                if (isNull(cisDivision)){
                    addError(CustomMessageRepository.CCB034_BatchParameterContainsInvalidCisDivision(
                            "Separate CIS Divisions",
                            cisDivStr));
                }
            }
        }
        // END ADD - Darryl H - 2022-01-04 - B20223
    }
    
    	// Start Change - DHuynh - 2015-04-20 - Defect#3163951
    /*
     * Validate SA Type
     *  @param - saType: SA type from parameter
     *  @param - parmDesc: SA type desciption 
     */
    private void validateServiceAgreementType(String saType, String parmDesc){
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT SATYPE.SA_TYPE_CD ");
		stringBuilder.append("FROM CI_SA_TYPE SATYPE ");
		stringBuilder.append("WHERE SATYPE.SA_TYPE_CD = '" + saType + "' ");
		
		//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
		prepState.execute();
		if (prepState.list().size() <= 0) {
            addError(CustomMessageRepositoryMDC.commBatchParmInvalidSaType(this.getBatchControlId().getIdValue()
                    .trim(), parmDesc ,CISDIVISION, saType));
		}
		prepState.close();    	
    }
    	//  End Change - DHuynh - 2015-04-20 - Defect#3163951
    public JobWork getJobWork() {
    	// START ADD - Darryl H - 2022-01-04 - B20223
    	String cisDivisions = createCisDivisionString(parmDivision);
    	// END ADD - Darryl H - 2022-01-04 - B20223
        Date sDate;
        Date eDate;
        // CVB - 2013-10-23 - Start
        Date runDate = this.getProcessDateTime().getDate();
        Date prevMonthDate = runDate.addMonths(-1);

        int prevMonthYYYY = prevMonthDate.getYear();
        int prevMonthMM = prevMonthDate.getMonth();
        int prevMonthLastDay;

        if (prevMonthDate.isLeapYear()){
        	prevMonthLastDay = prevMonthDate.getMonthValue().getLeapYearDaysInMonth();
        }
        else {
        	prevMonthLastDay = prevMonthDate.getMonthValue().getDaysInMonth();
        }

        // Populate Start date field
        // sDate = retrieveLastBatchRunDate();

        // if (isNull(sDate)) {
        //     sDate = parmInitialStartDate;
        // }

        // Store current batch run date to end date
        // eDate = this.getProcessDateTime().getDate();
        sDate = new Date(prevMonthYYYY, prevMonthMM,1);
        eDate = new Date(prevMonthYYYY,prevMonthMM,prevMonthLastDay);

        // CVB - 2013-10-23 - End

        StringBuilder getSAsString = new StringBuilder();
        getSAsString.append(" (SELECT SA.SA_ID, 'C' AS RECTYPE                      ");
        getSAsString.append("    FROM CI_SA SA                                      ");
        getSAsString.append("        ,CI_SA_TYPE SATYPE                             ");
        getSAsString.append("   WHERE SA.CIS_DIVISION = SATYPE.CIS_DIVISION         ");
        // START ADD - JHERNA - 2021-10-01 - SysAid#382665
        // START ADD - Darryl H - 2022-01-04 - B20223
        //   getSAsString.append("     AND SA.CIS_DIVISION IN ('LGC', 'MGE')             ");
        getSAsString.append("     AND SA.CIS_DIVISION IN (" + cisDivisions + ") ");  
        // START ADD - Darryl H - 2022-01-04 - B20223
        // END ADD - JHERNA - 2021-10-01 - SysAid#382665
        getSAsString.append("     AND SA.SA_TYPE_CD = SATYPE.SA_TYPE_CD             ");
        getSAsString.append("     AND SA.SA_STATUS_FLG = :saStatusFlag              ");
        getSAsString.append("     AND SATYPE.SPECIAL_ROLE_FLG = :specialRoleFlag    ");
        getSAsString.append("     AND SA.START_DT >= :startDate                     ");
        getSAsString.append("     AND (SA.END_DT IS NULL                            ");
        getSAsString.append("       OR SA.END_DT <= :endDate))                      ");
        getSAsString.append(" UNION                                                 ");
        getSAsString.append(" (SELECT SA.SA_ID, 'P' AS RECTYPE                      ");
        getSAsString.append("    FROM CI_SA SA                                      ");
        getSAsString.append("        ,CI_SA_TYPE SATYPE                             ");
        getSAsString.append("   WHERE SA.CIS_DIVISION = SATYPE.CIS_DIVISION         ");
        // START ADD - JHERNA - 2021-10-01 - SysAid#382665
        // START ADD - Darryl H - 2022-01-04 - B20223
        //getSAsString.append("     AND SA.CIS_DIVISION IN ('LGC', 'MGE')             ");
        getSAsString.append("     AND SA.CIS_DIVISION IN (" + cisDivisions + ") ");  
        // END ADD - Darryl H - 2022-01-04 - B20223
        // END ADD - JHERNA - 2021-10-01 - SysAid#382665
        getSAsString.append("     AND SA.SA_TYPE_CD = SATYPE.SA_TYPE_CD             ");
        getSAsString.append("     AND SATYPE.SPECIAL_ROLE_FLG = :specialRoleFlag    ");
        getSAsString.append("     AND EXISTS (SELECT 'X'                            ");
        getSAsString.append("                   FROM CI_FT FT                       ");
        getSAsString.append("                  WHERE FT.SA_ID = SA.SA_ID            ");
        getSAsString.append("                    AND FT.FT_TYPE_FLG IN ('PS','PX')  ");
        getSAsString.append("                    AND FT.FREEZE_DTTM >= :startDTTM   ");
        getSAsString.append("                    AND FT.FREEZE_DTTM <= :endDTTM     ");
        getSAsString.append("                    AND FT.FREEZE_SW = 'Y'             ");
        getSAsString.append("                    AND FT.REDUNDANT_SW = 'N'))        ");

        //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
        //PreparedStatement getServiceAgreements = createPreparedStatement(getSAsString.toString());
        PreparedStatement getServiceAgreements = createPreparedStatement(getSAsString.toString(), getClass().getName());
        //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
        getServiceAgreements.bindLookup("saStatusFlag", ServiceAgreementStatusLookup.constants.STOPPED);
        getServiceAgreements.bindLookup("specialRoleFlag", parmServiceAgreementSpecialRoleFlag);
        getServiceAgreements.bindDate("startDate", sDate);
        getServiceAgreements.bindDate("endDate", eDate);
        getServiceAgreements.bindDateTime("startDTTM", sDate.startOfDay());
        getServiceAgreements.bindDateTime("endDTTM", eDate.endOfDay());

        // Build Worklist
        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();

        QueryIterator<SQLResultRow> iter = getServiceAgreements.iterate();
        while (iter.hasNext()) {
            SQLResultRow row = iter.next();

            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId((ServiceAgreement_Id) row.getId("SA_ID", ServiceAgreement.class));
            workUnit.addSupplementalData("recordType", row.getString("RECTYPE"));

            workUnits.add(workUnit);
        }
        iter.close();

        return createJobWorkForThreadWorkUnitList(workUnits);
    }
    // START ADD - Darryl H - 2022-01-04 - B20223
    /**
     * This method builds the CIS Division string for the main query.
     * @param cisDivisionStr
     * @return String
     */
    private String createCisDivisionString(String cisDivisionStr) {
        
        StringTokenizer strTokenizer = new StringTokenizer(cisDivisionStr, COMMA);
        StringBuilder strBuilder = new StringBuilder();

        while (strTokenizer.hasMoreElements()) {
            strBuilder.append(SINGLE_QUOTE);
            strBuilder.append(strTokenizer.nextToken().trim());
            strBuilder.append(SINGLE_QUOTE);
            if (strTokenizer.hasMoreTokens()) {
                strBuilder.append(COMMA);
            }
        }

        return strBuilder.toString();
    }   
    // END ADD - Darryl H - 2022-01-04 - B20223
    // CVB - 2013-10-23 - Start comment
    /*
     * Retrieve Last Batch Run Date
     */

//    private Date retrieveLastBatchRunDate(){
//
//        Date batchBusinessDate = null;
//
//        Query retrieveLastBatchRunDate = createQuery("from BatchRun BR"
//                + " where BR.id.batchControl = :batchCd"
//                + " and BR.id.batchNumber = ("
//                + " select MAX(BR2.id.batchNumber)"
//                + " from BatchRun BR2"
//                + " where BR2.id.batchControl = BR.id.batchControl"
//                + " and BR2.runStatus = :runStat)");
//
//        retrieveLastBatchRunDate.bindEntity("batchCd", this.getBatchControlId().getEntity());
//        retrieveLastBatchRunDate.bindLookup("runStat", RunStatusLookup.constants.COMPLETE);
//        retrieveLastBatchRunDate.addResult("batchDate", "BR.batchBusinessDate");
//
//        batchBusinessDate = (Date) retrieveLastBatchRunDate.firstRow();
//
//        return batchBusinessDate;
//    }
    // CVB - 2013-10-23 - End comment

    public Class<CmGRTBadDebtExtractBatchWorker> getThreadWorkerClass() {
        return CmGRTBadDebtExtractBatchWorker.class;
    }

    public static class CmGRTBadDebtExtractBatchWorker extends
    CmGRTBadDebtExtractBatchWorker_Gen {

        // Batch Soft Parameters
    	// START ADD - Darryl H - 2022-01-04 - B20223
    	private String parmDivision;
        private List<String> wDivisionList = new ArrayList<String>();
    	// END ADD - Darryl H - 2022-01-04 - B20223
        private String parmFilePath;
        private String parmFileName;
        private String parmNetRevSaTypeCode;
        private String parmStateTaxSaTypeCode;
        private String parmCityTaxSaTypeCode;
        private String parmGrtTaxSaTypeCode;
        private String parmMerchandiseSaTypeCode;
        private String parmRemoteSaTypeCode;
        private String parmJobbingSaTypeCode;
        private String parmInsulationSaTypeCode;
        private CisDivision parmNetRevCisDivision;
        private CisDivision parmStateTaxCisDivision;
        private CisDivision parmCityTaxCisDivision;
        private CisDivision parmGrtTaxCisDivision;
        private CisDivision parmMerchandiseCisDivision;
        private CisDivision parmRemoteCisDivision;
        private CisDivision parmJobbingCisDivision;
        private CisDivision parmInsulationCisDivision;
        private ServiceAgreementType parmNetrev;
        private ServiceAgreementType parmStateTax;
        private ServiceAgreementType parmCityTax;
        private ServiceAgreementType parmGrtTax;
        private ServiceAgreementType parmMerchandise;
        private ServiceAgreementType parmRemote;
        private ServiceAgreementType parmJobbing;
        private ServiceAgreementType parmInsulation;
        private CharacteristicType parmTownCodeCharType;
        private AdjustmentType parmAdjustmentTypeForTransfer;
        // 2015-11-23. SMiran. SF-66226. Start Change
        //private LookupField parmRevenueClassLookupField;
        private ServiceTaskType parmRevClassStaskTypeLgc;
        private ServiceTaskType parmRevClassStaskTypeMge;
        // 2015-11-23. SMiran. SF-66226. End Change
        private Date parmInitialStartDate;

        // Local Constants
        private static final String INITIAL_START_DATE = "Initial Start Date";
        private static final String MMDDYY = "MMDDYY";
        private static final DateFormat mmDdYyyyFormat = new DateFormat("MM-dd-yyyy");
        private static final String DEFAULT_AMOUNT = ".00";
        private static final String SPACE = " ";
        private static final String NETREV = "Net Revenue";
        private static final String STATETAX = "State Tax";
        private static final String CITYTAX = "City Tax";
        private static final String GRTTAX = "Grt Tax";
        private static final String MERCHANDISE = "Merchandise";
        private static final String REMOTE = "Remote";
        private static final String JOBBING = "Jobbing";
        private static final String INSULATION = "Insulation";
        private static final String DATEFORMAT_MMDDYY = "MMddyy";
        private static final String DATEFORMAT_YYYYMM = "yyyyMM";
        private static final String RECORD_TYPE_C = "C";
        private static final String RECORD_TYPE_P = "P";
        private static final String NEW_LINE = "\n";
        private static final String HEADER_REC_TYPE = "RECTYPE";
        private static final String HEADER_CDATE = "CDATE";
        private static final String HEADER_FDATE = "FDATE";
        private static final String HEADER_TOWN_CODE = "TOWNCODE";
        private static final String HEADER_REVENUE_CLASS = "REVENUECLASS";
        private static final String HEADER_PREMISE = "PREMISE";
        private static final String HEADER_ACCOUNT = "ACCOUNT";
        private static final String HEADER_UTILITY = "UTILITY";
        private static final String HEADER_STATE_TAX = "STATETAX";
        private static final String HEADER_CITY_TAX = "CITYTAX";
        private static final String HEADER_GRT_TAX = "GRTTAX";
        private static final String HEADER_MERCH = "MERCH";
        private static final String HEADER_REMOTE = "REMOTE";
        private static final String HEADER_JOBBING = "JOBBING";
        private static final String HEADER_INSULATION = "INSULATION";
    	// Start Add - DHuynh - 2014-09-22 - MGE-CCB007
        private static final String HEADER_CISDIVISION = "CISDIVISION";
    	// End Add - DHuynh - 2014-09-22 - MGE-CCB007
        private static final String REV_CLASS_OTHER = "OTH";

        // Local Variables
        private Date sDate;
        private Date eDate;
        private BufferedWriter bufferedWriter;
        private ServiceAgreement_Id saId;
        private CmBadDebtExtractRecord extractRecord;
        private CmBadDebtExtractHeaderRecord headerRecord;
        private String recordType;

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new SingleTransactionStrategy(this);
        }

        public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {

            // Retrieve batch parameters
            retrieveParameters();

            // Populate Start date field
            // CVB - 2013-10-23 - Start
            Date runDate = this.getProcessDateTime().getDate();
            Date prevMonthDate = runDate.addMonths(-1);

            int prevMonthYYYY = prevMonthDate.getYear();
            int prevMonthMM = prevMonthDate.getMonth();
            int prevMonthLastDay;

            if (prevMonthDate.isLeapYear()){
            	prevMonthLastDay = prevMonthDate.getMonthValue().getLeapYearDaysInMonth();
            }
            else {
            	prevMonthLastDay = prevMonthDate.getMonthValue().getDaysInMonth();
            }
            // sDate = retrieveLastBatchRunDate();
            sDate = new Date(prevMonthYYYY, prevMonthMM,1);

            // if (isNull(sDate)) {
            //     sDate = parmInitialStartDate;
            // }

            // Store current batch run date to end date
            // eDate = this.getProcessDateTime().getDate();
            eDate = new Date(prevMonthYYYY,prevMonthMM,prevMonthLastDay);
            // CVB - 2013-10-23 - End

            parmFileName = parmFileName.replace(MMDDYY, eDate.toString(new DateFormat(DATEFORMAT_MMDDYY)));

            // Open the file
            try {
                File extractFile = new File(parmFilePath, parmFileName);
                bufferedWriter = new BufferedWriter(new FileWriter(extractFile));
            }
            catch (Exception e) {
                e.printStackTrace();
                addError(CustomMessageRepositoryMDC.commBatchFileOpenError(this.getBatchControlId().getIdValue().trim()));
            }

            // CVB - 2013-05-13 - Start
            // Write the header record
            headerRecord = new CmBadDebtExtractHeaderRecord();
            headerRecord.cmSetRecordType(HEADER_REC_TYPE);
            headerRecord.cmSetCDate(HEADER_CDATE);
            headerRecord.cmSetFDate(HEADER_FDATE);
            headerRecord.cmSetTownCode(HEADER_TOWN_CODE);
            headerRecord.cmSetRevenueClass(HEADER_REVENUE_CLASS);
            headerRecord.cmSetPremise(HEADER_PREMISE);
            headerRecord.cmSetAccount(HEADER_ACCOUNT);
            headerRecord.cmSetUtility(HEADER_UTILITY);
            headerRecord.cmSetStateTax(HEADER_STATE_TAX);
            headerRecord.cmSetCityTax(HEADER_CITY_TAX);
            headerRecord.cmSetGrtTax(HEADER_GRT_TAX);
            headerRecord.cmSetMerch(HEADER_MERCH);
            headerRecord.cmSetRemote(HEADER_REMOTE);
            headerRecord.cmSetJobbing(HEADER_JOBBING);
            headerRecord.cmSetInsulation(HEADER_INSULATION);
    	    // Start Add - DHuynh - 2014-09-22 - MGE-CCB007
            headerRecord.cmSetCISDivision(HEADER_CISDIVISION);
        	// End Add - DHuynh - 2014-09-22 - MGE-CCB007
            // Set the delimiters
            headerRecord.cmSetDelimiter0();
            headerRecord.cmSetDelimiter1();
            headerRecord.cmSetDelimiter2();
            headerRecord.cmSetDelimiter3();
            headerRecord.cmSetDelimiter4();
            headerRecord.cmSetDelimiter5();
            headerRecord.cmSetDelimiter6();
            headerRecord.cmSetDelimiter7();
            headerRecord.cmSetDelimiter8();
            headerRecord.cmSetDelimiter9();
            headerRecord.cmSetDelimiter10();
            headerRecord.cmSetDelimiter11();
            headerRecord.cmSetDelimiter12();
            headerRecord.cmSetDelimiter13();
            headerRecord.cmSetDelimiter14();
            headerRecord.cmSetDelimiter15();
    		// Start Add - DHuynh - 2014-09-22 - MGE-CCB007
            headerRecord.cmSetDelimiter16();
    	    // End Add - DHuynh - 2014-09-22 - MGE-CCB007
            writeExtractHeaderRecord();
            // CVB - 2013-05-13 - End
        }

        public boolean executeWorkUnit(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {

            saId = (ServiceAgreement_Id) unit.getPrimaryId();
            recordType = (String) unit.getSupplementallData("recordType");
            
            //Start Add - DHuynh - 2015-04-20 - Defect#3163951
            //Retrieve Cis Division from account
            Account wAccount = saId.getEntity().getAccount();
            CisDivision parmNetRevCisDivision = wAccount.fetchDivision();

            //Retrieve Service Agreement Type
            parmNetrev = retrieveServiceAgreementType(parmNetRevSaTypeCode, parmNetRevCisDivision, NETREV);
            parmStateTax = retrieveServiceAgreementType(parmStateTaxSaTypeCode, parmNetRevCisDivision, STATETAX);
            parmCityTax = retrieveServiceAgreementType(parmCityTaxSaTypeCode, parmNetRevCisDivision, CITYTAX);
            parmGrtTax = retrieveServiceAgreementType(parmGrtTaxSaTypeCode, parmNetRevCisDivision, GRTTAX);
            parmMerchandise = retrieveServiceAgreementType(parmMerchandiseSaTypeCode, parmNetRevCisDivision, MERCHANDISE);
            parmRemote = retrieveServiceAgreementType(parmRemoteSaTypeCode, parmNetRevCisDivision, REMOTE);
            parmJobbing = retrieveServiceAgreementType(parmJobbingSaTypeCode, parmNetRevCisDivision, JOBBING);
            parmInsulation = retrieveServiceAgreementType(parmInsulationSaTypeCode, parmNetRevCisDivision, INSULATION);
            //End Add - DHuynh - 2015-04-20 - Defect#3163951
            
            // Extract the GRT Bad Debts records
            extractGrtBadDebts();
            return true;

        }

        /*
         * Retrieve the Batch parameters
         */
        private void retrieveParameters(){

            parmFilePath = getParameters().getFILE_PATH();
            parmFileName = getParameters().getFILE_NAME();
            parmNetRevSaTypeCode = getParameters().getNETREV_SA_TYPE();
            parmStateTaxSaTypeCode = getParameters().getSTATETAX_SA_TYPE();
            parmCityTaxSaTypeCode = getParameters().getCITYTAX_SA_TYPE();
            parmGrtTaxSaTypeCode = getParameters().getGRTTAX_SA_TYPE();
            parmMerchandiseSaTypeCode = getParameters().getMERCHANDISE_SA_TYPE();
            parmRemoteSaTypeCode = getParameters().getREMOTE_SA_TYPE();
            parmJobbingSaTypeCode = getParameters().getJOBBING_SA_TYPE();
            parmInsulationSaTypeCode = getParameters().getINSULATION_SA_TYPE();
            parmNetRevCisDivision = getParameters().getNETREV_CIS_DIVISION();
            parmStateTaxCisDivision = getParameters().getSTATETAX_CIS_DIVISION();
            parmCityTaxCisDivision = getParameters().getCITYTAX_CIS_DIVISION();
            parmGrtTaxCisDivision = getParameters().getGRTTAX_CIS_DIVISION();
            parmMerchandiseCisDivision = getParameters().getMERCHANDISE_CIS_DIVISION();
            parmRemoteCisDivision = getParameters().getREMOTE_CIS_DIVISION();
            parmJobbingCisDivision = getParameters().getJOBBING_CIS_DIVISION();
            parmInsulationCisDivision = getParameters().getINSULATION_CIS_DIVISION();
            
            // Start Change - DHuynh - 2015-04-20 - Defect#3163951
            //parmNetrev = validateServiceAgreementType(parmNetRevSaTypeCode, parmNetRevCisDivision, NETREV);
            //parmStateTax = validateServiceAgreementType(parmStateTaxSaTypeCode, parmStateTaxCisDivision, STATETAX);
            //parmCityTax = validateServiceAgreementType(parmCityTaxSaTypeCode, parmCityTaxCisDivision, CITYTAX);
            //parmGrtTax = validateServiceAgreementType(parmGrtTaxSaTypeCode, parmGrtTaxCisDivision, GRTTAX);
            //parmMerchandise = validateServiceAgreementType(parmMerchandiseSaTypeCode, parmMerchandiseCisDivision, MERCHANDISE);
            //parmRemote = validateServiceAgreementType(parmRemoteSaTypeCode, parmRemoteCisDivision, REMOTE);
            //parmJobbing = validateServiceAgreementType(parmJobbingSaTypeCode, parmJobbingCisDivision, JOBBING);
            //parmInsulation = validateServiceAgreementType(parmInsulationSaTypeCode, parmInsulationCisDivision, INSULATION);
            //End Change - DHuynh - 2015-04-20 - Defect#3163951
            // START ADD - Darryl H - 2022-01-04 - B20223
            if (notNull(this.getParameters().getCIS_DIVISIONS())){
                String[] parmCisDivisions = this.getParameters().getCIS_DIVISIONS().split(",");
                for (int i=0; i < parmCisDivisions.length; i++){
                    String cisDivStr = parmCisDivisions[i];
                   	wDivisionList.add(cisDivStr.trim());
                }
            }
            // END ADD - Darryl H - 2022-01-04 - B20223
            parmTownCodeCharType = getParameters().getTOWN_CODE_CHAR_TYPE();
            parmAdjustmentTypeForTransfer = getParameters().getADJ_TYPE_FOR_XFER();
            // 2015-11-23. SMiran. SF-66226. Start Change
            //parmRevenueClassLookupField = getParameters().getREV_CLASS_LOOKUP();
            parmRevClassStaskTypeLgc = getParameters().getREVCL_STASK_TYPE_LGC();
            parmRevClassStaskTypeMge = getParameters().getREVCL_STASK_TYPE_MGE();            
            // 2015-11-23. SMiran. SF-66226. End Change
            try {
                parmInitialStartDate = Date.fromString(getParameters().getINITIAL_START_DATE(), mmDdYyyyFormat);
            }
            catch (Exception e) {
                addError(CustomMessageRepositoryMDC.commBatchParmDateFormatInvalid(this.getBatchControlId().getIdValue()
                        .trim(), INITIAL_START_DATE, getParameters().getINITIAL_START_DATE().trim()));
            }
        }


        /*
         * Extract GRT Bad Debts
         */
        private void extractGrtBadDebts(){

            Adjustment wXferAdjustment;
            Premise wPremise = null;
            Account wAccount;
            String wRevenueClass = "";
            String wRevenueClassValue = "";
            ServiceAgreement wOriginalSa;
    		// Start Add - DHuynh - 2014-09-22 - MGE-CCB007
            String cisDivision = "";
    		// End Add - DHuynh - 2014-09-22 - MGE-CCB007

            // Retrieve the Transfer from Adjustment
            Adjustment_Id wXferAdjustmentId = retrieveTransferFromAdjustment();

            if (notNull(wXferAdjustmentId)) {

                wXferAdjustment = wXferAdjustmentId.getEntity();

                // Retrieve the Original SA
                wOriginalSa = wXferAdjustment.getServiceAgreement();

                // CVB - 2013-05-13 - Start
                // wPremise = wOriginalSa.getPremiseId().getEntity();

                Premise_Id wPremiseId;
                wPremiseId = wOriginalSa.getPremiseId();

                if (notNull(wPremiseId)) {
                    wPremise = wPremiseId.getEntity();
                }
                // CVB - 2013-05-13 - End

                wAccount = wOriginalSa.getAccount();

                // Retrieve the town code characteristic value from the premise
                String townCodeCharVal = SPACE;

                if (notNull(wPremise)) {
                    PremiseCharacteristic premChar = wPremise.getEffectiveCharacteristic(parmTownCodeCharType);

                    if (!isNull(premChar)){
                        if (parmTownCodeCharType.getCharacteristicType().isAdhocValue() || parmTownCodeCharType.getCharacteristicType().isFileLocationValue()) {
                            townCodeCharVal = premChar.getAdhocCharacteristicValue().trim();
                        }
                        else if (parmTownCodeCharType.getCharacteristicType().isPredefinedValue()) {
                            townCodeCharVal = premChar.getCharacteristicValue().trim();
                        }
                        else if (parmTownCodeCharType.getCharacteristicType().isForeignKeyValue()) {
                            townCodeCharVal = premChar.getCharacteristicValueForeignKey1();
                        }
                    }
                }

                // Retrieve the revenue class of the original SA

                // CVB - 2013-05-13 - Start
                //wRevenueClass = wOriginalSa.getServiceAgreementType().getRevenueClassId().getIdValue().trim();
                RevenueClass_Id wRevenueClassId = wOriginalSa.getServiceAgreementType().getRevenueClassId();
                if (notNull(wRevenueClassId)){
                    wRevenueClass = wRevenueClassId.getIdValue().trim();
                    // 2015-11-23. SMiran. SF-66226. Start Change
                    //wRevenueClassValue = retrieveRevenueClassDesc(wRevenueClass);
                    wRevenueClassValue = retrieveRevenueClassDesc(wOriginalSa);
                    // 2015-11-23. SMiran. SF-66226. End Change
                }

                // CVB - 2013-10-23 - Start
                if (wRevenueClass.equals(REV_CLASS_OTHER) || (wRevenueClassValue.equals(SPACE)) || (isNull(wRevenueClassId))){
                	return;
                }
                // CVB - 2013-10-23 - End

                // CVB - 2013-05-13 - End

                // Format the FDate using processing date
                String fDate = this.getProcessDateTime().getDate().toString(new DateFormat(DATEFORMAT_YYYYMM)).trim();
                String netRevenue = "";
                String stateTax = "";
                String cityTax = "";
                String grtTax = "";
                String merchandise = "";
                String remote = "";
                String jobbing = "";
                String insulation = "";


                if (recordType.equals(CHARGEOFF_RECTYPE)){

                    // Format the CDate with SA's Start Date
                    Date saStartDate = saId.getEntity().getStartDate();
                    String cDate = saStartDate.toString(new DateFormat(DATEFORMAT_YYYYMM)).trim();

                    // Write a Write-off record
                    extractRecord = new CmBadDebtExtractRecord();
                    extractRecord.cmSetRecordType(RECORD_TYPE_C);
                    extractRecord.cmSetCDate(cDate);
                    extractRecord.cmSetFDate(fDate);
                    extractRecord.cmSetTownCode(townCodeCharVal);
                    extractRecord.cmSetRevenueClass(wRevenueClassValue);
                    if(notNull(wPremise)) {
                        extractRecord.cmSetPremise(wPremise.getId().getIdValue().trim());

                    }
                    // CVB - 2013-05-13 - Start
                    else {
                        extractRecord.cmSetPremise("");
                    }
                    // CVB - 2013-05-13 - End
                    extractRecord.cmSetAccount(wAccount.getId().getIdValue().trim());

                    // Retrieve and set Net Revenue value
                    netRevenue = cmCheckSaType(parmNetrev, Bool.TRUE);
                    extractRecord.cmSetNetRevenue(netRevenue);
                    // Retrieve and set State Tax value
                    stateTax = cmCheckSaType(parmStateTax, Bool.TRUE);
                    extractRecord.cmSetStateTax(stateTax);
                    // Retrieve and set City Tax value
                    cityTax = cmCheckSaType(parmCityTax, Bool.TRUE);
                    extractRecord.cmSetCityTax(cityTax);
                    // Retrieve and set GRT Tax value
                    grtTax = cmCheckSaType(parmGrtTax, Bool.TRUE);
                    extractRecord.cmSetGrtTax(grtTax);
                    // Retrieve and set Merchandise value
                    merchandise = cmCheckSaType(parmMerchandise, Bool.TRUE);
                    extractRecord.cmSetMerch(merchandise);
                    // Retrieve and set Remote value
                    remote = cmCheckSaType(parmRemote, Bool.TRUE);
                    extractRecord.cmSetRemote(remote);
                    // Retrieve and set Jobbing value
                    jobbing = cmCheckSaType(parmJobbing, Bool.TRUE);
                    extractRecord.cmSetJobbing(jobbing);
                    // Retrieve and set Insulation value
                    insulation = cmCheckSaType(parmInsulation, Bool.TRUE);
                    extractRecord.cmSetInsulation(insulation);
    				// Start Add - DHuynh - 2014-09-22 - MGE-CCB007
                    cisDivision = wAccount.getDivisionId().getTrimmedValue();
                    extractRecord.cmSetCISDivision(cisDivision);
    				// End Add - DHuynh - 2014-09-22 - MGE-CCB007

                    // Set the delimiters
                    // CVB - 2013-05-13 - Start
                    extractRecord.cmSetDelimiter0();
                    // CVB - 2013-05-13 - End
                    extractRecord.cmSetDelimiter1();
                    extractRecord.cmSetDelimiter2();
                    extractRecord.cmSetDelimiter3();
                    extractRecord.cmSetDelimiter4();
                    extractRecord.cmSetDelimiter5();
                    extractRecord.cmSetDelimiter6();
                    extractRecord.cmSetDelimiter7();
                    extractRecord.cmSetDelimiter8();
                    extractRecord.cmSetDelimiter9();
                    extractRecord.cmSetDelimiter10();
                    extractRecord.cmSetDelimiter11();
                    extractRecord.cmSetDelimiter12();
                    extractRecord.cmSetDelimiter13();
                    extractRecord.cmSetDelimiter14();
                    extractRecord.cmSetDelimiter15();
    				// Start Add - DHuynh - 2014-09-22 - MGE-CCB007
                    extractRecord.cmSetDelimiter16();
    				// End Add - DHuynh - 2014-09-22 - MGE-CCB007

                    writeExtractRecord();

                }

                if (recordType.equals(PAYMENT_RECTYPE)){
                    // Check if SA has a corresponding payment or payment cancellation in FT Table
                    DateTime freezeDttmPayment = checkForPaymentFt();

                    // If a record is retrieved, write a payment record in the extract file
                    if (notNull(freezeDttmPayment)) {
                        String cDate2 = freezeDttmPayment.getDate().toString(new DateFormat(DATEFORMAT_YYYYMM)).trim();

                        extractRecord = new CmBadDebtExtractRecord();
                        extractRecord.cmSetRecordType(RECORD_TYPE_P);
                        extractRecord.cmSetCDate(cDate2);
                        extractRecord.cmSetFDate(fDate);
                        extractRecord.cmSetTownCode(townCodeCharVal);
                        extractRecord.cmSetRevenueClass(wRevenueClassValue);
                        if(notNull(wPremise)) {
                            extractRecord.cmSetPremise(wPremise.getId().getIdValue().trim());
                        }
                        // CVB - 2013-05-13 - Start
                        else {
                            extractRecord.cmSetPremise("");
                        }
                        // CVB - 2013-05-13 - End
                        extractRecord.cmSetAccount(wAccount.getId().getIdValue().trim());
                        // Retrieve and set Net Revenue value
                        netRevenue = cmCheckSaType(parmNetrev, Bool.FALSE);
                        extractRecord.cmSetNetRevenue(netRevenue);
                        // Retrieve and set State Tax value
                        stateTax = cmCheckSaType(parmStateTax, Bool.FALSE);
                        extractRecord.cmSetStateTax(stateTax);
                        // Retrieve and set City Tax value
                        cityTax = cmCheckSaType(parmCityTax, Bool.FALSE);
                        extractRecord.cmSetCityTax(cityTax);
                        // Retrieve and set GRT Tax value
                        grtTax = cmCheckSaType(parmGrtTax, Bool.FALSE);
                        extractRecord.cmSetGrtTax(grtTax);
                        // Retrieve and set Merchandise value
                        merchandise = cmCheckSaType(parmMerchandise, Bool.FALSE);
                        extractRecord.cmSetMerch(merchandise);
                        // Retrieve and set Remote value
                        remote = cmCheckSaType(parmRemote, Bool.FALSE);
                        extractRecord.cmSetRemote(remote);
                        // Retrieve and set Jobbing value
                        jobbing = cmCheckSaType(parmJobbing, Bool.FALSE);
                        extractRecord.cmSetJobbing(jobbing);
                        // Retrieve and set Insulation value
                        insulation = cmCheckSaType(parmInsulation, Bool.FALSE);
                        extractRecord.cmSetInsulation(insulation);
    					// Start Add - DHuynh - 2014-09-22 - MGE-CCB007
                        cisDivision = wAccount.getDivisionId().getTrimmedValue();
                        extractRecord.cmSetCISDivision(cisDivision);
    				    // End Add - DHuynh - 2014-09-22 - MGE-CCB007
                        // Set the delimiters
                        // CVB - 2013-05-13 - Start
                        extractRecord.cmSetDelimiter0();
                        // CVB - 2013-05-13 - End
                        extractRecord.cmSetDelimiter1();
                        extractRecord.cmSetDelimiter2();
                        extractRecord.cmSetDelimiter3();
                        extractRecord.cmSetDelimiter4();
                        extractRecord.cmSetDelimiter5();
                        extractRecord.cmSetDelimiter6();
                        extractRecord.cmSetDelimiter7();
                        extractRecord.cmSetDelimiter8();
                        extractRecord.cmSetDelimiter9();
                        extractRecord.cmSetDelimiter10();
                        extractRecord.cmSetDelimiter11();
                        extractRecord.cmSetDelimiter12();
                        extractRecord.cmSetDelimiter13();
                        extractRecord.cmSetDelimiter14();
                        extractRecord.cmSetDelimiter15();
    					// Start Add - DHuynh - 2014-09-22 - MGE-CCB007
                        extractRecord.cmSetDelimiter16();
    					// End Add - DHuynh - 2014-09-22 - MGE-CCB007
                        writeExtractRecord();
                    }
                }
            }
        }
        /*
         * Check for payment FT
         */
        private DateTime checkForPaymentFt(){

            DateTime freezeDttmPayment = null;

            Query checkForPaymentFt = createQuery("from FinancialTransaction FT"
                    + " where FT.serviceAgreement = :saId"
                    + " and FT.financialTransactionType IN (:ftType1, :ftType2)"
                    + " and FT.freezeDateTime >= :sDate"
                    + " and FT.freezeDateTime <= :eDate"
                    + " and FT.isFrozen = :freezeSw"
                    //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
                    //+ " and FT.isRedundant = :redundantSw");
                    + " and FT.isRedundant = :redundantSw", getClass().getName());
            		//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            
            checkForPaymentFt.bindEntity("saId", saId.getEntity());
            checkForPaymentFt.bindLookup("ftType1", FinancialTransactionTypeLookup.constants.PAY_SEGMENT);
            checkForPaymentFt.bindLookup("ftType2", FinancialTransactionTypeLookup.constants.PAY_CANCELLATION);
            checkForPaymentFt.bindDateTime("sDate", sDate.startOfDay());
            checkForPaymentFt.bindDateTime("eDate", eDate.endOfDay());
            checkForPaymentFt.bindBoolean("freezeSw", Bool.TRUE);
            checkForPaymentFt.bindBoolean("redundantSw", Bool.FALSE);
            checkForPaymentFt.addResult("freezeDttm", "FT.freezeDateTime");

            if (checkForPaymentFt.listSize() > 0) {
                freezeDttmPayment = (DateTime) checkForPaymentFt.firstRow();
            }

            return freezeDttmPayment;
        }

        /*
         * Write the extract record
         */
        private void writeExtractRecord(){
            try {
                bufferedWriter.write(extractRecord.createRecordString() + NEW_LINE);
            }
            catch (Exception e) {
                e.printStackTrace();
                addError(CustomMessageRepositoryMDC.commBatchFileWriteError(this.getBatchControlId().getIdValue().trim()));
            }
        }

        /*
         * Write the extract header record
         */
        private void writeExtractHeaderRecord(){
            try {
                bufferedWriter.write(headerRecord.createRecordString() + NEW_LINE);
            }
            catch (Exception e) {
                e.printStackTrace();
                addError(CustomMessageRepositoryMDC.commBatchFileWriteError(this.getBatchControlId().getIdValue().trim()));
            }
        }

        /*
         * Retrieve Total Amount for a specific SA Type
         */
        private String cmCheckSaType(ServiceAgreementType saType, Bool checkAdjustment){

            String stringValue = DEFAULT_AMOUNT;
            String tempValue = SPACE;

            if (saId.getEntity().getServiceAgreementType().equals(saType)) {
                if (checkAdjustment.isTrue()) {
                    tempValue = getTotalAmount(FinancialTransactionTypeLookup.constants.ADJUSTMENT, FinancialTransactionTypeLookup
                            .constants.ADJUSTMENT_CANCELLATION);
                }
                else {
                    tempValue = getTotalAmount(FinancialTransactionTypeLookup.constants.PAY_SEGMENT, FinancialTransactionTypeLookup
                            .constants.PAY_CANCELLATION);
                }

                if (!tempValue.equals(SPACE)) {
                    stringValue = tempValue;
                }
            }
            return stringValue;
        }
        /*
         * Get the total amount from FT Table for an SA
         */
        private String getTotalAmount(FinancialTransactionTypeLookup ftType1, FinancialTransactionTypeLookup ftType2){

            String totalAmount = SPACE;

            Query<Money> getTotalAmount = createQuery("from FinancialTransaction FT"
                    + " where FT.serviceAgreement = :saId"
                    + " and FT.isFrozen = :freezeSw"
                    + " and FT.freezeDateTime >= :sDateTime "
                    + " and FT.freezeDateTime <= :eDateTime "
                    //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
                    //+ " and FT.financialTransactionType IN (:ftType1, :ftType2)");
                    + " and FT.financialTransactionType IN (:ftType1, :ftType2)", getClass().getName());
            		//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation

            getTotalAmount.bindEntity("saId", saId.getEntity());
            getTotalAmount.bindBoolean("freezeSw", Bool.TRUE);
            getTotalAmount.bindDateTime("sDateTime", sDate.startOfDay());
            getTotalAmount.bindDateTime("eDateTime", eDate.endOfDay());
            getTotalAmount.bindLookup("ftType1", ftType1);
            getTotalAmount.bindLookup("ftType2", ftType2);
            getTotalAmount.addResult("currAmount", "SUM(FT.currentAmount)");

            if (getTotalAmount.list().size() > 0) {
                totalAmount = getTotalAmount.firstRow().getAmount().toString();
            }

            return totalAmount;
        }

        /*
         * Retrieve the revenue class description from Revenue class lookup
         */
        // 2015-11-23. SMiran. SF-66226. Start Change
        //private String retrieveRevenueClassDesc(String revClassValue){
        private String retrieveRevenueClassDesc(ServiceAgreement originalSA){
        // 2015-11-23. SMiran. SF-66226. Start Change

            String revenueClassDesc = SPACE;
            // 2015-11-23. SMiran. SF-66226. Start Change
            //Query retrieveRevenueClassDesc = createQuery("from LookupValue_Language VAL"
            //        + " where VAL.id.parent.id.fieldName = :fieldName"
            //        + " and VAL.id.parent.id.fieldValue = :fieldVal"
            //        + " and VAL.id.language = :languageCode");

            //retrieveRevenueClassDesc.bindEntity("fieldName", parmRevenueClassLookupField);
            //retrieveRevenueClassDesc.bindStringProperty("fieldVal", LookupValue.properties.fieldValue, revClassValue);
            //retrieveRevenueClassDesc.bindEntity("languageCode", this.getActiveContextLanguage());
            //retrieveRevenueClassDesc.addResult("description", "VAL.description");

            //if (retrieveRevenueClassDesc.listSize() > 0) {
            //    revenueClassDesc = (String) retrieveRevenueClassDesc.firstRow();
            //}
            // START ADD - JHERNA - 2021-10-01 - SysAid#382665
            if (!wDivisionList.contains(originalSA.getServiceAgreementType().fetchIdDivision().getId().getIdValue().trim())){
            	addError(CustomMessageRepositoryMGE.commGenericError("Cannot process non-LGC / non-MGE SA '"+originalSA.getId().getTrimmedValue()+"'. SA must be LGC and MGE division only."));
            }
            // END ADD - JHERNA - 2021-10-01 - SysAid#382665
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT x.GRTREVCLASS ");
            stringBuilder.append("FROM F1_SVC_TASK_TYPE s ");
            stringBuilder.append(" , XMLTable( ");
            stringBuilder.append(" '/revenueClassDetails/revenueClassList/revenueClass' ");
            stringBuilder.append(" passing xmltype(s.BO_DATA_AREA) ");
            stringBuilder.append(" columns ");
            stringBuilder.append(" SATYPECD CHAR(08) PATH 'saTypeCd' ");
            stringBuilder.append(" , GRTREVCLASS CHAR(03) PATH 'grtRevClass' ");
            stringBuilder.append(" ) x ");
            stringBuilder.append(" WHERE s.F1_STASK_TYPE_CD = :serviceTaskTypeId ");
            stringBuilder.append(" and x.saTypeCd = :saTypeCd ");
            
            //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            //PreparedStatement preparedStatement =  createPreparedStatement(stringBuilder.toString());
            PreparedStatement preparedStatement =  createPreparedStatement(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            CisDivision originalSaCisDivision = originalSA.getServiceAgreementType().fetchIdDivision();
            if (originalSaCisDivision.getId().getIdValue().trim().equals("LGC")){
                preparedStatement.bindId("serviceTaskTypeId", parmRevClassStaskTypeLgc.getId());              
                
            }else if (originalSaCisDivision.getId().getIdValue().trim().equals("MGE")){
            	preparedStatement.bindId("serviceTaskTypeId", parmRevClassStaskTypeMge.getId());
            }
            preparedStatement.bindString("saTypeCd", originalSA.getServiceAgreementType().fetchIdSaType(), "SATYPECD");
            
            SQLResultRow row = preparedStatement.firstRow();
            if (notNull(row)){
            	revenueClassDesc = row.getString("GRTREVCLASS");
            }
            
            // 2015-11-23. SMiran. SF-66226. End Change

            return revenueClassDesc;
        }

        /*
         * Retrieve Transfer From Adjustment
         */
        private Adjustment_Id retrieveTransferFromAdjustment(){

            Adjustment_Id adjId = null;

            Query retrieveTransferFromAdjustment = createQuery("from Adjustment ADJ, FinancialTransaction FT"
                    + " where ADJ.serviceAgreement = :saId"
                    + " and ADJ.adjustmentType = :adjTypeCd"
                    + " and FT.siblingId = ADJ.id"
                    + " and FT.isFrozen = :freezeSw"
                    //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
                    //+ " and FT.isRedundant = :redundantSw");
                    + " and FT.isRedundant = :redundantSw", getClass().getName());
            		//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            

            retrieveTransferFromAdjustment.bindEntity("saId", saId.getEntity());
            retrieveTransferFromAdjustment.bindEntity("adjTypeCd", parmAdjustmentTypeForTransfer);
            retrieveTransferFromAdjustment.bindBoolean("freezeSw", Bool.TRUE);
            // retrieveTransferFromAdjustment.bindDateTime("sDateTime", sDate.startOfDay());
            // retrieveTransferFromAdjustment.bindDateTime("eDateTime", eDate.endOfDay());
            retrieveTransferFromAdjustment.bindBoolean("redundantSw", Bool.FALSE);
            retrieveTransferFromAdjustment.addResult("xferAdjId", "ADJ.transferAdjustmentId");

            retrieveTransferFromAdjustment.addResult("freezeDateTime", "FT.freezeDateTime");
            retrieveTransferFromAdjustment.orderBy("freezeDateTime", Query.ASCENDING);

            if(retrieveTransferFromAdjustment.list().size() > 0) {
                QueryResultRow getTransferAdjustment = (QueryResultRow) retrieveTransferFromAdjustment.firstRow();
                adjId = (Adjustment_Id) getTransferAdjustment.getId("xferAdjId", Adjustment.class);
            }

            return adjId;
        }

        /*
         * Retrieve Last Batch Run Date
         */
        // CVB - 2013-10-23 - Start comment
//        private Date retrieveLastBatchRunDate(){
//
//            Date batchBusinessDate = null;
//
//            Query retrieveLastBatchRunDate = createQuery("from BatchRun BR"
//                    + " where BR.id.batchControl = :batchCd"
//                    + " and BR.id.batchNumber = ("
//                    + " select MAX(BR2.id.batchNumber)"
//                    + " from BatchRun BR2"
//                    + " where BR2.id.batchControl = BR.id.batchControl"
//                    + " and BR2.runStatus = :runStat)");
//
//            retrieveLastBatchRunDate.bindEntity("batchCd", this.getBatchControlId().getEntity());
//            retrieveLastBatchRunDate.bindLookup("runStat", RunStatusLookup.constants.COMPLETE);
//            retrieveLastBatchRunDate.addResult("batchDate", "BR.batchBusinessDate");
//
//            batchBusinessDate = (Date) retrieveLastBatchRunDate.firstRow();
//
//            return batchBusinessDate;
//        }
        // CVB - 2013-10-23 - End comment
        //Start Change - DHuynh - 2015-04-20 - Defect#3163951
        /*
         * Retrieve SA Type
         */
        private ServiceAgreementType retrieveServiceAgreementType(String saType, CisDivision cisDivision, String parmDesc){

            ServiceAgreementType_Id serviceAgreementTypeId = new ServiceAgreementType_Id(cisDivision, saType);
            ServiceAgreementType serviceAgreementType = serviceAgreementTypeId.getEntity();
            
            //if (isNull(serviceAgreementType)) {
            //    addError(CustomMessageRepositoryMDC.commBatchParmInvalidSaType(this.getBatchControlId().getIdValue()
            //            .trim(), parmDesc, cisDivision.getId().getIdValue(), saType));
            //}
            
            return serviceAgreementType;
        }
        //End Change - DHuynh - 2015-04-20 - Defect#3163951
        
        public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
            // Close the file
            try {
                bufferedWriter.close();
            }
            catch (Exception e) {
                e.printStackTrace();
                addError(CustomMessageRepositoryMDC.commBatchFileCloseError(this.getBatchControlId().getIdValue().trim()));
            }
        }
    }
}
