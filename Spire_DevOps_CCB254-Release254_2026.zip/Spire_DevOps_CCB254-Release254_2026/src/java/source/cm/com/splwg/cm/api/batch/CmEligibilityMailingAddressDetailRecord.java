/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Record Layout for Custom Eligibility Mailing Address Detail Record
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-04-24   RDizon  NI0026.1 Initial Version.
 * 2013-11-07   Neha    IM-039396 XML parser throws error for Address with &, 
 *                      including CDATA to avoid parsing
 **************************************************************************/

package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmEligibilityMailingAddressDetailRecord
extends ColumnDelimitedRecord {

	public CmEligibilityMailingAddressDetailRecord() {
		super(5);
	}

	public void setAddress1(String address1) {
		// Start change 2013-11-07 Neha IM-039396
		//String string = "<Address1>" + address1 + "</Address1>" + "\n";
		String string = "<Address1>" + "<![CDATA[" + address1 + "]]>" + "</Address1>" + "\n";
		// End change 2013-11-07 Neha IM-039396
		this.rightPadColumn(1, string.length(), string);
	}

	public void setAddress2(String address2) {
		// Start change 2013-11-07 Neha IM-039396
		String string = "<Address2>"  + "<![CDATA[" + address2 + "]]>" + "</Address2>" + "\n";
		// End change 2013-11-07 Neha IM-039396
		this.rightPadColumn(2, string.length(), string);
	}

	public void setCity(String city) {
		// String string = "<City>" + city + "</City>" + "\n";
		String string = "<City>"  + "<![CDATA[" + city + "]]>" + "</City>" + "\n";
		this.rightPadColumn(3, string.length(), string);
	}

	public void setState(String state) {
		String string = "<State>" + state + "</State>" + "\n";
		this.rightPadColumn(4, string.length(), string);
	}

	public void setPostalCode(String postalCode) {
		String string = "<PostalCode>" + postalCode + "</PostalCode>" + "\n";
		this.rightPadColumn(5, string.length(), string);
	}
}
