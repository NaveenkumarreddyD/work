/**
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                     
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * This FT Creation Algorithm validates if the user creating the 
 * Adjustment has sufficient authorization to do so.
 * 
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:       by:          Reason:
 * YYYY-MM-DD  FLName
 * 2019-08-01  DIKSHA		SysAid#09299 Initial Version.
 * 
 ***********************************************************************
 */
package com.splwg.cm.domain.admin.adjustmentType.algorithm.freezeAdjustment;

import com.splwg.base.domain.security.applicationService.ApplicationService;
import com.splwg.base.domain.security.securityType.SecurityAuthorizationLevel_Id;
import com.splwg.base.domain.security.securityType.SecurityType;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.admin.adjustmentType.algorithm.freezeAdjustment.AdjustmentFreezeAlgorithmSpot;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author TMG02633
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = applicationService, name = applicationService, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = securityType, name = securityType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = authorizationLevel, required = true, type = string)})
 */

public class CmFreezeAdjustmentAuthorizationAlgComp_Impl extends CmFreezeAdjustmentAuthorizationAlgComp_Gen implements
		AdjustmentFreezeAlgorithmSpot {

	/*Soft Parameters*/
	private ApplicationService parmApplicationService;
	private SecurityType parmSecurityTypeBankruptAuthorization;
	private String parmAuthorizationLevel;	
	
	/*Work Variables*/
	private SecurityAuthorizationLevel_Id wSecAuthLevelID;
	private String wAlgorithmCode;
	private Adjustment adjustment;
	
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

		wAlgorithmCode = this.getAlgorithmId().getTrimmedValue();
		
		parmApplicationService = this.getApplicationService();
		parmSecurityTypeBankruptAuthorization = this.getSecurityType();
		parmAuthorizationLevel = this.getAuthorizationLevel();
		wSecAuthLevelID = new SecurityAuthorizationLevel_Id(parmSecurityTypeBankruptAuthorization, parmAuthorizationLevel);
		if (isNull(wSecAuthLevelID.getEntity())) {
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterIsInvalid(wAlgorithmCode, "Admin Access Level", parmAuthorizationLevel.trim()));
		}
	}

	@Override
	public void invoke() {
		
		boolean canCreateFT = this.getActiveContextUser().hasAuthorization(parmApplicationService, wSecAuthLevelID);
		if (!canCreateFT) {
			// User %1 has no authorization to create Adjustment FT of type %2.
			addError(CustomMessageRepositoryMGE.b09299AdjFTCreationNotAllowed(this.getActiveContextUser().getId().getTrimmedValue(), adjustment.getAdjustmentType().getId().getIdValue()));
		}
	}

	@Override
	public void setAdjustment(Adjustment arg0) {
		adjustment = arg0;
	}

}
