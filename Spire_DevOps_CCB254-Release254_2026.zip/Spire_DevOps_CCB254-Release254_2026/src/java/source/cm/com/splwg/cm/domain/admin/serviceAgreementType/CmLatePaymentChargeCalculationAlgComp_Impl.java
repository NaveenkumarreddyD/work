/* 
 *********************************************************************** 
 *                 Confidentiality Information: 
 * 
 * This module is the confidential and proprietary information of 
 * Oracle Corporation; it is not to be copied, reproduced, or 
 * transmitted in any form, by any means, in whole or in part, 
 * nor is it to be used for any purpose other than that for which 
 * it is expressly provided without the written permission of 
 * Oracle Corporation. 
 * 
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * This algorithm will prevent LPC from being assessed on 
 * final bill segments.
 * 
 * 
 ********************************************************************** 
 * 
 * 
 * CHANGE HISTORY: 
 * 
 * Date:       by:       Reason: 
 * 2013-01-22  AGambo    Created. Initial Version. 
 * 2013-09-11  MOL       LPC amount should be zero if SA's credit balance
 *                       is less than 0. (IM-037401)
 * 2014-01-14  Ujesh     LPC amount should be zero if the 
 * 						 bill is not having any bill segment 
 * 						 for that SA. (IM-043694)     
 * 2016-01-26  MPang	 Updated for CCB v2.4 compilation. 
 * 2025-03-11  JVitug    B-32269.Issue3. Added logic to 
 *                       set the LPC amount to zero if the
 *                       SA has no premise, the Adjustment Type is 
 *                       MGE-LPC , and the CIS Division is MGE. 
 ************************************************************************ 
 */

package com.splwg.cm.domain.admin.serviceAgreementType;

import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.Query;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.AdjustmentStatusLookup;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.adjustmentType.AdjustmentType;
import com.splwg.ccb.domain.admin.billFactor.BillFactor;
import com.splwg.ccb.domain.admin.billFactor.BillFactorValueData;
import com.splwg.ccb.domain.admin.billFactor.BillFactorValueInfoData;
import com.splwg.ccb.domain.admin.billFactor.BillFactorValueInfoRetriever;
import com.splwg.ccb.domain.admin.billFactor.BillFactorValueInfoRetrieverData;
import com.splwg.ccb.domain.admin.serviceAgreementType.SaTypeLpcCalculationAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.Bill;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;*/
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType_Id;
import com.splwg.ccb.domain.admin.billFactor.entity.BillFactor;
import com.splwg.ccb.domain.admin.common.BillFactorValueInfoRetriever;
import com.splwg.ccb.domain.admin.data.BillFactorValueData;
import com.splwg.ccb.domain.admin.data.BillFactorValueInfoData;
import com.splwg.ccb.domain.admin.data.BillFactorValueInfoRetrieverData;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.lpcCalculation.SaTypeLpcCalculationAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;


/**
 * @author AAGAMBOA
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentType, name = lpcAdjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billFactor, name = billFactor, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = premiseCharType, type = entity , required = false)
 *            , @AlgorithmSoftParameter (name = paAdjustmentTypes, type = string , required = false)})
 */
public class CmLatePaymentChargeCalculationAlgComp_Impl extends
		CmLatePaymentChargeCalculationAlgComp_Gen implements
		SaTypeLpcCalculationAlgorithmSpot {
	
	// Soft Parameter Variables
	private AdjustmentType adjustmentType;
	private BillFactor billFactor;
	//Start Add JVitug - B-32269.Issue3 - 2025-03-11
	private CharacteristicType premiseCharType;
	private String paAdjustmentTypes;
	//End Add JVitug - B-32269.Issue3 - 2025-03-11
	
	// Hard Parameter variables
	private Bill bill;
	private Date billDate;
	private ServiceAgreement serviceAgreement;
	
	// Work varibales
	private Money latePaymentAmount;
	
	//Start Add JVitug - B-32269.Issue3 - 2025-03-11
	private Premise premise;
	
	//Constants
	private String MGE_CIS_DIVISION = "MGE";
	private String MGE_LPC_ADJ_TYPE = "MGE-LPC";
	private String COMMA = ",";
	private String QUOTE = "'";
	//End Add JVitug - B-32269.Issue3 - 2025-03-11

	public AdjustmentType getAdjustmentType() {
		return this.adjustmentType;
	}

	public Money getLatePaymentAmount() {
		return latePaymentAmount;
	}

	public void setBill(Bill bill) {
		this.bill = bill;
	}

	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}

	public void setServiceAgreement(ServiceAgreement serviceAgreement) {
		this.serviceAgreement = serviceAgreement;
	}

	public void invoke() {
		Bool closingSwitch = Bool.FALSE;
		
		/*
		 * IM-037401 Begin - Do not apply LPC if SA's Current Balance is <= 0
		 */ 
		latePaymentAmount = Money.ZERO;
		/*
		 * IM-037401 End - Do not apply LPC if SA's Current Balance is <= 0
		 */ 
		
		// Get the Bill Segment's Closing Switch
		Query closingSwitchQuery = cmGetBillSegmentClosingSwitch();
		if(!closingSwitchQuery.list().isEmpty()) {
			closingSwitch = (Bool) closingSwitchQuery.firstRow();
		}
		/*
		 * IM-043694 Start - 2014-01-14 Ujesh - Do not apply LPC is Bill is not having any billsegment for the SA
		 */
		//if (closingSwitch.isTrue()) {
		if (closingSwitch.isTrue()||closingSwitchQuery.list().isEmpty()) {	
		/*
		 * IM-043694 End - 2014-01-14 Ujesh - Do not apply LPC is Bill is not having any billsegment for the SA
		 */			
	
			latePaymentAmount = Money.ZERO;
		}
		else {
			// Get the Bill Factor Value 
			BigDecimal billFactorValue = cmGetBillFactorValue();
			// Get the SA's current balance 
			Money saBalance = serviceAgreement.getCurrentBalance(this.getProcessDateTime().getDate(), billDate, Bool.TRUE);
			
			/*
			 * IM-037401 Begin - Do not apply LPC if SA's Current Balance is <= 0
			 */ 
			if (saBalance.getAmount().compareTo(BigDecimal.ZERO) > 0 ) {
				/*
				 * IM-037401 End - Do not apply LPC if SA's Current Balance is <= 0
				 */ 
				//Start Add JVitug - B-32269.Issue3 - 2025-03-11
				//MGE has a different way of charging Late Payment Charges , as the MGE-TAX rate schedule is applied to
				// LPCs for MGE Payment Arrangements
				//Start Add JVitug - B-32269.Issue3 - 2025-03-11
				//Derive the premise using the adjustment created on start of the Payment Arrangement. Only do this if the 
				//Service Agreement's Characteristic premise is blank.
				ServiceAgreementType saType = serviceAgreement.getServiceAgreementType();	
				if(notNull(premiseCharType) && !isBlankOrNull(paAdjustmentTypes)
						&& (saType.getSpecialRole().isPaymentArrangement()
							&& isNull(serviceAgreement.fetchPremise())
							&& serviceAgreement.getAccount().getDivisionId().getTrimmedValue().compareTo(MGE_CIS_DIVISION) == 0
							&& adjustmentType.getId().getTrimmedValue().compareTo(MGE_LPC_ADJ_TYPE) == 0)) {
					premise = getPremiseFromSACharacteristic();

					//If Premise couldn't be derived from the SA Characteristic, attempt to derive the premise from the
					//initial PA Adjustment created when activating a Payment Arrangement SA
					if(isNull(premise)) {
						premise = getPremiseFromSICAdjustment();

						//If no Premise was still derived, do not proceed in creation the LPC, as it will cause an error 
						//since the MGE-LPC adjustment type applies a rate schedule
						if(isNull(premise)) {
							latePaymentAmount = Money.ZERO;
							return;
						}
					}
					//End Add JVitug - B-32269.Issue3 - 2025-03-11
				}
				//End Add JVitug - B-32269.Issue3 - 2025-03-11
				// Calculate Late Payment Amount
				BigDecimal amount = saBalance.getAmount().multiply(billFactorValue.divide(BigDecimal.valueOf(100))).setScale(2, BigDecimal.ROUND_HALF_UP);			
				latePaymentAmount = new Money(amount, serviceAgreement.getCurrencyId());
				/*
				 * IM-037401 Begin - Do not apply LPC if SA's Current Balance is <= 0
				 */ 
			}
			/*
			 * IM-037401 End - Do not apply LPC if SA's Current Balance is <= 0
			 */ 
			
		}
	}
	
	/**
	 * This method will retrieve algorithm parameters
	 * @param isValid boolean
	 */
	@Override
	protected void extraSoftParameterValidations(boolean isValid) {
		adjustmentType = this.getLpcAdjustmentType();
		billFactor = this.getBillFactor();
		//Start Add JVitug - B-32269.Issue3 - 2025-03-11
		premiseCharType = getPremiseCharType();
		paAdjustmentTypes = getPaAdjustmentTypes();
		
		if(!isBlankOrNull(paAdjustmentTypes)) {
			String[] adjustmentTypesStr = paAdjustmentTypes.split(COMMA);

			AdjustmentType adjTypeVal = null;
			for(String adjTypeStr : adjustmentTypesStr) {
				adjTypeVal = new AdjustmentType_Id(adjTypeStr.trim()).getEntity();

				if(isNull(adjTypeVal))
					addError(CustomMessageRepository.B32269_invalidAdjustmentType("Payment Arrangement Transfer Adjustment Types", adjTypeStr.trim()));
			}
		}
		//End Add JVitug - B-32269.Issue3 - 2025-03-11
	}
	
	/**
	 * This method will retrieve bill segment closing switch
	 * @return query
	 */
	private Query cmGetBillSegmentClosingSwitch() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(" FROM Bill b, BillSegment bs ");
		stringBuilder.append(" WHERE b.id = :billId ");
		stringBuilder.append(" AND b.id = bs.billId ");
		stringBuilder.append(" AND bs.serviceAgreement = :serviceAgreement ");
		stringBuilder.append(" AND bs.billSegmentStatus = :billSegmentStatus ");
		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//Query query = createQuery(stringBuilder.toString());
		Query query = createQuery(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		
		query.addResult("isClosingBillSegment", "bs.isClosingBillSegment");
		
		query.bindId("billId", bill.getId());
		query.bindEntity("serviceAgreement", serviceAgreement);
		query.bindLookup("billSegmentStatus", BillSegmentStatusLookup.constants.FROZEN);

		return query;
	}
	
	/**
	 * This method will retrieve bill factor value
	 * @return billFactorValue
	 */
	private BigDecimal cmGetBillFactorValue() {	
		// Retrieve the Bill Factor Value.
		BillFactorValueInfoRetrieverData billFactorValueRetrieverData = BillFactorValueInfoRetrieverData.Factory.newInstance();
		billFactorValueRetrieverData.setBillFactor(billFactor);
		billFactorValueRetrieverData.setServiceAgreement(serviceAgreement);
		billFactorValueRetrieverData.setBillFactorPeriodStartDate(billDate);
		billFactorValueRetrieverData.setBillFactorPeriodEndDate(billDate);
		billFactorValueRetrieverData.setCharSourcePremise(serviceAgreement.fetchPremise());
		billFactorValueRetrieverData.setNoProrationAccountingDate(billDate);
		billFactorValueRetrieverData.setNoProrationStartDate(billDate);
		billFactorValueRetrieverData.setNoProrationEndDate(billDate);
		billFactorValueRetrieverData.setToFillTheGap(Bool.FALSE);
				
		BillFactorValueInfoRetriever billFactorValueInfoRetriever = BillFactorValueInfoRetriever.Factory.newInstance();
		billFactorValueInfoRetriever.retrieveBillFactorValueInfo(billFactorValueRetrieverData);
		
		BillFactorValueInfoData billFactorVal = billFactorValueRetrieverData.getBillFactorValueInfoData();
				
		// Retrieve the Bill Factor Value Data List.
		List<BillFactorValueData> billFactorValueDataList = billFactorVal.getBillFactorValueDataList();				
		if (billFactorValueDataList.isEmpty()) {
			addError(CustomMessageRepositoryMDC.na0060_NoBillFactorValueRetrieved(billFactor.getId().getTrimmedValue(), billDate.toString()));
		}
		
		return billFactorValueDataList.get(0).getBfValue();
	}
	
	//Start Add JVitug - B-32269.Issue3 - 2025-03-11
	/**
	 * Get the premise from this SA's CWR Premise ID Characteristic
	 * @return Premise ID
	 */
	private Premise getPremiseFromSACharacteristic() {
		PreparedStatement sql;
		StringBuilder stringSql = new StringBuilder();
		SQLResultRow result; 
		Premise returnValue = null;
		
		stringSql.append("SELECT ");
		stringSql.append(   "SAC.SRCH_CHAR_VAL ");
		stringSql.append("FROM ");
		stringSql.append(   "CI_SA_CHAR SAC ");
		stringSql.append("WHERE ");
		stringSql.append(   "SAC.SA_ID = :saID ");
		stringSql.append("AND ");
		stringSql.append(   "SAC.CHAR_TYPE_CD = :characteristicType ");
		
		sql = createPreparedStatement(stringSql.toString() , getClass().getName());
		sql.bindId("saID" , serviceAgreement.getId());
		sql.bindId("characteristicType", premiseCharType.getId());
		
		result = sql.firstRow();
		sql.close();
		
		if(notNull(result)){
			returnValue = result.getEntity("SRCH_CHAR_VAL" , Premise.class);
		}
		
		return returnValue;
	}
	
	/**
	 * Get the Premise from the Utility SA using the PA SIC Adjustment 
	 * created when starting SIC SAs, since part of the balance of an
	 * account's utility SA is passed to the SIC SA. 
	 * @return Premise ID
	 */
	private Premise getPremiseFromSICAdjustment() {
		PreparedStatement sql;
		StringBuilder stringSql = new StringBuilder();
		SQLResultRow result; 
		Premise returnValue = null;
		
		stringSql.append("SELECT ");
		stringSql.append(   "SA.CHAR_PREM_ID  ");
		stringSql.append("FROM ");
		stringSql.append(   "CI_SA SA, ");
		stringSql.append(   "CI_ADJ A1, ");
		stringSql.append(   "CI_ADJ A2 ");
		stringSql.append("WHERE ");
		stringSql.append(   "A1.SA_ID = :saID ");
		stringSql.append("AND ");
		//Start Change JVitug - B-32269.Issue2 - 2025-02-13
		//stringSql.append(   "A1.ADJ_TYPE_CD = :adjustmentType ");
		stringSql.append(   "A1.ADJ_TYPE_CD IN ( "+ encloseAdjustmentTypesInQuotes(paAdjustmentTypes) + " ) ");
		//End Change JVitug - B-32269.Issue2 - 2025-02-13
		//Start Delete JVitug - B-32269.Issue2 - 2025-02-13
		stringSql.append("AND ");
		stringSql.append(   "A1.ADJ_STATUS_FLG = :frozen ");
		//End Delete JVitug - B-32269.Issue2 - 2025-02-13
		stringSql.append("AND ");
		stringSql.append(   "A1.XFER_ADJ_ID = A2.ADJ_ID ");
		stringSql.append("AND ");
		stringSql.append(   "A2.ADJ_TYPE_CD = A1.ADJ_TYPE_CD ");
		stringSql.append("AND ");
		stringSql.append(   "A2.SA_ID <> A1.SA_ID ");
		stringSql.append("AND ");
		stringSql.append(   "A2.SA_ID = SA.SA_ID ");
		//Start Add JVitug - B-32269.Issue3 - 2025-03-11
		stringSql.append("AND ");
		stringSql.append(   "SA.CHAR_PREM_ID != ' '");
		//End Add JVitug - B-32269.Issue3 - 2025-03-11
		
		sql = createPreparedStatement(stringSql.toString() , getClass().getName());
		sql.bindId("saID" , serviceAgreement.getId());
		//Start Delete JVitug - B-32269.Issue2 - 2025-02-13
		//sql.bindId("adjustmentType", gpasicAdjustmentType.getId());
		//End Delete JVitug - B-32269.Issue2 - 2025-02-13
		sql.bindLookup("frozen" , AdjustmentStatusLookup.constants.FROZEN);
		
		result = sql.firstRow();
		sql.close();
		
		if(notNull(result)){
			returnValue = result.getEntity("CHAR_PREM_ID" , Premise.class);
		}
		
		return returnValue;
	}

	private String encloseAdjustmentTypesInQuotes(String adjListStr) {
		String stringInQuotes = "";
		
		//Separate the SA Types in an array
		String[] adjTypes = adjListStr.split(COMMA);
		
		for(int i = 0 ; i < adjTypes.length ; i ++) {
			
			if(isBlankOrNull(adjTypes[i])) {
				continue;
			}
			
			String adjType = adjTypes[i];
			
			//If this is the first instance, put quotes before and after the sa Type
			// string
			stringInQuotes = stringInQuotes + QUOTE + adjType + QUOTE;
			
			//If this is the last one, do not append a comma
			if(i < adjTypes.length - 1) {
				stringInQuotes = stringInQuotes + COMMA;
			} 
		}
		
		return stringInQuotes;
	}
	//End Add JVitug - B-32269.Issue3 - 2025-03-11
}
