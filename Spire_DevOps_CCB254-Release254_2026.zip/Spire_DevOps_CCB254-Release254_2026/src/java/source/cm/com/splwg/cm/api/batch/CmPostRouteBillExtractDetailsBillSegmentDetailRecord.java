/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 2024-07-30   DLampa     INC0037039. Updated field lengths to match 
 *                         the file layout extracted by the CM-BILEXTR 
 *                         algorithm 
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractDetailsBillSegmentDetailRecord 
		extends ColumnDelimitedRecord{	
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractDetailsBillSegmentDetailRecord() {
		super(20);
		
		this.setBPPrinterKey(" ");		
		this.setBPSortKey(" ");
		this.setBPMailingKey(" ");
		this.setStartDate(" ");
		this.setEndDate(" ");
		this.setClosingBsegSw(" ");
		this.setEstimateSw(" ");
		this.setBillCycleCd(" ");
		this.setServiceQuantityOverrideSw(" ");
		this.setItemOverrideSw(" ");
		this.setBsegStatFlg(" ");
		this.setCanRsnCd(" ");
		this.setCanRsnDescr(" ");
		this.setCurAmt(BigDecimal.ZERO, "0");
		this.setTotAmt(BigDecimal.ZERO, "0");
		this.setDhFlg(" ");
		this.setPayArrangeFlg(" ");
		this.setFiller();
	}
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * 
	 */
	public void setBPPrinterKey(String value) {		
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
	public void setBPSortKey(String value) {
		rightPadColumn(2, 184, truncateInput(value, 184));
	}
	public void setBPMailingKey(String value) {
		rightPadColumn(3, 15, truncateInput(value, 15));
	}	
	/*
	 * Bill Segment (List)
	 */
	public void setStartDate(String value) {
		rightPadColumn(4, 10, truncateInput(value, 10));
	}
	public void setEndDate(String value) {
		rightPadColumn(5, 10, truncateInput(value, 10));
	}	
	public void setClosingBsegSw(String value) {
		rightPadColumn(6, 1, truncateInput(value, 1));
	}
	public void setEstimateSw(String value) {
		rightPadColumn(7, 1, truncateInput(value, 1));
	}
	public void setBillCycleCd(String value) {
		rightPadColumn(8, 4, truncateInput(value, 4));
	}
	public void setServiceQuantityOverrideSw(String value) {
		rightPadColumn(9, 1, truncateInput(value, 1));
	}	
	public void setItemOverrideSw(String value) {
		rightPadColumn(10, 1, truncateInput(value, 1));
	}
	public void setBsegStatFlg(String value) {
		rightPadColumn(11, 2, truncateInput(value, 2));
	}
	public void setCanRsnCd(String value) {
		rightPadColumn(12, 4, truncateInput(value, 4));
	}
	public void setCanRsnDescr(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(13, 30, truncateInput(value, 30));
		rightPadColumn(13, 60, truncateInput(value, 60));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setCurAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(14, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(15, 15, truncateInput(value, 15));
	}
	public void setTotAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(16, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(17, 15, truncateInput(value, 15));
	}
	public void setDhFlg(String value) {
		rightPadColumn(18, 1, truncateInput(value, 1));
	}
	public void setPayArrangeFlg(String value) {
		rightPadColumn(19, 1, truncateInput(value, 1));
	}
	private void setFiller() {
		/*For some reason OLD version has this field to be only 3143 characters long; We are going to follow this instead of using base field length of 3346*/
		//rightPadColumn(20, 3346, " ");
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(20, 3143, " ");
		rightPadColumn(20, 3113, " ");
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
}