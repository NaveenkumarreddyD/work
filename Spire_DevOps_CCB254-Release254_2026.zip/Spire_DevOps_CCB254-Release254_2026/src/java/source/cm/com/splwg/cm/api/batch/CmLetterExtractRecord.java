/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Letter Extract Record                                                               
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                          
 * 2019-12-27  JVitug      SA-315895. Initial version                    
 *                                                                
 *******************************************************************************
 */

package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmLetterExtractRecord extends ColumnDelimitedRecord {
    // Letter Record
    private static final String LETTER_RECORD_PRINT_KEY = "1000";
    private static final String LETTER_RECORD_GRP = "10";
    private static final String BLANK = "  ";
    private static final String EMPTY_STR = "";
    
    public CmLetterExtractRecord() {
        super(15);  
        defaultPrintKey();
    }
    
    private void defaultPrintKey() {
        this.rightPadColumn(1, 4, formatString(LETTER_RECORD_PRINT_KEY, 4));
    }
    
    public void setSortKeyLetterTemplateCode(String letterTemplateCode) {
        this.rightPadColumn(2, 12, formatString(letterTemplateCode, 12));
    }
    
    public void setSortKeyCcId(String ccId) {
        this.rightPadColumn(3, 10, formatString(ccId, 10));
        setSortKeyCcRecordGroup();
        setSortKeyCAndCRecordGroup();
    }
    
    private void setSortKeyCcRecordGroup() {
        this.rightPadColumn(4, 2, LETTER_RECORD_GRP);
    }
    
    private void setSortKeyCAndCRecordGroup() {
        this.rightPadColumn(5, 2, BLANK);
    }
    
    public void setMailingKey(String mailingKey) {
        this.rightPadColumn(6, 12, formatString(mailingKey, 12));
        setFiller3Spaces();
    }
    
    private void setFiller3Spaces() {
        this.rightPadColumn(7, 3, " ");
    }
    
    public void setCcId(String ccId) {
        this.rightPadColumn(8, 10, formatString(ccId, 10));
    }
    
    public void setPersonId(String personId) {
        this.rightPadColumn(9, 10, formatString(personId, 10));
    }
    
    public void setCreateDate(String createDate) {
        this.rightPadColumn(10, 10, formatString(createDate, 10));
    }
    
    public void setCreateTime(String createTime) {
        this.rightPadColumn(11, 15, formatString(createTime, 15));
    }
    
    public void setCcClass(String ccClass) {
        this.rightPadColumn(12, 4, formatString(ccClass, 4));
    }
    
    public void setCcType(String ccType) {
        this.rightPadColumn(13, 12, formatString(ccType, 12));
    }
    
    public void setLetterTemplateCode(String letterTemplateCode) {
        this.rightPadColumn(14, 12, formatString(letterTemplateCode, 12));
    }
    
    public void setLetterDate(String letterDate) {
        this.rightPadColumn(15, 10, formatString(letterDate, 10));
    }
    
    /**
     * Returns "" if text is null;
     * Truncates text if length exceed fieldLength;
     * @param text String variable to be formatted
     * @param fieldLength Length of Field
     * @return formatted text
     */
    private String formatString(String text, int fieldLength) {
        if(text == null) {
            text = EMPTY_STR;
        }
        else {
            text = text.trim();
            if(text.length() > fieldLength) {
                text = text.substring(0, fieldLength);
            }
        }
        return text;
    }
}
