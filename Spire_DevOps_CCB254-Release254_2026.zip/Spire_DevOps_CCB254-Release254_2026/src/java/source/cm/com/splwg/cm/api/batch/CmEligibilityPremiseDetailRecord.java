/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Record Layout for Custom Eligibility Premise Detail Record
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-04-24   RDizon  NI0026.1 Initial Version.
 **************************************************************************/

package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmEligibilityPremiseDetailRecord
extends ColumnDelimitedRecord {

    public CmEligibilityPremiseDetailRecord() {
        super(7);
    }

    public void setPremiseId(String premiseId) {
        String string = "<PremiseID>" + premiseId + "</PremiseID>"+ "\n";
        this.rightPadColumn(1, string.length(), string);
    }
    
    public void setAddress1(String address1) {
        // String string = "<Address1>" + address1 + "</Address1>"+ "\n";
        String string = "<Address1>" + "<![CDATA[" + address1 + "]]>" + "</Address1>" + "\n";
        this.rightPadColumn(2, string.length(), string);
    }

    public void setAddress2(String address2) {
        // String string = "<Address2>" + address2 + "</Address2>"+ "\n";
        String string = "<Address2>" + "<![CDATA[" + address2 + "]]>" + "</Address2>"+ "\n";
        this.rightPadColumn(3, string.length(), string);
    }
    
    public void setCity(String city) {
        // String string = "<City>" + city + "</City>"+ "\n";
        String string = "<City>" + "<![CDATA[" + city + "]]>" + "</City>"+ "\n";
        this.rightPadColumn(4, string.length(), string);
    }
    
    public void setState(String state) {
        String string = "<State>" + state + "</State>"+ "\n";
        this.rightPadColumn(5, string.length(), string);
    }
    
    public void setPostalCode(String postal) {
        String string = "<PostalCode>" + postal + "</PostalCode>"+ "\n";
        this.rightPadColumn(6, string.length(), string);
    }
    
    public void setDiversionCase(String diversionCase) {
        String string = "<DiversionCase>" + diversionCase + "</DiversionCase>"+ "\n";
        this.rightPadColumn(7, string.length(), string);
    }
}
