/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 2024-07-30   DLampa     INC0037039. Updated field lengths to match 
 *                         the file layout extracted by the CM-BILEXTR 
 *                         algorithm 
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractDetailsBillSegmentSQRecord 
		extends ColumnDelimitedRecord{	
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractDetailsBillSegmentSQRecord() {
		super(10);
		
		// Initialize all fields as blank/spaces
		this.setBPPrinterKey(" ");		
		this.setBPSortKey(" ");
		this.setBPMailingKey(" ");
		this.setUomCd(" ");
		this.setTouCd(" ");
		this.setSqiCd(" ");
		this.setSqDecPos(" ");
		this.setBillSq(BigDecimal.ZERO, "0");
		this.setFiller();
	}
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * 
	 */
	public void setBPPrinterKey(String value) {		
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
	public void setBPSortKey(String value) {
		rightPadColumn(2, 184, truncateInput(value, 184));
	}
	public void setBPMailingKey(String value) {
		rightPadColumn(3, 15, truncateInput(value, 15));
	}	
	/*
	 * Bill Segment SQ (List)
	 */
	public void setUomCd(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(4, 4, truncateInput(value, 4));
		rightPadColumn(4, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setTouCd(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(5, 8, truncateInput(value, 5));
		rightPadColumn(5, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setSqiCd(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(6, 8, truncateInput(value, 8));
		rightPadColumn(6, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setSqDecPos(String value) {
		leftPadColumnWithZeros(7, 1, truncateInput(value, 1));
	}
	public void setBillSq(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(8, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(9, 18, truncateInput(value, 18));
	}
	private void setFiller() {
		//rightPadColumn(10, 3404, " ");
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(10, 3201, " ");
		rightPadColumn(10, 3131, " ");
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
}