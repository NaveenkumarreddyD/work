/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm will attempt to transfer balance to other applicable
 * SA's of the Customer, or to SA's that are related to the Customer
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *   
 * 2019-11-29   RDizon      CCB009.2. Initial version.
 * 2020-01-08   JTiozon     CCB009.2.Issue1. Added logic for decrypting SSN.
 * 2020-03-09   JVitug      CCB009.2.Issue2. Added logic to check if there 
 *                          exists a Do Not Transfer Char Type set as Y in the 
 *                          other account and its main Person
 * 2020-03-16   JVitug      CCB009.2_Issue3. Updated to handle encrypted
 *                          SSN numbers.                         
 * 2020-03-20   JVitug      CCB009.2_Issue4. Updated to not halt  
 *                          processing when an existing Overpayment SA 
 *                          from another person entity's account
 *                          is used as a target for a balance transfer 
 * 2020-03-24   JVitug      CCB009.2_Issue5. Updated the binding for the person 
 *                          name in the retrieveOtherCustomerAccounts() 
 *                          to not trim the Name being binded.  
 * 2020-03-26   JVitug      CCB009.2_Issue6 and CCB009.2_Issue7. 
 *                          Removed the else bracket after the 
 *                          processOverpaymentSA() method to allow 
 *                          transfer of credit balance based on rules
 *                          when a finalized overpayment SA is being processed.
 *                          Different Name and same SSN To Do will only
 *                          be raised if there is still credit balance
 *                          to be transferred.                    
 * 2020-04-14   JVitug      CCB009.2_Issue8. Updated to continue processing
 *                          if no To Do was raised if the SA being processsed
 *                          is an Overpayment SA             
 * 2020-04-22   JVitug      CCB009.2_Issue11. Updated SQL in retrieveOtherAccoutns
 *                          to not include accounts that has the DNT characteristic
 *                          whose effective date is less than or equal to
 *                          the Process Date 
 * 2020-04-23   JVitug      CCB009.2_Issue12. Changed criteria in 
 *                          retrieveOtherAccounts to get the max effective date
 *                          as of the process date    
 * 2020-05-04   JVitug      CCB009.Issue13. Updated transfer rules to now 
 *                          transfer to other SAs with different Write-off
 *                          Debt class that is in the Write-off Debt Classes
 *                          Algorithm Parameter
 * 2020-05-08   JVitug      CCB009.Issue14. Updated to use a specific transfer
 *                          adjustment type based on the account of the 
 *                          transfer SA             
 * 2020-08-26   JVitug      D-02142. Updated to not select overpayment
 *              BMarquez    SAs when selecting an eligible SA to transfer the 
 *                          remaining balance of an account. Transfer to
 *                          Overpayment SAs if they are found (even if they
 *                          were not created in this process). Only transfer
 *                          enough credit to SAs with debt to bring the
 *                          target SA's balance to zero.
 * 2020-12-07   JLumbre     CCB-017. Encryption updates.
 * 2021-02-17   JVitug      D-02215. Updated to only raise a Misapplied 
 *  						payment To do if the payment is 30 calendar days
 *  						old and has been made after the account's 
 *  						closing bill due date. Reworded the term 
 *  						'Misapplied' to "Payments after closure"
 *  2021-04-05   JVitug     D-02215. Updated to not continue processing when a 
 *  						misapplied payment is detected. 
 *  2021-04-22   JVitug     D-02215.Issue1. Updated to get the latest Bill
 *  						of the account that has a closing bill segment. 
 *  2021-05-06   BMarquez   D-02215.Issue2. Payments made before closure 
 *                          should be refunded automatically even if intact.
 * *************************************************************************                
 */
package com.splwg.cm.domain.admin.writeOffControl.algorithm.debtTransfer;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.encryption.DecryptedValue;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.BillStatusLookup;
import com.splwg.ccb.api.lookup.BillableChargeStatusLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.CustomerReadLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.api.lookup.NameTypeLookup;
import com.splwg.ccb.api.lookup.PaymentStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.idType.entity.IdType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.writeOffControl.algorithm.debtTransfer.DebtTransferAlgorithmSpot;
import com.splwg.ccb.domain.admin.writeOffDebtClass.entity.WriteOffDebtClass;
import com.splwg.ccb.domain.admin.writeOffDebtClass.entity.WriteOffDebtClass_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonCharacteristic;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonId;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonId_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonIds;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonName;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.ccb.domain.payment.payment.entity.Payment_Id;
import com.splwg.ccb.domain.security.common.FieldEncryptionDecryption;
import com.splwg.ccb.domain.security.data.FieldEncryptionDecryptionData;
import com.splwg.cm.api.lookup.CmInvalidSocialSecurityNumbersLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ServerMessage;

/**
 * @author RDizon
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = doNotTransferCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = doNotTransferCharacteristicValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = featureConfiguration, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = idType, name = sSNIdType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = overpaymentSATypeCode, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = role, name = toDoRole, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = transferAdjustmentTypeSameAccount, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = transferAdjustmentTypeDifferentAccount, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = transferBalanceSwitch, type = boolean)
 *            , @AlgorithmSoftParameter (name = writeOffDebtClasses, type = string)
 *            , @AlgorithmSoftParameter (name = transferCreditSwitch, required = true, type = boolean)})
 */

public class CmPersonLevelTransferAlgComp_Impl
        extends CmPersonLevelTransferAlgComp_Gen
        implements DebtTransferAlgorithmSpot {
    
    // Hard Parameters
    private Bool areSAsClosed = Bool.FALSE;
    private ServiceAgreement woServiceAgreement;
    private WriteOffDebtClass woDebtClass;
    private Money woDebtClassTotalBalance = Money.ZERO;

    // Soft Parameters
    private CharacteristicType parmDoNotTransferCharType;
    private String parmDoNotTransferCharValue;
    private FeatureConfiguration parmInvalidSSNsFeatConf;
    private IdType parmSSNIdType;
    private String parmOverpaymentSATypeCode;
    private ToDoType parmToDoType;
    private Role parmToDoRole;
    //Start Change JVitug - CCB009.Issue14 - 2020-05-08
    //private AdjustmentType parmAdjustmentType;
    private AdjustmentType parmAdjustmentTypeForSameAccount;
    private AdjustmentType parmAdjustmentTypeForDiffAccount;
    //End Change JVitug - CCb009.14 - 2020-05-08
    private Bool parmTransferBalanceSw;
    //Start Add JVitug - CCB009.Issue13 - 2020-05-04
    private String woDebtClasses;
    //End Add JVitug - CCB009.Issue13 - 2020-05-04

    // Work Variables
    private Account woAccount;
    private Money woSaBalance;
    private Person woPerson;
    // Start Delete - D-02142 - 2020-08-31
    //private Money transferAmount;
    // End Delete - D-02142 - 2020-08-31
    private CisDivision cisDivision;
    // Start Delete - D-02142 - 2020-08-31
    //private Bool accountIsActive = Bool.FALSE;
    //private ServiceAgreement xferServiceAgreement;
    // End Delete - D-02142 - 2020-08-31
    private Bool exitAlgorithm = Bool.FALSE;
    private Bool holdXferCreditSw = Bool.FALSE;
    private ServiceAgreement creditSA = null;
    private ServiceAgreement unbilledDebitSA = null;
    private Bool xferSAFound = Bool.FALSE;
    private String upperCasePrimaryName = "";
    private String ssn = "";
    //Start Add - JVitug - CCB009.2_Issue2 - 2020-03-16
    private String hashSSN = "";
    //End Add - JVitug - CCB009.2_Issue2 - 2020-03-16
    //Start Change JVitug - D-02215 - 2021-02-18
    //Start Add JVitug - CCB009.2_Issue8 -2020-04-14
    //Bool hasMisappliedPayment = Bool.FALSE;
    Bool hasPaymentsAfterClosure = Bool.FALSE;
    //End Add JVitug - CCB009.2_Issue8 - 2020-04-14
    //End Change JVitug - D-02215 - 2021-02-18
    // Start Delete - D-02142 - 2020-08-31
    //private Bool newOverpaymentSAcreated = Bool.FALSE;
    // End Delete - D-02142 - 2020-08-31
    //Start Add JVitug - CCB009.2_Issue13 - 2020-05-04
    String woDebtClassesInQuotes = "";
    //Start Add JVitug - D-02215 - 2021-02-17
    private Payment misappliedPayment;
    //End Add JVitug - D-02215 - 2021-02-17
    
    //Constants
    private final String COMMA = ",";
    //Start Add JVitug - D-02215 - 2021-02-17
    private final long THIRTY_DAYS = 30;
    //End Add JVitug - D-02215 - 2021-02-17
    //End Add JVitug - CCB009.2_Issue13 - 2020-05-04
    
    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        // Retrieve Soft Parameters
        parmDoNotTransferCharType = getDoNotTransferCharacteristicType();
        parmDoNotTransferCharValue = getDoNotTransferCharacteristicValue();
        parmInvalidSSNsFeatConf = getFeatureConfiguration();
        parmSSNIdType = getSSNIdType();
        parmOverpaymentSATypeCode = getOverpaymentSATypeCode();
        parmToDoType = getToDoType();
        parmToDoRole = getToDoRole();
        //Start Change JVitug - CCB009.2_Issue14 - 2020-05-08
        //parmAdjustmentType = getTransferAdjustmentType();
        parmAdjustmentTypeForSameAccount = getTransferAdjustmentTypeSameAccount();
        parmAdjustmentTypeForDiffAccount = getTransferAdjustmentTypeDifferentAccount();
        //End Change JVitug - CCB009.2_Issue14 - 2020-05-08
        parmTransferBalanceSw = getTransferBalanceSwitch();
        woDebtClasses = getWriteOffDebtClasses();

        // Validate the Do Not Transfer Characteristic Type
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(parmDoNotTransferCharType, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT);
        if(isNull(charEntityId.getEntity())){
            addError(CustomMessageRepositorySpireOne.CCB009_2_algParmInvalidCharacteristTypeForEntity(
                    getAlgorithmId().getTrimmedValue(),
                    getAlgorithm().getAlgorithmType().getParameterAt(0).fetchLanguageParameterLabel(),
                    parmDoNotTransferCharType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().fetchLanguageDescription().trim()));
        }
        charEntityId = new CharacteristicEntity_Id(parmDoNotTransferCharType, CharacteristicEntityLookup.constants.ACCOUNT);
        if(isNull(charEntityId.getEntity())){
            addError(CustomMessageRepositorySpireOne.CCB009_2_algParmInvalidCharacteristTypeForEntity(
                    getAlgorithmId().getTrimmedValue(),
                    getAlgorithm().getAlgorithmType().getParameterAt(0).fetchLanguageParameterLabel(),
                    parmDoNotTransferCharType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.ACCOUNT.getLookupValue().fetchLanguageDescription().trim()));
        }
        charEntityId = new CharacteristicEntity_Id(parmDoNotTransferCharType, CharacteristicEntityLookup.constants.PERSON);
        if(isNull(charEntityId.getEntity())){
            addError(CustomMessageRepositorySpireOne.CCB009_2_algParmInvalidCharacteristTypeForEntity(
                    getAlgorithmId().getTrimmedValue(),
                    getAlgorithm().getAlgorithmType().getParameterAt(0).fetchLanguageParameterLabel(),
                    parmDoNotTransferCharType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.PERSON.getLookupValue().fetchLanguageDescription().trim()));
        }

        // Validate the Do Not Transfer Characteristic Value
        if (parmDoNotTransferCharType.getCharacteristicType().isPredefinedValue()){
            CharacteristicValue_Id charValueId = new CharacteristicValue_Id(parmDoNotTransferCharType, parmDoNotTransferCharValue);

            if (isNull(charValueId.getEntity())) {
                addError(CustomMessageRepositorySpireOne.CCB009_2_algParmInvalidCharacteristValueForCharacteristicType(
                        getAlgorithmId().getTrimmedValue(),
                        getAlgorithm().getAlgorithmType().getParameterAt(0).fetchLanguageParameterLabel(),
                        parmDoNotTransferCharValue.trim(),
                        parmDoNotTransferCharType.getId().getTrimmedValue()));
            }
        }

        // Validate the To Do Role against the To Do Type
        if (notNull(parmToDoRole)) {
            ToDoTypeRole_Id toDoTypeRoleId = new ToDoTypeRole_Id(parmToDoType, parmToDoRole);

            if (isNull(toDoTypeRoleId.getEntity())) {
                addError(CustomMessageRepositorySpireOne.CCB009_2_algParmInvalidRoleForToDoType(
                        getAlgorithmId().getTrimmedValue(),
                        getAlgorithm().getAlgorithmType().getParameterAt(5).fetchLanguageParameterLabel(),
                        parmToDoRole.getId().getTrimmedValue(),
                        parmToDoType.getId().getTrimmedValue()));
            }
        } else {
            parmToDoRole = parmToDoType.getDefaultRole().fetchIdToDoRole();
        }
        
        // Default the Transfer Balance Switch if not provided
        if (isNull(parmTransferBalanceSw)){
            parmTransferBalanceSw = Bool.FALSE;
        }
        
        //Start Add JVitug - CCB009.Issue13 - 2020-05-04
        //Validate the write off debt classes in the writeOffDebtClasses algorithm parameter if 
        //supplied
        if(!isBlankOrNull(woDebtClasses)) {
        	String[] woDebtClassArray = woDebtClasses.split(COMMA);
        	for(int index = 0 ; index < woDebtClassArray.length ; index++) {
        		WriteOffDebtClass_Id woDebtClass = new WriteOffDebtClass_Id(woDebtClassArray[index]);
        		
        		if(isNull(woDebtClass.getEntity())) {
        			addError(CustomMessageRepositorySpireOne.CCB009_2_writeOffDebtClassIsInvalid(getAlgorithmId().getTrimmedValue(), 
        					getAlgorithm().getAlgorithmType().getParameterAt(9).fetchLanguageParameterLabel(), 
        					woDebtClassArray[index]));
        		}
        	}
        }
        
        //End Add JVitug - CCB009.Issue13 - 2020-05-04

    }

    @Override
    public Bool getAreServiceAgreementsClosed() {
        return areSAsClosed;
    }

    @Override
    public void setServiceAgreement(ServiceAgreement sa) {
        this.woServiceAgreement = sa;
    }

    @Override
    public void setWriteOffDebtClass(WriteOffDebtClass woDebtClass) {
        this.woDebtClass = woDebtClass;

    }

    @Override
    public void setWriteOffDebtClassTotalBalance(Money money) {
        this.woDebtClassTotalBalance = money;

    }

    @Override
    public void invoke() { 
        woAccount = woServiceAgreement.getAccount();
        woPerson = woAccount.getMainPerson(); 
        woSaBalance = woServiceAgreement.getFinancialBalances().getTotalAmount();
        // Start Delete - D-02142 - 2020-08-31
        //transferAmount = woServiceAgreement.getFinancialBalances().getTotalAmount();
        // End Delete - D-02142 - 2020-08-31
        
        // Start Add - D-02142 - 2020-08-31
        // End Add - D-02142 - 2020-08-31
        
        //Start Add JVitug - CCB009.2_Issue13 - 2020-05-04
        //Enclose each WO Debt class in the Algorithm WO debt class parameter 
        //in quotes if the WO Debt classes were supplied
        if(!isBlankOrNull(woDebtClasses)) {
        	woDebtClassesInQuotes = encloseWODebtClassInQuotes(woDebtClasses);
        }
        //End Add JVitug - CCB009.2_Issue13 - 2020-05-04
        
        // Validate the SA Type Code Parameter
        cisDivision = woServiceAgreement.getServiceAgreementType().getId().getDivision();
        ServiceAgreementType_Id overpaymentSATypeId = new ServiceAgreementType_Id(cisDivision, parmOverpaymentSATypeCode);
        if (isNull(overpaymentSATypeId.getEntity())){
            addError(CustomMessageRepositorySpireOne.CCB009_2_algParmInvalidSATypeForCISDivision(
                    getAlgorithmId().getTrimmedValue(),
                    getAlgorithm().getAlgorithmType().getParameterAt(3).fetchLanguageParameterLabel(),
                    parmOverpaymentSATypeCode,
                    cisDivision.getId().getTrimmedValue()));
        }
        
        if (hasExistingRefundToDoEntry().isTrue()){ 
            return;
        }
        
        // Start Add - D-02142 - 2020-08-31
        if (isAccountClosing(woAccount).isFalse()) {
            return;
        }
        
        // If the Overpayment SA credit was caused by a Payment that was never distributed to debt 
        // and that Payment was created after the last gas service SA closed 
        if (woSaBalance.isLessThan(Money.ZERO) 
                && woServiceAgreement.getServiceAgreementType().fetchIdSaType().trim().equalsIgnoreCase(parmOverpaymentSATypeCode.trim())
                && hasPaymentAfterClosure().isTrue()) {
            
            // Start Change - D-02215.Issue2 - 2021-05-06
            ////Start Add JVitug - D-02215 - 2021-02-17
            ////If there is a misapplied payment, we get the account's closing bill if there's any.
            //Bill closingBill = getClosingBill();
            //
            //long difference = getProcessDateTime().getDate().difference(misappliedPayment.getPaymentEvent().getPaymentDate())
            //		.getTotalDays();
            ////If the payment date is after the closing Bill's due date and
            ////the payment's age is 30 calendar days which include weekends, raise the To do
            //
            //if(notNull(closingBill) 
            //		&& misappliedPayment.getPaymentEvent().getPaymentDate().isAfter(closingBill.getDueDate())
            //		&& difference >= THIRTY_DAYS) {
            //	//End Add JVitug - D-02215 - 2021-02-17
            //	// Create To Do
            //	createToDo(CustomMessageRepositorySpireOne.CCB009_2_ToDoErrorMisappliedPayment(woSaBalance.getAmount().abs().toString()));
            //	//Start Delete JVitug - D-02215 - 2021-04-05
            //	//return;
            //	//End Delete JVitug - D-02215 - 2021-04-05
            //}
            ////Start Add JVitug - D-02215 - 2021-04-05
            ////if a lone payment is detected that is wholly distributed
            ////to the overpayment SA. Do not continue processing.
            //areSAsClosed = Bool.TRUE;
            //return;
            ////End Add JVitug - D-02215 - 2021-04-05

            // If the payment was made 30 or more calendar days ago
            if (getProcessDateTime().getDate().difference(misappliedPayment.getPaymentEvent().getPaymentDate()).getTotalDays() >= THIRTY_DAYS) {
                
                // Create To Do
                createToDo(CustomMessageRepositorySpireOne.CCB009_2_ToDoErrorMisappliedPayment(woSaBalance.getAmount().abs().toString()));
                
            }
            
            areSAsClosed = Bool.TRUE;
            return;
            
        }
        
        if (getTransferCreditSwitch().isFalse()) {
            return;
        }
        // End Add - D-02142 - 2020-08-31

        if (woSaBalance.isGreaterThan(Money.ZERO)){
            // Write-Off SA has Debit balance
            processDebitBalance();
            return;
        }
        else {
            // Start Delete - D-02142 - 2020-08-31
            //// Write-Off SA has Credit balance
            //if (woServiceAgreement.getServiceAgreementType().fetchIdSaType().trim().equalsIgnoreCase(parmOverpaymentSATypeCode.trim())){
            //    // Write-Off SA is an Overpayment SA
            //    processOverpaymentSA(); 
            //    //Start Delete Jvitug - CCB009.2_Issue6 and CCB009.2_Issue7 - 2020-03-26
            //    //return;
            //    //End Delete Jvitug - CCB009.2_Issue6 and CCB009.2_Issue7 - 2020-03-26
            //    
            //    //Start Add JVitug - CCB009.2_Issue8 - 2020-04-14
            //    //If flag hasMisappliedPayment is true, it means that a Misapplied Payment To do is raised
            //    //halt processing
            //    if(hasMisappliedPayment.isTrue()) {
            //        return;
            //    } 
            //    
            //    //If account is active and SA being processed is an overpayment SA, halt processing
            //    if(accountIsActive.isTrue()) {
            //        return;
            //    }
            //    //End Add JVitug - CCB009.2_Issue8 - 2020-04-14
            //}
            // End Delete - D-02142 - 2020-08-31
            //Start Delete Jvitug - CCB009.2_Issue6 and CCB009.2_Issue7 - 2020-03-26
            //else {
            //End Delete Jvitug - CCB009.2_Issue6 and CCB009.2_Issue7 - 2020-03-26
                // Write-Off SA is not an Overpayment SA 
            if (isAccountActive(woAccount).isTrue()) {
                processCreditBalanceForActiveAccount();
                if (exitAlgorithm.isTrue()){ 
                    return;    
                }
                //Start Delete JVitug - CCB009.2_Issue 8 -2020-04-14
                //return;
                //End Delete JVitug - CCB009.2_Issue 8 -2020-04-14
            }
            else {
                //Start Add JVitug - CCB009.2_Issue1 - 03-12-2020
                ServiceAgreementCharacteristic writeOffSADNT = woServiceAgreement.getEffectiveCharacteristic(parmDoNotTransferCharType);
                if (notNull(writeOffSADNT) && writeOffSADNT.getSearchCharacteristicValue().equalsIgnoreCase(parmDoNotTransferCharValue.trim())){
                    createToDo(CustomMessageRepositorySpireOne.CCB009_2_ToDoErrorServiceAgreementHasDoNotTransfer(
                            woSaBalance.getAmount().abs().toString(),
                            woServiceAgreement.getId().getTrimmedValue())); 
                    return;
                }
                //End Add JVitug - CCB009.2_Issue1 - 03-12-2020
                processCreditBalanceForInactiveAccount();
                if (exitAlgorithm.isTrue()){  
                    return;    
                }
                
                //Start Add JVitug - CCB009.2_Issue13 - 2020-05-04
                //If WO Debt classes parameter is provided, 
                //Attempt to transfer credit balance to other SAs of this account
                //that has a different WO Debt class from the Finalized SA
                //but has a WO Debt Class equal to the WO Debt Classes provided
                //in the algorithm parameter
                if(!isBlankOrNull(woDebtClasses)) {
                	transferCreditBalanceToSAWithDifferentWODebtClassOnSameAcct();
                	if (exitAlgorithm.isTrue()){
                        return;    
                    }
                }
                //End Add JVitug - CCB009.2_Issue13 - 2020-05-04
            }

            // Check if the Account has a Do Not Transfer Characteristic
            AccountCharacteristic accountDNTChar = woAccount.getEffectiveCharacteristic(parmDoNotTransferCharType);
            if (notNull(accountDNTChar) && accountDNTChar.getSearchCharacteristicValue().equalsIgnoreCase(parmDoNotTransferCharValue.trim())){
                createToDo(CustomMessageRepositorySpireOne.CCB009_2_ToDoErrorAccountHasDoNotTransfer(
                        woSaBalance.getAmount().abs().toString(),
                        woAccount.getId().getTrimmedValue())); 
                return;
            }
            
            processOtherAccounts();
            if (exitAlgorithm.isTrue()){
                return;    
            }

            // Check if the Main Person has a Do Not Transfer Characteristic
            PersonCharacteristic personDNTChar = woPerson.getEffectiveCharacteristic(parmDoNotTransferCharType);
            if (notNull(personDNTChar) && personDNTChar.getSearchCharacteristicValue().equalsIgnoreCase(parmDoNotTransferCharValue.trim())){
                createToDo(CustomMessageRepositorySpireOne.CCB009_2_ToDoErrorCustomerHasDoNotTransfer(
                        woSaBalance.getAmount().abs().toString(),
                        woPerson.getId().getTrimmedValue()));
                return;
            }
            
            if (checkCustomerSSN().isTrue()){
                createToDo(CustomMessageRepositorySpireOne.CCB009_2_ToDoErrorInvalidCustomerSSN(
                        woSaBalance.getAmount().abs().toString(),
                        woPerson.getId().getTrimmedValue()));
                return;
            }
            else {
                // Retrieve Person Primary Name
                upperCasePrimaryName = woPerson.getPersonPrimaryName().toUpperCase();
                if (upperCasePrimaryName.length() > 12){
                    upperCasePrimaryName = upperCasePrimaryName.substring(0,12);
                }
                // Retrieve Person SSN
                ListFilter<PersonIds> listFilterSsnId = woPerson.getIds().createFilter("WHERE this.id.idType = :ssnId", getClass().getName());
                listFilterSsnId.bindId("ssnId", parmSSNIdType.getId());

                if (listFilterSsnId.listSize() != 0){
                    ssn = ((PersonId) listFilterSsnId.firstRow()).getPersonIdNumber();
                    //Start Add JVitug - CCB009.2_Issue2 - 2020-03-16
                    hashSSN = ((PersonId) listFilterSsnId.firstRow()).getHashIdNumber();
                    //If Hash Id number is blank or null, set it as a blank string
                    if(isBlankOrNull(hashSSN)){
                        hashSSN = "";
                    }
                    //End Add JVitug - CCB009.2_Issue2 - 2020-03-16
                }
                processOtherCustomers();
                if (exitAlgorithm.isTrue()){
                    return;    
                }
                
                //Start Delete Jvitug - CCB009.2_Issue6 and CCB009.2_Issue7 - 2020-03-26
                //Bool sameSSNDiffNameExists = retrieveOtherCustomerSameSSNDifferentName();
                //if (sameSSNDiffNameExists.isTrue()){
                //    createToDo(CustomMessageRepositorySpireOne.CCB009_2_ToDoErrorCustomerSSNNameMismatch(
                //            woSaBalance.getAmount().abs().toString(),
                //            woPerson.getId().getTrimmedValue()));
                //    return;
                //}
                //End Delete Jvitug - CCB009.2_Issue6 and CCB009.2_Issue7 - 2020-03-26
            }
        }

        additionalProcessingForCreditBalance();
       //Start Delete Jvitug - CCB009.2_Issue6 and CCB009.2_Issue7 - 2020-03-26  
       //}
       //End Delete Jvitug - CCB009.2_Issue6 and CCB009.2_Issue7 - 2020-03-26 
    }

    /**
     * This method determines the processing for the WO SA's debit balance
     */
    private void processDebitBalance(){
    	//Start Change JVitug - D-02142 - 2020-08-26
        //List<ServiceAgreement> otherSAsList = retrieveOtherAccountSAs(
    	List<ServiceAgreement> otherSAsList =retrieveOtherNonOverpaymentAccountSAs(
    	//End Change JVitug - D-02142 - 2020-08-26
                woAccount,
                ServiceAgreementStatusLookup.constants.ACTIVE,
                ServiceAgreementStatusLookup.constants.PENDING_STOP);
        

    	// Start Change - D-02142 - 2020-08-31
        //if (otherSAsList.size() > 0){
        //    xferServiceAgreement = otherSAsList.get(0);
        //    transferDebitBalance(xferServiceAgreement);
        //    return;
        //}
    	if (!otherSAsList.isEmpty()) {
    	    createXferAdjustment(otherSAsList.get(0), woSaBalance);
    	}
        // End Change - D-02142 - 2020-08-31
        else {
            if (parmTransferBalanceSw.isTrue()){
                processStoppedSA(Bool.TRUE);
                
                if (exitAlgorithm.isTrue()){
                    areSAsClosed = Bool.TRUE;
                }
                return;
            }
            else {
                areSAsClosed = Bool.FALSE;
            }
        }
    }

    // Start Delete - D-02142 - 2020-08-31
    ///**
    // * This method performs processing for when the WO SA is an overpayment SA  
    // */
    //private void processOverpaymentSA(){
    //    accountIsActive = isAccountActive(woAccount);
    //    if (accountIsActive.isTrue()){
    //        areSAsClosed = Bool.TRUE;
    //        return;
    //    }
    //    else {
    //        //Start Change JVitug - CCB009.2_Issue8 - 2020-04-14
    //        //Bool hasMisappliedPayment = hasMisappliedPayment.isTrue()
    //        // Check for misapplied Payment on this SA
    //        hasMisappliedPayment = hasMisappliedPayment();
    //        //End Change JVitug - CCB009.2_Issue8 - 2020-04-14
    //
    //        if (hasMisappliedPayment.isTrue()){
    //            // Create To Do
    //            createToDo(CustomMessageRepositorySpireOne.CCB009_2_ToDoErrorMisappliedPayment(woSaBalance.getAmount().abs().toString()));
    //            areSAsClosed = Bool.TRUE;
    //            return;
    //        }
    //    }
    //}
    // End Delete - D-02142 - 2020-08-31
    
    /**
     * This method processes the credit balance for an active account 
     */    
    private void processCreditBalanceForActiveAccount(){
        ServiceAgreementCharacteristic saDNTChar = woServiceAgreement.getEffectiveCharacteristic(parmDoNotTransferCharType);
        if (notNull(saDNTChar) && saDNTChar.getSearchCharacteristicValue().equalsIgnoreCase(parmDoNotTransferCharValue.trim())){
            createToDo(CustomMessageRepositorySpireOne.CCB009_2_ToDoErrorServiceAgreementHasDoNotTransfer(
                    woSaBalance.getAmount().abs().toString(),
                    woServiceAgreement.getId().getTrimmedValue()));
            return;
        }
        
        ServiceAgreement overpaymentSA = retrieveOverpaymentSA(woAccount);
        if (notNull(overpaymentSA)){
            //Start Change JVitug - CCB009.2_Issue8 - 2020-04-14
            //transferCreditBalance(overpaymentSA);
            Bool stopLoop = transferCreditBalance(overpaymentSA);
            //End Add JVitug - CCB009.2_Issue8 - 2020-04-14
            //Start Add JVitug - CCB009.2_Issue8 -2020-04-14
            if(stopLoop.isTrue()) {
            //End Add JVitug - CCB009.2_Issue8 -2020-04-14
                exitAlgorithm = Bool.TRUE;
                return;
         //Start Add JVitug - CCB009.2_Issue8 -2020-04-14
            }
         //End Add JVitug - CCB009.2_Issue8 -2020-04-14
        }
        else {
            overpaymentSA = createOverpaymentSA(woAccount);
            // Start Change - D-02142 - 2020-08-31
            //newOverpaymentSAcreated = Bool.TRUE;
            //transferCreditBalance(overpaymentSA);
            //exitAlgorithm = Bool.TRUE;
            exitAlgorithm = transferCreditBalance(overpaymentSA);
            // End Change - D-02142 - 2020-08-31
            return;
        }
    }

    /**
     * This method processes the credit balance for an inactive account 
     */
    private void processCreditBalanceForInactiveAccount(){
        List<ServiceAgreement> otherSAsList = retrieveOtherAccountSAs(
                woAccount,
                ServiceAgreementStatusLookup.constants.ACTIVE,
                ServiceAgreementStatusLookup.constants.PENDING_STOP,
                ServiceAgreementStatusLookup.constants.STOPPED,
                ServiceAgreementStatusLookup.constants.REACTIVATED);
        
        for (ServiceAgreement otherSA : otherSAsList) {
            ServiceAgreementCharacteristic saDNTChar = otherSA.getEffectiveCharacteristic(parmDoNotTransferCharType);
            if (isNull(saDNTChar)){
                
                Bool stopLoop = transferCreditBalance(otherSA);
                if (stopLoop.isTrue()) {
                    exitAlgorithm = Bool.TRUE;
                    break;
                }
            }
        }
    }
    
    /**
     * This method performs processing for all other accounts 
     */
    private void processOtherAccounts(){
        List<Account> otherAccountsList = retrieveOtherAccounts();
        for (Account otherAccount : otherAccountsList){
            if(isAccountActive(otherAccount).isTrue()){
                
                ServiceAgreement overpaymentSA = retrieveOverpaymentSA(otherAccount);
                if (notNull(overpaymentSA)){
                    //Start Change JVitug - CCB009.2_Issue 8 - 2020-04-14
                    //transferCreditBalance(overpaymentSA);
                    Bool stopLoop = transferCreditBalance(overpaymentSA);
                    //End Change JVitug - CCB009.2_Issue 8 - 2020-04-14
                    //Start Add JVitug - CCB009.2_Issue 8 - 2020-04-14
                    if(stopLoop.isTrue()) {
                    //End Add JVitug - CCB009.2_Issue 8 - 2020-04-14
                        exitAlgorithm = Bool.TRUE;
                        return;
                    //Start Add JVitug - CCB009.2_Issue 8 - 2020-04-14
                    }
                    //End Add JVitug - CCB009.2_Issue 8 - 2020-04-14
                }
                else {
                    overpaymentSA = createOverpaymentSA(otherAccount);
                    // Start Delete - D-02142 - 2020-08-31
                    //newOverpaymentSAcreated = Bool.TRUE;
                    //transferCreditBalance(overpaymentSA);
                    //exitAlgorithm = Bool.TRUE;
                    exitAlgorithm = transferCreditBalance(overpaymentSA);
                    // End Delete - D-02142 - 2020-08-31
                    return;
                }
            }
            else {
                // Search the other SAs of this Account
                List<ServiceAgreement> otherSAsList = retrieveOtherAccountSAs(
                        otherAccount,
                        ServiceAgreementStatusLookup.constants.ACTIVE,
                        ServiceAgreementStatusLookup.constants.PENDING_STOP,
                        ServiceAgreementStatusLookup.constants.STOPPED,
                        ServiceAgreementStatusLookup.constants.REACTIVATED);
                
                for (ServiceAgreement otherSA : otherSAsList) {
                    ServiceAgreementCharacteristic saDNTChar = otherSA.getEffectiveCharacteristic(parmDoNotTransferCharType);
                    if (isNull(saDNTChar)){
                        Bool stopLoop = transferCreditBalance(otherSA);
                        if (stopLoop.isTrue()) {
                            exitAlgorithm = Bool.TRUE;
                            break;
                        }
                    }
                }
                
            }
            
            //Start Add JVitug - CCB009.2_Issue13 - 2020-05-04
            if(!isBlankOrNull(woDebtClasses)) {
            	transferCreditBalanceToOtherAccountSADiffWO(otherAccount);
            	if (exitAlgorithm.isTrue()){
                    return;    
                }
            }
            //End Add JVitug - CCB009.2_Issue13 - 2020-05-04
        }
    }
    
    /**
     * This method performs processing for other customer accounts 
     */
    private void processOtherCustomers(){
    	//Retrieve other accounts of other persons having the same SSN and name to the 
    	//Person linked to the Finalized SA
        List<Account> otherCustomerAccountsList = retrieveOtherCustomerAccounts();
        for (Account otherCustomerAccount : otherCustomerAccountsList){
            //Start Add JVitug - CCB009.2_Issue1 - 03-10-2020
            PersonCharacteristic doesPersonHaveDNT = otherCustomerAccount.getMainPerson().getEffectiveCharacteristic(parmDoNotTransferCharType);
            AccountCharacteristic doesAccountHaveDNT = otherCustomerAccount.getEffectiveCharacteristic(parmDoNotTransferCharType);

            //If the person or the Account has the Do Not Transfer Characteristic Type but
            //its characteristic value is N, treat it as it's null
            if(notNull(doesPersonHaveDNT) && doesPersonHaveDNT.getSearchCharacteristicValue().trim().compareToIgnoreCase(parmDoNotTransferCharValue) != 0){
                doesPersonHaveDNT = null;
            }
            
            if(notNull(doesAccountHaveDNT) && doesAccountHaveDNT.getSearchCharacteristicValue().trim().compareToIgnoreCase(parmDoNotTransferCharValue) != 0){
                doesAccountHaveDNT = null;
            }
            
            if(isNull(doesPersonHaveDNT) && isNull(doesAccountHaveDNT)){
            //End Add JVitug - CCB009.2_Issue1 - 03-10-2020
                if (isAccountActive(otherCustomerAccount).isTrue()){
                    ServiceAgreement overpaymentSA = retrieveOverpaymentSA(otherCustomerAccount);
                    if (notNull(overpaymentSA)){
                        //Start Change - JVitug - CCB009.2_Issue3 - 2020-03-20
                        //transferCreditBalance(overpaymentSA);
                        Bool stopLoop = transferCreditBalance(overpaymentSA);
                        //End Change - JVitug - CCB009.2_Issue3 - 2020-03-20
                        //Start Add JVitug - CCB009.2_Issue3 - 2020-03-20
                        if(stopLoop.isTrue()) {
                        //End Add JVitug - CCB009.2_Issue3 - 2020-03-20
                            exitAlgorithm = Bool.TRUE;
                            return;
                        //Start Add JVitug - CCB009.2_Issue3 - 2020-03-20
                        }
                        //End Add JVitug - CCB009.2_Issue3 - 2020-03-20
                    }
                    else {
                        overpaymentSA = createOverpaymentSA(otherCustomerAccount);
                        // Start Change - D-02142 - 2020-08-31
                        //newOverpaymentSAcreated = Bool.TRUE;
                        //transferCreditBalance(overpaymentSA);
                        //exitAlgorithm = Bool.TRUE;
                        exitAlgorithm = transferCreditBalance(overpaymentSA);;
                        // End Change - D-02142 - 2020-08-31
                        return;
                    }
                }
                else{
                    // Search the other SAs of this Account
                    List<ServiceAgreement> otherSAsList = retrieveOtherAccountSAs(
                            otherCustomerAccount,
                            ServiceAgreementStatusLookup.constants.ACTIVE,
                            ServiceAgreementStatusLookup.constants.PENDING_STOP,
                            ServiceAgreementStatusLookup.constants.STOPPED,
                            ServiceAgreementStatusLookup.constants.REACTIVATED);
                    
                    for (ServiceAgreement otherSA : otherSAsList) {
                        ServiceAgreementCharacteristic saDNTChar = otherSA.getEffectiveCharacteristic(parmDoNotTransferCharType);
                        if (isNull(saDNTChar)){
                            Bool stopLoop = transferCreditBalance(otherSA);
                            if (stopLoop.isTrue()) {
                                exitAlgorithm = Bool.TRUE;
                                break;
                            }
                        }
                    }
                    if (exitAlgorithm.isTrue()){
                        exitAlgorithm = Bool.TRUE;
                        break;
                    }
                }
                //Start Add JVitug - CCB009.2_Issue13 - 2020-05-04
                //If the Write-off Debt Classes are provided, attempt to transfer the credit balance
                //to the other person's account having the same name and SSN
                if(!isBlankOrNull(woDebtClasses)) {
                	transferCreditBalanceToOtherAccountSADiffWO(otherCustomerAccount);
                }
                //End Add JVitug - CCB009.2_Issue13 - 2020-05-04
           //Start Add JVitug - CCB009.2_Issue1 - 03-10-2020
            }
            //End Add JVitug - CCB009.2_Issue1 - 03-10-2020
        }
    }

    /**
     * This method creates the transfer adjustment between the appropriate SAs 
     * @param xferSA
     */
    // Start Change - D-02142 - 2020-08-31
    //private void createXferAdjustment(ServiceAgreement xferSA) {
    private void createXferAdjustment(ServiceAgreement xferSA, Money amount) {
    // End Change - D-02142 - 2020-08-31
        CreateFrozenAdjustmentData data = CreateFrozenAdjustmentData.Factory.newInstance();
        data.setServiceAgreement(woServiceAgreement);
        data.setTransferServiceAgreement(xferSA);
        //Start Change JVitug - CCB009.2_Issue14 - 2020-05-08
        //data.setAdjustmentType(parmAdjustmentType);
        //If the account of the transfer SA is equal to the Account
        //Linked to the write-off being processed, use the adjustment type
        //for the same accounts. If they're different, use the 
        //adjustment type for different accounts
        if(xferSA.getAccount().getId().compareTo(woAccount.getId()) == 0) {
        	data.setAdjustmentType(parmAdjustmentTypeForSameAccount);
        } else {
        	data.setAdjustmentType(parmAdjustmentTypeForDiffAccount);
        }
        //End Change JVitug - CCB009.2_Issue14 - 2020-05-08
        
        // Start Change - D-02142 - 2020-08-31
        //data.setAdjustmentAmount(transferAmount);
        data.setAdjustmentAmount(amount);
        // End Change - D-02142 - 2020-08-31
        data.setAllowZeroAmount(Bool.FALSE);
        woServiceAgreement.createFrozenAdjustment(data);
        
        // Start Change - D-02142 - 2020-08-31
        //areSAsClosed = Bool.TRUE;
        woSaBalance = woSaBalance.subtract(amount);
        if (woSaBalance.isZero()) {
            areSAsClosed = Bool.TRUE;
        }
        // End Change - D-02142 - 2020-08-31
    }

    // Start Delete - D-02142 - 2020-08-31
    ///**
    // * This method transfers the debit balance to the appropriate SA 
    // * @param xferSA
    // * @return Bool
    // */    
    //private Bool transferDebitBalance(ServiceAgreement xferSA){
    //    Bool stopLoop = Bool.FALSE;
    //
    //    createXferAdjustment(xferSA);
    //    stopLoop = Bool.TRUE;
    //
    //    return stopLoop;
    //}
    // End Delete - D-02142 - 2020-08-31

    /**
     * This method transfers the credit balance to the appropriate SA 
     * @param xferSA
     * @return Bool
     */
    private Bool transferCreditBalance(ServiceAgreement xferSA) {
        Bool stopLoop = Bool.FALSE;
        Money xferSaBalance = xferSA.getFinancialBalances().getTotalAmount();
        
        if (xferSaBalance.isGreaterThan(Money.ZERO)) { 
            // Start Change - D-02142 - 2020-08-31
            //// XFER-SA has Debit Balance
            //if (!xferSA.getStatus().isStopped() && !xferSA.getStatus().isReactivated()
            //        && !xferSA.getStatus().isClosed() && !xferSA.getStatus().isCanceled()) {
            //    createXferAdjustment(xferSA);
            //    xferSAFound = Bool.TRUE;
            //    woSaBalance = Money.ZERO;
            //    stopLoop = Bool.TRUE;
            //}
            //else {
            //    // If XFER-SA is inactive or about to be inactive, add the balances of the WO-SA and XFER-SA
            //    woSaBalance = woSaBalance.add(xferSaBalance);
            //    if (woSaBalance.isGreaterThanOrEqual(Money.ZERO)) {
            //        // If total XFER-AMT is a debit, transfer credit to XFER-SA
            //        createXferAdjustment(xferSA);
            //        xferSAFound = Bool.TRUE;
            //        stopLoop = Bool.TRUE;
            //    }
            //    else {
            //        // Since total XFER-AMT is a credit, transfer credit to XFER-SA,
            //        // Create an Adjustment to reduce XFER-SA Balance to ZERO
            //        transferAmount = xferSaBalance.negate();
            //        createXferAdjustment(xferSA);
            //        xferSAFound = Bool.TRUE;
            //        transferAmount = woSaBalance;
            //    }
            //
            //    if (isNull(unbilledDebitSA) && xferSA.getStatus().isStopped()) {
            //        if (isSAFinalBilled(xferSA).isFalse()) {
            //            unbilledDebitSA = xferSA;
            //        }
            //    }
            //}
            
            if (xferSaBalance.isGreaterThan(woSaBalance.negate())) {
                // Transfer full credit to Stopped SA
                createXferAdjustment(xferSA, woSaBalance);
                stopLoop = Bool.TRUE;
            } else {
                // Only transfer enough to fulfill debt on other SA
                createXferAdjustment(xferSA, xferSaBalance.negate());
            }
            
            if (isNull(unbilledDebitSA) && xferSA.getStatus().isStopped()) {
                if (isSAFinalBilled(xferSA).isFalse()) {
                    unbilledDebitSA = xferSA;
                }
            }
            // End Change - D-02142 - 2020-08-31
        }
        else {
            
            // Start Change - D-02142 - 2020-08-31
            //if (newOverpaymentSAcreated.isTrue()){
            //    createXferAdjustment(xferSA);
            //    xferSAFound = Bool.TRUE;
            //    woSaBalance = Money.ZERO;
            //    stopLoop = Bool.TRUE;
            //}
            if (xferSA.getServiceAgreementType().fetchIdSaType().trim().equals(parmOverpaymentSATypeCode.trim())) {
                createXferAdjustment(xferSA, woSaBalance);
                xferSAFound = Bool.TRUE;
                stopLoop = Bool.TRUE;
            }
            // End Change - D-02142 - 2020-08-31
            // XFER-SA has Credit Balance
            if (holdXferCreditSw.isFalse()) {
                holdXferCreditSw = Bool.TRUE;
                // Set XFER SA as Credit SA
                creditSA = xferSA;
            }
        }
        
        return stopLoop;
    }
    
    /**
     * This method performs all other processing for the credit balance 
     */
    private void additionalProcessingForCreditBalance(){
        
        if (xferSAFound.isFalse() && parmTransferBalanceSw.isTrue()){
            processStoppedSA(Bool.FALSE);
        }
        
        // Transfer remaining credit balance to the Credit SA
        if (holdXferCreditSw.isTrue() && woSaBalance.isLessThan(Money.ZERO)) {
            // Start Change - D-02142 - 2020-08-31
            //createXferAdjustment(creditSA);
            //woSaBalance = Money.ZERO;
            createXferAdjustment(creditSA, woSaBalance);
            // Start Change - D-02142 - 2020-08-31
        }
        
        // If there is remaining credit and there's no credit SA to transfer to, and there is a stopped unbilled debit SA, transfer the remaining credit to this debit SA
        if (holdXferCreditSw.isFalse() && woSaBalance.isLessThan(Money.ZERO) && notNull(unbilledDebitSA)) {
            // Start Change - D-02142 - 2020-08-31
            //createXferAdjustment(unbilledDebitSA);
            //woSaBalance = Money.ZERO;
            createXferAdjustment(unbilledDebitSA, woSaBalance);
            // Start Change - D-02142 - 2020-08-31
        }
        
      //Start Add Jvitug - CCB009.2_Issue6 and CCB009.2_Issue7 - 2020-03-26  
        //If there is still remaining credit , check if there is another person
        // with different name but same SSN with the finalized account
        if(woSaBalance.isLessThan(Money.ZERO)) {
            Bool sameSSNDiffNameExists = retrieveOtherCustomerSameSSNDifferentName();
            if (sameSSNDiffNameExists.isTrue()){
                createToDo(CustomMessageRepositorySpireOne.CCB009_2_ToDoErrorCustomerSSNNameMismatch(
                        woSaBalance.getAmount().abs().toString(),
                        woPerson.getId().getTrimmedValue()));
                return;
            }
        }
        //End Add Jvitug - CCB009.2_Issue6 and CCB009.2_Issue7 - 2020-03-26  
        
        // If a credit was transferred, there may be credit remaining for refund. Reset the 'SAs closed' switch
        if (woSaBalance.isLessThan(Money.ZERO)) {
            areSAsClosed = Bool.FALSE;
        }
    }

    /**
     * This method performs processing for stopped SAs 
     * @param Bool
     */
    private void processStoppedSA(Bool isDebitFlag) {
    	//Start Change JVitug - D-02142 - 2020-08-26
    	//If Write-off Account's balance is in debit, do not include the overpayment SA from the SAs to be selected.
    	//List<ServiceAgreement> stoppedSAsList = retrieveOtherAccountSAs(woAccount, ServiceAgreementStatusLookup.constants.STOPPED);
    	List<ServiceAgreement> stoppedSAsList;
    	if(isDebitFlag.isTrue()) {
    		stoppedSAsList = retrieveOtherNonOverpaymentAccountSAs(woAccount, ServiceAgreementStatusLookup.constants.STOPPED);
    	} else {
    		stoppedSAsList = retrieveOtherAccountSAs(woAccount, ServiceAgreementStatusLookup.constants.STOPPED);
    	}
    	//End Change JVitug - D-02142 - 2020-08-26
    	
        for (ServiceAgreement stoppedSA : stoppedSAsList) {
            ServiceAgreementType stoppedSaType = stoppedSA.getServiceAgreementType();
            if (stoppedSA.determineEligibilityForWriteOff(stoppedSaType.getSpecialRole(),
                                                stoppedSaType.getIsSubServiceAgreement(),
                                                stoppedSaType.getIsEligibleForBilling()).isFalse()) {
                Bool stopLoop = Bool.FALSE;
                if (isDebitFlag.isTrue()){
                    // Start Change - D-02142 - 2020-08-31
                    //stopLoop = transferDebitBalance(stoppedSA);
                    createXferAdjustment(stoppedSA, woSaBalance);
                    exitAlgorithm = Bool.TRUE;
                    return;
                    // End Change - D-02142 - 2020-08-31
                }
                else{
                    stopLoop = transferCreditBalance(stoppedSA);
                }
                
                if (stopLoop.isTrue()) {
                    exitAlgorithm = Bool.TRUE;
                    break;
                }
            }
        }
    }

    /**
     * This method creates the appropriate To Do Entry 
     * @param serverMessage
     */
    private void createToDo(ServerMessage serverMessage){ 
        // Create the To Do
        ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
        ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();
        toDoEntryDTO.setCreationDateTime(getProcessDateTime());
        toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
        toDoEntryDTO.setToDoTypeId(parmToDoType.getId());
        toDoEntryDTO.setToDoRoleId(parmToDoRole.getId());
        toDoEntryDTO.setMessageId(serverMessage.getMessageId());
        toDoCreator.setToDoDTO(toDoEntryDTO);


        // Add Drill Key
        Iterator<ToDoDrillKeyType> itrToDoDrillKeyType = parmToDoType.getId().getEntity().getDrillKeyTypes().iterator();
        while (itrToDoDrillKeyType.hasNext()){
            ToDoDrillKeyType drillKeyType = itrToDoDrillKeyType.next();
            toDoCreator.addDrillKeyValue(drillKeyType, woServiceAgreement.getId().getTrimmedValue());
        }

        // Add Sort Keys
        for (ToDoSortKeyType sortKeyType : parmToDoType.getSortKeyTypes()) {
            BigInteger sequence = sortKeyType.fetchIdSequence();
            // Sort Key - Credit Refund Amount
            if (sequence.compareTo(BigInteger.valueOf(10)) == 0) { 
                toDoCreator.addSortKeyValue(sortKeyType, woSaBalance.getAmount().abs().toString());
            }

            // Sort Key - Error Message Number
            if (sequence.compareTo(BigInteger.valueOf(20)) == 0) { 
                toDoCreator.addSortKeyValue(sortKeyType, serverMessage.getNumber().toString());
            }
        }

        // Add Message Parameters
        for (int index = 0; index < serverMessage.getMessageParameters().getSize(); index++){
            toDoCreator.addMessageParameter(serverMessage.getMessageParameters().getParameters().get(index).toString());
        }

        // Create the To Do Entry
        toDoCreator.create(); 
    }

    /**
     * This method creates an overpayment SA for the account 
     * @param account
     * @return ServiceAgreement_DTO
     */
    private ServiceAgreement createOverpaymentSA(Account account){
        ServiceAgreementType_Id overpaymentSaTypeId = new ServiceAgreementType_Id(account.getDivisionId(), parmOverpaymentSATypeCode);
        ServiceAgreement_DTO overpaymentSaDto = new ServiceAgreement_DTO();
        overpaymentSaDto.setAccountId(account.getId());
        overpaymentSaDto.setServiceAgreementTypeId(overpaymentSaTypeId);
        overpaymentSaDto.setStatus(ServiceAgreementStatusLookup.constants.PENDING_START);
        overpaymentSaDto.setStartDate(getProcessDateTime().getDate());
        overpaymentSaDto.setCustomerRead(CustomerReadLookup.constants.NO);
        
        return overpaymentSaDto.newEntity();
    }
    
    private String encloseSATypesInQuotes(ServiceAgreementStatusLookup... saStatusList){
        StringBuilder saStatuses = new StringBuilder();

        saStatuses.append("'");

        for (int i = 0; i < saStatusList.length; i++){
            saStatuses.append(saStatusList[i] + "'");
            if (i < saStatusList.length - 1) {
                saStatuses.append(",'");
            }
        }
        return saStatuses.toString();
    }

    /**
     * This method checks if the SA is final-billed 
     * @param sa
     * @return Bool
     */
    private Bool isSAFinalBilled(ServiceAgreement sa) {
        Bool isFinalBill = Bool.FALSE;
        if (sa.getServiceAgreementType().getSpecialRole().isBillableCharge()) {
            Query query = createQuery("FROM BillableCharge bc "
                    + "WHERE bc.serviceAgreement.id = :saId "
                    + "AND bc.billableChargeStatus = :stat "
                    + "AND NOT EXISTS(SELECT bs.id FROM BillSegment bs, BillSegmentCalculationHeader bch "
                    + "WHERE bs.serviceAgreement.id = :saId "
                    + "AND bs.id = bch.id.billSegment.id "
                    + "AND bch.billableChargeId = bc.id "
                    + "AND bs.billSegmentStatus = :bsegStat) "
                    , "isSAFinalBilled");

            query.bindId("saId", sa.getId());
            query.bindLookup("stat", BillableChargeStatusLookup.constants.BILLABLE);
            query.bindLookup("bsegStat", BillSegmentStatusLookup.constants.FROZEN);

            if (query.listSize() == 0) {
                isFinalBill = Bool.TRUE;
            }
        }
        else {
            Query query = createQuery("FROM BillSegment bs "
                    + "WHERE bs.serviceAgreement.id = :saId "
                    + "AND bs.endDate = :endDate "
                    + "AND  bs.billSegmentStatus = :bsegStat "
                    + "AND bs.isClosingBillSegment = :true "
                    , "isSAFinalBilled");

            query.bindId("saId", sa.getId());
            query.bindDate("endDate", sa.getEndDate());
            query.bindLookup("bsegStat", BillSegmentStatusLookup.constants.FROZEN);
            query.bindBoolean("true", Bool.TRUE);

            if (query.listSize() > 0) {
                isFinalBill = Bool.TRUE;
            }
        }
        return isFinalBill;
    }

    /**
     * This method checks if there are other active SAs for the account 
     * @param account
     * @return Bool
     */
    private Bool isAccountActive(Account account){
        Query<ServiceAgreement> query = createQuery("FROM ServiceAgreement SA "
                + "WHERE SA.status IN (:activeStatus, :pendingStopStatus) "
                + "AND SA.account = :account "
                + "AND SA.id <> :saId ",
                "isAccountActive");
        query.bindEntity("account", account);
        query.bindId("saId", woServiceAgreement.getId());
        query.bindLookup("activeStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
        query.bindLookup("pendingStopStatus", ServiceAgreementStatusLookup.constants.PENDING_STOP);

        query.addResult("sa", "SA");
        if (notNull(query.firstRow())){
            return Bool.TRUE;
        }
        else {
            return Bool.FALSE;
        }
    }
    
    // Start Add - D-02142 - 2020-08-31
    /**
     * This method checks if there are other SAs accepting credit for the account 
     * @param account
     * @return Bool
     */
    private Bool isAccountClosing(Account account){
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FROM ServiceAgreement SA, ServiceAgreementType SAT ");
        stringBuilder.append("WHERE SA.status NOT IN (:closedStatus, :cancelledStatus) ");
        stringBuilder.append("AND SA.account = :account ");
        stringBuilder.append("AND SA.serviceAgreementType.id.division = SAT.id.division  ");
        stringBuilder.append("AND SA.serviceAgreementType.id.saType = SAT.id.saType ");
        stringBuilder.append("AND SAT.writeOffDebtClass.id <> :woDebtClassCode ");
        Query<ServiceAgreement> query = createQuery(stringBuilder.toString(), "isAccountActive");
        query.bindEntity("account", account);
        query.bindId("woDebtClassCode", woDebtClass.getId());
        query.bindLookup("closedStatus", ServiceAgreementStatusLookup.constants.CLOSED);
        query.bindLookup("cancelledStatus", ServiceAgreementStatusLookup.constants.CANCELED);

        query.addResult("sa", "SA");
        if (notNull(query.firstRow())){
            return Bool.FALSE;
        }
        return Bool.TRUE;
    }
    // End Add - D-02142 - 2020-08-31

    /**
     * This method retrieves other SAs of the account 
     * @param account
     * @param saStatList
     * @return saList
     */
    private List<ServiceAgreement> retrieveOtherAccountSAs(Account account, ServiceAgreementStatusLookup... saStatList) {
        List<ServiceAgreement> saList = new ArrayList<ServiceAgreement>();

        String saStatusesInQuotes = encloseSATypesInQuotes(saStatList);

        Query<QueryResultRow> query = createQuery("FROM ServiceAgreement SA, ServiceAgreementType SAT "
                + "WHERE SA.status IN (" + saStatusesInQuotes + ") "
                + "AND SA.account.id = :accountId "
                + "AND SA.serviceAgreementType.id.division = SAT.id.division  "
                + "AND SA.serviceAgreementType.id.saType = SAT.id.saType "
                + "AND SAT.writeOffDebtClass.id = :woDebtClassCode "
                + "AND SA.id <> :saId "
                
                + "AND SAT.paymentPriority IS NOT NULL  ",
                "retrieveOtherAccountSAs");

        query.bindId("accountId", account.getId());
        query.bindId("woDebtClassCode", woDebtClass.getId());
        query.bindId("saId", woServiceAgreement.getId());
        
        query.addResult("sa", "SA");
        query.addResult("paymentPriority", "SAT.paymentPriority");
        query.orderBy("paymentPriority");

        for(QueryResultRow resultRow : query.list()) {
            saList.add(resultRow.getEntity("sa", ServiceAgreement.class));
        }

        return saList;
    }
    
    //Start Add JVitug - D-02142 - 2020-08-26
    /**
     * This method retrieves other non-overpayment SAs of the account 
     * @param account
     * @param saStatList
     * @return saList
     */
    private List<ServiceAgreement> retrieveOtherNonOverpaymentAccountSAs(Account account, ServiceAgreementStatusLookup... saStatList) {
        List<ServiceAgreement> saList = new ArrayList<ServiceAgreement>();

        String saStatusesInQuotes = encloseSATypesInQuotes(saStatList);

        Query<QueryResultRow> query = createQuery("FROM ServiceAgreement SA, ServiceAgreementType SAT "
                + "WHERE SA.status IN (" + saStatusesInQuotes + ") "
                + "AND SA.account.id = :accountId "
                + "AND SA.serviceAgreementType.id.division = SAT.id.division  "
                + "AND SA.serviceAgreementType.id.saType = SAT.id.saType "
                + "AND SAT.id.saType <> :overpaymentSA "
                + "AND SAT.writeOffDebtClass.id = :woDebtClassCode "
                + "AND SA.id <> :saId "
                + "AND SAT.paymentPriority IS NOT NULL  ",
                "retrieveOtherAccountSAs");

        query.bindId("accountId", account.getId());
        query.bindId("woDebtClassCode", woDebtClass.getId());
        query.bindId("saId", woServiceAgreement.getId());
        query.bindStringProperty("overpaymentSA", ServiceAgreementType.properties.saType, parmOverpaymentSATypeCode);
        
        query.addResult("sa", "SA");
        query.addResult("paymentPriority", "SAT.paymentPriority");
        query.orderBy("paymentPriority");

        for(QueryResultRow resultRow : query.list()) {
            saList.add(resultRow.getEntity("sa", ServiceAgreement.class));
        }

        return saList;
    }
    //End Add JVitug - D-02142 - 2020-08-26
    /**
     * This method retrieves the other Accounts where the main customer is the same
     * @return accountList
     */
    private List<Account> retrieveOtherAccounts() {
        List<Account> accountList = new ArrayList<Account>();

        Query<Account_Id> query = createQuery("FROM Account ACCT, AccountPerson AP "
                + "WHERE ACCT.id = AP.id.account "
                + "AND ACCT.id <> :accountId "
                + "AND AP.isMainCustomer = :yes "
                + "AND AP.id.person = :personId "
                + "AND ACCT.collectionClassId = :collClassId "
                + "AND ACCT.divisionId = :cisDivisionId "
                + "AND NOT EXISTS (SELECT AC.id.account "
                                + "FROM AccountCharacteristic AC "
                                + "WHERE AC.id.account = ACCT.id "
                                + "AND AC.id.characteristicType = :charType "
                                + "AND AC.searchCharacteristicValue = :charValue "
                                //Start Change JVitug - CCB009.2_Issue12 - 2020-04-23
                                //Start Change JVitug - CCB009.2_Issue11 - 2020-04-22
                                //+ "AND AC.id.effectiveDate = :effDate)",
                                //+ "AND AC.id.effectiveDate <= :effDate)",
                                + "AND AC.id.effectiveDate = ( "
                                        + "SELECT MAX(AC2.id.effectiveDate) "
                                        + "FROM AccountCharacteristic AC2 "
                                        + "WHERE AC2.id.account = AC.id.account "
                                        + "AND AC2.id.characteristicType = AC.id.characteristicType "
                                        + "AND AC2.id.effectiveDate <= :effDate "
                                    + ") "
                                + ") ",
                                //End Change JVitug - CCB009.2_Issue11 - 2020-04-22
                                //End Change JVitug - CCB009.2_Issue12 - 2020-04-23
                "retrieveOtherAccounts");

        query.bindId("accountId", woAccount.getId());
        query.bindBoolean("yes", Bool.TRUE);
        query.bindId("personId", woPerson.getId());
        query.bindId("collClassId", woAccount.getCollectionClassId());
        query.bindId("cisDivisionId", woAccount.getDivisionId());
        query.bindId("charType", parmDoNotTransferCharType.getId());
        query.bindStringProperty("charValue", AccountCharacteristic.properties.searchCharacteristicValue, parmDoNotTransferCharValue.trim());
        query.bindDate("effDate", getProcessDateTime().getDate());
        
        
        query.addResult("accountId", "ACCT.id");
        
        for(Account_Id accountId : query.list()) {
            accountList.add(accountId.getEntity());
        }

        return accountList;
    }

    /**
     * This method retrieves other customer accounts
     * @return accountList
     */
    private List<Account> retrieveOtherCustomerAccounts() {
        List<Account> accountList = new ArrayList<Account>();
                
        Query<Account_Id> query = createQuery("FROM PersonName PN, PersonId PID, "
                +       "AccountPerson AP, Account ACCT "
                + "WHERE PN.id.person <> :personId "
                + "AND PN.nameType = :nameType "
                //Start Change JVitug - CCB009.2_Issue4 - 2020-03-24
                //+ "AND PN.uppercaseEntityName LIKE :primaryName "
                + "AND SUBSTR(PN.uppercaseEntityName , 0 , 12) LIKE :primaryName "
                //End Change JVitug - CCB009.2_Issue4 - 2020-03-24
                + "AND PN.id.person = PID.id.person "
                + "AND PID.id.idType = :idType "
                //Start Change JVitug - CCB009.2_Issue2 - 2020-03-16
                //+ "AND PID.personIdNumber = :idNumber "
                + "AND ( "
                +    "(PID.hashIdNumber is NULL AND PID.personIdNumber = :idNumber) "
                +    "OR (PID.hashIdNumber IS NOT NULL AND PID.hashIdNumber = :hashIdNumber ) "
                + ") "
                //End Change JVitug - CCB009.2_Issue2 - 2020-03-16
                + "AND PN.id.person = AP.id.person "
                + "AND AP.isMainCustomer = :yes "
                + "AND AP.id.account = ACCT.id "
                // Start Add - D-02142 - 2020-08-31
                + "AND ACCT.divisionId = :cisDivisionId "
                // End Add - D-02142 - 2020-08-31
                + "AND ACCT.collectionClassId = :collClassId",
                "retrieveOtherCustomerAccounts");
        query.bindId("personId", woPerson.getId());
        query.bindLookup("nameType", NameTypeLookup.constants.PRIMARY);
        //Start Change JVitug - CCB009.2_Issue4 - 2020-03-24
        //query.bindLikableStringProperty("primaryName", PersonName.properties.uppercaseEntityName, upperCasePrimaryName.trim());
        query.bindStringProperty("primaryName", PersonName.properties.uppercaseEntityName, upperCasePrimaryName);
        //End Change JVitug - CCB009.2_Issue4 - 2020-03-24
        query.bindId("idType", parmSSNIdType.getId());
        query.bindStringProperty("idNumber", PersonId.properties.personIdNumber, ssn.trim());
        //Start Add - JVitug - CCB009.2_Issue2 - 2020-03-16
        query.bindStringProperty("hashIdNumber" , PersonId.properties.hashIdNumber , hashSSN.trim());
        //End Add - JVitug - CCB009.2_Issue2 - 2020-03-16
        query.bindBoolean("yes", Bool.TRUE);
        query.bindId("collClassId", woAccount.getCollectionClassId());
        // Start Add - D-02142 - 2020-08-31
        query.bindId("cisDivisionId", woAccount.getDivisionId());
        // End Add - D-02142 - 2020-08-31
        
        query.addResult("accountId", "ACCT.id");
        
        for(Account_Id Account_Id : query.list()) {
            accountList.add(Account_Id.getEntity());
        }

        return accountList;
    }
    
    /**
     * This method checks if there are existing customers having the same SSN Id as the main person on the account of the WO SA
     * @return Bool
     */
    private Bool retrieveOtherCustomerSameSSNDifferentName() {

        Query<PersonId_Id> query = createQuery("FROM PersonName PN, PersonId PID  "
                + "WHERE PN.id.person <> :personId "
                + "AND PN.nameType = :nameType "
                //Start Change JVitug - CCB009.2_Issue4 - 2020-03-24
                //+ "AND NOT PN.uppercaseEntityName LIKE :primaryName "
                + "AND NOT SUBSTR(PN.uppercaseEntityName, 0 ,12) LIKE :primaryName "
                //End Change JVitug - CCB009.2_Issue4 - 2020-03-24
                + "AND PN.id.person = PID.id.person "
                + "AND PID.id.idType = :idType "
              //Start Change JVitug - CCB009.2_Issue2 - 2020-03-16
              //+ "AND PID.personIdNumber = :idNumber " 
                + "AND ( "
                +    "(PID.hashIdNumber is NULL AND PID.personIdNumber = :idNumber) "
                +    "OR (PID.hashIdNumber IS NOT NULL AND PID.hashIdNumber = :hashIdNumber ) "
                + ") " , 
              //End Change JVitug - CCB009.2_Issue2 - 2020-03-16,
                "retrieveOtherCustomerSameSSNDifferentName");
        query.bindId("personId", woPerson.getId());
        query.bindLookup("nameType", NameTypeLookup.constants.PRIMARY);
        //Start Change JVitug - CCB009.2_Issue4 - 2020-03-24
        //query.bindLikableStringProperty("primaryName", PersonName.properties.uppercaseEntityName, upperCasePrimaryName.trim());
        query.bindStringProperty("primaryName", PersonName.properties.uppercaseEntityName, upperCasePrimaryName);
        //End Change JVitug - CCB009.2_Issue4 - 2020-03-24
        query.bindId("idType", parmSSNIdType.getId());
        query.bindStringProperty("idNumber", PersonId.properties.personIdNumber, ssn.trim());
        query.bindStringProperty("hashIdNumber" , PersonId.properties.hashIdNumber , hashSSN.trim());
        
        query.addResult("personId", "PN.id.person");
        
        if (isNull(query.firstRow())){
            return Bool.FALSE;
        }
        else{
            return Bool.TRUE;    
        }
    }
    
    /**
     * This method checks if there were any intact payments on the SA made after the last
     * non-Overpayment SA closed. Assume the other non-Overpayment SAs are closed or cancelled.
     * @return Bool
     */
    private Bool hasPaymentAfterClosure(){
        //Start Change - JVitug - CCB009.2_Issue2 - 2020-03-17
//        Query<ServiceAgreement> query = createQuery("FROM PaymentSegment PS "
//                + "WHERE PS.serviceAgreement = :saId "
//                + "AND PS.paySegmentAmount = :paymentAmount",
//                "hasMisappliedPayment");
        PreparedStatement query = null;
        StringBuilder stringSQL = new StringBuilder();
        SQLResultRow result = null;
        
        // Start Change - D-02215.Issue2 - 2021-05-06
        //stringSQL.append("SELECT PSEG.PAY_ID , ");
        //stringSQL.append(       "(SELECT COUNT(PSEG3.PAY_SEG_ID) ");
        //stringSQL.append(        "FROM CI_PAY_SEG PSEG3 ");
        //stringSQL.append(        "WHERE PSEG3.PAY_ID = PAY.PAY_ID) AS COUNT_PSEG ");
        stringSQL.append("SELECT PSEG.PAY_ID ");
        // End Change - D-02215.Issue2 - 2021-05-06
        stringSQL.append("FROM CI_PAY_EVENT PE , ");
        stringSQL.append(     "CI_PAY PAY , ");
        stringSQL.append(     "CI_PAY_SEG PSEG ");
        stringSQL.append("WHERE PE.PAY_EVENT_ID = PAY.PAY_EVENT_ID ");
        stringSQL.append("AND PAY.PAY_ID = PSEG.PAY_ID ");
        stringSQL.append("AND PSEG.SA_ID = :saId ");
        stringSQL.append("AND PAY.PAY_AMT = :paymentAmount ");
        stringSQL.append("AND PAY.PAY_STATUS_FLG = :frozen ");
        stringSQL.append("AND PE.PAY_DT = ( ");
        stringSQL.append(     "SELECT MAX(PE2.PAY_DT) ");
        stringSQL.append(     "FROM CI_PAY_EVENT PE2 ");
        stringSQL.append(     "WHERE PE.PAY_EVENT_ID = PE2.PAY_EVENT_ID ");
        stringSQL.append(") ");
        // Start Add - D-02215.Issue2 - 2021-05-06
        stringSQL.append("and PE.PAY_DT > ( ");
        stringSQL.append(    "select TRUNC(MAX(FT.FREEZE_DTTM)) ");
        stringSQL.append(    "from CI_SA SA1, CI_SA SA2 , CI_SA_TYPE SAT , CI_FT FT ");
        stringSQL.append(    "where SA2.SA_ID = PSEG.SA_ID ");
        stringSQL.append(    "and SA1.ACCT_ID = SA2.ACCT_ID ");
        stringSQL.append(    "and SAT.SA_TYPE_CD = SA1.SA_TYPE_CD ");
        stringSQL.append(    "and SAT.CIS_DIVISION = SA1.CIS_DIVISION ");
        stringSQL.append(    "and SAT.WO_DEBT_CL_CD <> :woDebtClassCode ");
        stringSQL.append(    "and SA1.SA_STATUS_FLG = :saClosedStatus ");
        stringSQL.append(    "and FT.SA_ID = SA1.SA_ID ");
        stringSQL.append(    "and FT.FT_TYPE_FLG not in (:ftTypeAdjCancel,:ftTypeBillSegCancel,:ftTypePaySegCancel) ");
        stringSQL.append(    "and not exists ( ");
        stringSQL.append(        "select FT1.FT_ID ");
        stringSQL.append(        "from CI_FT FT1 ");
        stringSQL.append(        "where FT1.SA_ID = FT.SA_ID ");
        stringSQL.append(        "and FT1.SIBLING_ID = FT.SIBLING_ID ");
        stringSQL.append(        "and FT1.FT_TYPE_FLG in (:ftTypeAdjCancel,:ftTypeBillSegCancel,:ftTypePaySegCancel))) ");
        // End Add - D-02215.Issue2 - 2021-05-06
        
        query = createPreparedStatement(stringSQL.toString() , "hasMisappliedPayment");
        query.bindId("saId", woServiceAgreement.getId());
        query.bindMoney("paymentAmount", woSaBalance.negate());
        //Start Add - JVitug - CCB009.2_Issue2 - 2020-03-16
        query.bindLookup("frozen", PaymentStatusLookup.constants.FROZEN);
        //End Add - JVitug - CCB009.2_Issue2 - 2020-03-16
        // Start Add - D-02215.Issue2 - 2021-05-06
        query.bindId("woDebtClassCode", woDebtClass.getId());
        query.bindLookup("saClosedStatus", ServiceAgreementStatusLookup.constants.CLOSED);
        query.bindLookup("ftTypeAdjCancel", FinancialTransactionTypeLookup.constants.ADJUSTMENT_CANCELLATION);
        query.bindLookup("ftTypeBillSegCancel", FinancialTransactionTypeLookup.constants.BILL_CANCELLATION);
        query.bindLookup("ftTypePaySegCancel", FinancialTransactionTypeLookup.constants.PAY_CANCELLATION);
        // End Add - D-02215.Issue2 - 2021-05-06
        
        result = query.firstRow();
        
        query.close();
        //End Change - JVitug - CCB009.2_Issue2 - 2020-03-17
        
        // Start Change - D-02215.Issue2 - 2021-05-06
        ////Start Change - JVitug - CCB009.2_Issue2 - 2020-03-17
        //if (notNull(result)) {
        ////if (notNull(latestPayment)) {
        //    //return Bool.TRUE;
        //    //If the count of payment segments of the Payment is one, this means
        //    //that the balance of the Finalized SA is composed entirely of this payment
        //    //return True as it is a misapplied payment. If count 
        //    // is greater than one, return false.
        //    BigInteger countOfPaymentSegment = result.getInteger("COUNT_PSEG");
        //    
        //    if(countOfPaymentSegment.compareTo(BigInteger.ONE) > 0){
        //        return Bool.FALSE;
        //    } else {
        //    	//Start Add JVitug - D-02215 - 2021-02-17
        //    	misappliedPayment = ((Payment_Id) result.getId("PAY_ID", Payment.class)).getEntity();
        //    	//End Add JVitug - D-02215 - 2021-02-17
        //        return Bool.TRUE;
        //    }
        //    
        ////End Change - JVitug - CCB009.2_Issue2 - 2020-03-17
        // }
        //else {
        //    return Bool.FALSE;
        //}
        
        if (notNull(result)) {
            misappliedPayment = ((Payment_Id) result.getId("PAY_ID", Payment.class)).getEntity();
            return Bool.TRUE;
        }
        
        return Bool.FALSE;
        // End Change - D-02215.Issue2 - 2021-05-06
    }

    /**
     * This method checks if the SA has an open Refund To Do Entry
     * @return Bool
     */
    private Bool hasExistingRefundToDoEntry(){
        Bool refundToDoExists = Bool.FALSE;
        Query<ToDoEntry> query = createQuery("FROM ServiceAgreement SA, ToDoEntry TDE, ToDoDrillKeyValue TDK "
                + "WHERE SA.id = :saId "
                + "AND SA.id = TDK.keyValue "
                + "AND TDK.id.toDo = TDE.id "
                + "AND TDE.toDoType = :toDoType "
                + "AND TDE.toDoEntryStatus <> :completedStatus",
                "hasExistingRefundToDoEntry");
        query.bindId("saId", woServiceAgreement.getId());
        query.bindId("toDoType", parmToDoType.getId());
        query.bindLookup("completedStatus", ToDoEntryStatusLookup.constants.COMPLETED);
        query.addResult("toDoEntry", "TDE");

        if (notNull(query.firstRow())) {
            refundToDoExists = Bool.TRUE;
        }
        return refundToDoExists;

    }
    
    /**
     * This method checks if the Customer's SSN is invalid
     * @return Bool
     */
    private Bool checkCustomerSSN(){
        Bool invalidSSN = Bool.FALSE;

        // Start Add - CCB009.2.Issue1       
        PersonId_Id perIdId = new PersonId_Id(woPerson.getId(), parmSSNIdType.getId()); 
        if(notNull(perIdId.getEntity())){
            String encryptedSSN = perIdId.getEntity().getEncryptedIdNumber();       
            if(!isBlankOrNull(encryptedSSN)){ 
                String decryptedSSN = "";

                try {
                    FieldEncryptionDecryptionData decryptData = FieldEncryptionDecryptionData.Factory.newInstance();
                    decryptData.setTableName("CI_PER_ID");
                    //Start Change - JLumbre - 2020-12-07 - CCB-017
                    //decryptData.setFieldName("ENCR_PER_ID_NBR");
                    decryptData.setFieldName("PER_ID_NBR");
                    //End Change - JLumbre - 2020-12-07 - CCB-017
                    decryptData.setCipherText(encryptedSSN.trim());
                    decryptData.setFilterField("ID_TYPE_CD");
                    decryptData.setFilterValue(parmSSNIdType.getId().getTrimmedValue());

                    FieldEncryptionDecryption decrypt = FieldEncryptionDecryption.Factory.newInstance(); 
                    DecryptedValue decryptedValue = decrypt.decrypt(decryptData); 

                    decryptedSSN = decryptedValue.getBuffer().toString().trim(); 

                } catch (Exception e) {
                    addError(CustomMessageRepositorySpireOne.CCB009_2_unableToDecrypt(woPerson.getId().getTrimmedValue()));
                }

                Query<FeatureConfigurationOption> query = createQuery("FROM FeatureConfigurationOption FCO "
                        + "WHERE FCO.id.workforceManagementSystem = :featureConfigId "
                        + "AND FCO.id.optionType = :optionType "
                        + "AND FCO.value = :decryptedSSN",
                        "checkCustomerSSN");
                query.bindId("featureConfigId", parmInvalidSSNsFeatConf.getId());
                query.bindStringProperty("optionType",
                        FeatureConfigurationOption.properties.optionType,
                        CmInvalidSocialSecurityNumbersLookup.constants.INVALID_S_S_N.getLookupValue().fetchIdFieldValue().trim());
                query.bindStringProperty("decryptedSSN", FeatureConfigurationOption.properties.value, decryptedSSN);

                if(notNull(query.firstRow())){
                    invalidSSN = Bool.TRUE;
                }

            }else {     
            // End Add - CCB009.2.Issue1

                Query<ToDoEntry> query = createQuery("FROM PersonId PID, FeatureConfigurationOption FCO "
                        + "WHERE PID.id.person = :personId "
                        + "AND PID.id.idType = :idType "
                        + "AND PID.personIdNumber = FCO.value "
                        + "AND FCO.id.workforceManagementSystem = :featureConfigId "
                        + "AND FCO.id.optionType = :optionType",
                        "checkCustomerSSN");
                query.bindId("personId", woPerson.getId());
                query.bindId("idType", parmSSNIdType.getId());
                query.bindId("featureConfigId", parmInvalidSSNsFeatConf.getId());
                query.bindStringProperty("optionType",
                        FeatureConfigurationOption.properties.optionType,
                        CmInvalidSocialSecurityNumbersLookup.constants.INVALID_S_S_N.getLookupValue().fetchIdFieldValue().trim());

                if (query.listSize() > 0) {
                    invalidSSN = Bool.TRUE;
                }
        // Start Add - CCB009.2.Issue1
            }            
        }
        // End Add - CCB009.2.Issue1

        return invalidSSN;

    }
    
    /**
     * This method retrieves an overpayment SA for the account
     * @param account
     * @return ServiceAgreement
     */
    private ServiceAgreement retrieveOverpaymentSA(Account account){
        ServiceAgreement overpaymentSA = null;
        
        Query<ServiceAgreement> query = createQuery("FROM ServiceAgreement SA "
                + "WHERE SA.status NOT IN (:closedStatus, :cancelledStatus) "
                + "AND SA.account = :accountId "
                + "AND SA.serviceAgreementType.id.saType = :overpaymentSaType "
                + "AND SA.serviceAgreementType.id.division = :cisDivisionId  "
                + "AND SA.id <> :saId ",
                "retrieveOverpaymentSA");
        query.bindLookup("closedStatus", ServiceAgreementStatusLookup.constants.CLOSED);
        query.bindLookup("cancelledStatus", ServiceAgreementStatusLookup.constants.CANCELED);
        query.bindId("accountId", account.getId());
        query.bindStringProperty("overpaymentSaType", ServiceAgreementType.properties.saType, parmOverpaymentSATypeCode.trim());
        query.bindId("cisDivisionId", account.getDivisionId());
        query.bindId("saId", woServiceAgreement.getId());

        query.addResult("sa", "SA");
        if (notNull(query.firstRow())){
            overpaymentSA = (ServiceAgreement) query.firstRow();
        }
        
        return overpaymentSA;
    }
    
    //Start Add JVitug - CCB009.2_Issue13 - 2020-05-04
    private void transferCreditBalanceToSAWithDifferentWODebtClassOnSameAcct() {

        List<ServiceAgreement> otherSAsList = retrieveOtherSAOfAccountWithDifferentWO(woAccount);
        
        for (ServiceAgreement otherSA : otherSAsList) {
            ServiceAgreementCharacteristic saDNTChar = otherSA.getEffectiveCharacteristic(parmDoNotTransferCharType);
            if (isNull(saDNTChar)){
                
                Bool stopLoop = transferCreditBalance(otherSA);
                if (stopLoop.isTrue()) {
                    exitAlgorithm = Bool.TRUE;
                    break;
                }
            }
        }
    
    }
    
    /**
     * Retrieve other SAs under the same account which has a different
     * WO Debt class from the finalized SA but whose WO debt class
     * is equal to one of the WO Debt Class of the WO Debt Class
     * Algorithm parameter
     * @param account
     * @return list of eligible SAs 
     */
    private List<ServiceAgreement> retrieveOtherSAOfAccountWithDifferentWO(Account account) {
        List<ServiceAgreement> saList = new ArrayList<ServiceAgreement>();
        
        Query<QueryResultRow> query = createQuery("FROM ServiceAgreement SA, ServiceAgreementType SAT "
                // Start Change - D-02142 - 2020-08-31
                //+ "WHERE SA.status IN (:active , :pendingStop , :stopped , :reactivated ) "
                + "WHERE SA.status IN (:stopped , :reactivated ) "
                // End Change - D-02142 - 2020-08-31
                + "AND SA.account.id = :accountId "
                + "AND SA.serviceAgreementType.id.division = SAT.id.division  "
                + "AND SA.serviceAgreementType.id.saType = SAT.id.saType "
                + "AND SAT.writeOffDebtClass.id IN (" + woDebtClassesInQuotes + ") "
                + "AND SA.id <> :saId "
                + "AND SAT.paymentPriority IS NOT NULL  ",
                "retrieveOtherAccountSAsWithDifferentWO");

        query.bindId("accountId", account.getId());
        query.bindId("saId", woServiceAgreement.getId());
        // Start Delete - D-02142 - 2020-08-31
        //query.bindLookup("active" , ServiceAgreementStatusLookup.constants.ACTIVE);
        //query.bindLookup("pendingStop" , ServiceAgreementStatusLookup.constants.PENDING_STOP);
        // End Delete - D-02142 - 2020-08-31
        query.bindLookup("stopped" , ServiceAgreementStatusLookup.constants.STOPPED);
        query.bindLookup("reactivated" , ServiceAgreementStatusLookup.constants.REACTIVATED);
        
        query.addResult("sa", "SA");
        query.addResult("paymentPriority", "SAT.paymentPriority");
        query.orderBy("paymentPriority");

        for(QueryResultRow resultRow : query.list()) {
            saList.add(resultRow.getEntity("sa", ServiceAgreement.class));
        }

        return saList;
    }
    
    /**
     * Enclose each WO debt class in quotes
     * @param woDebtClasses
     * @return WO Debt Class string with each WO debt class enclosed in quotes
     */
    private String encloseWODebtClassInQuotes(String woDebtClassParm){
        StringBuilder woDebtClassStringBuilder = new StringBuilder();
        String[] woDebtClasses = woDebtClassParm.split(COMMA);
        
        woDebtClassStringBuilder.append("'");

        for (int i = 0; i < woDebtClasses.length; i++){
            woDebtClassStringBuilder.append(woDebtClasses[i] + "'");
            if (i < woDebtClasses.length - 1) {
                woDebtClassStringBuilder.append(",'");
            }
        }
        return woDebtClassStringBuilder.toString();
    }
    
    /**
     * Attempt to transfer the Credit Balance to the SAs of another account
     * @param otherAccount
     */
    private void transferCreditBalanceToOtherAccountSADiffWO(Account otherAccount){
    	List<ServiceAgreement> SAsOfOtherAccount = retrieveOtherSAOfAccountWithDifferentWO(otherAccount);
    	
    	for (ServiceAgreement saOfOtherAccount : SAsOfOtherAccount) {
            ServiceAgreementCharacteristic saDNTChar = saOfOtherAccount.getEffectiveCharacteristic(parmDoNotTransferCharType);
            if (isNull(saDNTChar)){
                
                Bool stopLoop = transferCreditBalance(saOfOtherAccount);
                if (stopLoop.isTrue()) {
                    exitAlgorithm = Bool.TRUE;
                    break;
                }
            }
        }
    }
    
    //End Add JVitug - CCB009.2_Issue13 - 2020-05-04
    //Start Add JVitug - D-02215 - 2021-02-17
    private Bill getClosingBill() {
    	Bill closingBill = null;
    	StringBuilder stringSql = new StringBuilder();
    	
    	stringSql.append("SELECT ");
    	stringSql.append(   "BILL.BILL_ID ");
    	stringSql.append("FROM ");
    	stringSql.append(   "CI_BILL BILL, ");
    	stringSql.append(   "CI_BSEG BSEG ");
    	stringSql.append("WHERE ");
    	stringSql.append(   "BILL.ACCT_ID = :account ");
    	stringSql.append("AND ");
    	stringSql.append(   "BILL.BILL_STAT_FLG = :complete ");
    	//Start Delete JVitug - D-02215.Issue1 - 2021-04-22
    	//stringSql.append("AND ");
    	//stringSql.append(   "BILL.COMPLETE_DTTM = ( ");
    	//stringSql.append(      "SELECT ");
    	//stringSql.append(         "MAX(BILL2.COMPLETE_DTTM) ");
    	//stringSql.append(      "FROM ");
    	//stringSql.append(         "CI_BILL BILL2 ");
    	//stringSql.append(      "WHERE ");
    	//stringSql.append(         "BILL2.ACCT_ID = BILL.ACCT_ID ");
    	//stringSql.append(   ") ");
    	//End Delete JViitug - D-02215.Issue1 - 2021-04-22
    	stringSql.append("AND ");
    	stringSql.append(   "BILL.BILL_ID = BSEG.BILL_ID ");
    	stringSql.append("AND ");
    	stringSql.append(   "BSEG.BSEG_STAT_FLG = :frozen ");
    	stringSql.append("AND ");
    	stringSql.append(   "BSEG.CLOSING_BSEG_SW = :closingSwitch ");
		//Start Add JVitug -  D-02215.Issue1 - 2021-04-22
    	stringSql.append("ORDER BY BILL.DUE_DT DESC ");
    	//End Add JVitug -  D-02215.Issue1 - 2021-04-22
    	
    	PreparedStatement sql = createPreparedStatement(stringSql.toString(), getClass().getName());
    	sql.bindId("account", woAccount.getId());
    	sql.bindLookup("complete", BillStatusLookup.constants.COMPLETE);
    	sql.bindLookup("frozen" , BillSegmentStatusLookup.constants.FROZEN);
    	sql.bindBoolean("closingSwitch", Bool.TRUE);
    	
    	SQLResultRow result = sql.firstRow();
    	sql.close();
    	
    	if(notNull(result)) {
    		closingBill = result.getEntity("BILL_ID", Bill.class);
    	}
    	
    	return closingBill;
    }
    //End Add JVitug - D-02215 - 2021-02-17
}
