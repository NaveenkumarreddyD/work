/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractDetailsCorrectionChargesRecord 
		extends ColumnDelimitedRecord{	
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractDetailsCorrectionChargesRecord() {
		super(13);
		
		// Initialize all fields as blank/spaces
		this.setBPPrinterKey(" ");		
		this.setBPSortKey(" ");
		this.setBPMailingKey(" ");
		this.setBillCorrectionBillDescr(" ");
		this.setStartDt(" ");
		this.setEndDt(" ");
		this.setCancelBillAmt(BigDecimal.ZERO, "0");
		this.setRebillBillAmt(BigDecimal.ZERO, "0");
		this.setHeadTotAmt(BigDecimal.ZERO, "0");
		this.setFiller();
	}
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * 
	 */
	public void setBPPrinterKey(String value) {		
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
	public void setBPSortKey(String value) {
		rightPadColumn(2, 184, truncateInput(value, 184));
	}
	public void setBPMailingKey(String value) {
		rightPadColumn(3, 15, truncateInput(value, 15));
	}	
	/*
	 * Correction Charges
	 */
	public void setBillCorrectionBillDescr(String value) {
		rightPadColumn(4, 60, truncateInput(value, 60));
	}
	public void setStartDt(String value) {
		rightPadColumn(5, 10, truncateInput(value, 10));
	}
	public void setEndDt(String value) {
		rightPadColumn(6, 10, truncateInput(value, 10));
	}
	public void setCancelBillAmt(BigDecimal bdVal, String value) {		
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(7, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(8, 15, truncateInput(value, 15));		
	}
	public void setRebillBillAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(9, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(10, 15, truncateInput(value, 15));
	}
	public void setHeadTotAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(11, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(12, 15, truncateInput(value, 15));
	}
	private void setFiller() {
		//rightPadColumn(10, 3319, " ");
		rightPadColumn(13, 3113, " ");
	}
}