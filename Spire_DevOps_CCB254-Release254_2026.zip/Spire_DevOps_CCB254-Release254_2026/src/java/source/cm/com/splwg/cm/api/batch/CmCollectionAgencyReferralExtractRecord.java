/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Collection Agency Referral Extract Record                                                               
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                          
 * 2015-07-15  SMiran      Defect 3198240. Initial Version.      
 * 2021-06-15  EQuint      SA-368912. Add premise ID in staging table       
 * 2021-12-16  JHERNA      Mercury#47161 / B-20309. Add data status field                                                                   
 *******************************************************************************
 */

package com.splwg.cm.api.batch;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmCollectionAgencyReferralExtractRecord extends ColumnDelimitedRecord {
	
	public CmCollectionAgencyReferralExtractRecord() {
		// START CHANGE - JHERNA - 2021-12-16 -Mercury#47161 
		/*
		// Start Update - EQuint - SA-368912 - 2021-06-15
		// super(7);	
		super(8);	
		// End Update - EQuint - SA-368912 - 2021-06-15
		*/
		super(9);
		// END CHANGE - JHERNA - 2021-12-16 - Mercury#47161
	}
	
	public void setReferenceId(String referenceId) {
		this.rightPadColumn(1, 10, formatString(referenceId, 10));
	}
	
	public void setReferralId(String referralId) {
		this.rightPadColumn(2, 10, formatString(referralId, 10));
	}
	
	public void setAccountId(String accountId) {
		this.rightPadColumn(3, 10, formatString(accountId, 10));
	}
	
	// Start Add - EQuint - SA-368912 - 2021-06-15
	public void setPremiseId(String premiseId) {
		this.rightPadColumn(4, 10, formatString(premiseId, 10));
	}
	// End Add - EQuint - SA-368912 - 2021-06-15
	
	public void setCollectionAgency(String collectionAgency) {
		// Start Update - EQuint - SA-368912 - 2021-06-15
		// this.rightPadColumn(4, 8, formatString(collectionAgency, 8));
		this.rightPadColumn(5, 8, formatString(collectionAgency, 8));
		// End Update - EQuint - SA-368912 - 2021-06-15
	}
	
	// YYYY-MM-DD
	public void setDatePlaced(String datePlaced) {
		// Start Update - EQuint - SA-368912 - 2021-06-15
		// this.rightPadColumn(5, 10, formatString(datePlaced, 10));
		this.rightPadColumn(6, 10, formatString(datePlaced, 10));
		// End Update - EQuint - SA-368912 - 2021-06-15
	}
	
	public void setWoBalance(BigDecimal woBalance) {
		// Start Update - EQuint - SA-368912 - 2021-06-15
		// this.rightPadColumn(6, 16, formatAsS9999999999999V99(woBalance));
		this.rightPadColumn(7, 16, formatAsS9999999999999V99(woBalance));	
		// End Update - EQuint - SA-368912 - 2021-06-15
	}
	
	public void setCisDivision(String cisDivision) {
		// Start Update - EQuint - SA-368912 - 2021-06-15
		// this.rightPadColumn(7, 5, formatString(cisDivision, 5));
		this.rightPadColumn(8, 5, formatString(cisDivision, 5));
		// End Update - EQuint - SA-368912 - 2021-06-15
	}
	   
	// START ADD - JHERNA - 2021-12-16 - Mercury#47161
	public void setDataStatus(String dataStatus) {
		this.rightPadColumn(9, 9, formatString(dataStatus, 9));
	}
	// END ADD - JHERNA - 2021-12-16 - Mercury#47161
	
	/**
	 * Returns "" if text is null;
	 * Truncates text if length exceed fieldLength;
	 * @param text String variable to be formatted
	 * @param fieldLength Length of Field
	 * @return formatted text
	 */
	private String formatString(String text, int fieldLength) {
		if(text == null) {
			text = "";
		}
		else {
			text = text.trim();
			if(text.length() > fieldLength) {
				text = text.substring(0, fieldLength);
			}
		}
		return text;
	}
}
