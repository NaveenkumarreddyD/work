/* ************************************************************************
 *                Confidentiality Information:
 *
 * This module is the confidential and proprietary information of
 * Oracle Corporation; it is not to be copied, reproduced, or
 * transmitted in any form, by any means, in whole or in part,
 * nor is it to be used for any purpose other than that for which
 * it is expressly provided without the written permission of
 * Oracle Corporation.
 *
 *
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * Data Correction - Maximo vs CC&B - CC&B Changes - Meter Status
 *
 * This batch process will process Maximo data corrections for Meter 
 * Status.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:        Reason:
 * YYYY-MM-DD   IN         Reason text.
 *
 * 2015-05-06   RKing      Initial Version.
 * 2015-06-22   RKing      MTR-CCB001.002 Updated validation table.
 * 2016-01-29  	MPang	   Updated for CCB v2.4 compilation. 
 ***************************************************************************/
package com.splwg.cm.domain.batch;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.ccb.api.lookup.MeterStatusLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.meterread.meter.Meter;
import com.splwg.ccb.domain.meterread.meter.Meter_DTO;
import com.splwg.ccb.domain.meterread.meter.Meter_Id;*/
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_DTO;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.meter.meter.CmMeterDataLog;
import com.splwg.cm.domain.meter.meter.CmMeterDataLog_DTO;

/**
 * @author 90724
 *
 @BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = maximoErrorDescription, required = true, type = string)
 *            , @BatchJobSoftParameter (name = goLiveDate, required = true, type = date)
 *            , @BatchJobSoftParameter (name = outOfServiceMaximoValue, required = true, type = string)
 *            , @BatchJobSoftParameter (name = activeCcbValue, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = retireReason, name = retireReason, required = true, type = entity)
 *            })
 */

public class CmMaximoDataCorrectionMeterStatusBatch
		extends CmMaximoDataCorrectionMeterStatusBatch_Gen {

    public JobWork getJobWork() {
    	
    	// Setup bind variables.
    	String errorDescr = " '" + getParameters().getMaximoErrorDescription().trim() + "' ";
    	String outOfServiceVal = " '" + getParameters().getOutOfServiceMaximoValue().trim() + "' ";
    	String activeVal = " '" + getParameters().getActiveCcbValue().trim() + "' ";
	
		StringBuilder mainQuery =  new StringBuilder();
		mainQuery.append(" SELECT ");
		mainQuery.append("    ER.MTR_ID ");
		mainQuery.append("   ,MA.STATUSDATE ");
		mainQuery.append("   ,(SELECT MAX(SPH.REMOVAL_DTTM) ");
		mainQuery.append("       FROM CI_SP_MTR_HIST SPH ");
		mainQuery.append("          ,CI_MTR_CONFIG MC ");
		mainQuery.append("       WHERE MC.MTR_ID = ER.MTR_ID ");
		mainQuery.append("          AND MC.EFF_DTTM = (SELECT MAX(MC2.EFF_DTTM) ");
		mainQuery.append("               FROM CI_MTR_CONFIG MC2 ");
		mainQuery.append("               WHERE MC2.MTR_ID = MC.MTR_ID ");
		mainQuery.append("                  AND MC2.EFF_DTTM <= :processDate) ");
		mainQuery.append("                  AND MC.MTR_CONFIG_ID = SPH.MTR_CONFIG_ID) REMOVAL_DTTM ");
		mainQuery.append(" FROM ");
		mainQuery.append("    CM_VALIDATE.CM_VALIDATION_ERROR_METER ER ");
		/*
		 * MTR-CCB001.002 RKing - Start change.
		 */
		//mainQuery.append("    ,CM_VALIDATE.MAX_ASSET MA ");
		mainQuery.append("    ,CM_VALIDATE.MAX_METER MA ");
		/*
		 * MTR-CCB001.002 RKing - End change.
		 */
		mainQuery.append("    ,CI_MTR MTR ");
		mainQuery.append(" WHERE ");
		mainQuery.append("    ER.DESCRIPTION = " + errorDescr);
		mainQuery.append("    AND TRIM(ER.MAXIMO_VALUE)  =  " + outOfServiceVal);
		mainQuery.append("    AND TRIM(ER.CCB_VALUE) = " + activeVal);
		mainQuery.append("    AND ER.ASSETNUM = MA.ASSETNUM ");
		mainQuery.append("    AND MA.STATUSDATE < :goLiveDate ");
		mainQuery.append("    AND MTR.MTR_ID = ER.MTR_ID  ");
		mainQuery.append("    AND MTR.MTR_STATUS_FLG = " + activeVal);
		mainQuery.append("    AND NOT EXISTS (SELECT 'X' ");
		mainQuery.append("          FROM CI_SP_MTR_HIST SPH ");
		mainQuery.append("             ,CI_MTR_CONFIG MC ");
		mainQuery.append("          WHERE MC.MTR_ID = ER.MTR_ID ");
		mainQuery.append("             AND MC.EFF_DTTM = (SELECT MAX(MC2.EFF_DTTM) ");
		mainQuery.append("                  FROM CI_MTR_CONFIG MC2 ");
		mainQuery.append("                  WHERE MC2.MTR_ID = MC.MTR_ID ");
		mainQuery.append("                     AND MC2.EFF_DTTM <= :processDate) ");
		mainQuery.append("             AND MC.MTR_CONFIG_ID = SPH.MTR_CONFIG_ID ");
		mainQuery.append("             AND (SPH.REMOVAL_DTTM IS  NULL OR SPH.REMOVAL_DTTM > :processDate)) ");
		
		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement mainQueryPS = createPreparedStatement(mainQuery.toString());
		PreparedStatement mainQueryPS = createPreparedStatement(mainQuery.toString(), getClass().getName());
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		mainQueryPS.bindDate("processDate", getProcessDateTime().getDate());
		mainQueryPS.bindDate("goLiveDate", getParameters().getGoLiveDate());
		mainQueryPS.execute();
		
		QueryIterator iter = mainQueryPS.iterate();
		
		return createJobWorkForQueryIterator(iter, this);
	}
    
    public ThreadWorkUnit createWorkUnit(QueryResultRow resultRow) {
    	
    	ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        threadWorkUnit.addSupplementalData("mtrId", resultRow.getString("MTR_ID"));    	
        threadWorkUnit.addSupplementalData("statusDate", resultRow.getDate("STATUSDATE"));    	
        threadWorkUnit.addSupplementalData("removalDttm", resultRow.getDateTime("REMOVAL_DTTM"));    	
        return threadWorkUnit;
	}
    
    public void validateSoftParameters(boolean isNewRun) {
    }
	
	public Class<CmMaximoDataCorrectionMeterStatusBatchWorker> getThreadWorkerClass() {
        return CmMaximoDataCorrectionMeterStatusBatchWorker.class;
    }

    public static class CmMaximoDataCorrectionMeterStatusBatchWorker 
    		extends CmMaximoDataCorrectionMeterStatusBatchWorker_Gen {
    	
    	// Constants.
    	private static final String CI_MTR = "CI_MTR";
    	private static final String MTR_STATUS_FLG = "MTR_STATUS_FLG";
    	
    	public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

		@Override
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit) 
				throws ThreadAbortedException, RunAbortedException {

			WorkUnitResult result = new WorkUnitResult(true);
			
			String mtrIdStr = (String) unit.getSupplementallData("mtrId");			
			Date statusDate = (Date) unit.getSupplementallData("statusDate");
			DateTime removalDttm = (DateTime) unit.getSupplementallData("removalDttm");
			Meter mtr = (new Meter_Id(mtrIdStr)).getEntity();
			
			// Set Retire Date-time.
			Date retireDate = statusDate;
			if(notNull(removalDttm)) {
				if(removalDttm.getDate().isAfter(statusDate)) {
					retireDate = removalDttm.getDate();
				}
			} 
			
			// Retire meter.
			Meter_DTO mtrDto = mtr.getDTO();
			mtrDto.setMeterStatus(MeterStatusLookup.constants.RETIRED);
			mtrDto.setRetiredDate(retireDate);
			mtrDto.setRetireReasonId(getParameters().getRetireReason().getId());
			mtr.setDTO(mtrDto);
			
			// Create change log.
			cmCreateLog(mtr, MeterStatusLookup.constants.RETIRED.getLookupValue().getId().getFieldValue(), 
					MeterStatusLookup.constants.ACTIVE.getLookupValue().getId().getFieldValue());
			
			result.setUnitsProcessed(1);
			return result;
		}
		
		private void cmCreateLog(Meter mtr, String newValue, String oldValue) {
			
			CmMeterDataLog_DTO logDto = createDTO(CmMeterDataLog.class);
			logDto.setCreationDateTime(getProcessDateTime());
			logDto.setPrimaryKeyValue1(mtr.getId().getIdValue());
			logDto.setTable(CI_MTR);
			logDto.setValueAfterUpdate(newValue);
			logDto.setValueBeforeUpdate(oldValue);
	        logDto.setField(MTR_STATUS_FLG);
			
			logDto.newEntity();
		}
    }
}