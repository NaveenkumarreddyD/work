/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Pledge Payment FT Creation Algorithm
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-05-21   SMiran  NI0026.7 Initial Version.
 * 2013-08-30   CVB     Added Pledge Payment Char for those eligible for 
 *                      Pledge Funding.    
 * 2013-09-16   CVB     Added parameter for Pledge Bank. 
 * 2015-06-01   SMiran  Defect 3217093. Fixed NullPointerException when 
 * 						Payment does not have tender source yet (for autopay).
 * 						Proceed with normal payment segment FT creation. 
 * 2016-01-26   MPang	Updated for CCB v2.4 compilation.    
 * 2016-10-12   PSree   Updated for Incident# 73573           
 * 2017-01-06	JHerna	SysAid#176975. Current Amount and Total Amount value
 * 						should be identical.
 * 2020-10-27   DLampa  B-17434. Remove To Do Creation.               
 **************************************************************************/
package com.splwg.cm.domain.admin.paymentSegmentType;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.bank.Bank;
import com.splwg.ccb.domain.admin.bank.BankAccount;
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.GeneralLedgerDistributionCode;
import com.splwg.ccb.domain.admin.paymentSegmentType.PaymentSegmentTypeFinancialTransactionCreationAlgorithmSpot;
import com.splwg.ccb.domain.admin.tenderSource.TenderSource;
import com.splwg.ccb.domain.admin.tenderSource.TenderSource_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.financial.financialTransaction.FinancialTransactionGeneralLedgerData;
import com.splwg.ccb.domain.payment.payment.Payment;
import com.splwg.ccb.domain.payment.payment.PaymentCharacteristic;
import com.splwg.ccb.domain.payment.payment.PaymentCharacteristic_DTO;
import com.splwg.ccb.domain.payment.payment.PaymentCharacteristic_Id;
import com.splwg.ccb.domain.payment.payment.PaymentCharacteristics;
import com.splwg.ccb.domain.payment.payment.PaymentSegment;
import com.splwg.ccb.domain.payment.payment.PaymentSegmentFtGlCreationHelper;*/
import com.splwg.ccb.domain.admin.bank.entity.Bank;
import com.splwg.ccb.domain.admin.bank.entity.BankAccount;
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.entity.GeneralLedgerDistributionCode;
import com.splwg.ccb.domain.admin.paymentSegmentType.algorithm.ftCreation.PaymentSegmentTypeFinancialTransactionCreationAlgorithmSpot;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.financial.data.FinancialTransactionGeneralLedgerData;
import com.splwg.ccb.domain.payment.common.PaymentSegmentFtGlCreationHelper;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.ccb.domain.payment.payment.entity.PaymentCharacteristic;
import com.splwg.ccb.domain.payment.payment.entity.PaymentCharacteristic_DTO;
import com.splwg.ccb.domain.payment.payment.entity.PaymentCharacteristic_Id;
import com.splwg.ccb.domain.payment.payment.entity.PaymentCharacteristics;
import com.splwg.ccb.domain.payment.payment.entity.PaymentSegment;
import com.splwg.cm.api.lookup.CmPledgePaymentsOptionTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

//Start Change - 2016-10-12 - PSreekan - 73573
///**
// * @author smiranda
// *
// @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = featureConfiguration, name = pledgeFundingTypeTenderSourceFeatureConfiguration, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = eligiblePledgeFundingTypeTenderSourceOptionType, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = pledgePaymentCharacteristicType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = pledgePaymentCharacteristicValue, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = bank, name = pledgeBank, required = true, type = entity)
// *            })
// */
/**
 * @author smiranda
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = featureConfiguration, name = pledgePaymentReconcilationFeatureConfiguration, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = toDoType, name = ineligiblePaymentSegmentToDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = pledgePaymentCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = pledgePaymentCharacteristicValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = bank, name = pledgeBank, required = true, type = entity)
 *            })
 */
//End Change - 2016-10-12 - PSreekan - 73573
public class CmFtGlCreationForPledgePaymentAlgComp_Impl extends
CmFtGlCreationForPledgePaymentAlgComp_Gen implements
PaymentSegmentTypeFinancialTransactionCreationAlgorithmSpot {   

	// Constants 
	@SuppressWarnings("unused")
	private final String _OPT_TYP_FLG = "_OPT_TYP_FLG";

	// Hard Parameters
	private PaymentSegment paymentSegment;
	private Money currentAmount = Money.ZERO;
	private Money totalAmount = Money.ZERO;
	private List<FinancialTransactionGeneralLedgerData> financialTransactionGeneralLedgerData;
	private GeneralLedgerDistributionCode glDistributionCode;

	// Soft Parameters
	//Start Change - 2016-10-12 - PSreekan - 73573
//	private FeatureConfiguration pledgeFundingTypeTenderSourceFeatureConfiguration;
//	private String eligiblePledgeFundingTypeTenderSourceOptionType;
	private FeatureConfiguration pledgePaymentReconcilationFeatureConfiguration;
	private ToDoType ineligiblePaymentSegmentToDoType;
	//End Change - 2016-10-12 - PSreekan - 73573
	private CharacteristicType parmPledgePaymentCharacteristicType;
	private String parmPledgePaymentCharacteristicValue;
	// CVB - 2013-09-16 - Start
	private Bank parmPledgeBank;
	// CVB - 2013-09-16 - End

	// Work Variables
	private TenderSource_Id tenderSourceId;
	private Bool isEligible;
	private Money paymentSegmentAmount;
	private ServiceAgreement serviceAgreement;
	private PaymentSegmentFtGlCreationHelper ftGlCreationHelper;
	//Start Add - 2016-10-12 - PSreekan - 73573
	private CmMGEFeatureConfigurationOptionsRetriever cmMGEFeatureConfigurationOptionsRetriever;
	//End Add - 2016-10-12 - PSreekan - 73573

	public Money getCurrentAmount() {
		return currentAmount;
	}

	public List<FinancialTransactionGeneralLedgerData> getFinancialTransactionGeneralLedgerData() {
		return financialTransactionGeneralLedgerData;
	}

	public Money getTotalAmount() {
		return totalAmount;
	}

	public void setGeneralLedgerDistributionCode(
			GeneralLedgerDistributionCode arg0) {
		glDistributionCode = arg0;
	}

	public void setPaymentSegment(PaymentSegment arg0) {
		paymentSegment = arg0;
	}

	public void invoke() {

		//Start Add - 2016-10-12 - PSreekan - 73573
		cmMGEFeatureConfigurationOptionsRetriever = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
		//End Add - 2016-10-12 - PSreekan - 73573
		// Get Tender Source from Payment Segment's Payment's Payment Tender
		getTenderSource();

		// Check if Tender Source has a match in Pledge Funding Type Tender Source Feature Configuration
		// 2015-06-01 SMiran Defect 3217093 Start Change
		if (notNull(tenderSourceId)){
			isEligible = checkEligibility();
		}else{
			isEligible = Bool.FALSE;
		}
		// 2015-06-01 SMiran Defect 3217093 End Change
		
		// Set Current Amount and Payoff Amount
//		if (isEligible.isFalse()){
		currentAmount = paymentSegment.getPaySegmentAmount().negate();
	
//		}
		// Start Delete - 2020-10-27 - DLampa - B-17434
		//Start Add - 2016-10-12 - PSreekan - 73573
//		else{
		//if (isEligible.isTrue()){	
		//	String saTypeStrOpt = cmMGEFeatureConfigurationOptionsRetriever
		//			.getFeatureOptionValue(
		//					pledgePaymentReconcilationFeatureConfiguration.getId(),
		//					CmPledgePaymentsOptionTypeLookup.constants.ELIGIBLE_PLEDGE_SA_TYPES, Bool.TRUE, Bool.FALSE);
		//	String[] saTypeStr = saTypeStrOpt.split(",");
		//	Bool saTypeFound = Bool.FALSE;
		//	for (int i = 0; i < saTypeStr.length; i++) {
				
		//		ServiceAgreementType_Id saTypeId = new ServiceAgreementType_Id(paymentSegment.getServiceAgreement().getServiceAgreementType().getId().getDivision(), saTypeStr[i]);
		//		if(notNull(saTypeId) && notNull(saTypeId.getEntity()) && paymentSegment.getServiceAgreement().getServiceAgreementType().getId().equals(saTypeId)){
		//			saTypeFound = Bool.TRUE;
		//			break;
		//		}
		//	}
		//	if(saTypeFound.isFalse()){
		//		createToDoEntry();
				// START DELETE - JHERNA - 2017-01-06 - SysAid#176975
				// Process should still create FT GL Details as well as pledge pay char if applicable
				// return;
				// END DELETE - JHERNA - 2017-01-06 - SysAid#176975
		//	}
		//}
		//End Add - 2016-10-12 - PSreekan - 73573
		// End Delete - 2020-10-27 - DLampa - B-17434
		// CVB - 2013-09-16 - Start
		
		Bool createPledgePayChar = Bool.FALSE;
		 // 2015-06-01 SMiran Defect 3217093 Start Change
		if (notNull(tenderSourceId)){
			BankAccount pledgeBankAccount = tenderSourceId.getEntity().getBankAccount();
			if (!isNull(pledgeBankAccount)){
				Bank pledgeBank = pledgeBankAccount.getId().getBank();
				if (pledgeBank.equals(parmPledgeBank)){
					createPledgePayChar = Bool.TRUE;
				}
			}
		}
		// 2015-06-01 SMiran Defect 3217093 End Change

		//if (isEligible.isTrue()){
		if (createPledgePayChar.isTrue()){

			// CVB - 2013-09-16 - End

			// Insert Payment Characteristic
			createPaymentCharacteristic(paymentSegment.getPayment(),parmPledgePaymentCharacteristicType,parmPledgePaymentCharacteristicValue);
		}

		totalAmount = paymentSegment.getPaySegmentAmount().negate();		
		
		// Create FT GL Details
		financialTransactionGeneralLedgerData = new ArrayList<FinancialTransactionGeneralLedgerData>();
		ftGlCreationHelper = PaymentSegmentFtGlCreationHelper.Factory.newInstance();
		ftGlCreationHelper.validateInput(paymentSegment);
		paymentSegmentAmount = paymentSegment.getPaySegmentAmount();
		serviceAgreement = paymentSegment.getServiceAgreement();

		// Create "A/R" FT GL Detail               
		FinancialTransactionGeneralLedgerData arFtGl = ftGlCreationHelper
		.createFinancialTransactionGeneralLedgerDetail(Bool.TRUE,
				serviceAgreement.getServiceAgreementType().getDistributionCode().getId(),
				paymentSegmentAmount.negate());
		financialTransactionGeneralLedgerData.add(arFtGl);

		// Create "Cash" FT GL Detail
		FinancialTransactionGeneralLedgerData cashFtGl = ftGlCreationHelper
		.createFinancialTransactionGeneralLedgerDetail(Bool.FALSE,
				glDistributionCode.getId(), 
				paymentSegmentAmount);
		financialTransactionGeneralLedgerData.add(cashFtGl);

	}

	private void getTenderSource() {

		SQLResultRow tenderSourceSQLResult = null;        

		PreparedStatement getTenderSource 
		= createPreparedStatement(
				"SELECT " +
				"TC.TNDR_SOURCE_CD " +
				"FROM " +
				"CI_PAY_SEG PS, " +
				"CI_PAY PY, " +
				"CI_PAY_EVENT PE, " +
				"CI_PAY_TNDR PT, " +
				"CI_TNDR_CTL TC " +
				"WHERE " +
				"PS.PAY_SEG_ID = :paySegId " +
				"AND PY.PAY_ID = PS.PAY_ID " +
				"AND PE.PAY_EVENT_ID = PY.PAY_EVENT_ID " +
				"AND PT.PAY_EVENT_ID = PE.PAY_EVENT_ID " +
				//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
				// "AND TC.TNDR_CTL_ID = PT.TNDR_CTL_ID ");
				"AND TC.TNDR_CTL_ID = PT.TNDR_CTL_ID ", getClass().getName());
				//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation

		getTenderSource.bindId("paySegId", paymentSegment.getId());
		tenderSourceSQLResult = getTenderSource.firstRow();  
		// 2015-06-01 SMiran Defect 3217093 Start Change
		if (notNull(tenderSourceSQLResult)){
			tenderSourceId = (TenderSource_Id)tenderSourceSQLResult.getId("TNDR_SOURCE_CD", TenderSource.class);
		}else{
			tenderSourceId = null;
		}
		// 2015-06-01 SMiran Defect 3217093 End Change
	}

	private Bool checkEligibility() {     

		//Start Change - 2016-10-12 - PSreekan - 73573
//		StringBuilder stringBuilder = new StringBuilder();
//		stringBuilder.append(" FROM FeatureConfigurationOption fco1 ");
//		stringBuilder.append(" WHERE fco1.id.workforceManagementSystem = :wfmName ");
//		stringBuilder.append(" AND fco1.id.optionType = :optType ");
//		stringBuilder.append(" AND TRIM(fco1.value) = TRIM(:optVal) ");   
//		//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
//		//Query getOptionValue = createQuery(stringBuilder.toString());
//		Query getOptionValue = createQuery(stringBuilder.toString(), getClass().getName());
//		//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
//
//		getOptionValue.bindId("wfmName", pledgeFundingTypeTenderSourceFeatureConfiguration.getId());
//		getOptionValue.bindStringProperty("optType", FeatureConfigurationOption.properties.optionType, 
//				eligiblePledgeFundingTypeTenderSourceOptionType.trim());
//		getOptionValue.bindStringProperty("optVal", FeatureConfigurationOption.properties.value, tenderSourceId.getIdValue().trim());
//
//		if (getOptionValue.list().size() > 0){   
//			return Bool.TRUE;
//		}   
		String tenderSourceOption  = cmMGEFeatureConfigurationOptionsRetriever
				.getFeatureOptionValue(
						pledgePaymentReconcilationFeatureConfiguration.getId(),
						CmPledgePaymentsOptionTypeLookup.constants.PLEDGE_TENDER_SOURCE, Bool.TRUE, Bool.FALSE);
		String[] tenderSourceStr = tenderSourceOption.split(",");
		Bool tenderSourceMatched = Bool.FALSE;
		for (int i = 0; i < tenderSourceStr.length; i++) {
			
			if (tenderSourceStr[i].trim().equals(tenderSourceId.getTrimmedValue())) {
				tenderSourceMatched = Bool.TRUE;
				break;
			}
		}
		//End Change - 2016-10-12 - PSreekan - 73573

		return tenderSourceMatched;
	}

	@Override
	protected void extraSoftParameterValidations(boolean arg0) {

		//Start Change - 2016-10-12 - PSreekan - 73573
		// Get Pledge Funding Type Tender Source Feature Configuration
//		pledgeFundingTypeTenderSourceFeatureConfiguration = this.getPledgeFundingTypeTenderSourceFeatureConfiguration();
//
//		// Get Pledge Funding Type Tender Source Option Type
//		eligiblePledgeFundingTypeTenderSourceOptionType = this.getEligiblePledgeFundingTypeTenderSourceOptionType();
		pledgePaymentReconcilationFeatureConfiguration = this.getPledgePaymentReconcilationFeatureConfiguration();
		ineligiblePaymentSegmentToDoType = this.getIneligiblePaymentSegmentToDoType();
		//End Change - 2016-10-12 - PSreekan - 73573

		// Pledge Funding Type Tender Source Option Type must be a valid option type for 
		// Pledge Funding Type Tender Source Feature Configuration
		//Start Delete - 2016-10-12 - PSreekan - 73573
//		String extSysTypStr = pledgeFundingTypeTenderSourceFeatureConfiguration.getFeatureType().getLookupValue().fetchIdFieldValue().trim();
//		extSysTypStr = extSysTypStr.concat(_OPT_TYP_FLG);
//		LookupField_Id lookupField_Id = new LookupField_Id(extSysTypStr);
//		LookupValue_Id lookupValue_Id = new LookupValue_Id(lookupField_Id, eligiblePledgeFundingTypeTenderSourceOptionType.trim());
//		if (isNull(lookupValue_Id.getEntity())){
//			addError(CustomMessageRepository.NI0026_7_optTypeInvForWFM(                    
//					"Eligible Pledge Funding Type Tender Source Option Type", 
//					eligiblePledgeFundingTypeTenderSourceOptionType.trim(), 
//					pledgeFundingTypeTenderSourceFeatureConfiguration.getId().getIdValue().trim()));
//		}
		//End Delete - 2016-10-12 - PSreekan - 73573
		
		parmPledgePaymentCharacteristicType = getPledgePaymentCharacteristicType();

		// Validate the Pledge Payment Characteristic Type
		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(parmPledgePaymentCharacteristicType, CharacteristicEntityLookup.constants.PAYMENT);
		if(isNull(charEntityId.getEntity())){
			addError(CustomMessageRepositoryMDC.commInvalidCharacteristicTypeForEntity(parmPledgePaymentCharacteristicType.getId().getTrimmedValue(),
					CharacteristicEntityLookup.constants.PAYMENT.getLookupValue().fetchLanguageDescription()));
		}

		parmPledgePaymentCharacteristicValue = getPledgePaymentCharacteristicValue();

		// Pledge Characteristic Value
		if (parmPledgePaymentCharacteristicType.getCharacteristicType().isPredefinedValue() 
				&& validateCharTypeAndCharValue(parmPledgePaymentCharacteristicType, parmPledgePaymentCharacteristicValue).isFalse()) {
			addError(CustomMessageRepositoryMDC.commCharValueInvalidForCharType(parmPledgePaymentCharacteristicValue, parmPledgePaymentCharacteristicType.getId().getTrimmedValue()));
		}

		// CVB - 2013-09-16 - Start
		parmPledgeBank = getPledgeBank();
		// CVB - 2013-09-16 - End

	} 
	
	// Start Delete - 2020-10-27 - DLampa - B-17434
	//Start Add - 2016-10-12 - PSreekan - 73573
	// private void createToDoEntry() {
		// startChanges();
		// ServerMessage message = CustomMessageRepositoryMGE
				// .sa73573ToDoMessagePledgePaymentInvalid(paymentSegment
						// .getServiceAgreement().getServiceAgreementType()
						// .getId().getSaType(), paymentSegment
						// .getServiceAgreement().getId().getTrimmedValue(),
						// paymentSegment.getServiceAgreement().getAccount()
								// .getId().getTrimmedValue());
		
		// ToDoEntry_DTO entryDto  = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
		// entryDto.setCreationDateTime(getProcessDateTime());
        // entryDto.setToDoTypeId(ineligiblePaymentSegmentToDoType.getId());
        // entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
        // entryDto.setToDoPriority(ineligiblePaymentSegmentToDoType.getToDoPriority());
        // entryDto.setToDoRoleId(getDefaultToDoRole().getId());
        // entryDto.setMessageId(message.getMessageId());

		// ArrayList<ToDoSortKeyValue_DTO>sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();
        // ToDoTypeSortKeyTypes sortKeyTypes = ineligiblePaymentSegmentToDoType.getSortKeyTypes();

        // for (Iterator<ToDoSortKeyType> iter = sortKeyTypes.iterator(); iter.hasNext();) {
            // ToDoSortKeyType sortKeyType = (ToDoSortKeyType) iter.next();
            // ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
            // BigInteger seq = sortKeyType.fetchIdSequence();
            // sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));

            // if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(1))==0){
                // sortKeyDto.setKeyValue(paymentSegment
        				// .getPayment().getPaymentEvent().getId().getTrimmedValue());
            // }
            // sortKeyList.add(sortKeyDto);
        // }

        // ArrayList<ToDoDrillKeyValue_DTO>drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
        // ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO)     createDTO(ToDoDrillKeyValue.class);
        // ToDoDrillKeyType drillKeyType = (ToDoDrillKeyType) ineligiblePaymentSegmentToDoType.getDrillKeyTypes().iterator().next();
        // BigInteger sequence = drillKeyType.fetchIdSequence();
        // drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, sequence));

        // drillKeyDto.setKeyValue(paymentSegment
				// .getPayment().getPaymentEvent().getId().getTrimmedValue());
        // drillKeyList.add(drillKeyDto);

        // ArrayList <String> messageParameterList = new ArrayList<String> ();
        // messageParameterList.add(0,paymentSegment
				// .getServiceAgreement().getServiceAgreementType()
				// .getId().getSaType());
        // messageParameterList.add(1,paymentSegment
				// .getServiceAgreement().getId().getTrimmedValue());
        // messageParameterList.add(2,paymentSegment.getServiceAgreement().getAccount()
				// .getId().getTrimmedValue());
        // ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory.newInstance();

        // toDoEntryData.setDrillKeys(drillKeyList);
        // toDoEntryData.setEntryDto(entryDto);
        // toDoEntryData.setSortKeys(sortKeyList);
        // toDoEntryData.setMessageParams(messageParameterList);
        // ArrayList <ToDoEntryCharacteristic_DTO>  charList = new ArrayList<ToDoEntryCharacteristic_DTO> ();
        // toDoEntryData.setToDoCharacteristics(charList);

        // ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
        // toDoProcessor.addToDo(toDoEntryData);
		// saveChanges();
	// }
	
	 /**
     * @return Role 
     * This method fetches the Default Role to create a TODO
     * 
     */ 
    // private Role getDefaultToDoRole(){
        // Role defaultRole = null;
        // StringBuilder defaultRoleQueryString = new StringBuilder();
        // defaultRoleQueryString.append("SELECT ROLE_ID FROM CI_TD_VAL_ROLE WHERE TD_TYPE_CD = :toDoType AND DEFAULT_SW = :yes ");

        // //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        // //PreparedStatement defaultRolePrepStmt = createPreparedStatement(defaultRoleQueryString.toString()); 
        // PreparedStatement defaultRolePrepStmt = createPreparedStatement(defaultRoleQueryString.toString(), getClass().getName()); 
        // //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        // defaultRolePrepStmt.bindId("toDoType", ineligiblePaymentSegmentToDoType.getId()); 
        // defaultRolePrepStmt.bindBoolean("yes", Bool.TRUE);
        // defaultRole = defaultRolePrepStmt.firstRow().getEntity("ROLE_ID", Role.class);
        // defaultRolePrepStmt.close();
        // return defaultRole;
    // }
	//End Add - 2016-10-12 - PSreekan - 73573
	// End Delete - 2020-10-27 - DLampa - B-17434

	private void createPaymentCharacteristic(Payment payment, CharacteristicType charType, String charValue){

		PaymentCharacteristics payChars = payment.getCharacteristics(); 
		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		//ListFilter<PaymentCharacteristic> charFilter = payChars.createFilter("where this.id.characteristicType = :charType");
		ListFilter<PaymentCharacteristic> charFilter = payChars.createFilter("where this.id.characteristicType = :charType", getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		charFilter.bindEntity("charType", charType);
		PaymentCharacteristic payChar = charFilter.firstRow();

		if(isNull(payChar)){
			PaymentCharacteristic_DTO payCharDto = (PaymentCharacteristic_DTO) createDTO(PaymentCharacteristic.class);
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();


			if (charTypeLookup.isPredefinedValue()) {
				payCharDto.setCharacteristicValue(charValue);
			}
			else if (charTypeLookup.isForeignKeyValue()) {
				payCharDto.setCharacteristicValueForeignKey1(charValue);
			}
			else {
				payCharDto.setAdhocCharacteristicValue(charValue);
			}

			BigInteger paymentCharSequence = getPaymentCharNextSequence(payment,charType);

			PaymentCharacteristic_Id payCharId = new PaymentCharacteristic_Id(payment, charType, paymentCharSequence);
			payCharDto.setId(payCharId);
			payCharDto.newEntity();
		}

	}

	private Bool validateCharTypeAndCharValue(CharacteristicType charType, String charValue) {

		CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charType, charValue);
		if (isNull(charValueId.getEntity())) {
			return Bool.FALSE;
		}

		return Bool.TRUE;
	}

	private BigInteger getPaymentCharNextSequence(Payment payment, CharacteristicType charType){

		BigInteger sequence = BigInteger.ZERO;

		StringBuilder getPaymentCharNextSequenceStringBuilder = new StringBuilder();

		getPaymentCharNextSequenceStringBuilder.append(" SELECT MAX(SEQ_NUM)               ");
		getPaymentCharNextSequenceStringBuilder.append("   FROM CI_PAY_CHAR                ");
		getPaymentCharNextSequenceStringBuilder.append("  WHERE PAY_ID = :payment          ");
		getPaymentCharNextSequenceStringBuilder.append("    AND CHAR_TYPE_CD = :charType   ");
		//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
		// PreparedStatement getPaymentCharNextSequenceQuery = createPreparedStatement(getPaymentCharNextSequenceStringBuilder.toString());
		PreparedStatement getPaymentCharNextSequenceQuery = createPreparedStatement(getPaymentCharNextSequenceStringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
		getPaymentCharNextSequenceQuery.bindEntity("payment", payment);
		getPaymentCharNextSequenceQuery.bindEntity("charType", charType);

		SQLResultRow row = getPaymentCharNextSequenceQuery.firstRow();

		if(notNull(row)){
			sequence = row.getInteger("MAX(SEQ_NUM)");
		}

		return sequence;
	}


}
