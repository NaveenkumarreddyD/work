/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm will cause an Account with a credit balance to skip WO
 * Process creation.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *   
 * 2020-08-31   BMarquez    CCB009.5/D-02142 Initial version.  
 *              JVitug                  
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.writeOffControl.algorithm.writeOffLargeCreditAp;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.ccb.domain.admin.writeOffControl.algorithm.writeOffLargeCreditAp.WriteOffLargeCreditApAlgorithmSpot;
import com.splwg.ccb.domain.admin.writeOffDebtClass.entity.WriteOffDebtClass;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 *
@AlgorithmComponent ()
 */
public class CmSkipWriteOffProcessCreationAlgComp_Impl extends
        CmSkipWriteOffProcessCreationAlgComp_Gen implements
        WriteOffLargeCreditApAlgorithmSpot {

    // Hard parameters - input
    private Account account;
    private WriteOffDebtClass writeOffDebtClass;
    private Money writeOffDebtClassTotalBalance;
    
    // Hard parameters - output
    private Bool areServiceAgreementsClosed =  Bool.FALSE;
    
    // Logger
    private Logger logger = LoggerFactory.getLogger(CmSkipWriteOffProcessCreationAlgComp_Impl.class);

    @Override
    public void setAccount(Account account) {
        this.account = account;
    }

    @Override
    public void setWriteOffDebtClass(WriteOffDebtClass writeOffDebtClass) {
        this.writeOffDebtClass = writeOffDebtClass;
    }

    @Override
    public void setWriteOffDebtClassTotalBalance(Money writeOffDebtClassTotalBalance) {
        this.writeOffDebtClassTotalBalance = writeOffDebtClassTotalBalance;
    }
    
    @Override
    public Bool getAreServiceAgreementsClosed() {
        return areServiceAgreementsClosed;
    }
    
    @Override
    public void invoke() { 
       
        // If WO Debt Class Total Balance < 0, skip processing the SA       
        if (writeOffDebtClassTotalBalance.isLessThan(Money.ZERO)) {
            areServiceAgreementsClosed = Bool.TRUE;
        }
        
        logDebug(logger, "Account: " + account.getId().getTrimmedValue() + " " + writeOffDebtClassTotalBalance + " " + areServiceAgreementsClosed);
        
    }
    
}
