/**************************************************************************
* Program Name: CmZeroUseBillMessageAlgComp_Impl
* Program Title: CmZeroUseBillMessageAlgComp_Impl
* Author: ACasta
* Creation Date: 2017-05-29
* Purpose: Adds a Zero Use Bill Message for qualified Bill Segments. 
*          A Zero Bill Message will be inserted when zero usage is
*          identified on a Bill Segment. Multi-premise billing will
*          only have the Bill Message inserted once in the event
*          multiple bill segments have zero usage.
* Functional Spec: NA-86246
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:         Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  NA-86246           Alfonso Castano 2017-05-29    Initial Version.
 *  Defect 3775842     Aya Masilang    2017-06-19    Modified invoke() to use QueryIterator 
 *                                                   instead of Iterator when accessing the 
 *                                                   getMeteredBillSegment() return Query. Also, 
 *                                                   to close the QueryIterator at the end.
 ************************************************************************************************/
package com.splwg.cm.domain.admin.customerClass;

import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.ccb.api.lookup.ServicePointSubTypeLookup;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.customerClass.algorithm.postBillCompletion.CustomerClassPostBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author acasta
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = eligibleUOM, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = billMessageType, required = true, type = entity)})
 */
public class CmZeroUseBillMessageAlgComp_Impl extends
        CmZeroUseBillMessageAlgComp_Gen implements
        CustomerClassPostBillCompletionAlgorithmSpot {

    // Soft Parameters
    private String eligibleUOM;
    private BillMessageType billMessageType;
    
    // Hard Parameters
    private Bill bill;
    
    // Work Variables
    Bool wShouldCreateBillMessage = Bool.FALSE;
    
    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        billMessageType = getBillMessageType();
        
        // Validate eligible UOM
        eligibleUOM = getEligibleUOM();
        String[] uomList = eligibleUOM.split(",");
        eligibleUOM = "";
        for (int i=0; i<uomList.length; i++){
            String uom = uomList[i];
            UnitOfMeasure unitOfMeasure = new UnitOfMeasure_Id(uom.trim()).getEntity();
            if (isNull(unitOfMeasure)){
                addError(CustomMessageRepository.NA_86246_invalidUnitOfMeasure
                        (uom.trim()));
            }
            eligibleUOM = eligibleUOM + "'" + uomList[i] + "' , "; 
        }
        eligibleUOM = eligibleUOM.substring(0, eligibleUOM.lastIndexOf(","));
    }

    @Override
    public void invoke() {
        // Retrieve Bill Segments on Bill with Metered SP Subtype
        // If a valid Bill Segment is found, check if the Bill Segment's
        // SQ details has an eligible Unit of Measure.

        // Defect 3775842 - 2017-06-19 - Start Change
        //Iterator<BillSegment> bsegListRet = getMeteredBillSegment(bill).iterate();
        QueryIterator<BillSegment> bsegListRet = getMeteredBillSegment(bill).iterate();
        // Defect 3775842 - 2017-06-19 - End Change
        while (bsegListRet.hasNext()){
            BillSegment_Id bseg = (BillSegment_Id) bsegListRet.next();
            StringBuilder getSQStringBuilder = new StringBuilder();
            getSQStringBuilder.append("WHERE this.id.unitOfMeasure IN (" + eligibleUOM + ")");
            ListFilter<BillSegmentServiceQuantity> getServiceQuantities = 
                    bseg.getEntity().getServiceQuantities()
                    .createFilter(getSQStringBuilder.toString(),getClass().getName());

            List<BillSegmentServiceQuantity> svcQtyList = getServiceQuantities.list();
            if (svcQtyList.size() == 1){
                // If an Eligible Unit of Measure is found on the Bill Segment's SQ Details,
                // check the usage. If 0 usage is found, Add the Zero Use Bill Message.
                BillSegmentServiceQuantity bsegSQ = svcQtyList.get(0);
                if (bsegSQ != null){
                    if (bsegSQ.getBillableServiceQuantity().compareTo(BigDecimal.ZERO) == 0){
                        wShouldCreateBillMessage = Bool.TRUE;
                        break;
                    }
                }
            }
        }
        // Defect 3775842 - 2017-06-19 - Start Add
        bsegListRet.close(); 
        // Defect 3775842 - 2017-06-19 - End Add

        if (wShouldCreateBillMessage.isTrue()){
            if (checkExistingZeroUseBillMessage(bill.getId()).isFalse()){
                createBillMessage(billMessageType);
            }
        }
    }

    @Override
    public void setBill(Bill paramBill) {
        this.bill = paramBill;
    }
    
    /**
     * Get the Bill's Bill Segments with a Metered SP SubType
     * @param bill
     * @return List
     */
    private Query<BillSegment> getMeteredBillSegment(Bill bill){
        StringBuilder queryStr = new StringBuilder();
        queryStr.append("FROM Bill B, BillSegment BS, ServiceAgreementServicePoint SASP, " +
                " ServicePoint SP, ServicePointType ST ");
        queryStr.append(" WHERE B.id = :billId ");
        queryStr.append(" AND B.id = BS.billId ");
        queryStr.append(" AND BS.serviceAgreement = SASP.serviceAgreement ");
        queryStr.append(" AND SASP.startDateTime = ( ");
        queryStr.append("     SELECT MAX(SASP2.startDateTime) FROM ServiceAgreementServicePoint SASP2 ");
        queryStr.append("     WHERE SASP2.serviceAgreement = SASP.serviceAgreement) ");
        queryStr.append(" AND SASP.servicePoint = SP.id ");
        queryStr.append(" AND SP.spType = ST.id ");
        queryStr.append(" AND ST.servicePointSubType = :spSubType ");
        
        Query<BillSegment> getMeterBillSegmentQuery = createQuery(queryStr.toString(), getClass().getName());
        getMeterBillSegmentQuery.bindId("billId", bill.getId());
        getMeterBillSegmentQuery.bindLookup("spSubType", ServicePointSubTypeLookup.constants.METER);
        getMeterBillSegmentQuery.addResult("billSegment", "BS.id");
        getMeterBillSegmentQuery.selectDistinct(true);
        
        return getMeterBillSegmentQuery;       
    }
    
    /**
     * Check if the Bill has an existing Zero Use Bill Message
     * @param billId Bill_Id
     * @return Bool zeroUseBillMessageExists
     */
    private Bool checkExistingZeroUseBillMessage(Bill_Id billId){
        Bool zeroUseBillMessageExists = Bool.FALSE;
        Query<Bool> query = createQuery("FROM BillMessage BM " +
        		" WHERE BM.id.bill.id = :billId " +
        		" AND BM.id.billMessage = :billMessageType", getClass().getName());
        query.bindId("billId", billId);
        query.bindId("billMessageType", billMessageType.getId());
        query.addResult("billMessage", "BM.id.billMessage");
        
        if (query.firstRow() != null){
            zeroUseBillMessageExists = Bool.TRUE;
        }
        return zeroUseBillMessageExists;
    }
    
    /**
     * Create a Bill Message that is of a specific Bill Message Type
     * @param billMessageType BillMessageType
     */
    private void createBillMessage(BillMessageType billMessageType) {
        bill.getMessages().add(new BillMessage_DTO(), billMessageType.getId());
    }
    
    
}
