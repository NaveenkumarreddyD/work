/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Custom Post Route Bill Extract Algorithm
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Re-coded for performance issue.
 * 2019-10-30	JHERNA	   312869. Update the calculation formula for 
 *                         new total current charge amount.
 * 2021-11-19   JTIOZON    47090. Updated to print zeroes for Therms (TH)
 *                         unit of measure. Used for the Rate Change 2021.
 * 2021-11-19   JTIOZON    CCB-047. Updated for MO Severance Process
 *                         Alignment.  
 * 2024-09-17   DLampa     INC0037039.Issue1. Update logic on processing 
 *                         the number of bill copies.          
 * 2024-12-05   DLampa     E-09959. Update logic on processing deposit bill 
 *                         segments to disregard the premise id so the  
 *                         records appear in the non-premise format in 
 *                         the extract. 
 * 2025-11-14   EQuint      CCB25.4 Upgrade 
 * 2026-02-04   JBasha     Defect # 5157603 Null pointer check for bill intercept id
 *************************************************************************/
package com.splwg.cm.domain.admin.billRouteType.algorithm.billExtract;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.HibernateCacheHelper;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControl;
import com.splwg.base.domain.common.algorithm.Algorithm;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.currency.Currency_Id;
import com.splwg.base.domain.common.language.Language;
import com.splwg.base.domain.common.lookup.LookupField;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.domain.report.reportDefinition.ReportDefinition;
import com.splwg.base.domain.workflow.notificationExternalId.NotificationExternalId;
import com.splwg.base.domain.workflow.notificationExternalId.NotificationExternalId_Id;
import com.splwg.ccb.api.lookup.BillPrintPriorityLookup;
import com.splwg.ccb.api.lookup.BillingRelationshipLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ConsumptionTypeLookup;
import com.splwg.ccb.api.lookup.CustomerReadLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.api.lookup.MessagePriorityLookup;
import com.splwg.ccb.api.lookup.ReadTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementRelationshipStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.SpecialRoleLookup;
import com.splwg.ccb.cobol.mr.CobolCopybookCICMDBRN;
import com.splwg.ccb.cobol.mr.CobolProgramCIPMDBRN;
import com.splwg.ccb.cobol.zz.CobolCopybookCICZSMPV;
import com.splwg.ccb.cobol.zz.CobolProgramCIPZSMPV;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.admin.adjustmentCancelReason.entity.AdjustmentCancelReason_Id;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType_Id;
import com.splwg.ccb.domain.admin.billRouteType.algorithm.billExtract.BillExtractAlgorithmSpot;
import com.splwg.ccb.domain.admin.budgetPlan.entity.BudgetPlan;
import com.splwg.ccb.domain.admin.budgetPlan.entity.BudgetPlan_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.debtClass.entity.DebtClass;
import com.splwg.ccb.domain.admin.debtClass.entity.DebtClass_Id;
import com.splwg.ccb.domain.admin.itemType.entity.ItemType_Id;
import com.splwg.ccb.domain.admin.meterReadSource.entity.MeterReadSource;
import com.splwg.ccb.domain.admin.meterReadSource.entity.MeterReadSource_Id;
import com.splwg.ccb.domain.admin.paymentCancelReason.entity.PaymentCancelReason;
import com.splwg.ccb.domain.admin.paymentCancelReason.entity.PaymentCancelReason_Id;
import com.splwg.ccb.domain.admin.revenueClass.entity.RevenueClass;
import com.splwg.ccb.domain.admin.revenueClass.entity.RevenueClass_Id;
import com.splwg.ccb.domain.admin.serviceAgreementRelationshipType.entity.ServiceAgreementRelationshipType;
import com.splwg.ccb.domain.admin.serviceAgreementRelationshipType.entity.ServiceAgreementRelationshipType_Id;
import com.splwg.ccb.domain.admin.serviceProvider.entity.ServiceProvider;
import com.splwg.ccb.domain.admin.serviceProvider.entity.ServiceProvider_Id;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType_Id;
import com.splwg.ccb.domain.admin.sicCode.entity.SicCode;
import com.splwg.ccb.domain.admin.sicCode.entity.SicCode_Id;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillRouting;
import com.splwg.ccb.domain.billing.bill.entity.BillRouting_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillCalculationLine;
import com.splwg.ccb.domain.billing.billSegment.entity.BillCalculationLineCharacteristic;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentCalculationHeader;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentItem;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentMessage;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentRegisterRead;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentRegisterRead_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.common.currency.entity.Currency;
import com.splwg.ccb.domain.common.fileHelper.FileHelper;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreementRelationship.entity.ServiceAgreementRelationship;
import com.splwg.ccb.domain.customerinfo.serviceAgreementRelationship.entity.ServiceAgreementRelationship_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead_Id;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.ccb.domain.payment.payment.entity.Payment_Id;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentEvent;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentEvent_Id;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsAdjustmentDetailsRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsBillCalcHeaderRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsBillCalcLineRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsBillDetailsRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsBillMessageRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsBillSegmentDetailRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsBillSegmentItemRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsBillSegmentMessageRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsBillSegmentReadRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsBillSegmentSQRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsCorrectionChargesRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsCurrentChargeDebtClassRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsHistogramRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsOtherChargesRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsPAChargesRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsPaymentDetailsRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsPremiseDetailsRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractDetailsSADetailsRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractGenericEndRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractMailingKeyRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractPrinterKeyRecord;
import com.splwg.cm.api.batch.CmPostRouteBillExtractSortKeyRecord;
import com.splwg.cm.domain.common.customBusinessComponent.CmAccountCheckDigitRetriever;
import com.splwg.cm.domain.common.customBusinessComponent.CmBillPrintHistogramRoutine;
import com.splwg.cm.domain.common.customBusinessComponent.CmCheckDigitMod10Retriever;
import com.splwg.cm.domain.common.customBusinessComponent.CmDetermineAcctCreditAndCashOnlyRatingRoutine;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.common.StringUtilities;

/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = validateParameterSwitch, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (entityName = lookupField, name = billPrintHeaderDescriptionsLookupFieldName, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = billCorrectionPeriodHeaderLookupValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = otherChargesHeaderLookupValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = customerPaymentHeaderLookupValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = pledgePaymentHeaderLookupValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = remitToCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = defaultRemitTo, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = serviceQuantityIdentifier, name = btuFactorSQI, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = rateClassDescriptionCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = utilityChargesHeadersCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = taxingCommunityPremiseCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = taxingCommunityBillLineCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = grossAmountCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = latePaymentAdjustmentCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = pledgePaymentCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = serviceType, name = serviceTypeforMetered, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = serviceType, name = serviceTypeforUnmetered, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = dollarHelpSACharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = billCalcLinePriorityCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = additionalHistogramUOMSATypeCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = additionalHistogramSQISATypeCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = contractNumberSACharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = unitOfMeasure, name = propaneBillableUOM, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = schoolAggregationAccountCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = schoolAggregationAccountCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = budgetPaymentArrangementCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = rateClassCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = cwrBillMessageCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = nonCwrBillMessageCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = cisDivisionCompanyCodeCharType, required = true, type = entity)})
 */

public class CmPostRouteBillExtractAlgComp_Impl 
		extends CmPostRouteBillExtractAlgComp_Gen 
		implements BillExtractAlgorithmSpot {
	
	// Hard Parameters
	private Bool hpIsBillSkipped;
	private Bool hpIsXmlFile;
	private ReportDefinition hpReportDefinition;
	private BigInteger hpReturnCode;
	@SuppressWarnings("unused")
	private BatchControl hpBatchControl;
	@SuppressWarnings("unused")
	private BigInteger hpBatchNumber;
	@SuppressWarnings("unused")
	private BigInteger hpBatchReRunNumber;
	@SuppressWarnings("unused")
	private BigInteger hpBatchThreadCount;
	@SuppressWarnings("unused")
	private BigInteger hpBatchThreadNumber;
	private Bill hpBill;
	@SuppressWarnings("unused")
	private BigInteger hpBillCount;
	@SuppressWarnings("unused")
	private String hpEndBillIdStr;
	@SuppressWarnings("unused")
	private Algorithm hpExtractAlgorithm;
	@SuppressWarnings("unused")
	private DateTime hpExtractDateTime;
	@SuppressWarnings("unused")
	private String hpExtractFileName;
	private FileHelper hpFileHelper;
	@SuppressWarnings("unused")
	private Bool hpIsWriteSummary;
	private BigInteger hpNumberOfCopies;
	private BigInteger hpSequenceNumber;
	@SuppressWarnings("unused")
	private String hpStartBillId;
	@SuppressWarnings("unused")
	private Bill hpToBill;
	
	// Soft Parameters
	private Bool parmValidateParmSw;
	private LookupField parmLookupFieldBillPrintHeaderDescr;
	private String parmLookupValueBillCorrectionPeriodHeader;
	private String parmLookupValueOtherChargesHeader;
	private String parmLookupValueCustomerPaymentHeader;
	private String parmLookupValuePledgePaymentHeader;
	private CharacteristicType parmCharTypeRemitTo;
	private String parmCharValDefaultRemitTo;
	private ServiceQuantityIdentifier parmSQI_BTUFactor;
	private CharacteristicType parmCharTypeRateClassDescription;
	private CharacteristicType parmCharTypeUtilityChargesHeaders;
	private CharacteristicType parmCharTypeTaxingCommunityPremise;
	private CharacteristicType parmCharTypeTaxingCommunityBillLine;
	private CharacteristicType parmCharTypeGrossAmount;
	private CharacteristicType parmCharTypeLatePaymentAdjustment;
	private CharacteristicType parmCharTypePledgePayment;
	private ServiceType parmServiceTypeForMetered;
	private ServiceType parmServiceTypeForUnmetered;
	private CharacteristicType parmCharTypeDollarHelpSA;
	private CharacteristicType parmCharTypeBillCalcLinePriority;
	private CharacteristicType parmCharTypeAdditionalHistogramUOMSAType;
	private CharacteristicType parmCharTypeAdditionalHistogramSQISAType;
	private CharacteristicType parmCharTypeContractNumberSA;
	private UnitOfMeasure parmUOMPropaneBillable;
	private CharacteristicType parmCharTypeSchoolAggregationAccount;
	private String parmCharValueSchoolAggregationAccount;
	private CharacteristicType parmCharTypeBudgetPaymentArrangement;
	private CharacteristicType parmCharTypeRateClass;
	//Start Add - JTIOZON - CCB-047
	private BillMessageType parmCWRBillMessageType;
	private BillMessageType parmNonCWRBillMessageType;	
	//End Add - JTIOZON - CCB-047
	// Start Add - DLampa - 2024-07-30 - INC0037039
	private CharacteristicType parmCharTypeCisDivisionCompanyCode;
	// End Add - DLampa - 2024-07-30 - INC0037039
	
	// Variables
	private int wLineSeq;		
	private Account wAcct;	
	private Bool wIsFinalBillSw;
	private Bool wIsCashOnlySw;			
	private Bool wWithPremiseSw;
	private Bool wWithSaSw;
	private Bool wWithBsegSw;
	private Bool wWithCalcHdrSw;	
	private Bool wPossibleDuplPremSw;
	private Bool wDummyPremRecExistsSw;
	private Bool wNonPremSw;
	private Bool wSkipPremSw;
	private Bool wCalclnHdrExistsSw;
	private Bool wCalclnSeqExistsSw;
	private BillRouting wBillRouting;	
	private BudgetPlan_Id wBudgetPlanID;	
	private Currency_Id wAccountCurrencyID;
	private Currency_Id wInstallCurrencyID;
	private Person wMainPerson;
	private Premise_Id wPremID;
	private ReadTypeLookup wS_READTYP_OUT_DATA_readTypeFlg;
	private UnitOfMeasure_Id wUomCd;
	private TimeOfUse_Id wTouCd;
	private ServiceQuantityIdentifier_Id wSqiCd;
	// Start Add - DLampa - 2024-07-30 - INC0037039
	private Bool budgetSw = Bool.FALSE;
	// End Add - DLampa - 2024-07-30 - INC0037039
	// Start Add - DLampa - 2024-09-17 - INC0037039.Issue1
	private String hpNumberOfCopiesIdx;
	// End Add - DLampa - 2024-09-17 - INC0037039.Issue1	
		
	/*S_SA*/
	private ServiceAgreement_Id wS_SA_OUT_DATA_SaID;
	private CisDivision_Id wS_SA_OUT_DATA_CisDivID;
	private String wS_SA_OUT_DATA_SATypeCd;
	@SuppressWarnings("unused")
	private ServiceAgreementStatusLookup wS_SA_OUT_DATA_saStatusFlg;
	@SuppressWarnings("unused")
	private Account_Id wS_SA_OUT_DATA_acctID;
	@SuppressWarnings("unused")
	private Date wS_SA_OUT_DATA_startDt;
	@SuppressWarnings("unused")
	private Date wS_SA_OUT_DATA_endDt;
	private String wS_SA_OUT_DATA_oldAcctID;
	@SuppressWarnings("unused")
	private Bool wS_SA_OUT_DATA_allowEstSw;
	private CustomerReadLookup wS_SA_OUT_DATA_custReadFlg;
	private SicCode_Id wS_SA_OUT_DATA_sicCodeID;
	private Premise_Id wS_SA_OUT_DATA_charPremID;
	@SuppressWarnings("unused")
	private String wS_SA_OUT_DATA_startOptCd;
	@SuppressWarnings("unused")
	private Money wS_SA_OUT_DATA_totToBillAmt;
	private Currency_Id wS_SA_OUT_DATA_currencyCd;
	private ServiceAgreementRelationship_Id wS_SA_OUT_DATA_saRelID;
	private String wS_SA_OUT_DATA_descr;
	private String wS_SA_OUT_DATA_dfltDescrOnBill;
	private RevenueClass_Id wS_SA_OUT_DATA_revClCd;
	private BillPrintPriorityLookup wS_SA_OUT_DATA_billPrtPrioFlg;
	private UnitOfMeasure_Id wS_SA_OUT_DATA_GraphUomCd;
	private ServiceType_Id wS_SA_OUT_DATA_svcTypeCd;
	private SpecialRoleLookup wS_SA_OUT_DATA_specialRoleFlg;
	private String wS_SA_OUT_DATA_svcTypeDescr;
	private String wS_SA_OUT_DATA_revClDescr;
	/*S_SA*/
	/*S_SAREL*/
	private ServiceAgreementRelationship_Id wSAREL_OUT_DATA_saRelID;
	@SuppressWarnings("unused")
	private ServiceAgreement_Id wSAREL_OUT_DATA_sarSaID;
	private ServiceAgreementRelationshipType_Id wSAREL_OUT_DATA_saRelTypeID;
	@SuppressWarnings("unused")
	private String wSAREL_OUT_DATA_saExtRefID;
	@SuppressWarnings("unused")
	private ServiceAgreementRelationshipStatusLookup wSAREL_OUT_DATA_saRelStatusFlg;
	private ServiceProvider_Id wSAREL_OUT_DATA_sprCd;
	private String wSAREL_OUT_DATA_descr;
	private String wSAREL_OUT_DATA_descr50;
	@SuppressWarnings("unused")
	private ServiceAgreement_Id wSAREL_OUT_DATA_sprSaID;
	@SuppressWarnings("unused")
	private NotificationExternalId_Id wSAREL_OUT_DATA_ntXidCd;
	@SuppressWarnings("unused")
	private BillingRelationshipLookup wSAREL_OUT_DATA_billRelFlg;
	@SuppressWarnings("unused")
	private Person_Id wSAREL_OUT_DATA_perID;
	private String wSAREL_OUT_DATA_entityName;		
	/*S_SAREL*/
	/*S_BSEG_SQ*/
	private BigDecimal wS_BSEGSQ_OUT_DATA_initSq;
	private BigDecimal wS_BSEGSQ_OUT_DATA_billSq;
	/*S_BSEG_SQ*/
	/*S_READDTL*/
	private ReadTypeLookup wS_READDTL_OUT_DATA_readTypeFlg;
	private String wS_READDTL_OUT_DATA_badgeNbr;
	@SuppressWarnings("unused")
	private String wS_READDTL_OUT_DATA_serialNbr;
	private ConsumptionTypeLookup wS_READDTL_OUT_DATA_consumSubFlg;
	private BigInteger wS_READDTL_OUT_DATA_nbrOfDgtsRgt;
	private Register_Id wS_READDTL_OUT_DATA_regId;
	private BigInteger wS_READDTL_OUT_DATA_nbrOfDgtsLft;
	/*S_READDTL*/
	
	private Date wBillApaySchedExtractDt;
	private Date wCorrStartDt;
	private Date wCorrEndDt;
	private Date wBillDt;
		
	private String wMainPersonName;
	private String wBudgetPlanDescr;
	private String wClCharDescrOnBill;
	private String wTaxCommDescr;
	
	private Money wCorrCanAmt;
	private Money wCorrBillAmt;
	private Money wCorrTotAmt;		
	private Money wDepLoanAmt;
	private Money wNewTotCurrChgAmt;
	private Money wDepLoanCurAmt;
	private Money wDepLoanTotAmt;
	private Money wNewPrevBalAmt;
	private Money wNewPrevGasBalAmt;
	private Money wNewPrevOthrBalAmt;
	private Money wNewTotalBalAmt; 
	private Money wTotAmtBilled;
	@SuppressWarnings("unused")
	private Money wCurrPACurAmt;
	@SuppressWarnings("unused")
	private Money wCurrPATotAmt;
	private Money wDHCurAmt;
	private Money wDHTotAmt;
	private Money wBsegFtCurAmt;
	private Money wBsegFtTotAmt;
	private Money wTotalGrossAmt;
	private Money wClCharCalcAmt;
	private Money wCurrPrevBal;
	private Money wTotPrevBal;
	private Money wDelinquentAmt;
	private Money wTotPldgPayAmt;
	private Money wCurrPldgPayAmt;
	private Money wCurrLpcAdjAmt;
	@SuppressWarnings("unused")
	private Money wTotLpcAdjAmt;
	private Money wBillBalCurAmt;
	private Money wBillBalTotAmt;	
	private Money wBillChargeCurAmt;
	private Money wBillChargeTotAmt;
	private Money wBillCorrCurAmt;
	private Money wBillCorrTotAmt;
	private Money wBillAdjCurAmt;
	private Money wBillAdjTotAmt;
	private Money wBillPayCurAmt;
	private Money wBillPayTotAmt;	
	private Money wOtherAdjCurAmt;
	private Money wOthersTotAmt;
	private Money wInstallMinimumBillPrtAmt;
	private Money wBudgetRecurringChargeAmt;
	
	private CmPostRouteBillExtractDetailsBillDetailsRecord wBillDetailRecord;
	private CmPostRouteBillExtractSortKeyRecord wSortKeyRecord;
	private CmPostRouteBillExtractMailingKeyRecord wMailingKeyRecord;
	private CmPostRouteBillExtractPrinterKeyRecord wPrinterKeyRecord;
	private CmPostRouteBillExtractDetailsPAChargesRecord wPAChargesRecord;
	private CmPostRouteBillExtractDetailsCurrentChargeDebtClassRecord wCurrChargesDebtClassRecord;
	private CmPostRouteBillExtractDetailsCorrectionChargesRecord wCorrectionChargesRecord;
	private CmPostRouteBillExtractDetailsOtherChargesRecord wOtherChargesRecord;
	private CmPostRouteBillExtractDetailsPaymentDetailsRecord wPaymentDetailsRecord;
	private CmPostRouteBillExtractDetailsBillMessageRecord wBillMessageRecord;
	private CmPostRouteBillExtractDetailsHistogramRecord wHistogramRecord;
	private CmPostRouteBillExtractDetailsAdjustmentDetailsRecord wAdjDetailRecord;
	private CmPostRouteBillExtractDetailsPremiseDetailsRecord wPremiseDetailRecord;
	private CmPostRouteBillExtractDetailsSADetailsRecord wSaDetailRecord;
	private CmPostRouteBillExtractDetailsBillSegmentDetailRecord wBsegDetailRecord;
	private CmPostRouteBillExtractDetailsBillCalcHeaderRecord wBillCalcHdrRecord;
	private CmPostRouteBillExtractDetailsBillCalcLineRecord wBillCalcLineRecord;
	private CmPostRouteBillExtractDetailsBillSegmentMessageRecord wBsegMessageRecord;
	private CmPostRouteBillExtractDetailsBillSegmentReadRecord wBsegReadRecord;
	private CmPostRouteBillExtractDetailsBillSegmentSQRecord wBsegSqRecord;
	private CmPostRouteBillExtractDetailsBillSegmentItemRecord wBsegItemRecord;
	
	private static final DateFormat DTTM_FORMAT = new DateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS");
	
	//Start Add - JTIOZON - CCB-047
	private static final DateFormat DATE_FORMAT = new DateFormat("yyyy-MM-dd");
	//End Add - JTIOZON - CCB-047
	@Override
	public Bool getIsBillSkipped() {
		return hpIsBillSkipped;
	}

	@Override
	public Bool getIsXmlFile() {
		return hpIsXmlFile;
	}

	@Override
	public ReportDefinition getReportDefinition() {
		return hpReportDefinition;
	}

	@Override
	public BigInteger getReturnCode() {
		return hpReturnCode;
	}

	@Override
	public void setBatchControl(BatchControl batchControl) {
		hpBatchControl = batchControl;
	}

	@Override
	public void setBatchNumber(BigInteger batchNumber) {
		hpBatchNumber = batchNumber;
	}

	@Override
	public void setBatchRerunNumber(BigInteger batchRerunNumber) {
		hpBatchReRunNumber = batchRerunNumber;
	}

	@Override
	public void setBatchThreadCount(BigInteger batchThreadCount) {
		hpBatchThreadCount = batchThreadCount;
	}

	@Override
	public void setBatchThreadNumber(BigInteger batchThreadNumber) {
		hpBatchThreadNumber = batchThreadNumber;
	}

	@Override
	public void setBill(Bill bill) {
		hpBill = bill;
	}

	@Override
	public void setBillCount(BigInteger billCount) {
		hpBillCount = billCount;
	}

	@Override
	public void setEndBillId(String endBillId) {
		hpEndBillIdStr = endBillId;
	}

	@Override
	public void setExtractAlgorithm(Algorithm extractAlgorightm) {
		hpExtractAlgorithm = extractAlgorightm;
	}

	@Override
	public void setExtractDateTime(DateTime extractDttm) {
		hpExtractDateTime = extractDttm;
	}

	@Override
	public void setExtractFileName(String extractFileName) {
		hpExtractFileName = extractFileName;
	}

	@Override
	public void setFileHelper(FileHelper fileHelper) {
		hpFileHelper = fileHelper;
	}

	@Override
	public void setIsWriteSummary(Bool isWriteSummary) {
		hpIsWriteSummary = isWriteSummary;
	}

	@Override
	public void setNumberOfCopies(BigInteger nbrOfCopies) {
		hpNumberOfCopies = nbrOfCopies;
	}

	@Override
	public void setSequenceNumber(BigInteger sequenceNbr) {
		hpSequenceNumber = sequenceNbr;
	}

	@Override
	public void setStartBillId(String startBillId) {
		hpStartBillId = startBillId;
	}

	@Override
	public void setToBill(Bill toBill) {
		hpToBill = toBill;
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

		// Retrieve Parameter 10: Validate Parameter Switch 
		parmValidateParmSw = this.getValidateParameterSwitch();		
		if (parmValidateParmSw.isTrue()) {
			
			// Retrieve Parameter 20: Bill Print Header Description Lookup Field
			parmLookupFieldBillPrintHeaderDescr = this.getBillPrintHeaderDescriptionsLookupFieldName();		
			
			// Retrieve Parameter 30: Bill Correction Period Header Lookup Value
			parmLookupValueBillCorrectionPeriodHeader = this.getBillCorrectionPeriodHeaderLookupValue();			
			validateLookupValue(parmLookupFieldBillPrintHeaderDescr, 
					parmLookupValueBillCorrectionPeriodHeader, "Bill Correction Period Header Lookup Value");
			
			// Retrieve Parameter 40: Other Charges Header Lookup Value
			parmLookupValueOtherChargesHeader = this.getOtherChargesHeaderLookupValue();
			validateLookupValue(parmLookupFieldBillPrintHeaderDescr, 
					parmLookupValueOtherChargesHeader, "Other Charges Header Lookup Value");
			
			// Retrieve Parameter 50: Customer Payment Header Lookup Value
			parmLookupValueCustomerPaymentHeader = this.getCustomerPaymentHeaderLookupValue();
			validateLookupValue(parmLookupFieldBillPrintHeaderDescr,
					parmLookupValueCustomerPaymentHeader, "Customer Payment Header Lookup Value");
			
			// Retrieve Parameter 60: Pledge Payment Header Lookup Value
			parmLookupValuePledgePaymentHeader = this.getPledgePaymentHeaderLookupValue();
			validateLookupValue(parmLookupFieldBillPrintHeaderDescr,
					parmLookupValuePledgePaymentHeader, "Pledge Payment Header Lookup Value");
			
			// Retrieve Parameter 70: Remit To Characteristic Type
			parmCharTypeRemitTo = this.getRemitToCharType();
			validateCharacteristicType(parmCharTypeRemitTo, 
					CharacteristicEntityLookup.constants.ACCOUNT, "Remit To Characteristic Type");
			validateCharacteristicType(parmCharTypeRemitTo, 
					CharacteristicEntityLookup.constants.CIS_DIVISION, "Remit To Characteristic Type");
			
			// Retrieve Parameter 80: Default Remit To Characteristic Value
			parmCharValDefaultRemitTo = this.getDefaultRemitTo();
			validateCharacteristicValue(parmCharTypeRemitTo, parmCharValDefaultRemitTo, "Default Remit To Characteristic Value");
			
			// Retrieve Parameter 90: BTU Factor Service Quantity Identifier
			parmSQI_BTUFactor = this.getBtuFactorSQI();
			
			// Retrieve Parameter 100: Rate Class Description Characteristic Type
			parmCharTypeRateClassDescription = this.getRateClassDescriptionCharType();
			validateCharacteristicType(parmCharTypeRateClassDescription,
					CharacteristicEntityLookup.constants.RATE_COMPONENT, "Rate Class Description Characteristic Type");
			validateCharacteristicType(parmCharTypeRateClassDescription, 
					CharacteristicEntityLookup.constants.BILL_SEGMENT_CALC_LINE, "Rate Class Description Characteristic Type");
			
			// Retrieve Parameter 110: Utility Charges Headers Characteristic Type
			parmCharTypeUtilityChargesHeaders = this.getUtilityChargesHeadersCharType();
			validateCharacteristicType(parmCharTypeUtilityChargesHeaders,
					CharacteristicEntityLookup.constants.RATE_COMPONENT, "Utility Charges Headers Characteristic Type");
			validateCharacteristicType(parmCharTypeUtilityChargesHeaders, 
					CharacteristicEntityLookup.constants.BILL_SEGMENT_CALC_LINE, "Utility Charges Headers Characteristic Type");
			
			// Retrieve Parameter 120: Taxing Community Premise Characteristic Type
			parmCharTypeTaxingCommunityPremise = this.getTaxingCommunityPremiseCharType();
			validateCharacteristicType(parmCharTypeTaxingCommunityPremise, 
					CharacteristicEntityLookup.constants.PREMISE, "Taxing Community Premise Characteristic Type");			
			
			// Retrieve Parameter 130: Taxing Community Bill Line Characteristic Type
			parmCharTypeTaxingCommunityBillLine = this.getTaxingCommunityBillLineCharType();
			validateCharacteristicType(parmCharTypeTaxingCommunityBillLine, 
					CharacteristicEntityLookup.constants.RATE_COMPONENT, "Taxing Community Bill Line Characteristic Type");
			validateCharacteristicType(parmCharTypeTaxingCommunityBillLine, 
					CharacteristicEntityLookup.constants.BILL_SEGMENT_CALC_LINE, "Taxing Community Bill Line Characteristic Type");			
			
			// Retrieve Parameter 140: Gross Amount Characteristic Type
			parmCharTypeGrossAmount = this.getGrossAmountCharType();
			validateCharacteristicType(parmCharTypeGrossAmount, 
					CharacteristicEntityLookup.constants.RATE_COMPONENT, "Gross Amount Characteristic Type");
			validateCharacteristicType(parmCharTypeGrossAmount, 
					CharacteristicEntityLookup.constants.BILL_SEGMENT_CALC_LINE, "Gross Amount Characteristic Type");
			
			// Retrieve Parameter 150: Late Payment Adjustment Characteristic Type
			parmCharTypeLatePaymentAdjustment = this.getLatePaymentAdjustmentCharType();
			validateCharacteristicType(parmCharTypeLatePaymentAdjustment, 
					CharacteristicEntityLookup.constants.ADJUSTMENT_TYPE, "Late Payment Adjustment Characteristic Type");
			
			// Retrieve Parameter 160: Pledge Payment Characteristic Type
			parmCharTypePledgePayment = this.getPledgePaymentCharType();
			validateCharacteristicType(parmCharTypePledgePayment, 
					CharacteristicEntityLookup.constants.PAYMENT, "Pledge Payment Characteristic Type");			
			
			// Retrieve Parameter 170: Metered Service Type
			parmServiceTypeForMetered = this.getServiceTypeforMetered();
			
			// Retrieve Parameter 180: UnMetered Service Type
			parmServiceTypeForUnmetered = this.getServiceTypeforUnmetered();
			
			// Retrieve Parameter 190: Dollar Help SA Characteristic Type
			parmCharTypeDollarHelpSA = this.getDollarHelpSACharType();
			validateCharacteristicType(parmCharTypeDollarHelpSA, 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT_TYPE, "Dollar Help SA Characteristic Type");
			
			// Retrieve Parameter 200: Bill Calc Line Priority Characteristic Type
			parmCharTypeBillCalcLinePriority = this.getBillCalcLinePriorityCharType();
			validateCharacteristicType(parmCharTypeBillCalcLinePriority, 
					CharacteristicEntityLookup.constants.RATE_COMPONENT, "Bill Calc Line Priority Characteristic Type");
			validateCharacteristicType(parmCharTypeBillCalcLinePriority, 
					CharacteristicEntityLookup.constants.BILL_SEGMENT_CALC_LINE, "Bill Calc Line Priority Characteristic Type");
			
			// Retrieve Parameter 210: Additional Histogram UOM SA Type Characteristic Type
			parmCharTypeAdditionalHistogramUOMSAType = this.getAdditionalHistogramUOMSATypeCharType();
			validateCharacteristicType(parmCharTypeAdditionalHistogramUOMSAType, 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT_TYPE, "Additional Histogram UOM SA Type Characteristic Type");
			
			// Retrieve Parameter 220: Additional Histogram SQI SA Type Characteristic Type
			parmCharTypeAdditionalHistogramSQISAType = this.getAdditionalHistogramSQISATypeCharType();
			validateCharacteristicType(parmCharTypeAdditionalHistogramSQISAType, 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT_TYPE, "Additional Histogram SQI SA Type Characteristic Type");
			
			// Retrieve Parameter 230: Contract Number SA Characteristic Type
			parmCharTypeContractNumberSA = this.getContractNumberSACharType();
			validateCharacteristicType(parmCharTypeContractNumberSA, 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT, "Contract Number SA Characteristic Type");
			
			// Retrieve Parameter 240: Propane Billable UOM
			parmUOMPropaneBillable = this.getPropaneBillableUOM();
			
			// Retrieve Parameter 250: School Aggregation Account Characteristic Type
			parmCharTypeSchoolAggregationAccount = this.getSchoolAggregationAccountCharType();
			validateCharacteristicType(parmCharTypeSchoolAggregationAccount, 
					CharacteristicEntityLookup.constants.ACCOUNT, "School Aggregation Account Characteristic Type");
			
			// Retrieve Parameter 260: School Aggregation Account Characteristic Value
			parmCharValueSchoolAggregationAccount = this.getSchoolAggregationAccountCharValue();
			validateCharacteristicValue(parmCharTypeSchoolAggregationAccount, 
					parmCharValueSchoolAggregationAccount, "School Aggregation Account Characteristic Value");
			
			// Retrieve Parameter 270: Budget Payment Arrangement Characteristic Type
			parmCharTypeBudgetPaymentArrangement = this.getBudgetPaymentArrangementCharType();
			validateCharacteristicType(parmCharTypeBudgetPaymentArrangement, 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT_TYPE, "Budget Payment Arrangement Characteristic Type");
			
			// Retrieve Parameter 280: Rate Class Characteristic Type
			parmCharTypeRateClass = this.getRateClassCharacteristicType();
			validateCharacteristicType(parmCharTypeRateClass, 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT, "Rate Class Characteristic Type");
			
			// Start Add - JTIOZON - CCB-047
			// Retrieve Parameter 290: CWR Bill Message Code
			parmCWRBillMessageType = this.getCwrBillMessageCode();
			
			// Retrieve Parameter 300: Non-CWR Bill Message Code
			parmNonCWRBillMessageType = this.getNonCwrBillMessageCode();
		
			//End Add - JTIOZON - CCB-047
			// Start Add - DLampa - 2024-07-30 - INC0037039
			// Retrieve Parameter 310: CIS Division Company Code Characteristic Type
			parmCharTypeCisDivisionCompanyCode = this.getCisDivisionCompanyCodeCharType();
			validateCharacteristicType(parmCharTypeCisDivisionCompanyCode, 
                    CharacteristicEntityLookup.constants.CIS_DIVISION, "CIS Division Company Code Characteristic Type");
			// End Add - DLampa - 2024-07-30 - INC0037039			
		}
		else {
			// Retrieve Parameter 20: Bill Print Header Description Lookup Field
			parmLookupFieldBillPrintHeaderDescr = this.getBillPrintHeaderDescriptionsLookupFieldName();		
			// Retrieve Parameter 30: Bill Correction Period Header Lookup Value
			parmLookupValueBillCorrectionPeriodHeader = this.getBillCorrectionPeriodHeaderLookupValue();
			// Retrieve Parameter 40: Other Charges Header Lookup Value
			parmLookupValueOtherChargesHeader = this.getOtherChargesHeaderLookupValue();
			// Retrieve Parameter 50: Customer Payment Header Lookup Value
			parmLookupValueCustomerPaymentHeader = this.getCustomerPaymentHeaderLookupValue();
			// Retrieve Parameter 60: Pledge Payment Header Lookup Value
			parmLookupValuePledgePaymentHeader = this.getPledgePaymentHeaderLookupValue();
			// Retrieve Parameter 70: Remit To Characteristic Type
			parmCharTypeRemitTo = this.getRemitToCharType();
			// Retrieve Parameter 80: Default Remit To Characteristic Value
			parmCharValDefaultRemitTo = this.getDefaultRemitTo();
			// Retrieve Parameter 90: BTU Factor Service Quantity Identifier
			parmSQI_BTUFactor = this.getBtuFactorSQI();
			// Retrieve Parameter 100: Rate Class Description Characteristic Type
			parmCharTypeRateClassDescription = this.getRateClassDescriptionCharType();
			// Retrieve Parameter 110: Utility Charges Headers Characteristic Type
			parmCharTypeUtilityChargesHeaders = this.getUtilityChargesHeadersCharType();
			// Retrieve Parameter 120: Taxing Community Premise Characteristic Type
			parmCharTypeTaxingCommunityPremise = this.getTaxingCommunityPremiseCharType();
			// Retrieve Parameter 130: Taxing Community Bill Line Characteristic Type
			parmCharTypeTaxingCommunityBillLine = this.getTaxingCommunityBillLineCharType();
			// Retrieve Parameter 140: Gross Amount Characteristic Type
			parmCharTypeGrossAmount = this.getGrossAmountCharType();
			// Retrieve Parameter 150: Late Payment Adjustment Characteristic Type
			parmCharTypeLatePaymentAdjustment = this.getLatePaymentAdjustmentCharType();
			// Retrieve Parameter 160: Pledge Payment Characteristic Type
			parmCharTypePledgePayment = this.getPledgePaymentCharType();
			// Retrieve Parameter 170: Metered Service Type
			parmServiceTypeForMetered = this.getServiceTypeforMetered();
			// Retrieve Parameter 180: UnMetered Service Type
			parmServiceTypeForUnmetered = this.getServiceTypeforUnmetered();
			// Retrieve Parameter 190: Dollar Help SA Characteristic Type
			parmCharTypeDollarHelpSA = this.getDollarHelpSACharType();
			// Retrieve Parameter 200: Bill Calc Line Priority Characteristic Type
			parmCharTypeBillCalcLinePriority = this.getBillCalcLinePriorityCharType();
			// Retrieve Parameter 210: Additional Histogram UOM SA Type Characteristic Type
			parmCharTypeAdditionalHistogramUOMSAType = this.getAdditionalHistogramUOMSATypeCharType();
			// Retrieve Parameter 220: Additional Histogram SQI SA Type Characteristic Type
			parmCharTypeAdditionalHistogramSQISAType = this.getAdditionalHistogramSQISATypeCharType();
			// Retrieve Parameter 230: Contract Number SA Characteristic Type
			parmCharTypeContractNumberSA = this.getContractNumberSACharType();
			// Retrieve Parameter 240: Propane Billable UOM
			parmUOMPropaneBillable = this.getPropaneBillableUOM();
			// Retrieve Parameter 250: School Aggregation Account Characteristic Type
			parmCharTypeSchoolAggregationAccount = this.getSchoolAggregationAccountCharType();
			// Retrieve Parameter 260: School Aggregation Account Characteristic Value
			parmCharValueSchoolAggregationAccount = this.getSchoolAggregationAccountCharValue();
			// Retrieve Parameter 270: Budget Payment Arrangement Characteristic Type
			parmCharTypeBudgetPaymentArrangement = this.getBudgetPaymentArrangementCharType();
			// Retrieve Parameter 280: Rate Class Characteristic Type
			parmCharTypeRateClass = this.getRateClassCharacteristicType();
			
			// Start Add - JTIOZON - CCB-047
			// Retrieve Parameter 290: CWR Bill Message Code
			parmCWRBillMessageType = this.getCwrBillMessageCode();
						
			// Retrieve Parameter 300: Non-CWR Bill Message Code
			parmNonCWRBillMessageType = this.getNonCwrBillMessageCode();						
			
			//End Add - JTIOZON - CCB-047
			// Start Add - DLampa - 2024-07-30 - INC0037039
			// Retrieve Parameter 310: CIS Division Company Code Characteristic Type
			parmCharTypeCisDivisionCompanyCode = this.getCisDivisionCompanyCodeCharType();
			// End Add - DLampa - 2024-07-30 - INC0037039
		}
		
		// Initialize		
		wLineSeq = 0;
		wBudgetPlanDescr = " ";
		wBudgetPlanID = null;		
		wMainPerson = null;
		wMainPersonName= null;
		wBillApaySchedExtractDt = null;
		wCorrStartDt = null;
		wCorrEndDt = null;		
		wIsFinalBillSw = Bool.FALSE;
		wIsCashOnlySw = Bool.FALSE;		
		wWithPremiseSw = Bool.FALSE;		
		wWithSaSw = Bool.FALSE;
		wWithBsegSw = Bool.FALSE;
		wWithCalcHdrSw = Bool.FALSE;
		wPossibleDuplPremSw = Bool.FALSE;
		wDummyPremRecExistsSw = Bool.FALSE;
		wNonPremSw = Bool.FALSE;
		wSkipPremSw = Bool.FALSE;
		wCalclnHdrExistsSw = Bool.FALSE;
		wCalclnSeqExistsSw = Bool.FALSE;
		wBillRouting = null;
		wPremID = null;
		wUomCd = null;
		wTouCd = null;
		wSqiCd = null;
		wTaxCommDescr = " ";
		wS_READTYP_OUT_DATA_readTypeFlg = null;
		wS_SA_OUT_DATA_GraphUomCd = null;
		wS_SA_OUT_DATA_SaID = null;
		wS_SA_OUT_DATA_CisDivID = null;
		wS_SA_OUT_DATA_SATypeCd = " ";
		wS_SA_OUT_DATA_saStatusFlg = null;
		wS_SA_OUT_DATA_acctID = null;
		wS_SA_OUT_DATA_startDt = null;
		wS_SA_OUT_DATA_endDt = null;
		wS_SA_OUT_DATA_oldAcctID = null;
		wS_SA_OUT_DATA_allowEstSw = Bool.FALSE;
		wS_SA_OUT_DATA_custReadFlg = null;
		wS_SA_OUT_DATA_sicCodeID = null;
		wS_SA_OUT_DATA_charPremID = null;
		wS_SA_OUT_DATA_startOptCd = null;		
		wS_SA_OUT_DATA_currencyCd = null;
		wS_SA_OUT_DATA_saRelID = null;
		wS_SA_OUT_DATA_descr = " ";
		wS_SA_OUT_DATA_dfltDescrOnBill = " ";
		wS_SA_OUT_DATA_revClCd = null;
		wS_SA_OUT_DATA_billPrtPrioFlg = null;
		wS_SA_OUT_DATA_svcTypeCd = null;
		wS_SA_OUT_DATA_specialRoleFlg = null;
		wS_SA_OUT_DATA_svcTypeDescr = " ";
		wS_SA_OUT_DATA_revClDescr = " ";
		wS_SA_OUT_DATA_totToBillAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wSAREL_OUT_DATA_saRelID = null;
		wSAREL_OUT_DATA_sarSaID = null;
		wSAREL_OUT_DATA_saRelTypeID = null;
		wSAREL_OUT_DATA_saExtRefID = " ";
		wSAREL_OUT_DATA_saRelStatusFlg = null;
		wSAREL_OUT_DATA_sprCd = null;
		wSAREL_OUT_DATA_descr = " ";
		wSAREL_OUT_DATA_descr50 = " ";
		wSAREL_OUT_DATA_sprSaID = null;
		wSAREL_OUT_DATA_ntXidCd = null;
		wSAREL_OUT_DATA_billRelFlg = null;
		wSAREL_OUT_DATA_perID = null;
		wSAREL_OUT_DATA_entityName = " ";
		wS_BSEGSQ_OUT_DATA_initSq = BigDecimal.ZERO;
		wS_BSEGSQ_OUT_DATA_billSq = BigDecimal.ZERO;		
		wS_READDTL_OUT_DATA_readTypeFlg = null;
		wS_READDTL_OUT_DATA_badgeNbr = " ";
		wS_READDTL_OUT_DATA_serialNbr = " ";
		wS_READDTL_OUT_DATA_consumSubFlg = null;
		wS_READDTL_OUT_DATA_nbrOfDgtsRgt = BigInteger.ZERO;
		wS_READDTL_OUT_DATA_regId = null;
		wS_READDTL_OUT_DATA_nbrOfDgtsLft = BigInteger.ZERO;
				
		wBillBalCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBillBalTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBillChargeCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBillChargeTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBillCorrCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBillCorrTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBillAdjCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBillAdjTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBillPayCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBillPayTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wCurrPrevBal = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wTotPrevBal = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wDelinquentAmt  = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wCurrPldgPayAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wTotPldgPayAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wCurrLpcAdjAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wTotLpcAdjAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);		
		wBsegFtCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBsegFtTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wTotalGrossAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wClCharCalcAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wCurrPACurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wCurrPATotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wDHCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wDHTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wCorrCanAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wCorrBillAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wCorrTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wOtherAdjCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wDepLoanAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wNewTotCurrChgAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wDepLoanCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wDepLoanTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wNewPrevBalAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wNewPrevGasBalAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wNewPrevOthrBalAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wNewTotalBalAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID); 
		wTotAmtBilled = new Money(BigDecimal.ZERO, wAccountCurrencyID);	
		wBudgetRecurringChargeAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wOthersTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID); 
		
		wBillDetailRecord = new CmPostRouteBillExtractDetailsBillDetailsRecord();
		wSortKeyRecord = new CmPostRouteBillExtractSortKeyRecord();
		wMailingKeyRecord = new CmPostRouteBillExtractMailingKeyRecord();
		wPrinterKeyRecord = new CmPostRouteBillExtractPrinterKeyRecord();
		wPAChargesRecord = new CmPostRouteBillExtractDetailsPAChargesRecord();
		wCurrChargesDebtClassRecord = new CmPostRouteBillExtractDetailsCurrentChargeDebtClassRecord();
		wCorrectionChargesRecord = new CmPostRouteBillExtractDetailsCorrectionChargesRecord();
		wOtherChargesRecord = new CmPostRouteBillExtractDetailsOtherChargesRecord();
		wPaymentDetailsRecord = new CmPostRouteBillExtractDetailsPaymentDetailsRecord();
		wBillMessageRecord = new CmPostRouteBillExtractDetailsBillMessageRecord();
		wHistogramRecord = new CmPostRouteBillExtractDetailsHistogramRecord(1);
		wAdjDetailRecord = new CmPostRouteBillExtractDetailsAdjustmentDetailsRecord();
		wPremiseDetailRecord = new CmPostRouteBillExtractDetailsPremiseDetailsRecord();
		wSaDetailRecord = new CmPostRouteBillExtractDetailsSADetailsRecord();
		wBsegDetailRecord = new CmPostRouteBillExtractDetailsBillSegmentDetailRecord();
		wBillCalcHdrRecord = new CmPostRouteBillExtractDetailsBillCalcHeaderRecord();
		wBillCalcLineRecord = new CmPostRouteBillExtractDetailsBillCalcLineRecord();
		wBsegMessageRecord = new CmPostRouteBillExtractDetailsBillSegmentMessageRecord();
		wBsegReadRecord = new CmPostRouteBillExtractDetailsBillSegmentReadRecord();
		wBsegSqRecord = new CmPostRouteBillExtractDetailsBillSegmentSQRecord();
		wBsegItemRecord = new CmPostRouteBillExtractDetailsBillSegmentItemRecord();
		
		this.getCiInstallationValues();
	}
	
	private void validateLookupValue(LookupField lookupField, String lookupValue, String parmDescr) {
		
		LookupValue_Id lookupValueID = new LookupValue_Id(lookupField, lookupValue);
		if (isNull(lookupValueID.getEntity())) {
			addError(CustomMessageRepositoryMGE.
					commAlgorithmParameterLookupValueInvalidForLookupField(
							this.getAlgorithmId().getTrimmedValue(),
							parmDescr, lookupValue, lookupField.getId().getTrimmedValue()));
		}		
	}
	
	private void validateCharacteristicType(CharacteristicType charType, CharacteristicEntityLookup entity, String parmDescr) {
		
		CharacteristicEntity_Id charEntityID = new CharacteristicEntity_Id(charType, entity);
		if (isNull(charEntityID.getEntity())) {
			addError(CustomMessageRepositoryMGE.
					commAlgorithmParameterCharTypeNotValidForEntity(
							this.getAlgorithmId().getTrimmedValue(), 
							parmDescr, charType.getId().getTrimmedValue(), 
							entity.getLookupValue().fetchLanguageDescription().trim()));
		}		
	}
	
	private void validateCharacteristicValue(CharacteristicType charType, String charValue, String parmDescr) {
		
		if (charType.getCharacteristicType().isPredefinedValue()) {
			CharacteristicValue_Id charValueID = new CharacteristicValue_Id(charType, charValue);
			if (isNull(charValueID.getEntity())) {
				addError(CustomMessageRepositoryMGE.
						commAlgorithmParameterCharValueNotValidForCharType(
								this.getAlgorithmId().getTrimmedValue(), 
								parmDescr, charValue, charType.getId().getTrimmedValue()));
			}
		}
	}
	
	@Override
	public void invoke() {

		wBillRouting = new BillRouting_Id(hpBill, hpSequenceNumber).getEntity();
		wAccountCurrencyID = hpBill.getAccount().getCurrency().getId();
		wAcct = hpBill.getAccount();
		wBillDt = hpBill.getBillDate();
		
		// Start Add - DLampa - 2024-09-17 - INC0037039.Issue1
		for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {
			hpNumberOfCopiesIdx = String.valueOf(x);
		// End Add - DLampa - 2024-09-17 - INC0037039.Issue1		
			// Prepare Bill Info and Summary Charges Amounts
			extractMainBillDetails();
			
			if (hpIsBillSkipped.isFalse()) {
				// Prepare Main Extract
				prepareMainExtract();
				// Prepare the details on payments and current charges
				billCharges();
				// Prepare the details on bill messages
				billMessages();
				// Prepare the details on charges and adjustments (by prem/sa)
				premiseGroup();
				// Prepare the record to designate the end of a bill.
				endOfBill();
			}		
		// Start Add - DLampa - 2024-09-17 - INC0037039.Issue1
		}
		// End Add - DLampa - 2024-09-17 - INC0037039.Issue1		
		
		HibernateCacheHelper.flushAndClear();
	}
	
	private void endOfBill() {
		
		// End of Bill record
		/*SET BILL-END OF BILL-PRINT-SORT-KEY TO TRUE*/
		wSortKeyRecord.setBillRecordGroupSeq(CmPostRouteBillExtractSortKeyRecord.BILL_END);
		/*SET BP-EXTR-TYPE-END-BILL TO TRUE*/
		wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_END_BILL);
		/*INITIALIZE PREMISE-SEQ PREM-REC-GRP*/
		wSortKeyRecord.setPremRecGrpSeq(" ");
		wSortKeyRecord.STATE = " ";
		wSortKeyRecord.CITY = " ";
		wSortKeyRecord.ADDRESS1 = " ";
		wSortKeyRecord.PREMISE = " ";
		wSortKeyRecord.setPremiseSeq();
				
//		wBillDetailRecord = new CmPostRouteBillExtractDetailsBillDetailsRecord();
//		wBillDetailRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
//		wBillDetailRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
		CmPostRouteBillExtractGenericEndRecord endBillRecord = new CmPostRouteBillExtractGenericEndRecord();
		endBillRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
		endBillRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());

		/*PERFORM MX010-WRITE-EXTRACT-DATA*/		
		/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
		 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
		 */  
		// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
		//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

			/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
			//wSortKeyRecord.setCopyNbr(String.valueOf(x));
			wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
	    // End Change - DLampa - 2024-09-17 - INC0037039.Issue1			
			endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());
			endBillRecord.setFiller(3241);
			hpFileHelper.appendWriteClose(endBillRecord);		
		// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1			
		//}
	    // End Delete - DLampa - 2024-09-17 - INC0037039.Issue1	
	}
	
	private void premiseGroup() {
		
		// Get the details on SA's with current charges (bsegs + adj)
		// Premise
		/*SET SW-NO OF WITH-PREMISE-SW TO TRUE*/
		wWithPremiseSw = Bool.FALSE;
		// Prepare the Details on SAs with current charges (bsegs)
		bsegSA();
		// Prepare the details on SAs with adjustments only
		/*PERFORM MG010-ADJ-ONLY-SA*/
		adjOnlySA();
		// End of Premise if there was one
		if (wWithPremiseSw.isTrue()) {
			if (wNonPremSw.isFalse()) {
				/*PERFORM MZ040-END-OF-PREMISE*/
				endOfPremise();
			}
		}
	}
	
	private void adjOnlySA() {
		
		// Get the Adjustments for SA's without bill segments.
		
		/*
		 * Since it is possible for a bill to have multiple SAs and
		 * SAs can have adjustments only, avoid duplicating premises
		 * which have been added (since they have other SAs with bsegs)
		 */
		/*SET SW-YES OF W-POSSIBLE-DUPL-PREM-SW TO TRUE*/
		wPossibleDuplPremSw = Bool.TRUE;
		// Service Agreement
		/*SET SW-NO OF WITH-SA-SW TO TRUE*/
		wWithSaSw = Bool.FALSE;
		// Adjustments
		Iterator<SQLResultRow> collAdjOnly = getAdjOnly(hpBill, wAcct);
		
		while (collAdjOnly.hasNext()) {
			
			SQLResultRow sqlRow = (SQLResultRow) collAdjOnly.next();
			Premise_Id charPremID = (Premise_Id) sqlRow.getId("CHAR_PREM_ID", Premise.class);
			@SuppressWarnings("unused")
			BillPrintPriorityLookup billPrintPrioFlg = (BillPrintPriorityLookup) 
					sqlRow.getLookup("BILL_PRT_PRIO_FLG", BillPrintPriorityLookup.class);
			ServiceAgreement_Id saID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
			
			// Initial Premise or Change of Premise
			if (wWithPremiseSw.isFalse()
					|| (wPremID.compareTo(charPremID) != 0)) {
				// end of sa (previous)
				if (wWithSaSw.isTrue()) {
					/*PERFORM MZ030-END-OF-SA*/
					endOfSa();
				}
				
				if (wWithPremiseSw.isTrue()) {
					if (wNonPremSw.isFalse()) {
						// end of premise (previous)
						/*PERFORM MZ040-END-OF-PREMISE*/
						endOfPremise();
					}
				}
				// premise
				/*MOVE CHAR-PREM-ID OF S-ADJONLY TO PREM-ID OF W-WRK*/
				wPremID = charPremID;
				/*PERFORM MM010-PREMISE-DETAILS*/
				premiseDetails();
			}
			// Initial SA or Change of SA
			if (wWithSaSw.isFalse()
					|| wS_SA_OUT_DATA_SaID.compareTo(saID) != 0) {
				if (wWithSaSw.isTrue()) {
					// end of sa (previous)
					/*PERFORM MZ030-END-OF-SA*/
					endOfSa();
				}
				/*PERFORM MK010-SA-DETAILS*/
				saDetails(saID);				
			}
			// Adjustments
			/*PERFORM MI010-SA-ADJ*/
			saAdj();
		}
		// end of SA if there was one
		if (wWithSaSw.isTrue()) {
			/*PERFORM MZ030-END-OF-SA*/
			endOfSa();
		}
	}
	
	private void bsegSA() {
	
		// Get the details of SAs with bill segments.
		/*SET SW-NO OF W-POSSIBLE-DUPL-PREM-SW TO TRUE*/
		wPossibleDuplPremSw = Bool.FALSE;
		/*SET SW-NO OF W-DUMMY-PREM-REC-EXISTS TO TRUE*/
		wDummyPremRecExistsSw = Bool.FALSE;
		// Service Agreement
		/*SET SW-NO OF WITH-SA-SW*/
		wWithSaSw = Bool.FALSE;
		Iterator<SQLResultRow> collOfBsegs = getBsegs(hpBill);
		
		while(collOfBsegs.hasNext()) {
			SQLResultRow sqlRow = (SQLResultRow) collOfBsegs.next();
			Premise_Id bsegPremID = (Premise_Id) sqlRow.getId("PREM_ID", Premise.class);
			
			// Start Add- DLampa - 2024-12-05 - E-09959
			// If the bill segment being processed is for a deposit SA, set the Premise Id to blank  
			// so that the records are printed in the non-premise layout
			ServiceAgreement_Id wS_BSEG_OUT_saID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
			
			if (wS_BSEG_OUT_saID.getEntity().getServiceAgreementType().getSpecialRole().isCashDeposit()) {
				bsegPremID = Premise_Id.NULL;
			}
				
			// End Add - DLampa - 2024-12-05 - E-09959

			// Initial Premise or change of premise
			if (wWithPremiseSw.isFalse()
					|| wPremID.compareTo(bsegPremID) != 0) {

				// End of Bseg (previous)
				if (wWithBsegSw.isTrue()) {
					/*PERFORM MZ020-END-OF-BSEG*/
					endOfBseg();
				}
				// End of SA (previous)
				if (wWithSaSw.isTrue()) {
					// Histogram
					if (wNonPremSw.isFalse()) {
						/*PERFORM  ME030-SA-HISTOGRAM*/
						saHistogram();					
					}
					// Adjustments
					/*PERFORM MI010-SA-ADJ*/
					saAdj();
					/*PERFORM MZ030-END-OF-SA*/
					endOfSa();
				}
				// End of Premise (previous)
				if (wWithPremiseSw.isTrue()) {
					if (wNonPremSw.isFalse()) {
						/*PERFORM MZ040-END-OF-PREMISE*/
						endOfPremise();
					}
				}
				// Premise
				/*MOVE PREM-ID OF BSEG-OUT-DATA TO PREM-ID OF W-WRK*/
				wPremID = bsegPremID;
				/*PREMISE MM010-PREMISE-DETAILS*/
				premiseDetails();
			}

			// Initial SA or change of SA
			// Start Delete - DLampa - 2024-12-05 - E-09959	
			// Moving snippet to after the premise is derived as we need to check if a deposit SA is being processed  
			//ServiceAgreement_Id wS_BSEG_OUT_saID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
			// End Delete - DLampa - 2024-12-05 - E-09959
			if (wWithSaSw.isFalse()
					|| wS_SA_OUT_DATA_SaID.compareTo(wS_BSEG_OUT_saID) != 0) {
				if (wWithSaSw.isTrue()) {
					// end of bseg
					if (wWithBsegSw.isTrue()) {
						endOfBseg();
					}
					// Histogram
					if (wNonPremSw.isFalse()) {
						saHistogram();
					}
					// Adjustments
					saAdj();
					// end of sa (previous)
					endOfSa();
				}
				saDetails(wS_BSEG_OUT_saID);
			}
			// End of Bseg (previous)
			if (wWithBsegSw.isTrue()) {
				endOfBseg();
			}
			// Bill Segment (and details)
			BillSegment_Id bsegID = (BillSegment_Id) sqlRow.getId("BSEG_ID", BillSegment.class);
			bsegDetails(bsegID);		
		} // END-PERFORM
		
		// end of bseg if there was one
		if (wWithBsegSw.isTrue()) {
			/*PERFORM MZ020-END-OF-BSEG*/
			endOfBseg();
		}
		// end of sa if there was one
		if (wWithSaSw.isTrue()) {
			// Histogram
			if (wNonPremSw.isFalse()) {
				/*PERFORM ME030-SA-HISTOGRAM*/
				saHistogram();
			}
			// Adjustments
			/*PERFORM MI010-SA-ADJ*/
			saAdj();
			/*PERFORM MZ030-END-OF-SA*/
			endOfSa();
		}	
	}		
	
	private void bsegDetails(BillSegment_Id bsegID) {
		
		// Get the details on calc headers and calc lines.
		// Get Bill Segment Details (bseg, hdrs, lines, Rds, SQs, Items)
		BillSegment billSegment = bsegID.getEntity();
		
		if (wNonPremSw.isFalse()) {
			/*SET SA-REC-CURRENT-CHARGE OF SA-DETAIL-SECTION TO TRUE*/
			wSortKeyRecord.setSaRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.SA_REC_CURRENT_CHARGE);
			/*SET BSEG-REC-BSEG-DTL OF BSEG-ADJ-DETAIL-SECTION TO TRUE*/
			wSortKeyRecord.setBsegRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.BSEG_REC_BSEG_DTL);
			/*MOVE BSEG-ID OF BBLST TO BSEG-ID OF BSEG-ADJ-DETAIL-SECTION*/
			wSortKeyRecord.setBsegID(bsegID.getTrimmedValue());
			/*MOVE END-DT OF BBLST TO BSEG-END-DT OF BSEG-ADJ-DETAIL-SECTION*/
			wSortKeyRecord.setBsegEndDt(billSegment.getEndDate().toString().trim());
		}
		else {
			/*SET SA-REC-CURRENT-CHARGE OF NONPREM-SA-SEQ TO TRUE*/
			wSortKeyRecord.NP_SA_REC_GRP_SEQ = CmPostRouteBillExtractSortKeyRecord.NP_SA_REC_CURRENT_CHARGE;			
			/*SET BSEG-REC-BSEG-DTL OF NP-BSEG-ADJ-DETAIL-SECTION TO TRUE*/
			wSortKeyRecord.NP_BSEG_REC_GRP_SEQ = CmPostRouteBillExtractSortKeyRecord.BSEG_REC_BSEG_DTL;
			/*MOVE BSEG-ID OF BBLST TO NP-BSEG-ID OF NP-BSEG-ADJ-DETAIL-SECTION*/
			if (notNull(bsegID)) {
				wSortKeyRecord.NP_BSEG_ID = bsegID.getTrimmedValue();
			}
			/*MOVE END-DT OF BBLST TO NP-BSEG-END-DT OF NP-BSEG-ADJ-DETAIL-SECTION*/
			if (notNull(billSegment) 
					&& notNull(billSegment.getEndDate())) {
				wSortKeyRecord.NP_BSEG_END_DT = billSegment.getEndDate().toString().trim(); 
			}
			wSortKeyRecord.setNonPremSaSeq();
		}
		/*SW-YES OF WITH-BSEG-SW TO TRUE*/
		wWithBsegSw = Bool.TRUE;
		
		// Bill Segment
		/*PERFORM SQ140-GET-BSEGFT*/
		getBsegFT(hpBill, 
				billSegment.getServiceAgreement().getId(), 
				bsegID);
		
		/*INITIALIZE BP-EXTR-DTL-BSEG OF BBPXT*/
		wBsegDetailRecord = new CmPostRouteBillExtractDetailsBillSegmentDetailRecord();
		/*SET BP-EXTR-TYPE-DTL-BSEG OF BBPXT TO TRUE*/
		wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_BSEG);
		/*MOVE CORR BBLST TO BP-EXTR-DTL-BSEG OF BBPXT*/
		wBsegDetailRecord.setStartDate(billSegment.getStartDate().toString().trim());
		wBsegDetailRecord.setEndDate(billSegment.getEndDate().toString().trim());
		wBsegDetailRecord.setClosingBsegSw(transformToYorN(billSegment.getIsClosingBillSegment()));
		wBsegDetailRecord.setEstimateSw(transformToYorN(billSegment.getIsEstimate()));
		if (notNull(billSegment.getBillCycleScheduleId())
				&& notNull(billSegment.getBillCycleScheduleId().getBillCycleId())) {
			wBsegDetailRecord.setBillCycleCd(billSegment.getBillCycleScheduleId().getBillCycleId().getTrimmedValue());
		}				
		wBsegDetailRecord.setServiceQuantityOverrideSw(transformToYorN(billSegment.getHasServiceQuantityOverride()));
		wBsegDetailRecord.setItemOverrideSw(transformToYorN(billSegment.getIsItemOverride()));
		wBsegDetailRecord.setBsegStatFlg(billSegment.getBillSegmentStatus().trimmedValue());
		if (notNull(billSegment.getCancelReasonId())
				&& notNull(billSegment.getCancelReasonId().getEntity())) {
			wBsegDetailRecord.setCanRsnCd(billSegment.getCancelReasonId().getTrimmedValue());
			wBsegDetailRecord.setCanRsnDescr(billSegment.fetchCancelReason().fetchLanguageDescription());
		}
		/*MOVE CORR OF S-BSEGFT TO BP-EXTR-DTL-BSEG OF BBPXT*/
		wBsegDetailRecord.setCurAmt(wBsegFtCurAmt.getAmount(), transformImpliedBD(wBsegFtCurAmt.getAmount(), 2));
		wBsegDetailRecord.setTotAmt(wBsegFtTotAmt.getAmount(), transformImpliedBD(wBsegFtTotAmt.getAmount(), 2));
		
		/*PERFORM NA080-BSEG-CUSTOM-FIELDS*/
		bsegCustomFields(bsegID);

		wBsegDetailRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
		wBsegDetailRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
		
		/*PERFORM MX010-WRITE-EXTRACT-DATA*/
		/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
		 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
		 */ 
		// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
		//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

			/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
			//wSortKeyRecord.setCopyNbr(String.valueOf(x));
			wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
		// End Change - DLampa - 2024-09-17 - INC0037039.Issue1
			wBsegDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());								
			hpFileHelper.appendWriteClose(wBsegDetailRecord);	
		// Start Delete- DLampa - 2024-09-17 - INC0037039.Issue1			
		//}
		// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1
		
		// Bill Segment Calc Header
		/*SET SW-NO OF WITH-CALCHDR-SW TO TRUE*/
		int bsegCalcHdrCnt = 0;
		wWithCalcHdrSw = Bool.FALSE;
		Iterator<BillSegmentCalculationHeader> collOfBsegCalcHdrs = billSegment.getCalculationHeaders().iterator();
		while (collOfBsegCalcHdrs.hasNext()) {
			
			bsegCalcHdrCnt++;
			BillSegmentCalculationHeader bsegCalcHdr = (BillSegmentCalculationHeader) collOfBsegCalcHdrs.next();
			
			if (wWithCalcHdrSw.isTrue()) {
				/*
				 * this means that this is another bseg calc header
				 * the previous bseg calc header must be terminated.
				 */
				if (wNonPremSw.isFalse()) {
					/*SET CALCHDR-REC-END OF CALC-HDR-LINE-DETAIL-SECTION TO TRUE*/
					wSortKeyRecord.setCalcHdrRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.CALCHDR_REC_END);
				}
				else {
					/*SET CALCHDR-REC-END OF NP-CALC-HDR-LINE-DETAIL-SECTION TO TRUE*/
					wSortKeyRecord.NP_CALCHDR_REC_GRP_SEQ = CmPostRouteBillExtractSortKeyRecord.CALCHDR_REC_END;
					wSortKeyRecord.setNonPremSaSeq();
				}
				/*SET BP-EXTR-TYPE-END-CALCHDR TO TRUE*/
				wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_END_CALCHDR);
				
				/*
				 * NOT SURE with the wBillCalcHdrRecord is the column delimited record to write
				 */
//				wBillCalcHdrRecord = new CmPostRouteBillExtractDetailsBillCalcHeaderRecord();
//				wBillCalcHdrRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
//				wBillCalcHdrRecord.setBPSortKey(wSortKeyRecord.createRecordString());
//				wBillCalcHdrRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
				CmPostRouteBillExtractGenericEndRecord endBillRecord = new CmPostRouteBillExtractGenericEndRecord();
				endBillRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
				endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());
				endBillRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
				
				/*PERFORM MX010-WRITE-EXTRACT-DATA*/
				/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
				 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
				 */
				// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
				//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

					/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
					//wSortKeyRecord.setCopyNbr(String.valueOf(x));
					wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
				// End Change - DLampa - 2024-09-17 - INC0037039.Issue1					
					endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());	
					endBillRecord.setFiller(3241);
					hpFileHelper.appendWriteClose(endBillRecord);		
				// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1
				//}				
				// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1
			}
			
			if (wNonPremSw.isFalse()) {
				/*SET BSEG-REC-CALC OF BSEG-ADJ-DETAIL-SECTION TO TRUE*/
				wSortKeyRecord.setBsegRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.BSEG_REC_CALC);
				/*SET CALCHDR-REC-HEADER OF CALC-HDR-LINE-DETAIL-SECTION TO TRUE*/
				wSortKeyRecord.setCalcHdrRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.CALCHDR_REC_HEADER);
				/*MOVE W-CALCHDR-CNT TO CALCHDR-SEQ OF CALC-HDR-LINE-DETAIL-SECTION*/
				wSortKeyRecord.setCalcHdrSeq(String.valueOf(bsegCalcHdrCnt));
			}
			else {
				/*SET BSEG-REC-CALC OF NP-BSEG-ADJ-DETAIL-SECTION TO TRUE*/
				wSortKeyRecord.NP_BSEG_REC_GRP_SEQ = CmPostRouteBillExtractSortKeyRecord.BSEG_REC_CALC; 
				/*SET CALCHDR-REC-HEADER OF NP-CALC-HDR-LINE-DETAIL-SECTION TO TRUE*/
				wSortKeyRecord.NP_CALCHDR_REC_GRP_SEQ = CmPostRouteBillExtractSortKeyRecord.CALCHDR_REC_HEADER; 
				/*MOVE W-CALCHDR-CNT TO NP-CALCHDR-SEQ OF NP-CALC-HDR-LINE-DETAIL-SECTION*/
				wSortKeyRecord.NP_CALCHDR_SEQ = String.valueOf(bsegCalcHdrCnt);
				wSortKeyRecord.setNonPremSaSeq();
			}
			/*SET SW-YES OF WITH-CALCHDR-SW TO TRUE*/
			wWithCalcHdrSw = Bool.TRUE;
			/*INITIALIZE BP-EXTR-DTL-CALCHDR OF BBPXT*/
			wBillCalcHdrRecord = new CmPostRouteBillExtractDetailsBillCalcHeaderRecord();
			/*SET BP-EXTR-TYPE-DTL-CALCHDR OF BBPXT TO TRUE*/
			wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_CALCHDR);
			/*MOVE CORR BILL-SEGMENT-CALC-HDR (W-CALCHDR-CNT) TO BP-EXTR-DTL-CALCHDR*/
			wBillCalcHdrRecord.setStartDt(bsegCalcHdr.getStartDate().toString().trim());
			wBillCalcHdrRecord.setEndDt(bsegCalcHdr.getEndDate().toString().trim());	
			if (notNull(bsegCalcHdr.getRateVersionId())
					&& notNull(bsegCalcHdr.getRateVersionId().getRateScheduleId())) {
				wBillCalcHdrRecord.setRsCd(bsegCalcHdr.getRateVersionId().getRateScheduleId().getTrimmedValue());
			}			
			BigDecimal bsegCalcHdrCalculatedAmount = bsegCalcHdr.getCalculatedAmount().getAmount();
			wBillCalcHdrRecord.setCalcAmt(bsegCalcHdrCalculatedAmount, transformImpliedBD(bsegCalcHdrCalculatedAmount, 2));
			wBillCalcHdrRecord.setDescrOnBill(bsegCalcHdr.getDescriptionOnBill());
			
			/*PERFORM NA090-CALCHDR-CUSTOM-FIELDS*/
			calcHdrCustomFields(bsegCalcHdr);			
						
			wBillCalcHdrRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
			wBillCalcHdrRecord.setBPSortKey(wSortKeyRecord.createRecordString());
			wBillCalcHdrRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
			
			/*PERFORM MX010-WRITE-EXTRACT-DATA*/
			/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
			 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
			 */         
			// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
			//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

				/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
				//wSortKeyRecord.setCopyNbr(String.valueOf(x));
			    wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);			
			// End Change - DLampa - 2024-09-17 - INC0037039.Issue1
				wBillCalcHdrRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
				hpFileHelper.appendWriteClose(wBillCalcHdrRecord);
			// Start Delete- DLampa - 2024-09-17 - INC0037039.Issue1				
			//}
			// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1		
			
			// Bill Segment Calc Lines
			/*MOVE 0 TO W-LINE-SEQ*/
			wLineSeq = 0;
			
			Iterator<BillCalculationLine> collOfBillCalcLine = bsegCalcHdr.getBillCalculationLines().iterator();
			while (collOfBillCalcLine.hasNext()) {
				BillCalculationLine billCalcLine = collOfBillCalcLine.next();
				/*IF SW-YES OF PRT-SW OF BILL-SEGMENT-CALC-LINE*/
				if (billCalcLine.getShouldPrint().isTrue()) {
					/*ADD 1 TO W-LINE-SEQ*/
					wLineSeq++;
					if (wNonPremSw.isFalse()) {
						/*SET CALCHDR-REC-LINE OF CALC-HDR-LINE-DETAIL-SECTION TO TRUUE*/
						wSortKeyRecord.setCalcHdrRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.CALCHDR_REC_LINE);
						/*MOVE W-LINE-SEQ TO CALC-LINE-SEQ OF CALC-HDR-LINE-DETAIL-SECTION*/
						wSortKeyRecord.setCalcLineSeq(String.valueOf(wLineSeq));
					}
					else {
						/*SET CALCHDR-REC-LINE OF NP-CALC-HDR-LINE-DETAIL-SECTION TO TRUE*/
						wSortKeyRecord.NP_CALCHDR_REC_GRP_SEQ = CmPostRouteBillExtractSortKeyRecord.CALCHDR_REC_LINE;
						/*MOVE W-LINE-SEQ TO NP-CALC-LINE-SEQ OF NP-CALC-HDR-LINE-DETAIL-SECTION*/
						wSortKeyRecord.NP_CALC_LINE_SEQ = String.valueOf(wLineSeq); 
						wSortKeyRecord.setNonPremSaSeq();
					}
					/*SET BP-EXTR-TYPE-DTL-CALCLN OF BBPXT TO TRUE*/
					wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_CALCLN);
					/*INITIALIZE BP-EXTR-CALCLN OF BBPXT*/
					wBillCalcLineRecord = new CmPostRouteBillExtractDetailsBillCalcLineRecord();
					/*MOVE CORR BILL-SEGMENT-CALC-LINE(W-CALCLN-CNT) TO BP-EXTR-DTL-CALCLN-OF BBPXT*/
					wBillCalcLineRecord.setAppInSummSw(transformToYorN(billCalcLine.getShouldAppearInSummary()));
					BigDecimal billClcLnCalculatedAmount = billCalcLine.getCalculatedAmount().getAmount();
					BigDecimal billClcLnExemptAmount = billCalcLine.getExemptAmount().getAmount();
					wBillCalcLineRecord.setCalcAmt(billClcLnCalculatedAmount, transformImpliedBD(billClcLnCalculatedAmount, 2));
					wBillCalcLineRecord.setExemptAmt(billClcLnExemptAmount, transformImpliedBD(billClcLnExemptAmount, 2));
					wBillCalcLineRecord.setUomCd(" ");
					if (notNull(billCalcLine.fetchUnitOfMeasure())) {
						wBillCalcLineRecord.setUomCd(billCalcLine.getUnitOfMeasureId().getTrimmedValue());
					}
					wBillCalcLineRecord.setTouCd(" ");
					if (notNull(billCalcLine.fetchTimeOfUse())) {
						wBillCalcLineRecord.setTouCd(billCalcLine.getTimeOfUseId().getTrimmedValue());
					}
					wBillCalcLineRecord.setSqiCd(" ");
					if (notNull(billCalcLine.fetchServiceQuantityIdentifier())) {
						wBillCalcLineRecord.setSqiCd(billCalcLine.getServiceQuantityIdentifierId().getTrimmedValue());
					}
					wBillCalcLineRecord.setBillSq(billCalcLine.getBillableServiceQuantity(), transformImpliedBD(billCalcLine.getBillableServiceQuantity(), 6));
					
					wBillCalcLineRecord.setDescrOnBill(billCalcLine.getDescriptionOnBill());
					/*PERFORM NA100-CUSTOM-CALCLN-FIELDS*/
					customCalcLnFields(billCalcLine);
					
					wBillCalcLineRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
					wBillCalcLineRecord.setBPSortKey(wSortKeyRecord.createRecordString());
					wBillCalcLineRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
					
					/*PERFORM MX010-WRITE-EXTRACT-DATA*/
					/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
					 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
					 */  
					// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
					//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

						/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
						//wSortKeyRecord.setCopyNbr(String.valueOf(x));
						wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
					// End Change - DLampa - 2024-09-17 - INC0037039.Issue1						
						wBillCalcLineRecord.setBPSortKey(wSortKeyRecord.createRecordString());			
						hpFileHelper.appendWriteClose(wBillCalcLineRecord);
					// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1						
					//}
					// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1
				}
			}
			
			if (wNonPremSw.isFalse()) {
				/*INITIALIZE CALC-LINE-SEQ*/
				wSortKeyRecord.setCalcLineSeq(" ");
			}
			else {
				/*INITIALIZE NP-CALC-LINE-SEQ*/
				wSortKeyRecord.NP_CALC_LINE_SEQ = " ";
				wSortKeyRecord.setNonPremSaSeq();
			}					
		}
		
		if (wWithCalcHdrSw.isTrue()) {
			if (wNonPremSw.isFalse()) {
				/*SET CALCHDR-REC-END OF CALC-HDR-LINE-DETAIL-SECTION TO TRUE*/
				wSortKeyRecord.setCalcHdrRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.CALCHDR_REC_END);
				/*SET BP-EXTR-TYPE-END-CALCHDR TO TRUE*/
				wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_END_CALCHDR);
				
				/*
				 * NOT SURE with the wBillCalcHdrRecord is the column delimited record to write
				 */
//				wBillCalcHdrRecord = new CmPostRouteBillExtractDetailsBillCalcHeaderRecord();
//				wBillCalcHdrRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
//				wBillCalcHdrRecord.setBPSortKey(wSortKeyRecord.createRecordString());
//				wBillCalcHdrRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
				CmPostRouteBillExtractGenericEndRecord endBillRecord = new CmPostRouteBillExtractGenericEndRecord();
				endBillRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
				endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());
				endBillRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
				
				/*PERFORM MX010-WRITE-EXTRACT-DATA*/
				/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
				 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
				 */   
				// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
				//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

					/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
					//wSortKeyRecord.setCopyNbr(String.valueOf(x));
					wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
				// End Change - DLampa - 2024-09-17 - INC0037039.Issue1
					endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());	
					endBillRecord.setFiller(3241);
					hpFileHelper.appendWriteClose(endBillRecord);
				// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1					
				//}
				// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1
				
				/*MOVE SPACES TO CALC-HDR-LINE-DETAIL-SECTION*/
				wSortKeyRecord.setCalcHdrSeq(" ");
				wSortKeyRecord.setBsegReadNbr(" ");
				wSortKeyRecord.setBsegSqNbr(" ");
				wSortKeyRecord.setBsegItemNbr(" ");
				wSortKeyRecord.setCalcHdrLineBsegMsgsNbr(" ");
				wSortKeyRecord.setCalcHdrRecGrpSeq(" ");
				wSortKeyRecord.setCalcLineSeq(" ");
			}
			else {
				/*SET CALCHDR-REC-END OF NP-CALC-HDR-LINE-DETAIL SECTION TO TRUE*/
				wSortKeyRecord.NP_CALCHDR_REC_GRP_SEQ = CmPostRouteBillExtractSortKeyRecord.CALCHDR_REC_END;
				wSortKeyRecord.setNonPremSaSeq();
				/*SET BP-EXTR-TYPE-END-CALCHDR TO TRUE*/
				wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_END_CALCHDR);
				
				/*
				 * NOT SURE with the wBillCalcHdrRecord is the column delimited record to write
				 */
//				wBillCalcHdrRecord = new CmPostRouteBillExtractDetailsBillCalcHeaderRecord();
//				wBillCalcHdrRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
//				wBillCalcHdrRecord.setBPSortKey(wSortKeyRecord.createRecordString());
//				wBillCalcHdrRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
				CmPostRouteBillExtractGenericEndRecord endBillRecord = new CmPostRouteBillExtractGenericEndRecord();
				endBillRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
				endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());
				endBillRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
				
				/*PERFORM MX010-WRITE-EXTRACT-DATA*/
				/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
				 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
				 */  
				// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
				//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

					/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
					//wSortKeyRecord.setCopyNbr(String.valueOf(x));
					wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
				// End Change - DLampa - 2024-09-17 - INC0037039.Issue1					
					endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());	
					endBillRecord.setFiller(3241);
					hpFileHelper.appendWriteClose(endBillRecord);
				// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1					
				//}
				// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1			
				
				/*MOVE SPACES TO NP-CALC-HDR-LINE-DETAIL-SECTION*/				
				wSortKeyRecord.NP_CALCHDR_SEQ = " ";
				wSortKeyRecord.BSEG_MSGS_NBR = " ";
				wSortKeyRecord.NP_CALCHDR_REC_GRP_SEQ = " ";				
				wSortKeyRecord.NP_CALC_LINE_SEQ = " ";
				wSortKeyRecord.setNonPremSaSeq();
			}
			
			/*SET SW-NO OF WITH-CALCHDR-SW TO TRUE*/
			wWithCalcHdrSw = Bool.FALSE;			
		}
		// Bill Segment Messages
		/*MOVE 0 TO W-LINE-SEQ*/
		wLineSeq = 0;
		Iterator<BillSegmentMessage> collOfBillSegmentMessages = billSegment.getMessages().iterator();
		while (collOfBillSegmentMessages.hasNext()) {
			BillSegmentMessage billSegmentMessage = (BillSegmentMessage) collOfBillSegmentMessages.next();
			/*ADD 1 TO W-LINE-SEQ*/
			wLineSeq++;
			
			if (wNonPremSw.isFalse()) {
				/*SET BSEG-REC-BSEGMSG-DTL OF BSEG-ADJ-DETAIL-SECTION TO TRUE*/
				wSortKeyRecord.setBsegRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.BSEG_REC_BSEGMSG_DTL);
				/*MOVE W-LINE-SEQ TO BSEG-MSGS-NBR OF CALC-HDR-LINE-DETAIL-SECTION*/
				wSortKeyRecord.setCalcHdrLineBsegMsgsNbr(String.valueOf(wLineSeq));				
			}
			else {
				/*SET BSEG-REC-BSEGMSG-DTL OF NP-BSEG-ADJ-DETAIL-SECTION TO TRUE*/
				wSortKeyRecord.NP_BSEG_REC_GRP_SEQ = CmPostRouteBillExtractSortKeyRecord.BSEG_REC_BSEGMSG_DTL;
				/*MOVE W-LINE-SEQ TO BSEG-MSGS-NBR OF NP-CALC-HDR-LINE-DETAIL-SECTION*/
				wSortKeyRecord.BSEG_MSGS_NBR = String.valueOf(wLineSeq);
				wSortKeyRecord.setNonPremSaSeq();
			}
			/*SET BP-EXTR-TYPE-DTL-BSEGMSG OF BBPXT TO TRUE*/
			wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_BSEGMSG);
			/*INITIALIZE BP-EXTR-DTL-BSEGMSG OF BBPXT*/
			wBsegMessageRecord = new CmPostRouteBillExtractDetailsBillSegmentMessageRecord();
			/*MOVE CORR BILL-SEGMENT-MSGS(W-BSEGMSGS-CNT) TO BP-EXTR-DTL-BSEGMSG OF BBPXT*/
			wBsegMessageRecord.setBillMsgCd(billSegmentMessage.fetchIdBillMessage().getId().getTrimmedValue());
			wBsegMessageRecord.setMsgOnBill(billSegmentMessage.fetchIdBillMessage().fetchLanguageMessageOnBill());
						
			wBsegMessageRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
			wBsegMessageRecord.setBPSortKey(wSortKeyRecord.createRecordString());
			wBsegMessageRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
			
			/*PERFORM MX010-WRITE-EXTRACT-DATA*/
			/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
			 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
			 */   
			// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
			//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

				/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
				//wSortKeyRecord.setCopyNbr(String.valueOf(x));
				wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
			// End Change - DLampa - 2024-09-17 - INC0037039.Issue1				
				wBsegMessageRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
				hpFileHelper.appendWriteClose(wBsegMessageRecord);
			// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1				
			//}
			// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1			
		}
		if (wNonPremSw.isFalse()) {
			// Bill Segment Reads
			wLineSeq = 0;
			Iterator<BillSegmentRegisterRead> collBsegRegReads = retrieveBsegRegReads(billSegment);
			
			
			if (notNull(collBsegRegReads)) {				
				while(collBsegRegReads.hasNext()) {
					BillSegmentRegisterRead bsegRead = (BillSegmentRegisterRead) collBsegRegReads.next();
					
					
					if (!(bsegRead.getHowToUseRead().isCalculationAudit()
							|| bsegRead.getHowToUseRead().isServiceQuantity())) {

						// Get more read / meter / register details (end read)
						
						/*MOVE END-REG-READ-ID OF BILL-SEGMENT-READ(W-BSEGRD-CNT) TO REG-READ-ID OF S-READ*/
						getReadDtl(bsegRead.getEndRegisterReadingId());
						
						// Get more read details (start read)
						
						/*MOVE START-REG-READ-ID OF BILL-SEGMENT-READ(W-BSEGRD-CNT) TO REG-READ-ID OF S-READTYP*/
						wS_READTYP_OUT_DATA_readTypeFlg = bsegRead.fetchStartRegisterRead().getReadType();
					}
					/*SET BSEG-REC-BSEGRD-DTL TO TRUE*/
					wSortKeyRecord.setBsegRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.BSEG_REC_BSEGRD_DTL);
					/*ADD 1 TO W-LINE-SEQ*/
					wLineSeq++;
					/*MOVE W-LINE-SEQ TO BSEG-READ-NBR OF CALC-HDR-LINE-DETAIL-SECTION*/
					wSortKeyRecord.setBsegReadNbr(String.valueOf(wLineSeq));
					
					/*INITIALIZE BP-EXTR-DTL-BSEGRD OF BBPXT*/
					wBsegReadRecord = new CmPostRouteBillExtractDetailsBillSegmentReadRecord();
					/*SET BP-EXTR-TYPE-DTL-BSEGRD OF BBPXT TO TRUE*/
					wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_BSEGRD);
					/*MOVE CORR BILL-SEGMENT-READ(W-BSEGRD-CNT) TO BP-EXTR-DTL-BSEGRD OF BBPXT*/
					ServicePoint_Id spID = new ServicePoint_Id(bsegRead.fetchIdServicePointIdString().trim());
					wBsegReadRecord.setSpID(bsegRead.fetchIdServicePointIdString());								
					wBsegReadRecord.setSpDescr(spID.getEntity().getLongDescription());
					wBsegReadRecord.setUomCd(" ");
					if (notNull(bsegRead.getUnitOfMeasureId())
							&& notNull(bsegRead.fetchUnitOfMeasure())) {
						wBsegReadRecord.setUomCd(bsegRead.getUnitOfMeasureId().getTrimmedValue());
					}
					wBsegReadRecord.setTouCd(" ");
					if (notNull(bsegRead.getTimeOfUseId())
							&& notNull(bsegRead.fetchTimeOfUse())) {
						wBsegReadRecord.setTouCd(bsegRead.getTimeOfUseId().getTrimmedValue());
					}
					wBsegReadRecord.setStartRegReading(bsegRead.getStartRegisterReading(), transformImpliedBD(bsegRead.getStartRegisterReading(), 6));
					wBsegReadRecord.setStartReadDttm(bsegRead.getStartReadDateTime().toString(DTTM_FORMAT));
					wBsegReadRecord.setEndRegReading(bsegRead.getEndRegisterReading(), transformImpliedBD(bsegRead.getEndRegisterReading(), 6));
					wBsegReadRecord.setEndReadDttm(bsegRead.getEndReadDateTime().toString(DTTM_FORMAT));
					wBsegReadRecord.setMsrQty(bsegRead.getMeasuredQuantity(), transformImpliedBD(bsegRead.getMeasuredQuantity(), 6));
					wBsegReadRecord.setUsePct(bsegRead.getUsePercent().toString());
					wBsegReadRecord.setHowToUseFlg(bsegRead.getHowToUse().trimmedValue());				
					wBsegReadRecord.setMsrPeakQtySw(transformToYorN(bsegRead.getMeasuresPeakQuantity()));
					wBsegReadRecord.setRegConst(bsegRead.getRegisterConstant(), transformImpliedBD(bsegRead.getRegisterConstant(), 6));				
					wBsegReadRecord.setFinalUomCd(" ");
					if (notNull(bsegRead.fetchFinalUnitOfMeasure())
							&& notNull(bsegRead.getFinalUnitOfMeasureId())) {
						wBsegReadRecord.setFinalUomCd(bsegRead.getFinalUnitOfMeasureId().getTrimmedValue());
					}
					wBsegReadRecord.setFinalTouCd(" ");
					if (notNull(bsegRead.fetchFinalTimeOfUse())
							&& notNull(bsegRead.getFinalTimeOfUseId())) {
						wBsegReadRecord.setFinalTouCd(bsegRead.getFinalTimeOfUseId().getTrimmedValue());
					}
					wBsegReadRecord.setSqiCd(" ");
					if (notNull(bsegRead.fetchServiceQuantityIdentifier()) 
							&& notNull(bsegRead.getServiceQuantityIdentifierId())) {
						wBsegReadRecord.setSqiCd(bsegRead.getServiceQuantityIdentifierId().getTrimmedValue());
					}
					wBsegReadRecord.setFinalSqiCd(" ");
					if (notNull(bsegRead.fetchFinalServiceQuantity())
							&& notNull(bsegRead.getFinalServiceQuantityId())) {
						wBsegReadRecord.setFinalSqiCd(bsegRead.getFinalServiceQuantityId().getTrimmedValue());
					}
					
					/*
					 * Subtractive meters need to get the difference between two
					 * consecutive reads to get the consumption, whereas 
					 * consumptive meters only need one reading.
					 */
					if (wS_READDTL_OUT_DATA_consumSubFlg.isSubtractive()) {
						
						BigDecimal difference = getReadingDifference(wS_READDTL_OUT_DATA_regId,
								bsegRead.getStartRegisterReading(),
								bsegRead.getEndRegisterReading(),
								wS_READDTL_OUT_DATA_nbrOfDgtsLft,
								Bool.FALSE);
						/*MOVE DIFFERENCE OF MDBRN TO READ-DIFFERENT OF BP-EXTR-DTL-BSEGRD OF BBPXT*/
						wBsegReadRecord.setReadDifferent(difference, transformImpliedBD(difference, 6));
					}
					 
					/*MOVE CORR S-READDTL TO BP-EXTR-DTL-BSEGRD OF BBPXT*/				
					wBsegReadRecord.setBadgeNbr(wS_READDTL_OUT_DATA_badgeNbr);
					wBsegReadRecord.setReadType(wS_READDTL_OUT_DATA_readTypeFlg.trimmedValue());
					wBsegReadRecord.setConsumSubFlg(wS_READDTL_OUT_DATA_consumSubFlg.trimmedValue());
					wBsegReadRecord.setUsageFlg(bsegRead.getHowToUseRead().trimmedValue());
					wBsegReadRecord.setFinalRegQty(bsegRead.getRegisterQuantity(), transformImpliedBD(bsegRead.getRegisterQuantity(), 6));
					/*MOVE NBR-OF-DGTS-RGT OF S-READDTL TO RDG-DEC-POS OF BP-EXTR-DTL-BSEGRD OF BBPXT*/
					wBsegReadRecord.setRdgDecPos(wS_READDTL_OUT_DATA_nbrOfDgtsRgt.toString());
					
					// Set Start Estimate Sw (Retrieved from S-READTYP)
					if (wS_READTYP_OUT_DATA_readTypeFlg.isSystemEstimate()
							|| wS_READTYP_OUT_DATA_readTypeFlg.isServiceProviderEstimate()
							|| wS_READTYP_OUT_DATA_readTypeFlg.isOfficeEstimate()) {
						wBsegReadRecord.setStartEstimateSw(transformToYorN(Bool.TRUE));					
					}
					else {
						wBsegReadRecord.setStartEstimateSw(transformToYorN(Bool.FALSE));
					}
					
					// Set End Estimate Sw (Retrieved from S-READDTL)
					if (wS_READDTL_OUT_DATA_readTypeFlg.isSystemEstimate()
							|| wS_READDTL_OUT_DATA_readTypeFlg.isServiceProviderEstimate()
							|| wS_READDTL_OUT_DATA_readTypeFlg.isOfficeEstimate()) {					
						wBsegReadRecord.setEndEstimateSw(transformToYorN(Bool.TRUE));
					}
					else {					
						wBsegReadRecord.setEndEstimateSw(transformToYorN(Bool.FALSE));
					}
					
					// Get UOM details for pertinent decimal positions
					if (notNull(bsegRead.fetchFinalUnitOfMeasure())) {
						/*MOVE DECIMAL-POSITIONS OF TUOMT TO QTY-DEC-POS OF BP-EXTR-DTL-BSEGRD*/
						wBsegReadRecord.setQtyDecPos(bsegRead.fetchFinalUnitOfMeasure().getDecimalPositions().toString());
					}
					else {
						// Get SQI Details for pertinent decimal positions
						/*MOVE DECIMAL-POSITIONS OF TSQIT TO QTY-DEC-POS OF BP-EXTR-DTL-BSEGRD*/
						wBsegReadRecord.setQtyDecPos(bsegRead.fetchFinalServiceQuantity().getDecimalPositions().toString());
					}
					
					// Bill Segment Read (Custom)
					bsegReadCustomFields(bsegRead.fetchEndRegisterReading());
					
					wBsegReadRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
					wBsegReadRecord.setBPSortKey(wSortKeyRecord.createRecordString());
					wBsegReadRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
					
					/*PERFORM MX010-WRITE-EXTRACT-DATA*/
					/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
					 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
					 */   
					// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
					//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

						/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
						//wSortKeyRecord.setCopyNbr(String.valueOf(x));
						wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
					// End Change - DLampa - 2024-09-17 - INC0037039.Issue1						
						wBsegReadRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
						hpFileHelper.appendWriteClose(wBsegReadRecord);
					// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1						
					//}
					// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1				
				} // END-WHILE
			} // END-IF
			
			
			/*MOVE SPACES TO BSEG-READ-NBR OF CALC-HDR-LINE-DETAIL-SECTION*/
			wSortKeyRecord.setBsegReadNbr(" ");
			
			// Bill Segment SQs
			
			/*MOVE 0 TO W-LINE-SEQ*/
			wLineSeq = 0;
			
			Iterator<BillSegmentServiceQuantity> collOfBsegSQ = billSegment.getServiceQuantities().iterator();
			while (collOfBsegSQ.hasNext()) {
				BillSegmentServiceQuantity bsegSQ = collOfBsegSQ.next();
				/*SET BSEG-REC-BSEGSQ-DTL TO TRUE*/
				wSortKeyRecord.setBsegRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.BSEG_REC_BSEGSQ_DTL);
				/*ADD 1 TO W-LINE-SEQ*/
				wLineSeq++;
				/*MOVE W-LINE-SEQ TO BSEG-SQ-NBR OF CALC-HDR-LINE-DETAIL-SECTION*/
				wSortKeyRecord.setBsegSqNbr(String.valueOf(wLineSeq));
				/*INITIALIZE BP-EXTR-DTL-BSEGSQ OF BBPXT*/
				wBsegSqRecord = new CmPostRouteBillExtractDetailsBillSegmentSQRecord();
				/*SET BP-EXTR-TYPE-DTL-BSEGSQ OF BBPXT TO TRUE*/
				wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_BSEGSQ);
				/*MOVE CORR BILL-SEGMENT-SQ (W-BSEGSQ-CNT) TO BP-EXTR-DTL-BSEGSQ OF BBPXT*/
				wBsegSqRecord.setUomCd(" ");
				if (notBlank(bsegSQ.fetchIdUnitOfMeasure())) {
					wBsegSqRecord.setUomCd(bsegSQ.fetchIdUnitOfMeasure());
				}
				wBsegSqRecord.setTouCd(" ");
				if (notBlank(bsegSQ.fetchIdTimeOfUse())) {
					wBsegSqRecord.setTouCd(bsegSQ.fetchIdTimeOfUse());
				}
				wBsegSqRecord.setSqiCd(" ");
				if (notBlank(bsegSQ.fetchIdServiceQuantityIdentifier())) {
					wBsegSqRecord.setSqiCd(bsegSQ.fetchIdServiceQuantityIdentifier());
				}
				
				//Start Change - 47090 - JTIOZON - 2021-11-19
				//wBsegSqRecord.setBillSq(bsegSQ.getBillableServiceQuantity(), transformImpliedBD(bsegSQ.getBillableServiceQuantity(), 6));
				wBsegSqRecord.setBillSq(bsegSQ.getBillableServiceQuantity(), transformImpliedBDUOMSpecific(bsegSQ.getBillableServiceQuantity(), 6, bsegSQ.fetchIdUnitOfMeasure()));				
				//End Change - 47090 - JTIOZON - 2021-11-19
				
				if (isBlankOrNull(bsegSQ.fetchIdServiceQuantityIdentifier())) {
					UnitOfMeasure_Id uomID = new UnitOfMeasure_Id(bsegSQ.fetchIdUnitOfMeasure());
					if (notNull(uomID.getEntity())) {
						BigInteger decPos = uomID.getEntity().getDecimalPositions();
						/*MOVE DECIMAL-POSITIONS OF TUOMT TO SQ-DEC-POS OF BP-EXTR-DTL-BSEGSQ*/
						wBsegSqRecord.setSqDecPos(decPos.toString());
					}
				}
				else {
					ServiceQuantityIdentifier_Id sqiID = new ServiceQuantityIdentifier_Id(bsegSQ.fetchIdServiceQuantityIdentifier());
					if (notNull(sqiID.getEntity())) {
						BigInteger decPos = sqiID.getEntity().getDecimalPositions();
						/*MOVE DECIMAL-POSITIONS OF TSQIT TO SQ-DEC-POS OF BP-EXTR-DTL-BSEGSQ*/
						wBsegSqRecord.setSqDecPos(decPos.toString());
					}
				}
				
				wBsegSqRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
				wBsegSqRecord.setBPSortKey(wSortKeyRecord.createRecordString());
				wBsegSqRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
				
				/*PERFORM MX010-WRITE-EXTRACT-DATA*/
				/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
				 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
				 */  
				// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1				
				//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

					/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
					//wSortKeyRecord.setCopyNbr(String.valueOf(x));
					wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
				// End Change - DLampa - 2024-09-17 - INC0037039.Issue1					
					wBsegSqRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
					hpFileHelper.appendWriteClose(wBsegSqRecord);
				// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1					
				//}					
				// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1				
			}
			
			/*MOVE SPACES TO BSEG-SQ-NBR OF CALC-HDR-LINE-DETAIL-SECTION*/
			wSortKeyRecord.setBsegSqNbr(" ");
			
			// Bill Segment Items
			/*MOVE 0 TO W-LINE-SEQ*/
			wLineSeq = 0;
			Iterator<BillSegmentItem> collOfBsegItems = billSegment.getItems().iterator();
			while (collOfBsegItems.hasNext()) {
				
				BillSegmentItem bsegItem = (BillSegmentItem) collOfBsegItems.next();
				/*SET BSEG-REC-BSEGITM-DTL TO TRUE*/
				wSortKeyRecord.setBsegRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.BSEG_REC_BSEGITM_DTL);
				/*ADD 1 TO W-LINE-SEQ*/
				wLineSeq++;
				/*MOVE W-LINE-SEQ TO BSEG-ITEM-NBR OF CALC-HDR-LINE-DETAIL-SECTION*/
				wSortKeyRecord.setBsegItemNbr(String.valueOf(wLineSeq));
				/*INITIALIZE BP-EXTR-DTL-BSEGITM OF BBPXT*/
				wBsegItemRecord = new CmPostRouteBillExtractDetailsBillSegmentItemRecord();
				/*SET BP-EXTR-TYPE-DTL-BSEGITM OF BBPXT TO TRUE*/
				wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_BSEGITM);
				/*MOVE CORR BILL-SEGMENT-ITEM(W-BSEGITM-CNT) TO BP-EXTR-DTL-BSEGITM OF BBPXT*/
				wBsegItemRecord.setStartDt(bsegItem.getStartDate().toString());
				wBsegItemRecord.setEndDt(bsegItem.getEndDate().toString());
				wBsegItemRecord.setItemCnt(bsegItem.getItemCount(), transformImpliedBD(bsegItem.getItemCount(), 2));
				
				// Get Item Type Description
				ItemType_Id itemTypeID = new ItemType_Id(bsegItem.getItemType());
				if (notNull(itemTypeID.getEntity())) {
					wBsegItemRecord.setItemDescr(itemTypeID.getEntity().fetchLanguageDescription());
				}	
				
				wBsegItemRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
				wBsegItemRecord.setBPSortKey(wSortKeyRecord.createRecordString());
				wBsegItemRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
				
				/*PERFORM MX010-WRITE-EXTRACT-DATA*/
				/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
				 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
				 */   
				// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1				
				//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

					/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
					//wSortKeyRecord.setCopyNbr(String.valueOf(x));
					wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
				// End Change - DLampa - 2024-09-17 - INC0037039.Issue1					
					wBsegItemRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
					hpFileHelper.appendWriteClose(wBsegItemRecord);
				// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1					
				//}	
				// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1				
			}
			
			/*MOVE SPACES TO BSEG-ITEM-NBR OF CALC-HDR-LINE-DETAIL-SECTION*/
			wSortKeyRecord.setBsegItemNbr(" ");		
		}		
	}		
	
	private BigDecimal getReadingDifference(Register_Id regID,
			BigDecimal startRegRdg,
			BigDecimal endRegRdg,
			BigInteger nbrDgtsLft,
			Bool negConsPosibleSw) {
		
		BigDecimal returnValue = BigDecimal.ZERO;
		try {
			CobolProgramCIPMDBRN  cblRtne = CobolProgramCIPMDBRN.Factory.newInstance();
			CobolCopybookCICMDBRN cblCpybook = cblRtne.getCobolCopybookCICMDBRN();
			cblCpybook.get_INPUT_WRK().set_REG_ID(regID.getTrimmedValue());
			cblCpybook.get_INPUT_WRK().set_START_READING(startRegRdg);
			cblCpybook.get_INPUT_WRK().set_END_READING(endRegRdg);
			cblCpybook.get_INPUT_WRK().set_NBR_OF_DGTS_LFT(nbrDgtsLft);
			cblCpybook.get_INPUT_WRK().set_NEG_CONS_POSSIBLE_SW(negConsPosibleSw);
			cblRtne.callCobol();
			returnValue = cblCpybook.get_OUTPUT_WRK().get_DIFFERENCE();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return returnValue;
	}
	
	private void bsegReadCustomFields(RegisterRead endRegRead) {
		
		// Get MR Source
		MeterReadSource_Id mrSourceCd = getMrSource(endRegRead);		
		/*MOVE MR-SOURCE-CD OF S-MRSRC TO MR-SOURCE-CD OF BP-EXTR-DTL-BSEGRD*/
		wBsegReadRecord.setMrSourceCd(" ");
		if (notNull(mrSourceCd)
				&& notNull(mrSourceCd.getEntity())) {
			wBsegReadRecord.setMrSourceCd(mrSourceCd.getTrimmedValue());
		}
	}
	
	private void customCalcLnFields(BillCalculationLine billCalcLine) {
		
		/*SET SW-NO OF W-CALCLN-HDR-EXISTS-SW OF W-WRK TO TRUE*/
		wCalclnHdrExistsSw = Bool.FALSE;
		/*SET SW-NO OF W-CALCLN-SEQ-EXISTS-SW OF W-WRK TO TRUE*/
		wCalclnSeqExistsSw = Bool.FALSE;
		/*INITIALIZE W-HEADER-CD OF W-WRK W-OVERRIDE-SEQ OF W-WRK*/
		String wHeader = " ";
		String wOverrideSeq = " ";
		
		// Get all the Bill Segment Calc Line Characteristics
		Iterator<BillCalculationLineCharacteristic> collOfBillCalcLineChar = billCalcLine.getCharacteristics().iterator();
		while (collOfBillCalcLineChar.hasNext()) {
			BillCalculationLineCharacteristic billCalcLineChar = collOfBillCalcLineChar.next();
			CharacteristicType billCalcLineCharType = billCalcLineChar.fetchIdCharacteristicType();
			
			if (billCalcLineCharType.equals(parmCharTypeTaxingCommunityBillLine)) {
				// Determine the length of the Tax Community Descr
				/*
				 * STRING W-TAX-COMM-DESCR OF W-WRK (1:W-DESCR-LEN)
				 *         DELIMITED BY SIZE
				 *         ' ' DELIMITED BY SIZE
				 *         DESCR-ON-BILL
				 *         OF BILL-SEGMENT-CALC-LINE (W-CALCLN-CNT)
				 *     INTO DESCR-ON-BILL OF BP-EXTR-DTL-CALCLN OF BBPXT    
				 * END-STRING
				 */
				String descrOnBillResultingValue = " ";
				
				//descrOnBillResultingValue =  wTaxCommDescr.trim().substring(0, 2).concat(" ");
				descrOnBillResultingValue =  wTaxCommDescr.trim().concat(" ");
				descrOnBillResultingValue = descrOnBillResultingValue.concat(billCalcLine.getDescriptionOnBill());					
				wBillCalcLineRecord.setDescrOnBill(descrOnBillResultingValue);			
			}
			// Header Code
			if (billCalcLineCharType.equals(parmCharTypeUtilityChargesHeaders)) {
				/*SET SW-YES OF W-CALCLN-HDR-EXISTS-SW OF W-WRK TO TRUE*/
				wCalclnHdrExistsSw = Bool.TRUE;
				CharacteristicTypeLookup charTypeLookup = parmCharTypeUtilityChargesHeaders.getCharacteristicType();
				if (charTypeLookup.isAdhocValue()
						|| charTypeLookup.isFileLocationValue()) {
					wHeader = billCalcLineChar.getAdhocCharacteristicValue();
				}
				else if (charTypeLookup.isForeignKeyValue()) {
					wHeader = billCalcLineChar.getCharacteristicValueForeignKey1();
				}
				else {
					wHeader = billCalcLineChar.getCharacteristicValue();
				}
			}
			// Override Bill Line Sequence
			if (billCalcLineCharType.equals(parmCharTypeBillCalcLinePriority)) {
				/*SET SW-YES OF W-CALCLN-SEQ-EXISTS-SW OF W-WRK TO TRUE*/
				wCalclnSeqExistsSw = Bool.TRUE;
				CharacteristicTypeLookup charTypeLookup = parmCharTypeBillCalcLinePriority.getCharacteristicType();
				if (charTypeLookup.isAdhocValue()
						|| charTypeLookup.isFileLocationValue()) {
					wOverrideSeq = billCalcLineChar.getAdhocCharacteristicValue(); 
				}
				else if (charTypeLookup.isForeignKeyValue()) {
					wOverrideSeq = billCalcLineChar.getCharacteristicValueForeignKey1();
				}
				else {
					wOverrideSeq = billCalcLineChar.getCharacteristicValue();
				}
			}
		}
		if (wCalclnHdrExistsSw.isTrue()) {
			/*MOVE W-HEADER-CD OF W-WRK TO HEADER-CD OF BP-EXTR-DTL-CALCLN OF BBPXT*/
			wBillCalcLineRecord.setHeaderCd(wHeader);
			/*SET SW-YES OF HEADER-FLG OF BP-EXTR-DTL-CALCLN OF BBPXT TO TRUE*/
			wBillCalcLineRecord.setHeaderFlg(transformToYorN(Bool.TRUE));
		}
		else {
			/*SET SW-NO OF HEADER-FLG OF BP-EXTR-DTL-CALCLN OF BBPXT TO TRUE*/
			wBillCalcLineRecord.setHeaderFlg(transformToYorN(Bool.FALSE));
		}
		
		if (wCalclnSeqExistsSw.isTrue()) {			
			try {
				@SuppressWarnings("unused")
				int overrideSeq = Integer.parseInt(wOverrideSeq.trim());
				wSortKeyRecord.setCalcLineSeq(wOverrideSeq);
			}
			catch (Exception e) {
				e.printStackTrace();
			}			
		}		
	}
	
	private void calcHdrCustomFields(BillSegmentCalculationHeader bsegCalcHdr) {
		
		BillSegment_Id bsegID = bsegCalcHdr.fetchIdBillSegment().getId();
		wTaxCommDescr = " ";
		if (wS_SA_OUT_DATA_svcTypeCd.compareTo(parmServiceTypeForMetered.getId()) == 0
				|| wS_SA_OUT_DATA_svcTypeCd.compareTo(parmServiceTypeForUnmetered.getId()) == 0) {
			/*SET SW-YES OF UTILITY-SVC OF BP-EXTR-DTL-CALCHDR OF BBPXT TO TRUE*/
			wBillCalcHdrRecord.setUtilitySvc(transformToYorN(Bool.TRUE));
		}
		else {
			/*SET SW-NO OF UTILITY-SVC OF BP-EXTR-DTL-CALCHDR OF BBPXT TO TRUE*/
			wBillCalcHdrRecord.setUtilitySvc(transformToYorN(Bool.FALSE));
		}
		/*PERFORM XQ160-GET-CALC-LINE*/
		getCalcLine(bsegID,
				bsegCalcHdr.fetchIdHeaderSequence(),
				parmCharTypeRateClassDescription);
		
		/*MOVE DESCR-ON-BILL OF S-CLCHAR-OUT-DATA TO RATE-CLS-DESCR OF BP-EXTR-DTL-CALCHDR OF BBPXT*/
		if (notBlank(wClCharDescrOnBill)) {
			wBillCalcHdrRecord.setRateClsDescr(wClCharDescrOnBill);
		}				
		if (isBlankOrNull(wBillCalcHdrRecord.getRateClsDescr())) {
			CharacteristicTypeLookup charTypeLookup = parmCharTypeRateClass.getCharacteristicType();
			if (charTypeLookup.isPredefinedValue()) {
				ServiceAgreementCharacteristic saChar = wS_SA_OUT_DATA_SaID.getEntity()
						.getEffectiveCharacteristicAsOfDate(parmCharTypeRateClass,
								wBillDt);
				if (notNull(saChar)) {
					String rateClassCharVal = saChar.getCharacteristicValue();				
					if (notBlank(rateClassCharVal)) {
						CharacteristicValue_Id charValID = new CharacteristicValue_Id(
								parmCharTypeRateClass, rateClassCharVal.trim());
						if (notNull(charValID.getEntity())) {
							String rateClassDescr = charValID.getEntity().fetchLanguageDescription().trim();
							/*MOVE CHAR-VAL-DESCR OF S-CVDESC TO RATE-CLS-DESCR OF BP-EXTR-DTL-CALCHDR OF BBPXT*/
							wBillCalcHdrRecord.setRateClsDescr(rateClassDescr);
						}
					}	
				}	
			}			
		}
		// BTU Factor
		getBsegSQ(bsegID, null, null, parmSQI_BTUFactor.getId());
		wBillCalcHdrRecord.setBtuFactor(wS_BSEGSQ_OUT_DATA_billSq, transformImpliedBD(wS_BSEGSQ_OUT_DATA_billSq, 6));
		// Prophane
		getBsegSQ(bsegID, parmUOMPropaneBillable.getId(), null, null);
		if (wS_BSEGSQ_OUT_DATA_initSq.compareTo(BigDecimal.ZERO) != 0
				&& wS_BSEGSQ_OUT_DATA_billSq.compareTo(BigDecimal.ZERO) != 0){
			wBillCalcHdrRecord.setPropane(transformToYorN(Bool.TRUE));
		}
		else {
			wBillCalcHdrRecord.setPropane(transformToYorN(Bool.FALSE));
		}
		// Gross Amount
		getCalcLine(bsegID, 
				bsegCalcHdr.fetchIdHeaderSequence(), 
				parmCharTypeGrossAmount);
		if (wClCharCalcAmt.compareTo(Money.ZERO) != 0
				&& notBlank(wClCharDescrOnBill)) {
			wBillCalcHdrRecord.setGrossInd(transformToYorN(Bool.TRUE));
		}
		else {
			wBillCalcHdrRecord.setGrossInd(transformToYorN(Bool.FALSE));
		}
		/*MOVE CALC-AMT OF S-CLCHAR TO GROSS-AMT OF BP-EXTR-DTL-CALCHDR OF BBPXT*/
		wBillCalcHdrRecord.setGrossAmt(wClCharCalcAmt.getAmount(), transformImpliedBD(wClCharCalcAmt.getAmount(), 2));
		// Get Premise Town Code
		if (notNull(wPremID)
				&& notNull(wPremID.getEntity())) {
			PremiseCharacteristic premChar = wPremID.getEntity().
					getEffectiveCharacteristicAsOfDate(parmCharTypeTaxingCommunityPremise, wBillDt);
			if (notNull(premChar)) {
				String premTownCode = " ";
				CharacteristicTypeLookup charTypeLookup = parmCharTypeTaxingCommunityPremise.getCharacteristicType();		
				if (charTypeLookup.isPredefinedValue()) {
					premTownCode = premChar.getCharacteristicValue();
					wBillCalcHdrRecord.setTaxCmty(premTownCode);
					CharacteristicValue_Id charValID = new CharacteristicValue_Id(
							parmCharTypeTaxingCommunityPremise, premTownCode.trim());
					if (notNull(charValID.getEntity())) {
						wTaxCommDescr = charValID.getEntity().fetchLanguageDescription();
						wBillCalcHdrRecord.setTaxCmtyDescr(wTaxCommDescr);				
					}
				}
			}
		}		
	}
	
	//Start Add - 47090 - JTIOZON - 2021-11-19
	private String transformImpliedBDUOMSpecific(BigDecimal value, int scale, String uom) {

		if(!isBlankOrNull(uom)){
			if(uom.trim().equals("TH")){
				return "";
			}
		}

		String returnValue = " ";
		value = value.setScale(scale, BigDecimal.ROUND_HALF_UP);
		//value = value.setScale(scale, BigDecimal.ROUND_HALF_EVEN);
		value = value.abs();
		returnValue = value.toString().trim();
		returnValue = returnValue.replaceAll("\\.", "");

		return returnValue;

	}
	//End Add - 47090 - JTIOZON - 2021-11-19
		
	private String transformImpliedBD(BigDecimal value, int scale) {		
		String returnValue = " ";		
		value = value.setScale(scale, BigDecimal.ROUND_HALF_UP);
		//value = value.setScale(scale, BigDecimal.ROUND_HALF_EVEN);
		value = value.abs();
		returnValue = value.toString().trim();
		returnValue = returnValue.replaceAll("\\.", "");
		return returnValue;
	}
	
	private void bsegCustomFields(BillSegment_Id bsegID) {
		
		String dollarHelpCharVal = getSaTypeChar(wS_SA_OUT_DATA_CisDivID, 
				wS_SA_OUT_DATA_SATypeCd, 
				parmCharTypeDollarHelpSA);
		
		if (notBlank(dollarHelpCharVal)) {
			/*SET SW-YES OF DH-FLG OF BP-EXTR-DTL-BSEG OF BBPXT TO TRUE*/
			wBsegDetailRecord.setDhFlg(transformToYorN(Bool.TRUE));
		}
		else {
			/*SET SW-NO OF DH-FLG OF BP-EXTR-DTL-BSEG OF BBPXT TO TRUE*/
			wBsegDetailRecord.setDhFlg(transformToYorN(Bool.FALSE));
		}
		
		if (wS_SA_OUT_DATA_specialRoleFlg.isPaymentArrangement()) {
			/*SET SW-YES OF PAY-ARRANGE-FLG OF BP-EXTR-DTL-BSEG OF BBPXT TO TRUE*/
			wBsegDetailRecord.setPayArrangeFlg(transformToYorN(Bool.TRUE));
		}
		else {
			/*SET SW-NO OF PAY-ARRANGE-FLG OF BP-EXTR-DTL-BSEG OF BBPXT TO TRUE*/
			wBsegDetailRecord.setPayArrangeFlg(transformToYorN(Bool.FALSE));
		}		
	}
	
	private String cmFormat(String value) {
		String returnValue = value;
		if (notBlank(value)) {
			returnValue = value.trim();
		}
		return returnValue;
	}
	
	private void premiseDetails() {
		
		// Get the details of a premise.
		if (isNull(wPremID)
				|| isNull(wPremID.getEntity())) {
			/*SET SW-YES OF W-NON-PREMISE-SW TO TRUE*/
			wNonPremSw = Bool.TRUE;
			/*SET BILL-REC-NONPREM OF BILL-PRINT-SORT-KEY TO TRUE*/
			wSortKeyRecord.setBillRecordGroupSeq(CmPostRouteBillExtractSortKeyRecord.BILL_REC_NONPREM);			
		}
		else {
			/*SET SW-NO OF W-NON-PREMISE-SW TO TRUE*/
			wNonPremSw = Bool.FALSE;
			/*SET BILL-REC-PREM OF BILL-PRINT-SORT-KEY TO TRUE*/
			wSortKeyRecord.setBillRecordGroupSeq(CmPostRouteBillExtractSortKeyRecord.BILL_REC_PREM);						
		}
		if (wNonPremSw.isFalse()) {
			/*MOVE CORR CPRMT TO PREMISE-SEQ OF BILL-PRINT-SORT-KEY OF BBPXT*/
			Premise prem = wPremID.getEntity();
			wSortKeyRecord.STATE = cmFormat(prem.getState());
			wSortKeyRecord.CITY = cmFormat(prem.getCity());
			wSortKeyRecord.ADDRESS1 = cmFormat(prem.getAddress1());
			wSortKeyRecord.PREMISE = wPremID.getTrimmedValue();
			wSortKeyRecord.setPremiseSeq();
			/*SET SW-NO OF W-SKIP-PREM-SW TO TRUE*/
			wSkipPremSw = Bool.FALSE;
			
			if (wPossibleDuplPremSw.isTrue()) {
				wSkipPremSw = premiseCheck(hpBill, wPremID);
			}
			
			if (wSkipPremSw.isFalse()) {
				/*SET PREM-REC-PREM OF BILL-PRINT-SORT-KEY TO TRUE*/
				wSortKeyRecord.setPremRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.PREM_REC_PREM);
				/*SET BP-EXTR-TYPE-DTL-PREMISE OF BBPXT TO TRUE*/
				wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_PREMISE);
				/*MOVE CORR CPRMT TO BP-EXTR-DTL-PREMISE OF BBPXT*/
				wPremiseDetailRecord = new CmPostRouteBillExtractDetailsPremiseDetailsRecord();				
				wPremiseDetailRecord.setPremiseId(wPremID.getTrimmedValue());
				wPremiseDetailRecord.setCountry(prem.getCountryId().getTrimmedValue());
				wPremiseDetailRecord.setAddress1(cmFormat(prem.getAddress1()));
				wPremiseDetailRecord.setAddress2(cmFormat(prem.getAddress2()));
				wPremiseDetailRecord.setAddress3(cmFormat(prem.getAddress3()));
				wPremiseDetailRecord.setAddress4(cmFormat(prem.getAddress4()));
				wPremiseDetailRecord.setCity(cmFormat(prem.getCity()));
				wPremiseDetailRecord.setNum1(cmFormat(prem.getStreetNumber1()));
				wPremiseDetailRecord.setNum2(cmFormat(prem.getStreetNumber2()));				
				wPremiseDetailRecord.setHouseType(cmFormat(prem.getHouseType().value()));
				wPremiseDetailRecord.setCounty(cmFormat(prem.getCounty().trim()));
				wPremiseDetailRecord.setState(cmFormat(prem.getState().trim()));
				wPremiseDetailRecord.setPostal(cmFormat(prem.getPostal()));
				wPremiseDetailRecord.setGeoCode(cmFormat(prem.getTaxVendorGeographicalCode()));				
				wPremiseDetailRecord.setInCityLimit(transformToYorN(prem.getIsInCityLimit()));
				/*MOVE W-NON-PREMISE-SW To NON-PREMISE-SW OF BP-EXTR-DTL-PREMISE OF BBPXT*/
				wPremiseDetailRecord.setNonePremiseSw(transformToYorN(wNonPremSw));
				
				wPremiseDetailRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
				wPremiseDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());
				wPremiseDetailRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
				
				/*PERFORM MX010-WRITE-EXTRACT-DATA*/
				/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
				 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
				 */    
				// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
				//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

					/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
					//wSortKeyRecord.setCopyNbr(String.valueOf(x));
					wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
				// End Change - DLampa - 2024-09-17 - INC0037039.Issue1					
					wPremiseDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
					hpFileHelper.appendWriteClose(wPremiseDetailRecord);						
				// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1					
				//}
				// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1				
				
				/*SET SW-YES OF WITH-PREMISE-SW TO TRUE*/
				wWithPremiseSw = Bool.TRUE;
			}
		}
		else {
			if (wDummyPremRecExistsSw.isFalse()) {
				/*
				 * In order for the formatted document to arrange its data 
				 * properly, we must insert a 'dummy' Premise record and an
				 * offsetting End of Premise record into the extract file. 
				 */
				/*INITIALIZE PREMISE-SEQ PREM-REC-GRP*/
				wSortKeyRecord.STATE = " ";
				wSortKeyRecord.CITY = " ";
				wSortKeyRecord.ADDRESS1 = " ";				
				wSortKeyRecord.PREMISE = " ";
				wSortKeyRecord.setPremiseSeq();
				
				wSortKeyRecord.setPremRecGrpSeq(" ");
				wSortKeyRecord.setSaPriorityFlg(" ");
				wSortKeyRecord.setSaID(" ");
				wSortKeyRecord.setSaRecGrpSeq(" ");
				
				wSortKeyRecord.setBsegEndDt(" ");
				wSortKeyRecord.setAdjCreDt(" ");
				wSortKeyRecord.setHistDtlNbr(" ");
				wSortKeyRecord.setBsegID(" ");
				wSortKeyRecord.setAdjID(" ");
				wSortKeyRecord.setBsegRecGrpSeq(" ");
				wSortKeyRecord.setCalcHdrSeq(" ");
				wSortKeyRecord.setBsegReadNbr(" ");
				wSortKeyRecord.setBsegSqNbr(" ");
				wSortKeyRecord.setBsegItemNbr(" ");
				wSortKeyRecord.setCalcHdrLineBsegMsgsNbr(" ");
				wSortKeyRecord.setCalcHdrRecGrpSeq(" ");
				wSortKeyRecord.setCalcLineSeq(" ");
				
				/*INITIALIZE BP-EXTR-DTL-PREMISE OF BBPXT*/
				wPremiseDetailRecord = new CmPostRouteBillExtractDetailsPremiseDetailsRecord();
				
				/*SET BP-EXTR-TYPE-DTL-PREMISE OF BBPXT TO TRUE*/
				wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_PREMISE);
				
				/*MOVE W-NON-PREMISE-SW TO NON-PREMISE-SW OF BP-EXTR-DTL-PREMISE OF BBPXT*/
				wPremiseDetailRecord.setNonePremiseSw(transformToYorN(wNonPremSw));
				
				wPremiseDetailRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
				wPremiseDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());
				wPremiseDetailRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
				
				/*PERFORM MX010-WRITE-EXTRACT-DATA*/
				/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
				 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
				 */    
				// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1				
				//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

					/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
					//wSortKeyRecord.setCopyNbr(String.valueOf(x));
					wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
				// End Change - DLampa - 2024-09-17 - INC0037039.Issue1					
					wPremiseDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
					hpFileHelper.appendWriteClose(wPremiseDetailRecord);	
				// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1					
				//}
				// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1
				
				/*SET BP-EXTR-TYPE-END-PREMISE OF BBPXT TO TRUE*/
				wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_END_PREMISE);
				/*SET BILL-REC-NONPREM-END OF BILL-PRINT-SORT-KEY*/
				wSortKeyRecord.setBillRecordGroupSeq(CmPostRouteBillExtractSortKeyRecord.BILL_REC_NONPREM_END);
				/*INITIALIZE NON-PREMISE-SW OF BP-EXTR-DTL-PREMISE*/
				wPremiseDetailRecord.setNonePremiseSw(" ");
				
//				wPremiseDetailRecord = new CmPostRouteBillExtractDetailsPremiseDetailsRecord();
//				wPremiseDetailRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
//				wPremiseDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());
//				wPremiseDetailRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
				CmPostRouteBillExtractGenericEndRecord endBillRecord = new CmPostRouteBillExtractGenericEndRecord();
				endBillRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
				endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());
				endBillRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
				
				/*PERFORM MX010-WRITE-EXTRACT-DATA*/
				/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
				 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
				 */ 
				// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1				
				//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

					/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
					//wSortKeyRecord.setCopyNbr(String.valueOf(x));
					wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
				// End Change - DLampa - 2024-09-17 - INC0037039.Issue1					
					endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());
					endBillRecord.setFiller(3241);
					hpFileHelper.appendWriteClose(endBillRecord);
				// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1					
				//}	
				// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1				
				
				/*SET BILL-REC-NONPREM OF BILL-PRINT-SORT-KEY TO TRUE*/
				wSortKeyRecord.setBillRecordGroupSeq(CmPostRouteBillExtractSortKeyRecord.BILL_REC_NONPREM);
				/*SET SW-YES OF W-DUMMY-PREM-REC-EXISTS TO TRUE*/
				wDummyPremRecExistsSw = Bool.TRUE;				
			}			
		}
	}
	
	private void endOfPremise() {
		
		/*SET PREM-REC-END OF PREM-REC-GRP TO TRUE*/
		wSortKeyRecord.setPremRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.PREM_REC_END);
		/*SET BP-EXTR-TYPE-END-PREMISE OF BBPXT*/
		wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_END_PREMISE);
		/*PERFORM MX010-WRITE-EXTRACT-DATA*/
		
//		wPremiseDetailRecord = new CmPostRouteBillExtractDetailsPremiseDetailsRecord();
//		wPremiseDetailRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
//		wPremiseDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());
//		wPremiseDetailRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
		CmPostRouteBillExtractGenericEndRecord endBillRecord = new CmPostRouteBillExtractGenericEndRecord();
		endBillRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
		endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());
		endBillRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
		
		/*PERFORM MX010-WRITE-EXTRACT-DATA*/
		/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
		 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
		 */ 
		// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
		//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

			/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
			//wSortKeyRecord.setCopyNbr(String.valueOf(x));
			wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
		// End Change - DLampa - 2024-09-17 - INC0037039.Issue1			
			endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());	
			endBillRecord.setFiller(3241);
			hpFileHelper.appendWriteClose(endBillRecord);
		// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1			
		//}	
		// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1	
		
		/*INITIALIZE PREMISE-SEQ PREM-REC-GRP*/
		// Sort Key's PREMISE-SEQ
		wSortKeyRecord.STATE = " ";
		wSortKeyRecord.CITY = " ";
		wSortKeyRecord.ADDRESS1 = " ";				
		wSortKeyRecord.PREMISE = " ";
		wSortKeyRecord.setPremiseSeq();
		// Sort Key's PREM-REC-GRP
		wSortKeyRecord.setPremRecGrpSeq(" ");
		wSortKeyRecord.setSaPriorityFlg(" ");
		wSortKeyRecord.setSaID(" ");
		wSortKeyRecord.setSaRecGrpSeq(" ");
		wSortKeyRecord.setBsegEndDt(" ");
		wSortKeyRecord.setAdjCreDt(" ");
		wSortKeyRecord.setHistDtlNbr(" ");
		wSortKeyRecord.setBsegID(" ");
		wSortKeyRecord.setAdjID(" ");
		wSortKeyRecord.setBsegRecGrpSeq(" ");
		wSortKeyRecord.setCalcHdrSeq(" ");
		wSortKeyRecord.setBsegReadNbr(" ");
		wSortKeyRecord.setBsegSqNbr(" ");
		wSortKeyRecord.setBsegItemNbr(" ");
		wSortKeyRecord.setCalcHdrLineBsegMsgsNbr(" ");
		wSortKeyRecord.setCalcHdrRecGrpSeq(" ");
		wSortKeyRecord.setCalcLineSeq(" ");
		
		/*SET SW-NO OF WITH-PREMISE-SW TO TRUE*/
		wWithPremiseSw = Bool.FALSE;
	}
	
	private void endOfSa() {
		
		// End-of-service-agreement record.
		if (wNonPremSw.isFalse()) {
			/*SET SA-REC-SA-END OF SA-REC-GRP-SEQ TO TRUE*/
			wSortKeyRecord.setSaRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.SA_REC_SA_END);
			/*MOVE SPACES TO BSEG-ADJ-DETAIL-SECTION OF BILL-PRINT-SORT-KEY*/
			wSortKeyRecord.setBsegEndDt(" ");
			wSortKeyRecord.setAdjCreDt(" ");
			wSortKeyRecord.setHistDtlNbr(" ");
			wSortKeyRecord.setBsegID(" ");
			wSortKeyRecord.setAdjID(" ");
			wSortKeyRecord.setBsegRecGrpSeq(" ");
			wSortKeyRecord.setCalcHdrSeq(" ");
			wSortKeyRecord.setBsegReadNbr(" ");
			wSortKeyRecord.setBsegSqNbr(" ");
			wSortKeyRecord.setBsegItemNbr(" ");
			wSortKeyRecord.setCalcHdrLineBsegMsgsNbr(" ");
			wSortKeyRecord.setCalcHdrRecGrpSeq(" ");
			wSortKeyRecord.setCalcLineSeq(" ");
			/*SET BP-EXTR-TYPE-END-SA OF BBPXT TO TRUE*/
			wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_END_SA);
			
//			wSaDetailRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
//			wSaDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());
//			wSaDetailRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
			CmPostRouteBillExtractGenericEndRecord endBillRecord = new CmPostRouteBillExtractGenericEndRecord();
			endBillRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
			endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());
			endBillRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
			
			/*PERFORM MX010-WRITE-EXTRACT-DATA*/
			/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
			 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
			 */   
			// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1			
			//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

				/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
				//wSortKeyRecord.setCopyNbr(String.valueOf(x));
				wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
			// End Change - DLampa - 2024-09-17 - INC0037039.Issue1				
				endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());
				endBillRecord.setFiller(3241);
				hpFileHelper.appendWriteClose(endBillRecord);
			// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1				
			//}
			// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1			
			
			/*MOVE SPACES TO SA-DETAIL-SECTION OF BILL-PRINT-SORT-KEY*/
			wSortKeyRecord.setSaPriorityFlg(" ");
			wSortKeyRecord.setSaID(" ");
			wSortKeyRecord.setSaRecGrpSeq(" ");			
		}
		else {
			/*SET SA-REC-SA-END OF NP-SA-REC-GRP-SEQ TO TRUE*/
			wSortKeyRecord.NP_SA_REC_GRP_SEQ = CmPostRouteBillExtractSortKeyRecord.NP_SA_REC_SA_END; 
			/*MOVE SPACES TO NP-BSEG-ADJ-DETAIL-SECTION OF BILL-PRINT-SORT-KEY*/
			wSortKeyRecord.NP_BSEG_END_DT = " ";
			wSortKeyRecord.NP_ADJ_CRE_DT = " ";
			wSortKeyRecord.NP_BSEG_ID = " ";
			wSortKeyRecord.NP_ADJ_ID = " ";
			wSortKeyRecord.NP_BSEG_REC_GRP_SEQ = " ";
			wSortKeyRecord.NP_CALCHDR_SEQ = " ";
			wSortKeyRecord.BSEG_MSGS_NBR = " ";
			wSortKeyRecord.NP_CALCHDR_REC_GRP_SEQ = " ";
			wSortKeyRecord.NP_CALC_LINE_SEQ = " ";
			wSortKeyRecord.setNonPremSaSeq();
			/*SET BP-EXTR-TYPE-END-SA OF BBPXT TO TRUE*/
			wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_END_SA);
			
//			wSaDetailRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
//			wSaDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());
//			wSaDetailRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
			CmPostRouteBillExtractGenericEndRecord endBillRecord = new CmPostRouteBillExtractGenericEndRecord();
			endBillRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
			endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());
			endBillRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
			
			/*PERFORM MX010-WRITE-EXTRACT-DATA*/
			/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
			 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
			 */   
			// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
			//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

				/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
				//wSortKeyRecord.setCopyNbr(String.valueOf(x));
				wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
			// End Change - DLampa - 2024-09-17 - INC0037039.Issue1				
				endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());
				endBillRecord.setFiller(3241);
				hpFileHelper.appendWriteClose(endBillRecord);
			// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1				
			//}	
			// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1
			
			/*MOVE SPACES TO NONPREM-SA-SEQ OF BILL-PRINT-SORT-KEY*/
			wSortKeyRecord.NP_SA_PRIORITY_FLG = " ";
			wSortKeyRecord.NP_SA_ID = " ";
			wSortKeyRecord.NP_SA_REC_GRP_SEQ = " ";
			wSortKeyRecord.setNonPremSaSeq();
		}
		/*SET SW-NO OF WITH-SA-SW TO TRUE*/
		wWithSaSw = Bool.FALSE;
	}
		
	private void saAdj() {
		
		/*MOVE 0 TO W-LINE-SEQ*/
		wLineSeq = 0;
		
		Iterator<SQLResultRow> iter = getAdjSa(hpBill, wS_SA_OUT_DATA_SaID);
		while (iter.hasNext()) {
			
			SQLResultRow sqlRow = (SQLResultRow) iter.next();
			Date adjSaArsDt = sqlRow.getDate("ARS_DT");
			FinancialTransactionTypeLookup adjSaFtTypeFlg = (FinancialTransactionTypeLookup) 
					sqlRow.getLookup("FT_TYPE_FLG", FinancialTransactionTypeLookup.class);
			Adjustment_Id adjSaAdjID = (Adjustment_Id) sqlRow.getId("SIBLING_ID", Adjustment.class);
			@SuppressWarnings("unused")
			Currency_Id adjSaCurrencyID = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
			BigDecimal adjSaSumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			BigDecimal adjSaSumTotAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_TOT_AMT");

			/*PERFORM SQ190-GET-ADJDTL*/
			Adjustment adjDtlAdj = adjSaAdjID.getEntity();
			Date adjDtlCreDt = adjDtlAdj.getCreDt();
			AdjustmentCancelReason_Id adjDtlCanRsn = adjDtlAdj.getCancelReasonId();
			AdjustmentType adjDtlAdjType = adjDtlAdj.getAdjustmentType();
			String adjDtlDescr = adjDtlAdjType.fetchLanguageDescription();
			String adjDtlDescrOnBill = adjDtlAdjType.fetchLanguageDescriptionOnBill();
			@SuppressWarnings("unused")
			Bool adjDtlPrtDfltSw = adjDtlAdjType.getShouldPrintByDefault();
			
			if (wNonPremSw.isTrue()) {
				/*SET SA-REC-ADJ-DTL OF NP-SA-REC-GRP-SEQ TO TRUE*/
				wSortKeyRecord.NP_SA_REC_GRP_SEQ = CmPostRouteBillExtractSortKeyRecord.NP_SA_REC_ADJ_DTL;
				/*MOVE SIBLING-ID OF S-ADJSA TO NP-ADJ-ID OF NP-BSEG-ADJ-DETAIL-SECTION*/
				wSortKeyRecord.NP_ADJ_ID = adjSaAdjID.getTrimmedValue();
				/*MOVE CRE-DT OF S-ADJDTL TO NP-ADJ-CRE-DT OF NP-BSEG-ADJ-DETAIL-SECTION*/
				wSortKeyRecord.NP_ADJ_CRE_DT = adjDtlCreDt.toString().trim();
				wSortKeyRecord.setNonPremSaSeq();
			}
			else {
				/*SET SA-REC-ADJ-DTL OF SA-REC-GRP-SEQ TO TRUE*/
				wSortKeyRecord.setSaRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.SA_REC_ADJ_DTL);
				/*MOVE SIBLING-ID OF S-ADJSA TO ADJ-ID OF BSEG-ADJ-DETAIL-SECTION*/
				wSortKeyRecord.setAdjID(adjSaAdjID.getTrimmedValue());
				/*MOVE CRE-DT OF S-ADJDTL TO ADJ-CRE-DT OF BSEG-ADJ-DETAIL-SECTION*/
				wSortKeyRecord.setAdjCreDt(adjDtlCreDt.toString().trim());
			}
			
			/*SET BP-EXTR-TYPE-DTL-ADJSA OF BBPXT TO TRUE*/
			wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_ADJSA);
			/*MOVE CORR S-ADJSA TO BP-EXTR-DTL-ADJSA OF BBPXT*/
			wAdjDetailRecord = new CmPostRouteBillExtractDetailsAdjustmentDetailsRecord();
			wAdjDetailRecord.setFtTypeFlg(adjSaFtTypeFlg.value().trim());
			wAdjDetailRecord.setCurAmt(adjSaSumCurAmt, transformImpliedBD(adjSaSumCurAmt, 2));
			wAdjDetailRecord.setTotAmt(adjSaSumTotAmt, transformImpliedBD(adjSaSumTotAmt, 2));
			/*MOVE ARS-DT OF S-ADJSA TO ADJ-DT OF BP-EXTR-DTL-ADJSA OF BBPXT*/
			wAdjDetailRecord.setAdjDt(adjSaArsDt.toString().trim());
			/*MOVE CORR S-ADJDTL-OUT-DATA OF S-ADJDTL TO BP-EXTR-DTL-ADJSA OF BBPXT*/
			wAdjDetailRecord.setAdjTypeCd(adjDtlAdjType.getId().getTrimmedValue());
			wAdjDetailRecord.setAdjTypeDescr(adjDtlDescr);
			wAdjDetailRecord.setDescrOnBill(adjDtlDescrOnBill);
			if (notNull(adjDtlCanRsn)) {
				wAdjDetailRecord.setCanRsnCd(adjDtlCanRsn.getTrimmedValue());
				wAdjDetailRecord.setCanRsnDescr(adjDtlCanRsn.getEntity().fetchLanguageDescription().trim());
			}			
			
			wAdjDetailRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
			wAdjDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());
			wAdjDetailRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
			
			/*PERFORM MX010-WRITE-EXTRACT-DATA*/
			/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
			 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
			 */
			// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1			
			//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

				/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
				//wSortKeyRecord.setCopyNbr(String.valueOf(x));
				wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
			// End Change - DLampa - 2024-09-17 - INC0037039.Issue1				
				wAdjDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
				hpFileHelper.appendWriteClose(wAdjDetailRecord);	
			// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1				
			//}
			// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1		
		}		
	}
	
	private void endOfBseg() {
		
		//END-OF-BILL-SEGMENT RECORD
		/*IF SW-NO OF W-NON-PREMISE-SW*/
		if (wNonPremSw.isFalse()) {
			/*SET BSEG-REC-BSEG-END OF BSEG-ADJ-DETAIL-SECTION TO TRUE*/
			wSortKeyRecord.setBsegRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.BSEG_REC_GRP_SEQ_BSEG_REC_BSEG_END);
			/*MOVE SPACES TO CALC-HDR-LINE-DETAIL-SECTION OF BILL-PRINT-SORT-KEY */
			wSortKeyRecord.setCalcHdrSeq(" ");
			wSortKeyRecord.setBsegReadNbr(" ");
			wSortKeyRecord.setBsegSqNbr(" ");
			wSortKeyRecord.setBsegItemNbr(" ");
			wSortKeyRecord.setCalcHdrLineBsegMsgsNbr(" ");
			wSortKeyRecord.setCalcHdrRecGrpSeq(" ");
			wSortKeyRecord.setCalcLineSeq(" ");			
			/*SET BP-EXTR-TYPE-END-BSEG OF BBPXT TO TRUE*/
			wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_END_BSEG);
			
			/*
			 * END OF BSEG? BSEG DETAIL RECORD?
			 */
//			wBsegDetailRecord = new CmPostRouteBillExtractDetailsBillSegmentDetailRecord();
//			wBsegDetailRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
//			wBsegDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());
//			wBsegDetailRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
			CmPostRouteBillExtractGenericEndRecord endBillRecord = new CmPostRouteBillExtractGenericEndRecord();
			endBillRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
			endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());
			endBillRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
			
			/*PERFORM MX010-WRITE-EXTRACT-DATA*/
			/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
			 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
			 */     
			// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
			//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

				/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
				//wSortKeyRecord.setCopyNbr(String.valueOf(x));
				wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
			// End Change - DLampa - 2024-09-17 - INC0037039.Issue1				
				endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());	
				endBillRecord.setFiller(3241);
				hpFileHelper.appendWriteClose(endBillRecord);	
			// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1				
			//}	
			// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1		
			
			/*MOVE SPACES TO BSEG-ADJ-DETAIL-SECTION OF BILL-PRINT-SORT-KEY*/
			wSortKeyRecord.setBsegEndDt(" ");
			wSortKeyRecord.setAdjCreDt(" ");
			wSortKeyRecord.setHistDtlNbr(" ");
			wSortKeyRecord.setBsegID(" ");
			wSortKeyRecord.setAdjID(" ");
			wSortKeyRecord.setBsegRecGrpSeq(" ");
			
		}
		/*ELSE*/
		else {
			/*SET BSEG-REC-BSEG-END OF NP-BSEG-ADJ-DETAIL-SECTION TO TRUE*/
			wSortKeyRecord.NP_BSEG_REC_GRP_SEQ = CmPostRouteBillExtractSortKeyRecord.BSEG_REC_BSEG_END;
			/*MOVE SPACES TO NP-CALC-HDR-LINE-DETAIL-SECTION OF BILL-PRINT-SORT-KEY*/
			wSortKeyRecord.NP_CALCHDR_SEQ = " ";
			wSortKeyRecord.BSEG_MSGS_NBR = " ";
			wSortKeyRecord.NP_CALCHDR_REC_GRP_SEQ = " ";
			wSortKeyRecord.NP_CALC_LINE_SEQ = " ";
			wSortKeyRecord.setNonPremSaSeq();
			/*SET BP-EXTR-TYPE-ED-BSEG OF BBPXT TO TRUE*/
			wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_END_BSEG);
			
			/*
			 * END OF BSEG? BSEG DETAIL RECORD?
			 */
//			wBsegDetailRecord = new CmPostRouteBillExtractDetailsBillSegmentDetailRecord();
//			wBsegDetailRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
//			wBsegDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());
//			wBsegDetailRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
			CmPostRouteBillExtractGenericEndRecord endBillRecord = new CmPostRouteBillExtractGenericEndRecord();
			endBillRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
			endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());
			endBillRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
			
			/*PERFORM MX010-WRITE-EXTRACT-DATA*/
			/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
			 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
			 */         
			// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1			
			//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

				/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
				//wSortKeyRecord.setCopyNbr(String.valueOf(x));
				wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
			// End Change - DLampa - 2024-09-17 - INC0037039.Issue1				
				endBillRecord.setBPSortKey(wSortKeyRecord.createRecordString());	
				endBillRecord.setFiller(3241);
				hpFileHelper.appendWriteClose(endBillRecord);
			// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1				
			//}
			// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1			
			
			/*MOVE SPACES TO NP-BSEG-ADJ-DETAIL-SECTION OF BILL-PRINT-SORT-KEY*/
			wSortKeyRecord.NP_BSEG_END_DT = " ";
			wSortKeyRecord.NP_ADJ_CRE_DT = " ";
			wSortKeyRecord.NP_BSEG_ID = " ";
			wSortKeyRecord.NP_ADJ_ID = " ";
			wSortKeyRecord.NP_BSEG_REC_GRP_SEQ = " ";
			wSortKeyRecord.NP_CALCHDR_SEQ = " ";
			wSortKeyRecord.BSEG_MSGS_NBR = " ";
			wSortKeyRecord.NP_CALCHDR_REC_GRP_SEQ = " ";
			wSortKeyRecord.NP_CALC_LINE_SEQ = " ";
			wSortKeyRecord.setNonPremSaSeq();
		}
		/*SET SW-NO OF WITH-BSEG-SW TO TRUE*/
		wWithBsegSw = Bool.FALSE;		
	}
	
	private void saHistogram() {
		
		// Get the histogram for a service agreement.
		
		/*
		 * INITIALIZE W-UOM-CD OF W-WRK
		 *            W-TOU-CD OF W-WRK
		 *            W-SQI-CD OF W-WRK
		 */
		wUomCd = null;
		wTouCd = null;
		wSqiCd = null;
		/*MOVE 0 TO W-LINE-SEQ*/
		wLineSeq = 0;
		/*MOVE GRAPH-UOM-CD OF S-SA-OUT-DATA TO W-UOM-CD OF W-WRK*/
		wUomCd = wS_SA_OUT_DATA_GraphUomCd;
		/*SET SA-REC-HISTOGRAM-DTL TO TRUE*/
		wSortKeyRecord.setSaRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.SA_REC_HISTOGRAM_DTL);
		/*PERFORM NA120-CUSTOM-HISTOGRAM*/
		customHistogram();
		
		// Get all the additional graph UOMs
		List<String> saTypeCharValUom = getSaTypeCharList(
				wS_SA_OUT_DATA_CisDivID, wS_SA_OUT_DATA_SATypeCd, 
				parmCharTypeAdditionalHistogramUOMSAType);
		
		for (int x = 0; x < saTypeCharValUom.size(); x++) {
		
			/*
			 * INITIALIZE W-UOM-CD OF W-WRK
			 *            W-TOU-CD OF W-WRK
			 *            W-SQI-CD OF W-WRK
			 */
			wUomCd = null;
			wTouCd = null;
			wSqiCd = null;
			
			String saTypeCharVal = saTypeCharValUom.get(x);
			/*MOVE W-SATYPE-CHAR-VALUE OF W-WRK To W-UOM-CD OF W-WRK*/
			wUomCd = new UnitOfMeasure_Id(saTypeCharVal.trim());
			/*SET SA-UOM-CHAR-HIST TO TRUE*/
			wSortKeyRecord.setSaRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.SA_UOM_CHAR_HIST);
			/*PERFORM NA120-CUSTOM-HISTOGRAM*/
			customHistogram();			
		}
		// Get all the additional graph SQIs
		List<String> saTypeCharValSQI = getSaTypeCharList(
				wS_SA_OUT_DATA_CisDivID, wS_SA_OUT_DATA_SATypeCd, 
				parmCharTypeAdditionalHistogramSQISAType);
		
		for (int x = 0; x < saTypeCharValSQI.size(); x++) {
			/*
			 * INITIALIZE W-UOM-CD OF W-WRK
			 *            W-TOU-CD OF W-WRK
			 *            W-SQI-CD OF W-WRK
			 */
			wUomCd = null;
			wTouCd = null;
			wSqiCd = null;
			
			String saTypeCharVal = saTypeCharValSQI.get(x);
			/*MOVE W-SATYPE-CHAR-VALUE OF W-WRK TO W-SQI-CD OF W-WRK*/
			wSqiCd = new ServiceQuantityIdentifier_Id(saTypeCharVal.trim());
			/*SET SA-SQI-CHAR-HIST TO TRUE*/
			wSortKeyRecord.setSaRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.SA_SQI_CHAR_HIST);
			/*PERFORM NA120-CUSTOM-HISTOGRAM*/
			customHistogram();
		}
		/*MOVE SPACES TO HIST-DTL-NBR OF HISTOGRAM-DETAIL*/
		wSortKeyRecord.setHistDtlNbr(" ");
	}
	
	private void customHistogram() {
		
		// Get the histogram for a service agreement.
		CmBillPrintHistogramRoutine saHistogramRoutine = CmBillPrintHistogramRoutine.Factory.newInstance();
		/*MOVE ACCT-ID OF BBLLT TO ACCT-ID OF INPUT-WRK OF BHSTG*/
		saHistogramRoutine.setAcctID(wAcct.getId());
		/*MOVE SA-ID OF S-SA-OUT-DATA TO SA-ID OF INPUT-WRK OF BHSTG*/
		saHistogramRoutine.setSAID(wS_SA_OUT_DATA_SaID);
		/*MOVE BILL-ID OF BBLLT TO BILL-ID OF INPUT-WRK OF BHSTG*/ 
		saHistogramRoutine.setBillID(hpBill.getId());
		/*MOVE BILL-DT OF BBLLT TO BILL-DT OF INPUT-WRK OF BHSTG*/
		saHistogramRoutine.setBillDate(wBillDt);
		/*MOVE W-UOM-CD OF W-WRK TO UOM-CD OF INPUT-WRK OF BHSTG*/
		saHistogramRoutine.setUomID(wUomCd);
		/*MOVE W-TOU-CD OF W-WRK TO TOU-CD OF INPUT-WRK OF BHSTG*/
		saHistogramRoutine.setTouID(wTouCd);
		/*MOVE W-SQI-CD OF W-WRK TO SQI-CD OF INPUT-WRK OF BHSTG*/
		saHistogramRoutine.setSqiID(wSqiCd);
		
		/*PERFORM PA150-SA-HISTOGRAM*/
		saHistogramRoutine.invoke();
		/*IF SW-YES OF HISTOGRAM-FOUND-SW*/
		if (saHistogramRoutine.getHistogramFoundSw().isTrue()) {
			/*ADD 1 TO W-LINE-SEQ*/
			wLineSeq++;
			/*MOVE W-LINE-SEQ TO HIST-DTL-NBR OF HISTOGRAM-DETAIL OF BILL-PRINT-SORT-KEY*/
			wSortKeyRecord.setHistDtlNbr(String.valueOf(wLineSeq));
			/*SET BP-EXTR-TYPE-DTL-HISTGRM OF BBPXT TO TRUE*/
			wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_HISTGRM);
			/*MOVE CORR OUTPUT-WRK OF BHSTG TO BP-EXTR-DTL-HISTOGRAM OF BBPXT*/
			List<String> billSqList = saHistogramRoutine.getBillSqList();			
			wHistogramRecord = new CmPostRouteBillExtractDetailsHistogramRecord(billSqList.size());
			
			if (notNull(saHistogramRoutine.getUomID())) {
				wHistogramRecord.setUomCd(saHistogramRoutine.getUomID().getTrimmedValue());
			}
			if (notNull(saHistogramRoutine.getTouID())) {
				wHistogramRecord.setTouCd(saHistogramRoutine.getTouID().getTrimmedValue());
			}
			if (notNull(saHistogramRoutine.getSqiID())) {
				wHistogramRecord.setSqiCd(saHistogramRoutine.getSqiID().getTrimmedValue());
			}			
			wHistogramRecord.setSqDecPos(String.valueOf(saHistogramRoutine.getDecimalPosition()));
			wHistogramRecord.setSqCnt(String.valueOf(saHistogramRoutine.getSqCount()));
			BigDecimal maxBlSq = saHistogramRoutine.getMaxBillSq();//.setScale(6, BigDecimal.ROUND_HALF_UP);
			wHistogramRecord.setMaxBillSq(maxBlSq, transformImpliedBD(maxBlSq, 6));
			wHistogramRecord.setBillSqList(billSqList);
			
			wHistogramRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
			wHistogramRecord.setBPSortKey(wSortKeyRecord.createRecordString());
			wHistogramRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
			
			/*PERFORM MX010-WRITE-EXTRACT-DATA*/
			/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
			 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
			 */         
			// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
			//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

				/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
				//wSortKeyRecord.setCopyNbr(String.valueOf(x));
				wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
			// End Change - DLampa - 2024-09-17 - INC0037039.Issue1				
				wHistogramRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
				hpFileHelper.appendWriteClose(wHistogramRecord);		
			// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1				
			//}	
			// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1			
		}
	}
	
	private void extractMainBillDetails() {
		
		// Initialize Skip Bill Switch 
		hpIsBillSkipped = Bool.FALSE;
		// Get Main Person 
		wMainPerson = wAcct.getMainPerson();
		// Get Main Person's Primary Name
		wMainPersonName = wMainPerson.getPersonPrimaryName().trim();
		// Bill's Balance
		getBillBalance(hpBill);
		// Bill's Current Charge (Summary)
		getBillCurrentCharge(hpBill);
		// Bill's Corrections (Summary)
		getBillCorrectionCharge(hpBill);
		// Bill's Adjustment
		getBillAdjustment(hpBill);
		// Bill's Payment
		getBillPayment(hpBill);
		// Get Autopay details, if there are any
		getBillAutopayDetails(hpBill);
		// Determine if the Bill is the final bill	
		determineIfFinalBill();
		// Determine if account is a Cash Only account as of the bill date
		determineIfCashOnly();
		/*
		 * If the bill amount of the bill is not more than the minimum
		 * bill amount and the bill is a final bill, no need to extract.
		 * Compare the minimum bill amount and the bill amount only if
		 * the bill's account's currency code is the same as the one 
		 * on installation options.
		 */
		if (wInstallCurrencyID.compareTo(wAccountCurrencyID) == 0
				&& wBillBalTotAmt.compareTo(wInstallMinimumBillPrtAmt) < 0
				&& wBillBalCurAmt.compareTo(wInstallMinimumBillPrtAmt) < 0
				&& wIsFinalBillSw.isTrue()) {
			
			hpIsBillSkipped = Bool.TRUE;
		}
	}
	
	private void determineIfFinalBill() {
		
		// Initialize variable
		wIsFinalBillSw = Bool.FALSE;
		
		int cnt = getACTSTRT(wAcct);
		// No active or pending start SA
		if (cnt < 1) {
			// Get no clobs
			int clobsCount = getNoClobs(wAcct);
			if (clobsCount < 1) {
				// All SAs that are neither closed nor
			    // cancelled already have frozen closing bill segments.
				wIsFinalBillSw = Bool.TRUE;
			}
		}
	}
	
	private void determineIfCashOnly() {
		
		CmDetermineAcctCreditAndCashOnlyRatingRoutine determineAcctCredAndCashRatingRoutine = 
				CmDetermineAcctCreditAndCashOnlyRatingRoutine.Factory.newInstance();
		
		determineAcctCredAndCashRatingRoutine.setAccount(wAcct);
		determineAcctCredAndCashRatingRoutine.setRatingDate(wBillDt);
		determineAcctCredAndCashRatingRoutine.invoke();
		wIsCashOnlySw = determineAcctCredAndCashRatingRoutine.getHasExceedCreditRatingThresholdSw();		
	}
	
	private void prepareMainExtract() {
		
		/*
		 * Prepare the extract record for the bill
		 */
		/*SET BP-EXTR-TYPE-BILL OF BBPXT TO TRUE*/
		wPrinterKeyRecord = new CmPostRouteBillExtractPrinterKeyRecord();
		wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_BILL);
		
		wBillDetailRecord = new CmPostRouteBillExtractDetailsBillDetailsRecord();	
		/* MOVE CORR BBLLT TO BP-EXTR-BILL OF BBPXT */
		// BILL-ID
		wBillDetailRecord.setBillId(hpBill.getId().getTrimmedValue());
		// ACCT-ID
		wBillDetailRecord.setAcctId(wAcct.getId().getTrimmedValue());
		// BILL-DT
		String billDt = ((isNull(wBillDt)) ? " " : wBillDt.toString().trim());
		wBillDetailRecord.setBillDate(billDt);
		// DUE-DT
		String dueDt = ((isNull(hpBill.getDueDate())) ? " " : hpBill.getDueDate().toString().trim());
		wBillDetailRecord.setDueDate(dueDt);
		/*MOVE CURRENCY-CD OF CACCT TO ACCT-CURRENCY-CD OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setAcctCurrencyCd(wAccountCurrencyID.getTrimmedValue());
		/*MOVE CUR-SYMBOL... ...TO ACCT-CUR-SYMBOL OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setAcctCurSymbol(wAccountCurrencyID.getEntity().getCurrencySymbol());
		/*MOVE BBLRT TO BP-EXTR-BILL OF BBPXT*/
		// NBR-BILL-COPIES
		wBillDetailRecord.setNbrOfBillCopies(wBillRouting.getNumberOfBillCopies().toString());
		// BILL-FORMAT-FLG
		wBillDetailRecord.setBillFormatFlag(wBillRouting.getBillFormat().value());
		// CUST-PO-ID
		wBillDetailRecord.setCustPoId(wBillRouting.getCustomerPOId());
		// ENTITY-NAME1
		wBillDetailRecord.setEntityName1(wBillRouting.getEntityName1());
		// ENTITY-NAME2
		wBillDetailRecord.setEntityName2(wBillRouting.getEntityName2());
		// ENTITY-NAME3
		wBillDetailRecord.setEntityName3(wBillRouting.getEntityName3());
		// COUNTRY
		wBillDetailRecord.setCountry(wBillRouting.getCountryId().getTrimmedValue());
		// ADDRESS1
		wBillDetailRecord.setAddress1(cmFormat(wBillRouting.getAddress1()));
		// ADDRESS2
		wBillDetailRecord.setAddress2(cmFormat(wBillRouting.getAddress2()));
		// ADDRESS3
		wBillDetailRecord.setAddress3(cmFormat(wBillRouting.getAddress3()));
		// ADDRESS4
		wBillDetailRecord.setAddress4(cmFormat(wBillRouting.getAddress4()));
		// CITY
		wBillDetailRecord.setCity(cmFormat(wBillRouting.getCity()));
		// NUM1
		wBillDetailRecord.setNum1(cmFormat(wBillRouting.getStreetNumber1()));
		// NUM2
		wBillDetailRecord.setNum2(cmFormat(wBillRouting.getStreetNumber2()));
		// HOUSE-TYPE
		wBillDetailRecord.setHouseType(cmFormat(wBillRouting.getHouseType().value()));
		// COUNTY
		wBillDetailRecord.setCounty(cmFormat(wBillRouting.getCounty()));
		// STATE
		wBillDetailRecord.setState(cmFormat(wBillRouting.getState()));
		// POSTAL
		wBillDetailRecord.setPostal(cmFormat(wBillRouting.getPostal()));
		// GEO-CODE
		wBillDetailRecord.setGeoCode(cmFormat(wBillRouting.getTaxVendorGeographicalCode()));
		// IN-CITY-LIMIT
		wBillDetailRecord.setInCityLimit(transformToYorN(wBillRouting.getIsInCityLimit()));
		// REPRINT-SW
		wBillDetailRecord.setReprintSw(transformToYorN(wBillRouting.getShouldReprint()));
		// BILL-PRT-INTERCEPT
		// start update - equint - 2025-11-14 - CCB25.4 Upgrade
		// wBillDetailRecord.setBillPrintIntercept(wBillRouting.getBillPrintIntercept());
		// start add - ogc06199 - 2026-02-04 - Defect # 5157603
		if (!isNull(wBillRouting.getBillPrintInterceptId())) {
			//end add - ogc06199 - 2026-02-04 - Defect # 5157603
			wBillDetailRecord.setBillPrintIntercept(wBillRouting.getBillPrintInterceptId().getTrimmedValue());
			// start add - ogc06199 - 2026-02-04 - Defect # 5157603
		}
		//end add - ogc06199 - 2026-02-04 - Defect # 5157603
		// end update - equint - 2025-11-14 - CCB25.4 Upgrade
		/*MOVE ENTITY-NAME1 OF BBLRT TO ENTITY-NAME OF BBPXT*/
		wBillDetailRecord.setEntityName(wBillRouting.getEntityName1());
		/*MOVE ENTITY-NAME OF CPPNI TO ACCT-ENTITY-NAME OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setAcctEntityName(wMainPersonName);
		/*MOVE CUR-AMT OF S-BLBAL TO CUR-BAL PF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setCurrentBalance(wBillBalCurAmt.getAmount(), transformImpliedBD(wBillBalCurAmt.getAmount(), 2));
		/*MOVE TOT-AMT OF S-BLBAL TO TOT-BAL OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setTotalBal(wBillBalTotAmt.getAmount(), transformImpliedBD(wBillBalTotAmt.getAmount(), 2));
		/*MOVE CUR-AMT OF S-CURRCHG TO CUR-CHG-AMT OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setCurrentChargeAmt(wBillChargeCurAmt.getAmount(), transformImpliedBD(wBillChargeCurAmt.getAmount(), 2));
		/*MOVE TOT-AMT OF S-CURRCHG TO TOT-CHG-AMT OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setTotalChargeAmt(wBillChargeTotAmt.getAmount(), transformImpliedBD(wBillChargeTotAmt.getAmount(), 2));
		/*MOVE CUR-AMT OF S-CORRCHG TO CUR-CORR-AMT OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setCurrentCorrAmt(wBillCorrCurAmt.getAmount(), transformImpliedBD(wBillCorrCurAmt.getAmount(), 2));
		/*MOVE TOT-AMT OF S-CORRCHG TO TOT-CORR-AMT OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setTotalCorrAmt(wBillCorrTotAmt.getAmount(), transformImpliedBD(wBillCorrTotAmt.getAmount(), 2));
		/*MOVE CUR-AMT OF S-ADJSUMM TO CUR-ADJ-AMT OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setCurrentAdjAmt(wBillAdjCurAmt.getAmount(), transformImpliedBD(wBillAdjCurAmt.getAmount(), 2));
		/*MOVE TOT-AMT OF S-ADJSUMM TO TOT-ADJ-AMT OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setTotalAdjAmt(wBillAdjTotAmt.getAmount(), transformImpliedBD(wBillAdjTotAmt.getAmount(), 2));
		/*MOVE CUR-AMT OF S-PAYSUMM TO CUR-PAY-AMT OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setCurrentPayAmt(wBillPayCurAmt.getAmount(), transformImpliedBD(wBillPayCurAmt.getAmount(), 2));
		/*MOVE TOT-AMT OF S-PAYSUMM TO TOT-PAY-AMT OF BP-EXTR-BILL OF BBPXT*/ 
		wBillDetailRecord.setTotalPayAmt(wBillPayTotAmt.getAmount(), transformImpliedBD(wBillPayTotAmt.getAmount(), 2));
		/*MOVE SCHED-EXTRACT-DT OF S-BILLAPY TO APAY-EXTRACT-DT OF BP-EXTR-BILL OF BBPXT*/
		String apaySchedExt = ((isNull(wBillApaySchedExtractDt)) ? " " : wBillApaySchedExtractDt.toString().trim());		 
		wBillDetailRecord.setApayExtractDate(apaySchedExt);
		/*
		 * COMPUTE W-CUR-PREV-BAL = (W-CUR-BAL - W-CUR-CHG-AMT -
         *                           W-CUR-ADJ-AMT - W-CUR-PAY-AMT -
         *                           W-CUR-CORR-AMT)
         * COMPUTE W-TOT-PREV-BAL = (W-TOT-BAL - W-TOT-CHG-AMT -
         *                           W-TOT-ADJ-AMT - W-TOT-PAY-AMT -
         *                           W-TOT-CORR-AMT)
		 */
		wCurrPrevBal = wBillBalCurAmt.subtract(wBillChargeCurAmt)
						.subtract(wBillAdjCurAmt).subtract(wBillPayCurAmt)
						.subtract(wBillCorrCurAmt);
		wTotPrevBal = wBillBalTotAmt.subtract(wBillChargeTotAmt)
						.subtract(wBillAdjTotAmt).subtract(wBillPayTotAmt)
						.subtract(wBillCorrTotAmt);
		
		// Since payment amount is negative, delinquent amount is
		// computed as previous balance + payment amount.
		
		/* COMPUTE W-DELINQUENT-AMT = (W-CUR-PREV-BAL + W-CUR-PAY-AMT) */
		wDelinquentAmt = wCurrPrevBal.add(wBillPayCurAmt);
		/*MOVE W-CUR-PREV-BAL TO CUR-PREV-BAL OF BP-EXTR-BILL*/
		wBillDetailRecord.setCurrentPrevBal(wCurrPrevBal.getAmount(), transformImpliedBD(wCurrPrevBal.getAmount(), 2));
		/*MOVE W-TOT-PREV-BAL TO TOT-PREV-BAL OF BP-EXTR-BILL*/
		wBillDetailRecord.setTotalPrevBal(wTotPrevBal.getAmount(), transformImpliedBD(wTotPrevBal.getAmount(), 2));
		/*MOVE W-DELINQUENT-AMT TO DELINQUENT-AMT OF BP-EXTR-BILL*/
		wBillDetailRecord.setDelinquentAmt(wDelinquentAmt.getAmount(), transformImpliedBD(wDelinquentAmt.getAmount(), 2));
		/*MOVE W-FINAL-BILL-SW TO FINAL-BILL-SW OF BP-EXTR-BILL*/
		wBillDetailRecord.setIsFinalBillSw(transformToYorN(wIsFinalBillSw));
		/*MOVE W-CASH-ONLY-SW TO CASH-ONLY-SW OF BP-EXTR-BILL*/
		wBillDetailRecord.setIsCashOnlySw(transformToYorN(wIsCashOnlySw));
		
		// Prepare the Sort Keys for the Bill
		wSortKeyRecord = new CmPostRouteBillExtractSortKeyRecord();
		/*MOVE BILL-ID OF BBLRT TO BILL-ID OF BILL-PRINT-SORT-KEY OF BBPXT*/
		wSortKeyRecord.setBillId(hpBill.getId().getTrimmedValue());
		/*MOVE SEQNO OF BLLRT TO SEQNO OF BILL-PRINT-SORT-KEY OF BBPXT*/
		wSortKeyRecord.setSeqNbr(hpSequenceNumber.toString().trim());
		/*SET BILL-REC-BILL OF BILL-PRINT-SORT-KEY TO TRUE*/
		wSortKeyRecord.setBillRecordGroupSeq(CmPostRouteBillExtractSortKeyRecord.BILL_REC_BILL);
		
		// Prepare the Mailing Keys for the Bill
		/*MOVE POSTAL OF BBLRT TO POSTAL OF BILL-PRINT-MAILING-KEY OF BBPXT*/
		wMailingKeyRecord = new CmPostRouteBillExtractMailingKeyRecord();
		wMailingKeyRecord.setPostal(wBillRouting.getPostal());
		
		/*
		 * START Custom Fields for Bill Details
		 */
		// BILL-CUSTOM-FIELDS		
		// Total Credit Adjustment
		Money totCreditAdjAmt = getTotCrAdj(hpBill);
		/*MOVE CUR-AMT OF S-CRDADJ TO TOT-CRD-ADJ OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setTotCredAdj(totCreditAdjAmt.getAmount(), transformImpliedBD(totCreditAdjAmt.getAmount(), 2));
		// Total Pledge Payments
		getTotPlgPay(hpBill, parmCharTypePledgePayment);
		/*MOVE TOT-AMT OF S-PLDGPAY TO TOT-PLG-PAY OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setTotPlgPay(wTotPldgPayAmt.getAmount(), transformImpliedBD(wTotPldgPayAmt.getAmount(), 2));
		// Total Customer Payments
		Money totPayAmt = getTotPay(hpBill);
		/*
		 * COMPUTE TOT-CST-PAY OF BP-EXTR-BILL OF BBPXT
		 *         = W-TOT-PAYMENTS OF W-WRK
		 *         - CUR-AMT OF S-PLDGPAY
		 */
		Money totCstPay = totPayAmt.subtract(wCurrPldgPayAmt);
		wBillDetailRecord.setTotCstPay(totCstPay.getAmount(), transformImpliedBD(totCstPay.getAmount(), 2));
		if (notNull(hpBill.getLatePaymentChargeDate())) {
			wBillDetailRecord.setLatePayChargeDate(hpBill.getLatePaymentChargeDate().toString());
		}			
		/*MOVE W-REGULAR-PAY-HEADER OF W-WRK TO CST-PAY-BILL-DESCR OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setCstPayBillDescr(getLookupValueDescr(parmLookupFieldBillPrintHeaderDescr, parmLookupValueCustomerPaymentHeader));
		/*MOVE W-PLEDGE-PAY-HEADER OF W-WRK TO PLG-PAY-BILL-DESCR OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setPlgPayBillDescr(getLookupValueDescr(parmLookupFieldBillPrintHeaderDescr, parmLookupValuePledgePaymentHeader));
		// LPC Adjustments
		getLpcAdj(hpBill, parmCharTypeLatePaymentAdjustment);
		/*MOVE CUR-AMT OF S-LPCADJ-OUT-DATA TO TOT-LPC OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setTotalLPC(wCurrLpcAdjAmt.getAmount(), transformImpliedBD(wCurrLpcAdjAmt.getAmount(), 2));
		/*MOVE CIS-DIVISION OF CACCT TO CIS-DIVISION OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setCisDivision(wAcct.getDivisionId().getTrimmedValue());
		// Get Remit Value
		String remitValue = getAcctChar(wAcct, parmCharTypeRemitTo, wBillDt);
		
		if (isBlankOrNull(remitValue)) {			
			remitValue = getCisDivChar(wAcct.fetchDivision(), parmCharTypeRemitTo, wBillDt);
			if (isBlankOrNull(remitValue)) {
				remitValue = parmCharValDefaultRemitTo;
			}			
		}		
		/*MOVE W-REMIT-TO-VALUE OF W-WRK TO REMIT-TO-FLG OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setRemitToFlg(remitValue);

		// CCB Check Digit
		CmAccountCheckDigitRetriever acctCheckDigitRetriever = CmAccountCheckDigitRetriever.Factory.newInstance();
		acctCheckDigitRetriever.inputAccount(wAcct.getId().getTrimmedValue());
		acctCheckDigitRetriever.execute();
		String acctCheckDigit = acctCheckDigitRetriever.getCheckDigit();
		/*MOVE ACCT-CHECK-DIGIT OF CACDN TO CHK-DGT OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setCheckDigit(acctCheckDigit);
		
		// Autopay
		Bool hasAutopaySw = checkAutopay(wAcct, wBillDt, wBillDt);
		wBillDetailRecord.setAutopayFlg(transformToYorN(hasAutopaySw));
		
		// Email Address
		/*MOVE EMAILID OF CPERT TO EMAIL OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setEmail(wMainPerson.getEmailAddress());
		
		// Budget Details
		getBudgetDetails(wAcct, ServiceAgreementStatusLookup.constants.CLOSED, hpBill);
		/*MOVE DESCR OF S-BUDAMT TO BUD-DESCR-ON-BILL OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setBudgetDescrOnBill(wBudgetPlanDescr);
		/*MOVE BUD-PLAN-CD OF S-BUDAMT TO BUD-PLAN-CD OF BP-EXTR-BILL OF BBPXT*/
		if (notNull(wBudgetPlanID)) {
			wBillDetailRecord.setBudgetPlanCode(wBudgetPlanID.getTrimmedValue());
		}		
		
		Iterator<SQLResultRow> budgetDetails2 = getBudgetDetails2(wAcct, 
				ServiceAgreementStatusLookup.constants.CLOSED, hpBill, parmCharTypeBudgetPaymentArrangement);
		
		while (budgetDetails2.hasNext()) {
			SQLResultRow sqlRow = (SQLResultRow) budgetDetails2.next();
			ServiceAgreement_Id budgetDetailSAID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
			BillSegment_Id budgetDetailBsegID = (BillSegment_Id) sqlRow.getId("BSEG_ID", BillSegment.class);
			
			getBsegFT(hpBill, budgetDetailSAID, budgetDetailBsegID);
			/*ADD CUR-AMT OF S-BSEGFT TO RCR-CHG-AMT OF S-BUDAMT*/
			wBudgetRecurringChargeAmt = wBudgetRecurringChargeAmt.add(wBsegFtCurAmt);		
		}
		
		/*MOVE RCR-CHG-AMT OF S-BUDAMT TO BUD-AMT OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setBudgetAmount(wBudgetRecurringChargeAmt.getAmount(), transformImpliedBD(wBudgetRecurringChargeAmt.getAmount(), 2));
		
		/*
		 * IF BUD-AMT OF BP-EXTR-BILL OF BBPXT = ZERO
		 *     INITIALIZE BUD-AMT OF BP-EXTR-BILL OF BBPXT
		 *     INITIALIZE BUD-PLAN-CD OF BP-EXTR-BILL OF BBPXT
		 *     INITIALIZE BUD-DESCR-ON-BILL OF BP-EXTR-BILL OF BBPXT
		 * END-IF
		 */
		if (wBudgetRecurringChargeAmt.getAmount().compareTo(BigDecimal.ZERO) == 0) {
			wBillDetailRecord.setBudgetAmount(BigDecimal.ZERO, "0");
			wBillDetailRecord.setBudgetPlanCode(" ");
			wBillDetailRecord.setBudgetDescrOnBill(" ");
		}
		// Dollar Help
		String defaultDhelpDescrOnBill = getDHelpDescr(wAcct, parmCharTypeDollarHelpSA, wMainPerson.getLanguage());
		/*MOVE DFLT-DESCR-ON-BILL OF S-DHELP TO DH-DESCR OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setDhDescr(defaultDhelpDescrOnBill);
		
		DateTime startDttm = new DateTime(wBillDt.getYear(), 1, 1, 0, 0, 0);
		DateTime endDttm = new DateTime(wBillDt.getYear(), wBillDt.getMonth(), wBillDt.getDay(), 23, 59, 59);
		Money dollarHelpCurAmt = getDollarHelpAmt(wAcct, startDttm, endDttm, parmCharTypeDollarHelpSA);
		/*MOVE CUR-AMT OF S-DHAMT TO DH-YTD-PD OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setDhYtdPd(dollarHelpCurAmt.getAmount(), transformImpliedBD(dollarHelpCurAmt.getAmount(), 2));
		
		// School Aggregate
		String schoolAggregate = getAcctChar(wAcct, parmCharTypeSchoolAggregationAccount, wBillDt);
		Bool schoolAG = Bool.FALSE;
		if (notBlank(schoolAggregate)
				&& schoolAggregate.trim().compareTo(parmCharValueSchoolAggregationAccount.trim()) == 0) {
			schoolAG = Bool.TRUE;			
		}
		wBillDetailRecord.setSchlAgFlg(transformToYorN(schoolAG));
		
		// Total Gross Amount
		// Get All The Bill Segments of the Bill		
		Iterator<SQLResultRow> collBsegs = getBillBsegs(hpBill);
		while (collBsegs.hasNext()) {
			SQLResultRow sqlRow = (SQLResultRow) collBsegs.next();
			BillSegment_Id bsegID = (BillSegment_Id) sqlRow.getId("BSEG_ID", BillSegment.class);
			BigInteger headerSeq = (BigInteger) sqlRow.getInteger("HEADER_SEQ");
			
			// Get Calc Line
			getCalcLine(bsegID, headerSeq, parmCharTypeGrossAmount);
			/*
			 * COMPUTE W-TOTAL-GROSS-AMT = W-TOTAL-GROSS-AMT
			 *         + CALC-AMT OF S-CLCHAR
			 */
			wTotalGrossAmt = wTotalGrossAmt.add(wClCharCalcAmt);			
		}
		
		// Add Bill Amount to Gross Amount
		/*
		 * COMPUTE W-TOTAL-GROSS-AMT = W-TOTAL-GROSS-AMT 
		 *         + CUR-AMT OF S-BLBAL
		 */
		wTotalGrossAmt = wTotalGrossAmt.add(wBillBalCurAmt);
		/*MOVE W-TOTAL-GROSS-AMT OF W-WRK TO TOT-BILL-GROSS OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setTotalBillGross(wTotalGrossAmt.getAmount(), transformImpliedBD(wTotalGrossAmt.getAmount(), 2));
		
		// Current Charges without the budget payment arrangement charges
		getCurrPA(hpBill, SpecialRoleLookup.constants.PAYMENT_ARRANGEMENT);
		
		// Get Dollar Help Current Amount
		getDollarHelpBillAmt(hpBill, parmCharTypeDollarHelpSA);
		
		// PERFORM NA020-CORRECTION-BSEG
		na020CorrectionBseg();
		
		// Start Add - DLampa - 2024-07-30 - INC0037039
        if(budgetSw.isTrue()){
            //Previous Total Payoff Balance
        	BigDecimal wTotalPreviousAccountBalance= wCorrTotAmt.getAmount().subtract(wBillChargeTotAmt.getAmount());
        	wBillDetailRecord.setTotPrevAcctBal(budgetSw, wTotalPreviousAccountBalance, transformImpliedBD(wTotalPreviousAccountBalance, 2));        	
        	
            //Current Total Payoff Balance        	
        	wBillDetailRecord.setTotCurrAcctBal(budgetSw, wCorrTotAmt.getAmount(), transformImpliedBD(wCorrTotAmt.getAmount(), 2));
        }
        // End Add - DLampa - 2024-07-30 - INC0037039
		
		// Compute Adjustments on this bill excluding Payment Arrangements
		getOtherAdj(FinancialTransactionTypeLookup.constants.ADJUSTMENT,
				FinancialTransactionTypeLookup.constants.ADJUSTMENT_CANCELLATION,
				hpBill);
		
		getDepositLoanAmt(hpBill, SpecialRoleLookup.constants.CASH_DEPOSIT,
				SpecialRoleLookup.constants.LOAN);
		
		/*MOVE CUR-AMT OF S-CDLOAMT TO W-DEP-LOAN-AMT OF W-WRK*/
		wDepLoanAmt = wDepLoanCurAmt;
		
		/*
		 * COMPUTE W-NEW-TOT-CURR-CHG-AMT OF W-WRK
		 *         = TOT-AMT OF S-CURRCHG
		 *         + CUR-AMT OF DHBAMT
		 *         + W-CORR-TOT-AMT OF W-WRK
		 *         + W-OTHERS-ADJ-AMT OF W-WRK
		 *         + W-DEP-LOAN-AMT OF W-WRK
		 *         - TOT-AMT OF S-CDLOAMT
		 */
		wNewTotCurrChgAmt = wBillChargeTotAmt.add(wDHCurAmt)
				.add(wCorrTotAmt)
				.add(wOtherAdjCurAmt)
				.add(wDepLoanAmt)
				.subtract(wDepLoanTotAmt);		
		
		/*MOVE W-NEW-TOT-CURR-CHG-AMT OF W-WRK To CUR-CHGAMT-SUBPA OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setCurrChargeAmountSubPa(wNewTotCurrChgAmt.getAmount(), transformImpliedBD(wNewTotCurrChgAmt.getAmount(), 2));
		
		// New Previous Balance
		Money prevNonCDLoanTotAmt = getPrevNonCDLoan(hpBill, wBillDt);
		
		Money prevVDLoanCurAmt = getPrevCDLoan(hpBill, wBillDt);
		
		// Getting Previous Gas Balance alone
		Money prevOthBalTotAmt = getPrevOtherBal(hpBill, wBillDt);
		
		/*MOVE TOT-AMT OF S-PBALBUD TO W-NEW-PREV-GAS-BAL-AMT OF W-WRK*/
		wNewPrevGasBalAmt = prevNonCDLoanTotAmt;
		
		/*MOVE W-NEW-PREV-GAS-BAL-AMT OF W-WRK To NEW-PREV-GAS-BAL OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setNewPrevGasBal(wNewPrevGasBalAmt.getAmount(), transformImpliedBD(wNewPrevGasBalAmt.getAmount(), 2));
		
		// Getting Previous Other SA Balance
		/*
		 * COMPUTE W-NEW-PREV-OTHR-BAL-AMT OF W-WRK = 
		 *         TOT-AMT OF S-PBALOTH
		 *         + CUR-AMT OF S-PBLCDLO
		 */
		wNewPrevOthrBalAmt = prevOthBalTotAmt.add(prevVDLoanCurAmt);
		
		/*MOVE W-NEW-PREV-OTHR-BAL-AMT OF W-WRK TO NEW-PREV-OTH-AMT OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setNewPrevOthAmt(wNewPrevOthrBalAmt.getAmount(), transformImpliedBD(wNewPrevOthrBalAmt.getAmount(), 2));
		
		/*
		 * COMPUTE W-NEW-PREV-BAL-AMT =
		 *         W-NEW-PREV-GAS-BAL-AMT
		 *         + W-NEW-PREV-OTHR-BAL-AMT
		 */
		wNewPrevBalAmt = wNewPrevGasBalAmt.add(wNewPrevOthrBalAmt);
		
		// New Total Balance
		/*
		 * COMPUTE W-NEW-TOTAL-BAL-AMT OF W-WRK = 
		 *         W-NEW-PREV-BAL-AMT OF W-WRK
		 *         + W-TOT-PAY-AMT OF W-WRK
		 *         + W-NEW-TOT-CURR-CHG-AMT OF W-WRK
		 */
		wNewTotalBalAmt = wNewPrevBalAmt
				.add(wBillPayTotAmt)
				.add(wNewTotCurrChgAmt);
		
		/*MOVE W-NEW-TOTAL-BAL-AMT OF W-WRK TO NEW-TOTAL-BAL OF BP-EXTR-BILL OF BBPXT*/
		wBillDetailRecord.setNewTotalBal(wNewTotalBalAmt.getAmount(), transformImpliedBD(wNewTotalBalAmt.getAmount(),  2));

		// Start Add - DLampa - 2024-07-30 - INC0037039
		// OCR Scan Line
        String companyCodeStr = getCisDivChar(wAcct.fetchDivision(), parmCharTypeCisDivisionCompanyCode, wBillDt).trim();
        String paddedAccountIdStr = StringUtilities.leftPadWithZeros(wAcct.getId().getTrimmedValue(), 13);

        String currentBalanceStr = "";
        if (wBillBalCurAmt.getAmount().compareTo(BigDecimal.ZERO) <= 0){
            currentBalanceStr = "000000000";
        }
        else {
            currentBalanceStr = wBillBalCurAmt.getAmount().toString().replace(".", "");
            if (currentBalanceStr.length() < 10){
                currentBalanceStr = StringUtilities.leftPadWithZeros(currentBalanceStr, 9);
            }
            else {                
                return;
            }
        }
        String acceptCodeStr = "0";
        if (checkNonSufficientIndicator().isTrue()){
            acceptCodeStr = "9";
        }

        CmCheckDigitMod10Retriever checkDigitMod10Retriever = CmCheckDigitMod10Retriever.Factory.newInstance();
        String ocrScanLine = companyCodeStr.concat(paddedAccountIdStr).concat(currentBalanceStr);
        checkDigitMod10Retriever.inputString(ocrScanLine);
        checkDigitMod10Retriever.execute();
        String checkDigitMod10 = checkDigitMod10Retriever.getCheckDigitMod10();
        ocrScanLine = ocrScanLine.concat(acceptCodeStr).concat(checkDigitMod10);
        wBillDetailRecord.setOcrScanLine(ocrScanLine);
        // End Add - DLampa - 2024-07-30 - INC0037039
		
		/*
		 * END Custom Fields for Bill Details
		 */

		wBillDetailRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
		wBillDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());
		wBillDetailRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
		
		/*PERFORM MX010-WRITE-EXTRACT-DATA*/
		/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
		 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
		 */  
		// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1		
		//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

			/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
			//wSortKeyRecord.setCopyNbr(String.valueOf(x));
			wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
		// End Change - DLampa - 2024-09-17 - INC0037039.Issue1			
			wBillDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());
			// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1			
			//wBillDetailRecord.setCopyNbr(String.valueOf(x));
			wBillDetailRecord.setCopyNbr(hpNumberOfCopiesIdx);
			// End Change - DLampa - 2024-09-17 - INC0037039.Issue1			
			hpFileHelper.appendWriteClose(wBillDetailRecord);
		// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1			
		//}	
		// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1		
		
		/*
		 * COMPUTE TOT-AMT-BILLED OF BXZZX 
		 *         = TOT-AMT-BILLED OF BXZZX
		 *         + TOT-AMT OF S-CURRCHG-OUT-DATA
		 */
		wTotAmtBilled = wTotAmtBilled.add(wBillChargeTotAmt);
	}
	
	private void billCharges() {
		
		// Payment Arrangement Charges (Custom)
		Iterator<SQLResultRow> collOfPaSAS = getPaSAS(hpBill, SpecialRoleLookup.constants.PAYMENT_ARRANGEMENT, parmCharTypeBudgetPaymentArrangement);
		while (collOfPaSAS.hasNext()) {
			
			SQLResultRow sqlRow = (SQLResultRow) collOfPaSAS.next();
			ServiceAgreement_Id saID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
			String saTypeStr = sqlRow.getString("SA_TYPE_CD");
			String descrOnBill = sqlRow.getString("DESCR_ON_BILL");
			BigDecimal calcAmt = (BigDecimal) sqlRow.getBigDecimal("CALC_AMT");			
			calcAmt = calcAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			//calcAmt = calcAmt.setScale(2, BigDecimal.ROUND_HALF_EVEN);
			
			// Write PA Charges
			writePaCharges(saID, saTypeStr, descrOnBill, calcAmt);
		}
		
		// Current Charges per debt class
		wLineSeq = 0;
		Iterator<SQLResultRow> collOfCurrDC = getNextCurrDc(hpBill, this.getActiveContextLanguage());
		while(collOfCurrDC.hasNext()) {
			
			SQLResultRow sqlRow = (SQLResultRow) collOfCurrDC.next();
			DebtClass_Id debtClassCd = (DebtClass_Id) sqlRow.getId("DEBT_CL_CD", DebtClass.class);
			String descr = (String) sqlRow.getString("DESCR");
			Currency_Id currencyID = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			BigDecimal sumTotAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_TOT_AMT");
			sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			sumTotAmt = sumTotAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_EVEN);
			//sumTotAmt = sumTotAmt.setScale(2, BigDecimal.ROUND_HALF_EVEN);
			
			/*ADD 1 TO W-LINE-SEQ*/
			wLineSeq++;
			/*SET CURR-CHG-DTL OF BBPXT TO TRUE*/
			wSortKeyRecord.setBillRecordGroupSeq(CmPostRouteBillExtractSortKeyRecord.CURR_CHG_DTL);
			// Write Current Charges Per Debt Class
			writeCurrentChargesDebtClass(debtClassCd, descr, currencyID, sumCurAmt, sumTotAmt);			
		}
		
		// Correction Charges (Custom)
		if (notNull(wCorrStartDt)) {
			/*PERFORM NA030-WRITE-CORRECTION-BSEG*/
			writeCorrectionBseg();
		}
		
		// Other Charges (Custom)
		/*PERFORM NA040-OTHER-CHARGES*/
		otherCharges();
		
		// Payments
		wLineSeq = 0;
		Iterator<SQLResultRow> collOfPay = getPayDtl(hpBill);
		
		while (collOfPay.hasNext()) {
			SQLResultRow sqlRow = (SQLResultRow) collOfPay.next();
			FinancialTransactionTypeLookup ftType = 
					(FinancialTransactionTypeLookup) sqlRow.getLookup("FT_TYPE_FLG", FinancialTransactionTypeLookup.class);
			Date arsDt = (Date) sqlRow.getDate("ARS_DT");
			PaymentCancelReason_Id canRsnCd = (PaymentCancelReason_Id) sqlRow.getId("CAN_RSN_CD", PaymentCancelReason.class);	
			@SuppressWarnings("unused")
			Currency_Id currencyCd = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
			BigDecimal curAmt = (BigDecimal) sqlRow.getBigDecimal("CUR_AMT");
			BigDecimal totAmt = (BigDecimal) sqlRow.getBigDecimal("TOT_AMT");
			Payment_Id payID = (Payment_Id) sqlRow.getId("PAY_ID", Payment.class);
			PaymentEvent_Id payEventID = (PaymentEvent_Id) sqlRow.getId("PAY_EVENT_ID", PaymentEvent.class);
			curAmt = curAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			totAmt = totAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			//curAmt = curAmt.setScale(2, BigDecimal.ROUND_HALF_EVEN);
			//totAmt = totAmt.setScale(2, BigDecimal.ROUND_HALF_EVEN);
			
			wPaymentDetailsRecord = new CmPostRouteBillExtractDetailsPaymentDetailsRecord();
			/*ADD 1 TO W-LINE-SEQ*/
			wLineSeq++;
			/*SET PAY-DTL-DTL OF BBPXT OF TRUE*/
			wSortKeyRecord.setBillRecordGroupSeq(CmPostRouteBillExtractSortKeyRecord.PAY_DTL_DTL);			
			/*SET BP-EXTR-TYPE-DTL-PAYDTL OF BBPXT TO TRUE*/
			wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_PAYDTL);			
			/*MOVE FT-TYPE-FLG OF S-PAYDTL TO FT-TYPE-FLG OF S-PAYDTL*/
			wPaymentDetailsRecord.setFtTypeFlg(ftType.value().trim());
			/*MOVE ARS-DT OF S-PAYDTL TO PAY-DT OF BP-EXTR-DTL-PAYDTL*/
			wPaymentDetailsRecord.setPayDt(arsDt.toString().trim());
			/*MOVE CAN-RSN-CD OF PAYDTL TO CAN-RSN-CD OF BP-EXTR-DTL-PAYDTL*/
			wPaymentDetailsRecord.setCanRsnCd(canRsnCd.getTrimmedValue());
			/*MOVE CUR-AMT OF S-PAYDTL TO CUR-PAY-AMT OF BP-EXTR-DTL-PAYDTL*/
			wPaymentDetailsRecord.setCurPayAmt(curAmt, transformImpliedBD(curAmt, 2));
			/*MOVE TOT-AMT OF S-PAYDTL TO TOT-PAY-AMT OF BP-EXTR-DTL-PAYDTL*/
			wPaymentDetailsRecord.setTotPayAmt(totAmt, transformImpliedBD(totAmt, 2));
			
			if (notNull(canRsnCd) 
					&& notNull(canRsnCd.getEntity())) {
				/*MOVE DESCR OF TPCRT TO CAN-RSN-DESCR OF BP-EXTR-DTL-PAYDTL*/
				wPaymentDetailsRecord.setCanRsnDescr(
						canRsnCd.getEntity().fetchLanguageDescription().trim());
			}
			
			/*PERFORM NA060-PAY-CUSTOM-FIELDS*/
			payCustomFields(payID, payEventID);
			
			wPaymentDetailsRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
			wPaymentDetailsRecord.setBPSortKey(wSortKeyRecord.createRecordString());
			wPaymentDetailsRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());		
			
			/*PERFORM MX010-WRITE-EXTRACT-DATA*/                                                                                                                                                                                                                          
			/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
			 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
			 */  
			// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
			//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

				/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
				//wSortKeyRecord.setCopyNbr(String.valueOf(x));
				wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
			// End Change - DLampa - 2024-09-17 - INC0037039.Issue1				
				wPaymentDetailsRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
				hpFileHelper.appendWriteClose(wPaymentDetailsRecord);						
			// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1
			//}
			// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1			
		}		
	}
	
	private void billMessages() {
		
		// Bill Messages
		wLineSeq = 0;
		Iterator<SQLResultRow> collOfBillMsg = getNextBillMsg(hpBill, wMainPerson.getLanguage());
		while (collOfBillMsg.hasNext()) {
			SQLResultRow sqlRow = (SQLResultRow) collOfBillMsg.next();
			BillMessageType_Id billMsgCd = (BillMessageType_Id) sqlRow.getId("BILL_MSG_CD", BillMessageType.class); 
			@SuppressWarnings("unused")
			String descr = (String) sqlRow.getString("DESCR");
			String msgOnBill = (String) sqlRow.getString("MSG_ON_BILL");
			MessagePriorityLookup msgPriorityFlg = (MessagePriorityLookup) sqlRow.getLookup("MSG_PRIORITY_FLG", MessagePriorityLookup.class);
			String insertCd = (String) sqlRow.getString("INSERT_CD");
			
			wLineSeq++;
			/*SET BILL-MSG-DTL OF BBPXT TO TRUE*/
			wSortKeyRecord.setBillRecordGroupSeq(CmPostRouteBillExtractSortKeyRecord.BILL_MSG_DTL);
			/*SET BP-EXTR-TYPE-DTL-BILLMSG OF BBPXT TO TRUE*/
			wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_BILLMSG);			
			/*MOVE CORR S-BILLMSG-OUT-DATA OF S-BILLMSG TO BP-EXTR-DTL-BILLMSG OF BBPXT*/
			wBillMessageRecord = new CmPostRouteBillExtractDetailsBillMessageRecord();
			wBillMessageRecord.setBillMsgCd(billMsgCd.getTrimmedValue());
			wBillMessageRecord.setMsgOnBill(msgOnBill);
			wBillMessageRecord.setMsgPriorityFlg(msgPriorityFlg.value().trim());
			wBillMessageRecord.setInsertCd(insertCd);
			
			/*PERFORM MA060-EXPAND-BILL-MSG*/
			expandBillMsg(hpBill, msgOnBill, billMsgCd);
			
			wBillMessageRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
			wBillMessageRecord.setBPSortKey(wSortKeyRecord.createRecordString());
			wBillMessageRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());		
			
			/*PERFORM MX010-WRITE-EXTRACT-DATA*/                                                                                                                                                                                                                          
			/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
			 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
			 */   
			// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1			
			//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

				/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
				//wSortKeyRecord.setCopyNbr(String.valueOf(x));
				wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
			// End Change - DLampa - 2024-09-17 - INC0037039.Issue1				
				wBillMessageRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
				hpFileHelper.appendWriteClose(wBillMessageRecord);	
			// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1				
			//}
			// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1			
		}
	}
	
	private void expandBillMsg(Bill bill, String msgOnBill,
			BillMessageType_Id billMessageTypeID) {
		
		/*
		 * Expand the Message on Bill by substituting parameters 
		 */
		BigInteger billMsgParmCnt = BigInteger.ZERO;
		
		//Start Add - JTIOZON - CCB-047
		Date cutDate = null;
		BigDecimal severanceAmount = BigDecimal.ZERO;
		BigDecimal delinquentAmount = BigDecimal.ZERO;
		Date delinquentDate = null;
		String cwrFlag = "";
		//End Add - JTIOZON - CCB-047
		
		try {
			CobolProgramCIPZSMPV routine = CobolProgramCIPZSMPV.Factory.newInstance();
			CobolCopybookCICZSMPV cpyBook = routine.getCobolCopybookCICZSMPV();
			// Set the input of the routine
			/*MOVE MSG-ON-BILL OF S-BILLMSG TO MESSAGE-TEXT OF INPUT-WKR OF ZSMPV*/
			cpyBook.get_INPUT_WRK().set_MESSAGE_TEXT(msgOnBill);
			/*MOVE CORR S-BILLMSG TO S-BMSGPRM-IN-DATA */			
			Iterator<SQLResultRow> collMsgParm = getMsgParms(bill, billMessageTypeID);
			
			while (collMsgParm.hasNext()) { 
				SQLResultRow sqlRow = (SQLResultRow) collMsgParm.next();
				BigInteger seqNbr = (BigInteger) sqlRow.getInteger("SEQ_NUM");
				String msgParmVal = (String) sqlRow.getString("MSG_PARM_VAL");				
				/*MOVE SEQ-NUM Of S-BMSGPRM TO BILL-MSG-PARM-CNT OF W-WRK*/
				billMsgParmCnt = seqNbr;
				/*
				 * MOVE MSG-PARM-VAL OF S-BMSGPRM
				 *      TO EXP-MSG-PARM OF MESSAGE-PARM-COLL
				 *      OF ZSMPV(BILL-MSG-PARM-CNT OF W-WRK)
				 *
				 */
				cpyBook.get_INPUT_WRK().get_MESSAGE_PARM_COLL().newRow().set_EXP_MSG_PARM(msgParmVal);	
				
				//Start Add - JTIOZON - CCB-047
				if((billMessageTypeID.getEntity().equals(parmCWRBillMessageType) || billMessageTypeID.getEntity().equals(parmNonCWRBillMessageType)) && seqNbr.equals(BigInteger.ONE)){
					// Get Delinquent Amount
					delinquentAmount = new BigDecimal(msgParmVal); 					
					wBillMessageRecord.setDelinquentAmount(delinquentAmount, transformImpliedBD(delinquentAmount, 2));
															
				}else if((billMessageTypeID.getEntity().equals(parmCWRBillMessageType) || billMessageTypeID.getEntity().equals(parmNonCWRBillMessageType)) && seqNbr.equals(new BigInteger("2"))){ 
					// Get Delinquent Date
					delinquentDate = Date.fromString(msgParmVal, DATE_FORMAT); 
					wBillMessageRecord.setDelinquentDate(delinquentDate.toString().trim());
				}else if((billMessageTypeID.getEntity().equals(parmCWRBillMessageType) || billMessageTypeID.getEntity().equals(parmNonCWRBillMessageType)) && seqNbr.equals(new BigInteger("3"))){
					cutDate = Date.fromString(msgParmVal, DATE_FORMAT);
					wBillMessageRecord.setCutDate(cutDate.toString());
				}
				else if((billMessageTypeID.getEntity().equals(parmCWRBillMessageType) || billMessageTypeID.getEntity().equals(parmNonCWRBillMessageType)) && seqNbr.equals(new BigInteger("4"))){
					severanceAmount = new BigDecimal(msgParmVal);					
					wBillMessageRecord.setSeveranceAmount(severanceAmount, transformImpliedBD(severanceAmount, 2));
										
				}
				
				// Add CWR Indicator
				if(billMessageTypeID.getEntity().equals(parmCWRBillMessageType)){
					cwrFlag = "Y";
				}else if(billMessageTypeID.getEntity().equals(parmNonCWRBillMessageType)){
					cwrFlag = "N";
				}
				//End Add - JTIOZON - CCB-047
			}
			
			//Start Add - JTIOZON - CCB-047
			wBillMessageRecord.setCWRflag(cwrFlag);
			//End Add - JTIOZON - CCB-047
			
			if (billMsgParmCnt.compareTo(BigInteger.ZERO) > 0) { 
				
				/*MOVE BILL-MSG-PARM-CNT OF W-WRK TO PARM-COUNT OF INPUT-WRK OF ZSMPV*/
				cpyBook.get_INPUT_WRK().set_PARM_COUNT(billMsgParmCnt);
				/*PERFORM PA100-SUB-PARM-VALUES*/
				routine.callCobol();
				/*MOVE EXP-MSG OF OUTPUT-WRK OF ZSMPV TO MSG-ON-BILL OF BP-EXTR-DTL-BILLMSG OF BBPXT*/
				String expMsg = cpyBook.get_OUTPUT_WRK().get_EXP_MSG();
				wBillMessageRecord.setMsgOnBill(expMsg);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			// Error encountered while invoking base routine %1.
			addError(CustomMessageRepositoryMGE.commGenericErrorEncounteredInvokingBaseRoutine("CIPZSMPV"));
		}
	}
	
	private void payCustomFields(Payment_Id payID, PaymentEvent_Id payEventID) {

		Bool hasPledgePayment = checkPledgePayment(payID, parmCharTypePledgePayment);		
		if (hasPledgePayment.isTrue()) {
			
			/*SET SW-YES OF PLG-PAY-FLG OF BP-EXTR-DTL-PAYDTL TO TRUE*/
			wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_PAYDTL);
			wPaymentDetailsRecord.setPledgePayFlg(transformToYorN(Bool.TRUE));
			/*PERFORM XQ0140-GET-PLEDGE-DESCR*/
			String pledgeDescr = getPledgeDescr(payEventID);
			/*MOVE DESCR OF S-PLDDESC TO PLG-TNDR-DESCR OF BP-EXTR-DTL-PAYDL*/
			wPaymentDetailsRecord.setPledgeTenderDescr(pledgeDescr);
		}
		else {
			/*SET SW-NO OF PLG-PAY-FLG OF BP-EXTR-DTL-PAYDTL TO TRUE*/
			wPaymentDetailsRecord.setPledgePayFlg(transformToYorN(Bool.FALSE));
		}		
	}
	
	private void otherCharges() {
		
		Money othBillChgCurAmt = getOtherBillCharges(FinancialTransactionTypeLookup.constants.BILL_SEGMENT,
				FinancialTransactionTypeLookup.constants.BILL_CANCELLATION,
				hpBill, parmServiceTypeForMetered, parmServiceTypeForUnmetered,
				SpecialRoleLookup.constants.PAYMENT_ARRANGEMENT);		
		/*
		 * COMPUTE W-OTHERS-TOT-AMT OF W-WRK
		 *         = W-OTHERS-ADJ-AMT OF W-WRK
		 *         + CUR-AMT OF S-OTHCHG
		 */
		wOthersTotAmt = wOtherAdjCurAmt.add(othBillChgCurAmt);
		
		/*
		 * IF W-OTHERS-TOT-AMT OF W-WRK <> 0
		 *     PERFORM NA050-WRITE-OTHER-CHARGES
		 * END-IF
		 */
		if (wOthersTotAmt.getAmount().compareTo(BigDecimal.ZERO) != 0) {
			writeOtherCharges();			
		}		
	}
	
	private void writeOtherCharges() {
		
		wOtherChargesRecord = new CmPostRouteBillExtractDetailsOtherChargesRecord();
		/*SET BP-EXTR-TYPE-DTL-OTHCHG OF BBPXT TO TRUE*/
		wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_OTHCHG);
		/*SET OTHER-CHG-DTL OF BBPXT TO TRUE*/
		wSortKeyRecord.setBillRecordGroupSeq(CmPostRouteBillExtractSortKeyRecord.OTHER_CHG_DTL);
		/*MOVE W-OTHERS-HEADER OF W-WRK TO OTH-CHG-BILL-DESCR Of BP-EXTR-DTL-OTHCHG OF BBPXT*/
		wOtherChargesRecord.setOthChgBillDescr(getLookupValueDescr(parmLookupFieldBillPrintHeaderDescr, parmLookupValueOtherChargesHeader));
		/*MOVE W-OTHERS-TOT-AMT OF W-WRK TO TOT-OTH-AMT OF BP-EXTR-DTL-OTHCHG OF BBPXT*/
		wOtherChargesRecord.setTotOthAmt(wOthersTotAmt.getAmount(), transformImpliedBD(wOthersTotAmt.getAmount(), 2));
		
		wOtherChargesRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
		wOtherChargesRecord.setBPSortKey(wSortKeyRecord.createRecordString());
		wOtherChargesRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());		
		
		/*PERFORM MX010-WRITE-EXTRACT-DATA*/                                                                                                                                                                                                                          
		/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
		 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
		 */       
		// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
		//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

			/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
			//wSortKeyRecord.setCopyNbr(String.valueOf(x));
			wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
		// End Change - DLampa - 2024-09-17 - INC0037039.Issue1			
			wOtherChargesRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
			hpFileHelper.appendWriteClose(wOtherChargesRecord);	
		// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1			
		//}
		// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1		
	}
	
	private void writeCorrectionBseg() {
		
		wCorrectionChargesRecord = new CmPostRouteBillExtractDetailsCorrectionChargesRecord();
		/*SET BP-EXTR-TYPE-DTL-CANCHG OF BBPXT TO TRUE*/
		wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_CANCHG);
		/*SET CANCEL-CHG-DTL OF BBPXT TO TRUE*/
		wSortKeyRecord.setBillRecordGroupSeq(CmPostRouteBillExtractSortKeyRecord.CANCEL_CHG_DTL);
		/*MOVE W-CANCHG-HEADER OF W-WRK TO BL-COR-BILL-DESCR OF BP-EXTR-DTL-CORRCHG OF BBPXT*/
		wCorrectionChargesRecord.setBillCorrectionBillDescr(getLookupValueDescr(parmLookupFieldBillPrintHeaderDescr, parmLookupValueBillCorrectionPeriodHeader));
		/*MOVE W-CORR-START-DT OF W-WRK TO START-DT OF BP-EXTR-DTL-CORRCHG OF BBPXT*/
		wCorrectionChargesRecord.setStartDt(wCorrStartDt.toString().trim());
		/*MOVE W-CORR-END-DT OF W-WRK TO END-DT OF BP-EXTR-DTL-CORRCHG OF BBPXT*/
		wCorrectionChargesRecord.setEndDt(wCorrEndDt.toString().trim());
		/*MOVE W-CORR-CAN-AMT OF W-WRK TO CAN-BILL-AMT OF BP-EXTR-DTL-CORRCHG OF BBPXT*/
		wCorrectionChargesRecord.setCancelBillAmt(wCorrCanAmt.getAmount(), transformImpliedBD(wCorrCanAmt.getAmount(), 2));
		/*MOVE W-CORR-BILL-AMT OF W-WRK TO REBILL-BILL-AMT OF BP-EXTR-DTL-CORRCHG OF BBPXT*/
		wCorrectionChargesRecord.setRebillBillAmt(wCorrBillAmt.getAmount(), transformImpliedBD(wCorrBillAmt.getAmount(), 2));
		/*MOVE W-CORR-TOT-AMT OF W-WRK TO HEAD-TOT-AMD OF BP-EXTR-DTL-CORRCHG OF BBPXT*/
		wCorrectionChargesRecord.setHeadTotAmt(wCorrTotAmt.getAmount(), transformImpliedBD(wCorrTotAmt.getAmount(), 2));
		
		wCorrectionChargesRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
		wCorrectionChargesRecord.setBPSortKey(wSortKeyRecord.createRecordString());
		wCorrectionChargesRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());		
		
		/*PERFORM MX010-WRITE-EXTRACT-DATA*/
		/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
		 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
		 */         
		// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
		//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

			/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
			//wSortKeyRecord.setCopyNbr(String.valueOf(x));
			wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
		// End Change - DLampa - 2024-09-17 - INC0037039.Issue1			
			wCorrectionChargesRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
			hpFileHelper.appendWriteClose(wCorrectionChargesRecord);
		// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1			
		//}
		// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1		
	}
	
	private void writePaCharges(ServiceAgreement_Id saID,
			String saTypeStr, String descrOnBill, 
			BigDecimal calcAmt) {
		
		wPAChargesRecord = new CmPostRouteBillExtractDetailsPAChargesRecord();
		/*SET BP-EXTR-TYPE-PA-RECORD OF BBPXT TO TRUE*/
		wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_PA_RECORD);
		/*SET PA-REC-DTL OF BBPXT TO TRUE*/
		wSortKeyRecord.setBillRecordGroupSeq(CmPostRouteBillExtractSortKeyRecord.PA_REC_DTL);
		/*MOVE SA-ID OF S-PACHRGS TO SA-ID OF BP-EXTR-DTL-PA-CHG OF BBPXT*/
		wPAChargesRecord.setSAID(saID.getTrimmedValue());
		/*MOVE SA-TYPE-CD OF S-PACHRGS TO SA-TYPE-CD OF BP-EXTR-DTL-PA-CHG OF BBPXT*/
		wPAChargesRecord.setSaType(saTypeStr);
		/*MOVE DESCR-ON-BILL OF S-PACHRGS TO DESCR-ON-BILL OF BP-EXTR-DTL-PA-CHG OF BBPXT*/
		wPAChargesRecord.setDescrOnBill(descrOnBill);
		/*MOVE CALC-AMT OF S-PACHRGS TO CALC-AMT OF BP-EXTR-DTL-PA-CHG OF BBPXT*/
		wPAChargesRecord.setCalcAmt(calcAmt, transformImpliedBD(calcAmt, 2));
		
		wPAChargesRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
		wPAChargesRecord.setBPSortKey(wSortKeyRecord.createRecordString());
		wPAChargesRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
		
		/*PERFORM MX010-WRITE-EXTRACT-DATA*/
		/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
		 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
		 */         
		// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
		//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

			/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
			//wSortKeyRecord.setCopyNbr(String.valueOf(x));
			wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
		// End Change - DLampa - 2024-09-17 - INC0037039.Issue1			
			wPAChargesRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
			hpFileHelper.appendWriteClose(wPAChargesRecord);		
		// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1			
		//}		
		// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1		
	}
	
	private void writeCurrentChargesDebtClass(DebtClass_Id debtClassCd, String descr, 
			Currency_Id currencyID, BigDecimal sumCurAmt, BigDecimal sumTotAmt) {
		
		wCurrChargesDebtClassRecord = new CmPostRouteBillExtractDetailsCurrentChargeDebtClassRecord();
		/*SET BP-EXTR-TYPE-DTL-CURRDC OF BBPXT TO TRUE*/
		wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_CURRDC);
		/*MOVE DEBT-CL-CD Of S-CURRDC TO DEBT-CL-CD OF BP-EXTR-DTL-CURRDC*/
		wCurrChargesDebtClassRecord.setDebtClass(debtClassCd.getTrimmedValue());
		/*MOVE DESCR OF S-CURRDC TO DEBT-CLASS-DESCR OF BP-EXTR-DTL-CURRDC*/
		wCurrChargesDebtClassRecord.setDebtClassDescr(descr);
		/*MOVE CUR-AMT OF S-CURRDC TO CUR-CHARGE-AMT OF BP-EXTR-DTL-CURRDC*/
		wCurrChargesDebtClassRecord.setCurAmt(sumCurAmt, transformImpliedBD(sumCurAmt, 2));
		/*MOVE TOT-AMT OF S-CURRDC TO TOT-CHARGE-AMT OF BP-EXTR-DTL-CURRDC*/
		wCurrChargesDebtClassRecord.setTotAmt(sumTotAmt, transformImpliedBD(sumTotAmt, 2));
		
		wCurrChargesDebtClassRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
		wCurrChargesDebtClassRecord.setBPSortKey(wSortKeyRecord.createRecordString());
		wCurrChargesDebtClassRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
		
		/*PERFORM MX010-WRITE-EXTRACT-DATA*/
		/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
		 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
		 */  
		// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1
		//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

			/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
			//wSortKeyRecord.setCopyNbr(String.valueOf(x));
			wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
		// End Change - DLampa - 2024-09-17 - INC0037039.Issue1			
			wCurrChargesDebtClassRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
			hpFileHelper.appendWriteClose(wCurrChargesDebtClassRecord);
		// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1			
		//}
		// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1		
	}
	
	
//	private void writeExtractData(ColumnDelimitedRecord recordToWrite) {
//		
//		// Add the extract record to file.
//		
//		/*PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
//		 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
//		 */         
//		for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {
//
//			/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-LKLEY*/
//			wSortKeyRecord.setCopyNbr(String.valueOf(x));
//			
//			/*
//			 * IF BP-EXTR-TYPE-BILL OF PRINTER-KEY OF BBPXT
//			 *     MOVE COPY-NBR OF W-WRK TO COPY-NBR OF BP-EXTR-BILL
//			 * END-IF
//			 */
//			if (wPrinterKeyRecord.createRecordString().trim()
//					.compareTo(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_BILL) == 0) {
//				wBillDetailRecord.setCopyNbr(String.valueOf(x));
//			}			
//			
//			hpFileHelper.appendWriteClose(recordToWrite);						
//		}
//	}
	
	private void na020CorrectionBseg() {
		
		// Initialize variables
		wCorrStartDt = null;
		wCorrEndDt = null;
		wCorrCanAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wCorrBillAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wCorrTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		Iterator<SQLResultRow> collCorrBseg = getCorrectionBseg(FinancialTransactionTypeLookup.constants.BILL_SEGMENT,
				FinancialTransactionTypeLookup.constants.BILL_CANCELLATION,
				hpBill);
		
		while (collCorrBseg.hasNext()) {
			
			SQLResultRow sqlRow = (SQLResultRow) collCorrBseg.next();
			Date corrStartDt = (Date) sqlRow.getDate("START_DT");
			Date corrEndDt = (Date) sqlRow.getDate("END_DT");
			FinancialTransactionTypeLookup ftTypeFlg = 
					(FinancialTransactionTypeLookup) sqlRow.getLookup("FT_TYPE_FLG", FinancialTransactionTypeLookup.class);
			BigDecimal curAmt = (BigDecimal) sqlRow.getBigDecimal("CUR_AMT");
			BigDecimal totAmt = (BigDecimal) sqlRow.getBigDecimal("TOT_AMT");
			ServiceAgreement_Id saID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
			CisDivision_Id cisDivID = (CisDivision_Id) sqlRow.getId("CIS_DIVISION", CisDivision.class);
			String saTypeStr = (String) sqlRow.getString("SA_TYPE_CD");
			Bool eligBudgetSw = sqlRow.getBoolean("ELIG_BUDGET_SW");
			curAmt = curAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			totAmt = totAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			//curAmt = curAmt.setScale(2, BigDecimal.ROUND_HALF_EVEN);
			//totAmt = totAmt.setScale(2, BigDecimal.ROUND_HALF_EVEN);
			
			if (isNull(wCorrStartDt)) {
				wCorrStartDt = corrStartDt;
			}
			else {
				if (corrStartDt.compareTo(wCorrStartDt) < 0) {
					wCorrStartDt = corrStartDt;
				}
			}
			
			if (isNull(wCorrEndDt)) {
				wCorrEndDt = corrEndDt;
			}
			else {
				if (corrEndDt.compareTo(wCorrEndDt) > 0) {
					wCorrEndDt = corrEndDt;
				}				
			}
			
			// Use Payoff Amount if SA is a budget SA.
			// Start Change - DLampa - 2024-07-30 - INC0037039
			//Bool budgetSw = Bool.FALSE;
			budgetSw = Bool.FALSE;
			// End Change - DLampa - 2024-07-30 - INC0037039
			
			if (eligBudgetSw.isTrue()) {
				budgetSw = Bool.TRUE;
			}
			else {
				// Check if SA Type has budget characteristic
				String budgetCharVal = getSaTypeChar(cisDivID, saTypeStr, parmCharTypeBudgetPaymentArrangement);
				if (notBlank(budgetCharVal)) {
					budgetSw = Bool.TRUE;
				}
			}
			
			if (budgetSw.isTrue()) {
				
				Bool hasRecChge = getRecurringCharge(saID, wCorrEndDt);
				/*
				 * IF X OF S-RCHGCHK-OUT-DATA = SPACES
                 *     SET SW-NO OF W-BUDGET-SW OF W-WRK
                 *             TO TRUE
                 * END-IF
				 */
				if (hasRecChge.isTrue()) {
					budgetSw = Bool.TRUE;
				}
				else {
					budgetSw = Bool.FALSE;
				}				
			}
			
			if (ftTypeFlg.isBillSegment()) {
				if (budgetSw.isFalse()) {
					/*
					 * COMPUTE W-CORR-BILL-AMT = W-CORR-BILL-AMT 
					 *         + CUR-AMT OF S-CORRBS
					 */
					wCorrBillAmt = wCorrBillAmt.add(new Money(curAmt, wAccountCurrencyID));
				}
				else {
					/*
					 * COMPUTE W-CORR-BILL-AMT = W-CORR-BILL-AMT
					 *         + TOT-AMT OF S-CORRBS
					 */
					wCorrBillAmt = wCorrBillAmt.add(new Money(totAmt, wAccountCurrencyID));
				}				
			}
			
			if (ftTypeFlg.isBillCancellation()) {
				if (budgetSw.isFalse()) {
					/*
					 * COMPUTE W-CORR-CAN-AMT = W-CORR-CAN-AMT
					 *         + CUR-AMT OF S-CORRBS
					 */
					wCorrCanAmt = wCorrCanAmt.add(new Money(curAmt, wAccountCurrencyID));
				}
				else {
					/*
					 * COMPUTE W-CORR-CAN-AMT = W-CORR-CAN-AMT
					 *         + TOT-AMT OF S-CORRBS
					 */
					wCorrCanAmt = wCorrCanAmt.add(new Money(totAmt, wAccountCurrencyID));
				}
			}
		}
		
		if (notNull(wCorrStartDt)) {
			/*
			 * COMPUTE W-CORR-TOT-AMT OF W-WRK
			 *         = W-CORR-BILL-AMT OF W-WRK
			 *         + W-CORR-CAN-AMT OF W-WRK
			 */
			wCorrTotAmt = wCorrBillAmt.add(wCorrCanAmt);			
		}		
	}
	
	private String getLookupValueDescr(LookupField lookupField, String fieldValue) {
		String returnValue = " ";
		LookupValue_Id lookupValueID = new LookupValue_Id(lookupField, fieldValue);
		if (notNull(lookupValueID.getEntity())) {
			returnValue = lookupValueID.getEntity().fetchLanguageDescription().trim();
		}
		return returnValue;
	}
	private String transformToYorN(Bool value) {
		String returnValue = " ";
		if (value.isTrue()) {
			returnValue = "Y";
		}
		else {
			returnValue = "N";
		}
		return returnValue;
	}
	
	private String getAcctChar(Account acct, CharacteristicType charType, Date effDt) {
		
		String returnValue = " ";
		AccountCharacteristic acctChar = acct.getEffectiveCharacteristicAsOfDate(charType, effDt);
		if (notNull(acctChar)) {
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			if (charTypeLookup.isAdhocValue()
					|| charTypeLookup.isFileLocationValue()) {
				returnValue = acctChar.getAdhocCharacteristicValue();
			}
			else if (charTypeLookup.isForeignKeyValue()) {
				returnValue = acctChar.getCharacteristicValueForeignKey1();
			}
			else {
				returnValue = acctChar.getCharacteristicValue();
			}
		}
		return returnValue;
	}
	
	private void saDetails(ServiceAgreement_Id saID) {
		
		/*PERFORM SQ200-GET-SA*/
		getSa(saID);
		
		if (wNonPremSw.isFalse()) {
			/*SET PREM-REC-SA OF BILL-PRINT-SORT-KEY TO TRUE*/
			wSortKeyRecord.setPremRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.PREM_REC_SA);
			/*MOVE BILL-PRT-PRIO-FLG OF S-SA TO SA-PRIORITY-FLG OF BILL-PRINT-SORT-KEY*/
			wSortKeyRecord.setSaPriorityFlg(wS_SA_OUT_DATA_billPrtPrioFlg.value().trim());
			/*MOVE SA-ID OF S-SA TO SA-ID OF BILL-PRINT-SORT-KEY*/
			wSortKeyRecord.setSaID(wS_SA_OUT_DATA_SaID.getTrimmedValue());
			/*SET SA-REC-SA-DTL OF SA-REC-GRP-SEQ OF BILL-PRINT-SORT-KEY TO TRUE*/
			wSortKeyRecord.setSaRecGrpSeq(CmPostRouteBillExtractSortKeyRecord.SA_REC_SA_DTL);
		}
		else {
			/*MOVE BILL-PRT-PRIO-FLG OF S-SA TO NP-SA-PRIORITY-FLG OF BILL-PRINT-SORT-KEY*/
			wSortKeyRecord.NP_SA_PRIORITY_FLG = wS_SA_OUT_DATA_billPrtPrioFlg.value().trim();
			/*MOVE SA-ID OF S-SA TO NP-SA-ID OT BILL-PRINT-SORKT-KEY*/
			wSortKeyRecord.NP_SA_ID = wS_SA_OUT_DATA_SaID.getTrimmedValue();
			/*SET SA-REC-SA-DTL OF NP-SA-REC-GRP-SEQ OF BILL-PRINT-SORT-KEY TO TRUE*/
			wSortKeyRecord.NP_SA_REC_GRP_SEQ = CmPostRouteBillExtractSortKeyRecord.SA_REC_SA_DTL;			
			
			////
			wSortKeyRecord.setNonPremSaSeq();
			/////
		}
		
		/*SET SW-YES Of WITH-SA-SW TO TRUE*/
		wWithSaSw = Bool.TRUE;
		
		if (isNull(wS_SA_OUT_DATA_saRelID)
				|| isNull(wS_SA_OUT_DATA_saRelID.getEntity())) {
			// INITIALIZE S-SAREL-OUT-DATA
			wSAREL_OUT_DATA_saRelID = null;
			wSAREL_OUT_DATA_sarSaID = null;
			wSAREL_OUT_DATA_saRelTypeID = null;
			wSAREL_OUT_DATA_saExtRefID = " ";
			wSAREL_OUT_DATA_saRelStatusFlg = null;
			wSAREL_OUT_DATA_sprCd = null;
			wSAREL_OUT_DATA_descr = " ";
			wSAREL_OUT_DATA_descr50 = " ";
			wSAREL_OUT_DATA_sprSaID = null;
			wSAREL_OUT_DATA_ntXidCd = null;
			wSAREL_OUT_DATA_billRelFlg = null;
			wSAREL_OUT_DATA_perID = null;
			wSAREL_OUT_DATA_entityName = " ";
		}
		else {
			getSARel(wS_SA_OUT_DATA_saRelID);
		}
		
		/*Initialize BP-EXTR-DTL-SA OF BBPXT*/
		wSaDetailRecord = new CmPostRouteBillExtractDetailsSADetailsRecord();
		/*SET BP-EXTR-TYPE-DTL-SA OF BBPXT TO TRUE*/
		wPrinterKeyRecord.setPrinterKey(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_DTL_SA);
		/*MOVE CORR S-SAREL TO BP-EXDTR-DTL-SA OF BBPXT*/
		if (notNull(wSAREL_OUT_DATA_saRelID)) {
			wSaDetailRecord.setSaRelID(wSAREL_OUT_DATA_saRelID.getTrimmedValue());
		}
		if (notNull(wSAREL_OUT_DATA_saRelTypeID)) {
			wSaDetailRecord.setSaRelTypeCd(wSAREL_OUT_DATA_saRelTypeID.getTrimmedValue());
		}
		if (notNull(wSAREL_OUT_DATA_sprCd)) {
			wSaDetailRecord.setSprCd(wSAREL_OUT_DATA_sprCd.getTrimmedValue());
		}		
		/*MOVE DESCR OF S-SAREL TO SA-REL-TYPE-DESCR OF BP-EXTR-DTL-SA OF BBPXT*/
		wSaDetailRecord.setSaRelTypeDescr(wSAREL_OUT_DATA_descr);
		/*MOVE DESCR50 OF S-SAREL TO SPR-DESCR OF BP-EXTR-DTL-SA OF BBPXT*/
		wSaDetailRecord.setSprDescr(wSAREL_OUT_DATA_descr50);	
		/*MOVE ENTITY-NAME OF S-SAREL TO SPR-ENTITY-NAME OF BP-EXTR-DTL-SA OF BBPXT*/
		wSaDetailRecord.setSprEntityName(wSAREL_OUT_DATA_entityName);
		
		/*MOVE CORR S-SA-OUT-DATA TO BP-EXTR-DTL-SA OF BBPXT*/		
		wSaDetailRecord.setSAID(wS_SA_OUT_DATA_SaID.getTrimmedValue());
		wSaDetailRecord.setCisDivision(wS_SA_OUT_DATA_CisDivID.getTrimmedValue());
		wSaDetailRecord.setSaTypeCd(wS_SA_OUT_DATA_SATypeCd);
		wSaDetailRecord.setCustReadFlg(wS_SA_OUT_DATA_custReadFlg.value().trim());
		if (notNull(wS_SA_OUT_DATA_charPremID)) {
			wSaDetailRecord.setCharPremID(wS_SA_OUT_DATA_charPremID.getTrimmedValue());
		}			
		wSaDetailRecord.setRevClCd(wS_SA_OUT_DATA_revClCd.getTrimmedValue());
		wSaDetailRecord.setSvcTypeCd(wS_SA_OUT_DATA_svcTypeCd.getTrimmedValue());
		wSaDetailRecord.setOldAcctID(wS_SA_OUT_DATA_oldAcctID);			
		/*MOVE DESCR-STL OF S-SA TO SA-TYPE-DESCR OF BP-EXTR-DTL-SA OF BBPXT*/
		wSaDetailRecord.setSaTypeDescr(wS_SA_OUT_DATA_descr);
		/*MOVE DFLT-DESCR-ON-BILL OF S-SA TO SA-TYPE-DFLT-DESCR OF BP-EXTR-DTL-SA OF BBPXT*/
		wSaDetailRecord.setSaTypeDfltDescr(wS_SA_OUT_DATA_dfltDescrOnBill);
		/*MOVE DESCR-SVL OF S-SA TO SVC-TYPE-DESCR OF BP-EXTR-DTL-SA OF BBPXT*/
		wSaDetailRecord.setSvcTypeDescr(wS_SA_OUT_DATA_svcTypeDescr);
		
		if (notNull(wS_SA_OUT_DATA_sicCodeID)
				|| notNull(wS_SA_OUT_DATA_sicCodeID.getEntity())) {
			
			wSaDetailRecord.setSicCd(wS_SA_OUT_DATA_sicCodeID.getTrimmedValue());
			wSaDetailRecord.setSicDescr(wS_SA_OUT_DATA_sicCodeID.getEntity().fetchLanguageDescription().trim());
		}
		
		/*PERFORM NA070-SA-CUSTOM-FIELDS*/		
		saCustomFields();
		
		wSaDetailRecord.setBPPrinterKey(wPrinterKeyRecord.createRecordString());
		wSaDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());
		wSaDetailRecord.setBPMailingKey(wMailingKeyRecord.createRecordString());
		
		/*PERFORM MX010-WRITE-EXTRACT-DATA*/
		/* PERFORM VARYING COPY-NBR OF W-WRK FROM 1 BY 1
		 *        UNTIL COPY-NBR OF W-WRK > COPY-CNT OF BXZZX       
		 */     
		// Start Change - DLampa - 2024-09-17 - INC0037039.Issue1		
		//for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {

			/*MOVE COPY-NBR-TEMP OF W-WRK TO COPY-NBR OF BILL-PRINT-SORT-KEY*/
			//wSortKeyRecord.setCopyNbr(String.valueOf(x));
			wSortKeyRecord.setCopyNbr(hpNumberOfCopiesIdx);
		// End Change - DLampa - 2024-09-17 - INC0037039.Issue1
			wSaDetailRecord.setBPSortKey(wSortKeyRecord.createRecordString());					
			hpFileHelper.appendWriteClose(wSaDetailRecord);
		// Start Delete - DLampa - 2024-09-17 - INC0037039.Issue1			
		//}
		// End Delete - DLampa - 2024-09-17 - INC0037039.Issue1		
	}
	
	private void saCustomFields() {
		
		/*MOVE DESCR-REVCLL OF S-SA TO REV-CL-DESCR OF BP-EXTR-DTL-SA OF BBPXT*/
		wSaDetailRecord.setRevClDescr(wS_SA_OUT_DATA_revClDescr);
		ServiceAgreementCharacteristic saChar = wS_SA_OUT_DATA_SaID.getEntity().
				getEffectiveCharacteristicAsOfDate(parmCharTypeContractNumberSA, wBillDt);
		CharacteristicTypeLookup charTypeLookup = parmCharTypeContractNumberSA.getCharacteristicType();
		String contractNbrCharVal = " ";
		if (notNull(saChar)) {
			if (charTypeLookup.isAdhocValue()
					|| charTypeLookup.isFileLocationValue()) {
				contractNbrCharVal = saChar.getAdhocCharacteristicValue();
			}
			else if (charTypeLookup.isForeignKeyValue()) {
				contractNbrCharVal = saChar.getCharacteristicValueForeignKey1();
			}
			else {
				contractNbrCharVal = saChar.getCharacteristicValue();
			}
		}		
		/*MOVE W-CONTRACT-NBR-VALUE OF W-WRK TO CONTRACT-NUM OF BP-EXTR-DTL-SA OF BBPXT*/
		wSaDetailRecord.setContractNum(contractNbrCharVal);
	}
	
	/*
	 * SQL Methods
	 */
	private void getBillBalance(Bill bill) {
		
		// Initialize Output
		wBillBalCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBillBalTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT ");
		stringBuilder.append("    CURRENCY_CD, ");
		stringBuilder.append("    NVL(SUM(CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("    NVL(SUM(TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_BILL_SA ");
		stringBuilder.append("WHERE BILL_ID = :billID ");
		stringBuilder.append("GROUP BY CURRENCY_CD ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getBillBalance=");
		prepState.bindId("billID", bill.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			Currency_Id currencyID = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			BigDecimal sumTotAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_TOT_AMT");
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			//sumTotAmt = sumTotAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			wBillBalCurAmt = new Money(sumCurAmt, currencyID);
			wBillBalTotAmt = new Money(sumTotAmt, currencyID);
		}
		prepState.close();		
	}
	
	private void getBillCurrentCharge(Bill bill) {
		
		// Initialize Output
		wBillChargeCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBillChargeTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    CURRENCY_CD, ");
		stringBuilder.append("    NVL(SUM(CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("    NVL(SUM(TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM "); 
		stringBuilder.append("    CI_FT ");
		stringBuilder.append("WHERE BILL_ID = :billID ");
		stringBuilder.append("AND FT_TYPE_FLG IN ('BS', 'BX') ");
		stringBuilder.append("AND CORRECTION_SW = 'N' ");
		stringBuilder.append("AND SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("GROUP BY CURRENCY_CD ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getBillCurrentCharge=");
		prepState.bindId("billID", bill.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			Currency_Id currencyID = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			BigDecimal sumTotAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_TOT_AMT");
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			//sumTotAmt = sumTotAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			wBillChargeCurAmt = new Money(sumCurAmt, currencyID);
			wBillChargeTotAmt = new Money(sumTotAmt, currencyID);	
		}		
		prepState.close();
	}
	
	private void getBillCorrectionCharge(Bill bill) {
		
		// Initialize Output
		wBillCorrCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBillCorrTotAmt =new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    CURRENCY_CD, ");
		stringBuilder.append("    NVL(SUM(CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("    NVL(SUM(TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM "); 
		stringBuilder.append("    CI_FT ");
		stringBuilder.append("WHERE BILL_ID = :billID ");
		stringBuilder.append("AND FT_TYPE_FLG IN ('BS', 'BX') ");
		stringBuilder.append("AND CORRECTION_SW = 'Y' ");
		stringBuilder.append("AND SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("GROUP BY CURRENCY_CD ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getBillCorrectionCharge=");
		prepState.bindId("billID", bill.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			Currency_Id currencyID = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			BigDecimal sumTotAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_TOT_AMT");
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			//sumTotAmt = sumTotAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			wBillCorrCurAmt = new Money(sumCurAmt, currencyID);
			wBillCorrTotAmt = new Money(sumTotAmt, currencyID);	
		}		
		prepState.close();		
	}
	
	private void getBillAdjustment(Bill bill) {
		
		// Initialize Output
		wBillAdjCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBillAdjTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    CURRENCY_CD, ");
		stringBuilder.append("    NVL(SUM(CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("    NVL(SUM(TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_FT ");
		stringBuilder.append("WHERE BILL_ID = :billID ");
		stringBuilder.append("AND FT_TYPE_FLG IN ('AD', 'AX') ");
		stringBuilder.append("AND SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("GROUP BY CURRENCY_CD ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getBillAdjustment=");
		prepState.bindId("billID", bill.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			Currency_Id currencyID = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			BigDecimal sumTotAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_TOT_AMT");
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			//sumTotAmt = sumTotAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			wBillAdjCurAmt = new Money(sumCurAmt, currencyID);
			wBillAdjTotAmt = new Money(sumTotAmt, currencyID);
		}
		prepState.close();		
	}

	private void getBillPayment(Bill bill) {
		
		// Initialize Output
		wBillPayCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBillPayTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    CURRENCY_CD, ");
		stringBuilder.append("    NVL(SUM(CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("    NVL(SUM(TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_FT ");
		stringBuilder.append("WHERE BILL_ID = :billID ");
		stringBuilder.append("AND FT_TYPE_FLG IN ('PS', 'PX') ");
		stringBuilder.append("AND SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("GROUP BY CURRENCY_CD ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getBillPayment=");
		prepState.bindId("billID", bill.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			Currency_Id currencyID = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			BigDecimal sumTotAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_TOT_AMT");
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			//sumTotAmt = sumTotAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			wBillPayCurAmt = new Money(sumCurAmt, currencyID);
			wBillPayTotAmt = new Money(sumTotAmt, currencyID);
		}
		prepState.close();		
	}
	
	private void getBillAutopayDetails(Bill bill) {
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    ST.SCHED_EXTRACT_DT, ");
		stringBuilder.append("    AP.START_DT, ");
		stringBuilder.append("    AP.END_DT, ");
		stringBuilder.append("    AP.EXPIRE_DT, ");
		stringBuilder.append("    AP.EXT_ACCT_ID ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_APAY_CLR_STG ST, ");
		stringBuilder.append("    CI_ACCT_APAY AP ");
		stringBuilder.append("WHERE ST.BILL_ID = :billID ");
		stringBuilder.append("AND ST.ACCT_APAY_ID = AP.ACCT_APAY_ID ");
		stringBuilder.append("UNION SELECT ");
		stringBuilder.append("          BILL.APAY_CRE_DT, ");
		stringBuilder.append("          AP.START_DT, ");
		stringBuilder.append("          AP.END_DT, ");
		stringBuilder.append("          AP.EXPIRE_DT, ");
		stringBuilder.append("          AP.EXT_ACCT_ID ");
		stringBuilder.append("      FROM ");
		stringBuilder.append("          CI_BILL BILL, ");
		stringBuilder.append("          CI_ACCT_APAY AP ");
		stringBuilder.append("      WHERE BILL.BILL_ID = :billID ");
		stringBuilder.append("      AND BILL.APAY_CRE_DT IS NOT NULL ");
		stringBuilder.append("      AND BILL.ACCT_ID = AP.ACCT_ID ");
		stringBuilder.append("      AND AP.START_DT <= BILL.DUE_DT ");
		stringBuilder.append("      AND (AP.END_DT >= BILL.DUE_DT ");
		stringBuilder.append("           OR AP.END_DT IS NULL) ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getBillAutopayDetails=");
		prepState.bindId("billID", bill.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			wBillApaySchedExtractDt = (Date) sqlRow.getDate("SCHED_EXTRACT_DT"); 
		}
		prepState.close();
	}
	
	private int getACTSTRT(Account acct) {
		
		int returnValue = 0;
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT "); 
		stringBuilder.append("    COUNT(*) NBR_OF_REC ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_SA SA, ");
		stringBuilder.append("    CI_SA_TYPE SAT ");
		stringBuilder.append("WHERE SA.ACCT_ID = :acctID ");
		stringBuilder.append("AND SA.SA_STATUS_FLG IN ('10', '20') ");
		stringBuilder.append("AND SAT.CIS_DIVISION = SA.CIS_DIVISION ");
		stringBuilder.append("AND SAT.SA_TYPE_CD = SA.SA_TYPE_CD ");
		stringBuilder.append("AND SAT.ALLOW_BILLING_SW = 'Y' ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getACTSTRT=");
		prepState.bindId("acctID", acct.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			BigInteger resultCnt = (BigInteger) sqlRow.getInteger("NBR_OF_REC");
			returnValue = resultCnt.intValue();
		}
		prepState.close();				
		return returnValue;
	}
	
	private int getNoClobs(Account acct) {
		
		int returnValue = 0;
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    COUNT(*) NBR_OF_REC ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_SA SA, ");
		stringBuilder.append("    CI_SA_TYPE SAT ");
		stringBuilder.append("WHERE SA.ACCT_ID = :acctID ");
		stringBuilder.append("AND SA.SA_STATUS_FLG NOT IN ('60', '70') ");
		stringBuilder.append("AND SAT.CIS_DIVISION = SA.CIS_DIVISION ");
		stringBuilder.append("AND SAT.SA_TYPE_CD = SA.SA_TYPE_CD ");
		stringBuilder.append("AND SAT.ALLOW_BILLING_SW = 'Y' ");
		stringBuilder.append("AND NOT EXISTS ( ");
		stringBuilder.append("                SELECT BS.SA_ID ");
		stringBuilder.append("                FROM CI_BSEG BS ");
		stringBuilder.append("                WHERE BS.SA_ID = SA.SA_ID ");
		stringBuilder.append("                AND BS.BSEG_STAT_FLG = '50' ");
		stringBuilder.append("                AND BS.CLOSING_BSEG_SW = 'Y' ");
		stringBuilder.append("                ) ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getNoClobs=");
		prepState.bindId("acctID", acct.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			BigInteger cntRec = (BigInteger) sqlRow.getInteger("NBR_OF_REC");
			returnValue = cntRec.intValue();
		}
		prepState.close();
		return returnValue;
	}
	
	private void getCiInstallationValues() {
		
		// Initialize Output
		wInstallMinimumBillPrtAmt = new Money(BigDecimal.ZERO, wInstallCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT CURRENCY_CD, MIN_BILL_PRT_AMT ");
		stringBuilder.append("FROM CI_INSTALLATION ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getInstallation=");
		prepState.execute();
		prepState.setAutoclose(false);
		SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
		wInstallCurrencyID = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
		BigDecimal minBillPrtAmt = (BigDecimal) sqlRow.getBigDecimal("MIN_BILL_PRT_AMT");
		//minBillPrtAmt = minBillPrtAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
		wInstallMinimumBillPrtAmt = new Money(minBillPrtAmt, wInstallCurrencyID);
		prepState.close();
	}
	
	private Money getTotCrAdj(Bill bill) {
		
		Money returnValue = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    NVL(SUM(FT.CUR_AMT), 0) SUM_CUR_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_FT FT ");
		stringBuilder.append("WHERE FT.FT_TYPE_FLG IN ('AD', 'AX') ");
		stringBuilder.append("AND FT.BILL_ID = :billID ");
		stringBuilder.append("AND FT.FREEZE_SW = 'Y' ");
		stringBuilder.append("AND FT.REDUNDANT_SW = 'N' ");
		stringBuilder.append("AND FT.SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("AND FT.CUR_AMT < 0 ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getTotCrAdj=");
		prepState.bindId("billID", bill.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			if (notNull(sumCurAmt)) {
				//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
				returnValue = new Money(sumCurAmt, wAccountCurrencyID);
			}
		}
		prepState.close();
		return returnValue;
	}
	
	private void getTotPlgPay(Bill bill, CharacteristicType charType) {		
		
		// Initialize output
		wCurrPldgPayAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wTotPldgPayAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT "); 
		stringBuilder.append("    NVL(SUM(FT.CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("    NVL(SUM(FT.TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM "); 
		stringBuilder.append("    CI_FT FT ");
		stringBuilder.append("WHERE FT.BILL_ID = :billID ");
		stringBuilder.append("AND FT.FT_TYPE_FLG IN ('PS', 'PX') ");
		stringBuilder.append("AND FT.FREEZE_SW = 'Y' ");
		stringBuilder.append("AND FT.REDUNDANT_SW = 'N' ");
		stringBuilder.append("AND FT.SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("AND EXISTS (SELECT 'X' ");
		stringBuilder.append("		    FROM CI_PAY_CHAR PAYCHAR ");
		stringBuilder.append("		    WHERE PAYCHAR.PAY_ID = FT.PARENT_ID ");
		stringBuilder.append("		    AND PAYCHAR.CHAR_TYPE_CD = :charTypeID ");
		stringBuilder.append("		    ) ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(),	"=getTotPlgPay=");
		prepState.bindId("billID", bill.getId());
		prepState.bindId("charTypeID", charType.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			BigDecimal sumTotAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_TOT_AMT");
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			//sumTotAmt = sumTotAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			wCurrPldgPayAmt = new Money(sumCurAmt, wAccountCurrencyID);
			wTotPldgPayAmt = new Money(sumTotAmt, wAccountCurrencyID);
		}		
		prepState.close();		
	}
	
	private Money getTotPay(Bill bill) {
		
		Money returnValue = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    NVL(SUM(FT.CUR_AMT), 0) SUM_CUR_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_FT FT ");
		stringBuilder.append("WHERE FT.BILL_ID = :billID ");
		stringBuilder.append("AND FT.FT_TYPE_FLG IN ('PS', 'PX') ");
		stringBuilder.append("AND FT.FREEZE_SW = 'Y' ");
		stringBuilder.append("AND FT.REDUNDANT_SW = 'N' ");
		stringBuilder.append("AND FT.SHOW_ON_BILL_SW = 'Y' ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getTotPay=");
		prepState.bindId("billID", bill.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			returnValue = new Money(sumCurAmt, wAccountCurrencyID);
		}		
		prepState.close();
		return returnValue;
	}

	private void getLpcAdj(Bill bill, CharacteristicType charType) {
		
		// Initialize output
		wCurrLpcAdjAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wTotLpcAdjAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT "); 
		stringBuilder.append("    NVL(SUM(FT.CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("    NVL(SUM(FT.TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM "); 
		stringBuilder.append("    CI_FT FT, ");
		stringBuilder.append("    CI_ADJ ADJ, ");
		stringBuilder.append("    CI_ADJ_TYPE ADJTYPE ");
		stringBuilder.append("WHERE FT.BILL_ID = :billID ");
		stringBuilder.append("AND FT.SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("AND FT.FT_TYPE_FLG IN ('AD', 'AX') ");
		stringBuilder.append("AND ADJ.ADJ_ID = FT.SIBLING_ID ");
		stringBuilder.append("AND ADJTYPE.ADJ_TYPE_CD = ADJ.ADJ_TYPE_CD ");
		stringBuilder.append("AND EXISTS (SELECT 'X' ");
		stringBuilder.append("		    FROM CI_ADJ_TY_CHAR ADJTYCHAR ");
		stringBuilder.append("		    WHERE ADJTYCHAR.ADJ_TYPE_CD = ADJTYPE.ADJ_TYPE_CD ");
		stringBuilder.append("		    AND ADJTYCHAR.CHAR_TYPE_CD = :charType ");
		stringBuilder.append("		   ) ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getLpcAdj=");
		prepState.bindId("billID", bill.getId());
		prepState.bindId("charType", charType.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			BigDecimal sumTotAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_TOT_AMT");
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			//sumTotAmt = sumTotAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			wCurrLpcAdjAmt = new Money(sumCurAmt, wAccountCurrencyID);
			wTotLpcAdjAmt = new Money(sumTotAmt, wAccountCurrencyID);
		}
		prepState.close();
	}
	
	private String getCisDivChar(CisDivision cisDiv, CharacteristicType charType, Date effDt) {
		
		String returnValue = " ";
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ADHOC_CHAR_VAL, CHAR_VAL_FK1, CHAR_VAL ");
		stringBuilder.append("FROM CI_CIS_DIV_CHAR ");
		stringBuilder.append("WHERE CIS_DIVISION = :cisDivID ");
		stringBuilder.append("AND CHAR_TYPE_CD = :charTypeID ");
		stringBuilder.append("AND EFFDT <= :effDt ");
		stringBuilder.append("ORDER BY EFFDT DESC ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getCisDivChar=");
		prepState.bindId("cisDivID", cisDiv.getId());
		prepState.bindId("charTypeID", charType.getId());
		prepState.bindDate("effDt", effDt);
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			if (charTypeLookup.isAdhocValue()
					|| charTypeLookup.isFileLocationValue()) {
				returnValue = sqlRow.getString("ADHOC_CHAR_VALUE");
			}
			else if (charTypeLookup.isForeignKeyValue()) {
				returnValue = sqlRow.getString("CHAR_VAL_FK1");
			}
			else {
				returnValue = sqlRow.getString("CHAR_VAL");
			}
		}
		prepState.close();
		return returnValue;
	}
	
	private Bool checkAutopay(Account acct, Date startDt, Date endDt) {
		
		Bool returnValue = Bool.FALSE;
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    ACCT_APAY_ID ");
		stringBuilder.append("FROM "); 
		stringBuilder.append("    CI_ACCT_APAY ");
		stringBuilder.append("WHERE ACCT_ID = :acctID ");
		stringBuilder.append("AND START_DT <= :startDt ");
		stringBuilder.append("AND (END_DT IS NULL "); 
		stringBuilder.append("	 OR END_DT >= :endDt ");
		stringBuilder.append("	 ) ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=checkAutopay=");
		prepState.bindId("acctID", acct.getId());
		prepState.bindDate("startDt", startDt);
		prepState.bindDate("endDt", endDt);
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			returnValue = Bool.TRUE;
		}
		prepState.close();
		return returnValue;
	}
	
	private void getBudgetDetails(Account account, ServiceAgreementStatusLookup saStatus, Bill bill) {
		
		// Initialize Output
		wBudgetRecurringChargeAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBudgetPlanID = null;
		wBudgetPlanDescr = " ";
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    NVL(SUM(RCHG.RCR_CHG_AMT), 0) SUM_RCR_CHG_AMT, ");
		stringBuilder.append("    BUDPLAN.BUD_PLAN_CD, ");
		stringBuilder.append("    BUDPLAN.DESCR ");
		stringBuilder.append(" FROM ");
		stringBuilder.append("    CI_SA SA, ");
		stringBuilder.append("    CI_SA_TYPE SATYPE, ");
		stringBuilder.append("    CI_SA_RCHG_HIST RCHG, ");
		stringBuilder.append("    CI_ACCT ACCT, ");
		stringBuilder.append("    CI_BUD_PLAN_L BUDPLAN ");
		stringBuilder.append("WHERE SA.ACCT_ID = :acctID ");
		stringBuilder.append("AND SA.SA_STATUS_FLG < :saStatus ");
		stringBuilder.append("AND RCHG.SA_ID = SA.SA_ID ");
		stringBuilder.append("AND RCHG.EFFDT = (SELECT MAX(RCHG2.EFFDT) ");
		stringBuilder.append("                  FROM CI_SA_RCHG_HIST RCHG2 ");
		stringBuilder.append("                  WHERE RCHG2.SA_ID = RCHG.SA_ID ");
		stringBuilder.append("                  AND RCHG2.EFFDT <= (SELECT MAX(BSEG.END_DT) ");
		stringBuilder.append("                                     FROM CI_BSEG BSEG ");
		stringBuilder.append("                                     WHERE BSEG.BILL_ID =:billID ");
		stringBuilder.append("                                     AND BSEG.SA_ID = SA.SA_ID ");
		stringBuilder.append("                                     AND BSEG.BSEG_STAT_FLG = '50' ");
		stringBuilder.append("                                     ) ");
		stringBuilder.append("                 ) ");
		stringBuilder.append("AND ACCT.ACCT_ID = SA.ACCT_ID ");
		stringBuilder.append("AND BUDPLAN.BUD_PLAN_CD = ACCT.BUD_PLAN_CD ");
		stringBuilder.append("AND SATYPE.CIS_DIVISION = SA.CIS_DIVISION ");
		stringBuilder.append("AND SATYPE.SA_TYPE_CD = SA.SA_TYPE_CD ");
		stringBuilder.append("AND SATYPE.ELIG_BUDGET_SW = 'Y' ");
		stringBuilder.append("GROUP BY BUDPLAN.BUD_PLAN_CD, BUDPLAN.DESCR ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getBudgetDetails=");
		prepState.bindId("acctID", account.getId());
		prepState.bindLookup("saStatus", saStatus);
		prepState.bindId("billID", bill.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			BigDecimal cumRcrgChrgAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_RCR_CHG_AMT");
			//cumRcrgChrgAmt = cumRcrgChrgAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			wBudgetRecurringChargeAmt = new Money(cumRcrgChrgAmt, wAccountCurrencyID);
			wBudgetPlanID = (BudgetPlan_Id) sqlRow.getId("BUD_PLAN_CD", BudgetPlan.class);
			wBudgetPlanDescr = sqlRow.getString("DESCR");
		}
		prepState.close();	    
	}
	
	private Iterator<SQLResultRow> getBudgetDetails2(Account account, ServiceAgreementStatusLookup saStatus, 
			Bill bill, CharacteristicType charType) {
		
		Iterator<SQLResultRow> returnValue = null;
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    SA.SA_ID, ");
		stringBuilder.append("    BSEG.BSEG_ID ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_SA SA, ");
		stringBuilder.append("    CI_BSEG BSEG, ");
		stringBuilder.append("    CI_SA_TYPE SATYPE ");
		stringBuilder.append("WHERE SA.ACCT_ID = :acctID ");
		stringBuilder.append("AND SA.SA_STATUS_FLG < :saStatus ");
		stringBuilder.append("AND BSEG.SA_ID = SA.SA_ID ");
		stringBuilder.append("AND BSEG.BILL_ID = :billID ");
		stringBuilder.append("AND BSEG.BSEG_STAT_FLG = '50' ");
		stringBuilder.append("AND EXISTS (SELECT 'X' ");
		stringBuilder.append("            FROM CI_ACCT ACCT ");
		stringBuilder.append("            WHERE ACCT.ACCT_ID = SA.ACCT_ID ");
		stringBuilder.append("            AND ACCT.BUD_PLAN_CD <> ' ' ");
		stringBuilder.append("			) ");
		stringBuilder.append("AND SATYPE.CIS_DIVISION = SA.CIS_DIVISION ");
		stringBuilder.append("AND SATYPE.SA_TYPE_CD = SA.SA_TYPE_CD ");
		stringBuilder.append("AND SATYPE.ELIG_BUDGET_SW = 'N' ");
		stringBuilder.append("AND EXISTS (SELECT 'X' ");
		stringBuilder.append("            FROM CI_SA_TYPE_CHAR SATYPECHAR ");
		stringBuilder.append("            WHERE SATYPECHAR.CIS_DIVISION = SATYPE.CIS_DIVISION ");
		stringBuilder.append("            AND SATYPECHAR.SA_TYPE_CD = SATYPE.SA_TYPE_CD ");
		stringBuilder.append("            AND SATYPECHAR.CHAR_TYPE_CD = :charType ");
		stringBuilder.append("			) ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getBudgetDetails2=");
		prepState.bindId("acctID", account.getId());
		prepState.bindLookup("saStatus", saStatus);
		prepState.bindId("billID", bill.getId());
		prepState.bindId("charType", charType.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		returnValue = prepState.list().iterator();
		prepState.close();
		return returnValue;
	}
	
	private void getBsegFT(Bill bill, ServiceAgreement_Id saID, BillSegment_Id bsegID) {
		
		// Initialize bsegFT results
		wBsegFtCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wBsegFtTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    NVL(SUM(CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("    NVL(SUM(TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_FT ");
		stringBuilder.append("WHERE BILL_ID = :billID ");
		stringBuilder.append("AND SA_ID = :saID ");
		stringBuilder.append("AND SIBLING_ID = :bsegID ");
		stringBuilder.append("AND FT_TYPE_FLG IN ('BS', 'BX') ");
		stringBuilder.append("AND SHOW_ON_BILL_SW = 'Y' ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getBsegFT=");
		prepState.bindId("billID", bill.getId());
		prepState.bindId("saID", saID);
		prepState.bindId("bsegID", bsegID);
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			BigDecimal sumTotAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_TOT_AMT");
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			//sumTotAmt = sumTotAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			wBsegFtCurAmt = new Money(sumCurAmt, wAccountCurrencyID);
			wBsegFtTotAmt = new Money(sumTotAmt, wAccountCurrencyID);
		}
		prepState.close();
	}
	
	@SuppressWarnings("unused")
	private String getDHelpDescr(Account acct, CharacteristicType charType, Language lang) {
		
		String returnValue = " ";
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    SATYPEL.DESCR, ");
		stringBuilder.append("    SATYPEL.DFLT_DESCR_ON_BILL ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_ACCT ACCT, ");
		stringBuilder.append("    CI_SA SA, ");
		stringBuilder.append("    CI_SA_TYPE SATYPE, ");
		stringBuilder.append("    CI_SA_TYPE_L SATYPEL ");
		stringBuilder.append("WHERE ACCT.ACCT_ID = :acctID ");
		stringBuilder.append("AND SA.ACCT_ID = ACCT.ACCT_ID ");
		stringBuilder.append("AND SATYPE.CIS_DIVISION = SA.CIS_DIVISION ");
		stringBuilder.append("AND SATYPE.SA_TYPE_CD = SA.SA_TYPE_CD ");
		stringBuilder.append("AND EXISTS (SELECT 'X' ");
		stringBuilder.append("            FROM CI_SA_TYPE_CHAR SATYPECHAR ");
		stringBuilder.append("            WHERE SATYPECHAR.CIS_DIVISION = SATYPE.CIS_DIVISION ");
		stringBuilder.append("            AND SATYPECHAR.SA_TYPE_CD = SATYPE.SA_TYPE_CD ");
		stringBuilder.append("            AND SATYPECHAR.CHAR_TYPE_CD = :charTypeID ");
		stringBuilder.append("			) ");
		stringBuilder.append("AND SATYPEL.CIS_DIVISION = SATYPE.CIS_DIVISION ");
		stringBuilder.append("AND SATYPEL.SA_TYPE_CD = SATYPE.SA_TYPE_CD ");
		stringBuilder.append("AND SATYPEL.LANGUAGE_CD = :languageID ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getDHelpDescr=");
		prepState.bindId("acctID", acct.getId());
		prepState.bindId("charTypeID", charType.getId());
		prepState.bindId("languageID", lang.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			String saTypeLDescr = (String) sqlRow.getString("DESCR");
			String defaultDescrOnBill = (String) sqlRow.getString("DFLT_DESCR_ON_BILL");
			returnValue = defaultDescrOnBill;
		}
		prepState.close();
		return returnValue;		
	}
	
	private Money getDollarHelpAmt(Account acct, DateTime startDttm, DateTime endDttm, CharacteristicType charType) {
		
		Money returnValue = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   NVL(SUM(FT.CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("   NVL(SUM(FT.TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_FT FT, ");
		stringBuilder.append("   CI_SA SA, ");
		stringBuilder.append("   CI_SA_TYPE SATYPE ");
		stringBuilder.append("WHERE FT.FT_TYPE_FLG IN ('PS','PX') ");
		stringBuilder.append("AND SA.ACCT_ID = :acctID ");
		stringBuilder.append("AND FT.SA_ID = SA.SA_ID ");
		stringBuilder.append("AND FT.FREEZE_SW = 'Y' ");
		stringBuilder.append("AND FT.REDUNDANT_SW = 'N' ");
		stringBuilder.append("AND FT.SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("AND FT.FREEZE_DTTM BETWEEN :startDttm AND :endDttm ");
		stringBuilder.append("AND SATYPE.CIS_DIVISION = SA.CIS_DIVISION ");
		stringBuilder.append("AND SATYPE.SA_TYPE_CD = SA.SA_TYPE_CD ");
		stringBuilder.append("AND EXISTS (SELECT 'X' ");
		stringBuilder.append("            FROM CI_SA_TYPE_CHAR SATYPECHAR ");
		stringBuilder.append("            WHERE SATYPECHAR.CIS_DIVISION = SATYPE.CIS_DIVISION ");
		stringBuilder.append("            AND SATYPECHAR.SA_TYPE_CD = SATYPE.SA_TYPE_CD ");
		stringBuilder.append("            AND SATYPECHAR.CHAR_TYPE_CD = :charType ");
		stringBuilder.append("			) ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getDollarHelpAmt=");
		prepState.bindId("acctID", acct.getId());
		prepState.bindDateTime("startDttm", startDttm);
		prepState.bindDateTime("endDttm", endDttm);
		prepState.bindId("charType", charType.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			BigDecimal bdcuramt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			//bdcuramt = bdcuramt.setScale(2, BigDecimal.ROUND_HALF_UP);
			returnValue = new Money(bdcuramt, wAccountCurrencyID);
		}
		prepState.close();
		return returnValue;
	}
	
	private Iterator<SQLResultRow> getBillBsegs(Bill bill) {
		
		Iterator<SQLResultRow> returnValue = null;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT ");
		stringBuilder.append("   BSEGCALC.BSEG_ID, ");
		stringBuilder.append("   BSEGCALC.HEADER_SEQ ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_BSEG BSEG, ");
		stringBuilder.append("   CI_BSEG_CALC BSEGCALC ");
		stringBuilder.append("WHERE BSEG.BILL_ID = :billID ");
		stringBuilder.append("AND BSEG.BSEG_STAT_FLG = '50' ");
		stringBuilder.append("AND BSEGCALC.BSEG_ID = BSEG.BSEG_ID ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getBillBsegs=");
		prepState.bindId("billID", bill.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		returnValue = prepState.list().iterator();
		prepState.close();
		return returnValue;
	}
	
	private void getCalcLine(BillSegment_Id bsegID, BigInteger headerSeq, CharacteristicType charType) {
		
		// Initialize Output
		wClCharCalcAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wClCharDescrOnBill = " ";
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   CALCLN.DESCR_ON_BILL, ");
		stringBuilder.append("   CALCLN.CALC_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_BSEG_CALC_LN CALCLN, ");
		stringBuilder.append("   CI_BSEG_CL_CHAR CLCHAR ");
		stringBuilder.append("WHERE CALCLN.BSEG_ID = :bsegID ");
		stringBuilder.append("AND CALCLN.HEADER_SEQ = :headerSeq ");
		stringBuilder.append("AND CLCHAR.BSEG_ID = CALCLN.BSEG_ID ");
		stringBuilder.append("AND CLCHAR.HEADER_SEQ = CALCLN.HEADER_SEQ ");
		stringBuilder.append("AND CLCHAR.SEQNO = CALCLN.SEQNO ");
		stringBuilder.append("AND CLCHAR.CHAR_TYPE_CD = :charTypeID ");
		stringBuilder.append("AND CLCHAR.SEQNO = (SELECT MAX(CLCHAR2.SEQNO) ");
		stringBuilder.append("                    FROM CI_BSEG_CL_CHAR CLCHAR2 ");
		stringBuilder.append("                    WHERE CLCHAR2.BSEG_ID = CLCHAR.BSEG_ID ");
		stringBuilder.append("                    AND CLCHAR2.HEADER_SEQ = CLCHAR.HEADER_SEQ ");
		stringBuilder.append("                    AND CLCHAR2.CHAR_TYPE_CD = CLCHAR.CHAR_TYPE_CD ");
		stringBuilder.append("					) ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getCalcLine=");
		prepState.bindId("bsegID", bsegID);
		prepState.bindBigInteger("headerSeq", headerSeq);
		prepState.bindId("charTypeID", charType.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			wClCharDescrOnBill = sqlRow.getString("DESCR_ON_BILL");
			BigDecimal calcAmt = (BigDecimal) sqlRow.getBigDecimal("CALC_AMT");
			//calcAmt = calcAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			wClCharCalcAmt = new Money(calcAmt, wAccountCurrencyID);
		}
		prepState.close();		
	}
	
	private void getCurrPA(Bill bill, SpecialRoleLookup specialRole) {
		
		// Initialize Output
		wCurrPACurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wCurrPATotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   FT.CURRENCY_CD, ");
		stringBuilder.append("   NVL(SUM(FT.CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("   NVL(SUM(FT.TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_FT FT, ");
		stringBuilder.append("    CI_SA SA, ");
		stringBuilder.append("    CI_SA_TYPE SATYPE ");
		stringBuilder.append("WHERE FT.BILL_ID = :billID ");
		stringBuilder.append("AND FT.FT_TYPE_FLG IN ('BS','BX') ");
		stringBuilder.append("AND FT.CORRECTION_SW = 'N' ");
		stringBuilder.append("AND FT.SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("AND SA.SA_ID = FT.SA_ID ");
		stringBuilder.append("AND SATYPE.CIS_DIVISION = SA.CIS_DIVISION ");
		stringBuilder.append("AND SATYPE.SA_TYPE_CD = SA.SA_TYPE_CD ");
		stringBuilder.append("AND SATYPE.SPECIAL_ROLE_FLG = :specialRole ");
		stringBuilder.append("GROUP BY FT.CURRENCY_CD ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getCurrPA=");
		prepState.bindId("billID", bill.getId());
		prepState.bindLookup("specialRole", specialRole);
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			Currency_Id currencyID = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
			BigDecimal sumCurAmt = sqlRow.getBigDecimal("SUM_CUR_AMT");
			BigDecimal sumTotAmt = sqlRow.getBigDecimal("SUM_TOT_AMT");
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			//sumTotAmt = sumTotAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			wCurrPACurAmt = new Money(sumCurAmt, currencyID);
			wCurrPATotAmt = new Money(sumTotAmt, currencyID);			
		}
		prepState.close();
	}
	
	private void getDollarHelpBillAmt(Bill bill, CharacteristicType charType) {
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   NVL(SUM(FT.CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("   NVL(SUM(FT.TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_FT FT, ");
		stringBuilder.append("   CI_SA SA, ");
		stringBuilder.append("   CI_SA_TYPE SATYPE ");
		stringBuilder.append("WHERE FT.BILL_ID = :billID ");   
		stringBuilder.append("AND FT.FT_TYPE_FLG IN ('BS', 'BX') ");
		stringBuilder.append("AND FT.FREEZE_SW = 'Y' ");
		stringBuilder.append("AND FT.REDUNDANT_SW = 'N' ");
		stringBuilder.append("AND FT.SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("AND FT.SA_ID = SA.SA_ID ");
		stringBuilder.append("AND SATYPE.CIS_DIVISION = SA.CIS_DIVISION ");
		stringBuilder.append("AND SATYPE.SA_TYPE_CD = SA.SA_TYPE_CD ");
		stringBuilder.append("AND EXISTS (SELECT 'X' ");
		stringBuilder.append("            FROM CI_SA_TYPE_CHAR SATYPECHAR ");
		stringBuilder.append("            WHERE SATYPECHAR.CIS_DIVISION = SATYPE.CIS_DIVISION ");
		stringBuilder.append("            AND SATYPECHAR.SA_TYPE_CD = SATYPE.SA_TYPE_CD ");
		stringBuilder.append("            AND SATYPECHAR.CHAR_TYPE_CD = :charTypeCD ");
		stringBuilder.append("			) ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getDollarHelpBillAmt=");
		prepState.bindId("billID", bill.getId());
		prepState.bindId("charTypeCD", charType.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			BigDecimal sumTotAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_TOT_AMT");
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			//sumTotAmt = sumTotAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			wDHCurAmt = new Money(sumCurAmt, wAccountCurrencyID);
			wDHTotAmt = new Money(sumTotAmt, wAccountCurrencyID);	
			
			// START ADD - JHERNA - 2019-10-30 - 312869
			if (wDHCurAmt.isNegative()) {
				wDHCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);	
			}
			if (wDHTotAmt.isNegative()) {
				wDHTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
			}
			// END ADD - JHERNA - 2019-10-30 - 312869
		}
		prepState.close();
	}
	
	private Iterator<SQLResultRow> getCorrectionBseg(FinancialTransactionTypeLookup ftTypeBS,
			FinancialTransactionTypeLookup ftTypeBX, Bill bill) {
		
		Iterator<SQLResultRow> returnValue = null;
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   BSEG.START_DT, ");
		stringBuilder.append("   BSEG.END_DT, ");
		stringBuilder.append("   FT.FT_TYPE_FLG, ");
		stringBuilder.append("   FT.CUR_AMT, ");
		stringBuilder.append("   FT.TOT_AMT, ");
		stringBuilder.append("   FT.SA_ID, ");
		stringBuilder.append("   SA.CIS_DIVISION, ");
		stringBuilder.append("   SA.SA_TYPE_CD, ");
		stringBuilder.append("   SATYPE.ELIG_BUDGET_SW ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_FT FT, ");
		stringBuilder.append("   CI_BSEG BSEG, ");
		stringBuilder.append("   CI_SA SA, ");
		stringBuilder.append("   CI_SA_TYPE SATYPE ");
		stringBuilder.append("WHERE FT.BILL_ID = :billID ");
		stringBuilder.append("AND FT.FT_TYPE_FLG IN (:ftType1, :ftType2) ");
		stringBuilder.append("AND FT.FREEZE_SW = 'Y' ");
		stringBuilder.append("AND FT.REDUNDANT_SW = 'N' ");
		stringBuilder.append("AND FT.CORRECTION_SW = 'Y' ");
		stringBuilder.append("AND FT.SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("AND BSEG.BSEG_ID = FT.SIBLING_ID ");
		stringBuilder.append("AND SA.SA_ID = FT.SA_ID ");
		// START ADD - JHERNA - 2019-10-30 - 312869
		stringBuilder.append("AND SA.SA_TYPE_CD != 'GDHELP' ");
		// END ADD - JHERNA - 2019-10-30 - 312869
		stringBuilder.append("AND SATYPE.CIS_DIVISION = SA.CIS_DIVISION ");
		stringBuilder.append("AND SATYPE.SA_TYPE_CD = SA.SA_TYPE_CD ");			
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getCorrectionBseg=");
		prepState.bindId("billID", bill.getId());
		prepState.bindLookup("ftType1", ftTypeBS);
		prepState.bindLookup("ftType2", ftTypeBX);
		prepState.execute();
		prepState.setAutoclose(false);
		returnValue = prepState.list().iterator();
		prepState.close();						
		return returnValue;
	}
	
	private String getSaTypeChar(CisDivision_Id cisDivID, String saTypeStr, CharacteristicType charType) {
		
		String returnValue = " ";
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   SATYPECHAR.ADHOC_CHAR_VAL, ");
		stringBuilder.append("   SATYPECHAR.CHAR_VAL, ");
		stringBuilder.append("   SATYPECHAR.CHAR_VAL_FK1 ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_SA_TYPE_CHAR SATYPECHAR ");
		stringBuilder.append("WHERE SATYPECHAR.CIS_DIVISION = :cisDivisionID ");
		stringBuilder.append("AND SATYPECHAR.SA_TYPE_CD = :saTypeCd ");
		stringBuilder.append("AND SATYPECHAR.CHAR_TYPE_CD = :charTypeCd ");
		stringBuilder.append("ORDER BY SATYPECHAR.SEQ_NUM ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getSaTypeChar=");
		prepState.bindId("cisDivisionID", cisDivID);
		prepState.bindString("saTypeCd", saTypeStr.trim(), "SA_TYPE_CD");
		prepState.bindId("charTypeCd", charType.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			if (charTypeLookup.isAdhocValue()
					|| charTypeLookup.isFileLocationValue()) {
				returnValue = (String) sqlRow.getString("ADHOC_CHAR_VAL");
			}
			else if (charTypeLookup.isForeignKeyValue()) {
				returnValue = (String) sqlRow.getString("CHAR_VAL_FK1");
			}
			else {
				returnValue = (String) sqlRow.getString("CHAR_VAL");
			}
		}
		prepState.close();		
		return returnValue;
	}
	
	private List<String> getSaTypeCharList(CisDivision_Id cisDivID, String saTypeCd, CharacteristicType charType) {
		
		List<String> returnValue = new ArrayList<String>();
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   SATYPECHAR.ADHOC_CHAR_VAL, ");
		stringBuilder.append("   SATYPECHAR.CHAR_VAL, ");
		stringBuilder.append("   SATYPECHAR.CHAR_VAL_FK1 ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_SA_TYPE_CHAR SATYPECHAR ");
		stringBuilder.append("WHERE SATYPECHAR.CIS_DIVISION = :cisDivisionID ");
		stringBuilder.append("AND SATYPECHAR.SA_TYPE_CD = :saTypeCd ");
		stringBuilder.append("AND SATYPECHAR.CHAR_TYPE_CD = :charTypeCd ");
		stringBuilder.append("ORDER BY SATYPECHAR.SEQ_NUM ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getSaTypeChar=");
		prepState.bindId("cisDivisionID", cisDivID);
		prepState.bindString("saTypeCd", saTypeCd.trim(), "SA_TYPE_CD");
		prepState.bindId("charTypeCd", charType.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			Iterator<SQLResultRow> iter = prepState.list().iterator();
			while (iter.hasNext()) {
				SQLResultRow sqlRow = (SQLResultRow) iter.next();
				CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
				String charVal = " ";
				if (charTypeLookup.isAdhocValue()
						|| charTypeLookup.isFileLocationValue()) {
					charVal = (String) sqlRow.getString("ADHOC_CHAR_VAL");
				}
				else if (charTypeLookup.isForeignKeyValue()) {
					charVal = (String) sqlRow.getString("CHAR_VAL_FK1");
				}
				else {
					charVal = (String) sqlRow.getString("CHAR_VAL");
				}
				returnValue.add(charVal);
			}			
		}
		prepState.close();		
		return returnValue;
	}
	
	private Bool getRecurringCharge(ServiceAgreement_Id saID, Date endDt) {
		
		Bool returnValue = Bool.FALSE;
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   'X' ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_SA_RCHG_HIST RCHG ");
		stringBuilder.append("WHERE RCHG.SA_ID = :saID ");
		stringBuilder.append("AND EFFDT <= :effDt ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getRecurringCharge=");
		prepState.bindId("saID", saID);
		prepState.bindDate("effDt", endDt);
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			returnValue = Bool.TRUE;
		}
		prepState.close();
		return returnValue;
	}
	
	private void getOtherAdj(FinancialTransactionTypeLookup ftType1, FinancialTransactionTypeLookup ftType2, Bill bill) {

		// Initialize Output
		wOtherAdjCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   NVL(SUM(FT.CUR_AMT), 0) SUM_CUR_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_FT FT ");
		stringBuilder.append("WHERE FT.BILL_ID = :billID ");
		stringBuilder.append("AND FT.FT_TYPE_FLG IN (:ftType1, :ftType2) ");
		stringBuilder.append("AND FT.FREEZE_SW = 'Y' ");
		stringBuilder.append("AND FT.REDUNDANT_SW = 'N' ");
		stringBuilder.append("AND FT.SHOW_ON_BILL_SW = 'Y' ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getOtherAdj;ZS430-SETUP-SQL-S-OTHADJ=");
		prepState.bindId("billID", bill.getId());
		prepState.bindLookup("ftType1", ftType1);
		prepState.bindLookup("ftType2", ftType2);
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			wOtherAdjCurAmt = new Money(sumCurAmt, wAccountCurrencyID);
		}
		prepState.close();
	}
	
	private void getDepositLoanAmt(Bill bill, SpecialRoleLookup role1,	SpecialRoleLookup role2) {
		
		// Initialize 
		wDepLoanCurAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		wDepLoanTotAmt = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   NVL(SUM(FT.CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("   NVL(SUM(FT.TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_FT FT, ");
		stringBuilder.append("    CI_SA SA, ");
		stringBuilder.append("    CI_SA_TYPE SATYPE ");
		stringBuilder.append("WHERE FT.BILL_ID = :billID ");
		stringBuilder.append("AND FT.FT_TYPE_FLG IN ('BS', 'BX') ");
		stringBuilder.append("AND FT.CORRECTION_SW = 'N' ");
		stringBuilder.append("AND FT.SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("AND FT.SA_ID = SA.SA_ID ");
		stringBuilder.append("AND SATYPE.CIS_DIVISION = SA.CIS_DIVISION ");
		stringBuilder.append("AND SATYPE.SA_TYPE_CD = SA.SA_TYPE_CD ");
		stringBuilder.append("AND SATYPE.SPECIAL_ROLE_FLG IN (:role1, :role2) ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getDepositLoanAmt=");
		prepState.bindId("billID", bill.getId());
		prepState.bindLookup("role1", role1);
		prepState.bindLookup("role2", role2);
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			BigDecimal sumTotAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_TOT_AMT");
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			//sumTotAmt = sumTotAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			wDepLoanCurAmt = new Money(sumCurAmt, wAccountCurrencyID);
			wDepLoanTotAmt = new Money(sumTotAmt, wAccountCurrencyID);			
		}
		prepState.close();
	}
	
	private Money getPrevNonCDLoan(Bill bill, Date billDt) {
		
		Money returnValue = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   ft.CURRENCY_CD, ");
		stringBuilder.append("   NVL(SUM(ft.CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("   NVL(SUM(ft.TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_BILL_SA billSA, ");
		stringBuilder.append("   CI_SA sa, ");
		stringBuilder.append("   CI_SA_TYPE saType, ");
		stringBuilder.append("   CI_FT ft, ");
		stringBuilder.append("   CI_BILL bill ");
		stringBuilder.append("WHERE billSA.SA_ID = sa.SA_ID ");
		stringBuilder.append("AND sa.CIS_DIVISION = saType.CIS_DIVISION ");
		stringBuilder.append("AND sa.SA_TYPE_CD = saType.SA_TYPE_CD ");
		stringBuilder.append("AND sa.SA_ID = ft.SA_ID ");
		stringBuilder.append("AND ft.BILL_ID <> ' ' ");
		stringBuilder.append("AND ft.BILL_ID <> billSA.BILL_ID ");
		stringBuilder.append("AND saType.SPECIAL_ROLE_FLG NOT IN ('CD', 'LO') ");
		stringBuilder.append("AND billSA.BILL_ID = :billID ");
		stringBuilder.append("AND ft.BILL_ID = bill.BILL_ID ");
		stringBuilder.append("AND bill.BILL_DT <= :billDt ");
		stringBuilder.append("AND EXISTS (SELECT ");
		stringBuilder.append("               'X' ");
		stringBuilder.append("            FROM ");
		stringBuilder.append("               CI_SA_SP saSP ");
		stringBuilder.append("            WHERE saSP.SA_ID = sa.SA_ID ");
		stringBuilder.append("            ) ");
		stringBuilder.append("GROUP BY ft.CURRENCY_CD ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getPrevNonCDLoan;ZS480-SETUP-SQL-S-PBALBUD=");
		prepState.bindId("billID", bill.getId());
		prepState.bindDate("billDt", billDt);
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			Currency_Id currencyID = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
			BigDecimal sumTotAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_TOT_AMT");
			//sumTotAmt = sumTotAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			returnValue = new Money(sumTotAmt, currencyID);
		}
		prepState.close();
		return returnValue;
	}
	
	private Money getPrevCDLoan(Bill bill, Date billDt) {
		
		Money returnValue = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   ft.CURRENCY_CD, ");
		stringBuilder.append("   NVL(SUM(ft.CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("   NVL(SUM(ft.TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_BILL_SA billSA, ");
		stringBuilder.append("   CI_SA sa, ");
		stringBuilder.append("   CI_SA_TYPE saType, ");
		stringBuilder.append("   CI_FT ft, ");
		stringBuilder.append("   CI_BILL bill ");
		stringBuilder.append("WHERE billSA.SA_ID = sa.SA_ID ");
		stringBuilder.append("AND sa.CIS_DIVISION = saType.CIS_DIVISION ");
		stringBuilder.append("AND sa.SA_TYPE_CD = saType.SA_TYPE_CD ");
		stringBuilder.append("AND sa.SA_ID = ft.SA_ID ");
		stringBuilder.append("AND ft.BILL_ID <> ' ' ");
		stringBuilder.append("AND ft.BILL_ID <> billSA.BILL_ID ");
		stringBuilder.append("AND saType.SPECIAL_ROLE_FLG IN ('CD', 'LO') ");
		stringBuilder.append("AND billSA.BILL_ID = :billID ");
		stringBuilder.append("AND ft.BILL_ID = bill.BILL_ID ");
		stringBuilder.append("AND bill.BILL_DT <= :billDt ");
		stringBuilder.append("GROUP BY ft.CURRENCY_CD ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getPrevCDLoan=");
		prepState.bindId("billID", bill.getId());
		prepState.bindDate("billDt", billDt);
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			Currency_Id currencyID = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			returnValue = new Money(sumCurAmt, currencyID);
		}
		prepState.close();
		return returnValue;		
	}
	
	private Money getPrevOtherBal(Bill bill, Date billDt) {
		
		Money returnValue = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   ft.CURRENCY_CD, ");
		stringBuilder.append("   NVL(SUM(ft.CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("   NVL(SUM(ft.TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_BILL_SA billSA, ");
		stringBuilder.append("   CI_SA sa, ");
		stringBuilder.append("   CI_SA_TYPE saType, ");
		stringBuilder.append("   CI_FT ft, ");
		stringBuilder.append("   CI_BILL bill ");
		stringBuilder.append("WHERE billSA.SA_ID = sa.SA_ID ");
		stringBuilder.append("AND sa.CIS_DIVISION = saType.CIS_DIVISION ");
		stringBuilder.append("AND sa.SA_TYPE_CD = saType.SA_TYPE_CD ");
		stringBuilder.append("AND sa.SA_ID = ft.SA_ID ");
		stringBuilder.append("AND ft.BILL_ID <> ' ' ");
		stringBuilder.append("AND ft.BILL_ID <> billSA.BILL_ID ");
		stringBuilder.append("AND saType.SPECIAL_ROLE_FLG NOT IN ('CD', 'LO') ");
		stringBuilder.append("AND billSA.BILL_ID = :billID ");
		stringBuilder.append("AND ft.BILL_ID = bill.BILL_ID ");
		stringBuilder.append("AND bill.BILL_DT <= :billDt ");
		stringBuilder.append("AND NOT EXISTS (SELECT ");
		stringBuilder.append("                    'X' ");
		stringBuilder.append("                FROM ");
		stringBuilder.append("                    CI_SA_SP saSP ");
		stringBuilder.append("                WHERE saSP.SA_ID = sa.SA_ID ");
		stringBuilder.append("                ) ");
		stringBuilder.append("GROUP BY ft.CURRENCY_CD ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getPrevOtherBal=");
		prepState.bindId("billID", bill.getId());
		prepState.bindDate("billDt", billDt);
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			Currency_Id currencyID = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
			BigDecimal sumTotAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_TOT_AMT");
			//sumTotAmt = sumTotAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			returnValue = new Money(sumTotAmt, currencyID);
		}
		prepState.close();	
		return returnValue;
	}
	
	private Iterator<SQLResultRow> getPaSAS(Bill bill, SpecialRoleLookup role, CharacteristicType charType) {
		
		Iterator<SQLResultRow> returnValue = null;
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   SA.SA_ID, ");
		stringBuilder.append("   SA.SA_TYPE_CD, ");
		stringBuilder.append("   CALCLN.DESCR_ON_BILL, ");
		stringBuilder.append("   CALCLN.CALC_AMT, ");
		stringBuilder.append("   BSEG.BILL_ID ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_BSEG BSEG, ");
		stringBuilder.append("   CI_SA SA, ");
		stringBuilder.append("   CI_SA_TYPE SATYPE, ");
		stringBuilder.append("   CI_BSEG_CALC CALCHDR, ");
		stringBuilder.append("   CI_BSEG_CALC_LN CALCLN ");
		stringBuilder.append("WHERE BSEG.BILL_ID = :billID ");
		stringBuilder.append("AND BSEG.BSEG_STAT_FLG = '50' ");
		stringBuilder.append("AND SA.SA_ID = BSEG.SA_ID ");
		stringBuilder.append("AND SATYPE.CIS_DIVISION = SA.CIS_DIVISION ");
		stringBuilder.append("AND SATYPE.SA_TYPE_CD = SA.SA_TYPE_CD ");
		stringBuilder.append("AND SATYPE.SPECIAL_ROLE_FLG = :role ");
		stringBuilder.append("AND NOT EXISTS (SELECT 'X' ");
		stringBuilder.append("                FROM CI_SA_TYPE_CHAR SATYPECHAR ");
		stringBuilder.append("                WHERE SATYPECHAR.CIS_DIVISION = SATYPE.CIS_DIVISION ");
		stringBuilder.append("                AND SATYPECHAR.SA_TYPE_CD = SATYPE.SA_TYPE_CD ");
		stringBuilder.append("                AND SATYPECHAR.CHAR_TYPE_CD = :charType ");
		stringBuilder.append("				) ");
		stringBuilder.append("AND CALCHDR.BSEG_ID = BSEG.BSEG_ID ");
		stringBuilder.append("AND CALCLN.BSEG_ID = CALCHDR.BSEG_ID ");
		stringBuilder.append("AND CALCLN.HEADER_SEQ = CALCHDR.HEADER_SEQ ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getPaSAS=");
		prepState.bindId("billID", bill.getId());
		prepState.bindLookup("role", role);
		prepState.bindId("charType", charType.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		returnValue = prepState.list().iterator();
		prepState.close();
		return returnValue;
	}
	
	private Iterator<SQLResultRow> getNextCurrDc(Bill bill, Language lang) {
		
		Iterator<SQLResultRow> returnValue = null;
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    DC.DEBT_CL_CD, ");
		stringBuilder.append("    DCL.DESCR, ");
		stringBuilder.append("    FT.CURRENCY_CD, ");
		stringBuilder.append("    NVL(SUM(FT.CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("    NVL(SUM(FT.TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_FT FT, ");
		stringBuilder.append("    CI_SA SA, ");
		stringBuilder.append("    CI_SA_TYPE ST, ");
		stringBuilder.append("    CI_DEBT_CL DC, ");
		stringBuilder.append("    CI_DEBT_CL_L DCL ");
		stringBuilder.append("WHERE FT.BILL_ID = :billID ");
		stringBuilder.append("AND FT.FT_TYPE_FLG IN ('BS', 'BX') ");
		stringBuilder.append("AND FT.CORRECTION_SW = 'N' ");
		stringBuilder.append("AND FT.SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("AND SA.SA_ID = FT.SA_ID ");
		stringBuilder.append("AND ST.CIS_DIVISION = SA.CIS_DIVISION ");
		stringBuilder.append("AND ST.SA_TYPE_CD = SA.SA_TYPE_CD ");
		stringBuilder.append("AND DC.DEBT_CL_CD = ST.DEBT_CL_CD ");
		stringBuilder.append("AND DC.DEBT_CL_CD = DCL.DEBT_CL_CD ");
		stringBuilder.append("AND DCL.LANGUAGE_CD = :lang ");
		stringBuilder.append("GROUP BY DCL.DESCR, DC.DEBT_CL_CD, FT.CURRENCY_CD ");
		stringBuilder.append("ORDER BY DCL.DESCR, DC.DEBT_CL_CD ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getNextCurrDc=");
		prepState.bindId("billID", bill.getId());
		prepState.bindId("lang", lang.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		returnValue = prepState.list().iterator();
		prepState.close();
		return returnValue;
	}
	
	private Money getOtherBillCharges(FinancialTransactionTypeLookup bseg,
			FinancialTransactionTypeLookup bscanc, Bill bill,
			ServiceType meteredSvc, ServiceType unmeteredSvc,
			SpecialRoleLookup role) {
		
		Money returnValue = new Money(BigDecimal.ZERO, wAccountCurrencyID);
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   NVL(SUM(FT.CUR_AMT), 0) SUM_CUR_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_FT FT, ");
		stringBuilder.append("   CI_SA SA, ");
		stringBuilder.append("   CI_SA_TYPE SATYPE ");
		stringBuilder.append("WHERE FT.BILL_ID = :billID ");
		stringBuilder.append("AND FT.FT_TYPE_FLG IN (:ftType1, :ftType2) ");
		stringBuilder.append("AND FT.FREEZE_SW = 'Y' ");
		stringBuilder.append("AND FT.REDUNDANT_SW = 'N' ");
		stringBuilder.append("AND FT.SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("AND FT.CORRECTION_SW = 'N' ");
		stringBuilder.append("AND FT.SA_ID = SA.SA_ID ");
		stringBuilder.append("AND SA.CIS_DIVISION = SATYPE.CIS_DIVISION ");
		stringBuilder.append("AND SA.SA_TYPE_CD = SATYPE.SA_TYPE_CD ");
		stringBuilder.append("AND SATYPE.SVC_TYPE_CD NOT IN (:svcType1, :svcType2) ");
		stringBuilder.append("AND SATYPE.SPECIAL_ROLE_FLG <> :role ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getOtherBillCharges=");
		prepState.bindId("billID", bill.getId());
		prepState.bindLookup("ftType1", bseg);
		prepState.bindLookup("ftType2", bscanc);
		prepState.bindId("svcType1", meteredSvc.getId());
		prepState.bindId("svcType2", unmeteredSvc.getId());
		prepState.bindLookup("role", role);
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			BigDecimal sumCurAmt = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
			//sumCurAmt = sumCurAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
			returnValue = new Money(sumCurAmt, wAccountCurrencyID);
		}
		prepState.close();
		return returnValue;
	}
	
	private Iterator<SQLResultRow> getPayDtl(Bill bill) {
		
		Iterator<SQLResultRow> returnValue = null;
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    FT.FT_TYPE_FLG, ");
		stringBuilder.append("    FT.ARS_DT, ");
		stringBuilder.append("    PY.CAN_RSN_CD, ");
		stringBuilder.append("    FT.CURRENCY_CD, ");
		stringBuilder.append("    FT.CUR_AMT, ");
		stringBuilder.append("    FT.TOT_AMT, ");
		stringBuilder.append("    PY.PAY_ID, ");
		stringBuilder.append("    PY.PAY_EVENT_ID ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_FT FT, ");
		stringBuilder.append("    CI_PAY_SEG PS, ");
		stringBuilder.append("    CI_PAY PY ");
		stringBuilder.append("WHERE FT.BILL_ID = :billID ");
		stringBuilder.append("AND FT.FT_TYPE_FLG IN ('PS', 'PX') ");
		stringBuilder.append("AND FT.SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("AND PS.PAY_SEG_ID = FT.SIBLING_ID ");
		stringBuilder.append("AND PS.PAY_ID = PY.PAY_ID ");
		stringBuilder.append("ORDER BY FT.ARS_DT ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getPayDtl=");
		prepState.bindId("billID", bill.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		returnValue = prepState.list().iterator();
		prepState.close();
		return returnValue;
	}
	
	private Bool checkPledgePayment(Payment_Id payID, CharacteristicType charType) {
		
		Bool returnValue = Bool.FALSE;
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT 'X' ");
		stringBuilder.append("FROM CI_PAY_CHAR PAYCHAR ");
		stringBuilder.append("WHERE PAYCHAR.PAY_ID = :payID ");
		stringBuilder.append("AND PAYCHAR.CHAR_TYPE_CD = :charType ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=checkPledgePayment=");
		prepState.bindId("payID", payID);
		prepState.bindId("charType", charType.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			returnValue = Bool.TRUE;
		}
		prepState.close();
		return returnValue;
	}
	
	private String getPledgeDescr(PaymentEvent_Id payEventID) {
		
		String returnValue = " ";
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    TNDRSRCEL.DESCR ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_PAY_TNDR PAYTNDR, ");
		stringBuilder.append("    CI_TNDR_CTL TNDRCTL, ");
		stringBuilder.append("    CI_TNDR_SRCE_L TNDRSRCEL ");
		stringBuilder.append("WHERE PAYTNDR.PAY_EVENT_ID = :payEventID ");
		stringBuilder.append("AND TNDRCTL.TNDR_CTL_ID = PAYTNDR.TNDR_CTL_ID ");
		stringBuilder.append("AND TNDRSRCEL.TNDR_SOURCE_CD = TNDRCTL.TNDR_SOURCE_CD ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getPledgeDescr=");
		prepState.bindId("payEventID", payEventID);
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			returnValue = (String) sqlRow.getString("DESCR");
		}
		prepState.close();
		return returnValue;
	}
	
	private Iterator<SQLResultRow> getNextBillMsg(Bill bill, Language lang) {
		
		Iterator<SQLResultRow> returnValue = null;
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    billMsgs.BILL_ID, ");
		stringBuilder.append("    billMsgs.BILL_MSG_CD, ");
		stringBuilder.append("    billMsgLanguage.DESCR, ");
		stringBuilder.append("    billMsgLanguage.MSG_ON_BILL, ");
		stringBuilder.append("    billMsg.MSG_PRIORITY_FLG, ");
		stringBuilder.append("    billMsg.INSERT_CD ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_BILL_MSGS billMsgs, ");
		stringBuilder.append("    CI_BILL_MSG billMsg, ");
		stringBuilder.append("    CI_BILL_MSG_L billMsgLanguage ");
		stringBuilder.append("WHERE billMsgs.BILL_ID = :billID ");
		stringBuilder.append("AND billMsg.BILL_MSG_CD = billMsgs.BILL_MSG_CD ");
		stringBuilder.append("AND billMsgLanguage.BILL_MSG_CD = billMsg.BILL_MSG_CD ");
		stringBuilder.append("AND billMsgLanguage.LANGUAGE_CD = :lang ");
		stringBuilder.append("ORDER BY billMsg.MSG_PRIORITY_FLG ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getNextBillMsg=");
		prepState.bindId("billID", bill.getId());
		prepState.bindId("lang", lang.getId());
		prepState.execute();
		prepState.setAutoclose(false); 
		returnValue = prepState.list().iterator();
		prepState.close();
		return returnValue;
	}
	
	private Iterator<SQLResultRow> getMsgParms(Bill bill, BillMessageType_Id billMessageTypeID) {
		
		Iterator<SQLResultRow> returnValue = null;
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   SEQ_NUM, ");
		stringBuilder.append("   MSG_PARM_VAL ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_BILL_MSG_PRM ");
		stringBuilder.append("WHERE BILL_ID = :billID ");
		stringBuilder.append("AND BILL_MSG_CD = :billMsgCd ");
		stringBuilder.append("ORDER BY SEQ_NUM ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getMsgParms=");
		prepState.bindId("billID", bill.getId());
		prepState.bindId("billMsgCd", billMessageTypeID);
		prepState.execute();
		prepState.setAutoclose(false);
		returnValue = prepState.list().iterator();
		prepState.close();
		return returnValue;		
	}
	
	private Iterator<SQLResultRow> getBsegs(Bill bill) {
	
		Iterator<SQLResultRow> returnValue = null;
		StringBuilder stringBuilder = new StringBuilder();
		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    BS.BSEG_ID, ");
		stringBuilder.append("    BS.BILL_ID, ");
		stringBuilder.append("    BS.SA_ID, ");
		stringBuilder.append("    BS.START_DT, ");
		stringBuilder.append("    BS.END_DT, ");
		stringBuilder.append("    BS.BILL_CYC_CD, ");
		stringBuilder.append("    BS.WIN_START_DT, ");
		stringBuilder.append("    BS.EST_SW, ");
		stringBuilder.append("    BS.CLOSING_BSEG_SW, ");
		stringBuilder.append("    BS.SQ_OVERRIDE_SW, ");
		stringBuilder.append("    BS.ITEM_OVERRIDE_SW, ");
		stringBuilder.append("    BS.PREM_ID, ");
		stringBuilder.append("    BS.CAN_BSEG_ID, ");
		stringBuilder.append("    BS.REBILL_SEG_ID, ");
		stringBuilder.append("    BS.BSEG_STAT_FLG, ");
		stringBuilder.append("    BS.CRE_DTTM, ");
		stringBuilder.append("    BS.STAT_CHG_DTTM, ");
		stringBuilder.append("    BS.CAN_RSN_CD, ");
		stringBuilder.append("    TY.BILL_PRT_PRIO_FLG ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_BSEG BS, ");
		stringBuilder.append("    CI_SA SA, ");
		stringBuilder.append("    CI_SA_TYPE TY ");
		stringBuilder.append("WHERE BS.BILL_ID = :billID ");
		stringBuilder.append("AND SA.SA_ID = BS.SA_ID ");
		stringBuilder.append("AND TY.CIS_DIVISION = SA.CIS_DIVISION ");
		stringBuilder.append("AND TY.SA_TYPE_CD = SA.SA_TYPE_CD ");
		stringBuilder.append("AND EXISTS (SELECT FT.FT_ID ");
		stringBuilder.append("            FROM CI_FT FT ");
		stringBuilder.append("            WHERE FT.BILL_ID = :billID ");
		stringBuilder.append("            AND FT.SA_ID = BS.SA_ID ");
		stringBuilder.append("            AND FT.SIBLING_ID = BS.BSEG_ID ");
		stringBuilder.append("            AND FT.FT_TYPE_FLG IN ('BS', 'BX') ");
		stringBuilder.append("            AND FT.SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("			) ");
		stringBuilder.append("ORDER BY BS.PREM_ID, TY.BILL_PRT_PRIO_FLG, SA.SA_ID, BS.START_DT ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getBsegs=");
		prepState.bindId("billID", bill.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		returnValue = prepState.list().iterator();
		prepState.close();
		return returnValue;
	}
	
	private Iterator<SQLResultRow> getAdjSa(Bill bill, ServiceAgreement_Id saID) {
		
		Iterator<SQLResultRow> returnValue = null;
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("   FT.ARS_DT, ");
		stringBuilder.append("   FT.FT_TYPE_FLG, ");
		stringBuilder.append("   FT.SIBLING_ID, ");
		stringBuilder.append("   FT.CURRENCY_CD, ");
		stringBuilder.append("   NVL(SUM(FT.CUR_AMT), 0) SUM_CUR_AMT, ");
		stringBuilder.append("   NVL(SUM(FT.TOT_AMT), 0) SUM_TOT_AMT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("   CI_FT FT ");
		stringBuilder.append("WHERE FT.BILL_ID = :billID ");
		stringBuilder.append("AND FT.SA_ID = :saID ");
		stringBuilder.append("AND FT.SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("AND FT.FT_TYPE_FLG IN ('AD', 'AX') ");
		stringBuilder.append("GROUP BY FT.ARS_DT, ");
		stringBuilder.append("         FT.FT_TYPE_FLG, ");
		stringBuilder.append("		 FT.SIBLING_ID, ");
		stringBuilder.append("		 FT.CURRENCY_CD ");
		stringBuilder.append("ORDER BY FT.ARS_DT, ");
		stringBuilder.append("         FT.FT_TYPE_FLG, ");
		stringBuilder.append("		 FT.SIBLING_ID, ");
		stringBuilder.append("		 FT.CURRENCY_CD ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getAdjSa=");
		prepState.bindId("billID", bill.getId());
		prepState.bindId("saID", saID);
		prepState.execute();
		prepState.setAutoclose(false);
		returnValue = prepState.list().iterator();
		prepState.close();
		return returnValue;
	}
	
	private Bool premiseCheck(Bill bill, Premise_Id premID) {
		
		Bool returnValue = Bool.FALSE;
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT 'X' ");
		stringBuilder.append("FROM CI_BSEG ");
		stringBuilder.append("WHERE BILL_ID = :billID ");
		stringBuilder.append("AND PREM_ID = :premID ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=premiseCheck=");
		prepState.bindId("billID", bill.getId());
		prepState.bindId("premID", premID);
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			returnValue = Bool.TRUE;
		}
		prepState.close();
		return returnValue;
	}
	
	private void getSa(ServiceAgreement_Id saID) {
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    SA.SA_ID, ");
		stringBuilder.append("    SA.CIS_DIVISION, ");
		stringBuilder.append("    SA.SA_TYPE_CD, ");
		stringBuilder.append("    SA.SA_STATUS_FLG, ");
		stringBuilder.append("    SA.ACCT_ID, ");
		stringBuilder.append("    SA.START_DT, ");
		stringBuilder.append("    SA.END_DT, ");
		stringBuilder.append("    SA.OLD_ACCT_ID, ");
		stringBuilder.append("    SA.ALLOW_EST_SW, ");
		stringBuilder.append("    SA.CUST_READ_FLG, ");
		stringBuilder.append("    SA.SIC_CD, ");
		stringBuilder.append("    SA.CHAR_PREM_ID, ");
		stringBuilder.append("    SA.START_OPT_CD, ");
		stringBuilder.append("    SA.TOT_TO_BILL_AMT, ");
		stringBuilder.append("    SA.CURRENCY_CD, ");
	    stringBuilder.append("    SA.SA_REL_ID, ");
	    stringBuilder.append("    STL.DESCR, ");
	    stringBuilder.append("    STL.DFLT_DESCR_ON_BILL, ");
	    stringBuilder.append("    ST.REV_CL_CD, ");
	    stringBuilder.append("    ST.BILL_PRT_PRIO_FLG, ");
	    stringBuilder.append("    ST.GRAPH_UOM_CD, ");
	    stringBuilder.append("    ST.SVC_TYPE_CD, ");
	    stringBuilder.append("    ST.SPECIAL_ROLE_FLG, ");
	    stringBuilder.append("    SVL.DESCR SVLDESCR, ");
	    stringBuilder.append("    REVCLL.DESCR REVCLLDESCR ");
	    stringBuilder.append("FROM ");
	    stringBuilder.append("    CI_SA SA, ");
	    stringBuilder.append("    CI_SA_TYPE ST, ");
	    stringBuilder.append("    CI_SA_TYPE_L STL, ");
	    stringBuilder.append("    CI_SVC_TYPE_L SVL, ");
	    stringBuilder.append("    CI_REV_CL_L REVCLL ");
	    stringBuilder.append("WHERE SA.SA_ID = :saID ");
	    stringBuilder.append("AND ST.CIS_DIVISION = SA.CIS_DIVISION "); 
	    stringBuilder.append("AND ST.SA_TYPE_CD = SA.SA_TYPE_CD ");
	    stringBuilder.append("AND STL.CIS_DIVISION = ST.CIS_DIVISION ");
	    stringBuilder.append("AND STL.SA_TYPE_CD = ST.SA_TYPE_CD ");
	    stringBuilder.append("AND STL.LANGUAGE_CD = :langID ");
	    stringBuilder.append("AND SVL.SVC_TYPE_CD = ST.SVC_TYPE_CD ");
	    stringBuilder.append("AND SVL.LANGUAGE_CD = :langID ");
	    stringBuilder.append("AND REVCLL.REV_CL_CD (+) = ST.REV_CL_CD ");
	    stringBuilder.append("AND REVCLL.LANGUAGE_CD (+) = :langID ");
	    PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getSa=");
	    prepState.bindId("saID", saID);
	    prepState.bindId("langID", this.getActiveContextLanguage().getId());
	    prepState.execute();
	    prepState.setAutoclose(false);
	    if (notNull(prepState.firstRow())) {
	    	SQLResultRow sqlRow = prepState.firstRow();	    	
	    	wS_SA_OUT_DATA_SaID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
	    	wS_SA_OUT_DATA_CisDivID = (CisDivision_Id) sqlRow.getId("CIS_DIVISION", CisDivision.class); 
	    	wS_SA_OUT_DATA_SATypeCd = sqlRow.getString("SA_TYPE_CD");
	    	wS_SA_OUT_DATA_saStatusFlg = sqlRow.getLookup("SA_STATUS_FLG", ServiceAgreementStatusLookup.class);
	    	wS_SA_OUT_DATA_acctID =(Account_Id) sqlRow.getId("ACCT_ID", Account.class);
	    	wS_SA_OUT_DATA_startDt = sqlRow.getDate("START_DT");
	    	wS_SA_OUT_DATA_endDt = sqlRow.getDate("END_DT");
	    	wS_SA_OUT_DATA_oldAcctID = sqlRow.getString("OLD_ACCT_ID");
	    	wS_SA_OUT_DATA_allowEstSw = sqlRow.getBoolean("ALLOW_EST_SW");
	    	wS_SA_OUT_DATA_custReadFlg = sqlRow.getLookup("CUST_READ_FLG", CustomerReadLookup.class);
	    	wS_SA_OUT_DATA_sicCodeID = (SicCode_Id) sqlRow.getId("SIC_CD", SicCode.class); 
	    	wS_SA_OUT_DATA_charPremID = (Premise_Id) sqlRow.getId("CHAR_PREM_ID", Premise.class); 
	    	wS_SA_OUT_DATA_startOptCd = sqlRow.getString("START_OPT_CD");
	    	BigDecimal totToBillAmtBD = sqlRow.getBigDecimal("TOT_TO_BILL_AMT");
	    	wS_SA_OUT_DATA_currencyCd = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
	    	wS_SA_OUT_DATA_totToBillAmt = new Money(totToBillAmtBD, wS_SA_OUT_DATA_currencyCd);	    	
	    	wS_SA_OUT_DATA_saRelID = (ServiceAgreementRelationship_Id) sqlRow.getId("SA_REL_ID", ServiceAgreementRelationship.class); 
	    	wS_SA_OUT_DATA_descr = sqlRow.getString("DESCR");
	    	wS_SA_OUT_DATA_dfltDescrOnBill = sqlRow.getString("DFLT_DESCR_ON_BILL");
	    	wS_SA_OUT_DATA_revClCd = (RevenueClass_Id) sqlRow.getId("REV_CL_CD", RevenueClass.class);
	    	wS_SA_OUT_DATA_billPrtPrioFlg = sqlRow.getLookup("BILL_PRT_PRIO_FLG", BillPrintPriorityLookup.class);
	    	wS_SA_OUT_DATA_GraphUomCd = (UnitOfMeasure_Id) sqlRow.getId("GRAPH_UOM_CD", UnitOfMeasure.class);
	    	wS_SA_OUT_DATA_svcTypeCd = (ServiceType_Id) sqlRow.getId("SVC_TYPE_CD", ServiceType.class); 
	    	wS_SA_OUT_DATA_specialRoleFlg = sqlRow.getLookup("SPECIAL_ROLE_FLG", SpecialRoleLookup.class);
	    	wS_SA_OUT_DATA_svcTypeDescr = sqlRow.getString("SVLDESCR");
	    	wS_SA_OUT_DATA_revClDescr = sqlRow.getString("REVCLLDESCR");
	    }
	    prepState.close();
	}
	
	private void getSARel(ServiceAgreementRelationship_Id saRelID) {
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    SAR.SA_REL_ID, ");
		stringBuilder.append("    SAR.SA_ID, ");
		stringBuilder.append("    SAR.SA_REL_TYPE_CD, ");
		stringBuilder.append("    SAR.SA_EXT_REF_ID, ");
		stringBuilder.append("    SAR.SA_REL_STATUS_FLG, ");
		stringBuilder.append("    SAR.SPR_CD, ");
		stringBuilder.append("    SRL.DESCR, ");
		stringBuilder.append("    SPL.DESCR50, ");
		stringBuilder.append("    SPR.SA_ID SPRSAID, ");
		stringBuilder.append("    SPR.NT_XID_CD, ");
		stringBuilder.append("    SPR.BILL_REL_FLG, ");
		stringBuilder.append("    SPR.PER_ID, ");
		stringBuilder.append("    PN.ENTITY_NAME ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_SA_REL SAR, ");
		stringBuilder.append("    CI_SA_REL_TYPE_L SRL, ");
		stringBuilder.append("    CI_SPR SPR, ");
		stringBuilder.append("    CI_SPR_L SPL, ");
		stringBuilder.append("    CI_PER_NAME PN ");
		stringBuilder.append("WHERE SAR.SA_REL_ID = :saRelID ");
		stringBuilder.append("AND SRL.SA_REL_TYPE_CD = SAR.SA_REL_TYPE_CD ");
		stringBuilder.append("AND SRL.LANGUAGE_CD = :langID ");
		stringBuilder.append("AND SPL.SPR_CD = SAR.SPR_CD ");
		stringBuilder.append("AND SPL.LANGUAGE_CD = :langID ");
		stringBuilder.append("AND SPR.SPR_CD = SAR.SPR_CD ");
		stringBuilder.append("AND PN.PER_ID = SPR.PER_ID ");
		stringBuilder.append("AND PN.PRIM_NAME_SW = 'Y' ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getSARel=");
		prepState.bindId("saRelID", saRelID);
		prepState.bindId("langID", this.getActiveContextLanguage().getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			wSAREL_OUT_DATA_saRelID = (ServiceAgreementRelationship_Id) sqlRow.getId("SA_REL_ID", ServiceAgreementRelationship.class);
			wSAREL_OUT_DATA_sarSaID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class );
			wSAREL_OUT_DATA_saRelTypeID = (ServiceAgreementRelationshipType_Id) sqlRow.getId("SA_REL_TYPE_CD", ServiceAgreementRelationshipType.class);
			wSAREL_OUT_DATA_saExtRefID = sqlRow.getString("SA_EXT_REF_ID");
			wSAREL_OUT_DATA_saRelStatusFlg = (ServiceAgreementRelationshipStatusLookup) sqlRow.getLookup("SA_REL_STATUS_FLG", ServiceAgreementRelationshipStatusLookup.class);
			wSAREL_OUT_DATA_sprCd = (ServiceProvider_Id) sqlRow.getId("SPR_CD", ServiceProvider.class);
			wSAREL_OUT_DATA_descr = sqlRow.getString("DESCR");
			wSAREL_OUT_DATA_descr50 = sqlRow.getString("DESCR50");
			wSAREL_OUT_DATA_sprSaID = (ServiceAgreement_Id) sqlRow.getId("SPRSAID", ServiceAgreement.class );
			wSAREL_OUT_DATA_ntXidCd = (NotificationExternalId_Id) sqlRow.getId("NT_XID_CD", NotificationExternalId.class );
			wSAREL_OUT_DATA_billRelFlg = (BillingRelationshipLookup) sqlRow.getLookup("BILL_REL_FLG", BillingRelationshipLookup.class);
			wSAREL_OUT_DATA_perID = (Person_Id) sqlRow.getId("PER_ID", Person.class);
			wSAREL_OUT_DATA_entityName = sqlRow.getString("ENTITY_NAME");
		}
		prepState.close();
	}
	
	private void getBsegSQ(BillSegment_Id bsegID, UnitOfMeasure_Id uomID,
			TimeOfUse_Id touID, ServiceQuantityIdentifier_Id sqiID) {
		
		wS_BSEGSQ_OUT_DATA_initSq = BigDecimal.ZERO;
		wS_BSEGSQ_OUT_DATA_billSq = BigDecimal.ZERO;
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    INIT_SQ, ");
		stringBuilder.append("    BILL_SQ ");
		stringBuilder.append("FROM "); 
		stringBuilder.append("    CI_BSEG_SQ ");
		stringBuilder.append("WHERE BSEG_ID = :bsegID ");		
		if (notNull(uomID)
				&& notNull(uomID.getEntity())) {
			stringBuilder.append("AND UOM_CD = '"+uomID.getTrimmedValue()+"' ");
			stringBuilder.append("AND TOU_CD = ' ' ");
			stringBuilder.append("AND SQI_CD = ' ' ");
		}
		else if (notNull(touID)
				&& notNull(touID.getEntity())) {
			stringBuilder.append("AND UOM_CD = ' ' ");
			stringBuilder.append("AND TOU_CD = '"+touID.getTrimmedValue()+"' ");
			stringBuilder.append("AND SQI_CD = ' ' ");
		}
		else if (notNull(sqiID)
				&& notNull(sqiID.getEntity())) {
			stringBuilder.append("AND UOM_CD = ' ' ");
			stringBuilder.append("AND TOU_CD = ' ' ");
			stringBuilder.append("AND SQI_CD = '"+sqiID.getTrimmedValue()+"' ");
		}
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getBsegSQ=");
		prepState.bindId("bsegID", bsegID);		
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			wS_BSEGSQ_OUT_DATA_initSq = (BigDecimal) sqlRow.getBigDecimal("INIT_SQ");
			wS_BSEGSQ_OUT_DATA_billSq = (BigDecimal) sqlRow.getBigDecimal("BILL_SQ");
		}
		prepState.close();		
	}
	
	private void getReadDtl(RegisterRead_Id endRegReadingID) {
		
		// Initialize Output
		wS_READDTL_OUT_DATA_readTypeFlg = null;
		wS_READDTL_OUT_DATA_badgeNbr = " ";
		wS_READDTL_OUT_DATA_serialNbr = " ";
		wS_READDTL_OUT_DATA_consumSubFlg = null;
		wS_READDTL_OUT_DATA_nbrOfDgtsRgt = BigInteger.ZERO;
		wS_READDTL_OUT_DATA_regId = null;
		wS_READDTL_OUT_DATA_nbrOfDgtsLft = BigInteger.ZERO;
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    RR.READ_TYPE_FLG, ");
		stringBuilder.append("    MT.BADGE_NBR, ");
		stringBuilder.append("    MT.SERIAL_NBR, ");
		stringBuilder.append("    RG.CONSUM_SUB_FLG, ");
		stringBuilder.append("    RG.NBR_OF_DGTS_RGT, ");
		stringBuilder.append("    RG.REG_ID, ");
		stringBuilder.append("    RG.NBR_OF_DGTS_LFT ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_REG_READ RR, ");
		stringBuilder.append("    CI_REG RG, ");
		stringBuilder.append("    CI_MTR MT ");
		stringBuilder.append("WHERE RR.REG_READ_ID = :regReadID ");
		stringBuilder.append("AND RG.REG_ID = RR.REG_ID ");
		stringBuilder.append("AND MT.MTR_ID = RG.MTR_ID ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getReadDtl=");
		prepState.bindId("regReadID", endRegReadingID);
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			wS_READDTL_OUT_DATA_readTypeFlg = (ReadTypeLookup) sqlRow.getLookup("READ_TYPE_FLG", ReadTypeLookup.class);
			wS_READDTL_OUT_DATA_badgeNbr = sqlRow.getString("BADGE_NBR");
			wS_READDTL_OUT_DATA_serialNbr = sqlRow.getString("SERIAL_NBR");
			wS_READDTL_OUT_DATA_consumSubFlg = (ConsumptionTypeLookup) sqlRow.getLookup("CONSUM_SUB_FLG", ConsumptionTypeLookup.class);
			wS_READDTL_OUT_DATA_nbrOfDgtsRgt = sqlRow.getInteger("NBR_OF_DGTS_RGT");
			wS_READDTL_OUT_DATA_regId = (Register_Id) sqlRow.getId("REG_ID", Register.class);
			wS_READDTL_OUT_DATA_nbrOfDgtsLft = sqlRow.getInteger("NBR_OF_DGTS_LFT");
		}
		prepState.close();
	}
	
	private MeterReadSource_Id getMrSource(RegisterRead endRegRead) {
		
		MeterReadSource_Id returnValue = null;
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT ");
		stringBuilder.append("    MR.MR_SOURCE_CD ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_REG_READ REGREAD, ");
		stringBuilder.append("    CI_MR MR ");
		stringBuilder.append("WHERE REGREAD.REG_READ_ID = :regReadID ");
		stringBuilder.append("AND MR.MR_ID = REGREAD.MR_ID ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getMrSource=");
		prepState.bindId("regReadID", endRegRead.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			returnValue = (MeterReadSource_Id) sqlRow.getId("MR_SOURCE_CD", MeterReadSource.class);			
		}
		prepState.close();
		return returnValue;
	}
	
	private Iterator<SQLResultRow> getAdjOnly(Bill bill, Account account) {
		
		Iterator<SQLResultRow> returnValue = null;
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT DISTINCT ");
		stringBuilder.append("    SA.CHAR_PREM_ID, ");
		stringBuilder.append("    TY.BILL_PRT_PRIO_FLG, ");
		stringBuilder.append("    FT.SA_ID ");
		stringBuilder.append("FROM ");
		stringBuilder.append("    CI_FT FT, ");
		stringBuilder.append("    CI_SA SA, ");
		stringBuilder.append("    CI_SA_TYPE TY ");
		stringBuilder.append("WHERE FT.BILL_ID = :billID ");
		stringBuilder.append("AND FT.FT_TYPE_FLG IN ('AD','AX') ");
		stringBuilder.append("AND FT.SHOW_ON_BILL_SW = 'Y' ");
		stringBuilder.append("AND FT.SA_ID = SA.SA_ID ");
		stringBuilder.append("AND SA.ACCT_ID = :acctID ");
		stringBuilder.append("AND SA.CIS_DIVISION = TY.CIS_DIVISION ");
		stringBuilder.append("AND SA.SA_TYPE_CD = TY.SA_TYPE_CD ");
		stringBuilder.append("AND FT.SA_ID NOT IN (SELECT BS.SA_ID ");
		stringBuilder.append("                     FROM CI_BSEG BS ");
		stringBuilder.append("                     WHERE BS.BILL_ID = :billID ");
		stringBuilder.append("					 ) ");
		stringBuilder.append("ORDER BY SA.CHAR_PREM_ID, TY.BILL_PRT_PRIO_FLG, FT.SA_ID ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getAdjOnly=");
		prepState.bindId("billID", bill.getId());
		prepState.bindId("acctID", account.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		returnValue = prepState.list().iterator();
		prepState.close();
		return returnValue;
	}	
	
	private Iterator<BillSegmentRegisterRead> retrieveBsegRegReads(BillSegment billSegment) {
		
		Iterator<BillSegmentRegisterRead> returnValue = null;
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT BSEG_ID, SP_ID, SEQNO ");
		stringBuilder.append("FROM CI_BSEG_READ ");
		stringBuilder.append("WHERE BSEG_ID = :billSegmentID ");
		stringBuilder.append("ORDER BY SP_ID, SEQNO ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==retrieveBsegRegReads==");
		prepState.bindId("billSegmentID", billSegment.getId());
		prepState.execute();
		if (notNull(prepState.firstRow())) {
			List<BillSegmentRegisterRead> listOfBsegRegRead = new ArrayList<BillSegmentRegisterRead>();
			Iterator<SQLResultRow> collBsegRegRead = prepState.list().iterator();
			while (collBsegRegRead.hasNext()) {
				SQLResultRow sqlRow = collBsegRegRead.next();
				BillSegment_Id bsegID = (BillSegment_Id) sqlRow.getId("BSEG_ID", BillSegment.class);
				ServicePoint_Id spID = (ServicePoint_Id) sqlRow.getId("SP_ID", ServicePoint.class);
				BigInteger seqNo = (BigInteger) sqlRow.getInteger("SEQNO");
				BillSegmentRegisterRead_Id bsegRegReadID = new BillSegmentRegisterRead_Id(
						spID, bsegID, seqNo);
				listOfBsegRegRead.add(bsegRegReadID.getEntity());				
			}
			returnValue = listOfBsegRegRead.iterator();
		}		
		prepState.close();
		return returnValue;
	}

	// Start Add - DLampa - 2024-07-30 - INC0037039    
    private Bool checkNonSufficientIndicator() {
        Bool returnValue = Bool.FALSE;

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT PAY.PAY_ID ");
        stringBuilder.append("FROM CI_PAY PAY, ");
        stringBuilder.append("    CI_PAY_EVENT PEVT, ");
        stringBuilder.append("    CI_PAY_CAN_RSN PAYCR ");
        stringBuilder.append("WHERE PAY.ACCT_ID = :acctId ");
        stringBuilder.append("    AND PAY.CAN_RSN_CD = PAYCR.CAN_RSN_CD ");
        stringBuilder.append("    AND PAYCR.NSF_CHARGE_SW = 'Y' ");
        stringBuilder.append("    AND PAY.PAY_EVENT_ID = PEVT.PAY_EVENT_ID ");
        stringBuilder.append("    AND PEVT.PAY_DT > ADD_MONTHS(TRUNC(:billDate), -24) ");

        PreparedStatement prepStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        prepStatement.bindId("acctId", wAcct.getId());
        prepStatement.bindDate("billDate", wBillDt);
        prepStatement.execute();
        prepStatement.setAutoclose(false);

        if (prepStatement.list().size() > 2) {
            returnValue = Bool.TRUE;
        }

        prepStatement.close();
        return returnValue;
    }    
    // End Add - DLampa - 2024-07-30 - INC0037039
}
