/*******************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * Metering Exception Case - Auto-Transition New Exceptions
 *
 * This algorithm will check the Main Exception Code Case Characteristic value 
 * and the meter location code of the Service Point associated with the Case.  
 * It will determine the meter size (small/large) and whether a corrector exists 
 * on the meter, and then using this information will return the appropriate 
 * transition condition (to determine the next status). This algorithm will also 
 * check to see if there are any other open metering exception Cases associated 
 * with the Service Point. If others exist, this algorithm will return a 
 * transition condition for a review status what will create a To Do and 
 * require manual review by a Laclede resource.
 *
 ********************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-04-10   SMiranda        NI0007.5. Initial Version.
 * 2013-04-24   SMiranda        TIR2. The following parameters must be optional:
 *                              1. Transition Condition For Multiple Cases
 *                              2. Transition Condition For Multiregister 
 *                              Exceptions
 *                              3. Transition Condition For Meters With Correctors
 *                              4. Transition Condition For Large Meters
 * 2013-04-26   SMiranda        TIR3-TIR4. Auto-transition must trigger after the 
 *                              error has been corrected   
 * 2016-01-25   MPang			Updated for CCB v2.4 compilation.                          
 ********************************************************************************/
package com.splwg.cm.domain.admin.caseType;

import java.util.List;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.lookup.LookupField_Id;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;

//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseType;
import com.splwg.ccb.domain.admin.caseType.CaseTypeAutoTransitionAlgorithmSpot;
import com.splwg.ccb.domain.admin.itemType.ItemType;
import com.splwg.ccb.domain.admin.meterLocation.MeterLocation_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.Meter;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meter.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration_Id;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;*/

import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.caseType.algorithm.autoTransition.AutoTransitionAlgorithmSpot;
import com.splwg.ccb.domain.admin.itemType.entity.ItemType;
import com.splwg.ccb.domain.admin.meterLocation.entity.MeterLocation_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;

//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.cm.api.lookup.TransitionConditionLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author smiranda
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForMainExceptionCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForServicePointId, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = transitionConditionForMultipleCases, type = lookup)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = meterLocationFeatureConfigurationType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = itemType, name = itemTypeForCorrector, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForMeterSize, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, required = true, type = entity, name = exceptionCodeTransitionConditionFeatureConfigurationType)
 *            , @AlgorithmSoftParameter (required = true, type = string, name = exceptionCodeTransitionConditionFeatureConfigurationOptionType)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = transitionConditionForMultiregisterExceptions, type = lookup)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = transitionConditionForMetersWithCorrectors, type = lookup)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = transitionConditionForLargeMeters, type = lookup)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = featureConfigurationTypeForLargeMeterSize, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = featureConfigurationOptionTypeForLargeMeterSize, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = correctedExceptionCodeCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = uncorrectedExceptionCodeCharacteristicType, required = true, type = entity)})
 */
public class CmMeterExceptionCaseAutoTransNewExceptionAlgComp_Impl extends
        CmMeterExceptionCaseAutoTransNewExceptionAlgComp_Gen implements
      //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
      // CaseTypeAutoTransitionAlgorithmSpot {
        AutoTransitionAlgorithmSpot { 
     //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
    
    // Constants
    private final String _OPT_TYP_FLG = "_OPT_TYP_FLG";
    
    // Variables for Hard Parameters
    private ToDoCase toDoCase;
    private Bool shouldAutoTransition;
    private String nextTransitionCondition;
    
    // Variables for Soft Parameters
    private CharacteristicType characteristicTypeForMainExceptionCode,
            characteristicTypeForServicePointId,
            characteristicTypeForMeterSize,
            correctedExceptionCodeCharacteristicType,
            uncorrectedExceptionCodeCharacteristicType;
    private TransitionConditionLookup transitionConditionForMultipleCases, 
            transitionConditionForMultiregisterExceptions,
            transitionConditionForMetersWithCorrectors,
            transitionConditionForLargeMeters;
    private String exceptionCodeTransitionConditionFeatureConfigurationOptionType = "",
            featureConfigurationOptionTypeForLargeMeterSize = "";
    private FeatureConfiguration meterLocationFeatureConfigurationType,
            exceptionCodeTransitionConditionFeatureConfigurationType,
            featureConfigurationTypeForLargeMeterSize;
    private ItemType itemTypeForCorrector;
    
    // Other work variables
    private CaseType caseType;
    private String caseStatus = "",
            algCodeStr = "",
            servicePointIdStr = "",
            meterSize = "",
            insideOutside = "",
            mainExceptionCode = "";
    private SQLResultRow caseCharSQLResult = null,
            openCaseSQLResult = null,
            meterSQLResult = null,
            correctorSQLResult = null,
            meterSizeOptValSQLResult = null;
    private ServicePoint_Id servicePointId;
    private Meter_Id meterId;
    private MeterConfiguration_Id meterConfigId;
    private MeterLocation_Id meterLocationId;
    // TIR3-TIR4. Start Add
    private FrameworkSession session;
    // TIR3-TIR4. End Add
    
    public CaseStatus getNextCaseStatus() {

        return null;
    }

    public String getNextTransCondition() {

        return nextTransitionCondition;
    }

    public Bool getShouldAutoTransition() {

        return shouldAutoTransition;
    }

    public void setCase(ToDoCase arg0) {       
        toDoCase = arg0;
    }

    public void invoke() {     
        
        // TIR3-TIR4. Start Add
        session = (FrameworkSession) SessionHolder.getSession();
        // TIR3-TIR4. End Add
        
        // Set the following variables to FALSE
        shouldAutoTransition = Bool.FALSE;
        
        // Get Case Type
        caseType = toDoCase.getCaseStatus().fetchIdCaseType();
        
        // Get current Case status
        caseStatus = toDoCase.getCaseStatus().fetchIdStatus();
        
        // Validate transition condition soft parameters
        validateTransConditionParameters();
        
        // Get the Service Point from Case characteristics
        caseCharSQLResult = getCaseChar(characteristicTypeForServicePointId);
        if (isNull(caseCharSQLResult)){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            // TIR3-TIR4. Start Add
            //session.clear();
            // TIR3-TIR4. End Add
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_2_spIdCharMiss(
                    algCodeStr, 
                    characteristicTypeForServicePointId.getId().getIdValue().trim()));
        }
        servicePointIdStr = caseCharSQLResult.getString("CHARVAL");
        servicePointId = new ServicePoint_Id(servicePointIdStr);
        if (isNull(servicePointId.getEntity())){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            // TIR3-TIR4. Start Add
            //session.clear();
            // TIR3-TIR4. End Add
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_2_spIdInv(
                    algCodeStr, 
                    servicePointIdStr.trim()));
        }
        
        // TIR2. Start Change
        // Retrieve any metering exception case (in non-final status) for the same Service Point
        if (notNull(transitionConditionForMultipleCases)){
            openCaseSQLResult = getOpenCase(servicePointId);        
            if (notNull(openCaseSQLResult)){
                // If any are found, return the transition condition for multiple cases and exit processing.
                shouldAutoTransition = Bool.TRUE;
                nextTransitionCondition = transitionConditionForMultipleCases.getLookupValue().fetchIdFieldValue().trim();
                return;
            }
        }
        // TIR2. End Change
        
        // TIR2. Start Change
        // Determine whether the Corrected Exception Code Characteristic and the Uncorrected Exception Code Characteristic both exist.
        if (notNull(transitionConditionForMultiregisterExceptions)){
            caseCharSQLResult = getCaseChar(correctedExceptionCodeCharacteristicType);
            if (notNull(caseCharSQLResult)){
                caseCharSQLResult = getCaseChar(uncorrectedExceptionCodeCharacteristicType);
                if (notNull(caseCharSQLResult)){
                    // If they both exist, return the transition condition for multi-register exceptions and exit processing.
                    shouldAutoTransition = Bool.TRUE;
                    nextTransitionCondition = transitionConditionForMultiregisterExceptions.getLookupValue().fetchIdFieldValue().trim();
                    return;
                }
            }
        }
        // TIR2. End Change
        
        // TIR2. Start Change
        // Get meter currently installed at the Service Point
        if (notNull(transitionConditionForMetersWithCorrectors) || notNull(transitionConditionForLargeMeters)){
            meterSQLResult = getMeter(servicePointId);
            if (isNull(meterSQLResult)){
            	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                // TIR3-TIR4. Start Add
                //session.clear();
                // TIR3-TIR4. End Add
            	session.clear(session.toString().trim());
                //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                addError(CustomMessageRepositoryMDC.NI0007_5_2_spNoMeter(
                        algCodeStr, 
                        servicePointId.getIdValue().trim()));
            }
            meterId = (Meter_Id)meterSQLResult.getId("MTR", Meter.class);                
            meterConfigId = (MeterConfiguration_Id)meterSQLResult.getId("MCFG", MeterConfiguration.class);
        
            if (isNull(meterId.getEntity())){
            	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                // TIR3-TIR4. Start Add
                //session.clear();
                // TIR3-TIR4. End Add
            	session.clear(session.toString().trim());
                //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                addError(CustomMessageRepositoryMDC.NI0007_5_2_mtrIdInv(
                        algCodeStr, 
                        meterId.getIdValue().trim(),
                        meterConfigId.getIdValue().trim()));
            }                
        
            // Determine whether corrector is installed on the current meter
            if (notNull(transitionConditionForMetersWithCorrectors)){
                correctorSQLResult = getCorrector(meterId);
                if (notNull(correctorSQLResult)){
                    // If a corrector is installed, return the transition condition for meters with correctors and exit processing.
                    shouldAutoTransition = Bool.TRUE;
                    nextTransitionCondition = transitionConditionForMetersWithCorrectors.getLookupValue().fetchIdFieldValue().trim();
                    return;
                }
            }
        
            // Retrieve value of the Meter Size Characteristic
            if (notNull(transitionConditionForLargeMeters)){
                meterSize = getMeterChar(characteristicTypeForMeterSize);
                if (meterSize == ""){       
                	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                    // TIR3-TIR4. Start Add
                    //session.clear();
                    // TIR3-TIR4. End Add
                	session.clear(session.toString().trim());
                    //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                    addError(CustomMessageRepositoryMDC.NI0007_5_2_noMeterSize(
                            algCodeStr, 
                            meterId.getIdValue().trim()));
                }
        
                // Determine whether the Meter Size Characteristic Value is included in the Feature Configuration list of Large Meter Sizes.
                meterSizeOptValSQLResult = getMeterSizeOptVal(meterSize);        
                if (notNull(meterSizeOptValSQLResult)){
                    /* If the Characteristic Value is included in the Feature Configuration, return the transition condition for large meters
                    and exit processing. */
                    shouldAutoTransition = Bool.TRUE;
                    nextTransitionCondition = transitionConditionForLargeMeters.getLookupValue().fetchIdFieldValue().trim();
                    return;            
                }
            }
        }
        
        // Get the SP's Meter Location Code
        meterLocationId = servicePointId.getEntity().getMeterLocationId();
        if (isNull(meterLocationId)){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            // TIR3-TIR4. Start Add
            //session.clear();
            // TIR3-TIR4. End Add
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_2_noMeterLoc(
                    algCodeStr, 
                    servicePointId.getIdValue().trim()));
        }
        
        // Determine whether the meter location corresponds to inside or outside
        insideOutside = getMeterLocationRef(meterLocationId);
        
        // Get Main Exception Code characteristic
        caseCharSQLResult = getCaseChar(characteristicTypeForMainExceptionCode);
        if (isNull(caseCharSQLResult)){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            // TIR3-TIR4. Start Add
            //session.clear();
            // TIR3-TIR4. End Add
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_2_mainExcCharMiss(
                    algCodeStr, 
                    characteristicTypeForMainExceptionCode.getId().getIdValue().trim()));
        }
        mainExceptionCode = caseCharSQLResult.getString("CHARVAL");
        
        // Using the Main Exception Code and Inside/Outside, find the corresponding Transition Condition.
        shouldAutoTransition = Bool.TRUE;
        nextTransitionCondition = getMainTransitionCondition(mainExceptionCode, insideOutside);                
        
    }

    private void validateTransConditionParameters() {
        // TIR2. Start Change
        // Transition Condition for Multiple Cases        
        if (notNull(transitionConditionForMultipleCases)){
            validateTransCondition(transitionConditionForMultipleCases, 
                    "Transition Condition for Multiple Cases");
        }
        
        // Transition Condition for Multi-register Exceptions
        if (notNull(transitionConditionForMultiregisterExceptions)){
            validateTransCondition(transitionConditionForMultiregisterExceptions, 
                    "Transition Condition for Multi-register Exceptions");
        }
        
        // Transition Condition for Meters With Correctors
        if (notNull(transitionConditionForMetersWithCorrectors)){
            validateTransCondition(transitionConditionForMetersWithCorrectors, 
                    "Transition Condition for Meters With Correctors");
        }
        
        // Transition Condition for Large Meters
        if (notNull(transitionConditionForLargeMeters)){
            validateTransCondition(transitionConditionForLargeMeters, 
                    "Transition Condition for Large Meters");
        }
        // TIR2. End Change
    }      

    private void validateTransCondition(TransitionConditionLookup transCondition, String parmDescr) {
        
        PreparedStatement checkTransCondition
                = createPreparedStatement(
                        "SELECT " +
                            "TR.NEXT_STATUS_CD " +
                        "FROM " +
                            "CI_CASE_TR_RULE TR " +
                        "WHERE " +
                            "TR.CASE_TYPE_CD = :caseTypeCd " +
                            "AND TR.CASE_STATUS_CD = :caseStatusCd " +
                            //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                            //"AND TR.TR_COND_FLG = :transitionCondition"); 
                			"AND TR.TR_COND_FLG = :transitionCondition", getClass().getName());
        					//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        
        checkTransCondition.bindId("caseTypeCd", caseType.getId());
        checkTransCondition.bindString("caseStatusCd", caseStatus, "CASE_STATUS_CD");
        checkTransCondition.bindString("transitionCondition", transCondition.getLookupValue().fetchIdFieldValue().trim(), "TR_COND_FLG");
        
        if (checkTransCondition.list().size() == 0){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            // TIR3-TIR4. Start Add
            //session.clear();
            // TIR3-TIR4. End Add
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_2_transCondInv(
                    algCodeStr, 
                    parmDescr, 
                    transCondition.getLookupValue().fetchIdFieldValue().trim(), 
                    caseStatus.trim()));
        }        
        
    }
    
    private SQLResultRow getCaseChar(CharacteristicType charType){
        
        SQLResultRow caseCharSQLResult = null;        
        String charVal = "";
        
        if (charType.getCharacteristicType().isPredefinedValue()){
            charVal = "CACH.CHAR_VAL ";
        }        
        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            charVal = "CACH.ADHOC_CHAR_VAL ";
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            charVal = "CACH.CHAR_VAL_FK1 ";
        }
        
        PreparedStatement getCaseChar 
                = createPreparedStatement(
                        "SELECT " +
                            charVal + "AS CHARVAL, " +
                            "CACH.SEQ_NUM AS SEQNUM " +
                        "FROM " +
                            "CI_CASE_CHAR CACH " +
                        "WHERE " +
                            "CACH.CASE_ID = :caseId " +
                            "AND CACH.CHAR_TYPE_CD = :charTypeCd " +
                            "AND CACH.SEQ_NUM = (SELECT MAX(CACH2.SEQ_NUM) " +
                                                "FROM CI_CASE_CHAR CACH2 " +
                                                "WHERE CACH2.CASE_ID = CACH.CASE_ID " +
                                                //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                                                //"AND CACH2.CHAR_TYPE_CD = CACH.CHAR_TYPE_CD)");
                								"AND CACH2.CHAR_TYPE_CD = CACH.CHAR_TYPE_CD)", getClass().getName());
        										//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        
        getCaseChar.bindId("caseId", toDoCase.getId());
        getCaseChar.bindId("charTypeCd", charType.getId());
        caseCharSQLResult = getCaseChar.firstRow();                        
        
        return caseCharSQLResult;
    }
    
    private SQLResultRow getOpenCase(ServicePoint_Id servicePointId) {
        
        SQLResultRow openCaseSQLResult = null;  
        
        PreparedStatement getOpenCase 
                = createPreparedStatement(
                        "SELECT " +
                            "CA.CASE_ID " +
                        "FROM " +
                            "CI_CASE_CHAR CACH, " +
                            "CI_CASE CA " +
                        "WHERE " +
                            "CACH.CHAR_TYPE_CD = :charTypeCd " +
                            "AND (CACH.CHAR_VAL = :spId " + 
                                "OR CACH.ADHOC_CHAR_VAL = :spId " + 
                                "OR CACH.CHAR_VAL_FK1 = :spId) " +
                            "AND CACH.SEQ_NUM = (SELECT MAX(CACH2.SEQ_NUM) " +
                                                 "FROM CI_CASE_CHAR CACH2 " +      
                                                 "WHERE CACH2.CASE_ID = CACH.CASE_ID " +
                                                 "AND CACH2.CHAR_TYPE_CD = CACH.CHAR_TYPE_CD) " +
                            "AND CA.CASE_ID = CACH.CASE_ID " +
                            "AND CA.CASE_ID <> :caseId " +
                            "AND CA.CASE_TYPE_CD = :caseTypeCd " +
                            //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                            //"AND CA.CASE_COND_FLG = :caseCondFlag");
                			"AND CA.CASE_COND_FLG = :caseCondFlag", getClass().getName());
        					//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        
        getOpenCase.bindId("charTypeCd", characteristicTypeForServicePointId.getId());
        getOpenCase.bindString("spId", servicePointId.getIdValue().trim(), "CACH.CHAR_VAL");
        getOpenCase.bindString("spId", servicePointId.getIdValue().trim(), "CACH.ADHOC_CHAR_VAL");
        getOpenCase.bindString("spId", servicePointId.getIdValue().trim(), "CACH.CHAR_VAL_FK1");
        getOpenCase.bindId("caseId", toDoCase.getId());
        getOpenCase.bindId("caseTypeCd", caseType.getId());
        getOpenCase.bindLookup("caseCondFlag", CaseConditionLookup.constants.OPEN);
        
        openCaseSQLResult = getOpenCase.firstRow();
        
        return openCaseSQLResult;
    }
    
    private SQLResultRow getMeter(ServicePoint_Id servicePointId) {

        SQLResultRow meterSQLResult = null;
        
        PreparedStatement getMeter 
                = createPreparedStatement(
                        "SELECT " +
                            "MC.MTR_CONFIG_ID AS MCFG, " +
                            "MC.MTR_ID AS MTR " +
                        "FROM " +
                            "CI_SP_MTR_HIST SPMH, " +
                            "CI_MTR_CONFIG MC " +
                        "WHERE " +
                            "SPMH.SP_ID = :spId " +
                            "AND SPMH.REMOVAL_MR_ID = ' '" +
                            "AND SPMH.MTR_CONFIG_ID = MC.MTR_CONFIG_ID " +
                            //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                            //"AND TRUNC(MC.EFF_DTTM) <= :effDttm");
                			"AND TRUNC(MC.EFF_DTTM) <= :effDttm", getClass().getName());
        					//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        
        getMeter.bindId("spId", servicePointId);
        getMeter.bindDateTime("effDttm", this.getProcessDateTime());
        
        meterSQLResult = getMeter.firstRow();
        
        return meterSQLResult;
    }
    
    private SQLResultRow getCorrector(Meter_Id meterId) {
        
        SQLResultRow correctorSQLResult = null;
        
        PreparedStatement getCorrector 
                = createPreparedStatement(
                        "SELECT " +
                            "MEQ.MTR_ID " +
                        "FROM " + 
                            "CI_MTR_EQ MEQ, " +
                            "CI_ITEM ITM " +    
                        "WHERE " +
                            "MEQ.MTR_ID = :mtrId " +
                            // TIR2. Start Add
                            "AND MEQ.INSTALL_DT <= :installDate " +
                            // TIR2. End Add
                            "AND (MEQ.REMOVAL_DT IS NULL OR MEQ.REMOVAL_DT >= :removalDate) " +
                            "AND MEQ.ITEM_ID_EQ = ITM.ITEM_ID " +
                            //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                            //"AND ITM.ITEM_TYPE_CD = :itemTypeCd");
                			"AND ITM.ITEM_TYPE_CD = :itemTypeCd", getClass().getName());
        					//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        
        getCorrector.bindId("mtrId", meterId);
        getCorrector.bindDate("removalDate", this.getProcessDateTime().getDate());
        getCorrector.bindId("itemTypeCd", itemTypeForCorrector.getId());
        // TIR2. Start Add
        getCorrector.bindDate("installDate", this.getProcessDateTime().getDate());
        // TIR2. End Add
        
        correctorSQLResult = getCorrector.firstRow();
        
        return correctorSQLResult;
    }

    private String getMeterChar(CharacteristicType charType) {
        
        String charVal = "";
        
        MeterCharacteristic meterChar = meterId.getEntity().getEffectiveCharacteristic(charType);
        
        if (notNull(meterChar)){                     
            if (charType.getCharacteristicType().isAdhocValue())
                charVal = meterChar.getAdhocCharacteristicValue().trim();
            else if (charType.getCharacteristicType().isForeignKeyValue())
                charVal = meterChar.getCharacteristicValueForeignKey1().trim();
            else if (charType.getCharacteristicType().isPredefinedValue())
                charVal = meterChar.getCharacteristicValue().trim();
        }
        
        return charVal;
    }

    private SQLResultRow getMeterSizeOptVal(String meterSize) {

        SQLResultRow meterSizeOptValSQLResult = null;
        
        PreparedStatement getMeterSizeOptVal 
                = createPreparedStatement(
                        "SELECT " +
                            "OPT.WFM_OPT_VAL " +
                        "FROM " + 
                            "CI_WFM_OPT OPT " +    
                        "WHERE " +
                            "OPT.WFM_NAME = :wfmName " +
                            "AND OPT.EXT_OPT_TYPE = :optType " +
                            //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                            //"AND OPT.WFM_OPT_VAL = :optVal");
                			"AND OPT.WFM_OPT_VAL = :optVal", getClass().getName());
        					//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        
        getMeterSizeOptVal.bindId("wfmName", featureConfigurationTypeForLargeMeterSize.getId());
        getMeterSizeOptVal.bindString("optType", featureConfigurationOptionTypeForLargeMeterSize, "EXT_OPT_TYPE");
        getMeterSizeOptVal.bindString("optVal", meterSize, "WFM_OPT_VAL");               
        
        meterSizeOptValSQLResult = getMeterSizeOptVal.firstRow();  
        
        return meterSizeOptValSQLResult;
    }
    
    private String getMeterLocationRef(MeterLocation_Id meterLocationId) {

        String insideOutside = "";
        
        // Get Meter Location Cross Reference from Feature Configuration
        CmFeatureConfigurationRetriever fcOptRet = CmFeatureConfigurationRetriever.Factory.newInstance();
        fcOptRet.setParmWFMName(meterLocationFeatureConfigurationType);
        fcOptRet.setParmOptType(meterLocationId.getIdValue().trim());
        insideOutside = fcOptRet.getMaxSequenceOptionValue(); 
        
        if (insideOutside == ""){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            // TIR3-TIR4. Start Add
            //session.clear();
            // TIR3-TIR4. End Add
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_2_noCrossRef(
                    algCodeStr, 
                    meterLocationId.getIdValue().trim(),
                    meterLocationFeatureConfigurationType.getId().getIdValue().trim()));
        }
        
        return insideOutside;
    }
    
    private String getMainTransitionCondition(String mainExceptionCode, String insideOutside) {

        String mainTransCondition = "",
                optVal = "",
                transCondOptVal = "";
        String[] transCondArray;
        SQLResultRow transCondSQLResult = null;
        List<SQLResultRow> transCondList;
        
        optVal = mainExceptionCode.trim() + "," + insideOutside.trim() + ",";
        
        PreparedStatement getTransCond 
                = createPreparedStatement(
                        "SELECT " +
                            "OPT.WFM_OPT_VAL AS OPTVAL " +
                        "FROM " +
                            "CI_WFM_OPT OPT " +
                        "WHERE " +
                            "OPT.WFM_NAME = :wfmName " +
                            "AND OPT.EXT_OPT_TYPE = :optType " +
                            //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                            //"AND OPT.WFM_OPT_VAL LIKE :optVal");
                			"AND OPT.WFM_OPT_VAL LIKE :optVal", getClass().getName());
        					//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
       
        getTransCond.bindId("wfmName", exceptionCodeTransitionConditionFeatureConfigurationType.getId());
        getTransCond.bindString("optType", exceptionCodeTransitionConditionFeatureConfigurationOptionType, "EXT_OPT_TYPE");
        getTransCond.bindLikableString("optVal", optVal, "WFM_OPT_VAL"); 
        
        transCondList = getTransCond.list();
        
        // Raise error message if Main Exception Code and Inside/Outside combination has no entry in the Feature Configuration
        if (transCondList.size() == 0){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            // TIR3-TIR4. Start Add
            //session.clear();
            // TIR3-TIR4. End Add
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_2_noOptValFound(
                    algCodeStr, 
                    mainExceptionCode.trim(),
                    insideOutside.trim(),
                    exceptionCodeTransitionConditionFeatureConfigurationType.getId().getIdValue().trim()));
        }
        
        // Raise error message if Main Exception Code and Inside/Outside combiantion has mutliple entries in the Feature Configuration
        if (transCondList.size() > 1){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            // TIR3-TIR4. Start Add
            //session.clear();
            // TIR3-TIR4. End Add
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_2_multiOptValFound(
                    algCodeStr, 
                    mainExceptionCode.trim(),
                    insideOutside.trim(),
                    exceptionCodeTransitionConditionFeatureConfigurationType.getId().getIdValue().trim()));
        }
        
        // Retrieve option value if there is exactly one row retrieved
        transCondSQLResult = transCondList.get(0);
        transCondOptVal = transCondSQLResult.getString("OPTVAL");
        
        transCondArray = transCondOptVal.split(",");       
        
        try{
            mainTransCondition = transCondArray[2];
        }catch(ArrayIndexOutOfBoundsException e){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            // TIR3-TIR4. Start Add
            //session.clear();
            // TIR3-TIR4. End Add
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_2_noTransCondFound(
                    algCodeStr, 
                    mainExceptionCode.trim(),
                    insideOutside.trim(),
                    exceptionCodeTransitionConditionFeatureConfigurationType.getId().getIdValue().trim()));
        }
        
        return mainTransCondition;
        
    }
    
    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        
        // Get algorithm code
        algCodeStr = this.getAlgorithm().getId().getIdValue().trim();
        
        // Characteristic Type for Main Exception Code
        characteristicTypeForMainExceptionCode = this.getCharacteristicTypeForMainExceptionCode();
        validateChar(characteristicTypeForMainExceptionCode, 
                "Characteristic Type for Main Exception Code", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Service Point ID
        characteristicTypeForServicePointId = this.getCharacteristicTypeForServicePointId();
        validateChar(characteristicTypeForServicePointId, 
                "Characteristic Type for Service Point Id", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Transition Condition for Multiple Cases
        transitionConditionForMultipleCases = (TransitionConditionLookup) this.getTransitionConditionForMultipleCases();
        
        // Meter Location Feature Configuration Type
        meterLocationFeatureConfigurationType = this.getMeterLocationFeatureConfigurationType();
        
        // Item Type for Corrector
        itemTypeForCorrector = this.getItemTypeForCorrector();
        
        // Characteristic Type for Meter Size
        characteristicTypeForMeterSize = this.getCharacteristicTypeForMeterSize();
        validateChar(characteristicTypeForMeterSize, 
                "Characteristic Type for Meter Size", 
                CharacteristicEntityLookup.constants.METER);
        
        // Exception Code Transition Condition Feature Configuration Type
        exceptionCodeTransitionConditionFeatureConfigurationType 
                = this.getExceptionCodeTransitionConditionFeatureConfigurationType();
        
        // Exception Code Transition Condition Feature Configuration Option Type
        exceptionCodeTransitionConditionFeatureConfigurationOptionType 
                = this.getExceptionCodeTransitionConditionFeatureConfigurationOptionType();
        
        /* Exception Code Transition Condition Feature Configuration Option Type must be a valid option type 
        for Exception Code Transition Condition Feature Configuration Type */
        validateOptionType(exceptionCodeTransitionConditionFeatureConfigurationType,
                "Exception Code Transition Condition Feature Configuration Option Type",
                exceptionCodeTransitionConditionFeatureConfigurationOptionType);
        
        // Transition Condition for Multi-register Exceptions
        transitionConditionForMultiregisterExceptions = (TransitionConditionLookup)this.getTransitionConditionForMultiregisterExceptions();
        
        // Transition Condition for Meters With Correctors
        transitionConditionForMetersWithCorrectors = (TransitionConditionLookup)this.getTransitionConditionForMetersWithCorrectors();
        
        // Transition Condition for Large Meters
        transitionConditionForLargeMeters = (TransitionConditionLookup) this.getTransitionConditionForLargeMeters();
        
        // Feature Configuration Type for Large Meter Size
        featureConfigurationTypeForLargeMeterSize = this.getFeatureConfigurationTypeForLargeMeterSize();
        
        // Feature Configuration Option Type for Large Meter Size
        featureConfigurationOptionTypeForLargeMeterSize = this.getFeatureConfigurationOptionTypeForLargeMeterSize();
        
        /* Feature Configuration Option Type for Large Meter Size must be a valid option type 
        for Feature Configuration Type for Large Meter Size */
        validateOptionType(featureConfigurationTypeForLargeMeterSize,
                "Feature Configuration Option Type for Large Meter Size",
                featureConfigurationOptionTypeForLargeMeterSize);
        
        // Corrected Exception Code Characteristic Type
        correctedExceptionCodeCharacteristicType = this.getCorrectedExceptionCodeCharacteristicType();
        validateChar(correctedExceptionCodeCharacteristicType, 
                "Corrected Exception Code Characteristic Type", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Uncorrected Exception Code Characteristic Type
        uncorrectedExceptionCodeCharacteristicType = this.getUncorrectedExceptionCodeCharacteristicType();
        validateChar(uncorrectedExceptionCodeCharacteristicType, 
                "Uncorrected Exception Code Characteristic Type", 
                CharacteristicEntityLookup.constants.CASE);
        
    }

    private void validateChar(CharacteristicType charType, String parmDescr, CharacteristicEntityLookup entity) {

        CharacteristicEntity_Id charEntity_Id = new CharacteristicEntity_Id(charType, entity);
        if (isNull(charEntity_Id.getEntity())){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            // TIR3-TIR4. Start Add
            //session.clear();
            // TIR3-TIR4. End Add
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_2_charTypeInvForEntity(
                    algCodeStr, 
                    parmDescr, 
                    charType.getId().getIdValue().trim(), 
                    entity.getLookupValue().fetchLanguageDescription().trim()));
        }
    }
    
    private void validateOptionType(FeatureConfiguration wfmName, String parmDescr, String optType) {

        String extSysTypStr = wfmName.getFeatureType().getLookupValue().fetchIdFieldValue().trim();
        extSysTypStr = extSysTypStr.concat(_OPT_TYP_FLG);
        LookupField_Id lookupField_Id = new LookupField_Id(extSysTypStr);
        LookupValue_Id lookupValue_Id = new LookupValue_Id(lookupField_Id, optType.trim());
        if (isNull(lookupValue_Id.getEntity())){
        	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            // TIR3-TIR4. Start Add
            //session.clear();
            // TIR3-TIR4. End Add
        	session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_2_optTypeInvForWFM(
                    algCodeStr, 
                    parmDescr, 
                    optType.trim(), 
                    wfmName.getId().getIdValue().trim()));
        }
        
    }
        

}
