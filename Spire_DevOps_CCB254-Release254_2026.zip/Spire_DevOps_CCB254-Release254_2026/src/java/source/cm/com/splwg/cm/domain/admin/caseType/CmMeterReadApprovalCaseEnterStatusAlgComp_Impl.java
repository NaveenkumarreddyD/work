/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NU0030 - Meter Read Approvals
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-10-23   Srikanth        SD20131023 -Phase-2 -Case Creation 
 * 2013-12-03	Karthik			KL20131203 - Added a new parameter to set use on bill on 
 * 								Meter Read to true
 * 2013-12-11	Karthik			KL20131211 - IM-042506 - Parameter 'shouldSetUseOnBillFlg' 
 * 								has been set as a required parameter in the annotation.
 * 2016-01-26	AUmali	        Updated for CCB v2.4 compilation.
 ******************************************************************************************/
package com.splwg.cm.domain.admin.caseType;

import java.math.BigInteger;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
//Start Change: 2016-01-26 - AUmali - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseTypeEnterStatusAlgorithmSpot;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.MeterReadCharacteristic_DTO;
import com.splwg.ccb.domain.meterread.meterRead.MeterReadCharacteristic_Id;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead_DTO;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCaseCharacteristics;*/
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.algorithm.enterStatus.EnterStatusAlgorithmSpot;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterReadCharacteristic_DTO;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterReadCharacteristic_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_DTO;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCaseCharacteristics;
//End Change: 2016-01-26 - AUmali - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author sdesabhatl002
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = meterReadIdOnCaseTypeChar, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = meterReadApprovalCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = meterReadApprovalCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = shouldSetUseOnBillFlg, required = true, type = boolean)})
 */
public class CmMeterReadApprovalCaseEnterStatusAlgComp_Impl 
extends CmMeterReadApprovalCaseEnterStatusAlgComp_Gen 
//Start Change: 2016-01-26 - AUmali - Updated for CCB v2.4 compilation
//implements CaseTypeEnterStatusAlgorithmSpot {
implements EnterStatusAlgorithmSpot {
//End Change: 2016-01-26 - AUmali - Updated for CCB v2.4 compilation

	// Hard Parameter
	private ToDoCase currentCase;


	// Soft Parameters
	private String meterReadApprovalCharValue;    
	private CharacteristicType meterReadApprovalCharType;
	private CharacteristicType meterReadIdOnCaseTypeChar;
	// KL20131203 - Start of change - Added a new parameter to indicate setting use on bill on Meter Read to true.
	private Bool shouldSetUseOnBillFlg = Bool.FALSE;
	// KL20131203 - End of change

	public void invoke() {

		//initialize soft Params
		meterReadApprovalCharValue = getMeterReadApprovalCharValue();
		meterReadApprovalCharType = getMeterReadApprovalCharType();
		meterReadIdOnCaseTypeChar = getMeterReadIdOnCaseTypeChar();
		// KL20131203 - Start of change - Added a new parameter to indicate setting use on bill on Meter Read to true.
		shouldSetUseOnBillFlg = getShouldSetUseOnBillFlg();
		// KL20131203 - End of change

		//Validate Soft params

		CharacteristicEntity charEntity = new CharacteristicEntity_Id(meterReadApprovalCharType,CharacteristicEntityLookup.constants.METER_READ).getEntity();
		if(isNull(charEntity)){
			addError(CustomMessageRepository.nu0030CharTypeInvalidForMeterRead(meterReadApprovalCharType.getId().getIdValue()));
		}

		charEntity = new CharacteristicEntity_Id(meterReadIdOnCaseTypeChar,CharacteristicEntityLookup.constants.CASE).getEntity();
		if(isNull(charEntity)){
			addError(CustomMessageRepository.nu0030CharTypeInvalidForCase(meterReadIdOnCaseTypeChar.getId().getIdValue()));
		}

		CharacteristicValue_Id charValue = new CharacteristicValue_Id(meterReadApprovalCharType,meterReadApprovalCharValue);
		if(isNull(charValue.getEntity())){
			addError(CustomMessageRepository.nu0030invalidCharTypeForCharVal(meterReadApprovalCharType.getId().getIdValue(), meterReadApprovalCharValue));
		}

		CaseCharacteristic meterReadChar = null;
		ToDoCaseCharacteristics caseChars = currentCase.getCharacteristics();

		for (CaseCharacteristic caseChar : caseChars) {
			if (caseChar.fetchIdCharacteristicType().getId().getIdValue().trim().equals(
					meterReadIdOnCaseTypeChar.getId().getIdValue().trim())) {
				meterReadChar = caseChar;
				break;
			}
		}

		if(isNull(meterReadChar)){
			addError(CustomMessageRepository.nu0030MeterReadCharTypeNotExistsOnCase(meterReadIdOnCaseTypeChar.getId().getIdValue()));
		}

		MeterRead meterRead =  new MeterRead_Id(meterReadChar.getCharacteristicValueForeignKey1()).getEntity();
		if(isNull(meterRead)){
			addError(CustomMessageRepository.nu0030InvalidMeterReadOnCase(meterReadChar.getCharacteristicValueForeignKey1()));
		}

		// KL20131203 - Start of code change - Setting the Use On Bill flag on the Meter Read to true.
		if(shouldSetUseOnBillFlg.isTrue()){
			MeterRead_DTO meterReadDTO = meterRead.getDTO();
			meterReadDTO.setCanUseOnBill(Bool.TRUE);
			meterRead.setDTO(meterReadDTO);
		}
		// KL20131203 - End of code change

		addMtrReadCharacteristic(meterRead);
	}

	private void addMtrReadCharacteristic(MeterRead meterRead){
		CharacteristicTypeLookup charTypeLookup = meterReadApprovalCharType.getCharacteristicType();
		MeterReadCharacteristic_DTO mreadCharDTO = meterRead.getCharacteristics().newChildDTO();
		MeterReadCharacteristic_Id meterCharId = new MeterReadCharacteristic_Id(
				meterRead, meterReadApprovalCharType, (BigInteger.valueOf(meterRead.getCharacteristics().size()).multiply(BigInteger.TEN)).add(BigInteger.TEN));
		mreadCharDTO.setId(meterCharId);
		mreadCharDTO.setVersion(1);


		if(charTypeLookup.isAdhocValue()){
			mreadCharDTO.setAdhocCharacteristicValue(meterReadApprovalCharValue);
		} else if (charTypeLookup.isPredefinedValue()){
			mreadCharDTO.setCharacteristicValue(meterReadApprovalCharValue);
		} else if (charTypeLookup.isForeignKeyValue()){
			mreadCharDTO.setCharacteristicValueForeignKey1(meterReadApprovalCharValue);
		}
		meterRead.getCharacteristics().add(mreadCharDTO.newEntity());

	}


	public String getNextCaseStatus() {
		return null;
	}

	public String getNextTransCondition() {
		return null;
	}

	public Bool getShouldAutoTransition() {
		return null;
	}

	public void setCase(ToDoCase currentCase) {
		this.currentCase = currentCase;

	}

	public void setCaseOriginalStatus(CaseStatus arg0) {
	}

}
