/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Hyperion Extract Batch
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-07-22   CVB     Separated extract portion for Revenue Model.
 * 2013-08-21   MOHIT   Fixed as per IM-34989, Add sorting to extracted 
 *                      records.
 * 2013-09-16   JPunza  Modified the SA Count for monthly option.
 * 2013-11-12   JPunza  Modified the SA Count to not include FT with
 *                      multiple Revenue Rate Classes.
 * 2016-01-29  	MPang	Updated for CCB v2.4 compilation.                                           
 *************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Month;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.GeneralLedgerDistributionCodeCharacteristic;
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.GeneralLedgerDistributionEff;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.financial.financialTransaction.FinancialTransaction;*/

import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.entity.GeneralLedgerDistributionCodeCharacteristic;
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.entity.GeneralLedgerDistributionEff;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.api.batch.CmRevenueModelExtractRecord;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

// JPunza - 2013-09-16 - Start
///**
// * @author jpunzalan2
// *
// @BatchJob (multiThreaded = false, rerunnable = false, modules = {},
// *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
// *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
// *            , @BatchJobSoftParameter (name = DAILY_OR_MONTHLY_SW, required = true, type = string)})
// */
/**
 * @author jpunzalan2
 *
 @BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = DAILY_OR_MONTHLY_SW, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = REVENUE_RATE_CLASS_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = TRANS_SALES_COM_BASIC_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = TRANS_SALES_COM_FIRM_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = TRANS_SALES_IND_BASIC_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = TRANS_SALES_IND_FIRM_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = TRANSPORT_COM_BASIC_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = TRANSPORT_COM_FIRM_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = TRANSPORT_IND_BASIC_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = TRANSPORT_IND_FIRM_CHAR_VAL, required = true, type = string)})
 */
// JPunza - 2013-09-16 - End

public class CmHyperionExtractBatch
        extends CmHyperionExtractBatch_Gen {

    // Constant Variables
    private final static String FILE_PATH = "FILE_PATH";
    private final static String DAILY_OR_MONTHLY_SW = "DAILY_OR_MONTHLY_SW";
    private final static String DAILY = "D";
    private final static String MONTHLY = "M";
    // JPunza - 2013-09-16 - Start
    private final static String TRANS_SALES_COM_BASIC_CHAR_VAL = "TRANS_SALES_COM_BASIC_CHAR_VAL";
    private final static String TRANS_SALES_COM_FIRM_CHAR_VAL = "TRANS_SALES_COM_FIRM_CHAR_VAL";
    private final static String TRANS_SALES_IND_BASIC_CHAR_VAL = "TRANS_SALES_IND_BASIC_CHAR_VAL";
    private final static String TRANS_SALES_IND_FIRM_CHAR_VAL = "TRANS_SALES_IND_FIRM_CHAR_VAL";
    private final static String TRANSPORT_COM_BASIC_CHAR_VAL = "TRANSPORT_COM_BASIC_CHAR_VAL";
    private final static String TRANSPORT_COM_FIRM_CHAR_VAL = "TRANSPORT_COM_FIRM_CHAR_VAL";
    private final static String TRANSPORT_IND_BASIC_CHAR_VAL = "TRANSPORT_IND_BASIC_CHAR_VAL";
    private final static String TRANSPORT_IND_FIRM_CHAR_VAL = "TRANSPORT_IND_FIRM_CHAR_VAL";
    // JPunza - 2013-09-16 - End
    
    public JobWork getJobWork() {

        // Create Dummy Job Work
        List<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        arrayList.add(threadWorkUnit);
        return createJobWorkForThreadWorkUnitList(arrayList);
    }

    public Class<CmHyperionExtractBatchWorker> getThreadWorkerClass() {
        return CmHyperionExtractBatchWorker.class;    }

    @Override
    public void validateSoftParameters(boolean arg0) {

        JobParameters parameters = getParameters();

        // File Path
        String filePath = parameters.getFILE_PATH();

        if (validateFilePath(filePath).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0034_1_filePathInvalid(FILE_PATH, filePath));
        }

        // Daily Or Monthly Switch
        String dailyOrMonthlySwitch = parameters.getDAILY_OR_MONTHLY_SW();
        if (!(dailyOrMonthlySwitch.equalsIgnoreCase(DAILY) || dailyOrMonthlySwitch.equalsIgnoreCase(MONTHLY))) {
            addError(CustomMessageRepositoryMDC.NI0034_1_valueEitherMorD(DAILY_OR_MONTHLY_SW, dailyOrMonthlySwitch));
        }
        
        // JPunza - 2013-09-16 - Start
        CharacteristicType charType = parameters.getREVENUE_RATE_CLASS_CHAR_TYPE();                
        if (charType.getCharacteristicType().isPredefinedValue()) {

            // Transport Sales Commercial Basic Revenue Rate Class Characteristic Value
            String charValue = parameters.getTRANS_SALES_COM_BASIC_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANS_SALES_COM_BASIC_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Transport Sales Commercial Firm Revenue Rate Class Characteristic Value
            charValue = parameters.getTRANS_SALES_COM_FIRM_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANS_SALES_COM_FIRM_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Transport Sales Industrial Basic Revenue Rate Class Characteristic Value
            charValue = parameters.getTRANS_SALES_IND_BASIC_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANS_SALES_IND_BASIC_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Transport Sales Industrial Firm Revenue Rate Class Characteristic Value
            charValue = parameters.getTRANS_SALES_IND_FIRM_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANS_SALES_IND_FIRM_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Transportation Commercial Basic Revenue Rate Class Characteristic Value
            charValue = parameters.getTRANSPORT_COM_BASIC_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANSPORT_COM_BASIC_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Transportation Commercial Firm Revenue Rate Class Characteristic Value
            charValue = parameters.getTRANSPORT_COM_FIRM_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANSPORT_COM_FIRM_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Transportation Industrial Basic Revenue Rate Class Characteristic Value
            charValue = parameters.getTRANSPORT_IND_BASIC_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANSPORT_IND_BASIC_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }

            // Transportation Industrial Firm Revenue Rate Class Characteristic Value
            charValue = parameters.getTRANSPORT_IND_FIRM_CHAR_VAL();
            if (validateCharacteristicValue(charType, charValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0034_1_charValueInvalidForCharType(
                        TRANSPORT_IND_FIRM_CHAR_VAL, 
                        charValue, 
                        charType.getId().getTrimmedValue()));   
            }
        }
        // JPunza - 2013-09-16 - End
    }

    /**
     * This method validates file path.
     * @param filePath - String
     * @return Bool
     */
    private Bool validateFilePath(String filePath) {

        File folder = new File(filePath);

        if (folder.isDirectory()) {
            return Bool.TRUE;
        }
        return Bool.FALSE;
    }

    // JPunza - 2013-09-16 - Start
    /**
     * This method validates if characteristic value is valid for a given characteristic type. 
     * @param charType - Characteristic Type
     * @param charValue - String
     * @return Bool
     */
    private Bool validateCharacteristicValue(CharacteristicType charType, String charValue) {

        CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charType, charValue);
        if (isNull(charValueId.getEntity())) {
            return Bool.FALSE;
        }        
        return Bool.TRUE;
    }
    // JPunza - 2013-09-16 - End
    
    public static class CmHyperionExtractBatchWorker
            extends CmHyperionExtractBatchWorker_Gen {
        
        // Soft Parameters
        private Bool dailyFlag;
        // JPunza - 2013-09-16 - Start
        private CharacteristicType revenueRateClassCharType;
        private String transportSalesComBasicCharValue;
        private String transportSalesComFirmCharValue;
        private String transportSalesIndBasicCharValue;
        private String transportSalesIndFirmCharValue;
        private String transportationComBasicCharValue;
        private String transportationComFirmCharValue;
        private String transportationIndBasicCharValue;
        private String transportationIndFirmCharValue;
        // JPunza - 2013-09-16 - End
        
        // Working Variables
        private Date processDate;
        private Date startDate;
        private Date endDate;
        private BufferedWriter bufferedWriter;
        private String fercNumber;
        private String revenueRateClassDescr;
        private BigDecimal saCount;
        private BigDecimal billCount;

        private BigDecimal block1WinterThermsBilledAmt;
        private BigDecimal block1SummerThermsBilledAmt;
        private BigDecimal block2WinterThermsBilledAmt;
        private BigDecimal block2SummerThermsBilledAmt;
        private BigDecimal demandThermsBilledAmt;
        private BigDecimal authorizedOverrunThermsAmt;
        private BigDecimal unauthorizedOverrunThermsAmt;

        private BigDecimal block1WinterRevenueBilledAmt;
        private BigDecimal block1SummerRevenueBilledAmt;
        private BigDecimal block2WinterRevenueBilledAmt;
        private BigDecimal block2SummerRevenueBilledAmt;
        private BigDecimal customerChargeBilledAmt;
        private BigDecimal demandChargeRevenueAmt;
        private BigDecimal isrsRevenueBilledAmt;
        private BigDecimal authorizedOverrunRevenueAmt;
        private BigDecimal unauthorizedOverrunRevenueAmt;
        private BigDecimal pgaRevenueBilledAmt;
        private BigDecimal acaRevenueBilledAmt;
        private BigDecimal grtInRevenueAmt;
        private BigDecimal iaRevenueAmt;
        private BigDecimal principalRefundAmt;
        private BigDecimal lacledeIntRefundAmt;
        private BigDecimal grtRefundAmt;
        private BigDecimal stateSalesTaxAmt;
        private BigDecimal citySalesTaxAmt;
        private BigDecimal transportationStorageRevenueAmt;

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new SingleTransactionStrategy(this);
        }

        @Override
        public void initializeThreadWork(boolean arg0)
                throws ThreadAbortedException, RunAbortedException {

            // Soft Parameters
            ThreadParameters parameters = getParameters();

            // Daily Or Monthly Switch
            dailyFlag = Bool.FALSE;
            if (parameters.getDAILY_OR_MONTHLY_SW().equalsIgnoreCase(DAILY)) {
                dailyFlag = Bool.TRUE;
            }
           
            // JPunza - 2013-09-16 - Start
            revenueRateClassCharType = parameters.getREVENUE_RATE_CLASS_CHAR_TYPE();
            transportSalesComBasicCharValue = parameters.getTRANS_SALES_COM_BASIC_CHAR_VAL();
            transportSalesComFirmCharValue = parameters.getTRANS_SALES_COM_FIRM_CHAR_VAL();
            transportSalesIndBasicCharValue = parameters.getTRANS_SALES_IND_BASIC_CHAR_VAL();
            transportSalesIndFirmCharValue = parameters.getTRANS_SALES_IND_FIRM_CHAR_VAL();
            transportationComBasicCharValue = parameters.getTRANSPORT_COM_BASIC_CHAR_VAL();
            transportationComFirmCharValue = parameters.getTRANSPORT_COM_FIRM_CHAR_VAL();
            transportationIndBasicCharValue = parameters.getTRANSPORT_IND_BASIC_CHAR_VAL();
            transportationIndFirmCharValue = parameters.getTRANSPORT_IND_FIRM_CHAR_VAL();
            // JPunza - 2013-09-16 - End           
            
            // Set Dates
            processDate = getProcessDateTime().getDate();
            if (dailyFlag.isFalse()) {
                Month month = processDate.getMonthValue();
                int year = processDate.getYear();

                startDate = new Date(year, month, 1);
                endDate = new Date(year, month, month.getDaysInMonth());
            }

            // Open file
            String fileName = getParameters().getFILE_NAME();

            File file = new File(parameters.getFILE_PATH(), fileName);
            try {
                bufferedWriter = new BufferedWriter(new FileWriter(file));
            } catch (Exception e) {
                addError(CustomMessageRepositoryMDC.NI0034_1_errorWhileAccessingFile(e.getMessage()));
            }

        }

        @Override
        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit arg0)
                throws ThreadAbortedException, RunAbortedException {

            // Counters
            int processedRecord = 0;
            int recordInError = 0;

            saCount = BigDecimal.ZERO;
            billCount = BigDecimal.ZERO;

            // Fields
            block1WinterThermsBilledAmt = BigDecimal.ZERO;
            block1SummerThermsBilledAmt = BigDecimal.ZERO;
            block2WinterThermsBilledAmt = BigDecimal.ZERO;
            block2SummerThermsBilledAmt = BigDecimal.ZERO;
            demandThermsBilledAmt = BigDecimal.ZERO;
            authorizedOverrunThermsAmt = BigDecimal.ZERO;
            unauthorizedOverrunThermsAmt = BigDecimal.ZERO;

            block1WinterRevenueBilledAmt = BigDecimal.ZERO;
            block1SummerRevenueBilledAmt = BigDecimal.ZERO;
            block2WinterRevenueBilledAmt = BigDecimal.ZERO;
            block2SummerRevenueBilledAmt = BigDecimal.ZERO;
            customerChargeBilledAmt = BigDecimal.ZERO;
            demandChargeRevenueAmt = BigDecimal.ZERO;
            isrsRevenueBilledAmt = BigDecimal.ZERO;
            authorizedOverrunRevenueAmt = BigDecimal.ZERO;
            unauthorizedOverrunRevenueAmt = BigDecimal.ZERO;
            pgaRevenueBilledAmt = BigDecimal.ZERO;
            acaRevenueBilledAmt = BigDecimal.ZERO;
            grtInRevenueAmt = BigDecimal.ZERO;
            iaRevenueAmt = BigDecimal.ZERO;
            principalRefundAmt = BigDecimal.ZERO;
            lacledeIntRefundAmt = BigDecimal.ZERO;
            grtRefundAmt = BigDecimal.ZERO;
            stateSalesTaxAmt = BigDecimal.ZERO;
            citySalesTaxAmt = BigDecimal.ZERO;
            transportationStorageRevenueAmt = BigDecimal.ZERO;

            // For each entry in the custom table, extract to file
            QueryIterator<SQLResultRow> iter = getRevenueModelRecords().iterate();
            while (iter.hasNext()) {

                processedRecord++;

                SQLResultRow result = iter.next();

                revenueRateClassDescr = result.getString("CM_RATE_CLASS_DESCR");
                fercNumber = result.getString("CM_FERC_NBR");
                // JPunza - 2013-09-16 - Start
                //saCount = result.getBigDecimal("TOTAL_CNT");
                if (dailyFlag.isTrue()) {
                    saCount = result.getBigDecimal("TOTAL_CNT");
                }
                else {
                    saCount = getSaCount(result.getString("CM_REV_RATE_CLASS").trim()); 
                }
                // JPunza - 2013-09-16 - End
                billCount = result.getBigDecimal("CM_BILL_CNT");
                block1WinterThermsBilledAmt = result.getBigDecimal("CM_BLK1_WNTR_TH_VAL");
                block1SummerThermsBilledAmt = result.getBigDecimal("CM_BLK1_SUMR_TH_VAL");
                block2WinterThermsBilledAmt = result.getBigDecimal("CM_BLK2_WNTR_TH_VAL");
                block2SummerThermsBilledAmt = result.getBigDecimal("CM_BLK2_SUMR_TH_VAL");
                demandThermsBilledAmt = result.getBigDecimal("CM_DEMAND_TH_VAL");
                authorizedOverrunThermsAmt = result.getBigDecimal("CM_AUTH_OVERRUN_TH_VAL");
                unauthorizedOverrunThermsAmt = result.getBigDecimal("CM_UNAUTH_OVERRUN_TH_VAL");
                block1WinterRevenueBilledAmt = result.getBigDecimal("CM_BLK1_WNTR_REV_VAL");
                block1SummerRevenueBilledAmt = result.getBigDecimal("CM_BLK1_SUMR_REV_VAL");
                block2WinterRevenueBilledAmt = result.getBigDecimal("CM_BLK2_WNTR_REV_VAL");
                block2SummerRevenueBilledAmt = result.getBigDecimal("CM_BLK2_SUMR_REV_VAL");
                customerChargeBilledAmt = result.getBigDecimal("CM_CUST_CHG_VAL");
                demandChargeRevenueAmt = result.getBigDecimal("CM_DEMAND_CHG_VAL");
                isrsRevenueBilledAmt = result.getBigDecimal("CM_ISRS_REV_VAL");
                authorizedOverrunRevenueAmt = result.getBigDecimal("CM_AUTH_OVERRUN_REV_VAL");
                unauthorizedOverrunRevenueAmt = result.getBigDecimal("CM_UNAUTH_OVERRUN_REV_VAL");
                pgaRevenueBilledAmt = result.getBigDecimal("CM_PGA_REV_VAL");
                acaRevenueBilledAmt = result.getBigDecimal("CM_ACA_REV_VAL");
                grtInRevenueAmt = result.getBigDecimal("CM_GRT_IN_REV_VAL");
                iaRevenueAmt = result.getBigDecimal("CM_IA_REV_VAL");
                principalRefundAmt = result.getBigDecimal("CM_PRINCIPAL_REFUND_VAL");
                lacledeIntRefundAmt = result.getBigDecimal("CM_LACLEDE_INT_REFUND_VAL");
                grtRefundAmt = result.getBigDecimal("CM_GRT_REFUND_VAL");
                stateSalesTaxAmt = result.getBigDecimal("CM_STATE_SALES_TAX_VAL");
                citySalesTaxAmt = result.getBigDecimal("CM_CITY_SALES_TAX_VAL");
                transportationStorageRevenueAmt = result.getBigDecimal("CM_TRANSPO_STORAGE_REV_VAL");

                // Write record on File
                writeRecord();
            }
            iter.close();

            WorkUnitResult result = new WorkUnitResult(true);
            result.setUnitsProcessed(processedRecord);
            result.setUnitsInError(recordInError);

            return result;
        }

        private PreparedStatement getRevenueModelRecords() {

            StringBuilder sb = new StringBuilder();

            sb.append("SELECT                                                                    ");
            // JPunza - 2013-09-16 - Start
            sb.append("       CM_REV_RATE_CLASS,                                                 ");            
            // JPunza - 2013-09-16 - End
            sb.append("       CM_RATE_CLASS_DESCR,                                               ");
            sb.append("       CM_FERC_NBR,                                                       ");
            sb.append("       NVL(SUM(TOTAL_CNT),0) AS TOTAL_CNT,                                ");
            sb.append("       NVL(SUM(CM_BILL_CNT),0) AS CM_BILL_CNT,                            ");
            sb.append("       NVL(SUM(CM_BLK1_WNTR_THERMS),0) AS CM_BLK1_WNTR_TH_VAL,            ");
            sb.append("       NVL(SUM(CM_BLK1_SUMR_THERMS),0) AS CM_BLK1_SUMR_TH_VAL,            ");
            sb.append("       NVL(SUM(CM_BLK2_WNTR_THERMS),0) AS CM_BLK2_WNTR_TH_VAL,            ");
            sb.append("       NVL(SUM(CM_BLK2_SUMR_THERMS),0) AS CM_BLK2_SUMR_TH_VAL,            ");
            sb.append("       NVL(SUM(CM_DEMAND_THERMS),0) AS CM_DEMAND_TH_VAL,                  ");
            sb.append("       NVL(SUM(CM_AUTH_OVERRUN_THERMS),0) AS CM_AUTH_OVERRUN_TH_VAL,      ");
            sb.append("       NVL(SUM(CM_UNAUTH_OVERRUN_THERMS),0) AS CM_UNAUTH_OVERRUN_TH_VAL,  ");
            sb.append("       NVL(SUM(CM_BLK1_WNTR_REV),0) AS CM_BLK1_WNTR_REV_VAL,              ");
            sb.append("       NVL(SUM(CM_BLK1_SUMR_REV),0) AS CM_BLK1_SUMR_REV_VAL,              ");
            sb.append("       NVL(SUM(CM_BLK2_WNTR_REV),0) AS CM_BLK2_WNTR_REV_VAL,              ");
            sb.append("       NVL(SUM(CM_BLK2_SUMR_REV),0) AS CM_BLK2_SUMR_REV_VAL,              ");
            sb.append("       NVL(SUM(CM_CUST_CHG),0) AS CM_CUST_CHG_VAL,                        ");
            sb.append("       NVL(SUM(CM_DEMAND_CHG),0) AS CM_DEMAND_CHG_VAL,                    ");
            sb.append("       NVL(SUM(CM_ISRS_REV),0) AS CM_ISRS_REV_VAL,                        ");
            sb.append("       NVL(SUM(CM_AUTH_OVERRUN_REV),0) AS CM_AUTH_OVERRUN_REV_VAL,        ");
            sb.append("       NVL(SUM(CM_UNAUTH_OVERRUN_REV),0) AS CM_UNAUTH_OVERRUN_REV_VAL,    ");
            sb.append("       NVL(SUM(CM_PGA_REV),0) AS CM_PGA_REV_VAL,                          ");
            sb.append("       NVL(SUM(CM_ACA_REV),0) AS CM_ACA_REV_VAL,                          ");
            sb.append("       NVL(SUM(CM_GRT_IN_REV),0) AS CM_GRT_IN_REV_VAL,                    ");
            sb.append("       NVL(SUM(CM_IA_REV),0) AS CM_IA_REV_VAL,                            ");
            sb.append("       NVL(SUM(CM_PRINCIPAL_REFUND),0) AS CM_PRINCIPAL_REFUND_VAL,        ");
            sb.append("       NVL(SUM(CM_LACLEDE_INT_REFUND),0) AS CM_LACLEDE_INT_REFUND_VAL,    ");
            sb.append("       NVL(SUM(CM_GRT_REFUND),0) AS CM_GRT_REFUND_VAL,                    ");
            sb.append("       NVL(SUM(CM_STATE_SALES_TAX),0) AS CM_STATE_SALES_TAX_VAL,          ");
            sb.append("       NVL(SUM(CM_CITY_SALES_TAX),0) AS CM_CITY_SALES_TAX_VAL,            ");
            sb.append("       NVL(SUM(CM_TRANSPO_STORAGE_REV),0) AS CM_TRANSPO_STORAGE_REV_VAL   ");
            sb.append("  FROM CM_REV_MODEL                                                       ");

            if (dailyFlag.isTrue()) {
                sb.append("WHERE XFER_TO_GL_DT = :processDate ");
            }
            else {
                sb.append("WHERE XFER_TO_GL_DT BETWEEN :startDate AND :endDate ");
            }

            sb.append(" GROUP BY CM_RATE_CLASS_DESCR,                                            ");
            // JPunza - 2013-09-16 - Start
            sb.append("          CM_REV_RATE_CLASS,                                              ");            
            // JPunza - 2013-09-16 - End
            sb.append("          CM_FERC_NBR                                                     ");

			//Start Changes IM-34989 Mohit
			sb.append(" ORDER BY CM_FERC_NBR,                                            ");
            sb.append("          CM_RATE_CLASS_DESCR                                                     ");
			//End Changes IM-34989 Mohit
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement getRevModelQuery = createPreparedStatement(sb.toString());
            PreparedStatement getRevModelQuery = createPreparedStatement(sb.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            if (dailyFlag.isTrue()) {
                getRevModelQuery.bindDate("processDate", processDate);
            }
            else {
                getRevModelQuery.bindDate("startDate", startDate);
                getRevModelQuery.bindDate("endDate", endDate);
            }


            return getRevModelQuery;
        }

        /**
         * This method writes record to the extract file.
         *
         */
        private void writeRecord() {

            CmRevenueModelExtractRecord record = new CmRevenueModelExtractRecord();
            record.setRevenueRateClass(revenueRateClassDescr);
            record.setFercNumber(fercNumber);
            record.setNumberOfCustomersBilled(saCount.toString());
            record.setNumberOfBills(billCount.toString());
            record.setBlock1WinterTherms(block1WinterThermsBilledAmt.toString());
            record.setBlock1SummerTherms(block1SummerThermsBilledAmt.toString());
            record.setBlock2WinterTherms(block2WinterThermsBilledAmt.toString());
            record.setBlock2SummerTherms(block2SummerThermsBilledAmt.toString());
            record.setDemandThermsBilled(demandThermsBilledAmt.toString());
            record.setAuthorizedOverrunTherms(authorizedOverrunThermsAmt.toString());
            record.setUnauthorizedOverrunTherms(unauthorizedOverrunThermsAmt.toString());
            record.setBlock1WinterRevenueBilled(block1WinterRevenueBilledAmt.toString());
            record.setBlock1SummerRevenueBilled(block1SummerRevenueBilledAmt.toString());
            record.setBlock2WinterRevenueBilled(block2WinterRevenueBilledAmt.toString());
            record.setBlock2SummerRevenueBilled(block2SummerRevenueBilledAmt.toString());
            record.setCustomerChargeBilled(customerChargeBilledAmt.toString());
            record.setDemandChargeRevenue(demandChargeRevenueAmt.toString());
            record.setISRSRevenueBilled(isrsRevenueBilledAmt.toString());
            record.setAuthorizedOverrunRevenue(authorizedOverrunRevenueAmt.toString());
            record.setUnauthorizedOverrunRevenue(unauthorizedOverrunRevenueAmt.toString());
            record.setPGARevenueBilled(pgaRevenueBilledAmt.toString());
            record.setACARevenueBilled(acaRevenueBilledAmt.toString());
            record.setGRTInRevenue(grtInRevenueAmt.toString());
            record.setIARevenue(iaRevenueAmt.toString());
            record.setPrincipalRefund(principalRefundAmt.toString());
            record.setLacledeIntRefund(lacledeIntRefundAmt.toString());
            record.setGRTRefund(grtRefundAmt.toString());
            record.setStateSalesTax(stateSalesTaxAmt.toString());
            record.setCitySalesTax(citySalesTaxAmt.toString());
            record.setTransportationStorageRevenue(transportationStorageRevenueAmt.toString());

            try {
                bufferedWriter.write(record.createRecordString());
                bufferedWriter.newLine();
            }
            catch (Exception e) {
                addError(CustomMessageRepositoryMDC.NI0034_1_errorWhileAccessingFile(e.getMessage()));
            }
        }
        
        // JPunza - 2013-09-16 - Start
        /**
         * This method retrieves the total number of SA given the Revenue Rate Class.
         * @param revenueRateClass - String
         * @return BigDecimal
         */
        private BigDecimal getSaCount(String revenueRateClass) {

            BigDecimal count = BigDecimal.ZERO;
                        
            // Check for Transport Sales
            Bool isTransportSales = Bool.FALSE;
            if (revenueRateClass.equalsIgnoreCase(transportSalesComBasicCharValue)
                    || revenueRateClass.equalsIgnoreCase(transportSalesComFirmCharValue)
                    || revenueRateClass.equalsIgnoreCase(transportSalesIndBasicCharValue)
                    || revenueRateClass.equalsIgnoreCase(transportSalesIndFirmCharValue)) { 
                isTransportSales = Bool.TRUE;
            }
            
            // JPunza - 2013-11-12 - Start
            //PreparedStatement financialTransactions = getFinancialTransactions(isTransportSales, revenueRateClass, fercNumber);            
            String transportRateClass1 = null;
            String transportRateClass2 = null;
            
            // Determine the Transport Sales and Transportation pair
            transportRateClass1 = revenueRateClass;
            if (revenueRateClass.equalsIgnoreCase(transportSalesComBasicCharValue)) {
                transportRateClass2 = transportationComBasicCharValue;
            }
            else if (revenueRateClass.equalsIgnoreCase(transportSalesComFirmCharValue)) {
                transportRateClass2 = transportationComFirmCharValue;
            }
            else if (revenueRateClass.equalsIgnoreCase(transportSalesIndBasicCharValue)) {
                transportRateClass2 = transportationIndBasicCharValue;
            }
            else if (revenueRateClass.equalsIgnoreCase(transportSalesIndFirmCharValue)) {
                transportRateClass2 = transportationIndFirmCharValue;
            }
            else if (revenueRateClass.equalsIgnoreCase(transportationComBasicCharValue)) {
                transportRateClass2 = transportSalesComBasicCharValue;
            }
            else if (revenueRateClass.equalsIgnoreCase(transportationComFirmCharValue)) {
                transportRateClass2 = transportSalesComFirmCharValue;
            }
            else if (revenueRateClass.equalsIgnoreCase(transportationIndBasicCharValue)) {
                transportRateClass2 = transportSalesIndBasicCharValue;
            }
            else if (revenueRateClass.equalsIgnoreCase(transportationIndFirmCharValue)) {
                transportRateClass2 = transportSalesIndFirmCharValue;
            }
            else {
                transportRateClass2 = revenueRateClass; 
            }
         
            PreparedStatement financialTransactions = getFinancialTransactions(isTransportSales, transportRateClass1, transportRateClass2, fercNumber);
            // JPunza - 2013-11-12 - End
            
            if (isTransportSales.isFalse()) {                
                count = financialTransactions.firstRow().getBigDecimal("CNT");
            }
            else {
                
                // JPunza - 2013-11-12 - Start
                //String transportRateClass1 = null;
                //String transportRateClass2 = null;
                //
                //// Determine the Transport Sales and Transportation pair
                //if (revenueRateClass.equalsIgnoreCase(transportSalesComBasicCharValue)) {
                //    transportRateClass1 = transportSalesComBasicCharValue;
                //    transportRateClass2 = transportationComBasicCharValue;
                //}
                //else if (revenueRateClass.equalsIgnoreCase(transportSalesComFirmCharValue)) {
                //    transportRateClass1 = transportSalesComFirmCharValue;
                //    transportRateClass2 = transportationComFirmCharValue;
                //}
                //else if (revenueRateClass.equalsIgnoreCase(transportSalesIndBasicCharValue)) {
                //    transportRateClass1 = transportSalesIndBasicCharValue;
                //    transportRateClass2 = transportationIndBasicCharValue;
                //}
                //else if (revenueRateClass.equalsIgnoreCase(transportSalesIndFirmCharValue)) {
                //    transportRateClass1 = transportSalesIndFirmCharValue;
                //    transportRateClass2 = transportationIndFirmCharValue;
                //}
                // JPunza - 2013-11-12 - End
                
                // Check Revenue Rate Classes in FT GL
                ServiceAgreement previousSa = null;
                ServiceAgreement currentSa = null;
                
                QueryIterator<SQLResultRow> iter = financialTransactions.iterate();
                while (iter.hasNext()) {
                    
                    SQLResultRow resultFt = iter.next();
                    currentSa = resultFt.getEntity("SA_ID", ServiceAgreement.class);
                    FinancialTransaction ft = resultFt.getEntity("FT_ID", FinancialTransaction.class);

                    Bool specialProcess = Bool.FALSE;
                    // Check if both Transportation and Transport Sales exist 
                    if (checkForRevenueRateClass(ft, transportRateClass1).isTrue() 
                            && checkForRevenueRateClass(ft, transportRateClass2).isTrue()) {
                        specialProcess = Bool.TRUE;
                    }                    

                    // Count Service Agreement
                    if (!(currentSa.equals(previousSa))) {

                        // For Transport Sales, count SA only if there is no GL with Transportation  
                        if (isTransportSales.isTrue()) {
                            if (specialProcess.isFalse()) {
                                count = count.add(BigDecimal.ONE);
                            }                        
                        }
                        else {
                            count = count.add(BigDecimal.ONE);
                        }
                        previousSa = currentSa;
                    }
                }
                iter.close();
            }
            financialTransactions.close();
            
            return count;
        }
        
        /**
         * This method either retrieves the total number of SA or a list of eligible FTs.
         * @param isTransportSales - Bool
         * @param revenueRateClass1 - String
         * @param revenueRateClass2 - String
         * @param fercNumber - String
         * @return PreparedStatement
         */
        // JPunza - 2013-11-12 - Start
        //private PreparedStatement getFinancialTransactions(Bool isTransportSales, String revenueRateClass, String fercNumber) {
        private PreparedStatement getFinancialTransactions(Bool isTransportSales, String revenueRateClass1, 
                String revenueRateClass2, String fercNumber) {
        // JPunza - 2013-11-12 - End
            
            StringBuilder sb = new StringBuilder("");

            if (isTransportSales.isTrue()) {
                sb.append("SELECT FT.SA_ID, FT.FT_ID ");
            }
            else {
                sb.append("SELECT COUNT(DISTINCT FT.SA_ID) AS CNT ");
            }
            sb.append("FROM CI_FT FT "  +
                    "WHERE FT.XFER_TO_GL_DT BETWEEN :startDate AND :endDate " +
                    "AND FT.FT_TYPE_FLG IN (:bsFtType, :bxFtType) " +
                    "AND EXISTS (SELECT 'X' FROM CI_FT_GL FG " +
                    "   WHERE FG.FT_ID = FT.FT_ID " +
                    "   AND EXISTS (SELECT 'X' FROM CI_DST_CODE_EFF DCE " +
                    "      WHERE DCE.DST_ID = FG.DST_ID " + 
                    "      AND DCE.GL_ACCT LIKE :fercNumber " +
                    "      AND EXISTS (SELECT 'X' FROM CI_DST_CD_CHAR DCC " +
                    "         WHERE DCC.DST_ID = DCE.DST_ID " +
                    "         AND DCC.CHAR_TYPE_CD = :charType " +
                    "         AND TRIM(DCC.CHAR_VAL) = TRIM(:charValue) " +
                    // JPunza - 2013-11-12 - Start
                    //"         AND DCC.EFFDT <= :processDate))) ");
                    "         AND DCC.EFFDT <= :processDate))) " +
                    "AND NOT EXISTS (SELECT 'X' FROM CI_FT_GL FG2 " +
                    "   WHERE FG2.FT_ID = FT.FT_ID " +
                    "   AND EXISTS (SELECT 'X' FROM CI_DST_CD_CHAR DCC2 " +
                    "         WHERE DCC2.DST_ID = FG2.DST_ID " +
                    "         AND DCC2.CHAR_TYPE_CD = :charType " +
                    "         AND TRIM(DCC2.CHAR_VAL) NOT IN (TRIM(:charValue), TRIM(:charValue2)) " +
                    "         AND DCC2.EFFDT <= :processDate)) ");
                    // JPunza - 2013-11-12 - End
            if (isTransportSales.isTrue()) {
                sb.append("ORDER BY FT.SA_ID");
            }    
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement getftQuery = createPreparedStatement(sb.toString());
            PreparedStatement getftQuery = createPreparedStatement(sb.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            getftQuery.bindDate("processDate", processDate);  
            getftQuery.bindDate("startDate", startDate);
            getftQuery.bindDate("endDate", endDate);            
            getftQuery.bindLookup("bsFtType", FinancialTransactionTypeLookup.constants.BILL_SEGMENT);
            getftQuery.bindLookup("bxFtType", FinancialTransactionTypeLookup.constants.BILL_CANCELLATION);
            getftQuery.bindLikableStringProperty("fercNumber", 
                    GeneralLedgerDistributionEff.properties.glAccount, 
                    "____" + fercNumber);
            getftQuery.bindEntity("charType", revenueRateClassCharType);
            // JPunza - 2013-11-12 - Start
            //getftQuery.bindStringProperty("charValue", 
            //        GeneralLedgerDistributionCodeCharacteristic.properties.characteristicValue, 
            //        revenueRateClass);
            getftQuery.bindStringProperty("charValue", 
                    GeneralLedgerDistributionCodeCharacteristic.properties.characteristicValue, 
                    revenueRateClass1);
            getftQuery.bindStringProperty("charValue2", 
                    GeneralLedgerDistributionCodeCharacteristic.properties.characteristicValue, 
                    revenueRateClass2);
            // JPunza - 2013-11-12 - End
            return getftQuery;
        }
        
        /**
         * This method checks for Revenue Rate Class.
         * @param ft - Financial Transaction
         * @param transportRateClass - String
         * @return Bool
         */
        private Bool checkForRevenueRateClass(FinancialTransaction ft, String transportRateClass) {

            PreparedStatement checkRateClassQuery = createPreparedStatement("SELECT FG.FT_ID FROM CI_FT_GL FG " +
                    "WHERE FG.FT_ID = :ft " +
                    "AND EXISTS (SELECT 'X' FROM CI_DST_CD_CHAR DCC " +
                    "   WHERE DCC.DST_ID = FG.DST_ID " +
                    "   AND DCC.CHAR_TYPE_CD = :charType " +
                    "   AND (TRIM(DCC.CHAR_VAL) = TRIM(:charValue) " +
                    "   OR TRIM(DCC.CHAR_VAL_FK1) = TRIM(:charValueFk1) " +
                    "   OR TRIM(DCC.ADHOC_CHAR_VAL) = TRIM(:adhocCharValue)) " +
                    //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
                    //"   AND DCC.EFFDT <= :processDate)");
        			"   AND DCC.EFFDT <= :processDate)", getClass().getName());
            		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation

            checkRateClassQuery.bindEntity("ft", ft);
            checkRateClassQuery.bindEntity("charType", revenueRateClassCharType);
            checkRateClassQuery.bindStringProperty("charValue", 
                    GeneralLedgerDistributionCodeCharacteristic.properties.characteristicValue, 
                    transportRateClass);
            checkRateClassQuery.bindStringProperty("charValueFk1", 
                    GeneralLedgerDistributionCodeCharacteristic.properties.characteristicValueForeignKey1, 
                    transportRateClass); 
            checkRateClassQuery.bindStringProperty("adhocCharValue", 
                    GeneralLedgerDistributionCodeCharacteristic.properties.adhocCharacteristicValue, 
                    transportRateClass);                 
            checkRateClassQuery.bindDate("processDate", processDate);

            if (notNull(checkRateClassQuery.firstRow())) {
                checkRateClassQuery.close();
                return Bool.TRUE;
            }

            checkRateClassQuery.close();
            return Bool.FALSE;
        }        
        // JPunza - 2013-09-16 - End

        @Override
        public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {

            try {
                bufferedWriter.close();
            }
            catch (Exception e) {
                addError(CustomMessageRepositoryMDC.NI0034_1_errorWhileAccessingFile(e.getMessage()));
            }
        }
    }
}
