/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPCXCCX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      RI0016. Initial Version.
 * 2016-05-23   MPang       Defect 3439849. Added close connection to avoid
 *                          UniversalPoolConnectionException.     
 * 2016-09-27   SFelip      Defect 3512842. Add a warning if the 
 *                          ADDRESS-FOUND-SW of Cmpcxccx returns N.
 * 2018-06-07   SFelip      CCB v2.6 Upgrade. 
 * 2025-11-14   EQuint      CCB25.4 Upgrade                                                                   
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.letterTemplate.algorithm.letterExtract;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.batch.batchRun.BatchRun;
import com.splwg.base.domain.common.algorithm.Algorithm;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.domain.report.reportDefinition.ReportDefinition;
import com.splwg.base.domain.report.reportDefinition.ReportDefinition_Id;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.admin.letterTemplate.algorithm.letterExtract.LetterTemplateLetterExtractAlgorithmSpot;
import com.splwg.ccb.domain.admin.letterTemplate.entity.LetterTemplate;
import com.splwg.ccb.domain.common.fileHelper.FileHelper;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpcxccx;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = accountIDCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = preferredMethodOfContactCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = preferredMethodOfEmailCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = defaultPreferredMethodOfContactCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = mailToMailingandServiceAddressCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = mailToMailingandServiceAddressCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = premiseIDCharType, type = entity)})
 */
public class CmCreateExtendedGeneralLetterExtractRecordsAlgComp_Impl extends
		CmCreateExtendedGeneralLetterExtractRecordsAlgComp_Gen implements
		LetterTemplateLetterExtractAlgorithmSpot {

	// hard parameters
	private BigInteger customerContactExtractedCount;
	private ReportDefinition reportDefinition;
	private BatchRun batchRun;
	private CustomerContact customerContact;
	private String extractFileName;
	private FileHelper fileHelper;
	private Bool isFieldDelimited;
	private Bool isFirstHeaderDelimited;
	private Algorithm letterExtractAlgorithm;
	private LetterTemplate letterTemplate;
	private CustomerContact toCustomerContact;
	
	// soft parameters
	private CharacteristicType accountIDCharType;
	private CharacteristicType preferredMethodOfContactCharType;
	private CharacteristicValue preferredMethodOfEmailCharValue;
	private CharacteristicValue defaultPreferredMethodOfContactCharValue;
	private CharacteristicType mailToMailingandServiceAddressCharType;
	private String mailToMailingandServiceAddressCharValue;
	private CharacteristicType premiseIDCharType;
	
	private Cmpcxccx cmpcxccx;
	//Start Add - MPang - Defect 3439849 - 2016-05-23
	private Connection connection;
	//End Add - MPang - Defect 3439849 - 2016-05-23
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	
	
	@Override
	public BigInteger getCustomerContactExtractedCount() {
		return customerContactExtractedCount;
	}

	@Override
	public ReportDefinition getReportDefinition() {
		return reportDefinition;
	}

	@Override
	public void setBatchRun(BatchRun arg0) {
		batchRun = arg0;
	}

	@Override
	public void setCustomerContact(CustomerContact arg0) {
		customerContact = arg0;
	}

	@Override
	public void setCustomerContactExtractedCount(BigInteger arg0) {
		customerContactExtractedCount = arg0;
	}

	@Override
	public void setExtractFileName(String arg0) {
		extractFileName = arg0;
	}

	@Override
	public void setFileHelper(FileHelper arg0) {
		fileHelper = arg0;
	}

	@Override
	public void setIsFieldDelimited(Bool arg0) {
		isFieldDelimited = arg0;
	}

	@Override
	public void setIsFirstHeaderDelimited(Bool arg0) {
		isFirstHeaderDelimited = arg0;
	}

	@Override
	public void setLetterExtractAlgorithm(Algorithm arg0) {
		letterExtractAlgorithm = arg0;
	}

	@Override
	public void setLetterTemplate(LetterTemplate arg0) {
		letterTemplate = arg0;
	}

	@Override
	public void setToCustomerContact(CustomerContact arg0) {
		toCustomerContact = arg0;
	}
	
	
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		
		accountIDCharType = getAccountIDCharType();
		preferredMethodOfContactCharType = getPreferredMethodOfContactCharType();
		preferredMethodOfEmailCharValue = new CharacteristicValue_Id(preferredMethodOfContactCharType, 
				getPreferredMethodOfEmailCharValue()).getEntity();
		defaultPreferredMethodOfContactCharValue = new CharacteristicValue_Id(preferredMethodOfContactCharType, 
				getDefaultPreferredMethodOfContactCharValue()).getEntity();
		mailToMailingandServiceAddressCharType = getMailToMailingandServiceAddressCharType();
		mailToMailingandServiceAddressCharValue = getMailToMailingandServiceAddressCharValue();
		premiseIDCharType = getPremiseIDCharType();
		
	}

	@Override
	public void invoke() {
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			if(notNull(customerContact)) {
				cmpcxccx.setInputWrkCcId(customerContact.getId().getTrimmedValue());
			}else{
				cmpcxccx.setInputWrkCcId(CobolCode.SPACES.toString());
			}
			if(notNull(batchRun)) {
				cmpcxccx.setInputWrkBatchCd(batchRun.fetchIdBatchControl().getId().getTrimmedValue());
				cmpcxccx.setInputWrkBatchNbr(java.math.BigDecimal.valueOf(batchRun.fetchIdBatchNumber().doubleValue()));
			}else{
				cmpcxccx.setInputWrkBatchCd(CobolCode.SPACES.toString());
				cmpcxccx.setInputWrkBatchNbr(java.math.BigDecimal.ZERO);
			}
			if(notNull(letterTemplate)) {
				cmpcxccx.setInputWrkLtrTmplCd(letterTemplate.getId().getTrimmedValue());
			}else{
				cmpcxccx.setInputWrkLtrTmplCd(CobolCode.SPACES.toString());
			}
			if (notNull(letterExtractAlgorithm)) {
				cmpcxccx.setExtractAlgCd(letterExtractAlgorithm.getId().getTrimmedValue());
			}else{
				cmpcxccx.setExtractAlgCd(CobolCode.SPACES.toString());
			}
			if(notBlank(extractFileName)) {
				cmpcxccx.setExtractFileName(extractFileName.trim());
			}else{
				cmpcxccx.setExtractFileName(CobolCode.SPACES.toString());
			}
			
			if(notNull(isFieldDelimited)) {
				String isFieldDelimitedSw = (isFieldDelimited.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpcxccx.setFieldDelimSw(isFieldDelimitedSw);
			}else{
				cmpcxccx.setFieldDelimSw(CobolCode.SPACES.toString());
			}
			if(notNull(isFirstHeaderDelimited)) {
				String isFirstHeaderDelimitedSw = (isFirstHeaderDelimited.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpcxccx.setDelim_1stHeaderSw(isFirstHeaderDelimitedSw);
			}else{
				cmpcxccx.setDelim_1stHeaderSw(CobolCode.SPACES.toString());
			}
			if(notNull(toCustomerContact)) {
				cmpcxccx.setToCcId(toCustomerContact.getId().getTrimmedValue());
			}else{
				cmpcxccx.setToCcId(CobolCode.SPACES.toString());
			}
			if (notNull(customerContactExtractedCount)) {
				cmpcxccx.setCcExtractedCnt(java.math.BigDecimal.valueOf(customerContactExtractedCount.doubleValue()));
			}else{
				cmpcxccx.setCcExtractedCnt(java.math.BigDecimal.ZERO);
			}
			
			// soft parameters
			cmpcxccx.setAlgParmVal(1, accountIDCharType.getId().getTrimmedValue()); 
			cmpcxccx.setAlgParmVal(2, preferredMethodOfContactCharType.getId().getTrimmedValue()); 
			cmpcxccx.setAlgParmVal(3, preferredMethodOfEmailCharValue.getId().getCharacteristicValue());
			cmpcxccx.setAlgParmVal(4, defaultPreferredMethodOfContactCharValue.getId().getCharacteristicValue()); 
			cmpcxccx.setAlgParmVal(5, mailToMailingandServiceAddressCharType.getId().getTrimmedValue()); 
			cmpcxccx.setAlgParmVal(6, mailToMailingandServiceAddressCharValue.trim()); 
			if (notNull(premiseIDCharType)) {
				cmpcxccx.setAlgParmVal(7, premiseIDCharType.getId().getTrimmedValue()); 
			}else{
				cmpcxccx.setAlgParmVal(7, CobolCode.SPACES.toString());
			}
			
			// invoke the main method
		    cmpcxccx.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmpcxccx.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmpcxccx.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmpcxccx.getMessageParm(i);
			    			if (notBlank(cmpcxccx.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmpcxccx.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmpcxccx.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmpcxccx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmpcxccx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    	customerContactExtractedCount = cmpcxccx.getCcExtractedCnt().toBigInteger();
		    	reportDefinition = new ReportDefinition_Id(cmpcxccx.getReportCd().trim()).getEntity();
		    	
		    	// Start Add - SFelip - Defect 3512842 - 2016-09-27
		    	if(cmpcxccx.getIgnoreWarningSw().equals(SWITCH_NO)) {
		    	    if(cmpcxccx.getOutputWrkAddressFoundSw().equals(SWITCH_NO)) {
		    	        addWarning(CustomMessageRepository.DEFECT_3512842_addressNotFound(customerContact.getId().getTrimmedValue()));
	                }
		    	}
		    	// End Add - SFelip - Defect 3512842 - 2016-09-27
		    	
		    }
		    else {
		        //Start Add - MPang - Defect 3439849 - 2016-05-23
		        ex.printStackTrace();
		        //End Add - MPang - Defect 3439849 - 2016-05-23
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmpcxccx=Session.returnSessionAndCodeToCache(cmpcxccx);
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//			//Start Add - MPang - Defect 3439849 - 2016-05-23
//			try {
//                connection.close();
//            } catch (SQLException e) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
//            }
//			//End Add - MPang - Defect 3439849 - 2016-05-23
			// end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}

	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
		FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
	    RequestContext context = session.getRequestContext();
	    

        // start update - equint - 2025-11-14 - CCB25.4 Upgrade
 		session.doWork(new ConnectionWork() {
 			
 			@Override
 			public void execute(Connection connection) throws SQLException {
 				try {
 					String username = connection.getMetaData().getUserName();
 					String url = connection.getMetaData().getURL();
 					
 					CobolSession.setLogSessionStartEnd(false);
 				    cmpcxccx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpcxccx.class);
 					
 					cmpcxccx.getSession().getDbSession().setUpdateConnection(connection);
 					cmpcxccx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
 					cmpcxccx.aa100Initialize();
 					// set ZSTAT parameters

 					cmpcxccx.setProcessDt(getProcessDateTime().getDate().toString());
 					cmpcxccx.setProcessDttmSep("-");
 					cmpcxccx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
 					
 					if (session.isOnlineConnection()) { 
 						cmpcxccx.setConnectionFlg(CONNECTION_ONLINE);
 					}
 					else {
 						cmpcxccx.setConnectionFlg(CONNECTION_BATCH);
 					}
 					
 					cmpcxccx.setUserId(context.getUserId());
 					cmpcxccx.setZstatLanguageCd(context.getLanguageCode());
 			        
 			        if (context.ignoreWarnings()) {
 			        	cmpcxccx.setIgnoreWarningSw(SWITCH_YES);
 			        }
 			        else {
 			        	cmpcxccx.setIgnoreWarningSw(SWITCH_NO);
 			        }
 			        
 			        if (session.getBatchInstanceId() != null) {
 			        	cmpcxccx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
 			        	
 					} else {
 						cmpcxccx.setSchedulerId(new BigDecimal(0).toBigDecimal());
 					}
 			        
 			        cmpcxccx.setAppSvcId(context.getSecurityServiceIdContext());
 			        
 			        DatabaseHelper dbHelper = session.getDatabaseHelper();
 			        cmpcxccx.setDbMode(dbHelper.getCobolDBMode());
 			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
 			        //cmpcxccx.setSplHighValue(cmpcxccx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
 			        //cmpcxccx.setSplLowValue(cmpcxccx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
 			        
 			        cmpcxccx.setSplHighValue(cmpcxccx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
 			        cmpcxccx.setSplLowValue(cmpcxccx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
 			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
 			        cmpcxccx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
 			        
 			        cmpcxccx.setLkExpiryDt(Date.MAX.toString());
 			        
 			        cmpcxccx.setProgramStatus(" ");
 			        
 			        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
 			        cmpcxccx.setCallSeq(";");
 			        cmpcxccx.setMessageAreaProgramName("CMPCXCCX");
 			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
 			        
 			        if (context.getRandomGeneratorSeedSet().isTrue()) {
 			        	cmpcxccx.setRandomGenSeedSw(SWITCH_YES);
 			        	cmpcxccx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
 			        	cmpcxccx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
 			        	cmpcxccx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
 			        	cmpcxccx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
 			        }
 			        else {
 			        	cmpcxccx.setRandomGenSeedSw(SWITCH_NO);
 			        }
 			        
 			        if (context.traceStandardOut()) { 
 			        	cmpcxccx.setTrcStdoutSw(SWITCH_YES);
 			        }
 			        else {
 			        	cmpcxccx.setTrcStdoutSw(SWITCH_NO);
 			        }
 			        
 			        if (context.traceProgramStart()) { 
 			        	cmpcxccx.setTrcProgStartSw(SWITCH_YES);
 			        }
 			        else {
 			        	cmpcxccx.setTrcProgStartSw(SWITCH_NO);
 			        }
 			        
 			        if (context.traceProgramExit()) { 
 			        	cmpcxccx.setTrcProgExitSw(SWITCH_YES);
 			        }
 			        else {
 			        	cmpcxccx.setTrcProgExitSw(SWITCH_NO);
 			        }
 			        
 			        if (context.traceSQL()) { 
 			        	cmpcxccx.setTrcExecSqlSw(SWITCH_YES);
 			        }
 			        else {
 			        	cmpcxccx.setTrcExecSqlSw(SWITCH_NO);
 			        }
 			        
 			        // Set ZMSGN parms
 			        BigInteger messageSequence = session.getMessageSequence();
 			        if (notNull(messageSequence)) {
 			        	cmpcxccx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
 			        }
 			        else {
 			        	cmpcxccx.setMessageSeq(new BigDecimal(0).toBigDecimal());
 			        }
 				}
 				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});

//	    SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//		//Start Change - MPang - Defect 3439849 - 2016-05-23
//		//Connection connection = implementor.getConnectionProvider().getConnection();
//		connection = implementor.getConnectionProvider().getConnection();
//		//End Change - MPang - Defect 3439849 - 2016-05-23
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmpcxccx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpcxccx.class);
//		
//		cmpcxccx.getSession().getDbSession().setUpdateConnection(connection);
//		cmpcxccx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		cmpcxccx.aa100Initialize();
//		// set ZSTAT parameters
//
//		cmpcxccx.setProcessDt(getProcessDateTime().getDate().toString());
//		cmpcxccx.setProcessDttmSep("-");
//		cmpcxccx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmpcxccx.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmpcxccx.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmpcxccx.setUserId(context.getUserId());
//		cmpcxccx.setZstatLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmpcxccx.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxccx.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmpcxccx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmpcxccx.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmpcxccx.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmpcxccx.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmpcxccx.setSplHighValue(cmpcxccx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmpcxccx.setSplLowValue(cmpcxccx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmpcxccx.setSplHighValue(cmpcxccx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmpcxccx.setSplLowValue(cmpcxccx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        cmpcxccx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmpcxccx.setLkExpiryDt(Date.MAX.toString());
//        
//        cmpcxccx.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmpcxccx.setCallSeq(";");
//        cmpcxccx.setMessageAreaProgramName("CMPCXCCX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmpcxccx.setRandomGenSeedSw(SWITCH_YES);
//        	cmpcxccx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmpcxccx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmpcxccx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmpcxccx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmpcxccx.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmpcxccx.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxccx.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmpcxccx.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxccx.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmpcxccx.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxccx.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmpcxccx.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxccx.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmpcxccx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmpcxccx.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }
 		
 	// end update - equint - 2025-11-14 - CCB25.4 Upgrade

	}

}
