/**************************************************************************
* Program Name: CmCreateMassFieldActivityBatch
* Program Title: CmCreateMassFieldActivityBatch
* Author: AMasil
* Creation Date: 2017-06-06
* Purpose: This batch processes the records in the CM_MASS_ISSUE_FA table 
*          to mass create Field Activities with the corresponding 
*          details in the table.
* Functional Spec: FS_NA49131
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:         Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *    FS_NA49131      Aya Masilang    2017-06-06    Initial Version
 ************************************************************************************************/
package com.splwg.cm.domain.batch;

import java.util.concurrent.TimeUnit;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.ccb.api.lookup.FieldActivityCreatedByLookup;
import com.splwg.ccb.domain.admin.dispatchGroup.entity.DispatchGroup_Id;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.fieldOrder.cmMassIssueFieldAcitvity.CmMassIssueFieldActivity;
import com.splwg.cm.domain.fieldOrder.cmMassIssueFieldAcitvity.CmMassIssueFieldActivity_DTO;
import com.splwg.cm.domain.fieldOrder.cmMassIssueFieldAcitvity.CmMassIssueFieldActivity_Id;
import com.splwg.shared.common.ApplicationError;

/**
 * @author Administrator
 *
@BatchJob (multiThreaded = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = SLEEP, required = true, type = integer)})
 */
public class CmCreateMassFieldActivityBatch extends
        CmCreateMassFieldActivityBatch_Gen {
    
    //Constants
    private final String NEW_STATUS_FLG = "N";
    
    public JobWork getJobWork() { 
        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
        StringBuilder queryString = new StringBuilder();

        queryString.append("SELECT FA_REQ_ID ");
        queryString.append("FROM CM_MASS_ISSUE_FA ");
        queryString.append("WHERE STATUS_FLAG = :pendingStatus ");

        PreparedStatement recordQuery = createPreparedStatement(queryString.toString(), getClass().getName());
        recordQuery.bindString("pendingStatus", NEW_STATUS_FLG, "STATUS_FLAG");

        QueryIterator<SQLResultRow> recordIterator = recordQuery.iterate();
        while(recordIterator.hasNext()){
            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId(new CmMassIssueFieldActivity_Id(recordIterator.next().getInteger("FA_REQ_ID")));
            workUnits.add(workUnit);
        }

        recordIterator.close();
        recordQuery.close();
        return createJobWorkForThreadWorkUnitList(workUnits);
    }

    public Class<CmCreateMassFieldActivityBatchWorker> getThreadWorkerClass() {
        return CmCreateMassFieldActivityBatchWorker.class;
    }

    public static class CmCreateMassFieldActivityBatchWorker extends
            CmCreateMassFieldActivityBatchWorker_Gen {
        
        //Soft Parameters
        private int maxErrors = 0;
        private int sleepMS = 0;
        
        //Working Variables
        private int errorCount = 0;
        
        //Constants
        private final String FIELD_ACTIVITY_ID_IN_ERROR = "0";
        private final String COMMA = ",";
        private final String EQUAL = "=";
        private final String COMPLETED_STATUS_FLG = "C";
        private final String ERROR_STATUS_FLG = "E";

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

        public void initializeThreadWork(
                boolean initializationPreviouslySuccessful)
                throws ThreadAbortedException, RunAbortedException {
            sleepMS = getParameters().getSLEEP().intValue();
            maxErrors = getParameters().getSoftMaxErrors().intValue();
        }

        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
            CmMassIssueFieldActivity massIssueFa = ((CmMassIssueFieldActivity_Id)unit.getPrimaryId()).getEntity();
            Bool isInError = Bool.FALSE;
            FieldActivity fa = null;

            try{
                //Create the Field Activity
                FieldActivity_DTO faDto = new FieldActivity_DTO();
                faDto.setFieldActivityTypeId(new FieldActivityType_Id(massIssueFa.getFieldActivityType()));
                faDto.setServicePointId(new ServicePoint_Id(massIssueFa.getServicePointId()));
                faDto.setScheduleDateTimeStart(massIssueFa.getScheduleDateTimeStart());
                faDto.setInstructions(massIssueFa.getInstructions());
                faDto.setCreatedBy(FieldActivityCreatedByLookup.constants.BACKGROUND);
                
                faDto.setCreationDateTime(getProcessDateTime());
                
                FieldActivityCreatorData faCreatorData = FieldActivityCreatorData.Factory.newInstance();
                faCreatorData.setFaDTO(faDto);
                
                FieldActivityCreator faCreator = FieldActivityCreator.Factory.newInstance();
                fa = faCreator.addFieldActivity(faCreatorData);
                
                //Adds the Field Activity Characteristic
                if(notNull(massIssueFa.getCmFieldActivityCharacteristicDetails())){
                    List<String> charTypeWithValueList = Arrays.asList(massIssueFa.getCmFieldActivityCharacteristicDetails().split(COMMA));

                    for(String charTypeWithValue : charTypeWithValueList){
                        String[] charDetails = charTypeWithValue.split(EQUAL);
                        CharacteristicType charType = new CharacteristicType_Id(charDetails[0]).getEntity();
                        CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
                        FieldActivityCharacteristic_DTO faCharDTO = new FieldActivityCharacteristic_DTO();

                        if (charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
                            faCharDTO.setAdhocCharacteristicValue(charDetails[1]);
                        } 
                        else if (charTypeLookup.isPredefinedValue()) {
                            faCharDTO.setCharacteristicValue(charDetails[1]);
                        }
                        else if (charTypeLookup.isForeignKeyValue()) {
                            faCharDTO.setCharacteristicValueForeignKey1(charDetails[1]);
                        }  
                        
                        BigInteger sequence = retrieveFACharMaxSequence(fa.getId(), charType);
                        
                        if(notNull(sequence)){
                            sequence = sequence.add(BigInteger.ONE);
                        } else {
                            sequence = BigInteger.ONE;
                        }
                        
                        fa.getCharacteristics().add(faCharDTO, charType.getId(), sequence);
                    }
                }
                
                if(notNull(massIssueFa.getDispatchGroup())){
                    FieldActivity_DTO faDispatchGrpDTO = fa.getDTO();
                    faDispatchGrpDTO.setDispatchGroupId(new DispatchGroup_Id(massIssueFa.getDispatchGroup()));
                    fa.setDTO(faDispatchGrpDTO);
                }
                
                
            } catch(ApplicationError e){
                errorCount++;
                isInError = Bool.TRUE;
                logError(CustomMessageRepository.NA49131_errorMessage(massIssueFa.getId().getIdValue().toString(), e.getServerMessage().getMessageText()));
                
                if (errorCount > maxErrors){
                    throw new RunAbortedException(CustomMessageRepository.NA49131_MaxErrorLimitExceeded(String.valueOf(maxErrors)));
                }
            }
            
            //Updates the Mass Issue FA record in the custom table
            CmMassIssueFieldActivity_DTO massIssueFaDTO = massIssueFa.getDTO();
            if(isInError.isFalse()){
                massIssueFaDTO.setCmMassFieldActivityStatusFlag(COMPLETED_STATUS_FLG);
                massIssueFaDTO.setFieldActivityId(fa.getId().getTrimmedValue());
            } else {
                massIssueFaDTO.setCmMassFieldActivityStatusFlag(ERROR_STATUS_FLG);
                massIssueFaDTO.setFieldActivityId(FIELD_ACTIVITY_ID_IN_ERROR);
            }
            
            massIssueFaDTO.setBatchNumber(getBatchNumber());
            massIssueFaDTO.setCompletedDatetime(getProcessDateTime());
            massIssueFa.setDTO(massIssueFaDTO);
            
            if(sleepMS > 0){
                try {
                    TimeUnit.MILLISECONDS.sleep(sleepMS);
                } catch (InterruptedException e) {
                    logError(CustomMessageRepository.NA49131_errorMessage(massIssueFa.getId().toString(), e.getMessage()));
                }
            }
            
            if(isInError.isFalse()){
                return true;
            } else {
                return false;
            }
        }
        
        /**
         * This method retrieves the maximum sequence number of the Field Activity and Characteristic Type 
         * @param faId - Field Activity
         * @param charType - Characteristic Type
         * @return maxSequence - BigInteger
         */
        private BigInteger retrieveFACharMaxSequence(FieldActivity_Id faId, CharacteristicType charType){
            // Check if Field Activity characteristic exists, if exists, get the sequence number.
            StringBuilder queryString = new StringBuilder();

            queryString.append("SELECT MAX(SEQ_NUM) AS MAX_SEQ ");
            queryString.append("FROM CI_FA_CHAR ");
            queryString.append("WHERE FA_ID = :faId ");
            queryString.append( "AND CHAR_TYPE_CD = :charType ");

            PreparedStatement getMaxSequence = createPreparedStatement(queryString.toString(), getClass().getName());

            getMaxSequence.bindEntity("charType", charType);
            getMaxSequence.bindId("faId", faId);

            BigInteger faCharSequence = getMaxSequence.firstRow().getInteger("MAX_SEQ");                

            getMaxSequence.close();

            return faCharSequence;
        }

    }

}
