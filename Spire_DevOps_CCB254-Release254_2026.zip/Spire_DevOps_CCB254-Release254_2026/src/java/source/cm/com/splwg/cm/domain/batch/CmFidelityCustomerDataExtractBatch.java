/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Extract Customer Data for Fidelity
 * 
 * This batch process is used to send customer data to Fidelity.
 * The batch will extract customer data for accounts in the specified CIS 
 * Division.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2021-05-24	NMendo			CCB031.1. Initial Version.
 * 2021-06-24	GCrisp			CCB031.Issue1. Allow multithreading and add
 *								the thread number at the end of the file 
 *								name before the file extension.
 * 								Add null checker for Account's Billing 
 *								Premise ID.
 **************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.text.DecimalFormat;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.phoneType.PhoneType_Id;
import com.splwg.ccb.api.lookup.BillingAddressSourceLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.common.installation.CcbInstallationHelper;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.data.AccountMailingAddressData;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonPhone;
import com.splwg.cm.api.batch.CmFidelityCustomerDataExtractRecord;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author NMendo
 *
 @BatchJob (multiThreaded = true, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = PHONE_TYPE_CD_LIST, required = true, type = string)})
 */
public class CmFidelityCustomerDataExtractBatch 
		extends CmFidelityCustomerDataExtractBatch_Gen {
	
	// Constants
	private static final String BATCH_PARM_FILE_PATH = "FILE_PATH";
	private static final String BATCH_PARM_PHONE_TYPE_CD_LIST = "PHONE_TYPE_CD_LIST";
	private static final String COMMA = ",";
	
	@Override
	public JobWork getJobWork() {
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT ACCT.ACCT_ID ");
        sb.append("FROM CI_ACCT ACCT ");
        sb.append("WHERE ACCT.CIS_DIVISION = :cisDivision ");
        sb.append("AND EXISTS (SELECT 'X' ");
        sb.append(            "FROM CI_SA SA ");
        sb.append(            "WHERE SA.ACCT_ID = ACCT.ACCT_ID ");
        sb.append(            "AND SA.CIS_DIVISION = ACCT.CIS_DIVISION ");
        sb.append(            "AND SA.SA_STATUS_FLG IN (:pendingStart, :active, :pendingStop, :stopped, :reactivated)) ");
        
        PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
        ps.bindId("cisDivision", getParameters().getCIS_DIVISION().getId());
        ps.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
        ps.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
        ps.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        ps.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
        ps.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
		QueryIterator returnValue = ps.iterate();
		
		return createJobWorkForQueryIterator(returnValue, this);
	}
	
    @Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow qrw) {
		ThreadWorkUnit twu = new ThreadWorkUnit();
		Account_Id accountId = (Account_Id) qrw.getId("ACCT_ID", Account.class);
		twu.setPrimaryId(accountId);		
		return twu;
	}
	
	@Override
	public void validateSoftParameters(boolean arg0) {
		String parmFilePath = getParameters().getFILE_PATH();
		String parmPhoneTypeList = getParameters().getPHONE_TYPE_CD_LIST().trim();
		
		// Validate File Path
		File file = new File(parmFilePath.trim());
		if (!file.isDirectory()) {
			// Batch Parameter %1 value (%2) is not a valid file path.
			addError(CustomMessageRepositorySpireOne.CCB031_1_InvalidFilePath(BATCH_PARM_FILE_PATH, parmFilePath));
		}
		
		// Validate Phone Type List
		String phoneTypeStr = null;
		for (String phoneTypeIdString : parmPhoneTypeList.split(COMMA)) {
			phoneTypeStr = phoneTypeIdString.trim();
			if(phoneTypeStr.length() > PhoneType_Id.FIELD_SIZE) {
				// Batch Parameter %1 contains invalid Phone Type (%2).
				addError(CustomMessageRepositorySpireOne.CCB031_1_InvalidPhoneType(BATCH_PARM_PHONE_TYPE_CD_LIST, phoneTypeStr));
	        }
	           
			PhoneType_Id phoneTypeId = new PhoneType_Id(phoneTypeStr);
	        if(isNull(phoneTypeId.getEntity())) {
				// Batch Parameter %1 contains invalid Phone Type (%2).
				addError(CustomMessageRepositorySpireOne.CCB031_1_InvalidPhoneType(BATCH_PARM_PHONE_TYPE_CD_LIST, phoneTypeStr));
	        }
		}
	}
	
	public Class<CmFidelityCustomerDataExtractBatchWorker> getThreadWorkerClass() {
		return CmFidelityCustomerDataExtractBatchWorker.class;
	}

	public static class CmFidelityCustomerDataExtractBatchWorker extends
			CmFidelityCustomerDataExtractBatchWorker_Gen {
		
    	// Constants
    	private static final String BACKSLASH = "/";
    	private static final String FORWARDSLASH = "\\";
    	private static final String COMMA = ",";
    	private static final String SPACE = " ";
		
		// Work Variables
		private List<PhoneType_Id> priorityPersonPhoneTypeList;
		private String filePathName;
		private BufferedWriter buffWriter;
		private String accountNumber;
		private String customerName;
		private String premiseAddress;
		private String city;
		private String state;
		private String zipCode;
		private String phoneNumber;
		private String acceptChecks;
		
		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
			// Get the parameters
			String parmFilePath = getParameters().getFILE_PATH();
			String parmFileName = getParameters().getFILE_NAME();
			String parmPhoneTypeList = getParameters().getPHONE_TYPE_CD_LIST();
			
			priorityPersonPhoneTypeList = new ArrayList<PhoneType_Id>();
            for (String phoneTypeIdString : parmPhoneTypeList.split(COMMA)) {
                priorityPersonPhoneTypeList.add(new PhoneType_Id(phoneTypeIdString.trim()));
            }
			
			// Create or open the extract file.
			formFilePathName(parmFilePath, parmFileName);
			openFile();
		}
		
		 /**
         * Form File Path Name
         */
        private void formFilePathName(String filePath, String fileName) {
        	// Replace all \ with / and make sure that the file path ends with a /
			if (!filePath.trim().endsWith(FORWARDSLASH)
					&& !filePath.trim().endsWith(BACKSLASH)) {
				filePath = filePath.trim().concat(BACKSLASH);
			}
			filePath = filePath.replace(FORWARDSLASH, BACKSLASH);
			// Start Change - GCrisp - 06-24-2021 - CCB031.Issue1
			//filePathName = filePath.trim().concat(fileName.trim());
			
			//Add Batch thread number at the end of the file name before the file extension
			DecimalFormat decimalFormat = new DecimalFormat("00");
			int periodIndex = fileName.lastIndexOf('.');
			//If filename has file extension
			if(periodIndex > 0){
				String fileNameWithoutFileExtension = fileName.substring(0, fileName.lastIndexOf('.'));
				String fileExtension = fileName.substring(fileName.lastIndexOf('.')).trim();
				
				filePathName = filePath.trim().concat(fileNameWithoutFileExtension.trim())
						.concat(decimalFormat.format(getBatchThreadNumber()).trim().concat(fileExtension));
			//If filename has no file extension
			} else{
				filePathName = filePath.trim().concat(fileName.trim())
						.concat(decimalFormat.format(getBatchThreadNumber()).trim());
			}
			
			// End Change - GCrisp - 06-24-2021 - CCB031.Issue1
		}
        
        /**
         * Open File
         */
		private void openFile() {
			try {
				File file = new File(filePathName);
				FileWriter fileWriter = new FileWriter(file);
				buffWriter = new BufferedWriter(fileWriter);
			} catch (Exception e) { 
				// Error encountered opening file (%1%2%3%4).
				throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB031_1_errorOpeningFile(filePathName));
			}
		}
		
		/**
		 * Write to File
		 * @param stringToWrite
		 */
		private void writeToFile(String stringToWrite) {
			try {
				buffWriter.write(stringToWrite);
				buffWriter.newLine();
			} catch (Exception e) {
				// Error encountered writing to file (%1%2%3%4).
				throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB031_1_errorWritingFile(filePathName));
			}
		}

		/**
		 * Close File
		 */
		private void closeFile() {
			try {
				buffWriter.close();
			} catch (Exception e) {
				// Error encountered closing file (%1%2%3%4).
				throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB031_1_errorClosingFile(filePathName));
			}
		}

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
			// Close the extract file.
			closeFile();
		}

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		@Override
		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			Account_Id accountId = (Account_Id) unit.getPrimaryId();
			deriveExtractValues(accountId);
			constructAndWriteRecord();
			
			return true;
		}
		
		/**
		 * Derive Extract Record values.
		 * @param accountId
		 */
		private void deriveExtractValues(Account_Id accountId) {
			// Initialize variables
			accountNumber = "";
			customerName = "";
			premiseAddress = "";
			city = "";
			state = "";
			zipCode = "";
			phoneNumber = "";
			acceptChecks = "N";
			
			Account account = accountId.getEntity();
			Person person = account.getMainPerson();
			// Start Change - GCrisp - 06-24-2021 - CCB031.Issue1
			//AccountMailingAddressData mailingAddress = account.fetchMailingAddress(person);
			AccountPerson acctPer = new AccountPerson_Id(person, account).getEntity();
			AccountMailingAddressData mailingAddress;
			if(isNull(account.getMailingPremiseId()) &&
					acctPer.getBillAddressSource().equals(BillingAddressSourceLookup.constants.MAILING_PREMISE_ON_ACCOUNT)){
				mailingAddress = null;
			} else{
				mailingAddress = account.fetchMailingAddress(person);
			}
			// End Change - GCrisp - 06-24-2021 - CCB031.Issue1
			accountNumber = "000".concat(accountId.getTrimmedValue());
			
			// Set Customer Name
			customerName = person.getPersonPrimaryName().trim();
			if(person.getPersonOrBusiness().isPerson()){
        		//Split the primary name using comma
        		//this results to an array whose first element is the surname and the last element is the first name
        		String[] entityName = customerName.split(COMMA);
        		
        		if(entityName.length == 2) {
	        		//Store the customer Name in First Name , Last Name format.
	        		customerName = entityName[1].trim().concat(SPACE).concat(entityName[0].trim());
        		}
        	}
			
			// Set Address fields
			if(notNull(mailingAddress)) {
				if(notNull(mailingAddress.getAddress1())) {
					premiseAddress = mailingAddress.getAddress1().trim();
				}
				
				if(notNull(mailingAddress.getCity())) {
					city = mailingAddress.getCity().trim();
				}
				
				if(notNull(mailingAddress.getState())) {
					state = mailingAddress.getState().fetchIdState().trim();
				}
				
				if(notNull(mailingAddress.getPostalCode())) {
					zipCode = mailingAddress.getPostalCode().trim();
				}
			}
			
			// Set Phone Number
			for(PhoneType_Id phoneTypeId : priorityPersonPhoneTypeList) {
				for(PersonPhone personPhone : person.getPhones()) {
					if(phoneTypeId.equals(personPhone.getPhoneType().getId())) {
						phoneNumber = personPhone.getPhone().replaceAll("[^0-9]", "");
						break;
					}
				}
				
				if(!isBlankOrNull(phoneNumber)) {
					break;
				}
			}
			
			// Set Accept Checks
			BigInteger cashOnlyThreshold = CcbInstallationHelper.getCcbInstallationInstance().getCashOnlyThreshold();
			BigInteger accountCashOnlyPoints = account.getCreditRatingInfo(getProcessDateTime().getDate()).getCashOnlyPoints();
			if(accountCashOnlyPoints.compareTo(cashOnlyThreshold) > 0) {
				acceptChecks = "Y";
			}
		}
		
		/**
		 * Construct and Write Extract Record.
		 */
		private void constructAndWriteRecord() {
			CmFidelityCustomerDataExtractRecord record = new CmFidelityCustomerDataExtractRecord();
			record.setAccountNumber(accountNumber);
			record.setCustomerName(customerName);
			record.setPremiseAddress(premiseAddress);
			record.setCity(city);
			record.setState(state);
			record.setZipCode(zipCode);
			record.setPhoneNumber(phoneNumber);
			record.setAcceptChecks(acceptChecks);
			
			writeToFile(record.createRecordString());
		}
	}
}
