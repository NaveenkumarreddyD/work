/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Algorithm - Adjustment Bill Message
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-04-04   RDizon  NM0079. Initial Version.
 * 2013-05-24   SMiran  Defect #1561. Set Allow Bill Reopen to true
 * 2013-06-07   CVB     Add Bill Message only if it does not exist yet.
 * 2016-01-25   MPang	Updated for CCB v2.4 compilation.
 **************************************************************************/

package com.splwg.cm.domain.admin.customerClass;

import java.math.BigInteger;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.currency.Currency;
import com.splwg.ccb.api.lookup.AdjustmentStatusLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;

//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.adjustmentType.AdjustmentTypeCharacteristic;
import com.splwg.ccb.domain.admin.billMessage.BillMessageType;
import com.splwg.ccb.domain.admin.customerClass.CustomerClassBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.BillData;
import com.splwg.ccb.domain.billing.bill.BillMessage;
import com.splwg.ccb.domain.billing.bill.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.BillMessage_Id;
import com.splwg.ccb.domain.billing.bill.Bill_Id;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;*/

import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentTypeCharacteristic;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.customerClass.algorithm.billCompletion.CustomerClassBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.billing.data.BillData;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author redizon
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = adjustmentTypeCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = adjustmentTypeCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = existingAdjustmentBillMessageCode, type = entity)
 *            , @AlgorithmSoftParameter (name = consecutiveNumberOfDays, type = integer)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = billWithoutAdjustmentBillMessageCode, type = entity)})
 */
public class CmAdjustmentBillMessageAlgComp_Impl 
        extends CmAdjustmentBillMessageAlgComp_Gen 
        implements CustomerClassBillCompletionAlgorithmSpot {

    // Soft Parameters
    private CharacteristicType parmAdjustmentTypeCharType;
    private String parmAdjustmentTypeCharValue;
    private BillMessageType parmExistingAdjustmentBillMessageCode;
    private BigInteger parmConsecutiveNumberOfDays;
    private BillMessageType parmBillWithoutAdjustmentBillMessageCode;

    // Hard Parameters
    private Date accountingDate;
    private BillData billData;
    private Date billDate;
    private Currency currency;
    //2013-05-24 SMiran Start
    private Bool shouldAllowBillReopen;
    //2013-05-24 SMiran End

    // Properties
    private Account account;
    private Bill_Id billId;

    public Bool getAllowBillReopen() {
        //2013-05-24 SMiran Start
        //return null;
        return shouldAllowBillReopen;
        //2013-05-24 SMiran End
    }

    public BillData getBillData() {
        return billData;
    }

    public void setAccountingDate(Date accountingDate) {
        this.accountingDate = accountingDate;
    }

    public void setBillData(BillData billData) {
        this.billData = billData;
    }

    public void setBillDate(Date billDate) {
        this.billDate = billDate;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public void invoke() {
        //2013-05-24 SMiran Start
        shouldAllowBillReopen = Bool.TRUE;
        //2013-05-24 SMiran End
        billId = billData.getBillDTO().getId();
        account = billData.getBillDTO().fetchAccount();

        if (notNull(parmExistingAdjustmentBillMessageCode)){
            QueryIterator itrSaOfBillSegments = cmGetServiceAgreementOfBillSegments().iterate();
            while (itrSaOfBillSegments.hasNext()){
                ServiceAgreement sa = (ServiceAgreement) itrSaOfBillSegments.next();

                Query getFrozenAdjustmentOnBill = cmGetFrozenAdjustmentOnBill(sa);
                if (getFrozenAdjustmentOnBill.listSize() > 0){
                    // Create Bill Message if at least 1 associated Adjustment is included in the current Bill
                    cmCreateBillMessage(parmExistingAdjustmentBillMessageCode);
                    itrSaOfBillSegments.close();
                    break;
                }
            }
            
        }

        if (notNull(parmBillWithoutAdjustmentBillMessageCode)){
            Query getFrozenAdjustmentOnAccount = cmGetFrozenAdjustmentOnAccount();
            
            // Create Bill Message if no associated Adjustment exists on the Account for the specific time period
            if (getFrozenAdjustmentOnAccount.listSize() == 0){
                cmCreateBillMessage(parmBillWithoutAdjustmentBillMessageCode);
            }
        }
    }

    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        // Retrieve the Algorithm Parameters
        parmAdjustmentTypeCharType = getAdjustmentTypeCharType();
        parmAdjustmentTypeCharValue = getAdjustmentTypeCharValue();
        parmExistingAdjustmentBillMessageCode = getExistingAdjustmentBillMessageCode();
        parmConsecutiveNumberOfDays = getConsecutiveNumberOfDays();
        parmBillWithoutAdjustmentBillMessageCode = getBillWithoutAdjustmentBillMessageCode();

        if (notNull(parmBillWithoutAdjustmentBillMessageCode) && isNull(parmConsecutiveNumberOfDays)){
            addError(CustomMessageRepositoryMDC.nm0079_ConsecutiveNumberOfDaysIsRequired());            
        }
    }

    /**
     * Create a Bill Message that is of a specific Bill Message Type
     * @param billMessageType BillMessageType
     */
    private void cmCreateBillMessage(BillMessageType billMessageType) {
        
        // CVB - 2013-06-07 - Start
        BillMessage_Id existingBillMessageId = new BillMessage_Id(billMessageType,  billData.getBillDTO().getEntity());
        BillMessage existingBillMessage = existingBillMessageId.getEntity();
        if (isNull(existingBillMessage)){
            // CVB - 2013-06-07 - End
            billData.getBillDTO().getEntity().getMessages().add(new BillMessage_DTO(), billMessageType.getId());
        }

    }

    /**
     * Get the Frozen Adjustment on the Bill with the associated Adjustment Type Characteristic
     * @param sa ServiceAgrement
     * @return query Query
     */
    private Query cmGetFrozenAdjustmentOnBill(ServiceAgreement sa) {
    	
    	Query query = createQuery("FROM FinancialTransaction FT1 "
    			+ "WHERE FT1.serviceAgreement = :serviceAgreement "
    			+ "AND FT1.financialTransactionType = :adjustmentFt "
    			+ "AND FT1.isFrozen = :frozen "
    			+ "AND FT1.billId = ' ' "
    			+ "AND EXISTS (SELECT ATC.id.adjustmentType FROM AdjustmentTypeCharacteristic ATC "
    			+ "WHERE ATC.id.adjustmentType = FT1.parentId "
    			+ "AND ATC.id.characteristicType = :charType "
    			+ "AND (ATC.characteristicValue = :charValue "
    			+ "OR ATC.adhocCharacteristicValue = :adhocCharValue "
    			+ "OR ATC.characteristicValueForeignKey1 = :charValueFk1)) "
    			+ "AND NOT EXISTS (SELECT FT2.id FROM FinancialTransaction FT2 "
    			+ "WHERE FT2.financialTransactionType = :adjustmentCancelFT "

                        //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                        //+ "AND FT2.siblingId = FT1.siblingId)");
                        + "AND FT2.siblingId = FT1.siblingId)" , getClass().getName());
    					//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        query.bindEntity("serviceAgreement", sa);
        query.bindLookup("adjustmentFt", FinancialTransactionTypeLookup.constants.ADJUSTMENT);
        query.bindBoolean("frozen", Bool.TRUE);
        query.bindId("charType", parmAdjustmentTypeCharType.getId());
        query.bindStringProperty("charValue", AdjustmentTypeCharacteristic.properties.characteristicValue, parmAdjustmentTypeCharValue);
        query.bindStringProperty("adhocCharValue", AdjustmentTypeCharacteristic.properties.adhocCharacteristicValue, parmAdjustmentTypeCharValue);
        query.bindStringProperty("charValueFk1", AdjustmentTypeCharacteristic.properties.characteristicValueForeignKey1, parmAdjustmentTypeCharValue);
        query.bindLookup("adjustmentCancelFT", FinancialTransactionTypeLookup.constants.ADJUSTMENT_CANCELLATION);
        query.addResult("ftId", "FT1.id");

        return query;
    }

    /**
     * Get the Frozen Adjustment on the Account with the associated Adjustment Type Characteristic
     * @return query Query
     */
    private Query cmGetFrozenAdjustmentOnAccount() {
        Query query = createQuery("FROM FinancialTransaction FT "
                + "WHERE FT.financialTransactionType = :adjustmentFt "
                + "AND FT.freezeDateTime > :adjustedProcessDate "
                + "AND EXISTS (SELECT B.id FROM Bill B "
                        + "WHERE B.account = :account "
                        + "AND B.id = FT.billId) "
                + "AND EXISTS (SELECT ADJ.id FROM Adjustment ADJ "
                        + "WHERE ADJ.id = FT.siblingId "
                        + "AND ADJ.adjustmentStatus = :frozenStatus) "
                + "AND EXISTS (SELECT ATC.id.adjustmentType FROM AdjustmentTypeCharacteristic ATC "
                        + "WHERE ATC.id.adjustmentType = FT.parentId "
                        + "AND ATC.id.characteristicType = :charType "
                        + "AND (ATC.characteristicValue = :charValue "
                            + "OR ATC.adhocCharacteristicValue = :adhocCharValue "
                        
                          //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                          //  + "OR ATC.characteristicValueForeignKey1 = :charValueFk1))");
                          + "OR ATC.characteristicValueForeignKey1 = :charValueFk1))" , getClass().getName());
        				//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        
        query.bindEntity("account", account);
        query.bindDate("adjustedProcessDate", getProcessDateTime().getDate().addDays(parmConsecutiveNumberOfDays.negate().intValue()));
        query.bindLookup("adjustmentFt", FinancialTransactionTypeLookup.constants.ADJUSTMENT);
        query.bindLookup("frozenStatus", AdjustmentStatusLookup.constants.FROZEN);
        query.bindId("charType", parmAdjustmentTypeCharType.getId());
        query.bindStringProperty("charValue", AdjustmentTypeCharacteristic.properties.characteristicValue, parmAdjustmentTypeCharValue);
        query.bindStringProperty("adhocCharValue", AdjustmentTypeCharacteristic.properties.adhocCharacteristicValue, parmAdjustmentTypeCharValue);
        query.bindStringProperty("charValueFk1", AdjustmentTypeCharacteristic.properties.characteristicValueForeignKey1, parmAdjustmentTypeCharValue);
        query.addResult("ftId", "FT.id");
        
        return query;
    }

    /**
     * Get the Service Agreement of the Bill Segments 
     * @return query Query
     */
    private Query cmGetServiceAgreementOfBillSegments() {
    	Query query = createQuery("FROM BillSegment BS "
    			//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
    			//+ "WHERE BS.billId = :billId ");
    			+ "WHERE BS.billId = :billId " , getClass().getName());
    			//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
    	
    	query.bindId("billId", billId);
    	query.addResult("sa", "BS.serviceAgreement");

        return query;
    }
}