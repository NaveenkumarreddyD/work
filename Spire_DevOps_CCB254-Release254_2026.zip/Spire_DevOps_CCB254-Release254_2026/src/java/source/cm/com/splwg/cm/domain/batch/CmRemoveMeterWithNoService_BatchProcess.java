/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Remove Meter with no service for 18+ months
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2012-06-09   Rakesh          NI0018.8. Initial Version.
 * 2013-08-08   Srikanth        IM-033059 - Remove FA Incorrectly Created.
 * 2015-08-07   SMiranda		Defect 3264772. Added parameter to be able to filter by
 * 								CIS Division.
 * 2016-01-29  	MPang			Updated for CCB v2.4 compilation. 
 ******************************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.ListFilter;

import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;

import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_Id;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_LanguageId;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
//2015-08-07. SMiranda. Defect 3264772. Start Add
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
//2015-08-07. SMiranda. Defect 3264772. End Add
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityCreatedByLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointMeterEventTypeLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*//2015-08-07. SMiranda. Defect 3264772. Start Add
import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
//2015-08-07. SMiranda. Defect 3264772. End Add
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristics;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_DTO;*/

import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristics;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;

// 2015-08-07. SMiranda. Defect 3264772. Start Change
///**
// *
// @BatchJob (modules = {}
// *      ,multiThreaded = true, rerunnable = false,
// *      softParameters = { @BatchJobSoftParameter (entityName = fieldActivityType, name = METER_REMOVE_FA_TYPE, type = entity)
// *            , @BatchJobSoftParameter (name = NBR_OF_DAYS_SA_INACTIVE, required = true, type = integer)
// *            , @BatchJobSoftParameter (name = MAX_NBR_OF_FA_CREATED, type = integer)
// *            , @BatchJobSoftParameter (name = FA_SCHED_ADJ_DATE_NBR_OF_DAYS, required = true, type = integer)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = REMOVE_RSN_CODE_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = REMOVE_RSN_CODE_CHAR_VAL, required = true, type = string)
// *            }
// *            )
// */
/**
*
@BatchJob (modules = {}
*      ,multiThreaded = true, rerunnable = false,
*      softParameters = { @BatchJobSoftParameter (entityName = fieldActivityType, name = METER_REMOVE_FA_TYPE, type = entity)
*            , @BatchJobSoftParameter (name = NBR_OF_DAYS_SA_INACTIVE, required = true, type = integer)
*            , @BatchJobSoftParameter (name = MAX_NBR_OF_FA_CREATED, type = integer)
*            , @BatchJobSoftParameter (name = FA_SCHED_ADJ_DATE_NBR_OF_DAYS, required = true, type = integer)
*            , @BatchJobSoftParameter (entityName = characteristicType, name = REMOVE_RSN_CODE_CHAR_TYPE, required = true, type = entity)
*            , @BatchJobSoftParameter (name = REMOVE_RSN_CODE_CHAR_VAL, required = true, type = string)
*            , @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = false, type = entity)
*            }
*            )
*/
//2015-08-07. SMiranda. Defect 3264772. End Change

public class CmRemoveMeterWithNoService_BatchProcess 
extends CmRemoveMeterWithNoService_BatchProcess_Gen {


	//  Soft Parameters
	// 2015-08-07. SMiranda. Defect 3264772. Start Change
	//private static FieldActivityType parmFieldActivityType;
	//private static BigInteger parmNumOfDaysSAInactive;
	//private static BigInteger parmMaxNumFaCreated;
	//private static BigInteger parmFASchedNumDays;
	//private static CharacteristicType parmRemovalReasonCharType;
	//private static String parmRemovalReasonCharValue;
	//private static BigInteger threadCount;
	//private static BigInteger maxFACreated;
	private FieldActivityType parmFieldActivityType;
	private BigInteger parmNumOfDaysSAInactive;
	private BigInteger parmMaxNumFaCreated;
	private BigInteger parmFASchedNumDays;
	private CharacteristicType parmRemovalReasonCharType;
	private String parmRemovalReasonCharValue;
	private BigInteger threadCount;
	private CisDivision parmCisDivision;
	// 2015-08-07. SMiranda. Defect 3264772. End Change

	// Class Variables
	// 2015-08-07. SMiranda. Defect 3264772. Start Change
	//private static Date thresholdDate;
	private Date thresholdDate;
	// 2015-08-07. SMiranda. Defect 3264772. End Change	
	// 2015-08-07. SMiranda. Defect 3264772. Start Delete
	//private static BigInteger numberOfRecordsRead = BigInteger.ZERO;

	//private static List<SQLResultRow> eligibleMetersList;
	// 2015-08-07. SMiranda. Defect 3264772. End Delete

	public void validateSoftParameters(boolean isNewRun){

		BigInteger parmMaxErrors = getParameters().getSoftMaxErrors();
		CharacteristicEntity charEntity = null;

		if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
			addError(CustomMessageRepository.ni0018_8MaxErrorIsInvalid(parmMaxErrors.toString().trim()));
		}

		parmFieldActivityType = getParameters().getMETER_REMOVE_FA_TYPE();

		parmNumOfDaysSAInactive = getParameters().getNBR_OF_DAYS_SA_INACTIVE();
		validateNumericParameter(getBatchParameterName(BigInteger.valueOf(30)), parmNumOfDaysSAInactive);
	
		parmMaxNumFaCreated = getParameters().getMAX_NBR_OF_FA_CREATED();
		if(isNull(parmMaxNumFaCreated)){
			parmMaxNumFaCreated = BigInteger.valueOf(99999999);
		}
		validateNumericParameter(getBatchParameterName(BigInteger.valueOf(40)), parmMaxNumFaCreated);

		parmFASchedNumDays = getParameters().getFA_SCHED_ADJ_DATE_NBR_OF_DAYS();
		validateNumericParameter(getBatchParameterName(BigInteger.valueOf(50)), parmFASchedNumDays);

		parmRemovalReasonCharType = getParameters().getREMOVE_RSN_CODE_CHAR_TYPE();
		charEntity = new CharacteristicEntity_Id(parmRemovalReasonCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY).getEntity();
		if(isNull(charEntity)){
			addError(CustomMessageRepository.ni0018_8InvalidCharType(parmRemovalReasonCharType.getId().getIdValue().trim(),CharacteristicEntityLookup.constants.FIELD_ACTIVITY.toString()));
		}

		parmRemovalReasonCharValue = getParameters().getREMOVE_RSN_CODE_CHAR_VAL();
		
		// 2015-08-07. SMiran. Defect 3264772. Start Add
		CharacteristicValue_Id charValueId = new CharacteristicValue_Id(parmRemovalReasonCharType, parmRemovalReasonCharValue);
		if (isNull(charValueId.getEntity())){
			addError(CustomMessageRepository.ni0018_8InvalidInputCharValue(parmRemovalReasonCharValue));
		}
		// 2015-08-07. SMiran. Defect 3264772. End Add
		try {
			thresholdDate = getProcessDateTime().getDate().addDays(parmNumOfDaysSAInactive.negate().intValue());
		} catch (RuntimeException e) {
			addError(CustomMessageRepository.ni0018_8InvalidThresholdDate());
			e.printStackTrace();
		}

		threadCount = getParameters().getThreadCount();
		
		if(parmMaxNumFaCreated.intValue() < threadCount.intValue()){
			addError(CustomMessageRepository.ni0018_8ThreadCountGreaterThanMaxFA(threadCount,parmMaxNumFaCreated));
		}
		
		// 2015-08-07. SMiran. Defect 3264772. Start Add
		parmCisDivision = getParameters().getCIS_DIVISION();
		// 2015-08-07. SMiran. Defect 3264772. End Add
		
	}

	public void validateNumericParameter(String parameterName, BigInteger value){
		if (notNull(value) && value.intValue() < 0) {
			addError(CustomMessageRepository.ni0018_8NumberParamterInvalid(parameterName));
		}
	}

	private String getBatchParameterName(BigInteger paramSeq){

		String paramName = "";      		    
		BatchControlParameter_Id batchparameterId = new BatchControlParameter_Id(getBatchControlId(),paramSeq);
		BatchControlParameter_LanguageId batchParameterLanguageId = new BatchControlParameter_LanguageId(batchparameterId,getActiveContextLanguage().getId());
		paramName = batchParameterLanguageId.getParent().getBatchParameterName();
		return paramName;
	}



	public JobWork getJobWork() {

		// 2015-08-07. SMiranda. Defect 3264772. Start Change
		//getEligibleMetersToRemove();
		List<SQLResultRow> eligibleMetersList = getEligibleMetersToRemove();
		// 2015-08-07. SMiranda. Defect 3264772. End Change

		ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ServicePoint_Id spId;

		for(SQLResultRow resultSPRow : eligibleMetersList){
			spId = (ServicePoint_Id)resultSPRow.getId("SP_ID", ServicePoint.class);
			ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
			threadWorkUnit.setPrimaryId(spId);
			arrayList.add(threadWorkUnit);
		}
		// 2015-08-07. SMiranda. Defect 3264772. Start Delete
		//maxFACreated = parmMaxNumFaCreated.divide(threadCount);
		// 2015-08-07. SMiranda. Defect 3264772. End Delete
		return createJobWorkForThreadWorkUnitList(arrayList);
	}
	
	// 2015-08-07. SMiranda. Defect 3264772. Start Change
	//private void getEligibleMetersToRemove(){
	private List<SQLResultRow> getEligibleMetersToRemove(){
	// 2015-08-07. SMiranda. Defect 3264772. End Change
		StringBuilder getSPMeterString = new StringBuilder();
		// 2015-08-07. SMiranda. Defect 3264772. Start Change
		//getSPMeterString.append("SELECT HIST.SP_ID ");
		//getSPMeterString.append("FROM CI_SP_MTR_EVT EVNT, CI_SP SP, CI_MR MR ");
		//getSPMeterString.append(", CI_SP_MTR_HIST HIST ");
		//getSPMeterString.append("WHERE HIST.SP_ID = SP.SP_ID ");
		//getSPMeterString.append("AND EVNT.SP_MTR_EVT_FLG  = :spInstallFlag "); 
		//getSPMeterString.append("AND EVNT.MR_ID = MR.MR_ID ");
		//getSPMeterString.append("AND MR.READ_DTTM <= :thresholdDate ");
		//getSPMeterString.append("AND HIST.SP_MTR_HIST_ID  = EVNT.SP_MTR_HIST_ID ");
		// //  IM-033059 //
		////getSPMeterString.append("AND (HIST.REMOVAL_DTTM  IS NULL OR HIST.REMOVAL_DTTM >= :thresholdDate) ");
		//getSPMeterString.append("AND (HIST.REMOVAL_DTTM  IS NULL OR TRUNC(HIST.REMOVAL_DTTM) > :processDt) ");
		//getSPMeterString.append("AND EXISTS (  SELECT 'X'  FROM CI_SA_SP SASP, CI_SA SA  ");
		//getSPMeterString.append("        WHERE SASP.SP_ID = SP.SP_ID ");
		//getSPMeterString.append("        AND SASP.SA_ID =  SA.SA_ID  ");
		//getSPMeterString.append("        AND SA.END_DT <= :thresholdDate ");
		//getSPMeterString.append("        AND SA.START_DT = (SELECT MAX(SA1.START_DT) FROM CI_SA_SP SASP1, CI_SA SA1 ");
		//getSPMeterString.append("                WHERE SASP1.SP_ID = SASP.SP_ID ");
		//getSPMeterString.append("                AND SASP1.SA_ID = SA1.SA_ID ");
		//getSPMeterString.append("                )");
		//getSPMeterString.append("           ) ");
		//getSPMeterString.append(" AND NOT EXISTS (  SELECT 'X' FROM CI_FA FA  ");
		//getSPMeterString.append(" WHERE FA.SP_ID =  SP.SP_ID  ");
		//getSPMeterString.append(" AND FA.FA_TYPE_CD = :meterRemoveFATypeCode  ");
		//getSPMeterString.append(" AND FA.FA_STATUS_FLG =  :pending ");
		//getSPMeterString.append(" ) ");
		getSPMeterString.append(" SELECT ");
		getSPMeterString.append("	SPMH.SP_ID ");
		getSPMeterString.append(" FROM ");
		getSPMeterString.append("	CI_SP_MTR_HIST SPMH ");
		getSPMeterString.append("	, CI_SP_MTR_EVT SPME ");
		getSPMeterString.append("	, CI_MR MR ");
		if (notNull(parmCisDivision)){
			getSPMeterString.append("	, CI_SP SP ");
			getSPMeterString.append("	, CI_PREM PREM ");
		}
		getSPMeterString.append(" WHERE ");
		getSPMeterString.append("	(SPMH.REMOVAL_DTTM IS NULL OR SPMH.REMOVAL_DTTM > :processDt) ");
		getSPMeterString.append("	AND SPME.SP_MTR_HIST_ID = SPMH.SP_MTR_HIST_ID ");
		getSPMeterString.append("	AND SPME.SP_MTR_EVT_FLG = :spInstallFlag ");
		getSPMeterString.append("	AND MR.MR_ID = SPME.MR_ID ");
		getSPMeterString.append("	AND MR.READ_DTTM <= :thresholdDate ");
		getSPMeterString.append("	AND NOT EXISTS (SELECT 'X' ");
		getSPMeterString.append("					FROM CI_SA_SP SASP, CI_SA SA ");
		getSPMeterString.append("					WHERE SASP.SP_ID = SPMH.SP_ID ");
		getSPMeterString.append("					AND SA.SA_ID = SASP.SA_ID ");
		getSPMeterString.append("					AND (SA.END_DT IS NULL OR SA.END_DT > :thresholdDate)) ");
		getSPMeterString.append("	AND NOT EXISTS (SELECT 'X' ");
		getSPMeterString.append("					FROM CI_FA FA ");
		getSPMeterString.append("					WHERE FA.SP_ID = SPMH.SP_ID ");
		getSPMeterString.append("					AND FA.FA_TYPE_CD = :meterRemoveFATypeCode ");
		getSPMeterString.append("					AND FA.FA_STATUS_FLG = :pending) ");
		if (notNull(parmCisDivision)){
			getSPMeterString.append("	AND SP.SP_ID = SPMH.SP_ID ");
			getSPMeterString.append("	AND PREM.PREM_ID = SP.PREM_ID ");
			getSPMeterString.append("	AND PREM.CIS_DIVISION = :cisDivision ");
		}
		// 2015-08-07. SMiranda. Defect 3264772. End Change

		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement spPrepStmt = createPreparedStatement(getSPMeterString.toString()); 
		PreparedStatement spPrepStmt = createPreparedStatement(getSPMeterString.toString(), getClass().getName()); 
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		spPrepStmt.bindLookup("spInstallFlag", ServicePointMeterEventTypeLookup.constants.INSTALL);
		spPrepStmt.bindDate("thresholdDate", thresholdDate);
	     //  IM-033059 //
		spPrepStmt.bindDate("processDt", getProcessDateTime().getDate());
		spPrepStmt.bindId("meterRemoveFATypeCode", parmFieldActivityType.getId());
		spPrepStmt.bindLookup("pending", FieldActivityStatusLookup.constants.PENDING);
		// 2015-08-07. SMiranda. Defect 3264772. Start Add
		if (notNull(parmCisDivision)){
			spPrepStmt.bindEntity("cisDivision", getParameters().getCIS_DIVISION());
		}
		// 2015-08-07. SMiranda. Defect 3264772. End Add

		// 2015-08-07. SMiranda. Defect 3264772. Start Change
		//eligibleMetersList = spPrepStmt.list();
		List<SQLResultRow> eligibleMetersList = spPrepStmt.list();
		// 2015-08-07. SMiranda. Defect 3264772. End Change
		spPrepStmt.close();
		
		// 2015-08-07. SMiranda. Defect 3264772. Start Add
		return eligibleMetersList;
		// 2015-08-07. SMiranda. Defect 3264772. End Add
	}

	public Class<CmRemoveMeterWithNoService_BatchProcessWorker> getThreadWorkerClass() {
		return CmRemoveMeterWithNoService_BatchProcessWorker.class;
	}

	public static class CmRemoveMeterWithNoService_BatchProcessWorker
	extends CmRemoveMeterWithNoService_BatchProcessWorker_Gen {

		BigInteger numberOfRecordsWithinThread ;
		BigInteger numberOfFAWithinThread ;
		BigInteger numberOfRecordsErrored;
		
		// 2015-08-07. SMiranda. Defect 3264772. Start Add
		private FieldActivityType parmFieldActivityType;
		private BigInteger parmMaxNumFaCreated;
		private BigInteger parmFASchedNumDays;
		private CharacteristicType parmRemovalReasonCharType;
		private String parmRemovalReasonCharValue;
		@SuppressWarnings("unused")
		private BigInteger maxErrors;
		// 2015-08-07. SMiranda. Defect 3264772. End Add
		/**
		 * This method identifies the execution strategy to be used for the thread.
		 * 
		 * @return an instance of ThreadExecutionStrategy that governs how this ThreadWorker will be executed at runtime.
		 * @see com.splwg.base.api.batch.ThreadWorker#createExecutionStrategy()
		 */
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new CommitEveryUnitStrategy(this);
		}



		/* (non-Javadoc)
		 * @see com.splwg.base.api.batch.AbstractThreadWorker#initializeThreadWork(boolean)
		 */
		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
			numberOfFAWithinThread = BigInteger.ZERO;
			numberOfRecordsWithinThread = BigInteger.ZERO;
			numberOfRecordsErrored = BigInteger.ZERO;
			
			// 2015-08-07. SMiranda. Defect 3264772. Start Add
			parmFieldActivityType = getParameters().getMETER_REMOVE_FA_TYPE();
			parmMaxNumFaCreated = getParameters().getMAX_NBR_OF_FA_CREATED();
			if(isNull(parmMaxNumFaCreated)){
				parmMaxNumFaCreated = BigInteger.valueOf(99999999);
			}
			parmFASchedNumDays = getParameters().getFA_SCHED_ADJ_DATE_NBR_OF_DAYS();
			parmRemovalReasonCharType = getParameters().getREMOVE_RSN_CODE_CHAR_TYPE();
			parmRemovalReasonCharValue = getParameters().getREMOVE_RSN_CODE_CHAR_VAL();
			maxErrors = getParameters().getSoftMaxErrors();
			// 2015-08-07. SMiranda. Defect 3264772. End Add
		}



		/**
		 * Execute a WorkUnit and provide result details.
		 * 
		 * @param unit - a ThreadWorkUnit
		 * @return a boolean that describes the success or failure of the work unit processing.
		 * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
		 * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
		 * @see com.splwg.base.api.batch.ThreadWorker#executeWorkUnit(com.splwg.base.api.batch.ThreadWorkUnit)
		 */
		public boolean executeWorkUnit(ThreadWorkUnit unit)
		throws ThreadAbortedException, RunAbortedException {

			ServicePoint_Id  spId  = (ServicePoint_Id)unit.getPrimaryId();
			// 2015-08-07. SMiranda. Defect 3264772. Start Delete
			//numberOfRecordsRead = numberOfRecordsRead.add(BigInteger.ONE);
			// 2015-08-07. SMiranda. Defect 3264772. End Delete
			numberOfRecordsWithinThread = numberOfRecordsWithinThread.add(BigInteger.ONE);

			// 2015-08-07. SMiranda. Defect 3264772. Start Change
			//if (numberOfFAWithinThread.intValue() < maxFACreated.intValue()) {
			if (numberOfFAWithinThread.intValue() < parmMaxNumFaCreated.intValue()){
			// 2015-08-07. SMiranda. Defect 3264772. End Change				
				processEligibleServicePointRecords(spId);
			}
			return true;


		}

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {

			logMessage(CustomMessageRepository.ni0018_8NoOfFACreated(numberOfFAWithinThread), MessageSeverityLookup.constants.INFORMATIONAL);
			logMessage(CustomMessageRepository.ni0018_8NoOfRecordsProcessed(numberOfRecordsWithinThread), MessageSeverityLookup.constants.INFORMATIONAL);
			logMessage(CustomMessageRepository.ni0018_8RecordsErrored(numberOfRecordsErrored), MessageSeverityLookup.constants.INFORMATIONAL);

		}

		private void processEligibleServicePointRecords(ServicePoint_Id spId){


				try {
					FieldActivity_DTO fieldActivityDTO = (FieldActivity_DTO)createDTO(FieldActivity.class);
					fieldActivityDTO.setFieldActivityTypeId(parmFieldActivityType.getId());
					fieldActivityDTO.setServicePointId(spId);
					fieldActivityDTO.setScheduleDateTimeStart(getProcessDateTime().startOfDay().addDays(parmFASchedNumDays.intValue()));
					fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.BACKGROUND);
					FieldActivityCreatorData faCreatorData = FieldActivityCreatorData.Factory.newInstance();
					faCreatorData.setFaDTO(fieldActivityDTO);

					FieldActivityCreator faCreator = FieldActivityCreator.Factory.newInstance();
					FieldActivity fa = faCreator.addFieldActivity(faCreatorData);
					createCharOnFA(fa);
					numberOfFAWithinThread = numberOfFAWithinThread.add(BigInteger.ONE);
				} catch (ApplicationError appError) {
					numberOfRecordsErrored = numberOfRecordsErrored.add(BigInteger.ONE);
					// 2015-08-07. SMiranda. Defect 3264772. Start Change
					//logMessage(CustomMessageRepository.ni0018_8FACreationError(appError.getServerMessage().getMessageText()), MessageSeverityLookup.constants.INFORMATIONAL);
					addError(CustomMessageRepository.ni0018_8FACreationError(appError.getServerMessage().getMessageText()));
					// 2015-08-07. SMiranda. Defect 3264772. End Change
				}
				
		
		}

		private void createCharOnFA(FieldActivity fieldActivity){

			FieldActivityCharacteristics faCharacteristics = fieldActivity.getCharacteristics();
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//ListFilter<FieldActivityCharacteristic> faCharListFilter = fieldActivity.getCharacteristics().createFilter(" WHERE this.id.characteristicType = :characteristicType ");
			ListFilter<FieldActivityCharacteristic> faCharListFilter = fieldActivity.getCharacteristics().createFilter(
					" WHERE this.id.characteristicType = :characteristicType ", getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			faCharListFilter.bindEntity("characteristicType",parmRemovalReasonCharType	);

			FieldActivityCharacteristic_DTO faCharacteristicDTO = faCharacteristics.newChildDTO();
			CharacteristicTypeLookup charTypeLookup = parmRemovalReasonCharType.getCharacteristicType();

			faCharacteristicDTO.setId(new FieldActivityCharacteristic_Id(fieldActivity, parmRemovalReasonCharType, BigInteger.valueOf(faCharListFilter.listSize() +1)));
			if(charTypeLookup.isAdhocValue()){
				faCharacteristicDTO.setAdhocCharacteristicValue(parmRemovalReasonCharValue);
			} else if (charTypeLookup.isPredefinedValue()){
				faCharacteristicDTO.setCharacteristicValue(parmRemovalReasonCharValue);
			} else if (charTypeLookup.isForeignKeyValue()){
				faCharacteristicDTO.setCharacteristicValueForeignKey1(parmRemovalReasonCharValue);
			}
			FieldActivityCharacteristic faChar = faCharacteristicDTO.newEntity();
			faCharacteristics.add(faChar);
		}
	}
}
