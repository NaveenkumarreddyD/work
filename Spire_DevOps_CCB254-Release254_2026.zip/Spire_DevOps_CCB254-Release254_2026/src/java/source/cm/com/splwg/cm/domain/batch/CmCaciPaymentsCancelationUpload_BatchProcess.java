/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * CACI Payment Cancellation Batch
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-03-25   MLekkala NI0040.4. Initial Version.
 * 2013-06-25   Srikanth SD20131806 - Defect 2142 - CR 104  - Missing Context Values
 * 2013-09-06   Srikanth IM-036746 - CACI Payment Cancellation - 
 *                       Incorrect File Trailer batch and Item Count
 * 2015-08-26	JHERNA	 3294040 - Updated code to remove usage of global static
 *                       variables. 
 * 2016-01-27	MPang	 Updated for CCB v2.4 compilation.                                           
 *************************************************************************
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;


import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.lookup.NotificationUploadContextLookup;
import com.splwg.base.api.lookup.NotificationUploadExtensionLookup;
import com.splwg.base.api.lookup.NotificationUploadStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.workflow.notificationExternalId.NotificationExternalId_Id;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadContext_DTO;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadContext_Id;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload_DTO;
import com.splwg.base.domain.workflow.notificationUploadExtensionType.NotificationUploadExtensionType;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
//Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.paymentCancelReason.PaymentCancelReason;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;*/
import com.splwg.ccb.domain.admin.paymentCancelReason.entity.PaymentCancelReason;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
//End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 *
 @BatchJob (
 *		modules = {},
 *      multiThreaded = false, rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PAYMENT_SOURCE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = BATCH_TYPE, required = true, type = integer)
 *            , @BatchJobSoftParameter (name = COMPANY_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = notificationUploadExtensionType,name = NOTIF_XTYPE_FLG, required = true, type = entity)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = CUST_CTXT_TYPE_FLG, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = TAMT_CTXT_TYPE_FLG, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = XREF_CTXT_TYPE_FLG, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = CNRC_CTXT_TYPE_FLG, required = true, type = lookup)
 *            , @BatchJobSoftParameter (entityName = paymentCancelReason, name = CAN_RSN_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = OPYD_CTXT_TYPE_FLG, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = OBNM_CTXT_TYPE_FLG, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = PYRD_CTXT_TYPE_FLG, required = true, type = lookup)
 *            })
 */
public class CmCaciPaymentsCancelationUpload_BatchProcess extends
CmCaciPaymentsCancelationUpload_BatchProcess_Gen {

	// START DELETE - JHERNA - 2015-08-26 - 3294040
	/*
	//	 Soft Parameters
	private static String parmFilePath;
	private static String parmFileName;
	private static String parmPaymentSource;
	private static BigInteger parmBatchType;
	private static String parmCompanyName;
	private static NotificationUploadExtensionType parmNotificationType;
	private static NotificationUploadContextLookup parmAcctIdNotificationContextType;
	private static NotificationUploadContextLookup parmTenderAmountNotificationContextType;
	private static NotificationUploadContextLookup parmExternalPayIdNotificationContextType;
	private static NotificationUploadContextLookup parmCancelReasonNotificationContextType;
	private static NotificationUploadContextLookup parmOriginalPayDateContextType;
	private static NotificationUploadContextLookup parmOriginalPayBatchNumContextType;
	private static NotificationUploadContextLookup parmPayReturnDateContextType;
	
	private static PaymentCancelReason parmPaymentCancelReason;
	private static BigInteger parmMaxErrors;
	*/
	// END DELETE - JHERNA - 2015-08-26 - 3294040
	//Working variables

	public JobWork getJobWork() {
		ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
		arrayList.add(threadWorkUnit);
		return createJobWorkForThreadWorkUnitList(arrayList);

	}

	public void validateSoftParameters(boolean arg0){
		// START CHANGE - JHERNA - 2015-08-26 - 3294040
		/*
		// Get all parameter value
		parmFilePath = getParameters().getFILE_PATH().trim();

		// Validate whether the file path exists or not
		File folder = new File(parmFilePath);
		if(!(folder.exists() && folder.isDirectory())) {
			addError(CustomMessageRepository.ni0040_4FilePathInvalid(parmFilePath));
		}

		parmFileName = getParameters().getFILE_NAME().trim();

		File inputFile = new File(parmFilePath, parmFileName);
		if(!inputFile.exists() || !inputFile.canRead()){
			addError(CustomMessageRepository.ni0040_4InvalidFileName(parmFileName)); 
		} 

		parmPaymentSource = getParameters().getPAYMENT_SOURCE();
		parmBatchType = getParameters().getBATCH_TYPE();
		parmCompanyName = getParameters().getCOMPANY_NAME().trim();
		parmNotificationType = getParameters().getNOTIF_XTYPE_FLG();
		parmAcctIdNotificationContextType = getParameters().getCUST_CTXT_TYPE_FLG();
		parmTenderAmountNotificationContextType = getParameters().getTAMT_CTXT_TYPE_FLG();
		parmExternalPayIdNotificationContextType = getParameters().getXREF_CTXT_TYPE_FLG();
		parmCancelReasonNotificationContextType = getParameters().getCNRC_CTXT_TYPE_FLG();
		parmPaymentCancelReason = getParameters().getCAN_RSN_CD();
		parmMaxErrors = getParameters().getSoftMaxErrors();
		
		// SD20131806 - CR104
	
		parmOriginalPayDateContextType =  getParameters().getOPYD_CTXT_TYPE_FLG();
		parmOriginalPayBatchNumContextType = getParameters().getOBNM_CTXT_TYPE_FLG();
		parmPayReturnDateContextType =getParameters().getPYRD_CTXT_TYPE_FLG();
		// Check if the override maximum errors is less than 0 
		if (notNull(getParameters().getSoftMaxErrors()) && getParameters().getSoftMaxErrors().intValue() < 0) {
			addError(CustomMessageRepository.ni0040_4MaxErrorInvalid(parmMaxErrors.toString())); 
		}
		*/
		// Get all parameter value
		String parmFilePath = getParameters().getFILE_PATH().trim();

		// Validate whether the file path exists or not
		File folder = new File(parmFilePath);
		if(!(folder.exists() && folder.isDirectory())) {
			addError(CustomMessageRepository.ni0040_4FilePathInvalid(parmFilePath));
		}

		String parmFileName = getParameters().getFILE_NAME().trim();

		File inputFile = new File(parmFilePath, parmFileName);
		if(!inputFile.exists() || !inputFile.canRead()){
			addError(CustomMessageRepository.ni0040_4InvalidFileName(parmFileName)); 
		} 

		BigInteger parmMaxErrors = getParameters().getSoftMaxErrors();
		
		// Check if the override maximum errors is less than 0 
		if (notNull(getParameters().getSoftMaxErrors()) && getParameters().getSoftMaxErrors().intValue() < 0) {
			addError(CustomMessageRepository.ni0040_4MaxErrorInvalid(parmMaxErrors.toString())); 
		}
		// END CHANGE - JHERNA - 2015-08-26 - 3294040
	}

	public Class<CmCaciPaymentsCancelationUpload_BatchProcessWorker> getThreadWorkerClass() {
		return CmCaciPaymentsCancelationUpload_BatchProcessWorker.class;
	}

	public static class CmCaciPaymentsCancelationUpload_BatchProcessWorker
	extends
	CmCaciPaymentsCancelationUpload_BatchProcessWorker_Gen {

		// CONSTANT NAMES
		private static final int RECORD_TYPE_INDEX = 0;
		private static final int RECORD_TYPE_LENGTH = 1;

		private static final String SAVE_POINT = "CACI_PAY_CANCEL";


		private static final String CONST_RECORD_TYPE = "RECORD TYPE";
		private static final String CONST_PAYMENT_SOURCE = "PAYMENT SOURCE";
		private static final String CONST_COMPANY_NAME = "COMPANY NAME";
		private static final String CONST_FILE_DATE = "FILE DATE";
		private static final String CONST_TRAILER_DATE = "TRAILER DATE";
		private static final String CONST_BATCH_NUM = "BATCH NUMBER";
		private static final String CONST_BATCH_TYPE = "BATCH TYPE";
		private static final String CONST_AMOUNT_PAID = "AMOUNT PAID";
		private static final String CONST_EXT_PAY_ID = "EXTERNAL PAYMENT ID";
		private static final String CONST_DEP_AMT = "BATCH DEPOSIT AMOUNT";
		private static final String CONST_BATCH_COUNT = "BATCH COUNT";
		private static final String CONST_FILE_DEP_AMT = "TOTAL DEPOSIT AMOUNT";
		private static final String CONST_REFERRAL_ID = "REFERRAL ID";
		private static final String CONST_PREMISE_ID = "PREMISE ID";	
		private static final String CONST_ITEM_COUNT = "BATCH ITEM COUNT";
		
		// FILE HEADER 
		private static final String DATETIME_FORMAT_MMDDYYYYHHMMSS = "yyyy-MM-dd HH:mm:ss";
		private static final String DATE_FORMAT_YYYYMMDD = "yyyy-MM-dd";
		private static final String FILE_HEADER_RECORD_TYPE = "A";
		private static final int COMPANY_NAME_INDEX = 2-1;
		private static final int COMPANY_NAME_LENGTH = 11;
		private static final int PAYMENT_SOURCE_INDEX = 17-1;
		private static final int PAYMENT_SOURCE_LENGTH = 17;
		private static final int FILE_DATE_INDEX = 35-1;
		// As we need to consider only upto seconds , we are using the length 19 for file Date
		private static final int FILE_DATE_LENGTH = 19;

		//BATCH HEADER
		private static final String BATCH_HEADER_RECORD_TYPE = "B";
		private static final int BATCH_NUMBER_INDEX = 2-1;
		private static final int BATCH_NUMBER_LENGTH = 5;
		private static final int BATCH_TYPE_INDEX = 7-1;
		private static final int BATCH_TYPE_LENGTH = 1;

		//DETAIL RECORD
		private static final String DETAILS_RECORD_TYPE = "C";
		private static final int PREMISE_ID_INDEX = 26-1;
		private static final int PREMISE_ID_LENGTH = 10;
		private static final int REFERRAL_ID_INDEX = 16-1;
		private static final int REFERRAL_ID_LENGTH = 10;
		private static final int AMOUNT_PAID_INDEX = 36-1; 
		private static final int AMOUNT_PAID_LENGTH = 9;
		private static final int EXT_REF_ID_INDEX = 61-1;
		private static final int EXT_REF_ID_LENGTH = 30;
		// SD20131806 - CR 104
		private static final int PAY_DATE_INDEX = 91-1;
		private static final int PAY_DATE_LENGTH = 10;

		//BATCH TRAILER
		private static final String BATCH_TRAILER_RECORD_TYPE = "D";
		private static final int BATCH_ITEM_COUNT_INDEX = 7-1;
		private static final int BATCH_ITEM_COUNT_LENGTH = 3;
		private static final int BATCH_DEPOSIT_AMT_INDEX = 10-1;
		private static final int BATCH_DEPOSIT_AMT_LENGTH = 14;

		//FILE TRAILER
		private static final String FILE_TRAILER_RECORD_TYPE = "E";
		private static final int TRAILER_DATE_INDEX = 2 -1;
		// As we need to consider only upto seconds , we are using the length 19 for Trailer Date
		private static final int TRAILER_DATE_LENGTH = 19;
		
		// IM-036746 - CACI payment Cancellation - Start
		
   /*	private static final int TOTAL_BATCH_COUNT_INDEX = 28-1;
		private static final int TOTAL_BATCH_COUNT_LENGTH = 4;
		private static final int TOTAL_ITEM_COUNT_INDEX = 32-1;
		private static final int TOTAL_ITEM_COUNT_LENGTH = 5;
		private static final int TOTAL_CANCEL_AMT_INDEX = 37-1;
		private static final int TOTAL_CANCEL_AMT_LENGTH = 14;
	*/
		private static final int TOTAL_BATCH_COUNT_INDEX = 51-1;
		private static final int TOTAL_BATCH_COUNT_LENGTH = 4;
		private static final int TOTAL_ITEM_COUNT_INDEX = 55-1;
		private static final int TOTAL_ITEM_COUNT_LENGTH = 5;
		private static final int TOTAL_CANCEL_AMT_INDEX = 60-1;
		private static final int TOTAL_CANCEL_AMT_LENGTH = 14;
		// IM-036746 - CACI payment Cancellation - End
		


		//Switches to check the order of processing is right
		private Bool isFileHeaderRead = Bool.FALSE;
		private Bool isBatchHeaderRead = Bool.FALSE;
		private Bool isBatchTrailerRead = Bool.FALSE;
		private Bool isFileTrailerRead = Bool.FALSE;
		private Bool isDetailRecordRead = Bool.FALSE;

		// Thread Class Variables
		private CollectionAgencyReferral_Id colReferralAgencyId;
		private CollectionAgencyReferral colReferralAgency;
		private Account account;
		private Premise_Id premiseId;
		private String extRefId;
		private String strPayDate; //SD20131806 - CR 104
		private BigInteger lineCounter = BigInteger.ZERO;
		private BufferedReader inputFile = null;
		@SuppressWarnings("unused")
		private File inputFilePathAndName = null;
		private String fileDateStr = null;
		private String paymentSourceStr = null;
		private DateTime fileDateTime = null;
		private String batchNumber = null;
		private String batchTypeStr = null;
		private BigInteger batchType = BigInteger.ZERO;
		private BigDecimal calculatedTotalPaymentCancelAmount = BigDecimal.ZERO;
		private String referralIdStr = null;
		private String premiseIdStr = null;
		private int batchTrailerRecordCount;
		private int totalBatchCount = 0;
		private int fileTrailerBatchCount;
		private int totalFileRecordCount = 0;
		private int fileTrailerRecordCount;
		private BigInteger numberOfRecordsInError = BigInteger.ZERO;
		private int totalBatchHeaderRecords = 0;
		private int totalBatchTrailerRecords = 0;
		private int totalFileHeaderRecords = 0;
		private int totalFileTrailerRecords = 0;

		// Thread Class Variables
		private int processedRecordsCount = 0;
		private NotificationUpload notificationUpload;
		private NotificationExternalId_Id notificationExternalId;
		private BigDecimal calculatedFileTotalPaymentCancelationAmt = BigDecimal.ZERO;
		private BigDecimal totalBatchPaymentCancellationAmount= BigDecimal.ZERO;
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		// START ADD - JHERNA - 2015-08-26 - 3294040
		private static final Logger LOG = LoggerFactory.getLogger(CmCaciPaymentsCancelationUpload_BatchProcess.class);
		private String parmCompanyName;
		private String parmPaymentSource;
		private BigInteger parmBatchType;
		private NotificationUploadContextLookup parmAcctIdNotificationContextType;
		private NotificationUploadContextLookup parmTenderAmountNotificationContextType;
		private NotificationUploadContextLookup parmExternalPayIdNotificationContextType;
		private NotificationUploadContextLookup parmCancelReasonNotificationContextType;
		private PaymentCancelReason parmPaymentCancelReason;
		private NotificationUploadContextLookup parmPayReturnDateContextType;
		private NotificationUploadContextLookup parmOriginalPayBatchNumContextType;
		private NotificationUploadContextLookup parmOriginalPayDateContextType;
		private NotificationUploadExtensionType parmNotificationType;
		private String parmFilePath; 
		private String parmFileName;
		//Start Add - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
		private static FrameworkSession session;
		//End Add - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
		
		private void cmRetrieveParameters() {
			
			LOG.info("***About to Retrieve Parameters***");
			parmCompanyName = this.getParameters().getCOMPANY_NAME();
			parmPaymentSource = this.getParameters().getPAYMENT_SOURCE();
			parmBatchType = this.getParameters().getBATCH_TYPE();
			parmAcctIdNotificationContextType = this.getParameters().getCUST_CTXT_TYPE_FLG();
			parmTenderAmountNotificationContextType = getParameters().getTAMT_CTXT_TYPE_FLG();
			parmExternalPayIdNotificationContextType = getParameters().getXREF_CTXT_TYPE_FLG();
			parmCancelReasonNotificationContextType = getParameters().getCNRC_CTXT_TYPE_FLG();
			parmPaymentCancelReason = getParameters().getCAN_RSN_CD();
			parmPayReturnDateContextType =getParameters().getPYRD_CTXT_TYPE_FLG();
			parmOriginalPayBatchNumContextType = getParameters().getOBNM_CTXT_TYPE_FLG();
			parmOriginalPayDateContextType =  getParameters().getOPYD_CTXT_TYPE_FLG();
			parmNotificationType = getParameters().getNOTIF_XTYPE_FLG();
			parmFilePath = getParameters().getFILE_PATH().trim();
			parmFileName = getParameters().getFILE_NAME().trim();
			LOG.info("***parmFilePath:"+parmFilePath+"***");
			LOG.info("***parmFileName:"+parmFileName+"***");
			LOG.info("***Done Retrieving Parameters***");
		}
		// END ADD - JHERNA - 2015-08-26 - 3294040		
		
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
		throws ThreadAbortedException, RunAbortedException {

			// START ADD - JHERNA - 2015-08-26 - 3294040
			cmRetrieveParameters();
			// END ADD - JHERNA - 2015-08-26 - 3294040
			
			processFile();

			// Log Total Number of Records Processed and Total Amount of Payment Processed
			logMessage(CustomMessageRepository.ni0040_4TotalNbrOfPaymentCancellationRecordsProcessed(totalFileRecordCount), MessageSeverityLookup.constants.INFORMATIONAL);
			logMessage(CustomMessageRepository.ni0040_4TotalPaymentCancellationAmountProcessed(calculatedTotalPaymentCancelAmount), MessageSeverityLookup.constants.INFORMATIONAL);  
			logMessage(CustomMessageRepository.ni0040_4TotalNbrOfPaymentCancellationBatchesProcessed(totalBatchCount), MessageSeverityLookup.constants.INFORMATIONAL);  

			// Set Batch Run Totals
			WorkUnitResult workUnitResult = new WorkUnitResult(true);
			workUnitResult.setUnitsProcessed(totalFileRecordCount);
			workUnitResult.setUnitsInError(numberOfRecordsInError.intValue());

			return workUnitResult;
		}

		private void processFile() {
			openFile();

			String fileRecord = null;
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
            session = (FrameworkSession)SessionHolder.getSession();
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
            
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
            //setSavepoint(SAVE_POINT);
        	session.setSavepoint(SAVE_POINT);
        	//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation

			fileRecord = readFileLine();
			if(fileRecord.length() <= 0) {
				addError(CustomMessageRepository.ni0040_4EmptyFileError());  
			}

			// Process each record until end of file
			while (notNull(fileRecord)){
				// Increment line counter
				lineCounter = lineCounter.add(BigInteger.ONE);
				try {
					// Process the file record if and only if record length != 0
					if(fileRecord.length()!= 0) { 
						processRecords(fileRecord);
					}
					// Read the next line
					fileRecord = readFileLine();
				}catch (ApplicationError ae){
					//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
	                //rollbackToSavepoint(SAVE_POINT);
					session.rollbackToSavepoint(SAVE_POINT);
					//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
					numberOfRecordsInError  = numberOfRecordsInError.add(BigInteger.ONE);
					throw ae;
				}
			}
			closeFile();
		}

		/**
		 * This Method will process each record present in the Payment Return file.
		 * @param detailRecord
		 */
		private void processRecords(String detailRecord){
			String recordType = getFieldValue(detailRecord,RECORD_TYPE_INDEX,RECORD_TYPE_LENGTH).trim();

			// Check whether Record Type is present in the Record or not. If No Record Type , throw an error
			validateField(recordType, CONST_RECORD_TYPE, RECORD_TYPE_INDEX+1, RECORD_TYPE_INDEX+RECORD_TYPE_LENGTH);

			if(recordType.equalsIgnoreCase(FILE_HEADER_RECORD_TYPE)){
				processFileHeader(detailRecord);

			}else if(recordType.equalsIgnoreCase(BATCH_HEADER_RECORD_TYPE)){
				processBatchHeader(detailRecord);

			}else if(recordType.equalsIgnoreCase(DETAILS_RECORD_TYPE)){
				processDetailsRecord(detailRecord);

			}else if(recordType.equalsIgnoreCase(BATCH_TRAILER_RECORD_TYPE)){
				processBatchTrailer(detailRecord);

			}else if(recordType.equalsIgnoreCase(FILE_TRAILER_RECORD_TYPE)){
				processFileTrailer(detailRecord);
			}
			else{
				addError(CustomMessageRepository.ni0040_4InvalidRecordType(lineCounter.toString(), recordType));
			}
		}

		/**
		 * This Method will process the File Header Record, to fetch and validate the file date.
		 * @param record
		 */
		private void processFileHeader(String record){
			totalFileHeaderRecords = totalFileHeaderRecords + 1;

			if(totalFileHeaderRecords  >1 ){
				addError(CustomMessageRepository.ni0040_4MultipleFileHeaderRecords());  
			}

			if (isBatchHeaderRead.isTrue() || isBatchTrailerRead.isTrue()|| isDetailRecordRead.isTrue()||isFileTrailerRead.isTrue()){
				addError(CustomMessageRepository.ni0040_4InvalidRecordTypeOrder());
			}

			// Get the Company Name Details
			String companyNameStr = getFieldValue(record, COMPANY_NAME_INDEX, COMPANY_NAME_LENGTH).trim();
			validateField(companyNameStr, CONST_COMPANY_NAME, COMPANY_NAME_INDEX+1, COMPANY_NAME_INDEX+COMPANY_NAME_LENGTH);

			
			if(!companyNameStr.equalsIgnoreCase(parmCompanyName)){
				addError(CustomMessageRepository.ni0040_4InvalidCompanyName(lineCounter.toString(), companyNameStr));
			}

			// If Payment Source on the file header is different than provided as PAYMENT-SOURCE batch parameter,
			// error out entire file.
			paymentSourceStr = getFieldValue(record, PAYMENT_SOURCE_INDEX, PAYMENT_SOURCE_LENGTH).trim();
			validateField(paymentSourceStr, CONST_PAYMENT_SOURCE, PAYMENT_SOURCE_INDEX+1, PAYMENT_SOURCE_INDEX+PAYMENT_SOURCE_LENGTH);

			if(!paymentSourceStr.equalsIgnoreCase(parmPaymentSource)){
				addError(CustomMessageRepository.ni0040_4InvalidPaymentSource(lineCounter.toString(), paymentSourceStr));
			}

			// Retrieve Notificational External Details based on the Payment Source (i.e. CACI). Payment Source 
			notificationExternalId = new NotificationExternalId_Id(paymentSourceStr);
			if(isNull(notificationExternalId.getEntity())){
				addError(CustomMessageRepository.ni0040_4InvalidExternalNotification(lineCounter.toString(), paymentSourceStr));
			}



			fileDateStr = getFieldValue(record, FILE_DATE_INDEX, FILE_DATE_LENGTH);
			validateField(fileDateStr, CONST_FILE_DATE, FILE_DATE_INDEX+1, FILE_DATE_INDEX+FILE_DATE_LENGTH);

			// File DateTime must be a valid DateTime.
			fileDateTime = convertFileDateStrToDateTimeFormat(fileDateStr);
			isFileHeaderRead = Bool.TRUE;

			isBatchAlreadyProcessed();
		}

		/**
		 * This Method will process the BAtch Header Record, to fetch and validate the Batch Number.
		 * @param record
		 */
		private void processBatchHeader(String record){

			totalBatchHeaderRecords = totalBatchHeaderRecords + 1;

			if(totalBatchHeaderRecords > 1){
				addError(CustomMessageRepository.ni0040_4MultipleBatchHeaderRecords());
			}

			// To check that the File Header is processed first.
			if(isFileHeaderRead.isFalse() || isBatchTrailerRead.isTrue() || isFileTrailerRead.isTrue()){
				addError(CustomMessageRepository.ni0040_4InvalidRecordTypeOrder());
			}

			batchNumber = getFieldValue(record, BATCH_NUMBER_INDEX, BATCH_NUMBER_LENGTH);
			validateField(batchNumber, CONST_BATCH_NUM, BATCH_NUMBER_INDEX+1, BATCH_NUMBER_INDEX+BATCH_NUMBER_LENGTH);

			// Check whether the Batch Type in the file matches with Batch Type Parameter
			batchTypeStr = getFieldValue(record, BATCH_TYPE_INDEX, BATCH_TYPE_LENGTH);
			validateField(batchTypeStr, CONST_BATCH_TYPE, BATCH_TYPE_INDEX+1, BATCH_TYPE_INDEX+BATCH_TYPE_LENGTH);

			try {
				batchType = new BigInteger(batchTypeStr);
			}catch(Exception ae){
				addError(CustomMessageRepository.ni0040_4RecordInError(lineCounter.toString().trim(), ae.getMessage()));
			}

			if(batchType.compareTo(parmBatchType)!=0){
				addError(CustomMessageRepository.ni0040_4InvalidBatchType(lineCounter.toString(), batchTypeStr));
			}

			calculatedTotalPaymentCancelAmount =  BigDecimal.ZERO;  
			isBatchHeaderRead = Bool.TRUE;

		}

		/**
		 * This Method will process the Detail record present in the File.
		 * It will Fetch the Required Fields and validate them.
		 * It will create the Notification Upload Staging records.
		 * @param record
		 */
		private void processDetailsRecord(String record){

			if(isFileHeaderRead.isFalse() || isBatchHeaderRead.isFalse() || isFileTrailerRead.isTrue()){
				addError(CustomMessageRepository.ni0040_4InvalidRecordTypeOrder());  
			}

			// Find An Collection Agency Details provided on the record 
			referralIdStr = getFieldValue(record, REFERRAL_ID_INDEX, REFERRAL_ID_LENGTH);
			validateField(referralIdStr, CONST_REFERRAL_ID, REFERRAL_ID_INDEX+1, REFERRAL_ID_INDEX+REFERRAL_ID_LENGTH);

			colReferralAgencyId = new CollectionAgencyReferral_Id(referralIdStr);

			colReferralAgency = colReferralAgencyId.getEntity();

			// If Col Agency Referral Not found, error out		
			if(isNull(colReferralAgency)){
				addError(CustomMessageRepository.ni0040_4InvalidCollectionReferralAgency(lineCounter.toString(),referralIdStr.trim()));  
			}

			account = colReferralAgency.getAccount();

			// Retrieve associated Account Id from the Col Referral Account 
			// accountId = retrieveActiveReferralAccount();

			if(isNull(account)){
				addError(CustomMessageRepository.ni0040_4NoAccountFound(colReferralAgencyId.getTrimmedValue(),lineCounter.toString()));
			}

			// Get Premise Id Details provided on the Record and Validate them
			premiseIdStr = getFieldValue(record, PREMISE_ID_INDEX, PREMISE_ID_LENGTH);
			validateField(premiseIdStr, CONST_PREMISE_ID, PREMISE_ID_INDEX + 1, PREMISE_ID_INDEX + PREMISE_ID_LENGTH);

			premiseId = new Premise_Id(premiseIdStr);

			if(isNull(premiseId.getEntity())){
				addError(CustomMessageRepository.ni0040_4InvalidPremiseIdFound(lineCounter.toString(),premiseIdStr.trim()));  
			}

			// Get the External Reference Id Details from the input file and Validate them
			extRefId = getFieldValue(record, EXT_REF_ID_INDEX, EXT_REF_ID_LENGTH);		
			validateField(extRefId, CONST_EXT_PAY_ID, EXT_REF_ID_INDEX+1, EXT_REF_ID_INDEX+EXT_REF_ID_LENGTH);
			
			//SD20131806 - CR 104   - Do not Error. If value is not Present, donot populate the Context value. So validatefield is not called
			strPayDate = getFieldValue(record, PAY_DATE_INDEX, PAY_DATE_LENGTH);
			


			// Get the Amount-Paid Details  from the  Input File and Validate them
			String amountPaidStr = getFieldValue(record, AMOUNT_PAID_INDEX, AMOUNT_PAID_LENGTH);
			validateField(amountPaidStr, CONST_AMOUNT_PAID, AMOUNT_PAID_INDEX+1, AMOUNT_PAID_INDEX + AMOUNT_PAID_LENGTH);
			BigDecimal payCancelAmount = BigDecimal.ZERO;

			try{
				payCancelAmount = new BigDecimal(amountPaidStr);
				payCancelAmount = payCancelAmount.movePointLeft(2);

			} catch(NumberFormatException e){
				addError(CustomMessageRepository.ni0040_4NumberFormatException(lineCounter.toString(), amountPaidStr));  
			}

			try {	
				startChanges();

				createNotificationUpload();
				createContextRecord(parmAcctIdNotificationContextType,account.getId().getTrimmedValue());
				createContextRecord(parmTenderAmountNotificationContextType, payCancelAmount.toString());
				createContextRecord(parmExternalPayIdNotificationContextType,extRefId );
				createContextRecord(parmCancelReasonNotificationContextType, parmPaymentCancelReason.getId().getTrimmedValue());
				//SD20131806 - CR 104 - Create the Context values that are missing.
				createContextRecord(parmPayReturnDateContextType, getFormattedDateString(getProcessDateTime().getDate().toString()));
				createContextRecord(parmOriginalPayBatchNumContextType, batchNumber);
				// If Date not Present or Invalid  do not populate the Context value.
				if(!isBlankOrNull(strPayDate) && strPayDate.trim().length() == 10 ){
					try{
						Date.fromString(strPayDate, new DateFormat(DATE_FORMAT_YYYYMMDD));
						createContextRecord(parmOriginalPayDateContextType, getFormattedDateString(strPayDate));
					} catch (DateFormatParseException e) {
						logWarning(CustomMessageRepository.ni0040_4InvalidDate(lineCounter.toString(), 
								CONST_FILE_DATE, fileDateStr, DATE_FORMAT_YYYYMMDD));
					}
 
				}
				

				saveChanges();
			}catch(ApplicationError ae){
				addError(CustomMessageRepository.ni0040_4RecordInError(lineCounter.toString().trim(), ae.getServerMessage().getMessageText()));
			}
			calculatedTotalPaymentCancelAmount = calculatedTotalPaymentCancelAmount.add(payCancelAmount);
			processedRecordsCount++;

		}

		private void processBatchTrailer(String record) {

			totalBatchTrailerRecords = totalBatchTrailerRecords  + 1;

			if(totalBatchTrailerRecords > 1){
				addError(CustomMessageRepository.ni0040_4MultipleBatchTrailerRecords());
			}

			// To Check that the File & Batch Headers are processed before processing the batch trailer.
			if(isFileHeaderRead.isFalse() || isBatchHeaderRead.isFalse() || isFileTrailerRead.isTrue()){
				addError(CustomMessageRepository.ni0040_4InvalidRecordTypeOrder()); 
			}

			// Get the Batch Trailer Number Details from the Input File and Validate them
			String trailerBatchNumberStr = getFieldValue(record, BATCH_NUMBER_INDEX, BATCH_NUMBER_LENGTH);
			validateField(trailerBatchNumberStr, CONST_BATCH_NUM, BATCH_NUMBER_INDEX+1, BATCH_NUMBER_INDEX+BATCH_NUMBER_LENGTH);

			//  Check whether the Batch Number in Batch Trailer matches with Batch Number in Batch Header Record.
			// If not matched , throw an error
			if(!batchNumber.equalsIgnoreCase(trailerBatchNumberStr)){
				addError(CustomMessageRepository.ni0040_4BatchHdrAndTrailerRecordsBatchNbrAreNotSame()); 
			}

			// Get the Batch Item Count Details from the input file and validate them 
			String batchitemCountStr = getFieldValue(record, BATCH_ITEM_COUNT_INDEX, BATCH_ITEM_COUNT_LENGTH);
			validateField(batchitemCountStr, CONST_ITEM_COUNT, BATCH_ITEM_COUNT_INDEX+1, BATCH_ITEM_COUNT_INDEX+BATCH_ITEM_COUNT_LENGTH);

			try{
				batchTrailerRecordCount = Integer.parseInt(batchitemCountStr);
			}catch(ApplicationError ae){
				addError(CustomMessageRepository.ni0040_4RecordInError(lineCounter.toString().trim(), ae.getServerMessage().getMessageText()));  
			}

			if (batchTrailerRecordCount != processedRecordsCount){
				addError(CustomMessageRepository.ni0040_4BatchTrailerCountndTotalRecordCountAreNotSame(batchitemCountStr,String.valueOf(processedRecordsCount), batchNumber)); 
			}

			// Get the Total Payment Cancellation Amount from the input file 
			String batchPayCancelAmountStr = getFieldValue(record, BATCH_DEPOSIT_AMT_INDEX, BATCH_DEPOSIT_AMT_LENGTH);
			validateField(batchPayCancelAmountStr, CONST_DEP_AMT, BATCH_DEPOSIT_AMT_INDEX+1, BATCH_DEPOSIT_AMT_INDEX+BATCH_DEPOSIT_AMT_LENGTH);
			totalBatchPaymentCancellationAmount = new BigDecimal(batchPayCancelAmountStr).movePointLeft(2);

			if(calculatedTotalPaymentCancelAmount.compareTo(totalBatchPaymentCancellationAmount) !=0){
				addError(CustomMessageRepository.ni0040_4BatchTotalDepositAmountAndTotalPaymentAmountAreNotSame(totalBatchPaymentCancellationAmount.toString(),calculatedTotalPaymentCancelAmount.toString(), batchNumber)); 
			}

			// Update Deposit Control Amount
			totalBatchCount++;
			totalFileRecordCount = totalFileRecordCount + processedRecordsCount;
			calculatedFileTotalPaymentCancelationAmt = calculatedFileTotalPaymentCancelationAmt.add(calculatedTotalPaymentCancelAmount); 
			isBatchTrailerRead = Bool.TRUE;
		}

		/**
		 * This Method will fetch and validate the Batch Count, Deposit Amount and item processedRecordsCount with the
		 * total number of batches, total number of records and total payment amount of records in the File. 
		 * @param record
		 */
		private void processFileTrailer(String record){

			totalFileTrailerRecords = totalFileTrailerRecords + 1;

			if(totalFileTrailerRecords  >1 ){
				addError(CustomMessageRepository.ni0040_4MultipleFileTrailerRecords());  
			}

			// To Check whether there are any unclosed batch records or the file and batch headers are processed first.
			if(isFileHeaderRead.isFalse() || isBatchHeaderRead.isFalse() || isBatchTrailerRead.isFalse()){
				addError(CustomMessageRepository.ni0040_4InvalidRecordTypeOrder());  
			}

			String trailerDateStr = getFieldValue(record, TRAILER_DATE_INDEX, TRAILER_DATE_LENGTH);
			validateField(trailerDateStr, CONST_TRAILER_DATE, TRAILER_DATE_INDEX+1, TRAILER_DATE_INDEX+TRAILER_DATE_LENGTH);

			// Trailer DateTime must be a valid DateTime.
			DateTime trailerDateTime = convertFileDateStrToDateTimeFormat(trailerDateStr);
			if(fileDateTime.compareTo(trailerDateTime) !=0){
				addError(CustomMessageRepository.ni0040_4FileHdrAndTrailerDateTimeNotSame(fileDateStr,trailerDateStr));
			}

			String fileTrailerBatchCountStr = getFieldValue(record, TOTAL_BATCH_COUNT_INDEX, TOTAL_BATCH_COUNT_LENGTH);
			validateField(fileTrailerBatchCountStr, CONST_BATCH_COUNT, TOTAL_BATCH_COUNT_INDEX+1, TOTAL_BATCH_COUNT_INDEX+TOTAL_BATCH_COUNT_LENGTH);
			try{
				fileTrailerBatchCount = Integer.parseInt(fileTrailerBatchCountStr);
			}catch(ApplicationError ae){
				addError(CustomMessageRepository.ni0040_4RecordInError(lineCounter.toString().trim(), ae.getServerMessage().getMessageText())); 
			}

			if (totalBatchCount != fileTrailerBatchCount){
				addError(CustomMessageRepository.ni0040_4FileTrailerBatchCountAndTotalBatchCountAreNotSame(fileTrailerBatchCountStr, String.valueOf(totalBatchCount)));   
			}

			String fileTrailerRecordCountStr = getFieldValue(record, TOTAL_ITEM_COUNT_INDEX, TOTAL_ITEM_COUNT_LENGTH);
			validateField(fileTrailerRecordCountStr, CONST_ITEM_COUNT, TOTAL_ITEM_COUNT_INDEX+1, TOTAL_ITEM_COUNT_INDEX+TOTAL_ITEM_COUNT_LENGTH);

			try{
				fileTrailerRecordCount = Integer.parseInt(fileTrailerRecordCountStr);
			}catch(ApplicationError ae){
				addError(CustomMessageRepository.ni0040_4RecordInError(lineCounter.toString().trim(), ae.getServerMessage().getMessageText())); 
			}

			if(fileTrailerRecordCount !=totalFileRecordCount){
				addError(CustomMessageRepository.ni0040_4FileTrailerItemCountAndTotalItemCountAreNotSame(fileTrailerRecordCountStr, String.valueOf(totalFileRecordCount))); 
			}

			String totalDepositAmountStr = getFieldValue(record, TOTAL_CANCEL_AMT_INDEX, TOTAL_CANCEL_AMT_LENGTH);
			validateField(totalDepositAmountStr, CONST_FILE_DEP_AMT, TOTAL_CANCEL_AMT_INDEX+1, TOTAL_CANCEL_AMT_INDEX+TOTAL_CANCEL_AMT_LENGTH);

			BigDecimal filePaymentCancelationAmount = new BigDecimal(totalDepositAmountStr);
			filePaymentCancelationAmount = filePaymentCancelationAmount.movePointLeft(2);

			if(calculatedFileTotalPaymentCancelationAmt.compareTo(filePaymentCancelationAmount) != 0){
				addError(CustomMessageRepository.ni0040_4FileTotalDepositAmountAndTotalPaymentAmountsAreNotSame(String.valueOf(filePaymentCancelationAmount), calculatedFileTotalPaymentCancelationAmt.toString()));  
			}

			isFileTrailerRead = Bool.TRUE;
		}

		/**
		 * This method will check whether the Batch with the 
		 * batch number and file date combination
		 * is already processed.
		 *
		 */
		private void isBatchAlreadyProcessed(){

			StringBuilder batchProcessesQueryStr = new StringBuilder();

			batchProcessesQueryStr.append(" SELECT 'X' ");
			batchProcessesQueryStr.append(" FROM CI_NT_UP ");
			batchProcessesQueryStr.append(" WHERE NT_XID_CD = :notExtId ");
			batchProcessesQueryStr.append(" AND CRE_DTTM = :fileDate ");
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			//PreparedStatement batchProcessesPrepStmt = createPreparedStatement(batchProcessesQueryStr.toString());
			PreparedStatement batchProcessesPrepStmt = createPreparedStatement(batchProcessesQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			batchProcessesPrepStmt.bindId("notExtId", notificationExternalId);
			batchProcessesPrepStmt.bindDateTime("fileDate", fileDateTime);

			if(notNull(batchProcessesPrepStmt.firstRow())){
				addError(CustomMessageRepository.ni0040_4BatchIsAlreadyProcessed(paymentSourceStr, fileDateTime.toString()));
			}

			batchProcessesPrepStmt.close();
		}

		private void createNotificationUpload(){
			// Create and insert Notification Upload record
			NotificationUpload_DTO notificationUploadDto = createDTO(NotificationUpload.class);
			notificationUploadDto.setCreationDateTime(fileDateTime);
			notificationUploadDto.setNotificationUploadTypeId(parmNotificationType.getId());
			notificationUploadDto.setNotificationExternalId(notificationExternalId);
			notificationUploadDto.setNotificationStatus(NotificationUploadStatusLookup.constants.PENDING);
			notificationUploadDto.setNotificationUploadExtension(NotificationUploadExtensionLookup.constants.NO_EXTENSION);

			notificationUpload = notificationUploadDto.newEntity();

		} 

		private void createContextRecord(NotificationUploadContextLookup notificationUploadContextType, String contextValue){

			//Create and insert Notification Upload Context record
			NotificationUploadContext_DTO notificationUploadContextDTO = new NotificationUploadContext_DTO();
			notificationUploadContextDTO.setId(new NotificationUploadContext_Id(notificationUpload, notificationUploadContextType, contextValue.trim()));
			notificationUploadContextDTO.newEntity();
		}


		/**
		 * Convert the input fileDateString to the Date in the given date format.
		 * @param fileDate
		 */
		private DateTime convertFileDateStrToDateTimeFormat(String fileDateStr){

			DateTime dateTime=null;

			try{
				dateTime = DateTime.fromString(fileDateStr, new DateFormat(DATETIME_FORMAT_MMDDYYYYHHMMSS));
			} catch (DateFormatParseException e) {
				addError(CustomMessageRepository.ni0040_4InvalidDate(lineCounter.toString(), 
						CONST_FILE_DATE, fileDateStr, DATETIME_FORMAT_MMDDYYYYHHMMSS));
			}
			return dateTime;
		}
		
		/**
		 * Convert the processDate  the given date format YYMMDD.
		 * @param fileDate
		 */
		private String getFormattedDateString(String strDate){
     	    String strDtFmt = strDate.substring(5,7)+ strDate.substring(8, 10)+strDate.substring(2,4);
		    return strDtFmt;
    	}
		


		/**
		 * This method retrieves the trimmed field value from the record starting 
		 * from the startPos and of the given length.
		 * @param record
		 * @param startPos
		 * @param length
		 * @return
		 */
		private String getFieldValue(String record, int startPos, int length) {

			String value = null;
			//  if(record.length() >= startPos+length){
			value = record.substring(startPos, startPos+length).trim();
			// }
			return value;
		}

		private void validateField(String value, String fieldName, int startPos, int endPos){
			if(isBlankOrNull(value)){
				addError(CustomMessageRepository.ni0040_4MandatoryfieldIsBlank(lineCounter.toString(), fieldName,String.valueOf(startPos), String.valueOf(endPos))); 
			}
		}

		private void openFile(){
			LOG.info("***About to Open File***");
			// START CHANGES - JHERNA - 2015-08-26 - 3294040
			/*
			if(isNull(parmFileName)) {
				parmFileName = null;
			}
			inputFilePathAndName = new File(parmFilePath, parmFileName);
			try {
				inputFile = new BufferedReader(new FileReader(inputFilePathAndName));  

			}
			catch (IOException e) {     
				throw new RunAbortedException(CustomMessageRepository.ni0040_4ErrorInFile(e.getMessage())); 
			}
			*/
			if(isNull(parmFileName)
					|| isNull(parmFilePath)) {
				parmFileName = this.getParameters().getFILE_NAME();
				parmFilePath = this.getParameters().getFILE_PATH();
			}
			try {
				File inputFilePathAndName = new File(parmFilePath, parmFileName);
				inputFile = new BufferedReader(new FileReader(inputFilePathAndName));  

			}
			catch (IOException e) {     
				throw new RunAbortedException(CustomMessageRepository.ni0040_4ErrorInFile(e.getMessage())); 
			}
			catch (Exception e) {
				throw new RunAbortedException(CustomMessageRepository.ni0040_4ErrorInFile(e.getMessage()));
			}
			// END CHANGES - JHERNA - 2015-08-26 - 3294040
			LOG.info("***File Opened***");
		}      

		private String readFileLine(){
			try {       
				return inputFile.readLine();
			}
			catch(IOException e) {
				throw new RunAbortedException(CustomMessageRepository.ni0040_4ErrorInFile(e.getMessage())); 
			}
			// START ADD - JHERNA - 2015-08-26 - 3294040
			catch (Exception e) {
				throw new RunAbortedException(CustomMessageRepository.ni0040_4ErrorInFile(e.getMessage()));
			}
			// END ADD - JHERNA - 2015-08-26 - 3294040
		}

		private void closeFile(){
			LOG.info("***About to Close File***");
			try {       
				inputFile.close();
			}
			catch(IOException e) {
				throw new RunAbortedException(CustomMessageRepository.ni0040_4ErrorInFile(e.getMessage()));
			}   
			catch (Exception e) {
				throw new RunAbortedException(CustomMessageRepository.ni0040_4ErrorInFile(e.getMessage()));
			}
			LOG.info("***File Closed***");
		}
	}
}