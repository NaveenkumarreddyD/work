/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Gold Lock Deposit Recommendation Algorithm.
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2022-04-28   Carlos Atilano  B-21582  - This algorithm will calculate the deposit amount as follows
 * 								-IF there is 24 months of billing data, sum the highest 2 bills
 * 								-If not, if there is 9 months of billing data, sum the highest 2 bills
 * 								-When there is insufficient billing data, use the amount specified in 
 *								the defaultAmount parm.
 * 2025-07-09   DLampa          E-11151. Updated to retrieve billing history only from accounts 
 *                              linked to the premise via non-canceled SAs.
 ******************************************************************************************/
package com.splwg.cm.domain.admin.depositClass.algorithm.recommendation;

import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.domain.common.currency.Currency_Id;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.BillStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.depositClass.algorithm.recommendation.DepositClassDepositRecommendationAlgorithmSpot;
import com.splwg.ccb.domain.admin.depositClass.algorithm.recommendation.DepositRecommendationResult;
import com.splwg.ccb.domain.admin.depositClass.entity.DepositClass;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementTypeStartOption.entity.ServiceAgreementTypeStartOption;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.admin.sicCode.entity.SicCode;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author OGC04023
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = initialNumberOfMonthsBillHistory, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = secondaryNumberOfMonthsBillHistory, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = defaultAmount, required = true, type = decimal)})
 */
public class CmGoldLockDepositRecommendationAlgComp_Impl extends
		CmGoldLockDepositRecommendationAlgComp_Gen implements
		DepositClassDepositRecommendationAlgorithmSpot {

	public final String CURRENCY_USD = "USD";
	public int nbrBills = 2;
	private DepositClass depositClass;
	public Account acct;
	public Premise prem;
	public int initNbrMnths;
	public int secNbrMnths;
	public BigDecimal defaultAmt;
	public  QueryIterator <QueryResultRow> billingHistory;
	public List<QueryResultRow> blHist = new ArrayList();
	public BigDecimal amount;
	public int periods;
	public Money recomendedAmt = Money.ZERO;
	
	@SuppressWarnings("deprecation")

	public void invoke() {

		
		blHist = retrieveBillingHistory(initNbrMnths);
		periods = blHist.size();
		//Check if Premise has 10-24 months of billing history
		if(periods < secNbrMnths){
			blHist = retrieveBillingHistory(secNbrMnths);
			//Check if Premise has 9 months of billing history
			periods = blHist.size();
			if(periods < secNbrMnths){
				//if premise has not enough billing history, return default recommended budget
				addWarning(CustomMessageRepositorySpireOne.B21582_CheckPremiseNotes());
				recomendedAmt = new Money(getDefaultAmount(), new Currency_Id(CURRENCY_USD));
			}
			else{
				/*for(int count = 0; count < nbrBills; count++){
				//if premise has 9 months of billing history, the recommended budget is the sum of the 2 highest bills
					
				amount = amount.add(billingHistory.next().getBigDecimal("BSUM"));
				}*/
				amount = (blHist.get(0).getMoney("bsum").add(blHist.get(1).getMoney("bsum"))).getAmount();
				recomendedAmt = new Money(amount.setScale(0, BigDecimal.ROUND_CEILING) , new Currency_Id(CURRENCY_USD));
			}
		}
		else{
			//if premise has 24 months of billing history, the recommended budget is the sum of the 2 highest bills
			/*for(int count = 0; count < nbrBills; count++){
				//if premise has 9 months of billing history, the recommended budget is the sum of the 2 highest bills
				amount = amount.add(billingHistory.next().getBigDecimal("BSUM"));
				}
				recomendedAmt = new Money(amount.setScale(0, BigDecimal.ROUND_CEILING) , new Currency_Id(CURRENCY_USD));*/
			
			amount = (blHist.get(0).getMoney("bsum").add(blHist.get(1).getMoney("bsum"))).getAmount();
			recomendedAmt = new Money(amount.setScale(0, BigDecimal.ROUND_CEILING) , new Currency_Id(CURRENCY_USD));
		}
		
			

		
	}
	
	public List<QueryResultRow> retrieveBillingHistory(int numberOfMonths){
		
		Date dateParm = getProcessDateTime().getDate().addMonths(numberOfMonths*-1);
		//move the date to the first day of the month to get all bill periods
		if(!dateParm.isFirstDayOfMonth()){
			int day = dateParm.getDay() - 1;
			dateParm = dateParm.addDays(day*-1);
		}
		
		
		String hql = " from Bill b, BillSegment bs, BillSegmentCalculationHeader bsc"
				+ " where b.account in (select sa.account from ServiceAgreement sa, ServicePoint sp"
				+ "		, ServiceAgreementServicePoint sasp where sp.premise = :prem and sasp.servicePoint = sp"
				// Start Change - DLampa - 2025-07-09 - E-11151
				//+ "		and sasp.serviceAgreement = sa)"
				+ "		and sasp.serviceAgreement = sa "
				+ "		and sa.status < :canceled ) "
				// End Change - DLampa - 2025-07-09 - E-11151
				+ " and b.billDate >= :date"
				+ " and b.billStatus = :complete"
				+ "	and b.id = bs.billId"
				+ " and bs.billSegmentStatus = :frozen"
				+ " and bs.id = bsc.id.billSegment"
				+ " and exists (select sq.id from BillSegmentServiceQuantity sq"
				+ "		where sq.id.billSegment = bs"
				+ "		and sq.id.serviceQuantityIdentifier = :daysInPeriod"
				+ "		and sq.billableServiceQuantity <= '40' )";
		
		Query qry = createQuery(hql,"retrieveBillingHistory");
		qry.bindEntity("prem", prem);
		// Start Add - DLampa - 2025-07-09 - E-11151
		qry.bindLookup("canceled", ServiceAgreementStatusLookup.constants.CANCELED);
		// End Add - DLampa - 2025-07-09 - E-11151
		qry.bindDate("date", dateParm);
		qry.bindLookup("complete", BillStatusLookup.constants.COMPLETE);
		qry.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
		qry.bindEntity("daysInPeriod", new ServiceQuantityIdentifier_Id("DAYBP").getEntity());
		qry.addResult("billId","b.id");
		qry.addResult("billDate","b.billDate");
		qry.addResult("bsum", "sum(bsc.calculatedAmount)");
		qry.groupBy("billId");
		qry.groupBy("billDate");
		qry.orderBy("bsum", Query.DESCENDING);

		/*String sql = "SELECT B.BILL_ID, B.BILL_DT, SUM(BSC.CALC_AMT) BSUM"
				+ " FROM CI_BILL B, CI_BSEG BS, CI_BSEG_CALC BSC"
				+ " WHERE B.ACCT_ID = (SELECT SA.ACCT_ID FROM CI_SP SP, CI_SA_SP SASP, CI_SA SA"
				+ "	 	WHERE SP.PREM_ID = :prem"
				+ "		AND SASP.SP_ID = SP.SP_ID"
				+ "		AND SA.SA_ID = SASP.SA_ID)"
				+ " AND BS.BILL_ID = B.BILL_ID"
				+ " AND BSC.BSEG_ID = BS.BSEG_ID"
				+ " AND B.BILL_DT >= :date"
				+ " AND B.BILL_STAT_FLG = :complete"
				+ " AND EXISTS (SELECT 'X' FROM CI_BSEG_SQ SQ WHERE SQ.BSEG_ID = BS.BSEG_ID"
				+ "		AND SQ.SQI_CD = :daysInPeriod AND SQ.BILL_SQ <= '40')"
				+ "		GROUP BY B.BILL_ID, B.BILL_DT"
				+ "		  ORDER BY SUM(BSC.CALC_AMT) DESC";
		PreparedStatement ps = createPreparedStatement(sql, "retrieveBillingHistory");
		ps.bindEntity("prem", prem);
		ps.bindDate("date", dateParm);
		ps.bindLookup("complete", BillStatusLookup.constants.COMPLETE);
		ps.bindEntity("daysInPeriod", new ServiceQuantityIdentifier_Id("DAYBP").getEntity());
		periods = ps.list().size();
		return ps.iterate();*/
		return qry.list();
		
		
	}

	@Override
	protected void extraSoftParameterValidations() {
		initNbrMnths = getInitialNumberOfMonthsBillHistory().intValue();
		secNbrMnths = getSecondaryNumberOfMonthsBillHistory().intValue();	
	}

	@Override
	public DepositClass getDepositClass() {
		return depositClass;
	}

	@Override
	public Bool getIsGoodCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DepositRecommendationResult getRecommendationResult() {
		
		return DepositRecommendationResult.NO_ALGORITHM_DEFINED;
	}

	@Override
	public Money getRecommendedAmount() {
		// TODO Auto-generated method stub
		return recomendedAmt;
	}

	@Override
	public void setAccount(Account arg0) {
		acct = arg0;

	}

	@Override
	public void setDepositClass(DepositClass arg0) {
		depositClass = arg0;

	}

	@Override
	public void setPremise(Premise arg0) {
		prem = arg0;

	}

	@Override
	public void setRecurringChargeAmount(Money arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setServiceAgreementType(ServiceAgreementType arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setServiceAgreementTypeStartOption(
			ServiceAgreementTypeStartOption arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setShouldAlwaysCalculateRecommendation(Bool arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setSicCode(SicCode arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setStartDate(Date arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setTotalAmountToBill(Money arg0) {
		// TODO Auto-generated method stub

	}


}
