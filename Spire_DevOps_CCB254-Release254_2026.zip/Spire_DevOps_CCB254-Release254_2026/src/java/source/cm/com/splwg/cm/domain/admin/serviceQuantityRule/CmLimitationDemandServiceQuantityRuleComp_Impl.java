/* 
 *********************************************************************** 
 *                 Confidentiality Information: 
 * 
 ************************************************************************ 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * The Algorithm will retrieve the maximum demand during the defined 
 * limitation period if greater than a set maximum service quantity.  
 * The Algorithm will also set a default value if the maximum demand 
 * retrieved is less than the set maximum service quantity. 
 * 
 *********************************************************************** 
 * 
 * 
 * CHANGE HISTORY: 
 * 
 * Date:		by:       	Reason: 
 * 2013-05-25	Neha      	NM0100. Initial Version
 * 2013-10-28	Karthik		KL20131028 - Fix for IM-037739. Passed 
 * 							Premise ID as Bill Factor char source value.
 * 2013-11-05	Karthik		KL20131105 - Added +1 day while retrieving 
 * 							daily consumption.
 * 2016-01-26   MPang	Updated for CCB v2.4 compilation.
 * 2018-07-25   SFelip      CCB v2.6 Upgrade. Remove trim from SQLS 
 *                          that are no longer needed.   
 *********************************************************************** 
 */

package com.splwg.cm.domain.admin.serviceQuantityRule;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.ibm.icu.math.MathContext;
import com.splwg.base.api.GenericBusinessComponent;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.database.field.Field_Id;
import com.splwg.ccb.api.lookup.ConsumptionTypeLookup;
import com.splwg.ccb.api.lookup.HowToUseReadLookup;
import com.splwg.ccb.api.lookup.ServicePointMeterEventTypeLookup;
import com.splwg.ccb.api.lookup.ServiceQuantityLookup;
//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.billFactor.BillFactor;
import com.splwg.ccb.domain.admin.billFactor.BillFactorValueData;
import com.splwg.ccb.domain.admin.billFactor.BillFactorValueInfoRetriever;
import com.splwg.ccb.domain.admin.billFactor.BillFactorValueInfoRetrieverData;
import com.splwg.ccb.domain.admin.billFactor.BillFactor_Id;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.admin.serviceQuantityRule.ServiceQuantityRuleComponent;
import com.splwg.ccb.domain.admin.timeOfUse.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure_Id;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentItemData;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentReadData;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantity;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantityData;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantity_DTO;
import com.splwg.ccb.domain.billing.billSegment.BillSegmentServiceQuantity_Id;
import com.splwg.ccb.domain.billing.billSegment.BillSegment_Id;
import com.splwg.ccb.domain.common.characteristic.CharacteristicData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.rate.ApplyRateData;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;*/

import com.splwg.ccb.domain.admin.billFactor.entity.BillFactor;
import com.splwg.ccb.domain.admin.data.BillFactorValueData ;
import com.splwg.ccb.domain.admin.common.BillFactorValueInfoRetriever;
import com.splwg.ccb.domain.admin.data.BillFactorValueInfoRetrieverData;
import com.splwg.ccb.domain.admin.billFactor.entity.BillFactor_Id;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.admin.data.ServiceQuantityRuleComponent;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.billing.data.BillSegmentItemData;
import com.splwg.ccb.domain.billing.data.BillSegmentReadData;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity;
import com.splwg.ccb.domain.billing.data.BillSegmentServiceQuantityData;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity_DTO;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentServiceQuantity_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.common.data.CharacteristicData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.rate.data.ApplyRateData;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 *
 * @BusinessComponent (customizationCallable = true)
 */
public class CmLimitationDemandServiceQuantityRuleComp_Impl 
		extends GenericBusinessComponent 
		implements CmLimitationDemandServiceQuantityRuleComp, ServiceQuantityRuleComponent {
    // Constants
    private static final String ALG_DESC = "Limitation Demand SQ Rule";
    private static final String COMMA_DELIMITER = ",";
    private static final String DATE_FORMAT = "MM-dd-yyyy";

    // Hard Parameters
    private ApplyRateData applyRateData;
    private List<BillSegmentItemData> billSegmentItemData;
    private List<BillSegmentReadData> billSegmentReadData;
    private List<BillSegmentServiceQuantityData> billSegmentServiceQuantityData;
    private List<CharacteristicData> characteristicData;
    private String featureConfStr;
    private String limitedPeriodOptTypeStr;
    private String correctedUomStr;
    private String conversionOneBillFactorStr;
    private String conversionTwoBillFactorStr;
    private String maxContractQtySqiStr;
    private String defaultValueStr;
    private String parameter8;
    private String parameter9;
    private String parameter10;
    private ServiceQuantityIdentifier_Id serviceQuantityIdentifierId;
    private ServiceQuantityLookup serviceQuantityLookup;
    private Bool shouldCreateBillingError;
    private TimeOfUse_Id timeOfUseId;
    private UnitOfMeasure_Id unitOfMeasureId;

    // Program variables
    private ServiceQuantityIdentifier contractQuantityMaximumSqi;
    private BigDecimal defaultSQValue = BigDecimal.ZERO;
    private ServiceAgreement serviceAgreement;
    private Bool isErrorEncountered;
    private FeatureConfiguration featureConfig;
    private UnitOfMeasure_Id correctedUomCd;
    private BillFactor conversionOneBF;
    private BillFactor conversionTwoBF;
    private List<String> listOfLimitingPeriods = new ArrayList<String>();
    //KL20131028 - Start of fix for IM-037739
    private int initialSQScale = new Field_Id("INIT_SQ").getEntity().getActiveFieldScale().intValue();
    private int billableSQScale = new Field_Id("BILL_SQ").getEntity().getActiveFieldScale().intValue();
    //KL20131028 - End of fix for IM-037739
    

    public ApplyRateData getApplyRateData() {
        return applyRateData;
    }

    public List<BillSegmentItemData> getBillSegmentItemData() {
        return billSegmentItemData;
    }

    public List<BillSegmentReadData> getBillSegmentReadData() {
        return billSegmentReadData;
    }

    public List<BillSegmentServiceQuantityData> getBillSegmentServiceQuantityData() {
        return billSegmentServiceQuantityData;
    }

    public List<CharacteristicData> getCharacteristicData() {
        return characteristicData;
    }

    public String getSQRuleParameter1() {
        return featureConfStr;
    }

    public String getSQRuleParameter10() {
        return parameter10;
    }

    public String getSQRuleParameter2() {
        return limitedPeriodOptTypeStr;
    }

    public String getSQRuleParameter3() {
        return correctedUomStr;
    }

    public String getSQRuleParameter4() {
        return conversionOneBillFactorStr;
    }

    public String getSQRuleParameter5() {
        return conversionTwoBillFactorStr;
    }

    public String getSQRuleParameter6() {
        return maxContractQtySqiStr;
    }

    public String getSQRuleParameter7() {
        return defaultValueStr;
    }

    public String getSQRuleParameter8() {
        return parameter8;
    }

    public String getSQRuleParameter9() {
        return parameter9;
    }

    public ServiceQuantityIdentifier_Id getServiceQuantityIdentifierId() {
        return serviceQuantityIdentifierId;
    }

    public ServiceQuantityLookup getServiceQuantityLookup() {
        return serviceQuantityLookup;
    }

    public Bool getShouldCreateBillingError() {
        return shouldCreateBillingError;
    }

    public TimeOfUse_Id getTimeOfUseId() {
        return timeOfUseId;
    }

    public UnitOfMeasure_Id getUnitOfMeasureId() {
        return unitOfMeasureId;
    }

    public void setApplyRateData(ApplyRateData applyRateData) {
        this.applyRateData = applyRateData;
    }

    public void setBillSegmentItemData(List<BillSegmentItemData> billSegmentItemData) {
        this.billSegmentItemData = billSegmentItemData;
    }

    public void setBillSegmentReadData(List<BillSegmentReadData> billSegmentReadData) {
        this.billSegmentReadData = billSegmentReadData;
    }

    public void setBillSegmentServiceQuantityData(List<BillSegmentServiceQuantityData> billSegmentServiceQuantityData) {
        this.billSegmentServiceQuantityData = billSegmentServiceQuantityData;
    }

    public void setCharacteristicData(List<CharacteristicData> characteristicData) {
        this.characteristicData = characteristicData;
    }

    public void setSQRuleParameter1(String parameter1) {
        this.featureConfStr = parameter1;
    }

    public void setSQRuleParameter10(String parameter10) {
        this.parameter10 = parameter10;
    }

    public void setSQRuleParameter2(String parameter2) {
        this.limitedPeriodOptTypeStr = parameter2;
    }

    public void setSQRuleParameter3(String parameter3) {
        this.correctedUomStr = parameter3;
    }

    public void setSQRuleParameter4(String parameter4) {
        this.conversionOneBillFactorStr = parameter4;
    }

    public void setSQRuleParameter5(String parameter5) {
        this.conversionTwoBillFactorStr = parameter5;
    }

    public void setSQRuleParameter6(String parameter6) {
        this.maxContractQtySqiStr = parameter6;
    }

    public void setSQRuleParameter7(String parameter7) {
        this.defaultValueStr = parameter7;
    }

    public void setSQRuleParameter8(String parameter8) {
        this.parameter8 = parameter8;
    }

    public void setSQRuleParameter9(String parameter9) {
        this.parameter9 = parameter9;
    }

    public void setServiceQuantityIdentifierId(ServiceQuantityIdentifier_Id serviceQuantityIdentifierId) {
        this.serviceQuantityIdentifierId = serviceQuantityIdentifierId;
    }

    public void setServiceQuantityLookup(ServiceQuantityLookup serviceQuantityLookup) {
        this.serviceQuantityLookup = serviceQuantityLookup;
    }

    public void setShouldCreateBillingError(Bool shouldCreateBillingError) {
        this.shouldCreateBillingError = shouldCreateBillingError;
    }

    public void setTimeOfUseId(TimeOfUse_Id timeOfUseId) {
        this.timeOfUseId = timeOfUseId;
    }

    public void setUnitOfMeasureId(UnitOfMeasure_Id unitOfMeasureId) {
        this.unitOfMeasureId = unitOfMeasureId;
    }

    public void invoke() {
        isErrorEncountered = Bool.FALSE;

        // Retrieve and validate parameters
        retrieveAndValidateParameters();

        // Perform processing rules
        if(isErrorEncountered.isFalse()) {
            performProcessingRules();
        }
    }

    /**
     * This method will retrieve and validate parameters
     *
     */
    private void retrieveAndValidateParameters() {
        // Validate Feature Configuration
        featureConfig = new FeatureConfiguration_Id(featureConfStr).getEntity();
        if (isNull(featureConfig)) {
            if (shouldCreateBillingError.isTrue()) {
                addError(CustomMessageRepository.nm0100InvalidFeatureConfig(ALG_DESC,featureConfStr));
            }
            else {
                isErrorEncountered = Bool.TRUE;
                return;
            }
        }

        // Validate Limitation Period Option Type
        listOfLimitingPeriods = validateOptionType(limitedPeriodOptTypeStr);
        if(listOfLimitingPeriods.isEmpty()){
            if (shouldCreateBillingError.isTrue()) {
                addError(CustomMessageRepository.nm0100OptionTypeMissing(ALG_DESC, limitedPeriodOptTypeStr,featureConfStr));
            }
            else {
                isErrorEncountered = Bool.TRUE;
                return;
            }
        }

        // Validate Feature Config data
        for(String limitingOptVal : listOfLimitingPeriods){

            String[] dates = limitingOptVal.split(COMMA_DELIMITER);
            if(dates.length != 2){
                addError(CustomMessageRepository.nm0100StartNEndDtMustBGiven(featureConfStr, limitedPeriodOptTypeStr.trim()));
            }
            Date limitStartDt = null;
            Date limitEndDt = null;
            String dateStr = "";
            try{
                dateStr = dates[0];
                limitStartDt = Date.fromString(dateStr, new DateFormat(DATE_FORMAT));
                dateStr = dates[1];
                limitEndDt = Date.fromString(dateStr, new DateFormat(DATE_FORMAT));
            }catch(DateFormatParseException e){
                addError(CustomMessageRepository.nm0100InvalidDate(ALG_DESC, featureConfStr, dateStr.trim()));
            }
            if(limitEndDt.isBefore(limitStartDt)){
                addError(CustomMessageRepository.nm0100EndDtCannotBBeforeStartDt(dates[1], dates[0], featureConfStr));
            }
        }
        // Validate Maximum SQI

        ServiceQuantityIdentifier_Id contractQuantityMaximumSqiId = new ServiceQuantityIdentifier_Id(maxContractQtySqiStr);
        contractQuantityMaximumSqi = contractQuantityMaximumSqiId.getEntity();
        if (isNull(contractQuantityMaximumSqi)) {
            if (shouldCreateBillingError.isTrue()) {
                addError(CustomMessageRepository.nm0100InvalidServiceQtyIdentifier(ALG_DESC, maxContractQtySqiStr));
            }
            else {
                isErrorEncountered = Bool.TRUE;
                return;
            }
        }
        // Validate UOM
        correctedUomCd = new UnitOfMeasure_Id(correctedUomStr);
        if(isNull(correctedUomCd.getEntity())){
            if (shouldCreateBillingError.isTrue()) {
                addError(CustomMessageRepository.nm0100InvalidUnitOfMeasure(ALG_DESC, correctedUomStr));
            }
            else {
                isErrorEncountered = Bool.TRUE;
                return;
            }
        }
        // validate Conversion 1 Bill Factor
        if(!isEmptyOrNull(conversionOneBillFactorStr.trim())){
            conversionOneBF = (new BillFactor_Id(conversionOneBillFactorStr)).getEntity();
            if(isNull(conversionOneBF)){
                if (shouldCreateBillingError.isTrue()) {
                    addError(CustomMessageRepository.nm0100InvalidBillFactor(ALG_DESC, conversionOneBillFactorStr));
                }
                else {
                    isErrorEncountered = Bool.TRUE;
                    return;
                }
            }
        }
        // validate Conversion 2 Bill Factor
        if(!isEmptyOrNull(conversionTwoBillFactorStr.trim())){
            conversionTwoBF = (new BillFactor_Id(conversionTwoBillFactorStr.trim())).getEntity();
            if(isNull(conversionTwoBF)){
                if (shouldCreateBillingError.isTrue()) {
                    addError(CustomMessageRepository.nm0100InvalidBillFactor(ALG_DESC, conversionTwoBillFactorStr));
                }
                else {
                    isErrorEncountered = Bool.TRUE;
                    return;
                }
            }
        }
        // Validate Default Value
        try {
            defaultSQValue = new BigDecimal(defaultValueStr.trim());
        }
        catch(NumberFormatException e) {
            if (shouldCreateBillingError.isTrue()) {
                addError(CustomMessageRepository.nm0100DefaultValueNotNumeric(ALG_DESC, defaultValueStr));
            }
            else {
                isErrorEncountered = Bool.TRUE;
                return;
            }

        }
    }



    @SuppressWarnings("unchecked")
    private List<String> validateOptionType(String optType){

        List<String> strFeatureConfigVal = null;

        StringBuilder getOptionTypeString = new StringBuilder();
        getOptionTypeString.append("SELECT 'X' FROM CI_LOOKUP_VAL LOOK ");
        getOptionTypeString.append("WHERE TRIM(LOOK.FIELD_NAME) = (SELECT TRIM(WFM.EXT_SYS_TYP_FLG)|| '_OPT_TYP_FLG' FROM CI_WFM WFM WHERE WFM.WFM_NAME = :wfmName) ");
        // CCB v2.6 Upgrade - 2018-07-25 - Start Change
        //getOptionTypeString.append("AND TRIM(LOOK.FIELD_VALUE) = :optionType ");
        getOptionTypeString.append("AND LOOK.FIELD_VALUE = :optionType ");
        // CCB v2.6 Upgrade - 2018-07-25 - End Change
        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //PreparedStatement optionTypeStmt = createPreparedStatement(getOptionTypeString.toString()); 
        PreparedStatement optionTypeStmt = createPreparedStatement(getOptionTypeString.toString(), getClass().getName()); 
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        optionTypeStmt.bindId("wfmName", featureConfig.getId());        
        optionTypeStmt.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType,optType.trim());
        if(isNull(optionTypeStmt.firstRow())){
            addError(CustomMessageRepository.nm0100InvalidOptionTypForFeatureConfig(ALG_DESC,optType,featureConfStr)); 
        }
        optionTypeStmt.close();

        CmFeatureConfigurationRetriever cmFeatureConfigurationRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
        cmFeatureConfigurationRetriever.setParmWFMName(featureConfig);
        cmFeatureConfigurationRetriever.setParmOptType(optType);
        strFeatureConfigVal = cmFeatureConfigurationRetriever.getListOfOptionValues();
        return strFeatureConfigVal;
    }


    /**
     * This method will perform algorithm processing rules
     *
     */
    private void performProcessingRules() {
        Date billSegStartDate = applyRateData.getBillSegmentPeriodStart();
        Date billSegEndDate = applyRateData.getBillSegmentPeriodEnd();
        serviceAgreement = applyRateData.getServiceAgreement();

        boolean isBsegSQRetrieved = false;

        // Retrieve Maximum Contract Quantity SQI 
        BigDecimal maxContractQty = BigDecimal.ZERO;
        Iterator<BillSegmentServiceQuantityData> itr = billSegmentServiceQuantityData.iterator();
        while(itr.hasNext()) {
            BillSegmentServiceQuantityData data = itr.next();
            ServiceQuantityIdentifier sqi = data.getBillSegmentServiceQuantityDto().getId().fetchServiceQuantityIdentifier();
            if(contractQuantityMaximumSqi.equals(sqi)) {
                maxContractQty = data.getBillSegmentServiceQuantityDto().getBillableServiceQuantity();
                isBsegSQRetrieved = true;
                break;
            }
        }

        if (!isBsegSQRetrieved) {
            if (shouldCreateBillingError.isTrue()) {
                addError(CustomMessageRepository.nm0100SQINotFound(ALG_DESC, contractQuantityMaximumSqi.getId().getTrimmedValue()));
            }
            else {
                isErrorEncountered = Bool.TRUE;
                return;
            }
        }

        //         Get limiting period
        BigDecimal overallComputation = BigDecimal.ZERO;
        Bool useHighestRead = Bool.FALSE;
        BigDecimal highestReadInPeriod = BigDecimal.ZERO;
        Bool hasLimitation = Bool.FALSE;

        for(String limitingOptVal : listOfLimitingPeriods){

            String[] dates = limitingOptVal.split(COMMA_DELIMITER);
            Date limitStartDt = null;
            Date limitEndDt = null;
            String dateStr = "";
            try{
                dateStr = dates[0];
                limitStartDt = Date.fromString(dateStr, new DateFormat(DATE_FORMAT));
                dateStr = dates[1];
                limitEndDt = Date.fromString(dateStr, new DateFormat(DATE_FORMAT));
            }catch(DateFormatParseException e){
                addError(CustomMessageRepository.nm0100InvalidDate(ALG_DESC, featureConfStr, dateStr.trim()));
            }
            // check if limiting period in billing period
            /* if(limitStartDt.isBefore(billSegStartDate) || limitEndDt.isAfter(billSegEndDate)){
                continue;
            }
            Date tempDate = limitStartDt;*/
            // Start of Changes -  06/04/2013 for checking whether Limitation Period is during Billing Period

            /* limitStartDt - Limiting Period start Date 
             *  LE - Limiting Period End Date 
             *  BE - Bill Seg End Date , 
             *   BS - Bill Segment Start Date
             */

        //  Condition # 1 : If LS > BE || LE < BS
            if(hasLimitation.isFalse()){
                if((limitStartDt.isAfter(billSegEndDate) || limitEndDt.isBefore(billSegStartDate))){
                    continue;
                }
            }

            //  Condition # 2 : If LS <= BS && LE >= BE, Process for limitation Period Days that are inside  Billing Period
            if(hasLimitation.isFalse()){
                if (limitStartDt.isSameOrBefore(billSegStartDate) && limitEndDt.isSameOrAfter(billSegEndDate)){
                    limitStartDt = billSegStartDate;
                    limitEndDt = billSegEndDate;                                      
                    hasLimitation = Bool.TRUE;
                }
            }

            // Condition # 3 : If LS > BS && LE < BE, Process for all days in the Limitation Period

            if(hasLimitation.isFalse()){
                // Start change by Neha
                // if(limitStartDt.isAfter(billSegStartDate)&& limitEndDt.isBefore(billSegEndDate)){
                if(limitStartDt.isSameOrAfter(billSegStartDate)&& limitEndDt.isSameOrBefore(billSegEndDate)){
                 // End change by Neha
                    hasLimitation = Bool.TRUE;
                }
            }

            // Condition # 4 : If LS <= BS and BS < LE < BE (i.e LE is between BS and BE) - 
            // Process for days starting with BS till LE

            if(hasLimitation.isFalse()){
                if(limitStartDt.isSameOrBefore(billSegStartDate)&&  
                     // Start change by Neha
                        //(billSegStartDate.isBefore(limitEndDt)&& limitEndDt.isAfter(billSegEndDate) )) {
                        (billSegStartDate.isSameOrBefore(limitEndDt)&& limitEndDt.isBefore(billSegEndDate) )) {
                 // End change by Neha
                    limitStartDt = billSegStartDate;
                    hasLimitation = Bool.TRUE;
                }
            }

            // Condition # 5 : If BS<LS<BE  (i.e. LS is in between BS and BE ) and LE > BE,  
            // then process days only from starting with LS 

            if(hasLimitation.isFalse()){
             // Start change by Neha
                // if((billSegStartDate.isBefore(limitStartDt)&& limitStartDt.isBefore(billSegEndDate)) 
                if((billSegStartDate.isBefore(limitStartDt)&& limitStartDt.isSameOrBefore(billSegEndDate)) 
                     // End change by Neha
                        && (limitEndDt.isAfter(billSegEndDate))){
                    limitEndDt = billSegEndDate;
                    hasLimitation = Bool.TRUE;
                }
            }
            
            Date tempDate = limitStartDt;
         // Start change by Neha
            //            if(limitationPeriodAvailable.isTrue()) {    
            if(hasLimitation.isFalse()){
                continue;
            }
         // End change by Neha
            // End of Changes -  06/04/2013

                while (tempDate.isSameOrBefore(limitEndDt)) {
                    // Get the Daily Meter reading for the day
                    // KL20131105 - Start of change - Added +1 day while retrieving daily consumption.
                    //BigDecimal dailyReading = getDailyReading(tempDate);
                    BigDecimal dailyReading = getDailyReading(tempDate.addDays(1));
                    // BigDecimal dailyTherm = BigDecimal.ZERO;
                    // KL20131105 - End of change

                    BigDecimal dailyTherm = dailyReading;

                    BigDecimal factorVal = BigDecimal.ZERO;

                    if(notNull(conversionOneBF)){
                        factorVal = retrieveBillFactorValue(conversionOneBF, tempDate);
                        if(conversionOneBF.getValueType().isPercentage()){
                            dailyTherm = dailyReading.multiply(factorVal.divide(BigDecimal.valueOf(100)));
                        }else{
                            dailyTherm = dailyReading.multiply(factorVal);
                        }
                    }
                    if(notNull(conversionTwoBF)){
                        factorVal = retrieveBillFactorValue(conversionTwoBF, tempDate);
                        if(isNull(conversionOneBF)){
                            if(conversionTwoBF.getValueType().isPercentage()){
                                dailyTherm = dailyReading.multiply(factorVal.divide(BigDecimal.valueOf(100)));
                            }else{
                                dailyTherm = dailyReading.multiply(factorVal);
                            }
                        }else{
                            if(conversionTwoBF.getValueType().isPercentage()){
                                dailyTherm = dailyTherm.multiply(factorVal.divide(BigDecimal.valueOf(100)));
                            }else{
                                dailyTherm = dailyTherm.multiply(factorVal);
                            }
                        }
                    }
                    if(dailyTherm.compareTo(maxContractQty) > 0) {
                        useHighestRead = Bool.TRUE;
                    }
                    if(highestReadInPeriod.compareTo(dailyTherm) < 0){
                        highestReadInPeriod =  dailyTherm;
                    }

                    tempDate = tempDate.addDays(1);
                }
            }
//        }
        if(useHighestRead.isTrue()){
            overallComputation = highestReadInPeriod;
        }else{
            overallComputation = defaultSQValue;
        }
        if(overallComputation.compareTo(BigDecimal.ZERO) <= 0) {

            overallComputation = defaultSQValue;

        } 
        // Add a new entry using the totalAmount as the Initial SQ and Bill SQ
        createSQIs(overallComputation);
    }

    private BigDecimal getDailyReading(Date limitingDate){

        StringBuilder getReadingString = new StringBuilder();
        getReadingString.append(" SELECT SASP.USAGE_FLG, REG.CONSUM_SUB_FLG, RR.REG_READING READING, ");
        getReadingString.append("       NVL((SELECT RR2.REG_READING FROM  CI_MR MR2 ");
        getReadingString.append("       , CI_REG_READ RR2 ");
        getReadingString.append("       WHERE HIST.MTR_CONFIG_ID = MR2.MTR_CONFIG_ID ");
        getReadingString.append("       AND MR2.MR_ID =  RR2.MR_ID ");
        getReadingString.append("       AND REG.REG_ID = RR2.REG_ID ");
        getReadingString.append("       AND MR2.READ_DTTM = (SELECT MAX(MR3.READ_DTTM) FROM CI_MR MR3 ");
        getReadingString.append("               WHERE MR3.MTR_CONFIG_ID= HIST.MTR_CONFIG_ID ");   
        getReadingString.append("               AND TRUNC(MR3.READ_DTTM) < TRUNC(MR.READ_DTTM) ");
        getReadingString.append("               ) ");
        getReadingString.append("       ),0) PREV_READING  ");
        getReadingString.append(" FROM CI_SP_MTR_HIST HIST ");
        getReadingString.append(" , CI_SP_MTR_EVT EVNT ");
        getReadingString.append(" , CI_SA_SP SASP ");
        getReadingString.append(" , CI_MR MR ");
        getReadingString.append(" , CI_REG_READ RR ");
        getReadingString.append(" , CI_REG REG ");
        getReadingString.append(" , CI_MR MR1 ");
        getReadingString.append(" WHERE SASP.SA_ID = :saId ");
        getReadingString.append(" AND SASP.START_DTTM <= :limitationPeriodDay ");
        getReadingString.append(" AND SASP.SP_ID=HIST.SP_ID ");
        getReadingString.append(" AND (HIST.REMOVAL_DTTM >= :limitationStartDay OR HIST.REMOVAL_DTTM IS NULL) ");
        getReadingString.append(" AND EVNT.SP_MTR_EVT_FLG = :install ");
        getReadingString.append(" AND HIST.SP_MTR_HIST_ID = EVNT.SP_MTR_HIST_ID ");
        getReadingString.append(" AND EVNT.MR_ID = MR1.MR_ID ");
        getReadingString.append(" AND MR1.MTR_CONFIG_ID = HIST.MTR_CONFIG_ID ");
        getReadingString.append(" AND MR1.READ_DTTM <= :limitationPeriodDay   ");
        getReadingString.append(" AND MR.MTR_CONFIG_ID = HIST.MTR_CONFIG_ID ");
        getReadingString.append(" AND RR.MR_ID = MR.MR_ID ");
        getReadingString.append(" AND REG.REG_ID = RR.REG_ID ");
        getReadingString.append(" AND REG.UOM_CD =  :correctedUom ");
        getReadingString.append(" AND MR.READ_DTTM = (SELECT MAX(MR2.READ_DTTM) FROM CI_MR MR2 ");
        getReadingString.append("                    WHERE MR2.MTR_CONFIG_ID= HIST.MTR_CONFIG_ID ");
        getReadingString.append("                    AND TRUNC(MR2.READ_DTTM) = TRUNC(:limitationPeriodDay) ");
        getReadingString.append("                    ) ");
        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        //PreparedStatement readPrepStmt = createPreparedStatement(getReadingString.toString());
        PreparedStatement readPrepStmt = createPreparedStatement(getReadingString.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        readPrepStmt.bindId("saId", serviceAgreement.getId());
        readPrepStmt.bindDateTime("limitationStartDay", limitingDate.startOfDay());
        readPrepStmt.bindDateTime("limitationPeriodDay", limitingDate.endOfDay());
        readPrepStmt.bindLookup("install", ServicePointMeterEventTypeLookup.constants.INSTALL);
        readPrepStmt.bindId("correctedUom", correctedUomCd);

        List<SQLResultRow> resultList = readPrepStmt.list();
        readPrepStmt.close();

        if(resultList.isEmpty()){
            // No read found for limitation period day %1 gas purchased sq rule.
            addError(CustomMessageRepository.nm0100NoReadFoundForDay(limitingDate.toString()));
        }
        BigDecimal dailyRead = BigDecimal.ZERO;
        for(SQLResultRow resultrow : resultList){
            HowToUseReadLookup usageFlg = resultrow.getLookup("USAGE_FLG", HowToUseReadLookup.class);
            ConsumptionTypeLookup consumptionTypeLookup = resultrow.getLookup("CONSUM_SUB_FLG", ConsumptionTypeLookup.class);
            BigDecimal read = resultrow.getBigDecimal("READING");
            BigDecimal prevRead = resultrow.getBigDecimal("PREV_READING");
            BigDecimal actualConsumption = BigDecimal.ZERO;
            if(consumptionTypeLookup.isSubtractive()){
                actualConsumption = read.subtract(prevRead);
            }else{
                actualConsumption = read;
            }
            if(usageFlg.isAdd()){
                dailyRead = dailyRead.add(actualConsumption);
            }else{
                dailyRead = dailyRead.subtract(actualConsumption);
            }
        }
        return dailyRead;
    }

    /**
     * This method is to retrieve the bill factor Value. 
     * @param billFactor
     * @return BigDecimal
     */
    private BigDecimal retrieveBillFactorValue(BillFactor billFactor,Date limitingDate){
        BigDecimal bfValue = BigDecimal.ZERO;
        BillFactorValueInfoRetriever bfValueinfoRetriever = BillFactorValueInfoRetriever.Factory.newInstance();
        BillFactorValueInfoRetrieverData bfValueInfo = BillFactorValueInfoRetrieverData.Factory.newInstance();

        bfValueInfo.setToGetBillFactor(Bool.TRUE);
        bfValueInfo.setBillFactor(billFactor);
        bfValueInfo.setBillFactorPeriodStartDate(limitingDate);
        bfValueInfo.setBillFactorPeriodEndDate(limitingDate);
        bfValueInfo.setNoProrationAccountingDate(limitingDate);
        bfValueInfo.setNoProrationStartDate(limitingDate);
        bfValueInfo.setNoProrationEndDate(limitingDate);
        bfValueInfo.setToFillTheGap(Bool.FALSE);
        bfValueInfo.setServiceAgreement(applyRateData.getServiceAgreement());
        bfValueInfo.setApplyRateData(applyRateData);
        //KL20131028 - Start of fix for IM-037739
        bfValueInfo.setCharSourcePremise(applyRateData.getCharacteristicPremise());
        bfValueInfo.setCharacteristicSourceServicePoint(applyRateData.getCharacteristicServicePoint());
        //KL20131028 - End of fix for IM-037739

        bfValueinfoRetriever.retrieveBillFactorValueInfo(bfValueInfo);
        List<BillFactorValueData> bfValueInfoCollection = bfValueInfo.getBillFactorValueInfoData().getBillFactorValueDataList();
        bfValue = bfValueInfoCollection.get(0).getBfValue();
        return bfValue;
    }

    private void createSQIs(BigDecimal overallComputation){
        BillSegmentServiceQuantity_DTO bsegServiceQuantityDTO = null;
        //KL20131028 - Start of fix for IM-037739
        String currentUOMStr = null;
        String currentTOUStr = null;
        //KL20131028 - End of fix for IM-037739
        String currentSQI = null;
        boolean hasSQI = false;

        startChanges();
        for(BillSegmentServiceQuantityData bsegSQData: billSegmentServiceQuantityData){
            bsegServiceQuantityDTO = bsegSQData.getBillSegmentServiceQuantityDto();
            if(isBlankOrNull(bsegServiceQuantityDTO.getId().getServiceQuantityIdentifier())){
                continue;
            }
            
            currentSQI = bsegServiceQuantityDTO.getId().getServiceQuantityIdentifier().trim();
            //KL20131028 - Start of fix for IM-037739
            currentUOMStr = bsegServiceQuantityDTO.getId().getUnitOfMeasure().trim();
            currentTOUStr = bsegServiceQuantityDTO.getId().getTimeOfUse().trim();

            if((currentUOMStr.compareTo(unitOfMeasureId.getTrimmedValue())==0) && 
            		(currentTOUStr.compareTo(timeOfUseId.getTrimmedValue())==0) && 
            			(currentSQI.compareTo(serviceQuantityIdentifierId.getTrimmedValue())==0)){
            //if((currentSQI.compareTo(serviceQuantityIdentifierId.getTrimmedValue())==0)){
            //KL20131028 - End of fix for IM-037739
                bsegServiceQuantityDTO.setBillableServiceQuantity(overallComputation.setScale(serviceQuantityIdentifierId.getEntity().getDecimalPositions().intValue(), MathContext.ROUND_HALF_UP));
                hasSQI = true;        
            }
            bsegSQData.setBillSegmentServiceQuantityDto(bsegServiceQuantityDTO);

        }

        if(!hasSQI){
            BillSegmentServiceQuantityData newBsegSQData = createBsegSQData(overallComputation);
            billSegmentServiceQuantityData.add(newBsegSQData);
        }
        saveChanges();
    }

    private BillSegmentServiceQuantityData createBsegSQData(BigDecimal serviceQuantity){
        BillSegmentServiceQuantityData billSegmentSqData = BillSegmentServiceQuantityData.Factory.newInstance();
        BillSegmentServiceQuantity_DTO billSegSQDTO = (BillSegmentServiceQuantity_DTO) createDTO(BillSegmentServiceQuantity.class);
        BillSegmentServiceQuantity_Id newBsegSQId = new BillSegmentServiceQuantity_Id(unitOfMeasureId, timeOfUseId, serviceQuantityIdentifierId, BillSegment_Id.NULL);
        billSegSQDTO.setId(newBsegSQId);
        //KL20131028 - Start of fix for IM-037739
        //billSegSQDTO.setInitialServiceQuantity(serviceQuantity.setScale(serviceQuantityIdentifierId.getEntity().getDecimalPositions().intValue(), MathContext.ROUND_HALF_UP));
        //billSegSQDTO.setBillableServiceQuantity(serviceQuantity.setScale(serviceQuantityIdentifierId.getEntity().getDecimalPositions().intValue(), MathContext.ROUND_HALF_UP));
        billSegSQDTO.setInitialServiceQuantity(serviceQuantity.setScale(initialSQScale, MathContext.ROUND_HALF_UP));
        billSegSQDTO.setBillableServiceQuantity(serviceQuantity.setScale(billableSQScale, MathContext.ROUND_HALF_UP));
        //KL20131028 - End of fix for IM-037739
        billSegmentSqData.setBillSegmentServiceQuantityDto(billSegSQDTO);
        return billSegmentSqData;
    }
}
