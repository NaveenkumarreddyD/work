/*********************************************************************************************
 * Program Name: CmDaffronCustImportBatch
 * Program Title: CmDaffronCustImportBatch
 * Author: Naga Yada
 * Creation Date: 2021-06-07
 * Purpose: This batch process will read the file and create/update the Daffron customer's data accordingly.
 * 
 **********************************************************************************************/
/*----------------------------------------------------------------------------------------
 *-------------------------- Modification HISTORY: ---------------------------------------
 * ---------------------------------------------------------------------------------------
 * Modification ID:   CCTicket:	  Author:          Date:       Description:
.* --------------------------------------------------------------------------------------
 * WmartRTP  	      46685  	  Naga Yada      2021-06-07    - Initial Version            
 *                                                      
 *****************************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.cm.domain.customerinfo.CmDaffronCustomerData.CmDaffronFisCusData;
import com.splwg.cm.domain.customerinfo.CmDaffronCustomerData.CmDaffronFisCusData_DTO;
import com.splwg.cm.domain.customerinfo.CmDaffronCustomerData.CmDaffronFisCusData_Id;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author 42422
 *
 @BatchJob (modules = {}, softParameters = { @BatchJobSoftParameter (name = CIS_DIVISON, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)})
 */
public class CmDaffronCustImportBatch extends CmDaffronCustImportBatch_Gen {
	
	public JobWork getJobWork() {
		ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
		arrayList.add(threadWorkUnit);

		return createJobWorkForThreadWorkUnitList(arrayList);
	}

	public Class<CmDaffronCustImportBatchWorker> getThreadWorkerClass() {
		return CmDaffronCustImportBatchWorker.class;
	}
	
	public void validateSoftParameters(boolean arg0){
		String parmFilePath;
		String parmFileName;
		File inputFile = null;
		// Validate that the file path.
		parmFilePath  = getParameters().getFILE_PATH().trim();
		File folder = new File(parmFilePath);
		if(!(folder.exists() && folder.isDirectory())) {
			addError(CustomMessageRepositorySpireOne.CCB029_1_invalidFilePath(parmFilePath));  
		}

		//Validate that the parameter FILE-NAME is a correct file name and that the corresponding file can be opened and read.
		parmFileName = getParameters().getFILE_NAME().trim();
		inputFile = new File(parmFilePath, parmFileName);
		if(!inputFile.exists() || !inputFile.canRead()){
			addError(CustomMessageRepositorySpireOne.CCB029_1_invalidFileName(parmFileName)); 
		}
		
	}

	public static class CmDaffronCustImportBatchWorker extends
			CmDaffronCustImportBatchWorker_Gen {
		
		Logger logger = LoggerFactory.getLogger(CmDaffronCustImportBatchWorker.class);
		
		// Soft Parameters
		private String parmFilePath;
		private String parmFileName;
		private File inputFile = null;
		private String cisDivison;
		
		//Working Variables
		private BufferedReader inputBufferReader = null;
		private BigInteger lineCounter = BigInteger.ZERO;
		
		private int totalFileRecordCount = 0;
		private int numberOfRecordsInError = 0;
		
		//Ignore the First character(0) of the each row.
		private final Integer DETAIL_START_ACT_NBR = 1;
		private final Integer ACT_NBR_LENGTH = 12;
		private final Integer DETAIL_START_CUST_NAME = 14;
		private final Integer CUST_NAME_LENGTH = 26;
		private final Integer DETAIL_START_ADDR = 41;
		private final Integer ADDR_LENGTH = 79;
		private final Integer DETAIL_START_CITY = 121;
		private final Integer CITY_LENGTH = 29;
		private final Integer DETAIL_START_STATE = 151;
		private final Integer STATE_LENGTH = 2;
		private final Integer DETAIL_START_ZIP = 154;
		private final Integer ZIP_LENGTH = 5;
		private final Integer DETAIL_START_PH_NBR = 160;
		private final Integer PH_NBR_LENGTH = 10;
		
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}
		
		/**
		 * Perform any initialization that must be done at the start of this thread processing work. 
		 * @param initializationPreviouslySuccessful - indicates that this method was called successfully called during some 
		 * prior execution, presumably because this is a restart situation.
		 * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
		 * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
		 * @see com.splwg.base.api.batch.ThreadWorker#initializeThreadWork(boolean) 
		 */
		public void initializeThreadWork(boolean initializationPreviouslySuccessful)
		throws ThreadAbortedException, RunAbortedException {
			initializeInputParameters();
		}

		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			processFile();
			WorkUnitResult results = new WorkUnitResult(true);
			results.setUnitsInError(numberOfRecordsInError);
			results.setUnitsProcessed(totalFileRecordCount);
			closeFile();
			return results;
		}
		
		private void initializeInputParameters(){
			parmFilePath  = getParameters().getFILE_PATH().trim();
			parmFileName = getParameters().getFILE_NAME().trim();
			inputFile = new File(parmFilePath, parmFileName);
			cisDivison = getParameters().getCIS_DIVISON().trim();
		}
		
		private void processFile(){
			openFile();
			String detailRecord = null;
			while(!isBlankOrNull(detailRecord = readRecord())){ 
				//Increment line counter
				lineCounter = lineCounter.add(BigInteger.ONE);

				try{
					insertCustRecord(detailRecord);
				} catch(ApplicationError ae){
					if(isBlankOrNull(ae.getServerMessage().getMessageText())){
						numberOfRecordsInError++;
						addError(CustomMessageRepositorySpireOne.CCB029_1_FileReadError(ae.getMessage().trim()));  
					}else{
						numberOfRecordsInError++;
						addError(CustomMessageRepositorySpireOne.CCB029_1_FileReadError(ae.getServerMessage().getMessageText().trim())); 
					}
				}
			}
		}
		
		/**
		  * This method opens a buffered reader for input file
		  *
		  */
		private void openFile() {
			try {                          
				 inputBufferReader = new BufferedReader(new FileReader(inputFile));                    
			} catch (IOException e) {
				throw new RunAbortedException(CustomMessageRepositorySpireOne.ccb030_2_errorOpeningFile(e.getMessage().trim()));                                      
			} 
		}

		 /**
		  * This method closes a buffered reader for input file
		  *
		  */
		private void closeFile() {
			try {
				 if(notNull(inputBufferReader))
					 inputBufferReader.close();           
			 } catch (IOException e) {
				 throw new RunAbortedException(CustomMessageRepositorySpireOne.ccb030_2_errorClosingFile(e.getMessage().trim()));                                        
			 }
		 }
		 
		 /**
		  * This method returns the next record from the input file.
		  * @return a String object.
		  */
		 private String readRecord() {
			 String record = null;
			 try {
				 record =  inputBufferReader.readLine();                 
			 } catch (IOException exception) {
				 throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB029_1_FileReadError(exception.getMessage().trim()));  
			 }  
			 return record;
		 }
		 
		 /**
		  * This method retrieves the trimmed field value from the record starting 
		  * from the startPos and of the given length.
		  * @param record
		  * @param startPos
		  * @param length
		  * @return
		  */
		private String getFieldValue(String record, int startPos, int length) {
			String value = "";
		  if(record.length() >= startPos+length){
			  value = record.substring(startPos, startPos+length).trim();
		  }
		  return value;
		}
	  
	  /**
	   * This method will insert/update record in CM_FISCUS_WIL using the file record.
	   * @param record
	   */
	    private void insertCustRecord(String record) {
	    	String accountId = null;
		    String custName = null;
		    String custAddress1 = null;
		    String city = null;
		    String state = null;
		    String postalCd = null;
		    String phone = null;
		  
		    accountId = getFieldValue(record, DETAIL_START_ACT_NBR, ACT_NBR_LENGTH);
		    custName = getFieldValue(record, DETAIL_START_CUST_NAME, CUST_NAME_LENGTH);
		    
		    //If the account ID is blank/empty, just ignore that record and continue the process.
		    if(isBlankOrNull(accountId)){
		    	logger.error("From Daffron Customer Data inbound file  processing Account ID is blank in line "+lineCounter.toString());
		    	numberOfRecordsInError++;
		    	return;
		    }
		    custAddress1 = getFieldValue(record, DETAIL_START_ADDR, ADDR_LENGTH);
		    city = getFieldValue(record, DETAIL_START_CITY, CITY_LENGTH);
		    state = getFieldValue(record, DETAIL_START_STATE, STATE_LENGTH);
		    postalCd = getFieldValue(record, DETAIL_START_ZIP, ZIP_LENGTH);
		    phone = getFieldValue(record, DETAIL_START_PH_NBR, PH_NBR_LENGTH);
		  
		    CmDaffronFisCusData_Id acctId = new CmDaffronFisCusData_Id(accountId);
		    CmDaffronFisCusData custEntity = acctId.getEntity();
		    CmDaffronFisCusData_DTO custDTO;
		    if(notNull(custEntity)) {
		    	custDTO = custEntity.getDTO();
		    	custDTO.setCmDaffCisDivision(cisDivison);
		    	custDTO.setCmDaffronCustName(custName);
		    	custDTO.setCmDaffronStreetAddress(custAddress1);
		    	custDTO.setCmDaffCity(city);
		    	custDTO.setCmDaffRegion(state);
		    	custDTO.setCmDaffPostal(postalCd);
		    	custDTO.setCmDaffronPhoneNumber(phone);
		    	custEntity.setDTO(custDTO);
		    } else {
		    	custDTO = createDTO(CmDaffronFisCusData.class);
		    	custDTO.setCmDaffCisDivision(cisDivison);
		    	custDTO.setCmDaffronCustName(custName);
		    	custDTO.setCmDaffronStreetAddress(custAddress1);
		    	custDTO.setCmDaffCity(city);
		    	custDTO.setCmDaffRegion(state);
		    	custDTO.setCmDaffPostal(postalCd);
		    	custDTO.setCmDaffronPhoneNumber(phone);
		    	custDTO.setId(acctId);
		    	custDTO.newEntity();
		    }
		    totalFileRecordCount++;
		  
	    }

	}

}
