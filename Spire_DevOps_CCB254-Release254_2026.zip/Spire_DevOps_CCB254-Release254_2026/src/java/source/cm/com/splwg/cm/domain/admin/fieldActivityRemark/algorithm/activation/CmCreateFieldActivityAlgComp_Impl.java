/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPOBFAX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-12   EQuint      Initial Version. 
 * 2016-05-30   MPang       Defect 3444302. Added close connection
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.   
 * 2025-11-14   EQuint      CCB25.4 Upgrade                     
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.fieldActivityRemark.algorithm.activation;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.admin.fieldActivityRemark.algorithm.activation.FieldActivityRemarkActivationAlgorithmSpot;
import com.splwg.ccb.domain.admin.fieldActivityRemarkCode.entity.FieldActivityRemarkCode;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpobfax;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = fieldActivityType, name = fieldActivityType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = fieldActivityCharType, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = fieldActivityRemarkCharType, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = curbBoxStandardRemarkCharType, required = true, type = entity)})
 */
public class CmCreateFieldActivityAlgComp_Impl extends
		CmCreateFieldActivityAlgComp_Gen implements
		FieldActivityRemarkActivationAlgorithmSpot {

	// hard parameter
	private Bool isComplete;
	private FieldActivityData faData;
	private FieldActivityRemarkCode faRemarkCode;
	private ServiceTask serviceTask;
	
	// soft parameter
	private FieldActivityType faType;
	private CharacteristicType faCharType;
	private CharacteristicType faRemarkCharType;
	private CharacteristicType curbBoxStandardRemarkCharType;
	
	// Work variables
	private Cmpobfax cmpobfax;
    //Start Add - MPang - Defect 3444302- 2016-05-30
    private Connection connection;
    //End Add - MPang - Defect 3444302- 2016-05-30
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	
	@Override
	public Bool getIsComplete() {
		return isComplete;
	}

	@Override
	public void setFieldActivityData(FieldActivityData arg0) {
		this.faData = arg0;
	}

	@Override
	public void setFieldActivityRemark(FieldActivityRemarkCode arg0) {
		this.faRemarkCode = arg0;
	}

	@Override
	public void setIsComplete(Bool arg0) {
		this.isComplete = arg0;
	}

	@Override
	public void setServiceTask(ServiceTask arg0) {
		this.serviceTask = arg0;
	}
	
	
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		faType = getFieldActivityType();
		faCharType = getFieldActivityCharType();
		faRemarkCharType = getFieldActivityRemarkCharType();
		curbBoxStandardRemarkCharType = getCurbBoxStandardRemarkCharType();
	}

	@Override
	public void invoke() {
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			if (notNull(faRemarkCode)) {
				cmpobfax.setInputWrkFaRemCd(faRemarkCode.getId().getTrimmedValue());
			}else{
				cmpobfax.setInputWrkFaRemCd(CobolCode.SPACES.toString());
			}
			if (notNull(serviceTask)) {
				cmpobfax.setF1SvcTaskId(serviceTask.getId().getTrimmedValue());
			}else{
				cmpobfax.setF1SvcTaskId(CobolCode.SPACES.toString());
			}
			
			if (notNull(faData)) {
				FieldActivity_DTO faDTO = faData.getFieldActivity_DTO();
				if (notNull(faDTO)) {
					if (notNull(faDTO.getId())) {
						cmpobfax.setOfactFaId(faDTO.getId().getTrimmedValue());
					}else{
						cmpobfax.setOfactFaId(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getFieldActivityTypeId())) {
						cmpobfax.setOfactFaTypeCd(faDTO.getFieldActivityTypeId().getTrimmedValue());
					}else{
						cmpobfax.setOfactFaTypeCd(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getServicePointId())) {
						cmpobfax.setOfactSpId(faDTO.getServicePointId().getTrimmedValue());
					}else{
						cmpobfax.setOfactSpId(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getFieldActivityPriority())) {
						cmpobfax.setOfactFaPriorityFlg(faDTO.getFieldActivityPriority().getLookupValue().getValueName().trim());
					}else{
						cmpobfax.setOfactFaPriorityFlg(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getCreatedBy())) {
						cmpobfax.setOfactFaCreatedByFlg(faDTO.getCreatedBy().getLookupValue().getValueName().trim());
					}else{
						cmpobfax.setOfactFaCreatedByFlg(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getScheduleDateTimeStart())) {
						cmpobfax.setOfactSchedDttm(faDTO.getScheduleDateTimeStart().toString());
					}else{
						cmpobfax.setOfactSchedDttm(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getFieldActivityStatus())) {
						cmpobfax.setOfactFaStatusFlg(faDTO.getFieldActivityStatus().getLookupValue().getValueName().trim());
					}else{
						cmpobfax.setOfactFaStatusFlg(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getIsEligibleForDispatch())) {
						String isEligibleForDispatch = (faDTO.getIsEligibleForDispatch().isTrue()) ? SWITCH_YES : SWITCH_NO;
						cmpobfax.setOfactEligDispatchSw(isEligibleForDispatch);
					}else{
						cmpobfax.setOfactEligDispatchSw(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getDispatchGroupId())) {
						cmpobfax.setOfactDispGrpCd(faDTO.getDispatchGroupId().getTrimmedValue());
					}else{
						cmpobfax.setOfactDispGrpCd(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getFieldOrderId())) {
						cmpobfax.setOfactFoId(faDTO.getFieldOrderId().getTrimmedValue());
					}else{
						cmpobfax.setOfactFoId(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getCreationDateTime())) {
						cmpobfax.setOfactCreDttm(faDTO.getCreationDateTime().toString());
					}else{
						cmpobfax.setOfactCreDttm(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getTestSelectionId())) {
						cmpobfax.setOfactTestSelId(faDTO.getTestSelectionId().getTrimmedValue());
					}else{
						cmpobfax.setOfactTestSelId(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getUserId())) {
						cmpobfax.setOfactUserId(faDTO.getUserId().getTrimmedValue());
					}else{
						cmpobfax.setOfactUserId(CobolCode.SPACES.toString());
					}
					if (notBlank(faDTO.getInstructions())) {
						cmpobfax.setOfactInstructions(faDTO.getInstructions().trim());
					}else{
						cmpobfax.setOfactInstructions(CobolCode.SPACES.toString());
					}
					if (notBlank(faDTO.getLongDescription())) {
						cmpobfax.setOfactDescrlong(faDTO.getLongDescription().trim());
					}else{
						cmpobfax.setOfactDescrlong(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getCancelReasonId())) {
						cmpobfax.setOfactFaCanRsnCd(faDTO.getCancelReasonId().getTrimmedValue());
					}else{
						cmpobfax.setOfactFaCanRsnCd(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getAppointmentScheduleId())) {
						cmpobfax.setOfactAppSchedId(faDTO.getAppointmentScheduleId().getTrimmedValue());
					}else{
						cmpobfax.setOfactAppSchedId(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getIlmDate())) {
						cmpobfax.setOfactIlmDt(faDTO.getIlmDate().toString());
					}else{
						cmpobfax.setOfactIlmDt(CobolCode.SPACES.toString());
					}
					if (notNull(faDTO.getVersion())) {
						cmpobfax.setOfactVersion(java.math.BigDecimal.valueOf(faDTO.getVersion()));
					}else{
						cmpobfax.setOfactVersion(java.math.BigDecimal.ZERO);
					}
					if (notBlank(faDTO.getExternalId())) {
						cmpobfax.setOfactFaExtId(faDTO.getExternalId().trim());
					}else{
						cmpobfax.setOfactFaExtId(CobolCode.SPACES.toString());
					}
					if (notBlank(faDTO.getIntermediateStatus())) {
						cmpobfax.setOfactFaIntStatusFlg(faDTO.getIntermediateStatus().trim());
					}else{
						cmpobfax.setOfactFaIntStatusFlg(CobolCode.SPACES.toString());
					}
					if (notBlank(faDTO.getFieldActivityDataArea())) {
						cmpobfax.setOfactFaDataArea(faDTO.getFieldActivityDataArea().trim());
					}
					if (notNull(faDTO.getFieldworkRescheduleReasonId())) {
						cmpobfax.setOfactFaReschedRsnCd(faDTO.getFieldworkRescheduleReasonId().getTrimmedValue());
					}else{
						cmpobfax.setOfactFaReschedRsnCd(CobolCode.SPACES.toString());
					}
				}
				
				if (notNull(faData.getIsFieldActivityTypeChanged())) {
					String isFieldActivityTypeChanged = (faData.getIsFieldActivityTypeChanged().isTrue()) ? SWITCH_YES : SWITCH_NO;
					cmpobfax.setOfactFaTypeChangeSw(isFieldActivityTypeChanged);
				}else{
					cmpobfax.setOfactFaTypeChangeSw(CobolCode.SPACES.toString());
				}
				
				
			}
			
			if (notNull(isComplete)) {
				String isCompleteRemark = (isComplete.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpobfax.setCompleteRemSw(isCompleteRemark);
			}else{
				cmpobfax.setCompleteRemSw(CobolCode.SPACES.toString());
			}
			
			// set cobol program's soft parameters
			cmpobfax.setAlgParmVal(1, faType.getId().getTrimmedValue()); 
			if (notNull(faCharType)) {
				cmpobfax.setAlgParmVal(2, faCharType.getId().getTrimmedValue()); 
			}else{
				cmpobfax.setAlgParmVal(2, CobolCode.SPACES.toString());
			}
			if (notNull(faRemarkCharType)) {
				cmpobfax.setAlgParmVal(3, faRemarkCharType.getId().getTrimmedValue()); 
			}else{
				cmpobfax.setAlgParmVal(3, CobolCode.SPACES.toString());
			}
			cmpobfax.setAlgParmVal(4, curbBoxStandardRemarkCharType.getId().getTrimmedValue()); 
			
			// invoke the main method
		    cmpobfax.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
		    //Start Delete - MPang - Defect 3444302- 2016-05-30
		    //ex.printStackTrace();
		    //End Delete - MPang - Defect 3444302- 2016-05-30
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmpobfax.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmpobfax.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmpobfax.getMessageParm(i);
			    			if (notBlank(cmpobfax.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmpobfax.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmpobfax.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmpobfax.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmpobfax.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    	isComplete = (cmpobfax.getCompleteRemSw().compareTo(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE;
		    }
		    else {
		        //Start Add - MPang - Defect 3444302- 2016-05-30
		        ex.printStackTrace();
		        //End Add - MPang - Defect 3444302- 2016-05-30
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmpobfax=Session.returnSessionAndCodeToCache(cmpobfax);
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//			//Start Add - MPang - Defect 3444302- 2016-05-30
//			try {
//                connection.close();
//            } catch (SQLException e) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
//            }
//			//End Add - MPang - Defect 3444302- 2016-05-30
			// end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}

	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
		FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
		RequestContext context = session.getRequestContext();
		
		// start update - equint - 2025-11-14 - CCB25.4 Upgrade
  		session.doWork(new ConnectionWork() {
  			
  			@Override
  			public void execute(Connection connection) throws SQLException {
  				try {  			        
  					String username = connection.getMetaData().getUserName();
  					String url = connection.getMetaData().getURL();
  					
  					CobolSession.setLogSessionStartEnd(false);
  				    cmpobfax=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpobfax.class);
  					
  					cmpobfax.getSession().getDbSession().setUpdateConnection(connection);
  					cmpobfax.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
  					
  					// set ZSTAT parameters

  					cmpobfax.setProcessDt(getProcessDateTime().getDate().toString());
  					cmpobfax.setProcessDttmSep("-");
  					cmpobfax.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
  					
  					if (session.isOnlineConnection()) { 
  						cmpobfax.setConnectionFlg(CONNECTION_ONLINE);
  					}
  					else {
  						cmpobfax.setConnectionFlg(CONNECTION_BATCH);
  					}
  					
  					cmpobfax.setZstatUserId(context.getUserId());
  					cmpobfax.setZstatLanguageCd(context.getLanguageCode());
  			        
  			        if (context.ignoreWarnings()) {
  			        	cmpobfax.setIgnoreWarningSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpobfax.setIgnoreWarningSw(SWITCH_NO);
  			        }
  			        
  			        if (session.getBatchInstanceId() != null) {
  			        	cmpobfax.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
  			        	
  					} else {
  						cmpobfax.setSchedulerId(new BigDecimal(0).toBigDecimal());
  					}
  			        
  			        cmpobfax.setAppSvcId(context.getSecurityServiceIdContext());
  			        
  			        DatabaseHelper dbHelper = session.getDatabaseHelper();
  			        cmpobfax.setDbMode(dbHelper.getCobolDBMode());
  			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
  			        //cmpobfax.setSplHighValue(cmpobfax.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
  			        //cmpobfax.setSplLowValue(cmpobfax.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
  			        
  			        cmpobfax.setSplHighValue(cmpobfax.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
  			        cmpobfax.setSplLowValue(cmpobfax.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
  			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
  			        
  			        cmpobfax.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
  			        
  			        cmpobfax.setLkExpiryDt(Date.MAX.toString());
  			        
  			        cmpobfax.setProgramStatus(" ");
  			        
  			        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
  			        cmpobfax.setCallSeq(";");
  			        cmpobfax.setMessageAreaProgramName("CMPOBFAX");
  			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
  			        
  			        if (context.getRandomGeneratorSeedSet().isTrue()) {
  			        	cmpobfax.setRandomGenSeedSw(SWITCH_YES);
  			        	cmpobfax.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
  			        	cmpobfax.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
  			        	cmpobfax.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
  			        	cmpobfax.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
  			        }
  			        else {
  			        	cmpobfax.setRandomGenSeedSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceStandardOut()) { 
  			        	cmpobfax.setTrcStdoutSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpobfax.setTrcStdoutSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramStart()) { 
  			        	cmpobfax.setTrcProgStartSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpobfax.setTrcProgStartSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramExit()) { 
  			        	cmpobfax.setTrcProgExitSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpobfax.setTrcProgExitSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceSQL()) { 
  			        	cmpobfax.setTrcExecSqlSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpobfax.setTrcExecSqlSw(SWITCH_NO);
  			        }
  			        
  			        // Set ZMSGN parms
  			        BigInteger messageSequence = session.getMessageSequence();
  			        if (notNull(messageSequence)) {
  			        	cmpobfax.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
  			        }
  			        else {
  			        	cmpobfax.setMessageSeq(new BigDecimal(0).toBigDecimal());
  			        }
  				}
  				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		 
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//        //Start Change - MPang - Defect 3444302- 2016-05-30
//        //Connection connection = implementor.getConnectionProvider().getConnection();
//        connection = implementor.getConnectionProvider().getConnection();
//        //End Change - MPang - Defect 3444302- 2016-05-30
//        
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmpobfax=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpobfax.class);
//		
//		cmpobfax.getSession().getDbSession().setUpdateConnection(connection);
//		cmpobfax.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		
//		// set ZSTAT parameters
//
//		cmpobfax.setProcessDt(getProcessDateTime().getDate().toString());
//		cmpobfax.setProcessDttmSep("-");
//		cmpobfax.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmpobfax.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmpobfax.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmpobfax.setZstatUserId(context.getUserId());
//		cmpobfax.setZstatLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmpobfax.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmpobfax.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmpobfax.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmpobfax.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmpobfax.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmpobfax.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmpobfax.setSplHighValue(cmpobfax.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmpobfax.setSplLowValue(cmpobfax.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmpobfax.setSplHighValue(cmpobfax.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmpobfax.setSplLowValue(cmpobfax.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmpobfax.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmpobfax.setLkExpiryDt(Date.MAX.toString());
//        
//        cmpobfax.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmpobfax.setCallSeq(";");
//        cmpobfax.setMessageAreaProgramName("CMPOBFAX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmpobfax.setRandomGenSeedSw(SWITCH_YES);
//        	cmpobfax.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmpobfax.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmpobfax.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmpobfax.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmpobfax.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmpobfax.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmpobfax.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmpobfax.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmpobfax.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmpobfax.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmpobfax.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmpobfax.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmpobfax.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmpobfax.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmpobfax.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }

  	// end update - equint - 2025-11-14 - CCB25.4 Upgrade
  		
	}

}
