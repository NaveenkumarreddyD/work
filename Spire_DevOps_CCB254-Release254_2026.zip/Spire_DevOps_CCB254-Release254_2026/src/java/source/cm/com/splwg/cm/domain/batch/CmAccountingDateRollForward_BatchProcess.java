/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Accounting Date Roll Forward Batch
 *
 * This batch process looks for adjustments awaiting approval and 
 * updates the accounting date on associated financial transactions to the 
 * batch business date. Adjustments can be excluded by adding a 
 * characteristic (see parameters 10/20). 
 * Adjustment and adjustment types with that characteristic will not be 
 * included in processing. 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2022-10-24   JVitug  E-05671. Initial Version.  
 **************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.List;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.AdjustmentStatusLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction_DTO;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author JVitug
 *
 @BatchJob (multiThreaded = true, rerunnable = false,
 *     modules={},
 *      softParameters = {@BatchJobSoftParameter (entityName = characteristicType, name = BYPASS_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = BYPASS_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = NBR_DAYS , type = integer)})
 */

public class CmAccountingDateRollForward_BatchProcess
extends CmAccountingDateRollForward_BatchProcess_Gen {
	
	//Soft Parameters
	CharacteristicType bypassAccountingDateCharType;
	String bypassAccountingDateCharVal;
	BigInteger numberOfDaysToLookBack;
	
	//For error Messages
	final String BYPASS_ACCT_DATE_CHAR_TYPE = "Bypass Accounting Date Characteristic Type";
	final String NUMBER_OF_DAYS_TO_LOOK_BACK = "Number of Days to Look Back";
	final String BYPASS_ACCT_DATE_CHAR_VAL = "Bypass Accounting Date Characteristic Value";
	
	public JobWork getJobWork() {
		QueryIterator mainIter = getEligibleAdjustments().iterate();
        return createJobWorkForQueryIterator(mainIter, this);
	}
	
	private PreparedStatement getEligibleAdjustments() {
		StringBuilder stringSql = new StringBuilder();
		
		stringSql.append("SELECT ADJ.ADJ_ID ");
		stringSql.append("FROM CI_ADJ ADJ ");
		stringSql.append("WHERE ADJ.ADJ_STATUS_FLG = :freezable ");
		stringSql.append("AND ADJ.APPR_REQ_ID > ' ' ");
		stringSql.append("AND NOT EXISTS (SELECT 'X' FROM CI_ADJ_CHAR AC ");
		stringSql.append("                WHERE ADJ.ADJ_ID = AC.ADJ_ID ");
		stringSql.append("                AND AC.CHAR_TYPE_CD = :charType ");
		stringSql.append("                AND AC.SRCH_CHAR_VAL = :charVal) ");
		stringSql.append("AND NOT EXISTS (SELECT 'X' FROM CI_ADJ_TY_CHAR ATC ");
		stringSql.append("                WHERE ADJ.ADJ_TYPE_CD = ATC.ADJ_TYPE_CD ");
		stringSql.append("                AND TRIM(ATC.CHAR_TYPE_CD) = TRIM(:charType) ");
		stringSql.append("                AND TRIM(ATC.CHAR_VAL) = TRIM(:charVal)) ");
		stringSql.append("AND ADJ.CRE_DT > :processDate - :numberOfDaysToLookBack ");
		
		PreparedStatement sql = createPreparedStatement(stringSql.toString(), getClass().getName());
		sql.bindLookup("freezable", AdjustmentStatusLookup.constants.FREEZABLE);
		sql.bindId("charType" , bypassAccountingDateCharType.getId());
		sql.bindDate("processDate" , getProcessDateTime().getDate());
		sql.bindString("charVal",bypassAccountingDateCharVal , "");
		sql.bindBigInteger("numberOfDaysToLookBack", numberOfDaysToLookBack);
		
		return sql;
	}
	
	public ThreadWorkUnit createWorkUnit(QueryResultRow row){
        ThreadWorkUnit threadUnit = new ThreadWorkUnit();   
        
        Adjustment_Id adjustmentId = (Adjustment_Id) row.getId("ADJ_ID", Adjustment.class);
        threadUnit.setPrimaryId(adjustmentId);
        
        return threadUnit;
    }  

	public void validateSoftParameters(boolean arg0){
		bypassAccountingDateCharType = getParameters().getBYPASS_CHAR_TYPE();
		bypassAccountingDateCharVal = getParameters().getBYPASS_CHAR_VAL();
		numberOfDaysToLookBack = getParameters().getNBR_DAYS();
		
		//Validate that the bypass accounting date characteristic type is valid for the Adjustment Entity
		CharacteristicEntity charEntity = new CharacteristicEntity_Id(bypassAccountingDateCharType , 
				CharacteristicEntityLookup.constants.ADJUSTMENT).getEntity();
		
		if(isNull(charEntity)) {
			addError(CustomMessageRepository.
					E05671_invalidCharacteristicTypeForEntity(BYPASS_ACCT_DATE_CHAR_TYPE, 
							bypassAccountingDateCharType.getId().getTrimmedValue(), 
							CharacteristicEntityLookup.constants.ADJUSTMENT.getLookupValue().fetchLanguageDescription()));
		}
		
		//Validate that the bypass accounting date characteristic type is valid for the Adjustment Type Entity
		charEntity = new CharacteristicEntity_Id(bypassAccountingDateCharType , 
				CharacteristicEntityLookup.constants.ADJUSTMENT_TYPE).getEntity();
		
		if(isNull(charEntity)) {
			addError(CustomMessageRepository.
					E05671_invalidCharacteristicTypeForEntity(BYPASS_ACCT_DATE_CHAR_TYPE, 
							bypassAccountingDateCharType.getId().getTrimmedValue(), 
							CharacteristicEntityLookup.constants.ADJUSTMENT_TYPE.getLookupValue().fetchLanguageDescription()));
		}
		
		//Validate that the numberOfDaysToLookBack is greater than zero
		if(notNull(numberOfDaysToLookBack)) {
			if(numberOfDaysToLookBack.compareTo(BigInteger.ZERO) < 0) {
				addError(CustomMessageRepository.E05671_batchParmNotGreaterThanZero(NUMBER_OF_DAYS_TO_LOOK_BACK, numberOfDaysToLookBack.toString()));
			}
		} else {
			//Set number of days to look back to zero
			numberOfDaysToLookBack = BigInteger.ZERO;
		}
		
		//Validate that the characteristic value parameter is a valid characteristic value for the characteristic type batch parameter
		if(bypassAccountingDateCharType.getCharacteristicType().isPredefinedValue()) {
			CharacteristicValue charValue = new CharacteristicValue_Id(bypassAccountingDateCharType , bypassAccountingDateCharVal).getEntity();
			
			if(isNull(charValue)) {
				addError(CustomMessageRepository.E05671_batchParmNotValidCharValForCharType(BYPASS_ACCT_DATE_CHAR_VAL,
						bypassAccountingDateCharVal.trim(), 
						bypassAccountingDateCharType.getId().getTrimmedValue()));
			}
		}
	}

	public Class<CmAccountingDateRollForward_BatchProcessWorker> getThreadWorkerClass() {
		return CmAccountingDateRollForward_BatchProcessWorker.class;
	}

	public static class CmAccountingDateRollForward_BatchProcessWorker
	extends CmAccountingDateRollForward_BatchProcessWorker_Gen {

		//Soft Parameters
		CharacteristicType bypassAccountingDateCharType;
		String bypassAccountingDateCharVal;
		BigInteger numberOfDaysToLookBack;
		

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
			bypassAccountingDateCharType = getParameters().getBYPASS_CHAR_TYPE();
			bypassAccountingDateCharVal = getParameters().getBYPASS_CHAR_VAL();
			numberOfDaysToLookBack = getParameters().getNBR_DAYS();
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
		throws ThreadAbortedException, RunAbortedException {
			
			Adjustment_Id adjustmentId = (Adjustment_Id) unit.getPrimaryId();

			FinancialTransaction_Id ftId;
			FinancialTransaction ft;
			FinancialTransaction_DTO ft_DTO;
			
			List<SQLResultRow> ftsLinkedToAdjustment = getFTsLinkedToAdjustment(adjustmentId);
			
			try {
				for(SQLResultRow row : ftsLinkedToAdjustment) {
					ftId = (FinancialTransaction_Id) row.getId("FT_ID", FinancialTransaction.class);
					ft = ftId.getEntity();
					ft_DTO = ft.getDTO();
					
					ft_DTO.setAccountingDate(getProcessDateTime().getDate());
					ft.setDTO(ft_DTO);
				}
			} catch(Exception e) {
				//If an exception occurs, log an error message in the batch run tree using the Adjustment ID
				logError(CustomMessageRepository.E05671_errorDuringProcessing(adjustmentId.getTrimmedValue() , 
						e.getLocalizedMessage()));
				return false;
			}
			
			return true;
		}
		
		/**
		 * This method will return the FTs linked to an adjustment
		 * @param adjustmentId
		 * @return list of FTs linked to an adjustmentId
		 */
		private List<SQLResultRow> getFTsLinkedToAdjustment(Adjustment_Id adjustmentId) {
			List<SQLResultRow> resultList = null;
			StringBuilder stringSql = new StringBuilder();
			
			stringSql.append("SELECT ");
			stringSql.append(   "FT.FT_ID ");
			stringSql.append("FROM ");
			stringSql.append(   "CI_FT FT ");
			stringSql.append("WHERE " );
			stringSql.append(   "FT.SIBLING_ID = :adjustmentId ");
			stringSql.append("AND " );
			stringSql.append(   "FT.FT_TYPE_FLG IN (:adjustment , :adjustmentCancel) ");
			
			PreparedStatement sql = createPreparedStatement(stringSql.toString() , getClass().getName());
			sql.bindId("adjustmentId" , adjustmentId);
			sql.bindLookup("adjustment" , FinancialTransactionTypeLookup.constants.ADJUSTMENT);
			sql.bindLookup("adjustmentCancel" , FinancialTransactionTypeLookup.constants.ADJUSTMENT_CANCELLATION);
			
			resultList = sql.list();
			sql.close();
			
			return resultList;
		}

	}

}
