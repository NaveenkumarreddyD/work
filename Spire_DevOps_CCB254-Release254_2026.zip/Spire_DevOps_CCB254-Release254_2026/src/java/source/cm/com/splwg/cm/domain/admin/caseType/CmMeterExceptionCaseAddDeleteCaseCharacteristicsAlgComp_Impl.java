/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Add Or Delete Case Characteristic 
 * 
 * This algorithm will either delete any existing FA_ID case characteristic 
 * or add a new FA_ID case characteristic.  
 *            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-04-01   JPunza  NI0007.5 Initial Version.
 * 2016-01-22   MPang	Updated for CCB v2.4 compilation
 *************************************************************************/

package com.splwg.cm.domain.admin.caseType;

import java.math.BigInteger;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.ccb.api.lookup.CaseLogTypeLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;

//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseTypeExitStatusAlgorithmSpot;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.FieldActivityCancelReason;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCancelProcessorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameter_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameter_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameters;
import com.splwg.ccb.domain.todo.toDoCase.CaseLog_DTO;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCaseCharacteristics;*/

import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.algorithm.exitStatus.ExitStatusAlgorithmSpot;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.entity.FieldActivityCancelReason;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCancelProcessorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameter_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameter_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameters;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCaseCharacteristics;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.cm.domain.customMessages.CustomMessagesMDC;
import com.splwg.shared.common.ApplicationError;

/**
 * @author jpunzalan2
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = fieldActivityIdCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = fieldActivityStatus, name = newFieldActivityStatus, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityCancelReason, name = fieldActivityCancelReason, type = entity)})
 */
public class CmMeterExceptionCaseAddDeleteCaseCharacteristicsAlgComp_Impl
        extends CmMeterExceptionCaseAddDeleteCaseCharacteristicsAlgComp_Gen
      //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        // implements CaseTypeExitStatusAlgorithmSpot {
        implements ExitStatusAlgorithmSpot {
	//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
    // Constant Variable
    private final String FA_ID = "Field Activity Id";
    
    // Soft Parameters
    private CharacteristicType faIdCharType;
    private FieldActivityStatusLookup newFaStatus;
    private FieldActivityCancelReason cancelReason;
    
    // Hard Parameter
    private ToDoCase toDoCase;
       
    public void setCase(ToDoCase arg0) {
        toDoCase = arg0;
    }

    public void setNextCaseStatus(CaseStatus arg0) {

    }
    
    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        
        // Field Activity Id Characteristic Type
        faIdCharType = getFieldActivityIdCharacteristicType();
        if (validateCharacteristicEntity(faIdCharType, CharacteristicEntityLookup.constants.CASE).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0007_5_charTypeInvalidForEntity(
                    getAlgorithm().getId().getTrimmedValue(),
                    FA_ID,
                    faIdCharType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.CASE.getLookupValue().fetchLanguageDescription()));
        }
        
        if (validateCharacteristicEntity(faIdCharType, CharacteristicEntityLookup.constants.CASE_LOG).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0007_5_charTypeInvalidForEntity(
                    getAlgorithm().getId().getTrimmedValue(),
                    FA_ID,
                    faIdCharType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.CASE_LOG.getLookupValue().fetchLanguageDescription()));
        }
        
        // New Field Activity Status
        newFaStatus = getNewFieldActivityStatus();
        
        // Field Activity Cancel Reason
        cancelReason = getFieldActivityCancelReason();        
        if (newFaStatus.isCanceled() && isNull(cancelReason)) {
            addError(CustomMessageRepositoryMDC.NI0007_5_cancelReasonRequired(getAlgorithm().getId().getTrimmedValue()));
        }        
    }
    
    /**
     * This method validates if a characteristic type is valid for a specific characteristic entity.
     * @param charType - Characteristic Type
     * @param charEntityLookup - Characteristic Entity Lookup
     * @return Bool
     */
    private Bool validateCharacteristicEntity(CharacteristicType charType, CharacteristicEntityLookup charEntityLookup) {
        
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType.getId(), charEntityLookup);        
        if (isNull(charEntityId.getEntity())) {
            return Bool.FALSE;
        }
        
        return Bool.TRUE;
    }

    public void invoke() {
    
        // Retrieve the current FA from the Case Log
        SQLResultRow result = getLatestCaseLog().firstRow();
        if (isNull(result)) {
            addError(CustomMessageRepositoryMDC.NI0007_5_noFaInCaseLog(faIdCharType.getId().getTrimmedValue()));
        }
        String latestFaIdString = result.getString("VALUE").trim();
        
        // Retrieve Case Characteristics with the given Characteristic Type
        ToDoCaseCharacteristics caseChars = toDoCase.getCharacteristics();
        String faIdString = ""; 
        //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        // ListFilter<CaseCharacteristic> charFilter = caseChars.createFilter("where this.id.characteristicType = :charType");
        ListFilter<CaseCharacteristic> charFilter = caseChars.createFilter("where this.id.characteristicType = :charType" , getClass().getName());
        //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        charFilter.bindEntity("charType", faIdCharType);

        QueryIterator<CaseCharacteristic> iter = charFilter.iterate();
                 
        while (iter.hasNext()) {
        
            CaseCharacteristic caseChar = iter.next();
                        
            // Retrieve FA Id from characteristic           
            CharacteristicTypeLookup charTypeLookup = faIdCharType.getCharacteristicType();
            if (charTypeLookup.isForeignKeyValue()) {
                faIdString = caseChar.getCharacteristicValueForeignKey1().trim();
            }
            else if (charTypeLookup.isPredefinedValue()) {
                faIdString = caseChar.getCharacteristicValue().trim();
            }
            else {            
                faIdString = caseChar.getAdhocCharacteristicValue().trim();
            }
            
            FieldActivity fa = (new FieldActivity_Id(faIdString)).getEntity();
            if (isNull(fa)) {
                iter.close();
                addError(CustomMessageRepositoryMDC.NI0007_5_faIdInvalid(
                        faIdCharType.getId().getTrimmedValue(), 
                        caseChar.fetchIdSequence().toString(),
                        faIdString));
            }
            
            // If Canceled
            if (newFaStatus.isCanceled()) {

                FieldActivityCancelProcessorData faCancelData = FieldActivityCancelProcessorData.Factory.newInstance();
                faCancelData.setFieldActivity(fa);
                faCancelData.setMustCancelDispatchedFa(Bool.TRUE);
                faCancelData.setCancelReason(cancelReason);                
                fa.cancel(faCancelData);
            }
            else if (newFaStatus.isCompleted()) { // If Completed              
                
                try {
                    fa.complete(); 
                }
                catch (ApplicationError ae) {
                    iter.close();
                    addError(CustomMessageRepositoryMDC.NI0007_5_unableToCompleteFa(faIdString));
                }                
            }
            
            // Delete Case Characteristic
            caseChars.remove(caseChar);
            
            // Create Case Log for Delete
            createCaseLog(caseChar.fetchIdSequence(), faIdString, Bool.TRUE);                                    
        }
        iter.close();
        
        // Add Case Characteristic
        addCaseCharacteristic(latestFaIdString);        
    }
    
    /**
     * This method retrieves the latest Case Log a given the Characteristic Type.
     * @return PreparedStatement
     */
    private PreparedStatement getLatestCaseLog() {
        
        StringBuilder sb = new StringBuilder("SELECT ");
        CharacteristicTypeLookup charTypeLookup = faIdCharType.getCharacteristicType();
        if (charTypeLookup.isForeignKeyValue()) {
            sb.append("CL.CHAR_VAL_FK1 AS VALUE ");
        }
        else if (charTypeLookup.isPredefinedValue()) {
            sb.append("CL.CHAR_VAL AS VALUE ");
        }
        else {            
            sb.append("CL.ADHOC_CHAR_VAL AS VALUE ");
        }
        sb.append("FROM CI_CASE_LOG CL " +
                "WHERE CL.CASE_ID = :case " +
                "AND CL.CHAR_TYPE_CD = :charType " +
                "AND CL.SEQ_NUM = (SELECT MAX(CL2.SEQ_NUM) FROM CI_CASE_LOG CL2 " +
                "       WHERE CL2.CASE_ID = CL.CASE_ID " +
                "       AND CL2.CHAR_TYPE_CD = CL.CHAR_TYPE_CD)");
      //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
      // PreparedStatement getCaseLog = createPreparedStatement(sb.toString());
        PreparedStatement getCaseLog = createPreparedStatement(sb.toString(), getClass().getName());
      //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        getCaseLog.bindEntity("case", toDoCase);
        getCaseLog.bindEntity("charType", faIdCharType);
        
        return getCaseLog;
    }
    
    /**
     * This method adds Case Characteristic.
     * @param charValue - Characteristic Value
     */
    private void addCaseCharacteristic(String charValue) {
        
        CharacteristicTypeLookup charTypeLookup = faIdCharType.getCharacteristicType(); 
        ToDoCaseCharacteristics caseChars = toDoCase.getCharacteristics();
            
        // Add Case Characteristic
        CaseCharacteristic_DTO caseCharDto = caseChars.newChildDTO();
        
        if (charTypeLookup.isForeignKeyValue()) {
            caseCharDto.setCharacteristicValueForeignKey1(charValue);
        }
        else if (charTypeLookup.isPredefinedValue()) {
            caseCharDto.setCharacteristicValue(charValue); 
        } 
        else { 
            caseCharDto.setAdhocCharacteristicValue(charValue);
        }
        
        CaseCharacteristic caseChar = caseChars.add(caseCharDto, faIdCharType.getId(), null); 
        
        // Create Case Log for Add
        createCaseLog(caseChar.fetchIdSequence(), charValue, Bool.FALSE); 
    }
    
    /**
     * This method creates Case Log.
     * @param seqNum - Sequence Number
     * @param charValue - Characteristic Value
     * @param actionDelete - Add or Delete
     */
    private void createCaseLog(BigInteger seqNum, String charValue, Bool actionDelete) {
        
        // Create Case Log Entry
        CaseLog_DTO caseLogDto = new CaseLog_DTO();
        caseLogDto.setCaseStatusId(toDoCase.getCaseStatus().getId());
        caseLogDto.setCharacteristicTypeId(faIdCharType.getId());
        
        CharacteristicTypeLookup charTypeLookup = faIdCharType.getCharacteristicType();
        if (charTypeLookup.isForeignKeyValue()) {
            caseLogDto.setCharacteristicValueForeignKey1(charValue);
        }
        else if (charTypeLookup.isPredefinedValue()) {
            caseLogDto.setCharacteristicValue(charValue);
        }
        else {
            caseLogDto.setAdhocCharacteristicValue(charValue);
        }
        
        caseLogDto.setLogType(CaseLogTypeLookup.constants.SYSTEM);
        
        // Set Message Id depending on Action
        MessageCategory_Id messageCategoryId = new MessageCategory_Id(BigInteger.valueOf(CustomMessagesMDC.MESSAGE_CATEGORY));
        if (actionDelete.isTrue()) {
            caseLogDto.setMessageId(new Message_Id(messageCategoryId, BigInteger.valueOf(CustomMessagesMDC.NI0007_5_CASE_CHAR_DELETE)));
        }
        else {
            caseLogDto.setMessageId(new Message_Id(messageCategoryId, BigInteger.valueOf(CustomMessagesMDC.NI0007_5_CASE_CHAR_ADD)));
        }        
                
        // Get newly created Case Log
        CaseLog caseLog = toDoCase.getLogs().add(caseLogDto, null);                    

        CaseLogMessageParameters messageParms = caseLog.getMessageParameters();
        
        // Add message parameter for characteristic type
        CaseLogMessageParameter_DTO caseLogMsgParmDto = messageParms.newChildDTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.ONE));
        caseLogMsgParmDto.setMessageParameter(faIdCharType.getId().getTrimmedValue());        
        messageParms.add(caseLogMsgParmDto, BigInteger.ONE);
        
        // Add message parameter for sequence number
        caseLogMsgParmDto = messageParms.newChildDTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.valueOf(2)));
        caseLogMsgParmDto.setMessageParameter(seqNum.toString().trim());        
        messageParms.add(caseLogMsgParmDto, BigInteger.valueOf(2));
        
        // Add message parameter for characteristic value
        caseLogMsgParmDto = messageParms.newChildDTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.valueOf(3)));
        caseLogMsgParmDto.setMessageParameter(charValue);        
        messageParms.add(caseLogMsgParmDto, BigInteger.valueOf(3));        
    }
}
