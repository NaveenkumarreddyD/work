/*
 ***************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Credit Card Auto Pay Batch
 * 
 *            
 ****************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2020-04-21   JLumbre SpireOne. CCB-102. Initial Version.
 * 2020-05-06   JLumbre SpireOne. Update apayAmt based on Current Balance. If
 * 								  curBalance <=0,no payment generated. If 
 * 								  curBalance < apayAmt, update apayAmt = curBal.
 * 2020-06-04   JLumbre QAComplete#4438817. Update selection criteria to look
 * 								  for auto pay end >= process date. this is when
 * 								  the auto pay is updated from CC to ACH.
 * 2020-08-10   JLumbre QAComplete#4465427. Change next processing date on CC 
 * 								  failed AutoPay to next business day
 * 2020-10-08   JLumbre QAComplete#4498857. two outbound messages get created
 * 						in case of warning/error.
 * 2021-02-08   JLumbre B-18110. Add CIS Division for different batch
 * 						to process AL/Gulf accounts.  
 *   
 ****************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
//import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.businessService.BusinessServiceDispatcher;
import com.splwg.base.api.businessService.BusinessServiceInstance;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.serviceScript.ServiceScriptDispatcher;
import com.splwg.base.api.serviceScript.ServiceScriptInstance;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.currency.Currency_Id;
import com.splwg.base.domain.common.workCalendar.WorkCalendar;
import com.splwg.ccb.api.lookup.BillStatusLookup;
import com.splwg.ccb.domain.admin.autopayRouteType.entity.AutopayRouteType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillCharacteristic;
import com.splwg.ccb.domain.billing.bill.entity.BillCharacteristic_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillCharacteristics;
import com.splwg.ccb.domain.billing.bill.entity.Bill_DTO;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.common.currency.entity.Currency;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountAutopay;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountAutopay_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.data.AccountFinancialBalanceData;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author TMG02631
 *
@BatchJob (rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = autopayRouteType, name = AUTO_PAY_ROUTE_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = PAYMENT_METHOD_TOKEN, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = BILL_PROCESSED_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = REPROCESS_FAILURE_CODES, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CIS_DIVISION, type = string)})
 */
public class CmCreditCardAutoPayBatch extends CmCreditCardAutoPayBatch_Gen {

	private static final Logger log = LoggerFactory.getLogger(CmCreditCardAutoPayBatch.class);


	private AutopayRouteType ccRouteType;
	
	//Start Add - JLumbre - SAP Conversion
	private String companyCodeStr;
	private String companyCodes = "";


	@Override
	public void validateSoftParameters(boolean isNewRun) {
		companyCodeStr = getParameters().getCIS_DIVISION();

		//String companyCode;
		String[] companyCodes = companyCodeStr.split(",");
		for (String companyCodeDiv : companyCodes){			
			if (!isNull(new CisDivision_Id(companyCodeDiv)) && isNull(new CisDivision_Id(companyCodeDiv).getEntity())){
				addError(CustomMessageRepositorySpireOne.S1_invalidCisDivision(companyCodeDiv));
			}
		}			
	}
	
	private String encloseCompanyCodesInQuotes(String cisDivision){
        StringBuilder cisDivisionStringBuilder = new StringBuilder();
        String[] cisDivisions = cisDivision.split(",");
        
        cisDivisionStringBuilder.append("'");

        for (int i = 0; i < cisDivisions.length; i++){
        	cisDivisionStringBuilder.append(cisDivisions[i] + "'");
            if (i < cisDivisions.length - 1) {
            	cisDivisionStringBuilder.append(",'");
            }
        }
        return cisDivisionStringBuilder.toString();
    }
	//End Add - JLumbre - 2021-02-08 - B-18110

	public JobWork getJobWork() {
		ccRouteType = getParameters().getAUTO_PAY_ROUTE_TYPE();
		companyCodeStr = getParameters().getCIS_DIVISION();
		//Start Add - JLumbre - 2021-02-08 - B-18110
		if(!isBlankOrNull(companyCodeStr)){
			companyCodes = encloseCompanyCodesInQuotes(companyCodeStr);
		}
		//End Add - JLumbre - 2021-02-08 - B-18110
		log.info(">>>>> ccRouteType" + ccRouteType);
		log.info(">>>>> companyCodeStr" + companyCodeStr);		
		
		StringBuilder getApayStr = new StringBuilder();
		getApayStr.append("SELECT ");
		getApayStr.append("BILL.BILL_ID, ");
		getApayStr.append("AC.ACCT_ID, ");
		getApayStr.append("BILL.APAY_AMT, ");
		getApayStr.append("BILL.APAY_CRE_DT, ");
		getApayStr.append("AP.APAY_SRC_CD, ");
		getApayStr.append("AP.EXT_ACCT_ID, ");
		getApayStr.append("AP.EXPIRE_DT, ");
		getApayStr.append("AP.ACCT_APAY_ID ");
		getApayStr.append("FROM CI_BILL BILL, ");
		getApayStr.append("CI_ACCT_APAY AP, ");
		getApayStr.append("CI_ACCT AC, ");
		getApayStr.append("CI_APAY_RT_TYPE RT, ");
		getApayStr.append("CI_APAY_SRC SR ");
		getApayStr.append("WHERE ");
		getApayStr.append("BILL.ACCT_ID=AC.ACCT_ID ");
		getApayStr.append("AND AC.ACCT_ID=AP.ACCT_ID ");
		getApayStr.append("AND BILL.BILl_STAT_FLG= :complete ");
		getApayStr.append("AND (BILL.APAY_CRE_DT IS NOT NULL AND BILL.APAY_CRE_DT <= :processDate) ");
		getApayStr.append("AND AP.START_DT <=BILL.DUE_DT ");
		//Start Change - JLumbre - 2020-06-04 - QAComplete#4438817
		//getApayStr.append("AND (AP.END_DT IS NULL OR AP.END_DT > :processDate) ");
		getApayStr.append("AND (AP.END_DT IS NULL OR AP.END_DT >= :processDate) ");
		//End Change - JLumbre - 2020-06-04 - QAComplete#4438817
		getApayStr.append("AND AP.APAY_SRC_CD=SR.APAY_SRC_CD ");
		getApayStr.append("AND SR.APAY_RTE_TYPE_CD=RT.APAY_RTE_TYPE_CD ");
		getApayStr.append("AND RT.APAY_RTE_TYPE_CD = :cc ");
		//Start Add - JLumbre - 2021-02-08 - B-18110
		if (!isBlankOrNull(companyCodeStr)){
			getApayStr.append("AND AC.CIS_DIVISION IN (" + companyCodes + ")");
		}
		//End Add - JLumbre - 2021-02-08 - B-18110


		PreparedStatement getApayPs = createPreparedStatement(getApayStr.toString(), getClass().getName());
		getApayPs.bindLookup("complete", BillStatusLookup.constants.COMPLETE);
		getApayPs.bindDate("processDate", getProcessDateTime().getDate());
		getApayPs.bindEntity("cc", ccRouteType);
		//getApayPs.execute();
		getApayPs.setAutoclose(false);

		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();		

		//Start Change - 2020-10-08 - JLumbre - QAComplete#4498857
		//QueryIterator<SQLResultRow> iter = getApayPs.iterate();
		List<SQLResultRow> iter = getApayPs.list();
		
		for (SQLResultRow row : iter){
			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId(new Bill_Id(row.getString("BILL_ID")));
			workUnit.addSupplementalData("accountId", row.getId("ACCT_ID",  Account.class));
			workUnit.addSupplementalData("amount", row.getBigDecimal("APAY_AMT"));
			workUnit.addSupplementalData("apayDate", row.getDate("APAY_CRE_DT"));
			workUnit.addSupplementalData("cardType", row.getString("APAY_SRC_CD"));
			workUnit.addSupplementalData("cardNbr", row.getString("EXT_ACCT_ID"));
			workUnit.addSupplementalData("expireDate", row.getDate("EXPIRE_DT"));
			workUnit.addSupplementalData("acctApayId", row.getString("ACCT_APAY_ID"));
			workUnits.add(workUnit);
		}
			
		/*while (iter.hasNext()) {
			SQLResultRow row = iter.next();

			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId(new Bill_Id(row.getString("BILL_ID")));
			workUnit.addSupplementalData("accountId", row.getId("ACCT_ID",  Account.class));
			workUnit.addSupplementalData("amount", row.getBigDecimal("APAY_AMT"));
			workUnit.addSupplementalData("apayDate", row.getDate("APAY_CRE_DT"));
			workUnit.addSupplementalData("cardType", row.getString("APAY_SRC_CD"));
			workUnit.addSupplementalData("cardNbr", row.getString("EXT_ACCT_ID"));
			workUnit.addSupplementalData("expireDate", row.getDate("EXPIRE_DT"));
			//workUnit.addSupplementalData("tenderType", row.getString("TENDER_TYPE_CD"));
			workUnits.add(workUnit);              
		}
		log.info(">>>>> workUnits: " + workUnits.size());
		iter.close();  */
		//End Change - 2020-10-08 - JLumbre - QAComplete#4498857
		getApayPs.close();

		return createJobWorkForThreadWorkUnitList(workUnits);		
	}

	public Class<CmCreditCardAutoPayBatchWorker> getThreadWorkerClass() {
		return CmCreditCardAutoPayBatchWorker.class;
	}

	public static class CmCreditCardAutoPayBatchWorker extends
	CmCreditCardAutoPayBatchWorker_Gen {

		private ServiceScriptInstance serviceScriptInstance;
		private COTSInstanceNode scriptInput;
		private COTSInstanceNode scriptOutput;
		private int recordsRemovedFromApay = 0;
		private int recordsProcessed = 0;
		private int recordsToBeReprocessed = 0;

		//batch parms
		private CharacteristicType billProcessedCharType;
		private AutopayRouteType ccRouteType;
		private String reprocessCodes;
		private String payMethodToken;

		//constants
		private final String CM_SUBMITPAY = "CM-SubmitPay";
		private final String Y = "Y";
		private final String INPUT = "input";
		private final String OUTPUT = "output";
		private final String SUCCESS = "Success";
		private final String TRUE = "true";
		private final String CardProcessorResponseCode = "CardProcessorResponseCode";
		//private final String ZERO = "0";

		private static final String PROCESSED = "PROCESSED";
		private static final String REPROCESS = "REPROCESS";
		private static final String FAILURE = "FAILURE";

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
						throws ThreadAbortedException, RunAbortedException {

			billProcessedCharType = getParameters().getBILL_PROCESSED_CHAR_TYPE();
			ccRouteType = getParameters().getAUTO_PAY_ROUTE_TYPE();
			reprocessCodes = getParameters().getREPROCESS_FAILURE_CODES();
			payMethodToken = getParameters().getPAYMENT_METHOD_TOKEN();
		}

		@Override
		protected boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			log.info(">>>>> execute workunit");

			//parms
			billProcessedCharType = getParameters().getBILL_PROCESSED_CHAR_TYPE();
			ccRouteType = getParameters().getAUTO_PAY_ROUTE_TYPE();
			reprocessCodes = getParameters().getREPROCESS_FAILURE_CODES();
			payMethodToken = getParameters().getPAYMENT_METHOD_TOKEN();

			log.info(">>>> bill process: " + billProcessedCharType);
			log.info(">>>>> payment token: " + payMethodToken);
			log.info(">>>>> cc route: " + ccRouteType);
			log.info(">>>>> reprocess codes: " + reprocessCodes);


			Bill_Id billId = (Bill_Id) unit.getPrimaryId();
			Account_Id acctId = (Account_Id) unit.getSupplementallData("accountId");
			BigDecimal apayAmt = (BigDecimal) unit.getSupplementallData("amount");
			Date apayDt = (Date) unit.getSupplementallData("apayDate");
			String cardType = (String) unit.getSupplementallData("cardType");
			String cardNbr = (String) unit.getSupplementallData("cardNbr");
			Date expireDt = (Date) unit.getSupplementallData("expireDate");
			String acctApayStr = (String) unit.getSupplementallData("acctApayId");	
			

			log.info(">>>>> cardNbr: before" + cardNbr);
			
			Money apayAmount = new Money(apayAmt, getCurrency());
			log.info(">>>>> apayAmount: before" + apayAmount);
			
			//Start Add - JLumbre - 2021-08-05
			AccountAutopay acctApay = new AccountAutopay_Id(acctApayStr).getEntity();
			log.info(">>>>> getEncryptedExternalAccountId: before" + acctApay.getEncryptedExternalAccountId());
			if (!isBlankOrNull(acctApay.getEncryptedExternalAccountId())){
				BusinessServiceInstance decryptBS = BusinessServiceInstance.create("F1-Decrypt");
				decryptBS.set("encrValue", acctApay.getEncryptedExternalAccountId());
				decryptBS.set("tableName", "CI_ACCT_APAY");
				decryptBS.set("fieldName", "EXT_ACCT_ID");

				BusinessServiceInstance output = BusinessServiceDispatcher.execute(decryptBS);
				cardNbr = output.getString("plainText");
				log.info(">>>>>cardNbr :" + cardNbr);
			}
			
			if (isBlankOrNull(cardNbr)){
				cardNbr = (String) unit.getSupplementallData("cardNbr");
			}
			//End Add - JLumbre - 2021-08-05
			
			//Start Add - JLumbre - 2020-05-06
			if (isCheckForAccountBalance().isTrue()){
				Money currentBalance = getAccountCurrentBalance(acctId.getEntity(), getProcessDateTime().getDate());
				log.info(">>>>> currentBalance: " + currentBalance);
				if (currentBalance.isLessThanOrEqual(Money.ZERO)){
					//process bill - do not call payment service
					log.info(">>>>> currentBalance:isLessThanOrEqual0 " + currentBalance);
					updateBill(billId.getEntity(), null, Money.ZERO, PROCESSED);
					recordsProcessed++;
					return true;
				}

				if (apayAmount.isGreaterThan(currentBalance)){
					log.info(">>>>> apayAmount.isGreaterThan(currentBalance) " + currentBalance);
					apayAmount = currentBalance;
				}
			}
			log.info(">>>>> apayAmount: after" + apayAmount);
			//End Add - JLumbre - 2020-05-06

			//split reprocess codes		
			String errorCode;
			String[] errorCodesStr = reprocessCodes.split(",");
			List<String> errorCodesList = new ArrayList<>();
			for (String error : errorCodesStr){
				errorCodesList.add(error);
			}


			//Substring Expire Date
			DateFormat dF = new DateFormat("YYYY-MM-DD");						
			String expMonth = String.valueOf(expireDt.getMonth());
			String expYear = String.valueOf(expireDt.getYear());			
			//format payment date
			String payDt = dF.format(apayDt);
			try {
				apayDt = dF.parseDate(payDt);
			} catch (DateFormatParseException e) {
				e.getMessage();				
			}

			log.info(">>>> billId: " + billId);			
			log.info(">>>> acctId: " + acctId);
			log.info(">>>> apayAmt: " + apayAmt);
			log.info(">>>> apayAmount: " + apayAmount);
			log.info(">>>> apayAmountToString: " + apayAmount.getAmount().toString());
			log.info(">>>> apayDt: " + apayDt);
			log.info(">>>> cardType: " + cardType);
			log.info(">>>> cardNbr: " + cardNbr);
			log.info(">>>> expireDt: " + expireDt);

			//Call CM-SubmitPay
			serviceScriptInstance = ServiceScriptInstance.create(CM_SUBMITPAY);
			scriptInput = serviceScriptInstance.getGroup(INPUT);
			//inputs
			scriptInput.set("accountId", acctId.getTrimmedValue());
			//Start Change - JLumbre - 2020-05-06
			//scriptInput.set("Amount", apayAmt.toString());
			scriptInput.set("Amount", apayAmount.getAmount().toString());
			//End Change - JLumbre - 2020-05-06
			scriptInput.set("PaymentDate", apayDt);
			scriptInput.set("CardType", cardType.trim());
			scriptInput.set("CardAccountNumber", cardNbr.trim());
			scriptInput.set("CardExpirationMonth", expMonth.trim());
			scriptInput.set("CardExpirationYear", expYear.trim());
			scriptInput.set("PaymentMethodToken", payMethodToken);
			//scriptInput.set("billId", billId.getTrimmedValue());

			try{
				ServiceScriptDispatcher.invoke(serviceScriptInstance);	
				scriptOutput = serviceScriptInstance.getGroup(OUTPUT);
				if (scriptOutput.getString(SUCCESS).compareToIgnoreCase(TRUE) == 0){
					updateBill(billId.getEntity(), null, Money.ZERO, PROCESSED);
					recordsProcessed++;
				}
				else{
					log.info(">>>> success = false" );
					if (!isBlankOrNull(scriptOutput.getString(CardProcessorResponseCode))){						
						errorCode = scriptOutput.getString(CardProcessorResponseCode);
						log.info(">>>> errorCode: " + errorCode);
						if (errorCodesList.contains(errorCode.trim())){
							log.info(">>>> errorCode1: " + errorCode);
							//add 1 day to APAY_CRE_DT
							updateBill(billId.getEntity(), apayDt, apayAmount, REPROCESS);
							recordsToBeReprocessed++;
						}
						else{
							log.info(">>>> errorCode2: " + errorCode);
							//Stop auto pay on bill
							updateBill(billId.getEntity(), apayDt, apayAmount, FAILURE);
							recordsRemovedFromApay++;
						}
					}
					else{
						log.info(">>>> errorCode3: " );
						updateBill(billId.getEntity(), apayDt, apayAmount, REPROCESS);
						recordsToBeReprocessed++;							
						//return false;						
					}
				}

			}
			catch (ApplicationError e){			
				log.info(">>>> errorCode4: " );
				updateBill(billId.getEntity(), apayDt, apayAmount, REPROCESS);
				recordsToBeReprocessed++;
				logError(e.getServerMessage());				
				return false;				
			}

			return true;
		}


		public void finalizeThreadWork() throws ThreadAbortedException,
		RunAbortedException {

			log.info(">>>>> finalize");
			logInfo(CustomMessageRepositorySpireOne.S1_TotalRecordsProcessed(recordsProcessed));
			logInfo(CustomMessageRepositorySpireOne.S1_TotalRecordsToBeReprocessed(recordsToBeReprocessed));
			logInfo(CustomMessageRepositorySpireOne.S1_TotalRecordsRemovedFromApay(recordsRemovedFromApay));				
		}

		public Currency_Id getCurrency(){
			log.info(">>>>> getCurrency: ");
			Currency_Id currencyId = null;

			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT CURRENCY_CD ");
			stringBuilder.append("FROM CI_INSTALLATION ");
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "getCurrency");
			prepState.execute();
			prepState.setAutoclose(false);
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			currencyId = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
			log.info(">>>>> getCurrency: " + currencyId);
			prepState.close();

			if (isNull(currencyId)){
				currencyId = new Currency_Id("USD");
			}

			return currencyId;
		}

		//Start Add - JLumbre - 2020-05-06	
		public Bool isCheckForAccountBalance(){
			log.info(">>>>> check for acct bal" );
			String val;
			Bool isA = Bool.FALSE;

			StringBuilder valStr = new StringBuilder();
			valStr.append("SELECT ALG_PARM_VAL ");
			valStr.append("FROM CI_ALG_PARM ");
			valStr.append("WHERE ALG_CD IN (SELECT ALG_CD FROM CI_INSTALL_ALG ");
			valStr.append("WHERE INS_ALG_ENTITY_FLG='APAY') ");
			valStr.append("AND SEQNO = '40' ");

			PreparedStatement valPs = createPreparedStatement(valStr.toString(), getClass().getName());		
			valPs.setAutoclose(false);
			valPs.execute();

			SQLResultRow row = valPs.firstRow();
			val = row.getString("ALG_PARM_VAL");
			if (!isBlankOrNull(val)){
				if (val.trim().compareTo("A") == 0){
					isA = Bool.TRUE;
				}				
			}
			valPs.close();
			log.info(">>>>> isA: " + isA);
			return isA;
		}

		public Money getAccountCurrentBalance(Account account, Date processDate){
			AccountFinancialBalanceData acctFinancialBalance = account.getFinancialBalances(processDate, processDate);

			return acctFinancialBalance.getCurrentAmount();			
		}
		//End Add - JLumbre - 2020-05-06


		public void updateBill (Bill bill, Date apayDate, Money apayAmt, String action){
			log.info(">>>>> updateBill");
			Bill_DTO billDto = bill.getDTO();

			if (action.compareToIgnoreCase(PROCESSED) == 0){
				log.info(">>>>> updateBill " + PROCESSED);
				billDto.setAutopayAmount(apayAmt);
				billDto.setAutopayCreationDate(apayDate);				
			}

			if (action.compareToIgnoreCase(REPROCESS) == 0){
				log.info(">>>>> updateBill " + REPROCESS);
				//Start Change - JLumbre - 2020-08-06 - QAComplete#4465427
				//Date newApayDate = apayDate.addDays(1);
				WorkCalendar workCalendar = bill.getAccount().getDivisionId().getEntity().getWorkCalendar();				
				Date newApayDate = workCalendar.addBusinessDays(apayDate, 1);
				//End Change - JLumbre - 2020-08-06 - QAComplete#4465427
				billDto.setAutopayCreationDate(newApayDate);
			}

			if (action.compareToIgnoreCase(FAILURE) == 0){
				log.info(">>>>> updateBill " + FAILURE);
				billDto.setAutopayAmount(Money.ZERO);
				billDto.setAutopayCreationDate(null);
				//stop fields
				billDto.setAutopayStopAmount(apayAmt);
				billDto.setAutopayStopCreationDate(apayDate);
				billDto.setAutopayStopDateTime(getProcessDateTime());
				billDto.setAutopayStopUserId(getActiveContextUser().getId());			
			}			
			bill.setDTO(billDto);

			if (action.compareToIgnoreCase(PROCESSED) == 0){
				log.info(">>>>> addBillCharacteristic " + PROCESSED);
				//Add Characteristic 
				addBillCharacteristic(bill,billProcessedCharType, Y);
			}
		}

		public void addBillCharacteristic(Bill bill, CharacteristicType charType, String charVal){

			if (hasBillCharacteristic(bill, charType).isFalse()){
				BillCharacteristics billChars = bill.getCharacteristics();
				BillCharacteristic_DTO bcDto = billChars.newChildDTO();
				if (charType.getCharacteristicType().isAdhocValue()){
					bcDto.setAdhocCharacteristicValue(charVal);
				}else if (charType.getCharacteristicType().isPredefinedValue()){
					bcDto.setCharacteristicValue(charVal);
				}else if (charType.getCharacteristicType().isForeignKeyValue()){
					bcDto.setCharacteristicValueForeignKey1(charVal);
				}
				billChars.add(bcDto, charType.getId(), BigInteger.ONE);	
			}
		}

		public Bool hasBillCharacteristic(Bill bill, CharacteristicType charType){
			log.info(">>>>> hasBillCharacteristic" );
			ListFilter<BillCharacteristic> bc = bill.getCharacteristics().createFilter("WHERE this.id.characteristicType = :charType order by this.id.sequence desc", getClass().getName());
			bc.bindEntity("charType", charType);						
			log.info(">>>>>bc.list().size(): " + bc.list().size() );
			if (bc.list().size() > 0){				
				return Bool.TRUE;
			}			
			return Bool.FALSE;
		}
	}
}
