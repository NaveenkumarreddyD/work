/**************************************************************************
 * Program Name: CmPostWriteOffDebtTransfersBatch
 * Program Title: CmPostWriteOffDebtTransfersBatch
 * Author: Marianne Pango
 * Creation Date: 2017-07-10
 * Purpose: This batch process selects Change Log records created by the 
 * custom Algorithms of this design and matches them to the CM Table, 
 * CM_WO_XFERS. It then analyzes the Person IDs on CM_WO_XFERS to see if 
 * another Active SA exists to transfer the Write Off Debt to. 
 * CM_WO_XFERS only stores Person IDs that are financially responsible 
 * and this batch process will only transfer to an SA if the Person ID is
 * the Main Customer on the Account. 
 *  
 * Functional Spec: SA-68623
 **************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  SA-68623     	  Marianne Pango   2017-07-10    Initial Version.
 ************************************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_Id;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_LanguageId;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass_Id;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author MPang
 *
@BatchJob (multiThreaded = true, rerunnable = true, modules = {},
 *		softParameters = { @BatchJobSoftParameter (entityName = serviceType, name = GAS_SVC_TYPE, required = true, type = entity)
 *			  , @BatchJobSoftParameter (entityName = characteristicType, name = EXCL_SATY_CHAR, required = true, type = entity)
 *			  , @BatchJobSoftParameter (entityName = characteristicType, name = STOP_XFER_PER_SA_CHAR, required = true, type = entity)
 *			  , @BatchJobSoftParameter (name = RES_CUST_CLASS, required = true, type = string)
 *			  , @BatchJobSoftParameter (name = COM_IND_CUST_CLASS, required = true, type = string)
 *			  , @BatchJobSoftParameter (entityName = adjustmentType, name = WO_XFER_ADJ_TYPE, required = true, type = entity)})
 */
public class CmPostWriteOffDebtTransfersBatch extends
		CmPostWriteOffDebtTransfersBatch_Gen {

	//// Soft Parameters
	private CharacteristicType excludeFromTransferringSatypeChar;
	private CharacteristicType personSaCharToPreventTransfersCharacteristicType;
	private String[] resCustClasses;
	private String[] commIndCustClasses;

	public JobWork getJobWork() {

		StringBuilder getPkValChangeLog = new StringBuilder();
		getPkValChangeLog.append("SELECT CH.PK_VAL1 ");
		getPkValChangeLog.append(	"FROM CI_CHG_LOG CH ");
		getPkValChangeLog.append("WHERE ");
		getPkValChangeLog.append(	"CH.BATCH_CD = :batchCode"); 

		PreparedStatement getChangeLogs = createPreparedStatement(getPkValChangeLog.toString(), getClass().getName());
		getChangeLogs.bindEntity("batchCode", getBatchControlId().getEntity());

		// Build the Worklist
		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();

		QueryIterator<SQLResultRow> iter = getChangeLogs.iterate();

		while (iter.hasNext()) {
			SQLResultRow row = iter.next();

			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			String pkVal = (String) row.get("PK_VAL1");
			ServiceAgreement_Id saId = new ServiceAgreement_Id(pkVal);

			workUnit.setPrimaryId(saId);
			workUnits.add(workUnit);              
		}
		iter.close();  
		return createJobWorkForThreadWorkUnitList(workUnits);  

	}

	@Override
	public void validateSoftParameters(boolean isNewRun) {
		
		excludeFromTransferringSatypeChar = getParameters().getEXCL_SATY_CHAR();
		personSaCharToPreventTransfersCharacteristicType = getParameters().getSTOP_XFER_PER_SA_CHAR();

		// Validate Exclude from Transferring SA Type Characteristic parameter (Parameter 20).
		CharacteristicEntity_Id excludeXferSaTypeCharEntity = new CharacteristicEntity_Id(excludeFromTransferringSatypeChar, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT_TYPE);
		if (isNull(excludeXferSaTypeCharEntity.getEntity())) {
			addError(CustomMessageRepository.SA_68623_3_InvalidEntity(getBatchParameterName(20), excludeFromTransferringSatypeChar.getId().getTrimmedValue(), "SA TYPE"));
		}
		// Validate Person / SA Characteristic to Prevent Transfers parameter (Parameter 30).
		CharacteristicEntity_Id perCharToPreventXferCharEntity = new CharacteristicEntity_Id(personSaCharToPreventTransfersCharacteristicType, CharacteristicEntityLookup.constants.PERSON);
		if (isNull(perCharToPreventXferCharEntity.getEntity())) {
			addError(CustomMessageRepository.SA_68623_3_InvalidEntity(getBatchParameterName(30), personSaCharToPreventTransfersCharacteristicType.getId().getTrimmedValue(), "Person"));
		}

		// Validate Person / SA Characteristic to Prevent Transfers parameter (Parameter 30).
		CharacteristicEntity_Id saCharToPreventXferCharEntity = new CharacteristicEntity_Id(personSaCharToPreventTransfersCharacteristicType, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT);
		if (isNull(saCharToPreventXferCharEntity.getEntity())) {
			addError(CustomMessageRepository.SA_68623_3_InvalidEntity(getBatchParameterName(30), personSaCharToPreventTransfersCharacteristicType.getId().getTrimmedValue(), "Service Agreement"));
		}

		// Validate Residential Customer Classes parameter (Parameter 40).
		resCustClasses = getParameters().getRES_CUST_CLASS().split(",");
		if (resCustClasses.length < 1) {
			addError(CustomMessageRepository.SA_68623_3_ParameterIsRequired(getBatchParameterName(40)));
		}

		CustomerClass_Id resCustomerClassId = null;
		for (String resCustClassStr : resCustClasses) {
			resCustomerClassId = new CustomerClass_Id(resCustClassStr.trim());

			if (isNull(resCustomerClassId.getEntity())) {
				addError(CustomMessageRepository.SA_68623_3_InvalidCustomerClass(getBatchParameterName(40),resCustomerClassId.getTrimmedValue()));
			}
		}

		// Validate Commercial / Industrial Customer Classes parameter (Parameter 50).
		commIndCustClasses = getParameters().getCOM_IND_CUST_CLASS().split(",");

		if (commIndCustClasses.length < 1) {
			addError(CustomMessageRepository.SA_68623_3_ParameterIsRequired(getBatchParameterName(50)));
		}

		CustomerClass_Id commIndCustomerClassId = null;
		for (String commIndCustClassStr : commIndCustClasses) {
			commIndCustomerClassId = new CustomerClass_Id(commIndCustClassStr.trim());
			if (isNull(commIndCustomerClassId.getEntity())) {
				addError(CustomMessageRepository.SA_68623_3_InvalidCustomerClass(getBatchParameterName(50),commIndCustomerClassId.getTrimmedValue()));

			}
		}
	}

	/**
	 * Get Batch Parameter Description
	 * @param numSeq
	 * @return
	 */
	private String getBatchParameterName(int numSeq){

		String parmName = "";

		BatchControlParameter_Id batchControlParameter_Id = 
				new BatchControlParameter_Id(this.getBatchControlId(), BigInteger.valueOf(numSeq));        
		BatchControlParameter_LanguageId batchControlParameterLanguageId = 
				new BatchControlParameter_LanguageId(batchControlParameter_Id, getActiveContextLanguage().getId());
		parmName = batchControlParameterLanguageId.getParent().fetchLanguageDescription();

		return parmName;
	}


	public Class<CmPostWriteOffDebtTransfersBatchWorker> getThreadWorkerClass() {
		return CmPostWriteOffDebtTransfersBatchWorker.class;
	}

	public static class CmPostWriteOffDebtTransfersBatchWorker extends
	CmPostWriteOffDebtTransfersBatchWorker_Gen {

		// Soft Parameters
		private ServiceType gasServiceType;
		private CharacteristicType excludeFromTransferringSatypeChar;
		private CharacteristicType personSaCharToPreventTransfersCharacteristicType;
		private String[] resCustClasses;
		private String[] commIndCustClasses;
		private AdjustmentType woXferAdjType;

		// Work Variable
		private List<CustomerClass> residentialCustomerClassLists;
		private List<CustomerClass> commIndCustomerClassLists; 
		private ServiceAgreement transferSa = null;

		private Account_Id accountId = null;
		private Person_Id mainPersonId = null;
		private Person_Id frPerson1Id = null;
		private Person_Id frPerson2Id = null;
		private Person_Id frPerson3Id = null;
		private Person_Id frPerson4Id = null;
		private Person_Id frPerson5Id = null;
		private Bool personCharExists = Bool.FALSE;

		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
			gasServiceType = getParameters().getGAS_SVC_TYPE();
			excludeFromTransferringSatypeChar = getParameters().getEXCL_SATY_CHAR();
			personSaCharToPreventTransfersCharacteristicType = getParameters().getSTOP_XFER_PER_SA_CHAR();

			residentialCustomerClassLists = new ArrayList<CustomerClass>();
			resCustClasses = getParameters().getRES_CUST_CLASS().split(",");

			CustomerClass_Id resCustomerClassId = null;
			for (String resCustClassStr : resCustClasses) {
				resCustomerClassId = new CustomerClass_Id(resCustClassStr.trim());
				residentialCustomerClassLists.add(resCustomerClassId.getEntity());
			}

			commIndCustomerClassLists = new ArrayList<CustomerClass>();
			commIndCustClasses = getParameters().getCOM_IND_CUST_CLASS().split(",");

			CustomerClass_Id commIndCustomerClassId = null;
			for (String commIndCustClassStr : commIndCustClasses) {
				commIndCustomerClassId = new CustomerClass_Id(commIndCustClassStr.trim());
				commIndCustomerClassLists.add(commIndCustomerClassId.getEntity());
			}

			woXferAdjType = getParameters().getWO_XFER_ADJ_TYPE();

		}

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			// Get the SA from the Change Log.
			ServiceAgreement_Id saId = (ServiceAgreement_Id) unit.getPrimaryId();
			// Retrieve the matching record from the CM_WO_XFERS table
			StringBuilder checkRecordSameWithSa = new StringBuilder();

			checkRecordSameWithSa.append("SELECT  ");
			checkRecordSameWithSa.append(	"WOXFER.WO_ACCT_ID, ");
			checkRecordSameWithSa.append(	"WOXFER.MAIN_PER_ID, ");
			checkRecordSameWithSa.append(	"WOXFER.FR_PER_ID1, ");
			checkRecordSameWithSa.append(	"WOXFER.FR_PER_ID2, ");
			checkRecordSameWithSa.append(	"WOXFER.FR_PER_ID3, ");
			checkRecordSameWithSa.append(	"WOXFER.FR_PER_ID4, ");
			checkRecordSameWithSa.append(	"WOXFER.FR_PER_ID5 ");
			checkRecordSameWithSa.append("FROM ");
			checkRecordSameWithSa.append(  "CM_WO_XFERS WOXFER ");
			checkRecordSameWithSa.append("WHERE ");
			checkRecordSameWithSa.append(  "WOXFER.WO_SA_ID = :saId ");

			PreparedStatement chechRecordSameWithSaExist = createPreparedStatement(checkRecordSameWithSa.toString(), getClass().getName());
			chechRecordSameWithSaExist.bindId("saId", saId);

			SQLResultRow row = chechRecordSameWithSaExist.firstRow();
			chechRecordSameWithSaExist.close();


			if(notNull(row)) {
				accountId = (Account_Id) new Account_Id(row.getString("WO_ACCT_ID"));
				mainPersonId = (Person_Id) new Person_Id(row.getString("MAIN_PER_ID"));
				frPerson1Id = (Person_Id) new Person_Id(row.getString("FR_PER_ID1"));
				frPerson2Id = (Person_Id) new Person_Id(row.getString("FR_PER_ID2"));
				frPerson3Id = (Person_Id) new Person_Id(row.getString("FR_PER_ID3"));
				frPerson4Id = (Person_Id) new Person_Id(row.getString("FR_PER_ID4"));
				frPerson5Id = (Person_Id) new Person_Id(row.getString("FR_PER_ID5"));

				personCharExists = checkPersonCharacteristic (mainPersonId);
				
				// If Person Characteristic does not exists.
				if(personCharExists.isFalse()) {
					// Retrieve Active Gas SA
					transferSa = retrieveActiveSas(mainPersonId, saId);
				}
				// Check if FR Person 1 is not null and transfer SA is Null
				if(!isNull(frPerson1Id.getEntity()) && isNull(transferSa)) {
					personCharExists = checkPersonCharacteristic (frPerson1Id);
					if(personCharExists.isFalse()) {
						// Retrieve Active Gas SA
						transferSa = retrieveActiveSas(frPerson1Id, saId);
					}
				}

				// Check if FR Person 2 is not null and transfer SA is Null
				if(!isNull(frPerson2Id.getEntity()) && isNull(transferSa)) {
					personCharExists = checkPersonCharacteristic (frPerson2Id);
					if(personCharExists.isFalse()) {
						// Retrieve Active Gas SA
						transferSa = retrieveActiveSas(frPerson2Id, saId);
					}
				}

				// Check if FR Person 3 is not null and transfer SA is Null
				if(!isNull(frPerson3Id.getEntity()) && isNull(transferSa)) {
					personCharExists = checkPersonCharacteristic (frPerson3Id);
					if(personCharExists.isFalse()) {
						// Retrieve Active Gas SA
						transferSa = retrieveActiveSas(frPerson3Id, saId);
					}
				}

				// Check if FR Person 4 is not null and transfer SA is Null
				if(!isNull(frPerson4Id.getEntity()) && isNull(transferSa)) {
					personCharExists = checkPersonCharacteristic (frPerson4Id);
					if(personCharExists.isFalse()) {
						// Retrieve Active Gas SA
						transferSa = retrieveActiveSas(frPerson4Id, saId);
					}
				}

				// Check if FR Person 5 is not null
				if(!isNull(frPerson5Id.getEntity()) && isNull(transferSa)) {
					personCharExists = checkPersonCharacteristic (frPerson5Id);
					if(personCharExists.isFalse()) {
						// Retrieve Active Gas SA
						transferSa = retrieveActiveSas(frPerson5Id, saId);
					}
				}

				if (isNull(transferSa)) {
					// Delete CI_CHG_LOG record for SA.
					deleteChangeLog(saId);
					// End Processing.
					return true;
				} else {
					CustomerClass newGasSacustomerClass;
					CustomerClass writeOffSaCustomerClass;

					writeOffSaCustomerClass = saId.getEntity().getAccount().getCustomerClass();
					newGasSacustomerClass = transferSa.getAccount().getCustomerClass();

					// Check if Write Off SA's Account Customer Class is Residential (Parameter 40) or Commercial (Parameter 50)
					if(residentialCustomerClassLists.contains(writeOffSaCustomerClass) 
							|| commIndCustomerClassLists.contains(writeOffSaCustomerClass)) {
						// Check if Write Off SA and new gas SA have matching Customer Class
						if((residentialCustomerClassLists.contains(writeOffSaCustomerClass) && residentialCustomerClassLists.contains(newGasSacustomerClass))
								|| (commIndCustomerClassLists.contains(writeOffSaCustomerClass) && commIndCustomerClassLists.contains(newGasSacustomerClass))){
							// Create Adjustment
							createAdjustment(woXferAdjType, saId.getEntity(), transferSa);
							// Check in CM_WO_XFERS table, SA Id is existing using account id.
							for(ServiceAgreement_Id otherSaInAccountId : checkOtherSaExistingUsingAccountId(accountId, saId)) {
								// Check the retrieved otherSaInAccountId in Change Log
								SQLResultRow otherSaInChangeLogRow = checkOtherSaInChangeLog(otherSaInAccountId);
								// If not found prepare to transfer
								if(isNull(otherSaInChangeLogRow)) {
									// Create Adjustment for the other SAs retrieved using the account id.
									createAdjustment(woXferAdjType, otherSaInAccountId.getEntity(), transferSa);
								} 
							}

							deleteChangeLog(saId);

							// Write Off SA and new gas SA does not have matching Customer Class
						} else {
							//  Delete CHANGE LOG
							deleteChangeLog(saId);
							// End Processing.
							return true;
						}

						// Write Off SA's Customer Class does not contain in Parameter 40 and Parameter 50.
					} else {
						// Delete CM_WO_XFER and CI_CHG_LOG for SA
						deleteChangeLog(saId);
						deleteWriteOffTable(saId);
						// End Processing.
						return true;
					}
				}
			
			} else {
				// Log Warning
				logWarning(CustomMessageRepository.SA_68623_3_CouldNotIdentify(saId.getIdValue().trim()));
				// Delete CI_CHG_LOG for SA
				deleteChangeLog(saId);
			}
			
			return true;
		}

		/**
		 * Check if Main Person has a Person Characteristic
		 * @param personId
		 * @return bool
		 */
		private Bool checkPersonCharacteristic (Person_Id personId) {

			StringBuilder personCharacteristicExists = new StringBuilder();

			personCharacteristicExists.append("SELECT ");
			personCharacteristicExists.append(  "'X' ");
			personCharacteristicExists.append("FROM ");
			personCharacteristicExists.append(  "CI_PER_CHAR PERCHAR ");
			personCharacteristicExists.append("WHERE ");
			personCharacteristicExists.append(  "PERCHAR.CHAR_TYPE_CD = :stopXferPerSaChar ");
			personCharacteristicExists.append(  "AND PERCHAR.PER_ID = :personId ");
			personCharacteristicExists.append(  "AND PERCHAR.EFFDT <= :processDate");
			
			PreparedStatement isPersonCharacteristicExistsPs = createPreparedStatement(personCharacteristicExists.toString(), getClass().getName());
			isPersonCharacteristicExistsPs.bindEntity("stopXferPerSaChar", personSaCharToPreventTransfersCharacteristicType);
			isPersonCharacteristicExistsPs.bindId("personId", personId);
			isPersonCharacteristicExistsPs.bindDate("processDate", getProcessDateTime().getDate());

			SQLResultRow row = isPersonCharacteristicExistsPs.firstRow();
			isPersonCharacteristicExistsPs.close();

			if(notNull(row)) {
				return Bool.TRUE;
			} else {
				return Bool.FALSE;
			}

		}

		/**
		 * Delete Change Log (CI_CHG_LOG) for SA
		 * @param saId
		 */
		private void deleteChangeLog(ServiceAgreement_Id saId) {
			StringBuilder changeLogDelete = new StringBuilder();

			changeLogDelete.append("DELETE ");
			changeLogDelete.append("FROM ");
			changeLogDelete.append(  "CI_CHG_LOG CH ");
			changeLogDelete.append("WHERE ");
			changeLogDelete.append(	"CH.BATCH_CD = :batchCode "); 
			changeLogDelete.append(	"AND CH.PK_VAL1 = :saId "); 

			PreparedStatement changeDeletePs = createPreparedStatement(changeLogDelete.toString(), getClass().getName());
			changeDeletePs.bindEntity("batchCode", getBatchControlId().getEntity());
			changeDeletePs.bindId("saId", saId);

			changeDeletePs.execute();
			changeDeletePs.close();

		}

		/**
		 * Delete Custom Table Write Off Transfers (CM_WO_XFERS)for SA 
		 * @param saId
		 */
		private void deleteWriteOffTable(ServiceAgreement_Id saId) {
			StringBuilder changeLogDelete = new StringBuilder();

			changeLogDelete.append("DELETE ");
			changeLogDelete.append("FROM ");
			changeLogDelete.append(  "CM_WO_XFERS WOXFER ");
			changeLogDelete.append("WHERE ");
			changeLogDelete.append(	"WOXFER.WO_SA_ID = :saId "); 

			PreparedStatement changeDeletePs = createPreparedStatement(changeLogDelete.toString(), getClass().getName());
			changeDeletePs.bindId("saId", saId);

			changeDeletePs.execute();
			changeDeletePs.close(); 

		}

		/**
		 * Search CM_WO_XFERS table for other existing records with the same Account ID 
		 * @param accountId, woSaId
		 * @return saList
		 */
		private List<ServiceAgreement_Id> checkOtherSaExistingUsingAccountId (Account_Id accountId, ServiceAgreement_Id woSaId) {
			List<ServiceAgreement_Id> saList = null;
			StringBuilder otherSaUsingAccountId = new StringBuilder();

			otherSaUsingAccountId.append("SELECT ");
			otherSaUsingAccountId.append(  "WOXFER.WO_SA_ID ");
			otherSaUsingAccountId.append("FROM ");
			otherSaUsingAccountId.append(  "CM_WO_XFERS WOXFER ");
			otherSaUsingAccountId.append("WHERE ");
			otherSaUsingAccountId.append(  "WOXFER.WO_ACCT_ID = :acctId ");
			otherSaUsingAccountId.append(  "AND WOXFER.WO_SA_ID <> :woSaId");

			PreparedStatement otherSaUsingAcctIdPs = createPreparedStatement(otherSaUsingAccountId.toString(), getClass().getName());
			otherSaUsingAcctIdPs.bindId("acctId", accountId);
			otherSaUsingAcctIdPs.bindId("woSaId", woSaId);


			saList = new ArrayList<ServiceAgreement_Id>();
			for(SQLResultRow row : otherSaUsingAcctIdPs.list()) {
				ServiceAgreement_Id serviceAgreementId = (ServiceAgreement_Id) row.getId("WO_SA_ID", ServiceAgreement.class);
				if(notNull(serviceAgreementId.getEntity())) {
					saList.add(serviceAgreementId);
				}

			}

			otherSaUsingAcctIdPs.close();
			return saList;

		}

		/**
		 * Check Other SA in Change Log (CI_CHG_LOG)
		 * @param saId
		 */
		private SQLResultRow checkOtherSaInChangeLog(ServiceAgreement_Id saId) {
			StringBuilder changeLogDelete = new StringBuilder();

			changeLogDelete.append("SELECT ");
			changeLogDelete.append(	"'X' ");
			changeLogDelete.append("FROM ");
			changeLogDelete.append(  "CI_CHG_LOG CH ");
			changeLogDelete.append("WHERE ");
			changeLogDelete.append(	"CH.BATCH_CD = :batchCode "); 
			changeLogDelete.append(	"AND CH.PK_VAL1 = :saId "); 

			PreparedStatement changeDeletePs = createPreparedStatement(changeLogDelete.toString(), getClass().getName());
			changeDeletePs.bindEntity("batchCode", getBatchControlId().getEntity());
			changeDeletePs.bindId("saId", saId);

			SQLResultRow row = changeDeletePs.firstRow();
			changeDeletePs.close();

			return row;

		}
		/**
		 * Create Adjustment for SA using validated Adjustment Type
		 * @param adjustmentType
		 * @param sa
		 */
		private void createAdjustment(AdjustmentType adjustmentType, ServiceAgreement sourceSa, ServiceAgreement xferSa) {
			CreateFrozenAdjustment createFrozenAdjustment = CreateFrozenAdjustment.Factory.newInstance();
			CreateFrozenAdjustmentData createFrozenAdjustmentData = CreateFrozenAdjustmentData.Factory.newInstance();
			createFrozenAdjustmentData.setServiceAgreement(sourceSa);
			createFrozenAdjustmentData.setTransferServiceAgreement(xferSa);
			createFrozenAdjustmentData.setAdjustmentType(adjustmentType);
			createFrozenAdjustmentData.setAdjustmentDate(getProcessDateTime().getDate());
			createFrozenAdjustmentData.setAdjustmentAmount(sourceSa.getCurrentBalance());
			createFrozenAdjustmentData.setAllowZeroAmount(Bool.FALSE);
			createFrozenAdjustment.createFrozenAdjustment(createFrozenAdjustmentData);
		}

		/**
		 * Retrieve Active Sas
		 * @param personId
		 * @param saId
		 * @return list saId
		 */
		private ServiceAgreement retrieveActiveSas(Person_Id personId, ServiceAgreement_Id saId) {
			ServiceAgreement serviceAgreement = null;
			StringBuilder saActiveStr = new StringBuilder();

			saActiveStr.append("SELECT ");
			saActiveStr.append(  "SA.SA_ID ");
			saActiveStr.append("FROM ");
			saActiveStr.append(  "CI_ACCT_PER ACCTPER, ");
			saActiveStr.append(  "CI_SA SA, ");
			saActiveStr.append(  "CI_SA_TYPE SATY ");
			saActiveStr.append("WHERE ");
			saActiveStr.append(  "ACCTPER.MAIN_CUST_SW = :y ");
			saActiveStr.append(  "AND ACCTPER.PER_ID = :personId ");
			saActiveStr.append(  "AND SA.ACCT_ID = ACCTPER.ACCT_ID ");
			saActiveStr.append(  "AND SA.SA_STATUS_FLG = :active ");
			saActiveStr.append(  "AND SA.CIS_DIVISION = :woSaCisDivision ");
			saActiveStr.append(  "AND NOT EXISTS (SELECT 'X' ");
			saActiveStr.append(  				   "FROM ");
			saActiveStr.append(  				   		"CI_SA_CHAR SACHAR ");
			saActiveStr.append(  					"WHERE ");
			saActiveStr.append(  						"SACHAR.CHAR_TYPE_CD = :stopXferPerSaChar ");
			saActiveStr.append(  						"AND SACHAR.SA_ID = SA.SA_ID ");
			saActiveStr.append(  						"AND SACHAR.EFFDT <= :processDate) ");
			saActiveStr.append(  "AND SATY.SA_TYPE_CD = SA.SA_TYPE_CD ");
			saActiveStr.append(  "AND SATY.SVC_TYPE_CD = :gasServiceType ");
			saActiveStr.append(  "AND SATY.CIS_DIVISION = SA.CIS_DIVISION ");
			saActiveStr.append(  "AND NOT EXISTS (SELECT 'X' ");
			saActiveStr.append(  				   "FROM ");
			saActiveStr.append(  				   		"CI_SA_TYPE_CHAR SATYCHAR ");
			saActiveStr.append(  					"WHERE ");
			saActiveStr.append(  						"SATYCHAR.CHAR_TYPE_CD = :excludeSatyChar ");
			saActiveStr.append(  						"AND SATYCHAR.CIS_DIVISION = SATY.CIS_DIVISION ");
			saActiveStr.append(  						"AND SATYCHAR.SA_TYPE_CD = SATY.SA_TYPE_CD) ");


			PreparedStatement activeSasPs = createPreparedStatement(saActiveStr.toString(), getClass().getName());
			activeSasPs.bindBoolean("y", Bool.TRUE);
			activeSasPs.bindId("personId", personId);
			activeSasPs.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
			activeSasPs.bindEntity("woSaCisDivision", saId.getEntity().getServiceAgreementType().fetchIdDivision());
			activeSasPs.bindEntity("stopXferPerSaChar", personSaCharToPreventTransfersCharacteristicType);
			activeSasPs.bindDate("processDate", getProcessDateTime().getDate());
			activeSasPs.bindEntity("gasServiceType", gasServiceType);
			activeSasPs.bindEntity("excludeSatyChar", excludeFromTransferringSatypeChar);

			SQLResultRow row = activeSasPs.firstRow();
			if(isNull(row)) {
				serviceAgreement = null;
			} else {
				ServiceAgreement_Id serviceAgreementId = (ServiceAgreement_Id) row.getId("SA_ID", ServiceAgreement.class);
				serviceAgreement = serviceAgreementId.getEntity();
			}
			activeSasPs.close();

			return serviceAgreement;

		}

	}
}
