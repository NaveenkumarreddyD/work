/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This custom Batch Process will create Compliance Case for
 * ACI Corrosion Inspect and Repair.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-04-03   Raviteja        NM0101 Initial Version.
 * 2013-08-14   Seshu Gogineni	IM-33957
 * 2013-09-25   Neha	        Tuned main query
 * 2013-11-29   Neha            IM-041589 Static variables removed
 * 2014-05-06   Neha            IM-050188 Case pointing to old customer
 * 2015-02-05   Ujesh           #6943 - Case closing & reopening everyday
 * 2015-02-09   Ujesh           #7213 - ACI Repair Cases not closing after a code A
 * 2015-04-08	Alex			#19455 - Do not check the ACI result characteristic for Inspection cases
 * 2015-11-24	JHERNA			SysAid#31775 - Performance issue. Re-structure the batch to use the
 *                              newer thread execution strategy to improve performance
 * 2015-12-17	JHERNA			SysAid#74725 - Null pointer exception issue.
 * 2016-02-18   MPang		    Updated for CCB v2.4 compilation.
 * 2016-03-16   JHERNA          SysAid#89759 - ACI Result check only for ACI Repair Cases.
 * 2017-08-17   JTiozon         FS_NA188394/SA-188394.3. Exclude disconnect location codes.
 * 2017-09-22   LBallo          Defect 3868063. Removed static variable aciFeatureConfig
 * 								and add a new another aciFeatureConfig variable
 * 								in the inner class.
 * 2019-03-20	JHERNA			SysAid#286046. Update code to retrieve the correct
 * 								and latest customer information linked to the service point.
 * 2021-01-29	P.Nikiforovitch	SysAid#358138. Update code to make sure the location is IN
 * 								rather than not OUT (there are other options besides those two).
 * 2024-02-12   EQuint			B-36287 Add condition to exclude CIS Divisions
 **************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadIterationStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.StringId;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicTypeValues;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.phoneType.PhoneType;
import com.splwg.base.domain.common.phoneType.PhoneType_Id;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ContactMethodLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.caseType.entity.CharacteristicTypeCaseType;
import com.splwg.ccb.domain.admin.caseType.entity.CharacteristicTypeCaseType_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.disconnectLocation.entity.DisconnectLocation_Id;
import com.splwg.ccb.domain.admin.meterLocation.entity.MeterLocation;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.todo.common.CaseCreator;
import com.splwg.ccb.domain.todo.data.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_Id;
import com.splwg.cm.api.lookup.CmAciExcludedDisconnectLocationLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.common.customBusinessComponent.CmSaSpMeterRelationshipsRoutine_Impl;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
/**
 * @author rgullapall003
 *
 @BatchJob (
 *      modules = {},
 *      multiThreaded = true,
 *      rerunnable = false,
 *      softParameters = {@BatchJobSoftParameter (entityName = caseType, name = CASE_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = X_DAYS_BEFORE_DUE_DATE, required = true, type = integer)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = ACI_DUE_DT_CHAR_TY, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = METER_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (lookupName = serviceAgreementStatus, name = SA_STATUS, required = true, type = lookup)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = ELIG_PORTAL_CASE_CHAR_TY, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = ELIG_PORTAL_CASE_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MTR_LOCATION, required = true, type = entity, entityName = meterLocation)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = SP_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = ACI_RESULT_CHAR_TY, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = ACI_RESULT_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = ACI_CASE_MG_EXC_DISLOC_FC_NAME, type = entity)
 *            , @BatchJobSoftParameter (name = EXCLUDE_CIS_DIV, type = string)})
 *
 */
public class CmACIInspectRepairCase_BatchProcess extends
CmACIInspectRepairCase_BatchProcess_Gen {

    // Start change Neha IM-041589 2013-11-29
    /*private static ServiceAgreementStatusLookup paramSaStatus;
    private static CaseType paramCaseType;
    private static CharacteristicType paramACIDueDtCharType;
    private static CharacteristicType paramMeterIdCharType;
    private static CharacteristicType paramEligPortalCaseCharType;
    private static CharacteristicType paramSpIdCharType;
    private static MeterLocation paramMeterLocation;
    private BigInteger paramDaysBeforeDueDate;
    private static BigInteger paramMaxErrors;
    private static String paramEligPortalCaseCharValue;
    private static final String SAVEPOINT = "CREATE_CASE";*/
    @SuppressWarnings("unused")
	private ServiceAgreementStatusLookup paramSaStatus;
    private CaseType paramCaseType;
    private CharacteristicType paramACIDueDtCharType;
    private CharacteristicType paramMeterIdCharType;
    private CharacteristicType paramEligPortalCaseCharType;
    private CharacteristicType paramSpIdCharType;
    @SuppressWarnings("unused")
	private MeterLocation paramMeterLocation;
    private BigInteger paramDaysBeforeDueDate;
    private BigInteger paramMaxErrors;
    private String paramEligPortalCaseCharValue;
    // End change Neha IM-041589 2013-11-29

    // Start Add - #7213 - Ujesh - 2015-02-09
    private CharacteristicType paramACIResultCodeCharType;
    // START DELETE - JHERNA - 2015-11-24 - SysAid#31775
    //private String paramACIResultCodeCharVal;
    // END  DELETE - JHERNA - 2015-11-24 - SysAid#31775
    // End Add - #7213 - Ujesh - 2015-02-09
    // Start Add - #19455 - Alex - 2015-04-08
    // Constants
    // START DELETE - JHERNA - 2015-11-24 - SysAid#31775
    //private static final String aciRepairCaseType = "CMACIREPAIR";
    // END DELETE - JHERNA - 2015-11-24 - SysAid#31775
    // START ADD - JHERNA - 2016-03-16 - SysAid#89759
    private static final String aciRepairCaseType = "CMACIREPAIR";
    // END ADD - JHERNA - 2016-03-16 - SysAid#89759
    // End   Add - #19455 - Alex - 2015-04-08
    
	// Start add - EQuint - B-36287 - 02-12-2025
	private static final String aciInspectionCaseType = "CMACIINSPECT";
	// End add - EQuint - B-36287 - 02-12-2025

    /*
     * Start Add - JTiozon - 2017-08-17 - FS_NA188394/SA-188394.3
     */
    // Defect 3868063 - 2017-09-22 - Start Delete
    //private static FeatureConfiguration aciFeatureConfig;
    // Defect 3868063 - 2017-09-22 - End Delete
    /*
     * End Add - JTiozon - 2017-08-17 - FS_NA188394/SA-188394.3
     */

    // START DELETE - JHERNA - 2015-11-24 - SysAid#31775
//    public JobWork getJobWork() {
//
//        ArrayList<ThreadWorkUnit> workUnitList =  new ArrayList<ThreadWorkUnit>();
//        List<SQLResultRow> servicePointsRow = null;
//        servicePointsRow = getServicePoints();
//
//        for(SQLResultRow row : servicePointsRow){
//
//            // Start Add - #7213 - Ujesh - 2015-02-09
//
//        	// Don't Create Case if the effective ACI Result Code Char is "A"
//        	// Start Change - #19455 - Alex - 2015-04-08
///*        	ServicePoint_Id spId = (ServicePoint_Id) row.getId("SP_ID", ServicePoint.class);
//        	ServicePointCharacteristic spChar =  spId.getEntity().getEffectiveCharacteristic(paramACIResultCodeCharType);
//        	if(!isNull(spChar))
//        	{
//	        	String effectiveCharOnSp = spChar.getCharacteristicValue();
//	        	if(effectiveCharOnSp.trim().equalsIgnoreCase(paramACIResultCodeCharVal.trim()))
//	        	{
//	        		// Skip this record and get Next one
//	        		continue;
//	        	}
//        	}*/
//            // End Add - #7213 - Ujesh - 2015-02-09
//        	if(paramCaseType.equals(new CaseType_Id(aciRepairCaseType).getEntity())){
//        		ServicePoint_Id spId = (ServicePoint_Id) row.getId("SP_ID", ServicePoint.class);
//            	ServicePointCharacteristic spChar =  spId.getEntity().getEffectiveCharacteristic(paramACIResultCodeCharType);
//            	if(!isNull(spChar))
//            	{
//    	        	String effectiveCharOnSp = spChar.getCharacteristicValue();
//    	        	if(effectiveCharOnSp.trim().equalsIgnoreCase(paramACIResultCodeCharVal.trim()))
//    	        	{
//    	        		// Skip this record and get Next one
//    	        		continue;
//    	        	}
//            	}
//        	}
//        	// End Change - #19455 - Alex - 2015-04-08
//
//            ThreadWorkUnit workUnit = new ThreadWorkUnit();
//
//            workUnit.setPrimaryId((ServicePoint_Id)row.getId("SP_ID", ServicePoint.class));
//            workUnit.addSupplementalData("meterId", (Meter_Id) row.getId("MTR_ID", Meter.class));
//            workUnitList.add(workUnit);
//        }
//
//        return createJobWorkForThreadWorkUnitList(workUnitList);
//    }
    //  END DELETE - JHERNA - 2015-11-24 - SysAid#31775

    /**
     * This method checks if all required Soft Parameters were populated,
     * and all optional Soft Parameters (if populated) are valid.
     *
     * @param isNewRun - a boolean value
     */
    public void validateSoftParameters(boolean isNewRun){

        paramMaxErrors = getParameters().getSoftMaxErrors();
        // Validates Max Error soft parameter
        if (notNull(paramMaxErrors) && paramMaxErrors.intValue() < 0) {
            addError(CustomMessageRepository.nm0101MaxErrorCannotBeLessThanZero(paramMaxErrors.toString().trim()));
        }

        paramDaysBeforeDueDate = getParameters().getX_DAYS_BEFORE_DUE_DATE();
        if(paramDaysBeforeDueDate.intValue() < 0){
            addError(CustomMessageRepository.nm0101XDaysCannotBeLessThanZero(paramDaysBeforeDueDate.toString()));
        }

        paramCaseType = getParameters().getCASE_TYPE_CD();
        paramACIDueDtCharType = getParameters().getACI_DUE_DT_CHAR_TY();

        validateCharTypeEntity(paramACIDueDtCharType, CharacteristicEntityLookup.constants.SERVICE_POINT);

        paramEligPortalCaseCharType = getParameters().getELIG_PORTAL_CASE_CHAR_TY();
        validateCharTypeEntity(paramEligPortalCaseCharType, CharacteristicEntityLookup.constants.CASE);
        validateCharTypeForCaseType(paramEligPortalCaseCharType);

        paramSpIdCharType = getParameters().getSP_ID_CHAR_TYPE();
        validateCharTypeEntity(paramSpIdCharType, CharacteristicEntityLookup.constants.CASE);
        validateCharTypeForCaseType(paramSpIdCharType);

        paramMeterIdCharType = getParameters().getMETER_ID_CHAR_TYPE();
        validateCharTypeEntity(paramMeterIdCharType, CharacteristicEntityLookup.constants.CASE);
        validateCharTypeForCaseType(paramMeterIdCharType);

        paramMeterLocation = getParameters().getMTR_LOCATION();
        paramSaStatus = getParameters().getSA_STATUS();
        paramEligPortalCaseCharValue = getParameters().getELIG_PORTAL_CASE_CHAR_VAL();

        if(paramEligPortalCaseCharType.getCharacteristicType().isPredefinedValue()){
            boolean validCharVal = false;

            // validate char value
            CharacteristicTypeValues charTypeValues = paramEligPortalCaseCharType.getValues();
            for(CharacteristicValue charValIter : charTypeValues){
                if(charValIter.fetchIdCharacteristicValue().trim().compareTo(paramEligPortalCaseCharValue.trim()) == 0){
                    validCharVal = true;
                    break;
                }
            }
            if(!validCharVal){
                // log an error in batch run tree
                addError(CustomMessageRepository.nm0101InvalidInputCharVal(paramEligPortalCaseCharValue, paramEligPortalCaseCharType.getId().getTrimmedValue()));
            }
        }

        // Start Add - #7213 - Ujesh - 2015-02-09
        paramACIResultCodeCharType = getParameters().getACI_RESULT_CHAR_TY();
        // START DELETE - JHERNA - 2015-11-24 - SysAid#31775
        //paramACIResultCodeCharVal = getParameters().getACI_RESULT_CHAR_VAL();
        // END DELETE - JHERNA - 2015-11-24 - SysAid#31775
        validateCharTypeEntity(paramACIResultCodeCharType, CharacteristicEntityLookup.constants.SERVICE_POINT);
        // Start End - #7213 - Ujesh - 2015-02-09

        /*
	     * Start Add - JTiozon - 2017-08-17 - FS_NA188394/SA-188394.3
	     */
        // Defect 3868063 - 2017-09-22 - Start Delete
		//aciFeatureConfig = this.getParameters().getACI_CASE_MG_EXC_DISLOC_FC_NAME();
        // Defect 3868063 - 2017-09-22 - End Delete
	    /*
	     * End Add - JTiozon - 2017-08-17 - FS_NA188394/SA-188394.3
	     */
        
        // Start add - EQuint - B-36287 - 02-12-2025
        String paramExcludeCisDiv = getParameters().getEXCLUDE_CIS_DIV();
        if (notBlank(paramExcludeCisDiv)) {
        	String[] excludeCisDivArr = paramExcludeCisDiv.split("\\s*,\\s*");
        	for (String cisDivStr : excludeCisDivArr) {
        		CisDivision_Id cisDivId = new CisDivision_Id(cisDivStr);
    			if (isNull(cisDivId.getEntity())) {
    				addError(CustomMessageRepository.nm0101InvalidCisDivision(cisDivStr));
    			} 
    		}
        }
        // End add - EQuint - B-36287 - 02-12-2025
    }
    // START DELETE - JHERNA - 2015-11-24 - SysAid#31775
    /*
    private List<SQLResultRow> getServicePoints(){

        StringBuilder servicePointsQueryStr = new StringBuilder();
        //servicePointsQueryStr.append(" SELECT MTR.MTR_ID, HIST.SP_ID ");
        //servicePointsQueryStr.append(" FROM CI_MTR MTR, CI_SP_MTR_EVT EVNT ");
		servicePointsQueryStr.append(" SELECT CONFIG.MTR_ID, HIST.SP_ID ");
		servicePointsQueryStr.append(" FROM CI_SP_MTR_EVT EVNT ");
        servicePointsQueryStr.append(" , CI_MTR_CONFIG CONFIG ");
        servicePointsQueryStr.append(" , CI_SP_MTR_HIST HIST ");
        servicePointsQueryStr.append(" , CI_SP_CHAR CH ");
        servicePointsQueryStr.append(" , CI_SP SP ");
        servicePointsQueryStr.append(" , CI_MR MR ");
        servicePointsQueryStr.append(" , CI_SA_SP SASP ");
        servicePointsQueryStr.append(" , CI_SA SA ");
        //servicePointsQueryStr.append(" WHERE CONFIG.MTR_ID = MTR.MTR_ID ");
        //servicePointsQueryStr.append(" AND EVNT.SP_MTR_EVT_FLG = :install ");
		servicePointsQueryStr.append(" WHERE EVNT.SP_MTR_EVT_FLG = :install ");
        servicePointsQueryStr.append(" AND HIST.SP_ID = SP.SP_ID ");
        servicePointsQueryStr.append(" AND HIST.SP_MTR_HIST_ID = EVNT.SP_MTR_HIST_ID ");
        servicePointsQueryStr.append(" AND HIST.MTR_CONFIG_ID = CONFIG.MTR_CONFIG_ID ");
        servicePointsQueryStr.append(" AND (HIST.REMOVAL_DTTM IS NULL OR HIST.REMOVAL_DTTM > :processDateTime) ");
        servicePointsQueryStr.append(" AND EVNT.MR_ID = MR.MR_ID ");
        servicePointsQueryStr.append(" AND MR.READ_DTTM <= :processDateTime ");
        servicePointsQueryStr.append(" AND NOT EXISTS (SELECT 'X' FROM CI_CASE CSE, CI_CASE_CHAR CASECH ");
        servicePointsQueryStr.append("                  WHERE CASECH.CHAR_TYPE_CD = :spIdCharType ");
        servicePointsQueryStr.append("                  AND TRIM(CASECH.CHAR_VAL_FK1) = TRIM(HIST.SP_ID) ");
        servicePointsQueryStr.append("                  AND CASECH.CASE_ID = CSE.CASE_ID ");
		servicePointsQueryStr.append("                  AND CSE.CASE_TYPE_CD = :caseType ");
        servicePointsQueryStr.append("                  AND CSE.CASE_COND_FLG = :open) ");
        servicePointsQueryStr.append(" AND (SP.MTR_LOC_CD IS NULL OR SP.MTR_LOC_CD <> :mtrLocation) ");
        servicePointsQueryStr.append(" AND CH.SP_ID = SP.SP_ID ");
        servicePointsQueryStr.append(" AND CH.CHAR_TYPE_CD = :dueDtCharType ");
       // below is change due to IM- 33957 - SG
       //servicePointsQueryStr.append(" AND :processDate >= (to_date(nvl(nvl(TRIM(ch.adhoc_char_val),TRIM(ch.char_val)),TRIM(ch.char_val_fk1)),'MM/DD/YYYY') - :xdays) ");
       //servicePointsQueryStr.append(" AND :processDate >= (to_date(nvl(nvl(TRIM(ch.adhoc_char_val),TRIM(ch.char_val)),TRIM(ch.char_val_fk1)),'YYYY-MM-DD') - :xdays) ");
	   servicePointsQueryStr.append(" AND :processDate >= (to_date(TRIM(ch.adhoc_char_val),'YYYY-MM-DD') - :xdays) ");
       //above is change due to IM- 33957 - SG
       servicePointsQueryStr.append(" AND CH.EFFDT = (SELECT MAX(CH1.EFFDT) FROM CI_SP_CHAR CH1 WHERE CH1.SP_ID = CH.SP_ID AND CH1.CHAR_TYPE_CD = CH.CHAR_TYPE_CD AND CH1.EFFDT <= :processDate) ");
        servicePointsQueryStr.append(" AND SASP.SP_ID = SP.SP_ID ");
        servicePointsQueryStr.append(" AND SA.SA_ID = SASP.SA_ID ");
        servicePointsQueryStr.append(" AND SA.SA_STATUS_FLG = :saStatus  ");
        servicePointsQueryStr.append(" AND SA.END_DT IS NULL ");
        PreparedStatement servicePointPrepStmt = createPreparedStatement(servicePointsQueryStr.toString());
        servicePointPrepStmt.bindDateTime("processDateTime", getProcessDateTime());
        servicePointPrepStmt.bindLookup("install", ServicePointMeterEventTypeLookup.constants.INSTALL);
        servicePointPrepStmt.bindEntity("spIdCharType", paramSpIdCharType);
		servicePointPrepStmt.bindId("caseType", paramCaseType.getId());
        servicePointPrepStmt.bindLookup("open", CaseConditionLookup.constants.OPEN);
        servicePointPrepStmt.bindEntity("mtrLocation", paramMeterLocation);
        servicePointPrepStmt.bindEntity("dueDtCharType", paramACIDueDtCharType);
        servicePointPrepStmt.bindBigInteger("xdays", paramDaysBeforeDueDate);
        servicePointPrepStmt.bindDate("processDate", getProcessDateTime().getDate());
        servicePointPrepStmt.bindLookup("saStatus", paramSaStatus);
        List<SQLResultRow> servicePointRow = servicePointPrepStmt.list();

        return servicePointRow;

    }
    */
    // END DELETE - JHERNA - 2015-11-24 - SysAid#31775


    /**
     * This Method will validate whether the input parameter Characteristic Type
     * is valid for the Case Characteristic Entity.
     * @param parmCharType
     */
    private void validateCharTypeEntity(CharacteristicType parmCharType, CharacteristicEntityLookup parmEntityLookup){
        CharacteristicEntity_Id characteristicEntityId = new CharacteristicEntity_Id(parmCharType, parmEntityLookup);
        if (isNull(characteristicEntityId.getEntity())){
            addError(CustomMessageRepository.nm0101InvalidInputCharTypeForEntity(parmCharType.getId().getIdValue(), parmEntityLookup.getConstantName()));
        }
    }

    /**
     * This Method will validate whether the input parameter Characteristic Type
     * is valid for the input Case Type.
     * @param parmCharType
     */
    private void validateCharTypeForCaseType(CharacteristicType parmCharType){
        CharacteristicTypeCaseType charTypeCaseType = new CharacteristicTypeCaseType_Id(parmCharType, paramCaseType).getEntity();
        if(isNull(charTypeCaseType)){
            addError(CustomMessageRepository.nm0101CharTypeInvalidForCaseType(parmCharType.getId().getTrimmedValue(), paramCaseType.getId().getTrimmedValue()));
        }
    }


    public Class<CmACIInspectRepairCase_BatchProcessWorker> getThreadWorkerClass() {
        return CmACIInspectRepairCase_BatchProcessWorker.class;
    }

    /*
     * INNER CLASS
     */
    public static class CmACIInspectRepairCase_BatchProcessWorker extends
    CmACIInspectRepairCase_BatchProcessWorker_Gen {

        // Start add Neha IM-041589 2013-11-29
        private CaseType paramCaseType;
        private CharacteristicType paramMeterIdCharType;
        private CharacteristicType paramEligPortalCaseCharType;
        private CharacteristicType paramSpIdCharType;
        private String paramEligPortalCaseCharValue;
        private String SAVEPOINT = "CREATE_CASE";
        // End add Neha IM-041589 2013-11-29
        
        // Start add - EQuint - B-36287 - 02-12-2025
        private String paramExcludeCisDiv;
        // End add - EQuint - B-36287 - 02-12-2025

        private ServicePoint_Id spId;
        private Meter_Id meterId;
        private ArrayList <CaseCharacteristic_DTO>  charList;// = new ArrayList<CaseCharacteristic_DTO>();

        //Start Add - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
        private static FrameworkSession session;
        //End Add - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
        // Defect 3868063 - 2017-09-22 - Start Add
        private FeatureConfiguration aciFeatureConfig;
        // Defect 3868063 - 2017-09-22 - End Add
        
        // Start add - EQuint - B-36287 - 02-12-2025
        private String[] exlcudeCisDivArr;
    	// End add - EQuint - B-36287 - 02-12-2025

        public ThreadExecutionStrategy createExecutionStrategy() {
            // START CHANGE - JHERNA - 2015-11-24 - SysAid#31775
            //return new StandardCommitStrategy(this);
        	return new ThreadIterationStrategy(this);
            // END CHANGE - JHERNA - 2015-11-24 - SysAid#31775
        }

        // START DELETE - JHERNA - 2015-11-24 - SysAid#31775
        // Start add Neha IM-041589 2013-11-29
        ///**
        // * Perform any initialization that must be done at the start of this thread processing work.
        // * @param initializationPreviouslySuccessful - indicates that this method was called successfully called during some
        // * prior execution, presumably because this is a restart situation.
        // * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted
        // * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
        // * @see com.splwg.base.api.batch.ThreadWorker#initializeThreadWork(boolean)
        // */
        /*
        public void initializeThreadWork(boolean initializationPreviouslySuccessful)
        throws ThreadAbortedException, RunAbortedException {
            // retrieving parameters
            JobParameters parameters = getParameters();
            paramCaseType = parameters.getCASE_TYPE_CD();
            paramEligPortalCaseCharType = parameters.getELIG_PORTAL_CASE_CHAR_TY();
            paramSpIdCharType = parameters.getSP_ID_CHAR_TYPE();
            paramMeterIdCharType = parameters.getMETER_ID_CHAR_TYPE();
            paramEligPortalCaseCharValue = parameters.getELIG_PORTAL_CASE_CHAR_VAL();
        }
        */
        // End add Neha IM-041589 2013-11-29
        // END DELETE - JHERNA - 2015-11-24 - SysAid#31775

//      START ADD - JHERNA - 2015-11-19 - SysAid#31775

        /* (non-Javadoc)
		 * @see com.splwg.base.api.batch.AbstractThreadWorker#getQueryIteratorForThread(com.splwg.base.api.datatypes.SingleFieldId, com.splwg.base.api.datatypes.SingleFieldId)
		 *
		 * This is the main selection criteria method
		 */
		@Override
		protected QueryIterator getQueryIteratorForThread(StringId lowID, StringId highID) {
			/*
			 * Start Add - JTiozon - 2017-08-17 - FS_NA188394/SA-188394.3
			 * Retrieve all Excluded disconnect location from the feature configuration (both ACI Inspection and ACI Repair excluded disconnect locations)
			 * note: include only either inspect or repair list
			 */
			String aciInspectionOptType = CmAciExcludedDisconnectLocationLookup.constants.EXCLUDE_DISC_LOCATION_A_C_I_INSPECTION_LIST.getLookupValue().fetchIdFieldValue();
			List<String> aciInspectionValueList = retrieveFeatureConfigurationOptionValues(aciFeatureConfig, aciInspectionOptType);

			String aciRepairOptType = CmAciExcludedDisconnectLocationLookup.constants.EXCLUDE_DISC_LOCATION_A_C_I_REPAIR_LIST.getLookupValue().fetchIdFieldValue();
			List<String> aciRepairValueList = retrieveFeatureConfigurationOptionValues(aciFeatureConfig, aciRepairOptType);
			
			// Start add - EQuint - B-36287 - 02-12-2025
	        if (notBlank(paramExcludeCisDiv)) {
	        	exlcudeCisDivArr = paramExcludeCisDiv.split("\\s*,\\s*");
	        }
	        // End add - EQuint - B-36287 - 02-12-2025

			/*
			 * End Add - JTiozon - 2017-08-17 - FS_NA188394/SA-188394.3
			 */
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT UNIQUE(SPMH.SP_ID) SPID, SPMH.MTR_CONFIG_ID ");
			stringBuilder.append("FROM CI_SP SP, CI_SP_MTR_HIST SPMH, CI_SA SA, CI_SA_SP SASP ");
			// Criteria that the SP's meter location must not be outside
			/*
			 * Start Add - PNikiforovitch - 2021-01-29 - SA-358138-CM-CORRI_Loc_IN_002
			 */
			// New criterion: SP's meter location must be inside
			//stringBuilder.append("WHERE SP.MTR_LOC_CD <> :meterLocationCode ");
			stringBuilder.append("WHERE SP.MTR_LOC_CD = :meterLocationCode ");
			/*
			 * End Add - PNikiforovitch - 2021-01-29 - SA-358138-CM-CORRI_Loc_IN_002
			 */
			/*
			 * Start Add - JTiozon - 2017-08-17 - FS_NA188394/SA-188394.3
			 */
			stringBuilder.append("AND SP.DISCON_LOC_CD NOT IN ( ");
			if (paramCaseType.getId().getTrimmedValue().compareTo(aciRepairCaseType) == 0) {
				for (int counter = 0;counter < aciRepairValueList.size(); counter++) {
			          if (counter == 0) {
			        	  stringBuilder.append(":excludeList" + counter);
			          } else {
			        	  stringBuilder.append(", :excludeList" + counter);
			          }
			     }

			}else{
				for (int counter = 0;counter < aciInspectionValueList.size(); counter++) {
			          if (counter == 0) {
			        	  stringBuilder.append(":excludeList" + counter);
			          } else {
			        	  stringBuilder.append(", :excludeList" + counter);
			          }
			     }

			}
			stringBuilder.append(")  ");
			/*
			 * End Add - JTiozon - 2017-08-17 - FS_NA188394/SA-188394.3
			 */
			stringBuilder.append("AND SPMH.SP_ID = SP.SP_ID ");
            // START CHANGES - JHERNA - 2016-03-16 - SysAid#89759
            // Criteria where SP must currently have a meter installed
            //stringBuilder.append("AND SPMH.REMOVAL_DTTM IS null ");
            stringBuilder.append("AND (SPMH.REMOVAL_DTTM IS null OR SPMH.REMOVAL_DTTM > :processDateTime)");
            // END CHANGES - JHERNA - 2016-03-16 - SysAid#89759
			// Criteria where SP must not have an open CASE
			stringBuilder.append("AND NOT EXISTS (SELECT 'X' ");
			stringBuilder.append("				FROM CI_CASE ccbCase, CI_CASE_CHAR ccbCaseChar ");
			stringBuilder.append("				WHERE ccbCase.CASE_TYPE_CD = :caseTypeCode ");
			stringBuilder.append("        and ccbCase.CASE_COND_FLG = :openCondition ");
			stringBuilder.append("				AND ccbCaseChar.CASE_ID = ccbCase.CASE_ID ");
			stringBuilder.append("				AND ccbCaseChar.CHAR_TYPE_CD = :charTypeSPID ");
			// It is assumed that the characteristic would only be as an Foreign Key characteristic to improve performance
			stringBuilder.append("				AND ccbCaseChar.CHAR_VAL_FK1 = SPMH.SP_ID ");
			stringBuilder.append("				) ");
			// Criteria that the SP must have an active Service Agreement
			stringBuilder.append("AND SASP.SP_ID = SPMH.SP_ID ");
			stringBuilder.append("AND SA.SA_ID = SASP.SA_ID ");
			stringBuilder.append("AND SA.SA_STATUS_FLG = :activeStatus ");
			// Criteria that the SP must have an ACI Due Date characteristic
			stringBuilder.append("AND EXISTS (SELECT 'X' ");
			stringBuilder.append("			FROM CI_SP_CHAR SPC ");
			stringBuilder.append("			WHERE SPC.SP_ID = SPMH.SP_ID ");
			stringBuilder.append("			AND SPC.CHAR_TYPE_CD = :charTypeAciDueDate ");
			// Criteria that the processing date must be greater or equal to the ACI Duration Date - modifier parameter
			stringBuilder.append("			AND :processDate >= ");
			stringBuilder.append("              (TO_DATE(SPC.ADHOC_CHAR_VAL, 'yyyy-MM-dd') - :dateModifier) ");
			// START ADD - JHERNA - 2016-03-16 - SysAid#89759
	        // Ensure that only the most effective ACI Due Date Characteristic is being checked.
            stringBuilder.append("          AND SPC.EFFDT = (SELECT MAX(SPC2.EFFDT) ");
            stringBuilder.append("                           FROM CI_SP_CHAR SPC2 ");
            stringBuilder.append("                           WHERE SPC2.SP_ID = SPC.SP_ID ");
            stringBuilder.append("                           AND SPC2.CHAR_TYPE_CD = :charTypeAciDueDate ");
            stringBuilder.append("                           AND SPC2.EFFDT <= :processDate ");
            stringBuilder.append("                            ) ");
            // END ADD - JHERNA - 2016-03-16 - SysAid#89759
			stringBuilder.append("			) ");
			// START ADD - JHERNA - 2016-03-16 - SysAid#89759
            // only validate for the ACI Result if processing ACI Repair
            if (paramCaseType.getId().getTrimmedValue().compareTo(aciRepairCaseType) == 0) {
            // END ADD - JHERNA - 2016-03-16 - SysAid#89759
    			// Criteria for ACI REPAIR that the SP must not have a result code characteristic which matches the  batch parameters
    			stringBuilder.append("AND NOT EXISTS (SELECT 'X' ");
    			stringBuilder.append("            FROM CI_SP_CHAR SPC ");
    			stringBuilder.append("            WHERE SPC.SP_ID = SPMH.SP_ID ");
    			stringBuilder.append("            AND SPC.CHAR_TYPE_CD = :charTypeACIResult ");
    			stringBuilder.append("            AND SPC.CHAR_VAL = :aciResult ");
    			stringBuilder.append("            AND SPC.EFFDT = (SELECT MAX(SPC2.EFFDT) ");
    			stringBuilder.append("                             FROM CI_SP_CHAR SPC2 ");
    			stringBuilder.append("                             WHERE SPC2.SP_ID = SPMH.SP_ID ");
    			stringBuilder.append("                             AND SPC2.CHAR_TYPE_CD = :charTypeACIResult ");
    			// START ADD - JHERNA - 2016-03-16 - SysAid#89759
                stringBuilder.append("                             AND SPC2.EFFDT <= :processDate ");
                // END ADD - JHERNA - 2016-03-16 - SysAid#89759
    			stringBuilder.append("                            ) ");
    			stringBuilder.append("            ) ");
	        // START ADD - JHERNA - 2016-03-16 - SysAid#89759
            }
            // END ADD - JHERNA - 2016-03-16 - SysAid#89759
            
            // Start add - EQuint - B-36287 - 02-12-2025
        	if (Arrays.asList(aciRepairCaseType, aciInspectionCaseType).contains(paramCaseType.getId().getTrimmedValue()) && notNull(exlcudeCisDivArr) && exlcudeCisDivArr.length > 0) {
            	stringBuilder.append("AND SA.CIS_DIVISION NOT IN ( ");
				for (int i = 0;i < exlcudeCisDivArr.length; i++) {
					if (i == 0) {
						stringBuilder.append(":cisDivExcludeList" + i);
			        } else {
			        	stringBuilder.append(", :cisDivExcludeList" + i);
			        }
				}
	            stringBuilder.append(")  ");
			} 
            // End add - EQuint - B-36287 - 02-12-2025
            
			// Criteria for multi threading - define what the range would be processed by this thread
			stringBuilder.append("AND SPMH.SP_ID BETWEEN :lowID AND :highID ");
			stringBuilder.append("ORDER BY SPID ASC ");
			//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			prepState.bindId("meterLocationCode", this.getParameters().getMTR_LOCATION().getId());
			prepState.bindId("caseTypeCode", this.getParameters().getCASE_TYPE_CD().getId());
			prepState.bindLookup("openCondition", CaseConditionLookup.constants.OPEN);
			prepState.bindId("charTypeSPID", this.getParameters().getSP_ID_CHAR_TYPE().getId());
			prepState.bindLookup("activeStatus", this.getParameters().getSA_STATUS());
			prepState.bindId("charTypeAciDueDate", this.getParameters().getACI_DUE_DT_CHAR_TY().getId());
			prepState.bindDate("processDate", this.getProcessDateTime().getDate());
			prepState.bindBigInteger("dateModifier", this.getParameters().getX_DAYS_BEFORE_DUE_DATE());

            // START ADD - JHERNA - 2016-03-16 - SysAid#89759
            prepState.bindDateTime("processDateTime", this.getProcessDateTime());
            // only validate for the ACI Result if processing ACI Repair
            if (paramCaseType.getId().getTrimmedValue().compareTo(aciRepairCaseType) == 0) {
            // END ADD - JHERNA - 2016-03-16 - SysAid#89759
                prepState.bindId("charTypeACIResult", this.getParameters().getACI_RESULT_CHAR_TY().getId());
                prepState.bindString("aciResult", this.getParameters().getACI_RESULT_CHAR_VAL().trim(), "CHAR_VAL");
            // START ADD - JHERNA - 2016-03-16 - SysAid#89759
            }
            // END ADD - JHERNA - 2016-03-16 - SysAid#89759

            /*
			 * Start Add - JTiozon - 2017-08-17 - FS_NA188394/SA-188394.3
			 */
			if (paramCaseType.getId().getTrimmedValue().compareTo(aciRepairCaseType) == 0) {
				for (int i = 0; i < aciRepairValueList.size(); i++){
					DisconnectLocation_Id disconnectLocId = new DisconnectLocation_Id(aciRepairValueList.get(i).trim());
					prepState.bindId("excludeList" + i, disconnectLocId);
                }

			}else{
				for (int i = 0; i < aciInspectionValueList.size(); i++){
					DisconnectLocation_Id disconnectLocId = new DisconnectLocation_Id(aciInspectionValueList.get(i).trim());
					prepState.bindId("excludeList" + i, disconnectLocId);
                }
			}
			/*
			 * End Add - JTiozon - 2017-08-17 - FS_NA188394/SA-188394.3
			 */
			
			// Start add - EQuint - B-36287 - 02-12-2025
			if (Arrays.asList(aciRepairCaseType, aciInspectionCaseType).contains(paramCaseType.getId().getTrimmedValue()) && notNull(exlcudeCisDivArr)  && exlcudeCisDivArr.length > 0) {
				for (int i = 0; i < exlcudeCisDivArr.length; i++){
					CisDivision_Id cisDivId = new CisDivision_Id(exlcudeCisDivArr[i].trim());
					prepState.bindId("cisDivExcludeList" + i, cisDivId);
                }

			}
			// End add - EQuint - B-36287 - 02-12-2025
			

			prepState.bindId("lowID", lowID);
			prepState.bindId("highID", highID);

			prepState.execute();
			return prepState.iterate();
		}

		/* (non-Javadoc)
		 * @see com.splwg.base.api.batch.AbstractThreadWorker#getNextWorkUnit(com.splwg.base.api.QueryResultRow)
		 */
		@Override
		protected ThreadWorkUnit getNextWorkUnit(QueryResultRow qrw) {

			ServicePoint_Id spID = (ServicePoint_Id) qrw.getId("SPID", ServicePoint.class);
			MeterConfiguration_Id mtrConfigID = (MeterConfiguration_Id) qrw.getId("MTR_CONFIG_ID", MeterConfiguration.class);

			ThreadWorkUnit twu = new ThreadWorkUnit();
			twu.setPrimaryId(spID);
			twu.addSupplementalData("MTR_CONFIG_ID", mtrConfigID);

			return twu;
		}

		/* (non-Javadoc)
		 * @see com.splwg.base.api.batch.AbstractThreadWorker#initializeThreadWork(boolean, com.splwg.base.api.batch.ThreadWorkUnit)
		 */
		@Override
		public void initializeThreadWork(boolean arg0, ThreadWorkUnit arg1) throws ThreadAbortedException, RunAbortedException {

			this.startResultRowQueryIteratorForThread(ServicePoint_Id.class);

			paramCaseType = this.getParameters().getCASE_TYPE_CD();
			paramEligPortalCaseCharType = this.getParameters().getELIG_PORTAL_CASE_CHAR_TY();
			paramSpIdCharType = this.getParameters().getSP_ID_CHAR_TYPE();
			paramMeterIdCharType = this.getParameters().getMETER_ID_CHAR_TYPE();
			paramEligPortalCaseCharValue = this.getParameters().getELIG_PORTAL_CASE_CHAR_VAL();
			
			// Start add - EQuint - B-36287 - 02-12-2025
	        paramExcludeCisDiv = getParameters().getEXCLUDE_CIS_DIV();
	        // End add - EQuint - B-36287 - 02-12-2025
			
			// Defect 3868603 - 2017-09-22 - Start Add
			aciFeatureConfig = this.getParameters().getACI_CASE_MG_EXC_DISLOC_FC_NAME();
			// Defect 3868603 - 2017-09-22 - End Add
		}
		// END ADD - JHERNA - 2015-11-19 - SysAid#31775

        public boolean executeWorkUnit(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {
            charList = new ArrayList<CaseCharacteristic_DTO>();

            spId = (ServicePoint_Id) unit.getPrimaryId();
            // START CHANGES - JHERNA - 2015-12-17 - SysAid#74725
            //meterId = (Meter_Id) unit.getSupplementallData("meterId");
            MeterConfiguration_Id mtrConfigID = (MeterConfiguration_Id) unit.getSupplementallData("MTR_CONFIG_ID");
            // Retrieve Meter ID of the Meter Configuration
            PreparedStatement prepState = createPreparedStatement("SELECT MC.MTR_ID " +
            		"FROM CI_MTR_CONFIG MC " +
            		"WHERE MC.MTR_CONFIG_ID = :mtrConfigID " +
            		"AND MC.EFF_DTTM = (SELECT MAX(MC2.EFF_DTTM) " +
            		"                   FROM CI_MTR_CONFIG MC2 " +
            		"                   WHERE MC2.MTR_CONFIG_ID = :mtrConfigID " +
            		"                   AND MC2.EFF_DTTM <= :currentDttm " +
            		//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            		//"                   ) ");
            		"                   ) ", getClass().getName());
            		//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            prepState.bindId("mtrConfigID", mtrConfigID);
            prepState.bindDateTime("currentDttm", this.getProcessDateTime());
            prepState.execute();
            if (prepState.list().size() > 0) {
            	SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
            	meterId = (Meter_Id) sqlRow.getId("MTR_ID", Meter.class);
            }
            prepState.close();
            // END CHANGES - JHERNA - 2015-12-17 - SysAid#74725
            //Start Add - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            session = (FrameworkSession)SessionHolder.getSession();
            //End Add - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            try{
            	//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
                //setSavepoint(SAVEPOINT);
            	session.setSavepoint(SAVEPOINT);
                //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
                Boolean caseCreated = createCase();
                if(!caseCreated){
                    return false;
                }
            }catch(ApplicationError appError){
                String msgText = appError.getServerMessage().toString();
                if(notNull(appError.getServerMessage().getMessageText())){
                    msgText = appError.getServerMessage().getMessageText();
                }
                //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
                //rollbackToSavepoint(SAVEPOINT);
                session.rollbackToSavepoint(SAVEPOINT);
                //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
                logError(CustomMessageRepository.nm0101ApplicationError(spId.getTrimmedValue(), msgText));
                return false;
            }
            return true;
        }

        private Boolean createCase() {

            // START CHANGES - JHERNA - 2019-03-20 - SysAid#286046
			/*
        	SQLResultRow usageRow = getUsage();
            Account_Id acctId = null;
            Person_Id personId = null;
            String phone = "";
            if(notNull(usageRow)){
                acctId = (Account_Id)usageRow.getId("ACCT_ID", Account.class);
                personId = (Person_Id)usageRow.getId("PER_ID", Person.class);
                phone = usageRow.getString("PHONE");
            }
            */
			CmSaSpMeterRelationshipsRoutine_Impl.LatestCustomerData latestCustomerData = new CmSaSpMeterRelationshipsRoutine_Impl.LatestCustomerData();
        	latestCustomerData.setSPID(spId);
        	latestCustomerData.invoke();
        	Account_Id acctId = latestCustomerData.getAccountID();
        	Person_Id personId = latestCustomerData.getPersonID();
        	String phone = latestCustomerData.getPhone();
            // END CHANGES - JHERNA - 2019-03-20 - SysAid#286046

            ToDoCase_DTO toDoCaseDTO = (ToDoCase_DTO) createDTO(ToDoCase.class);
            for (CaseStatus status : paramCaseType.getId().getEntity().getCaseStatues()){
                if(status.getStatusCondition().isInitial()){
                    toDoCaseDTO.setCaseStatusId(status.getId());
                }
            }
            if(isNull(acctId) && paramCaseType.getAccountUsage().isRequired()){
                logError(CustomMessageRepository.nm0101AccountNotFoundButReqdOnCase(spId.getTrimmedValue(), paramCaseType.getId().getTrimmedValue()));
                return false;
            }
            if(isNull(personId) && paramCaseType.getPersonUsage().isRequired()){
                logError(CustomMessageRepository.nm0101PersonNotFoundButReqdOnCase(spId.getTrimmedValue(), paramCaseType.getId().getTrimmedValue()));
                return false;
            }
            if(isNull(spId.getEntity().getPremise()) && paramCaseType.getPremiseUsage().isRequired()){
                logError(CustomMessageRepository.nm0101PremiseNotFoundButReqdOnCase(spId.getTrimmedValue(), paramCaseType.getId().getTrimmedValue()));
                return false;
            }
            if(notNull(acctId) && !paramCaseType.getAccountUsage().isNotAllowed()){
                toDoCaseDTO.setAccountId(acctId);
            }
            if(notNull(personId) && !paramCaseType.getPersonUsage().isNotAllowed()){
                toDoCaseDTO.setPersonId(personId);
            }
            if(notNull(spId.getEntity().getPremise()) && !paramCaseType.getPremiseUsage().isNotAllowed()){
                toDoCaseDTO.setPremiseId(spId.getEntity().getPremise().getId());
            }

            if(paramCaseType.getCallbackPhoneUsage().isRequired()){
                if(notNull(personId)){
                    List<SQLResultRow> list = getPhoneInformation(personId);
                    phone = list.iterator().next().getString("PHONE");
                    toDoCaseDTO.setPhoneTypeId((PhoneType_Id)list.iterator().next().getId("PHONE_TYPE_CD", PhoneType.class));
                    toDoCaseDTO.setPhone(phone);
                }
            }
            if(paramCaseType.getContactInformationUsage().isRequired()){
                toDoCaseDTO.setContactPersonId(personId);
                toDoCaseDTO.setPreferredContactMethod(ContactMethodLookup.constants.NOT_APPLICABLE);
            }
            if(paramCaseType.getContactInstructionsUsage().isRequired()){
                toDoCaseDTO.setContactInstructions(CustomMessageRepository.nm0101ContactInstructionsUsage().getMessageText());
            }


            createCaseChar();

            CaseCreatorData caseCreatorData = CaseCreatorData.Factory.newInstance();
            caseCreatorData.setToDoCaseDTO(toDoCaseDTO);
            caseCreatorData.setCaseCharacteristics(charList);

            CaseCreator caseCreator = CaseCreator.Factory.newInstance();
            caseCreatorData = caseCreator.createCase(caseCreatorData);

            return true;
        }

        private void createCaseChar() {

            if(!addCharacteristic(paramSpIdCharType, spId.getTrimmedValue())){
                return;
            }
            if(!addCharacteristic(paramMeterIdCharType, meterId.getTrimmedValue())){
                return;
            }
            if(!addCharacteristic(paramEligPortalCaseCharType, paramEligPortalCaseCharValue)){
                return;
            }

        }

        /**
         * This Method is used to add a characteristic Value to the Case.
         * @param caseId
         * @param charType
         * @param charVal
         * @return
         */
        private boolean addCharacteristic(CharacteristicType charType, String charVal){

            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

            CaseCharacteristic_DTO caseCharacteristicDTO;
            CaseCharacteristic_Id caseCharacteristicId = new CaseCharacteristic_Id(charType.getId(), ToDoCase_Id.NULL, BigInteger.ONE);
            caseCharacteristicDTO = caseCharacteristicId.newDTO();

            if(charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()){
                caseCharacteristicDTO.setAdhocCharacteristicValue(charVal);
            } else if (charTypeLookup.isPredefinedValue()){
                caseCharacteristicDTO.setCharacteristicValue(charVal);
            } else if (charTypeLookup.isForeignKeyValue()){
                caseCharacteristicDTO.setCharacteristicValueForeignKey1(charVal);
            }
            charList.add(caseCharacteristicDTO);
            return true;
        }
        // START DELETE - JHERNA - 2019-03-20 - SysAid#286046
        /*
        private SQLResultRow getUsage(){

            StringBuilder usageQueryStr = new StringBuilder();
            usageQueryStr.append(" SELECT SA.ACCT_ID, APER.PER_ID,(SELECT PHONE FROM CI_PER_PHONE WHERE PER_ID = APER.PER_ID AND ROWNUM <=1) PHONE ");
            usageQueryStr.append(" FROM CI_SA_SP SASP ");
            usageQueryStr.append(" , CI_SA SA ");
            usageQueryStr.append(" , CI_ACCT_PER APER ");
            usageQueryStr.append(" WHERE SASP.SP_ID = :spId ");
            usageQueryStr.append(" AND SASP.SA_ID = SA.SA_ID ");
            // Start add 2014-05-06   Neha  IM-050188
            usageQueryStr.append("  AND SASP.STOP_DTTM IS NULL ");
            // End add 2014-05-06   Neha  IM-050188
            usageQueryStr.append(" AND SA.ACCT_ID = APER.ACCT_ID ");
            usageQueryStr.append(" AND APER.MAIN_CUST_SW = 'Y' ");
            // Start add 2015-02-04  Ujesh #6943
            usageQueryStr.append(" AND SA.SA_STATUS_FLG = :active ");
            // End add 2015-02-04  Ujesh #6943
            usageQueryStr.append(" AND APER.ACCT_REL_TYPE_CD = 'MAIN' ");
            //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            //PreparedStatement usagePrepStmt = createPreparedStatement(usageQueryStr.toString());
            PreparedStatement usagePrepStmt = createPreparedStatement(usageQueryStr.toString(), getClass().getName());
            //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            usagePrepStmt.bindId("spId", spId);
            // Start add 2015-02-04  Ujesh #6943
            usagePrepStmt.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
            // End add 2015-02-04  Ujesh  #6943

            SQLResultRow usageRow = usagePrepStmt.firstRow();
            return usageRow;
        }
        */
        // END DELETE - JHERNA - 2019-03-20 - SysAid#286046

        private List<SQLResultRow> getPhoneInformation(Person_Id perId){
            StringBuilder getUsageDetailsString = new StringBuilder();
            getUsageDetailsString.append("SELECT PHONE , PHONE_TYPE_CD FROM CI_PER_PHONE WHERE PER_ID = :perId ");
            //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            //PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString());
            PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString(), getClass().getName());
            //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            getUsageDetailsPrepStmt.bindId("perId", perId);

            List<SQLResultRow> usageList = getUsageDetailsPrepStmt.list();

            getUsageDetailsPrepStmt.close();

            return usageList;
        }

        /**
         * This method retrieves Feature Configuration Options
         * @param featConfig - Feature Configuration Name
         * @param optionType - Feature Option Type
         * @return List of Feature Option Values
         */
        @SuppressWarnings("unchecked")
		private List<String> retrieveFeatureConfigurationOptionValues(FeatureConfiguration featConfig, String optionType){
        	CmFeatureConfigurationRetriever cmFeatureConfigurationRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
			cmFeatureConfigurationRetriever.setParmWFMName(featConfig);
			cmFeatureConfigurationRetriever.setParmOptType(optionType);

			return cmFeatureConfigurationRetriever.getListOfOptionValues();
        }
    }//Inner

}//Outer
