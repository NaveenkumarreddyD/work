/*
 * *************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This batch program will retrieve all the service Points with 
 * Source Status as disconnected and the Consumption between the 
 * first time period exceeds the consumption threshold value.
 * 
 * Then checks whether the premise linked to the retrieved Service
 * Point has more than one Service Points linked to the Premise.
 * 
 * If Yes:
 *  It will check whether there is a To Do Entry already existing
 * Premise. If no, creates a new To Do Entry.
 * Else:
 *  It will check whether any open case of the mentioned case type 
 * exists on the Premise. If no, creates a new Case.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-03-09   Raviteja        NM0038 Initial Version.  
 * 2013-06-06   Srikanth        WebService Invocation to Daily Read DB
 * 2013-12-11   JPunza          Modified to improve performance.
 * 2013-12-13   JPunza          Modified to address the error and warning
 *                              messages in the logs. Also add a criteria on
 *                              the main query.
 * 2013-12-17   JPunza          Modified to change the main criteria.
 * 2014-02-12	Neha			IM-044718 Modify main query to retreive SPs
 *								have been disconnected more than 5 days
 * 2014-03-06   Rahul           IM-044718 Modify main query to retreive SPs
 *								where REMOVAL_DTTM <= :processingDateTime
 * 2014-09-25   JHERNA          MGE-CCB009: Updated main selection criteria
 *                              to select only Service Points whose Premise
 *                              CIS Division is for the specified division
 *                              only (Batch Parameter).
 * 2016-01-29  	MPang			Updated for CCB v2.4 compilation.                              
 **************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicTypeValues;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointSourceStatusLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.CaseType;
import com.splwg.ccb.domain.admin.caseType.CharacteristicTypeCaseType;
import com.splwg.ccb.domain.admin.caseType.CharacteristicTypeCaseType_Id;
import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseCreator;
import com.splwg.ccb.domain.todo.toDoCase.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_Id;*/
import com.splwg.ccb.api.lookup.ServicePointStatusLookup;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.caseType.entity.CharacteristicTypeCaseType;
import com.splwg.ccb.domain.admin.caseType.entity.CharacteristicTypeCaseType_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.todo.common.CaseCreator;
import com.splwg.ccb.domain.todo.data.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_Id;
import com.splwg.cm.domain.common.CmWSDLCallToAMRDataBase;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.customMessages.CustomMessages;

//START CHANGE - PSREEKAN - 2016-09-26 - DEFECT#108371
///**
// * @author rgullapall003
// *
// @BatchJob (rerunnable = false, modules = {}, 
// *      softParameters = { @BatchJobSoftParameter (entityName = caseType, name = CASE_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_BDG_NBR_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_SRC_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = CASE_SRC_CHAR_VALUE, required = true, type = string)
// *            , @BatchJobSoftParameter (name = INITIAL_CASE_STATUS, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_SP_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = toDoType, name = CASE_TO_DO_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = unitOfMeasure, name = UOM_CD, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = NBR_DAYS_BEFORE_FOR_PREV_READ, required = true, type = integer)
// *            , @BatchJobSoftParameter (name = NBR_DAYS_BEFORE_FOR_HIST_READ, required = true, type = integer)
// *            , @BatchJobSoftParameter (name = CONSUMPTION_THRESHOLD_VALUE, required = true, type = integer)
// *            , @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity)})
// */
/**
 * @author rgullapall003
 *
 @BatchJob (rerunnable = false, modules = {}, 
 *      softParameters = { @BatchJobSoftParameter (name = MAX-ERRORS, type = integer)
 *      	  ,	@BatchJobSoftParameter (entityName = caseType, name = CASE_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_BDG_NBR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_SRC_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CASE_SRC_CHAR_VALUE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = INITIAL_CASE_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_SP_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = CASE_TO_DO_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = unitOfMeasure, name = UOM_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = NBR_DAYS_BEFORE_FOR_PREV_READ, required = true, type = integer)
 *            , @BatchJobSoftParameter (name = NBR_DAYS_BEFORE_FOR_HIST_READ, required = true, type = integer)
 *            , @BatchJobSoftParameter (name = CONSUMPTION_THRESHOLD_VALUE, required = true, type = integer)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = DISC_FA_TYPE_CD, required = true, type = string)})
 */
//END CHANGE - PSREEKAN - 2016-09-26 - DEFECT#108371
public class CmLockedMeterShowingConsumption_BatchProcess extends
CmLockedMeterShowingConsumption_BatchProcess_Gen {
    
    // JPunza - 2013-12-11 - Start
    //private static CharacteristicType parmBadgeNumCaseCharType;
    //private static CharacteristicType parmCaseSourceCharType;
    //private static CharacteristicType parmCaseSPCharType;
    //private static CaseType parmCaseType = null;
    //private static CaseStatus_Id parmCaseStatusId;
    //private static BigInteger parmMaxErrors = null;
    //private static UnitOfMeasure parmUnitOfMeasure;
    //private static String parmCaseSourceCharValueStr;
    //private static BigInteger parmConsumptionThresholdValue;
    //private static int parmNoOfDaysForPrevRead;
    // Start Add 2014-02-12     Neha IM-044718
    private static int parmNoOfDaysForHistoricalRead;
    // Start Add 2014-02-12     Neha IM-044718
    //private static ToDoType parmToDoType;
    private CharacteristicType parmBadgeNumCaseCharType;
    private CharacteristicType parmCaseSourceCharType;
    private CharacteristicType parmCaseSPCharType;
    private CaseType parmCaseType;
    private String parmCaseSourceCharValueStr;
    private String parmCaseStatusCdStr;
    private BigInteger parmMaxErrors;
    // JPunza - 2013-12-11 - End
    // START ADD - JHERNA - 2014-09-25 - MGE-CCB009
    private CisDivision parmCisDivision;
    // END ADD - JHERNA - 2014-09-25 - MGE-CCB009
    public JobWork getJobWork() {

        // JPunza - 2013-12-11 - Start
        //List<SQLResultRow> servicePointRowList = retrieveServicePointDetails();
        //List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();       
        //
        //if(!servicePointRowList.isEmpty())
        //{
        //
        //    for(SQLResultRow row: servicePointRowList){
        //        ThreadWorkUnit threadUnit = createWorkUnit(row);
        //        workUnits.add(threadUnit);
        //    }
        //}
        PreparedStatement getServicePoints = createPreparedStatement("SELECT SP.SP_ID, M.BADGE_NBR " +
                "FROM CI_SP SP, CI_SP_MTR_HIST SPMH, CI_MTR_CONFIG MC, CI_MTR M " +
                // Start Add 2014-02-12	Neha IM-044718
                ", CI_SA_SP SASP " +
                // End Add 2014-02-12	Neha IM-044718
                "WHERE SP.SP_SRC_STATUS_FLG = :disconnected " +
                // Start Add 2014-02-12	Neha IM-044718
                "AND SASP.SP_ID = SP.SP_ID " + 
                "AND SASP.STOP_DTTM = (SELECT MAX(STOP_DTTM) FROM CI_SA_SP WHERE SP_ID= SP.SP_ID) " + 
                "AND TRUNC(SASP.STOP_DTTM) <= :noDaysThreshold " + 
                // End Add 2014-02-12	Neha IM-044718
				
                // JPunza - 2013-12-13 - Start
                // JPunza - 2013-12-17 - Start
                //"AND EXISTS (SELECT 'X' FROM CI_SA_SP SS, CI_SA SA " + 
                //"   WHERE SS.SP_ID = SP.SP_ID " +
                //"   AND SS.SA_ID = SA.SA_ID " +
                //"   AND SA.SA_STATUS_FLG IN (:stopped, :closed) " +
                //"   AND SA.END_DT < :disconnectDate) " +
                "AND NOT EXISTS (SELECT 'X' FROM CI_SA_SP SS, CI_SA SA " + 
                "   WHERE SS.SP_ID = SP.SP_ID " +
                "   AND SS.SA_ID = SA.SA_ID " +
                "   AND SA.SA_STATUS_FLG IN (:pendingStart, :active, :pendingStop)) " +
                // JPunza - 2013-12-17 - End
                // JPunza - 2013-12-13 - End
                "AND SPMH.SP_ID = SP.SP_ID " +
                "AND (SPMH.REMOVAL_DTTM IS NULL " +
				// Start Change 2014-03-06	Rahul IM-044718
				// "OR SPMH.REMOVAL_DTTM >= :processingDateTime) " +
                "OR SPMH.REMOVAL_DTTM <= :processingDateTime) " +
				// End Change 2014-03-06	Rahul IM-044718
                "AND MC.MTR_CONFIG_ID = SPMH.MTR_CONFIG_ID " +
                "AND EXISTS (SELECT 'X' FROM CI_REG R " +
                "   WHERE R.MTR_ID = MC.MTR_ID " +
                "   AND R.UOM_CD = :uomCd) " +
                // START CHANGE - JHERNA - 2014-09-25 - MGE-CCB009
                //"AND M.MTR_ID = MC.MTR_ID");
        		"AND M.MTR_ID = MC.MTR_ID " +
                "AND EXISTS (SELECT SP3.SP_ID " +
                "        	 FROM CI_SP SP3, CI_PREM PREM3 " + 
                "        	 WHERE SP3.SP_ID = SP.SP_ID " +
                "        	 AND PREM3.PREM_ID = SP3.PREM_ID " +
                "        	 AND PREM3.CIS_DIVISION = :cisDivision " +
              //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
              //  "			 ) ");
        		"			 ) ", getClass().getName());
        	  //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        		// END CHANGE - JHERNA - 2014-09-25 - MGE-CCB009

        getServicePoints.bindLookup("disconnected", ServicePointSourceStatusLookup.constants.DISCONNECTED);      
        getServicePoints.bindEntity("uomCd", getParameters().getUOM_CD());
        getServicePoints.bindDateTime("processingDateTime", getProcessDateTime());
        // Start Add 2014-02-12	Neha IM-044718
        getServicePoints.bindDate("noDaysThreshold", getProcessDateTime().getDate().addDays(parmNoOfDaysForHistoricalRead));
        // End Add 2014-02-12	Neha IM-044718
        
        // JPunza - 2013-12-13 - Start
        // JPunza - 2013-12-17 - Start
        //getServicePoints.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
        //getServicePoints.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
        //getServicePoints.bindDate("disconnectDate", 
        //        getProcessDateTime().getDate().addDays(getParameters().getNBR_DAYS_AFTER_DISCONNECT().negate().intValue()));
        getServicePoints.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
        getServicePoints.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
        getServicePoints.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        // JPunza - 2013-12-17 - End
        // JPunza - 2013-12-13 - End
        // START ADD - JHERNA - 2014-09-25 - MGE-CCB009
        getServicePoints.bindId("cisDivision", parmCisDivision.getId());
        // END ADD - JHERNA - 2014-09-25 - MGE-CCB009
        
        // Build Worklist
        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
            
        QueryIterator<SQLResultRow> iter = getServicePoints.iterate();
        while (iter.hasNext()) {
            SQLResultRow row = iter.next();
            
            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId((ServicePoint_Id) row.getId("SP_ID", ServicePoint.class));
            workUnit.addSupplementalData("BADGE_NBR", row.getString("BADGE_NBR"));
          
            workUnits.add(workUnit);              
        }
        iter.close();  
        getServicePoints.close();        
        // JPunza - 2013-12-11 - End
        
        return createJobWorkForThreadWorkUnitList(workUnits); 
    }

// JPunza - 2013-12-11 - Start    
//    /**
//     * this Method will create the Thread Work Unit for each of the Service Point
//     * Row obtained.
//     * 
//     */
//    private ThreadWorkUnit createWorkUnit(SQLResultRow row){
//
//        ThreadWorkUnit threadUnit = new ThreadWorkUnit();
//        ServicePoint_Id spId = (ServicePoint_Id)row.getId("SP_ID", ServicePoint.class);
//        threadUnit.setPrimaryId(spId);
//        threadUnit.addSupplementalData("MTR_ID",row.getId("MTR_ID",Meter.class));
//        threadUnit.addSupplementalData("BADGE_NBR", row.getString("BADGE_NBR"));
//        threadUnit.addSupplementalData("UOM_CD", row.getString("UOM_CD"));
//        return threadUnit;
//    }
// JPunza - 2013-12-11 - End
    
    /**
     * This method checks if all required Soft Parameters were populated,
     * and all optional Soft Parameters (if populated) are valid.
     * 
     * @param isNewRun - a boolean value
     */
    public void validateSoftParameters(boolean isNewRun){
        
        // JPunza - 2013-12-11 - Start
        //parmNoOfDaysForPrevRead = getParameters().getNBR_DAYS_BEFORE_FOR_PREV_READ().negate().intValue();
        // Start add Neha IM-044718
        parmNoOfDaysForHistoricalRead = getParameters().getNBR_DAYS_BEFORE_FOR_HIST_READ().negate().intValue();
        // End add Neha IM-044718
        //parmCaseType = getParameters().getCASE_TYPE();
        //parmToDoType = getParameters().getCASE_TO_DO_TYPE();
        parmCaseType = getParameters().getCASE_TYPE();
        if (parmCaseType.getPremiseUsage().isNotAllowed()) {
            addError(CustomMessageRepository.nm0038PremiseUsageNotAllowediInCaseType(parmCaseType.getId().getTrimmedValue()));
        }
        // JPunza - 2013-12-11 - End

        parmBadgeNumCaseCharType = getParameters().getCASE_BDG_NBR_CHAR_TYPE();
        validateCharTypeEntity(parmBadgeNumCaseCharType);
        validateCharTypeForCaseType(parmBadgeNumCaseCharType);

        parmCaseSourceCharType = getParameters().getCASE_SRC_CHAR_TYPE();
        validateCharTypeEntity(parmCaseSourceCharType);
        validateCharTypeForCaseType(parmCaseSourceCharType);

        parmCaseSPCharType = getParameters().getCASE_SP_CHAR_TYPE();
        validateCharTypeEntity(parmCaseSPCharType);
        validateCharTypeForCaseType(parmCaseSPCharType);

        // JPunza - 2013-12-11 - Start
        if (parmCaseSourceCharType.getCharacteristicType().isPredefinedValue()) {
        // JPunza - 2013-12-11 - End
            parmCaseSourceCharValueStr = getParameters().getCASE_SRC_CHAR_VALUE();
            CharacteristicValue_Id caseSourceCharValueId = new CharacteristicValue_Id(parmCaseSourceCharType, parmCaseSourceCharValueStr);
            if(isNull(caseSourceCharValueId.getEntity())){
                addError(CustomMessageRepository.nm0038InvalidCharacteristicValue(parmCaseSourceCharValueStr, parmCaseSourceCharType.getId().getTrimmedValue()));
            }
        
        // JPunza - 2013-12-11 - Start
        //parmUnitOfMeasure = getParameters().getUOM_CD();
        //validateCaseTypeAndInitialCaseStatus();
        //
        //parmConsumptionThresholdValue = getParameters().getCONSUMPTION_THRESHOLD_VALUE();
        }
            
        parmCaseStatusCdStr = getParameters().getINITIAL_CASE_STATUS();
        CaseStatus_Id caseStatusId = new CaseStatus_Id(parmCaseType, parmCaseStatusCdStr);
        CaseStatus caseStatus = caseStatusId.getEntity();
        if (isNull(caseStatus)) {              
            addError(CustomMessageRepository.nm0038InvalidCaseStatus(parmCaseStatusCdStr,parmCaseType.getId().getTrimmedValue()));
        }
        if (!(caseStatus.getStatusCondition().isInitial())) {
            addError(CustomMessageRepository.nm0038InvalidInitialCaseStatus(parmCaseStatusCdStr,parmCaseType.getId().getTrimmedValue()));
        }                
        // JPunza - 2013-12-11 - End
        
        parmMaxErrors = getParameters().getSoftMaxErrors();
        // Validates Max Error soft parameter
        if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
            addError(CustomMessageRepository.nm0038MaxErrorCannotBeLessThanZero(parmMaxErrors.toString().trim()));
        }
        
        // START ADD - JHERNA - 2014-09-25 - MGE-CCB009
        // Retrieve New Batch Parameter 140: CIS Division
        parmCisDivision = this.getParameters().getCIS_DIVISION();
        // END ADD - JHERNA - 2014-09-25 - MGE-CCB009
        
        //START ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
     	cmValidateFaTypes();
     	//END ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
    } 
    
    //START ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
 	private void cmValidateFaTypes() {
 		
 		String parm150 = this.getParameters().getDISC_FA_TYPE_CD();
 		String[] splitParms150 = parm150.split(",");
 		for (int x = 0; x < splitParms150.length; x++) {
 			FieldActivityType_Id faTypeID = new FieldActivityType_Id(splitParms150[x].trim());
 			if (isNull(faTypeID.getEntity())) {
 				addError(CustomMessageRepositoryMGE.commBatchParameterInvalid(getParameters().getDISC_FA_TYPE_CD(), splitParms150[x]));
 			}
 		}
 	}
 	//END ADD - PSREEKAN - 2016-09-26 - DEFECT#108371

    /**
     * This Method will validate whether the input parameter Characteristic Type 
     * is valid for the Case Characteristic Entity.
     * @param parmCharType
     */
    private void validateCharTypeEntity(CharacteristicType parmCharType){
        CharacteristicEntityLookup parmEntityLookup = CharacteristicEntityLookup.constants.CASE;
        CharacteristicEntity_Id characteristicEntityId = new CharacteristicEntity_Id(parmCharType, parmEntityLookup);
        if (isNull(characteristicEntityId.getEntity())){
            addError(CustomMessageRepository.nm0038CharTypeInvalidForCharEntity(parmCharType.getId().getIdValue(), parmEntityLookup.getConstantName()));
        } 
    }

    /**
     * This Method will validate whether the input parameter Characteristic Type 
     * is valid for the input Case Type.
     * @param parmCharType
     */
    private void validateCharTypeForCaseType(CharacteristicType parmCharType){
        
        CharacteristicTypeCaseType charTypeCaseType = new CharacteristicTypeCaseType_Id(parmCharType, parmCaseType).getEntity();
        if(isNull(charTypeCaseType)){
            addError(CustomMessageRepository.nm0038InvalidCharTypeForCaseType(parmCharType.getId().getTrimmedValue(), parmCaseType.getId().getTrimmedValue()));
        }
    }

// JPunza - 2013-12-11 - Start
//    /**
//     * This Method will validate the Case Type and the Initial Case Status 
//     * input Parameters.
//     *
//     */
//    private void validateCaseTypeAndInitialCaseStatus(){
//
//        parmCaseType = parmCaseType.getId().getEntity();
//        if(parmCaseType.getPremiseUsage().isNotAllowed()){
//            addError(CustomMessageRepository.nm0038PremiseUsageNotAllowediInCaseType(parmCaseType.getId().getTrimmedValue()));
//        }
//        String parmCaseStatusCdStr = getParameters().getINITIAL_CASE_STATUS();
//        parmCaseStatusId = new CaseStatus_Id(parmCaseType, parmCaseStatusCdStr);
//        if(isNull(parmCaseStatusId.getEntity())){              
//            addError(CustomMessageRepository.nm0038InvalidCaseStatus(parmCaseStatusCdStr,parmCaseType.getId().getTrimmedValue()));
//        }
//        if(!(parmCaseStatusId.getEntity().getStatusCondition().isInitial())){
//            addError(CustomMessageRepository.nm0038InvalidInitialCaseStatus(parmCaseStatusCdStr,parmCaseType.getId().getTrimmedValue()));
//        } 
//    }
//    
//    /**
//     * This Method is used to retrieve all the disconnected Service Points
//     * and has meter installed.
//     * @return SQL Result Row for list of Service Points.
//     */
//    private List<SQLResultRow> retrieveServicePointDetails(){
//
//        StringBuilder servicePointQueryStr = new StringBuilder();
//        servicePointQueryStr.append(" SELECT MTR.MTR_ID, HIST.SP_ID, MTR.BADGE_NBR, RR.UOM_CD ");
//        servicePointQueryStr.append(" FROM CI_MTR MTR, CI_SP_MTR_EVT EVNT, CI_SP SP, CI_MR MR, ");
//        servicePointQueryStr.append(" CI_MTR_CONFIG CONFIG,CI_SP_MTR_HIST HIST,CI_REG RR ");
//        servicePointQueryStr.append(" WHERE HIST.SP_ID = SP.SP_ID ");
//        servicePointQueryStr.append(" AND SP.SP_SRC_STATUS_FLG = :disconnected ");
//        servicePointQueryStr.append(" AND CONFIG.MTR_ID = MTR.MTR_ID ");
//        servicePointQueryStr.append(" AND CONFIG.EFF_DTTM <= :processingDateTime ");
//        servicePointQueryStr.append(" AND EVNT.SP_MTR_EVT_FLG  = :install");
//        servicePointQueryStr.append(" AND HIST.SP_MTR_HIST_ID  = EVNT.SP_MTR_HIST_ID ");
//        servicePointQueryStr.append(" AND EVNT.MR_ID = MR.MR_ID ");
//        servicePointQueryStr.append(" AND MR.READ_DTTM <= :processingDateTime ");
//        servicePointQueryStr.append(" AND HIST.MTR_CONFIG_ID   = CONFIG.MTR_CONFIG_ID ");
//        servicePointQueryStr.append(" AND MTR.MTR_ID = RR.MTR_ID ");
//        servicePointQueryStr.append(" AND RR.UOM_CD = :uomCd ");
//        servicePointQueryStr.append(" AND (HIST.REMOVAL_DTTM  IS NULL ");
//        servicePointQueryStr.append(" OR HIST.REMOVAL_DTTM >= :processingDateTime ) ");
//        PreparedStatement servicePointPrepStmt = createPreparedStatement(servicePointQueryStr.toString());
//        servicePointPrepStmt.bindLookup("disconnected", ServicePointSourceStatusLookup.constants.DISCONNECTED);
//        servicePointPrepStmt.bindId("uomCd", parmUnitOfMeasure.getId());
//        servicePointPrepStmt.bindDateTime("processingDateTime", getProcessDateTime());
//        servicePointPrepStmt.bindLookup("install", ServicePointMeterEventTypeLookup.constants.INSTALL);
//        List<SQLResultRow> servicePointRow = servicePointPrepStmt.list();
//        servicePointPrepStmt.close();
//        return servicePointRow;
//    }
// JPunza - 2013-12-11 - End

    public Class<CmLockedMeterShowingConsumption_BatchProcessWorker> getThreadWorkerClass() {
        return CmLockedMeterShowingConsumption_BatchProcessWorker.class;
    }

    public static class CmLockedMeterShowingConsumption_BatchProcessWorker
    extends CmLockedMeterShowingConsumption_BatchProcessWorker_Gen {

        // JPunza - 2013-12-11 - Start
        // Soft Parameters
        private CharacteristicType parmBadgeNumCaseCharType;
        private CharacteristicType parmCaseSourceCharType;
        private CharacteristicType parmCaseSPCharType;
        private CaseStatus_Id parmCaseStatusId;
        private BigInteger parmConsumptionThresholdValue;
        private String parmCaseSourceCharValueStr;
        private int parmNoOfDaysForPrevRead;
        private int parmNoOfDaysForHistoricalRead;
        // JPunza - 2013-12-11 - End
        
        private ServicePoint_Id spId;
        // JPunza - 2013-12-11 - Start
        //private UnitOfMeasure_Id uomCd;
        //private Premise_Id premiseId;
        //private Meter_Id meterId;
        private Premise_Id premiseId;
        private Message_Id messageId;
        // JPunza - 2013-12-11 - End
        private String badgeNumber;
        private Date processDate;
        private ArrayList <CaseCharacteristic_DTO>  charList = new ArrayList<CaseCharacteristic_DTO>();
        // JPunza - 2013-12-11 - Start
        //private BigInteger intMessageCat; 
        //private BigInteger messageNumber;
        //private User_Id userId;
        // JPunza - 2013-12-11 - End
        private BigInteger noOfCasesCreated;
        private BigInteger noOfToDoEntriesCreated;
        private String strAMRWsdlURL = null;
        
		// START ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
		private List<FieldActivityType_Id> disconnectedFaTypeID = new ArrayList<FieldActivityType_Id>();
		// END ADD - PSREEKAN - 2016-09-26 - DEFECT#108371

        public ThreadExecutionStrategy createExecutionStrategy() {
            // JPunza - 2013-12-11 - Start
            //return new CommitEveryUnitStrategy(this);
            return new StandardCommitStrategy(this);
            // JPunza - 2013-12-11 - End
        }

        public boolean executeWorkUnit(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {

            initializeParameters(unit);

            // JPunza - 2013-12-11 - Start
            //processDate = getProcessDateTime().getDate();
            // JPunza - 2013-12-11 - End

            // JPunza - 2013-12-13 - Start
            //startChanges();
            // JPunza - 2013-12-13 - End
            if(checkIfCaseAlreadyExists().isFalse()){
                int numOfServicePoints = retrieveSPLinkedToPremise(); 
                if(numOfServicePoints > 1){
                    SQLResultRow resultRow = retrieveToDoEntryDetails();
                    if(isNull(resultRow)){
                        createToDoEntry();
                    }
                }else{
                	// START CHANGE - PSREEKAN - 2016-09-26 - DEFECT#108371
//                	if(checkConsumption()){
                	if(!isCompletedDisconnectedFAExists(spId) && checkConsumption()){
                		 createCase();
                	}
                	// END CHANGE - PSREEKAN - 2016-09-26 - DEFECT#108371
                }
            }
            // JPunza - 2013-12-13 - Start
            //saveChanges();
            // JPunza - 2013-12-13 - End
            return true;
        }

        private void initializeParameters(ThreadWorkUnit unit){

            spId = (ServicePoint_Id) unit.getPrimaryId();
            // JPunza - 2013-12-11 - Start
            //meterId = (Meter_Id) unit.getSupplementallData("MTR_ID");
            //badgeNumber = (String) unit.getSupplementallData("BADGE_NBR");
            //String uomCdStr = (String) unit.getSupplementallData("UOM_CD");
            //uomCd = new UnitOfMeasure_Id(uomCdStr);
            // JPunza - 2013-12-13 - Start
            //badgeNumber = (String) unit.getSupplementallData("BADGE_NBR");
            badgeNumber = ((String) unit.getSupplementallData("BADGE_NBR")).trim();
            // JPunza - 2013-12-13 - End
            // JPunza - 2013-12-11 - End
            premiseId = spId.getEntity().getPremise().getId();
        }

        /**
         * This Method is to create the ToDoEntry When following conditions are met
         * Premise linked to the Service Point has more than One Service Point linked. 
         */
        private void createToDoEntry(){

            // JPunza - 2013-12-11 - Start 
            //SQLResultRow defaultRoleResultDetailsRow = retrieveDefaultRole();
            //Role_Id defaultRole = null;
            //if(notNull(defaultRoleResultDetailsRow)){
            //    defaultRole  = (Role_Id) defaultRoleResultDetailsRow.getId("ROLE_ID", Role.class);
            //    if(isNull(defaultRole.getEntity())){
            //        addError(CustomMessageRepository.nm0038NoDefaultToDoRole(parmToDoType.getId().getTrimmedValue()));
            //    }
            //}else{
            //    addError(CustomMessageRepository.nm0038NoDefaultToDoRole(parmToDoType.getId().getTrimmedValue()));
            //}
            //
            ////Message Number and Message Category Number
            //intMessageCat = BigInteger.valueOf(CustomMessages.MESSAGE_CATEGORY);
            //messageNumber = BigInteger.valueOf(CustomMessages.NM0038_TO_DO_ENTRY_CREATED_FOR_SORT_KEY_PREMISE_ID);
            //
            //addToDoEntry(defaultRole);            
            ToDoType toDoType = getParameters().getCASE_TO_DO_TYPE();
            
            ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
            ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();
                        
            toDoEntryDTO.setBatchControlId(getBatchControlId());
            toDoEntryDTO.setBatchNumber(getBatchNumber());            
            toDoEntryDTO.setCreationDateTime(getProcessDateTime());
            toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
            toDoEntryDTO.setToDoTypeId(toDoType.getId());
            toDoEntryDTO.setMessageId(messageId);
                        
            toDoCreator.setToDoDTO(toDoEntryDTO);            
            toDoCreator.addSortKeyValue(toDoType.getSortKeyTypes().iterator().next(), premiseId.getTrimmedValue());
            toDoCreator.addDrillKeyValue(toDoType.getDrillKeyTypes().iterator().next(), premiseId.getTrimmedValue());
            
            toDoCreator.create();
            
            noOfToDoEntriesCreated = noOfToDoEntriesCreated.add(BigInteger.ONE);
            // JPunza - 2013-12-11 - End
        }
        
// JPunza - 2013-12-11 - Start 
//        /**
//         * This Method is used to create the To Do Entry.
//         * @param defaultRole
//         * @param listSortKey
//         * @param listDrillKey
//         */private void addToDoEntry(Role_Id defaultRole){
//
//             MessageCategory messageCatergory = new MessageCategory_Id(intMessageCat).getEntity();
//             Message_Id messageId = new Message_Id(messageCatergory, messageNumber);
//             ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
//             ToDoEntry_DTO entryDto = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
//             entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
//             entryDto.setToDoRoleId(defaultRole);
//             entryDto.setToDoTypeId(parmToDoType.getId());
//             entryDto.setAssignedToUserId(userId);
//             entryDto.setMessageId(messageId);
//             toDoCreator.setToDoDTO(entryDto);
//
//             toDoCreator.addDrillKeyValue(parmToDoType.getId().getEntity().getDrillKeyTypes().iterator().next(), premiseId.getTrimmedValue());
//             toDoCreator.addSortKeyValue(parmToDoType.getId().getEntity().getSortKeyTypes().iterator().next(), premiseId.getTrimmedValue());
//             ToDoEntry toDoEntry = toDoCreator.create();
//
//             noOfToDoEntriesCreated = noOfToDoEntriesCreated.add(BigInteger.ONE);
//
//         }
//        
//         /**
//          * This method will be used to retrieve the Default Role associated to the To Do Type
//          * @return SQLResultRow
//          */
//         private SQLResultRow retrieveDefaultRole() {
//
//             SQLResultRow defaultRoleDetailsRow = null;
//
//             StringBuilder sb = new StringBuilder();
//             sb.append(" SELECT ROLE_ID FROM CI_TD_VAL_ROLE  ");
//             sb.append(" WHERE TD_TYPE_CD = :toDoType ");
//             sb.append(" AND DEFAULT_SW = :defaultSw ");
//
//             PreparedStatement ps = createPreparedStatement(sb.toString());
//             ps.bindEntity("toDoType", parmToDoType);
//             ps.bindBoolean("defaultSw", Bool.TRUE);
//
//             defaultRoleDetailsRow = ps.firstRow();
//
//             ps.close();
//             return defaultRoleDetailsRow;
//         }
// JPunza - 2013-12-11 - End  
         
         /**
          * This Method is used to create the Case if the Consumption exceeds the threshold value
          * and the premise is not linked to more than one Service Points.
          * 
          */
         private void createCase(){

             // JPunza - 2013-12-11 - Start
             //retrieveUserAuthLevelDetails();
             // JPunza - 2013-12-11 - End
             charList.clear();
             ToDoCase_DTO toDoCaseDTO = (ToDoCase_DTO) createDTO(ToDoCase.class);
             // JPunza - 2013-12-11 - Start
             //// To avoid lazy initialization reinitialize case type
             //parmCaseType = parmCaseType.getId().getEntity();
             // JPunza - 2013-12-11 - End
             toDoCaseDTO.setCaseStatusId(parmCaseStatusId);
             toDoCaseDTO.setPremiseId(premiseId);
             // JPunza - 2013-12-11 - Start
             //toDoCaseDTO.setUserId(userId);
             toDoCaseDTO.setUserId(getActiveContextUser().getId());
             // JPunza - 2013-12-11 - End

             if(!addCharacteristic(ToDoCase_Id.NULL, parmBadgeNumCaseCharType, badgeNumber)){
                 return;
             }
             if(!addCharacteristic(ToDoCase_Id.NULL, parmCaseSourceCharType, parmCaseSourceCharValueStr)){
                 return;
             }
             if(!addCharacteristic(ToDoCase_Id.NULL, parmCaseSPCharType, spId.getTrimmedValue())){
                 return;
             }

             CaseCreatorData caseCreatorData = CaseCreatorData.Factory.newInstance();
             caseCreatorData.setToDoCaseDTO(toDoCaseDTO); 
             caseCreatorData.setCaseCharacteristics(charList);
             CaseCreator caseCreator = CaseCreator.Factory.newInstance();

             caseCreatorData = caseCreator.createCase(caseCreatorData);
             noOfCasesCreated = noOfCasesCreated.add(BigInteger.ONE);

         }

// JPunza - 2013-12-11 - Start
//         /**
//          * This Method will retrieve the active Context User_Id
//          */
//         private void retrieveUserAuthLevelDetails() {
//
//             userId = getParameters().getUserId();
//             if(isNull(userId)){
//                 addError(CustomMessageRepository.nm0038UserIdCannotBeBlank());
//             }
//
//             if(isNull(userId.getEntity())){
//
//                 addError(CustomMessageRepository.nm0038InvalidUserValue(userId.getTrimmedValue()));
//             }
//         }
// JPunza - 2013-12-11 - End

         /**
          * This Method is used to add a characteristic Value to the Case.
          * @param caseId
          * @param charType
          * @param charVal
          * @return
          */private boolean addCharacteristic(ToDoCase_Id caseId, CharacteristicType charType, String charVal){
              CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

              if(isBlankOrNull(charVal)){                
                  return true;
              }

              if(charTypeLookup.isPredefinedValue()){
                  boolean validCharVal = false;

                  // validate char value
                  CharacteristicTypeValues charTypeValues = charType.getId().getEntity().getValues();  // re-initialize to avoid lazy initialization
                  for(CharacteristicValue charValIter : charTypeValues){
                      if(charValIter.fetchIdCharacteristicValue().trim().compareTo(charVal.trim()) == 0){
                          validCharVal = true;
                          break;
                      }   
                  }
                  if(!validCharVal){
                      // log an error in batch run tree
                      logError(CustomMessageRepository.nm0038InvalidCharacteristicValue(charVal, charType.getId().getTrimmedValue()));
                      return false;
                  }
              } 

              CaseCharacteristic_DTO caseCharacteristicDTO;
              CaseCharacteristic_Id caseCharacteristicId = new CaseCharacteristic_Id(charType.getId(), caseId, BigInteger.ONE);            
              caseCharacteristicDTO = caseCharacteristicId.newDTO();

              if(charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()){
                  caseCharacteristicDTO.setAdhocCharacteristicValue(charVal);
              } else if (charTypeLookup.isPredefinedValue()){
                  caseCharacteristicDTO.setCharacteristicValue(charVal);
              } else if (charTypeLookup.isForeignKeyValue()){
                  caseCharacteristicDTO.setCharacteristicValueForeignKey1(charVal);
              }
              charList.add(caseCharacteristicDTO);
              return true;
          }

          /**
           * This Method will calculate the Consumption of the given meter in between the 
           * given time period and will check whether it exceeds the input threshold value. 
           * @return consumption exceeds the threshold value or not.
           */
          private Boolean checkConsumption(){

              BigDecimal previousRead = retrieveMeterRead(processDate.addDays(parmNoOfDaysForPrevRead));
              if(isNull(previousRead)){
                  // JPunza - 2013-12-13 - Start
                  //logWarning(CustomMessageRepository.nm0038AmrReadNotFound(badgeNumber,spId.getIdValue(),(processDate.addDays(parmNoOfDaysForPrevRead)).toString()));
                  // JPunza - 2013-12-13 - End
                  return false;
              }
              BigDecimal historicalRead = retrieveMeterRead(processDate.addDays(parmNoOfDaysForHistoricalRead));
              if(isNull(historicalRead)){
                  // JPunza - 2013-12-13 - Start
                  //logWarning(CustomMessageRepository.nm0038AmrReadNotFound(badgeNumber,spId.getIdValue(),(processDate.addDays(parmNoOfDaysForHistoricalRead)).toString()));
                  // JPunza - 2013-12-13 - End
                  return false;
              }
              
              BigDecimal readsDifference = previousRead.subtract(historicalRead);
              if(readsDifference.toBigInteger().compareTo(parmConsumptionThresholdValue) >= 0 ){
                  return true;
              }else{
                  return false;
              }
          }

          /**
           * This method will retrieve the Meter Read from the daily meter read database
           * using the input business service.
           * @param readDate
           * @return
           */
          private BigDecimal retrieveMeterRead(Date readDate){
           //SD20130606 - Web Service Invocation.
           // Only Corrected read will be used.This is because from the Batch parameter and Register UOM, Corrected/Uncorrected cannot be determined
           // and Web Service does not Provide the UOM in response.
           // Alternative would be to match the Batch Param UOM with the Feature Config and determine if this is Corrected/Uncorrected.
              
            BigDecimal amrCorrectedRead;
            CmWSDLCallToAMRDataBase wsdlComp = CmWSDLCallToAMRDataBase.Factory.newInstance();
            if(isNull(strAMRWsdlURL)){
                strAMRWsdlURL = wsdlComp.getWsdlURLForAMRReads();
                if(isNull(strAMRWsdlURL)){
                  addError(wsdlComp.getServerMessage());
                }
            }
            wsdlComp.setWsdlURL(strAMRWsdlURL);
            wsdlComp.setInputBadgeNumber(badgeNumber);
            wsdlComp.setInputSpId(spId);
            wsdlComp.setInputReadDate(readDate);
            try{
                wsdlComp.retreiveReadDetailsFromAMR();
            }catch(UnknownHostException uhe){
                throw new RunAbortedException(CustomMessageRepository.webServiceHostUnreachable(uhe.getMessage()));
            }catch(Exception excp){
                throw new RunAbortedException(CustomMessageRepository.errorInvokingAMRWebService(excp.getMessage()));
            }
            amrCorrectedRead = wsdlComp.getAmrCorrectedRead();
            return amrCorrectedRead;

          }

          /**
           * This method will retrieve the number of Service Points
           * linked to the Premise.  
           * @return number of Service Points linked to the Premise.
           */
          private int retrieveSPLinkedToPremise(){

              StringBuilder numOfSPForPremiseQueryStr = new StringBuilder();
              numOfSPForPremiseQueryStr.append(" SELECT COUNT('X') AS COUNT ");
              numOfSPForPremiseQueryStr.append(" FROM CI_SP ");
              numOfSPForPremiseQueryStr.append(" WHERE PREM_ID = :premiseId ");
              //START ADD - PSREEKAN - 2016-09-26 - DEFECT#6637
              numOfSPForPremiseQueryStr.append(" AND SP_STATUS_FLG <> :servicePointStatus ");
              //END ADD - PSREEKAN - 2016-09-26 - DEFECT#6637
              //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
              //PreparedStatement numOfSPForPremiseStmt = createPreparedStatement(numOfSPForPremiseQueryStr.toString());
              PreparedStatement numOfSPForPremiseStmt = createPreparedStatement(numOfSPForPremiseQueryStr.toString(), getClass().getName());
              //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
              numOfSPForPremiseStmt.bindId("premiseId", premiseId);
              //START ADD - PSREEKAN - 2016-09-26 - DEFECT#6637
              numOfSPForPremiseStmt.bindLookup("servicePointStatus", ServicePointStatusLookup.constants.ABOLISHED);
              //START ADD - PSREEKAN - 2016-09-26 - DEFECT#6637
              SQLResultRow numOfSPForPremiseRow = numOfSPForPremiseStmt.firstRow();
              numOfSPForPremiseStmt.close();
              int numOfSP = numOfSPForPremiseRow.getBigDecimal("COUNT").intValue();

              return numOfSP;
          }

          /**
           * This Method will check whether there are any Open To Do entries present 
           * against the Premise. 
           * 
           */
          private SQLResultRow retrieveToDoEntryDetails(){

              StringBuilder toDoEntryDetailsStr = new StringBuilder();
              toDoEntryDetailsStr.append("SELECT TODOENTRY.TD_ENTRY_ID ");
              toDoEntryDetailsStr.append(" FROM CI_TD_ENTRY TODOENTRY, CI_TD_DRLKEY DRILKEY ");
              toDoEntryDetailsStr.append("  WHERE TODOENTRY.TD_TYPE_CD = :toDoTypeCd ");
              toDoEntryDetailsStr.append("      AND TODOENTRY.ENTRY_STATUS_FLG <> :completeStatus ");
              toDoEntryDetailsStr.append("      AND DRILKEY.TD_ENTRY_ID = TODOENTRY.TD_ENTRY_ID ");
              toDoEntryDetailsStr.append("      AND trim(DRILKEY.KEY_VALUE) = :premiseId ");
              toDoEntryDetailsStr.append("  ORDER BY CRE_DTTM DESC ");
              //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
              //PreparedStatement toDoEntryDetailsPrepStmt = createPreparedStatement(toDoEntryDetailsStr.toString());
              PreparedStatement toDoEntryDetailsPrepStmt = createPreparedStatement(toDoEntryDetailsStr.toString(), getClass().getName());
              //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
              // JPunza - 2013-12-11 - Start
              //toDoEntryDetailsPrepStmt.bindId("toDoTypeCd", parmToDoType.getId());
              toDoEntryDetailsPrepStmt.bindEntity("toDoTypeCd", getParameters().getCASE_TO_DO_TYPE());
              // JPunza - 2013-12-11 - End
              toDoEntryDetailsPrepStmt.bindLookup("completeStatus", ToDoEntryStatusLookup.constants.COMPLETED);
              toDoEntryDetailsPrepStmt.bindStringProperty("premiseId", ToDoDrillKeyValue.properties.keyValue, premiseId.getTrimmedValue());

              SQLResultRow toDoEntryResultRow = toDoEntryDetailsPrepStmt.firstRow();
              toDoEntryDetailsPrepStmt.close();

              return toDoEntryResultRow;
          }        

          /**
           * This Method will check whether there is any Open Case present 
           * against the Premise, If Yes, return True else False.
           * 
           */
          private Bool checkIfCaseAlreadyExists(){

              StringBuilder caseQueryStr = new StringBuilder();
              caseQueryStr.append(" SELECT 'X' ");
              caseQueryStr.append(" FROM CI_CASE ");
              caseQueryStr.append(" WHERE CASE_TYPE_CD = :caseType ");
              caseQueryStr.append(" AND CASE_COND_FLG = :open ");
              caseQueryStr.append(" AND PREM_ID = :premiseId ");
              //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
              //PreparedStatement caseQueryPrepStmt = createPreparedStatement(caseQueryStr.toString());
              PreparedStatement caseQueryPrepStmt = createPreparedStatement(caseQueryStr.toString(), getClass().getName());
              //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
              // JPunza - 2013-12-11 - Start
              //caseQueryPrepStmt.bindId("caseType", parmCaseType.getId());
              caseQueryPrepStmt.bindEntity("caseType", getParameters().getCASE_TYPE());
              // JPunza - 2013-12-11 - End
              caseQueryPrepStmt.bindLookup("open", CaseConditionLookup.constants.OPEN);
              caseQueryPrepStmt.bindId("premiseId", premiseId);
              SQLResultRow caseQueryResultRow = caseQueryPrepStmt.firstRow();
              caseQueryPrepStmt.close();
              if(notNull(caseQueryResultRow)){
                  return Bool.TRUE;
              }else{
                  return Bool.FALSE;
              }
          }

          /* (non-Javadoc)
           * @see com.splwg.base.api.batch.AbstractThreadWorker#initializeThreadWork(boolean)
           */
          @Override
          public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
              noOfCasesCreated = BigInteger.ZERO;
              noOfToDoEntriesCreated = BigInteger.ZERO;

              // JPunza - 2013-12-11 - Start
              // Soft Parameters
              parmBadgeNumCaseCharType = getParameters().getCASE_BDG_NBR_CHAR_TYPE();
              parmCaseSourceCharType = getParameters().getCASE_SRC_CHAR_TYPE();
              parmCaseSourceCharValueStr = getParameters().getCASE_SRC_CHAR_VALUE();
              parmCaseSPCharType = getParameters().getCASE_SP_CHAR_TYPE();              
              parmNoOfDaysForPrevRead = getParameters().getNBR_DAYS_BEFORE_FOR_PREV_READ().negate().intValue();
              parmNoOfDaysForHistoricalRead = getParameters().getNBR_DAYS_BEFORE_FOR_HIST_READ().negate().intValue();
              parmConsumptionThresholdValue = getParameters().getCONSUMPTION_THRESHOLD_VALUE();
              
              parmCaseStatusId = new CaseStatus_Id(getParameters().getCASE_TYPE(), getParameters().getINITIAL_CASE_STATUS());
              processDate = getProcessDateTime().getDate();
              messageId = new Message_Id(new MessageCategory_Id(BigInteger.valueOf(CustomMessages.MESSAGE_CATEGORY)), 
                      BigInteger.valueOf(CustomMessages.NM0038_TO_DO_ENTRY_CREATED_FOR_SORT_KEY_PREMISE_ID));
              // JPunza - 2013-12-11 - End
              
              //START ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
  			  cmRetrieveDisconnectedFaTypes();
  			  //END ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
          }

          	// START ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
			private void cmRetrieveDisconnectedFaTypes() {
	
				String parm100 = this.getParameters().getDISC_FA_TYPE_CD();
				String[] splitParms = parm100.split(",");
				for (int x = 0; x < splitParms.length; x++) {
					FieldActivityType_Id faTypeID = new FieldActivityType_Id(
							splitParms[x].trim());
					disconnectedFaTypeID.add(faTypeID);
				}
			}
			// END ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
			
			//START ADD - PSREEKAN - 2016-09-26 - DEFECT#108371
			private boolean isCompletedDisconnectedFAExists(ServicePoint_Id spID) {
				
				boolean returnValue = false;
				String disconnectFATypes = "";
				Iterator<FieldActivityType_Id> iter = disconnectedFaTypeID.iterator();
				while (iter.hasNext()) {
					FieldActivityType_Id faTypeID = iter.next();
					disconnectFATypes = disconnectFATypes.concat("'");
					disconnectFATypes = disconnectFATypes.concat(faTypeID.getTrimmedValue());
					disconnectFATypes = disconnectFATypes.concat("'");
					disconnectFATypes = disconnectFATypes.concat(",");
				}
				disconnectFATypes = disconnectFATypes.substring(0, disconnectFATypes.length() - 1);
				
				// Find the completed disconnect FA for the SP
				StringBuilder stringBuilder = new StringBuilder();		
				stringBuilder.append(" SELECT FA.FA_ID");
				stringBuilder.append(" FROM CI_FA FA");
				stringBuilder.append(" WHERE FA.SP_ID = :spID ");
				stringBuilder.append(" AND FA.FA_TYPE_CD IN ( ");
				stringBuilder.append("                      "+disconnectFATypes+" ");
				stringBuilder.append("                      ) ");						
				stringBuilder.append(" AND FA.FA_STATUS_FLG = :faStatus ");
				stringBuilder.append(" AND FA.SCHED_DTTM >= :startReadDateTime ");
				stringBuilder.append(" AND FA.SCHED_DTTM <= :stopReadDateTime ");

				PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
				prepState.bindId("spID", spID);
				prepState.bindLookup("faStatus", FieldActivityStatusLookup.constants.COMPLETED);
				prepState.bindDateTime("startReadDateTime", getSystemDateTime().addDays(-parmNoOfDaysForHistoricalRead));
				prepState.bindDateTime("stopReadDateTime", getSystemDateTime());
				prepState.execute();
				
				if(notNull(prepState.firstRow())){
					
					returnValue = true;
				}
				prepState.close();
				return returnValue;
			}
			//END ADD - PSREEKAN - 2016-09-26 - DEFECT#108371

          @Override
          public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {

              logInfo(CustomMessageRepository.nm0038NoOfCaseCreated(noOfCasesCreated.toString()));
              logInfo(CustomMessageRepository.nm0038NoOfToDoEntriesCreated(noOfToDoEntriesCreated.toString()));
          }
    }

}
