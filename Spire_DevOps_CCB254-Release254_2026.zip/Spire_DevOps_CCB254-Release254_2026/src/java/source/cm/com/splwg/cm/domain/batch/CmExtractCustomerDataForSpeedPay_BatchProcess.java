/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Customer Data Extract Batch for SpeedPay
 * 
 * This batch will extract customer data for SpeedPay.
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                                                                
 * 2021-05-21  JVitug      CCB031.2 Initial Version     
 * 2021-06-24  GCrisp	   CCB031.Issue1. Allow multithreading and add
 *						   the thread number at the end of the file 
 *						   name before the file extension.
 * 						   Add null checker for Account's Billing 
 *						   Premise ID. 
 *******************************************************************************
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.text.DecimalFormat;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_Id;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_LanguageId;
import com.splwg.ccb.api.lookup.BillingAddressSourceLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage;
import com.splwg.ccb.domain.common.installation.CcbInstallationHelper;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.data.AccountMailingAddressData;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.cm.api.batch.CmCustomerDataRecordForSpeedPay;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author JVitug
 *
@BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision , name = CIS_DIVISION, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = BILL_MSG_CD_LIST, required = true, type = string)})
 */
public class CmExtractCustomerDataForSpeedPay_BatchProcess extends
	CmExtractCustomerDataForSpeedPay_BatchProcess_Gen {
	
    // Constants
    private static final String COMMA = ",";
    
    //Soft Parameters
    private CisDivision cisDivision;
    
    @Override
	public void validateSoftParameters(boolean isNewRun) {
        //Get all the soft parameters
    	String filePath = getParameters().getFILE_PATH();
    	String billMessages = getParameters().getBILL_MSG_CD_LIST();
    	cisDivision = getParameters().getCIS_DIVISION();
    	
    	// Validate that File Path is a valid directory
    	File file = new File(filePath);
    	if (!file.isDirectory()){
            addError(CustomMessageRepositorySpireOne.CCB031_2_batchParmInvalidFilePath(getBatchParameterName(10), filePath));
        }
    	
    	//Validate that each entry in the phone type list which is delimited by comma is a valid phone type
    	String[] billMessageList = billMessages.split(COMMA);
    	BillMessageType billMessage;
    	
    	for(int i = 0 ; i < billMessageList.length ; i++) {
    		billMessage = new BillMessageType_Id(billMessageList[i].trim()).getEntity();
    		
    		if(isNull(billMessage)) {
    			addError(CustomMessageRepositorySpireOne.CCB031_2_batchParmInvalidBillMessageType(getBatchParameterName(40) , billMessageList[i]));
    		}
    	}
	}
    
    /**
     * This method will return the batch parameter name given the sequence number input
     * @param numSeq
     * @return
     */
    private String getBatchParameterName(int numSeq){

        String parmName = "";
        
        BatchControlParameter_Id batchControlParameter_Id = 
                new BatchControlParameter_Id(this.getBatchControlId(), BigInteger.valueOf(numSeq));        
        BatchControlParameter_LanguageId batchControlParameterLanguageId = 
                new BatchControlParameter_LanguageId(batchControlParameter_Id, getActiveContextLanguage().getId());
        parmName = batchControlParameterLanguageId.getParent().fetchLanguageDescription();
        
        return parmName;
    }

    @Override
	public JobWork getJobWork() {
		StringBuilder stringSql = new StringBuilder();
		
		stringSql.append("SELECT ");
		stringSql.append(   "ACCT.ACCT_ID ");
		stringSql.append("FROM ");
		stringSql.append(   "CI_ACCT ACCT ");
		stringSql.append("WHERE ");
		stringSql.append(   "ACCT.CIS_DIVISION = :cisDivision ");
		stringSql.append("AND ");
		stringSql.append(   "EXISTS ( ");
		stringSql.append(      "SELECT ");
		stringSql.append(         "'X' ");
		stringSql.append(      "FROM ");
		stringSql.append(         "CI_SA SA ");
		stringSql.append(      "WHERE ");
		stringSql.append(         "SA.ACCT_ID = ACCT.ACCT_ID ");
		stringSql.append(      "AND ");
		stringSql.append(         "SA.CIS_DIVISION = ACCT.CIS_DIVISION ");
		stringSql.append(      "AND ");
		stringSql.append(         "SA.SA_STATUS_FLG < :closed ");
		stringSql.append(   ") ");
		
		PreparedStatement getMainPreparedStatement = createPreparedStatement(stringSql.toString(), getClass().getName());
		getMainPreparedStatement.bindId("cisDivision" , cisDivision.getId());
		getMainPreparedStatement.bindLookup("closed" , ServiceAgreementStatusLookup.constants.CLOSED);
		
		QueryIterator iterator = getMainPreparedStatement.iterate();
		
		return createJobWorkForQueryIterator(iterator, this);	
    }
	
    @Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow queryResultRow) {
    
    	String accountIdString = (String) queryResultRow.get("ACCT_ID");
    	Account_Id accountId = new Account_Id(accountIdString);
    	
    	ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
    	threadWorkUnit.setPrimaryId(accountId);
    	
    	return threadWorkUnit;
	}

	public Class<CmExtractCustomerDataForSpeedPay_BatchProcessWorker> getThreadWorkerClass() {
        return CmExtractCustomerDataForSpeedPay_BatchProcessWorker.class;
    }

    public static class CmExtractCustomerDataForSpeedPay_BatchProcessWorker extends
    CmExtractCustomerDataForSpeedPay_BatchProcessWorker_Gen {
    	
        // Constant
    	private static final String COMMA = ",";
    	private static final String SPACE = " ";
        
        //Working Variables
        Account account;
        Person mainPerson;
        private File extractFile;
        private BufferedWriter extractFileWriter;
        private DateFormat dateFormat = new DateFormat("yyyyMMdd");
        private List<String> billMessageList;
        
        //Customer Information
        private String customerName;
        
        //Premise Details
        String houseNumber;
        String streetName;
        String city;
        String postalCode; 
        
        //DNP details
        String pendingDNP;
        String cashOnly;
        String dnpForecast;
        String currentBalance;
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new SingleTransactionStrategy(this);
        }     

        @Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
        	
        	// Retrieve parameters. Also retrieve the other parameters to prevent lazy initialization exception
        	String filePath = getParameters().getFILE_PATH();
        	String fileName = getParameters().getFILE_NAME();
        	String billMessages = getParameters().getBILL_MSG_CD_LIST();
        	
        	billMessageList = new ArrayList<String>();
        	for (String billMessageStr : billMessages.split(COMMA)) {
        		billMessageList.add(billMessageStr.trim());
            }
			
			// Start Add - GCrisp - 06-24-2021 - CCB031.Issue1
			//Add Batch thread number at the end of the file name before the file extension
			DecimalFormat decimalFormat = new DecimalFormat("00");
			int periodIndex = fileName.lastIndexOf('.');
			//If filename has file extension
			if(periodIndex > 0){
				String fileNameWithoutFileExtension = fileName.substring(0, fileName.lastIndexOf('.'));
				String fileExtension = fileName.substring(fileName.lastIndexOf('.')).trim();
				
				fileName = fileNameWithoutFileExtension.trim()
						.concat(decimalFormat.format(getBatchThreadNumber()).trim().concat(fileExtension));
			//If filename has no file extension
			} else{
				fileName = fileName.trim()
						.concat(decimalFormat.format(getBatchThreadNumber()).trim());
			}
			// End Add - GCrisp - 06-24-2021 - CCB031.Issue1
        	
            // Open Extract File
            try {
            	extractFile = new File(filePath,fileName);   
            	extractFileWriter = new BufferedWriter(new FileWriter(extractFile));     
            }
            catch(Exception e) {
                throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB031_2_errorInOpeningFile(extractFile.getAbsolutePath()));
            }

		}

        @Override
        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
        	
        	Account_Id accountId = (Account_Id) unit.getPrimaryId();
        	account = accountId.getEntity();
        	
        	//Reset values of working variables
        	initializeWorkingVariables();
        	// Write Information to extract file
        	writeInformationToExtractFile(account);

            return true;
        }
        
        /**
         * This method will initialize the working variables
         */
        private void initializeWorkingVariables() { 
        	//Customer Information 
        	customerName = "";
        	
        	//Premise Details
        	houseNumber = "" ;
        	streetName = "" ;
        	city = "" ;
        	postalCode = "" ; 

        	//DNP details
        	pendingDNP = "N" ;
        	cashOnly = "N" ;
        	dnpForecast = "" ;
        	currentBalance = "" ;
        	
        	//Get the main person of the account
        	mainPerson = account.getMainPerson();
        }
                        
        
        /**
         * This method will write information retrieved to extract file
         */
        private void writeInformationToExtractFile(Account account) {
        	CmCustomerDataRecordForSpeedPay record = new CmCustomerDataRecordForSpeedPay();
        	
        	prepareCustomerInformation(mainPerson);
        	preparePremiseInformation(account);
        	prepareDNPInformation(account);
        	
        	record.setAccount(account.getId().getTrimmedValue());
        	record.setCustomerName(customerName);
        	record.setHouseNumber(houseNumber);
        	record.setStreetName(streetName);
        	record.setCity(city);
        	record.setPostalCode(postalCode);
        	
        	//Currently , alternate addresses are not used so we use spaces
        	record.setAlternateStreet(SPACE);
        	record.setAlternateCity(SPACE);
        	record.setAlternateState(SPACE);
        	record.setAlternatePostalCode(SPACE);
        	
        	//DNP records
        	record.setPendingDNP(pendingDNP);
        	record.setCashOnly(cashOnly);
        	record.setDNPForecase(dnpForecast);
        	record.setCurrentBalance(currentBalance);
        	
            try {
            	extractFileWriter.write(record.createRecordString());
            	extractFileWriter.newLine();
            }
            catch (Exception e) {
                throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB031_2_errorInWritingToFile(extractFile.getAbsolutePath()));
            }
        }      
        
        /**
         * Prepare the customer information
         * @param mainPerson
         */
        private void prepareCustomerInformation(Person mainPerson) {
			customerName = mainPerson.getPersonPrimaryName().trim();
			if(mainPerson.getPersonOrBusiness().isPerson()){
        		//Split the primary name using comma
        		//this results to an array whose first element is the surname and the last element is the first name
        		String[] entityName = customerName.split(COMMA);
        		
        		if(entityName.length == 2) {
	        		//Store the customer Name in First Name , Last Name format.
	        		customerName = entityName[1].trim().concat(SPACE).concat(entityName[0].trim());
        		}
        	}
        }

        /**
         * This method will prepare the needed premise information for the Customer Data Extract
         * @param account
         */
        private void preparePremiseInformation(Account account) {			
			// Start Change - GCrisp - 06-24-2021 - CCB031.Issue1
        	//AccountMailingAddressData mailingAddress = account.fetchMailingAddress(mainPerson);
			AccountPerson acctPer = new AccountPerson_Id(mainPerson, account).getEntity();
			AccountMailingAddressData mailingAddress;
			if(isNull(account.getMailingPremiseId()) &&
					acctPer.getBillAddressSource().equals(BillingAddressSourceLookup.constants.MAILING_PREMISE_ON_ACCOUNT)){
				mailingAddress = null;
			} else{
				mailingAddress = account.fetchMailingAddress(mainPerson);
			}
			// End Change - GCrisp - 06-24-2021 - CCB031.Issue1
        	if(notNull(mailingAddress)) {
        		if(notNull(mailingAddress.getAddress1())) {
        			String[] address1Details = mailingAddress.getAddress1().split(SPACE);
                	
                	houseNumber =  address1Details[0].trim();
					// Start Change - GCrisp - 06-24-2021 - CCB031.Issue1
					//Check if address contains a space first to avoid error
                	//street name is the entirety of the address1 field without the house number
					//streetName = mailingAddress.getAddress1().substring(mailingAddress.getAddress1().indexOf(SPACE)).trim();
					int spaceIndex = mailingAddress.getAddress1().indexOf(SPACE);
					if(spaceIndex > 0){
						streetName = mailingAddress.getAddress1().substring(mailingAddress.getAddress1().indexOf(SPACE)).trim();
					}
                	// End Change - GCrisp - 06-24-2021 - CCB031.Issue1
        		}
        		
        		if(notNull(mailingAddress.getCity())) {
        			city = mailingAddress.getCity().trim();
        		}
        		
        		if(notNull(mailingAddress.getPostalCode())) {
        			postalCode = mailingAddress.getPostalCode().trim();
        		}
        	}
        }
        
        /**
         * This method will prepare the information for DNP Details 
         */
        private void prepareDNPInformation(Account account) {
        	//Get the latest bill of the account
        	Bill latestBill = account.getLatestCompletedBill();
        	
        	// If the latest bill of the account has a bill message type equal to the
        	// bill messages defined in the Bill message list parameter, set 
        	// pendingDNP to 'Y'
        	if(notNull(latestBill)) {
        		for(BillMessage billMessage : latestBill.getMessages()) {
        			if(billMessageList.contains(billMessage.fetchIdBillMessage().getId().getTrimmedValue())) {
        				pendingDNP = "Y";
        				break;
        			}
        		}
        		
        		//DNP Forecast is the latest bill's due date in YYYYMMDD format
            	dnpForecast = latestBill.getDueDate().toString(dateFormat);
        	}
        	
        	//CashOnly Flag. customer's current Cash Only Score exceeds 
        	// (greater than) the threshold in the installation options
        	Date processDate = getProcessDateTime().getDate();
        	BigInteger cashOnlyThreshold = CcbInstallationHelper.getCcbInstallationInstance().getCashOnlyThreshold();
			BigInteger accountCashOnlyPoints = account.getCreditRatingInfo(processDate).getCashOnlyPoints();
			if(accountCashOnlyPoints.compareTo(cashOnlyThreshold) > 0) {
				cashOnly = "Y";
			}
        	
        	//Set current balance to the current balance of the account
        	currentBalance = account.getFinancialBalances(processDate, processDate).getCurrentAmount().getAmount().toString();
        }
        
		@Override 
		public void finalizeThreadWork() throws ThreadAbortedException,
				RunAbortedException {
            // Close Extract File
            try {
            	extractFileWriter.close();    
            }
            catch(Exception e) {
                e.printStackTrace();
                throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB031_2_errorInClosingFile(extractFile.getAbsolutePath()));
            }
		}            
    }
}
