/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Whenever a service initiates a stop, this program will update the
 * account's mailing premise with the account's latest remaining active
 * service agreement's premise if there is one.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2020-03-24   JHERNA  SysAid#322461. Initial Version.
 * 2020-05-04	JHERNA	SysAid#332847. takes into consideration when account 
 *                      for some reason does not have mailing premise id 
 * 
 **************************************************************************/
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.initiateStopSa;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.initiateStopSa.SaTypeInitiateStopSaAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;


/**
 * @author blu02772
 *
@AlgorithmComponent ()
 */
public class CmUpdateAccountMailingPremiseOnStopServiceAlgComp_Impl 
		extends CmUpdateAccountMailingPremiseOnStopServiceAlgComp_Gen 
		implements SaTypeInitiateStopSaAlgorithmSpot {


	// Hard Parameters
	@SuppressWarnings("unused")
	private Bool hpShouldCreateFA;
	@SuppressWarnings("unused")
	private Date hpStopDate;
	@SuppressWarnings("unused")
	private Premise hpPremise;
	private ServiceAgreement hpSA;
	private ServiceType hpServiceType;			
	@SuppressWarnings("unused")
	private String hpRevertToLandLord, hpStopRequestedBy;
	
	// Soft Parameters
	
	/* *************************
	 * Getter / Setter Methods *
	 * for hard parameters     *
	 * *************************/
	
	@Override
	public ServiceType getServiceType() {
		return hpServiceType;
	}

	@Override
	public void setPremise(Premise arg0) {
		hpPremise = arg0;
	}

	@Override
	public void setRevertToLandlord(String arg0) {
		hpRevertToLandLord = arg0;
	}

	@Override
	public void setServiceAgreement(ServiceAgreement arg0) {
		hpSA = arg0;
	}

	@Override
	public void setServiceType(ServiceType arg0) {
		hpServiceType = arg0;
	}

	@Override
	public void setShouldCreateFieldActivity(Bool arg0) {
		hpShouldCreateFA = arg0;
	}

	@Override
	public void setStopDate(Date arg0) {
		hpStopDate = arg0;
	}

	@Override
	public void setStopRequestedBy(String arg0) {
		hpStopRequestedBy = arg0;
	}

	/* *************
	 * Main Method *
	 * *************/
	@Override
	public void invoke() {
		
		Account acct = hpSA.getAccount();
		Premise_Id latestPremID = getLatestActiveSAsPremise(acct.getId());

		// START CHANGES - JHERNA - 2020-05-04 - SysAid#332847
		// Update the account's mailing premise when the latest premise from an active SA is different from the current account mailing premise	
//		if (notNull(latestPremID)
//				&& acct.getMailingPremiseId().compareTo(latestPremID) != 0		
		
		/* 
		 * If account does not have mailing premise id and there 
		 * is a latest active service premise retrieved, 
		 * proceed with updating account's mailing premise id.
		 * 
		 * If account has a mailing premise, there is a latest 
		 * active service premise retrieved which is different 
		 * from the current account mailing premise id, 
		 * proceed with the update
		 */
		if ((isNull(acct.getMailingPremiseId()) && notNull(latestPremID))				
				|| (notNull(acct.getMailingPremiseId()) 
						&& notNull(latestPremID)
						&& acct.getMailingPremiseId().compareTo(latestPremID) != 0)
						) {
		// END CHANGES - JHERNA - 2020-05-04 - SysAid#332847
			startChanges();
			Account_DTO acctDTO = acct.getDTO();
			acctDTO.setMailingPremiseId(latestPremID);
			acct.setDTO(acctDTO);
			saveChanges();
			
		}
	}
	
	private Premise_Id getLatestActiveSAsPremise(Account_Id acctID) {
		
		Premise_Id returnValue = null;
		StringBuilder stringBuilder = new StringBuilder();
		
		stringBuilder.append("SELECT SA.CHAR_PREM_ID ");
		stringBuilder.append("FROM CI_SA SA, CI_SA_TYPE SAT ");
		stringBuilder.append("WHERE SA.ACCT_ID = :acctID ");
		stringBuilder.append("AND SA.SA_STATUS_FLG IN (:pendingStart, :active) ");
		stringBuilder.append("AND SAT.SA_TYPE_CD = SA.SA_TYPE_CD ");
		stringBuilder.append("AND SAT.CIS_DIVISION = SA.CIS_DIVISION ");
		stringBuilder.append("AND SAT.SVC_TYPE_CD = 'G' ");
		stringBuilder.append("ORDER BY SA.START_DT DESC ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getLatestActiveSAsPremise=");
		prepState.setAutoclose(false);
		prepState.bindId("acctID", acctID);
		prepState.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
		prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
		prepState.execute();
		
		if (notNull(prepState.firstRow())) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			returnValue = (Premise_Id) sqlRow.getId("CHAR_PREM_ID", Premise.class);
		}		
		prepState.close();
		return returnValue;		
	}
}
