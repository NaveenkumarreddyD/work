/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPLWOTX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      QAC #3240979. Initial Version.
 * 2016-05-30   MPang       Defect 3444302. Added close connection
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.  
 * 2025-11-14   EQuint      CCB25.4 Upgrade                       
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.writeOffEventType.algorithm.event;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.writeOffEventType.algorithm.event.WriteOffEventTypeEventAlgorithmSpot;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffEvent;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmplwotx;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = debtThresholdAmount, required = true, type = decimal)
 *            , @AlgorithmSoftParameter (entityName = customerContactClass, name = customerContactClass, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = customerContactType, required = true, type = string)})
 */
public class CmCreateLetterIfBalanceExceedsThresholdAlgComp_Impl extends
		CmCreateLetterIfBalanceExceedsThresholdAlgComp_Gen implements
		WriteOffEventTypeEventAlgorithmSpot {

	
	// hard parameters
	private Account account;
	private WriteOffEvent event;
	
	// soft parameters
	private BigDecimal debtThresholdAmount;
	private CustomerContactClass customerContactClass;
	private String  customerContactType;
	
	private Cmplwotx cmplwotx;
	//Start Add - MPang - Defect 3444302- 2016-05-30
	private Connection connection;
	//End Add - MPang - Defect 3444302- 2016-05-30
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	
	@Override
	public void setAccount(Account arg0) {
		account = arg0;
	}

	@Override
	public void setWriteOffEvent(WriteOffEvent arg0) {
		event = arg0;
	}
	
	
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		debtThresholdAmount = getDebtThresholdAmount();
		customerContactClass = getCustomerContactClass();
		customerContactType = getCustomerContactType();
	}

	@Override
	public void invoke() {
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			if (notNull(event) && notNull(event.getId())) {
				if (notNull(event.getId().getWriteOffProcessId())) { 
					cmplwotx.setLwzzxInputWrkWoProcId(event.getId().getWriteOffProcessId().getTrimmedValue());
				}else{
					cmplwotx.setLwzzxInputWrkWoProcId(CobolCode.SPACES.toString());
				}
				if (notNull(event.getId().getEventSequence())) { 
					cmplwotx.setLwzzxInputWrkEvtSeq(java.math.BigDecimal.valueOf(event.getId().getEventSequence().doubleValue()));
				}else{
					cmplwotx.setLwzzxInputWrkEvtSeq(java.math.BigDecimal.ZERO);
				}
			}
			if (notNull(account)) {
				cmplwotx.setInputWrkAcctId(account.getId().getTrimmedValue());
			}else{
				cmplwotx.setInputWrkAcctId(CobolCode.SPACES.toString());
			}
			
			
			cmplwotx.setAlgParmVal(1, debtThresholdAmount.toString()); 
			cmplwotx.setAlgParmVal(2, customerContactClass.getId().getTrimmedValue()); 
			cmplwotx.setAlgParmVal(3, customerContactType);
			
			// invoke the main method
		    cmplwotx.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
		    //Start Delete - MPang - Defect 3444302- 2016-05-30
		    //ex.printStackTrace();
		    //End Delete - MPang - Defect 3444302- 2016-05-30
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmplwotx.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmplwotx.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmplwotx.getMessageParm(i);
			    			if (notBlank(cmplwotx.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmplwotx.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmplwotx.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmplwotx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmplwotx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    }
		    else {
		        //Start Add - MPang - Defect 3444302- 2016-05-30
		        ex.printStackTrace();
		        //End Add - MPang - Defect 3444302- 2016-05-30
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmplwotx=Session.returnSessionAndCodeToCache(cmplwotx);
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//			//Start Add - MPang - Defect 3444302- 2016-05-30
//            try {
//                connection.close();
//            } catch (SQLException e) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
//            }
//            //End Add - MPang - Defect 3444302- 2016-05-30
         // end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}

	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
		FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
		RequestContext context = session.getRequestContext();
		
		// start update - equint - 2025-11-14 - CCB25.4 Upgrade
  		session.doWork(new ConnectionWork() {
  			
  			@Override
  			public void execute(Connection connection) throws SQLException {
  				try {  
  					String username = connection.getMetaData().getUserName();
  					String url = connection.getMetaData().getURL();
  					
  					CobolSession.setLogSessionStartEnd(false);
  				    cmplwotx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmplwotx.class);
  					
  					cmplwotx.getSession().getDbSession().setUpdateConnection(connection);
  					cmplwotx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
  					
  					// set ZSTAT parameters

  					cmplwotx.setProcessDt(getProcessDateTime().getDate().toString());
  					cmplwotx.setProcessDttmSep("-");
  					cmplwotx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
  					
  					if (session.isOnlineConnection()) { 
  						cmplwotx.setConnectionFlg(CONNECTION_ONLINE);
  					}
  					else {
  						cmplwotx.setConnectionFlg(CONNECTION_BATCH);
  					}
  					
  					cmplwotx.setZstatUserId(context.getUserId());
  					cmplwotx.setLanguageCd(context.getLanguageCode());
  			        
  			        if (context.ignoreWarnings()) {
  			        	cmplwotx.setIgnoreWarningSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmplwotx.setIgnoreWarningSw(SWITCH_NO);
  			        }
  			        
  			        if (session.getBatchInstanceId() != null) {
  			        	cmplwotx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
  			        	
  					} else {
  						cmplwotx.setSchedulerId(new BigDecimal(0).toBigDecimal());
  					}
  			        
  			        cmplwotx.setAppSvcId(context.getSecurityServiceIdContext());
  			        
  			        DatabaseHelper dbHelper = session.getDatabaseHelper();
  			        cmplwotx.setDbMode(dbHelper.getCobolDBMode());
  			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
  			        //cmplwotx.setSplHighValue(cmplwotx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
  			        //cmplwotx.setSplLowValue(cmplwotx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
  			        
  			        cmplwotx.setSplHighValue(cmplwotx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
  			        cmplwotx.setSplLowValue(cmplwotx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
  			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
  			        
  			        cmplwotx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
  			        
  			        cmplwotx.setLkExpiryDt(Date.MAX.toString());
  			        
  			        cmplwotx.setProgramStatus(" ");
  			        
  			        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
  			        cmplwotx.setCallSeq(";");
  			        cmplwotx.setMessageAreaProgramName("CMPLWOTX");
  			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
  			        
  			        if (context.getRandomGeneratorSeedSet().isTrue()) {
  			        	cmplwotx.setRandomGenSeedSw(SWITCH_YES);
  			        	cmplwotx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
  			        	cmplwotx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
  			        	cmplwotx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
  			        	cmplwotx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
  			        }
  			        else {
  			        	cmplwotx.setRandomGenSeedSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceStandardOut()) { 
  			        	cmplwotx.setTrcStdoutSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmplwotx.setTrcStdoutSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramStart()) { 
  			        	cmplwotx.setTrcProgStartSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmplwotx.setTrcProgStartSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramExit()) { 
  			        	cmplwotx.setTrcProgExitSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmplwotx.setTrcProgExitSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceSQL()) { 
  			        	cmplwotx.setTrcExecSqlSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmplwotx.setTrcExecSqlSw(SWITCH_NO);
  			        }
  			        
  			        // Set ZMSGN parms
  			        BigInteger messageSequence = session.getMessageSequence();
  			        if (notNull(messageSequence)) {
  			        	cmplwotx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
  			        }
  			        else {
  			        	cmplwotx.setMessageSeq(new BigDecimal(0).toBigDecimal());
  			        }
  				}
  				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		 
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//        //Start Change - MPang - Defect 3444302- 2016-05-30
//        //Connection connection = implementor.getConnectionProvider().getConnection();
//        connection = implementor.getConnectionProvider().getConnection();
//        //End Change - MPang - Defect 3444302- 2016-05-30
//        
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmplwotx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmplwotx.class);
//		
//		cmplwotx.getSession().getDbSession().setUpdateConnection(connection);
//		cmplwotx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		
//		// set ZSTAT parameters
//
//		cmplwotx.setProcessDt(getProcessDateTime().getDate().toString());
//		cmplwotx.setProcessDttmSep("-");
//		cmplwotx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmplwotx.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmplwotx.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmplwotx.setZstatUserId(context.getUserId());
//		cmplwotx.setLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmplwotx.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmplwotx.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmplwotx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmplwotx.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmplwotx.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmplwotx.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmplwotx.setSplHighValue(cmplwotx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmplwotx.setSplLowValue(cmplwotx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmplwotx.setSplHighValue(cmplwotx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmplwotx.setSplLowValue(cmplwotx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmplwotx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmplwotx.setLkExpiryDt(Date.MAX.toString());
//        
//        cmplwotx.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmplwotx.setCallSeq(";");
//        cmplwotx.setMessageAreaProgramName("CMPLWOTX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmplwotx.setRandomGenSeedSw(SWITCH_YES);
//        	cmplwotx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmplwotx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmplwotx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmplwotx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmplwotx.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmplwotx.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmplwotx.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmplwotx.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmplwotx.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmplwotx.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmplwotx.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmplwotx.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmplwotx.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmplwotx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmplwotx.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }
  		
  	// end update - equint - 2025-11-14 - CCB25.4 Upgrade

	}

}
