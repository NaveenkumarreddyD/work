/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm calls the CMPLA3PX Algorithm but with an added functionality.
 * Before calling CMPLA3PX, this algorithm will attempt to transfer the 
 * credit balance due to Pledge payments 
 * of the SA whose write off debt class is the same as the write off debt 
 * class of the Write Off control this algorithm is plugged into to a 
 * Pledge Overpayment SA.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2024-03-26   JVitug      B-31789. Initial Version. 
 * 2024-05-30   JVitug      E-08256.Issue1. Updated to now call the COBOL
 *                          routine when creating the adjustment to transfer
 *                          pledge payments to Pledge overpayment SA. Futhermore,
 *                          added checks to not allow the transfer of the pledge
 *                          payment if the total calculated balance due to
 *                          Pledge is greater than the balance of the 
 *                          Deposit SA. 
 * 2024-09-06   JVitug      E-08256.Issue2. Updated to allow transfer of 
 *                          credit balance if the sum of the pledge payments
 *                          is equal to or greater than the Deposit SA's 
 *                          credit balance.
 * 2024-11-15   JVitug      E-08256.Issue3. Updated to not call the COBOL 
 *                          routine if the Write-off debt amount is zero.
 * 2025-11-14   EQuint      CCB25.4 Upgrade
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.writeOffControl.algorithm.writeOffLargeCreditAp;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.role.Role_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_Id;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.base.domain.todo.toDoType.ToDoTypeSortKeyTypes;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.CustomerReadLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.writeOffControl.algorithm.writeOffLargeCreditAp.WriteOffLargeCreditApAlgorithmSpot;
import com.splwg.ccb.domain.admin.writeOffDebtClass.entity.WriteOffDebtClass;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.todo.common.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.data.ToDoMaintenanceData;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpla3px;

/**
 * @author JVitug
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentType, name = syncAdjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = transferAdjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = cisDivision, name = cisDivision, type = entity)
 *            , @AlgorithmSoftParameter (name = overpaymentSAType, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = overpaymentPledgeSAType, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = pledgeCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = pledgeCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = toDoType, name = todoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = toDoRole, type = string, required = true)})
 */
public class CmTransferNonPledgeCreditAmountsToOverpaymentSaAlgComp_Impl extends
        CmTransferNonPledgeCreditAmountsToOverpaymentSaAlgComp_Gen implements
		WriteOffLargeCreditApAlgorithmSpot {

	 
	// hard parameters
	private Bool areServiceAgreementClosed;
	private Account account;
	private WriteOffDebtClass writeOffDebtClass;
	private Money writeOffDebtClassTotalBalance;
	
	// soft parameters
	private AdjustmentType syncAdjustmentType;
	private AdjustmentType transferAdjustmentType;
	private CisDivision cisDivision;
	private String saType;
	private String pledgeOverpaymentSAType;
	//Start Change JVitug - E-08256.Issue1 - 2024-06-04
	//private CharacteristicType doNotTransferCharacteristicType;
	private ToDoType todoType;
	private Role todoRole;
	//End Change JVitug - E-08256.Issue1 - 2024-06-04
	private CharacteristicType pledgePaymentCharacteristicType;
	//Start Delete JVitug - E-08256.Issue1 - 2024-06-04
	//private String dntCharValue;
	//End Delete JVitug - E-08256.Issue1 - 2024-06-04
	private String pledgeCharValue;
	
	private Cmpla3px cmpla3px;
	private Connection connection;
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	//Start Change JVitug - E-08256.Issue1 - 2024-06-04
	//private static final String DNT_CHAR_TYPE_PARM_NAME = "Do Not Transfer Characteristic Type";
	//private static final String DNT_CHAR_VAL_PARM_NAME = "Do Not Transfer Characteristic Value";
	private static final String TODO_ROLE_PARM_NAME = "To Do Role";
	private static final String TODO_TYPE_PARM_NAME = "To Do Type";
	//End Change JVitug - E-08256.Issue1 - 2024-06-04
	private static final String PLEDGE_CHAR_TYPE_PARM_NAME = "Pledge Characteristic Type";
	private static final String PLEDGE_CHAR_VAL_PARM_NAME = "Pledge Characteristic Value";
	
	@Override
	public Bool getAreServiceAgreementsClosed() {
		return areServiceAgreementClosed;
	}

	@Override
	public void setAccount(Account arg0) {
		account = arg0;
	}

	@Override
	public void setWriteOffDebtClass(WriteOffDebtClass arg0) {
		writeOffDebtClass = arg0;
	}

	@Override
	public void setWriteOffDebtClassTotalBalance(Money arg0) {
		writeOffDebtClassTotalBalance = arg0;
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		syncAdjustmentType = getSyncAdjustmentType();
		transferAdjustmentType = getTransferAdjustmentType();
		cisDivision = getCisDivision();
		saType = getOverpaymentSAType();
		pledgeOverpaymentSAType = getOverpaymentPledgeSAType();
		//Start Change JVitug - E-08256.Issue1 - 2024-06-04
		//doNotTransferCharacteristicType = getDntCharacteristicType();
		todoType = getTodoType();
		//End Change JVitug - E-08256.Issue1 - 2024-06-04
		pledgePaymentCharacteristicType = getPledgeCharacteristicType();
		//Start Delete JVitug - E-08256.Issue1 - 2024-06-04
		//dntCharValue = getDntCharValue();
		//End Delete JVitug - E-08256.Issue1 - 2024-06-04
		pledgeCharValue = getPledgeCharValue();
		
		//Start Delete JVitug - E-08256.Issue1 - 2024-06-05
		// Validate the Do Not Transfer Characteristic Type
        //CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(doNotTransferCharacteristicType, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT); 
        //if(isNull(charEntityId.getEntity())){
        	//addError(CustomMessageRepository.B_31789_2_invalidCharTypeForEntity(
        			//DNT_CHAR_TYPE_PARM_NAME, doNotTransferCharacteristicType.getId().getTrimmedValue(), 
        			//CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().fetchLanguageDescription().trim()));
        //}
		
        // Validate the Do Not Transfer Characteristic Value
        //if (doNotTransferCharacteristicType.getCharacteristicType().isPredefinedValue()){
            //CharacteristicValue_Id charValueId = new CharacteristicValue_Id(doNotTransferCharacteristicType, dntCharValue);

            //if (isNull(charValueId.getEntity())) {
                //addError(CustomMessageRepository.B_31789_2_invalidCharValueForCharType(
                //		DNT_CHAR_VAL_PARM_NAME, dntCharValue , doNotTransferCharacteristicType.getId().getTrimmedValue()));
            //}
        //}
		//End Delete JVitug - E-08256.Issue1 - 2024-06-05
        // Validate the Pledge Payment Characteristic Type
		//Start Change JVitug - E-08256.Issue1-2024-06-05
        //charEntityId = new CharacteristicEntity_Id(pledgePaymentCharacteristicType, CharacteristicEntityLookup.constants.PAYMENT);
		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(pledgePaymentCharacteristicType, CharacteristicEntityLookup.constants.PAYMENT);
		//End Change JVitug - E-08256.Issue1-2024-06-05
        if(isNull(charEntityId.getEntity())){
        	addError(CustomMessageRepository.B_31789_2_invalidCharTypeForEntity(
        			PLEDGE_CHAR_TYPE_PARM_NAME, pledgePaymentCharacteristicType.getId().getTrimmedValue(), 
        			CharacteristicEntityLookup.constants.PAYMENT.getLookupValue().fetchLanguageDescription().trim()));
        }
        
        // Validate the Pledge Payment Characteristic Value
        if (pledgePaymentCharacteristicType.getCharacteristicType().isPredefinedValue()){
            CharacteristicValue_Id charValueId = new CharacteristicValue_Id(pledgePaymentCharacteristicType, pledgeCharValue);

            if (isNull(charValueId.getEntity())) {
            	addError(CustomMessageRepository.B_31789_2_invalidCharValueForCharType(
                		PLEDGE_CHAR_VAL_PARM_NAME, pledgeCharValue , pledgePaymentCharacteristicType.getId().getTrimmedValue()));
            }
        } 
        //Start Add JVitug - E-08256.Issue1-2024-06-05
        //Validate the To Do Role
        String parmTodoRoleStr = getToDoRole();
        if(!isBlankOrNull(parmTodoRoleStr)) {
        	todoRole = new Role_Id(parmTodoRoleStr).getEntity();

        	if(isNull(todoRole)) {
        		addError(CustomMessageRepository.B_31789_2_invalidToDoRole(TODO_ROLE_PARM_NAME,parmTodoRoleStr));
        	}

        	//Validate that the To Do Role is valid for the To Do Type
        	ToDoTypeRole_Id validateRoleForToDoType = new ToDoTypeRole_Id(todoType , todoRole);
        	if (isNull(validateRoleForToDoType.getEntity())){
        		//To Do Role is not valid for To Do Type
        		addError(CustomMessageRepository.B_31789_2_invalidToDoRoleForToDoType(TODO_TYPE_PARM_NAME , 
        				parmTodoRoleStr , todoType.getId().getTrimmedValue()));
        	}
        }
        //End Add JVitug - E-08256.Issue1-2024-06-05
	}

	@Override
	public void invoke() {
		ServiceAgreement depositSA = getDepositSAOfAccount();
		
		//try-catch that calls the COBOL since the change is to use the COBOL to create the Pledge Overpayment SA
		// If the current balance of the SA is a credit, check if the credit is from a pledge payment.Check if the credit is from a pledge payment.
        if(notNull(depositSA) && depositSA.getCurrentBalance().isNegative()){
        	BigDecimal creditBalanceFromPledgePayments = getCreditBalanceFromPledgePayments(depositSA.getId());
        	//Start Add JVitug - E-08256.Issue1-2024-06-05
        	if(creditBalanceFromPledgePayments.compareTo(BigDecimal.ZERO) < 0 ){ 
        	//End Add JVitug - E-08256.Issue1-2024-06-05
        		//If a part of the deposit SA's credit balance are due to pledge payments, separate that part of the credit balance and transfer it to a
        		//Pledge overpayment SA
        		ServiceAgreement pledgeOverpaymentSA = searchForActivePledgeOverpaymentSAOnAccount(account);
        		if(isNull(pledgeOverpaymentSA)) {
        			pledgeOverpaymentSA = createOverpaymentSA(account);
        		}
        		//Start Delete JVitug - E-08256.Issue3 - 2024-11-15
        		//Start Add JVitug - E-08256.Issue1-2024-06-05
        		//if(creditBalanceFromPledgePayments.compareTo(BigDecimal.ZERO) < 0 ){
        		//End Delete JVitug - E-08256.Issue3 - 2024-11-15
        		//ServiceAgreement pledgeOverpaymentSA = searchForActivePledgeOverpaymentSAOnAccount(account);
        		//if(isNull(pledgeOverpaymentSA)) {
        		//pledgeOverpaymentSA = createOverpaymentSA(account);
        		//}
        		//Get the Current amount of the Deposit Interest, if any. This is defaulted to zero if deposit interest does not exist.
        		//BigDecimal depositInterest = getDepositInterestAmount(depositSA.getId());
        		//logger.info("deposit interest received : " + depositInterest);
        		//Before transferring the pledge payments to a pledge overpayment SA , check that the total pledge payments
        		//is less than the Deposit SA's Pay-off balance.
        		//Start Change JVitug - E-08256.Issue2 - 2024-09-06
        		//if(creditBalanceFromPledgePayments.abs().compareTo(depositSA.getCurrentBalance().getAmount().abs()) >= 0) {
        		if(creditBalanceFromPledgePayments.abs().compareTo(writeOffDebtClassTotalBalance.getAmount().abs()) >= 0) {
        			//End Change JVitug - E-08256.Issue2 - 2024-09-06
        			//End Add JVitug - E-08256.Issue1-2024-06-05
        			//Start Change JVitug - E-08256.Issue2 - 2024-09-06
        			//If the Pledge payments total amount is greater than or equal to the Deposit SA's current balance, no 
        			//credit amount should be transferred to a normal utility Overpayment SA. Set the amount to be refunded
        			//to the Pledge Overpayment SA equal to the Deposit SA's current balance.
        			//createToDo(depositSA , 
        			//CustomMessageRepository.
        			//B_31789_2_reviewDepositRefund(depositSA.getCurrentBalance().getAmount().toString()
        			//, depositSA.getId().getTrimmedValue()));
        			//If the pledge payments total amount is greater than or equal to the Deposit SA's current balance, we set the pledge amount to be 
        			//equal to the deposit SA's current balance
        			creditBalanceFromPledgePayments = writeOffDebtClassTotalBalance.getAmount();
        			//End Change JVitug - E-08256.Issue2 - 2024-09-06
        			//Start Change JVitug - E-08256.Issue2 - 2024-09-06
        			//Start Add JVitug - E-08256.Issue1-2024-06-05
        			//return;
        			//End Change JVitug - E-08256.Issue2 - 2024-09-06
        		} 
        		//Start Delete JVitug - E-08256.Issue2 - 2024-09-06
        		//else {
        		//End Delete JVitug - E-08256.Issue2 - 2024-09-06
        		//End Add JVitug - E-08256.Issue1-2024-06-05
        		//Start Change JVitug - E-08256.Issue2 - 2024-09-06
        		//createXferAdjustment(depositSA , pledgeOverpaymentSA , new Money(creditBalanceFromPledgePayments , account.getCurrency().getId()));
        		//Attempt to create a transfer adjustment to Gas Pledge SA. If any error occurs during transfer, raise a to do
        		try {
        			createXferAdjustment(depositSA , pledgeOverpaymentSA , new Money(creditBalanceFromPledgePayments , account.getCurrency().getId()));
        		} catch (Exception e) {
        			createToDo(depositSA , 
        					CustomMessageRepository.
        					B_31789_2_reviewDepositRefund(depositSA.getCurrentBalance().getAmount().toString()
        							, depositSA.getId().getTrimmedValue()));
        			return;
        		}
        		//End Change JVitug - E-08256.Issue2 - 2024-09-06
        		//Start Add JVitug - E-08256.Issue1-2024-06-05
        		//Subtract the pledge credit balance from the overall total balance of the Deposit SA so that only the non-pledge portion of the Credit Balance
        		//is credited to the Non-Pledge Overpayment SA
        		writeOffDebtClassTotalBalance = writeOffDebtClassTotalBalance.subtract(new Money(creditBalanceFromPledgePayments , account.getCurrency().getId()));
        		//End Add JVitug - E-08256.Issue1-2024-06-05
        		//Start Delete JVitug - E-08256.Issue2 - 2024-09-06
        		//}
        		//End Delete JVitug - E-08256.Issue2 - 2024-09-06
        		//Start Delete JVitug - E-08256.Issue1-2024-06-05
        		//Subtract the pledge credit balance from the overall total balance of the Deposit SA so that only the non-pledge portion of the Credit Balance
        		//is credited to the Non-Pledge Overpayment SA
        		//writeOffDebtClassTotalBalance = writeOffDebtClassTotalBalance.subtract(new Money(creditBalanceFromPledgePayments , account.getCurrency().getId()));
        		//End Delete JVitug - E-08256.Issue1-2024-06-05
        		//Start Delete JVitug - E-08256.Issue3 - 2024-11-15
        		//}
        		//End Delete JVitug - E-08256.Issue3 - 2024-11-15
        	}
        }

		//Call COBOL to transfer the remaining balance to a Gas Overpayment SA.
        //Start Add JVitug - E-08256.Issue3 - 2024-11-15
        if(!writeOffDebtClassTotalBalance.isZero()) {
        //End Add JVitug - E-08256.Issue3 - 2024-11-15
        	try { 
        		initializeCobolProgram();

        		if(notNull(account)) {
        			cmpla3px.setInputWrkAcctId(account.getId().getTrimmedValue());
        		}
        		else {
        			cmpla3px.setInputWrkAcctId(CobolCode.SPACES.toString());
        		}

        		if(notNull(writeOffDebtClass)) {
        			cmpla3px.setInputWrkWoDebtClCd(writeOffDebtClass.getId().getTrimmedValue());
        		}
        		else {
        			cmpla3px.setInputWrkWoDebtClCd(CobolCode.SPACES.toString());
        		}
        		cmpla3px.setAlgParmVal(1, syncAdjustmentType.getId().getTrimmedValue()); 
        		cmpla3px.setAlgParmVal(2, transferAdjustmentType.getId().getTrimmedValue()); 
        		if(notNull(cisDivision)) {
        			cmpla3px.setAlgParmVal(3, cisDivision.getId().getTrimmedValue());
        		}
        		else {
        			cmpla3px.setAlgParmVal(3, CobolCode.SPACES.toString());
        		}

        		// set cobol program's hard parameters
        		if(notNull(writeOffDebtClassTotalBalance)) {
        			cmpla3px.setWoDebtClTotBal(writeOffDebtClassTotalBalance.getAmount().toBigDecimal());
        		}
        		else {
        			cmpla3px.setWoDebtClTotBal(java.math.BigDecimal.ZERO);
        		}

        		// soft parameters
        		cmpla3px.setAlgParmVal(1, syncAdjustmentType.getId().getTrimmedValue()); 
        		cmpla3px.setAlgParmVal(2, transferAdjustmentType.getId().getTrimmedValue()); 
        		if(notNull(cisDivision)) { 
        			cmpla3px.setAlgParmVal(3, cisDivision.getId().getTrimmedValue());
        		}
        		else {
        			cmpla3px.setAlgParmVal(3, CobolCode.SPACES.toString());
        		}
        		cmpla3px.setAlgParmVal(4, saType); 

        		// invoke the main method
        		cmpla3px.cobolMain(); 
        	} 
        	catch(Exception _ex) {
        		Throwable ex=_ex;
        		while(ex.getCause()!=null) ex=ex.getCause();

        		if(ex instanceof Stop) {
        			if (cmpla3px.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
        					&& cmpla3px.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {

        				MessageParameters messageparameters = new MessageParameters();
        				for (int i = 1; i <= 9; i++) {
        					try {
        						String parmValue = cmpla3px.getMessageParm(i);
        						if (notBlank(cmpla3px.getMessageParm(i))) {
        							messageparameters.addRawString(parmValue.trim());
        						}
        					}
        					catch(IndexOutOfBounds e) {
        						break;
        					}

        				}

        				MessageCategory_Id categoryId = new MessageCategory_Id(cmpla3px.getZmsgnMessageCatNbr().toBigInteger());
        				ServerMessage serverMessage = 
        						ServerMessageFactory.Factory.newInstance().createMessage(
        								categoryId, cmpla3px.getMessageNbr().intValue(), messageparameters);

        				// info
        				if (cmpla3px.getMessageSeverity().compareTo(
        						MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
        					logInfo(serverMessage);
        				}
        				// warning
        				else if (cmpla3px.getMessageSeverity().compareTo(
        						MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
        					addWarning(serverMessage);
        				}
        				// error
        				else {
        					//Start Change JVitug - E-08256.Issue1 - 2024-05-30
        					//addError(serverMessage);
        					createToDoOnTransferError(depositSA, serverMessage , messageparameters);
        					//End Change JVitug - E-08256.Issue1 - 2024-05-30
        				}

        			}

        			areServiceAgreementClosed = (cmpla3px.getSasClosedSw().trim().compareTo(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE;
        		}
        		else {
        			ex.printStackTrace();

        			if (ex instanceof ApplicationError) {
        				addError(((ApplicationError)ex).getServerMessage());
        			}
        			else {
        				addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
        			}
        		}
        	}
        	finally {
        		cmpla3px=Session.returnSessionAndCodeToCache(cmpla3px);
        		// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//        		try {
//        			connection.close();
//        		} catch (SQLException e) {
//        			addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
//        		}
        		// end delete - equint - 2025-11-14 - CCB25.4 Upgrade
        	}
        //Start Add JVitug - E-08256.Issue3 - 2024-11-15
        }
        //End Add JVitug - E-08256.Issue3 - 2024-11-15
	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
	    FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
		RequestContext context = session.getRequestContext();
		
		// start update - equint - 2025-11-14 - CCB25.4 Upgrade
  		session.doWork(new ConnectionWork() {
  			
  			@Override
  			public void execute(Connection connection) throws SQLException {
  				try { 
  					String username = connection.getMetaData().getUserName();
  					String url = connection.getMetaData().getURL();
  					
  					CobolSession.setLogSessionStartEnd(false);
  				    cmpla3px=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpla3px.class);
  					
  					cmpla3px.getSession().getDbSession().setUpdateConnection(connection);
  					cmpla3px.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
  					
  					// set ZSTAT parameters

  					cmpla3px.setProcessDt(getProcessDateTime().getDate().toString());
  					cmpla3px.setProcessDttmSep("-");
  					cmpla3px.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
  					
  					if (session.isOnlineConnection()) { 
  						cmpla3px.setConnectionFlg(CONNECTION_ONLINE);
  					}
  					else {
  						cmpla3px.setConnectionFlg(CONNECTION_BATCH);
  					}
  					
  					cmpla3px.setUserId(context.getUserId());
  					cmpla3px.setZstatLanguageCd(context.getLanguageCode());
  			        
  			        if (context.ignoreWarnings()) {
  			        	cmpla3px.setIgnoreWarningSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpla3px.setIgnoreWarningSw(SWITCH_NO);
  			        }
  			        
  			        if (session.getBatchInstanceId() != null) {
  			        	cmpla3px.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
  			        	
  					} else {
  						cmpla3px.setSchedulerId(new BigDecimal(0).toBigDecimal());
  					}
  			        
  			        cmpla3px.setAppSvcId(context.getSecurityServiceIdContext());
  			        
  			        DatabaseHelper dbHelper = session.getDatabaseHelper();
  			        cmpla3px.setDbMode(dbHelper.getCobolDBMode());
  			        cmpla3px.setSplHighValue(cmpla3px.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
  			        cmpla3px.setSplLowValue(cmpla3px.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
  			        cmpla3px.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
  			        cmpla3px.setLkExpiryDt(Date.MAX.toString());
  			        cmpla3px.setProgramStatus(" ");
  			        cmpla3px.setCallSeq(";");
  			        cmpla3px.setMessageAreaProgramName("CMPLA3PX");
  			        
  			        if (context.getRandomGeneratorSeedSet().isTrue()) {
  			        	cmpla3px.setRandomGenSeedSw(SWITCH_YES);
  			        	cmpla3px.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
  			        	cmpla3px.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
  			        	cmpla3px.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
  			        	cmpla3px.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
  			        }
  			        else {
  			        	cmpla3px.setRandomGenSeedSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceStandardOut()) { 
  			        	cmpla3px.setTrcStdoutSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpla3px.setTrcStdoutSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramStart()) { 
  			        	cmpla3px.setTrcProgStartSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpla3px.setTrcProgStartSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramExit()) { 
  			        	cmpla3px.setTrcProgExitSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpla3px.setTrcProgExitSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceSQL()) { 
  			        	cmpla3px.setTrcExecSqlSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpla3px.setTrcExecSqlSw(SWITCH_NO);
  			        }
  			        
  			        // Set ZMSGN parms
  			        BigInteger messageSequence = session.getMessageSequence();
  			        if (notNull(messageSequence)) {
  			        	cmpla3px.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
  			        }
  			        else {
  			        	cmpla3px.setMessageSeq(new BigDecimal(0).toBigDecimal());
  			        }
  				}
  				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		 
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//		connection = implementor.getConnectionProvider().getConnection();
//		
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmpla3px=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpla3px.class);
//		
//		cmpla3px.getSession().getDbSession().setUpdateConnection(connection);
//		cmpla3px.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		
//		// set ZSTAT parameters
//
//		cmpla3px.setProcessDt(getProcessDateTime().getDate().toString());
//		cmpla3px.setProcessDttmSep("-");
//		cmpla3px.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmpla3px.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmpla3px.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmpla3px.setUserId(context.getUserId());
//		cmpla3px.setZstatLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmpla3px.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmpla3px.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmpla3px.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmpla3px.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmpla3px.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmpla3px.setDbMode(dbHelper.getCobolDBMode());
//        cmpla3px.setSplHighValue(cmpla3px.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmpla3px.setSplLowValue(cmpla3px.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        cmpla3px.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        cmpla3px.setLkExpiryDt(Date.MAX.toString());
//        cmpla3px.setProgramStatus(" ");
//        cmpla3px.setCallSeq(";");
//        cmpla3px.setMessageAreaProgramName("CMPLA3PX");
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmpla3px.setRandomGenSeedSw(SWITCH_YES);
//        	cmpla3px.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmpla3px.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmpla3px.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmpla3px.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmpla3px.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmpla3px.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmpla3px.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmpla3px.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmpla3px.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmpla3px.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmpla3px.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmpla3px.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmpla3px.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmpla3px.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmpla3px.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }
  		
  	// end update - equint - 2025-11-14 - CCB25.4 Upgrade

	}
	
	/** 
	 * This method check if SAs credit from from a pledge payment
	 * @param creditDepositSA - Service Agreement
	 * @return - Bool
	 */
	private BigDecimal getCreditBalanceFromPledgePayments(ServiceAgreement_Id creditDepositSA){
		PreparedStatement sql = null;
		SQLResultRow result = null;
		BigDecimal totalOfPledgePayments = BigDecimal.ZERO;
		
		StringBuilder stringSql = new StringBuilder();
		stringSql.append("SELECT ");
		stringSql.append(   "NVL(SUM(FT.CUR_AMT) , 0) AS CUR_AMT ");
		stringSql.append("FROM ");
		stringSql.append(   "CI_FT FT, ");
		stringSql.append(   "CI_PAY_CHAR PC ");
		stringSql.append("WHERE ");
		stringSql.append(   "FT.SA_ID = :saId ");
		stringSql.append("AND ");
		stringSql.append(   "FT.FT_TYPE_FLG IN (:payment , :paymentCancel) ");
		stringSql.append("AND ");
		stringSql.append(   "FT.FREEZE_SW = 'Y' ");
		stringSql.append("AND ");
		stringSql.append(   "FT.CUR_AMT <> 0 ");
		stringSql.append("AND ");
		stringSql.append(   "FT.PARENT_ID = PC.PAY_ID ");
		stringSql.append("AND ");
		stringSql.append(   "PC.CHAR_TYPE_CD = :pledgeCharType ");
		
		sql = createPreparedStatement(stringSql.toString(), getClass().getName());
		sql.bindId("saId", creditDepositSA);
		sql.bindLookup("payment" , FinancialTransactionTypeLookup.constants.PAY_SEGMENT);
		sql.bindLookup("paymentCancel" , FinancialTransactionTypeLookup.constants.PAY_CANCELLATION);
		sql.bindId("pledgeCharType" , pledgePaymentCharacteristicType.getId());
		
		result = sql.firstRow();
		sql.close();
		
		if(notNull(result)){ 
			totalOfPledgePayments = result.getBigDecimal("CUR_AMT");
		}
		
		return totalOfPledgePayments;
	}
	
	/**
	 * This method search all Write-Off Eligible SAs on the account that does not have the DNT characteristic
	 * @return SQLResultRow
	 */
	private ServiceAgreement getDepositSAOfAccount(){		
		
		ServiceAgreement depositSA = null;
		SQLResultRow row = null;
		StringBuilder sqlQuery = new StringBuilder();    
		
    	sqlQuery.append("SELECT "
    					    +"SA.SA_ID "
    					+"FROM "
    					    +"CI_ACCT AC, "
    					    +"CI_SA SA, "
    					    +"CI_SA_TYPE SATY "
    					+"WHERE "
    					    +"SA.ACCT_ID = :account "
    					+"AND AC.ACCT_ID = SA.ACCT_ID "
    					+"AND SA.SA_TYPE_CD = SATY.SA_TYPE_CD "
    					+"AND SATY.WO_DEBT_CL_CD = :writeOffDebtClass "
    					+"AND SATY.CIS_DIVISION = AC.CIS_DIVISION "
    					//Start Change JVitug - E-08256.Issue1 - 2024-06-04
    					//+"AND SA.SA_STATUS_FLG NOT IN (:closed,:cancelled)
    					+"AND SA.SA_STATUS_FLG NOT IN (:closed,:cancelled) ");
    					//+"AND NOT EXISTS(SELECT 'X' "
    					               //+"FROM CI_SA_CHAR SAC "
    					               //+"WHERE SAC.CHAR_TYPE_CD = :doNotTransfer "
    					               //+"AND (SAC.CHAR_VAL = :charVal "
    					                     //+"OR SAC.ADHOC_CHAR_VAL = :adhocCharVal "
    					                     //+"OR SAC.CHAR_VAL_FK1 = :charValFK1) "
    					               //+"AND SAC.SA_ID = SA.SA_ID)");
    	                //End Change JVitug - E-08256.Issue1 - 2024-06-04
    	
    	PreparedStatement pStmt = createPreparedStatement(sqlQuery.toString(), getClass().getName());
    	pStmt.bindId("account", account.getId());
    	pStmt.bindEntity("writeOffDebtClass", writeOffDebtClass);
    	pStmt.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
    	pStmt.bindLookup("cancelled", ServiceAgreementStatusLookup.constants.CANCELED);
    	//Start Delete JVitug - E-08256.Issue1 - 2024-06-04
    	//pStmt.bindEntity("doNotTransfer", doNotTransferCharacteristicType);
    	//pStmt.bindStringProperty("charVal", ServiceAgreementCharacteristic.properties.characteristicValue, dntCharValue);
    	//pStmt.bindStringProperty("adhocCharVal", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, dntCharValue);
    	//pStmt.bindStringProperty("charValFK1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, dntCharValue);
    	//End Delete JVitug - E-08256.Issue1 - 2024-06-04
    	
    	row = pStmt.firstRow();
    	pStmt.close();
    	
    	if(notNull(row)) {
    		depositSA = row.getEntity("SA_ID" , ServiceAgreement.class);
    	}
		
		return depositSA;
		
	}
	
	/**
	 * This method will create an Overpayment SA Type for an account
	 * @param account
	 * @return
	 */
	private ServiceAgreement createOverpaymentSA(Account account){
        ServiceAgreementType_Id overpaymentSaTypeId = new ServiceAgreementType_Id(account.getDivisionId(), pledgeOverpaymentSAType);
        ServiceAgreement_DTO overpaymentSaDto = new ServiceAgreement_DTO();
        overpaymentSaDto.setAccountId(account.getId());
        overpaymentSaDto.setServiceAgreementTypeId(overpaymentSaTypeId);
        overpaymentSaDto.setStatus(ServiceAgreementStatusLookup.constants.PENDING_START);
        overpaymentSaDto.setStartDate(getProcessDateTime().getDate());
        overpaymentSaDto.setCustomerRead(CustomerReadLookup.constants.NO);
        
        return overpaymentSaDto.newEntity();
    }
	
    /**
     * This method creates the transfer adjustment between the appropriate SAs 
     * @param xferSA
     */
    private void createXferAdjustment(ServiceAgreement depositSA , ServiceAgreement xferSA, Money amount) {
        CreateFrozenAdjustmentData data = CreateFrozenAdjustmentData.Factory.newInstance();
        data.setServiceAgreement(depositSA);
        data.setTransferServiceAgreement(xferSA);
        data.setAdjustmentType(transferAdjustmentType);
        data.setAdjustmentAmount(amount);
        data.setAllowZeroAmount(Bool.FALSE);
        depositSA.createFrozenAdjustment(data);
    }
    
    /**
     * This method will search for an non-closed pledge overpayment SA on the account
     * @param account
     * @return Pledge SA
     */
    private ServiceAgreement searchForActivePledgeOverpaymentSAOnAccount(Account account) {
    	ServiceAgreement pledgeSA = null;
    	StringBuilder stringSql = new StringBuilder();
    	PreparedStatement sql = null;
    	SQLResultRow result = null;
    	
    	stringSql.append("SELECT ");
    	stringSql.append(   "SA.SA_ID ");
    	stringSql.append("FROM ");
    	stringSql.append(   "CI_SA SA ");
    	stringSql.append("WHERE ");
    	stringSql.append(   "SA.SA_TYPE_CD = :saType ");
    	stringSql.append("AND ");
    	stringSql.append(   "SA.ACCT_ID = :accountId ");
    	stringSql.append("AND ");
    	stringSql.append(   "SA.CIS_DIVISION = :division ");
    	stringSql.append("AND ");
    	stringSql.append(   "SA.SA_STATUS_FLG NOT IN (:closed , :canceled) ");
    	
    	sql = createPreparedStatement(stringSql.toString() , getClass().getName());
    	sql.bindId("accountId", account.getId());
    	sql.bindId("division" , account.getDivisionId());
    	sql.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
    	sql.bindLookup("canceled", ServiceAgreementStatusLookup.constants.CANCELED);
    	sql.bindString("saType" , pledgeOverpaymentSAType , "SA_TYPE_CD");
    	
    	result = sql.firstRow();
    	sql.close();
    	
    	if(notNull(result)) {
    		pledgeSA = result.getEntity("SA_ID", ServiceAgreement.class);
    	}
    	
    	return pledgeSA;
    }
    
    //Start Add JVitug - E-08256.Issue1 - 2024-06-04
	private void createToDo(ServiceAgreement depositSA, ServerMessage message) {
		ToDoEntry_DTO entryDto  = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
		
        entryDto.setToDoTypeId(todoType.getId());
        if(notNull(todoRole)) {
        	entryDto.setToDoRoleId(todoRole.getId());
        } else {
        	entryDto.setToDoRoleId(todoType.getDefaultRole().fetchIdToDoRole().getId());
        }
        entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
        entryDto.setCreationDateTime(getProcessDateTime());

        ArrayList<ToDoSortKeyValue_DTO>sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();
        ToDoTypeSortKeyTypes sortKeyTypes = todoType.getSortKeyTypes();

        for (Iterator<ToDoSortKeyType> iter = sortKeyTypes.iterator(); iter.hasNext();) {
            ToDoSortKeyType sortKeyType = (ToDoSortKeyType) iter.next();
            ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
            BigInteger seq = sortKeyType.fetchIdSequence();
            sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));

            if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(10))== 0){
                sortKeyDto.setKeyValue(depositSA.getCurrentBalance().getAmount().toString().trim());
            } else if (sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(20)) == 0) {
            	sortKeyDto.setKeyValue(message.getMessageId().getMessageCategory().getId().getIdValue().toString() + ", " +  message.getMessageId().getMessageNumber().toString());
            }
            
            sortKeyList.add(sortKeyDto);
        }

        ArrayList<ToDoDrillKeyValue_DTO> drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
        ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO) createDTO(ToDoDrillKeyValue.class);
        ToDoDrillKeyType drillKeyType = (ToDoDrillKeyType) todoType.getDrillKeyTypes().iterator().next();
        BigInteger sequence = drillKeyType.fetchIdSequence();
        drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, sequence));

        drillKeyDto.setKeyValue(depositSA.getId().getTrimmedValue());
        drillKeyList.add(drillKeyDto);
        
        entryDto.setMessageId(message.getMessageId());

        ArrayList <String> messageParameterList = new ArrayList<String> ();
        messageParameterList.add(0, depositSA.getCurrentBalance().getAmount().toString().trim());
        messageParameterList.add(1 , depositSA.getId().getTrimmedValue());

        ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory.newInstance();

        toDoEntryData.setDrillKeys(drillKeyList);
        toDoEntryData.setEntryDto(entryDto);
        toDoEntryData.setSortKeys(sortKeyList);
        toDoEntryData.setMessageParams(messageParameterList);

        ArrayList <ToDoEntryCharacteristic_DTO>  charList = new ArrayList<ToDoEntryCharacteristic_DTO> ();
        toDoEntryData.setToDoCharacteristics(charList);

        ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
        @SuppressWarnings("unused")
        ToDoEntry toDoEntry = toDoProcessor.addToDo(toDoEntryData);
	}
	
	private void createToDoOnTransferError(ServiceAgreement depositSA, ServerMessage message , MessageParameters parms) {
		ToDoEntry_DTO entryDto  = (ToDoEntry_DTO) createDTO(ToDoEntry.class);

		entryDto.setToDoTypeId(todoType.getId());
		if(notNull(todoRole)) {
			entryDto.setToDoRoleId(todoRole.getId());
		} else {
			entryDto.setToDoRoleId(todoType.getDefaultRole().fetchIdToDoRole().getId());
		}
		entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
		entryDto.setCreationDateTime(getProcessDateTime());

		ArrayList<ToDoSortKeyValue_DTO>sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();
		ToDoTypeSortKeyTypes sortKeyTypes = todoType.getSortKeyTypes();

		for (Iterator<ToDoSortKeyType> iter = sortKeyTypes.iterator(); iter.hasNext();) {
			ToDoSortKeyType sortKeyType = (ToDoSortKeyType) iter.next();
			ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
			BigInteger seq = sortKeyType.fetchIdSequence();
			sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));

			if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(10))== 0){
				sortKeyDto.setKeyValue(depositSA.getCurrentBalance().getAmount().toString().trim());
			} else if (sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(20)) == 0) {
				sortKeyDto.setKeyValue(message.getMessageId().getMessageCategory().getId().getIdValue().toString() + ", " +  message.getMessageId().getMessageNumber().toString());
			}

			sortKeyList.add(sortKeyDto);
		}

		ArrayList<ToDoDrillKeyValue_DTO> drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
		ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO) createDTO(ToDoDrillKeyValue.class);
		ToDoDrillKeyType drillKeyType = (ToDoDrillKeyType) todoType.getDrillKeyTypes().iterator().next();
		BigInteger sequence = drillKeyType.fetchIdSequence();
		drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, sequence));

		drillKeyDto.setKeyValue(depositSA.getId().getTrimmedValue());
		drillKeyList.add(drillKeyDto);

		entryDto.setMessageId(message.getMessageId());

		ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory.newInstance();

		toDoEntryData.setDrillKeys(drillKeyList);
		toDoEntryData.setEntryDto(entryDto);
		toDoEntryData.setSortKeys(sortKeyList);
		toDoEntryData.setMessageParams(parms.getParameters());

		ArrayList <ToDoEntryCharacteristic_DTO>  charList = new ArrayList<ToDoEntryCharacteristic_DTO> ();
		toDoEntryData.setToDoCharacteristics(charList);

		ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
		@SuppressWarnings("unused")
		ToDoEntry toDoEntry = toDoProcessor.addToDo(toDoEntryData);
	}
    //End Add JVitug - E-08256.Issue1 - 2024-06-04
}
