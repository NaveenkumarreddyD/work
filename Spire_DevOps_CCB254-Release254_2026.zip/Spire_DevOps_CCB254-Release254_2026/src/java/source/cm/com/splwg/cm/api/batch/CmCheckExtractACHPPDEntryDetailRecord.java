/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Column Delimited Record class for PPD Entry Detail
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-05-27   RDizon  CCB041. Initial version.        
 **************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

/**
 * @author RDizon
 */
public class CmCheckExtractACHPPDEntryDetailRecord extends ColumnDelimitedRecord {
        
    public CmCheckExtractACHPPDEntryDetailRecord() {
        super(11);
    }

    public void setRecordType(String value) {
        this.rightPadColumn(1, 1, value);
    }

    public void setTransactionCode(String value) {
        this.rightPadColumn(2, 2, value);
    }

    public void setReceivingDFIiIdentification(String value) {
        this.rightPadColumn(3, 8, value);
    }

    public void setCheckDigit(String value) {
        this.rightPadColumn(4, 1, value);
    }

    public void setDFIAccountNumber(String value) {
        this.rightPadColumn(5, 17, value);
    }

    public void setAmount(String value) {
        this.rightPadColumn(6, 10, StringUtilities.leftPadWithZeros(value, 10));
        
    }

    public void setIndividualIdNumber(String value) {
        this.rightPadColumn(7, 15, value);
    }

    public void setIndividualName(String value) {
        this.rightPadColumn(8, 22, value);
    }

    public void setDiscretionaryData(String value) {
        this.rightPadColumn(9, 2, value);
    }

    public void setAddendaRecordIndicator(String value) {
        this.rightPadColumn(10, 1, value);
    }

    public void setTraceNumber(String value) {
        this.rightPadColumn(11, 15, value);
    }

}
