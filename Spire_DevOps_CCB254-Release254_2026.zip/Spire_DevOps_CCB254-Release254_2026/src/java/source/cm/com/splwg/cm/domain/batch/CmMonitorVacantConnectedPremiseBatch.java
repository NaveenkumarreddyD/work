/*
 *************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * MGE-CCB009: Vacant Premise With Consumption
 * 	- Monitor Vacant Connected Premise Batch
 * 
 * This Background Process will monitor the connected Service Points on a 
 * premise under the specified Cis Division and would create 'Disconnect SP'
 * field activities for the SP which satisfies the following conditions:
 * 
 * 1.) A meter read was found after the Service Point's service was stopped
 *     and the calculated consumption exceeded the Consumption Threshold 
 *     batch parameter.
 * 2.) The elapsed time since the premise was left vacant (service was 
 *     stopped) exceeded the vacant days threshold batch parameter.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2014-09-24   JHERNA          MGE-CCB009: Initial Version. 
 * 2015-03-23	JHERNA			DEFECT#3179370: Change request to add a
 *                              soft parameter to this background process
 *                              which would limit the maximum number of 
 *                              Field Activities this batch will create. 
 *                              Once this threshold is reached, then the 
 *                              batch program will terminate. Also included
 *                              updates to improve performance (specially
 *                              for the main query) and updated the thread
 *                              execution strategy to match what is on the
 *                              design.
 * 2015-07-30	SMiran			Defect 3259515. Change execution strategy
 * 								to Standard Commit so that errors are
 * 								logged without aborting the job.
 * 2015-10-06	JHERNA			DEFECT#3311665: Change Requests:
 * 								1.) add parameter for schedule date modifier
 * 								2.) ensure that the created FAs have a
 * 									schedule date of create date + modifier
 * 									and it falls on a business day according
 * 									to the premise's work calendar
 * 2016-01-29  	MPang		    Updated for CCB v2.4 compilation. 
 * 2024-07-29   JVitug          INC0033320. Updated to change the case log
 *                              type being logged as System instead of
 *                              Created Log Type
 **************************************************************************
 */
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.TimeInterval;
import com.splwg.base.api.lookup.ProgramTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControl;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CaseLogTypeLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.ReadTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointMeterEventTypeLookup;
import com.splwg.ccb.api.lookup.ServicePointSourceStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointStatusLookup;
import com.splwg.ccb.cobol.mr.CobolCopybookCICMDBRN;
import com.splwg.ccb.cobol.mr.CobolProgramCIPMDBRN;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.caseType.entity.CharacteristicTypeCaseType;
import com.splwg.ccb.domain.admin.caseType.entity.CharacteristicTypeCaseType_Id;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityLog_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_DTO;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.Register;
import com.splwg.ccb.domain.meterread.meterConfiguration.Register_Id;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead_Id;*/
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_Id;
import com.splwg.ccb.domain.todo.common.CaseCreator;
import com.splwg.ccb.domain.todo.data.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameter;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameter_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameter_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.common.ServerMessage;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation

//START CHANGE - PSREEKAN - 2016-09-26 - DEFECT#82480
///**
// * @author JHERNA
// *
// @BatchJob (modules = {}, rerunnable = false,
// *      softParameters = { @BatchJobSoftParameter (name = VAC_DAYS_THRSHLD, required = true, type = integer)
// *            , @BatchJobSoftParameter (entityName = unitOfMeasure, name = CNSMPTN_UOM, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = CNSMPTN_THRSHLD, required = true, type = decimal)
// *            , @BatchJobSoftParameter (entityName = fieldActivityType, name = FA_TYPE_CD, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = MAX-ERRORS, type = integer)
// *            , @BatchJobSoftParameter (name = MAX_NBR_FA_PER_THD, type = integer)
// *            , @BatchJobSoftParameter (name = FA_SCHED_DT_MODIFIER, required = true, type = integer)})
// */
/**
 * @author JHERNA
 *
 @BatchJob (modules = {}, rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (name = VAC_DAYS_THRSHLD, required = true, type = integer)
 *            , @BatchJobSoftParameter (entityName = unitOfMeasure, name = CNSMPTN_UOM, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CNSMPTN_THRSHLD, required = true, type = decimal)
 *            , @BatchJobSoftParameter (entityName = fieldActivityType, name = FA_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = MAX-ERRORS, type = integer)
 *            , @BatchJobSoftParameter (name = MAX_NBR_CASE_PER_THD, type = integer)
 *            , @BatchJobSoftParameter (entityName = caseType, name = CASE_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = INITIAL_CASE_LIFECYCLE, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = SP_ID_CHAR, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_SOURCE_CHAR, required = true, type = entity)})
 */
//END CHANGE - PSREEKAN - 2016-09-26 - DEFECT#82480
public class CmMonitorVacantConnectedPremiseBatch 
		extends CmMonitorVacantConnectedPremiseBatch_Gen {

	// Parameters
	private BigInteger parmVacDaysThreshold;
	@SuppressWarnings("unused")
	private UnitOfMeasure parmConsumptionUOM;
	private BigDecimal parmConsumptionThreshold;
	@SuppressWarnings("unused")
	private FieldActivityType parmFAType;
	@SuppressWarnings("unused")
	private CisDivision parmCisDivision;
	@SuppressWarnings("unused")
	private BigInteger parmMaxErrors;
	// Constant
	private final static String PROG_NAME = "com.splwg.cm.domain.batch.CmMonitorVacantConnectedPremiseBatch";
	// START ADD - JHERNA - 2015-03-23 - DEFECT#3179370
	private final static Logger LG = LoggerFactory.getLogger(CmMonitorVacantConnectedPremiseBatch.class);
	// START DELETE - PSREEKAN - 2016-09-26 - DEFECT#82480
//	@SuppressWarnings("unused")
//	private BigInteger parmMaxNbrFA;
	// END DELETE - PSREEKAN - 2016-09-26 - DEFECT#82480
	// END ADD - JHERNA - 2015-03-23 - DEFECT#3179370
	// START ADD - PSREEKAN - 2016-09-26 - DEFECT#82480
	private CaseType parmCaseType;
	private String parmCaseStatus;
	private BigInteger parmMaxNbrCASE;
	private CharacteristicType parmCaseSourceCharType;
	private CharacteristicType parmSpChar;
	
	// END ADD - PSREEKAN - 2016-09-26 - DEFECT#82480
	@Override
	public void validateSoftParameters(boolean arg0) {
		
		// Retrieve Batch Parameter 10: Vacant Days Threshold
		parmVacDaysThreshold = this.getParameters().getVAC_DAYS_THRSHLD();
		String parm10Desc = cmOutRetrieveBatchParameterDescription(PROG_NAME, BigInteger.TEN);
		cmValidateParmIntegerGreaterThanZero(parmVacDaysThreshold, parm10Desc);
		// Retrieve Batch Parameter 20: Consumption Unit Of Measure
		parmConsumptionUOM = this.getParameters().getCNSMPTN_UOM();
		// Retrieve Batch Parameter 30: Consumption Threshold
		parmConsumptionThreshold = this.getParameters().getCNSMPTN_THRSHLD();
		String parm30Desc = cmOutRetrieveBatchParameterDescription(PROG_NAME, BigInteger.valueOf(30));
		cmValidateParmDecimalGreaterThanZero(parmConsumptionThreshold, parm30Desc);
		// Retrieve Batch Parameter 40: Field Activity Type
		parmFAType = this.getParameters().getFA_TYPE_CD();
		// Retrieve Batch Paramater 50: Cis Division
		parmCisDivision = this.getParameters().getCIS_DIVISION();
		// Retrieve Batch Parameter 60: Maximum Errors
		parmMaxErrors = this.getParameters().getMAX_ERRORS();
		// START ADD - JHERNA - 2015-03-23 - DEFECT#3179370
		// START DELETE - PSREEKAN - 2016-09-26 - DEFECT#82480
//		parmMaxNbrFA = this.getParameters().getMAX_NBR_FA_PER_THD();
//		if (notNull(parmMaxNbrFA)
//				&& parmMaxNbrFA.compareTo(BigInteger.ZERO) <= 0) {
//			String parm70Desc = cmOutRetrieveBatchParameterDescription(PROG_NAME, BigInteger.valueOf(70));
//			cmValidateParmIntegerGreaterThanZero(parmMaxNbrFA, parm70Desc);
//		}
//		// END ADD - JHERNA - 2015-03-23 - DEFECT#3179370
//		// START ADD - JHERNA - 2015-10-07 - 3311665
//		// Retrieve and validate parameter for FA Schedule Date Modifier (value should be zero or greater)
//		BigInteger faSchedDateModifier = this.getParameters().getFA_SCHED_DT_MODIFIER();
//		String parm90Desc = cmOutRetrieveBatchParameterDescription(PROG_NAME, BigInteger.valueOf(90));		
//		if (faSchedDateModifier.compareTo(BigInteger.ZERO) < 0) {
//			// Batch parameter '%1%2' value (%3) must be greater than zero.
//			addError(CustomMessageRepositoryMGE.commBatchParameterMustBeAPositiveNumberorDecimal(parm90Desc.trim(), faSchedDateModifier.toString().trim()));
//		}	
		// END DELETE - PSREEKAN - 2016-09-26 - DEFECT#82480
		// END ADD - JHERNA - 2015-10-07 - 3311665
		// START ADD - PSREEKAN - 2016-09-26 - DEFECT#82480
		parmMaxNbrCASE = this.getParameters().getMAX_NBR_CASE_PER_THD();
		if (notNull(parmMaxNbrCASE)
				&& parmMaxNbrCASE.compareTo(BigInteger.ZERO) <= 0) {
			String parm70Desc = cmOutRetrieveBatchParameterDescription(PROG_NAME, BigInteger.valueOf(70));
			cmValidateParmIntegerGreaterThanZero(parmMaxNbrCASE, parm70Desc);
		}
		
		parmCaseType = getParameters().getCASE_TYPE_CD();
        if (parmCaseType.getPremiseUsage().isNotAllowed()) {
            addError(CustomMessageRepository.nm0038PremiseUsageNotAllowediInCaseType(parmCaseType.getId().getTrimmedValue()));
        }
        
        parmCaseStatus = getParameters().getINITIAL_CASE_LIFECYCLE();
        CaseStatus_Id caseStatusId = new CaseStatus_Id(parmCaseType, parmCaseStatus);
        CaseStatus caseStatus = caseStatusId.getEntity();
        if (isNull(caseStatus)) {              
            addError(CustomMessageRepository.nm0038InvalidCaseStatus(parmCaseStatus,parmCaseType.getId().getTrimmedValue()));
        }
        if (!(caseStatus.getStatusCondition().isInitial())) {
            addError(CustomMessageRepository.nm0038InvalidInitialCaseStatus(parmCaseStatus,parmCaseType.getId().getTrimmedValue()));
        }  
        
        parmCaseSourceCharType = getParameters().getCASE_SOURCE_CHAR();
        validateCharTypeEntity(parmCaseSourceCharType);
        validateCharTypeForCaseType(parmCaseSourceCharType);
        
        parmSpChar = getParameters().getSP_ID_CHAR();
        validateCharTypeEntity(parmSpChar);
        validateCharTypeForCaseType(parmSpChar);
		// END ADD - PSREEKAN - 2016-09-26 - DEFECT#82480
	}
	
	// START ADD - PSREEKAN - 2016-09-26 - DEFECT#82480
	/**
     * This Method will validate whether the input parameter Characteristic Type 
     * is valid for the Case Characteristic Entity.
     * @param parmCharType
     */
    private void validateCharTypeEntity(CharacteristicType parmCharType){
        CharacteristicEntityLookup parmEntityLookup = CharacteristicEntityLookup.constants.CASE;
        CharacteristicEntity_Id characteristicEntityId = new CharacteristicEntity_Id(parmCharType, parmEntityLookup);
        if (isNull(characteristicEntityId.getEntity())){
            addError(CustomMessageRepository.nm0038CharTypeInvalidForCharEntity(parmCharType.getId().getIdValue(), parmEntityLookup.getConstantName()));
        } 
    }

    /**
     * This Method will validate whether the input parameter Characteristic Type 
     * is valid for the input Case Type.
     * @param parmCharType
     */
    private void validateCharTypeForCaseType(CharacteristicType parmCharType){
        
        CharacteristicTypeCaseType charTypeCaseType = new CharacteristicTypeCaseType_Id(parmCharType, parmCaseType).getEntity();
        if(isNull(charTypeCaseType)){
            addError(CustomMessageRepository.nm0038InvalidCharTypeForCaseType(parmCharType.getId().getTrimmedValue(), parmCaseType.getId().getTrimmedValue()));
        }
    }
    // END ADD - PSREEKAN - 2016-09-26 - DEFECT#82480

	/**
	 * Custom method which retrieves the Batch Parameter Description
	 * @param progName the programe and the package where the program is located
	 * @param parmSeq the parameter sequence
	 * @return returnValue the parameter description
	 */
	private String cmOutRetrieveBatchParameterDescription(String progName, BigInteger parmSeq) {
		
		String returnValue = " ";		
		StringBuilder stringBuilder = new StringBuilder();				
		stringBuilder.append("SELECT BCPL.DESCR50 ");
		stringBuilder.append("FROM CI_BATCH_CTRL_P_L BCPL, CI_BATCH_CTRL BC ");
		stringBuilder.append("WHERE BC.PROGRAM_NAME = :progName ");
		stringBuilder.append("AND BC.PGM_TYPE_FLG = :javaType ");
		stringBuilder.append("AND BCPL.BATCH_CD = BC.BATCH_CD ");
		stringBuilder.append("AND BCPL.LANGUAGE_CD = :language ");
		stringBuilder.append("AND BCPL.SEQ_NUM = :parmSeq ");
		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		prepState.bindStringProperty("progName", BatchControl.properties.programName, progName);
		prepState.bindLookup("javaType", ProgramTypeLookup.constants.JAVA);
		prepState.bindId("language", this.getActiveContextLanguage().getId());
		prepState.bindBigInteger("parmSeq", parmSeq);
		prepState.execute();
		if (prepState.list().size() > 0) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			returnValue = (String) sqlRow.get("DESCR50");
		}
		prepState.close();
		return returnValue;
	}
	/**
	 * Custom method which validates that the Integer value is greater than zero
	 * @param parmVal the value that is being validated
	 * @param parmDesc the parameter's description (will be used in case that validation failed for the value)
	 */
	private void cmValidateParmIntegerGreaterThanZero(BigInteger parmVal, String parmDesc) {
		
		if (parmVal.compareTo(BigInteger.ZERO) <= 0) {
			// Batch parameter '%1%2' value (%3) must be greater than zero.
			addError(CustomMessageRepositoryMGE.commBatchParameterMustBeGreaterThanZero(parmDesc.trim(), parmVal.toString().trim()));
		}		
	}
	/**
	 * Custom method which validates that the BigDecimal value is greater than zero
	 * @param parmVal the value that is being validated
	 * @param parmDesc the parameter's description (will be used in case that validation failed for the value)
	 */
	private void cmValidateParmDecimalGreaterThanZero(BigDecimal parmVal, String parmDesc) {
		
		if (parmVal.compareTo(BigDecimal.ZERO) <= 0) {
			// Batch parameter '%1%2' value (%3) must be greater than zero.
			addError(CustomMessageRepositoryMGE.commBatchParameterMustBeGreaterThanZero(parmDesc.trim(), parmVal.toString().trim()));
		}		
	}
	
	@SuppressWarnings("unchecked")
	public JobWork getJobWork() {
		
		/*
		 * Main Criteria
		 * 
		 * Select all Service Points (inService - not abolished) connected into a premise with the specified CIS Division
		 * that does not have any active (billable) Service Agreements. An additional requirement is that the Service Points
		 * must not have any pending Field Activity with FA Type matching Batch Parameter 40: Field Activity Type 
		 */
		StringBuilder stringBuilder = new StringBuilder();				
		stringBuilder.append("SELECT SP.SP_ID ");
		stringBuilder.append("FROM CI_SP SP, CI_PREM PREM ");
		// Criteria: Cis Division as specified
		stringBuilder.append("WHERE PREM.CIS_DIVISION = :cisDivision ");                                               
		stringBuilder.append("AND SP.PREM_ID = PREM.PREM_ID ");
		// Criteria: SP is still Connected
		stringBuilder.append("AND SP.SP_SRC_STATUS_FLG = :spSourceStatus ");
		// Criteria: SP is still InService / Not Abolished
		stringBuilder.append("AND (SP.SP_STATUS_FLG = :spStatus ");
			// Criteria: SP is Not Abolished as of processing date
		stringBuilder.append("    OR (SP.ABOLISH_DT IS NULL OR SP.ABOLISH_DT > :processDate) ");                   
		stringBuilder.append("    ) ");
		    // Criteria: SP does not have any Actively Billable SA
		stringBuilder.append("AND SP.SP_ID NOT IN (SELECT SASP.SP_ID ");
				             // Inner Select: List of SPs that contains Active Services
		stringBuilder.append("                     FROM CI_SA_SP SASP, CI_SA SA ");                               
		stringBuilder.append("                     WHERE SASP.SP_ID IN (SELECT SP2.SP_ID ");
		stringBuilder.append("                                          FROM CI_SP SP2 ");
		stringBuilder.append("                                          WHERE SP2.PREM_ID = PREM.PREM_ID ");
		stringBuilder.append("                                          AND SP2.SP_SRC_STATUS_FLG = :spSourceStatus ");
		stringBuilder.append("                                          AND SP2.SP_STATUS_FLG = :spStatus ");
		stringBuilder.append("                                          AND (SP2.ABOLISH_DT IS NULL OR SP2.ABOLISH_DT > :processDate) ");                                          
		stringBuilder.append("                                         ) ");
		stringBuilder.append("                     AND SA.SA_ID = SASP.SA_ID ");
		stringBuilder.append("                     AND SA.SA_STATUS_FLG IN (:pendingStart, :active, :pendingStop, :reactivated) ");
		stringBuilder.append("                    ) ");
		// START CHANGES - JHERNA - 2015-03-23 - DEFECT#3179370
							// Criteria: SP must not have any pending FA of FA Type that matches Batch Parameter 40: Field Activity Type
		//stringBuilder.append("AND SP.SP_ID NOT IN (SELECT FA.SP_ID ");
		//stringBuilder.append("                     FROM CI_FA FA ");
		//stringBuilder.append("                     WHERE FA.FA_TYPE_CD = :faTypeCd ");
		//stringBuilder.append("                     AND FA.FA_STATUS_FLG = :pending ");
		//stringBuilder.append("                     ) ");
		stringBuilder.append("ORDER BY SP.SP_ID ASC ");		
		// END CHANGES - JHERNA - 2015-03-23 - DEFECT#3179370

		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		prepState.bindId("cisDivision", parmCisDivision.getId());
		prepState.bindLookup("spSourceStatus", ServicePointSourceStatusLookup.constants.CONNECTED);
		prepState.bindLookup("spStatus", ServicePointStatusLookup.constants.IN_SERVICE);
		prepState.bindDate("processDate", this.getProcessDateTime().getDate());
		prepState.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
		prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
		prepState.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
		prepState.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
		// START DELETE - JHERNA - 2015-03-23 - DEFECT#3179370
		//prepState.bindId("faTypeCd", parmFAType.getId());
		//prepState.bindLookup("pending", FieldActivityStatusLookup.constants.PENDING);
		// END DELETE - JHERNA - 2015-03-23 - DEFECT#3179370
		prepState.execute();
		QueryIterator queryIter = prepState.iterate();
		return createJobWorkForQueryIterator(queryIter, this);
	}

	@Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow qrw) {
		
		ThreadWorkUnit twu = new ThreadWorkUnit();
		ServicePoint_Id spID = (ServicePoint_Id) qrw.getId("SP_ID", ServicePoint.class);
		twu.setPrimaryId(spID);
		return twu;
	}
	
	public Class<CmMonitorVacantConnectedPremiseBatchWorker> getThreadWorkerClass() {
		return CmMonitorVacantConnectedPremiseBatchWorker.class;
	}

	public static class CmMonitorVacantConnectedPremiseBatchWorker 
			extends CmMonitorVacantConnectedPremiseBatchWorker_Gen {

		private BigInteger parmVacDaysThreshold;
		private UnitOfMeasure parmConsumptionUOM;
		private BigDecimal parmConsumptionThreshold;
		private FieldActivityType parmFAType;
		@SuppressWarnings("unused")
		private CisDivision parmCisDivision;
		// START ADD - JHERNA - 2015-03-23 - DEFECT#3179370
		private BigInteger createdFACounter;
		// START DELETE - PSREEKAN - 2016-09-26 - DEFECT#82480
//		private BigInteger parmMaxNbrFA;
		// END ADD - JHERNA - 2015-03-23 - DEFECT#3179370
		// START ADD - JHERNA - 2015-10-07 - 3311665
//		private BigInteger parmFaSchedDateModifier;
		// END DELETE - PSREEKAN - 2016-09-26 - DEFECT#82480
		// END ADD - JHERNA - 2015-10-07 - 3311665
		// START ADD - PSREEKAN - 2016-09-26 - DEFECT#82480
		private BigInteger createdCaseCounter;
		private BigInteger parmMaxNbrCASE;
		// END ADD - PSREEKAN - 2016-09-26 - DEFECT#82480
		
		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
			
			// Retrieve Parameter 10: Vacant Days Threshold
			parmVacDaysThreshold = this.getParameters().getVAC_DAYS_THRSHLD();
			// Retrieve Parameter 20: Consumption UOM
			parmConsumptionUOM = this.getParameters().getCNSMPTN_UOM();
			// Retrieve Parameter 30: Consumption Threshold
			parmConsumptionThreshold = this.getParameters().getCNSMPTN_THRSHLD();
			// Retrieve Parameter 40: Field Activity Type
			parmFAType = this.getParameters().getFA_TYPE_CD();
			// Retrieve Parameter 50: CIS Division
			parmCisDivision = this.getParameters().getCIS_DIVISION();
			// START ADD - JHERNA - 2015-03-23 - DEFECT#3179370
			// START DELETE - PSREEKAN - 2016-09-26 - DEFECT#82480
//			parmMaxNbrFA = this.getParameters().getMAX_NBR_FA_PER_THD();
			// END DELETE - PSREEKAN - 2016-09-26 - DEFECT#82480
			createdFACounter = BigInteger.ZERO;
			// END ADD - JHERNA - 2015-03-23 - DEFECT#3179370
			// START ADD - JHERNA - 2015-10-07 - 3311665
			// START DELETE - PSREEKAN - 2016-09-26 - DEFECT#82480
//			parmFaSchedDateModifier = this.getParameters().getFA_SCHED_DT_MODIFIER();
			// END DELETE - PSREEKAN - 2016-09-26 - DEFECT#82480
			// END ADD - JHERNA - 2015-10-07 - 3311665
			
			// START ADD - PSREEKAN - 2016-09-26 - DEFECT#82480
			createdCaseCounter = BigInteger.ZERO;;
			parmMaxNbrCASE = this.getParameters().getMAX_NBR_CASE_PER_THD();
			// END ADD - PSREEKAN - 2016-09-26 - DEFECT#82480
		}

		public ThreadExecutionStrategy createExecutionStrategy() {
			// 2015-07-30. SMiran. Defect 3259515. Start Change
			//// START CHANGE - JHERNA - 2015-03-23 - DEFECT#3179370
			////return new StandardCommitStrategy(this);
			//return new SingleTransactionStrategy(this);
			//// END CHANGE - JHERNA - 2015-03-23 - DEFECT#3179370
			return new StandardCommitStrategy(this);
			// 2015-07-30. SMiran. Defect 3259515. End Change
		}
		
		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			ServicePoint_Id spID = (ServicePoint_Id) unit.getPrimaryId();
			// START ADD - JHERNA - 2015-03-23 - DEFECT#3179370
			// START CHANGE - PSREEKAN - 2016-09-26 - DEFECT#82480
//			if (shouldProceed(spID).isTrue()
//					// In the event that the maximum number of FA parameter is not populated, then there is no limit to the FA to be created.
//					// Create FA at will. In the event that the maximum number of FA parameter is populated, ensure that the number of
//					// FAs created will not exceed this value.
//					&& (isNull(parmMaxNbrFA)
//							|| createdFACounter.compareTo(parmMaxNbrFA) < 0)) {		
			if (shouldProceed(spID).isTrue()
					// In the event that the maximum number of CASE parameter is not populated, then there is no limit to the CASE to be created.
					// Create CASE at will. In the event that the maximum number of CASE parameter is populated, ensure that the number of
					// CASEs created will not exceed this value.
					&& (isNull(parmMaxNbrCASE)
							|| createdCaseCounter.compareTo(parmMaxNbrCASE) < 0)) {	
			// END CHANGE - PSREEKAN - 2016-09-26 - DEFECT#82480
			// END ADD - JHERNA - 2015-03-23 - DEFECT#3179370
				// Retrieve the meter configuration and the stop date of the latest SA/SP that had service at the premise.
				StringBuilder stringBuilder = new StringBuilder();						
				stringBuilder.append("SELECT MR.READ_DTTM, MR.MTR_CONFIG_ID, MR.MR_ID ");
				stringBuilder.append("FROM CI_SA_SP SASP, CI_MR MR ");
				stringBuilder.append("WHERE SASP.SP_ID = :spID ");
				stringBuilder.append("AND SASP.STOP_DTTM = (SELECT MAX(SASP2.STOP_DTTM) ");
				stringBuilder.append("                      FROM CI_SA_SP SASP2 ");
				stringBuilder.append("                      WHERE SASP2.SP_ID = SASP.SP_ID ");
				stringBuilder.append("                      ) ");
				stringBuilder.append("AND MR.MR_ID = SASP.STOP_MR_ID ");
				//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
				PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
				//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				prepState.bindId("spID", spID);
				prepState.execute();
				
				if (prepState.list().size() > 0) {
					
					SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();				
					DateTime stopMRDateTime = sqlRow.getDateTime("READ_DTTM");
					MeterConfiguration_Id mtrConfigID = (MeterConfiguration_Id) sqlRow.getId("MTR_CONFIG_ID", MeterConfiguration.class);
					MeterRead_Id stopMeterReadID = (MeterRead_Id) sqlRow.getId("MR_ID", MeterRead.class); 
						
					// Check (and retrieve) if the meter has been removed after stopMRDateTime
					DateTime meterRemovedDttm = cmRetrieveMeterRemovalDate(mtrConfigID, spID, stopMRDateTime);								
					
					// Retrieve the starting read of the consumption
					BigDecimal startingRead = cmRetrieveRead(stopMeterReadID, parmConsumptionUOM);
					// Retrieve the latest meter read id after the service was stopped
					MeterRead_Id latestMeterReadIdAfterStop = cmRetrieveLatestMeterReadAfterServiceStop(mtrConfigID, stopMRDateTime, meterRemovedDttm);
	
					// In the event that there are no reads / consumption after the service was stopped, proceed to check the premise for vacant days threshold
					if (isNull(latestMeterReadIdAfterStop)) {
						cmValidatePremiseForMaxVacantDaysAllowed(stopMRDateTime, spID, parmFAType);
						prepState.close();
						return true;
					}
					// Retrieve the ending read of the consumption
					BigDecimal endingRead = cmRetrieveRead(latestMeterReadIdAfterStop, parmConsumptionUOM); 				
					// Compute for the consumption
					Register register = cmRetrieveRegister(mtrConfigID, parmConsumptionUOM);
					BigDecimal consumption = cmComputeConsumption(startingRead, endingRead, register);
					// Used the starting read (a.k.a. stop meter read) to get the scale to use
					int scaleValue = startingRead.scale();
					consumption = consumption.setScale(scaleValue, BigDecimal.ROUND_HALF_UP);
					BigDecimal consumptionThreshold = parmConsumptionThreshold.setScale(scaleValue, BigDecimal.ROUND_HALF_UP);
					
					// In the event that the consumption exceeds Batch Parameter 30: Threshold Amount, create disconnect FA
					if (consumption.compareTo(consumptionThreshold) > 0
							&& endingRead.compareTo(BigDecimal.ZERO) != 0) {
						// Create a Disconnect Field Activity
						// START CHANGE - PSREEKAN - 2016-09-26 - DEFECT#82480
//						cmCreateFieldActivity(spID, parmFAType);	
						cmCreateCase(spID);
						// END CHANGE - PSREEKAN - 2016-09-26 - DEFECT#82480
					}
					else {
						// Check if premise exceeded the maximum vacant days threshold
						cmValidatePremiseForMaxVacantDaysAllowed(stopMRDateTime, spID, parmFAType);
					}
				}			
				prepState.close();
			
			// START ADD - JHERNA - 2015-03-23 - DEFECT#3179370
			}
			// END ADD - JHERNA - 2015-03-23 - DEFECT#3179370
			return true;
		}

		/**
		 * Custom method which validates if the premise exceeded the maximum number of days a premise could be vacant.
		 * If the premise exceeded the Vacant Days Threshold, create a disconnect Field Activity
		 * @param mrDttm the stop meter read date time that will be used to compute the time interval.
		 * @param spID the service point being processed
		 * @param faType the field activity type to be used in the event that a FA needs to be created because the
		 *        premise exceeded the vacant days threshold.
		 */
		private void cmValidatePremiseForMaxVacantDaysAllowed(DateTime mrDttm, ServicePoint_Id spID, FieldActivityType faType) {
			// Compute the elapsed days after the stop read date
			TimeInterval timeInterval = this.getProcessDateTime().difference(mrDttm);
			BigInteger elapsedDays = BigInteger.valueOf(timeInterval.getTotalDays());
			// In the event that the elapsed days exceed the vacant days threshold parameter value, create a disconnect FA
			if (elapsedDays.compareTo(parmVacDaysThreshold) > 0) { 
				// START CHANGE - PSREEKAN - 2016-09-26 - DEFECT#82480
				// Create a Disconnect Field Activity
//				cmCreateFieldActivity(spID, faType);
				cmCreateCase(spID);
				// END CHANGE - PSREEKAN - 2016-09-26 - DEFECT#82480
			}	
		}
		
		/**
		 * Custom method which retrieves the earliest non-estimated read after the service was stopped. 
		 * Note: The selected read cannot be future dated.  
		 * @param meterConfigID the meter configuration
		 * @param stopMRDateTime the stop Meter Read Date Time
		 * @return the latest Meter Read ID after the service was stopped
		 */
		private MeterRead_Id cmRetrieveLatestMeterReadAfterServiceStop(MeterConfiguration_Id meterConfigID, DateTime stopMRDateTime,
				DateTime meterRemovedDttm) {
			
			MeterRead_Id returnValue = null;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT MR.READ_DTTM, MR.MR_ID ");
			stringBuilder.append("FROM CI_MR MR ");
			stringBuilder.append("WHERE MR.MTR_CONFIG_ID = :meterConfigID ");
			stringBuilder.append("AND MR.USE_ON_BILL_SW = :yesUseOnBill ");
			
			if (isNull(meterRemovedDttm)) {
				// Meter Reads after the Stop Read
				stringBuilder.append("AND READ_DTTM >= :stopMRDateTime ");				
			}
			else {
				// Meter Reads after the Stop Read and before the Meter Removal
				stringBuilder.append("AND READ_DTTM BETWEEN :stopMRDateTime AND :meterRemovedDttm ");
			}

			stringBuilder.append("AND MR.MR_ID IN (SELECT RR.MR_ID ");
			stringBuilder.append("                 FROM CI_REG_READ RR ");
			stringBuilder.append("                 WHERE RR.MR_ID = MR.MR_ID ");
			                      // Condition for None Estimate Reads only (no need to use feature configuration as it is overkill. Read Type Flag lookup is owned by product and cannot be modified)
			stringBuilder.append("                 AND RR.READ_TYPE_FLG NOT IN (:systemEstimate, :serviceProviderEstimate, :officeEstimate) ");
			stringBuilder.append("                ) ");
			// Condition to restrict future dated reads                
			stringBuilder.append("AND MR.READ_DTTM <= :processDateTime ");
			stringBuilder.append("ORDER BY MR.READ_DTTM DESC ");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("meterConfigID", meterConfigID);
			prepState.bindBoolean("yesUseOnBill", Bool.TRUE);
			
			if (isNull(meterRemovedDttm)) {
				prepState.bindDateTime("stopMRDateTime", stopMRDateTime);
			}
			else {
				prepState.bindDateTime("stopMRDateTime", stopMRDateTime);
				prepState.bindDateTime("meterRemovedDttm", meterRemovedDttm);
			}
			
			prepState.bindLookup("systemEstimate", ReadTypeLookup.constants.SYSTEM_ESTIMATE);
			prepState.bindLookup("serviceProviderEstimate", ReadTypeLookup.constants.SERVICE_PROVIDER_ESTIMATE);
			prepState.bindLookup("officeEstimate", ReadTypeLookup.constants.OFFICE_ESTIMATE);
			prepState.bindDateTime("processDateTime", this.getProcessDateTime());
			prepState.execute();
			
			if (prepState.list().size() > 0) {
				SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
				@SuppressWarnings("unused")
				DateTime mrDttm = (DateTime) sqlRow.getDateTime("READ_DTTM");				
				returnValue = (MeterRead_Id) sqlRow.getId("MR_ID", MeterRead.class);
			}			
			prepState.close();
			return returnValue;
		}
		/**
		 * Custom method which retrieves the actual Register Reading of the correct UOM from the Meter Read ID 
		 * @param mrID the meter read
		 * @param readUOM the UOM 
		 * @return the register reading 
		 */
		private BigDecimal cmRetrieveRead(MeterRead_Id mrID, UnitOfMeasure readUOM) {
			
			BigDecimal returnValue = BigDecimal.ZERO;			
			
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT RR.REG_READING ");
			stringBuilder.append("FROM CI_REG_READ RR, CI_REG REG ");
			stringBuilder.append("WHERE RR.MR_ID = :mrID ");
			stringBuilder.append("AND REG.REG_ID = RR.REG_ID ");
			stringBuilder.append("AND REG.UOM_CD = :uomCd ");
			stringBuilder.append("AND RR.READ_SEQ = REG.READ_SEQ ");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("mrID", mrID);
			prepState.bindId("uomCd", readUOM.getId());
			prepState.execute();
			
			if (prepState.list().size() > 0) {
				// Program is already using the specific Meter Read ID, so program needs to retrieve only one row
				SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
				returnValue = (BigDecimal) sqlRow.getBigDecimal("REG_READING");
			}					
			prepState.close();
			
			return returnValue;
			
		}
		
		// START DELETE - PSREEKAN - 2016-09-26 - DEFECT#82480
//		/**
//		 * Custom method which creates Pending Field Activity
//		 * @param spID The Service Point to create the FA
//		 * @param faType the FA Type
//		 */
//		private void cmCreateFieldActivity(ServicePoint_Id spID, FieldActivityType faType) {
//			
//			// Create Field Activity
//			startChanges();
//			FieldActivity_DTO faDTO = new FieldActivity_DTO();
//			faDTO.setFieldActivityTypeId(faType.getId());
//			faDTO.setCreationDateTime(this.getProcessDateTime());
//			// START CHANGES - JHERNA - 2015-10-07 - 3311665
//			//faDTO.setScheduleDateTimeStart(this.getProcessDateTime());
//			// Retreve the Schedule Date Time (process date time + modifier ensuring that this will fall on a business days)
//			DateTime scheduleDateTime = this.getProcessDateTime().addDays(parmFaSchedDateModifier.intValue());
//			WorkCalendar workCalendar = spID.getEntity().getPremise().fetchDivision().getWorkCalendar();
//			while (!workCalendar.isBusinessDay(scheduleDateTime.getDate())) {
//				// add 1 day to the schedule date time until it becomes a valid business day 
//				scheduleDateTime = scheduleDateTime.addDays(1);
//			}
//			faDTO.setScheduleDateTimeStart(scheduleDateTime);
//			// END CHANGES - JHERNA - 2015-10-07 - 3311665
//			faDTO.setServicePointId(spID);
//			faDTO.setUserId(this.getActiveContextUser().getId());
//			faDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.BACKGROUND);
//						
//			FieldActivityCreatorData faCreatorData = FieldActivityCreatorData.Factory.newInstance();
//			faCreatorData.setFaDTO(faDTO);
//			
//			FieldActivityCreator faCreator = FieldActivityCreator.Factory.newInstance();
//			FieldActivity fa = faCreator.addFieldActivity(faCreatorData);
//			
//			// Create FA Log
//			cmCreateFieldActivityLog(fa, 
//					FieldActivityLogTypeLookup.constants.CM_FIELD_ACTIVITY_CREATED,
//					CustomMessageRepositoryMGE.ccb009FACreationSource(this.getBatchControlId().getTrimmedValue()).getMessageText().trim());
//			saveChanges();
//			
//			// START ADD - JHERNA - 2015-03-23 - DEFECT#3179370
//			createdFACounter = createdFACounter.add(BigInteger.ONE);
//			// END ADD - JHERNA - 2015-03-23 - DEFECT#3179370
//		}
		
//		/**
//		 * Custom method which creates FA Logs on an existing Field Activity
//		 * @param fa the field activity to create logs on
//		 * @param faLogType the fa log type
//		 * @param faLogDetail the fa log detail
//		 */
//		private void cmCreateFieldActivityLog(FieldActivity fa, FieldActivityLogTypeLookup faLogType,
//				String faLogDetail) {
//			
//			FieldActivityLog_DTO faLogDTO = fa.getLogs().newChildDTO();
//			faLogDTO.setUser(this.getActiveContextUser().getId().getTrimmedValue());
//			faLogDTO.setDetails(faLogDetail);
//			faLogDTO.setLogDateTime(this.getProcessDateTime());
//			faLogDTO.setLogType(faLogType.trimmedValue());
//			fa.getLogs().add(faLogDTO, BigInteger.ONE);
//		}
		// END DELETE - PSREEKAN - 2016-09-26 - DEFECT#82480
		/**
		 * Custom method which creates Case
		 * @param spID The Service Point to create the Case
		 */
		private void cmCreateCase(ServicePoint_Id spID) {
			
			ToDoCase openCase = getOpenCase(spID);
			if(isNull(openCase)){
				// Create Case
				startChanges();
				
				CaseCreator caseCreatorComp = CaseCreator.Factory.newInstance();
				CaseCreatorData caseCreatorCompData = CaseCreatorData.Factory
						.newInstance();
				List<CaseCharacteristic_DTO> caseCharacteristics = new ArrayList<CaseCharacteristic_DTO>();
				ToDoCase_DTO caseDTO = new ToDoCase_DTO();
				
				// Set the Case Status and Condition to Initial
				caseDTO.setCaseStatusId(new CaseStatus_Id(getParameters().getCASE_TYPE_CD(), getParameters().getINITIAL_CASE_LIFECYCLE()));
				caseDTO.setPremiseId(spID.getEntity().getPremise().getId());
				caseDTO.setCaseCondition(CaseConditionLookup.constants.OPEN);
				caseDTO.setUserId(getActiveContextUser().getId());
				
				caseCharacteristics.add(createCaseCharacteristicDTO(getParameters().getSP_ID_CHAR(), BigInteger.ONE, spID.getTrimmedValue())); 
				caseCharacteristics.add(createCaseCharacteristicDTO(getParameters().getCASE_SOURCE_CHAR(), BigInteger.ONE, getBatchControlId().getTrimmedValue())); 
				
				// Set to do case DTO
				caseCreatorCompData.setToDoCaseDTO(caseDTO); 
				caseCreatorCompData.setCaseCharacteristics(caseCharacteristics);
				ToDoCase_Id toDoCaseID =  caseCreatorComp.createCase(caseCreatorCompData).getCaseId();
				
				// Create Case Log
				createCaseLogEntry(
						toDoCaseID.getEntity(),
						CustomMessageRepositoryMGE
						.ccb009CaseCreationSource(
								this.getBatchControlId().getTrimmedValue()));
				saveChanges();
				createdCaseCounter = createdCaseCounter.add(BigInteger.ONE);
			}
		}
		
		private ToDoCase getOpenCase(ServicePoint_Id spID){
			
			ToDoCase returnValue = null;
			StringBuilder queryString = new StringBuilder();
			queryString.append("SELECT toDoCase.CASE_ID");
			queryString.append(" FROM CI_CASE toDoCase");
			queryString.append(" WHERE CASE_TYPE_CD = :caseTypeCode");
			queryString.append(" AND CASE_COND_FLG = :conditionalFlag");
			queryString.append(" AND PREM_ID = :charPremiseId");
			
			PreparedStatement prepStatement = createPreparedStatement(queryString.toString(), getClass().getName());
			prepStatement.bindEntity("caseTypeCode", getParameters().getCASE_TYPE_CD());
			prepStatement.bindLookup("conditionalFlag", CaseConditionLookup.constants.OPEN);
			prepStatement.bindId("charPremiseId", spID.getEntity().getPremise().getId());
			prepStatement.execute();
			
			SQLResultRow sqlRow = (SQLResultRow) prepStatement.firstRow();
			if(notNull(sqlRow)){
				ToDoCase_Id toDoCaseId = (ToDoCase_Id) sqlRow.getId("CASE_ID", ToDoCase.class);
				if(notNull(toDoCaseId)){
					returnValue = toDoCaseId.getEntity();
				}
			}
			
			return returnValue;
		}
		/**
		 * Adds a Characteristic to a given ToDoCase.
		 * 
		 * @param charType
		 * @param toDoCase
		 * @param sequence
		 * @param value
		 */
		private static CaseCharacteristic_DTO createCaseCharacteristicDTO(
				CharacteristicType charType, BigInteger sequence, String value) {

			CaseCharacteristic_DTO caseCharDTO = new CaseCharacteristic_DTO();
			caseCharDTO.setId(new CaseCharacteristic_Id(charType, null,
					sequence));

			if (charType.getCharacteristicType().isPredefinedValue()) {
				caseCharDTO.setCharacteristicValue(value);
			} else if (charType.getCharacteristicType().isAdhocValue()
					|| charType.getCharacteristicType().isFileLocationValue()) {
				caseCharDTO.setAdhocCharacteristicValue(value);
			} else if (charType.getCharacteristicType().isForeignKeyValue()) {
				caseCharDTO.setCharacteristicValueForeignKey1(value);
			}

			return caseCharDTO;
		}
		
		/**
		 * This method creates case log entry
		 * 
		 * @param message
		 */
		private void createCaseLogEntry(ToDoCase toDoCase, ServerMessage message){
			
			//Retrieve the next SEQUENCE ID 
	        Query query = createQuery("FROM CaseLog caseLog WHERE caseLog.id.toDoCase = :toDoCase", getClass().getName());
	        query.bindId("toDoCase", toDoCase.getId());
	        query.addResult("maxResult", "MAX(caseLog.id.sequence)");

	        BigInteger seq = (BigInteger) query.firstRow();

			// Create the case log
			CaseLog_DTO caseLogDTO = createDTO(CaseLog.class);
			caseLogDTO.setId(new CaseLog_Id(toDoCase, seq.add(BigInteger.ONE)));
			caseLogDTO.setCaseStatusId(toDoCase.getCaseStatus().getId());
			//Start Change JVitug - INC0033320 - 2024-07-29
			//caseLogDTO.setLogType(CaseLogTypeLookup.constants.CREATED);
			caseLogDTO.setLogType(CaseLogTypeLookup.constants.SYSTEM);
			//End Change JVitug - INC0033320 - 2024-07-29
			caseLogDTO.setLogDateTime(getProcessDateTime());
			caseLogDTO.setUserId(getActiveContextUser().getId());
			caseLogDTO.setMessageId(message.getMessageId());

			// Add case log
			CaseLog caseLog = caseLogDTO.newEntity();

			// Add message parameters
			if(notNull(message.getMessageParameters())) {
				BigInteger index = BigInteger.ONE;
				Bool flag = Bool.FALSE;
				String messageParm = "";

				Iterator messageParmIterator = message.getMessageParameters().getParameters().iterator();
				CaseLogMessageParameter_DTO caseLogMessageParmDto = null;

				while(messageParmIterator.hasNext()){
					messageParm = (String) messageParmIterator.next();
					caseLogMessageParmDto = caseLog.getMessageParameters().newChildDTO();

					// If parameter string exceeds the length of 30, use another message variable.
					flag = Bool.FALSE;
					for (int i = 0; i <= messageParm.length(); i = i + 29) {
						if (i + 29 > messageParm.length()) {
							if(flag.isFalse()) {
								caseLogMessageParmDto.setMessageParameter(messageParm.substring(i, messageParm.length()));
								flag = Bool.TRUE;
							}
						}
						else {
							caseLogMessageParmDto.setMessageParameter(messageParm.substring(i, i + 29));
						}
						caseLogMessageParmDto.setId(new CaseLogMessageParameter_Id(caseLog, index));
						CaseLogMessageParameter caseLogMessageParm = caseLogMessageParmDto.newEntity();
						caseLog.getMessageParameters().add(caseLogMessageParm);
						index = index.add(BigInteger.ONE);
					}            
				}
			}
		}
		
		/**
		 * Custom method which calls the base routine to calculate the consumption given 2 reads and the register's number of digits left
		 * and taking into account the dial rollover.
		 * @param startReading the starting read
		 * @param endReading the ending read
		 * @param register the register to retrieve the number of digits left value
		 * @return BigDecimal value of the consumption between two reads
		 */
		private BigDecimal cmComputeConsumption(BigDecimal startReading, BigDecimal endReading, Register register) {
			
			BigDecimal returnValue = BigDecimal.ZERO;			
			try {
				/*
				 * Use the base routine CIPMDBRN which calculates the difference (a.k.a. consumption)
				 * between two register reads by taking the dial rollover into account.
				 */			
				CobolProgramCIPMDBRN cobolRoutine = CobolProgramCIPMDBRN.Factory.newInstance();
				CobolCopybookCICMDBRN cobolCopybook = cobolRoutine.getCobolCopybookCICMDBRN();
				// Set the input of the routine
				cobolCopybook.get_INPUT_WRK().set_START_READING(startReading);
				cobolCopybook.get_INPUT_WRK().set_END_READING(endReading);
				cobolCopybook.get_INPUT_WRK().set_NBR_OF_DGTS_LFT(register.getNumberOfDigitsLeft());			
				// Execute the routine
				cobolRoutine.callCobol();
				// Retrieve the ouput of the routine
				returnValue = cobolCopybook.get_OUTPUT_WRK().get_DIFFERENCE();
				
			}
			catch (Exception e) {
				// Error encountered while invoking base routine %1.
				addError(CustomMessageRepositoryMGE.commGenericErrorEncounteredInvokingBaseRoutine("CIPMDBRN"));
			}
			return returnValue;
		}
		/**
		 * Custom method which retrieves the correct register (of the specified UOM type) from the meter configuration 
		 * @param mtrConfigID the meter configuration id
		 * @param uom the unit of measure of the register to be retrieved
		 * @return the register which has the correct unit of measure from the meter configuration
		 */
		private Register cmRetrieveRegister(MeterConfiguration_Id mtrConfigID, UnitOfMeasure uom) {
			
			Register returnValue = null;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT REG_ID ");
			stringBuilder.append("FROM CI_REG REG ");
			stringBuilder.append("WHERE REG.MTR_ID = :mtrID ");
			stringBuilder.append("AND REG.UOM_CD = :uomCd ");
			stringBuilder.append("AND REG.EFF_DTTM = (SELECT MAX(REG2.EFF_DTTM) ");
			stringBuilder.append("                    FROM CI_REG REG2 ");
			stringBuilder.append("                    WHERE REG2.MTR_ID = REG.MTR_ID ");
			stringBuilder.append("                    AND REG2.UOM_CD = REG.UOM_CD ");
			stringBuilder.append("                    AND TO_DATE(REG2.EFF_DTTM) <= :procDt ");
			stringBuilder.append("                    ) ");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("mtrID", mtrConfigID.getEntity().getMeter().getId());
			prepState.bindId("uomCd", uom.getId());
			prepState.bindDate("procDt", this.getProcessDateTime().getDate());
			prepState.execute();			
			if (prepState.list().size() > 0) {
				SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
				Register_Id regID = (Register_Id) sqlRow.getId("REG_ID", Register.class);
				returnValue = regID.getEntity();
			}
			else {
				// Failed to retrieve effective register with (%1) UOM for Meter Configuration (%2)
				// 2015-07-30. SMiran. Defect 3259515. Start Change
				//addError(CustomMessageRepositoryMGE.ccb009FailedToRetrieveRegisterOfMeterConfig(mtrConfigID.getTrimmedValue(), uom.getId().getTrimmedValue()));
				addError(CustomMessageRepositoryMGE.ccb009FailedToRetrieveRegisterOfMeterConfig(
						uom.getId().getTrimmedValue(),mtrConfigID.getTrimmedValue()));
				// 2015-07-30. SMiran. Defect 3259515. End Change
			}
			prepState.close();
			return returnValue;
		}
		/**
		 * Custom method which retrieves the meter's removal date time (if any) after the service has been stopped.
		 * @param mtrConfigID meter configuration id
		 * @param spID service point 
		 * @param stopMRDttm the service's stop meter read date time
		 * @return returnValue the meter's removal date time (if any) after the service has been stopped.
		 */
		private DateTime cmRetrieveMeterRemovalDate(MeterConfiguration_Id mtrConfigID, ServicePoint_Id spID, DateTime stopMRDttm) {
			DateTime returnValue = null;
			
			StringBuilder stringBuilder = new StringBuilder();						
			stringBuilder.append("SELECT MAX(EVT1.READ_DTTM) RMV_DTTM ");
			stringBuilder.append("FROM CI_SP_MTR_EV_VW EVT1 ");
			stringBuilder.append("WHERE EVT1.MTR_CONFIG_ID = :mtrConfigID "); 
			stringBuilder.append("AND EVT1.SP_ID = :spID ");
			stringBuilder.append("AND EVT1.READ_DTTM >= :stopMRDttm ");
			stringBuilder.append("AND EVT1.SP_MTR_EVT_FLG = :removalEvent ");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("mtrConfigID", mtrConfigID);
			prepState.bindId("spID", spID);
			prepState.bindDateTime("stopMRDttm", stopMRDttm);
			prepState.bindLookup("removalEvent", ServicePointMeterEventTypeLookup.constants.REMOVAL);
			prepState.execute();
			
			if (prepState.list().size() > 0) {				
				SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
				returnValue = (DateTime) sqlRow.getDateTime("RMV_DTTM");
			}
			
			prepState.close();
			return returnValue;
		}
		// START ADD - JHERNA - 2015-03-23 - DEFECT#3179370
		// Criteria: SP must not have any pending FA of FA Type that matches Batch Parameter 40: Field Activity Type
		private Bool shouldProceed(ServicePoint_Id spID) {
			
			Bool returnValue = Bool.TRUE;			
			StringBuilder stringBuilder = new StringBuilder();

			stringBuilder.append("SELECT FA.FA_ID ");
			stringBuilder.append("FROM CI_FA FA ");
			stringBuilder.append("WHERE FA.SP_ID = :spID ");
			stringBuilder.append("AND FA.FA_TYPE_CD = :faTypeCd ");
			stringBuilder.append("AND FA.FA_STATUS_FLG = :pending ");

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("spID", spID);
			prepState.bindId("faTypeCd", parmFAType.getId());
			prepState.bindLookup("pending", FieldActivityStatusLookup.constants.PENDING);
			prepState.execute();
			if (prepState.list().size() > 0) {
				returnValue = Bool.FALSE;
			}
			return returnValue;
		}

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
			// In the event that the maximum number of FA to be created threshold is reached, raise a log message.
			// START CHANGE - PSREEKAN - 2016-09-26 - DEFECT#82480
//			if (notNull(parmMaxNbrFA)
//					&& createdFACounter.compareTo(parmMaxNbrFA) >= 0) {
//				LG.info("\n[CM-VPCNC]: ****Maximum Number of FA ("+parmMaxNbrFA+") to be created has been reached****");
//			}
			if (notNull(parmMaxNbrCASE)
					&& createdCaseCounter.compareTo(parmMaxNbrCASE) >= 0) {
				LG.info("\n[CM-VPCNC]: ****Maximum Number of CASE ("+parmMaxNbrCASE+") to be created has been reached****");
			}
			// END CHANGE - PSREEKAN - 2016-09-26 - DEFECT#82480
		}		
		// END ADD - JHERNA - 2015-03-23 - DEFECT#3179370
	}
}
