/**************************************************************************
* Program Name: CmTransitionReconnectQuoteToPaidStatus_Impl
* Program Title: CmTransitionReconnectQuoteToPaidStatus_Impl
* Author: Aya Masilang
* Creation Date: 2018-02-23
* Purpose: This algorithm will check if a self-service reconnect quote 
*          exists for the customer and if found, it will compare the 
*          payment amount to the "Standard Turn On or Avoid Severance 
*          Amount". If the required payment is made, the service task 
*          should be transitioned to paid status.  
* Functional Spec: CCB-CC-022-2.3
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  CCB-CC-022-2.3    Aya Masilang     2018-02-23    Initial Version
 *  CCB v2.6 Upgrade  Sharmayne Felipe 2018-07-25    Remove trim from SQLS that are no longer
 *                                                   needed.                                                                                                                                                                                                                                                                              
 ************************************************************************************************/
package com.splwg.cm.domain.admin.customerClass.algorithm.payFreeze;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.PaymentStatusLookup;
import com.splwg.ccb.domain.admin.customerClass.algorithm.payFreeze.CustomerClassPayFreezeAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.cm.api.lookup.CmQuotePortalParametersLookup;
import com.splwg.cm.api.lookup.CmServiceTaskCharacteristicTypesLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author AMasil
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = serviceTaskType, name = quoteServiceTaskType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = quoteSourceReconnectQuote, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = charTypeRequiredPaymentAmount, required = true, type = entity)})
 */
public class CmTransitionReconnectQuoteToPaidStatusAlgComp_Impl extends
        CmTransitionReconnectQuoteToPaidStatusAlgComp_Gen implements
        CustomerClassPayFreezeAlgorithmSpot {

    private Payment payment;
    private Account account;
    
    private BusinessObject quoteBusinessObject;
    private String quoteBusinessObjectActiveStatus;
    private String quoteBusinessObjectPaidStatus;
    private CharacteristicType saCharType;
    private CharacteristicType quoteSourceCharType;
    private CharacteristicType selectionCharType;
    

    private static final String QUOTE_PORTAL_FEAT_CONFIG = "CM-QPPARM";
    private static final String SVC_TASK_CHAR_TYPES_FEAT_CONFIG = "CMSVCTSKCTYP";
    private final static String STANDARD_CHAR_VALUE = "Standard";
    
    @Override
    public void invoke() {

        if (!this.isOnlineConnection()){
            return;
        }
        
        ServiceTask quoteServiceTask = retrieveActiveQuote();
        
        if(notNull(quoteServiceTask)){
            String reqPayAmtString = retrieveServiceTaskCharValue(quoteServiceTask, getCharTypeRequiredPaymentAmount());
            
            if(!reqPayAmtString.isEmpty()){
                //Required payment amount on the Active Quote
                Money reqPayAmt = new Money(reqPayAmtString, account.getCurrency().getId());
                
                //Total payment amounts posted to the account for the day.
                Money totalPayment = getTotalPayAmtForAcctOnProcessDt(account.getId(), quoteServiceTask.getCreationDateTime());
                
                //If the accumulated payment amount >= the required payment amount, transition the service task to PAID status.
                if(totalPayment.isGreaterThanOrEqual(reqPayAmt)){
                    updateServiceTask(quoteServiceTask);
                    
                }
            }
        }
    }

    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        CharacteristicType reqPayAmCharType = getCharTypeRequiredPaymentAmount();
        
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(reqPayAmCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        
        if(isNull(charEntityId.getEntity())){
            addError(CustomMessageRepository.CCB_CC_011_23_invalidCharType(reqPayAmCharType.getId().getTrimmedValue()));
        }
        
        // Retrieve values from the Quote Portal Feature Configuration.
        FeatureConfiguration featureConfiguration = 
                new FeatureConfiguration_Id(QUOTE_PORTAL_FEAT_CONFIG).getEntity();
        
        CmFeatureConfigurationRetriever featConfigRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
        featConfigRetriever.setParmWFMName(featureConfiguration);
        
        
        // Quote Business Object
        LookupValue optionType = CmQuotePortalParametersLookup.constants.QUOTE_BUSINESS_OBJECT.getLookupValue();
        featConfigRetriever.setParmOptType(optionType.fetchIdFieldValue());
        quoteBusinessObject = new BusinessObject_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
        
        // Quote Business Object Active Status
        optionType = CmQuotePortalParametersLookup.constants.QUOTE_BUSINESS_OBJECT_ACTIVE_STATUS.getLookupValue();
        featConfigRetriever.setParmOptType(optionType.fetchIdFieldValue());
        quoteBusinessObjectActiveStatus = featConfigRetriever.getMaxSequenceOptionValue().trim();
        
        // Quote Business Object Paid Status
        optionType = CmQuotePortalParametersLookup.constants.QUOTE_BUSINESS_OBJECT_PAID_STATUS.getLookupValue();
        featConfigRetriever.setParmOptType(optionType.fetchIdFieldValue());
        quoteBusinessObjectPaidStatus = featConfigRetriever.getMaxSequenceOptionValue().trim();
        
        // Retrieve values from the Service Task Characteristic Types Feature Configuration.
        featureConfiguration = 
                new FeatureConfiguration_Id(SVC_TASK_CHAR_TYPES_FEAT_CONFIG).getEntity();
        featConfigRetriever.setParmWFMName(featureConfiguration);

        // SA ID Characteristic Type
        optionType = CmServiceTaskCharacteristicTypesLookup.constants.SA_ID_CHARACTERISTIC_TYPE.getLookupValue();
        featConfigRetriever.setParmOptType(optionType.fetchIdFieldValue());
        saCharType = new CharacteristicType_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
        
        // Quote Source Characteristic Type
        optionType = CmServiceTaskCharacteristicTypesLookup.constants.QUOTE_SOURCE_CHARACTERISTIC_TYPE.getLookupValue();
        featConfigRetriever.setParmOptType(optionType.fetchIdFieldValue());
        quoteSourceCharType = new CharacteristicType_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
        
        // Selection Characteristic Type
        optionType = CmServiceTaskCharacteristicTypesLookup.constants.SELECTION_CHARACTERISTIC_TYPE.getLookupValue();
        featConfigRetriever.setParmOptType(optionType.fetchIdFieldValue());
        selectionCharType = new CharacteristicType_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
        
    }

    @Override
    public void setPayment(Payment arg0) {
        payment = arg0;
    }
    
    /**
     * This method updates the Active Quote Service Task to PAID status
     * @param quoteServiceTask
     */
    private void updateServiceTask(ServiceTask quoteServiceTask){
        
        //Read the Service Task Business Object
        BusinessObjectInstance serviceTaskType = BusinessObjectInstance.create(quoteServiceTask.getBusinessObject());
        serviceTaskType.set("serviceTaskId", quoteServiceTask.getId().getTrimmedValue());
        
        //Update the Service Task Business Object Status to PAID
        serviceTaskType = BusinessObjectDispatcher.read(serviceTaskType);  
        serviceTaskType.set("status", quoteBusinessObjectPaidStatus);
        BusinessObjectDispatcher.update(serviceTaskType);
    }
    
    /**
     * This method retrieves the Active Quote Service Task
     * @return ServiceTask
     */
    private ServiceTask retrieveActiveQuote() {

        ServiceTask quoteServiceTask = null;

        // Retrieve the CWR PA Quote Service Task that was created on the same day.
        StringBuilder getServiceTaskStr = new StringBuilder();

        getServiceTaskStr.append("SELECT ST.F1_SVC_TASK_ID, ");
        getServiceTaskStr.append("STC1.SRCH_CHAR_VAL AS QUOTE_SA ");
        getServiceTaskStr.append("FROM F1_SVC_TASK ST, F1_SVC_TASK_CHAR STC1, F1_SVC_TASK_CHAR STC2, F1_SVC_TASK_CHAR STC3 ");
        getServiceTaskStr.append("WHERE ST.F1_STASK_TYPE_CD  =:serviceTaskType ");
        // CCB v2.6 Upgrade - 2018-07-25 - Start Change
        //getServiceTaskStr.append("AND TRIM(ST.BO_STATUS_CD) =:boStatus ");
        getServiceTaskStr.append("AND ST.BO_STATUS_CD =:boStatus ");
        // CCB v2.6 Upgrade - 2018-07-25 - End Change
        getServiceTaskStr.append("AND TRUNC(ST.CRE_DTTM) =:processDate ");
        getServiceTaskStr.append("AND ST.BUS_OBJ_CD =:quoteBusinessObject ");
        getServiceTaskStr.append("AND STC1.F1_SVC_TASK_ID = ST.F1_SVC_TASK_ID ");
        getServiceTaskStr.append("AND STC1.CHAR_TYPE_CD = :saCharType ");
        getServiceTaskStr.append("AND STC1.SRCH_CHAR_VAL IN (SELECT PS.SA_ID FROM CI_PAY_SEG PS WHERE PS.PAY_ID = :payId) ");
        getServiceTaskStr.append("AND STC2.F1_SVC_TASK_ID = STC1.F1_SVC_TASK_ID ");
        getServiceTaskStr.append("AND STC2.CHAR_TYPE_CD =:quoteSourceCharType ");
        getServiceTaskStr.append("AND STC2.SRCH_CHAR_VAL =:quoteSource ");
        getServiceTaskStr.append("AND STC3.F1_SVC_TASK_ID = STC1.F1_SVC_TASK_ID ");
        getServiceTaskStr.append("AND STC3.CHAR_TYPE_CD =:selectionCharType ");
        getServiceTaskStr.append("AND STC3.SRCH_CHAR_VAL =:standard ");

        PreparedStatement getServiceTaskQuery = createPreparedStatement(
                getServiceTaskStr.toString(), getClass().getName());

        getServiceTaskQuery.bindEntity("saCharType", saCharType);
        getServiceTaskQuery.bindId("payId", payment.getId());
        getServiceTaskQuery.bindDate("processDate", getProcessDateTime().getDate());

        getServiceTaskQuery.bindId("serviceTaskType", getQuoteServiceTaskType().getId());
        getServiceTaskQuery.bindEntity("quoteBusinessObject", quoteBusinessObject);
        getServiceTaskQuery.bindStringProperty("boStatus", ServiceTask.properties.status, quoteBusinessObjectActiveStatus);

        getServiceTaskQuery.bindEntity("quoteSourceCharType", quoteSourceCharType);
        getServiceTaskQuery.bindStringProperty("quoteSource", ServiceTaskCharacteristic.properties.searchCharacteristicValue, getQuoteSourceReconnectQuote());

        getServiceTaskQuery.bindEntity("selectionCharType", selectionCharType);
        getServiceTaskQuery.bindStringProperty("standard", ServiceTaskCharacteristic.properties.searchCharacteristicValue, STANDARD_CHAR_VALUE.toUpperCase());

        SQLResultRow serviceTaskRow = getServiceTaskQuery.firstRow();

        if(notNull(serviceTaskRow)) {
            quoteServiceTask = serviceTaskRow.getEntity("F1_SVC_TASK_ID", ServiceTask.class);
            account = new ServiceAgreement_Id(serviceTaskRow.getString("QUOTE_SA")).getEntity().getAccount();
        }

        getServiceTaskQuery.close();

        return quoteServiceTask;
    }
    
    /**
     * This method retrieves the total Payment Amount on the Account for the day
     * @param acctId
     * @param svcTaskCreDttm
     * @return Money
     */
    private Money getTotalPayAmtForAcctOnProcessDt(Account_Id acctId, DateTime svcTaskCreDttm){
        
            Money totalAmount = Money.ZERO;
            StringBuilder getAmountString = new StringBuilder();
            getAmountString.append("SELECT SUM(PAY.PAY_AMT) AMT ");
            getAmountString.append("FROM CI_PAY PAY, ");
            getAmountString.append( "CI_PAY_EVENT EVT ");
            getAmountString.append("WHERE PAY.ACCT_ID = :acctId ");
            getAmountString.append( "AND EVT.CRE_DTTM > :svcTaskCreDttm ");
            getAmountString.append( "AND PAY.PAY_EVENT_ID = EVT.PAY_EVENT_ID ");
            getAmountString.append( "AND PAY.PAY_STATUS_FLG = :frozen ");

            PreparedStatement getAmountPrepStmt = createPreparedStatement(getAmountString.toString(), getClass().getName());
            getAmountPrepStmt.bindId("acctId", acctId);
            getAmountPrepStmt.bindDateTime("svcTaskCreDttm", svcTaskCreDttm);
            getAmountPrepStmt.bindLookup("frozen", PaymentStatusLookup.constants.FROZEN);
            
            SQLResultRow row = getAmountPrepStmt.firstRow();
            getAmountPrepStmt.close();

            if (notNull(row)){
                totalAmount = row.getMoney("AMT");
            }
            
            return totalAmount;
        }
    
    /**
     * This method will return the characteristic value of the given Service Task and Characteristic Type.
     * @param serviceTask 
     * @param charType
     * @return String
     */
    private String retrieveServiceTaskCharValue(ServiceTask serviceTask, CharacteristicType charType) {
        
        String charValue = "";
        
        ListFilter<ServiceTaskCharacteristic> serviceTaskCharFilter = serviceTask.getCharacteristics()
                .createFilter("WHERE this.id.characteristicType = :charType ORDER BY this.id.sequence DESC", 
                        getClass().getName());
        
        serviceTaskCharFilter.bindEntity("charType", charType);
        ServiceTaskCharacteristic serviceTaskChar = serviceTaskCharFilter.firstRow();
        
        if(notNull(serviceTaskChar)) {
            charValue = serviceTaskChar.getSearchCharacteristicValue();
        }
        
        return charValue.trim();
    }

}
