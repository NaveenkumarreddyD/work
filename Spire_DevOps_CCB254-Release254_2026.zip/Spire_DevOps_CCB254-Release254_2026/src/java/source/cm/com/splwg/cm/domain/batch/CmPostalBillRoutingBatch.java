/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPBXBL1 Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-02-10   EQuint      RI0008. Initial Version.   
 * 2016-05-18   MPang       Defect 3435872. Removed the DTO and changed it
 *                          into SQL so that the time stamp on the Bill Routing
 *                          records is updated in a similar manner with COBOL. 
 * 2016-09-16   SMiran      Defect 3510115. Fixed Total Amount Billed on batch
 * 							run tree.
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.  
 * 2025-11-14   EQuint      CCB25.4 Upgrade                   
 * *************************************************************************                
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
// 2016-09-16. SMiran. Defect 3510115. Start Delete
//import java.util.Currency;
//import java.util.Locale;
// 2016-09-16. SMiran. Defect 3510115. End Delete

import com.ibm.icu.text.DecimalFormat;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.StandardMessages;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.admin.billRouteType.entity.BillRouteType;
import com.splwg.ccb.domain.admin.billRouteType.entity.BillRouteType_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillRouting;
import com.splwg.ccb.domain.billing.bill.entity.BillRouting_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ServerMessage;
import com.splwg.shared.common.StringUtilities;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpbxbl1;

/**
 * @author Administrator
 *
@BatchJob (multiThreaded = true, rerunnable = true, modules = {},
 * softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)})
 */
public class CmPostalBillRoutingBatch extends CmPostalBillRoutingBatch_Gen {

	// CONSTANTS
	private static final String PRINT_KEY = "0010";
	private static final String NBR_COPY_ZERO = "0";
	private static final String THREAD_NUMBER_DESC = "Thread Number";

	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";

	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";

	public JobWork getJobWork() {
		Query<QueryResultRow> query = createQuery(" FROM BillRouting br " +
				" WHERE br.batchControlId = :batchCd " +
				" AND br.batchNumber = :batchNum " +
				" AND br.doNotExtract = :doNotExtract "
				, "getJobWork");

		query.bindId("batchCd", getBatchControlId());
		query.bindBigInteger("batchNum", getBatchNumber());
		query.bindBoolean("doNotExtract", Bool.FALSE);

		query.addResult("billId", "br.id.bill.id");
		query.addResult("seqNo", "br.id.sequence");
		query.addResult("noCopies", "br.numberOfBillCopies");
		query.addResult("routeTypeCd", "br.billRouteTypeId");

		query.orderBy("billId");
		query.orderBy("seqNo");
		return createJobWorkForQueryIterator(query.iterate(), this);
	}

	/*
	 * This method will create the Thread Work Unit per result row
	 */
	public ThreadWorkUnit createWorkUnit(QueryResultRow resultRow) {
		Bill_Id billId = (Bill_Id) resultRow.getId("billId", Bill.class);		
		BigInteger seqNo =  resultRow.getInteger("seqNo");		
		BigInteger noCopies =  resultRow.getInteger("noCopies");
		BillRouteType_Id billRouteTypeId =  (BillRouteType_Id) resultRow.getId("routeTypeCd", BillRouteType.class);

		ThreadWorkUnit unit = new ThreadWorkUnit();
		unit.setPrimaryId(new BillRouting_Id(billId, seqNo));
		unit.addSupplementalData("noCopies", noCopies);
		unit.addSupplementalData("routeTypeCd", billRouteTypeId);
		return unit;
	}

	public Class<CmPostalBillRoutingBatchWorker> getThreadWorkerClass() {
		return CmPostalBillRoutingBatchWorker.class;
	}

	public static class CmPostalBillRoutingBatchWorker extends
	CmPostalBillRoutingBatchWorker_Gen {

		// soft parameters
		private String filePath;
		private String fileName;
		private BigInteger maxErrors;

		// work variables
		private Cmpbxbl1 cmpbxbl1;
		private File extractFile;
		private BigInteger billCount;
		private BigDecimal totalAmountBilled;
		private BillRouting billRouting;
		private Connection connection;

		@Override
		public void initializeThreadWork(boolean flag)
				throws ThreadAbortedException, RunAbortedException {
			billCount = BigInteger.ZERO;
			totalAmountBilled = BigDecimal.ZERO;

			filePath = getParameters().getFILE_PATH();
			fileName = getParameters().getFILE_NAME();
			maxErrors = getParameters().getMAX_ERRORS();


			// assemble file name
			// if ?? is present in the file name, replace it with the thread number
			fileName = getParameters().getFILE_NAME();
			if (fileName.indexOf("??") >= 0) {
				fileName = fileName.replace("??", String.format("%02d", getBatchThreadNumber()));
			}
			else if (fileName.indexOf("?") >= 0) {
				if (getBatchThreadNumber().compareTo(BigInteger.valueOf(9)) > 0) {
					addError(StandardMessages.fieldMissing(THREAD_NUMBER_DESC));
				}
				fileName = fileName.replace("?", String.format("%01d", getBatchThreadNumber()));
			}

			if (isBlankOrNull(filePath)) {
				filePath = new File("").getAbsolutePath();
			}
			extractFile = new File(filePath, fileName);
			BufferedWriter outputWriter;
			try {
				outputWriter = new BufferedWriter(new FileWriter(extractFile));	
				try {
					outputWriter.close();	
				}
				catch(IOException ioe) {
					//If an error is encountered while opening the file, raise an error 
					addError(CustomMessageRepository.JACOB_FileCloseError(ioe.getMessage()));
				}
			}
			catch(IOException ioe) {
				//If an error is encountered while opening the file, raise an error 
				addError(CustomMessageRepository.JACOB_FileOpenError(ioe.getMessage()));
			}

			try {
				// initialize program
				initializeCobolProgram();
			}
			catch(Exception err) {
				addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), err.toString()));
			} 
		}

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		@Override
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			WorkUnitResult workUnit = new WorkUnitResult(true);
			billRouting = ((BillRouting_Id) unit.getPrimaryId()).getEntity();
			// reset program status and message numbers every unit
			cmpbxbl1.setProgramStatus(" ");
			cmpbxbl1.setMessageNbr(BigDecimal.ZERO);
			cmpbxbl1.setZmsgnMessageCatNbr(BigDecimal.ZERO);

			cmpbxbl1.setBxbl1InputWrkBatchCd(getBatchControlId().getTrimmedValue());
			cmpbxbl1.setBxbl1InputWrkBatchNbr(BigDecimal.valueOf(getBatchNumber().doubleValue()));
			cmpbxbl1.setInputWrkBatchRerunNbr(BigDecimal.valueOf(getBatchRerunNumber().doubleValue()));
			cmpbxbl1.setInputWrkBatchThreadNbr(BigDecimal.valueOf(getBatchThreadNumber().doubleValue()));
			cmpbxbl1.setBxbl1InputWrkBatchThreadCnt(BigDecimal.valueOf(getParameters().getThreadCount().doubleValue()));
			cmpbxbl1.setBxbl1InputWrkExtractFileName(extractFile.getAbsolutePath());

			cmpbxbl1.setBxbl1InputWrkBillId(billRouting.getId().getBillId().getTrimmedValue());
			cmpbxbl1.setBxbl1InputWrkSeqno(BigDecimal.valueOf(billRouting.getId().getSequence().doubleValue()));
			cmpbxbl1.setInputWrkNbrBillCopies(BigDecimal.valueOf(billRouting.getNumberOfBillCopies().doubleValue()));
			cmpbxbl1.setInputWrkBillRteTypeCd(billRouting.getBillRouteTypeId().getTrimmedValue());

			callCobol();
			return workUnit;
		}

		/*
		 * Initialize cobol program
		 */
		@SuppressWarnings("deprecation")
		private void initializeCobolProgram() throws Exception {
			FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
			RequestContext context = session.getRequestContext();

			// start update - equint - 2025-11-14 - CCB25.4 Upgrade
      		session.doWork(new ConnectionWork() {
      			
      			@Override
      			public void execute(Connection connection) throws SQLException {
      				try {  
      					String username = connection.getMetaData().getUserName();
      					String url = connection.getMetaData().getURL();

      					CobolSession.setLogSessionStartEnd(false);
      					cmpbxbl1=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpbxbl1.class);

      					cmpbxbl1.getSession().getDbSession().setUpdateConnection(connection);
      					cmpbxbl1.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");

      					// initialize linkage copybooks
      					cmpbxbl1.aa100Initialize(); 
      					
      					// set ZSTAT parameters

      					cmpbxbl1.setProcessDt(getProcessDateTime().getDate().toString());
      					cmpbxbl1.setProcessDttmSep("-");
      					cmpbxbl1.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
      					cmpbxbl1.setLkExpiryDt(Date.MAX.toString());
      					cmpbxbl1.setProgramStatus(" ");
      					if (session.isOnlineConnection()) { 
      						cmpbxbl1.setConnectionFlg(CONNECTION_ONLINE);
      					}
      					else {
      						cmpbxbl1.setConnectionFlg(CONNECTION_BATCH);
      					}

      					cmpbxbl1.setUserId(context.getUserId()); 
      					cmpbxbl1.setZstatLanguageCd(context.getLanguageCode());

      					if (context.ignoreWarnings()) {
      						cmpbxbl1.setIgnoreWarningSw(SWITCH_YES);
      					}
      					else {
      						cmpbxbl1.setIgnoreWarningSw(SWITCH_NO);
      					}

      					if (session.getBatchInstanceId() != null) {
      						cmpbxbl1.setZstatSchedulerId(new BigDecimal(session.getBatchInstanceId()));
      						cmpbxbl1.setSchedulerId(new BigDecimal(session.getBatchInstanceId()));

      					} else {
      						cmpbxbl1.setZstatSchedulerId(new BigDecimal(0));
      						cmpbxbl1.setSchedulerId(new BigDecimal(0));
      					}

      					cmpbxbl1.setAppSvcId(context.getSecurityServiceIdContext());

      					DatabaseHelper dbHelper = session.getDatabaseHelper();
      					cmpbxbl1.setDbMode(dbHelper.getCobolDBMode());
      					// CCB v2.6 Upgrade - 2018-05-31 - Start Change
      					//cmpbxbl1.setSplHighValue(cmpbxbl1.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
      					//cmpbxbl1.setSplLowValue(cmpbxbl1.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
      					
      					cmpbxbl1.setSplHighValue(cmpbxbl1.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
      		            cmpbxbl1.setSplLowValue(cmpbxbl1.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
      					// CCB v2.6 Upgrade - 2018-05-31 - End Change

      					cmpbxbl1.setEnvInfoEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()));

      					if (context.getRandomGeneratorSeedSet().isTrue()) {
      						cmpbxbl1.setRandomGenSeedSw(SWITCH_YES);
      						cmpbxbl1.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()));
      						cmpbxbl1.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()));
      						cmpbxbl1.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()));
      						cmpbxbl1.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()));
      					}
      					else {
      						cmpbxbl1.setRandomGenSeedSw(SWITCH_NO);
      					}

      					if (context.traceStandardOut()) { 
      						cmpbxbl1.setTrcStdoutSw(SWITCH_YES);
      					}
      					else {
      						cmpbxbl1.setTrcStdoutSw(SWITCH_NO);
      					}

      					if (context.traceProgramStart()) { 
      						cmpbxbl1.setTrcProgStartSw(SWITCH_YES);
      					}
      					else {
      						cmpbxbl1.setTrcProgStartSw(SWITCH_NO);
      					}

      					if (context.traceProgramExit()) { 
      						cmpbxbl1.setTrcProgExitSw(SWITCH_YES);
      					}
      					else {
      						cmpbxbl1.setTrcProgExitSw(SWITCH_NO);
      					}

      					if (context.traceSQL()) { 
      						cmpbxbl1.setTrcExecSqlSw(SWITCH_YES);
      					}
      					else {
      						cmpbxbl1.setTrcExecSqlSw(SWITCH_NO);
      					} 
      				}
      				catch(Exception e) {
    					throw new SQLException(e.getCause());
    				}
    				
    			}
    		});
			
//			SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//			connection = implementor.getConnectionProvider().getConnection();
//
//			String username = connection.getMetaData().getUserName();
//			String url = connection.getMetaData().getURL();
//
//			CobolSession.setLogSessionStartEnd(false);
//			cmpbxbl1=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpbxbl1.class);
//
//			cmpbxbl1.getSession().getDbSession().setUpdateConnection(connection);
//			cmpbxbl1.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//
//			// initialize linkage copybooks
//			cmpbxbl1.aa100Initialize(); 
//			
//			// set ZSTAT parameters
//
//			cmpbxbl1.setProcessDt(getProcessDateTime().getDate().toString());
//			cmpbxbl1.setProcessDttmSep("-");
//			cmpbxbl1.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//			cmpbxbl1.setLkExpiryDt(Date.MAX.toString());
//			cmpbxbl1.setProgramStatus(" ");
//			if (session.isOnlineConnection()) { 
//				cmpbxbl1.setConnectionFlg(CONNECTION_ONLINE);
//			}
//			else {
//				cmpbxbl1.setConnectionFlg(CONNECTION_BATCH);
//			}
//
//			cmpbxbl1.setUserId(context.getUserId()); 
//			cmpbxbl1.setZstatLanguageCd(context.getLanguageCode());
//
//			if (context.ignoreWarnings()) {
//				cmpbxbl1.setIgnoreWarningSw(SWITCH_YES);
//			}
//			else {
//				cmpbxbl1.setIgnoreWarningSw(SWITCH_NO);
//			}
//
//			if (session.getBatchInstanceId() != null) {
//				cmpbxbl1.setZstatSchedulerId(new BigDecimal(session.getBatchInstanceId()));
//				cmpbxbl1.setSchedulerId(new BigDecimal(session.getBatchInstanceId()));
//
//			} else {
//				cmpbxbl1.setZstatSchedulerId(new BigDecimal(0));
//				cmpbxbl1.setSchedulerId(new BigDecimal(0));
//			}
//
//			cmpbxbl1.setAppSvcId(context.getSecurityServiceIdContext());
//
//			DatabaseHelper dbHelper = session.getDatabaseHelper();
//			cmpbxbl1.setDbMode(dbHelper.getCobolDBMode());
//			// CCB v2.6 Upgrade - 2018-05-31 - Start Change
//			//cmpbxbl1.setSplHighValue(cmpbxbl1.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//			//cmpbxbl1.setSplLowValue(cmpbxbl1.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//			
//			cmpbxbl1.setSplHighValue(cmpbxbl1.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//            cmpbxbl1.setSplLowValue(cmpbxbl1.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//			// CCB v2.6 Upgrade - 2018-05-31 - End Change
//
//			cmpbxbl1.setEnvInfoEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()));
//
//			if (context.getRandomGeneratorSeedSet().isTrue()) {
//				cmpbxbl1.setRandomGenSeedSw(SWITCH_YES);
//				cmpbxbl1.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()));
//				cmpbxbl1.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()));
//				cmpbxbl1.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()));
//				cmpbxbl1.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()));
//			}
//			else {
//				cmpbxbl1.setRandomGenSeedSw(SWITCH_NO);
//			}
//
//			if (context.traceStandardOut()) { 
//				cmpbxbl1.setTrcStdoutSw(SWITCH_YES);
//			}
//			else {
//				cmpbxbl1.setTrcStdoutSw(SWITCH_NO);
//			}
//
//			if (context.traceProgramStart()) { 
//				cmpbxbl1.setTrcProgStartSw(SWITCH_YES);
//			}
//			else {
//				cmpbxbl1.setTrcProgStartSw(SWITCH_NO);
//			}
//
//			if (context.traceProgramExit()) { 
//				cmpbxbl1.setTrcProgExitSw(SWITCH_YES);
//			}
//			else {
//				cmpbxbl1.setTrcProgExitSw(SWITCH_NO);
//			}
//
//			if (context.traceSQL()) { 
//				cmpbxbl1.setTrcExecSqlSw(SWITCH_YES);
//			}
//			else {
//				cmpbxbl1.setTrcExecSqlSw(SWITCH_NO);
//			} 
      		
      	// end update - equint - 2025-11-14 - CCB25.4 Upgrade
		}

		private void callCobol() {
			try {
				cmpbxbl1.cobolMain();
			}catch(Exception _ex) {
				Throwable ex=_ex;
				
				while(ex.getCause()!=null) ex=ex.getCause();

				if(ex instanceof Stop) {
					// if message number and category are not 0, meaning a server message is passed from the jacob code
					if (cmpbxbl1.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
							&& cmpbxbl1.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {

						// pass the parameter to the server message
						MessageParameters messageparameters = new MessageParameters();
						for (int i = 1; i <= 9; i++) {
							try { 
								String parmValue = cmpbxbl1.getMessageParm(i);
								if (notBlank(parmValue)) {
									messageparameters.addRawString(parmValue.trim());
								}
							}
							catch(IndexOutOfBounds e) {
								break;
							}

						}
						MessageCategory_Id categoryId = new MessageCategory_Id(cmpbxbl1.getZmsgnMessageCatNbr().toBigInteger());
						ServerMessage serverMessage = 
								ServerMessageFactory.Factory.newInstance().createMessage(
										categoryId, cmpbxbl1.getMessageNbr().intValue(), messageparameters);

						// info
						if (cmpbxbl1.getMessageSeverity().compareTo(
								MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
							logInfo(serverMessage);
						}
						// warning
						else if (cmpbxbl1.getMessageSeverity().compareTo(
								MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
							logWarning(serverMessage);
						}
						// error
						else {
							logError(serverMessage);
						}
					}
					//Start Delete - 2016-05-18 - MPang - Defect 3435872
					//BillRouting_DTO dto = billRouting.getDTO();
					//dto.setExtractDateTime(getProcessDateTime());
					//billRouting.setDTO(dto);
					//End Delete - 2016-05-18 - MPang - Defect 3435872

					//Start Add - 2016-05-18 - MPang - Defect 3435872
					PreparedStatement billRoutingPreStmt = createPreparedStatement("UPDATE " +
					        " CI_BILL_ROUTING " +
					        " SET EXTRACT_DTTM = :extractDttm " +
					        " WHERE " +
					        " BILL_ID = :billId " +
					        " AND SEQNO = :seqNo " +
					        " AND BATCH_CD = :batchCd " +
					        " AND BATCH_NBR = :batchNumber " +
					        " AND NO_BATCH_PRT_SW = 'N' ", getClass().getName());

					billRoutingPreStmt.bindId("billId", billRouting.getId().getBillId());
					billRoutingPreStmt.bindDateTime("extractDttm", getProcessDateTime());
					billRoutingPreStmt.bindBigInteger("seqNo", billRouting.getId().getSequence());
					billRoutingPreStmt.bindId("batchCd", getBatchControlId());
					billRoutingPreStmt.bindBigInteger("batchNumber", getBatchNumber());
					billRoutingPreStmt.executeUpdate();
					billRoutingPreStmt.close();
					//End Add - 2016-05-18 - MPang - Defect 3435872
					
					billCount = billCount.add(cmpbxbl1.getOutputWrkBillCnt().toBigInteger());
					// 2016-09-16. SMiran. Defect 3510115. Start Change
					//totalAmountBilled = totalAmountBilled.add(BigDecimal.valueOf(cmpbxbl1.getBxbl1OutputWrkTotAmtBilled().doubleValue()));
					totalAmountBilled = BigDecimal.valueOf(cmpbxbl1.getBxbl1OutputWrkTotAmtBilled().doubleValue());
					// 2016-09-16. SMiran. Defect 3510115. End Change
					
				}
				else  {
					addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), _ex.toString()));
				}
			}
		}

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException,
		RunAbortedException {						
		
			String record = StringUtilities.padRight(PRINT_KEY, 26);

			record += StringUtilities.padRight(NBR_COPY_ZERO, 177);
			record += StringUtilities.padRight(getBatchControlId().getTrimmedValue(), 8);
			record += StringUtilities.leftPadWithZeros(getBatchNumber().toString(), 10);
			record += StringUtilities.leftPadWithZeros(getBatchRerunNumber().toString(), 10);
			record += StringUtilities.leftPadWithZeros(billCount.toString(), 10);
			record += StringUtilities.padRight(getProcessDateTime().toString() + ".000000", 26);
			record += StringUtilities.leftPadWithZeros(getLowIdForThread(Bill_Id.FIELD_SIZE), 12);
			record += StringUtilities.leftPadWithZeros(getHighIdForThread(Bill_Id.FIELD_SIZE), 12);
			record += StringUtilities.leftPadWithZeros(getBatchThreadNumber().toString(), 10);
			record += StringUtilities.leftPadWithZeros(getParameters().getThreadCount().toString(), 10);
			if (totalAmountBilled.signum() == -1) {
				record += "-";	
			} else {
				record += "+";
			}			
			record += StringUtilities.leftPadWithZeros(String.format("%.2f",totalAmountBilled).replaceAll("[^0-9]",""), 15);			

			try {				
				if (isBlankOrNull(filePath)) {
					filePath = new File("").getAbsolutePath();
				}
				extractFile = new File(filePath, fileName);
				BufferedWriter bufferedWriter= new BufferedWriter(new FileWriter(extractFile,true));					
				bufferedWriter.write(record);
				bufferedWriter.close();
				
				// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//				connection.close();
				// end delete - equint - 2025-11-14 - CCB25.4 Upgrade
			} catch (IOException e) {
				addError(CustomMessageRepository.JACOB_FileWriteError(e.getMessage()));
			}
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//            catch(SQLException se) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getIdValue(), se.getMessage()));
//            }
			// end delete - equint - 2025-11-14 - CCB25.4 Upgrade
			
			/* Write Informational Message on Number of Bills Extracted and Total Amount Billed */
			logInfo(CustomMessageRepository.RI0008_numberOfBillsCreated(billCount.toString()));
			// 2016-09-16. SMiran. Defect 3510115. Start Change
			//logInfo(CustomMessageRepository.RI0008_totalAmountBilled(Currency.getInstance(Locale.US).getSymbol() + totalAmountBilled.toString()));
			double amount = Double.parseDouble(totalAmountBilled.toString());
			DecimalFormat formatter = new DecimalFormat("#,###.00");
			logInfo(CustomMessageRepository.RI0008_totalAmountBilled(formatter.format(amount)));
			// 2016-09-16. SMiran. Defect 3510115. End Change
		}

	}

}
