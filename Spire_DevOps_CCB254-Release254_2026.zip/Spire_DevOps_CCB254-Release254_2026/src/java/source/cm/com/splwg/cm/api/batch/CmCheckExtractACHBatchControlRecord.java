/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Column Delimited Record class for ACH Batch Control
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-05-27   RDizon  CCB041. Initial version.        
 **************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

/**
 * @author RDizon
 */
public class CmCheckExtractACHBatchControlRecord extends ColumnDelimitedRecord {
    
    public CmCheckExtractACHBatchControlRecord() {
        super(11);
    }
 
    public void setRecordType(String value) {
        this.rightPadColumn(1, 1, value);
    }

    public void setServiceClassCode(String value) {
        this.rightPadColumn(2, 3, value);
    }

    public void setEntryCount(String value) {
        this.rightPadColumn(3, 6, value);
    }

    public void setEntryHash(String value) {
        this.rightPadColumn(4, 10, value);
    }

    public void setTotalDebitEntryDollarAmount(String value) {
        this.rightPadColumn(5, 12, StringUtilities.leftPadWithZeros(value, 12));
    }

    public void setTotalCreditEntryDollarAmount(String value) {
        this.rightPadColumn(6, 12, StringUtilities.leftPadWithZeros(value, 12));
    }

    public void setCompanyId(String value) {
        this.rightPadColumn(7, 10, value);
    }

    public void setMessageAuthenticationCode(String value) {
        this.rightPadColumn(8, 19, value);
    }

    public void setReserved(String value) {
        this.rightPadColumn(9, 6, value);
    }

    public void setOriginatingDFIId(String value) {
        this.rightPadColumn(10, 8, value);
    }

    public void setBatchNumber(String value) {
        this.rightPadColumn(11, 7, value);
    }

}
