/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Algorithm - Override Credit Review Date
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2019-11-20   DLampa  CCB009.1. Initial Version.
 **************************************************************************/

package com.splwg.cm.domain.admin.customerClass;

import java.math.BigInteger;

import com.splwg.base.api.Query;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.domain.common.workCalendar.WorkCalendar;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.SpecialRoleLookup;
import com.splwg.ccb.domain.admin.customerClass.algorithm.postBillCompletion.CustomerClassPostBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.Bill_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author dlampa
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = creditReviewOverrideDays, type = integer, required = true)})
 */
public class CmOverrideCreditReviewDateAlgComp_Impl 
        extends CmOverrideCreditReviewDateAlgComp_Gen 
        implements CustomerClassPostBillCompletionAlgorithmSpot {

    // Soft Parameters
    private BigInteger creditReviewOverrideDays;

    // Hard Parameters
    private Bill bill;

    public void setBill(Bill bill) {
        this.bill = bill;
    }

    public void invoke() {
        Bill_DTO billDTO = bill.getDTO();

        // Check if bill has final-billed deposit SA with a credit balance
        if (checkFinalBilledDepositSACreditBalance().isTrue()){            
            // Override the credit review date
            billDTO.setNextCreditReviewDate(processWorkdayReviewDate(bill.getBillDate().addDays(creditReviewOverrideDays.intValue())));
            bill.setDTO(billDTO);
        } else {
            // Otherwise, check if the bill segments for all billable SAs (except billable charge SAs) are closing segments
            if (getClosingBillSegments().isTrue()){
                // Check if the bill's balance is a credit.
                Money billAmount = getBillAmount();

                if(billAmount.compareTo(Money.ZERO) < 0){
                    // If all bill segments are closing segments, override the credit review date
                    billDTO.setNextCreditReviewDate(processWorkdayReviewDate(bill.getBillDate().addDays(creditReviewOverrideDays.intValue())));
                    bill.setDTO(billDTO);
                }           
            }           
        }

    }


    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        // Retrieve the soft parameters
        creditReviewOverrideDays = getCreditReviewOverrideDays();

        if (creditReviewOverrideDays.compareTo(BigInteger.ZERO) <= 0){
            addError(CustomMessageRepositorySpireOne.cmCcb0093CreditReviewOverrideDaysInvalid(creditReviewOverrideDays));
        }
    }
    
    /**
     * Check if the bill has any closing segment for a deposit SA. If so, determine if it has a credit balance.
     * @return Bool
     */
    private Bool checkFinalBilledDepositSACreditBalance() {
        
        StringBuilder queryString = new StringBuilder();
        queryString.append("FROM BillSegment bs, ");
        queryString.append(     "ServiceAgreement sa, ");
        queryString.append(     "ServiceAgreementType sat ");
        queryString.append("WHERE bs.billId = :billId ");
        queryString.append("AND bs.serviceAgreement = sa.id ");
        queryString.append("AND sa.serviceAgreementType.id.division = sat.id.division ");
        queryString.append("AND sa.serviceAgreementType.id.saType = sat.id.saType ");
        queryString.append("AND sat.specialRole = :specialRole ");
        queryString.append("AND bs.billSegmentStatus = :bsegStat ");
        queryString.append("AND bs.isClosingBillSegment = :true ");

        Query<ServiceAgreement> finalBillSegQuery = createQuery(queryString.toString(), getClass().getName());

        finalBillSegQuery.bindEntity("billId", bill);
        finalBillSegQuery.bindLookup("bsegStat", BillSegmentStatusLookup.constants.FROZEN);
        finalBillSegQuery.bindLookup("specialRole", SpecialRoleLookup.constants.CASH_DEPOSIT);
        finalBillSegQuery.bindBoolean("true", Bool.TRUE);
        finalBillSegQuery.addResult("serviceAgreement", "bs.serviceAgreement");

        ServiceAgreement sa = finalBillSegQuery.firstRow();

        if(notNull(sa)){
            if(sa.getCurrentBalance().compareTo(Money.ZERO) < 0){
                return Bool.TRUE;
            } else {
                return Bool.FALSE;
            }
        } else {
            return Bool.FALSE;
        }
        
    }
    
    /**
     * Check if the bill only has closing bill segments (except for billable charge SAs).
     * @return Bool
     */
    private Bool getClosingBillSegments() {

        StringBuilder queryString = new StringBuilder();
        queryString.append("FROM BillSegment bs, ");
        queryString.append(     "ServiceAgreement sa, ");
        queryString.append(     "ServiceAgreementType sat ");
        queryString.append("WHERE bs.billId = :billId ");
        queryString.append("AND bs.serviceAgreement = sa.id ");
        queryString.append("AND sa.serviceAgreementType.id.division = sat.id.division ");
        queryString.append("AND sa.serviceAgreementType.id.saType = sat.id.saType ");
        queryString.append("AND sat.specialRole <> :specialRole ");
        queryString.append("AND bs.billSegmentStatus = :bsegStat ");
        queryString.append("AND bs.isClosingBillSegment = :false ");

        Query nonClosingBillSegQuery = createQuery(queryString.toString(), getClass().getName());

        nonClosingBillSegQuery.bindEntity("billId", bill);
        nonClosingBillSegQuery.bindLookup("bsegStat", BillSegmentStatusLookup.constants.FROZEN);
        nonClosingBillSegQuery.bindLookup("specialRole", SpecialRoleLookup.constants.BILLABLE_CHARGE);
        nonClosingBillSegQuery.bindBoolean("false", Bool.FALSE);
        nonClosingBillSegQuery.addResult("bsegId", "bs.id");

        // If not all bill segments are closing, return false
        if (notNull(nonClosingBillSegQuery.firstRow())){
            return Bool.FALSE;
        } else {
            return Bool.TRUE;
        }

    }
    
    /**
     * Returns the Total current amount of the Bill's SAs.
     * @return Total current amount
     */
    private Money getBillAmount() {

        StringBuilder queryString = new StringBuilder();
        queryString.append("FROM BillSaBalanceSnapshot bs ");
        queryString.append("WHERE bs.id.bill = :bill ");
        
        Query<Money> getBillAmountQuery = createQuery(queryString.toString(), getClass().getName());
        
        getBillAmountQuery.bindEntity("bill", bill);        
        getBillAmountQuery.addResult("totalAmount", "SUM(bs.currentAmount)");
        
        Money billAmount = (Money)getBillAmountQuery.firstRow();
        
        if(notNull(billAmount)){
            return billAmount;
        }
        return Money.ZERO;
        
    }    

    /**
     * If the computed Credit Review Date is not a workday, adjust it to the following workday. 
     * @return newReviewDate
     * @return date
     */
    private Date processWorkdayReviewDate(Date newReviewDate) {
        Account account = bill.getAccount();
        
        // Make sure that the Review Date is not on a weekend or a holiday.
        WorkCalendar workCalendar = account.fetchDivision().getWorkCalendar();
        while (!workCalendar.isBusinessDay(newReviewDate)) {
            newReviewDate = newReviewDate.addDays(1);            
        }
        
        return newReviewDate;
        
    }    
}
