/* ***************************************************************************
 * PROGRAM DESCRIPTION: 
 * 
 * Common Payment Upload for Spire AL and Gulf Batch Process
 * 
 * This job reads and uploads payment files from Spire Alabama and Gulf payment 
 * vendors that use a common file layout.
 *
 * It will be used to accept payment files from the following vendors:
 *     - DebtNext
 *     - Western Union (Speedpay)
 *     - Fidelity 
 *                                                  
 ******************************************************************************                                                                 
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:             Reason:                                     
 * YYYY-MM-DD   IN              Reason text.                                
 *           
 * 2021-03-30   SRoman          CCB029.1. Initial Version.
 * 2021-05-12   NMendo          CCB029.Issue1. Update logic on retrieving 
 *                              Tender Source. Update Parsing of Account Number 
 *                              field. Fix issue on incorrect Total Tenders 
 *                              Amount and Total Number of Tenders.
 * 2021-06-21   RDizon          CCB029.Issue2. Post 13-digit input Account 
 *                              Numbers to Suspense.
 * 2021-06-23   NMendo          CCB029.Issue4. Disable error when CIS Division and 
 *                              Pay Process combination does not have equivalent 
 *                              Tender Source, then process the Account as Suspense.
 * 2021-09-17   NMendo          Defect 4595996. Added default payment batch 
 *                              number parameter.
 *****************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.lookup.LookupField_Id;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.domain.common.masterConfiguration.MasterConfiguration_Id;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.DepositControlStagingStatusLookup;
import com.splwg.ccb.api.lookup.PaymentTenderStagingStatusLookup;
import com.splwg.ccb.api.lookup.TenderControlStatusLookup;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource_Id;
import com.splwg.ccb.domain.admin.tenderType.entity.TenderType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging_Id;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging_Id;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentTenderUpload_DTO;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentTenderUpload_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;

/**
 * @author SRoman
 *
@BatchJob (modules = {}, multiThreaded = false, rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PAY_PROC_NM, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = tenderSource, name = TENDER_SOURCE_CD_DEFAULT, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = tenderType, name = TENDER_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = businessObject, name = TNDR_SRC_MASTER_CONFIG_BO, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = PYMT_BATCH_NBR, required = true, type = string)})
 */
public class CmCommonPaymentUploadForAlabamaGulfBatch extends
        CmCommonPaymentUploadForAlabamaGulfBatch_Gen {
    
    // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
    // Constants
    private static final String PAY_PROCESS_NAMES_LOOKUP = "CM_PAY_PROC_NM_FLG";
    private static final String BATCH_PARM_NAME_PAY_PROC_NM = "PAY_PROC_NM";
    private static final String BATCH_PARM_NAME_TNDR_SRC_MASTER_CONFIG_BO = "TNDR_SRC_MASTER_CONFIG_BO";
    // End Add - NMendo - CCB029.Issue1 -  2021-05-12

    public JobWork getJobWork() {
        ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        arrayList.add(threadWorkUnit);
        return createJobWorkForThreadWorkUnitList(arrayList);
    }

    @Override
    public void validateSoftParameters(boolean isNewRun) {
        String parmFilePath = getParameters().getFILE_PATH().trim();
        String parmFileName = getParameters().getFILE_NAME().trim();
        // Start Change - NMendo - CCB029.Issue1 -  2021-05-12
        //LookupField cisTenderSrceLookup = getParameters().getCIS_DIV_TNDR_SRCE_LOOKUP();
        //String cisDivStr;
        //String tenderSrcStr;
        //CisDivision_Id lookupCisDivId = null;
        //TenderSource_Id lookupTndrSrcId = null;
        String parmPayProcessName = getParameters().getPAY_PROC_NM().trim();
        BusinessObject parmMasterConfigBO = getParameters().getTNDR_SRC_MASTER_CONFIG_BO();
        // End Change - NMendo - CCB029.Issue1 -  2021-05-12
        
        // Validate if the file path parameter exists
        File folder = new File(parmFilePath);
        if(!(folder.exists() && folder.isDirectory())) {
            addError(CustomMessageRepositorySpireOne.CCB029_1_invalidFilePath(parmFilePath));  
        }
        
        // Validate if the file exists in the file path parameter
        File inputFile = new File(parmFilePath, parmFileName);
        if(!inputFile.exists() || !inputFile.canRead()) {
            addError(CustomMessageRepositorySpireOne.CCB029_1_invalidFileName(parmFileName)); 
        }
        
        // Start Delete - NMendo - CCB029.Issue1 -  2021-05-12
        // Validate that each CIS Division in the Lookup Value is a valid CIS Division
        //StringBuilder validateCisDiv = new StringBuilder();
        //
        //validateCisDiv.append("SELECT FIELD_VALUE FROM CI_LOOKUP_VAL WHERE FIELD_NAME = :lookupField ");
        //PreparedStatement validateCisDivQry = createPreparedStatement(validateCisDiv.toString(), getClass().getName());
        //validateCisDivQry.bindEntity("lookupField", cisTenderSrceLookup);
        //
        //if(validateCisDivQry.list().size() == 0) {
        //    addError(CustomMessageRepositorySpireOne.CCB029_1_emptyLookup(cisTenderSrceLookup.getId().getTrimmedValue()));
        //}
        //
        //for(SQLResultRow row : validateCisDivQry.list()) {
        //    cisDivStr = row.getString("FIELD_VALUE").trim();
        //    lookupCisDivId = new CisDivision_Id(cisDivStr);
        //    if(isNull(lookupCisDivId.getEntity())){
        //        addError(CustomMessageRepositorySpireOne.CCB029_1_invalidCisDivision(cisTenderSrceLookup.getId().getTrimmedValue(), cisDivStr));
        //    }
        //}
        //
        // Validate that each Tender Source in the Lookup Value Description is a valid Tender Source
        //StringBuilder validateTenderSrc = new StringBuilder();
        //
        //validateTenderSrc.append("SELECT DESCR FROM CI_LOOKUP_VAL_L WHERE FIELD_NAME = :lookupField ");
        //PreparedStatement validateTenderSrcQry = createPreparedStatement(validateTenderSrc.toString(), getClass().getName());
        //validateTenderSrcQry.bindEntity("lookupField", cisTenderSrceLookup);
        //
        //for(SQLResultRow row : validateTenderSrcQry.list()) {
        //    tenderSrcStr = row.getString("DESCR").trim();
        //    lookupTndrSrcId = new TenderSource_Id(tenderSrcStr);
        //    if(isNull(lookupTndrSrcId.getEntity())) {
        //        addError(CustomMessageRepositorySpireOne.CCB029_1_invalidTenderSource(cisTenderSrceLookup.getId().getTrimmedValue(), tenderSrcStr));
        //    }
        //}
        //
        //validateCisDivQry.close();
        //validateTenderSrcQry.close();
        // End Delete - NMendo - CCB029.Issue1 -  2021-05-12
        
        // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
        // Pay Process Name must be a valid value for the CM_PAY_PROC_NM_FLG lookup
        LookupValue_Id lookupValueID = new LookupValue_Id(new LookupField_Id(PAY_PROCESS_NAMES_LOOKUP), parmPayProcessName);
        if(isNull(lookupValueID.getEntity())) {
             addError(CustomMessageRepositorySpireOne.CCB029_invalidLookupValue(BATCH_PARM_NAME_PAY_PROC_NM,parmPayProcessName, PAY_PROCESS_NAMES_LOOKUP));
        }
        
        // Tender Source Master Configuration BO must be a valid Master Configuration BO
        MasterConfiguration_Id masterConfigId = new MasterConfiguration_Id(parmMasterConfigBO.getId());
        if (isNull(masterConfigId.getEntity())) {
            addError(CustomMessageRepositorySpireOne.CCB029_invalidMasterConfigBO(BATCH_PARM_NAME_TNDR_SRC_MASTER_CONFIG_BO,parmMasterConfigBO.getId().getTrimmedValue()));
        }
        // End Add - NMendo - CCB029.Issue1 -  2021-05-12
    }

    public Class<CmCommonPaymentUploadForAlabamaGulfBatchWorker> getThreadWorkerClass() {
        return CmCommonPaymentUploadForAlabamaGulfBatchWorker.class;
    }

    public static class CmCommonPaymentUploadForAlabamaGulfBatchWorker extends
            CmCommonPaymentUploadForAlabamaGulfBatchWorker_Gen {
    	
        // Constant Variables
        private static final String BLANK = "";
        private static final String DASH = "-";
        private static final String EXT_BATCH_ID = "00001";
        // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
        private static final String COMMA = ",";
        // End Add - NMendo - CCB029.Issue1 -  2021-05-12
        
        // Soft Parameter Variables
        private String parmFilePath;
        private String parmFileName;
        // Start Change - NMendo - CCB029.Issue1 -  2021-05-12
        //private LookupField cisTenderSrceLookup;
        private String parmPayProcessName;
        private BusinessObject parmMasterConfigBO;
        // End Change - NMendo - CCB029.Issue1 -  2021-05-12
        private TenderSource defaultTenderSource;
        private TenderType tenderType;
        // Start Add - NMendo - Defect 4595996 - 2021-09-17
        private String parmPaymentBatchNumber;
        // End Add - NMendo - Defect 4595996 - 2021-09-17
        
        // Working Variables
        private BufferedReader bufferedReader;
        private String recordLine;
        private CisDivision_Id tempCisDivId = null;
        // Start Delete - NMendo - CCB029.Issue1 -  2021-05-12
        //private CisDivision_Id cisDivId_2 = null;
        //private CisDivision_Id cisDivId_1 = null;
        //private BigDecimal totalAmountTenderSource_1 = BigDecimal.ZERO;
        //private BigDecimal totalAmountTenderSource_2 = BigDecimal.ZERO;
        //private BigDecimal totalAmountTenderSourceDefault = BigDecimal.ZERO;
        //private BigInteger totalPayTenderForCisDiv1 = BigInteger.ZERO;
        //private BigInteger totalPayTenderForCisDiv2 = BigInteger.ZERO;
        //private BigInteger totalSuspensePayTender = BigInteger.ZERO;
        // End Delete - NMendo - CCB029.Issue1 -  2021-05-12
        private BigDecimal totalFileAmountProcessed = BigDecimal.ZERO;
        // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
        private Map<String, String> tenderSourceMap = null;
        // End Add - NMendo - CCB029.Issue1 -  2021-05-12
        
        // Record Value Holder
        private String dateStr;
        private String accountNbrStr;
        private String amountStr;
        private String paymentSrcStr;
        private BigInteger lineCounter = BigInteger.ZERO;
        private BigDecimal amount;
        private Bool isSuspenseAccount = Bool.FALSE;
        private String newAccountNbrStr;
        
        // Detail Record
        private static final int DATE_INDEX = 1 - 1;
        private static final int ACCOUNT_NBR_INDEX = 9 - 1;
        private static final int AMOUNT_INDEX = 84 - 1;
        private static final int PAYSRC_INDEX = 222 - 1;
        private static final int DATE_LENGTH = 8;
        private static final int ACCOUNT_NBR_LENGTH = 13;
        private static final int AMOUNT_LENGTH = 9;
        private static final int PAYSRC_LENGTH = 1;
        private static final int CCB_ACCOUNT_NBR_LENGTH = 10;
        private static final String SAVE_POINT = "SAVE_POINT";
        private FrameworkSession session;
                
        private int totalFileRecordCount = 0;
        private int numberOfRecordsInError = 0;
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new SingleTransactionStrategy(this);
        }

        @Override
        public void initializeThreadWork(
                boolean initializationPreviouslySuccessful)
                throws ThreadAbortedException, RunAbortedException {
            
            parmFilePath = getParameters().getFILE_PATH().trim();
            parmFileName = getParameters().getFILE_NAME().trim();
            // Start Change - NMendo - CCB029.Issue1 -  2021-05-12
            //cisTenderSrceLookup = getParameters().getCIS_DIV_TNDR_SRCE_LOOKUP();
            parmPayProcessName = getParameters().getPAY_PROC_NM().trim();
            parmMasterConfigBO = getParameters().getTNDR_SRC_MASTER_CONFIG_BO();
            // End Change - NMendo - CCB029.Issue1 -  2021-05-12
            defaultTenderSource = getParameters().getTENDER_SOURCE_CD_DEFAULT();
            tenderType = getParameters().getTENDER_TYPE_CD();
            // Start Add - NMendo - Defect 4595996 - 2021-09-17
            parmPaymentBatchNumber = getParameters().getPYMT_BATCH_NBR().trim();
            // End Add - NMendo - Defect 4595996 - 2021-09-17

            dateStr = BLANK;
            accountNbrStr = BLANK;
            amountStr = BLANK;
            amount = BigDecimal.ZERO;
            isSuspenseAccount = Bool.FALSE;
            tempCisDivId = null;
        }

        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
            // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
            // Read Master Configuration BO
            BusinessObjectInstance masterConfigBoInstance = BusinessObjectInstance.create(parmMasterConfigBO);
            masterConfigBoInstance.set("bo", parmMasterConfigBO);
            masterConfigBoInstance = BusinessObjectDispatcher.read(masterConfigBoInstance);
            
            COTSInstanceNode masterConfigData = masterConfigBoInstance.getGroup("masterConfigData");
            COTSInstanceList payTenderSrcMapping = masterConfigData.getList("payTenderSrcMapping");
            Iterator<COTSInstanceListNode> payTenderSrcMappingIter = payTenderSrcMapping.iterator();
            
            tenderSourceMap = new ConcurrentHashMap<>();
            String mapKey = null;
            COTSInstanceListNode paySourceMappingNode = null;
            while(payTenderSrcMappingIter.hasNext()) {
                paySourceMappingNode = payTenderSrcMappingIter.next();
                String paySource = paySourceMappingNode.getLookup("paySource").value().trim();
                String cisDivision = paySourceMappingNode.getString("cisDivision").trim();
                mapKey = paySource.concat(COMMA).concat(cisDivision);
                
                if (isNull(tenderSourceMap.get(mapKey))) {
                    tenderSourceMap.put(mapKey, paySourceMappingNode.getString("tenderSource"));
                } 
            }
            // End Add - NMendo - CCB029.Issue1 -  2021-05-12

            processFile();
            
            // Log Total Number of Records Processed and Total Amount of Payment Processed
            logMessage(CustomMessageRepositorySpireOne.CCB029_1_totalNbrOfPaymentRecordsProcessed(totalFileRecordCount), MessageSeverityLookup.constants.INFORMATIONAL);
            logMessage(CustomMessageRepositorySpireOne.CCB029_1_totalPaymentAmountProcessed(totalFileAmountProcessed.toString()), MessageSeverityLookup.constants.INFORMATIONAL);  

            // Set Batch Run Totals
            WorkUnitResult workUnitResult = new WorkUnitResult(true);
            workUnitResult.setUnitsProcessed(totalFileRecordCount);
            workUnitResult.setUnitsInError(numberOfRecordsInError);
            return workUnitResult;
        }

        /**
         * This method will process the file.
         */
        private void processFile() {
            openFile();

            session = (FrameworkSession)SessionHolder.getSession();
            session.setSavepoint(SAVE_POINT);

            // Read Input File
            recordLine = null;

            while (!isBlankOrNull(recordLine = readLineFromFile())) {
                lineCounter = lineCounter.add(BigInteger.ONE);

                try {
                    // Validate each field in the file
                    validateInputFields();
                    
                    // Start Change - NMendo - CCB029.Issue1 -  2021-05-12
                    // Remove leading zeroes from the account number string.
                    //String strPattern = "^0+(?!$)";
                    //newAccountNbrStr = accountNbrStr.replaceAll(strPattern, "");
                    
                    Account_Id acctId = null;
                    //if(newAccountNbrStr.length() > CCB_ACCOUNT_NBR_LENGTH) {
                        //acctId = new Account_Id(newAccountNbrStr.substring(0, 2));
                    //} else {
                        //acctId = new Account_Id(newAccountNbrStr);
                    //}
                    
                    String accountNbr12Digit = null;
                    String accountNbr10Digit = null;
                    
                    accountNbrStr = accountNbrStr.trim();
                    if(accountNbrStr.trim().length() == 13) {
                        // Start Add - RDizon - CCB029.Issue2 - 2021-06-21
                        if(accountNbrStr.charAt(0) != '0') {
                            isSuspenseAccount = Bool.TRUE;
                        }
                        // End Add - RDizon - CCB029.Issue2 - 2021-06-21
                        // Get last 12 digits
                        accountNbr12Digit = accountNbrStr.substring(1);
                    } else {
                        // Start Change - RDizon - CCB029.Issue2 - 2021-06-21
                        if (accountNbrStr.trim().length() != 12 && accountNbrStr.trim().length() != 10) {
                            isSuspenseAccount = Bool.TRUE;
                            
                        }
                        // End Change - RDizon - CCB029.Issue2 - 2021-06-21
                        accountNbr12Digit = accountNbrStr;
                    }
                    
                    if(accountNbr12Digit.substring(0, 2).equals("00")) {
                        accountNbr10Digit = accountNbr12Digit.substring(2);
                    }

                    if(notNull(accountNbr10Digit)) {
                        acctId = new Account_Id(accountNbr10Digit);
                    }

                    // If Account was found using the 10-digit number
                    if(notNull(acctId) && notNull(acctId.getEntity())) {
                        tempCisDivId = acctId.getEntity().getDivisionId();
                        newAccountNbrStr = acctId.getTrimmedValue();
                    } else {
                        // Otherwise, Check the OLD_ACCT_ID from the CI_SA table
                        //acctId = retrieveOldAccount(newAccountNbrStr);
                        // Check if the 12 digit Account Number exists as Old Account ID
                        acctId = retrieveOldAccount(accountNbr12Digit);
                        
                        
                        if(isNull(acctId) || isNull(acctId.getEntity())) {
                            isSuspenseAccount = Bool.TRUE;
                            newAccountNbrStr = accountNbr12Digit;
                        } else {
                            tempCisDivId = acctId.getEntity().getDivisionId();
                            newAccountNbrStr = acctId.getTrimmedValue();
                        }
                    }
                    // End Change - NMendo - CCB029.Issue1 -  2021-05-12
                    // Start Change - NMendo - CCB029.Issue4 -  2021-06-23
                    //if(isSuspenseAccount.isFalse() ) {
                    if(isSuspenseAccount.isFalse() && notNull(tempCisDivId) && notNull(retrieveTenderSource(tempCisDivId))) {
                    // End Change - NMendo - CCB029.Issue4 -  2021-06-23
                        // Process Payment for identified account
                        processPayment();

                    } else {
                        // Process Suspense Payment
                        // Start Add - RDizon - CCB029.Issue2 - 2021-06-21
                        newAccountNbrStr = accountNbrStr;
                        // End Add - RDizon - CCB029.Issue2 - 2021-06-21
                        processSuspensePayment();
                    }
                    
                    totalFileAmountProcessed = totalFileAmountProcessed.add(amount);
                    totalFileRecordCount = totalFileRecordCount + 1;

                    // Reset Record Value Holder Variables
                    dateStr = BLANK;
                    accountNbrStr = BLANK;
                    amountStr = BLANK;
                    amount = BigDecimal.ZERO;
                    isSuspenseAccount = Bool.FALSE;
                    tempCisDivId = null;
                    newAccountNbrStr = BLANK;
                    
                } catch(ApplicationError ae) {
                    session.rollbackToSavepoint(SAVE_POINT);
                    numberOfRecordsInError  = numberOfRecordsInError + 1;
                    addError(CustomMessageRepositorySpireOne.CCB029_1_errorInFile(ae.getServerMessage().getMessageText().trim()));
                }
            }
            closedFile();
        }
        
        /**
         * This method will open the file in preparation for Read.
         */
        private void openFile() {
            // Local variables
            File fileForRead = new File(parmFilePath, parmFileName);
            BufferedReader tempBufferedReader = null;
    
            try {
                // Open file
                tempBufferedReader = new BufferedReader(new FileReader(fileForRead));
            } catch (IOException e) {
                addError(CustomMessageRepositorySpireOne.CCB029_1_fileOpenError(parmFileName));
            }
    
            this.bufferedReader = tempBufferedReader;
        }
        
        /**
         * This method will read a line in the file.
         * @return String - the line read from the file.
         */
        private String readLineFromFile() {
            try {
                return bufferedReader.readLine();
            } catch (IOException e) {
                throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB029_1_FileReadError(parmFileName));
            }
        }
        
        /**
         * This method will closed the file.
         */
        private void closedFile() {
            try {
                if (notNull(bufferedReader)) {
                    this.bufferedReader.close();
                }
            } catch (IOException e) {
                addError(CustomMessageRepositorySpireOne.CCB029_1_FileClosingError(parmFileName));
            }
        }

        /**
         * This method will retrieve the trimmed field value from the record starting 
         * from the startPos and of the given length.
         * @param record - String
         * @param startPos - int
         * @param length - int
         * @return value - String
         */
        private String getFieldValue(String record, int startPos, int length) {
            String value = null;
            if(record.length() >= startPos+length) {
                value = record.substring(startPos, startPos+length).trim();
            }
            return value;
        }
        
        /**
         * This method will retrieve and validate each field in the file.
         */
        private void validateInputFields() {
            dateStr = getFieldValue(recordLine, DATE_INDEX, DATE_LENGTH);
            accountNbrStr = getFieldValue(recordLine, ACCOUNT_NBR_INDEX, ACCOUNT_NBR_LENGTH);
            amountStr = getFieldValue(recordLine, AMOUNT_INDEX, AMOUNT_LENGTH);
            paymentSrcStr = getFieldValue(recordLine, PAYSRC_INDEX, PAYSRC_LENGTH);
            
            // Validate if the date from the file is in YYYYMMDD format.
            validateDate();

            // Validate if the Account Number is numeric.
            validateAccountNumber();
            
            // Validate if the Amount is numeric.
            amount = validateAmount();
        }
        
        /**
         * This method will validate the date in the file.
         */
        private void validateDate() {
            String year = dateStr.substring(0, 4);
            String month = dateStr.substring(4, 6);
            String day = dateStr.substring(6, 8);

            String newDateStr = year.concat(DASH).concat(month).concat(DASH).concat(day);

            try {
                Date.fromString(newDateStr, new DateFormat("yyyy-MM-dd"));
            } catch (DateFormatParseException ex) {
                addError(CustomMessageRepositorySpireOne.CCB029_1_invalidDateFormat(lineCounter.toString()));
            }
        }
        
        /**
         * This method will validate the account number in the file.
         */
        private void validateAccountNumber() {
            // Validate if Account Number field is numeric
            boolean isNumeric = accountNbrStr.chars().allMatch(x -> Character.isDigit(x));
            
            if(!isNumeric) {
                addError(CustomMessageRepositorySpireOne.CCB029_1_invalidAccountNumber(lineCounter.toString()));
            }
            
            // Start Delete - RDizon - CCB029.Issue2 - 2021-06-21
            // If Account Number length is 13 and first character is a non-zero, raise an error.
            // if(accountNbrStr.length() == ACCOUNT_NBR_LENGTH) {
            //     if(accountNbrStr.charAt(0) != '0') {
            //         addError(CustomMessageRepositorySpireOne.CCB029_1_invalidAccountNumber(lineCounter.toString()));
            //     }
            // }
            // End Delete - RDizon - CCB029.Issue2 - 2021-06-21
        }
        
        /**
         * This checks is amount string is convertible to BigDecimal.
         * @return tempAmount - BigDecimal 
         */
        private BigDecimal validateAmount() {
            // Validate if Amount field is numeric
            boolean isNumeric = amountStr.chars().allMatch(x -> Character.isDigit(x));
            
            if(!isNumeric) {
                addError(CustomMessageRepositorySpireOne.CCB029_1_invalidAmount(lineCounter.toString()));
            }
                
            String decimalStr =  amountStr.substring(amountStr.length() - 2, amountStr.length());
            String wholeNbrStr = amountStr.substring(0, amountStr.length() - 2);
            BigDecimal tempAmount = BigDecimal.ZERO;
            
            try {
                tempAmount = new BigDecimal (wholeNbrStr.concat(".").concat(decimalStr));
            }
            catch (NumberFormatException nfe) {
                addError(CustomMessageRepositorySpireOne.CCB029_1_invalidAmount(lineCounter.toString()));
            }
            return tempAmount;
        }
        
        /**
         * This method will retrieve the account id from old account id in the CI_SA.
         * @param acctStr - String
         * @return accountId - Account_Id          
         */
        private Account_Id retrieveOldAccount(String acctStr) {
            SQLResultRow firstRow = null;
            Account_Id accountId = null;
            
            StringBuilder retrieveOldAcctFromSA = new StringBuilder();
            retrieveOldAcctFromSA.append("SELECT DISTINCT SA.ACCT_ID ");
            retrieveOldAcctFromSA.append("FROM ");
            retrieveOldAcctFromSA.append(        "CI_SA SA ");
            retrieveOldAcctFromSA.append("WHERE ");
            retrieveOldAcctFromSA.append(    "SA.OLD_ACCT_ID = :oldAccountId ");
            
            PreparedStatement retrieveOldAcctFromSAQry = createPreparedStatement(retrieveOldAcctFromSA.toString(), getClass().getName()); 
            retrieveOldAcctFromSAQry.bindStringProperty("oldAccountId", ServiceAgreement.properties.oldAccountId, acctStr); 
            
           if(retrieveOldAcctFromSAQry.list().size() == 1) {
               firstRow = retrieveOldAcctFromSAQry.firstRow();
               accountId = (Account_Id) firstRow.getId("ACCT_ID", Account.class);
           }
           
           retrieveOldAcctFromSAQry.close();
           
           return accountId;
        }

        /**
         * This method will retrieve the Tender Source mapped to the CIS Division and  
         * Payment Process Name from the Master Configuration.
         * @param tempCisDivId - CisDivision_Id
         * @return tenderSrcStr - Lookup Value Description          
         */
        private String retrieveTenderSource(CisDivision_Id tempCisDivId) {
            // Start Delete - NMendo - CCB029.Issue1 -  2021-05-12
            //StringBuilder retrieveTenderSourceFromLookup = new StringBuilder();
            //
            //retrieveTenderSourceFromLookup.append("SELECT DESCR ");
            //retrieveTenderSourceFromLookup.append("FROM ");
            //retrieveTenderSourceFromLookup.append(        "CI_LOOKUP_VAL_L ");
            //retrieveTenderSourceFromLookup.append("WHERE ");
            //retrieveTenderSourceFromLookup.append(        "FIELD_NAME = :lookupField ");
            //retrieveTenderSourceFromLookup.append("AND FIELD_VALUE = :lookupValue ");
            //
            //PreparedStatement retrieveTenderSourceFromLookupQry = createPreparedStatement(retrieveTenderSourceFromLookup.toString(), getClass().getName());
            //retrieveTenderSourceFromLookupQry.bindEntity("lookupField", cisTenderSrceLookup);
            //retrieveTenderSourceFromLookupQry.bindStringProperty("lookupValue", com.splwg.base.domain.common.lookup.LookupValue.properties.fieldValue, tempCisDivId.getTrimmedValue());
            //
            //if(retrieveTenderSourceFromLookupQry.list().size() == 0) {
            //    addError(CustomMessageRepositorySpireOne.CCB029_1_tenderSourceIsMissing(tempCisDivId.getTrimmedValue()));
            //} 
            //
            //SQLResultRow firstRow = null;
            //firstRow = retrieveTenderSourceFromLookupQry.firstRow();
            //String tenderSrcStr = firstRow.getString("DESCR").trim();
            // End Delete - NMendo - CCB029.Issue1 -  2021-05-12
            // Start Add - NMendo - CCB029.Issue1 -  2021-05-12
            String cisDivisionStr = tempCisDivId.getTrimmedValue();
            String mapKey = parmPayProcessName.concat(COMMA).concat(cisDivisionStr);
            String tenderSrcStr = tenderSourceMap.get(mapKey);
            
            // Start Delete - NMendo - CCB029.Issue4 -  2021-06-23
            //if(isNull(tenderSrcStr)) {
            //    addError(CustomMessageRepositorySpireOne.CCB029_1_tenderSourceIsMissing(cisDivisionStr));
            //}
            // End Delete - NMendo - CCB029.Issue4 -  2021-06-23
            // End Add - NMendo - CCB029.Issue1 -  2021-05-12
            
            return tenderSrcStr;
        }
        

        /**
         * This method will process payment based on the mapping of the CIS Division and Tender Source.
         */
        private void processPayment() {
            
            // Start Delete - NMendo - CCB029.Issue1 -  2021-05-12
            //if(isNull(cisDivId_1) || tempCisDivId.equals(cisDivId_1)) {
            //    if(isNull(cisDivId_1)) {
            //        cisDivId_1 = tempCisDivId;
            //    }
            //    // Increment total pay tender count and total tender amount for cisDivId_1
            //    totalAmountTenderSource_1 = totalAmountTenderSource_1.add(amount);
            //    totalPayTenderForCisDiv1 = totalPayTenderForCisDiv1.add(BigInteger.ONE);
            //} else if((isNull(cisDivId_2) && !tempCisDivId.equals(cisDivId_1))
            //            || tempCisDivId.equals(cisDivId_2)) {
            //    if(isNull(cisDivId_2)) {
            //        cisDivId_2 = tempCisDivId;
            //    }
            //    // Increment total pay tender count and total tender amount for cisDivId_2
            //    totalAmountTenderSource_2 = totalAmountTenderSource_2.add(amount);
            //    totalPayTenderForCisDiv2 = totalPayTenderForCisDiv2.add(BigInteger.ONE);
            //}
            // End Delete - NMendo - CCB029.Issue1 -  2021-05-12
            
            // Get Tender Source using Pay Process Name parameter and the CIS Division 
            String tenderSrcStr = retrieveTenderSource(tempCisDivId);
            TenderSource tenderSrc = new TenderSource_Id(tenderSrcStr).getEntity();
            
            // Check if Deposit Control for the CIS Division Tender Source is already created
            DepositControlStaging_Id depositCntlStgId = new DepositControlStaging_Id(tenderSrc.getExternalSourceId(), parmFileName);
            
            if(isNull(depositCntlStgId.getEntity())) {
                // Create Staging Records for the CIS Division.
                DepositControlStaging newDepositControlStaging = createDepositControlStagingRecord(tenderSrc, new Money(amount.toString(), tenderSrc.getCurrency().getId()));
                createTenderControlStagingRecord(newDepositControlStaging, new Money(amount.toString(), tenderSrc.getCurrency().getId()));
                createPaymentTenderStagingRecord(newDepositControlStaging, lineCounter.toString());
            } else {
                // Otherwise, Update existing Deposit and Tender Control Staging Records
                DepositControlStaging_DTO depositControlStagingDTO = depositCntlStgId.getEntity().getDTO();
                // Start Change - NMendo - Defect 4595996 - 2021-09-17
                //TenderControlStaging_Id tenderCntlStgId = new TenderControlStaging_Id(depositCntlStgId, EXT_BATCH_ID);
                TenderControlStaging_Id tenderCntlStgId = new TenderControlStaging_Id(depositCntlStgId, parmPaymentBatchNumber);
                // End Change - NMendo - Defect 4595996 - 2021-09-17
                TenderControlStaging_DTO tenderControlStagingDTO = tenderCntlStgId.getEntity().getDTO();
                
                // Start Change - NMendo - CCB029.Issue1 -  2021-05-12
                //if(tempCisDivId.equals(cisDivId_1)) {
                //    // Update Tender Control Total Amount
                //    depositControlStagingDTO.setTenderControlTotalAmount(new Money(totalAmountTenderSource_1.toString(), tenderSrc.getCurrency().getId()));
                //    
                //    // Update Total Tenders Amount and Total Number of Tenders
                //    tenderControlStagingDTO.setTotalTendersAmount(new Money(totalAmountTenderSource_1.toString(), tenderSrc.getCurrency().getId()));
                //    tenderControlStagingDTO.setTotalNumberOfTender(totalPayTenderForCisDiv1);
                //}
                //
                //if(tempCisDivId.equals(cisDivId_2)) {
                //    // Update Tender Control Total Amount
                //    depositControlStagingDTO.setTenderControlTotalAmount(new Money(totalAmountTenderSource_2.toString(), tenderSrc.getCurrency().getId()));
                //    
                //    // Update Total Tenders Amount and Total Number of Tenders
                //    tenderControlStagingDTO.setTotalTendersAmount(new Money(totalAmountTenderSource_2.toString(), tenderSrc.getCurrency().getId()));
                //    tenderControlStagingDTO.setTotalNumberOfTender(totalPayTenderForCisDiv2);
                //}
                Money tempMoney = depositCntlStgId.getEntity().getTenderControlTotalAmount();
                BigInteger tempCtr = tenderCntlStgId.getEntity().getTotalNumberOfTender();

                tempMoney = tempMoney.add(new Money(amount.toString(), tenderSrc.getCurrency().getId()));
                tempCtr = tempCtr.add(BigInteger.ONE);
                
                // Update Tender Control Total Amount
                depositControlStagingDTO.setTenderControlTotalAmount(tempMoney);
                
                // Update Total Tenders Amount and Total Number of Tenders
                tenderControlStagingDTO.setTotalTendersAmount(tempMoney);
                tenderControlStagingDTO.setTotalNumberOfTender(tempCtr);
                // End Change - NMendo - CCB029.Issue1 -  2021-05-12
                
                depositCntlStgId.getEntity().setDTO(depositControlStagingDTO);
                tenderCntlStgId.getEntity().setDTO(tenderControlStagingDTO);
                createPaymentTenderStagingRecord(depositCntlStgId.getEntity(), lineCounter.toString());
            }
        }
        
        /**
         * This method will process suspense payment.
         */
        private void processSuspensePayment() {
            // Check if Deposit Control for the Default Tender Source is already created
            DepositControlStaging_Id depositCntlStgId = new DepositControlStaging_Id(defaultTenderSource.getExternalSourceId(), parmFileName);
            // Start Delete - NMendo - CCB029.Issue1 -  2021-05-12
            //totalSuspensePayTender = totalSuspensePayTender.add(BigInteger.ONE);
            //totalAmountTenderSourceDefault = totalAmountTenderSourceDefault.add(amount);
            // End Delete - NMendo - CCB029.Issue1 -  2021-05-12
            
            if(isNull(depositCntlStgId.getEntity())) {    
                // Create Deposit Control for the Suspense Tender Source Default
                DepositControlStaging newDepositControlStaging = createDepositControlStagingRecord(defaultTenderSource, new Money(amount.toString(), defaultTenderSource.getCurrency().getId()));
                createTenderControlStagingRecord(newDepositControlStaging, new Money(amount.toString(), defaultTenderSource.getCurrency().getId()));
                createPaymentTenderStagingRecord(newDepositControlStaging, lineCounter.toString());
            } else {
                // Start Change - NMendo - CCB029.Issue1 -  2021-05-12
                DepositControlStaging_DTO depositControlStagingDTO = depositCntlStgId.getEntity().getDTO();
                // Start Change - NMendo - Defect 4595996 - 2021-09-17
                //TenderControlStaging_Id tenderCntlStgId = new TenderControlStaging_Id(depositCntlStgId, EXT_BATCH_ID);
                TenderControlStaging_Id tenderCntlStgId = new TenderControlStaging_Id(depositCntlStgId, parmPaymentBatchNumber);
                // End Change - NMendo - Defect 4595996 - 2021-09-17
                TenderControlStaging_DTO tenderControlStagingDTO = tenderCntlStgId.getEntity().getDTO();

                Money tempMoney = depositCntlStgId.getEntity().getTenderControlTotalAmount();
                BigInteger tempCtr = tenderCntlStgId.getEntity().getTotalNumberOfTender();

                tempMoney = tempMoney.add(new Money(amount.toString(), defaultTenderSource.getCurrency().getId()));
                tempCtr = tempCtr.add(BigInteger.ONE);
                
                // Update Tender Control Total Amount
                depositControlStagingDTO.setTenderControlTotalAmount(tempMoney);
                
                // Update Total Tenders Amount and Total Number of Tenders
                tenderControlStagingDTO.setTotalTendersAmount(tempMoney);
                tenderControlStagingDTO.setTotalNumberOfTender(tempCtr);
                
                depositCntlStgId.getEntity().setDTO(depositControlStagingDTO);
                tenderCntlStgId.getEntity().setDTO(tenderControlStagingDTO);
                // End Change - NMendo - CCB029.Issue1 -  2021-05-12
                createPaymentTenderStagingRecord(depositCntlStgId.getEntity(), lineCounter.toString());
            }
        }
        
        /**
         * This method creates and inserts Deposit Control Staging record.
         * @param tenderSource - TenderSource
         * @param totTenderCtlAmount - Money
         * return depositControlStaging - DepositControlStaging
         */
        private DepositControlStaging createDepositControlStagingRecord (TenderSource tenderSource, Money totTenderCtlAmount) {
            startChanges();
            DepositControlStaging depositControlStaging = null;
            DepositControlStaging_Id depositControlStagingId = new DepositControlStaging_Id(tenderSource.getExternalSourceId(), parmFileName);                                                
            DepositControlStaging_DTO depositControlStagingDTO = depositControlStagingId.newDTO();                                                                                 
            depositControlStagingDTO.setDepositControlStagingStatus(DepositControlStagingStatusLookup.constants.PENDING);
            depositControlStagingDTO.setTransmissionDateTime(getProcessDateTime());                                                                       
            depositControlStagingDTO.setCurrencyId(tenderSource.getCurrency().getId());                                                                  
            depositControlStagingDTO.setTenderControlTotalAmount(totTenderCtlAmount);
            depositControlStagingDTO.setTotalTenderControl(BigInteger.ONE);
            depositControlStaging = depositControlStagingDTO.newEntity();
            saveChanges();
            
            return depositControlStaging;
        }
        
        /**
         * This method creates and inserts Tender Control Staging record.
         * @param depositControlStaging - DepositControlStaging
         * @param totTenderCtlAmount - Money
         * return tenderControlStaging - TenderControlStaging
         */ 
        private TenderControlStaging createTenderControlStagingRecord(DepositControlStaging depositControlStaging, Money totTenderCtlAmount) {
            startChanges();
            TenderControlStaging tenderControlStaging = null;
            TenderControlStaging_Id tenderControlStagingId = null;
            // Start Change - NMendo - Defect 4595996 - 2021-09-17
            //tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, EXT_BATCH_ID);
            tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, parmPaymentBatchNumber);
            // End Change - NMendo - Defect 4595996 - 2021-09-17
            TenderControlStaging_DTO tenderControlStagingDTO = tenderControlStagingId.newDTO();
            tenderControlStagingDTO.setTenderControlStatus(TenderControlStatusLookup.constants.PENDING);                                             
            tenderControlStagingDTO.setTotalTendersAmount(totTenderCtlAmount);
            tenderControlStagingDTO.setTotalNumberOfTender(BigInteger.ONE);
            tenderControlStaging = tenderControlStagingDTO.newEntity();
            saveChanges();
            
            return tenderControlStaging;
        }
        
        /**
         * This method creates and inserts Payment Tender Staging record.
         * @param depositControlStaging - DepositControlStaging
         * @param extRefId - String
         */ 
        private void createPaymentTenderStagingRecord(DepositControlStaging depositControlStaging, String extRefId) {
            startChanges();
            // Start Change - NMendo - Defect 4595996 - 2021-09-17
            //TenderControlStaging_Id tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, EXT_BATCH_ID);                                             
            TenderControlStaging_Id tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, parmPaymentBatchNumber);
         	// End Change - NMendo - Defect 4595996 - 2021-09-17
            PaymentTenderUpload_Id paymentTenderUploadId = new PaymentTenderUpload_Id(tenderControlStagingId, extRefId);
            PaymentTenderUpload_DTO paymentTenderUploadDTO = paymentTenderUploadId.newDTO(); 
            paymentTenderUploadDTO.setPaymentTenderStagingStatus(PaymentTenderStagingStatusLookup.constants.PENDING);  
            paymentTenderUploadDTO.setTenderAmount(new Money (amount.toString(), depositControlStaging.getCurrency().getId()));               
            paymentTenderUploadDTO.setAccountingDate(getProcessDateTime().getDate());
            paymentTenderUploadDTO.setTenderTypeId(tenderType.getId());

            paymentTenderUploadDTO.setCustomerId(newAccountNbrStr); 
            paymentTenderUploadDTO.setMicrId(BLANK);                        
            paymentTenderUploadDTO.setName(BLANK);
            paymentTenderUploadDTO.setCheckNumber(BLANK);
            paymentTenderUploadDTO.newEntity();
            saveChanges();
        }
    }
}