/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * CINT01812 - This batch process will evaluate the inbound staging records
 * from MAXIMO and create or update field activities accordingly. 
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2015-03-18   SMiran        	CINT01812 - Initial Version.
 * 2016-01-29  	MPang			Updated for CCB v2.4 compilation.
 * 2016-08-16   SMiran          Defect 3494861. Check first if Dispatch Group
 * 								is populated before comparing
 **************************************************************************/
package com.splwg.cm.domain.batch;

import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.batch.CommitEveryUnitStrategy;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Id;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.lookup.TransactionTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.lookup.LookupField_Id;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.ccb.api.lookup.FieldActivityCreatedByLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.cisDivision.CisDivision_Id;
import com.splwg.ccb.domain.admin.dispatchGroup.DispatchGroup_Id;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.FieldActivityCancelReason_Id;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCancelProcessor;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCancelProcessorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_Id;*/

import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.dispatchGroup.entity.DispatchGroup_Id;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.entity.FieldActivityCancelReason_Id;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCancelProcessor;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCancelProcessorData;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.api.lookup.CmInterfaceStatusLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.interfaceStaging.CmFaIdOutboundInterfaceStagingMaintenance;
import com.splwg.cm.domain.interfaceStaging.CmInterfaceErrorLogMaintenance;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

/**
 * @author 90723
 *
 @BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (entityName = serviceTaskType, name = SERVICE_TASK_TYPE_IN, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = SERVICE_TASK_TYPE_OUT, required = true, type = entity)})
 */
public class CmFACreateUpdateFromMaximoBatch extends
		CmFACreateUpdateFromMaximoBatch_Gen {
	
	// Batch parameters
	private ServiceTaskType parmServiceTaskTypeIn;
	
	// Service Task parameters
	private String parmSourceSystemNameIn;
	private String parmTargetSystemNameIn;
	
	// Id class for the Staging Key
	private static class CmInboundInterfaceStaging_Id implements Id {
		
		private static final long serialVersionUID = 1L;		
		private String stagingKey;
		
		public CmInboundInterfaceStaging_Id(String stagingKey) {
			setStagingKey(stagingKey);
		}
		
		public String getStagingKey() {
			return stagingKey;
		}
		
		private void setStagingKey(String stagingKey) {
			this.stagingKey = stagingKey;
		}
		
		public boolean isNull() {
			return false;
		}
		
		public void appendContents(StringBuilder arg0) {
			
		}
		
	}
	
	@Override
	public void validateSoftParameters(boolean arg0) {
				
		// Get soft parameters
		parmServiceTaskTypeIn = this.getParameters().getSERVICE_TASK_TYPE_IN();
		
		BusinessObject serviceTaskTypeBo = parmServiceTaskTypeIn.getBusinessObject();
		BusinessObjectInstance serviceTaskType = BusinessObjectInstance.create(serviceTaskTypeBo);
		serviceTaskType.set("serviceTaskType", parmServiceTaskTypeIn.getId().getTrimmedValue()); 
		serviceTaskType = BusinessObjectDispatcher.read(serviceTaskType);		
				
		parmSourceSystemNameIn = serviceTaskType.getString("sourceSystem");
		parmTargetSystemNameIn = serviceTaskType.getString("targetSystem");
		
	}

	public JobWork getJobWork() {
		
        ArrayList<ThreadWorkUnit> workUnitList =  new ArrayList<ThreadWorkUnit>();
        List<SQLResultRow> inboundStagingRow = null;
        // Get inbound staging records to process
        inboundStagingRow = getInboundStagingRecords();

        // Create work unit for each record in result set
        for(SQLResultRow row : inboundStagingRow){
            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId(new CmInboundInterfaceStaging_Id(row.getString("STAGING_KEY")));
            workUnit.addSupplementalData("logicalTransactionNumber", row.getString("LOGICAL_TRX_NUMBER"));
            workUnit.addSupplementalData("creationDateTime", row.getDateTime("CREATION_DATETIME"));
            workUnit.addSupplementalData("originatingKey", row.getString("ORIGINATING_KEY")); 
            workUnitList.add(workUnit);
        }

        return createJobWorkForThreadWorkUnitList(workUnitList);

	}
	
	private List<SQLResultRow> getInboundStagingRecords() {
		
		/*
		 * Interface Name must be equal to Interface Name batch parameter
		 * Status Flag must be "N"
		 * Source System Name must be equal to Source System Name batch parameter
		 * Target System Name must be equal to Target System Name batch parameter
		 */
		StringBuilder createUpdateMeterItemQueryStr = new StringBuilder();
		createUpdateMeterItemQueryStr.append(" SELECT ");
		createUpdateMeterItemQueryStr.append("	 STAGING_KEY ");
		createUpdateMeterItemQueryStr.append("   , LOGICAL_TRX_NUMBER ");
		createUpdateMeterItemQueryStr.append("   , CREATION_DATETIME ");
		createUpdateMeterItemQueryStr.append("   , ORIGINATING_KEY ");
		createUpdateMeterItemQueryStr.append(" FROM ");
		createUpdateMeterItemQueryStr.append("   XXL_INT_INBOUND_STG ");
		createUpdateMeterItemQueryStr.append(" WHERE ");
		createUpdateMeterItemQueryStr.append("   INTERFACE_NAME = :interfaceName ");
		createUpdateMeterItemQueryStr.append("   AND STATUS_FLAG = :statusFlag ");
		createUpdateMeterItemQueryStr.append("   AND SOURCE_SYSTEM_NAME = :sourceSystemName ");
		createUpdateMeterItemQueryStr.append("   AND TARGET_SYSTEM_NAME = :targetSystemName ");
		createUpdateMeterItemQueryStr.append(" ORDER BY STAGING_KEY ASC ");
		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement inboundStagingPrepStmt = createPreparedStatement(createUpdateMeterItemQueryStr.toString());	
		PreparedStatement inboundStagingPrepStmt = createPreparedStatement(createUpdateMeterItemQueryStr.toString(), getClass().getName());	
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		inboundStagingPrepStmt.bindString("interfaceName", parmServiceTaskTypeIn.getId().getTrimmedValue(), "INTERFACE_NAME");
		inboundStagingPrepStmt.bindString("statusFlag", CmInterfaceStatusLookup.constants.NEW.trimmedValue(), "STATUS_FLG");
		inboundStagingPrepStmt.bindString("sourceSystemName", parmSourceSystemNameIn.trim(), "SOURCE_SYSTEM_NAME");
		inboundStagingPrepStmt.bindString("targetSystemName", parmTargetSystemNameIn.trim(), "TARGET_SYSTEM_NAME");
		
		List<SQLResultRow> inboundStagingRow = inboundStagingPrepStmt.list();
		
		inboundStagingPrepStmt.close();
		
		return inboundStagingRow;
	}

	public Class<CmFACreateUpdateFromMaximoBatchWorker> getThreadWorkerClass() {
		return CmFACreateUpdateFromMaximoBatchWorker.class;
	}

	public static class CmFACreateUpdateFromMaximoBatchWorker extends
			CmFACreateUpdateFromMaximoBatchWorker_Gen {
		
		// Constants
		private final String BLANK_VALUE = " ";
		private final String ERROR_CODE_DELIMITER = "-";
		private final String ERROR_SOURCE = "Logged by Target System";
		private final String XXL_INT_FACRUP_IN_STG = "XXL_INT_FACRUP_IN_STG";
		
		// Soft parameters
		private ServiceTaskType parmServiceTaskTypeIn;
		private String parmSourceSystemNameIn;
		private String parmTargetSystemNameIn;
		private String parmDispatchGroupOverride = "";
		private ServiceTaskType parmServiceTaskTypeOut;
		
		// Work Variables
		private CmInboundInterfaceStaging_Id stagingKey = null;
		private String logicalTransactionNumber = BLANK_VALUE;
		private String originationTable = BLANK_VALUE;
		private SQLResultRow faCreUpRow = null;
		private ServiceTaskType parmServiceTaskType;
		private String parmSourceSystemName;
		private String parmTargetSystemName;
		
		// FA Variables
		private TransactionTypeLookup transactionType;
		private FieldActivity_Id faId;
		private FieldActivityType_Id faTypeId;
		private ServicePoint_Id spId;
		private DateTime scheduleDateTime;
		private FieldActivityStatusLookup faStatus;
		private String instructions;
		private String externalId;
		private String faIntStatus;
		private FieldActivityCancelReason_Id faCancelReasonId;
		private CisDivision_Id siteId;
		
		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
			
			// Get soft parameters
			parmServiceTaskTypeIn = this.getParameters().getSERVICE_TASK_TYPE_IN();
			parmServiceTaskTypeOut = this.getParameters().getSERVICE_TASK_TYPE_OUT();
			
			// Get BO elements for Inbound
			BusinessObject serviceTaskTypeBo = parmServiceTaskTypeIn.getBusinessObject();
			BusinessObjectInstance serviceTaskType = BusinessObjectInstance.create(serviceTaskTypeBo);
			serviceTaskType.set("serviceTaskType", parmServiceTaskTypeIn.getId().getTrimmedValue()); 
			serviceTaskType = BusinessObjectDispatcher.read(serviceTaskType);	
			
			// Source System Name
			parmSourceSystemNameIn = serviceTaskType.getString("sourceSystem");
			// Target System Name
			parmTargetSystemNameIn = serviceTaskType.getString("targetSystem");
			// Dispatch Group Override
			parmDispatchGroupOverride = serviceTaskType.getGroup("stagingInterfaceDetails").getString("dispatchGroupOverride");		
			
		}

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new CommitEveryUnitStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			// Get Staging Key
			stagingKey = (CmInboundInterfaceStaging_Id) unit.getPrimaryId();			
			// Get Logical Transaction Number
			logicalTransactionNumber = unit.getSupplementallData("logicalTransactionNumber").toString();
			
			// Initialize variables
			parmServiceTaskType = parmServiceTaskTypeIn;
			parmSourceSystemName = parmSourceSystemNameIn;
			parmTargetSystemName = parmTargetSystemNameIn;
			
			// Search record from FA create/update table
			getFaCreateUpdateRecord();
			
			// Validate inbound FA Create/Update details
			validateFaCreUpRow();			

			// Create or Update FA
			processCreateUpdateFa();
			
			// Update Inbound Staging record to Complete
			updateInboundInterfaceStagingStatus(
					stagingKey.getStagingKey().trim()
					, CmInterfaceStatusLookup.constants.COMPLETE
					, this.getProcessDateTime());
			
			return true;
		}

		private void getFaCreateUpdateRecord() {
			
			// Set Table Name
			originationTable = XXL_INT_FACRUP_IN_STG;

			// Get record from FA Create/Update Inbound Staging Table
			StringBuilder getFaCreUpQueryStr = new StringBuilder();
			getFaCreUpQueryStr.append(" SELECT ");
			getFaCreUpQueryStr.append(" 	TRANSACTION_TYPE ");
			getFaCreUpQueryStr.append(" 	,NVL(FA_ID,' ') FA_ID ");
			getFaCreUpQueryStr.append(" 	,NVL(FA_TYPE,' ') FA_TYPE ");
			getFaCreUpQueryStr.append(" 	,NVL(SP_ID,' ') SP_ID ");
			getFaCreUpQueryStr.append(" 	,SCHED_DTTM ");
			getFaCreUpQueryStr.append(" 	,FA_STATUS_FLG ");
			getFaCreUpQueryStr.append(" 	,NVL(INSTRUCTIONS,' ') INSTRUCTIONS ");
			getFaCreUpQueryStr.append(" 	,NVL(EXTERNAL_ID,' ') EXTERNAL_ID ");
			getFaCreUpQueryStr.append(" 	,NVL(FA_INT_STATUS_FLG,' ') FA_INT_STATUS_FLG ");
			getFaCreUpQueryStr.append(" 	,NVL(FA_CAN_RSN_CD,' ') FA_CAN_RSN_CD ");
			getFaCreUpQueryStr.append(" 	,NVL(SITEID,' ') SITEID ");
			getFaCreUpQueryStr.append(" FROM ");
			getFaCreUpQueryStr.append(" 	XXL_INT_FACRUP_IN_STG ");
			getFaCreUpQueryStr.append(" WHERE ");
			getFaCreUpQueryStr.append("   LOGICAL_TRX_NUMBER = :logicalTransactionNumber ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement faCreUpPrepStmt = createPreparedStatement(getFaCreUpQueryStr.toString());
			PreparedStatement faCreUpPrepStmt = createPreparedStatement(getFaCreUpQueryStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			faCreUpPrepStmt.bindString("logicalTransactionNumber", logicalTransactionNumber, "LOGICAL_TRX_NUMBER");
			
			List<SQLResultRow> faCreUpStagingList = faCreUpPrepStmt.list();			
			faCreUpPrepStmt.close();
			
			if (faCreUpStagingList.size() == 0){
				// Raise error if no FA staging record found
				addError(CustomMessageRepositoryMGE.cint01812noFaStgRec(stagingKey.getStagingKey(), logicalTransactionNumber, originationTable));
			}else if (faCreUpStagingList.size() == 1){
				// If exactly one FA Staging record found for Logical Transaction Number
				faCreUpRow = faCreUpStagingList.get(0);
			}
			
		}
		
		private void validateFaCreUpRow() {
			
			// Method variables
			LookupField_Id lookupFieldId;
			LookupValue_Id lookupValueId;

			// TRANSACTION_TYPE
			String transactionTypeStr = faCreUpRow.getString("TRANSACTION_TYPE").trim();
			if (isEmptyOrNull(transactionTypeStr)){
				addError(CustomMessageRepositoryMGE.cint01812tblFldMiss(stagingKey.getStagingKey(), logicalTransactionNumber
						, originationTable, "TRANSACTION_TYPE"));
			}else{
				// Transaction Type must be valid
				lookupFieldId = new LookupField_Id("TRANS_TYPE_FLG");
				lookupValueId = new LookupValue_Id(lookupFieldId, transactionTypeStr);					
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01812tblFldInv(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "TRANSACTION_TYPE", transactionTypeStr));
				}else{
					transactionType = (TransactionTypeLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
				// Transasction Type must be "ADD" or "UPDT"
				if (!(transactionType.isAdd() || transactionType.isUpdate())){
					addError(CustomMessageRepositoryMGE.cint01812tblFldInv(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "TRANSACTION_TYPE", transactionTypeStr));
				}
			}
			
			// FA_ID
			String faIdStr = faCreUpRow.getString("FA_ID").trim();
			if (!isEmptyOrNull(faIdStr)){
				// If Transaction Type is ADD, the FA_ID must not be supplied
				if (transactionType.isAdd()){
					addError(CustomMessageRepositoryMGE.cint01812fldValErr(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "FA_ID", "TRANSACTION_TYPE", "UPDT"));
				}
				// If supplied, the FA must exist in CC&B
				faId = new FieldActivity_Id(faIdStr);
				if (isNull(faId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01812tblFldInv(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "FA_ID", faIdStr));
				}
				// The FA must be in pending status
				if (!faId.getEntity().getFieldActivityStatus().isPending()){
					addError(CustomMessageRepositoryMGE.cint01812faNotPending(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, faIdStr));
				}
			}else{
				// If Transaction Type is UPDT, the FA ID must be supplied
				if (transactionType.isUpdate()){
					addError(CustomMessageRepositoryMGE.cint01812fldValErr2(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "FA_ID", "TRANSACTION_TYPE", "UPDT"));
				}
			}
			
			// FA_TYPE
			String faTypeStr = faCreUpRow.getString("FA_TYPE").trim();
			if (!isEmptyOrNull(faTypeStr)){
				// FA Type must be valid
				faTypeId = new FieldActivityType_Id(faTypeStr);
				if (isNull(faTypeId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01812tblFldInv(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "FA_TYPE", faTypeStr));
				}
			}else{
				// FA Type must be supplied if Transaction Type is ADD
				if (transactionType.isAdd()){
					addError(CustomMessageRepositoryMGE.cint01812fldValErr2(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "FA_TYPE", "TRANSACTION_TYPE", "ADD"));
				}
			}
			
			// SP_ID
			String spIdStr = faCreUpRow.getString("SP_ID").trim();
			if (!isEmptyOrNull(spIdStr)){
				// SP ID must be valid
				spId = new ServicePoint_Id(spIdStr);
				if (isNull(spId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01812tblFldInv(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "SP_ID", spIdStr));
				}
			}else{
				// SP ID must be supplied if Transaction Type is ADD
				if (transactionType.isAdd()){
					addError(CustomMessageRepositoryMGE.cint01812fldValErr2(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "SP_ID", "TRANSACTION_TYPE", "ADD"));
				}
			}
			
			// SCHED_DTTM
			scheduleDateTime = faCreUpRow.getDateTime("SCHED_DTTM");
			if (isNull(scheduleDateTime)){
				if (transactionType.isAdd()){
					addError(CustomMessageRepositoryMGE.cint01812fldValErr2(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "SCHED_DTTM", "TRANSACTION_TYPE", "ADD"));
				}
			}
			
			// FA_STATUS_FLG
			String faStatusStr = faCreUpRow.getString("FA_STATUS_FLG").trim();
			if (isEmptyOrNull(faStatusStr)){
				addError(CustomMessageRepositoryMGE.cint01812tblFldMiss(stagingKey.getStagingKey(), logicalTransactionNumber
						, originationTable, "FA_STATUS_FLG"));
			}else{
				// FA Status must be valid
				lookupFieldId = new LookupField_Id("FA_STATUS_FLG");
				lookupValueId = new LookupValue_Id(lookupFieldId, faStatusStr);					
				if(isNull(lookupValueId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01812tblFldInv(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "FA_STATUS_FLG", faStatusStr));
				}else{
					faStatus = (FieldActivityStatusLookup) LookupHelper.getLookupInstance(lookupValueId.getEntity());
				}
				// If Transaction Type is "ADD", the FA Status Flag must be "P"
				if (transactionType.isAdd()){
					if (!faStatus.isPending()){
						addError(CustomMessageRepositoryMGE.cint01812faStatPendingAddInv(stagingKey.getStagingKey(), logicalTransactionNumber
								, originationTable, "FA_STATUS_FLG", "P", "TRANSACTION_TYPE", "ADD"));
					}
				}
				// If Transaction Type is "UPDT", the FA Status Flag can't be "C"
				if (transactionType.isUpdate()){
					if (faStatus.isCompleted()){
						addError(CustomMessageRepositoryMGE.cint01812faStatCompleteUpdtInv(stagingKey.getStagingKey(), logicalTransactionNumber
								, originationTable, "FA_STATUS_FLG", "C", "TRANSACTION_TYPE", "UPDT"));
					}
				}
			}
			
			// INSTRUCTIONS
			instructions = faCreUpRow.getString("INSTRUCTIONS").trim();
			
			// EXTERNAL_ID
			externalId = faCreUpRow.getString("EXTERNAL_ID").trim();
			if (isEmptyOrNull(externalId)){
				if (transactionType.isAdd()){
					addError(CustomMessageRepositoryMGE.cint01812fldValErr2(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "EXTERNAL_ID", "TRANSACTION_TYPE", "ADD"));
				}
			}
			
			// FA_INT_STATUS_FLG
			faIntStatus = faCreUpRow.getString("FA_INT_STATUS_FLG").trim();
			if (!isEmptyOrNull(faIntStatus)){
				// If supplied, FA Intermediate Status must be valid
				if(!isFaIntStatusValid(faIntStatus)){
					addError(CustomMessageRepositoryMGE.cint01812tblFldInv(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "FA_INT_STATUS_FLG", faIntStatus));
				}
			}

			// FA_CAN_RSN_CD
			String faCanRsnStr = faCreUpRow.getString("FA_CAN_RSN_CD").trim();
			if (!isEmptyOrNull(faCanRsnStr)){
				// FA Cancel Reason must be supplied only if FA Status is cancelled
				if (!faStatus.isCanceled()){
					addError(CustomMessageRepositoryMGE.cint01812fldValErr(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "FA_CAN_RSN_CD", "FA_STATUS_FLG", "X"));
				}
				// FA Cancel Reason must be valid
				faCancelReasonId = new FieldActivityCancelReason_Id(faCanRsnStr);
				if (isNull(faCancelReasonId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01812tblFldInv(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "FA_CAN_RSN_CD", faCanRsnStr));
				}
			}else{
				// FA Cancel Reason must be supplied if FA Status is Cancelled
				if (faStatus.isCanceled()){
					addError(CustomMessageRepositoryMGE.cint01812fldValErr2(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "FA_CAN_RSN_CD", "FA_STATUS_FLG", "X"));
				}
			}
			
			// SITEID
			String siteIdStr = faCreUpRow.getString("SITEID").trim();
			if (!isEmptyOrNull(siteIdStr)){
				siteId = new CisDivision_Id(siteIdStr);
				if (isNull(siteId.getEntity())){
					addError(CustomMessageRepositoryMGE.cint01812tblFldInv(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "SITEID", siteIdStr));
				}
			}else{
				// Site Id must be supplied if Transaction Type is ADD
				if (transactionType.isAdd()){
					addError(CustomMessageRepositoryMGE.cint01812fldValErr2(stagingKey.getStagingKey(), logicalTransactionNumber
							, originationTable, "SITEID", "TRANSACTION_TYPE", "ADD"));
				}
			}
			
		}
		
		private boolean isFaIntStatusValid(String faIntStatus) {
			
			StringBuilder faIntStatusQueryStr = new StringBuilder();
			faIntStatusQueryStr.append(" SELECT ");
			faIntStatusQueryStr.append("  FIELD_VALUE ");
			faIntStatusQueryStr.append(" FROM ");
			faIntStatusQueryStr.append("  CI_LOOKUP_VAL ");
			faIntStatusQueryStr.append(" WHERE ");
			faIntStatusQueryStr.append("  FIELD_NAME = :fieldName ");
			faIntStatusQueryStr.append("  AND FIELD_VALUE = :fieldValue ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement faIntStatusPrepStmt = createPreparedStatement(faIntStatusQueryStr.toString());	
			PreparedStatement faIntStatusPrepStmt = createPreparedStatement(faIntStatusQueryStr.toString(), getClass().getName());	
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			faIntStatusPrepStmt.bindString("fieldName", "FA_INT_STATUS_FLG", "FIELD_NAME");
			faIntStatusPrepStmt.bindString("fieldValue", faIntStatus, "FIELD_VALUE");
			if (faIntStatusPrepStmt.list().size() > 0){
				return true;
			}

			return false;
		}

		private void processCreateUpdateFa() {

			// If the transaction type is ADD, process FA creation
			if (transactionType.isAdd()){
				// Create the Field Activity
				FieldActivity newlyCreatedFA = createFA();
				// Override the Dispatch Group
				if (newlyCreatedFA.getIsEligibleForDispatch().isTrue()){
					overrideDispGroup(newlyCreatedFA);
				}
				// Create Outbound Staging Record to update MAXIMO with CCB FA ID
				createOutboundStagingRecord(newlyCreatedFA);
			}
			// If the transaction type is UPDT, process FA update
			if (transactionType.isUpdate()){
				updateFA();
			}
		}

		private FieldActivity createFA() {

			FieldActivity newFA = null;
			
			// Create FA
			FieldActivity_DTO faDto = createDTO(FieldActivity.class);
			faDto.setServicePointId(spId);
			faDto.setScheduleDateTimeStart(scheduleDateTime);
			faDto.setFieldActivityTypeId(faTypeId);
			faDto.setCreatedBy(FieldActivityCreatedByLookup.constants.BACKGROUND);
			faDto.setInstructions(instructions);
			// Set intermediate status to "CREX" to skip message creation to external system
			if (faTypeId.getEntity().getIsEligibleForDispatch().isTrue()){
				faDto.setIntermediateStatus("CREX");
				faDto.setExternalId(externalId);
			}
			FieldActivityCreatorData faCreatorData = FieldActivityCreatorData.Factory.newInstance();
			faCreatorData.setFaDTO(faDto);
			FieldActivityCreator faCreator = FieldActivityCreator.Factory.newInstance();
			try{
				newFA = faCreator.addFieldActivity(faCreatorData);
			}catch(ApplicationError e){
				addError(CustomMessageRepositoryMGE.cint01812baseError(stagingKey.getStagingKey(), logicalTransactionNumber, e.getMessage()));
			}
			return newFA;
			
		}
		
		private void overrideDispGroup(FieldActivity newlyCreatedFA) {
			// If Override Dispatch Group is supplied
			if (!isEmptyOrNull(parmDispatchGroupOverride)){
				DispatchGroup_Id overrideDispGroupId = new DispatchGroup_Id(parmDispatchGroupOverride.trim());
				// Update if current dispatch group is not the same as Override
				// 2016-08-16. SMiranda. Defect 3494861. Start Change
				//if (!newlyCreatedFA.getDispatchGroupId().equals(overrideDispGroupId)){
				if (notNull(newlyCreatedFA.getDispatchGroupId()) 
						&& !newlyCreatedFA.getDispatchGroupId().equals(overrideDispGroupId)){
				// 2016-08-16. SMiranda. Defect 3494861. End Change	
					StringBuilder updateString = new StringBuilder("");
					updateString.append(" UPDATE ");
					updateString.append("	CI_FA FA ");
					updateString.append(" SET ");
					updateString.append("	FA.DISP_GRP_CD = :overrideDispGroupCd ");
					if (isNull(overrideDispGroupId.getEntity().fetchWorkforceManagementSystem())){
						updateString.append("	,FA.FA_EXT_ID = ' ' ");
						updateString.append("	,FA.FA_INT_STATUS_FLG = ' ' ");
					}
					updateString.append(" WHERE ");
					updateString.append("	FA.FA_ID = :faId ");
					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					//PreparedStatement updateSQL = createPreparedStatement(updateString.toString());
					PreparedStatement updateSQL = createPreparedStatement(updateString.toString(), getClass().getName());
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					updateSQL.bindId("overrideDispGroupCd", new DispatchGroup_Id(parmDispatchGroupOverride.trim()));
					updateSQL.bindId("faId", newlyCreatedFA.getId());
					updateSQL.execute();
					updateSQL.close();
				}
			}
		}
		
		private void createOutboundStagingRecord(FieldActivity fa) {
			
			CmFaIdOutboundInterfaceStagingMaintenance faIdOutStg = CmFaIdOutboundInterfaceStagingMaintenance.Factory.newInstance();
			faIdOutStg.setExternalId(externalId);
			faIdOutStg.setFa(fa);
			faIdOutStg.setServiceTaskType(parmServiceTaskTypeOut);
			faIdOutStg.setSiteId(siteId);
			try{
				faIdOutStg.createFaIdStagingRecords();
			}catch(Exception e){
				addError(CustomMessageRepositoryMGE.cint01812baseError(stagingKey.getStagingKey(), logicalTransactionNumber, e.getMessage()));
			}
			
		}
		
		private void updateFA() {

			// If FA Status is Canceled, cancel the FA
			if (faStatus.isCanceled()){
				cancelFA();
			}else{
				// Get the FA
				FieldActivity fa = faId.getEntity();
				// Update the FA Status, Schedule Date Time, or Instructions
				if (!fa.getFieldActivityStatus().equals(faStatus)
						|| (notNull(scheduleDateTime) && !fa.getScheduleDateTimeStart().equals(scheduleDateTime))
						|| (!isEmptyOrNull(fa.getInstructions()) && !fa.getInstructions().trim().equals(instructions.trim()))
						|| (isEmptyOrNull(fa.getInstructions()) && !isEmptyOrNull(instructions.trim()))){
					FieldActivity_DTO faDTO = fa.getDTO();
					faDTO.setFieldActivityStatus(faStatus);
					if (notNull(scheduleDateTime)){
						faDTO.setScheduleDateTimeStart(scheduleDateTime);
					}
					if (!isEmptyOrNull(fa.getInstructions().trim())){
						instructions = fa.getInstructions().trim() + "; " + instructions;
					}
					faDTO.setInstructions(instructions);
					faDTO.setIntermediateStatus("CREX");
					try{
						fa.setDTO(faDTO);
					}catch(ApplicationError e){
						addError(CustomMessageRepositoryMGE.cint01812baseError(stagingKey.getStagingKey(), logicalTransactionNumber, e.getMessage()));
					}
				}
				// Update the Intermediate Status
				if (!isEmptyOrNull(faIntStatus)){
					if (isEmptyOrNull(fa.getIntermediateStatus())
							|| (!isEmptyOrNull(fa.getIntermediateStatus()) && !fa.getIntermediateStatus().trim().equals(faIntStatus.trim()))){
						FieldActivity_DTO faDTO = fa.getDTO();
						faDTO.setIntermediateStatus(faIntStatus);
						try{
							fa.setDTO(faDTO);
						}catch(ApplicationError e){
							addError(CustomMessageRepositoryMGE.cint01812baseError(stagingKey.getStagingKey(), logicalTransactionNumber, e.getMessage()));
						}
					}
				}
			}						
		}
		
		private void cancelFA() {

			// Cancel FA
			FieldActivityCancelProcessorData faCanProcData = FieldActivityCancelProcessorData.Factory.newInstance();
			faCanProcData.setFieldActivity(faId.getEntity());
			// Set Cancel Reason to "Cancelled by External System" to skip message creation to external system
			faCanProcData.setCancelReason(faCancelReasonId.getEntity());
			// Set switch to check intermediate status to Prevent Cancellation
			faCanProcData.setMustIgnoreExternalSystemCheck(Bool.TRUE);
			FieldActivityCancelProcessor faCanProcessor = FieldActivityCancelProcessor.Factory.newInstance();
			try{
				faCanProcessor.cancel(faCanProcData);
			}catch(ApplicationError e){
				addError(CustomMessageRepositoryMGE.cint01812baseError(stagingKey.getStagingKey(), logicalTransactionNumber, e.getMessage()));
			}
			
		}
		
		@Override
		public boolean handleApplicationError(ApplicationError applicationError, ThreadWorkUnit unit) {
			
			CmInboundInterfaceStaging_Id inboundInterfaceStagingId = (CmInboundInterfaceStaging_Id) unit.getPrimaryId();
			String inboundInterfaceStagingKey = inboundInterfaceStagingId.getStagingKey();
			
			// Inboun Interface Staging record update date time
			DateTime stagingUpdateDateTime = this.getProcessDateTime();
			
			// Update Inbound Interface Staging record to Error status.
			updateInboundInterfaceStagingStatus(inboundInterfaceStagingKey.trim(), CmInterfaceStatusLookup.constants.ERROR, stagingUpdateDateTime);
			
			// Retrieve details of the error encountered.
			String errorCategory = BLANK_VALUE;
			String errorNumber = BLANK_VALUE;
			String errorCode = BLANK_VALUE;
			String errorDescription = BLANK_VALUE;
			String additionalInfo = BLANK_VALUE;
			if(notNull(applicationError)){
				ServerMessage serverMessage = applicationError.getServerMessage();
				if(notNull(serverMessage)){
					errorCategory = serverMessage.getCategory().toString().trim();
					errorNumber = serverMessage.getNumber().toString().trim();
					errorCode = errorCategory.concat(ERROR_CODE_DELIMITER).concat(errorNumber);
					errorDescription = serverMessage.getMessageText().trim();
					if (serverMessage.getLongDescription().length() > 0){
						if (serverMessage.getLongDescription().length() > 200){
							additionalInfo = serverMessage.getLongDescription().substring(0, 200);
						}else{
							additionalInfo = serverMessage.getLongDescription();
						}
					}					
				}
			}
			
			// Create a new Interface Error Log record for the error encountered.
			DateTime stagingCreationDateTime = (DateTime) unit.getSupplementallData("creationDateTime");			
			String logicalTransactionNumber = (String) unit.getSupplementallData("logicalTransactionNumber");
			String originatingKey = (String) unit.getSupplementallData("originatingKey");
			CmInterfaceErrorLogMaintenance interfaceErrorLogMaintenance = CmInterfaceErrorLogMaintenance.Factory.newInstance();
			interfaceErrorLogMaintenance.createInterfaceErrorLog(
					parmSourceSystemName, 
					parmTargetSystemName, 
					logicalTransactionNumber, 
					originationTable, 
					parmServiceTaskType.getId().getTrimmedValue(), 
					errorCode,
					errorDescription, 
					stagingCreationDateTime, 
					stagingUpdateDateTime, 
					parmTargetSystemName, 
					originatingKey, 
					additionalInfo, 
					ERROR_SOURCE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE,
					BLANK_VALUE);
			
			return true;
			
		}
		
		private void updateInboundInterfaceStagingStatus(String stagingKey, CmInterfaceStatusLookup status, DateTime dateTime){
			StringBuilder updateString = new StringBuilder("");
			updateString.append(" UPDATE ");
			updateString.append("	XXL_INT_INBOUND_STG IB ");
			updateString.append(" SET ");
			updateString.append("	IB.STATUS_FLAG = :status ");
			updateString.append("   , IB.UPDATE_DATETIME = :processDateTime ");
			updateString.append(" WHERE ");
			updateString.append("	IB.STAGING_KEY = :stagingKey ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement updateSQL = createPreparedStatement(updateString.toString());	
			PreparedStatement updateSQL = createPreparedStatement(updateString.toString(), getClass().getName());	
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			updateSQL.bindString("stagingKey", stagingKey, "STAGING_KEY");
			updateSQL.bindDateTime("processDateTime", dateTime);
			updateSQL.bindString("status", status.trimmedValue(), "STATUS_FLAG");
			updateSQL.execute();
			updateSQL.close();		
		}

	}

}
