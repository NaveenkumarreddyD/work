/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Adjustment User Exit
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2014-01-30	MCRUZ			MGE-CCB004.007 (CR3135978) Initial Version
 * 								- When invoked for 'add', the program
 * 								checks if the user has the appropriate
 * 								security access level to create an
 * 								adjustment of the specified type. 
 * 2016-01-28  	MPang	  		Updated for CCB v2.4 compilation. 
 * 2022-09-13   EQuint        	B-22188 Add authorization logic
 * 								for no approval adjustment types 
 **************************************************************************/
package com.splwg.cm.domain.adjustment.adjustment;

import com.splwg.base.api.changehandling.AbstractChangeHandler;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.security.applicationService.ApplicationService_Id;
import com.splwg.base.domain.security.securityType.SecurityAuthorizationLevel_Id;
import com.splwg.base.domain.security.securityType.SecurityType_Id;
//Start Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.adjustment.adjustment.Adjustment;
import com.splwg.ccb.domain.admin.adjustmentType.AdjustmentType;*/
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.cm.api.lookup.FinancialTransactionOptionTypeLookup;
//End Add - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author mcruz
 *
 @ChangeHandler (entityName = adjustment)
 */
public class CmAdjustment_CHandler extends AbstractChangeHandler<Adjustment> {
	
	// CCB004.007 (CR3135978) - Adjustment Type Application Service/Security Constants
	private static final String FT_OPT_FEAT_CONFIG = "FIN TRAN OPT";
	private static final String ADJ_APP_SVC_ID = "CILAADUP";
	private static final String ADJ_TYPE_SEC_TYPE = "CM-ADJTYP";
	private static final String SECURITY_AUTH_LVL = "2";
	
	@Override
	public void handleAdd(Adjustment adjustment) {
		
		// Check if the adjustment type is a restricted type.
		
		// start change - EQuint - B-22188 - 2022-09-14
		// if(isAdjustmentRestricted(adjustment.getAdjustmentType()).isTrue()) {
		if(isAdjustmentRestricted(adjustment.getAdjustmentType()).isTrue() || isAdjustmentNoApproval(adjustment.getAdjustmentType()).isTrue()) {
		// end change - EQuint - B-22188 - 2022-09-14

			// Check if the user is authorized to create the adjustment.
			if(isUserAuthorized().isFalse()) {
				// Error: You do not have security access to create an adjustment of type %1.
				addError(CustomMessageRepositoryMGE.ccb004UserNotAuthorized(adjustment.getAdjustmentType().getId().getIdValue().trim()));
			}
		}
	}
	
	/**
	 * This method checks if the adjustment type is listed as a Restricted Adjustment Type on 
	 * the Financial Transaction Options Feature Configuration.
	 * @param AdjustmentType
	 * @return Bool
	 */
	private Bool isAdjustmentRestricted(AdjustmentType adjType) {
	
		FeatureConfiguration_Id featConfigId = new FeatureConfiguration_Id(FT_OPT_FEAT_CONFIG);
		Bool matchFound = Bool.FALSE;
				
        PreparedStatement getAdjTypeMatch = createPreparedStatement("SELECT " +
        		"	OPT.WFM_OPT_VAL " +
        		"FROM " + 
        		"	CI_WFM_OPT OPT " +    
        		"WHERE " +
        		"	OPT.WFM_NAME = :wfmName " +
        		"	AND OPT.EXT_OPT_TYPE = :optType " +
        		//Start Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
        		//"	AND TRIM(OPT.WFM_OPT_VAL) = TRIM(:optVal)");
        		"	AND TRIM(OPT.WFM_OPT_VAL) = TRIM(:optVal)", getClass().getName());
        		//End Change - 2016-01-28 - MPang - Updated for CCB v2.4 compilation
        getAdjTypeMatch.bindId("wfmName", featConfigId);
        getAdjTypeMatch.bindLookup("optType", FinancialTransactionOptionTypeLookup.constants.RESTRICTED_ADJUSTMENT_TYPE);
        getAdjTypeMatch.bindStringProperty("optVal", FeatureConfigurationOption.properties.value, adjType.getId().getIdValue());
		
        if(getAdjTypeMatch.list().size() > 0) {
        	matchFound = Bool.TRUE;
        }
        
        getAdjTypeMatch.close();
        
        return matchFound;
	}
	
	/**
	 * This method checks if the user belongs to a user group having a specific security level on the Adjustment application service.
	 * Adjustment application service must also not be expired and have an 'Add' access mode for the user group. 
	 * @return Bool
	 */
	private Bool isUserAuthorized() {
	
		Bool authFound = Bool.FALSE;
				
		ApplicationService_Id appServiceId = new ApplicationService_Id(ADJ_APP_SVC_ID);
		SecurityType_Id secTypeId = new SecurityType_Id(ADJ_TYPE_SEC_TYPE);
		
		// Validate the Security Type
		if(isNull(secTypeId.getEntity())) {
			// Error: Security type %1 is invalid.
			addError(CustomMessageRepositoryMGE.ccb004InvalidSecurityType(ADJ_TYPE_SEC_TYPE));
		}
		
		// Validate the Authorization Level
		SecurityAuthorizationLevel_Id secAuthLvlId = new SecurityAuthorizationLevel_Id(secTypeId, SECURITY_AUTH_LVL);
		if(isNull(secAuthLvlId.getEntity())) {
			// Error: Authorization level %1 is not valid for security type %2.
			addError(CustomMessageRepositoryMGE.ccb004InvalidAuthorizationLevel(SECURITY_AUTH_LVL, ADJ_TYPE_SEC_TYPE));
		}
		
		// Check if the User has the required Authorization Level
		if(getActiveContextUser().hasAuthorization(appServiceId.getEntity(), secAuthLvlId)) {
			authFound = Bool.TRUE;
		}
		
		return authFound;
	}
	
	// start add - EQuint - B-22188 - 2022-09-14
	/**
	 * This method checks if the adjustment type is listed as a no approval adjustment type on 
	 * the Financial Transaction Options Feature Configuration.
	 * @param AdjustmentType
	 * @return Bool
	 */
	private Bool isAdjustmentNoApproval(AdjustmentType adjType) {
		FeatureConfiguration_Id featConfigId = new FeatureConfiguration_Id(FT_OPT_FEAT_CONFIG);
		Bool matchFound = Bool.FALSE;
				
        PreparedStatement getAdjTypeMatch = createPreparedStatement("SELECT " +
        		"	OPT.WFM_OPT_VAL " +
        		"FROM " + 
        		"	CI_WFM_OPT OPT " +    
        		"WHERE " +
        		"	OPT.WFM_NAME = :wfmName " +
        		"	AND OPT.EXT_OPT_TYPE = :optType " +
        		"	AND TRIM(OPT.WFM_OPT_VAL) = TRIM(:optVal)", getClass().getName());
        getAdjTypeMatch.bindId("wfmName", featConfigId);
        getAdjTypeMatch.bindLookup("optType", FinancialTransactionOptionTypeLookup.constants.NO_APPROVAL_ADJUSTMENT_TYPE);
        getAdjTypeMatch.bindStringProperty("optVal", FeatureConfigurationOption.properties.value, adjType.getId().getIdValue());
		
        if(!getAdjTypeMatch.list().isEmpty()) {
        	matchFound = Bool.TRUE;
        }
        
        getAdjTypeMatch.close();
        
        return matchFound;
	}
	// end add - EQuint - B-22188 - 2022-09-14
}
