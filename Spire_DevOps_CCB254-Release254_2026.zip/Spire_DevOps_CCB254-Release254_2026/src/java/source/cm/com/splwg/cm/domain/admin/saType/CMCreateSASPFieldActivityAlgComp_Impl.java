/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NM0049 - Fieldwork Changes
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2012-11-28   RGullapalli    NM0049-Initial Version.
 * 2012-12-02   RGullapalli    Incorporated Review Comments
 * 2013-05-13   RGullapalli    TIR Incorporated 
 * 2013-06-09   CVB             Fixed code to not use soft parameters for
 *                              Customer Event flag (with Power Status Char)
 *                              and to not use soft parameter for 
 *                              SP Condition Flag. Also, modified code to
 *                              process SPs with no Power Status Char as
 *                              Non-AMR.
 * 2013-07-01   CVB             Fixed code to pickup the FA to cancel even
 *                              when the appointment has changed the FA's 
 *                              scheduled time.                      
 * 2013-07-09   CVB             Fixed SQL for checking back to back to
 *                              ignore Completed FAs so it will not be 
 *                              counted as back to back if FA is already
 *                              complete.    
 * 2014-07-16   Ujesh           IM-051529 - Wrong FA Getting Created on Start 
 *                              Service and Pending Stop FA not getting Cancled 
 * 2016-01-26   MPang			Updated for CCB v2.4 compilation. 
 * 2019-05-08   EQuint			Defect 4253862 - ID56 - set prepared statement auto close
 * 2023-03-29   Kiran       	Ignore this alg for ADDP Route
 **************************************************************************/
package com.splwg.cm.domain.admin.saType;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Lookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.CustomerEventLookup;
import com.splwg.ccb.api.lookup.FieldActivityCreatedByLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointFieldConditionLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.ServiceAgreementSpFaTypeLookup;
//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.fieldActivityCancelReason.FieldActivityCancelReason;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.FieldActivityCancelReason_Id;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.SaTypeSaSpFieldWorkCreationAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementServicePoint_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementSpFieldActivity;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementSpFieldActivity_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementSpFieldActivity_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePointCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCancelProcessorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_Id;*/

import com.splwg.ccb.domain.admin.fieldActivityCancelReason.entity.FieldActivityCancelReason;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.entity.FieldActivityCancelReason_Id;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.meterReadCycle.entity.MeterReadRoute;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saSpFieldWorkCreation.SaTypeSaSpFieldWorkCreationAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCancelProcessorData;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;

/**
 * @author rgullapall003
 *  
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = minThreshold, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = maxThreshold, required = true, type = integer)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = powerStatusCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = customerEvent, name = ssCustEventFlg, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (lookupName = customerEvent, name = ssNonAMRCustEventFlg, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (lookupName = servicePointFieldCondition, name = spConditionFlg, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (name = excludeLogicForRouteTypes, type = string)})
 */
public class CMCreateSASPFieldActivityAlgComp_Impl 
		extends CMCreateSASPFieldActivityAlgComp_Gen 
		implements SaTypeSaSpFieldWorkCreationAlgorithmSpot {
    private ServicePoint paramSp;
    private ServiceAgreementSpFaTypeLookup paramSaSpFieldActivityType;
    private DateTime paramPreviousSaSpEndDateTime;
    private Date paramFutureSaStartDate;
    private ServiceAgreementServicePoint paramSaSp;
    private CharacteristicType paramPowerStatusCharType;
    private Lookup paramStartStopCustomerEvent;
    private Lookup nonAMRCustEvent;
    private Lookup paramSpConditionFlag;
    private ServiceAgreement paramSa;
    private Bool isFaCreated=Bool.FALSE;
    private static final String COMMA_DELIMITER = ",";
    private static final String insideMeterLoc = "IN";
    private FieldActivityType_Id addpFaId = new FieldActivityType_Id("ADDPREAD");
    // CVB - 2013-06-08 - Start
    private DateTime paramPreviousSaSpStartDateTime;
    private DateTime backToBackSaSpDateTime;
    private ServicePointFieldConditionLookup servicePointConditionFlag;
    private CustomerEventLookup customerEventLookupFlag;
    private Bool powerStatus = Bool.FALSE;
    // CVB - 2013-06-08 - End
    private List<MeterReadRouteType> excludedMeterReadRouteTypesList = new ArrayList<MeterReadRouteType>();
    private List<MeterReadRouteType> excludedLogicMeterReadRouteTypesList = new ArrayList<MeterReadRouteType>();
    /**
     * Method to Validate Soft Parameters
     */
    protected void extraSoftParameterValidations()  {

        paramPowerStatusCharType = getPowerStatusCharType();
        paramStartStopCustomerEvent=getSsCustEventFlg();
        nonAMRCustEvent=getSsNonAMRCustEventFlg();
        paramSpConditionFlag=getSpConditionFlg();
        CharacteristicEntity_Id charEntity = new CharacteristicEntity_Id(paramPowerStatusCharType, CharacteristicEntityLookup.constants.SERVICE_POINT);
        if(isNull(charEntity.getEntity())){
            addError(CustomMessageRepository.nm0049InvalidCharType(paramPowerStatusCharType.getId().getIdValue().trim()));
        }
        
        String excludeLogicForRouteTypes = getExcludeLogicForRouteTypes();
        if (notBlank(excludeLogicForRouteTypes)) {

            String[] excludeLogicForRouteTypesList = excludeLogicForRouteTypes.split(COMMA_DELIMITER);

            for (String excludeLogicMeterReadRouteTypeIdString : excludeLogicForRouteTypesList) {

                if (excludeLogicMeterReadRouteTypeIdString.trim().length() > MeterReadRouteType_Id.FIELD_SIZE) {
                    addError(CustomMessageRepositorySpireOne.CCB108_InvalidRouteType(
                    		excludeLogicMeterReadRouteTypeIdString, getAlgorithm()));
                }

                MeterReadRouteType_Id meterReadRouteTypeId = new MeterReadRouteType_Id(excludeLogicMeterReadRouteTypeIdString.trim());
                if (isNull(meterReadRouteTypeId.getEntity())) {
                    addError(CustomMessageRepositorySpireOne.CCB108_InvalidRouteType(
                    		excludeLogicMeterReadRouteTypeIdString, getAlgorithm()));
                }

                excludedLogicMeterReadRouteTypesList.add(meterReadRouteTypeId.getEntity());
            }
        }
        
    }

    public Bool getIsFaCreated() {
        return isFaCreated;
    }

    public void setFaCreated(Bool arg0) {

    }

    public void setSaSpFieldActivityType(ServiceAgreementSpFaTypeLookup arg0) {
        this.paramSaSpFieldActivityType=arg0;
    }

    public void setSaSpStartDateTime(DateTime arg0) {
        // CVB - 2013-06-08 - Start
        this.paramPreviousSaSpStartDateTime=arg0;
        // CVB - 2013-06-08 - End
    }

    public void setSaSpStopDateTime(DateTime arg0) {
        this.paramPreviousSaSpEndDateTime=arg0;
    }

    public void setSaStartDate(Date arg0) {
        this.paramFutureSaStartDate=arg0;
    }

    public void setSaStopDate(Date arg0) {
    }

    public void setServiceAgreement(ServiceAgreement arg0) {
        this.paramSa=arg0;
    }

    public void setServiceAgreementServicePoint(
            ServiceAgreementServicePoint arg0) {
        this.paramSaSp=arg0;
    }

    public void setServicePoint(ServicePoint arg0) {
        this.paramSp=arg0;
    }

    public void setShouldActivateManually(Bool arg0) {

    }

    public void invoke() {

    	// 03-23-2023 Kiran Begin exit for the ADDP Route type
    	
    	MeterReadRoute meterReadRoute = paramSp.fetchMeterReadRoute();
    	
    	if (notNull(meterReadRoute)
                && excludedLogicMeterReadRouteTypesList.contains(meterReadRoute.getMeterReadRouteType()))
    		{
    	if (paramSp.fetchMeterLocation().getId().getIdValue().trim().equals(insideMeterLoc))
    			{
    		
    			}
    	else
    		if(paramSp.getServicePointSourceStatus().isDisconnected())
			{
				// if disconnected and not inside then continue otherwise halt
			}
    		else
			{
    			return;
			}
    		
    	}
    		
        // 03-23-2023 Kiran End
    	
    	
        ServicePointCharacteristic spChar =paramSp.getEffectiveCharacteristic(paramPowerStatusCharType);

        if(isNull(spChar)){
            // CVB - 2013-06-08 - Start 
            powerStatus = Bool.FALSE;
            // return;
        }
        else {
            if (spChar.getCharacteristicValue().trim().equalsIgnoreCase("Y")){
                powerStatus = Bool.TRUE;
            }
            else {
                powerStatus = Bool.FALSE;
            }
            // CVB - 2013-06-08 - End
        }

        // CVB - 2013-06-08 - Start
        servicePointConditionFlag = paramSp.determineFieldCondition();

        if (paramSaSpFieldActivityType.isStartActivity() || paramSaSpFieldActivityType.isStopActivity()){

            Bool faIsBackToBack = isBackToBack();

            if (faIsBackToBack.isTrue()){
                customerEventLookupFlag = CustomerEventLookup.constants.START_STOP;
            }
            else {
                if (paramSaSpFieldActivityType.isStartActivity()){
                    customerEventLookupFlag = CustomerEventLookup.constants.START_SERVICE;
                }        
                if (paramSaSpFieldActivityType.isStopActivity()){
                    customerEventLookupFlag = CustomerEventLookup.constants.STOP_SERVICE;
                }
            }
        }
        // CVB - 2013-06-08 - End

        ServiceAgreementServicePoint_Id lastSaSpId=paramSaSp.getId();
        DateTime ssEndDate=paramPreviousSaSpEndDateTime;
        if(paramSaSpFieldActivityType.isStopActivity()){
            stopActivityProcess(spChar);
        }else if(paramSaSpFieldActivityType.isStartActivity()){
            StringBuilder saSpDetailsRetreivalStmt=new StringBuilder();
            saSpDetailsRetreivalStmt.append("SELECT SS.SA_SP_ID, SS.STOP_DTTM                       ");
            saSpDetailsRetreivalStmt.append("FROM CI_SA_SP SS                                       ");
            saSpDetailsRetreivalStmt.append("WHERE SS.SP_ID = :SpId                                 ");
            saSpDetailsRetreivalStmt.append("AND SS.STOP_DTTM =(SELECT MAX(SS1.STOP_DTTM)           ");
            saSpDetailsRetreivalStmt.append("                   FROM CI_SA_SP SS1                   ");
            saSpDetailsRetreivalStmt.append("                   WHERE SS1.SP_ID = :SpId             ");
            saSpDetailsRetreivalStmt.append("                   AND SS1.STOP_DTTM <= :StartDateTime)");
            PreparedStatement saSpDetailsRetreival = null;
            //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
            // saSpDetailsRetreival=createPreparedStatement(saSpDetailsRetreivalStmt.toString());
            saSpDetailsRetreival=createPreparedStatement(saSpDetailsRetreivalStmt.toString(), getClass().getName());
            //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
            // Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
            saSpDetailsRetreival.setAutoclose(false);
            // End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
            saSpDetailsRetreival.bindId("SpId", paramSp.getId());
            saSpDetailsRetreival.bindDate("StartDateTime", paramFutureSaStartDate);
            if(saSpDetailsRetreival.list().isEmpty()){
                return;
            }
            SQLResultRow resultRow=saSpDetailsRetreival.firstRow();
            saSpDetailsRetreival.close();
            lastSaSpId=(ServiceAgreementServicePoint_Id)resultRow.getId("SA_SP_ID", ServiceAgreementServicePoint.class);
            ssEndDate=resultRow.getDateTime("STOP_DTTM");
            
            // 2013-07-09 - CVB - Start
            Bool stopFAIsPending = isStopStillPending(lastSaSpId);
            if (stopFAIsPending.isFalse()){
                return;
            }
            // 2013-07-09 - CVB - End
            
            StringBuilder faTypeRetreivalStmt=new StringBuilder();
            faTypeRetreivalStmt.append("SELECT FAPT.FA_TYPE_CD                            ");
            faTypeRetreivalStmt.append("FROM   CI_SP SP, CI_SP_TYPE SPT, CI_FAPR_TMPL FAPT   ");
            faTypeRetreivalStmt.append("WHERE  SP.SP_ID = :SpId                           ");
            faTypeRetreivalStmt.append("       AND SP.SP_TYPE_CD = SPT.SP_TYPE_CD            ");
            faTypeRetreivalStmt.append("       AND SPT.FA_TYPE_PROF_CD = FAPT.FA_TYPE_PROF_CD");
            faTypeRetreivalStmt.append("       AND FAPT.CUST_EVT_FLG = :CustEventFlag        ");
            faTypeRetreivalStmt.append("       AND FAPT.SP_COND_FLG = :SpCondFlag            ");
            PreparedStatement faTypeRetreival=null;
            try
            {
            	//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
                // faTypeRetreival=createPreparedStatement(faTypeRetreivalStmt.toString());
                faTypeRetreival=createPreparedStatement(faTypeRetreivalStmt.toString(), getClass().getName());
                //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
                // Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
                faTypeRetreival.setAutoclose(false);
                // End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
                faTypeRetreival.bindId("SpId", paramSp.getId());
                // CVB - 2013-06-08 - Start
                // if(spChar.getCharacteristicValue().trim().equalsIgnoreCase("Y")){
                if(powerStatus.isTrue()){
                    // faTypeRetreival.bindLookup("CustEventFlag", paramStartStopCustomerEvent);
                    faTypeRetreival.bindLookup("CustEventFlag", customerEventLookupFlag);
                }else {
                    // if(spChar.getCharacteristicValue().trim().equalsIgnoreCase("N"))
                    // CVB - 2013-06-08 - End
                    faTypeRetreival.bindLookup("CustEventFlag", nonAMRCustEvent);
                }
                // CVB - 2013-06-08 - Start
                // faTypeRetreival.bindLookup("SpCondFlag", paramSpConditionFlag);
                faTypeRetreival.bindLookup("SpCondFlag", servicePointConditionFlag);
                // CVB - 2013-06-08 - End

                faTypeRetreival.execute();
                if(faTypeRetreival.list().isEmpty()){
                    //Add warning
                    addError(CustomMessageRepository.nm0049FeildActivityTypeNotPresent(paramSp.getId().getIdValue().trim()));
                }
                List<SQLResultRow> fieldActivityTypeList=faTypeRetreival.list();
                FieldActivityType_Id fieldActivityTypeID;
                Bool faIsBackToBack = isBackToBack();
                for(SQLResultRow row:fieldActivityTypeList)
                { 
                    BigInteger days=BigInteger.valueOf(ssEndDate.difference(paramFutureSaStartDate).getTotalDays());
                    fieldActivityTypeID=(FieldActivityType_Id)row.getId("FA_TYPE_CD", FieldActivityType.class);
                    FieldActivityType faType = fieldActivityTypeID.getEntity();
                    if (faIsBackToBack.isTrue())
                    {
                    	meterReadRoute = paramSp.fetchMeterReadRoute();
                    	
                    	if (notNull(meterReadRoute)
                                && excludedLogicMeterReadRouteTypesList.contains(meterReadRoute.getMeterReadRouteType()))
                    		{
                    	if (paramSp.fetchMeterLocation().getId().getIdValue().trim().equals(insideMeterLoc))
                    			{
                    		fieldActivityTypeID = addpFaId;
                    		faType = fieldActivityTypeID.getEntity();
                    			}
                    		}
                    	
                    }
                    
                    if(isNull(faType)){
                        continue;
                    }
                    FieldActivity fa=createFieldActivity(faType, paramFutureSaStartDate.startOfDay());
                    linkFAtoSASP(fa, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY, paramSaSp );
                    if(days.compareTo(BigInteger.ZERO) == 0){
                        linkFAtoSASP(fa, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY, lastSaSpId.getEntity());
                    }
                    // IM-051529 - Start Changes - 2014-07-16 - Ujesh
                    //else if(days.abs().compareTo(BigInteger.ZERO) > 0 && days.abs().compareTo(getMaxThreshold()) <0 && days.abs().compareTo(getMinThreshold()) >0){
                    else if(days.abs().compareTo(BigInteger.ZERO) > 0 && days.abs().compareTo(getMaxThreshold()) <= 0 && days.abs().compareTo(getMinThreshold()) >0){                    
                    
                    // IM-051529 - End Changes - 2014-07-16 - Ujesh
                        FieldActivity fa1 = createFieldActivity(faType, ssEndDate.startOfDay());
                        linkFAtoSASP(fa1, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY, lastSaSpId.getEntity());
                    }
                }
            }
            finally{
                if(notNull(faTypeRetreival)){
                	// Start Change - EQuint - Defect 4253862 - ID56 - 2019-05-09
                    // saSpDetailsRetreival.close();
                	faTypeRetreival.close();
                    // End Change - EQuint - Defect 4253862 - ID56 - 2019-05-09
                }
            }
        }
    }

    /**
     * Create Field Activity using the inputs fieldActivityType, ScheduledDateTime 
     * and eligibilty of the field activity for dispatch.
     * @param faType            -           FieldActivityType
     * @param schedDateTime     -           DateTime
     * @return fieldActivity
     */
    private FieldActivity createFieldActivity(FieldActivityType faType, DateTime schedDateTime){

        FieldActivity fa = null;

        if(isNull(checkFieldActivity(faType, schedDateTime))){
            try{

                FieldActivity_DTO fieldActivityDTO = (FieldActivity_DTO)createDTO(FieldActivity.class);
                fieldActivityDTO.setFieldActivityTypeId(faType.getId());
                fieldActivityDTO.setServicePointId(paramSp.getId());
                fieldActivityDTO.setScheduleDateTimeStart(schedDateTime);
                fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);
                FieldActivityCreatorData faCreatorData = FieldActivityCreatorData.Factory.newInstance();
                faCreatorData.setFaDTO(fieldActivityDTO);

                FieldActivityCreator faCreator = FieldActivityCreator.Factory.newInstance();
                fa = faCreator.addFieldActivity(faCreatorData);
                isFaCreated=Bool.TRUE;
            }catch(ApplicationError e){
                String msg=e.getServerMessage().getMessageText();
                addError(CustomMessageRepository.nm0049ApplicationError(msg));
            }
        }else{
            SQLResultRow faRow = checkFieldActivity(faType, schedDateTime);
            fa = faRow.getEntity("FA_ID", FieldActivity.class);
        }
        return fa;
    }

    /**
     * Method required to process when the SASPFieldActivity is "STOP" 
     * @param spChar
     */

    private void stopActivityProcess(ServicePointCharacteristic spChar){

        StringBuilder retreivePendingSa=new StringBuilder();
        retreivePendingSa.append("SELECT DISTINCT(SS.SA_ID),SS.SA_SP_ID,SS.START_DTTM     ");
        retreivePendingSa.append("FROM CI_SA_SP SS,CI_SA SA                               ");
        retreivePendingSa.append("WHERE SA.SA_TYPE_CD=:SaTypeCd                           ");
        retreivePendingSa.append("      AND SA.CIS_DIVISION = :CisDiv                     ");
        retreivePendingSa.append("      AND SS.START_DTTM >=:PreviousSaEndDate            ");
        retreivePendingSa.append("      AND SS.SP_ID=:SpId                                ");
        retreivePendingSa.append("      AND SA.SA_STATUS_FLG=:SaStatusFlag                ");  
        PreparedStatement retreivePendingSaStmt=null;
        PreparedStatement fieldActivityTypeRetreival=null;
        try{
        	//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
            // retreivePendingSaStmt=createPreparedStatement(retreivePendingSa.toString());
            retreivePendingSaStmt=createPreparedStatement(retreivePendingSa.toString(), getClass().getName());
            //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
            // Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
            retreivePendingSaStmt.setAutoclose(false);
            // End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
            retreivePendingSaStmt.bindStringProperty("SaTypeCd", ServiceAgreementType.properties.saType,paramSa.getServiceAgreementType().getId().getSaType());
            retreivePendingSaStmt.bindId("CisDiv", paramSa.getServiceAgreementType().getId().getDivisionId());
            retreivePendingSaStmt.bindDateTime("PreviousSaEndDate",paramPreviousSaSpEndDateTime);
            retreivePendingSaStmt.bindId("SpId", paramSp.getId());
            retreivePendingSaStmt.bindLookup("SaStatusFlag", ServiceAgreementStatusLookup.constants.PENDING_START);
            retreivePendingSaStmt.execute();
            if(retreivePendingSaStmt.list().isEmpty()){
                return;
            }
            FieldActivity fa;

            StringBuilder fieldActivityTypeRetreivalStmt=new StringBuilder();
            fieldActivityTypeRetreivalStmt.append("SELECT FAPT.FA_TYPE_CD                               ");
            fieldActivityTypeRetreivalStmt.append("FROM CI_SP SP, CI_SP_TYPE SPT, CI_FAPR_TMPL FAPT     ");
            fieldActivityTypeRetreivalStmt.append("WHERE SP.SP_ID = :SpId                               ");
            fieldActivityTypeRetreivalStmt.append("      AND SP.SP_TYPE_CD = SPT.SP_TYPE_CD             ");
            fieldActivityTypeRetreivalStmt.append("      AND SPT.FA_TYPE_PROF_CD = FAPT.FA_TYPE_PROF_CD ");
            fieldActivityTypeRetreivalStmt.append("      AND FAPT.CUST_EVT_FLG = :CustEventFlag         ");
            fieldActivityTypeRetreivalStmt.append("      AND FAPT.SP_COND_FLG = :SpCondFlag             ");
            //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
            // fieldActivityTypeRetreival=createPreparedStatement(fieldActivityTypeRetreivalStmt.toString());
            fieldActivityTypeRetreival=createPreparedStatement(fieldActivityTypeRetreivalStmt.toString(), getClass().getName());
            //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
            // Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
            fieldActivityTypeRetreival.setAutoclose(false);
            // End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
            fieldActivityTypeRetreival.bindId("SpId", paramSp.getId());
            // CVB - 2013-06-08 - Start
            // if(spChar.getCharacteristicValue().trim().equalsIgnoreCase("Y")){
            if(powerStatus.isTrue()){
                //fieldActivityTypeRetreival.bindLookup("CustEventFlag", paramStartStopCustomerEvent);
                fieldActivityTypeRetreival.bindLookup("CustEventFlag", customerEventLookupFlag);
            }else {
                // if(spChar.getCharacteristicValue().trim().equalsIgnoreCase("N"))
                // CVB - 2013-06-08 - End
                fieldActivityTypeRetreival.bindLookup("CustEventFlag", nonAMRCustEvent);
            }
            // CVB - 2013-06-08 - Start
            //fieldActivityTypeRetreival.bindLookup("SpCondFlag", paramSpConditionFlag);
            fieldActivityTypeRetreival.bindLookup("SpCondFlag", servicePointConditionFlag);
            // CVB - 2013-06-08 - End
            fieldActivityTypeRetreival.execute();
            if(fieldActivityTypeRetreival.list().isEmpty()){
                addError(CustomMessageRepository.nm0049FeildActivityTypeNotPresent(paramSp.getId().getIdValue().trim()));
            }
            List<SQLResultRow> fieldActivityTypeList=fieldActivityTypeRetreival.list();
            FieldActivityType_Id fieldActivityType;
            for(SQLResultRow row:fieldActivityTypeList)
            {
                fieldActivityType =(FieldActivityType_Id)row.getId("FA_TYPE_CD", FieldActivityType.class);
                fa=createFieldActivity(fieldActivityType.getEntity(), paramPreviousSaSpEndDateTime);
                linkFAtoSASP(fa, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY, paramSaSp);
            }
        }
        finally{
            if(notNull(retreivePendingSaStmt)){
                retreivePendingSaStmt.close();
            }
            if(notNull(fieldActivityTypeRetreival)){
                fieldActivityTypeRetreival.close();
            }
        }
    }


    /**
     * Method To Check whether any field activities on the same day and 
     * for the same field activity type are created by the base algorithm
     * and if created cancel those field activites.
     * @param sasp - ServiceAgreementServicePoint
     * @param saSpFaLookup- ServiceAgreementSpFaTypeLookup
     * @param fa- FieldActivity
     */
    private void checkPendingFieldActivityAndCancel(ServiceAgreementServicePoint sasp, ServiceAgreementSpFaTypeLookup saSpFaLookup, FieldActivity fa){

        StringBuilder checkPendingFieldActivityStmt=new StringBuilder();
        checkPendingFieldActivityStmt.append("SELECT DISTINCT(SS.FA_ID)                 ");
        checkPendingFieldActivityStmt.append("FROM CI_SA_SP_FA SS, CI_FA FA             ");
        checkPendingFieldActivityStmt.append("WHERE SS.SA_SP_ID=:SaSpId AND             ");
        checkPendingFieldActivityStmt.append("      SS.SA_SP_FA_TYPE_FLG=:SaSpType AND  ");
        checkPendingFieldActivityStmt.append("      FA.FA_ID=SS.FA_ID AND               ");
        // CVB - 2013-07-01 - Start
        //checkPendingFieldActivityStmt.append("      FA.SCHED_DTTM=:Scheduled AND        ");
        checkPendingFieldActivityStmt.append("      TRUNC(FA.SCHED_DTTM) = :Scheduled AND        ");
        // CVB - 2013-07-01 - End
        checkPendingFieldActivityStmt.append("      FA.FA_STATUS_FLG=:FaStatusFlag AND  ");
        checkPendingFieldActivityStmt.append("      FA.FA_ID <> :faId      ");
        PreparedStatement checkPendingFieldActivity= null;
        try{
        	//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
            // checkPendingFieldActivity= createPreparedStatement(checkPendingFieldActivityStmt.toString());
            checkPendingFieldActivity= createPreparedStatement(checkPendingFieldActivityStmt.toString(), getClass().getName());
            //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
            // Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
            checkPendingFieldActivity.setAutoclose(false);
            // End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
            checkPendingFieldActivity.bindId("SaSpId", sasp.getId());
            checkPendingFieldActivity.bindLookup("SaSpType", saSpFaLookup);
            // CVB - 2013-07-01 - Start
            //checkPendingFieldActivity.bindDateTime("Scheduled", fa.getScheduleDateTimeStart());
            checkPendingFieldActivity.bindDate("Scheduled", fa.getScheduleDateTimeStart().getDate());
            // CVB - 2013-07-01 - End
            checkPendingFieldActivity.bindLookup("FaStatusFlag", FieldActivityStatusLookup.constants.PENDING);
            checkPendingFieldActivity.bindId("faId", fa.getId());
            if(checkPendingFieldActivity.list().isEmpty()){
                return;
            }
            List<SQLResultRow> faList=checkPendingFieldActivity.list();
            FieldActivity_Id faId;
            for(SQLResultRow row:faList)
            {
                faId =(FieldActivity_Id)row.getId("FA_ID", FieldActivity.class);
                FieldActivityCancelProcessorData fieldActivityCancelProcessorData=FieldActivityCancelProcessorData.Factory.newInstance();
                FieldActivityCancelReason_Id faCancelId=new FieldActivityCancelReason_Id("SASP");
                FieldActivityCancelReason faCancel=faCancelId.getEntity();
                fieldActivityCancelProcessorData.setFieldActivity(faId.getEntity());
                fieldActivityCancelProcessorData.setCancelReason(faCancel);
                faId.getEntity().cancel(fieldActivityCancelProcessorData);
            }
        }
        finally{
            if(notNull(checkPendingFieldActivity)){
                checkPendingFieldActivity.close();
            }
        }
    }

    /**
     * This Method will link the Created Field Activity to the SASP Maintainance Object
     * @param fa-FieldActivity
     * @param saSpFaLookup-ServiceAgreementSpFaTypeLookup
     * @param sasp-ServiceAgreementServicePoint
     */
    private void linkFAtoSASP(FieldActivity fa, ServiceAgreementSpFaTypeLookup saSpFaLookup, ServiceAgreementServicePoint sasp){

        checkPendingFieldActivityAndCancel(sasp,saSpFaLookup,fa);
        if(checkSaSpFa(sasp, saSpFaLookup,fa).isFalse()){
            try{
                ServiceAgreementSpFieldActivity_Id saSpFieldActivityId = new ServiceAgreementSpFieldActivity_Id(sasp,fa);

                ServiceAgreementSpFieldActivity_DTO saSpFieldActivityDto = (ServiceAgreementSpFieldActivity_DTO)createDTO(ServiceAgreementSpFieldActivity.class); 
                saSpFieldActivityDto.setId(saSpFieldActivityId);

                saSpFieldActivityDto.setFieldActivityType(saSpFaLookup);
                saSpFieldActivityDto.setServiceAgreementId(paramSa.getId());
                saSpFieldActivityDto.setServicePointId(paramSp.getId());

                saSpFieldActivityDto.newEntity();
            }catch(ApplicationError e){
                String msg=e.getServerMessage().getMessageText();
                addError(CustomMessageRepository.nm0049ApplicationError(msg));
            }
        }
    }
    /*
     * TIR comments incorporation Start
     * TIR Reason: Two FA's of the same FA type with one in canclled State and the other in the Pending state, 
     * but only one FA must be created for the FA Type and the Scheduled Date in the pending state.
     */
    /**
     * This Method will check whether a Field Activity of the same FA type and Scheduled time is present.
     * @param faType-FieldActivity Type
     * @param schedDateTime-DateTime
     * 
     */
    private SQLResultRow checkFieldActivity(FieldActivityType faType, DateTime schedDateTime) {

        StringBuilder faQueryStr = new StringBuilder();
        faQueryStr.append(" SELECT FA.FA_ID ");
        faQueryStr.append(" FROM CI_FA FA, CI_SA_SP SS, CI_SA_SP_FA SSF ");
        faQueryStr.append(" WHERE FA.SP_ID=:spId ");
        faQueryStr.append(" AND FA.SP_ID=SS.SP_ID ");
        faQueryStr.append(" AND SSF.FA_ID = FA.FA_ID ");
        faQueryStr.append(" AND FA.FA_TYPE_CD=:faTypeCd ");
        faQueryStr.append(" AND FA.FA_STATUS_FLG <> :faStatus ");
        faQueryStr.append(" AND SSF.SA_SP_ID = SS.SA_SP_ID ");
        faQueryStr.append(" AND FA.SCHED_DTTM = :schedDtTm ");
        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement faPrepStmt = createPreparedStatement(faQueryStr.toString());
        PreparedStatement faPrepStmt = createPreparedStatement(faQueryStr.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
        faPrepStmt.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
        faPrepStmt.bindId("spId", paramSp.getId());
        faPrepStmt.bindId("faTypeCd", faType.getId());
        faPrepStmt.bindLookup("faStatus", FieldActivityStatusLookup.constants.CANCELED);
        faPrepStmt.bindDateTime("schedDtTm", schedDateTime);
        SQLResultRow faRow = faPrepStmt.firstRow();
        faPrepStmt.close();
        return faRow;
    }

    /**
     * This Method will check whether is already attached to the SA/SP for the lookup.
     * @param sasp-ServiceAgreementServicePoint
     * @param saSpFaLookup-ServiceAgreementSpFaTypeLookup
     * @param fa-FieldActivity
     */
    private Bool checkSaSpFa(ServiceAgreementServicePoint sasp, ServiceAgreementSpFaTypeLookup saSpFaLookup, FieldActivity fa){
        StringBuilder faQueryStr = new StringBuilder();
        faQueryStr.append(" SELECT 'X' ");
        faQueryStr.append(" FROM CI_SA_SP_FA  ");
        faQueryStr.append(" WHERE SA_SP_ID=:saSpId ");
        faQueryStr.append(" AND FA_ID=:faId ");
        faQueryStr.append(" AND SA_SP_FA_TYPE_FLG=:faTypeCd ");
        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement faPrepStmt = createPreparedStatement(faQueryStr.toString());
        PreparedStatement faPrepStmt = createPreparedStatement(faQueryStr.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
        faPrepStmt.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
        faPrepStmt.bindId("saSpId", sasp.getId());
        faPrepStmt.bindId("faId", fa.getId());
        faPrepStmt.bindLookup("faTypeCd", saSpFaLookup);
        SQLResultRow faRow = faPrepStmt.firstRow();
        faPrepStmt.close();
        if(isNull(faRow)){
            return Bool.FALSE;
        }else
            return Bool.TRUE;
    }

    /*
     * TIR comments incorporation end.
     */

    // CVB - 2013-06-08 - Start
    private Bool isBackToBack() {

        Bool isBackToBack = Bool.FALSE;

        StringBuilder checkBackToBackString = new StringBuilder();
        checkBackToBackString.append(" SELECT                                                 ");
        checkBackToBackString.append("    S2.START_DTTM,                                      ");
        checkBackToBackString.append("    S2.SA_ID,                                           ");
        checkBackToBackString.append("    S2.SA_SP_ID                                         ");
        checkBackToBackString.append(" FROM                                                   ");
        checkBackToBackString.append("    CI_SA S1,                                           ");
        checkBackToBackString.append("     CI_SA_SP_DT_VW S2                                  ");
        checkBackToBackString.append(" WHERE                                                  ");
        checkBackToBackString.append("    S2.SA_ID = S1.SA_ID                                 ");
        checkBackToBackString.append("     AND S2.SP_ID = :spId                               ");
        checkBackToBackString.append("     AND S2.SA_SP_ID <> :saspId                         ");

        if (paramSaSpFieldActivityType.isStartActivity()){
            checkBackToBackString.append("     AND S1.SA_STATUS_FLG IN ('10','20','30','40')           ");
            checkBackToBackString.append("     AND S2.STOP_DT BETWEEN :startDate AND :endDate    ");
            checkBackToBackString.append("     AND S2.STOP_MR_ID = ' '                           ");
        }

        if (paramSaSpFieldActivityType.isStopActivity()){
            checkBackToBackString.append("     AND S1.SA_STATUS_FLG IN ('10','20','30')           ");
            checkBackToBackString.append("     AND S2.START_DT BETWEEN :startDate AND :endDate    ");
            checkBackToBackString.append("     AND S2.START_MR_ID = ' '                           ");

        }

        checkBackToBackString.append("     AND EXISTS                                         ");
        checkBackToBackString.append("    (SELECT S3.FA_ID                                    ");
        checkBackToBackString.append("     FROM CI_SA_SP_FA S3                                ");
        checkBackToBackString.append("    , CI_FA F1                                          ");
        checkBackToBackString.append("     WHERE S3.SA_SP_ID = S2.SA_SP_ID                    ");
        checkBackToBackString.append("     AND F1.FA_ID = S3.FA_ID                            ");
        // checkBackToBackString.append("     AND F1.FA_STATUS_FLG IN ('H','P','C')              ");
        checkBackToBackString.append("     AND F1.FA_STATUS_FLG IN ('H','P')                  ");

        if (paramSaSpFieldActivityType.isStartActivity()){
            checkBackToBackString.append("     AND S3.SA_SP_FA_TYPE_FLG = 'SP')                   ");
        }
        if (paramSaSpFieldActivityType.isStopActivity()){
            checkBackToBackString.append("     AND S3.SA_SP_FA_TYPE_FLG = 'ST')                   ");    
        }
        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement qry = createPreparedStatement(checkBackToBackString.toString());
        PreparedStatement qry = createPreparedStatement(checkBackToBackString.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
        qry.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
        qry.bindId("spId", paramSp.getId());
        qry.bindId("saspId", paramSaSp.getId());
        
        if (paramSaSpFieldActivityType.isStartActivity()){
            Date startDate = paramPreviousSaSpStartDateTime.addDays(getMaxThreshold().negate().intValue()).getDate();
            qry.bindDate("startDate", startDate);
            qry.bindDate("endDate", paramPreviousSaSpStartDateTime.getDate());
        }
        if (paramSaSpFieldActivityType.isStopActivity()){
            backToBackSaSpDateTime = paramPreviousSaSpEndDateTime;
            Date endDate = paramPreviousSaSpEndDateTime.addDays(getMaxThreshold().intValue()).getDate();
            qry.bindDate("startDate", paramPreviousSaSpEndDateTime.getDate());
            qry.bindDate("endDate", endDate);
        }
        
        SQLResultRow row = qry.firstRow();

        if (notNull(row)){
            isBackToBack = Bool.TRUE;
        }

        qry.close();

        return isBackToBack;

    }
    // CVB - 2013-06-08 - End
    // 2013-07-09 - CVB - Start
    private Bool isStopStillPending(ServiceAgreementServicePoint_Id lastSaspId) {

        Bool isStopStillPending = Bool.FALSE;

        StringBuilder checkPendingFAString = new StringBuilder();
        checkPendingFAString.append(" SELECT FA.FA_ID                                                                      ");
        checkPendingFAString.append("   FROM CI_SA_SP_FA SASPFA                                                            ");
        checkPendingFAString.append("       ,CI_FA FA                                                                      ");
        checkPendingFAString.append("  WHERE SASPFA.SA_SP_ID = :saSpId                                                     ");
        checkPendingFAString.append("    AND SASPFA.SA_SP_FA_TYPE_FLG = 'SP'                                               ");
        checkPendingFAString.append("    AND SASPFA.FA_ID = FA.FA_ID                                                       ");
        checkPendingFAString.append("    AND FA.FA_STATUS_FLG IN ('P','H')                                                 ");
        checkPendingFAString.append("    AND FA.SCHED_DTTM = (SELECT MAX(FA2.SCHED_DTTM)                                   ");
        checkPendingFAString.append("                           FROM CI_SA_SP_FA SASPFA2                                   ");
        checkPendingFAString.append("                               ,CI_FA FA2                                             ");
        checkPendingFAString.append("                          WHERE SASPFA.SA_SP_ID = SASPFA2.SA_SP_ID                    ");
        checkPendingFAString.append("                            AND SASPFA.SA_SP_FA_TYPE_FLG = SASPFA2.SA_SP_FA_TYPE_FLG  ");
        checkPendingFAString.append("                            AND SASPFA2.FA_ID = FA2.FA_ID                             ");
        checkPendingFAString.append("                            AND FA2.FA_STATUS_FLG IN ('P','H'))                       ");
        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement qry = createPreparedStatement(checkPendingFAString.toString());
        PreparedStatement qry = createPreparedStatement(checkPendingFAString.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // Start Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
        qry.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 - 2019-05-09
        qry.bindId("saSpId", lastSaspId);
        
        SQLResultRow row = qry.firstRow();

        if (notNull(row)){
            isStopStillPending = Bool.TRUE;
        }

        qry.close();

        return isStopStillPending;

    }
    // 2013-07-09 - CVB - End
}
