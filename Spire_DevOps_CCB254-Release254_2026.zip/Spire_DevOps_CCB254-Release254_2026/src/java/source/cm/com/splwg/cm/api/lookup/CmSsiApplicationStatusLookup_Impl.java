package com.splwg.cm.api.lookup;

/**
 * @author TMG02493
 *
@LookupFieldname (value = CM_SSI_APP_STATUS)
 */
public class CmSsiApplicationStatusLookup_Impl extends
		CmSsiApplicationStatusLookup_Gen {

}
