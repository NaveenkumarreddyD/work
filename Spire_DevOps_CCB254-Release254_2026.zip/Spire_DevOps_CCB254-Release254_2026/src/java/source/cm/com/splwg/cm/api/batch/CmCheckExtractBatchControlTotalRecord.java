/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Column Delimited Record class for Batch Control Total
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-05-27   RDizon  CCB041. Initial version.        
 **************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

/**
 * @author RDizon
 */
public class CmCheckExtractBatchControlTotalRecord extends ColumnDelimitedRecord {
    
    private static final String DELIMITER = "|";
        
    public CmCheckExtractBatchControlTotalRecord() {
        super(9);
    }
    
    public void setRecordType(String value) {
        this.leftPadColumn(1, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setControlNumber(String runNumber, String rerunNumber) {
    	runNumber = padLeftZeros(runNumber, 10);
    	rerunNumber = padLeftZeros(rerunNumber, 10);
        this.leftPadColumn(2, 21, runNumber + rerunNumber + DELIMITER);
    }

    public void setTotalAmount(String value) {
        this.leftPadColumn(3, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setNumberOfCheckPayments(String value) {
        this.leftPadColumn(4, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setNumberOfACHPayments(String value) {
        this.leftPadColumn(5, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setNumberOfWirePayments(String value) {
        this.leftPadColumn(6, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setNumberOfCardPayments(String value) {
        this.leftPadColumn(7, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setNumberOfVoidRecords(String value) {
        this.leftPadColumn(8, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setNumberOfPPORecords(String value) {
        this.leftPadColumn(9, value.length() + 1, value.trim());
    }
    
    private String padLeftZeros(String inputString, int length) {
        if (inputString.length() >= length) {
            return inputString;
        }
        StringBuilder sb = new StringBuilder();
        while (sb.length() < length - inputString.length()) {
            sb.append('0');
        }
        sb.append(inputString);

        return sb.toString();
    }
    
}
