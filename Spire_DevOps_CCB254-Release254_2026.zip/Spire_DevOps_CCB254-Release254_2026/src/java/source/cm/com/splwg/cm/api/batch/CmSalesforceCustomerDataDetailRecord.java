/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Column Delimited Record class for Detail record of CM-EXSFR Batch Control 
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-10-21   RDizon  CCB046. Initial version.   
 * 2021-12-02   NMendo  Defect 4629503. Replace Premise Type field with 
 *                      Customer Type.     
 *                      
 **************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

/**
 * @author RDizon
 */
public class CmSalesforceCustomerDataDetailRecord extends ColumnDelimitedRecord {
    private static final String DELIMITER = "|";
        
    public CmSalesforceCustomerDataDetailRecord() {
        super(16);
    }
    
    public void setAccount(String value) {
        this.leftPadColumn(1, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setFirstName(String value) {
        this.leftPadColumn(2, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setLastName(String value) {
        this.leftPadColumn(3, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setStreet(String value) {
        this.leftPadColumn(4, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setAddress(String value) {
        this.leftPadColumn(5, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setCity(String value) {
        this.leftPadColumn(6, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setState(String value) {
        this.leftPadColumn(7, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPostalCode(String value) {
        this.leftPadColumn(8, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPhoneNumber(String value) {
        this.leftPadColumn(9, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setEmail(String value) {
        this.leftPadColumn(10, value.length() + 1, value.trim() + DELIMITER);
    }

    // Start Change - NMendo - Defect 4629503 - 2021-12-02
    //public void setPremiseType(String value) {
    public void setCustomerType(String value) {
    // End Change - NMendo - Defect 4629503 - 2021-12-02
       this.leftPadColumn(11, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setBetrw(String value) {
        this.leftPadColumn(12, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setBDate(String value) {
        this.leftPadColumn(13, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setText(String value) {
        this.leftPadColumn(14, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPremiseId(String value) {
        this.leftPadColumn(15, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setBadgeNumber(String value) {
        this.leftPadColumn(16, value.length() + 1, value.trim() + DELIMITER);
    }

}
