/* ************************************************************************
 *                Confidentiality Information:
 *
 * This module is the confidential and proprietary information of
 * Oracle Corporation; it is not to be copied, reproduced, or
 * transmitted in any form, by any means, in whole or in part,
 * nor is it to be used for any purpose other than that for which
 * it is expressly provided without the written permission of
 * Oracle Corporation.
 *
 *
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * Data Correction - Maximo vs CC&B - CC&B Changes - Meter Sampling
 *
 * This batch process will process Maximo data corrections for Meter 
 * Sampling Flag.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:        Reason:
 * YYYY-MM-DD   IN         Reason text.
 *
 * 2015-05-12   RKing      Initial Version.
 * 2016-01-29  	MPang	   Updated for CCB v2.4 compilation. 
 ***************************************************************************/
package com.splwg.cm.domain.batch;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.meterread.meter.Meter;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic_DTO;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristics;
import com.splwg.ccb.domain.meterread.meter.Meter_Id;*/
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic_DTO;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristics;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
//Emd Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.meter.meter.CmMeterDataLog;
import com.splwg.cm.domain.meter.meter.CmMeterDataLog_DTO;

/**
 * @author 90724
 *
 @BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = maximoErrorDescription, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = meterSamplingCharType, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = meterSamplingCharValYes, required = true, type = string)
 *            , @BatchJobSoftParameter (name = meterSamplingCharValNo, required = true, type = string)
 *            })
 */

public class CmMaximoDataCorrectionMeterSamplingBatch
		extends CmMaximoDataCorrectionMeterSamplingBatch_Gen {
	
	// Parameter descriptions.
	private static final String MTR_SAMPLE_CHTY = "Meter Sampling Char Type";
	private static final String CHAR_VAL_YES = "Meter Sampling Yes Char Value";
	private static final String CHAR_VAL_NO = "Meter Sampling No Char Value";

    public JobWork getJobWork() {
    	
    	// Setup bind variables.
    	String errorDescr = " '" + getParameters().getMaximoErrorDescription().trim() + "' ";
	
		StringBuilder mainQuery =  new StringBuilder();
		mainQuery.append(" SELECT ");
		mainQuery.append("    ER.MTR_ID ");
		mainQuery.append("   ,ER.MAXIMO_VALUE ");
		mainQuery.append(" FROM ");
		mainQuery.append("    CM_VALIDATE.CM_VALIDATION_ERROR_METER ER ");
		mainQuery.append(" WHERE ");
		mainQuery.append("    ER.DESCRIPTION = " + errorDescr);
		mainQuery.append("    AND EXISTS (SELECT 'X' ");
		mainQuery.append("          FROM CI_SP_MTR_HIST SPH ");
		mainQuery.append("             ,CI_MTR_CONFIG MC ");
		mainQuery.append("          WHERE MC.MTR_ID = ER.MTR_ID ");
		mainQuery.append("             AND MC.EFF_DTTM = (SELECT MAX(MC2.EFF_DTTM) ");
		mainQuery.append("                  FROM CI_MTR_CONFIG MC2 ");
		mainQuery.append("                  WHERE MC2.MTR_ID = MC.MTR_ID ");
		mainQuery.append("                     AND MC2.EFF_DTTM <= :processDate) ");
		mainQuery.append("             AND MC.MTR_CONFIG_ID = SPH.MTR_CONFIG_ID ");
		mainQuery.append("             AND (SPH.REMOVAL_DTTM IS  NULL OR SPH.REMOVAL_DTTM > :processDate)) ");
		
		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement mainQueryPS = createPreparedStatement(mainQuery.toString());
		PreparedStatement mainQueryPS = createPreparedStatement(mainQuery.toString(), getClass().getName());
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		mainQueryPS.bindDate("processDate", getProcessDateTime().getDate());
		mainQueryPS.execute();
		
		QueryIterator iter = mainQueryPS.iterate();
		
		return createJobWorkForQueryIterator(iter, this);
	}
    
    public ThreadWorkUnit createWorkUnit(QueryResultRow resultRow) {
    	
    	ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        threadWorkUnit.addSupplementalData("mtrId", resultRow.getString("MTR_ID"));    	
        threadWorkUnit.addSupplementalData("maximoValue", resultRow.getString("MAXIMO_VALUE"));
        return threadWorkUnit;
	}
    
    public void validateSoftParameters(boolean isNewRun) {
    	
    	// Char Type must be correct char entity.
    	CharacteristicType meterSamplingCharType = getParameters().getMeterSamplingCharType();
    	CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(meterSamplingCharType, CharacteristicEntityLookup.constants.METER);
        if(isNull(charEntityId.getEntity())) {
            addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharTypeForEntity(MTR_SAMPLE_CHTY, 
            		meterSamplingCharType.getId().getIdValue(), 
            		(CharacteristicEntityLookup.constants.METER).trimmedValue()));
        }
        
    	// Char values must be valid.
    	CharacteristicValue_Id chvYes = new CharacteristicValue_Id(meterSamplingCharType, 
    			getParameters().getMeterSamplingCharValYes());    	
    	if(isNull(chvYes.getEntity())) {
            addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharValueForCharType(
            		CHAR_VAL_YES, 
            		getParameters().getMeterSamplingCharValYes(), 
            		meterSamplingCharType.getId().getIdValue().trim()));
    	}

    	CharacteristicValue_Id chvNo = new CharacteristicValue_Id(meterSamplingCharType, 
    			getParameters().getMeterSamplingCharValNo());
    	if(isNull(chvNo.getEntity())) {
            addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharValueForCharType(
            		CHAR_VAL_NO, 
            		getParameters().getMeterSamplingCharValNo(), 
            		meterSamplingCharType.getId().getIdValue().trim()));
    	}
    }
	
	public Class<CmMaximoDataCorrectionMeterSamplingBatchWorker> getThreadWorkerClass() {
        return CmMaximoDataCorrectionMeterSamplingBatchWorker.class;
    }

    public static class CmMaximoDataCorrectionMeterSamplingBatchWorker 
    		extends CmMaximoDataCorrectionMeterSamplingBatchWorker_Gen {
    	
    	// Constants.
    	private static final String MAXIMO_VALUE_1 = "1";
    	private static final String CI_MTR_CHAR = "CI_MTR_CHAR";
    	private static final String CHAR_VAL = "CHAR_VAL";
    	
    	public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

		@Override
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit) 
				throws ThreadAbortedException, RunAbortedException {

			WorkUnitResult result = new WorkUnitResult(true);
			
			String mtrIdStr = (String) unit.getSupplementallData("mtrId");			
			String maximoValue = ((String) unit.getSupplementallData("maximoValue")).trim();
			
			// Setup char value based on maximo value.
			String newCharVal = "";
			
			if(maximoValue.equals(MAXIMO_VALUE_1)) {
				newCharVal = getParameters().getMeterSamplingCharValYes();
			} else {
				newCharVal = getParameters().getMeterSamplingCharValNo();
			}
			
			// Retrieve meter sampling char type.
			Meter mtr = (new Meter_Id(mtrIdStr)).getEntity();
			CharacteristicType meterSamplingCharType = getParameters().getMeterSamplingCharType();
			MeterCharacteristic meterSamplingChar = mtr.getEffectiveCharacteristic(meterSamplingCharType);
			
			// If no char found, add new meter sampling char using maximo value.
			if(isNull(meterSamplingChar)) {
				
				MeterCharacteristics meterChars = mtr.getCharacteristics();
				MeterCharacteristic_DTO mcDto = meterChars.newChildDTO();
				mcDto.setCharacteristicValue(newCharVal);
				MeterCharacteristic mcNew = meterChars.add(mcDto, meterSamplingCharType.getId(), getProcessDateTime().getDate());				
				cmCreateLog(mcNew, newCharVal, "");
				
			} else {
			
				// Else if char is found, update char value using maximo value.
				String oldCharVal = meterSamplingChar.getCharacteristicValue();
				
				if(!newCharVal.trim().equals(oldCharVal.trim())) {
					MeterCharacteristic_DTO mcDto = meterSamplingChar.getDTO();
					mcDto.setCharacteristicValue(newCharVal);
					meterSamplingChar.setDTO(mcDto);
					cmCreateLog(meterSamplingChar, newCharVal, oldCharVal);
				}
			}
			
			result.setUnitsProcessed(1);
			return result;
		}
		
		private void cmCreateLog(MeterCharacteristic mtrChar, String newValue, String oldValue) {
			
			CmMeterDataLog_DTO logDto = createDTO(CmMeterDataLog.class);
			logDto.setCreationDateTime(getProcessDateTime());
			logDto.setPrimaryKeyValue1(mtrChar.getId().getMeter().getId().getIdValue());
			logDto.setPrimaryKeyValue2(mtrChar.getId().getCharacteristicType().getId().getIdValue());
			logDto.setPrimaryKeyValue3(mtrChar.getId().getEffectiveDate().toString());
			logDto.setTable(CI_MTR_CHAR);
			logDto.setValueAfterUpdate(newValue);
			logDto.setValueBeforeUpdate(oldValue);
	        logDto.setField(CHAR_VAL);
			
			logDto.newEntity();
		}
    }
}