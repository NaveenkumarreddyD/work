/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 2024-07-30   DLampa     INC0037039. Updated field lengths to match 
 *                         the file layout extracted by the CM-BILEXTR 
 *                         algorithm 
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractDetailsBillCalcHeaderRecord 
		extends ColumnDelimitedRecord{	
	
	private String rateClassDescr = " ";
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractDetailsBillCalcHeaderRecord() {
		super(21);
		this.setBPPrinterKey(" ");		
		this.setBPSortKey(" ");
		this.setBPMailingKey(" ");	
		this.setStartDt(" ");
		this.setEndDt(" ");
		this.setSETID(" ");
		this.setRsCd(" ");
		this.setCalcAmt(BigDecimal.ZERO, "0");
		this.setDescrOnBill(" ");
		this.setUtilitySvc(" ");
		this.setRateClsDescr(" ");
		this.setBtuFactor(BigDecimal.ZERO, "0");
		this.setPropane(" ");
		this.setGrossInd(" ");
		this.setGrossAmt(BigDecimal.ZERO, "0");
		this.setTaxCmty(" ");
		this.setTaxCmtyDescr(" ");
		this.setFiller();
		rateClassDescr = " ";
	}
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * 
	 */
	public void setBPPrinterKey(String value) {		
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
	public void setBPSortKey(String value) {
		rightPadColumn(2, 184, truncateInput(value, 184));
	}
	public void setBPMailingKey(String value) {
		rightPadColumn(3, 15, truncateInput(value, 15));
	}	
	/*
	 * Bill Calc Header (List Item)
	 */
	public void setStartDt(String value) {
		rightPadColumn(4, 10, truncateInput(value, 10));
	}
	public void setEndDt(String value) {
		rightPadColumn(5, 10, truncateInput(value, 10));
	}
	public void setSETID(String value) {
		rightPadColumn(6, 10, truncateInput(value, 10));
	}
	public void setRsCd(String value) {
		rightPadColumn(7, 8, truncateInput(value, 8));
	}
	public void setCalcAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(8, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(9, 15, truncateInput(value, 15));
	}
	public void setDescrOnBill(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(10, 80, truncateInput(value, 80));
		rightPadColumn(10, 254, truncateInput(value, 254));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setUtilitySvc(String value) {
		rightPadColumn(11, 1, truncateInput(value, 1));
	}
	public void setRateClsDescr(String value) {
		rateClassDescr = value;
		rightPadColumn(12, 60, truncateInput(value, 60));
	}
	public void setBtuFactor(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(13, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(14, 18, truncateInput(value, 18));
	}
	public void setPropane(String value) {
		rightPadColumn(15, 1, truncateInput(value, 1));
	}
	public void setGrossInd(String value) {
		rightPadColumn(16, 1, truncateInput(value, 1));
	}
	public void setGrossAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(17, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(18, 15, truncateInput(value, 15));
	}
	public void setTaxCmty(String value) {
		rightPadColumn(19, 16, truncateInput(value, 16));
	}
	public void setTaxCmtyDescr(String value) {
		rightPadColumn(20, 60, truncateInput(value, 60));
	}	
	public void setFiller() {
		/*For some reason OLD version has this field to be only 2933 characters long; We are going to follow this instead of using base field length of 3136*/
		//rightPadColumn(21, 3136, " ");
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(21, 2933, " ");
		rightPadColumn(21, 2759, " ");
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	/*
	 * Getter
	 */
	public String getRateClsDescr() {
		return rateClassDescr;
	}
}