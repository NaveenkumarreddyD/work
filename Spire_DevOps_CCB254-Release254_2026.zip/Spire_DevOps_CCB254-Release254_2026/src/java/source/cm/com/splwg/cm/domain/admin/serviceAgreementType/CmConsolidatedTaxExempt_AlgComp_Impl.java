/****************************************************************************************
 * Program Name: CmConsolidatedTaxExempt_AlgComp_Impl
 * Program Title: CmConsolidatedTaxExempt_AlgComp_Impl
 * Author: Jain Akshita
 * Creation Date: 2019-08-06
 * Purpose:The algorithm type will execute when a new consolidated tax SA is activated. 
 * It is responsible for populating the consolidated tax exemption on all active gas service
 * agreements under the account. This will prevent the system from calculating state utility 
 * tax when it calculates the gas service charges Maintenance object for normal degree day
 * 
 ******************************************************************************************/
/*----------------------------------------------------------------------------------------
 *-------------------------- Modification HISTORY: ---------------------------------------
 * ---------------------------------------------------------------------------------------
 * Modification ID:   CCTicket:	  Author:          Date:       Description:
.* --------------------------------------------------------------------------------------
 * CCB003  	       	  45992    	 Jain Akshita     2019-08-06   TMG02493 - Initial Version 
 * CCB003			  45992		 Ravi			  2019-10-10   Incorporating Review comments
 * 															   - Adding a constant 100 for 
 * 															   tax exempt instead of taking 
 * 															   from the bill factor.                
 *                                                      
 *****************************************************************************************/


package com.splwg.cm.domain.admin.serviceAgreementType;

import java.math.BigInteger;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.ccb.api.lookup.ContractTermTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.billFactor.entity.BillFactor;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saActivation.SaTypeSaActivationAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.admin.taxExemptionType.entity.TaxExemptionType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementContractTerm_DTO;
import com.splwg.shared.common.ServerMessage;

/**
 * @author TMG02493
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = taxExemptionType, name = taxExemptType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billFactor, name = consTaxExemptBillFactor, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = serviceType, name = serviceType, required = true, type = entity)})
 */
public class CmConsolidatedTaxExempt_AlgComp_Impl extends
CmConsolidatedTaxExempt_AlgComp_Gen implements
SaTypeSaActivationAlgorithmSpot {

	//Soft parameter variable
	private TaxExemptionType parmTaxExemptType = null;
	private BillFactor parmConsTaxExemptBillFactor = null;
	private ServiceType parmGasMeterdService = null;

	//Working variable
	private Account_Id parmAccountId = null;
	private Date excemptionStartDate = null;

	//Hard parameter variable	
	private ServiceAgreement parmSA = null;

	//Constants
	private BigInteger INV_BF_CAT_NUM = BigInteger.valueOf(3);
	private int INV_BF_MSG_NUM = 32226;
	/*private BigInteger NO_BF_VAL_CAT_NUM = BigInteger.valueOf(11);
	private int NO_BF_VAL_MSG_NUM = 28801;
	private BigInteger NO_BF_CHAR_CAT_NUM = BigInteger.valueOf(4);
	private int NO_BF_CHAR_MSG_NUM = 12867;*/
	private BigDecimal TAX_EXEMPT_PERCENT = new BigDecimal(100);
	
	/*private BillFactorValue vPercentExempt = null;
	private BillFactorCharacteristics vBfChararcteristics = null;*/
	
	@Override
	protected void extraSoftParameterValidations() {
		
		parmConsTaxExemptBillFactor = getConsTaxExemptBillFactor();
		if (parmConsTaxExemptBillFactor.getHasTaxExemptionInContractTerm().isFalse())
		{
			//Base Error Message - Bill Factor %1 may not be used on a Tax Exemption.
			ServerMessageFactory serverMessagesFactory = ServerMessageFactory.Factory.newInstance();
			MessageParameters messageParameters = new MessageParameters();
			messageParameters.addRawString(parmConsTaxExemptBillFactor.getId().getIdValue());
			ServerMessage invTaxExemptionBFServerMsg = serverMessagesFactory.createMessage(new MessageCategory_Id(INV_BF_CAT_NUM), INV_BF_MSG_NUM, messageParameters);
			addError(invTaxExemptionBFServerMsg);
		}

	}

	@Override
	public void invoke() {

		parmTaxExemptType=getTaxExemptType();	
		parmAccountId=parmSA.getAccount().getId();
		parmGasMeterdService=getServiceType();		

		List<SQLResultRow> activeSAList=getActiveSaId();

		for(SQLResultRow activeSaRow:activeSAList){
			ServiceAgreement serviceAgreement =activeSaRow.getEntity("SA_ID",ServiceAgreement.class);
			Date saStartDate=activeSaRow.getDate("START_DT");

			if(saStartDate.isBefore(getProcessDateTime().getDate())){
				excemptionStartDate=parmSA.getStartDate();
			}else{
				excemptionStartDate= saStartDate;
			}
			
			/*vBfChararcteristics  = parmConsTaxExemptBillFactor.getCharacteristics();
			//If no chars found on bill factor.
			if(vBfChararcteristics.size() < 1){
				//Base Error Message - Bill factor characteristic is not found for bill factor %1.
				ServerMessageFactory serverMessagesFactory = ServerMessageFactory.Factory.newInstance();
				MessageParameters messageParameters = new MessageParameters();
				messageParameters.addRawString(parmConsTaxExemptBillFactor.getId().getIdValue());
				ServerMessage noBFCharServerMsg = serverMessagesFactory.createMessage(new MessageCategory_Id(NO_BF_CHAR_CAT_NUM), NO_BF_CHAR_MSG_NUM, messageParameters);
				addError(noBFCharServerMsg);
			}
			
			vPercentExempt = vBfChararcteristics.iterator().next().getEffectiveBillFactorValue(excemptionStartDate);
			
			if(isNull(vPercentExempt)){
				//Base Error Message - No bill factor value found for bill factor %1 effective on %2.
				ServerMessageFactory serverMessagesFactory = ServerMessageFactory.Factory.newInstance();
				MessageParameters messageParameters = new MessageParameters();
				messageParameters.addRawString(parmConsTaxExemptBillFactor.getId().getIdValue());
				messageParameters.addRawString(saStartDate.toString());
				ServerMessage noBFValServerMsg = serverMessagesFactory.createMessage(new MessageCategory_Id(NO_BF_VAL_CAT_NUM), NO_BF_VAL_MSG_NUM, messageParameters);
				addError(noBFValServerMsg);
			}*/

			ServiceAgreementContractTerm_DTO sactDto = new ServiceAgreementContractTerm_DTO();
			sactDto.setTaxExemptTypeId(parmTaxExemptType.getId());
			//sactDto.setPercentExempt(vPercentExempt.getValue().setScale(4));
			sactDto.setPercentExempt(TAX_EXEMPT_PERCENT);
			serviceAgreement.getContractTerms().add(sactDto, parmConsTaxExemptBillFactor.getId(),ContractTermTypeLookup.constants.TAX_EXEMPTION,"", excemptionStartDate);
		}									
	}




	private List<SQLResultRow> getActiveSaId(){
		
		StringBuilder getActiveSaStr=new StringBuilder();

		getActiveSaStr.append("SELECT SA.SA_ID, SA.START_DT ");
		getActiveSaStr.append(" FROM CI_SA SA,CI_SA_TYPE SATY ");
		getActiveSaStr.append(" WHERE SA.ACCT_ID = :accountId ");
		getActiveSaStr.append(" AND SA.CIS_DIVISION = SATY.CIS_DIVISION ");
		getActiveSaStr.append(" AND SA.SA_TYPE_CD = SATY.SA_TYPE_CD ");
		getActiveSaStr.append(" AND SATY.SVC_TYPE_CD = :gasService ");
		getActiveSaStr.append(" AND SA.SA_STATUS_FLG IN (:pendingStart,:active) ");
		getActiveSaStr.append(" AND SA.SA_ID <> :conSAId ");
		PreparedStatement getActiveSaStmt=createPreparedStatement(getActiveSaStr.toString(),"get active SA");

		getActiveSaStmt.bindId("accountId", parmAccountId);
		getActiveSaStmt.bindEntity("gasService",parmGasMeterdService);
		getActiveSaStmt.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
		getActiveSaStmt.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
		getActiveSaStmt.bindId("conSAId", parmSA.getId());

		getActiveSaStmt.setAutoclose(false);
		List<SQLResultRow> saList= getActiveSaStmt.list();
		getActiveSaStmt.close();

		return saList;
	}

	@Override
	public void setServiceAgreement(ServiceAgreement sa) {
		parmSA = sa;
	}


}
