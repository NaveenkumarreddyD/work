/* *************************************************************************************************
 * PROGRAM DESCRIPTION
 *
 * CCB108 - Delayed Transfer Fieldwork Creation 
 *
 * Description
 *
 * This algorithm will be similar to the MO West algorithm CM-FWCR-SUCC, but will not include the 
 * logic to find the succession calendar since AMR meters in MO East have automatic reads every day.
 *
 ***************************************************************************************************
 *
 * CHANGE HISTORY
 *
 * Date:        by:              Reason:
 * YYYY-MM-DD   IN               Reason text.
 *
 * 2021-02-03   JRaymu/NMendo    CCB108. Initial version.
 * 2022-02-03   JVitug           TBD. Updated to create two distinct FAs if there is a 
 *                               back-to-back scenario.
 * 2022-02-08   Kiran Machavarapu The scenario failing is when the meter is inside and the start date is greater than the pending
 * 								  stop date. The algorithm is leaving the M-STOP pending, but for the start it's creating 
 * 								  an M-DAILY or M-READ (depending on the AMR Status). 
 * 								  It should be creating an M-ON because we'll be turning the gas off on the M-STOP.
 * 2023-03-23   Kiran             Ignore this alg for ADDP Routes                               
 **************************************************************************************************/

package com.splwg.cm.domain.admin.serviceAgreementType;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.FieldActivityCreatedByLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.FieldOrderStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementSpFaTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointFieldConditionLookup;
import com.splwg.ccb.api.lookup.SeveranceStatusLookup;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.meterLocation.entity.MeterLocation;
import com.splwg.ccb.domain.admin.meterLocation.entity.MeterLocation_Id;
import com.splwg.ccb.domain.admin.meterReadCycle.entity.MeterReadRoute;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saSpFieldWorkCreation.SaTypeSaSpFieldWorkCreationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.data.SaSpFieldActivityCreatorData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.cm.api.lookup.CustomerEventLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmCancelUnlinkFasOfSaSp;
import com.splwg.cm.domain.common.customBusinessComponent.CmCancelUnlinkFasOfSaSpData;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author JRaymundo
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = numberOfDaysLeadTime, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = backToBackThresholdDays, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = nonDispatchableFieldActivityTypeForMeterRead, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = servicePointFieldCondition, name = spsDesiredStateForMeterRead, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (name = excludeRouteTypes, type = string)
 *            , @AlgorithmSoftParameter (name = excludeMeterLocations, type = string)
 *            , @AlgorithmSoftParameter (name = immediateFaCreation, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = powerStatusSpCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = truePowerStatusCharVal, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = dispatchableFieldActivityTypeForMeterRead, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = excludeLogicForRouteTypes, type = string)})
 *
 */

public class CmDelayedTransferFieldWorkCreationAlgComp_Impl extends
        CmDelayedTransferFieldWorkCreationAlgComp_Gen implements
        SaTypeSaSpFieldWorkCreationAlgorithmSpot {

    // Constants
    private static final String COMMA_DELIMITER = ",";
    private static final String NEVER_CREATE_SINGLE_FA = "N";
    private static final String addpRoute = "ADDP";
    // Soft parameters
    private Bool neverCreateSingleFieldActivity = Bool.FALSE;
    private BigInteger backToBackThresholdDays;
    private List<MeterReadRouteType> excludedMeterReadRouteTypesList = new ArrayList<MeterReadRouteType>();
    private List<MeterReadRouteType> excludedLogicMeterReadRouteTypesList = new ArrayList<MeterReadRouteType>();
    private List<MeterLocation> excludedMeterLocationsList = new ArrayList<MeterLocation>();
    private Bool immediateFaCreation;
    private CharacteristicValue truePowerStatusCharVal;
    
    // Hard parameters - input
    private ServiceAgreementSpFaTypeLookup saSpFieldActivityType;
    private DateTime saSpStartDateTime;
    private DateTime saSpStopDateTime;
    @SuppressWarnings("unused")
    private Date saStartDate;
    @SuppressWarnings("unused")
    private Date saStopDate;
    private ServiceAgreement serviceAgreement;
    private ServiceAgreementServicePoint serviceAgreementServicePoint;
    private ServicePoint servicePoint;
    private Bool shouldActivateManually;

    // Hard parameters - input/output
    private Bool isFaCreated;

    // Working variables
    private Bool isBackToBack = Bool.FALSE;
    private DateTime leastStopDateTime;
    private DateTime scheduleDateTime;
    //Start Add JVitug - TBD - 2022-02-03
    private FieldActivity fa1;
    private FieldActivity fa2;
    Bool hasCreatedFA2 =  Bool.FALSE;
    ServiceAgreementServicePoint futureStoppedPendingStopSASP;
    //End Add JVitug - TBD - 2022-02-03

    private FieldActivityType_Id mONFaId = new FieldActivityType_Id("M-ON");
    private FieldActivityType_Id addpFaId = new FieldActivityType_Id("ADDPREAD");
    // Common component
    private CmCancelUnlinkFasOfSaSp cancelUnlinkFasOfSaSp = CmCancelUnlinkFasOfSaSp.Factory.newInstance();

    public void setSaSpFieldActivityType(ServiceAgreementSpFaTypeLookup saSpFieldActivityType) {
        this.saSpFieldActivityType = saSpFieldActivityType;
    }

    public void setSaSpStartDateTime(DateTime saSpStartDateTime) {
        this.saSpStartDateTime = saSpStartDateTime;
    }

    public void setSaSpStopDateTime(DateTime saSpStopDateTime) {
        this.saSpStopDateTime = saSpStopDateTime;
    }

    public void setSaStartDate(Date saStartDate) {
        this.saStartDate = saStartDate;
    }

    public void setSaStopDate(Date saStopDate) {
        this.saStopDate = saStopDate;
    }

    public void setServiceAgreement(ServiceAgreement serviceAgreement) {
        this.serviceAgreement = serviceAgreement;
    }

    public void setServiceAgreementServicePoint(ServiceAgreementServicePoint serviceAgreementServicePoint) {
        this.serviceAgreementServicePoint = serviceAgreementServicePoint;
    }

    public void setServicePoint(ServicePoint servicePoint) {
        this.servicePoint = servicePoint;
    }

    public void setShouldActivateManually(Bool shouldActivateManually) {
        this.shouldActivateManually = shouldActivateManually;
    }

    public void setFaCreated(Bool isFaCreated) {
        this.isFaCreated = isFaCreated;
    }

    public Bool getIsFaCreated() {
        return this.isFaCreated;
    }

    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        String excludeRouteTypes = getExcludeRouteTypes();
        if (notBlank(excludeRouteTypes)) {

            String[] excludeRouteTypeList = excludeRouteTypes.split(COMMA_DELIMITER);

            for (String excludedMeterReadRouteTypeIdString : excludeRouteTypeList) {

                if (excludedMeterReadRouteTypeIdString.trim().length() > MeterReadRouteType_Id.FIELD_SIZE) {
                    addError(CustomMessageRepositorySpireOne.CCB108_InvalidRouteType(
                            excludedMeterReadRouteTypeIdString, getAlgorithm()));
                }

                MeterReadRouteType_Id meterReadRouteTypeId = new MeterReadRouteType_Id(excludedMeterReadRouteTypeIdString.trim());
                if (isNull(meterReadRouteTypeId.getEntity())) {
                    addError(CustomMessageRepositorySpireOne.CCB108_InvalidRouteType(
                            excludedMeterReadRouteTypeIdString, getAlgorithm()));
                }

                excludedMeterReadRouteTypesList.add(meterReadRouteTypeId.getEntity());
            }
        }

        String excludeLogicForRouteTypes = getExcludeLogicForRouteTypes();
        if (notBlank(excludeLogicForRouteTypes)) {

            String[] excludeLogicForRouteTypesList = excludeLogicForRouteTypes.split(COMMA_DELIMITER);

            for (String excludeLogicMeterReadRouteTypeIdString : excludeLogicForRouteTypesList) {

                if (excludeLogicMeterReadRouteTypeIdString.trim().length() > MeterReadRouteType_Id.FIELD_SIZE) {
                    addError(CustomMessageRepositorySpireOne.CCB108_InvalidRouteType(
                    		excludeLogicMeterReadRouteTypeIdString, getAlgorithm()));
                }

                MeterReadRouteType_Id meterReadRouteTypeId = new MeterReadRouteType_Id(excludeLogicMeterReadRouteTypeIdString.trim());
                if (isNull(meterReadRouteTypeId.getEntity())) {
                    addError(CustomMessageRepositorySpireOne.CCB108_InvalidRouteType(
                    		excludeLogicMeterReadRouteTypeIdString, getAlgorithm()));
                }

                excludedLogicMeterReadRouteTypesList.add(meterReadRouteTypeId.getEntity());
            }
        }

        String excludeMeterLocations = getExcludeMeterLocations();
        if (notBlank(excludeMeterLocations)) {

            String[] excludeMeterLocationList = excludeMeterLocations.split(COMMA_DELIMITER);

            for (String excludedMeterLocationIdString : excludeMeterLocationList) {

                if (excludedMeterLocationIdString.trim().length() > MeterLocation_Id.FIELD_SIZE) {
                    addError(CustomMessageRepositorySpireOne.CCB108_InvalidMeterLocation(
                            excludedMeterLocationIdString, getAlgorithm()));
                }

                MeterLocation_Id meterLocationId = new MeterLocation_Id(excludedMeterLocationIdString.trim());
                if (isNull(meterLocationId.getEntity())) {
                    addError(CustomMessageRepositorySpireOne.CCB108_InvalidMeterLocation(
                            excludedMeterLocationIdString, getAlgorithm()));
                }

                excludedMeterLocationsList.add(meterLocationId.getEntity());
            }
        }

        // Back to Back Threshold Days parameter can either be a string value "N" or an integer
        String backToBackThresholdDaysString = getBackToBackThresholdDays();
        if (NEVER_CREATE_SINGLE_FA.equals(backToBackThresholdDaysString.trim())) {
            neverCreateSingleFieldActivity = Bool.TRUE;
        } else {
            try {
                backToBackThresholdDays = BigInteger.valueOf(Integer.parseInt(backToBackThresholdDaysString));
            } catch (NumberFormatException e) {
                addError(CustomMessageRepositorySpireOne.CCB108_InvalidB2bThresholdDays(NEVER_CREATE_SINGLE_FA, getAlgorithm()));
            }
        }

        immediateFaCreation = getImmediateFaCreation();

        CharacteristicValue_Id truePowerStatusCharValueId = new CharacteristicValue_Id(
                getPowerStatusSpCharType(), getTruePowerStatusCharVal());
        if (isNull(truePowerStatusCharValueId.getEntity())){
            addError(CustomMessageRepositorySpireOne.CCB108_invalidPowerStatus(
                    getPowerStatusSpCharType().getId().getTrimmedValue(), getAlgorithm()));
        }
        
        truePowerStatusCharVal = truePowerStatusCharValueId.getEntity();
        
        super.extraSoftParameterValidations(forAlgorithmValidation);
    }

    /**
     * GA000
     */
    public void invoke() {
    	
    	// 03-23-2023 Kiran Begin exit for the ADDP Route type
    	
    	MeterReadRoute meterReadRoute = servicePoint.fetchMeterReadRoute();
    	
    	if (notNull(meterReadRoute)
                && excludedLogicMeterReadRouteTypesList.contains(meterReadRoute.getMeterReadRouteType()))
    		{
    		if (excludedMeterLocationsList.contains(servicePoint.fetchMeterLocation()))
    			{
    		//if the meter is inside continue
    			}
    		else
    		if(servicePoint.getServicePointSourceStatus().isDisconnected())
    			{
    				// if disconnected and not inside then continue otherwise halt
    			}
    		else
    			{
    		return;
    			}
    		
    	}
    		
        // 03-23-2023 Kiran End
        // Decide if it is time to create the FA
        decideIfTooEarly();

        // Process the pending start/stop SA/SP for the SP
        checkPendingStartStop();

        // Process the pending start/stop SA/SP for same SP type
        checkPendingStartStopForSameSpType();

        // Determine if Back-To-Back situation exists
        checkForBackToBack();
        
        if (shouldActivateManually.isFalse()) {
            // Create Field Activity and Field Activity Steps for SA/SP
            processServiceAgreementServicePoint();

            // Link newly created pending Field Activity
            processFieldActivity();

        } else {
            if (immediateFaCreation.isTrue()){
                processServiceAgreementServicePoint();
                processFieldActivity();

            }else{
                if (saSpFieldActivityType.isStartActivity()
                        && saSpStartDateTime.getDate().isSameOrBefore(getProcessDateTime().getDate())) {
                    processServiceAgreementServicePoint();
                    processFieldActivity();

                }

                if (saSpFieldActivityType.isStopActivity()
                        && saSpStopDateTime.getDate().isSameOrBefore(getProcessDateTime().getDate())) {
                    processServiceAgreementServicePoint();
                    processFieldActivity();
                }
            }
        }
    }

    /**
     * MA000 - If the Manual Activation switch is false and calculated days for START/STOP exceeds the Number of Days Lead Time,
     * it's too early for creating Field Activities.
     */
    private void decideIfTooEarly() {

        if (saSpFieldActivityType.isStartActivity()) {
            // Calculate Date Difference between SASP's Start Date and Business Date
            long startDays = saSpStartDateTime.getDate().difference(getProcessDateTime().getDate()).getDays();

            if (shouldActivateManually.isFalse() && startDays > getNumberOfDaysLeadTime().longValue()) {
                addError(CustomMessageRepositorySpireOne.CCB108_TooEarlyForFa(
                        serviceAgreement, servicePoint, getNumberOfDaysLeadTime(), getAlgorithm()));
            }
        }

        if (saSpFieldActivityType.isStopActivity()) {
            // Calculate Date Difference between SA/SP's Stop Date and Business Date
            long stopDays = saSpStopDateTime.getDate().difference(getProcessDateTime().getDate()).getTotalDays();

            if (shouldActivateManually.isFalse() && stopDays > getNumberOfDaysLeadTime().longValue()) {
                addError(CustomMessageRepositorySpireOne.CCB108_TooEarlyForFa(
                        serviceAgreement, servicePoint, getNumberOfDaysLeadTime(), getAlgorithm()));
            }
        }
    }
    
    /**
     * Check if has active severance process for SA
     * @param saId
     */
    private Bool hasActiveSevProcForSA(ServiceAgreement_Id saId){
        Bool hasActiveSev = Bool.FALSE;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT SEVPROC.SA_ID ");
        stringBuilder.append("FROM CI_SEV_PROC SEVPROC ");
        stringBuilder.append("WHERE SEVPROC.SA_ID = :saId ");
        stringBuilder.append("AND SEVPROC.SEV_STATUS_FLG = :active ");
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("saId", saId);
        preparedStatement.bindLookup("active", SeveranceStatusLookup.constants.ACTIVE);
        
        if(notNull(preparedStatement.firstRow())){
            hasActiveSev = Bool.TRUE;
        }
        preparedStatement.close();
        
        return hasActiveSev;
    }
    
    /**
     * MC000
     */
    private void checkPendingStartStop() {
        // Do not cancel if creating 2 different FAs
        if (neverCreateSingleFieldActivity.isTrue()) {
            return;
        }

        // If FA Type is Start, determine if there is a Pending Stop, Pending Start or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the PAST of the Start Date that has a
        // Non-Dispatched Pending Field Activity for Stop
        if (saSpFieldActivityType.isStartActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.negate().intValue());

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, start1Date, saSpStartDateTime.getDate()
                    , null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            
            if (!results.isEmpty()) {
                // Ensure only latest one is selected
                cancelUnlinkPendingFa(results.get(0), ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }
        }

        // If FA Type is Stop, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the FUTURE of the Stop Date that has a
        // Non-Dispatched Pending Field Activity for Start
        if (saSpFieldActivityType.isStopActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date stop2Date = saSpStopDateTime.getDate().addDays(backToBackThresholdDays.intValue());

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, null, null, saSpStopDateTime.getDate()
                    , stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            
            for (ServiceAgreementServicePoint pendingSaSp : results) {
                cancelUnlinkPendingFa(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
        }
    }

    /**
     * SQ010, SQ030
     * @param servicePoint
     * @param start1Date
     * @param start2Date
     * @param stop1Date
     * @param stop2Date
     * @param serviceAgreementSpFaTypeLookup
     * @return List&lt;ServiceAgreementServicePoint&gt;
     */
    private List<ServiceAgreementServicePoint> getPendingSaSp(ServicePoint servicePoint, Date start1Date, Date start2Date
            , Date stop1Date, Date stop2Date, ServiceAgreementSpFaTypeLookup serviceAgreementSpFaTypeLookup) {

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "S2.STOP_DTTM, ");
        // Selected S2.START_DTTM instead of S2.SA_ID so that query can be used when searching for either Stop or Start
        stringBuilder.append(  "S2.START_DTTM, ");
        stringBuilder.append(  "S2.SA_SP_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA S1, ");
        stringBuilder.append(  "CI_SA_SP_DT_VW S2 ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "S2.SA_ID = S1.SA_ID ");
        stringBuilder.append("AND S2.SP_ID = :servicePoint ");
        stringBuilder.append("AND S1.SA_STATUS_FLG IN (:activeSaStatus , :pendingStopSaStatus, :pendingStartSaStatus) ");
        // Cater for either stop or start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_DT BETWEEN :start1Date AND :start2Date ");
        }
        // Cater for either stop or start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_DT BETWEEN :stop1Date AND :stop2Date ");
        }
        // Cater for either stop or start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_MR_ID = ' ' ");
        }
        // Cater for either stop or start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_MR_ID = ' ' ");
        }
        stringBuilder.append("AND EXISTS ( ");
        stringBuilder.append(  "SELECT ");
        stringBuilder.append(    "S3.FA_ID ");
        stringBuilder.append(  "FROM ");
        stringBuilder.append(    "CI_SA_SP_FA S3, ");
        stringBuilder.append(    "CI_FA F1 ");
        stringBuilder.append(  "WHERE ");
        stringBuilder.append(    "S3.SA_SP_ID = S2.SA_SP_ID ");
        stringBuilder.append(  "AND F1.FA_ID = S3.FA_ID ");
        stringBuilder.append(  "AND F1.FA_STATUS_FLG = :pendingFaStatus ");
        stringBuilder.append(  "AND S3.SA_SP_FA_TYPE_FLG = :saSpFaType ");
        stringBuilder.append(  "AND F1.FA_ID = S3.FA_ID ");
        stringBuilder.append(  "AND ( ");
        stringBuilder.append(    "F1.FO_ID = ' ' ");
        stringBuilder.append(      "OR EXISTS ( ");
        stringBuilder.append(        "SELECT ");
        stringBuilder.append(          "'X' ");
        stringBuilder.append(        "FROM ");
        stringBuilder.append(          "CI_FO FO ");
        stringBuilder.append(        "WHERE ");
        stringBuilder.append(          "F1.FO_ID = FO.FO_ID ");
        stringBuilder.append(        "AND FO.FO_STATUS_FLG = :pendingFoStatus ");
        stringBuilder.append(      ") ");
        stringBuilder.append(    ") ");
        stringBuilder.append(  ") ");
        stringBuilder.append("ORDER BY ");
        // Cater for either stop or start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append(  "S2.STOP_DTTM DESC ");
        }
        // Cater for either stop or start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append(  "S2.START_DTTM DESC ");
        }

        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindLookup("activeSaStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
        preparedStatement.bindLookup("pendingStopSaStatus", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        preparedStatement.bindLookup("pendingStartSaStatus", ServiceAgreementStatusLookup.constants.PENDING_START);
        if (notNull(start1Date) && notNull(start2Date)) {
            preparedStatement.bindDate("start1Date", start1Date);
            preparedStatement.bindDate("start2Date", start2Date);
        }
        if (notNull(stop1Date) && notNull(stop2Date)) {
            preparedStatement.bindDate("stop1Date", stop1Date);
            preparedStatement.bindDate("stop2Date", stop2Date);
        }
        preparedStatement.bindLookup("saSpFaType", serviceAgreementSpFaTypeLookup);
        preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);
        preparedStatement.bindLookup("pendingFoStatus", FieldOrderStatusLookup.constants.PENDEDBY_USER);

        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<ServiceAgreementServicePoint> serviceAgreementServicePointResults = new ArrayList<ServiceAgreementServicePoint>();
        for (SQLResultRow sqlResultRow : results) {
            serviceAgreementServicePointResults.add(sqlResultRow.getEntity("SA_SP_ID", ServiceAgreementServicePoint.class));
        }

        return serviceAgreementServicePointResults;
    }

    /**
     * MC060
     * @param serviceAgreementServicePoint
     * @param serviceAgreementSpFaType
     */
    private void cancelUnlinkPendingFa(ServiceAgreementServicePoint serviceAgreementServicePoint
            , ServiceAgreementSpFaTypeLookup serviceAgreementSpFaType) {

        CmCancelUnlinkFasOfSaSpData data = CmCancelUnlinkFasOfSaSpData.Factory.newInstance();
        data.setServiceAgreementServicePoint(serviceAgreementServicePoint);
        data.setServiceAgreementSpFaType(serviceAgreementSpFaType);
        cancelUnlinkFasOfSaSp.cancelUnlinkFas(data);
    }

    /**
     * ME000
     */
    private void checkPendingStartStopForSameSpType() {

        // Do not cancel if creating 2 different FAs
        if (neverCreateSingleFieldActivity.isTrue()) {
            return;
        }

        // If FA Type is Start, determine if there is a Pending Stop, Pending Start or Active SA/SP for the SP
        // on the exact date as start date that has a Non-Dispatched Field Activity for Start
        if (saSpFieldActivityType.isStartActivity()) {

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, null, null
                    , saSpStartDateTime.getDate(), saSpStartDateTime.getDate(), ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            for (ServiceAgreementServicePoint pendingSaSp : results) {
                cancelUnlinkPendingFa(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
            
        }

        // If FA Type is Stop, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // on the exact date as stop date that has a Non-Dispatched Pending Field Activity for Stop
        if (saSpFieldActivityType.isStopActivity()) {

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, saSpStopDateTime.getDate()
                    , saSpStopDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            for (ServiceAgreementServicePoint pendingSaSp : results) {
                cancelUnlinkPendingFa(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }
        }
    }

    /**
     * MG000
     *
     */
    private void checkForBackToBack() {

        // There is no need to check for back to back if creating separate FAs
        if (neverCreateSingleFieldActivity.isTrue()) {
            return;
        }

        // If FA Type is Start, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the Past of the Start Date
        // without Pending, Held or Completed Field Activity for Stop
        if (saSpFieldActivityType.isStartActivity()) {

            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.negate().intValue());

            //Start Change JVitug - TBD - 2022-02-07
            //List<ServiceAgreementServicePoint> results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    //, start1Date, saSpStartDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            List<ServiceAgreementServicePoint> results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , start1Date, saSpStartDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY , Bool.FALSE);
            //End Change JVitug - TBD - 2022-02-07

            if (!results.isEmpty()) {
                // Assume back to back
                isBackToBack = Bool.TRUE;
                leastStopDateTime = results.get(0).getStopDateTime();
            }
            
            //Start Add JVitug - TBD - 2022-02-04
            //Now check if there is a pending stop SA whose pending stop date is on a later date compared to the 
            //Start date of this new SA. This is to cater a possible back-to-back scenario
            //where a pending stop SA is linked to a SP whose end date is future dated.
            start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.intValue());
            results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint, saSpStartDateTime.getDate(), 
            		start1Date, null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY , Bool.TRUE);

            if (!results.isEmpty()) {
                // Assume back to back
                isBackToBack = Bool.TRUE;
                leastStopDateTime = results.get(0).getStopDateTime();
                futureStoppedPendingStopSASP = results.get(0);
            }
            //End Add JVitug - TBD - 2022-02-04
        }

        // If FA Type is Stop, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the Future of the Stop Date
        // without Pending, Held or Completed Field Activity for Start
        if (saSpFieldActivityType.isStopActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date stop2Date = saSpStopDateTime.getDate().addDays(backToBackThresholdDays.intValue());

          //Start Change JVitug - TBD - 2022-02-07
            //List<ServiceAgreementServicePoint> results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    //, null, null, saSpStopDateTime.getDate(), stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            List<ServiceAgreementServicePoint> results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , null, null, saSpStopDateTime.getDate(), stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY, Bool.FALSE);
          //End Change JVitug - TBD - 2022-02-07

            if (!results.isEmpty()) {
                // Assume back to back
                isBackToBack = Bool.TRUE;
            }
        }
    }

    /**
     * SQ050, SQ070
     * @param servicePoint
     * @param serviceAgreementServicePoint
     * @param start1Date
     * @param start2Date
     * @param stop1Date
     * @param stop2Date
     * @param serviceAgreementSpFaTypeLookup
     * @return List&lt;ServiceAgreementServicePoint&gt;
     */
    private List<ServiceAgreementServicePoint> getOtherSaSpFieldActivities(ServicePoint servicePoint
            , ServiceAgreementServicePoint serviceAgreementServicePoint, Date start1Date, Date start2Date
    //Start Change JVitug - TBD - 2022-02-07
            //, Date stop1Date, Date stop2Date, ServiceAgreementSpFaTypeLookup serviceAgreementSpFaTypeLookup) {
            , Date stop1Date, Date stop2Date, ServiceAgreementSpFaTypeLookup serviceAgreementSpFaTypeLookup, Bool shouldCheckForFutureDatedBackToBack) {
    //End Change JVitug - TBD - 2022-02-07

    	StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "S2.STOP_DTTM, ");
        // Selected S2.START_DTTM instead of S2.SA_ID so that query can be used when searching for either back-to-back Stop or back-to-back Start
        stringBuilder.append(  "S2.START_DTTM, ");
        stringBuilder.append(  "S2.SA_SP_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA S1, ");
        stringBuilder.append(  "CI_SA_SP_DT_VW S2 ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "S2.SA_ID = S1.SA_ID ");
        stringBuilder.append("AND S2.SP_ID = :servicePoint ");
        stringBuilder.append("AND S2.SA_SP_ID <> :serviceAgreementServicePoint ");
        stringBuilder.append("AND S1.SA_STATUS_FLG IN ");
        stringBuilder.append(  "( "); 
        stringBuilder.append(    ":activeSaStatus, :pendingStopSaStatus, :pendingStartSaStatus");
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append(    ", :stoppedSaStatus");
        }
        stringBuilder.append(  ") ");
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_DT BETWEEN :start1Date AND :start2Date ");
        }
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_DT BETWEEN :stop1Date AND :stop2Date ");
        }
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_MR_ID = ' ' ");
        }
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_MR_ID = ' ' ");
        }
        //Start Add JVitug - TBD - 2022-02-07
    	if(shouldCheckForFutureDatedBackToBack.isFalse()) {
    	//End Add JVitug - TBD - 2022-02-07
    		stringBuilder.append("AND NOT EXISTS ");
    		stringBuilder.append(  "( ");
    		stringBuilder.append(    "SELECT ");
    		stringBuilder.append(      "S3.FA_ID ");
    		stringBuilder.append(    "FROM ");
    		stringBuilder.append(      "CI_SA_SP_FA S3, ");
    		stringBuilder.append(      "CI_FA F1 ");
    		stringBuilder.append(    "WHERE ");
    		stringBuilder.append(      "S3.SA_SP_ID = S2.SA_SP_ID ");
    		stringBuilder.append(    "AND S3.SA_SP_FA_TYPE_FLG = :saSpFaType ");
    		stringBuilder.append(    "AND F1.FA_ID = S3.FA_ID ");
    		stringBuilder.append(    "AND F1.FA_STATUS_FLG IN (:heldFaStatus, :pendingFaStatus, :completedFaStatus) ");
    		stringBuilder.append(  ") ");
    	//Start Add JVitug - TBD - 2022-02-07
    	}
    	//End Add JVitug - TBD - 2022-02-07
        stringBuilder.append("ORDER BY ");
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append(  "S2.STOP_DTTM DESC ");
        }
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append(  "S2.START_DTTM DESC ");
        }

        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindId("serviceAgreementServicePoint", serviceAgreementServicePoint.getId());
        preparedStatement.bindLookup("activeSaStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
        preparedStatement.bindLookup("pendingStopSaStatus", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        preparedStatement.bindLookup("pendingStartSaStatus", ServiceAgreementStatusLookup.constants.PENDING_START);
        if (notNull(start1Date) && notNull(start2Date)) {
            preparedStatement.bindLookup("stoppedSaStatus", ServiceAgreementStatusLookup.constants.STOPPED);
        }
        if (notNull(start1Date) && notNull(start2Date)) {
            preparedStatement.bindDate("start1Date", start1Date);
            preparedStatement.bindDate("start2Date", start2Date);
        }
        if (notNull(stop1Date) && notNull(stop2Date)) {
            preparedStatement.bindDate("stop1Date", stop1Date);
            preparedStatement.bindDate("stop2Date", stop2Date);
        }
        //Start Add JVitug - TBD - 2022-02-07
        if(shouldCheckForFutureDatedBackToBack.isFalse()) {
        //End Add JVitug - TBD - 2022-02-07
        	preparedStatement.bindLookup("saSpFaType", serviceAgreementSpFaTypeLookup);
        	preparedStatement.bindLookup("heldFaStatus", FieldActivityStatusLookup.constants.HELD);
        	preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);
        	preparedStatement.bindLookup("completedFaStatus", FieldActivityStatusLookup.constants.COMPLETED);
        //Start Add JVitug - TBD - 2022-02-07
        }
        //End Add JVitug - TBD - 2022-02-07

        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<ServiceAgreementServicePoint> serviceAgreementServicePointResults = new ArrayList<ServiceAgreementServicePoint>();
        for (SQLResultRow sqlResultRow : results) {
            serviceAgreementServicePointResults.add(sqlResultRow.getEntity("SA_SP_ID", ServiceAgreementServicePoint.class));
        }

        return serviceAgreementServicePointResults;
    }

    /**
     * MI000 -  Create FA based on SP condition in FA Profile
     * This is the section that was modified to cater for custom requirements for succession reads.
     */
    private void processServiceAgreementServicePoint() {
        // Retrieve information about the Service Point
        ServicePointFieldConditionLookup spCondition = servicePoint.determineFieldCondition();
        MeterReadRoute meterReadRoute = servicePoint.fetchMeterReadRoute();
        scheduleDateTime = decideScheduleDateTime();

        if (!spCondition.equals(getSpsDesiredStateForMeterRead())) {
            // If the SP's condition does not match the SP's desired State for Meter Read value
            createFieldActivityViaFieldActivityTypeProfile();

        } else if (notNull(meterReadRoute)
                && excludedMeterReadRouteTypesList.contains(meterReadRoute.getMeterReadRouteType())) {
            // If the SP's Route Type is in the Exclude Route Type List (this is not an AMR meter),
            // create FA via FA Type profile
            createFieldActivityViaFieldActivityTypeProfile();

        } else if (saSpFieldActivityType.isStopActivity()
                && notNull(servicePoint.fetchMeterLocation())
                && excludedMeterLocationsList.contains(servicePoint.fetchMeterLocation())) {
            // If the SPs Meter Location is in the Exclude Meter Location list, meaning Meter location is IN
            // create FA via FA Type profile
            createFieldActivityViaFieldActivityTypeProfile();
        } else if(saSpFieldActivityType.isStopActivity() && hasActiveSevProcForSA(serviceAgreement.getId()).isTrue()){
            // If the customer event is Stop Service and the service agreement has an active severance process
            // create FA via FA Type profile
            createFieldActivityViaFieldActivityTypeProfile();
            
        } else {
            ServicePointCharacteristic spChar = servicePoint.getEffectiveCharacteristic(getPowerStatusSpCharType());
            String powerStatusStr = "";
            CharacteristicTypeLookup spCharType = getPowerStatusSpCharType().getCharacteristicType();
            
            if (isNull(spChar)){
                //Start Change JVitug - TBD - 2022-02-03
                //createFieldActivityAndLinkToSaSp(getDispatchableFieldActivityTypeForMeterRead());
                if(saSpFieldActivityType.isStopActivity()) {
                	if (meterReadRoute.getMeterReadRouteType().getId().getIdValue().trim().equals(addpRoute))
                	{
                    fa1 = createFieldActivityAndLinkToSaSp(addpFaId.getEntity(), saSpStopDateTime);
                	}
                	else
                	{
                    fa1 = createFieldActivityAndLinkToSaSp(getDispatchableFieldActivityTypeForMeterRead(), saSpStopDateTime);
                	}
                } else {
                	// Start of change 2022-02-08   Kiran Machavarapu
                	if(isBackToBack.isTrue() || !excludedMeterLocationsList.contains(servicePoint.fetchMeterLocation()))
                			{
                		
                		if (meterReadRoute.getMeterReadRouteType().getId().getIdValue().trim().equals(addpRoute))
                    	{
                        fa1 = createFieldActivityAndLinkToSaSp(addpFaId.getEntity(), saSpStartDateTime);
                    	}
                    	else
                    	{
                    fa1 = createFieldActivityAndLinkToSaSp(getDispatchableFieldActivityTypeForMeterRead() , saSpStartDateTime);
                			}
                			}
                	else
                	{
                		fa1 = createFieldActivityAndLinkToSaSp(mONFaId.getEntity(), saSpStartDateTime);
                		//fa1 = createFieldActivityAndLinkToSaSp(getDispatchableFieldActivityTypeForMeterRead() , saSpStartDateTime);
                	}
                }// end of change 2022-02-08   Kiran Machavarapu
                //End Change JVitug - TBD - 2022-02-03
                
                //Start Add JVitug - TBD - 2022-02-03
                //Only create a second FA if there is a back-to-back situation and 
                // the Pending Stop SA's stop-date-time is earlier than the new SA's
                // start date
                if(isBackToBack.isTrue() && saSpFieldActivityType.isStartActivity()  
                        && (notNull(leastStopDateTime) && leastStopDateTime.isBefore(saSpStartDateTime))) {
                	if (meterReadRoute.getMeterReadRouteType().getId().getIdValue().trim().equals(addpRoute))
                	{
                    fa2 = createFieldActivity(addpFaId.getEntity(), leastStopDateTime);
                	}
                	else
                	{
                    fa2 = createFieldActivity(getDispatchableFieldActivityTypeForMeterRead() , leastStopDateTime);
                    hasCreatedFA2 = Bool.TRUE; 
                }
                }
                //End Add JVitug - TBD - 2022-02-03
            }else{
                if (spCharType.isPredefinedValue()){
                    powerStatusStr = spChar.getCharacteristicValue();
                }else if (spCharType.isForeignKeyValue()){
                    powerStatusStr = spChar.getCharacteristicValueForeignKey1();
                }else{
                    powerStatusStr = spChar.getAdhocCharacteristicValue();
                }
            }
            
            if (powerStatusStr.trim().equals(truePowerStatusCharVal.fetchIdCharacteristicValue().trim())){
                //Start Change JVitug - TBD - 2022-02-03
                //createFieldActivityAndLinkToSaSp(getNonDispatchableFieldActivityTypeForMeterRead());
                if(saSpFieldActivityType.isStopActivity()) {
                    fa1 = createFieldActivityAndLinkToSaSp(getNonDispatchableFieldActivityTypeForMeterRead() , saSpStopDateTime);
                } else {
                	// Start of change 2022-02-08   Kiran Machavarapu
                //    fa1 = createFieldActivityAndLinkToSaSp(getNonDispatchableFieldActivityTypeForMeterRead() , saSpStartDateTime);
                	if(isBackToBack.isTrue() || !excludedMeterLocationsList.contains(servicePoint.fetchMeterLocation()))
        			{
                			fa1 = createFieldActivityAndLinkToSaSp(getNonDispatchableFieldActivityTypeForMeterRead() , saSpStartDateTime);
        			}
                	else
                	{
                		fa1 = createFieldActivityAndLinkToSaSp(mONFaId.getEntity(), saSpStartDateTime);
        		//fa1 = createFieldActivityAndLinkToSaSp(getDispatchableFieldActivityTypeForMeterRead() , saSpStartDateTime);
        	}// end of change 2022-02-08   Kiran Machavarapu
                
                }
                //End Change JVitug - TBD - 2022-02-03
                
                //Start Add JVitug - TBD - 2022-02-03
                //Only create a second FA if there is a back-to-back situation and 
                // the Pending Stop SA's stop-date-time is earlier than the new SA's
                // start date
                if(isBackToBack.isTrue() && saSpFieldActivityType.isStartActivity() 
                        && (notNull(leastStopDateTime) && leastStopDateTime.isBefore(saSpStartDateTime))) {
                    fa2 = createFieldActivity(getNonDispatchableFieldActivityTypeForMeterRead() , leastStopDateTime);
                    hasCreatedFA2 = Bool.TRUE;
                }
                //End Add JVitug - TBD - 2022-02-03
            } else {
                //Start Change JVitug - TBD - 2022-02-03
                //createFieldActivityAndLinkToSaSp(getDispatchableFieldActivityTypeForMeterRead());
                if(saSpFieldActivityType.isStopActivity()) {
                	
                	if (meterReadRoute.getMeterReadRouteType().getId().getIdValue().trim().equals(addpRoute))
                	{
                    fa1 = createFieldActivityAndLinkToSaSp(addpFaId.getEntity(), saSpStopDateTime);
                	}
                	else
                	{
                    fa1 = createFieldActivityAndLinkToSaSp(getDispatchableFieldActivityTypeForMeterRead() , saSpStopDateTime);
                	}
                } else {
                	// Start of change 2022-02-08   Kiran Machavarapu
               //     fa1 = createFieldActivityAndLinkToSaSp(getDispatchableFieldActivityTypeForMeterRead() , saSpStartDateTime);
                
                	if(isBackToBack.isTrue() || !excludedMeterLocationsList.contains(servicePoint.fetchMeterLocation()))
        			{
                		
                    	if (meterReadRoute.getMeterReadRouteType().getId().getIdValue().trim().equals(addpRoute))
                    	{
                        fa1 = createFieldActivityAndLinkToSaSp(addpFaId.getEntity(), saSpStartDateTime);
                    	}
                    	else
                    	{
                			fa1 = createFieldActivityAndLinkToSaSp(getDispatchableFieldActivityTypeForMeterRead() , saSpStartDateTime);
        			}
        			}
                	else
                	{
                		fa1 = createFieldActivityAndLinkToSaSp(mONFaId.getEntity(), saSpStartDateTime);
        		//fa1 = createFieldActivityAndLinkToSaSp(getDispatchableFieldActivityTypeForMeterRead() , saSpStartDateTime);
        	}// end of change 2022-02-08   Kiran Machavarapu
                	
                }
                //End Change JVitug - TBD - 2022-02-03
                
                //Start Add JVitug - TBD - 2022-02-03
                //Only create a second FA if there is a back-to-back situation and 
                // the Pending Stop SA's stop-date-time is earlier than the new SA's
                // start date
                if(isBackToBack.isTrue() && saSpFieldActivityType.isStartActivity()
                        && (notNull(leastStopDateTime) && leastStopDateTime.isBefore(saSpStartDateTime))) {
                	if (meterReadRoute.getMeterReadRouteType().getId().getIdValue().trim().equals(addpRoute))
                	{
                        fa2 = createFieldActivity(addpFaId.getEntity() , leastStopDateTime);
                        hasCreatedFA2 = Bool.TRUE;	
                	}
                	else
                	{
                    fa2 = createFieldActivity(getDispatchableFieldActivityTypeForMeterRead() , leastStopDateTime);
                    hasCreatedFA2 = Bool.TRUE;
                	}
                }
                //End Add JVitug - TBD - 2022-02-03
            }
        }
    }
    
    /**
     * MI040
     * @return scheduleDateTime
     */
    private DateTime decideScheduleDateTime() {

        // If it is START and there is no BACK-to-BACK situation then SCHED-DTTM will be set to START-DTTM,
        // otherwise (i.e. BACK-to-BACK) it will be set to earliest STOP-DTTM among SA/SPs
        if (saSpFieldActivityType.isStartActivity() && isBackToBack.isTrue()) {
            return leastStopDateTime;
        }

        if (saSpFieldActivityType.isStartActivity() && isBackToBack.isFalse()) {
            return saSpStartDateTime;
        }

        // If it is STOP, SCHED-DTTM will be set to STOP-DTTM of SA/SP regardless of BACK-to-BACK situation
        if (saSpFieldActivityType.isStopActivity()) {
            return saSpStopDateTime;
        }

        return null;
    }

    /**
     * PA130
     */
    private void createFieldActivityViaFieldActivityTypeProfile() {
        
        SaSpFieldActivityCreatorData data = SaSpFieldActivityCreatorData.Factory.newInstance();
        data.setServiceAgreementSpFaType(saSpFieldActivityType);
        data.setIsBackToBack(isBackToBack);
        if (saSpFieldActivityType.isStartActivity()){
            data.setCustomerEvent(CustomerEventLookup.constants.START_SERVICE);
        }
        if (saSpFieldActivityType.isStopActivity()){
            data.setCustomerEvent(CustomerEventLookup.constants.STOP_SERVICE);
        }
        if (isBackToBack.isTrue()){
            // Check SP's Power status. If the Power Status is equal to Power Status Char Val, SP is an AMR SP so use
            // Start/Stop Customer Event. Otherwise, if the Power Status on the SP is not equal to the Power Status
            // Char Val or if the SP does not have a Power Status Characteristic, the SP is not an AMR SP so use
            // Start/Stop Non-AMR Customer Event.
            ServicePointCharacteristic spChar = servicePoint.getEffectiveCharacteristic(getPowerStatusSpCharType());

            if (isNull(spChar)){
                data.setCustomerEvent(CustomerEventLookup.constants.X_START_STOP_NON_A_M_R);
            }else{
                String powerStatusStr = "";
                CharacteristicTypeLookup spCharType = getPowerStatusSpCharType().getCharacteristicType();
                if (spCharType.isPredefinedValue()){
                    powerStatusStr = spChar.getCharacteristicValue();
                }else if (spCharType.isForeignKeyValue()){
                    powerStatusStr = spChar.getCharacteristicValueForeignKey1();
                }else{
                    powerStatusStr = spChar.getAdhocCharacteristicValue();
                }
                if (powerStatusStr.trim().equals(truePowerStatusCharVal.fetchIdCharacteristicValue().trim())){
                    data.setCustomerEvent(CustomerEventLookup.constants.START_STOP);
                }else{
                    data.setCustomerEvent(CustomerEventLookup.constants.X_START_STOP_NON_A_M_R);
                }
            }
        }
        
        data.setScheduledDateTime(scheduleDateTime);
        data.setFieldActivityCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);
        data.setIsFaCollectionRequired(Bool.FALSE);

        data = serviceAgreementServicePoint.addFieldActivity(data);

        isFaCreated = data.getIsFaCreated();
    }

    //Start Change JVitug - TBD - 2022-02-03
    //private FieldActivity createFieldActivityAndLinkToSaSp(FieldActivityType fieldActivityType) {
    private FieldActivity createFieldActivityAndLinkToSaSp(FieldActivityType fieldActivityType , DateTime scheduleDateTime) {
    //End Change JVitug - TBD - 2022-02-03
        FieldActivity_DTO fieldActivityDTO = new FieldActivity_DTO();
        fieldActivityDTO.setServicePointId(servicePoint.getId());
        fieldActivityDTO.setFieldActivityTypeId(fieldActivityType.getId());
        fieldActivityDTO.setScheduleDateTimeStart(scheduleDateTime);
        fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);

        FieldActivityCreatorData data = FieldActivityCreatorData.Factory.newInstance();
        data.setFaDTO(fieldActivityDTO);

        FieldActivity fieldActivity = FieldActivityCreator.Factory.newInstance().addFieldActivity(data);

        ServiceAgreementSpFieldActivity_DTO serviceAgreementSpFieldActivityDTO = new ServiceAgreementSpFieldActivity_DTO();
        serviceAgreementSpFieldActivityDTO.setFieldActivityType(saSpFieldActivityType);
        serviceAgreementSpFieldActivityDTO.setServiceAgreementId(serviceAgreementServicePoint.getServiceAgreement().getId());
        serviceAgreementSpFieldActivityDTO.setServicePointId(serviceAgreementServicePoint.getServicePoint().getId());
        serviceAgreementServicePoint.getServiceAgreementSpFieldActivities().add(serviceAgreementSpFieldActivityDTO, fieldActivity.getId());

        isFaCreated = Bool.TRUE;

        return fieldActivity;
    }
    
    //Start Add JVitug - TBD - 2022-02-03
    private FieldActivity createFieldActivity(FieldActivityType fieldActivityType , DateTime scheduledDateTime) {
        FieldActivity_DTO fieldActivityDTO = new FieldActivity_DTO();
        fieldActivityDTO.setServicePointId(servicePoint.getId());
        fieldActivityDTO.setFieldActivityTypeId(fieldActivityType.getId());
        fieldActivityDTO.setScheduleDateTimeStart(scheduleDateTime);
        fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);

        FieldActivityCreatorData data = FieldActivityCreatorData.Factory.newInstance();
        data.setFaDTO(fieldActivityDTO);

        FieldActivity fieldActivity = FieldActivityCreator.Factory.newInstance().addFieldActivity(data);
        
        return fieldActivity;
    }
    //End Add JVitug - TBD - 2022-02-03

    /**
     * MM000 - Retrieve newly created Pending FAs of SA/SP and link to Back-to-Back SA/SPs
     */
    private void processFieldActivity() {

        //Start Add JVitug - TBD - 2022-02-03
        if(hasCreatedFA2.isTrue()) {
            //If another FA was created, this means that there is a back to back SA for the SP. Link FA2 to the pending stop
            //and FA 1 to the active SA
            linkSameType(fa1);
            
            linkB2BSaSpFa(fa2);
        } else {
        //End Add JVitug - TBD - 2022-02-03
            for (FieldActivity fieldActivity : getSaSpFas(serviceAgreementServicePoint)) {

                if (isBackToBack.isTrue()) {
                    linkB2BSaSpFa(fieldActivity);
                }

                linkSameType(fieldActivity);
            }
      //Start Add JVitug - TBD - 2022-02-03
        }
      //End Add JVitug - TBD - 2022-02-03
    }

    /**
     * SQ090
     * @param serviceAgreementServicePoint
     * @return List&lt;FieldActivity&gt;
     */
    private List<FieldActivity> getSaSpFas(ServiceAgreementServicePoint serviceAgreementServicePoint) {

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "SASPFA.FA_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA_SP_FA SASPFA, ");
        stringBuilder.append(  "CI_FA FA ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "SASPFA.SA_SP_ID = :saSpId ");
        stringBuilder.append(  "AND SASPFA.SA_SP_FA_TYPE_FLG = :saSpFaType ");
        stringBuilder.append(  "AND FA.FA_ID = SASPFA.FA_ID ");
        stringBuilder.append(  "AND FA.FA_STATUS_FLG = :pendingFaStatus ");

        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("saSpId", serviceAgreementServicePoint.getId());

        preparedStatement.bindLookup("saSpFaType", saSpFieldActivityType);
        preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);

        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<FieldActivity> fieldActivityResults = new ArrayList<FieldActivity>();
        for (SQLResultRow sqlResultRow : results) {
            fieldActivityResults.add(sqlResultRow.getEntity("FA_ID", FieldActivity.class));
        }

        return fieldActivityResults;
    }

    /**
     * MM020 - Link the Field Activity to the Pending Start and Pending Stop SA/SPs.
     * @param fieldActivity
     */
    private void linkB2BSaSpFa(FieldActivity fieldActivity) {

        if (saSpFieldActivityType.isStartActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.negate().intValue());

            //Start Change JVitug - TBD - 2022-02-07
            //for (ServiceAgreementServicePoint pendingStopSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    //, start1Date, saSpStartDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY)) {
            for (ServiceAgreementServicePoint pendingStopSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , start1Date, saSpStartDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY , Bool.FALSE)) {
            //End Change JVitug - TBD - 2022-02-07

                createSaSpFa(pendingStopSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
                
            }
            
            //Start Add JVitug - TBD - 2022-02-03
            //If there is a future dated pending stop whose stop date is future dated and is within the number of back to back threshold days
            // link the FA created to the future-dated Pending Stop SA and update its end date to be equal to the 
            //start date of the new SA
            if(notNull(futureStoppedPendingStopSASP) && futureStoppedPendingStopSASP.getStopDateTime().isAfter(saStartDate)) {
                //Update the SA's end date 
                ServiceAgreement pendingStopSA = futureStoppedPendingStopSASP.getServiceAgreement();
                ServiceAgreement_DTO pendingStopSA_DTO = pendingStopSA.getDTO();
                pendingStopSA_DTO.setEndDate(saStartDate);
                pendingStopSA.setDTO(pendingStopSA_DTO);
                
                //Update the SA/SP Record of the 
                ServiceAgreementServicePoint_DTO pendingStopSaSpDto = futureStoppedPendingStopSASP.getDTO();
                
                pendingStopSaSpDto.setStopDateTime(saSpStartDateTime);
                futureStoppedPendingStopSASP.setDTO(pendingStopSaSpDto);
                
                //Cancel any pending Stop Activity FAs on the Pending Stop SA
                cancelUnlinkPendingFa(futureStoppedPendingStopSASP, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
                
                //Link the created FA to the pending stop 
                createSaSpFa(futureStoppedPendingStopSASP, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }
            //End Add JVitug - TBD - 2022-02-03
        }

        if (saSpFieldActivityType.isStopActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date stop2Date = saSpStopDateTime.getDate().addDays(backToBackThresholdDays.intValue());

            //Start Change JVitug - TBD - 2022-02-07
            //for (ServiceAgreementServicePoint pendingStartSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    //, null, null, saSpStopDateTime.getDate(), stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY)) {
            for (ServiceAgreementServicePoint pendingStartSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , null, null, saSpStopDateTime.getDate(), stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY , Bool.FALSE)) {
            //End Change JVitug - TBD - 2022-02-07
                createSaSpFa(pendingStartSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
        }
    }

    /**
     * MM060 - Create SA/SP/FA record using the row maintenance.
     */
    private void createSaSpFa(ServiceAgreementServicePoint serviceAgreementServicePoint, FieldActivity fieldActivity
            , ServiceAgreementSpFaTypeLookup lookup) {

        ServiceAgreementSpFieldActivity_Id serviceAgreementSpFieldActivityId = new ServiceAgreementSpFieldActivity_Id(serviceAgreementServicePoint
                , fieldActivity);
        if (isNull(serviceAgreementSpFieldActivityId.getEntity())) {

            ServiceAgreementSpFieldActivity_DTO serviceAgreementSpFieldActivityDTO = new ServiceAgreementSpFieldActivity_DTO();
            serviceAgreementSpFieldActivityDTO.setFieldActivityType(lookup);
            serviceAgreementSpFieldActivityDTO.setServiceAgreementId(serviceAgreementServicePoint.getServiceAgreement().getId());
            serviceAgreementSpFieldActivityDTO.setServicePointId(serviceAgreementServicePoint.getServicePoint().getId());
            serviceAgreementSpFieldActivityDTO.setId(serviceAgreementSpFieldActivityId);
            serviceAgreementSpFieldActivityDTO.newEntity();
        }
    }

    /**
     * MK040 - Link the FA to the Pending Start and Pending Stop SA/SPs
     */
    private void linkSameType(FieldActivity fieldActivity) {
        if (saSpFieldActivityType.isStartActivity()) {
            
        	//Start Change JVitug - TBD - 2022-02-07
            //for (ServiceAgreementServicePoint pendingStartSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    //, null, null, saSpStartDateTime.getDate(), saSpStartDateTime.getDate(), ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY)) {
        	for (ServiceAgreementServicePoint pendingStartSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , null, null, saSpStartDateTime.getDate(), saSpStartDateTime.getDate(), ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY,Bool.FALSE)) {
            //End Change JVitug - TBD - 2022-02-07

                // Cancel field activity and disconnect from SA/SP
                cancelUnlinkPendingFa(pendingStartSaSp, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);

                // Link new FA to SA/SP
                createSaSpFa(pendingStartSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
        }

        if (saSpFieldActivityType.isStopActivity()) {

        	//Start Change JVitug - TBD - 2022-02-07
            //for (ServiceAgreementServicePoint pendingStopSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    //, saSpStopDateTime.getDate(), saSpStopDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY)) {
        	for (ServiceAgreementServicePoint pendingStopSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , saSpStopDateTime.getDate(), saSpStopDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY , Bool.FALSE)) {
            //End Change JVitug - TBD - 2022-02-07

                // Cancel field activity and disconnect from SA/SP
                cancelUnlinkPendingFa(pendingStopSaSp, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);

                // Link new FA to SA/SP
                createSaSpFa(pendingStopSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }
        }
    }
}
