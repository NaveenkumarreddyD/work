/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Customer Data Record for SpeedPay
 * 
 * This class depicts the format for a Customer record for
 * the Customer Data Extract For SpeedPay Batch
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                                                                
 * 2021-05-21  JVitug      CCB031.2.  Initial Version                                                              
 *******************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

/**
 * @author JVitug
 */
public class CmCustomerDataRecordForSpeedPay extends ColumnDelimitedRecord{
    
    //Constants
	private static final String SPACES = " ";
	private static final String EMPTY_STRING = "";
	
    public CmCustomerDataRecordForSpeedPay() {
        super(28);
        setFiller(1 , 5);
    }
    
    public void setAccount(String account) {
        this.rightPadColumn(2, 13, formatString(account , 13));
        
        setFiller(3 , 1);
    }
    
    public void setCustomerName(String customerName) {
        this.rightPadColumn(4, 26, formatString(customerName,26));
        
        setFiller(5 , 3);
    }
    
    public void setHouseNumber(String houseNumber) {
        this.rightPadColumn(6, 5 , formatString(houseNumber , 5));
        
        setFiller(7,5);
    }
    
    public void setStreetName(String streetName) {
        this.rightPadColumn(8, 16, formatString(streetName , 16));
        setFiller(9, 14);
    }
    
    public void setCity(String city) { 
    	this.rightPadColumn(10 , 30 , formatString(city , 30));
    	setFiller(11,1);
    }
    
    public void setPostalCode(String postalCode) {
    	this.rightPadColumn(12, 5 , formatString(postalCode , 5 ));
    	setFiller(13, 1);
    }
    
    public void setAlternateStreet(String alternateStreet) {
    	this.rightPadColumn(14, 35 , formatString(alternateStreet , 35));
    	setFiller(15, 1);
    }
    
    public void setAlternateCity(String alternateCity) {
    	this.rightPadColumn(16, 27 , formatString(alternateCity , 27));
    	setFiller(17, 1);
    }
    
    public void setAlternateState(String alternateState) {
    	this.rightPadColumn(18, 2 , formatString(alternateState , 2));
    	setFiller(19, 1);
    }
    
    public void setAlternatePostalCode(String alternatePostalCode) {
    	this.rightPadColumn(20, 5 , formatString(alternatePostalCode , 5));
    	setFiller(21, 1);
    }
    
    public void setPendingDNP(String isPendingDNP) {
    	this.rightPadColumn(22, 1 , isPendingDNP);
    	setFiller(23, 1);
    }
    
    public void setCashOnly(String isCashOnly) {
    	this.rightPadColumn(24, 1 , isCashOnly);
    	setFiller(25, 1);
    }
    
    public void setDNPForecase(String dnpForecast) {
    	this.rightPadColumn(26, 8 , dnpForecast);
    	setFiller(27, 1);
    }
    
    public void setCurrentBalance(String currentBalance) {
    	this.leftPadColumn(28, 16, formatString(currentBalance , 16));
    }

    /**
     * Set Filler
     * @param columnNumber
     * @param length
     */
    private void setFiller(int columnNumber , int length) {
        this.rightPadColumn(columnNumber, length, SPACES);
    }
    
    /**
     * Returns "" if text is null;
     * Truncates text if length exceed fieldLength;
     * @param text String variable to be formatted
     * @param fieldLength Length of Field
     * @return formatted text
     */
    private String formatString(String text, int fieldLength) {
        if(text == null) {
            text = EMPTY_STRING;
        }
        else {
            text = text.trim();
            if(text.length() > fieldLength) {
                text = text.substring(0, fieldLength);
            }
        }
        return text;
    }

}
