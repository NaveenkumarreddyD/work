/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm will estimate meter reads based on the following criteria:
 * - If usage last year is zero, usage this year should also be zero
 * - Else, look for a bill segment within the last N months with similar 
 *   degree days and use that bill's usage as the estimate for the current
 *   period
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2020-04-07   DLampa      B-15575.1. Initial Version.
 * 2020-07-23   DLampa      Include insertion of derived estimate into the 
 *                          CM_ESTIMATED_RD table.
 * 2020-08-10   DLampa      Updated computation used when a matching bill 
 *                          is found but the degree days is zero. This addresses
 *                          the issue when the total degree days for the 
 *                          estimation period is barely above the ceiling 
 *                          for low degree days.
 * 2020-10-14   DLampa      - Updated to check for a start end end date 
 *                          before proceeding with the computation to correct 
 *                          the estimation period start date.
 *                          - Correct the trend estimation call
 * 2020-10-23   DLampa      - Updated to immediately proceed with trend 
 *                          estimation if the dates for the estimation 
 *                          period cannot be derived.                       
 *                          - Correct validation for the lastReadDttm from 
 *                          MEDRX to trim the value so that a substring error 
 *                          is not raised when the value is spaces. 
 * 2020-11-10   DLampa      Update the query retrieving the previous bill 
 *                          segment to arrange the results by the meter 
 *                          read date/time. This is to ensure that the 
 *                          correct read is returned when a meter exchange 
 *                          occurred within the bill period.
 * 2020-11-26   DLampa      D-02179. Use getTotalDays instead of getDays 
 *                          when deriving the interval between two dates so 
 *                          that the year is considered.                          
 * 2021-01-29   DLampa      D-02207. Include logic to handle meter exchanges 
 *                          within the billing period. 
 * 2021-06-10   DLampa      Defect # 4557018. Updated to correct the value 
 *                          being compared to the estimateType.     
 * 2021-08-09   DLampa      Defect # 4579388. Updated to correct the end 
 *                          reading when a rollover is encountered.
 * 2021-08-13   DLampa      D-4579388. Updated to handle off-cycle reads.   
 * 2021-08-21   DLampa      Updated to address null pointer exception when 
 *                          details on the previous bill segment's usage 
 *                          are not available.
 * 2021-08-25   DLampa      Process off-cycle reads only for subtractive 
 *                          meter configurations.
 * 2021-09-03   DLampa      Update query retrieving the off-cycle reads 
 *                          so they are returned in ascending order of date.
 *                          Suppress the error when a rollover is detected  
 *                          in the off-cycle reads when the estimate type flag 
 *                          is not estimate and hilo.
 * 2021-09-06   DLampa      Update comparisons with the estimate type 
 *                          to check against the constant and the lookup 
 *                          value.
 * 2021-09-08    DLampa     D-4598507. Update the latest register reading  
 *                          when a meter exchange or off-cycle read 
 *                          is encountered. Also update the parameters used 
 *                          in retrieving a meter's installation read so that 
 *                          it includes a timestamp. 
 * 2021-10-05    DLampa     D-4604068. Add a validation when checking for 
 *                          off-cycle reads to ensure that only reads from 
 *                          the same register are compared.  
 * 2021-11-09    DLampa     D-4622696. Ensure that the correct read is used 
 *                          in computing the estimated reading.   
 * 2023-09-26	 EQuint		B-33801. Fix non-numeric data error
 * *************************************************************************
 */

package com.splwg.cm.domain.admin.trendArea.algorithm.meterReadEstimation;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.program.standard.StandardRecords;
import com.splwg.base.api.program.standard.StandardRecordsSyncer;
import com.splwg.base.api.program.types.ArrayField;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.cm.api.lookup.ExternalSystemTypeLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.base.domain.common.data.RecordCICZALPN;
import com.splwg.base.domain.common.data.RecordCICZALPNFragment;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOptionInfo;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOptionsCache;
import com.splwg.base.domain.database.field.Field_Id;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.ConsumptionTypeLookup;
import com.splwg.ccb.api.lookup.EstimateAlgorithmLookup;
import com.splwg.ccb.api.lookup.EstimateTypeLookup;
import com.splwg.ccb.api.lookup.MeterManagementOptionTypeLookup;
import com.splwg.ccb.api.lookup.ReadTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.degreeDay.entity.DegreeDay;
import com.splwg.ccb.domain.admin.degreeDay.entity.DegreeDay_Id;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse;
import com.splwg.ccb.domain.admin.trendArea.algorithm.meterReadEstimation.MeterReadEstimationAlgorithmSpot;
import com.splwg.ccb.domain.admin.trendArea.algorithm.meterReadEstimation.ProgramCIPMETRX;
import com.splwg.ccb.domain.admin.trendArea.entity.TrendArea;
import com.splwg.ccb.domain.admin.trendClass.entity.TrendClass;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.meterread.common.EstimationCommonDataRetriever;
import com.splwg.ccb.domain.meterread.common.NegativeConsumptionOptionRetriever;
import com.splwg.ccb.domain.meterread.data.EstimationCommonData;
import com.splwg.ccb.domain.meterread.data.NegativeConsumptionCheckData;
import com.splwg.ccb.domain.meterread.data.RecordCICMEDRX;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead_Id;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = minimumDaysBetweenReads, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = daysSufficientforEstimation, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = numberOfMonthsToLookBack, required = true, type = integer)            
 *            , @AlgorithmSoftParameter (name = degreeDayLowRangeMultiplier, required = true, type = decimal)
 *            , @AlgorithmSoftParameter (name = degreeDayHighRangeMultiplier, required = true, type = decimal)
 *            , @AlgorithmSoftParameter (name = lowDegreeDayCeiling, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = performTrendEstimation, type = boolean)
 *            , @AlgorithmSoftParameter (name = storeEstimationDetails, type = boolean)
 *            , @AlgorithmSoftParameter (name = billPeriodDaysCeiling, required = true, type = integer)})
 */
public class CmThreeStepUsingCCFPerDegreeDayEstimationAlgComp_Impl extends
        CmThreeStepUsingCCFPerDegreeDayEstimationAlgComp_Gen implements
        MeterReadEstimationAlgorithmSpot {

    // Input hard parameters
    private String estimateType;
    private DateTime readDateTime;
    private Register register;
    private ServicePoint servicePoint;
    private ServiceAgreement serviceAgreement;
    
    // Input/Output hard parameters
    private ConsumptionTypeLookup consumptionType;
    private Bool measuresPeakQuantity;
    private BigInteger numberOfDigitsLeft;
    private BigInteger numberOfDigitsRight;
    private BigInteger numberOfReads;
    private BigDecimal registerConstant;
    private BigDecimal registerReading;
    private TimeOfUse timeOfUse;
    private TrendArea trendArea;
    private TrendClass trendClass;
    private UnitOfMeasure unitOfMeasure;
    
    // Output hard parameters
    private EstimateAlgorithmLookup estimateAlgorithm;
    private BigDecimal estimatedRawUsage;
    private BigDecimal estimatedRegisterReading;
    private Bool isEstimateImpossible;
    private DateTime latestReadDateTime;
    private BigDecimal latestRegisterReading;
    
    // Estimation Common Data
    private Account_Id accountId;
    private Date startDate;
    private Date endDate;
    private Date midPeriodDateLastYear;
    
    // Soft parameters
    private BigInteger minimumDaysBetweenReads;
    private BigInteger daysSufficientforEstimation;
    private BigInteger numberOfMonthsToLookBack;
    private BigDecimal degreeDayLowRangeMultiplier;
    private BigDecimal degreeDayHighRangeMultiplier;
    private BigInteger lowDegreeDayCeiling;
    private Bool performTrendEstimationSw = Bool.FALSE;
    private Bool storeEstimationDetailsSw = Bool.FALSE;
    private BigInteger billPeriodDaysCeiling;
    
    // Debug logger
    private Logger logger = LoggerFactory.getLogger(getClass());
    
    private String performTrendEstimation;
    
    // Work variables
    private BigDecimal prevBillPeriodDegreeDays;
    private BigDecimal currBillPeriodDegreeDays;
    private BigDecimal prevBillPeriodDays;
    private BigDecimal currBillPeriodDays;
    private BillSegment referenceBill;
    private ReadTypeLookup readType;  
    // 2021-08-13 - Start Change
    private RegisterRead offCycleRegReading;
    // 2021-10-05 - D-4604068 - Start Delete
    //private Bool isOffCycleReadFound = Bool.FALSE;
    //private BigDecimal currBillPeriodDaysAfterOffCycleReading;    
    //private BigDecimal currBillPeriodDegreeDaysAfterOffCycleReading;
    // 2021-10-05 - D-4604068 - End Delete
    // 2021-08-13 - End Change   
    // 2021-11-19 - D-4622696 - Start Add
    private Bool isNewSa = Bool.FALSE;
    // 2021-11-19 - D-4622696 - End Add
    
    // Constants
    private static final String EST_TYPE_EST_AND_HI_LOW = "EST&HILOW"; // based on CICMEST8 
    
    @Override
    public void setConsumptionType(ConsumptionTypeLookup consumptionType) {
        this.consumptionType = consumptionType;
    }

    @Override
    public void setEstimationType(String estimationType) {
        estimateType = estimationType;
    }

    @Override
    public void setMeasuresPeakQuantity(Bool measuresPeakQuantity) {
        this.measuresPeakQuantity = measuresPeakQuantity;
    }

    @Override
    public void setNumberOfDigitsLeft(BigInteger numberOfDigitsLeft) {
        this.numberOfDigitsLeft = numberOfDigitsLeft;
    }

    @Override
    public void setNumberOfDigitsRight(BigInteger numberOfDigitsRight) {
        this.numberOfDigitsRight = numberOfDigitsRight;
    }

    @Override
    public void setNumberOfReads(BigInteger numberOfReads) {
        this.numberOfReads = numberOfReads;
    }

    @Override
    public void setReadDateTime(DateTime readDateTime) {
        this.readDateTime = readDateTime;
    }

    @Override
    public void setRegister(Register register) {
        this.register = register;
    }

    @Override
    public void setRegisterConstant(BigDecimal registerConstant) {
        this.registerConstant = registerConstant;
    }

    @Override
    public void setRegisterReading(BigDecimal registerReading) {
        this.registerReading = registerReading;
    }

    @Override
    public void setServiceAgreement(ServiceAgreement serviceAgreement) {
        this.serviceAgreement = serviceAgreement;
    }

    @Override
    public void setServicePoint(ServicePoint servicePoint) {
        this.servicePoint = servicePoint;
    }

    @Override
    public void setTimeOfUse(TimeOfUse timeOfUse) {
        this.timeOfUse = timeOfUse;
    }

    @Override
    public void setTrendArea(TrendArea trendArea) {
        this.trendArea = trendArea;
    }

    @Override
    public void setTrendClass(TrendClass trendClass) {
        this.trendClass = trendClass;
    }

    @Override
    public void setUnitOfMeasure(UnitOfMeasure unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
    }
    
    @Override
    public ConsumptionTypeLookup getConsumptionTypeLookup() {
        return consumptionType;
    }

    @Override
    public EstimateAlgorithmLookup getEstimateAlgorithm() {
        return estimateAlgorithm;
    }

    @Override
    public BigDecimal getEstimatedRawUsage() {
        return estimatedRawUsage;
    }

    @Override
    public BigDecimal getEstimatedRegisterReading() {
        return estimatedRegisterReading;
    }

    @Override
    public Bool getIsEstimateImpossible() {
        return isEstimateImpossible;
    }

    @Override
    public DateTime getLatestReadDateTime() {
        return latestReadDateTime;
    }

    @Override
    public BigDecimal getLatestRegisterReading() {
        return latestRegisterReading;
    }

    @Override
    public Bool getMeasuresPeakQuantity() {
        return measuresPeakQuantity;
    }

    @Override
    public BigInteger getNumberOfDigitsLeft() {
        return numberOfDigitsLeft;
    }

    @Override
    public BigInteger getNumberOfDigitsRight() {
        return numberOfDigitsRight;
    }

    @Override
    public BigInteger getNumberOfReads() {
        return numberOfReads;
    }

    @Override
    public BigDecimal getRegisterConstant() {
        return registerConstant;
    }

    @Override
    public BigDecimal getRegisterReading() {
        return registerReading;
    }

    @Override
    public TimeOfUse getTimeOfUse() {
        return timeOfUse;
    }

    @Override
    public TrendArea getTrendArea() {
        return trendArea;
    }

    @Override
    public TrendClass getTrendClass() {
        return trendClass;
    }

    @Override
    public UnitOfMeasure getUnitOfMeasure() {
        return unitOfMeasure;
    }

    @Override
    public void invoke() {

        // Initialize program
        initialize();
        
        // Validate Input
        checkInput();
        
        // Perform Process
        performProc();
        
    }
    
    /**
     * CA000-INITIALIZE
     * Initialize program
     */
    private void initialize() {
        
        isEstimateImpossible = Bool.FALSE;

    }
    
    /**
     * EA000-CHECK-INPUT
     * Validate input
     */
    private void checkInput() {
        
        // Register ID is required
        if (isNull(register)) {
            addError(CustomMessageRepositorySpireOne.B15575_1_FieldMissing(new Field_Id("REG_ID")));
        }

        // Retrieve feature option for meter management that indicates if same UOM/TOU value
        FeatureConfigurationOptionInfo featureConfigurationOptionInfo = FeatureConfigurationOptionsCache.getHighestSequenceOptionFor(ExternalSystemTypeLookup.constants.METER_MANAGEMENT_OPTIONS, MeterManagementOptionTypeLookup.constants.ALLOW_DUPLICATE_UOM_TOU);
        if (notNull(featureConfigurationOptionInfo)) {
            if ("Y".equals(featureConfigurationOptionInfo.getValue().trim())) {

                // If the value of the Allow Same UOM/TOU combination is Yes then this estimation routine should not be used.
                if (checkForDuplicateUomTouCombinations(register).intValue() > 0) {
                    addError(CustomMessageRepositorySpireOne.B15575_1_BaseEstimationNotAllowed());
                }
            }
        }

        // SP ID is required
        if (isNull(servicePoint)) {
            addError(CustomMessageRepositorySpireOne.B15575_1_FieldMissing(new Field_Id("SP_ID")));
        }
        
        // Read Date/Time is required
        if (isNull(readDateTime)) {
            addError(CustomMessageRepositorySpireOne.B15575_1_FieldMissing(new Field_Id("READ_DTTM")));
        }
        
        // See extraSoftParameterValidations for Soft Parameter validation

    }
    

    /**
     * Check if there are other register reads with the same TOU , UOM combination
     * in the meter linked to the register being processed
     * @return
     */
    private BigInteger checkForDuplicateUomTouCombinations(Register register){
        StringBuilder stringCheckForDuplicates = new StringBuilder();
        PreparedStatement queryCheckForDuplicates;
        
        stringCheckForDuplicates.append("SELECT COUNT('X') COUNT ");
        stringCheckForDuplicates.append("FROM CI_REG REG ");
        stringCheckForDuplicates.append("WHERE REG.REG_ID <> :registerId ");
        stringCheckForDuplicates.append(  "AND REG.UOM_CD = :uom ");
        stringCheckForDuplicates.append(  "AND REG.TOU_CD = :tou ");
        stringCheckForDuplicates.append(  "AND REG.MTR_ID = :mr ");
        stringCheckForDuplicates.append(  "AND REG.EFF_DTTM = :date ");
        
        queryCheckForDuplicates = createPreparedStatement(stringCheckForDuplicates.toString(), this.getClass().getName());
        queryCheckForDuplicates.bindId("registerId", register.getId());
        queryCheckForDuplicates.bindId("uom",unitOfMeasure.getId());
        queryCheckForDuplicates.bindId("tou", timeOfUse.getId());
        queryCheckForDuplicates.bindId("mr",register.getMeterConfiguration().getMeter().getId());
        queryCheckForDuplicates.bindDateTime("date", register.getMeterConfiguration().getEffectiveDateTime());
                
        SQLResultRow sqlResultRow = queryCheckForDuplicates.firstRow();
        queryCheckForDuplicates.close();
        
        return (isNull(sqlResultRow)) ? BigInteger.ZERO : sqlResultRow.getInteger("COUNT");
    }

    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        
        // Minimum Days Between Reads must be between 0 and 999.
        minimumDaysBetweenReads = getMinimumDaysBetweenReads();
        if (minimumDaysBetweenReads.compareTo(BigInteger.ZERO) < 0
                || minimumDaysBetweenReads.compareTo(BigInteger.valueOf(999)) > 0) {
            addError(CustomMessageRepositorySpireOne.B15575_1_MinimumIntervalInvalid(minimumDaysBetweenReads));
        }

        // Days Sufficient For Estimation must be between 0 and 999.
        daysSufficientforEstimation = getDaysSufficientforEstimation();
        if (daysSufficientforEstimation.compareTo(BigInteger.ZERO) < 0
                || daysSufficientforEstimation.compareTo(BigInteger.valueOf(999)) > 0) {
            addError(CustomMessageRepositorySpireOne.B15575_1_DaysSufficientInvalid(daysSufficientforEstimation));
        }        
        
        numberOfMonthsToLookBack = getNumberOfMonthsToLookBack();
        if (numberOfMonthsToLookBack.compareTo(BigInteger.ZERO) <= 0) {
            addError(CustomMessageRepositorySpireOne.B15575_1_NumberOfMonthsForPreviousBillsInvalid(numberOfMonthsToLookBack));
        }
        
        degreeDayLowRangeMultiplier = getDegreeDayLowRangeMultiplier();
        if (degreeDayLowRangeMultiplier.compareTo(BigDecimal.ZERO) < 0) {
            addError(CustomMessageRepositorySpireOne.B15575_1_LowPercentageFactorInvalid(degreeDayLowRangeMultiplier));
        }        

        degreeDayHighRangeMultiplier = getDegreeDayHighRangeMultiplier();
        if (degreeDayHighRangeMultiplier.compareTo(BigDecimal.ZERO) < 0) {
            addError(CustomMessageRepositorySpireOne.B15575_1_HighPercentageFactorInvalid(degreeDayHighRangeMultiplier));
        }
        
        lowDegreeDayCeiling = getLowDegreeDayCeiling();
        if (lowDegreeDayCeiling.compareTo(BigInteger.ZERO) < 0) {
            addError(CustomMessageRepositorySpireOne.B15575_1_LowDegreeDayCeilingInvalid(lowDegreeDayCeiling));
        }  
        
        performTrendEstimationSw = getPerformTrendEstimation();
        if (!getPerformTrendEstimation().isTrue() && !getPerformTrendEstimation().isFalse()) {
            addError(CustomMessageRepositorySpireOne.B15575_1_PerformTrendEstimation(performTrendEstimation));
        }        
        
        storeEstimationDetailsSw = getStoreEstimationDetails();
        if (!storeEstimationDetailsSw.isTrue()) {
            storeEstimationDetailsSw = Bool.FALSE;
        }
        
        billPeriodDaysCeiling = getBillPeriodDaysCeiling();
        if (billPeriodDaysCeiling.compareTo(BigInteger.ZERO) < 0) {
            addError(CustomMessageRepositorySpireOne.B15575_1_BillPeriodDaysCeilingInvalid(billPeriodDaysCeiling));
        } 
        
        super.extraSoftParameterValidations(forAlgorithmValidation);
        
    }
    
    /**
     * GA000-PERFORM-PROC
     * Perform Process.
     */
    private void performProc() {
        
        FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
        session.getRequestContext().traceAll();    
        
        // Estimation not allowed for Negative Consumption Metering
        if (checkForNegativeConsumptionOption().isTrue()) {
            isEstimateImpossible = Bool.TRUE;
            // Error msg only if estimate requested (not just hi-lo)
            // 2021-09-06 - Start Change
            // 2021-06-10 - Defect # 4557018 - Start Change
            //if (EST_TYPE_EST_AND_HI_LOW.equals(estimateType)) {
            //if (estimateType.equalsIgnoreCase(EstimateTypeLookup.constants.ESTIMATE_AND_HIGH_LOW.toString())) {               
            if (estimateType.equalsIgnoreCase(EstimateTypeLookup.constants.ESTIMATE_AND_HIGH_LOW.toString())
                    || estimateType.equalsIgnoreCase(EST_TYPE_EST_AND_HI_LOW)) {
            // 2021-06-10 - Defect # 4557018 - End Change
            // 2021-09-06 - End Change
                addError(CustomMessageRepositorySpireOne.B15575_1_NegativeConsumption());
            }
            return;
        }
        
        /*
         * Prepare Common Data:
         * - Get Account ID using SA or SP;
         * - Get Mid Period Date of Billing Period; and
         * - Get Billing Start Date.
         */        
        prepareCommonData();
        
        determineEligibility();
        
        estimateRegister();
        
        finalProcessing();
        
        logDebug(logger, "*** FINAL ESTIMATION RESULTS ***");
        logDebug(logger, "Latest Register Reading  : " + getLatestRegisterReading());
        logDebug(logger, "Latest Read Date Time    : " + getLatestReadDateTime());
        logDebug(logger, "Estimate Impossible      : " + getIsEstimateImpossible());
        logDebug(logger, "Estimated Raw Usage      : " + getEstimatedRawUsage());
        logDebug(logger, "Estimated Register Read  : " + getEstimatedRegisterReading());
        
    }
    
    /**
     * MA010-CHECK-FOR-NEG-CONS-OPTN
     * Check for Meter Management Options, and Meter Type and SP characteristics that indicate that
     * Negative Consumption metering is allowed for this meter/sp. If allowed, estimation is not 
     * allowed.
     * @return Bool.TRUE if Negative Consumption is allowed on Meter/SP
     */
    private Bool checkForNegativeConsumptionOption() {
        
        NegativeConsumptionCheckData negativeConsumptionCheckData = NegativeConsumptionCheckData.Factory.newInstance();
        negativeConsumptionCheckData.setServicePoint(servicePoint);
        negativeConsumptionCheckData.setRegister(register);
        negativeConsumptionCheckData.setReadDateTime(readDateTime);
        
        return NegativeConsumptionOptionRetriever.Factory.newInstance().checkNegativeConsumptionAllowed(register, negativeConsumptionCheckData).getIsNegativeConsumptionAllowed();
        
    }

    /**
     * MA030-PREPARE-COMMON-DATA
     * XC010-GET-COMMON-DATA
     * Prepare Common Data for Processing
     */
    private void prepareCommonData() {
        EstimationCommonData estimationCommonData = EstimationCommonData.Factory.newInstance();
        estimationCommonData.setServicePoint(servicePoint);
        estimationCommonData.setRegister(register);
        estimationCommonData.setReadDateTime(readDateTime);
        estimationCommonData.setServiceAgreement(serviceAgreement);
        estimationCommonData.setUnitOfMeasure(unitOfMeasure);
        estimationCommonData.setTimeOfUse(timeOfUse);
        
        estimationCommonData = EstimationCommonDataRetriever.Factory.newInstance().retrieveEstimationCommonData(estimationCommonData);
        
        accountId = estimationCommonData.getAcctId();
        startDate = estimationCommonData.getStartDate();
        endDate = estimationCommonData.getEndDate();
        midPeriodDateLastYear = estimationCommonData.getMidPeriodDateLastYear();
        latestRegisterReading = estimationCommonData.getLatestRegisterReading();
        latestReadDateTime = estimationCommonData.getLatestReadDateTime();
        
        // B-15575.1 - 2020-08-10 - Start Add
        // If the returned estimation period exceeds the usual number of days for a bill, check if there is a new SA on the SP.
        // If so, use the SA's start date as the start date of the estimation period instead of the end date of the last frozen 
        // bill segment. 
        // B-15575.1 - 2020-10-14 - Start Change
        //if(new BigDecimal(endDate.difference(startDate).getDays()).compareTo(new BigDecimal(billPeriodDaysCeiling)) > 0){
        // D-02179 - 2020-11-26 - Start Change
        //if(!isNull(endDate) && !isNull(startDate) && new BigDecimal(endDate.difference(startDate).getDays()).compareTo(new BigDecimal(billPeriodDaysCeiling)) > 0){
        if(!isNull(endDate) && !isNull(startDate) && new BigDecimal(endDate.difference(startDate).getTotalDays()).compareTo(new BigDecimal(billPeriodDaysCeiling)) > 0){            
        // D-02179 - 2020-11-26 - End Change            
        // B-15575.1 - 2020-10-14 - End Change          
            ServiceAgreement sa = getSA();
            
            // B-15575.1 - 2020-08-19 - Start Change
            // Retrieve the start date only if an SA was found
            // startDate = sa.getStartDate();           
            if(!isNull(sa)){
                startDate = sa.getStartDate(); 
                // 2021-11-19 - D-4622696 - Start Add
                isNewSa = Bool.TRUE;
                latestReadDateTime = sa.getStartDate().startOfDay();
                // 2021-11-19 - D-4622696 - End Add
            }           
            // B-15575.1 - 2020-08-19 - End Change
        }
        // B-15575.1 - 2020-08-10 - End Add         
        
        logDebug(logger, "* * * * * Estimation Algo - Prepare Common Data * * * * *");
        // B-15575.1 - 2020-10-14 - Start Change
        //logDebug(logger, "Account Id: " + accountId.toString());
        //logDebug(logger, "Start Date: " + startDate.toString());
        //logDebug(logger, "End Date: " + endDate.toString());        
        logDebug(logger, "Account Id: " + (!isNull(accountId) ? accountId.toString() : ""));
        logDebug(logger, "Start Date: " + (!isNull(startDate) ? startDate.toString() : ""));
        logDebug(logger, "End Date: " + (!isNull(endDate) ? endDate.toString() : ""));
        // B-15575.1 - 2020-10-14 - End Change
        logDebug(logger, "Mid Period Date Last Year: " + (!isNull(midPeriodDateLastYear) ? midPeriodDateLastYear.toString() : ""));
        // B-15575.1 - 2020-10-14 - Start Change
        //logDebug(logger, "Latest Reg Reading: " + latestRegisterReading.toString());
        logDebug(logger, "Latest Reg Reading: " + (!isNull(latestRegisterReading) ? latestRegisterReading.toString() : ""));
        // B-15575.1 - 2020-10-14 - End Change
        logDebug(logger, "Latest Read Date/Time: " + (!isNull(latestReadDateTime) ? latestReadDateTime.toString() : ""));
    }

    /**
     * MA040-DETER-ELIG
     * Determine Eligibility
     */
    private void determineEligibility() {

        if (isNull(accountId)) {
            isEstimateImpossible = Bool.TRUE;
            return;
        }

    }
  
    /**
     * MA000-EST-REG
     * Perform Estimation
     */
    private void estimateRegister() {
        /*
         * Call relevant estimate method Regular or TOU.
         */
        if (isEstimateImpossible.isTrue()) {
            
            return;
         
        // B-15575.1 - 2020-10-23 - Start Change            
        //} else if (notNull(unitOfMeasure) && notNull(trendArea)) {
        } else if (notNull(unitOfMeasure) && notNull(trendArea) && notNull(startDate) && notNull(endDate)) {
        // B-15575.1 - 2020-10-23 - End Change              
            Bool isEstimateDerived = Bool.FALSE;
            
            // Retrieve information on the previous bill to be used as reference for computing the estimated register reading
            SQLResultRow endReadDetails = retrievePreviousBillSegment();

            // 2021-11-19 - D-4622696 - Start Change
            // Overwrite the latest read date/time and reading when this is not the first bill for a new SA
            //if (!isNull(endReadDetails)) {
            if (!isNull(endReadDetails) && isNewSa.isFalse()) {
            // 2021-11-19 - D-4622696 - End Change            
                latestReadDateTime = endReadDetails.getDateTime("END_READ_DTTM");
                latestRegisterReading = endReadDetails.getBigDecimal("END_REG_READING");
            }
            
            // 2021-10-05 - D-4604068 - Start Delete
            //2021-08-25 - Start Change
            //2021-08-13 - Start Add
            //checkForOffCycleReads();
            //2021-08-13 - End Add
            //if (register.getConsumptionType().isSubtractive()) {
            //  logDebug(logger, "*** Latest Register Reading: " + latestRegisterReading);
            //  checkForOffCycleReads();
            //}
            //2021-08-25 - End Change
            // 2021-10-05 - D-4604068 - End Delete
            
            //Derive the number of days within the current bill period
            // D-02179 - 2020-11-26 - Start Change
            //currBillPeriodDays = new BigDecimal(endDate.difference(startDate).getDays());            
            currBillPeriodDays = new BigDecimal(endDate.difference(startDate).getTotalDays());
            // D-02179 - 2020-11-26 - End Change
            logDebug(logger, "Period days for current billing period: " + currBillPeriodDays.toString());
            
            // Derive the total degree days for the current bill period
            currBillPeriodDegreeDays = getDegreeDayForBillPeriod(startDate, endDate);
            logDebug(logger, "Degree days for current billing period: " + currBillPeriodDegreeDays.toString());
            
            // Compute the average degree days for the current bill period
            BigDecimal currBillAveDegreeDays = currBillPeriodDegreeDays.divide(currBillPeriodDays);

            // Derive last year's bill segment
            BillSegment prevYearBillSegment = retrieveLastYearBillSegment();
            logDebug(logger, "Last Year's Bill Segment: " + (!isNull(prevYearBillSegment) ? prevYearBillSegment.getId().toString() : ""));

            // If the current bill period's degree days is zero and a bill from the previous year is found, check if the degree days 
            // for the previous year's bill is within the acceptable range. 
            if (!isNull(prevYearBillSegment) && currBillPeriodDegreeDays.compareTo(BigDecimal.ZERO) == 0) {             
                // Derive the degree days for last year's bill
                prevBillPeriodDegreeDays = getDegreeDayForBillPeriod(prevYearBillSegment.getStartDate(), prevYearBillSegment.getEndDate());
                
                // Derive the number of days within last year's bill period
                // D-02179 - 2020-11-26 - Start Change
                //prevBillPeriodDays = new BigDecimal(prevYearBillSegment.getEndDate().difference(prevYearBillSegment.getStartDate()).getDays());
                prevBillPeriodDays = new BigDecimal(prevYearBillSegment.getEndDate().difference(prevYearBillSegment.getStartDate()).getTotalDays());
                // D-02179 - 2020-11-26 - End Change
                            
                // If last year's bill's degree days is between zero and the ceiling for low degree days, use the previous bill's usage as reference   
                // for computing the estimate. Compute the estimate by dividing the reference bill's usage by the number of days within that bill period,  
                // then multiply the dividend by the number of days in the current period.
                if (prevBillPeriodDegreeDays.compareTo(BigDecimal.ZERO) >= 0
                        && prevBillPeriodDegreeDays.compareTo(new BigDecimal(lowDegreeDayCeiling)) <= 0) {
                    // 2020-07-23 - Start Change                    
                    //estimatedRawUsage = retrieveBillSegmentUsage(prevYearBillSegment).divide(prevBillPeriodDays).multiply(currBillPeriodDays);                    
                    SQLResultRow previousBsegUsageDetails = retrieveBillSegmentUsage(prevYearBillSegment);
                    BigDecimal prevUsage = BigDecimal.ZERO;
                    if (notNull(previousBsegUsageDetails)) {
                        prevUsage = (BigDecimal)previousBsegUsageDetails.getBigDecimal("MSR_QTY"); 
                    }
                    
                    // 2021-10-05 - D-4604068 - Start Delete
                    //2021-08-13 - Start Change
                    //estimatedRawUsage = prevUsage.divide(prevBillPeriodDays).multiply(currBillPeriodDays);
                    // 2020-07-23 - End Change
                    //estimatedRegisterReading = computeRegisterReading(latestRegisterReading, estimatedRawUsage);
                    //if (isOffCycleReadFound.isTrue()) {
                    //  estimatedRawUsage = prevUsage.divide(prevBillPeriodDays).multiply(currBillPeriodDaysAfterOffCycleReading);
                    //    estimatedRegisterReading = computeRegisterReading(offCycleRegReading.getRegisterReading(), estimatedRawUsage);                        
                    //} else {
                    // 2021-10-05 - D-4604068 - End Delete                      
                    estimatedRawUsage = prevUsage.divide(prevBillPeriodDays).multiply(currBillPeriodDays);
                    estimatedRegisterReading = computeRegisterReading(latestRegisterReading, estimatedRawUsage);
                    // 2021-10-05 - D-4604068 - End Delete
                    //}
                    // 2021-10-05 - D-4604068 - End Delete
                    //2021-08-13 - End Change
                    isEstimateImpossible = Bool.FALSE;
                    isEstimateDerived = Bool.TRUE;
                    logDebug(logger, "* * * * * Estimation Algo - Degree days for current billing period is zero, Last year's bill found * * * * *");
                    logDebug(logger, "Previous Year's Bill's Usage: " + estimatedRawUsage.toString());
                    
                    referenceBill = prevYearBillSegment;
                    // 2021-08-21 - Start Change
                    //readType = (ReadTypeLookup)previousBsegUsageDetails.getLookup("READ_TYPE_FLG", ReadTypeLookup.class);
                    readType = ReadTypeLookup.constants.REGULAR;
                    if (notNull(previousBsegUsageDetails)) {
                        readType = (ReadTypeLookup)previousBsegUsageDetails.getLookup("READ_TYPE_FLG", ReadTypeLookup.class);
                    }
                    // 2021-08-21 - End Change
                    if (storeEstimationDetailsSw.isTrue()){
                        // Store estimated usage into the CM_ESTIMATED_RD table if switch is set to true
                        storeEstimatedUsage();
                    }

                    return;
                }
            }            
                
            if (isEstimateDerived.isFalse()) {
                // Look for a bill within the last 12 months where the degree days match the total degree days for the current bill
                List<SQLResultRow> prevBsegOnPremList = retrievePreviousBillsOnPrem(Bool.TRUE);                
                
                for(SQLResultRow row : prevBsegOnPremList){
                    prevBillPeriodDegreeDays = BigDecimal.ZERO;

                    BillSegment_Id bsegId = (BillSegment_Id) row.getId("BSEG_ID", BillSegment.class);
                    BillSegment bseg = bsegId.getEntity();
                    // D-02179 - 2020-11-26 - Start Change
                    //prevBillPeriodDays = new BigDecimal(bseg.getEndDate().difference(bseg.getStartDate()).getDays());
                    prevBillPeriodDays = new BigDecimal(bseg.getEndDate().difference(bseg.getStartDate()).getTotalDays());
                    // D-02179 - 2020-11-26 - End Change

                    // If the retrieved bill has enough days to be used for estimation,
                    if (prevBillPeriodDays.compareTo(new BigDecimal(daysSufficientforEstimation)) >= 0) {
                        // 2020-07-23 - Start Add
                        SQLResultRow previousBsegUsageDetails;
                        // 2020-07-23 - End Add
                        
                        // Derive the average degree days for the bill period 
                        prevBillPeriodDegreeDays = getDegreeDayForBillPeriod(bseg.getStartDate(), bseg.getEndDate());
                        BigDecimal prevBillAveDegreeDays = prevBillPeriodDegreeDays.divide(prevBillPeriodDays).setScale(0, BigDecimal.ROUND_HALF_UP);
                    
                        // If the current period's degree days is NOT zero and the total degree days for the previous bill is within the acceptable range  
                        // of degree days, use that previous bill's usage as the reference for the current period's estimate. Compute the estimate 
                        // by dividing the previous bill's usage by the number of degree days within that period and multiplying the result by the number 
                        // of degree days in the current period.  
                        if (currBillPeriodDegreeDays.compareTo(new BigDecimal(lowDegreeDayCeiling)) > 0                             
                                && prevBillAveDegreeDays.compareTo(currBillAveDegreeDays.multiply(degreeDayLowRangeMultiplier).setScale(0, BigDecimal.ROUND_HALF_UP)) >= 0
                                && prevBillAveDegreeDays.compareTo(currBillAveDegreeDays.multiply(degreeDayHighRangeMultiplier).setScale(0, BigDecimal.ROUND_HALF_UP)) <= 0) {
                            
                            // 2020-07-23 - Start Change
                            //estimatedRawUsage = retrieveBillSegmentUsage(bseg).divide(prevBillPeriodDegreeDays).multiply(currBillPeriodDegreeDays);
                            previousBsegUsageDetails = retrieveBillSegmentUsage(bseg);
                            BigDecimal prevUsage = BigDecimal.ZERO;
                            if (notNull(previousBsegUsageDetails)) {
                                prevUsage = (BigDecimal)previousBsegUsageDetails.getBigDecimal("MSR_QTY"); 
                            }
                            // 2020-08-08 - Start Change
                            //estimatedRawUsage = prevUsage.divide(prevBillPeriodDegreeDays).multiply(currBillPeriodDegreeDays);
                            // To avoid not getting an estimate if the previous bill period's degree days is zero, use the CCF/day computation
                            // to derive an estimate
                            if (prevBillPeriodDegreeDays.compareTo(BigDecimal.ZERO) > 0) {
                                // 2021-10-05 - D-4604068 - Start Delete
                                // 2021-08-13 - Start Change
                                //estimatedRawUsage = prevUsage.divide(prevBillPeriodDegreeDays).multiply(currBillPeriodDegreeDays);
                                //if (isOffCycleReadFound.isTrue()) {
                                //  estimatedRawUsage = prevUsage.divide(prevBillPeriodDegreeDays).multiply(currBillPeriodDegreeDaysAfterOffCycleReading);
                                //} else {
                                // 2021-10-05 - D-4604068 - End Delete  
                                    estimatedRawUsage = prevUsage.divide(prevBillPeriodDegreeDays).multiply(currBillPeriodDegreeDays);
                                // 2021-10-05 - D-4604068 - Start Delete
                                //}
                                // 2021-10-05 - D-4604068 - End Delete
                                //2021-08-13 - End Change
                            } else {
                                // 2021-10-05 - D-4604068 - Start Delete
                                // 2021-08-13 - Start Change
                                //estimatedRawUsage = prevUsage.divide(prevBillPeriodDays).multiply(currBillPeriodDays);
                                //if (isOffCycleReadFound.isTrue()) {
                                //  estimatedRawUsage = prevUsage.divide(prevBillPeriodDays).multiply(currBillPeriodDaysAfterOffCycleReading);
                                //} else {
                                // 2021-10-05 - D-4604068 - End Delete
                                    estimatedRawUsage = prevUsage.divide(prevBillPeriodDays).multiply(currBillPeriodDays);
                                // 2021-10-05 - D-4604068 - Start Delete                                    
                                //}
                                // 2021-10-05 - D-4604068 - End Delete
                                //2021-08-13 - End Change
                            }
                            // 2020-08-08 - End Change
                            // 2020-07-23 - End Change
                            // 2021-08-13 - Start Change
                            //estimatedRegisterReading = computeRegisterReading(latestRegisterReading, estimatedRawUsage);
                            // 2021-10-05 - D-4604068 - Start Delete
                            //if (isOffCycleReadFound.isTrue()) {
                            //    estimatedRegisterReading = computeRegisterReading(offCycleRegReading.getRegisterReading(), estimatedRawUsage);                        
                            //} else {
                            // 2021-10-05 - D-4604068 - End Delete
                                estimatedRegisterReading = computeRegisterReading(latestRegisterReading, estimatedRawUsage);
                            // 2021-10-05 - D-4604068 - Start Delete
                            //}
                            // 2021-10-05 - D-4604068 - End Delete
                            // 2021-08-13 - End Change
                            isEstimateImpossible = Bool.FALSE;
                            isEstimateDerived = Bool.TRUE;
                            referenceBill = bseg;
                            // 2021-08-21 - Start Change
                            //readType = (ReadTypeLookup)previousBsegUsageDetails.getLookup("READ_TYPE_FLG", ReadTypeLookup.class);
                            readType = ReadTypeLookup.constants.REGULAR;
                            if (notNull(previousBsegUsageDetails)) {
                                readType = (ReadTypeLookup)previousBsegUsageDetails.getLookup("READ_TYPE_FLG", ReadTypeLookup.class);
                            }
                            // 2021-08-21 - End Change                            
                            if (storeEstimationDetailsSw.isTrue()){
                                // Store estimated usage into the CM_ESTIMATED_RD table if switch is set to true
                                storeEstimatedUsage();
                            }

                            logDebug(logger, "Matching Bill Segment found - Degree Day within acceptable range !!");
                            logDebug(logger, "Computed Estimated Usage: " + estimatedRawUsage.toString());
                            
                            return;                                 
                        }

                        // If both the current period's degree days and the total degree days of the previous bill are less than or equal to the low 
                        // degree day ceiling, use that previous bill's usage as the reference for the current period's estimate. Compute the estimate 
                        // by dividing the previous bill's usage by the number of days within that period and multiplying the result by the number 
                        // of days in the current period.  
                        if (currBillPeriodDegreeDays.compareTo(new BigDecimal(lowDegreeDayCeiling)) <= 0
                                && prevBillPeriodDegreeDays.compareTo(new BigDecimal(lowDegreeDayCeiling)) <= 0
                                && ((currBillPeriodDegreeDays.compareTo(BigDecimal.ZERO) > 0
                                && prevBillPeriodDegreeDays.compareTo(BigDecimal.ZERO) > 0)
                                || (currBillPeriodDegreeDays.compareTo(BigDecimal.ZERO) == 0
                                && prevBillPeriodDegreeDays.compareTo(BigDecimal.ZERO) >= 0))) {                                                    
                            // 2020-07-23 - Start Add
                            previousBsegUsageDetails = retrieveBillSegmentUsage(bseg);
                            BigDecimal prevUsage = BigDecimal.ZERO;
                            if (notNull(previousBsegUsageDetails)) {
                                prevUsage = (BigDecimal)previousBsegUsageDetails.getBigDecimal("MSR_QTY"); 
                            }
                            // 2020-07-23 - End Add 

                            if (prevBillPeriodDays.compareTo(BigDecimal.ZERO) == 0
                                    || currBillPeriodDays.compareTo(BigDecimal.ZERO) == 0) {                                
                                estimatedRawUsage = BigDecimal.ZERO;
                                logDebug(logger, "Estimated Usage" + estimatedRawUsage.toString());
                            } else {
                                // 2021-08-13 - Start Change
                                // 2020-07-23 - Start Change
                                //estimatedRawUsage = retrieveBillSegmentUsage(bseg).divide(prevBillPeriodDays).multiply(currBillPeriodDays);                               
                                //estimatedRawUsage = prevUsage.divide(prevBillPeriodDays).multiply(currBillPeriodDays);
                                // 2020-07-23 - End Change
                                // 2021-10-05 - D-4604068 - Start Delete
                                //if (isOffCycleReadFound.isTrue()) {
                                //  estimatedRawUsage = prevUsage.divide(prevBillPeriodDays).multiply(currBillPeriodDaysAfterOffCycleReading);
                                //} else {
                                // 2021-10-05 - D-4604068 - End Delete  
                                    estimatedRawUsage = prevUsage.divide(prevBillPeriodDays).multiply(currBillPeriodDays);
                                // 2021-10-05 - D-4604068 - Start Delete    
                                //}
                                // 2021-10-05 - D-4604068 - End Delete
                                //2021-08-13 - End Change
                                logDebug(logger, "Computed Estimated Usage" + estimatedRawUsage.toString());
                            }
                            // 2021-08-13 - Start Change
                            //estimatedRegisterReading = computeRegisterReading(latestRegisterReading, estimatedRawUsage);
                            // 2021-10-05 - D-4604068 - Start Delete
                            //if (isOffCycleReadFound.isTrue()) {
                            //    estimatedRegisterReading = computeRegisterReading(offCycleRegReading.getRegisterReading(), estimatedRawUsage);                        
                            //} else {
                            // 2021-10-05 - D-4604068 - End Delete  
                                estimatedRegisterReading = computeRegisterReading(latestRegisterReading, estimatedRawUsage);
                            // 2021-10-05 - D-4604068 - Start Delete
                            //}                            
                            // 2021-10-05 - D-4604068 - End Delete
                            // 2021-08-13 - End Change                            
                            isEstimateImpossible = Bool.FALSE;
                            isEstimateDerived = Bool.TRUE;
                            referenceBill = bseg;
                            // 2021-08-21 - Start Change
                            //readType = (ReadTypeLookup)previousBsegUsageDetails.getLookup("READ_TYPE_FLG", ReadTypeLookup.class);
                            readType = ReadTypeLookup.constants.REGULAR;
                            if (notNull(previousBsegUsageDetails)) {
                                readType = (ReadTypeLookup)previousBsegUsageDetails.getLookup("READ_TYPE_FLG", ReadTypeLookup.class);
                            }
                            // 2021-08-21 - End Change                            
                            if (storeEstimationDetailsSw.isTrue()){
                                // Store estimated usage into the CM_ESTIMATED_RD table if switch is set to true
                                storeEstimatedUsage();
                            }

                            return;                                 
                        }                   
                    }
                }
                
                // If a matching degree days is not found after looping through all the bill segments from the past N months,
                // set the estimate impossible switch to true
                if (isNull(estimatedRawUsage) && isEstimateDerived.isFalse()) {                 
                    isEstimateImpossible = Bool.TRUE;           
                }
            }            
        } else {
            isEstimateImpossible = Bool.TRUE;
        }
        
        if (isEstimateImpossible.isTrue()){ 
            // Perform base estimation using the trend
            if (performTrendEstimationSw.isTrue()) {
                baseEstimation();
            } 

            // Raise an error to prevent the creation of a meter read with incorrect usage when an estimate still cannot be derived
            if (isEstimateImpossible.isTrue()) {
                logDebug(logger, "* * * * * Unable to estimate - Raise an error so that a meter read is not created * * * * *");

                // Raise an error when estimation is triggered online from the bill segment generation
                // 2021-09-06 - Start Change
                // 2021-07-28 - Start Change
                // Allow error to be raised when the algorithm is called from a batch
                // 2021-06-10 - Defect # 4557018 - Start Change
                //if (isOnlineConnection() && EST_TYPE_EST_AND_HI_LOW.equals(estimateType)) {
                //if (isOnlineConnection() && estimateType.equalsIgnoreCase(EstimateTypeLookup.constants.ESTIMATE_AND_HIGH_LOW.toString())) {
                //if (estimateType.equalsIgnoreCase(EstimateTypeLookup.constants.ESTIMATE_AND_HIGH_LOW.toString())) {
                if (estimateType.equalsIgnoreCase(EstimateTypeLookup.constants.ESTIMATE_AND_HIGH_LOW.toString())
                        || estimateType.equalsIgnoreCase(EST_TYPE_EST_AND_HI_LOW)) {
                // 2021-06-10 - Defect # 4557018 - End Change
                // 2021-07-28 - End Change
                // 2021-09-06 - End Change
                    addError(CustomMessageRepositorySpireOne.B15575_1_UnableToEstimate());
                }               
            }           
        } 
        
    }
    
    private BillSegment retrieveLastYearBillSegment() {
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT BS.BSEG_ID ");
        stringBuilder.append("FROM CI_BSEG_READ BSR, CI_BSEG BS ");
        stringBuilder.append("WHERE BSR.SP_ID = :servicePoint ");
        stringBuilder.append("AND BS.BSEG_ID = BSR.BSEG_ID ");
        stringBuilder.append("AND BS.START_DT <= :midPeriodDateLastYear ");
        stringBuilder.append("AND BS.END_DT >= :midPeriodDateLastYear ");
        stringBuilder.append("AND BS.BSEG_STAT_FLG = '50' ");
        stringBuilder.append("AND BS.MASTER_BSEG_ID = ' ' ");
        stringBuilder.append("AND BS.EST_SW = 'N' ");
        stringBuilder.append("AND BSR.UOM_CD = :unitOfMeasure ");
        stringBuilder.append("AND BSR.TOU_CD = " + ((notNull(timeOfUse)) ? ":timeOfUse " : "' ' "));
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindDate("midPeriodDateLastYear", midPeriodDateLastYear);
        preparedStatement.bindId("unitOfMeasure", unitOfMeasure.getId());
        if (notNull(timeOfUse)) {
            preparedStatement.bindId("timeOfUse", timeOfUse.getId());
        }
        
        preparedStatement.execute();
        SQLResultRow sqlResultRow = preparedStatement.firstRow();

        preparedStatement.close();
        
        if (isNull(sqlResultRow)) {
            return null;
        }
        
        return sqlResultRow.getEntity("BSEG_ID", BillSegment.class);
        
    }    
    
    private SQLResultRow retrievePreviousBillSegment() {
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT BSR.END_READ_DTTM, BSR.END_REG_READING ");
        stringBuilder.append("FROM CI_BSEG_READ BSR, CI_BSEG BS ");
        stringBuilder.append("WHERE BSR.SP_ID = :servicePoint ");
        stringBuilder.append("AND BS.BSEG_ID = BSR.BSEG_ID ");        
        stringBuilder.append("AND BS.END_DT < :readDateTime ");
        stringBuilder.append("AND BS.BSEG_STAT_FLG = '50' ");
        stringBuilder.append("AND BS.MASTER_BSEG_ID = ' ' ");
        stringBuilder.append("AND BSR.UOM_CD = :unitOfMeasure ");
        stringBuilder.append("AND BSR.TOU_CD = " + ((notNull(timeOfUse)) ? ":timeOfUse " : "' ' "));
        // B-15575.1 - 2020-11-10 - Start Change
        //stringBuilder.append("ORDER BY BS.END_DT DESC");
        stringBuilder.append("ORDER BY BS.END_DT DESC, BSR.END_READ_DTTM DESC");
        // B-15575.1 - 2020-11-10 - End Change
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindDate("readDateTime", readDateTime.getDate());
        preparedStatement.bindId("unitOfMeasure", unitOfMeasure.getId());
        if (notNull(timeOfUse)) {
            preparedStatement.bindId("timeOfUse", timeOfUse.getId());
        }
        
        preparedStatement.execute();
        SQLResultRow sqlResultRow = preparedStatement.firstRow();

        preparedStatement.close();
        
        if (isNull(sqlResultRow)) {
            return null;
        }
        
        return sqlResultRow;
        
    }    
    
    // 2020-07-23 - Start Change
    //private BigDecimal retrieveBillSegmentUsage(BillSegment bseg) {
    private SQLResultRow retrieveBillSegmentUsage(BillSegment bseg) {
    // 2020-07-23 - End Change  
        StringBuilder stringBuilder = new StringBuilder();
        //2020-07-23 - Start Change
        //stringBuilder.append("SELECT BSR.MSR_QTY ");
        //stringBuilder.append("FROM CI_BSEG_READ BSR, CI_BSEG BS ");            
        stringBuilder.append("SELECT BSR.MSR_QTY, RR.READ_TYPE_FLG ");
        stringBuilder.append("FROM CI_BSEG_READ BSR, CI_BSEG BS, CI_REG_READ RR ");            
        //2020-07-23 - End Change
        stringBuilder.append("WHERE BS.BSEG_ID = :billSegment ");
        stringBuilder.append("AND BS.BSEG_ID = BSR.BSEG_ID ");
        stringBuilder.append("AND BSR.UOM_CD = :unitOfMeasure ");
        stringBuilder.append("AND BSR.TOU_CD = " + ((notNull(timeOfUse)) ? ":timeOfUse " : "' ' "));
        //2020-07-23 - Start Add
        stringBuilder.append("AND BSR.END_REG_READ_ID = RR.REG_READ_ID ");
        //2020-07-23 - End Add
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());

        preparedStatement.bindId("billSegment", bseg.getId());
        preparedStatement.bindId("unitOfMeasure", unitOfMeasure.getId());
        if (notNull(timeOfUse)) {
            preparedStatement.bindId("timeOfUse", timeOfUse.getId());
        }        
        
        SQLResultRow sqlResultRow = preparedStatement.firstRow();

        preparedStatement.close();
        
        // 2020-07-23 - Start Change
        //if (isNull(sqlResultRow)) {
        //    return BigDecimal.ZERO;
        //}
        
        //return sqlResultRow.getBigDecimal("MSR_QTY");
        if (isNull(sqlResultRow)) {
            return null;
        }
        
        return sqlResultRow;
        // 2020-07-23 - End Change       
        
    }    
    
    private List<SQLResultRow> retrievePreviousBillsOnPrem(Bool sortAscending) {

        List<SQLResultRow> results = new ArrayList<SQLResultRow>();
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT BS.BSEG_ID ");
        stringBuilder.append("FROM CI_BSEG_READ BSR, CI_BSEG BS ");            
        stringBuilder.append("WHERE BSR.SP_ID = :servicePoint ");
        stringBuilder.append("AND BS.BSEG_ID = BSR.BSEG_ID ");        
        stringBuilder.append("AND BS.END_DT >= :referenceDate ");
        stringBuilder.append("AND BS.END_DT < :endDate ");
        stringBuilder.append("AND BS.BSEG_STAT_FLG = '50' ");
        stringBuilder.append("AND BS.MASTER_BSEG_ID = ' ' ");
        stringBuilder.append("AND BS.EST_SW = 'N' ");
        stringBuilder.append("AND BSR.UOM_CD = :unitOfMeasure ");
        stringBuilder.append("AND BSR.TOU_CD = " + ((notNull(timeOfUse)) ? ":timeOfUse " : "' ' "));
        stringBuilder.append("ORDER BY BS.START_DT ");
        if (sortAscending.isFalse()) {
            stringBuilder.append("DESC");   
        }        
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());

        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindDate("referenceDate", readDateTime.addMonths(numberOfMonthsToLookBack.negate().intValue()).getDate());
        preparedStatement.bindDate("endDate", endDate);
        preparedStatement.bindId("unitOfMeasure", unitOfMeasure.getId());
        if (notNull(timeOfUse)) {
            preparedStatement.bindId("timeOfUse", timeOfUse.getId());
        }        
        
        results = preparedStatement.list();
        preparedStatement.close();
        
        return results;      
        
    }
    
    // B-15575.1 - 2020-08-10 - Start Add
    private ServiceAgreement getSA() {
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT SA.SA_ID ");
        stringBuilder.append("FROM CI_SA_SP SASP, CI_SA SA ");
        stringBuilder.append("WHERE SASP.SP_ID = :servicePoint ");
        // B-15575.1 - 2020-08-19 - Start Change
        // SA should have started prior to the end date of the estimation period. 
        // This is to make sure an SA is not retrieved for back-to-back stop/starts.
        // stringBuilder.append("AND SASP.START_DTTM <= :endDate ");
        stringBuilder.append("AND SASP.START_DTTM < :endDate ");
        // B-15575.1 - 2020-08-19 - End Change
        stringBuilder.append("AND (SASP.STOP_DTTM IS NULL  ");
        stringBuilder.append("OR SASP.STOP_DTTM > :endDate) ");
        stringBuilder.append("AND SASP.SA_ID = SA.SA_ID ");
        stringBuilder.append("AND SA.START_DT > :startDate ");
        stringBuilder.append("AND SA.SA_STATUS_FLG < :closed ");
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindDate("endDate", endDate);
        preparedStatement.bindDate("startDate", startDate);        
        preparedStatement.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
        
        preparedStatement.execute();
        SQLResultRow sqlResultRow = preparedStatement.firstRow();

        preparedStatement.close();
        
        if (isNull(sqlResultRow)) {
            return null;
        }
        
        return sqlResultRow.getEntity("SA_ID", ServiceAgreement.class);
        
    }    
    // B-15575.1 - 2020-08-10 - End Add
    
    /**
     * MA300-BASE-ESTIMATION
     * XC-140-BASE-ESTIMATION
     */
    private void baseEstimation() {
        
        // If there is no data last year or previous bill segment use any available trend data.
        isEstimateImpossible = Bool.FALSE;

        // B-15575.1 - 2020-10-14 - Start Change  
        // Call Java version of Trend Estimation
        //CmTrendBasedEstimation cmTrendBasedEstimation = CmTrendBasedEstimation.Factory.newInstance();
        //cmTrendBasedEstimation.setConsumptionType(consumptionType);
        //cmTrendBasedEstimation.setEstimationType(estimateType);
        //cmTrendBasedEstimation.setServicePoint(servicePoint);
        //cmTrendBasedEstimation.setRegister(register);
        //cmTrendBasedEstimation.setReadDateTime(readDateTime);
        //cmTrendBasedEstimation.setServiceAgreement(serviceAgreement);
        //cmTrendBasedEstimation.setUnitOfMeasure(unitOfMeasure);
        //cmTrendBasedEstimation.setTimeOfUse(timeOfUse);
        //cmTrendBasedEstimation.setRegisterConstant(registerConstant);
        //cmTrendBasedEstimation.setNumberOfDigitsLeft(numberOfDigitsLeft);
        //cmTrendBasedEstimation.setNumberOfDigitsRight(numberOfDigitsRight);
        //cmTrendBasedEstimation.setNumberOfReads(numberOfReads);
        //cmTrendBasedEstimation.setMeasuresPeakQuantity(measuresPeakQuantity);
        //cmTrendBasedEstimation.setMinimumDaysBetweenReads(minimumDaysBetweenReads);
        //cmTrendBasedEstimation.invoke();
        
        //estimateAlgorithm = cmTrendBasedEstimation.getEstimateAlgorithm();
        //latestRegisterReading = cmTrendBasedEstimation.getLatestRegisterReading();
        //latestReadDateTime = cmTrendBasedEstimation.getLatestReadDateTime();
        //estimatedRawUsage = cmTrendBasedEstimation.getEstimatedRawUsage();
        //estimatedRegisterReading = cmTrendBasedEstimation.getEstimatedRegisterReading();
        //isEstimateImpossible = cmTrendBasedEstimation.getIsEstimateImpossible();
        
        // Call base Java version of Trend Estimation
        StandardRecords standardRecords = new StandardRecords();
        StandardRecordsSyncer.initializeRecordsFromSession(standardRecords);
        
        RecordCICMEDRX recordCICMEDRX = RecordCICMEDRX.Factory.FACTORY.newInstance();
        recordCICMEDRX.initialize();
        recordCICMEDRX.refIoReg().refConsumSubFlg().setValue(consumptionType.trimmedValue());
        recordCICMEDRX.refInputWrk().refEstType().setValue(estimateType);
        recordCICMEDRX.refInputWrk().refSpId().setValue(servicePoint.getId().getTrimmedValue());
        recordCICMEDRX.refInputWrk().refRegId().setValue(register.getId().getTrimmedValue());
        recordCICMEDRX.refInputWrk().refReadDttm().setValue(readDateTime.toString());
        if (notNull(serviceAgreement)) {
            recordCICMEDRX.refInputWrk().refSaId().setValue(serviceAgreement.getId().getTrimmedValue());
        }
        recordCICMEDRX.refIoReg().refUomCd().setValue(unitOfMeasure.getId().getTrimmedValue());
        if (notNull(timeOfUse)) {
            recordCICMEDRX.refIoReg().refTouCd().setValue(timeOfUse.getId().getTrimmedValue());
        }
        recordCICMEDRX.refIoReg().refRegConst().setValue(BigDecimal.valueOf(registerConstant.longValue()).setScale(0).toString());
        recordCICMEDRX.refIoReg().refNbrOfDgtsLft().setValue(numberOfDigitsLeft.toString().trim());
        recordCICMEDRX.refIoReg().refNbrOfDgtsRgt().setValue(numberOfDigitsRight.toString().trim());
        recordCICMEDRX.refIoTrendAreaCl().refNbrOfReads().setValue(numberOfReads.toString());
        recordCICMEDRX.refIoReg().refMsrPeakQtySw().setValue(measuresPeakQuantity.toString().trim());
        // Start Change - EQuint - 09-26-2024 - B-33801
        // recordCICMEDRX.refIoTrendAreaCl().refRegReading().setValue(registerReading.toString());
        recordCICMEDRX.refIoTrendAreaCl().refRegReading().setValue(BigDecimal.valueOf(registerReading.longValue()).setScale(0).toString());
        // End Change - EQuint - 09-26-2024 - B-33801
        if (notNull(trendArea)) {
            recordCICMEDRX.refIoTrendAreaCl().refTrendAreaCd().setValue(trendArea.getId().getTrimmedValue());
        }
        if (notNull(trendClass)) {
            recordCICMEDRX.refIoTrendAreaCl().refTrendClCd().setValue(trendClass.getId().getTrimmedValue());
        }
        
        RecordCICZALPN recordCICZALPN = RecordCICZALPN.Factory.FACTORY.newInstance();
        ArrayField<RecordCICZALPNFragment.AlgParmArray> algParmArray = recordCICZALPN.refAlgParmArray();
        algParmArray.get(1).refAlgParmVal().setValue(minimumDaysBetweenReads.toString());
        algParmArray.get(2).refAlgParmVal().setValue(daysSufficientforEstimation.toString());
        
        ProgramCIPMETRX.invoke(standardRecords, recordCICMEDRX, recordCICZALPN);
        
        estimateAlgorithm = (recordCICMEDRX.refOutputWrk().refC1EstAlgFlg().isEstAlgBillUsage()) ? EstimateAlgorithmLookup.constants.BILLED_USAGE : EstimateAlgorithmLookup.constants.TREND;
        latestRegisterReading = BigDecimal.valueOf(recordCICMEDRX.refOutputWrk().refLatestRegReading().getValue().longValue());
        // B-15575.1 - 2020-10-23 - Start Change 
        //if (notBlank(recordCICMEDRX.refOutputWrk().refLatestReadDttm().toString())) {        
        if (!isBlankOrNull(recordCICMEDRX.refOutputWrk().refLatestReadDttm().getRightTrimmedStringValue())) {           
        // B-15575.1 - 2020-10-23 - End Change          
            latestReadDateTime = DateTime.fromIso(recordCICMEDRX.refOutputWrk().refLatestReadDttm().getRightTrimmedStringValue());
        }
        estimatedRawUsage = BigDecimal.valueOf(recordCICMEDRX.refOutputWrk().refEstRawUsage().getValue().longValue());
        estimatedRegisterReading = BigDecimal.valueOf(recordCICMEDRX.refOutputWrk().refEstRegReading().getValue().longValue());
        isEstimateImpossible = (recordCICMEDRX.refOutputWrk().refEstImpossibleSw().isSwYes()) ? Bool.TRUE : Bool.FALSE;
        // B-15575.1 - 2020-10-14 - End Change  
        
        logDebug(logger, "***Meter Read Estimation Using Trend***");
        logDebug(logger, "latestRegisterReading   : " + latestRegisterReading);
        logDebug(logger, "latestReadDateTime      : " + latestReadDateTime);
        logDebug(logger, "estimatedRawUsage       : " + estimatedRawUsage);
        logDebug(logger, "estimatedRegisterReading: " + estimatedRegisterReading);
        logDebug(logger, "isEstimateImpossible    : " + isEstimateImpossible);
        
    }

    /**
     * MA900-FINAL-PROCESSING
     */
    private void finalProcessing() {
        if (isEstimateImpossible.isTrue()) {
            estimateAlgorithm = null;
            estimatedRawUsage = null;
            estimatedRegisterReading = null;
            isEstimateImpossible = Bool.TRUE;
            latestReadDateTime = null;
            latestRegisterReading = null;
        }
    }

    /**
     * Retrieve the sum of the degree days between the start and end dates.
     * @param startDate
     * @param endDate
     * @return BigDecimal
     */
    private BigDecimal getDegreeDayForBillPeriod(Date startDate, Date endDate) {

        BigDecimal degreeDaySum = BigDecimal.ZERO;

        // Do not include the end date where the meter would have had an estimate or read
        endDate = endDate.addDays(-1);

        DegreeDay degreeDay;

        while (startDate.isSameOrBefore(endDate)) {

            degreeDay = new DegreeDay_Id(trendArea, startDate).getEntity();
            if (isNull(degreeDay)) {
                addError(CustomMessageRepositorySpireOne.B15575_1_DegreeDayMissing(trendArea, startDate));
            }

            degreeDaySum = degreeDaySum.add(degreeDay.getDegreeDay());
            startDate = startDate.addDays(1);
        }

        return (degreeDaySum.compareTo(BigDecimal.ZERO) == 0) ? BigDecimal.ZERO : degreeDaySum;

    }

    /**
     * Compute the correct estimated register reading using register and
     * installation constants, ensures correct reading if dial rolls over and truncates unneeded
     * trailing digits.
     * @return BigDecimal RegisterReading
     */
    private BigDecimal computeRegisterReading(BigDecimal startRegisterReading, BigDecimal usage) {
        
        // 2021-10-05 - D-4604068 - Start Change
        // 2021-01-29 - D-02207 - Start Add
        // If a meter exchange occurred within the estimation period, calculate the estimated reading based on the usage
        // of the old meter and the install read of the new meter
        //SQLResultRow meterExchangeRow = retrieveMeterExchangeDetails();
        //if (notNull(meterExchangeRow)) {
        //    BigDecimal removalRead = meterExchangeRow.getBigDecimal("REG_READING");
        //    Register removedRegister = meterExchangeRow.getEntity("REG_ID", Register.class);
        //    BigDecimal removeRegisterMaximumDial = BigDecimal.TEN.pow(BigDecimal.valueOf(removedRegister.getNumberOfDigitsLeft().longValue()));

            // If removal read is less than the latest billed read, consider the rollover when computing the usage
        //    BigDecimal oldMeterUsage = BigDecimal.ZERO;
        //    if (removalRead.compareTo(latestRegisterReading) < 0) {
        //        oldMeterUsage = removalRead.add(removeRegisterMaximumDial).subtract(latestRegisterReading);
        //    } else {
        //        oldMeterUsage = removalRead.subtract(latestRegisterReading);
        //    }

            // Override the estimated usage depending on the usage from the old meter
        //   if (usage.compareTo(oldMeterUsage) > 0) {
        //        usage = usage.subtract(oldMeterUsage).multiply(removedRegister.getRegisterConstant());
        //    }
        //    else {
        //        usage = BigDecimal.ZERO;
        //    }
            
        //    estimatedRawUsage = usage;

            // Retrieve the install read of the new meter and override the startRegisterReading
        //    SQLResultRow meterInstallRow = retrieveInstallRead();
        //    startRegisterReading = meterInstallRow.getBigDecimal("REG_READING");
        //    latestRegisterReading = startRegisterReading;
        //}
        // 2021-01-29 - D-02207 - End Add
        // 2021-09-08 - D-4598507 - Start Add
        // Override the latestRegisterReading if the value differs from the startRegisterReading
        //if (!isNull(startRegisterReading) && startRegisterReading.compareTo(latestRegisterReading) != 0) {
        //  latestRegisterReading = startRegisterReading;
        //}
        // 2021-09-08 - D-4598507 - End Add
        
        // Consolidate all unbilled usage from meter exchanges and off-cycle reads
        BigDecimal oldMeterUsage = consolidateUnbilledUsage();
        if (usage.compareTo(oldMeterUsage) > 0) {
            usage = usage.subtract(oldMeterUsage);
        } else {
            usage = BigDecimal.ZERO;
        }
        
        // If there were any updates to the latestRegisterReading while consolidating the unbilled usage, overwrite the startRegReading
        if (startRegisterReading.compareTo(latestRegisterReading) != 0) {
            startRegisterReading = latestRegisterReading;
        }
        estimatedRawUsage = usage;
        // 2021-10-05 - D-4604068 - End Change        

        BigDecimal maximumDial = BigDecimal.TEN.pow(BigDecimal.valueOf(register.getNumberOfDigitsLeft().longValue()));
        
        BigDecimal rawUsage = usage.divide(register.getRegisterConstant());

        BigDecimal installationConstant = getServicePointMeterHistory(servicePoint, register.getMeterConfiguration()).getInstallationConstant();

        if (BigDecimal.ZERO.longValue() < installationConstant.longValue()) {
            rawUsage = rawUsage.divide(installationConstant);
        }

        if (rawUsage.compareTo(maximumDial) >= 0) {
            addError(CustomMessageRepositorySpireOne.B15575_1_Rollover(register));
        }

        // Check the Raw Usage against Number of Digits Right and truncate the trailing digits
        usage = rawUsage.setScale(register.getNumberOfDigitsRight().intValue(), BigDecimal.ROUND_HALF_DOWN);

        // Calculate the register reading. 
        BigDecimal endReading = BigDecimal.ZERO;
        if (register.getConsumptionType().isSubtractive()) {
            endReading = startRegisterReading.add(usage);
        } else {
            endReading = usage;
        }
        
        // If greater than the capacity of the dial, then we assume that the dial has rolled over.
        // 2021-08-09 - D-4579388 - Start Change
        //if (endReading.compareTo(maximumDial) > 0) {          
        if (endReading.compareTo(maximumDial) >= 0) {
        // 2021-08-09 - D-4579388 - End Change
            endReading = endReading.subtract(maximumDial);
        }
        
        return endReading;
        
    }
    
    /**
     * Based on CIPMERCN:ZS110-SETUP-SQL-S-SPMRRG
     * @param servicePoint
     * @param meterConfiguration
     * @return ServicePointMeterHistory
     */ 
    private ServicePointMeterHistory getServicePointMeterHistory(ServicePoint servicePoint, MeterConfiguration meterConfiguration) {
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select spmr.SP_MTR_HIST_ID ");
        stringBuilder.append("from CI_CFG_SPMR_VW spmr ");
        stringBuilder.append("where spmr.SP_ID = :servicePoint ");
        stringBuilder.append("and spmr.MTR_CONFIG_ID = :meterConfiguration ");
        stringBuilder.append("order by spmr.INSTALL_DTTM desc ");
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());

        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindId("meterConfiguration", meterConfiguration.getId());
        
        preparedStatement.execute();
        ServicePointMeterHistory servicePointMeterHistory = preparedStatement.firstRow().getEntity("SP_MTR_HIST_ID", ServicePointMeterHistory.class);
        preparedStatement.close();
        
        return servicePointMeterHistory;
        
    }
    
    //2020-07-23 - Start Add
    // Store  the estimated read 
    public void storeEstimatedUsage() {
        
        // Insert estimated read into the table
        try{
            logger.debug("* * * * Store Estimated Usage * * * * ");
            
            StringBuilder insertSql = new StringBuilder();
            insertSql.append("INSERT INTO CM_ESTIMATED_RD ");
            insertSql.append("VALUES (:PROC_DT, ");
            insertSql.append(":EST_ALG_CD, ");
            insertSql.append(":VERSION, ");
            insertSql.append(":ACCT_ID, ");
            insertSql.append(":SP_ID, ");
            insertSql.append(":BADGE_NBR, ");
            insertSql.append(":SEQNO, ");
            insertSql.append(":READ_DTTM, ");
            insertSql.append(":MSR_QTY, ");
            insertSql.append(":PERCENT_DIFF, ");
            insertSql.append(":CM_BSEG_ID_REF, ");
            insertSql.append(":READ_TYPE_FLG)");

            PreparedStatement insertQry = createPreparedStatement(insertSql.toString(), getClass().getName());
            insertQry.bindDateTime("PROC_DT", getProcessDateTime());
            insertQry.bindId("EST_ALG_CD", this.getAlgorithmId());
            insertQry.bindBigInteger("VERSION", BigInteger.valueOf(this.getAlgorithm().getVersion()));
            insertQry.bindId("ACCT_ID", accountId);
            insertQry.bindId("SP_ID", servicePoint.getId());
            insertQry.bindString("BADGE_NBR", register.getMeterConfiguration().getMeter().getBadgeNumber().toString(), "BADGE_NBR");
            //2020-08-10 - Start Change
            //insertQry.bindBigInteger("SEQNO", register.getSeq());
            insertQry.bindBigInteger("SEQNO", BigInteger.ZERO);
            //2020-08-10 - End Change
            insertQry.bindDateTime("READ_DTTM", readDateTime);
            insertQry.bindBigDecimal("MSR_QTY", estimatedRawUsage);
            insertQry.bindBigDecimal("PERCENT_DIFF", BigDecimal.ZERO);
            insertQry.bindId("CM_BSEG_ID_REF", referenceBill.getId());
            insertQry.bindLookup("READ_TYPE_FLG", readType);

            insertQry.setAutoclose(false);
            insertQry.execute();
            insertQry.close();

        } catch (ApplicationError ae) {
            addError(CustomMessageRepositorySpireOne.B15575_2_unableToAddRecord(
                    accountId.getIdValue(), ae.getServerMessage().getMessageText()));
        }

    }
    // 2020-07-23 - End Add

    // 2021-01-29 - D-02207 - Start Add
    /**
     * This method will retrieve the details of the old meter if a meter exchange occurred within the billing period
     * @return
     */
    // 2021-10-05 - D-4604068 - Start Change
    //private SQLResultRow retrieveMeterExchangeDetails() {
    private List<SQLResultRow> retrieveMeterExchangeDetails() {
    // 2021-10-05 - D-4604068 - End Change
        
        StringBuilder meterRemovalDetailsPrepStmtStr =  new StringBuilder();
        meterRemovalDetailsPrepStmtStr.append(" SELECT MH.MTR_CONFIG_ID, MH.REMOVAL_DTTM, RR.REG_ID, RR.REG_READING ");
        meterRemovalDetailsPrepStmtStr.append(" FROM CI_CFG_SPMR_VW MH, CI_REG_READ RR  ");
        // 2021-08-09 - D-4579388 - Start Change
        //meterRemovalDetailsPrepStmtStr.append(" WHERE MH.MTR_CONFIG_ID <> :meterConfigurationId ");        
        //meterRemovalDetailsPrepStmtStr.append(" AND MH.REMOVAL_DTTM BETWEEN :startDate AND :endDate ");
        meterRemovalDetailsPrepStmtStr.append(" WHERE MH.REMOVAL_DTTM BETWEEN :startDate AND :endDate  ");
        // 2021-08-09 - D-4579388 - End Change
        meterRemovalDetailsPrepStmtStr.append(" AND MH.SP_ID = :servicePointId ");
        meterRemovalDetailsPrepStmtStr.append(" AND MH.REMOVAL_MR_ID = RR.MR_ID ");
        // 2021-10-05 - D-4604068 - Start Change
        //meterRemovalDetailsPrepStmtStr.append(" ORDER BY MH.REMOVAL_DTTM DESC ");
        meterRemovalDetailsPrepStmtStr.append(" ORDER BY MH.REMOVAL_DTTM ");
        // 2021-10-05 - D-4604068 - End Change
        
        PreparedStatement meterRemovalDetailsPrepStmt = createPreparedStatement(meterRemovalDetailsPrepStmtStr.toString(), getClass().getName());

        // 2021-08-09 - D-4579388 - Start Delete
        //meterRemovalDetailsPrepStmt.bindId("meterConfigurationId", register.getMeterConfiguration().getId());
        // 2021-08-09 - D-4579388 - End Delete        
        meterRemovalDetailsPrepStmt.bindId("servicePointId", servicePoint.getId());
        meterRemovalDetailsPrepStmt.bindDate("startDate", startDate);
        meterRemovalDetailsPrepStmt.bindDate("endDate", endDate);

        // 2021-10-05 - D-4604068 - Start Change
        //SQLResultRow meterRemovalRow = meterRemovalDetailsPrepStmt.firstRow();
        List<SQLResultRow> meterExchangeList = new ArrayList<SQLResultRow>();
        meterExchangeList = meterRemovalDetailsPrepStmt.list();
        // 2021-10-05 - D-4604068 - End Change
        meterRemovalDetailsPrepStmt.close();
        
        // 2021-10-05 - D-4604068 - Start Change
        //return meterRemovalRow;
        return meterExchangeList;
        // 2021-10-05 - D-4604068 - End Change

    }

    /**
     * This method will retrieve the install read of the new meter if a meter exchange occurred within the billing period
     * @return
     */
    // 2021-10-05 - D-4604068 - Start Change
    //private SQLResultRow retrieveInstallRead() {
    private SQLResultRow retrieveInstallRead(Register register, Date startDate, DateTime endDateTime) {
    // 2021-10-05 - D-4604068 - End Change

        StringBuilder meterInstallDetailsPrepStmtStr = new StringBuilder();
        // 2021-10-05 - D-4604068 - Start Change
        //meterInstallDetailsPrepStmtStr.append(" SELECT MH.MTR_CONFIG_ID, MH.REMOVAL_DTTM, RR.REG_READING ");
        meterInstallDetailsPrepStmtStr.append(" SELECT MH.MTR_CONFIG_ID, MH.REMOVAL_DTTM, RR.REG_READ_ID, RR.REG_READING ");
        // 2021-10-05 - D-4604068 - End Change
        meterInstallDetailsPrepStmtStr.append(" FROM CI_CFG_SPMR_VW MH, CI_REG_READ RR  ");
        meterInstallDetailsPrepStmtStr.append(" WHERE MH.MTR_CONFIG_ID = :meterConfigurationId ");
        meterInstallDetailsPrepStmtStr.append(" AND MH.INSTALL_DTTM BETWEEN :startDate AND :endDate ");
        meterInstallDetailsPrepStmtStr.append(" AND MH.SP_ID = :servicePointId ");
        meterInstallDetailsPrepStmtStr.append(" AND MH.INSTALL_MR_ID = RR.MR_ID ");
        meterInstallDetailsPrepStmtStr.append(" AND RR.REG_ID = :registerId ");
        meterInstallDetailsPrepStmtStr.append(" ORDER BY MH.INSTALL_DTTM DESC ");

        PreparedStatement meterInstallDetailsPrepStmt = createPreparedStatement(meterInstallDetailsPrepStmtStr.toString(), getClass().getName());

        meterInstallDetailsPrepStmt.bindId("meterConfigurationId", register.getMeterConfiguration().getId());
        meterInstallDetailsPrepStmt.bindId("servicePointId", servicePoint.getId());
        meterInstallDetailsPrepStmt.bindDate("startDate", startDate);
        // 2021-09-08 - D-4598507 - Start Change
        //meterInstallDetailsPrepStmt.bindDate("endDate", endDate);
        meterInstallDetailsPrepStmt.bindDateTime("endDate", readDateTime);
        // 2021-09-08 - D-4598507 - End Change
        meterInstallDetailsPrepStmt.bindId("registerId", register.getId());

        SQLResultRow meterInstallRow = meterInstallDetailsPrepStmt.firstRow();
        meterInstallDetailsPrepStmt.close();
        return meterInstallRow;

    }
    // 2021-01-29 - D-02207 - End Add

    // 2021-08-13 - Start Add
    /**
     * Retrieve off-cycle reads
     */ 
    private List<SQLResultRow> getOffCycleReads() {
        
        logDebug(logger, "Check for Off Cycle Reads for Register: " + register.getId().getTrimmedValue());
        
        List<SQLResultRow> results = new ArrayList<SQLResultRow>();
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT RR.REG_READ_ID, RR.REG_READING ");
        stringBuilder.append("FROM CI_MR MR, CI_REG_READ RR ");
        stringBuilder.append("WHERE MR.MR_ID = RR.MR_ID ");
        stringBuilder.append("AND RR.REG_ID = :registerId ");
        stringBuilder.append("AND TRUNC(MR.READ_DTTM) > :startDate ");
        stringBuilder.append("AND TRUNC(MR.READ_DTTM) < :endDate ");
        stringBuilder.append("AND RR.READ_TYPE_FLG >= :readTypeFlag ");
        // 2021-10-05 - D-4604068 - Start Add
        stringBuilder.append("AND MR.USE_ON_BILL_SW = 'Y' ");
        // 2021-10-05 - D-4604068 - End Add
        // 2021-09-03 - Start Change
        //stringBuilder.append("ORDER BY MR.READ_DTTM DESC ");
        stringBuilder.append("ORDER BY MR.READ_DTTM ");
        // 2021-09-03 - End Change
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());

        preparedStatement.bindEntity("registerId", register);
        preparedStatement.bindDate("startDate", startDate);
        preparedStatement.bindDate("endDate", endDate);
        preparedStatement.bindLookup("readTypeFlag", ReadTypeLookup.constants.CUSTOMER_READ);
        
        results = preparedStatement.list();
        preparedStatement.close();
        
        return results;         
    }
    
    /**
     * Process off-cycle reads. Derive usage by getting the difference between the last off-cycle read and the meter's install read.
     */ 
    // 2021-10-05 - D-4604068 - Start Change
    //private void checkForOffCycleReads() {        
    private BigDecimal checkForOffCycleReads() {
    // 2021-10-05 - D-4604068 - End Change
                
        List<SQLResultRow> offCycleReadsList = getOffCycleReads(); 
        BigDecimal prevRead = latestRegisterReading;
        
        // 2021-10-05 - D-4604068 - Start Add 
        // If the meter was installed within the estimation period, use the install read as the start read
        RegisterRead_Id installRead = null;
        SQLResultRow meterInstallRow = retrieveInstallRead(register, startDate, readDateTime); 
        if (notNull(meterInstallRow)) {
            installRead = (RegisterRead_Id) meterInstallRow.getId("REG_READ_ID", RegisterRead.class);
            prevRead = meterInstallRow.getBigDecimal("REG_READING");    
            // 2021-11-19 - D-4622696 - Start Add
            latestRegisterReading = prevRead;
            // 2021-11-19 - D-4622696 - End Add
        }
        // 2021-10-05 - D-4604068 - End Add
        RegisterRead_Id regReadId = null;   
        
        // Loop through the off-cycle readings and check if there was a rollover.
        for(SQLResultRow row : offCycleReadsList){
            regReadId = (RegisterRead_Id) row.getId("REG_READ_ID", RegisterRead.class);
            BigDecimal regRead = row.getBigDecimal("REG_READING");            

            // Raise an error if a rollover is detected
            if (prevRead.compareTo(regRead) > 0) {
                //2021-09-06 - Start Change
                //2021-09-03 - Start Change
                // To add considerations for rollover, raise the error only for billing
                //addError(CustomMessageRepositorySpireOne.B15575_1_OffCycleReadRollover());  
                //if (estimateType.equalsIgnoreCase(EstimateTypeLookup.constants.ESTIMATE_AND_HIGH_LOW.toString())) {
                if (estimateType.equalsIgnoreCase(EstimateTypeLookup.constants.ESTIMATE_AND_HIGH_LOW.toString())
                        || estimateType.equalsIgnoreCase(EST_TYPE_EST_AND_HI_LOW)) {
                //2021-09-06 - End Change
                    addError(CustomMessageRepositorySpireOne.B15575_1_OffCycleReadRollover());
                }
                //2021-09-03 - End Change
            }

            prevRead = regRead;                     
        }
    
        // If an off-cycle read is found,
        if (notNull(regReadId)) {
            // 2021-10-05 - D-4604068 - Start Change
            //isOffCycleReadFound = Bool.TRUE;          
            //offCycleRegReading = regReadId.getEntity();
            //currBillPeriodDaysAfterOffCycleReading = new BigDecimal(endDate.difference(offCycleRegReading.getMeterRead().getReadDateTime().getDate()).getTotalDays());            
            //currBillPeriodDegreeDaysAfterOffCycleReading = getDegreeDayForBillPeriod(offCycleRegReading.getMeterRead().getReadDateTime().getDate(), endDate);
            logDebug(logger, "Off Cycle Reads found for Register: " + register.getId().getTrimmedValue());
            offCycleRegReading = regReadId.getEntity();
            BigDecimal offCycleUsage = BigDecimal.ZERO;
            
            // If the meter was installed within the estimation period, compute the usage between the latest off-cycle read and the install read
            if (notNull(installRead)) {
                latestRegisterReading = offCycleRegReading.getRegisterReading();
                if (!regReadId.equals(installRead)) {
                    offCycleUsage = offCycleRegReading.getRegisterReading().subtract(installRead.getEntity().getRegisterReading()).multiply(offCycleRegReading.getRegister().getRegisterConstant());                    
                } 
            } else {
                // If the meter was installed prior to the estimation period, compute the usage between the latest off-cycle read and the last billed reading
                offCycleUsage = offCycleRegReading.getRegisterReading().subtract(latestRegisterReading).multiply(offCycleRegReading.getRegister().getRegisterConstant());
                latestRegisterReading = offCycleRegReading.getRegisterReading();
            }  
                        
            return offCycleUsage;  
            // 2021-10-05 - D-4604068 - End Change
        }
        
        // 2021-10-05 - D-4604068 - Start Add
        return BigDecimal.ZERO;
        // 2021-10-05 - D-4604068 - End Add
        
    }        
    // 2021-08-13 - End Add

    // 2021-10-05 - D-4604068 - Start Add    
    /**
     * Consolidate unbilled usages
     */ 
    private BigDecimal consolidateUnbilledUsage() {     
        
        List<SQLResultRow> meterExchangeList = retrieveMeterExchangeDetails();
        Date installDate = latestReadDateTime.getDate();
        BigDecimal oldMeterUsage = BigDecimal.ZERO;
        
        // Retrieve all meter removals within the estimation period
        for(SQLResultRow meterExchangeRow : meterExchangeList){             
            BigDecimal removalRead = meterExchangeRow.getBigDecimal("REG_READING");
            Register removedRegister = meterExchangeRow.getEntity("REG_ID", Register.class);
            BigDecimal removeRegisterMaximumDial = BigDecimal.TEN.pow(BigDecimal.valueOf(removedRegister.getNumberOfDigitsLeft().longValue()));
            DateTime removalDateTime = meterExchangeRow.getDateTime("REMOVAL_DTTM");

            // For every removal found, check if the installation was also within the estimation period
            SQLResultRow meterInstallRow = retrieveInstallRead(removedRegister, installDate, removalDateTime);
            
            // If meter was installed and removed within the period, use the install read when deriving the total usage
            if (notNull(meterInstallRow)) {
                latestRegisterReading = meterInstallRow.getBigDecimal("REG_READING");
                logDebug(logger, "Consolidate Unbilled Usage - Meter Installed Within - Latest Register Reading: " + latestRegisterReading);
            } 

            // If removal read is less than the latest billed read, consider the rollover when computing the usage.
            if (removalRead.compareTo(latestRegisterReading) < 0) {
                oldMeterUsage = oldMeterUsage.add(removalRead.add(removeRegisterMaximumDial).subtract(latestRegisterReading).multiply(removedRegister.getRegisterConstant()));
            } else {
                oldMeterUsage = oldMeterUsage.add(removalRead.subtract(latestRegisterReading).multiply(removedRegister.getRegisterConstant()));
            }                           
            
            //latestRegisterReading = removalRead;  
            //logDebug(logger, "Consolidate Unbilled Usage - Meter Removal Read - Latest Register Reading: " + latestRegisterReading);
        }
        
        // Check for off-cycle reads for the currently installed meter and consolidate the usage
        if (register.getConsumptionType().isSubtractive()) {
            oldMeterUsage = oldMeterUsage.add(checkForOffCycleReads()); 
        }   
        
        logDebug(logger, "Total Old Meter Usage: " + oldMeterUsage);
        
        return oldMeterUsage;
                
    }        
    // 2021-10-05 - D-4604068 - End Add    
    
}
