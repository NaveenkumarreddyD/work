/*
 ************************************************************************ 
 *                 Confidentiality Information: 
 * 
 ************************************************************************
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * Payment Arrangement Activation - Create Customer Contact
 * 
 * This algorithm creates a Customer Contact so a letter can be sent
 * to the customer outlining the Payment Arrangement terms.
 * 
 ************************************************************************ 
 * CHANGE HISTORY: 
 * 
 * Date:        by:         Reason: 
 * YYYY-MM-DD   FLName
 * 2014-10-28   WCARANDA    Initial Version. MGE-CCB008.
 * 2016-01-26   MPang		Updated for CCB v2.4 compilation.
 ************************************************************************
 */
package com.splwg.cm.domain.admin.serviceAgreementType;

import java.util.Iterator;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.service.ItemList;
import com.splwg.base.api.service.ListBody;
import com.splwg.base.api.service.PageBody;
import com.splwg.base.api.service.PageHeader;
import com.splwg.base.api.service.ServiceDispatcher;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.batch.batchControl.BatchControl;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.customerContactClass.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.CharacteristicTypeContactType_Id;
import com.splwg.ccb.domain.admin.customerContactType.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.letterTemplate.LetterTemplate_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.SaTypeSaActivationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristics;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.Person;
import com.splwg.ccb.domain.customerinfo.person.Person_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;*/

import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CharacteristicTypeContactType_Id;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.letterTemplate.entity.LetterTemplate_Id;
import  com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saActivation.SaTypeSaActivationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristics;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
* @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = customerContactClass, name = customerContactClass, required = true, type = entity)
*            , @AlgorithmSoftParameter (name = customerContactType, required = true, type = string)
*            , @AlgorithmSoftParameter (entityName = characteristicType, name = payArrangementDownPaymentCharType, required = true, type = entity)
*            , @AlgorithmSoftParameter (entityName = characteristicType, name = payArrangementDownPaymentDueDateCharType, required = true, type = entity)
*            , @AlgorithmSoftParameter (entityName = characteristicType, name = payArrangementInstallmentsCharType, required = true, type = entity)
*            , @AlgorithmSoftParameter (entityName = characteristicType, name = payArrangementInstallmentAmountCharType, required = true, type = entity)
*            , @AlgorithmSoftParameter (entityName = characteristicType, name = premiseCharType, required = true, type = entity)
*            , @AlgorithmSoftParameter (entityName = characteristicType, name = payArrangementSACharType, required = true, type = entity)})
*/

public class CmCreatePaymentArrangementCustomerContactAlgComp_Impl
		extends	CmCreatePaymentArrangementCustomerContactAlgComp_Gen
		implements SaTypeSaActivationAlgorithmSpot {	
	
	// Hard Parameters
	private ServiceAgreement paServiceAgreement = null;
	
	// Soft Parameters
	private CustomerContactClass parmCustomerContactClass = null;
	private String parmCustomerContactTypeString = "";
	private CustomerContactType parmCustomerContactType = null; 
	private CharacteristicType parmPayArrangementDownPaymentCharType = null;
	private CharacteristicType parmPayArrangementDownPaymentDueDateCharType = null;
	private CharacteristicType parmPayArrangementInstallmentsCharType = null;
	private CharacteristicType parmPayArrangementInstallmentAmountCharType = null;
	private CharacteristicType parmPremiseCharType = null;
	private CharacteristicType parmPayArrangementSACharType = null;	
	
	// Work Variables
	private String paSaDownPayment = "";
	private String paSaDownPaymentDueDate = "";
	private String paSaIntallments = "";
	private String paSaIntallmentAmount = "";
	private String paSaPremise = "";
	
	/**
	 * This method retrieves the Service Agreement hard parameter that is being activated.
	 * @param serviceAgreement - the Service Agreement being activated.
	 */
	public void setServiceAgreement(ServiceAgreement serviceAgreement) {
		paServiceAgreement = serviceAgreement;
	}
	
	/**
	 * This method retrieves and validates the soft parameters for this algorithm.
	 * @param arg0 - not used.
	 */
	protected void extraSoftParameterValidations(boolean arg0) {
		/*
		 * Retrieve and validate Customer Contact Class and Type.
		 * Customer Contact Type must be valid for Customer Contact Class.
		 */
		parmCustomerContactClass = getCustomerContactClass();
		parmCustomerContactTypeString = getCustomerContactType();
		parmCustomerContactType = cmValidateCustomerContactType(
				parmCustomerContactClass, 
				parmCustomerContactTypeString,
				getAlgorithm().getAlgorithmType().getParameterAt(1).fetchLanguageParameterLabel());
		
		/*
		 * Retrieve and validate PA Down Payment Characteristic Type.
		 * Characteristic Type must be valid for Customer Contact entity and valid for Customer Contact Type.
		 */
		parmPayArrangementDownPaymentCharType = getPayArrangementDownPaymentCharType();	
		cmValidateCharacteristicTypeForEntity(
				parmPayArrangementDownPaymentCharType, 
				CharacteristicEntityLookup.constants.CUSTOMER_CONTACT,
				getAlgorithm().getAlgorithmType().getParameterAt(2).fetchLanguageParameterLabel());
		cmValidateCharacteristicTypeForContactType(
				parmPayArrangementDownPaymentCharType, 
				parmCustomerContactType,
				getAlgorithm().getAlgorithmType().getParameterAt(2).fetchLanguageParameterLabel());
		
		/*
		 * Retrieve and validate PA Down Payment Due Date Characteristic Type.
		 * Characteristic Type must be valid for Customer Contact entity and valid for Customer Contact Type.
		 */
		parmPayArrangementDownPaymentDueDateCharType = getPayArrangementDownPaymentDueDateCharType();
		cmValidateCharacteristicTypeForEntity(
				parmPayArrangementDownPaymentDueDateCharType, 
				CharacteristicEntityLookup.constants.CUSTOMER_CONTACT,
				getAlgorithm().getAlgorithmType().getParameterAt(3).fetchLanguageParameterLabel());
		cmValidateCharacteristicTypeForContactType(
				parmPayArrangementDownPaymentDueDateCharType, 
				parmCustomerContactType,
				getAlgorithm().getAlgorithmType().getParameterAt(3).fetchLanguageParameterLabel());
		
		/*
		 * Retrieve and validate PA Installments Characteristic Type.
		 * Characteristic Type must be valid for Customer Contact entity and valid for Customer Contact Type.
		 */
		parmPayArrangementInstallmentsCharType = getPayArrangementInstallmentsCharType();
		cmValidateCharacteristicTypeForEntity(
				parmPayArrangementInstallmentsCharType, 
				CharacteristicEntityLookup.constants.CUSTOMER_CONTACT,
				getAlgorithm().getAlgorithmType().getParameterAt(4).fetchLanguageParameterLabel());
		cmValidateCharacteristicTypeForContactType(
				parmPayArrangementInstallmentsCharType, 
				parmCustomerContactType,
				getAlgorithm().getAlgorithmType().getParameterAt(4).fetchLanguageParameterLabel());
		
		/*
		 * Retrieve and validate PA Installment Amount Characteristic Type.
		 * Characteristic Type must be valid for Customer Contact entity and valid for Customer Contact Type.
		 */ 
		parmPayArrangementInstallmentAmountCharType = getPayArrangementInstallmentAmountCharType();
		cmValidateCharacteristicTypeForEntity(
				parmPayArrangementInstallmentAmountCharType, 
				CharacteristicEntityLookup.constants.CUSTOMER_CONTACT,
				getAlgorithm().getAlgorithmType().getParameterAt(5).fetchLanguageParameterLabel());
		cmValidateCharacteristicTypeForContactType(
				parmPayArrangementInstallmentAmountCharType, 
				parmCustomerContactType,
				getAlgorithm().getAlgorithmType().getParameterAt(5).fetchLanguageParameterLabel());
		
		/*
		 * Retrieve and validate Premise Characteristic Type.
		 * Characteristic Type must be valid for Customer Contact entity and valid for Customer Contact Type.
		 */ 
		parmPremiseCharType = getPremiseCharType();
		cmValidateCharacteristicTypeForEntity(
				parmPremiseCharType, 
				CharacteristicEntityLookup.constants.CUSTOMER_CONTACT,
				getAlgorithm().getAlgorithmType().getParameterAt(6).fetchLanguageParameterLabel());
		cmValidateCharacteristicTypeForContactType(
				parmPremiseCharType, 
				parmCustomerContactType,
				getAlgorithm().getAlgorithmType().getParameterAt(6).fetchLanguageParameterLabel());
		
		/*
		 * Retrieve and validate PA Service Agreement Characteristic Type.
		 * Characteristic Type must be valid for Customer Contact entity and valid for Customer Contact Type.
		 */ 
		parmPayArrangementSACharType = getPayArrangementSACharType();
		cmValidateCharacteristicTypeForEntity(
				parmPayArrangementSACharType, 
				CharacteristicEntityLookup.constants.CUSTOMER_CONTACT,
				getAlgorithm().getAlgorithmType().getParameterAt(7).fetchLanguageParameterLabel());
		cmValidateCharacteristicTypeForContactType(
				parmPayArrangementSACharType, 
				parmCustomerContactType,
				getAlgorithm().getAlgorithmType().getParameterAt(7).fetchLanguageParameterLabel());
	}
	
	/**
	 * This method validates if a given Characteristic Type is valid for a Customer Contact Type.
	 * @param characteristicType - the Characteristic Type to validate.
	 * @param customerContactType - the Customer Contact Type to validate the Characteristic Type for. 
	 * @param parameterDescription - the Algorithm Type parameter description.
	 */
	private void cmValidateCharacteristicTypeForContactType(
			CharacteristicType characteristicType, 
			CustomerContactType customerContactType, 
			String parameterDescription) {
		CharacteristicTypeContactType_Id charTypeContactTypeId = new CharacteristicTypeContactType_Id(customerContactType, characteristicType);
		if(isNull(charTypeContactTypeId.getEntity())){
			// Algorithm %1 parameter '%2%3' value (%4) is not valid for Customer Contact Class/Type (%5/%6).
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharTypeInvalidForCustomerContactType(
					getAlgorithm().getId().getTrimmedValue(),
					parameterDescription.trim(),
					characteristicType.getId().getTrimmedValue(),
					customerContactType.fetchIdContactClass().getId().getTrimmedValue(),
					customerContactType.fetchIdContactType().trim()));
		}
	}

	/**
	 * This method validates if a given Characteristic Type is valid for a given Entity.
	 * @param characteristicType - the Characteristic Type to validate.
	 * @param entityLookup - the Characteristic Entity to validate the Characteristic Type for. 
	 * @param parameterDescription - the Algorithm Type parameter description.
	 */
	private void cmValidateCharacteristicTypeForEntity(
			CharacteristicType characteristicType, 
			CharacteristicEntityLookup entityLookup,
			String parameterDescription) {
		CharacteristicEntity_Id characteristicEntityId = new CharacteristicEntity_Id(characteristicType, entityLookup);
		if(isNull(characteristicEntityId.getEntity())){
			// Algorithm %1's parameter '%2%3' value (%4) is not a valid char type for %5%6 entity.
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharTypeNotValidForEntity(
					getAlgorithm().getId().getTrimmedValue(),
					parameterDescription.trim(),
					characteristicType.getId().getTrimmedValue(),
					entityLookup.getLookupValue().fetchLanguageDescription().trim()));
		}
	}

	/**
	 * This method validates if a given Customer Contact Type is valid for a given Customer Contact Class.
	 * @param customerContactClass - the Customer Contact Class to validate the Customer Contact Type for.
	 * @param customerContactTypeString - the Customer Contact Type to validate.
	 * @param parameterDescription - the Algorithm Type parameter description.
	 * @return customerContactType - a valid Customer Contact Type.
	 */
	private CustomerContactType cmValidateCustomerContactType(
			CustomerContactClass customerContactClass, 
			String customerContactTypeString,
			String parameterDescription) {		
		CustomerContactType_Id customerContactTypeId = new CustomerContactType_Id(customerContactClass, customerContactTypeString);
		CustomerContactType customerContactType = customerContactTypeId.getEntity();
		if(isNull(customerContactType)){
			// Algorithm %1 parameter '%2%3' is an invalid Contact Type (%4) for Contact Class (%5)
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterContactTypeInvalidForContactClass(
					getAlgorithm().getId().getTrimmedValue(),
					parameterDescription.trim(),
					customerContactTypeString.trim(),
					customerContactClass.getId().getTrimmedValue()));
		}
		return customerContactType;
	}

	/**
	 * This method performs the main processing for this Service Agreement Type - Service Agreement Activation algorithm.
	 */
	public void invoke() {
		// If Payment Arrangement SA does not have non-zero Down Payment Amount, skip all processing.  
		paSaDownPayment = cmGetSaCharacteristicValue(paServiceAgreement, parmPayArrangementDownPaymentCharType);		
		if(isEmptyOrNull(paSaDownPayment)){
			return;
		}else{
			if(Double.valueOf(paSaDownPayment) == 0){
				return;
			}
		}
		
		// Retrieve main Person linked to the Payment Arrangement Service agreement being activated.
		Person_Id mainPersonId = cmGetMainPerson(paServiceAgreement.getAccount().getId());
		
		// Retrieve Payment Arrangement Service Agreement details needed for the Customer Contact creation.
		cmGetPayArrangementDetails();
		
		/*
		 * Add a Customer Contact for the main Person linked to the Payment Arrangement Service agreement being activated 
		 * using the Customer Contact Class and Customer Contact Type soft parameters. 
		 */
		CustomerContact paCustomerContact = cmCreateCustomerContact(parmCustomerContactType, mainPersonId);
		
		// Add Customer Contact Characteristics.
		cmAddCustomerContactCharacteristic(paCustomerContact, parmPayArrangementDownPaymentCharType, paSaDownPayment);
		cmAddCustomerContactCharacteristic(paCustomerContact, parmPayArrangementDownPaymentDueDateCharType, paSaDownPaymentDueDate);
		cmAddCustomerContactCharacteristic(paCustomerContact, parmPayArrangementInstallmentsCharType, paSaIntallments);
		cmAddCustomerContactCharacteristic(paCustomerContact, parmPayArrangementInstallmentAmountCharType, paSaIntallmentAmount);
		cmAddCustomerContactCharacteristic(paCustomerContact, parmPremiseCharType, paSaPremise);
		cmAddCustomerContactCharacteristic(paCustomerContact, parmPayArrangementSACharType, paServiceAgreement.getId().getTrimmedValue());
	}
	
	/**
	 * This method adds a characteristic to a Customer Contact given a Characteristic Type and a characteristic value.
	 * @param customerContact - ths Customer Contact to which the characteristic is added to.
	 * @param characteristicType - the Characteristic Type of the characteristic to add.
	 * @param characteristicValue - the characteristic vype of the characteristic to add.
	 */
	private void cmAddCustomerContactCharacteristic(
			CustomerContact customerContact, 
			CharacteristicType characteristicType, 
			String characteristicValue) {
		if(this.isEmptyOrNull(characteristicValue)){
			return;			
		}
		
		// Create Customer Contact characteristic.
		CustomerContactCharacteristics ccChars =  customerContact.getCharacteristics();

        CustomerContactCharacteristic_DTO ccCharacteristicDTO = ccChars.newChildDTO();
        
        CharacteristicTypeLookup charTypeLookup = characteristicType.getCharacteristicType();
		if(charTypeLookup.isForeignKeyValue()){
			ccCharacteristicDTO.setCharacteristicValueForeignKey1(characteristicValue.trim());
		}else if(charTypeLookup.isPredefinedValue()){
			ccCharacteristicDTO.setCharacteristicValue(characteristicValue.trim());
		}else{
			ccCharacteristicDTO.setAdhocCharacteristicValue(characteristicValue.trim());
		}
		
		ccChars.add(ccCharacteristicDTO, characteristicType.getId());
	}

	/**
	 * This method retrieves Payment Arrangement Service Agreement details by calling the base Payment Arrangement page service CILCPASP. 
	 */
	@SuppressWarnings("unchecked")
	private void cmGetPayArrangementDetails() {
		/*
		 * Call base Payment Arrangement page service CILCPASP to retrieve the following:
		 * - Installments (i.e. number of installments);
		 * - Installment Amount (i.e. recurring charge amount on the PA SA); and
		 * - Premise (i.e characteristic Premise ID of the Service Agreement of the "Transfer From" Adjustment).
		 */
		PageHeader pageHeader = new PageHeader();
		PageBody pageBody = new PageBody(); 
		pageHeader.put("PA_SA_ID", paServiceAgreement.getId().getTrimmedValue());		
		pageBody = ServiceDispatcher.readItem("CILCPASP", pageHeader, SessionHolder.getSession().getRequestContext());
		
		paSaIntallments = pageBody.get("CURR_INSTALLMENT").toString().trim();
		paSaIntallmentAmount = pageBody.get("CURR_RCR_CHG_AMT").toString().trim();		
		ItemList listBodyItemList = pageBody.getList("PA_ADJ");
		Iterator<ListBody> listBodyItemListIter = listBodyItemList.getListBodies().iterator();
		if(listBodyItemListIter.hasNext()){
			ListBody listBody = listBodyItemListIter.next();
			ServiceAgreement_Id serviceAgreementId = new ServiceAgreement_Id(listBody.get("SA_ID").toString().trim());
			if(isNull(serviceAgreementId.getEntity().getPremiseId())){
				// Characteristic Premise ID is missing on Service Agreement %1.
				addError(CustomMessageRepositoryMGE.ccb008SACharacteristicPremiseIsMissing(serviceAgreementId.getTrimmedValue()));
			}
			paSaPremise = serviceAgreementId.getEntity().getPremiseId().getTrimmedValue();
		}
		
		// Retrieve the Payment Arrangement Down Payment Due Date Service Agreement characteristic.
		paSaDownPaymentDueDate = cmGetSaCharacteristicValue(paServiceAgreement, parmPayArrangementDownPaymentDueDateCharType);		
	}

	/**
	 * This method retrieves the Service Agreement characteristic's value given a Characteristic Type. 
	 * The most effective characteristic as of process date is retrieved.
	 * @param serviceAgreement - the Service Agreement from which the characteristic value is retrieved.
	 * @param characteristicType - the Characteristic Type of the Service Agreement characteristic.
	 * @return characteristicValue - the characteristic value retrieved.
	 */
	private String cmGetSaCharacteristicValue(
			ServiceAgreement serviceAgreement, 
			CharacteristicType characteristicType) {
		String characteristicValue = "";
		CharacteristicTypeLookup charTypeLookup = characteristicType.getCharacteristicType();
		
		ServiceAgreementCharacteristic saChar = serviceAgreement.getEffectiveCharacteristic(characteristicType);
		if(isNull(saChar)){
			if(characteristicType.equals(parmPayArrangementDownPaymentCharType)){
				return characteristicValue;
			}			
			// Payment Arrangement SA (%1) must have a %2%3 characteristic.
			addError(CustomMessageRepositoryMGE.ccb008PAServiceAgreementCharacteristicIsMissing(
					serviceAgreement.getId().getTrimmedValue(),
					characteristicType.fetchLanguageDescription().trim()));
		}
		
		if(charTypeLookup.isForeignKeyValue()){
			characteristicValue = saChar.getCharacteristicValueForeignKey1();
		}else if(charTypeLookup.isPredefinedValue()){
			characteristicValue = saChar.getCharacteristicValue();
		}else{
			characteristicValue = saChar.getAdhocCharacteristicValue();
		}
		
		return characteristicValue;
	}

	/**
	 * This method creates a Customer Contact for a Person given a Customer Contract Type.
	 * @param customerContactType - the Customer Contact Type to use.
	 * @param mainPersonId - the Person to whom the Customer Contact is created for.
	 * @return customerContact - the Customer Contact created.
	 */
	private CustomerContact cmCreateCustomerContact(
			CustomerContactType customerContactType, 
			Person_Id mainPersonId) {
		CustomerContact customerContact = null;
		LetterTemplate_Id letterTemplateId = customerContactType.getLetterTemplateId();
		
		CustomerContact_DTO customerContactDTO = (CustomerContact_DTO) createDTO(CustomerContact.class);
		customerContactDTO.setCustomerContactTypeId(customerContactType.getId());
		customerContactDTO.setPersonId(mainPersonId);
		customerContactDTO.setContactDateTime(getProcessDateTime());
		customerContactDTO.setUserId(getActiveContextUser().getId());
		if(notNull(letterTemplateId)){
			customerContactDTO.setLetterTemplateId(letterTemplateId);
			customerContactDTO.setShouldPrintLetter(Bool.TRUE);
			BatchControl batchControl = letterTemplateId.getEntity().getBatchControl();
			if(notNull(batchControl)){
				customerContactDTO.setBatchControlId(batchControl.getId());
				customerContactDTO.setBatchNumber(batchControl.getNextBatchNumber());
			}
		}
		
		customerContact = customerContactDTO.newEntity();
		
		return customerContact;
	}

	/**
	 * This method retrieves the main Person of a given Account.
	 * @param accountId - the Account from which the main Person is retrieved.
	 * @return mainPersonId - the main Person of the Account.
	 */
	private Person_Id cmGetMainPerson(Account_Id accountId) {
		Person_Id mainPersonId = null;

		StringBuffer queryString = new StringBuffer();
		queryString.append("SELECT ");
		queryString.append("    AP.PER_ID ");
		queryString.append("FROM ");
		queryString.append("    CI_ACCT_PER AP ");
		queryString.append("WHERE ");
		queryString.append("    AP.ACCT_ID = :accountId ");
		queryString.append("    AND AP.MAIN_CUST_SW = 'Y' ");
		//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        // PreparedStatement query = createPreparedStatement(queryString.toString());	
        PreparedStatement query = createPreparedStatement(queryString.toString(), getClass().getName());	
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        query.bindId("accountId", accountId);
        
        query.execute();
        if(query.list().size() > 0){
        	mainPersonId = (Person_Id) query.firstRow().getId("PER_ID", Person.class);
        }
        query.close();
        
		return mainPersonId;
	}	
}
