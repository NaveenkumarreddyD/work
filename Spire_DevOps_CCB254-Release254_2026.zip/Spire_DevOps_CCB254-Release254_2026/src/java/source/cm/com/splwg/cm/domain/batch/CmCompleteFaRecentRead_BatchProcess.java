/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NM0049 -  FieldWork Changes
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-01-24   Rakesh          NM0049. Initial Version.
 * 2013-06-06   Srikanth        SD20130606 - AMR Daily Read WebService Invocation
 * 2013-06-24   Murali          ML20130624 - Defaulting Meter Read Source Code to A, when AMR Daily Read Service Sents
 *                              No or Invalid Meter Read Source Code is found in CCB
 * 2013-08-28   Srikanth        IM-035909 - Duplicate Read Issue 
 * 2014-07-17	Rahul			IM-054111 - FA completion algorithm not being called.
 * 2016-01-27	MPang	 		Updated for CCB v2.4 compilation. 
 * 2019-04-16   MPang           Defect 4237470. Remove the creation of ToDo if no AMR 
 *                              Correct not found
 * 2021-05-07	JHerna			Emergency Patch. Best Practices regarding global static variables.
 * 								SysAid#368087       
 * 2023-08-01   Kiran			E06473.ADDP Project if the FA TYPE is ADDP get the reads from ADDP Platform           
 * 2023-09-12   Kiran           INC0014756 non ADDP looking for ADDPREAD FA Type which shouldn't
 * 2023-09-12	CAtilano		CCB 227 - 2.1.3. MidCycle Stop/Transfer Field Activity Completion.
 * 2024-02-22   DLampa          INC0025094, Updated to initialize the parameters to avoid 
 *                              the null pointer exception.
 * 2024-02-27   DLampa          INC0025094.2. Updated to use the ThreadIterationStrategy as 
 *                              the framework stores the BatchThreadInstance to prevent the 
 *                              LazyInitializationException.
 * 2025-06-23   Kiran           E09983 if the FA is back to back ignore the recent read
 ******************************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadIterationStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.ThreadWorker;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.StringId;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.serviceScript.ServiceScriptDispatcher;
import com.splwg.base.api.serviceScript.ServiceScriptInstance;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_Id;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole;
import com.splwg.base.domain.todo.toDoType.ToDoTypeSortKeyTypes;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.FieldActivityStepTypeActionLookup;
import com.splwg.ccb.api.lookup.ReadTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementSpFaTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
/*import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType;
import com.splwg.ccb.domain.admin.meterReadSource.MeterReadSource;
import com.splwg.ccb.domain.admin.meterReadSource.MeterReadSource_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementServicePoint_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementSpFieldActivity;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementSpFieldActivity_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementSpFieldActivity_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityStep;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivitySteps;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.Register;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.MeterReadCreatorData;
import com.splwg.ccb.domain.meterread.meterRead.MeterReadCreatorRegisterReadData;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead_Id;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoMaintenanceData;*/
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.meterReadSource.entity.MeterReadSource;
import com.splwg.ccb.domain.admin.meterReadSource.entity.MeterReadSource_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityStep;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivitySteps;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.ccb.domain.meterread.data.MeterReadCreatorData;
import com.splwg.ccb.domain.meterread.data.MeterReadCreatorRegisterReadData;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_Id;
import com.splwg.ccb.domain.todo.common.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.data.ToDoMaintenanceData;
import com.splwg.cm.api.lookup.CmQuotePortalParametersLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.cm.domain.common.CmWSDLCallToAMRDataBase;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;
/**
 *
@BatchJob (modules = {},
 *			multiThreaded = true,
 *      	rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (entityName = fieldActivityType, name = FA_TYPE_CD, type = entity)
 *            , @BatchJobSoftParameter (lookupName = readType, name = READ_TYPE_CD, required = true, type = lookup)
 *            , @BatchJobSoftParameter (name = WAIT_TIME, required = true, type = integer)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = TO_DO_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = role, name = TO_DO_ROLE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = unitOfMeasure, name = CORRECTED_UOM_CD,  type = entity)
 *            , @BatchJobSoftParameter (entityName = unitOfMeasure, name = UNCORRECTED_UOM_CD, type = entity)
 *            , @BatchJobSoftParameter (entityName = fieldActivityType, required = true, name = ADDP_FA_TYPE_CD, type = entity)
 *            , @BatchJobSoftParameter (name = ADDP_READ_TIME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = FA_CHAR_TYPE, type = entity)
 *            , @BatchJobSoftParameter (name = HEATING_SSON_THRESHOLD, type = integer)
 *            , @BatchJobSoftParameter (name = NONHEATING_SSON_THRESHOLD, type = integer)
 *            , @BatchJobSoftParameter (name = TRIM_READ_RTE_TYPE, type = string)})
 */

public class CmCompleteFaRecentRead_BatchProcess extends
CmCompleteFaRecentRead_BatchProcess_Gen {

	//Logger
	private static final Logger logger= LoggerFactory.getLogger(CmCompleteFaRecentRead_BatchProcess.class);    
	
	
    //	Soft Parameters
    private static FieldActivityType parmFAType;
    private static ReadTypeLookup parmReadType;
    private static BigInteger parmWaitTime;
    private static ToDoType parmToDoType;
    private static Role parmToDoRole;
    private static UnitOfMeasure parmCorrectedUOM;
    private static UnitOfMeasure parmUnCorrectedUOM;
    private static FieldActivityType parmADDPFAType;
    private static String parmADDPReadTime;
    private static CharacteristicType parmFaCharType;
    private static BigInteger parmHeatingSsonThreshold;
    private static BigInteger parmNonheatingSson;
    private static List<String> parmTrimReadRteTypes;  
   
   // Begin of change  2023-08-01   Kiran

    private static final String CM_ADDPREAD="CM-ADDP";
	private static final String GROUP_INPUT = "input";
	private static final String GROUP_OUTPUT = "output";
	private static final String QUOTE_PORTAL_FEAT_CONFIG = "CM-QPPARM";
	private static final String DATE_FORMAT = "yyyy-MM-dd";
	private static Date cWRStart;
	private static Date cWREnd;
	 
  // End of change  2023-08-01   Kiran
	// Start Delete - DLampa - 2024-02-27 - INC0025094.2
    //public JobWork getJobWork() {
    //    QueryIterator mainIter = getPendingFAs().iterate();
    //    return createJobWorkForQueryIterator(mainIter, this);
    //}

    //private PreparedStatement getPendingFAs(){

    //    StringBuilder getPendingFAString = new StringBuilder();
    //    getPendingFAString.append("SELECT FA.FA_ID, FA.SCHED_DTTM SCHED_DT, SP.SP_ID, MC.MTR_CONFIG_ID, MTR.BADGE_NBR ");
    //    getPendingFAString.append("FROM CI_FA FA, CI_SP SP, CI_SP_MTR_HIST SMH, CI_MTR_CONFIG MC, CI_MTR MTR ");
    //    getPendingFAString.append("WHERE FA.SP_ID = SP.SP_ID ");
    //    getPendingFAString.append("AND FA.FA_TYPE_CD IN (:faTypeCode, :ADDPfaTypeCode) ");
    //    getPendingFAString.append("AND FA.SCHED_DTTM <= :batchBusinessDateTime ");
    //    getPendingFAString.append("AND FA.ELIG_DISPATCH_SW = 'N' ");
    //    getPendingFAString.append("AND FA.FA_STATUS_FLG = :faStatus ");
    //    getPendingFAString.append("AND SP.SP_ID = SMH.SP_ID ");		
    //    getPendingFAString.append("AND SMH.REMOVAL_DTTM IS NULL ");
    //    getPendingFAString.append("AND SMH.MTR_CONFIG_ID = MC.MTR_CONFIG_ID ");
    //    getPendingFAString.append("AND MC.MTR_ID = MTR.MTR_ID ");
        //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
        //PreparedStatement getPendingFAPrepStmt = createPreparedStatement(getPendingFAString.toString()); 
    //    PreparedStatement getPendingFAPrepStmt = createPreparedStatement(getPendingFAString.toString(), getClass().getName()); 
        //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
        // 
        // Begin of change  2023-08-01   Kiran
        // * 2023-09-12   Kiran           INC0014756 
    //    getPendingFAPrepStmt.bindId("faTypeCode",parmFAType.getId());
        //  * 2023-09-12   Kiran           INC0014756 
    //    getPendingFAPrepStmt.bindId("ADDPfaTypeCode",parmADDPFAType.getId());
        
        // End of change  2023-08-01   Kiran
    //    getPendingFAPrepStmt.bindDateTime("batchBusinessDateTime", getProcessDateTime());

    //    getPendingFAPrepStmt.bindLookup("faStatus", FieldActivityStatusLookup.constants.PENDING);       


    //    return getPendingFAPrepStmt;
    //}

    //public ThreadWorkUnit createWorkUnit(QueryResultRow row){
    //    ThreadWorkUnit threadUnit = new ThreadWorkUnit();             
    //    FieldActivity_Id fieldActivityId = (FieldActivity_Id) row.getId("FA_ID", FieldActivity.class);
    //    threadUnit.setPrimaryId(fieldActivityId);
    //    threadUnit.addSupplementalData("SCHED_DT", row.getDateTime("SCHED_DT"));
    //    threadUnit.addSupplementalData("SP_ID", row.getId("SP_ID",ServicePoint.class));
    //    threadUnit.addSupplementalData("MTR_CONFIG_ID", row.getId("MTR_CONFIG_ID",MeterConfiguration.class));
    //    threadUnit.addSupplementalData("BADGE_NBR", row.getString("BADGE_NBR"));
    //    return threadUnit;
    //}      
    // End Delete - DLampa - 2024-02-27 - INC0025094.2

    public Class<CmCompleteFaRecentRead_BatchProcessWorker> getThreadWorkerClass() {
        return CmCompleteFaRecentRead_BatchProcessWorker.class;
    }

    public void validateSoftParameters(boolean arg0){

        Boolean exists = false;
        parmFAType = getParameters().getFA_TYPE_CD();
        parmReadType = getParameters().getREAD_TYPE_CD();
        parmWaitTime = getParameters().getWAIT_TIME();
        parmToDoType = getParameters().getTO_DO_TYPE_CD();
        parmToDoRole = getParameters().getTO_DO_ROLE_CD();
        parmCorrectedUOM = getParameters().getCORRECTED_UOM_CD();
        parmUnCorrectedUOM = getParameters().getUNCORRECTED_UOM_CD();
        parmFaCharType = getParameters().getFA_CHAR_TYPE();
        parmHeatingSsonThreshold = getParameters().getHEATING_SSON_THRESHOLD();
        parmNonheatingSson = getParameters().getNONHEATING_SSON_THRESHOLD();
        if(isNull(getParameters().getTRIM_READ_RTE_TYPE()))
        	parmTrimReadRteTypes = null;
        else
        	parmTrimReadRteTypes = new ArrayList<String>(Arrays.asList(getParameters().getTRIM_READ_RTE_TYPE().split(",")));

        // Begin of change  2023-08-01   Kiran
        parmADDPFAType = getParameters().getADDP_FA_TYPE_CD();
        parmADDPReadTime = getParameters().getADDP_READ_TIME();
        
        // End of change  2023-08-01   Kiran

        // Check Role is valid for type
        for (ToDoTypeRole todoTypeRole : parmToDoType.getRoles()) {
            if (todoTypeRole.fetchIdToDoRole().getId().getIdValue().trim()
                    .equals(parmToDoRole.getId().getIdValue().trim())) {
                exists = true;
                break;
            }
        }
        if (!exists) {
            addError(CustomMessageRepository.nm0049invalidToDoRoleType(
                    parmToDoRole.getId().getIdValue().toString(), parmToDoType.getId()
                    .getIdValue().toString()));
        }

    }

    public static class CmCompleteFaRecentRead_BatchProcessWorker
    	extends CmCompleteFaRecentRead_BatchProcessWorker_Gen {
    	
        private String strAMRWsdlURL = null;
        private MeterReadSource meterReadSource = new MeterReadSource_Id("A").getEntity();

        public ThreadExecutionStrategy createExecutionStrategy() {
        	//Start Change - DLampa - 2024-02-27 - INC0025094.2
            //return new StandardCommitStrategy(this);
            return (ThreadExecutionStrategy)new ThreadIterationStrategy((ThreadWorker)this);
            //End Change - DLampa - 2024-02-27 - INC0025094.2
        }

        /*START ADD - JHERNA - 2021-05-07 - Emergency Patch 368087*/	   
        @SuppressWarnings("unused")
		private FieldActivityType parmFAType;
	    @SuppressWarnings("unused")
		private BigInteger parmWaitTime;
	    private ReadTypeLookup parmReadType;
	    private ToDoType parmToDoType;
	    private Role parmToDoRole;
	    private UnitOfMeasure parmCorrectedUOM;
	    private UnitOfMeasure parmUnCorrectedUOM;
	    private FieldActivityType parmADDPFAType;
	    private String parmADDPReadTime;
	    private DateFormat dateFormat = new DateFormat(DATE_FORMAT);
	    private Boolean correctRead;
	    // Start Add - DLampa - 2024-02-22 - INC0025094
	    private CharacteristicType parmFaCharType;
	    private BigInteger parmHeatingSsonThreshold;
	    private BigInteger parmNonheatingSson;
	    private List<String> parmTrimReadRteTypes;
	    // End Add - DLampa - 2024-02-22 - INC0025094
	    
		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
			/*Initialize variables*/
		    parmFAType = this.getParameters().getFA_TYPE_CD();
		    parmReadType = this.getParameters().getREAD_TYPE_CD();
		    parmWaitTime = this.getParameters().getWAIT_TIME();
		    parmToDoType = this.getParameters().getTO_DO_TYPE_CD();
		    parmToDoRole = this.getParameters().getTO_DO_ROLE_CD();
		    parmCorrectedUOM = this.getParameters().getCORRECTED_UOM_CD();
		    parmUnCorrectedUOM = this.getParameters().getUNCORRECTED_UOM_CD();
		    
		    // Begin of change  2023-08-01   Kiran ADDP Project
		    parmADDPFAType = this.getParameters().getADDP_FA_TYPE_CD();
		    parmADDPReadTime = this.getParameters().getADDP_READ_TIME();
		    
		    FeatureConfiguration featureConfiguration = new FeatureConfiguration_Id(QUOTE_PORTAL_FEAT_CONFIG).getEntity();
		    CmFeatureConfigurationRetriever featConfigRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
			featConfigRetriever.setParmWFMName(featureConfiguration);
			featConfigRetriever.setParmOptType(CmQuotePortalParametersLookup.constants.CWR_SEASON_BEGIN.getLookupValue().fetchIdFieldValue());
			String []startCWR = featConfigRetriever.getMaxSequenceOptionValue().trim().split("/");
			cWRStart = new Date(getProcessDateTime().getYear(), Integer.valueOf(startCWR[0]).intValue(), Integer.valueOf(startCWR[1]).intValue());
			featConfigRetriever.setParmOptType(CmQuotePortalParametersLookup.constants.CWR_SEASON_END.getLookupValue().fetchIdFieldValue());
			String []endCWR = featConfigRetriever.getMaxSequenceOptionValue().trim().split("/");
			cWREnd = new Date(getProcessDateTime().getYear(), Integer.valueOf(endCWR[0]).intValue(), Integer.valueOf(endCWR[1]).intValue());
			
		    
		    // End of change  2023-08-01   Kiran ADDP Project
			
			// Start Add - DLampa - 2024-02-22 - INC0025094
			// Initialize new parameters
	        parmFaCharType = this.getParameters().getFA_CHAR_TYPE();
	        parmHeatingSsonThreshold = this.getParameters().getHEATING_SSON_THRESHOLD();
	        parmNonheatingSson = this.getParameters().getNONHEATING_SSON_THRESHOLD();
	        if(isNull(getParameters().getTRIM_READ_RTE_TYPE())) {
	        	parmTrimReadRteTypes = null;
	        } else {
	        	parmTrimReadRteTypes = new ArrayList<String>(Arrays.asList(this.getParameters().getTRIM_READ_RTE_TYPE().split(",")));
	        }
			// End Add - DLampa - 2024-02-22 - INC0025094
	        
	         // Start Add - DLampa - 2024-02-27 - INC0025094.2
	         this.startResultRowQueryIteratorForThread(FieldActivity_Id.class);
	         // End Add - DLampa - 2024-02-27 - INC0025094.2
		}
		
		/*END ADD - JHERNA - 2021-05-07 - Emergency Patch 368087*/

		// Start Add - DLampa - 2024-02-27 - INC0025094.2
        @Override
        protected QueryIterator getQueryIteratorForThread(StringId lowID, StringId highID) {

            StringBuilder getPendingFAString = new StringBuilder();
            getPendingFAString.append("SELECT FA.FA_ID, FA.SCHED_DTTM SCHED_DT, SP.SP_ID, MC.MTR_CONFIG_ID, MTR.BADGE_NBR ");
            getPendingFAString.append("FROM CI_FA FA, CI_SP SP, CI_SP_MTR_HIST SMH, CI_MTR_CONFIG MC, CI_MTR MTR ");
            getPendingFAString.append("WHERE FA.SP_ID = SP.SP_ID ");
            getPendingFAString.append("AND FA.FA_TYPE_CD IN (:faTypeCode, :ADDPfaTypeCode) ");
            getPendingFAString.append("AND FA.SCHED_DTTM <= :batchBusinessDateTime ");
            getPendingFAString.append("AND FA.ELIG_DISPATCH_SW = 'N' ");
            getPendingFAString.append("AND FA.FA_STATUS_FLG = :faStatus ");
            getPendingFAString.append("AND SP.SP_ID = SMH.SP_ID ");     
            getPendingFAString.append("AND SMH.REMOVAL_DTTM IS NULL ");
            getPendingFAString.append("AND SMH.MTR_CONFIG_ID = MC.MTR_CONFIG_ID ");
            getPendingFAString.append("AND MC.MTR_ID = MTR.MTR_ID ");            
            getPendingFAString.append("AND FA.FA_ID BETWEEN :lowId AND :highId ");
            
            PreparedStatement getPendingFAPrepStmt = createPreparedStatement(getPendingFAString.toString(), getClass().getName()); 
            getPendingFAPrepStmt.bindId("faTypeCode",parmFAType.getId());
            getPendingFAPrepStmt.bindId("ADDPfaTypeCode",parmADDPFAType.getId());
            getPendingFAPrepStmt.bindDateTime("batchBusinessDateTime", getProcessDateTime());
            getPendingFAPrepStmt.bindLookup("faStatus", FieldActivityStatusLookup.constants.PENDING);
            getPendingFAPrepStmt.bindId("lowId", lowID);
            getPendingFAPrepStmt.bindId("highId", highID);
            
            getPendingFAPrepStmt.setAutoclose(false);
            getPendingFAPrepStmt.execute();
            
            return getPendingFAPrepStmt.iterate();
        	
        }
        
        @Override
        protected ThreadWorkUnit getNextWorkUnit(QueryResultRow row){
            ThreadWorkUnit threadUnit = new ThreadWorkUnit();             
            FieldActivity_Id fieldActivityId = (FieldActivity_Id) row.getId("FA_ID", FieldActivity.class);
            threadUnit.setPrimaryId(fieldActivityId);
            threadUnit.addSupplementalData("SCHED_DT", row.getDateTime("SCHED_DT"));
            threadUnit.addSupplementalData("SP_ID", row.getId("SP_ID",ServicePoint.class));
            threadUnit.addSupplementalData("MTR_CONFIG_ID", row.getId("MTR_CONFIG_ID",MeterConfiguration.class));
            threadUnit.addSupplementalData("BADGE_NBR", row.getString("BADGE_NBR"));
            return threadUnit;
        }          
		// End Add - DLampa - 2024-02-27 - INC0025094.2		
		
        public boolean executeWorkUnit(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {
            List<SQLResultRow> saSPList;
            SQLResultRow saSPRow = null;
            ServiceAgreementServicePoint_Id saSpId;
            FieldActivity_Id faSaSp;
            ServiceAgreementStatusLookup saStatus;
          //IM-035909 - Duplicate Read Issue - Start
            MeterRead meterRead = null;
          //IM-035909 - Duplicate Read Issue - End
            correctRead = false;
            Boolean createAddpRead = false;

            FieldActivity_Id fieldActivityId  = (FieldActivity_Id)unit.getPrimaryId();
            FieldActivity fa = fieldActivityId.getEntity();
            DateTime scheduleDate = (DateTime) unit.getSupplementallData("SCHED_DT");

            ServicePoint_Id spId = (ServicePoint_Id) unit.getSupplementallData("SP_ID");
            MeterConfiguration_Id meterConfigId = (MeterConfiguration_Id) unit.getSupplementallData("MTR_CONFIG_ID");
            String badgeNumber = (String) unit.getSupplementallData("BADGE_NBR");
            String serailNumber = meterConfigId.getEntity().getMeter().getSerialNumber();
            //IM-035909 - Duplicate Read Issue - Start
			MeterRead_Id mrId = rerieveUsableMeterRead(meterConfigId,scheduleDate);
			if(notNull(mrId)){
				meterRead = mrId.getEntity();
			}
			//If FA type is ADDPREAD, process ADDP logic
			else if(fieldActivityId.getEntity().getFieldActivityType().getId().getTrimmedValue().equals(parmADDPFAType.getId().getTrimmedValue()))
			{
				//IM-035909 - Duplicate Read Issue - End
	            String serviceRouteType = null;
	            String serviceCycle = null;
	            serviceCycle = spId.getEntity().getMeterReadCycleId().getIdValue();
	            serviceRouteType = spId.getEntity().getMeterReadRouteId().getEntity().getMeterReadRouteType().getId().getIdValue().trim();
	            
	            //Check the Service Route Type, if is s configured in TRIM_READ_RTE_TYPE the read needs to be corrected
	            if(!isNull(parmTrimReadRteTypes) && parmTrimReadRteTypes.contains(serviceRouteType)){
	            	correctRead = true;
	            }
	            

                
	            //If current Read is a Stop Read..
	            if(isStopFa(fieldActivityId, spId)){
	            	//Get Most Recent use on Bill Read
	            	MeterRead_Id mostRecentRead = this.retrieveRecentMeterRead(meterConfigId, scheduleDate);
            		long dateDifference = scheduleDate.difference(mostRecentRead.getEntity().getReadDateTime()).getTotalDays();
            		BigInteger dateDiff = BigInteger.valueOf(dateDifference);
            		
            		//Check if current FA's schedule Date is within CWR Season (heating season)
	            	if(scheduleDate.getDate().isSameOrAfter(cWRStart) || scheduleDate.getDate().isSameOrBefore(cWREnd)){
	            		//Current FA's schedule Date is within CWR Season
	          
	            		//Check if Latest Read's difference and Fa's schedule Date is equal or less than threshold parameter
	            		if(dateDiff.compareTo(parmHeatingSsonThreshold) < 1){
	            			//If read is within the threshold, use that read

                            if(isStartStopFa(fieldActivityId, spId)){
                                createAddpRead = true;
                            }
                            else{
	            			meterRead = mostRecentRead.getEntity();
                            }
	            		}
	            		else{
	            			createAddpRead = true;
	            		}
	            	}
	            	//FA is not within CWR season (heating season)
	            	else{
	            		if(dateDiff.compareTo(parmNonheatingSson) < 1){
	            			//If read is within the threshold, use that read
	            			if(isStartStopFa(fieldActivityId, spId)){
                                createAddpRead = true;
                            }
                            else{
	            			meterRead = mostRecentRead.getEntity();
                            }
	            		}
	            		else{		
	            			createAddpRead = true;
	            		}
	            	}
	            	
	            }
	            //not Stop FA 
	            else{
	            	createAddpRead = true;
	            }
	            if (createAddpRead){
	            	//If the FA has a characteristic type equal to what's configured in parameter 110 then determine the characteristic's value, which will be a date.
	            	if(!checkDateChar(fa))
	            		//If the current date is less than the date in the characteristic, then skip the record. 
        				return true;
        			meterRead = createADDPOutboundMessageAndRead(serailNumber, badgeNumber, scheduleDate, fieldActivityId, meterConfigId);
	            }
			}
		    else
			    {	
	            CmWSDLCallToAMRDataBase responseValues = retrieveMeterRead(badgeNumber,spId,scheduleDate);
			    
	            if(isNull(responseValues.getAmrCorrectedRead())){
	            	//Start Change - 2019-04-16 - Defect 4237470
	            	//if(getProcessDateTime().compareTo(scheduleDate.addDays(parmWaitTime.intValue()))>0){
	            	//    //Log Error
	            	//    createTODO(fieldActivityId);
	            	//    logError(CustomMessageRepository.nm0049ProcessDateExceedsSchDate(fieldActivityId.getIdValue().trim()));
	
	            	//}
	            	logError(CustomMessageRepository.nm0049NoAmrCorrectedReadFound(fieldActivityId.getIdValue().trim()));
	            	//End Change - 2019-04-16 - Defect 4237470
	            }
	            else{
	                String strMeterReadSrc = responseValues.getStrReadSource();
	                
	                if(isNull(strMeterReadSrc)){
	                    logWarning (CustomMessageRepository.nm0049meterReadSrcNotInAMR(badgeNumber, spId.getIdValue()));
	                    //return true;
	                }
	                MeterReadSource mrSourceFromAMR = new MeterReadSource_Id(strMeterReadSrc).getEntity();
	                if(isNull(mrSourceFromAMR)){
	                    // ML20130624 - Start
	                    // logWarning (CustomMessageRepository.nm0049InvalidMeterReadSource(strMeterReadSrc));
	                    mrSourceFromAMR = meterReadSource;
	                    // ML20130624 - End
	                    //return true;
	                }
	
	                // ML20130624 - Start
	                /*else{
			    mrSourceFromAMR = meterReadSource; 
			}*/
	
	                // ML20130624 - End
	                
	
	                //MeterRead meterRead= createMeterRead(meterConfigId,scheduleDate,meterReadSourceId,actualRead,fieldActivityId);				
	                meterRead= createMeterRead(meterConfigId,mrSourceFromAMR,responseValues,fieldActivityId);	
					//IM-035909 - Duplicate Read Issue - Start
				 }
		    }
		
			
			if(notNull(meterRead)){
			//IM-035909 - Duplicate Read Issue - End	
				startChanges();
                FieldActivity_DTO faDTO = fieldActivityId.getEntity().getDTO();
                FieldActivitySteps steps =fieldActivityId.getEntity().getSteps();
                
                for(FieldActivityStep step :steps){
                    if(step.getFaStepTypeAction().isReadMeter()){
                        updateMeterReadOnFAStep(fieldActivityId,meterRead.getId());						
                    }
                }
// Start changes 2014-07-17	Rahul			IM-054111
                //faDTO.setFieldActivityStatus(FieldActivityStatusLookup.constants.COMPLETED);
                //fieldActivityId.getEntity().setDTO(faDTO);
				fieldActivityId.getEntity().complete();
// End   changes 2014-07-17	Rahul			IM-054111
                if(!(fieldActivityId.getEntity().getFieldActivityStatus().compareTo(FieldActivityStatusLookup.constants.COMPLETED)==0)){
                    createTODO(fieldActivityId);
                    logError(CustomMessageRepository.nm0049FaCompleteError(fieldActivityId.getIdValue().trim()));
                }

                //Link Completed FA to SASP
                saSPList = retrieveSASPToLinkFA(spId);
                for (Iterator<SQLResultRow> saSPIter = saSPList.iterator(); saSPIter.hasNext();) 
                {

                    saSPRow = (SQLResultRow) saSPIter.next();

                    saSpId = (ServiceAgreementServicePoint_Id) saSPRow.getId("SA_SP_ID",ServiceAgreementServicePoint.class);
                    faSaSp = (FieldActivity_Id) saSPRow.getId("FA_ID",FieldActivity.class);
                    saStatus = (ServiceAgreementStatusLookup) saSPRow.getLookup("SA_STATUS_FLG",ServiceAgreementStatusLookup.class);
                    if(saStatus.compareTo(ServiceAgreementStatusLookup.constants.PENDING_START)==0 && isNull(faSaSp)){
                        //Link FA to SASP
                        linkFAtoSASP(fieldActivityId.getEntity(), ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY, saSpId.getEntity(),spId );
                    }else{
                        if(saStatus.compareTo(ServiceAgreementStatusLookup.constants.PENDING_STOP)==0 && isNull(faSaSp)){
                            linkFAtoSASP(fieldActivityId.getEntity(), ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY, saSpId.getEntity(),spId );
                        }
                    }

                }
                saveChanges();
            }


            return true;
        }

        /**
         * This method will retreive the Meter Read from the daily meter read database
         * using the input business service.
         * @param readDate
         * @return
         */
        private CmWSDLCallToAMRDataBase retrieveMeterRead(String badgeNumber,ServicePoint_Id spId,DateTime scheduleDate){
            //SD20130606 - Web Service Invocation.
            // Only Corrected read will be used.This is because from the Batch parameter and Register UOM, Corrected/Uncorrected cannot be determined
            // and Web Service does not Provide the UOM in response.
            // Alternative would be to match the Batch Param UOM with the Feature Config and determine if this is Corrected/Uncorrected.

            //			BigDecimal amrCorrectedRead;
            CmWSDLCallToAMRDataBase wsdlComp = CmWSDLCallToAMRDataBase.Factory.newInstance();
            if(isNull(strAMRWsdlURL)){
                strAMRWsdlURL = wsdlComp.getWsdlURLForAMRReads();
                if(isNull(strAMRWsdlURL)){
                    addError(wsdlComp.getServerMessage());
                }
            }
            wsdlComp.setWsdlURL(strAMRWsdlURL);
            wsdlComp.setInputBadgeNumber(badgeNumber);
            wsdlComp.setInputSpId(spId);
            wsdlComp.setInputReadDate(scheduleDate.getDate());

            try{
                wsdlComp.retreiveReadDetailsFromAMR();
            }catch(UnknownHostException uhe){
                throw new RunAbortedException(CustomMessageRepository.webServiceHostUnreachable(uhe.getMessage()));
            }catch(Exception excp){
                throw new RunAbortedException(CustomMessageRepository.errorInvokingAMRWebService(excp.getMessage()));
            }
            //			amrCorrectedRead = wsdlComp.getAmrCorrectedRead();
            return wsdlComp;

        }

        private MeterRead createMeterRead(MeterConfiguration_Id meterConfigId,MeterReadSource mrSourceFromAMR,
                CmWSDLCallToAMRDataBase responseValues,FieldActivity_Id faId){

            MeterReadCreatorData mrCreator = MeterReadCreatorData.Factory.newInstance();
            mrCreator.setReadDateTime(responseValues.getAmrCorrectedReadDate());
            MeterRead meterRead = null;	
            //continue with meter read creation
            List<MeterReadCreatorRegisterReadData> mrcrrd = new ArrayList<MeterReadCreatorRegisterReadData>();
            try{
            //iterate throug the registers to get the sequences to add the reads
	            Iterator<Register> iterator = meterConfigId.getEntity().getRegisters().iterator();
	            while (iterator.hasNext()) {
	                Register register = iterator.next();
	                MeterReadCreatorRegisterReadData mrCreatorRegRead = MeterReadCreatorRegisterReadData.Factory.newInstance();
	                mrCreatorRegRead.setReadSequence(register.getSeq());
	                mrCreatorRegRead.setReadType(parmReadType);
	                //Corrected Read
	                if(register.getUnitOfMeasure().getId().compareTo(parmCorrectedUOM.getId()) == 0){
	                    mrCreatorRegRead.setRegisterReading(responseValues.getAmrCorrectedRead());
	                    //mtrCreatorRegRead.setRegisterReading(actualRead);
	                }//Uncorrected Read
	                else if(notNull(responseValues.getAmrUnCorrectedRead()) && (register.getUnitOfMeasure().getId().compareTo(parmUnCorrectedUOM.getId()) == 0)){
	                    mrCreatorRegRead.setRegisterReading(responseValues.getAmrUnCorrectedRead());
	                }
	                mrcrrd.add(mrCreatorRegRead);
	            }
	
	            mrCreator.setRegisterReadDataList(mrcrrd);
	            mrCreator.setIsInstallationRead(Bool.FALSE);
	            mrCreator.setCanUseOnBill(Bool.TRUE);
	            mrCreator.setMeterReadSource(mrSourceFromAMR);
	            //add meter reads to the configuration
	
	            meterRead = meterConfigId.getEntity().addMeterRead(mrCreator);
	            if(isNull(meterRead)){
	                createTODO(faId);
	                logError(CustomMessageRepository.nm0049CannotCreateMeterRead(faId.getIdValue().trim()));
	            }
	        }catch(ApplicationError e){
	        	addError(CustomMessageRepository.nm0049ApplicationError(e.getMessage()));
	        }
            return meterRead;
        }

        
        
        // Begin of change  2023-08-01   Kiran ADDP Project
        private MeterRead createMeterReadADDP(MeterConfiguration_Id meterConfigId,MeterReadSource mrSourceFromADDP,
                String ADDPReading, FieldActivity_Id faId,DateTime readDate){

            MeterReadCreatorData mrCreator = MeterReadCreatorData.Factory.newInstance();
            mrCreator.setReadDateTime(readDate);
            //continue with meter read creation
            List<MeterReadCreatorRegisterReadData> mrcrrd = new ArrayList<MeterReadCreatorRegisterReadData>();

            //iterate through the registers to get the sequences to add the reads
            
            Iterator<Register> iterator = meterConfigId.getEntity().getRegisters().iterator();
            while (iterator.hasNext()) {
                Register register = iterator.next();
                if(correctRead){
	                if(register.getUnitOfMeasure().getId().getIdValue().compareTo("CCFC") == 0)
	                {
	                	if(ADDPReading.length() > 2) 
	                	{
	                	ADDPReading = ADDPReading.substring(0, ADDPReading.length() - 2);
	                	}
	                }
	                if(register.getUnitOfMeasure().getId().getIdValue().compareTo("MCFC") == 0)
	                {
	                	if(ADDPReading.length() > 3) 
	                	{
	                	ADDPReading = ADDPReading.substring(0, ADDPReading.length() - 3);
	                	}
	                	
	                }
                }
                BigDecimal finalRead = new BigDecimal(ADDPReading);
                MeterReadCreatorRegisterReadData mrCreatorRegRead = MeterReadCreatorRegisterReadData.Factory.newInstance();
                mrCreatorRegRead.setReadSequence(register.getSeq());
                mrCreatorRegRead.setReadType(parmReadType);
                // Always Corrected Read for Brightlync
               // if(register.getUnitOfMeasure().getId().compareTo(parmCorrectedUOM.getId()) == 0){
                    mrCreatorRegRead.setRegisterReading(finalRead);
                    //mtrCreatorRegRead.setRegisterReading(actualRead);
              //  }//Uncorrected Read
               // else if(notNull(responseValues.getAmrUnCorrectedRead()) && (register.getUnitOfMeasure().getId().compareTo(parmUnCorrectedUOM.getId()) == 0)){
               //     mrCreatorRegRead.setRegisterReading(responseValues.getAmrUnCorrectedRead());
               // }
                mrcrrd.add(mrCreatorRegRead);
            }

            mrCreator.setRegisterReadDataList(mrcrrd);
            mrCreator.setIsInstallationRead(Bool.FALSE);
            mrCreator.setCanUseOnBill(Bool.TRUE);
            mrCreator.setMeterReadSource(mrSourceFromADDP);
            //add meter reads to the configuration

            MeterRead meterRead = meterConfigId.getEntity().addMeterRead(mrCreator);
            if(isNull(meterRead)){
                createTODO(faId);
                logError(CustomMessageRepository.nm0049CannotCreateMeterRead(faId.getIdValue().trim()));
            }
            return meterRead;
        }

        
        // End of change  2023-08-01   Kiran ADDP Project
        private void createTODO(FieldActivity_Id faId) {
            ToDoEntry_DTO entryDto = (ToDoEntry_DTO) createDTO(ToDoEntry.class);

            parmToDoType = parmToDoType.getId().getEntity();
            entryDto.setToDoTypeId(parmToDoType.getId());
            entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
            entryDto.setToDoPriority(parmToDoType.getToDoPriority());
            entryDto.setToDoRoleId(parmToDoRole.getId());
            entryDto.setCreationDateTime(getProcessDateTime());
            entryDto.setToDoPriority(parmToDoType.getToDoPriority());

            ArrayList<ToDoSortKeyValue_DTO> sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();
            ToDoTypeSortKeyTypes sortKeyTypes = parmToDoType.getSortKeyTypes();

            for (Iterator iter = sortKeyTypes.iterator(); iter.hasNext();) {
                ToDoSortKeyType sortKeyType = (ToDoSortKeyType) iter.next();
                ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
                BigInteger seq = sortKeyType.fetchIdSequence();
                sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));


                if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(1))==0){
                    sortKeyDto.setKeyValue(BigInteger.valueOf(CustomMessageRepository.NM0049_TODO_ERROR_MSG).toString());
                }

                if (sortKeyType.getId().getSequence().compareTo(
                        BigInteger.valueOf(2)) == 0) {
                    sortKeyDto.setKeyValue(faId.getIdValue().trim());
                }

                sortKeyList.add(sortKeyDto);
            }

            ArrayList<ToDoDrillKeyValue_DTO> drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
            ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO) createDTO(ToDoDrillKeyValue.class);
            ToDoDrillKeyType drillKeyType = (ToDoDrillKeyType) parmToDoType
            .getDrillKeyTypes().iterator().next();
            BigInteger sequence = drillKeyType.fetchIdSequence();
            drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, sequence));

            drillKeyDto.setKeyValue(faId.getIdValue().trim());
            drillKeyList.add(drillKeyDto);

            MessageCategory_Id msgCatId = new MessageCategory_Id(BigInteger.valueOf(CustomMessageRepository.MESSAGE_CATEGORY));
            Message_Id msgId = new Message_Id(msgCatId, BigInteger.valueOf(CustomMessageRepository.NM0049_TODO_ERROR_MSG));
            entryDto.setMessageId(msgId);

            ArrayList<String> messageParameterList = new ArrayList<String>();
            messageParameterList.add(0, parmToDoType.getId().getIdValue());

            ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory
            .newInstance();

            toDoEntryData.setDrillKeys(drillKeyList);
            toDoEntryData.setEntryDto(entryDto);
            toDoEntryData.setSortKeys(sortKeyList);
            toDoEntryData.setMessageParams(messageParameterList);
            ArrayList<ToDoEntryCharacteristic_DTO> charList = new ArrayList<ToDoEntryCharacteristic_DTO>();
            toDoEntryData.setToDoCharacteristics(charList);

            ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory
            .newInstance();
            toDoProcessor.addToDo(toDoEntryData);

        }

        private void updateMeterReadOnFAStep(FieldActivity_Id faId,MeterRead_Id mrId){

            StringBuilder sb = new StringBuilder();
            sb.append("UPDATE CI_FA_STEP ");
            sb.append("SET MR_ID = :mrId ");
            sb.append("WHERE FA_ID = :faId ");
            sb.append("AND FA_STEP_TY_ACT_FLG = :stepType  ");
            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement ps = createPreparedStatement(sb.toString());
            PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            ps.bindId("mrId", mrId);
            ps.bindId("faId", faId);
            ps.bindLookup("stepType", FieldActivityStepTypeActionLookup.constants.READ_METER);
            ps.executeUpdate();

            ps.close();
        }      

        private List<SQLResultRow> retrieveSASPToLinkFA(ServicePoint_Id spId) {

            StringBuilder retrieveSASPToLinkFAString = new StringBuilder();
            retrieveSASPToLinkFAString.append(" SELECT SS.SA_SP_ID,  SSF.FA_ID, SA.SA_STATUS_FLG ");
            retrieveSASPToLinkFAString.append(" FROM CI_SA_SP_FA SSF, CI_SA SA, CI_SA_SP SS ");
            retrieveSASPToLinkFAString.append(" WHERE SS.SP_ID = :spId ");
            retrieveSASPToLinkFAString.append(" AND SS.SA_ID = SA.SA_ID ");
            retrieveSASPToLinkFAString.append(" AND SA.SA_ID = SSF.SA_ID(+) ");
            retrieveSASPToLinkFAString.append(" AND ((:processDateTime between SS.START_DTTM AND SS.STOP_DTTM) OR (SS.STOP_DTTM IS NULL)) ");

            //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            //PreparedStatement retrieveSASPToLinkFAPrepStmt = createPreparedStatement(retrieveSASPToLinkFAString.toString());
            PreparedStatement retrieveSASPToLinkFAPrepStmt = createPreparedStatement(retrieveSASPToLinkFAString.toString(), getClass().getName());
            //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
            retrieveSASPToLinkFAPrepStmt.bindId("spId", spId);
            retrieveSASPToLinkFAPrepStmt.bindDateTime("processDateTime", getProcessDateTime());
            List<SQLResultRow> resultList = retrieveSASPToLinkFAPrepStmt.list();

            retrieveSASPToLinkFAPrepStmt.close();

            return resultList;

        }

        private void linkFAtoSASP(FieldActivity fa, ServiceAgreementSpFaTypeLookup saSpFaLookup, ServiceAgreementServicePoint sasp,ServicePoint_Id spId){

            try{

                ServiceAgreementSpFieldActivity_Id saSpFieldActivityId = new ServiceAgreementSpFieldActivity_Id(sasp,fa);
                ServiceAgreementSpFieldActivity_DTO saSpFieldActivityDto = (ServiceAgreementSpFieldActivity_DTO)createDTO(ServiceAgreementSpFieldActivity.class); 
                saSpFieldActivityDto.setId(saSpFieldActivityId);
                saSpFieldActivityDto.setFieldActivityType(saSpFaLookup);
                saSpFieldActivityDto.setServiceAgreementId(sasp.getServiceAgreement().getId());
                saSpFieldActivityDto.setServicePointId(spId);
                saSpFieldActivityDto.newEntity();
            }catch(ApplicationError e){
                String msg=e.getServerMessage().getMessageText();
                addError(CustomMessageRepository.nm0049ApplicationError(msg));
            }
        }
        
		/* IM-035909 - Duplicate Read Issue
		 * 
		 * Retrieve Meter Read for the given Meter Config and FA Sched Date
		 * @param MeterConfiguration_Id,DateTime
		 * @return MeterRead_Id
		 */
		
		private MeterRead_Id rerieveUsableMeterRead(MeterConfiguration_Id mtrConfigId,DateTime schedDate){
			MeterRead_Id mrId = null;
			StringBuilder meterReadQuery = new StringBuilder();
			meterReadQuery.append(" SELECT MR_ID FROM CI_MR ");
			meterReadQuery.append(" WHERE MTR_CONFIG_ID = :meterConfigId ");
			meterReadQuery.append(" AND TRUNC(READ_DTTM) = :faSchedDate ");
			meterReadQuery.append(" AND USE_ON_BILL_SW = 'Y' ");
			meterReadQuery.append(" ORDER BY READ_DTTM DESC ");
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			//PreparedStatement meterReadPrepStmt = createPreparedStatement(meterReadQuery.toString());
			PreparedStatement meterReadPrepStmt = createPreparedStatement(meterReadQuery.toString(), getClass().getName());
			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			meterReadPrepStmt.bindId("meterConfigId", mtrConfigId);
			meterReadPrepStmt.bindDate("faSchedDate", schedDate.getDate());
						
			SQLResultRow resultRow = meterReadPrepStmt.firstRow();
			if(notNull(resultRow)){
				mrId = (MeterRead_Id)resultRow.getId("MR_ID", MeterRead.class);
			}
			meterReadPrepStmt.close();
			return mrId;
		}
			
		private MeterRead_Id retrieveRecentMeterRead(MeterConfiguration_Id mtrConfigId,DateTime schedDate){
			MeterRead_Id mrId = null;
			StringBuilder meterReadQuery = new StringBuilder();
			meterReadQuery.append(" SELECT MR_ID FROM CI_MR ");
			meterReadQuery.append(" WHERE MTR_CONFIG_ID = :meterConfigId ");
			meterReadQuery.append(" AND TRUNC(READ_DTTM) <= :faSchedDate ");
			meterReadQuery.append(" AND USE_ON_BILL_SW = 'Y' ");
			meterReadQuery.append(" ORDER BY READ_DTTM DESC ");
			//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			//PreparedStatement meterReadPrepStmt = createPreparedStatement(meterReadQuery.toString());
			PreparedStatement meterReadPrepStmt = createPreparedStatement(meterReadQuery.toString(), getClass().getName());
			//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
			meterReadPrepStmt.bindId("meterConfigId", mtrConfigId);
			meterReadPrepStmt.bindDate("faSchedDate", schedDate.getDate());
						
			SQLResultRow resultRow = meterReadPrepStmt.firstRow();
			if(notNull(resultRow)){
				mrId = (MeterRead_Id)resultRow.getId("MR_ID", MeterRead.class);
			}
			meterReadPrepStmt.close();
			return mrId;
		}
		
		private Boolean isStopFa(FieldActivity_Id fa, ServicePoint_Id sp){
			String queryStr = (" SELECT FA_ID FROM CI_SA_SP_FA WHERE FA_ID = :faId "
					+ "AND SP_ID = :spId AND SA_SP_FA_TYPE_FLG = :stopFlg");
			PreparedStatement qrySttmt = createPreparedStatement(queryStr, "isStopFa Qry");
			qrySttmt.bindId("faId", fa);
			qrySttmt.bindId("spId", sp);
			qrySttmt.bindLookup("stopFlg", ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
			SQLResultRow resultRow = qrySttmt.firstRow();
			if(notNull(resultRow))
				return true;
			return false;
		}
		

        private Boolean isStartStopFa(FieldActivity_Id fa, ServicePoint_Id sp){
			String queryStr = (" SELECT FA_ID FROM CI_SA_SP_FA WHERE FA_ID = :faId "
					+ "AND SP_ID = :spId AND SA_SP_FA_TYPE_FLG = :stopFlg");
			PreparedStatement qrySttmt = createPreparedStatement(queryStr, "isStopFa Qry");
			qrySttmt.bindId("faId", fa);
			qrySttmt.bindId("spId", sp);
			qrySttmt.bindLookup("stopFlg", ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
			SQLResultRow resultRow = qrySttmt.firstRow();
			if(notNull(resultRow)){

			    String queryStrStart = (" SELECT FA_ID FROM CI_SA_SP_FA WHERE FA_ID = :faId "
					    + "AND SP_ID = :spId AND SA_SP_FA_TYPE_FLG = :startFlg");
			    PreparedStatement qrySttmtStart = createPreparedStatement(queryStrStart, "isStartFa Qry");
			    qrySttmtStart.bindId("faId", fa);
			    qrySttmtStart.bindId("spId", sp);
			    qrySttmtStart.bindLookup("startFlg", ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
			    SQLResultRow resultRowStart = qrySttmtStart.firstRow();
                if(notNull(resultRowStart)) {
				    return true;
                }
			}    
			return false;
		}

		public MeterRead createADDPOutboundMessageAndRead(String serialNumber, String badgeNumber, DateTime scheduleDate,
				FieldActivity_Id fieldActivityId, MeterConfiguration_Id meterConfigId){
			MeterRead meterRead = null;
			ServiceScriptInstance serviceScriptInstance = null;
    		COTSInstanceNode scriptInput = null;
    		COTSInstanceNode scriptOutput = null;
			serviceScriptInstance = ServiceScriptInstance.create(CM_ADDPREAD); 	
    		// Retrieve the script's input node
    		scriptInput = serviceScriptInstance.getGroup(GROUP_INPUT);
    		
    		scriptInput.set("meterAssetNumber", serialNumber);
    		scriptInput.set("meterBadgeNumber", badgeNumber);
    		scriptInput.set("readDateStart",scheduleDate.getDate());
    		scriptInput.set("readDateEnd",scheduleDate.getDate());
    		scriptInput.set("readTime",parmADDPReadTime.toString().trim());
			
			try{
				ServiceScriptDispatcher.invoke(serviceScriptInstance);	
			} catch (ApplicationError e){
				e.getServerMessage();
			}
			 //it can be added to the FA later if needed
			scriptOutput = serviceScriptInstance.getGroup(GROUP_OUTPUT);
			String outboundMessageId = scriptOutput.getString("outboundMsgId");
			String errorMessage = null;
			String correctedIndexRead_str = null;
			correctedIndexRead_str  = scriptOutput.getString("correctedIndex");
			errorMessage = scriptOutput.getString("errorMessage");

			if(errorMessage == null)
			{				
				// logger.info("correctedIndexRead");
				// logger.info(correctedIndexRead_str);
				// Start Add - DLampa - 2024-02-27 - INC0025094.2
				if (!isBlankOrNull(correctedIndexRead_str)) {
				// End Add - DLampa - 2024-02-27 - INC0025094.2
				    MeterReadSource mrSourceFromADDP = new MeterReadSource_Id("ADDP").getEntity();
				    meterRead= createMeterReadADDP(meterConfigId,mrSourceFromADDP,correctedIndexRead_str,fieldActivityId,scheduleDate);
				// Start Add - DLampa - 2024-02-27 - INC0025094.2
				}
				else {
	                createTODO(fieldActivityId);
	                logError(CustomMessageRepository.nm0049CannotCreateMeterRead(fieldActivityId.getIdValue().trim()));
				}
				// End Add - DLampa - 2024-02-27 - INC0025094.2
			}
            else
            {	
				errorMessage = "Response from ADDP : " + errorMessage + " FA ID : " + fieldActivityId.getIdValue().trim() + " Outbound Message :" + outboundMessageId;
				ServerMessage serverMsg = CustomMessageRepositorySpireOne.CCB011_applicationError(errorMessage);
				
            	addError(serverMsg);
            }
			return meterRead;
		}	
		
		private Boolean checkDateChar(FieldActivity fa){
			Date faCharDate = null;
			ListFilter<FieldActivityCharacteristic> faCharFilter = fa.getCharacteristics().createFilter("where this.id.characteristicType = :charType","FA Char Filter");
			faCharFilter.bindEntity("charType", parmFaCharType);
			FieldActivityCharacteristic faChar= faCharFilter.firstRow();
			if(notNull(faChar)){
				try{
					faCharDate = dateFormat.parseDate(faChar.getAdhocCharacteristicValue());
				}
				catch(Exception e){
					addError(CustomMessageRepositorySpireOne.
    						CCB022_errorInParsingCharacteristicValueAsDate(parmFaCharType.getId().getTrimmedValue(),
    								fa.getId().getIdValue()));
				}
				if(getProcessDateTime().getDate().isBefore(faCharDate))
					return false;
			}
			return true;
		}
    }
}
