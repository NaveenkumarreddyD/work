/*
 **************************************************************************
 *                Confidentiality Information:                    
 *                                                                
 * This module is the confidential and proprietary information of 
 * Oracle Corporation; it is not to be copied, reproduced, or         
 * transmitted in any form, by any means, in whole or in part,    
 * nor is it to be used for any purpose other than that for which 
 * it is expressly provided without the written permission of     
 * Oracle Corporation.                                                
 *                                                                
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Extract Letters Batch
 * 
 * This batch process creates an output file with rate information, using 
 * Bill Factor Values for selected tax rate components to be passed to  
 * GRT. 
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2012-11-06   BCordo  NI006.1. Initial Version.   
 * 2013-04-23   CVB     Modified to allow multiple Bill Factors
 *                      defined on the Feature Configuration.     
 * 2013-05-13   CVB     Put in quotes the headers.
 * 2013-09-12   JPunza  Modified to change EDATE from system date to bill 
 *                      factor value's effective date.
 * 2013-09-26   JPunza  Modified to set EDATE to blank if no bill factor
 *                      value retrieved.   
 * 2013-10-02   CVB     Modified to use the Bill Factor Characteristic as the
 *                      main table for deriving Town Codes.                                                               
 * 2014-10-13	DHuynh	MGE-CCB007
 * 						-Modify to add 2 new columns to ouput file
 * 						(GRTINDBS and GRTOTHBS)      
 * 2016-01-29  	MPang	Updated for CCB v2.4 compilation.                                                
 **************************************************************************
 */
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.ibm.icu.text.DecimalFormat;
import com.splwg.base.api.Query;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ValueTypeLookup;
//JPunza - 2013-09-12 - Start
//import com.splwg.ccb.domain.admin.billFactor.BillFactor;
//import com.splwg.ccb.domain.admin.billFactor.BillFactor_Id;
//JPunza - 2013-09-12 - End
import com.splwg.cm.api.lookup.CmGrtBillFactorLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author 95223
 *
 @BatchJob (multiThreaded = false, rerunnable = false, modules={},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = TOWNCODE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = FTR_NAME, required = true, type = entity)})
 */
public class CmGRTRateExtractBatch extends CmGRTRateExtractBatch_Gen {

	// Local Constants
	private static final String FILE_PATH = "File Path";
	private static final String FILE_NAME = "File Name";
	private static final String TOWN_CODE = "Town Code";
	private static final String MMDDYY = "MMDDYY";

	@Override
	public void validateSoftParameters(boolean arg0) {
		// Validate Parameter File Path
		File tempPathFolder = new File(getParameters().getFILE_PATH());

		if (!tempPathFolder.isDirectory()){
			addError(CustomMessageRepositoryMDC.commBatchParmFilePathInvalid(this.getBatchControlId().getIdValue()
					.trim(), FILE_PATH, getParameters().getFILE_PATH()));
		}         

		// Validate that Town Code characteristic Type is valid for Bill Factor Entity
		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(getParameters()
				.getTOWNCODE(), CharacteristicEntityLookup.constants.BILL_FACTOR);
		if (isNull(charEntityId.getEntity())) {
			addError(CustomMessageRepositoryMDC.commBatchParmCharTypeInvalid(this.getBatchControlId().getIdValue()
					.trim(), TOWN_CODE, getParameters().getTOWNCODE().getId().getIdValue().trim(), CharacteristicEntityLookup
					.constants.BILL_FACTOR.getLookupValue().fetchLanguageDescription()));
		}

		// Validate that file name batch parameter contains explicit string 'MMDDYY'
		if (!getParameters().getFILE_NAME().contains(MMDDYY)){
			addError(CustomMessageRepositoryMDC.commBatchParmFileNameInvalid(this.getBatchControlId().getIdValue()
					.trim(), FILE_NAME, getParameters().getFILE_NAME()));                
		}
	}

	public JobWork getJobWork() {
		// Create Dummy Job Work
		List<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
		arrayList.add(threadWorkUnit);
		return createJobWorkForThreadWorkUnitList(arrayList);
	}

	public Class<CmGRTRateExtractBatchWorker> getThreadWorkerClass() {
		return CmGRTRateExtractBatchWorker.class;
	}

	public static class CmGRTRateExtractBatchWorker 
	extends CmGRTRateExtractBatchWorker_Gen {

		// Local Constants
		private static final String MMDDYY = "MMDDYY";
		// Start Change - DHuynh - 2014-10-13 - MGE-CCB007
		//private static final String FILE_HEADER = "\"TOWNCODE\",\"EDATE\",\"SALERES\",\"SALECOM\",\"GRTRESBS\",\"GRTCOMBS\",\"GRTRESR\",\"GRTCOMR\"";
		private static final String FILE_HEADER = "\"TOWNCODE\",\"EDATE\",\"SALERES\",\"SALECOM\",\"GRTRESBS\",\"GRTCOMBS\",\"GRTRESR\",\"GRTCOMR\",\"GRTINDBS\",\"GRTOTHBS\"";	
		// End Change - DHuynh - 2014-10-13 - MGE-CCB007
		private static final String DELIMETER = ",";
		private static final String QUOTE_MARK = "\"";

		// Local Variables
		private String filePath;
		private String fileName;
		private FeatureConfiguration grtBillFactorFeatConfig;
		private CharacteristicType townCodeCharType;
		// JPunza - 2013-09-12 - Start
		//private BillFactor resSalesBillFactor;
		//private BillFactor comSalesBillFactor;
		//private BillFactor resGrossReceiptsTaxBasicBillFactor;
		//private BillFactor comGrossReceiptsTaxBasicBillFactor;
		//private BillFactor resGrossReceiptsTaxRefundBillFactor;
		//private BillFactor comGrossReceiptsTaxRefundBillFactor;
		private String resSalesBillFactorValue;
		private String comSalesBillFactorValue;
		private String resGrossReceiptsTaxBasicBillFactorValue;
		private String comGrossReceiptsTaxBasicBillFactorValue;
		private String resGrossReceiptsTaxRefundBillFactorValue;
		private String comGrossReceiptsTaxRefundBillFactorValue;        
		// Start Add - DHuynh - 2014-10-13 - MGE-CCB007 
		private String industGrossReceiptsTaxRefundBillFactorValue;
		private String otherGrossReceiptsTaxRefundBillFactorValue;
		// End Add - DHuynh - 2014-10-13 - MGE-CCB007
		// JPunza - 2013-09-12 - End
		private Date eDate;
		private BufferedWriter bufferedWriter;

		// CVB - 2013-04-23 - Start

		private int recordsProcessed;
		private int recordsInError;
		// JPunza - 2013-09-12 - Start
		//private BillFactor billFactor;
		// JPunza - 2013-09-12 - End
		private CmGrtBillFactorLookup resSalesBillFactorLookup;
		private CmGrtBillFactorLookup comSalesBillFactorLookup;
		private CmGrtBillFactorLookup resGrossReceiptsTaxBasicBillFactorLookup;
		private CmGrtBillFactorLookup comGrossReceiptsTaxBasicBillFactorLookup;
		private CmGrtBillFactorLookup resGrossReceiptsTaxRefundBillFactorLookup;
		private CmGrtBillFactorLookup comGrossReceiptsTaxRefundBillFactorLookup;
		// Start Add - DHuynh - 2014-10-13 - MGE-CCB007
		private CmGrtBillFactorLookup industGrossReceiptsTaxRefundBillFactorLookup;
		private CmGrtBillFactorLookup otherGrossReceiptsTaxRefundBillFactorLookup;
		// End Add - DHuynh - 2014-10-13 - MGE-CCB007
		
		// CVB - 2013-04-23 - End

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
			// Retrieve batch parameters
			retrieveParameters();

			eDate = this.getProcessDateTime().getDate();

			fileName = fileName.replace(MMDDYY, eDate.toString(new DateFormat("MMddyy")));

			// Retrieve the corresponding Bill Factors from Feature Configuration

			// CVB - 2013-04-23 - Start

			// retrieveBillFactorFromFeatConfig();
			recordsProcessed = 0;
			recordsInError = 0;

			// CVB - 2013-04-23 - End

			// Open the file
			try {
				File extractFile = new File(filePath, fileName);
				bufferedWriter = new BufferedWriter(new FileWriter(extractFile));
			}
			catch (Exception e) {
				e.printStackTrace();
				addError(CustomMessageRepositoryMDC.commBatchFileOpenError(this.getBatchControlId().getIdValue().trim()));                
			}
		}

		// CVB - 2013-04-23 - Start
		// public boolean executeWorkUnit(ThreadWorkUnit unit)
		// throws ThreadAbortedException, RunAbortedException {
		//     // Write the standard header for the output file
		//     writeHeader();
		// 
		//     // Extract and write the GRT Rates
		//     extractGrtRates();
		// 
		//     return true;
		// }


		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
		throws ThreadAbortedException, RunAbortedException {

			// Write the standard header for the output file
			writeHeader();

			// Extract and write the GRT Rates
			extractGrtRates();

			WorkUnitResult results = new WorkUnitResult(true);
			results.setUnitsInError(recordsInError);
			results.setUnitsProcessed(recordsProcessed);
			return results;
		}

		// CVB - 2013-04-23 - End

		/*
		 * Retrieve the Batch parameters
		 */
		private void retrieveParameters(){    
			filePath = getParameters().getFILE_PATH();
			townCodeCharType = getParameters().getTOWNCODE();
			fileName = getParameters().getFILE_NAME();
			grtBillFactorFeatConfig = getParameters().getFTR_NAME();
		}

//		JPunza - 2013-09-12 - Start
//		/*
//		* This method retrieves the corresponding Bill Factors from Feature Configuration
//		*/
//		private void retrieveBillFactorFromFeatConfig(){

//		// Retrieve the Residential Sales Tax Bill Factor from Feature Configuration
//		resSalesBillFactor = retrieveFeatureOptionValue(CmGrtBillFactorLookup.constants
//		.RESIDENTIAL_SALES_TAX_BF).getEntity();

//		// Retrieve the Commercial Sales Tax Bill factor from Feature Configuration
//		comSalesBillFactor = retrieveFeatureOptionValue(CmGrtBillFactorLookup.constants
//		.COMMERCIAL_SALES_TAX_BF).getEntity();

//		// Retrieve the Residential Gross Receipts Tax Basic Bill Factor from Feature Configuration
//		resGrossReceiptsTaxBasicBillFactor = retrieveFeatureOptionValue(CmGrtBillFactorLookup.constants
//		.RESIDENTIAL_GROSS_RECEIPTS_TAX_BASIC_BF).getEntity();

//		// Retrieve the Commercial Gross Receipts Tax Basic Bill Factor from Feature Configuration
//		comGrossReceiptsTaxBasicBillFactor = retrieveFeatureOptionValue(CmGrtBillFactorLookup.constants
//		.COMMERCIAL_GROSS_RECEIPTS_TAX_BASIC_BF).getEntity();

//		// Retrieve the Residential Gross Receipts Tax Refund Bill Factor from Feature Configuration
//		resGrossReceiptsTaxRefundBillFactor = retrieveFeatureOptionValue(CmGrtBillFactorLookup.constants
//		.RESIDENTIAL_GROSS_RECEIPTS_TAX_REFUND_BF).getEntity();


//		// Retrieve the Commercial Gross Receipts Tax Refund Bill Factor from Feature Configuration
//		comGrossReceiptsTaxRefundBillFactor = retrieveFeatureOptionValue(CmGrtBillFactorLookup.constants
//		.COMMERCIAL_GROSS_RECEIPTS_TAX_REFUND_BF).getEntity();
//		}
//		JPunza - 2013-09-12 - End

		/*
		 * This method writes the output file header
		 */
		private void writeHeader(){            
			try {
				bufferedWriter.write(FILE_HEADER);
				bufferedWriter.newLine();
			}
			catch (Exception e) {
				e.printStackTrace(); 
				addError(CustomMessageRepositoryMDC.commBatchFileWriteError(this.getBatchControlId().getIdValue().trim()));
			}
		}

		/*
		 * This method extracts and process the GRT rates
		 */
		private void extractGrtRates(){
			// Retrieve the characteristic values of the Town Code Characteristic Type
			Iterator townCodeCharValIter = retrieveTownCodeCharVal().list().iterator();

			// CVB - 2013-04-23 - Start

			resSalesBillFactorLookup = CmGrtBillFactorLookup.constants.RESIDENTIAL_SALES_TAX_BF;
			comSalesBillFactorLookup = CmGrtBillFactorLookup.constants.COMMERCIAL_SALES_TAX_BF;
			resGrossReceiptsTaxBasicBillFactorLookup = CmGrtBillFactorLookup.constants.RESIDENTIAL_GROSS_RECEIPTS_TAX_BASIC_BF;
			comGrossReceiptsTaxBasicBillFactorLookup = CmGrtBillFactorLookup.constants.COMMERCIAL_GROSS_RECEIPTS_TAX_BASIC_BF;
			resGrossReceiptsTaxRefundBillFactorLookup = CmGrtBillFactorLookup.constants.RESIDENTIAL_GROSS_RECEIPTS_TAX_REFUND_BF;
			comGrossReceiptsTaxRefundBillFactorLookup = CmGrtBillFactorLookup.constants.COMMERCIAL_GROSS_RECEIPTS_TAX_REFUND_BF;
			// Start Add - DHuynh - 2014-10-13 - MGE-CCB007
			industGrossReceiptsTaxRefundBillFactorLookup = CmGrtBillFactorLookup.constants.INDUSTRIAL_GROSS_RECEIPTS_TAX_BASIC_BF;
			otherGrossReceiptsTaxRefundBillFactorLookup = CmGrtBillFactorLookup.constants.OTHER_GROSS_RECEIPTS_TAX_BASIC_BF;
			// End Add - DHuynh - 2014-10-13 - MGE-CCB007				
			// CVB - 2013-04-23 - End

			// For each Value extracted, write the corresponding output record
			while(townCodeCharValIter.hasNext()){

				StringBuffer extractLine = new StringBuffer();
				String townCodeValue = (String) townCodeCharValIter.next();

				// JPunza - 2013-09-12 - Start
				eDate = null;

				resSalesBillFactorValue = extractBillFactorValue(resSalesBillFactorLookup, townCodeValue).trim();
				comSalesBillFactorValue = extractBillFactorValue(comSalesBillFactorLookup, townCodeValue).trim();
				resGrossReceiptsTaxBasicBillFactorValue = extractBillFactorValue(resGrossReceiptsTaxBasicBillFactorLookup, townCodeValue).trim();
				comGrossReceiptsTaxBasicBillFactorValue = extractBillFactorValue(comGrossReceiptsTaxBasicBillFactorLookup, townCodeValue).trim();
				resGrossReceiptsTaxRefundBillFactorValue = extractBillFactorValue(resGrossReceiptsTaxRefundBillFactorLookup, townCodeValue).trim();
				comGrossReceiptsTaxRefundBillFactorValue = extractBillFactorValue(comGrossReceiptsTaxRefundBillFactorLookup, townCodeValue).trim();
				// Start Add - DHuynh - 2014-10-13 - MGE-CCB007
				industGrossReceiptsTaxRefundBillFactorValue = extractBillFactorValue(industGrossReceiptsTaxRefundBillFactorLookup, townCodeValue).trim();
				otherGrossReceiptsTaxRefundBillFactorValue = extractBillFactorValue(otherGrossReceiptsTaxRefundBillFactorLookup, townCodeValue).trim();
				// End Add - DHuynh - 2014-10-13 - MGE-CCB007
				// JPunza - 2013-09-12 - End

				// CVB - 2013-05-13 - Start
				// String towncCodeString = townCodeValue.trim() + DELIMETER + QUOTE_MARK + eDate.toString(new DateFormat("yyyyMMdd")) + QUOTE_MARK;
				// JPunza - 2013-09-26 - Start
				//String towncCodeString = QUOTE_MARK + townCodeValue.trim() + QUOTE_MARK + DELIMETER + QUOTE_MARK + eDate.toString(new DateFormat("yyyyMMdd")) + QUOTE_MARK;
				String towncCodeString = QUOTE_MARK + townCodeValue.trim() + QUOTE_MARK + DELIMETER + QUOTE_MARK;
				if (notNull(eDate)) {
					towncCodeString = towncCodeString + eDate.toString(new DateFormat("yyyyMMdd")) + QUOTE_MARK;
				}
				else {
					towncCodeString = towncCodeString + QUOTE_MARK;                    
				}
				// JPunza - 2013-09-26 - End
				// CVB - 2013-05-13 - End
				extractLine.append(towncCodeString.trim());

				// CVB - 2013-04-23 - Start

				// extractLine.append(extractBillFactorValue(resSalesBillFactor, townCodeValue).trim());
				// extractLine.append(extractBillFactorValue(comSalesBillFactor, townCodeValue).trim());
				// extractLine.append(extractBillFactorValue(resGrossReceiptsTaxBasicBillFactor, townCodeValue).trim());
				// extractLine.append(extractBillFactorValue(comGrossReceiptsTaxBasicBillFactor, townCodeValue).trim());
				// extractLine.append(extractBillFactorValue(resGrossReceiptsTaxRefundBillFactor, townCodeValue).trim());
				// extractLine.append(extractBillFactorValue(comGrossReceiptsTaxRefundBillFactor, townCodeValue).trim());
				// JPunza - 2013-09-12 - Start
				//extractLine.append(extractBillFactorValue(resSalesBillFactorLookup, townCodeValue).trim());
				//extractLine.append(extractBillFactorValue(comSalesBillFactorLookup, townCodeValue).trim());
				//extractLine.append(extractBillFactorValue(resGrossReceiptsTaxBasicBillFactorLookup, townCodeValue).trim());
				//extractLine.append(extractBillFactorValue(comGrossReceiptsTaxBasicBillFactorLookup, townCodeValue).trim());
				//extractLine.append(extractBillFactorValue(resGrossReceiptsTaxRefundBillFactorLookup, townCodeValue).trim());
				//extractLine.append(extractBillFactorValue(comGrossReceiptsTaxRefundBillFactorLookup, townCodeValue).trim());
				extractLine.append(resSalesBillFactorValue);
				extractLine.append(comSalesBillFactorValue);
				extractLine.append(resGrossReceiptsTaxBasicBillFactorValue);
				extractLine.append(comGrossReceiptsTaxBasicBillFactorValue);
				extractLine.append(resGrossReceiptsTaxRefundBillFactorValue);
				extractLine.append(comGrossReceiptsTaxRefundBillFactorValue);
				// Start Add - DHuynh - 2014-10-13 - MGE-CCB007
				extractLine.append(industGrossReceiptsTaxRefundBillFactorValue);
				extractLine.append(otherGrossReceiptsTaxRefundBillFactorValue);
				// End Add - DHuynh - 2014-10-13 - MGE-CCB007
				// JPunza - 2013-09-12 - End
				recordsProcessed++;

				// CVB - 2013-04-23 - End

				try {
					bufferedWriter.write(extractLine.toString().trim());
					bufferedWriter.newLine();
				}
				catch (Exception e) {
					e.printStackTrace();
					addError(CustomMessageRepositoryMDC.commBatchFileWriteError(this.getBatchControlId().getIdValue().trim()));                
				}
			}          
		}

		/*
		 * This method retrieves the corresponding Bill Factor Value and formats the actual field to be written
		 */
		// CVB - 2013-04-23 - Start
		// private String extractBillFactorValue(BillFactor bf, String charValue){
		private String extractBillFactorValue(CmGrtBillFactorLookup lookupVal, String charValue){
			// CVB - 2013-04-23 - End

			// Output format should be in '.nnnnn' format
			String billFactorValue = "";
			String stringFormat = "%1$6s";
			DecimalFormat decimalFormat = new DecimalFormat(".00000");

			// CVB - 2013-04-23 - Start

			// BigDecimal bfVal = retrieveBillFactorValue(bf, charValue);

			BigDecimal bfVal = retrieveMostEffectiveBFValue(lookupVal, charValue);

			// CVB - 2013-04-23 - End

			// CVB - 2013-05-03 - Start
			// Remove this validation

			//// Raise an error if retrieved bill factor value is not less than 1
			//if (bfVal.compareTo(BigDecimal.ONE) >= 0) {
			//    addError(CustomMessageRepositoryMDC.ni006_1BfValNotLessThanOne(this.getBatchControlId().getIdValue().trim(),
			//            // CVB - 2013-04-23 - Start
			//            
			//            // bfVal.toString().trim(), bf.getId().getIdValue().trim(), charValue.trim()));
			//            bfVal.toString().trim(), billFactor.getId().getIdValue().trim(), charValue.trim()));
			//    
			//    // CVB - 2013-04-23 - End
			//}

			// CVB - 2013-05-03 - End

			if (bfVal.compareTo(BigDecimal.ZERO) == 0){
				billFactorValue = ",\".00000\"";
			}
			else {
				String strBfVal = String.format(stringFormat, decimalFormat.format(bfVal));
				billFactorValue = DELIMETER + QUOTE_MARK + strBfVal + QUOTE_MARK;
			}          

			return billFactorValue; 
		}

//		JPunza - 2013-09-12 - Start
//		/*
//		* Query to retrieve the Bill Factor value
//		*/
//		private BigDecimal retrieveBillFactorValue(BillFactor bf, String charValue){

//		BigDecimal billFactorValue = BigDecimal.ZERO;

//		Query retrieveBillFactorValue = createQuery("from BillFactorValue BFV"
//		+ " where BFV.id.billFactorCharacteristic.id.billFactor = :bfCd"
//		+ " and BFV.id.billFactorCharacteristic.id.characteristicValue.id.characteristicType = :charTypeCd"
//		+ " and BFV.id.billFactorCharacteristic.id.characteristicValue.id.characteristicValue = :charVal"
//		+ " and BFV.id.touGroup = ' '"
//		+ " and BFV.id.effectiveDate ="
//		+ " (select MAX(BFV2.id.effectiveDate)"
//		+ " from BillFactorValue BFV2"
//		+ " where BFV2.id.billFactorCharacteristic.id.billFactor = BFV.id.billFactorCharacteristic.id.billFactor"
//		+ " and BFV2.id.billFactorCharacteristic.id.characteristicValue.id.characteristicType =" 
//		+ " BFV.id.billFactorCharacteristic.id.characteristicValue.id.characteristicType"
//		+ " and BFV2.id.billFactorCharacteristic.id.characteristicValue.id.characteristicValue =" 
//		+ " BFV.id.billFactorCharacteristic.id.characteristicValue.id.characteristicValue"
//		+ " and BFV2.id.touGroup = BFV.id.touGroup"
//		+ " and BFV2.id.effectiveDate <= :effdt)");

//		retrieveBillFactorValue.bindEntity("bfCd", bf);
//		retrieveBillFactorValue.bindEntity("charTypeCd", townCodeCharType);
//		retrieveBillFactorValue.bindStringProperty("charVal", CharacteristicValue.properties.characteristicValue, charValue);
//		retrieveBillFactorValue.bindDate("effdt", this.getProcessDateTime().getDate());
//		retrieveBillFactorValue.addResult("bfVal", "BFV.value");

//		if (retrieveBillFactorValue.listSize() > 0) {
//		billFactorValue = (BigDecimal) retrieveBillFactorValue.firstRow();
//		}            

//		return billFactorValue;          
//		}
//		JPunza - 2013-09-12 - End        

		/*
		 * Query to retrieve the Town Code Characteristic Value
		 */
		private Query retrieveTownCodeCharVal(){
			// CVB - 2013-10-02 - Start
			// Query retrieveTownCodeCharVal = createQuery("from CharacteristicValue CH"
			//         + " where CH.id.characteristicType = :charTypeCd");
			Query retrieveTownCodeCharVal = createQuery("from BillFactorCharacteristic BFCH"
					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					//+ " where BFCH.id.characteristicValue.id.characteristicType = :charTypeCd");
					+ " where BFCH.id.characteristicValue.id.characteristicType = :charTypeCd", getClass().getName());
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			// CVB - 2013-10-02 - End

			retrieveTownCodeCharVal.bindEntity("charTypeCd", townCodeCharType);


			// CVB - 2013-10-02 - Start
			//  retrieveTownCodeCharVal.addResult("charVal", "CH.id.characteristicValue");
			retrieveTownCodeCharVal.addResult("charVal", "BFCH.id.characteristicValue.id.characteristicValue");
			retrieveTownCodeCharVal.orderBy("charVal", Query.ASCENDING);
			retrieveTownCodeCharVal.selectDistinct(true);
			// CVB - 2013-10-02 - End

			return retrieveTownCodeCharVal;           
		}

//		JPunza - 2013-09-12 - Start
//		/*
//		* Query to retrieve and validate the corresponding Bill Factor from Feature Configuration
//		*/
//		private BillFactor_Id retrieveFeatureOptionValue(CmGrtBillFactorLookup lookupVal){
//		Query retrieveFeatureOptionValue = createQuery("from FeatureConfigurationOption FC"
//		+ " where FC.id.workforceManagementSystem = :wfmName"
//		+ " and FC.id.optionType = :extOptType");

//		retrieveFeatureOptionValue.bindId("wfmName", grtBillFactorFeatConfig.getId());
//		retrieveFeatureOptionValue.bindStringProperty("extOptType", FeatureConfigurationOption.properties.optionType
//		, lookupVal.value().trim());
//		retrieveFeatureOptionValue.addResult("optionValue", "FC.value");

//		if (retrieveFeatureOptionValue.listSize() == 0){
//		addError(CustomMessageRepositoryMDC.commBatchFcMissing(this.getBatchControlId().getIdValue()
//		.trim(), grtBillFactorFeatConfig.getId().getIdValue().trim(), lookupVal.getLookupValue()
//		.fetchLanguageDescription()));
//		} 
//		else if (retrieveFeatureOptionValue.listSize() > 1){
//		addError(CustomMessageRepositoryMDC.commBatchFcMultiple(this.getBatchControlId().getIdValue()
//		.trim(), grtBillFactorFeatConfig.getId().getIdValue().trim(), lookupVal.getLookupValue()
//		.fetchLanguageDescription()));
//		}

//		String strBillFactor = (String) retrieveFeatureOptionValue.firstRow();

//		BillFactor_Id bfId = new BillFactor_Id(strBillFactor);

//		if (isNull(bfId.getEntity())){
//		addError(CustomMessageRepositoryMDC.commBatchFcInvalid(this.getBatchControlId().getIdValue()
//		.trim(), grtBillFactorFeatConfig.getId().getIdValue().trim(), lookupVal.getLookupValue()
//		.fetchLanguageDescription().trim(), strBillFactor));
//		}

//		return bfId;
//		}
//		JPunza - 2013-09-12 - End        

		// CVB - 2013-04-23 - Start

		private BigDecimal retrieveMostEffectiveBFValue(CmGrtBillFactorLookup lookupVal, String charValue) {

			BigDecimal billFactorValue = BigDecimal.ZERO;
			ValueTypeLookup valTypeFlag = null;

			StringBuilder strBldr = new StringBuilder();

			strBldr.append(" SELECT BFVAL.VAL                                                        ");
			// JPunza - 2013-09-12 - Start
			//strBldr.append("       ,BFVAL.BF_CD                                                      ");
			strBldr.append("       ,BFVAL.EFFDT                                                      ");
			// JPunza - 2013-09-12 - End
			// CVB - 2013-05-13 - Start
			strBldr.append("       ,BF.VAL_TYPE_FLG                                                  ");
			// CVB - 2013-05-13 - End
			strBldr.append("   FROM CI_BF_VAL BFVAL                                                  ");
			// CVB - 2013-05-13 - Start
			strBldr.append("       ,CI_BF BF                                                         ");
			// CVB - 2013-05-13 - End
			strBldr.append("  WHERE TRIM(BFVAL.BF_CD) IN (SELECT TRIM(WFMOPT.WFM_OPT_VAL)            ");
			strBldr.append("                                FROM CI_WFM_OPT WFMOPT                   ");
			strBldr.append("                               WHERE WFMOPT.WFM_NAME = :featureCfg       ");
			strBldr.append("                                 AND WFMOPT.EXT_OPT_TYPE = :extOptType)  ");
			strBldr.append("    AND BFVAL.CHAR_TYPE_CD = :townCodeCharType                           ");
			strBldr.append("    AND BFVAL.CHAR_VAL = :townCodeCharValue                              ");
			strBldr.append("    AND BFVAL.TOU_GRP_CD = ' '                                           ");
			strBldr.append("    AND BFVAL.EFFDT = (SELECT MAX(BFVAL2.EFFDT)                          ");
			strBldr.append("                         FROM CI_BF_VAL BFVAL2                           ");
			strBldr.append("                        WHERE BFVAL2.BF_CD = BFVAL.BF_CD                 ");
			strBldr.append("                          AND BFVAL2.CHAR_TYPE_CD = BFVAL.CHAR_TYPE_CD   ");
			strBldr.append("                          AND BFVAL2.CHAR_VAL = BFVAL.CHAR_VAL           ");
			strBldr.append("                          AND BFVAL2.TOU_GRP_CD = BFVAL.TOU_GRP_CD       ");
			strBldr.append("                          AND BFVAL2.EFFDT <= :processDate)              ");
			// CVB - 2013-05-13 - Start
			strBldr.append("    AND BF.BF_CD = BFVAL.BF_CD                                           ");
			// CVB - 2013-05-13 - End
			strBldr.append(" ORDER BY BFVAL.EFFDT DESC                                               ");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement qry = createPreparedStatement(strBldr.toString()); 
			PreparedStatement qry = createPreparedStatement(strBldr.toString(), getClass().getName()); 
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			qry.bindEntity("featureCfg", grtBillFactorFeatConfig);
			qry.bindStringProperty("extOptType", FeatureConfigurationOption.properties.optionType, lookupVal.value().trim());
			qry.bindEntity("townCodeCharType", townCodeCharType);
			qry.bindStringProperty("townCodeCharValue", CharacteristicValue.properties.characteristicValue, charValue);
			qry.bindDate("processDate", this.getProcessDateTime().getDate());

			SQLResultRow row = qry.firstRow();

			if(notNull(row)){
				billFactorValue = row.getBigDecimal("VAL");
				// CVB - 2013-05-13 - Start
				valTypeFlag = row.getLookup("VAL_TYPE_FLG", ValueTypeLookup.class);
				if (valTypeFlag.equals(ValueTypeLookup.constants.PERCENTAGE)) {
					billFactorValue = billFactorValue.divide(BigDecimal.valueOf(100));
				}
				BigDecimal integerValue = new BigDecimal(Math.floor(billFactorValue.doubleValue()));
				billFactorValue = billFactorValue.subtract(integerValue).setScale(5,BigDecimal.ROUND_FLOOR);
				// CVB - 2013-05-13 - End

				// JPunza - 2013-09-12 - Start
				//billFactor = row.getEntity("BF_CD", BillFactor.class);
				Date billValueEffDate =  row.getDate("EFFDT");
				if (isNull(eDate) || eDate.isBefore(billValueEffDate)) {
					eDate = billValueEffDate;
				}
				// JPunza - 2013-09-12 - End
			}

			qry.close();

			return billFactorValue;
		}   

		// CVB - 2013-04-23 - End

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
			// Close the file
			try {
				bufferedWriter.close();
			}
			catch (Exception e) {
				e.printStackTrace();
				addError(CustomMessageRepositoryMDC.commBatchFileCloseError(this.getBatchControlId().getIdValue().trim()));                
			}
		}
	}
}
