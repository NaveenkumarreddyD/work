/* ************************************************************************
 *                Confidentiality Information:
 *
 * This module is the confidential and proprietary information of
 * Oracle Corporation; it is not to be copied, reproduced, or
 * transmitted in any form, by any means, in whole or in part,
 * nor is it to be used for any purpose other than that for which
 * it is expressly provided without the written permission of
 * Oracle Corporation.
 *
 *
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * Data Correction - Maximo vs CC&B - CC&B Changes - Meter Dimension
 *
 * This batch process will process Maximo data corrections for Meter 
 * Dimension.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:        Reason:
 * YYYY-MM-DD   IN         Reason text.
 *
 * 2015-05-14   RKing      Initial Version.
 * 2016-01-29  	MPang	   Updated for CCB v2.4 compilation. 
 ***************************************************************************/
package com.splwg.cm.domain.batch;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.meterread.meter.Meter;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic_DTO;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic_Id;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristics;
import com.splwg.ccb.domain.meterread.meter.Meter_Id;*/
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic_DTO;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic_Id;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristics;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.meter.meter.CmMeterDataLog;
import com.splwg.cm.domain.meter.meter.CmMeterDataLog_DTO;

/**
 * @author 90724
 *
 @BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = maximoErrorDescription, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = meterDimensionCharType, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = meterDimensionCharValLarge, required = true, type = string)
 *            , @BatchJobSoftParameter (name = meterDimensionCharValRegular, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = meterSizeCharType, required = true, type = entity)
 *            })
 */

public class CmMaximoDataCorrectionMeterDimensionBatch
		extends CmMaximoDataCorrectionMeterDimensionBatch_Gen {
	
	// Parameter descriptions.
	private static final String MTR_DIMENSION_CHTY = "Meter Dimension Char Type";
	private static final String MTR_SIZE_CHTY = "Meter Size Char Type";
	private static final String CHAR_VAL_LARGE = "Meter Dimension Large Char Value";
	private static final String CHAR_VAL_REGULAR = "Meter Dimension Regular Char Value";

    public JobWork getJobWork() {
    	
    	// Setup bind variables.
    	String errorDescr = " '" + getParameters().getMaximoErrorDescription().trim() + "' ";
	
		StringBuilder mainQuery =  new StringBuilder();
		mainQuery.append(" SELECT ");
		mainQuery.append("    ER.MTR_ID ");
		mainQuery.append("   ,REF.MTR_DIMENSION ");
		mainQuery.append(" FROM ");
		mainQuery.append("    CM_VALIDATE.CM_VALIDATION_ERROR_METER ER ");
		mainQuery.append("   ,CI_MTR_CHAR CHV ");
		mainQuery.append("   ,CM_MX_MTR_DIMENSION_CROSS_REF REF ");
		mainQuery.append(" WHERE ");
		mainQuery.append("    ER.DESCRIPTION = " + errorDescr);
		mainQuery.append("   AND CHV.MTR_ID = ER.MTR_ID ");
		mainQuery.append("   AND CHV.CHAR_TYPE_CD = :mtrSizeCharType ");
		mainQuery.append("   AND CHV.EFFDT = (SELECT MAX(CHV2.EFFDT) ");
		mainQuery.append("           FROM CI_MTR_CHAR CHV2 ");
		mainQuery.append("           WHERE CHV.CHAR_TYPE_CD = CHV2.CHAR_TYPE_CD ");
		mainQuery.append("              AND CHV.MTR_ID = CHV2.MTR_ID ");
		mainQuery.append("              AND CHV2.EFFDT <= :processDate) ");
		mainQuery.append("   AND TRIM(REF.MTR_SIZE) = TRIM(CHV.CHAR_VAL) ");
		
		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement mainQueryPS = createPreparedStatement(mainQuery.toString());
		PreparedStatement mainQueryPS = createPreparedStatement(mainQuery.toString(), getClass().getName());
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		mainQueryPS.bindEntity("mtrSizeCharType", getParameters().getMeterSizeCharType());
		mainQueryPS.bindDate("processDate", getProcessDateTime().getDate());
		mainQueryPS.execute();
		
		QueryIterator iter = mainQueryPS.iterate();
		
		return createJobWorkForQueryIterator(iter, this);
	}
    
    public ThreadWorkUnit createWorkUnit(QueryResultRow resultRow) {
    	
    	ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        threadWorkUnit.addSupplementalData("mtrId", resultRow.getString("MTR_ID"));    	
        threadWorkUnit.addSupplementalData("newDimension", resultRow.getString("MTR_DIMENSION"));
        return threadWorkUnit;
	}
    
    public void validateSoftParameters(boolean isNewRun) {
    	
    	// Meter dimension char type must be correct char entity.
    	CharacteristicType meterDimensionCharType = getParameters().getMeterDimensionCharType();
    	CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(meterDimensionCharType, CharacteristicEntityLookup.constants.METER);
        if(isNull(charEntityId.getEntity())) {
            addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharTypeForEntity(MTR_DIMENSION_CHTY, 
            		meterDimensionCharType.getId().getIdValue(), 
            		(CharacteristicEntityLookup.constants.METER).trimmedValue()));
        }
        
    	// Char values must be valid.
    	CharacteristicValue_Id chvLarge = new CharacteristicValue_Id(meterDimensionCharType, 
    			getParameters().getMeterDimensionCharValLarge());    	
    	if(isNull(chvLarge.getEntity())) {
            addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharValueForCharType(
            		CHAR_VAL_LARGE, 
            		getParameters().getMeterDimensionCharValLarge(), 
            		meterDimensionCharType.getId().getIdValue().trim()));
    	}

    	CharacteristicValue_Id chvReg = new CharacteristicValue_Id(meterDimensionCharType, 
    			getParameters().getMeterDimensionCharValRegular());
    	if(isNull(chvReg.getEntity())) {
            addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharValueForCharType(
            		CHAR_VAL_REGULAR, 
            		getParameters().getMeterDimensionCharValRegular(), 
            		meterDimensionCharType.getId().getIdValue().trim()));
    	}
    	
    	// Meter size char type must be correct char entity.
    	CharacteristicType meterSizeCharType = getParameters().getMeterSizeCharType();
    	charEntityId = new CharacteristicEntity_Id(meterSizeCharType, CharacteristicEntityLookup.constants.METER);
        if(isNull(charEntityId.getEntity())) {
            addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharTypeForEntity(MTR_SIZE_CHTY, 
            		meterSizeCharType.getId().getIdValue(), 
            		(CharacteristicEntityLookup.constants.METER).trimmedValue()));
        }

    }
	
	public Class<CmMaximoDataCorrectionMeterDimensionBatchWorker> getThreadWorkerClass() {
        return CmMaximoDataCorrectionMeterDimensionBatchWorker.class;
    }

    public static class CmMaximoDataCorrectionMeterDimensionBatchWorker 
    		extends CmMaximoDataCorrectionMeterDimensionBatchWorker_Gen {
    	
    	// Constants.
    	private static final String MAXIMO_VALUE_LARGE = "LARGE";
    	private static final String MAXIMO_VALUE_REGULAR = "SMALL";
    	private static final String MAXIMO_VALUE = "Maximo New Dimension Value";
    	private static final String CI_MTR_CHAR = "CI_MTR_CHAR";
    	private static final String CHAR_VAL = "CHAR_VAL";
    	
    	public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

		@Override
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit) 
				throws ThreadAbortedException, RunAbortedException {

			WorkUnitResult result = new WorkUnitResult(true);
			int recordsProcessed = 0;
			
			String mtrIdStr = (String) unit.getSupplementallData("mtrId");			
			String newDimension = ((String) unit.getSupplementallData("newDimension")).trim();
			
			// Skip record if new dimension is null.
			if(isBlankOrNull(newDimension)) {
				result.setUnitsProcessed(recordsProcessed);
				return result;
			}
			
			// Setup char value based on maximo value.
			String newCharVal = "";
			
			if(newDimension.trim().equals(MAXIMO_VALUE_LARGE.trim())) {
				newCharVal = getParameters().getMeterDimensionCharValLarge();
			} else if(newDimension.trim().equals(MAXIMO_VALUE_REGULAR.trim())) {
				newCharVal = getParameters().getMeterDimensionCharValRegular();
			} else {
				addError(CustomMessageRepositoryMGE.commGenericObjectDoesNotExistsOnCCB(MAXIMO_VALUE, newDimension));
			}
			
			// Check if a char exists with effective date = process date.
			Meter mtr = (new Meter_Id(mtrIdStr)).getEntity();
			CharacteristicType meterDimensionCharType = getParameters().getMeterDimensionCharType();
			MeterCharacteristic_Id meterDimensionCharId = new MeterCharacteristic_Id(mtr, 
					meterDimensionCharType, 
					getProcessDateTime().getDate());
			
			MeterCharacteristic meterDimensionChar = meterDimensionCharId.getEntity();
			
			// If no char found, add new meter dimension char using new dimension value.
			if(isNull(meterDimensionChar)) {
				
				// Get effective char.
				MeterCharacteristic effChar = mtr.getEffectiveCharacteristic(meterDimensionCharType);
				String charVal = null;
				
				if(notNull(effChar)) {
					charVal = effChar.getCharacteristicValue();
				}
				
				// Create New char if effective char val is not equal to new char val.
				if(isBlankOrNull(charVal) || !charVal.trim().equals(newCharVal.trim())) {
					
					MeterCharacteristics meterChars = mtr.getCharacteristics();
					MeterCharacteristic_DTO mcDto = meterChars.newChildDTO();
					mcDto.setCharacteristicValue(newCharVal);
					MeterCharacteristic mcNew = meterChars.add(mcDto, meterDimensionCharType.getId(), getProcessDateTime().getDate());				
					cmCreateLog(mcNew, newCharVal, "");
					recordsProcessed = 1;
				} 
				
			} else {
			
				// Else if char is found, update char value using maximo value.
				String oldCharVal = meterDimensionChar.getCharacteristicValue();
				
				if(!newCharVal.trim().equals(oldCharVal.trim())) {
					MeterCharacteristic_DTO mcDto = meterDimensionChar.getDTO();
					mcDto.setCharacteristicValue(newCharVal);
					meterDimensionChar.setDTO(mcDto);
					cmCreateLog(meterDimensionChar, newCharVal, oldCharVal);
					recordsProcessed = 1;
				}
			}
			
			result.setUnitsProcessed(recordsProcessed);
			return result;
		}
		
		private void cmCreateLog(MeterCharacteristic mtrChar, String newValue, String oldValue) {
			
			CmMeterDataLog_DTO logDto = createDTO(CmMeterDataLog.class);
			logDto.setCreationDateTime(getProcessDateTime());
			logDto.setPrimaryKeyValue1(mtrChar.getId().getMeter().getId().getIdValue());
			logDto.setPrimaryKeyValue2(mtrChar.getId().getCharacteristicType().getId().getIdValue());
			logDto.setPrimaryKeyValue3(mtrChar.getId().getEffectiveDate().toString());
			logDto.setTable(CI_MTR_CHAR);
			logDto.setValueAfterUpdate(newValue);
			logDto.setValueBeforeUpdate(oldValue);
	        logDto.setField(CHAR_VAL);
			
			logDto.newEntity();
		}
    }
}