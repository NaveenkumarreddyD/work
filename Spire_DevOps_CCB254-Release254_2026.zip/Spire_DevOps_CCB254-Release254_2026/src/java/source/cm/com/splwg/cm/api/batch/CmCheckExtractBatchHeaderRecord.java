/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Column Delimited Record class for Batch Header
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-05-27   RDizon  CCB041. Initial version.        
 **************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

/**
 * @author RDizon
 */
public class CmCheckExtractBatchHeaderRecord extends ColumnDelimitedRecord {
    
    private static final String DELIMITER = "|";
        
    public CmCheckExtractBatchHeaderRecord() {
        super(10);
    }
    
    public void setRecordType(String value) {
        this.leftPadColumn(1, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setDisbursementSiteId(String value) {
        this.leftPadColumn(2, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setOriginName(String value) {
        this.leftPadColumn(3, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setTransmissionDate(String value) {
        this.leftPadColumn(4, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setTransmissionTimeHH(String value) {
        this.leftPadColumn(5, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setTransmissionTimeMM(String value) {
        this.leftPadColumn(6, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setControlNumber(String runNumber, String rerunNumber) {
    	runNumber = padLeftZeros(runNumber, 10);
    	rerunNumber = padLeftZeros(rerunNumber, 10);
        this.leftPadColumn(7, 21, runNumber + rerunNumber + DELIMITER);
    }
    
    public void setPMTFormateCode(String value) {
        this.leftPadColumn(8, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setPOSPayIndicator(String value) {
        this.leftPadColumn(9, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setSpecialProcessing(String value) {
        this.leftPadColumn(10, value.length() + 1, value.trim());
    }

    private String padLeftZeros(String inputString, int length) {
        if (inputString.length() >= length) {
            return inputString;
        }
        StringBuilder sb = new StringBuilder();
        while (sb.length() < length - inputString.length()) {
            sb.append('0');
        }
        sb.append(inputString);

        return sb.toString();
    }
    
}
