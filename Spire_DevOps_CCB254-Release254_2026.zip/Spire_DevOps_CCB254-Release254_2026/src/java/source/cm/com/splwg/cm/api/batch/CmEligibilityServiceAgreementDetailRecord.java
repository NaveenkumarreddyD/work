/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Record Layout for Custom Eligibility Service Agreement Detail Record
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-04-24   RDizon  NI0026.1 Initial Version.
 * 2013-09-05   CVB     Added DownpaymentRemainingAmount tag
 **************************************************************************/

package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmEligibilityServiceAgreementDetailRecord
extends ColumnDelimitedRecord {

    public CmEligibilityServiceAgreementDetailRecord() {
        super(15);
    }

    public void setServiceAgreementId(String serviceAgreementId) {
        String string = "<ServiceAgreementID>" + serviceAgreementId + "</ServiceAgreementID>" + "\n";
        this.rightPadColumn(1, string.length(), string);
    }
    
    public void setCisDivision(String cisDivision) {
        String string = "<CISDivision>" + cisDivision + "</CISDivision>" + "\n";
        this.rightPadColumn(2, string.length(), string);
    }

    public void setCurrentBalance(String currentBalance) {
        String string = "<CurrentBalance>" + currentBalance + "</CurrentBalance>" + "\n";
        this.rightPadColumn(3, string.length(), string);
    }
    
    public void setPayoffBalance(String payoffBalance) {
        String string = "<PayoffBalance>" + payoffBalance + "</PayoffBalance>" + "\n";
        this.rightPadColumn(4, string.length(), string);
    }
    
    public void setWriteOffAmount(String writeOffAmount) {
        String string = "<WriteOffAmt>" + writeOffAmount + "</WriteOffAmt>" + "\n";
        this.rightPadColumn(5, string.length(), string);
    }
    
    public void setSAType(String saType) {
        String string = "<SAType>" + saType + "</SAType>" + "\n";
        this.rightPadColumn(6, string.length(), string);
    }
    
    public void setSATypeDescription(String saTypeDescription) {
        String string = "<SATypeDescr>" + saTypeDescription + "</SATypeDescr>" + "\n";
        this.rightPadColumn(7, string.length(), string);
    }
    
    public void setSAStatus(String saStatus) {
        String string = "<SAStatus>" + saStatus + "</SAStatus>" + "\n";
        this.rightPadColumn(8, string.length(), string);
    }
    
    public void setSAStatusDescription(String saStatusDescription) {
        String string = "<SAStatusDescr>" + saStatusDescription + "</SAStatusDescr>" + "\n";
        this.rightPadColumn(9, string.length(), string);
    }
    
    public void setStartDate(String startDate) {
        String string = "<StartDate>" + startDate + "</StartDate>" + "\n";
        this.rightPadColumn(10, string.length(), string);
    }
    
    public void setEndDate(String endDate) {
        String string = "<EndDate>" + endDate + "</EndDate>" + "\n";
        this.rightPadColumn(11, string.length(), string);
    }
    
    public void setOldAccountId(String oldAccountId) {
        String string = "<OldAcctId>" + oldAccountId + "</OldAcctId>" + "\n";
        this.rightPadColumn(12, string.length(), string);
    }
    
    public void setOKToTONN(String okToTONN) {
        String string = "<OKToTONN>" + okToTONN + "</OKToTONN>" + "\n";
        this.rightPadColumn(13, string.length(), string);
    }
    
    public void setBackToBack(String backToBack) {
        String string = "<BackToBack>" + backToBack + "</BackToBack>" + "\n";
        this.rightPadColumn(14, string.length(), string);
    }
    
    // CVB - 2013-09-05 - Start
    public void setDownpaymentRemainingAmount(String downpaymentRemainingAmount) {
        String string = "<DownpaymentRemainingAmount>" + downpaymentRemainingAmount + "</DownpaymentRemainingAmount>" + "\n";
        this.rightPadColumn(15, string.length(), string);
    }
    // CVB - 2013-09-05 - End
}