/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * The new batch process will derive a priority category based on daily 
 * consumption of the peak month of last 12 months (Oct-Sep).
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2020-01-27  JTiozon     CCB004.2. Initial Version. 
 * 2022-05-23  DLampa      E-05432. If the priority is changing, add an instance
 *                         of the old priority with a value of zero so that 
 *                         the new priority is used in future bills. 
 * 2022-07-06  DLampa      E-05432. Issue1. Add factor for computing the average 
 *                         for LCLI SAs. Also, derive the sum of the firm 
 *                         priorities so that the latest valid values are
 *                         correctly deducted.
 * 2022-07-25  DLampa      E-05432.Issue2. Updated checking of interruptible
 *                         priority when determining whether old priority 
 *                         should be expired.  
 * 2022-08-09  DLampa      E-05432.Issue3. Update the value of the SA's RATECLS 
 *                         characteristic depending on the value of the new 
 *                         interruptible priority.     
 * 2022-08-31  DLampa      E-05432.Issue4. Add a new instance of the RATECLS 
 *                         characteristic only if the new value is different 
 *                         from the existing one                                                                      
 *                                                                     
 * *************************************************************************                
 */

package com.splwg.cm.domain.batch;

import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.contractQuantityType.entity.ContractQuantityType;
import com.splwg.ccb.domain.admin.contractQuantityType.entity.ContractQuantityType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementContractQuantity;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementContractQuantity_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementContractQuantity_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementRateScheduleHistory_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.rate.rateSchedule.entity.RateSchedule;
import com.splwg.ccb.domain.rate.rateSchedule.entity.RateSchedule_Id;

/**
 * @author JTiozon
 *
@BatchJob (multiThreaded = false, rerunnable = true, modules = {},
 * 		softParameters = { @BatchJobSoftParameter (name = PROCESS_PERIOD_START_DATE, type = date, required = true)
 *            , @BatchJobSoftParameter (name = PROCESS_PERIOD_END_DATE, type = date, required = true)
 *            , @BatchJobSoftParameter (name = EFFECTIVE_START_DATE, type = date, required = true)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = TRNSPO_PRIO_CTGRY_SVC_TSK_TYPE, type = entity, required = true)})
 */
public class CmDeriveTransportationPriorityCategoryBatch 
extends CmDeriveTransportationPriorityCategoryBatch_Gen {	
		
	// Batch Parameters
	private ServiceTaskType parmServiceTaskType;
	
	public JobWork getJobWork() { 

		parmServiceTaskType = getParameters().getTRNSPO_PRIO_CTGRY_SVC_TSK_TYPE();

		//Read Service Task Type Business Object
		BusinessObject serviceTaskTypeBo = parmServiceTaskType.getBusinessObject();
		BusinessObjectInstance serviceTaskType = BusinessObjectInstance.create(serviceTaskTypeBo);
		serviceTaskType.set("serviceTaskType", parmServiceTaskType.getId().getTrimmedValue()); 
		serviceTaskType = BusinessObjectDispatcher.read(serviceTaskType);

		ArrayList<ThreadWorkUnit> workUnitList =  new ArrayList<ThreadWorkUnit>();
		List<SQLResultRow> saList = null;

		// CIS Division / SA Types
		COTSInstanceList cisDivSaTypesListStr = serviceTaskType.getGroup("cisDivisionSaTypeDetails").getList("cisDivisionSaTypeDetailsList");
		for(COTSInstanceNode listNode : cisDivSaTypesListStr){
			String cisDivIdStr = listNode.getString("cisDivision"); 
			String saTypeCdStr = listNode.getString("saType"); 

			CisDivision_Id cisDivId = new CisDivision_Id(cisDivIdStr);
			ServiceAgreementType_Id saTypeId = new ServiceAgreementType_Id(cisDivId, saTypeCdStr);			
			saList = getServiceAgreement(saTypeId,cisDivId);
			
			for(SQLResultRow row: saList){
				ThreadWorkUnit workUnit = new ThreadWorkUnit();
				workUnit.setPrimaryId(new ServiceAgreement_Id(row.getString("SA_ID")));
				workUnitList.add(workUnit);
			}
		}
		

		return createJobWorkForThreadWorkUnitList(workUnitList);

	}


	/**
	 * This method retrieves the Service Agreements matching a SA Type
	 * @param saTypeId - Service Agreement Type
	 * @return SQLResultRow List
	 */
	private List<SQLResultRow> getServiceAgreement(ServiceAgreementType_Id saTypeId, CisDivision_Id cisDivId){ 

		StringBuilder sqlQuery = new StringBuilder();

		sqlQuery.append("SELECT "
						   +"SA.SA_ID "
						+"FROM "
						    +"CI_SA SA, "
						    +"CI_SA_TYPE ST "
						+"WHERE "
						    +"ST.SA_TYPE_CD = :saTypeCd "
						+"AND SA.SA_STATUS_FLG IN (:active,:pendingStop,:reactivated) "
						+"AND ST.CIS_DIVISION = :cisDivId "
						+"AND SA.CIS_DIVISION =  ST.CIS_DIVISION "
						+"AND SA.SA_TYPE_CD = ST.SA_TYPE_CD");

		PreparedStatement pStmt = createPreparedStatement(sqlQuery.toString(), getClass().getName());
		pStmt.bindStringProperty("saTypeCd", ServiceAgreementType.properties.saType, saTypeId.getSaType());
		pStmt.bindEntity("cisDivId", cisDivId.getEntity());
		pStmt.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
		pStmt.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
		pStmt.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);

		List<SQLResultRow> resultRowList = pStmt.list();
		pStmt.close();

		return resultRowList;

	}

	public Class<CmDeriveTransportationPriorityCategoryBatchWorker> getThreadWorkerClass() {
		return CmDeriveTransportationPriorityCategoryBatchWorker.class;
	}



	public static class CmDeriveTransportationPriorityCategoryBatchWorker 
	extends CmDeriveTransportationPriorityCategoryBatchWorker_Gen {

		// Work Variables
		private ServiceAgreement_Id saId;
		private List<ContractQuantityType> firmContractQtyTypeList;		
		private COTSInstanceList priorityCategoryListStr;
		// Start Add - E-05432 - 2022-05-23
		private List<ContractQuantityType> priorityContractQtyTypeList;
		// End Add - E-05432 - 2022-05-23
		// Start Add - E-05432 - 2022-07-06
		private BigDecimal numDays = BigDecimal.ZERO;
		// End Add - E-05432 - 2022-07-06
		// Start Add - E-05432 - 2022-08-09
		private COTSInstanceList newRateClassList;
		private Bool doesSaHaveFirmContractQty = Bool.FALSE;
		// End Add - E-05432 - 2022-08-09		
		
		// Soft Parameters
		private Date periodStart;
		private Date periodEnd;   
		private Date effStartDate;
		private String consUOM;
		private String consTOU;
		private String consSQI;
		private String billDaysUOM;
		private String billDaysTOU;
		private String billDaysSQI;
		private ServiceTaskType parmServiceTaskType;

		// Start Add - E-05432 - 2022-08-09
		private static final CharacteristicType_Id rateClassCharType = new CharacteristicType_Id("RATECLS");
		// End Add - E-05432 - 2022-08-09			
		
		@Override
		public void initializeThreadWork(boolean flag)
				throws ThreadAbortedException, RunAbortedException {

			periodStart = getParameters().getPROCESS_PERIOD_START_DATE();
			periodEnd = getParameters().getPROCESS_PERIOD_END_DATE();  
			effStartDate = getParameters().getEFFECTIVE_START_DATE();  		

			parmServiceTaskType = getParameters().getTRNSPO_PRIO_CTGRY_SVC_TSK_TYPE();
			firmContractQtyTypeList = new ArrayList<ContractQuantityType>();
			// Start Add - E-05432 - 2022-05-23
			priorityContractQtyTypeList = new ArrayList<ContractQuantityType>();
			// End Add - E-05432 - 2022-05-23

			// Get BO elements
			BusinessObject serviceTaskTypeBo = parmServiceTaskType.getBusinessObject();
			BusinessObjectInstance serviceTaskType = BusinessObjectInstance.create(serviceTaskTypeBo);
			serviceTaskType.set("serviceTaskType", parmServiceTaskType.getId().getTrimmedValue()); 
			serviceTaskType = BusinessObjectDispatcher.read(serviceTaskType);

			// Firm Contract Quantity Types
			COTSInstanceList firmContQtyTypesListStr = serviceTaskType.getGroup("firmContractQtyTypeDetails").getList("firmContractQtyTypeDetailsList");
			
			for(COTSInstanceNode listNode : firmContQtyTypesListStr){
				String firmContractQtyTypeStr = listNode.getString("firmContractQtyType");
				ContractQuantityType_Id firmContractQtyType = new ContractQuantityType_Id(firmContractQtyTypeStr);
				firmContractQtyTypeList.add(firmContractQtyType.getEntity());    	
			}
					
			// Priority Category Range
			priorityCategoryListStr = serviceTaskType.getGroup("priorityCatDetails").getList("priorityCategoryDetailsList");
			
			// Start Add - E-05432 - 2022-05-23
			for(COTSInstanceNode listNode : priorityCategoryListStr){
				String priorityContractQtyTypeStr = listNode.getString("priorityCategory");
				ContractQuantityType_Id priorityContractQtyType = new ContractQuantityType_Id(priorityContractQtyTypeStr);
				priorityContractQtyTypeList.add(priorityContractQtyType.getEntity());    	
			}			
			// End Add - E-05432 - 2022-05-23
			
			// Consumption UOM/TOU/SQI
			COTSInstanceNode consUomTouSqiNode = serviceTaskType.getGroup("consumption");
			consUOM = consUomTouSqiNode.getString("unitOfMeasure"); 
			consTOU = consUomTouSqiNode.getString("timeOfUse"); 
			consSQI = consUomTouSqiNode.getString("serviceQuantity"); 
			
			// Bill Days UOM/TOU/SQI
			COTSInstanceNode billDaysUomTouSqiNode = serviceTaskType.getGroup("billDays");
			billDaysUOM = billDaysUomTouSqiNode.getString("unitOfMeasure");
			billDaysTOU = billDaysUomTouSqiNode.getString("timeOfUse"); 
			billDaysSQI = billDaysUomTouSqiNode.getString("serviceQuantity"); 

			// Start Add - E-05432 - 2022-07-06
			COTSInstanceNode lcliFactorNode = serviceTaskType.getGroup("lcliFactor");
			if (!isNull(lcliFactorNode.getNumber("numDays"))) {
				numDays = lcliFactorNode.getNumber("numDays");
			}					
			// End Add - E-05432 - 2022-07-06
			
			// Start Add - E-05432 - 2022-08-09
			// New Rate Class Details
			newRateClassList = serviceTaskType.getGroup("newRateClassDetails").getList("newRateClassDetailsList");
			// End Add - E-05432 - 2022-08-09			
			
		}

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}


		@Override
		protected boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			saId = (ServiceAgreement_Id) unit.getPrimaryId(); 

			//Get the frozen bill segments with the maximum billable SQ (Peak Consumption). 
			SQLResultRow bsegResultRow = getFrozenBillSegments(saId, periodStart, periodEnd);

			if(notNull(bsegResultRow)){
				BillSegment_Id bsegId = (BillSegment_Id) bsegResultRow.getId("BSEG_ID", BillSegment.class); 

				BigDecimal peakConsumption = bsegResultRow.getBigDecimal("BILL_SQ"); 
				peakConsumption = peakConsumption.setScale(0, BigDecimal.ROUND_HALF_UP);

				// Start Change - E-05432 - 2022-07-06
				//Get the number of days from the SQ Collection.
				//BigDecimal days = getNumberOfDaysFromBillSegment(bsegId);

				// Determine the divisor for the average usage. Only one can be defined between the bill period days
				// and the LCLI number of days factor. For transportation, the bill period days will be used.
				// For LCLI, the number of days will be used.
				BigDecimal days;				
				if (numDays.equals(BigDecimal.ZERO)) {
					days = getNumberOfDaysFromBillSegment(bsegId);
				} else {
					days = numDays;
				}
				// End Change - E-05432 - 2022-07-06
				
				if(notNull(days)){
					days = days.setScale(0, BigDecimal.ROUND_HALF_UP);
					
					// Calculate Daily Average Consumption as (Peak Consumption / Days)
					BigDecimal dailyAverageConsumption = peakConsumption.divide(days); 
					dailyAverageConsumption = dailyAverageConsumption.setScale(0, BigDecimal.ROUND_HALF_UP);

					// Start Add - E-05432 - 2022-08-09
					doesSaHaveFirmContractQty = Bool.FALSE;
					// End Add - E-05432 - 2022-08-09					
					
					//Check if the SA has a Firm Priority contract quantity in effect. 					
					BigDecimal firmContractQty = checkSaFirmPriorityContract(saId); 
					
					if(notNull(firmContractQty)){	
						// Start Add - E-05432 - 2022-08-09
						doesSaHaveFirmContractQty = Bool.TRUE;
						// End Add - E-05432 - 2022-08-09
						
						//If so deduct this from the above, i.e. Daily Average Consumption = (Daily Average Consumption - Firm Contract Qty)
						firmContractQty = firmContractQty.setScale(0, BigDecimal.ROUND_HALF_UP);
						
						dailyAverageConsumption = dailyAverageConsumption.subtract(firmContractQty);
						//Add the computed daily average consumption as SA Contract Quantity
						processAddUpdateSaContractQuantity(dailyAverageConsumption);
					}else{
						//Add the daily average consumption as SA Contract Quantity
						processAddUpdateSaContractQuantity(dailyAverageConsumption);
					}
				}


			}

			return true;
		}

		/**
		 * This method will add or update the SA Contract Quantity
		 * @param dailyAverageConsumption - Daily Average Consumption
		 */
		private void processAddUpdateSaContractQuantity(BigDecimal dailyAverageConsumption){ 
		
			for(COTSInstanceNode node : priorityCategoryListStr){
				BigDecimal minimum =  node.getNumber("minimum"); 
				BigDecimal maximum =  node.getNumber("maximum");
				String priorityCategory = node.getString("priorityCategory");   	
				
				ContractQuantityType_Id contQtyId = new ContractQuantityType_Id(priorityCategory);

				ServiceAgreementContractQuantity_Id sacqId = new ServiceAgreementContractQuantity_Id(saId.getEntity(), contQtyId.getEntity(), effStartDate); 
				
				//If the daily average consumption is less than 0, add/update the SA Contract Quantity with a value of 1
				if(dailyAverageConsumption.compareTo(BigDecimal.ZERO) <=0){ 
					if(notNull(sacqId.getEntity())){ 
						updateSaContractQuantity(sacqId, BigDecimal.ONE, contQtyId, effStartDate);						
					}else{
						addSaContractQuantity(sacqId, BigDecimal.ONE); 
					}
					// Start Add - E-05432 - 2022-08-09
					updateRateClassChar(saId, contQtyId);
					// End Add - E-05432 - 2022-08-09
					break;
				}
				
				//If the daily average falls on the Priority Category Range, add/update the SA Contract Quantity with the daily average consumption 
				//using the matching Priority Category from the Service Task Type
				if(dailyAverageConsumption.compareTo(minimum) >=0 && dailyAverageConsumption.compareTo(maximum) <=0){ 			
					
					if(notNull(sacqId.getEntity())){ 
						updateSaContractQuantity(sacqId, dailyAverageConsumption, contQtyId, effStartDate);						
					}else{
						addSaContractQuantity(sacqId, dailyAverageConsumption); 
					}
					// Start Add - E-05432 - 2022-08-09
					updateRateClassChar(saId, contQtyId);
					// End Add - E-05432 - 2022-08-09
					break;
				}
			}
		}
		
		/**
		 * This method will add a SA Contract Quantity
		 * @param sacqId - Service Agreement Contract Quantity ID
		 * @param contractQuantity - Contract Quantity
		 */
		private void addSaContractQuantity(ServiceAgreementContractQuantity_Id sacqId, BigDecimal contractQuantity){ 

			ServiceAgreementContractQuantity_DTO saQtyDTO = new ServiceAgreementContractQuantity_DTO();
			saQtyDTO.setId(sacqId);
			saQtyDTO.setContractQuantity(contractQuantity);
			saQtyDTO.newEntity();
			
			// Start Add - E-05432 - 2022-05-23
			// If there is a previously existing contract quantity on the SA, expire it by adding a new instance with a value of zero.
			ListFilter<ServiceAgreementContractQuantity> saContFilter = saId.getEntity().getContractQuantities().createFilter("where this.id.effectiveDate < :effectiveDate ORDER BY this.id.effectiveDate DESC"
					, getClass().getName());
			saContFilter.bindDate("effectiveDate", effStartDate);
			
			ServiceAgreementContractQuantity_DTO sacqDTO = null;
			if (saContFilter.listSize() > 0){
				// Start Change - E-05432.Issue2 - 2022-07-25
				//ServiceAgreementContractQuantity sacq = (ServiceAgreementContractQuantity) saContFilter.firstRow();
				//sacqDTO = sacq.getDTO();
				
				// If existing priority (interruptible contract quantity) on the SA differs from what was just added, 
				// add an instance with a value of zero to expire it.
				//if (!sacqDTO.getId().getContractQuantityType().equals(sacqId.getContractQuantityType())
				//		&& !firmContractQtyTypeList.contains(sacqDTO.getId().getContractQuantityTypeId().getEntity())
				//		&& priorityContractQtyTypeList.contains(sacqDTO.getId().getContractQuantityTypeId().getEntity())) {
				//	ServiceAgreementContractQuantity_Id expireSaCqId = new ServiceAgreementContractQuantity_Id(saId.getEntity(), sacqDTO.getId().getContractQuantityTypeId().getEntity(), effStartDate);
				//	saQtyDTO = new ServiceAgreementContractQuantity_DTO();
				//	saQtyDTO.setId(expireSaCqId);
				//	saQtyDTO.setContractQuantity(BigDecimal.ZERO);
				//	saQtyDTO.newEntity();
				//}
					
				Bool isContQtyExpired = Bool.FALSE;
				QueryIterator<ServiceAgreementContractQuantity> saContIter = saContFilter.iterate();
				
		    	while(saContIter.hasNext()) {
		    		ServiceAgreementContractQuantity sacq = (ServiceAgreementContractQuantity) saContIter.next();
		    		sacqDTO = sacq.getDTO();

					// If existing priority (interruptible contract quantity) on the SA differs from what was just added, 
					// add an instance with a value of zero to expire it.
					if (!sacqDTO.getId().getContractQuantityType().equals(sacqId.getContractQuantityType())
							&& !firmContractQtyTypeList.contains(sacqDTO.getId().getContractQuantityTypeId().getEntity())
							&& priorityContractQtyTypeList.contains(sacqDTO.getId().getContractQuantityTypeId().getEntity())) {
						ServiceAgreementContractQuantity_Id expireSaCqId = new ServiceAgreementContractQuantity_Id(saId.getEntity(), sacqDTO.getId().getContractQuantityTypeId().getEntity(), effStartDate);
						saQtyDTO = new ServiceAgreementContractQuantity_DTO();
						saQtyDTO.setId(expireSaCqId);
						saQtyDTO.setContractQuantity(BigDecimal.ZERO);
						saQtyDTO.newEntity();
						
						isContQtyExpired = Bool.TRUE;
					}
					
					// Terminate looping once the interruptible value to expire has been found
					if (isContQtyExpired.isTrue()) {
						break;
					}
		    	}							
				// End Change - E-05432.Issue2 - 2022-07-25				
			}					
			// End Add - E-05432 - 2022-05-23
			
		}

		/**
		 * This method updates the SA Contract Quantity
		 * @param sacqId - Service Agreement Contract Quantity ID
		 * @param contractQuantity - Contract Quantity
		 * @param contQtyId - Contract Quantity ID
		 * @param effectiveDate - Effective Date
		 */
		private void updateSaContractQuantity(ServiceAgreementContractQuantity_Id sacqId, BigDecimal contractQuantity, ContractQuantityType_Id contQtyId, Date effectiveDate){ 
			
			ListFilter<ServiceAgreementContractQuantity> saContFilter = saId.getEntity().getContractQuantities().createFilter("where this.id.contractQuantityType = :contractQtyType and this.id.effectiveDate = :effectiveDate"
																		, getClass().getName());
			saContFilter.bindId("contractQtyType", contQtyId);
			saContFilter.bindDate("effectiveDate", effectiveDate);
			
			ServiceAgreementContractQuantity_DTO sacqDTO = null;
			if (saContFilter.listSize() > 0){
				ServiceAgreementContractQuantity sacq = (ServiceAgreementContractQuantity) saContFilter.firstRow();
				sacqDTO = sacq.getDTO();
				sacqDTO.setContractQuantity(contractQuantity);
				sacq.setDTO(sacqDTO);
			}			
	
		}

		/**
		 * This method retrieves the Bill Segments Frozen Billable Segments
		 * @param saId - Service Agreement
		 * @param periodStart - Period Start Date
		 * @param periodEnd - Period End Date
		 * @return SQLResultRow
		 */
		private SQLResultRow getFrozenBillSegments(ServiceAgreement_Id saId, Date periodStart, Date periodEnd){

			StringBuilder sqlQuery = new StringBuilder();

			sqlQuery.append("SELECT "
					           +"B.BSEG_ID, "
					           +"BSQ.BILL_SQ "
					       +"FROM "
					           +"CI_BSEG B, "
					           +"CI_BSEG_SQ BSQ "
					       +"WHERE "
					           +"B.SA_ID = :saId "
						   +"AND BSQ.BSEG_ID = B.BSEG_ID "
						   +"AND START_DT >= :periodStart "
						   +"AND END_DT <= :periodEnd "
						   +"AND B.BSEG_STAT_FLG = :frozen ");
			if(!isBlankOrNull(consUOM)){
				sqlQuery.append("AND BSQ.UOM_CD = '"+consUOM+"' ");
			}else{
				sqlQuery.append("AND BSQ.UOM_CD = ' ' ");
			}
			if(!isBlankOrNull(consTOU)){
				sqlQuery.append("AND BSQ.TOU_CD = '"+consTOU+"' ");
			}else{
				sqlQuery.append("AND BSQ.TOU_CD = ' ' ");
			}	    	
			if(!isBlankOrNull(consSQI)){
				sqlQuery.append("AND BSQ.SQI_CD = '"+consSQI+"' ");
			}else{
				sqlQuery.append("AND BSQ.SQI_CD = ' ' ");
			}

			sqlQuery.append("ORDER BY BSQ.BILL_SQ DESC");

			PreparedStatement pStmt = createPreparedStatement(sqlQuery.toString(), getClass().getName());
			pStmt.bindId("saId", saId);
			pStmt.bindDate("periodStart", periodStart);
			pStmt.bindDate("periodEnd", periodEnd);
			pStmt.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);

			SQLResultRow resultRow = pStmt.firstRow();
			pStmt.close();

			return resultRow;

		}

		/**
		 * This method retrieves the number of days bill segment quantity
		 * @param bsegId - Bill Segment ID
		 * @return - Number of Days
		 */
		private BigDecimal getNumberOfDaysFromBillSegment(BillSegment_Id bsegId){

			BigDecimal numOfDays = null;
			
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("SELECT "
					           +"BSQ.BILL_SQ AS NUM_OF_DAYS "
					       +"FROM "
					           +"CI_BSEG_SQ BSQ "
					       +"WHERE "
					           +"BSQ.BSEG_ID = :bsegId ");
			if(!isBlankOrNull(billDaysUOM)){
				sqlQuery.append("AND BSQ.UOM_CD = '"+billDaysUOM+"' ");
			}else{
				sqlQuery.append("AND BSQ.UOM_CD = ' ' ");
			}
			if(!isBlankOrNull(billDaysTOU)){
				sqlQuery.append("AND BSQ.TOU_CD = '"+billDaysTOU+"' ");
			}else{
				sqlQuery.append("AND BSQ.TOU_CD = ' ' ");
			}	    	
			if(!isBlankOrNull(billDaysSQI)){
				sqlQuery.append("AND BSQ.SQI_CD = '"+billDaysSQI+"' ");
			}else{
				sqlQuery.append("AND BSQ.SQI_CD = ' ' ");
			}

			PreparedStatement pStmt = createPreparedStatement(sqlQuery.toString(), getClass().getName());
			pStmt.bindId("bsegId", bsegId);

			SQLResultRow resultRow = pStmt.firstRow();

			if(notNull(resultRow)){
				numOfDays = resultRow.getBigDecimal("NUM_OF_DAYS");
			}

			pStmt.close();

			return numOfDays;

		}

		/**
		 * This method check if SA has Firm Priority Contract Quantity
		 * @param saId - Service Agreement ID
		 * @return - Service Contract Quantity
		 */
		private BigDecimal checkSaFirmPriorityContract(ServiceAgreement_Id saId){
			
			String bindStr = null;
			for(int i = 0; i < firmContractQtyTypeList.size(); i++) {
				if(isNull(bindStr)) {
					bindStr = ":qtyType" + i;
				} else {
					bindStr += ", :qtyType" + i;
				}
			}
			
			StringBuilder sqlQuery = new StringBuilder();
			// Start Change - E-05432 - 2022-07-06
			//sqlQuery.append("SELECT "
			//		           +"QTY.CONT_QTY "
			//		       +"FROM "
			//		           +"CI_SA_CONT_QTY QTY "
			//		       +"WHERE "
			//		           +"QTY.SA_ID = :saId "
			//		       +"AND QTY.CONT_QTY_TYPE_CD IN ( "+bindStr+" ) "
			//		       +"AND QTY.EFFDT = (SELECT MAX(QTY2.EFFDT) "
			//		                        +"FROM "
			//		                            +"CI_SA_CONT_QTY QTY2 "
			//		                        +"WHERE QTY2.SA_ID = QTY.SA_ID "
			//		                        +"AND QTY2.CONT_QTY_TYPE_CD = QTY.CONT_QTY_TYPE_CD "
			//		                        +"AND QTY2.EFFDT >= :periodStart "
			//		                        +"AND QTY2.EFFDT <= :periodEnd "
			//		                        +"AND QTY2.CONT_QTY < 999999)");
			sqlQuery.append("SELECT "
			           +"SUM(QTY.CONT_QTY) AS CONT_QTY "
			       +"FROM "
			           +"CI_SA_CONT_QTY QTY "
			       +"WHERE "
			           +"QTY.SA_ID = :saId "
			       +"AND QTY.CONT_QTY_TYPE_CD IN ( "+bindStr+" ) "
			       +"AND QTY.EFFDT = (SELECT MAX(QTY2.EFFDT) "
			                        +"FROM "
			                            +"CI_SA_CONT_QTY QTY2 "
			                        +"WHERE QTY2.SA_ID = QTY.SA_ID "
			                        +"AND QTY2.CONT_QTY_TYPE_CD = QTY.CONT_QTY_TYPE_CD "
			                        +"AND QTY2.EFFDT <= :periodEnd "
			                        +"AND QTY2.CONT_QTY < 999999)");			
			// End Change - E-05432 - 2022-07-06

			PreparedStatement pStmt = createPreparedStatement(sqlQuery.toString(), getClass().getName());
			pStmt.bindId("saId", saId);
			// Start Delete - E-05432 - 2022-07-06
			//pStmt.bindDate("periodStart", periodStart);
			// End Delete - E-05432 - 2022-07-06
			pStmt.bindDate("periodEnd", periodEnd);			
			
			for(int i = 0; i < firmContractQtyTypeList.size(); i++) {
				pStmt.bindEntity("qtyType" + i, firmContractQtyTypeList.get(i));
			}

			BigDecimal firmContractQty = null;

			SQLResultRow resultRow = pStmt.firstRow();

			if(notNull(resultRow)){
				firmContractQty = resultRow.getBigDecimal("CONT_QTY");
			}

			pStmt.close();

			return firmContractQty;
		}
		
		// Start Change - E-05432 - 2022-08-09
		/**
		 * This method will update the Rate Class characteristic on the account
		 * @param dailyAverageConsumption - Daily Average Consumption
		 */
		private void updateRateClassChar(ServiceAgreement_Id saId, ContractQuantityType_Id contQtyId){ 
		
			// Retrieve the SA's rate schedule
			RateSchedule currRateSchedule = retrieveCurrentEffectiveSaRateSchedule(saId);
			
			if (notNull(currRateSchedule)) {				
				for(COTSInstanceNode node : newRateClassList){
					String rateSchedule =  node.getString("rateSchedule").trim(); 				
					String priorityCategory = node.getString("priorityCategory").trim();  
					String newRateClass =  node.getString("newRateClass").trim();
					String newRateSchedMult =  node.getString("newRateScheduleMult").trim();
					String newRateClassMult =  node.getString("newRateClassMult").trim();
					
					// Find the matching Rate Schedule and Priority Category combination from the Service Task Type
					if (currRateSchedule.getId().getTrimmedValue().equalsIgnoreCase(rateSchedule)
							&& contQtyId.getTrimmedValue().equalsIgnoreCase(priorityCategory)) {
						if (doesSaHaveFirmContractQty.isTrue()) {
							updateOrAddSaCharacteristic(saId, newRateClassMult);
							
							// If the current rate schedule differs from the rate schedule for multiple priorities,
							// add a new rate scheduled instance
							if (!currRateSchedule.getId().getTrimmedValue().equalsIgnoreCase(newRateSchedMult)) {								
								RateSchedule_Id newRateSchedId = new RateSchedule_Id(newRateSchedMult);
								ServiceAgreementRateScheduleHistory_DTO saRsDto = saId.getEntity().getRateScheduleHistories().newChildDTO();
								saRsDto.setRateScheduleId(newRateSchedId);
								saId.getEntity().getRateScheduleHistories().add(saRsDto, effStartDate);											
							}
						} else {
							// Update the SA's existing Rate Class characteristic
							updateOrAddSaCharacteristic(saId, newRateClass);						
							
						}
					}					
				}
			}
			
		}
		
	    private RateSchedule retrieveCurrentEffectiveSaRateSchedule(ServiceAgreement_Id saId) {	    	
	        
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("SELECT "
					           +"RS_CD "
					       +"FROM "
					           +"CI_SA_RS_HIST "
					       +"WHERE "
					           +"SA_ID = :saId "
	           				   +"AND EFFDT <= :effectiveDate "
						   +"ORDER BY EFFDT DESC ");

			PreparedStatement pStmt = createPreparedStatement(sqlQuery.toString(), getClass().getName());
			pStmt.bindId("saId", saId);
			pStmt.bindDate("effectiveDate", effStartDate);			

			SQLResultRow resultRow = pStmt.firstRow();

			RateSchedule currRateSched = null;
			
			if(notNull(resultRow)){
				currRateSched = resultRow.getEntity("RS_CD", RateSchedule.class);				
			}

			pStmt.close();

			return currRateSched;
	        
			
	    }
	    
		/**
		 * This method updates the SA's RATECLS characteristic, if it exists, or adds a new instance.
		 */
		private void updateOrAddSaCharacteristic(ServiceAgreement_Id saId, String newRateClass){ 
			
			// Check if there is an instance of the SA's RATECLS characteristic where the effective date matches the effective start date batch parameter 			
			ServiceAgreementCharacteristic_DTO saCharDTO = null;
			ServiceAgreementCharacteristic_Id saCharId = new ServiceAgreementCharacteristic_Id(saId, rateClassCharType, effStartDate);			
			
			// If the characteristic exists on the SA, update its value
			if (!isNull(saCharId.getEntity())){
				saCharDTO = saCharId.getEntity().getDTO();
				
				ServiceAgreementCharacteristic saChar = saCharId.getEntity();
				saCharDTO = saChar.getDTO();
				if (rateClassCharType.getEntity().getCharacteristicType().isPredefinedValue()) {
					saCharDTO.setCharacteristicValue(newRateClass);	
				} else if (rateClassCharType.getEntity().getCharacteristicType().isAdhocValue()) {
					saCharDTO.setAdhocCharacteristicValue(newRateClass);
				} else {
					saCharDTO.setCharacteristicValueForeignKey1(newRateClass);
				}
				
				saCharDTO.setSearchCharacteristicValue(newRateClass);
				saChar.setDTO(saCharDTO);
			} else {
				// Start Add - E-05432 - 2022-08-31
				// Check if the latest effective instance of the SA's RATECLS characteristic differs from what is to be added.
				// If current effective value matches, no need to add a new instance of the characteristic.
				if (saId.getEntity().getEffectiveCharacteristic(rateClassCharType.getEntity()).getSearchCharacteristicValue().equalsIgnoreCase(newRateClass)) {
					return;
				}						
				// End Add - E-05432 - 2022-08-31				
				
				// Otherwise, add the characteristic			
				saCharDTO = createDTO(ServiceAgreementCharacteristic.class);
				saCharDTO.setId(saCharId);
				if (rateClassCharType.getEntity().getCharacteristicType().isPredefinedValue()) {
					saCharDTO.setCharacteristicValue(newRateClass);	
				} else if (rateClassCharType.getEntity().getCharacteristicType().isAdhocValue()) {
					saCharDTO.setAdhocCharacteristicValue(newRateClass);
				} else {
					saCharDTO.setCharacteristicValueForeignKey1(newRateClass);
				}
				
				saCharDTO.setSearchCharacteristicValue(newRateClass);
				saCharDTO.newEntity();
			}
	
		}	    
		// End Change - E-05432 - 2022-08-09		

	}

}
