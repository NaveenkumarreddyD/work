/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm issues an error that the Dispatch Group is no longer valid.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2020-12-21   NMendo      D-02189. Initial Version.                       
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.dispatchGroup.algorithm.faIntegration;

import java.math.BigInteger;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.ccb.api.lookup.FieldActivityChangeEventLookup;
import com.splwg.ccb.domain.admin.dispatchGroup.algorithm.faIntegration.DispatchGroupFaIntegrationAlgorithmSpot;
import com.splwg.ccb.domain.admin.dispatchGroup.entity.DispatchGroup;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.workflow.notificationDownload.entity.NotificationDownload;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author NMendo
 *
@AlgorithmComponent ()
 */
public class CmDisabledFAIntegrationAlgComp_Impl extends
		CmDisabledFAIntegrationAlgComp_Gen implements
		DispatchGroupFaIntegrationAlgorithmSpot {
	
	// Hard parameters
	private Bool isFaChangeProcessed;
	private List<NotificationDownload> notificationDownloads;
	private BigInteger notificationDownloadCount;
	private FieldActivityChangeEventLookup fieldActivityChangeEventLookup;
	private DispatchGroup fieldActivityIntDispatchGroup;
	
	@Override
	public Bool getIsFaChangeProcessed() {
		return isFaChangeProcessed;
	}

	@Override
	public List<NotificationDownload> getNotificationDownloads() {
		return notificationDownloads;
	}

	@Override
	public BigInteger getnotificationDownloadCount() {
		return notificationDownloadCount;
	}

	@Override
	public void setFaDataAfterChange(FieldActivityData arg0) {
	}

	@Override
	public void setFaDataBeforeChange(FieldActivityData arg0) {
	}

	@Override
	public void setFieldActivity(FieldActivity arg0) {
	}

	@Override
	public void setFieldActivityChangeEventLookup(
			FieldActivityChangeEventLookup arg0) {
		fieldActivityChangeEventLookup = arg0;
	}

	@Override
	public void setFieldActivityIntDispatchGroup(DispatchGroup arg0) {
		fieldActivityIntDispatchGroup = arg0;
	}
	
	@Override
	public void setIsFaChangeProcessed(Bool arg0) {
	}

	@Override
	public void setIsFaHeaderChanged(Bool arg0) {
	}

	@Override
	public void invoke() {
		
		// Raise an error if FA Change Event is Create or Change.
		if(fieldActivityChangeEventLookup.equals(FieldActivityChangeEventLookup.constants.CREATE_FIELD_ACTIVITY)
				|| fieldActivityChangeEventLookup.equals(FieldActivityChangeEventLookup.constants.CHANGE_FIELD_ACTIVITY)) {
			addError(CustomMessageRepositorySpireOne.d02189_dispatchGroupDisabled(fieldActivityIntDispatchGroup.getId().getTrimmedValue()));
		}
	}

}
