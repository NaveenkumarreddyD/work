/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Update Case Characteristic 
 * 
 * This algorithm will update a Case Characteristic given the 
 * Characteristic Type and Characteristic Value. 
 *            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-04-03   JPunza  NI0007.5 Initial Version.
 * 2016-01-25   MPang	Updated for CCB v2.4 compilation. 
 *************************************************************************/

package com.splwg.cm.domain.admin.caseType;

import java.math.BigInteger;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.ccb.api.lookup.CaseLogTypeLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;

//Start Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseTypeEnterStatusAlgorithmSpot;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameter_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameter_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameters;
import com.splwg.ccb.domain.todo.toDoCase.CaseLog_DTO;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCaseCharacteristics;*/

import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.algorithm.enterStatus.EnterStatusAlgorithmSpot;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameter_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameter_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameters;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCaseCharacteristics;
//End Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.cm.domain.customMessages.CustomMessagesMDC;

/**
 * @author jpunzalan2
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeToUpdate, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = newCharacteristicValue, required = true, type = string)})
 */
public class CmUpdateCaseCharacteristicAlgComp_Impl 
        extends CmUpdateCaseCharacteristicAlgComp_Gen 

        //Start Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
        // implements CaseTypeEnterStatusAlgorithmSpot {
        implements EnterStatusAlgorithmSpot { 
	   //End Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation

    // Constant Variable
    private final String CURRENT_DT = "$CURRENT_DT";
    private final DateFormat DATE_FORMAT = new DateFormat("yyyy-MM-dd");
    
    // Soft Parameters
    private CharacteristicType charTypeToUpdate;
    private String newCharValue;
    
    // Hard Parameter
    private ToDoCase toDoCase;
    
    public String getNextCaseStatus() {
        return null;
    }

    public String getNextTransCondition() {
        return null;
    }

    public Bool getShouldAutoTransition() {
        return null;
    }

    public void setCase(ToDoCase arg0) {
        toDoCase = arg0;
    }

    public void setCaseOriginalStatus(CaseStatus arg0) {

    }
    
    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        
        // Characteristic Type To Update
        charTypeToUpdate = getCharacteristicTypeToUpdate();
        if (validateCharacteristicEntity(charTypeToUpdate, CharacteristicEntityLookup.constants.CASE).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0007_5_charTypeToUpdInvalidForEntity(
                    getAlgorithm().getId().getTrimmedValue(),
                    charTypeToUpdate.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.CASE.getLookupValue().fetchLanguageDescription()));
        }
        
        if (validateCharacteristicEntity(charTypeToUpdate, CharacteristicEntityLookup.constants.CASE_LOG).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0007_5_charTypeToUpdInvalidForEntity(
                    getAlgorithm().getId().getTrimmedValue(),
                    charTypeToUpdate.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.CASE_LOG.getLookupValue().fetchLanguageDescription()));
        }
        
        // New Characteristic Value
        newCharValue = getNewCharacteristicValue();
        if (charTypeToUpdate.getCharacteristicType().isPredefinedValue() 
                && validateCharTypeAndCharValue(charTypeToUpdate, newCharValue).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0007_5_newCharValueInvalidForCharType(
                    getAlgorithm().getId().getTrimmedValue(), 
                    newCharValue, 
                    charTypeToUpdate.getId().getTrimmedValue()));
        }
    }    
    
    /**
     * This method validates if a characteristic type is valid for a specific characteristic entity.
     * @param charType - Characteristic Type
     * @param charEntityLookup - Characteristic Entity Lookup
     * @return Bool
     */
    private Bool validateCharacteristicEntity(CharacteristicType charType, CharacteristicEntityLookup charEntityLookup) {
        
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType.getId(), charEntityLookup);        
        if (isNull(charEntityId.getEntity())) {
            return Bool.FALSE;
        }
        
        return Bool.TRUE;
    }
    
    /**
     * This method validates if characteristic value is valid for a given characteristic type. 
     * @param charType - Characteristic Type
     * @param charValue - String
     * @return Bool
     */
    private Bool validateCharTypeAndCharValue(CharacteristicType charType, String charValue) {

        CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
        if (charTypeLookup.isPredefinedValue()) {
            CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charType, charValue);
            if (isNull(charValueId.getEntity())) {
                return Bool.FALSE;
            }
        }

        return Bool.TRUE;
    }

    public void invoke() {

        // Set Characteristic Value to Process Date
        if (newCharValue.compareTo(CURRENT_DT) == 0) {
            newCharValue = getProcessDateTime().getDate().toString(DATE_FORMAT);
        }
        
        // Retrieve Case Characteristics with a given Characteristic Type
        ToDoCaseCharacteristics caseChars = toDoCase.getCharacteristics();       
        //Start Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
        //ListFilter<CaseCharacteristic> charFilter = caseChars.createFilter("where this.id.characteristicType = :charType");
        ListFilter<CaseCharacteristic> charFilter = caseChars.createFilter("where this.id.characteristicType = :charType" , getClass().getName());
       //End Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
        charFilter.bindEntity("charType", charTypeToUpdate);
        
        long numberOfChars  = charFilter.listSize();
        
        if (numberOfChars == 0) { // Add
            addCaseCharacteristic();
            createCaseLog(BigInteger.ONE, newCharValue, ActionTypeCode.ADD);
        }
        else if (numberOfChars == 1) { // Update
            
            CaseCharacteristic caseChar = charFilter.firstRow();
            CaseCharacteristic_DTO caseCharDto = caseChar.getDTO();
            
            CharacteristicTypeLookup charTypeLookup = charTypeToUpdate.getCharacteristicType();
            if (charTypeLookup.isForeignKeyValue()) {
                caseCharDto.setCharacteristicValueForeignKey1(newCharValue);
            }
            else if (charTypeLookup.isPredefinedValue()) {
                caseCharDto.setCharacteristicValue(newCharValue); 
            } 
            else { 
                caseCharDto.setAdhocCharacteristicValue(newCharValue);
            }
            caseChar.setDTO(caseCharDto);
            createCaseLog(caseChar.fetchIdSequence(), newCharValue, ActionTypeCode.UPD);
        }
        else { // Delete
            
            QueryIterator<CaseCharacteristic> iter = charFilter.iterate();
            while (iter.hasNext()) {
                
                CaseCharacteristic caseChar = iter.next();                                
                caseChars.remove(caseChar);
                
                CharacteristicTypeLookup charTypeLookup = charTypeToUpdate.getCharacteristicType();
                String charValue = new String();
                if (charTypeLookup.isForeignKeyValue()) {
                    charValue = caseChar.getCharacteristicValueForeignKey1().trim();
                }
                else if (charTypeLookup.isPredefinedValue()) {
                    charValue = caseChar.getCharacteristicValue().trim();
                } 
                else { 
                    charValue = caseChar.getAdhocCharacteristicValue().trim();
                }
                createCaseLog(caseChar.fetchIdSequence(), charValue, ActionTypeCode.DEL);
            }
            iter.close();
            
            addCaseCharacteristic();
            createCaseLog(BigInteger.ONE, newCharValue, ActionTypeCode.ADD);
        }
    }
    
    /**
     * This method adds Case Characteristic.
     */
    private void addCaseCharacteristic() {
        
        CharacteristicTypeLookup charTypeLookup = charTypeToUpdate.getCharacteristicType(); 
        ToDoCaseCharacteristics caseChars = toDoCase.getCharacteristics();
            
        // Add Case Characteristic
        CaseCharacteristic_DTO caseCharDto = caseChars.newChildDTO();
        
        if (charTypeLookup.isForeignKeyValue()) {
            caseCharDto.setCharacteristicValueForeignKey1(newCharValue);
        }
        else if (charTypeLookup.isPredefinedValue()) {
            caseCharDto.setCharacteristicValue(newCharValue); 
        } 
        else { 
            caseCharDto.setAdhocCharacteristicValue(newCharValue);
        }
        
        caseChars.add(caseCharDto, charTypeToUpdate.getId(), BigInteger.ONE);        
    }
    
    /**
     * This method creates Case Log.
     * @param seqNum - Sequence Number
     * @param charValue - Characteristic Value
     * @param action - Action Type Code
     */
    private void createCaseLog(BigInteger seqNum, String charValue, ActionTypeCode action) {
        
        // Create Case Log Entry
        CaseLog_DTO caseLogDto = new CaseLog_DTO();
        caseLogDto.setCaseStatusId(toDoCase.getCaseStatus().getId());
        caseLogDto.setCharacteristicTypeId(charTypeToUpdate.getId());
        
        CharacteristicTypeLookup charTypeLookup = charTypeToUpdate.getCharacteristicType();
        if (charTypeLookup.isForeignKeyValue()) {
            caseLogDto.setCharacteristicValueForeignKey1(charValue);
        }
        else if (charTypeLookup.isPredefinedValue()) {
            caseLogDto.setCharacteristicValue(charValue);
        }
        else {
            caseLogDto.setAdhocCharacteristicValue(charValue);
        }
        
        caseLogDto.setLogType(CaseLogTypeLookup.constants.SYSTEM);
        
        // Set Message Id depending on Action
        MessageCategory_Id messageCategoryId = new MessageCategory_Id(BigInteger.valueOf(CustomMessagesMDC.MESSAGE_CATEGORY));
        if (action == ActionTypeCode.ADD) {
            caseLogDto.setMessageId(new Message_Id(messageCategoryId, BigInteger.valueOf(CustomMessagesMDC.NI0007_5_UCC_CASE_CHAR_ADD)));
        }
        else if (action == ActionTypeCode.UPD) {
            caseLogDto.setMessageId(new Message_Id(messageCategoryId, BigInteger.valueOf(CustomMessagesMDC.NI0007_5_UCC_CASE_CHAR_UPDATE)));
        }
        else {
            caseLogDto.setMessageId(new Message_Id(messageCategoryId, BigInteger.valueOf(CustomMessagesMDC.NI0007_5_UCC_CASE_CHAR_DELETE)));
        }
                
        // Get newly created Case Log
        CaseLog caseLog = toDoCase.getLogs().add(caseLogDto, null);                    

        CaseLogMessageParameters messageParms = caseLog.getMessageParameters();
        
        // Add message parameter for characteristic type
        CaseLogMessageParameter_DTO caseLogMsgParmDto = messageParms.newChildDTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.ONE));
        caseLogMsgParmDto.setMessageParameter(charTypeToUpdate.getId().getTrimmedValue());        
        messageParms.add(caseLogMsgParmDto, BigInteger.ONE);
        
        // Add message parameter for sequence number
        caseLogMsgParmDto = messageParms.newChildDTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.valueOf(2)));
        caseLogMsgParmDto.setMessageParameter(seqNum.toString().trim());        
        messageParms.add(caseLogMsgParmDto, BigInteger.valueOf(2));
        
        // Add message parameter for characteristic value
        BigInteger sequence = BigInteger.valueOf(3);
        for (int i = 0; i <= charValue.length(); i = i + 29) {
                       
            caseLogMsgParmDto = messageParms.newChildDTO();
            caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, sequence));
            
            if (i + 29 > charValue.length()) {
                caseLogMsgParmDto.setMessageParameter(charValue.substring(i, charValue.length()));     
            }
            else {
                caseLogMsgParmDto.setMessageParameter(charValue.substring(i, i + 29));
            }
            messageParms.add(caseLogMsgParmDto, sequence); 
            sequence = sequence.add(BigInteger.ONE);
        }               
    }
    
    /**
     * This is an enum type for Action Type
     */
    public enum ActionTypeCode {
        ADD, DEL, UPD
    }
}
