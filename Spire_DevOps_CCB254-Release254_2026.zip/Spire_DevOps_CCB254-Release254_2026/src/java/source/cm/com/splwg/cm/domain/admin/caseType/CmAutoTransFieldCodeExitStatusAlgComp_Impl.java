/*******************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * Metering Exception Case - Auto-Transition Based on Field Codes
 *
 * This algorithm will first evaluate the "inbound" field code and exception 
 * status Characteristics and update the "permanent" characteristics if   
 * necessary. The "inbound" Characteristics will be deleted after this  
 * evaluation. It will then evaluate the "permanent" field code and exception   
 * status Characteristics. If the values are populated and both registers have  
 * the same value, the algorithm will use Feature Configuration to retrieve the  
 * appropriate transition condition. If there are mismatching field code or  
 * exception status Characteristic values on the registers, the algorithm will  
 * return a transition condition for a manual review status for a Laclede  
 * resource to investigate the scenario and update the Case accordingly. 
 *
 ********************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-04-30   SMiranda        NI0007.5 - TIR6. Initial Version.
 * 2016-01-22	MPang		    Updated for CCB v2.4 compilation
 ********************************************************************************/
package com.splwg.cm.domain.admin.caseType;

import java.math.BigInteger;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.ccb.api.lookup.CaseLogTypeLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
//import com.splwg.ccb.domain.admin.caseType.CaseStatus;
//import com.splwg.ccb.domain.admin.caseType.CaseTypeExitStatusAlgorithmSpot;
//import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic;
//import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_DTO;
//import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_Id;
//import com.splwg.ccb.domain.todo.toDoCase.CaseLog;
//import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameter_DTO;
//import com.splwg.ccb.domain.todo.toDoCase.CaseLogMessageParameter_Id;
//import com.splwg.ccb.domain.todo.toDoCase.CaseLog_DTO;
//import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;

import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.algorithm.exitStatus.ExitStatusAlgorithmSpot;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameter_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLogMessageParameter_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;

//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation

import com.splwg.cm.api.lookup.TransitionConditionLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.cm.domain.customMessages.CustomMessagesMDC;
import com.splwg.shared.common.StringUtilities;

/**
 * @author smiranda
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForInboundCorrectedFieldCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundCorrectedExceptionStatus)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundCorrectedExceptionStatusDate)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForInboundUncorrectedFieldCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundUncorrectedExceptionStatus)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundUncorrectedExceptionStatusDate)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForCorrectedFieldCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForCorrectedExceptionStatus, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForCorrectedExceptionStatusDate, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForUncorrectedFieldCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForUncorrectedExceptionStatus, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForUncorrectedExceptionStatusDate)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForMainFieldCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForMainExceptionStatus, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForMainExceptionStatusDate, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = transitionCondition, name = manualReviewTransitionCondition, type = lookup)})
 */
public class CmAutoTransFieldCodeExitStatusAlgComp_Impl 
		extends CmAutoTransFieldCodeExitStatusAlgComp_Gen 
      //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
      //  CaseTypeExitStatusAlgorithmSpot {   
		implements ExitStatusAlgorithmSpot {
     //End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
    
    // Constants
    private final String CASE_LOG_ADD = "ADD";
    private final String CASE_LOG_UPDATE = "UPDATE";
    private final String CASE_LOG_DELETE = "DELETE";
    private final MessageCategory_Id MESSAGE_CAT = new MessageCategory_Id(BigInteger.valueOf(CustomMessagesMDC.MESSAGE_CATEGORY));
    private final BigInteger CASE_CHAR_ADDED_MSG_NUM = BigInteger.valueOf(CustomMessageRepositoryMDC.NI0007_5_4_CASE_CHAR_ADDED);
    private final BigInteger CASE_CHAR_UPDATED_MSG_NUM = BigInteger.valueOf(CustomMessageRepositoryMDC.NI0007_5_4_CASE_CHAR_UPDATED);
    private final BigInteger CASE_CHAR_DELETED_MSG_NUM = BigInteger.valueOf(CustomMessageRepositoryMDC.NI0007_5_4_CASE_CHAR_DELETED);
    
    // Variables for Hard Parameters   
    private ToDoCase toDoCase;
    
    // Variables for Soft Parameters
    private CharacteristicType inboundCorrectedFieldCodeCharType,
            inboundCorrectedExceptionStatusCharType,
            inboundCorrectedExceptionStatusDateCharType,
            inboundUncorrectedFieldCodeCharType,
            inboundUncorrectedExceptionStatusCharType,
            inboundUncorrectedExceptionStatusDateCharType,
            correctedFieldCodeCharType,
            correctedExceptionStatusCharType,
            correctedExceptionStatusDateCharType,
            uncorrectedFieldCodeCharType,
            uncorrectedExceptionStatusCharType,
            uncorrectedExceptionStatusDateCharType,
            mainFieldCodeCharType,
            mainExceptionStatusCharType,
            mainExceptionStatusDateCharType;
    private TransitionConditionLookup manualReviewTransitionCondition;
    
    // Other work variables
    private String algCodeStr;
    private SQLResultRow caseCharSQLResult = null;
    private Bool correctedExceptionStatusUpdatedSw,
            uncorrectedExceptionStatusUpdatedSw,
            correctedFieldCodeUpdatedSw,
            uncorrectedFieldCodeUpdatedSw,
            autoTransManualReviewSw;
    
    // Corrected
    private String inboundCorrectedExceptionStatus = "",
            inboundCorrectedExceptionStatusDate = "",
            inboundCorrectedFieldCode = "",
            correctedExceptionStatus = "",
            correctedExceptionStatusDate = "",
            correctedFieldCode = "";
    private BigInteger inboundCorrectedExceptionStatusSeq = BigInteger.ZERO,
            inboundCorrectedExceptionStatusDateSeq = BigInteger.ZERO,
            inboundCorrectedFieldCodeSeq = BigInteger.ZERO,
            correctedExceptionStatusSeq = BigInteger.ZERO,
            correctedExceptionStatusDateSeq = BigInteger.ZERO,
            correctedFieldCodeSeq = BigInteger.ZERO;
    // Uncorrected 
    private String inboundUncorrectedExceptionStatus = "",
            inboundUncorrectedExceptionStatusDate = "",
            inboundUncorrectedFieldCode = "",
            uncorrectedExceptionStatus = "",
            uncorrectedExceptionStatusDate = "",
            uncorrectedFieldCode = "";
    private BigInteger inboundUncorrectedExceptionStatusSeq = BigInteger.ZERO,
            inboundUncorrectedExceptionStatusDateSeq = BigInteger.ZERO,
            inboundUncorrectedFieldCodeSeq = BigInteger.ZERO,
            uncorrectedExceptionStatusSeq = BigInteger.ZERO,
            uncorrectedExceptionStatusDateSeq = BigInteger.ZERO,
            uncorrectedFieldCodeSeq = BigInteger.ZERO;
    // Permanent
    private String permanentExceptionStatus = "",
            permanentExceptionStatusDate = "",
            permanentFieldCode = "";
    // Main
    private String mainExceptionStatus = "",
            mainExceptionStatusDate = "",
            mainFieldCode = "";
    private BigInteger mainExceptionStatusSeq = BigInteger.ZERO,
            mainExceptionStatusDateSeq = BigInteger.ZERO,
            mainFieldCodeSeq = BigInteger.ZERO;

    public CaseStatus getNextCaseStatus() {
        
        return null;
    }

    public String getNextTransCondition() {
        
        return null;
    }

    public Bool getShouldAutoTransition() {
        
        return null;
    }
    
    public void setNextCaseStatus(CaseStatus arg0) {
        
    }

    public void setCase(ToDoCase arg0) {        
        toDoCase = arg0;
    }

    public void invoke() {      
        
        // Determine whether a new exception status has been sent
        evaluateCorrectedExceptionStatus();         
        evaluateUncorrectedExceptionStatus();
        
        // Process status updates
        if (correctedExceptionStatusUpdatedSw.isTrue() || uncorrectedExceptionStatusUpdatedSw.isTrue()){
            processStatusUpdates();
            if (autoTransManualReviewSw.isTrue()){
                deleteInboundFieldCodes();
                return;
            }
        }
        
        // Determine whether a field code has been sent
        evaluateCorrectedFieldCode();
        evaluateUncorrectedFieldCode();       
        
        // Process field code updates
        if (correctedFieldCodeUpdatedSw.isTrue() || uncorrectedFieldCodeUpdatedSw.isTrue()){
            processFieldCodeUpdates();
        }        
        
        deleteInboundFieldCodes();
        
    } 

    private void deleteInboundFieldCodes() {

        if (inboundCorrectedFieldCode != "") {
            // Delete the Inbound Corrected Field Code Characteristic
            deleteCaseChar(inboundCorrectedFieldCodeCharType, inboundCorrectedFieldCodeSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedFieldCodeCharType, 
                    inboundCorrectedFieldCodeSeq, 
                    inboundCorrectedFieldCode, 
                    CASE_LOG_DELETE); 
        }
        
        if (inboundUncorrectedFieldCode != ""){
            // Delete the Inbound Uncorrected Field Code Characteristic
            deleteCaseChar(inboundUncorrectedFieldCodeCharType, inboundUncorrectedFieldCodeSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedFieldCodeCharType, 
                    inboundUncorrectedFieldCodeSeq, 
                    inboundUncorrectedFieldCode, 
                    CASE_LOG_DELETE); 
        }
        
    }

    private void evaluateCorrectedExceptionStatus() {        
        
        correctedExceptionStatusUpdatedSw = Bool.FALSE;

        // Determine whether an Inbound Corrected Exception Status Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            inboundCorrectedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }   
        
        // Determine whether an Inbound Corrected Exception Status Date Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            inboundCorrectedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }  
        
        // Retrieve the value for the Permanent Corrected Exception Status Characteristic.
        caseCharSQLResult = getCaseChar(correctedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            correctedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            correctedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }     
        
        // Retrieve the value for the Permanent Corrected Exception Status Date Characteristic.
        caseCharSQLResult = getCaseChar(correctedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            correctedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            correctedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        } 
        
        // If the Inbound Corrected Exception Status and the Permanent Corrected Exception Status are different
        if (inboundCorrectedExceptionStatus != "" && (!inboundCorrectedExceptionStatus.equals(correctedExceptionStatus))){
            
            createOrUpdateChar(inboundCorrectedExceptionStatus,
                    correctedExceptionStatusCharType,
                    correctedExceptionStatusSeq,
                    correctedExceptionStatus);
            correctedExceptionStatus = inboundCorrectedExceptionStatus;
            correctedExceptionStatusUpdatedSw = Bool.TRUE;
            
            /* Update the Permanent Corrected Exception Status Date Characteristic using the value from 
             * the Inbound Corrected Exception Status Date. */
            if (inboundCorrectedExceptionStatusDate != ""){
                createOrUpdateChar(inboundCorrectedExceptionStatusDate,
                        correctedExceptionStatusDateCharType,
                        correctedExceptionStatusDateSeq,
                        correctedExceptionStatusDate);
                correctedExceptionStatusDate = inboundCorrectedExceptionStatusDate;
            }
        }
        
        // Delete the Inbound Corrected Exception Status Characteristic
        if (inboundCorrectedExceptionStatus != ""){
            deleteCaseChar(inboundCorrectedExceptionStatusCharType, inboundCorrectedExceptionStatusSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedExceptionStatusCharType, 
                    inboundCorrectedExceptionStatusSeq, 
                    inboundCorrectedExceptionStatus, 
                    CASE_LOG_DELETE);                         
        }

        // Delete the Inbound Corrected Exception Status Date Characteristic
        if (inboundCorrectedExceptionStatusDate != ""){
            deleteCaseChar(inboundCorrectedExceptionStatusDateCharType, inboundCorrectedExceptionStatusDateSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedExceptionStatusDateCharType, 
                    inboundCorrectedExceptionStatusDateSeq, 
                    inboundCorrectedExceptionStatusDate, 
                    CASE_LOG_DELETE); 
        }
        
    }
    
    private void evaluateUncorrectedExceptionStatus() {     
        
        uncorrectedExceptionStatusUpdatedSw = Bool.FALSE;

        // Determine whether an Inbound Uncorrected Exception Status Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            inboundUncorrectedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }   
        
        // Determine whether an Inbound Uncorrected Exception Status Date Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            inboundUncorrectedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }  
        
        // Retrieve the value for the Permanent Uncorrected Exception Status Characteristic.
        caseCharSQLResult = getCaseChar(uncorrectedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            uncorrectedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            uncorrectedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }     
        
        // Retrieve the value for the Permanent Uncorrected Exception Status Date Characteristic.
        caseCharSQLResult = getCaseChar(uncorrectedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            uncorrectedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            uncorrectedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        } 
        
        // If the Inbound Uncorrected Exception Status and the Permanent Uncorrected Exception Status are different
        if (inboundUncorrectedExceptionStatus != "" && (!inboundUncorrectedExceptionStatus.equals(uncorrectedExceptionStatus))){
            
            createOrUpdateChar(inboundUncorrectedExceptionStatus,
                    uncorrectedExceptionStatusCharType,
                    uncorrectedExceptionStatusSeq,
                    uncorrectedExceptionStatus);
            uncorrectedExceptionStatus = inboundUncorrectedExceptionStatus;
            uncorrectedExceptionStatusUpdatedSw = Bool.TRUE;
            
            /* Update the Permanent Uncorrected Exception Status Date Characteristic using the value from 
             * the Inbound Unorrected Exception Status Date. */
            if (inboundUncorrectedExceptionStatusDate != ""){
                createOrUpdateChar(inboundUncorrectedExceptionStatusDate,
                        uncorrectedExceptionStatusDateCharType,
                        uncorrectedExceptionStatusDateSeq,
                        uncorrectedExceptionStatusDate);
                uncorrectedExceptionStatusDate = inboundUncorrectedExceptionStatusDate;
            }
        }
        
        // Delete the Inbound Uncorrected Exception Status Characteristic
        if (inboundUncorrectedExceptionStatus != ""){
            deleteCaseChar(inboundUncorrectedExceptionStatusCharType, inboundUncorrectedExceptionStatusSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedExceptionStatusCharType, 
                    inboundUncorrectedExceptionStatusSeq, 
                    inboundUncorrectedExceptionStatus, 
                    CASE_LOG_DELETE); 
        }

        // Delete the Inbound Uncorrected Exception Status Date Characteristic
        if (inboundUncorrectedExceptionStatusDate != ""){
            deleteCaseChar(inboundUncorrectedExceptionStatusDateCharType, inboundUncorrectedExceptionStatusDateSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedExceptionStatusDateCharType, 
                    inboundUncorrectedExceptionStatusDateSeq, 
                    inboundUncorrectedExceptionStatusDate, 
                    CASE_LOG_DELETE); 
        }
    }
    
    private void processStatusUpdates() {        
        
        autoTransManualReviewSw = Bool.FALSE;
        
        // If both Permanent Corrected Exception Status Characteristic and Permanent Uncorrected Exception Status Characteristic exist
        if (correctedExceptionStatus != "" && uncorrectedExceptionStatus !=""){
            // But the Characteristics have different values
            if (!correctedExceptionStatus.equals(uncorrectedExceptionStatus)){
                // Return a transition condition equal to the value of the Manual Review Transition Condition parameter.
                if (notNull(manualReviewTransitionCondition)){
                    autoTransManualReviewSw = Bool.TRUE;
                    return;
                }
            }else{
                // Both Characteristics exist and have the same value
                permanentExceptionStatus = correctedExceptionStatus;
                permanentExceptionStatusDate = correctedExceptionStatusDate;
            }
        }else{
            if (correctedExceptionStatus != ""){
                permanentExceptionStatus = correctedExceptionStatus;
                permanentExceptionStatusDate = correctedExceptionStatusDate;
            }
            if (uncorrectedExceptionStatus != ""){
                permanentExceptionStatus = uncorrectedExceptionStatus;
                permanentExceptionStatusDate = uncorrectedExceptionStatusDate;
            }
        }
        
        // If only one of the Characteristics exist, or if both Characteristics exist and have the same value
        if (permanentExceptionStatus != ""){
            // Retrieve the Main Exception Status Characteristic value
            caseCharSQLResult = getCaseChar(mainExceptionStatusCharType);
            if (notNull(caseCharSQLResult)){
                mainExceptionStatus = caseCharSQLResult.getString("CHARVAL");
                mainExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");            
            }
            // Retrieve the Main Exception Status Date Characteristic value
            caseCharSQLResult = getCaseChar(mainExceptionStatusDateCharType);
            if (notNull(caseCharSQLResult)){
                mainExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
                mainExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
            }
            
            // If the value for the "permanent" Characteristics is different from the Main Exception Status
            if (!permanentExceptionStatus.equals(mainExceptionStatus)){
                
                createOrUpdateChar(permanentExceptionStatus,
                        mainExceptionStatusCharType,
                        mainExceptionStatusSeq,
                        mainExceptionStatus);                   
                    
                if (permanentExceptionStatusDate != ""){
                    // Create or Update the Main Exception Status Date Characteristic using the value from the Permanent Exception Status Date
                    createOrUpdateChar(permanentExceptionStatusDate,
                            mainExceptionStatusDateCharType,
                            mainExceptionStatusDateSeq,
                            mainExceptionStatusDate); 
                }
            }
                
        }                     
        
    }
    
    private void evaluateCorrectedFieldCode() {        
        
        correctedFieldCodeUpdatedSw = Bool.FALSE;
        
        // Determine whether an Inbound Corrected Field Code Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedFieldCodeCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedFieldCode = caseCharSQLResult.getString("CHARVAL");
            inboundCorrectedFieldCodeSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }         
        
        // Retrieve the value for the Permanent Corrected Field Code Characteristic.
        caseCharSQLResult = getCaseChar(correctedFieldCodeCharType);
        if (notNull(caseCharSQLResult)){
            correctedFieldCode = caseCharSQLResult.getString("CHARVAL");
            correctedFieldCodeSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
        if (inboundCorrectedFieldCode != "" && (!inboundCorrectedFieldCode.equals(correctedFieldCode))){
            // Create or update the Permanent Corrected Field Code Characteristic using the value from the Inbound Corrected Field Code.
            createOrUpdateChar(inboundCorrectedFieldCode,
                    correctedFieldCodeCharType,
                    correctedFieldCodeSeq,
                    correctedFieldCode); 
            correctedFieldCode = inboundCorrectedFieldCode;
            correctedFieldCodeUpdatedSw = Bool.TRUE;
        }
                
    }
    
    private void evaluateUncorrectedFieldCode() {       
        
        uncorrectedFieldCodeUpdatedSw = Bool.FALSE;
        
        // Determine whether an Inbound Uncorrected Field Code Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedFieldCodeCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedFieldCode = caseCharSQLResult.getString("CHARVAL");
            inboundUncorrectedFieldCodeSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }         
        
        // Retrieve the value for the Permanent Uncorrected Field Code Characteristic.
        caseCharSQLResult = getCaseChar(uncorrectedFieldCodeCharType);
        if (notNull(caseCharSQLResult)){
            uncorrectedFieldCode = caseCharSQLResult.getString("CHARVAL");
            uncorrectedFieldCodeSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
        
        if (inboundUncorrectedFieldCode != "" && (!inboundUncorrectedFieldCode.equals(uncorrectedFieldCode))){
            // Create or update the Permanent Uncorrected Field Code Characteristic using the value from the Inbound Uncorrected Field Code
            createOrUpdateChar(inboundUncorrectedFieldCode,
                    uncorrectedFieldCodeCharType,
                    uncorrectedFieldCodeSeq,
                    uncorrectedFieldCode); 
            uncorrectedFieldCode = inboundUncorrectedFieldCode;
            uncorrectedFieldCodeUpdatedSw = Bool.TRUE;
        }
              
    }    
    
    private void processFieldCodeUpdates() {             
        
        // If both Permanent Corrected Field Code Characteristic and Permanent Uncorrected Field Code Characteristic exist
        if (correctedFieldCode != "" && uncorrectedFieldCode !=""){
            // But the Characteristics have different values
            if (!correctedFieldCode.equals(uncorrectedFieldCode)){
                // Return a transition condition equal to the value of the Manual Review Transition Condition parameter.
                if (notNull(manualReviewTransitionCondition)){
                    return;
                }
            }else{
                // Both Characteristics exist and have the same value
                permanentFieldCode = correctedFieldCode;
            }
        }else{            
            if (correctedFieldCode != ""){
                permanentFieldCode = correctedFieldCode;
            }
            if (uncorrectedFieldCode != ""){
                permanentFieldCode = uncorrectedFieldCode;
            }
        }
        
        // If only one of the Characteristics exist, or if both Characteristics exist and have the same value
        if (permanentFieldCode != ""){
            // Retrieve the Main Field Code Characteristic value
            caseCharSQLResult = getCaseChar(mainFieldCodeCharType);
            if (notNull(caseCharSQLResult)){
                mainFieldCode = caseCharSQLResult.getString("CHARVAL");
                mainFieldCodeSeq = caseCharSQLResult.getInteger("SEQNUM");            
            }
           
            // If the value for the "permanent" Characteristics is different from the Main Exception Status
            if (!permanentFieldCode.equals(mainFieldCode)){
                // Update the Main Field Code Characteristic using the value from the Permanent Field Code Characteristic.
                createOrUpdateChar(permanentFieldCode,
                        mainFieldCodeCharType,
                        mainFieldCodeSeq,
                        mainFieldCode); 
            }          
        }               
        
    }           

    private SQLResultRow getCaseChar(CharacteristicType charType){
        
        SQLResultRow caseCharSQLResult = null;        
        String charVal = "";
        
        if (charType.getCharacteristicType().isPredefinedValue()){
            charVal = "CACH.CHAR_VAL ";
        }        
        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            charVal = "CACH.ADHOC_CHAR_VAL ";
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            charVal = "CACH.CHAR_VAL_FK1 ";
        }
        
        PreparedStatement getCaseChar 
                = createPreparedStatement(
                        "SELECT " +
                            charVal + "AS CHARVAL, " +
                            "CACH.SEQ_NUM AS SEQNUM " +
                        "FROM " +
                            "CI_CASE_CHAR CACH " +
                        "WHERE " +
                            "CACH.CASE_ID = :caseId " +
                            "AND CACH.CHAR_TYPE_CD = :charTypeCd " +
                            "AND CACH.SEQ_NUM = (SELECT MAX(CACH2.SEQ_NUM) " +
                                                "FROM CI_CASE_CHAR CACH2 " +
                                                "WHERE CACH2.CASE_ID = CACH.CASE_ID " +
                                              //Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
                                              //  "AND CACH2.CHAR_TYPE_CD = CACH.CHAR_TYPE_CD)");
                								  "AND CACH2.CHAR_TYPE_CD = CACH.CHAR_TYPE_CD)" , getClass().getName());
        									//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
        
        getCaseChar.bindId("caseId", toDoCase.getId());
        getCaseChar.bindId("charTypeCd", charType.getId());
        caseCharSQLResult = getCaseChar.firstRow();                        
        
        return caseCharSQLResult;
    }
    
    private void createOrUpdateChar(String inboundCharValue, CharacteristicType permanentCharType, 
            BigInteger permanentCharSeq, String currentCharValue) {

        if (currentCharValue == ""){
            // Create the Permanent characteristic
            permanentCharSeq = createCaseChar(permanentCharType, inboundCharValue);
            // Create case log for added characteristic
            createCaseLog(permanentCharType, permanentCharSeq, inboundCharValue, CASE_LOG_ADD); 
        }else{
            if (!currentCharValue.equals(inboundCharValue)){
                // Update the Permanent characteristic
                updateCaseChar(permanentCharType, permanentCharSeq, inboundCharValue);
                // Create case log for updated characteristic
                createCaseLog(permanentCharType, permanentCharSeq, inboundCharValue, CASE_LOG_UPDATE);
            }                 
        }               
       
    }

    private BigInteger createCaseChar(CharacteristicType charType, String charValue){                  

        CaseCharacteristic_DTO caseCharDTO = new CaseCharacteristic_DTO();
        caseCharDTO.setId(new CaseCharacteristic_Id(charType, toDoCase, null));
        
        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            caseCharDTO.setAdhocCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isPredefinedValue()){
            caseCharDTO.setCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            caseCharDTO.setCharacteristicValueForeignKey1(charValue.trim());
        }
        
        CaseCharacteristic caseChar = caseCharDTO.newEntity();
        return caseChar.fetchIdSequence();
  
    }
    
    private void updateCaseChar(CharacteristicType charType, BigInteger seqNum, String newCharValue) {
        
        CaseCharacteristic_Id charChar_Id = new CaseCharacteristic_Id(charType, toDoCase, seqNum);
        CaseCharacteristic_DTO caseCharDTO = charChar_Id.getEntity().getDTO();
        
        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            caseCharDTO.setAdhocCharacteristicValue(newCharValue.trim());
        }
        if (charType.getCharacteristicType().isPredefinedValue()){
            caseCharDTO.setCharacteristicValue(newCharValue.trim());
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            caseCharDTO.setCharacteristicValueForeignKey1(newCharValue.trim());
        }
        
        charChar_Id.getEntity().setDTO(caseCharDTO);
        
    }
    
    private void deleteCaseChar(CharacteristicType charType, BigInteger seqNum) {

        CaseCharacteristic_Id charChar_Id = new CaseCharacteristic_Id(charType, toDoCase, seqNum);
        toDoCase.getCharacteristics().remove(charChar_Id);
        
    }
    
    private void createCaseLog(CharacteristicType charType, BigInteger seqNum, String charValue, String action){     
           
        CaseLog_DTO caseLogDto = new CaseLog_DTO();
        caseLogDto.setCaseStatusId(toDoCase.getCaseStatus().getId());
        caseLogDto.setCharacteristicTypeId(charType.getId());
        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            caseLogDto.setAdhocCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isPredefinedValue()){
            caseLogDto.setCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            caseLogDto.setCharacteristicValueForeignKey1(charValue.trim());
        }
        // Set Message Id depending on Action
        if (action == CASE_LOG_ADD){
            caseLogDto.setMessageId(new Message_Id(MESSAGE_CAT, CASE_CHAR_ADDED_MSG_NUM));
        }
        if (action == CASE_LOG_UPDATE){
            caseLogDto.setMessageId(new Message_Id(MESSAGE_CAT, CASE_CHAR_UPDATED_MSG_NUM));
        }
        if (action == CASE_LOG_DELETE){
            caseLogDto.setMessageId(new Message_Id(MESSAGE_CAT, CASE_CHAR_DELETED_MSG_NUM));
        }        
        caseLogDto.setLogType(CaseLogTypeLookup.constants.SYSTEM);
        
        // Get newly created Case Log
        CaseLog caseLog = toDoCase.getLogs().add(caseLogDto, null);             

        // Add message parameter for characteristic type
        CaseLogMessageParameter_DTO caseLogMsgParmDto = new CaseLogMessageParameter_DTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.ONE));
        caseLogMsgParmDto.setMessageParameter(charType.getId().getIdValue().trim());        
        caseLog.getMessageParameters().add(caseLogMsgParmDto, BigInteger.ONE);
        
        // Add message parameter for characteristic sequence number
        caseLogMsgParmDto = new CaseLogMessageParameter_DTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.valueOf(2)));
        caseLogMsgParmDto.setMessageParameter(seqNum.toString().trim());        
        caseLog.getMessageParameters().add(caseLogMsgParmDto, BigInteger.valueOf(2));
        
        // Add message parameter for characteristic value
        int counter = 0;
        String[] charVal = new String[]{"","","","","","",""};        
        
        for(int i = 0; i <= charValue.length() && counter < 7; i = i + 30){            
            if( i + 30 > charValue.length()){
                charVal[counter] = (charValue.substring(i, charValue.length()));
            }else{
                charVal[counter] = (charValue.substring(i, i + 30));                
                counter++;
            }
        }
        
        BigInteger charValParmSeq = BigInteger.valueOf(3);
        for (int i = 0; i < 7; i++) {            
            if (StringUtilities.notEmptyOrBlank(charVal[i])) {
                caseLogMsgParmDto = new CaseLogMessageParameter_DTO();
                caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, charValParmSeq));
                caseLogMsgParmDto.setMessageParameter(charVal[i].trim());        
                caseLog.getMessageParameters().add(caseLogMsgParmDto, charValParmSeq);
            }
            charValParmSeq = charValParmSeq.add(BigInteger.ONE);
        }
        
    }   

    @Override
    protected void extraSoftParameterValidations(boolean arg0) {

        // Get algorithm code
        algCodeStr = this.getAlgorithm().getId().getIdValue().trim();
        
        // Characteristic Type for Inbound Corrected Field Code
        inboundCorrectedFieldCodeCharType = this.getCharacteristicTypeForInboundCorrectedFieldCode();
        validateChar(inboundCorrectedFieldCodeCharType, 
                "Characteristic Type for Inbound Corrected Field Code", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Inbound Corrected Exception Status
        inboundCorrectedExceptionStatusCharType = this.getCharacteristicTypeForInboundCorrectedExceptionStatus();
        validateChar(inboundCorrectedExceptionStatusCharType, 
                "Characteristic Type for Inbound Corrected Exception Status", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Inbound Corrected Exception Status Date
        inboundCorrectedExceptionStatusDateCharType = this.getCharacteristicTypeForInboundCorrectedExceptionStatusDate();
        validateChar(inboundCorrectedExceptionStatusDateCharType, 
                "Characteristic Type for Inbound Corrected Exception Status Date", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Inbound Uncorrected Field Code
        inboundUncorrectedFieldCodeCharType = this.getCharacteristicTypeForInboundUncorrectedFieldCode();
        validateChar(inboundUncorrectedFieldCodeCharType, 
                "Characteristic Type for Inbound Uncorrected Field Code", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Inbound Uncorrected Exception Status
        inboundUncorrectedExceptionStatusCharType = this.getCharacteristicTypeForInboundUncorrectedExceptionStatus();
        validateChar(inboundUncorrectedExceptionStatusCharType, 
                "Characteristic Type for Inbound Uncorrected Exception Status", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Inbound Uncorrected Exception Status Date
        inboundUncorrectedExceptionStatusDateCharType = this.getCharacteristicTypeForInboundUncorrectedExceptionStatusDate();
        validateChar(inboundUncorrectedExceptionStatusDateCharType, 
                "Characteristic Type for Inbound Uncorrected Exception Status Date", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Corrected Field Code
        correctedFieldCodeCharType = this.getCharacteristicTypeForCorrectedFieldCode();
        validateChar(correctedFieldCodeCharType, 
                "Characteristic Type for Corrected Field Code", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Corrected Exception Status
        correctedExceptionStatusCharType = this.getCharacteristicTypeForCorrectedExceptionStatus();
        validateChar(correctedExceptionStatusCharType, 
                "Characteristic Type for Corrected Exception Status", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Corrected Exception Status Date
        correctedExceptionStatusDateCharType = this.getCharacteristicTypeForCorrectedExceptionStatusDate();
        validateChar(correctedExceptionStatusDateCharType, 
                "Characteristic Type for Corrected Exception Status Date", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Uncorrected Field Code
        uncorrectedFieldCodeCharType = this.getCharacteristicTypeForUncorrectedFieldCode();
        validateChar(uncorrectedFieldCodeCharType, 
                "Characteristic Type for Uncorrected Field Code", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Uncorrected Exception Status
        uncorrectedExceptionStatusCharType = this.getCharacteristicTypeForUncorrectedExceptionStatus();
        validateChar(uncorrectedExceptionStatusCharType, 
                "Characteristic Type for Uncorrected Exception Status", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Uncorrected Exception Status Date                
        uncorrectedExceptionStatusDateCharType = this.getCharacteristicTypeForUncorrectedExceptionStatusDate();
        validateChar(uncorrectedExceptionStatusDateCharType, 
                "Characteristic Type for Uncorrected Exception Status Date", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Main Field Code
        mainFieldCodeCharType = this.getCharacteristicTypeForMainFieldCode();
        validateChar(mainFieldCodeCharType, 
                "Characteristic Type for Main Field Code", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Main Exception Status
        mainExceptionStatusCharType = this.getCharacteristicTypeForMainExceptionStatus();
        validateChar(mainExceptionStatusCharType, 
                "Characteristic Type for Main Exception Status", 
                CharacteristicEntityLookup.constants.CASE);
        
        // Characteristic Type for Main Exception Status Date        
        mainExceptionStatusDateCharType = this.getCharacteristicTypeForMainExceptionStatusDate();
        validateChar(mainExceptionStatusDateCharType, 
                "Characteristic Type for Main Exception Status Date", 
                CharacteristicEntityLookup.constants.CASE);    

        // Manual Review Transition Condition
        manualReviewTransitionCondition = (TransitionConditionLookup) this.getManualReviewTransitionCondition();
        
    }
    
    private void validateChar(CharacteristicType charType, String parmDescr, CharacteristicEntityLookup entity) {

        CharacteristicEntity_Id charEntity_Id = new CharacteristicEntity_Id(charType, entity);
        if (isNull(charEntity_Id.getEntity())){
            addError(CustomMessageRepositoryMDC.NI0007_5_4_charTypeInvForEntity(
                    algCodeStr, 
                    parmDescr, 
                    charType.getId().getIdValue().trim(), 
                    entity.getLookupValue().fetchLanguageDescription().trim()));
        }
    }   

}
