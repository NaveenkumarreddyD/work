/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Custom Post Route Bill Extract Algorithm
 * 
 *           
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2021-03-19   RDizon     CCB027. Initial version. Duplicate and optimized 
 *                         version of the existing CM-BLEX algorithm.
 * 2021-04-28   RDizon     CCB027. Add CIS Division Characteristic Type soft 
 *                         parameter. Add OCR Scan Line.
 * 2021-06-07   RDizon     CCB027.Issue2. Remove consecutive printing 
 *                         of copies.
 * 2021-06-22	JMeden	   CCB027. Redevelopment of Bill Extract. Calling
 * 						   the new Business Component bill extract process.
 * 2021-07-01   NMendo     CCB027. Added transportation parameters. 
 * 2021-10-21	JMeden	   Defect 4604495. Added Check Reservation Charge
 * 						   Parameter
 *************************************************************************/
package com.splwg.cm.domain.admin.billRouteType.algorithm.billExtract;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;

import com.splwg.base.api.batch.HibernateCacheHelper;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.domain.batch.batchControl.BatchControl;
import com.splwg.base.domain.common.algorithm.Algorithm;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.lookup.LookupField;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.domain.report.reportDefinition.ReportDefinition;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.billRouteType.algorithm.billExtract.BillExtractAlgorithmSpot;
import com.splwg.ccb.domain.admin.contractQuantityType.entity.ContractQuantityType;
import com.splwg.ccb.domain.admin.contractQuantityType.entity.ContractQuantityType_Id;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.common.fileHelper.FileHelper;
import com.splwg.ccb.domain.rate.rateSchedule.entity.RateSchedule_Id;
import com.splwg.cm.domain.common.customBusinessComponent.CmBillExtractRecordsBuild;
import com.splwg.cm.domain.common.customBusinessComponent.CmBillRecord;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.LoggedException;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

// Start Change - JMeden - Defect 4604495 - 2021-10-21
///**
// * @author RDizon
// *
//@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = validateParameterSwitch, required = true, type = boolean)
// *            , @AlgorithmSoftParameter (entityName = lookupField, name = billPrintHeaderDescriptionsLookupFieldName, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = billCorrectionPeriodHeaderLookupValue, required = true, type = string)
// *            , @AlgorithmSoftParameter (name = otherChargesHeaderLookupValue, required = true, type = string)
// *            , @AlgorithmSoftParameter (name = customerPaymentHeaderLookupValue, required = true, type = string)
// *            , @AlgorithmSoftParameter (name = pledgePaymentHeaderLookupValue, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = serviceQuantityIdentifier, name = btuFactorSQI, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = serviceType, name = serviceTypeForMetered, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = serviceType, name = serviceTypeForUnmetered, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = unitOfMeasure, name = propaneBillableUOM, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = billMessageType, name = severanceCNPBillMessageType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = remitToCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = defaultRemitTo, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = rateClassDescriptionCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = utilityChargesHeadersCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = taxingCommunityPremiseCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = taxingCommunityBillLineCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = grossAmountCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = latePaymentAdjustmentCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = pledgePaymentCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = dollarHelpSACharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = billCalcLinePriorityCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = additionalHistogramUOMSATypeCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = additionalHistogramSQISATypeCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = contractNumberSACharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = schoolAggregationAccountCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = schoolAggregationAccountCharValue, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = budgetPaymentArrangementCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = rateClassCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = cutDateCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = severanceAmountCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = cisDivisionCompanyCodeCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = transportationRates, required = true, type = string)
// *            , @AlgorithmSoftParameter (name = ratesWithPrintFlagOverride, required = true, type = string)
// *            , @AlgorithmSoftParameter (name = firmQuantityTypeCodes, required = true, type = string)
// *            , @AlgorithmSoftParameter (name = interruptibleQuantityTypeCodes, required = true, type = string)})
// */
/**
 * @author RDizon
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = validateParameterSwitch, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (entityName = lookupField, name = billPrintHeaderDescriptionsLookupFieldName, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = billCorrectionPeriodHeaderLookupValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = otherChargesHeaderLookupValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = customerPaymentHeaderLookupValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = pledgePaymentHeaderLookupValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = serviceQuantityIdentifier, name = btuFactorSQI, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = serviceType, name = serviceTypeForMetered, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = serviceType, name = serviceTypeForUnmetered, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = unitOfMeasure, name = propaneBillableUOM, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = severanceCNPBillMessageType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = remitToCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = defaultRemitTo, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = rateClassDescriptionCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = utilityChargesHeadersCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = taxingCommunityPremiseCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = taxingCommunityBillLineCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = grossAmountCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = latePaymentAdjustmentCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = pledgePaymentCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = dollarHelpSACharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = billCalcLinePriorityCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = additionalHistogramUOMSATypeCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = additionalHistogramSQISATypeCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = contractNumberSACharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = schoolAggregationAccountCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = schoolAggregationAccountCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = budgetPaymentArrangementCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = rateClassCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = cutDateCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = severanceAmountCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = cisDivisionCompanyCodeCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = transportationRates, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = ratesWithPrintFlagOverride, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = firmQuantityTypeCodes, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = interruptibleQuantityTypeCodes, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = contractQuantityType, name = reservationChargeConQty, required = true, type = entity)})
 */
// End Change - JMeden - Defect 4604495 - 2021-10-21

public class CmBillExtractAlgComp_Impl 
        extends CmBillExtractAlgComp_Gen 
        implements BillExtractAlgorithmSpot {

    Logger logger = LoggerFactory.getLogger(this.getClass());
    
    // Hard Parameters
    private Bool hpIsBillSkipped;
    private Bool hpIsXmlFile;
    private ReportDefinition hpReportDefinition;
    private BigInteger hpReturnCode;
    @SuppressWarnings("unused")
    private BatchControl hpBatchControl;
    @SuppressWarnings("unused")
    private BigInteger hpBatchNumber;
    @SuppressWarnings("unused")
    private BigInteger hpBatchReRunNumber;
    @SuppressWarnings("unused")
    private BigInteger hpBatchThreadCount;
    @SuppressWarnings("unused")
    private BigInteger hpBatchThreadNumber;
    private Bill hpBill;
    @SuppressWarnings("unused")
    private BigInteger hpBillCount;
    @SuppressWarnings("unused")
    private String hpEndBillIdStr;
    @SuppressWarnings("unused")
    private Algorithm hpExtractAlgorithm;
    @SuppressWarnings("unused")
    private DateTime hpExtractDateTime;
    private String hpExtractFileName;
    @SuppressWarnings("unused")
    private FileHelper hpFileHelper;
    @SuppressWarnings("unused")
    private Bool hpIsWriteSummary;
    private BigInteger hpNumberOfCopies;
    private BigInteger hpSequenceNumber;
    @SuppressWarnings("unused")
    private String hpStartBillId;
    @SuppressWarnings("unused")
    private Bill hpToBill;
    
    // Soft Parameters
    private Bool parmValidateParmSw;
    private LookupField parmLookupFieldBillPrintHeaderDescr;
    private String parmLookupValueBillCorrectionPeriodHeader;
    private String parmLookupValueOtherChargesHeader;
    private String parmLookupValueCustomerPaymentHeader;
    private String parmLookupValuePledgePaymentHeader;
    private CharacteristicType parmCharTypeRemitTo;
    private String parmCharValDefaultRemitTo;
    private ServiceQuantityIdentifier parmSqiBTUFactor;
    private CharacteristicType parmCharTypeRateClassDescription;
    private CharacteristicType parmCharTypeUtilityChargesHeaders;
    private CharacteristicType parmCharTypeTaxingCommunityPremise;
    private CharacteristicType parmCharTypeTaxingCommunityBillLine;
    private CharacteristicType parmCharTypeGrossAmount;
    private CharacteristicType parmCharTypeLatePaymentAdjustment;
    private CharacteristicType parmCharTypePledgePayment;
    private ServiceType parmServiceTypeForMetered;
    private ServiceType parmServiceTypeForUnmetered;
    private CharacteristicType parmCharTypeDollarHelpSA;
    private CharacteristicType parmCharTypeBillCalcLinePriority;
    private CharacteristicType parmCharTypeAdditionalHistogramUOMSAType;
    private CharacteristicType parmCharTypeAdditionalHistogramSQISAType;
    private CharacteristicType parmCharTypeContractNumberSA;
    private UnitOfMeasure parmUOMPropaneBillable;
    private CharacteristicType parmCharTypeSchoolAggregationAccount;
    private String parmCharValueSchoolAggregationAccount;
    private CharacteristicType parmCharTypeBudgetPaymentArrangement;
    private CharacteristicType parmCharTypeRateClass;
    private CharacteristicType parmCharTypeCutDate;
    private CharacteristicType parmCharTypeSeveranceAmount;
    private BillMessageType parmSeveranceCNPBillMessage;
    private ToDoType parmToDoType;
    // Start Add - RDizon - CCB027.1 - 2021-04-28
    private CharacteristicType parmCharTypeCisDivisionCompanyCode;
    // End Add - RDizon - CCB027.1 - 2021-04-28
    // Start Add - NMendo - CCB027 - 2021-07-01
    private String parmTransportationRates;
    private String parmRatesWithPrintFlagOverride;
    private String parmFirmQuantityTypeCodes;
    private String parmInterruptibleQuantityTypeCodes;
    // End Add - NMendo - CCB027 - 2021-07-01
    // Start Add - JMeden - Defect 4604495 - 2021-10-21
    private ContractQuantityType parmReservationChargeConQty;
    // End Add - JMeden - Defect 4604495 - 2021-10-21
    
    // Constants
    private static final String COMMA = ",";
    
    @Override
    public Bool getIsBillSkipped() {
        return hpIsBillSkipped;
    }

    @Override
    public Bool getIsXmlFile() {
        return hpIsXmlFile;
    }

    @Override
    public ReportDefinition getReportDefinition() {
        return hpReportDefinition;
    }

    @Override
    public BigInteger getReturnCode() {
        return hpReturnCode;
    }

    @Override
    public void setBatchControl(BatchControl batchControl) {
        hpBatchControl = batchControl;
    }

    @Override
    public void setBatchNumber(BigInteger batchNumber) {
        hpBatchNumber = batchNumber;
    }

    @Override
    public void setBatchRerunNumber(BigInteger batchRerunNumber) {
        hpBatchReRunNumber = batchRerunNumber;
    }

    @Override
    public void setBatchThreadCount(BigInteger batchThreadCount) {
        hpBatchThreadCount = batchThreadCount;
    }

    @Override
    public void setBatchThreadNumber(BigInteger batchThreadNumber) {
        hpBatchThreadNumber = batchThreadNumber;
    }

    @Override
    public void setBill(Bill bill) {
        hpBill = bill;
    }

    @Override
    public void setBillCount(BigInteger billCount) {
        hpBillCount = billCount;
    }

    @Override
    public void setEndBillId(String endBillId) {
        hpEndBillIdStr = endBillId;
    }

    @Override
    public void setExtractAlgorithm(Algorithm extractAlgorightm) {
        hpExtractAlgorithm = extractAlgorightm;
    }

    @Override
    public void setExtractDateTime(DateTime extractDttm) {
        hpExtractDateTime = extractDttm;
    }

    @Override
    public void setExtractFileName(String extractFileName) {
        hpExtractFileName = extractFileName;
    }

    @Override
    public void setFileHelper(FileHelper fileHelper) {
        hpFileHelper = fileHelper;
    }

    @Override
    public void setIsWriteSummary(Bool isWriteSummary) {
        hpIsWriteSummary = isWriteSummary;
    }

    @Override
    public void setNumberOfCopies(BigInteger nbrOfCopies) {
        hpNumberOfCopies = nbrOfCopies;
    }

    @Override
    public void setSequenceNumber(BigInteger sequenceNbr) {
        hpSequenceNumber = sequenceNbr;
    }

    @Override
    public void setStartBillId(String startBillId) {
        hpStartBillId = startBillId;
    }

    @Override
    public void setToBill(Bill toBill) {
        hpToBill = toBill;
    }
    
    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        // Retrieve all soft parameters
        parmValidateParmSw = this.getValidateParameterSwitch(); 
        parmLookupFieldBillPrintHeaderDescr = this.getBillPrintHeaderDescriptionsLookupFieldName();    
        parmLookupValueBillCorrectionPeriodHeader = this.getBillCorrectionPeriodHeaderLookupValue();   
        parmLookupValueOtherChargesHeader = this.getOtherChargesHeaderLookupValue();
        parmLookupValueCustomerPaymentHeader = this.getCustomerPaymentHeaderLookupValue();
        parmLookupValuePledgePaymentHeader = this.getPledgePaymentHeaderLookupValue();
        parmSqiBTUFactor = this.getBtuFactorSQI();
        parmServiceTypeForMetered = this.getServiceTypeForMetered();
        parmServiceTypeForUnmetered = this.getServiceTypeForUnmetered();
        parmUOMPropaneBillable = this.getPropaneBillableUOM();
        parmSeveranceCNPBillMessage = this.getSeveranceCNPBillMessageType();
        parmCharTypeRemitTo = this.getRemitToCharType();
        parmCharValDefaultRemitTo = this.getDefaultRemitTo();
        parmCharTypeRateClassDescription = this.getRateClassDescriptionCharType();
        parmCharTypeUtilityChargesHeaders = this.getUtilityChargesHeadersCharType();
        parmCharTypeTaxingCommunityPremise = this.getTaxingCommunityPremiseCharType();
        parmCharTypeTaxingCommunityBillLine = this.getTaxingCommunityBillLineCharType();
        parmCharTypeGrossAmount = this.getGrossAmountCharType();
        parmCharTypeLatePaymentAdjustment = this.getLatePaymentAdjustmentCharType();
        parmCharTypePledgePayment = this.getPledgePaymentCharType();
        parmCharTypeDollarHelpSA = this.getDollarHelpSACharType();
        parmCharTypeBillCalcLinePriority = this.getBillCalcLinePriorityCharType();
        parmCharTypeAdditionalHistogramUOMSAType = this.getAdditionalHistogramUOMSATypeCharType();
        parmCharTypeAdditionalHistogramSQISAType = this.getAdditionalHistogramSQISATypeCharType();
        parmCharTypeContractNumberSA = this.getContractNumberSACharType();
        parmCharTypeSchoolAggregationAccount = this.getSchoolAggregationAccountCharType();
        parmCharValueSchoolAggregationAccount = this.getSchoolAggregationAccountCharValue();
        parmCharTypeBudgetPaymentArrangement = this.getBudgetPaymentArrangementCharType();
        parmCharTypeRateClass = this.getRateClassCharType();
        parmCharTypeCutDate = this.getCutDateCharType();
        parmCharTypeSeveranceAmount = this.getSeveranceAmountCharType();
        parmToDoType = this.getToDoType();
        // Start Add - RDizon - CCB027.1 - 2021-04-28
        parmCharTypeCisDivisionCompanyCode = this.getCisDivisionCompanyCodeCharType();
        // End Add - RDizon - CCB027.1 - 2021-04-28
        // Start Add - NMendo - CCB027 - 2021-07-01
        parmTransportationRates = this.getTransportationRates();
        parmRatesWithPrintFlagOverride = this.getRatesWithPrintFlagOverride();
        parmFirmQuantityTypeCodes = this.getFirmQuantityTypeCodes();
        parmInterruptibleQuantityTypeCodes = this.getInterruptibleQuantityTypeCodes();
        // End Add - NMendo - CCB027 - 2021-07-01
        // Start Add - JMeden - Defect 4604495 - 2021-10-21
        parmReservationChargeConQty = this.getReservationChargeConQty();
        // End Add - JMeden - Defect 4604495 - 2021-10-21
        
        
        
        
        if (parmValidateParmSw.isTrue()) {
            // Validate Parameter 30: Bill Correction Period Header Lookup Value
            validateLookupValue(parmLookupFieldBillPrintHeaderDescr, 
                    parmLookupValueBillCorrectionPeriodHeader, "Bill Correction Period Header Lookup Value");
            
            // Validate Parameter 40: Other Charges Header Lookup Value
            validateLookupValue(parmLookupFieldBillPrintHeaderDescr, 
                    parmLookupValueOtherChargesHeader, "Other Charges Header Lookup Value");
            
            // Validate Parameter 50: Customer Payment Header Lookup Value
            validateLookupValue(parmLookupFieldBillPrintHeaderDescr,
                    parmLookupValueCustomerPaymentHeader, "Customer Payment Header Lookup Value");
            
            // Validate Parameter 60: Pledge Payment Header Lookup Value
            validateLookupValue(parmLookupFieldBillPrintHeaderDescr,
                    parmLookupValuePledgePaymentHeader, "Pledge Payment Header Lookup Value");
            
            // Validate Parameter 120: Remit To Characteristic Type
            validateCharacteristicType(parmCharTypeRemitTo, 
                    CharacteristicEntityLookup.constants.ACCOUNT, "Remit To Characteristic Type");
            validateCharacteristicType(parmCharTypeRemitTo, 
                    CharacteristicEntityLookup.constants.CIS_DIVISION, "Remit To Characteristic Type");
            
            // Validate Parameter 130: Default Remit To Characteristic Value
            validateCharacteristicValue(parmCharTypeRemitTo, parmCharValDefaultRemitTo, "Default Remit To Characteristic Value");
            
            // Retrieve Parameter 140: Rate Class Description Characteristic Type
            validateCharacteristicType(parmCharTypeRateClassDescription,
                    CharacteristicEntityLookup.constants.RATE_COMPONENT, "Rate Class Description Characteristic Type");
            validateCharacteristicType(parmCharTypeRateClassDescription, 
                    CharacteristicEntityLookup.constants.BILL_SEGMENT_CALC_LINE, "Rate Class Description Characteristic Type");
            
            // Validate Parameter 150: Utility Charges Headers Characteristic Type
            validateCharacteristicType(parmCharTypeUtilityChargesHeaders,
                    CharacteristicEntityLookup.constants.RATE_COMPONENT, "Utility Charges Headers Characteristic Type");
            validateCharacteristicType(parmCharTypeUtilityChargesHeaders, 
                    CharacteristicEntityLookup.constants.BILL_SEGMENT_CALC_LINE, "Utility Charges Headers Characteristic Type");
            
            // Validate Parameter 160: Taxing Community Premise Characteristic Type
            validateCharacteristicType(parmCharTypeTaxingCommunityPremise, 
                    CharacteristicEntityLookup.constants.PREMISE, "Taxing Community Premise Characteristic Type");          
            
            // Validate Parameter 170: Taxing Community Bill Line Characteristic Type
            validateCharacteristicType(parmCharTypeTaxingCommunityBillLine, 
                    CharacteristicEntityLookup.constants.RATE_COMPONENT, "Taxing Community Bill Line Characteristic Type");
            validateCharacteristicType(parmCharTypeTaxingCommunityBillLine, 
                    CharacteristicEntityLookup.constants.BILL_SEGMENT_CALC_LINE, "Taxing Community Bill Line Characteristic Type");         
            
            // Validate Parameter 180: Gross Amount Characteristic Type
            validateCharacteristicType(parmCharTypeGrossAmount, 
                    CharacteristicEntityLookup.constants.RATE_COMPONENT, "Gross Amount Characteristic Type");
            validateCharacteristicType(parmCharTypeGrossAmount, 
                    CharacteristicEntityLookup.constants.BILL_SEGMENT_CALC_LINE, "Gross Amount Characteristic Type");
            
            // Validate Parameter 190: Late Payment Adjustment Characteristic Type
            validateCharacteristicType(parmCharTypeLatePaymentAdjustment, 
                    CharacteristicEntityLookup.constants.ADJUSTMENT_TYPE, "Late Payment Adjustment Characteristic Type");
            
            // Validate Parameter 200: Pledge Payment Characteristic Type
            validateCharacteristicType(parmCharTypePledgePayment, 
                    CharacteristicEntityLookup.constants.PAYMENT, "Pledge Payment Characteristic Type");            
            
            // Validate Parameter 210: Dollar Help SA Characteristic Type
            validateCharacteristicType(parmCharTypeDollarHelpSA, 
                    CharacteristicEntityLookup.constants.SERVICE_AGREEMENT_TYPE, "Dollar Help SA Characteristic Type");
            
            // Validate Parameter 220: Bill Calc Line Priority Characteristic Type
            validateCharacteristicType(parmCharTypeBillCalcLinePriority, 
                    CharacteristicEntityLookup.constants.RATE_COMPONENT, "Bill Calc Line Priority Characteristic Type");
            validateCharacteristicType(parmCharTypeBillCalcLinePriority, 
                    CharacteristicEntityLookup.constants.BILL_SEGMENT_CALC_LINE, "Bill Calc Line Priority Characteristic Type");
            
            // Validate Parameter 230: Additional Histogram UOM SA Type Characteristic Type
            validateCharacteristicType(parmCharTypeAdditionalHistogramUOMSAType, 
                    CharacteristicEntityLookup.constants.SERVICE_AGREEMENT_TYPE, "Additional Histogram UOM SA Type Characteristic Type");
            
            // Validate Parameter 240: Additional Histogram SQI SA Type Characteristic Type
            validateCharacteristicType(parmCharTypeAdditionalHistogramSQISAType, 
                    CharacteristicEntityLookup.constants.SERVICE_AGREEMENT_TYPE, "Additional Histogram SQI SA Type Characteristic Type");
            
            // Validate Parameter 250: Contract Number SA Characteristic Type
            validateCharacteristicType(parmCharTypeContractNumberSA, 
                    CharacteristicEntityLookup.constants.SERVICE_AGREEMENT, "Contract Number SA Characteristic Type");
            
            // Validate Parameter 260: School Aggregation Account Characteristic Type
            validateCharacteristicType(parmCharTypeSchoolAggregationAccount, 
                    CharacteristicEntityLookup.constants.ACCOUNT, "School Aggregation Account Characteristic Type");
            
            // Validate Parameter 270: School Aggregation Account Characteristic Value
            validateCharacteristicValue(parmCharTypeSchoolAggregationAccount, 
                    parmCharValueSchoolAggregationAccount, "School Aggregation Account Characteristic Value");
            
            // Validate Parameter 280: Budget Payment Arrangement Characteristic Type
            validateCharacteristicType(parmCharTypeBudgetPaymentArrangement, 
                    CharacteristicEntityLookup.constants.SERVICE_AGREEMENT_TYPE, "Budget Payment Arrangement Characteristic Type");
            
            // Validate Parameter 290: Rate Class Characteristic Type
            validateCharacteristicType(parmCharTypeRateClass, 
                    CharacteristicEntityLookup.constants.SERVICE_AGREEMENT, "Rate Class Characteristic Type");
            
            // Validate Parameter 300: Cut Date Characteristic Type
            validateCharacteristicType(parmCharTypeCutDate, 
                    CharacteristicEntityLookup.constants.BILL, "Cut Date Characteristic Type");
            
            // Validate Parameter 310: Severance Amount Characteristic Type
            validateCharacteristicType(parmCharTypeSeveranceAmount, 
                    CharacteristicEntityLookup.constants.BILL, "Severance Amount Characteristic Type");
            
            // Start Add - RDizon - CCB027.1 - 2021-04-28
            // Validate Parameter 330: CIS Division Company Code Characteristic Type
            validateCharacteristicType(parmCharTypeCisDivisionCompanyCode, 
                    CharacteristicEntityLookup.constants.CIS_DIVISION, "CIS Division Company Code Characteristic Type");
            // End Add - RDizon - CCB027.1 - 2021-04-28
            
            // Start Add - NMendo - CCB027 - 2021-07-01
            // Validate Parameter 340: Transportation Rates
            validateRateSchedules(parmTransportationRates, "Transportation Rates");
            
            // Validate Parameter 350: Rates with Print Flag Override
            validateRateSchedules(parmRatesWithPrintFlagOverride, "Rates with Print Flag Override");
            
            // Validate Parameter 360: Firm Contract Quantity Types
            validateContractQuantityTypes(parmFirmQuantityTypeCodes, "Firm Contract Quantity Types");
            
            // Validate Parameter 370: Interruptible Contract Quantity Types
            validateContractQuantityTypes(parmInterruptibleQuantityTypeCodes, "Interruptible Contract Quantity Types");
            // End Add - NMendo - CCB027 - 2021-07-01
        }
        
    }
    
    private void validateLookupValue(LookupField lookupField, String lookupValue, String parmDescr) {
        
        LookupValue_Id lookupValueID = new LookupValue_Id(lookupField, lookupValue);
        if (isNull(lookupValueID.getEntity())) {
            addError(CustomMessageRepositorySpireOne.CCB027_AlgorithmParameterMustBeValidLookupValueForLookupField(
                            this.getAlgorithmId().getTrimmedValue(),
                            parmDescr,
                            lookupValue,
                            lookupField.getId().getTrimmedValue()));
        }       
    }
    
    private void validateCharacteristicType(CharacteristicType charType, CharacteristicEntityLookup entity, String parmDescr) {
        CharacteristicEntity_Id charEntityID = new CharacteristicEntity_Id(charType, entity);
        if (isNull(charEntityID.getEntity())) {
            addError(CustomMessageRepositorySpireOne.CCB027_AlgorithmParameterMustBeValidCharTypeForEntity(
                            this.getAlgorithmId().getTrimmedValue(), 
                            parmDescr,
                            charType.getId().getTrimmedValue(), 
                            entity.getLookupValue().fetchLanguageDescription().trim()));
        }       
    }
    
    private void validateCharacteristicValue(CharacteristicType charType, String charValue, String parmDescr) {
        if (charType.getCharacteristicType().isPredefinedValue()) {
            CharacteristicValue_Id charValueID = new CharacteristicValue_Id(charType, charValue);
            if (isNull(charValueID.getEntity())) {
                addError(CustomMessageRepositorySpireOne.CCB027_AlgorithmParameterMustBeValidCharValueForCharType(
                                this.getAlgorithmId().getTrimmedValue(), 
                                parmDescr,
                                charValue,
                                charType.getId().getTrimmedValue()));
            }
        }
    }
    
    // Start Add - NMendo - CCB027 - 2021-07-01
    /**
     * Validate comma-delimited list of Rate Schedule.
     * @param rateSchedules
     * @param parmDescr
     */
    private void validateRateSchedules(String rateSchedules, String parmDescr) {
    	if(notNull(rateSchedules)) {
    		String[] splittedInput = rateSchedules.trim().split(COMMA);
    		for(String inputStr : splittedInput) {
    			RateSchedule_Id rsId = new RateSchedule_Id(inputStr.trim());
    			if(isNull(rsId.getEntity())) {
    				addError(CustomMessageRepositorySpireOne.CCB027_AlgorithmParameterRateScheduleInvalid(
    						this.getAlgorithmId().getTrimmedValue(), parmDescr, inputStr.trim()));
    			}
    		}
    	}
    }
    
    /**
     * Validate comma-delimited list of Contract Quantity Types.
     * @param rateSchedules
     * @param parmDescr
     */
    private void validateContractQuantityTypes(String contractQtyTypes, String parmDescr) {
    	if(notNull(contractQtyTypes)) {
    		String[] splittedInput = contractQtyTypes.trim().split(COMMA);
    		for(String inputStr : splittedInput) {
    			ContractQuantityType_Id rsId = new ContractQuantityType_Id(inputStr.trim());
    			if(isNull(rsId.getEntity())) {
    				addError(CustomMessageRepositorySpireOne.CCB027_AlgorithmParameterContractQuantityTypeInvalid(
    						this.getAlgorithmId().getTrimmedValue(), parmDescr, inputStr.trim()));
    			}
    		}
    	}
    }
    // End Add - NMendo - CCB027 - 2021-07-01
    
    @Override
    public void invoke() {
        // Initialize the Build Bill Extract 
    	// Start Change - JMeden - CCB027 - 2021-06-22
        //CmBuildBillExtractRecords buildBillExtract = CmBuildBillExtractRecords.Factory.newInstance();
    	CmBillExtractRecordsBuild buildBillExtract = CmBillExtractRecordsBuild.Factory.newInstance();
        // End Change - JMeden - CCB027 - 2021-06-22
        
        // Set hard parameters
        buildBillExtract.setHpBill(hpBill);
        // Start Delete - JMeden - CCB027 - 2021-06-22
        //buildBillExtract.setHpIsBillSkipped(hpIsBillSkipped);
        // End Delete - JMeden - CCB027 - 2021-06-22
        buildBillExtract.setHpSequenceNumber(hpSequenceNumber);

        // Set soft parameters
        buildBillExtract.setLookupFieldBillPrintHeaderDescr(parmLookupFieldBillPrintHeaderDescr);
        buildBillExtract.setLookupValueBillCorrectionPeriodHeader(parmLookupValueBillCorrectionPeriodHeader);
        buildBillExtract.setLookupValueOtherChargesHeader(parmLookupValueOtherChargesHeader);
        buildBillExtract.setLookupValueCustomerPaymentHeader(parmLookupValueCustomerPaymentHeader);
        buildBillExtract.setLookupValuePledgePaymentHeader(parmLookupValuePledgePaymentHeader);
        buildBillExtract.setSqiBTUFactor(parmSqiBTUFactor);
        buildBillExtract.setServiceTypeForMetered(parmServiceTypeForMetered);
        buildBillExtract.setServiceTypeForUnmetered(parmServiceTypeForUnmetered);
        buildBillExtract.setUOMPropaneBillable(parmUOMPropaneBillable);
        buildBillExtract.setSeveranceCNPBillMessage(parmSeveranceCNPBillMessage);
        buildBillExtract.setCharTypeRemitTo(parmCharTypeRemitTo);
        buildBillExtract.setCharValDefaultRemitTo(parmCharValDefaultRemitTo);
        buildBillExtract.setCharTypeRateClassDescription(parmCharTypeRateClassDescription);
        buildBillExtract.setCharTypeUtilityChargesHeaders(parmCharTypeUtilityChargesHeaders);
        buildBillExtract.setCharTypeTaxingCommunityPremise(parmCharTypeTaxingCommunityPremise);
        buildBillExtract.setCharTypeTaxingCommunityBillLine(parmCharTypeTaxingCommunityBillLine);
        buildBillExtract.setCharTypeGrossAmount(parmCharTypeGrossAmount);
        buildBillExtract.setCharTypeLatePaymentAdjustment(parmCharTypeLatePaymentAdjustment);
        buildBillExtract.setCharTypePledgePayment(parmCharTypePledgePayment);
        buildBillExtract.setCharTypeDollarHelpSA(parmCharTypeDollarHelpSA);;
        buildBillExtract.setCharTypeBillCalcLinePriority(parmCharTypeBillCalcLinePriority);
        buildBillExtract.setCharTypeAdditionalHistogramUOMSAType(parmCharTypeAdditionalHistogramUOMSAType);
        buildBillExtract.setCharTypeAdditionalHistogramSQISAType(parmCharTypeAdditionalHistogramSQISAType);
        buildBillExtract.setCharTypeContractNumberSA(parmCharTypeContractNumberSA);
        buildBillExtract.setCharTypeSchoolAggregationAccount(parmCharTypeSchoolAggregationAccount);
        buildBillExtract.setCharValueSchoolAggregationAccount(parmCharValueSchoolAggregationAccount);
        buildBillExtract.setCharTypeBudgetPaymentArrangement(parmCharTypeBudgetPaymentArrangement);
        buildBillExtract.setCharTypeRateClass(parmCharTypeRateClass);
        buildBillExtract.setCharTypeCutDate(parmCharTypeCutDate);
        buildBillExtract.setCharTypeSeveranceAmount(parmCharTypeSeveranceAmount);
        buildBillExtract.setToDoType(parmToDoType);
        // Start Add - RDizon - CCB027.1 - 2021-04-28
        buildBillExtract.setCharTypeCisDivisionCompanyCode(parmCharTypeCisDivisionCompanyCode);
        // End Add - RDizon - CCB027.1 - 2021-04-28
        // Start Add - NMendo - CCB027 - 2021-07-01
        buildBillExtract.setTransportationRates(parmTransportationRates);
        buildBillExtract.setRatesWithPrintFlagOverride(parmRatesWithPrintFlagOverride);
        buildBillExtract.setFirmQuantityTypeCodes(parmFirmQuantityTypeCodes);
        buildBillExtract.setInterruptibleQuantityTypeCodes(parmInterruptibleQuantityTypeCodes);
        // End Add - NMendo - CCB027 - 2021-07-01
        // Start Add - JMeden - Defect 4604495 - 2021-10-21
        buildBillExtract.setParmReservationChargeConQty(parmReservationChargeConQty);
    	// End Add - JMeden - Defect 4604495 - 2021-10-21
        
        // Call the Bill Extract routine
        // Start Delete - RDizon - CCB027.Issue2 - 2021-06-07
        // List<String> returnedStrings = buildBillExtract.buildBillExtract();
        // 
        // if (returnedStrings.get(0).equalsIgnoreCase("22202")){
        //     logInfo(CustomMessageRepositorySpireOne.CCB027_TotalAmountDueExceedsMaxLength(hpBill.getId().getTrimmedValue()));
        //     return;
        // }
        // End Delete - RDizon - CCB027.Issue2 - 2021-06-07
        
        FileWriter fileWriter = null;
        BufferedWriter bufferedWriter = null;
        try {
            fileWriter = new FileWriter(new File(this.hpExtractFileName), true);
            
            bufferedWriter = new BufferedWriter(fileWriter);
             
            // Start Change - RDizon - CCB027.Issue2 - 2021-06-07
            // Iterator<String> itrStrings = returnedStrings.iterator();
            // 
            // while (itrStrings.hasNext()){
            //     String recordString = itrStrings.next();
            //     
            //     bufferedWriter.write(recordString);
            //     bufferedWriter.newLine();
            // }
            
            // Start Change - JMeden - CCB027 - 2021-06-22
//            for (int x = 1; x <= hpNumberOfCopies.intValue(); x++) {
//                buildBillExtract.setHpNthCopy(BigInteger.valueOf(x));
//                List<String> returnedStrings = buildBillExtract.buildBillExtract();
//
//                if (returnedStrings.get(0).equalsIgnoreCase("22202")){
//                    logInfo(CustomMessageRepositorySpireOne.CCB027_TotalAmountDueExceedsMaxLength(hpBill.getId().getTrimmedValue()));
//                    return;
//                }
//                
//                Iterator<String> itrStrings = returnedStrings.iterator();
//
//                while (itrStrings.hasNext()){
//                    String recordString = itrStrings.next();
//
//                    bufferedWriter.write(recordString);
//                    bufferedWriter.newLine();
//                }
//            }
            
         
            buildBillExtract.buildBillExtract();
            ArrayList<CmBillRecord> returnedStrings = buildBillExtract.getReturnedStrings();

            if (buildBillExtract.getErrorLargeCurBal().isTrue()){
                logInfo(CustomMessageRepositorySpireOne.CCB027_TotalAmountDueExceedsMaxLength(hpBill.getId().getTrimmedValue()));
                return;
            }
            
            Iterator<CmBillRecord> itrStrings = null;
            for (int iCount = 1; iCount <= hpNumberOfCopies.intValue(); iCount++) {
            	itrStrings = returnedStrings.iterator();
            	while (itrStrings.hasNext()){
                    String recordString = itrStrings.next().toPrintLine(Integer.toString(iCount));

                    bufferedWriter.write(recordString);
                    bufferedWriter.newLine();
                }
            }
            // End Change - JMeden - CCB027 - 2021-06-22
            // End Change - RDizon - CCB027.Issue2 - 2021-06-07
            
            bufferedWriter.flush();
        }
        catch (IOException e) {
          throw LoggedException.wrap(logger, "Unexpected IOException", e);
        }
        finally {
            try {
                if (bufferedWriter != null) {
                    bufferedWriter.close();
                }
            }
            catch (IOException e){
                throw LoggedException.wrap(logger, "Unexpected IOException", e);
            }
        }
        
        HibernateCacheHelper.flushAndClear();
    }
}
