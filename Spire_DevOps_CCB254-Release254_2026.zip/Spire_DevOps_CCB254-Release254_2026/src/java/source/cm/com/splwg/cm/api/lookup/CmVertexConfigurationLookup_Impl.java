/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Vertex Configuration Lookup
 *            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2021-01-26   Ravi  	Vertex Integration Initial Version.
 *************************************************************************/

package com.splwg.cm.api.lookup;

/**
 * @author Ravi
 *
 @LookupFieldname (value = XVTX_OPT_TYP_FLG)
 */
public class CmVertexConfigurationLookup_Impl 
    extends CmVertexConfigurationLookup_Gen {

}
