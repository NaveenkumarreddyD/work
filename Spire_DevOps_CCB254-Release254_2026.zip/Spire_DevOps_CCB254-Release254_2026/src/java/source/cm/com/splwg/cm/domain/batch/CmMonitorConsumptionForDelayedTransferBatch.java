/*
 *************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * CCB108: Delayed Transfer Batch
 * This new batch process will be developed to monitor consumption at 
 * vacant premises with connected service points and create a case  if 
 * necessary. The logic will be similar to batch control CM-VPCNC.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2021-02-03   JRaymu/NMendo   CCB108. Initial version.
 * 2024-11-08   JVitug          E-09689. Updated Unit of Measure parameter
 *                              to handle multiple UOMs.
 **************************************************************************
 */
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.serviceScript.ServiceScriptDispatcher;
import com.splwg.base.api.serviceScript.ServiceScriptInstance;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControl;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ConsumptionTypeLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.ReadTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointMeterEventTypeLookup;
import com.splwg.ccb.api.lookup.ServicePointSourceStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointStatusLookup;
import com.splwg.ccb.api.lookup.StatusConditionLookup;
import com.splwg.ccb.cobol.mr.CobolCopybookCICMDBRN;
import com.splwg.ccb.cobol.mr.CobolProgramCIPMDBRN;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.caseType.entity.CharacteristicTypeCaseType;
import com.splwg.ccb.domain.admin.caseType.entity.CharacteristicTypeCaseType_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_Id;
import com.splwg.ccb.domain.todo.common.CaseCreator;
import com.splwg.ccb.domain.todo.data.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_DTO;
import com.splwg.cm.api.lookup.CmQuotePortalParametersLookup;
import com.splwg.cm.domain.common.CmWSDLCallToAMRDataBase;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

//Start Change JVitug - E-09689 - 2024-11-08
///**
// * @author JRaymu
// *
// @BatchJob (modules = {}, rerunnable = false,
// *      softParameters = { @BatchJobSoftParameter (name = VAC_DAYS_THRSHLD, required = true, type = integer)
// *            , @BatchJobSoftParameter (entityName = unitOfMeasure, name = CNSMPTN_UOM, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = USAGE_MAX_SMR, required = true, type = decimal)
// *            , @BatchJobSoftParameter (name = USAGE_MAX_WNTR, required = true, type = decimal)
// *            , @BatchJobSoftParameter (name = FA_TYPE_CD, type = string)
// *            , @BatchJobSoftParameter (name = CIS_DIVISION, required = true, type = string)
// *            , @BatchJobSoftParameter (name = MAX-ERRORS, type = integer)
// *            , @BatchJobSoftParameter (entityName = caseType, name = CASE_TYPE_CD, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = INITIAL_CASE_LIFECYCLE, type = string)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = SP_ID_CHAR, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_RSN_CHAR, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = CASE_RSN_USG, type = string, required = true)
// *            , @BatchJobSoftParameter (name = CASE_RSN_DYS, type = string, required = true)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = PWRST_CHAR, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = PWRST_VAL, type = string, required = true)
// *            , @BatchJobSoftParameter (name = ADDP_RTE_TYPE, type = string, required = true)})
// */
/**
 * @author JRaymu
 *
 @BatchJob (modules = {}, rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (name = VAC_DAYS_THRSHLD, required = true, type = integer)
 *            , @BatchJobSoftParameter (name = CNSMPTN_UOM, required = true, type = string)
 *            , @BatchJobSoftParameter (name = USAGE_MAX_SMR, required = true, type = decimal)
 *            , @BatchJobSoftParameter (name = USAGE_MAX_WNTR, required = true, type = decimal)
 *            , @BatchJobSoftParameter (name = FA_TYPE_CD, type = string)
 *            , @BatchJobSoftParameter (name = CIS_DIVISION, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAX-ERRORS, type = integer)
 *            , @BatchJobSoftParameter (entityName = caseType, name = CASE_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = INITIAL_CASE_LIFECYCLE, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = SP_ID_CHAR, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CASE_RSN_CHAR, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CASE_RSN_USG, type = string, required = true)
 *            , @BatchJobSoftParameter (name = CASE_RSN_DYS, type = string, required = true)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PWRST_CHAR, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = PWRST_VAL, type = string, required = true)
 *            , @BatchJobSoftParameter (name = ADDP_RTE_TYPE, type = string, required = true)})
 */
//End Change JVitug - E-09689 - 2024-11-08
public class CmMonitorConsumptionForDelayedTransferBatch 
		extends CmMonitorConsumptionForDelayedTransferBatch_Gen {

	// Parameters
	private BigInteger parmVacDaysThreshold;
	private String parmFAType;
	private String parmCisDivision;
	private BigInteger parmMaxErrors;
	private CaseType parmCaseType;
	private String parmCaseStatus;
    private CharacteristicType parmSpChar;
    private BigDecimal parmUsageMaxSummer;
    private BigDecimal parmUsageMaxWinter;
	private CharacteristicType parmCaseReasonChar;
	private CharacteristicType parmPowerStatusChar;
    private String faTypes;
    private String cisDivisions;
    private String parmADDPReadRouteType;
    //Start Add JVitug - E-09689 - 2024-11-08
    private String parmConsumptionUOM;
    private String consumptionUOMs;
    //Start Add JVitug - E-09689 - 2024-11-08
	
    private static final String CM_ADDPREAD="CM-ADDP";
	private static final String GROUP_INPUT = "input";
	private static final String GROUP_OUTPUT = "output";
	
	// Constant
	private static final String COMMA_DELIMITER = ",";
    private static final String SINGLE_QUOTE = "'";
    private static final String SLASH_DELIMITER = "/";

	@Override
	public void validateSoftParameters(boolean arg0) {

        BatchControl batchControl = this.getBatchControlId().getEntity();
        parmADDPReadRouteType = this.getParameters().getADDP_RTE_TYPE();
		// Retrieve Batch Parameter 10: Vacant Days Threshold
		parmVacDaysThreshold = this.getParameters().getVAC_DAYS_THRSHLD();
		String parm10Desc = batchControl.getParameterByName("VAC_DAYS_THRSHLD").fetchLanguageDescription();
		cmValidateParmIntegerGreaterThanZero(parmVacDaysThreshold, parm10Desc);
		
		// Retrieve Batch Parameter 30: Max usage summer
		parmUsageMaxSummer = this.getParameters().getUSAGE_MAX_SMR();
		String parm30Desc = batchControl.getParameterByName("USAGE_MAX_SMR").fetchLanguageDescription();
        cmValidateParmDecimalGreaterThanZero(parmUsageMaxSummer, parm30Desc);
        
        // Retrieve Batch Parameter 40: Max usage winter
        parmUsageMaxWinter = this.getParameters().getUSAGE_MAX_WNTR();
        String parm40Desc = batchControl.getParameterByName("USAGE_MAX_WNTR").fetchLanguageDescription();
        cmValidateParmDecimalGreaterThanZero(parmUsageMaxWinter, parm40Desc);
        
        StringBuilder stringBuilder = new StringBuilder();
        int index = 0;
        int listSize = 0;
		// Retrieve Batch Parameter 50: Field Activity Type
		parmFAType = this.getParameters().getFA_TYPE_CD();
		faTypes = SINGLE_QUOTE.concat(SINGLE_QUOTE);
		if(notNull(parmFAType)) {
	        String[] faTypeSplit = parmFAType.split(COMMA_DELIMITER);
	        index = 0;
	        listSize = faTypeSplit.length;
	        for(String faTypeString : faTypeSplit){
	            index++;
	            FieldActivityType faType = new FieldActivityType_Id(faTypeString).getEntity();
	            if(isNull(faType)){
	                // Batch %1: Parameter value (%2) is not a valid Field Activity Type.
	                addError(CustomMessageRepositorySpireOne.CCB108_algParmFATypeInvalid("FA_TYPE_CD", faTypeString));
	            }else{
	                stringBuilder.append(SINGLE_QUOTE);
	                stringBuilder.append(faTypeString);
	                stringBuilder.append(SINGLE_QUOTE);
	                if(index < listSize){
	                    stringBuilder.append(COMMA_DELIMITER);
	                }
	            }
	        }
	        
	        faTypes = stringBuilder.toString();
		}
        
		// Retrieve Batch Parameter 60: CIS Division
		parmCisDivision = this.getParameters().getCIS_DIVISION();
        stringBuilder = new StringBuilder();		
        String[] cisDivisionSplit = parmCisDivision.split(COMMA_DELIMITER);
        index = 0;
        listSize = cisDivisionSplit.length;
        for(String cisDivision : cisDivisionSplit){
            index++;
            CisDivision cisDiv = new CisDivision_Id(cisDivision).getEntity();
            if(isNull(cisDiv)){
                // Batch %1: Parameter value (%2) is not a valid CIS Division.
                addError(CustomMessageRepositorySpireOne.CCB108_algParmCisDivInvalid("CIS_DIVISION", cisDivision));
            }else{
                stringBuilder.append(SINGLE_QUOTE);
                stringBuilder.append(cisDivision);
                stringBuilder.append(SINGLE_QUOTE);
                if(index < listSize){
                    stringBuilder.append(COMMA_DELIMITER);
                }
            }
        }
        cisDivisions = stringBuilder.toString();
        
		// Retrieve Batch Parameter 70: Maximum Errors
		parmMaxErrors = this.getParameters().getMAX_ERRORS();

        // Retrieve Batch Parameter 80: Case Type
		parmCaseType = getParameters().getCASE_TYPE_CD();
        if (parmCaseType.getPremiseUsage().isNotAllowed()) {
            addError(CustomMessageRepositorySpireOne.CCB108_PremiseUsageNotAllowediInCaseType("CASE_TYPE_CD", parmCaseType.getId().getTrimmedValue()));
        }

        // Retrieve Batch Parameter 90: Initial Case Lifecycle
        parmCaseStatus = getParameters().getINITIAL_CASE_LIFECYCLE();
        if(!isBlankOrNull(parmCaseStatus)){
            CaseStatus_Id caseStatusId = new CaseStatus_Id(parmCaseType, parmCaseStatus);
            CaseStatus caseStatus = caseStatusId.getEntity();
            if (isNull(caseStatus)) {              
                addError(CustomMessageRepositorySpireOne.CCB108_InvalidCaseStatus("INITIAL_CASE_LIFECYCLE", parmCaseStatus, parmCaseType.getId().getTrimmedValue()));
            }
            if (!(caseStatus.getStatusCondition().isInitial())) {
                addError(CustomMessageRepositorySpireOne.CCB108_InvalidInitialCaseStatus("INITIAL_CASE_LIFECYCLE", parmCaseStatus, parmCaseType.getId().getTrimmedValue()));
            }  
        }
        
        // Retrieve Batch Parameter 100: SP ID Case Char
        parmSpChar = getParameters().getSP_ID_CHAR();
        validateCharTypeEntity("SP_ID_CHAR", parmSpChar,CharacteristicEntityLookup.constants.CASE);
        validateCharTypeForCaseType("SP_ID_CHAR", parmSpChar);
        
        // Retrieve Batch Parameter 110: Case reason char
        parmCaseReasonChar = getParameters().getCASE_RSN_CHAR();
        validateCharTypeEntity("CASE_RSN_CHAR", parmCaseReasonChar,CharacteristicEntityLookup.constants.CASE);
        validateCharTypeForCaseType("CASE_RSN_CHAR", parmCaseReasonChar);

        // Retrieve Batch Parameter 120 and 130: Usage and Vacant Days
        String rsnVacantDays = getParameters().getCASE_RSN_DYS();
        String rsnUsage = getParameters().getCASE_RSN_USG();
        // Validate characteristic value for characteristic type
        validateCharVal("CASE_RSN_DYS", parmCaseReasonChar, rsnVacantDays);
        validateCharVal("CASE_RSN_USG", parmCaseReasonChar, rsnUsage);
        
        // Retrieve Batch Parameter 140: Power Status SP char
        parmPowerStatusChar = getParameters().getPWRST_CHAR();
        validateCharTypeEntity("PWRST_CHAR", parmPowerStatusChar,CharacteristicEntityLookup.constants.SERVICE_POINT);       

        // Retrieve Batch Parameter 150: Power Status SP val
        String powerStatVal = getParameters().getPWRST_VAL();
        // Validate characteristic value for characteristic type
        validateCharVal("PWRST_VAL", parmPowerStatusChar, powerStatVal);
        
        //Start Add JVitug - E-09689 - 2024-11-08
        parmConsumptionUOM = getParameters().getCNSMPTN_UOM();

        String[] uomSplit = parmConsumptionUOM.split(COMMA_DELIMITER);

        for(String uomStr : uomSplit){
        	index++;
        	UnitOfMeasure uom = new UnitOfMeasure_Id(uomStr.trim()).getEntity();
        	if(isNull(uom)){
        		// Batch %1: Parameter value (%2) is not a valid CIS Division.
        		addError(CustomMessageRepositorySpireOne.E09689_invalidUnitOfMeasure("CNSMPTN_UOM", uomStr));
        	}
        }
        //End Add JVitug - E-09689 - 2024-11-08
	}
	
	/**
     * This Method will validate whether the characteristic val.
     * @param parmCharType
     */
    private void validateCharVal(String parmCd, CharacteristicType parmCharType, String charVal){
        if(parmCharType.getCharacteristicType().isPredefinedValue()){
            CharacteristicValue_Id charValId = new CharacteristicValue_Id(parmCharType, charVal);
            if (isNull(charValId.getEntity())){
                addError(CustomMessageRepositorySpireOne.CCB108_invalidCharVal(parmCd, charVal, parmCharType.getId().getIdValue()));
            } 
        }
    }
    
	/**
     * This Method will validate whether the input parameter Characteristic Type 
     * is valid for the Case Characteristic Entity.
     * @param parmCharType
     */
    private void validateCharTypeEntity(String parmCd, CharacteristicType parmCharType, CharacteristicEntityLookup parmEntityLookup){
        CharacteristicEntity_Id characteristicEntityId = new CharacteristicEntity_Id(parmCharType, parmEntityLookup);
        if (isNull(characteristicEntityId.getEntity())){
            addError(CustomMessageRepositorySpireOne.CCB108_CharTypeInvalidForCharEntity(
            		parmCd, parmCharType.getId().getIdValue(), parmEntityLookup.getLookupValue().fetchLanguageDescription().trim()));
        } 
    }

    /**
     * This Method will validate whether the input parameter Characteristic Type 
     * is valid for the input Case Type.
     * @param parmCharType
     */
    private void validateCharTypeForCaseType(String parmCd, CharacteristicType parmCharType){
        
        CharacteristicTypeCaseType charTypeCaseType = new CharacteristicTypeCaseType_Id(parmCharType, parmCaseType).getEntity();
        if(isNull(charTypeCaseType)){
            addError(CustomMessageRepositorySpireOne.CCB108_InvalidCharTypeForCaseType(
            		parmCd, parmCharType.getId().getTrimmedValue(), parmCaseType.getId().getTrimmedValue()));
        }
    }

	/**
	 * Custom method which validates that the Integer value is greater than zero
	 * @param parmVal the value that is being validated
	 * @param parmDesc the parameter's description (will be used in case that validation failed for the value)
	 */
	private void cmValidateParmIntegerGreaterThanZero(BigInteger parmVal, String parmDesc) {
		
		if (parmVal.compareTo(BigInteger.ZERO) <= 0) {
			// Batch parameter '%1%2' value (%3) must be greater than zero.
			addError(CustomMessageRepositoryMGE.commBatchParameterMustBeGreaterThanZero(parmDesc.trim(), parmVal.toString().trim()));
		}		
	}
	/**
	 * Custom method which validates that the BigDecimal value is greater than zero
	 * @param parmVal the value that is being validated
	 * @param parmDesc the parameter's description (will be used in case that validation failed for the value)
	 */
	private void cmValidateParmDecimalGreaterThanZero(BigDecimal parmVal, String parmDesc) {
		
		if (parmVal.compareTo(BigDecimal.ZERO) <= 0) {
			// Batch parameter '%1%2' value (%3) must be greater than zero.
			addError(CustomMessageRepositoryMGE.commBatchParameterMustBeGreaterThanZero(parmDesc.trim(), parmVal.toString().trim()));
		}		
	}
	
	@SuppressWarnings("unchecked")
	public JobWork getJobWork() {
		/*
		 * Main Criteria
		 * 
		 * Select all Service Points (inService - not abolished) connected into a premise with the specified CIS Division
		 * that does not have any active (billable) Service Agreements. An additional requirement is that the Service Points
		 * must not have any pending Field Activity with FA Type matching Batch Parameter 40: Field Activity Type 
		 */
		StringBuilder stringBuilder = new StringBuilder();				
		stringBuilder.append("SELECT SP.SP_ID ");
		stringBuilder.append("FROM CI_SP SP, CI_PREM PREM ");
		stringBuilder.append("WHERE PREM.CIS_DIVISION IN ("+ cisDivisions + ") ");
		stringBuilder.append("AND SP.PREM_ID = PREM.PREM_ID ");
		stringBuilder.append("AND SP.SP_SRC_STATUS_FLG = :spSourceStatus ");
		stringBuilder.append("AND (SP.SP_STATUS_FLG = :spStatus ");
		stringBuilder.append(     "OR (SP.ABOLISH_DT IS NULL OR SP.ABOLISH_DT > :processDate)) ");
		stringBuilder.append("AND NOT EXISTS (SELECT SASP.SP_ID ");
		stringBuilder.append(                "FROM CI_SA_SP SASP, CI_SA SA ");                               
		stringBuilder.append(                "WHERE SASP.SP_ID = SP.SP_ID "); 
		stringBuilder.append(                "AND SA.SA_ID = SASP.SA_ID ");
		stringBuilder.append(                "AND SA.SA_STATUS_FLG IN (:pendingStart, :active, :pendingStop)) ");
		stringBuilder.append("AND NOT EXISTS (SELECT FA.SP_ID "); 
		stringBuilder.append(                "FROM CI_FA FA "); 
		stringBuilder.append(                "WHERE FA.SP_ID = SP.SP_ID ");
		stringBuilder.append(                "AND FA.FA_TYPE_CD IN ("+ faTypes + ") ");
		stringBuilder.append("                AND FA.FA_STATUS_FLG = :pending) ");
		stringBuilder.append("AND NOT EXISTS (SELECT 'X' FROM CI_CASE_CHAR CSC ");
		stringBuilder.append(                "WHERE CSC.SRCH_CHAR_VAL = SP.SP_ID ");
		stringBuilder.append(                "AND CSC.CHAR_TYPE_CD = :spCharType ");
		stringBuilder.append(                "AND EXISTS (SELECT 'X' FROM CI_CASE CS ");
		stringBuilder.append(                            "WHERE CS.CASE_ID = CSC.CASE_ID ");
		stringBuilder.append(                            "AND CS.CASE_TYPE_CD = :caseType ");
		stringBuilder.append(                            "AND CS.CASE_COND_FLG = :open) ) ");
		stringBuilder.append("ORDER BY SP.SP_ID ASC ");	
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		prepState.bindLookup("spSourceStatus", ServicePointSourceStatusLookup.constants.CONNECTED);
		prepState.bindLookup("spStatus", ServicePointStatusLookup.constants.IN_SERVICE);
		prepState.bindDate("processDate", this.getProcessDateTime().getDate());
		prepState.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
		prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
		prepState.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        prepState.bindLookup("open", CaseConditionLookup.constants.OPEN);
        prepState.bindLookup("pending", FieldActivityStatusLookup.constants.PENDING);
        prepState.bindId("spCharType", parmSpChar.getId());
        prepState.bindId("caseType", parmCaseType.getId());
		prepState.execute();
		
		QueryIterator queryIter = prepState.iterate();
		return createJobWorkForQueryIterator(queryIter, this);
	}

	@Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow qrw) {
		
		ThreadWorkUnit twu = new ThreadWorkUnit();
		ServicePoint_Id spID = (ServicePoint_Id) qrw.getId("SP_ID", ServicePoint.class);
		twu.setPrimaryId(spID);
		return twu;
	}
	
	public Class<CmMonitorConsumptionForDelayedTransferBatchWorker> getThreadWorkerClass() {
		return CmMonitorConsumptionForDelayedTransferBatchWorker.class;
	}

	public static class CmMonitorConsumptionForDelayedTransferBatchWorker 
			extends CmMonitorConsumptionForDelayedTransferBatchWorker_Gen {
		
		// Parameters
		private BigInteger parmVacDaysThreshold;
		//Start Change JVitug - E-09689 - 2024-11-08
		//private UnitOfMeasure parmConsumptionUOM;
		private String parmConsumptionUOM;
		private String consumptionUOMs;
		//End Changee JVitug - E-09689 - 2024-11-08
		private CharacteristicType parmSpIdChar;
		private CharacteristicType parmCreationReasonCharType;
		private CaseStatus_Id caseStatusId;
        private String parmCreationRsnVacantDays;
        private String parmCreationRsnUsage;
        private CharacteristicType parmPowerStatusChar;
        private String parmPowerStatusCharVal;
        private BigDecimal parmMaxUsageSmr;
        private BigDecimal parmMaxUsageWnt;
        private String parmADDPReadRouteType;
        
        // Working Variables
        private int totalNumOfSP;
        private int totalVacantDysCase;
        private int totalUsageCase;
        
        // Constants 
        private FeatureConfiguration quotePortalFC = new FeatureConfiguration_Id("CM-QPPARM").getEntity();
		
		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
			// Initialize parameters
			parmADDPReadRouteType = this.getParameters().getADDP_RTE_TYPE();
			parmVacDaysThreshold = this.getParameters().getVAC_DAYS_THRSHLD();
			//Start Delete JVitug - E-09689 - 2024-11-08
			//parmConsumptionUOM = this.getParameters().getCNSMPTN_UOM();
			//End Delete JVitug - E-09689 - 2024-11-08
			parmSpIdChar = this.getParameters().getSP_ID_CHAR();
			parmCreationReasonCharType = this.getParameters().getCASE_RSN_CHAR();
			
			CaseType caseType = this.getParameters().getCASE_TYPE_CD();
			if(!isBlankOrNull(this.getParameters().getINITIAL_CASE_LIFECYCLE())){
			    caseStatusId = new CaseStatus_Id(caseType.getId(), this.getParameters().getINITIAL_CASE_LIFECYCLE());
			}else{
                ListFilter<CaseStatus> caseStatusFilter = caseType.getCaseStatues().createFilter(
						"where this.statusCondition = :initial", getClass().getName());
				caseStatusFilter.bindLookup("initial", StatusConditionLookup.constants.INITIAL);
				CaseStatus caseStatus = caseStatusFilter.firstRow();
				caseStatusId = caseStatus.getId();
			}
			
            parmCreationRsnVacantDays = this.getParameters().getCASE_RSN_DYS();
            parmCreationRsnUsage = this.getParameters().getCASE_RSN_USG();
	        parmPowerStatusChar = this.getParameters().getPWRST_CHAR();
	        parmPowerStatusCharVal = this.getParameters().getPWRST_VAL();
	        parmMaxUsageSmr = this.getParameters().getUSAGE_MAX_SMR();	        
	        parmMaxUsageWnt = this.getParameters().getUSAGE_MAX_WNTR();

	        totalNumOfSP = 0;
	        totalVacantDysCase = 0;
	        totalUsageCase = 0;
	        
	        //Start Add JVitug - E-09689 - 2024-11-08
	        parmConsumptionUOM = getParameters().getCNSMPTN_UOM();
	        StringBuilder stringBuilder = new StringBuilder();
	        String[] uomSplit = parmConsumptionUOM.split(COMMA_DELIMITER);
	        int index = 0;
	        int listSize = uomSplit.length;
	        
	        for(String uomStr : uomSplit){
	        	index++;
	        	stringBuilder.append(SINGLE_QUOTE);
	        	stringBuilder.append(uomStr);
	        	stringBuilder.append(SINGLE_QUOTE);
	        	if(index < listSize){
	        		stringBuilder.append(COMMA_DELIMITER);
	        	}

	        }
	        consumptionUOMs = stringBuilder.toString();
	      //End Add JVitug - E-09689 - 2024-11-08
		}

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}
		
		public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {

            ServicePoint_Id spID = (ServicePoint_Id) unit.getPrimaryId();
            totalNumOfSP++;
            
            // Retrieve the meter configuration and the stop date of the latest SA/SP that had service at the premise.
            SQLResultRow latestMeterReadDtls = retrieveMeterReadDtls(spID);
            
            if (notNull(latestMeterReadDtls)) {
                DateTime stopMRDateTime = latestMeterReadDtls.getDateTime("READ_DTTM");
                MeterConfiguration_Id mtrConfigID = (MeterConfiguration_Id) latestMeterReadDtls.getId("MTR_CONFIG_ID", MeterConfiguration.class);
                MeterRead_Id stopMeterReadID = (MeterRead_Id) latestMeterReadDtls.getId("MR_ID", MeterRead.class);      
                DateTime saSpStopDttm  = latestMeterReadDtls.getDateTime("STOP_DTTM");
                
                // Determine whether the premise has been vacant long enough for disconnection
                // Determine the number of days since the service was stopped (process date - SA/SP stop date time).
                long numberOfDaysSinceStopped = getProcessDateTime().difference(saSpStopDttm).getDays();
                if(numberOfDaysSinceStopped > parmVacDaysThreshold.longValue()){
                	// If the result is greater than the number of days threshold (parameter 10) create a case.
                    cmCreateCase(caseStatusId, parmSpIdChar, spID, 
                            parmCreationReasonCharType, parmCreationRsnVacantDays);
                    totalVacantDysCase++;
                    return true;
                }
                
                /*
                 * Determine whether the SP is associated with an AMR meter. 
                 * If the SP has a characteristic with type matching parameter 140 and value matching parameter 150 the SP is AMR. Otherwise it is non-AMR
                 * Check (and retrieve) if the meter has been removed after stopMRDateTime
                 */
                ServicePointCharacteristic spChar = spID.getEntity().getEffectiveCharacteristic(parmPowerStatusChar);
                Bool isSpAMR = Bool.FALSE;
                if(notNull(spChar) && spChar.getCharacteristicValue().trim().compareToIgnoreCase(parmPowerStatusCharVal) == 0){
                    isSpAMR = Bool.TRUE;//temporary
                }
                
                // Get the most recent reading
                BigDecimal mostRecentReading = null;
                Date latestMeterReadDateAfterStop = null;
                //Start Delete JVitug - E-09689 - 2024-11-08
                //UnitOfMeasure consumptionUom = parmConsumptionUOM;
                //End Delete JVitug - E-09689 - 2024-11-08
                
                if(isSpAMR.isTrue()){
                    // For AMR retrieve the most recent meter read for the SP from the AMR daily reads database.
                    String badgeNumber = stopMeterReadID.getEntity().getMeterConfiguration().getMeter().getBadgeNumber();
                    CmWSDLCallToAMRDataBase amrDb = retrieveLatestAMRRead(spID, badgeNumber);
                    
                    if(notNull(amrDb.getAmrCorrectedRead())){
                        mostRecentReading = amrDb.getAmrCorrectedRead();
                        latestMeterReadDateAfterStop = amrDb.getAmrCorrectedReadDate().getDate();
                    }
                    
                }else{
                	// check the route type is ADDP
                    String serviceRoute = null;
                    String serviceCycle = null;
                    serviceCycle = spID.getEntity().getMeterReadCycleId().getIdValue().toString();
                    serviceRoute = spID.getEntity().getMeterReadRouteId().getMeterReadRoute().toString();
                    
                    String wRouteTypeRetrieveFrSql = cmRetrieveRouteType(serviceCycle,serviceRoute);
                    if(wRouteTypeRetrieveFrSql.trim().toString().equals(parmADDPReadRouteType.trim().toString()))
                    {
                    // it's a ADDP Route
                    	
                        String badgeNumber = stopMeterReadID.getEntity().getMeterConfiguration().getMeter().getBadgeNumber();
                        String serailNumber = stopMeterReadID.getEntity().getMeterConfiguration().getMeter().getSerialNumber();
                        
            	        //Create outbound notification to ADDP
        				ServiceScriptInstance serviceScriptInstance = null;
        	    		COTSInstanceNode scriptInput = null;
        	    		COTSInstanceNode scriptOutput = null;
        				serviceScriptInstance = ServiceScriptInstance.create(CM_ADDPREAD); 	
        	    		// Retrieve the script's input node
        	    		scriptInput = serviceScriptInstance.getGroup(GROUP_INPUT);
        	    		
        	    		scriptInput.set("meterBadgeNumber", badgeNumber);
        	    		scriptInput.set("meterAssetNumber", serailNumber);
        	    		scriptInput.set("readDateStart",this.getProcessDateTime().getDate());
        	    		scriptInput.set("readDateEnd",this.getProcessDateTime().getDate());
        	    		scriptInput.set("readTime","10:00");
        				
        				try{
        					ServiceScriptDispatcher.invoke(serviceScriptInstance);	
        				} catch (ApplicationError e){
        					e.getServerMessage();
        				}
        				 //it can be added to the FA later if needed
        				scriptOutput = serviceScriptInstance.getGroup(GROUP_OUTPUT);
        				String outboundMessageId = scriptOutput.getString("outboundMsgId");
        				String correctedIndexRead_str = null;
        				String errorMessage = null;
        				correctedIndexRead_str  = scriptOutput.getString("correctedIndex");
        				errorMessage = scriptOutput.getString("errorMessage");

        				//correctedIndexRead_str = correctedIndexRead_str.substring(0, correctedIndexRead_str.length() - 3);
        				if(errorMessage == null)
        				{
        					
                            DateTime meterRemovedDttm = cmRetrieveMeterRemovalDate(mtrConfigID, spID, stopMRDateTime);  
                            MeterRead_Id latestMeterReadIdAfterStop = cmRetrieveLatestMeterReadAfterServiceStop(mtrConfigID, stopMRDateTime, meterRemovedDttm);

                            if(notNull(latestMeterReadIdAfterStop)){
                            	//Start Change JVitug - E-09689 - 2024-11-08
                                //mostRecentReading = cmRetrieveRead(latestMeterReadIdAfterStop, consumptionUom); 
                                mostRecentReading = cmRetrieveRead(latestMeterReadIdAfterStop); 
                                //End Change JVitug - E-09689 - 2024-11-08
                                latestMeterReadDateAfterStop = latestMeterReadIdAfterStop.getEntity().getReadDateTime().getDate();
                            }
                            
        				//	BigDecimal correctedIndexRead = new BigDecimal(correctedIndexRead_str);
        					Iterator<Register> iterator = mtrConfigID.getEntity().getRegisters().iterator();
        					
        		            while (iterator.hasNext()) {
        		                Register register = iterator.next();
        		                if(register.getUnitOfMeasure().getId().getIdValue().compareTo("CCFC") == 0)
        		                {
        		                	if(correctedIndexRead_str.length() > 2) 
        		                	{
        		                	correctedIndexRead_str = correctedIndexRead_str.substring(0, correctedIndexRead_str.length() - 2);
        		                	}
        		                }
        		                if(register.getUnitOfMeasure().getId().getIdValue().compareTo("MCFC") == 0)
        		                {
        		                	if(correctedIndexRead_str.length() > 3) 
        		                	{
        		                	correctedIndexRead_str = correctedIndexRead_str.substring(0, correctedIndexRead_str.length() - 3);
        		                	}
        		                }
        		                mostRecentReading = new BigDecimal(correctedIndexRead_str);
        		            }
        				}else
        				{
            				errorMessage = "Response from ADDP : " + errorMessage + " Service Point : " + spID + " Outbound Message :" + outboundMessageId;
            				ServerMessage serverMsg = CustomMessageRepositorySpireOne.CCB011_applicationError(errorMessage);
            				
        					addError(serverMsg);
        			
        				}
        						
        				
        				
                    }
                    else
                    {
                    	// For non AMR retrieve the most recent non estimated billable read for the service point from CCB.
                    	DateTime meterRemovedDttm = cmRetrieveMeterRemovalDate(mtrConfigID, spID, stopMRDateTime);  
                    	MeterRead_Id latestMeterReadIdAfterStop = cmRetrieveLatestMeterReadAfterServiceStop(mtrConfigID, stopMRDateTime, meterRemovedDttm);

                    	if(notNull(latestMeterReadIdAfterStop)){
                    		//Start Change JVitug - E-09689 - 2024-11-08
                    		//mostRecentReading = cmRetrieveRead(latestMeterReadIdAfterStop, consumptionUom);
                    		mostRecentReading = cmRetrieveRead(latestMeterReadIdAfterStop);
                    		//End Change JVitug - E-09689 - 2024-11-08
                    		latestMeterReadDateAfterStop = latestMeterReadIdAfterStop.getEntity().getReadDateTime().getDate();
                    	}
                    }
                }
                
                // Exit if no most recent reading after stop
                if(isNull(mostRecentReading)){
                    return true;
                }
                
                // Compute for the consumption
                //Start Change JVitug - E-09689 - 2024-11-08
                //Register register = cmRetrieveRegister(mtrConfigID, consumptionUom);
                Register register = cmRetrieveRegister(mtrConfigID);
                //End Change JVitug - E-09689 - 2024-11-08
                ConsumptionTypeLookup consumptType = register.getConsumptionType();
                
                BigDecimal consumption = BigDecimal.ZERO;
                // If consumptive, most recent reading is the usage
                if(consumptType.isConsumptive()){
                    consumption = mostRecentReading;
                }else{
                    // Determine the usage from the start and stop read
                	//Start Change JVitug - E-09689 - 2024-11-08
                    //BigDecimal startingRead = cmRetrieveRead(stopMeterReadID, consumptionUom);
                	BigDecimal startingRead = cmRetrieveRead(stopMeterReadID);
                    //End Change JVitug - E-09689 - 2024-11-08
                    int scaleValue = startingRead.scale();
                    consumption = cmComputeConsumption(startingRead, mostRecentReading, register);
                    consumption = consumption.setScale(scaleValue, BigDecimal.ROUND_HALF_UP); 
                }
                
                Bool isHeatingSeason = isHeatingSeason(quotePortalFC, latestMeterReadDateAfterStop);
                // Determine if heating season
                if(isHeatingSeason.isTrue()){
                    // Compare usage to the max usage winter parm        
                    parmMaxUsageWnt = this.getParameters().getUSAGE_MAX_WNTR();
                    if(consumption.compareTo(parmMaxUsageWnt) > 0){
                    	// If the result is greater than the threshold create a case.
                        cmCreateCase(caseStatusId, parmSpIdChar, spID, 
                                parmCreationReasonCharType, parmCreationRsnUsage);
                        totalUsageCase++;
                        return true;
                    }
                }else{
                    // Compare usage to the max usage summer parm
                    parmMaxUsageSmr = this.getParameters().getUSAGE_MAX_SMR();  
                    if(consumption.compareTo(parmMaxUsageSmr) > 0){
                        // If the result is greater than the threshold create a case.
                        cmCreateCase(caseStatusId, parmSpIdChar, spID, 
                                parmCreationReasonCharType, parmCreationRsnUsage);
                        totalUsageCase++;
                        return true;
                    }
                }
            }           
            
            return true;
        }
		
		/**
         * Determine whether the latest meter read date falls under heating season or non-heating season 
         * using the Quote Portal Parameters feature confige CM-QPPARM if the process date month/day falls on 
         * or between the values for CWR Season Begin and CWR Season End it is heating season. 
         * Otherwise it is non-heating season
         * @param quoteFC
         * @param latestMeterReadDate
		 * @return Is heating season boolean
		 */
		private Bool isHeatingSeason(FeatureConfiguration quoteFC, Date latestMeterReadDate){
			Bool isHeatingSeason = Bool.FALSE;
			
		    CmMGEFeatureConfigurationOptionsRetriever retriever = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
		    
            String cwrSeasonBeginString = retriever.cmGetFeatOptValue(quoteFC.getId(), CmQuotePortalParametersLookup.constants.CWR_SEASON_BEGIN, Bool.TRUE, Bool.FALSE);
            String[] cwrGetBegMonthDy = cwrSeasonBeginString.split(SLASH_DELIMITER);
            Date cwrSeasonStart = new Date(latestMeterReadDate.getYear(), Integer.parseInt(cwrGetBegMonthDy[0]), Integer.parseInt(cwrGetBegMonthDy[1]));
            String cwrSeasonEndString =retriever.cmGetFeatOptValue(quoteFC.getId(), CmQuotePortalParametersLookup.constants.CWR_SEASON_END, Bool.TRUE, Bool.FALSE);
            String[] cwrGetEndMonthDy = cwrSeasonEndString.split(SLASH_DELIMITER);
            
            Date cwrSeasonEnd = new Date(latestMeterReadDate.getYear(), Integer.parseInt(cwrGetEndMonthDy[0]), Integer.parseInt(cwrGetEndMonthDy[1]));
            if(cwrSeasonStart.isAfter(cwrSeasonEnd)){
                cwrSeasonEnd = new Date(latestMeterReadDate.getYear()+1, Integer.parseInt(cwrGetEndMonthDy[0]), Integer.parseInt(cwrGetEndMonthDy[1]));
            }

            if(latestMeterReadDate.isSameOrAfter(cwrSeasonStart) && latestMeterReadDate.isSameOrBefore(cwrSeasonEnd)) {
            	isHeatingSeason = Bool.TRUE;
            }
            
            if(isHeatingSeason.isFalse() && latestMeterReadDate.isSameOrBefore(cwrSeasonStart)) {
            	cwrSeasonStart = cwrSeasonStart.addYears(-1);
            	cwrSeasonEnd = cwrSeasonStart.addYears(-1);

            	if(latestMeterReadDate.isSameOrAfter(cwrSeasonStart) && latestMeterReadDate.isSameOrBefore(cwrSeasonEnd)) {
                	isHeatingSeason = Bool.TRUE;
                }
            }
            
            return isHeatingSeason;
		}
		
		/**
		 * This method retrieves AMR reads from AMR Database
		 * @param spID
		 * @param badgeNumber
		 * @return AMR read
		 */
		private CmWSDLCallToAMRDataBase retrieveLatestAMRRead(ServicePoint_Id spID, String badgeNumber){
		    // For AMR retrieve the most recent meter read for the SP from the AMR daily reads database.
            CmWSDLCallToAMRDataBase wsdlComp = CmWSDLCallToAMRDataBase.Factory.newInstance();
            String strAMRWsdlURL = wsdlComp.getWsdlURLForAMRReads();
            if(isNull(strAMRWsdlURL)){
                addError(wsdlComp.getServerMessage());
            }
            
            wsdlComp.setWsdlURL(strAMRWsdlURL);
            wsdlComp.setInputBadgeNumber(badgeNumber);
            wsdlComp.setInputSpId(spID);
            wsdlComp.setInputReadDate(getProcessDateTime().getDate());
            
            try{
                wsdlComp.retreiveReadDetailsFromAMR();
            }catch(UnknownHostException uhe){
                throw new RunAbortedException(CustomMessageRepository.webServiceHostUnreachable(uhe.getMessage()));
            }catch(Exception excp){
                throw new RunAbortedException(CustomMessageRepository.errorInvokingAMRWebService(excp.getMessage()));
            }
            
            return wsdlComp;
		}
		
		/**
		 * Retrieve the meter configuration and the stop date of the latest SA/SP that had service at the premise.
		 * @param Service Point
		 * @return result list
		 */
		private SQLResultRow retrieveMeterReadDtls(ServicePoint_Id spID){
            // Retrieve the meter configuration and the stop date of the latest SA/SP that had service at the premise.
            StringBuilder stringBuilder = new StringBuilder();                      
            stringBuilder.append("SELECT SASP.STOP_DTTM, MR.READ_DTTM, MR.MTR_CONFIG_ID, MR.MR_ID ");
            stringBuilder.append("FROM CI_SA_SP SASP, CI_MR MR ");
            stringBuilder.append("WHERE SASP.SP_ID = :spID ");
            stringBuilder.append("AND SASP.STOP_DTTM = (SELECT MAX(SASP2.STOP_DTTM) ");
            stringBuilder.append(                      "FROM CI_SA_SP SASP2 ");
            stringBuilder.append(                      "WHERE SASP2.SP_ID = SASP.SP_ID ");
            stringBuilder.append(                      ") ");
            stringBuilder.append("AND MR.MR_ID = SASP.STOP_MR_ID ");
            PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            prepState.bindId("spID", spID);
            prepState.execute();
            SQLResultRow result = prepState.firstRow();
            prepState.close();
            
            return result;
		}
		
		/**
		 * Custom method which retrieves the earliest non-estimated read after the service was stopped. 
		 * Note: The selected read cannot be future dated.  
		 * @param meterConfigID the meter configuration
		 * @param stopMRDateTime the stop Meter Read Date Time
		 * @return the latest Meter Read ID after the service was stopped
		 */
		private MeterRead_Id cmRetrieveLatestMeterReadAfterServiceStop(MeterConfiguration_Id meterConfigID, DateTime stopMRDateTime,
				DateTime meterRemovedDttm) {
			
			MeterRead_Id returnValue = null;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT MR.READ_DTTM, MR.MR_ID ");
			stringBuilder.append("FROM CI_MR MR ");
			stringBuilder.append("WHERE MR.MTR_CONFIG_ID = :meterConfigID ");
			stringBuilder.append("AND MR.USE_ON_BILL_SW = :yesUseOnBill ");
			
			if (isNull(meterRemovedDttm)) {
				// Meter Reads after the Stop Read
				stringBuilder.append("AND READ_DTTM >= :stopMRDateTime ");				
			}
			else {
				// Meter Reads after the Stop Read and before the Meter Removal
				stringBuilder.append("AND READ_DTTM BETWEEN :stopMRDateTime AND :meterRemovedDttm ");
			}

			stringBuilder.append("AND MR.MR_ID IN (SELECT RR.MR_ID ");
			stringBuilder.append("                 FROM CI_REG_READ RR ");
			stringBuilder.append("                 WHERE RR.MR_ID = MR.MR_ID ");
			                      // Condition for None Estimate Reads only (no need to use feature configuration as it is overkill. Read Type Flag lookup is owned by product and cannot be modified)
			stringBuilder.append("                 AND RR.READ_TYPE_FLG NOT IN (:systemEstimate, :serviceProviderEstimate, :officeEstimate) ");
			stringBuilder.append("                ) ");
			// Condition to restrict future dated reads                
			stringBuilder.append("AND MR.READ_DTTM <= :processDateTime ");
			stringBuilder.append("ORDER BY MR.READ_DTTM DESC ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			prepState.bindId("meterConfigID", meterConfigID);
			prepState.bindBoolean("yesUseOnBill", Bool.TRUE);
			
			if (isNull(meterRemovedDttm)) {
				prepState.bindDateTime("stopMRDateTime", stopMRDateTime);
			}
			else {
				prepState.bindDateTime("stopMRDateTime", stopMRDateTime);
				prepState.bindDateTime("meterRemovedDttm", meterRemovedDttm);
			}
			
			prepState.bindLookup("systemEstimate", ReadTypeLookup.constants.SYSTEM_ESTIMATE);
			prepState.bindLookup("serviceProviderEstimate", ReadTypeLookup.constants.SERVICE_PROVIDER_ESTIMATE);
			prepState.bindLookup("officeEstimate", ReadTypeLookup.constants.OFFICE_ESTIMATE);
			prepState.bindDateTime("processDateTime", this.getProcessDateTime());
			prepState.execute();
			SQLResultRow result = prepState.firstRow();
			
			if (notNull(result)) {				
				returnValue = (MeterRead_Id) result.getId("MR_ID", MeterRead.class);
			}			
			prepState.close();

			return returnValue;
		}
		
		/**
		 * Custom method which retrieves the actual Register Reading of the correct UOM from the Meter Read ID 
		 * @param mrID the meter read
		 * @param readUOM the UOM 
		 * @return the register reading 
		 */
		//Start Change JVitug - E-09689 - 2024-11-08
		//private BigDecimal cmRetrieveRead(MeterRead_Id mrID, UnitOfMeasure readUOM) {
		private BigDecimal cmRetrieveRead(MeterRead_Id mrID) {
		//End Change JVitug - E-09689 - 2024-11-08
			
			BigDecimal returnValue = BigDecimal.ZERO;			
			
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT RR.REG_READING ");
			stringBuilder.append("FROM CI_REG_READ RR, CI_REG REG ");
			stringBuilder.append("WHERE RR.MR_ID = :mrID ");
			stringBuilder.append("AND REG.REG_ID = RR.REG_ID ");
			//Start Change JVitug - E-09689 - 2024-11-08 
			//stringBuilder.append("AND REG.UOM_CD = :uomCd ");
			stringBuilder.append("AND REG.UOM_CD IN (" + consumptionUOMs +  ") ");
			//End Change JVitug - E-09689 - 2024-11-08
			stringBuilder.append("AND RR.READ_SEQ = REG.READ_SEQ ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			prepState.bindId("mrID", mrID);
			//Start Delete JVitug - E-09689 - 2024-11-08
			//prepState.bindId("uomCd", readUOM.getId());
			//Start Delete JVitug - E-09689 - 2024-11-08
			prepState.execute();
			SQLResultRow result = prepState.firstRow();
			if (notNull(result)) {
				// Program is already using the specific Meter Read ID, so program needs to retrieve only one row
				returnValue = result.getBigDecimal("REG_READING");
			}					
			prepState.close();
			
			return returnValue;
			
		}
		
		/**
         * Custom method which creates Case
         * @param spID The Service Point to create the Case
         */
        private void cmCreateCase(CaseStatus_Id caseStatusId, CharacteristicType spIdChar, ServicePoint_Id spId, 
                CharacteristicType creationReasonCharType, String creationReason) {
            
            // Create Case
            startChanges();
            
            CaseCreator caseCreatorComp = CaseCreator.Factory.newInstance();
            CaseCreatorData caseCreatorCompData = CaseCreatorData.Factory
                    .newInstance();
            List<CaseCharacteristic_DTO> caseCharacteristics = new ArrayList<CaseCharacteristic_DTO>();
            ToDoCase_DTO caseDTO = new ToDoCase_DTO();
            
            // Set the Case Status and Condition to Initial
            caseDTO.setCaseStatusId(caseStatusId);
            caseDTO.setPremiseId(spId.getEntity().getPremise().getId());
            caseDTO.setCaseCondition(CaseConditionLookup.constants.OPEN);
            caseDTO.setUserId(getActiveContextUser().getId());
            
            caseCharacteristics.add(createCaseCharacteristicDTO(spIdChar, BigInteger.ONE, spId.getTrimmedValue())); 
            caseCharacteristics.add(createCaseCharacteristicDTO(creationReasonCharType, BigInteger.ONE, creationReason)); 
            
            // Set to do case DTO
            caseCreatorCompData.setToDoCaseDTO(caseDTO); 
            caseCreatorCompData.setCaseCharacteristics(caseCharacteristics);
            caseCreatorComp.createCase(caseCreatorCompData);
          
            saveChanges();
        }
		
		/**
		 * Adds a Characteristic to a given ToDoCase.
		 * 
		 * @param charType
		 * @param toDoCase
		 * @param sequence
		 * @param value
		 */
		private static CaseCharacteristic_DTO createCaseCharacteristicDTO(
				CharacteristicType charType, BigInteger sequence, String value) {

			CaseCharacteristic_DTO caseCharDTO = new CaseCharacteristic_DTO();
			caseCharDTO.setId(new CaseCharacteristic_Id(charType, null,
					sequence));

			if (charType.getCharacteristicType().isPredefinedValue()) {
				caseCharDTO.setCharacteristicValue(value);
			} else if (charType.getCharacteristicType().isAdhocValue()
					|| charType.getCharacteristicType().isFileLocationValue()) {
				caseCharDTO.setAdhocCharacteristicValue(value);
			} else if (charType.getCharacteristicType().isForeignKeyValue()) {
				caseCharDTO.setCharacteristicValueForeignKey1(value);
			}

			return caseCharDTO;
		}
		
		/**
		 * Custom method which calls the base routine to calculate the consumption given 2 reads and the register's number of digits left
		 * and taking into account the dial rollover.
		 * @param startReading the starting read
		 * @param endReading the ending read
		 * @param register the register to retrieve the number of digits left value
		 * @return BigDecimal value of the consumption between two reads
		 */
		private BigDecimal cmComputeConsumption(BigDecimal startReading, BigDecimal endReading, Register register) {
			
			BigDecimal returnValue = BigDecimal.ZERO;			
			try {
				/*
				 * Use the base routine CIPMDBRN which calculates the difference (a.k.a. consumption)
				 * between two register reads by taking the dial rollover into account.
				 */			
				CobolProgramCIPMDBRN cobolRoutine = CobolProgramCIPMDBRN.Factory.newInstance();
				CobolCopybookCICMDBRN cobolCopybook = cobolRoutine.getCobolCopybookCICMDBRN();
				// Set the input of the routine
				cobolCopybook.get_INPUT_WRK().set_START_READING(startReading);
				cobolCopybook.get_INPUT_WRK().set_END_READING(endReading);
				cobolCopybook.get_INPUT_WRK().set_NBR_OF_DGTS_LFT(register.getNumberOfDigitsLeft());			
				// Execute the routine
				cobolRoutine.callCobol();
				// Retrieve the ouput of the routine
				returnValue = cobolCopybook.get_OUTPUT_WRK().get_DIFFERENCE();
				
			}
			catch (Exception e) {
				// Error encountered while invoking base routine %1.
				addError(CustomMessageRepositoryMGE.commGenericErrorEncounteredInvokingBaseRoutine("CIPMDBRN"));
			}
			return returnValue;
		}
		/**
		 * Custom method which retrieves the correct register (of the specified UOM type) from the meter configuration 
		 * @param mtrConfigID the meter configuration id
		 * @param uom the unit of measure of the register to be retrieved
		 * @return the register which has the correct unit of measure from the meter configuration
		 */
		//Start Change JVitug - E-09689 - 2024-11-08
		//private Register cmRetrieveRegister(MeterConfiguration_Id mtrConfigID, UnitOfMeasure uom) {
		private Register cmRetrieveRegister(MeterConfiguration_Id mtrConfigID) {
		//End Change JVitug - E-09689 - 2024-11-08 
			Register returnValue = null;
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT REG_ID ");
			stringBuilder.append("FROM CI_REG REG ");
			stringBuilder.append("WHERE REG.MTR_ID = :mtrID ");
			//Start Change JVitug - E-09689 - 2024-11-08
			//stringBuilder.append("AND REG.UOM_CD = :uomCd ");
			stringBuilder.append("AND REG.UOM_CD IN (" + consumptionUOMs + ") ");
			//End Change JVitug - E-09689 - 2024-11-08
			stringBuilder.append("AND REG.EFF_DTTM = (SELECT MAX(REG2.EFF_DTTM) ");
			stringBuilder.append("                    FROM CI_REG REG2 ");
			stringBuilder.append("                    WHERE REG2.MTR_ID = REG.MTR_ID ");
			stringBuilder.append("                    AND REG2.UOM_CD = REG.UOM_CD ");
			stringBuilder.append("                    AND TO_DATE(REG2.EFF_DTTM) <= :procDt ");
			stringBuilder.append("                    ) ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			prepState.bindId("mtrID", mtrConfigID.getEntity().getMeter().getId());
			//Start Delete JVitug - E-09689 - 2024-11-08
			//prepState.bindId("uomCd", uom.getId());
			//End Delete JVitug - E-09689 - 2024-11-08
			prepState.bindDate("procDt", this.getProcessDateTime().getDate());
			prepState.execute();	
			SQLResultRow result = prepState.firstRow();
			if (notNull(result)) {
				Register_Id regID = (Register_Id)result.getId("REG_ID", Register.class);
				returnValue = regID.getEntity();
			}
			else {
				// Failed to retrieve effective register with (%1) UOM for Meter Configuration (%2)
				//Start Change JVitug - E-09689 - 2024-11-08
				//addError(CustomMessageRepositorySpireOne.CCB108_failedToRetrieveRegisterOfMeterConfig(
						//uom.getId().getTrimmedValue(),mtrConfigID.getTrimmedValue()));
				addError(CustomMessageRepositorySpireOne.CCB108_failedToRetrieveRegisterOfMeterConfig(
						consumptionUOMs ,mtrConfigID.getTrimmedValue()));
				//End Change JVitug - E-09689 - 2024-11-08
			}
			prepState.close();
			return returnValue;
		}
		
		
		/** 
		 * Custom method which retrieves Route Type base on cycle and route number
		 * @param cycle, route
		 * @return Route type
		 */
		private String cmRetrieveRouteType(String cycle, String route) {
			
			PreparedStatement countRoute = createPreparedStatement(
					"SELECT MRRTE.MR_RTE_TYPE_CD "		 +
					"FROM CI_MR_RTE MRRTE "							 +
					"       WHERE MRRTE.MR_CYC_CD  = '" + cycle + "'" +
					"       AND MRRTE.MR_RTE_CD = '" + route + "'", getClass().getName());

			countRoute.execute();   
			SQLResultRow result = countRoute.firstRow();
			countRoute.close();
			if (notNull(result)){
				String wRouteTypeTemp = result.getString("MR_RTE_TYPE_CD");
				return wRouteTypeTemp;
			}else{
				return "";
			}
		}
		
		/**
		 * Custom method which retrieves the meter's removal date time (if any) after the service has been stopped.
		 * @param mtrConfigID meter configuration id
		 * @param spID service point 
		 * @param stopMRDttm the service's stop meter read date time
		 * @return returnValue the meter's removal date time (if any) after the service has been stopped.
		 */
		private DateTime cmRetrieveMeterRemovalDate(MeterConfiguration_Id mtrConfigID, ServicePoint_Id spID, DateTime stopMRDttm) {
			DateTime returnValue = null;
			
			StringBuilder stringBuilder = new StringBuilder();						
			stringBuilder.append("SELECT MAX(EVT1.READ_DTTM) RMV_DTTM ");
			stringBuilder.append("FROM CI_SP_MTR_EV_VW EVT1 ");
			stringBuilder.append("WHERE EVT1.MTR_CONFIG_ID = :mtrConfigID "); 
			stringBuilder.append("AND EVT1.SP_ID = :spID ");
			stringBuilder.append("AND EVT1.READ_DTTM >= :stopMRDttm ");
			stringBuilder.append("AND EVT1.SP_MTR_EVT_FLG = :removalEvent ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			prepState.bindId("mtrConfigID", mtrConfigID);
			prepState.bindId("spID", spID);
			prepState.bindDateTime("stopMRDttm", stopMRDttm);
			prepState.bindLookup("removalEvent", ServicePointMeterEventTypeLookup.constants.REMOVAL);
			prepState.execute();
			SQLResultRow result = prepState.firstRow();
			if (notNull(result)) {				
				returnValue = result.getDateTime("RMV_DTTM");
			}
			
			prepState.close();
			return returnValue;
		}

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {
			// Number of connected vacant service points: %1
			logInfo(CustomMessageRepositorySpireOne.CCB108_numberOfConnectedVacantSPs(String.valueOf(totalNumOfSP)));
			// Number of cases created due to vacant days threshold: %1
            logInfo(CustomMessageRepositorySpireOne.CCB108_numberOfNewVacantCases(String.valueOf(totalVacantDysCase)));
            // Number of cases created due to usage threshold: %1
            logInfo(CustomMessageRepositorySpireOne.CCB108_numberOfNewUsageCases(String.valueOf(totalUsageCase)));
		
		}		
	}
} 
