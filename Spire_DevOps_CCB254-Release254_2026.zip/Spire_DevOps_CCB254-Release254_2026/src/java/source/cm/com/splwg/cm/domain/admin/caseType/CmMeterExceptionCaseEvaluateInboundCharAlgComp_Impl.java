/*******************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * Metering Exception Case - Evaluate Inbound Characteristics
 *
 * This algorithm will perform the evaluation of the "inbound" Characteristics and 
 * make the appropriate changes to the "permanent" Characteristics on the Case. 
 * Once this evaluation is complete, the algorithm will delete the "inbound" 
 * Characteristics. 
 * 
 * Once this is complete, the "permanent" Characteristics will be evaluated to 
 * determine whether the "main" Characteristics should be updated with the information.  
 * The "main" characteristics are used to drive the lifecycle of the Case. 
 * In the event that the "main" exception code Characteristic on the Case is updated, 
 * this algorithm will transition the Case to the "New Exception" status (supplied
 * as parameter to this algorithm). 
 *
 ********************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-03-25   SMiranda        NI0007.5. Initial Version.
 * 2013-04-24   SMiranda        TIR1. Fixed auto-transition when Case is in 
 *                              Initial Status
 * 2013-04-26   SMiranda        TIR3-TIR4. Transferred logic of add/udpate/delete
 *                              characteristic to Exit Status.    
 * 2016-01-52   MPang			Updated for CCB v2.4 compilation. 
 * 2016-05-05	MPang			Defect 3429075. An error is encountered even the 
 * 								next status is in configuration. Instead of custom
 *                              error, base will be shown.                     
 ********************************************************************************/
package com.splwg.cm.domain.admin.caseType;

import java.math.BigInteger;
import java.util.List;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.lookup.LookupField_Id;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;

/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseStatusTransitionRule_Id;
import com.splwg.ccb.domain.admin.caseType.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.CaseType;
import com.splwg.ccb.domain.admin.caseType.CaseTypeAutoTransitionAlgorithmSpot;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;*/


//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
//Start Delete - 2016-05-05 - MPang - Defect 3429075
//import com.splwg.ccb.domain.admin.caseType.entity.CaseStatusTransitionRule_Id;
//End Delete - 2016-05-05 - MPang - Defect 3429075
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.caseType.algorithm.autoTransition.AutoTransitionAlgorithmSpot;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author smiranda
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForInboundCorrectedExceptionCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, required = true, type = entity, name = characteristicTypeForInboundUncorrectedExceptionCode)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForCorrectedExceptionCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForUncorrectedExceptionCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = characteristicTypeForMainExceptionCode, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = exceptionCodeFeatureConfigurationType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = exceptionPriorityFeatureConfigurationOptionType, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = nextStatus, required = true, type = string)})
 */
public class CmMeterExceptionCaseEvaluateInboundCharAlgComp_Impl 
extends CmMeterExceptionCaseEvaluateInboundCharAlgComp_Gen 
//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
//implements CaseTypeAutoTransitionAlgorithmSpot {
implements AutoTransitionAlgorithmSpot {
    //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.

    // Constants
    private final String _OPT_TYP_FLG = "_OPT_TYP_FLG";
    // TIR3-TIR4. Start Delete
    /*
    private final String CASE_LOG_ADD = "ADD";
    private final String CASE_LOG_UPDATE = "UPDATE";
    private final String CASE_LOG_DELETE = "DELETE";
    private final MessageCategory_Id MESSAGE_CAT = new MessageCategory_Id(BigInteger.valueOf(CustomMessagesMDC.MESSAGE_CATEGORY));
    private final BigInteger CASE_CHAR_ADDED_MSG_NUM = BigInteger.valueOf(CustomMessageRepositoryMDC.NI0007_5_1_CASE_CHAR_ADDED);
    private final BigInteger CASE_CHAR_UPDATED_MSG_NUM = BigInteger.valueOf(CustomMessageRepositoryMDC.NI0007_5_1_CASE_CHAR_UPDATED);
    private final BigInteger CASE_CHAR_DELETED_MSG_NUM = BigInteger.valueOf(CustomMessageRepositoryMDC.NI0007_5_1_CASE_CHAR_DELETED);
     */
    // TIR3-TIR4. End Delete

    // Variables for Hard Parameters
    private CaseStatus nextCaseStatus;
    private Bool shouldAutoTransition;
    private ToDoCase toDoCase;

    // Variables for Soft Parameters
    private CharacteristicType inboundCorrectedExceptionCodeCharType,
    // TIR3-TIR4. Start Delete
    /*
            inboundCorrectedExceptionRequestDateCharType,
            inboundCorrectedExceptionRequesterCharType,
            inboundCorrectedExceptionStatusCharType,
            inboundCorrectedExceptionStatusDateCharType,
     */
    // TIR3-TIR4. End Delete
    inboundUncorrectedExceptionCodeCharType,
    // TIR3-TIR4. Start Delete
    /*
            inboundUncorrectedExceptionRequestDateCharType,
            inboundUncorrectedExceptionRequesterCharType,
            inboundUncorrectedExceptionStatusCharType,
            inboundUncorrectedExceptionStatusDateCharType,
     */
    // TIR3-TIR4. End Delete
    permanentCorrectedExceptionCodeCharType,
    // TIR3-TIR4. Start Delete
    /*
            permanentCorrectedExceptionRequestDateCharType,
            permanentCorrectedExceptionRequesterCharType,
            permanentCorrectedExceptionStatusCharType,
            permanentCorrectedExceptionStatusDateCharType,
     */
    // TIR3-TIR4. End Delete
    permanentUncorrectedExceptionCodeCharType,
    // TIR3-TIR4. Start Delete
    /*
            permanentUncorrectedExceptionRequestDateCharType,
            permanentUncorrectedExceptionRequesterCharType,
            permanentUncorrectedExceptionStatusCharType,
            permanentUncorrectedExceptionStatusDateCharType,
     */
    // TIR3-TIR4. End Delete
    mainExceptionCodeCharType;
    // TIR3-TIR4. Start Delete
    /*
            mainExceptionRequestDateCharType,
            mainExceptionRequesterCharType,
            mainExceptionStatusCharType,
            mainExceptionStatusDateCharType;
     */
    // TIR3-TIR4. End Delete
    private FeatureConfiguration exceptionCodeFeatureConfigurationType;
    private String exceptionPriorityFeatureConfigurationOptionType, 
    nextStatus;

    // Other work variables
    private CaseType caseType;
    private String algCodeStr;    
    private Bool permanentExceptionCodeUpdatedSw,
    mainExceptionCodeUpdatedSw;
    // TIR3-TIR4. Start Delete
    /*
            mainExceptionRequestDateUpdatedSw,
            mainExceptionRequesterUpdatedSw,
            mainExceptionStatusDateUpdatedSw,
            mainExceptionStatusUpdatedSw;
     */
    // TIR3-TIR4. End Delete

    private CaseStatus_Id caseStatus_Id;

    private SQLResultRow caseCharSQLResult = null;

    private String inboundCorrectedExceptionCode = "",
            permanentCorrectedExceptionCode = "",
            // TIR3-TIR4. Start Delete
            /*
            inboundCorrectedExceptionRequestDate = "",
            permanentCorrectedExceptionRequestDate = "",
            inboundCorrectedExceptionRequester = "",
            permanentCorrectedExceptionRequester = "",
            inboundCorrectedExceptionStatus = "",
            permanentCorrectedExceptionStatus = "",
            inboundCorrectedExceptionStatusDate = "",
            permanentCorrectedExceptionStatusDate = "",
             */
            // TIR3-TIR4. End Delete
            // Uncorrected
            inboundUncorrectedExceptionCode = "",
            permanentUncorrectedExceptionCode = "",
            // TIR3-TIR4. Start Delete
            /*
            inboundUncorrectedExceptionRequestDate = "",
            permanentUncorrectedExceptionRequestDate = "",
            inboundUncorrectedExceptionRequester = "",
            permanentUncorrectedExceptionRequester = "",
            inboundUncorrectedExceptionStatus = "",
            permanentUncorrectedExceptionStatus = "",
            inboundUncorrectedExceptionStatusDate = "",
            permanentUncorrectedExceptionStatusDate = "",
             */
            // TIR3-TIR4. End Delete
            // Main
            mainExceptionCode = "";
    // TIR3-TIR4. Start Delete
    /*
            mainExceptionRequestDate = "",
            mainExceptionRequester = "",
            mainExceptionStatus = "",
            mainExceptionStatusDate = "",
            origMainExceptionCode = "",
            origMainExceptionRequestDate = "",
            origMainExceptionRequester = "",
            origMainExceptionStatus = "",
            origMainExceptionStatusDate = "";
     */
    // TIR3-TIR4. End Delete.
    private BigInteger
    // TIR3-TIR4. Start Delete
    //inboundCorrectedExceptionCodeSeq = BigInteger.ZERO,
    // TIR3-TIR4. End Delete
    inboundCorrectedExceptionCodePriority = BigInteger.valueOf(-1),
    // TIR3-TIR4. Start Delete
    //permanentCorrectedExceptionCodeSeq = BigInteger.ZERO,
    // TIR3-TIR4. End Delete
    permanentCorrectedExceptionCodePriority = BigInteger.valueOf(-1),
    // TIR3-TIR4. Start Delete
    /*
            inboundCorrectedExceptionRequestDateSeq = BigInteger.ZERO,
            permanentCorrectedExceptionRequestDateSeq = BigInteger.ZERO,
            inboundCorrectedExceptionRequesterSeq = BigInteger.ZERO,
            permanentCorrectedExceptionRequesterSeq = BigInteger.ZERO,
            inboundCorrectedExceptionStatusSeq = BigInteger.ZERO,
            permanentCorrectedExceptionStatusSeq = BigInteger.ZERO,
            inboundCorrectedExceptionStatusDateSeq = BigInteger.ZERO,
            permanentCorrectedExceptionStatusDateSeq = BigInteger.ZERO,
     */
    // TIR3-TIR4. End Delete
    // Uncorrected
    // TIR3-TIR4. Start Delete
    //inboundUncorrectedExceptionCodeSeq = BigInteger.ZERO,
    // TIR3-TIR4. End Delete
    inboundUncorrectedExceptionCodePriority = BigInteger.valueOf(-1),
    // TIR3-TIR4. Start Delete
    //permanentUncorrectedExceptionCodeSeq = BigInteger.ZERO,
    // TIR3-TIR4. End Delete
    permanentUncorrectedExceptionCodePriority = BigInteger.valueOf(-1),
    // TIR3-TIR4. Start Delete
    /*
            inboundUncorrectedExceptionRequestDateSeq = BigInteger.ZERO,
            permanentUncorrectedExceptionRequestDateSeq = BigInteger.ZERO,
            inboundUncorrectedExceptionRequesterSeq = BigInteger.ZERO,
            permanentUncorrectedExceptionRequesterSeq = BigInteger.ZERO,
            inboundUncorrectedExceptionStatusSeq = BigInteger.ZERO,
            permanentUncorrectedExceptionStatusSeq = BigInteger.ZERO,
            inboundUncorrectedExceptionStatusDateSeq = BigInteger.ZERO,
            permanentUncorrectedExceptionStatusDateSeq = BigInteger.ZERO,
     */
    // TIR3-TIR4. End Delete
    // Main
    // TIR3-TIR4. Start Delete
    //mainExceptionCodeSeq = BigInteger.ZERO,
    // TIR3-TIR4. End Delete
    mainExceptionCodePriority = BigInteger.valueOf(-1);
    // TIR3-TIR4. Start Delete
    /*
            mainExceptionRequestDateSeq = BigInteger.ZERO,
            mainExceptionRequesterSeq = BigInteger.ZERO,
            mainExceptionStatusSeq = BigInteger.ZERO,
            mainExceptionStatusDateSeq = BigInteger.ZERO;
     */
    // TIR3-TIR4. ENd Delete
    
    public CaseStatus getNextCaseStatus() {

        return nextCaseStatus;
    }

    public String getNextTransCondition() {

        return null;
    }

    public Bool getShouldAutoTransition() {

        return shouldAutoTransition;
    }

    public void setCase(ToDoCase arg0) {
        // Get Case
        toDoCase = arg0;
    }

    public void invoke() {   
        // Get Case Type
        caseType = toDoCase.getCaseStatus().fetchIdCaseType();
        // Validate the Next Status soft parameter
        validateNextStatus();

        // Set the following variables to FALSE
        permanentExceptionCodeUpdatedSw = Bool.FALSE;
        shouldAutoTransition = Bool.FALSE;

        // Evaluate Inbound Corrected Characteristics and update the Permanent Corrected Characteristics as needed
        evaluateInboundCorrectedCharacteristics();   

        // Evaluate Inbound Uncorrected Characteristics and update the Permanent Uncorrected Characteristics as needed
        evaluateInboundUncorrectedCharacteristics();

        if (permanentExceptionCodeUpdatedSw.isTrue()){

            // Set the following variables to FALSE
            mainExceptionCodeUpdatedSw = Bool.FALSE;
            // TIR3-TIR4. Start Delete
            /*
            mainExceptionRequestDateUpdatedSw = Bool.FALSE;
            mainExceptionRequesterUpdatedSw = Bool.FALSE;
            mainExceptionStatusDateUpdatedSw = Bool.FALSE;
            mainExceptionStatusUpdatedSw = Bool.FALSE;
             */
            // TIR3-TIR4. End Delete

            // Evaluate Permanent Corrected Characteristics and update the Main Characteristics as needed
            evaluatePermanentCorrectedCharacteristics();

            // Evaluate Permanent Uncorrected Characteristics and update the Main Characteristics as needed
            evaluatePermanentUncorrectedCharacteristics();

            // Create or Update Main Characteristics
            // TIR3-TIR4. Start Delete
            //createOrUpdateMainCharacteristics();
            // TIR3-TIR4. End Delete

            if (mainExceptionCodeUpdatedSw.isTrue()){
                nextCaseStatus = caseStatus_Id.getEntity();
                shouldAutoTransition = Bool.TRUE;
                // TIR3-TIR4. Start Delete
                // TIR1. Start Add
                //toDoCase.autoTransitionCase(nextCaseStatus, null, Bool.TRUE);
                // TIR1. End Add
                // TIR3-TIR4. End Delete
            }
        }
    }

    private void validateNextStatus () {
        // Next Status parameter must be valid for the Case Type
        caseStatus_Id = new CaseStatus_Id(caseType, nextStatus);
        if (isNull(caseStatus_Id.getEntity())){
            addError(CustomMessageRepositoryMDC.NI0007_5_1_statusInvForCaseType(
                    algCodeStr, 
                    nextStatus.trim(), 
                    caseType.getId().getIdValue().trim()));                     
        }
        //Start Delete - 2016-05-05 - MPang - Defect 3429075
        // Next Status parameter must be valid for the current case status
        //CaseStatusTransitionRule_Id caseStatusTransRule_Id 
        //= new CaseStatusTransitionRule_Id(caseStatus_Id, toDoCase.getCaseStatus().fetchIdStatus().trim());
        //if (isNull(caseStatusTransRule_Id.getEntity())){
        //    addError(CustomMessageRepositoryMDC.NI0007_5_1_statusInvForStatus(
        //            algCodeStr, 
        //            nextStatus.trim(), 
        //            toDoCase.getCaseStatus().fetchIdStatus().trim()));
        //}
        //End Delete - 2016-05-05 - MPang - Defect 3429075
    }
    private void evaluateInboundCorrectedCharacteristics(){      

        // Get Inbound Corrected Characteristics
        getInboundCorrectedCharacteristics();

        // Get Permanent Corrected Characteristics
        getPermanentCorrectedCharacteristics();               

        /* 
         * If there is no Permanent Corrected Exception Code Characteristic, or if the Inbound Corrected Exception Code 
         * has a higher priority than the Permanent Corrected Exception Code, create or update the Permanent Characteristics.
         */
        if (permanentCorrectedExceptionCode == ""
                || (inboundCorrectedExceptionCodePriority.intValue() != -1 && 
                (inboundCorrectedExceptionCodePriority.intValue() < permanentCorrectedExceptionCodePriority.intValue()))){

            // Create or Update Permanent Corrected Exception Code
            if (inboundCorrectedExceptionCode != ""){
                // TIR3-TIR4. Start Delete
                /*
                createOrUpdatePermChar(inboundCorrectedExceptionCode,
                        permanentCorrectedExceptionCodeCharType,
                        permanentCorrectedExceptionCodeSeq,
                        permanentCorrectedExceptionCode);
                 */
                // TIR3-TIR4. End Delete
                permanentCorrectedExceptionCode = inboundCorrectedExceptionCode;
                permanentCorrectedExceptionCodePriority = inboundCorrectedExceptionCodePriority;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }                        

            // TIR3-TIR4. Start Delete
            /*
            // Create or update Permanent Corrected Exception Request Date characteristic             
            if (inboundCorrectedExceptionRequestDate != ""){                                
                createOrUpdatePermChar(inboundCorrectedExceptionRequestDate,
                        permanentCorrectedExceptionRequestDateCharType,
                        permanentCorrectedExceptionRequestDateSeq,
                        permanentCorrectedExceptionRequestDate);
                permanentCorrectedExceptionRequestDate = inboundCorrectedExceptionRequestDate;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }                        

            // Create or update Permanent Corrected Exception Requester characteristic             
            if (inboundCorrectedExceptionRequester != ""){                                
                createOrUpdatePermChar(inboundCorrectedExceptionRequester,
                        permanentCorrectedExceptionRequesterCharType,
                        permanentCorrectedExceptionRequesterSeq,
                        permanentCorrectedExceptionRequester);
                permanentCorrectedExceptionRequester = inboundCorrectedExceptionRequester;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }                      


            // Create or update Permanent Corrected Exception Status characteristic             
            if (inboundCorrectedExceptionStatus != ""){                                
                createOrUpdatePermChar(inboundCorrectedExceptionStatus,
                        permanentCorrectedExceptionStatusCharType,
                        permanentCorrectedExceptionStatusSeq,
                        permanentCorrectedExceptionStatus);
                permanentCorrectedExceptionStatus = inboundCorrectedExceptionStatus;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }                       

            // Create or update Permanent Corrected Exception Status Date characteristic             
            if (inboundCorrectedExceptionStatusDate != ""){                                
                createOrUpdatePermChar(inboundCorrectedExceptionStatusDate,
                        permanentCorrectedExceptionStatusDateCharType,
                        permanentCorrectedExceptionStatusDateSeq,
                        permanentCorrectedExceptionStatusDate);
                permanentCorrectedExceptionStatusDate = inboundCorrectedExceptionStatusDate;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }
             */
            // TIR3-TIR4. End Delete

        }
        // TIR3-TIR4. Start Delete
        /*
        // Delete the Inbound Corrected Exception Code Characteristic
        if (inboundCorrectedExceptionCode != ""){
            deleteCaseChar(inboundCorrectedExceptionCodeCharType, 
                    inboundCorrectedExceptionCodeSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedExceptionCodeCharType, 
                    inboundCorrectedExceptionCodeSeq, 
                    inboundCorrectedExceptionCode, 
                    CASE_LOG_DELETE); 
        }

        // Delete the Inbound Corrected Exception Request Date Characteristic
        if (inboundCorrectedExceptionRequestDate != ""){
            deleteCaseChar(inboundCorrectedExceptionRequestDateCharType, 
                    inboundCorrectedExceptionRequestDateSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedExceptionRequestDateCharType, 
                    inboundCorrectedExceptionRequestDateSeq, 
                    inboundCorrectedExceptionRequestDate, 
                    CASE_LOG_DELETE); 
        }

        // Delete the Inbound Corrected Exception Requester Characteristic
        if (inboundCorrectedExceptionRequester != ""){
            deleteCaseChar(inboundCorrectedExceptionRequesterCharType, 
                    inboundCorrectedExceptionRequesterSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedExceptionRequesterCharType, 
                    inboundCorrectedExceptionRequesterSeq, 
                    inboundCorrectedExceptionRequester, 
                    CASE_LOG_DELETE); 
        }

        // Delete the Inbound Corrected Exception Status Characteristic
        if (inboundCorrectedExceptionStatus != ""){
            deleteCaseChar(inboundCorrectedExceptionStatusCharType, 
                    inboundCorrectedExceptionStatusSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedExceptionStatusCharType, 
                    inboundCorrectedExceptionStatusSeq, 
                    inboundCorrectedExceptionStatus, 
                    CASE_LOG_DELETE); 
        }

        // Delete the Inbound Corrected Exception Status Date Characteristic
        if (inboundCorrectedExceptionStatusDate != ""){
            deleteCaseChar(inboundCorrectedExceptionStatusDateCharType, 
                    inboundCorrectedExceptionStatusDateSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundCorrectedExceptionStatusDateCharType, 
                    inboundCorrectedExceptionStatusDateSeq, 
                    inboundCorrectedExceptionStatusDate, 
                    CASE_LOG_DELETE); 
        }
         */
        // TIR3-TIR4. End Delete

    }    

    private void getInboundCorrectedCharacteristics() {

        // Determine whether an Inbound Corrected Exception Code Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedExceptionCodeCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedExceptionCode = caseCharSQLResult.getString("CHARVAL");
            // TIR3-TIR4. Start Delete
            //inboundCorrectedExceptionCodeSeq = caseCharSQLResult.getInteger("SEQNUM"); 
            // TIR3-TIR4. End Delete
        }    

        // If so, retrieve the exception priority using Feature Configuration for the exception code.
        if (inboundCorrectedExceptionCode != ""){
            inboundCorrectedExceptionCodePriority = getExceptionPriority(inboundCorrectedExceptionCode);                    
        }

        // TIR3-TIR4. Start Delete
        /*
        // Determine whether an Inbound Corrected Exception Request Date Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedExceptionRequestDateCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedExceptionRequestDate = caseCharSQLResult.getString("CHARVAL");
            inboundCorrectedExceptionRequestDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }

        // Determine whether an Inbound Corrected Exception Requester Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedExceptionRequesterCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedExceptionRequester = caseCharSQLResult.getString("CHARVAL");
            inboundCorrectedExceptionRequesterSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }

        // Determine whether an Inbound Corrected Exception Status Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            inboundCorrectedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }

        // Determine whether an Inbound Corrected Exception Status Date Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundCorrectedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            inboundCorrectedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            inboundCorrectedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
         */
        // TIR3-TIR4. End Delete

    }

    private void getPermanentCorrectedCharacteristics() {

        // Determine whether a Permanent Corrected Exception Code Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentCorrectedExceptionCodeCharType);
        if (notNull(caseCharSQLResult)){
            permanentCorrectedExceptionCode = caseCharSQLResult.getString("CHARVAL");
            // TIR3-TIR4. Start Delete
            //permanentCorrectedExceptionCodeSeq = caseCharSQLResult.getInteger("SEQNUM"); 
            // TIR3-TIR4. End Delete
        }

        // If so, retrieve the exception priority using Feature Configuration for the exception code.
        if (permanentCorrectedExceptionCode != ""){
            permanentCorrectedExceptionCodePriority = getExceptionPriority(permanentCorrectedExceptionCode);                    
        }

        // TIR3-TIR4. Start Delete
        /*
        // Determine whether a Permanent Corrected Exception Request Date Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentCorrectedExceptionRequestDateCharType);
        if (notNull(caseCharSQLResult)){
            permanentCorrectedExceptionRequestDate = caseCharSQLResult.getString("CHARVAL");
            permanentCorrectedExceptionRequestDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }

        // Determine whether a Permanent Corrected Exception Requester Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentCorrectedExceptionRequesterCharType);
        if (notNull(caseCharSQLResult)){
            permanentCorrectedExceptionRequester = caseCharSQLResult.getString("CHARVAL");
            permanentCorrectedExceptionRequesterSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }

        // Determine whether a Permanent Corrected Exception Status Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentCorrectedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            permanentCorrectedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            permanentCorrectedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }

        // Determine whether a Permanent Corrected Exception Status Date Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentCorrectedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            permanentCorrectedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            permanentCorrectedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
         */
        // TIR3-TIR4. End Delete

    }

    private void evaluateInboundUncorrectedCharacteristics(){    

        // Get Inbound Uncorrected Characteristics
        getInboundUncorrectedCharacteristics();

        // Get Permanent Uncorrected Characteristics
        getPermanentUncorrectedCharacteristics();        

        /* 
         * If there is no Permanent Uncorrected Exception Code Characteristic, or if the Inbound Uncorrected Exception Code 
         * has a higher priority than the Permanent Uncorrected Exception Code, create or update the Permanent Characteristics.
         */
        if (permanentUncorrectedExceptionCode == ""
                || (inboundUncorrectedExceptionCodePriority.intValue() != -1 && 
                (inboundUncorrectedExceptionCodePriority.intValue() < permanentUncorrectedExceptionCodePriority.intValue()))){

            // Create or Update Permanent Uncorrected Exception Code
            if (inboundUncorrectedExceptionCode != ""){
                // TIR3-TIR4. Start Delete
                /*
                createOrUpdatePermChar(inboundUncorrectedExceptionCode,
                        permanentUncorrectedExceptionCodeCharType,
                        permanentUncorrectedExceptionCodeSeq,
                        permanentUncorrectedExceptionCode);
                 */
                // TIR3-TIR4. End Delete
                permanentUncorrectedExceptionCode = inboundUncorrectedExceptionCode;
                permanentUncorrectedExceptionCodePriority = inboundUncorrectedExceptionCodePriority;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }            

            // TIR3-TIR4. Start Delete
            /*
            //If Inbound Uncorrected Exception Request Date Characteristic exists, 
            //create or update Permanent Uncorrected Exception Request Date characteristic
            if (inboundUncorrectedExceptionRequestDate != ""){                                
                createOrUpdatePermChar(inboundUncorrectedExceptionRequestDate,
                        permanentUncorrectedExceptionRequestDateCharType,
                        permanentUncorrectedExceptionRequestDateSeq,
                        permanentUncorrectedExceptionRequestDate);
                permanentUncorrectedExceptionRequestDate = inboundUncorrectedExceptionRequestDate;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }            

            //If Inbound Uncorrected Exception Requester Characteristic exists, 
            //create or update Permanent Uncorrected Exception Requester characteristic
            if (inboundUncorrectedExceptionRequester != ""){                                
                createOrUpdatePermChar(inboundUncorrectedExceptionRequester,
                        permanentUncorrectedExceptionRequesterCharType,
                        permanentUncorrectedExceptionRequesterSeq,
                        permanentUncorrectedExceptionRequester);
                permanentUncorrectedExceptionRequester = inboundUncorrectedExceptionRequester;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }            

            //If Inbound Uncorrected Exception Status Characteristic exists, 
            //create or update Permanent Uncorrected Exception Status characteristic
            if (inboundUncorrectedExceptionStatus != ""){                                
                createOrUpdatePermChar(inboundUncorrectedExceptionStatus,
                        permanentUncorrectedExceptionStatusCharType,
                        permanentUncorrectedExceptionStatusSeq,
                        permanentUncorrectedExceptionStatus);
                permanentUncorrectedExceptionStatus = inboundUncorrectedExceptionStatus;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }            

            //If Inbound Uncorrected Exception Status Date Characteristic exists, 
            //create or update Permanent Uncorrected Exception Status Date characteristic
            if (inboundUncorrectedExceptionStatusDate != ""){                                
                createOrUpdatePermChar(inboundUncorrectedExceptionStatusDate,
                        permanentUncorrectedExceptionStatusDateCharType,
                        permanentUncorrectedExceptionStatusDateSeq,
                        permanentUncorrectedExceptionStatusDate);
                permanentUncorrectedExceptionStatusDate = inboundUncorrectedExceptionStatusDate;
                permanentExceptionCodeUpdatedSw = Bool.TRUE;
            }  
             */                  
            // TIR3-TIR4. End Delete           
        }
        // TIR3-TIR4. Start Delete
        /*
        // Delete the Inbound Uncorrected Exception Code Characteristic
        if (inboundUncorrectedExceptionCode != ""){
            deleteCaseChar(inboundUncorrectedExceptionCodeCharType, 
                    inboundUncorrectedExceptionCodeSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedExceptionCodeCharType, 
                    inboundUncorrectedExceptionCodeSeq, 
                    inboundUncorrectedExceptionCode, 
                    CASE_LOG_DELETE); 
        }

        // Delete the Inbound Uncorrected Exception Request Date Characteristic
        if (inboundUncorrectedExceptionRequestDate != ""){
            deleteCaseChar(inboundUncorrectedExceptionRequestDateCharType, 
                    inboundUncorrectedExceptionRequestDateSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedExceptionRequestDateCharType, 
                    inboundUncorrectedExceptionRequestDateSeq, 
                    inboundUncorrectedExceptionRequestDate, 
                    CASE_LOG_DELETE); 
        }

        // Delete the Inbound Uncorrected Exception Requester Characteristic
        if (inboundUncorrectedExceptionRequester != ""){
            deleteCaseChar(inboundUncorrectedExceptionRequesterCharType, 
                    inboundUncorrectedExceptionRequesterSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedExceptionRequesterCharType, 
                    inboundUncorrectedExceptionRequesterSeq, 
                    inboundUncorrectedExceptionRequester, 
                    CASE_LOG_DELETE); 
        }

        // Delete the Inbound Uncorrected Exception Status Characteristic
        if (inboundUncorrectedExceptionStatus != ""){
            deleteCaseChar(inboundUncorrectedExceptionStatusCharType, 
                    inboundUncorrectedExceptionStatusSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedExceptionStatusCharType, 
                    inboundUncorrectedExceptionStatusSeq, 
                    inboundUncorrectedExceptionStatus, 
                    CASE_LOG_DELETE); 
        }

        // Delete the Inbound Uncorrected Exception Status Date Characteristic
        if (inboundUncorrectedExceptionStatusDate != ""){
            deleteCaseChar(inboundUncorrectedExceptionStatusDateCharType, 
                    inboundUncorrectedExceptionStatusDateSeq);
            // Create case log for deleted characteristic
            createCaseLog(inboundUncorrectedExceptionStatusDateCharType, 
                    inboundUncorrectedExceptionStatusDateSeq, 
                    inboundUncorrectedExceptionStatusDate, 
                    CASE_LOG_DELETE); 
        }
         */
        // TIR3-TIR4. End Delete

    }

    private void getInboundUncorrectedCharacteristics() {

        // Determine whether an Inbound Uncorrected Exception Code Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedExceptionCodeCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedExceptionCode = caseCharSQLResult.getString("CHARVAL");
            // TIR3-TIR4. Start Delete
            //inboundUncorrectedExceptionCodeSeq = caseCharSQLResult.getInteger("SEQNUM");    
            // TIR3-TIR4. End Delete
        }    

        // If so, retrieve the exception priority using Feature Configuration for the exception code.
        if (inboundUncorrectedExceptionCode != ""){
            inboundUncorrectedExceptionCodePriority = getExceptionPriority(inboundUncorrectedExceptionCode);                    
        }
        // TIR3-TIR4. Start Delete
        /*
        // Determine whether an Inbound Uncorrected Exception Request Date Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedExceptionRequestDateCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedExceptionRequestDate = caseCharSQLResult.getString("CHARVAL");
            inboundUncorrectedExceptionRequestDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }

        // Determine whether an Inbound Uncorrected Exception Requester Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedExceptionRequesterCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedExceptionRequester = caseCharSQLResult.getString("CHARVAL");
            inboundUncorrectedExceptionRequesterSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }

        // Determine whether an Inbound Uncorrected Exception Status Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            inboundUncorrectedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }       

        // Determine whether an Inbound Uncorrected Exception Status Date Characteristic exists.
        caseCharSQLResult = getCaseChar(inboundUncorrectedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            inboundUncorrectedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            inboundUncorrectedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }        
         */
        // TIR3-TIR4. End Delete

    }

    private void getPermanentUncorrectedCharacteristics() {

        // Determine whether a Permanent Uncorrected Exception Code Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentUncorrectedExceptionCodeCharType);
        if (notNull(caseCharSQLResult)){
            permanentUncorrectedExceptionCode = caseCharSQLResult.getString("CHARVAL");
            // TIR3-TIR4. Start Delete
            //permanentUncorrectedExceptionCodeSeq = caseCharSQLResult.getInteger("SEQNUM");  
            // TIR3-TIR4. End Delete
        }

        // If so, retrieve the exception priority using Feature Configuration for the exception code.
        if (permanentUncorrectedExceptionCode != ""){
            permanentUncorrectedExceptionCodePriority = getExceptionPriority(permanentUncorrectedExceptionCode);                    
        }

        // TIR3-TIR4. Start Delete
        /*
        // Determine whether a Permanent Uncorrected Exception Request Date Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentUncorrectedExceptionRequestDateCharType);
        if (notNull(caseCharSQLResult)){
            permanentUncorrectedExceptionRequestDate = caseCharSQLResult.getString("CHARVAL");
            permanentUncorrectedExceptionRequestDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }

        // Determine whether a Permanent Uncorrected Exception Requester Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentUncorrectedExceptionRequesterCharType);
        if (notNull(caseCharSQLResult)){
            permanentUncorrectedExceptionRequester = caseCharSQLResult.getString("CHARVAL");
            permanentUncorrectedExceptionRequesterSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }

        // Determine whether a Permanent Uncorrected Exception Status Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentUncorrectedExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            permanentUncorrectedExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            permanentUncorrectedExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }

        // Determine whether a Permanent Uncorrected Exception Status Date Characteristic exists.
        caseCharSQLResult = getCaseChar(permanentUncorrectedExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            permanentUncorrectedExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            permanentUncorrectedExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");            
        }
         */
        // TIR3-TIR4. End Delete
    }

    private void evaluatePermanentCorrectedCharacteristics(){

        // Get Main characteristics
        getMainCharacteristics();  

        /* 
         * If there is no Main Exception Code Characteristic, or if the Permanent Corrected Exception Code 
         * has a higher priority than the Main Exception Code, create or update the Main Characteristics.
         */
        if (mainExceptionCode == ""
                || (permanentCorrectedExceptionCodePriority.intValue() != -1 && 
                (permanentCorrectedExceptionCodePriority.intValue() < mainExceptionCodePriority.intValue()))){

            // Create or Update the Main Exception Code
            if (permanentCorrectedExceptionCode != ""){               
                mainExceptionCode = permanentCorrectedExceptionCode;
                mainExceptionCodePriority = permanentCorrectedExceptionCodePriority;
                mainExceptionCodeUpdatedSw = Bool.TRUE; 
            }                      

            // TIR3-TIR4. Start Delete
            /*
            // Create or Update the Main Exception Request Date
            if (permanentCorrectedExceptionRequestDate != ""){
                mainExceptionRequestDateUpdatedSw = Bool.TRUE;
                mainExceptionRequestDate = permanentCorrectedExceptionRequestDate;                
            }       

            // Create or Update the Main Exception Requester
            if (permanentCorrectedExceptionRequester != ""){
                mainExceptionRequesterUpdatedSw = Bool.TRUE;
                mainExceptionRequester = permanentCorrectedExceptionRequester;
            }                        

            // Create or Update the Main Exception Status
            if (permanentCorrectedExceptionStatus != ""){
                mainExceptionStatusUpdatedSw = Bool.TRUE;
                mainExceptionStatus = permanentCorrectedExceptionStatus;
            }                                   

            // Create or Update the Main Exception Status Date
            if (permanentCorrectedExceptionStatusDate != ""){
                mainExceptionStatusDateUpdatedSw = Bool.TRUE;
                mainExceptionStatusDate = permanentCorrectedExceptionStatusDate;
            }
             */
            // TIR3-TIR4. End Delete

        }

    }

    private void getMainCharacteristics() {

        // Determine whether a Main Exception Code Characteristic exists.
        caseCharSQLResult = getCaseChar(mainExceptionCodeCharType);
        if (notNull(caseCharSQLResult)){
            mainExceptionCode = caseCharSQLResult.getString("CHARVAL");
            // TIR3-TIR4. Start Delete
            //mainExceptionCodeSeq = caseCharSQLResult.getInteger("SEQNUM"); 
            //origMainExceptionCode = mainExceptionCode;
            // TIR3-TIR4. End Delete
        }

        // If so, retrieve the exception priority using Feature Configuration for the exception code.
        if (mainExceptionCode != ""){
            mainExceptionCodePriority = getExceptionPriority(mainExceptionCode);                    
        }

        // TIR3-TIR4. Start Delete
        /*
        // Determine whether a Main Exception Request Date Characteristic exists.
        caseCharSQLResult = getCaseChar(mainExceptionRequestDateCharType);
        if (notNull(caseCharSQLResult)){
            mainExceptionRequestDate = caseCharSQLResult.getString("CHARVAL");
            mainExceptionRequestDateSeq = caseCharSQLResult.getInteger("SEQNUM");    
            origMainExceptionRequestDate = mainExceptionRequestDate;
        }

        // Determine whether a Main Exception Requester Characteristic exists.
        caseCharSQLResult = getCaseChar(mainExceptionRequesterCharType);
        if (notNull(caseCharSQLResult)){
            mainExceptionRequester = caseCharSQLResult.getString("CHARVAL");
            mainExceptionRequesterSeq = caseCharSQLResult.getInteger("SEQNUM");
            origMainExceptionRequester = mainExceptionRequester;
        }

        // Determine whether a Main Exception Status Characteristic exists.
        caseCharSQLResult = getCaseChar(mainExceptionStatusCharType);
        if (notNull(caseCharSQLResult)){
            mainExceptionStatus = caseCharSQLResult.getString("CHARVAL");
            mainExceptionStatusSeq = caseCharSQLResult.getInteger("SEQNUM");   
            origMainExceptionStatus = mainExceptionStatus;
        }

        // Determine whether a Main Exception Status Date Characteristic exists.
        caseCharSQLResult = getCaseChar(mainExceptionStatusDateCharType);
        if (notNull(caseCharSQLResult)){
            mainExceptionStatusDate = caseCharSQLResult.getString("CHARVAL");
            mainExceptionStatusDateSeq = caseCharSQLResult.getInteger("SEQNUM");     
            origMainExceptionStatusDate = mainExceptionStatusDate;
        }        
         */
        // TIR3-TIR4. End Delete

    }

    private void evaluatePermanentUncorrectedCharacteristics(){
        /* 
         * If there is no Main Exception Code Characteristic, or if the Permanent Uncorrected Exception Code 
         * has a higher priority than the Main Exception Code, create or update the Main Characteristics.
         */
        if (mainExceptionCode == ""
                || (permanentUncorrectedExceptionCodePriority.intValue() != -1 && 
                (permanentUncorrectedExceptionCodePriority.intValue() < mainExceptionCodePriority.intValue()))){

            // Create or Update the Main Exception Code
            if (permanentUncorrectedExceptionCode != ""){
                mainExceptionCode = permanentUncorrectedExceptionCode;
                mainExceptionCodeUpdatedSw = Bool.TRUE;
            }                       
            // TIR3-TIR4. Start Delete
            /*
            // Create or Update the Main Exception Request Date
            if (permanentUncorrectedExceptionRequestDate != ""){
                mainExceptionRequestDateUpdatedSw = Bool.TRUE;
                mainExceptionRequestDate = permanentUncorrectedExceptionRequestDate;
            }            

            // Create or Update the Main Exception Requester
            if (permanentUncorrectedExceptionRequester != ""){
                mainExceptionRequesterUpdatedSw = Bool.TRUE;
                mainExceptionRequester = permanentUncorrectedExceptionRequester;
            }            

            // Create or Update the Main Exception Status
            if (permanentUncorrectedExceptionStatus != ""){
                mainExceptionStatusUpdatedSw = Bool.TRUE;
                mainExceptionStatus = permanentUncorrectedExceptionStatus;
            }            

            // Create or Update the Main Exception Status Date
            if (permanentUncorrectedExceptionStatusDate != ""){
                mainExceptionStatusDateUpdatedSw = Bool.TRUE;
                mainExceptionStatusDate = permanentUncorrectedExceptionStatusDate;
            }
             */
            // TIR3-TIR4. End Delete

        }

    }

    // TIR3-TIR4. Start Delete
    /*
    private void createOrUpdateMainCharacteristics() {

        // Create or Update Main Exception Code
        if (mainExceptionCodeUpdatedSw.isTrue()){
            createOrUpdateMainChar(mainExceptionCodeCharType,
                    mainExceptionCodeSeq,
                    mainExceptionCode,
                    origMainExceptionCode);
        }

        // Create or Update Main Exception Request Date
        if (mainExceptionRequestDateUpdatedSw.isTrue()){
            createOrUpdateMainChar(mainExceptionRequestDateCharType,
                    mainExceptionRequestDateSeq,
                    mainExceptionRequestDate,
                    origMainExceptionRequestDate);
        }

        // Create or Update Main Exception Requester
        if (mainExceptionRequesterUpdatedSw.isTrue()){
            createOrUpdateMainChar(mainExceptionRequesterCharType,
                    mainExceptionRequesterSeq,
                    mainExceptionRequester,
                    origMainExceptionRequester);
        }

        // Create or Update Main Exception Status Date
        if (mainExceptionStatusDateUpdatedSw.isTrue()){
            createOrUpdateMainChar(mainExceptionStatusDateCharType,
                    mainExceptionStatusDateSeq,
                    mainExceptionStatusDate,
                    origMainExceptionStatusDate);
        }

        // Create or Update Main Exception Status
        if (mainExceptionStatusUpdatedSw.isTrue()){
            createOrUpdateMainChar(mainExceptionStatusCharType,
                    mainExceptionStatusSeq,
                    mainExceptionStatus,
                    origMainExceptionStatus);
        }

    }
     */
    // TIR3-TIR4. End Delete

    private SQLResultRow getCaseChar(CharacteristicType charType){

        SQLResultRow caseCharSQLResult = null;        
        String charVal = "";

        if (charType.getCharacteristicType().isPredefinedValue()){
            charVal = "CACH.CHAR_VAL ";
        }        
        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            charVal = "CACH.ADHOC_CHAR_VAL ";
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            charVal = "CACH.CHAR_VAL_FK1 ";
        }

        PreparedStatement getCaseChar 
        = createPreparedStatement(
                "SELECT " +
                        charVal + "AS CHARVAL, " +
                        "CACH.SEQ_NUM AS SEQNUM " +
                        "FROM " +
                        "CI_CASE_CHAR CACH " +
                        "WHERE " +
                        "CACH.CASE_ID = :caseId " +
                        "AND CACH.CHAR_TYPE_CD = :charTypeCd " +
                        "AND CACH.SEQ_NUM = (SELECT MAX(CACH2.SEQ_NUM) " +
                        "FROM CI_CASE_CHAR CACH2 " +
                        "WHERE CACH2.CASE_ID = CACH.CASE_ID " +
                        //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                        //"AND CACH2.CHAR_TYPE_CD = CACH.CHAR_TYPE_CD)");
                        "AND CACH2.CHAR_TYPE_CD = CACH.CHAR_TYPE_CD)", getClass().getName());
        //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.

        getCaseChar.bindId("caseId", toDoCase.getId());
        getCaseChar.bindId("charTypeCd", charType.getId());
        caseCharSQLResult = getCaseChar.firstRow();                        

        return caseCharSQLResult;
    }

    private BigInteger getExceptionPriority(String exceptionCode){        

        FrameworkSession session = (FrameworkSession) SessionHolder.getSession();

        String exceptionPriorityOptVal = "",
                exceptionPriorityStr = "",
                nfeMessage = "";
        BigInteger exceptionPriority = BigInteger.ZERO;
        SQLResultRow exceptionPrioritySQLResult = null;
        List<SQLResultRow> excPriorityList;

        PreparedStatement getExcPriority
        = createPreparedStatement(
                "SELECT " +
                        "OPT.WFM_OPT_VAL AS OPTVAL " +
                        "FROM " +
                        "CI_WFM_OPT OPT " +
                        "WHERE " +
                        "OPT.WFM_NAME = :wfmName " +
                        "AND OPT.EXT_OPT_TYPE = :optType " +
                        //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                        //"AND OPT.WFM_OPT_VAL LIKE :optVal");
                        "AND OPT.WFM_OPT_VAL LIKE :optVal", getClass().getName());
        //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
        getExcPriority.bindId("wfmName", exceptionCodeFeatureConfigurationType.getId());
        getExcPriority.bindString("optType", exceptionPriorityFeatureConfigurationOptionType, "EXT_OPT_TYPE");
        getExcPriority.bindLikableString("optVal", exceptionCode.trim(), "WFM_OPT_VAL");  

        excPriorityList = getExcPriority.list();

        // Raise error message if Exception Code has no entry in the Feature Configuration
        if (excPriorityList.size() == 0){
            //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            //session.clear();
            session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_1_excpCodeNotFound(
                    algCodeStr, 
                    exceptionCode.trim(), 
                    exceptionCodeFeatureConfigurationType.getId().getIdValue().trim()));
        }

        // Raise error message if Exception Code has multiple entries in the Feature Configuration        
        if (excPriorityList.size() > 1){   
            //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            //session.clear();
            session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_1_excpCodeMultiFound(
                    algCodeStr, 
                    exceptionCode.trim(), 
                    exceptionCodeFeatureConfigurationType.getId().getIdValue().trim()));
        }

        // Retrieve option value if there is exactly one row retrieved
        exceptionPrioritySQLResult = excPriorityList.get(0);
        exceptionPriorityOptVal = exceptionPrioritySQLResult.getString("OPTVAL");

        // Get the characters after the first comma
        if (exceptionPriorityOptVal.indexOf(",") == -1){ 
            //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            //session.clear();
            session.clear(session.toString().trim());
            //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
            addError(CustomMessageRepositoryMDC.NI0007_5_1_excpCodeNoPriority(
                    algCodeStr, 
                    exceptionCode.trim(), 
                    exceptionCodeFeatureConfigurationType.getId().getIdValue().trim()));
        }
        exceptionPriorityStr = exceptionPriorityOptVal.substring(exceptionPriorityOptVal.indexOf(",") + 1).trim();                        

        // Convert the string Priority value to an integer value
        try{
            exceptionPriority = BigInteger.valueOf(Integer.parseInt(exceptionPriorityStr));
        }catch(NumberFormatException nfe){
            nfeMessage = nfe.getMessage();            
        }finally{
            if (nfeMessage != "" || exceptionPriority.intValue() < 0){
                //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                //session.clear();
                session.clear(session.toString().trim());
                //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation.
                addError(CustomMessageRepositoryMDC.NI0007_5_1_excpPriorityInvalid(
                        algCodeStr, 
                        exceptionCode.trim(), 
                        exceptionPriorityStr.trim(),
                        exceptionCodeFeatureConfigurationType.getId().getIdValue().trim()));
            }
        }

        return exceptionPriority;
    }

    /**
     * 
     * @param inboundCharType - The 'Inbound' characteristic type. Will be passed to deleteCaseChar() method
     * @param inboundCharSeq - The 'Inbound' characteristic sequence
     * @param inboundCharValue - The 'Inbound' characteristic value
     * @param permanentCharType - The 'Permanent' Characteristic Type
     * @param permanentCharSeq - The 'Permanent' Characteristic Sequence
     * @param permanentCharValue - The 'Permanent' characteristic value. Will determine if action is add or update.
     */
    // TIR3-TIR4. Start Delete
    /*
    private void createOrUpdatePermChar(String inboundCharValue, CharacteristicType permanentCharType, 
            BigInteger permanentCharSeq, String permanentCharValue) {

        if (permanentCharValue == ""){
            // Create the Permanent characteristic
            permanentCharSeq = createCaseChar(permanentCharType, inboundCharValue);
            // Create case log for added characteristic
            createCaseLog(permanentCharType, permanentCharSeq, inboundCharValue, CASE_LOG_ADD); 
        }else{
            if (!permanentCharValue.equals(inboundCharValue)){
                // Update the Permanent characteristic
                updateCaseChar(permanentCharType, permanentCharSeq, inboundCharValue);
                // Create case log for updated characteristic
                createCaseLog(permanentCharType, permanentCharSeq, inboundCharValue, CASE_LOG_UPDATE);
            }                 
        }               

    }
     */
    // TIR3-TIR4. End Delete

    /**
     * 
     * @param permanentCharValue - The 'Permanent' characteristic value
     * @param mainCharType - The 'Main' characteristic type 
     * @param mainCharSeq - The 'Main' characteristic sequence
     * @param mainCharValue - The 'Main' characteristic value. Will determine if action is add or update.
     */
    // TIR3-TIR4. Start Delete
    /*
    private void createOrUpdateMainChar(CharacteristicType mainCharType, BigInteger mainCharSeq, 
            String mainCharValue, String origMainCharValue) {

        BigInteger newCharSeq = BigInteger.ZERO;

        if (mainCharSeq.intValue() == 0){
            // Create the Main characteristic
            newCharSeq = createCaseChar(mainCharType, mainCharValue);
            // Create case log for added characteristic
            createCaseLog(mainCharType, newCharSeq, mainCharValue, CASE_LOG_ADD); 
        }else{
            if (!mainCharValue.equals(origMainCharValue)){
                // Update the Main characteristic
                updateCaseChar(mainCharType, mainCharSeq, mainCharValue);
                // Create case log for updated characteristic
                createCaseLog(mainCharType, mainCharSeq, mainCharValue, CASE_LOG_UPDATE);
            }             
        }        
    }
     */
    // TIR3-TIR4. End Delete

    /**
     * 
     * @param charType - The type of characteristic to create
     * @param charValue - The value of the characteristic that will be created
     * @return Returns the sequence number of the newly created characteristic
     */
    // TIR3-TIR4. Start Delete
    /*
    private BigInteger createCaseChar(CharacteristicType charType, String charValue){                  

        CaseCharacteristic_DTO caseCharDTO = new CaseCharacteristic_DTO();
        caseCharDTO.setId(new CaseCharacteristic_Id(charType, toDoCase, null));

        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            caseCharDTO.setAdhocCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isPredefinedValue()){
            caseCharDTO.setCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            caseCharDTO.setCharacteristicValueForeignKey1(charValue.trim());
        }

        CaseCharacteristic caseChar = caseCharDTO.newEntity();
        return caseChar.fetchIdSequence();

    }
     */
    // TIR3-TIR4. End Delete

    /**
     * 
     * @param charType - Characteristic type of characteristic that will be updated
     * @param seqNum - Sequence of the characteristic that will be udpated
     * @param newCharValue - New Characteristic value
     */
    // TIR3-TIR4. Start Delete
    /*
    private void updateCaseChar(CharacteristicType charType, BigInteger seqNum, String newCharValue) {

        CaseCharacteristic_Id charChar_Id = new CaseCharacteristic_Id(charType, toDoCase, seqNum);
        CaseCharacteristic_DTO caseCharDTO = charChar_Id.getEntity().getDTO();

        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            caseCharDTO.setAdhocCharacteristicValue(newCharValue.trim());
        }
        if (charType.getCharacteristicType().isPredefinedValue()){
            caseCharDTO.setCharacteristicValue(newCharValue.trim());
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            caseCharDTO.setCharacteristicValueForeignKey1(newCharValue.trim());
        }

        charChar_Id.getEntity().setDTO(caseCharDTO);

    }
     */
    // TIR3-TIR4. End Delete

    /**
     * 
     * @param charType - Characteristic type of characteristic that will be deleted
     * @param seqNum - Sequence of the characteristic that will be deleted
     */
    // TIR3-TIR4. Start Delete
    /*
    private void deleteCaseChar(CharacteristicType charType, BigInteger seqNum) {

        CaseCharacteristic_Id charChar_Id = new CaseCharacteristic_Id(charType, toDoCase, seqNum);
        toDoCase.getCharacteristics().remove(charChar_Id);

    }
     */
    // TIR3-TIR4. End Delete

    /**
     * 
     * @param charType - Characteristic Type of the added/updated/deleted characteristic
     * @param seqNum - Sequence number of the added/updated/deleted characteristic
     * @param charValue - Value of the added/updated/deleted characteristic
     * @param action - Will determine the correct Message to use
     */
    // TIR3-TIR4. Start Delete
    /*
    private void createCaseLog(CharacteristicType charType, BigInteger seqNum, String charValue, String action){

        // Create Case Log Entry
        CaseLog_DTO caseLogDto = new CaseLog_DTO();
        caseLogDto.setCaseStatusId(toDoCase.getCaseStatus().getId());
        caseLogDto.setCharacteristicTypeId(charType.getId());
        if (charType.getCharacteristicType().isAdhocValue()
                || charType.getCharacteristicType().isFileLocationValue()){
            caseLogDto.setAdhocCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isPredefinedValue()){
            caseLogDto.setCharacteristicValue(charValue.trim());
        }
        if (charType.getCharacteristicType().isForeignKeyValue()){
            caseLogDto.setCharacteristicValueForeignKey1(charValue.trim());
        }
        // Set Message Id depending on Action
        if (action == CASE_LOG_ADD){
            caseLogDto.setMessageId(new Message_Id(MESSAGE_CAT, CASE_CHAR_ADDED_MSG_NUM));
        }
        if (action == CASE_LOG_UPDATE){
            caseLogDto.setMessageId(new Message_Id(MESSAGE_CAT, CASE_CHAR_UPDATED_MSG_NUM));
        }
        if (action == CASE_LOG_DELETE){
            caseLogDto.setMessageId(new Message_Id(MESSAGE_CAT, CASE_CHAR_DELETED_MSG_NUM));
        }        
        caseLogDto.setLogType(CaseLogTypeLookup.constants.SYSTEM);

        // Get newly created Case Log
        CaseLog caseLog = toDoCase.getLogs().add(caseLogDto, null);                    

        // Add message parameter for characteristic type
        CaseLogMessageParameter_DTO caseLogMsgParmDto = new CaseLogMessageParameter_DTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.ONE));
        caseLogMsgParmDto.setMessageParameter(charType.getId().getIdValue().trim());        
        caseLog.getMessageParameters().add(caseLogMsgParmDto, BigInteger.ONE);

        // Add message parameter for characteristic sequence number
        caseLogMsgParmDto = new CaseLogMessageParameter_DTO();
        caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, BigInteger.valueOf(2)));
        caseLogMsgParmDto.setMessageParameter(seqNum.toString().trim());        
        caseLog.getMessageParameters().add(caseLogMsgParmDto, BigInteger.valueOf(2));

        // Add message parameter for characteristic value
        int counter = 0;
        String[] charVal = new String[]{"","","","","","",""};        

        for(int i = 0; i <= charValue.length() && counter < 7; i = i + 30){            
            if( i + 30 > charValue.length()){
                charVal[counter] = (charValue.substring(i, charValue.length()));
            }else{
                charVal[counter] = (charValue.substring(i, i + 30));                
                counter++;
            }
        }

        BigInteger charValParmSeq = BigInteger.valueOf(3);
        for (int i = 0; i < 7; i++) {            
            if (StringUtilities.notEmptyOrBlank(charVal[i])) {
                caseLogMsgParmDto = new CaseLogMessageParameter_DTO();
                caseLogMsgParmDto.setId(new CaseLogMessageParameter_Id(caseLog, charValParmSeq));
                caseLogMsgParmDto.setMessageParameter(charVal[i].trim());        
                caseLog.getMessageParameters().add(caseLogMsgParmDto, charValParmSeq);
            }
            charValParmSeq = charValParmSeq.add(BigInteger.ONE);
        }

    }
     */
    // TIR3-TIR4. End Delete

    @Override
    protected void extraSoftParameterValidations(boolean arg0) {

        // Get algorithm code
        algCodeStr = this.getAlgorithm().getId().getIdValue().trim();

        // Characteristic Type for Inbound Corrected Exception Code
        inboundCorrectedExceptionCodeCharType = this.getCharacteristicTypeForInboundCorrectedExceptionCode();
        validateCaseChar(inboundCorrectedExceptionCodeCharType, "Characteristic Type for Inbound Corrected Exception Code");      

        // Characteristic Type for Inbound Uncorrected Exception Code
        inboundUncorrectedExceptionCodeCharType = this.getCharacteristicTypeForInboundUncorrectedExceptionCode();
        validateCaseChar(inboundUncorrectedExceptionCodeCharType, "Characteristic Type for Inbound Uncorrected Exception Code");       

        // Characteristic Type for Corrected Exception Code
        permanentCorrectedExceptionCodeCharType = this.getCharacteristicTypeForCorrectedExceptionCode();
        validateCaseChar(permanentCorrectedExceptionCodeCharType, "Characteristic Type for Corrected Exception Code");        

        // Characteristic Type for Uncorrected Exception Code
        permanentUncorrectedExceptionCodeCharType = this.getCharacteristicTypeForUncorrectedExceptionCode();
        validateCaseChar(permanentUncorrectedExceptionCodeCharType, "Characteristic Type for Uncorrected Exception Code");        

        // Characteristic Type for Main Exception Code
        mainExceptionCodeCharType = this.getCharacteristicTypeForMainExceptionCode();
        validateCaseChar(mainExceptionCodeCharType, "Characteristic Type for Main Exception Code");        

        // Exception Code Feature Configuration Type
        exceptionCodeFeatureConfigurationType = this.getExceptionCodeFeatureConfigurationType();

        // Exception Priority Feature Configuration Option Type
        exceptionPriorityFeatureConfigurationOptionType = this.getExceptionPriorityFeatureConfigurationOptionType();

        // Exception Priority Feature Configuration Option Type must be valid a valid option type for Exception Code Feature Configuration Type
        String extSysTypStr = exceptionCodeFeatureConfigurationType.getFeatureType().getLookupValue().fetchIdFieldValue().trim();
        extSysTypStr = extSysTypStr.concat(_OPT_TYP_FLG);
        LookupField_Id lookupField_Id = new LookupField_Id(extSysTypStr);
        LookupValue_Id lookupValue_Id = new LookupValue_Id(lookupField_Id, exceptionPriorityFeatureConfigurationOptionType.trim());
        if (isNull(lookupValue_Id.getEntity())){
            addError(CustomMessageRepositoryMDC.NI0007_5_1_optTypeInvForWFM(
                    algCodeStr, 
                    "Exception Priority Feature Configuration Option Type", 
                    exceptionPriorityFeatureConfigurationOptionType.trim(), 
                    exceptionCodeFeatureConfigurationType.getId().getIdValue().trim()));
        }

        nextStatus = this.getNextStatus();
    }

    private void validateCaseChar(CharacteristicType charType, String parmDescr) {
        CharacteristicEntity_Id charEntity_Id = new CharacteristicEntity_Id(charType, CharacteristicEntityLookup.constants.CASE);
        if (isNull(charEntity_Id.getEntity())){
            addError(CustomMessageRepositoryMDC.NI0007_5_1_charTypeInvForEntity(
                    algCodeStr, 
                    parmDescr, 
                    charType.getId().getIdValue().trim(), 
                    CharacteristicEntityLookup.constants.CASE.getLookupValue().fetchLanguageDescription().trim()));
        }        
    }    

}
