/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * B-22188. To retrieve customers that have housing authority credit 
 * over $75. Once identified, we will need to generate the AP refund 
 * request for these accounts to send out a refund check. Additionally we 
 * need to add a customer contact that is contact class 
 * (community services) and contact type (general) including account number
 * refund was issued on.

 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2022-09-13   EQuint        	B-22188 Initial Version.    
 * 2023-08-18   EQuint			B-29435 Transfer the appropriate HUD 
 * 								credit balance from overpayment SA to the 
 * 								gas SA prior to creating refund adjustment                          
 **************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.PaymentStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.AdjustmentCharacteristic_DTO;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType_Id;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;

/**
 * @author OGC02353
 *
@BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      toDoCreation = @ToDoCreation (drillKeyEntity = account,
 *            sortKeys = { "ACCT_ID"
 *                  , "SA_ID"
 *                  , "CREDIT_AMT"}),
 *      softParameters = { @BatchJobSoftParameter (name = CREDIT_THRESHOLD, required = true, type = decimal)
 *            , @BatchJobSoftParameter (name = NO_OF_MONTHS_THRESHOLD, required = true, type = integer)
 *            , @BatchJobSoftParameter (entityName = adjustmentType, name = REFUND_ADJUSTMENT_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = adjustmentType, name = XFER_ADJUSTMENT_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CUSTOMER_CONTACT_CLASS, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CUSTOMER_CONTACT_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = HOUSING_TENDER_SOURCES, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = customerClass, name = CUSTOMER_CLASS, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = SERVICE_TYPES, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = AP_ADJUSTMENT_CHAR_TYPE, required = true, type = entity)})
 */
public class CmHousingAuthorityAPRefundBatch extends
		CmHousingAuthorityAPRefundBatch_Gen {
	
	private static final String COMMA_REGEX = "\\s*,\\s*";
	private static final String CREDIT_AMOUNT_FIELD = "CREDIT_AMT";
	private static final String CREDIT_THRESHOLD_DESC = "Credit Threshold";
	private static final String NO_OF_MONTHS_DESC = "Number of Months";

	@Override
	public void validateSoftParameters(boolean isNewRun) {
		BigDecimal creditThreshold  = getParameters().getCREDIT_THRESHOLD();
		if (creditThreshold.intValue() <= 0) {
			// add error "Batch parameter %1 (%2) must be greater than zero."
			addError(CustomMessageRepository.B22188_batchParmGreaterThanZero(CREDIT_THRESHOLD_DESC, creditThreshold.toString()));
		}
		
		BigInteger noOfMonthsThreshold =  getParameters().getNO_OF_MONTHS_THRESHOLD();
		if (noOfMonthsThreshold.intValue() <= 0) {
			// add error "Batch parameter %1 (%2) must be greater than zero."
			addError(CustomMessageRepository.B22188_batchParmGreaterThanZero(NO_OF_MONTHS_DESC, noOfMonthsThreshold.toString()));
		}

		CustomerContactClass ccClass = getParameters().getCUSTOMER_CONTACT_CLASS();
		String ccType = getParameters().getCUSTOMER_CONTACT_TYPE();
		if (isNull(new CustomerContactType_Id(ccClass, ccType).getEntity())) {
			// add error "Batch parameters Customer Contact Class (%1) and Customer Contact Type (%2) are not a valid combination."
			addError(CustomMessageRepository.B22188_ccInvalid(ccClass.getId().getTrimmedValue(), ccType));
		}
		
		String[] housingTenderSources = getParameters().getHOUSING_TENDER_SOURCES().trim().split(COMMA_REGEX);
		for (String tenderSource : housingTenderSources) {
			if (isNull(new TenderSource_Id(tenderSource).getEntity())) {
				// add error "Batch parameter Housing Tender Sources contains invalid tender source code (%1)."
				addError(CustomMessageRepository.B22188_tenderSourceInvalid(tenderSource));
				break;
			}
		}
		
		String[] serviceTypes = getParameters().getSERVICE_TYPES().trim().split(COMMA_REGEX);
		for (String svcType : serviceTypes) {
			if (isNull(new ServiceType_Id(svcType).getEntity())) {
				// add error "Batch parameter Service Types contains invalid service type code (%1)."
				addError(CustomMessageRepository.B22188_serviceTypeInvalid(svcType));
				break;
			}
		}
		
		CharacteristicType charType = getParameters().getAP_ADJUSTMENT_CHAR_TYPE();
		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);
		if (isNull(charEntityId.getEntity())) {
			// add error "Batch parameter AP Adjustment (%1) Characteristic Type is not valid for %2 entity."
			addError(CustomMessageRepository.B22188_charTypeEntityInvalid(charType.getId().getTrimmedValue(), CharacteristicEntityLookup.constants.CUSTOMER_CONTACT.getLookupValue().getEffectiveDescription()));
		}
		
	}

	@Override
	public JobWork getJobWork() {
		
		BigInteger noOfMonthsThreshold =  getParameters().getNO_OF_MONTHS_THRESHOLD();
		String[] housingTenderSources = getParameters().getHOUSING_TENDER_SOURCES().trim().split(COMMA_REGEX);
		CustomerClass custClass = getParameters().getCUSTOMER_CLASS();
		String[] serviceTypes = getParameters().getSERVICE_TYPES().trim().split(COMMA_REGEX);
		Date fromDate = getProcessDateTime().getDate().addMonths(noOfMonthsThreshold.negate().intValue());
		// start change - B-29435 - equint - 08-18-2023
		// AdjustmentType adjType = getParameters().getADJUSTMENT_TYPE();
		
		AdjustmentType refundAdjType = getParameters().getREFUND_ADJUSTMENT_TYPE();
		// end change - B-29435 - equint - 08-18-2023
		
		List<ThreadWorkUnit> workUnits = new ArrayList<>();
		
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT  DISTINCT ACCT.ACCT_ID ");
		stringBuilder.append("  , SA1.SA_ID ");
		stringBuilder.append("  , LISTAGG(A.SA_ID, ',') WITHIN GROUP(ORDER by A.SA_ID) HUD_SA_IDS ");
		stringBuilder.append("FROM ( ");
		stringBuilder.append("  SELECT DISTINCT C.SA_ID "); //HUD SA cur bal must be below threshold
		stringBuilder.append("  FROM ( ");
		stringBuilder.append("	  SELECT FT.SA_ID "); //get cur bal of HUD SA
		stringBuilder.append("      , SUM(FT.CUR_AMT) CUR_BAL");
		stringBuilder.append("    FROM ( ");
		stringBuilder.append("	    SELECT DISTINCT PS.SA_ID "); // get SA with HUD payments
		stringBuilder.append("      FROM CI_PAY_EVENT PE ");
		stringBuilder.append("        , CI_PAY_TNDR PT ");
		stringBuilder.append("        , CI_TNDR_CTL TC ");
		stringBuilder.append("        , CI_PAY P ");
		stringBuilder.append("        , CI_PAY_SEG PS ");
		stringBuilder.append("        , CI_SA SA ");
		stringBuilder.append("      WHERE PE.PAY_DT >= :fromDate ");
		stringBuilder.append("      AND PE.PAY_DT <= :toDate ");
		stringBuilder.append("      AND PE.PAY_EVENT_ID = PT.PAY_EVENT_ID ");
		stringBuilder.append("      AND PT.TNDR_CTL_ID = TC.TNDR_CTL_ID ");
		stringBuilder.append("      AND TC.TNDR_SOURCE_CD IN ( ");
		
		for (int i = 0; i < housingTenderSources.length; i++) {
			stringBuilder.append(":tc" + i);
			if (i + 1 < housingTenderSources.length) {
				stringBuilder.append(", ");
			}
		}

		stringBuilder.append("      ) AND P.PAY_EVENT_ID = PE.PAY_EVENT_ID ");
		stringBuilder.append("      AND PS.PAY_ID = P.PAY_ID ");
		stringBuilder.append("      AND P.PAY_STATUS_FLG =:frozen ");
		stringBuilder.append("      AND SA.SA_ID = PS.SA_ID ");
		stringBuilder.append("      AND SA.SA_STATUS_FLG BETWEEN :active AND :reactivated ");
		// start add - B-29435 - equint - 08-18-2023
		stringBuilder.append("      ORDER BY SA.START_DT ASC ");
		// end add - B-29435 - equint - 08-18-2023
		stringBuilder.append("	  ) B ");
		stringBuilder.append("	  , CI_FT FT ");
		stringBuilder.append("	  WHERE B.SA_ID = FT.SA_ID ");
		stringBuilder.append("	  AND FT.FREEZE_SW = :true ");
		stringBuilder.append("	  AND FT.REDUNDANT_SW = :false ");
		stringBuilder.append("	  GROUP BY FT.SA_ID ");
		stringBuilder.append("  ) C ");
		stringBuilder.append("  WHERE C.CUR_BAL < 0 ");
		stringBuilder.append(") A ");
		stringBuilder.append(", CI_SA SA ");
		stringBuilder.append(", CI_SA SA1 ");
		stringBuilder.append(", CI_SA_TYPE SAT ");
		stringBuilder.append(", CI_ACCT ACCT ");
		stringBuilder.append(", ( ");
		stringBuilder.append("    SELECT SAT.SA_TYPE_CD "); // SA types that are valid to contain special HUD A/P adjustment
		stringBuilder.append("      , SAT.CIS_DIVISION ");
		stringBuilder.append("    FROM CI_SA_TYPE SAT ");
		stringBuilder.append("    	, CI_SAT_ADJ_PROF SAP ");
		stringBuilder.append("      , CI_ADJ_TYP_PROF ATP  ");
		stringBuilder.append("      , CI_ADJT_ADJTPRF AA ");
		stringBuilder.append("    WHERE SAT.SA_TYPE_CD = SAP.SA_TYPE_CD  ");
		stringBuilder.append("    AND SAT.CIS_DIVISION = SAP.CIS_DIVISION ");
		stringBuilder.append("    AND SAP.ADJ_TYPE_PROF_CD = ATP.ADJ_TYPE_PROF_CD ");
		stringBuilder.append("    AND ATP.ADJ_TYPE_PROF_CD = AA.ADJ_TYPE_PROF_CD ");
		stringBuilder.append("    AND AA.ADJ_TYPE_CD = :adjType ");
		stringBuilder.append("  ) d ");
		stringBuilder.append("WHERE SA.SA_ID = A.SA_ID ");
		stringBuilder.append("AND ACCT.ACCT_ID = SA.ACCT_ID ");
		stringBuilder.append("AND ACCT.CUST_CL_CD = :custClassCd ");
		stringBuilder.append("AND SA1.ACCT_ID = ACCT.ACCT_ID ");
		stringBuilder.append("AND SA1.SA_STATUS_FLG BETWEEN :active AND :reactivated ");
		stringBuilder.append("AND SA1.SA_TYPE_CD = SAT.SA_TYPE_CD ");
		stringBuilder.append("AND SA1.CIS_DIVISION = SAT.CIS_DIVISION ");
		stringBuilder.append("AND SAT.SVC_TYPE_CD IN ( ");
		
		for (int i = 0; i < serviceTypes.length; i++) {
			stringBuilder.append(":st" + i);
			if (i + 1 < serviceTypes.length) {
				stringBuilder.append(", ");
			}
		}
		
		stringBuilder.append("	) ");
		stringBuilder.append("AND SAT.cis_division = d.cis_division ");
		stringBuilder.append("and SAT.sa_type_cd = d.sa_type_cd ");
		stringBuilder.append("GROUP BY ACCT.ACCT_ID, SA1.SA_ID ");

		PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), "getJobWork");
		preparedStatement.bindDate("fromDate", fromDate);
		preparedStatement.bindDate("toDate", getProcessDateTime().getDate());
		
		for (int i = 0; i < housingTenderSources.length; i++) {
			preparedStatement.bindId("tc" + i, new TenderSource_Id(housingTenderSources[i]));
		}

		preparedStatement.bindId("custClassCd", custClass.getId());
		
		for (int i = 0; i < serviceTypes.length; i++) {
			preparedStatement.bindId("st" + i, new ServiceType_Id(serviceTypes[i]));
		}
		preparedStatement.bindId("adjType", refundAdjType.getId());
		preparedStatement.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
		preparedStatement.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
		preparedStatement.bindLookup("frozen", PaymentStatusLookup.constants.FROZEN);
		preparedStatement.bindBoolean("true", Bool.TRUE);
		preparedStatement.bindBoolean("false", Bool.FALSE);

		preparedStatement.setAutoclose(false);
		preparedStatement.execute();

		QueryIterator<SQLResultRow> row = preparedStatement.iterate();
		while (row.hasNext()){
			SQLResultRow rec = row.next();
			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			
			workUnit.setPrimaryId(rec.getId("ACCT_ID", Account.class));			
			workUnit.addSupplementalData("SA_ID", rec.getId("SA_ID", ServiceAgreement.class));			
			workUnit.addSupplementalData("HUD_SA_IDS", rec.getString("HUD_SA_IDS"));
			workUnits.add(workUnit);
		}
		row.close();
		preparedStatement.close();

		return createJobWorkForThreadWorkUnitList(workUnits);
	}

	public Class<CmHousingAuthorityAPRefundBatchWorker> getThreadWorkerClass() {
		return CmHousingAuthorityAPRefundBatchWorker.class;
	}

	public static class CmHousingAuthorityAPRefundBatchWorker extends
			CmHousingAuthorityAPRefundBatchWorker_Gen {
		
		private class FtBalance {
			private FinancialTransaction ft;
			private Money balance;
			
			public FtBalance(FinancialTransaction ft, Money balance) {
				this.ft = ft;
				this.balance = balance;
			}
			public FinancialTransaction getFt() {
				return ft;
			}
			public void setFt(FinancialTransaction ft) {
				this.ft = ft;
			}
			public Money getBalance() {
				return balance;
			}
			public void setBalance(Money balance) {
				this.balance = balance;
			}
			
		}
		
		// start change - B-29435 - equint - 08-18-2023
		// private AdjustmentType adjustmentType;
		private AdjustmentType refundAdjType;
		private AdjustmentType xferAdjType;
		// end change - B-29435 - equint - 08-18-2023
		private CustomerContactType ccType;
		private CharacteristicType adjCharType;
		private ServiceAgreement_Id saId;
		private Account_Id acctId;
		private Money hudCreditBalance;
		private BigInteger noOfMonthsThreshold;
		private BigDecimal creditThreshold;
		private Date fromDate;
		private String[] housingTenderSources;

		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
			
			// start change - B-29435 - equint - 08-18-2023
			// adjustmentType = getParameters().getADJUSTMENT_TYPE();
			
			refundAdjType = getParameters().getREFUND_ADJUSTMENT_TYPE();
			xferAdjType = getParameters().getXFER_ADJUSTMENT_TYPE();
			// end change - B-29435 - equint - 08-18-2023
			ccType = new CustomerContactType_Id(getParameters().getCUSTOMER_CONTACT_CLASS(), getParameters().getCUSTOMER_CONTACT_TYPE()).getEntity();
			adjCharType = getParameters().getAP_ADJUSTMENT_CHAR_TYPE();
			noOfMonthsThreshold =  getParameters().getNO_OF_MONTHS_THRESHOLD();
			creditThreshold  = getParameters().getCREDIT_THRESHOLD();
			housingTenderSources = getParameters().getHOUSING_TENDER_SOURCES().trim().split(COMMA_REGEX);
						
			fromDate = getProcessDateTime().getDate().addMonths(noOfMonthsThreshold.negate().intValue());
			
		}

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		@Override
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			WorkUnitResult result = new WorkUnitResult(true);
			result.setUnitsProcessed(0);
			
			acctId = (Account_Id) unit.getPrimaryId();
			saId = (ServiceAgreement_Id) unit.getSupplementallData("SA_ID");
			// start add - B-29435 - equint - 08-18-2023
			ServiceAgreement sa = saId.getEntity();
			// end add - B-29435 - equint - 08-18-2023
			
			// list of SAs of account that has candidate HUD payments for refund
			String hudSaIds = (String) unit.getSupplementallData("HUD_SA_IDS");
			String[] hudSaIdsArr = hudSaIds.split(",");
			
			// initialize accounts account's HUD total balance to zero
			hudCreditBalance =  Money.ZERO;
			
			// start add - B-29435 - equint - 08-18-2023
			// initialize the queue that will hold HUD SAs credit balances
			LinkedList<FtBalance> hudCreditQueue =  new LinkedList<FtBalance>();
			List<FtBalance> hudRefundList = new ArrayList<FtBalance>();
			// end add - B-29435 - equint - 08-18-2023
			
			// for each HUD SAs
			for (String hudSaId: hudSaIdsArr) {
				ServiceAgreement hudSa = new ServiceAgreement_Id(hudSaId).getEntity();
				
				// get the HUD SAs current balance as of the date threshold
				// if HUD SA start date is after the calculated start date range, then use it as the start date of threshold
				Date balDate = (hudSa.getStartDate().isAfter(fromDate)) ? hudSa.getStartDate() : fromDate;
				Money hudSaRunningBal = hudSa.getCurrentBalance(balDate, balDate, Bool.TRUE);
			
				// start delete - B-29435 - equint - 08-18-2023
				// initialize the queue that will hold HUD SAs credit balances
				// LinkedList<FtBalance> hudCreditQueue =  new LinkedList<FtBalance>();
				// end delete - B-29435 - equint - 08-18-2023
				
				// get the HUD SAs FT within the date threshold
				PreparedStatement preparedStatement = getSAFtWithinDates(hudSa.getId(), fromDate, getProcessDateTime().getDate());
				
				QueryIterator<SQLResultRow> iterator = preparedStatement.iterate();
				while (iterator.hasNext()){
					SQLResultRow row = iterator.next();
					
					FinancialTransaction ft = row.getEntity("FT_ID", FinancialTransaction.class);
					
					// if HUD credit queue is empty and HUD running balance is positive, then apply the running balance to the credits in queue
					if (!hudCreditQueue.isEmpty() && hudSaRunningBal.isPositive()) {
						hudSaRunningBal = applyBalance(hudCreditQueue, hudSaRunningBal);
					}
						
					// if FT balance is negative, then add at it in the credit queue
					if (ft.getCurrentAmount().isNegative()) {
						hudCreditQueue.add(new FtBalance(ft, ft.getCurrentAmount()));
					} else {
						// else if balance is positive, then apply it to the credits in queue
						hudSaRunningBal = applyBalance(hudCreditQueue, ft.getCurrentAmount());
					}
					
				}
				iterator.close();
				preparedStatement.close();
				
				// if the running balance is still positive after applying all the FT balances, apply the remaining running balance to the credits in the queue
				if (hudSaRunningBal.isPositive()) {
					hudSaRunningBal = applyBalance(hudCreditQueue, hudSaRunningBal);
				}

				// start delete - B-29435 - equint - 08-18-2023
				// // for each credit in the queue, if the FT is related to HUD, then add it to the HUD total credit balance
				// for (FtBalance ftBalance : hudCreditQueue) {
				// 	if (notNull(ftBalance.getFt()) && isHudFt(ftBalance.getFt()).isTrue()) {
				// 		hudCreditBalance = hudCreditBalance.add(ftBalance.getBalance());
				// 	}
				// }
				// end delete - B-29435 - equint - 08-18-2023
			}
			
			// start add - B-29435 - equint - 08-18-2023
			// for each credit in the queue, if the FT is related to HUD, then add it to the HUD total credit balance
			for (FtBalance ftBalance : hudCreditQueue) {
				if (notNull(ftBalance.getFt()) && isHudFt(ftBalance.getFt()).isTrue()) {
					hudCreditBalance = hudCreditBalance.add(ftBalance.getBalance());
					hudRefundList.add(ftBalance);
				}
			}
			// end add - B-29435 - equint - 08-18-2023
			
			// if HUD credit balance is within the threshold, then do refund
			if (hudCreditBalance.getAmount().abs().compareTo(creditThreshold) > 0) {
				// start delete - B-29435 - equint - 08-18-2023
				// ServiceAgreement sa = saId.getEntity();
				// end delete - B-29435 - equint - 08-18-2023
				Account acct = acctId.getEntity();
				
				try {
					BigDecimal refundAmount = hudCreditBalance.getAmount().abs().subtract(creditThreshold);
					
					Adjustment adj = createApAdjustment(sa, refundAdjType, refundAmount);
					
					// start add - B-29435 - equint - 08-18-2023
					BigDecimal remainingRefundAmount = new BigDecimal(refundAmount.longValue());
					for (FtBalance ftBalance : hudRefundList) {
						if (remainingRefundAmount.compareTo(BigDecimal.ZERO) > 0) {
							BigDecimal transferAmount =  ftBalance.getBalance().getAmount().abs();
							// if remaining refund amount is less than the transfer amount, transfer only the remaining amount
							if (remainingRefundAmount.compareTo(transferAmount) < 0) {
								transferAmount = remainingRefundAmount;
							} 
							createXferAdjustment(ftBalance.getFt().getServiceAgreement(), sa, xferAdjType, transferAmount.negate(), adj.getId());
							remainingRefundAmount = remainingRefundAmount.subtract(transferAmount);
						}
					}
					// end add - B-29435 - equint - 08-18-2023
					
					createCustomerContact(acct, adj.getId());
					result.setUnitsProcessed(1);
				} catch (ApplicationError e) {
					addError(e.getServerMessage());
					result.setUnitsProcessed(1);
					result.setUnitsInError(1);
				}
			}
			
			return result;
		}
		
		/**
		 * Given a HUD credit queue (FIFO), the 2nd parameter, balance, will be applied to it.
		 * Once a balance in the queue is consumed, it will be popped from the queue
		 * @param hudCreditQueue
		 * @param balance
		 * @return
		 */
		private Money applyBalance(LinkedList<FtBalance> hudCreditQueue, Money balance) {
			if (!hudCreditQueue.isEmpty()) {
				Money appliedBal = hudCreditQueue.getFirst().getBalance().add(balance);
				if (appliedBal.isGreaterThanOrEqual(Money.ZERO)) {
					hudCreditQueue.pop();
					return applyBalance(hudCreditQueue, appliedBal);
				} else {
					hudCreditQueue.getFirst().setBalance(appliedBal);
					return appliedBal;
				}
			} else {
				return balance;
			}
		}
		
		/**
		 * Check if the provided FT is related to HUD
		 * @param ft
		 * @return true if HUD else false
		 */
		private Bool isHudFt(FinancialTransaction ft) {
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT 'x' ");
			stringBuilder.append("FROM CI_FT FT ");
			stringBuilder.append("  , CI_PAY_SEG PS ");
			stringBuilder.append("  , CI_PAY P ");
			stringBuilder.append("  , CI_PAY_EVENT PE ");
			stringBuilder.append("  , CI_PAY_TNDR PT ");
			stringBuilder.append("  , CI_TNDR_CTL TC ");
			stringBuilder.append("WHERE FT.FT_ID = :ftId ");
			stringBuilder.append("AND FT.SIBLING_ID = PS.PAY_SEG_ID ");
			stringBuilder.append("AND PS.PAY_ID = P.PAY_ID ");
			stringBuilder.append("AND P.PAY_EVENT_ID = PE.PAY_EVENT_ID ");
			stringBuilder.append("AND PE.PAY_EVENT_ID = PT.PAY_EVENT_ID ");
			stringBuilder.append("AND PT.TNDR_CTL_ID = TC.TNDR_CTL_ID ");
			stringBuilder.append("AND TC.TNDR_SOURCE_CD IN ( ");
			
			for (int i = 0; i < housingTenderSources.length; i++) {
				stringBuilder.append(":tc" + i);
				if (i + 1 < housingTenderSources.length) {
					stringBuilder.append(", ");
				}
			}

			stringBuilder.append(") ");
			
			PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), "isHudFt");
			preparedStatement.bindId("ftId", ft.getId());
			
			for (int i = 0; i < housingTenderSources.length; i++) {
				preparedStatement.bindId("tc" + i, new TenderSource_Id(housingTenderSources[i]));
			}

			preparedStatement.setAutoclose(false);
			preparedStatement.execute();
			
			SQLResultRow row = preparedStatement.firstRow();
			preparedStatement.close();
			
			return Bool.valueOf(notNull(row));
		}
		
		/**
		 * Get SAs FT within the provided date range
		 * @param saId
		 * @param fromDate
		 * @param toDate
		 * @return
		 */
		private PreparedStatement getSAFtWithinDates(ServiceAgreement_Id saId, Date fromDate, Date toDate) {
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT FT.* ");
			stringBuilder.append("FROM CI_FT FT ");
			stringBuilder.append("WHERE FT.SA_ID = :saId ");
			stringBuilder.append("AND FT.ARS_DT >= :fromDate ");
			stringBuilder.append("AND FT.ARS_DT <= :toDate ");
			stringBuilder.append("AND FT.FREEZE_SW = :true ");
			stringBuilder.append("AND FT.REDUNDANT_SW = :false ");
			stringBuilder.append("AND FT.NOT_IN_ARS_SW = :false ");
			stringBuilder.append("ORDER BY FT.ARS_DT ASC ");
			
			PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), "get HUD SA FTs");
			preparedStatement.bindId("saId", saId);
			preparedStatement.bindDate("fromDate", fromDate);
			preparedStatement.bindDate("toDate", toDate);
			
			preparedStatement.bindBoolean("true", Bool.TRUE);
			preparedStatement.bindBoolean("false", Bool.FALSE);

			preparedStatement.setAutoclose(false);
			preparedStatement.execute();
			
			return preparedStatement;
		}
		
		/**
		 * Create AP Adjustment for the SA
		 * @param sa
		 * @param adjustmentType
		 * @param amount
		 * @return adjustment
		 */
		private Adjustment createApAdjustment(ServiceAgreement sa, AdjustmentType adjustmentType, BigDecimal amount) {
			CreateFrozenAdjustment createAdjustmentForCurBalTransfer = CreateFrozenAdjustment.Factory.newInstance();
			CreateFrozenAdjustmentData createFrozenAdjustmentData = CreateFrozenAdjustmentData.Factory.newInstance();
			createFrozenAdjustmentData.setServiceAgreement(sa);
			createFrozenAdjustmentData.setAdjustmentType(adjustmentType);
			createFrozenAdjustmentData.setAdjustmentAmount(new Money(amount, sa.fetchCurrency().getId()));
			createFrozenAdjustmentData.setAllowZeroAmount(Bool.FALSE);

			CreateFrozenAdjustmentData newData = createAdjustmentForCurBalTransfer.createFrozenAdjustment(createFrozenAdjustmentData);
			return newData.getAdjustment();
		}
		
		// start add - B-29435 - equint - 08-18-2023	
		/**
		 * Create AP Adjustment for the SA
		 * @param sa
		 * @param adjustmentType
		 * @param amount
		 * @return adjustment
		 */
		private Adjustment createXferAdjustment(ServiceAgreement sa, ServiceAgreement xferSa, AdjustmentType adjustmentType, BigDecimal amount, Adjustment_Id adjId) {
			CreateFrozenAdjustment createAdjustmentForCurBalTransfer = CreateFrozenAdjustment.Factory.newInstance();
			CreateFrozenAdjustmentData createFrozenAdjustmentData = CreateFrozenAdjustmentData.Factory.newInstance();
			createFrozenAdjustmentData.setServiceAgreement(sa);
			createFrozenAdjustmentData.setAdjustmentType(adjustmentType);
			createFrozenAdjustmentData.setAdjustmentAmount(new Money(amount, sa.fetchCurrency().getId()));
			createFrozenAdjustmentData.setAllowZeroAmount(Bool.FALSE);
			createFrozenAdjustmentData.setAdjustmentDate(getProcessDateTime().getDate());
			createFrozenAdjustmentData.setCalculationDate(getProcessDateTime().getDate());
			createFrozenAdjustmentData.setArrearsDate(getProcessDateTime().getDate());
			createFrozenAdjustmentData.setTransferServiceAgreement(xferSa);

			CreateFrozenAdjustmentData newData = createAdjustmentForCurBalTransfer.createFrozenAdjustment(createFrozenAdjustmentData);
			
			Adjustment xferAdj = newData.getAdjustment();
			AdjustmentCharacteristic_DTO adjCharDto = xferAdj.getCharacteristics().newChildDTO();
			if (adjCharType.getCharacteristicType().isForeignKeyValue()) {
				adjCharDto.setCharacteristicValueForeignKey1(adjId.getTrimmedValue());
			} else if (adjCharType.getCharacteristicType().isPredefinedValue()) {
				adjCharDto.setCharacteristicValue(adjId.getTrimmedValue());
			} else {
				adjCharDto.setAdhocCharacteristicValue(adjId.getTrimmedValue());
			}

			xferAdj.getCharacteristics().add(adjCharDto, adjCharType.getId(), BigInteger.ONE);
			
			return newData.getAdjustment();
		}
		// end add - B-29435 - equint - 08-18-2023	
		
		/**
		 * Create Customer contact for the account
		 * @param account
		 * @param adjId
		 * @return Customer Contact
		 */
		private CustomerContact createCustomerContact(Account account, Adjustment_Id adjId) {

			Person_Id perID = account.getMainPerson().getId();
			Premise_Id premID =  account.getMailingPremiseId();

			CustomerContact_DTO contactDTO = new CustomerContact_DTO();
			contactDTO.setCustomerContactTypeId(ccType.getId());
			contactDTO.setPersonId(perID);
			contactDTO.setAccountId(account.getId());
			contactDTO.setContactDateTime(getProcessDateTime());
			contactDTO.setUserId(getActiveContextUser().getId());
			if (premID != null) {
				contactDTO.setPremiseId(premID);
			}
			CustomerContact cc = contactDTO.newEntity();
			CustomerContactCharacteristic_DTO ccCharDto = cc.getCharacteristics().newChildDTO();
			if (adjCharType.getCharacteristicType().isForeignKeyValue()) {
				ccCharDto.setCharacteristicValueForeignKey1(adjId.getTrimmedValue());
			} else if (adjCharType.getCharacteristicType().isPredefinedValue()) {
				ccCharDto.setCharacteristicValue(adjId.getTrimmedValue());
			} else {
				ccCharDto.setAdhocCharacteristicValue(adjId.getTrimmedValue());
			}

			cc.getCharacteristics().add(ccCharDto, adjCharType.getId());
			
			return cc;
		 }

		@Override
		public ToDoProperties createToDoProperties(ThreadWorkUnit arg0) {
			ToDoProperties toDoProperties = new ToDoProperties(acctId);
			toDoProperties.setACCT_ID(acctId.getTrimmedValue());
			toDoProperties.setSA_ID(saId.getTrimmedValue());
			toDoProperties.setCREDIT_AMT(hudCreditBalance.getAmount().toString());
			return toDoProperties;
			
		}

	}

}
