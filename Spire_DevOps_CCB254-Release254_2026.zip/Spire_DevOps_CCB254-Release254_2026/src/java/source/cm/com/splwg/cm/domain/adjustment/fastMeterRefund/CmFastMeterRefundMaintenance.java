/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Fast Meter Refund Entity Page Maintenance
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2019-11-11	RDizon			CCB-007.5. Initial version.
 **************************************************************************/
package com.splwg.cm.domain.adjustment.fastMeterRefund;

/**
  *  
@EntityPageMaintenance (modules={}, entity = cmFastMeterRefund, service = CMFASTMTRREFUND, program = cmFastMeterRefund, secured = false,
 *      body = @DataElement (contents = { @RowField (entity = cmFastMeterRefund, name = cmFastMeterRefund)}),
 *      actions = {"change", "delete", "read", "add"})
 */

public class CmFastMeterRefundMaintenance
    extends CmFastMeterRefundMaintenance_Gen {
   
}
