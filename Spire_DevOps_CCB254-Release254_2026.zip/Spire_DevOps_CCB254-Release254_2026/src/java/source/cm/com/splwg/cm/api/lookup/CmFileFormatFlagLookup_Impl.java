/**************************************************************************
 * Program Name: CmFileFormatFlagLookup_Impl
 * Program Title: CmFileFormatFlagLookup_Impl
 * Author: Ravi
 * Creation Date: 2020-09-18
 * Purpose: 
 * File Format Lookup - Delimited, XML or Fixed Length.
 * 
 **************************************************************************/
/*--------------------------------------------------------------------------
 *-------------------------- Modification HISTORY: -------------------------
 * -------------------------------------------------------------------------
 *  Modification ID:   Author:        Date:          Description:
.* -------------------------------------------------------------------------
 *  CCB017			   Ravi   		  2020-09-18     Initial Version         
 *                                                      
 ***************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author TMG02518
 *
@LookupFieldname (value = CM_FILE_FMT_FLG)
 */
public class CmFileFormatFlagLookup_Impl extends CmFileFormatFlagLookup_Gen {

}
