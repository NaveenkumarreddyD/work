/* **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * This custom batch process will select all accounts in the CM table. 
 * For each account, this batch process will look for SAs with a CIS Division 
 * and SA Type that matches the input parameters. If there is, the SA's 
 * bill segments and adjustments will be canceled, the payments will be 
 * transferred to other SAs within the account, and the SA will be canceled.
 * The corresponding CM table record will be updated to note whether the SA 
 * was canceled or not (not canceled for whatever reason).
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:        	 Reason:
 * YYYY-MM-DD   IN         	 Reason text.
 *
 * 2018-10-02   MPang 		 SA-269362. Initial Version.
 * 2018-11-26   RDizon 		 SA-272952. Updates for v2.6.
 * ************************************************************************/
package com.splwg.cm.domain.batch;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.util.StringTokenizer;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.BillMessageTypeLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.adjustment.common.CancelAdjustment;
import com.splwg.ccb.domain.admin.adjustmentCancelReason.entity.AdjustmentCancelReason;
import com.splwg.ccb.domain.admin.billCancelReason.entity.BillCancelReason;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.paymentCancelReason.entity.PaymentCancelReason;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountMessage_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountMessages;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.payment.common.PaymentTransferProcessor;
import com.splwg.ccb.domain.payment.data.PaymentTransferData;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.ccb.domain.payment.payment.entity.Payment_Id;
import com.splwg.cm.domain.common.customBusinessComponent.CmReinstateServiceAgreementRoutine;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;

/**
 * @author RDizon
 *
@BatchJob (multiThreaded = true, rerunnable = false, modules ={},
 *      softParameters = { @BatchJobSoftParameter (name = CIS_DIVISION, required = true, type = string)
 *      , @BatchJobSoftParameter (name = SA_TYPE_CD, required = true, type = string)
 *      , @BatchJobSoftParameter (entityName = billCancelReason, name = BSEG_CAN_RSN_CD, required = true, type = entity)
 *      , @BatchJobSoftParameter (entityName = adjustmentCancelReason, name = ADJ_CAN_RSN_CD, required = true, type = entity)
 *      , @BatchJobSoftParameter (entityName = paymentCancelReason, name = PAY_CAN_RSN_CD, required = true, type = entity)
 *      , @BatchJobSoftParameter (entityName = customerContactClass, name = CUST_CONT_CL, required = true, type = entity)
 *      , @BatchJobSoftParameter (name = CUST_CONT_TYPE, required = true, type = string)
 *      , @BatchJobSoftParameter (name = CC_COMMENTS, required = true, type = string)
 *      , @BatchJobSoftParameter (entityName = billMessageType, name = BILL_MSG, type = entity)
 *      })
 */
public class CmCancelIncorrectSasBatch extends CmCancelIncorrectSasBatch_Gen {


	// Batch Parameters
	private String parmCisDivision;
	private String parmSaTypeCode;
	private CustomerContactClass parmCustomerContactClass;
	private String parmCustomerContactType;

	// Constants
	private static final String COMMA_DELIMITER = ",";
	private static final String SINGLE_QUOTE = "'";
	private static final String PARM_CIS_DIVISION = "CIS_DIVISION";
	private static final String PARM_SA_TYPE = "SA_TYPE_CD";

	public JobWork getJobWork() {

		StringBuilder sbGetAccounts = new StringBuilder();
		sbGetAccounts.append("SELECT ACCT_ID, SA_ID  ");
		sbGetAccounts.append("FROM CM_CANCEL_SA_ON_ACCT ");
		sbGetAccounts.append("WHERE SA_CANCELED_SW <> 'Y' ");

		PreparedStatement psGetAccounts = createPreparedStatement(sbGetAccounts.toString(), getClass().getName());

		// Build the Work list
		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();

		QueryIterator<SQLResultRow> iter = psGetAccounts.iterate();

		while (iter.hasNext()) {
			SQLResultRow row = iter.next();

			Account_Id accountId = (Account_Id) row.getId("ACCT_ID", Account.class);
			ServiceAgreement_Id saId = (ServiceAgreement_Id) row.getId("SA_ID", ServiceAgreement.class);

			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId(accountId);
			workUnit.addSupplementalData("saId", saId);
			workUnits.add(workUnit);              
		}
		iter.close();  

		return createJobWorkForThreadWorkUnitList(workUnits);  
	}

	/**
	 * This method will contain the logic used to validate the batch soft parameters.
	 * @param boolean
	 */
	public void validateSoftParameters(boolean isNewRun) {

		// Validate Parameter CIS Division
		parmCisDivision = getParameters().getCIS_DIVISION();
		StringTokenizer strTokenizerCis = new StringTokenizer(parmCisDivision, ",");
		int cisDivisionCount = strTokenizerCis.countTokens();
		if (cisDivisionCount < 1) {
			addError(CustomMessageRepository.SA269362_parameterIsMissing(PARM_CIS_DIVISION.trim()));
		}

		for (int i=0; i < cisDivisionCount; i++){
			String cisDivisionStr = strTokenizerCis.nextToken().trim();
			CisDivision cisDivision = new CisDivision_Id(cisDivisionStr.trim()).getEntity();
			if (isNull(cisDivision)){
				addError(CustomMessageRepository.SA269362_parameterIsInvalid(PARM_CIS_DIVISION.trim(), cisDivisionStr.trim()));
			}
		}

		// Validate Parameter SA Type
		parmSaTypeCode = getParameters().getSA_TYPE_CD();
		StringTokenizer strTokenizer = new StringTokenizer(parmSaTypeCode, ",");
		int saTypeCount = strTokenizer.countTokens();
		if (saTypeCount < 1) {
			addError(CustomMessageRepository.SA269362_parameterIsMissing(PARM_SA_TYPE.trim()));
		}

		for(int i=0; i < saTypeCount; i++) {
			String saType = strTokenizer.nextToken().trim();
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.append("SELECT 'X' ");
			stringBuilder.append("FROM CI_SA_TYPE ");
			stringBuilder.append("WHERE SA_TYPE_CD = :saType ");

			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			prepState.bindString("saType", saType, "SA_TYPE_CD");
			prepState.execute();
			if (prepState.list().size() == 0) {
				prepState.close();
				// SA Type is invalid
				addError(CustomMessageRepository.SA269362_parameterIsInvalid(PARM_SA_TYPE.trim(), saType.trim()));
			}
		}


		parmCustomerContactClass = getParameters().getCUST_CONT_CL();
		parmCustomerContactType = getParameters().getCUST_CONT_TYPE();
		CustomerContactType_Id ccTypeId = new CustomerContactType_Id(parmCustomerContactClass, parmCustomerContactType);
		if (isNull(ccTypeId.getEntity())) {
			addError(CustomMessageRepository.SA269362_invalidCcType(parmCustomerContactClass.getId().getTrimmedValue(), parmCustomerContactType));
		}

	}

	public Class<CmCancelIncorrectSasBatchWorker> getThreadWorkerClass() {
		return CmCancelIncorrectSasBatchWorker.class;
	}

	public static class CmCancelIncorrectSasBatchWorker extends
	CmCancelIncorrectSasBatchWorker_Gen {

		// Soft Parameters
		private String parmCisDivision;
		private String parmSaTypeCode;
		private BillCancelReason parmBillCancelRsn;
		private AdjustmentCancelReason parmAdjustmentCancelRsn;
		private PaymentCancelReason parmPaymentCancelRsn;
		private CustomerContactClass parmCustomerContactClass;
		private String parmCustomerContactType;
		private String parmCustomerContactComments;
		private BillMessageType parmBillMessage;

		// Work Variable
		private Account account;
		private ServiceAgreement saForCancellation;
		private CustomerContactType customerContactType;
		private List<String> cancelledSaList;
		private Bool atLeastOneSaIsCancelled;
		private Bool allSaAreInError;

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}
		public void initializeThreadWork(boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {

			parmCisDivision = getParameters().getCIS_DIVISION();
			parmSaTypeCode = getParameters().getSA_TYPE_CD();
			parmBillCancelRsn = getParameters().getBSEG_CAN_RSN_CD();
			parmAdjustmentCancelRsn = getParameters().getADJ_CAN_RSN_CD();
			parmPaymentCancelRsn = getParameters().getPAY_CAN_RSN_CD();
			parmCustomerContactClass = getParameters().getCUST_CONT_CL();
			parmCustomerContactType = getParameters().getCUST_CONT_TYPE();
			customerContactType = new CustomerContactType_Id(parmCustomerContactClass, parmCustomerContactType).getEntity();
			parmCustomerContactComments = getParameters().getCC_COMMENTS();
			parmBillMessage = getParameters().getBILL_MSG();
		}

		public boolean executeWorkUnit(ThreadWorkUnit threadWorkUnit)
				throws ThreadAbortedException, RunAbortedException {

			Account_Id accountId = (Account_Id) threadWorkUnit.getPrimaryId();
			account = accountId.getEntity();
			
			ServiceAgreement_Id saId = (ServiceAgreement_Id) threadWorkUnit.getSupplementallData("saId");

			atLeastOneSaIsCancelled = Bool.FALSE;
			allSaAreInError = Bool.FALSE;
			cancelledSaList = new ArrayList<String>();
			
			if (notNull(saId.getEntity())){
				saForCancellation = saId.getEntity();
				if (saForCancellation.getStatus().isCanceled()){
					updateCmTableToN(accountId,
							CustomMessageRepository.SA272952_invalidStatusOfSaForCancellation(saId.getEntity().getStatus().toLocalizedString(),
									saId.getTrimmedValue()).getMessageText(), "");
				}
				else {
					processSAforCancellation(saForCancellation);
				}
			}
			else {
				String cisDivisions = createsStringForQuery(parmCisDivision);
				String saTypes = createsStringForQuery(parmSaTypeCode); 

				StringBuilder retrieveServiceAgreements = new StringBuilder();
				retrieveServiceAgreements.append("SELECT ");
				retrieveServiceAgreements.append(  "SA.SA_ID ");
				retrieveServiceAgreements.append("FROM ");
				retrieveServiceAgreements.append(  "CI_SA SA, CI_SA_TYPE SATY ");
				retrieveServiceAgreements.append("WHERE ");
				retrieveServiceAgreements.append(  "SA.ACCT_ID = :accountId ");
				retrieveServiceAgreements.append(  "AND SA.CIS_DIVISION IN (" + cisDivisions.trim() + ") ");
				retrieveServiceAgreements.append(  "AND SA.SA_TYPE_CD IN (" + saTypes.trim() + ") ");
				retrieveServiceAgreements.append(  "AND SA.SA_STATUS_FLG NOT IN (:closedStatus, :canceledStatus) ");
				retrieveServiceAgreements.append(  "AND SA.SA_TYPE_CD = SATY.SA_TYPE_CD ");
				retrieveServiceAgreements.append(  "AND SA.CIS_DIVISION = SATY.CIS_DIVISION ");

				PreparedStatement retrieveServiceAgreementStmt = createPreparedStatement(retrieveServiceAgreements.toString(), getClass().getName());
				retrieveServiceAgreementStmt.bindId("accountId", accountId);
				retrieveServiceAgreementStmt.bindLookup("closedStatus", ServiceAgreementStatusLookup.constants.CLOSED);
				retrieveServiceAgreementStmt.bindLookup("canceledStatus", ServiceAgreementStatusLookup.constants.CANCELED);

				if(retrieveServiceAgreementStmt.list().size() < 1) {
					updateCmTableToN(accountId, CustomMessageRepository.SA272952_accountHasNoCancellableSAs().getMessageText(), saTypes);
				}
				else {
					// Process each retrieved SA for Cancellation
					for(SQLResultRow resultRow : retrieveServiceAgreementStmt.list()) {
						ServiceAgreement_Id	saForCancellationId = (ServiceAgreement_Id) resultRow.getId("SA_ID", ServiceAgreement.class);
						saForCancellation = saForCancellationId.getEntity();

						processSAforCancellation(saForCancellation);
					} 
					retrieveServiceAgreementStmt.close();
				}
			}

			// If at least one SA is cancelled
			if (atLeastOneSaIsCancelled.isTrue()) {
				// Create Customer Contact for the Main Person of the Account
				createCustomerContact(account.getMainPerson().getId(), cancelledSaList.toString());

				// If populated, use Bill Message parameter to create a temporary Bill Message on the Account
				if(notNull(parmBillMessage)) {
					AccountMessages accountMessages = account.getMessages();
					ListFilter<BillMessage> listFilterBillMessages =
							accountMessages.createFilter("WHERE this.id.billMessage = :billMessageType", "getBillMessage");
					listFilterBillMessages.bindId("billMessageType", parmBillMessage.getId());
					if (listFilterBillMessages.listSize() == 0){
					    AccountMessage_DTO acctMessageDto = accountMessages.newChildDTO();
					    acctMessageDto.setBillMessageType(BillMessageTypeLookup.constants.TEMPORARY);
					    accountMessages.add(acctMessageDto, parmBillMessage.getId());
					}
				}

				// Update SA_CANCELLED_SW to 'Y' if there is no error in SA cancellation
				if (allSaAreInError.isFalse()){
					// Set the SA_CANCELLED_SW to 'Y' on CM_ACCT_ON_SA CM Table
					StringBuilder queryString = new StringBuilder();
					queryString.append("UPDATE CM_CANCEL_SA_ON_ACCT ");
					queryString.append("SET SA_CANCELED_SW = :true ");
					queryString.append("WHERE ACCT_ID = :accountId ");

					PreparedStatement preparedStatement = createPreparedStatement(queryString.toString(), getClass().getName());
					preparedStatement.bindBoolean("true", Bool.TRUE);
					preparedStatement.bindId("accountId", accountId);

					preparedStatement.executeUpdate();
					preparedStatement.close();
				}
			}
			return true;
		}

		/**
		 * This method updates the CM_CANCEL_SA_ON_ACCT 
		 */
		private void updateCmTableToN(Account_Id accountId, String messageText, String concatText) {
			// Set the SA_CANCELED_SW to N and add Message Text on CM_CANCEL_SA_ON_ACCT table
			StringBuilder queryString = new StringBuilder();
			queryString.append("UPDATE CM_CANCEL_SA_ON_ACCT ");
			queryString.append("SET SA_CANCELED_SW = :false , ");
			queryString.append("MESSAGE_TEXT = :messageText ");
			queryString.append("WHERE ACCT_ID = :accountId ");

			PreparedStatement preparedStatement = createPreparedStatement(queryString.toString(), getClass().getName());
			preparedStatement.bindBoolean("false", Bool.FALSE);
			preparedStatement.bindString("messageText", messageText.concat(concatText), "MESSAGE_TEXT");
			preparedStatement.bindId("accountId", accountId);

			preparedStatement.executeUpdate();
			preparedStatement.close();
		}

		/**
		 * This method builds the String for query.
		 * @param saTypesStr
		 * @return String
		 */
		private String createsStringForQuery(String string) {
			StringTokenizer strTokenizer = new StringTokenizer(string, COMMA_DELIMITER);
			StringBuilder strBuilder = new StringBuilder();

			while (strTokenizer.hasMoreElements()) {
				strBuilder.append(SINGLE_QUOTE);
				strBuilder.append(strTokenizer.nextToken().trim());
				strBuilder.append(SINGLE_QUOTE);

				if (strTokenizer.hasMoreTokens()) {
					strBuilder.append(COMMA_DELIMITER);
				}
			}

			return strBuilder.toString();
		}

		/**
		 * This method cancels an SA and its frozen FTs
		 * @param sa
		 */
		private void processSAforCancellation(ServiceAgreement sa){
			SQLResultRow sqlRow = null;
			FinancialTransactionTypeLookup ftType = null;
			Adjustment_Id adjustmentId = null;
			Payment_Id paymentId = null;
			BillSegment_Id billSegmentId = null;

			// Retrieve and process non-cancelled Bill Segments, Adjustments and Payments
			Iterator<SQLResultRow> nonCanceledFts = getNonCancelledFts(sa);
			while (nonCanceledFts.hasNext()) {
				sqlRow = (SQLResultRow) nonCanceledFts.next();
				ftType = (FinancialTransactionTypeLookup) sqlRow.getLookup("FT_TYPE_FLG", FinancialTransactionTypeLookup.class);

				if(ftType.equals(FinancialTransactionTypeLookup.constants.BILL_SEGMENT)) {
					// Retrieve and cancel Bill Segment ID from Column SIBLING_ID
					billSegmentId = (BillSegment_Id) sqlRow.getId("SIBLING_ID", BillSegment.class);
					billSegmentId.getEntity().initiateCancel(getProcessDateTime().getDate(), parmBillCancelRsn);
					billSegmentId.getEntity().cancel(getProcessDateTime().getDate());
				} else if (ftType.equals(FinancialTransactionTypeLookup.constants.ADJUSTMENT)) {
					// Retrieve and cancel Adjustment ID from Column SIBLING_ID
					adjustmentId = (Adjustment_Id) sqlRow.getId("SIBLING_ID", Adjustment.class);
					CancelAdjustment cancelAdjustment = CancelAdjustment.Factory.newInstance();
					cancelAdjustment.cancelAdjustment(adjustmentId.getEntity(), parmAdjustmentCancelRsn);
				} else {
					if(ftType.equals(FinancialTransactionTypeLookup.constants.PAY_SEGMENT)) {
						// Retrieve and transfer Payment ID from Column PARENT_ID
						paymentId = (Payment_Id) sqlRow.getId("PARENT_ID", Payment.class);

						// Transfer Payment to the same Account where the SA belongs
						PaymentTransferProcessor paymentTransferProcessor = PaymentTransferProcessor.Factory.newInstance();
						PaymentTransferData paymentTransferData = PaymentTransferData.Factory.newInstance();
						paymentTransferData.setTransferAccount(account);
						paymentTransferData.setTransferPaymentCancelReason(parmPaymentCancelRsn);
						paymentTransferData.setTransferNonCisPayment(Bool.FALSE);
						paymentTransferData.setUseCurrentDateAsAccountingDate(Bool.TRUE);
						paymentTransferData.setCanFreezePayment(Bool.TRUE);
						paymentTransferProcessor.transferPayment(paymentId.getEntity(), paymentTransferData);
					}
				}
			}

			// If SA is currently Reactivated, set it first to Reinstated 
			if (sa.getStatus().isReactivated()){
				CmReinstateServiceAgreementRoutine reinstateSARoutine = CmReinstateServiceAgreementRoutine.Factory.newInstance();
				reinstateSARoutine.setIgnoreWarningSwitch(Bool.TRUE);
				reinstateSARoutine.setServiceAgreementID(sa.getId());
				reinstateSARoutine.invoke();
			}

			// Cancel the Service Agreement
			try {
				sa.cancel(Bool.TRUE);
			} catch (ApplicationError e) {
				updateCmTableToN(account.getId(), e.getServerMessage().getMessageText(), "");
				allSaAreInError = Bool.TRUE;
			}

			if (sa.getStatus().equals(ServiceAgreementStatusLookup.constants.CANCELED)) {
				atLeastOneSaIsCancelled = Bool.TRUE;
				cancelledSaList.add(sa.getId().getIdValue().trim());
			}
		}

		/**
		 * Retrieves Non-Cancelled FTs
		 * @param serviceAgreement
		 * @return returnValue - Iterator<SQLResultRow>
		 */
		private Iterator<SQLResultRow> getNonCancelledFts(ServiceAgreement serviceAgreement) {

			Iterator<SQLResultRow> returnValue = null;
			PreparedStatement query = createPreparedStatement(
					"SELECT FT.FT_TYPE_FLG, FT.SIBLING_ID, FT.PARENT_ID "
							+ "FROM CI_FT FT "
							+ "WHERE FT.SA_ID = :serviceAgreement "
							+ "AND FT.FT_TYPE_FLG IN (:billsegment, :adjustment, :paySegment) "
							+ "AND FT.FREEZE_SW = :true "
							+ "AND NOT EXISTS ( "
							+ "SELECT 'X' "
							+ "FROM CI_FT FT2 "
							+ "WHERE FT2.SA_ID = FT.SA_ID "
							+ "AND FT2.PARENT_ID = FT.PARENT_ID "
							+ "AND FT2.SIBLING_ID = FT.SIBLING_ID "
							+ "AND FT2.FT_TYPE_FLG IN (:billCancellation, :adjustmentCancellation, :payCancellation) "
							+ "AND FT2.FREEZE_SW = :true "
							+ ") "
							+ "ORDER BY FT.FT_TYPE_FLG ", getClass().getName()); 

			query.bindEntity("serviceAgreement", serviceAgreement);
			query.bindLookup("billsegment", FinancialTransactionTypeLookup.constants.BILL_SEGMENT);
			query.bindLookup("adjustment", FinancialTransactionTypeLookup.constants.ADJUSTMENT);
			query.bindLookup("paySegment", FinancialTransactionTypeLookup.constants.PAY_SEGMENT);
			query.bindBoolean("true", Bool.TRUE);
			query.bindLookup("billCancellation", FinancialTransactionTypeLookup.constants.BILL_CANCELLATION);
			query.bindLookup("adjustmentCancellation", FinancialTransactionTypeLookup.constants.ADJUSTMENT_CANCELLATION);
			query.bindLookup("payCancellation", FinancialTransactionTypeLookup.constants.PAY_CANCELLATION);

			query.execute();
			query.setAutoclose(false);
			returnValue = query.list().iterator();
			query.close();
			return returnValue;
		}
		
		/**
		 * Create Customer Contact
		 * @param perId
		 * @param saIdsStr
		 */
		private void createCustomerContact(Person_Id perId, String saIdsStr) {
			CustomerContact_DTO customerContactDto = new CustomerContact_DTO();
			customerContactDto.setPersonId(perId);
			customerContactDto.setContactDateTime(getProcessDateTime());
			customerContactDto.setCustomerContactTypeId(customerContactType.getId());
			customerContactDto.setLongDescription(parmCustomerContactComments.concat(saIdsStr));
			customerContactDto.newEntity();
		}
	}
}