/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 2024-07-30   DLampa     INC0037039. Updated field lengths to match 
 *                         the file layout extracted by the CM-BILEXTR 
 *                         algorithm
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractDetailsCurrentChargeDebtClassRecord 
		extends ColumnDelimitedRecord{	
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractDetailsCurrentChargeDebtClassRecord() {
		super(10);
		
		// Initialize all fields as blank/spaces
		this.setBPPrinterKey(" ");		
		this.setBPSortKey(" ");
		this.setBPMailingKey(" ");		
		this.setDebtClass(" ");
		this.setDebtClassDescr(" ");
		this.setCurAmt(BigDecimal.ZERO, "0");
		this.setTotAmt(BigDecimal.ZERO, "0");	
		this.setFiller();
	}
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * 
	 */
	public void setBPPrinterKey(String value) {		
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
	public void setBPSortKey(String value) {
		rightPadColumn(2, 184, truncateInput(value, 184));
	}
	public void setBPMailingKey(String value) {
		rightPadColumn(3, 15, truncateInput(value, 15));
	}	
	/*
	 * Current Charge Debt Class
	 */
	public void setDebtClass(String value) {
		rightPadColumn(4, 4, truncateInput(value, 4));
	}
	public void setDebtClassDescr(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(5, 30, truncateInput(value, 30));
		rightPadColumn(5, 60, truncateInput(value, 60));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setCurAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(6, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(7, 15, truncateInput(value, 15));
	}
	public void setTotAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(8, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(9, 15, truncateInput(value, 15));
	}
	public void setFiller() {
		//rightPadColumn(10, 3378, " ");
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(10, 3175, " ");
		rightPadColumn(10, 3145, " ");
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
}