/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 2024-07-30   DLampa     INC0037039. Updated field lengths to match 
 *                         the file layout extracted by the CM-BILEXTR 
 *                         algorithm 
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractDetailsBillSegmentReadRecord 
		extends ColumnDelimitedRecord{	
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractDetailsBillSegmentReadRecord() {
		super(38);
		
		// Initialize all fields as blank/spaces
		this.setBPPrinterKey(" ");		
		this.setBPSortKey(" ");
		this.setBPMailingKey(" ");
		this.setSpID(" ");
		this.setBadgeNbr(" ");
		this.setUomCd(" ");
		this.setTouCd(" ");
		this.setRdgDecPos(" ");
		this.setStartRegReading(BigDecimal.ZERO, "0");
		this.setStartReadDttm(" ");
		this.setStartEstimateSw(" ");
		this.setEndRegReading(BigDecimal.ZERO, "0");
		this.setEndReadDttm(" ");
		this.setEndEstimateSw(" ");
		this.setMsrQty(BigDecimal.ZERO, "0");
		this.setUsageFlg(" ");
		this.setUsePct(" ");
		this.setHowToUseFlg(" ");
		this.setConsumSubFlg(" ");
		this.setMsrPeakQtySw(" ");
		this.setRegConst(BigDecimal.ZERO, "0");
		this.setQtyDecPos(" ");
		this.setFinalUomCd(" ");
		this.setFinalTouCd(" ");
		this.setFinalRegQty(BigDecimal.ZERO, "0");
		this.setSqiCd(" ");
		this.setFinalSqiCd(" ");
		this.setReadType(" ");
		this.setMrSourceCd(" ");
		this.setSpDescr(" ");
		this.setReadDifferent(BigDecimal.ZERO, "0");
		this.setFiller();
	}
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * 
	 */
	public void setBPPrinterKey(String value) {		
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
	public void setBPSortKey(String value) {
		rightPadColumn(2, 184, truncateInput(value, 184));
	}
	public void setBPMailingKey(String value) {
		rightPadColumn(3, 15, truncateInput(value, 15));
	}	
	/*
	 * Bill Segment Read (List)
	 */
	public void setSpID(String value) {
		rightPadColumn(4, 10, truncateInput(value, 10));
	}
	public void setBadgeNbr(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(5, 16, truncateInput(value, 16));
		rightPadColumn(5, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setUomCd(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(6, 4, truncateInput(value, 4));
		rightPadColumn(6, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setTouCd(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(7, 8, truncateInput(value, 8));
		rightPadColumn(7, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setRdgDecPos(String value) {
		rightPadColumn(8, 1, truncateInput(value, 1));
	}
	public void setStartRegReading(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(9, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(10, 15, truncateInput(value, 15));
	}
	public void setStartReadDttm(String value) {
		rightPadColumn(11, 26, truncateInput(value, 26));
	}
	public void setStartEstimateSw(String value) {
		rightPadColumn(12, 1, truncateInput(value, 1));
	}
	public void setEndRegReading(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(13, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(14, 15, truncateInput(value, 15));
	}
	public void setEndReadDttm(String value) {
		rightPadColumn(15, 26, truncateInput(value, 26));
	}
	public void setEndEstimateSw(String value) {
		rightPadColumn(16, 1, truncateInput(value, 1));
	}
	public void setMsrQty(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(17, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(18, 18, truncateInput(value, 18));
	}
	public void setUsageFlg(String value) {
		rightPadColumn(19, 2, truncateInput(value, 2));
	}
	public void setUsePct(String value) {
		leftPadColumnWithZeros(20, 3, truncateInput(value, 3));
	}
	public void setHowToUseFlg(String value) {
		rightPadColumn(21, 2, truncateInput(value, 2));
	}
	public void setConsumSubFlg(String value) {
		rightPadColumn(22, 2, truncateInput(value, 2));
	}
	public void setMsrPeakQtySw(String value) {
		rightPadColumn(23, 1, truncateInput(value, 1));
	}
	public void setRegConst(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(24, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(25, 12, truncateInput(value, 12));
	}
	public void setQtyDecPos(String bdValue) {
		leftPadColumnWithZeros(26, 1, truncateInput(bdValue, 1));
	}
	public void setFinalUomCd(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(27, 4, truncateInput(value, 4));
		rightPadColumn(27, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setFinalTouCd(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(28, 8, truncateInput(value, 8));
		rightPadColumn(28, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setFinalRegQty(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(29, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(30, 18, truncateInput(value, 18));
	}
	public void setSqiCd(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(31, 8, truncateInput(value, 8));
		rightPadColumn(31, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setFinalSqiCd(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(32, 8, truncateInput(value, 8));
		rightPadColumn(32, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	} 
	public void setReadType(String value) {
		rightPadColumn(33, 2, truncateInput(value, 2));
	}
	public void setMrSourceCd(String value) {
		rightPadColumn(34,  12, truncateInput(value, 12));
	}
	public void setSpDescr(String value) {
		rightPadColumn(35, 254, truncateInput(value, 254));
	}
	public void setReadDifferent(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(36, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(37, 15, truncateInput(value, 15));
	}
	private void setFiller() {
		//rightPadColumn(38, 2945, " ");
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(38, 2742, " ");
		rightPadColumn(38, 2588, " ");
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
}