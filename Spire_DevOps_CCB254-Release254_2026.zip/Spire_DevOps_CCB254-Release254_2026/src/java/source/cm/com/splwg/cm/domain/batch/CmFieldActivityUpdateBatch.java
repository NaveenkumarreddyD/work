/* 
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * FA Update Batch Process
 *
 * This Java batch program will be the equivalent of CMPOFAUB. 
 * 
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:        Reason:
 * YYYY-MM-DD   IN         Reason text.
 *
 * 2016-02-22   MPang     NI0009.4. Initial Version.
 * 2016-06-09   MPang     Defect 3444408. Added connection closed and 
 *                        finalizeThreadWork method.
 * 2016-06-17   SFelip    Defect 3457887. Retrieve the parameters inside the
 *                        Batch Worker class.
 * 2018-06-07   SFelip    CCB v2.6 Upgrade. 
 * 2019-02-27   MPang     Defect 4211882. Updated the ntDowloadTypeCondition
 *                        to FACH.   
 * 2020-10-26   FRoig     Defect 4507031. Add intermediate status parameter
 * 						  to exclude FAs from being picked up.
 * 2021-07-23	JMeden	  D-02275. Update all the existing non-final
 * 						  sync request of field activity to cancelled
 * 2021-11-11	GCrisp	  Defect 4618832. Include new BO when updating all 
 * 						  the existing non-finalsync request of field 
 *                        activity to cancelled
 * 2021-12-29   RDizon    B-20173. Retrieve the Sync Request BO from the
 *                        Master Configuration instead of the Feature
 *                        Configuration.
 * 2025-11-14   EQuint    CCB25.4 Upgrade       
 ***************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.lookup.BusinessObjectStatusConditionLookup;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.domain.common.workCalendar.WorkCalendar;
import com.splwg.base.domain.syncRequest.SyncRequest;
import com.splwg.base.domain.syncRequest.SyncRequest_Id;
import com.splwg.base.domain.workflow.notificationDownloadType.NotificationDownloadType;
import com.splwg.base.domain.workflow.notificationDownloadType.NotificationDownloadType_Id;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.domain.admin.dispatchGroup.entity.DispatchGroup;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.cm.api.lookup.NtDownloadTypeConditionLookup;
import com.splwg.cm.api.lookup.SyncRequestCancelReasonLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpofaun;

//Start Update - 2021-07-23 - JMeden - D-02275
///**
// * @author MPang
// *
// @BatchJob (multiThreaded = true, rerunnable = false, modules = {},
// *      softParameters = { @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)
// *            , @BatchJobSoftParameter (entityName = workCalendar, name = WORK_CALENDAR_CD, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = NUMBER_OF_DAYS, required = true, type = integer)
// *            , @BatchJobSoftParameter (entityName = dispatchGroup, name = G4_DISP_GRP_CD, required = true, type = entity)
// *            , @BatchJobSoftParameter (lookupName = ntDownloadTypeCondition, name = NT_DWN_TY_COND_FLG, required = true, type = lookup)
// *            , @BatchJobSoftParameter (name = SKIP_PIGGYBACK_FA_SW, required = true, type = boolean)
// *            , @BatchJobSoftParameter (name = INTERMEDIATE_STATUS_LIST, type = string)})
// */
/**
 * @author MPang
 *
 @BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)
 *            , @BatchJobSoftParameter (entityName = workCalendar, name = WORK_CALENDAR_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = NUMBER_OF_DAYS, required = true, type = integer)
 *            , @BatchJobSoftParameter (entityName = dispatchGroup, name = G4_DISP_GRP_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (lookupName = ntDownloadTypeCondition, name = NT_DWN_TY_COND_FLG, required = true, type = lookup)
 *            , @BatchJobSoftParameter (name = SKIP_PIGGYBACK_FA_SW, required = true, type = boolean)
 *            , @BatchJobSoftParameter (name = INTERMEDIATE_STATUS_LIST, type = string)
 *            , @BatchJobSoftParameter (entityName = businessObject, name = BUS_OBJ_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = BO_CANCELLED_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (lookupName = syncRequestCancelReason, name = CANCEL_REASON, required = true, type = lookup)})      
 */
//End Update - 2021-07-23 - JMeden - D-02275
public class CmFieldActivityUpdateBatch extends CmFieldActivityUpdateBatch_Gen {

    // CONSTANTS
    // Start Change - 2016-06-17 - SFelipe - Defect 3457887
    //private static final String SP_OPT_TYPE = "CM_G4SVCPROV";
    //private static final String MSG_OPT_TYPE = "CI_WFM_MSGID_SEQ";
    
    private static final String SP_OPT_TYPE = "SPRV";
    // End Change - 2016-06-17 - SFelipe - Defect 3457887

    private static final String CONNECTION_ONLINE = "O";
    private static final String CONNECTION_BATCH = "B";

    private static final String SWITCH_YES = "Y";
    private static final String SWITCH_NO = "N";
    // Start Change - 2016-06-17 - SFelipe - Defect 3457887
    //private static DispatchGroup faDispatchGroup;
    //private static FeatureConfiguration dispatchGrpFC;
    //private static CmFeatureConfigurationRetriever configurationRetriever = null;
    //
    //private static NotificationDownloadType_Id notificationDownloadType;
    
    private DispatchGroup faDispatchGroup;
    private FeatureConfiguration dispatchGrpFC;
    // End Change - 2016-06-17 - SFelipe - Defect 3457887
    // Start Add - 2020-10-26 - FRoig - Defect 4507031
    private String intermediateStatusList;
    // End Add - 2020-10-26 - FRoig - Defect 4507031


    public JobWork getJobWork() {
        // Retrieve Dispatch Group entity from parameter
        faDispatchGroup = getParameters().getG4_DISP_GRP_CD();

        // Retrieve Feature Configuration from the Dispatch Group of the Field Activity
        dispatchGrpFC = faDispatchGroup.fetchWorkforceManagementSystem();
        // Start Delete - 2016-06-17 - SFelipe - Defect 3457887
        //// Retrieve Feature Configuration Option Type Value Service Provider from the Dispatch Group's Feature Configuration
        //configurationRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
        //configurationRetriever.setParmWFMName(dispatchGrpFC);
        //configurationRetriever.setParmOptType(SP_OPT_TYPE.trim());
        // End Delete - 2016-06-17 - SFelipe - Defect 3457887

        // Start Delete - 2016-06-17 - SFelipe - Defect 3457887
        ////Retrieve Notification Download Type of Look up FA Batch Update
        //NtDownloadTypeConditionLookup ntDownloadtypeLookUp = LookupHelper.getLookupInstance(NtDownloadTypeConditionLookup.class, getParameters().getNT_DWN_TY_COND_FLG().trimmedValue());
        //SQLResultRow resultSqlResultRow = retrieveNotificationDownloadType(ntDownloadtypeLookUp);
        //
        //if(ntDownloadtypeLookUp.isFaBatchUpdate()) {
        //  notificationDownloadType = (NotificationDownloadType_Id) resultSqlResultRow.getId("NT_DWN_TYPE_CD", NotificationDownloadType.class);
        //}
        // End Delete - 2016-06-17 - SFelipe - Defect 3457887

        //Copy VA030-GET-REQUIRED-VALUES, this will retrieve the following values

        // Start Change - 2020-10-26 - FRoig - Defect 4507031
        //Query<FieldActivity_Id> query = createQuery(" FROM FieldActivity fieldActivity " +
        //        " WHERE fieldActivity.dispatchGroupId = :dispatchGrpId " +
        //        " AND fieldActivity.fieldActivityStatus = :faStatus  " +
        //        " AND fieldActivity.scheduleDateTimeStart BETWEEN :startDate AND :endDate " +
        //        "       AND TRIM(UPPER(fieldActivity.user)) " +
        //        "       NOT IN (SELECT TRIM(UPPER(fco.value)) " +
        //        "       FROM FeatureConfigurationOption fco " +
        //        "       WHERE fco.id.workforceManagementSystem = :wfmName " +
        //        "       AND fco.id.optionType = 'XEUI') ", getClass().getName());
        
        intermediateStatusList = getParameters().getINTERMEDIATE_STATUS_LIST();
        StringBuilder queryStr = new StringBuilder();
        queryStr.append(" FROM FieldActivity fieldActivity ");
        queryStr.append(" WHERE fieldActivity.dispatchGroupId = :dispatchGrpId ");
        queryStr.append(" AND fieldActivity.fieldActivityStatus = :faStatus  ");

        String[] intermediateStates = null;
        if (notBlank(intermediateStatusList) && notNull(intermediateStatusList)) {
        	intermediateStates = intermediateStatusList.trim().split(",");
	        for(int i = 0; i < intermediateStates.length; i++) {
	        	// first element in the list
	            if (i == 0) {
	            	queryStr.append(" AND (fieldActivity.intermediateStatus <> :intStatus" + i + " ");
	            } else {
	            	queryStr.append("      AND fieldActivity.intermediateStatus <> :intStatus" + i + " ");
	            }
	            // last element in the list
	            if (i == intermediateStates.length - 1) {
	            	queryStr.append(")");
	            }
	        }
        }
        queryStr.append(" AND fieldActivity.scheduleDateTimeStart BETWEEN :startDate AND :endDate ");
        queryStr.append("       AND TRIM(UPPER(fieldActivity.user)) ");
        queryStr.append("       NOT IN (SELECT TRIM(UPPER(fco.value)) ");
        queryStr.append("       FROM FeatureConfigurationOption fco ");
        queryStr.append("       WHERE fco.id.workforceManagementSystem = :wfmName ");
        queryStr.append("       AND fco.id.optionType = 'XEUI') ");
        Query<FieldActivity_Id> query = createQuery(queryStr.toString(), getClass().getName());
        // End Change - 2020-10-26 - FRoig - Defect 4507031

        query.bindEntity("dispatchGrpId", faDispatchGroup);
        query.bindLookup("faStatus", FieldActivityStatusLookup.constants.PENDING);
        query.bindDate("startDate", getProcessDateTime().getDate());
        query.bindDate("endDate", getProcessDateTime().getDate().addDays(getParameters().getNUMBER_OF_DAYS().intValue()));
        query.bindEntity("wfmName", dispatchGrpFC);

        // Start Add - 2020-10-26 - FRoig - Defect 4507031
        if (notBlank(intermediateStatusList) && notNull(intermediateStatusList)) {
	        for(int i = 0; i < intermediateStates.length; i++) {
	        	query.bindStringProperty("intStatus" + i, FieldActivity.properties.intermediateStatus, intermediateStates[i]);
	        }
        }
        // End Add - 2020-10-26 - FRoig - Defect 4507031
        
        query.addResult("faId", "fieldActivity.id");

        return createJobWorkForEntityIdQuery(query);
    }

    // Start Delete - 2016-06-17 - SFelipe - Defect 3457887
    //private SQLResultRow retrieveNotificationDownloadType(NtDownloadTypeConditionLookup ntfDwldTypeConditionLookup) {
    //  SQLResultRow resultRow = null;
    //  StringBuilder getNotifDwldType = new StringBuilder();
    //  getNotifDwldType.append(" SELECT NTDWNTYPE.NT_DWN_TYPE_CD " +
    //          " FROM CI_NT_DWN_TYPE NTDWNTYPE " +
    //          " WHERE NTDWNTYPE.NT_DWN_TY_COND_FLG = :ntDwnTyCondFlag ");
    //
    //  PreparedStatement getExcPrepStmt = createPreparedStatement(getNotifDwldType.toString(), getClass().getName());
    //  getExcPrepStmt.bindLookup("ntDwnTyCondFlag", ntfDwldTypeConditionLookup);
    //  resultRow = getExcPrepStmt.firstRow();
    //  getExcPrepStmt.close();
    //
    //  return resultRow;
    //}
    // End Delete - 2016-06-17 - SFelipe - Defect 3457887
    /*
     * This method will create the Thread Work Unit per result row
     */
    public ThreadWorkUnit createWorkUnit(QueryResultRow resultRow) {
        FieldActivity_Id faId = (FieldActivity_Id) resultRow.getId("faId", FieldActivity.class);

        ThreadWorkUnit unit = new ThreadWorkUnit();
        unit.setPrimaryId(faId);
        unit.addSupplementalData("faId", faId);

        return unit;

    }

    public Class<CmFieldActivityUpdateBatchWorker> getThreadWorkerClass() {
        return CmFieldActivityUpdateBatchWorker.class;
    }

    public static class CmFieldActivityUpdateBatchWorker
    extends CmFieldActivityUpdateBatchWorker_Gen {

        //Work Variable
        private Cmpofaun cmpofaun;
        // start delete - equint - 2025-11-14 - CCB25.4 Upgrade
        // //Start Add - MPang - Defect 3444408 - 2016-06-09
        // private Connection connection;
        // //End Add - MPang - Defect 3444408 - 2016-06-09
        // end delete - equint - 2025-11-14 - CCB25.4 Upgrade

        //Batch Parameters
        // Start Change - 2016-06-17 - SFelipe - Defect 3457887
        //private static BigInteger parmMaxErrors;
        //private static WorkCalendar parmWorkCalendarCode;
        //private static BigInteger parmNumberOfDays;
        //private static DispatchGroup parmG4_DISP_GRP_CD;
        //private static NtDownloadTypeConditionLookup parmNtDownloadTypeCondition;
        //private static Bool parmSkipPiggyBackFASW;
        
        private BigInteger parmMaxErrors;
        private WorkCalendar parmWorkCalendarCode;
        private BigInteger parmNumberOfDays;
        private DispatchGroup parmG4_DISP_GRP_CD;
        private NtDownloadTypeConditionLookup parmNtDownloadTypeCondition;
        private Bool parmSkipPiggyBackFASW;
        
        private CmFeatureConfigurationRetriever configurationRetriever = null;
        private NotificationDownloadType_Id notificationDownloadType;
        private FeatureConfiguration dispatchGrpFC;
        private String serviceProvider;
        // End Change - 2016-06-17 - SFelipe - Defect 3457887
        //Start Add - 2021-07-23 - JMeden - D-02275
        private BusinessObject parmBusinessObject;
        private String parmCancelledStatus;
        private SyncRequestCancelReasonLookup parmCancelReason;
        //End Add - 2021-07-23 - JMeden - D-02275

        //Unit Variable
        private FieldActivity_Id faId;

        // Start Add - 2021-12-29 - RDizon  - B-20173
        private static final String MST_CFG_CLICK_FA = "CM-ClickFieldActivityMstConfig";
        // End Add
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }
   
        public boolean executeWorkUnit(ThreadWorkUnit threadWorkUnit)
                throws ThreadAbortedException, RunAbortedException {

            faId = (FieldActivity_Id) threadWorkUnit.getPrimaryId();
            
            //Start Add - 2021-07-23 - JMeden - D-02275
            //update all existing non-final Sync Request to Cancelled
            updateExistingSyncRequestToCancelledStatus(faId);
            //End Add - 2021-07-23 - JMeden - D-02275
            
            // start add - equint - 2025-11-14 - CCB25.4 Upgrade
 			try {
 				FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
				session.doWork(new ConnectionWork() {
		  			
		  			@Override
		  			public void execute(Connection connection) throws SQLException {
		  				try {  
							// assign new connection as it closes per work unit
		  					cmpofaun.getSession().getDbSession().setUpdateConnection(connection);
		  				}
		  				catch(Exception e) {
							throw new SQLException(e.getCause());
						}
					}
				});
 			}
 			catch(Exception err) {
 				logError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), err.toString()));
 			}
 			// end add - equint - 2025-11-14 - CCB25.4 Upgrade
            
            // reset program status and message numbers every unit
            cmpofaun.setProgramStatus(" ");
            cmpofaun.setMessageNbr(BigDecimal.ZERO);
            cmpofaun.setZmsgnMessageCatNbr(BigDecimal.ZERO);
            
            // Start Delete - 2016-06-17 - SFelipe - Defect 3457887
            ///*
            // * Using the Dispatch Group's Feature Configuration from the parameter,
            // * get the option value of Message Id Database Sequence where option type is "MSEQ".
            // */
            //faDispatchGroup = getParameters().getG4_DISP_GRP_CD();
            //dispatchGrpFC = faDispatchGroup.fetchWorkforceManagementSystem();
            //
            //configurationRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
            //configurationRetriever.setParmWFMName(dispatchGrpFC);
            //configurationRetriever.setParmOptType(MSG_OPT_TYPE.trim());
            // End Delete - 2016-06-17 - SFelipe - Defect 3457887
            
            // Start Add - 2016-06-17 - SFelipe - Defect 3457887
            // Retrieve Feature Configuration Option Type Value Service Provider from the Dispatch Group's Feature Configuration
            dispatchGrpFC = parmG4_DISP_GRP_CD.fetchWorkforceManagementSystem();

            configurationRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
            configurationRetriever.setParmWFMName(dispatchGrpFC);
            configurationRetriever.setParmOptType(SP_OPT_TYPE.trim());
            
            serviceProvider = configurationRetriever.getMaxSequenceOptionValue();
            
            //Retrieve Notification Download Type of Look up FA Batch Update
            NtDownloadTypeConditionLookup ntDownloadtypeLookUp = LookupHelper.getLookupInstance(NtDownloadTypeConditionLookup.class, 
                    parmNtDownloadTypeCondition.trimmedValue());
            SQLResultRow resultSqlResultRow = retrieveNotificationDownloadType(ntDownloadtypeLookUp);
            
            // Start Change - MPang - Defect 4211882 - 2019-02-27
            //if(ntDownloadtypeLookUp.isFaBatchUpdate()) {
            if(ntDownloadtypeLookUp.isFieldActivityChange()) {
            // End Change - MPang - Defect 4211882 - 2019-02-27
              notificationDownloadType = (NotificationDownloadType_Id) resultSqlResultRow.getId("NT_DWN_TYPE_CD", NotificationDownloadType.class);
            }
            // End Add - 2016-06-17 - SFelipe - Defect 3457887

            //Get actual Message Id, get the SQL from MS020 of CISXMSGP
            BigInteger messageIdSequence = BigInteger.ZERO;

            StringBuilder getDatabaseSequence = new StringBuilder();
            getDatabaseSequence.append("SELECT CI_WFM_MSGID_SEQ.NEXTVAL AS NEXTVALUE FROM DUAL ");

            PreparedStatement getExcPrepStmt = createPreparedStatement(getDatabaseSequence.toString(), getClass().getName());

            SQLResultRow resultRow = getExcPrepStmt.firstRow();

            if (notNull(resultRow)) {
                messageIdSequence = resultRow.getInteger("NEXTVALUE");
            }

            getExcPrepStmt.close();

            //Prepare call to CMPOFAUN, set batch parameters the following are expected in the copy book.
            // FA ID from the work unit
            // set unit parameters
            cmpofaun.setInputWrkFaId(faId.getTrimmedValue());

            //SKIP-PIGGYBACK-FA-SW from batch parameter
            cmpofaun.setSkipPiggybackFaSw(parmSkipPiggyBackFASW.isTrue() ? SWITCH_YES : SWITCH_NO);

            //Service Provider from VA030
            // Start Change - 2016-06-17 - SFelipe - Defect 3457887
            //if (notNull(dispatchGrpFC)) {
            //    cmpofaun.setInputWrkSprCd(SP_OPT_TYPE.trim());
            //}
            if (notNull(serviceProvider)) {
                cmpofaun.setInputWrkSprCd(serviceProvider.trim());
            }
            // End Change - 2016-06-17 - SFelipe - Defect 3457887
            //Notification Download Type from VA030; 

            if (notNull(notificationDownloadType)) {
                cmpofaun.setInputWrkNtDwnTypeCd(notificationDownloadType.getTrimmedValue());
            }
            //Message Id retrieved at the start of execute work unit
            cmpofaun.setMsgId(messageIdSequence.toString().trim());
            //System date time
            cmpofaun.setSysDttm(getProcessDateTime().toString());

            // log an error in batch run tree
            try {
                // initialize program
                callCobol();
            } catch(Exception err) {
                logError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), err.toString()));
                //Continue to the next record if there was an error
                //return true;
            }

            return true;
        }

        public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
            // Retrieve the Batch Parameters
            parmMaxErrors = getParameters().getMAX_ERRORS();
            parmWorkCalendarCode = getParameters().getWORK_CALENDAR_CD();
            parmNumberOfDays = getParameters().getNUMBER_OF_DAYS();
            parmG4_DISP_GRP_CD = getParameters().getG4_DISP_GRP_CD();
            parmNtDownloadTypeCondition = getParameters().getNT_DWN_TY_COND_FLG();
            parmSkipPiggyBackFASW = getParameters().getSKIP_PIGGYBACK_FA_SW();
            //Start Add - 2021-07-23 - JMeden - D-02275
            parmBusinessObject = getParameters().getBUS_OBJ_CD();
            parmCancelledStatus = getParameters().getBO_CANCELLED_STATUS();
            parmCancelReason = getParameters().getCANCEL_REASON();
            //End Add - 2021-07-23 - JMeden - D-02275
            

            try {
            	// initialize program
            	initializeCobolProgram();
            }
            catch(Exception err) {
            	addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), err.toString()));
            }   


        }
        
        //Start Add - 2021-07-23 - JMeden - D-02275
        /**
         * This method will cancelled all the existing non final Sync Request of field activity
         * @param faId
         */
        private void updateExistingSyncRequestToCancelledStatus(FieldActivity_Id faId){
            // Start Change - 2021-12-29 - RDizon  - B-20173
			// Start Add - 2021-11-13 - GCrisp - Defect 4618832 
			// CmFeatureConfigurationRetriever_Impl featConfigRetriever = new CmFeatureConfigurationRetriever_Impl();
			// FeatureConfiguration_Id featConfigId = new FeatureConfiguration_Id("CM-CLKFABSR");
			// featConfigRetriever.setParmWFMName(featConfigId.getEntity());
			
			// Retrieve BO
			// featConfigRetriever.setParmOptType(CmClickFABatchSyncRequestLookup.constants.BO.value());
			// String batchSyncRequestBo = featConfigRetriever.getMaxSequenceOptionValue().trim();
            
            String batchSyncRequestBo = null;
            String overrideSyncRequestBo = null;
            String onlineSyncRequestBo = null;
            String faCisDivisionStr = faId.getEntity().getServicePoint().getPremise().fetchDivision().getId().getTrimmedValue();
            String faTypeStr = faId.getEntity().getFieldActivityType().getId().getTrimmedValue();
            
            // Read Click FA  Master Configuration
            BusinessObjectInstance masterConfigBoInstance = BusinessObjectInstance.create(MST_CFG_CLICK_FA);
            masterConfigBoInstance.set("bo", MST_CFG_CLICK_FA);
            masterConfigBoInstance = BusinessObjectDispatcher.read(masterConfigBoInstance);
            
            COTSInstanceNode groupFaSyncRequestDetails = masterConfigBoInstance.getGroup("fieldActivitySyncRequestDetails");
            COTSInstanceList listFaSyncRequest = groupFaSyncRequestDetails.getList("fieldActivitySyncRequest");
            
            Iterator<COTSInstanceListNode> itrFaSyncRequest = listFaSyncRequest.iterator();
            COTSInstanceListNode faSyncRequestDetails = null;
            while (itrFaSyncRequest.hasNext()){
                
                faSyncRequestDetails = itrFaSyncRequest.next();
                String faSyncReqCisDivision = faSyncRequestDetails.getString("cisDivision").trim();
                String faSyncReqFaType = faSyncRequestDetails.getString("faType").trim();

                if (faSyncReqCisDivision.equalsIgnoreCase(faCisDivisionStr)
                        && faSyncReqFaType.equalsIgnoreCase(faTypeStr)){
                	overrideSyncRequestBo = faSyncRequestDetails.getString("syncRequestBo");
                    
                    break;
                }

            }

            if(isBlankOrNull(overrideSyncRequestBo)) {
            	overrideSyncRequestBo = masterConfigBoInstance.getString("batchSyncRequestBo");
    		}
            batchSyncRequestBo = masterConfigBoInstance.getString("batchSyncRequestBo");
            onlineSyncRequestBo = masterConfigBoInstance.getString("onlineSyncRequestBo");
            // End Change - 2021-12-29 - RDizon  - B-20173

            BusinessObject_Id batchSyncBoId = new BusinessObject_Id(batchSyncRequestBo);
            BusinessObject_Id overrideSyncBoId = new BusinessObject_Id(overrideSyncRequestBo);
            BusinessObject_Id onlineSyncBoId = new BusinessObject_Id(onlineSyncRequestBo);
			//End Add - 2021-11-13 - GCrisp - Defect 4618832 
        	Iterator<SQLResultRow> itr = null;
        	StringBuilder sqlNonFinalSyncRequest = new StringBuilder();
       	 	sqlNonFinalSyncRequest.append(" SELECT SR.F1_SYNC_REQ_ID ");
       	 	sqlNonFinalSyncRequest.append(" FROM F1_SYNC_REQ SR ");
			//Start Change - 2021-11-13 - GCrisp - Defect 4618832 
       	 	//sqlNonFinalSyncRequest.append(" WHERE SR.BUS_OBJ_CD = :boId ");
			sqlNonFinalSyncRequest.append(" WHERE SR.BUS_OBJ_CD in (:boId, :batchSyncBoId, :overrideBoId) ");
			//End Change - 2021-11-13 - GCrisp - Defect 4618832 
       	 	sqlNonFinalSyncRequest.append(" AND SR.PK_VALUE1 = :faId ");
       	 	sqlNonFinalSyncRequest.append(" AND SR.BO_STATUS_CD NOT IN (SELECT BOS.BO_STATUS_CD ");
       	 	sqlNonFinalSyncRequest.append(                            " FROM F1_BUS_OBJ_STATUS BOS ");
       	 	sqlNonFinalSyncRequest.append(                            " WHERE BOS.BUS_OBJ_CD = SR.BUS_OBJ_CD ");
       	 	sqlNonFinalSyncRequest.append(                            " AND BOS.BO_STATUS_COND_FLG = :final ) ");
       	 	
            PreparedStatement psSyncStatusUpdate = createPreparedStatement(sqlNonFinalSyncRequest.toString(), getClass().getName());
            psSyncStatusUpdate.bindId("boId", onlineSyncBoId);
			//Start Add - 2021-11-13 - GCrisp - Defect 4618832 
			psSyncStatusUpdate.bindId("batchSyncBoId", batchSyncBoId);
			psSyncStatusUpdate.bindId("overrideBoId", overrideSyncBoId);
			//End Add - 2021-11-13 - GCrisp - Defect 4618832 
            psSyncStatusUpdate.bindId("faId", faId);
            psSyncStatusUpdate.bindLookup("final", BusinessObjectStatusConditionLookup.constants.FINAL);
            itr = psSyncStatusUpdate.list().iterator();
            psSyncStatusUpdate.close();
            
            BusinessObjectInstance boInstance = null;
            BusinessObjectInstance boReadInstance = null;
            
            SyncRequest_Id syncReqId = null;
            while(itr.hasNext()){
            	boInstance = BusinessObjectInstance.create(parmBusinessObject);
            	syncReqId = (SyncRequest_Id) itr.next().getId("F1_SYNC_REQ_ID", SyncRequest.class);
            	boInstance.set("syncRequestId", syncReqId.getTrimmedValue());
            	boReadInstance = BusinessObjectDispatcher.read(boInstance);
            	
            	boReadInstance.set("boStatus", parmCancelledStatus);
            	boReadInstance.set("cancelReason", parmCancelReason);
            	BusinessObjectDispatcher.update(boReadInstance);
            }
        }
        //End Add - 2021-07-23 - JMeden - D-02275
        
        // Start Add - 2016-06-17 - SFelipe - Defect 3457887
        private SQLResultRow retrieveNotificationDownloadType(NtDownloadTypeConditionLookup ntfDwldTypeConditionLookup) {
          SQLResultRow resultRow = null;
          StringBuilder getNotifDwldType = new StringBuilder();
          getNotifDwldType.append(" SELECT NTDWNTYPE.NT_DWN_TYPE_CD " +
                  " FROM CI_NT_DWN_TYPE NTDWNTYPE " +
                  " WHERE NTDWNTYPE.NT_DWN_TY_COND_FLG = :ntDwnTyCondFlag ");
        
          PreparedStatement getExcPrepStmt = createPreparedStatement(getNotifDwldType.toString(), getClass().getName());
          getExcPrepStmt.bindLookup("ntDwnTyCondFlag", ntfDwldTypeConditionLookup);
          resultRow = getExcPrepStmt.firstRow();
          getExcPrepStmt.close();
        
          return resultRow;
        }
        // End Add - 2016-06-17 - SFelipe - Defect 3457887
        
        //Start Add - MPang - Defect 3444408 - 2016-06-09
        @Override
        public void finalizeThreadWork() throws ThreadAbortedException,
                RunAbortedException {
        	// start update - equint - 2025-11-14 - CCB25.4 Upgrade
        	cmpofaun=Session.returnSessionAndCodeToCache(cmpofaun);
//            try {
//                cmpofaun=Session.returnSessionAndCodeToCache(cmpofaun);
//                connection.close();
//            } catch(SQLException se) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getIdValue(), se.getMessage()));
//            }
            // end  update - equint - 2025-11-14 - CCB25.4 Upgrade
        }
        //End Add - MPang - Defect 3444408 - 2016-06-09
        /*
         * Initialize cobol program
         */
        @SuppressWarnings("deprecation")
        private void initializeCobolProgram() throws Exception {
            FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
            RequestContext context = session.getRequestContext();
            

    		// start update - equint - 2025-11-14 - CCB25.4 Upgrade
      		session.doWork(new ConnectionWork() {
      			
      			@Override
      			public void execute(Connection connection) throws SQLException {
      				try {  
      		            String username = connection.getMetaData().getUserName();
      		            String url = connection.getMetaData().getURL();
      		            CobolSession.setLogSessionStartEnd(false);
      		            cmpofaun=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpofaun.class);

      		            cmpofaun.getSession().getDbSession().setUpdateConnection(connection);
      		            cmpofaun.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");

      		            // set ZSTAT parameters

      		            cmpofaun.setProcessDt(getProcessDateTime().getDate().toString());
      		            cmpofaun.setProcessDttmSep("-");
      		            cmpofaun.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");

      		            if (session.isOnlineConnection()) { 
      		                cmpofaun.setConnectionFlg(CONNECTION_ONLINE);
      		            }
      		            else {
      		                cmpofaun.setConnectionFlg(CONNECTION_BATCH);
      		            }

      		            cmpofaun.setZstatUserId(context.getUserId()); 
      		            cmpofaun.setLanguageCd(context.getLanguageCode());

      		            if (context.ignoreWarnings()) {
      		                cmpofaun.setIgnoreWarningSw(SWITCH_YES);
      		            }
      		            else {
      		                cmpofaun.setIgnoreWarningSw(SWITCH_NO);
      		            }

      		            if (session.getBatchInstanceId() != null) {
      		                cmpofaun.setZstatSchedulerId(new BigDecimal(session.getBatchInstanceId()));
      		                cmpofaun.setSchedulerId(new BigDecimal(session.getBatchInstanceId()));

      		            } else {
      		                cmpofaun.setZstatSchedulerId(new BigDecimal(0));
      		                cmpofaun.setSchedulerId(new BigDecimal(0));
      		            }

      		            cmpofaun.setAppSvcId(context.getSecurityServiceIdContext());

      		            DatabaseHelper dbHelper = session.getDatabaseHelper();
      		            cmpofaun.setDbMode(dbHelper.getCobolDBMode());
      		            // CCB v2.6 Upgrade - 2018-05-31 - Start Change
      		            //cmpofaun.setSplHighValue(cmpofaun.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
      		            //cmpofaun.setSplLowValue(cmpofaun.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
      		            
      		            cmpofaun.setSplHighValue(cmpofaun.getSession().getSettings().getString(
      		                    new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
      		            cmpofaun.setSplLowValue(cmpofaun.getSession().getSettings().getString(
      		                    new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
      		            // CCB v2.6 Upgrade - 2018-05-31 - End Change

      		            cmpofaun.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()));
      		            
      		            cmpofaun.setLkExpiryDt(Date.MAX.toString());
      		            
      		            cmpofaun.setProgramStatus(" ");
      		            
      		            // CCB v2.6 Upgrade - 2018-08-02 - Start Add
      		            cmpofaun.setCallSeq(";");
      		            cmpofaun.setMessageAreaProgramName("CMPOFAUN");
      		            // CCB v2.6 Upgrade - 2018-08-02 - End Add

      		            if (context.getRandomGeneratorSeedSet().isTrue()) {
      		                cmpofaun.setRandomGenSeedSw(SWITCH_YES);
      		                cmpofaun.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()));
      		                cmpofaun.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()));
      		                cmpofaun.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()));
      		                cmpofaun.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()));
      		            }
      		            else {
      		                cmpofaun.setRandomGenSeedSw(SWITCH_NO);
      		            }

      		            if (context.traceStandardOut()) { 
      		                cmpofaun.setTrcStdoutSw(SWITCH_YES);
      		            }
      		            else {
      		                cmpofaun.setTrcStdoutSw(SWITCH_NO);
      		            }

      		            if (context.traceProgramStart()) { 
      		                cmpofaun.setTrcProgStartSw(SWITCH_YES);
      		            }
      		            else {
      		                cmpofaun.setTrcProgStartSw(SWITCH_NO);
      		            }

      		            if (context.traceProgramExit()) { 
      		                cmpofaun.setTrcProgExitSw(SWITCH_YES);
      		            }
      		            else {
      		                cmpofaun.setTrcProgExitSw(SWITCH_NO);
      		            }

      		            if (context.traceSQL()) { 
      		                cmpofaun.setTrcExecSqlSw(SWITCH_YES);
      		            }
      		            else {
      		                cmpofaun.setTrcExecSqlSw(SWITCH_NO);
      		            } 
      				}
      				catch(Exception e) {
    					throw new SQLException(e.getCause());
    				}
    				
    			}
    		});

//            SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//            //Start Add - MPang - Defect 3444408 - 2016-06-09
//            //Connection connection = implementor.getConnectionProvider().getConnection();
//            connection = implementor.getConnectionProvider().getConnection();
//            //End Add - MPang - Defect 3444408 - 2016-06-09
//            String username = connection.getMetaData().getUserName();
//            String url = connection.getMetaData().getURL();
//            CobolSession.setLogSessionStartEnd(false);
//            cmpofaun=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpofaun.class);
//
//            cmpofaun.getSession().getDbSession().setUpdateConnection(connection);
//            cmpofaun.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//
//            // set ZSTAT parameters
//
//            cmpofaun.setProcessDt(getProcessDateTime().getDate().toString());
//            cmpofaun.setProcessDttmSep("-");
//            cmpofaun.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//
//            if (session.isOnlineConnection()) { 
//                cmpofaun.setConnectionFlg(CONNECTION_ONLINE);
//            }
//            else {
//                cmpofaun.setConnectionFlg(CONNECTION_BATCH);
//            }
//
//            cmpofaun.setZstatUserId(context.getUserId()); 
//            cmpofaun.setLanguageCd(context.getLanguageCode());
//
//            if (context.ignoreWarnings()) {
//                cmpofaun.setIgnoreWarningSw(SWITCH_YES);
//            }
//            else {
//                cmpofaun.setIgnoreWarningSw(SWITCH_NO);
//            }
//
//            if (session.getBatchInstanceId() != null) {
//                cmpofaun.setZstatSchedulerId(new BigDecimal(session.getBatchInstanceId()));
//                cmpofaun.setSchedulerId(new BigDecimal(session.getBatchInstanceId()));
//
//            } else {
//                cmpofaun.setZstatSchedulerId(new BigDecimal(0));
//                cmpofaun.setSchedulerId(new BigDecimal(0));
//            }
//
//            cmpofaun.setAppSvcId(context.getSecurityServiceIdContext());
//
//            DatabaseHelper dbHelper = session.getDatabaseHelper();
//            cmpofaun.setDbMode(dbHelper.getCobolDBMode());
//            // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//            //cmpofaun.setSplHighValue(cmpofaun.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//            //cmpofaun.setSplLowValue(cmpofaun.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//            
//            cmpofaun.setSplHighValue(cmpofaun.getSession().getSettings().getString(
//                    new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//            cmpofaun.setSplLowValue(cmpofaun.getSession().getSettings().getString(
//                    new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//            // CCB v2.6 Upgrade - 2018-05-31 - End Change
//
//            cmpofaun.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()));
//            
//            cmpofaun.setLkExpiryDt(Date.MAX.toString());
//            
//            cmpofaun.setProgramStatus(" ");
//            
//            // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//            cmpofaun.setCallSeq(";");
//            cmpofaun.setMessageAreaProgramName("CMPOFAUN");
//            // CCB v2.6 Upgrade - 2018-08-02 - End Add
//
//            if (context.getRandomGeneratorSeedSet().isTrue()) {
//                cmpofaun.setRandomGenSeedSw(SWITCH_YES);
//                cmpofaun.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()));
//                cmpofaun.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()));
//                cmpofaun.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()));
//                cmpofaun.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()));
//            }
//            else {
//                cmpofaun.setRandomGenSeedSw(SWITCH_NO);
//            }
//
//            if (context.traceStandardOut()) { 
//                cmpofaun.setTrcStdoutSw(SWITCH_YES);
//            }
//            else {
//                cmpofaun.setTrcStdoutSw(SWITCH_NO);
//            }
//
//            if (context.traceProgramStart()) { 
//                cmpofaun.setTrcProgStartSw(SWITCH_YES);
//            }
//            else {
//                cmpofaun.setTrcProgStartSw(SWITCH_NO);
//            }
//
//            if (context.traceProgramExit()) { 
//                cmpofaun.setTrcProgExitSw(SWITCH_YES);
//            }
//            else {
//                cmpofaun.setTrcProgExitSw(SWITCH_NO);
//            }
//
//            if (context.traceSQL()) { 
//                cmpofaun.setTrcExecSqlSw(SWITCH_YES);
//            }
//            else {
//                cmpofaun.setTrcExecSqlSw(SWITCH_NO);
//            } 
      		
      	// end update - equint - 2025-11-14 - CCB25.4 Upgrade
        }

        private void callCobol() {
            try {
                cmpofaun.cobolMain();
            }catch(Exception _ex) {
                Throwable ex=_ex;
                while(ex.getCause()!=null) ex=ex.getCause();
                if(ex instanceof Stop) {
                    // if message number and category are not 0, meaning a server message is passed from the jacob code
                    if (cmpofaun.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
                            && cmpofaun.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
                        // pass the parameter to the server message
                        MessageParameters messageparameters = new MessageParameters();
                        for (int i = 1; i <= 9; i++) {
                            try { 
                                String parmValue = cmpofaun.getMessageParm(i);
                                if (notBlank(parmValue)) {
                                    messageparameters.addRawString(parmValue.trim());
                                }
                            }
                            catch(IndexOutOfBounds e) {
                                break;
                            }

                        }
                        MessageCategory_Id categoryId = new MessageCategory_Id(cmpofaun.getZmsgnMessageCatNbr().toBigInteger());
                        ServerMessage serverMessage = 
                                ServerMessageFactory.Factory.newInstance().createMessage(
                                        categoryId, cmpofaun.getMessageNbr().intValue(), messageparameters);

                        // check the message severity so we'll know what type of message to raise
                        
                        // info
                        if (cmpofaun.getMessageSeverity().compareTo(
                                MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
                            logInfo(serverMessage);
                        }
                        // warning
                        else if (cmpofaun.getMessageSeverity().compareTo(
                                MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0) {
                            logWarning(serverMessage);
                        }
                        // error
                        else {
                            logError(serverMessage);
                        }
                        
                    }
                }
                else  {
                    //Start Add - MPang - Defect 3444408 - 2016-06-09
                    ex.printStackTrace();
                    //End Add - MPang - Defect 3444408 - 2016-06-09
                    addError(CustomMessageRepository.JACOB_errorMessage(getBatchControlId().getTrimmedValue(), _ex.toString()));
                }
            }

        }
    }

    @Override
    public void validateSoftParameters(boolean flag) {
        // Validate that NUMBER-OF-DAYS is an integer greater than zero
        BigInteger parmNumberOfDays = getParameters().getNUMBER_OF_DAYS();
        if(parmNumberOfDays.compareTo(BigInteger.ZERO) < 0){
            addError(CustomMessageRepository.JACOB_InvalidNumericValue(parmNumberOfDays.toString()));
        }
        
        //Start Add - 2021-07-23 - JMeden - D-02275
        String parmCancelledStatus = getParameters().getBO_CANCELLED_STATUS();
        BusinessObject parmBusinessObject = getParameters().getBUS_OBJ_CD();
        ListFilter<BusinessObjectStatus> boStatus = parmBusinessObject.getStatuses().createFilter(" WHERE this.id.status = :status ", getClass().getName());
    	boStatus.bindStringProperty("status", BusinessObjectStatus.properties.status, parmCancelledStatus);

    	if(isNull(boStatus.firstRow())){
    		addError(CustomMessageRepositorySpireOne.D02275_BatchParmBOCancelledStatusInvalid(parmCancelledStatus));
    	}
        //End Add - 2021-07-23 - JMeden - D-02275
    }

}   

