/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Dollar Help Billing Adjustment
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2012-10-23   Arun          NA0039. Initial Version.
 * 2012-10-29   Arun          NA0039. Review Comments Incorporated.
 * 2013-02015   Srikanth      TIR - Invalid Currency Symbol -Bill Message Correction
 * 2013-06-24   Srikanth      CR- SD20130624 - Defect 2503
 * 2016-01-26   MPang		  Updated for CCB v2.4 compilation. 
 ******************************************************************************************/

package com.splwg.cm.domain.admin.saType;

import java.math.BigInteger;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.api.lookup.PaymentStatusLookup;
//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.adjustment.adjustment.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.adjustment.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.billMessage.BillMessageType;
import com.splwg.ccb.domain.admin.serviceAgreementType.SaTypeBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.billing.bill.BillData;
import com.splwg.ccb.domain.billing.bill.BillMessage;
import com.splwg.ccb.domain.billing.bill.BillMessageParameter_DTO;
import com.splwg.ccb.domain.billing.bill.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.BillMessage_Id;
import com.splwg.ccb.domain.billing.bill.Bill_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;*/

import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.billCompletion.SaTypeBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.billing.data.BillData;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage;
import com.splwg.ccb.domain.billing.bill.entity.BillMessageParameter_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * 
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentType, name = adjType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = billMessage, type = entity)
 *            , @AlgorithmSoftParameter (name = recurringOrOneTime, required = true, type = string)})
 */

public class CmDollarHelpSATypeBillCompletion_Impl 
extends CmDollarHelpSATypeBillCompletion_Gen 
implements SaTypeBillCompletionAlgorithmSpot {

    private ServiceAgreement saId;
    private BillData billData;
    private Bool isFtProcessAdded = Bool.FALSE;
    private Bool isFtTransferred = Bool.FALSE;
    private Bool isMultiRelExists = Bool.FALSE;
    private String strRecurOrOneTime;
    
    //Constants
    private final String RECUR = "Y";
    private final String ONETIME = "N";
    
    

    public Bool getAllowBillReopening() {
        return billData.getBillDTO().getIsReopenAllowed();
    }

    public BillData getBillData() {
        return billData;
    }

    public Bool getDoMultipleBillingRelationshipsExist() {
    	return isMultiRelExists;
    }

    public Bool getIsFtProcessAdded() {
        return isFtProcessAdded;
    }

    public Bool getIsFtTransferred() {
        return isFtTransferred;
    }

    public void setAccountingDate(Date arg0) {
    }

    public void setBillData(BillData billData) {
        this.billData=billData;
    }

    public void setBillDate(Date billDt) {
    	
    }

    public void setServiceAgreement(ServiceAgreement sa) {
        saId = sa;
    }
    
  /**
   * SD20130624 Defect 2503
   */
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
    	strRecurOrOneTime = getRecurringOrOneTime().trim();
           if(!(strRecurOrOneTime.equalsIgnoreCase(RECUR)) && !(strRecurOrOneTime.equalsIgnoreCase(ONETIME))){
        	  addError(CustomMessageRepository.na0039InvalidAlgoParamValue()) ;
           }
    }

    public void invoke() {
        Money currBillAmt;
        Money currUnBilledAdjAmt;
        Money previousCurrBalance;
        currBillAmt = saId.getCurrentBalance();
        currUnBilledAdjAmt = retreiveCurrentUnbilledAmt(saId);
        
        if(notNull(currUnBilledAdjAmt))
            previousCurrBalance = currBillAmt.subtract(currUnBilledAdjAmt);
        else
            previousCurrBalance = currBillAmt;
        
        
        BillMessageType billMessage=getBillMessage();
        // SD20130624 Defect 2503
        if(strRecurOrOneTime.equalsIgnoreCase(RECUR)){
           if(previousCurrBalance.compareTo(Money.ZERO) <= 0 ){
        	  return;
          }
        }else if(strRecurOrOneTime.equalsIgnoreCase(ONETIME)){
            if(previousCurrBalance.compareTo(Money.ZERO) == 0 ){
                return;
            }
          }

        CreateFrozenAdjustmentData frozenAdjData = CreateFrozenAdjustmentData.Factory.newInstance();
        frozenAdjData.setServiceAgreement(saId);
        frozenAdjData.setAdjustmentType(getAdjType());
        frozenAdjData.setAdjustmentAmount(previousCurrBalance.negate());
        frozenAdjData.setAllowZeroAmount(Bool.FALSE);
        CreateFrozenAdjustment frozenAdjustment =  CreateFrozenAdjustment.Factory.newInstance();
        frozenAdjustment.createFrozenAdjustment(frozenAdjData);

        if(notNull(billMessage))
        {
            Bill_DTO billDTO = billData.getBillDTO();
            startChanges();
            BillMessage_DTO billMsgDTO =  billDTO.getEntity().getMessages().newChildDTO();
            BillMessage_Id billMsgId = new BillMessage_Id(billMessage.getId(),billDTO.getId());
            billMsgDTO.setId(billMsgId);
            billMsgDTO.setVersion(1);
            BillMessage billMsg = billMsgDTO.newEntity();
            BillMessageParameter_DTO billMsgParmDTO = billMsg.getParameters().newChildDTO();
            billMsgParmDTO.setMessageParameterValue(previousCurrBalance.toLocalizedString(saId.fetchCurrency()));
            billMsgParmDTO.setVersion(1);
            billMsg.getParameters().add(billMsgParmDTO,BigInteger.ONE);
            billDTO.getId().getEntity().getMessages().add(billMsg);
            saveChanges();

        }
    }

    private Money retreiveCurrentUnbilledAmt(ServiceAgreement saId){
        Money currentBalAmt = null;
        StringBuilder currentBillAmtQueryString = new StringBuilder();
        currentBillAmtQueryString.append("SELECT FT.CUR_AMT CURAMNT FROM CI_FT FT  ");
        currentBillAmtQueryString.append("WHERE FT.SA_ID = :saId ");
        currentBillAmtQueryString.append("AND FT.REDUNDANT_SW = :no ");
        currentBillAmtQueryString.append("AND FT.FT_TYPE_FLG IN (:billSeg) ");
        currentBillAmtQueryString.append("AND FT.BILL_ID = ' ' ");
        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement currentBillAmtPrepStmt = createPreparedStatement(currentBillAmtQueryString.toString()); 
        PreparedStatement currentBillAmtPrepStmt = createPreparedStatement(currentBillAmtQueryString.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        currentBillAmtPrepStmt.bindId("saId", saId.getId());
        currentBillAmtPrepStmt.bindBoolean("no", Bool.FALSE);
        currentBillAmtPrepStmt.bindLookup("billSeg", FinancialTransactionTypeLookup.constants.BILL_SEGMENT);
        currentBalAmt = currentBillAmtPrepStmt.firstRow().getMoney("CURAMNT");
        currentBillAmtPrepStmt.close();

        if(isNull(currentBalAmt))
            return Money.ZERO;
        else
            return currentBalAmt;
    }


}
