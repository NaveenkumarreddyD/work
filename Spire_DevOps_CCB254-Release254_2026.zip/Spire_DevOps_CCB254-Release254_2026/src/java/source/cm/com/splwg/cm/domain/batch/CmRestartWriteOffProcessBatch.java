/**************************************************************************
* Program Name: CmRestartWriteOffProcessBatch
* Program Title: CmRestartWriteOffProcessBatch
* Author: LBallo
* Creation Date: 2017-05-30
* Purpose: This batch process will sync the SA's current and payoff balance
            and create a WO Process for the SA
* Functional Spec: 83395
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:         Date:         Description:
 * ----------------------------------------------------------------------------------------------
 *  83395             Louis Ballon    2017-05-30    Initial Version
 *  Defect 3803394    Louis Ballon    2017-07-26    1. Added filter in the main query to exclude
 *  												SAs with zero balance.
 *  												2. Change the creation of Write Off Process
 *  												from WriteOffProcessCreator to DTO
 *  Defect 3890429    Jerald Tiozon   2017-10-18    Set Trigger Business Process to false
 *                                                  when creating Write Off Process and Write Off
 *                                                  Events.
 * SysAid# 330523     JHERNA          2020-04-17    Update the main selection criteria to take 
 *                                                  into consideration of the status of the 
 *                                                  Collection Agency Placement records. 
 *                                                  main selection SQL is also updated for 
 *                                                  efficiency.                                             
 ************************************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.List;
import java.util.StringTokenizer;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.CriteriaPriorityLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.WriteOffEventStatusLookup;
import com.splwg.ccb.api.lookup.WriteOffSaStatusLookup;
import com.splwg.ccb.api.lookup.WriteOffStatusLookup;
import com.splwg.ccb.api.lookup.WriteOffStatusReasonLookup;
import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.debtClass.entity.DebtClass;
import com.splwg.ccb.domain.admin.writeOffControl.entity.WriteOffControl_Id;
import com.splwg.ccb.domain.admin.writeOffDebtClass.entity.WriteOffDebtClass;
import com.splwg.ccb.domain.admin.writeOffEventType.entity.WriteOffEventType_Id;
import com.splwg.ccb.domain.admin.writeOffProcessTemplate.entity.WriteOffProcessTemplate;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffEvent_DTO;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffEvent_Id;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffProcess;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffProcessServiceAgreement_DTO;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffProcessServiceAgreement_Id;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffProcess_DTO;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffProcess_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author LBallo
 *
@BatchJob (	multiThreaded = false, 
 *	   		rerunnable = true,
 *	   		modules = {},
 *         	softParameters = {@BatchJobSoftParameter (entityName = debtClass, name = DEBT_CLASS, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = MAX_AGE_OF_DEBT, required = true, type = integer)
 *            , @BatchJobSoftParameter (name = SA_TYPE_TO_EXCLUDE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = SA_CHAR_TO_EXCLUDE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = adjustmentType, name = ADJ_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = writeOffProcessTemplate, name = WO_PROC_TMPL_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity)
 *            })
 */

public class CmRestartWriteOffProcessBatch extends CmRestartWriteOffProcessBatch_Gen {

	// START CHANGES - JHERNA - 2020-04-17 - SysAid#330523
	/*
	// Constant Variables
	private static final String COMMA = ",";
	
	@Override
	public JobWork getJobWork() {
		
		DebtClass debtClass = getParameters().getDEBT_CLASS();
		BigInteger maxAgeOfDebt = getParameters().getMAX_AGE_OF_DEBT();
		String saTypesToExclude = getParameters().getSA_TYPE_TO_EXCLUDE();
		String saCharsToExclude = getParameters().getSA_CHAR_TO_EXCLUDE();
		CisDivision cisDivision = getParameters().getCIS_DIVISION();
		int saTypeCounter;
		int saCharCounter;
		
		List<ThreadWorkUnit> workUnitList = new ArrayList<ThreadWorkUnit>();
		
		Date ageOfDebtDate = getParameters().getProcessDate().addYears(-maxAgeOfDebt.intValue());
		
		StringBuilder queryStr = new StringBuilder();
		
        queryStr.append("SELECT ");
		queryStr.append(  "A.SA_ID ");
		queryStr.append("FROM ");
		queryStr.append(  "CI_SA A, ");
		queryStr.append(  "CI_SA_TYPE B ");
		queryStr.append("WHERE ");
		queryStr.append(  "A.END_DT >= :ageOfDebt ");
		queryStr.append(  "AND A.SA_STATUS_FLG IN (:stopped,:reactivated) ");
		queryStr.append(  "AND B.DEBT_CL_CD = :debtClass ");
		queryStr.append(  "AND A.CIS_DIVISION = :cisDivision ");
		queryStr.append(  "AND A.SA_TYPE_CD NOT IN ( ");
		
		for(saTypeCounter = 1;saTypeCounter <= saTypesToExclude.split(",").length;saTypeCounter++) {
			if(saTypeCounter > 1) {
				queryStr.append(COMMA);
		    }
			queryStr.append(":saType" + saTypeCounter);  
		}
		queryStr.append(" ) ");
		
		queryStr.append(  "AND NOT EXISTS ");
		queryStr.append(    "(SELECT ");
		queryStr.append(	   "'X' ");
		queryStr.append(	 "FROM ");
		queryStr.append(       "CI_SA_CHAR B1 ");
		queryStr.append(	 "WHERE ");
		queryStr.append(	   "A.SA_ID = B1.SA_ID ");
		queryStr.append(	   "AND B1.CHAR_TYPE_CD IN ( ");
		
		for(saCharCounter = 1;saCharCounter <= saCharsToExclude.split(",").length;saCharCounter++) {
			if(saCharCounter > 1) {
				queryStr.append(COMMA);
			}
			queryStr.append(":saChar" + saCharCounter);
		}
		queryStr.append(" ) ");
		queryStr.append(	   "AND EFFDT <= :processDate) ");
		queryStr.append(  "AND NOT EXISTS ");
		queryStr.append(    "(SELECT ");
		queryStr.append(        "'X' ");
		queryStr.append(      "FROM ");
		queryStr.append(        "F1_SVC_TASK A1, ");
		queryStr.append(        "F1_SVC_TASK_CHAR B1 ");
		queryStr.append(      "WHERE ");
		queryStr.append(        "A1.BUS_OBJ_CD = 'CM-CollAgencyPlacement' ");
		queryStr.append(        "AND A1.F1_SVC_TASK_ID = B1.F1_SVC_TASK_ID ");
		queryStr.append(        "AND B1.CHAR_VAL_FK1 = A.SA_ID ");
		queryStr.append(        "AND B1.CHAR_TYPE_CD = 'C1-SA   ' ");
		queryStr.append(        "AND A1.F1_SVC_TASK_ID = B1.F1_SVC_TASK_ID ) ");
		queryStr.append(  "AND A.SA_TYPE_CD = B.SA_TYPE_CD ");
		queryStr.append(  "AND A.CIS_DIVISION = B.CIS_DIVISION ");
		queryStr.append(  "AND NOT EXISTS ");
	    queryStr.append(    "(SELECT ");
	    queryStr.append(        "'X' ");
	    queryStr.append(      "FROM ");
	    queryStr.append(        "CI_WO_PROC_SA WOS, ");
	    queryStr.append(        "CI_WO_PROC WO ");
	    queryStr.append(      "WHERE ");
	    queryStr.append(      "WOS.WO_PROC_ID = WO.WO_PROC_ID ");
	    queryStr.append(      "AND WOS.SA_ID = A.SA_ID ");
	    queryStr.append(      "AND WO.WO_STATUS_FLG = :active ) ");
		
		PreparedStatement query = createPreparedStatement(queryStr.toString(), getClass().getName());
		query.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
		query.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
		query.bindLookup("active", WriteOffStatusLookup.constants.ACTIVE);
		query.bindDate("ageOfDebt", ageOfDebtDate);
		query.bindDate("processDate", getProcessDateTime().getDate());
		query.bindEntity("debtClass", debtClass);
		query.bindEntity("cisDivision", cisDivision);
		
		saTypeCounter = 1;
		saCharCounter = 1;
		
		for(String saTypeIdStr : saTypesToExclude.split(",")) {
			query.bindString("saType" + saTypeCounter++, saTypeIdStr, "SA_TYPE_CD");
		}
		
		for(String saCharIdStr : saCharsToExclude.split(",")) {
			query.bindString("saChar" + saCharCounter++, saCharIdStr, "CHAR_TYPE_CD");
		}
		
		for(SQLResultRow row : query.list()) {
			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId(row.getId("SA_ID", ServiceAgreement.class));
			workUnitList.add(workUnit);
		}
		
		query.close();
		return createJobWorkForThreadWorkUnitList(workUnitList);
	}
	
	public void validateSoftParameters(boolean isNewRun) {
		
		String[] saTypesToExclude = getParameters().getSA_TYPE_TO_EXCLUDE().split(COMMA);
		String[] saCharsToExclude = getParameters().getSA_CHAR_TO_EXCLUDE().split(COMMA);
		BigInteger ageOfDebt = getParameters().getMAX_AGE_OF_DEBT();
		
		if(ageOfDebt.intValue() <= 0) {
			addError(CustomMessageRepository.SPIRE_83395_InvalidAgeOfDebt(ageOfDebt));
		}
		
		for(String saTypeStr : saTypesToExclude) {
			isSATypeIdValid(saTypeStr);
		}
		
		for(String charTypeStr : saCharsToExclude) {
			CharacteristicType_Id charTypeId = new CharacteristicType_Id(charTypeStr);
			if(isNull(charTypeId.getEntity())) {
				addError(CustomMessageRepository.SPIRE_83395_InvalidCharType(charTypeStr));
			}
		}
		
		super.validateSoftParameters(isNewRun);
	}
	
	
	private void isSATypeIdValid(String saTypeIdStr) {
		
		CisDivision cisDivision = getParameters().getCIS_DIVISION();
		ServiceAgreementType_Id saTypeId = new ServiceAgreementType_Id(cisDivision, saTypeIdStr);
		
		if(isNull(saTypeId.getEntity())) {
			addError(CustomMessageRepository.SPIRE_83395_InvalidSAType(saTypeIdStr));
		}
	}
	*/
	// Work Variables for get job work
	private String wCollOfSaTypesToExclude, wCollOfCharTypesToExclude;
	@Override
	public void validateSoftParameters(boolean isNewRun) {

		// Age of Debt parameter must be a valid integer and greater than zero
		BigInteger maxAgeOfDebt = this.getParameters().getMAX_AGE_OF_DEBT();
		if (maxAgeOfDebt.compareTo(BigInteger.ZERO) <= 0) {
		    // Batch parameter '%1%2' value (%3) must be greater than zero.
			addError(CustomMessageRepositoryMGE.commBatchParameterMustBeGreaterThanZero("Max Age of Debt", maxAgeOfDebt.toString().trim()));
		}
		// SA Types on the collection must be valid.
		wCollOfSaTypesToExclude = retrieveAndValidateSaTypes(this.getParameters().getSA_TYPE_TO_EXCLUDE(), "SA Types to exclude");
		// Characteristic Types on the collection must be valid and must be usable on the Service Agreement entity.
		wCollOfCharTypesToExclude = retriveAndValidateCharTypes(this.getParameters().getSA_CHAR_TO_EXCLUDE(), "SA Char Types to exclude");		
	}
	
	private String retrieveAndValidateSaTypes(String parmVal, String parmDesc) {
		String returnValue = " ";
		if (notBlank(parmVal)) {
			StringTokenizer st = new StringTokenizer(parmVal, ",");
			while (st.hasMoreTokens()) {
				String saTypeStr = st.nextToken(); 
				validateSaTypeStr(saTypeStr, parmDesc);
				returnValue = returnValue.trim().concat("'");
				returnValue = returnValue.trim().concat(saTypeStr.trim());
				returnValue = returnValue.trim().concat("',");				
			}
		}		
		if (notBlank(returnValue)) {
			returnValue = returnValue.trim().substring(0, returnValue.trim().length() - 1);
		}
		return returnValue;
	}

	private void validateSaTypeStr(String saType, String parmDesc) {
		
		if (notBlank(saType)) {
			
			PreparedStatement prepState = createPreparedStatement(
					"SELECT 'X' "
					+ "FROM CI_SA_TYPE "
					+ "WHERE SA_TYPE_CD = '"+saType.trim()+"' ", 
					"==validateSaTypeStr==");
			prepState.setAutoclose(false);
			prepState.execute();
			if (isNull(prepState.firstRow())) {
				prepState.close();
			    // Batch parameter '%1%2' value (%3) is invalid.
				addError(CustomMessageRepositoryMGE.commBatchParameterInvalid(parmDesc.trim(), saType.trim()));
			}	
			prepState.close();
		}	
	}
	
	private String retriveAndValidateCharTypes(String charTypes, String parmDesc) {
		
		String returnValue = " ";
		if (notBlank(charTypes)) {
			StringTokenizer st = new StringTokenizer(charTypes, ",");
			while (st.hasMoreTokens()) {
				String charTypeStr = st.nextToken(); 
				validateCharTypeStr(charTypeStr, parmDesc, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT);
				returnValue = returnValue.trim().concat("'");
				returnValue = returnValue.trim().concat(charTypeStr.trim());
				returnValue = returnValue.trim().concat("',");					
			}
		}		
		if (notBlank(returnValue)) {
			returnValue = returnValue.trim().substring(0, returnValue.trim().length() - 1);
		}
		return returnValue;		
	}
	
	private void validateCharTypeStr(String charType, String parmDesc, CharacteristicEntityLookup entity) {
		
		if (notBlank(charType)) {
			CharacteristicType_Id charTypeID = new CharacteristicType_Id(charType.trim());
			if (isNull(charTypeID.getEntity())) {
			    // Batch parameter '%1%2' value (%3) is invalid.
				addError(CustomMessageRepositoryMGE.commBatchParameterInvalid(parmDesc, charType.trim()));
			}
			CharacteristicEntity_Id charEntityID = new CharacteristicEntity_Id(charTypeID, entity);
			if (isNull(charEntityID.getEntity())) {
			    // Batch parameter '%1%2' value (%3) is not a valid char type for %4%5 entity.
				addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharTypeForEntity(parmDesc, charType, 
						entity.getLookupValue().fetchLanguageDescription().trim()));
			}			
		}
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public JobWork getJobWork() {
		
		Date processDate = this.getProcessDateTime().getDate();
		Date maxAgeOfDebt = processDate.addYears(-this.getParameters().getMAX_AGE_OF_DEBT().intValue());
		StringBuilder stringBuilder = new StringBuilder();
		
		stringBuilder.append("SELECT SA.SA_ID ");
		stringBuilder.append("FROM CI_SA SA, CI_SA_TYPE SAT ");
		stringBuilder.append("WHERE SA.END_DT >= :maxAgeOfDebt  ");
		stringBuilder.append("AND SA.SA_STATUS_FLG IN (:stopped, :reactivated) ");	
		stringBuilder.append("AND SA.SA_TYPE_CD NOT IN ("+wCollOfSaTypesToExclude+") ");
		stringBuilder.append("AND SA.CIS_DIVISION = :cisDivision ");
		stringBuilder.append("AND SAT.SA_TYPE_CD = SA.SA_TYPE_CD ");
		stringBuilder.append("AND SAT.CIS_DIVISION = SA.CIS_DIVISION ");
		stringBuilder.append("AND SAT.DEBT_CL_CD = :debtClass ");
		// Must not have restart write off characteristic 
		stringBuilder.append("AND NOT EXISTS (SELECT 'X' ");
		stringBuilder.append("                FROM CI_SA_CHAR SAC ");
		stringBuilder.append("				  WHERE SAC.SA_ID = SA.SA_ID ");
		stringBuilder.append("				  AND SAC.CHAR_TYPE_CD IN ("+wCollOfCharTypesToExclude+") ");
		stringBuilder.append("				  AND SAC.EFFDT <= :processDate ");
		stringBuilder.append("                ) ");
		// Must not have an active write off
		stringBuilder.append("AND NOT EXISTS (SELECT 'X' ");
		stringBuilder.append("                FROM CI_WO_PROC WO, CI_WO_PROC_SA WOSA ");
		stringBuilder.append("				  WHERE WOSA.SA_ID = SA.SA_ID ");
		stringBuilder.append("				  AND WO.WO_PROC_ID = WOSA.WO_PROC_ID ");
		stringBuilder.append("				  AND WO.WO_STATUS_FLG = :active ");
		stringBuilder.append("                ) ");
		// Must not have an active collection agency placement
		stringBuilder.append("AND NOT EXISTS (SELECT 'X' ");
		stringBuilder.append("                FROM F1_SVC_TASK ST, F1_SVC_TASK_CHAR STC ");
		stringBuilder.append("				  WHERE ST.BUS_OBJ_CD = 'CM-CollAgencyPlacement' ");
		stringBuilder.append("				  AND ST.BO_STATUS_CD = 'ACTIVE' ");
		stringBuilder.append("				  AND STC.F1_SVC_TASK_ID = ST.F1_SVC_TASK_ID ");
		stringBuilder.append("				  AND STC.CHAR_TYPE_CD = 'C1-SA' ");
		stringBuilder.append("				  AND STC.CHAR_VAL_FK1 = SA.SA_ID ");
		stringBuilder.append("               ) ");

		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==Main Selection Criteria==");
		prepState.setAutoclose(true);
		prepState.bindDate("maxAgeOfDebt", maxAgeOfDebt);
		prepState.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
		prepState.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
		prepState.bindId("cisDivision", this.getParameters().getCIS_DIVISION().getId());
		prepState.bindId("debtClass", this.getParameters().getDEBT_CLASS().getId());
		prepState.bindDate("processDate", processDate);
		prepState.bindLookup("active", WriteOffStatusLookup.constants.ACTIVE);
		prepState.execute();
		
		QueryIterator returnValue = prepState.iterate();
		return createJobWorkForQueryIterator(returnValue, this);	
	}

	@Override
	public ThreadWorkUnit createWorkUnit(QueryResultRow qrw) {
		
		ThreadWorkUnit twu = new ThreadWorkUnit();
		ServiceAgreement_Id saID = (ServiceAgreement_Id) qrw.getId("SA_ID", ServiceAgreement.class);	
		twu.setPrimaryId(saID);
		return twu;
	}	
	// END CHANGES - JHERNA - 2020-04-17 - SysAid#330523	

	@Override
	public Class<CmRestartWriteOffProcessBatchWorker> getThreadWorkerClass() {
		return CmRestartWriteOffProcessBatchWorker.class;
	}
	
	public static class CmRestartWriteOffProcessBatchWorker extends
	CmRestartWriteOffProcessBatchWorker_Gen {
		
		// Work Variables
		AdjustmentType syncAdjType;
		DebtClass debtClass;
		WriteOffProcessTemplate writeOffprocessTemplate;
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}
		
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
			syncAdjType = getParameters().getADJ_TYPE_CD();
			debtClass = getParameters().getDEBT_CLASS();
			writeOffprocessTemplate = getParameters().getWO_PROC_TMPL_CD();
		}
		
		protected boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			ServiceAgreement_Id saId = (ServiceAgreement_Id) unit.getPrimaryId(); 
			ServiceAgreement sa = saId.getEntity();
			
			Money currentBalance = sa.getCurrentBalance();
			Money payoffBalance = sa.getPayoffBalance();
			
			// Defect 3803394 - 2017-07-26 - Start Add
			if(payoffBalance.isZero()) {
				return true;
			}
			// Defect 3803394 - 2017-07-26 - End Add
			
			if(!currentBalance.isEqualTo(payoffBalance)) {
				CreateFrozenAdjustmentData frozenAdjData = CreateFrozenAdjustmentData.Factory.newInstance();
				frozenAdjData.setServiceAgreement(saId.getEntity());
				frozenAdjData.setAdjustmentType(syncAdjType);
				frozenAdjData.setAdjustmentAmount(payoffBalance.add(currentBalance.negate()));
				frozenAdjData.setCalculationDate(getProcessDateTime().getDate());
				frozenAdjData.setAdjustmentDate(getProcessDateTime().getDate());
				frozenAdjData.setArrearsDate(getProcessDateTime().getDate());
				frozenAdjData.setAllowZeroAmount(Bool.TRUE);
				CreateFrozenAdjustment frozenAdjustment = CreateFrozenAdjustment.Factory.newInstance();
				frozenAdjData = frozenAdjustment.createFrozenAdjustment(frozenAdjData);
			}
			
			Account acct = sa.getAccount();
			
			WriteOffControl_Id writeOffControlId = retrieveAccountsWriteOffControl(acct.getId());
			if(isNull(writeOffControlId)){
			    addError(CustomMessageRepository.SPIRE_83395_NoCollectionClass(acct.getId().getIdValue()));
			   
			}
			CriteriaPriorityLookup criteriaPriority = retrieveCriteriaPriority(writeOffControlId);
			if(isNull(criteriaPriority)) {
				criteriaPriority = CriteriaPriorityLookup.constants.CRITERIA_PRIORITY_9_0_;
			}
			
			WriteOffProcess existingWO = getExistingWriteOff(acct, writeOffControlId, sa.getServiceAgreementType().getWriteOffDebtClass());
			
			if (notNull(existingWO)){
			    
			    addSAToWriteOffProcess(existingWO, sa);
			    
			} else {
			    
				// Defect 3803394 - 2017-07-26 - Start Change
			    //WriteOffProcessCreator woProcCreator = WriteOffProcessCreator.Factory.newInstance();
	            //WriteOffProcess newWO = woProcCreator.addWriteOffProcess(acct, writeOffControlId.getEntity().getWriteOffDebtClass(), writeOffControlId.getEntity(), criteriaPriority, writeOffprocessTemplate, Bool.TRUE);
	            WriteOffProcess_DTO woProcDto = new WriteOffProcess_DTO();
	            woProcDto.setAccountId(acct.getId());
	            woProcDto.setWriteOffControlId(writeOffControlId);
	            woProcDto.setCreationDateTime(getProcessDateTime());
	            woProcDto.setPriority(criteriaPriority);
	            woProcDto.setWriteOffProcessTemplateId(writeOffprocessTemplate.getId());
	            woProcDto.setWriteOffStatus(WriteOffStatusLookup.constants.ACTIVE);
	            woProcDto.setWriteOffStatusReason(WriteOffStatusReasonLookup.constants.EVENTS_PENDING);
	            // Defect 3890429 - 2017-10-18 - Start Change
	            //woProcDto.setTriggerBusinessProcess(Bool.TRUE);
	            woProcDto.setTriggerBusinessProcess(Bool.FALSE);
	            // Defect 3890429 - 2017-10-18 - End Change
	            WriteOffProcess newWO = woProcDto.newEntity();
	            addWoProcEvent(newWO,writeOffprocessTemplate);
	            // Defect 3803394 - 2017-07-26 - End Change
	            
	            addSAToWriteOffProcess(newWO, sa);
			}
			
			return true;
			
		}
		
		private void addSAToWriteOffProcess (WriteOffProcess woProc, ServiceAgreement sa) {
		    
            WriteOffProcessServiceAgreement_DTO woProcSa_DTO = new WriteOffProcessServiceAgreement_DTO();
            WriteOffProcessServiceAgreement_Id woProcSaId = new WriteOffProcessServiceAgreement_Id(woProc, sa);
            
            woProcSa_DTO.setId(woProcSaId);
            woProcSa_DTO.setWriteOffSAStatus(WriteOffSaStatusLookup.constants.ACTIVE);
            woProcSa_DTO.setArrearsAmount(sa.getPayoffBalance());
            
            woProc.getServiceAgreements().add(woProcSa_DTO, sa.getId());
            
		}
		
		private WriteOffProcess getExistingWriteOff(Account account, WriteOffControl_Id writeOffCtrl_Id, WriteOffDebtClass woDebtClass){
		    
		    WriteOffProcess woProc = null;
		    
		    StringBuilder queryStr = new StringBuilder();
		    queryStr.append("SELECT ");
		    queryStr.append(  "WOP.WO_PROC_ID ");
		    queryStr.append("FROM ");
		    queryStr.append(  "CI_WO_PROC WOP, ");
		    queryStr.append(  "CI_WO_CNTL WOC ");
		    queryStr.append("WHERE ");
		    queryStr.append(  "WOP.ACCT_ID = :acctId ");
		    queryStr.append(  "AND WOP.WO_STATUS_FLG = :active ");
		    queryStr.append(  "AND WOP.WO_PROC_TMPL_CD = :woProcTmpCd ");
		    queryStr.append(  "AND WOP.WO_CNTL_CD = :woCntlCd ");
		    queryStr.append(  "AND WOP.WO_CNTL_CD = WOC.WO_CNTL_CD ");
		    queryStr.append(  "AND WOC.WO_DEBT_CL_CD = :woDebtClass ");
		    
		    PreparedStatement statement = createPreparedStatement(queryStr.toString(), getClass().getName());
		    statement.bindId("acctId", account.getId());
		    statement.bindLookup("active", WriteOffStatusLookup.constants.ACTIVE);
		    statement.bindId("woProcTmpCd", writeOffprocessTemplate.getId());
		    statement.bindId("woCntlCd", writeOffCtrl_Id);
		    statement.bindId("woDebtClass", woDebtClass.getId());
		    
			// START ADD - JHERNA - 2020-04-17 - SysAid#330523
		    statement.setAutoclose(false);
			// END ADD - JHERNA - 2020-04-17 - SysAid#330523
		    SQLResultRow result = statement.firstRow();
		    
		    if(notNull(result)){
		        WriteOffProcess_Id woProcId = new WriteOffProcess_Id(result.getString("WO_PROC_ID"));
		        woProc = woProcId.getEntity();
		    }
		    
		    statement.close();
		    
		    return woProc;
		    
		}
		
		private WriteOffControl_Id retrieveAccountsWriteOffControl(Account_Id acctId) {
			
			StringBuilder queryStr = new StringBuilder();
			
			queryStr.append("SELECT ");
			queryStr.append(  "WC.WO_CNTL_CD ");
			queryStr.append("FROM ");
			queryStr.append(  "CI_WO_CNTL WC, CI_ACCT AC ");
			queryStr.append("WHERE ");
			queryStr.append(  "AC.ACCT_ID = :accountId ");
			queryStr.append(  "AND AC.COLL_CL_CD = WC.COLL_CL_CD ");
			queryStr.append(  "AND WC.WO_DEBT_CL_CD = :woDebtClCd "); 
			
			PreparedStatement query = createPreparedStatement(queryStr.toString(), getClass().getName());
			
			query.bindId("accountId", acctId);
			query.bindEntity("woDebtClCd", debtClass);
			// START ADD - JHERNA - 2020-04-17 - SysAid#330523
			query.setAutoclose(false);
			// END ADD - JHERNA - 2020-04-17 - SysAid#330523
			WriteOffControl_Id writeOffControlId = null;
			
			if(notNull(query.firstRow())) {
				String writeOffControlIdStr = query.firstRow().getString("WO_CNTL_CD");
				writeOffControlId = new WriteOffControl_Id(writeOffControlIdStr);
			}
			
			query.close();
			return writeOffControlId;
			
		}
		
		private CriteriaPriorityLookup retrieveCriteriaPriority(WriteOffControl_Id writeOffControlId) {
			
			StringBuilder queryStr = new StringBuilder();
			
			queryStr.append("SELECT ");
			queryStr.append(  "CRIT_PRIO_FLG ");
			queryStr.append("FROM ");
			queryStr.append(  "CI_WO_CRIT ");
			queryStr.append("WHERE ");
			queryStr.append(  "WO_CNTL_CD = :woCtrlId ");
			queryStr.append("ORDER BY CRIT_PRIO_FLG ASC ");
			
			PreparedStatement query = createPreparedStatement(queryStr.toString(), getClass().getName());
			
			query.bindId("woCtrlId", writeOffControlId);
			// START ADD - JHERNA - 2020-04-17 - SysAid#330523
			query.setAutoclose(false);
			// END ADD - JHERNA - 2020-04-17 - SysAid#330523
			SQLResultRow row = query.firstRow();
			query.close();
			
			if(notNull(row)) {
				return row.getLookup("CRIT_PRIO_FLG", CriteriaPriorityLookup.class);
			} else {
				return null;
			}
		}
		
		// Defect 3803394 - 2017-07-26 - Start Add
		private void addWoProcEvent(WriteOffProcess woProc, WriteOffProcessTemplate woProcTemplate) {
			StringBuilder addWoProcEventStr = new StringBuilder();
			
			addWoProcEventStr.append("SELECT ");
			addWoProcEventStr.append(  "EVT_SEQ, ");
			addWoProcEventStr.append(  "WO_EVT_TYP_CD, "); 
			addWoProcEventStr.append(  "DAYS_AFT_PROC_CRE ");
			addWoProcEventStr.append("FROM ");
			addWoProcEventStr.append(  "CI_WO_RESP "); 
			addWoProcEventStr.append("WHERE ");
			addWoProcEventStr.append(  "WO_PROC_TMPL_CD = :woProcTemplate ");
			
			PreparedStatement addWoProcEventQuery = createPreparedStatement(addWoProcEventStr.toString(), getClass().getName());
			addWoProcEventQuery.bindEntity("woProcTemplate", woProcTemplate);
			// START ADD - JHERNA - 2020-04-17 - SysAid#330523
			addWoProcEventQuery.setAutoclose(false);
			// END ADD - JHERNA - 2020-04-17 - SysAid#330523
			
			List<SQLResultRow> rowList = addWoProcEventQuery.list();
			BigInteger eventSequence;
			BigInteger daysAfterProcessCreation;
			WriteOffEventType_Id woEvtTypeId;
			WriteOffEvent_DTO writeOffEventDto = null;
			WriteOffEvent_Id woEvtId;
			
			for(SQLResultRow row : rowList) {
				eventSequence = row.getInteger("EVT_SEQ");
				woEvtTypeId = new WriteOffEventType_Id(row.getString("WO_EVT_TYP_CD"));
				daysAfterProcessCreation = row.getInteger("DAYS_AFT_PROC_CRE");
				
            	writeOffEventDto = new WriteOffEvent_DTO();
            	woEvtId = new WriteOffEvent_Id(woProc, eventSequence);
            	
            	writeOffEventDto.setId(woEvtId);
            	// Defect 3890429 - 2017-10-18 - Start Change
            	//writeOffEventDto.setTriggerBusinessProcess(Bool.TRUE);
            	writeOffEventDto.setTriggerBusinessProcess(Bool.FALSE);
            	// Defect 3890429 - 2017-10-18 - End Change
            	writeOffEventDto.setWriteOffEventStatus(WriteOffEventStatusLookup.constants.PENDING);
            	writeOffEventDto.setWriteOffEventTypeCodeId(woEvtTypeId);
            	writeOffEventDto.setTriggerDate(getProcessDateTime().getDate().addDays(daysAfterProcessCreation.intValue()));
            	writeOffEventDto.newEntity();
			}
			// START ADD - JHERNA - 2020-04-17 - SysAid#330523
			addWoProcEventQuery.close();
			// END ADD - JHERNA - 2020-04-17 - SysAid#330523
		}
		// Defect 3803394 - 2017-07-26 - End Add
	}
}
