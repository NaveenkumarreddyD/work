/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Pledge Payment Reconciliation Batch
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-04-23   Arun            NI0026.7 Initial Version.
 * 2016-01-29  	MPang			Updated for CCB v2.4 compilation.
 * 2018-07-25   SFelip          CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                              longer needed. 
 ******************************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_Id;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeSortKeyTypes;
import com.splwg.ccb.api.lookup.ActionFlagLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.PaymentStatusLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.matchType.MatchType;
import com.splwg.ccb.domain.admin.paymentCancelReason.PaymentCancelReason;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTask;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTaskCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTaskCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTask_DTO;
import com.splwg.ccb.domain.payment.payment.Payment;
import com.splwg.ccb.domain.payment.payment.PaymentCharacteristic;
import com.splwg.ccb.domain.payment.payment.PaymentCharacteristic_DTO;
import com.splwg.ccb.domain.payment.payment.PaymentOnlineDriverParameters;
import com.splwg.ccb.domain.payment.payment.PaymentTransferData;
import com.splwg.ccb.domain.payment.payment.PaymentTransferProcessor;
import com.splwg.ccb.domain.payment.payment.Payment_DTO;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentEvent_Id;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoMaintenanceData;*/

import com.splwg.ccb.domain.admin.matchType.entity.MatchType;
import com.splwg.ccb.domain.admin.paymentCancelReason.entity.PaymentCancelReason;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic_DTO;
import com.splwg.base.domain.serviceTask.ServiceTask_DTO;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.ccb.domain.payment.payment.entity.PaymentCharacteristic;
import com.splwg.ccb.domain.payment.payment.entity.PaymentCharacteristic_DTO;
import com.splwg.ccb.domain.payment.data.PaymentOnlineDriverParameters;
import com.splwg.ccb.domain.payment.data.PaymentTransferData;
import com.splwg.ccb.domain.payment.common.PaymentTransferProcessor;
import com.splwg.ccb.domain.payment.payment.entity.Payment_DTO;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentEvent_Id;
import com.splwg.ccb.domain.todo.common.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.data.ToDoMaintenanceData;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/** 
 * @BatchJob (modules = {}, multiThreaded = false,
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string )
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string )
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, required = false, type = integer) 
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PLEDGE_PAYMENT_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = PLEDGE_PAYMENT_CHAR_VALUE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PLEDGE_PAID_STATUS, required = true, type = string)            
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = TRANSACTION_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = paymentCancelReason, name = PAY_CANCEL_REASON, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = TO_DO_TYPE_PLEDGE_PAYMENT, required = true, type = entity, entityName = toDoType)
 *            , @BatchJobSoftParameter (entityName = matchType, name = MATCH_TYPE_CODE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PLEDGE_ID_CHAR_TYPE, required = true, type = entity)})
 */

public class CmPledgePayReconIb_BatchProcess 
extends CmPledgePayReconIb_BatchProcess_Gen{

    // Soft Parameters
    private static String parmFileName;
    private static String parmFilePath;
    private static BigInteger parmMaxErrors = BigInteger.ZERO;
    private static CharacteristicType parmPledgePaymentCharType;
    private static String parmPledgePaymentCharValue;
    private static String parmPledgePaidStatus;
    private static CharacteristicType parmTransIdCharType;
    private static PaymentCancelReason parmPayCancelReason;
    private static MatchType parmMatchTypeCode;
    private static ToDoType parmTodoTypePledgePayment;
    private static CharacteristicType parmPledgeIdCharType;

    private static File inputFile = null;
    private static final String PAYMENT_ID = "PAY_ID";
    private static final String SERVICETASK_ID = "F1_SVC_TASK_ID";
    private static final String COMMA_DELIMITER = ",";
    private static final int TOTAL_NBR_FIELDS_IN_FILE = 5;

    /**
     * This method retrieves the records to be processed and in case of error returns a JobWork with single ThreadWorkUnit
     * 
     * @return the JobWork that will be processed in this run.
     */
    public JobWork getJobWork() {

        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();                                               
        ThreadWorkUnit workUnit = new ThreadWorkUnit(); 
        workUnits.add(workUnit);   
        return createJobWorkForThreadWorkUnitList(workUnits);
    }

    public ThreadWorkUnit createWorkUnit(QueryResultRow queryResultRow) {
        return super.createWorkUnit(queryResultRow);
    }

    /**
     * This method checks if all required Soft Parameters were populated,
     * and all optional Soft Parameters (if populated) are valid.
     * 
     * @param isNewRun - a boolean value
     */
    public void validateSoftParameters(boolean isNewRun){
        initializeSoftParams();
        File folder = new File(parmFilePath);
        if(!(folder.exists() && folder.isDirectory())){
            addError(CustomMessageRepository.ni0026_7FilePathInvalid(parmFilePath));
        }

        inputFile = new File(parmFilePath, parmFileName);
        if(!inputFile.exists() || !inputFile.canRead()){
            addError(CustomMessageRepository.ni0026_7InvalidFileName(parmFileName)); 
        } 

        if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
            addError(CustomMessageRepository.ni0026_7IntegerParamCannotBeNegative(parmMaxErrors.toString().trim()));
        }

        validateChar(parmPledgePaymentCharType, CharacteristicEntityLookup.constants.PAYMENT);
        validateChar(parmTransIdCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        validateChar(parmPledgeIdCharType, CharacteristicEntityLookup.constants.SERVICE_TASK); 

        CharacteristicValue_Id charValueId = new CharacteristicValue_Id(new CharacteristicType_Id(parmPledgePaymentCharType.getId().getIdValue()),parmPledgePaymentCharValue);
        if (isNull(charValueId.getEntity())){
            addError(CustomMessageRepository.ni0026_7InvalidInputCharValue(parmPledgePaymentCharValue));
        } 
    }

    private void validateChar(CharacteristicType charType,CharacteristicEntityLookup charEntity){
        CharacteristicEntity_Id charEntityId; 
        charEntityId = new CharacteristicEntity_Id(charType, charEntity);
        if(isNull(charEntityId.getEntity())){
            addError(CustomMessageRepository.ni0026_7InvalidCharType(charType.getId().getTrimmedValue(),charEntity.getLookupValue().fetchLanguageDescription()));
        }
    }

    private void initializeSoftParams(){
        parmFileName = getParameters().getFILE_NAME();
        parmFilePath = getParameters().getFILE_PATH();
        parmMaxErrors = getParameters().getSoftMaxErrors();
        parmPledgePaymentCharType = getParameters().getPLEDGE_PAYMENT_CHAR_TYPE();
        parmPledgePaymentCharValue = getParameters().getPLEDGE_PAYMENT_CHAR_VALUE();
        parmPledgePaidStatus = getParameters().getPLEDGE_PAID_STATUS();
        parmTransIdCharType = getParameters().getTRANSACTION_ID_CHAR_TYPE();
        parmPayCancelReason = getParameters().getPAY_CANCEL_REASON();
        parmMatchTypeCode = getParameters().getMATCH_TYPE_CODE();
        parmTodoTypePledgePayment = getParameters().getTO_DO_TYPE_PLEDGE_PAYMENT();
        parmPledgeIdCharType = getParameters().getPLEDGE_ID_CHAR_TYPE();
    }

    /**
     * Method to retrieve the Thread Worker Class.
     * 
     * @return the thread worker class
     */
    public Class<CmPledgePayReconIb_BatchProcessWorker> getThreadWorkerClass() {
        return CmPledgePayReconIb_BatchProcessWorker.class;
    }

    /**
     * This Worker Class is responsible for processing a single Thread Instance.
     */
    public static class CmPledgePayReconIb_BatchProcessWorker
    extends CmPledgePayReconIb_BatchProcessWorker_Gen {

        // Working Variables
        private BigInteger numberOfRecordsInError = BigInteger.ZERO;
        private BigInteger numberOfRecordsProcessed = BigInteger.ZERO;

        private PaymentEvent_Id payEventId = null;
        private Account account = null;
        private ServiceAgreement_Id saId = null;


        private BufferedReader inputBufferReader = null;

        /**
         * This method identifies the execution strategy to be used for the thread.
         * 
         * @return an instance of ThreadExecutionStrategy that governs how this ThreadWorker will be executed at runtime.
         * @see com.splwg.base.api.batch.ThreadWorker#createExecutionStrategy()
         */
        public ThreadExecutionStrategy createExecutionStrategy() {

            return new SingleTransactionStrategy(this);
        }

        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {

            processFile();

            logMessage(CustomMessageRepository.ni0026_7TotalNumberOfRecordsProcessed(String.valueOf(numberOfRecordsProcessed)), MessageSeverityLookup.constants.INFORMATIONAL);
            WorkUnitResult workUnitResult = new WorkUnitResult(true);
            workUnitResult.setUnitsProcessed(numberOfRecordsProcessed.intValue());
            workUnitResult.setUnitsInError(numberOfRecordsInError.intValue());

            closeFile();
            return workUnitResult; 
        }  

        private void processFile(){
            String detailRecord = null;
            Payment payId = null;
            String pledgeId = null;
            String transactionId = null;

            openFile();

            while(notNull(detailRecord = readRecord())){
                String[] elements = detailRecord.split(COMMA_DELIMITER);
                if(elements.length < (TOTAL_NBR_FIELDS_IN_FILE-1)){
                    addError(CustomMessageRepository.ni0026_7FileMustHaveFiveFields(parmFileName));
                }

                if(isBlankOrNull(elements[0].trim())){
                    addError(CustomMessageRepository.ni0026_7AccountIdShouldNotBeBlankInFile());
                }

                account = new Account_Id(elements[0].trim()).getEntity();
                if(isNull(account)){
                    addError(CustomMessageRepository.ni0026_7AccountIdNotFound(elements[0].trim()));
                }
                if(isBlankOrNull(elements[1].trim())){
                    addError(CustomMessageRepository.ni0026_7SaIdShouldNotBeBlankInFile());
                }
                saId = new ServiceAgreement_Id(elements[1].trim());

                if(isNull(saId.getEntity())){
                    addError(CustomMessageRepository.ni0026_7SaIdNotFound(saId.getTrimmedValue()));
                }

                if(isBlankOrNull(elements[2].trim())){
                    addError(CustomMessageRepository.ni0026_7payEventIdShouldNotBeBlankInFile());
                }

                payEventId = new PaymentEvent_Id(elements[2].trim());

                if(isNull(payEventId.getEntity())){
                    addError(CustomMessageRepository.ni0026_7payEventIdNotFound(payEventId.getTrimmedValue()));
                }
                pledgeId = elements[3].trim();
                if(isBlankOrNull(pledgeId)){
                    addError(CustomMessageRepository.ni0026_7PledgeIdShouldNotBeBlankInFile());
                }

                transactionId = elements[4].trim();
                if(isBlankOrNull(transactionId)){
                    addError(CustomMessageRepository.ni0026_7TransactionIdShouldNotBeBlankInFile());
                }

                Money saPayOffBal =  saId.getEntity().getPayoffBalance();

                List<SQLResultRow> payIdList = retrievePayId();
                for(SQLResultRow resultRow: payIdList) {

                    payId = resultRow.getEntity(PAYMENT_ID, Payment.class);
                    PaymentTransferProcessor transferPayment = PaymentTransferProcessor.Factory.newInstance();
                    PaymentTransferData payData = PaymentTransferData.Factory.newInstance();
                    payData.setTransferAccount(account);
                    payData.setTransferPaymentCancelReason(parmPayCancelReason);
                    payData.setTransferMatchType(parmMatchTypeCode);
                    payData.setTransferMatchValue(saId.getTrimmedValue());
                    payData.setCanFreezePayment(Bool.FALSE);
                    payData.setTransferNonCisPayment(Bool.FALSE);
                    payData.setUseCurrentDateAsAccountingDate(Bool.TRUE);
                    transferPayment.transferPayment(payId, payData);

                    List<SQLResultRow> payIdListTransferAssigned = retreiveTransferPayId();
                    for(SQLResultRow resultRow1: payIdListTransferAssigned) {
                        payId = resultRow1.getEntity(PAYMENT_ID, Payment.class);

                        PaymentCharacteristic_DTO payCharacteristicDto = payId.getCharacteristics().newChildDTO();
                        CharacteristicTypeLookup paymentCharLookup = parmPledgePaymentCharType.getCharacteristicType();
                        if(paymentCharLookup.isAdhocValue()){
                            payCharacteristicDto.setAdhocCharacteristicValue(parmPledgePaymentCharValue);
                        } else if (paymentCharLookup.isPredefinedValue()){
                            payCharacteristicDto.setCharacteristicValue(parmPledgePaymentCharValue);
                        } else if (paymentCharLookup.isForeignKeyValue()){
                            payCharacteristicDto.setCharacteristicValueForeignKey1(parmPledgePaymentCharValue);
                        }

                        BigInteger seq = BigInteger.valueOf(payId.getCharacteristics().size()+1).multiply(BigInteger.TEN);
                        payId.getCharacteristics().add(payCharacteristicDto, parmPledgePaymentCharType.getId(), seq);

                        PaymentOnlineDriverParameters pod = PaymentOnlineDriverParameters.Factory.newInstance();
                        Payment_DTO payDto = payId.getDTO();
                        pod.setPayment(payId);
                        pod.setPaymentAction(ActionFlagLookup.constants.FREEZE);
                        payDto.getEntity().freezePayment(pod);

                        saPayOffBal = saId.getEntity().getPayoffBalance();
                        if(saPayOffBal.isNegative()){
                            createToDoEntry(payEventId.getTrimmedValue(), account.getId(), payEventId.getEntity().getCreationDateTime().toString());
                        }
                    }
                }

                List<SQLResultRow> serviceTaskIdList = retrieveServiceTask(pledgeId);
                for(SQLResultRow resultRow2: serviceTaskIdList){
                    ServiceTask svcTask =  resultRow2.getEntity(SERVICETASK_ID, ServiceTask.class);
                    startChanges();
                    ServiceTask_DTO svcTaskdto = svcTask.getDTO();
                    svcTaskdto.setStatus(parmPledgePaidStatus);
                    svcTask.setDTO(svcTaskdto);
                    saveChanges();

                    ServiceTaskCharacteristic_DTO svcTaskCharDto = svcTask.getCharacteristics().newChildDTO();
                    CharacteristicTypeLookup svcTaskCharLookup = parmTransIdCharType.getCharacteristicType();
                    if(svcTaskCharLookup.isAdhocValue()){
                        svcTaskCharDto.setAdhocCharacteristicValue(transactionId);
                    } else if (svcTaskCharLookup.isPredefinedValue()){
                        svcTaskCharDto.setCharacteristicValue(transactionId);
                    } else if (svcTaskCharLookup.isForeignKeyValue()){
                        svcTaskCharDto.setCharacteristicValueForeignKey1(transactionId);
                    }
                    BigInteger sequence = BigInteger.valueOf(svcTask.getCharacteristics().size()+1).multiply(BigInteger.TEN);
                    svcTask.getCharacteristics().add(svcTaskCharDto, parmTransIdCharType.getId(), sequence);
                }

            }
            numberOfRecordsProcessed = numberOfRecordsProcessed.add(BigInteger.ONE);
            closeFile();
        }

        /**
         * @return void 
         *  This method creates Todo.
         * 
         */
        private void createToDoEntry(String payEventStr, Account_Id payeeAcctId, String createDtStr){
            ToDoEntry_DTO entryDto  = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
            ToDoType toDoType = parmTodoTypePledgePayment.getId().getEntity();
            entryDto.setToDoTypeId(toDoType.getId());
            entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
            entryDto.setToDoPriority(toDoType.getToDoPriority());
            entryDto.setToDoRoleId(getDefaultToDoRole().getId());
            entryDto.setCreationDateTime(getProcessDateTime());
            entryDto.setToDoPriority(toDoType.getToDoPriority());
            entryDto.setBatchControlId(getBatchControlId());
            entryDto.setBatchNumber(getBatchNumber());
            MessageCategory_Id msgCatId = new MessageCategory_Id(BigInteger.valueOf(CustomMessageRepository.MESSAGE_CATEGORY));
            Message_Id msgId = new Message_Id(msgCatId, BigInteger.valueOf(CustomMessageRepository.NI0026_7_INVALID_PAYEE_ACCT_ID));
            entryDto.setMessageId(msgId);

            ArrayList<ToDoSortKeyValue_DTO>sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();
            ToDoTypeSortKeyTypes sortKeyTypes = toDoType.getSortKeyTypes();

            for (Iterator<ToDoSortKeyType> iter = sortKeyTypes.iterator(); iter.hasNext();) {
                ToDoSortKeyType sortKeyType = (ToDoSortKeyType) iter.next();
                ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
                BigInteger seq = sortKeyType.fetchIdSequence();
                sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));

                if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(1))==0){
                    sortKeyDto.setKeyValue(createDtStr.toString());
                }
                sortKeyList.add(sortKeyDto);
            }

            ArrayList<ToDoDrillKeyValue_DTO>drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
            ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO)     createDTO(ToDoDrillKeyValue.class);
            ToDoDrillKeyType drillKeyType = (ToDoDrillKeyType) toDoType.getDrillKeyTypes().iterator().next();
            BigInteger sequence = drillKeyType.fetchIdSequence();
            drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, sequence));

            drillKeyDto.setKeyValue(payEventStr);
            drillKeyList.add(drillKeyDto);

            ArrayList <String> messageParameterList = new ArrayList<String> ();
            messageParameterList.add(0,payeeAcctId.getTrimmedValue());
            messageParameterList.add(1,payEventStr);
            ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory.newInstance();

            toDoEntryData.setDrillKeys(drillKeyList);
            toDoEntryData.setEntryDto(entryDto);
            toDoEntryData.setSortKeys(sortKeyList);
            toDoEntryData.setMessageParams(messageParameterList);
            ArrayList <ToDoEntryCharacteristic_DTO>  charList = new ArrayList<ToDoEntryCharacteristic_DTO> ();
            toDoEntryData.setToDoCharacteristics(charList);

            ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
            toDoProcessor.addToDo(toDoEntryData);
        }

        /**
         * @return Role 
         * This method fetches the Default Role to create a TODO
         * 
         */ 
        private Role getDefaultToDoRole(){
            Role defaultRole = null;
            StringBuilder defaultRoleQueryString = new StringBuilder();
            defaultRoleQueryString.append("SELECT ROLE_ID FROM CI_TD_VAL_ROLE WHERE TD_TYPE_CD = :toDoType AND DEFAULT_SW = :yes ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement defaultRolePrepStmt = createPreparedStatement(defaultRoleQueryString.toString());
            PreparedStatement defaultRolePrepStmt = createPreparedStatement(defaultRoleQueryString.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            defaultRolePrepStmt.bindId("toDoType", parmTodoTypePledgePayment.getId()); 
            defaultRolePrepStmt.bindBoolean("yes", Bool.TRUE);
            defaultRole = defaultRolePrepStmt.firstRow().getEntity("ROLE_ID", Role.class);
            defaultRolePrepStmt.close();
            return defaultRole;
        }

        /**
         * This method opens a buffered reader for input file
         *
         */
        private void openFile() {
            try {                          
                inputBufferReader = new BufferedReader(new FileReader(inputFile));                    
            } catch (IOException e) {                
                throw new RunAbortedException(CustomMessageRepository.ni0026_7ErrorInFile(e.getMessage().trim()));                                     
            } 
        }

        /**
         * This method closes a buffered reader for input file
         *
         */
        private void closeFile() {
            try {
                if(notNull(inputBufferReader))
                    inputBufferReader.close();           
            } catch (IOException e) {
                throw new RunAbortedException(CustomMessageRepository.ni0026_7ErrorInFile(e.getMessage().trim()));                                      
            }
        }   

        /**
         * This method handles Max Error handling
         */
        private void maxErrorHandling() {
            numberOfRecordsInError = numberOfRecordsInError.add(BigInteger.ONE);

            if (notNull(parmMaxErrors)) {
                if (numberOfRecordsInError.intValue() >= parmMaxErrors.intValue()) {
                    throw new RunAbortedException(CustomMessageRepository.ni0026_7MaxErrorCountReached(parmMaxErrors.toString()));
                }
            }
        } 

        /**
         * This method returns the next record from the input file.
         * @return a String object.
         */
        private String readRecord() {
            String record = null;
            try {
                record =  inputBufferReader.readLine();                 
            } catch (IOException exception) {

                throw new RunAbortedException(CustomMessageRepository.ni0026_7ErrorInFile(exception.getMessage().trim()));
            }  
            return record;
        }

        private List<SQLResultRow> retrievePayId(){
            List<SQLResultRow> resultList = null;
            StringBuilder getPayIdQuery = new StringBuilder();
            getPayIdQuery.append("SELECT PAY_ID FROM CI_PAY P ") ;
            getPayIdQuery.append("WHERE P.PAY_EVENT_ID = :paymentEventIdFromFile ");
            getPayIdQuery.append("AND P.PAY_STATUS_FLG != :paymentStatusFlagCancelled ");
            getPayIdQuery.append("AND NOT EXISTS (SELECT 'X' FROM CI_PAY_CHAR WHERE PAY_ID = P.PAY_ID ");
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //getPayIdQuery.append("AND CHAR_TYPE_CD = :pledgePaymentCharType AND TRIM(CHAR_VAL) = :pledgePaymentCharValue) ");
            getPayIdQuery.append("AND CHAR_TYPE_CD = :pledgePaymentCharType AND CHAR_VAL = :pledgePaymentCharValue) ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement payIdPrepStmt = createPreparedStatement(getPayIdQuery.toString());
            PreparedStatement payIdPrepStmt = createPreparedStatement(getPayIdQuery.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            
            payIdPrepStmt.bindId("paymentEventIdFromFile", payEventId);
            payIdPrepStmt.bindLookup("paymentStatusFlagCancelled", PaymentStatusLookup.constants.CANCELED);
            payIdPrepStmt.bindEntity("pledgePaymentCharType", parmPledgePaymentCharType);
            payIdPrepStmt.bindStringProperty("pledgePaymentCharValue", PaymentCharacteristic.properties.adhocCharacteristicValue, parmPledgePaymentCharValue.trim());

            resultList = payIdPrepStmt.list();
            payIdPrepStmt.close();
            return resultList;
        }

        private List<SQLResultRow> retrieveServiceTask(String svcTaskPledgeIdCharVal){
            List<SQLResultRow> resultList = null;
            StringBuilder getServiceTaskIdQuery = new StringBuilder();
            getServiceTaskIdQuery.append("SELECT TASK.F1_SVC_TASK_ID, BO_STATUS_CD, ");
            getServiceTaskIdQuery.append("CH.ADHOC_CHAR_VAL FROM F1_SVC_TASK TASK, F1_SVC_TASK_CHAR CH ");
            getServiceTaskIdQuery.append("WHERE TASK.F1_SVC_TASK_ID = CH.F1_SVC_TASK_ID ");
            getServiceTaskIdQuery.append("AND CH.CHAR_TYPE_CD = :pledgeIdCharType ");
            getServiceTaskIdQuery.append("AND TRIM(CH.ADHOC_CHAR_VAL) = :pledgeIdCharVal ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement taskIdPrepStmt = createPreparedStatement(getServiceTaskIdQuery.toString());
            PreparedStatement taskIdPrepStmt = createPreparedStatement(getServiceTaskIdQuery.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            
            taskIdPrepStmt.bindId("pledgeIdCharType", parmPledgeIdCharType.getId());
            taskIdPrepStmt.bindStringProperty("pledgeIdCharVal", ServiceTaskCharacteristic.properties.adhocCharacteristicValue, svcTaskPledgeIdCharVal.trim());
            resultList = taskIdPrepStmt.list();
            if(resultList.isEmpty()){
                logError(CustomMessageRepository.ni0026_7ServiceTaskListNotFound(svcTaskPledgeIdCharVal.toString()));
                maxErrorHandling();
            }
            taskIdPrepStmt.close();
            return resultList;
        }

        private List<SQLResultRow> retreiveTransferPayId(){
            List<SQLResultRow> resultList = null;
            StringBuilder getPaymentIdQuery = new StringBuilder();
            getPaymentIdQuery.append("SELECT PAY_ID FROM CI_PAY P ") ;
            getPaymentIdQuery.append("WHERE P.PAY_EVENT_ID = :paymentEventIdFromFile ");
            getPaymentIdQuery.append("AND P.PAY_STATUS_FLG = :paymentStatusFlagFreezable ");
            getPaymentIdQuery.append("AND P.ACCT_ID = :acctId ");
            getPaymentIdQuery.append("AND P.MATCH_TYPE_CD = :matchTypeCode ");
            getPaymentIdQuery.append("AND TRIM(P.MATCH_VAL) = :matchValue ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement paymentIdPrepStmt = createPreparedStatement(getPaymentIdQuery.toString());
            PreparedStatement paymentIdPrepStmt = createPreparedStatement(getPaymentIdQuery.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            
            paymentIdPrepStmt.bindId("paymentEventIdFromFile", payEventId);
            paymentIdPrepStmt.bindLookup("paymentStatusFlagFreezable", PaymentStatusLookup.constants.FREEZABLE);
            paymentIdPrepStmt.bindId("acctId", account.getId());
            paymentIdPrepStmt.bindEntity("matchTypeCode", parmMatchTypeCode);
            paymentIdPrepStmt.bindStringProperty("matchValue", Payment.properties.matchValue, saId.getTrimmedValue());

            resultList = paymentIdPrepStmt.list();
            paymentIdPrepStmt.close();
            return resultList;
        }
    }
}