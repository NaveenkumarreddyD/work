/*
 ***********************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NI0019.4 - Remittance File Processing
 *
 ***********************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-03-07   Rakesh          NI0019.4. Initial Version.
 * 2013-03-19	Karthik			TIR1_NI0019.4 - changes made to log message instead of  
 * 								adding an error and terminating the entire process.
 * 								Included check for blank along with null check.
 * 								Also passed customer address as MICR CD.
 * 2013-03-27	Karthik			Replaced notNull() check on String variables with 
 * 								"!isBlankOrNull()"
 * 2013-04-03	Karthik			kl20130403 - Defect Fix - Partial file  
 * 								is processed, which should not happen. Also added logic 
 * 								to error out if file has been partially processed.
 * 2013-04-17	Karthik			KL20130417 - Modified logMessage to addError as file should
 * 								not be processed (partial commit) if there is an error.
 * 2013-04-26	Karthik			KL20130426 - Fix for Defect 700
 * 								Modified logic to process no data file.
 * 2013-05-20	Karthik			KL20130520 - Fixes for Defects #1230 & #1466
 * 2013-05-24	Karthik			KL20130523 - NI0019.4 - Defect fix for #1474. Deposit & Tender
 * 								Controls not created for duplicate payments. Also added a new
 * 								message to batch run tree to show total amount presented in the
 * 								remittance file and total amount processed excluding duplicates.
 * 2013-05-29	Karthik			KL20130529 - Updating the Tender Control Staging with the 
 * 								actual no of records processed excluding duplicates
 * 2013-06-03	Karthik			KL20130603 - Fix for Defect #1808 - Right paded input SA Type 
 * 								parameter with spaces to match the datebase value. 
 * 								Implemented CR (Defect #1433) - to include a new input boolean 
 * 								parameter to indicate processing of non-unique Ext. Payment Ids 
 * 								only for US Bank (EDI Process) and to update the characteristic 
 * 								value on the Payment Event Characteristic created for 
 * 								already processed real-time payments with the current Remittance 
 * 								file date and batch code. Also removed the existing input parm
 * 								Real-time Char Value
 * 2015-03-03   SMiran          MGE-CCB031. 
 * 								- Use single Tender Source for each Bank/Payment Vendor (Populate
 * 								EXT_SOURCE_ID with BANK-NAME from file header)
 * 								- Create only 1 Deposit Control for the remittance file.
 * 2015-04-13	JHERNA			Defect#3201381: Change CIS Division parameters to be optional.
 * 2015-06-22	SMiran			Defect 3238863. Do not delete deposit control
 * 2015-07-29   SMiran			Defect 3261619. Use totalFileAmountProcessed (Amount actually
 * 								processed) as Deposit Control Amount 
 * 2015-08-17	JHERNA			Defect#3279010 update code so that if the account does not have
 * 								a cis division, a message will be simply logged and Dollar Help
 * 								SA will not be created for the account without CIS Division.
 * 2015-12-10	JHERNA			SysAid#73195. Performance Issue. Remove use of TRIM functions
 * 								on SQL as it is unnecessary.
 * 2016-01-07 	DHuynh			SA:55473 Stop error 'Error in put file - Tender Control Total 
 * 								Amount field missing' when the whole payment file already post by 								
 * 2016-02-18   MPang			Updated for CCB v2.4 compilation.
 * 2016-01-18   JHERNA          Merged with PWC code 7144.
 * 2016-03-04   JHERNA          SysAid#88622: Payment Upload issues. There is a possibility that
 *                              the deposit control staging's expected Total Tender Control Count
 *                              does not match the actualy total Tender Control Counts due to   
 *                              possibility that some payments in the input already exists in 
 *                              CC&B and will be skipped.       
 * 2024-12-18   CAtilano		E-09921 - INC0046297 - Missouri Commerce Lockbox Payments are not recording the money order ID number                            
 ***********************************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.CopyOptionForProposalSALookup;
import com.splwg.ccb.api.lookup.CustomerReadLookup;
import com.splwg.ccb.api.lookup.DepositControlStagingStatusLookup;
import com.splwg.ccb.api.lookup.PaymentTenderStagingStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.StartReasonLookup;
import com.splwg.ccb.api.lookup.TenderControlStatusLookup;
//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.CisDivision_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.tenderSource.TenderSource;
import com.splwg.ccb.domain.admin.tenderType.TenderType_Id;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCreator;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCreatorData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementRecurringCharge;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementRecurringCharge_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.DepositControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.DepositControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.DepositControlStaging_Id;
import com.splwg.ccb.domain.payment.depositControlStaging.TenderControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.TenderControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.TenderControlStaging_Id;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentTender;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentTenderCharacteristic;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentTenderCharacteristic_DTO;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentTenderCharacteristic_Id;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentTenderCharacteristics;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentTender_Id;
import com.splwg.ccb.domain.payment.paymentTenderUpload.PaymentTenderUpload_DTO;
import com.splwg.ccb.domain.payment.paymentTenderUpload.PaymentTenderUpload_Id;*/
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource;
import com.splwg.ccb.domain.admin.tenderType.entity.TenderType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.common.ServiceAgreementCreator;
import com.splwg.ccb.domain.customerinfo.data.ServiceAgreementCreatorData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementRecurringCharge;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementRecurringCharge_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging_Id;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging_Id;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentTender;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentTenderCharacteristic;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentTenderCharacteristic_DTO;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentTenderCharacteristic_Id;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentTenderCharacteristics;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentTender_Id;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentTenderUpload_DTO;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentTenderUpload_Id;
//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.api.lookup.CmPaymentTypeLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.StringUtilities;


/**
 *
 @BatchJob (
 *      modules = {},    
 *      multiThreaded = false, 
 *      rerunnable = true,
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = DOLLAR_HELP_SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = cisDivision,name = DOLLAR_HELP_CIS_DIVISION, type = entity)
 *            , @BatchJobSoftParameter (name = REAL_TIME_CHAR_TYPE, required = true, type = entity, entityName = characteristicType)
 *            , @BatchJobSoftParameter (name = DOLLAR_HELP_FEATURE_CONFIG, required = true, type = string)
 *            , @BatchJobSoftParameter (name = IS_US_BANK_EDI_FILE, required = true, type = boolean)})
 */
public class CmPaymentUpload_BatchProcess 
		extends CmPaymentUpload_BatchProcess_Gen {

	/* KL20130603 - Start of Defect #1808
	 * Accessing the input parameters as local variables in the outer class 
	 * and making them as global variables within the inner class
	 * to prevent residual values issue. 
	// Soft Parameters
	private static String parmFilePath;
	private static String parmFileName;
	private static BigInteger parmMaxErrors = null;
	private static File inputFile = null;
	private static String parmSAType;
	private static CisDivision parmCisDivision;
	private static CharacteristicType parmRealTimeCharType;
	private static String parmRealTimeCharValue;
	private static String parmDollarHelpfeatureConfig;
	private static ServiceAgreementType_Id saTypeId = null;
	 */


	public JobWork getJobWork() {
		ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
		arrayList.add(threadWorkUnit);

		return createJobWorkForThreadWorkUnitList(arrayList);

	}

	public Class<CmPaymentUpload_BatchProcessWorker> getThreadWorkerClass() {
		return CmPaymentUpload_BatchProcessWorker.class;
	}

	public void validateSoftParameters(boolean arg0){

		// KL20130603 - Start of change for CR / Defect #1433
		String parmFilePath;
		String parmFileName;
		//BigInteger parmMaxErrors = null;
		File inputFile = null;
		String parmSAType;
		CisDivision parmCisDivision;
		CharacteristicType parmRealTimeCharType;
		//String parmRealTimeCharValue;
		String parmDollarHelpfeatureConfig;
		ServiceAgreementType_Id saTypeId = null;
		// not required to validate is_US_EDI_FILE as the framework handles it.

		/* Validation on max Errors is not required as this is a file processing and should not process even if 1 error exist.
		parmMaxErrors = getParameters().getMAX_ERRORS();
		// Validates Max Error soft parameter
		if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
			addError(CustomMessageRepository.ni0019_4MaxErrorCannotBeLessThanZero(parmMaxErrors.toString().trim())); 
		} 
		*/
		//KL20130603 - End of change for CR / Defect #1433
		
		// Validate that the file path.
		parmFilePath  = getParameters().getFILE_PATH().trim();
		File folder = new File(parmFilePath);
		if(!(folder.exists() && folder.isDirectory())) {
			addError(CustomMessageRepository.ni0019_4InvalidFilePath(parmFilePath));  
		}

		//Validate that the parameter FILE-NAME is a correct file name and that the corresponding file can be opened and read.
		parmFileName = getParameters().getFILE_NAME().trim();
		inputFile = new File(parmFilePath, parmFileName);
		if(!inputFile.exists() || !inputFile.canRead()){
			addError(CustomMessageRepository.ni0019_4InvalidFileName(parmFileName)); 
		} 

		parmSAType = getParameters().getDOLLAR_HELP_SA_TYPE();
		// START CHANGES - JHERNA - 2015-04-13 - DEFECT#3201381
		/*
		parmCisDivision = getParameters().getDOLLAR_HELP_CIS_DIVISION();
		saTypeId = new ServiceAgreementType_Id(parmCisDivision,parmSAType);
		if(isNull(saTypeId.getEntity())){
			addError(CustomMessageRepository.ni0019_4InvalidServiceAgreementType(parmSAType,parmCisDivision.getId().getIdValue().trim()));   
		}
		*/
		parmCisDivision = getParameters().getDOLLAR_HELP_CIS_DIVISION();
		if (notNull((parmCisDivision))) {		
			saTypeId = new ServiceAgreementType_Id(parmCisDivision,parmSAType);
			if(isNull(saTypeId.getEntity())){
				addError(CustomMessageRepository.ni0019_4InvalidServiceAgreementType(parmSAType,parmCisDivision.getId().getIdValue().trim()));   
			}			
		}
		// END CHANGES - JHERNA - 2015-04-13 - DEFECT#3201381

		parmRealTimeCharType = getParameters().getREAL_TIME_CHAR_TYPE();
		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(parmRealTimeCharType, CharacteristicEntityLookup.constants.PAYMENT_TENDER);
		if (isNull(charEntityId.getEntity())){
			addError(CustomMessageRepository.ni0019_4InvalidInputCharTypeForEntity(parmRealTimeCharType.getId().getTrimmedValue()));
		} 

		/*
		 * KL20130603 - Start of changes for CR / Defect #1433
		 * 
		 * Per the CR, input parm Real-time char value is replaced by (filename,batchnumber) as the char value
		 * 
		parmRealTimeCharValue = getParameters().getREAL_TIME_CHAR_VALUE();
		CharacteristicValue_Id charValueId = new CharacteristicValue_Id(new CharacteristicType_Id(parmRealTimeCharType.getId().getIdValue()),parmRealTimeCharValue);
		if (isNull(charValueId.getEntity())){
			addError(CustomMessageRepository.ni0019_4InvalidInputCharValue(parmRealTimeCharValue.trim(), parmRealTimeCharType.getId().getTrimmedValue()));
		}
		 */
		
		parmDollarHelpfeatureConfig = getParameters().getDOLLAR_HELP_FEATURE_CONFIG();
		FeatureConfiguration_Id recurringChargeId = new FeatureConfiguration_Id(parmDollarHelpfeatureConfig);
		if(isNull(recurringChargeId.getEntity())){
			addError(CustomMessageRepository.ni0019_4InvalidDollarHelpFeatureConfiguration(parmDollarHelpfeatureConfig));
		}
	}


	public static class CmPaymentUpload_BatchProcessWorker 
			extends CmPaymentUpload_BatchProcessWorker_Gen {

		private static final int RECORD_TYPE_INDEX = 0;
		private static final int RECORD_TYPE_LENGTH = 1;
		private static final String DATETIME_FORMAT_MMDDYYYYHHMMSS = "MMddyyyy HHmmss"; 
		//kl20130403 - Fix for Defect - partial file was being committed which should not happen
		//private static final String SAVE_POINT = "SAVE POINT";

		// Constants
		private final String CONST_FILE_HEADER_RECORD_TYPE = "A";
		private final String CONST_BATCH_HEADER_RECORD_TYPE = "B";
		private final String CONST_DETAIL_RECORD_TYPE = "C";
		private final String CONST_BATCH_TRAILER_RECORD_TYPE = "D";
		private final String CONST_FILE_TRAILER_RECORD_TYPE = "E";
		//KL20130603 - Start of change for Defect #1808
		private final int SA_TYPE_FIELD_LENGTH = 8;
		// End of change - for Defect #1808

		//CONSTANT NAMES
		private static final String CONST_RECORD_TYPE = "RECORD TYPE";
		private static final String CONST_FILE_DATE = "FILE DATE";
		// 2015-03-03 SMiran MGE-CCB031 Start Add
		private static final String CONST_BANK_NAME = "BANK NAME";
		// 2015-03-03 SMiran MGE-CCB031 End Add
		private static final String CONST_BATCH_NUM = "BATCH NUMBER";
		private static final String CONST_ACCOUNT_ID = "ACCOUNT ID";
		private static final String CONST_PAY_TYPE  = "PAY TYPE CODE";
		private static final String CONST_AMOUNT_PAID = "AMOUNT PAID";
		private static final String CONST_CHECK_NUMBER = "CHECK NUMBER";
		private static final String CONST_ITEM_COUNT = "BATCH ITEM COUNT";
		private static final String CONST_DEP_AMT = "BATCH DEPOSIT AMOUNT";
		private static final String CONST_BATCH_COUNT = "BATCH COUNT";
		private static final String CONST_FILE_DEP_AMT = "TOTAL DEPOSIT AMOUNT";

		//KL20130603 - Start of change for CR / Defect #1433
		// Soft Parameters
		private String parmFilePath;
		private String parmFileName;
		private File inputFile = null;
		private String parmSAType;
		private CisDivision parmCisDivision;
		private ServiceAgreementType_Id saTypeId = null;
		private CharacteristicType parmRealTimeCharType;
		private String parmDollarHelpfeatureConfig;
		private Bool parmIsUSBankEDIFile = Bool.FALSE;
		
		private final int SEQ_NUM_LENGTH = 5;
		private final String HYPHEN = "-";
		private final String COMMA = ",";
		//KL20130603 - End of change for CR / Defect #1433

		//Record Length
		private final Integer FILE_HEADER_RECORD_LENGTH = 49;
		private final Integer BATCH_HEADER_RECORD_LENGTH = 42;
		private final Integer DETAIL_RECORD_LENGTH = 139;
		private final Integer BATCH_TRAILER_RECORD_LENGTH = 35;
		private final Integer FILE_TRAILER_RECORD_LENGTH = 52;

		//File Header Field Lengths
		private final Integer FILE_HEADER_START_FILE_DATE = 35-1;
		private final Integer FILE_HEADER_END_FILE_DATE = 15;
		
		// 2015-03-03 SMiran MGE-CCB031 Start Add
		private final Integer FILE_HEADER_START_BANK_NAME = 17-1;
		private final Integer FILE_HEADER_END_BANK_NAME = 17;		
		// 2015-03-03 SMiran MGE-CCB031 End Add
		
		//Batch Header Field Lengths
		private final Integer BATCH_HEADER_START_BATCH_NUMBER  = 2-1;
		private final Integer BATCH_HEADER_END_BATCH_NUMBER  = 5;

		//Detail Record Field Lengths
		private final Integer DETAIL_START_ACCOUNT_ID = 7-1;
		private final Integer DETAIL_END_ACCOUNT_ID = 10;
		private final Integer DETAIL_START_AMOUNT_PAID = 17-1;
		private final Integer DETAIL_END_AMOUNT_PAID = 10;
		private final Integer DETAIL_START_PAY_TYPE_CODE = 27-1;
		private final Integer DETAIL_END_PAY_TYPE_CODE = 1;
		private final Integer DETAIL_START_DOLLAR_HELP = 28-1;
		private final Integer DETAIL_END_DOLLAR_HELP = 2;
		private final Integer DETAIL_START_CHECK_NUMBER = 30-1;
		private final Integer DETAIL_END_CHECK_NUMBER = 10;      
		private final Integer DETAIL_START_EXT_PAYMENT_ID = 40-1;
		private final Integer DETAIL_END_EXT_PAYMENT_ID = 30;
		private final Integer DETAIL_START_CUSTOMER_NAME = 70-1;
		private final Integer DETAIL_END_CUSTOMER_NAME = 40;
		private final Integer DETAIL_START_CUSTOMER_ADDRESS = 110-1;
		private final Integer DETAIL_END_CUSTOMER_ADDRESS = 30;

		//Batch Trailer Field Lenghts
		private final Integer BATCH_TRAILER_START_BATCH_ITEM_COUNT = 7-1;
		private final Integer BATCH_TRAILER_END_BATCH_ITEM_COUNT = 5;
		private final Integer BATCH_TRAILER_START_BATCH_DEPOSIT_AMT = 12-1;
		private final Integer BATCH_TRAILER_END_BATCH_DEPOSIT_AMT = 12;

		//File Trailer Field Lengths
		private final Integer FILE_TRAILER_START_TOTAL_BATCH_COUNT = 17-1;
		private final Integer FILE_TRAILER_END_TOTAL_BATCH_COUNT = 4;
		private final Integer FILE_TRAILER_START_TOTAL_ITEM_COUNT = 21-1;
		private final Integer FILE_TRAILER_END_TOTAL_ITEM_COUNT = 6;
		private final Integer FILE_TRAILER_START_TOTAL_DEPOSIT_AMT = 27-1;
		private final Integer FILE_TRAILER_END_TOTAL_DEPOSIT_AMT = 14;

		//Switches to check the order of processing is right
		private Bool isFileHeaderRead = Bool.FALSE;
		private Bool isBatchHeaderRead = Bool.FALSE;
		//private Bool isBatchTrailerRead = Bool.FALSE;
		private Bool isFileTrailerRead = Bool.FALSE;

		//Working Variables
		private BufferedReader inputBufferReader = null;
		private BigInteger lineCounter = BigInteger.ZERO;
		private String fileDateStr = "";
		// 2015-03-03 SMiran MGE-CCB031 Start Add
		private String bankNameStr = "";
		// 2015-03-03 SMiran MGE-CCB031 End Add
		private DateTime fileDateTime;
		private String batchNumber;
		private BigDecimal batchAmountInFile = BigDecimal.ZERO;
		// KL20130523 - Start of fix for Defect #1474
		private BigDecimal batchAmountProcessed = BigDecimal.ZERO;
		private BigInteger batchRecordsProcessedCount = BigInteger.ZERO;
		private BigDecimal totalFileAmountProcessed = BigDecimal.ZERO;
		private boolean isTenderControlStagingCreatedForBatch = false;
		private TenderControlStaging_DTO tenderControlStagingDTO = null;
		// KL20130523 - End of fix for Defect #1474
		// 2015-03-03 SMiran MGE-CCB031 Start Delete
		//private BigInteger batchCount = BigInteger.ZERO;
		// 2015-03-03 SMiran MGE-CCB031 End Delete
		private int detailRecordsPerBatchCount = 0;
		private int batchTrailerRecordCount;
		private int totalBatchCount = 0;
		private int fileTrailerBatchCount;
		private int totalFileRecordCount = 0;
		private int fileTrailerRecordCount;
		private BigDecimal sumOfBatchAmountsInFile = BigDecimal.ZERO;
		private BigDecimal totalTenderAmount;	
		private BigInteger numberOfRecordsInError = BigInteger.ZERO;
		private BigInteger detailPerHeaderCnt = BigInteger.ZERO;
		private DepositControlStaging depositControlStaging;
		private TenderControlStaging tenderControlStaging;
		private TenderSource tenderSource;
		
        // START ADD - JHERNA - 2016-03-04 - 88622
        private int actualTenderControlStagingCount = 0;
        // END ADD - JHERNA - 2016-03-04 - 88622

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		/**
		 * Perform any initialization that must be done at the start of this thread processing work. 
		 * @param initializationPreviouslySuccessful - indicates that this method was called successfully called during some 
		 * prior execution, presumably because this is a restart situation.
		 * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
		 * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
		 * @see com.splwg.base.api.batch.ThreadWorker#initializeThreadWork(boolean) 
		 */
		public void initializeThreadWork(boolean initializationPreviouslySuccessful)
		throws ThreadAbortedException, RunAbortedException {
			//			openFile();
		}

		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
		throws ThreadAbortedException, RunAbortedException {

			// Start of change for CR / Defect #1433
			initializeInputParameters();
			// End of change for CR / Defect #1433
			processFile();

			//Log Total Number of Records Processed and Total Amount of Payment Processed
			logMessage(CustomMessageRepository.ni0019_4TotalNumberOfRecordsProcessed(String.valueOf(totalFileRecordCount)), MessageSeverityLookup.constants.INFORMATIONAL);
			logMessage(CustomMessageRepository.ni0019_4TotalPaymentAmountPresentedInFile(String.valueOf(sumOfBatchAmountsInFile)), MessageSeverityLookup.constants.INFORMATIONAL);  
			// KL20130523 - Start of fix for Defect #1474
			logMessage(CustomMessageRepository.ni0019_4TotalAmountActuallyProcessedInBatch(String.valueOf(totalFileAmountProcessed)), MessageSeverityLookup.constants.INFORMATIONAL);  
			// KL20130523 - End of fix for Defect #1474

			WorkUnitResult workUnitResult = new WorkUnitResult(true);
			workUnitResult.setUnitsProcessed(totalFileRecordCount);
			workUnitResult.setUnitsInError(numberOfRecordsInError.intValue());

			closeFile();
			return workUnitResult; 
		}

		// KL20130603 - Start of change for CR / Defect #1433
		/**
		 * Initializing the batch input parameters within the inner BatchProcessWorker class
		 * to avoid the static variable reinitialization issue
		 */
		private void initializeInputParameters(){
			parmFilePath  = getParameters().getFILE_PATH().trim();
			parmFileName = getParameters().getFILE_NAME().trim();
			inputFile = new File(parmFilePath, parmFileName);
			
			parmSAType = getParameters().getDOLLAR_HELP_SA_TYPE();
			parmCisDivision = getParameters().getDOLLAR_HELP_CIS_DIVISION();
			// START CHANGES - JHERNA - 2015-04-13 - DEFECT#3201381
			//saTypeId = new ServiceAgreementType_Id(parmCisDivision,parmSAType);
			if (notNull(parmCisDivision)) {
				saTypeId = new ServiceAgreementType_Id(parmCisDivision,parmSAType);
			}
			// END CHANGES - JHERNA - 2015-04-13 - DEFECT#3201381

			parmRealTimeCharType = getParameters().getREAL_TIME_CHAR_TYPE();
			parmDollarHelpfeatureConfig = getParameters().getDOLLAR_HELP_FEATURE_CONFIG();
			parmIsUSBankEDIFile = getParameters().getIS_US_BANK_EDI_FILE();
			
	        // START ADD - JHERNA - 2016-03-04 - 88622
            // initialize counter for total tender control staging record that was created
            actualTenderControlStagingCount = 0;
            // END ADD - JHERNA - 2016-03-04 - 88622
		}
		
		private void processFile(){

			// Open File to read detail records. 
			openFile();
			String detailRecord = null;
			//KLOGANATHA 20130327 - replaced notNull() with !isBlankOrNull() checks for String variables. 
			while(!isBlankOrNull(detailRecord = readRecord())){  

				//Increment line counter
				lineCounter = lineCounter.add(BigInteger.ONE);
				//kl20130403 - Fix for Defect - partial file was being committed which should not happen
				//setSavepoint(SAVE_POINT);

				try{
					processRecords(detailRecord);
				}catch(ApplicationError ae){
					//kl20130403 - Fix for Defect - partial file was being committed which should not happen
					//rollbackToSavepoint(SAVE_POINT);
					// TIR 4 - Included check for both Blank and Null values
					if(isBlankOrNull(ae.getServerMessage().getMessageText())){
						numberOfRecordsInError = numberOfRecordsInError.add(BigInteger.ONE);
						addError(CustomMessageRepository.ni0019_4ErrorInFile(ae.getMessage().trim()));  
					}else{
						numberOfRecordsInError = numberOfRecordsInError.add(BigInteger.ONE);
						addError(CustomMessageRepository.ni0019_4ErrorInFile(ae.getServerMessage().getMessageText().trim())); 
					}
				}
			}
			//kl20130403 - Added logic to error out if file has been partially processed
			// START CHANGES - JHERNA - 2016-01-18 - Merged with PWC code 7144
			//if(isFileTrailerRead.isFalse()){
			if(isFileTrailerRead.isFalse() && lineCounter.compareTo(BigInteger.ZERO)>0){
			// END CHANGES - JHERNA - 2016-01-18 - Merged with PWC code 7144
				lineCounter = lineCounter.add(BigInteger.ONE);
				addError(CustomMessageRepository.ni0019_4IncompleteRunDueToErrorInFile(lineCounter.toString()));  
			}
		}

		/**
		 * This Method will process each record present in the Payment file.
		 * @param detailRecord
		 */
		private void processRecords(String detailRecord){
			String recordType = getFieldValue(detailRecord,RECORD_TYPE_INDEX,RECORD_TYPE_LENGTH).trim();

			validateField(recordType, CONST_RECORD_TYPE, RECORD_TYPE_INDEX+1, RECORD_TYPE_INDEX+RECORD_TYPE_LENGTH);

			if(recordType.equalsIgnoreCase(CONST_FILE_HEADER_RECORD_TYPE)){
				processFileHeader(detailRecord);

			}else if(recordType.equalsIgnoreCase(CONST_BATCH_HEADER_RECORD_TYPE)){
				processBatchHeader(detailRecord);

			}else if(recordType.equalsIgnoreCase(CONST_DETAIL_RECORD_TYPE)){
				processDetailsRecord(detailRecord);

			}else if(recordType.equalsIgnoreCase(CONST_BATCH_TRAILER_RECORD_TYPE)){
				processBatchTrailer(detailRecord);

			}else if(recordType.equalsIgnoreCase(CONST_FILE_TRAILER_RECORD_TYPE)){
				processFileTrailer(detailRecord);

			}else{
				addError(CustomMessageRepository.ni0019_4InvalidRecordType(lineCounter.toString(), recordType));  
			}

		}

		/**
		 * This Method will process the File Header Record, to fetch and validate the file date.
		 * @param record
		 */
		private void processFileHeader(String record){

			if(isFileHeaderRead.isTrue()){
				addError(CustomMessageRepository.ni0019_4InvalidFileWithTwoFileHearderRecords());
			}
			if(record.length() < FILE_HEADER_RECORD_LENGTH.intValue()){
				addError(CustomMessageRepository.ni0019_4InvalidLengthForFileHeaderRecordInFile(lineCounter.toString()));
			}

			fileDateStr = getFieldValue(record, FILE_HEADER_START_FILE_DATE, FILE_HEADER_END_FILE_DATE).trim();
			validateField(fileDateStr, CONST_FILE_DATE, FILE_HEADER_START_FILE_DATE+1, FILE_HEADER_START_FILE_DATE+FILE_HEADER_END_FILE_DATE);

			// Deposit DateTime must be a valid DateTime.
			convertFileDateStringToDateTimeFormat(fileDateStr);
			
			// 2015-03-03. SMiran. MGE-CCB031 Start Add
			// Get Bank Name from File Header
			bankNameStr = getFieldValue(record, FILE_HEADER_START_BANK_NAME, FILE_HEADER_END_BANK_NAME).trim();
			validateField(bankNameStr, CONST_BANK_NAME, FILE_HEADER_START_BANK_NAME+1, FILE_HEADER_START_BANK_NAME+FILE_HEADER_END_BANK_NAME);
			
			// Get Tender Source of External Source (Bank Name)
			tenderSource = getTenderSource(bankNameStr); 
			if (isNull(tenderSource)){
				addError(CustomMessageRepository.ni0019_4TenderSourceNotFound(bankNameStr));                 
			}
			
			isFileAlreadyProcessed();
			
			//Create and insert Deposit Control Staging record
			startChanges();
			DepositControlStaging_Id depositControlStagingId = new DepositControlStaging_Id(bankNameStr, fileDateStr);                                                
			DepositControlStaging_DTO depositControlStagingDTO = depositControlStagingId.newDTO();                                                                                 
			depositControlStagingDTO.setDepositControlStagingStatus(DepositControlStagingStatusLookup.constants.PENDING);
			depositControlStagingDTO.setTransmissionDateTime(fileDateTime);                                                                       
			depositControlStagingDTO.setCurrencyId(tenderSource.getCurrency().getId());                                                           
			depositControlStagingDTO.setTenderControlTotalAmount(new Money(BigDecimal.ONE, tenderSource.getCurrency().getId())); 
			depositControlStagingDTO.setTotalTenderControl(BigInteger.ONE);   
			depositControlStaging = depositControlStagingDTO.newEntity();   
			saveChanges();
			
			// 2015-03-03. SMiran. MGE-CCB031 End Add			
			
			isFileHeaderRead = Bool.TRUE;
		}

		/**
		 * This Method will process the BAtch Header Record, to fetch and validate the Batch Number.
		 * @param record
		 */
		private void processBatchHeader(String record){

			//To check that the File Header is processed first.
			if(isFileHeaderRead.isFalse() || isFileTrailerRead.isTrue()){
				addError(CustomMessageRepository.ni0019_4InvalidRecordTypeOrder());  
			}
			if(isBatchHeaderRead.isTrue()){
				addError(CustomMessageRepository.ni0019_4BatchTrailerRecordMissing(lineCounter.toString(),batchNumber));
			}
			if(record.length() < BATCH_HEADER_RECORD_LENGTH.intValue()){
				addError(CustomMessageRepository.ni0019_4InvalidLengthForBatchHeaderRecordInFile(lineCounter.toString()));
			}

			batchNumber = getFieldValue(record, BATCH_HEADER_START_BATCH_NUMBER, BATCH_HEADER_END_BATCH_NUMBER);
			validateField(batchNumber, CONST_BATCH_NUM, BATCH_HEADER_START_BATCH_NUMBER+1, BATCH_HEADER_START_BATCH_NUMBER+BATCH_HEADER_END_BATCH_NUMBER);

			// 2015-03-03 SMiran MGE-CCB031 Start Delete
			//// Get Tender Source of External Source
			//tenderSource = getTenderSource(batchNumber.trim()); 
			//if (isNull(tenderSource)){
			//	addError(CustomMessageRepository.ni0019_4TenderSourceNotFound(batchNumber));                 
			//} 

			//isFileAlreadyProcessed();
			// 2015-03-03 SMiran MGE-CCB031 End Delete
			
			batchAmountInFile =  BigDecimal.ONE;  
			// KL20130523 - Start of fix for Defect #1474
			batchAmountProcessed = BigDecimal.ZERO;
			batchRecordsProcessedCount = BigInteger.ZERO;
			tenderControlStagingDTO = null;
			isTenderControlStagingCreatedForBatch = false;
			// KL20130523 - End of fix for Defect #1474
			// 2015-03-03 SMiran MGE-CCB031 Start Delete
			//batchCount = BigInteger.ONE;   
			// 2015-03-03 SMiran MGE-CCB031 End Delete
			detailRecordsPerBatchCount = 0;
			isBatchHeaderRead = Bool.TRUE;

			// 2015-03-03 SMiran MGE-CCB031 Start Delete
			//// 1.1.	Create and insert a Deposit Control staging record
			//Money totTenderCtlAmount = new Money(batchAmountInFile.toString(), tenderSource.getCurrency().getId() );

			//Create and insert Deposit Control Staging record
			//startChanges();
			//DepositControlStaging_Id depositControlStagingId = new DepositControlStaging_Id(batchNumber, fileDateStr);                                                
			//DepositControlStaging_DTO depositControlStagingDTO = depositControlStagingId.newDTO();                                                                                 
			//depositControlStagingDTO.setDepositControlStagingStatus(DepositControlStagingStatusLookup.constants.PENDING);
			//depositControlStagingDTO.setTransmissionDateTime(fileDateTime);                                                                       
			//depositControlStagingDTO.setCurrencyId(tenderSource.getCurrency().getId());                                                           
			//depositControlStagingDTO.setTenderControlTotalAmount(totTenderCtlAmount); 
			//depositControlStagingDTO.setTotalTenderControl(batchCount);   
			//depositControlStaging = depositControlStagingDTO.newEntity();   
			//saveChanges();
			// 2015-03-03 SMiran MGE-CCB031 End Delete
			
			//Create and insert a Tender Control staging record
			startChanges();
			TenderControlStaging_Id tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, batchNumber);                                             
			tenderControlStagingDTO = tenderControlStagingId.newDTO();
			tenderControlStagingDTO.setTenderControlStatus(TenderControlStatusLookup.constants.PENDING);
			// 2015-03-03 SMiran MGE-CCB031 Start Change
			//tenderControlStagingDTO.setTotalTendersAmount(totTenderCtlAmount);
			tenderControlStagingDTO.setTotalTendersAmount(new Money(BigDecimal.ONE, tenderSource.getCurrency().getId()));
			// 2015-03-03 SMiran MGE-CCB031 End Change			
			// KL20130523 - Start of fix for Defect #1474 - Moving the creation of Tender Control Staging to Detail Record Processing method.
			//tenderControlStaging = tenderControlStagingDTO.newEntity();   
			// KL20130523 - End of fix for Defect #1474
			saveChanges();

			// Reset count of detail records per header
			detailPerHeaderCnt = BigInteger.ZERO;
			batchAmountInFile =  BigDecimal.ZERO;  
		}

		/**
		 * This Method will process the Detail record present in the File.
		 * It will Fetch the Required Fields and validate them.
		 * It will create the Payment Staging records.
		 * @param record
		 */
		private void processDetailsRecord(String record){

			List<SQLResultRow> payTndrList;
			SQLResultRow payTndrRow = null;
			PaymentTender_Id payTndrId;
			TenderType_Id tenderTypeId = null;
			String payTypeCode;
			//			Account account =null;
			Boolean mandatoryValidation = true;
			PaymentTenderUpload_Id paymentTenderUploadId;
			Account validAccountWithDollarHelpSA;

			detailRecordsPerBatchCount++;

			//To check that the File & Batch Headers are processed first.
			if(isFileHeaderRead.isFalse() || isBatchHeaderRead.isFalse() || isFileTrailerRead.isTrue()){
				addError(CustomMessageRepository.ni0019_4InvalidRecordTypeOrder());  
			}
			if(record.length() < DETAIL_RECORD_LENGTH.intValue()){
				addError(CustomMessageRepository.ni0019_4InvalidLengthForDetailRecordInFile(lineCounter.toString()));
			}

			String extPayId = getFieldValue(record, DETAIL_START_EXT_PAYMENT_ID, DETAIL_END_EXT_PAYMENT_ID).trim();
			//Validation removed as FS Designer confirmed this as an optional field in file
			//mandatoryValidation = mandatoryValidation && validateDetailField(extPayId, CONST_EXT_PAY_ID, DETAIL_START_EXT_PAYMENT_ID+1, DETAIL_START_EXT_PAYMENT_ID+DETAIL_END_EXT_PAYMENT_ID);
			/**
			 * KL20130603 - Start of change for CR / Defect #1433
			 */
			if(!isBlankOrNull(extPayId) && parmIsUSBankEDIFile.isTrue()){
				extPayId = extPayId.trim() + HYPHEN + StringUtilities.leftPadWithZeros(String.valueOf(detailRecordsPerBatchCount), SEQ_NUM_LENGTH);
			}
			/**
			 * KL20130603 - End of change for CR / Defect #1433
			 */

			String amountPaidStr = getFieldValue(record, DETAIL_START_AMOUNT_PAID, DETAIL_END_AMOUNT_PAID).trim();
			mandatoryValidation = mandatoryValidation && validateDetailField(amountPaidStr, CONST_AMOUNT_PAID, DETAIL_START_AMOUNT_PAID+1, DETAIL_START_AMOUNT_PAID+DETAIL_END_AMOUNT_PAID);
			// KLOGANATHA001 - Using BigInteger to validate Number Format on 17-Mar-2013 and introducing a decimal point
			//Start of code change
			BigInteger inputAmount = checkAndConvertStringToBigInteger(amountPaidStr); //used to validate number format

			BigDecimal amount = new BigDecimal(inputAmount);

			if(amount.compareTo(BigDecimal.ZERO)!=0){
				amount = amount.divide(new BigDecimal(100), 2, BigDecimal.ROUND_FLOOR);
			}
			batchAmountInFile = batchAmountInFile.add(amount);
			//End of code change
			Money tenderAmount = new Money(amount,tenderSource.getCurrency().getId());

			String unmappedPayTypeCode = getFieldValue(record, DETAIL_START_PAY_TYPE_CODE, DETAIL_END_PAY_TYPE_CODE);
			mandatoryValidation = mandatoryValidation && validateDetailField(unmappedPayTypeCode, CONST_PAY_TYPE, DETAIL_START_PAY_TYPE_CODE+1, DETAIL_START_PAY_TYPE_CODE+DETAIL_END_PAY_TYPE_CODE);
			if(!isEmptyOrNull(unmappedPayTypeCode.trim())){
				String payTypeCodeVal = "X"+unmappedPayTypeCode;
				//KL20130530 - validate if the Pay Type Code is a valid Payment Type Lookup value.
				if(!LookupHelper.getLookupInstance(CmPaymentTypeLookup.class, payTypeCodeVal).isValidLookupValue()){
					addError(CustomMessageRepository.ni0019_4InvalidPayTypeCodeInFile(unmappedPayTypeCode, lineCounter.toString().trim()));
				}
				payTypeCode = retrieveFeatureConfig(payTypeCodeVal);
				tenderTypeId = new TenderType_Id(payTypeCode);
			}

			String accountIdStr = getFieldValue(record, DETAIL_START_ACCOUNT_ID, DETAIL_END_ACCOUNT_ID);
			mandatoryValidation = mandatoryValidation && validateDetailField(accountIdStr, CONST_ACCOUNT_ID, DETAIL_START_ACCOUNT_ID+1, DETAIL_START_ACCOUNT_ID+DETAIL_END_ACCOUNT_ID);
			// KL20130520 - Start - Defect Fix for #1466
			//if(!isBlankOrNull(accountIdStr)){
			//	account = retrieveAccount(accountIdStr);
			//}
			// KL20130520 - End - Defect Fix for #1466

			String customerName = getFieldValue(record, DETAIL_START_CUSTOMER_NAME, DETAIL_END_CUSTOMER_NAME);
			//validateField(customerName, CONST_CUST_NAME, DETAIL_START_CUSTOMER_NAME+1, DETAIL_START_CUSTOMER_NAME+DETAIL_END_CUSTOMER_NAME);

			String customerAddress = getFieldValue(record, DETAIL_START_CUSTOMER_ADDRESS, DETAIL_END_CUSTOMER_ADDRESS);
			//validateField(customerAddress, CONST_CUST_ADRS, DETAIL_START_CUSTOMER_ADDRESS+1, DETAIL_START_CUSTOMER_ADDRESS+CUST_ADRS_LENGTH);

			String dollarHelpInd = getFieldValue(record, DETAIL_START_DOLLAR_HELP, DETAIL_END_DOLLAR_HELP);
			//			mandatoryValidation = mandatoryValidation && validateDetailField(dollarHelpInd, CONST_DOLLAR_HELP, DETAIL_START_DOLLAR_HELP+1, DETAIL_START_DOLLAR_HELP+DETAIL_END_DOLLAR_HELP);

			String checkNumber = getFieldValue(record, DETAIL_START_CHECK_NUMBER, DETAIL_END_CHECK_NUMBER).trim();
			// Start change 2024-12-18   CAtilano		E-09921
			if(!isEmptyOrNull(unmappedPayTypeCode) && (Integer.parseInt(unmappedPayTypeCode) == 2	||	
					Integer.parseInt(unmappedPayTypeCode) == 3)	)				
			{
				mandatoryValidation = mandatoryValidation && validateDetailField(checkNumber, CONST_CHECK_NUMBER, DETAIL_START_CHECK_NUMBER+1, DETAIL_START_CHECK_NUMBER+DETAIL_END_CHECK_NUMBER);
			}
			// End change 2024-12-18   CAtilano		E-09921
			//			if(mandatoryValidation){
			//KLOGANATHA 20130327 - replaced notNull() with !isBlankOrNull() checks for String variables. 
			if(!isBlankOrNull(dollarHelpInd)){
				String strRecurringCharges = retrieveFeatureConfig("X"+dollarHelpInd);				
				// KL20130520 - Start - Defect Fix for #1466
				validAccountWithDollarHelpSA = retrieveAccount(accountIdStr);
				if(isNull(validAccountWithDollarHelpSA)){
					// Modified message severity to Error
					logMessage(CustomMessageRepository.ni0019_4AccountNotExists(lineCounter.toString()), MessageSeverityLookup.constants.ERROR);
				}
				else if(isEmptyOrNull(strRecurringCharges)){
					// Modified message severity to Error
					logMessage(CustomMessageRepository.ni0019_4InvalidRecurringChargeInFeatureConfig(dollarHelpInd), MessageSeverityLookup.constants.ERROR);
				}else{
					Money recurringCharge = new Money(strRecurringCharges,tenderSource.getCurrency().getId());
					ServiceAgreement dollarHelpSA = getDollarHelpSA(validAccountWithDollarHelpSA);
					if(isNull(dollarHelpSA)){
						//Create Dollar Help SA
						createSA(validAccountWithDollarHelpSA,fileDateTime.getDate(),recurringCharge);
					}else{
						addRecurringCharge(dollarHelpSA,fileDateTime.getDate(),recurringCharge);  
					}
				}
				// KL20130520 - End - Defect Fix for #1466
			}
			if(mandatoryValidation){
				// TIR 4 - Included check for both Blank and Null values
				// Defect 1230 - KL20130514: Modified the logic to process payments even if External Payment ID is not sent via Remittance File
				if(!(isBlankOrNull(extPayId))){
					payTndrList = retrievePaymentTender(extPayId);
					// Payment Tender already exists for this external reference id 
					if(!payTndrList.isEmpty()){
						for (Iterator<SQLResultRow> payTndrIter = payTndrList.iterator(); payTndrIter.hasNext();) {
							payTndrRow = (SQLResultRow) payTndrIter.next();
							payTndrId = (PaymentTender_Id) payTndrRow.getId("PAY_TENDER_ID",PaymentTender.class);
							// KL20130603 - Start of change for CR / Defect #1433
							//createCharOnPayTndr(payTndrId.getEntity() , parmRealTimeCharType, parmRealTimeCharValue);
							createCharOnPayTndr(payTndrId.getEntity());
							// KL20130603 - End of change for CR / Defect #1433
						}
						return;
					}
				}
				// Create and insert payment tender staging record
				detailPerHeaderCnt = detailPerHeaderCnt.add(BigInteger.ONE); 
				// KL20130523 - Start of fix for Defect #1474
				batchAmountProcessed = batchAmountProcessed.add(amount);
				batchRecordsProcessedCount = batchRecordsProcessedCount.add(BigInteger.ONE);
				if(!isTenderControlStagingCreatedForBatch && (BigDecimal.ZERO.compareTo(batchAmountProcessed)<0)){
					tenderControlStaging = tenderControlStagingDTO.newEntity();
					isTenderControlStagingCreatedForBatch = true;
					
	                // START ADD - JHERNA - 2016-03-04 - 88622
                    // Add 1 to the counter for actual tender control staging records created
                    actualTenderControlStagingCount++;
                    // END ADD - JHERNA - 2016-03-04 - 88622
				}
				// KL20130523 - Start of fix for Defect #1474

				try{
					// KL20130520 - Start - Defect Fix for #1466 - Payment Posting to Suspense Account should not be done by CM code.
					// Base PUPL Batch process will do the posting based on Tender Source Configuration
					//if(isNull(account)){ 
					//	account = tenderSource.getServiceAgreementId().getEntity().getAccount();
					//}
					// KL20130520 - End - Defect Fix for #1466

					startChanges();
					TenderControlStaging_Id tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, batchNumber);
					if(isBlankOrNull(extPayId)){
						paymentTenderUploadId = new PaymentTenderUpload_Id(tenderControlStagingId, lineCounter.toString());
					}else{
						paymentTenderUploadId = new PaymentTenderUpload_Id(tenderControlStagingId, extPayId.toString());
					}
					PaymentTenderUpload_DTO paymentTenderUploadDTO = paymentTenderUploadId.newDTO();                                                            
					paymentTenderUploadDTO.setPaymentTenderStagingStatus(PaymentTenderStagingStatusLookup.constants.PENDING);  
					paymentTenderUploadDTO.setTenderAmount(tenderAmount);               
					paymentTenderUploadDTO.setAccountingDate(getProcessDateTime().getDate());
					paymentTenderUploadDTO.setTenderTypeId(tenderTypeId);   
					if((Integer.parseInt(unmappedPayTypeCode) == 2) || (Integer.parseInt(unmappedPayTypeCode) == 3))				
					{
						paymentTenderUploadDTO.setCheckNumber(checkNumber.trim());
					}
					// KL20130520 - Start - Defect Fix for #1466
					//paymentTenderUploadDTO.setCustomerId(account.getId().getTrimmedValue());  
					paymentTenderUploadDTO.setCustomerId(accountIdStr);
					// KL20130520 - End - Defect Fix for #1466
					if(!isBlankOrNull(customerAddress)){
						paymentTenderUploadDTO.setMicrId(customerAddress);	
					}
					if(!isBlankOrNull(customerName)){
						paymentTenderUploadDTO.setName(customerName);
					}
					paymentTenderUploadDTO.newEntity();  
					saveChanges();

				}catch(ApplicationError ae){
					// KL20130417 - Modified logMessage to addError as the file should not be processed if there is an error
					addError(CustomMessageRepository.ni0019_4RecordInError(lineCounter.toString().trim(), ae.getServerMessage().getMessageText()));
				}
			}
		}

		/**
		 * This Method will fetch and validate the Batch Item Count, Batch Deposit Amount
		 * with the total number of records and total payment amount of records in the batch. 
		 * @param record
		 */
		private void processBatchTrailer(String record){

			//To Check that the File & Batch Headers are processed before processing the batch trailer.
			if(isFileHeaderRead.isFalse() || isBatchHeaderRead.isFalse() || isFileTrailerRead.isTrue()){
				addError(CustomMessageRepository.ni0019_4InvalidRecordTypeOrder()); 
			}
			// Setting isBatchHeaderRead to false so that the next batch header can validate if the previous batch was processed correctly.
			isBatchHeaderRead = Bool.FALSE;
			//KL20130521 - Defect fix for 1466
			//isBatchTrailerRead = Bool.TRUE;
			if(record.length() < BATCH_TRAILER_RECORD_LENGTH.intValue()){
				addError(CustomMessageRepository.ni0019_4InvalidLengthForBatchTrailerRecordInFile(lineCounter.toString()));
			}

			String batchItemCountStr = getFieldValue(record, BATCH_TRAILER_START_BATCH_ITEM_COUNT, BATCH_TRAILER_END_BATCH_ITEM_COUNT);
			validateField(batchItemCountStr, CONST_ITEM_COUNT, BATCH_TRAILER_START_BATCH_ITEM_COUNT+1, BATCH_TRAILER_START_BATCH_ITEM_COUNT+BATCH_TRAILER_START_BATCH_ITEM_COUNT);
			batchTrailerRecordCount = checkAndConvertStringToBigInteger(batchItemCountStr).intValue();
			if (batchTrailerRecordCount != detailRecordsPerBatchCount){
				addError(CustomMessageRepository.ni0019_4RecordCountInBatchTrailerAndTotalRecordCountIsNotSame(batchItemCountStr,String.valueOf(detailRecordsPerBatchCount), batchNumber)); 
			}

			String batchdepositAmountStr = getFieldValue(record, BATCH_TRAILER_START_BATCH_DEPOSIT_AMT, BATCH_TRAILER_END_BATCH_DEPOSIT_AMT);
			validateField(batchdepositAmountStr, CONST_DEP_AMT, BATCH_TRAILER_START_BATCH_DEPOSIT_AMT+1, BATCH_TRAILER_START_BATCH_DEPOSIT_AMT+BATCH_TRAILER_END_BATCH_DEPOSIT_AMT);
			BigInteger batchDepAmount = checkAndConvertStringToBigInteger(batchdepositAmountStr);
			totalTenderAmount = new BigDecimal(batchDepAmount);

			if(totalTenderAmount.compareTo(BigDecimal.ZERO)!=0){
				totalTenderAmount = totalTenderAmount.divide(new BigDecimal(100), 2, BigDecimal.ROUND_FLOOR);
			}
			if(batchAmountInFile.compareTo(totalTenderAmount) !=0){
				addError(CustomMessageRepository.ni0019_4AmountInBatchTrailerAndTotalAmountInRecordsNotSame(totalTenderAmount.toString(),batchAmountInFile.toString(), batchNumber)); 
			}

			String batchDepositCount = getFieldValue(record, BATCH_TRAILER_START_BATCH_ITEM_COUNT, BATCH_TRAILER_END_BATCH_ITEM_COUNT);
			validateField(batchDepositCount, CONST_BATCH_COUNT, BATCH_TRAILER_START_BATCH_ITEM_COUNT+1, BATCH_TRAILER_START_BATCH_ITEM_COUNT+BATCH_TRAILER_END_BATCH_ITEM_COUNT);

			totalBatchCount++;
			totalFileRecordCount = totalFileRecordCount + detailRecordsPerBatchCount;
			sumOfBatchAmountsInFile = sumOfBatchAmountsInFile.add(batchAmountInFile); 
			// KL20130523 - Start of fix for Defect #1474
			totalFileAmountProcessed = totalFileAmountProcessed.add(batchAmountProcessed);
			// 2015-06-22. SMiran. Defect 3238863. Start Delete
			//if(BigDecimal.ZERO.compareTo(batchAmountProcessed)==0){
			//	depositControlStaging.delete();
			//	return;
			//}
			// 2015-06-22. SMiran. Defect 3238863. End Delete
			// KL20130523 - End of fix for Defect #1474

			// 2015-03-03 SMiran MGE-CCB031 Start Delete
			////Update Deposit Control Amount
			//DepositControlStaging_DTO depositControlStagingDTO= depositControlStaging.getDTO();
			//// KL20130523 - Start of fix for Defect #1474 
			//// Only actual amount posted to system should be assigned to deposit & tender control leaving the duplicate entries 
			////depositControlStagingDTO.setTenderControlTotalAmount(new Money(totalTenderAmount.toString(),tenderSource.getCurrency().getId()));
			//depositControlStagingDTO.setTenderControlTotalAmount(new Money(batchAmountProcessed.toString(),tenderSource.getCurrency().getId()));
			//// KL20130523 - End of fix for Defect #1474
			//depositControlStaging.setDTO(depositControlStagingDTO);
			// 2015-03-03 SMiran MGE-CCB031 End Delete
			
			// 2015-06-22. SMiran. Defect 3238863. Start Add
			if (isTenderControlStagingCreatedForBatch){
			// 2015-06-22. SMiran. Defect 3238863. End Add
				TenderControlStaging_DTO  tenderControlStagingDTO = tenderControlStaging.getDTO();
				// KL20130523 - Start of fix for Defect #1474
				//tenderControlStagingDTO.setTotalTendersAmount(new Money(totalTenderAmount.toString(),tenderSource.getCurrency().getId()));
				tenderControlStagingDTO.setTotalTendersAmount(new Money(batchAmountProcessed.toString(),tenderSource.getCurrency().getId()));
				//tenderControlStagingDTO.setTotalNumberOfTender(BigInteger.valueOf(batchTrailerRecordCount));
				// KL20130529 - Updating the Tender Control Staging with the no of records processed excluding duplicates
				tenderControlStagingDTO.setTotalNumberOfTender(batchRecordsProcessedCount);
				tenderControlStaging.setDTO(tenderControlStagingDTO);
				// KL20130523 - End of fix for Defect #1474
			// 2015-06-22. SMiran. Defect 3238863. Start Add
			//2016-01-07 Dhuynh SA#55473 start
			}/*else{
				TenderControlStaging_DTO tenderControlStagingDto = createDTO(TenderControlStaging.class);
				TenderControlStaging_Id tcsId = new TenderControlStaging_Id(depositControlStaging, batchNumber);                                             
				tenderControlStagingDto.setId(tcsId);
				tenderControlStagingDto.setTenderControlStatus(TenderControlStatusLookup.constants.PENDING);
				tenderControlStagingDto.setTotalTendersAmount(new Money(BigDecimal.ZERO, tenderSource.getCurrency().getId()));
				tenderControlStagingDto.setTotalNumberOfTender(BigInteger.ZERO);
				tenderControlStagingDto.newEntity();
			}
			*/
			//2016-01-07 Dhuynh SA#55473 end
			// 2015-06-22. SMiran. Defect 3238863. End Add
		}

		/**
		 * This Method will fetch and validate the Batch Count, Deposit Amount and item count with the
		 * total number of batches, total number of records and total payment amount of records in the File. 
		 * @param record
		 */private void processFileTrailer(String record){

			 //To Check whether there are any unclosed batch records or the file and batch headers are processed first.
			 //KL20130426 - Fix for Defect 700: Removed Batch Header & trailer check to process no data file.
			 if(isFileHeaderRead.isFalse()){	
				 addError(CustomMessageRepository.ni0019_4InvalidRecordTypeOrder());  
			 }

			 if(isFileTrailerRead.isTrue()){	
				 addError(CustomMessageRepository.ni0019_4InvalidFileWithTwoFileTrailerRecords());  
			 }
			 isFileTrailerRead = Bool.TRUE;
			 if(record.length() < FILE_TRAILER_RECORD_LENGTH.intValue()){
				 addError(CustomMessageRepository.ni0019_4InvalidLengthForFileTrailerRecordInFile(lineCounter.toString()));
			 }

			 String fileTrailerBatchCountStr = getFieldValue(record, FILE_TRAILER_START_TOTAL_BATCH_COUNT, FILE_TRAILER_END_TOTAL_BATCH_COUNT);
			 validateField(fileTrailerBatchCountStr, CONST_BATCH_COUNT, FILE_TRAILER_START_TOTAL_BATCH_COUNT+1, FILE_TRAILER_START_TOTAL_BATCH_COUNT+FILE_TRAILER_END_TOTAL_BATCH_COUNT);
			 fileTrailerBatchCount = checkAndConvertStringToBigInteger(fileTrailerBatchCountStr).intValue();
			 if (totalBatchCount != fileTrailerBatchCount){
				 addError(CustomMessageRepository.ni0019_4BatchCountInFileTrailerAndTotalBatchCountIsNotSame(fileTrailerBatchCountStr, String.valueOf(totalBatchCount)));  
			 }

			 String fileTrailerRecordCountStr = getFieldValue(record, FILE_TRAILER_START_TOTAL_ITEM_COUNT, FILE_TRAILER_END_TOTAL_ITEM_COUNT);
			 validateField(fileTrailerRecordCountStr, CONST_ITEM_COUNT, FILE_TRAILER_START_TOTAL_ITEM_COUNT+1, FILE_TRAILER_START_TOTAL_ITEM_COUNT+FILE_TRAILER_END_TOTAL_ITEM_COUNT);
			 fileTrailerRecordCount = checkAndConvertStringToBigInteger(fileTrailerRecordCountStr).intValue();
			 if(fileTrailerRecordCount !=totalFileRecordCount){
				 addError(CustomMessageRepository.ni0019_4RecordCountInFileTrailerAndTotalRecordCountIsNotSame(fileTrailerRecordCountStr, String.valueOf(totalFileRecordCount))); 
			 }

			 String totalDepositAmountStr = getFieldValue(record, FILE_TRAILER_START_TOTAL_DEPOSIT_AMT, FILE_TRAILER_END_TOTAL_DEPOSIT_AMT);
			 validateField(totalDepositAmountStr, CONST_FILE_DEP_AMT, FILE_TRAILER_START_TOTAL_DEPOSIT_AMT+1, FILE_TRAILER_START_TOTAL_DEPOSIT_AMT+FILE_TRAILER_END_TOTAL_DEPOSIT_AMT);
			 checkAndConvertStringToBigInteger(totalDepositAmountStr);
			 BigDecimal totalDepositAmount = new BigDecimal(totalDepositAmountStr);

			 if(totalDepositAmount.compareTo(BigDecimal.ZERO)!=0){
				 totalDepositAmount = totalDepositAmount.divide(new BigDecimal(100), 2, BigDecimal.ROUND_FLOOR);
			 }

			 if(sumOfBatchAmountsInFile.compareTo(totalDepositAmount) != 0){
				 addError(CustomMessageRepository.ni0019_4AmountInFileTrailerAndTotalAmountInRecordsIsNotSame(totalDepositAmountStr, sumOfBatchAmountsInFile.toString())); 
			 }
			 //Update File Amount and count to Deposit control
			 // 2015-03-03 SMiran MGE-CCB031 Start Add
			 //2016-01-07 Dhuynh SA#55473 start
			 if (totalFileAmountProcessed.compareTo(BigDecimal.ZERO)== 1){	
			   DepositControlStaging_DTO depositControlStagingDTO= depositControlStaging.getDTO();
               // START ADD - JHERNA - 2016-03-04 - 88622
               /* Use the Actual number of tender control staging records created by this batch program instead of the total batch count from the input file.
                * Reasoning behind this is that there is a possibility that some of the batch of payments will not be created because all of the payments
                * on that specific batch is already posted on CC&B via Real Time Process.
               // Total Tender Controls on Deposit Control Staging is populated with the file trailer's TOTAL-BATCH-CNT
               depositControlStagingDTO.setTotalTenderControl(BigInteger.valueOf(fileTrailerBatchCount));
               */
               depositControlStagingDTO.setTotalTenderControl(BigInteger.valueOf(actualTenderControlStagingCount));
               // END ADD - JHERNA - 2016-03-04 - 88622
			   // 2015-07-29. SMiran. Defect 3261619. Start Change
			   //// Tender Control Total Amount on Deposit Control Staging is populated with the file trailer record's TOTAL-DEPOSIT-AMOUNT
			   //depositControlStagingDTO.setTenderControlTotalAmount(new Money(totalDepositAmount, tenderSource.getCurrency().getId()));			 
			   // Tender Control Total Amount on Deposit Control Staging is populated with totalFileAmountProcessed
			   depositControlStagingDTO.setTenderControlTotalAmount(new Money(totalFileAmountProcessed, tenderSource.getCurrency().getId()));
			   // 2015-07-29. SMiran. Defect 3261619. End Change			 
			   depositControlStaging.setDTO(depositControlStagingDTO);
			   // 2015-03-03 SMiran MGE-CCB031 End Add
			 }else{
				 depositControlStaging.delete(); 
			 }
			 //2016-01-07 Dhuynh SA#55473 end
		 }

		 /**
		  * This method opens a buffered reader for input file
		  *
		  */
		 private void openFile() {

			 try {                          
				 inputBufferReader = new BufferedReader(new FileReader(inputFile));                    
			 } catch (IOException e) {                
				 throw new RunAbortedException(CustomMessageRepository.ni0019_4ErrorInFile(e.getMessage().trim()));                                      
			 } 
		 }

		 /**
		  * This method closes a buffered reader for input file
		  *
		  */
		 private void closeFile() {

			 try {
				 if(notNull(inputBufferReader))
					 inputBufferReader.close();           
			 } catch (IOException e) {
				 throw new RunAbortedException(CustomMessageRepository.ni0019_4ErrorInFile(e.getMessage().trim()));                                        
			 }
		 }   

		 /**
		  * This method returns the next record from the input file.
		  * @return a String object.
		  */
		 private String readRecord() {

			 String record = null;
			 try {
				 record =  inputBufferReader.readLine();                 
			 } catch (IOException exception) {
				 throw new RunAbortedException(CustomMessageRepository.ni0019_4ErrorInFile(exception.getMessage().trim()));  
			 }  
			 return record;
		 }

		 /**
		  * This method retrieves the trimmed field value from the record starting 
		  * from the startPos and of the given length.
		  * @param record
		  * @param startPos
		  * @param length
		  * @return
		  */private String getFieldValue(String record, int startPos, int length) {

			  String value = "";
			  if(record.length() >= startPos+length){
				  value = record.substring(startPos, startPos+length).trim();

			  }
			  return value;
		  }

		  /**\
		   * Validate the given field value whether the field value is blank,
		   * if yes log an error and terminate the process.
		   * @param value
		   * @param name
		   * @param startPos
		   * @param endPos
		   */

		  private boolean validateDetailField(String value, String name, int startPos, int endPos){
			  if(isBlankOrNull(value)){
				  // KL20130417 - Changed from logMessage to addError as the file should not be processed if there is an error
				  addError(CustomMessageRepository.ni0019_4MandatoryfieldIsBlank( 
						  lineCounter.toString(), name,
						  String.valueOf(startPos),
						  String.valueOf(endPos+1)));
				  return false;
			  }
			  return true;
		  }

		  /**\
		   * Validate the given field value whether the field value is blank,
		   * if yes log an error and terminate the process.
		   * @param value
		   * @param name
		   * @param startPos
		   * @param endPos
		   */

		  private void validateField(String value, String name, int startPos, int endPos){
			  if(isBlankOrNull(value)){
				  addError(CustomMessageRepository.ni0019_4MandatoryfieldIsBlank(
						  lineCounter.toString(), name,
						  String.valueOf(startPos),
						  String.valueOf(endPos+1))); 
			  }
		  }

		  /**
		   * Convert the input fileDateString to the Date in the given date format.
		   * @param fileDate
		   */
		  private void convertFileDateStringToDateTimeFormat(String fileDateStr){

			  try{
				  fileDateTime = DateTime.fromString(fileDateStr, new DateFormat(DATETIME_FORMAT_MMDDYYYYHHMMSS));
			  } catch (DateFormatParseException e) {
				  addError(CustomMessageRepository.ni0019_4InvalidDate(lineCounter.toString(), 
						  CONST_FILE_DATE, fileDateStr.trim(), DATETIME_FORMAT_MMDDYYYYHHMMSS)); 
			  }
		  }

		  /**
		   * Convert the given string value to BigInteger and 
		   * also checks whether the input string is a valid number.
		   * @param value
		   * @return
		   */private BigInteger checkAndConvertStringToBigInteger(String value){

			   BigInteger number = BigInteger.ZERO;
			   try{
				   number = new BigInteger(value);
			   }catch(NumberFormatException e){
				   addError(CustomMessageRepository.ni0019_4NumberFormatException(lineCounter.toString(), value));  
			   }
			   return number;
		   }

		   /**
		    * This method will check whether the File with the 
		    * bank name and file date combination
		    * is already processed.
		    *
		    */
		   private void isFileAlreadyProcessed(){

			   SQLResultRow firstRow = null;
			   StringBuilder batchProcessesQueryStr = new StringBuilder();

			   batchProcessesQueryStr.append(" SELECT 'X' ");
			   batchProcessesQueryStr.append(" FROM CI_DEP_CTL_ST DEP ");
			   // START CHANGES - JHERNA - 2015-12-10 - SysAid#73195
			   //batchProcessesQueryStr.append(" WHERE TRIM(DEP.EXT_TRANSMIT_ID) = :externalTransId ");
			   //batchProcessesQueryStr.append(" AND TRIM(DEP.EXT_SOURCE_ID) = :externalSourceId ");
			   batchProcessesQueryStr.append(" WHERE DEP.EXT_TRANSMIT_ID = :externalTransId ");
			   batchProcessesQueryStr.append(" AND DEP.EXT_SOURCE_ID = :externalSourceId ");
			   
			   //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			   //PreparedStatement batchProcessesPrepStmt = createPreparedStatement(batchProcessesQueryStr.toString());
			   PreparedStatement batchProcessesPrepStmt = createPreparedStatement(batchProcessesQueryStr.toString(), getClass().getName());
			   //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			   //batchProcessesPrepStmt.bindStringProperty("externalTransId", DepositControlStaging.properties.externalTransmissionId ,fileDateStr.trim());
			   batchProcessesPrepStmt.bindString("externalTransId", fileDateStr.trim(), "EXT_TRANSMIT_ID");
			   // 2015-03-03 SMiran MGE-CCB031 Start Change
			   //batchProcessesPrepStmt.bindStringProperty("externalSourceId",DepositControlStaging.properties.externalSourceId,batchNumber.trim());
			   //batchProcessesPrepStmt.bindStringProperty("externalSourceId",DepositControlStaging.properties.externalSourceId,bankNameStr);
			   batchProcessesPrepStmt.bindString("externalSourceId", bankNameStr.trim(), "EXT_SOURCE_ID");
			   // 2015-03-03 SMiran MGE-CCB031 End Change
			   // END CHANGES - JHERNA - 2015-12-10 - SysAid#73195
			   firstRow = batchProcessesPrepStmt.firstRow();
			   batchProcessesPrepStmt.close();

			   if(notNull(firstRow)){
				   // 2015-03-03 SMiran MGE-CCB031 Start Change
				   //addError(CustomMessageRepository.ni0019_4BatchIsAlreadyProcessed(batchNumber, fileDateTime.toString())); 
				   addError(CustomMessageRepositoryMGE.ccb031_bankNameFileDateProcessed(bankNameStr, fileDateTime.toString()));
				   // 2015-03-03 SMiran MGE-CCB031 End Change
			   }
		   }

		   private TenderSource getTenderSource(String extSourceId){

			   TenderSource tenderSource = null;
			   SQLResultRow firstResultRow = null;
			   StringBuilder getTenderSourceQueryStr = new StringBuilder();

			   getTenderSourceQueryStr.append(" SELECT TNDR_SOURCE_CD ");
			   getTenderSourceQueryStr.append(" FROM CI_TNDR_SRCE TNDR ");
			   // START CHANGES - JHERNA - 2015-12-10 - SysAid#73195
			   //getTenderSourceQueryStr.append(" WHERE TRIM(TNDR.EXT_SOURCE_ID) = :externalSourceId ");
			   getTenderSourceQueryStr.append(" WHERE TNDR.EXT_SOURCE_ID = :externalSourceId ");
			   
			   //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			   //PreparedStatement getTenderSourcePrepStmt = createPreparedStatement(getTenderSourceQueryStr.toString());
			   PreparedStatement getTenderSourcePrepStmt = createPreparedStatement(getTenderSourceQueryStr.toString(), getClass().getName());
			   //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			   //getTenderSourcePrepStmt.bindStringProperty("externalSourceId",DepositControlStaging.properties.externalSourceId,extSourceId);
			   getTenderSourcePrepStmt.bindString("externalSourceId", extSourceId.trim(), "EXT_SOURCE_ID");
			   // END CHANGES - JHERNA - 2015-12-10 - SysAid#73195
			   firstResultRow = getTenderSourcePrepStmt.firstRow();
			   getTenderSourcePrepStmt.close();

			   if(notNull(firstResultRow)){
				   tenderSource = firstResultRow.getEntity("TNDR_SOURCE_CD", TenderSource.class);
			   }
			   return tenderSource;
		   }

		   private ServiceAgreement getDollarHelpSA(Account account){

			   ServiceAgreement dollarHelpSA = null;
			   StringBuilder getDollarHelpSAString = new StringBuilder();
			   getDollarHelpSAString.append(" SELECT SA.SA_ID FROM CI_SA SA ");
			   getDollarHelpSAString.append("WHERE SA.SA_TYPE_CD = :saType ");
			   getDollarHelpSAString.append( "AND SA.CIS_DIVISION = :cisDivision ");
			   getDollarHelpSAString.append( "AND SA.ACCT_ID = :account ");
			   getDollarHelpSAString.append( "AND SA.SA_STATUS_FLG IN (:pendingStart , :active) ");
			   getDollarHelpSAString.append(" UNION ");
			   getDollarHelpSAString.append(" SELECT SA.SA_ID FROM CI_SA SA ");
			   getDollarHelpSAString.append("WHERE SA.SA_TYPE_CD = :saType ");
			   getDollarHelpSAString.append( "AND SA.CIS_DIVISION = :cisDivision ");
			   getDollarHelpSAString.append( "AND SA.ACCT_ID IN (SELECT ACCT_ID FROM CI_SA WHERE OLD_ACCT_ID = :account ) ");
			   getDollarHelpSAString.append( "AND SA.SA_STATUS_FLG IN (:pendingStart , :active) ");

			   //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			   //PreparedStatement getDollarHelpSAPrepStmt = createPreparedStatement(getDollarHelpSAString.toString());
			   PreparedStatement getDollarHelpSAPrepStmt = createPreparedStatement(getDollarHelpSAString.toString(), getClass().getName());
			   //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			   getDollarHelpSAPrepStmt.bindStringProperty("saType", ServiceAgreementType.properties.saType,StringUtilities.padRight(parmSAType, SA_TYPE_FIELD_LENGTH));
				// START CHANGES - JHERNA - 2015-04-13 - DEFECT#3201381
			   //getDollarHelpSAPrepStmt.bindId("cisDivision", parmCisDivision.getId());
			   if (notNull(parmCisDivision)) {
				   getDollarHelpSAPrepStmt.bindId("cisDivision", parmCisDivision.getId());
			   }
			   else {
				   CisDivision_Id accountCisDivisionID = account.getDivisionId();
				   if (isNull(accountCisDivisionID)
						   || isNull(accountCisDivisionID.getEntity())) {
					   // START CHANGES - JHERNA - 2015-08-17 - 3279010
					   // Account %1 does not have a CIS Division.
					   //addError(CustomMessageRepositoryMGE.commGenericErrorAccountCisDivisionMissing(account.getId().getTrimmedValue()));
					   logError(CustomMessageRepositoryMGE.commGenericErrorAccountCisDivisionMissing(account.getId().getTrimmedValue()));
					   return null;
					   // END CHANGES - JHERNA - 2015-08-17 - 3279010
				   }
				   // Retrieve the CIS Division from the account in the event that the cis division parameter is not supplied
				   getDollarHelpSAPrepStmt.bindId("cisDivision", accountCisDivisionID);
			   }
				// END CHANGES - JHERNA - 2015-04-13 - DEFECT#3201381
			   getDollarHelpSAPrepStmt.bindId("account", account.getId());
			   getDollarHelpSAPrepStmt.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
			   getDollarHelpSAPrepStmt.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);

			   if(notNull(getDollarHelpSAPrepStmt.firstRow())){
				   dollarHelpSA = getDollarHelpSAPrepStmt.firstRow().getEntity("SA_ID", ServiceAgreement.class);
			   }
			   getDollarHelpSAPrepStmt.close();
			   return dollarHelpSA;
		   }

		   private ServiceAgreement createSA(Account account,Date fileDate,Money recurringCharge) {

			   ServiceAgreementCreator saCreator = ServiceAgreementCreator.Factory.newInstance();
			   ServiceAgreement_DTO saDto = (ServiceAgreement_DTO) createDTO(ServiceAgreement.class);
			   ServiceAgreementCreatorData saCreatorData = ServiceAgreementCreatorData.Factory.newInstance();
				// START CHANGES - JHERNA - 2015-04-13 - DEFECT#3201381			  
			   // saDto.setServiceAgreementTypeId(saTypeId); 
			   if (notNull(parmCisDivision)) {
				   saDto.setServiceAgreementTypeId(saTypeId);
			   }
			   else {
				   /*
				    * In the event that the parameter cis division is not supplied, retrieve the cis division from the account.
				    * Use this cis division for the Service Agreement Type ID to be used when creating the Service Agreement itself.
				    */  
				   CisDivision_Id accountCisDivisionID = account.getDivisionId();
				   if (isNull(accountCisDivisionID)
						   || isNull(accountCisDivisionID.getEntity())) {
					   // START CHANGES - JHERNA - 2015-08-17 - 3279010
					   // Account %1 does not have a CIS Division.
					   //addError(CustomMessageRepositoryMGE.commGenericErrorAccountCisDivisionMissing(account.getId().getTrimmedValue()));
					   logError(CustomMessageRepositoryMGE.commGenericErrorAccountCisDivisionMissing(account.getId().getTrimmedValue()));
					   return null;
					   // END CHANGES - JHERNA - 2015-08-17 - 3279010
				   }
				   saTypeId = new ServiceAgreementType_Id(accountCisDivisionID, parmSAType);
				   saDto.setServiceAgreementTypeId(saTypeId);
			   }
				// END CHANGES - JHERNA - 2015-04-13 - DEFECT#3201381
			   saDto.setStatus(ServiceAgreementStatusLookup.constants.PENDING_START);
			   saDto.setAccountId(account.getId());
			   saDto.setStartDate(fileDate);
			   saDto.setAreEstimatesAllowed(Bool.FALSE);
			   saDto.setCustomerRead(CustomerReadLookup.constants.NO);
			   saDto.setStartReason(StartReasonLookup.constants.CUSTOMER_REQUEST);
			   saCreatorData.setRecurringChargeAmount(recurringCharge);
			   saCreatorData.setShouldCreateFieldActivity(Bool.FALSE);
			   saCreatorData.setShouldExcludeCopySASP(Bool.TRUE);

			   saCreatorData.setCopyOption(CopyOptionForProposalSALookup.constants.COPY_OPTION_FOR_PROPOSAL_S_A_B_S_P);

			   return saCreator.addServiceAgreement(saDto, saCreatorData);

		   }

		   private void addRecurringCharge(ServiceAgreement sa,Date fileDate,Money recurringChargeAmt){
			   if(!sa.getRecurringCharges().isEmpty()){ 
				   //If recurring Charge exists on SA
				   ServiceAgreementRecurringCharge latestRecurringCharge = null;
				   for (Iterator<ServiceAgreementRecurringCharge> saRecurringChargeIter = sa.getRecurringCharges().iterator(); saRecurringChargeIter.hasNext();) 
				   {
					   latestRecurringCharge = saRecurringChargeIter.next();
				   }

				   if (!(latestRecurringCharge.fetchIdEffectiveDate().equals(fileDate))) {
					   //if effective date != file date, Create Recurring Charge
					   ServiceAgreementRecurringCharge_DTO recurringChargeDto = (ServiceAgreementRecurringCharge_DTO) createDTO(ServiceAgreementRecurringCharge.class);
					   recurringChargeDto.setCurrencyId(recurringChargeAmt.getCurrencyId());
					   recurringChargeDto.setRecurringChargeAmount(recurringChargeAmt);
					   sa.getRecurringCharges().add(recurringChargeDto, fileDate);
				   }
			   }else{
				   ServiceAgreementRecurringCharge_DTO recurringChargeDto = (ServiceAgreementRecurringCharge_DTO) createDTO(ServiceAgreementRecurringCharge.class);
				   recurringChargeDto.setCurrencyId(recurringChargeAmt.getCurrencyId());
				   recurringChargeDto.setRecurringChargeAmount(recurringChargeAmt);
				   sa.getRecurringCharges().add(recurringChargeDto, fileDate);
			   }
		   }

		   private Account retrieveAccount(String accountStr){

			   SQLResultRow firstRow = null;
			   Account account = null;
			   StringBuilder retrieveAccountString = new StringBuilder();
			   retrieveAccountString.append(" SELECT ACCT_ID FROM CI_ACCT ACCT ");
			   retrieveAccountString.append("WHERE ACCT.ACCT_ID = :account ");
			   retrieveAccountString.append( "UNION ");
			   retrieveAccountString.append( "SELECT ACCT_ID FROM CI_SA  SA ");
			   retrieveAccountString.append( "WHERE SA.OLD_ACCT_ID = :account ");

			   //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			   //PreparedStatement retreiveAccountPrepStmt = createPreparedStatement(retrieveAccountString.toString());
			   PreparedStatement retreiveAccountPrepStmt = createPreparedStatement(retrieveAccountString.toString(), getClass().getName());
			   //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			   retreiveAccountPrepStmt.bindId("account", new Account_Id(accountStr));
			   firstRow = retreiveAccountPrepStmt.firstRow();
			   retreiveAccountPrepStmt.close();

			   if(notNull(firstRow)){
				   account = firstRow.getEntity("ACCT_ID", Account.class);
			   }
			   return account;
		   }

		   /**
		    * @return String 
		    *  This method retrieves Feature Config value
		    * 
		    */  
		   private String retrieveFeatureConfig(String strFeatureConfigOption) {
			   String strFeatureConfigVal = null;
			   FeatureConfiguration_Id recurringChargeId = new FeatureConfiguration_Id(parmDollarHelpfeatureConfig);
			   FeatureConfiguration recurringChargeFeatureConfig = recurringChargeId.getEntity();

			   CmFeatureConfigurationRetriever cmFeatureConfigurationRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
			   cmFeatureConfigurationRetriever.setParmWFMName(recurringChargeFeatureConfig);
			   cmFeatureConfigurationRetriever.setParmOptType(strFeatureConfigOption);
			   strFeatureConfigVal = cmFeatureConfigurationRetriever.getMaxSequenceOptionValue();
			   return strFeatureConfigVal;
		   }

		   private List<SQLResultRow> retrievePaymentTender(String extPaymentId){

			   List<SQLResultRow> resultList = null;
			   StringBuilder payTndrString = new StringBuilder();
			   payTndrString.append(" SELECT PAY_TENDER_ID FROM CI_PAY_TNDR  ");
			   // START CHANGES - JHERNA - 2015-12-10 - SysAid#73195
			   //payTndrString.append("WHERE TRIM(EXT_REFERENCE_ID) = :extPayId ");
			   payTndrString.append("WHERE EXT_REFERENCE_ID = :extPayId ");
			   
			   //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			   //PreparedStatement payTndrPrepStmt = createPreparedStatement(payTndrString.toString());
			   PreparedStatement payTndrPrepStmt = createPreparedStatement(payTndrString.toString(), getClass().getName());
			   //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			   //payTndrPrepStmt.bindStringProperty("extPayId", PaymentTender.properties.externalReferenceId, extPaymentId.trim());
			   payTndrPrepStmt.bindString("extPayId", extPaymentId.trim(), "EXT_REFERENCE_ID");
			   // END CHANGES - JHERNA - 2015-12-10 - SysAid#73195
			   
			   resultList = payTndrPrepStmt.list();
			   payTndrPrepStmt.close();
			   return resultList;
		   }

		   private void createCharOnPayTndr(PaymentTender payTndr){
			   PaymentTenderCharacteristics payTndrCharacteristics = payTndr.getCharacteristics();
			   //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			   //ListFilter<PaymentTenderCharacteristic> payTndrCharListFilter = payTndr.getCharacteristics().createFilter(" WHERE this.id.characteristicType = :characteristicType ");
			   ListFilter<PaymentTenderCharacteristic> payTndrCharListFilter = payTndr.getCharacteristics().
					   createFilter(" WHERE this.id.characteristicType = :characteristicType ", getClass().getName());
			   //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
			   payTndrCharListFilter.bindEntity("characteristicType",parmRealTimeCharType);
			   PaymentTenderCharacteristic_DTO payTndrCharacteristicDTO = payTndrCharacteristics.newChildDTO();
			   CharacteristicTypeLookup charTypeLookup = parmRealTimeCharType.getCharacteristicType();
			   payTndrCharacteristicDTO.setId(new PaymentTenderCharacteristic_Id(payTndr,parmRealTimeCharType,BigInteger.valueOf(payTndrCharListFilter.listSize() +1)));

			   // KL20130603 - Start of change for CR / Defect #1433
			   String charValue = fileDateStr + COMMA + batchNumber;
			   
			   if(charTypeLookup.isAdhocValue()){
				   payTndrCharacteristicDTO.setAdhocCharacteristicValue(charValue);
			   } else if (charTypeLookup.isPredefinedValue()){
				   payTndrCharacteristicDTO.setCharacteristicValue(charValue);
			   } else if (charTypeLookup.isForeignKeyValue()){
				   payTndrCharacteristicDTO.setCharacteristicValueForeignKey1(charValue);
			   }
			   // KL20130603 - End of change for CR / Defect #1433

			   PaymentTenderCharacteristic payTndrChar = payTndrCharacteristicDTO.newEntity();
			   payTndrCharacteristics.add(payTndrChar);

		   }

	}

}
