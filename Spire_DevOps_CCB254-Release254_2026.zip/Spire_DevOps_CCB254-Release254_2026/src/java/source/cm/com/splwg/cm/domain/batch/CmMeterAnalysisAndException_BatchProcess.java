/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Meter Analysis and Exception upload Batch
 * 
 * An Exception case created for the highest priority exception sent by DataRaker in file.
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-02-27   Neha            NI0028.6 Initial Version.
 * 2013-05-14   JPunza          TIR 1. Modified to allow zero Minimum Threshold Value.
 *                              TIR 2. Modified to remove unused batch parameters.
 *                              TIR 3. Modified to prevent error message from being trimmed.
 *                              TIR 4. Modified to add Meter Badge batch parameter.
 *                              TIR 5. Modified to add default case characteristics.
 * 2013-06-07   JPunza          TIR 6. Modified to search for completed case correctly.
 * 2013-07-04   MLecaroz        Fix to Defect 2604.
 * 2013-08-27   Neha            IM-036038 reference to other unrelated Case Types removed
 * 2013-11-13	Karthik		KL20131113 - Code change for CR (IM-041170) - Replace error 
 * 				with To Do, when one badge number is associated with 2 or more meters. 
 * 2013-11-19	Karthik		KL20131119 - IM-041170. Modified the logic to retrieve and use the 
 * 				max. sequence number instead of count while create Case Char.
 * 2013-12-18   Neha            IM-042812 Every characteristic to occur only once
 * 2014-03-21	Neha			IM-044199 Case created on old accounts
 * 2016-01-29  	MPang			Updated for CCB v2.4 compilation.
 * 2016-11-25  	RGoke			Updated for Incident #92435.
 * 2018-07-25   SFelip          CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                              longer needed.  
 * 2018-12-17   MPang           Defect 4172199. Added trim to TEST_TYPE fields.
 * 2019-03-20	JHERNA			SysAid#286046. Update code to retrieve the correct 
 * 								and latest customer information linked to the service point.
 * 2020-08-26   DLampa          B-17008. Update query that looks for an existing open To Do
 *                              so that multiple entries are not created for the same badge 
 *                              number. 
 ******************************************************************************************/

package com.splwg.cm.domain.batch;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_Id;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_LanguageId;
import com.splwg.base.domain.batch.batchRun.BatchRun_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.common.phoneType.PhoneType;
import com.splwg.base.domain.common.phoneType.PhoneType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ContactMethodLookup;
import com.splwg.ccb.api.lookup.ServicePointMeterEventTypeLookup;
import com.splwg.ccb.api.lookup.StatusConditionLookup;

//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.CaseType;
import com.splwg.ccb.domain.admin.caseType.CaseTypeCaseStatues;*/
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.caseType.entity.CaseTypeCaseStatues;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation

/*
 * Start Delete - 2013-05-14 - JPunza 
 */
//import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure;
//import com.splwg.ccb.domain.admin.unitOfMeasure.UnitOfMeasure_Id;
/*
 * End Delete - 2013-05-14 - JPunza 
 */
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.Person;
import com.splwg.ccb.domain.customerinfo.person.Person_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.Meter;
import com.splwg.ccb.domain.meterread.meter.Meter_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseCreator;
import com.splwg.ccb.domain.todo.toDoCase.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCaseCharacteristics;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_Id;*/

import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.common.CaseCreator;
import com.splwg.ccb.domain.todo.data.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCaseCharacteristics;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_Id;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever_Impl;
import com.splwg.cm.domain.common.customBusinessComponent.CmSaSpMeterRelationshipsRoutine_Impl;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.customMessages.CustomMessages;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

// KL20131113 - Start of delete - Code Change for CR (IM-041170)
///** 
// * @BatchJob (multiThreaded = false, modules = {},
// *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
// *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
// *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)
// *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = FEATURE_NAME, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = OPTION_TYPE_TEST_CNTRL, required = true, type = string)
// *            , @BatchJobSoftParameter (name = OPTION_TYPE_CURR_SEASON, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = EX_REQUESTER_CORR_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = EX_REQ_DT_CORR_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = IN_EX_CD_CORR_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = IN_EX_STAT_CD_CORR_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = IN_EX_STAT_DT_CORR_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = EX_REQUESTER_UNCORR_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = EX_REQ_DT_UNCORR_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = IN_EX_CD_UNCORR_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = IN_EX_STAT_CD_UNCORR_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = IN_EX_STAT_DT_UNCORR_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = DR_MTR_TEST_DT_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = caseType, name = MTR_EXCP_CASE_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = SP_ID_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = OWNER_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = METER_BADGE_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = CORR_EXCP_CODE_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = UNCORR_EXCP_CODE_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = COMPLETED_CASE_STATUS, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = EX_STAT_DT_CORR_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = EX_STAT_DT_UNCORR_CHAR_TYPE, required = true, type = entity)})
// */
// KL20131113 - End of delete


/*
 *  KL20131113 - Start of Code Change for CR (IM-041170) 
 *  Modify annotation to include To Do Creation
 */
/** 
 * @BatchJob (multiThreaded = false, modules = {},
 *      toDoCreation = @ToDoCreation (drillKeyEntity = batchRun,
 *            sortKeys = { "BATCH_NBR"}),
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = FEATURE_NAME, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = OPTION_TYPE_TEST_CNTRL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = OPTION_TYPE_CURR_SEASON, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = EX_REQUESTER_CORR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = EX_REQ_DT_CORR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = IN_EX_CD_CORR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = IN_EX_STAT_CD_CORR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = IN_EX_STAT_DT_CORR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = EX_REQUESTER_UNCORR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = EX_REQ_DT_UNCORR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = IN_EX_CD_UNCORR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = IN_EX_STAT_CD_UNCORR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = IN_EX_STAT_DT_UNCORR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = DR_MTR_TEST_DT_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = caseType, name = MTR_EXCP_CASE_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = SP_ID_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = OWNER_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = METER_BADGE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CORR_EXCP_CODE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = UNCORR_EXCP_CODE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = COMPLETED_CASE_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = EX_STAT_DT_CORR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = EX_STAT_DT_UNCORR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = TD_TYPE_CD, required = true, type = entity)            
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = MTR_ST_NMBR_CHAR_TYPE, required = true, type = entity)
 *             , @BatchJobSoftParameter (name = MTR_ST_NMBR_CHAR_VAL, required = true, type = string)
 *            
 *            })
 */
//KL20131113 - End of Change


public class CmMeterAnalysisAndException_BatchProcess 
		extends CmMeterAnalysisAndException_BatchProcess_Gen{

	/*
	 * Start Delete - 2013-06-07 - JPunza 
	 */
	//    // Soft Parameters
	//    private static BigInteger parmMaxErrors = null;
	//    private static String parmFilePath;
	//    private static String parmFileName;
	//    private static FeatureConfiguration parmFeatConfig; 
	//    private static String parmOptionTypeTestCntrl;
	//    private static String parmOptionTypeCurrSeason;
	//    private static CharacteristicType parmExcRequesterCorrCharType; 
	//    private static CharacteristicType parmExcRequestDtCorrCharType; 
	//    private static CharacteristicType parmInExcCdCorrCharType;
	//    private static CharacteristicType parmInExcStatusCorrCharType;   
	//    private static CharacteristicType parmInExcStatDtCorrCharType; 
	//    private static CharacteristicType parmExcRequesterUncorrCharType; 
	//    private static CharacteristicType parmExcRequestDtUncorrCharType; 
	//    private static CharacteristicType parmInExcCdUncorrCharType; 
	//    private static CharacteristicType parmInExcStatusUncorrCharType; 
	//    private static CharacteristicType parmInExcStatDtUncorrCharType; 
	//    private static CharacteristicType parmDRMeterTestDtCharType; 
	//    private static CaseType parmMeteringExceptionCaseType;
	//    private static CharacteristicType parmServicePointCharType;
	//    /*
	//     * Start Change - 2013-05-14 - JPunza 
	//     */
	//    //private static UnitOfMeasure parmCorrUomCd;
	//    //private static UnitOfMeasure parmUncorrUomCd;
	//    private static CharacteristicType parmMeterBadgeCharType; 
	//    /*
	//     * End Change - 2013-05-14 - JPunza 
	//     */
	//    
	//    private static CharacteristicType parmOwnerCharType;    
	//
	//    private static File inputFile = null;
	/*
	 * End Delete - 2013-06-07 - JPunza 
	 */

	/**
	 * This method retrieves the records to be processed and in case of error returns a JobWork with single ThreadWorkUnit
	 * 
	 * @return the JobWork that will be processed in this run.
	 */
	public JobWork getJobWork() {

		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();                                               
		ThreadWorkUnit workUnit = new ThreadWorkUnit(); 
		workUnits.add(workUnit);   
		return createJobWorkForThreadWorkUnitList(workUnits);
	}

	/**
	 * This method checks if all required Soft Parameters were populated,
	 * and all optional Soft Parameters (if populated) are valid.
	 * 
	 * @param isNewRun - a boolean value
	 */
	public void validateSoftParameters(boolean isNewRun){

		/*
		 * Start Add - 2013-06-07 - JPunza 
		 */
		BigInteger parmMaxErrors = null;
		String parmFilePath;
		String parmFileName;
		FeatureConfiguration parmFeatConfig; 
		String parmOptionTypeTestCntrl;
		String parmOptionTypeCurrSeason;
		CharacteristicType parmExcRequesterCorrCharType; 
		CharacteristicType parmExcRequestDtCorrCharType; 
		CharacteristicType parmInExcCdCorrCharType;
		CharacteristicType parmInExcStatusCorrCharType;   
		CharacteristicType parmInExcStatDtCorrCharType; 
		CharacteristicType parmExcRequesterUncorrCharType; 
		CharacteristicType parmExcRequestDtUncorrCharType; 
		CharacteristicType parmInExcCdUncorrCharType; 
		CharacteristicType parmInExcStatusUncorrCharType; 
		CharacteristicType parmInExcStatDtUncorrCharType; 
		CharacteristicType parmDRMeterTestDtCharType;
		CaseType parmMeteringExceptionCaseType;
		CharacteristicType parmServicePointCharType;
		CharacteristicType parmOwnerCharType;
		CharacteristicType parmMeterBadgeCharType;
		CharacteristicType parmCorrExcpCdCharType; 
		CharacteristicType parmUncorrExcpCdCharType;
		
		/* MOL20130704 Begin */
		CharacteristicType parmExcStatDtCorrCharType; 
		CharacteristicType parmExcStatDtUncorrCharType; 
		/* MOL20130704 End */
		//Start Change -RGoke - 92435 - 11-25-2016
        CharacteristicType parmMeterStNmbrCharType;
        String parmMeterStNmbrCharVal;
        //End Change -RGoke - 92435 - 11-25-2016

		String parmCompletedCaseStatus;
		File inputFile = null;
		/*
		 * End Add - 2013-06-07 - JPunza 
		 */
		
		parmMaxErrors = getParameters().getMAX_ERRORS();
		// Validates Max Error soft parameter
		if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
			addError(CustomMessageRepository.int0028_6MaxErrorCannotBeLessThanZero(parmMaxErrors.toString().trim()));
		}   
		parmFilePath = getParameters().getFILE_PATH().trim();
		parmFileName = getParameters().getFILE_NAME().trim();

		File folder = new File(parmFilePath);
		if(!folder.exists()){
			addError(CustomMessageRepository.int0028_6InvalidFilePath(parmFilePath));
		}

		// Validate that the parameter FILE-NAME is a correct file name and that the corresponding file can be opened and read.
		inputFile = new File(parmFilePath, parmFileName);
		if(!inputFile.exists() || !inputFile.canRead()){
			addError(CustomMessageRepository.int0028_6InvalidFileName(parmFileName));
		}      
		parmFeatConfig = getParameters().getFEATURE_NAME();
		parmOptionTypeTestCntrl = getParameters().getOPTION_TYPE_TEST_CNTRL().trim();
		validateOptionType(parmFeatConfig, parmOptionTypeTestCntrl);        
		parmOptionTypeCurrSeason = getParameters().getOPTION_TYPE_CURR_SEASON().trim();
		validateOptionType(parmFeatConfig, parmOptionTypeCurrSeason);

		parmExcRequesterCorrCharType = getParameters().getEX_REQUESTER_CORR_CHAR_TYPE();
		validateCharTypeAndEntity(parmExcRequesterCorrCharType, getBatchParameterName(BigInteger.valueOf(70)));  

		parmExcRequestDtCorrCharType = getParameters().getEX_REQ_DT_CORR_CHAR_TYPE();
		validateCharTypeAndEntity(parmExcRequestDtCorrCharType, getBatchParameterName(BigInteger.valueOf(80)));     

		parmInExcCdCorrCharType = getParameters().getIN_EX_CD_CORR_CHAR_TYPE();
		validateCharTypeAndEntity(parmInExcCdCorrCharType, getBatchParameterName(BigInteger.valueOf(90)));        

		parmInExcStatusCorrCharType = getParameters().getIN_EX_STAT_CD_CORR_CHAR_TYPE();   
		validateCharTypeAndEntity(parmInExcStatusCorrCharType, getBatchParameterName(BigInteger.valueOf(100)));

		parmInExcStatDtCorrCharType = getParameters().getIN_EX_STAT_DT_CORR_CHAR_TYPE(); 
		validateCharTypeAndEntity(parmInExcStatDtCorrCharType, getBatchParameterName(BigInteger.valueOf(110)));

		parmExcRequesterUncorrCharType = getParameters().getEX_REQUESTER_UNCORR_CHAR_TYPE();
		validateCharTypeAndEntity(parmExcRequesterUncorrCharType, getBatchParameterName(BigInteger.valueOf(120)));

		parmExcRequestDtUncorrCharType = getParameters().getEX_REQ_DT_UNCORR_CHAR_TYPE();
		validateCharTypeAndEntity(parmExcRequestDtUncorrCharType, getBatchParameterName(BigInteger.valueOf(130)));

		parmInExcCdUncorrCharType = getParameters().getIN_EX_CD_UNCORR_CHAR_TYPE(); 
		validateCharTypeAndEntity(parmInExcCdUncorrCharType, getBatchParameterName(BigInteger.valueOf(140)));

		parmInExcStatusUncorrCharType = getParameters().getIN_EX_STAT_CD_UNCORR_CHAR_TYPE(); 
		validateCharTypeAndEntity(parmInExcStatusUncorrCharType, getBatchParameterName(BigInteger.valueOf(110)));         

		parmInExcStatDtUncorrCharType = getParameters().getIN_EX_STAT_DT_UNCORR_CHAR_TYPE(); 
		validateCharTypeAndEntity(parmInExcStatDtUncorrCharType, getBatchParameterName(BigInteger.valueOf(160)));

		parmDRMeterTestDtCharType = getParameters().getDR_MTR_TEST_DT_CHAR_TYPE(); 
		validateCharTypeAndEntity(parmDRMeterTestDtCharType, getBatchParameterName(BigInteger.valueOf(170)));

		parmMeteringExceptionCaseType = getParameters().getMTR_EXCP_CASE_TYPE();

		parmServicePointCharType = getParameters().getSP_ID_CHAR_TYPE(); 
		validateCharTypeAndEntity(parmServicePointCharType, getBatchParameterName(BigInteger.valueOf(190)));

		parmOwnerCharType = getParameters().getOWNER_CHAR_TYPE(); 
		validateCharTypeAndEntity(parmOwnerCharType, getBatchParameterName(BigInteger.valueOf(200)));
		
		
		/*
		 * Start Change - 2013-05-14 - JPunza 
		 */
		 //parmCorrUomCd = getParameters().getCORR_UOM_CD();
		//
		//parmUncorrUomCd = getParameters().getUNCORR_UOM_CD();        
		parmMeterBadgeCharType = getParameters().getMETER_BADGE_CHAR_TYPE();
		validateCharTypeAndEntity(parmMeterBadgeCharType, getBatchParameterName(BigInteger.valueOf(210)));
		/*
		 * End Change - 2013-05-14 - JPunza 
		 */

		/*
		 * Start Add - 2013-06-07 - JPunza 
		 */
		parmCorrExcpCdCharType = getParameters().getCORR_EXCP_CODE_CHAR_TYPE();
		validateCharTypeAndEntity(parmCorrExcpCdCharType, getBatchParameterName(BigInteger.valueOf(220)));

		parmUncorrExcpCdCharType = getParameters().getUNCORR_EXCP_CODE_CHAR_TYPE();
		validateCharTypeAndEntity(parmUncorrExcpCdCharType, getBatchParameterName(BigInteger.valueOf(230)));

		parmCompletedCaseStatus = getParameters().getCOMPLETED_CASE_STATUS().trim();
		CaseStatus_Id caseStatusId = new CaseStatus_Id(parmMeteringExceptionCaseType, parmCompletedCaseStatus);
		if (isNull(caseStatusId.getEntity())) {
			addError(CustomMessageRepository.ni0028_6InvalidCaseStatusForCaseType(
					parmCompletedCaseStatus, 
					parmMeteringExceptionCaseType.getId().getTrimmedValue()));
		}
		/*
		 * End Add - 2013-06-07 - JPunza 
		 */

		/* MOL20130704 Begin */
		//logger.info("Leky - before get/validate " + getParameters().getEX_STAT_DT_CORR_CHAR_TYPE());
		parmExcStatDtCorrCharType = getParameters().getEX_STAT_DT_CORR_CHAR_TYPE(); 
		validateCharTypeAndEntity(parmExcStatDtCorrCharType, getBatchParameterName(BigInteger.valueOf(250)));

		//logger.info("Leky - before get/validate " + getParameters().getEX_STAT_DT_UNCORR_CHAR_TYPE());
		parmExcStatDtUncorrCharType = getParameters().getEX_STAT_DT_UNCORR_CHAR_TYPE();
		validateCharTypeAndEntity(parmExcStatDtUncorrCharType, getBatchParameterName(BigInteger.valueOf(260)));
		/* MOL20130704 End */
		//Start Change -RGoke - 92435 - 11-25-2016
		parmMeterStNmbrCharType  = getParameters().getMTR_ST_NMBR_CHAR_TYPE();
		validateCharTypeEntity(parmMeterStNmbrCharType, CharacteristicEntityLookup.constants.METER,getBatchParameterName(BigInteger.valueOf(280)));
          
		parmMeterStNmbrCharVal = this.getParameters().getMTR_ST_NMBR_CHAR_VAL();
		validateCharVal(parmMeterStNmbrCharType, parmMeterStNmbrCharVal, getBatchParameterName(BigInteger.valueOf(290)));
	}
	   //End Change -RGoke - 92435 - 11-25-2016


	private void validateOptionType(FeatureConfiguration featConfig, String optionType) {

		StringBuilder getOptionTypeString = new StringBuilder();
		getOptionTypeString.append("SELECT 'X' FROM CI_LOOKUP_VAL LOOK ");
		getOptionTypeString.append("WHERE TRIM(LOOK.FIELD_NAME) = (SELECT TRIM(WFM.EXT_SYS_TYP_FLG)|| '_OPT_TYP_FLG' FROM CI_WFM WFM WHERE WFM.WFM_NAME = :wfmName) ");
		// CCB v2.6 Upgrade - 2018-07-25 - Start Change
		//getOptionTypeString.append("AND TRIM(LOOK.FIELD_VALUE) = :optionType ");
		getOptionTypeString.append("AND LOOK.FIELD_VALUE = :optionType ");
		// CCB v2.6 Upgrade - 2018-07-25 - End Change
		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement optionTypeStmt = createPreparedStatement(getOptionTypeString.toString()); 
		PreparedStatement optionTypeStmt = createPreparedStatement(getOptionTypeString.toString(), getClass().getName()); 
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		optionTypeStmt.bindId("wfmName", featConfig.getId());        
		optionTypeStmt.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType,optionType);
		if(isNull(optionTypeStmt.firstRow())){
			addError(CustomMessageRepository.ni0028_6InvalidOptionTypForFeatureConfig(optionType,featConfig.getId().getTrimmedValue())); 
		}
		optionTypeStmt.close();
		return;
	}

	/**
	 * This method will validate the input CharacteristicType is valid for the 
	 * CharacteristicEntityLookup for Field Activity.
	 * 
	 * @param characteristicType a Characteristic Type Entity 
	 * return returns Bool.TRUE if the Char Value is valid for the Char Type, otherwise returns Bool.FALSE.
	 */
	private void validateCharTypeAndEntity(CharacteristicType characteristicType, String paramName) {

		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(characteristicType.getId(), CharacteristicEntityLookup.constants.CASE);
		if(isNull(charEntityId.getEntity())){
			addError(CustomMessageRepository.int0028_6InvalidCharTypeForEntity(paramName, characteristicType.getId().getTrimmedValue()));  
		}
	}
	//Start Change -RGoke - 92435 - 11-25-2016
	/**
     * This Method will validate whether the input parameter Characteristic Type 
     * is valid for the  Characteristic Entity.
     * @param parmCharType
     */
	
    private void validateCharTypeEntity(CharacteristicType parmCharType, CharacteristicEntityLookup parmEntityLookup,String paramName){
        CharacteristicEntity_Id characteristicEntityId = new CharacteristicEntity_Id(parmCharType, parmEntityLookup);
        if (isNull(characteristicEntityId.getEntity())){
            addError(CustomMessageRepository.nm0038CharTypeInvalidForCharEntity(parmCharType.getId().getIdValue(), parmEntityLookup.getConstantName()));
        } 
    }
    /**
    * This Method will validate whether the input parameter Characteristic Value 
    * is valid for the  Characteristic Type.
    */
	
	private void validateCharVal(CharacteristicType charType, String charVal, String parmDesc) {
		// Validate only if the characteristic type is of predefined char value type
		if (charType.getCharacteristicType().isPredefinedValue()) {
			CharacteristicValue_Id charValID = new CharacteristicValue_Id(charType, charVal.toString());
			if (isNull(charValID.getEntity())) {
				// Batch parameter '%1%2' value (%3) is not a valid char value for %4 char type.
				addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharValueForCharType(
						parmDesc.trim(), charVal.toString().trim(), charType.getId().getTrimmedValue()));
			}
		}
	}
	//End Change -RGoke - 92435 - 11-25-2016

	/**
	 * This method will retrieve the batch parameter label name.
	 * @param paramSeq a BigInteger value
	 * @return String a String value
	 */
	private String getBatchParameterName(BigInteger paramSeq){

		String paramName = "";
		BatchControlParameter_Id batchCntrlParameterId = new BatchControlParameter_Id(getBatchControlId(), paramSeq);        
		BatchControlParameter_LanguageId batchCntrlParameterLanguageId = new BatchControlParameter_LanguageId(batchCntrlParameterId, getActiveContextLanguage().getId());
		paramName = batchCntrlParameterLanguageId.getParent().getBatchParameterName();        
		return paramName;
	}

	/**
	 * Method to retrieve the Thread Worker Class.
	 * 
	 * @return the thread worker class
	 */
	public Class<CmMeterAnalysisAndException_BatchProcessWorker> getThreadWorkerClass() {

		return CmMeterAnalysisAndException_BatchProcessWorker.class;
	}

	/**
	 * This Worker Class is responsible for processing a single Thread Instance.
	 */
	public static class CmMeterAnalysisAndException_BatchProcessWorker
	extends CmMeterAnalysisAndException_BatchProcessWorker_Gen {

		/*
		 * Start Add - 2013-06-07 - JPunza 
		 */       
		// Soft Parameters
		private BigInteger parmMaxErrors;
		private String parmFilePath;
		private String parmFileName;
		private FeatureConfiguration parmFeatConfig; 
		private String parmOptionTypeTestCntrl;
		private String parmOptionTypeCurrSeason;
		private CharacteristicType parmExcRequesterCorrCharType; 
		private CharacteristicType parmExcRequestDtCorrCharType; 
		private CharacteristicType parmInExcCdCorrCharType;
		private CharacteristicType parmInExcStatusCorrCharType;   
		private CharacteristicType parmInExcStatDtCorrCharType; 
		private CharacteristicType parmExcRequesterUncorrCharType; 
		private CharacteristicType parmExcRequestDtUncorrCharType; 
		private CharacteristicType parmInExcCdUncorrCharType; 
		private CharacteristicType parmInExcStatusUncorrCharType; 
		private CharacteristicType parmInExcStatDtUncorrCharType; 
		private CharacteristicType parmDRMeterTestDtCharType; 
		private CaseType parmMeteringExceptionCaseType;
		private CharacteristicType parmServicePointCharType;
		private CharacteristicType parmMeterBadgeCharType;       
		private CharacteristicType parmOwnerCharType;
		private CharacteristicType parmCorrExcpCdCharType; 
		private CharacteristicType parmUncorrExcpCdCharType;
		private String parmCompletedCaseStatus;
		/* MOL20130704 Begin */
		private CharacteristicType parmExcStatDtCorrCharType; 
		private CharacteristicType parmExcStatDtUncorrCharType; 
		//Start Change -RGoke - 92435 - 11-25-2016
		private CharacteristicType parmMeterStNmbrCharType;
		private String parmMeterStNmbrCharVal;
		//End Change -RGoke - 92435 - 11-25-2016
		/* MOL20130704 End */
		private File inputFile;
		/*
		 * End Add - 2013-06-07 - JPunza 
		 */
		// KL20131113 - Start of code change for IM-041170
		private ToDoType paramTodoType;
		// KL20131113 - End of code change for IM-041170
		

		// Working Variables
		private String badgeNumber = "";
		/*
		 * Start Delete - 2013-05-14 - JPunza 
		 */
		//private Meter_Id meterId = null;
		/*
		 * End Delete - 2013-05-14 - JPunza 
		 */
		private String spId= "";
		private String testTypeInFile = "";    
		private String exceptionCd = "";     
		private String effectiveDtStr = "";               
		private Date effDtFromFile = null;
		private BigInteger numberOfDaysToPost = null;
		private Bool isUncorrected = Bool.TRUE;
		@SuppressWarnings("unused")
		private BigInteger testPriority = BigInteger.ZERO;
		private String currentSeasonInFeatConfig = "";
		private ArrayList <CaseCharacteristic_DTO>  charList;// = new ArrayList<CaseCharacteristic_DTO>();
		private List<String> testTypeList;

		private BufferedReader inputBufferReader = null;
		private BigInteger numberOfRecordsInError = BigInteger.ZERO;
		private BigInteger numberOfRecordsProcessed = BigInteger.ZERO;
		private BigInteger numberOfCasesCreated = BigInteger.ZERO;

		// Constants
		private static final int TOTAL_LENGTH_OF_TEST_PARAMS = 9;
		private static final int TOTAL_NBR_FIELDS_IN_FILE = 8;
		private static final int CNTRL_TEST_PRIORITY_INDEX = 0;
		private static final int CNTRL_TEST_TYPE_INDEX = 1;
		private static final int CNTRL_BYPASS_TEST_INDEX = 2;
		private static final int CNTRL_SUMMER_EXC_INDEX = 3;
		private static final int CNTRL_WINTER_EXC_INDEX = 4;
		private static final int CNTRL_MIN_THRES_INDEX = 5;
		private static final int CNTRL_MAX_THRES_INDEX = 6;
		private static final int CNTRL_NUM_DAYS_POST_INDEX = 7;
		private static final int CNTRL_NO_TEST_RESPONSE_INDEX = 8;
		private static final int SP_ID_LENGTH = 10; //Only first 10 correspond to SP ID from Utility Id
		private static final String exceptionRequester = "D";
		private static final String exceptionStatus = "P";
		private static final String owner = "L"; 
		private static final String DATE_FORMAT = "yyyy-MM-dd";
		private static final String PIPE_DELIMITER = "\\|";
		private static final String COMMA_DELIMITER = ",";
		private static final String CURRENT_SEASON_SUMMER = "S";
		private static final String CURRENT_SEASON_WINTER = "W";
		private static final String BYPASS_TEST_FLG_Y = "Y";
		private static final String BYPASS_TEST_FLG_N = "N";
		private static final String NO_TEST_RESP_CONTINUE = "C";
		private static final String NO_TEST_RESP_ABORT = "A";
		// Start Add - 2020-08-26 - DLampa - B-17008 
		private static final String OPEN_BRACE = "{";
		private static final String CLOSE_BRACE = "}";
		// End Add - 2020-08-26 - DLampa - B-17008
		
		
		

		/**
		 * This method identifies the execution strategy to be used for the thread.
		 * 
		 * @return an instance of ThreadExecutionStrategy that governs how this ThreadWorker will be executed at runtime.
		 * @see com.splwg.base.api.batch.ThreadWorker#createExecutionStrategy()
		 */
		public ThreadExecutionStrategy createExecutionStrategy() {

			return new SingleTransactionStrategy(this);
		}

		/**
		 * Perform any initialization that must be done at the start of this thread processing work. 
		 * @param initializationPreviouslySuccessful - indicates that this method was called successfully called during some 
		 * prior execution, presumably because this is a restart situation.
		 * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
		 * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
		 * @see com.splwg.base.api.batch.ThreadWorker#initializeThreadWork(boolean) 
		 */
		public void initializeThreadWork(boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {

			/*
			 * Start Add - 2013-06-07 - JPunza 
			 */  
			// Retrieve Parameters
			JobParameters parameters = getParameters();
			parmMaxErrors = parameters.getMAX_ERRORS();
			parmFilePath = parameters.getFILE_PATH().trim();
			parmFileName = parameters.getFILE_NAME().trim();     
			parmFeatConfig = parameters.getFEATURE_NAME();
			parmOptionTypeTestCntrl = parameters.getOPTION_TYPE_TEST_CNTRL().trim();       
			parmOptionTypeCurrSeason = parameters.getOPTION_TYPE_CURR_SEASON().trim();
			parmExcRequesterCorrCharType = parameters.getEX_REQUESTER_CORR_CHAR_TYPE();
			parmExcRequestDtCorrCharType = parameters.getEX_REQ_DT_CORR_CHAR_TYPE();    
			parmInExcCdCorrCharType = parameters.getIN_EX_CD_CORR_CHAR_TYPE();       
			parmInExcStatusCorrCharType = parameters.getIN_EX_STAT_CD_CORR_CHAR_TYPE();   
			parmInExcStatDtCorrCharType = parameters.getIN_EX_STAT_DT_CORR_CHAR_TYPE(); 
			parmExcRequesterUncorrCharType = parameters.getEX_REQUESTER_UNCORR_CHAR_TYPE();
			parmExcRequestDtUncorrCharType = parameters.getEX_REQ_DT_UNCORR_CHAR_TYPE();
			parmInExcCdUncorrCharType = parameters.getIN_EX_CD_UNCORR_CHAR_TYPE(); 
			parmInExcStatusUncorrCharType = parameters.getIN_EX_STAT_CD_UNCORR_CHAR_TYPE();         
			parmInExcStatDtUncorrCharType = parameters.getIN_EX_STAT_DT_UNCORR_CHAR_TYPE(); 
			parmDRMeterTestDtCharType = parameters.getDR_MTR_TEST_DT_CHAR_TYPE(); 
			parmMeteringExceptionCaseType = parameters.getMTR_EXCP_CASE_TYPE();
			parmServicePointCharType = parameters.getSP_ID_CHAR_TYPE(); 
			parmOwnerCharType = parameters.getOWNER_CHAR_TYPE(); 
			parmMeterBadgeCharType = parameters.getMETER_BADGE_CHAR_TYPE();
			parmCorrExcpCdCharType = parameters.getCORR_EXCP_CODE_CHAR_TYPE();            
			parmUncorrExcpCdCharType = parameters.getUNCORR_EXCP_CODE_CHAR_TYPE();
			parmCompletedCaseStatus = parameters.getCOMPLETED_CASE_STATUS().trim();

			/* MOL20130704 Begin */
			parmExcStatDtCorrCharType = parameters.getEX_STAT_DT_CORR_CHAR_TYPE(); 
			parmExcStatDtUncorrCharType = parameters.getEX_STAT_DT_UNCORR_CHAR_TYPE(); 
			/* MOL20130704 End */

			// KL20131113 - Start of code change for IM-041170
			paramTodoType = parameters.getTD_TYPE_CD();
			// KL20131113 - End of code change for IM-041170
			//Start Change -RGoke - 92435 - 11-25-2016
			parmMeterStNmbrCharType = parameters.getMTR_ST_NMBR_CHAR_TYPE();
			parmMeterStNmbrCharVal = parameters.getMTR_ST_NMBR_CHAR_VAL();
			//End Change -RGoke - 92435 - 11-25-2016
			inputFile = new File(parmFilePath, parmFileName);
			/*
			 * End Add - 2013-06-07 - JPunza 
			 */  
			openFile();
		}


		/**
		 * Execute a WorkUnit and provide result details.
		 * 
		 * @param unit - a ThreadWorkUnit
		 * @return a boolean that describes the success or failure of the work unit processing.
		 * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
		 * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
		 * @see com.splwg.base.api.batch.ThreadWorker#executeWorkUnitDetailedResult(com.splwg.base.api.batch.ThreadWorkUnit)
		 */        
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			charList = new ArrayList<CaseCharacteristic_DTO>();
			purgeTempTable();

			// Insert file records into staging table
			insertIntoStagingTable();
			// Validate file
			validateFileFormat();

			List<SQLResultRow> priorityExceptionList = getPriorityExceptionDetails();

			for(SQLResultRow meterTestRow : priorityExceptionList){  
				charList.clear();
				badgeNumber = meterTestRow.getString("BADGE_NBR").trim();
				spId = meterTestRow.getString("SP_ID").trim();
				exceptionCd = meterTestRow.getString("EXCEPTION_CD").trim();
				isUncorrected = meterTestRow.getBoolean("UNCORR_SW");                
				testPriority = meterTestRow.getInteger("TEST_PRIORITY");   
				numberOfDaysToPost = meterTestRow.getInteger("NBR_DAYS_POST");
				effDtFromFile = meterTestRow.getDate("MTR_TEST_DT");
				
				// KL20131113 - Start of Code Change for IM-041170
				//if(!validateRecord()){
				if(!validateRecord(unit)){
				// KL20131113 - End of Code Change for IM-041170
					continue;
				}
				Meter_Id meterId = isMeterNoLongerInstalled(badgeNumber,spId);
				if(isNull(meterId)){
					logWarning(CustomMessageRepository.ni0028_6MeterNoLongerInstalled(badgeNumber, spId));
					continue;
				}

				// Check whether an open metering exception already exists for the Meter/SP 
				SQLResultRow existingCaseRow = checkIfExceptionExists(spId);

				Date currentExcReqDtInCase = null;
				Date currentStatDtInCase = null;                
				if(notNull(existingCaseRow)){ // Open Metering Case exists  
					ToDoCase_Id caseRetrieved = (ToDoCase_Id)existingCaseRow.getId("CASE_ID", ToDoCase.class);
					SQLResultRow openCaseDetails = getOpenCaseDetails(caseRetrieved);
					String dateStr ="";
					@SuppressWarnings("unused")
					String exceptionCdCase = openCaseDetails.getString("EXC_CD");
					try{
						dateStr = openCaseDetails.getString("EXC_REQ_DT");
						//logger.info("Leky EXC_REQ_DT dateStr=" + dateStr);
						if(!isEmptyOrNull(dateStr)){
							currentExcReqDtInCase = Date.fromString(dateStr, new DateFormat(DATE_FORMAT));
						}
						dateStr = openCaseDetails.getString("STAT_DT");    
						//logger.info("Leky STAT_DT dateStr=" + dateStr);
						if(!isEmptyOrNull(dateStr)){
							currentStatDtInCase = Date.fromString(dateStr, new DateFormat(DATE_FORMAT));
						}
					}catch(DateFormatParseException e){
						logError(CustomMessageRepository.ni0028_6InvalidDate(dateStr.trim()));
						maxErrorHandling();
						continue;                  
					}
					if(notNull(currentStatDtInCase) && notNull(effDtFromFile) && effDtFromFile.isBefore(currentStatDtInCase)){
						logError(CustomMessageRepository.ni0028_6RecordWithOlderDate(caseRetrieved.getTrimmedValue(), effDtFromFile.toString(new DateFormat(DATE_FORMAT))));
						maxErrorHandling();
						continue;
					}
					if(isNull(currentExcReqDtInCase)){
						updateExceptionCase(caseRetrieved);
					}

					if(notNull(currentExcReqDtInCase) && notNull(effDtFromFile) && effDtFromFile.isAfter(currentExcReqDtInCase)){    // Compare corrected to corrected and uncorrected to uncorrected
						//logger.info("Leky exceptionCdCase=" + exceptionCdCase);
						//logger.info("Leky getTestPriorityOfCase(exceptionCdCase)=" + getTestPriorityOfCase(exceptionCdCase));
						//BigInteger testPriorityFromCase = new BigInteger(getTestPriorityOfCase(exceptionCdCase));
						//if(testPriority.compareTo(testPriorityFromCase) > 0){
						updateExceptionCase(caseRetrieved);
						//}
					}

				}else{ 
					SQLResultRow recentCaseDetails = getRecentCaseExceptionCode(spId, isUncorrected);
					String exceptionCdFromCase;
					DateTime caseCompletionDateTime;

					if(isNull(recentCaseDetails)){
						createExceptionCase();
					}else{
						exceptionCdFromCase = recentCaseDetails.getString("EXC_CD");                

						caseCompletionDateTime = recentCaseDetails.getDateTime("LOG_DTTM");
						if(exceptionCdFromCase.compareTo(exceptionCd) != 0){                            
							createExceptionCase();
						}else{
							if(caseCompletionDateTime.isBefore((getProcessDateTime().addDays(numberOfDaysToPost.negate().intValue())))){                               
								createExceptionCase();
							}else{// not more than X days
								continue;
							}

						}
					}
				}                
			}

			purgeTempTable();

			logInfo(CustomMessageRepository.ni0028_6NumberOfCasesCreated(numberOfCasesCreated.toString()));
			WorkUnitResult workUnitResult = new WorkUnitResult(true);
			workUnitResult.setUnitsProcessed(numberOfRecordsProcessed.intValue());
			workUnitResult.setUnitsInError(numberOfRecordsInError.intValue());
			return workUnitResult; 
		}   

		private void insertIntoStagingTable(){

			String detailRecord = null;
			BigInteger seqNum = BigInteger.ONE;
			openFile();
			while(notNull(detailRecord = readRecord())){
				StringBuilder insertFileDataString = null;
				PreparedStatement meterPrepStmt = null;

				String[] elements = detailRecord.split(PIPE_DELIMITER);
				if(elements.length < (TOTAL_NBR_FIELDS_IN_FILE-1)){
					addError(CustomMessageRepository.ni0028_6FileMustHaveEightFields());
				}

				String meterNumber = elements[4].trim();
				badgeNumber = meterNumber.substring(0, meterNumber.trim().length() - 4);
				String uncorrectedIndicator = meterNumber.substring(meterNumber.length() - 3, meterNumber.length() - 2);
				if(uncorrectedIndicator.compareTo("U") == 0){
					isUncorrected = Bool.TRUE;
				}else{
					isUncorrected = Bool.FALSE;
				}
				spId = elements[3].trim().substring(0, SP_ID_LENGTH);
				testTypeInFile = elements[1].trim();
				effectiveDtStr = elements[5].trim();

				try {
					effDtFromFile = Date.fromString(effectiveDtStr, new DateFormat(DATE_FORMAT));
				} catch (DateFormatParseException e) {
					//logger.info("Leky - catch effDtFromFile!!!");
					logError(CustomMessageRepository.ni0028_6InvalidDate(effectiveDtStr.trim()));
					maxErrorHandling();
					continue;
				}

				try{
					insertFileDataString = new StringBuilder();
					insertFileDataString.append("INSERT INTO CM_MTR_EXC (BADGE_NBR, SP_ID, TEST_PRIORITY, TEST_TYPE, EXCEPTION_CD, NBR_DAYS_POST,UNCORR_SW,SEQ_NUM, IGNORE_SW, MTR_TEST_DT, BATCH_NBR ) ");
					insertFileDataString.append("VALUES (:badgeNbr,:spId,:testPriority,:testType,:excCd,:nbrDaysPost,:uncorrSw,:seqNum, :ignoredSw,:mtrTestDt, :batchNbr) ");
					//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					//meterPrepStmt = createPreparedStatement(insertFileDataString.toString()); 
					meterPrepStmt = createPreparedStatement(insertFileDataString.toString(), getClass().getName()); 
					//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
					meterPrepStmt.bindString("badgeNbr", badgeNumber,badgeNumber);
					meterPrepStmt.bindString("spId", spId, spId);
					meterPrepStmt.bindBigInteger("testPriority", BigInteger.ZERO);
					meterPrepStmt.bindString("testType", testTypeInFile,testTypeInFile);
					meterPrepStmt.bindString("excCd", "","excCd");
					meterPrepStmt.bindBigInteger("nbrDaysPost", BigInteger.ZERO);
					meterPrepStmt.bindBoolean("uncorrSw", isUncorrected);
					meterPrepStmt.bindBigInteger("seqNum", seqNum);
					meterPrepStmt.bindBoolean("ignoredSw", Bool.FALSE);
					meterPrepStmt.bindDate("mtrTestDt", effDtFromFile);
					meterPrepStmt.bindBigInteger("batchNbr", getBatchNumber());
					meterPrepStmt.execute();
				}finally{
					if(notNull(meterPrepStmt)){
						meterPrepStmt.close();
					}
				}
				seqNum = seqNum.add(BigInteger.ONE);
			}
			closeFile();
		}

		/**
		 * This method validates the input file against a specific file format. 
		 * and checks the detail record count present in trailer record and total number of detail record.
		 */
		@SuppressWarnings("unchecked")
		private void validateFileFormat() {

			BigInteger numberOfTestsFound = BigInteger.ZERO;

			CmFeatureConfigurationRetriever_Impl featConfigurationRetriever = new CmFeatureConfigurationRetriever_Impl();
			featConfigurationRetriever.setParmOptType(parmOptionTypeCurrSeason);
			featConfigurationRetriever.setParmWFMName(parmFeatConfig);
			currentSeasonInFeatConfig = featConfigurationRetriever.getMaxSequenceOptionValue().trim();
			if(isEmptyOrNull(currentSeasonInFeatConfig)){// Current Season is not defined in the DataRaker Test Control Feature Configuration
				addError(CustomMessageRepository.ni0028_6CurrentSeasonNotDefinedOnFC(parmFeatConfig.getId().getTrimmedValue()));
			}
			if(currentSeasonInFeatConfig.compareTo(CURRENT_SEASON_SUMMER) !=0 && currentSeasonInFeatConfig.compareTo(CURRENT_SEASON_WINTER) !=0){// Current Season can have only S or W as values
				addError(CustomMessageRepository.ni0028_6InvalidCurrentSeason(currentSeasonInFeatConfig, parmFeatConfig.getId().getTrimmedValue()));
			}

			// Get the list of TestTypes from Feature Configuration
			CmFeatureConfigurationRetriever_Impl featureConfigurationRetriever = new CmFeatureConfigurationRetriever_Impl();
			featureConfigurationRetriever.setParmOptType(parmOptionTypeTestCntrl);
			featureConfigurationRetriever.setParmWFMName(parmFeatConfig);
			testTypeList = featureConfigurationRetriever.getListOfOptionValues();
			if(testTypeList.isEmpty()){ // No Test Types configured in Feature Configuration
				addError(CustomMessageRepository.ni0028_6NoTestTypesDefinedOnFC(parmFeatConfig.getId().getTrimmedValue()));
			}
			for(String testTypeDetails : testTypeList){

				String[] testControlData = testTypeDetails.split(COMMA_DELIMITER);
				validateTestTypeControlData(testControlData);

				String testType = testControlData[CNTRL_TEST_TYPE_INDEX].trim();
				String minRecordThreshold = testControlData[CNTRL_MIN_THRES_INDEX].trim();
				String maxRecordThreshold = testControlData[CNTRL_MAX_THRES_INDEX].trim();                

				if(currentSeasonInFeatConfig.compareTo(CURRENT_SEASON_WINTER) == 0 && isEmptyOrNull(testControlData[CNTRL_WINTER_EXC_INDEX].trim())){// If Current Season is Winter but Test Type should not be processed in Winter
					ignoreTestType(testType);
					addWarning(CustomMessageRepository.ni0028_6NoExceptionCdDefinedForCurrentSeason(currentSeasonInFeatConfig, testType));
					continue;
				}else if(currentSeasonInFeatConfig.compareTo(CURRENT_SEASON_SUMMER) == 0 && isEmptyOrNull(testControlData[CNTRL_SUMMER_EXC_INDEX].trim())){// If Current Season is Summer but Test Type should not be processed in Summer
					ignoreTestType(testType);
					addWarning(CustomMessageRepository.ni0028_6NoExceptionCdDefinedForCurrentSeason(currentSeasonInFeatConfig, testType));
					continue;
				}
				if(testControlData[CNTRL_BYPASS_TEST_INDEX].trim().compareTo(BYPASS_TEST_FLG_Y) == 0){
					ignoreTestType(testType);
					raiseBypassWarning(testType);
					continue;
				}

				// Count records per Test Type
				StringBuilder getCountString = new StringBuilder();
				// CCB v2.6 Upgrade - 2018-07-25 - Start Change
				//getCountString.append("SELECT COUNT(1) CNT FROM CM_MTR_EXC WHERE TRIM(TEST_TYPE) = :testType AND BATCH_NBR = :batchNbr ");
				// Defect 4172199 - 2018-12-17 - Start Change
				//getCountString.append("SELECT COUNT(1) CNT FROM CM_MTR_EXC WHERE TEST_TYPE = :testType AND BATCH_NBR = :batchNbr ");
				getCountString.append("SELECT COUNT(1) CNT FROM CM_MTR_EXC WHERE TRIM(TEST_TYPE) = :testType AND BATCH_NBR = :batchNbr ");
				// Defect 4172199 - 2018-12-17 - End Change
				// CCB v2.6 Upgrade - 2018-07-25 - End Change
				//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				//PreparedStatement countPrepStmt = createPreparedStatement(getCountString.toString()); 
				PreparedStatement countPrepStmt = createPreparedStatement(getCountString.toString(), getClass().getName()); 
				//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				countPrepStmt.bindString("testType", testType.trim(),"testType");
				countPrepStmt.bindBigInteger("batchNbr", getBatchNumber());
				SQLResultRow row = countPrepStmt.firstRow();
				numberOfTestsFound = row.getInteger("CNT");
				countPrepStmt.close();

				if(numberOfTestsFound.compareTo(BigInteger.ZERO) == 0){
					if(testControlData[CNTRL_NO_TEST_RESPONSE_INDEX].trim().compareTo("A") == 0){
						// Aborting process since no Meter Test of a %1 Test Type exists in the file 
						addError(CustomMessageRepository.ni0028_6NoTestofTypeInFile(testType));
					}else{
						logWarning(CustomMessageRepository.ni0028_6NoTestofTypeInFile(testType));
						continue;
					}
				}
				if(numberOfTestsFound.compareTo(new BigInteger(minRecordThreshold)) < 0 || numberOfTestsFound.compareTo(new BigInteger(maxRecordThreshold)) > 0){
					// Ignore all meter tests with this Test Type
					ignoreTestType(testType);
					addWarning(CustomMessageRepository.ni0028_6NumMtrTestNotInMinMaxforTestTyp(numberOfTestsFound.toString(),minRecordThreshold, maxRecordThreshold, testType));
					continue;
				}
				// When test type is not ignored
				insertTestTypeDetails(testControlData);
			}
			// Retrieve any test which does not have corresponding test type in Feature config (non ignored but still priority is empty)
			StringBuilder getMeterTestString = new StringBuilder();
			getMeterTestString.append("SELECT TEST_TYPE ");
			getMeterTestString.append("FROM CM_MTR_EXC E ");
			getMeterTestString.append("WHERE TRIM(E.IGNORE_SW) = 'N' ");
			getMeterTestString.append("AND (TRIM(E.TEST_PRIORITY) IS NULL OR E.TEST_PRIORITY = 0) AND BATCH_NBR = :batchNbr"); 
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement meterTestPrepStmt = createPreparedStatement(getMeterTestString.toString());
			PreparedStatement meterTestPrepStmt = createPreparedStatement(getMeterTestString.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			meterTestPrepStmt.bindBigInteger("batchNbr", getBatchNumber());
			SQLResultRow row = meterTestPrepStmt.firstRow();
			meterTestPrepStmt.close();
			if(notNull(row)){
				addError(CustomMessageRepository.ni0028_6MissingTestTypeInFC(row.getString("TEST_TYPE")));
			}
		}   

		// KL20131113 - Start of Code Change for IM-041170
		//private boolean validateRecord(){
		private boolean validateRecord(ThreadWorkUnit unit){
		// KL20131113 - End of Code Change for IM-041170

			/*
			 * Start Delete - 2013-05-14 - JPunza 
			 */
			//UnitOfMeasure_Id uomCd;            
			//meterId = null;
			/*
			 * End Delete - 2013-05-14 - JPunza 
			 */
			// Validate Meter
			StringBuilder getMeterString = new StringBuilder();
			//Start Change -RGoke - 92435 - 11-25-2016
			//getMeterString.append("SELECT MTR.MTR_ID FROM CI_MTR MTR WHERE TRIM(MTR.BADGE_NBR) = :badgeNumber");
			// CCB v2.6 Upgrade - 2018-07-25 - Start Change
			//getMeterString.append("SELECT MTR.MTR_ID FROM CI_MTR MTR WHERE TRIM(MTR.BADGE_NBR) = :badgeNumber");
			getMeterString.append("SELECT MTR.MTR_ID FROM CI_MTR MTR WHERE MTR.BADGE_NBR = :badgeNumber");
			// CCB v2.6 Upgrade - 2018-07-25 - End Change
			getMeterString.append(" AND EXISTS (SELECT * FROM CI_MTR_CHAR MC WHERE MTR.MTR_ID = MC.MTR_ID AND CHAR_TYPE_CD = :parmMeterStNmbrCharType AND CHAR_VAL = '"+parmMeterStNmbrCharVal+"')");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement meterPrepStmt = createPreparedStatement(getMeterString.toString()); 
			PreparedStatement meterPrepStmt = createPreparedStatement(getMeterString.toString(), getClass().getName()); 
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			meterPrepStmt.bindStringProperty("badgeNumber", Meter.properties.badgeNumber,badgeNumber.trim());
			meterPrepStmt.bindEntity("parmMeterStNmbrCharType",parmMeterStNmbrCharType);	
			//End Change -RGoke - 92435 - 11-25-2016
			List<SQLResultRow> list = meterPrepStmt.list();
			meterPrepStmt.close();
			if(!list.isEmpty()){
				if(list.size() > 1){
					// KL20131113 - Start of Code Change for IM-041170
					//addError(CustomMessageRepository.ni0028_6BadgeNumHasMultipleMeters(badgeNumber));
					if(!hasToDoInOpenStatus(badgeNumber)){
						logErrorOrCreateToDo(CustomMessageRepository.ni0028_6BadgeNumHasMultipleMeters(badgeNumber), unit);
					}
					return false;
					// KL20131113 - Start of Code Change for IM-041170
				}
			
			
				/*
				 * Start Delete - 2013-05-14 - JPunza 
				 */
				//meterId = (Meter_Id)list.iterator().next().getId("MTR_ID", Meter.class);
				/*
				 * End Delete - 2013-05-14 - JPunza 
				 */
			}else{
				addWarning(CustomMessageRepository.ni0028_6InvalidBadgeNumberInFile(badgeNumber));
				return false;
			}
			

			/*
			 * Start Delete - 2013-05-14 - JPunza 
			 */
			////Validate register            
			//if(isUncorrected.isTrue()){
			//    uomCd = parmUncorrUomCd.getId();
			//}else{
			//    uomCd = parmCorrUomCd.getId();
			//}
			//
			//StringBuilder getRegString = new StringBuilder();
			//getRegString.append("SELECT REG.REG_ID FROM CI_REG REG WHERE REG.MTR_ID = :mtrId AND REG.UOM_CD = :uomCd");
			//
			//PreparedStatement regPrepStmt = createPreparedStatement(getRegString.toString()); 
			//regPrepStmt.bindId("mtrId", meterId);            
			//regPrepStmt.bindId("uomCd", uomCd);            
			//SQLResultRow row = regPrepStmt.firstRow();
			//regPrepStmt.close();
			//if(isNull(row)){ 
			//    addWarning(CustomMessageRepository.ni0028_6InvalidRegisterInFile(badgeNumber,uomCd.getTrimmedValue()));
			//    return false;
			//}
			/*
			 * End Delete - 2013-05-14 - JPunza 
			 */

			// Validate SP
			ServicePoint_Id servicePointId = new ServicePoint_Id(spId);
			if(isNull(servicePointId.getEntity())){
				addWarning(CustomMessageRepository.ni0028_6InvalidSPIdInFile(spId));
				return false;
			}
			return true;
		}
		private void validateTestTypeControlData(String[] testControlData) {

			if(testControlData.length < TOTAL_LENGTH_OF_TEST_PARAMS){
				addError(CustomMessageRepository.ni0028_6NotAllTestParamsGivenInFeatConfig(parmFeatConfig.getId().getTrimmedValue()));
			}
			String testType = testControlData[CNTRL_TEST_TYPE_INDEX].trim();
			if(isEmptyOrNull(testType)){
				addError(CustomMessageRepository.ni0028_6TestTypeIsRequiredInFeatConfig(parmFeatConfig.getId().getTrimmedValue()));
			}
			String testPriorityStr = testControlData[CNTRL_TEST_PRIORITY_INDEX].trim();
			validateNumParam(testPriorityStr,CustomMessageRepository.ni0028_6ParamNameTestPriority().getMessageText(), testType);

			String bypassTest = testControlData[CNTRL_BYPASS_TEST_INDEX].trim();
			if(isEmptyOrNull(bypassTest)){
				addError(CustomMessageRepository.ni0028_6FieldRequiredInFeatConfig(parmFeatConfig.getId().getTrimmedValue(), CustomMessageRepository.ni0028_6ParamNameBypassTestFlg().getMessageText(), testType));
			}else{
				if(bypassTest.compareTo(BYPASS_TEST_FLG_Y) != 0 && bypassTest.compareTo(BYPASS_TEST_FLG_N) != 0){
					addError(CustomMessageRepository.ni0028_6BypassTestFlgIsInvalidInFeatConfig(bypassTest,testType));
				}
			}
			String minRecordThreshold = testControlData[CNTRL_MIN_THRES_INDEX].trim();
			/*
			 * Start Change - 2013-05-14 - JPunza 
			 */
			 //validateNumParam(minRecordThreshold, CustomMessageRepository.ni0028_6ParamNameMinThreshold().getMessageText(), testType);
			validateNumParamMin(minRecordThreshold, CustomMessageRepository.ni0028_6ParamNameMinThreshold().getMessageText(), testType);
			/*
			 * End Change - 2013-05-14 - JPunza 
			 */

			String maxRecordThreshold = testControlData[CNTRL_MAX_THRES_INDEX].trim();
			validateNumParam(maxRecordThreshold, CustomMessageRepository.ni0028_6ParamNameMaxThreshold().getMessageText(), testType);

			String nbrDaysToPost = testControlData[CNTRL_NUM_DAYS_POST_INDEX].trim();
			validateNumParam(nbrDaysToPost, CustomMessageRepository.ni0028_6ParamNameNoOfDaysPost().getMessageText(), testType);

			String noTestResponse = testControlData[CNTRL_NO_TEST_RESPONSE_INDEX].trim();
			if(isEmptyOrNull(noTestResponse)){
				addError(CustomMessageRepository.ni0028_6FieldRequiredInFeatConfig(parmFeatConfig.getId().getTrimmedValue(), CustomMessageRepository.ni0028_6ParamNameNoTestResponse().getMessageText(), testType));
			}else{
				if(noTestResponse.compareTo(NO_TEST_RESP_ABORT) != 0 && noTestResponse.compareTo(NO_TEST_RESP_CONTINUE) != 0){
					addError(CustomMessageRepository.ni0028_6NoTestRespInvalidInFeatConfig(noTestResponse,testType));
				}
			}
		}

		/*
		 * Start Add - 2013-05-14 - JPunza 
		 */
		private void validateNumParamMin(String numStr, String paramName, String testType){
			BigInteger numValue = BigInteger.ZERO;
			if(isEmptyOrNull(numStr)){
				addError(CustomMessageRepository.ni0028_6FieldRequiredInFeatConfig(parmFeatConfig.getId().getTrimmedValue(), paramName, testType));
			}
			try{
				numValue = new BigInteger(numStr);
			}catch(NumberFormatException ex){
				//Must be a valid number                
				addError(CustomMessageRepository.ni0028_6InvalidNumberParameter(paramName, numStr, testType));
			}
			if(numValue.compareTo(BigInteger.ZERO) < 0){
				addError(CustomMessageRepository.ni0028_6NumberShouldEqualOrGreaterThanZero(paramName));
			}
		}
		/*
		 * End Add - 2013-05-14 - JPunza 
		 */

		private void validateNumParam(String numStr, String paramName, String testType){
			BigInteger numValue = BigInteger.ZERO;
			if(isEmptyOrNull(numStr)){
				addError(CustomMessageRepository.ni0028_6FieldRequiredInFeatConfig(parmFeatConfig.getId().getTrimmedValue(), paramName, testType));
			}
			try{
				numValue = new BigInteger(numStr);
			}catch(NumberFormatException ex){
				//Must be a valid number                
				addError(CustomMessageRepository.ni0028_6InvalidNumberParameter(paramName, numStr, testType));
			}
			if(numValue.compareTo(BigInteger.ZERO) <= 0){
				addError(CustomMessageRepository.ni0028_6NumberShouldBGreaterThanZero(paramName));
			}
		}

		private void ignoreTestType(String testType){
			StringBuilder updateString = null;
			PreparedStatement updatePrepStmt = null;
			try{
				updateString = new StringBuilder();
				// CCB v2.6 Upgrade - 2018-07-25 - Start Change
				//updateString.append("UPDATE CM_MTR_EXC SET IGNORE_SW = 'Y' WHERE TRIM(TEST_TYPE) = :testType AND BATCH_NBR = :batchNbr");
				// Defect 4172199 - 2018-12-17 - Start Change
				//updateString.append("UPDATE CM_MTR_EXC SET IGNORE_SW = 'Y' WHERE TEST_TYPE = :testType AND BATCH_NBR = :batchNbr");
				updateString.append("UPDATE CM_MTR_EXC SET IGNORE_SW = 'Y' WHERE TRIM(TEST_TYPE) = :testType AND BATCH_NBR = :batchNbr");
				// Defect 4172199 - 2018-12-17 - End Change
				// CCB v2.6 Upgrade - 2018-07-25 - End Change

				//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				//updatePrepStmt = createPreparedStatement(updateString.toString()); 
				updatePrepStmt = createPreparedStatement(updateString.toString(), getClass().getName()); 
				//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				updatePrepStmt.bindString("testType", testType,testType);
				updatePrepStmt.bindBigInteger("batchNbr", getBatchNumber());
				updatePrepStmt.executeUpdate();                
			}finally{
				if(notNull(updatePrepStmt)){
					updatePrepStmt.close();
				}
			}
		}
		private void raiseBypassWarning(String testType){
			StringBuilder getMeterTestString = new StringBuilder();
			getMeterTestString.append("SELECT E.BADGE_NBR ");
			getMeterTestString.append("FROM CM_MTR_EXC E ");
			// CCB v2.6 Upgrade - 2018-07-25 - Start Change
			//getMeterTestString.append("WHERE TRIM(TEST_TYPE) = :testType AND BATCH_NBR = :batchNbr");
			// Defect 4172199 - 2018-12-17 - Start Change
			//getMeterTestString.append("WHERE TEST_TYPE = :testType AND BATCH_NBR = :batchNbr");
			getMeterTestString.append("WHERE TRIM(TEST_TYPE) = :testType AND BATCH_NBR = :batchNbr");
			// Defect 4172199 - 2018-12-17 - End Change
			// CCB v2.6 Upgrade - 2018-07-25 - End Change
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement meterTestPrepStmt = createPreparedStatement(getMeterTestString.toString());
			PreparedStatement meterTestPrepStmt = createPreparedStatement(getMeterTestString.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			meterTestPrepStmt.bindString("testType", testType,testType);
			meterTestPrepStmt.bindBigInteger("batchNbr", getBatchNumber());
			List<SQLResultRow> list = meterTestPrepStmt.list();
			meterTestPrepStmt.close();

			for(SQLResultRow row : list){
				addWarning(CustomMessageRepository.ni0028_6TestBypassedAsConfigInFC(row.getString("BADGE_NBR"), testType));
			}
		}
		private void insertTestTypeDetails(String[] testControlData){
			StringBuilder updateString = null;
			PreparedStatement updatePrepStmt = null;
			try{
				updateString = new StringBuilder();
				// CCB v2.6 Upgrade - 2018-07-25 - Start Change
				// Defect 4172199 - 2018-12-17 - Start Change
				//updateString.append("UPDATE CM_MTR_EXC SET TEST_PRIORITY = :priority, EXCEPTION_CD = :excCd, NBR_DAYS_POST = :nbrDaysPost, IGNORE_SW = 'N' WHERE TRIM(TEST_TYPE) = :testType AND BATCH_NBR = :batchNbr");
				//updateString.append("UPDATE CM_MTR_EXC SET TEST_PRIORITY = :priority, EXCEPTION_CD = :excCd, NBR_DAYS_POST = :nbrDaysPost, IGNORE_SW = 'N' WHERE TEST_TYPE = :testType AND BATCH_NBR = :batchNbr");
				updateString.append("UPDATE CM_MTR_EXC SET TEST_PRIORITY = :priority, EXCEPTION_CD = :excCd, NBR_DAYS_POST = :nbrDaysPost, IGNORE_SW = 'N' WHERE TRIM(TEST_TYPE) = :testType AND BATCH_NBR = :batchNbr");
				// Defect 4172199 - 2018-12-17 - End Change
				// CCB v2.6 Upgrade - 2018-07-25 - End Change
				//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				//updatePrepStmt = createPreparedStatement(updateString.toString());
				updatePrepStmt = createPreparedStatement(updateString.toString(), getClass().getName());
				//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				updatePrepStmt.bindString("priority", testControlData[CNTRL_TEST_PRIORITY_INDEX].trim(),"priority");
				if(currentSeasonInFeatConfig.compareTo(CURRENT_SEASON_WINTER) == 0){
					updatePrepStmt.bindString("excCd", testControlData[CNTRL_WINTER_EXC_INDEX].trim(),"excCd");
				}else{
					updatePrepStmt.bindString("excCd", testControlData[CNTRL_SUMMER_EXC_INDEX].trim(),"excCd");
				}
				updatePrepStmt.bindString("nbrDaysPost", testControlData[CNTRL_NUM_DAYS_POST_INDEX].trim(),"nbrDaysPost");
				updatePrepStmt.bindString("testType", testControlData[CNTRL_TEST_TYPE_INDEX].trim(),"testType");
				updatePrepStmt.bindBigInteger("batchNbr", getBatchNumber());
				updatePrepStmt.executeUpdate();                
			}finally{
				if(notNull(updatePrepStmt)){
					updatePrepStmt.close();
				}
			}               
		}

		private List<SQLResultRow> getPriorityExceptionDetails(){
			StringBuilder getMeterTestString = new StringBuilder();
			getMeterTestString.append("SELECT E.BADGE_NBR,E.SP_ID, E.EXCEPTION_CD,E.UNCORR_SW,E.TEST_PRIORITY, E.NBR_DAYS_POST, E.MTR_TEST_DT ");
			getMeterTestString.append("FROM CM_MTR_EXC E ");
			getMeterTestString.append("WHERE E.BATCH_NBR = :batchNbr ");
			getMeterTestString.append("AND E.TEST_PRIORITY = (SELECT MIN(TEST_PRIORITY) FROM CM_MTR_EXC WHERE BADGE_NBR =  E.BADGE_NBR AND TRIM(IGNORE_SW) != 'Y' AND BATCH_NBR = :batchNbr) "); 

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement meterTestPrepStmt = createPreparedStatement(getMeterTestString.toString());
			PreparedStatement meterTestPrepStmt = createPreparedStatement(getMeterTestString.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			meterTestPrepStmt.bindBigInteger("batchNbr", getBatchNumber());
			List<SQLResultRow> list = meterTestPrepStmt.list();
			meterTestPrepStmt.close();
			return list;         
		}
		/**
		 * This method opens a buffered reader for input file
		 *
		 */
		private void openFile() {

			try {                          
				inputBufferReader = new BufferedReader(new FileReader(inputFile));                    
			} catch (IOException e) {                
				throw new RunAbortedException(CustomMessageRepository.ni0028_6ErrorInFile(e.getMessage().trim()));                                     
			} 
		}


		/**
		 * This method closes a buffered reader for input file
		 *
		 */
		private void closeFile() {

			try {
				if(notNull(inputBufferReader))
					inputBufferReader.close();           
			} catch (IOException e) {
				throw new RunAbortedException(CustomMessageRepository.ni0028_6ErrorInFile(e.getMessage().trim()));                                      
			}
		}        

		/**
		 * This method handles Max Error handling
		 */
		private void maxErrorHandling() {
			numberOfRecordsInError = numberOfRecordsInError.add(BigInteger.ONE);

			if (notNull(parmMaxErrors)) {
				if (numberOfRecordsInError.intValue() >= parmMaxErrors.intValue()) {
					throw new RunAbortedException(CustomMessageRepository.ni0028_6MaxErrorCountReached(parmMaxErrors.toString()));
				}
			}
		}   

		private Meter_Id isMeterNoLongerInstalled(String badgeNumber, String spId){
			StringBuilder getMeterString = new StringBuilder();
			getMeterString.append("SELECT MTR.MTR_ID, HIST.SP_ID ");
			getMeterString.append("FROM CI_MTR MTR, CI_SP_MTR_EVT EVNT ");
			getMeterString.append(", CI_MTR_CONFIG CONFIG ");
			getMeterString.append(", CI_MR MR ");
			getMeterString.append(", CI_SP_MTR_HIST HIST "); 
			// CCB v2.6 Upgrade - 2018-07-25 - Start Change
			//getMeterString.append("WHERE TRIM(MTR.BADGE_NBR) = :badgeNumber ");
			getMeterString.append("WHERE MTR.BADGE_NBR = :badgeNumber ");
			// CCB v2.6 Upgrade - 2018-07-25 - End Change
			getMeterString.append("AND CONFIG.MTR_ID = MTR.MTR_ID ");
			getMeterString.append("AND CONFIG.EFF_DTTM <= :processDateTime ");
			getMeterString.append("AND EVNT.SP_MTR_EVT_FLG = :install ");
			getMeterString.append("AND HIST.SP_ID = :spId ");
			getMeterString.append("AND HIST.SP_MTR_HIST_ID = EVNT.SP_MTR_HIST_ID ");
			getMeterString.append("AND HIST.MTR_CONFIG_ID = CONFIG.MTR_CONFIG_ID ");
			getMeterString.append("AND (HIST.REMOVAL_DTTM IS NULL OR HIST.REMOVAL_DTTM > :processDateTime) ");
			getMeterString.append("AND EVNT.MR_ID = MR.MR_ID ");
			getMeterString.append("AND MR.READ_DTTM <= :processDateTime ");

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement meterPrepStmt = createPreparedStatement(getMeterString.toString());
			PreparedStatement meterPrepStmt = createPreparedStatement(getMeterString.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			meterPrepStmt.bindStringProperty("badgeNumber", Meter.properties.badgeNumber,badgeNumber);
			meterPrepStmt.bindDateTime("processDateTime", getProcessDateTime());
			meterPrepStmt.bindLookup("install", ServicePointMeterEventTypeLookup.constants.INSTALL);
			meterPrepStmt.bindId("spId", new ServicePoint_Id(spId));
			SQLResultRow row = meterPrepStmt.firstRow();
			meterPrepStmt.close();
			if(isNull(row)){ 
				return null;
			}else{                
				return (Meter_Id)row.getId("MTR_ID", Meter.class);
			}            
		}

		private SQLResultRow checkIfExceptionExists(String spId){
			CharacteristicTypeLookup characteristicTypeLookup = parmServicePointCharType.getCharacteristicType();
			StringBuilder getExcString = new StringBuilder();
			getExcString.append("SELECT CH.CASE_ID FROM CI_CASE CSE, CI_CASE_CHAR CH ");
			getExcString.append("WHERE CH.CASE_ID = CSE.CASE_ID ");
			getExcString.append(appendCharConditions(characteristicTypeLookup));             
			getExcString.append("AND CSE.CASE_COND_FLG = :open "); 
			// Start changes IM-036038
			getExcString.append("AND CSE.CASE_TYPE_CD = :caseType ");
			// End changes IM-036038
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement getExcPrepStmt = createPreparedStatement(getExcString.toString());
			PreparedStatement getExcPrepStmt = createPreparedStatement(getExcString.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			getExcPrepStmt.bindId("characteristicType", parmServicePointCharType.getId());
			if(characteristicTypeLookup.isPredefinedValue()){
				getExcPrepStmt.bindStringProperty("charValue", CaseCharacteristic.properties.characteristicValue ,spId.trim());    
			}else if(characteristicTypeLookup.isForeignKeyValue()){
				getExcPrepStmt.bindStringProperty("charValue", CaseCharacteristic.properties.characteristicValueForeignKey1,spId.trim());         
			}else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
				getExcPrepStmt.bindStringProperty("charValue", CaseCharacteristic.properties.adhocCharacteristicValue, spId.trim());
			}
			getExcPrepStmt.bindLookup("open", CaseConditionLookup.constants.OPEN);
			// Start changes IM-036038
			getExcPrepStmt.bindId("caseType", parmMeteringExceptionCaseType.getId());
			// End changes IM-036038

			SQLResultRow row = getExcPrepStmt.firstRow();
			getExcPrepStmt.close();

			return row;
		}

		private SQLResultRow getOpenCaseDetails(ToDoCase_Id caseId){
			StringBuilder getExcString = new StringBuilder();
			/* MOL20130704 Begin
            getExcString.append("SELECT NVL(TRIM(CASECH2.ADHOC_CHAR_VAL),NVL(TRIM(CASECH2.CHAR_VAL),TRIM(CASECH2.CHAR_VAL_FK1))) EXC_REQ_DT ");
            getExcString.append(",NVL(TRIM(CASECH3.ADHOC_CHAR_VAL),NVL(TRIM(CASECH3.CHAR_VAL),TRIM(CASECH3.CHAR_VAL_FK1))) EXC_CD ");
            getExcString.append(",NVL(TRIM(CASECH4.ADHOC_CHAR_VAL),NVL(TRIM(CASECH4.CHAR_VAL),TRIM(CASECH4.CHAR_VAL_FK1))) STAT_DT ");
            getExcString.append("FROM CI_CASE_CHAR CASECH2, CI_CASE_CHAR CASECH3, CI_CASE_CHAR CASECH4 ");
            getExcString.append("WHERE CASECH2.CASE_ID = :caseId ");
            getExcString.append("AND CASECH2.CHAR_TYPE_CD = :excRequestDateCharType ");
            getExcString.append("AND CASECH2.SEQ_NUM = (SELECT MAX(SEQ_NUM) FROM CI_CASE_CHAR WHERE CASE_ID = CASECH2.CASE_ID AND CHAR_TYPE_CD = CASECH2.CHAR_TYPE_CD) ");            
            getExcString.append("AND CASECH3.CASE_ID = CASECH2.CASE_ID ");
            getExcString.append("AND CASECH3.CHAR_TYPE_CD = :exceptionCdCharType ");
            getExcString.append("AND CASECH3.SEQ_NUM = (SELECT MAX(SEQ_NUM) FROM CI_CASE_CHAR WHERE CASE_ID = CASECH3.CASE_ID AND CHAR_TYPE_CD = CASECH3.CHAR_TYPE_CD) ");
            getExcString.append("AND CASECH4.CASE_ID = CASECH2.CASE_ID ");
            getExcString.append("AND CASECH4.CHAR_TYPE_CD = :statusDtCharType ");
            getExcString.append("AND CASECH4.SEQ_NUM = (SELECT MAX(SEQ_NUM) FROM CI_CASE_CHAR WHERE CASE_ID = CASECH4.CASE_ID AND CHAR_TYPE_CD = CASECH4.CHAR_TYPE_CD) ");
			 */

			getExcString.append(" SELECT CCASE.CASE_ID ");
			getExcString.append("   ,NVL(TRIM(CASECH2.ADHOC_CHAR_VAL),NVL(TRIM(CASECH2.CHAR_VAL),TRIM(CASECH2.CHAR_VAL_FK1))) EXC_REQ_DT ");
			getExcString.append("   ,NVL(TRIM(CASECH3.ADHOC_CHAR_VAL),NVL(TRIM(CASECH3.CHAR_VAL),TRIM(CASECH3.CHAR_VAL_FK1))) EXC_CD ");
			getExcString.append("   ,NVL(TRIM(CASECH4.ADHOC_CHAR_VAL),NVL(TRIM(CASECH4.CHAR_VAL),TRIM(CASECH4.CHAR_VAL_FK1))) STAT_DT ");
			getExcString.append(" FROM CI_CASE CCASE ");
			getExcString.append("   ,(SELECT CASECH2.CASE_ID, CASECH2.ADHOC_CHAR_VAL, CASECH2.CHAR_VAL, CASECH2.CHAR_VAL_FK1 ");
			getExcString.append("     FROM CI_CASE_CHAR CASECH2 ");
			getExcString.append("     WHERE CASECH2.CHAR_TYPE_CD = :excRequestDateCharType ");
			getExcString.append("       AND CASECH2.SEQ_NUM      = (SELECT MAX(SEQ_NUM) ");
			getExcString.append("                                   FROM CI_CASE_CHAR ");
			getExcString.append("                                   WHERE CASE_ID    = CASECH2.CASE_ID ");
			getExcString.append("                                     AND CHAR_TYPE_CD = CASECH2.CHAR_TYPE_CD) ");
			getExcString.append("    ) CASECH2 ");
			getExcString.append("   ,(SELECT CASECH3.CASE_ID, CASECH3.ADHOC_CHAR_VAL, CASECH3.CHAR_VAL, CASECH3.CHAR_VAL_FK1 ");
			getExcString.append("     FROM CI_CASE_CHAR CASECH3 ");
			getExcString.append("     WHERE CASECH3.CHAR_TYPE_CD = :exceptionCdCharType ");
			getExcString.append("       AND CASECH3.SEQ_NUM      = (SELECT MAX(SEQ_NUM) ");
			getExcString.append("                                   FROM CI_CASE_CHAR ");
			getExcString.append("                                   WHERE CASE_ID    = CASECH3.CASE_ID ");
			getExcString.append("                                     AND CHAR_TYPE_CD = CASECH3.CHAR_TYPE_CD) ");
			getExcString.append("    ) CASECH3 ");
			getExcString.append("   ,(SELECT CASECH4.CASE_ID, CASECH4.ADHOC_CHAR_VAL, CASECH4.CHAR_VAL, CASECH4.CHAR_VAL_FK1 ");
			getExcString.append("     FROM CI_CASE_CHAR CASECH4 ");
			getExcString.append("     WHERE CASECH4.CHAR_TYPE_CD = :statusDtCharType ");
			getExcString.append("       AND CASECH4.SEQ_NUM      = (SELECT MAX(SEQ_NUM) ");
			getExcString.append("                                   FROM CI_CASE_CHAR ");
			getExcString.append("                                   WHERE CASE_ID    = CASECH4.CASE_ID ");
			getExcString.append("                                     AND CHAR_TYPE_CD = CASECH4.CHAR_TYPE_CD) ");
			getExcString.append("    ) CASECH4 ");
			getExcString.append(" WHERE CCASE.CASE_ID    = :caseId ");
			getExcString.append(" AND CCASE.CASE_ID = CASECH2.CASE_ID (+) ");
			getExcString.append(" AND CCASE.CASE_ID = CASECH3.CASE_ID (+) ");
			getExcString.append(" AND CCASE.CASE_ID = CASECH4.CASE_ID (+) ");
			/* MOL20130704 End */

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement getExcPrepStmt = createPreparedStatement(getExcString.toString());
			PreparedStatement getExcPrepStmt = createPreparedStatement(getExcString.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			getExcPrepStmt.bindId("caseId", caseId);
			if(isUncorrected.isTrue()){
				/* MOL20130704 Begin
                getExcPrepStmt.bindId("exceptionCdCharType", parmInExcCdUncorrCharType.getId());
                getExcPrepStmt.bindId("excRequestDateCharType", parmExcRequestDtUncorrCharType.getId());
                getExcPrepStmt.bindId("statusDtCharType", parmInExcStatDtUncorrCharType.getId());
				 */
				getExcPrepStmt.bindId("exceptionCdCharType", parmUncorrExcpCdCharType.getId());
				getExcPrepStmt.bindId("excRequestDateCharType", parmExcRequestDtUncorrCharType.getId());
				getExcPrepStmt.bindId("statusDtCharType", parmExcStatDtUncorrCharType.getId());
				/* MOL20130704 End */
			}else{
				/* MOL20130704 Begin
                getExcPrepStmt.bindId("exceptionCdCharType", parmInExcCdCorrCharType.getId());
                getExcPrepStmt.bindId("excRequestDateCharType", parmExcRequestDtCorrCharType.getId());
                getExcPrepStmt.bindId("statusDtCharType", parmInExcStatDtCorrCharType.getId());
				 */
				getExcPrepStmt.bindId("exceptionCdCharType", parmCorrExcpCdCharType.getId());
				getExcPrepStmt.bindId("excRequestDateCharType", parmExcRequestDtCorrCharType.getId());
				getExcPrepStmt.bindId("statusDtCharType", parmExcStatDtCorrCharType.getId());
				/* MOL20130704 End */
			}
			SQLResultRow row =   getExcPrepStmt.firstRow();
			getExcPrepStmt.close();
			return row;    
		}


		private StringBuilder appendCharConditions(CharacteristicTypeLookup characteristicTypeLookup){
			StringBuilder queryString = new StringBuilder();
			queryString.append("AND CH.CHAR_TYPE_CD = :characteristicType ");
			if(characteristicTypeLookup.isPredefinedValue()){
			    // CCB v2.6 Upgrade - 2018-07-25 - Start Change
				//queryString.append("AND TRIM(CH.CHAR_VAL) = :charValue ");
			    queryString.append("AND CH.CHAR_VAL = :charValue ");
				// CCB v2.6 Upgrade - 2018-07-25 - End Change
			}else if(characteristicTypeLookup.isForeignKeyValue()){
			    // CCB v2.6 Upgrade - 2018-07-25 - Start Change
				//queryString.append("AND TRIM(CH.CHAR_VAL_FK1) = :charValue ");
			    queryString.append("AND CH.CHAR_VAL_FK1 = :charValue ");
				// CCB v2.6 Upgrade - 2018-07-25 - End Change
			}else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
			    // CCB v2.6 Upgrade - 2018-07-25 - Start Change
				//queryString.append("AND TRIM(CH.ADHOC_CHAR_VAL) = :charValue ");
			    queryString.append("AND CH.ADHOC_CHAR_VAL = :charValue ");
				// CCB v2.6 Upgrade - 2018-07-25 - End Change
			}
			return queryString;
		}
        // START DELETE - JHERNA - 2019-03-20 - SysAid#286046
		/*
		private String getTestPriorityOfCase(String exceptionCd){
			String testPriority = "";
			String excCd = "";
			for(String testTypeDetails : testTypeList){

				String[] testControlData = testTypeDetails.split(COMMA_DELIMITER);
				if(currentSeasonInFeatConfig.compareTo(CURRENT_SEASON_SUMMER) == 0){
					excCd = testControlData[CNTRL_SUMMER_EXC_INDEX].trim();
				}else{
					excCd = testControlData[CNTRL_WINTER_EXC_INDEX].trim();
				}
				if(excCd.trim().compareTo(exceptionCd.trim()) == 0){
					testPriority =  testControlData[CNTRL_TEST_PRIORITY_INDEX].trim();
					break;
				}
			}
			return testPriority;
		}
		*/
        // END DELETE - JHERNA - 2019-03-20 - SysAid#286046
		private SQLResultRow getRecentCaseExceptionCode(String spId, Bool isUncorrected){
			CharacteristicTypeLookup characteristicTypeLookup = parmServicePointCharType.getCharacteristicType();

			StringBuilder getExcString = new StringBuilder();
			getExcString.append("SELECT CH.CASE_ID,NVL(TRIM(CASECH2.ADHOC_CHAR_VAL),NVL(TRIM(CASECH2.CHAR_VAL),TRIM(CASECH2.CHAR_VAL_FK1))) EXC_CD, LOG.LOG_DTTM ");
			// Start changes IM-036038
			//getExcString.append("FROM CI_CASE CSE, CI_CASE_CHAR CH, CI_CASE_CHAR CASECH2, CI_CASE_LOG LOG, CI_CASE_TYPE CSETYP, CI_CASE_STATUS STATUS ");
			getExcString.append("FROM CI_CASE CSE, CI_CASE_CHAR CH, CI_CASE_CHAR CASECH2, CI_CASE_LOG LOG , CI_CASE_STATUS STATUS ");
			// End changes IM-036038
			getExcString.append("WHERE CH.CASE_ID = CSE.CASE_ID "); 
			getExcString.append(appendCharConditions(characteristicTypeLookup));  
			getExcString.append("AND CH.SEQ_NUM = (SELECT MAX(SEQ_NUM) FROM CI_CASE_CHAR WHERE CASE_ID = CH.CASE_ID AND CHAR_TYPE_CD = CH.CHAR_TYPE_CD) ");
			getExcString.append("AND CSE.CASE_COND_FLG = :closed "); 
			// Start changes IM-036038
			getExcString.append("AND CSE.CASE_TYPE_CD = :caseType ");
			// End changes IM-036038
			getExcString.append("AND CASECH2.CASE_ID = CSE.CASE_ID ");
			getExcString.append("AND CASECH2.CHAR_TYPE_CD = :exceptionCdCharType ");
			getExcString.append("AND CASECH2.SEQ_NUM = (SELECT MAX(SEQ_NUM) FROM CI_CASE_CHAR WHERE CASE_ID = CASECH2.CASE_ID AND CHAR_TYPE_CD = CASECH2.CHAR_TYPE_CD) ");
			getExcString.append("AND LOG.CASE_ID = CSE.CASE_ID ");
			// Start change IM-036038                     
			getExcString.append("AND LOG.CASE_TYPE_CD = CSE.CASE_TYPE_CD "); 
			getExcString.append("AND STATUS.CASE_TYPE_CD = CSE.CASE_TYPE_CD ");
			// End change IM-036038
			getExcString.append("AND LOG.CASE_STATUS_CD = STATUS.CASE_STATUS_CD ");
			/*
			 * Start Add - 2013-06-07 - JPunza 
			 */
			getExcString.append("AND UPPER(TRIM(STATUS.CASE_STATUS_CD)) = UPPER(TRIM(:completedStatus)) ");
			/*
			 * End Add - 2013-06-07 - JPunza 
			 */
			getExcString.append("AND STATUS.STATUS_COND_FLG = :final ");
			getExcString.append("ORDER BY LOG.LOG_DTTM DESC");

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement getExcPrepStmt = createPreparedStatement(getExcString.toString());
			PreparedStatement getExcPrepStmt = createPreparedStatement(getExcString.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			getExcPrepStmt.bindId("characteristicType", parmServicePointCharType.getId());
			// Start changes IM-036038
			getExcPrepStmt.bindId("caseType", parmMeteringExceptionCaseType.getId());
			// End changes IM-036038
			if(characteristicTypeLookup.isPredefinedValue()){
				getExcPrepStmt.bindStringProperty("charValue", CaseCharacteristic.properties.characteristicValue ,spId.trim());    
			}else if(characteristicTypeLookup.isForeignKeyValue()){
				getExcPrepStmt.bindStringProperty("charValue", CaseCharacteristic.properties.characteristicValueForeignKey1,spId.trim());         
			}else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
				getExcPrepStmt.bindStringProperty("charValue", CaseCharacteristic.properties.adhocCharacteristicValue, spId.trim());
			}            
			getExcPrepStmt.bindLookup("closed", CaseConditionLookup.constants.CLOSED);
			/*
			 * Start Change - 2013-06-07 - JPunza 
			 */
			//if(isUncorrected.isTrue()){
			//    characteristicTypeLookup = parmInExcCdUncorrCharType.getCharacteristicType();
			//    getExcPrepStmt.bindId("exceptionCdCharType", parmInExcCdUncorrCharType.getId());
			//}else{
			//    characteristicTypeLookup = parmInExcCdCorrCharType.getCharacteristicType();
			//    getExcPrepStmt.bindId("exceptionCdCharType", parmInExcCdCorrCharType.getId());
			//}
			if(isUncorrected.isTrue()){
				getExcPrepStmt.bindEntity("exceptionCdCharType", parmUncorrExcpCdCharType);
			}
			else {
				getExcPrepStmt.bindEntity("exceptionCdCharType", parmCorrExcpCdCharType);
			}
			getExcPrepStmt.bindStringProperty("completedStatus", CaseStatus.properties.status, parmCompletedCaseStatus);
			/*
			 * End Change - 2013-06-07 - JPunza 
			 */
			getExcPrepStmt.bindLookup("final", StatusConditionLookup.constants.FINAL);
			SQLResultRow row = getExcPrepStmt.firstRow();
			getExcPrepStmt.close();
			return row;     
		}

		/**
		 * This method returns the next record from the input file.
		 * @return a String object.
		 */
		private String readRecord() {

			String record = null;
			try {
				record =  inputBufferReader.readLine();                 
			} catch (IOException exception) {

				throw new RunAbortedException(CustomMessageRepository.ni0028_6ErrorInFile(exception.getMessage().trim()));
			}  
			return record;
		}

		private void createExceptionCase(){

			ToDoCase_DTO toDoCaseDTO = (ToDoCase_DTO) createDTO(ToDoCase.class);
			// To avoid lazy initialization reinitialize case type
			parmMeteringExceptionCaseType = parmMeteringExceptionCaseType.getId().getEntity();
			CaseTypeCaseStatues statuses = parmMeteringExceptionCaseType.getCaseStatues();
			for (CaseStatus status : statuses){
				if(status.getStatusCondition().isInitial()){
					toDoCaseDTO.setCaseStatusId(status.getId());
				}
			}
			Account_Id accountId = null;
			Person_Id personId = null;
			String phone = "";

			// START CHANGES - JHERNA - 2019-03-20 - SysAid#286046
			/*
			SQLResultRow usageRow = getUsageInformation(spId);
			if(notNull(usageRow)){
				accountId = (Account_Id)usageRow.getId("ACCT_ID", Account.class);
				personId = (Person_Id)usageRow.getId("PER_ID", Person.class);               
			}
			*/
			CmSaSpMeterRelationshipsRoutine_Impl.LatestCustomerData latestCustomerData = new CmSaSpMeterRelationshipsRoutine_Impl.LatestCustomerData();         
        	latestCustomerData.setSPID(new ServicePoint_Id(spId));
        	latestCustomerData.invoke();
        	accountId = latestCustomerData.getAccountID();
        	personId = latestCustomerData.getPersonID();        	
            // END CHANGES - JHERNA - 2019-03-20 - SysAid#286046
        	
			if(isNull(accountId) && (parmMeteringExceptionCaseType.getAccountUsage().isRequired())){
				addError(CustomMessageRepository.ni0028_6AccountNotFoundButReqdOnCase(spId,parmMeteringExceptionCaseType.getId().getTrimmedValue()));
			}
			if(notNull(accountId) && ((parmMeteringExceptionCaseType.getAccountUsage().isRequired()) || parmMeteringExceptionCaseType.getAccountUsage().isOptional())){
				toDoCaseDTO.setAccountId(accountId);
			}
			if(isNull(personId) && (parmMeteringExceptionCaseType.getPersonUsage().isRequired())){
				addError(CustomMessageRepository.ni0028_6PersonNotFoundButReqdOnCase(spId,parmMeteringExceptionCaseType.getId().getTrimmedValue()));
			}
			if(notNull(personId) && (parmMeteringExceptionCaseType.getPersonUsage().isRequired() || parmMeteringExceptionCaseType.getPersonUsage().isOptional())){
				toDoCaseDTO.setPersonId(personId);
			}
			if(parmMeteringExceptionCaseType.getCallbackPhoneUsage().isRequired()){
				if(notNull(personId)){
					List<SQLResultRow> list = getPhoneInformation(personId);
					phone = list.iterator().next().getString("PHONE");
					toDoCaseDTO.setPhoneTypeId((PhoneType_Id)list.iterator().next().getId("PHONE_TYPE_CD", PhoneType.class));
					toDoCaseDTO.setPhone(phone);
				}
			}
			if(parmMeteringExceptionCaseType.getContactInformationUsage().isRequired()){
				toDoCaseDTO.setContactPersonId(personId);
				toDoCaseDTO.setPreferredContactMethod(ContactMethodLookup.constants.NOT_APPLICABLE);
			}
			if(parmMeteringExceptionCaseType.getContactInstructionsUsage().isRequired()){
				toDoCaseDTO.setContactInstructions(CustomMessageRepository.ni0028_6ContactInstructionsUsage().getMessageText());
			}
			ServicePoint_Id servicePointId = new ServicePoint_Id(spId);
			if(isNull(servicePointId.getEntity().getPremise()) && parmMeteringExceptionCaseType.getPremiseUsage().isRequired()){
				addError(CustomMessageRepository.ni0028_6PremiseNotFoundButReqdOnCase(servicePointId.getTrimmedValue(), parmMeteringExceptionCaseType.getId().getTrimmedValue()));
			}
			if(parmMeteringExceptionCaseType.getPremiseUsage().isRequired() || parmMeteringExceptionCaseType.getPremiseUsage().isOptional()){
				toDoCaseDTO.setPremiseId(servicePointId.getEntity().getPremise().getId());
			}
			if(parmMeteringExceptionCaseType.getResponsibleUserUsage().isRequired()){
				toDoCaseDTO.setUserId(getActiveContextUser().getId());
			}
			createCharacteristics(ToDoCase_Id.NULL);

			CaseCreatorData caseCreatorData = CaseCreatorData.Factory.newInstance();
			caseCreatorData.setToDoCaseDTO(toDoCaseDTO);             
			caseCreatorData.setCaseCharacteristics(charList);
			/*
			 * Start Add - 2013-05-14 - JPunza 
			 */
			 caseCreatorData.setShouldSetDefaults(Bool.TRUE);
			/*
			 * End Add - 2013-05-14 - JPunza 
			 */

			 CaseCreator caseCreator = CaseCreator.Factory.newInstance();
			 caseCreatorData = caseCreator.createCase(caseCreatorData);
			 numberOfRecordsProcessed = numberOfRecordsProcessed.add(BigInteger.ONE);
			 numberOfCasesCreated = numberOfCasesCreated.add(BigInteger.ONE);
		}
        // START DELETE - JHERNA - 2019-03-20 - SysAid#286046
		/*
		private SQLResultRow getUsageInformation(String spId){
			StringBuilder getUsageDetailsString = new StringBuilder();
			getUsageDetailsString.append("SELECT SA.ACCT_ID, APER.PER_ID,(SELECT PHONE FROM CI_PER_PHONE WHERE PER_ID = APER.PER_ID AND ROWNUM <=1) PHONE ");
			getUsageDetailsString.append("FROM CI_SA_SP SASP ");
			getUsageDetailsString.append(", CI_SA SA ");
			getUsageDetailsString.append(", CI_ACCT_PER APER ");
			getUsageDetailsString.append("WHERE SASP.SP_ID = :spId ");
			getUsageDetailsString.append("AND SASP.SA_ID = SA.SA_ID ");
			// Start add 2014-03-21	Neha IM-044199
			getUsageDetailsString.append("AND SASP.START_DTTM = (SELECT MAX(START_DTTM) FROM CI_SA_SP WHERE SP_ID = :spId) ");
			// End add 2014-03-21	Neha IM-044199
			getUsageDetailsString.append("AND SA.ACCT_ID = APER.ACCT_ID  "); 
			getUsageDetailsString.append("AND APER.MAIN_CUST_SW = 'Y' "); 
			getUsageDetailsString.append("AND APER.ACCT_REL_TYPE_CD = 'MAIN' "); 

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString());
			PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			getUsageDetailsPrepStmt.bindId("spId", new ServicePoint_Id(spId));

			SQLResultRow usageRow = getUsageDetailsPrepStmt.firstRow();

			getUsageDetailsPrepStmt.close();

			return usageRow;
		}
		*/
        // END DELETE - JHERNA - 2019-03-20 - SysAid#286046

		private List<SQLResultRow> getPhoneInformation(Person_Id perId){
			StringBuilder getUsageDetailsString = new StringBuilder();
			getUsageDetailsString.append("SELECT PHONE , PHONE_TYPE_CD FROM CI_PER_PHONE WHERE PER_ID = :perId ");
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString()); 
			PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString(), getClass().getName()); 
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			getUsageDetailsPrepStmt.bindId("perId", perId);

			List<SQLResultRow> usageList = getUsageDetailsPrepStmt.list();

			getUsageDetailsPrepStmt.close();

			return usageList;
		}

		private void updateExceptionCase(ToDoCase_Id caseId){

			if(isUncorrected.isTrue()){ 
				if(!isEmptyOrNull(exceptionCd.trim())){
				 // Start change Neha IM-042812 2013-12-18
					//addCharacteristic(caseId, parmInExcCdUncorrCharType, exceptionCd);
				    updateCharacteristic(caseId, parmInExcCdUncorrCharType, exceptionCd);
				// End change Neha IM-042812 2013-12-18
				}
				// Start change Neha IM-042812 2013-12-18
				/*
				addCharacteristic(caseId, parmExcRequesterUncorrCharType, exceptionRequester);
				addCharacteristic(caseId, parmExcRequestDtUncorrCharType, effDtFromFile.toString(new DateFormat(DATE_FORMAT)));
				addCharacteristic(caseId, parmInExcStatusUncorrCharType, exceptionStatus);
				addCharacteristic(caseId, parmInExcStatDtUncorrCharType, getProcessDateTime().getDate().toString(new DateFormat(DATE_FORMAT)));
				*/
				updateCharacteristic(caseId, parmExcRequesterUncorrCharType, exceptionRequester);
				updateCharacteristic(caseId, parmExcRequestDtUncorrCharType, effDtFromFile.toString(new DateFormat(DATE_FORMAT)));
				updateCharacteristic(caseId, parmInExcStatusUncorrCharType, exceptionStatus);
				updateCharacteristic(caseId, parmInExcStatDtUncorrCharType, getProcessDateTime().getDate().toString(new DateFormat(DATE_FORMAT)));
				// End change Neha IM-042812 2013-12-18
			}else{     
			    if(!isEmptyOrNull(exceptionCd.trim())){
			        // Start change Neha IM-042812 2013-12-18
			        //addCharacteristic(caseId, parmInExcCdCorrCharType, exceptionCd);
			        updateCharacteristic(caseId, parmInExcCdCorrCharType, exceptionCd);
			        // End change Neha IM-042812 2013-12-18
			    }
			    // Start change Neha IM-042812 2013-12-18
			    /*
				addCharacteristic(caseId, parmExcRequesterCorrCharType, exceptionRequester);
				addCharacteristic(caseId, parmExcRequestDtCorrCharType, effDtFromFile.toString(new DateFormat(DATE_FORMAT)));
				addCharacteristic(caseId, parmInExcStatusCorrCharType, exceptionStatus);
				addCharacteristic(caseId, parmInExcStatDtCorrCharType, getProcessDateTime().getDate().toString(new DateFormat(DATE_FORMAT)));
			     */
			    updateCharacteristic(caseId, parmExcRequesterCorrCharType, exceptionRequester);
			    updateCharacteristic(caseId, parmExcRequestDtCorrCharType, effDtFromFile.toString(new DateFormat(DATE_FORMAT)));
			    updateCharacteristic(caseId, parmInExcStatusCorrCharType, exceptionStatus);
			    updateCharacteristic(caseId, parmInExcStatDtCorrCharType, getProcessDateTime().getDate().toString(new DateFormat(DATE_FORMAT)));
			 // End change Neha IM-042812 2013-12-18
			}
			// Start change Neha IM-042812 2013-12-18
			//addCharacteristic(caseId, parmOwnerCharType, owner);
			//addCharacteristic(caseId, parmDRMeterTestDtCharType, effectiveDtStr);
			/*
			 * Start Add - 2013-05-14 - JPunza 
			 */
			 //addCharacteristic(caseId, parmMeterBadgeCharType, badgeNumber);
			/*
			 * End Add - 2013-05-14 - JPunza 
			 */
			updateCharacteristic(caseId, parmOwnerCharType, owner);
			updateCharacteristic(caseId, parmDRMeterTestDtCharType, effectiveDtStr);
			updateCharacteristic(caseId, parmMeterBadgeCharType, badgeNumber);
			// End change Neha IM-042812 2013-12-18
			 numberOfRecordsProcessed = numberOfRecordsProcessed.add(BigInteger.ONE);

			 ToDoCaseCharacteristics toDoCaseChars = caseId.getEntity().getCharacteristics();
			 for(CaseCharacteristic_DTO caseCharDto : charList){
				 CaseCharacteristic caseChar = caseCharDto.newEntity();
				 toDoCaseChars.add(caseChar);
			 }
		}


		private void createCharacteristics(ToDoCase_Id caseId){
			if(isUncorrected.isTrue()){ 
				if(!isEmptyOrNull(exceptionCd.trim())){
					addCharacteristic(caseId, parmInExcCdUncorrCharType, exceptionCd);
				}
				addCharacteristic(caseId, parmExcRequesterUncorrCharType, exceptionRequester);
				addCharacteristic(caseId, parmExcRequestDtUncorrCharType, effDtFromFile.toString(new DateFormat(DATE_FORMAT)));
				addCharacteristic(caseId, parmInExcStatusUncorrCharType, exceptionStatus);
				addCharacteristic(caseId, parmInExcStatDtUncorrCharType, getProcessDateTime().getDate().toString(new DateFormat(DATE_FORMAT)));
			}else{     
				if(!isEmptyOrNull(exceptionCd.trim())){
					addCharacteristic(caseId, parmInExcCdCorrCharType, exceptionCd);
				}
				addCharacteristic(caseId, parmExcRequesterCorrCharType, exceptionRequester);
				addCharacteristic(caseId, parmExcRequestDtCorrCharType, effDtFromFile.toString(new DateFormat(DATE_FORMAT)));
				addCharacteristic(caseId, parmInExcStatusCorrCharType, exceptionStatus);
				addCharacteristic(caseId, parmInExcStatDtCorrCharType, getProcessDateTime().getDate().toString(new DateFormat(DATE_FORMAT)));
			}
			addCharacteristic(caseId, parmServicePointCharType, spId);
			addCharacteristic(caseId, parmOwnerCharType, owner);
			addCharacteristic(caseId, parmDRMeterTestDtCharType, effectiveDtStr);
			/*
			 * Start Add - 2013-05-14 - JPunza 
			 */
			 addCharacteristic(caseId, parmMeterBadgeCharType, badgeNumber);
			/*
			 * End Add - 2013-05-14 - JPunza 
			 */
		}

		private void addCharacteristic(ToDoCase_Id caseId, CharacteristicType charType, String charVal){
			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
			CaseCharacteristic_DTO caseCharacteristicDTO;

			// Create new char
			if(notNull(caseId) && notNull(caseId.getEntity())){
				ToDoCaseCharacteristics caseCharacteristics = caseId.getEntity().getCharacteristics();
				caseCharacteristicDTO  = caseCharacteristics.newChildDTO();
				
				/**
				 * KL20131119 - Start of change for IM-041170.
				 * Modified the logic to retrieve and use the max. sequence number instead of count while create Case Char
				**/
				//ListFilter<CaseCharacteristic> caseCharListFilter = caseCharacteristics.createFilter(" WHERE this.id.characteristicType = :characteristicType ");
				//caseCharListFilter.bindEntity("characteristicType",charType);
				//caseCharacteristicDTO  = caseCharacteristics.newChildDTO();
				//caseCharacteristicDTO.setId(new CaseCharacteristic_Id(charType, caseId.getEntity(), BigInteger.valueOf(caseCharListFilter.listSize() +1)));
				caseCharacteristicDTO.setId(new CaseCharacteristic_Id(charType, caseId.getEntity(), getMaxSequence(caseId, charType).add(BigInteger.ONE)));
				/**
				 * KL20131119 - End of change for IM-041170. 
				 */
			}else{

				CaseCharacteristic_Id caseCharacteristicId = new CaseCharacteristic_Id(charType.getId(), caseId, BigInteger.ONE);            
				caseCharacteristicDTO = caseCharacteristicId.newDTO();
			}

			if(charTypeLookup.isAdhocValue()){
				caseCharacteristicDTO.setAdhocCharacteristicValue(charVal);
			} else if (charTypeLookup.isPredefinedValue()){
				caseCharacteristicDTO.setCharacteristicValue(charVal);
			} else if (charTypeLookup.isForeignKeyValue()){
				caseCharacteristicDTO.setCharacteristicValueForeignKey1(charVal);
			}
			charList.add(caseCharacteristicDTO);
		}
		
		// Start add Neha IM-042812 2013-12-18
	        private boolean updateCharacteristic(ToDoCase_Id caseId, CharacteristicType charType, String charVal){
	            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

	            if(isBlankOrNull(charVal)){
	                // if value is blank skip the record
	                return true;
	            }

	            CaseCharacteristic_DTO caseCharacteristicDTO;
	            ToDoCaseCharacteristics caseCharacteristics = caseId.getEntity().getCharacteristics();
	            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
	            //ListFilter<CaseCharacteristic> caseCharListFilter = caseCharacteristics.createFilter(" WHERE this.id.characteristicType = :characteristicType ");
	            ListFilter<CaseCharacteristic> caseCharListFilter = caseCharacteristics.createFilter(
	            		" WHERE this.id.characteristicType = :characteristicType ", getClass().getName());
	            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
	            caseCharListFilter.bindEntity("characteristicType",charType);

	            if(caseCharListFilter.listSize()==0){
	                // If no Char Type exists, add the Characteristic of that type
	                addCharacteristic(caseId, charType, charVal);
	            } else {
	                CaseCharacteristic caseCharacteristic = caseCharListFilter.iterate().next();

	                caseCharacteristicDTO  = caseCharacteristic.getDTO();

	                if(charTypeLookup.isAdhocValue()){
	                    caseCharacteristicDTO.setAdhocCharacteristicValue(charVal);
	                } else if (charTypeLookup.isPredefinedValue()){
	                    caseCharacteristicDTO.setCharacteristicValue(charVal);
	                } else if (charTypeLookup.isForeignKeyValue()){
	                    caseCharacteristicDTO.setCharacteristicValueForeignKey1(charVal);
	                }
	                caseCharacteristic.setDTO(caseCharacteristicDTO);
	            }
	            return true;
	        }
	        
	     // End add Neha IM-042812 2013-12-18
	        
		/**
		 * KL20131119 - Start of change for IM-041170. 
		 * Modified the logic to retrieve and use the max. sequence number instead of count while create Case Char
		 */
		private BigInteger getMaxSequence(ToDoCase_Id caseId, CharacteristicType charType){
			BigInteger maxSeq = BigInteger.ZERO;
			
			StringBuilder maxSeqNumStr = new StringBuilder();
			maxSeqNumStr.append("SELECT MAX(SEQ_NUM) MAX_SEQ_NUM FROM CI_CASE_CHAR WHERE CASE_ID=:caseId AND CHAR_TYPE_CD=:charTypeCd");
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement maxSeqNumQuery = createPreparedStatement(maxSeqNumStr.toString());
			PreparedStatement maxSeqNumQuery = createPreparedStatement(maxSeqNumStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			maxSeqNumQuery.bindId("caseId", caseId);
			maxSeqNumQuery.bindId("charTypeCd", charType.getId());
			
			if(notNull(maxSeqNumQuery.firstRow()) && notNull(maxSeqNumQuery.firstRow().getInteger("MAX_SEQ_NUM"))){
				maxSeq = maxSeqNumQuery.firstRow().getInteger("MAX_SEQ_NUM");
			}
			maxSeqNumQuery.close();
			
			return maxSeq;
		}
		/**
		 * KL20131119 - End of change for IM-041170. 
		 */
		
		private void purgeTempTable(){
			StringBuilder purgeString = new StringBuilder();
			purgeString.append("DELETE FROM CM_MTR_EXC WHERE BATCH_NBR = :batchNbr ");

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement purgePrepStmt = createPreparedStatement(purgeString.toString());
			PreparedStatement purgePrepStmt = createPreparedStatement(purgeString.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			purgePrepStmt.bindBigInteger("batchNbr", getBatchNumber());
			purgePrepStmt.execute();
			purgePrepStmt.close();
		}
		/**
		 * Perform final processing before ending the thread.
		 * 
		 * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
		 * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
		 * @see com.splwg.base.api.batch.ThreadWorker#finalizeThreadWork() 
		 */
		public void finalizeThreadWork() 
				throws ThreadAbortedException, RunAbortedException {

			try {
				if(notNull(inputBufferReader)){
					inputBufferReader.close();                    
				}
			} catch (IOException exception) {

				throw new RunAbortedException(CustomMessageRepository.ni0028_6ErrorInFile(exception.getMessage().trim()));
			}
		}

		// KL20131113 - Start of Code change for IM-041170
		public ToDoProperties createToDoProperties(ThreadWorkUnit arg0) {
			BatchRun_Id batchRunId = new BatchRun_Id(getBatchControlId(), getBatchNumber(), getBatchRerunNumber());
			ToDoProperties todoProps =  new ToDoProperties(batchRunId);
			todoProps.setBATCH_NBR(getBatchNumber().toString());
			return todoProps;
		}
		// KL20131113 - End of Code change for IM-041170
		
		// KL20131113 - Start of Code change for IM-041170
		public boolean hasToDoInOpenStatus(String badgeNumber){
			StringBuilder checkForExistingToDosStr = new StringBuilder();
			checkForExistingToDosStr.append("SELECT 'X' FROM CI_TD_ENTRY TODO, CI_TD_MSG_PARM TODOMSGPARM ");
			checkForExistingToDosStr.append("WHERE TODO.MESSAGE_CAT_NBR = :msgCatNbr AND TODO.MESSAGE_NBR = :msgNbr ");
			checkForExistingToDosStr.append("AND TODO.ENTRY_STATUS_FLG <> :complete AND TODOMSGPARM.TD_ENTRY_ID = TODO.TD_ENTRY_ID ");
			// Start Change - 2020-08-26 - DLampa - B-17008
			//checkForExistingToDosStr.append("AND TODO.TD_TYPE_CD = :toDoType AND TODOMSGPARM.MSG_PARM_VAL= :badgeNumber ");
			checkForExistingToDosStr.append("AND TODO.TD_TYPE_CD = :toDoType AND TRIM(TODOMSGPARM.MSG_PARM_VAL) = TRIM(:badgeNumber) ");
			// End Change - 2020-08-26 - DLampa - B-17008
			
			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement hasExistingToDos = createPreparedStatement(checkForExistingToDosStr.toString());
			PreparedStatement hasExistingToDos = createPreparedStatement(checkForExistingToDosStr.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			hasExistingToDos.bindBigInteger("msgCatNbr", BigInteger.valueOf(CustomMessages.MESSAGE_CATEGORY));
			hasExistingToDos.bindBigInteger("msgNbr", BigInteger.valueOf(CustomMessages.NI0028_6_BADGE_NBR_HAS_MUL_MTR));
			hasExistingToDos.bindLookup("complete", ToDoEntryStatusLookup.constants.COMPLETED);
			hasExistingToDos.bindId("toDoType", paramTodoType.getId());
			// Start Change - 2020-08-26 - DLampa - B-17008
			//hasExistingToDos.bindStringProperty("badgeNumber", Meter.properties.badgeNumber, badgeNumber.trim());
			hasExistingToDos.bindStringProperty("badgeNumber", Meter.properties.badgeNumber, OPEN_BRACE.concat(badgeNumber.trim().concat(CLOSE_BRACE)));
			// Start Change - 2020-08-26 - DLampa - B-17008
			
			List<SQLResultRow> todoList = hasExistingToDos.list();
			hasExistingToDos.close();
			if(todoList.isEmpty()){
				return false;
			}
			return true;
		}
		// KL20131113 - End of Code change for IM-041170
		
	}
}
