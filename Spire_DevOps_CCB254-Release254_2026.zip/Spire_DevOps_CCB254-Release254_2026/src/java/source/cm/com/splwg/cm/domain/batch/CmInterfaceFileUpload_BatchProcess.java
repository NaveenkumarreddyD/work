/******************************************************************************************
 *
* PROGRAM DESCRIPTION:
 *
 * L&G Interface file upload Batch
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2012-11-22   Neha            NI0007.3 Initial Version.
 * 2012-11-23   Neha            NI0007.3 Incorporated review comments
 * 2013-01-28   Neha            NI0007.3 Fixed TIR - No Case created when Case is closed 
 *                              and no Case Id in file
 * 2013-04-30   Neha            NI0007.3 CR - Populate Person and Account even when usage
 *                              optional in Case Type
 * 2013-06-12   Murali          Fix for No Such Element Exception   
 * 2013-06-18   Murali          ML20130618 - Additional Case Characteristics are added
 * 2013-07-11   CVB             Change the search for Case to improve performance
 * 2013-08-29   Neha            IM-036993 Reference to other unrelated Case Types removed
 *                              Remove static variables
 * 2013-10-09   Neha			IM-039305 Fix for parameter Case type not being initialized
 * 2013-12-18   Neha            IM-042812 Every characteristic to occur only once
 * 2014-03-21	Neha			IM-044199 Case created on old accounts
 * 2016-01-29  	MPang			Updated for CCB v2.4 compilation.
 * 2018-07-25   SFelip          CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                              longer needed. 
 ******************************************************************************************/

package com.splwg.cm.domain.batch;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_Id;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_LanguageId;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicTypeValues;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.phoneType.PhoneType;
import com.splwg.base.domain.common.phoneType.PhoneType_Id;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ContactMethodLookup;
import com.splwg.ccb.api.lookup.ServicePointMeterEventTypeLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseType;
import com.splwg.ccb.domain.admin.caseType.CaseTypeCaseStatues;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.Person;
import com.splwg.ccb.domain.customerinfo.person.Person_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.Meter;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseCreator;
import com.splwg.ccb.domain.todo.toDoCase.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCaseCharacteristics;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_Id;*/

import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.caseType.entity.CaseTypeCaseStatues;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.common.CaseCreator;
import com.splwg.ccb.domain.todo.data.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCaseCharacteristics;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_Id;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;


/** 
 * @BatchJob ( modules = {} 
 *              , multiThreaded = false
 *              , rerunnable = true
 *              , softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)                                 
 *                                 , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *                                 , @BatchJobSoftParameter (name = MAX_ERRORS, required = false, type = integer)
 *                                 , @BatchJobSoftParameter (name = TEMP_CORR_EXCEPTION_CD, required = true, type = entity, entityName = characteristicType)                                 
 *                                 , @BatchJobSoftParameter (name = TEMP_CORR_EXCEPTION_REQ_DT, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = TEMP_CORR_STATUS_CD, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = TEMP_CORR_STATUS_DT, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = TEMP_CORR_FIELD_CD, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = TEMP_UNCORR_EXCEPTION_CD, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = TEMP_UNCORR_EXCEPTION_REQ_DT, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = TEMP_UNCORR_STATUS_CD, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = TEMP_UNCORR_STATUS_DT, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = TEMP_UNCORR_FIELD_CD, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = CORRECTED_EXCEPTION_REQUESTER, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = UNCORRECTED_EXCEPTION_REQUEST, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = SP_ID, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = OWNER, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = LNG_WORK_ORDER_ID, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = NO_ACCESS_FLAG, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = OTHER, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = CASE_TYPE, required = true, type = entity, entityName = caseType)
 *                                 , @BatchJobSoftParameter (name = METER_BADGE_NBR, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = CREATED_BY_CHAR_TYPE, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = CREATED_BY_CHAR_VALUE, required = true, type = string)
 *                                 , @BatchJobSoftParameter (name = CASE_MGMT_PORTAL_CHAR_TYPE, required = true, type = entity, entityName = characteristicType)
 *                                 , @BatchJobSoftParameter (name = CASE_MGMT_PORTAL_CHAR_VALUE, required = true, type = string)
 *                                }
 *           )
 */

public class CmInterfaceFileUpload_BatchProcess 
extends CmInterfaceFileUpload_BatchProcess_Gen{

    /*
     *  start delete Neha 29-Aug
     */
    // Soft Parameters
//    private static BigInteger parmMaxErrors = null;
//    private static String parmFilePath;
//    private static String parmFileName;
//    private static CharacteristicType parmTempCorrExcCdCharType;
//    private static CharacteristicType parmTempCorrExcReqDtCharType;
//    private static CharacteristicType parmTempCorrExcStatusCharType;   
//    private static CharacteristicType parmTempCorrExcStatDtCharType; 
//    private static CharacteristicType parmTempCorrFieldCdCharType; 
//    private static CharacteristicType parmTempUncorrExcCdCharType; 
//    private static CharacteristicType parmTempUncorrExcReqDtCharType; 
//    private static CharacteristicType parmTempUncorrExcStatusCharType; 
//    private static CharacteristicType parmTempUncorrExcStatDtCharType; 
//    private static CharacteristicType parmTempUncorrFieldCdCharType; 
//    private static CharacteristicType parmCorrectedExcRequesterCharType; 
//    private static CharacteristicType parmUncorrectedExcRequesterCharType; 
//    private static CharacteristicType parmServicePointCharType; 
//    private static CharacteristicType parmOwnerCharType; 
//    private static CharacteristicType parmLnGWorkOrderIdCharType; 
//    private static CharacteristicType parmNoAccessFlagCharType; 
//    private static CharacteristicType parmOtherCharType; 
//    private static CaseType parmCaseType;
//
//    //ML20130618 - Start
//
//    private static CharacteristicType paramMeterBadgeNbrCharType; 
//    private static CharacteristicType paramCreatedByCharType;
//    // private static CharacteristicValue paramCreatedByCharVal;
//    
//    private static String paramCreatedByCharValStr;
//
//    private static CharacteristicType paramCaseMgmtPortalCharType;
//   // private static CharacteristicValue paramCaseMgmtPortalCharValue;
//    
//    private static String paramCaseMgmtPortalCharValStr;
//
//    //ML20130618 - End
//
//    private static File inputFile = null;
    
    /* End delete Neha 6-Aug
     * */

    /**
     * This method retrieves the records to be processed and in case of error returns a JobWork with single ThreadWorkUnit
     * 
     * @return the JobWork that will be processed in this run.
     */
    public JobWork getJobWork() {

        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();                                               
        ThreadWorkUnit workUnit = new ThreadWorkUnit(); 
        workUnits.add(workUnit);   
        return createJobWorkForThreadWorkUnitList(workUnits);
    }

    /**
     * This method checks if all required Soft Parameters were populated,
     * and all optional Soft Parameters (if populated) are valid.
     * 
     * @param isNewRun - a boolean value
     */
    public void validateSoftParameters(boolean isNewRun){
        /*
         * Start Add Neha 
         */
        BigInteger parmMaxErrors = null;
        String parmFilePath;
        String parmFileName;
        CharacteristicType parmTempCorrExcCdCharType;
        CharacteristicType parmTempCorrExcReqDtCharType;
        CharacteristicType parmTempCorrExcStatusCharType;   
        CharacteristicType parmTempCorrExcStatDtCharType; 
        CharacteristicType parmTempCorrFieldCdCharType; 
        CharacteristicType parmTempUncorrExcCdCharType; 
        CharacteristicType parmTempUncorrExcReqDtCharType; 
        CharacteristicType parmTempUncorrExcStatusCharType; 
        CharacteristicType parmTempUncorrExcStatDtCharType; 
        CharacteristicType parmTempUncorrFieldCdCharType; 
        CharacteristicType parmCorrectedExcRequesterCharType; 
        CharacteristicType parmUncorrectedExcRequesterCharType; 
        CharacteristicType parmServicePointCharType; 
        CharacteristicType parmOwnerCharType; 
        CharacteristicType parmLnGWorkOrderIdCharType; 
        CharacteristicType parmNoAccessFlagCharType; 
        CharacteristicType parmOtherCharType; 
        CharacteristicType paramMeterBadgeNbrCharType; 
        CharacteristicType paramCreatedByCharType;
        String paramCreatedByCharValStr;
        CharacteristicType paramCaseMgmtPortalCharType;
        String paramCaseMgmtPortalCharValStr;
        File inputFile = null;
        /*
         * End Neha
         */
        parmMaxErrors = getParameters().getMAX_ERRORS();
        // Validates Max Error soft parameter
        if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
            addError(CustomMessageRepository.ni0007_3MaxErrorCannotBeLessThanZero(parmMaxErrors.toString().trim()));
        }   
        parmFilePath = getParameters().getFILE_PATH().trim();
        parmFileName = getParameters().getFILE_NAME().trim();

        File folder = new File(parmFilePath);
        if(!folder.exists()){
            addError(CustomMessageRepository.ni0007_3InvalidFilePath(parmFilePath));
        }

        // Validate that the parameter FILE-NAME is a correct file name and that the corresponding file can be opened and read.
        inputFile = new File(parmFilePath, parmFileName);
        if(!inputFile.exists() || !inputFile.canRead()){
            addError(CustomMessageRepository.ni0007_3InvalidFileName(parmFileName));
        }      

        parmTempCorrExcCdCharType = getParameters().getTEMP_CORR_EXCEPTION_CD();
        validateCharTypeAndEntity(parmTempCorrExcCdCharType, getBatchParameterName(BigInteger.valueOf(40)));

        parmTempCorrExcReqDtCharType = getParameters().getTEMP_CORR_EXCEPTION_REQ_DT();
        validateCharTypeAndEntity(parmTempCorrExcReqDtCharType, getBatchParameterName(BigInteger.valueOf(50)));

        parmTempCorrExcStatusCharType = getParameters().getTEMP_CORR_STATUS_CD();   
        validateCharTypeAndEntity(parmTempCorrExcStatusCharType, getBatchParameterName(BigInteger.valueOf(60)));

        parmTempCorrExcStatDtCharType = getParameters().getTEMP_CORR_STATUS_DT(); 
        validateCharTypeAndEntity(parmTempCorrExcStatDtCharType, getBatchParameterName(BigInteger.valueOf(70)));

        parmTempCorrFieldCdCharType = getParameters().getTEMP_CORR_FIELD_CD(); 
        validateCharTypeAndEntity(parmTempCorrFieldCdCharType, getBatchParameterName(BigInteger.valueOf(80)));

        parmTempUncorrExcCdCharType = getParameters().getTEMP_UNCORR_EXCEPTION_CD(); 
        validateCharTypeAndEntity(parmTempUncorrExcCdCharType, getBatchParameterName(BigInteger.valueOf(90)));

        parmTempUncorrExcReqDtCharType = getParameters().getTEMP_UNCORR_EXCEPTION_REQ_DT(); 
        validateCharTypeAndEntity(parmTempUncorrExcReqDtCharType, getBatchParameterName(BigInteger.valueOf(100)));

        parmTempUncorrExcStatusCharType = getParameters().getTEMP_UNCORR_STATUS_CD(); 
        validateCharTypeAndEntity(parmTempUncorrExcStatusCharType, getBatchParameterName(BigInteger.valueOf(110)));         

        parmTempUncorrExcStatDtCharType = getParameters().getTEMP_UNCORR_STATUS_DT(); 
        validateCharTypeAndEntity(parmTempUncorrExcStatDtCharType, getBatchParameterName(BigInteger.valueOf(120)));

        parmTempUncorrFieldCdCharType = getParameters().getTEMP_UNCORR_FIELD_CD(); 
        validateCharTypeAndEntity(parmTempUncorrFieldCdCharType, getBatchParameterName(BigInteger.valueOf(130)));

        parmCorrectedExcRequesterCharType = getParameters().getCORRECTED_EXCEPTION_REQUESTER(); 
        validateCharTypeAndEntity(parmCorrectedExcRequesterCharType, getBatchParameterName(BigInteger.valueOf(140)));

        parmUncorrectedExcRequesterCharType = getParameters().getUNCORRECTED_EXCEPTION_REQUEST(); 
        validateCharTypeAndEntity(parmUncorrectedExcRequesterCharType, getBatchParameterName(BigInteger.valueOf(150)));

        parmServicePointCharType = getParameters().getSP_ID(); 
        validateCharTypeAndEntity(parmServicePointCharType, getBatchParameterName(BigInteger.valueOf(160)));

        parmOwnerCharType = getParameters().getOWNER(); 
        validateCharTypeAndEntity(parmOwnerCharType, getBatchParameterName(BigInteger.valueOf(170)));

        parmLnGWorkOrderIdCharType = getParameters().getLNG_WORK_ORDER_ID(); 
        validateCharTypeAndEntity(parmLnGWorkOrderIdCharType, getBatchParameterName(BigInteger.valueOf(180)));

        parmNoAccessFlagCharType = getParameters().getNO_ACCESS_FLAG(); 
        validateCharTypeAndEntity(parmNoAccessFlagCharType, getBatchParameterName(BigInteger.valueOf(190)));

        parmOtherCharType = getParameters().getOTHER(); 
        validateCharTypeAndEntity(parmOtherCharType, getBatchParameterName(BigInteger.valueOf(200)));

        //ML20130618 - Start

        paramMeterBadgeNbrCharType = getParameters().getMETER_BADGE_NBR();
        validateCharTypeAndEntity(paramMeterBadgeNbrCharType, getBatchParameterName(BigInteger.valueOf(220)));        

        paramCreatedByCharType = getParameters().getCREATED_BY_CHAR_TYPE();
        validateCharTypeAndEntity(paramCreatedByCharType, getBatchParameterName(BigInteger.valueOf(230)));
        
        paramCreatedByCharValStr = getParameters().getCREATED_BY_CHAR_VALUE();       
        validateCharValue(paramCreatedByCharType, paramCreatedByCharValStr);

        paramCaseMgmtPortalCharType = getParameters().getCASE_MGMT_PORTAL_CHAR_TYPE();
        validateCharTypeAndEntity(paramCaseMgmtPortalCharType, getBatchParameterName(BigInteger.valueOf(250)));

        paramCaseMgmtPortalCharValStr = getParameters().getCASE_MGMT_PORTAL_CHAR_VALUE();
        validateCharValue(paramCaseMgmtPortalCharType, paramCaseMgmtPortalCharValStr);

        //ML20130618 - End
    }

    private void validateCharValue(CharacteristicType charType, String charValueStr) {

        CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charType, charValueStr);               
        if(isNull(charValueId.getEntity())){
            addError(CustomMessageRepository.na07_3InvalidCharValue(charValueStr.trim(),charType.getId().getIdValue()));  
        }
    }

    /**
     * This method will validate the input CharacteristicType is valid for the 
     * CharacteristicEntityLookup for Field Activity.
     * 
     * @param characteristicType a Characteristic Type Entity 
     * return returns Bool.TRUE if the Char Value is valid for the Char Type, otherwise returns Bool.FALSE.
     */
    private void validateCharTypeAndEntity(CharacteristicType characteristicType, String paramName) {

        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(characteristicType.getId(), CharacteristicEntityLookup.constants.CASE);
        if(isNull(charEntityId.getEntity())){
            addError(CustomMessageRepository.ni0007_3InvalidCharTypeForEntity(paramName, characteristicType.getId().getTrimmedValue()));  
        }
    }

    /**
     * This method will retrieve the batch parameter label name.
     * @param paramSeq a BigInteger value
     * @return String a String value
     */
    private String getBatchParameterName(BigInteger paramSeq){

        String paramName = "";
        BatchControlParameter_Id batchCntrlParameterId = new BatchControlParameter_Id(getBatchControlId(), paramSeq);        
        BatchControlParameter_LanguageId batchCntrlParameterLanguageId = new BatchControlParameter_LanguageId(batchCntrlParameterId, getActiveContextLanguage().getId());
        paramName = batchCntrlParameterLanguageId.getParent().getBatchParameterName();        
        return paramName;
    }

    /**
     * Method to retrieve the Thread Worker Class.
     * 
     * @return the thread worker class
     */
    public Class<CmInterfaceFileUpload_BatchProcessWorker> getThreadWorkerClass() {

        return CmInterfaceFileUpload_BatchProcessWorker.class;
    }

    /**
     * This Worker Class is responsible for processing a single Thread Instance.
     */
    public static class CmInterfaceFileUpload_BatchProcessWorker
    extends CmInterfaceFileUpload_BatchProcessWorker_Gen {

        /*
         * Start Add Neha 
         */
        //Soft parameters
        private BigInteger parmMaxErrors = null;
        private String parmFilePath;
        private String parmFileName;
        private CharacteristicType parmTempCorrExcCdCharType;
        private CharacteristicType parmTempCorrExcReqDtCharType;
        private CharacteristicType parmTempCorrExcStatusCharType;   
        private CharacteristicType parmTempCorrExcStatDtCharType; 
        private CharacteristicType parmTempCorrFieldCdCharType; 
        private CharacteristicType parmTempUncorrExcCdCharType; 
        private CharacteristicType parmTempUncorrExcReqDtCharType; 
        private CharacteristicType parmTempUncorrExcStatusCharType; 
        private CharacteristicType parmTempUncorrExcStatDtCharType; 
        private CharacteristicType parmTempUncorrFieldCdCharType; 
        private CharacteristicType parmCorrectedExcRequesterCharType; 
        private CharacteristicType parmUncorrectedExcRequesterCharType; 
        private CharacteristicType parmServicePointCharType; 
        private CharacteristicType parmOwnerCharType; 
        private CharacteristicType parmLnGWorkOrderIdCharType; 
        private CharacteristicType parmNoAccessFlagCharType; 
        private CharacteristicType parmOtherCharType; 
        private CaseType parmCaseType;
        private CharacteristicType paramMeterBadgeNbrCharType; 
        private CharacteristicType paramCreatedByCharType;
        private String paramCreatedByCharValStr;
        private CharacteristicType paramCaseMgmtPortalCharType;
        private String paramCaseMgmtPortalCharValStr;
        private File inputFile = null;
        /*
         * End Neha
         */
        // Working Variables
        private String badgeNumber = "";
        private String spId= "";
        private String exceptionRequester = "";
        private String exceptionRequesterDt = "";
        private String exceptionCd = "";
        private String exceptionStatus = "";
        private String exceptionStatusDt = "";
        private String fieldCd = "";
        private String changeoutId = "";
        private String noAccessFlg = "";
        private String owner = "";
        private String other = "";
        private String caseId = "";
        private Bool isUncorrected = Bool.TRUE;
        private ArrayList <CaseCharacteristic_DTO>  charList;// = new ArrayList<CaseCharacteristic_DTO>();

        private BufferedReader inputBufferReader = null;
        private BigInteger numberOfRecordsInError = BigInteger.ZERO;
        private BigInteger numberOfRecordsProcessed = BigInteger.ZERO;
        private BigInteger numberOfCasesCreated = BigInteger.ZERO;

        // Constants
        private static final int METER_ID_INDEX = 0;
        private static final int METER_ID_LENGTH = 20;
        private static final int UTILITY_ID_INDEX = 21;
        private static final int SP_ID_LENGTH = 10; //Utility Id has length of 25 but only first 10 correspond to SP ID
        private static final int EXC_REQ_INDEX = 74;
        private static final int EXC_REQ_LENGTH = 1;
        private static final int EXC_REQ_DATE_INDEX = 76;
        private static final int EXC_REQ_DATE_LENGTH = 6;
        private static final int REASON_CODE_1_INDEX = 83;
        private static final int REASON_CODE_1_LENGTH = 1;
        private static final int EXC_STATUS_INDEX = 88;
        private static final int EXC_STATUS_LENGTH = 1;
        private static final int EXC_DATE_INDEX = 90;
        private static final int EXC_DATE_LENGTH = 6;
        private static final int FIELD_CODE_INDEX = 97;
        private static final int FIELD_CODE_LENGTH = 4;
        private static final int CHANGEOUT_ID_INDEX = 102;
        private static final int CHANGEOUT_ID_LENGTH = 15;
        private static final int NO_ACCESS_INDEX = 118;
        private static final int NO_ACCESS_LENGTH = 1;
        private static final int OWNER_INDEX = 120;
        private static final int OWNER_LENGTH = 1;
        private static final int OTHER_INDEX = 122;
        private static final int OTHER_LENGTH = 25;
        private static final int CASE_ID_INDEX = 148;
        private static final int CASE_ID_LENGTH = 10;

        private static final String DATE_FORMAT_FILE = "yyMMdd";
        private static final String DATE_FORMAT_CASE = "yyyy-MM-dd";


        /**
         * This method identifies the execution strategy to be used for the thread.
         * 
         * @return an instance of ThreadExecutionStrategy that governs how this ThreadWorker will be executed at runtime.
         * @see com.splwg.base.api.batch.ThreadWorker#createExecutionStrategy()
         */
        public ThreadExecutionStrategy createExecutionStrategy() {

            return new SingleTransactionStrategy(this);
        }

        /**
         * Perform any initialization that must be done at the start of this thread processing work. 
         * @param initializationPreviouslySuccessful - indicates that this method was called successfully called during some 
         * prior execution, presumably because this is a restart situation.
         * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
         * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
         * @see com.splwg.base.api.batch.ThreadWorker#initializeThreadWork(boolean) 
         */
        public void initializeThreadWork(boolean initializationPreviouslySuccessful)
        throws ThreadAbortedException, RunAbortedException {

            /*
             * Start add Neha
             */
            // retrieving parameters
            JobParameters parameters = getParameters();
            parmMaxErrors = parameters.getMAX_ERRORS();
            parmFilePath = parameters.getFILE_PATH().trim();
            parmFileName = parameters.getFILE_NAME().trim();
            inputFile = new File(parmFilePath, parmFileName);
            parmTempCorrExcCdCharType = parameters.getTEMP_CORR_EXCEPTION_CD();
            parmTempCorrExcReqDtCharType = parameters.getTEMP_CORR_EXCEPTION_REQ_DT();
            parmTempCorrExcStatusCharType = parameters.getTEMP_CORR_STATUS_CD();   
            parmTempCorrExcStatDtCharType = parameters.getTEMP_CORR_STATUS_DT(); 
            parmTempCorrFieldCdCharType = parameters.getTEMP_CORR_FIELD_CD(); 
            parmTempUncorrExcCdCharType = parameters.getTEMP_UNCORR_EXCEPTION_CD(); 
            parmTempUncorrExcReqDtCharType = parameters.getTEMP_UNCORR_EXCEPTION_REQ_DT(); 
            parmTempUncorrExcStatusCharType = parameters.getTEMP_UNCORR_STATUS_CD();
            parmTempUncorrExcStatDtCharType = parameters.getTEMP_UNCORR_STATUS_DT(); 
            parmTempUncorrFieldCdCharType = parameters.getTEMP_UNCORR_FIELD_CD(); 
            parmCorrectedExcRequesterCharType = parameters.getCORRECTED_EXCEPTION_REQUESTER(); 
            parmUncorrectedExcRequesterCharType = parameters.getUNCORRECTED_EXCEPTION_REQUEST(); 
            parmServicePointCharType = parameters.getSP_ID(); 
            parmOwnerCharType = parameters.getOWNER(); 
            parmLnGWorkOrderIdCharType = parameters.getLNG_WORK_ORDER_ID(); 
            parmNoAccessFlagCharType = parameters.getNO_ACCESS_FLAG(); 
            parmOtherCharType = parameters.getOTHER(); 
            parmCaseType = parameters.getCASE_TYPE();
            paramMeterBadgeNbrCharType = parameters.getMETER_BADGE_NBR();
            paramCreatedByCharType = parameters.getCREATED_BY_CHAR_TYPE();            
            paramCreatedByCharValStr = parameters.getCREATED_BY_CHAR_VALUE();  
            paramCaseMgmtPortalCharType = parameters.getCASE_MGMT_PORTAL_CHAR_TYPE();
            paramCaseMgmtPortalCharValStr = parameters.getCASE_MGMT_PORTAL_CHAR_VALUE();
            /*
             * End add 
             */
            openFile();
        }


        /**
         * Execute a WorkUnit and provide result details.
         * 
         * @param unit - a ThreadWorkUnit
         * @return a boolean that describes the success or failure of the work unit processing.
         * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
         * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
         * @see com.splwg.base.api.batch.ThreadWorker#executeWorkUnitDetailedResult(com.splwg.base.api.batch.ThreadWorkUnit)
         */
        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {

            charList = new ArrayList<CaseCharacteristic_DTO>();
            // Open File to read detail records. 
            openFile();
            String detailRecord = null;

            while(notNull(detailRecord = readRecord())){  
                charList.clear();
                String meterNumber = getFieldValue(detailRecord,METER_ID_INDEX,METER_ID_LENGTH).trim();

                badgeNumber = meterNumber.substring(0, meterNumber.trim().length() - 4);

                String uncorrectedIndicator = meterNumber.substring(meterNumber.length() - 3, meterNumber.length() - 2);
                if(uncorrectedIndicator.compareTo("U") == 0){
                    isUncorrected = Bool.TRUE;
                }else{
                    isUncorrected = Bool.FALSE;
                }
                spId = getFieldValue(detailRecord,UTILITY_ID_INDEX,SP_ID_LENGTH);
                exceptionRequester = getFieldValue(detailRecord,EXC_REQ_INDEX,EXC_REQ_LENGTH);
                exceptionRequesterDt = getFieldValue(detailRecord,EXC_REQ_DATE_INDEX,EXC_REQ_DATE_LENGTH);
                exceptionCd = getFieldValue(detailRecord,REASON_CODE_1_INDEX,REASON_CODE_1_LENGTH);
                exceptionStatus = getFieldValue(detailRecord,EXC_STATUS_INDEX,EXC_STATUS_LENGTH);
                exceptionStatusDt = getFieldValue(detailRecord,EXC_DATE_INDEX,EXC_DATE_LENGTH);
                fieldCd = getFieldValue(detailRecord,FIELD_CODE_INDEX,FIELD_CODE_LENGTH);
                changeoutId = getFieldValue(detailRecord,CHANGEOUT_ID_INDEX,CHANGEOUT_ID_LENGTH);
                noAccessFlg = getFieldValue(detailRecord,NO_ACCESS_INDEX,NO_ACCESS_LENGTH);
                owner = getFieldValue(detailRecord,OWNER_INDEX, OWNER_LENGTH);
                other = getFieldValue(detailRecord,OTHER_INDEX, OTHER_LENGTH);
                caseId = getFieldValue(detailRecord,CASE_ID_INDEX, CASE_ID_LENGTH);

                if(isMeterNoLongerInstalled(badgeNumber,spId)){
                    logWarning(CustomMessageRepository.ni0007_3MeterNoLongerInstalled(badgeNumber, spId));
                    maxErrorHandling();
                    continue;
                }
                // Check whether an open metering exception already exists for the Meter/SP 
                List<SQLResultRow> existingCaseList = checkIfExceptionExists(spId); 
                ToDoCase_Id existingCaseId = null;  
                boolean caseFound = false;
                if(isNull(existingCaseList) || existingCaseList.isEmpty()){
                    if(isBlankOrNull(caseId)){
                        createExceptionCase();
                    }else{
                        logError(CustomMessageRepository.ni0007_3InvalidCaseIdInFile(caseId));
                        maxErrorHandling();
                        continue; 
                    }                    
                }else{
                    if(existingCaseList.size() > 1){
                        logError(CustomMessageRepository.ni0007_3MultipleCaseExistForSP(spId));
                        maxErrorHandling();
                    }
                    if(isBlankOrNull(caseId)){
                        caseFound = true;
                        if(existingCaseList.size() == 1){
                            ToDoCase_Id caseRetrieved = (ToDoCase_Id)existingCaseList.iterator().next().getId("CASE_ID", ToDoCase.class);
                            updateExceptionCase(caseRetrieved);
                        }
                    }else{                        
                        for(SQLResultRow row : existingCaseList){
                            existingCaseId  = (ToDoCase_Id)row.getId("CASE_ID", ToDoCase.class);
                            if(existingCaseId.equals(new ToDoCase_Id(caseId))){
                                caseFound = true;
                                updateExceptionCase(existingCaseId);
                                break;
                            }
                        }
                        if(!caseFound){
                            logError(CustomMessageRepository.ni0007_3InvalidCaseIdInFile(caseId));
                            maxErrorHandling();
                            continue;
                        }
                    }
                }
            }
            closeFile();
            logInfo(CustomMessageRepository.ni0007_3NumberOfCasesCreated(numberOfCasesCreated.toString()));
            WorkUnitResult workUnitResult = new WorkUnitResult(true);
            workUnitResult.setUnitsProcessed(numberOfRecordsProcessed.intValue());
            workUnitResult.setUnitsInError(numberOfRecordsInError.intValue());
            return workUnitResult; 
        }   

        /**
         * This method opens a buffered reader for input file
         *
         */
        private void openFile() {

            try {                          
                inputBufferReader = new BufferedReader(new FileReader(inputFile));                    
            } catch (IOException e) {                
                throw new RunAbortedException(CustomMessageRepository.ni0007_3ErrorInFile(e.getMessage().trim()));                                     
            } 
        }


        /**
         * This method closes a buffered reader for input file
         *
         */
        private void closeFile() {

            try {
                if(notNull(inputBufferReader))
                    inputBufferReader.close();           
            } catch (IOException e) {
                throw new RunAbortedException(CustomMessageRepository.ni0007_3ErrorInFile(e.getMessage().trim()));                                      
            }
        }        

        /**
         * This method handles Max Error handling
         */
        private void maxErrorHandling() {
            numberOfRecordsInError = numberOfRecordsInError.add(BigInteger.ONE);

            if (notNull(parmMaxErrors)) {
                if (numberOfRecordsInError.intValue() >= parmMaxErrors.intValue()) {
                    throw new RunAbortedException(CustomMessageRepository.ni0007_3MaxErrorCountReached(parmMaxErrors.toString()));
                }
            }
        }   

        private String getFieldValue(String record, int startPos, int length) {
            String value = "";
            if(record.length() >= startPos+length){
                value = record.substring(startPos, startPos+length).trim();
            }
            return value;
        }

        private boolean isMeterNoLongerInstalled(String badgeNumber, String spId){
            StringBuilder getMeterString = new StringBuilder();
            getMeterString.append("SELECT MTR.MTR_ID, HIST.SP_ID ");
            getMeterString.append("FROM CI_MTR MTR, CI_SP_MTR_EVT EVNT ");
            getMeterString.append(", CI_MTR_CONFIG CONFIG ");
            getMeterString.append(", CI_SP_MTR_HIST HIST ");
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //getMeterString.append("WHERE TRIM(MTR.BADGE_NBR) = :badgeNumber ");
            getMeterString.append("WHERE MTR.BADGE_NBR = :badgeNumber ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change
            getMeterString.append("AND CONFIG.MTR_ID = MTR.MTR_ID ");
            getMeterString.append("AND CONFIG.EFF_DTTM <= :processDateTime ");
            getMeterString.append("AND EVNT.SP_MTR_EVT_FLG = :install ");
            getMeterString.append("AND HIST.SP_ID = :spId ");
            getMeterString.append("AND HIST.SP_MTR_HIST_ID = EVNT.SP_MTR_HIST_ID ");
            getMeterString.append("AND HIST.MTR_CONFIG_ID = CONFIG.MTR_CONFIG_ID ");
            getMeterString.append("AND (HIST.REMOVAL_DTTM IS NULL OR HIST.REMOVAL_DTTM > :processDateTime) ");
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement meterPrepStmt = createPreparedStatement(getMeterString.toString()); 
            PreparedStatement meterPrepStmt = createPreparedStatement(getMeterString.toString(), getClass().getName()); 
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            meterPrepStmt.bindStringProperty("badgeNumber", Meter.properties.badgeNumber,badgeNumber);
            meterPrepStmt.bindDateTime("processDateTime", getProcessDateTime());
            meterPrepStmt.bindLookup("install", ServicePointMeterEventTypeLookup.constants.INSTALL);
            meterPrepStmt.bindId("spId", new ServicePoint_Id(spId));
            if(meterPrepStmt.list().isEmpty()){ //record retrieved for removed meter query
                meterPrepStmt.close();
                return true;
            }else{
                meterPrepStmt.close();
                return false;
            }            
        }

        private List<SQLResultRow> checkIfExceptionExists(String spId){
            StringBuilder getExcString = new StringBuilder();
            getExcString.append("SELECT CASECH.CASE_ID FROM CI_CASE CSE, CI_CASE_CHAR CASECH ");
            getExcString.append("WHERE CASECH.CHAR_TYPE_CD = :spIdCharType ");
            // CVB - 2013-07-11 - Start
            // getExcString.append("AND TRIM(CASECH.CHAR_VAL_FK1) = :spId "); 
            getExcString.append("AND CASECH.SRCH_CHAR_VAL = :spId ");
            // CVB - 2013-07-11 - End
            getExcString.append("AND CASECH.CASE_ID = CSE.CASE_ID "); 
            getExcString.append("AND CSE.CASE_COND_FLG = :open "); 
            // Start changes 08-29-2013
            getExcString.append("AND CSE.CASE_TYPE_CD = :caseType ");
            // End changes 08-29-2013
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement getExcPrepStmt = createPreparedStatement(getExcString.toString()); 
            PreparedStatement getExcPrepStmt = createPreparedStatement(getExcString.toString(), getClass().getName()); 
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            getExcPrepStmt.bindId("spIdCharType", parmServicePointCharType.getId());
            // CVB - 2013-07-11 - Start
            // getExcPrepStmt.bindStringProperty("spId", CaseCharacteristic.properties.characteristicValueForeignKey1, spId.trim());
            getExcPrepStmt.bindStringProperty("spId", CaseCharacteristic.properties.searchCharacteristicValue, spId);
            // CVB - 2013-07-11 - End
            getExcPrepStmt.bindLookup("open", CaseConditionLookup.constants.OPEN);
            // Start changes IM-036038
            getExcPrepStmt.bindId("caseType", parmCaseType.getId());
            // End changes IM-036038
            List<SQLResultRow> exceptionList = null;

            exceptionList = getExcPrepStmt.list();
            getExcPrepStmt.close();

            return exceptionList;
        }

        /**
         * This method returns the next record from the input file.
         * @return a String object.
         */
        private String readRecord() {

            String record = null;
            try {
                record =  inputBufferReader.readLine();                 
            } catch (IOException exception) {

                throw new RunAbortedException(CustomMessageRepository.ni0007_3ErrorInFile(exception.getMessage().trim()));
            }  
            return record;
        }

        private void createExceptionCase(){

            ToDoCase_DTO toDoCaseDTO = (ToDoCase_DTO) createDTO(ToDoCase.class);
            // To avoid lazy initialization reinitialize case type
            parmCaseType = parmCaseType.getId().getEntity();
            CaseTypeCaseStatues statuses = parmCaseType.getCaseStatues();
            for (CaseStatus status : statuses){
                if(status.getStatusCondition().isInitial()){
                    toDoCaseDTO.setCaseStatusId(status.getId());
                }
            }
            Account_Id accountId = null;
            Person_Id personId = null;
            String phone = "";
            List<SQLResultRow> usageList = getUsageInformation(spId);
            if(!usageList.isEmpty()){
                accountId = (Account_Id)usageList.iterator().next().getId("ACCT_ID", Account.class);
                personId = (Person_Id)usageList.iterator().next().getId("PER_ID", Person.class);                
            }
            // Start CR change
            /*if(parmCaseType.getAccountUsage().isRequired()){
                toDoCaseDTO.setAccountId(accountId);
            }
            if(parmCaseType.getPersonUsage().isRequired()){
                toDoCaseDTO.setPersonId(personId);
            }*/
            if(isNull(accountId) && (parmCaseType.getAccountUsage().isRequired())){
                addError(CustomMessageRepository.ni0007_3AccountNotFoundButReqdOnCase(spId,parmCaseType.getId().getTrimmedValue()));
            }
            if(notNull(accountId) && ((parmCaseType.getAccountUsage().isRequired()) || parmCaseType.getAccountUsage().isOptional())){
                toDoCaseDTO.setAccountId(accountId);
            }
            if(isNull(personId) && (parmCaseType.getPersonUsage().isRequired())){
                addError(CustomMessageRepository.ni0007_3PersonNotFoundButReqdOnCase(spId,parmCaseType.getId().getTrimmedValue()));
            }
            if(notNull(personId) && (parmCaseType.getPersonUsage().isRequired() || parmCaseType.getPersonUsage().isOptional())){
                toDoCaseDTO.setPersonId(personId);
            }
            // End CR change
            if(parmCaseType.getCallbackPhoneUsage().isRequired()){
                if(notNull(personId)){
                    List<SQLResultRow> list = getPhoneInformation(personId);
                    phone = list.iterator().next().getString("PHONE");
                    toDoCaseDTO.setPhoneTypeId((PhoneType_Id)list.iterator().next().getId("PHONE_TYPE_CD", PhoneType.class));
                    toDoCaseDTO.setPhone(phone);
                }
            }
            if(parmCaseType.getContactInformationUsage().isRequired()){
                toDoCaseDTO.setContactPersonId(personId);
                toDoCaseDTO.setPreferredContactMethod(ContactMethodLookup.constants.NOT_APPLICABLE);
            }
            if(parmCaseType.getContactInstructionsUsage().isRequired()){
                toDoCaseDTO.setContactInstructions(CustomMessageRepository.ni0007_3ContactInstructionsUsage().getMessageText());
            }
            // Start CR change
            /* if(parmCaseType.getPremiseUsage().isRequired()){
                toDoCaseDTO.setPremiseId((new ServicePoint_Id(spId)).getEntity().getPremise().getId());
            }*/
            ServicePoint_Id servicePointId = new ServicePoint_Id(spId);
            if(isNull(servicePointId.getEntity().getPremise()) && parmCaseType.getPremiseUsage().isRequired()){
                addError(CustomMessageRepository.ni0007_3PremiseNotFoundButReqdOnCase(servicePointId.getTrimmedValue(), parmCaseType.getId().getTrimmedValue()));
            }
            if(parmCaseType.getPremiseUsage().isRequired() || parmCaseType.getPremiseUsage().isOptional()){
                toDoCaseDTO.setPremiseId(servicePointId.getEntity().getPremise().getId());
            }
            // End CR change
            if(parmCaseType.getResponsibleUserUsage().isRequired()){
                toDoCaseDTO.setUserId(getActiveContextUser().getId());
            }

            if(isUncorrected.isTrue()){ 
                if(!addCharacteristic(ToDoCase_Id.NULL, parmTempUncorrExcCdCharType, exceptionCd)){
                    return;
                }
                if(!addCharacteristic(ToDoCase_Id.NULL, parmUncorrectedExcRequesterCharType, exceptionRequester)){
                    return;
                }
                if(!addCharacteristic(ToDoCase_Id.NULL, parmTempUncorrExcReqDtCharType, convertFileDateToCaseCharFormat(exceptionRequesterDt))){
                    return;
                }
                if(!addCharacteristic(ToDoCase_Id.NULL, parmTempUncorrExcStatusCharType, exceptionStatus)){
                    return;
                }
                if(!addCharacteristic(ToDoCase_Id.NULL, parmTempUncorrExcStatDtCharType, convertFileDateToCaseCharFormat(exceptionStatusDt))){
                    return;
                }
                if(!addCharacteristic(ToDoCase_Id.NULL, parmTempUncorrFieldCdCharType, fieldCd)){
                    return;
                }

            }else{
                if(!addCharacteristic(ToDoCase_Id.NULL, parmTempCorrExcCdCharType, exceptionCd)){
                    return;
                }
                if(!addCharacteristic(ToDoCase_Id.NULL, parmCorrectedExcRequesterCharType, exceptionRequester)){
                    return;
                }
                if(!addCharacteristic(ToDoCase_Id.NULL, parmTempCorrExcReqDtCharType, convertFileDateToCaseCharFormat(exceptionRequesterDt))){
                    return;
                }
                if(!addCharacteristic(ToDoCase_Id.NULL, parmTempCorrExcStatusCharType, exceptionStatus)){
                    return;
                }
                if(!addCharacteristic(ToDoCase_Id.NULL, parmTempCorrExcStatDtCharType, convertFileDateToCaseCharFormat(exceptionStatusDt))){
                    return;
                }
                if(!addCharacteristic(ToDoCase_Id.NULL, parmTempCorrFieldCdCharType, fieldCd)){
                    return;
                }

            }

            // Add if new Case or else update the characteristic with new value
            if(!addCharacteristic(ToDoCase_Id.NULL, parmServicePointCharType, spId)){
                return;
            }
            if(!addCharacteristic(ToDoCase_Id.NULL, parmOwnerCharType, owner)){
                return;
            }
            if(!addCharacteristic(ToDoCase_Id.NULL, parmOtherCharType, other)){
                return;
            }
            if(!addCharacteristic(ToDoCase_Id.NULL, parmLnGWorkOrderIdCharType, changeoutId)){
                return;
            }
            if(!addCharacteristic(ToDoCase_Id.NULL, parmNoAccessFlagCharType, noAccessFlg)){
                return;
            }

            // ML20130618 - Start

            if(!addCharacteristic(ToDoCase_Id.NULL, paramMeterBadgeNbrCharType, badgeNumber)){
                return;
            }

            if(!addCharacteristic(ToDoCase_Id.NULL, paramCreatedByCharType, paramCreatedByCharValStr)){
                return;
            }

            if(!addCharacteristic(ToDoCase_Id.NULL, paramCaseMgmtPortalCharType, paramCaseMgmtPortalCharValStr)){                
                return;
            }

            // ML20130618 - End

            CaseCreatorData caseCreatorData = CaseCreatorData.Factory.newInstance();
            caseCreatorData.setToDoCaseDTO(toDoCaseDTO);             
            caseCreatorData.setCaseCharacteristics(charList);

            CaseCreator caseCreator = CaseCreator.Factory.newInstance();
            caseCreatorData = caseCreator.createCase(caseCreatorData);
            numberOfRecordsProcessed = numberOfRecordsProcessed.add(BigInteger.ONE);
            numberOfCasesCreated = numberOfCasesCreated.add(BigInteger.ONE);
        }

        private List<SQLResultRow> getUsageInformation(String spId){
            StringBuilder getUsageDetailsString = new StringBuilder();
            getUsageDetailsString.append("SELECT SA.ACCT_ID, APER.PER_ID,(SELECT PHONE FROM CI_PER_PHONE WHERE PER_ID = APER.PER_ID AND ROWNUM <=1) PHONE ");
            getUsageDetailsString.append("FROM CI_SA_SP SASP ");
            getUsageDetailsString.append(", CI_SA SA ");
            getUsageDetailsString.append(", CI_ACCT_PER APER ");
            getUsageDetailsString.append("WHERE SASP.SP_ID = :spId ");
            getUsageDetailsString.append("AND SASP.SA_ID = SA.SA_ID ");
			// Start add 2014-03-21	Neha IM-044199
			getUsageDetailsString.append("AND SASP.START_DTTM = (SELECT MAX(START_DTTM) FROM CI_SA_SP WHERE SP_ID = :spId) ");
			// End add 2014-03-21	Neha IM-044199
            getUsageDetailsString.append("AND SA.ACCT_ID = APER.ACCT_ID  "); 
            getUsageDetailsString.append("AND APER.MAIN_CUST_SW = 'Y' "); 
            getUsageDetailsString.append("AND APER.ACCT_REL_TYPE_CD = 'MAIN' "); 
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString()); 
            PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            getUsageDetailsPrepStmt.bindId("spId", new ServicePoint_Id(spId));

            List<SQLResultRow> usageList = getUsageDetailsPrepStmt.list();

            getUsageDetailsPrepStmt.close();

            return usageList;
        }

        private List<SQLResultRow> getPhoneInformation(Person_Id perId){
            StringBuilder getUsageDetailsString = new StringBuilder();
            getUsageDetailsString.append("SELECT PHONE , PHONE_TYPE_CD FROM CI_PER_PHONE WHERE PER_ID = :perId ");
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString()); 
            PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString(), getClass().getName()); 
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            getUsageDetailsPrepStmt.bindId("perId", perId);

            List<SQLResultRow> usageList = getUsageDetailsPrepStmt.list();

            getUsageDetailsPrepStmt.close();

            return usageList;
        }

        private void updateExceptionCase(ToDoCase_Id caseId){

            Date fileDate = null;
            try {
                fileDate = Date.fromString(exceptionStatusDt, new DateFormat(DATE_FORMAT_FILE));
            } catch (DateFormatParseException e) {
                logError(CustomMessageRepository.ni0007_3InvalidDate(exceptionStatusDt.trim()));
                maxErrorHandling();
            }
            if(isUncorrected.isTrue()){ // If file record is uncorrected then compare uncorrected dates
                String dateStr = getCharacteristic(caseId, parmTempUncorrExcStatDtCharType);
                Date date = null;
                if(!isBlankOrNull(dateStr)){
                    try {
                        date = Date.fromString(dateStr, new DateFormat(DATE_FORMAT_CASE));
                    } catch (DateFormatParseException e) {
                        e.printStackTrace();
                    }
                }
                if(notNull(date) && fileDate.isSameOrBefore(date)){
                    logError(CustomMessageRepository.ni0007_3RecordWithOlderDate(caseId.getTrimmedValue()));
                    maxErrorHandling();
                    return;
                }else{
                    // Start change Neha IM-042812 2013-12-18
                    /*if(!addCharacteristic(caseId, parmTempUncorrExcCdCharType, exceptionCd)){
                        return;
                    }
                    if(!addCharacteristic(caseId, parmUncorrectedExcRequesterCharType, exceptionRequester)){
                        return;
                    }
                    if(!addCharacteristic(caseId, parmTempUncorrExcReqDtCharType, convertFileDateToCaseCharFormat(exceptionRequesterDt))){                    
                        return;
                    }
                    if(!addCharacteristic(caseId, parmTempUncorrExcStatusCharType, exceptionStatus)){
                        return;
                    }
                    if(!addCharacteristic(caseId, parmTempUncorrExcStatDtCharType, convertFileDateToCaseCharFormat(exceptionStatusDt))){
                        return;
                    }
                    if(!addCharacteristic(caseId, parmTempUncorrFieldCdCharType, fieldCd)){
                        return;
                    }*/
                    if(!updateCharacteristic(caseId, parmTempUncorrExcCdCharType, exceptionCd)){
                        return;
                    }
                    if(!updateCharacteristic(caseId, parmUncorrectedExcRequesterCharType, exceptionRequester)){
                        return;
                    }
                    if(!updateCharacteristic(caseId, parmTempUncorrExcReqDtCharType, convertFileDateToCaseCharFormat(exceptionRequesterDt))){                    
                        return;
                    }
                    if(!updateCharacteristic(caseId, parmTempUncorrExcStatusCharType, exceptionStatus)){
                        return;
                    }
                    if(!updateCharacteristic(caseId, parmTempUncorrExcStatDtCharType, convertFileDateToCaseCharFormat(exceptionStatusDt))){
                        return;
                    }
                    if(!updateCharacteristic(caseId, parmTempUncorrFieldCdCharType, fieldCd)){
                        return;
                    }
                    // End change Neha IM-042812 2013-12-18
                }
            }else{
                String dateStr = getCharacteristic(caseId, parmTempCorrExcStatDtCharType);
                Date date = null;
                if(!isBlankOrNull(dateStr)){
                    try {
                        date = Date.fromString(dateStr, new DateFormat(DATE_FORMAT_CASE));
                    } catch (DateFormatParseException e) {
                        e.printStackTrace();
                    }
                }
                if(notNull(date) && fileDate.isSameOrBefore(date)){
                    logError(CustomMessageRepository.ni0007_3RecordWithOlderDate(caseId.getTrimmedValue()));
                    maxErrorHandling();
                    return;
                }else{// Start change Neha IM-042812 2013-12-18
                    /*if(!addCharacteristic(caseId, parmTempCorrExcCdCharType, exceptionCd)){
                        return;
                    }
                    if(!addCharacteristic(caseId, parmCorrectedExcRequesterCharType, exceptionRequester)){
                        return;
                    }
                    if(!addCharacteristic(caseId, parmTempCorrExcReqDtCharType, convertFileDateToCaseCharFormat(exceptionRequesterDt))){
                        return;
                    }
                    if(!addCharacteristic(caseId, parmTempCorrExcStatusCharType, exceptionStatus)){
                        return;
                    }
                    if(!addCharacteristic(caseId, parmTempCorrExcStatDtCharType, convertFileDateToCaseCharFormat(exceptionStatusDt))){
                        return;
                    }
                    if(!addCharacteristic(caseId, parmTempCorrFieldCdCharType, fieldCd)){
                        return;
                    }*/
                    if(!updateCharacteristic(caseId, parmTempCorrExcCdCharType, exceptionCd)){
                        return;
                    }
                    if(!updateCharacteristic(caseId, parmCorrectedExcRequesterCharType, exceptionRequester)){
                        return;
                    }
                    if(!updateCharacteristic(caseId, parmTempCorrExcReqDtCharType, convertFileDateToCaseCharFormat(exceptionRequesterDt))){
                        return;
                    }
                    if(!updateCharacteristic(caseId, parmTempCorrExcStatusCharType, exceptionStatus)){
                        return;
                    }
                    if(!updateCharacteristic(caseId, parmTempCorrExcStatDtCharType, convertFileDateToCaseCharFormat(exceptionStatusDt))){
                        return;
                    }
                    if(!updateCharacteristic(caseId, parmTempCorrFieldCdCharType, fieldCd)){
                        return;
                    }
                 // End change Neha IM-042812 2013-12-18
                }
            }
            if(!updateCharacteristic(caseId, parmServicePointCharType, spId)){
                return;
            }
            if(!updateCharacteristic(caseId, parmOwnerCharType, owner)){
                return;
            }
            if(!updateCharacteristic(caseId, parmOtherCharType, other)){
                return;
            }
            if(!updateCharacteristic(caseId, parmLnGWorkOrderIdCharType, changeoutId)){
                return;
            }
            if(!updateCharacteristic(caseId, parmNoAccessFlagCharType, noAccessFlg)){
                return;
            }
            numberOfRecordsProcessed = numberOfRecordsProcessed.add(BigInteger.ONE);

            ToDoCaseCharacteristics toDoCaseChars = caseId.getEntity().getCharacteristics();
            for(CaseCharacteristic_DTO caseCharDto : charList){
                CaseCharacteristic caseChar = caseCharDto.newEntity();
                toDoCaseChars.add(caseChar);
            }
        }

        private String getCharacteristic(ToDoCase_Id caseId, CharacteristicType charType){
            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

            StringBuilder getCharString = new StringBuilder();
            getCharString.append("SELECT CH.ADHOC_CHAR_VAL, CH.CHAR_VAL, CH.CHAR_VAL_FK1 FROM CI_CASE_CHAR CH ");
            getCharString.append("WHERE CH.CASE_ID = :caseId ");
            getCharString.append("AND CH.CHAR_TYPE_CD = :charTypecd ");
            getCharString.append("AND CH.SEQ_NUM = (SELECT MAX(CASECH.SEQ_NUM) FROM CI_CASE_CHAR CASECH  "); 
            getCharString.append("                  WHERE CASECH.CASE_ID = CH.CASE_ID "); 
            getCharString.append("                  AND CASECH.CHAR_TYPE_CD = :charTypecd"); 
            getCharString.append("                  ) "); 
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement getCharPrepStmt = createPreparedStatement(getCharString.toString()); 
            PreparedStatement getCharPrepStmt = createPreparedStatement(getCharString.toString(), getClass().getName()); 
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            getCharPrepStmt.bindId("caseId", caseId);
            getCharPrepStmt.bindId("charTypecd", charType.getId());

            List<SQLResultRow> charList = null;

            charList = getCharPrepStmt.list();
            getCharPrepStmt.close();
            if(!charList.isEmpty()){
                if(charTypeLookup.isAdhocValue()){
                    return charList.iterator().next().getString("ADHOC_CHAR_VAL").trim();
                } else if (charTypeLookup.isPredefinedValue()){
                    return charList.iterator().next().getString("CHAR_VAL").trim();
                } else if (charTypeLookup.isForeignKeyValue()){
                    return charList.iterator().next().getString("CHAR_VAL_FK1").trim();
                }
            }
            return "";
        }

        private String convertFileDateToCaseCharFormat(String fileDate){
            Date dateInFile = null;
            String dateInCase ="";
            try{
                dateInFile = Date.fromString(fileDate, new DateFormat(DATE_FORMAT_FILE));
                dateInCase = dateInFile.toString(new DateFormat(DATE_FORMAT_CASE));
            } catch (DateFormatParseException e) {
                logError(CustomMessageRepository.ni0007_3InvalidDate(fileDate.trim()));
                maxErrorHandling();
            }
            return dateInCase;
        }

        private boolean addCharacteristic(ToDoCase_Id caseId, CharacteristicType charType, String charVal){
            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

            if(isBlankOrNull(charVal)){                
                return true;
            }

            if(charTypeLookup.isPredefinedValue()){
                boolean validCharVal = false;
                // validate char value
                CharacteristicTypeValues charTypeValues = charType.getId().getEntity().getValues();  // re-initialize to avoid lazy initialization
                for(CharacteristicValue charValIter : charTypeValues){
                    if(charValIter.fetchIdCharacteristicValue().trim().compareTo(charVal) == 0){
                        validCharVal = true;
                        break;
                    }   
                }
                if(!validCharVal){
                    // log an error in batch run tree
                    logError(CustomMessageRepository.ni0007_3InvalidFieldInFile(charVal, charType.fetchLanguageDescription().trim()));
                    maxErrorHandling();
                    return false;
                }
            } 


            CaseCharacteristic_DTO caseCharacteristicDTO;
            String existingValue;
            if(notNull(caseId.getEntity())){ //if case exists add a new char if value differs
                existingValue = getCharacteristic(caseId, charType);
                if(!isBlankOrNull(existingValue)){
                    if(existingValue.trim().compareTo(charVal.trim()) == 0){
                        return true;
                    }
                }
                // If value is not same then create new char
                ToDoCaseCharacteristics caseCharacteristics = caseId.getEntity().getCharacteristics();

                //ML20130611 - Start

                BigInteger maxSeqNum =   retrieveMaxSeqNum(caseId,charType);

                /*  ListFilter<CaseCharacteristic> caseCharListFilter = caseCharacteristics.createFilter(" WHERE this.id.characteristicType = :characteristicType ");
                caseCharListFilter.bindEntity("characteristicType",charType);*/

                caseCharacteristicDTO  = caseCharacteristics.newChildDTO();
                caseCharacteristicDTO.setId(new CaseCharacteristic_Id(charType, caseId.getEntity(), maxSeqNum.add(BigInteger.ONE)));
                //ML20130611 - End

            }else{

                CaseCharacteristic_Id caseCharacteristicId = new CaseCharacteristic_Id(charType.getId(), caseId, BigInteger.ONE);            
                caseCharacteristicDTO = caseCharacteristicId.newDTO();
            }

            if(charTypeLookup.isAdhocValue()){
                caseCharacteristicDTO.setAdhocCharacteristicValue(charVal);
            } else if (charTypeLookup.isPredefinedValue()){
                caseCharacteristicDTO.setCharacteristicValue(charVal);
            } else if (charTypeLookup.isForeignKeyValue()){
                caseCharacteristicDTO.setCharacteristicValueForeignKey1(charVal);
            }
            charList.add(caseCharacteristicDTO);
            return true;
        }

        //ML20130611 - Start

        private BigInteger retrieveMaxSeqNum(ToDoCase_Id caseId,
                CharacteristicType charType) {
            StringBuilder caseCharStr = new StringBuilder();
            caseCharStr.append("SELECT MAX(SEQ_NUM) AS SEQ_NUM FROM CI_CASE_CHAR CH ");
            caseCharStr.append("WHERE CH.CASE_ID = :caseId ");
            caseCharStr.append("AND CH.CHAR_TYPE_CD = :charTypecd ");
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement caseCharPrepStmt = createPreparedStatement(caseCharStr.toString()); 
            PreparedStatement caseCharPrepStmt = createPreparedStatement(caseCharStr.toString(), getClass().getName()); 
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            caseCharPrepStmt.bindId("caseId", caseId);
            caseCharPrepStmt.bindId("charTypecd", charType.getId());

            SQLResultRow resultRow = caseCharPrepStmt.firstRow();
            caseCharPrepStmt.close();

            BigInteger maxSeqNum = resultRow.getInteger("SEQ_NUM");

            if(isNull(maxSeqNum)){
                maxSeqNum = BigInteger.ZERO;
            }

            return maxSeqNum;
        }

        //ML20130611 - End

        private boolean updateCharacteristic(ToDoCase_Id caseId, CharacteristicType charType, String charVal){
            CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

            if(isBlankOrNull(charVal)){
                // if value is blank skip the record
                return true;
            }

            if(charTypeLookup.isPredefinedValue()){
                boolean validCharVal = false;
                // validate char value
                CharacteristicTypeValues charTypeValues = charType.getId().getEntity().getValues();  // re-initialize to avoid lazy initialization
                for(CharacteristicValue charValIter : charTypeValues){
                    if(charValIter.fetchIdCharacteristicValue().trim().compareTo(charVal) == 0){
                        validCharVal = true;
                        break;
                    }   
                }
                if(!validCharVal){
                    // log an error in batch run tree
                    logError(CustomMessageRepository.ni0007_3InvalidFieldInFile(charVal, charType.getId().getTrimmedValue()));
                    maxErrorHandling();
                    return false;
                }
            } 


            CaseCharacteristic_DTO caseCharacteristicDTO;
            ToDoCaseCharacteristics caseCharacteristics = caseId.getEntity().getCharacteristics();

            //ML20130611 - Start
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //ListFilter<CaseCharacteristic> caseCharListFilter = caseCharacteristics.createFilter(" WHERE this.id.characteristicType = :characteristicType ");
            ListFilter<CaseCharacteristic> caseCharListFilter = caseCharacteristics.createFilter(
            		" WHERE this.id.characteristicType = :characteristicType ", getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            caseCharListFilter.bindEntity("characteristicType",charType);

            if(caseCharListFilter.listSize()==0){
                // If no Char Type exists, add the Characteristic of that type
                addCharacteristic(caseId, charType, charVal);
            } else {
                //  retrieveCaseCharacteristic(caseId, charType);

                CaseCharacteristic caseCharacteristic = caseCharListFilter.iterate().next();

                //ML20130611 - End

                caseCharacteristicDTO  = caseCharacteristic.getDTO();

                if(charTypeLookup.isAdhocValue()){
                    caseCharacteristicDTO.setAdhocCharacteristicValue(charVal);
                } else if (charTypeLookup.isPredefinedValue()){
                    caseCharacteristicDTO.setCharacteristicValue(charVal);
                } else if (charTypeLookup.isForeignKeyValue()){
                    caseCharacteristicDTO.setCharacteristicValueForeignKey1(charVal);
                }
                caseCharacteristic.setDTO(caseCharacteristicDTO);
            }
            return true;
        }

        /**
         * Perform final processing before ending the thread.
         * 
         * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
         * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
         * @see com.splwg.base.api.batch.ThreadWorker#finalizeThreadWork() 
         */
        public void finalizeThreadWork() 
        throws ThreadAbortedException, RunAbortedException {

            try {
                if(notNull(inputBufferReader)){
                    inputBufferReader.close();                    
                }
            } catch (IOException exception) {

                throw new RunAbortedException(CustomMessageRepository.ni0007_3ErrorInFile(exception.getMessage().trim()));
            }
        }
    }
}