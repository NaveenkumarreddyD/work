/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPPDPPX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      NI0040.5. Initial Version.      
 * 2016-04-29   AUmali      Issue 29. JACOB Conversion 
 * 2016-05-30   MPang       Defect 3444302. Added close connection
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.
 * 2025-11-14   EQuint      CCB25.4 Upgrade                  
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.matchType.algorithm.payDistributionOverride;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.api.lookup.DebitCreditFlagLookup;
import com.splwg.ccb.domain.admin.data.MatchTypePaymentDistributionData;
import com.splwg.ccb.domain.admin.depositClass.entity.DepositClass;
import com.splwg.ccb.domain.admin.matchType.algorithm.payDistributionOverride.PaymentDistributionOverrideAlgorithmSpot;
import com.splwg.ccb.domain.admin.matchType.entity.MatchType;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.financial.matchEvent.entity.MatchEvent;
import com.splwg.ccb.domain.financial.matchEvent.entity.MatchEvent_Id;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmppdppx;

/**
 * @author Administrator
 *
@AlgorithmComponent ()
 */
public class CmDistributePaymentbyPremiseAndCollAgyRefAlgComp_Impl extends
		CmDistributePaymentbyPremiseAndCollAgyRefAlgComp_Gen implements
		PaymentDistributionOverrideAlgorithmSpot {

	// hard parameter
	private Money excessCreditAmountPaid;
	private DebitCreditFlagLookup isDebitOrCredit;
	private MatchEvent matchEvent;
	// Start Update AUmali 04/29/2016 Issue 29 JACOB Conversion
	//private List<MatchTypePaymentDistributionData> matchTypePaymentDistributionDatas;
	private List<MatchTypePaymentDistributionData> matchTypePaymentDistributionDatas = new ArrayList<MatchTypePaymentDistributionData>();
	// End Update AUmali 04/29/2016 Issue 29 JACOB Conversion
	private Bool shouldDistribute;
	private Bill startBill;
	private MatchEvent startMatchEvent;
	private ServiceAgreement startServiceAgreement;
	private Money totalAmountDistributed;
	private Account account;
	private Money creditAmount;
	private DepositClass depositClass;
	private MatchType matchType;
	private String matchValue;
	private Payment payment;
	private Date processDate;
	
	private Cmppdppx cmppdppx;
	//Start Add - MPang - Defect 3444302- 2016-05-30
	private Connection connection;
	//End Add - MPang - Defect 3444302- 2016-05-30
	
	// constants
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	
	@Override
	public Money getExcessCreditAmountPaid() {
		return excessCreditAmountPaid;
	}

	@Override
	public DebitCreditFlagLookup getIsDebitOrCredit() {
		return isDebitOrCredit;
	}

	@Override
	public MatchEvent getMatchEvent() {
		return matchEvent;
	}

	@Override
	public List<MatchTypePaymentDistributionData> getPaymentDistributions() {
		return matchTypePaymentDistributionDatas;
	}

	@Override
	public Bool getShouldDistribute() {
		return shouldDistribute;
	}

	@Override
	public Bill getStartBill() {
		return startBill;
	}

	@Override
	public MatchEvent getStartMatchEvent() {
		return startMatchEvent;
	}

	@Override
	public ServiceAgreement getStartServiceAgreement() {
		return startServiceAgreement;
	}

	@Override
	public Money getTotalAmountDistributed() {
		return totalAmountDistributed;
	}

	@Override
	public void setAccount(Account arg0) {
		account = arg0;
	}

	@Override
	public void setCreditAmount(Money arg0) {
		creditAmount  =arg0;
	}

	@Override
	public void setDepositClass(DepositClass arg0) {
		depositClass = arg0;
	}

	@Override
	public void setIsDebitOrCredit(DebitCreditFlagLookup arg0) {
		isDebitOrCredit = arg0;
	}

	@Override
	public void setMatchEvent(MatchEvent arg0) {
		matchEvent = arg0;
	}

	@Override
	public void setMatchType(MatchType arg0) {
		matchType = arg0;
	}

	@Override
	public void setMatchValue(String arg0) {
		matchValue = arg0;
	}

	@Override
	public void setPayment(Payment arg0) {
		payment = arg0;
	}

	@Override
	public void setProcessDate(Date arg0) {
		processDate = arg0;
	}

	@Override
	public void setShouldDistribute(Bool arg0) {
		shouldDistribute = arg0;
	}

	@Override
	public void setStartBill(Bill arg0) {
		startBill = arg0;
	}

	@Override
	public void setStartMatchEvent(MatchEvent arg0) {
		startMatchEvent = arg0;
	}

	@Override
	public void setStartServiceAgreement(ServiceAgreement arg0) {
		startServiceAgreement = arg0;
	}
	
	@Override
	public void invoke() {
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			
			if (notNull(account)) {
				cmppdppx.setPmdrxInputWrkAcctId(account.getId().getTrimmedValue());
			}else{
				cmppdppx.setPmdrxInputWrkAcctId(CobolCode.SPACES.toString());
			}
			if (notNull(creditAmount)) {
				cmppdppx.setInputWrkCreditAmt(creditAmount.getAmount().toBigDecimal());
			}else{
				cmppdppx.setInputWrkCreditAmt(java.math.BigDecimal.ZERO);
			}
			if (notNull(depositClass)) {
				cmppdppx.setPmdrxInputWrkDepClCd(depositClass.getId().getTrimmedValue());
			}else{
				cmppdppx.setPmdrxInputWrkDepClCd(CobolCode.SPACES.toString());
			}
			if (notNull(isDebitOrCredit)) {
				cmppdppx.setDbCrFlg(isDebitOrCredit.trimmedValue());
			}else{
				cmppdppx.setDbCrFlg(CobolCode.SPACES.toString());
			}
			if (notNull(matchEvent)) {
				cmppdppx.setMatchEvtId(matchEvent.getId().getTrimmedValue());
			}else{
				cmppdppx.setMatchEvtId(CobolCode.SPACES.toString());
			}
			if (notNull(processDate)) {
				cmppdppx.setPmdrxInputWrkProcessDt(processDate.toString());
			}else{
				cmppdppx.setPmdrxInputWrkProcessDt(CobolCode.SPACES.toString());
			}
			if (notNull(payment)) {
				cmppdppx.setPayId(payment.getId().getTrimmedValue());
			}else{
				cmppdppx.setPayId(CobolCode.SPACES.toString());
			}
			if (notNull(matchType)) {
				cmppdppx.setMatchTypeCd(matchType.getId().getTrimmedValue());
			}else{
				cmppdppx.setMatchTypeCd(CobolCode.SPACES.toString());
			}
			if (notNull(matchValue)) {
				cmppdppx.setMatchVal(matchValue.trim());
			}else{
				cmppdppx.setMatchVal(CobolCode.SPACES.toString());
			}
			if (notNull(shouldDistribute)) {
				String distSw = (shouldDistribute.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmppdppx.setDistributedSw(distSw);
			}else{
				cmppdppx.setDistributedSw(CobolCode.SPACES.toString());
			}
			if (notNull(startBill)) {
				cmppdppx.setStartBillId(startBill.getId().getTrimmedValue());
			}else{
				cmppdppx.setStartBillId(CobolCode.SPACES.toString());
			}
			if (notNull(startMatchEvent)) {
				cmppdppx.setStartMatchEvtId(startMatchEvent.getId().getTrimmedValue());
			}else{
				cmppdppx.setStartMatchEvtId(CobolCode.SPACES.toString());
			}
			if (notNull(startServiceAgreement)) {
				cmppdppx.setIoWrkStartSaId(startServiceAgreement.getId().getTrimmedValue());
			}else{
				cmppdppx.setIoWrkStartSaId(CobolCode.SPACES.toString());
			}
			
			// invoke the main method
		    cmppdppx.cobolMain();
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
		    //Start Delete - MPang - Defect 3444302- 2016-05-30
		    //ex.printStackTrace();
		    //End Delete - MPang - Defect 3444302- 2016-05-30
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmppdppx.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmppdppx.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmppdppx.getMessageParm(i);
			    			if (notBlank(cmppdppx.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmppdppx.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmppdppx.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmppdppx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmppdppx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}		    		
		    	}
		    	
		    	startServiceAgreement = new ServiceAgreement_Id(cmppdppx.getIoWrkStartSaId().trim()).getEntity();
		    	startBill = new Bill_Id(cmppdppx.getStartBillId().trim()).getEntity();
		    	matchEvent = new MatchEvent_Id(cmppdppx.getMatchEvtId().trim()).getEntity();
		    	shouldDistribute = (cmppdppx.getDistributedSw().compareTo(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE;
		    	startMatchEvent = new MatchEvent_Id(cmppdppx.getStartMatchEvtId().trim()).getEntity();
		    	isDebitOrCredit = LookupHelper.getLookupInstance(DebitCreditFlagLookup.class, cmppdppx.getDbCrFlg().trim()); 
		    	totalAmountDistributed = new Money(BigDecimal.valueOf(cmppdppx.getTotAmtDistributed().doubleValue()), account.getCurrency().getId());
		    	excessCreditAmountPaid = new Money(BigDecimal.valueOf(cmppdppx.getOutputWrkExcessCrPaid().doubleValue()), account.getCurrency().getId());
		    	
		    	int saCount = cmppdppx.getSaCnt().intValue();
		    	
		    	// Start Change AUmali 04/29/2016 Issue 29 JACOB Conversion
		    	//for (int i = 0; i < saCount; i++) {
		    	for (int i = 1; i <= saCount; i++) {
			    // End Change AUmali 04/29/2016 Issue 29 JACOB Conversion		    		
		    		try {
			    		MatchTypePaymentDistributionData data = MatchTypePaymentDistributionData.Factory.newInstance();
			    		
			    		ServiceAgreement sa = new ServiceAgreement_Id(cmppdppx.getSaCollSaId(i)).getEntity();						
			    		data.setServiceAgreement(sa);
				    					    	
			    		Money saCreditAmount = new Money(BigDecimal.valueOf(cmppdppx.getSaCollCreditAmt(i).doubleValue()), account.getCurrency().getId());
			    		data.setCreditAmount(saCreditAmount);

			    		MatchEvent me = new MatchEvent_Id(cmppdppx.getMeId(i)).getEntity();
			    		data.setMatchEvent(me);	
			    		
			    		matchTypePaymentDistributionDatas.add(data);	
		    		
					} catch (IndexOutOfBounds e) {
						addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
					}
		    	}		    	
		    }
		    else {
		        //Start Add - MPang - Defect 3444302- 2016-05-30
		        ex.printStackTrace();
		        //End Add - MPang - Defect 3444302- 2016-05-30
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmppdppx=Session.returnSessionAndCodeToCache(cmppdppx);
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//			//Start Add - MPang - Defect 3444302- 2016-05-30
//            try {
//                connection.close();
//            } catch (SQLException e) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
//            }
//            //End Add - MPang - Defect 3444302- 2016-05-30
         // end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}
	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
		FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
		RequestContext context = session.getRequestContext();
		
		// start update - equint - 2025-11-14 - CCB25.4 Upgrade
  		session.doWork(new ConnectionWork() {
  			
  			@Override
  			public void execute(Connection connection) throws SQLException {
  				try {  
  					String username = connection.getMetaData().getUserName();
  					String url = connection.getMetaData().getURL();
  					
  					CobolSession.setLogSessionStartEnd(false);
  				    cmppdppx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmppdppx.class);
  					
  					cmppdppx.getSession().getDbSession().setUpdateConnection(connection);
  					cmppdppx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
  					
  					// set ZSTAT parameters
  					cmppdppx.setProcessDttmProcessDt(getProcessDateTime().getDate().toString());
  					cmppdppx.setProcessDttmSep("-");
  					cmppdppx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
  					
  					if (session.isOnlineConnection()) { 
  						cmppdppx.setConnectionFlg(CONNECTION_ONLINE);
  					}
  					else {
  						cmppdppx.setConnectionFlg(CONNECTION_BATCH);
  					}
  					
  					cmppdppx.setZstatUserId(context.getUserId());
  					cmppdppx.setLanguageCd(context.getLanguageCode());
  			        
  			        if (context.ignoreWarnings()) {
  			        	cmppdppx.setIgnoreWarningSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmppdppx.setIgnoreWarningSw(SWITCH_NO);
  			        }
  			        
  			        if (session.getBatchInstanceId() != null) {
  			        	cmppdppx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
  			        	
  					} else {
  						cmppdppx.setSchedulerId(new BigDecimal(0).toBigDecimal());
  					}
  			        
  			        cmppdppx.setAppSvcId(context.getSecurityServiceIdContext());
  			        
  			        DatabaseHelper dbHelper = session.getDatabaseHelper();
  			        cmppdppx.setDbMode(dbHelper.getCobolDBMode());
  			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
  			        //cmppdppx.setSplHighValue(cmppdppx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
  			        //cmppdppx.setSplLowValue(cmppdppx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
  			        
  			        cmppdppx.setSplHighValue(cmppdppx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
  			        cmppdppx.setSplLowValue(cmppdppx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
  			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
  			        
  			        cmppdppx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
  			        
  			        cmppdppx.setLkExpiryDt(Date.MAX.toString());
  			        
  			        cmppdppx.setProgramStatus(" ");
  			        
  			        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
  			        cmppdppx.setCallSeq(";");
  			        cmppdppx.setMessageAreaProgramName("CMPPDPPX");
  			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
  			        
  			        if (context.getRandomGeneratorSeedSet().isTrue()) {
  			        	cmppdppx.setRandomGenSeedSw(SWITCH_YES);
  			        	cmppdppx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
  			        	cmppdppx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
  			        	cmppdppx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
  			        	cmppdppx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
  			        }
  			        else {
  			        	cmppdppx.setRandomGenSeedSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceStandardOut()) { 
  			        	cmppdppx.setTrcStdoutSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmppdppx.setTrcStdoutSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramStart()) { 
  			        	cmppdppx.setTrcProgStartSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmppdppx.setTrcProgStartSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramExit()) { 
  			        	cmppdppx.setTrcProgExitSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmppdppx.setTrcProgExitSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceSQL()) { 
  			        	cmppdppx.setTrcExecSqlSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmppdppx.setTrcExecSqlSw(SWITCH_NO);
  			        }
  			        
  			        // Set ZMSGN parms
  			        BigInteger messageSequence = session.getMessageSequence();
  			        if (notNull(messageSequence)) {
  			        	cmppdppx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
  			        }
  			        else {
  			        	cmppdppx.setMessageSeq(new BigDecimal(0).toBigDecimal());
  			        }
  				}
  				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		 
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//        //Start Change - MPang - Defect 3444302- 2016-05-30
//        //Connection connection = implementor.getConnectionProvider().getConnection();
//        connection = implementor.getConnectionProvider().getConnection();
//        //End Change - MPang - Defect 3444302- 2016-05-30		
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmppdppx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmppdppx.class);
//		
//		cmppdppx.getSession().getDbSession().setUpdateConnection(connection);
//		cmppdppx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		
//		// set ZSTAT parameters
//		cmppdppx.setProcessDttmProcessDt(getProcessDateTime().getDate().toString());
//		cmppdppx.setProcessDttmSep("-");
//		cmppdppx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmppdppx.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmppdppx.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmppdppx.setZstatUserId(context.getUserId());
//		cmppdppx.setLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmppdppx.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmppdppx.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmppdppx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmppdppx.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmppdppx.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmppdppx.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmppdppx.setSplHighValue(cmppdppx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmppdppx.setSplLowValue(cmppdppx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmppdppx.setSplHighValue(cmppdppx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmppdppx.setSplLowValue(cmppdppx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmppdppx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmppdppx.setLkExpiryDt(Date.MAX.toString());
//        
//        cmppdppx.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmppdppx.setCallSeq(";");
//        cmppdppx.setMessageAreaProgramName("CMPPDPPX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmppdppx.setRandomGenSeedSw(SWITCH_YES);
//        	cmppdppx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmppdppx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmppdppx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmppdppx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmppdppx.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmppdppx.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmppdppx.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmppdppx.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmppdppx.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmppdppx.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmppdppx.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmppdppx.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmppdppx.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmppdppx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmppdppx.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }
  		
  	// end update - equint - 2025-11-14 - CCB25.4 Upgrade
	}
}