/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPMESRX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      MGE-CCB019. Initial Version.       
 * 2016-04-22   AUmali      Applied fix for Issue 24. Estimation
 * 2016-10-28   SMiran		Defect 3539732 Quote Portal estimation error
 * 							SA-165350. CCB v2.6 Upgrade 12/12/2018
 * 2018-06-07   SFelip      CCB v2.6 Upgrade. CCB v2.6 Upgrade 12/12/2018
 * 2018-09-28   SFelip      Defect 10. Fixed connection closed issue. CCB v2.6 Upgrade 12/12/2018
 * 2019-01-15   EQuint      Defect 4187341. Fixed Connection pool error.
 * 2025-11-14   EQuint      CCB25.4 Upgrade
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.trendArea.algorithm.meterReadEstimation;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.api.lookup.ConsumptionTypeLookup;
import com.splwg.ccb.api.lookup.EstimateAlgorithmLookup;
import com.splwg.ccb.domain.admin.billFactor.entity.BillFactor;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse;
import com.splwg.ccb.domain.admin.trendArea.algorithm.meterReadEstimation.MeterReadEstimationAlgorithmSpot;
import com.splwg.ccb.domain.admin.trendArea.entity.TrendArea;
import com.splwg.ccb.domain.admin.trendClass.entity.TrendClass;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpmesrx;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = minimumDaysBetweenReads, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = daysSufficientforEstimation, required = true, type = integer)
 *            , @AlgorithmSoftParameter (entityName = billFactor, name = degreedDayTolerancePercentBillFactor, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = usageAdjustmentFactorSATypeCharType, required = true, type = entity)})
 */
public class CmThreeStepUsingDegreeDaysEstimationAlgComp_Impl extends
		CmThreeStepUsingDegreeDaysEstimationAlgComp_Gen implements
		MeterReadEstimationAlgorithmSpot {
			
	// hard parameters
	private ConsumptionTypeLookup consumptionTypeLookup;
	private EstimateAlgorithmLookup estimateAlgorithmLookup;
	private BigDecimal estimatedRawUsage;
	private BigDecimal estimatedRegisterReading;
	private Bool isEstimateImpossible;
	private DateTime latestReadDateTime;
	private BigDecimal latestRegisterReading;
	private Bool measuresPeakQuantity;
	private BigInteger numberOfDigitsLeft;
	private BigInteger numberOfDigitsRight;
	private BigInteger numberOfReads;
	private BigDecimal registerConstant;
	private BigDecimal registerReading;
	private TimeOfUse timeOfUse;
	private TrendArea trendArea;
	private TrendClass trendClass;
	private UnitOfMeasure unitOfMeasure;
	private String estimationType;
	private DateTime readDateTime;
	private Register register;
	private ServiceAgreement serviceAgreement;
	private ServicePoint servicePoint;
	
	private Cmpmesrx cmpmesrx;
	private Connection connection;
	
	// soft parameters
	private BigInteger minimumDaysBetweenReads;
	private BigInteger daysSufficientforEstimation;
	private BillFactor degreedDayTolerancePercentBillFactor;
	private CharacteristicType usageAdjustmentFactorSATypeCharType;
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";

	@Override
	public ConsumptionTypeLookup getConsumptionTypeLookup() {
		return consumptionTypeLookup;
	}

	@Override
	public EstimateAlgorithmLookup getEstimateAlgorithm() {
		return estimateAlgorithmLookup;
	}

	@Override
	public BigDecimal getEstimatedRawUsage() {
		return estimatedRawUsage;
	}

	@Override
	public BigDecimal getEstimatedRegisterReading() {
		return estimatedRegisterReading;
	}

	@Override
	public Bool getIsEstimateImpossible() {
		return isEstimateImpossible;
	}

	@Override
	public DateTime getLatestReadDateTime() {
		return latestReadDateTime;
	}

	@Override
	public BigDecimal getLatestRegisterReading() {
		return latestRegisterReading;
	}

	@Override
	public Bool getMeasuresPeakQuantity() {
		return measuresPeakQuantity;
	}

	@Override
	public BigInteger getNumberOfDigitsLeft() {
		return numberOfDigitsLeft;
	}

	@Override
	public BigInteger getNumberOfDigitsRight() {
		return numberOfDigitsRight;
	}

	@Override
	public BigInteger getNumberOfReads() {
		return numberOfReads;
	}

	@Override
	public BigDecimal getRegisterConstant() {
		return registerConstant;
	}

	@Override
	public BigDecimal getRegisterReading() {
		return registerReading;
	}

	@Override
	public TimeOfUse getTimeOfUse() {
		return timeOfUse;
	}

	@Override
	public TrendArea getTrendArea() {
		return trendArea;
	}

	@Override
	public TrendClass getTrendClass() {
		return trendClass;
	}

	@Override
	public UnitOfMeasure getUnitOfMeasure() {
		return unitOfMeasure;
	}

	@Override
	public void setConsumptionType(ConsumptionTypeLookup arg0) {
		consumptionTypeLookup = arg0;
	}

	@Override
	public void setEstimationType(String arg0) {
		estimationType = arg0;
	}

	@Override
	public void setMeasuresPeakQuantity(Bool arg0) {
		measuresPeakQuantity = arg0;
	}

	@Override
	public void setNumberOfDigitsLeft(BigInteger arg0) {
		numberOfDigitsLeft = arg0;
	}

	@Override
	public void setNumberOfDigitsRight(BigInteger arg0) {
		numberOfDigitsRight = arg0;
	}

	@Override
	public void setNumberOfReads(BigInteger arg0) {
		numberOfReads = arg0;
	}

	@Override
	public void setReadDateTime(DateTime arg0) {
		readDateTime = arg0;
	}

	@Override
	public void setRegister(Register arg0) {
		register = arg0;
	}

	@Override
	public void setRegisterConstant(BigDecimal arg0) {
		registerConstant = arg0;
	}

	@Override
	public void setRegisterReading(BigDecimal arg0) {
		registerReading = arg0;
	}

	@Override
	public void setServiceAgreement(ServiceAgreement arg0) {
		serviceAgreement = arg0;
	}

	@Override
	public void setServicePoint(ServicePoint arg0) {
		servicePoint = arg0;
	}

	@Override
	public void setTimeOfUse(TimeOfUse arg0) {
		timeOfUse = arg0;
	}

	@Override
	public void setTrendArea(TrendArea arg0) {
		trendArea = arg0;
	}

	@Override
	public void setTrendClass(TrendClass arg0) {
		trendClass = arg0;
	}

	@Override
	public void setUnitOfMeasure(UnitOfMeasure arg0) {
		unitOfMeasure = arg0;
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		minimumDaysBetweenReads = getMinimumDaysBetweenReads();
		daysSufficientforEstimation = getDaysSufficientforEstimation();
		degreedDayTolerancePercentBillFactor = getDegreedDayTolerancePercentBillFactor();
		usageAdjustmentFactorSATypeCharType = getUsageAdjustmentFactorSATypeCharType();
	}

	@Override
	public void invoke() {

		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters			
			if(notNull(servicePoint)) {
				cmpmesrx.setMedrxInputWrkSpId(servicePoint.getId().getTrimmedValue());
			}else{
				cmpmesrx.setMedrxInputWrkSpId(CobolCode.SPACES.toString());
			}
			
			if(notNull(register)) {
				cmpmesrx.setMedrxInputWrkRegId(register.getId().getTrimmedValue());
			}else{
				cmpmesrx.setMedrxInputWrkRegId(CobolCode.SPACES.toString());
			}
			
			if(notNull(readDateTime)) {
				// Start Change: 2016-04-22 AUmali Issue 24
				//cmpmesrx.setMedrxInputWrkReadDttm(readDateTime.toString()+ ".000000");
				cmpmesrx.setMedrxInputWrkReadDttm(readDateTime.toString());
				// End Change: 2016-04-22 AUmali Issue 24
			}else{
				cmpmesrx.setMedrxInputWrkReadDttm(CobolCode.SPACES.toString());
			}
			
			if(notNull(serviceAgreement)) {
				cmpmesrx.setMedrxInputWrkSaId(serviceAgreement.getId().getTrimmedValue());
			}else{
				cmpmesrx.setMedrxInputWrkSaId(CobolCode.SPACES.toString());
			}
			
			if(notBlank(estimationType)) {
				cmpmesrx.setEstType(estimationType.trim());
			}else{
				cmpmesrx.setEstType(CobolCode.SPACES.toString());
			}
			
			if(notNull(trendArea)) {
				cmpmesrx.setIoTrendAreaClTrendAreaCd(trendArea.getId().getTrimmedValue());
			}else{
				cmpmesrx.setIoTrendAreaClTrendAreaCd(CobolCode.SPACES.toString());
			}
			
			if(notNull(trendClass)) {
				cmpmesrx.setTrendClCd(trendClass.getId().getTrimmedValue());
			}else{
				cmpmesrx.setTrendClCd(CobolCode.SPACES.toString());
			}
			
			if(notNull(numberOfReads)) {
				cmpmesrx.setNbrOfReads(java.math.BigDecimal.valueOf(numberOfReads.longValue()));
			}else{
				cmpmesrx.setNbrOfReads(java.math.BigDecimal.ZERO);
			}
			
			if(notNull(registerReading)) {
				cmpmesrx.setRegReading(registerReading.toBigDecimal());
			}else{
				cmpmesrx.setRegReading(java.math.BigDecimal.ZERO);
			}
			
			if(notNull(unitOfMeasure)) {
				cmpmesrx.setIoRegUomCd(unitOfMeasure.getId().getTrimmedValue());
			}else{
				cmpmesrx.setIoRegUomCd(CobolCode.SPACES.toString());
			}
			
			if(notNull(timeOfUse)) {
				cmpmesrx.setIoRegTouCd(timeOfUse.getId().getTrimmedValue());
			}else{
				cmpmesrx.setIoRegTouCd(CobolCode.SPACES.toString());
			}
			
			if(notNull(registerConstant)) {
				cmpmesrx.setIoRegRegConst(registerConstant.toBigDecimal());
			}else{
				cmpmesrx.setIoRegRegConst(java.math.BigDecimal.ZERO);
			}
			
			if(notNull(consumptionTypeLookup)) {
				cmpmesrx.setIoRegConsumSubFlg(consumptionTypeLookup.trimmedValue());
			}else{
				cmpmesrx.setIoRegConsumSubFlg(CobolCode.SPACES.toString());
			}
			
			if(notNull(numberOfDigitsLeft)) {
				cmpmesrx.setIoRegNbrOfDgtsLft(java.math.BigDecimal.valueOf(numberOfDigitsLeft.longValue()));
			}else{
				cmpmesrx.setIoRegNbrOfDgtsLft(java.math.BigDecimal.ZERO);
			}
			
			if(notNull(numberOfDigitsRight)) {
				cmpmesrx.setIoRegNbrOfDgtsRgt(java.math.BigDecimal.valueOf(numberOfDigitsRight.longValue()));
			}else{
				cmpmesrx.setIoRegNbrOfDgtsRgt(java.math.BigDecimal.ZERO);
			}
			
			cmpmesrx.setMedrxOutputWrkEstImpossibleSw("N");
			cmpmesrx.setMedrxOutputWrkEstRawUsage(java.math.BigDecimal.ZERO);
			cmpmesrx.setMedrxOutputWrkEstRegReading(java.math.BigDecimal.ZERO);
			cmpmesrx.setMedrxOutputWrkLatestReadDttm(CobolCode.SPACES.toString());
			cmpmesrx.setMedrxOutputWrkLatestRegReading(java.math.BigDecimal.ZERO);
			
			// set cobol program's soft parameters
			cmpmesrx.setNbrOfParms(java.math.BigDecimal.valueOf(4));
			cmpmesrx.setAlgParmVal(1, minimumDaysBetweenReads.toString()); 
			cmpmesrx.setAlgParmVal(2, daysSufficientforEstimation.toString()); 
			cmpmesrx.setAlgParmVal(3, degreedDayTolerancePercentBillFactor.getId().getTrimmedValue());
			cmpmesrx.setAlgParmVal(4, usageAdjustmentFactorSATypeCharType.getId().getTrimmedValue()); 
			
			// invoke the main method
		    cmpmesrx.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;		    
		    
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmpmesrx.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmpmesrx.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmpmesrx.getMessageParm(i);
		    				
			    			if (notBlank(cmpmesrx.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmpmesrx.getZmsgnMessageCatNbr().toBigInteger());
		    		
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmpmesrx.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmpmesrx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmpmesrx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    	latestRegisterReading = BigDecimal.valueOf(cmpmesrx.getMedrxOutputWrkLatestRegReading().doubleValue());
		    	
		    	try {		  
		    		// Start Change: 2016-04-22 AUmali Issue 24
					/* latestReadDateTime = DateTime.fromString((cmpmesrx.getMedrxOutputWrkLatestReadDttm()), 
							new DateFormat("yyyy-MM-dd-hh.mm.ss.SSSSSS")); */
		    		if(cmpmesrx.getMedrxOutputWrkLatestReadDttm().matches("([0-9]{4})-([0-9]{2})-([0-9]{2})-([0-9]{2}).([0-9]{2}).([0-9]{2}).([0-9]{6})")){
		    			latestReadDateTime = DateTime.fromString(cmpmesrx.getMedrxOutputWrkLatestReadDttm(), 
		    					new DateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS"));
					} else {
						latestReadDateTime = DateTime.fromString(cmpmesrx.getMedrxOutputWrkLatestReadDttm(), 
		    					new DateFormat("yyyy-MM-dd-HH.mm.ss"));
					}
		    		// End Change: 2016-04-22 AUmali Issue 24
		    		
				} catch (DateFormatParseException e) {
					// CCB v2.6 Upgrade - 2018-07-25 - Start Delete
					// addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
					e.printStackTrace();
					// CCB v2.6 Upgrade - 2018-07-25 - End Delete
				}
		    	// 2016-10-28. SMiran. Defect 3539732. Start Change
		    	isEstimateImpossible = (cmpmesrx.getMedrxOutputWrkEstImpossibleSw().trim().compareTo(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE;
		    	if (isEstimateImpossible.isFalse()){
			    	try {
			    		// Start Change: 2016-04-22 AUmali Issue 24
						/* latestReadDateTime = DateTime.fromString((cmpmesrx.getMedrxOutputWrkLatestReadDttm()), 
								new DateFormat("yyyy-MM-dd-hh.mm.ss.SSSSSS")); */
			    		if(cmpmesrx.getMedrxOutputWrkLatestReadDttm().matches("([0-9]{4})-([0-9]{2})-([0-9]{2})-([0-9]{2}).([0-9]{2}).([0-9]{2}).([0-9]{6})")){
			    			latestReadDateTime = DateTime.fromString(cmpmesrx.getMedrxOutputWrkLatestReadDttm(), 
			    					new DateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS"));
						} else {
							latestReadDateTime = DateTime.fromString(cmpmesrx.getMedrxOutputWrkLatestReadDttm(), 
			    					new DateFormat("yyyy-MM-dd-HH.mm.ss"));
						}
			    		// End Change: 2016-04-22 AUmali Issue 24
			    		
					} catch (DateFormatParseException e) {
						addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
					}
		    	}else{
		    		latestReadDateTime = null;
		    	}
		    	//isEstimateImpossible = (cmpmesrx.getMedrxOutputWrkEstImpossibleSw().trim().compareTo(SWITCH_YES) == 0) ? Bool.TRUE : Bool.FALSE;
		    	// 2016-10-28. SMiran. Defect 3539732. End Change
		    	estimatedRawUsage = BigDecimal.valueOf(cmpmesrx.getMedrxOutputWrkEstRawUsage().doubleValue());
		    	estimatedRegisterReading = BigDecimal.valueOf(cmpmesrx.getMedrxOutputWrkEstRegReading().doubleValue());
		    	estimateAlgorithmLookup = LookupHelper.getLookupInstance(EstimateAlgorithmLookup.class, cmpmesrx.getC1EstAlgFlg().trim());
		    }
		    else {
			    
		    	ex.printStackTrace();
			    
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmpmesrx=Session.returnSessionAndCodeToCache(cmpmesrx);
			
			// Defect 10 - 2018-09-28 - Start Delete
            //try {
            //    connection.close();
            //} catch (SQLException e) {
            //    addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
            //}		
			// Defect 10 - 2018-09-28 - End Delete
			
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//			// start add - EQuint - 2019-01-15 - Defect 4187341
//			FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
//			if (!session.isOnlineConnection()) { 
//				try {
//                    connection.close();
//                } catch (SQLException e) {
//                    addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
//                }		
//			}
//			// End add - EQuint - 2019-01-15 - Defect 4187341
			// end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}

	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
		FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
		RequestContext context = session.getRequestContext();
		 
		// start update - equint - 2025-11-14 - CCB25.4 Upgrade
  		session.doWork(new ConnectionWork() {
  			
  			@Override
  			public void execute(Connection connection) throws SQLException {
  				try { 
  					String username = connection.getMetaData().getUserName();
  					String url = connection.getMetaData().getURL();
  							
  					CobolSession.setLogSessionStartEnd(false);
  					// start change - EQuint - 2019-01-15 - Defect 4187341
  				    // cmpmesrx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpmesrx.class);
  					if (CobolSession.haveSession()) {
  						cmpmesrx = CobolSession.getSessionAndCode(Cmpmesrx.class);
  					}
  					else {
  						cmpmesrx = CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpmesrx.class);
  					}
  					// End change - EQuint - 2019-01-15 - Defect 4187341
  					
  					cmpmesrx.getSession().getDbSession().setUpdateConnection(connection);
  					cmpmesrx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH24:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
  					
  					// set ZSTAT parameters

  					cmpmesrx.setProcessDt(getProcessDateTime().getDate().toString());
  					cmpmesrx.setProcessDttmSep("-");
  					
  					// Start Change: 2016-04-22 AUmali Issue 24		
  					// cmpmesrx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
  					cmpmesrx.setProcessTm(getProcessDateTime().getTime().toString());
  					// End Change: 2016-04-22 AUmali Issue 24
  					
  					if (session.isOnlineConnection()) { 
  						cmpmesrx.setConnectionFlg(CONNECTION_ONLINE);
  					}
  					else {
  						cmpmesrx.setConnectionFlg(CONNECTION_BATCH);
  					}
  					
  					cmpmesrx.setUserId(context.getUserId());
  					cmpmesrx.setZstatLanguageCd(context.getLanguageCode());
  					
  			        if (context.ignoreWarnings()) {
  			        	cmpmesrx.setIgnoreWarningSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpmesrx.setIgnoreWarningSw(SWITCH_NO);
  			        }
  			        
  			        if (session.getBatchInstanceId() != null) {
  			        	cmpmesrx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
  			        	
  					} else {
  						cmpmesrx.setSchedulerId(new BigDecimal(0).toBigDecimal());
  					}
  			        
  			        cmpmesrx.setAppSvcId(context.getSecurityServiceIdContext());
  			        
  			        DatabaseHelper dbHelper = session.getDatabaseHelper();
  			        cmpmesrx.setDbMode(dbHelper.getCobolDBMode());
  			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
  			        //cmpmesrx.setSplHighValue(cmpmesrx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
  			        //cmpmesrx.setSplLowValue(cmpmesrx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
  			        
  			        cmpmesrx.setSplHighValue(cmpmesrx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
  			        cmpmesrx.setSplLowValue(cmpmesrx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
  			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
  			        
  			        cmpmesrx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
  			        
  			        cmpmesrx.setLkExpiryDt(Date.MAX.toString());
  			        
  			        cmpmesrx.setProgramStatus(" ");
  			        
  			        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
  			        cmpmesrx.setCallSeq(";");
  			        cmpmesrx.setMessageAreaProgramName("CMPMERSX");
  			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
  			        
  			        if (context.getRandomGeneratorSeedSet().isTrue()) {
  			        	cmpmesrx.setRandomGenSeedSw(SWITCH_YES);
  			        	cmpmesrx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
  			        	cmpmesrx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
  			        	cmpmesrx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
  			        	cmpmesrx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
  			        }
  			        else {
  			        	cmpmesrx.setRandomGenSeedSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceStandardOut()) { 
  			        	cmpmesrx.setTrcStdoutSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpmesrx.setTrcStdoutSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramStart()) { 
  			        	cmpmesrx.setTrcProgStartSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpmesrx.setTrcProgStartSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramExit()) { 
  			        	cmpmesrx.setTrcProgExitSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpmesrx.setTrcProgExitSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceSQL()) { 
  			        	cmpmesrx.setTrcExecSqlSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpmesrx.setTrcExecSqlSw(SWITCH_NO);
  			        }
  			        
  			        // Set ZMSGN parms
  			        BigInteger messageSequence = session.getMessageSequence();
  			        if (notNull(messageSequence)) {
  			        	cmpmesrx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
  			        }
  			        else {
  			        	cmpmesrx.setMessageSeq(new BigDecimal(0).toBigDecimal());
  			        }      
  				}
  				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//		connection = implementor.getConnectionProvider().getConnection();
//		
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//				
//		CobolSession.setLogSessionStartEnd(false);
//		// start change - EQuint - 2019-01-15 - Defect 4187341
//	    // cmpmesrx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpmesrx.class);
//		if (CobolSession.haveSession()) {
//			cmpmesrx = CobolSession.getSessionAndCode(Cmpmesrx.class);
//		}
//		else {
//			cmpmesrx = CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpmesrx.class);
//		}
//		// End change - EQuint - 2019-01-15 - Defect 4187341
//		
//		cmpmesrx.getSession().getDbSession().setUpdateConnection(connection);
//		cmpmesrx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH24:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		
//		// set ZSTAT parameters
//
//		cmpmesrx.setProcessDt(getProcessDateTime().getDate().toString());
//		cmpmesrx.setProcessDttmSep("-");
//		
//		// Start Change: 2016-04-22 AUmali Issue 24		
//		// cmpmesrx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		cmpmesrx.setProcessTm(getProcessDateTime().getTime().toString());
//		// End Change: 2016-04-22 AUmali Issue 24
//		
//		if (session.isOnlineConnection()) { 
//			cmpmesrx.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmpmesrx.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmpmesrx.setUserId(context.getUserId());
//		cmpmesrx.setZstatLanguageCd(context.getLanguageCode());
//		
//        if (context.ignoreWarnings()) {
//        	cmpmesrx.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmpmesrx.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmpmesrx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmpmesrx.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmpmesrx.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmpmesrx.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmpmesrx.setSplHighValue(cmpmesrx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmpmesrx.setSplLowValue(cmpmesrx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmpmesrx.setSplHighValue(cmpmesrx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmpmesrx.setSplLowValue(cmpmesrx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmpmesrx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmpmesrx.setLkExpiryDt(Date.MAX.toString());
//        
//        cmpmesrx.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmpmesrx.setCallSeq(";");
//        cmpmesrx.setMessageAreaProgramName("CMPMERSX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmpmesrx.setRandomGenSeedSw(SWITCH_YES);
//        	cmpmesrx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmpmesrx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmpmesrx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmpmesrx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmpmesrx.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmpmesrx.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmpmesrx.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmpmesrx.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmpmesrx.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmpmesrx.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmpmesrx.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmpmesrx.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmpmesrx.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmpmesrx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmpmesrx.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }    
  		
  	// end update - equint - 2025-11-14 - CCB25.4 Upgrade
	}
}