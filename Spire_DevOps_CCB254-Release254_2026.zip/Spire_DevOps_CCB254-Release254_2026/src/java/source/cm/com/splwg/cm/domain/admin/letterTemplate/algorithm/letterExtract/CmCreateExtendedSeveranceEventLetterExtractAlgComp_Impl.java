/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPCXSVX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      RI0016. Initial Version.  
 * 2016-05-23   MPang       Defect 3439849. Added close connection to avoid
 *                          UniversalPoolConnectionException.    
 * 2016-09-27   SFelip      Defect 3512842. Add a warning if the 
 *                          ADDRESS-FOUND-SW of Cmpcxccx returns N.  
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.
 * 2021-02-05   NMendo      CCB042. Added Parameter noBaseDateSevProcTmpl. When 
 *                          Severance Process Template is noBaseDateSevProcTmpl
 *                          and sevArsDt is blank, the severance process creation 
 *                          date is passed to the debitDt.
 * 2022-06-22   DLampa      CCB047.5. Updated for MO Severance Process Alignment.
 * 2022-10-24   DLampa      E-06060. Extract the bill format flag depending 
 *                          on the account's CIS Division.
 * 2025-11-14   EQuint      CCB25.4 Upgrade        
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.letterTemplate.algorithm.letterExtract;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.Query;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchRun.BatchRun;
import com.splwg.base.domain.common.algorithm.Algorithm;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.domain.report.reportDefinition.ReportDefinition;
import com.splwg.base.domain.report.reportDefinition.ReportDefinition_Id;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.letterTemplate.algorithm.letterExtract.LetterTemplateLetterExtractAlgorithmSpot;
import com.splwg.ccb.domain.admin.letterTemplate.entity.LetterTemplate;
import com.splwg.ccb.domain.admin.severanceProcessTemplate.entity.SeveranceProcessTemplate;
import com.splwg.ccb.domain.common.fileHelper.FileHelper;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.cm.api.lookup.CmQuotePortalParametersLookup;
import com.splwg.cm.api.lookup.ExternalSystemTypeLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpcxsvx;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = disconnectLetterCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = disconnectLetterCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = impendingDisconnectXNumberOfDays, required = true, type = integer)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = pasaTypeCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = pasaTypeCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = severanceProcessTemplate, name = noBaseDateSevProcTmpl, type = entity)
 *            , @AlgorithmSoftParameter (name = cisDivisionForFormat, required = true, type = string)})
 */
public class CmCreateExtendedSeveranceEventLetterExtractAlgComp_Impl extends
		CmCreateExtendedSeveranceEventLetterExtractAlgComp_Gen implements
		LetterTemplateLetterExtractAlgorithmSpot {

	// hard parameters
	private BigInteger customerContactExtractedCount;
	private ReportDefinition reportDefinition;
	private BatchRun batchRun;
	private CustomerContact customerContact;
	private String extractFileName;
	private FileHelper fileHelper;
	private Bool isFieldDelimited;
	private Bool isFirstHeaderDelimited;
	private Algorithm letterExtractAlgorithm;
	private LetterTemplate letterTemplate;
	private CustomerContact toCustomerContact;
	
	// soft parameters
	private CharacteristicType disconnectLetterCharType;
	private String disconnectLetterCharValue;
	private BigInteger impendingDisconnectXNumberOfDays;
	private CharacteristicType pasaTypeCharType;
	private String pasaTypeCharValue;
	// Start Add - NMendo - 2021-02-05 - CCB042
	private SeveranceProcessTemplate noBaseDateSevProcTmpl;
	// End Add - NMendo - 2021-02-05 - CCB042
    // Start Add - E-06060 - DLampa - 10-24-2022
    private String cisDivisionsForFormat;
    // End Add - E-06060 - DLampa - 10-24-2022	
	
	private Cmpcxsvx cmpcxsvx;
	
	//Start Add - MPang - Defect 3439849 - 2016-05-23
    private Connection connection;
    //End Add - MPang - Defect 3439849 - 2016-05-23
	
    // Start Add - CCB047.5 - DLampa - 06-22-2022
    private String cwrSeasonBeginDate;
    private String cwrSeasonEndDate;        
    // End Add - CCB047.5 - DLampa - 06-22-2022
    // Start Add - E-06060 - DLampa - 10-24-2022
    private ArrayList<CisDivision> wCisDivisionsForFormat = new ArrayList<CisDivision>();
    // End Add - E-06060 - DLampa - 10-24-2022    
    
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	
	// Start Add - CCB047.5 - DLampa - 06-22-2022
	private static final String CC_TYPE_96HR = "96HR";
    private static final String DATE_FORMAT_MMDDYYYY = "MM/dd/yyyy";
    // End Add - CCB047.5 - DLampa - 06-22-2022
	
	@Override
	public BigInteger getCustomerContactExtractedCount() {
		return customerContactExtractedCount;
	}

	@Override
	public ReportDefinition getReportDefinition() {
		return reportDefinition;
	}

	@Override
	public void setBatchRun(BatchRun arg0) {
		batchRun = arg0;
	}

	@Override
	public void setCustomerContact(CustomerContact arg0) {
		customerContact = arg0;
	}

	@Override
	public void setCustomerContactExtractedCount(BigInteger arg0) {
		customerContactExtractedCount = arg0;
	}

	@Override
	public void setExtractFileName(String arg0) {
		extractFileName = arg0;
	}

	@Override
	public void setFileHelper(FileHelper arg0) {
		fileHelper = arg0;
	}

	@Override
	public void setIsFieldDelimited(Bool arg0) {
		isFieldDelimited = arg0;
	}

	@Override
	public void setIsFirstHeaderDelimited(Bool arg0) {
		isFirstHeaderDelimited = arg0;
	}

	@Override
	public void setLetterExtractAlgorithm(Algorithm arg0) {
		letterExtractAlgorithm = arg0;
	}

	@Override
	public void setLetterTemplate(LetterTemplate arg0) {
		letterTemplate = arg0;
	}

	@Override
	public void setToCustomerContact(CustomerContact arg0) {
		toCustomerContact = arg0;
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		disconnectLetterCharType = getDisconnectLetterCharType();
		disconnectLetterCharValue = getDisconnectLetterCharValue();
		impendingDisconnectXNumberOfDays = getImpendingDisconnectXNumberOfDays();
		pasaTypeCharType = getPasaTypeCharType();
		pasaTypeCharValue = getPasaTypeCharValue();
		// Start Add - NMendo - 2021-02-05 - CCB042
		noBaseDateSevProcTmpl = getNoBaseDateSevProcTmpl();
		// End Add - NMendo - 2021-02-05 - CCB042
		
        // Start Add - E-06060 - DLampa - 10-24-2022
        // CIS Divisions for Format
        cisDivisionsForFormat = getCisDivisionForFormat();
        String[] cisDivisions = cisDivisionsForFormat.split(",");

        for (int i=0; i < cisDivisions.length; i++){
            String cisDivStr = cisDivisions[i];
            CisDivision cisDivision = new CisDivision_Id(cisDivStr.trim()).getEntity();
            if (isNull(cisDivision)){
                addError(CustomMessageRepository.E06060_AlgParmContainsInvalidCisDivision(
                        getAlgorithm().getAlgorithmType().getParameterAt(6).fetchLanguageParameterLabel(),
                        cisDivStr));
            }
            wCisDivisionsForFormat.add(cisDivision);
        }
        // End Add - E-06060 - DLampa - 10-24-2022 		
	}

	@Override
	public void invoke() {
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			if(notNull(customerContact)) {
				cmpcxsvx.setInputWrkCcId(customerContact.getId().getTrimmedValue());
			}else{
				cmpcxsvx.setInputWrkCcId(CobolCode.SPACES.toString());
			}
			if(notNull(batchRun)) {
				cmpcxsvx.setInputWrkBatchCd(batchRun.fetchIdBatchControl().getId().getTrimmedValue());
				cmpcxsvx.setInputWrkBatchNbr(java.math.BigDecimal.valueOf(batchRun.fetchIdBatchNumber().doubleValue()));
			}else{
				cmpcxsvx.setInputWrkBatchCd(CobolCode.SPACES.toString());
				cmpcxsvx.setInputWrkBatchNbr(java.math.BigDecimal.ZERO);
			}
			if(notNull(letterTemplate)) {
				cmpcxsvx.setInputWrkLtrTmplCd(letterTemplate.getId().getTrimmedValue());
			}else{
				cmpcxsvx.setInputWrkLtrTmplCd(CobolCode.SPACES.toString());
			}
			if (notNull(letterExtractAlgorithm)) {
				cmpcxsvx.setExtractAlgCd(letterExtractAlgorithm.getId().getTrimmedValue());
			}else{
				cmpcxsvx.setExtractAlgCd(CobolCode.SPACES.toString());
			}
			if(notBlank(extractFileName)) {
				cmpcxsvx.setExtractFileName(extractFileName.trim());
			}else{
				cmpcxsvx.setExtractFileName(CobolCode.SPACES.toString());
			}
			
			if(notNull(isFieldDelimited)) {
				String isFieldDelimitedSw = (isFieldDelimited.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpcxsvx.setFieldDelimSw(isFieldDelimitedSw);
			}else{
				cmpcxsvx.setFieldDelimSw(CobolCode.SPACES.toString());
			}
			if(notNull(isFirstHeaderDelimited)) {
				String isFirstHeaderDelimitedSw = (isFirstHeaderDelimited.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpcxsvx.setDelim_1stHeaderSw(isFirstHeaderDelimitedSw);
			}else{
				cmpcxsvx.setDelim_1stHeaderSw(CobolCode.SPACES.toString());
			}
			if(notNull(toCustomerContact)) {
				cmpcxsvx.setToCcId(toCustomerContact.getId().getTrimmedValue());
			}else{
				cmpcxsvx.setToCcId(CobolCode.SPACES.toString());
			}
			if (notNull(customerContactExtractedCount)) {
				cmpcxsvx.setCcExtractedCnt(java.math.BigDecimal.valueOf(customerContactExtractedCount.doubleValue()));
			}else{
				cmpcxsvx.setCcExtractedCnt(java.math.BigDecimal.ZERO);
			}
			
			// soft parameters
			if (notBlank(disconnectLetterCharType.getId().toString())){
				cmpcxsvx.setAlgParmVal(1, disconnectLetterCharType.getId().getTrimmedValue());	
			} else {
				cmpcxsvx.setAlgParmVal(1, CobolCode.SPACES.toString());
			}
			if (notBlank(disconnectLetterCharValue.trim())){ 
				cmpcxsvx.setAlgParmVal(2, disconnectLetterCharValue.trim());
			} else {
				cmpcxsvx.setAlgParmVal(2, CobolCode.SPACES.toString());
			}
			if (notBlank(impendingDisconnectXNumberOfDays.toString())){
				cmpcxsvx.setAlgParmVal(3, impendingDisconnectXNumberOfDays.toString());
			} else {
				cmpcxsvx.setAlgParmVal(3, CobolCode.SPACES.toString());
			}
			if (notBlank(pasaTypeCharType.getId().getTrimmedValue())){
				cmpcxsvx.setAlgParmVal(4, pasaTypeCharType.getId().getTrimmedValue());
			} else {
				cmpcxsvx.setAlgParmVal(4, CobolCode.SPACES.toString());
			}
			if (notBlank(pasaTypeCharValue.trim())){
				cmpcxsvx.setAlgParmVal(5, pasaTypeCharValue.trim());
			} else {
				cmpcxsvx.setAlgParmVal(5, CobolCode.SPACES.toString());
			}
			// Start Add - NMendo - 2021-02-05 - CCB042
			String ovrdDebitDt = getOverrideDebitDate();
			if (notNull(ovrdDebitDt)){
				cmpcxsvx.setAlgParmVal(6, ovrdDebitDt);
			} else {
				cmpcxsvx.setAlgParmVal(6, CobolCode.SPACES.toString());
			}	
			// End Add - NMendo - 2021-02-05 - CCB042

			// Start Add - CCB047.5 - DLampa - 06-22-2022
			// Extract the CWR Flag for 96HR customer contacts
			if (customerContact.getCustomerContactType().fetchIdContactType().trim().equalsIgnoreCase(CC_TYPE_96HR)) { 
				String cwrFlag = getCwrFlag();
				if (notNull(cwrFlag)){
					cmpcxsvx.setAlgParmVal(7, cwrFlag);
				} else {
					cmpcxsvx.setAlgParmVal(7, CobolCode.SPACES.toString());
				}
			} else {
				cmpcxsvx.setAlgParmVal(7, CobolCode.SPACES.toString());
			}			
			// End Add - CCB047.5 - DLampa - 06-22-2022	
	        // Start Add - E-06060 - DLampa - 10-24-2022
			cmpcxsvx.setAlgParmVal(8, getBillFormatFlag());
	        // End Add - E-06060 - DLampa - 10-24-2022
			
			// invoke the main method
		    cmpcxsvx.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
		    //Start Delete - MPang - Defect 3439849 - 2016-05-23
		    //ex.printStackTrace();
		    //End Delete - MPang - Defect 3439849 - 2016-05-23
		 
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmpcxsvx.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmpcxsvx.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmpcxsvx.getMessageParm(i);
			    			if (notBlank(cmpcxsvx.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmpcxsvx.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmpcxsvx.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmpcxsvx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmpcxsvx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    	customerContactExtractedCount = cmpcxsvx.getCcExtractedCnt().toBigInteger();
		    	reportDefinition = new ReportDefinition_Id(cmpcxsvx.getReportCd().trim()).getEntity();
		    	
		    	// Start Add - SFelip - Defect 3512842 - 2016-09-27
                if(cmpcxsvx.getIgnoreWarningSw().equals(SWITCH_NO)) {
                    if(cmpcxsvx.getOutputWrkAddressFoundSw().equals(SWITCH_NO)) {
                        addWarning(CustomMessageRepository.DEFECT_3512842_addressNotFound(customerContact.getId().getTrimmedValue()));
                    }
                }
                // End Add - SFelip - Defect 3512842 - 2016-09-27
		    	
		    }
		    else {
		        //Start Add - MPang - Defect 3439849 - 2016-05-23
		        ex.printStackTrace();
		        //End Add - MPang - Defect 3439849 - 2016-05-23
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmpcxsvx=Session.returnSessionAndCodeToCache(cmpcxsvx);
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//			//Start Add - MPang - Defect 3439849 - 2016-05-23
//            try {
//                connection.close();
//            } catch (SQLException e) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
//            }
//            //End Add - MPang - Defect 3439849 - 2016-05-23
         // end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}

	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
        FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
	    RequestContext context = session.getRequestContext();
	    
	    // start update - equint - 2025-11-14 - CCB25.4 Upgrade
  		session.doWork(new ConnectionWork() {
  			
  			@Override
  			public void execute(Connection connection) throws SQLException {
  				try {
  					String username = connection.getMetaData().getUserName();
  					String url = connection.getMetaData().getURL();
  					
  					CobolSession.setLogSessionStartEnd(false);
  				    cmpcxsvx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpcxsvx.class);
  					
  					cmpcxsvx.getSession().getDbSession().setUpdateConnection(connection);
  					cmpcxsvx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
  					
  					// set ZSTAT parameters

  					cmpcxsvx.setProcessDt(getProcessDateTime().getDate().toString());
  					cmpcxsvx.setProcessDttmSep("-");
  					cmpcxsvx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
  					
  					if (session.isOnlineConnection()) { 
  						cmpcxsvx.setConnectionFlg(CONNECTION_ONLINE);
  					}
  					else {
  						cmpcxsvx.setConnectionFlg(CONNECTION_BATCH);
  					}
  					
  					cmpcxsvx.setUserId(context.getUserId());
  					cmpcxsvx.setZstatLanguageCd(context.getLanguageCode());
  			        
  			        if (context.ignoreWarnings()) {
  			        	cmpcxsvx.setIgnoreWarningSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpcxsvx.setIgnoreWarningSw(SWITCH_NO);
  			        }
  			        
  			        if (session.getBatchInstanceId() != null) {
  			        	cmpcxsvx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
  			        	
  					} else {
  						cmpcxsvx.setSchedulerId(new BigDecimal(0).toBigDecimal());
  					}
  			        
  			        cmpcxsvx.setAppSvcId(context.getSecurityServiceIdContext());
  			        
  			        DatabaseHelper dbHelper = session.getDatabaseHelper();
  			        cmpcxsvx.setDbMode(dbHelper.getCobolDBMode());
  			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
  			        //cmpcxsvx.setSplHighValue(cmpcxsvx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
  			        //cmpcxsvx.setSplLowValue(cmpcxsvx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
  			        
  			        cmpcxsvx.setSplHighValue(cmpcxsvx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
  			        cmpcxsvx.setSplLowValue(cmpcxsvx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
  			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
  			        
  			        cmpcxsvx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
  			        
  			        cmpcxsvx.setLkExpiryDt(Date.MAX.toString());
  			        
  			        cmpcxsvx.setProgramStatus(" ");
  			        
  			        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
  			        cmpcxsvx.setCallSeq(";");
  			        cmpcxsvx.setMessageAreaProgramName("CMPCXSVX");
  			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
  			        
  			        if (context.getRandomGeneratorSeedSet().isTrue()) {
  			        	cmpcxsvx.setRandomGenSeedSw(SWITCH_YES);
  			        	cmpcxsvx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
  			        	cmpcxsvx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
  			        	cmpcxsvx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
  			        	cmpcxsvx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
  			        }
  			        else {
  			        	cmpcxsvx.setRandomGenSeedSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceStandardOut()) { 
  			        	cmpcxsvx.setTrcStdoutSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpcxsvx.setTrcStdoutSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramStart()) { 
  			        	cmpcxsvx.setTrcProgStartSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpcxsvx.setTrcProgStartSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceProgramExit()) { 
  			        	cmpcxsvx.setTrcProgExitSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpcxsvx.setTrcProgExitSw(SWITCH_NO);
  			        }
  			        
  			        if (context.traceSQL()) { 
  			        	cmpcxsvx.setTrcExecSqlSw(SWITCH_YES);
  			        }
  			        else {
  			        	cmpcxsvx.setTrcExecSqlSw(SWITCH_NO);
  			        }
  			        
  			        // Set ZMSGN parms
  			        BigInteger messageSequence = session.getMessageSequence();
  			        if (notNull(messageSequence)) {
  			        	cmpcxsvx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
  			        }
  			        else {
  			        	cmpcxsvx.setMessageSeq(new BigDecimal(0).toBigDecimal());
  			        }
  				}
  				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		 
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//		//Start Change - MPang - Defect 3439849 - 2016-05-23
//        //Connection connection = implementor.getConnectionProvider().getConnection();
//        connection = implementor.getConnectionProvider().getConnection();
//        //End Change - MPang - Defect 3439849 - 2016-05-23  		
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmpcxsvx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpcxsvx.class);
//		
//		cmpcxsvx.getSession().getDbSession().setUpdateConnection(connection);
//		cmpcxsvx.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		
//		// set ZSTAT parameters
//
//		cmpcxsvx.setProcessDt(getProcessDateTime().getDate().toString());
//		cmpcxsvx.setProcessDttmSep("-");
//		cmpcxsvx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmpcxsvx.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmpcxsvx.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmpcxsvx.setUserId(context.getUserId());
//		cmpcxsvx.setZstatLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmpcxsvx.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxsvx.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmpcxsvx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmpcxsvx.setSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmpcxsvx.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmpcxsvx.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmpcxsvx.setSplHighValue(cmpcxsvx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmpcxsvx.setSplLowValue(cmpcxsvx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmpcxsvx.setSplHighValue(cmpcxsvx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmpcxsvx.setSplLowValue(cmpcxsvx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmpcxsvx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        
//        cmpcxsvx.setLkExpiryDt(Date.MAX.toString());
//        
//        cmpcxsvx.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmpcxsvx.setCallSeq(";");
//        cmpcxsvx.setMessageAreaProgramName("CMPCXSVX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmpcxsvx.setRandomGenSeedSw(SWITCH_YES);
//        	cmpcxsvx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmpcxsvx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmpcxsvx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmpcxsvx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmpcxsvx.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmpcxsvx.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxsvx.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmpcxsvx.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxsvx.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmpcxsvx.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxsvx.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmpcxsvx.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmpcxsvx.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmpcxsvx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmpcxsvx.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }

  	// end update - equint - 2025-11-14 - CCB25.4 Upgrade
  		
	}
	
	// Start Add - NMendo - 2021-02-05 - CCB042
	/**
	 * Retrieve Severance Process Creation Date linked to Customer Contact
	 * where Severance Process Template is equal to Parameter noBaseDateSevProcTmpl
	 * and Severance Process Base Date is null.
	 * @return String
	 */
	private String getOverrideDebitDate() {
		String overrideDebitDate = null;
		
		if(notNull(noBaseDateSevProcTmpl)) {
			StringBuilder stringBuilder = new StringBuilder();
	        stringBuilder.append("SELECT TO_CHAR(SEV.CRE_DTTM,'YYYY-MM-DD') OVRD_DEBIT_DT ");
	        stringBuilder.append("FROM CI_SEV_PROC SEV, CI_SEV_EVT_CC CC ");
	        stringBuilder.append("WHERE SEV.SEV_PROC_ID = CC.SEV_PROC_ID ");
	        stringBuilder.append("AND CC.CC_ID = :ccId ");
	        stringBuilder.append("AND SEV.SEV_PROC_TMPL_CD = :severanceProcessTemplate ");
	        stringBuilder.append("AND SEV.SEV_ARS_DT IS NULL ");

	        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
	        preparedStatement.bindId("ccId", customerContact.getId());
	        preparedStatement.bindId("severanceProcessTemplate", noBaseDateSevProcTmpl.getId());

	        SQLResultRow result = preparedStatement.firstRow();
	        preparedStatement.close();
	        
	        if(notNull(result)) {
	        	overrideDebitDate = result.getString("OVRD_DEBIT_DT");
	        }
		}

        return overrideDebitDate;
    }
	// End Add - NMendo - 2021-02-05 - CCB042

	// Start Add - CCB047.5 - DLampa - 06-22-2022
	/**
	 * Retrieve Severance Process Creation Date linked to Customer Contact
	 * where Severance Process Template is equal to Parameter noBaseDateSevProcTmpl
	 * and Severance Process Base Date is null.
	 * @return String
	 */
	private String getCwrFlag() {
		
		String cwrFlg = SWITCH_NO;
		
        // Quote Portal Parameters Feature Configuration
        FeatureConfiguration quotePortalParmsFeatConfig = retrieveFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_QUOTE_PORTAL_PARAMETERS); 
      
        // Season Begin
        LookupValue seasonStartOptionType = CmQuotePortalParametersLookup.constants.CWR_SEASON_BEGIN.getLookupValue();
        String seasonStartOptionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, seasonStartOptionType);
        cwrSeasonBeginDate = seasonStartOptionValue.trim();
        
        // Season End
        LookupValue seasonEndOptionType = CmQuotePortalParametersLookup.constants.CWR_SEASON_END.getLookupValue();
        String seasonEndOptionValue = retrieveFeatureConfigurationOptionValue(quotePortalParmsFeatConfig, seasonEndOptionType);
        cwrSeasonEndDate = seasonEndOptionValue.trim();
        
        if (checkIfCwrSeason().isTrue()) {
        	cwrFlg = SWITCH_YES;
        }
        
        return cwrFlg;
    }
	
    /**
     * This method will retrieve feature configuration
     * @param lookup ExternalSystemTypeLookup
     * @return featureConfiguration FeatureConfiguration
     */
    private FeatureConfiguration retrieveFeatureConfiguration(ExternalSystemTypeLookup featureType) {
        FeatureConfiguration featureConfiguration = null;

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" FROM FeatureConfiguration fc ");
        stringBuilder.append(" WHERE fc.featureType = :featureType ");

        Query query = createQuery(stringBuilder.toString(), getClass().getName());
        query.bindLookup("featureType", featureType);

        if (query.list().isEmpty()) {
            addError(CustomMessageRepository.CCB047_5_noFeatureConfigurationRetrieved(featureType.getLookupValue().fetchLanguageDescription()));
        }
        else if (query.list().size() > 1) {
            addError(CustomMessageRepository.CCB047_5_multipleFeatureConfigurationRetrieved(featureType.getLookupValue().fetchLanguageDescription()));
        }
        else {
            featureConfiguration = (FeatureConfiguration) query.firstRow();
        }

        return featureConfiguration;
    }
    
    /**
     * This method will retrieve feature configuration option value
     * @param featureConfiguration FeatureConfiguration
     * @param optionType String
     * @return optionValue String
     */
    private String retrieveFeatureConfigurationOptionValue(FeatureConfiguration featureConfiguration, LookupValue lookupValue) {
        String optionValue = "";

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" FROM FeatureConfigurationOption fco ");
        stringBuilder.append(" WHERE fco.id.workforceManagementSystem = :workforceManagementSystem ");
        stringBuilder.append(" AND fco.id.optionType = :optionType ");

        Query query = createQuery(stringBuilder.toString(), getClass().getName());
        
        query.bindEntity("workforceManagementSystem", featureConfiguration);
        query.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, lookupValue.fetchIdFieldValue().trim());   
        query.addResult("value", "fco.value");

        if (query.list().isEmpty()) {
            addError(CustomMessageRepository.CCB047_5_noOptionvalueRetrieved(featureConfiguration.getId().getTrimmedValue(), lookupValue.fetchLanguageDescription()));
        }
        else if (query.list().size() > 1) {
            addError(CustomMessageRepository.CCB047_5_multipleOptionvalueRetrieved(featureConfiguration.getId().getTrimmedValue(), lookupValue.fetchLanguageDescription()));
        }
        else {
            optionValue = (String) query.firstRow();
        }

        return optionValue.trim();
    }  
    
    /**
     * This method will check if the business date is within the CWR season
     * @param serviceAgreement ServiceAgreement
     * @return bool isHeatingSeason
     */
    private Bool checkIfCwrSeason(){
        Bool isInsideOfthePeriod = Bool.FALSE;
        DateFormat dateFormat = new DateFormat(DATE_FORMAT_MMDDYYYY);
        
        int systemYear = this.getSystemDateTime().getYear();
        
        Date currentDate = this.getProcessDateTime().getDate();

        systemYear = this.getProcessDateTime().getYear();
        String cwrSeasonEndStr = cwrSeasonEndDate + "/" + systemYear;
        Date cwrSeasonEndDate = null;
        try {
            cwrSeasonEndDate = Date.fromString(cwrSeasonEndStr, dateFormat);
            if (currentDate.isAfter(cwrSeasonEndDate)) {
                cwrSeasonEndDate = cwrSeasonEndDate.addYears(1);
            }
        }
        catch (Exception e) {}
        
        String cwrSeasonBeginStr = cwrSeasonBeginDate + "/" + cwrSeasonEndDate.getYear();
        Date cwrSeasonBeginDate = null;
        try {
            cwrSeasonBeginDate = Date.fromString(cwrSeasonBeginStr, dateFormat);
            if (cwrSeasonEndDate.isBefore(cwrSeasonBeginDate)) {
                cwrSeasonBeginDate = cwrSeasonBeginDate.addYears(-1);
            }
        }
        catch (Exception e) {}
        if (currentDate.isAfter(cwrSeasonBeginDate) && currentDate.isBefore(cwrSeasonEndDate)) {
        	isInsideOfthePeriod = Bool.TRUE;
        }
        
        return isInsideOfthePeriod;
    }  	
	// End Add - CCB047.5 - DLampa - 06-22-2022

    // Start Add - E-06060 - DLampa - 10-24-2022
    private String getBillFormatFlag() {

        String billFormatFlag = "";        

        if (notNull(customerContact.fetchAccount())) {
            Account acct = customerContact.fetchAccount();
            if (wCisDivisionsForFormat.contains(acct.getDivisionId().getEntity())){          	
                AccountPerson_Id acctPerID = new AccountPerson_Id(customerContact.getPersonId(), acct.getId());
                AccountPerson acctPer = acctPerID.getEntity();

                billFormatFlag = acctPer.getBillFormat().trimmedValue();
            }            
        }
        
        return billFormatFlag;
    }
    // End Add - E-06060 - DLampa - 10-24-2022    
}
