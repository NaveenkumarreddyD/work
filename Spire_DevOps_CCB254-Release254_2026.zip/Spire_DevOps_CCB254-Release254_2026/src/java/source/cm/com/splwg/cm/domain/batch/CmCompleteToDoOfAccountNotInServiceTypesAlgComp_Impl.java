/*
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                     
 * 
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * SA-364029 - TD-NOBC batch enhancement
 * 
 * The post processing algorithm for the TD-NOBC algorithm will have a 
 * parameter to accept a comma delimited list of Service Types that will 
 * be used to filter the list of SAs the account has active. If the
 *  account does not have any active SAs for the service types in the 
 *  parameter, the To do will be automatically closed.
 *
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:       by:          Reason:
 * YYYY-MM-DD  Name
 * 2021-04-28  EQuint       SA 364029. Initial Version.
 ***********************************************************************
 */

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.Query;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Lookup;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.domain.batch.BatchParm;
import com.splwg.base.domain.batch.BatchPostProcessingAlgorithmSpot;
import com.splwg.base.domain.batch.batchControl.BatchControl_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.lookup.LookupField;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType_Id;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author OGC02353
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = serviceTypes, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = saStatus, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = accountIdCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = noOfDays, type = integer)})
 */
public class CmCompleteToDoOfAccountNotInServiceTypesAlgComp_Impl extends
		CmCompleteToDoOfAccountNotInServiceTypesAlgComp_Gen implements
		BatchPostProcessingAlgorithmSpot {
	
	// constants
	private static final String SERVICE_TYPES_DESC = "Service Types";
	private static final String SA_STATUS_DESC = "SA Status";
	private static final String ACCOUNT_CHAR_DESC = "Account ID Characteristic Type";
	private static final String NO_OF_DAYS_DESC = "No Of Days from Processing Date";
	
	// soft parameters
	private ToDoType paramToDoType;
	private String paramServiceTypes;
	private CharacteristicType paramAccountIdCharType;
	private String paramSaStatus;
	private BigInteger paramNoOfDays;
	
	// hard parameters
	private Date batchBusinessDate;
	
	// work variables
	private List<ServiceType_Id> serviceTypes = new ArrayList<ServiceType_Id>();
	private List<Lookup> saStatusValues = new ArrayList<Lookup>();
	private Date toDoCreationDate;

	@Override
	public void setBatchControlId(BatchControl_Id arg0) {
	}

	@Override
	public void setBatchParms(List<BatchParm> arg0) {
	}

	@Override
	public void setBatchRunNumber(BigInteger arg0) {
	}

	@Override
	public void setBusinessDate(Date arg0) {
		batchBusinessDate = arg0;
	}

	@Override
	public void setNumOfThreads(BigInteger arg0) {
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		paramToDoType = getToDoType();
		
		// validate each service types in list
		paramServiceTypes = getServiceTypes();		
		String[] serviceTypesArr = paramServiceTypes.split("\\s*,\\s*");
		for (String serviceType : serviceTypesArr) {
			ServiceType_Id serviceTypeId = new ServiceType_Id(serviceType);
			if (isNull(serviceTypeId.getEntity())) {
				addError(CustomMessageRepository.SA364029_invalidServiceType(SERVICE_TYPES_DESC, paramServiceTypes, serviceType));
			} else {
				serviceTypes.add(serviceTypeId);
			}
		}
		
		// account id char type must be valid for to do entity
		paramAccountIdCharType = getAccountIdCharType();
		CharacteristicEntity charEntity = new CharacteristicEntity_Id(paramAccountIdCharType, CharacteristicEntityLookup.constants.TO_DO_ENTRY).getEntity();
		if (isNull(charEntity)) {
			addError(CustomMessageRepository.SA364029_invalidCharTypeForEntity(ACCOUNT_CHAR_DESC, paramAccountIdCharType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.TO_DO_ENTRY.getLookupValue().fetchLanguageDescription()));
		}
		
		// validate each SA status in the list
		paramSaStatus = getSaStatus();
		String[] saStatusArr = paramSaStatus.split("\\s*,\\s*");
		LookupField saStatusLookupField = ServiceAgreementStatusLookup.constants.ACTIVE.getLookupValue().fetchIdFieldName();
		for (String saStatus : saStatusArr) {
			LookupValue lookupVal = new LookupValue_Id(saStatusLookupField, saStatus).getEntity();
			if (isNull(lookupVal)) {
				addError(CustomMessageRepository.SA364029_invalidServiceType(SA_STATUS_DESC, paramSaStatus, saStatus));
			} else {
				saStatusValues.add(lookupVal.asLookup());
			}
		}
		
		// if no of days is not provided, default to business date / systemdate
		paramNoOfDays = getNoOfDays();
		if (isNull(paramNoOfDays)) {
			toDoCreationDate = (notNull(batchBusinessDate)) ? batchBusinessDate : getSystemDateTime().getDate();
		} else {
			// must be greater than or equal to zero
			if (paramNoOfDays.intValue() < 0) {
				addError(CustomMessageRepository.SA364029_mustBeGreaterThanEqualToZero(NO_OF_DAYS_DESC, paramNoOfDays.toString()));
			} else {
				// derive to do creation date from business date / system date minus the param value
				toDoCreationDate = ((notNull(batchBusinessDate)) ? batchBusinessDate : getSystemDateTime().getDate()).addDays(paramNoOfDays.negate().intValue());
			}
		}
	}
	
	@Override
	public void invoke() {
		Query<ToDoEntry> query = getToDoQuery();
		List<ToDoEntry> toDoEntries = query.list();
		// for reach retrieved to do, complete
		toDoEntries.forEach(toDo -> {
			toDo.complete();
		});
	}
	
	/**
	 * get to dos where 
	 *  - status is open
	 *  - to do type is same as input parameter
	 *  - creation date is business / system date minus no of days parm
	 *  - has existing account that has no SA with matching service types and status
	 * @return query
	 */
	private Query<ToDoEntry> getToDoQuery() {
		String queryString = " FROM ToDoEntry tde "
				+ " WHERE tde.toDoType.id = :toDoTypeId "
				+ " AND tde.toDoEntryStatus = :open "
				+ " AND TRUNC(tde.creationDateTime) >= :creDttm "
				+ " AND NOT EXISTS( SELECT tdec.id FROM ToDoEntryCharacteristic tdec "
					+ " WHERE tdec.id.toDo.id = tde.id "
					+ " AND tdec.id.characteristicType.id = :accountIdCharTypeId "
					+ " AND tdec.id.sequence = (SELECT MAX(tdec2.id.sequence) "
						+ " FROM ToDoEntryCharacteristic tdec2 "
						+ " WHERE tdec2.id.toDo.id = tdec.id.toDo.id "
						+ " AND tdec2.id.characteristicType.id = tdec.id.characteristicType.id ) ";
		
		CharacteristicTypeLookup charType = paramAccountIdCharType.getCharacteristicType();
		if (charType.isForeignKeyValue()) {
			queryString += " AND tdec.characteristicValueForeignKey1 IN ";
		} else if (charType.isPredefinedValue()) {
			queryString += " AND tdec.characteristicValue IN ";
		} else {
			queryString += " AND tdec.adhocCharacteristicValue IN ";
		}
		
		queryString += " (SELECT sa.account.id "
				+ " FROM ServiceAgreement sa "
				+ " WHERE sa.status IN ( ";
		
		for (int i = 0; i < saStatusValues.size(); i++) {
			queryString += ":saStat" + i;
			if (i != saStatusValues.size() - 1) {
				queryString += ", ";
			}
		}
		
		queryString += " ) AND sa.serviceAgreementType.serviceType.id IN ( ";
		
		for (int i = 0; i < serviceTypes.size(); i++) {
			queryString += ":sType" + i;
			if (i != serviceTypes.size() - 1) {
				queryString += ", ";
			}
		}
		
		queryString += " )))";
		
		
		Query<ToDoEntry> query = createQuery(queryString, getClass().getName());
		query.bindId("toDoTypeId", paramToDoType.getId());
		query.bindLookup("open", ToDoEntryStatusLookup.constants.OPEN);
		query.bindDate("creDttm", toDoCreationDate);
		query.bindId("accountIdCharTypeId", paramAccountIdCharType.getId());
		
		for (int i = 0; i < saStatusValues.size(); i++) {
			query.bindLookup("saStat"+i, saStatusValues.get(i));
		}
		
		for (int i = 0; i < serviceTypes.size(); i++) {
			query.bindId("sType"+i, serviceTypes.get(i));
		}
		
		return query;
	}

}
