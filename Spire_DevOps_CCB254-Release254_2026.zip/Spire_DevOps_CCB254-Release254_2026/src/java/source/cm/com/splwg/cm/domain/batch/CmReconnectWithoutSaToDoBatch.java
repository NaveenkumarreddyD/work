/* **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * This custom batch process will Create a To Do when a reconnect is created
 * on an service point with no SA. This process should check the SP linked 
 * to the reconnect FA and see if there is an active SA linked to it. 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:        	 Reason:
 * YYYY-MM-DD   IN         	 Reason text.
 *
 * 2018-10-25   MPang        SA-241626. Initial Version.
 * 2018-11-27   SMiranda     Defect 1. Do not create To Do if the SA's End 
 *                           Date is after the FA's Schedule Date
 * ************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.util.StringTokenizer;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_Id;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_LanguageId;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.security.user.User;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ServerMessage;

/**
 * @author Administrator
 *
@BatchJob (multiThreaded = true, rerunnable = false, modules ={},
 *      softParameters = { @BatchJobSoftParameter (name = FA_TYPES, required = true, type = string)
 *            , @BatchJobSoftParameter (lookupName = fieldActivityStatus, name = COMPLETE_FA_STATUS, required = true, type = lookup)
 *            , @BatchJobSoftParameter (entityName = user, name = INELIGIBLE_USER_ID, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = TO_DO_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = role, name = TO_DO_ROLE, type = entity)
 *            , @BatchJobSoftParameter (name = SA_STATUS, required = true, type = string)
 *            })
 */
public class CmReconnectWithoutSaToDoBatch extends
		CmReconnectWithoutSaToDoBatch_Gen {
	
	// Soft Parameters
	private String parmFaTypes;
	private FieldActivityStatusLookup parmCompleteFaStatus;
	private User parmIneligibleUserId;
	private ToDoType parmToDoType;
	private Role parmToDoRole;
	private String parmSaStatus;
	
	// Constants
	private static final String COMMA_DELIMITER = ",";
	private static final String SINGLE_QUOTE = "'";
	
	// Work Variable
	private String faTypeCds;
	private String saStatuses;
	
	public JobWork getJobWork() {

		PreparedStatement getFas = createPreparedStatement(
				"SELECT FA.SP_ID, FA.FA_TYPE_CD, FA.FA_ID " +
						"FROM CI_FA FA " +
						"WHERE FA.FA_TYPE_CD IN (" +faTypeCds+ ")" +
						"AND FA.FA_STATUS_FLG = :completeFaStatus " +
						"AND FA.USER_ID <> :ineligibleUserId " +
						"AND NOT EXISTS (SELECT 'X' " +
						"                FROM CI_SA_SP SASP, CI_SA SA " +
						"                WHERE SASP.SP_ID = FA.SP_ID " +
						"                AND SASP.SA_ID = SA.SA_ID " +
						"                AND SA.SA_STATUS_FLG IN (" +saStatuses+ ") " +
						"                )" +
						"AND NOT EXISTS (SELECT 'X'	" +
						"                FROM CI_TD_ENTRY TDE, CI_TD_DRLKEY TDD, CI_TD_SRTKEY TDS " +
						"                WHERE TDE.TD_TYPE_CD = :todoTypeCd " +
						"                AND TDE.BATCH_CD = :batchCode " +
						"                AND TDE.TD_ENTRY_ID = TDD.TD_ENTRY_ID " +
						"                AND TRIM(TDD.KEY_VALUE) = TRIM(FA.SP_ID) " +
						"                AND TDE.TD_ENTRY_ID = TDS.TD_ENTRY_ID " +
						"                AND TRIM(TDS.KEY_VALUE) = TRIM(FA.FA_ID) " +
						"                )"
						, getClass().getName());

		getFas.bindLookup("completeFaStatus", parmCompleteFaStatus);
		getFas.bindEntity("ineligibleUserId", parmIneligibleUserId);
		getFas.bindEntity("todoTypeCd", parmToDoType);
		getFas.bindEntity("batchCode", getBatchControlId().getEntity());
		
		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();

		QueryIterator<SQLResultRow> iter = getFas.iterate();
		while (iter.hasNext()) {
			SQLResultRow row = iter.next();

			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId((ServicePoint_Id) row.getId("SP_ID", ServicePoint.class));
			workUnit.addSupplementalData("FA_TYPE_CD", row.getString("FA_TYPE_CD"));
			workUnit.addSupplementalData("FA_ID", row.getString("FA_ID"));
			
			workUnits.add(workUnit);              
		}
		iter.close();
		
		return createJobWorkForThreadWorkUnitList(workUnits);  

	}
	
	
    /**
     * This method Retrieves the Batch Parameter Name
     * @param numSeq
     * @return
     */
    private String getBatchParameterName(int numSeq){

        String parmName = "";
        
        BatchControlParameter_Id batchControlParameter_Id = 
                new BatchControlParameter_Id(this.getBatchControlId(), BigInteger.valueOf(numSeq));        
        BatchControlParameter_LanguageId batchControlParameterLanguageId = 
                new BatchControlParameter_LanguageId(batchControlParameter_Id, getActiveContextLanguage().getId());
        parmName = batchControlParameterLanguageId.getParent().fetchLanguageDescription();
        
        return parmName;
    }

	public Class<CmReconnectWithoutSaToDoBatchWorker> getThreadWorkerClass() {
		return CmReconnectWithoutSaToDoBatchWorker.class;
	}
	
	@Override
	public void validateSoftParameters(boolean isNewRun) {
		
		// Validate Parameter FA Types
		parmFaTypes = getParameters().getFA_TYPES();
		
		String faTypeStr = "";
    	FieldActivityType_Id faTypeId = null;
    	StringBuilder faStrBuilder = new StringBuilder();
		StringTokenizer faTypeStrTokenizer = new StringTokenizer(parmFaTypes, COMMA_DELIMITER);
    	int faTypeCount = faTypeStrTokenizer.countTokens();
    	if(faTypeCount < 1) {
    		addError(CustomMessageRepository.SA241626_parameterNotPopulated(getBatchParameterName(10)));
    	}
    	
    	for(int i = 0; i < faTypeCount; i++) {
    		faTypeStr = faTypeStrTokenizer.nextToken().trim();
    		faTypeId = new FieldActivityType_Id(faTypeStr);
    		if(isNull(faTypeId.getEntity())) {
    			addError(CustomMessageRepository.SA241626_parameterInvalid(getBatchParameterName(10), faTypeStr));
    		} else {
    			faStrBuilder.append(SINGLE_QUOTE);
    			faStrBuilder.append(faTypeStr);
    			faStrBuilder.append(SINGLE_QUOTE);
	            
	            if (faTypeStrTokenizer.hasMoreTokens()) {
	            	faStrBuilder.append(COMMA_DELIMITER);
	            }
	            
    		}
    		
    	}
    	
    	faTypeCds = faStrBuilder.toString();
    	
		// Validate Parameter Complete FA Status
		parmCompleteFaStatus= getParameters().getCOMPLETE_FA_STATUS();
		
		// Validate Parameter Ineligible User Id
		parmIneligibleUserId = getParameters().getINELIGIBLE_USER_ID();
		
		// Validate Parameter To Do Type
		parmToDoType = getParameters().getTO_DO_TYPE();
		
		// Validate Parameter To Do Role
		parmToDoRole = getParameters().getTO_DO_ROLE();
		
		// Checks Parameter To Do Role if valid for Parameter To Do Role
		if(notNull(parmToDoRole)) {
			ToDoTypeRole_Id toDoTypeRoleId = new ToDoTypeRole_Id(parmToDoType, parmToDoRole);
			if(isNull(toDoTypeRoleId.getEntity())) {
				addError(CustomMessageRepository.SA241626_toDoRoleInvalidForToDoType(
						getBatchParameterName(50), parmToDoRole.getId().getIdValue().trim()
						, getBatchParameterName(40), parmToDoType.getId().getIdValue().trim()));
				
			}
		}
		
		// Validate Parameter SA Status
		parmSaStatus = getParameters().getSA_STATUS();
		String saStatusStr = "";
    	ServiceAgreementStatusLookup saStatusLookup;
    	StringBuilder saStrBuilder = new StringBuilder();
    	
		StringTokenizer saStatusStrTokenizer = new StringTokenizer(parmSaStatus, COMMA_DELIMITER);
    	int saStatusCount = saStatusStrTokenizer.countTokens();
    	if(saStatusCount < 1) {
    		addError(CustomMessageRepository.SA241626_parameterNotPopulated(getBatchParameterName(60)));
    	}
    	
    	for(int i = 0; i < saStatusCount; i++) {
    		saStatusStr = saStatusStrTokenizer.nextToken().trim();
    		saStatusLookup = LookupHelper.getLookupInstance(ServiceAgreementStatusLookup.class, saStatusStr);
    		if(!saStatusLookup.isValidLookupValue()) {
    			addError(CustomMessageRepository.SA241626_parameterInvalid(getBatchParameterName(60), saStatusStr));
    		} else {
    			saStrBuilder.append(SINGLE_QUOTE);
    			saStrBuilder.append(saStatusStr);
    			saStrBuilder.append(SINGLE_QUOTE);
	            
	            if (saStatusStrTokenizer.hasMoreTokens()) {
	            	saStrBuilder.append(COMMA_DELIMITER);
	            }
	            
    		}
    	}
    	
    	saStatuses = saStrBuilder.toString();
	}

	public static class CmReconnectWithoutSaToDoBatchWorker extends
			CmReconnectWithoutSaToDoBatchWorker_Gen {
		
		// Soft Parameters
		private String parmFaTypes;
		private FieldActivityStatusLookup parmCompleteFaStatus;
		private User parmIneligibleUserId;
		private ToDoType parmToDoType;
		private Role parmToDoRole;
		private String parmSaStatus;
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

        // 2018-11-27. SMiranda. Defect 1. Start Change
		//public boolean executeWorkUnit(ThreadWorkUnit unit)
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
        // 2018-11-27. SMiranda. Defect 1. End Change			
			ServicePoint_Id servicePoint = (ServicePoint_Id) unit.getPrimaryId();
            String faType = (String) unit.getSupplementallData("FA_TYPE_CD");
            String faId = (String) unit.getSupplementallData("FA_ID");
            // 2018-11-27. SMiranda. Defect 1. Start Change
            FieldActivity_Id faID = new FieldActivity_Id(faId);            
            WorkUnitResult workUnitResult = new WorkUnitResult(true);
            workUnitResult.setUnitsProcessed(0);
            workUnitResult.setUnitsInError(0);
            
            // Get the SP's most recent SA's end date
            PreparedStatement getSpSaEndDt = createPreparedStatement(
    				"SELECT SA.SA_ID, SA.START_DT, SA.END_DT " +
    						"FROM CI_SA_SP SASP, CI_SA SA " +
    						"WHERE SASP.SP_ID = :spId " +
    						"AND SA.SA_ID = SASP.SA_ID " +
    						"ORDER BY SA.START_DT DESC "
    						, "Get SP's most recent SA's end date");

            getSpSaEndDt.bindId("spId", servicePoint);     
            SQLResultRow saRow = getSpSaEndDt.firstRow();
            getSpSaEndDt.close();
            if (notNull(saRow)){
            	Date saEndDate = saRow.getDate("END_DT");
            	// Create a To Do if the SA's end date is before the FA Schedule Date
            	if (notNull(saEndDate) && saEndDate.isBefore(faID.getEntity().getScheduleDateTimeStart().getDate())){
	    			//Create a To Do Entry
	    			addToDoEntry(servicePoint.getEntity(), faType, faId);
	    			//Add 1 to records processed
	    			workUnitResult.setUnitsProcessed(1);
            	}
            }
			//return true;
            return workUnitResult;
            // 2018-11-27. SMiranda. Defect 1. End Change
		}
		
		/**
	     * This method creates a To Do Entry
	     * @param adjustment
	     * @return
	     */
	    private ToDoEntry addToDoEntry(ServicePoint servicePoint, String faType, String faId) {
	        ToDoType toDoType = getParameters().getTO_DO_TYPE();

	        ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
	        ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();

	        toDoEntryDTO.setBatchControlId(getBatchControlId());
	        toDoEntryDTO.setBatchNumber(getBatchNumber());            
	        toDoEntryDTO.setCreationDateTime(getProcessDateTime());
	        
	        ServerMessage msg = CustomMessageRepository.SA241626_spDoesNotHaveActiveSa(servicePoint.getId().getIdValue().trim());
	        MessageCategory_Id msgCatId = new MessageCategory_Id(msg.getCategory());
	        Message_Id messageId = new Message_Id(msgCatId, msg.getNumber());
	        toDoEntryDTO.setMessageId(messageId);     
	        for(Iterator iter = msg.getMessageParameters().iterator(); iter.hasNext();){
	        	toDoCreator.addMessageParameter(iter.next().toString());
	        }
	        
	        toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
	        toDoEntryDTO.setToDoTypeId(toDoType.getId());
	        
	        if(notNull(parmToDoRole)) {
	        	toDoEntryDTO.setToDoRoleId(parmToDoRole.getId());
	        }
	        
	        toDoCreator.setToDoDTO(toDoEntryDTO);    
	        
	        //Add drill key
	        Iterator<ToDoDrillKeyType> drillKeyIterator = parmToDoType.getId().getEntity().getDrillKeyTypes().iterator();
	        toDoCreator.addDrillKeyValue(drillKeyIterator.next(), servicePoint.getId().getIdValue().trim());
	        //Add sort key
	        Iterator<ToDoSortKeyType> sortKeyIterator = parmToDoType.getId().getEntity().getSortKeyTypes().iterator();
	        toDoCreator.addSortKeyValue(sortKeyIterator.next(), servicePoint.getId().getIdValue().trim());
	        toDoCreator.addSortKeyValue(sortKeyIterator.next(), faType.trim());
	        toDoCreator.addSortKeyValue(sortKeyIterator.next(), faId.trim());
	        
	        return toDoCreator.create();
	    }

		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
						throws ThreadAbortedException, RunAbortedException {
			parmFaTypes = getParameters().getFA_TYPES();
			parmCompleteFaStatus = getParameters().getCOMPLETE_FA_STATUS();
			parmIneligibleUserId = getParameters().getINELIGIBLE_USER_ID();
			parmToDoType = getParameters().getTO_DO_TYPE();
			parmToDoRole = getParameters().getTO_DO_ROLE();
			parmSaStatus = getParameters().getSA_STATUS();
		}
	}

}
