/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Pledge Payment Reconciliation Batch
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-04-23   Arun            NI0026.7 Initial Version.
 * 2016-01-25   MPang			Updated for CCB v2.4 compilation.
 ******************************************************************************************/

package com.splwg.cm.domain.admin.customerClass;

import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Lookup;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.currency.Currency_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
//Start Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.customerClass.CustomerClassFtFreezeAlgorithmSpot;
import com.splwg.ccb.domain.admin.tenderSource.TenderSource;
import com.splwg.ccb.domain.admin.tenderSource.TenderSource_Id;
import com.splwg.ccb.domain.financial.financialTransaction.FinancialTransaction;
import com.splwg.ccb.domain.financial.financialTransaction.FinancialTransaction_DTO;*/

import com.splwg.ccb.domain.admin.customerClass.algorithm.ftFreeze.CustomerClassFtFreezeAlgorithmSpot;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource_Id;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction_DTO;
//End Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;

/**
 * @author adevaraj001
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (lookupName = schemaConstantOption, name = ELIG_PLEDGE_TNDR_SRC_OPT_TYPE, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = PLEDGE_PAY_CHAR_TYPE, required = true, type = entity)})
 */

public class CmPledgePaymentFTFreeze_Impl 
		extends CmPledgePaymentFTFreeze_Gen
		implements CustomerClassFtFreezeAlgorithmSpot {

    private FinancialTransaction financialTransaction;
    private CharacteristicType pledgeCharType;
    private FeatureConfiguration featureConfiguration;
    private Lookup eligPledgeTndrSrc;
    private TenderSource tenderSource;
    private Money paySegmentAmount;
    private Boolean isvalidTenderSource;
    private FinancialTransactionTypeLookup ftTypeLookup;

    //Class Variable
    private List<TenderSource_Id> tndrSrcIdList;

    public Bool getFinancialTransactionProcessAdded() {
        return Bool.TRUE;
    }

    public void setFinancialTransaction(FinancialTransaction arg0) {
        this.financialTransaction = arg0;
    }

    public void setFinancialTransactionType(FinancialTransactionTypeLookup arg0) {
        this.ftTypeLookup = arg0;

    }

    public void setRegularFinancialTransaction(FinancialTransaction arg0) {
    }

    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

        featureConfiguration = new FeatureConfiguration_Id("SCHEMACONST").getEntity();
        if(isNull(featureConfiguration)){
            addError(CustomMessageRepository.ni0026_7SchemaConstantFeatureConfigurationDoesNotExists("SCHEMACONST"));
        }
        pledgeCharType = getPLEDGE_PAY_CHAR_TYPE();
        eligPledgeTndrSrc = getELIG_PLEDGE_TNDR_SRC_OPT_TYPE();
        validateFCOption();

    }

    private void validateFCOption(){
        boolean isExists = false;
        for( FeatureConfigurationOption featureConfigurationOption : featureConfiguration.getOptions()){
            if(eligPledgeTndrSrc.trimmedValue().equals(featureConfigurationOption.fetchIdOptionType().trim())){
                CmFeatureConfigurationRetriever cmFeatureConfigurationRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
                cmFeatureConfigurationRetriever.setParmWFMName(featureConfiguration);
                cmFeatureConfigurationRetriever.setParmOptType(eligPledgeTndrSrc.trimmedValue());
                List<String> tenderSourceList = cmFeatureConfigurationRetriever.getListOfOptionValues();
                if(tenderSourceList.size() == 0){
                    addError(CustomMessageRepository.ni0026_7TenderSourceNotConfiguredOnFeatConf(featureConfiguration.getId().getTrimmedValue()));
                }
                validateAndGetTenderSource(tenderSourceList);
                isExists = true;
            }
        } 
        if(!isExists){
            addError(CustomMessageRepository.ni0026_7TenderSourceOptionTypeNotConfigured(featureConfiguration.getId().getTrimmedValue()));
        }
    }

    private void validateAndGetTenderSource(List<String> tndrSrcList){
        TenderSource_Id tndrSrcId = null;
        tndrSrcIdList = new ArrayList<TenderSource_Id>();
        for(String strtndrSource : tndrSrcList ){
            tndrSrcId =  new  TenderSource_Id(strtndrSource);
            if(isNull(tndrSrcId.getEntity())){
                addError(CustomMessageRepository.ni0026_7InvalidTenderSourceOnFeatConf(strtndrSource,featureConfiguration.getId().getTrimmedValue()));
            }
            tndrSrcIdList.add(tndrSrcId)   ;              
        }
    }

    public void invoke() {
        if(ftTypeLookup.isPaySegment() || ftTypeLookup.isPayCancellation()){
            isvalidTenderSource = false;
            retreiveTenderSource();
            FinancialTransaction_DTO ftDto = financialTransaction.getDTO();
            for (TenderSource_Id tndrSrcId : tndrSrcIdList) {
                if(tenderSource.getId().equals(tndrSrcId)){
                    isvalidTenderSource = true;
                    break;
                }
            }
            if(isvalidTenderSource){
                ftDto.setCurrentAmount(new Money("1", new Currency_Id("USD")));
                if(!(financialTransaction.getPayoffAmount().equals(paySegmentAmount.negate()))){
                    ftDto.setPayoffAmount(paySegmentAmount.negate());
                }
            }else{

                if(!(financialTransaction.getCurrentAmount().equals(paySegmentAmount.negate()))){
                    ftDto.setCurrentAmount(paySegmentAmount.negate());
                }
                if(!(financialTransaction.getPayoffAmount().equals(paySegmentAmount.negate()))){
                    ftDto.setPayoffAmount(paySegmentAmount.negate());
                }
            }
            financialTransaction.setDTO(ftDto);
        }
    }

    private void retreiveTenderSource() {
        StringBuilder getTenderSource = new StringBuilder();
        getTenderSource.append("SELECT  DISTINCT  PS.PAY_SEG_AMT, TC.TNDR_SOURCE_CD ");
        getTenderSource.append("FROM CI_FT FT, CI_PAY P, CI_PAY_SEG PS, CI_PAY_TNDR PT,  CI_TNDR_CTL TC ");
        getTenderSource.append("WHERE FT.FT_ID = :ftId ");
        getTenderSource.append("AND P.PAY_ID = PS.PAY_ID ");
        getTenderSource.append("AND PS.PAY_SEG_ID = FT.SIBLING_ID ");
        getTenderSource.append("AND P.PAY_EVENT_ID = PT.PAY_EVENT_ID ");
        getTenderSource.append("AND PT.TNDR_CTL_ID = TC.TNDR_CTL_ID ");
        getTenderSource.append("AND EXISTS (SELECT 'X' FROM CI_PAY_CHAR PC WHERE PC.CHAR_TYPE_CD = :charTypeCd ");
        getTenderSource.append("AND PC.PAY_ID = P.PAY_ID) ");
        //Start Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
        //PreparedStatement pstmt = createPreparedStatement(getTenderSource.toString());
        PreparedStatement pstmt = createPreparedStatement(getTenderSource.toString(), getClass().getName());
        //End Change - 2016-01-25 - MPang - Updated for Updated for CCB v2.4 compilation
        pstmt.bindId("ftId", financialTransaction.getId());
        pstmt.bindId("charTypeCd", pledgeCharType.getId());
        SQLResultRow getTndrSrcRow = pstmt.firstRow();

        if(isNull(getTndrSrcRow)){
            addError(CustomMessageRepository.ni0026_7TenderSourceNotFound());
        }
        tenderSource = getTndrSrcRow.getEntity("TNDR_SOURCE_CD", TenderSource.class);
        paySegmentAmount = getTndrSrcRow.getMoney("PAY_SEG_AMT");
    }
}
