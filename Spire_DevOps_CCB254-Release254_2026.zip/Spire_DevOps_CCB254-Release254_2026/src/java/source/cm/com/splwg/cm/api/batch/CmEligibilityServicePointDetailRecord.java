/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Record Layout for Custom Eligibility Service Point Detail Record
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-04-24   RDizon  NI0026.1 Initial Version.
 **************************************************************************/

package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmEligibilityServicePointDetailRecord
extends ColumnDelimitedRecord {

    public CmEligibilityServicePointDetailRecord() {
        super(8);
    }

    public void setServicePointId(String servicePointId) {
        String string = "<ServicePointID>" + servicePointId + "</ServicePointID>" + "\n";
        this.rightPadColumn(1, string.length(), string);
    }
    
    public void setServicePointStatus(String servicePointStatus) {
        String string = "<ServicePointStatus>" + servicePointStatus + "</ServicePointStatus>" + "\n";
        this.rightPadColumn(2, string.length(), string);
    }

    public void setServicePointStatusDescription(String servicePointStatusDescription) {
        String string = "<ServicePointStatusDescr>" + servicePointStatusDescription + "</ServicePointStatusDescr>" + "\n";
        this.rightPadColumn(3, string.length(), string);
    }
    
    public void setServicePointSourceStatus(String servicePointSourceStatus) {
        String string = "<ServicePointSourceStatus>" + servicePointSourceStatus + "</ServicePointSourceStatus>" + "\n";
        this.rightPadColumn(4, string.length(), string);
    }
    
    public void setLatestTONNDate(String latestTONNDate) {
        String string = "<LatestTONNDate>" + latestTONNDate + "</LatestTONNDate>" + "\n";
        this.rightPadColumn(5, string.length(), string);
    }
    
    public void setLatestTOFFDate(String latestTOFFDate) {
        String string = "<LatestTOFFDate>" + latestTOFFDate + "</LatestTOFFDate>" + "\n";
        this.rightPadColumn(6, string.length(), string);
    }
    
    public void setMeterStatus(String meterStatus) {
        String string = "<MeterStatus>" + meterStatus + "</MeterStatus>" + "\n";
        this.rightPadColumn(7, string.length(), string);
    }
    
    public void setMeterInstallStatus(String meterInstallStatus) {
        String string = "<MeterInstallStatus>" + meterInstallStatus + "</MeterInstallStatus>" + "\n";
        this.rightPadColumn(8, string.length(), string);
    }
}
