/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Column Delimited Record class for File Trailer
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-05-27   RDizon  CCB041. Initial version.        
 **************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

/**
 * @author RDizon
 */
public class CmCheckExtractFileTrailerRecord extends ColumnDelimitedRecord {
    
    private static final String DELIMITER = "|";
        
    public CmCheckExtractFileTrailerRecord() {
        super(5);
    }
    
    public void setTRVald(String value) {
        this.leftPadColumn(1, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setFileGenerationDate(String value) {
        this.leftPadColumn(2, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setFileGenerationTimestamp(String value) {
        this.leftPadColumn(3, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setNumberOfLines(String value) {
        this.leftPadColumn(4, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setSequence(String value) {
        this.leftPadColumn(5, value.length() + 1, value.trim());
    }
}
