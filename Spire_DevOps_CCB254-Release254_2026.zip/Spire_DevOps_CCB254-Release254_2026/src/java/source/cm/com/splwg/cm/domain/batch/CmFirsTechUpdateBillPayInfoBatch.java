/*
 ***************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * FirsTech All User File Upload (Customer Data Upload) 
 * 
 * This custom Batch Process will read the inbound All User file and load 
 * the data into a custom table. This table will have the same layout as 
 * the All User file's detail records and will be emptied of all data prior 
 * to loading the file.
 *            
 ****************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2019-12-04   JLumbre SpireOne. CCB-107. Initial Version.
 * 2020-03-23   JVitug  OMNI.1 - Updated to change Bill Format based on
 *                      E-Bill Enrollment characteristic.
 * 2020-05-13   JLumbre SpireOne. Updated main query, added criteria.                     
 *  
 ****************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPersons;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.cm.api.lookup.BillFormatLookup;
import com.splwg.cm.api.lookup.CmAllUserProcessingLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;

/**
 * @author TMG02631
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules={},
 *      softParameters = { @BatchJobSoftParameter (entityName = characteristicType, name = BILL_PAY_VENDOR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = EBILL_VENDOR_FEATURE_CONFIG, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = MAX_UPDATES, required = true, type = integer)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)})
 */
public class CmFirsTechUpdateBillPayInfoBatch extends
    CmFirsTechUpdateBillPayInfoBatch_Gen {

	private BigInteger parmMaxUpdates;
	private BigInteger parmMaxErrors;
	private CharacteristicType parmBillPayVendorCharType;

	public JobWork getJobWork() {

		StringBuilder getDataToProcess = new StringBuilder();
		getDataToProcess.append("SELECT AC.ACCT_ID, (AC.ADHOC_CHAR_VAL || AC.CHAR_VAL || AC.CHAR_VAL_FK1) AS CCB_BILL_PAY_VENDOR, FTC.CM_BILL_PAY_VNDR AS FT_BILL_PAY_VENDOR, 'DIFF' AS FLG ");
		getDataToProcess.append("FROM CI_ACCT_CHAR AC, CM_FIRSTECH_CUST_IN FTC ");
		getDataToProcess.append("WHERE AC.CHAR_TYPE_CD=:charType ");
		getDataToProcess.append("AND AC.EFFDT = (SELECT MAX(AC1.EFFDT) ");
		getDataToProcess.append("FROM CI_ACCT_CHAR AC1 ");
		getDataToProcess.append("WHERE AC1.ACCT_ID=AC.ACCT_ID ");
		getDataToProcess.append("AND AC1.CHAR_TYPE_CD=AC.CHAR_TYPE_CD ");
		getDataToProcess.append("AND AC1.EFFDT <=:processDate ) ");
		getDataToProcess.append("AND AC.ACCT_ID=FTC.ACCT_ID ");
		//Start Change JVitug - OMNI.1 - 2020-03-23
		//getDataToProcess.append("AND TRIM(AC.ADHOC_CHAR_VAL) <> TRIM(FTC.CM_BILL_PAY_VNDR) ");
		getDataToProcess.append("AND TRIM(AC.ADHOC_CHAR_VAL || AC.CHAR_VAL || AC.CHAR_VAL_FK1) <> TRIM(FTC.CM_BILL_PAY_VNDR) ");
		//End Change JVitug - OMNI.1 - 2020-03-23
		getDataToProcess.append("UNION ALL ");
		getDataToProcess.append("SELECT AC.ACCT_ID,AC.ADHOC_CHAR_VAL AS CCB_BILL_PAY_VENDOR, null AS FT_BILL_PAY_VENDOR, 'IN_CCB' AS FLG ");
		getDataToProcess.append("FROM CI_ACCT_CHAR AC ");
		getDataToProcess.append("WHERE AC.CHAR_TYPE_CD=:charType ");
		//Start Add JLumbre - 2020-05-13
		getDataToProcess.append("AND (AC.ADHOC_CHAR_VAL='Y' OR AC.CHAR_VAL='Y' OR AC.CHAR_VAL_FK1='Y') ");
		//End Add JLumbre - 2020-05-13
		getDataToProcess.append("AND AC.EFFDT = (SELECT MAX(AC1.EFFDT) FROM CI_ACCT_CHAR AC1 ");
		getDataToProcess.append("WHERE AC1.ACCT_ID=AC.ACCT_ID ");
		getDataToProcess.append("AND AC1.CHAR_TYPE_CD=AC.CHAR_TYPE_CD ");
		getDataToProcess.append("AND AC1.EFFDT <=:processDate) ");
		getDataToProcess.append("AND NOT EXISTS (SELECT 'X' FROM CM_FIRSTECH_CUST_IN FT ");
		getDataToProcess.append("WHERE FT.ACCT_ID=AC.ACCT_ID) ");
		getDataToProcess.append("UNION ALL ");
		getDataToProcess.append("SELECT FT1.ACCT_ID, null AS CCB_BILL_PAY_VENDOR, TRIM(FT1.CM_BILL_PAY_VNDR) AS FT_BILL_PAY_VENDOR, 'NOT_IN_CCB' AS FLG ");
		getDataToProcess.append("FROM CM_FIRSTECH_CUST_IN FT1 ");
		getDataToProcess.append("WHERE NOT EXISTS (SELECT 'X' FROM CI_ACCT_CHAR AC2 ");
		getDataToProcess.append("WHERE AC2.ACCT_ID=FT1.ACCT_ID ");
		getDataToProcess.append("AND AC2.CHAR_TYPE_CD=:charType ");
		getDataToProcess.append("AND AC2.EFFDT = (SELECT MAX(AC3.EFFDT) FROM CI_ACCT_CHAR AC3 ");
		getDataToProcess.append("WHERE AC3.ACCT_ID=AC2.ACCT_ID ");
		getDataToProcess.append("AND AC3.CHAR_TYPE_CD=AC2.CHAR_TYPE_CD ");	
		getDataToProcess.append("AND AC3.EFFDT <=:processDate )) ");

		PreparedStatement getDataToProcessSql = createPreparedStatement(getDataToProcess.toString(), "checkMaxUpdates");
		getDataToProcessSql.bindEntity("charType", parmBillPayVendorCharType);
		getDataToProcessSql.bindDate("processDate", getProcessDateTime().getDate());

		//Start Add - JLumbre - 2020-05-13
		getDataToProcessSql.setAutoclose(false);
		getDataToProcessSql.execute();		
		//End Add - JLumbre - 2020-05-13
		Integer recCount = getDataToProcessSql.list().size();		
		BigInteger rCount = BigInteger.valueOf(recCount.longValue()); 

		if (rCount.compareTo(parmMaxUpdates) > 0){
			addError(CustomMessageRepositorySpireOne.S1_numOfChangesExceeds(rCount, parmMaxUpdates));
		}

		// Build Worklist
		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();

		QueryIterator<SQLResultRow> iter = getDataToProcessSql.iterate();

		while (iter.hasNext()) {
			SQLResultRow row = iter.next();

			ThreadWorkUnit workUnit = new ThreadWorkUnit();
			workUnit.setPrimaryId((Account_Id) row.getId("ACCT_ID", Account.class));
			workUnit.addSupplementalData("CCB_BILL_PAY_VENDOR", row.getString("CCB_BILL_PAY_VENDOR"));
			workUnit.addSupplementalData("FT_BILL_PAY_VENDOR", row.getString("FT_BILL_PAY_VENDOR"));  
			workUnit.addSupplementalData("FLG", row.getString("FLG"));

			workUnits.add(workUnit);              
		}
		iter.close();  
		getDataToProcessSql.close();

		return createJobWorkForThreadWorkUnitList(workUnits);	
	}


	public Class<CmFirsTechUpdateBillPayInfoBatchWorker> getThreadWorkerClass() {
		return CmFirsTechUpdateBillPayInfoBatchWorker.class;
	}

	@Override
	public void validateSoftParameters(boolean isNewRun) {

		parmMaxErrors = getParameters().getMAX_ERRORS();
		parmMaxUpdates = getParameters().getMAX_UPDATES();	
		parmBillPayVendorCharType = getParameters().getBILL_PAY_VENDOR_CHAR_TYPE();

		if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0){
			addError(CustomMessageRepositorySpireOne.S1_MaxErrorCannotBeLessThanZero(parmMaxErrors.toString()));
		}

		if (parmMaxUpdates.compareTo(BigInteger.ZERO) < 0){
			addError(CustomMessageRepositorySpireOne.S1_MaxUpdatesCannotBeLessThanZero(parmMaxUpdates.toString()));
		}			
	}

	public static class CmFirsTechUpdateBillPayInfoBatchWorker extends
	CmFirsTechUpdateBillPayInfoBatchWorker_Gen {
	  
		private BigInteger maxErrors;
		private CharacteristicType billPayVendorCharType;
		//Start Add JVitug - OMNI.1 - 2020-03-23
		private FeatureConfiguration thirdPartyEBillFeatConfig;
		//End Add JVitug - OMNI.1 - 2020-03-23

		//counters
		private int bpAdded = 0;
		private int bpUpdated = 0;
		private int bpRemoved = 0;
		//private int errorCount = 0;

		//Constants
		//private static String NA = "NA"; 
		private static String IN_CCB = "IN_CCB";
		private static String DIFF = "DIFF";
		private static String NOT_IN_CCB = "NOT_IN_CCB";
		//Start Add JVitug - OMNI.1 - 2020-03-23
		private static String EBILLENR = "EBILLENR";
		private static  String EBILLENR_NO = "N";
		//End Add JVitug - OMNI.1 - 2020-03-23

		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			maxErrors = getParameters().getMAX_ERRORS();
			billPayVendorCharType = getParameters().getBILL_PAY_VENDOR_CHAR_TYPE();
			thirdPartyEBillFeatConfig = getParameters().getEBILL_VENDOR_FEATURE_CONFIG();

			Account_Id acctId = (Account_Id) unit.getPrimaryId();
			String CCB_BILL_PAY_VENDOR = (String) unit.getSupplementallData("CCB_BILL_PAY_VENDOR");
			String FT_BILL_PAY_VENDOR = (String) unit.getSupplementallData("FT_BILL_PAY_VENDOR");
			String ccbFlag = (String) unit.getSupplementallData("FLG");
		
			//Start Change JVitug - OMNI.1 - 2020-03-23
			//if (!isBlankOrNull(CCB_BILL_PAY_VENDOR) && CCB_BILL_PAY_VENDOR.compareTo(NA) != 0){		
			if (!isBlankOrNull(CCB_BILL_PAY_VENDOR) && CCB_BILL_PAY_VENDOR.compareTo(EBILLENR_NO) != 0){           
			//End Change JVitug - OMNI.1 - 2020-03-23
				//Process records with bill pay vendor characteristic 
				if (ccbFlag.compareTo(IN_CCB) == 0){
				    
				    //Start Change JVitug - OMNI.1 - 2020-03-23
					//addBillPayChar(acctId.getEntity(), NA); 
					addBillPayChar(acctId.getEntity(), EBILLENR_NO);
					//End Change JVitug - OMNI.1 - 2020-03-23
					bpRemoved++;
					
					//Start Add JVitug - OMNI.1 - 2020-03-23
					//Check to see if the Account's Bill Format is XE
					ListFilter<AccountPersons> mainPersonFilter = acctId.getEntity().getPersons().createFilter("WHERE this.isMainCustomer = :true", "getMainPerson");
					mainPersonFilter.bindBoolean("true" , Bool.TRUE);
					
					if(mainPersonFilter.listSize() != 0 ){
						AccountPerson mainPerson = (AccountPerson)mainPersonFilter.firstRow();
						
						BillFormatLookup xe = BillFormatLookup.constants.EBILL; 
						
						//If account's Bill Format is EBILL
						if(mainPerson.getBillFormat().compareTo(xe) == 0) {
						    CharacteristicType_Id charTypeId = new CharacteristicType_Id(EBILLENR);
						
							if(notNull(charTypeId.getEntity())){
							    
							    CharacteristicType ebillenr = charTypeId.getEntity();
	                            
								//Check the effective characteristic value for account characteristic type EBILLENR  
								AccountCharacteristic ebillenrCharVal = acctId.getEntity().getEffectiveCharacteristic(ebillenr);
								
								if(notNull(ebillenrCharVal)) {
									//If it exists, and the value is N, then change the Bill format to D
									if(ebillenrCharVal.getSearchCharacteristicValue().trim().compareToIgnoreCase(EBILLENR_NO) == 0){
										AccountPerson_DTO mainPersonDTO = mainPerson.getDTO();
										
										mainPersonDTO.setBillFormat(BillFormatLookup.constants.DETAILED);										
										mainPerson.setDTO(mainPersonDTO);
									}
								} else {
									//If it does not exist, then change the Bill Format to D
									AccountPerson_DTO mainPersonDTO = mainPerson.getDTO();
									
									mainPersonDTO.setBillFormat(BillFormatLookup.constants.DETAILED);
									mainPerson.setDTO(mainPersonDTO);
								}
							}
						}
					}
					//End Add JVitug - OMNI.1 - 2020-03-23
				}
				else if (ccbFlag.compareTo(DIFF) == 0){
				    
				    //Start Add JVitug - OMNI.1 - 2020-03-23
				    if(isBlankOrNull(FT_BILL_PAY_VENDOR)){
				        FT_BILL_PAY_VENDOR = EBILLENR_NO;
				    }
				    //End Add JVitug - OMNI.1 - 2020-03-23

					addBillPayChar(acctId.getEntity(), FT_BILL_PAY_VENDOR);
					bpUpdated++;
					
					//Start Add JVitug - OMNI.1 - 2020-03-23
					updateBillFormat(acctId, FT_BILL_PAY_VENDOR);
					//End Add JVitug - OMNI.1 - 2020-03-23
				}
			}
			else{ 
				//Process records with no bill pay vendor characteristic				
				if (ccbFlag.compareTo(NOT_IN_CCB) == 0 || ccbFlag.compareTo(DIFF) == 0){					
					if (!isBlankOrNull(FT_BILL_PAY_VENDOR)){
						addBillPayChar(acctId.getEntity(), FT_BILL_PAY_VENDOR);
						bpAdded++;
						
						//Start Add JVitug - OMNI.1 - 2020-03-23
						updateBillFormat(acctId, FT_BILL_PAY_VENDOR);						
						//End Add JVitug - OMNI.1 - 2020-03-23
					}
				}
			}

			return true;
		}

		//Start Add JVitug - OMNI.1 - 2020-03-23
		/**
		 * This method updates Account's Bill Format to E-Bill
		 * @param acctId
		 */
		private void updateBillFormat(Account_Id acctId, String billPayVendor){
		    
		    //Check to see if the Account's Bill Format is also paperless (XE)
            ListFilter<AccountPersons> mainPersonFilter = acctId.getEntity().getPersons().createFilter("WHERE this.isMainCustomer = :true", "getMainPerson");
            mainPersonFilter.bindBoolean("true" , Bool.TRUE);
            
            if(mainPersonFilter.listSize() != 0 ){
                AccountPerson mainPerson = (AccountPerson) mainPersonFilter.firstRow();                

                BillFormatLookup eBill = BillFormatLookup.constants.EBILL; 
                BillFormatLookup detailed = BillFormatLookup.constants.DETAILED; 
                
                if (isPaperlessVendor(billPayVendor).isTrue()) {
                    //If account's Bill Format is not an E-Bill set it to E-Bill
                    if(mainPerson.getBillFormat().compareTo(eBill) != 0) {
                        AccountPerson_DTO mainPersonDTO = mainPerson.getDTO();
                        
                        mainPersonDTO.setBillFormat(eBill);
                        mainPerson.setDTO(mainPersonDTO); 
                    }
                    
                }else{
                    
                    if(mainPerson.getBillFormat().compareTo(eBill) == 0) {
                        
                        CharacteristicType_Id charTypeId = new CharacteristicType_Id(EBILLENR);
                        
                        if(notNull(charTypeId.getEntity())){
                            
                            CharacteristicType ebillenr = charTypeId.getEntity();
                            
                            //Check the effective characteristic value for account characteristic type EBILLENR  
                            AccountCharacteristic ebillenrCharVal = acctId.getEntity().getEffectiveCharacteristic(ebillenr);
                            AccountPerson_DTO mainPersonDTO = mainPerson.getDTO();
                            
                            if(notNull(ebillenrCharVal)) {
                               
                                //If EBILLENR characteristic is N, set the bill format to EBill. Otherwise, set it to Detailed.
                                if(ebillenrCharVal.getSearchCharacteristicValue().trim().compareToIgnoreCase(EBILLENR_NO) != 0){ 
                                    mainPersonDTO.setBillFormat(eBill);                                    
                                    mainPerson.setDTO(mainPersonDTO);
                                }else{                                   
                                    mainPersonDTO.setBillFormat(detailed);                                    
                                    mainPerson.setDTO(mainPersonDTO);
                                }
                            } else {  
                                //If there is no EBILLENR characteristic, set bill format to Detailed.
                                mainPersonDTO.setBillFormat(detailed);
                                mainPerson.setDTO(mainPersonDTO);
                            }
                        }
                        
                      
                    }
                }
                
            }
		    
		              
		   
		}		
		//End Add JVitug - OMNI.1 - 2020-03-23
		
		@Override
		public void finalizeThreadWork() throws ThreadAbortedException,
		RunAbortedException {

			logInfo(CustomMessageRepositorySpireOne.S1_totalRecordsAdded(bpAdded));//bpAdded
			logInfo(CustomMessageRepositorySpireOne.S1_totalRecordsUpdated(bpUpdated));//bpUpdated
			logInfo(CustomMessageRepositorySpireOne.S1_totalRecordsRemoved(bpRemoved));//bpRemoved
		}

		public void addBillPayChar(Account account, String charVal){
			maxErrors = getParameters().getMAX_ERRORS();
			if (isNull(maxErrors)){
				maxErrors = getParameters().getSoftMaxErrors();
			}

			AccountCharacteristic_DTO acDto = new AccountCharacteristic_DTO();

			AccountCharacteristic_Id acctCharId = new AccountCharacteristic_Id(billPayVendorCharType, account, getProcessDateTime().getDate());
			//Start Add JVitug - OMNI.1 - 2020-03-23
            CharacteristicTypeLookup charTypeLookup = billPayVendorCharType.getCharacteristicType();
            //End Add JVitug - OMNI.1 - 2020-03-23
            
			try{
				if (!isNull(acctCharId.getEntity())){				    
					acDto = acctCharId.getEntity().getDTO();
					//Start Change JVitug - OMNI.1 - 2020-03-23
					//acDto.setAdhocCharacteristicValue(charVal);
					if(charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()){
					    acDto.setAdhocCharacteristicValue(charVal);
					}else if(charTypeLookup.isPredefinedValue()){
					    acDto.setCharacteristicValue(charVal);
					}else if(charTypeLookup.isForeignKeyValue()){
					    acDto.setCharacteristicValueForeignKey1(charVal);
					}
					//End Change JVitug - OMNI.1 - 2020-03-23
					acctCharId.getEntity().setDTO(acDto);
				}
				else{				
					acDto.setId(acctCharId);
					//Start Change JVitug - OMNI.1 - 2020-03-23
                    //acDto.setAdhocCharacteristicValue(charVal);
                    if(charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()){
                        acDto.setAdhocCharacteristicValue(charVal);
                    }else if(charTypeLookup.isPredefinedValue()){
                        acDto.setCharacteristicValue(charVal);
                    }else if(charTypeLookup.isForeignKeyValue()){
                        acDto.setCharacteristicValueForeignKey1(charVal);
                    }
                    //End Change JVitug - OMNI.1 - 2020-03-23
					acDto.newEntity();           
				}
			}catch (ApplicationError e){
				logError(e.getServerMessage());
				//errorCount++;				
			}

		}
		
		//Start Add JVitug - OMNI.1 - 2020-03-23
		/**
		 * Check if the payVendor received in this method
		 * is in the Paperless Vendors Feature Configuration
		 * @param payVendor
		 * @return if vendor is paperless
		 */
		private Bool isPaperlessVendor(String payVendor) {
			Bool result = Bool.FALSE;
			StringBuilder stringsql = new StringBuilder();
			PreparedStatement query = null;
			SQLResultRow resultSet = null;
			
			stringsql.append("SELECT WFM_OPT_VAL ");
			stringsql.append("FROM ");
			stringsql.append(   "CI_WFM_OPT ");
			stringsql.append("WHERE ");
			stringsql.append(   "WFM_NAME = :wfmName ");
			stringsql.append("AND ");
			stringsql.append(   "EXT_OPT_TYPE = :optionType ");
			stringsql.append("AND ");
			stringsql.append(   "WFM_OPT_VAL = :optVal ");
			
			query = createPreparedStatement(stringsql.toString(), getClass().getName());
			query.bindId("wfmName" , thirdPartyEBillFeatConfig.getId());
			query.bindLookup("optionType" , CmAllUserProcessingLookup.constants.CMB_BILL_PRESENTMENT_VENDORS);
			query.bindString("optVal", payVendor.trim() , "WFM_OPT_VAL" );
			
			resultSet = query.firstRow();
			query.close();
			
			if(notNull(resultSet)){
				result = Bool.TRUE;
			}
			
			return result;
		}
		//End Add JVitug - OMNI.1 - 2020-03-23
	}

}
