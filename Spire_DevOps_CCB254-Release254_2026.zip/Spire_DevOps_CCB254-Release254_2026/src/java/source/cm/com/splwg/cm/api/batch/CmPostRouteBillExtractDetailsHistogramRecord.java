/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 2024-07-30   DLampa     INC0037039. Updated field lengths to match 
 *                         the file layout extracted by the CM-BILEXTR 
 *                         algorithm 
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractDetailsHistogramRecord 
		extends ColumnDelimitedRecord{	
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractDetailsHistogramRecord(int billSqListCnt) {
		
		super((10+(billSqListCnt*2)));

		// Initialize all fields as blank/spaces
		this.setBPPrinterKey(" ");		
		this.setBPSortKey(" ");
		this.setBPMailingKey(" ");		
		this.setUomCd(" ");
		this.setTouCd(" ");
		this.setSqiCd(" ");
		this.setSqDecPos(" ");
		this.setSqCnt(" ");
		this.setMaxBillSq(BigDecimal.ZERO, "0");
		this.setBillSqList(new ArrayList<String>());
	}

	
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}	
	/*
	 * 
	 */
	public void setBPPrinterKey(String value) {		
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
	public void setBPSortKey(String value) {
		rightPadColumn(2, 184, truncateInput(value, 184));
	}
	public void setBPMailingKey(String value) {
		rightPadColumn(3, 15, truncateInput(value, 15));
	}	
	/*
	 * Histogram (List)
	 */
	public void setUomCd(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(4, 4, truncateInput(value, 4));
		rightPadColumn(4, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setTouCd(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(5, 8, truncateInput(value, 8));
		rightPadColumn(5, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setSqiCd(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(6, 8, truncateInput(value, 8));
		rightPadColumn(6, 30, truncateInput(value, 30));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setSqDecPos(String value) {
		leftPadColumnWithZeros(7, 1, truncateInput(value, 1));
	}
	public void setSqCnt(String value) {
		leftPadColumnWithZeros(8, 2, truncateInput(value, 2));
	}
	public void setMaxBillSq(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(9, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(10, 18, truncateInput(value, 18));
	}
	private int totalCharCnt = 42;
	public void setBillSqList(List<String> billSqList) {		
		int columnNbr = 10;
		String prevBillSqStr = " ";
		for (int x = 0; x < billSqList.size(); x++) {
			
			String billSqID= billSqList.get(x);
			
			String[] billSqSplit = billSqID.trim().split(",");
			String sqDateStr = billSqSplit[0].trim();
			String billSqStr = billSqSplit[1].trim();			
			columnNbr++;
			rightPadColumn(columnNbr, 10, truncateInput(sqDateStr, 10));
			totalCharCnt = totalCharCnt + 10;
			columnNbr++;
			rightPadColumn(columnNbr, 19, truncateInput(billSqStr, 19));
			prevBillSqStr = billSqStr;
			totalCharCnt = totalCharCnt + 19;
		}
		
		//if (totalCharCnt < 3444) {
		if (totalCharCnt < 3241) {
			//int maxLength = 19 + (3444 - totalCharCnt);
			int maxLength = 19 + (3241 - totalCharCnt);
			rightPadColumn(columnNbr, maxLength, truncateInput(prevBillSqStr, maxLength));
		}		
	}		
}