/*
 **************************************************************************
 *                Confidentiality Information:
 *
 * This module is the confidential and proprietary information of
 * Oracle Corporation; it is not to be copied, reproduced, or
 * transmitted in any form, by any means, in whole or in part,
 * nor is it to be used for any purpose other than that for which
 * it is expressly provided without the written permission of
 * Oracle Corporation.
 *
 *
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * SA Type - Break Payment Arrangement Algorithm
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2016-09-20   JHerna  58779. Initial Version. 
 * 2023-03-24   JVitug  D-03324.Issue1. Added custom method that calculates
 *                      FTs that are yet to be swept by a bill
 *                      and subtracts them from the Gas SA Current balance
 *                      when creating a snapshot of the balance of both the
 *                      CWR SA and Gas SA.     
 * 2025-07-28   JVitug  E-11030 / INC0059665. Updated method 
 *                      calculateTotalOfFTsAfterCWRSAEndDate() to only
 *                      consider frozen FTs.
 * 2025-09-01   JVitug  E-11030.Issue1. Updated to now also consider the total
 *                      current balance of an account's Pledge Overpayment SA.                    
 **************************************************************************
 */
package com.splwg.cm.domain.admin.serviceAgreementType;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.currency.Currency_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.adjustmentCancelReason.entity.AdjustmentCancelReason;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.breakPayArrangement.SaTypeBreakPayArrangementAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.common.CancelPaymentArrangement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.api.lookup.CmQuotePortalParametersLookup;
import com.splwg.cm.api.lookup.CmServiceTaskCharacteristicTypesLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = charTypeBrokenPaymentArrangement, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = charValBrokenPaymentArrangement, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = adjTypeSynch, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentCancelReason, name = adjustmentCancelReason, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = charTypeQuoteSource, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = charTypeServiceAgreement, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = charTypeBalBefBreakingPa, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = cwrPaSaTypes, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = quotePortalFeatureConfig, required = true, type = entity )
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = serviceTaskCharFeatureConfiguration, required = true, type = entity )
 *            , @AlgorithmSoftParameter (name = pledgeOverpaymentSAType, required = true, type = string )})
 */
public class CmSaTypeBreakPaymentArrangementAlgComp_Impl 
		extends CmSaTypeBreakPaymentArrangementAlgComp_Gen 
		implements SaTypeBreakPayArrangementAlgorithmSpot {

	// Hard Parameters
	@SuppressWarnings("unused")
	private Account hpAccount;
	private ServiceAgreement hpServiceAgreement;
	private AdjustmentType hpXferAdjustmentType;
	
	// Soft Parameters
	private CharacteristicType parmCharTypeBrokenPaymentArrangement;
	private String parmCharValBrokenPaymentArrangement;
	private AdjustmentType parmAdjTypeSynch;
	private AdjustmentCancelReason parmAdjCancelReason;
    private List<String> parmCollOfCWRSaTypes = new ArrayList<String>();
    private CharacteristicType parmCharTypeBalanceBeforeBreakingPA;
    private CharacteristicType parmCharTypeSAID;
    private CharacteristicType parmCharTypeQuoteSourceID;
    //Start Add JVitug - E-11030 / INC0059665 - 2025-07-28
    private FeatureConfiguration quotePortalFeatureConfig;
    private FeatureConfiguration serviceTaskCharFeatureConfiguration;
    //End Add JVitug - E-11030 / INC0059665 - 2025-07-28
    //Start Add JVitug - E-11030.Issue1 - 2025-09-02
    private String pledgeOverpaymentSAType;
    //End Add JVitug - E-11030.Issue1 - 2025-09-02
    
	// Work Variable
	private static CharacteristicValue charValueBrokenPA;
	//Start Add JVitug - E-11030 / INC0059665 - 2025-07-28
	BusinessObject pledgeBusinessObject;
	String pledgeBusinessObjectActiveStatus;
	CharacteristicType amountCharType;
	Currency_Id currencyId;
	Money pledgeAmount;
	ServiceTaskType pledgeServiceTaskType;
	//End Add JVitug - E-11030 / INC0059665 - 2025-07-28
	
	//Start Add JVitug - E-11030.Issue1 - 2025-09-02
	ServiceAgreement pledgeOverpaymentSA;
	//End Add JVitug - E-11030.Issue1 - 2025-09-02
	
	@Override
	public void setAccount(Account acct) {
		this.hpAccount = acct;

	}

	@Override
	public void setServiceAgreement(ServiceAgreement sa) {
		this.hpServiceAgreement = sa;

	}

	@Override
	public void setTransferAdjustmentType(AdjustmentType adj) {
		this.hpXferAdjustmentType = adj;

	}	

	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		
		// Retrieve Parameter 10: Broken Payment Arrangement Characteristic Type 
		this.parmCharTypeBrokenPaymentArrangement = this.getCharTypeBrokenPaymentArrangement();
		
		// Validate that the characteristic is valid for the SA entity
		CharacteristicEntity_Id charEntityID = new CharacteristicEntity_Id(parmCharTypeBrokenPaymentArrangement, 
				CharacteristicEntityLookup.constants.SERVICE_AGREEMENT);
		if (isNull(charEntityID.getEntity())) {
			// Algorithm %1's parameter '%2%3' value (%4) is not a valid char type for %5%6 entity
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharTypeNotValidForEntity(this.getAlgorithmId().getTrimmedValue(),
					"Broken payment arrangement characteristic type", parmCharTypeBrokenPaymentArrangement.getId().getTrimmedValue(),
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.fieldName().trim()));
		}
		
		// Retrieve Parameter 20: Characteristic Value Broken Payment Arrangement
		this.parmCharValBrokenPaymentArrangement = this.getCharValBrokenPaymentArrangement();
		
		// Validate that the characteristic value is valid for the characteristic type retrieved for algorithm parameter 10
		CharacteristicValue_Id charValID = new CharacteristicValue_Id(parmCharTypeBrokenPaymentArrangement, parmCharValBrokenPaymentArrangement.trim());
		if (isNull(charValID.getEntity())) {
			// Algorithm %1's parameter '%2%3' value (%4) is not a valid char value for %5 char type.
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharValueNotValidForCharType(this.getAlgorithmId().getTrimmedValue(),
					"Broken payment arrangement characteristic value", parmCharValBrokenPaymentArrangement.trim(), 
					parmCharTypeBrokenPaymentArrangement.getId().getTrimmedValue()));
		}
		charValueBrokenPA = charValID.getEntity();

		// Retrieve Parameter 30: Adjustment Type (transfer money to original SA)
		this.parmAdjTypeSynch = this.getAdjTypeSynch();
		
		// Retrieve Parameter 40: Adjustment Cancel Reason
		this.parmAdjCancelReason = this.getAdjustmentCancelReason();
		
        // Retrieve Parameter 50: Quote Source Characteristic Type
        parmCharTypeQuoteSourceID = this.getCharTypeQuoteSource();
        
        // Verify that the characteristic type is valid for the service agreement entity.
        validateCharacteristicType(parmCharTypeQuoteSourceID, 
        		CharacteristicEntityLookup.constants.SERVICE_AGREEMENT, 
        		"Quote Source Characteristic Type");
        
        // Retrieve Parameter 60: SA ID Characteristic Type
        parmCharTypeSAID = this.getCharTypeServiceAgreement();
        
        // Verify that the characteristic type is valid for the Service Task entity.
        validateCharacteristicType(parmCharTypeSAID,
        		CharacteristicEntityLookup.constants.SERVICE_TASK, 
        		"SA ID Characteristic Type");
        
        // Retrieve Parameter 70: Balance before breaking PA Characteristic Type
        parmCharTypeBalanceBeforeBreakingPA = this.getCharTypeBalBefBreakingPa();
        
        // Verify that the characteristic type is valid for the service agreement entity.
        validateCharacteristicType(parmCharTypeBalanceBeforeBreakingPA, 
        		CharacteristicEntityLookup.constants.SERVICE_AGREEMENT, 
        		"Balance before breaking Payment Arrangement Characteristic Type");
        
        // Retrieve Parameter 80: CWR PA SA Types
        String cwrPASATypes = this.getCwrPaSaTypes();
        // Verify that all the CWR PA SA Types (comma delimited) are valid sa types
        validateCwrPaSaTypes(cwrPASATypes);
        
        //Start Add JVitug - E-11030 / INC0059665 - 2025-07-28
        quotePortalFeatureConfig = getQuotePortalFeatureConfig();
        serviceTaskCharFeatureConfiguration = getServiceTaskCharFeatureConfiguration();
        //End Add JVitug - E-11030 / INC0059665 - 2025-07-28
        
        //Start Add JVitug - E-11030.Issue1 - 2025-09-02
        pledgeOverpaymentSAType = getPledgeOverpaymentSAType();
        
        //Validate that the Overpayment SA Type exists
        validatePledgeOverpaymentSAType();
        //End Add JVitug - E-11030.Issue1 - 2025-09-02
	}
	
    private void validateCharacteristicType(CharacteristicType charType, CharacteristicEntityLookup charEntityLookup, String parmDescr) {
    	
   	 CharacteristicEntity_Id charEntityID = new CharacteristicEntity_Id(charType.getId(), 
   			 charEntityLookup);
        
        if (isNull(charEntityID.getEntity())) {
        	addError(CustomMessageRepositoryMGE.commAlgorithmParameterCharTypeNotValidForEntity(
        			this.getAlgorithmId().getTrimmedValue(),
        			parmDescr.trim(), 
        			charType.getId().getTrimmedValue(), 
        			charEntityLookup.fieldName().trim()));
        }
   }
   
   private void validateCwrPaSaTypes(String cwrPASATypes) {
   	
   	String[] arraySaType = cwrPASATypes.split(",");
   	
   	for (int x=0; x < arraySaType.length; x++) {
   		
   		String saType = arraySaType[x];
   		
   		if (notBlank(saType)) {
   			StringBuilder stringBuilder = new StringBuilder();
       		stringBuilder.append("SELECT 'X' ");
       		stringBuilder.append("FROM CI_SA_TYPE ");
       		stringBuilder.append("WHERE SA_TYPE_CD = :saType ");
       		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==ValidateCwrPaSaTypes==");
       		prepState.bindString("saType", saType.trim(), "SA_TYPE_CD");
       		prepState.execute();
       		prepState.setAutoclose(false);
       		if (prepState.list().size() == 0) {
       			prepState.close();
       			// SA Type is invalid
       			addError(CustomMessageRepositoryMGE.commAlgorithmParameterIsInvalid(
       					this.getAlgorithmId().getTrimmedValue(),
       					"CWR Payment Arrangement SA Types", 
       					saType));
       		}
       		else {
       			if (notBlank(saType)) {
       				if (!parmCollOfCWRSaTypes.contains(saType.trim())) {
       					parmCollOfCWRSaTypes.add(saType.trim());
       				}
       			}
       		}
       		prepState.close();
   		}
   	}
   	// If there are no SA Types provided then trigger error message
		if (parmCollOfCWRSaTypes.isEmpty()) {
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterMissing(
					this.getAlgorithmId().getTrimmedValue(),
					"CWR Payment Arrangement SA Types"));
		}    
   }
	
	@Override
	public void invoke() { 
		
		// Start 58779 additional functionality to store balances before breaking the payment arrangement
        String saType = hpServiceAgreement.getServiceAgreementType().fetchIdSaType().trim();
        // Store balances only if the SA being broken is one of the CWR PA SAs on the list
        if (parmCollOfCWRSaTypes.contains(saType)) {
        	//Start Add JVitug - E-11030 / INC0059665 - 2025-07-28
        	//Get required info from Quote portal Feature Configuration
        	retrieveFeatureConfigurationParameters(); 
        	currencyId = hpServiceAgreement.getAccount().getCurrency().getId();
        	//End Add JVitug - E-11030 / INC0059665 - 2025-07-28
        	
        	// Capture Current Balance of the CWR PA SA before breaking.
        	Money currentBalanceBeforeBreakPaSA = hpServiceAgreement.getCurrentBalance();
        	//Start Add JVitug - D-03324.Issue1 - 2023-03-22
        	BigDecimal breakPAAmount = currentBalanceBeforeBreakPaSA.getAmount();
        	//End Add JVitug - D-03324.Issue1 - 2023-03-22
        	
        	Money currentBalanceBeforeBreakGasSA = Money.ZERO;
        	
        	// Retrieve Gas SA linked to this CWR PA SA.
        	ServiceAgreement gasSA = cmRetrieveLinkedGasSA(hpServiceAgreement);
        	
        	Money totalAmountOfFTsWithNoArrearsOrFutureDated = Money.ZERO;
        	if (notNull(gasSA)) {
            	// Capture Current Balance of the linked GAS SA before the CWR PA SA is broken.
            	currentBalanceBeforeBreakGasSA = gasSA.getCurrentBalance();
            	//Start Add JVitug - D-03324.Issue1 - 2023-03-22
            	totalAmountOfFTsWithNoArrearsOrFutureDated = calculateTotalOfFTsAfterCWRSAEndDate(gasSA);
        		breakPAAmount = breakPAAmount.add(currentBalanceBeforeBreakGasSA.getAmount().subtract(totalAmountOfFTsWithNoArrearsOrFutureDated.getAmount()));
            	//End Add JVitug - D-03324.Issue1 - 2023-03-22
        		
        		//Start Add JVitug - E-11030 / INC0059665 - 2025-07-28
        		pledgeAmount = retrieveActivePledgeAmount(gasSA);

        		//Subtract the pledge amounts from the balance before PA Breakage
        		breakPAAmount = breakPAAmount.subtract(pledgeAmount.getAmount());
        		
        		//Start Add JVitug - E-11030.Issue1 - 2025-09-02
        		pledgeOverpaymentSA = retrievePledgeOverpaymentSAFromAccount();
        		
        		//If pledge Overpayment exists for the account and its current balance is not zero, subtract
        		//the balance from the Break PA amount
        		if(notNull(pledgeOverpaymentSA) 
        				&& pledgeOverpaymentSA.getCurrentBalance().
        				getAmount().compareTo(BigDecimal.ZERO) != 0) {
        			breakPAAmount = breakPAAmount.subtract(pledgeOverpaymentSA.getCurrentBalance().getAmount().abs());
        		}
        		//End Add JVitug - E-11030.Issue1 - 2025-09-02
        		
        		//If resulting amount from the calculations above is less than zero, make it zero.
        		//This is copied from the CmPaymentArrangementMaintenance logic
        		if(new Money(breakPAAmount, currencyId).isLessThan(Money.ZERO)) {
        			breakPAAmount = BigDecimal.ZERO.setScale(2);
        		}
            	//End Add JVitug - E-11030 / INC0059665 - 2025-07-28
        	}
        	//Start Change JVitug - D-03324.Issue1 - 2023-03-22
        	// Total the current balances retrieved above.
        	//Money totals = currentBalanceBeforeBreakPaSA.add(currentBalanceBeforeBreakGasSA);  
        	// Store this value as a Service Agreement Characteristic
        	//cmCreateCharacteristicOnSA(hpServiceAgreement, parmCharTypeBalanceBeforeBreakingPA, totals.getAmount().toString().trim());
        	cmCreateCharacteristicOnSA(hpServiceAgreement, parmCharTypeBalanceBeforeBreakingPA, breakPAAmount.toString().trim());
        	//End Change JVitug - D-03324.Issue1 - 2023-03-22
        	
        }   
		// End 58779 additional functionality to store balances before breaking the payment arrangement
		
		// Start cloned process of CIPCPARX
		CancelPaymentArrangement cancelPaymentArrangementRoutine = CancelPaymentArrangement.Factory.newInstance();
		cancelPaymentArrangementRoutine.cancel(hpServiceAgreement,
				charValueBrokenPA, 
				parmAdjTypeSynch,
				parmAdjCancelReason,
				hpXferAdjustmentType);
		// End cloned process of CIPCPARX

	}
	
	private ServiceAgreement cmRetrieveLinkedGasSA(ServiceAgreement payArrangeSA) {
    	
    	ServiceAgreement sa = null;
    	
    	// Retrieve the Quote ID which generated the CWR PA SA
    	String quoteID = cmGetSaCharacteristic(payArrangeSA, parmCharTypeQuoteSourceID);
    	
    	if (notBlank(quoteID)) {
    	
    		// Retrieve the SA ID characteristic from the Quote Service Task
    		String saIDstring = cmRetrieveSvcTaskChar(quoteID, parmCharTypeSAID);
    		ServiceAgreement_Id saID = new ServiceAgreement_Id(saIDstring);
    		
    		if (notNull(saID.getEntity())) {
    			sa = saID.getEntity();
    		}
    	}
    	else {
    		addWarning(CustomMessageRepositoryMGE.commGenericError(
    				"Quote Source characteristic is missing. Gas SA linked to this Payment Arrangement SA ("
    						+payArrangeSA.getId().getTrimmedValue()+") cannot be found."));
    	}
    	return sa;
    }
    
    private String cmRetrieveSvcTaskChar(String svcTaskID, CharacteristicType charType) {
    	
    	String returnValue = " ";
    	StringBuilder stringBuilder = new StringBuilder();		
    	stringBuilder.append("SELECT SRCH_CHAR_VAL ");
    	stringBuilder.append("FROM F1_SVC_TASK_CHAR ");
    	stringBuilder.append("WHERE F1_SVC_TASK_ID = :svcTaskID  ");
    	stringBuilder.append("AND CHAR_TYPE_CD = :charTypeID ");
    	
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==Retrieve Service Task Characteristic==");
		prepState.bindString("svcTaskID", svcTaskID.trim(), "F1_SVC_TASK_ID");
		prepState.bindId("charTypeID", charType.getId());
		
		prepState.setAutoclose(false);
		prepState.execute();

		if (prepState.list().size() > 0) {
			
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			returnValue = (String) sqlRow.get("SRCH_CHAR_VAL");
		}				
		prepState.close();
		
		return returnValue;
    }
    
    private String cmGetSaCharacteristic(ServiceAgreement sa, CharacteristicType charType) {
    	
    	String returnValue = " ";
    	
    	ServiceAgreementCharacteristic saChar = sa.getEffectiveCharacteristic(charType);
    	
    	if (notNull(saChar)) {
    		CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
        	if (charTypeLookup.isAdhocValue()
        			|| charTypeLookup.isFileLocationValue()) {
        		returnValue = saChar.getAdhocCharacteristicValue().trim();
        	}
        	else if (charTypeLookup.isForeignKeyValue()) {
        		returnValue = saChar.getCharacteristicValueForeignKey1().trim();
        	}
        	else {
        		returnValue = saChar.getCharacteristicValue().trim();
        	}
    	} 
    	
    	return returnValue;
    }
    
    private void cmCreateCharacteristicOnSA(ServiceAgreement sa, CharacteristicType charType, String charValue) {
    	
    	if (notBlank(charValue)) {
    		
    		ServiceAgreementCharacteristic_Id saCharID = new ServiceAgreementCharacteristic_Id(sa, charType, this.getProcessDateTime().getDate());

    		
    		// SA Characteristic for the specified SA Char Type and Effective Date already exists
    		if (notNull(saCharID.getEntity())) {
    			
    			startChanges();
    			ServiceAgreementCharacteristic saChar = saCharID.getEntity();
    			ServiceAgreementCharacteristic_DTO saCharDTO = saChar.getDTO();
    			
    			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
            	if (charTypeLookup.isAdhocValue() 
            			|| charTypeLookup.isFileLocationValue()) {
            		saCharDTO.setAdhocCharacteristicValue(charValue.trim());
            	}
            	else if (charTypeLookup.isForeignKeyValue()) {
            		saCharDTO.setCharacteristicValueForeignKey1(charValue.trim());
            	}
            	else {
            		saCharDTO.setCharacteristicValue(charValue.trim());
            	}
            	saChar.setDTO(saCharDTO);
            	saveChanges();
    		}
    		else {
    			
        		ServiceAgreementCharacteristic_DTO saCharDTO = new ServiceAgreementCharacteristic_DTO();
            	
        		CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
            	if (charTypeLookup.isAdhocValue() 
            			|| charTypeLookup.isFileLocationValue()) {
            		saCharDTO.setAdhocCharacteristicValue(charValue.trim());
            	}
            	else if (charTypeLookup.isForeignKeyValue()) {
            		saCharDTO.setCharacteristicValueForeignKey1(charValue.trim());
            	}
            	else {
            		saCharDTO.setCharacteristicValue(charValue.trim());
            	} 
            	saCharDTO.setId(saCharID);
            	saCharDTO.newEntity();
    		}
    	}
    } 
    
    //Start Add JVitug - D-03324.Issue1 - 2023-03-24
    /**
     * This method will calculate the sum of all FTs for a given SA
     * whose FT Arrears date is less than or equal to the process date
     * @param sa
     * @return Sum of current amounts of all the FTs
     */
    private Money calculateTotalOfFTsAfterCWRSAEndDate(ServiceAgreement sa) {
    	Money returnValue = Money.ZERO;
    	
    	StringBuilder stringSql = new StringBuilder();
    	
    	stringSql.append("SELECT " );
    	stringSql.append(   "NVL(SUM(FT.CUR_AMT) , 0) AS CUR_AMT_TOT " );
    	stringSql.append("FROM " );
    	stringSql.append(   "CI_FT FT " );
    	stringSql.append("WHERE " );
    	stringSql.append(   "FT.SA_ID = :saId " );
    	stringSql.append("AND " );
    	stringSql.append(   "(FT.ARS_DT IS NULL OR FT.ARS_DT > :cwrSAEndDate) " );
    	//Start Add JVitug -  E-11030 / INC0059665 - 2025-07-28
    	stringSql.append("AND " );
    	stringSql.append(   "FT.FREEZE_SW = 'Y' " );  
    	stringSql.append("AND " );
    	stringSql.append(   "FT.REDUNDANT_SW = 'N' " );
    	//End Add JVitug -  E-11030 / INC0059665 - 2025-07-28
    	
    	PreparedStatement sql = createPreparedStatement(stringSql.toString() , getClass().getName());
    	sql.bindId("saId", sa.getId());
    	sql.bindDate("cwrSAEndDate" , getProcessDateTime().getDate());
    	
    	SQLResultRow result = sql.firstRow();
    	sql.close();
    	
    	if(notNull(result)) {
    		returnValue = result.getMoney("CUR_AMT_TOT", sa.getCurrencyId());
    	}
    	
    	return returnValue;
    }
    //End Add JVitug - D-03324.Issue1 - 2023-03-24
    
    //Start Add JVitug -  E-11030 / INC0059665 - 2025-07-28
    /**
     * This method will retrieve the Active Pledge Amount.
     * @param sa
     * @return Money
     */
    private Money retrieveActivePledgeAmount(ServiceAgreement sa) {
        
        Money totalActivePledges = Money.ZERO;
        
        StringBuilder getActivePledge = new StringBuilder();
        getActivePledge.append("SELECT ST.F1_SVC_TASK_ID ");
        getActivePledge.append("FROM F1_SVC_TASK ST, F1_SVC_TASK_CHAR STC ");
        getActivePledge.append("WHERE ST.F1_STASK_TYPE_CD =:serviceTaskType ");
        getActivePledge.append("AND ST.BUS_OBJ_CD =:businessObject ");
        getActivePledge.append("AND ST.BO_STATUS_CD =:status ");
        getActivePledge.append("AND ST.F1_SVC_TASK_ID = STC.F1_SVC_TASK_ID ");
        getActivePledge.append("AND STC.CHAR_TYPE_CD =:characteristicType ");
        getActivePledge.append("AND STC.SRCH_CHAR_VAL =:searchCharacteristicValue ");
        getActivePledge.append("ORDER BY CRE_DTTM DESC ");

        PreparedStatement getActivePledgeQuery = createPreparedStatement(getActivePledge.toString(), getClass().getName());
        getActivePledgeQuery.setAutoclose(false);

        getActivePledgeQuery.bindEntity("serviceTaskType", pledgeServiceTaskType);
        getActivePledgeQuery.bindEntity("businessObject", pledgeBusinessObject);
        getActivePledgeQuery.bindStringProperty("status", ServiceTask.properties.status, pledgeBusinessObjectActiveStatus);
        getActivePledgeQuery.bindEntity("characteristicType", parmCharTypeSAID);
        getActivePledgeQuery.bindStringProperty("searchCharacteristicValue", ServiceTaskCharacteristic.properties.searchCharacteristicValue, 
                sa.getId().getTrimmedValue());
        
        Iterator activePledgeItr = getActivePledgeQuery.list().iterator();
        
        while(activePledgeItr.hasNext()) {
            SQLResultRow result = (SQLResultRow) activePledgeItr.next();
            ServiceTask pledge = result.getEntity("F1_SVC_TASK_ID", ServiceTask.class);

            String amount = retrieveServiceTaskCharValue(pledge, amountCharType);
            
            if (!isBlankOrNull(amount)) {
                totalActivePledges = totalActivePledges.add(new Money(amount, currencyId));
            }
        }
        
        getActivePledgeQuery.close();
        
        return totalActivePledges;
    }
    
    private void retrieveFeatureConfigurationParameters () {
    	CmFeatureConfigurationRetriever featConfigRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
        featConfigRetriever.setParmWFMName(quotePortalFeatureConfig);
        
        // Pledge Service Task Type
        LookupValue optionType =  CmQuotePortalParametersLookup.constants.PLEDGE_SERVICE_TASK_TYPE.getLookupValue();
        featConfigRetriever.setParmOptType(optionType.fetchIdFieldValue());
        pledgeServiceTaskType = new ServiceTaskType_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();

        // Pledge Business Object
        optionType = CmQuotePortalParametersLookup.constants.PLEDGE_BUSINESS_OBJECT.getLookupValue();
        featConfigRetriever.setParmOptType(optionType.fetchIdFieldValue());
        pledgeBusinessObject = new BusinessObject_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();

        // Pledge Business Object Active Status
        optionType = CmQuotePortalParametersLookup.constants.PLEDGE_BUSINESS_OBJECT_ACTIVE_STATUS.getLookupValue();
        featConfigRetriever.setParmOptType(optionType.fetchIdFieldValue());
        pledgeBusinessObjectActiveStatus = featConfigRetriever.getMaxSequenceOptionValue().trim();
        
        featConfigRetriever.setParmWFMName(serviceTaskCharFeatureConfiguration);
        
        // Amount Characteristic Type
        optionType = CmServiceTaskCharacteristicTypesLookup.constants.AMOUNT_CHARACTERISTIC_TYPE.getLookupValue();
        featConfigRetriever.setParmOptType(optionType.fetchIdFieldValue());
        amountCharType = new CharacteristicType_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
    }
    
    /**
     * This method will return the characteristic value of the given Service Task and Characteristic Type.
     * @param serviceTask 
     * @param charType
     * @return String
     */
    private String retrieveServiceTaskCharValue(ServiceTask serviceTask, CharacteristicType charType) {
        
        String charValue = "";
        
        ListFilter<ServiceTaskCharacteristic> serviceTaskCharFilter = serviceTask.getCharacteristics()
                .createFilter("WHERE this.id.characteristicType = :charType ORDER BY this.id.sequence DESC", 
                        getClass().getName());
        
        serviceTaskCharFilter.bindEntity("charType", charType);
        ServiceTaskCharacteristic serviceTaskChar = serviceTaskCharFilter.firstRow();
        
        if(notNull(serviceTaskChar)) {
            charValue = serviceTaskChar.getSearchCharacteristicValue();
        }
        
        return charValue.trim();
    }
    //End Add JVitug -  E-11030 / INC0059665 - 2025-07-28
    
    //Start Add JVitug - E-11030.Issue1 - 2025-09-02
    /**
     * Validate the Pledge Overpayment Type
     * @return
     */
    private void validatePledgeOverpaymentSAType() {
    	StringBuilder stringSql = new StringBuilder();
    	PreparedStatement sql = null;
    	List<SQLResultRow> results;
    	
    	stringSql.append("SELECT " );
    	stringSql.append(   "SAT.SA_TYPE_CD " );
    	stringSql.append("FROM " );
    	stringSql.append(   "CI_SA_TYPE SAT " );
    	stringSql.append("WHERE " );
    	stringSql.append(   "SAT.SA_TYPE_CD = :saType " );
    	
    	sql = createPreparedStatement(stringSql.toString() , getClass().getName());
    	sql.bindString("saType", pledgeOverpaymentSAType, "SA_TYPE_CD");
    	
    	results = sql.list();
    	sql.close();
    	
    	if(results.size() < 1 ){
    		addError(CustomMessageRepositoryMGE.commAlgorithmParameterIsInvalid(
   					this.getAlgorithmId().getTrimmedValue(),
   					"Pledge Overpayment SA Type", 
   					pledgeOverpaymentSAType));
    	}
    }
    
    /**
     * Retrieve the Account's Pledge Overpayment SA, if any.
     * @return
     */
    private ServiceAgreement retrievePledgeOverpaymentSAFromAccount() {
    	ServiceAgreement pledgeOverpaymentSA = null;
    	StringBuilder stringSql = new StringBuilder();
    	PreparedStatement sql = null;
    	SQLResultRow result = null;
    	
    	stringSql.append("SELECT " );
    	stringSql.append(   "SA.SA_ID " );
    	stringSql.append("FROM " );
    	stringSql.append(   "CI_SA SA " );
    	stringSql.append("WHERE " );
    	stringSql.append(   "SA.SA_TYPE_CD = :saType " );
    	stringSql.append("AND " );
    	stringSql.append(   "SA.CIS_DIVISION = :divisionId " );
    	stringSql.append("AND " );
    	stringSql.append(   "SA.ACCT_ID = :accountId " );
    	stringSql.append("AND " );
    	stringSql.append(   "SA.SA_STATUS_FLG NOT IN (:closed , :canceled) " );
    	
    	sql = createPreparedStatement(stringSql.toString() , getClass().getName());
    	sql.bindString("saType", pledgeOverpaymentSAType, "SA_TYPE_CD");
    	sql.bindId("divisionId", hpServiceAgreement.getAccount().getDivisionId());
    	sql.bindId("accountId" , hpServiceAgreement.getAccount().getId());
    	sql.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
    	sql.bindLookup("canceled", ServiceAgreementStatusLookup.constants.CANCELED);
    	
    	result = sql.firstRow();
    	sql.close();
    	
    	if(notNull(result)) {
    		pledgeOverpaymentSA = result.getEntity("SA_ID", ServiceAgreement.class);
    	}
    	
    	return pledgeOverpaymentSA;
    }
    //End Add JVitug - E-11030.Issue1 - 2025-09-02
}
