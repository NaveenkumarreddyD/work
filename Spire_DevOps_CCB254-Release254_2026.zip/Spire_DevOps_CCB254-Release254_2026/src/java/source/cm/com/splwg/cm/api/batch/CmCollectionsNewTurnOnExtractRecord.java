/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * MGE-CCB004.006 (CR3135978) - Collections New Turn On Extract Record 
 * 
 * This is the record class for the Collections New Turn On Extract
 * batch program.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2014-01-30	MCRUZ			MGE-CCB004.006 (CR3135978) Initial Version.
 **************************************************************************/

package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmCollectionsNewTurnOnExtractRecord extends ColumnDelimitedRecord {

	public CmCollectionsNewTurnOnExtractRecord() {
		super(6);
	}
	
	public void setAccount(String accountId) {
		this.rightPadColumn(1, 10, cmTruncateString(accountId, 10));
	}
	
	public void setServiceAgreement(String saId) {
		this.rightPadColumn(2, 10, cmTruncateString(saId, 10));
	}
	
	public void setCisDivision(String cisDivision) {
		this.rightPadColumn(3, 5, cmTruncateString(cisDivision, 5));
	}
	
	public void setSaType(String saType) {
		this.rightPadColumn(4, 8, cmTruncateString(saType, 8));
	}
	
	public void setSaStartDate(String startDate) {
		this.rightPadColumn(5, 10, cmTruncateString(startDate, 10));
	}
	
	public void setCollectionAgencyReferral(String referralId) {
		this.rightPadColumn(6, 10, cmTruncateString(referralId, 10));
	}
	
	private String cmTruncateString(String string, int maxFieldLength){
        if (string.length() > maxFieldLength){
            return string.substring(0, maxFieldLength).trim();            
        } else {
            return string.trim();
        }
    }
	

}
