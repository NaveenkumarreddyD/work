/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm will be used to stop Dollar Help SA as of last billing.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2019-09-16   RKing       Initial Version.                   
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.stopSa;



import com.splwg.base.api.Query;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saStop.SaTypeSaStopAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.cm.domain.common.customBusinessComponent.CmDollarHelpReversalRoutine;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;


/**
 * @author RKing
 *
 * @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentCancelReason, name = adjCancelReason, required = true, type = entity)
 * 										 , @AlgorithmSoftParameter (entityName = paymentCancelReason, name = payCancelReason, required = true, type = entity)
 * 										 , @AlgorithmSoftParameter (entityName = billCancelReason, name = billCancelReason, required = true, type = entity)
 *            })
 */

public class CmStopDollarHelpSAAlgComp_Impl extends CmStopDollarHelpSAAlgComp_Gen implements SaTypeSaStopAlgorithmSpot {
	
	// hard parameters
	private ServiceType serviceType;
	private ServiceAgreement sa;

	
	@Override
	public ServiceType getServiceType() {
		return serviceType;
	}

	@Override
	public void setPremise(Premise arg0) {

	}

	@Override
	public void setRevertToLandlord(String arg0) {
	}

	@Override
	public void setServiceAgreement(ServiceAgreement arg0) {
		sa = arg0;
	}

	@Override
	public void setServiceType(ServiceType arg0) {
		serviceType = arg0;
	}

	@Override
	public void setShouldCreateFieldActivity(Bool arg0) {
	}

	@Override
	public void setStopDate(Date arg0) {

	}

	@Override
	public void setStopRequestedBy(String arg0) {

	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

	}

	@Override
	public void invoke() {
		
		// Check for pending cancel, incomplete, error or freezable bill segments.
		Query<BillSegment> frzBsQry = createQuery("from BillSegment bs "
				+ " where bs.serviceAgreement = :sa "
				+ "		and bs.billSegmentStatus in (:incomplete,:pendingCancel,:error,:freezabol) "
				, "FBSQ");
		frzBsQry.bindEntity("sa", sa);
		frzBsQry.bindLookup("error", BillSegmentStatusLookup.constants.ERROR);
		frzBsQry.bindLookup("incomplete", BillSegmentStatusLookup.constants.INCOMPLETE);
		frzBsQry.bindLookup("pendingCancel", BillSegmentStatusLookup.constants.PENDING_CANCEL);
		frzBsQry.bindLookup("freezabol", BillSegmentStatusLookup.constants.FREEZABLE);
		
		// Error if bill segment found.
		if(frzBsQry.listSize() > 0) {
			BillSegment bs = frzBsQry.firstRow();
			addError(CustomMessageRepositorySpireOne.saHasABsegWithStatus(bs.getId().getIdValue()
					, bs.getBillSegmentStatus().getLookupValue().getEffectiveDescription()));
		}
		
		// Get latest frozen Bill Segment.		
		Query<QueryResultRow> bsQry = createQuery("from BillSegment bs "
				+ " where bs.serviceAgreement = :sa "
				+ "		and bs.billSegmentStatus = :frozen "
				, "BSQ");
		bsQry.bindEntity("sa", sa);
		bsQry.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
		bsQry.addResult("bsId", "bs.id");
		bsQry.addResult("endDate", "bs.endDate");
		bsQry.orderBy("endDate", Query.DESCENDING);
		
		if(bsQry.listSize() == 0) {
			
			// Set stop date to SA start date.
			ServiceAgreement_DTO saDto = sa.getDTO();
			saDto.setEndDate(sa.getStartDate());
			sa.setDTO(saDto);	
			
			// If no BS exists, cancel FTs and cancel SA.
			CmDollarHelpReversalRoutine rev = CmDollarHelpReversalRoutine.Factory.newInstance();
			rev.setAdjustmentCancelReason(getAdjCancelReason());
			rev.setPaymentCancelReason(getPayCancelReason());
			rev.setBillCancelReason(getBillCancelReason());
			rev.setServiceAgreement(sa);
			rev.execute();
				
			
		} else {
			
			// Set stop date to latest BS' end date.
			QueryResultRow latestBs = bsQry.firstRow();
			BillSegment_Id bsId = (BillSegment_Id) latestBs.getId("bsId", BillSegment.class);
			BillSegment bs = bsId.getEntity();
			
			ServiceAgreement_DTO saDto = sa.getDTO();
			saDto.setEndDate(bs.getEndDate());
			sa.setDTO(saDto);
			
			// Update latest BS to closing BS.
			PreparedStatement updBS = createPreparedStatement("UPDATE CI_BSEG BSEG SET BSEG.CLOSING_BSEG_SW = :Y "
					+ "WHERE BSEG.BSEG_ID = :BS"
					,"updBS");
			updBS.bindBoolean("Y", Bool.TRUE);
			updBS.bindId("BS", bs.getId());
			updBS.execute();
			updBS.close();
		}

	}

}
