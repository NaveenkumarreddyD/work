/**************************************************************************
* Program Name: CmCreateWriteOffRecordAlgComp_Impl
* Program Title: CmCreateWriteOffRecordAlgComp_Impl
* Author: Justine Roxas
* Creation Date: 2017-07-10
* Purpose: This algorithm will stage a write-off service agreement for
*          automated write-off transfer upon FT freeze.
*  
* Functional Spec: SA-68623.1
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
 * ----------------------------------------------------------------------------------------------
 *  SA-68623.1        Justine Roxas    2017-07-10    Initial Version.
 *  CCB25.4 Upgrade   EQuint           2025-11-14        
 ************************************************************************************************/
package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.ftFreeze;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControl;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.database.table.Table_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.ftFreeze.SaTypeFtFreezeAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountPerson;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic_Id;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
import com.splwg.cm.domain.common.customBusinessComponent.ChangeLogTable_DTO;
import com.splwg.cm.domain.common.customBusinessComponent.ChangeLogTable_Id;
import com.splwg.cm.domain.creditcollections.writeOffProcess.CmWriteOffTransfer_DTO;
import com.splwg.cm.domain.creditcollections.writeOffProcess.CmWriteOffTransfer_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

/**
 * @author JRoxas
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = batchControl, name = batchControl, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = changeTypeFlag, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = custClassList, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = saToExcludeCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = saToExcludeCharVal, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)})
 */
public class CmCreateWriteOffRecordAlgComp_Impl extends CmCreateWriteOffRecordAlgComp_Gen
        implements SaTypeFtFreezeAlgorithmSpot {
    
    //Hard Parameters
    private FinancialTransaction ft;
    
    //Soft Parameters
    private BatchControl batchControl;
    private String changeTypeFlag;
    private String custClassList;
    private CharacteristicType saToExcludeCharType;
    private String saToExcludeCharVal;
    private ToDoType toDoType;
    
    //Work Variables
    private ArrayList<CustomerClass_Id> customerClassList = new ArrayList<CustomerClass_Id>();
    private ServiceAgreement sa;
    
    //Constants
    private static final String DELIMITER = ",";
    private static final int MAX_FRP = 5;
    
    @Override
    public void invoke() {
        
        FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
        
        try {
            
            session.flush("flush");
            session.setSavepoint(getClass().getName());
            
            sa = ft.getServiceAgreement();
            
            ListFilter<ServiceAgreementCharacteristic> saCharFilter = sa.getCharacteristics()
                    .createFilter("WHERE this.id.characteristicType = :saToExcludeCharType " +
                    		"and this.searchCharacteristicValue = :saToExcludeCharVal", getClass().getName());
            saCharFilter.bindId("saToExcludeCharType", saToExcludeCharType.getId());
            saCharFilter.bindStringProperty("saToExcludeCharVal", ServiceAgreementCharacteristic.properties.searchCharacteristicValue, saToExcludeCharVal);
            
            if (saCharFilter.listSize() > 0) {
                return;
            }
            
            Money currentBalance = sa.getCurrentBalance();
            
            if (currentBalance.isLessThanOrEqual(Money.ZERO)) {
                removeSAFromCustomTransfer();
            } else {
                addSAToCustomTransfer();
            }
            
        } catch (ApplicationError e) {
            
            session.flush("flush");
            session.rollbackToSavepoint(getClass().getName());
            
            String[] errors = CustomMessageRepository.splitMessageParmString(e.getMessage());
            ServerMessage message = CustomMessageRepository.SA_68623_GenericError(errors);
            
            ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
            ToDoEntry_DTO toDoEntry_DTO = new ToDoEntry_DTO();
            toDoEntry_DTO.setToDoTypeId(toDoType.getId());
            toDoEntry_DTO.setCreationDateTime(getProcessDateTime());
            toDoEntry_DTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
            toDoEntry_DTO.setToDoPriority(toDoType.getToDoPriority());
            toDoEntry_DTO.setMessageId(message.getMessageId());
            toDoCreator.setToDoDTO(toDoEntry_DTO);
            
            for (String messageParm : errors) {
                toDoCreator.addMessageParameter(messageParm);
            }
            
            ToDoDrillKeyType tdDrillKeyType = toDoType.getDrillKeyTypes().iterator().next();
            toDoCreator.addDrillKeyValue(tdDrillKeyType, sa.getId().getIdValue());
            
            ToDoSortKeyType tdSortKeyType = toDoType.getSortKeyTypes().iterator().next();
            toDoCreator.addSortKeyValue(tdSortKeyType, sa.getId().getIdValue());
            
            toDoCreator.create();
        }

    }
    
    /**
     * This method deletes all entries in the custom and change log tables
     * for the write-off SA
     */
    private void removeSAFromCustomTransfer () {
        
        StringBuilder deleteSQL = new StringBuilder();
        deleteSQL.append("DELETE ");
        deleteSQL.append(  "FROM CM_WO_XFERS ");
        deleteSQL.append( "WHERE WO_SA_ID = :saId ");
        
        PreparedStatement deleteStatement = createPreparedStatement(deleteSQL.toString(), getClass().getName());
        deleteStatement.bindId("saId", sa.getId());
        deleteStatement.execute();
        
        StringBuilder getChangeLogs = new StringBuilder();
        getChangeLogs.append("SELECT CHG_LOG_ID ");
        getChangeLogs.append(  "FROM CI_CHG_LOG ");
        getChangeLogs.append( "WHERE BATCH_CD = :batchControl ");
        getChangeLogs.append(   "AND PK_VAL1 = :saId ");
        
        PreparedStatement deleteChangeLogs = createPreparedStatement(getChangeLogs.toString(), getClass().getName());
        deleteChangeLogs.bindId("batchControl", batchControl.getId());
        deleteChangeLogs.bindId("saId", sa.getId());
        
        for (SQLResultRow row : deleteChangeLogs.list()) {
            ChangeLogTable_Id changeLogId = new ChangeLogTable_Id(row.getBigDecimal("CHG_LOG_ID").toBigInteger());
            changeLogId.getEntity().delete();
        }
        
    }
    
    /**
     * This method determines what action needs to be performed
     * for the write-off SA
     */
    private void addSAToCustomTransfer () {
        
        CustomerClass custClass = sa.getAccount().getCustomerClass();
        CustomerClass_Id custClassId = null;
        if(notNull(custClass)) {
            custClassId = custClass.getId();
        }
        
        if (isInCustomTable().isTrue()) {
            createChangeLogRecord();
        }else {
            if (isCustomerClassEligible(custClassId).isTrue()) {
                insertSAToCustomTable();
                createChangeLogRecord();
            }else {
                tagSAAsIneligible();
            }
        }
    }
    
    /**
     * This method adds an entry to the custom table with the
     * write-off SA information
     */
    private void insertSAToCustomTable () {
        
        ListFilter<AccountPerson> acctPerFitler = sa.getAccount().getPersons()
                .createFilter("WHERE this.isFinanciallyResponsible = :true and this.isMainCustomer = :false ", getClass().getName());
        acctPerFitler.bindBoolean("true", Bool.TRUE); 
        acctPerFitler.bindBoolean("false", Bool.FALSE); 
        
        ArrayList<AccountPerson> acctPerList = new ArrayList<AccountPerson>();
        
        int counter = 0;
        for (AccountPerson acctPer : acctPerFitler.list()) {
            if (counter == MAX_FRP) {
                break;
            } else {
                acctPerList.add(acctPer);
                counter++;
            }
        }
        
        CmWriteOffTransfer_DTO cmWriteOff_DTO = new CmWriteOffTransfer_DTO();
        CmWriteOffTransfer_Id woSaId = new CmWriteOffTransfer_Id(sa.getId().getIdValue());
        cmWriteOff_DTO.setId(woSaId);
        cmWriteOff_DTO.setCmWoAccountId(sa.getAccount().getId().getIdValue());
        // start update - equint - 2025-11-14 - CCB25.4 Upgrade
        // cmWriteOff_DTO.setMainPersonId(sa.getAccount().getMainPerson().getId().getIdValue());
        cmWriteOff_DTO.setMainPerson(sa.getAccount().getMainPerson().getId().getIdValue());
        // end update - equint - 2025-11-14 - CCB25.4 Upgrade

        String frPerId = "";
        for (int i = 0; i < acctPerList.size(); i++) {
            frPerId = acctPerList.get(i).getId().getPersonId().getIdValue();
            if (i == 0) {
                cmWriteOff_DTO.setCmFinanciallyRespPer1(frPerId);
            }else if (i == 1) {
                cmWriteOff_DTO.setCmFinanciallyRespPer2(frPerId);
            }else if (i == 2) {
                cmWriteOff_DTO.setCmFinanciallyRespPer3(frPerId);
            }else if (i == 3) {
                cmWriteOff_DTO.setCmFinanciallyRespPer4(frPerId);
            }else if (i == 4) {
                cmWriteOff_DTO.setCmFinanciallyRespPer5(frPerId);
            }
        }
        
        cmWriteOff_DTO.newEntity();
    }
    
    /**
     * This method adds a characteristic to the write-off SA
     * to prevent this SA from being processed
     */
    private void tagSAAsIneligible () {
        
        ServiceAgreementCharacteristic_DTO saChar_DTO = new ServiceAgreementCharacteristic_DTO();
        ServiceAgreementCharacteristic_Id saCharId = new ServiceAgreementCharacteristic_Id(sa, saToExcludeCharType, getProcessDateTime().getDate());
        
        saChar_DTO.setId(saCharId);
        
        if(saToExcludeCharType.getCharacteristicType().isPredefinedValue()) {
            saChar_DTO.setCharacteristicValue(saToExcludeCharVal);
        } else if (saToExcludeCharType.getCharacteristicType().isAdhocValue()) {
            saChar_DTO.setAdhocCharacteristicValue(saToExcludeCharVal);
        } else if (saToExcludeCharType.getCharacteristicType().isForeignKeyValue()) {
            saChar_DTO.setCharacteristicValueForeignKey1(saToExcludeCharVal);
        }
        
        saChar_DTO.setSearchCharacteristicValue(saToExcludeCharVal);
        saChar_DTO.newEntity();
        
    }
    
    /**
     * This method checks if a write-off SA already has an entry
     * in the custom table
     * @return Bool
     */
    private Bool isInCustomTable () {
        
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT 'X' ");
        sb.append(  "FROM CM_WO_XFERS ");
        sb.append( "WHERE WO_SA_ID = :saId ");
        
        PreparedStatement statement = createPreparedStatement(sb.toString(), getClass().getName());
        statement.bindId("saId", sa.getId());
        
        if (statement.list().size() > 0) {
            return Bool.TRUE;
        }
        else {
            return Bool.FALSE;
        }
        
    }
    
    /**
     * This method checks if a write-off SA's Account's
     * customer class is eligible for processing
     * @return Bool
     */
    private Bool isCustomerClassEligible (CustomerClass_Id custClassId) {
        if(customerClassList.contains(custClassId)) {
            return Bool.TRUE;
        } else {
            return Bool.FALSE;
        }
    }
    
    /**
     * This method creates a change log record for
     * the write-off SA and batch control Id
     */
    private void createChangeLogRecord () {

        StringBuilder sb = new StringBuilder();
        sb.append("SELECT 'X' ");
        sb.append(  "FROM CI_CHG_LOG ");
        sb.append ("WHERE BATCH_CD = :batchCd ");
        sb.append(   "AND PK_VAL1 = :saId ");
        
        PreparedStatement selectStatement = createPreparedStatement(sb.toString(), getClass().getName());
        selectStatement.bindId("batchCd", batchControl.getId());
        selectStatement.bindId("saId", sa.getId());
        
        if (selectStatement.list().size() > 0) {
            return;
        }
        
        // Generate Change Log ID.
        ChangeLogTable_Id changeLogId = null;
        Bool isUniqueId = Bool.FALSE;
        while(isUniqueId.isFalse()) {

            BigInteger genId = generateChangeLogId();

            if(isUniqueChangeLogId(genId).isTrue()) {
                changeLogId = new ChangeLogTable_Id(genId);
                isUniqueId = Bool.TRUE;
                break;
            }
        }
        
        ChangeLogTable_DTO changeLogTable_DTO = new ChangeLogTable_DTO();
        changeLogTable_DTO.setId(changeLogId);
        changeLogTable_DTO.setBatchControlId(batchControl.getId());
        changeLogTable_DTO.setBatchNumber(batchControl.getNextBatchNumber());
        changeLogTable_DTO.setChangeDateTime(getProcessDateTime());
        changeLogTable_DTO.setChangeType(changeTypeFlag);
        changeLogTable_DTO.setTableId(new Table_Id("CM_WO_XFERS"));
        changeLogTable_DTO.setPkVal1(sa.getId().getIdValue());
        changeLogTable_DTO.setPkVal2(sa.getAccount().getId().getIdValue());
        changeLogTable_DTO.newEntity();
    }
    
    /**
     * This method checks if the generated key is unique to the Change Log table.
     * @param BigInteger
     * @return Bool
     */
    private Bool isUniqueChangeLogId(BigInteger changeLogId) {

        Bool isUnique = Bool.FALSE;

        PreparedStatement checkId = createPreparedStatement("SELECT " +
                "   CHG_LOG_ID " +
                " FROM " +
                "   CI_CHG_LOG " +
                " WHERE " +
                "   CHG_LOG_ID = :changeLogId", getClass().getName());

        checkId.bindId("changeLogId", new ChangeLogTable_Id(changeLogId));

        List checkIdList = checkId.list();

        if(notNull(checkIdList) || !checkIdList.isEmpty()) {
            isUnique = Bool.TRUE;
        }

        checkId.close();

        return isUnique;
    }
    
    /**
     * This method returns a randomly generated key.
     * @return BigInteger
     */
    private BigInteger generateChangeLogId() {

        PreparedStatement createId = createPreparedStatement("SELECT " +
                "   (TO_NUMBER(ROUND(DBMS_RANDOM.VALUE(1,99999999999999),0))) AS CHG_LOG_ID " +
                " FROM " +
                "   DUAL ", getClass().getName());

        SQLResultRow row = createId.firstRow();
        BigInteger intId = row.getInteger("CHG_LOG_ID");

        createId.close();

        return intId;
    }

    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        
        batchControl = getBatchControl();
        changeTypeFlag = getChangeTypeFlag();
        custClassList = getCustClassList();
        saToExcludeCharType = getSaToExcludeCharType();
        saToExcludeCharVal = getSaToExcludeCharVal();
        toDoType = getToDoType();
        
        CharacteristicValue_Id charValId = new CharacteristicValue_Id(saToExcludeCharType, saToExcludeCharVal);
        
        if (isNull(charValId.getEntity())) {
            addError(CustomMessageRepository.SA_68623_InvalidCharVal(saToExcludeCharVal, saToExcludeCharType.getId().getIdValue()));
        }
        
        StringTokenizer splitter = new StringTokenizer(custClassList, DELIMITER);
        
        while(splitter.hasMoreTokens()) {
            CustomerClass_Id custClass_Id = new CustomerClass_Id(splitter.nextToken());
            if (notNull(custClass_Id.getEntity())) {
                customerClassList.add(custClass_Id);
            } else {
                addError(CustomMessageRepository.SA_68623_InvalidCustomerClass(custClass_Id.getIdValue()));
            }
        }
        
        super.extraSoftParameterValidations(forAlgorithmValidation);
    }

    @Override
    public Bool getWasFinancialProcessAdded() {
        return null;
    }

    @Override
    public void setFinancialTransaction(FinancialTransaction arg0) {
        ft = arg0;
    }

    @Override
    public void setFinancialTransactionType(FinancialTransactionTypeLookup arg0) {
    }

    @Override
    public void setRegularFinancialTransaction(FinancialTransaction arg0) {
    }

}
