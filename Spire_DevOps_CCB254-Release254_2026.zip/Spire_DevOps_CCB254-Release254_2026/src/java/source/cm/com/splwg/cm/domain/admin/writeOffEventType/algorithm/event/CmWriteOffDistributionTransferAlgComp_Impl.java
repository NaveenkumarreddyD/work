/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPLWWDX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      NA0058. Initial Version.
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.                         
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.writeOffEventType.algorithm.event;

import java.math.BigInteger;
import java.sql.Connection;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmplwwdx;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.admin.writeOffEventType.algorithm.event.WriteOffEventTypeEventAlgorithmSpot;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffEvent;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.HibernateHelper;
import com.splwg.shared.common.ServerMessage;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = triggerDateOverrideDays, required = true, type = integer)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = heatingCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = heatingCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = eligibleSaTypesFeatureConfiguration, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = writeOffSaType, required = true, type = string)})
 */
public class CmWriteOffDistributionTransferAlgComp_Impl extends
		CmWriteOffDistributionTransferAlgComp_Gen implements
		WriteOffEventTypeEventAlgorithmSpot {

	
	// hard parameters
	private Account account;
	private WriteOffEvent event;
	
	// soft parameters
	private BigInteger triggerDateOverrideDays;
	private CharacteristicType heatingCharType;
	private String  heatingCharValue;
	private FeatureConfiguration eligibleSaTypesFeatureConfiguration;
	private String writeOffSaType;
	
	private Cmplwwdx cmplwwdx;
	
	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	
	@Override
	public void setAccount(Account arg0) {
		account = arg0;
	}

	@Override
	public void setWriteOffEvent(WriteOffEvent arg0) {
		event = arg0;
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		
		triggerDateOverrideDays = getTriggerDateOverrideDays();
		heatingCharType = getHeatingCharType();
		heatingCharValue = getHeatingCharValue();
		eligibleSaTypesFeatureConfiguration = getEligibleSaTypesFeatureConfiguration();
		writeOffSaType = getWriteOffSaType();
		
	}

	@Override
	public void invoke() {
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			if (notNull(event) && notNull(event.getId())) {
				if (notNull(event.getId().getWriteOffProcessId())) {
					cmplwwdx.setInputWrkWoProcId(event.getId().getWriteOffProcessId().getTrimmedValue());
				}else{
					cmplwwdx.setInputWrkWoProcId(CobolCode.SPACES.toString());
				}
				if (notNull(event.getId().getEventSequence())) {
					cmplwwdx.setInputWrkEvtSeq(java.math.BigDecimal.valueOf(event.getId().getEventSequence().doubleValue()));
				}else{
					cmplwwdx.setInputWrkEvtSeq(java.math.BigDecimal.ZERO);
				}
			}
			
			if (notNull(account)) {
				cmplwwdx.setInputWrkAcctId(account.getId().getTrimmedValue());
			}else{
				cmplwwdx.setInputWrkAcctId(CobolCode.SPACES.toString());
			}
			
			cmplwwdx.setAlgParmVal(1, triggerDateOverrideDays.toString()); 
			cmplwwdx.setAlgParmVal(2, heatingCharType.getId().getTrimmedValue()); 
			cmplwwdx.setAlgParmVal(3, heatingCharValue.trim());
			cmplwwdx.setAlgParmVal(4, eligibleSaTypesFeatureConfiguration.getId().getTrimmedValue());
			cmplwwdx.setAlgParmVal(5, writeOffSaType.trim());
			
			// invoke the main method
		    cmplwwdx.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
		    
		    while(ex.getCause()!=null) ex=ex.getCause();
		    
		    if(ex instanceof Stop) {
		    	if (cmplwwdx.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmplwwdx.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmplwwdx.getMessageParm(i);
			    			if (notBlank(cmplwwdx.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmplwwdx.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmplwwdx.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmplwwdx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmplwwdx.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}		    			    		    		    	
		    }
		    else {
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmplwwdx=Session.returnSessionAndCodeToCache(cmplwwdx);
		}

	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
		FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
		RequestContext context = session.getRequestContext();
		 
		@SuppressWarnings("deprecation")
		Connection connection = HibernateHelper.getConnection(session.getHibernateSession());
		
		String username = connection.getMetaData().getUserName();
		String url = connection.getMetaData().getURL();
		
		CobolSession.setLogSessionStartEnd(false);
		
	    cmplwwdx=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmplwwdx.class);		
		cmplwwdx.getSession().getDbSession().setUpdateConnection(connection);
		
		// set ZSTAT parameters

		cmplwwdx.setProcessDt(getProcessDateTime().getDate().toString());
		cmplwwdx.setProcessDttmSep("-");
		cmplwwdx.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
		
		if (session.isOnlineConnection()) { 
			cmplwwdx.setConnectionFlg(CONNECTION_ONLINE);
		}
		else {
			cmplwwdx.setConnectionFlg(CONNECTION_BATCH);
		}
		
		cmplwwdx.setUserId(context.getUserId());
		cmplwwdx.setZstatLanguageCd(context.getLanguageCode());
        
        if (context.ignoreWarnings()) {
        	cmplwwdx.setIgnoreWarningSw(SWITCH_YES);
        }
        else {
        	cmplwwdx.setIgnoreWarningSw(SWITCH_NO);
        }
        
        if (session.getBatchInstanceId() != null) {
        	cmplwwdx.setSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
        	
		} else {
			cmplwwdx.setSchedulerId(new BigDecimal(0).toBigDecimal());
		}
        
        cmplwwdx.setAppSvcId(context.getSecurityServiceIdContext());
        
        DatabaseHelper dbHelper = session.getDatabaseHelper();
        cmplwwdx.setDbMode(dbHelper.getCobolDBMode());
        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
        //cmplwwdx.setSplHighValue(cmplwwdx.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
        //cmplwwdx.setSplLowValue(cmplwwdx.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
        
        cmplwwdx.setSplHighValue(cmplwwdx.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
        cmplwwdx.setSplLowValue(cmplwwdx.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
        // CCB v2.6 Upgrade - 2018-05-31 - End Change
        
        cmplwwdx.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
        
        cmplwwdx.setLkExpiryDt(Date.MAX.toString());
        
        cmplwwdx.setProgramStatus(" ");
        
        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
        cmplwwdx.setCallSeq(";");
        cmplwwdx.setMessageAreaProgramName("CMPLWWDX");
        // CCB v2.6 Upgrade - 2018-08-02 - End Add
        
        if (context.getRandomGeneratorSeedSet().isTrue()) {
        	cmplwwdx.setRandomGenSeedSw(SWITCH_YES);
        	cmplwwdx.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
        	cmplwwdx.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
        	cmplwwdx.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
        	cmplwwdx.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
        }
        else {
        	cmplwwdx.setRandomGenSeedSw(SWITCH_NO);
        }
        
        if (context.traceStandardOut()) { 
        	cmplwwdx.setTrcStdoutSw(SWITCH_YES);
        }
        else {
        	cmplwwdx.setTrcStdoutSw(SWITCH_NO);
        }
        
        if (context.traceProgramStart()) { 
        	cmplwwdx.setTrcProgStartSw(SWITCH_YES);
        }
        else {
        	cmplwwdx.setTrcProgStartSw(SWITCH_NO);
        }
        
        if (context.traceProgramExit()) { 
        	cmplwwdx.setTrcProgExitSw(SWITCH_YES);
        }
        else {
        	cmplwwdx.setTrcProgExitSw(SWITCH_NO);
        }
        
        if (context.traceSQL()) { 
        	cmplwwdx.setTrcExecSqlSw(SWITCH_YES);
        }
        else {
        	cmplwwdx.setTrcExecSqlSw(SWITCH_NO);
        }
        
        // Set ZMSGN parms
        BigInteger messageSequence = session.getMessageSequence();
        if (notNull(messageSequence)) {
        	cmplwwdx.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
        }
        else {
        	cmplwwdx.setMessageSeq(new BigDecimal(0).toBigDecimal());
        }

	}

}
