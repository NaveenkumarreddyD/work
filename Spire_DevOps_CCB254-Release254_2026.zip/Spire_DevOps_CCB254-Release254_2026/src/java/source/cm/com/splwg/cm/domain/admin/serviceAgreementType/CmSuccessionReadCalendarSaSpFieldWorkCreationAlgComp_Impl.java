/* *************************************************************************************************
 * PROGRAM DESCRIPTION
 *
 * MGE-CCB010 - Succession Read Calendar SA/SP Field Work Creation Algorithm
 *
 * Description
 *
 * This algorithm creates Field Activities for Pending Start and Pending Stop Service Agreements.
 * It is a functional clone to the existing base SA/SP FW CRE algorithm type (CIPCSFWX), except
 * that it checks for the next schedule read date or the permissible succession read days from the
 * Succession Read Calendar. In addition, it creates an ITRON read request row on
 * MR Download Staging.
 *
 ***************************************************************************************************
 *
 * CHANGE HISTORY
 *
 * Date:        by:       Reason:
 * YYYY-MM-DD   IN        Reason text.
 *
 * 2015-04-28   BMarquez  MGE-CCB010. Initial version.
 * 2015-06-22	SMiran	  Defect 3237877.
 * 						  If any of the following are true, go to FA Type Profile
 * 							- SP Location of IN
 * 							- NOT SP Condition 30
 * 							- Not AMR
 * 						  For any of the following, perform Succession Read Logic
 * 							- SP Location of OUT
 * 							- SP Condition 30
 * 							- AMR
 * 						  Also added new algorithm parameter to determine whether to use
 * 						  Start/Stop Non AMR Customer Event
 * 2015-06-25	SMiran	  Defect 3241668.
 * 						  Get isFaCreated value from base routine when attempting to create FA via
 * 						  FA Type profile.
 * 2015-07-17   SMiran	  Defect 3250440. Fixed linking of FA to back-to-back SAs
 * 2015-09-17   SMiran	  Defect 3296586.
 * 						  	- Support either I-READ or M-READ field activities.
 * 						  	- Use FA Type profile when stopping service at SP with an inside meter.
 * 						  	- Added soft parameter for Dispatchable FA Type for Meter Read
 * 2015-09-22   SMiran    Defect 3296586.
 * 							- Before creating I-READ for succession, confirm that
 * 							a succession territory exists for the town code/grid code combination.
 * 							If no territory is found, create dispatchable FA using dispatchable FA
 * 							Type for Meter Read.
 * 							- Added soft parameter for Grid Code Geographic Type
 * 2016-01-26   MPang	  Updated for CCB v2.4 compilation.
 * 2017-04-11   90930	  Commercial successions need to go to AMR Truck.
 * 2023-03-29   Kiran       	Ignore this alg for ADDP Route
 * 2024-11-22	IReyes	  E-09691/B-35293. When a service is being started, create a Turn on (M-ON)
 * 						  FA when the difference between the SA/SP stop and start activity is 
 * 						  greater than the back to back threshold parameter. This is to ensure new 
 * 						  customer's service will not be left off and the possible manual  
 * 						  cancellation of M-STOP FA which can put the pending stop SA to active and 
 * 						  having multiple active SA at some point. 	
 **************************************************************************************************/

package com.splwg.cm.domain.admin.serviceAgreementType;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;








import weblogic.utils.classfile.expr.NotNullCondExpression;







//2015-09-22. SMiran. Defect 3296586. Start Add
import com.splwg.base.api.ListFilter;
//2015-09-22. SMiran. Defect 3296586. End Add
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.DayOfWeek;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.workCalendar.WorkCalendar;
import com.splwg.ccb.api.lookup.FieldActivityCreatedByLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.FieldOrderStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementSpFaTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointFieldConditionLookup;
//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType;
import com.splwg.ccb.domain.admin.meterLocation.MeterLocation;
import com.splwg.ccb.domain.admin.meterLocation.MeterLocation_Id;
import com.splwg.ccb.domain.admin.meterReadCycle.MeterReadCycle;
import com.splwg.ccb.domain.admin.meterReadCycle.MeterReadRoute;
import com.splwg.ccb.domain.admin.meterReadRouteType.MeterReadRouteType;
import com.splwg.ccb.domain.admin.meterReadRouteType.MeterReadRouteType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.SaTypeSaSpFieldWorkCreationAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.customerinfo.premise.Premise;
import com.splwg.ccb.domain.customerinfo.premise.PremiseCharacteristic;
//2015-09-22. SMiran. Defect 3296586. Start Add
import com.splwg.ccb.domain.customerinfo.premise.PremiseGeographicLocation;
//2015-09-22. SMiran. Defect 3296586. End Add
import com.splwg.ccb.domain.customerinfo.serviceAgreement.SaSpFieldActivityCreatorData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementSpFieldActivity_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementSpFieldActivity_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
// 2015-06-22. SMiran. Defect 3237877. Start Add
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePointCharacteristic;
// 2015-06-22. SMiran. Defect 3237877. End Add
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_DTO;
import com.splwg.cm.api.lookup.CustomerEventLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmCancelUnlinkFasOfSaSp;
import com.splwg.cm.domain.common.customBusinessComponent.CmCancelUnlinkFasOfSaSpData;*/

import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.meterLocation.entity.MeterLocation;
import com.splwg.ccb.domain.admin.meterLocation.entity.MeterLocation_Id;
import com.splwg.ccb.domain.admin.meterReadCycle.entity.MeterReadCycle;
import com.splwg.ccb.domain.admin.meterReadCycle.entity.MeterReadRoute;
import com.splwg.ccb.domain.admin.meterReadCycle.entity.MeterReadRoute_Id;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saSpFieldWorkCreation.SaTypeSaSpFieldWorkCreationAlgorithmSpot;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType ;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseGeographicLocation;
import com.splwg.ccb.domain.customerinfo.data.SaSpFieldActivityCreatorData ;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.cm.api.lookup.CustomerEventLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmCancelUnlinkFasOfSaSp;
import com.splwg.cm.domain.common.customBusinessComponent.CmCancelUnlinkFasOfSaSpData;
//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
//2015-09-22. SMiran. Defect 3296586. Start Add
import com.splwg.cm.domain.meterread.meterRead.CmAmrSegment;
import com.splwg.cm.domain.meterread.meterRead.CmAmrSegment_Id;
//2015-09-22. SMiran. Defect 3296586. End Add
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

// 2015-06-22. SMiran. Defect 3237877. Start Change
///**
// * @author 90725
// *
// @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = numberOfDaysLeadTime, required = true, type = integer)
// *            , @AlgorithmSoftParameter (name = backToBackThresholdDays, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = nonDispatchableFieldActivityTypeForMeterRead, required = true, type = entity)
// *            , @AlgorithmSoftParameter (lookupName = servicePointFieldCondition, name = spsDesiredStateForMeterRead, required = true, type = lookup)
// *            , @AlgorithmSoftParameter (name = excludeRouteTypes, type = string)
// *            , @AlgorithmSoftParameter (name = excludeMeterLocations, type = string)
// *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = dispatchableFieldActivityTypeForMeterRead, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = readSourceFaCharacteristicType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = townCodePremiseCharacteristicType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = scheduledRouteReadSourceCharacteristicValue, required = true, type = string)
// *            , @AlgorithmSoftParameter (name = successionReadSourceCharacteristicValue, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = serviceTaskType, name = successionReadCalendarServiceTaskType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = immediateFaCreation, required = true, type = boolean)})
// */
/**
 * @author 90725
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = numberOfDaysLeadTime, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = backToBackThresholdDays, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = nonDispatchableFieldActivityTypeForMeterRead, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = servicePointFieldCondition, name = spsDesiredStateForMeterRead, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (name = excludeRouteTypes, type = string)
 *            , @AlgorithmSoftParameter (name = excludeMeterLocations, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = readSourceFaCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = townCodePremiseCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = scheduledRouteReadSourceCharacteristicValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = successionReadSourceCharacteristicValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = serviceTaskType, name = successionReadCalendarServiceTaskType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = immediateFaCreation, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = powerStatusSpCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = truePowerStatusCharVal, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = dispatchableFieldActivityTypeForMeterRead, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = geographicType, name = gridCodeGeographicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = alwaysUseFaProfile, type = string)
 *            , @AlgorithmSoftParameter (name = excludeLogicForRouteTypes, type = string)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = turnOnMeterFieldActivityType, type = entity)})
 *
 */
//2015-06-22. SMiran. Defect 3237877. End Change

public class CmSuccessionReadCalendarSaSpFieldWorkCreationAlgComp_Impl extends
        CmSuccessionReadCalendarSaSpFieldWorkCreationAlgComp_Gen implements
        SaTypeSaSpFieldWorkCreationAlgorithmSpot {

	private static final Logger logger= LoggerFactory.getLogger(CmSuccessionReadCalendarSaSpFieldWorkCreationAlgComp_Impl.class);    
	
    // Constants
    private static final String COMMA_DELIMITER = ",";
    private static final String NEVER_CREATE_SINGLE_FA = "N";
    private static final String insideMeterLoc = "IN";
    // Soft parameters
    private Bool neverCreateSingleFieldActivity = Bool.FALSE;
    private BigInteger backToBackThresholdDays;
    private CharacteristicValue scheduledReadSource;
    private CharacteristicValue successionReadSource;
    private List<MeterReadRouteType> excludedMeterReadRouteTypesList = new ArrayList<MeterReadRouteType>();
    private List<MeterLocation> excludedMeterLocationsList = new ArrayList<MeterLocation>();
    private Map<String, TownSchedule> successionReadCalendar;
    private Bool immediateFaCreation;
    private Bool isAddp = Bool.FALSE;
    // 2015-06-22. SMiran. Defect 3237877. Start Add
    private CharacteristicValue truePowerStatusCharVal;
 // 2015-06-22. SMiran. Defect 3237877. End Add
 // 2017-04-11. 90930. Defect 65464. Start Add
    private String alwaysUseFaProfile;
    // 2017-04-11. 90930. Defect 65464. End Add
    // 2015-09-17. SMiran. Defect 3296586. Start Add
    private Map<String, Bool> townCodeDispatch;
    // 2015-09-17. SMiran. Defect 3296586. End Add
    private List<MeterReadRouteType> excludedLogicMeterReadRouteTypesList = new ArrayList<MeterReadRouteType>();
    /** Stores the validity of a Meter Read on specific days of the week. */
    private class TownSchedule extends HashMap<DayOfWeek, Bool> {

        private static final long serialVersionUID = 1L;

        public TownSchedule(Bool monday, Bool tuesday, Bool wednesday, Bool thursday, Bool friday, Bool saturday, Bool sunday) {
            super();
            put(DayOfWeek.MONDAY, monday);
            put(DayOfWeek.TUESDAY, tuesday);
            put(DayOfWeek.WEDNESDAY, wednesday);
            put(DayOfWeek.THURSDAY, thursday);
            put(DayOfWeek.FRIDAY, friday);
            put(DayOfWeek.SATURDAY, saturday);
            put(DayOfWeek.SUNDAY, sunday);
        }

        public boolean isSuccessionReadDay(Date date) {

            return get(date.getDayOfWeek()).isTrue();

        }

        public String validDays() {

            StringBuilder stringBuilder = new StringBuilder();

            if (get(DayOfWeek.MONDAY).isTrue()) {
                stringBuilder.append(DayOfWeek.MONDAY.toLocalizedString());
            }

            if (get(DayOfWeek.TUESDAY).isTrue()) {
                if (stringBuilder.length() > 0) {
                    stringBuilder.append(", ");
                }
                stringBuilder.append(DayOfWeek.TUESDAY.toLocalizedString());
            }

            if (get(DayOfWeek.WEDNESDAY).isTrue()) {
                if (stringBuilder.length() > 0) {
                    stringBuilder.append(", ");
                }
                stringBuilder.append(DayOfWeek.WEDNESDAY.toLocalizedString());
            }

            if (get(DayOfWeek.THURSDAY).isTrue()) {
                if (stringBuilder.length() > 0) {
                    stringBuilder.append(", ");
                }
                stringBuilder.append(DayOfWeek.THURSDAY.toLocalizedString());
            }

            if (get(DayOfWeek.FRIDAY).isTrue()) {
                if (stringBuilder.length() > 0) {
                    stringBuilder.append(", ");
                }
                stringBuilder.append(DayOfWeek.FRIDAY.toLocalizedString());
            }

            if (get(DayOfWeek.SATURDAY).isTrue()) {
                if (stringBuilder.length() > 0) {
                    stringBuilder.append(", ");
                }
                stringBuilder.append(DayOfWeek.SATURDAY.toLocalizedString());
            }

            if (get(DayOfWeek.SUNDAY).isTrue()) {
                if (stringBuilder.length() > 0) {
                    stringBuilder.append(", ");
                }
                stringBuilder.append(DayOfWeek.SUNDAY.toLocalizedString());
            }

            return stringBuilder.toString();

        }

    }

    // Hard parameters - input
    private ServiceAgreementSpFaTypeLookup saSpFieldActivityType;
    private DateTime saSpStartDateTime;
    private DateTime saSpStopDateTime;
    @SuppressWarnings("unused")
	private Date saStartDate;
    @SuppressWarnings("unused")
	private Date saStopDate;
    private ServiceAgreement serviceAgreement;
    private ServiceAgreementServicePoint serviceAgreementServicePoint;
    private ServicePoint servicePoint;
    private Bool shouldActivateManually;

    // Hard parameters - input/output
    private Bool isFaCreated;

    // Working variables
    private Bool isBackToBack = Bool.FALSE;
    private DateTime leastStopDateTime;
    private DateTime scheduleDateTime;

    // Common component
    private CmCancelUnlinkFasOfSaSp cancelUnlinkFasOfSaSp = CmCancelUnlinkFasOfSaSp.Factory.newInstance();

    public void setSaSpFieldActivityType(ServiceAgreementSpFaTypeLookup saSpFieldActivityType) {
        this.saSpFieldActivityType = saSpFieldActivityType;
    }

    public void setSaSpStartDateTime(DateTime saSpStartDateTime) {
        this.saSpStartDateTime = saSpStartDateTime;
    }

    public void setSaSpStopDateTime(DateTime saSpStopDateTime) {
        this.saSpStopDateTime = saSpStopDateTime;
    }

    public void setSaStartDate(Date saStartDate) {
        this.saStartDate = saStartDate;
    }

    public void setSaStopDate(Date saStopDate) {
        this.saStopDate = saStopDate;
    }

    public void setServiceAgreement(ServiceAgreement serviceAgreement) {
        this.serviceAgreement = serviceAgreement;
    }

    public void setServiceAgreementServicePoint(ServiceAgreementServicePoint serviceAgreementServicePoint) {
        this.serviceAgreementServicePoint = serviceAgreementServicePoint;
    }

    public void setServicePoint(ServicePoint servicePoint) {
        this.servicePoint = servicePoint;
    }

    public void setShouldActivateManually(Bool shouldActivateManually) {
        this.shouldActivateManually = shouldActivateManually;
    }

    public void setFaCreated(Bool isFaCreated) {
        this.isFaCreated = isFaCreated;
    }

    public Bool getIsFaCreated() {
        return this.isFaCreated;
    }

    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

        String excludeLogicForRouteTypes = getExcludeLogicForRouteTypes();
        if (notBlank(excludeLogicForRouteTypes)) {

            String[] excludeLogicForRouteTypesList = excludeLogicForRouteTypes.split(COMMA_DELIMITER);

            for (String excludeLogicMeterReadRouteTypeIdString : excludeLogicForRouteTypesList) {

                if (excludeLogicMeterReadRouteTypeIdString.trim().length() > MeterReadRouteType_Id.FIELD_SIZE) {
                    addError(CustomMessageRepositorySpireOne.CCB108_InvalidRouteType(
                    		excludeLogicMeterReadRouteTypeIdString, getAlgorithm()));
                }

                MeterReadRouteType_Id meterReadRouteTypeId = new MeterReadRouteType_Id(excludeLogicMeterReadRouteTypeIdString.trim());
                if (isNull(meterReadRouteTypeId.getEntity())) {
                    addError(CustomMessageRepositorySpireOne.CCB108_InvalidRouteType(
                    		excludeLogicMeterReadRouteTypeIdString, getAlgorithm()));
                }

                excludedLogicMeterReadRouteTypesList.add(meterReadRouteTypeId.getEntity());
            }
        }
        

        String excludeMeterLocations = getExcludeMeterLocations();
        if (notBlank(excludeMeterLocations)) {

            String[] excludeMeterLocationList = excludeMeterLocations.split(COMMA_DELIMITER);

            for (String excludedMeterLocationIdString : excludeMeterLocationList) {

                if (excludedMeterLocationIdString.trim().length() > MeterLocation_Id.FIELD_SIZE) {
                    addError(CustomMessageRepositoryMGE.ccb010_1_InvalidMeterLocation(excludedMeterLocationIdString, getAlgorithm()));
                }

                MeterLocation_Id meterLocationId = new MeterLocation_Id(excludedMeterLocationIdString.trim());
                if (isNull(meterLocationId.getEntity())) {
                    addError(CustomMessageRepositoryMGE.ccb010_1_InvalidMeterLocation(excludedMeterLocationIdString, getAlgorithm()));
                }

                excludedMeterLocationsList.add(meterLocationId.getEntity());

            }

        }

        // Back to Back Threshold Days parameter can either be a string value "N" or an integer
        String backToBackThresholdDaysString = getBackToBackThresholdDays();
        if (NEVER_CREATE_SINGLE_FA.equals(backToBackThresholdDaysString.trim())) {
            neverCreateSingleFieldActivity = Bool.TRUE;
        } else {
            try {
                backToBackThresholdDays = BigInteger.valueOf(Integer.parseInt(backToBackThresholdDaysString));
            } catch (NumberFormatException e) {
                addError(CustomMessageRepositoryMGE.ccb010_1_InvalidB2bThresholdDays(NEVER_CREATE_SINGLE_FA, getAlgorithm()));
            }
        }

        // Read Source FA Characteristic Type must be predefined
        if (!getReadSourceFaCharacteristicType().getCharacteristicType().isPredefinedValue()) {
            addError(CustomMessageRepositoryMGE.ccb010_1_ReadSourceFaCharacteristicNotPredefined(getAlgorithm()));
        }

        // Succession and Scheduled Read Source must be valid on the Read Source FA Characteristic Type
        String scheduledReadSourceCharacteristicValueString = getScheduledRouteReadSourceCharacteristicValue();
        if (scheduledReadSourceCharacteristicValueString.length() > CharacteristicValue.properties.characteristicValue.getMaxLength()) {
            addError(CustomMessageRepositoryMGE.ccb010_1_InvalidScheduledReadSource(getReadSourceFaCharacteristicType(), getAlgorithm()));
        }

        CharacteristicValue_Id scheduledCharacteristicValueId = new CharacteristicValue_Id(getReadSourceFaCharacteristicType()
        		, scheduledReadSourceCharacteristicValueString);
        if (isNull(scheduledCharacteristicValueId.getEntity())) {
            addError(CustomMessageRepositoryMGE.ccb010_1_InvalidScheduledReadSource(getReadSourceFaCharacteristicType(), getAlgorithm()));
        }

        scheduledReadSource = scheduledCharacteristicValueId.getEntity();

        String successionReadSourceCharacteristicValueString = getSuccessionReadSourceCharacteristicValue();
        if (successionReadSourceCharacteristicValueString.length() > CharacteristicValue.properties.characteristicValue.getMaxLength()) {
            addError(CustomMessageRepositoryMGE.ccb010_1_InvalidSuccessionReadSource(getReadSourceFaCharacteristicType(), getAlgorithm()));
        }

        CharacteristicValue_Id successionCharacteristicValueId = new CharacteristicValue_Id(getReadSourceFaCharacteristicType()
        		, successionReadSourceCharacteristicValueString);
        if (isNull(successionCharacteristicValueId.getEntity())) {
            addError(CustomMessageRepositoryMGE.ccb010_1_InvalidSuccessionReadSource(getReadSourceFaCharacteristicType(), getAlgorithm()));
        }

        successionReadSource = successionCharacteristicValueId.getEntity();

        immediateFaCreation = getImmediateFaCreation();

        // 2015-06-22. SMiran. Defect 3237877. Start Add
        CharacteristicValue_Id truePowerStatusCharValueId = new CharacteristicValue_Id(getPowerStatusSpCharType()
        		, getTruePowerStatusCharVal());
        if (isNull(truePowerStatusCharValueId.getEntity())){
        	addError(CustomMessageRepositoryMGE.ccb010_1_invalidPowerStatus(getPowerStatusSpCharType().getId().getTrimmedValue(), getAlgorithm()));
        }
        truePowerStatusCharVal = truePowerStatusCharValueId.getEntity();
        // 2015-06-22. SMiran. Defect 3237877. End Add
     // 2017-04-11. 90930. Defect 65464. Start Add
        alwaysUseFaProfile = getAlwaysUseFaProfile();
     // 2017-04-11. 90930. Defect 65464. End Add
        super.extraSoftParameterValidations(forAlgorithmValidation);

    }

    /**
     * GA000
     */
    public void invoke() {

    	// 03-23-2023 Kiran Begin exit for the ADDP Route type
    	logger.info(">>>>> 496" + servicePoint.fetchMeterLocation().getId().getIdValue());
    	MeterReadRoute meterReadRoute = servicePoint.fetchMeterReadRoute();
    	
    	if (notNull(meterReadRoute)
                && excludedLogicMeterReadRouteTypesList.contains(meterReadRoute.getMeterReadRouteType()))
    		{
    	if (servicePoint.fetchMeterLocation().getId().getIdValue().trim().equals(insideMeterLoc))
    			{
    		logger.info(">>>>> 504" + servicePoint.fetchMeterLocation().getId().getIdValue());
    			}
    	else
    		if(servicePoint.getServicePointSourceStatus().isDisconnected())
			{
				// if disconnected and not inside then continue otherwise halt
			}
    		else	
    		{
    		logger.info(">>>>> 508" + servicePoint.fetchMeterLocation().getId().getIdValue());
    		logger.info(">>>>> 509" + insideMeterLoc);
    		return;
    		}
    		
    	}
    		
        // 03-23-2023 Kiran End
    	
    	logger.info(">>>>> 516" + servicePoint.fetchMeterLocation().getId().getIdValue());
    	// Decide if it is time to create the FA
        decideIfTooEarly();
        logger.info(">>>>> 519" + servicePoint.fetchMeterLocation().getId().getIdValue());
        // Process the pending start/stop SA/SP for the SP
        checkPendingStartStop();
        logger.info(">>>>> 522" + servicePoint.fetchMeterLocation().getId().getIdValue());
        // Process the pending start/stop SA/SP for same SP type
        checkPendingStartStopForSameSpType();
        logger.info(">>>>> 525" + servicePoint.fetchMeterLocation().getId().getIdValue());
        // Determine if Back-To-Back situation exists
        checkForBackToBack();
        logger.info(">>>>> 528" + servicePoint.fetchMeterLocation().getId().getIdValue());
        if (shouldActivateManually.isFalse()) {
        	logger.info(">>>>> 530" + servicePoint.fetchMeterLocation().getId().getIdValue());
            // Create Field Activity and Field Activity Steps for SA/SP
            processServiceAgreementServicePoint();

            // Link newly created pending Field Activity
            processFieldActivity();

        } else {
        	logger.info(">>>>> 538" + servicePoint.fetchMeterLocation().getId().getIdValue());
        	if (immediateFaCreation.isTrue()){
        		logger.info(">>>>> 540" + servicePoint.fetchMeterLocation().getId().getIdValue());
                processServiceAgreementServicePoint();
                processFieldActivity();

        	}else{

                if (saSpFieldActivityType.isStartActivity()
                        && saSpStartDateTime.getDate().isSameOrBefore(getProcessDateTime().getDate())) {

                    processServiceAgreementServicePoint();
                    processFieldActivity();

                }

                if (saSpFieldActivityType.isStopActivity()
                        && saSpStopDateTime.getDate().isSameOrBefore(getProcessDateTime().getDate())) {
                	logger.info(">>>>> 556" + servicePoint.fetchMeterLocation().getId().getIdValue());
                    processServiceAgreementServicePoint();
                    processFieldActivity();

                }

        	}

        }

    }

    /**
     * MA000 - If the Manual Activation switch is false and calculated days for START/STOP exceeds the Number of Days Lead Time,
     * it's too early for creating Field Activities.
     */
    private void decideIfTooEarly() {

        if (saSpFieldActivityType.isStartActivity()) {

            // Calculate Date Difference between SASP's Start Date and Business Date
            long startDays = saSpStartDateTime.getDate().difference(getProcessDateTime().getDate()).getDays();

            if (shouldActivateManually.isFalse()) {

                if (startDays > getNumberOfDaysLeadTime().longValue()) {
                    addError(CustomMessageRepositoryMGE.ccb010_1_TooEarlyForFa(serviceAgreement, servicePoint
                    		, getNumberOfDaysLeadTime(), getAlgorithm()));
                }

            }

        }

        if (saSpFieldActivityType.isStopActivity()) {

            // Calculate Date Difference between SA/SP's Stop Date and Business Date
            long stopDays = saSpStopDateTime.getDate().difference(getProcessDateTime().getDate()).getTotalDays();

            if (shouldActivateManually.isFalse()) {

                if (stopDays > getNumberOfDaysLeadTime().longValue()) {
                    addError(CustomMessageRepositoryMGE.ccb010_1_TooEarlyForFa(serviceAgreement, servicePoint
                    		, getNumberOfDaysLeadTime(), getAlgorithm()));
                }

            }

        }

    }

    /**
     * MC000
     */
    private void checkPendingStartStop() {

        // Do not cancel if creating 2 different FAs
        if (neverCreateSingleFieldActivity.isTrue()) {
            return;
        }

        // If FA Type is Start, determine if there is a Pending Stop, Pending Start or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the PAST of the Start Date that has a
        // Non-Dispatched Pending Field Activity for Stop
        if (saSpFieldActivityType.isStartActivity()) {

            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.negate().intValue());

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, start1Date, saSpStartDateTime.getDate()
            		, null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            if (!results.isEmpty()) {

                // Ensure only latest one is selected
                cancelUnlinkPendingFa(results.get(0), ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }

        }

        // If FA Type is Stop, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the FUTURE of the Stop Date that has a
        // Non-Dispatched Pending Field Activity for Start
        if (saSpFieldActivityType.isStopActivity()) {

            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date stop2Date = saSpStopDateTime.getDate().addDays(backToBackThresholdDays.intValue());

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, null, null, saSpStopDateTime.getDate()
            		, stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            for (ServiceAgreementServicePoint pendingSaSp : results) {
                cancelUnlinkPendingFa(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }

        }

    }

    /**
     * SQ010, SQ030
     * @param servicePoint
     * @param start1Date
     * @param start2Date
     * @param stop1Date
     * @param stop2Date
     * @param serviceAgreementSpFaTypeLookup
     * @return List&lt;ServiceAgreementServicePoint&gt;
     */
    private List<ServiceAgreementServicePoint> getPendingSaSp(ServicePoint servicePoint, Date start1Date, Date start2Date
    		, Date stop1Date, Date stop2Date, ServiceAgreementSpFaTypeLookup serviceAgreementSpFaTypeLookup) {

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "S2.STOP_DTTM, ");
        // Selected S2.START_DTTM instead of S2.SA_ID so that query can be used when searching for either Stop or Start
        stringBuilder.append(  "S2.START_DTTM, ");
        stringBuilder.append(  "S2.SA_SP_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA S1, ");
        stringBuilder.append(  "CI_SA_SP_DT_VW S2 ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "S2.SA_ID = S1.SA_ID ");
        stringBuilder.append("AND S2.SP_ID = :servicePoint ");
        stringBuilder.append("AND S1.SA_STATUS_FLG IN (:activeSaStatus , :pendingStopSaStatus, :pendingStartSaStatus) ");
        // Cater for either stop or start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_DT BETWEEN :start1Date AND :start2Date ");
        }
        // Cater for either stop or start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_DT BETWEEN :stop1Date AND :stop2Date ");
        }
        // Cater for either stop or start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_MR_ID = ' ' ");
        }
        // Cater for either stop or start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_MR_ID = ' ' ");
        }
        stringBuilder.append("AND EXISTS ( ");
        stringBuilder.append(  "SELECT ");
        stringBuilder.append(    "S3.FA_ID ");
        stringBuilder.append(  "FROM ");
        stringBuilder.append(    "CI_SA_SP_FA S3, ");
        stringBuilder.append(    "CI_FA F1 ");
        stringBuilder.append(  "WHERE ");
        stringBuilder.append(    "S3.SA_SP_ID = S2.SA_SP_ID ");
        stringBuilder.append(  "AND F1.FA_ID = S3.FA_ID ");
        stringBuilder.append(  "AND F1.FA_STATUS_FLG = :pendingFaStatus ");
        stringBuilder.append(  "AND S3.SA_SP_FA_TYPE_FLG = :saSpFaType ");
        stringBuilder.append(  "AND F1.FA_ID = S3.FA_ID ");
        stringBuilder.append(  "AND ( ");
        stringBuilder.append(    "F1.FO_ID = ' ' ");
        stringBuilder.append(      "OR EXISTS ( ");
        stringBuilder.append(        "SELECT ");
        stringBuilder.append(          "'X' ");
        stringBuilder.append(        "FROM ");
        stringBuilder.append(          "CI_FO FO ");
        stringBuilder.append(        "WHERE ");
        stringBuilder.append(          "F1.FO_ID = FO.FO_ID ");
        stringBuilder.append(        "AND FO.FO_STATUS_FLG = :pendingFoStatus ");
        stringBuilder.append(      ") ");
        stringBuilder.append(    ") ");
        stringBuilder.append(  ") ");
        stringBuilder.append("ORDER BY ");
        // Cater for either stop or start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append(  "S2.STOP_DTTM DESC ");
        }
        // Cater for either stop or start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append(  "S2.START_DTTM DESC ");
        }

        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindLookup("activeSaStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
        preparedStatement.bindLookup("pendingStopSaStatus", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        preparedStatement.bindLookup("pendingStartSaStatus", ServiceAgreementStatusLookup.constants.PENDING_START);
        if (notNull(start1Date) && notNull(start2Date)) {
            preparedStatement.bindDate("start1Date", start1Date);
            preparedStatement.bindDate("start2Date", start2Date);
        }
        if (notNull(stop1Date) && notNull(stop2Date)) {
            preparedStatement.bindDate("stop1Date", stop1Date);
            preparedStatement.bindDate("stop2Date", stop2Date);
        }
        preparedStatement.bindLookup("saSpFaType", serviceAgreementSpFaTypeLookup);
        preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);
        preparedStatement.bindLookup("pendingFoStatus", FieldOrderStatusLookup.constants.PENDEDBY_USER);

        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<ServiceAgreementServicePoint> serviceAgreementServicePointResults = new ArrayList<ServiceAgreementServicePoint>();
        for (SQLResultRow sqlResultRow : results) {
            serviceAgreementServicePointResults.add(sqlResultRow.getEntity("SA_SP_ID", ServiceAgreementServicePoint.class));
        }

        return serviceAgreementServicePointResults;

    }

    /**
     * MC060
     * @param serviceAgreementServicePoint
     * @param serviceAgreementSpFaType
     */
    private void cancelUnlinkPendingFa(ServiceAgreementServicePoint serviceAgreementServicePoint
    		, ServiceAgreementSpFaTypeLookup serviceAgreementSpFaType) {

        CmCancelUnlinkFasOfSaSpData data = CmCancelUnlinkFasOfSaSpData.Factory.newInstance();
        data.setServiceAgreementServicePoint(serviceAgreementServicePoint);
        data.setServiceAgreementSpFaType(serviceAgreementSpFaType);
        cancelUnlinkFasOfSaSp.cancelUnlinkFas(data);

    }

    /**
     * ME000
     */
    private void checkPendingStartStopForSameSpType() {

        // Do not cancel if creating 2 different FAs
        if (neverCreateSingleFieldActivity.isTrue()) {
            return;
        }

        // If FA Type is Start, determine if there is a Pending Stop, Pending Start or Active SA/SP for the SP
        // on the exact date as start date that has a Non-Dispatched Field Activity for Start
        if (saSpFieldActivityType.isStartActivity()) {

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, null, null
            		, saSpStartDateTime.getDate(), saSpStartDateTime.getDate(), ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            for (ServiceAgreementServicePoint pendingSaSp : results) {
                cancelUnlinkPendingFa(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }

        }

        // If FA Type is Stop, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // on the exact date as stop date that has a Non-Dispatched Pending Field Activity for Stop
        if (saSpFieldActivityType.isStopActivity()) {

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, saSpStopDateTime.getDate()
            		, saSpStopDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            for (ServiceAgreementServicePoint pendingSaSp : results) {
                cancelUnlinkPendingFa(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }

        }

    }

    /**
     * MG000
     *
     */
    private void checkForBackToBack() {

        // There is no need to check for back to back if creating separate FAs
        if (neverCreateSingleFieldActivity.isTrue()) {
            return;
        }

        // If FA Type is Start, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the Past of the Start Date
        // without Pending, Held or Completed Field Activity for Stop
        if (saSpFieldActivityType.isStartActivity()) {

            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.negate().intValue());

            List<ServiceAgreementServicePoint> results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
            		, start1Date, saSpStartDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);

            if (!results.isEmpty()) {

                // Assume back to back
                isBackToBack = Bool.TRUE;
                leastStopDateTime = results.get(0).getStopDateTime();

            }

        }

        // If FA Type is Stop, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the Future of the Stop Date
        // without Pending, Held or Completed Field Activity for Start
        if (saSpFieldActivityType.isStopActivity()) {

            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date stop2Date = saSpStopDateTime.getDate().addDays(backToBackThresholdDays.intValue());

            List<ServiceAgreementServicePoint> results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
            		, null, null, saSpStopDateTime.getDate(), stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);

            if (!results.isEmpty()) {

                // Assume back to back
                isBackToBack = Bool.TRUE;

            }

        }

    }

    /**
     * SQ050, SQ070
     * @param servicePoint
     * @param serviceAgreementServicePoint
     * @param start1Date
     * @param start2Date
     * @param stop1Date
     * @param stop2Date
     * @param serviceAgreementSpFaTypeLookup
     * @return List&lt;ServiceAgreementServicePoint&gt;
     */
    private List<ServiceAgreementServicePoint> getOtherSaSpFieldActivities(ServicePoint servicePoint
    		, ServiceAgreementServicePoint serviceAgreementServicePoint, Date start1Date, Date start2Date
    		, Date stop1Date, Date stop2Date, ServiceAgreementSpFaTypeLookup serviceAgreementSpFaTypeLookup) {

    	StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "S2.STOP_DTTM, ");
        // Selected S2.START_DTTM instead of S2.SA_ID so that query can be used when searching for either back-to-back Stop or back-to-back Start
        stringBuilder.append(  "S2.START_DTTM, ");
        stringBuilder.append(  "S2.SA_SP_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA S1, ");
        stringBuilder.append(  "CI_SA_SP_DT_VW S2 ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "S2.SA_ID = S1.SA_ID ");
        stringBuilder.append("AND S2.SP_ID = :servicePoint ");
        stringBuilder.append("AND S2.SA_SP_ID <> :serviceAgreementServicePoint ");
        stringBuilder.append("AND S1.SA_STATUS_FLG IN ");
        stringBuilder.append(  "( ");
        stringBuilder.append(    ":activeSaStatus, :pendingStopSaStatus, :pendingStartSaStatus");
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append(    ", :stoppedSaStatus");
        }
        stringBuilder.append(  ") ");
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_DT BETWEEN :start1Date AND :start2Date ");
        }
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_DT BETWEEN :stop1Date AND :stop2Date ");
        }
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_MR_ID = ' ' ");
        }
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_MR_ID = ' ' ");
        }
        stringBuilder.append("AND NOT EXISTS ");
        stringBuilder.append(  "( ");
        stringBuilder.append(    "SELECT ");
        stringBuilder.append(      "S3.FA_ID ");
        stringBuilder.append(    "FROM ");
        stringBuilder.append(      "CI_SA_SP_FA S3, ");
        stringBuilder.append(      "CI_FA F1 ");
        stringBuilder.append(    "WHERE ");
        stringBuilder.append(      "S3.SA_SP_ID = S2.SA_SP_ID ");
        stringBuilder.append(    "AND S3.SA_SP_FA_TYPE_FLG = :saSpFaType ");
        stringBuilder.append(    "AND F1.FA_ID = S3.FA_ID ");
        stringBuilder.append(    "AND F1.FA_STATUS_FLG IN (:heldFaStatus, :pendingFaStatus, :completedFaStatus) ");
        stringBuilder.append(  ") ");
        stringBuilder.append("ORDER BY ");
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append(  "S2.STOP_DTTM DESC ");
        }
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append(  "S2.START_DTTM DESC ");
        }

        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindId("serviceAgreementServicePoint", serviceAgreementServicePoint.getId());
        preparedStatement.bindLookup("activeSaStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
        preparedStatement.bindLookup("pendingStopSaStatus", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        preparedStatement.bindLookup("pendingStartSaStatus", ServiceAgreementStatusLookup.constants.PENDING_START);
        if (notNull(start1Date) && notNull(start2Date)) {
            preparedStatement.bindLookup("stoppedSaStatus", ServiceAgreementStatusLookup.constants.STOPPED);
        }
        if (notNull(start1Date) && notNull(start2Date)) {
            preparedStatement.bindDate("start1Date", start1Date);
            preparedStatement.bindDate("start2Date", start2Date);
        }
        if (notNull(stop1Date) && notNull(stop2Date)) {
            preparedStatement.bindDate("stop1Date", stop1Date);
            preparedStatement.bindDate("stop2Date", stop2Date);
        }
        preparedStatement.bindLookup("saSpFaType", serviceAgreementSpFaTypeLookup);
        preparedStatement.bindLookup("heldFaStatus", FieldActivityStatusLookup.constants.HELD);
        preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);
        preparedStatement.bindLookup("completedFaStatus", FieldActivityStatusLookup.constants.COMPLETED);

        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<ServiceAgreementServicePoint> serviceAgreementServicePointResults = new ArrayList<ServiceAgreementServicePoint>();
        for (SQLResultRow sqlResultRow : results) {
            serviceAgreementServicePointResults.add(sqlResultRow.getEntity("SA_SP_ID", ServiceAgreementServicePoint.class));
        }

        return serviceAgreementServicePointResults;

    }

    /**
     * MI000 -  Create FA based on SP condition in FA Profile
     * This is the section that was modified to cater for custom requirements for succession reads.
     */
    private void processServiceAgreementServicePoint() {
    	logger.info(">>>>> 984" + servicePoint.fetchMeterLocation().getId().getIdValue());
        // Retrieve information about the Service Point
        ServicePointFieldConditionLookup spCondition = servicePoint.determineFieldCondition();
        MeterReadRoute meterReadRoute = servicePoint.fetchMeterReadRoute();
        MeterReadRoute_Id meterReadRouteId = new MeterReadRoute_Id(servicePoint.getMeterReadCycleId(), servicePoint.getMeterReadRoute()); 
        
        scheduleDateTime = decideScheduleDateTime();
        logger.info(">>>>> 999" + isBackToBack);
        logger.info(">>>>> 984" + servicePoint.fetchMeterLocation().getId().getIdValue());
        logger.info(">>>>> 984" + meterReadRoute);
        logger.info(">>>>> 984" + meterReadRoute.getMeterReadRouteType());
        if ( isBackToBack.isTrue() && (servicePoint.fetchMeterLocation().getId().getIdValue().trim().equals(insideMeterLoc)) && (notNull(meterReadRouteId.getEntity()) 
        		&& excludedLogicMeterReadRouteTypesList.contains(meterReadRouteId.getEntity().getMeterReadRouteType())) )
        {
        	isAddp = Bool.TRUE;
        	//createFieldActivityAndLinkToSaSp_addp(getEstimatedReadFieldActivityType());
        }
         
        if (!spCondition.equals(getSpsDesiredStateForMeterRead())) {

            // If the SP's condition does not match the SP's desired State for Meter Read value
            createFieldActivityViaFieldActivityTypeProfile();

        } else if (notNull(meterReadRoute)
        		&& excludedMeterReadRouteTypesList.contains(meterReadRoute.getMeterReadRouteType())) {

        	// 2015-06-22. SMiran. Defect 3237877. Start Change
            //// If the SP's Route Type is in the Exclude Route Type list (not FA Type Profile because LGC uses M-Daily FA)
            //createDispatchableFieldActivity();
        	// If the SP's Route Type is in the Exclude Route Type List (this is not an AMR meter),
        	// create FA via FA Type profile
        	createFieldActivityViaFieldActivityTypeProfile();
        	// 2015-06-22. SMiran. Defect 3237877. End Change

        // 2015-09-17. SMiran. Defect 3296586. Start Change
        //} else if (notNull(servicePoint.fetchMeterLocation())
        		//&& excludedMeterLocationsList.contains(servicePoint.fetchMeterLocation())) {
        } else if (saSpFieldActivityType.isStopActivity()
        		&& notNull(servicePoint.fetchMeterLocation())
        		&& excludedMeterLocationsList.contains(servicePoint.fetchMeterLocation())) {
        // 2015-09-17. SMiran. Defect 3296586. End Change

        	// 2015-06-22. SMiran. Defect 3237877. Start Change
            //// If the SP's Meter Location is in the Exclude Meter Location list
            //createDispatchableFieldActivity();
        	// If the SP's Meter Location is in the Exclude Meter Location list, meaning Meter location is IN
        	// create FA via FA Type profile
        	createFieldActivityViaFieldActivityTypeProfile();
        	// 2015-06-22. SMiran. Defect 3237877. End Change

        // 2017-04-11. 90930. Defect 65464. Start Add
        }else if (saSpFieldActivityType.isStopActivity()
        		&& notNull(alwaysUseFaProfile)
        		&& alwaysUseFaProfile.trim().equalsIgnoreCase("Y")) {


        	// create FA via FA Type profile
        	createFieldActivityViaFieldActivityTypeProfile();

        	// 2015-04-11. 90930. Defect 65464. End Change

        } else if (dispatchableFAShouldBeCreated()){

        	// If Dispatch Read is true for the town code entry retrieved, then create a dispatchable FA using
        	// Dispatchable Field Activity Type for Meter Read parameter. Ensure that the necessary SAs are linked
        	// to the FA and exit the algorithm
        	createFieldActivityAndLinkToSaSp(getDispatchableFieldActivityTypeForMeterRead());

        // 2015-09-17. SMiran. Defect 3296586. End Add

        } else if (notNull(servicePoint.fetchMeterReadCycle())
        		&& checkMeterReadCycleSchedule(servicePoint.fetchMeterReadCycle(), scheduleDateTime.getDate())) {

            // If the Meter is scheduled to be read on the found Schedule Date
            createNonDispatchableFieldActivity(scheduledReadSource);

        } else {
            // Get the SP's premise
            Premise premise = servicePoint.getPremise();
            // Get the Premise Town Code
            PremiseCharacteristic premiseTownCodeCharacteristic = premise.getEffectiveCharacteristic(getTownCodePremiseCharacteristicType());
            // If a premise town code is not found, return an error
            if (isNull(premiseTownCodeCharacteristic)) {
                addError(CustomMessageRepositoryMGE.ccb010_1_PremiseMissingTown(premise, getTownCodePremiseCharacteristicType(), getAlgorithm()));
            }

            String townCode = "";
            CharacteristicTypeLookup townCodeCharacteristicTypeLookup = getTownCodePremiseCharacteristicType().getCharacteristicType();
            if (townCodeCharacteristicTypeLookup.isPredefinedValue()) {
                townCode = premiseTownCodeCharacteristic.getCharacteristicValue();
            } else if (townCodeCharacteristicTypeLookup.isForeignKeyValue()) {
                townCode = premiseTownCodeCharacteristic.getCharacteristicValueForeignKey1();
            } else {
                townCode = premiseTownCodeCharacteristic.getAdhocCharacteristicValue();
            }

            buildSuccessionReadCalendars();
            // Get calendar entry for the premise town code
            TownSchedule townSchedule = successionReadCalendar.get(townCode.trim());
            // If a calendar entry for the premise town code is not found, return an error
            if (isNull(townSchedule)) {
                addError(CustomMessageRepositoryMGE.ccb010_1_SuccessionCalendarMissingTown(getSuccessionReadCalendarServiceTaskType()
                		, premiseTownCodeCharacteristic.fetchCharacteristicValue(), getAlgorithm()));
            }

            // Display error message if Premise does not have CIS Division
            if (isNull(premise.fetchDivision())){
            	addError(CustomMessageRepositoryMGE.ccb010_1_PremiseCisDivisionMiss(premise.getId().getTrimmedValue(), getAlgorithm()));
            }

            // Get work calendar from Premise's CIS Division
            WorkCalendar workCalendar = premise.fetchDivision().getWorkCalendar();

            // Scheduled Date must be a business day
            if (!workCalendar.isBusinessDay(scheduleDateTime.getDate())) {
                addError(CustomMessageRepositoryMGE.ccb010_1_ScheduledDateNotBusinessDay(workCalendar, getAlgorithm()));
            }

            // Scheduled Date must fall on a Succession Read Day
            if (!townSchedule.isSuccessionReadDay(scheduleDateTime.getDate())) {
                String validWorkDays = townSchedule.validDays();
                if (validWorkDays.length() == 0) {
                    addError(CustomMessageRepositoryMGE.ccb010_1_NoValidWorkDaysForTown(getSuccessionReadCalendarServiceTaskType()
                    		, premiseTownCodeCharacteristic.fetchCharacteristicValue(), getAlgorithm()));
                }
                addError(CustomMessageRepositoryMGE.ccb010_1_ScheduledDateNotSuccessionReadDay(premiseTownCodeCharacteristic.fetchCharacteristicValue()
                		, validWorkDays));
            }

            // If the schedule date falls on a valid succession read day
        	// 2015-09-22. SMiran. Defect 3296586. Start Change
            // Get Premise Grid Code geographic value
            String gridCodeStr = "";

			// Raise error if premise does not have grid code
            //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilatio
			// ListFilter listFilter = premise.getGeographicLocations().createFilter("WHERE this.id.geographicType = :gridCodeGeoType ");
            ListFilter listFilter = premise.getGeographicLocations().
            		createFilter("WHERE this.id.geographicType = :gridCodeGeoType ", getClass().getName());
            //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilatio
			listFilter.bindEntity("gridCodeGeoType", getGridCodeGeographicType());
			PremiseGeographicLocation premGeoLoc = (PremiseGeographicLocation)listFilter.firstRow();

			if (isNull(premGeoLoc)){
				addError(CustomMessageRepositoryMGE.ccb010_3_premGridCodeMiss(premise.getId().getTrimmedValue()));
			}else{
				gridCodeStr = premGeoLoc.getGeographicValue().trim();
			}

			// Get succession territory from CM_AMR_SEGMENT table using the premise town code and premise grid code
			CmAmrSegment_Id cmAmrSegmentId = new CmAmrSegment_Id(townCode.trim(), gridCodeStr);

			// Create dispatchable FA if the town code and grid code does not exist in AMR Segment Table or if the combination does not have
			// Succession Territory
			CmAmrSegment cmAmrSegment = cmAmrSegmentId.getEntity();
			if (isNull(cmAmrSegment) || isNull(cmAmrSegment.getCmSuccessionTerritory()) || cmAmrSegment.getCmSuccessionTerritory().intValue() == 0){
				createFieldActivityAndLinkToSaSp(getDispatchableFieldActivityTypeForMeterRead());
			}else{
				//Start Change IReyes - E-09691/B-35293 - 2024-11-22
				//createNonDispatchableFieldActivity(successionReadSource);				
				if (notNull(getTurnOnMeterFieldActivityType())&& turnOnMeterFAShouldBeCreated(servicePoint)){
					createFieldActivityAndLinkToSaSp(getTurnOnMeterFieldActivityType());
				} else {
					createNonDispatchableFieldActivity(successionReadSource);
				}
				//End Change IReyes - E-09691/B-35293 - 2024-11-22
			}
            // 2015-09-22. SMiran. Defect 3296586. End Change

        }

    }

	// 2015-09-17. SMiran. Defect 3296586. Start Add
    private boolean dispatchableFAShouldBeCreated() {
    	logger.info(">>>>> 1140" + servicePoint.fetchMeterLocation().getId().getIdValue());
        // Get the SP's premise
        Premise premise = servicePoint.getPremise();
        // Get the Premise Town Code
        PremiseCharacteristic premiseTownCodeCharacteristic = premise.getEffectiveCharacteristic(getTownCodePremiseCharacteristicType());
        // If a premise town code is not found, return an error
        if (isNull(premiseTownCodeCharacteristic)) {
            addError(CustomMessageRepositoryMGE.ccb010_1_PremiseMissingTown(premise, getTownCodePremiseCharacteristicType(), getAlgorithm()));
        }

        String townCode = "";
        CharacteristicTypeLookup townCodeCharacteristicTypeLookup = getTownCodePremiseCharacteristicType().getCharacteristicType();
        if (townCodeCharacteristicTypeLookup.isPredefinedValue()) {
            townCode = premiseTownCodeCharacteristic.getCharacteristicValue();
        } else if (townCodeCharacteristicTypeLookup.isForeignKeyValue()) {
            townCode = premiseTownCodeCharacteristic.getCharacteristicValueForeignKey1();
        } else {
            townCode = premiseTownCodeCharacteristic.getAdhocCharacteristicValue();
        }

        // Build town code and dispatch read combination from Succession Calendar
        buildTownCodeDispatch();

        // Get calendar entry for the premise town code
        Bool isDispatchRead = townCodeDispatch.get(townCode.trim());

        // If a calendar entry for the premise town code is not found, return an error
        if (isNull(isDispatchRead)) {
            addError(CustomMessageRepositoryMGE.ccb010_1_SuccessionCalendarMissingTown(getSuccessionReadCalendarServiceTaskType()
            		, premiseTownCodeCharacteristic.fetchCharacteristicValue(), getAlgorithm()));
        }else{
            // Return true if Dispatch Read is true for the town code entry retrieved
        	if (isDispatchRead.isTrue()){
        		return true;
        	}
        }

		return false;
	}

    private void buildTownCodeDispatch() {

    	// Read the Succession Read Calendar from the Service Task Type
    	townCodeDispatch = new HashMap<String, Bool>();

        ServiceTaskType serviceTaskType = getSuccessionReadCalendarServiceTaskType();
        BusinessObjectInstance businessObjectInstance = BusinessObjectInstance.create(serviceTaskType.getBusinessObject());
        businessObjectInstance.set("serviceTaskType", serviceTaskType.getId().getTrimmedValue());
        businessObjectInstance = BusinessObjectDispatcher.read(businessObjectInstance);

        COTSInstanceList townScheduleList = businessObjectInstance.getGroup("calendarDetails").getGroup("townScheduleList").getList("townSchedule");
        Iterator<COTSInstanceListNode> iterator = townScheduleList.iterator();

        COTSInstanceListNode townSchedule;
        while (iterator.hasNext()) {

            townSchedule = iterator.next();
            townCodeDispatch.put(townSchedule.getString("townCode"), townSchedule.getBoolean("dispatchRead"));

        }

    }
    // 2015-09-17. SMiran. Defect 3296586. End Add

	/**
     * MI040
     * @return scheduleDateTime
     */
    private DateTime decideScheduleDateTime() {

    	// If it is START and there is no BACK-to-BACK situation then SCHED-DTTM will be set to START-DTTM,
    	// otherwise (i.e. BACK-to-BACK) it will be set to earliest STOP-DTTM among SA/SPs
        if (saSpFieldActivityType.isStartActivity() && isBackToBack.isTrue()) {

            return leastStopDateTime;

        }

        if (saSpFieldActivityType.isStartActivity() && isBackToBack.isFalse()) {

            return saSpStartDateTime;

        }

        // If it is STOP, SCHED-DTTM will be set to STOP-DTTM of SA/SP regardless of BACK-to-BACK situation
        if (saSpFieldActivityType.isStopActivity()) {

            return saSpStopDateTime;

        }

        return null;

    }

    /**
     * Checks if a Meter Read is already scheduled for the supplied date by the regular
     * Meter Read Schedule.
     * @param meterReadCycle
     * @param scheduledDate
     * @return TRUE, if Meter Read for Cycle already scheduled on date
     */
    private boolean checkMeterReadCycleSchedule(MeterReadCycle meterReadCycle, Date scheduleDate) {

    	StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "MR.MR_CYC_CD ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_MR_SCHED MR ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "MR.MR_CYC_CD = :meterCycle ");
        stringBuilder.append("AND MR.SCHED_READ_DT = :scheduledDate ");

        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        preparedStatement.bindId("meterCycle", meterReadCycle.getId());
        preparedStatement.bindDate("scheduledDate", scheduleDate);

        SQLResultRow sqlResultRow = preparedStatement.firstRow();

        preparedStatement.close();

        return notNull(sqlResultRow);

    }

    private void buildSuccessionReadCalendars() {

    	// Read the Succession Read Calendar from the Service Task Type
    	successionReadCalendar = new HashMap<String, TownSchedule>();

        ServiceTaskType serviceTaskType = getSuccessionReadCalendarServiceTaskType();
        BusinessObjectInstance businessObjectInstance = BusinessObjectInstance.create(serviceTaskType.getBusinessObject());
        businessObjectInstance.set("serviceTaskType", serviceTaskType.getId().getTrimmedValue());
        businessObjectInstance = BusinessObjectDispatcher.read(businessObjectInstance);

        COTSInstanceList townScheduleList = businessObjectInstance.getGroup("calendarDetails").getGroup("townScheduleList").getList("townSchedule");
        Iterator<COTSInstanceListNode> iterator = townScheduleList.iterator();

        COTSInstanceListNode townSchedule;
        while (iterator.hasNext()) {

            townSchedule = iterator.next();

            successionReadCalendar.put(townSchedule.getString("townCode"),
                    new TownSchedule(
                            townSchedule.getBoolean("monday"),
                            townSchedule.getBoolean("tuesday"),
                            townSchedule.getBoolean("wednesday"),
                            townSchedule.getBoolean("thursday"),
                            townSchedule.getBoolean("friday"),
                            townSchedule.getBoolean("saturday"),
                            townSchedule.getBoolean("sunday")));

        }

    }

    /**
     * PA130
     */
    private void createFieldActivityViaFieldActivityTypeProfile() {
    	logger.info(">>>>> 1304" + servicePoint.fetchMeterLocation().getId().getIdValue());
    	SaSpFieldActivityCreatorData data = SaSpFieldActivityCreatorData.Factory.newInstance();
        data.setServiceAgreementSpFaType(saSpFieldActivityType);
        data.setIsBackToBack(isBackToBack);
        if (saSpFieldActivityType.isStartActivity()){
        	data.setCustomerEvent(CustomerEventLookup.constants.START_SERVICE);
        }
        if (saSpFieldActivityType.isStopActivity()){
        	data.setCustomerEvent(CustomerEventLookup.constants.STOP_SERVICE);
        }
        if (isBackToBack.isTrue()){
        	// 2015-06-2015. SMiran. Defect 3237877. Start Change
        	//data.setCustomerEvent(CustomerEventLookup.constants.START_STOP);

        	// Check SP's Power status. If the Power Status is equal to Power Status Char Val, SP is an AMR SP so use
        	// Start/Stop Customer Event. Otherwise, if the Power Status on the SP is not equal to the Power Status
        	// Char Val or if the SP does not have a Power Status Characteristic, the SP is not an AMR SP so use
        	// Start/Stop Non-AMR Customer Event.
        	ServicePointCharacteristic spChar = servicePoint.getEffectiveCharacteristic(getPowerStatusSpCharType());

        	if (isNull(spChar)){
        		data.setCustomerEvent(CustomerEventLookup.constants.X_START_STOP_NON_A_M_R);
        	}else{
        		String powerStatusStr = "";
        		CharacteristicTypeLookup spCharType = getPowerStatusSpCharType().getCharacteristicType();
        		if (spCharType.isPredefinedValue()){
        			powerStatusStr = spChar.getCharacteristicValue();
        		}else if (spCharType.isForeignKeyValue()){
        			powerStatusStr = spChar.getCharacteristicValueForeignKey1();
        		}else{
        			powerStatusStr = spChar.getAdhocCharacteristicValue();
        		}
        		if (powerStatusStr.trim().equals(truePowerStatusCharVal.fetchIdCharacteristicValue().trim())){
        			data.setCustomerEvent(CustomerEventLookup.constants.START_STOP);
        		}else{
        			data.setCustomerEvent(CustomerEventLookup.constants.X_START_STOP_NON_A_M_R);
        		}
        	}
        	// 2015-06-2015. SMiran. Defect 3237877. End Change
        }
        data.setScheduledDateTime(scheduleDateTime);
        data.setFieldActivityCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);
        data.setIsFaCollectionRequired(Bool.FALSE);

        data = serviceAgreementServicePoint.addFieldActivity(data);

        // 2015-06-25. SMiran. Defect 3241668. Start Change
        //isFaCreated = Bool.TRUE;
        isFaCreated = data.getIsFaCreated();
        // 2015-06-25. SMiran. Defect 3241668. End Change

    }

    // 2015-06-22. SMiran. Defect 3237877. Start Delete
    //private void createDispatchableFieldActivity() {
    //
    //    createFieldActivityAndLinkToSaSp(getDispatchableFieldActivityTypeForMeterRead());
    //
    //}
    // 2015-06-22. SMiran. Defect 3237877. End Delete

    private FieldActivity createFieldActivityAndLinkToSaSp(FieldActivityType fieldActivityType) {
    	logger.info(">>>>> 1366" + servicePoint.fetchMeterLocation().getId().getIdValue());
    	
    	FieldActivityType faType = new FieldActivityType_Id("ADDPREAD").getEntity();
    	FieldActivity_DTO fieldActivityDTO = new FieldActivity_DTO();
        fieldActivityDTO.setServicePointId(servicePoint.getId());
        logger.info(">>>>> 1277" + isAddp);
    	if (isAddp.isTrue()){
    		fieldActivityDTO.setFieldActivityTypeId(faType.getId());
    	}
    	else
    	{
    		fieldActivityDTO.setFieldActivityTypeId(fieldActivityType.getId());
    	}
    	
    	//FieldActivity_DTO fieldActivityDTO = new FieldActivity_DTO();
      //  fieldActivityDTO.setServicePointId(servicePoint.getId());
       // fieldActivityDTO.setFieldActivityTypeId(fieldActivityType.getId());
        fieldActivityDTO.setScheduleDateTimeStart(scheduleDateTime);
        fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);

        FieldActivityCreatorData data = FieldActivityCreatorData.Factory.newInstance();
        data.setFaDTO(fieldActivityDTO);

        FieldActivity fieldActivity = FieldActivityCreator.Factory.newInstance().addFieldActivity(data);

        ServiceAgreementSpFieldActivity_DTO serviceAgreementSpFieldActivityDTO = new ServiceAgreementSpFieldActivity_DTO();
        serviceAgreementSpFieldActivityDTO.setFieldActivityType(saSpFieldActivityType);
        serviceAgreementSpFieldActivityDTO.setServiceAgreementId(serviceAgreementServicePoint.getServiceAgreement().getId());
        serviceAgreementSpFieldActivityDTO.setServicePointId(serviceAgreementServicePoint.getServicePoint().getId());
        serviceAgreementServicePoint.getServiceAgreementSpFieldActivities().add(serviceAgreementSpFieldActivityDTO, fieldActivity.getId());

        isFaCreated = Bool.TRUE;

        return fieldActivity;

    }

    private void createNonDispatchableFieldActivity(CharacteristicValue readSource) {
    	logger.info(">>>>> 1391" + servicePoint.fetchMeterLocation().getId().getIdValue());
    	FieldActivity fieldActivity = createFieldActivityAndLinkToSaSp(getNonDispatchableFieldActivityTypeForMeterRead());
        FieldActivityCharacteristic_DTO fieldActivityCharacteristicDTO = new FieldActivityCharacteristic_DTO();
        fieldActivityCharacteristicDTO.setCharacteristicValue(readSource.fetchIdCharacteristicValue());
        fieldActivity.getCharacteristics().add(fieldActivityCharacteristicDTO, readSource.fetchIdCharacteristicType().getId(), BigInteger.ONE);

    }

    /**
     * MM000 - Retrieve newly created Pending FAs of SA/SP and link to Back-to-Back SA/SPs
     */
    private void processFieldActivity() {
    	logger.info(">>>>> 1403" + servicePoint.fetchMeterLocation().getId().getIdValue());
        for (FieldActivity fieldActivity : getSaSpFas(serviceAgreementServicePoint)) {

            if (isBackToBack.isTrue()) {

                linkB2BSaSpFa(fieldActivity);
            }

            linkSameType(fieldActivity);

        }

    }

    /**
     * SQ090
     * @param serviceAgreementServicePoint
     * @return List&lt;FieldActivity&gt;
     */
    private List<FieldActivity> getSaSpFas(ServiceAgreementServicePoint serviceAgreementServicePoint) {

    	StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "SASPFA.FA_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA_SP_FA SASPFA, ");
        stringBuilder.append(  "CI_FA FA ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "SASPFA.SA_SP_ID = :saSpId ");
        stringBuilder.append(  "AND SASPFA.SA_SP_FA_TYPE_FLG = :saSpFaType ");
        stringBuilder.append(  "AND FA.FA_ID = SASPFA.FA_ID ");
        stringBuilder.append(  "AND FA.FA_STATUS_FLG = :pendingFaStatus ");

        //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        preparedStatement.bindId("saSpId", serviceAgreementServicePoint.getId());

        preparedStatement.bindLookup("saSpFaType", saSpFieldActivityType);
        preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);

        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<FieldActivity> fieldActivityResults = new ArrayList<FieldActivity>();
        for (SQLResultRow sqlResultRow : results) {
            fieldActivityResults.add(sqlResultRow.getEntity("FA_ID", FieldActivity.class));
        }

        return fieldActivityResults;

    }

    /**
     * MM020 - Link the Field Activity to the Pending Start and Pending Stop SA/SPs.
     * @param fieldActivity
     */
    private void linkB2BSaSpFa(FieldActivity fieldActivity) {

    	if (saSpFieldActivityType.isStartActivity()) {

            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.negate().intValue());

            for (ServiceAgreementServicePoint pendingStopSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
            		// 2015-07-17. SMiran. Defect 3250440. Start Change
            		//, start1Date, saSpStartDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY)) {
            		, start1Date, saSpStartDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY)) {
            		// 2015-07-17. SMiran. Defect 3250440. End Change

                createSaSpFa(pendingStopSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);

            }

        }

        if (saSpFieldActivityType.isStopActivity()) {
        	logger.info(">>>>> 1482" + servicePoint.fetchMeterLocation().getId().getIdValue());
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date stop2Date = saSpStopDateTime.getDate().addDays(backToBackThresholdDays.intValue());

            for (ServiceAgreementServicePoint pendingStartSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
            		// 2015-07-17. SMiran. Defect 3250440. Start Change
            		//, null, null, saSpStopDateTime.getDate(), stop2Date, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY)) {
            		, null, null, saSpStopDateTime.getDate(), stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY)) {
        			// 2015-07-17. SMiran. Defect 3250440. End Change

            	createSaSpFa(pendingStartSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);

            }

        }

    }

    /**
     * MM060 - Create SA/SP/FA record using the row maintenance.
     */
    private void createSaSpFa(ServiceAgreementServicePoint serviceAgreementServicePoint, FieldActivity fieldActivity
    		, ServiceAgreementSpFaTypeLookup lookup) {
    	logger.info(">>>>> 1505" + servicePoint.fetchMeterLocation().getId().getIdValue());
        ServiceAgreementSpFieldActivity_Id serviceAgreementSpFieldActivityId = new ServiceAgreementSpFieldActivity_Id(serviceAgreementServicePoint
        		, fieldActivity);
        if (isNull(serviceAgreementSpFieldActivityId.getEntity())) {

            ServiceAgreementSpFieldActivity_DTO serviceAgreementSpFieldActivityDTO = new ServiceAgreementSpFieldActivity_DTO();
            serviceAgreementSpFieldActivityDTO.setFieldActivityType(lookup);
            serviceAgreementSpFieldActivityDTO.setServiceAgreementId(serviceAgreementServicePoint.getServiceAgreement().getId());
            serviceAgreementSpFieldActivityDTO.setServicePointId(serviceAgreementServicePoint.getServicePoint().getId());
            serviceAgreementSpFieldActivityDTO.setId(serviceAgreementSpFieldActivityId);
            serviceAgreementSpFieldActivityDTO.newEntity();

        }

    }

    private FieldActivity createFieldActivityAndLinkToSaSp_addp() {
    	
    	FieldActivityType faType = new FieldActivityType_Id("ADDPREAD").getEntity();
    	
    	FieldActivity_DTO fieldActivityDTO = new FieldActivity_DTO();
        fieldActivityDTO.setServicePointId(servicePoint.getId());
        fieldActivityDTO.setFieldActivityTypeId(faType.getId());
        fieldActivityDTO.setScheduleDateTimeStart(scheduleDateTime);
        fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);

        FieldActivityCreatorData data = FieldActivityCreatorData.Factory.newInstance();
        data.setFaDTO(fieldActivityDTO);

        FieldActivity fieldActivity = FieldActivityCreator.Factory.newInstance().addFieldActivity(data);

        ServiceAgreementSpFieldActivity_DTO serviceAgreementSpFieldActivityDTO = new ServiceAgreementSpFieldActivity_DTO();
        serviceAgreementSpFieldActivityDTO.setFieldActivityType(saSpFieldActivityType);
        serviceAgreementSpFieldActivityDTO.setServiceAgreementId(serviceAgreementServicePoint.getServiceAgreement().getId());
        serviceAgreementSpFieldActivityDTO.setServicePointId(serviceAgreementServicePoint.getServicePoint().getId());
        serviceAgreementServicePoint.getServiceAgreementSpFieldActivities().add(serviceAgreementSpFieldActivityDTO, fieldActivity.getId());

        isFaCreated = Bool.TRUE;

        return fieldActivity;
    }
    
    /**
     * MK040 - Link the FA to the Pending Start and Pending Stop SA/SPs
     */
    private void linkSameType(FieldActivity fieldActivity) {

    	if (saSpFieldActivityType.isStartActivity()) {

            for (ServiceAgreementServicePoint pendingStartSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
            		, null, null, saSpStartDateTime.getDate(), saSpStartDateTime.getDate(), ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY)) {

                // Cancel field activity and disconnect from SA/SP
                cancelUnlinkPendingFa(pendingStartSaSp, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);

                // Link new FA to SA/SP
                createSaSpFa(pendingStartSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);

            }

        }

        if (saSpFieldActivityType.isStopActivity()) {
        	logger.info(">>>>> 1542" + servicePoint.fetchMeterLocation().getId().getIdValue());
            for (ServiceAgreementServicePoint pendingStopSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
            		, saSpStopDateTime.getDate(), saSpStopDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY)) {
            	logger.info(">>>>> 1545" + servicePoint.fetchMeterLocation().getId().getIdValue());
                // Cancel field activity and disconnect from SA/SP
                cancelUnlinkPendingFa(pendingStopSaSp, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);

                // Link new FA to SA/SP
                createSaSpFa(pendingStopSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);

            }

        }

    }
    
    //Start Add IReyes - E-09691/B-35293 - 2024-11-22
    private boolean turnOnMeterFAShouldBeCreated(ServicePoint servicePoint){
    	
    	//Get SA/SP stop date for the pending stop (M-STOP) FA that exist 
    	DateTime pendingstopFaDateTime = getPendingStopFaDateTime(servicePoint);
  
    	if(notNull(pendingstopFaDateTime)){
	        // Calculate Date Difference between SASP's Start Date and Pending FA SA SP Stop Date
	        long dateDiff = saSpStartDateTime.getDate().difference(pendingstopFaDateTime.getDate()).getDays();
	        
	        //If date difference is greater than the back to back threshold parameter, set the create M-ON FA flag to true
	        if(dateDiff > backToBackThresholdDays.longValue()){
	        	return true;
	        }
    	}

		return false;
	}
    
    /**
     * This method will check and return a pending stop FA SA/SP stop date time 
     * @param sp
     * @return SA/SP stop date time
     */
    private DateTime getPendingStopFaDateTime(ServicePoint sp) {
    	
    	DateTime pendingStopFADateTime = null;
    	StringBuilder pendStFaSql = new StringBuilder();
    	PreparedStatement sql = null;
    	SQLResultRow result = null;
    	
    	pendStFaSql.append("SELECT ");
    	pendStFaSql.append(   "SASP.STOP_DTTM ");
    	pendStFaSql.append("FROM ");
    	pendStFaSql.append(   "CI_SA_SP_FA SASPFA, ");
    	pendStFaSql.append(   "CI_SA SA, ");
    	pendStFaSql.append(   "CI_FA FA, ");
    	pendStFaSql.append(   "CI_SA_SP SASP ");
    	pendStFaSql.append("WHERE ");
    	pendStFaSql.append(   "SASPFA.SP_ID = :spId ");
    	pendStFaSql.append("AND ");
    	pendStFaSql.append(   "SASPFA.SA_SP_FA_TYPE_FLG = :stopActivity ");
    	pendStFaSql.append("AND ");
    	pendStFaSql.append(   "SASPFA.SA_ID = SA.SA_ID ");
    	pendStFaSql.append("AND ");
    	pendStFaSql.append(   "SA.SA_STATUS_FLG = :pendingStop ");
    	pendStFaSql.append("AND ");
    	pendStFaSql.append(   "SASPFA.FA_ID = FA.FA_ID ");
    	pendStFaSql.append("AND ");
    	pendStFaSql.append(   "FA.FA_TYPE_CD = 'M-STOP' ");
    	pendStFaSql.append("AND ");
    	pendStFaSql.append(   "FA.FA_STATUS_FLG = :pending ");
    	pendStFaSql.append("AND ");
    	pendStFaSql.append(   "SASPFA.SA_SP_ID = SASP.SA_SP_ID ");
    	
    	sql = createPreparedStatement(pendStFaSql.toString() , getClass().getName());
    	sql.bindId("spId" , sp.getId());
    	sql.bindLookup("stopActivity" , ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
    	sql.bindLookup("pendingStop" , ServiceAgreementStatusLookup.constants.PENDING_STOP);
    	sql.bindLookup("pending" , FieldActivityStatusLookup.constants.PENDING);
    	
    	result = sql.firstRow();
    	sql.close();
    	
    	if(notNull(result)) {
    		pendingStopFADateTime = result.getDateTime("STOP_DTTM");
    	}
    	
    	return pendingStopFADateTime;
    }  
    //End Add IReyes - E-09691/B-35293 - 2024-11-22
}
