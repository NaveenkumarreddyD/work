/*
 **************************************************************************
 *                Confidentiality Information:
 *
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Feature Type for PA SA Types to determine CWR Level
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 * 
 * 2018-03-20   JHERNA      SysAid#244206. Initial Version.  
 * *************************************************************************                
 */
package com.splwg.cm.api.lookup;

/**
 * @author 90622
 *
@LookupFieldname (value = XQPA_OPT_TYP_FLG)
 */
public class CmQPPaymentArrangementSATypesLookup_Impl 
		extends CmQPPaymentArrangementSATypesLookup_Gen {

}
