/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Irregular Use Codes Lookup
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2012-08-29	Srikanth	NA0002. Initial Version.
 **************************************************************************/
package com.splwg.cm.api.lookup;
/**
 * @author sdesabhatl002
 * 
 * @LookupFieldname (value = XXIC_OPT_TYP_FLG)
 */

public class CmIrregularUseCodeLookup_Impl 
extends CmIrregularUseCodeLookup_Gen{

}
