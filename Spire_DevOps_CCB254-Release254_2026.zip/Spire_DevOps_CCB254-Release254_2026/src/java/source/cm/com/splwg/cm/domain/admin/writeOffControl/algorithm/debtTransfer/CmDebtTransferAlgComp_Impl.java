/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This write off event algorithm looks at all service agreements that are 
 * subject to write-off processing.  For each service agreement it performs 
 * the following: 
 * - Each SA's current balance will be set equal to its payoff balance using 
 *   the Synch Current adjustment type defined on the SA type. 
 * - If the service agreement being written off has a credit balance, the 
 *   algorithm attempts to transfer this balance to SAs in the same 
 *   write-off debt class and account that have a debit balance and are in 
 *   a non-canceled / non-closed status.  The SAs are reviewed in order of 
 *   their SA Type payment priority.   If a non-stopped service agreement is 
 *   found, the credit balance is transferred in total and processing stops.  
 *   If a stopped SA is found, enough of the credit balance is transferred 
 *   to bring the balance to zero.  If more credit is left, the next SA 
 *   is processed.  The adjustment type used to transfer the balance is 
 *   defined in Adjustment Type (transfer).
 * - If the service agreement being written off has a debit balance, 
 *   this balance is transferred in its entirety to an active service 
 *   agreement that is linked to the same write-off debt class and account.  
 *   If multiple such service agreements exist, the service agreement with 
 *   the highest payment priority on its SA type is selected.  
 *   The adjustment type used to transfer the balance is defined in 
 *   Adjustment Type (transfer).
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2018-12-06   EQuint      Initial Version. 
 * 2019-05-17   MPang       Defect 4257951. Remove pending start SA from 
 *                          eligible recipient of credits.                  
 * *************************************************************************                
 */
package com.splwg.cm.domain.admin.writeOffControl.algorithm.debtTransfer;

import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.BillableChargeStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.writeOffControl.algorithm.debtTransfer.DebtTransferAlgorithmSpot;
import com.splwg.ccb.domain.admin.writeOffDebtClass.entity.WriteOffDebtClass;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentType, name = adjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = transferBalanceSw, type = boolean)})
 */
public class CmDebtTransferAlgComp_Impl extends CmDebtTransferAlgComp_Gen
		implements DebtTransferAlgorithmSpot {

	// hard parameter
	private Bool areSaClosed = Bool.FALSE;
	private ServiceAgreement sa;
	private WriteOffDebtClass woDebtClass;
	private Money woDebtClassTotBal = Money.ZERO;
	
	// soft parameters
	private AdjustmentType xferAdjType;
	private Bool xferBalSw = Bool.FALSE;
	
	// work variables
	private Money fromTotAmt = Money.ZERO;
	private Money xferAmt = Money.ZERO;
	private Bool isXferDebit = Bool.FALSE;
	private Bool isXferCredit = Bool.FALSE;
	private List<ServiceAgreement> saList = new ArrayList<ServiceAgreement>();
	private Bool xferSaFound = Bool.FALSE;
	private ServiceAgreement unbilledDebitSa;
	private Bool holdXferCreditSw = Bool.FALSE;
	private ServiceAgreement creditSa;
	
	@Override
	public Bool getAreServiceAgreementsClosed() {
		return areSaClosed;
	}

	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		// initialize soft parameters
		xferAdjType = getAdjustmentType();
		xferBalSw = getTransferBalanceSw();
		if (isNull(xferBalSw)) {
			xferBalSw = Bool.FALSE;
		}
	}

	@Override
	public void setServiceAgreement(ServiceAgreement arg0) {
		sa = arg0;
	}

	@Override
	public void setWriteOffDebtClass(WriteOffDebtClass arg0) {
		woDebtClass = arg0;
	}

	@Override
	public void setWriteOffDebtClassTotalBalance(Money arg0) {
		woDebtClassTotBal = arg0;
	}
	
	@Override
	public void invoke() {
		Money saTotBal = sa.getFinancialBalances().getTotalAmount();
		fromTotAmt = saTotBal;
		xferAmt = saTotBal;
		
		// if there is debit balance on SA
		if (fromTotAmt.isGreaterThan(Money.ZERO)) {
			// Only pass SA Status '20' and '30' to the S-SA SQL. This should be the only difference with the base algorithm CIPL1TRX. 
			// The base algorithm also passes the SA Status '10' to the SA-SA SQL
			saList = retrieveOtherServiceAgreementsWithStatus(ServiceAgreementStatusLookup.constants.ACTIVE, ServiceAgreementStatusLookup.constants.PENDING_STOP);
			isXferDebit = Bool.TRUE;
		}
		// if there is credit balance on SA
		else {
			//Start Change - MPang - Defect 4257951 - 2019-05-17
			//saList = retrieveOtherServiceAgreementsWithStatus(ServiceAgreementStatusLookup.constants.PENDING_START, ServiceAgreementStatusLookup.constants.ACTIVE,
			//		ServiceAgreementStatusLookup.constants.PENDING_STOP, ServiceAgreementStatusLookup.constants.STOPPED, ServiceAgreementStatusLookup.constants.REACTIVATED);
			saList = retrieveOtherServiceAgreementsWithStatus(ServiceAgreementStatusLookup.constants.ACTIVE,
					ServiceAgreementStatusLookup.constants.PENDING_STOP, ServiceAgreementStatusLookup.constants.STOPPED, ServiceAgreementStatusLookup.constants.REACTIVATED);
			//End Change - MPang - Defect 4257951 - 2019-05-17
			isXferCredit = Bool.TRUE;
		}
		
		// transfer SA found
		xferSaFound = Bool.valueOf(saList.size() > 1);
		
		// transfer balance
		for (ServiceAgreement xferSa : saList) {
			Bool stopLoop = transferBalance(xferSa);
			if (stopLoop.isTrue()) {
				break;
			}
		}
		
		// If no transfer SAs found and the Transfer Balance Switch is set to Y, transfer the balance to Stopped SAs
		if (xferSaFound.isFalse() && xferBalSw.isTrue()) {
			processStoppedSa();
		}
		// Transfer remaining credit balance to the Credit SA
		if (holdXferCreditSw.isTrue() && fromTotAmt.isLessThan(Money.ZERO)) {
			processSa(creditSa);
			fromTotAmt = Money.ZERO;
		}
		// If there is remaining credit and there's no credit SA to transfer to, and there is a stopped unbilled debit SA, transfer the remaining credit to this debit SA
		if (isXferCredit.isTrue() && holdXferCreditSw.isFalse() && fromTotAmt.isLessThan(Money.ZERO) && notNull(unbilledDebitSa)) {
			processSa(unbilledDebitSa);
			fromTotAmt = Money.ZERO;
		}
		// If a credit was transferred, there may be credit remaining for refund. Reset the 'SAs closed' switch
		if (isXferCredit.isTrue() && fromTotAmt.isLessThan(Money.ZERO)) {
			areSaClosed = Bool.FALSE;
		}
	}
	
	/**
	 * Retrieve the list of SAs other than the main SA with the given status
	 * @param saStatList SA Status filter
	 * @return List of Service Agreement
	 */
	private List<ServiceAgreement> retrieveOtherServiceAgreementsWithStatus(ServiceAgreementStatusLookup... saStatList) {
		
		String queryStr = "FROM ServiceAgreement sa,ServiceAgreementType st WHERE sa.status IN (";
		
		for (int i = 0; i < saStatList.length; i++) {
			queryStr += ":" + i;
			if (i != saStatList.length - 1) {
				queryStr += ", ";
			}
			else {
				queryStr += ") ";
			}
		}
		queryStr += "AND sa.account.id = :acctId "
				+ "AND sa.serviceAgreementType.id.division = st.id.division "
				+ "AND sa.serviceAgreementType.id.saType = st.id.saType "
				+ "AND st.writeOffDebtClass.id = :woDebtClassCd "
				+ "AND sa.id != :saId "
				+ "AND st.paymentPriority IS NOT NULL ";
		
		Query<QueryResultRow> query = createQuery(queryStr, "retrieveServiceAgreement");
		
		for (int i = 0; i < saStatList.length; i++) {
			query.bindLookup(""+i, saStatList[i]);
		}
		query.bindId("acctId", sa.getAccount().getId());
		query.bindId("woDebtClassCd", woDebtClass.getId());
		query.bindId("saId", sa.getId());
		
		query.addResult("paymentPrio", "st.paymentPriority");
		query.addResult("sa", "sa");
		
		query.orderBy("paymentPrio");
		
		List<ServiceAgreement> saList = new ArrayList<ServiceAgreement>();
		for(QueryResultRow qr : query.list()) {
			saList.add(qr.getEntity("sa", ServiceAgreement.class));
		}
		
		return saList;
	}
	
	/**
	 * Create Transfer Adjustment to the given SA
	 * @param xferSa Transfer Service Agreement
	 */
	private void processSa(ServiceAgreement xferSa) {
		CreateFrozenAdjustmentData data = CreateFrozenAdjustmentData.Factory.newInstance();
		data.setServiceAgreement(sa);
		data.setTransferServiceAgreement(xferSa);
		data.setAdjustmentType(xferAdjType);
		data.setAdjustmentAmount(xferAmt);
		data.setAllowZeroAmount(Bool.FALSE);
		sa.createFrozenAdjustment(data);
		areSaClosed = Bool.TRUE;
	}
	
	/**
	 * Transfer main SA balance to the supplied transfer SA
	 * @param xferSa Transfer Service Agreement
	 * @return Bool to determine whether to stop transfer balance to the next SA
	 */
	private Bool transferBalance(ServiceAgreement xferSa) {
		Bool stopLoop = Bool.FALSE;
		if (isXferDebit.isTrue()) {
			processSa(xferSa);
			// Stop the loop
			stopLoop = Bool.TRUE;
		}
		else if (isXferCredit.isTrue()) {
			Money toTotAmount = xferSa.getFinancialBalances().getTotalAmount();
			
			if (toTotAmount.isGreaterThan(Money.ZERO)) {
				if (!xferSa.getStatus().isStopped() && !xferSa.getStatus().isReactivated() && !xferSa.getStatus().isClosed() && !xferSa.getStatus().isCanceled()) {
					processSa(xferSa);
					fromTotAmt = Money.ZERO;
					// stop the loop
					stopLoop = Bool.TRUE;
				}
				else {
					fromTotAmt = fromTotAmt.add(toTotAmount);
					if (fromTotAmt.isGreaterThanOrEqual(Money.ZERO)) {
						processSa(xferSa);
						// stop the loop
						stopLoop = Bool.TRUE;
					}
					else {
						xferAmt = toTotAmount.negate();
						processSa(xferSa);
						xferAmt = fromTotAmt;
					}
					
					if (isNull(unbilledDebitSa) && xferSa.getStatus().isStopped()) {
						if (isSaFinalBilled(xferSa).isFalse()) {
							unbilledDebitSa = xferSa;
						}
					}
				}
			}
			else {
				if (holdXferCreditSw.isFalse()) {
					holdXferCreditSw = Bool.TRUE;
					creditSa = xferSa;
				}
			}
		}
		
		return stopLoop;
	}

	/**
	 * Determine whether the SA is final billed
	 * @param sa Service Agreement
	 * @return Bool
	 */
	private Bool isSaFinalBilled(ServiceAgreement sa) {
		Bool isFinalBill = Bool.FALSE;
		if (sa.getServiceAgreementType().getSpecialRole().isBillableCharge()) {
			Query query = createQuery("FROM BillableCharge bc "
					+ "WHERE bc.serviceAgreement.id = :saId "
					+ "AND bc.billableChargeStatus = :stat "
					+ "AND NOT EXISTS(SELECT bs.id FROM BillSegment bs, BillSegmentCalculationHeader bch "
						+ "WHERE bs.serviceAgreement.id = :saId "
						+ "AND bs.id = bch.id.billSegment.id "
						+ "AND bch.billableChargeId = bc.id "
						+ "AND bs.billSegmentStatus = :bsegStat) "
					, "isSaFinalBilled");
			
			query.bindId("saId", sa.getId());
			query.bindLookup("stat", BillableChargeStatusLookup.constants.BILLABLE);
			query.bindLookup("bsegStat", BillSegmentStatusLookup.constants.FROZEN);
			
			if (query.listSize() == 0) {
				isFinalBill = Bool.TRUE;
			}
		}
		else {
			Query query = createQuery("FROM BillSegment bs "
					+ "WHERE bs.serviceAgreement.id = :saId "
					+ "AND bs.endDate = :endDate "
					+ "AND  bs.billSegmentStatus = :bsegStat "
					+ "AND bs.isClosingBillSegment = :true "
					, "isSaFinalBilled");
			
			query.bindId("saId", sa.getId());
			query.bindDate("endDate", sa.getEndDate());
			query.bindLookup("bsegStat", BillSegmentStatusLookup.constants.FROZEN);
			query.bindBoolean("true", Bool.TRUE);
			
			if (query.listSize() > 0) {
				isFinalBill = Bool.TRUE;
			}
		}
		return isFinalBill;
	}
	
	
	/**
	 * Process Stopped SA
	 */
	private void processStoppedSa() {
		List<ServiceAgreement> stoppedSaList = retrieveOtherServiceAgreementsWithStatus(ServiceAgreementStatusLookup.constants.STOPPED);
		for (ServiceAgreement sa : stoppedSaList) {
			if (sa.determineEligibilityForWriteOff(sa.getServiceAgreementType().getSpecialRole()
					, sa.getServiceAgreementType().getIsSubServiceAgreement(), sa.getServiceAgreementType().getIsEligibleForBilling()).isFalse()) {
				Bool stopLoop = transferBalance(sa);
				if (stopLoop.isTrue()) {
					break;
				}
			}
		}
	}
}
