/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm will issue a warning pop-up message informing the user 
 * that the premise is covered under an active CIAC agreement, showing, at 
 * a minimum, the monthly CIAC amount to be billed and the number of terms 
 * in months. When the user clicks the Ok button on the warning pop-up 
 * window, the algorithm will then default the SA's CIAC contract value 
 * from its associated CIAC Parent Premise's CIAC Monthly Charge.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2018-08-16   EQuint      SA-251520D. Initial Version.    
 * 2018-09-13	EQuint		SA-251520D Issue 1. - Do not raise error if term char is
 * 							missing. 
 * 										- check for CIAC billing status <> 
 * 							'Fully Billed', this means that we will default 
 * 							the contract value if billing status is blank 
 * 							(billing status char is not yet added) or active 
 * 							(billing status char is already there and is 
 * 							equal to 'A').
 * 2018-09-21   SMiran      Added saveChanges();
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.saCreation;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.Query;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ContractTermTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.billFactor.entity.BillFactor;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saCreation.SaTypeSaCreationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementContractTerm_DTO;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author Dell
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = ciacMonthlyChargePremCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = ciacTermsPremCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = ciacBillingStatusPremCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = ciacBillingStatusPremCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = billFactor, name = ciacBillFactorCode, required = true, type = entity)})
 */
public class CmIssueCIACWarningMessageAndDefaultCIACChargeOnSaAlgComp_Impl
		extends CmIssueCIACWarningMessageAndDefaultCIACChargeOnSaAlgComp_Gen
		implements SaTypeSaCreationAlgorithmSpot {

	// soft parameters
	private CharacteristicType softParmCiacMonthlyChargePremCharType;
	private CharacteristicType softParmCiacTermsPremCharType;
	private CharacteristicType softParmCiacBillingStatusPremCharType;
	private CharacteristicValue softParmCiacBillingStatusPremCharValue;
	private String softParmCiacBillingStatusPremCharValueStr;
	private BillFactor softParmCiacBillFactor;
	
	// hard parameters
	private ServiceAgreement sa;
	
	@Override
	public void setServiceAgreement(ServiceAgreement sa) {
		this.sa = sa;
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		
		// monthly charge must be a valid char type for premise entity
		softParmCiacMonthlyChargePremCharType = getCiacMonthlyChargePremCharType();
		CharacteristicEntity premCharEntity = new CharacteristicEntity_Id(softParmCiacMonthlyChargePremCharType, 
				CharacteristicEntityLookup.constants.PREMISE).getEntity();
		if (isNull(premCharEntity)) {
			// raise error "Algorithm Parameter value %1 is not a valid characteristic for entity %2"
			addError(CustomMessageRepository.SA251520D_charInvalidForEntity(softParmCiacMonthlyChargePremCharType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.PREMISE.getLookupValue().fetchLanguageDescription()));
		}
		
		// terms must be a valid char type for premise entity
		softParmCiacTermsPremCharType = getCiacTermsPremCharType();
		premCharEntity = new CharacteristicEntity_Id(softParmCiacTermsPremCharType, 
				CharacteristicEntityLookup.constants.PREMISE).getEntity();
		if (isNull(premCharEntity)) {
			// raise error "Algorithm Parameter value %1 is not a valid characteristic for entity %2"
			addError(CustomMessageRepository.SA251520D_charInvalidForEntity(softParmCiacTermsPremCharType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.PREMISE.getLookupValue().fetchLanguageDescription()));
		}
		
		// billing status must be a valid char type for premise entity
		softParmCiacBillingStatusPremCharType = getCiacBillingStatusPremCharType();
		premCharEntity = new CharacteristicEntity_Id(softParmCiacBillingStatusPremCharType, 
				CharacteristicEntityLookup.constants.PREMISE).getEntity();
		if (isNull(premCharEntity)) {
			// raise error "Algorithm Parameter value %1 is not a valid characteristic for entity %2"
			addError(CustomMessageRepository.SA251520D_charInvalidForEntity(softParmCiacBillingStatusPremCharType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.PREMISE.getLookupValue().fetchLanguageDescription()));
			
		}
		
		// billing status premise char value must be valid for billing status premise char type
		softParmCiacBillingStatusPremCharValueStr = getCiacBillingStatusPremCharValue().trim();
		softParmCiacBillingStatusPremCharValue = new CharacteristicValue_Id(softParmCiacBillingStatusPremCharType, 
				softParmCiacBillingStatusPremCharValueStr).getEntity();
		if (isNull(softParmCiacBillingStatusPremCharValue)) {
			// raise error "Algorithm Parameter value %1 is not a valid characteristic value for characteristic type %2"
			addError(CustomMessageRepository.SA251520D_charValueInvalidForCharType(softParmCiacBillingStatusPremCharValueStr, 
					softParmCiacBillingStatusPremCharType.getId().getTrimmedValue()));
		}
		
		softParmCiacBillFactor = getCiacBillFactorCode();
		
	}

	@Override
	public void invoke() {
		// Check if the premise associated to the SA being started has a Parent Premise ID.
		// If the Premise does not have a Parent Premise ID, the premise is not covered under a CIAC agreement. 
		// Skip further processing and exit the algorithm.
		Premise saPrem = sa.getPremiseId().getEntity();
		Premise parentPremise = saPrem.fetchParentPremise();
		if (notNull(parentPremise)) {
			// If the Premise has a Parent Premise ID, use the CIAC Billing Status Premise Characteristic Type 
			// and Value parameters to determine if the CIAC agreement is currently in Active status.		
			PremiseCharacteristic billStatusPremChar = parentPremise.getEffectiveCharacteristic(softParmCiacBillingStatusPremCharType);
			
			// If the agreement is not in active status in CC&B, 
			// skip further processing and exit the algorithm, else proceed
			// start - change - SA-251520D Issue 1 - EQuint - 09-13-2018
			if (isNull(billStatusPremChar) || (notNull(billStatusPremChar) && billStatusPremChar.getSearchCharacteristicValue().compareTo(softParmCiacBillingStatusPremCharValueStr) == 0)) {
			// if (notNull(billStatusPremChar) && billStatusPremChar.getSearchCharacteristicValue().compareTo(softParmCiacBillingStatusPremCharValueStr) == 0) {
			// End - change - SA-251520D Issue 1 - EQuint - 09-13-2018
				// Check if there are other SPs within the same premise linked to an SA that is being billed with a CIAC monthly charge
				Query<ServicePoint_Id> getPremiseSpLinkedToCiacSaQuery = getPremiseSpLinkedToCiacSa(sa);
				ServicePoint_Id spId = getPremiseSpLinkedToCiacSaQuery.firstRow();
				// If there's already a gas SA being billed a CIAC monthly charge for a different SP on the same premise, 
				//skip further processing and exit the algorithm, else proceed
				if (isNull(spId)) {
					// Build the message using the retrieve CIAC values, and issue a warning pop-up message.
					PremiseCharacteristic monthlyChargePremChar = parentPremise.getEffectiveCharacteristic(softParmCiacMonthlyChargePremCharType);
					if (isNull(monthlyChargePremChar)) {
						// raise error "The CIAC parent premise (%1) must have %2 characteristic."
						addError(CustomMessageRepository.SA251520D_ciacPremCharMissing(parentPremise.getId().getTrimmedValue()
								, softParmCiacMonthlyChargePremCharType.fetchLanguageDescription()));
					}
					
					// start - delete - SA-251520D Issue 1 - EQuint - 09-13-2018
					// PremiseCharacteristic termsPremChar = parentPremise.getEffectiveCharacteristic(softParmCiacTermsPremCharType);
					// if (isNull(termsPremChar)) {
					// 	// raise error "The CIAC parent premise (%1) must have %2 characteristic."
					// 	addError(CustomMessageRepository.SA251520D_ciacPremCharMissing(parentPremise.getId().getTrimmedValue()
					// 			, softParmCiacTermsPremCharType.fetchLanguageDescription()));
					// }
					// end - delete - SA-251520D Issue 1 - EQuint - 09-13-2018
					
					// Add warning "The premise is covered under an active CIAC agreement with monthly CIAC amount of $%1."
					addWarning(CustomMessageRepository.SA251520D_warnPremiseUnderCiac(monthlyChargePremChar.getSearchCharacteristicValue().trim()));
					
					// If the user clicks the Ok button, create a contract value row on the SA using the CIAC Bill Factor parameter, 
					// with start date equal to the SA start date. The end date will be left blank.
					ServiceAgreementContractTerm_DTO sactDto = new ServiceAgreementContractTerm_DTO();
					sactDto.setValue(BigDecimal.valueOf(Double.valueOf(monthlyChargePremChar.getSearchCharacteristicValue())));
					sa.getContractTerms().add(sactDto, softParmCiacBillFactor.getId(), ContractTermTypeLookup.constants.CONTRACT_VALUE
							, "", sa.getStartDate());
					// start - add - SA-251520D Issue 1 - SMiran - 09-21-2018
					saveChanges();
					// end - add - SA-251520D Issue 1 - SMiran - 09-21-2018
				
				}
			}
		}
	}
	
	private Query<ServicePoint_Id> getPremiseSpLinkedToCiacSa(ServiceAgreement sa) {	
		
		Query<ServicePoint_Id> query = createQuery(" FROM ServicePoint sp, ServiceAgreementServicePoint sasp, ServiceAgreementContractTerm sact "
				+ " WHERE sp.premise.id = :premId "
				+ " AND sp.id = sasp.servicePoint.id "
				+ " AND sasp.serviceAgreement.id != :curSaId "
				// start - change - SA-251520D Issue 1 - EQuint - 09-13-2018
				// + " AND sasp.serviceAgreement.status IN ( :actv, :ps, :st, :react) "
				+ " AND sasp.serviceAgreement.status IN ( :actv, :ps) "
				// end - change - SA-251520D Issue 1 - EQuint - 09-13-2018
				+ " AND sasp.serviceAgreement.id = sact.id.serviceAgreement.id "
				+ " AND sact.id.billFactor.id = :bfCd "
				+ " AND sact.id.contractTermType = :cv "
				+ " AND ((sact.id.startDate <= :curDate AND sact.endDate IS NULL) "
					+ " OR :curDate BETWEEN sact.id.startDate AND sact.endDate) "
				, "getPremiseSpLinkedToCiacSa");
		
		query.bindId("premId", sa.getPremiseId());
		query.bindId("curSaId", sa.getId());
		query.bindLookup("actv", ServiceAgreementStatusLookup.constants.ACTIVE);
		// start - change - SA-251520D Issue 1 - EQuint - 09-13-2018
		// query.bindLookup("ps", ServiceAgreementStatusLookup.constants.PENDING_STOP);
		// query.bindLookup("st", ServiceAgreementStatusLookup.constants.STOPPED);
		// query.bindLookup("react", ServiceAgreementStatusLookup.constants.REACTIVATED);
		query.bindLookup("ps", ServiceAgreementStatusLookup.constants.PENDING_START);
		// end - change - SA-251520D Issue 1 - EQuint - 09-13-2018
		query.bindId("bfCd", softParmCiacBillFactor.getId());
		query.bindLookup("cv", ContractTermTypeLookup.constants.CONTRACT_VALUE);
		query.bindDate("curDate", getProcessDateTime().getDate());
		
		query.addResult("spId", "sp.id");
		
		return query;
	}



}
