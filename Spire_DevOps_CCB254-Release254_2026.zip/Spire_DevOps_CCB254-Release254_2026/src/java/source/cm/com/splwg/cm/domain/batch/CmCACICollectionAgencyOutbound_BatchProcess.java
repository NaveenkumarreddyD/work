/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * CACI Collection Agency Out Bound 
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-04-18   Srikanth        NI0040.1. Initial Version.
 * 2013-06-11   Srikanth        SD20131106 - CR - Solution Change for Pledge Payment
 * 2013-06-11   Srikanth        SD20131106-1 Defect - FTs of SAs not in WriteOff Process are shown in output file.
 * 2013-06-27   Srikanth        SD20132706  CR107. Pledge Payment is on Payment Char,not on Payment Tender Char(SD20131106) 
 * 2013-08-08   Srikanth        IM-033087 -CR114.
 * 2014-01-30   Ujesh           IM-043433 - Mandatory field validations
 * 2014-09-10   Ujesh           IM-053664 - DF 002 - Collection Agency FT Update File - ADJUST CWR
 * 2015-01-07   MCruz           CCB004.008 (CR3135978) - Added parameters and columns to Initial Referral extract file:
 *                              - Person ID
 *                              - CIS Division
 *                              - SA Type
 *                              - Final Bill Date
 *                              - Rate Class
 *                              - Building Meter Indicator
 *                              - Region
 *                              - Disconnect Reason
 * 2015-06-09   SMiran          Defect 3232581. Fixed SQL error in getDisconnectReason
 *              BMarquez        Altered Java variables and soft parameter intialization.
 *                              Use Sequence Number to retrieve latest History record.
 * 2015-06-15   BMarquez        Defect 3233475. Removed duplicate info in demographic 
 *                              update file.
 * 2015-06-26   BMarquez        Defect 3241939. CMCAREXT should not be rerunnable.
 * 2015-08-27   SMiran			Defect 3294942. Change FT selection for FT Update File
 * 							    Freeze date = creation date of the referral history record
 * 2015-09-18   DHuynh			Defect#3272420. Create TO DO if address source is premise
 * 								but mailing premise ID is not exist on account
 * 2015-10-15   SMiran          SF-59547. Report all FT's except the System Write Off 
 * 								Adjustment Type SYSXFR3.
 * 2016-01-27   SMiran          SF-68527. Ensure that all FTs are extracted
 * 2016-02-18   MPang		    Updated for CCB v2.4 compilation.
 * 2018-07-25   SFelip          CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                              longer needed.
 * 2020-08-31   JHERNA          SA-15994. Updated to extract referral cancellations even if
 *                              there are no FTs associated with the event. 
 *                              This will be based on 2015 PWC fix by Ujesh  
 * 2020-10-22   JRAYMU          CCB017. Encryption/Decryption Task: CMCAREXT batch update    
 * 2020-11-03   JHERNA          SysAid#383853 / Mercury#47077. Add Delinquency Date and 
 *                              Delinquency Amount fields for initial referral file.
 * 2021-12-09   JHERNA          Mercury#47158 / B-20308. Correction to how the final bill 
 * 								date is being determined.                                                      
 ******************************************************************************************/
package com.splwg.cm.domain.batch;

// CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
//import com.splwg.base.api.datatypes.LookupHelper;
//import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
//import com.splwg.cm.api.lookup.CmBankDistributionCodeLookup;
// CCB004.008 (CR3135978) - MCruz 2015-01-07 - End

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.encryption.DecryptedValue;
import com.splwg.base.api.lookup.BusinessObjectStatusConditionLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus_Id;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObject_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.base.domain.todo.role.Role_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_Id;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeDrillKeyTypes;
import com.splwg.base.domain.todo.toDoType.ToDoTypeSortKeyTypes;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.api.lookup.NameTypeLookup;
import com.splwg.ccb.api.lookup.PersonOrBusinessLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementSpFaTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.adjustmentType.AdjustmentType;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.Person;
import com.splwg.ccb.domain.customerinfo.person.Person_Id;
import com.splwg.ccb.domain.customerinfo.premise.AccountMailingAddressData;
import com.splwg.ccb.domain.customerinfo.premise.Premise;
import com.splwg.ccb.domain.customerinfo.premise.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity_Id;
import com.splwg.ccb.domain.financial.financialTransaction.FinancialTransaction;
import com.splwg.ccb.domain.financial.financialTransaction.FinancialTransaction_Id;
import com.splwg.ccb.domain.payment.payment.Payment;
import com.splwg.ccb.domain.payment.payment.PaymentCharacteristic;
import com.splwg.ccb.domain.payment.payment.PaymentCharacteristics;
import com.splwg.ccb.domain.payment.payment.Payment_Id;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentEventPaymentTenders;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentTender;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentTenderCharacteristic;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentTenderCharacteristic_DTO;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentTenderCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoMaintenanceData;*/
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffProcess;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffProcessServiceAgreement;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffProcess_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.data.AccountMailingAddressData;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.premise.entity.PremiseCharacteristic;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction_Id;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.ccb.domain.payment.payment.entity.PaymentCharacteristic;
import com.splwg.ccb.domain.payment.payment.entity.PaymentCharacteristics;
import com.splwg.ccb.domain.payment.payment.entity.Payment_Id;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentEventPaymentTenders;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentTender;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentTenderCharacteristic;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentTenderCharacteristic_DTO;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentTenderCharacteristic_Id;
import com.splwg.ccb.domain.security.common.FieldEncryptionDecryption;
import com.splwg.ccb.domain.security.data.FieldEncryptionDecryptionData;
import com.splwg.ccb.domain.todo.common.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.data.ToDoMaintenanceData;
import com.splwg.cm.api.lookup.ReferralHistoryReasonLookup;
import com.splwg.cm.api.lookup.SchemaConstantOptionLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

/*
 * Start Change - Defect 3241939 - 2015-06-26
 */
////CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
/////**
////* @author sdesabhatl002
////*
////@BatchJob (modules = {}
////*      , multiThreaded = false
////*      , rerunnable = false
////*      ,  softParameters = {@BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
////*      , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
////*      , @BatchJobSoftParameter(entityName = serviceTaskType, name = SVC_TASK_TYPE_CD, required = true, type = entity)
////*      , @BatchJobSoftParameter(name = CWR_STATUS_CD, required = true, type = string)
////*      , @BatchJobSoftParameter (entityName = characteristicType, name = CWR_CHAR_TYPE_CD, required = true, type = entity)
////*      , @BatchJobSoftParameter (entityName = featureConfiguration, name = DIST_CODE_FEAT_CONFIG, required = true, type = entity)
////*      , @BatchJobSoftParameter (name = DIST_CODE_OPT_TYPE, required = true, type = string)
////*      , @BatchJobSoftParameter (name = CACI_EXT_SRC_ID, required = true, type = string)
////*      , @BatchJobSoftParameter (entityName = characteristicType, name = PAY_CHAR_TYPE_RSN_CD, required = true, type = entity)
////*      , @BatchJobSoftParameter (name = CA_FT_RSN_ADJUST, required = true, type = string)
////*      , @BatchJobSoftParameter (name = CA_FT_RSN_CWR_ADJUST, required = true, type = string)
////*      , @BatchJobSoftParameter (name = CA_FT_RSN_CACI_PAY, required = true, type = string)
////*      , @BatchJobSoftParameter (name = CA_FT_RSN_PAY, required = true, type = string)
////*      , @BatchJobSoftParameter (name = CA_FT_RSN_CANC_PAY, required = true, type = string)
////*      , @BatchJobSoftParameter (name = CA_FT_RSN_CACI_CANC_PAY, required = true, type = string)
////*      , @BatchJobSoftParameter (name = CA_FT_RSN_CAN_TRANS, required = true, type = string)
////*      , @BatchJobSoftParameter (name = CA_FT_RSN_CANCEL, required = true, type = string)
////*      , @BatchJobSoftParameter (entityName = characteristicType, name = PAYMENT_CHAR_TYPE_CD, required = true, type = entity)
////*      , @BatchJobSoftParameter (entityName = adjustmentType, name = BAL_FWD_ADJ_TYPE_CD, required = false, type = entity)
////*      , @BatchJobSoftParameter (entityName = toDoType, name = TO_DO_TYPE, required = true, type = entity)
////*      , @BatchJobSoftParameter (entityName = role, name = TO_DO_ROLE, required = true, type = entity)
////*      , @BatchJobSoftParameter (entityName = characteristicType, name = BLDGMTR_CHAR_TYPE_CD, type = entity)
////*      , @BatchJobSoftParameter (entityName = characteristicType, name = OPSAREA_CHAR_TYPE_CD, type = entity)
////*      , @BatchJobSoftParameter (entityName = characteristicType, name = RATECLASS_CHAR_TYPE_CD, type = entity, required = true)
////*      , @BatchJobSoftParameter (name = NONVOL_DISC_FAT, type = string)})
////*/
//
///**
// * @author sdesabhatl002
// *
// @BatchJob (multiThreaded = false, modules = {},
// *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
// *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = SVC_TASK_TYPE_CD, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = CWR_STATUS_CD, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = CWR_CHAR_TYPE_CD, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = CACI_EXT_SRC_ID, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = PAY_CHAR_TYPE_RSN_CD, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = CA_FT_RSN_ADJUST, required = true, type = string)
// *            , @BatchJobSoftParameter (name = CA_FT_RSN_CWR_ADJUST, required = true, type = string)
// *            , @BatchJobSoftParameter (name = CA_FT_RSN_CACI_PAY, required = true, type = string)
// *            , @BatchJobSoftParameter (name = CA_FT_RSN_PAY, required = true, type = string)
// *            , @BatchJobSoftParameter (name = CA_FT_RSN_CANC_PAY, required = true, type = string)
// *            , @BatchJobSoftParameter (name = CA_FT_RSN_CACI_CANC_PAY, required = true, type = string)
// *            , @BatchJobSoftParameter (name = CA_FT_RSN_CAN_TRANS, required = true, type = string)
// *            , @BatchJobSoftParameter (name = CA_FT_RSN_CANCEL, required = true, type = string)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = PAYMENT_CHAR_TYPE_CD, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = adjustmentType, name = BAL_FWD_ADJ_TYPE_CD, type = entity)
// *            , @BatchJobSoftParameter (entityName = toDoType, name = TO_DO_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = role, name = TO_DO_ROLE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = BLDGMTR_CHAR_TYPE_CD, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = OPSAREA_CHAR_TYPE_CD, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = RATECLASS_CHAR_TYPE_CD, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = NONVOL_DISC_FAT, type = string)})
// */
//// CCB004.008 (CR3135978) - MCruz 2015-01-07 - End
/**
 * @author sdesabhatl002
 *
 @BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = SVC_TASK_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CWR_STATUS_CD, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CWR_CHAR_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CACI_EXT_SRC_ID, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PAY_CHAR_TYPE_RSN_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CA_FT_RSN_ADJUST, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CA_FT_RSN_CWR_ADJUST, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CA_FT_RSN_CACI_PAY, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CA_FT_RSN_PAY, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CA_FT_RSN_CANC_PAY, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CA_FT_RSN_CACI_CANC_PAY, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CA_FT_RSN_CAN_TRANS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CA_FT_RSN_CANCEL, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PAYMENT_CHAR_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = adjustmentType, name = BAL_FWD_ADJ_TYPE_CD, type = entity)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = TO_DO_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = role, name = TO_DO_ROLE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = BLDGMTR_CHAR_TYPE_CD, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = OPSAREA_CHAR_TYPE_CD, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = RATECLASS_CHAR_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = NONVOL_DISC_FAT, type = string)})
 */
/*
 * End Change - Defect 3241939 - 2015-06-26
 */
public class CmCACICollectionAgencyOutbound_BatchProcess extends
        CmCACICollectionAgencyOutbound_BatchProcess_Gen {
    
    /*
     * Start Change - Defect 3232581 - 2015-06-09
     */
    //private static String strFilePath;
    //private  static String strFileName;
    //private static ServiceTaskType svcTaskType;
    //private static String strBoStatus;
    //private static CharacteristicType cwrCharTypeCd;
    //// CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
    ////private static String strFCOptionType;
    ////  CCB004.008 (CR3135978) - MCruz 2015-01-07 - End
    //private static String strCACIExtSrcId;
    //private static CharacteristicType payCharTypeRsnCode;
    //private static CharacteristicType paymentCharType; //CR107
    //private static String strFTRsnAdjust;
    //private static String strFTRsnCWRAdjust;
    //private static String strFTRsnCACIPay;
    //private static String strFTRsnPay;
    //private static String strFTRsnCancelPay;
    //private static String strFTRsnCACICancelPay;
    //private static String strFTRsnCancelTrans;
    //private static String strFTRsnCancel;
    
    private String strFilePath;
    private ServiceTaskType svcTaskType;
    private String strBoStatus;
    private CharacteristicType cwrCharTypeCd;
    private CharacteristicType payCharTypeRsnCode;
    private CharacteristicType paymentCharType;
    /*
     * End Change - Defect 3232581 - 2015-06-09
     */
    // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
    private String[] nonVolFaTypes;
    // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End
    
   
    //Constants
    private static final String COLL_AGY_REF_ID = "COLL_AGY_REF_ID";
    private static final String CRE_DT = "CRE_DT";
    private static final String REF_HIST_RSN_FLG = "REF_HIST_RSN_FLG";
    private static final String REF_AMT = "REF_AMT";
    /*
     * Start Add - Defect 3232581 - 2015-06-09
     */
    private static final String SEQ_NUM = "SEQ_NUM";
    /*
     * End Add - Defect 3232581 - 2015-06-09
     */
    // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
    //private static FeatureConfiguration distCodeFeatConfig;
    // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
    // IM-033087 - Start    
    /*
     * Start Remove - Defect 3232581 - 2015-06-09
     */
    //private static AdjustmentType parmBalFwdAdjType;
     /*
      * End Remove - Defect 3232581 - 2015-06-09
      */
    // IM-033087 - End
    // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
    private static final String PARM_DESCR_NONVOL_FA = "Non-Voluntary FA Types";
    private static final String DELIMITER = ",";
    // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End
        
    public void validateSoftParameters(boolean isNewRun){
        initializeSoftParams();
        validateSoftParams();
    }
    
    private void initializeSoftParams(){
        /*
         * Start Change - SF-3232581 - 2015-06-15
         */
        //strFilePath = getParameters().getFILE_PATH();
        //strFileName = getParameters().getFILE_NAME();
        //svcTaskType = getParameters().getSVC_TASK_TYPE_CD();
        //strBoStatus = getParameters().getCWR_STATUS_CD();
        //cwrCharTypeCd = getParameters().getCWR_CHAR_TYPE_CD();
        //// CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
        ////distCodeFeatConfig = getParameters().getDIST_CODE_FEAT_CONFIG();
        ////strFCOptionType = getParameters().getDIST_CODE_OPT_TYPE().trim();
        //// CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
        //strCACIExtSrcId = getParameters().getCACI_EXT_SRC_ID().trim();
        //payCharTypeRsnCode = getParameters().getPAY_CHAR_TYPE_RSN_CD();
        //strFTRsnAdjust = getParameters().getCA_FT_RSN_ADJUST().trim();
        //strFTRsnCWRAdjust = getParameters().getCA_FT_RSN_CWR_ADJUST().trim();
        //strFTRsnCACIPay = getParameters().getCA_FT_RSN_CACI_PAY().trim();
        //strFTRsnPay = getParameters().getCA_FT_RSN_PAY().trim();
        //strFTRsnCancelPay = getParameters().getCA_FT_RSN_CANC_PAY().trim();
        //strFTRsnCACICancelPay = getParameters().getCA_FT_RSN_CACI_CANC_PAY().trim();
        //strFTRsnCancelTrans = getParameters().getCA_FT_RSN_CAN_TRANS().trim();
        //strFTRsnCancel =getParameters().getCA_FT_RSN_CANCEL().trim();
        ////SD20132706  CR107
        //paymentCharType = getParameters().getPAYMENT_CHAR_TYPE_CD();
        //// IM-033087 - Start
        //parmBalFwdAdjType = getParameters().getBAL_FWD_ADJ_TYPE_CD();
        
        strFilePath = getParameters().getFILE_PATH();
        svcTaskType = getParameters().getSVC_TASK_TYPE_CD();
        strBoStatus = getParameters().getCWR_STATUS_CD();
        cwrCharTypeCd = getParameters().getCWR_CHAR_TYPE_CD();
        payCharTypeRsnCode = getParameters().getPAY_CHAR_TYPE_RSN_CD();
        paymentCharType = getParameters().getPAYMENT_CHAR_TYPE_CD();
        /*
         * End Change - SF-3232581 - 2015-06-15
         */
        
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Add
        // Non-Voluntary Disconnect FA Types
        String strNonVolDiscFaTypes = getParameters().getNONVOL_DISC_FAT();
        if(!isBlankOrNull(strNonVolDiscFaTypes)) {
            nonVolFaTypes = strNonVolDiscFaTypes.split(DELIMITER);    
        } else {
            nonVolFaTypes = null;
        }     
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Add
     }
    
    private void validateSoftParams(){

        // Check if the override maximum errors is less than 0
        BigInteger parmMaxErrors = getParameters().getSoftMaxErrors();
        if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
            addError(CustomMessageRepository.ni0040_1IntegerParamCannotBeNegative(parmMaxErrors.toString().trim())); 
        }
        validateFilePath();
        validateCWRBOStatus();
        validateCWRCharType();
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
        //if(validateFCOptionType().isFalse()){
        //    addError (CustomMessageRepository.ni0040_1InvalidInputFCOption(strFCOptionType,distCodeFeatConfig.getId().getIdValue()));
        //}
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
        validatePayFTCharType();
        
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Add
        // Validate each FT Type specified in the Non-voluntary Disconnect FA Types parameter
        int faCtr = 0; 
        for(faCtr = 0; faCtr < nonVolFaTypes.length; faCtr++) {
            validateFaType(nonVolFaTypes[faCtr]);
        }
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Add
    }
    
    private void  validateFilePath(){
        // Validate if the file path is valid
        File folder = new File(strFilePath);
        if(!(folder.exists() && folder.isDirectory())) {
            addError(CustomMessageRepository.ni0040_1InvalidFilePath(strFilePath));
        }
    }
    
    private void validateCWRBOStatus(){
        BusinessObject_Id transSrvcTaskBOId = svcTaskType.getRelatedTransactionBO().getId();
        String svcTaskBoName = svcTaskType.getRelatedTransactionBO().getId().getIdValue().trim();
        BusinessObjectStatus boStatus = new BusinessObjectStatus_Id(transSrvcTaskBOId,strBoStatus).getEntity();
        if(isNull(boStatus)){
            addError(CustomMessageRepository.ni0040_1InvalidInputActiveBOStatus(strBoStatus,svcTaskBoName,svcTaskType.getId().getIdValue()));
        }
    
    }
    
    private void validateCWRCharType(){
        CharacteristicEntity charEntity = new CharacteristicEntity_Id(cwrCharTypeCd, CharacteristicEntityLookup.constants.SERVICE_TASK).getEntity();
        if(isNull(charEntity)){
            addError(CustomMessageRepository.ni0040_1InvalidCharTypeForServiceTask(cwrCharTypeCd.getId().getIdValue()));
        }
        
    }
    

    // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
    //private Bool validateFCOptionType(){  
    //    CmBankDistributionCodeLookup bankDistLookup = LookupHelper.getLookupInstance(CmBankDistributionCodeLookup.class, strFCOptionType);
    //    if(bankDistLookup.isValidLookupValue())
    //        return Bool.TRUE;
    //    else
    //        return Bool.FALSE;
    //      
    //}
    // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
    
    private void validatePayFTCharType(){
        CharacteristicEntity charEntity = new CharacteristicEntity_Id(payCharTypeRsnCode, CharacteristicEntityLookup.constants.PAYMENT_TENDER).getEntity();
        if(isNull(charEntity)){
            addError(CustomMessageRepository.ni0040_1InvalidCharTypeForPayTender(payCharTypeRsnCode.getId().getIdValue()));
        }
        charEntity = null;
        //CR 107 SD20132706 - Characteristic 
        charEntity = new CharacteristicEntity_Id(paymentCharType, CharacteristicEntityLookup.constants.PAYMENT).getEntity();
        if(isNull(charEntity)){
            addError(CustomMessageRepository.ni0040_1InvalidCharTypeForPayment(paymentCharType.getId().getIdValue()));
        }
        
    }
    
    // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Add
    private void validateFaType(String strFaType) {
    
        if(strFaType.length() <= FieldActivityType_Id.FIELD_SIZE) {
            FieldActivityType_Id faTypeId = new FieldActivityType_Id(strFaType);
            if(isNull(faTypeId.getEntity())) {
                addError(CustomMessageRepositoryMGE.ccb004InvalidFieldActivityType(PARM_DESCR_NONVOL_FA, strFaType));
            }
        } else {
            addError(CustomMessageRepositoryMGE.ccb004InvalidFieldActivityType(PARM_DESCR_NONVOL_FA, strFaType));
        }
    }
    // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Add

    @SuppressWarnings({ "rawtypes", "unchecked" })
	public JobWork getJobWork() {
        QueryIterator mainIter = retrieveCollAgyHistDetails().iterate();
        return createJobWorkForQueryIterator(mainIter, this);
    }
    
    /**
     * Retrieves all the Records from the Collection History that matches the Current Batch Code and Batch Number
     * @return preparedStatement
     */
    
    private PreparedStatement retrieveCollAgyHistDetails(){
        
        StringBuilder getMeterDetails = new StringBuilder();
        /*
         * Start Change - Defect 3232581 - 2015-06-09
         */
        //getMeterDetails.append("SELECT CREF.COLL_AGY_REF_ID,HIST.CRE_DT,HIST.REF_HIST_RSN_FLG,HIST.REF_AMT ");
        getMeterDetails.append("SELECT CREF.COLL_AGY_REF_ID,HIST.CRE_DT,HIST.REF_HIST_RSN_FLG,HIST.REF_AMT, HIST.SEQ_NUM ");
        /*
         * End Change - Defect 3232581 - 2015-06-09
         */
        getMeterDetails.append("FROM CI_COLL_AGY_HIS HIST, CI_COLL_AGY_REF CREF ");
        getMeterDetails.append("WHERE HIST.COLL_AGY_REF_ID = CREF.COLL_AGY_REF_ID ");
        getMeterDetails.append("AND BATCH_CD = :currBatchCd "); 
        getMeterDetails.append("AND BATCH_NBR  = :currBatchNum  ");
        //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
        //PreparedStatement pstmt =  createPreparedStatement(getMeterDetails.toString());
        PreparedStatement pstmt =  createPreparedStatement(getMeterDetails.toString(), getClass().getName());
        //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
        pstmt.bindId("currBatchCd", getBatchControlId());
        pstmt.bindBigInteger("currBatchNum", getBatchNumber());
        return pstmt;   
    }
    
    public ThreadWorkUnit createWorkUnit(QueryResultRow row){
        
        ThreadWorkUnit threadUnit = new ThreadWorkUnit();             
        CollectionAgencyReferral_Id mtrReadId = (CollectionAgencyReferral_Id) row.getId(COLL_AGY_REF_ID, CollectionAgencyReferral.class);
        threadUnit.setPrimaryId(mtrReadId);
        threadUnit.addSupplementalData(CRE_DT, row.getDate(CRE_DT));
        threadUnit.addSupplementalData(REF_HIST_RSN_FLG, row.getLookup(REF_HIST_RSN_FLG, ReferralHistoryReasonLookup.class));
        threadUnit.addSupplementalData(REF_AMT, row.getBigDecimal(REF_AMT));
        /*
         * Start Add - Defect 3232581 - 2015-06-09
         */
        threadUnit.addSupplementalData(SEQ_NUM, row.getInteger(SEQ_NUM));
        /*
         * End Add - Defect 3232581 - 2015-06-09
         */

        return threadUnit;
    }

    public Class<CmCACICollectionAgencyOutbound_BatchProcessWorker> getThreadWorkerClass() {
        return CmCACICollectionAgencyOutbound_BatchProcessWorker.class;
    }
    
    
    public static class CmCACICollectionAgencyOutbound_BatchProcessWorker
            extends CmCACICollectionAgencyOutbound_BatchProcessWorker_Gen {
        
        private CollectionAgencyReferral_Id collReferralId ;
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Delete
        //private Date creationDate;
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Delete
        private ReferralHistoryReasonLookup refHistRsnLookup;
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Delete
        //private BigDecimal refAmount;
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Delete
        /*
         * Start Add - Defect 3232581 - 2015-06-09
         */
        @SuppressWarnings("unused")
		private BigInteger sequenceNumber;
        /*
         * End Add - Defect 3232581 - 2015-06-09
         */
        // 2015-08-27. SMiran. Defect 3294942. Start Add
        private Date collAgyHisCreDate;
        // 2015-08-27. SMiran. Defect 3294942. End Add
        private BufferedWriter initBufferedWriter;
        private BufferedWriter finBufferedWriter;
        private BufferedWriter peruBufferedWriter;
        private SQLResultRow  mainPersonDtls;
        private Person_Id perId;
        private  DateFormat dateTimeFormat = new DateFormat("yyyy-MM-dd HH:mm:ss");
        
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
        private CharacteristicType bldgMtrCharType;
        private CharacteristicType opsAreaCharType;
        private CharacteristicType rateClassCharType;
        private List<FieldActivityType> nonVoluntaryStopFaTypeList;
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End
        
        private Bool isInitHeaderCreated = Bool.FALSE;
        private Bool isPeruHeaderCreated = Bool.FALSE;
        private Bool isFinHeaderCreated = Bool.FALSE;
        
        //Constants
        private final String INIT_FILE_EXT = "_InitialReferral";
        private final String CHG_FILE_EXT = "_FinancialUpdates";
        private final String PERU_FILE_EXT = "_PersonalUpdates";        
        
        //File  Header Constants
        private final String ACCT_ID = "\"Account_Id\"";
        private final String RFRL_ID = "\"Referral_Id\"";
        private final String PREM_ID = "\"Premise_Id\"";
        private final String RFRL_TYP = "\"Referral_Type\"";
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
        //private final String PER_BUS = "\"Person_Or_Bussiness\"";
        private final String PER_BUS = "\"Person_Or_Business\"";
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End
        private final String PER_NAM = "\"Person_Name\"";
        private final String MAIL_ADDR1 =  "\"Mail_To_Address_1\"";
        private final String MAIL_ADDR2 = "\"Mail_To_Address_2\"";
        private final String MAIL_ADDR3 = "\"Mail_To_Address_3\"";
        private final String MAIL_ADDR4 = "\"Mail_To_Address_4\"";
        private final String MAIL_CITY ="\"Mail_To_City\"";
        private final String MAIL_STATE ="\"Mail_To_State\"";
        private final String MAIL_ZIP ="\"Mail_To_Zip\"";
        private final String SRVC_ADDR1 = "\"Service_Address_1\"";
        private final String SRVC_ADDR2 = "\"Service_Address_2\"";
        private final String SRVC_ADDR3 = "\"Service_Address_3\"";
        private final String SRVC_ADDR4 ="\"Service_Address_4\"";
        private final String SRVC_CITY ="\"Service_City\"";
        private final String SRVC_STATE = "\"Service_State\"";
        private final String SRVC_ZIP ="\"Service_Zip\"";
        private final String PER_ID ="\"Person_Id\"";
        private final String PHN_MAIN ="\"Phone_Number_Main\"";
        private final String PHN_WRK ="\"Phone_Number_Work\"";
        private final String PHN_CELL="\"Phone_Number_Cell\"";
        private final String ON_DT ="\"Turn_On_Date\"";
        private final String OFF_DT ="\"Turn_Off_Date\"";
        private final String LAST_PAY_DT = "\"Last_Payment_Date\"";
        private final String AGNCY_NAME = "\"AgencyName\"";
        private final String IMPRT_DT= "\"ImportDate\"";
        private final String CUR_BAL ="\"CurrentBalance\"";
        private final String AMOUNT ="\"Amount\"";
        private final String TRANSACT_DTTM ="\"Transaction_Dttm\"";
        private final String TRANSACT_ID ="\"Transaction_Id\"";
        private final String UPD_RSN ="\"Update_Reason\"";
        private final String EXPRT_DTTM ="\"Export_Date\"";
        private final String EMPTY_STRING_QUOTE = "\"\"";
        
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Add
        private final String HDR_PER_ID = "\"PersonId\"";
        private final String HDR_CIS_DIVISION = "\"CIS_Division\"";
        private final String HDR_SA_TYPE = "\"SA_Type\"";
        private final String HDR_SA_RATE_CL = "\"SA_Rate_Class\"";
        private final String HDR_FINAL_BILL_DT = "\"Final_Bill_Date\"";
        private final String HDR_BLDG_MTR = "\"Building_Meter\"";
        private final String HDR_OPS_AREA = "\"Region\"";
        private final String HDR_DISCONNECT_RSN = "\"Disconnect_Reason\"";  
        private final String VOLUNTARY_FA = "Voluntary";
        private final String NONVOLUNTARY_FA = "Non-voluntary";
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Add
        
        /* START ADD - JHERNA - 2021-11-03 - SysAid#383853 */
        // Add 2 new header fields
        private final String DELINQUENCY_DT = "\"Delinquency Date\"";
        private final String DELINQUENCY_AMT = "\"Delinquency Amount\"";        
        /* END ADD - JHERNA - 2021-11-03 - SysAid#383853 */
        
        // Initial referral Constnats
        private final String ACCOUNT_ID = "ACCT_ID";
        private final String PREMISE_ID = "CHAR_PREM_ID";
        private final String SA_ID = "SA_ID";
        private final String SA_TYPE_DESCR = "DESCR";
        private final String MAIN_PER_ID = "PER_ID";
        private final String TURN_OFF_DT ="END_DT";
        private final String TURN_ON_DT ="START_DT";
        private final String FT_ID ="FT_ID";
        private final String FREEZE_DTTM ="FREEZE_DTTM";
        private final String PAY_ID ="PARENT_ID";
        private final String  CUR_AMT ="CUR_AMT";
        private final String FT_TYPE_FLG = "FT_TYPE_FLG";
        private final String PER_IDN = "PER_IDNTFR";
        private final String MAIN_PH = "PER_MAIN_PHONE";
        private final String CELL_PH = "CELL_PHONE";
        private final String POSTAL_PH = "WORK_PHONE";
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Delete
        //private final String AGY_NAME = "CACI";
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Delete
        private final String P_B_FLAG = "PER_OR_BUS_FLG";
        private final String PER_NAME = "ENTITY_NAME";
        
        private final String COLUMN_SEPERATOR = ",";
        
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Add
        private static final MaintenanceObject_Id COLL_AGY_REF_MO = new MaintenanceObject_Id("COLL AGY REF");
        private static final BusinessObject_Id  COLL_AGY_PLACE_TYPE_BO = new BusinessObject_Id("CM-CollAgencyPlacementType");
        private final static CharacteristicType_Id RELATED_SA_CHAR_TYPE = new CharacteristicType_Id("C1-SA");
        // CCB004.008 (CR3135987) - MCruz 2015-01-07 - End Add

        // START ADD - JRAYMU - 2020-10-22 - CCB017
        private final String ENCR_PER_IDN = "ENCR_PER_IDNTFR";
        private static final String CI_PER_ID = "CI_PER_ID";
        private static final String PER_ID_NBR = "PER_ID_NBR";
        private static final String ID_TYPE_CD = "ID_TYPE_CD";
        private static final FeatureConfiguration_Id SCH_CONST_FEAT_CONF = new FeatureConfiguration_Id("SCHEMACONST");
        // END ADD - JRAYMU - 2020-10-22 - CCB017
        
        /*
         * Start Add - Defect 3232581 - 2015-06-09
         */
        private String strFilePath;
        private String strFileName;
        private ServiceTaskType svcTaskType;
        private String strBoStatus;
        private CharacteristicType cwrCharTypeCd;
        private String strCACIExtSrcId;
        private CharacteristicType payCharTypeRsnCode;
        private CharacteristicType paymentCharType;
        private String strFTRsnAdjust;
        private String strFTRsnCWRAdjust;
        private String strFTRsnCACIPay;
        private String strFTRsnPay;
        private String strFTRsnCancelPay;
        private String strFTRsnCACICancelPay;
        private String strFTRsnCancelTrans;
        private String strFTRsnCancel;
        private AdjustmentType parmBalFwdAdjType;
        /*
         * End Add - Defect 3232581 - 2015-06-09
         */
        // 2016-01-26. SMiran. SysAid68527. Start Add
        private List<FinancialTransaction_Id> ftIdList = new ArrayList<FinancialTransaction_Id>();
        // 2016-01-26. SMiran. SysAid68527. End Add
        
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Add
        @Override
        public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
            
            /*
             * Start Add - Defect 3232581 - 2015-06-09
             */
            strFilePath = getParameters().getFILE_PATH();
            strFileName = getParameters().getFILE_NAME();
            svcTaskType = getParameters().getSVC_TASK_TYPE_CD();
            strBoStatus = getParameters().getCWR_STATUS_CD();
            cwrCharTypeCd = getParameters().getCWR_CHAR_TYPE_CD();
            strCACIExtSrcId = getParameters().getCACI_EXT_SRC_ID().trim();
            payCharTypeRsnCode = getParameters().getPAY_CHAR_TYPE_RSN_CD();
            strFTRsnAdjust = getParameters().getCA_FT_RSN_ADJUST().trim();
            strFTRsnCWRAdjust = getParameters().getCA_FT_RSN_CWR_ADJUST().trim();
            strFTRsnCACIPay = getParameters().getCA_FT_RSN_CACI_PAY().trim();
            strFTRsnPay = getParameters().getCA_FT_RSN_PAY().trim();
            strFTRsnCancelPay = getParameters().getCA_FT_RSN_CANC_PAY().trim();
            strFTRsnCACICancelPay = getParameters().getCA_FT_RSN_CACI_CANC_PAY().trim();
            strFTRsnCancelTrans = getParameters().getCA_FT_RSN_CAN_TRANS().trim();
            strFTRsnCancel =getParameters().getCA_FT_RSN_CANCEL().trim();
            paymentCharType = getParameters().getPAYMENT_CHAR_TYPE_CD();
            parmBalFwdAdjType = getParameters().getBAL_FWD_ADJ_TYPE_CD(); 
            /*
             * End Add - Defect 3232581 - 2015-06-09
             */
            
            // Premise Building Meter Characteristic Type
            bldgMtrCharType = getParameters().getBLDGMTR_CHAR_TYPE_CD();
            // Premise Operations Area Characteristic Type
            opsAreaCharType = getParameters().getOPSAREA_CHAR_TYPE_CD();
            // SA Rate Class Characteristic Type
            rateClassCharType = getParameters().getRATECLASS_CHAR_TYPE_CD();
            
            // Non-Voluntary Disconnect FA Types
            String strNonVolDiscFaTypes = getParameters().getNONVOL_DISC_FAT();
            nonVoluntaryStopFaTypeList = new ArrayList<FieldActivityType>();
            for (String nonVolFaType : strNonVolDiscFaTypes.split(DELIMITER)) {
                nonVoluntaryStopFaTypeList.add(new FieldActivityType_Id(nonVolFaType).getEntity());
            }

        }
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Add

        private void initializeWorkUnitParams(ThreadWorkUnit unit){
            
            collReferralId = (CollectionAgencyReferral_Id) unit.getPrimaryId();
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Delete
            //creationDate = ((Date) unit.getSupplementallData(CRE_DT));
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Delete
            refHistRsnLookup = ((ReferralHistoryReasonLookup) unit.getSupplementallData(REF_HIST_RSN_FLG));
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Delete
            //refAmount = ((BigDecimal) unit.getSupplementallData(REF_AMT));
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Delete
            /*
             * Start Add - Defect 3232581 - 2015-06-09
             */
            sequenceNumber = (BigInteger) unit.getSupplementallData(SEQ_NUM);
            /*
             * End Add - Defect 3232581 - 2015-06-09
             */
            // 2015-08-27. SMiran. Defect 3294942. Start Add
            collAgyHisCreDate = (Date) unit.getSupplementallData(CRE_DT);
            // 2015-08-27. SMiran. Defect 3294942. End Add
        }

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new SingleTransactionStrategy(this);
        }

        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {

            initializeWorkUnitParams(unit);
            
            if(refHistRsnLookup.isInitialReferral()){
            /*
             * Start Change - 2014-01-13 Ujesh IM-043433
             */                 
                //processInitialReferralRecord();
                if(!processInitialReferralRecord())
                    return false;
            /*
             * End Change - 2014-01-13 Ujesh IM-043433
             */                 
            }else if(refHistRsnLookup.isReferralPaid()||refHistRsnLookup.isReferralCancellation() || refHistRsnLookup.isChangeReferral() ){
                processFinancialUpdateRecord();
                
            }else if(refHistRsnLookup.isPersonalUpdates()){
            /*
             * Start Change - 2014-01-13 Ujesh IM-043433
             */         
                //processPersonalUpdateRecord();
                if(!processPersonalUpdateRecord())
                    return false;
            /*
             * End Change - 2014-01-13 Ujesh IM-043433
             */                 
            }else{
                logError(CustomMessageRepository.ni0040_1InvalidReferralHistoryReason(refHistRsnLookup.getLookupValue().fetchLanguageDescription()));
                return false;
            }
            
            return true;
        }
        
        /**
         *  This method process the Collection Referral of Type Initial Referral Record .
         */
        
        /*
         * Start Change - 2014-01-13 Ujesh IM-043433
         */   
        
        //private void processInitialReferralRecord(){
        private boolean processInitialReferralRecord(){
            
            List<CmCACIOutboundData> premiseDataList = getCollectionAgencyReferralData();
            if(isNull(premiseDataList))
                return false;
        
        /*
         * End Change - 2014-01-13 Ujesh IM-043433
         */     
            
            if(!premiseDataList.isEmpty()){
                // Create Header Line   
                  if(isInitHeaderCreated.isFalse()){    
                     openFileWriter(refHistRsnLookup);
                     createInitHeaderLine();
                      isInitHeaderCreated = Bool.TRUE;
                  }

                  writeDataToInitFile(premiseDataList);
            }
            
        /*
         * Start Change - 2014-01-13 Ujesh IM-043433
         */ 
            
            return true;
        /*
         * End Change - 2014-01-13 Ujesh IM-043433
         */ 
          
        }
        
        /**
         *  This method process the Collection Referral of Type Person Information Record .
         */  
        
        /*
         * Start Change - 2014-01-13 Ujesh IM-043433
         */ 
        
        //private void processPersonalUpdateRecord(){
        private boolean processPersonalUpdateRecord(){
            
            //Retrieve all the Writeoff Process SAs for the Collection Referral
            List<CmCACIOutboundData> premiseDataList = getCollectionAgencyReferralData();
            if(isNull(premiseDataList))
                return false;
            /*
             * End Change - 2014-01-13 Ujesh IM-043433
             */             
            
            
            if(!premiseDataList.isEmpty()){     
              if(isPeruHeaderCreated.isFalse()){    
                     openFileWriter(refHistRsnLookup);
                     createPeruHeaderLine();
                     isPeruHeaderCreated = Bool.TRUE;
              }
              writeDataToPeruFile(premiseDataList);
            }
            /*
             * Start Change - 2014-01-13 Ujesh IM-043433
             */ 
            return true;
            /*
             * End Change - 2014-01-13 Ujesh IM-043433
             */             
            
        }

        // START ADD - JRAYMU - 2020-10-22 - CCB017
        /**
         * This will decrypt encrypted strings
         * @param Table Name
         * @param Field Name
         * @param Filter Field
         * @param Filter Value
         * @param Cipher Text
         * @return decrypted text
         */
        private String decryptData(String tableName, String fieldName, String filterField, String filterVal, String cipherTxt) {
            FieldEncryptionDecryptionData decryptData = FieldEncryptionDecryptionData.Factory.newInstance();
            decryptData.setTableName(tableName);
            decryptData.setFieldName(fieldName);
            decryptData.setFilterField(filterField);
            decryptData.setFilterValue(filterVal);
            decryptData.setCipherText(cipherTxt);

            FieldEncryptionDecryption decrypt = FieldEncryptionDecryption.Factory.newInstance();
            DecryptedValue decryptedValue = decrypt.decrypt(decryptData);

            return (isNull(decryptedValue)) ? "": decryptedValue.getBuffer().toString().trim();
        }
        // END ADD - JRAYMU - 2020-10-22 - CCB017
        
        /**
         *  This method process the Collection Referral of Type Financial Information Record .
         */         
        @SuppressWarnings("deprecation")
		private void processFinancialUpdateRecord(){
            List<SQLResultRow> resultRowList = null;
            // IM-033087 Start
            //Map<Premise_Id,Money> premBalMap = new HashMap<Premise_Id,Money>();
            // IM-033087 End
            
            //Record Variables
            Account_Id acctId = null;
            Premise_Id premId = null;
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Delete
            //ServiceAgreement_Id saId = null;
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Delete
            FinancialTransaction_Id ftId = null;
            DateTime FTfreezeDttm  = null;
            Payment_Id payId = null;
            Money ftCurrAmnt = null;
            Money ftPremiseAmnt = Money.ZERO;
            FinancialTransactionTypeLookup ftLookup = null;
            String strFTReason= null;

            // IM-033087 Start
            //premBalMap = getCurrentBalanceByPremise();
            // IM-033087 End
            
            resultRowList = getReferralFTDetails();
            
            
            if(resultRowList.size() >0 ){
                if(isFinHeaderCreated.isFalse()){   
                      openFileWriter(refHistRsnLookup);
                         createFinHeaderLine();
                      isFinHeaderCreated = Bool.TRUE;
                  } 
            }
            
            StringBuilder recordLine = null;
            //Process FT Starts
            for(SQLResultRow saResultRow : resultRowList){
                //initialize variables
                premId = null;
                // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Delete
                //saId = null;
                // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Delete
                ftId = null;
                payId = null;
                acctId = null;
                FTfreezeDttm = null;
                ftCurrAmnt = Money.ZERO;
                ftPremiseAmnt = Money.ZERO;
                strFTReason = "";
                
                recordLine = new StringBuilder();
                premId =  (Premise_Id)saResultRow.getId(PREMISE_ID, Premise.class);
                // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Delete
                //saId = (ServiceAgreement_Id)saResultRow.getId(SA_ID, ServiceAgreement.class);
                // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Delete
                ftId = (FinancialTransaction_Id)saResultRow.getId(FT_ID, FinancialTransaction.class);
                FTfreezeDttm =  saResultRow.getDateTime(FREEZE_DTTM); 
                payId  =  (Payment_Id)saResultRow.getId(PAY_ID, Payment.class);
                acctId  =  (Account_Id)saResultRow.getId(ACCOUNT_ID,Account.class);
                ftCurrAmnt = saResultRow.getMoney(CUR_AMT);
                ftLookup = saResultRow.getLookup(FT_TYPE_FLG,FinancialTransactionTypeLookup.class);
                
                if(refHistRsnLookup.isReferralCancellation()){ //Last Point in the Mapping table
                    strFTReason = strFTRsnCancel;
                    ftCurrAmnt = Money.ZERO;
                    ftPremiseAmnt = Money.ZERO;
                }else{
                    strFTReason = determineFTReasonFlag(ftLookup,payId,ftCurrAmnt);
                    //IM-033087 Start
                    // ftPremiseAmnt = premBalMap.get(premId);     
                    ftPremiseAmnt = retrieveSABalances(); 
                    //IM-033087 End
                    //FS Section 4.4.2.4.1
                     if(ftPremiseAmnt.isNegative()){
                         ftCurrAmnt = ftCurrAmnt.add(ftPremiseAmnt);
                         ftPremiseAmnt = Money.ZERO;
                     }
                }
                if(isBlankOrNull(strFTReason)){ // FS - 4.4.2.2.1
                    logError(CustomMessageRepository.ni0040_1FTReasonCannotBeDetermined(payId.getIdValue()));
                    continue;
                }

                 //Iterate Premise List and Write to File
                // 2016-01-26. SMiran. SysAid68527. Start Add
                if (!ftIdList.contains(ftId)){
                // 2016-01-26. SMiran. SysAid68527. End Add
                    recordLine.append(toUpperAndEncloseinQuote(acctId.getIdValue().trim()));
                    recordLine.append(COLUMN_SEPERATOR);
                    recordLine.append(toUpperAndEncloseinQuote(collReferralId.getIdValue().trim()));
                    recordLine.append(COLUMN_SEPERATOR);
                    recordLine.append(toUpperAndEncloseinQuote(premId.getIdValue().trim()));
                    recordLine.append(COLUMN_SEPERATOR);
                    recordLine.append(toUpperAndEncloseinQuote(ftPremiseAmnt.toPlainString()));
                    recordLine.append(COLUMN_SEPERATOR);
                    recordLine.append(toUpperAndEncloseinQuote(ftCurrAmnt.toPlainString()));
                    recordLine.append(COLUMN_SEPERATOR);
                    recordLine.append(toUpperAndEncloseinQuote(FTfreezeDttm.toString(dateTimeFormat)));
                    recordLine.append(COLUMN_SEPERATOR);
                    recordLine.append(toUpperAndEncloseinQuote(ftId.getIdValue().trim()));
                    recordLine.append(COLUMN_SEPERATOR);
                    recordLine.append(toUpperAndEncloseinQuote(strFTReason));
                    recordLine.append(COLUMN_SEPERATOR);
                    recordLine.append(toUpperAndEncloseinQuote(getProcessDateTime().toString(dateTimeFormat)));
                    writeLineFinFile(recordLine.toString());
                    recordLine = null;
                // 2016-01-26. SMiran. SysAid68527. Start Add
                    ftIdList.add(ftId);
                }
                // 2016-01-26. SMiran. SysAid68527. End Add
            }
            
            // START ADD - JHERNA - 2020-08-31 - SA-15994
            /* Based on 2015 PWC fix by Ujesh */
            if (resultRowList.size() == 0
            		&& refHistRsnLookup.isReferralCancellation()) {
            	
                if(isFinHeaderCreated.isFalse()){   
                    openFileWriter(refHistRsnLookup);
                       createFinHeaderLine();
                    isFinHeaderCreated = Bool.TRUE;
                } 
				premId = null;
				ftId = null;
				payId = null;
				acctId = null;
				FTfreezeDttm = null;

				strFTReason = strFTRsnCancel;
				ftCurrAmnt = Money.ZERO;
				ftPremiseAmnt = Money.ZERO;
				
				recordLine = new StringBuilder();
				
				recordLine.append(toUpperAndEncloseinQuote(collReferralId.getEntity().getAccount().getId().getIdValue().trim()));
				recordLine.append(COLUMN_SEPERATOR);
				recordLine.append(toUpperAndEncloseinQuote(collReferralId.getIdValue().trim()));
				recordLine.append(COLUMN_SEPERATOR);
				recordLine.append(toUpperAndEncloseinQuote("          "));
				recordLine.append(COLUMN_SEPERATOR);
				recordLine.append(toUpperAndEncloseinQuote(ftPremiseAmnt.toPlainString()));
				recordLine.append(COLUMN_SEPERATOR);
				recordLine.append(toUpperAndEncloseinQuote(ftCurrAmnt.toPlainString()));
				recordLine.append(COLUMN_SEPERATOR);
				recordLine.append(toUpperAndEncloseinQuote("                   "));
				recordLine.append(COLUMN_SEPERATOR);
				recordLine.append(toUpperAndEncloseinQuote("            "));
				recordLine.append(COLUMN_SEPERATOR);
				recordLine.append(toUpperAndEncloseinQuote(strFTReason));
				recordLine.append(COLUMN_SEPERATOR);
				recordLine.append(toUpperAndEncloseinQuote(getProcessDateTime().toString(dateTimeFormat)));
				
				writeLineFinFile(recordLine.toString());
				recordLine = null;
            	
            }
            // END ADD - JHERNA - 2020-08-31 - SA-15994
    }
        
/**
 * This method retrieves all the FTs of the current Referral excluding the Adjustments transfer of same Char premise Id or to Write Off process
 * @return SQLResultRow
 */
        
        private List<SQLResultRow> getReferralFTDetails(){ 
            
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Change
            //// SD20131106-1 Defect - FTs of SAs not in WriteOff Process are shown in output file.
            //// Only SAs of Write off Processes are selected rather than all SAs of the premise
            //List<SQLResultRow> resultRowList = null;
            //StringBuilder queryString = new StringBuilder();
            //queryString.append("SELECT FT.FT_ID,FT.PARENT_ID,FT.FT_TYPE_FLG,FT.CUR_AMT,FT.FREEZE_DTTM,SA1.CHAR_PREM_ID, SA1.ACCT_ID,SA1.SA_ID ");
            //queryString.append("FROM CI_FT FT, CI_SA SA1 ");
            //queryString.append("WHERE FT.SA_ID IN ( ");
            //  queryString.append("SELECT SA2.SA_ID FROM CI_SA SA2 ");
            //  queryString.append("WHERE SA2.SA_ID IN ( ");
            //  queryString.append("SELECT SA.SA_ID ");
            //  queryString.append("FROM  CI_COLL_AGY_REF CREF,  CI_WO_PROC WPROC, CI_WO_PROC_SA WPSA, CI_SA SA ");
            //  queryString.append("WHERE CREF.COLL_AGY_REF_ID =  :collRefId ");
            //  queryString.append("AND WPROC.WO_PROC_ID  = WPSA.WO_PROC_ID  ");
            //  queryString.append("AND CREF.WO_PROC_ID =  WPROC.WO_PROC_ID ");
            //  queryString.append("AND WPSA.SA_ID = SA.SA_ID ))  ");
            //  queryString.append("AND FT.FREEZE_SW='Y' ");
            //  queryString.append("AND FT.REDUNDANT_SW='N' ");
            //  queryString.append("AND FT.SA_ID = SA1.SA_ID "); 
            //    queryString.append(" AND (TRUNC(FT.FREEZE_DTTM) > (SELECT MAX (CH1.CRE_DT) FROM CI_COLL_AGY_HIS CH1 ");
            //    queryString.append("WHERE CH1.COLL_AGY_REF_ID = :collRefId  ");
            //    queryString.append("AND CH1.REF_HIST_RSN_FLG != :personUpdFlg ");
            //    queryString.append("AND CH1.BATCH_CD = :currBatchCd  "); 
            //    queryString.append("AND CH1.BATCH_NBR < :currBatchNbr ");
            //  queryString.append("AND CH1.SEQ_NUM = ( SELECT MAX(CH2.SEQ_NUM) ");
            //         queryString.append("FROM CI_COLL_AGY_HIS CH2  WHERE CH2.COLL_AGY_REF_ID = :collRefId ");
            //         queryString.append("AND CH2.BATCH_CD = :currBatchCd ");
            //         queryString.append("AND CH2.BATCH_NBR < :currBatchNbr  )) ");
            //    queryString.append("AND FT.FREEZE_DTTM <= :processDttm ) ");
            //  queryString.append("AND NOT EXISTS ");
            //      queryString.append("(SELECT  FT2.FT_ID  FROM CI_FT FT2 , CI_ADJ ADJ, CI_ADJ ADJ1 ");
            //      queryString.append("WHERE FT2.FT_ID =FT.FT_ID ");
            //      queryString.append("AND ADJ.ADJ_ID = FT2.SIBLING_ID ");
            //      queryString.append("AND ADJ.XFER_ADJ_ID IS NOT  NULL ");
            //        queryString.append("  AND ADJ1.ADJ_ID = ADJ.XFER_ADJ_ID  ");
            //      queryString.append(" AND ADJ1.SA_ID  IN ");
            //          queryString.append("(SELECT SA2.SA_ID FROM CI_SA SA2 ");
            //          queryString.append("WHERE SA2.CHAR_PREM_ID IN (  ");
            //             queryString.append("SELECT SA.CHAR_PREM_ID ");
            //             queryString.append("FROM  CI_COLL_AGY_REF CREF,  CI_WO_PROC WPROC, CI_WO_PROC_SA WPSA, CI_SA SA ");
            //             queryString.append("WHERE CREF.COLL_AGY_REF_ID =  :collRefId ");
            //             queryString.append("AND WPROC.WO_PROC_ID  = WPSA.WO_PROC_ID  ");
            //             queryString.append("AND CREF.WO_PROC_ID =  WPROC.WO_PROC_ID ");
            //             queryString.append("AND WPSA.SA_ID = SA.SA_ID ");
            //             queryString.append("))) ");
            //// IM-033087 - Start - For Excluding the Balance Fwd Adjustments created as a part of Conversion
            //    if(!isNull(parmBalFwdAdjType)){
            //          queryString.append("  AND NOT EXISTS ( SELECT 'X' FROM CI_ADJ ADJ where ADJ.ADJ_ID = FT.SIBLING_ID AND ADJ.ADJ_TYPE_CD = :balFwdAdjTypeCd )  ");
            //    }
            //                      
            //// IM-033087 - End
            //
            //
            //PreparedStatement pstmt =  createPreparedStatement(queryString.toString());
            //
            //pstmt.bindId("collRefId", collReferralId);
            //pstmt.bindId("currBatchCd", getBatchControlId());
            //pstmt.bindLookup("personUpdFlg", ReferralHistoryReasonLookup.constants.PERSONAL_UPDATES);
            //pstmt.bindDateTime("processDttm",getProcessDateTime());
            //pstmt.bindBigInteger("currBatchNbr", getBatchNumber());
            ////IM-033087 - Start            
            //if(!isNull(parmBalFwdAdjType)){
            //  pstmt.bindEntity("balFwdAdjTypeCd", parmBalFwdAdjType);
            //  
            //}
            //// IM-033087 - End    
            //resultRowList = pstmt.list();
            //pstmt.close();
            //return resultRowList;
            
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");
            stringBuilder.append(  "FT.FT_ID, ");
            stringBuilder.append(  "FT.PARENT_ID, ");
            stringBuilder.append(  "FT.FT_TYPE_FLG, ");
            stringBuilder.append(  "FT.CUR_AMT, ");
            stringBuilder.append(  "FT.FREEZE_DTTM, ");
            stringBuilder.append(  "SA.CHAR_PREM_ID, ");
            stringBuilder.append(  "SA.ACCT_ID, ");
            stringBuilder.append(  "SA.SA_ID ");
            stringBuilder.append("FROM ");
            stringBuilder.append(  "F1_SVC_TASK_REL_OBJ STRO, ");
            stringBuilder.append(  "F1_SVC_TASK STASK, ");
            stringBuilder.append(  "F1_SVC_TASK_TYPE STT, ");
            stringBuilder.append(  "F1_SVC_TASK_CHAR STCH, ");
            stringBuilder.append(  "CI_SA SA, ");
            stringBuilder.append(  "CI_FT FT ");
            stringBuilder.append("WHERE ");
            stringBuilder.append(  "STRO.PK_VALUE1 = :collRefId ");
            stringBuilder.append(  "AND STRO.MAINT_OBJ_CD = :serviceTaskMo ");
            stringBuilder.append(  "AND STASK.F1_SVC_TASK_ID = STRO.F1_SVC_TASK_ID ");
            stringBuilder.append(  "AND STT.BUS_OBJ_CD = :taskTypeBo ");
            stringBuilder.append(  "AND STASK.BUS_OBJ_CD = STT.TRANS_BUS_OBJ_CD ");
            stringBuilder.append(  "AND STASK.F1_STASK_TYPE_CD = STT.F1_STASK_TYPE_CD ");
            stringBuilder.append(  "AND STCH.F1_SVC_TASK_ID = STASK.F1_SVC_TASK_ID ");
            stringBuilder.append(  "AND STCH.CHAR_TYPE_CD = :relSaCharType ");
            stringBuilder.append(  "AND (SA.SA_ID = TRIM(STCH.CHAR_VAL) ");
            stringBuilder.append(    "OR SA.SA_ID = TRIM(STCH.ADHOC_CHAR_VAL) ");
            stringBuilder.append(    "OR SA.SA_ID = TRIM(STCH.CHAR_VAL_FK1)) ");
            stringBuilder.append(  "AND FT.SA_ID = SA.SA_ID ");
            stringBuilder.append(  "AND FT.FREEZE_SW = :isFrozen ");
            stringBuilder.append(  "AND FT.REDUNDANT_SW = :isRedundant ");
            // 2015-08-27. SMiran. Defect 3294942. Start Change
            //stringBuilder.append(  "AND TRUNC(FT.FREEZE_DTTM) > ( ");
            //stringBuilder.append(    "SELECT ");
            //stringBuilder.append(      "CH1.CRE_DT ");
            //stringBuilder.append(    "FROM ");
            //stringBuilder.append(      "CI_COLL_AGY_HIS CH1 ");
            //stringBuilder.append(    "WHERE ");
            //stringBuilder.append(      "CH1.COLL_AGY_REF_ID = :collRefId ");
            ///*
            // * Start Change - Defect 3232581 - 2015-06-09
            // */
            ////stringBuilder.append(      "AND CH1.REF_HIST_RSN_FLG <> :personUpdFlg ");
            ////stringBuilder.append(      "AND CH1.BATCH_CD = :currBatchCd ");
            ////stringBuilder.append(      "AND CH1.BATCH_NBR <= :currBatchNbr ");
            ////stringBuilder.append(      "AND CH1.SEQ_NUM = ( ");
            ////stringBuilder.append(        "SELECT ");
            ////stringBuilder.append(          "MAX(CH2.SEQ_NUM) ");
            ////stringBuilder.append(        "FROM ");
            ////stringBuilder.append(          "CI_COLL_AGY_HIS CH2 ");
            ////stringBuilder.append(        "WHERE ");
            ////stringBuilder.append(          "CH2.COLL_AGY_REF_ID = CH1.COLL_AGY_REF_ID ");
            ////stringBuilder.append(          "AND CH2.BATCH_CD = CH1.BATCH_CD ");
            ////stringBuilder.append(          "AND CH2.BATCH_NBR <= CH1.BATCH_NBR)) ");
            
            //stringBuilder.append(      "AND CH1.SEQ_NUM = ( ");
            //stringBuilder.append(        "SELECT ");
            //stringBuilder.append(          "MAX(CH2.SEQ_NUM) ");
            //stringBuilder.append(        "FROM ");
            //stringBuilder.append(          "CI_COLL_AGY_HIS CH2 ");
            //stringBuilder.append(        "WHERE ");
            //stringBuilder.append(          "CH2.COLL_AGY_REF_ID = CH1.COLL_AGY_REF_ID ");
            //stringBuilder.append(          "AND CH2.REF_HIST_RSN_FLG <> :personUpdFlg ");
            //stringBuilder.append(          "AND CH2.SEQ_NUM < :sequenceNumber ");
            //stringBuilder.append(          "AND CH2.BATCH_CD = :currBatchCd ");
            //stringBuilder.append(          "AND CH2.BATCH_NBR <= :currBatchNbr)) ");
            ///*
            // * End Change - Defect 3232581 - 2015-06-09
            // */
            //stringBuilder.append(  "AND FT.FREEZE_DTTM <= :processDttm ");
            stringBuilder.append(  "AND TRUNC(FT.FREEZE_DTTM) = :collAgyHisCreDate ");
            // 2016-01-26. SMiran. SysAid68527. Start Delete
            //if (refHistRsnLookup.isReferralPaid()){
            //	stringBuilder.append(  "AND FT.FT_TYPE_FLG = 'PS' ");
            //}
            //if (refHistRsnLookup.isChangeReferral()){
            //	stringBuilder.append(  "AND FT.FT_TYPE_FLG IN ('PX','AD','AX') ");
            //}
            // 2016-01-26. SMiran. SysAid68527. End Delete
            // 2015-08-27. SMiran. Defect 3294942. End Change
            stringBuilder.append(  "AND NOT EXISTS ( ");
            stringBuilder.append(    "SELECT ");
            stringBuilder.append(      "FT2.FT_ID ");
            stringBuilder.append(    "FROM ");
            stringBuilder.append(      "CI_FT FT2, ");
            stringBuilder.append(      "CI_ADJ ADJ, ");
            stringBuilder.append(      "CI_ADJ ADJ1, ");
            stringBuilder.append(      "CI_SA SA1 ");
            stringBuilder.append(    "WHERE ");
            stringBuilder.append(      "FT2.FT_ID = FT.FT_ID ");
            stringBuilder.append(      "AND ADJ.ADJ_ID = FT2.SIBLING_ID ");
            // 2015-10-15. SMiran. SF-59547. Start Add
            stringBuilder.append(      "AND ADJ.ADJ_TYPE_CD = 'SYSXFR3' ");
            // 2015-10-15. SMiran. SF-59547. End Add
            stringBuilder.append(      "AND ADJ.XFER_ADJ_ID IS NOT NULL ");
            stringBuilder.append(      "AND ADJ1.ADJ_ID = ADJ.XFER_ADJ_ID ");
            stringBuilder.append(      "AND SA1.SA_ID = ADJ1.SA_ID ");
            stringBuilder.append(      "AND SA1.CHAR_PREM_ID IN ( ");
            stringBuilder.append(        "SELECT ");
            stringBuilder.append(          "SA1.CHAR_PREM_ID ");
            stringBuilder.append(        "FROM ");
            stringBuilder.append(          "F1_SVC_TASK_REL_OBJ STRO1, ");
            stringBuilder.append(          "F1_SVC_TASK STASK1, ");
            stringBuilder.append(          "F1_SVC_TASK_TYPE STT1, ");
            stringBuilder.append(          "F1_SVC_TASK_CHAR STCH1, ");
            stringBuilder.append(          "CI_SA SA1 ");
            stringBuilder.append(        "WHERE ");
            stringBuilder.append(          "STRO1.PK_VALUE1 = :collRefId ");
            stringBuilder.append(          "AND STRO1.MAINT_OBJ_CD = :serviceTaskMo ");
            stringBuilder.append(          "AND STASK1.F1_SVC_TASK_ID = STRO1.F1_SVC_TASK_ID ");
            stringBuilder.append(          "AND STT1.BUS_OBJ_CD = :taskTypeBo ");
            stringBuilder.append(          "AND STASK1.BUS_OBJ_CD = STT1.TRANS_BUS_OBJ_CD ");
            stringBuilder.append(          "AND STASK1.F1_STASK_TYPE_CD = STT1.F1_STASK_TYPE_CD ");
            stringBuilder.append(          "AND STCH1.F1_SVC_TASK_ID = STASK1.F1_SVC_TASK_ID ");
            stringBuilder.append(          "AND STCH1.CHAR_TYPE_CD = :relSaCharType ");
            stringBuilder.append(          "AND (SA1.SA_ID = TRIM(STCH1.CHAR_VAL) ");
            stringBuilder.append(            "OR SA1.SA_ID = TRIM(STCH1.ADHOC_CHAR_VAL) ");
            stringBuilder.append(            "OR SA1.SA_ID = TRIM(STCH1.CHAR_VAL_FK1)))) ");
            if (notNull(parmBalFwdAdjType)){
                stringBuilder.append(  "AND NOT EXISTS ( ");
                stringBuilder.append(    "SELECT ");
                stringBuilder.append(      "'X' ");
                stringBuilder.append(    "FROM ");
                stringBuilder.append(      "CI_ADJ ADJ ");
                stringBuilder.append(    "WHERE ");
                stringBuilder.append(      "ADJ.ADJ_ID = FT.SIBLING_ID ");
                stringBuilder.append(      "AND ADJ.ADJ_TYPE_CD = :balFwdAdjTypeCd) ");
            }
            
            //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            //PreparedStatement preparedStatement =  createPreparedStatement(stringBuilder.toString());
            PreparedStatement preparedStatement =  createPreparedStatement(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            
            preparedStatement.bindId("collRefId", collReferralId);
            preparedStatement.bindId("serviceTaskMo", COLL_AGY_REF_MO);
            preparedStatement.bindId("taskTypeBo", COLL_AGY_PLACE_TYPE_BO);
            preparedStatement.bindId("relSaCharType", RELATED_SA_CHAR_TYPE);
            preparedStatement.bindBoolean("isRedundant", Bool.FALSE);
            preparedStatement.bindBoolean("isFrozen", Bool.TRUE);
            // 2015-08-27. SMiran. Defect 3294942. Start Delete
            //preparedStatement.bindLookup("personUpdFlg", ReferralHistoryReasonLookup.constants.PERSONAL_UPDATES);
            //preparedStatement.bindId("currBatchCd", getBatchControlId());
            //preparedStatement.bindBigInteger("currBatchNbr", getBatchNumber());
            //preparedStatement.bindDateTime("processDttm", getProcessDateTime());
            ///*
            // * Start Add - Defect 3232581 - 2015-06-09
            // */
            //preparedStatement.bindBigInteger("sequenceNumber", sequenceNumber);
            ///*
            // * End Add - Defect 3232581 - 2015-06-09
            // */
            // 2015-08-27. SMiran. Defect 3294942. End Delete
            // 2015-08-27. SMiran. Defect 3294942. Start Add
            preparedStatement.bindDate("collAgyHisCreDate", collAgyHisCreDate);
            // 2015-08-27. SMiran. Defect 3294942. End Add
            
            if (notNull(parmBalFwdAdjType)){
                preparedStatement.bindEntity("balFwdAdjTypeCd", parmBalFwdAdjType);
            }
            
            List<SQLResultRow> resultRowList = preparedStatement.list();
            
            preparedStatement.close();
            
            return resultRowList;
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Change
            
        }
        
/*  IM-033087 -Method commented 
 * private Map<Premise_Id,Money> getCurrentBalanceByPremise(){
            Map<Premise_Id,Money> premBalMap = new HashMap<Premise_Id,Money>();
            Premise_Id premId = null;
            Money balance = Money.ZERO;
            StringBuilder queryString = new StringBuilder();
            queryString.append("SELECT SA2.CHAR_PREM_ID, SUM (FT.CUR_AMT) CUR_AMT ");
            queryString.append("FROM CI_SA SA2, CI_FT FT ");
            queryString.append("WHERE SA2.CHAR_PREM_ID IN ( ");
            queryString.append("SELECT SA.CHAR_PREM_ID ");
            queryString.append("FROM  CI_COLL_AGY_REF CREF,  CI_WO_PROC WPROC, CI_WO_PROC_SA WPSA, CI_SA SA ");
            queryString.append("WHERE CREF.COLL_AGY_REF_ID =  :collRefId  ");
            queryString.append("AND WPROC.WO_PROC_ID  = WPSA.WO_PROC_ID  ");
            queryString.append("AND CREF.WO_PROC_ID =  WPROC.WO_PROC_ID ");
            queryString.append("AND WPSA.SA_ID = SA.SA_ID ) ");
            queryString.append("AND SA2.SA_ID = FT.SA_ID ");
            queryString.append("GROUP BY  SA2.CHAR_PREM_ID ");
                        
            PreparedStatement pstmt =  createPreparedStatement(queryString.toString());
            pstmt.bindId("collRefId", collReferralId);
            for(SQLResultRow resultRow : pstmt.list()){
                premId =  (Premise_Id)resultRow.getId(PREMISE_ID, Premise.class);
                balance  = resultRow.getMoney(CUR_AMT);
                premBalMap.put(premId,balance);
            }
            pstmt.close();
            return premBalMap;
        }*/
        
    //IM-033087 - Start 
        
        @SuppressWarnings("deprecation")
		private Money retrieveSABalances(){

            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Change
            //Money saBalance = Money.ZERO;
            //StringBuilder sb = new StringBuilder();
            //sb.append("SELECT SUM(FT.CUR_AMT) AS SABAL FROM CI_FT FT, CI_WO_PROC_SA WPSA, CI_COLL_AGY_REF CR , CI_WO_PROC WP ");
            //sb.append("WHERE FT.SA_ID = WPSA.SA_ID AND WPSA.WO_PROC_ID = CR.WO_PROC_ID AND WPSA.WO_PROC_ID = WP.WO_PROC_ID ");
            //sb.append("AND CR.COLL_AGY_REF_ID =:collectionAgencyReferalId AND WP.WO_STATUS_FLG = :writeOffActiveStatus ");
            //sb.append(" AND WPSA.WO_SA_STAT_FLG = :woSaStatus ");
            //sb.append("AND FT.REDUNDANT_SW = :isRedundant AND FT.NOT_IN_ARS_SW <> :isNotInArrears AND FT.FREEZE_SW = :isFrozen");
            //
            //PreparedStatement prepStmt = createPreparedStatement(sb.toString()); 
            //prepStmt.bindId("collectionAgencyReferalId", collReferralId);
            //prepStmt.bindLookup("writeOffActiveStatus", WriteOffStatusLookup.constants.ACTIVE);
            //prepStmt.bindLookup("woSaStatus", WriteOffSaStatusLookup.constants.ACTIVE);
            //prepStmt.bindBoolean("isRedundant", Bool.FALSE);
            //prepStmt.bindBoolean("isNotInArrears", Bool.TRUE);
            //prepStmt.bindBoolean("isFrozen", Bool.TRUE);
            //
            //saBalance = prepStmt.firstRow().getMoney("SABAL");
            //if(isNull(saBalance))
            //    saBalance = Money.ZERO;
            //prepStmt.close();
            //
            //return saBalance;
            
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");
            stringBuilder.append(  "SUM(FT.CUR_AMT) AS SABAL ");
            stringBuilder.append("FROM ");
            stringBuilder.append(  "F1_SVC_TASK_REL_OBJ STRO, ");
            stringBuilder.append(  "F1_SVC_TASK STASK, ");
            stringBuilder.append(  "F1_SVC_TASK_TYPE STT, ");
            stringBuilder.append(  "F1_SVC_TASK_CHAR STCH, ");
            stringBuilder.append(  "CI_SA SA, ");
            stringBuilder.append(  "CI_FT FT ");
            stringBuilder.append("WHERE ");
            stringBuilder.append(  "STRO.PK_VALUE1 = :collectionAgencyReferalId ");
            stringBuilder.append(  "AND STRO.MAINT_OBJ_CD = :serviceTaskMo ");
            stringBuilder.append(  "AND STASK.F1_SVC_TASK_ID = STRO.F1_SVC_TASK_ID ");
            stringBuilder.append(  "AND STT.BUS_OBJ_CD = :taskTypeBo ");
            stringBuilder.append(  "AND STASK.BUS_OBJ_CD = STT.TRANS_BUS_OBJ_CD ");
            stringBuilder.append(  "AND STASK.F1_STASK_TYPE_CD = STT.F1_STASK_TYPE_CD ");
            stringBuilder.append(  "AND STCH.F1_SVC_TASK_ID = STASK.F1_SVC_TASK_ID ");
            stringBuilder.append(  "AND STCH.CHAR_TYPE_CD = :relSaCharType ");
            stringBuilder.append(  "AND (SA.SA_ID = TRIM(STCH.CHAR_VAL) ");
            stringBuilder.append(    "OR SA.SA_ID = TRIM(STCH.ADHOC_CHAR_VAL) ");
            stringBuilder.append(    "OR SA.SA_ID = TRIM(STCH.CHAR_VAL_FK1)) ");
            stringBuilder.append(  "AND SA.SA_STATUS_FLG <> :closedSaStatus ");
            stringBuilder.append(  "AND FT.SA_ID = SA.SA_ID ");
            stringBuilder.append(  "AND FT.REDUNDANT_SW = :isRedundant ");
            stringBuilder.append(  "AND FT.NOT_IN_ARS_SW <> :isNotInArrears ");
            stringBuilder.append(  "AND FT.FREEZE_SW = :isFrozen ");

            //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            //PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString());
            PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            preparedStatement.bindId("collectionAgencyReferalId", collReferralId);
            preparedStatement.bindId("serviceTaskMo", COLL_AGY_REF_MO);
            preparedStatement.bindId("taskTypeBo", COLL_AGY_PLACE_TYPE_BO);
            preparedStatement.bindId("relSaCharType", RELATED_SA_CHAR_TYPE);
            preparedStatement.bindLookup("closedSaStatus", ServiceAgreementStatusLookup.constants.CLOSED);
            preparedStatement.bindBoolean("isRedundant", Bool.FALSE);
            preparedStatement.bindBoolean("isNotInArrears", Bool.TRUE);
            preparedStatement.bindBoolean("isFrozen", Bool.TRUE);

            SQLResultRow sqlResultRow = preparedStatement.firstRow();

            preparedStatement.close();
            
            if (isNull(sqlResultRow)) {
                return Money.ZERO;
            }
            
            Money saBalance = sqlResultRow.getMoney("SABAL");
            return isNull(saBalance) ? Money.ZERO : saBalance;
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Change
        }
        
    //IM-033087 - End 
        
        private String determineFTReasonFlag(FinancialTransactionTypeLookup ftType, Payment_Id payId,Money ftCurrAmount) {
        
            String strReason = "";
            // If the Financial Transaction is Payment
            if(ftType.isPaySegment()){
                if(isCWRPayment(payId).isTrue()){
                    strReason = strFTRsnCWRAdjust;
                }else if(isPledgePayment(payId).isTrue()){
                    strReason = strFTRsnAdjust;
                }else if(isCollectionAgncyPayment(payId).isTrue()){
                    strReason = strFTRsnCACIPay;
                }else{
                    strReason =strFTRsnPay;
                }
                addCharToPayTender(payId,ftCurrAmount.negate(),strReason); // amount has to be negated else it will not equal to Tender Amount
                return strReason;
            }
            // If the Financial Transaction is Payment Cancel  
            
            
            if(ftType.isPayCancellation()){
                
                if(isPayCancelOriginallyPostedByCACI(payId).isTrue()) 
                    strReason = strFTRsnCACICancelPay;
                else
                    strReason = strFTRsnCancelPay;
                
                addCharToPayTender(payId,ftCurrAmount,strReason);
                return strReason;
            }
            // If the Financial Transaction is Adjustment and referral Hist is Cancel
            
            if(ftType.isAdjustment() && refHistRsnLookup.isReferralCancellation() ){
                strReason = strFTRsnCancelTrans;
                return strReason;
            }
            // If the Financial Transaction is Adjustment and referral Hist is not Cancel or BS,BX,AX
            
            if((ftType.isAdjustment() && (!refHistRsnLookup.isReferralCancellation()))
                || (ftType.isAdjustmentCancellation())
                || (ftType.isBillSegment())
                || (ftType.isBillCancellation())
            ){
                strReason = strFTRsnAdjust;
                return strReason;
            }
            
            return strReason;

        }
        
        private void addCharToPayTender(Payment_Id payId,Money ftCurrAmount, String strReason){
            boolean isCreated = false;
            PaymentEventPaymentTenders payTenders = payId.getEntity().getPaymentEvent().getPaymentTenders();
            for(PaymentTender tender : payTenders ){ 
                
                if(tender.getTenderAmount().compareTo(ftCurrAmount) ==0 ){ // tenderAmount will always be positive ,ftCurrAmount can be +ve (Cancel) or -ve(pay)
                    
                    // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Change
                    //PaymentTenderCharacteristic_DTO payTenderDTO = tender.getCharacteristics().newChildDTO();
                    //PaymentTenderCharacteristic_Id payTenderChar_Id = new PaymentTenderCharacteristic_Id(tender,payCharTypeRsnCode,BigInteger.valueOf(tender.getCharacteristics().size()+1));
                    //payTenderDTO.setId(payTenderChar_Id);
                    //payTenderDTO.setAdhocCharacteristicValue(strReason);
                    //payTenderDTO.newEntity();
                    //isCreated = true;
                    
                    // Check for an existing Characteristic on the Pay Tender
                    boolean alreadyHasCharacteristic = false;
                    for (PaymentTenderCharacteristic paymentTenderCharacteristic: tender.getCharacteristics()) {
                        
                        if (payCharTypeRsnCode.equals(paymentTenderCharacteristic.getAdhocCharacteristicValue())) {
                            alreadyHasCharacteristic = true;
                        }
                        
                    }
                    
                    if (!alreadyHasCharacteristic) {
                        PaymentTenderCharacteristic_DTO payTenderDTO = tender.getCharacteristics().newChildDTO();
                        PaymentTenderCharacteristic_Id payTenderChar_Id = new PaymentTenderCharacteristic_Id(tender,payCharTypeRsnCode,BigInteger.valueOf(tender.getCharacteristics().size()+1));
                        payTenderDTO.setId(payTenderChar_Id);
                        payTenderDTO.setAdhocCharacteristicValue(strReason);
                        payTenderDTO.newEntity();
                    }
                    
                    isCreated = true;
                    // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Change
                }
                if(isCreated)
                   break;
            }
        }
        

        /**
         *  This method checks if the Payment is the CWRpayment
         *  @ return Bool
         */     
        private Bool isCWRPayment(Payment_Id payId){
            
            
            StringBuilder getCWRPayment = new StringBuilder();
            
          //Start Change - IM-053664 - Ujesh - 2014-10-09
          
         /*   
            
            getCWRPayment.append("SELECT COUNT(*) COUNT  ");
            getCWRPayment.append("FROM  F1_SVC_TASK SVC, F1_SVC_TASK_CHAR SVCC  ");
            getCWRPayment.append("WHERE SVC.F1_SVC_TASK_ID = SVCC.F1_SVC_TASK_ID  ");
            getCWRPayment.append("AND SVC.F1_STASK_TYPE_CD = :svcTaskType ");
            getCWRPayment.append("AND SVC.BO_STATUS_CD = :taskBoStatus ");
            getCWRPayment.append("AND SVCC.CHAR_TYPE_CD = :charTypeCd ");
            getCWRPayment.append("AND SVCC.CHAR_VAL_FK1 = :acctId ");
    
            PreparedStatement pstmt =  createPreparedStatement(getCWRPayment.toString());
            
            pstmt.bindId("svcTaskType", svcTaskType.getId());
            pstmt.bindStringProperty("taskBoStatus",ServiceTask.properties.status, strBoStatus);
            pstmt.bindId("charTypeCd", cwrCharTypeCd.getId());
            pstmt.bindId("acctId", payId.getEntity().getAccount().getId()); 
            
         */
            getCWRPayment.append("SELECT COUNT(*) COUNT  ");
            getCWRPayment.append("FROM  F1_SVC_TASK SVC, F1_SVC_TASK_CHAR SVCC  ");
            getCWRPayment.append("WHERE SVC.F1_SVC_TASK_ID = SVCC.F1_SVC_TASK_ID  ");
            getCWRPayment.append("AND SVC.F1_STASK_TYPE_CD = :svcTaskType ");
            getCWRPayment.append("AND SVC.BO_STATUS_CD = :taskBoStatus ");
            getCWRPayment.append("AND SVCC.CHAR_TYPE_CD = :charTypeCd ");
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //getCWRPayment.append("AND TRIM(SVCC.CHAR_VAL_FK1) = :acctId ");
            getCWRPayment.append("AND SVCC.CHAR_VAL_FK1 = :acctId ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change
    
            //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            //PreparedStatement pstmt =  createPreparedStatement(getCWRPayment.toString());
            PreparedStatement pstmt =  createPreparedStatement(getCWRPayment.toString(), getClass().getName());
            //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            
            pstmt.bindId("svcTaskType", svcTaskType.getId());
            pstmt.bindString("taskBoStatus", strBoStatus, "BO_STATUS_CD");
            pstmt.bindId("charTypeCd", cwrCharTypeCd.getId());
            pstmt.bindString("acctId", payId.getEntity().getAccount().getId().getTrimmedValue(), "CHAR_VAL_FK1");   
            //End Change - IM-053664 - Ujesh - 2014-10-09            
            
            
            BigInteger rowCount  = pstmt.firstRow().getInteger("COUNT");
            pstmt.close();
            if(rowCount.compareTo(BigInteger.ZERO) == 0)
                return Bool.FALSE;
            else
                return Bool.TRUE;

        }
        /**
         *  This method checks if the Payment is the CWRpayment
         *  @ return Bool
         */         
        private Bool isPledgePayment(Payment_Id payId){
            // SD20131106 - CR - Solution Change for Pledge Payment
            Bool isCharExists = Bool.FALSE;
            
            
            /*        CR107 -SD20132706 
             *         PaymentEventPaymentTenders payTenders = payId.getEntity().getPaymentEvent().getPaymentTenders();
             *         for(PaymentTender tender : payTenders ){ 
                            for(PaymentTenderCharacteristic payTndrChar : tender.getCharacteristics()){
                                if(payTndrChar.getId().getCharacteristicTypeId().compareTo(payTndrCharType.getId())==0){
                                    isCharExists = Bool.TRUE;
                                    break;
                                }
                            }
                             
                        }*/
            
            //CR107 - SD20132706
            PaymentCharacteristics payChars = payId.getEntity().getCharacteristics();
            for(PaymentCharacteristic payChar : payChars){
                if(payChar.getId().getCharacteristicTypeId().compareTo(paymentCharType.getId())==0){
                    isCharExists = Bool.TRUE;
                    break;
                }   
            }
                
                return isCharExists;
            
    }  
        
        private Bool isCollectionAgncyPayment(Payment_Id payId){
            String strExtSrcId = null;
            PaymentEventPaymentTenders payTenders = payId.getEntity().getPaymentEvent().getPaymentTenders();
            for(PaymentTender tender : payTenders ){ 
                strExtSrcId = tender.fetchTenderControl().getTenderSource().getExternalSourceId();
                break;
            }
            if(isBlankOrNull(strExtSrcId) || (!strExtSrcId.trim().equals(strCACIExtSrcId))){
                return Bool.FALSE;
            }else
                return Bool.TRUE;
        }
        
/*  
 *        SD20131106 - CR - Solution Change for the Pledge Payment  
        private Bool isDistCodeExistsInFC(String strGLDistCode){
            StringBuilder queryString = new StringBuilder();
            queryString.append("SELECT 'X' FROM CI_WFM_OPT ");
            queryString.append("WHERE WFM_NAME = :wfmName ");
            queryString.append("AND @trim(EXT_OPT_TYPE) = :optType ");
            queryString.append("AND @trim(WFM_OPT_VAL) = :optVal ");
            
            PreparedStatement pstmt =  createPreparedStatement(queryString.toString());
            pstmt.bindEntity("wfmName", distCodeFeatConfig);
            pstmt.bindStringProperty("optType", FeatureConfigurationOption.properties.optionType, strFCOptionType);
            pstmt.bindStringProperty("optVal", FeatureConfigurationOption.properties.value, strGLDistCode);
            SQLResultRow resultRow = pstmt.firstRow();
            pstmt.close();
            if(isNull(resultRow))
                return Bool.FALSE;
            else
                return Bool.TRUE;
            
        }*/
        
        private Bool isPayCancelOriginallyPostedByCACI(Payment_Id payId){
                return isCollectionAgncyPayment(payId);
    
        }
        
        
        private void writeDataToPeruFile(List<CmCACIOutboundData> premiseDataList){
            StringBuilder recordLine = null;
              //Iterate Premise List and Write to File
            for(CmCACIOutboundData outData : premiseDataList){
                recordLine = new StringBuilder();
                recordLine.append(toUpperAndEncloseinQuote(outData.getAcctId().getIdValue().trim()));
                recordLine.append(COLUMN_SEPERATOR);
                recordLine.append(toUpperAndEncloseinQuote(collReferralId.getIdValue().trim()));
                recordLine.append(COLUMN_SEPERATOR);
                recordLine.append(toUpperAndEncloseinQuote(outData.getPremiseId().getIdValue().trim()));
                recordLine.append(COLUMN_SEPERATOR);
                recordLine.append(toUpperAndEncloseinQuote(mainPersonDtls.getString(P_B_FLAG)));
                recordLine.append(COLUMN_SEPERATOR);
                recordLine.append(toUpperAndEncloseinQuote(mainPersonDtls.getString(PER_NAME)));
                recordLine.append(COLUMN_SEPERATOR);
                recordLine.append(outData.getAcctMailAddr());
                recordLine.append(COLUMN_SEPERATOR);
                recordLine.append(preparePersonDetails(mainPersonDtls));
                recordLine.append(COLUMN_SEPERATOR);
                // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Change
                /*
                 * Start Change - Defect 3233475 - 2015-06-15
                 */
                //recordLine.append(recordLine.append(toUpperAndEncloseinQuote(collReferralId.getEntity().getCollectionAgency().getId().getTrimmedValue())));
                recordLine.append(toUpperAndEncloseinQuote(collReferralId.getEntity().getCollectionAgency().getId().getTrimmedValue()));
                /*
                 * End Change - Defect 3233475 - 2015-06-15
                 */
                // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Change
                recordLine.append(COLUMN_SEPERATOR);
                recordLine.append(toUpperAndEncloseinQuote(getProcessDateTime().getDate().toString()));//import date

                writeLinePeruFile(recordLine.toString());
                recordLine = null;
                
            }
        }
        
        @SuppressWarnings("rawtypes")
		private void writeDataToInitFile(List<CmCACIOutboundData> premiseDataList){
            StringBuilder recordLine = null;
            
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Delete
            //Iterate Premise List and Write to File
            //for(CmCACIOutboundData outData : premiseDataList){
            //  recordLine = new StringBuilder();
            //  recordLine.append(toUpperAndEncloseinQuote(outData.getAcctId().getIdValue().trim()));
            //  recordLine.append(COLUMN_SEPERATOR);
            //  recordLine.append(toUpperAndEncloseinQuote(collReferralId.getIdValue().trim()));
            //  recordLine.append(COLUMN_SEPERATOR);
            //  recordLine.append(toUpperAndEncloseinQuote(outData.getPremiseId().getIdValue().trim()));
            //  recordLine.append(COLUMN_SEPERATOR);
            //  recordLine.append(toUpperAndEncloseinQuote(outData.getRefferalType().trim()));
            //  recordLine.append(COLUMN_SEPERATOR);
            //  recordLine.append(toUpperAndEncloseinQuote(mainPersonDtls.getString(P_B_FLAG)));
            //  recordLine.append(COLUMN_SEPERATOR);
            //  recordLine.append(toUpperAndEncloseinQuote(mainPersonDtls.getString(PER_NAME)));
            //  recordLine.append(COLUMN_SEPERATOR);
            //  recordLine.append(outData.getAcctMailAddr());
            //  recordLine.append(COLUMN_SEPERATOR);
            //  recordLine.append(outData.getPremAddress());
            //  recordLine.append(COLUMN_SEPERATOR);
            //  recordLine.append(preparePersonDetails(mainPersonDtls));
            //  recordLine.append(COLUMN_SEPERATOR);
            //  recordLine.append(toUpperAndEncloseinQuote(outData.getTurnOnDate()));  
            //  recordLine.append(COLUMN_SEPERATOR);
            //  recordLine.append(toUpperAndEncloseinQuote(outData.getTurnOffDate()));
            //  recordLine.append(COLUMN_SEPERATOR);
            //  recordLine.append(toUpperAndEncloseinQuote(getMostRecentPayDate(outData.getSaList())));//Payment Date
            //  recordLine.append(COLUMN_SEPERATOR);
            //  recordLine.append(toUpperAndEncloseinQuote(AGY_NAME));
            //  recordLine.append(COLUMN_SEPERATOR);
            //  recordLine.append(toUpperAndEncloseinQuote(getProcessDateTime().getDate().toString()));//import date
            //  recordLine.append(COLUMN_SEPERATOR);
            //  recordLine.append(toUpperAndEncloseinQuote(outData.getCurrBalance().toPlainString()));
            //  
            //  writeLineInitFile(recordLine.toString());
            //  recordLine = null;
            //}
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Delete
            
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Add
            Iterator premiseDataIter = premiseDataList.iterator();
            while(premiseDataIter.hasNext()) {
        
                CmCACIOutboundData outData = (CmCACIOutboundData) premiseDataIter.next();
                                
                // Get and process each SA associated with the Premise.
                Iterator saIter = outData.getSaList().iterator();
                
                while(saIter.hasNext()) {
                    ServiceAgreement_Id currentSaId = (ServiceAgreement_Id) saIter.next();
                    ServiceAgreement currentSa = currentSaId.getEntity();
                    recordLine = new StringBuilder();
                    
                    // Account ID
                    recordLine.append(toUpperAndEncloseinQuote(outData.getAcctId().getIdValue().trim()));
                    recordLine.append(COLUMN_SEPERATOR);
                    //Collection Agency Referral ID
                    recordLine.append(toUpperAndEncloseinQuote(collReferralId.getIdValue().trim()));
                    recordLine.append(COLUMN_SEPERATOR);
                    // Premise ID
                    recordLine.append(toUpperAndEncloseinQuote(outData.getPremiseId().getIdValue().trim()));
                    recordLine.append(COLUMN_SEPERATOR);
                    // Referral Type
                    recordLine.append(toUpperAndEncloseinQuote(currentSa.getServiceAgreementType().fetchLanguageDescription().trim()));
                    recordLine.append(COLUMN_SEPERATOR);
                    // Person/Business Indicator
                    recordLine.append(toUpperAndEncloseinQuote(mainPersonDtls.getString(P_B_FLAG)));
                    recordLine.append(COLUMN_SEPERATOR);
                    // Person Name
                    recordLine.append(toUpperAndEncloseinQuote(mainPersonDtls.getString(PER_NAME)));
                    recordLine.append(COLUMN_SEPERATOR);
                    // Mail Address
                    recordLine.append(outData.getAcctMailAddr());
                    recordLine.append(COLUMN_SEPERATOR);
                    // Premise Address
                    recordLine.append(outData.getPremAddress());
                    recordLine.append(COLUMN_SEPERATOR);
                    // Person Details - ID, Main Phone, Work Phone, Cell Phone
                    recordLine.append(preparePersonDetails(mainPersonDtls));
                    recordLine.append(COLUMN_SEPERATOR);
                    // Turn On Date
                    recordLine.append(toUpperAndEncloseinQuote(outData.getTurnOnDate()));  
                    recordLine.append(COLUMN_SEPERATOR);
                    // Turn Off Date
                    recordLine.append(toUpperAndEncloseinQuote(outData.getTurnOffDate()));
                    recordLine.append(COLUMN_SEPERATOR);
                    // Last Payment Date
                    recordLine.append(toUpperAndEncloseinQuote(getMostRecentPayDate(outData.getSaList())));//Payment Date
                    recordLine.append(COLUMN_SEPERATOR);
                    // Collection Agency
                    recordLine.append(toUpperAndEncloseinQuote(collReferralId.getEntity().getCollectionAgency().getId().getTrimmedValue()));
                    recordLine.append(COLUMN_SEPERATOR);
                    // Import Date
                    recordLine.append(toUpperAndEncloseinQuote(getProcessDateTime().getDate().toString()));//import date
                    recordLine.append(COLUMN_SEPERATOR);
                    // Current Balance
                    recordLine.append(toUpperAndEncloseinQuote(outData.getCurrBalance().toPlainString()));
                    recordLine.append(COLUMN_SEPERATOR);
                    
                    // Main Person ID
                    recordLine.append(toUpperAndEncloseinQuote(perId.getIdValue().toString().trim()));
                    recordLine.append(COLUMN_SEPERATOR);
                    
                    // CIS Division
                    String cisDivision = currentSa.getServiceAgreementType().getId().getDivisionId().getIdValue().trim();
                    recordLine.append(toUpperAndEncloseinQuote(cisDivision));
                    recordLine.append(COLUMN_SEPERATOR);
                    
                    // SA Type
                    String saType = currentSa.getServiceAgreementType().getId().getSaType().trim();
                    recordLine.append(toUpperAndEncloseinQuote(saType));
                    recordLine.append(COLUMN_SEPERATOR);
                    
                    // SA Rate Class
                    recordLine.append(toUpperAndEncloseinQuote(getEffectiveSaCharVal(currentSa, rateClassCharType)));
                    recordLine.append(COLUMN_SEPERATOR);
                    
                    // Final Bill Date
                    // START CHANGES - JHERNA - DEC092021 6:11PM EST - Mercury#47158
                    /*
                    recordLine.append(toUpperAndEncloseinQuote(outData.getTurnOffDate()));
                    recordLine.append(COLUMN_SEPERATOR);
                    */       
                    String finalBillDateStr = "";
                    Date woProcCreateDt = outData.getWriteOffProcessID().getEntity().getCreationDateTime().getDate();
                    Date finalBillDate = getFinalBillDate(outData.getAcctId(), woProcCreateDt, outData.getPremiseId());
                    if (notNull(finalBillDate)) {
                    	finalBillDateStr = finalBillDate.toString().trim();
                    }
                    recordLine.append(toUpperAndEncloseinQuote(finalBillDateStr));
                    recordLine.append(COLUMN_SEPERATOR);
                    // END CHANGES - JHERNA - DEC092021 6:11PM EST - Mercury#47158
                    
                    // Building Meter Characteristic
                    String bldgMtrCharVal = "";
                    if(notNull(bldgMtrCharType)) {
                        bldgMtrCharVal = getEffectivePremiseCharVal(outData.getPremiseId().getEntity(), bldgMtrCharType);
                    }
                    recordLine.append(toUpperAndEncloseinQuote(bldgMtrCharVal));
                    recordLine.append(COLUMN_SEPERATOR);
                    
                    // Operations Area (N/S) Characteristic
                    String opsAreaCharVal = "";
                    if(notNull(opsAreaCharType)) {
                        opsAreaCharVal = getEffectivePremiseCharVal(outData.getPremiseId().getEntity(), opsAreaCharType);
                    }
                    recordLine.append(toUpperAndEncloseinQuote(opsAreaCharVal));
                    recordLine.append(COLUMN_SEPERATOR);
                    
                    // FA Disconnect Reason
                    recordLine.append(toUpperAndEncloseinQuote(getDisconnectReason(outData.getPremiseId().getEntity(), currentSa)));
                    
                    /* START ADD - JHERNA - 2021-11-03 - SysAid#383853 */
                    // Delinquency Info is populated only for MO division, otherwise it is left null.
                    String delinquencyDateStr = "";
                    String delinquencyAmountStr = "";
                    CisDivision_Id moeDiv = new CisDivision_Id("LGC");
                    CisDivision_Id mowDiv = new CisDivision_Id("MGE");
                    CisDivision_Id saDivision = currentSa.getServiceAgreementType().fetchIdDivision().getId();
                    
                    // Derive delinquency date and amount for Missouri Divisions (for other divisions, leave blank)
                    if (saDivision.compareTo(moeDiv) == 0
                    		|| saDivision.compareTo(mowDiv) == 0) {
                    	
                    	// Determine Delinquency Information
                    	WriteOffProcess_Id woProcID = outData.getWriteOffProcessID();
                    	WriteOffProcess woProc = woProcID.getEntity();
                    	
                    	Iterator<WriteOffProcessServiceAgreement> iterWoProcSA = woProc.getServiceAgreements().iterator();
                    	Money arrearsAmount = Money.ZERO;
                    	
                    	while (iterWoProcSA.hasNext()) {
                    		WriteOffProcessServiceAgreement woProcSA = (WriteOffProcessServiceAgreement) iterWoProcSA.next();
                    		arrearsAmount = arrearsAmount.add(woProcSA.getArrearsAmount());
                    	}
                    	delinquencyDateStr = woProc.getCreationDateTime().getDate().toString();
                    	delinquencyAmountStr = arrearsAmount.toPlainString();
                    }
                    
                    // Delinquency Date
                    recordLine.append(COLUMN_SEPERATOR);
                    recordLine.append(toUpperAndEncloseinQuote(delinquencyDateStr));
                    
                    // Delinquency Amount
                    recordLine.append(COLUMN_SEPERATOR);
                    recordLine.append(toUpperAndEncloseinQuote(delinquencyAmountStr));                    
                    /* END ADD - JHERNA - 2021-11-03 - SysAid#383853 */
                    
                    writeLineInitFile(recordLine.toString());
                    recordLine = null;
                }
            }
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Add
        }
        
        // START ADD - JHERNA - DEC092021 6:11PM EST - Mercury#47158
        private Date getFinalBillDate(Account_Id accountID, Date woProcCreateDt, Premise_Id premID) {
        	        	
        	Date returnValue = null;        	
        	StringBuilder stringBuilder = new StringBuilder();        	
        	
        	stringBuilder.append("SELECT BILL.BILL_DT "); 
        	stringBuilder.append("FROM CI_BILL BILL, CI_BSEG BS, CI_SA SA, CI_SA_TYPE SAT ");
        	stringBuilder.append("WHERE SA.ACCT_ID = :accountID ");
        	stringBuilder.append("AND SA.CHAR_PREM_ID = :premID ");
        	stringBuilder.append("AND SAT.SA_TYPE_CD = SA.SA_TYPE_CD ");
        	stringBuilder.append("AND SAT.CIS_DIVISION = SA.CIS_DIVISION ");
        	stringBuilder.append("AND SAT.SVC_TYPE_CD = 'G' ");
        	stringBuilder.append("AND BS.SA_ID = SA.SA_ID ");
        	stringBuilder.append("AND BS.CLOSING_BSEG_SW = 'Y' ");
        	stringBuilder.append("AND BS.BSEG_STAT_FLG = :frozen ");
        	stringBuilder.append("AND BS.CRE_DTTM <= :woProcCreateDt ");
        	stringBuilder.append("AND BILL.BILL_ID = BS.BILL_ID ");
        	stringBuilder.append("ORDER BY BS.CRE_DTTM DESC ");
        	
        	PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==getFinalBillDate==");
        	prepState.setAutoclose(false);
        	prepState.bindId("accountID", accountID);
        	prepState.bindId("premID", premID);
        	prepState.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
        	prepState.bindDate("woProcCreateDt", woProcCreateDt);
        	prepState.execute();
        	if (notNull(prepState.firstRow())) {
        		SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
        		returnValue = sqlRow.getDate("BILL_DT");
        	}        	
        	prepState.close();
        	return returnValue;
        }
        // END ADD - JHERNA - DEC092021 6:11PM EST - Mercury#47158

        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Add
        private String getEffectiveSaCharVal(ServiceAgreement sa, CharacteristicType charType) {
            
            String charVal = "";
            
            ServiceAgreementCharacteristic saChar = sa.getEffectiveCharacteristic(charType);
            
            if(notNull(saChar)) {
                if(charType.getCharacteristicType().isAdhocValue() || charType.getCharacteristicType().isFileLocationValue()) {
                    charVal = saChar.getAdhocCharacteristicValue();
                } else if(charType.getCharacteristicType().isPredefinedValue()) {
                    charVal = saChar.getCharacteristicValue();
                } else if(charType.getCharacteristicType().isForeignKeyValue()) {
                    charVal = saChar.getCharacteristicValueForeignKey1(); 
                }
            }
            
            return charVal;
        }
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Add
        
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Add
        private String getEffectivePremiseCharVal(Premise premise, CharacteristicType charType) {
            
            String charVal = "";
    
            PremiseCharacteristic premChar = premise.getEffectiveCharacteristic(charType);
            
            if(notNull(premChar)) {
                if(charType.getCharacteristicType().isAdhocValue() || charType.getCharacteristicType().isFileLocationValue()) {
                    charVal = premChar.getAdhocCharacteristicValue();
                } else if(charType.getCharacteristicType().isPredefinedValue()) {
                    charVal = premChar.getCharacteristicValue();
                } else if(charType.getCharacteristicType().isForeignKeyValue()) {
                    charVal = premChar.getCharacteristicValueForeignKey1(); 
                }
            }
            
            return charVal;
        }
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Add
        
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Add
        @SuppressWarnings("rawtypes")
		private String getDisconnectReason(Premise premise, ServiceAgreement sa) {
			
			String disconRsn = VOLUNTARY_FA;
			List saSpFaList = null;

			PreparedStatement getSaSpFa = createPreparedStatement("SELECT " +
					// 2015-06-09. SMiran. Defect 3232581. Start Change
					//"	SSF.FA_ID" +
					"	FA.FA_ID " +
					// 2015-06-09. SMiran. Defect 3232581. End Change
					" FROM " +
					"	CI_SP SP, " +
					"	CI_SA_SP SS," +
					"	CI_SA_SP_FA SSF" +
					// 2015-06-09. SMiran. Defect 3232581. Start Add
					"	,CI_FA FA" +
					// 2015-06-09. SMiran. Defect 3232581. End Add
					" WHERE " +
					"	SP.PREM_ID = :premise " +
					// 2015-06-09. SMiran. Defect 3232581. Start Change					
					//"	AND SS.SP_ID = SP.SP_ID " +
					//"	AND SS.SA_ID = :sa " +
					//"	AND SSF.SA_ID = SS.SA_ID" +
					//"	AND SSF.SP_ID = SS.SP_ID" +
					//"	AND SSF.FA_ID = (SELECT " +
					//"						SSF2.FA_ID" +
					//"					FROM " +
					//"						CI_SA_SP_FA SSF2" +
					//"					WHERE " +
					//"						SSF2.SA_ID = SS.SA_ID " +
					//"						AND SSF2.SP_ID = SS.SP_ID" +
					//"						AND SSF2.SA_SP_ID = SS.SA_SP_ID" +
					//"						AND SSF2.SA_SP_FA_TYPE_FLG = :saSpFaType)" +
					//" ORDER BY" +
					//"	SS.STOP_DTTM DESC");
					" AND SP.SP_ID = SS.SP_ID " +
					" AND SS.SA_ID = :sa " +
					" AND SSF.SA_ID = SS.SA_ID " +
					" AND SSF.SA_SP_FA_TYPE_FLG = :saSpFaType " +
					" AND SSF.SA_ID = SS.SA_ID " +
					" AND SSF.SP_ID = SS.SP_ID " +
					" AND SSF.FA_ID = FA.FA_ID " +	
					//Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
					//" AND FA.FA_STATUS_FLG = :complete");
					" AND FA.FA_STATUS_FLG = :complete", getClass().getName());
					//End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
					// 2015-06-09. SMiran. Defect 3232581. End Change
			
			getSaSpFa.bindEntity("premise", premise);
			getSaSpFa.bindEntity("sa", sa);
			getSaSpFa.bindLookup("saSpFaType",ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
			// 2015-06-09. SMiran. Defect 3232581. Start Add
			getSaSpFa.bindLookup("complete", FieldActivityStatusLookup.constants.COMPLETED);
			// 2015-06-09. SMiran. Defect 3232581. End Add
			
			saSpFaList = getSaSpFa.list();
			getSaSpFa.close();
			
			if(notNull(saSpFaList) && !saSpFaList.isEmpty()) {
				
				SQLResultRow row = (SQLResultRow) saSpFaList.get(0);
				FieldActivity_Id faId = (FieldActivity_Id) row.getId("FA_ID", FieldActivity.class);
				
                if (nonVoluntaryStopFaTypeList.contains(faId.getEntity().getFieldActivityType())) {
                    disconRsn = NONVOLUNTARY_FA;
                }
                
			}
			
			return disconRsn;

            
        }
        // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Add
        
        private List<CmCACIOutboundData> getCollectionAgencyReferralData(){
            List<CmCACIOutboundData>premiseDataList = new ArrayList<CmCACIOutboundData>();  
            
                    
            String  premMailAddress = null;
            String  acctMailAddress = null; 
            
            //Class Variable initialization
            mainPersonDtls = null;
            perId = null;
            
            //Record Variables
            Account_Id acctId = null;
            Premise_Id premId = null;
            Premise_Id oldPremId = null;
            
            
            ServiceAgreement_Id saId = null;
            ServiceAgreement sa = null;
            CmCACIOutboundData premOutData = null;

            
            //Retrieve all the Writeoff Process SAs for the Collection Referral
            List<SQLResultRow> writeOffSAList = retrieveWriteOffProcessSAs();
            for(SQLResultRow saResultRow : writeOffSAList){
                saId = (ServiceAgreement_Id)saResultRow.getId(SA_ID, ServiceAgreement.class);
                premId =  (Premise_Id)saResultRow.getId(PREMISE_ID, Premise.class);
                
                if(isNull(premId)){
                    logError (CustomMessageRepository.ni0040_1NoCharPremiseExistsForSA(saId.getIdValue()));
                    continue;
                }
                
                acctId = (Account_Id)saResultRow.getId(ACCOUNT_ID, Account.class);
                sa = saId.getEntity(); //Lazy initialization Issue
                
                // Get Main Person Details only once.It should not be extracted for each Premise of the given Coll Ref Id.
                if(isNull(mainPersonDtls)){
                    mainPersonDtls = getMainPersonDetails(acctId);
                    perId =  (Person_Id)mainPersonDtls.getId(MAIN_PER_ID,Person.class);
                }


                if(isNull(oldPremId) || (oldPremId.compareTo(premId)!=0)){
                    
                    //Outbound Data Instance to hold the Details
                    premOutData = null;
                    premOutData = CmCACIOutboundData.Factory.newInstance();
                    premOutData.setPremiseId(premId);
                    premOutData.setAcctId(acctId);
                    //Info Needed only in case of Initial Referral
                    if(refHistRsnLookup.isInitialReferral()){
                        Date turnOffDate = saResultRow.getDate(TURN_OFF_DT);
                        String strDate= "";
                        if(isNull(turnOffDate))
                            strDate = "";
                        else
                            strDate = turnOffDate.toString();
                        premOutData.setTurnOffDate(strDate);
                        premOutData.setTurnOnDate(saResultRow.getDate(TURN_ON_DT).toString());
                        premOutData.setRefferalType(saResultRow.getString(SA_TYPE_DESCR));
                        premMailAddress = preparePremiseAddr(premId);
                        premOutData.setPremAddress(premMailAddress);
                    }
                 
                 //If Bill Address Source is person,Premise or Account Override
                      acctMailAddress =  getAccountMailAddress(acctId);
                      
                    /*
                     * Start Change - 2014-01-13 Ujesh IM-043433
                     */   

                      if(isNull(acctMailAddress))
                          return null;
                    /*
                     * End Change - 2014-01-13 Ujesh IM-043433
                     */     
                      
                      premOutData.setAcctMailAddr(acctMailAddress);
                      premOutData.setCurrBalance(premOutData.getCurrBalance().add(sa.getCurrentBalance())); 
                      premOutData.getSaList().add(saId);
                     premiseDataList.add(premOutData);
                }
                //Info Needed only in case of Initial Referral
                if(refHistRsnLookup.isInitialReferral()){               
                    if(notNull(oldPremId) && (oldPremId.compareTo(premId)==0)){
                        premOutData.setCurrBalance(premOutData.getCurrBalance().add(sa.getCurrentBalance()));
                        premOutData.getSaList().add(saId);
                    }
                    
                }   

                /* START ADD - JHERNA - 2021-11-03 - SysAid#383853 */
                WriteOffProcess_Id woProcID = (WriteOffProcess_Id) saResultRow.getId("WO_PROC_ID", WriteOffProcess.class);
                premOutData.setWriteOffProcessID(woProcID);
                /* END ADD - JHERNA - 2021-11-03 - SysAidWO_#383853 */
                
                oldPremId = premId;
            }//End For
            
            return premiseDataList;
        }
        
        private String preparePersonDetails(SQLResultRow result){
            StringBuilder personDtls = new StringBuilder();

            // START CHANGE - JRAYMU - 2020-10-22 - CCB017
            // Check if the field ENCR_PER_IDN is populated.
            String encPerIdn = result.getString(ENCR_PER_IDN);
            if(!isBlankOrNull(encPerIdn)){
            	Person_Id mainPerId = (Person_Id)result.getId(MAIN_PER_ID, Person.class);
            	CmMGEFeatureConfigurationOptionsRetriever featConfRet = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
            	String ssnIdType = featConfRet.getFeatureOptionValue(SCH_CONST_FEAT_CONF, SchemaConstantOptionLookup.constants.SSN_ID_TYPE, Bool.TRUE, Bool.FALSE);
            	PersonOrBusinessLookup perOrBus = mainPerId.getEntity().getPersonOrBusiness();
                // If populated get the decrypted value of PER_IDN and append to personDtls
            	if(perOrBus.isPerson()){
	            	personDtls.append(toUpperAndEncloseinQuote(decryptData(CI_PER_ID, PER_ID_NBR, ID_TYPE_CD, 
	            			ssnIdType, encPerIdn)));
            	}else{
            		String finIdType = featConfRet.getFeatureOptionValue(SCH_CONST_FEAT_CONF, SchemaConstantOptionLookup.constants.TAX_IDENTIFIER_TYPE, Bool.TRUE, Bool.FALSE);
                	
            		personDtls.append(toUpperAndEncloseinQuote(decryptData(CI_PER_ID, PER_ID_NBR, ID_TYPE_CD, 
            				finIdType, encPerIdn)));
            	}
            }else{
            	// Append PER_IDN original value
            	personDtls.append(toUpperAndEncloseinQuote(result.getString(PER_IDN)));
            }
            // END CHANGE - JRAYMU - 2020-10-22 - CCB017
            personDtls.append(COLUMN_SEPERATOR);
            personDtls.append(toUpperAndEncloseinQuote(result.getString(MAIN_PH)));
            personDtls.append(COLUMN_SEPERATOR);
            personDtls.append(toUpperAndEncloseinQuote(result.getString(CELL_PH)));
            personDtls.append(COLUMN_SEPERATOR);
            personDtls.append(toUpperAndEncloseinQuote(result.getString(POSTAL_PH)));
            return personDtls.toString();
        }
        
        private String getMostRecentPayDate(List<ServiceAgreement_Id> saIdList){
            SQLResultRow resultRow = null;
            
            StringBuilder getPayDate = new StringBuilder();
            getPayDate.append("SELECT FT.FREEZE_DTTM ");
            getPayDate.append("FROM CI_FT FT  ");
            getPayDate.append("WHERE FT.SA_ID IN (  ");
            int counter = 0;
            for (;counter < saIdList.size(); counter++) {
                if (counter == 0) {
                    getPayDate.append(":saId" + counter);
                } else {
                    getPayDate.append(", :saId" + counter);
                }
            }
            getPayDate.append(")  ");
            getPayDate.append("AND FT.FT_TYPE_FLG = :paySeg ");
            getPayDate.append("AND FT.FREEZE_SW = 'Y' ");
            getPayDate.append("AND NOT EXISTS  ");
            getPayDate.append("( SELECT 'X' FROM CI_FT FT1  ");
            getPayDate.append("WHERE FT1.SIBLING_ID = FT.SIBLING_ID ");
            getPayDate.append("AND FT1.SA_ID = FT.SA_ID ");
            getPayDate.append("AND FT1.FT_TYPE_FLG = :paySegCancel) ");
            getPayDate.append("ORDER BY FREEZE_DTTM DESC ");
   
            //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            //PreparedStatement pstmt =  createPreparedStatement(getPayDate.toString());
            PreparedStatement pstmt =  createPreparedStatement(getPayDate.toString(), getClass().getName());
            //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            counter = 0;
            for (ServiceAgreement_Id saId : saIdList) {
                pstmt.bindId("saId" + counter++, saId);
            }
            pstmt.bindLookup("paySeg", FinancialTransactionTypeLookup.constants.PAY_SEGMENT);
            pstmt.bindLookup("paySegCancel", FinancialTransactionTypeLookup.constants.PAY_CANCELLATION);
                        
            resultRow = pstmt.firstRow();
            pstmt.close();
            
            if(notNull(resultRow)){
                return resultRow.getDateTime("FREEZE_DTTM").getDate().toString();
            }
            return "";
        }
        
        
        /**
         *  This method converts a String to Upper case and encloses in double Quotes .
         *  @param String str
         *  @return String 
         */         
        
        private String toUpperAndEncloseinQuote(String str){
            
            if(!isBlankOrNull(str)){
                str = "\"" + str.trim().toUpperCase() + "\"";
                return str;
            }
            return EMPTY_STRING_QUOTE;
        }
        
        /**
         *  This method retrieves all SAs that are linked to the Write Off Process of a Collection Referral Id .
         */     
        private List<SQLResultRow> retrieveWriteOffProcessSAs(){
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start Change
            //List<SQLResultRow> writeOffSAList = null;
            //
            //StringBuilder getWriteOffSAs = new StringBuilder();
            //getWriteOffSAs.append("SELECT CREF.COLL_AGY_REF_ID,WPSA.SA_ID,STYP.SA_TYPE_CD,STYL.DESCR,SA.START_DT,SA.END_DT,SA.ACCT_ID,SA.CHAR_PREM_ID,STYP.PAY_PRIORITY_FLG ");
            //getWriteOffSAs.append("FROM  CI_COLL_AGY_REF CREF,  CI_WO_PROC WPROC, CI_WO_PROC_SA WPSA, CI_SA SA, CI_SA_TYPE STYP,CI_SA_TYPE_L STYL  ");
            //getWriteOffSAs.append("WHERE CREF.COLL_AGY_REF_ID =  :collRefId "); 
            //getWriteOffSAs.append("AND WPROC.WO_PROC_ID  = WPSA.WO_PROC_ID ");
            //getWriteOffSAs.append("AND WPSA.SA_ID =  SA.SA_ID ");
            //getWriteOffSAs.append("AND SA.SA_TYPE_CD =  STYP.SA_TYPE_CD ");
            //getWriteOffSAs.append("AND SA.CIS_DIVISION = STYP.CIS_DIVISION ");
            //getWriteOffSAs.append("AND STYP.SA_TYPE_CD =  STYL.SA_TYPE_CD ");
            //getWriteOffSAs.append("AND STYP.CIS_DIVISION =  STYL.CIS_DIVISION ");
            ////WO SA STATUS FLAG can be active or Inactive for Financial Updates
            //if(refHistRsnLookup.isInitialReferral() || refHistRsnLookup.isPersonalUpdates()){
            //   getWriteOffSAs.append("AND WPSA.WO_SA_STAT_FLG = :woSAStatusFlg ");
            //}
            //getWriteOffSAs.append("AND CREF.WO_PROC_ID =  WPROC.WO_PROC_ID ");
            //getWriteOffSAs.append("ORDER BY SA.CHAR_PREM_ID,STYP.PAY_PRIORITY_FLG,SA.SA_ID ");
            //
            //PreparedStatement pstmt =  createPreparedStatement(getWriteOffSAs.toString());
            //
            //if(refHistRsnLookup.isInitialReferral() || refHistRsnLookup.isPersonalUpdates()){
            //   pstmt.bindLookup("woSAStatusFlg", WriteOffSaStatusLookup.constants.ACTIVE);
            //}
            //pstmt.bindId("collRefId", collReferralId);
            //
            //writeOffSAList = preparedStatement.list();
            //preparedStatement.close();
            // 
            //return writeOffSAList;
            
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SELECT ");
            stringBuilder.append(  "STRO.PK_VALUE1 AS COLL_AGY_REF_ID, ");
            stringBuilder.append(  "SA.SA_ID, ");
            stringBuilder.append(  "STYP.SA_TYPE_CD, ");
            stringBuilder.append(  "STYL.DESCR, ");
            stringBuilder.append(  "SA.START_DT, ");
            stringBuilder.append(  "SA.END_DT, ");
            stringBuilder.append(  "SA.ACCT_ID, ");
            stringBuilder.append(  "SA.CHAR_PREM_ID, ");
            stringBuilder.append(  "STYP.PAY_PRIORITY_FLG ");
            /* START ADD - JHERNA - 2021-11-03 - SysAid#383853 */
            /* Also retrieve the Write Off Process to be used  */
            /* to get delinquency information for MO divisions */
            stringBuilder.append(",(SELECT WP.PK_VALUE1 FROM F1_SVC_TASK_REL_OBJ WP WHERE WP.F1_SVC_TASK_ID = STRO.F1_SVC_TASK_ID AND WP.MAINT_OBJ_CD = 'WO PROC') WO_PROC_ID ");            
            /* END ADD - JHERNA - 2021-11-03 - SysAid#383853   */
            stringBuilder.append("FROM ");
            stringBuilder.append(  "F1_SVC_TASK_REL_OBJ STRO, ");
            stringBuilder.append(  "F1_SVC_TASK STASK, ");
            stringBuilder.append(  "F1_SVC_TASK_TYPE STT, ");
            stringBuilder.append(  "F1_BUS_OBJ_STATUS BOS, ");
            stringBuilder.append(  "F1_SVC_TASK_CHAR STCH, ");
            stringBuilder.append(  "CI_SA SA, ");
            stringBuilder.append(  "CI_SA_TYPE STYP, ");
            stringBuilder.append(  "CI_SA_TYPE_L STYL ");
            stringBuilder.append("WHERE ");
            stringBuilder.append(  "STRO.PK_VALUE1 = :collRefId ");
            stringBuilder.append(  "AND STRO.MAINT_OBJ_CD = :serviceTaskMo ");
            stringBuilder.append(  "AND STASK.F1_SVC_TASK_ID = STRO.F1_SVC_TASK_ID ");
            stringBuilder.append(  "AND STT.BUS_OBJ_CD = :taskTypeBo ");
            stringBuilder.append(  "AND STASK.BUS_OBJ_CD = STT.TRANS_BUS_OBJ_CD ");
            stringBuilder.append(  "AND STASK.F1_STASK_TYPE_CD = STT.F1_STASK_TYPE_CD ");
            stringBuilder.append(  "AND BOS.BUS_OBJ_CD = STASK.BUS_OBJ_CD ");
            stringBuilder.append(  "AND BOS.BO_STATUS_CD = STASK.BO_STATUS_CD ");
            stringBuilder.append(  "AND BOS.BO_STATUS_COND_FLG <> :finalBoStatusCondition ");
            stringBuilder.append(  "AND STCH.F1_SVC_TASK_ID = STASK.F1_SVC_TASK_ID ");
            stringBuilder.append(  "AND STCH.CHAR_TYPE_CD = :relSaCharType ");
            stringBuilder.append(  "AND (SA.SA_ID = TRIM(STCH.CHAR_VAL) ");
            stringBuilder.append(    "OR SA.SA_ID = TRIM(STCH.ADHOC_CHAR_VAL) ");
            stringBuilder.append(    "OR SA.SA_ID = TRIM(STCH.CHAR_VAL_FK1)) ");
            stringBuilder.append(  "AND SA.SA_TYPE_CD = STYP.SA_TYPE_CD ");
            stringBuilder.append(  "AND SA.CIS_DIVISION = STYP.CIS_DIVISION ");
            stringBuilder.append(  "AND STYP.SA_TYPE_CD = STYL.SA_TYPE_CD ");
            stringBuilder.append(  "AND STYP.CIS_DIVISION = STYL.CIS_DIVISION ");
            stringBuilder.append(  "AND STYL.LANGUAGE_CD = :language ");
            stringBuilder.append("ORDER BY ");
            stringBuilder.append(  "SA.CHAR_PREM_ID, ");
            stringBuilder.append(  "STYP.PAY_PRIORITY_FLG, ");
            stringBuilder.append(  "SA.SA_ID ");
            
            //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            //PreparedStatement preparedStatement =  createPreparedStatement(stringBuilder.toString());
            PreparedStatement preparedStatement =  createPreparedStatement(stringBuilder.toString(), getClass().getName());
            //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            
            preparedStatement.bindId("collRefId", collReferralId);
            preparedStatement.bindId("serviceTaskMo", COLL_AGY_REF_MO);
            preparedStatement.bindId("taskTypeBo", COLL_AGY_PLACE_TYPE_BO);
            preparedStatement.bindLookup("finalBoStatusCondition", BusinessObjectStatusConditionLookup.constants.FINAL);
            preparedStatement.bindId("relSaCharType", RELATED_SA_CHAR_TYPE);
            preparedStatement.bindId("language", getParameters().getLanguageId());
            
            List<SQLResultRow> writeOffSAList = preparedStatement.list();
            preparedStatement.close();
             
            return writeOffSAList;
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End Change
        }
        
        /**
         * To Get the Main Person Details 
         * @param Account Id
         * @return SQLResultRow
         */
        
        private SQLResultRow getMainPersonDetails(Account_Id acctId){
            SQLResultRow result = null;
            StringBuilder getMainPersonDtls = new StringBuilder();
            getMainPersonDtls.append("SELECT PER.PER_ID,PRNM.ENTITY_NAME, PER.PER_OR_BUS_FLG,  ");
            // START ADD - JRAYMU - 2020-10-22 - CCB017
            getMainPersonDtls.append("(CASE PER_OR_BUS_FLG ");
            getMainPersonDtls.append("WHEN 'P' THEN (SELECT PRID.ENCR_PER_ID_NBR FROM CI_PER_ID PRID, CI_WFM CW,CI_WFM_OPT CWO WHERE PRID.PER_ID = PER.PER_ID AND  CWO.WFM_NAME = CW.WFM_NAME AND CWO.EXT_OPT_TYPE = :perIdntfr AND CW.WFM_NAME = 'SCHEMACONST' AND TRIM(PRID.ID_TYPE_CD) = CWO.WFM_OPT_VAL AND ROWNUM <= 1 )   ");
            getMainPersonDtls.append("WHEN  'B' THEN (SELECT PRID.ENCR_PER_ID_NBR FROM CI_PER_ID PRID, CI_WFM CW,CI_WFM_OPT CWO WHERE PRID.PER_ID = PER.PER_ID AND CWO.WFM_NAME = CW.WFM_NAME AND CWO.EXT_OPT_TYPE = :bsnIdntfr AND CW.WFM_NAME = 'SCHEMACONST' AND TRIM(PRID.ID_TYPE_CD) = CWO.WFM_OPT_VAL AND ROWNUM <= 1 ) ");
            getMainPersonDtls.append("END) ENCR_PER_IDNTFR, ");
            // END ADD - JRAYMU - 2020-10-22 - CCB017

            getMainPersonDtls.append("(CASE PER_OR_BUS_FLG   ");
            
            /*
             * Start Change - 2014-01-13 Ujesh IM-043433
             */   
            
            //getMainPersonDtls.append(" WHEN 'P' THEN (SELECT PRID.PER_ID_NBR FROM CI_PER_ID PRID, CI_WFM CW,CI_WFM_OPT CWO WHERE PRID.PER_ID = PER.PER_ID AND  CWO.WFM_NAME = CW.WFM_NAME AND CWO.EXT_OPT_TYPE = :perIdntfr AND CW.WFM_NAME = 'SCHEMACONST' AND TRIM(PRID.ID_TYPE_CD) = CWO.WFM_OPT_VAL ) ");
            //getMainPersonDtls.append("WHEN  'B' THEN (SELECT PRID.PER_ID_NBR FROM CI_PER_ID PRID, CI_WFM CW,CI_WFM_OPT CWO WHERE PRID.PER_ID = PER.PER_ID AND  CWO.WFM_NAME = CW.WFM_NAME AND CWO.EXT_OPT_TYPE = :bsnIdntfr AND CW.WFM_NAME = 'SCHEMACONST' AND TRIM(PRID.ID_TYPE_CD) = CWO.WFM_OPT_VAL ) ");
            getMainPersonDtls.append(" WHEN 'P' THEN (SELECT PRID.PER_ID_NBR FROM CI_PER_ID PRID, CI_WFM CW,CI_WFM_OPT CWO WHERE PRID.PER_ID = PER.PER_ID AND  CWO.WFM_NAME = CW.WFM_NAME AND CWO.EXT_OPT_TYPE = :perIdntfr AND CW.WFM_NAME = 'SCHEMACONST' AND TRIM(PRID.ID_TYPE_CD) = CWO.WFM_OPT_VAL AND ROWNUM <= 1 ) ");
            getMainPersonDtls.append("WHEN  'B' THEN (SELECT PRID.PER_ID_NBR FROM CI_PER_ID PRID, CI_WFM CW,CI_WFM_OPT CWO WHERE PRID.PER_ID = PER.PER_ID AND  CWO.WFM_NAME = CW.WFM_NAME AND CWO.EXT_OPT_TYPE = :bsnIdntfr AND CW.WFM_NAME = 'SCHEMACONST' AND TRIM(PRID.ID_TYPE_CD) = CWO.WFM_OPT_VAL AND ROWNUM <= 1 ) ");
        
            /*
             * End Change - 2014-01-13 Ujesh IM-043433
             */ 
            
            getMainPersonDtls.append(" END) PER_IDNTFR, ");
            getMainPersonDtls.append("(CASE PER_OR_BUS_FLG  ");
            
            /*
             * Start Change - 2014-01-13 Ujesh IM-043433
             */ 
            
            //getMainPersonDtls.append("WHEN 'P' THEN (SELECT PRPH.PHONE FROM CI_PER_PHONE PRPH,CI_WFM CW,CI_WFM_OPT CWO WHERE PRPH.PER_ID = PER.PER_ID  AND CWO.WFM_NAME = CW.WFM_NAME AND CWO.EXT_OPT_TYPE = :homePhone AND CW.WFM_NAME = 'SCHEMACONST' AND TRIM(PRPH.PHONE_TYPE_CD) = CWO.WFM_OPT_VAL ) ");
            //getMainPersonDtls.append("WHEN  'B' THEN (SELECT PRPH.PHONE FROM CI_PER_PHONE PRPH,CI_WFM CW,CI_WFM_OPT CWO WHERE PRPH.PER_ID = PER.PER_ID  AND CWO.WFM_NAME = CW.WFM_NAME AND CWO.EXT_OPT_TYPE = :busnPhone AND CW.WFM_NAME = 'SCHEMACONST' AND TRIM(PRPH.PHONE_TYPE_CD) = CWO.WFM_OPT_VAL ) ");
            getMainPersonDtls.append("WHEN 'P' THEN (SELECT PRPH.PHONE FROM CI_PER_PHONE PRPH,CI_WFM CW,CI_WFM_OPT CWO WHERE PRPH.PER_ID = PER.PER_ID  AND CWO.WFM_NAME = CW.WFM_NAME AND CWO.EXT_OPT_TYPE = :homePhone AND CW.WFM_NAME = 'SCHEMACONST' AND TRIM(PRPH.PHONE_TYPE_CD) = CWO.WFM_OPT_VAL AND ROWNUM <= 1 ) ");
            getMainPersonDtls.append("WHEN  'B' THEN (SELECT PRPH.PHONE FROM CI_PER_PHONE PRPH,CI_WFM CW,CI_WFM_OPT CWO WHERE PRPH.PER_ID = PER.PER_ID  AND CWO.WFM_NAME = CW.WFM_NAME AND CWO.EXT_OPT_TYPE = :busnPhone AND CW.WFM_NAME = 'SCHEMACONST' AND TRIM(PRPH.PHONE_TYPE_CD) = CWO.WFM_OPT_VAL AND ROWNUM <= 1 ) ");

            /*
             * End Change - 2014-01-13 Ujesh IM-043433
             */ 
            
            getMainPersonDtls.append(" END) PER_MAIN_PHONE, ");
            getMainPersonDtls.append(" (CASE PER_OR_BUS_FLG  ");
            
            /*
             * Start Change - 2014-01-13 Ujesh IM-043433
             */ 
            
            //getMainPersonDtls.append(" WHEN 'P' THEN (SELECT PRPH.PHONE FROM CI_PER_PHONE PRPH,CI_WFM CW,CI_WFM_OPT CWO WHERE PRPH.PER_ID = PER.PER_ID  AND CWO.WFM_NAME = CW.WFM_NAME AND CWO.EXT_OPT_TYPE = :mobilePhone AND CW.WFM_NAME = 'SCHEMACONST' AND TRIM(PRPH.PHONE_TYPE_CD) = CWO.WFM_OPT_VAL ) ");
            getMainPersonDtls.append(" WHEN 'P' THEN (SELECT PRPH.PHONE FROM CI_PER_PHONE PRPH,CI_WFM CW,CI_WFM_OPT CWO WHERE PRPH.PER_ID = PER.PER_ID  AND CWO.WFM_NAME = CW.WFM_NAME AND CWO.EXT_OPT_TYPE = :mobilePhone AND CW.WFM_NAME = 'SCHEMACONST' AND TRIM(PRPH.PHONE_TYPE_CD) = CWO.WFM_OPT_VAL AND ROWNUM <= 1 ) ");
            
            /*
             * End Change - 2014-01-13 Ujesh IM-043433
             */ 
            
            getMainPersonDtls.append(" WHEN  'B' THEN (' ') ");
            getMainPersonDtls.append(" END) CELL_PHONE, ");
            getMainPersonDtls.append("(CASE PER_OR_BUS_FLG  ");
            
            /*
             * Start Change - 2014-01-13 Ujesh IM-043433
             */ 
            
            //getMainPersonDtls.append("WHEN 'P' THEN (SELECT PRPH.PHONE FROM CI_PER_PHONE PRPH,CI_WFM CW,CI_WFM_OPT CWO WHERE PRPH.PER_ID = PER.PER_ID  AND CWO.WFM_NAME = CW.WFM_NAME AND CWO.EXT_OPT_TYPE = :workPhone AND CW.WFM_NAME = 'SCHEMACONST' AND TRIM(PRPH.PHONE_TYPE_CD) = CWO.WFM_OPT_VAL ) ");
            getMainPersonDtls.append("WHEN 'P' THEN (SELECT PRPH.PHONE FROM CI_PER_PHONE PRPH,CI_WFM CW,CI_WFM_OPT CWO WHERE PRPH.PER_ID = PER.PER_ID  AND CWO.WFM_NAME = CW.WFM_NAME AND CWO.EXT_OPT_TYPE = :workPhone AND CW.WFM_NAME = 'SCHEMACONST' AND TRIM(PRPH.PHONE_TYPE_CD) = CWO.WFM_OPT_VAL AND ROWNUM <= 1 ) ");
            
            /*
             * Start Change - 2014-01-13 Ujesh IM-043433
             */ 
            
            getMainPersonDtls.append("WHEN  'B' THEN (' ') ");
            getMainPersonDtls.append(" END) WORK_PHONE ");
            getMainPersonDtls.append("FROM CI_ACCT_PER ACPR,CI_PER PER,CI_PER_NAME PRNM ");
            getMainPersonDtls.append("WHERE ACPR.ACCT_ID = :acctId ");
            getMainPersonDtls.append("AND PRNM.PER_ID =  PER.PER_ID ");
            getMainPersonDtls.append("AND ACPR.PER_ID = PER.PER_ID ");
            getMainPersonDtls.append("AND PRNM.NAME_TYPE_FLG = :primFlg ");
            getMainPersonDtls.append("AND ACPR.MAIN_CUST_SW = 'Y' ");
            
            //Start Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            //PreparedStatement pstmt =  createPreparedStatement(getMainPersonDtls.toString());
            PreparedStatement pstmt =  createPreparedStatement(getMainPersonDtls.toString(), getClass().getName());
            //End Change - 2016-02-18 - MPang - Updated for Updated for CCB v2.4 compilation
            
            pstmt.bindId("acctId", acctId);
           // pstmt.bindStringProperty("schConst",FeatureConfiguration.properties., SCHEMA_CONST);
            pstmt.bindLookup("perIdntfr", SchemaConstantOptionLookup.constants.SSN_ID_TYPE);
            pstmt.bindLookup("bsnIdntfr", SchemaConstantOptionLookup.constants.TAX_IDENTIFIER_TYPE); 
            pstmt.bindLookup("homePhone", SchemaConstantOptionLookup.constants.HOME_PHONE);
            pstmt.bindLookup("busnPhone", SchemaConstantOptionLookup.constants.BUSINESS_PHONE);
            pstmt.bindLookup("mobilePhone", SchemaConstantOptionLookup.constants.MOBILE_PHONE);
            pstmt.bindLookup("workPhone", SchemaConstantOptionLookup.constants.WORK_PHONE_TYPE); 
            
            pstmt.bindLookup("primFlg", NameTypeLookup.constants.PRIMARY);
            result = pstmt.firstRow();
            pstmt.close();
            return result;
        }
    
        /**
         * To Get the Account Mailing Address 
         * @param Account Id
         * @return SQLResultRow
         */
        private String getAccountMailAddress(Account_Id accountId){
        	//Start Change -Dhuynh- 2015-09-18 Df#3272420
        	StringBuilder premiseAddr  = new StringBuilder();       	
        	
            try {

            	AccountMailingAddressData acctMailData = accountId.getEntity().fetchMailingAddress(perId.getEntity());              
                
                premiseAddr.append(toUpperAndEncloseinQuote(acctMailData.getAddress1()));
                premiseAddr.append(COLUMN_SEPERATOR);
                premiseAddr.append(toUpperAndEncloseinQuote(acctMailData.getAddress2()));
                premiseAddr.append(COLUMN_SEPERATOR);
                premiseAddr.append(toUpperAndEncloseinQuote(acctMailData.getAddress3()));
                premiseAddr.append(COLUMN_SEPERATOR);
                premiseAddr.append(toUpperAndEncloseinQuote(acctMailData.getAddress4()));
                premiseAddr.append(COLUMN_SEPERATOR);
                premiseAddr.append(toUpperAndEncloseinQuote(acctMailData.getCity()));
                premiseAddr.append(COLUMN_SEPERATOR);
		
                /*
                 * Start Add - 2014-01-30 Ujesh IM-043433
                 */
                if(isNull(acctMailData.getState())) {
             
                    createToDoEntry(accountId, "State");
                    return null;
                }
                else {
                
                    premiseAddr.append(toUpperAndEncloseinQuote(acctMailData.getState().fetchIdState()));
                }
                
                /*
                 * End Add - 2014-01-30 Ujesh IM-043433
                 */
                
                
                premiseAddr.append(COLUMN_SEPERATOR);
                premiseAddr.append(toUpperAndEncloseinQuote(acctMailData.getPostalCode()));
                
                return premiseAddr.toString();
            	
			} catch (ApplicationError ae) {

				logError(ae.getServerMessage());
			    premiseAddr.append(toUpperAndEncloseinQuote(""));
				premiseAddr.append(COLUMN_SEPERATOR);
				premiseAddr.append(toUpperAndEncloseinQuote(""));
				premiseAddr.append(COLUMN_SEPERATOR);
				premiseAddr.append(toUpperAndEncloseinQuote(""));
				premiseAddr.append(COLUMN_SEPERATOR);
				premiseAddr.append(toUpperAndEncloseinQuote(""));
				premiseAddr.append(COLUMN_SEPERATOR);
				premiseAddr.append(toUpperAndEncloseinQuote(""));
				premiseAddr.append(COLUMN_SEPERATOR);
				premiseAddr.append(toUpperAndEncloseinQuote(""));
				premiseAddr.append(COLUMN_SEPERATOR);
				premiseAddr.append(toUpperAndEncloseinQuote(""));
				createToDoEntry(accountId, "(Mailing Address)");
				
			}
			catch (Exception e) {

				e.printStackTrace();
			    premiseAddr.append(toUpperAndEncloseinQuote(""));
				premiseAddr.append(COLUMN_SEPERATOR);
				premiseAddr.append(toUpperAndEncloseinQuote(""));
				premiseAddr.append(COLUMN_SEPERATOR);
				premiseAddr.append(toUpperAndEncloseinQuote(""));
				premiseAddr.append(COLUMN_SEPERATOR);
				premiseAddr.append(toUpperAndEncloseinQuote(""));
				premiseAddr.append(COLUMN_SEPERATOR);
				premiseAddr.append(toUpperAndEncloseinQuote(""));
				premiseAddr.append(COLUMN_SEPERATOR);
				premiseAddr.append(toUpperAndEncloseinQuote(""));
				premiseAddr.append(COLUMN_SEPERATOR);
				premiseAddr.append(toUpperAndEncloseinQuote(""));
				createToDoEntry(accountId, "(Mailing Address)");

			}

			return premiseAddr.toString();      
            
			//End Change -Dhuynh- 2015-09-18 Df#3272420
        }
        
        
        
        /**
         * Retrieves the Service Premise Address 
         * @param Premise Id
         * @return String
         */     
        private String preparePremiseAddr(Premise_Id premiseId){
            
            Premise premise = premiseId.getEntity();
            StringBuilder premiseAddr  = new StringBuilder();
            
            premiseAddr.append(toUpperAndEncloseinQuote(premise.getAddress1()));
            premiseAddr.append(COLUMN_SEPERATOR);
            premiseAddr.append(toUpperAndEncloseinQuote(premise.getAddress2()));
            premiseAddr.append(COLUMN_SEPERATOR);
            premiseAddr.append(toUpperAndEncloseinQuote(premise.getAddress3()));
            premiseAddr.append(COLUMN_SEPERATOR);
            premiseAddr.append(toUpperAndEncloseinQuote(premise.getAddress4()));
            premiseAddr.append(COLUMN_SEPERATOR);
            premiseAddr.append(toUpperAndEncloseinQuote(premise.getCity()));
            premiseAddr.append(COLUMN_SEPERATOR);
            premiseAddr.append(toUpperAndEncloseinQuote(premise.getState()));
            premiseAddr.append(COLUMN_SEPERATOR);
            premiseAddr.append(toUpperAndEncloseinQuote(premise.getPostal()));
            return premiseAddr.toString();
        }
        
        
        /**
         * Creates Header Line for the Initial Referral File
         */
        
        private void createInitHeaderLine(){

            StringBuilder headerLineBuilder = new StringBuilder();
            headerLineBuilder.append(ACCT_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(RFRL_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(PREM_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(RFRL_TYP);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(PER_BUS);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(PER_NAM);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(getMainAddressHeader().toString());
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(getServiceAddressHeader().toString());
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(PER_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(PHN_MAIN);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(PHN_WRK);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(PHN_CELL);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(ON_DT);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(OFF_DT);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(LAST_PAY_DT);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(AGNCY_NAME);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(IMPRT_DT);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(CUR_BAL);
                        
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - Start
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_PER_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_CIS_DIVISION);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_SA_TYPE);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_SA_RATE_CL);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_FINAL_BILL_DT);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_BLDG_MTR);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_OPS_AREA);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(HDR_DISCONNECT_RSN);
            // CCB004.008 (CR3135978) - MCruz 2015-01-07 - End
                        
            /* START ADD - JHERNA - 2021-11-03 - SysAid#383853 */
            // add 2 new header fields
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(DELINQUENCY_DT);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(DELINQUENCY_AMT);
            /* END ADD - JHERNA - 2021-11-03 - SysAid#383853 */
            
            writeLineInitFile(headerLineBuilder.toString());
        }
        
        private void createFinHeaderLine(){

            StringBuilder headerLineBuilder = new StringBuilder();
            headerLineBuilder.append(ACCT_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(RFRL_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(PREM_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(CUR_BAL);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(AMOUNT);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(TRANSACT_DTTM);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(TRANSACT_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(UPD_RSN);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(EXPRT_DTTM);

            writeLineFinFile(headerLineBuilder.toString());
        
        }
        
        /**
         * Method returns the Main Address Part of Header Line
         * @return String
         */
        
        private String getMainAddressHeader(){
            StringBuilder headerLineBuilder = new StringBuilder();
            headerLineBuilder.append(MAIL_ADDR1);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(MAIL_ADDR2);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(MAIL_ADDR3);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(MAIL_ADDR4);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(MAIL_CITY);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(MAIL_STATE);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(MAIL_ZIP); 
            return headerLineBuilder.toString();
        }
        
        /**
         * Method returns the Service Address Part of Header Line
         * @return String
         */     
        private String getServiceAddressHeader(){   
            
            StringBuilder headerLineBuilder = new StringBuilder();
            headerLineBuilder.append(SRVC_ADDR1);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(SRVC_ADDR2);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(SRVC_ADDR3);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(SRVC_ADDR4);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(SRVC_CITY);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(SRVC_STATE);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(SRVC_ZIP);
            return headerLineBuilder.toString();
        }
        
        private void createPeruHeaderLine(){
            StringBuilder headerLineBuilder = new StringBuilder();
            headerLineBuilder.append(ACCT_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(RFRL_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(PREM_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(PER_BUS);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(PER_NAM);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(getMainAddressHeader().toString());
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(PER_ID);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(PHN_MAIN);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(PHN_WRK);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(PHN_CELL);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(AGNCY_NAME);
            headerLineBuilder.append(COLUMN_SEPERATOR);
            headerLineBuilder.append(IMPRT_DT);
            writeLinePeruFile(headerLineBuilder.toString());
        }
        
        /**
         * Open File Writer
         */
        private void openFileWriter(ReferralHistoryReasonLookup refHistRsnLkp){ 
            File inputFilePathAndName = null;
            String strNewFileName = null;
            String strFileNameNoExt = null;
            String strExtension = null;
            //check if the input file name has an extension
            if(strFileName.lastIndexOf(".") !=-1){
                strFileNameNoExt = strFileName.substring(0, strFileName.lastIndexOf("."));
                strExtension  = strFileName.substring(strFileName.lastIndexOf("."));
            }else{
                strFileNameNoExt = strFileName;
                strExtension = ".txt";
            }
            
            if(refHistRsnLkp.isInitialReferral()){
                strNewFileName = strFileNameNoExt + INIT_FILE_EXT+strExtension;
                inputFilePathAndName = new File(strFilePath, strNewFileName);
                
            }else if(refHistRsnLkp.isPersonalUpdates()){
                strNewFileName = strFileNameNoExt + PERU_FILE_EXT + strExtension;
                inputFilePathAndName = new File(strFilePath, strNewFileName);
            }else{
                strNewFileName = strFileNameNoExt + CHG_FILE_EXT + strExtension;
                inputFilePathAndName = new File(strFilePath, strNewFileName);
            }
            try { 
                if(refHistRsnLkp.isInitialReferral()){
                    initBufferedWriter = new BufferedWriter(new FileWriter(inputFilePathAndName));
                }else if(refHistRsnLkp.isPersonalUpdates()){
                    peruBufferedWriter = new BufferedWriter(new FileWriter(inputFilePathAndName));
                }else{
                    finBufferedWriter = new BufferedWriter(new FileWriter(inputFilePathAndName));
                }
                
            } catch (IOException e) {
                 addError(CustomMessageRepository.ni0040_1ErrorInFileOpen(strFilePath,strFileName));
                
            }
        }
        

        
        /**
         * Write a Line to Initial Referral File
         */
        private void writeLineInitFile(String recordline){      

            try {
                getInitBufferedWriter().write(recordline);
                getInitBufferedWriter().newLine();
            } catch (IOException e) {
                addError(CustomMessageRepository.ni0040_1ErrorInFileWrite(strFilePath,strFileName));
                
            }
        }
        
        
        /**
         * Write a Line to Personal Updates File
         */
        private void writeLinePeruFile(String recordline){      

            try {
                getPeruBufferedWriter().write(recordline);
                getPeruBufferedWriter().newLine();
            } catch (IOException e) {
                addError(CustomMessageRepository.ni0040_1ErrorInFileWrite(strFilePath,strFileName));
                }
        }
        
        /**
         * Write a Line to Financial Updates File
         */
        private void writeLineFinFile(String recordline){       

            try {
                getFinBufferedWriter().write(recordline);
                getFinBufferedWriter().newLine();
            } catch (IOException e) {
                addError(CustomMessageRepository.ni0040_1ErrorInFileWrite(strFilePath,strFileName));
                
            }
        }
        
        
        /**
         * Get Writer to the Initial Referral File
         */     
        private BufferedWriter getInitBufferedWriter(){
              return initBufferedWriter;
        }
        
        /**
         * Get Writer to the Personal Updates File
         */         
        private BufferedWriter getPeruBufferedWriter(){
              return peruBufferedWriter;
        }
        
        /**
         * Get Writer to the Financial Updates File
         */         
        private BufferedWriter getFinBufferedWriter(){
              return finBufferedWriter;
        }
        
        /*
         * Start Add - 2014-01-13 Ujesh IM-043714
         */
        
        /**
         * This method create a ToDoEntry.
         *
         */
        @SuppressWarnings("rawtypes")
		private void createToDoEntry(Account_Id account_Id,String missingField) {
            ArrayList <String> sortKeyValues = new ArrayList<String> ();
            ArrayList <String> messageParameterList = new ArrayList<String> ();
            ArrayList <ToDoSortKeyValue_DTO>  sortKeyList = new ArrayList<ToDoSortKeyValue_DTO> ();
            ArrayList <ToDoDrillKeyValue_DTO> drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO> ();
            ArrayList <ToDoEntryCharacteristic_DTO>  charList = new ArrayList<ToDoEntryCharacteristic_DTO> ();

            ToDoEntry_DTO toDoEntryDTO = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
            ToDoType toDoType = getParameters().getTO_DO_TYPE();

            // Set ToDo Type
            toDoEntryDTO.setToDoTypeId(toDoType.getId());

            Role_Id toDoRoleId = getParameters().getTO_DO_ROLE().getId();

            toDoEntryDTO.setToDoRoleId(toDoRoleId);

            ServerMessage message = CustomMessageRepository.nb0088MandatoryFieldMissing(missingField);
            //Validate Message Id
            toDoEntryDTO.setMessageId(message.getMessageId());

            // Batch Process Information
            toDoEntryDTO.setBatchControlId(getBatchControlId());
            toDoEntryDTO.setBatchNumber(getBatchNumber());

            // Set ToDo Entry status
            toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);

            // Set ToDo's Priority
            toDoEntryDTO.setToDoPriority(toDoType.getToDoPriority());

            // Set Creation Date Time
            toDoEntryDTO.setCreationDateTime(this.getProcessDateTime());

            // Set Sort Key List
            // Get the Sort Key Types of a certain ToDo Type
            ToDoTypeSortKeyTypes toDoTypeSortKeyTypes = toDoType.getSortKeyTypes();
            // Create a DTO for Retrieving the Sort Key Values
            ToDoSortKeyValue_DTO toDoSortKeyValueDTO;
            sortKeyValues.add(0, account_Id.getIdValue());


            // For every sort key type, place the String sort key value to it
            Iterator <String> sortKeyValue = sortKeyValues.iterator();
            for (Iterator<ToDoSortKeyType> sortKeyItr = toDoTypeSortKeyTypes.iterator(); sortKeyItr.hasNext(); sortKeyList.add(toDoSortKeyValueDTO)) {
                toDoSortKeyValueDTO = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
                ToDoSortKeyType toDoSortKeyType = sortKeyItr.next();
                BigInteger toDoSortKeyIdSeq = toDoSortKeyType.fetchIdSequence();
                toDoSortKeyValueDTO.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL,toDoSortKeyIdSeq));
                if(sortKeyValue.hasNext()){
                    toDoSortKeyValueDTO.setKeyValue(sortKeyValue.next());
                }
            }

            // Get the Drill Key Types of a certain ToDoType
            ToDoTypeDrillKeyTypes toDoTypeDrillKeyTypes = toDoType.getDrillKeyTypes();
            // Create a DTO for retrieving the Drill Key Value
            ToDoDrillKeyValue_DTO toDoDrillKeyValueDTO;
            // For every drill key type, place the String drill key value to it
            Bool isFirstDrillKey = Bool.TRUE;
            for (Iterator iterator = (Iterator) toDoTypeDrillKeyTypes.iterator(); iterator.hasNext(); ) {

                toDoDrillKeyValueDTO = (ToDoDrillKeyValue_DTO) createDTO(ToDoDrillKeyValue.class);
                ToDoDrillKeyType toDoDrillKeyType = (ToDoDrillKeyType) iterator.next();
                BigInteger toDoDrillKeyIdSeq = toDoDrillKeyType.getId().getSequence();
                // To Do's Drill Key's 1st sequence should be the account payment table
                if(isFirstDrillKey.isTrue()){
                    toDoDrillKeyValueDTO.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL,toDoDrillKeyIdSeq));
                    toDoDrillKeyValueDTO.setKeyValue(account_Id.getTrimmedValue());
                    drillKeyList.add(toDoDrillKeyValueDTO);
                }
            }
            // Set the message parameters
            messageParameterList.add(0, missingField);
            

            // Create the ToDoEntry
            ToDoMaintenanceData toDoMaintData = ToDoMaintenanceData.Factory.newInstance();
            toDoMaintData.setEntryDto(toDoEntryDTO);
            toDoMaintData.setSortKeys(sortKeyList);
            toDoMaintData.setDrillKeys(drillKeyList);
            toDoMaintData.setMessageParams(messageParameterList);
            toDoMaintData.setToDoCharacteristics(charList);
            ToDoEntryProcessor toDoEntryProcessor = ToDoEntryProcessor.Factory.newInstance();
            toDoEntryProcessor.addToDo(toDoMaintData);
        }
        
        /*
         * End Add - 2014-01-13 Ujesh IM-043714
         */             
        
        
        
        /**
         * Close File Writer after all the records for this thread are processed.
         */
        public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException{

            try {
                if(notNull(initBufferedWriter)){
                   initBufferedWriter.close();
                }
                if(notNull(peruBufferedWriter)){
                    peruBufferedWriter.close();
                }
                if(notNull(finBufferedWriter)){
                    finBufferedWriter.close();
                }
                
            } catch (IOException e) {
                addError(CustomMessageRepository.ni0040_1ErrorInFileClose(strFilePath,strFileName));
                
            }
        }

    }//Inner Class

}
