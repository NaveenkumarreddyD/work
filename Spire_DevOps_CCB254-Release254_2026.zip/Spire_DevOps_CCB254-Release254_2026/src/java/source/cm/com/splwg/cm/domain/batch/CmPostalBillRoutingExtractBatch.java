/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Custom Postal Bill Routing Extract Batch.
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Re-coded for performance issue.
 * 
 *************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadIterationStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.datatypes.StringId;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.StandardMessages;
import com.splwg.base.domain.common.algorithm.Algorithm_Id;
import com.splwg.base.domain.common.currency.Currency;
import com.splwg.base.domain.common.currency.Currency_Id;
import com.splwg.base.domain.common.installation.Installation_Id;
import com.splwg.ccb.api.lookup.AlternateBillIdOptionLookup;
import com.splwg.ccb.domain.admin.billRouteType.algorithm.billExtract.BillExtractInputData;
import com.splwg.ccb.domain.admin.billRouteType.algorithm.billExtract.BillExtractOutputData;
import com.splwg.ccb.domain.admin.billRouteType.entity.BillRouteType;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillRouting;
import com.splwg.ccb.domain.billing.bill.entity.BillRouting_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.common.installation.entity.Installation;
import com.splwg.cm.api.batch.CmPostRouteBillExtractPrinterKeyRecord;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.common.StringUtilities;

/**
 * @author 90622
 *
@BatchJob (modules = {}, softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)})
 */
public class CmPostalBillRoutingExtractBatch 
		extends CmPostalBillRoutingExtractBatch_Gen {

	public Class<CmPostalBillRoutingExtractBatchWorker> getThreadWorkerClass() {
		return CmPostalBillRoutingExtractBatchWorker.class;
	}

	public static class CmPostalBillRoutingExtractBatchWorker 
			extends CmPostalBillRoutingExtractBatchWorker_Gen {
		
		// Constants
		private static final Currency_Id USD = new Currency_Id("USD");
		// Variables
		private String parmFilePath;
		private String parmFileName;
		private String resultingFilePathName;
		private int wBillCnt;
		private Bool wSkipBillSw;
		private Bill_Id wTempBillID;
		private Money wTotalAmt;
		
		private File wFile;
		private BufferedWriter wBufferedWriter;
		
		
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new ThreadIterationStrategy(this);
		}

		@SuppressWarnings("rawtypes")
		@Override
		protected QueryIterator getQueryIteratorForThread(StringId lowId,
				StringId highId) {
			
			StringBuilder stringBuilder = new StringBuilder();			
			stringBuilder.append("SELECT ");
			stringBuilder.append("    BILL_ID, ");
			stringBuilder.append("    SEQNO ");
			stringBuilder.append("FROM ");
			stringBuilder.append("    CI_BILL_ROUTING ");
			stringBuilder.append("WHERE BILL_ID BETWEEN :billIdStart AND :billIdEnd ");
			stringBuilder.append("AND BATCH_CD = :batchCd ");
			stringBuilder.append("AND BATCH_NBR = :batchNbr ");
			stringBuilder.append("AND NO_BATCH_PRT_SW = 'N' ");			
			stringBuilder.append("ORDER BY BILL_ID, SEQNO ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(),"=getQueryIteratorForThread=");			
			prepState.bindId("billIdStart", lowId);
			prepState.bindId("billIdEnd", highId);
			prepState.bindId("batchCd", this.getBatchControlId());
			prepState.bindBigInteger("batchNbr", this.getBatchNumber());
			prepState.execute();
			
			QueryIterator recordsToProcess = prepState.iterate();
			return recordsToProcess;
		}

		@Override
		protected ThreadWorkUnit getNextWorkUnit(QueryResultRow qrw) {
			
			ThreadWorkUnit twu = new ThreadWorkUnit();
			Bill_Id billID = (Bill_Id) qrw.getId("BILL_ID", Bill.class);
			BigInteger seqNo = qrw.getInteger("SEQNO");							
			twu.setPrimaryId(billID);
			twu.addSupplementalData("SEQ_NO", seqNo);
			return twu;
		}		

		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful,
				ThreadWorkUnit lastWorkUnit) throws ThreadAbortedException,
				RunAbortedException {
			
			this.startResultRowQueryIteratorForThread(Bill_Id.class);
			parmFilePath = this.getParameters().getFILE_PATH();
			parmFileName = this.getParameters().getFILE_NAME();
			
			wBillCnt = 0;
			wSkipBillSw = Bool.FALSE;
			wTempBillID = null;
			wTotalAmt = new Money(BigDecimal.ZERO, USD);
			
			// Prepare File Name and then create and open the file for writing
			prepareFileName();
			openFile();
			closeFile();
			
			// Check bill without sequential number
			checkBillsWithoutSeqNo();
		}
		
		private void prepareFileName() {
						
			//Ensure that the file path uses "/" and that it has a "/" at the end.
			String filePath = parmFilePath.replace("\\", "/");
			filePath = filePath.trim();
			if (filePath.endsWith("/")) {
				resultingFilePathName = filePath.trim().concat(parmFileName.trim());
			}
			else {
				resultingFilePathName = filePath.trim().concat("/");
				resultingFilePathName = resultingFilePathName.trim().concat(parmFileName.trim());
			}						
			
			// If ?? is present in the file name, replace it with the thread number
			if (resultingFilePathName.indexOf("??") >= 0) {
				resultingFilePathName = resultingFilePathName.replace("??", String.format("%02d", getBatchThreadNumber()));
			} else if (resultingFilePathName.indexOf("?") >= 0) {

				if(getBatchThreadNumber().compareTo(BigInteger.valueOf(9)) > 0) {
					addError(StandardMessages.fieldMissing("BATCH_THD_NBR"));
				}
				resultingFilePathName = resultingFilePathName.replace("?", String.format("%01d", getBatchThreadNumber()));
			}
		}
		
		private void openFile() {			
			try {
    			wFile = new File(resultingFilePathName);
				wBufferedWriter = new BufferedWriter(new FileWriter(wFile));
			} 
            catch (Exception e) {
            	e.printStackTrace();
            	throw new RunAbortedException(CustomMessageRepositoryMGE.commGenericErrorOpeningFile(resultingFilePathName));
			}
		}		
		
		private void closeFile() {
			try {
				wBufferedWriter.close();
			}
			catch (Exception e) {
				e.printStackTrace();
				addError(CustomMessageRepositoryMGE.commGenericErrorClosingFile(resultingFilePathName));
			}
		}
		
		private void checkBillsWithoutSeqNo() {
			
			// Retrieve Installation Option and Alternate Bill Id Switch			
			StringBuilder getInstOptStr = new StringBuilder();			
			getInstOptStr.append("SELECT  ");
			getInstOptStr.append("    INSTALL_OPT_ID,  ");
			getInstOptStr.append("    USE_ALT_BILL_ID_SW, ");
			getInstOptStr.append("    ALT_BILL_ID_OPT_FLG ");
			getInstOptStr.append("FROM CI_INSTALLATION ");
			PreparedStatement getInstOptPS = createPreparedStatement(getInstOptStr.toString(), "=getInstOpt=");
			getInstOptPS.execute();
			getInstOptPS.setAutoclose(false);
			
			if (notNull(getInstOptPS.firstRow())) {
				SQLResultRow sqlRow1 = getInstOptPS.firstRow();
				@SuppressWarnings("unused")
				Installation_Id installationID = (Installation_Id) sqlRow1.getId("INSTALL_OPT_ID", Installation.class);
				Bool useAlternateBillIdSw = sqlRow1.getBoolean("USE_ALT_BILL_ID_SW");
				AlternateBillIdOptionLookup altBillIdOptFlg = 
						sqlRow1.getLookup("ALT_BILL_ID_OPT_FLG", AlternateBillIdOptionLookup.class);
				
				getInstOptPS.close();
				if (useAlternateBillIdSw.isTrue()) {
					/*
					 * If system uses sequential bill number and there is a
					 * completed bill without sequential number, log an error.
					 */					
					if (notNull(altBillIdOptFlg)
							&& altBillIdOptFlg.isSeqBillNumbers()) {
						StringBuilder stringBuilder = new StringBuilder();						
						stringBuilder.append("SELECT "); 
						stringBuilder.append("    'X' ");
						stringBuilder.append("FROM "); 
						stringBuilder.append("    CI_BILL_ROUTING RTG, ");
						stringBuilder.append("    CI_BILL BL ");
						stringBuilder.append("WHERE RTG.BATCH_CD = :batchCd ");
						stringBuilder.append("AND RTG.BATCH_NBR = :batchNbr ");
						stringBuilder.append("AND RTG.NO_BATCH_PRT_SW = 'N' ");
						stringBuilder.append("AND BL.BILL_ID = RTG.BILL_ID ");
						stringBuilder.append("AND BL.ALT_BILL_ID = 0 ");
						stringBuilder.append("AND BL.BILL_STAT_FLG = 'C' ");
						PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=checkBillHasSeqNbr=");
						prepState.bindId("batchCd", this.getBatchControlId());
						prepState.bindBigInteger("batchNbr", this.getBatchNumber());
						prepState.execute();
						prepState.setAutoclose(false);
						if (notNull(prepState.firstRow())) {
							prepState.close();
							//A bill to be extracted for printing is not assigned a sequential bill number.
							throw new RunAbortedException(CustomMessageRepositoryMGE.commGenericError(
									"A bill to be extracted for printing is not assigned a sequential bill number."));
						}
						prepState.close();						
					}
					/*
					 * If system uses sequential bill number and there is a
					 * completed bill without document number, log an error.
					 */
					if (notNull(altBillIdOptFlg)
							&& altBillIdOptFlg.isDocNumbers()) {
						StringBuilder stringBuilder = new StringBuilder();						
						stringBuilder.append("SELECT "); 
						stringBuilder.append("    'X' ");
						stringBuilder.append("FROM "); 
						stringBuilder.append("    CI_BILL_ROUTING RTG, ");
						stringBuilder.append("    CI_BILL BL ");
						stringBuilder.append("WHERE RTG.BATCH_CD = :batchCd ");
						stringBuilder.append("AND RTG.BATCH_NBR = :batchNbr ");
						stringBuilder.append("AND RTG.NO_BATCH_PRT_SW = 'N' ");
						stringBuilder.append("AND BL.BILL_ID = RTG.BILL_ID ");
						stringBuilder.append("AND BL.DOC_ID = ' ' ");
						stringBuilder.append("AND BL.BILL_STAT_FLG = 'C' ");
						PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=checkBillHasDocNbr=");
						prepState.bindId("batchCd", this.getBatchControlId());
						prepState.bindBigInteger("batchNbr", this.getBatchNumber());
						prepState.execute();
						prepState.setAutoclose(false);
						if (notNull(prepState.firstRow())) {
							prepState.close();
							//A bill to be extracted for printing is not assigned a document bill number.
							throw new RunAbortedException(CustomMessageRepositoryMGE.commGenericError(
									"A bill to be extracted for printing is not assigned a document bill number."));
						}
						prepState.close();							
					}					
				}				
			}
			getInstOptPS.close();			
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			Bill_Id billID = (Bill_Id) unit.getPrimaryId();
			BigInteger seqNo = (BigInteger) unit.getSupplementallData("SEQ_NO");
						
			BillRouting_Id billRoutingID = new BillRouting_Id(billID, seqNo);
			BillRouting billRouting = billRoutingID.getEntity();
			
			// Determine Extract Algorithm
			BillRouteType billRouteType = billRouting.fetchBillRouteType();
			Algorithm_Id extractAlgorithmID = billRouteType.getExtractAlgorithmId();
			
			// Process Completed Bills only (skip pending bills including those on re-opened status)
			Bill bill = billRouting.fetchIdBill();
			int nbrOfBillCopies = billRouting.getNumberOfBillCopies().intValue();
			// Only Complete Bills are processed
			// (skip pending bills -- those which were reopened)
			if (bill.getBillStatus().isComplete()
					&& nbrOfBillCopies > 0) {
				
				// Extract Bill
				extractBill(bill.getId(), billRouting, billRouteType, extractAlgorithmID);
				
				if (wSkipBillSw.isFalse()) {
					wBillCnt = wBillCnt + nbrOfBillCopies;
				}				
			}
			
			// Stamp the record as extracted on the Bill Routing table
			stampBillAsExtracted(billID, seqNo);
			
			return true;
		}
		
		private void stampBillAsExtracted(Bill_Id billID, BigInteger seqNo) {
			
			StringBuilder stringBuilder = new StringBuilder();			
			stringBuilder.append("UPDATE ");
			stringBuilder.append("    CI_BILL_ROUTING ");
			stringBuilder.append("SET ");
			stringBuilder.append("    EXTRACT_DTTM = :extractDttm ");
			stringBuilder.append("WHERE  ");
			stringBuilder.append("    BILL_ID = :billID  ");
			stringBuilder.append("    AND SEQNO = :seqNo ");
			stringBuilder.append("    AND BATCH_CD = :batchCd ");
			stringBuilder.append("    AND BATCH_NBR = :batchNbr ");
			stringBuilder.append("    AND NO_BATCH_PRT_SW = 'N' ");			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==stampBillAsExtracted==");
			prepState.bindDateTime("extractDttm", this.getProcessDateTime());
			prepState.bindId("billID", billID);
			prepState.bindBigInteger("seqNo", seqNo);
			prepState.bindId("batchCd", this.getBatchControlId());
			prepState.bindBigInteger("batchNbr", this.getBatchNumber());
			prepState.execute();
			PreparedStatement psCommit = createPreparedStatement("COMMIT", "==commit==");
			psCommit.execute();
			psCommit.close();
			prepState.close();			
		}

		private void extractBill(Bill_Id billID,
				BillRouting billRouting,
				BillRouteType billRouteType,
				Algorithm_Id extractAlgorithmID) {
			
			// Execute Extract Algorithm
			try {
				BillExtractInputData inputData = BillExtractInputData.Factory.newInstance();
				inputData.setBatchControl(billRouting.fetchBatchControl());
				inputData.setBatchNumber(billRouting.getBatchNumber());
				inputData.setBill(billRouting.fetchIdBill());
				inputData.setExtractAlgorithm(extractAlgorithmID.getEntity());
				inputData.setExtractFileName(resultingFilePathName.trim());
				inputData.setNumberOfCopies(billRouting.getNumberOfBillCopies());
				inputData.setSequenceNumber(billRouting.fetchIdSequence());
				
				BillExtractOutputData outputData = billRouteType.extractBill(inputData);
				
				wSkipBillSw = outputData.getIsBillSkipped();	
			}
			catch (Exception e) {
				e.printStackTrace();
				throw new RunAbortedException(CustomMessageRepositoryMGE.commGenericError(
						"Error encountered"));
			}					
			/*
			try {
				CobolProgramCIPBXBLW cblPrg = CobolProgramCIPBXBLW.Factory.newInstance();
				CobolCopybookCICBXZZX cpyBook = cblPrg.getCobolCopybookCICBXZZX();
				// Input
				cpyBook.get_INPUT_WRK().set_BATCH_CD(billRouting.fetchBatchControl().getId().getTrimmedValue());
				cpyBook.get_INPUT_WRK().set_BATCH_NBR(billRouting.getBatchNumber());
				cpyBook.get_INPUT_WRK().set_BILL_ID(billRouting.fetchIdBill().getId().getTrimmedValue());
				cpyBook.get_INPUT_WRK().set_SEQNO(billRouting.fetchIdSequence());
				cpyBook.get_INPUT_WRK().set_EXTRACT_ALG_CD(extractAlgorithmID.getTrimmedValue());
				cpyBook.get_INPUT_WRK().set_EXTRACT_FILE_NAME(resultingFilePathName.trim());
				cpyBook.get_INPUT_WRK().set_COPY_CNT(billRouting.getNumberOfBillCopies());
				// Execute the cobol program
				cblPrg.callCobol();
				// Output
				wSkipBillSw = cpyBook.get_OUTPUT_WRK().get_SKIP_BILL_SW();
			}
			catch (Exception e) {
				lg.info("\n\n==ERROR ENCOUNTERED="+e.getMessage()+"==\n\n");
				e.printStackTrace();
			}
			*/
			// Check for Bill Amount
			if (isNull(wTempBillID)
					|| wTempBillID.compareTo(billID) != 0) {
				wTempBillID = billID;
				// Retrieve Total Billed Amount 
				Money totalAmt = getTotalBilledAmount(billID);
				wTotalAmt = wTotalAmt.add(totalAmt);
			}			
		}
		
		private Money getTotalBilledAmount(Bill_Id billID) {
			
			Money returnValue = new Money(BigDecimal.ZERO, USD);
			StringBuilder stringBuilder = new StringBuilder();			
			stringBuilder.append("SELECT ");
			stringBuilder.append("    CURRENCY_CD, ");
			stringBuilder.append("    SUM(CUR_AMT) SUM_CUR_AMT, ");
			stringBuilder.append("    SUM(TOT_AMT) SUM_TOT_AMT ");
			stringBuilder.append("FROM ");
			stringBuilder.append("    CI_FT ");
			stringBuilder.append("WHERE BILL_ID = :billID ");
			stringBuilder.append("AND FT_TYPE_FLG IN ('BS','BX') ");
			stringBuilder.append("AND CORRECTION_SW = 'N' ");
			stringBuilder.append("AND SHOW_ON_BILL_SW = 'Y' ");
			stringBuilder.append("GROUP BY CURRENCY_CD ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=getTotalBilledAmount=");
			prepState.bindId("billID", billID);
			prepState.execute();
			prepState.setAutoclose(false);
			if (notNull(prepState.firstRow())) {
				SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
				Currency_Id currencyID = (Currency_Id) sqlRow.getId("CURRENCY_CD", Currency.class);
				BigDecimal sumCurrentAmountBD = (BigDecimal) sqlRow.getBigDecimal("SUM_CUR_AMT");
				BigDecimal sumTotalAmountBD = (BigDecimal) sqlRow.getBigDecimal("SUM_TOT_AMT");
				sumCurrentAmountBD = sumCurrentAmountBD.setScale(2, BigDecimal.ROUND_HALF_UP);
				sumTotalAmountBD = sumTotalAmountBD.setScale(2, BigDecimal.ROUND_HALF_UP);
				returnValue = new Money(sumTotalAmountBD, currencyID);				
			}
			prepState.close();
			return returnValue;
		}
		
		@Override
		public void finalizeThreadWork() throws ThreadAbortedException,
				RunAbortedException {

			// END PROCESSING
			// Write Batch Thread Summary
			String record = StringUtilities.padRight(CmPostRouteBillExtractPrinterKeyRecord.PRINTER_KEY_EXTRACT_INFO, 26);

			record += StringUtilities.padRight("0", 177);
			record += StringUtilities.padRight(this.getBatchControlId().getTrimmedValue(), 8);
			record += StringUtilities.leftPadWithZeros(this.getBatchNumber().toString(), 10);
			record += StringUtilities.leftPadWithZeros(this.getBatchRerunNumber().toString(), 10);
			record += StringUtilities.leftPadWithZeros(String.valueOf(wBillCnt), 10);
			record += StringUtilities.padRight(this.getProcessDateTime().toString() + ".000000", 26);
			record += StringUtilities.leftPadWithZeros(this.getLowIdForThread(Bill_Id.FIELD_SIZE), 12);
			record += StringUtilities.leftPadWithZeros(this.getHighIdForThread(Bill_Id.FIELD_SIZE), 12);
			record += StringUtilities.leftPadWithZeros(this.getBatchThreadNumber().toString(), 10);
			record += StringUtilities.leftPadWithZeros(this.getParameters().getThreadCount().toString(), 10);
			if (wTotalAmt.isNegative()) {
				record += "-";	
			} else {
				record += "+";
			}			
			record += StringUtilities.leftPadWithZeros(transformImpliedBD(wTotalAmt.getAmount(), 2), 15);	
			
			try {				
				
				File extractFile = new File(resultingFilePathName.trim());
				BufferedWriter bufferedWriter= new BufferedWriter(new FileWriter(extractFile,true));					
				bufferedWriter.append(record);
				bufferedWriter.close();
			} catch (IOException ioE) {
				ioE.printStackTrace();
				addError(CustomMessageRepositoryMGE.commGenericErrorWritingToFile(resultingFilePathName.trim()));
			}
			
			// Total Bills created 
			logMessage(CustomMessageRepositoryMGE.commGenericError(
					"Number of Bills created: "+String.valueOf(wBillCnt)), 
					MessageSeverityLookup.constants.INFORMATIONAL);			
			// Total Amount Billed
			logMessage(CustomMessageRepositoryMGE.commGenericError(
					"Total Amount Billed: "+wTotalAmt.toLocalizedString(new Currency_Id("USD").getEntity())), 
					MessageSeverityLookup.constants.INFORMATIONAL);
		}
		
		private String transformImpliedBD(BigDecimal value, int scale) {		
			String returnValue = " ";
			value = value.setScale(scale, BigDecimal.ROUND_HALF_UP);
			returnValue = value.toString().trim();
			returnValue = returnValue.replaceAll("\\.", "");
			return returnValue;
		}
	}
}
