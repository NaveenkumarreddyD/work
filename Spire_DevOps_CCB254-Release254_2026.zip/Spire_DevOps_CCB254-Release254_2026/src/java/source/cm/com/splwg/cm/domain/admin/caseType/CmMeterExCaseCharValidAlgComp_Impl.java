/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Case Status Entry validation algorithm
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-11-19   Satish           NI0007.5. Initial Version.
 * 2016-01-22   MPang			 Updated for CCB v2.4 compilation
 ******************************************************************************************/
package com.splwg.cm.domain.admin.caseType;

import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseTypeEnterStatusValidationAlgorithmSpot;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCaseCharacteristics;*/

import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.algorithm.enterStatusValidation.EnterStatusValidationAlgorithmSpot;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCaseCharacteristics;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * 
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = correctedException, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = uncorrectedException, required = true, type = string)})
 */
public class CmMeterExCaseCharValidAlgComp_Impl 
		extends CmMeterExCaseCharValidAlgComp_Gen 
		//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
		//implements CaseTypeEnterStatusValidationAlgorithmSpot {
		implements EnterStatusValidationAlgorithmSpot {
		//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation

	// Soft Params
	private String paramCorrectedException;
	private String paramUncorrectedException;
	// Hard Params
	private ToDoCase toDoCase;

	// Class Level Record variables
	private List<CharacteristicType_Id> correctedList = new ArrayList<CharacteristicType_Id>();
	private List<CharacteristicType_Id> uncorrectedList = new ArrayList<CharacteristicType_Id>();
	private List<CharacteristicType_Id> ToDoCaseCharacteristicsList = new ArrayList<CharacteristicType_Id>();
	private static final String COMMA_DELIMITER=",";

	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		initializeSoftParams();
		validateSoftParams();
	}

	private void initializeSoftParams() {
		paramCorrectedException = getCorrectedException().trim();
		paramUncorrectedException = getUncorrectedException().trim();
	}

	private void validateSoftParams() {

		String[] corrected = paramCorrectedException.split(COMMA_DELIMITER);
		String[] uncorrected = paramUncorrectedException.split(COMMA_DELIMITER);

		for (String charType : corrected) {
			CharacteristicType_Id charTypeId = new CharacteristicType_Id(charType);
			if (isNull(charTypeId.getEntity())) {				
				addError(CustomMessageRepository.NI0007_5_invalidCharacteristicType(charType)); 
			} else {
				correctedList.add(charTypeId);
			}
		}

		for (String charType : uncorrected) {
			CharacteristicType_Id charTypeId = new CharacteristicType_Id(charType);
			if (isNull(charTypeId.getEntity())) {
				addError(CustomMessageRepository.NI0007_5_invalidCharacteristicType(charType));
			} else {
				uncorrectedList.add(charTypeId);
			}
		}

	}

	public void invoke() {
		// Initialize Hard parameter
		ToDoCaseCharacteristics todoChars = toDoCase.getCharacteristics();
		if (!isNull(todoChars)) {
			for (CaseCharacteristic caseChar : todoChars) {

				ToDoCaseCharacteristicsList.add(caseChar.getId()
						.getCharacteristicTypeId());
			}

			if (!(ToDoCaseCharacteristicsList.containsAll(correctedList) || ToDoCaseCharacteristicsList
					.containsAll(uncorrectedList))) {

				// add error of characteristic from at least one of above groups
				// should present and send the both lists to error message
				addError(CustomMessageRepository.NI0007_5_invalidCaseCharacteristic(paramCorrectedException,paramUncorrectedException));
			}
		} else {
			addError(CustomMessageRepository.NI0007_5_invalidCaseCharacteristic(paramCorrectedException, paramUncorrectedException));
		}

	}

	public void setCase(ToDoCase toDoCase) {
		this.toDoCase = toDoCase;
	}

	public void setOriginalCaseStatus(CaseStatus arg0) {

	}
	
	//Start Add - 2016-01-22 - MPang - Updated for CCB v2.4 compilation
	@Override
	public String getNextCaseStatus() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getNextTransCondition() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Bool getShouldAutoTransition() {
		// TODO Auto-generated method stub
		return null;
	}
	
	//End Add - 2016-01-22 - MPang - Updated for CCB v2.4 compilation

}
