/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Premise Appliances Control Lookup
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *
 * 2013-03-22   NSiopo      NI0009.3. Initial Version.
 **************************************************************************/



package com.splwg.cm.api.lookup;

/**
 * @author rsiopongco
 *
 @LookupFieldname (value = XPAC_OPT_TYP_FLG)
 */
public class CmPremiseAppliancesControlsLookup_Impl extends
        CmPremiseAppliancesControlsLookup_Gen {

}
