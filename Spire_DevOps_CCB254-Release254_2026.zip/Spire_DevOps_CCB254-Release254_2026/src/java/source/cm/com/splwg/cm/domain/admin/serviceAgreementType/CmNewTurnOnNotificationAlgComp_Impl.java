/*
 **************************************************************************
 *                Confidentiality Information:
 *
 * This module is the confidential and proprietary information of
 * Oracle Corporation; it is not to be copied, reproduced, or
 * transmitted in any form, by any means, in whole or in part,
 * nor is it to be used for any purpose other than that for which
 * it is expressly provided without the written permission of
 * Oracle Corporation.
 *
 *
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * MGE-CCB004.005 (CR3135978) - New Turn On Notification
 * 
 * This algorithm will create a change log record to 
 * notify DebtNext of new turn on.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2014-03-03	MCRUZ			MGE-CCB004.005 (CR3135978) Initial Version
 * 2016-01-26   MPang		  	Updated for CCB v2.4 compilation.
 **************************************************************************/

package com.splwg.cm.domain.admin.serviceAgreementType;

import java.math.BigInteger;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControl;
import com.splwg.base.domain.database.table.Table_Id;
import com.splwg.ccb.api.lookup.ReferralStatusLookup;
//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.serviceAgreementType.SaTypeSaActivationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;*/
import  com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saActivation.SaTypeSaActivationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.domain.common.customBusinessComponent.ChangeLogTable;
import com.splwg.cm.domain.common.customBusinessComponent.ChangeLogTable_DTO;
import com.splwg.cm.domain.common.customBusinessComponent.ChangeLogTable_Id;

/**
 * @author mcruz
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = batchControl, name = newTurnOnExtractBatch, required = true, type = entity)})
 */
public class CmNewTurnOnNotificationAlgComp_Impl 
		extends CmNewTurnOnNotificationAlgComp_Gen 
		implements SaTypeSaActivationAlgorithmSpot {
	
	// Hard/Soft Parameters
	private BatchControl parmNewTurnOnBatch;
	private ServiceAgreement parmSa;
	
	// Constants
	private static final String SA_TABLE = "CI_SA";
	private static final String SA_CHANGE_TYPE = "I";
	
	public void setServiceAgreement(ServiceAgreement sa) {
		parmSa = sa;
	}

	public void invoke() {
	
		// Retrieve the soft parameter.
		parmNewTurnOnBatch = getNewTurnOnExtractBatch();
		
		// Get the active Collection Agency Referrals linked to the SA Account.
		List collectionReferrals = getActiveCollectionReferrals(parmSa.getAccount());
		
		if(notNull(collectionReferrals) && !collectionReferrals.isEmpty()) {
			
			// Generate Change Log ID.
			ChangeLogTable_Id changeLogId = null;
			Bool isUniqueId = Bool.FALSE;
			
			while(isUniqueId.isFalse()) {
				
				BigInteger genId = generateChangeLogId();
				
				if(isUniqueChangeLogId(genId).isTrue()) {
					changeLogId = new ChangeLogTable_Id(genId);
					isUniqueId = Bool.TRUE;
					break;
				}
			}
			
			// Create a Change Log record.
			Table_Id saTableId = new Table_Id(SA_TABLE);
			
			ChangeLogTable_DTO changeLogDto = (ChangeLogTable_DTO)this.createDTO(ChangeLogTable.class);
			changeLogDto.setId(changeLogId);
			changeLogDto.setBatchControlId(parmNewTurnOnBatch.getId());
			changeLogDto.setBatchNumber(parmNewTurnOnBatch.getNextBatchNumber());
			changeLogDto.setChangeDateTime(getProcessDateTime());
			changeLogDto.setChangeType(SA_CHANGE_TYPE);
			changeLogDto.setTableId(saTableId);
			changeLogDto.setPkVal1(parmSa.getId().getIdValue());
			changeLogDto.newEntity();
			
		}
	}
	
	/**
	 * This mehod retrieves the active collection referrals from the account.
	 * @param Account_Id
	 * @return List
	 */
	private List getActiveCollectionReferrals(Account account) {
					
		List collectionReferrals = null;
		
		PreparedStatement getCollectionReferrals = createPreparedStatement("SELECT " +
				"	COLL_AGY_REF_ID " +
				"FROM " +
				"	CI_COLL_AGY_REF " +
				"WHERE " +
				"	ACCT_ID = :account " +
				//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
				//"	AND REF_STATUS_FLG IN (:status)");
				"	AND REF_STATUS_FLG IN (:status)", getClass().getName());
				//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		
		getCollectionReferrals.bindEntity("account", account);
		getCollectionReferrals.bindLookup("status", ReferralStatusLookup.constants.ACTIVE);
		
		collectionReferrals = getCollectionReferrals.list();

		getCollectionReferrals.close();
		
		return collectionReferrals;
	}
	
	/**
	 * This method returns a randomly generated key.
	 * @return BigInteger
	 */
	private BigInteger generateChangeLogId() {
		
		PreparedStatement createId = createPreparedStatement("SELECT " +
				"	(TO_NUMBER(ROUND(DBMS_RANDOM.VALUE(1,99999999999999),0))) AS CHG_LOG_ID " +
				" FROM " +
				//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
				//"	DUAL ");
				"	DUAL ", getClass().getName());
				//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		
		createId.execute();
		
		SQLResultRow row = createId.firstRow();
		BigInteger intId = row.getInteger("CHG_LOG_ID");

		createId.close();
		
		return intId;
	}
	
	/**
	 * This method checks if the generated key is unique to the Change Log table.
	 * @param BigInteger
	 * @return Bool
	 */
	private Bool isUniqueChangeLogId(BigInteger changeLogId) {
		
		Bool isUnique = Bool.FALSE;
		
		PreparedStatement checkId = createPreparedStatement("SELECT " +
				"	CHG_LOG_ID " +
				" FROM " +
				"	CI_CHG_LOG " +
				" WHERE " +
				//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
				//"	CHG_LOG_ID = :changeLogId");
				"	CHG_LOG_ID = :changeLogId", getClass().getName());
				//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
		
		checkId.bindId("changeLogId", new ChangeLogTable_Id(changeLogId));
		
		List checkIdList = checkId.list();
		
		if(notNull(checkIdList) || !checkIdList.isEmpty()) {
			isUnique = Bool.TRUE;
		}

		checkId.close();
		
		return isUnique;
	}

}
