/*
 *********************************************************************** 
 *                 Confidentiality Information: 
 *                                                                                     
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION: 
 * 
 * This algorithm would perform the following if a bill segment is
 * being cancelled:
 * 
 * 1.) Search for spire credit adjustment created by this bill 
 * 2.) Cancel the spire credit adjustment when found.
 * 
 *********************************************************************** 
 * 
 *
 * CHANGE HISTORY: 
 * 
 * Date:       by:          Reason:
 * YYYY-MM-DD  FLName
 * 2018-09-18  JHERNA		SysAid#245408 Initial Version.
 * 
 ***********************************************************************
 */
package com.splwg.cm.domain.admin.customerClass.algorithm.billSegment;

import java.util.Iterator;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.admin.adjustmentCancelReason.entity.AdjustmentCancelReason;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType_Id;
import com.splwg.ccb.domain.admin.customerClass.algorithm.billSegment.CustomerClassBillSegmentFreezeOrCancelAlgorithmSpot;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.cm.api.lookup.CmLowIncomeProgramConfigurationsOptionTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;

/**
 * @author 90622
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = featureConfiguration, name = featConfigLIP, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = charTypeBillId, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentCancelReason, name = adjustmentCancelReason, required = true, type = entity)})
 */
public class CmCancelSpireCreditForBudgetAlgComp_Impl 
		extends CmCancelSpireCreditForBudgetAlgComp_Gen 
		implements CustomerClassBillSegmentFreezeOrCancelAlgorithmSpot {

	/*Soft Parameter*/
	private FeatureConfiguration parmFeatConfLIP;
	private CharacteristicType parmCharTypeBillID;	
	private AdjustmentCancelReason parmAdjustmentCancelReason;
	
	/*Hard Parameter*/
	@SuppressWarnings("unused")
	private Date hpAccountingDate;
	private BillSegment hpBillSegment;		
	
	/*Work Variables*/
	private AdjustmentType_Id wAdjTypeIDSpireCredit;
	
	@Override
	public void setAccountingDate(Date arg0) {
		hpAccountingDate = arg0;
	}

	@Override
	public void setBillSegment(BillSegment arg0) {
		hpBillSegment = arg0;
	}
		
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
	
		// Retrieve Parameter 10: Feature Configuration Low Income Program Configuration
		parmFeatConfLIP = this.getFeatConfigLIP();
		// Retrieve Parameter 20: Characteristic Type for Bill ID
		parmCharTypeBillID = this.getCharTypeBillId();
		// Retrieve Parameter 30: Adjustment Cancel Reason
		parmAdjustmentCancelReason = this.getAdjustmentCancelReason();
		// Retrieve Spire Credit Adjustment Type from the feature configuration
		CmMGEFeatureConfigurationOptionsRetriever fcHelper = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
		wAdjTypeIDSpireCredit = fcHelper.getAdjustmentTypeFeatureOptionValue(parmFeatConfLIP.getId(),
				CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.SPIRE_CREDIT_ADJUSTMENT_TYPE,
				Bool.TRUE,
				Bool.FALSE);
	}

	@Override
	public void invoke() {

		// Proceed only if the bill segment is being cancelled
		if (hpBillSegment.getBillSegmentStatus().isCanceled()) {
			
			Iterator<SQLResultRow> iterSpireCred = cmRetrieveSpireCredits(hpBillSegment);
			while (iterSpireCred.hasNext()) {
				SQLResultRow sqlRow = iterSpireCred.next();
				Adjustment_Id spireCreditAdjID = (Adjustment_Id) sqlRow.getId("ADJ_ID", Adjustment.class); 
				Adjustment spireCredit = spireCreditAdjID.getEntity();
				spireCredit.cancel(parmAdjustmentCancelReason);
			}
		}
	}
	
	private Iterator<SQLResultRow> cmRetrieveSpireCredits(BillSegment bseg) {
		
		Iterator<SQLResultRow> returnValue;
		
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT "); 
		stringBuilder.append("  UNIQUE(ADJ.ADJ_ID) ADJ_ID ");
		stringBuilder.append("FROM "); 
		stringBuilder.append("  CI_ADJ ADJ, ");
		stringBuilder.append("  CI_ADJ_CHAR AC ");
		stringBuilder.append("WHERE "); 
		stringBuilder.append("  ADJ.SA_ID = :saID ");
		stringBuilder.append("  AND ADJ.ADJ_TYPE_CD = :adjType ");
		stringBuilder.append("  AND AC.ADJ_ID = ADJ.ADJ_ID ");
		stringBuilder.append("  AND AC.CHAR_TYPE_CD = :charTypeBillId ");
		stringBuilder.append("  AND AC.SRCH_CHAR_VAL = '"+bseg.getBillId().getTrimmedValue()+"' ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==cmRetrieveSpireCredits==");
		prepState.bindId("saID", bseg.getServiceAgreement().getId());
		prepState.bindId("adjType", wAdjTypeIDSpireCredit);
		prepState.bindId("charTypeBillId", parmCharTypeBillID.getId());
		prepState.execute();
		prepState.setAutoclose(false);
		returnValue = prepState.list().iterator();
		prepState.close();
		return returnValue;		
	}

}
