/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This batch program will process input file containing CC log updates
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-03-22   Jagadeesh        NI0011.4 Initial Version.
 * 2016-01-27	MPang	 		 Updated for CCB v2.4 compilation.
 * 2018-03-09	DarrylH			SA:235884 Altered Java variables and soft parameter
 * 								intialization. Static variable did not work well
 * 								in AE (uc4 schedule)
 **************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicTypeValues;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
//Start Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
/*import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactLog_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact_Id;*/

import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactLog_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_Id;
//End Change - 2016-01-22 - MPang - Updated for CCB v2.4 compilation.
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author
 *
 @BatchJob ( modules = {}
 *              , multiThreaded = false
 *              , rerunnable = true
 *              , softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CC_CALLDT_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CC_STATUS_CHAR_TYPE, required = true, type = entity)
 *           } )
 */

public class CmCallResultsUpd_BatchProcess extends CmCallResultsUpd_BatchProcess_Gen {
	// START CHANGE-DarrylH -2018-03-09 SA-235884
	/*private static String parmFilePath;
	private static String parmFileName;
	private static File inputFile = null;
	private static CharacteristicType parmCCCallDateCharType;
	private static CharacteristicType parmCCStatusCharType;
	*/
	private  String parmFilePath;
	private  String parmFileName;
	private  File inputFile = null;
	private  CharacteristicType parmCCCallDateCharType;
	private  CharacteristicType parmCCStatusCharType;
	// END CHANGE-DarrylH -2018-03-09 SA-235884

	public JobWork getJobWork() {
		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit workUnit = new ThreadWorkUnit();
		workUnits.add(workUnit);
		return createJobWorkForThreadWorkUnitList(workUnits);
	}

	public void validateSoftParameters(boolean isNewRun){

		parmFilePath = getParameters().getFILE_PATH().trim();
		parmFileName = getParameters().getFILE_NAME().trim();
		parmCCCallDateCharType = getParameters().getCC_CALLDT_CHAR_TYPE();
		parmCCStatusCharType = getParameters().getCC_STATUS_CHAR_TYPE();

		File folder = new File(parmFilePath);
		if(!folder.exists()){
			addError(CustomMessageRepository.ni0011_4_InvalidFilePath(parmFilePath));
		}

		inputFile = new File(parmFilePath, parmFileName);
		if(!inputFile.exists() || !inputFile.canRead()){
			addError(CustomMessageRepository.ni0011_4_InvalidFileName(parmFileName));
		}

		CharacteristicEntity charEntity = new CharacteristicEntity_Id(parmCCCallDateCharType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT).getEntity();
		if (isNull(charEntity)) {
			addError(CustomMessageRepository.ni0011_4_InvalidCCCharType(parmCCCallDateCharType.getId().getTrimmedValue()));
		}
		charEntity = new CharacteristicEntity_Id(parmCCStatusCharType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT).getEntity();
		if (isNull(charEntity)) {
			addError(CustomMessageRepository.ni0011_4_InvalidCCCharType(parmCCStatusCharType.getId().getTrimmedValue()));
		}

	}

	public Class<CmCallResultsUpd_BatchProcessWorker> getThreadWorkerClass() {
		return CmCallResultsUpd_BatchProcessWorker.class;
	}

	public static class CmCallResultsUpd_BatchProcessWorker extends
	CmCallResultsUpd_BatchProcessWorker_Gen {
		// START ADD-DarrylH -2018-03-09 SA-235884
		private  String parmFilePath = null;
		private  String parmFileName = null;
		private  File inputFile = null;
		private  CharacteristicType parmCCCallDateCharType = null;
		private  CharacteristicType parmCCStatusCharType = null;
		// END ADD-DarrylH -2018-03-09 SA-235884
		private static final int CC_ID_START = 0;
		private static final int CC_ID_END = 10;
		private static final int ACCT_ID_BEGIN = 11;
		private static final int ACCT_ID_END = 21;
		private static final int COMMENT_BEGIN = 22;

		private BufferedReader inputBufferReader = null;
		private int totalRecProcessed = 0;
		private int totalRecError = 0;

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		public void initializeThreadWork(boolean initializationPreviouslySuccessful)
		throws ThreadAbortedException, RunAbortedException {
			// START ADD-DarrylH -2018-03-09 SA-235884
			parmFilePath = getParameters().getFILE_PATH().trim();
			parmFileName = getParameters().getFILE_NAME().trim();
			parmCCCallDateCharType = getParameters().getCC_CALLDT_CHAR_TYPE();
			parmCCStatusCharType = getParameters().getCC_STATUS_CHAR_TYPE();

			inputFile = new File(parmFilePath, parmFileName);
			// END ADD-DarrylH -2018-03-09 SA-235884

			openFile();

		}

		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
		throws ThreadAbortedException, RunAbortedException {

			CustomerContact_Id ccId = null;
			Account_Id acctId = null;
			String comment = " ";
			String fileRecord = null;
			BigInteger lineNumber = BigInteger.ZERO;

			while(!isBlankOrNull(fileRecord = readRecord())){
				lineNumber = lineNumber.add(BigInteger.ONE);

				ccId = new CustomerContact_Id(fileRecord.substring(CC_ID_START, CC_ID_END));
				CustomerContact cc = ccId.getEntity();
				acctId = new Account_Id(fileRecord.substring(ACCT_ID_BEGIN,ACCT_ID_END));
				comment = fileRecord.substring(COMMENT_BEGIN).trim();
				if(isBlankOrNull(comment)){
					comment = " ";	// Comment if null, should be saved as blank.
				}

				if(notNull(cc) && notNull(acctId.getEntity())){
					if (isNull(cc.getEffectiveCharacteristic(parmCCStatusCharType)) && notNull(cc.getEffectiveCharacteristic(parmCCCallDateCharType))) {

						// re-initialize to avoid lazy initialization. NPE will be thrown if this is not performed.
		                CharacteristicTypeValues charTypeValues = parmCCStatusCharType.getId().getEntity().getValues();
						String ccStatusCharValue = charTypeValues.iterator().next().getId().getCharacteristicValue();

						//Adding a new Customer Contact Status Characteristic entry
						CustomerContactCharacteristic_DTO ccStatusCharDTO = cc.getCharacteristics().newChildDTO();
						if(parmCCStatusCharType.getCharacteristicType().isPredefinedValue()){
							ccStatusCharDTO.setCharacteristicValue(ccStatusCharValue);
						} else if (parmCCStatusCharType.getCharacteristicType().isForeignKeyValue()){
							ccStatusCharDTO.setCharacteristicValueForeignKey1(ccStatusCharValue);
						} else if(parmCCStatusCharType.getCharacteristicType().isAdhocValue()
								|| parmCCStatusCharType.getCharacteristicType().isFileLocationValue()){
							ccStatusCharDTO.setAdhocCharacteristicValue(ccStatusCharValue);
						}
						cc.getCharacteristics().add(ccStatusCharDTO, parmCCStatusCharType.getId());

						//Updating the existing Customer Contact Call Date Characteristic entry
						CustomerContactCharacteristic ccCallDateChar = cc.getEffectiveCharacteristic(parmCCCallDateCharType);
						String businessDate = getProcessDateTime().getDate().toString();
						CustomerContactCharacteristic_DTO ccCallDateCharDTO = ccCallDateChar.getDTO();

						if(parmCCCallDateCharType.getCharacteristicType().isPredefinedValue()){
							ccCallDateCharDTO.setCharacteristicValue(businessDate);
							} else if (parmCCCallDateCharType.getCharacteristicType().isForeignKeyValue()){
								ccCallDateCharDTO.setCharacteristicValueForeignKey1(businessDate);
							} else if(parmCCCallDateCharType.getCharacteristicType().isAdhocValue()
									|| parmCCCallDateCharType.getCharacteristicType().isFileLocationValue()){
								ccCallDateCharDTO.setAdhocCharacteristicValue(businessDate);
							}
						ccCallDateChar.setDTO(ccCallDateCharDTO);

						CustomerContactLog_DTO ccLogDTO = cc.getLogs().newChildDTO();
						ccLogDTO.setCustomerContactId(ccId);
						ccLogDTO.setLogEntry(comment);
						ccLogDTO.setCreationDateTime(getProcessDateTime());
						ccLogDTO.setUserId(getActiveContextUser().getId());
						ccLogDTO.newEntity();
						totalRecProcessed++;
					}
				}else {
					logMessage(CustomMessageRepository.ni0011_4_InvalidCCIdAcctId(ccId.getTrimmedValue(), acctId.getTrimmedValue()
							,lineNumber.toString()), MessageSeverityLookup.constants.ERROR);
					totalRecError++;
					continue;
				}
			}

			WorkUnitResult workUnitResult = new WorkUnitResult(true);
			workUnitResult.setUnitsProcessed(totalRecProcessed);
			workUnitResult.setUnitsInError(totalRecError);

			return workUnitResult;
		}

		private void openFile() {
			try {
				inputBufferReader = new BufferedReader(new FileReader(inputFile));
			} catch (IOException e) {
				throw new RunAbortedException(CustomMessageRepository.ni0011_4_ErrorInFile(e.getMessage().trim()));
			}
		}

		private String readRecord() {
			String record = null;
			try {
				record =  inputBufferReader.readLine();
			} catch (IOException exception) {
				throw new RunAbortedException(CustomMessageRepository.ni0011_4_ErrorInFile(exception.getMessage().trim()));
			}
			return record;
		}

		public void finalizeThreadWork()
		throws ThreadAbortedException, RunAbortedException {
			try {
				if(notNull(inputBufferReader)){
					inputBufferReader.close();
				}
			} catch (IOException exception) {
				throw new RunAbortedException(CustomMessageRepository.ni0011_4_ErrorInFile(exception.getMessage().trim()));
			}
		}
	}

}
