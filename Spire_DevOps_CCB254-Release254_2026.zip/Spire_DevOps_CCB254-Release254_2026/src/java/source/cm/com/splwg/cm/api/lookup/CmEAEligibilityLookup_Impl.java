/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * EA Eligibility Lookup
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 * 
 * 2013-04-24   RDizon      NI0026.1 Initial Version.  
 * *************************************************************************                
 */

package com.splwg.cm.api.lookup;

/**
 * @author redizon
 *
 @LookupFieldname (value = XEAE_OPT_TYP_FLG)
 */
public class CmEAEligibilityLookup_Impl extends CmEAEligibilityLookup_Gen {

}
