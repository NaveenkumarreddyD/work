/**************************************************************************
* Program Name: CmAutopayActionFlagLookup_Impl
* Program Title: CmAutopayActionFlagLookup_Impl
* Author: Gerard Cinco
* Creation Date: 2017-01-23
* Purpose: Lookup for Autopay Maintenance Actions
*  
* Functional Spec: CCB-CC-015
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:         Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  CCB-CC-015        Gerard Cinco    2017-01-30    Initial Version
 ************************************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author gcicno
 *
 @LookupFieldname (value = CM_AUTOPAY_ACT_FLG)
 */
public class CmAutopayActionFlagLookup_Impl	extends CmAutopayActionFlagLookup_Gen {

}

