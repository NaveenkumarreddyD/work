/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * CACI Payment Upload Batch 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-03-25   MLekkala NI0040.4. Initial Version.
 * 2015-08-17	JHERNA	3283928. updated code to not use static global 
 *                      variables. 
 * 2016-01-27	MPang	Updated for CCB v2.4 compilation.
 * 2018-07-25   SFelip  CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                      longer needed.        
 * 2021-09-27	JMeden	Defect 4598924. Update Handling of Suspense Payment    
 **************************************************************************/

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.DepositControlStagingStatusLookup;
import com.splwg.ccb.api.lookup.PaymentTenderStagingStatusLookup;
import com.splwg.ccb.api.lookup.TenderControlStatusLookup;
//Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.matchType.MatchType;
import com.splwg.ccb.domain.admin.tenderSource.TenderSource;
import com.splwg.ccb.domain.admin.tenderSource.TenderSource_Id;
import com.splwg.ccb.domain.admin.tenderType.TenderType_Id;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;
import com.splwg.ccb.domain.payment.depositControlStaging.DepositControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.DepositControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.DepositControlStaging_Id;
import com.splwg.ccb.domain.payment.depositControlStaging.TenderControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.TenderControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.TenderControlStaging_Id;
import com.splwg.ccb.domain.payment.paymentTenderUpload.PaymentTenderUpload;
import com.splwg.ccb.domain.payment.paymentTenderUpload.PaymentTenderUpload_DTO;
import com.splwg.ccb.domain.payment.paymentTenderUpload.PaymentTenderUpload_Id;
import com.splwg.ccb.domain.payment.paymentTenderUpload.PaymentUpload;
import com.splwg.ccb.domain.payment.paymentTenderUpload.PaymentUpload_DTO;
import com.splwg.ccb.domain.payment.paymentTenderUpload.PaymentUpload_Id;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;*/

import com.splwg.ccb.domain.admin.matchType.entity.MatchType;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource;
import com.splwg.ccb.domain.admin.tenderSource.entity.TenderSource_Id;
import com.splwg.ccb.domain.admin.tenderType.entity.TenderType_Id;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.DepositControlStaging_Id;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging_DTO;
import com.splwg.ccb.domain.payment.depositControlStaging.entity.TenderControlStaging_Id;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentTenderUpload;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentTenderUpload_DTO;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentTenderUpload_Id;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentUpload;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentUpload_DTO;
import com.splwg.ccb.domain.payment.paymentTenderUpload.entity.PaymentUpload_Id;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
//End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author mlekkala001
 *
 @BatchJob (multiThreaded = false, rerunnable = true,
 *     modules={},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = matchType, name = MATCH_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = PAYMENT_SOURCE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = BATCH_TYPE, required = true, type = integer)
 *            , @BatchJobSoftParameter (name = COMPANY_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = PAYMENTS_FEAT_CONFIG, required = true, type = entity)})
 */

public class CmCaciPaymentsUpload_BatchProcess
extends CmCaciPaymentsUpload_BatchProcess_Gen {

	// START DELETE - JHERNA - 2015-08-17 - 3283928
	/*
	// Soft Parameters	
	private static String parmFilePath;
	private static String parmFileName;
	private static MatchType parmMatchType;
	private static BigInteger parmMaxErrors;
	private static String parmPaymentSource;
	private static BigInteger parmBatchType;
	private static String parmCompanyName;
	private static FeatureConfiguration parmPaymentsFeatureConfig;
	*/	
	// END DELETE - JHERNA - 2015-08-17 - 3283928
	
	public JobWork getJobWork() {
		ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
		arrayList.add(threadWorkUnit);
		return createJobWorkForThreadWorkUnitList(arrayList);
	}

	public void validateSoftParameters(boolean arg0){

		// START CHANGES - JHERNA - 2015-08-17 - 3283928
		/*
		// Get File Parameter Related and Validate them
		parmFilePath = getParameters().getFILE_PATH().trim();

		// Validate whether the file path exists or not
		File folder = new File(parmFilePath);
		if(!(folder.exists() && folder.isDirectory())) {
			addError(CustomMessageRepository.ni0040_4FilePathInvalid(parmFilePath));
		}

		parmFileName = getParameters().getFILE_NAME().trim();

		File inputFile = new File(parmFilePath, parmFileName);
		if(!inputFile.exists() || !inputFile.canRead()){
			addError(CustomMessageRepository.ni0040_4InvalidFileName(parmFileName)); 
		} 

		parmMaxErrors = getParameters().getSoftMaxErrors();

		// Validates Max Error soft parameter
		if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
			addError(CustomMessageRepository.ni0040_4MaxErrorCannotBeLessThanZero(parmMaxErrors.toString().trim())); 
		} 

		parmPaymentsFeatureConfig = getParameters().getPAYMENTS_FEAT_CONFIG();

		parmCompanyName = getParameters().getCOMPANY_NAME();

		parmBatchType = getParameters().getBATCH_TYPE();

		parmMatchType = getParameters().getMATCH_TYPE_CD();

		parmPaymentSource = getParameters().getPAYMENT_SOURCE();
		*/
		// Get File Parameter Related and Validate them
		String parmFilePath = getParameters().getFILE_PATH().trim();

		// Validate whether the file path exists or not
		File folder = new File(parmFilePath);
		if(!(folder.exists() && folder.isDirectory())) {
			addError(CustomMessageRepository.ni0040_4FilePathInvalid(parmFilePath));
		}

		String parmFileName = getParameters().getFILE_NAME().trim();

		File inputFile = new File(parmFilePath, parmFileName);
		if(!inputFile.exists() || !inputFile.canRead()){
			addError(CustomMessageRepository.ni0040_4InvalidFileName(parmFileName)); 
		} 

		BigInteger parmMaxErrors = getParameters().getSoftMaxErrors();

		// Validates Max Error soft parameter
		if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
			addError(CustomMessageRepository.ni0040_4MaxErrorCannotBeLessThanZero(parmMaxErrors.toString().trim())); 
		} 
		// END CHANGES - JHERNA - 2015-08-17 - 3283928
	}

	public Class<CmCaciPaymentsUpload_BatchProcessWorker> getThreadWorkerClass() {
		return CmCaciPaymentsUpload_BatchProcessWorker.class;
	}

	public static class CmCaciPaymentsUpload_BatchProcessWorker
	extends CmCaciPaymentsUpload_BatchProcessWorker_Gen {

		// Thread Class Variables
		private BigInteger lineCounter = BigInteger.ZERO;
		private BufferedReader inputFile = null;
		private File inputFilePathAndName = null;
		private String fileDateStr = null;
		private String paymentSourceStr = null;
		private DateTime fileDateTime = null;
		private String headerBatchNumber = null;
		private String batchTypeStr = null;
		private BigInteger batchType = BigInteger.ZERO;
		private BigDecimal batchTotalDepositAmount = BigDecimal.ZERO;
		private BigInteger batchCount = BigInteger.ZERO;
		private int processedDetailedRecordsCount = 0;
		private TenderSource tenderSource;
		private TenderSource_Id tenderSourceCd;
		private String referralIdStr = null;
		private String premiseIdStr = null;
		private String customerIdStr = null;
		private int batchTrailerRecordCount;
		private int totalBatchCount = 0;
		private int fileTrailerBatchCount;
		private int totalFileRecordCount = 0;
		private int fileTrailerRecordCount;
		private BigDecimal calculatedFileTotalDepositAmt = BigDecimal.ZERO;
		private BigDecimal calculatedBatchTotalPaymentAmount = BigDecimal.ZERO;	
		private BigInteger numberOfRecordsInError = BigInteger.ZERO;
		private int totalBatchHeaderRecords = 0;
		private int totalBatchTrailerRecords = 0;
		private int totalFileHeaderRecords = 0;
		private int totalFileTrailerRecords = 0;

		// CONSTANT NAMES
		private static final int RECORD_TYPE_INDEX = 0;
		private static final int RECORD_TYPE_LENGTH = 1;
		private static final String SAVE_POINT = "40_4_SAVE_POINT";

		private static final String CONST_RECORD_TYPE = "RECORD TYPE";
		private static final String CONST_PAYMENT_SOURCE = "PAYMENT SOURCE";
		private static final String CONST_COMPANY_NAME = "COMPANY NAME";
		private static final String CONST_FILE_DATE = "FILE DATE";
		private static final String CONST_TRAILER_DATE = "TRAILER DATE";
		private static final String CONST_BATCH_NUM = "BATCH NUMBER";
		private static final String CONST_BATCH_TYPE = "BATCH TYPE";
		private static final String CONST_AMOUNT_PAID = "AMOUNT PAID";
		private static final String CONST_PAY_TYPE = "PAYMENT TYPE";
		private static final String CONST_EXT_PAY_ID = "EXTERNAL PAYMENT ID";
		private static final String CONST_BATCH_ITEM_COUNT = "BATCH ITEM COUNT";
		private static final String CONST_DEP_AMT = "BATCH DEPOSIT AMOUNT";
		private static final String CONST_BATCH_COUNT = "BATCH COUNT";
		private static final String CONST_FILE_DEP_AMT = "TOTAL DEPOSIT AMOUNT";
		private static final String CONST_REFERRAL_ID = "REFERRAL ID";
		private static final String CONST_PREMISE_ID = "PREMISE ID";	
		private static final String CONST_CHECK_NUMBER = "CHECK NUMBER";
		private static final String CONST_SPACE = " ";

		//FILE HEADER 
		private static final String DATETIME_FORMAT_MMDDYYYYHHMMSS = "yyyy-MM-dd HH:mm:ss";
		private static final String FILE_HEADER_RECORD_TYPE = "A";
		private static final int COMPANY_NAME_INDEX = 2-1;
		private static final int COMPANY_NAME_LENGTH = 11;
		private static final int PAYMENT_SOURCE_INDEX = 17-1;
		private static final int PAYMENT_SOURCE_LENGTH = 17;
		private static final int FILE_DATE_INDEX = 35-1;
		// As we need to consider only upto seconds , we are using the length 19 for file Date
		private static final int FILE_DATE_LENGTH = 19;


		//BATCH HEADER
		private static final String BATCH_HEADER_RECORD_TYPE = "B";
		private static final int BATCH_NUMBER_INDEX = 2-1;
		private static final int BATCH_NUMBER_LENGTH = 5;
		private static final int BATCH_TYPE_INDEX = 7-1;
		private static final int BATCH_TYPE_LENGTH = 1;

		//DETAIL RECORD
		private static final String DETAILS_RECORD_TYPE = "C";
		private static final int PREMISE_ID_INDEX = 26-1;
		private static final int PREMISE_ID_LENGTH = 10;
		private static final int REFERRAL_ID_INDEX = 16-1;
		private static final int REFERRAL_ID_LENGTH = 10;
		private static final int AMOUNT_PAID_INDEX = 36-1; 
		private static final int AMOUNT_PAID_LENGTH = 9;
		private static final int EXT_REF_ID_INDEX = 61-1;
		private static final int EXT_REF_ID_LENGTH = 30;
		private static final int PAY_TYPE_CODE_INDEX = 46-1;
		private static final int PAY_TYPE_CODE_LENGTH = 1;
		private static final int CHECK_NUMBER_INDEX = 51-1;
		private static final int CHECK_NUMBER_LENGTH = 10;
		//Start Add - JMeden - Defect 4598924 - 2021-09-27
		private static final int ACCOUNT_ID_INDEX = 6-1;
		private static final int ACCOUNT_ID_LENGTH = 10;
		
		private static final String DFLT_COL_REF_AGENCY_ID = "0000000000";
		private static final String DFLT_PREM_ID = "0000000000";
		//End Add - JMeden - Defect 4598924 - 2021-09-27
		

		//BATCH TRAILER
		private static final String BATCH_TRAILER_RECORD_TYPE = "D";
		private static final int BATCH_ITEM_COUNT_INDEX = 7-1;
		private static final int BATCH_ITEM_COUNT_LENGTH = 3;
		private static final int BATCH_DEPOSIT_AMT_INDEX = 10-1;
		private static final int BATCH_DEPOSIT_AMT_LENGTH = 14;

		//FILE TRAILER
		private static final String FILE_TRAILER_RECORD_TYPE = "E";
		private static final int TRAILER_DATE_INDEX = 2 -1;
		// As we need to consider only upto seconds , 
		// we are using the length 19 for Trailer Date
		private static final int TRAILER_DATE_LENGTH = 19;
		private static final int TOTAL_FILE_COUNT_INDEX = 28-1;
		private static final int TOTAL_FILE_COUNT_LENGTH = 4;
		private static final int TOTAL_ITEM_COUNT_INDEX = 32-1;
		private static final int TOTAL_ITEM_COUNT_LENGTH = 5;
		private static final int TOTAL_DEPOSIT_AMT_INDEX = 37-1;
		private static final int TOTAL_DEPOSIT_AMT_LENGTH = 14;


		//Switches to check the order of processing is right
		private Bool isFileHeaderRead = Bool.FALSE;
		private Bool isBatchHeaderRead = Bool.FALSE;
		private Bool isBatchTrailerRead = Bool.FALSE;
		private Bool isFileTrailerRead = Bool.FALSE;
		private Bool isDetailRecordRead = Bool.FALSE;

		// Working Variables
		private DepositControlStaging depositControlStaging;
		private TenderControlStaging tenderControlStaging;
		private Boolean isSuspensePayment = false;
		private CollectionAgencyReferral_Id colReferralAgencyId;
		private CollectionAgencyReferral colReferralAgency;
		private Account account;
		private Premise_Id premiseId;
		private String extRefId;
		private TenderType_Id tenderTypeId;
		private Money tenderAmount;
		private String payTypeCode;
		private String mappedPayTypeCode;
		private String checkNumber;
		private String amountPaidStr; 
		private PaymentTenderUpload paymentTenderUpload;
		private BigDecimal amountPaid = BigDecimal.ZERO;	

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}
		
		// START ADD - JHERNA - 2015-08-17 - 3283928			
		// Soft Parameters	
		private String parmFilePath;
		private String parmFileName;
		private MatchType parmMatchType;
		private BigInteger parmMaxErrors;
		private String parmPaymentSource;
		private BigInteger parmBatchType;
		private String parmCompanyName;
		private FeatureConfiguration parmPaymentsFeatureConfig;
		//Start Add - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
		private static FrameworkSession session;
		//End Add - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
		
		@Override
		public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
		
			Logger logger = LoggerFactory.getLogger(CmCaciPaymentsUpload_BatchProcess.class);
			logger.info("****CACI Upload Retrieve Parameters****");
			// Get File Parameter Related and Validate them
			parmFilePath = getParameters().getFILE_PATH().trim();

			// Validate whether the file path exists or not
			File folder = new File(parmFilePath);
			if(!(folder.exists() && folder.isDirectory())) {
				addError(CustomMessageRepository.ni0040_4FilePathInvalid(parmFilePath));
			}

			parmFileName = getParameters().getFILE_NAME().trim();

			File inputFile = new File(parmFilePath, parmFileName);
			if(!inputFile.exists() || !inputFile.canRead()){
				addError(CustomMessageRepository.ni0040_4InvalidFileName(parmFileName)); 
			} 

			parmMaxErrors = getParameters().getSoftMaxErrors();

			// Validates Max Error soft parameter
			if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
				addError(CustomMessageRepository.ni0040_4MaxErrorCannotBeLessThanZero(parmMaxErrors.toString().trim())); 
			} 

			parmPaymentsFeatureConfig = getParameters().getPAYMENTS_FEAT_CONFIG();

			parmCompanyName = getParameters().getCOMPANY_NAME();

			parmBatchType = getParameters().getBATCH_TYPE();

			parmMatchType = getParameters().getMATCH_TYPE_CD();

			parmPaymentSource = getParameters().getPAYMENT_SOURCE();
			
			logger.info("****File Path="+parmFilePath+"****");
			logger.info("****File Name="+parmFileName+"****");
			logger.info("****Max Errors="+parmMaxErrors+"****");
			logger.info("****Payments FeatConf="+parmPaymentsFeatureConfig+"****");
			logger.info("****Company Name="+parmCompanyName+"****");
			logger.info("****Batch Type="+parmBatchType+"****");
			logger.info("****Payment Source="+parmPaymentSource+"****");
		}
		// END ADD - JHERNA - 2015-08-17 - 3283928

		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
		throws ThreadAbortedException, RunAbortedException {

			processFile();

			// Log Total Number of Records Processed and Total Amount of Payment Processed
			logMessage(CustomMessageRepository.ni0040_4TotalNbrOfPaymentRecordsProcessed(totalFileRecordCount), MessageSeverityLookup.constants.INFORMATIONAL);
			logMessage(CustomMessageRepository.ni0040_4TotalPaymentAmountProcessed(calculatedBatchTotalPaymentAmount), MessageSeverityLookup.constants.INFORMATIONAL);  
			logMessage(CustomMessageRepository.ni0040_4TotalNbrOfPaymentBatchesProcessed(totalBatchCount), MessageSeverityLookup.constants.INFORMATIONAL);  

			// Set Batch Run Totals
			WorkUnitResult workUnitResult = new WorkUnitResult(true);
			workUnitResult.setUnitsProcessed(totalFileRecordCount);
			workUnitResult.setUnitsInError(numberOfRecordsInError.intValue());

			return workUnitResult;
		}

		private void processFile() {
			openFile();

			String fileRecord = null;
			//Start Add - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
			session = (FrameworkSession)SessionHolder.getSession();
			//End Add - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
			//Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
			//setSavepoint(SAVE_POINT);
			session.setSavepoint(SAVE_POINT);
			//End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation

			fileRecord = readFileLine();
			if(fileRecord.length() <= 0) {
				addError(CustomMessageRepository.ni0040_4EmptyFileError());  
			}

			while (notNull(fileRecord)){
				// Increment line counter
				lineCounter = lineCounter.add(BigInteger.ONE);
				try {
					// Process the file record if and only if record length != 0
					if(fileRecord.length()!= 0) { 
						isSuspensePayment = Boolean.FALSE;
						processRecords(fileRecord);
					}	
					// Read the next line						
					fileRecord = readFileLine();

				} catch (ApplicationError ae){
					//Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
					//rollbackToSavepoint(SAVE_POINT);
					session.rollbackToSavepoint(SAVE_POINT);
					//End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
					numberOfRecordsInError  = numberOfRecordsInError.add(BigInteger.ONE);
					throw ae;
				}
			}

			closeFile();
		}

		/**
		 * This Method will process each record present in the Payment Return file.
		 * @param detailRecord
		 */
		private void processRecords(String detailRecord){
			String recordType = getFieldValue(detailRecord,RECORD_TYPE_INDEX,RECORD_TYPE_LENGTH).trim();

			// Check whether Record Type is present in the Record or not. If No Record Type , throw an error
			validateField(recordType, CONST_RECORD_TYPE, RECORD_TYPE_INDEX+1, RECORD_TYPE_INDEX+RECORD_TYPE_LENGTH);

			if(recordType.equalsIgnoreCase(FILE_HEADER_RECORD_TYPE)){
				processFileHeader(detailRecord);

			}else if(recordType.equalsIgnoreCase(BATCH_HEADER_RECORD_TYPE)){
				processBatchHeader(detailRecord);

			}else if(recordType.equalsIgnoreCase(DETAILS_RECORD_TYPE)){
				processDetailsRecord(detailRecord);

			}else if(recordType.equalsIgnoreCase(BATCH_TRAILER_RECORD_TYPE)){
				processBatchTrailer(detailRecord);

			}else if(recordType.equalsIgnoreCase(FILE_TRAILER_RECORD_TYPE)){
				processFileTrailer(detailRecord);

			}
			else{
				addError(CustomMessageRepository.ni0040_4InvalidRecordType(lineCounter.toString(), recordType));
			}
		}


		/**
		 * This Method will process the File Header Record, to fetch and validate the file date.
		 * @param record
		 */
		private void processFileHeader(String record){

			totalFileHeaderRecords = totalFileHeaderRecords + 1;

			if(totalFileHeaderRecords  >1 ){
				addError(CustomMessageRepository.ni0040_4MultipleFileHeaderRecords());  
			}

			if (isBatchHeaderRead.isTrue() || isBatchTrailerRead.isTrue()|| isDetailRecordRead.isTrue()||isFileTrailerRead.isTrue()){
				addError(CustomMessageRepository.ni0040_4InvalidRecordTypeOrder());
			}

			// Get the Company Name Details
			String companyNameStr = getFieldValue(record, COMPANY_NAME_INDEX, COMPANY_NAME_LENGTH).trim();

			validateField(companyNameStr, CONST_COMPANY_NAME, COMPANY_NAME_INDEX+1, COMPANY_NAME_INDEX+COMPANY_NAME_LENGTH);

			if(!companyNameStr.equalsIgnoreCase(parmCompanyName)){
				addError(CustomMessageRepository.ni0040_4InvalidCompanyName(lineCounter.toString(), companyNameStr));
			}

			// If Payment Source on the file header is different than provided as Payment-Source batch parameter,
			// error out entire file.

			paymentSourceStr = getFieldValue(record, PAYMENT_SOURCE_INDEX, PAYMENT_SOURCE_LENGTH).trim();

			validateField(paymentSourceStr, CONST_PAYMENT_SOURCE, PAYMENT_SOURCE_INDEX+1, PAYMENT_SOURCE_INDEX+PAYMENT_SOURCE_LENGTH);

			if(!paymentSourceStr.equalsIgnoreCase(parmPaymentSource)){
				addError(CustomMessageRepository.ni0040_4InvalidPaymentSource(lineCounter.toString(), paymentSourceStr));
			}

			fileDateStr = getFieldValue(record, FILE_DATE_INDEX, FILE_DATE_LENGTH);
			validateField(fileDateStr, CONST_FILE_DATE, FILE_DATE_INDEX+1, FILE_DATE_INDEX+FILE_DATE_LENGTH);

			// File DateTime must be a valid DateTime.
			fileDateTime = convertFileDateStrToDateTimeFormat(fileDateStr);
			isFileHeaderRead = Bool.TRUE;

		}

		/**
		 * This Method will process the BAtch Header Record, to fetch and validate the Batch Number.
		 * @param record
		 */
		private void processBatchHeader(String record){

			totalBatchHeaderRecords = totalBatchHeaderRecords + 1;

			if(totalBatchHeaderRecords > 1){
				addError(CustomMessageRepository.ni0040_4MultipleBatchHeaderRecords());
			}

			//To check that the File Header is processed first.
			if(isFileHeaderRead.isFalse() || isBatchTrailerRead.isTrue() || isFileTrailerRead.isTrue()){
				addError(CustomMessageRepository.ni0040_4InvalidRecordTypeOrder());
			}

			headerBatchNumber = getFieldValue(record, BATCH_NUMBER_INDEX, BATCH_NUMBER_LENGTH);
			validateField(headerBatchNumber, CONST_BATCH_NUM, BATCH_NUMBER_INDEX+1, BATCH_NUMBER_INDEX+BATCH_NUMBER_LENGTH);

			// Get Trend Source for External Source Id  = batch number;
			retrieveTrendSource();

			// Check whether Batch Type matches with Batch Type Parameter
			batchTypeStr = getFieldValue(record, BATCH_TYPE_INDEX, BATCH_TYPE_LENGTH);

			validateField(batchTypeStr, CONST_BATCH_TYPE, BATCH_TYPE_INDEX+1, BATCH_TYPE_INDEX+BATCH_TYPE_LENGTH);

			try {
				batchType = new BigInteger(batchTypeStr);
			}catch(Exception ae){
				addError(CustomMessageRepository.ni0040_4RecordInError(lineCounter.toString().trim(), ae.getMessage()));
			}

			if(batchType.compareTo(parmBatchType)!=0){
				addError(CustomMessageRepository.ni0040_4InvalidBatchType(lineCounter.toString(), batchTypeStr));
			}

			batchTotalDepositAmount =  BigDecimal.ONE;  
			batchCount = BigInteger.ONE;   
			processedDetailedRecordsCount = 0;
			isBatchHeaderRead = Bool.TRUE;

			Money totTenderCtlAmount = new Money(batchTotalDepositAmount.toString(), tenderSource.getCurrency().getId() );

			//  if EXT_SOURCE_ID and EXT_TRANSMIT_ID already exist in Deposit Control Staging, log error message then abort program
			DepositControlStaging_Id depositCntlStgId = new DepositControlStaging_Id(headerBatchNumber, fileDateStr);              
			if(!isNull(depositCntlStgId.getEntity())){
				addError(CustomMessageRepository.ni0040_4DuplicateDepositError(headerBatchNumber, fileDateStr));
			} 

			//Create entry into Deposit Control Staging table
			createDepositControlStagingRecord(totTenderCtlAmount);

			// Create Entry into Tender Control Staging Table
			createTenderControlStagingRecord(totTenderCtlAmount);

			//  Reset processedDetailedRecordsCount of detail records per header
			batchTotalDepositAmount =  BigDecimal.ZERO;

		}
		

		/**
		 * This Method will process the Detail record present in the File.
		 * It will Fetch the Required Fields and validate them.
		 * It will create the Payment Staging records.
		 * @param record
		 */
		private void processDetailsRecord(String record){

			//To check that the File & Batch Headers are processed first.
			if(isFileHeaderRead.isFalse() || isBatchHeaderRead.isFalse() || isFileTrailerRead.isTrue()){
				addError(CustomMessageRepository.ni0040_4InvalidRecordTypeOrder());  
			}

			// Get Premise Details provided on the Record
			premiseIdStr = getFieldValue(record, PREMISE_ID_INDEX, PREMISE_ID_LENGTH);

			//Start Change - JMeden - Defect 4598924 - 2021-09-27
			//validateField(premiseIdStr, CONST_PREMISE_ID, PREMISE_ID_INDEX + 1, PREMISE_ID_INDEX + PREMISE_ID_LENGTH);
			if(isBlankOrNull(premiseIdStr)){
				isSuspensePayment = Boolean.TRUE;
			} else {
			//End Change - JMeden - Defect 4598924 - 2021-09-27	
				premiseId = new Premise_Id(premiseIdStr);
	
				if(isNull(premiseId.getEntity())){
					isSuspensePayment = Boolean.TRUE;
	
				}
			//Start Add - JMeden - Defect 4598924 - 2021-09-27
			}
			//End Add - JMeden - Defect 4598924 - 2021-09-27

			// Find An Active Referral for the Referral Details provided on the record 
			referralIdStr = getFieldValue(record, REFERRAL_ID_INDEX, REFERRAL_ID_LENGTH);

			//Start Change - JMeden - Defect 4598924 - 2021-09-27
			//validateField(referralIdStr, CONST_REFERRAL_ID, REFERRAL_ID_INDEX+1, REFERRAL_ID_INDEX+REFERRAL_ID_LENGTH);
			
			if(isBlankOrNull(referralIdStr)){
				isSuspensePayment = Boolean.TRUE;
			} else {
			//End Change - JMeden - Defect 4598924 - 2021-09-27
				colReferralAgencyId = new CollectionAgencyReferral_Id(referralIdStr);
	
				colReferralAgency = colReferralAgencyId.getEntity();
	
				if(isNull(colReferralAgency)){
					isSuspensePayment = Boolean.TRUE;
	
				}else {
	
					if(!colReferralAgency.getReferralStatus().isActive()){
						// If Coll Referral Agency is not Active , then put Payment(s) into Suspesne Account
						isSuspensePayment = Boolean.TRUE;
					}
					// Retrieve Account details from Col Agency Referral 
					account = colReferralAgency.getAccount();
					if(isNull(account)){
						// If Account is not found then then put Payment(s) into Suspense Account
						isSuspensePayment = Boolean.TRUE;
					}
				}
			//Start Add - JMeden - Defect 4598924 - 2021-09-27
			}
			//End Add - JMeden - Defect 4598924 - 2021-09-27


			// Get the External Referrence Details from the input file
			extRefId = getFieldValue(record, EXT_REF_ID_INDEX, EXT_REF_ID_LENGTH);
			validateField(extRefId, CONST_EXT_PAY_ID, EXT_REF_ID_INDEX+1, EXT_REF_ID_INDEX+EXT_REF_ID_LENGTH);

			// Get the Pay Type Code Details from the input file
			payTypeCode = getFieldValue(record, PAY_TYPE_CODE_INDEX, PAY_TYPE_CODE_LENGTH);

			validateField(payTypeCode, CONST_PAY_TYPE, PAY_TYPE_CODE_INDEX+1, PAY_TYPE_CODE_INDEX+PAY_TYPE_CODE_LENGTH);

			mappedPayTypeCode = retrieveFeatureConfig("X"+payTypeCode);
			tenderTypeId = new TenderType_Id(mappedPayTypeCode);

			if(isNull(tenderTypeId.getEntity())) {
				addError(CustomMessageRepository.ni0040_4InvalidPayTypeCode( payTypeCode, lineCounter.toString()));
			}

			// Get the Amount-Paid Field from the Input File
			amountPaidStr = getFieldValue(record, AMOUNT_PAID_INDEX, AMOUNT_PAID_LENGTH);
			validateField(amountPaidStr, CONST_AMOUNT_PAID, AMOUNT_PAID_INDEX+1, AMOUNT_PAID_INDEX + AMOUNT_PAID_LENGTH);

			try{
				amountPaid = new BigDecimal(amountPaidStr);
				amountPaid = amountPaid.movePointLeft(2);

			} catch(NumberFormatException e){
				addError(CustomMessageRepository.ni0040_4NumberFormatException(lineCounter.toString(), amountPaidStr));  
			}

			tenderAmount = new Money(amountPaid,tenderSource.getCurrency().getId());
			batchTotalDepositAmount = batchTotalDepositAmount.add(amountPaid);

			// Get Check Number details from the Input File
			if(!isBlankOrNull(payTypeCode) && Integer.parseInt(payTypeCode) == 2){
				checkNumber = getFieldValue(record, CHECK_NUMBER_INDEX, CHECK_NUMBER_LENGTH);
				validateField(checkNumber, CONST_CHECK_NUMBER, CHECK_NUMBER_INDEX+1, CHECK_NUMBER_INDEX + CHECK_NUMBER_LENGTH);
			}

			if(isSuspensePayment){
				// When Accout or Premise or Collection Agency Referral are not found , i.e then they
				// need to send payments to suspense Accounts.  Hence Cusotmer Id = X + Premise Id for posting the Payments to Suspsense Acct
				
				//Start Change - JMeden - Defect 4598924 - 2021-09-27
				//customerIdStr = 'X'+premiseIdStr;
				String strAcctId = getFieldValue(record, ACCOUNT_ID_INDEX, ACCOUNT_ID_LENGTH);
				customerIdStr = 'X'+strAcctId;
				//End Change - JMeden - Defect 4598924 - 2021-09-27
			}else{
				customerIdStr = account.getId().getTrimmedValue();
			}


			// Create Payment Tender Staging Table 
			createPaymentTenderStagingRecord();

			// Create Payment Upload Staging Table
			createPaymentUploadStagingRecord();

			processedDetailedRecordsCount++;
		}

		private void processBatchTrailer(String record) {

			totalBatchTrailerRecords = totalBatchTrailerRecords  + 1;

			if(totalBatchTrailerRecords > 1){
				addError(CustomMessageRepository.ni0040_4MultipleBatchTrailerRecords());
			}

			// To Check that the File & Batch Headers are processed before processing the batch trailer.
			if(isFileHeaderRead.isFalse() || isBatchHeaderRead.isFalse() || isFileTrailerRead.isTrue()){
				addError(CustomMessageRepository.ni0040_4InvalidRecordTypeOrder()); 
			}

			String trailerBatchNumberStr = getFieldValue(record, BATCH_NUMBER_INDEX, BATCH_NUMBER_LENGTH);
			validateField(trailerBatchNumberStr, CONST_BATCH_NUM, BATCH_NUMBER_INDEX+1, BATCH_NUMBER_INDEX+BATCH_NUMBER_LENGTH);

			//  Check whether the Batch Number in Batch Trailer matches with Batch Number in Batch Header Record.
			// If not matched , throw an error
			if(!headerBatchNumber.equalsIgnoreCase(trailerBatchNumberStr)){
				addError(CustomMessageRepository.ni0040_4BatchHdrAndTrailerRecordsBatchNbrAreNotSame()); 
			}

			String batchitemCountStr = getFieldValue(record, BATCH_ITEM_COUNT_INDEX, BATCH_ITEM_COUNT_LENGTH);
			validateField(batchitemCountStr, CONST_BATCH_ITEM_COUNT, BATCH_ITEM_COUNT_INDEX+1, BATCH_ITEM_COUNT_INDEX+BATCH_ITEM_COUNT_LENGTH);

			try{
				batchTrailerRecordCount = Integer.parseInt(batchitemCountStr);
			}catch(Exception ae){
				addError(CustomMessageRepository.ni0040_4RecordInError(lineCounter.toString().trim(), ae.getMessage()));
			}

			if (batchTrailerRecordCount != processedDetailedRecordsCount){
				addError(CustomMessageRepository.ni0040_4BatchTrailerCountndTotalRecordCountAreNotSame(String.valueOf(batchTrailerRecordCount),String.valueOf(processedDetailedRecordsCount), headerBatchNumber)); 
			}

			// Get the Batch Deposit Amount Details
			String batchdepositAmountStr = getFieldValue(record, BATCH_DEPOSIT_AMT_INDEX, BATCH_DEPOSIT_AMT_LENGTH);

			validateField(batchdepositAmountStr, CONST_DEP_AMT, BATCH_DEPOSIT_AMT_INDEX+1, BATCH_DEPOSIT_AMT_INDEX+BATCH_DEPOSIT_AMT_LENGTH);
			calculatedBatchTotalPaymentAmount = new BigDecimal(batchdepositAmountStr);
			calculatedBatchTotalPaymentAmount = calculatedBatchTotalPaymentAmount.movePointLeft(2);

			if(batchTotalDepositAmount.compareTo(calculatedBatchTotalPaymentAmount) !=0){
				addError(CustomMessageRepository.ni0040_4BatchTotalDepositAmountAndTotalPaymentAmountAreNotSame(calculatedBatchTotalPaymentAmount.toString(),batchTotalDepositAmount.toString(), headerBatchNumber)); 
			}

			// Update Deposit Control Amount
			DepositControlStaging_DTO depositControlStagingDTO= depositControlStaging.getDTO();
			depositControlStagingDTO.setTenderControlTotalAmount(new Money(calculatedBatchTotalPaymentAmount,tenderSource.getCurrency().getId()));
			depositControlStaging.setDTO(depositControlStagingDTO);

			TenderControlStaging_DTO tenderControlStagingDTO = tenderControlStaging.getDTO();
			tenderControlStagingDTO.setTotalTendersAmount(new Money(calculatedBatchTotalPaymentAmount,tenderSource.getCurrency().getId()));
			tenderControlStagingDTO.setTotalNumberOfTender(BigInteger.valueOf(batchTrailerRecordCount));
			tenderControlStaging.setDTO(tenderControlStagingDTO);

			totalBatchCount = totalBatchCount + 1;
			totalFileRecordCount = totalFileRecordCount + processedDetailedRecordsCount;
			calculatedFileTotalDepositAmt = calculatedFileTotalDepositAmt.add(batchTotalDepositAmount); 

			isBatchTrailerRead = Bool.TRUE;
		}


		/**
		 * This Method will fetch and validate the Batch Count, Deposit Amount and item processedDetailedRecordsCount with the
		 * total number of batches, total number of records and total payment amountPaid of records in the File. 
		 * @param record
		 */private void processFileTrailer(String record){

			 BigDecimal  fileTotalDepositAmount = BigDecimal.ZERO;

			 totalFileTrailerRecords = totalFileTrailerRecords + 1;

			 if(totalFileTrailerRecords  >1 ){
				 addError(CustomMessageRepository.ni0040_4MultipleFileTrailerRecords());  
			 }

			 //To Check whether there are any unclosed batch records or the file and batch headers are processed first.

			 if(isFileHeaderRead.isFalse() || isBatchHeaderRead.isFalse() || isBatchTrailerRead.isFalse()){
				 addError(CustomMessageRepository.ni0040_4InvalidRecordTypeOrder());  
			 }

			 String trailerDateStr = getFieldValue(record, TRAILER_DATE_INDEX, TRAILER_DATE_LENGTH);
			 validateField(trailerDateStr, CONST_TRAILER_DATE, TRAILER_DATE_INDEX+1, TRAILER_DATE_INDEX+TRAILER_DATE_LENGTH);

			 // Trailer DateTime must be a valid DateTime.
			 DateTime trailerDateTime = convertFileDateStrToDateTimeFormat(trailerDateStr);
			 if(fileDateTime.compareTo(trailerDateTime) !=0){
				 addError(CustomMessageRepository.ni0040_4FileHdrAndTrailerDateTimeNotSame(fileDateStr,trailerDateStr));
			 }

			 // Get the File Trailer Batch Count Details
			 String fileTrailerBatchCountStr = getFieldValue(record, TOTAL_FILE_COUNT_INDEX, TOTAL_FILE_COUNT_LENGTH);
			 validateField(fileTrailerBatchCountStr, CONST_BATCH_COUNT, TOTAL_FILE_COUNT_INDEX+1, TOTAL_FILE_COUNT_INDEX+TOTAL_FILE_COUNT_LENGTH);
			 try{
				 fileTrailerBatchCount = Integer.parseInt(fileTrailerBatchCountStr);
			 }catch(Exception ae){
				 addError(CustomMessageRepository.ni0040_4RecordInError(lineCounter.toString().trim(), ae.getMessage()));
			 }

			 if (totalBatchCount != fileTrailerBatchCount){
				 addError(CustomMessageRepository.ni0040_4FileTrailerBatchCountAndTotalBatchCountAreNotSame(fileTrailerBatchCountStr, String.valueOf(totalBatchCount)));  

			 }

			 String fileTrailerRecordCountStr = getFieldValue(record, TOTAL_ITEM_COUNT_INDEX, TOTAL_ITEM_COUNT_LENGTH);
			 validateField(fileTrailerRecordCountStr, CONST_BATCH_ITEM_COUNT, TOTAL_ITEM_COUNT_INDEX+1, TOTAL_ITEM_COUNT_INDEX+TOTAL_ITEM_COUNT_LENGTH);

			 try{
				 fileTrailerRecordCount = Integer.parseInt(fileTrailerRecordCountStr);
			 }catch(Exception ae){
				 addError(CustomMessageRepository.ni0040_4RecordInError(lineCounter.toString().trim(), ae.getMessage()));
			 }

			 if(fileTrailerRecordCount !=totalFileRecordCount){
				 addError(CustomMessageRepository.ni0040_4FileTrailerItemCountAndTotalItemCountAreNotSame(fileTrailerRecordCountStr, String.valueOf(totalFileRecordCount))); 
			 }

			 String totalDepositAmountStr = getFieldValue(record, TOTAL_DEPOSIT_AMT_INDEX, TOTAL_DEPOSIT_AMT_LENGTH);

			 validateField(totalDepositAmountStr, CONST_FILE_DEP_AMT, TOTAL_DEPOSIT_AMT_INDEX+1, TOTAL_DEPOSIT_AMT_INDEX+TOTAL_DEPOSIT_AMT_LENGTH);
			 try{
				 fileTotalDepositAmount = new BigDecimal(totalDepositAmountStr);
			 }catch(Exception ae){
				 addError(CustomMessageRepository.ni0040_4RecordInError(lineCounter.toString().trim(), ae.getMessage()));
			 }

			 fileTotalDepositAmount = fileTotalDepositAmount.movePointLeft(2);

			 if(calculatedFileTotalDepositAmt.compareTo(fileTotalDepositAmount) != 0){
				 addError(CustomMessageRepository.ni0040_4FileTotalDepositAmountAndTotalPaymentAmountsAreNotSame(fileTotalDepositAmount.toString(), calculatedFileTotalDepositAmt.toString())); 
			 }

			 isFileTrailerRead = Bool.TRUE;
		 }



		 /**
		  * @return String 
		  *  This method retrieves Feature Config value
		  * 
		  */  
		 private String retrieveFeatureConfig(String strFeatureConfigOption) {
			 String strFeatureConfigVal = null;
			 CmFeatureConfigurationRetriever cmFeatureConfigurationRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
			 cmFeatureConfigurationRetriever.setParmWFMName(parmPaymentsFeatureConfig);
			 cmFeatureConfigurationRetriever.setParmOptType(strFeatureConfigOption);
			 strFeatureConfigVal = cmFeatureConfigurationRetriever.getMaxSequenceOptionValue();
			 return strFeatureConfigVal;


		 }

		 private void createPaymentUploadStagingRecord() {
			 startChanges();
			 //Start Change - JMeden - Defect 4598924 - 2021-09-27
			 //String matchValue = colReferralAgencyId.getTrimmedValue().concat(premiseId.getTrimmedValue());
			 String strColRefAgencyId = "";
			 String strPremId = "";

			 if(isBlankOrNull(referralIdStr)){
				 strColRefAgencyId = DFLT_COL_REF_AGENCY_ID;
			 } else {
				 strColRefAgencyId = colReferralAgencyId.getTrimmedValue();
			 }
			 
			 if(isBlankOrNull(premiseIdStr)){
				 strPremId = DFLT_PREM_ID;
			 } else {
				 strPremId = premiseId.getTrimmedValue();
			 }
			 
			 String matchValue = strColRefAgencyId.concat(strPremId);
			 //End Change - JMeden - Defect 4598924 - 2021-09-27
			 
			 PaymentUpload_Id paymentUploadId = new PaymentUpload_Id(paymentTenderUpload,customerIdStr, parmMatchType.getId().getTrimmedValue(), matchValue  );

			 PaymentUpload_DTO paymentUploadDTO  = paymentUploadId.newDTO();

			 paymentUploadDTO.setPaymentAmount(tenderAmount);

			 @SuppressWarnings("unused")
			 PaymentUpload paymentUpload =  paymentUploadDTO.newEntity();

			 saveChanges();

		 }

		 private void createPaymentTenderStagingRecord() {
			 startChanges();
			 
			 TenderControlStaging_Id tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, headerBatchNumber);   
			 PaymentTenderUpload_Id paymentTenderUploadId = new PaymentTenderUpload_Id(tenderControlStagingId, extRefId);
			 PaymentTenderUpload_DTO paymentTenderUploadDTO = paymentTenderUploadId.newDTO(); 
			 paymentTenderUploadDTO.setPaymentTenderStagingStatus(PaymentTenderStagingStatusLookup.constants.PENDING);  
			 paymentTenderUploadDTO.setTenderAmount(tenderAmount);               
			 paymentTenderUploadDTO.setAccountingDate(getProcessDateTime().getDate());
			 paymentTenderUploadDTO.setTenderTypeId(tenderTypeId);   
			 if(Integer.parseInt(payTypeCode) == 2){
				 paymentTenderUploadDTO.setCheckNumber(checkNumber.trim());
			 }
			 paymentTenderUploadDTO.setCustomerId(customerIdStr); 
			 paymentTenderUploadDTO.setMicrId(CONST_SPACE);						
			 paymentTenderUploadDTO.setName(CONST_SPACE);
			 paymentTenderUpload = paymentTenderUploadDTO.newEntity(); 

			 saveChanges();
		 }


		 /** Creating Deposit Control Staging Record 
		  *  Initially Setting the TotalTender Cntrl Amount and batch processedDetailedRecordsCount = 1
		  */ 
		 private void createDepositControlStagingRecord(Money totTenderCtlAmount) {

			 startChanges();
			 DepositControlStaging_Id depositControlStagingId = new DepositControlStaging_Id(headerBatchNumber, fileDateStr);                                                
			 DepositControlStaging_DTO depositControlStagingDTO = depositControlStagingId.newDTO();                                                                                 
			 depositControlStagingDTO.setDepositControlStagingStatus(DepositControlStagingStatusLookup.constants.PENDING);
			 depositControlStagingDTO.setTransmissionDateTime(fileDateTime);                                                                       
			 depositControlStagingDTO.setCurrencyId(tenderSource.getCurrency().getId());                                                                  
			 depositControlStagingDTO.setTenderControlTotalAmount(totTenderCtlAmount);
			 depositControlStagingDTO.setTotalTenderControl(batchCount);
			 depositControlStaging = depositControlStagingDTO.newEntity();   
			 saveChanges();

		 }

		 // Create and insert a Tender Control staging record. Initially Setting the TotalTender Cntrl Amount = 1
		 private void createTenderControlStagingRecord(Money totTenderCtlAmount) {
			 startChanges();
			 TenderControlStaging_Id tenderControlStagingId = new TenderControlStaging_Id(depositControlStaging, headerBatchNumber);                                             
			 TenderControlStaging_DTO tenderControlStagingDTO = tenderControlStagingId.newDTO();
			 tenderControlStagingDTO.setTenderControlStatus(TenderControlStatusLookup.constants.PENDING);                                             
			 tenderControlStagingDTO.setTotalTendersAmount(totTenderCtlAmount);                
			 tenderControlStaging = tenderControlStagingDTO.newEntity();   
			 saveChanges();

		 }

		 private void retrieveTrendSource() {

			 SQLResultRow trendSourceResultRow = null;

			 StringBuilder getTrendSourceQueryStr = new StringBuilder();

			 getTrendSourceQueryStr.append("SELECT TNDR_SOURCE_CD FROM CI_TNDR_SRCE ");
			 // CCB v2.6 Upgrade - 2018-07-25 - Start Change
			 //getTrendSourceQueryStr.append("WHERE @trim(EXT_SOURCE_ID) = :headerBatchNumber ");
			 getTrendSourceQueryStr.append("WHERE EXT_SOURCE_ID = :headerBatchNumber ");
			 // CCB v2.6 Upgrade - 2018-07-25 - End Change
			 //Start Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
			 //PreparedStatement pstmt =  createPreparedStatement(getTrendSourceQueryStr.toString());
			 PreparedStatement pstmt =  createPreparedStatement(getTrendSourceQueryStr.toString(), getClass().getName());
			 //End Change - 2016-01-27 - MPang - Updated for CCB v2.4 compilation
			 pstmt.bindStringProperty("headerBatchNumber", TenderSource.properties.externalSourceId, headerBatchNumber);

			 if(notNull(pstmt.firstRow())){
				 trendSourceResultRow = pstmt.firstRow();
			 }

			 pstmt.close();

			 if(isNull(trendSourceResultRow)){
				 addError(CustomMessageRepository.ni0040_4NoTrendSourceFound(lineCounter.toString(), headerBatchNumber));
			 }

			 tenderSourceCd = (TenderSource_Id) trendSourceResultRow.getId("TNDR_SOURCE_CD", TenderSource.class);

			 if(isNull(tenderSourceCd)){
				 addError(CustomMessageRepository.ni0040_4NoTrendSourceFound(lineCounter.toString(), headerBatchNumber));
			 }

			 tenderSource = tenderSourceCd.getEntity();

			 if(isNull(tenderSource)){
				 addError(CustomMessageRepository.ni0040_4InvalidTrendSourceFound(lineCounter.toString(), headerBatchNumber));
			 }

		 }

		 /**
		  * Convert the input fileDateString to the Date in the given date format.
		  * @param fileDate
		  */
		 private DateTime convertFileDateStrToDateTimeFormat(String fileDateStr){

			 DateTime dateTime=null;

			 try{
				 dateTime = DateTime.fromString(fileDateStr, new DateFormat(DATETIME_FORMAT_MMDDYYYYHHMMSS));
			 } catch (DateFormatParseException e) {
				 addError(CustomMessageRepository.ni0040_4InvalidDate(lineCounter.toString(), 
						 CONST_FILE_DATE, fileDateStr, DATETIME_FORMAT_MMDDYYYYHHMMSS));
			 }
			 return dateTime;
		 }

		 /**
		  * This method retrieves the trimmed field value from the record starting 
		  * from the startPos and of the given length.
		  * @param record
		  * @param startPos
		  * @param length
		  * @return
		  */
		 private String getFieldValue(String record, int startPos, int length) {

			 String value = null;
			 if(record.length() >= startPos+length){
				 value = record.substring(startPos, startPos+length).trim();
			 }
			 return value;
		 }

		 private void validateField(String value, String fieldName, int startPos, int endPos){
			 if(isBlankOrNull(value)){
				 addError(CustomMessageRepository.ni0040_4MandatoryfieldIsBlank(lineCounter.toString(), fieldName,
						 String.valueOf(startPos), String.valueOf(endPos)));
			 }
		 }

		 private void openFile(){
			 if(isNull(parmFileName)) {
				 parmFileName = null;
			 }
			 inputFilePathAndName = new File(parmFilePath, parmFileName);
			 try {
				 inputFile = new BufferedReader(new FileReader(inputFilePathAndName));  

			 }
			 catch (IOException e) {     
				 throw new RunAbortedException(CustomMessageRepository.ni0040_4ErrorInFile(e.getMessage()));
			 }
		 }      

		 private String readFileLine(){
			 try {       
				 return inputFile.readLine();
			 }
			 catch(IOException e) {
				 throw new RunAbortedException(CustomMessageRepository.ni0040_4ErrorInFile(e.getMessage()));
			 }
		 }

		 private void closeFile(){
			 try {       
				 inputFile.close();
			 }
			 catch(IOException e) {
				 throw new RunAbortedException(CustomMessageRepository.ni0040_4ErrorInFile(e.getMessage()));
			 }       
		 }	

	}

}
