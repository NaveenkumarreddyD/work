/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm will be used to update the PAYS SA end date to the date 
 * of the latest bill segment, set the latest bill segment final bill 
 * switch to true and create an adjustment to match the PAYS SA payoff 
 * balance with the current balance
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2023-11-17   IReyes      Initial Version.                   
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.stopSa;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_DTO;
import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saStop.SaTypeSaStopAlgorithmSpot;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;

/**
 * @author OGC04200
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = adjustmentType, name = paysPrincipalAdjustmentType, required = true, type = entity)})
 */
public class CmProcessPaysSaFinalBillAlgComp_Impl extends
		CmProcessPaysSaFinalBillAlgComp_Gen implements
		SaTypeSaStopAlgorithmSpot {
	
	// Hard parameters
	private ServiceAgreement sa;
	
    //Constants
    private String PAY_ADJ_COMMENT = "Removing unpaid PAYS balance - To be setup for new homeowner at the premise.";
	
	@Override
	public void setServiceAgreement(ServiceAgreement serviceAgreement) {
		sa = serviceAgreement;
	}
	
	@Override
	public void invoke() {
    	//Check if PAYS SA payoff amount is greater than the current amount.
		if (sa.getPayoffBalance().isGreaterThan(sa.getCurrentBalance())){
			//Get the latest bill segment for the PAYS SA
			Query<QueryResultRow> bsQry = createQuery("from BillSegment bs "
					+ " where bs.serviceAgreement = :sa "
					+ "		and bs.billSegmentStatus = :frozen "
					, "BSQ");
			bsQry.bindEntity("sa", sa);
			bsQry.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
			bsQry.addResult("bsId", "bs.id");
			bsQry.addResult("endDate", "bs.endDate");
			bsQry.orderBy("endDate", Query.DESCENDING);
			
			if (bsQry.listSize() > 0){
				
				// Set SA stop date to latest bill segment end date.
				QueryResultRow latestBs = bsQry.firstRow();
				BillSegment_Id bsId = (BillSegment_Id) latestBs.getId("bsId", BillSegment.class);
				BillSegment bs = bsId.getEntity();
				
				ServiceAgreement_DTO saDto = sa.getDTO();
				saDto.setEndDate(bs.getEndDate());
				sa.setDTO(saDto);
				
				// Update latest bill segment to closing bill segment.
				PreparedStatement updBS = createPreparedStatement("UPDATE CI_BSEG BSEG SET BSEG.CLOSING_BSEG_SW = :Y "
						+ "WHERE BSEG.BSEG_ID = :BS"
						,"updBS");
				updBS.bindBoolean("Y", Bool.TRUE);
				updBS.bindId("BS", bs.getId());
				updBS.execute();
				updBS.close();
				
			}
			
			//Update the PAYS SA payoff balance to match the current balance
	        CreateFrozenAdjustmentData adjustmentData = CreateFrozenAdjustmentData.Factory.newInstance();

	        adjustmentData.setServiceAgreement(sa);
	        adjustmentData.setAdjustmentAmount(sa.getPayoffBalance().subtract(sa.getCurrentBalance()).negate());
	        adjustmentData.setAdjustmentType(getPaysPrincipalAdjustmentType());
	        adjustmentData.setAllowZeroAmount(Bool.FALSE);

	        CreateFrozenAdjustment createFrozenAdjustment = CreateFrozenAdjustment.Factory.newInstance();
			CreateFrozenAdjustmentData outputData = createFrozenAdjustment.createFrozenAdjustment(adjustmentData);
			
			Adjustment adjustment = outputData.getAdjustment();
			Adjustment_DTO adjustmentDTO = adjustment.getDTO();
			adjustmentDTO.setComments(PAY_ADJ_COMMENT); 
			adjustment.setDTO(adjustmentDTO);
		}
	}
}
