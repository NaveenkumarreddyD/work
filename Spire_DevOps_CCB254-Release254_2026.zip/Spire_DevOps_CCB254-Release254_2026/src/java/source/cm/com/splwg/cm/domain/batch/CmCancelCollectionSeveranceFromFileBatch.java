/* 
 *********************************************************************** 
 *                 Confidentiality Information: 
 * 
 * 
 *********************************************************************** 
 * 
 * PROGRAM DESCRIPTION:
 * 
 * Cancel Collection / Severance Process from a list of account
 * 
 * This batch control would read through a flat file containing 
 * a list of account and call a business service which would 
 * prevent disconnection of service for the account by checking 
 * for and canceling any active severance process and collection 
 * process for the account. Additionally, this service would also
 * postpone credit review of the account by n number of days.
 * 
 *********************************************************************** 
 * 
 * 
 * CHANGE HISTORY: 
 * 
 * Date:         by:       Reason:
 * YYYY-MM-DD    IN        Reason text.
 *
 * 2021-06-17    JHERNA    SysAid#371555. Initial Version.                             
 *********************************************************************** 
 */
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.businessObject.COTSFieldDataAndMD;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.businessService.BusinessServiceDispatcher;
import com.splwg.base.api.businessService.BusinessServiceInstance;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author blu02772
 *
@BatchJob (modules = {}, multiThreaded = false,
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CANCEL_COLL_PROC_SW, required = true, type = boolean)
 *            , @BatchJobSoftParameter (name = CANCEL_SEV_PROC_SW, required = true, type = boolean)
 *            , @BatchJobSoftParameter (name = POSTPONE_BY_DAYS, required = true, type = integer)})
 */
public class CmCancelCollectionSeveranceFromFileBatch 
		extends CmCancelCollectionSeveranceFromFileBatch_Gen {

	public JobWork getJobWork() {
		// Dummy batch
		List<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
		arrayList.add(threadWorkUnit);
		return createJobWorkForThreadWorkUnitList(arrayList);
	}
	
	@Override
	public void validateSoftParameters(boolean isNewRun) {
		
		// Retrieve and validate parameter 10: file path
		String filePath = this.getParameters().getFILE_PATH().trim();
		filePath = filePath.replaceAll("\\\\", "/");
		if (filePath.substring(filePath.length()-1).compareTo("/") != 0) {
			filePath = filePath.concat("/");
		}
		Bool isValidPath = validateFile(filePath, Bool.FALSE);
		if (isValidPath.isFalse()) {
			addError(CustomMessageRepositoryMGE.commBatchParameterIsNotValidFilePath("FILE_PATH", filePath));
		}
		
		// Retrieve and validate parameter 20: file name
		String fileName = this.getParameters().getFILE_NAME().trim();
		String filePathName = filePath.trim().concat(fileName).trim();
		Bool isValidFile = validateFile(filePathName, Bool.TRUE);
		if (isValidFile.isFalse()) {
			addError(CustomMessageRepositoryMGE.commBatchParameterInvalid("FILE_NAME", this.getParameters().getFILE_NAME().trim()));
		}	
		
		// Retrieve and validate parameter 50: postpone by days
		BigInteger postponeByDays = this.getParameters().getPOSTPONE_BY_DAYS();
		if (postponeByDays.compareTo(BigInteger.ZERO) < 0) {
			addError(CustomMessageRepositoryMGE.commBatchParameterIsNotValidInteger("POSTPONE_BY_DAYS", postponeByDays.toString().trim()));
		}
	}

	private Bool validateFile(String filePath, Bool isReadable) {
    	
    	Bool returnValue = Bool.FALSE;
        File folder = new File(filePath);

        if (folder.exists()) {
            returnValue = Bool.TRUE;
        }
        if (isReadable.isTrue()) {        	
        	if (folder.canRead()) {
        		returnValue = Bool.TRUE;
        	}   
        	else {
        		returnValue = Bool.FALSE;
        	}
        }        
        return returnValue;
    }


	public Class<CmCancelCollectionSeveranceFromFileBatchWorker> getThreadWorkerClass() {
		return CmCancelCollectionSeveranceFromFileBatchWorker.class;
	}

	public static class CmCancelCollectionSeveranceFromFileBatchWorker extends
			CmCancelCollectionSeveranceFromFileBatchWorker_Gen {

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		/*work variables*/
		private String wFilePathName;
		private String wFileName;
		private Bool wShouldCancelCollProc;
		private Bool wShouldCancelSevProc;
		private BigInteger wPostponeCreditReviewByNbrOfDays;		
		private BigInteger wTotalNbrCollProcCanceled;
		private BigInteger wTotalNbrSevProcCanceled;		
		private File wFile;
		private int wTotalNbrRecordsInErrored;
		private int wTotalNbrRecordsProcessed;
						
		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {

			String parmFilePath = this.getParameters().getFILE_PATH();
			wFileName = this.getParameters().getFILE_NAME();
			
			if (parmFilePath.substring(parmFilePath.length()-1).compareTo("/") != 0) {
				parmFilePath = parmFilePath.concat("/");
			}
			wFilePathName = parmFilePath.trim().concat(wFileName).trim();
			
			wShouldCancelCollProc = this.getParameters().getCANCEL_COLL_PROC_SW();
			wShouldCancelSevProc = this.getParameters().getCANCEL_SEV_PROC_SW();
			wPostponeCreditReviewByNbrOfDays = this.getParameters().getPOSTPONE_BY_DAYS();
			
			wFile = new File(wFilePathName);			
			wTotalNbrCollProcCanceled = BigInteger.ZERO;
			wTotalNbrSevProcCanceled = BigInteger.ZERO;
			wTotalNbrRecordsInErrored = 0;
			wTotalNbrRecordsProcessed = 0;
		}

		@SuppressWarnings("rawtypes")
		private void cmPopulateSchemaElements(BusinessServiceInstance bsInstance, String elementName, String value) {
			COTSFieldDataAndMD element = bsInstance.getGroup("input").getFieldAndMD(elementName);
			element.setXMLValue(value);
		}
		
		@SuppressWarnings({ "rawtypes", "unchecked" })
		private void cmPopulateSchemaElements(BusinessServiceInstance bsInstance, String elementName, Bool value) {
			COTSFieldDataAndMD element = bsInstance.getGroup("input").getFieldAndMD(elementName);
			element.setValue(value);				
		}		
		
		private BusinessServiceInstance cmCallBusinessService(BusinessServiceInstance bsInstance) {
			return BusinessServiceDispatcher.execute(bsInstance);
		}
		
		@Override
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			BufferedReader reader = null;
			try {
				reader = new BufferedReader(new FileReader(wFile));
				int lineNumber = 0;
				// retrieve lines from file if available
				while (reader.ready()) {
					
					lineNumber++;
					wTotalNbrRecordsProcessed++;
					
					String recordLine = reader.readLine();
					
					// note that the input file only has one data in it per record line and that is the account ID
					if (isBlankOrNull(recordLine)) {
						wTotalNbrRecordsInErrored++;
						// %1%2 is missing. See line number %3 of %4%5
						logError(CustomMessageRepositoryMGE.commFileMissing("Account Id", String.valueOf(lineNumber), wFileName.trim()));
						continue;
					}
					else {
						
						Account_Id accountID = new Account_Id(recordLine.trim());
						if (isNull(accountID.getEntity())) {
							wTotalNbrRecordsInErrored++;
							// Error on line number %1 of the file %2%3. %4%5 is not a valid %6%7.
							logError(CustomMessageRepositoryMGE.commFileRecordInvalid(String.valueOf(lineNumber), wFileName.trim(), recordLine.trim(), "Account Id"));
							continue;
						}
						
						/* Call business service to process the account */
						BusinessServiceInstance bsInstance = BusinessServiceInstance.create("CM-CancelCollectionActivities");
						/* populate schema elements */
						cmPopulateSchemaElements(bsInstance, "accountID", accountID.getTrimmedValue());
						cmPopulateSchemaElements(bsInstance, "cancelCollectionProcessSw", wShouldCancelCollProc);
						cmPopulateSchemaElements(bsInstance, "cancelSeveranceProcessSw", wShouldCancelSevProc);		
						cmPopulateSchemaElements(bsInstance, "postponeByDays", wPostponeCreditReviewByNbrOfDays.toString().trim());
						
						BusinessServiceInstance results = cmCallBusinessService(bsInstance);
						COTSInstanceNode output = results.getGroupFromPath("output");
						
						BigInteger totCollCanceled = output.getNumber("totalCollProcCanceled").toBigInteger();
						BigInteger totSevCanceled = output.getNumber("totalSevProcCanceled").toBigInteger();
						wTotalNbrCollProcCanceled = wTotalNbrCollProcCanceled.add(totCollCanceled);
						wTotalNbrSevProcCanceled = wTotalNbrSevProcCanceled.add(totSevCanceled);
						
						COTSInstanceNode errorInfo = results.getGroupFromPath("errorInformation");
						
						Bool isInError = errorInfo.getBoolean("isInError");
						if (isInError.isTrue()) {
							
							String messageText = errorInfo.getString("errorMessage");
							logError(CustomMessageRepositoryMGE.commGenericError(messageText.trim()));
							wTotalNbrRecordsProcessed--;
							wTotalNbrRecordsInErrored++;
						}						
					}					
				}	
			}
			catch (FileNotFoundException fe) {
				fe.printStackTrace();				
				addError(CustomMessageRepositoryMGE.commFileError(fe.getMessage()));
			}	
			catch (IOException e) {
				e.printStackTrace();
				addError(CustomMessageRepositoryMGE.commFileError(e.getMessage()));
			}
			finally {
				try {
					reader.close();
				}
				catch (IOException e) {
					e.printStackTrace();
				}				
			}
			
			WorkUnitResult workUnitResult = new WorkUnitResult(true);
			workUnitResult.setUnitsProcessed(wTotalNbrRecordsProcessed);
			workUnitResult.setUnitsInError(wTotalNbrRecordsInErrored);
			return workUnitResult;
		}

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException,
				RunAbortedException {
			
			/* log result summary to the run tree*/
			logInfo(CustomMessageRepositoryMGE.sa371555Summary("Collection", wTotalNbrCollProcCanceled.toString().trim()));
			logInfo(CustomMessageRepositoryMGE.sa371555Summary("Severance", wTotalNbrSevProcCanceled.toString().trim()));
		}
	}
}
