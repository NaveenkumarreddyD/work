/**************************************************************************
* Program Name: CmProcessPendingPiggyBackFABatch
* Program Title: CmProcessPendingPiggyBackFABatch
* Author: Joshua Ace Vitug
* Creation Date: 2018-06-06
* Purpose: This Batch Job processes pending piggyback FAs whose
*          Booking Appointment Characteristic is set to Y
* Functional Spec: CCB-CC-025-2B
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  CCB-CC-025-2B     JVitug/LBallo    2018-06-06    Initial Version. 
 *  CCB v2.6 Upgrade  SRomano    	   2018-12-07    Modified the logic of for creating
 *  												 To Do Message.                                                                                                                                                                                                                                                                            
 ************************************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.Iterator;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.outboundMessage.outboundMessageType.OutboundMessageType;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.workflow.notificationExternalId.NotificationExternalId;
import com.splwg.base.domain.workflow.notificationExternalId.OutboundMessageProfile_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.domain.admin.dispatchGroup.entity.DispatchGroup;
import com.splwg.ccb.domain.admin.dispatchGroupAppointmentSchedule.entity.DispatchGroupAppointmentSchedule;
import com.splwg.ccb.domain.admin.fieldActivityCancelReason.entity.FieldActivityCancelReason;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCancelProcessor;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCancelProcessorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

/**
 * @author JVitug/LBallon
 *
 @BatchJob (rerunnable = false, modules = {} ,
 *      softParameters = { @BatchJobSoftParameter (name = maxPollingTime, type = integer)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = piggyBackErrorToDoType, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = notificationExternalId, name = externalSystem, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = outboundMessageType, name = retrieveSlotsOutboundMsgType, type = entity)
 *            , @BatchJobSoftParameter (entityName = outboundMessageType, name = bookAppointOutboundMsgType, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = bookingCharType, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = fieldActivityCancelReason, name = faCancelReason, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = dispatchGroup, name = g4DispatchGroup, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = origFACharType, required = true, type = entity)})
 */
public class CmProcessPendingPiggyBackFABatch extends CmProcessPendingPiggyBackFABatch_Gen {

    //Batch Parameters
    private BigInteger maxPollingTime;
    private ToDoType piggyBackErrorToDoType;
    private NotificationExternalId externalSystem;
    private OutboundMessageType retrieveSlotsOutboundMessageType;
    private CharacteristicType bookingCharType;
	private OutboundMessageType bookAppointmentOutboundMessageType;
    private FieldActivityCancelReason faCanRsn;
    private DispatchGroup g4DispatchGroup;
    private CharacteristicType originalFaCharType;
    
    @Override
    public void validateSoftParameters(boolean isNewRun) {
        maxPollingTime = getParameters().getMaxPollingTime();
        piggyBackErrorToDoType = getParameters().getPiggyBackErrorToDoType();
        externalSystem = getParameters().getExternalSystem();
        retrieveSlotsOutboundMessageType = getParameters().getRetrieveSlotsOutboundMsgType();
        bookAppointmentOutboundMessageType = getParameters().getBookAppointOutboundMsgType();
        bookingCharType = getParameters().getBookingCharType();
        faCanRsn = getParameters().getFaCancelReason();
        g4DispatchGroup = getParameters().getG4DispatchGroup();
        originalFaCharType = getParameters().getOrigFACharType();
        
        // Validate Characteristic Entities of the Characteristic Types
        CharacteristicEntity_Id charEntityId1 = new CharacteristicEntity_Id(bookingCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY);        
        if (isNull(charEntityId1.getEntity())) {
            addError(CustomMessageRepository.CCB_CC_025_2B_bookingCharTypeIsInvalidForEntity(bookingCharType.getId().getTrimmedValue()
            		, CharacteristicEntityLookup.constants.FIELD_ACTIVITY.getLookupValue().fetchLanguageDescription()));
        }
        
        CharacteristicEntity_Id charEntityId2 = new CharacteristicEntity_Id(originalFaCharType, CharacteristicEntityLookup.constants.FIELD_ACTIVITY);        
        if (isNull(charEntityId2.getEntity())) {
            addError(CustomMessageRepository.CCB_CC_025_2B_originalFaCharTyppeInvalidEntity(originalFaCharType.getId().getTrimmedValue()
            		, CharacteristicEntityLookup.constants.FIELD_ACTIVITY.getLookupValue().fetchLanguageDescription()));
        }
        
        CharacteristicEntity_Id charEntityId3 = new CharacteristicEntity_Id(originalFaCharType, CharacteristicEntityLookup.constants.TO_DO_ENTRY);        
        if (isNull(charEntityId3.getEntity())) {
            addError(CustomMessageRepository.CCB_CC_025_2B_originalFaCharTyppeInvalidEntity(originalFaCharType.getId().getTrimmedValue()
            		, CharacteristicEntityLookup.constants.TO_DO_ENTRY.getLookupValue().fetchLanguageDescription()));
        }
        
        // Validate External System and Outbound Message Types
        OutboundMessageProfile_Id retSlotsOutMsgProfileId = new OutboundMessageProfile_Id(retrieveSlotsOutboundMessageType, externalSystem);
        if (isNull(retSlotsOutMsgProfileId.getEntity())) {
        	addError(CustomMessageRepository.CCB_CC_025_2B_outboundMesageInvalidForExternalSystem(retrieveSlotsOutboundMessageType.getId().getTrimmedValue()
        			, externalSystem.getId().getTrimmedValue()));
        }
        
        OutboundMessageProfile_Id bookApptOutMsgProfileId = new OutboundMessageProfile_Id(bookAppointmentOutboundMessageType, externalSystem);
        if (isNull(bookApptOutMsgProfileId.getEntity())) {
        	addError(CustomMessageRepository.CCB_CC_025_2B_outboundMesageInvalidForExternalSystem(bookAppointmentOutboundMessageType.getId().getTrimmedValue()
        			, externalSystem.getId().getTrimmedValue()));
        }
        
    }
    
    public JobWork getJobWork() {
        
        StringBuilder stringBuilder = new StringBuilder();              
        stringBuilder.append("SELECT FA.FA_ID ");
        stringBuilder.append("FROM CI_FA FA, ");
        stringBuilder.append(     "CI_FA_CHAR FACHAR ");
        stringBuilder.append("WHERE FA.FA_STATUS_FLG = :pendingStatus ");
        stringBuilder.append(  "AND FA.FA_ID = FACHAR.FA_ID ");
        stringBuilder.append(  "AND FACHAR.CHAR_TYPE_CD = :needsBookingCharType ");
        stringBuilder.append(  "AND FACHAR.CHAR_VAL = 'Y' ");

        PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        prepState.bindLookup("pendingStatus", FieldActivityStatusLookup.constants.PENDING);
        prepState.bindEntity("needsBookingCharType" , bookingCharType);
        QueryIterator queryIter = prepState.iterate();
        
        return createJobWorkForQueryIterator(queryIter, this);      
    }

    @Override
    public ThreadWorkUnit createWorkUnit(QueryResultRow qrw) {
        ThreadWorkUnit twu = new ThreadWorkUnit();
        FieldActivity_Id fieldActivityId = (FieldActivity_Id) qrw.getId("FA_ID", FieldActivity.class); 
        twu.setPrimaryId(fieldActivityId);
        return twu;
    }

    public Class<CmProcessPendingPiggyBackFABatchWorker> getThreadWorkerClass() {
        return CmProcessPendingPiggyBackFABatchWorker.class;
    }

    public static class CmProcessPendingPiggyBackFABatchWorker extends
        CmProcessPendingPiggyBackFABatchWorker_Gen {
        
        //Batch Parameters
        private BigInteger maxPollingTime;
        private NotificationExternalId externalSystem;
        private OutboundMessageType retrieveSlotsOutboundMessageType;
        private OutboundMessageType bookAppointmentOutboundMessageType;
        private CharacteristicType bookingCharType;
        private FieldActivityCancelReason faCanRsn;
        private DispatchGroup g4DispatchGroup;
        private CharacteristicType originalFaCharType;
        
        // Work variables
        private DispatchGroupAppointmentSchedule origFaAppSched = null;
        private String appointmentStartDateTimeStr = "";
        private String appointmentEndDateTimeStr = "";
        private FieldActivity originalFA;
        private DateFormat df = new DateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        
        //Constants
        private final String N_CHAR_VALUE = "N";
        private final String ZERO_STRING = "0";
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

        @Override
        public void initializeThreadWork(
                boolean initializationPreviouslySuccessful)
                throws ThreadAbortedException, RunAbortedException {
            
            maxPollingTime = getParameters().getMaxPollingTime();
            externalSystem = getParameters().getExternalSystem();
            retrieveSlotsOutboundMessageType = getParameters().getRetrieveSlotsOutboundMsgType();
            bookAppointmentOutboundMessageType = getParameters().getBookAppointOutboundMsgType();     
            bookingCharType = getParameters().getBookingCharType();
            faCanRsn = getParameters().getFaCancelReason();
            g4DispatchGroup = getParameters().getG4DispatchGroup();
            originalFaCharType = getParameters().getOrigFACharType();
        }
        
        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {            
            
            // Retrieve piggyBack FA to be processed from jobwork
            FieldActivity_Id piggyBackFaId = (FieldActivity_Id) unit.getPrimaryId();
            FieldActivity piggybackFA = piggyBackFaId.getEntity();
            
            FieldActivity_Id originalFaId = getOriginalFA(piggyBackFaId);
            
            if(notNull(originalFaId)){
            	
            	originalFA = originalFaId.getEntity();
            	
            	// If Original FA does not have, appointment schedule, skip FA
            	if (notNull(originalFA.getAppointmentScheduleId())) {
            		
            		// Update the characteristic Value for CMBOOKPG to 'N'
            		ListFilter<FieldActivityCharacteristic> faCharFilter =  piggybackFA.getCharacteristics().createFilter(
            				" where this.id.characteristicType = :charType ", getClass().getName());
            		faCharFilter.bindEntity("charType", bookingCharType);
            		updateFAChar(faCharFilter.iterate().next(), bookingCharType, N_CHAR_VALUE);
            		
            		// If originalFA is not in pending status, cancel the piggyback FA
            		if(!originalFA.getFieldActivityStatus().isPending()){
            			try {
            				FieldActivityCancelProcessorData fieldActivityCancelProcessorData = FieldActivityCancelProcessorData.Factory.newInstance();
            				fieldActivityCancelProcessorData.setFieldActivity(piggybackFA);
            				fieldActivityCancelProcessorData.setCancelReason(faCanRsn);
            				
            				FieldActivityCancelProcessor fieldActivityCancelProcessor = FieldActivityCancelProcessor.Factory.newInstance();
            				fieldActivityCancelProcessor.cancel(fieldActivityCancelProcessorData);
            			} catch(ApplicationError e){
            				createToDo(piggybackFA, e.getServerMessage());
            			}
            			
            			// FA is in pending status
            		} else if (originalFA.getFieldActivityStatus().isPending()) {
            			
            			// Update the dispatch group to G4
            			FieldActivity_DTO faDto = piggybackFA.getDTO();
            			faDto.setDispatchGroupId(g4DispatchGroup.getId());
            			piggybackFA.setDTO(faDto);
            			
            			//Poll for the external Id until max timeout parameter is reached
            			Long startTime = System.currentTimeMillis(); // Get current time
            			Long maxPollingTimeInMilliseconds = maxPollingTime.longValue() * 1000;
            			Bool shouldProceed = Bool.FALSE;
            			
            			// Loop until External Id has value or max polling time is reached
            			while(shouldProceed.isFalse() && (System.currentTimeMillis() - startTime) < maxPollingTimeInMilliseconds) {
            				
            				if (notNull(piggybackFA.getExternalId())) {
            					shouldProceed = Bool.TRUE;
            				}
            			}
            			
            			if(shouldProceed.isFalse()){
            				createToDo(piggybackFA, CustomMessageRepository.CCB_CC_025_2B_maxPollTimeReached(maxPollingTime.toString(), piggyBackFaId.getTrimmedValue()));
            			} else {
            				
            				try {
            					
            					// Call Retrieve Appointment Slots Outbound Message
            					BusinessObjectInstance retrieveAppointmentSlotsrequestBo = null;
            					
            					BusinessObjectInstance retrieveAppointmentSlotsOutMessage = BusinessObjectInstance.create(retrieveSlotsOutboundMessageType.getBusinessObject());
            					retrieveAppointmentSlotsOutMessage.set("externalSystem", externalSystem.getId().getIdValue());
            					retrieveAppointmentSlotsOutMessage.set("outboundMessageType", retrieveSlotsOutboundMessageType.getId().getIdValue());
            					retrieveAppointmentSlotsOutMessage.set("creationDateTime", getProcessDateTime());
            					
            					origFaAppSched = originalFA.getAppointmentScheduleId().getEntity();
            					
            					COTSInstanceNode g4AppReqDetails = retrieveAppointmentSlotsOutMessage.getGroup("G4AppReqDetails");
            					g4AppReqDetails.set("fa_id", piggyBackFaId.getTrimmedValue());
            					g4AppReqDetails.set("appt_on_around_dt", df.format(origFaAppSched.getStartDateTime()));
            					g4AppReqDetails.set("disp_grp_cd", g4DispatchGroup.getId().getTrimmedValue());
            					
            					retrieveAppointmentSlotsrequestBo = BusinessObjectDispatcher.add(retrieveAppointmentSlotsOutMessage);
            					
            					COTSInstanceNode responseDetailsGroup = retrieveAppointmentSlotsrequestBo.getGroup("G4AppRespDetails");
            					COTSInstanceList timeSlotList = responseDetailsGroup.getList("TimeSlotsList");
            					
            					Iterator<COTSInstanceListNode> cotsInstanceListIterator = timeSlotList.iterator();
            					
            					Bool isAppointmentAvailable = Bool.FALSE;
            					
            					// Find an appointment time slot with the same start and  date time as the appointment schedule of the Original FA
            					while (cotsInstanceListIterator.hasNext()) {
            						
            						COTSInstanceListNode responseListNode = cotsInstanceListIterator.next();
            						appointmentStartDateTimeStr = responseListNode.getString("start_dttm");
            						appointmentEndDateTimeStr = responseListNode.getString("end_dttm");
            						
            						if (df.format(origFaAppSched.getStartDateTime()).compareTo(appointmentStartDateTimeStr) == 0
            								&& df.format(origFaAppSched.getEndDateTime()).compareTo(appointmentEndDateTimeStr) == 0) {
            							isAppointmentAvailable = Bool.TRUE;
            						}
            					}
            					
            					// If appointment is available, call the book appointment outbound message
            					if (isAppointmentAvailable.isTrue()) {
            						
            						BusinessObjectInstance bookAppointmentRequestBo = null;
            						
            						BusinessObjectInstance bookAppointmentOutMessage = BusinessObjectInstance.create(bookAppointmentOutboundMessageType.getBusinessObject());
            						bookAppointmentOutMessage.set("externalSystem", externalSystem.getId().getIdValue());
            						bookAppointmentOutMessage.set("outboundMessageType", bookAppointmentOutboundMessageType.getId().getIdValue());
            						bookAppointmentOutMessage.set("creationDateTime", getProcessDateTime());
            						
            						COTSInstanceNode g4AppBookReqDetails = bookAppointmentOutMessage.getGroup("G4AppBookReqDetails");
            						g4AppBookReqDetails.set("fa_id", piggyBackFaId.getTrimmedValue());
            						g4AppBookReqDetails.set("dateFrom", appointmentStartDateTimeStr);
            						g4AppBookReqDetails.set("dateTo", appointmentEndDateTimeStr);
            						g4AppBookReqDetails.set("disp_grp_cd", g4DispatchGroup.getId().getTrimmedValue());
            						g4AppBookReqDetails.set("userid", getActiveContextUser().getId().getTrimmedValue());
            						
            						bookAppointmentRequestBo = BusinessObjectDispatcher.add(bookAppointmentOutMessage);
            						
            						// Retrieve response details
            						COTSInstanceNode bookAppointmentResponseGroup = bookAppointmentRequestBo.getGroup("G4AppBookRespDetails");
            						String responseCode = bookAppointmentResponseGroup.getString("ResponseCode");
            						
            						// If booking is successful, set piggyback FA appointment schedule same as original FA
            						if (ZERO_STRING.compareTo(responseCode.trim()) == 0) {
            							FieldActivity_DTO faDto2 = piggybackFA.getDTO();
            							faDto2.setAppointmentScheduleId(originalFA.getAppointmentScheduleId());
            							piggybackFA.setDTO(faDto2);
            						} else {
            							createToDo(piggybackFA, CustomMessageRepository.CCB_CC_025_2B_bookingFailed());
            						}
            						
            						// No appointment time slot found 	
            					} else {
            						createToDo(piggybackFA, CustomMessageRepository
            								.CCB_CC_025_2B_noAppointmentSlotsAvailable(
            										appointmentStartDateTimeStr
            										, appointmentEndDateTimeStr
            										, origFaAppSched.getId().getTrimmedValue()));
            					}
            				} catch (ApplicationError e) {
            					createToDo(piggybackFA, e.getServerMessage());
            				}
            			}
            		}
            	}
            	
            } else {
                createToDo(piggybackFA, CustomMessageRepository.CCB_CC_025_2B_noOriginalFA(piggyBackFaId.getTrimmedValue()));
            }
            
            return true;
        }
        
        /**
         * Retrieve the Original FA of the Piggyback FA
         * @param faId
         * @return
         */
        private FieldActivity_Id getOriginalFA(FieldActivity_Id faId){
            FieldActivity_Id returnValue = null;
            SQLResultRow results;
            CharacteristicType_Id originalFACharTypeId = originalFaCharType.getId();
            
            StringBuilder stringGetOriginalFA = new StringBuilder();
            PreparedStatement sqlGetOriginalFA = null;
            
            stringGetOriginalFA.append("SELECT ");
            stringGetOriginalFA.append(  "FA.CHAR_VAL_FK1 ");
            stringGetOriginalFA.append("FROM ");
            stringGetOriginalFA.append(  "CI_FA_CHAR FA ");
            stringGetOriginalFA.append("WHERE ");
            stringGetOriginalFA.append(  "FA.FA_ID = :faId ");
            stringGetOriginalFA.append(  "AND FA.CHAR_TYPE_CD = :originalFACharType ");
            
            sqlGetOriginalFA = createPreparedStatement(stringGetOriginalFA.toString() , this.getClass().getName());
            sqlGetOriginalFA.bindId("faId", faId);
            sqlGetOriginalFA.bindId("originalFACharType" , originalFACharTypeId);
            
            results = sqlGetOriginalFA.firstRow();
            
            if(notNull(results)){
                returnValue = (FieldActivity_Id) results.getId("CHAR_VAL_FK1", FieldActivity.class);
            }
            
            sqlGetOriginalFA.close();
            return returnValue;
        }
        
        /**
         * Update FA Characteristics
         * @param faChar
         * @param charType
         * @param charValue
         */
        private void updateFAChar(FieldActivityCharacteristic faChar, CharacteristicType charType, String charValue) {
        	
        	FieldActivityCharacteristic_DTO facharDto = faChar.getDTO();
        	CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
        	
        	if(charTypeLookup.isPredefinedValue()) {
        		facharDto.setCharacteristicValue(charValue);
        	} else if (charTypeLookup.isAdhocValue()) {
        		facharDto.setAdhocCharacteristicValue(charValue);
        	} else if (charTypeLookup.isForeignKeyValue()) {
        		facharDto.setCharacteristicValueForeignKey1(charValue);
        	}
        	
        	faChar.setDTO(facharDto);
        }
        
        private void createToDo(FieldActivity fa, ServerMessage errorMessage) {
        	
        	ToDoType toDoType = getParameters().getPiggyBackErrorToDoType();
        	
        	ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
        	ToDoEntry_DTO toDoEntryDto = createDTO(ToDoEntry.class);
        	
        	toDoEntryDto.setToDoTypeId(toDoType.getId());
        	toDoEntryDto.setCreationDateTime(getProcessDateTime());
        	toDoEntryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
        	toDoEntryDto.setMessageId(errorMessage.getMessageId());
        	
        	toDoCreator.setToDoDTO(toDoEntryDto);
        	
        	// 2018-12-07. SRomano. v2.4 to v2.6. Start Change
        	// Set To Do Entry message parameters
        	for(Iterator<Object> iter = errorMessage.getMessageParameters().iterator(); iter.hasNext();){
				toDoCreator.addMessageParameter(iter.next().toString());
			}	
        	
//        	// Set To Do Entry message parameters
//        	if (errorMessage.isSimilarTo(CustomMessageRepository.CCB_CC_025_2B_maxPollTimeReached(maxPollingTime.toString()
//        			, fa.getId().getTrimmedValue()))) {
//        		toDoCreator.addMessageParameter(maxPollingTime.toString());
//        		toDoCreator.addMessageParameter(fa.getId().getTrimmedValue());
//        	} else if (errorMessage.isSimilarTo(CustomMessageRepository.CCB_CC_025_2B_noAppointmentSlotsAvailable(appointmentStartDateTimeStr
//        			, appointmentEndDateTimeStr
//        			, origFaAppSched.getId().getTrimmedValue()))) {
//        		toDoCreator.addMessageParameter(appointmentStartDateTimeStr);
//        		toDoCreator.addMessageParameter(appointmentEndDateTimeStr);
//        		toDoCreator.addMessageParameter(origFaAppSched.getId().getTrimmedValue());
//        	} else if (errorMessage.isSimilarTo(CustomMessageRepository.CCB_CC_025_2B_noCMBOOKGPGCharType(fa.getId().getTrimmedValue()))) {
//        		toDoCreator.addMessageParameter(fa.getId().getTrimmedValue());
//        	} else if (errorMessage.isSimilarTo(CustomMessageRepository.CCB_CC_025_2B_noOriginalFA(fa.getId().getTrimmedValue()))) {
//        		toDoCreator.addMessageParameter(fa.getId().getTrimmedValue());
//        	}
        	
        	// 2018-12-07. SRomano. v2.4 to v2.6. End Change
        	
        	// Add drill key
        	for (ToDoDrillKeyType toDoDrillKeyType : toDoType.getDrillKeyTypes()) {
        		toDoCreator.addDrillKeyValue(toDoDrillKeyType, fa.getId().getTrimmedValue());
        	}
        	
        	// Add Sort Key
        	for (ToDoSortKeyType toDoSortKeyType : toDoType.getSortKeyTypes()) {
        		toDoCreator.addSortKeyValue(toDoSortKeyType, fa.getId().getTrimmedValue());
        	}
        	
        	ToDoEntry toDoEntry = toDoCreator.create();
        	
        	// Add To Do Characteristics
        	if (!errorMessage.isSimilarTo(CustomMessageRepository.CCB_CC_025_2B_noOriginalFA(fa.getId().getTrimmedValue()))) {
        		ToDoEntryCharacteristic_Id tdEntryCharId = new ToDoEntryCharacteristic_Id(toDoEntry, originalFaCharType, BigInteger.ONE);
        		ToDoEntryCharacteristic_DTO tdEntryCharDto = createDTO(ToDoEntryCharacteristic.class);
        		tdEntryCharDto.setCharacteristicValueForeignKey1(originalFA.getId().getTrimmedValue());
        		tdEntryCharDto.setId(tdEntryCharId);
        		toDoEntry.getCharacteristics().add(tdEntryCharDto.newEntity());
        	}
        }
    }
}
 