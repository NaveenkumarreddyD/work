/*
 * *************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This new batch will identify service points that need a read from ADDP 
 * based on their route type and the open bill cycle window(s). The batch 
 * will then make calls to ADDP (via SOA) to retrieve the reading information 
 * and create the meter reads in CCB so they can be used for billing. 
 * Reads that fail the high / low validation will be marked for review 
 * so they can be processed by TD-HILO.
 * 
 * The batch process should be multi-threaded and restartable, not rerunnable.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2023-02-27   JVitug          CCB219.6 Initial Version.             
 * 2023-03-28   Kiran           Call the Service script to get the ADDP Readings 
 * 2023-12-06	CAtilano		E-07870. Update ADDP call to send requests using as readStartDate start of bill cycle window
 * 								and as readEndDate the current process date. Skip accounts that have been billed in current cycle.
 * 2024-01-11   CAtilano		D-03572. Read should be posted with the Date coming from ADDP      
 * 2024-03-19   Kiran			B-31949 Exclude Route types from batch parameter     
 **************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.dom4j.Element;
import org.dom4j.io.DOMReader;
import org.w3c.dom.Document;
import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.XML;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.datatypes.Time;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.lookup.OutboundMessageProcessingMethodLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.serviceScript.ServiceScriptDispatcher;
import com.splwg.base.api.serviceScript.ServiceScriptInstance;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.outboundMessage.outboundMessage.OutboundMessage;
import com.splwg.base.domain.outboundMessage.outboundMessage.OutboundMessage_Id;
import com.splwg.base.domain.outboundMessage.outboundMessageType.OutboundMessageType;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.ccb.api.lookup.BillStatusLookup;
import com.splwg.ccb.api.lookup.ReadTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType;
import com.splwg.ccb.domain.admin.meterReadSource.entity.MeterReadSource;
import com.splwg.ccb.domain.admin.meterReadSource.entity.MeterReadSource_Id;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.data.MeterReadCreatorData;
import com.splwg.ccb.domain.meterread.data.MeterReadCreatorRegisterReadData;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead_DTO;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;


/**
 * @author jvitug
 *
 @BatchJob (rerunnable = false, modules = {}, 
 *      softParameters = { @BatchJobSoftParameter (name = MAX-ERRORS, type = integer)
 *            , @BatchJobSoftParameter (entityName = meterReadRouteType, name = ADDP_MR_RTE_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = ADDP_READ_TIME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = TO_DO_DAYS, type = integer)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = TO_DO_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = businessObject, name = ADDP_BUS_OBJ, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = outboundMessageType, name = ADDP_OUT_MSG_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = unitOfMeasure, name = CCFC_UOM, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = unitOfMeasure, name = MCFC_UOM, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = serviceType, name = SVC_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = MTR_CONFIG_TYPE_CD, required = true, type = string)
 *            , @BatchJobSoftParameter (name = ignoreBilling, required = true, type = string)})
 */

public class CmRetrieveADDPReadsForBilling_BatchProcess extends
	CmRetrieveADDPReadsForBilling_BatchProcess_Gen {
    
    private MeterReadRouteType parmAddpRouteType;
    private String parmADDPReadTime;
    private BigInteger parmToDoDays;
    private ToDoType parmToDoType;
    private BusinessObject addpBusObj; 
    private OutboundMessageType addpOutboundMessageType;
    private UnitOfMeasure ccfc;
    private UnitOfMeasure mcfc;
    private ServiceType gasServiceType;
    private String mtrConfigType;
    private String ignoreBilling;
    private static final Logger logger= LoggerFactory.getLogger(CmRetrieveADDPReadsForBilling_BatchProcess.class);  
    
    
    // Constant Variables
    private static final String COMMA = ",";
    private static final String SINGLE_QUOTE = "'";

    
    private static final String CM_ADDPREAD="CM-ADDP";
	private static final String GROUP_INPUT = "input";
	private static final String GROUP_OUTPUT = "output";
	private static final String NO_CONTENT_RESPONSE = "No Content";
	private static String mrSourceStr  = "ADDP";
    public JobWork getJobWork() {
    	
    	String mtrConfigTypeExcl = createStringForQuery(mtrConfigType).trim();
    	
    	StringBuilder stringSql = new StringBuilder();
    	
    	stringSql.append("SELECT ");
    	stringSql.append(	"SP.SP_ID, ");
    	stringSql.append(	"CFG.MTR_ID, ");
    	stringSql.append(	"CFG.MTR_CONFIG_ID, ");
    	stringSql.append(	"SCH.WIN_START_DT, ");
    	stringSql.append(	"SCH.WIN_END_DT ");
    	stringSql.append("FROM ");
    	stringSql.append(	"CI_BILL_CYC_SCH SCH , "); 
    	stringSql.append(	"CI_MR_CYC MCY, ");
    	stringSql.append(	"CI_SP_MTR_HIST SPH, ");
    	stringSql.append(	"CI_MTR_CONFIG CFG, ");
    	stringSql.append(	"CI_SP SP ");
    	stringSql.append("WHERE ");
    	stringSql.append(	":processDate BETWEEN SCH.WIN_START_DT AND SCH.WIN_END_DT ");
    	stringSql.append("AND ");
    	stringSql.append(	"SCH.BILL_CYC_CD = MCY.BILL_CYC_CD ");
    	stringSql.append("AND "); 
    	stringSql.append(	"MCY.MR_CYC_CD = SP.MR_CYC_CD ");
    	stringSql.append("AND ");
    	stringSql.append(	"SP.MR_RTE_CD IN ( ");
    	stringSql.append(      "SELECT ");
    	stringSql.append(         "RTE.MR_RTE_CD ");
    	stringSql.append(      "FROM ");
    	stringSql.append(         "CI_MR_RTE RTE ");
    	stringSql.append(      "WHERE ");
    	stringSql.append(         "RTE.MR_RTE_TYPE_CD = :routeType ");
    	stringSql.append(") ");
    	stringSql.append("AND "); 
    	stringSql.append(	"SP.SP_ID = SPH.SP_ID ");
    	stringSql.append("AND ");
    	stringSql.append(	"SPH.REMOVAL_MR_ID = ' ' ");
    	stringSql.append("AND NOT EXISTS ( ");
    	stringSql.append(	"SELECT ");
    	stringSql.append(		"'X' ");
    	stringSql.append(	"FROM ");
    	stringSql.append(		"CI_MR MR ");
    	stringSql.append(	"WHERE ");
    	stringSql.append(		"MR.MTR_CONFIG_ID = SPH.MTR_CONFIG_ID ");
    	stringSql.append(	"AND ");
    	stringSql.append(		"TRUNC(MR.READ_DTTM) BETWEEN SCH.WIN_START_DT AND SCH.WIN_END_DT ");
    	stringSql.append(	"AND ");
    	stringSql.append(		"MR.USE_ON_BILL_SW = :yes ");
    	stringSql.append(") ");
    	stringSql.append("AND ");
    	stringSql.append(	"SPH.MTR_CONFIG_ID = CFG.MTR_CONFIG_ID ");
    	stringSql.append("AND CFG.MTR_CONFIG_TY_CD NOT IN (" + mtrConfigTypeExcl + ") ");
    	
    	

        PreparedStatement getSPsForADDPReadsRetrieval = createPreparedStatement(stringSql.toString(), getClass().getName());
        getSPsForADDPReadsRetrieval.bindDate("processDate", getProcessDateTime().getDate());
        getSPsForADDPReadsRetrieval.bindId("routeType", parmAddpRouteType.getId());
        getSPsForADDPReadsRetrieval.bindBoolean("yes", Bool.TRUE);
        
        // Build Worklist
        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
            
        QueryIterator<SQLResultRow> iter = getSPsForADDPReadsRetrieval.iterate();
        while (iter.hasNext()) {
            SQLResultRow row = iter.next();
            
            ThreadWorkUnit workUnit = new ThreadWorkUnit();
            workUnit.setPrimaryId((ServicePoint_Id) row.getId("SP_ID", ServicePoint.class));
            workUnit.addSupplementalData("MTR_ID", row.getId("MTR_ID", Meter.class));
            workUnit.addSupplementalData("WIN_START_DT", row.getDate("WIN_START_DT"));
            workUnit.addSupplementalData("WIN_END_DT", row.getDate("WIN_END_DT")); 
            workUnit.addSupplementalData("MTR_CONFIG_ID", row.getId("MTR_CONFIG_ID", MeterConfiguration.class)); 
          
            workUnits.add(workUnit);              
        }
        iter.close();  
        getSPsForADDPReadsRetrieval.close();
        
        return createJobWorkForThreadWorkUnitList(workUnits); 
    }

    /**
 * This method builds the String for query.
 * @param comma-delimited string
 * @return comma-delimited string with quote
 */
private String createStringForQuery(String string) {
    StringBuilder strBuilder = new StringBuilder();
    String [] tempList;
    tempList = string.split(COMMA);
    for(int ctr = 0; ctr<tempList.length; ctr++){
        if(ctr > 0){
            strBuilder.append(COMMA);
        }
        strBuilder.append(SINGLE_QUOTE);
        strBuilder.append(tempList[ctr].trim());
        strBuilder.append(SINGLE_QUOTE);
    }
    return strBuilder.toString();
}
    /**
     * This method checks if all required Soft Parameters were populated,
     * and all optional Soft Parameters (if populated) are valid.
     * 
     * @param isNewRun - a boolean value
     */
    public void validateSoftParameters(boolean isNewRun){
    	parmAddpRouteType = getParameters().getADDP_MR_RTE_TYPE_CD();
        parmADDPReadTime = getParameters().getADDP_READ_TIME();
        parmToDoDays = getParameters().getTO_DO_DAYS();
        parmToDoType = getParameters().getTO_DO_TYPE();
        addpBusObj = getParameters().getADDP_BUS_OBJ();
        addpOutboundMessageType = getParameters().getADDP_OUT_MSG_TYPE();
        ccfc = getParameters().getCCFC_UOM();
        mcfc = getParameters().getMCFC_UOM();
        gasServiceType = getParameters().getSVC_TYPE_CD();
        mtrConfigType = getParameters().getMTR_CONFIG_TYPE_CD();
        ignoreBilling = getParameters().getIgnoreBilling();
        if(notNull(parmToDoDays)) {
        	//If parm To Do Days is supplied, check if the value is between 0 and 5 
        	if(parmToDoDays.compareTo(BigInteger.ZERO) < 0 || parmToDoDays.compareTo(new BigInteger("5")) > 0) {
        		addError(CustomMessageRepository.CCB219_6_invalidNumTodoDays(parmToDoDays.toString()));
        	}
        }
        
        //Validate the Time Parameter
        Time validator = null;
        try {
			validator = Time.fromString(parmADDPReadTime, new DateFormat("HH:mm"));
		} catch (DateFormatParseException e) {
				addError(CustomMessageRepository.CCB219_6_invalidTime(parmADDPReadTime));
		}
    } 

    

    public Class<CmRetrieveADDPReadsForBilling_BatchProcessWorker> getThreadWorkerClass() {
        return CmRetrieveADDPReadsForBilling_BatchProcessWorker.class;
    }

    public static class CmRetrieveADDPReadsForBilling_BatchProcessWorker
    extends CmRetrieveADDPReadsForBilling_BatchProcessWorker_Gen {

        // Soft Parameters
    	private MeterReadRouteType parmAddpRouteType;
        private String parmADDPReadTime;
        private BigInteger parmToDoDays;
        private ToDoType parmToDoType;
        private String mtrConfigType;
        private String ignoreBilling;
        
        //Working Variables
        ServicePoint sp;
        Meter meter;
        Date billCycleEndDate;
        Date billCycleStartDate;
        BusinessObject ADDPBusinessObject = null;
        OutboundMessageType addpOutMsgType = null;
        String CM_ADDP = "CM-ADDP";
        BusinessObjectInstance addpReadOutboundMessageInput = null; 
        BusinessObjectInstance addpReadOutboundMessageOutput = null;
        MeterConfiguration_Id meterConfigId;
        UnitOfMeasure ccfc = null;
        UnitOfMeasure mcfc = null;
        ServiceType gas = null;
        Time readTime = Time.MIN;
        DateFormat format24Hour = new DateFormat("HH:mm"); 
        DateFormat dateTimeFormat = new DateFormat("yyyy-MM-dd"); 
        ServiceScriptInstance serviceScriptInstance = null;
        
        //Constants
        private final String RESPONSE = "Response";
        private final String READ_TYPE= "readType";
        private final String BYPASS_HILO_REVIEW = "bypassHiLoReview";
        private final String CORRECTED_INDEX = "correctedIndex";
        private final String ERROR_MSG = "errorMessage";
        private static final String MTRCONFIG_ID = "C1_T_MTR_CONFIG_ID";
        
        //For record counting , which will be displayed after batch run
        private BigInteger numberOfTodosCreated = BigInteger.ZERO;
		private BigInteger numberOfSPsWithNoADDPRead = BigInteger.ZERO;
		private BigInteger numberOfMeterReadCreated = BigInteger.ZERO;
		private BigInteger numberOfMeterReadsFlaggedForHiLo = BigInteger.ZERO;
		

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

        public boolean executeWorkUnit(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {
        	
        	initializeParameters(unit);
            
            sp = ((ServicePoint_Id) unit.getPrimaryId()).getEntity();
            meter = ((Meter_Id) unit.getSupplementalId("MTR_ID")).getEntity();
            billCycleStartDate = ((Date) unit.getSupplementallData("WIN_START_DT"));
            billCycleEndDate = ((Date) unit.getSupplementallData("WIN_END_DT"));
            meterConfigId = (MeterConfiguration_Id) unit.getSupplementalId("MTR_CONFIG_ID");
            
            completeADDPToDoTypeLinkedToSp();
            
            //if account linked to Meter is already billed in cycle, skip it
            if(ignoreBilling.trim().toUpperCase().equals("FALSE"))
            {
            if(isSPbilledinCycle(billCycleStartDate))
            	return true;
            }
            //Complete any ADDP To Do Types linked to the SP 
            
            
            
            
	        //Create outbound notification to ADDP
			ServiceScriptInstance serviceScriptInstance = null;
    		COTSInstanceNode scriptInput = null;
    		COTSInstanceNode scriptOutput = null;
			serviceScriptInstance = ServiceScriptInstance.create(CM_ADDPREAD); 	
    		// Retrieve the script's input node
    		scriptInput = serviceScriptInstance.getGroup(GROUP_INPUT);
    		
    		
    		scriptInput.set("meterBadgeNumber", meter.getBadgeNumber().trim());
    		scriptInput.set("meterAssetNumber", meter.getSerialNumber().trim());
    		scriptInput.set("readDateStart",billCycleStartDate);
    		scriptInput.set("readDateEnd",getParameters().getProcessDate());
    		scriptInput.set("readTime",parmADDPReadTime.toString().trim());
    		
    		
			try{
				ServiceScriptDispatcher.invoke(serviceScriptInstance);	
			} catch (ApplicationError e){
				e.getServerMessage();
			}
			 //it can be added to the FA later if needed
			scriptOutput = serviceScriptInstance.getGroup(GROUP_OUTPUT);
			String outboundMessageId = scriptOutput.getString("outboundMsgId");
			String correctedIndexRead_str = null;
			String errorMessage = null;
			correctedIndexRead_str  = scriptOutput.getString("correctedIndex");
			errorMessage = scriptOutput.getString("errorMessage");

			

			if(errorMessage == null) {
				processADDPReadFromResponse(scriptOutput); 
			} else {
			       	logError(CustomMessageRepository.CCB219_6_noADDPReadReturned(meter.getBadgeNumber().trim()));
            	
            	//Check if we should raise a To Do. We raise a To Do when
            	// 1. parameter number of Days within Cycle is not blank or null
            	// 2. the number of days remaining in the bill cycle is less than or equal to the parameter 
            	//    number of days in the Bill Cycle
            	// 3. SP must have an associated Gas SA in an active status or in a stopped status with no final bill segment
            	if(notNull(parmToDoDays)) {
            		long numberOfDaysBeforeBillCycleEndDate = billCycleEndDate.difference(getProcessDateTime().getDate()).getDays();
            		
            		if(parmToDoDays.compareTo(BigInteger.valueOf(numberOfDaysBeforeBillCycleEndDate)) >= 0) {
            			if(isSPLinkedToActiveGasSA().isTrue() || isSPLinkedToStoppedSAWithNoFinalBill().isTrue()) {
            				createToDoEntry(meter.getBadgeNumber().trim());
            				numberOfTodosCreated = numberOfTodosCreated.add(BigInteger.ONE);
            			}
            		}
            	}
            	
            	//Add one to the count of SPs with no ADDP Read
            	numberOfSPsWithNoADDPRead = numberOfSPsWithNoADDPRead.add(BigInteger.ONE);
            }
            
            return true;
        }
        
        /**
         * This method will complete any ADDP To Do type linked to the SP
         */
        private void completeADDPToDoTypeLinkedToSp() {
        	List<SQLResultRow> addpToDoLinkedToSp = getAddpToDosLinkedToSp();
        	
        	ToDoEntry addpTodo = null;
        	for(SQLResultRow row : addpToDoLinkedToSp) {
        		addpTodo = row.getEntity("TD_ENTRY_ID", ToDoEntry.class);
        		
        		//Complete Todo
        		addpTodo.complete();
        	}
        }
        
        /**
         * This method will return a list of ADDP To Do Entries linked to the SP
         * being processed by this batch
         * @return
         */
        private List<SQLResultRow> getAddpToDosLinkedToSp() {
        	StringBuilder stringSql = new StringBuilder();
        	List<SQLResultRow> listValue = null;
        	
        	stringSql.append("SELECT ");
        	stringSql.append(   "TD.TD_ENTRY_ID ");
        	stringSql.append("FROM  ");
        	stringSql.append(   "CI_TD_ENTRY TD, ");
        	stringSql.append(   "CI_TD_DRLKEY DRL ");
        	stringSql.append("WHERE ");
        	stringSql.append(   "TD.TD_ENTRY_ID = DRL.TD_ENTRY_ID ");
        	stringSql.append("AND ");
        	stringSql.append(   "TD.TD_TYPE_CD = :todoType ");
        	stringSql.append("AND ");
        	stringSql.append(   "TD.ENTRY_STATUS_FLG = :open ");
        	stringSql.append("AND ");
        	stringSql.append(   "DRL.KEY_VALUE = :sp ");
        	
        	PreparedStatement sql = createPreparedStatement(stringSql.toString() , getClass().getName());
        	sql.bindId("todoType" ,parmToDoType.getId());
        	sql.bindLookup("open" , ToDoEntryStatusLookup.constants.OPEN);
        	sql.bindId("sp", sp.getId());
        	
        	listValue = sql.list();
        	sql.close();
        	
        	return listValue;
        }
        
        /**
         * This method will process the ADDP Response and adds a Meter Read
         * using the details from the Response.
         * @param response
         */
        private void processADDPReadFromResponse(COTSInstanceNode response) {
        	
        	String readTypeStr = response.getString(READ_TYPE).trim();
        	Bool bypassHiLoReview = null;
        	
        	if(isNull(response.getString(BYPASS_HILO_REVIEW))) {
        		bypassHiLoReview = Bool.FALSE;
        	} else {
        		bypassHiLoReview = Bool.valueOf(Boolean.parseBoolean(response.getString(BYPASS_HILO_REVIEW).trim()));
        	}
        	
        	ReadTypeLookup readTypeLookup = LookupHelper.getLookupInstance(ReadTypeLookup.class , "60");
        	String readingStr = response.getString(CORRECTED_INDEX).trim();
        	
        	MeterReadCreatorData mrCreatorData = MeterReadCreatorData.Factory.newInstance(); 
            /*
           	 * D-03572 - 2024-01-11 - Start Add
           	 */
        	String date = response.getString("timeofMeasure").substring(0,10);
        	try{
        		mrCreatorData.setReadDateTime(new DateTime(dateTimeFormat.parseDate(date), readTime));
        	}
        	catch(DateFormatParseException e){
        		addError(CustomMessageRepository.CCB219_6_invalidTime(date));
        	}
            /*
           	 * D-03572 - 2024-01-11 - End Add
           	 */
            //continue with meter read creation
            List<MeterReadCreatorRegisterReadData> mrcrrd = new ArrayList<MeterReadCreatorRegisterReadData>();

            //iterate through the registers to get the sequences to add the reads
            Iterator<Register> iterator = meterConfigId.getEntity().getRegisters().iterator();
            MeterReadCreatorRegisterReadData mrCreatorRegRead = MeterReadCreatorRegisterReadData.Factory.newInstance();
            
            while (iterator.hasNext()) {
                Register register = iterator.next();
                
                mrCreatorRegRead = MeterReadCreatorRegisterReadData.Factory.newInstance();
                
                mrCreatorRegRead.setReadSequence(register.getSeq());
                mrCreatorRegRead.setReadType(readTypeLookup);
                
                if(register.getUnitOfMeasure().getId().equals(ccfc.getId())) {
                	//If the register UOM is CCFC, remove the last two digits. 
                	if(readingStr.length() > 2) {
                		String truncatedRead = readingStr.substring(0 , readingStr.length() - 2);
                		mrCreatorRegRead.setRegisterReading(new BigDecimal(truncatedRead));
                	} else {
                		mrCreatorRegRead.setRegisterReading(new BigDecimal(readingStr));
                	}
                } else if (register.getUnitOfMeasure().getId().equals(mcfc.getId())) {
                	//If the register UOM is MCFC, remove the last three digits. 
                	//If the register UOM is CCFC, remove the last two digits. 
                	if(readingStr.length() > 3) {
                		String truncatedRead = readingStr.substring(0 , readingStr.length() - 3);
                		
                		mrCreatorRegRead.setRegisterReading(new BigDecimal(truncatedRead));
                	} else {
                		mrCreatorRegRead.setRegisterReading(new BigDecimal(readingStr));
                	}
                } else {
                	//This part is a catch all.
                	mrCreatorRegRead.setRegisterReading(new BigDecimal(readingStr));
                }
                mrCreatorRegRead.setIsHighLowReviewed(Bool.TRUE);
                mrcrrd.add(mrCreatorRegRead);
            }

            mrCreatorData.setRegisterReadDataList(mrcrrd);
            mrCreatorData.setIsInstallationRead(Bool.FALSE);
            mrCreatorData.setCanUseOnBill(Bool.TRUE);
            mrCreatorData.setServicePoint(sp);
            MeterReadSource mrSource = new MeterReadSource_Id(mrSourceStr).getEntity();
            mrCreatorData.setMeterReadSource(mrSource);
            //add meter reads to the configuration
            MeterRead meterRead = null;
            try {
            	
            	meterRead = meterConfigId.getEntity().addMeterRead(mrCreatorData);
            	
            	numberOfMeterReadCreated = numberOfMeterReadCreated.add(BigInteger.ONE);
            	checkIfMeterReadHasFailedHiLo(meterRead , bypassHiLoReview);
            	
            	
            } catch(Exception e) {
            	        	logError(CustomMessageRepository.CCB219_6_errorCreatingMeterRead(meter.getBadgeNumber()));
            	numberOfSPsWithNoADDPRead = numberOfSPsWithNoADDPRead.add(BigInteger.ONE);
            }
        }
        
        /**
         * If the Bypass HiLo Review from the ADDP Response 
         * is blank or null or if the Bypass Hilo Review is set to false, this method will
         * flag a meter read that has at least one register read that failed Hi - Lo validation 
         * @param meterRead
         * @param bypassHiLoReview 
         */
        private void checkIfMeterReadHasFailedHiLo(MeterRead meterRead, Bool bypassHiLoReview) {
        	BigDecimal hiLimit = BigDecimal.ZERO;
            BigDecimal loLimit = BigDecimal.ZERO;
            Bool wasFlaggedForHiLo = Bool.FALSE;
            
            for(RegisterRead rr : meterRead.getRegisterReads()) {
            	hiLimit = rr.getHighLimit();
            	loLimit = rr.getLowLimit();
            	
            	//If register reading is greater than the High Limit 
            	//or the register reading is less than the Lo Limit
            	//the read has failed hi-lo
            	if(hiLimit.compareTo(loLimit) >=0) {
            		if(rr.getRegisterReading().compareTo(hiLimit) > 0 || rr.getRegisterReading().compareTo(loLimit) < 0) {

            			if(isNull(bypassHiLoReview) || bypassHiLoReview.isFalse()) {
            				RegisterRead_DTO rrDto = rr.getDTO();
            				rrDto.setIsHighLowReviewed(Bool.TRUE);
            				rrDto.setExtraTCopybookFieldValue(MTRCONFIG_ID, meterConfigId.getTrimmedValue());

            				rr.setDTO(rrDto);
            				wasFlaggedForHiLo = Bool.TRUE;
            			} 
            		}
            	} else {
            		if(rr.getRegisterReading().compareTo(hiLimit) > 0 && rr.getRegisterReading().compareTo(loLimit) < 0) {
            			if(isNull(bypassHiLoReview) || bypassHiLoReview.isFalse()) {
            				RegisterRead_DTO rrDto = rr.getDTO();
            				rrDto.setIsHighLowReviewed(Bool.TRUE);
            				rrDto.setExtraTCopybookFieldValue(MTRCONFIG_ID, meterConfigId.getTrimmedValue());

            				rr.setDTO(rrDto);
            				wasFlaggedForHiLo = Bool.TRUE;
            			} 
            		}
            	}
            }
            
            if(wasFlaggedForHiLo.isTrue()) {
            	numberOfMeterReadsFlaggedForHiLo = numberOfMeterReadsFlaggedForHiLo.add(BigInteger.ONE);
            }
        }
        
        /**
         * This method will create an outbound message
         * @param badgeNumber
         */
        private OutboundMessage createOutboundMessage(String badgeNumber,String serialNumber){
        	
        	addpReadOutboundMessageInput = BusinessObjectInstance.create(ADDPBusinessObject.getId().getTrimmedValue());
        	addpReadOutboundMessageInput.set("creationDateTime", getProcessDateTime());
        	addpReadOutboundMessageInput.set("processingMethod", OutboundMessageProcessingMethodLookup.constants.REAL_TIME);
        	addpReadOutboundMessageInput.set("outboundMessageType", addpOutMsgType.getId().getTrimmedValue());
        	addpReadOutboundMessageInput.set("externalSystem" , CM_ADDP);

        	COTSInstanceNode requestDetails = addpReadOutboundMessageInput.getGroup("Request");
        	requestDetails.set("meterBadgeNumber", badgeNumber);        	
        	requestDetails.set("readDateStart", getProcessDateTime().getDate());
        	requestDetails.set("readDateEnd", getProcessDateTime().getDate());
        	requestDetails.set("readTime", parmADDPReadTime);        	
        	requestDetails.set("meterAssetNumber", serialNumber); 
        	addpReadOutboundMessageOutput = BusinessObjectDispatcher.add(addpReadOutboundMessageInput);
        	
        	String outId = addpReadOutboundMessageOutput.getString("outboundMsgId");
        	OutboundMessage outmsg = new OutboundMessage_Id(outId).getEntity();
        	
        	return outmsg;
        }
        
        /**
         * This method will return true if the SP being processed by this batch
         * is linked to an active Gas SA
         * @return
         */
        private Bool isSPLinkedToActiveGasSA() {
        	Bool returnValue = Bool.FALSE;
        	StringBuilder stringSql = new StringBuilder();
        	
        	stringSql.append("SELECT ");
        	stringSql.append(   "SA.SA_ID ");
        	stringSql.append("FROM ");
        	stringSql.append(   "CI_SA SA, ");
        	stringSql.append(   "CI_SA_TYPE SAT, ");
        	stringSql.append(   "CI_SA_SP SAPS ");
        	stringSql.append("WHERE ");
        	stringSql.append(   "SAPS.SP_ID = :spId ");
        	stringSql.append("AND ");
        	stringSql.append(   "SAPS.SA_ID = SA.SA_ID ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.SA_STATUS_FLG in (:active , :pendingStop) ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.CIS_DIVISION = SAT.CIS_DIVISION ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.SA_TYPE_CD = SAT.SA_TYPE_CD ");
        	stringSql.append("AND ");
        	stringSql.append(   "SAT.SVC_TYPE_CD = :gas ");
        	
        	PreparedStatement stmt = createPreparedStatement(stringSql.toString(), getClass().getName());
        	stmt.bindId("spId" , sp.getId());
        	stmt.bindLookup("active" , ServiceAgreementStatusLookup.constants.ACTIVE);
        	stmt.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        	stmt.bindId("gas" , gas.getId());
        	
        	SQLResultRow result = stmt.firstRow();
        	stmt.close();
        	
        	if(notNull(result)) {
        		returnValue = Bool.TRUE;
        	}
        	
        	return returnValue;
        }
        

        /**
         * This method will return true if the SP being processed by this batch
         * is linked to an active Gas SA
         * @return
         */
        private boolean isSPbilledinCycle(Date winStartDt) {
        	boolean returnValue = false;
        	StringBuilder stringSql = new StringBuilder();
        	
        	stringSql.append("SELECT ");
        	stringSql.append(   "'X' ");
        	stringSql.append("FROM ");
        	stringSql.append(   "CI_SA SA, ");
        	stringSql.append(   "CI_SA_SP SASP, ");
        	stringSql.append(   "CI_BILL B ");
        	stringSql.append("WHERE ");
        	stringSql.append(   "SASP.SP_ID = :spId ");
        	stringSql.append("AND ");
        	stringSql.append(   "SASP.SA_ID = SA.SA_ID ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.SA_STATUS_FLG in (:active , :pendingStop, :stopped) ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.ACCT_ID = B.ACCT_ID ");
        	stringSql.append("AND ");
        	stringSql.append(   "B.BILL_STAT_FLG = :complete ");
        	stringSql.append("AND ");
        	stringSql.append(   "TRUNC(B.COMPLETE_DTTM) BETWEEN :winStartDt AND :procDt ");
        	
        	PreparedStatement stmt = createPreparedStatement(stringSql.toString(), getClass().getName());
        	stmt.bindId("spId" , sp.getId());
        	stmt.bindLookup("active" , ServiceAgreementStatusLookup.constants.ACTIVE);
        	stmt.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        	stmt.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
        	stmt.bindLookup("complete", BillStatusLookup.constants.COMPLETE);
        	stmt.bindDate("winStartDt", winStartDt);
        	stmt.bindDate("procDt", getProcessDateTime().getDate());
        	
        	SQLResultRow result = stmt.firstRow();
        	stmt.close();
        	
        	if(notNull(result)) {
        		returnValue = true;
        	}
        	
        	return returnValue;
        }
        
        
        /**
         * This method will return true if the SP being processed by this batch
         * is linked to a Stopped Gas SA with no final bill
         * @return
         */
        private Bool isSPLinkedToStoppedSAWithNoFinalBill() {
        	Bool returnValue = Bool.FALSE;
        	
        	StringBuilder stringSql = new StringBuilder();
        	
        	stringSql.append("SELECT ");
        	stringSql.append(   "SA.SA_ID ");
        	stringSql.append("FROM ");
        	stringSql.append(   "CI_SA SA, ");
        	stringSql.append(   "CI_SA_TYPE SAT, ");
        	stringSql.append(   "CI_SA_SP SAPS ");
        	stringSql.append("WHERE ");
        	stringSql.append(   "SAPS.SP_ID = :spId ");
        	stringSql.append("AND ");
        	stringSql.append(   "SAPS.SA_ID = SA.SA_ID ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.SA_STATUS_FLG = :stopped ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.CIS_DIVISION = SAT.CIS_DIVISION ");
        	stringSql.append("AND ");
        	stringSql.append(   "SA.SA_TYPE_CD = SAT.SA_TYPE_CD ");
        	stringSql.append("AND ");
        	stringSql.append(   "SAT.SVC_TYPE_CD = :gas ");
        	stringSql.append("AND NOT EXISTS ( ");
        	stringSql.append(   "SELECT ");
        	stringSql.append(      "'X' ");
        	stringSql.append(   "FROM ");
        	stringSql.append(      "CI_BSEG BSEG ");
        	stringSql.append(   "WHERE ");
        	stringSql.append(      "BSEG.SA_ID = SA.SA_ID ");
        	stringSql.append(   "AND ");
        	stringSql.append(      "BSEG.CLOSING_BSEG_SW = :true ");
        	stringSql.append(") ");
        	
        	PreparedStatement stmt = createPreparedStatement(stringSql.toString(), getClass().getName());
        	stmt.bindId("spId" , sp.getId());
        	stmt.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
        	stmt.bindId("gas" , gas.getId());
        	stmt.bindBoolean("true", Bool.TRUE);
        	
        	SQLResultRow result = stmt.firstRow();
        	stmt.close();
        	
        	if(notNull(result)) {
        		returnValue = Bool.TRUE;
        	}
        	
        	return returnValue;
        }

        /**
         * This method will create a To Do Entry using the SP as both the drill key and sort key
         */
        private void createToDoEntry(String badgeNumber){
            
            ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
            ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();
                        
            toDoEntryDTO.setBatchControlId(getBatchControlId());
            toDoEntryDTO.setBatchNumber(getBatchNumber());            
            toDoEntryDTO.setCreationDateTime(getProcessDateTime());
            toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
            toDoEntryDTO.setToDoTypeId(parmToDoType.getId());
                  toDoEntryDTO.setMessageId(CustomMessageRepository.CCB219_6_noADDPReadReturned(badgeNumber).getMessageId());
                        
            toDoCreator.setToDoDTO(toDoEntryDTO);            
                 toDoCreator.addSortKeyValue(parmToDoType.getSortKeyTypes().iterator().next(), CustomMessageRepository.CCB219_6_noADDPReadReturned(badgeNumber).getNumber().toString());
            toDoCreator.addDrillKeyValue(parmToDoType.getDrillKeyTypes().iterator().next(), sp.getId().getTrimmedValue());
            
            toDoCreator.create();
        }

          /* (non-Javadoc)
           * @see com.splwg.base.api.batch.AbstractThreadWorker#initializeThreadWork(boolean)
           */
          @Override
          public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
        	  //Initialize parameter again to prevent lazy initialization error
        	  parmAddpRouteType = getParameters().getADDP_MR_RTE_TYPE_CD();
              parmADDPReadTime = getParameters().getADDP_READ_TIME();
              parmToDoDays = getParameters().getTO_DO_DAYS();
              parmToDoType = getParameters().getTO_DO_TYPE();
              ADDPBusinessObject = getParameters().getADDP_BUS_OBJ();
              addpOutMsgType = getParameters().getADDP_OUT_MSG_TYPE();
              ccfc = getParameters().getCCFC_UOM();
              mcfc = getParameters().getMCFC_UOM();
              gas = getParameters().getSVC_TYPE_CD();
              mtrConfigType = getParameters().getMTR_CONFIG_TYPE_CD();
              ignoreBilling = getParameters().getIgnoreBilling();
              logger.info("CmRetrieveADDPReadsForBilling_BatchProcess Initialize threadwork");
              try {
            	  readTime = Time.fromString(parmADDPReadTime, format24Hour);
              } catch (DateFormatParseException e) {
            	      	  addError(CustomMessageRepository.CCB219_6_invalidTime(parmADDPReadTime));
              }
          }
          
        //Initialize soft parameters
          private void initializeParameters(ThreadWorkUnit unit){
          	parmAddpRouteType = getParameters().getADDP_MR_RTE_TYPE_CD();
              parmADDPReadTime = getParameters().getADDP_READ_TIME();
              parmToDoDays = getParameters().getTO_DO_DAYS();
              parmToDoType = getParameters().getTO_DO_TYPE();  
              
              ADDPBusinessObject = getParameters().getADDP_BUS_OBJ();
              addpOutMsgType = getParameters().getADDP_OUT_MSG_TYPE();
              ccfc = getParameters().getCCFC_UOM();
              mcfc = getParameters().getMCFC_UOM();
              gas = getParameters().getSVC_TYPE_CD();
              mtrConfigType = getParameters().getMTR_CONFIG_TYPE_CD();
              ignoreBilling = getParameters().getIgnoreBilling();
          }

		@Override
		public void finalizeThreadWork() throws ThreadAbortedException,
				RunAbortedException {
					logMessage(CustomMessageRepository.CCB219_6_numberOfMeterReadsCreated(numberOfMeterReadCreated.toString()) , 
					MessageSeverityLookup.constants.INFORMATIONAL);
			
						logMessage(CustomMessageRepository.CCB219_6_numberOfMeterReadsFlaggedForHiLo(numberOfMeterReadsFlaggedForHiLo.toString()) , 
							MessageSeverityLookup.constants.INFORMATIONAL);
			
					logMessage(CustomMessageRepository.CCB219_6_numberOfSPsWithNoRead(numberOfSPsWithNoADDPRead.toString()) , 
						MessageSeverityLookup.constants.INFORMATIONAL);
			
				logMessage(CustomMessageRepository.CCB219_6_numberOfTodosCreated(numberOfTodosCreated.toString()) , 
						MessageSeverityLookup.constants.INFORMATIONAL);
		}

    }

}
