/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Voiding File Batch Extract - ACH PPD
 * Entry Detail Record
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2021-06-01   GCrisp     Initial version. CCB041.3 ACH PPD Entry Detail
 *                   	   Record
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmCheckVoidingExtractACHPpdEntryDetailRecord extends ColumnDelimitedRecord{
	
	/*
	 * Constructor
	 */
	public CmCheckVoidingExtractACHPpdEntryDetailRecord() {
		super(11);
	}

	public void setRecordTypeCode(String value) {		
		rightPadColumn(1, 1, value);
	}
	
	public void setTransactionCode(String value) {		
		rightPadColumn(2, 2, value);
	}
	
	public void setReceivingDFIIdentification(String value) {		
		rightPadColumn(3, 8, value);
	}
	
	public void setCheckDigit(String value) {		
		rightPadColumn(4, 1, value);
	}
	
	public void setDFIAccountNumber(String value) {		
		rightPadColumn(5, 17, value);
	}
	
	public void setAmount(String value) {		
		leftPadColumnWithZeros(6, 10, value);
	}
	
	public void setIndividualIdentificationNumber(String value) {		
		rightPadColumn(7, 15, value);
	}
	
	public void setIndividualName(String value) {		
		rightPadColumn(8, 22, value);
	}
	
	public void setDiscretionaryData(String value) {		
		rightPadColumn(9, 2, value);
	}
	
	public void setAddendaRecordIndicator(String value) {		
		rightPadColumn(10, 1, value);
	}
	
	public void setTraceNumber(String value) {		
		rightPadColumn(11, 15, value);
	}
	
}
