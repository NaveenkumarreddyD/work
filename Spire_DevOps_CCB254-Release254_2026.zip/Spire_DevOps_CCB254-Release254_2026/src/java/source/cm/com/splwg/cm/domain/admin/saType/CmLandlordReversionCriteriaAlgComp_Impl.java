/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Cancel Landlord reversion SA Algorithm
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2014-08-25   Rahul         IM-052517 And IM-05421 Initial Version.
 * 2014-10-01   Rahul         Removed To Do Creation step as per UAT testing by Shea S Murray
 * 2016-01-26   MPang		  Updated for CCB v2.4 compilation. 
 ******************************************************************************************/

package com.splwg.cm.domain.admin.saType;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.SaTypeSaCreationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoMaintenanceData;*/

import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import  com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saCreation.SaTypeSaCreationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.todo.common.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.data.ToDoMaintenanceData;
//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation

import com.splwg.cm.api.lookup.CmDiconnectFaLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_Id;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeSortKeyTypes;

/**
 * @author rsaran003
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = toDoType, name = landlordReversionCriterionToDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = disconnectForNonPayFeatureConfig, required = true, type = entity)})
 */
public class CmLandlordReversionCriteriaAlgComp_Impl extends CmLandlordReversionCriteriaAlgComp_Gen
implements SaTypeSaCreationAlgorithmSpot {

	//Soft Parameters
	private FeatureConfiguration parmDisconnectForNonPayFeatureConfig;
	private ToDoType parmToDoTypeForSaCancellation;
	//Hard Parameters
	private ServiceAgreement parmServiceAgreement;
	//Working Variables
	private ArrayList<String> disconnectForNonPayFaTypeList = new ArrayList<String>();
	private Premise_Id premiseId;
	private Account_Id accountId;
	private Account_Id landlordId;
	private Date startDate;
	private String lastCompletedFieldactivityType;

	public void invoke() {
		// Retrieve ToDo type for SA cancellation
		parmToDoTypeForSaCancellation = getLandlordReversionCriterionToDoType();
		// Retrieve Disconnect FA type list and validate for valid FA types
		parmDisconnectForNonPayFeatureConfig = getDisconnectForNonPayFeatureConfig();
		disconnectForNonPayFaTypeList = retrieveFeatureConfigOption(parmDisconnectForNonPayFeatureConfig);
		if(!disconnectForNonPayFaTypeList.isEmpty()){
			validateFaType(disconnectForNonPayFaTypeList);
		}

		// Fetch AccountId, PremiseId, LandlordId , SA start date
		accountId = parmServiceAgreement.getAccount().getId();
		premiseId = parmServiceAgreement.getPremiseId();
		if(!isNull(premiseId)){
		if(!isNull(premiseId.getEntity().fetchLandLord())){
		landlordId = premiseId.getEntity().fetchLandLord().getAccountId();
		startDate = parmServiceAgreement.getStartDate();

		// Check if current SA account is a Landlord Account
		if(!isNull(landlordId) && landlordId.equals(accountId)){

			// Check if there is any Landlord reversion
			if(ifStoppedServiceAgreementExist(premiseId, startDate)){
				//Check if budget has been copied to Landlord SA
				if(!parmServiceAgreement.getRecurringCharges().isEmpty()){	
					// Delete Budget On Landlord SA
					parmServiceAgreement.getRecurringCharges().removeAll();
				}
				// Retrieve last completed feild activity on premise service point
				lastCompletedFieldactivityType = getLastCompletedFieldActivityType(parmServiceAgreement.getServicePoints().iterator().next().getServicePoint().getId(), startDate.startOfDay());
				if(!isNull(lastCompletedFieldactivityType)){
					for(String faType: disconnectForNonPayFaTypeList){
						// Check if last completed FA type is Disconnection type
						if(faType.trim().compareTo(lastCompletedFieldactivityType.trim()) == 0){
							//Cancel Landlord SA and raise ToDo
							parmServiceAgreement.cancel(Bool.TRUE);
							// Start Change 2014-10-01   Rahul         Removed To Do Creation step as per UAT testing by Shea S Murray
							//createToDoEntry(parmServiceAgreement.getId().getTrimmedValue(), startDate.toString());
							// End 	 Change 2014-10-01   Rahul         Removed To Do Creation step as per UAT testing by Shea S Murray
						}
					}
				}
			}
		}
		}
		}
		
	}
	/*
	 * Method to check if a stopped SA exist on a given date on a premise
	 */

	private boolean ifStoppedServiceAgreementExist(Premise_Id premId, Date endDate){
		StringBuilder serviceagreementStoppedOnStartdateString = new StringBuilder();
		serviceagreementStoppedOnStartdateString.append("SELECT SA.SA_ID  ");
		serviceagreementStoppedOnStartdateString.append("FROM ");
		serviceagreementStoppedOnStartdateString.append("CI_SA SA, CI_SA_SP SASP, CI_SP SP ");
		serviceagreementStoppedOnStartdateString.append("WHERE ");
		serviceagreementStoppedOnStartdateString.append("SA.SA_ID = SASP.SA_ID ");
		serviceagreementStoppedOnStartdateString.append("AND SASP.SP_ID = SP.SP_ID ");
		serviceagreementStoppedOnStartdateString.append("AND SP.PREM_ID = :premiseid ");
		serviceagreementStoppedOnStartdateString.append("AND SA.END_DT = :endDate ");
		serviceagreementStoppedOnStartdateString.append("AND SA.SA_STATUS_FLG IN ( :pendingStop, :stop, :closed) ");
		//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
		// PreparedStatement serviceagreementStoppedOnStartdatePrepStmt = createPreparedStatement(serviceagreementStoppedOnStartdateString.toString());
		PreparedStatement serviceagreementStoppedOnStartdatePrepStmt = createPreparedStatement(serviceagreementStoppedOnStartdateString.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
		serviceagreementStoppedOnStartdatePrepStmt.bindDate("endDate", endDate);
		serviceagreementStoppedOnStartdatePrepStmt.bindId("premiseid", premId);
		serviceagreementStoppedOnStartdatePrepStmt.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
		serviceagreementStoppedOnStartdatePrepStmt.bindLookup("stop", ServiceAgreementStatusLookup.constants.STOPPED);
		serviceagreementStoppedOnStartdatePrepStmt.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
		List<SQLResultRow> resultList = serviceagreementStoppedOnStartdatePrepStmt.list();
		if(resultList.isEmpty()){
			return false;
		}else{
			return true;
		}
	}
	/*
	 * Method to retrieve featureConfiguration option values
	 */
	@SuppressWarnings("null")
	private ArrayList<String> retrieveFeatureConfigOption(FeatureConfiguration featureConfig){
		ArrayList<String> arraylist = new ArrayList<String>();
		//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
		// ListFilter<FeatureConfigurationOption> featConfigOptionFilter = featureConfig.getOptions().createFilter("WHERE this.id.optionType = :optionType");
		ListFilter<FeatureConfigurationOption> featConfigOptionFilter = featureConfig.getOptions().
				createFilter("WHERE this.id.optionType = :optionType", getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
		featConfigOptionFilter.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType, CmDiconnectFaLookup.constants.DISCONNECT_FA.trimmedValue());
		Iterator<FeatureConfigurationOption> faTypeIter = featConfigOptionFilter.list().iterator();
		while(faTypeIter.hasNext()){
			arraylist.add(faTypeIter.next().getValue());
		}

		return arraylist;
	}
	/*
	 * Method to validate an arraylist of faType
	 */
	private void validateFaType(ArrayList<String> faList){
		for(String fa: faList){
			FieldActivityType fieldActivityType = new FieldActivityType_Id(fa).getEntity();
			if(isNull(fieldActivityType)){
				addError(CustomMessageRepository.nb0029InvalidFAType(fa));
			}
		}
	}



	/*
	 * Get the last completed field activity on a service point
	 */
	private String getLastCompletedFieldActivityType(ServicePoint_Id servicePointId, DateTime endDate){
		String faType = null;
		StringBuilder lastCompletedFieldActivityTypeString = new StringBuilder();
		lastCompletedFieldActivityTypeString.append("SELECT ");
		lastCompletedFieldActivityTypeString.append("    FA_TYPE_CD ");
		lastCompletedFieldActivityTypeString.append("FROM ");
		lastCompletedFieldActivityTypeString.append("    CI_FA ");
		lastCompletedFieldActivityTypeString.append("WHERE ");
		lastCompletedFieldActivityTypeString.append("    FA_STATUS_FLG = 'C' ");
		lastCompletedFieldActivityTypeString.append("AND ");
		lastCompletedFieldActivityTypeString.append("    SP_ID = :spId ");
		lastCompletedFieldActivityTypeString.append("AND ");
		lastCompletedFieldActivityTypeString.append("    SCHED_DTTM <= :endDate ");	
		lastCompletedFieldActivityTypeString.append("ORDER BY SCHED_DTTM DESC ");
		//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
		// PreparedStatement lastCompletedFieldActivityTypePrepStmt = createPreparedStatement(lastCompletedFieldActivityTypeString.toString());
		PreparedStatement lastCompletedFieldActivityTypePrepStmt = createPreparedStatement(lastCompletedFieldActivityTypeString.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
		lastCompletedFieldActivityTypePrepStmt.bindId("spId", servicePointId);
		lastCompletedFieldActivityTypePrepStmt.bindDateTime("endDate", endDate);
		List<SQLResultRow> resultList = lastCompletedFieldActivityTypePrepStmt.list();
		if (!resultList.isEmpty()){
			faType = resultList.iterator().next().getString("FA_TYPE_CD");
		}
		return faType;
	}


	/**
	 * @return void 
	 *  This method creates Todo.
	 * 
	 */
	private void createToDoEntry(String cancelledServiceAgreement, String createDtStr){
		ToDoEntry_DTO entryDto  = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
		ToDoType toDoType = parmToDoTypeForSaCancellation.getId().getEntity();
		entryDto.setToDoTypeId(toDoType.getId());
		entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
		entryDto.setToDoPriority(toDoType.getToDoPriority());
		entryDto.setToDoRoleId(getDefaultToDoRole().getId());
		entryDto.setCreationDateTime(getProcessDateTime());
		entryDto.setToDoPriority(toDoType.getToDoPriority());
		MessageCategory_Id msgCatId = new MessageCategory_Id(BigInteger.valueOf(CustomMessageRepository.MESSAGE_CATEGORY));
		Message_Id msgId = new Message_Id(msgCatId, BigInteger.valueOf(CustomMessageRepository.IM052517_LANDLORD_SETUP_ON_BUDGET));
		entryDto.setMessageId(msgId);

		ArrayList<ToDoSortKeyValue_DTO>sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();
		ToDoTypeSortKeyTypes sortKeyTypes = toDoType.getSortKeyTypes();

		for (Iterator<ToDoSortKeyType> iter = sortKeyTypes.iterator(); iter.hasNext();) {
			ToDoSortKeyType sortKeyType = (ToDoSortKeyType) iter.next();
			ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
			BigInteger seq = sortKeyType.fetchIdSequence();
			sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));

			if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(1))==0){
				sortKeyDto.setKeyValue(createDtStr.toString());
			}
			sortKeyList.add(sortKeyDto);
		}

		ArrayList<ToDoDrillKeyValue_DTO>drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
		ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO)createDTO(ToDoDrillKeyValue.class);
		ToDoDrillKeyType drillKeyType = (ToDoDrillKeyType) toDoType.getDrillKeyTypes().iterator().next();
		BigInteger sequence = drillKeyType.fetchIdSequence();
		drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, sequence));

		drillKeyDto.setKeyValue(cancelledServiceAgreement);
		drillKeyList.add(drillKeyDto);

		ArrayList <String> messageParameterList = new ArrayList<String> ();
		messageParameterList.add(0,cancelledServiceAgreement);

		ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory.newInstance();

		toDoEntryData.setDrillKeys(drillKeyList);
		toDoEntryData.setEntryDto(entryDto);
		toDoEntryData.setSortKeys(sortKeyList);
		toDoEntryData.setMessageParams(messageParameterList);
		ArrayList <ToDoEntryCharacteristic_DTO>  charList = new ArrayList<ToDoEntryCharacteristic_DTO> ();
		toDoEntryData.setToDoCharacteristics(charList);

		ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
		toDoProcessor.addToDo(toDoEntryData);
	}

	/**
	 * @return Role 
	 * This method fetches the Default Role to create a TODO
	 * 
	 */ 
	private Role getDefaultToDoRole(){
		Role defaultRole = null;
		StringBuilder defaultRoleQueryString = new StringBuilder();
		defaultRoleQueryString.append("SELECT ROLE_ID FROM CI_TD_VAL_ROLE WHERE TD_TYPE_CD = :toDoType AND DEFAULT_SW = :yes ");
		//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
		// PreparedStatement defaultRolePrepStmt = createPreparedStatement(defaultRoleQueryString.toString()); 
		PreparedStatement defaultRolePrepStmt = createPreparedStatement(defaultRoleQueryString.toString(), getClass().getName());
		//End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
		defaultRolePrepStmt.bindId("toDoType", parmToDoTypeForSaCancellation.getId()); 
		defaultRolePrepStmt.bindBoolean("yes", Bool.TRUE);
		defaultRole = defaultRolePrepStmt.firstRow().getEntity("ROLE_ID", Role.class);
		defaultRolePrepStmt.close();
		return defaultRole;
	}




	public void setServiceAgreement(ServiceAgreement arg0) {
		parmServiceAgreement = arg0;

	}


}
