/* ************************************************************************
 *                Confidentiality Information:
 *
 * This module is the confidential and proprietary information of
 * Oracle Corporation; it is not to be copied, reproduced, or
 * transmitted in any form, by any means, in whole or in part,
 * nor is it to be used for any purpose other than that for which
 * it is expressly provided without the written permission of
 * Oracle Corporation.
 *
 *
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * Move Case to new Customer when a new Customer moves in
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:        Reason:
 * YYYY-MM-DD   IN         Reason text.
 *
 * 2013-11-26   Ujesh      IM-055867 - Close needed to be closed when new
 * 						   Customer moved in
 * 2014-12-04   Ujesh      IM-058230 - Restarting the Case in the Intial State
 * 2016-01-25   MPang	   Updated for CCB v2.4 compilation
 ***************************************************************************/

package com.splwg.cm.domain.admin.caseType;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.lookup.LookupField_Id;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.domain.common.phoneType.PhoneType;
import com.splwg.base.domain.common.phoneType.PhoneType_Id;
import com.splwg.ccb.api.lookup.CaseLogTypeLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ContactMethodLookup;
import com.splwg.ccb.api.lookup.TransitionConditionLookup;
//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.CaseType;
import com.splwg.ccb.domain.admin.caseType.CaseTypeAutoTransitionAlgorithmSpot;
import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityType;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.Person;
import com.splwg.ccb.domain.customerinfo.person.Person_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.toDoCase.CaseCreator;
import com.splwg.ccb.domain.todo.toDoCase.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCaseCharacteristics;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.ToDoCase_Id;*/

import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.caseType.algorithm.autoTransition.AutoTransitionAlgorithmSpot;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseCharacteristic_Id;
import com.splwg.ccb.domain.todo.common.CaseCreator;
import com.splwg.ccb.domain.todo.data.CaseCreatorData;
import com.splwg.ccb.domain.todo.toDoCase.entity.CaseLog;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCaseCharacteristics;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_DTO;
import com.splwg.ccb.domain.todo.toDoCase.entity.ToDoCase_Id;
//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;


/**
 * @author ut001
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (lookupName = transitionCondition, name = transitionConditionClose, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = featureConfigurationTypeForDisconnectFa, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = featureConfigurationOptionTypeForDisconnectFa, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = caseSPCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = statusInWhichCaseStarts, required = true, type = string)})
 */
public class CmMoveCaseToNewCustomerAlgComp_Impl 
       extends CmMoveCaseToNewCustomerAlgComp_Gen 	
	//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
	// implements CaseTypeAutoTransitionAlgorithmSpot { 
       implements AutoTransitionAlgorithmSpot {
	//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
	
	//private static Logger logger = LoggerFactory.getLogger(CmMoveCaseToNewCustomerAlgComp_Impl.class);
	
	private Bool shouldAutoTranstion = Bool.FALSE;
	private ToDoCase toDoCase;
	
	// Soft Parameters
	private CharacteristicType parmCaseSPCharType;
	private TransitionConditionLookup parmTransitionConditionClose;
	private FeatureConfiguration parmFeatureConfiguration;
	private String parmFeatureConfigurationOptType;
	private String transCondition;
	
	// IM-058230 - Start - Add - Ujesh - 2014-12-04
	private String parmStatusInWhichCaseStarts;
	// IM-058230 - End - Add - Ujesh - 2014-12-04
	 
	List<CaseCharacteristic_DTO> newCaseCharList;
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation)
	{
		
		parmCaseSPCharType = getCaseSPCharType();		
		CharacteristicEntity charEntity = new CharacteristicEntity_Id(parmCaseSPCharType, CharacteristicEntityLookup.constants.CASE).getEntity();
	    if(isNull(charEntity))
	    {
	    	addError(CustomMessageRepository.IM_055867_InvalidCharForEnitity(parmCaseSPCharType.getId().getTrimmedValue()));
	    }		
	    
	    parmTransitionConditionClose = getTransitionConditionClose();
	    parmFeatureConfiguration = getFeatureConfigurationTypeForDisconnectFa();
	    parmFeatureConfigurationOptType = getFeatureConfigurationOptionTypeForDisconnectFa();
	    
	    // IM-058230 - Start - Add - Ujesh - 2014-12-04 
	    parmStatusInWhichCaseStarts = getStatusInWhichCaseStarts().trim();
	    // IM-058230 - End - Add - Ujesh - 2014-12-04
	    
	    String extSysTypStr = parmFeatureConfiguration.getFeatureType().getLookupValue().fetchIdFieldValue().trim();
        extSysTypStr = extSysTypStr.concat("_OPT_TYP_FLG");
        LookupField_Id lookupField_Id = new LookupField_Id(extSysTypStr);
        LookupValue_Id lookupValue_Id = new LookupValue_Id(lookupField_Id, parmFeatureConfigurationOptType.trim());
        if (isNull(lookupValue_Id.getEntity())){
        	addError(CustomMessageRepository.IM_055867_OptionTypeInvalidForWfm(parmFeatureConfigurationOptType, parmFeatureConfiguration.getId().getTrimmedValue()));
        }
	    
	}


	public void invoke() 
	{
		
		// Get Case Creation Time
		
        DateTime caseCreDttm = null;
        for (CaseLog clog:toDoCase.getLogs())
        {
            if (clog.getLogType().equals(CaseLogTypeLookup.constants.CREATED))
            {
            	caseCreDttm = clog.getLogDateTime();
                break;
            }
        }
              
        // Get SP ID 
        List<CaseCharacteristic> caseSPCharList = toDoCase.getSortedCharacteristicsOfType(parmCaseSPCharType);
        if(caseSPCharList.isEmpty())
        {
        	addError(CustomMessageRepository.IM_055867_NoSpCharOnCase(toDoCase.getId().getTrimmedValue()));
        }
        ServicePoint_Id spId =  new ServicePoint_Id(caseSPCharList.iterator().next().getCharacteristicValueForeignKey1());

        ServicePoint sp = spId.getEntity();
        ServiceAgreementServicePoint sasp = getSASPRecord(sp);
        if(isNull(sasp))
        	return;
        
        if(!isNull(sasp.getStopDateTime()))
        if(sasp.getStopDateTime().isSameOrAfter(caseCreDttm) && sasp.getStopDateTime().isBefore(getProcessDateTime()) )
        {        	
        	
        	//Transition Current Case to Closed
        	transCondition=parmTransitionConditionClose.value();
        	shouldAutoTranstion = Bool.TRUE;    
        	return;
        }
        
        DateTime startDttm = sasp.getStartDateTime();
        
        
        if(startDttm.isSameOrAfter(caseCreDttm) && startDttm.isBefore(getProcessDateTime()) && !isDisconnectFaPresent(sp, caseCreDttm))
        {
        	
        	//Create Case on new Account
        	createCase(sp);  
        	
        	//Transition Current Case to Closed
        	
        	transCondition=parmTransitionConditionClose.value();
        	shouldAutoTranstion = Bool.TRUE;           	


        }
	}

	public CaseStatus getNextCaseStatus() 
	{
		
		return null;
	}

	public String getNextTransCondition() 
	{
		
		return transCondition;
	}

	public Bool getShouldAutoTransition() 
	{
		
		return shouldAutoTranstion;
	}

	public void setCase(ToDoCase arg0) 
	{
		toDoCase = arg0;
	}
	
	private ServiceAgreementServicePoint getSASPRecord(ServicePoint sp)
	{
		ServiceAgreementServicePoint sasp=null;
		
		StringBuilder queryStr = new StringBuilder();
		queryStr.append("SELECT SA_SP_ID FROM CI_SA_SP WHERE SP_ID = :spId ORDER BY START_DTTM DESC");
		//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
		// PreparedStatement getSaSpStmt = createPreparedStatement(queryStr.toString());
		PreparedStatement getSaSpStmt = createPreparedStatement(queryStr.toString(), getClass().getName());
		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
		getSaSpStmt.bindId("spId", sp.getId());
		
		if(getSaSpStmt.list().size()>0)
			sasp = getSaSpStmt.firstRow().getEntity("SA_SP_ID", ServiceAgreementServicePoint.class);
		
		return sasp;	
		
	}
	
    private void createCase(ServicePoint sp)
    {

        ToDoCase_DTO toDoCaseDTO = (ToDoCase_DTO) createDTO(ToDoCase.class);
        Account_Id accountId = null;
        Person_Id personId = null;
        String phone = "";
        List<SQLResultRow> usageList = getUsageInformation(sp.getId().getTrimmedValue());
        if(!usageList.isEmpty()){
            accountId = (Account_Id)usageList.iterator().next().getId("ACCT_ID", Account.class);
            personId = (Person_Id)usageList.iterator().next().getId("PER_ID", Person.class);                
        }
        
        CaseType toDocaseType = toDoCase.getCaseStatus().fetchIdCaseType();    
        
        // IM-058230 - Start - Change - Ujesh - 2014-12-04
        CaseStatus_Id caseStatusId = new CaseStatus_Id(toDocaseType, parmStatusInWhichCaseStarts);
        if(isNull(caseStatusId.getEntity()))
        {
        	addError(CustomMessageRepository.IM_055867_InvalidCaseStatusForCaseType(parmStatusInWhichCaseStarts, toDocaseType.getId().getTrimmedValue()));
        }
        //toDoCaseDTO.setCaseStatusId(toDoCase.getCaseStatus().getId());
        toDoCaseDTO.setCaseStatusId(caseStatusId);
        
        // IM-058230 - End - Change - Ujesh - 2014-12-04
        
        //toDoCaseDTO.setCaseStatusId(new CaseStatus_Id);
        
        if(isNull(accountId) && (toDocaseType.getAccountUsage().isRequired())){
        	addError(CustomMessageRepository.IM_055867_AccountNotFoundButReqOnCase(sp.getId().getTrimmedValue(), toDocaseType.getId().getTrimmedValue()));
        }
        if(notNull(accountId) && ((toDocaseType.getAccountUsage().isRequired()) || toDocaseType.getAccountUsage().isOptional())){
            toDoCaseDTO.setAccountId(accountId);
        }
        if(isNull(personId) && (toDocaseType.getPersonUsage().isRequired())){
        	addError(CustomMessageRepository.IM_055867_PersonNotFoundButReqOnCase(sp.getId().getTrimmedValue(), toDocaseType.getId().getTrimmedValue()));
        }
        if(notNull(personId) && (toDocaseType.getPersonUsage().isRequired() || toDocaseType.getPersonUsage().isOptional())){
            toDoCaseDTO.setPersonId(personId);
        }

        if(toDocaseType.getCallbackPhoneUsage().isRequired()){
            if(notNull(personId)){
                List<SQLResultRow> list = getPhoneInformation(personId);
                phone = list.iterator().next().getString("PHONE");
                toDoCaseDTO.setPhoneTypeId((PhoneType_Id)list.iterator().next().getId("PHONE_TYPE_CD", PhoneType.class));
                toDoCaseDTO.setPhone(phone);
            }
        }
        if(toDocaseType.getContactInformationUsage().isRequired()){
            toDoCaseDTO.setContactPersonId(personId);
            toDoCaseDTO.setPreferredContactMethod(ContactMethodLookup.constants.NOT_APPLICABLE);
        }
        if(toDocaseType.getContactInstructionsUsage().isRequired()){
            toDoCaseDTO.setContactInstructions(CustomMessageRepository.ni0007_3ContactInstructionsUsage().getMessageText());
        }

        
        if(isNull(sp.getPremise()) && toDocaseType.getPremiseUsage().isRequired()){
        	addError(CustomMessageRepository.IM_055867_PremiseNotFoundButReqOnCase(sp.getId().getTrimmedValue(), toDocaseType.getId().getTrimmedValue()));
        }
        if(toDocaseType.getPremiseUsage().isRequired() || toDocaseType.getPremiseUsage().isOptional()){
            toDoCaseDTO.setPremiseId(sp.getPremise().getId());
        }
        
        if(toDocaseType.getResponsibleUserUsage().isRequired()){
            toDoCaseDTO.setUserId(getActiveContextUser().getId());
        }

        /* 
         * Copy Characteristcs from old case to new case
         */
        newCaseCharList = new ArrayList<CaseCharacteristic_DTO>();
        ToDoCaseCharacteristics oldChars = toDoCase.getCharacteristics();
        Iterator<CaseCharacteristic> oldCharsIter = oldChars.iterator();
        while(oldCharsIter.hasNext())
        {
        	CaseCharacteristic caseChar = oldCharsIter.next();
        	CaseCharacteristic_DTO oldCaseCharDto = caseChar.getDTO();
        	CaseCharacteristic_DTO newCaseCharDto = createDTO(CaseCharacteristic.class);
        	
        	newCaseCharDto = oldCaseCharDto;
        	CaseCharacteristic_Id caseCharId = new CaseCharacteristic_Id(oldCaseCharDto.getId().getCharacteristicType(), ToDoCase_Id.NULL.getEntity(), oldCaseCharDto.getId().getSequence());
        	newCaseCharDto.setId(caseCharId);
        	
        	newCaseCharList.add(newCaseCharDto);
        	
        }
        

        CaseCreatorData caseCreatorData = CaseCreatorData.Factory.newInstance();
        caseCreatorData.setToDoCaseDTO(toDoCaseDTO);             
        caseCreatorData.setCaseCharacteristics(newCaseCharList);

        CaseCreator caseCreator = CaseCreator.Factory.newInstance();
        caseCreatorData = caseCreator.createCase(caseCreatorData);
        
    }
    
    private List<SQLResultRow> getUsageInformation(String spId)
    {
        StringBuilder getUsageDetailsString = new StringBuilder();
        getUsageDetailsString.append("SELECT SA.ACCT_ID, APER.PER_ID,(SELECT PHONE FROM CI_PER_PHONE WHERE PER_ID = APER.PER_ID AND ROWNUM <=1) PHONE ");
        getUsageDetailsString.append("FROM CI_SA_SP SASP ");
        getUsageDetailsString.append(", CI_SA SA ");
        getUsageDetailsString.append(", CI_ACCT_PER APER ");
        getUsageDetailsString.append("WHERE SASP.SP_ID = :spId ");
        getUsageDetailsString.append("AND SASP.SA_ID = SA.SA_ID ");
		getUsageDetailsString.append("AND SASP.START_DTTM = (SELECT MAX(START_DTTM) FROM CI_SA_SP WHERE SP_ID = :spId) ");
        getUsageDetailsString.append("AND SA.ACCT_ID = APER.ACCT_ID  "); 
        getUsageDetailsString.append("AND APER.MAIN_CUST_SW = 'Y' "); 
        getUsageDetailsString.append("AND APER.ACCT_REL_TYPE_CD = 'MAIN' "); 
        //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString()); 
        PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString(), getClass().getName());
        //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        getUsageDetailsPrepStmt.bindId("spId", new ServicePoint_Id(spId));

        List<SQLResultRow> usageList = getUsageDetailsPrepStmt.list();

        getUsageDetailsPrepStmt.close();

        return usageList;
    }
    private List<SQLResultRow> getPhoneInformation(Person_Id perId){
        StringBuilder getUsageDetailsString = new StringBuilder();
        getUsageDetailsString.append("SELECT PHONE , PHONE_TYPE_CD FROM CI_PER_PHONE WHERE PER_ID = :perId ");
        //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString()); 
        PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString(), getClass().getName());
        //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        getUsageDetailsPrepStmt.bindId("perId", perId);

        List<SQLResultRow> usageList = getUsageDetailsPrepStmt.list();

        getUsageDetailsPrepStmt.close();

        return usageList;
    }
	private boolean isDisconnectFaPresent(ServicePoint sp, DateTime caseCreDttm)
	{
		boolean isDisconnected = false;
		
		StringBuilder queryStr = new StringBuilder();		
		queryStr.append("SELECT FA_ID,FA_TYPE_CD FROM CI_FA WHERE SP_ID = :spId AND SCHED_DTTM >= :caseCreDttm");
		//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
		// PreparedStatement getFaStmt = createPreparedStatement(queryStr.toString());
		PreparedStatement getFaStmt = createPreparedStatement(queryStr.toString(), getClass().getName());
		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
		getFaStmt.bindId("spId", sp.getId());
		getFaStmt.bindDateTime("caseCreDttm", caseCreDttm.startOfDay());
		
		QueryIterator<SQLResultRow> faItr = getFaStmt.iterate();
		while(faItr.hasNext())
		{
			SQLResultRow faRow = faItr.next();
			FieldActivityType faType = faRow.getEntity("FA_TYPE_CD", FieldActivityType.class);
			
			//Check if this FA Type is Present in Feature Configuration
			StringBuilder checkFaInFeatureConfig = new  StringBuilder();
			checkFaInFeatureConfig.append("SELECT * FROM CI_WFM_OPT WHERE WFM_NAME=:WFM_NAME AND WFM_OPT_VAL = :WFM_OPT_VAL AND EXT_OPT_TYPE=:EXT_OPT_TYPE");
			
			//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement checkFaStmt = createPreparedStatement(checkFaInFeatureConfig.toString());
			PreparedStatement checkFaStmt = createPreparedStatement(checkFaInFeatureConfig.toString(), getClass().getName());
			//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
			checkFaStmt.bindId("WFM_NAME", parmFeatureConfiguration.getId());
			checkFaStmt.bindString("EXT_OPT_TYPE", parmFeatureConfigurationOptType, "EXT_OPT_TYPE");
			checkFaStmt.bindId("WFM_OPT_VAL",faType.getId());
			
			if(checkFaStmt.list().size() > 0)
				isDisconnected = true;			
		}		
		
		return isDisconnected;		
	}
 }
