/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Add Power Status Characteristic 
 * 
 * This algorithm will set the Power Status Service Point Characteristic 
 * whenever a new Meter is installed on the Service Point.
 *            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-04-01   JPunza  NI0009.3 Initial Version.
 * 2015-08-07	JHERNA	3271228. Issue with adding characteristic if the 
 *                      said characteristic already exists.
 * 2016-01-26   MPang	Updated for CCB v2.4 compilation.
 *************************************************************************/

package com.splwg.cm.domain.admin.fieldActivityType;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityStepTypeActionLookup;

//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.fieldActivityType.FieldActivityTypeFaCompletionAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePointCharacteristic;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePointCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePointCharacteristic_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.FieldActivityStep;
import com.splwg.ccb.domain.meterread.meterConfiguration.MeterConfiguration;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.ServicePointMeterHistory;*/

import com.splwg.ccb.domain.admin.fieldActivityType.algorithm.faCompletion.FieldActivityTypeFaCompletionAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityStep;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory;
//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;

/**
 * @author jpunzalan2
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = powerStatusCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = truePowerStatusCharacteristicValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = falsePowerStatusCharacteristicValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = itemType, name = amrItemType, required = true, type = entity)})
 */
public class CmAddPowerStatusCharacteristicToServicePointAlgComp_Impl 
        extends CmAddPowerStatusCharacteristicToServicePointAlgComp_Gen 
        implements FieldActivityTypeFaCompletionAlgorithmSpot {

    // Constant Variables
    private final String POWER_STATUS = "Power Status";
    private final String TRUE_POWER_STATUS = "True Power Status";
    private final String FALSE_POWER_STATUS = "False Power Status";
        
    // Soft Parameters
    private CharacteristicType powerStatusCharType;
    private String truePowerStatusCharValue;
    private String falsePowerStatusCharValue;
    
    // Hard Parameter
    private FieldActivity fieldActivity;
    
    public void setFieldActivity(FieldActivity arg0) {
        fieldActivity = arg0;
    }
    
    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        
        // Power Status Characteristic Type
        powerStatusCharType = getPowerStatusCharacteristicType();
        if (validateCharacteristicEntity(powerStatusCharType, CharacteristicEntityLookup.constants.SERVICE_POINT).isFalse()) {
            addError(CustomMessageRepositoryMDC.NI0009_3_psCharTypeInvalidForEntity(
                    getAlgorithm().getId().getTrimmedValue(),
                    POWER_STATUS, 
                    powerStatusCharType.getId().getTrimmedValue(),
                    CharacteristicEntityLookup.constants.SERVICE_POINT.getLookupValue().fetchLanguageDescription()));
        }
        
        if (powerStatusCharType.getCharacteristicType().isPredefinedValue()) {
        
            // Yes Power Status Characteristic Value
            truePowerStatusCharValue = getTruePowerStatusCharacteristicValue();
            if (validateCharTypeAndCharValue(powerStatusCharType, truePowerStatusCharValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0009_3_psCharValueInvalidForCharType(
                        getAlgorithm().getId().getTrimmedValue(),
                        TRUE_POWER_STATUS, 
                        truePowerStatusCharValue, 
                        powerStatusCharType.getId().getTrimmedValue()));
            }
            
            // No Power Status Characteristic Value
            falsePowerStatusCharValue = getFalsePowerStatusCharacteristicValue();
            if (validateCharTypeAndCharValue(powerStatusCharType, falsePowerStatusCharValue).isFalse()) {
                addError(CustomMessageRepositoryMDC.NI0009_3_psCharValueInvalidForCharType(
                        getAlgorithm().getId().getTrimmedValue(),
                        FALSE_POWER_STATUS, 
                        falsePowerStatusCharValue, 
                        powerStatusCharType.getId().getTrimmedValue()));
            }
        }       
    }
    
    /**
     * This method validates if a characteristic type is valid for a specific characteristic entity.
     * @param charType - Characteristic Type
     * @param charEntityLookup - Characteristic Entity Lookup
     * @return Bool
     */
    private Bool validateCharacteristicEntity(CharacteristicType charType, CharacteristicEntityLookup charEntityLookup) {
        
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType.getId(), charEntityLookup);        
        if (isNull(charEntityId.getEntity())) {
            return Bool.FALSE;
        }
        
        return Bool.TRUE;
    }
    
    /**
     * This method validates if characteristic value is valid for a given characteristic type. 
     * @param charType - Characteristic Type
     * @param charValue - String
     * @return Bool
     */
    private Bool validateCharTypeAndCharValue(CharacteristicType charType, String charValue) {

        CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
        if (charTypeLookup.isPredefinedValue()) {
            CharacteristicValue_Id charValueId = new CharacteristicValue_Id(charType, charValue);
            if (isNull(charValueId.getEntity())) {
                return Bool.FALSE;
            }
        }

        return Bool.TRUE;
    }
    
    public void invoke() {

        // Check for Install Meter FA Step Action 
    	
    	//Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        //ListFilter<FieldActivityStep> faStepsFilter = fieldActivity.getSteps().createFilter("where this.faStepTypeAction = :installMeterAction");
        ListFilter<FieldActivityStep> faStepsFilter = fieldActivity.getSteps().createFilter("where this.faStepTypeAction = :installMeterAction", getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
        
        faStepsFilter.bindLookup("installMeterAction", FieldActivityStepTypeActionLookup.constants.INSTALL_METER);

        FieldActivityStep faStep = faStepsFilter.firstRow();
        
        if (notNull(faStep)) {
            
            ServicePointMeterHistory spmh = faStep.fetchSpMeterHistory();
            if (isNull(spmh)) {
                addError(CustomMessageRepositoryMDC.NI0009_3_psSpMeterHistoryNotProvided(fieldActivity.getId().getTrimmedValue()));
            }
            
            MeterConfiguration meterConfig = spmh.getMeterConfiguration();
            
            // Count Register
            int registerCount = meterConfig.getRegisters().size();
            
            // Number of AMR Devices
            PreparedStatement countAmrDevices = createPreparedStatement(
                    "SELECT DISTINCT(MTRDEVICE.ITEM_ID_EQ) " +
                    "FROM CI_MTR_EQ MTRDEVICE, CI_ITEM ITEM " +
                    "WHERE MTRDEVICE.MTR_ID = :meterId " +
                    "AND MTRDEVICE.INSTALL_DT <= :processDate " +
                    "AND MTRDEVICE.REMOVAL_DT IS NULL " +
                    "AND MTRDEVICE.ITEM_ID_EQ = ITEM.ITEM_ID " +
                    //Start Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
                   // "AND ITEM.ITEM_TYPE_CD = :amrItemType");
            		"AND ITEM.ITEM_TYPE_CD = :amrItemType", getClass().getName());
                   //End Change - 2016-01-26 - MPang - Updated for CCB v2.4 compilation
            
            countAmrDevices.bindId("meterId", meterConfig.getMeter().getId());
            countAmrDevices.bindDate("processDate", getProcessDateTime().getDate());
            countAmrDevices.bindEntity("amrItemType", getAmrItemType());
            
            int amrDeviceCount = countAmrDevices.list().size();
            
            ServicePoint sp = fieldActivity.getServicePoint();
            
            if (registerCount == amrDeviceCount) {
                addSpCharacteristic(sp, powerStatusCharType, truePowerStatusCharValue);
            }
            else {
                addSpCharacteristic(sp, powerStatusCharType, falsePowerStatusCharValue);
            }
        }        
    }
    
    /**
     * This method adds Service Point Characteristic.
     * @param sp - Service Point
     * @param charType - Characteristic Type
     * @param charValue - Characteristic Value
     */
    private void addSpCharacteristic(ServicePoint sp, CharacteristicType charType, String charValue) {
        
    	// START CHANGES - JHERNA - 2015-08-07 - 3271228
    	/*
        CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType(); 
        ServicePointCharacteristics spChars = sp.getCharacteristics();
            
        // Add SP Characteristic
        ServicePointCharacteristic_DTO spCharDto = spChars.newChildDTO();
        
        if (charTypeLookup.isPredefinedValue()) { 
            spCharDto.setCharacteristicValue(charValue);
        } 
        else if (charTypeLookup.isForeignKeyValue()) {
            spCharDto.setCharacteristicValueForeignKey1(charValue);
        }
        else { 
            spCharDto.setAdhocCharacteristicValue(charValue);   
        }
        
        spChars.add(spCharDto, charType.getId(), getProcessDateTime().getDate());
        */
    	if (notBlank(charValue)) {
    		
    		Date processDate = this.getProcessDateTime().getDate();
    		// Check if characteristic already exists
    		ServicePointCharacteristic_Id spCharID = new ServicePointCharacteristic_Id(sp, charType, processDate);
    		
    		if (isNull(spCharID.getEntity())) {
    			// Processing in the event that there is still no characteristic of the said type and date on the service point
                ServicePointCharacteristic_DTO spCharDTO = new ServicePointCharacteristic_DTO();
            	CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();                                    
                
                if (charTypeLookup.isPredefinedValue()) { 
                	spCharDTO.setCharacteristicValue(charValue.trim());
                } 
                else if (charTypeLookup.isForeignKeyValue()) {
                	spCharDTO.setCharacteristicValueForeignKey1(charValue.trim());
                }
                else { 
                	spCharDTO.setAdhocCharacteristicValue(charValue.trim());   
                }
                                
                spCharDTO.setId(spCharID);
                spCharDTO.newEntity();
    		}
    		else {
    			// Processing in the event that there already exists a characteristic with the same effective date on the service point
    			ServicePointCharacteristic spChar = spCharID.getEntity();
    			ServicePointCharacteristic_DTO spCharDTO = spChar.getDTO();    			
    			CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();                                    
                
                if (charTypeLookup.isPredefinedValue()) { 
                	spCharDTO.setCharacteristicValue(charValue.trim());
                } 
                else if (charTypeLookup.isForeignKeyValue()) {
                	spCharDTO.setCharacteristicValueForeignKey1(charValue.trim());
                }
                else { 
                	spCharDTO.setAdhocCharacteristicValue(charValue.trim());   
                }
                spChar.setDTO(spCharDTO);
    		}            
    	}    	        
    	// END CHANGES - JHERNA - 2015-08-07 - 3271228 
    }
}
