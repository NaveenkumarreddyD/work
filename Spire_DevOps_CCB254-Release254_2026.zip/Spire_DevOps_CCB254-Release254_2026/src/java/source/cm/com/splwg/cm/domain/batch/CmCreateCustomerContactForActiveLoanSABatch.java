/* ***************************************************************************
 * PROGRAM DESCRIPTION: 
 * 
 * Customer Contact Creation For Active Loan SA Batch Process
 * 
 * This job will trigger the creation of Customer Contacts on Accounts that 
 * have an Active Loan SA. It will create the Customer Contact annually and 
 * will be created on the Start Date of the Loan SA.   
 * 
 *                                                  
 ******************************************************************************                                                                 
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:             Reason:                                     
 * YYYY-MM-DD   IN              Reason text.                                
 *           
 * 2021-03-18   SRoman          B-18265. Initial Version.
 *****************************************************************************/

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.lookup.LookupField_Id;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.domain.security.user.User_Id;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision_Id;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author SRoman
 *
@BatchJob (modules = {}, multiThreaded = true, rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (name = SA_TYPE_LIST, required = true, type = string)
 *            , @BatchJobSoftParameter (name = SA_STATUS_LIST, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CIS_DIVISION_LIST, type = string)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CC_CL_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CC_TYPE_CD, required = true, type = string)})
 */
public class CmCreateCustomerContactForActiveLoanSABatch extends
		CmCreateCustomerContactForActiveLoanSABatch_Gen {
	
	// Constant Variables
	private static final String COMMA = ",";
	private static final String SINGLE_QUOTE = "'";
	
    //Soft Parameters
    private String saTypeStr;
    private String saStatusStr;
    private String cisDivisionStr;
    private CustomerContactClass custContClass;
    private String custContTypeStr;

	public JobWork getJobWork() {
		saTypeStr = getParameters().getSA_TYPE_LIST();
		saStatusStr = getParameters().getSA_STATUS_LIST();
		cisDivisionStr = getParameters().getCIS_DIVISION_LIST();
		
		List<ThreadWorkUnit>workUnitList = new ArrayList<ThreadWorkUnit>();
		String saTypeStrBind = createStringForQuery(saTypeStr).trim();
		String saStatusStrBind = createStringForQuery(saStatusStr).trim();
		
        StringBuilder retrieveLoanSAs = new StringBuilder();
        retrieveLoanSAs.append("SELECT SA.SA_ID ");
        retrieveLoanSAs.append(		", SA.ACCT_ID ");
        retrieveLoanSAs.append(		", SA.START_DT ");
        retrieveLoanSAs.append("FROM ");
        retrieveLoanSAs.append(		"CI_SA SA ");
        retrieveLoanSAs.append("WHERE ");
        retrieveLoanSAs.append(    "SA.SA_TYPE_CD IN (" + saTypeStrBind + ") ");
        if (notBlank(cisDivisionStr)){
            String cisDivisionStrBind = createStringForQuery(cisDivisionStr).trim();
            retrieveLoanSAs.append("AND SA.CIS_DIVISION IN (" + cisDivisionStrBind + ") ");    
        }
        retrieveLoanSAs.append("AND SA.SA_STATUS_FLG IN (" + saStatusStrBind + ") ");
        retrieveLoanSAs.append("AND EXTRACT(MONTH FROM (SA.START_DT)) = :processDateMonth ");
        retrieveLoanSAs.append("AND EXTRACT(YEAR FROM (SA.START_DT)) < :processDateYear ");

        PreparedStatement retrieveLoanSAsQry = createPreparedStatement(retrieveLoanSAs.toString(), getClass().getName());
        retrieveLoanSAsQry.bindBigInteger("processDateMonth", BigInteger.valueOf(getProcessDateTime().getMonth()));
        retrieveLoanSAsQry.bindBigInteger("processDateYear", BigInteger.valueOf(getProcessDateTime().getYear()));
        
		for(SQLResultRow row : retrieveLoanSAsQry.list()) {
			Account_Id acctId = (Account_Id) row.getId("ACCT_ID", Account.class);
			Person_Id perId = acctId.getEntity().getMainPerson().getId();
			if (isCustomerContactCreatedForThisMonth(perId).isFalse()){
				ThreadWorkUnit workUnit = new ThreadWorkUnit();
				workUnit.setPrimaryId(perId);
				workUnitList.add(workUnit);
			}
		}
		
		retrieveLoanSAsQry.close();
		
		return createJobWorkForThreadWorkUnitList(workUnitList);
	}
	
    private Bool isCustomerContactCreatedForThisMonth(Person_Id perId) {
    	custContClass = getParameters().getCC_CL_CD();
    	custContTypeStr = getParameters().getCC_TYPE_CD().trim();
    	Bool hasCustomerContact = Bool.FALSE;
		
		StringBuilder checkLastCustomerContact = new StringBuilder();
		checkLastCustomerContact.append("SELECT 'X' ");
		checkLastCustomerContact.append("FROM ");
		checkLastCustomerContact.append(	"CI_CC CC ");
		checkLastCustomerContact.append("WHERE ");
		checkLastCustomerContact.append(	"CC.PER_ID = :mainPerId ");
		checkLastCustomerContact.append("AND CC.CC_CL_CD = :customerContClass ");
		checkLastCustomerContact.append("AND CC.CC_TYPE_CD = :customerContType ");
		checkLastCustomerContact.append("AND EXTRACT(MONTH FROM (CC.CC_DTTM)) = :processDateMonth ");
		checkLastCustomerContact.append("AND EXTRACT(YEAR FROM (CC.CC_DTTM)) = :processDateYear ");
		
		PreparedStatement checkLastCustomerContactQry = createPreparedStatement(checkLastCustomerContact.toString(), getClass().getName());
		checkLastCustomerContactQry.bindId("mainPerId", perId);
		checkLastCustomerContactQry.bindEntity("customerContClass" , custContClass);
		checkLastCustomerContactQry.bindString("customerContType", custContTypeStr, "CC_TYPE_CD");
		checkLastCustomerContactQry.bindBigInteger("processDateMonth", BigInteger.valueOf(getProcessDateTime().getMonth()));
		checkLastCustomerContactQry.bindBigInteger("processDateYear", BigInteger.valueOf(getProcessDateTime().getYear()));
		
		if(checkLastCustomerContactQry.list().size() > 0) {
			hasCustomerContact = Bool.TRUE;
		}else {
			hasCustomerContact = Bool.FALSE;
		}
		
		checkLastCustomerContactQry.close();
		
		return hasCustomerContact;
	}

	/**
     * This method builds the String for query.
     * @param comma-delimited string
     * @return comma-delimited string with quote
     */
    private String createStringForQuery(String string) {
        StringBuilder strBuilder = new StringBuilder();
        String [] tempList;
        tempList = string.split(COMMA);

        for(int ctr = 0; ctr<tempList.length; ctr++){
            if(ctr > 0){
                strBuilder.append(COMMA);
            }
            strBuilder.append(SINGLE_QUOTE);
            strBuilder.append(tempList[ctr].trim());
            strBuilder.append(SINGLE_QUOTE);
        }
        return strBuilder.toString();
    }

	@Override
	public void validateSoftParameters(boolean isNewRun) {
		String saTypeStr = getParameters().getSA_TYPE_LIST();
		String saStatusStr = getParameters().getSA_STATUS_LIST();
		String cisDivStr = getParameters().getCIS_DIVISION_LIST();
		CustomerContactClass ccClass = getParameters().getCC_CL_CD();
		String ccTypeStr = getParameters().getCC_TYPE_CD().trim();
		
        String [] saTypeList;
        String [] saStatusList;
        String [] cisDivList;

        CisDivision_Id parmCisDivId = null;
        LookupValue_Id parmSaStatus = null;
        saTypeList = saTypeStr.split(COMMA);
        
        //Validate that each SA Type in the parameter is a valid SA Type in CI_SA_TYPE table
        saTypeList = saTypeStr.split(COMMA);
        for (String saType : saTypeList){
        	StringBuilder validateSAtype = new StringBuilder();
        	validateSAtype.append("SELECT 'X' FROM CI_SA_TYPE SAT WHERE SAT.SA_TYPE_CD = :saTypeCd ");
        	PreparedStatement validateSAtypeQry = createPreparedStatement(validateSAtype.toString(), getClass().getName());
        	validateSAtypeQry.bindString("saTypeCd", saType, "SA_TYPE_CD");
        	
        	if(validateSAtypeQry.list().size() == 0){
        		addError(CustomMessageRepositorySpireOne.B18265_invalidSaType(saType));
        		break;
        	}
        }
        
        //Validate that each Status in the parameter is a valid SA status
        saStatusList = saStatusStr.split(COMMA);
        for (String saStatus : saStatusList){
            parmSaStatus = new LookupValue_Id(new LookupField_Id(ServiceAgreementStatusLookup.constants.ACTIVE.fieldName()), saStatus);
            if(isNull(parmSaStatus.getEntity())){
                addError(CustomMessageRepositorySpireOne.B18265_invalidSaStatus(saStatus));
            }
        }
        
        //Validate that each CIS Division in the parameter is a valid CIS Division
        if(notBlank(cisDivStr)){
        	cisDivList = cisDivStr.split(COMMA);
            for (String cisDiv : cisDivList){
            	parmCisDivId = new CisDivision_Id(cisDiv);
            	if(isNull(parmCisDivId.getEntity())){
            		addError(CustomMessageRepositorySpireOne.B18265_invalidCisDivision(cisDiv));
            	} 
            }
        }
        
        //Check if Customer Contact Type Field is valid for Contact Class Batch Parameter
        CustomerContactType_Id ccTypeId = new CustomerContactType_Id(ccClass, ccTypeStr);
        if(isNull(ccTypeId.getEntity())) {
            addError(CustomMessageRepositorySpireOne.B18265_invalidCustContactType(ccTypeStr, ccClass.getId().getTrimmedValue()));
        }
	}

	public Class<CmCreateCustomerContactForActiveLoanSABatchWorker> getThreadWorkerClass() {
		return CmCreateCustomerContactForActiveLoanSABatchWorker.class;
	}

	public static class CmCreateCustomerContactForActiveLoanSABatchWorker
			extends CmCreateCustomerContactForActiveLoanSABatchWorker_Gen {
		
		//Work Variables
		private CustomerContactClass custContClass;
		private CustomerContactType_Id custContTypeId;
		private String custContTypeStr;
		private Person_Id perId;

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}
		
		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful) 
				throws ThreadAbortedException, RunAbortedException {
			
			custContClass = getParameters().getCC_CL_CD();
			custContTypeStr = getParameters().getCC_TYPE_CD();
			custContTypeId = new CustomerContactType_Id(custContClass, custContTypeStr);
		}
		
		 @Override
		 public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			 perId = (Person_Id) unit.getPrimaryId();
			 createCustomerContact(perId);
			 return true;
		}

		/**
	      * Creates customer contact using the information from the
	      * algorithm parameters.
	      */
		private void createCustomerContact(Person_Id mainPerId){
			// Assign User Id
			User_Id userId = this.getParameters().getUserId();
			if (isNull(userId)) {
				userId = this.getActiveContextUser().getId();
			}

			// Create Customer Contact DTO
			CustomerContact_DTO customerContactDTO = (CustomerContact_DTO) createDTO(CustomerContact.class);

			// Set Customer Contact details
			customerContactDTO.setCustomerContactTypeId(custContTypeId);
			customerContactDTO.setPersonId(mainPerId);
			customerContactDTO.setContactDateTime(this.getProcessDateTime());
			customerContactDTO.setUserId(userId);

			// Check if Customer Contact Type Contact Action is Send Letter
			if (custContTypeId.getEntity().getCustomerContactAction().isSendLetter()) {
				customerContactDTO.setShouldPrintLetter(Bool.TRUE);
				customerContactDTO.setLetterTemplateId(custContTypeId.getEntity().getLetterTemplateId());
			} else {
				customerContactDTO.setShouldPrintLetter(Bool.FALSE);
			}

			// Create Customer Contact
			customerContactDTO.newEntity();
		}
	}

}
