/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This batch program is a duplicate of CmPaymentReturns_BatchProcess
 * and will stage all the records that are part of the 
 * Returned Items file in the Notification upload staging area. 
 * The records will have a unique external system ID and Notification Upload 
 * type to differentiate them from the other entries in the 
 * Notification Upload staging table. After which, the records processed
 * are inserted to the CM_PMT_RETURN custom table. 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2020-06-16   JVitug			B-15545. Initial Version    
 **************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.SingleTransactionStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.lookup.NotificationUploadContextLookup;
import com.splwg.base.api.lookup.NotificationUploadExtensionLookup;
import com.splwg.base.api.lookup.NotificationUploadStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.workflow.notificationExternalId.NotificationExternalId_Id;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadContext_DTO;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadContext_Id;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload_DTO;
import com.splwg.base.domain.workflow.notificationUploadExtensionType.NotificationUploadExtensionType;
import com.splwg.cm.api.lookup.CmPaymentTypeLookup;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.common.ApplicationError;

/**
 * @author rgullapall003
 *
 @BatchJob ( modules = {} 
 *              , multiThreaded = false, rerunnable = true,
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)
 *            , @BatchJobSoftParameter (entityName = notificationUploadExtensionType, name = NOTIFICATION_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = ACCT_ID_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = AMT_PAID_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = PAY_TYPE_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = ORG_PAY_BATCH_NUM_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = ORG_PAY_DATE_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = RETRN_PAY_DATE_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = RETRN_REASON_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = EXT_PAY_ID_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = CUST_NAME_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = CUST_ADRSS_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (name = RETENTION_DAYS, required = true, type = integer)})
 */

public class CmFirsTechPaymentReturns_BatchProcess extends CmFirsTechPaymentReturns_BatchProcess_Gen {


	public JobWork getJobWork() {

		List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();                                               
		ThreadWorkUnit workUnit = new ThreadWorkUnit(); 
		workUnits.add(workUnit);   
		return createJobWorkForThreadWorkUnitList(workUnits);   
	}

	/**
	 * This method checks if all required Soft Parameters were populated,
	 * and all optional Soft Parameters (if populated) are valid.
	 * 
	 * @param isNewRun - a boolean value
	 */
	public void validateSoftParameters(boolean isNewRun){
	    BigInteger parmMaxErrors = null;
	    String parmFilePath;
	    String parmFileName;
	    File inputFile = null;
	    
		parmMaxErrors = getParameters().getMAX_ERRORS();
		// Validates Max Error soft parameter
		if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
			addError(CustomMessageRepository.ni0019_5MaxErrorCannotBeLessThanZero(parmMaxErrors.toString().trim()));
		}   
		parmFilePath = getParameters().getFILE_PATH().trim();
		parmFileName = getParameters().getFILE_NAME().trim();

		File folder = new File(parmFilePath);
		if(!folder.exists()){
			addError(CustomMessageRepository.ni0019_5InvalidFilePath(parmFilePath));
		}

		// Validate that the parameter FILE-NAME is a correct file name and that the corresponding file can be opened and read.
		inputFile = new File(parmFilePath, parmFileName);
		if(!inputFile.exists() || !inputFile.canRead()){
			addError(CustomMessageRepository.ni0019_5InvalidFileName(parmFileName));
		} 
	}


	/**
	 * Method to retrieve the Thread Worker Class.
	 * 
	 * @return the thread worker class
	 */
	public Class<CmFirsTechPaymentReturns_BatchProcessWorker> getThreadWorkerClass() {
		return CmFirsTechPaymentReturns_BatchProcessWorker.class;
	}

	/**
	 * This Worker Class is responsible for processing a single Thread Instance.
	 */
	public static class CmFirsTechPaymentReturns_BatchProcessWorker extends
	CmFirsTechPaymentReturns_BatchProcessWorker_Gen {

		// Soft parameters
		private  BigInteger parmMaxErrors = null;
		private  String parmFilePath;
		private  String parmFileName;
		private  File inputFile = null;
		private  NotificationUploadExtensionType parmNotificationType;
		private  NotificationUploadContextLookup parmAcctIdNotificationContextType;
		private  NotificationUploadContextLookup parmAmountPaidNotificationContextType;
		private  NotificationUploadContextLookup parmPayTypeNotificationContextType;
		private  NotificationUploadContextLookup parmOriginalPayBatchNumberNotificationContextType;
		private  NotificationUploadContextLookup parmOrgPayDateNotificationContextType;
		private  NotificationUploadContextLookup parmReturnPayDateNotificationContextType;
		private  NotificationUploadContextLookup parmReturnReasonNotificationContextType;
		private  NotificationUploadContextLookup parmExternalPayIdNotificationContextType;
		private  NotificationUploadContextLookup parmCustomerNameNotificationContextType;
		private  NotificationUploadContextLookup parmCustomerAddressNotificationContextType;
		private  BigInteger parmDataRetentionDays;
		//Working Variables
		private BufferedReader inputBufferReader = null;
		private BigInteger lineCounter = BigInteger.ZERO;
		private String fileDateStr = "";
		private String fileBankNameStr = "";
		private DateTime fileDateTime;
		private String batchNumber;
		private BigDecimal batchAmount = BigDecimal.ZERO;
		private BigInteger orgPayBatchNum;
		private int count = 0;
		private int batchTrailerRecordCount;
		private int totalBatchCount = 0;
		private int fileTrailerBatchCount;
		private int totalFileRecordCount = 0;
		private int fileTrailerRecordCount;
		private BigDecimal totalBatchDepositAmt = BigDecimal.ZERO;
		private NotificationUpload notificationUpload;
		private BigDecimal batchDepositAmount;
		private NotificationExternalId_Id notificationExternalId;
		private BigInteger numberOfRecordsInError = BigInteger.ZERO;

		private static final int RECORD_TYPE_INDEX = 0;
		private static final int RECORD_TYPE_LENGTH = 1;
		private static final String DATETIME_FORMAT_MMDDYYYYHHMMSS = "MMddyyyy HHmmss";
		private static final String DATE_FORMAT_RECORD = "MMddyy";

		// CONSTANT NAMES
		private static final String CONST_RECORD_TYPE = "RECORD TYPE";
		private static final String CONST_FILE_DATE = "FILE DATE";
		private static final String CONST_BANK_NAME = "BANK NAME";
		private static final String CONST_BATCH_NUM = "BATCH NUMBER";
		private static final String CONST_ACCOUNT_ID = "ACCOUNT ID";
		private static final String CONST_AMOUNT_PAID = "AMOUNT PAID";
		private static final String CONST_PAY_TYPE = "PAYMENT TYPE";
		private static final String CONST_ORG_PAY_BATCH_NUM = "ORIGINAL PAYMENT BATCH NUMBER";
		private static final String CONST_ORG_PAY_DATE = "ORIGINAL PAYMENT DATE";
		private static final String CONST_RET_PAY_DATE = "RETURN PAYMENT DATE";
		private static final String CONST_RETURN_REASON = "RETURN REASON";
		
		private static final String CONST_ITEM_COUNT = "BATCH ITEM COUNT";
		private static final String CONST_DEP_AMT = "BATCH DEPOSIT AMOUNT";
		private static final String CONST_BATCH_COUNT = "BATCH COUNT";
		private static final String CONST_FILE_DEP_AMT = "TOTAL DEPOSIT AMOUNT";

		//FILE HEADER 
		private static final String FILE_HEADER_RECORD_TYPE = "A";
		private static final int FILE_DATE_INDEX = 34;
		private static final int FILE_DATE_LENGTH = 15;
		private static final int FILE_BANK_NAME_INDEX = 16;
		private static final int FILE_BANK_NAME_LENGTH = 17;

		//BATCH HEADER
		private static final String BATCH_HEADER_RECORD_TYPE = "B";
		private static final int BATCH_NUMBER_INDEX = 1;
		private static final int BATCH_NUMBER_LENGTH = 5;

		//DETAIL RECORD
		private static final String DETAILS_RECORD_TYPE = "C";
		private static final int ACCOUNT_ID_INDEX = 6;
		private static final int ACCOUNT_ID_LENGTH = 10;
		private static final int AMOUNT_PAID_INDEX = 16;
		private static final int AMOUNT_PAID_LENGTH = 10;
		private static final int PAY_TYPE_CODE_INDEX = 26;
		private static final int PAY_TYPE_CODE_LENGTH = 1;
		private static final int ORG_PAY_BATCH_NUM_INDEX = 27;
		private static final int ORG_PAY_BATCH_NUM_LENGTH = 5;
		private static final int ORG_PAY_DATE_INDEX = 32;
		private static final int ORG_PAY_DATE_LENGTH = 6;
		private static final int RET_PAY_DATE_INDEX = 38;
		private static final int RET_PAY_DATE_LENGTH = 6;
		private static final int RETURN_REASON_INDEX = 44;
		private static final int RETURN_REASON_LENGTH = 3;
		private static final int EXT_PAY_ID_INDEX = 47;
		private static final int EXT_PAY_ID_LENGTH = 30;
		private static final int CUST_NAME_INDEX = 77;
		private static final int CUST_NAME_LENGTH = 40;
		private static final int CUST_ADRS_INDEX = 117;
		private static final int CUST_ADRS_LENGTH = 30;
		private static final int SEQUENCE_NUMBER_INDEX = 1;
		private static final int SEQUENCE_NUMBER_LENGTH = 5;

		//BATCH TRAILER
		private static final String BATCH_TRAILER_RECORD_TYPE = "D";
		private static final int BATCH_ITEM_COUNT_INDEX = 6;
		private static final int BATCH_ITEM_COUNT_LENGTH = 5;
		private static final int BATCH_DEPOSIT_AMT_INDEX = 11;
		private static final int BATCH_DEPOSIT_AMT_LENGTH = 12;

		//FILE TRAILER
		private static final String FILE_TRAILER_RECORD_TYPE = "E";
		private static final int TOTAL_BATCH_COUNT_INDEX = 16;
		private static final int TOTAL_BATCH_COUNT_LENGTH = 4;
		private static final int TOTAL_ITEM_COUNT_INDEX = 20;
		private static final int TOTAL_ITEM_COUNT_LENGTH = 6;
		private static final int TOTAL_DEPOSIT_AMT_INDEX = 26;
		private static final int TOTAL_DEPOSIT_AMT_LENGTH = 14;

		//Switches to check the order of processing is right
		private Bool isFileHeaderRead = Bool.FALSE;
		private Bool isBatchHeaderRead = Bool.FALSE;
		private Bool isBatchTrailerRead = Bool.FALSE;
		private Bool isFileTrailerRead = Bool.FALSE;


		/**
		 * This method identifies the execution strategy to be used for the thread.
		 * 
		 * @return an instance of ThreadExecutionStrategy that governs how this ThreadWorker will be executed at runtime.
		 * @see com.splwg.base.api.batch.ThreadWorker#createExecutionStrategy()
		 */
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new SingleTransactionStrategy(this);
		}

		/**
		 * Perform any initialization that must be done at the start of this thread processing work. 
		 * @param initializationPreviouslySuccessful - indicates that this method was called successfully called during some 
		 * prior execution, presumably because this is a restart situation.
		 * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
		 * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
		 * @see com.splwg.base.api.batch.ThreadWorker#initializeThreadWork(boolean) 
		 */
		public void initializeThreadWork(boolean initializationPreviouslySuccessful)
		throws ThreadAbortedException, RunAbortedException {
		    
		    JobParameters parameters = getParameters();
		    parmMaxErrors = parameters.getMAX_ERRORS();	                  
		    parmFilePath = parameters.getFILE_PATH().trim();
		    parmFileName = parameters.getFILE_NAME().trim();
		    inputFile = new File(parmFilePath, parmFileName);
		    parmNotificationType = parameters.getNOTIFICATION_TYPE();
		    parmAcctIdNotificationContextType = parameters.getACCT_ID_NT_CTXT_TYPE();
		    parmAmountPaidNotificationContextType = parameters.getAMT_PAID_NT_CTXT_TYPE();
		    parmPayTypeNotificationContextType = parameters.getPAY_TYPE_NT_CTXT_TYPE();
		    parmOriginalPayBatchNumberNotificationContextType = parameters.getORG_PAY_BATCH_NUM_CTXT_TYPE();
		    parmOrgPayDateNotificationContextType = parameters.getORG_PAY_DATE_NT_CTXT_TYPE();
		    parmReturnPayDateNotificationContextType = parameters.getRETRN_PAY_DATE_NT_CTXT_TYPE();
		    parmReturnReasonNotificationContextType = parameters.getRETRN_REASON_NT_CTXT_TYPE();
		    parmExternalPayIdNotificationContextType = parameters.getEXT_PAY_ID_NT_CTXT_TYPE();
		    parmCustomerNameNotificationContextType = parameters.getCUST_NAME_NT_CTXT_TYPE();
		    parmCustomerAddressNotificationContextType = parameters.getCUST_ADRSS_NT_CTXT_TYPE();
		    parmDataRetentionDays = parameters.getRETENTION_DAYS();
		    
		}

		/**
		 * Execute a WorkUnit and provide result details.
		 * 
		 * @param unit - a ThreadWorkUnit
		 * @return a boolean that describes the success or failure of the work unit processing.
		 * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
		 * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
		 * @see com.splwg.base.api.batch.ThreadWorker#executeWorkUnitDetailedResult(com.splwg.base.api.batch.ThreadWorkUnit)
		 */
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
		throws ThreadAbortedException, RunAbortedException {

			processFile();

			// Log Total Number of Records Processed and Total Amount of Payment Processed
			logMessage(CustomMessageRepository.ni0019_5TotalNumberOfRecordsProcessed(String.valueOf(totalFileRecordCount)), MessageSeverityLookup.constants.INFORMATIONAL);
			logMessage(CustomMessageRepository.ni0019_5TotalPaymentAmountProcessed(String.valueOf(totalBatchDepositAmt)), MessageSeverityLookup.constants.INFORMATIONAL);

			WorkUnitResult workUnitResult = new WorkUnitResult(true);
			workUnitResult.setUnitsProcessed(totalFileRecordCount);
			workUnitResult.setUnitsInError(numberOfRecordsInError.intValue());

			closeFile();
			return workUnitResult;
		}

		private void processFile(){

			//Delete the records in the Payment Returns Table
			//whose file date is less than the retention date
			deletePayReturnRecords();
			// Open File to read detail records. 
			openFile();
			String detailRecord = null;

			while(notNull(detailRecord = readRecord())){  

				//Increment line counter
				lineCounter = lineCounter.add(BigInteger.ONE);
				//kl20130403 - Fix for Defect - partial file was being committed which should not happen
				//setSavepoint(SAVE_POINT);

				try{
					processRecords(detailRecord);
				}catch(ApplicationError ae){
					//kl20130403 - Fix for Defect - partial file was being committed which should not happen
					//rollbackToSavepoint(SAVE_POINT);

					if(isNull(ae.getServerMessage().getMessageText())){
						numberOfRecordsInError = numberOfRecordsInError.add(BigInteger.ONE);
						addError(CustomMessageRepository.ni0019_5ErrorInFile(ae.getMessage().trim()));
					}else{
						numberOfRecordsInError = numberOfRecordsInError.add(BigInteger.ONE);
						addError(CustomMessageRepository.ni0019_5ErrorInFile(ae.getServerMessage().getMessageText().trim()));
					}
				}
			}
			//kl20130403 - Added logic to error out if file has been partially processed
			if(isFileTrailerRead.isFalse()){
				lineCounter = lineCounter.add(BigInteger.ONE);
				addError(CustomMessageRepository.ni0019_5IncompleteRunDueToErrorInFile(lineCounter.toString()));  
			}
		}

		/**
		 * This Method will process each record present in the Payment Return file.
		 * @param detailRecord
		 */
		private void processRecords(String detailRecord){
			String recordType = getFieldValue(detailRecord,RECORD_TYPE_INDEX,RECORD_TYPE_LENGTH).trim();
			validateField(recordType, CONST_RECORD_TYPE, RECORD_TYPE_INDEX+1, RECORD_TYPE_INDEX+RECORD_TYPE_LENGTH);

			if(recordType.equalsIgnoreCase(FILE_HEADER_RECORD_TYPE)){
				processFileHeader(detailRecord);

			}else if(recordType.equalsIgnoreCase(BATCH_HEADER_RECORD_TYPE)){
				processBatchHeader(detailRecord);

			}else if(recordType.equalsIgnoreCase(DETAILS_RECORD_TYPE)){
				processDetailsRecord(detailRecord);
				insertIntoPayReturnTable(detailRecord);

			}else if(recordType.equalsIgnoreCase(BATCH_TRAILER_RECORD_TYPE)){
				processBatchTrailer(detailRecord);

			}else if(recordType.equalsIgnoreCase(FILE_TRAILER_RECORD_TYPE)){
				processFileTrailer(detailRecord);

			}else{
				addError(CustomMessageRepository.ni0019_5InvalidRecordType(lineCounter.toString(), recordType));
			}

		}

		/**
		 * This Method will process the File Header Record, to fetch and validate the file date.
		 * @param record
		 */
		private void processFileHeader(String record){

			fileDateStr = getFieldValue(record, FILE_DATE_INDEX, FILE_DATE_LENGTH).trim();
			validateField(fileDateStr, CONST_FILE_DATE, FILE_DATE_INDEX+1, FILE_DATE_INDEX+FILE_DATE_LENGTH);

			fileBankNameStr = getFieldValue(record, FILE_BANK_NAME_INDEX, FILE_BANK_NAME_LENGTH).trim();
			validateField(fileBankNameStr, CONST_BANK_NAME, FILE_BANK_NAME_INDEX+1, FILE_BANK_NAME_INDEX+FILE_BANK_NAME_LENGTH);
			
			notificationExternalId = new NotificationExternalId_Id(fileBankNameStr);
			if(isNull(notificationExternalId.getEntity())){
				// Raise error message "No corresponding External System configured for Bank Name %1."
				addError(CustomMessageRepositoryMGE.ccb031_noExternalSystem(fileBankNameStr));
			}			
			
			// Deposit DateTime must be a valid DateTime.
			convertFileDateStringToDateTimeFormat(fileDateStr);
			isFileHeaderRead = Bool.TRUE;
			
			isBatchProcessed();
		}

		/**
		 * This Method will process the BAtch Header Record, to fetch and validate the Batch Number.
		 * @param record
		 */private void processBatchHeader(String record){

			 //To check that the File Header is processed first.
			 if(isFileHeaderRead.isFalse() || isFileTrailerRead.isTrue()){
				 addError(CustomMessageRepository.ni0019_5InvalidRecordTypeOrder());
			 }

			 batchNumber = getFieldValue(record, BATCH_NUMBER_INDEX, BATCH_NUMBER_LENGTH);
			 validateField(batchNumber, CONST_BATCH_NUM, BATCH_NUMBER_INDEX+1, BATCH_NUMBER_INDEX+BATCH_NUMBER_LENGTH);

			 batchAmount = BigDecimal.ZERO;
			 count = 0;
			 isBatchHeaderRead = Bool.TRUE;
		 }

		 /**
		  * This Method will process the Detail record present in the File.
		  * It will Fetch the Required Fields and validate them.
		  * It will create the notification upload staging records.
		  * @param record
		  */
		 private void processDetailsRecord(String record){

			 //To check that the File & Batch Headers are processed first.
			 if(isFileHeaderRead.isFalse() || isBatchHeaderRead.isFalse() || isFileTrailerRead.isTrue()){
				 addError(CustomMessageRepository.ni0019_5InvalidRecordTypeOrder());
			 }

			 String accountIdStr = getFieldValue(record, ACCOUNT_ID_INDEX, ACCOUNT_ID_LENGTH);
			 validateField(accountIdStr, CONST_ACCOUNT_ID, ACCOUNT_ID_INDEX+1, ACCOUNT_ID_INDEX+ACCOUNT_ID_LENGTH);

			 String amountPaidStr = getFieldValue(record, AMOUNT_PAID_INDEX, AMOUNT_PAID_LENGTH);
			 validateField(amountPaidStr, CONST_AMOUNT_PAID, AMOUNT_PAID_INDEX+1, AMOUNT_PAID_INDEX+AMOUNT_PAID_LENGTH);
			 BigInteger inputAmount = checkAndConvertStringToBigInteger(amountPaidStr); //used to validate number format

			 BigDecimal amount = new BigDecimal(inputAmount);

			 if(amount.compareTo(BigDecimal.ZERO)!=0){
				 amount = amount.divide(new BigDecimal(100), 2, BigDecimal.ROUND_FLOOR);
			 }

			 batchAmount = batchAmount.add(amount);

			 String inputPayTypeCode = getFieldValue(record, PAY_TYPE_CODE_INDEX, PAY_TYPE_CODE_LENGTH);
			 validateField(inputPayTypeCode, CONST_PAY_TYPE, PAY_TYPE_CODE_INDEX+1, PAY_TYPE_CODE_INDEX+PAY_TYPE_CODE_LENGTH);
			 if(!isEmptyOrNull(inputPayTypeCode.trim())){
				 String payTypeCodeVal = "X"+inputPayTypeCode;
				 if(!LookupHelper.getLookupInstance(CmPaymentTypeLookup.class, payTypeCodeVal).isValidLookupValue()){
					 addError(CustomMessageRepository.ni0019_5InvalidPayTypeCodeInFile(inputPayTypeCode, lineCounter.toString().trim()));
				 }
			 }
			 
			 String orgPayBatchNumStr = getFieldValue(record, ORG_PAY_BATCH_NUM_INDEX, ORG_PAY_BATCH_NUM_LENGTH);
			 validateField(orgPayBatchNumStr, CONST_ORG_PAY_BATCH_NUM, ORG_PAY_BATCH_NUM_INDEX+1, ORG_PAY_BATCH_NUM_INDEX+ORG_PAY_BATCH_NUM_LENGTH);
			 orgPayBatchNum = checkAndConvertStringToBigInteger(orgPayBatchNumStr);

			 String orgPayDateStr = getFieldValue(record, ORG_PAY_DATE_INDEX, ORG_PAY_DATE_LENGTH);
			 validateField(orgPayDateStr, CONST_ORG_PAY_DATE, ORG_PAY_DATE_INDEX+1, ORG_PAY_DATE_INDEX+ORG_PAY_DATE_LENGTH);
			 convertFileDateStringToDateFormat(orgPayDateStr, CONST_ORG_PAY_DATE);

			 String returnPayDateStr = getFieldValue(record, RET_PAY_DATE_INDEX, RET_PAY_DATE_LENGTH);
			 validateField(returnPayDateStr, CONST_RET_PAY_DATE, RET_PAY_DATE_INDEX+1, RET_PAY_DATE_INDEX+RET_PAY_DATE_LENGTH);
			 convertFileDateStringToDateFormat(returnPayDateStr, CONST_RET_PAY_DATE);

			 String returnReason = getFieldValue(record, RETURN_REASON_INDEX, RETURN_REASON_LENGTH);
			 validateField(returnReason, CONST_RETURN_REASON, RETURN_REASON_INDEX+1, RETURN_REASON_INDEX+RETURN_REASON_LENGTH);
			 
			 String extPayId = getFieldValue(record, EXT_PAY_ID_INDEX, EXT_PAY_ID_LENGTH);
			 
			 String customerName = getFieldValue(record, CUST_NAME_INDEX, CUST_NAME_LENGTH);
			 
			 String customerAddress = getFieldValue(record, CUST_ADRS_INDEX, CUST_ADRS_LENGTH);
			 
			 try{
				 startChanges();
				 createNotificationUpload();
				 createContextRecord(parmAcctIdNotificationContextType, accountIdStr);
				 createContextRecord(parmAmountPaidNotificationContextType, amount.toString());
				 createContextRecord(parmPayTypeNotificationContextType, inputPayTypeCode);
				 createContextRecord(parmOriginalPayBatchNumberNotificationContextType, orgPayBatchNum.toString());
				 createContextRecord(parmOrgPayDateNotificationContextType, orgPayDateStr);
				 createContextRecord(parmReturnPayDateNotificationContextType, returnPayDateStr);
				 createContextRecord(parmReturnReasonNotificationContextType, returnReason);
				 
				 if(notBlank(extPayId)){
					 createContextRecord(parmExternalPayIdNotificationContextType, extPayId);
				 }
				 if(notBlank(customerName)){
					 createContextRecord(parmCustomerNameNotificationContextType, customerName);
				 }
				 if(notBlank(customerAddress)){
					 createContextRecord(parmCustomerAddressNotificationContextType, customerAddress);
				 }
				 saveChanges();
			 }catch(ApplicationError ae){
				 addError(CustomMessageRepository.ni0019_5RecordInError(lineCounter.toString().trim(), ae.getServerMessage().getMessageText()));
			 }
			 count++;
		 }

		 /**
		  * This Method will fetch and validate the Batch Item Count, Batch Deposit Amount
		  * with the total number of records and total payment amount of records in the batch. 
		  * @param record
		  */
		 private void processBatchTrailer(String record){

			 //To Check that the File & Batch Headers are processed before processing the batch trailer.
			 if(isFileHeaderRead.isFalse() || isBatchHeaderRead.isFalse() || isFileTrailerRead.isTrue()){
				 addError(CustomMessageRepository.ni0019_5InvalidRecordTypeOrder());
			 }

			 String batchitemCountStr = getFieldValue(record, BATCH_ITEM_COUNT_INDEX, BATCH_ITEM_COUNT_LENGTH);
			 validateField(batchitemCountStr, CONST_ITEM_COUNT, BATCH_ITEM_COUNT_INDEX+1, BATCH_ITEM_COUNT_INDEX+BATCH_ITEM_COUNT_LENGTH);
			 batchTrailerRecordCount = checkAndConvertStringToBigInteger(batchitemCountStr).intValue();
			 if (batchTrailerRecordCount != count){
				 addError(CustomMessageRepository.ni0019_5RecordCountInBatchTrailerAndTotalRecordCountIsNotSame(batchitemCountStr, 
						 String.valueOf(count), batchNumber));
			 }

			 String batchdepositAmountStr = getFieldValue(record, BATCH_DEPOSIT_AMT_INDEX, BATCH_DEPOSIT_AMT_LENGTH);
			 validateField(batchdepositAmountStr, CONST_DEP_AMT, BATCH_DEPOSIT_AMT_INDEX+1, BATCH_DEPOSIT_AMT_INDEX+BATCH_DEPOSIT_AMT_LENGTH);
			 checkAndConvertStringToBigInteger(batchdepositAmountStr);
			 batchDepositAmount = new BigDecimal(batchdepositAmountStr);

			 if(batchDepositAmount.compareTo(BigDecimal.ZERO)!=0){
				 batchDepositAmount = batchDepositAmount.divide(new BigDecimal(100), 2, BigDecimal.ROUND_FLOOR);
			 }

			 if(batchAmount.compareTo(batchDepositAmount) !=0){
				 addError(CustomMessageRepository.ni0019_5AmountInBatchTrailerAndTotalAmountInRecordsNotSame(batchDepositAmount.toString(),
						 batchAmount.toString(), batchNumber));
			 }

			 totalBatchCount++;
			 totalFileRecordCount = totalFileRecordCount + count;
			 totalBatchDepositAmt = totalBatchDepositAmt.add(batchAmount); 
			 isBatchTrailerRead = Bool.TRUE;
		 }

		 /**
		  * This Method will fetch and validate the Batch Count, Deposit Amount and item count with the
		  * total number of batches, total number of records and total payment amount of records in the File. 
		  * @param record
		  */private void processFileTrailer(String record){

			  //To Check whether there are any unclosed batch records or the file and batch headers are processed first.
			  //KL20130426 - Fix for Defect 700: Removed Batch Header & trailer check to process no data file.
			  if(isFileHeaderRead.isFalse()){ 
				  addError(CustomMessageRepository.ni0019_5InvalidRecordTypeOrder());
			  }

			  String fileTrailerBatchCountStr = getFieldValue(record, TOTAL_BATCH_COUNT_INDEX, TOTAL_BATCH_COUNT_LENGTH);
			  validateField(fileTrailerBatchCountStr, CONST_BATCH_COUNT, TOTAL_BATCH_COUNT_INDEX+1, TOTAL_BATCH_COUNT_INDEX+TOTAL_BATCH_COUNT_LENGTH);
			  fileTrailerBatchCount = checkAndConvertStringToBigInteger(fileTrailerBatchCountStr).intValue();
			  if (totalBatchCount != fileTrailerBatchCount){
				  addError(CustomMessageRepository.ni0019_5BatchCountInFileTrailerAndTotalBatchCountIsNotSame(fileTrailerBatchCountStr, String.valueOf(totalBatchCount)));
			  }

			  String fileTrailerRecordCountStr = getFieldValue(record, TOTAL_ITEM_COUNT_INDEX, TOTAL_ITEM_COUNT_LENGTH);
			  validateField(fileTrailerRecordCountStr, CONST_ITEM_COUNT, TOTAL_ITEM_COUNT_INDEX+1, TOTAL_ITEM_COUNT_INDEX+TOTAL_ITEM_COUNT_LENGTH);
			  fileTrailerRecordCount = checkAndConvertStringToBigInteger(fileTrailerRecordCountStr).intValue();
			  if(fileTrailerRecordCount !=totalFileRecordCount){
				  addError(CustomMessageRepository.ni0019_5RecordCountInFileTrailerAndTotalRecordCountIsNotSame(
						  fileTrailerRecordCountStr, String.valueOf(totalFileRecordCount)));
			  }

			  String totalDepositAmountStr = getFieldValue(record, TOTAL_DEPOSIT_AMT_INDEX, TOTAL_DEPOSIT_AMT_LENGTH);
			  validateField(totalDepositAmountStr, CONST_FILE_DEP_AMT, TOTAL_DEPOSIT_AMT_INDEX+1, TOTAL_DEPOSIT_AMT_INDEX+TOTAL_DEPOSIT_AMT_LENGTH);
			  checkAndConvertStringToBigInteger(totalDepositAmountStr);
			  BigDecimal totalDepositAmount = new BigDecimal(totalDepositAmountStr);

			  if(totalDepositAmount.compareTo(BigDecimal.ZERO)!=0){
				  totalDepositAmount = totalDepositAmount.divide(new BigDecimal(100), 2, BigDecimal.ROUND_FLOOR);
			  }

			  if(totalBatchDepositAmt.compareTo(totalDepositAmount) != 0){
				  addError(CustomMessageRepository.ni0019_5AmountInFileTrailerAndTotalAmountInRecordsIsNotSame(
						  totalDepositAmountStr, totalBatchDepositAmt.toString()));
			  }

			  isFileTrailerRead = Bool.TRUE;
		  }

		  /**
		   * This method opens a buffered reader for input file
		   *
		   */
		  private void openFile() {

			  try {                          
				  inputBufferReader = new BufferedReader(new FileReader(inputFile));                    
			  } catch (IOException e) {                
				  throw new RunAbortedException(CustomMessageRepository.ni0019_5ErrorInFile(e.getMessage().trim()));                                     
			  } 
		  }


		  /**
		   * This method closes a buffered reader for input file
		   *
		   */
		  private void closeFile() {

			  try {
				  if(notNull(inputBufferReader))
					  inputBufferReader.close();           
			  } catch (IOException e) {
				  throw new RunAbortedException(CustomMessageRepository.ni0019_5ErrorInFile(e.getMessage().trim()));                                      
			  }
		  }        

		  /**
		   * This method returns the next record from the input file.
		   * @return a String object.
		   */
		  private String readRecord() {

			  String record = null;
			  try {
				  record =  inputBufferReader.readLine();                 
			  } catch (IOException exception) {

				  throw new RunAbortedException(CustomMessageRepository.ni0019_5ErrorInFile(exception.getMessage().trim()));
			  }  
			  return record;
		  }

		  /**
		   * This method retrieves the trimmed field value from the record starting 
		   * from the startPos and of the given length.
		   * @param record
		   * @param startPos
		   * @param length
		   * @return
		   */private String getFieldValue(String record, int startPos, int length) {

			   String value = "";
			   if(record.length() >= startPos+length){
				   value = record.substring(startPos, startPos+length).trim();
			   }
			   return value;
		   }

		   /**
		    * Convert the input fileDateString to the Date in the given date format.
		    * @param fileDate
		    */
		   private void convertFileDateStringToDateTimeFormat(String fileDateStr){

			   try{
				   fileDateTime = DateTime.fromString(fileDateStr, new DateFormat(DATETIME_FORMAT_MMDDYYYYHHMMSS));
			   } catch (DateFormatParseException e) {
				   addError(CustomMessageRepository.ni0019_5InvalidDate(lineCounter.toString(), 
						   CONST_FILE_DATE, fileDateStr.trim(), DATETIME_FORMAT_MMDDYYYYHHMMSS));
			   }
		   }

		   /**
		    * Convert the input fileDateString to the Date in the given date format.
		    * @param fileDate
		    */
		   private Date convertFileDateStringToDateFormat(String fileDate, String fieldName){

			   Date date = null;
			   try{
				   date = Date.fromString(fileDate, new DateFormat(DATE_FORMAT_RECORD));
			   } catch (DateFormatParseException e) {
				   addError(CustomMessageRepository.ni0019_5InvalidDate(lineCounter.toString(), 
						   fieldName, fileDate.trim(), DATE_FORMAT_RECORD));
			   }
			   return date;
		   }

		   /**
		    * Convert the given string value to BigInteger and 
		    * also checks whether the input string is a valid number.
		    * @param value
		    * @return
		    */private BigInteger checkAndConvertStringToBigInteger(String value){

		    	BigInteger number = BigInteger.ZERO;
		    	try{
		    		number = new BigInteger(value);
		    	}catch(NumberFormatException e){
		    		addError(CustomMessageRepository.ni0019_5NumberFormatException(lineCounter.toString(), value));
		    	}
		    	return number;
		    }

		    /**
		     * This method will check whether the Batch with the 
		     * batch number and file date combination
		     * is already processed.
		     *
		     */
		    private void isBatchProcessed(){

		    	StringBuilder batchProcessesQueryStr = new StringBuilder();

		    	batchProcessesQueryStr.append(" SELECT 'X' ");
		    	batchProcessesQueryStr.append(" FROM CI_NT_UP ");
		    	batchProcessesQueryStr.append(" WHERE NT_XID_CD = :extSystem ");
		    	batchProcessesQueryStr.append(" AND CRE_DTTM = :fileDate ");
		    	PreparedStatement batchProcessesPrepStmt = createPreparedStatement(batchProcessesQueryStr.toString(), getClass().getName());
		    	batchProcessesPrepStmt.bindDateTime("fileDate", fileDateTime);
		    	batchProcessesPrepStmt.bindId("extSystem", notificationExternalId);
		    	if(notNull(batchProcessesPrepStmt.firstRow())){
		    		addError(CustomMessageRepositoryMGE.ccb031_bankNameFileDateProcessed(fileBankNameStr, fileDateTime.toString()));
		    	}
		    	batchProcessesPrepStmt.close();
		    }

		    private void createNotificationUpload(){

		    	//Create and insert Notification Upload record
		    	NotificationUpload_DTO notificationUploadDto = createDTO(NotificationUpload.class);
		    	notificationUploadDto.setCreationDateTime(fileDateTime);
		    	notificationUploadDto.setNotificationUploadTypeId(parmNotificationType.getId());
		    	notificationUploadDto.setNotificationExternalId(notificationExternalId);
		    	notificationUploadDto.setNotificationStatus(NotificationUploadStatusLookup.constants.PENDING);
		    	notificationUploadDto.setNotificationUploadExtension(NotificationUploadExtensionLookup.constants.NO_EXTENSION);

		    	notificationUpload = notificationUploadDto.newEntity();
		    }

		    private void createContextRecord(NotificationUploadContextLookup notificationUploadContextType, String contextValue){

		    	//Create and insert Notification Upload Context record
		    	NotificationUploadContext_DTO notificationUploadContextDTO = new NotificationUploadContext_DTO();
		    	notificationUploadContextDTO.setId(new NotificationUploadContext_Id(notificationUpload, notificationUploadContextType, contextValue));
		    	notificationUploadContextDTO.newEntity();
		    }

		    /**\
		     * Validate the given field value whether the field value is blank,
		     * if yes log an error and terminate the process.
		     * @param value
		     * @param name
		     * @param startPos
		     * @param endPos
		     */private void validateField(String value, String name, int startPos, int endPos){
		    	 if(isBlankOrNull(value)){
		    		 addError(CustomMessageRepository.ni0019_5MandatoryfieldIsBlank(
		    				 lineCounter.toString(), name,
		    				 String.valueOf(startPos),
		    				 String.valueOf(endPos+1)));
		    	 }
		     }


		     /**
		      * Perform final processing before ending the thread.
		      * 
		      * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
		      * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
		      * @see com.splwg.base.api.batch.ThreadWorker#finalizeThreadWork() 
		      */
		     public void finalizeThreadWork() 
		     throws ThreadAbortedException, RunAbortedException {

		    	 try {
		    		 if(notNull(inputBufferReader)){
		    			 inputBufferReader.close();                    
		    		 }
		    	 } catch (IOException exception) {

		    		 throw new RunAbortedException(CustomMessageRepository.ni0019_5ErrorInFile(exception.getMessage().trim()));
		    	 }
		     }
		     
		     /**
		      * This method delete records in CM_PMT_RETURN with 
		      * FILE_DATE <= (batch process date time - Parameter Data Retention Days value)
		      */
		     private void deletePayReturnRecords() {
		    	 DateTime retentionDate = getProcessDateTime().addDays(parmDataRetentionDays.intValue()*-1);

		    	 StringBuilder sb = new StringBuilder();
		    	 sb.append("DELETE ");
		    	 sb.append(  "FROM CM_PMT_RETURN ");
		    	 sb.append("WHERE FILE_DATE <= :retentionDate ");

		    	 PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
		    	 ps.bindDateTime("retentionDate", retentionDate);
		    	 ps.execute();
		    	 ps.close();
		     }
		     
		     /**
			    * This method will insert record in CM_PMT_RETURN using the file record.
			    * @param record
			    */
			   private void insertIntoPayReturnTable(String record) {
				   
				   String sequenceNumberRec = null;
				   String accountIdRec = null; 
				   String amountPaidRec = null;
				   String payTypeCodeRec = null;
				   String orgPayBatchNumStr = null;
				   String orgPayDateStr = null;
				   Date orgPayDate;
				   String returnPayDateStr = null;
				   Date returnPayDate;
				   String returnReason = null;
				   String extPaymentIdRec = null;
				   String customerNameRec = null;
				   String customerAddressRec = null;
				   BigDecimal amountPaid;
				   
				   sequenceNumberRec = getFieldValue(record, SEQUENCE_NUMBER_INDEX, SEQUENCE_NUMBER_LENGTH);
				   accountIdRec = getFieldValue(record, ACCOUNT_ID_INDEX, ACCOUNT_ID_LENGTH);
				   amountPaidRec = getFieldValue(record, AMOUNT_PAID_INDEX, AMOUNT_PAID_LENGTH);
				   payTypeCodeRec = getFieldValue(record, PAY_TYPE_CODE_INDEX, PAY_TYPE_CODE_LENGTH);
				   orgPayBatchNumStr = getFieldValue(record, ORG_PAY_BATCH_NUM_INDEX, ORG_PAY_BATCH_NUM_LENGTH);
				   orgPayDateStr = getFieldValue(record, ORG_PAY_DATE_INDEX, ORG_PAY_DATE_LENGTH);
				   orgPayDate = convertFileDateStringToDateFormat(orgPayDateStr, CONST_ORG_PAY_DATE);
				   returnPayDateStr = getFieldValue(record, RET_PAY_DATE_INDEX, RET_PAY_DATE_LENGTH);
				   returnPayDate = convertFileDateStringToDateFormat(returnPayDateStr, CONST_RET_PAY_DATE);
				   returnReason = getFieldValue(record, RETURN_REASON_INDEX, RETURN_REASON_LENGTH);
				   extPaymentIdRec = getFieldValue(record, EXT_PAY_ID_INDEX, EXT_PAY_ID_LENGTH);
				   customerNameRec = getFieldValue(record, CUST_NAME_INDEX, CUST_NAME_LENGTH);
				   customerAddressRec = getFieldValue(record, CUST_ADRS_INDEX, CUST_ADRS_LENGTH);
				   
				   try {
					   amountPaid = new BigDecimal(amountPaidRec);
					   amountPaid = amountPaid.divide(new BigDecimal(100), 2, BigDecimal.ROUND_FLOOR);
				   } catch (NumberFormatException e) {
					   amountPaid = BigDecimal.ZERO;
				   }
				   
				   // Insert Record
				   StringBuilder sb = new StringBuilder();
				   sb.append("INSERT INTO ");
				   sb.append(  "CM_PMT_RETURN ( ");
				   sb.append(    "BANK_NAME, ");
				   sb.append(    "FILE_DATE, ");
				   sb.append(    "BATCH_NUMBER, ");
				   sb.append(    "SEQUENCE_NUMBER, ");
				   sb.append(    "ACCOUNT_ID, ");
				   sb.append(    "AMOUNT_PAID, ");
				   sb.append(    "PAY_TYPE_CODE, ");
				   sb.append(    "ORG_PAY_BATCH_NUM, ");
				   sb.append(    "ORG_PAY_BATCH_DATE, ");
				   sb.append(    "RETURN_PAY_DATE, ");
				   sb.append(    "RETURN_REASON, ");
				   sb.append(    "EXT_PAYMENT_ID, ");
				   sb.append(    "CUSTOMER_NAME, ");
				   sb.append(    "CUSTOMER_ADDRESS ");
				   sb.append(  ") VALUES ( ");
				   sb.append(    ":bankName, ");
				   sb.append(    ":fileDate, ");
				   sb.append(    ":batchNumber, ");
				   sb.append(    ":sequenceNumber, ");
				   sb.append(    ":accountId, ");
				   sb.append(    ":amountPaid, ");
				   sb.append(    ":payTypeCode, ");
				   sb.append(    ":orgPayBatchNumStr, ");
				   sb.append(    ":orgPayDateStr, ");
				   sb.append(    ":returnPayDateStr, ");
				   sb.append(    ":returnReason, ");
				   sb.append(    ":extPaymentId, ");
				   sb.append(    ":customerName, ");
				   sb.append(    ":customerAddress ");
				   sb.append(  ") ");
				   
				   PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
				   ps.bindString("bankName", fileBankNameStr, getClass().getName());
				   ps.bindDateTime("fileDate", fileDateTime);
				   ps.bindString("batchNumber", batchNumber, getClass().getName());
				   ps.bindString("sequenceNumber", sequenceNumberRec, getClass().getName());
				   ps.bindString("accountId", accountIdRec, getClass().getName());
				   ps.bindBigDecimal("amountPaid", amountPaid);
				   ps.bindString("payTypeCode", payTypeCodeRec, getClass().getName());
				   ps.bindString("orgPayBatchNumStr", orgPayBatchNumStr, getClass().getName());
				   ps.bindDate("orgPayDateStr", orgPayDate);
				   ps.bindDate("returnPayDateStr", returnPayDate);
				   ps.bindString("returnReason", returnReason, getClass().getName());
				   ps.bindString("extPaymentId", extPaymentIdRec, getClass().getName());
				   ps.bindString("customerName", customerNameRec, getClass().getName());
				   ps.bindString("customerAddress", customerAddressRec, getClass().getName());
				   
				   ps.execute();
				   ps.close();
	  
			   }
	}

}
