/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Bill Simulation Batch
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2021-09-08   RDizon  CCB044. Initial Version.
 * 2021-11-12   NMendo  Defect 4615974. Fix issue when bill segment is
 *                      regenerated online.
 **************************************************************************/

package com.splwg.cm.domain.batch;

import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadIterationStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.StringId;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.BillStatusLookup;
import com.splwg.ccb.api.lookup.UnableToCompleteBillActionLookup;
import com.splwg.ccb.domain.admin.billCycle.entity.BillCycleSchedule;
import com.splwg.ccb.domain.admin.billCycle.entity.BillCycleSchedule_Id;
import com.splwg.ccb.domain.admin.billCycle.entity.BillCycle_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_DTO;
import com.splwg.ccb.domain.billing.data.BillCompletionInputData;
import com.splwg.ccb.domain.billing.data.BillCompletionOutputData;
import com.splwg.ccb.domain.common.data.CcbInstallationData;
import com.splwg.ccb.domain.common.installation.CcbInstallationHelper;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author RDizon
 *
@BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      toDoCreation = @ToDoCreation (drillKeyEntity = account,
 *            sortKeys = { "ACCT_ID"
 *                  , "BATCH_NBR"}),
 *      softParameters = { @BatchJobSoftParameter (name = billCycle, type = string)
 *            , @BatchJobSoftParameter (name = windowStartDate, type = date)
 *            , @BatchJobSoftParameter (name = billDate, required = true, type = date)
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = cisDivision,type = entity)})
 */

public class CmFreezeAndCompleteBillSimulationBatch extends
CmFreezeAndCompleteBillSimulationBatch_Gen {

    public Class<CmFreezeAndCompleteBillSimulationBatchWorker> getThreadWorkerClass() {
        return CmFreezeAndCompleteBillSimulationBatchWorker.class;
    }

    public static class CmFreezeAndCompleteBillSimulationBatchWorker extends
    CmFreezeAndCompleteBillSimulationBatchWorker_Gen {

        public static final Logger logger = LoggerFactory.getLogger(CmFreezeAndCompleteBillSimulationBatch.class);

        private String billCycle;
        private Date windowStartDate;
        private Date billDate;
        private CisDivision cisDivision;

        public ThreadExecutionStrategy createExecutionStrategy() {
            return new ThreadIterationStrategy(this);
        }

        @Override
        public void initializeThreadWork(
                boolean initializationPreviouslySuccessful)
                        throws ThreadAbortedException, RunAbortedException {

            billCycle = getParameters().getBillCycle();
            windowStartDate = getParameters().getWindowStartDate();
            billDate = getParameters().getBillDate();
            cisDivision = getParameters().getCisDivision();

            validateSoftParams();

            if (isBlankOrNull(billCycle)) {
                billCycle = getBillCycles();
            } else {
                billCycle = "'" + this.billCycle + "'";
            } 

            if (isBlankOrNull(billCycle)) {
                addError(CustomMessageRepositorySpireOne.CCB044_NoBillCycleFoundForWindowStartDate(windowStartDate.toLocalizedString()));
            } 

            startEntityQueryIteratorForThread(Account_Id.class);
        }

        private void validateSoftParams() {
            if (!isBlankOrNull(this.billCycle)) {
                BillCycle_Id billCycleId = new BillCycle_Id(this.billCycle);
                if (isNull(billCycleId.getEntity())) {
                    addError(CustomMessageRepositorySpireOne.CCB044_BatchParmInvalidBillCycle(billCycle));
                } 
            } 
        }

        private String getBillCycles() {
            String queryString = "FROM BillCycleSchedule billCycleSchedule WHERE billCycleSchedule.id.windowStartDate <= :businessDate  AND billCycleSchedule.windowEndDate >= :businessDate";

            Query<BillCycle_Id> query = createQuery(queryString, getClass().getName());
            query.bindDate("businessDate", getParameters().getProcessDate());

            if (logger.isDebugEnabled()) {
                logger.debug("Business Date =  " + getParameters().getProcessDate());
            }
            query.addResult("billCycleCd", "billCycleSchedule.id.billCycle.id");
            query.orderBy("billCycleCd");

            List<BillCycle_Id> queryResult = query.list();
            StringBuffer billCycleCds = new StringBuffer();
            for (Iterator<BillCycle_Id> iter = queryResult.iterator(); iter.hasNext(); ) {
                BillCycle_Id billCycleId = (BillCycle_Id)iter.next();
                billCycleCds.append("'" + billCycleId.getIdValue() + "'");
                if (iter.hasNext()) billCycleCds.append(", "); 
            } 
            return billCycleCds.toString();
        }
        
        protected QueryIterator<Account> getQueryIteratorForThread(StringId lowId, StringId highId) {
            Query<Account> query = createQuery(getQueryStringForThread(), getClass().getName());
            
            query.bindId("lowId", lowId);
            query.bindId("highId", highId);

            query.bindLookup("billStatusFlag", BillStatusLookup.constants.PENDING);
            if (!isNull(windowStartDate)) {
                query.bindDate("windowStartDate", windowStartDate);
            }
            if (!isNull(cisDivision)){
                query.bindId("cisDivision", cisDivision.getId());
            }
            
            query.addResult("account", "account");
            query.orderBy("account");

            return query.iterate();
        }

        private String getQueryStringForThread() {
            StringBuilder queryString = new StringBuilder();
            queryString.append(" FROM Account account WHERE account.billCycleId IN ( " + billCycle + ") ");
            queryString.append(" AND account.id between :lowId and :highId ");
            queryString.append(" AND exists ( select bill.account.id FROM Bill bill WHERE bill.account.id = account.id ");
            queryString.append(" AND bill.billStatus = :billStatusFlag ");

            if (!isNull(windowStartDate)) {
                queryString.append(" AND bill.billCycleScheduleId.windowStartDate = :windowStartDate ) ");
            } else {
                queryString.append(" ) ");
            } 
            
            if (!isNull(cisDivision)){
                queryString.append(" AND account.divisionId = :cisDivision ");
            }

            return queryString.toString();
        }
        
        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {

            Account_Id accountId = (Account_Id)unit.getPrimaryId();

            if (logger.isDebugEnabled()) {
                logger.debug("Account Id " + accountId.getIdValue());
            }
            
            Bill_Id billId = getPendingBill(accountId);

            if (!isNull(billId)) {
                if (logger.isDebugEnabled()) {
                    logger.debug("Processing " + billId);
                }
                
                // Start Add - NMendo - Defect 4615974 - 2021-11-12
                updateBillSegment(billId);
                // End Add - NMendo - Defect 4615974 - 2021-11-12
                
                freezeAndCompleteBill(billId);
            } 
            return true;
        }
        
        // Start Add - NMendo - Defect 4615974 - 2021-11-12
        /**
         * This method update the bill cycle of bill segment/s of the bill, 
         * if the bill cycle on the bill is not the same with the bill cycle on the bill segment.
         * @param billId
         */
        private void updateBillSegment(Bill_Id billId) {
        	Bill bill = billId.getEntity();
        	BillCycleSchedule_Id billCycleId = bill.getBillCycleScheduleId();
        	
        	StringBuilder sb = new StringBuilder();
        	sb.append("SELECT BS.BSEG_ID ");
        	sb.append("FROM CI_BILL B, CI_BSEG BS ");
        	sb.append("WHERE B.BILL_ID = :billId ");
        	sb.append("AND B.BILL_ID = BS.BILL_ID ");
        	sb.append("AND B.BILL_CYC_CD <> BS.BILL_CYC_CD ");
        	
        	PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
            ps.bindId("billId", billId);
            
            QueryIterator<SQLResultRow> bsegIter = ps.iterate();
            while(bsegIter.hasNext()) {
            	BillSegment bseg = bsegIter.next().getEntity("BSEG_ID", BillSegment.class);
            	BillSegment_DTO bsegDto = bseg.getDTO();
            	bsegDto.setBillCycleScheduleId(billCycleId);
            	bseg.setDTO(bsegDto);
            }
            
            ps.close();
        }
        // End Add - NMendo - Defect 4615974 - 2021-11-12

        private Bill_Id getPendingBill(Account_Id accountId) {
            Bill_Id billId = null;
            String queryString = "FROM Bill bill WHERE bill.billCycleScheduleId.billCycleId = :accountBillCycle  AND bill.account.id = :accountId AND bill.billStatus = :billStatusFlag ";

            if (!isNull(getParameters().getWindowStartDate())) {
                queryString = queryString + " AND bill.billCycleScheduleId.windowStartDate = :windowStartDate";
            }

            Query<QueryResultRow> query = createQuery(queryString, getClass().getName());
            query.bindId("accountBillCycle", ((Account)accountId.getEntity()).getBillCycleId());
            query.bindId("accountId", accountId);
            query.bindLookup("billStatusFlag", BillStatusLookup.constants.PENDING);
            if (!isNull(getParameters().getWindowStartDate()))
                query.bindDate("windowStartDate", getParameters().getWindowStartDate());
            
            query.addResult("billId", "bill.id");
            query.addResult("accountId", "bill.account.id");
            QueryResultRow row = (QueryResultRow)query.firstRow();

            if (!isNull(row) && !isNull(row.get("billId"))) {
                billId = (Bill_Id)row.get("billId");
                if (skipBill(billId)) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("Skipping bill " + billId.getIdValue());
                    }
                    billId = null;
                }

            } else if (logger.isDebugEnabled()) {
                logger.debug(accountId + " has no pending bills.");
            } 

            return billId;
        }
        
        private BillCompletionOutputData freezeAndCompleteBill(Bill_Id billId) {
            CcbInstallationData ccbInstallationData = CcbInstallationHelper.getCcbInstallation();
            BillCompletionOutputData billCompletionOutputData = BillCompletionOutputData.Factory.newInstance();

            Bill bill = (Bill)billId.getEntity();
            BillCycleSchedule billCycleSchedule = bill.fetchBillCycleSchedule();
            
            Date accountingDate = billCycleSchedule.getAccountingDate();

            if (ccbInstallationData.getAccountingDateFreezeOption().isAlwaysChange()) {
                accountingDate = getProcessDateTime().getDate();
            }

            if (ccbInstallationData.getBillSegmentFreezeOption().isFreezeAtWill()) {
                bill.freeze(accountingDate);
            }

            BillCompletionInputData billCompletionInputData = BillCompletionInputData.Factory.newInstance();

            billCompletionInputData.setAccountingDate(accountingDate);
            billCompletionInputData.setBillCycle(bill.getBillCycleScheduleId().getBillCycle());
            billCompletionInputData.setBillDate(getParameters().getBillDate());
            if (getParameters().getThreadCount().intValue() == 1 && getBatchThreadNumber().intValue() == 1 && 
                    getParameters().getMaximumCommitRecords().intValue() == 1) {
                billCompletionInputData.setShouldAssignSequentialNumber(Bool.TRUE);
            } else {
                billCompletionInputData.setShouldAssignSequentialNumber(Bool.FALSE);
            } 
            billCompletionInputData
            .setUnableToCompleteBillAction(UnableToCompleteBillActionLookup.constants.SKIP_OR_DELETE_BILL);
            billCompletionInputData.setWindowEndDate(billCycleSchedule.getWindowEndDate());
            billCompletionInputData.setWindowStartDate(billCycleSchedule.fetchIdWindowStartDate());
            return bill.complete(billCompletionInputData);
        }
        
        private boolean skipBill(Bill_Id billId) {
            BillSegmentStatusLookup.Constants constants = BillSegmentStatusLookup.constants;

            String statusStr = "'" + constants.PENDING_CANCEL.trimmedValue() + "', '" + constants.ERROR.trimmedValue() + "', '" + constants.INCOMPLETE.trimmedValue() + "'";
            String queryString = "FROM BillSegment billSegment WHERE billSegment.billSegmentStatus IN (" + statusStr + ") AND billSegment.billId =  :billId";

            Query<QueryResultRow> query = createQuery(queryString, getClass().getName());

            query.bindId("billId", billId);
            BillSegment billSegment = (BillSegment)query.firstRow();
            return !isNull(billSegment);
        }
        
        @Override
        public ToDoProperties createToDoProperties(ThreadWorkUnit unit) {
            
            Account_Id accountId = (Account_Id)unit.getPrimaryId();
            
            ToDoProperties toDoProperties = new ToDoProperties(accountId);
            toDoProperties.setACCT_ID(accountId.getIdValue());
            toDoProperties.setBATCH_NBR(getBatchNumber().toString());
            return toDoProperties;
          }
    }
}
