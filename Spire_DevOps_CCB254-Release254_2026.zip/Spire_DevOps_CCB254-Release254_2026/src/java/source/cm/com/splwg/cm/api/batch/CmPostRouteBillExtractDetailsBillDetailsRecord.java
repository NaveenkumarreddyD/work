/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 2024-07-30   DLampa     INC0037039. Updated field lengths to match 
 *                         the file layout extracted by the CM-BILEXTR 
 *                         algorithm
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractDetailsBillDetailsRecord 
		extends ColumnDelimitedRecord{
	private static final BigDecimal ZERO = BigDecimal.ZERO;
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractDetailsBillDetailsRecord() {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//super(97);
		super(102);
		// End Change - DLampa - 2024-07-30 - INC0037039
		
		// Initialize all fields as blank/spaces
		this.setBPPrinterKey(" ");		
		this.setBPSortKey(" ");
		this.setBPMailingKey(" ");
		this.setBillId(" ");
		this.setAcctId(" ");
		this.setBillDate(" ");
		this.setDueDate(" ");
		this.setCopyNbr(" ");
		this.setNbrOfBillCopies(" ");
		this.setBillPrintIntercept(" ");
		this.setBillFormatFlag(" ");
		this.setReprintSw(" ");
		this.setIsCashOnlySw(" ");
		this.setCurrentBalance(ZERO,"0");
		this.setCurrentChargeAmt(ZERO,"0");
		this.setCurrentCorrAmt(ZERO,"0");
		this.setCurrentAdjAmt(ZERO,"0");
		this.setCurrentPayAmt(ZERO,"0");
		this.setCurrentPrevBal(ZERO,"0");
		this.setTotalBal(ZERO,"0");
		this.setTotalChargeAmt(ZERO,"0");
		this.setTotalCorrAmt(ZERO,"0");
		this.setTotalAdjAmt(ZERO,"0");
		this.setTotalPayAmt(ZERO,"0");
		this.setTotalPrevBal(ZERO,"0");
		this.setAcctCurrencyCd(" ");
		this.setDelinquentAmt(ZERO,"0");
		this.setCustPoId(" ");
		this.setAcctEntityName(" ");
		this.setEntityName(" ");
		this.setCountry(" ");
		this.setAddress1(" ");
		this.setAddress2(" ");
		this.setAddress3(" ");
		this.setAddress4(" ");
		this.setCity(" ");
		this.setNum1(" ");
		this.setNum2(" ");
		this.setHouseType(" ");
		this.setCounty(" ");
		this.setState(" ");
		this.setPostal(" ");
		this.setGeoCode(" ");
		this.setInCityLimit(" ");
		this.setIsFinalBillSw(" ");
		this.setApayExtractDate(" ");
		this.setEntityName1(" ");
		this.setEntityName2(" ");
		this.setEntityName3(" ");
		this.setAcctCurSymbol(" ");
		this.setTotCredAdj(ZERO,"0");
		this.setTotPlgPay(ZERO,"0");
		this.setTotCstPay(ZERO,"0");
		this.setLatePayChargeDate(" ");
		this.setCstPayBillDescr(" ");
		this.setPlgPayBillDescr(" ");
		this.setTotalLPC(ZERO,"0");
		this.setCisDivision(" ");
		this.setRemitToFlg(" ");
		this.setCheckDigit(" ");
		this.setAutopayFlg(" ");
		this.setEmail(" ");
		this.setBudgetPlanCode(" ");
		this.setBudgetDescrOnBill(" ");
		this.setBudgetAmount(ZERO,"0");
		this.setDhDescr(" ");
		this.setDhYtdPd(ZERO,"0");
		this.setSchlAgFlg(" ");
		this.setTotalBillGross(ZERO,"0");
		this.setCurrChargeAmountSubPa(ZERO,"0");
		this.setNewPrevGasBal(ZERO,"0");
		this.setNewTotalBal(ZERO,"0");
		this.setNewPrevOthAmt(ZERO,"0");
		// Start Add - DLampa - 2024-07-30 - INC0037039
		this.setOcrScanLine(" ");
		this.setTotPrevAcctBal(Bool.FALSE, ZERO,"0");
		this.setTotCurrAcctBal(Bool.FALSE, ZERO,"0");
		// End Add - DLampa - 2024-07-30 - INC0037039
		
	}
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * 
	 */
	public void setBPPrinterKey(String value) {		
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
	public void setBPSortKey(String value) {
		rightPadColumn(2, 184, truncateInput(value, 184));
	}
	public void setBPMailingKey(String value) {
		rightPadColumn(3, 15, truncateInput(value, 15));
	}	
	/*
	 * Bill Details
	 */
	public void setBillId(String value) {
		leftPadColumnWithZeros(4, 12, truncateInput(value, 12));
	}
	public void setAcctId(String value) {
		leftPadColumnWithZeros(5, 10, truncateInput(value, 10));
	}
	public void setBillDate(String value) {
		rightPadColumn(6, 10, truncateInput(value, 10));
	}
	public void setDueDate(String value) {
		rightPadColumn(7, 10, truncateInput(value, 10));
	}
	public void setCopyNbr(String value) {
		leftPadColumnWithZeros(8, 1, truncateInput(value, 1));
	}
	public void setNbrOfBillCopies(String value) {
		leftPadColumnWithZeros(9, 1, truncateInput(value, 1));
	}
	public void setBillPrintIntercept(String value) {
		rightPadColumn(10, 8, truncateInput(value, 8));
	}
	public void setBillFormatFlag(String value) {
		rightPadColumn(11, 2, truncateInput(value, 2));
	}
	public void setReprintSw(String value) {
		rightPadColumn(12, 1, truncateInput(value, 1));
	}
	public void setIsCashOnlySw(String value) {
		rightPadColumn(13, 1, truncateInput(value, 1));
	}
	public void setCurrentBalance(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(14, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(15, 15, truncateInput(value, 15));
	}
	public void setCurrentChargeAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(16, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(17,  15, truncateInput(value, 15));
	}
	public void setCurrentCorrAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(18, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(19, 15, truncateInput(value, 15));
	}
	public void setCurrentAdjAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(20, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(21, 15, truncateInput(value, 15));
	}
	public void setCurrentPayAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(22, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(23, 15, truncateInput(value, 15));
	}
	public void setCurrentPrevBal(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(24, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(25, 15, truncateInput(value, 15));
	}
	public void setTotalBal(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(26, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(27, 15, truncateInput(value, 15));
	}
	public void setTotalChargeAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(28, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(29, 15, truncateInput(value, 15));
	}
	public void setTotalCorrAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(30, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(31, 15, truncateInput(value, 15));
	}
	public void setTotalAdjAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(32, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(33, 15, truncateInput(value, 15));
	}
	public void setTotalPayAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(34, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(35, 15, truncateInput(value, 15));
	}
	public void setTotalPrevBal(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(36, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(37, 15, truncateInput(value, 15));
	}
	public void setAcctCurrencyCd(String value) {
		rightPadColumn(38, 3, truncateInput(value, 3));
	}
	public void setDelinquentAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(39, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(40, 15, truncateInput(value, 15));
	}
	public void setCustPoId(String value) {
		rightPadColumn(41, 20, truncateInput(value, 20));
	}
	public void setAcctEntityName(String value) {
		rightPadColumn(42, 254, truncateInput(value, 254));
	}
	public void setEntityName(String value) {
		rightPadColumn(43, 254, truncateInput(value, 254));
	}
	// START CICZADDD.
	public void setCountry(String value) {
		rightPadColumn(44, 3, truncateInput(value, 3));
	}
	public void setAddress1(String value) {
		rightPadColumn(45, 254, truncateInput(value, 254));
	}
	public void setAddress2(String value) {
		rightPadColumn(46, 254, truncateInput(value, 254));
	}
	public void setAddress3(String value) {
		rightPadColumn(47, 254, truncateInput(value, 254));
	}
	public void setAddress4(String value) {
		rightPadColumn(48, 254, truncateInput(value, 254));
	}
	public void setCity(String value) {
		/*For some reason Origin version has this set sa 30 instead of CCBv2.4 field length of 90.*/
		//rightPadColumn(49, 90, truncateInput(value, 90));
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(49, 30, truncateInput(value, 30));
		rightPadColumn(49, 90, truncateInput(value, 90));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setNum1(String value) {
		rightPadColumn(50, 6, truncateInput(value, 6));
	}
	public void setNum2(String value) {
		rightPadColumn(51, 4, truncateInput(value, 4));
	}
	public void setHouseType(String value) {
		rightPadColumn(52, 2, truncateInput(value, 2));
	}
	public void setCounty(String value) {
		/*For some reason Origin version has this set sa 30 instead of CCBv2.4 field length of 90.*/
		//rightPadColumn(53, 90, truncateInput(value, 90));
		// Start Change - DLampa - 2024-07-30 - INC0037039 
		//rightPadColumn(53, 30, truncateInput(value, 30));
		rightPadColumn(53, 90, truncateInput(value, 90));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setState(String value) {
		rightPadColumn(54, 6, truncateInput(value, 6));
	}
	public void setPostal(String value) {
		rightPadColumn(55, 12, truncateInput(value, 12));
	}
	public void setGeoCode(String value) {
		rightPadColumn(56, 11, truncateInput(value, 11));
	}
	public void setInCityLimit(String value) {
		rightPadColumn(57, 1, truncateInput(value, 1));
	}
	// END CICZADDD.
	public void setIsFinalBillSw(String value) {
		rightPadColumn(58, 1, truncateInput(value, 1));
	}
	public void setApayExtractDate(String value) {
		rightPadColumn(59, 10, truncateInput(value, 10));
	}
	public void setEntityName1(String value) {
		rightPadColumn(60, 254, truncateInput(value, 254));
	}
	public void setEntityName2(String value) {
		rightPadColumn(61, 254, truncateInput(value, 254));
	}
	public void setEntityName3(String value) {
		rightPadColumn(62, 254, truncateInput(value, 254));
	}
	public void setAcctCurSymbol(String value) {
		rightPadColumn(63, 4, truncateInput(value, 4));
	}
	public void setTotCredAdj(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(64, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(65, 15, truncateInput(value, 15));
	}
	public void setTotPlgPay(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(66, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(67, 15, truncateInput(value, 15));
	}
	public void setTotCstPay(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(68, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(69, 15, truncateInput(value, 15));
	}
	public void setLatePayChargeDate(String value) {
		rightPadColumn(70, 10, truncateInput(value, 10));
	}
	public void setCstPayBillDescr(String value) {
		rightPadColumn(71, 60, truncateInput(value, 60));
	}
	public void setPlgPayBillDescr(String value) {
		rightPadColumn(72, 60, truncateInput(value, 60));
	}
	public void setTotalLPC(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(73, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(74, 15, truncateInput(value, 15));
	}
	public void setCisDivision(String value) {
		rightPadColumn(75, 5, truncateInput(value, 5));
	}
	public void setRemitToFlg(String value) {
		rightPadColumn(76, 16, truncateInput(value, 16));
	}
	public void setCheckDigit(String value) {
		rightPadColumn(77, 1, truncateInput(value, 1));
	}
	public void setAutopayFlg(String value) {
		rightPadColumn(78, 1, truncateInput(value, 1));
	}
	public void setEmail(String value) {
		rightPadColumn(79, 70, truncateInput(value, 70));
	}
	public void setBudgetPlanCode(String value) {
		rightPadColumn(80, 8, truncateInput(value, 8));
	}
	public void setBudgetDescrOnBill(String value) {
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(81, 60, truncateInput(value, 60));
		rightPadColumn(81, 254, truncateInput(value, 254));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setBudgetAmount(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(82, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(83, 15, truncateInput(value, 15));
	}
	public void setDhDescr(String value) {
		rightPadColumn(84, 80, truncateInput(value, 80));
	}
	public void setDhYtdPd(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(85, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(86, 15, truncateInput(value, 15));
	}
	public void setSchlAgFlg(String value) {
		rightPadColumn(87, 1, truncateInput(value, 1));
	}
	public void setTotalBillGross(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(88, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(89, 15, truncateInput(value, 15));
	}
	public void setCurrChargeAmountSubPa(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(90, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(91, 15, truncateInput(value, 15));
	}
	public void setNewPrevGasBal(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(92, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(93, 15, truncateInput(value, 15));
	}
	public void setNewTotalBal(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(94, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(95, 15, truncateInput(value, 15));
	}
	public void setNewPrevOthAmt(BigDecimal bdVal, String value) {
		String sign = "+";
		if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
			sign = "-";
		}
		rightPadColumn(96, 1, truncateInput(sign, 1));
		leftPadColumnWithZeros(97, 15, truncateInput(value, 15));
	}
	// Start Add - DLampa - 2024-07-30 - INC0037039	
	public void setOcrScanLine(String ocrScanLine) {
		rightPadColumn(98, 27, truncateInput(ocrScanLine, 27));
	}
	public void setTotPrevAcctBal(Bool eligBudSw, BigDecimal bdVal, String value) {
		if (eligBudSw.isTrue()) {
    		String sign = "+";
	    	if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
		    	sign = "-";
		    }
    		rightPadColumn(99, 1, truncateInput(sign, 1));
	    	leftPadColumnWithZeros(100, 15, truncateInput(value, 15));		
		} else {
		    rightPadColumn(99, 1,  " " );
            rightPadColumn(100, 15,  " " );
		}
	}
	public void setTotCurrAcctBal(Bool eligBudSw, BigDecimal bdVal, String value) {
		if (eligBudSw.isTrue()) {
    		String sign = "+";
	    	if (bdVal.compareTo(BigDecimal.ZERO) < 0) {
		    	sign = "-";
		    }
    		rightPadColumn(101, 1, truncateInput(sign, 1));
	    	leftPadColumnWithZeros(102, 15, truncateInput(value, 15));		
		} else {
		    rightPadColumn(101, 1,  " " );
            rightPadColumn(102, 15,  " " );
		}	
	}
	// End Add - DLampa - 2024-07-30 - INC0037039	
}