/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION: 
 * 
 * Consecutive Estimated Billing On Account
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2021-03-30   RDizon     CCB027.2. Initial version. 
 * 2021-10-05	JMeden/	   Defect 4601543. Update the main logic to check
 * 		        NMendo     the specific number of previous bill to create
 *                         Bill Message and Customer Contact
 *************************************************************************/

package com.splwg.cm.domain.admin.customerClass.algorithm.postBillCompletion;

import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.Query;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.ccb.api.lookup.BillStatusLookup;
import com.splwg.ccb.api.lookup.CustomerContactStatusLookup;
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.customerClass.algorithm.postBillCompletion.CustomerClassPostBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillMessage_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

//Start Change - JMeden - Defect 4601543 - 2021-10-05
///**
// * @author RDizon
// *
//@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = billMessageType, name = billMessageType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = numberOfEstimatedBills, required = true, type = integer)
// *            , @AlgorithmSoftParameter (entityName = customerContactClass, name = customerContactClass, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = customerContactType, required = true, type = string)})
// */
/**
 * @author RDizon
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = billMessageType, name = billMessageType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = numberOfEstimatedBills, required = true, type = integer)
 *            , @AlgorithmSoftParameter (entityName = customerContactClass, name = customerContactClass, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = customerContactType, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = numberOfEstimatedBillToAddCC, required = true, type = integer)})
 */
//End Change - JMeden - Defect 4601543 - 2021-10-05
public class CmConsecutiveEstimatedBillingOnAccountAlgComp_Impl
	extends CmConsecutiveEstimatedBillingOnAccountAlgComp_Gen
	implements CustomerClassPostBillCompletionAlgorithmSpot {
	
	// Hard Parameters
	private Bill bill;
	
	// Soft Parameters
	private BigInteger parmNumberOfEstimatedBills;
	private BillMessageType parmBillMessageType;
	private CustomerContactClass parmCustomerContactClass;
	private String parmCustomerContactType;
	//Start Add - JMeden - Defect 4601543 - 2021-10-05	
	private BigInteger parmNumberOfEstimatedBillToAddCC;
	//End Add - JMeden - Defect 4601543 - 2021-10-05	
	
	// Work Variables
	private CustomerContactType_Id customerContactTypeId;
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		parmBillMessageType = getBillMessageType();
		parmNumberOfEstimatedBills = getNumberOfEstimatedBills();
		parmCustomerContactClass = getCustomerContactClass();
		parmCustomerContactType = getCustomerContactType();
		//Start Add - JMeden - Defect 4601543 - 2021-10-05	
		parmNumberOfEstimatedBillToAddCC = getNumberOfEstimatedBillToAddCC();
		//End Add - JMeden - Defect 4601543 - 2021-10-05	
		
		if (parmNumberOfEstimatedBills.compareTo(BigInteger.ZERO) <= 0){
			addError(CustomMessageRepositorySpireOne.CCB027_AlgorithParameterMustBeGreaterThanZero(
					getAlgorithm().getAlgorithmType().getParameterAt(1).fetchLanguageParameterLabel().toString().trim(),
					parmNumberOfEstimatedBills.toString().trim()));
		}
		
		customerContactTypeId = new CustomerContactType_Id(parmCustomerContactClass, parmCustomerContactType);
		
		if(isNull(customerContactTypeId.getEntity())){
            addError(CustomMessageRepositorySpireOne.CCB027_AlgorithParameterInvalidContactTypeForContactClass(
            		getAlgorithm().getAlgorithmType().getParameterAt(3).fetchLanguageParameterLabel().toString().trim(),
					parmCustomerContactType.trim(),
					parmCustomerContactClass.getId().getIdValue().trim()));
        }
		
		//Start Add - JMeden - Defect 4601543 - 2021-10-05	
		if (parmNumberOfEstimatedBillToAddCC.compareTo(BigInteger.ZERO) <= 0){
			addError(CustomMessageRepositorySpireOne.CCB027_AlgorithParameterMustBeGreaterThanZero(
					getAlgorithm().getAlgorithmType().getParameterAt(4).fetchLanguageParameterLabel().toString().trim(),
					parmNumberOfEstimatedBillToAddCC.toString().trim()));
		}
		//End Add - JMeden - Defect 4601543 - 2021-10-05	
		
	}
	
	@Override
	public void invoke() {
		Bool isEstimate = checkForEstimatedMeteredBillSegment();

		if (isEstimate.isTrue()){

			//Start Change - JMeden - Defect 4601543 - 2021-10-05	
			//List<QueryResultRow> listPreviousBills = getPreviousEstimateBills();
			List<SQLResultRow> billsOfAccountList = getBillsOfAccount();
					
			//if (listPreviousBills.size() == parmNumberOfEstimatedBills.intValue()){
			if(checkNoOfEstimatedBill(billsOfAccountList, parmNumberOfEstimatedBills.intValue()).isTrue()){
				// Add Bill Message
				bill.getMessages().add(new BillMessage_DTO(), parmBillMessageType.getId());
			}

			//if (listPreviousBills.size() >= 12){
			if(checkNoOfEstimatedBill(billsOfAccountList, parmNumberOfEstimatedBillToAddCC.intValue()).isTrue()){
				// Create Customer Contact
				createCustomerContact(customerContactTypeId);
			}
			//End Change - JMeden - Defect 4601543 - 2021-10-05
		}
	}
	
	//Start Add - JMeden - Defect 4601543 - 2021-10-05
	private Bool checkNoOfEstimatedBill(List<SQLResultRow> billsOfAccountList, int numberOfBills){
		Bool returnVal = Bool.FALSE;

		Iterator<SQLResultRow> itr = billsOfAccountList.iterator();
		QueryResultRow qrr = null;
		
		int iIndex = 0;
		int iCount = 0;
		Bool isEstimate = Bool.FALSE;
		while(itr.hasNext()){
			qrr = itr.next();
			isEstimate = qrr.getBoolean("EST_SW");
			if(isEstimate.isTrue()){
				iCount++;
			}

			iIndex++;
			if(iIndex == numberOfBills){
				break;
			}
		}

		if(numberOfBills == iCount){
			returnVal = Bool.TRUE;
		}
		
		return returnVal;
	}
	//End Add - JMeden - Defect 4601543 - 2021-10-05

	@Override
	public void setBill(Bill bill) {
		this.bill = bill;
	}
	
    private void createCustomerContact(CustomerContactType_Id customerContactTypeId) {

        CustomerContact_DTO customerContactDto = new CustomerContact_DTO();

        customerContactDto.setPersonId(bill.getAccount().getMainPerson().getId());
        customerContactDto.setCustomerContactTypeId(customerContactTypeId);
        customerContactDto.setContactDateTime(getProcessDateTime());
        customerContactDto.setCustomerContactStatus(CustomerContactStatusLookup.constants.OPEN);
        customerContactDto.setUserId(getActiveContextUser().getId());

        /*Create customer contact record*/
        customerContactDto.newEntity();
    }

	private Bool checkForEstimatedMeteredBillSegment(){
        Bool returnValue = Bool.FALSE;
        Query<Bool> query = createQuery("FROM Bill BILL, " +
        								"    BillSegment BSEG, " +
        								"    BillSegmentRegisterRead BSRR, " +
        								"    RegisterRead RR, " +
        								"    MeterRead MR, " +
        								"WHERE BILL.id = :billId " + 
        								"    AND BILL.id = BSEG.billId " +
        								"    AND BSEG.isEstimate = :estimateSwitch " +
        								"    AND BSEG.id = BSRR.id.billSegment " +
        								"    AND BSRR.endRegisterReadingId = RR.id " +
        								"    AND RR.meterRead = MR.id", "--checkForEstimatedMeteredBillSegment--");
        query.bindId("billId", bill.getId());
        query.bindBoolean("estimateSwitch", Bool.TRUE);
        query.addResult("bsegId", "BSEG.id");
        
        if (query.firstRow() != null){
            returnValue = Bool.TRUE;
        }
        return returnValue;
	}
	
	// Start Delete - NMendo - Defect 4601543 - 2021-10-05
	//private List<QueryResultRow> getPreviousEstimateBills(){
    //    Query<QueryResultRow> query = createQuery("FROM Bill BILL, " +
    //    								"    BillSegment BSEG, " +
    //    								"    BillSegmentRegisterRead BSRR, " +
    //    								"    RegisterRead RR, " +
    //    								"    MeterRead MR " +
    //    								"WHERE BILL.account = :accountId " + 
    //    								"    AND BILL.billDate <= :billDate " +
    //    								"    AND BILL.billStatus = :complete " +
    //    								"    AND BILL.id = BSEG.billId " +
    //    								"    AND BSEG.isEstimate = :estimateSwitch " +
    //    								"    AND BSEG.id = BSRR.id.billSegment " +
    //    								"    AND BSRR.endRegisterReadingId = RR.id " +
    //    								"    AND RR.meterRead = MR.id " +
    //    								"    AND MR.canUseOnBill = :useOnBillSwitch ", "--getPreviousEstimateBills--");
    //    query.bindId("accountId", bill.getAccount().getId());
    //    query.bindDate("billDate", bill.getBillDate());
    //    query.bindLookup("complete", BillStatusLookup.constants.COMPLETE);
    //    query.bindBoolean("estimateSwitch", Bool.TRUE);
    //    query.bindBoolean("useOnBillSwitch", Bool.TRUE);
    //    query.addResult("billId", "BILL.id");
    //    
    //    return query.list();
	//}
	// End Delete - NMendo - Defect 4601543 - 2021-10-05
	
	// Start Add - NMendo - Defect 4601543 - 2021-10-05
	private List<SQLResultRow> getBillsOfAccount() {
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT BILL.BILL_ID, ");
		sb.append(       "BILL.BILL_DT, ");
		sb.append(       "CASE WHEN X.BILL_ID IS NULL THEN 'N' ");
		sb.append(            "ELSE 'Y' ");
		sb.append(       "END AS EST_SW ");
		sb.append("FROM CI_BILL BILL ");
		sb.append("LEFT JOIN (SELECT DISTINCT BILL2.BILL_ID ");
		sb.append(           "FROM CI_BILL BILL2, ");
		sb.append(                "CI_BSEG BSEG, ");
		sb.append(                "CI_BSEG_READ BSRR, ");
		sb.append(                "CI_REG_READ RR, ");
		sb.append(                "CI_MR MR ");
		sb.append(           "WHERE BILL2.ACCT_ID = :accountId ");
		sb.append(           "AND BILL2.BILL_ID = BSEG.BILL_ID ");
		sb.append(           "AND BSEG.BSEG_ID = BSRR.BSEG_ID ");
		sb.append(           "AND BSEG.EST_SW = :estimateSw ");
		sb.append(           "AND BSRR.END_REG_READ_ID = RR.REG_READ_ID ");
		sb.append(           "AND RR.MR_ID = MR.MR_ID ");
		sb.append(           "AND MR.USE_ON_BILL_SW = :useOnBillSw) X ");
		sb.append("ON BILL.BILL_ID = X.BILL_ID ");
		sb.append("WHERE BILL.ACCT_ID = :accountId ");
		sb.append("AND BILL.BILL_DT <= :billDate ");
		sb.append("AND BILL.BILL_STAT_FLG = :complete ");
		sb.append("ORDER BY BILL.BILL_DT DESC ");
		
		PreparedStatement ps = createPreparedStatement(sb.toString(), getClass().getName());
        ps.setAutoclose(false);
        ps.bindId("accountId", bill.getAccount().getId());
        ps.bindDate("billDate", bill.getBillDate());
        ps.bindLookup("complete", BillStatusLookup.constants.COMPLETE);
        ps.bindBoolean("useOnBillSw", Bool.TRUE);
        ps.bindBoolean("estimateSw", Bool.TRUE);
        
        List<SQLResultRow> result = ps.list();
        ps.close();
        
        return result;
	}
	// End Add - NMendo - Defect 4601543 - 2021-10-05
}
