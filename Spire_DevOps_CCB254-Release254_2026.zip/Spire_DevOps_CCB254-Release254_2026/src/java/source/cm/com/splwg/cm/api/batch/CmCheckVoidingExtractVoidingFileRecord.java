/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Voiding File Batch Extract - Voiding
 * File Record
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2021-06-01   GCrisp     Initial version. CCB041.3 Check Voiding
 *                   	   File Record
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmCheckVoidingExtractVoidingFileRecord extends ColumnDelimitedRecord{
	
	/*
	 * Constructor
	 */
	public CmCheckVoidingExtractVoidingFileRecord() {
		super(8);
	}
	public void setSpace(String value) {		
		leftPadColumnWithZeros(1, 1, value);
	}
	public void setAccountNumber(String value) {		
		leftPadColumnWithZeros(2, 10, value);
	}
	
	public void setCheckNumber(String value) {		
		leftPadColumnWithZeros(3, 10, value);
	}
	
	/*public void setOneSpaceBlankFieldFiller(String value) {		
		rightPadColumn(4, 1, value);
	}*/
	
	public void setAmount(String value) {		
		leftPadColumnWithZeros(4, 11, value);
	}
	
	public void setDateField(String value) {		
		rightPadColumn(5, 6, value);
	}
	
	public void setThreeSpaceBlankFieldFiller(String value) {		
		rightPadColumn(6, 3, value);
	}
	
	public void setVfiller(String value) {		
		rightPadColumn(7, 1, value);
	}
	
	public void setPayeeNameAndAddress(String value) {		
		rightPadColumn(8, 254, value);
	}
}
