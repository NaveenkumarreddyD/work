/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Cancel Rebill Portal Parameters Feature Configuration Lookup
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2012-12-15   Murali	NP0048. Initial Version.
 **************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author mlekkala001
 *
 @LookupFieldname (value = XCRB_OPT_TYP_FLG)
 */
public class CmCancelRebillParametersLookup_Impl 
extends CmCancelRebillParametersLookup_Gen {

}

