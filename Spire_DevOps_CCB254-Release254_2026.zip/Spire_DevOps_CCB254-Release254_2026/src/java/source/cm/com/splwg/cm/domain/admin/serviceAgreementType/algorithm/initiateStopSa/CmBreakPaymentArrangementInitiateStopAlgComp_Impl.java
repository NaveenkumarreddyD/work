/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm is a wrapper for CMPCBPAX Algorithm.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2016-01-22   EQuint      Initial Version. 
 * 2016-05-30   MPang       Defect 3444302. Added close connection
 * 2018-06-07   SFelip      CCB v2.6 Upgrade.  
 * 2025-11-14   EQuint      CCB25.4 Upgrade                      
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.serviceAgreementType.algorithm.initiateStopSa;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.SQLException;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.service.RequestContext;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.base.support.context.ConnectionWork;
import com.splwg.base.support.context.ContextHolder;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.base.support.sql.DatabaseHelper;
import com.splwg.ccb.domain.admin.adjustmentCancelReason.entity.AdjustmentCancelReason;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.initiateStopSa.SaTypeInitiateStopSaAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType_Id;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

import us.verang.framework.IndexOutOfBounds;
import us.verang.framework.Session;
import us.verang.framework.Stop;
import us.verang.framework.cobol.CobolCode;
import us.verang.framework.cobol.CobolSession;
import us.verang.origin.Cmpcbpax;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = brokenPaymentArrangementCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = brokenPaymentArrangementCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = transferAdjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentCancelReason, name = cancelReason, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = cisDivision, name = cisDivision, type = entity)
 *            , @AlgorithmSoftParameter (name = serviceAgreementType, type = string)})
 */
public class CmBreakPaymentArrangementInitiateStopAlgComp_Impl extends
		CmBreakPaymentArrangementInitiateStopAlgComp_Gen implements
		SaTypeInitiateStopSaAlgorithmSpot {
	
	// hard parameters
	private ServiceType serviceType;
	private Premise premise;
	private String revertToLandlord;
	private ServiceAgreement serviceAgreement;
	private Bool shouldCreateFieldActivity;
	private Date stopDate;
	private String stopRequestedBy;
	
	// soft parameters
	private CharacteristicType brokenPaymentArrangementCharType;
	private String brokenPaymentArrangementCharValue;
	private AdjustmentType transferAdjustmentType;
	private AdjustmentCancelReason cancelReason;
	private CisDivision cisDivision;
	private String serviceAgreementTypeString;
	
	private Cmpcbpax cmpcbpax;
	//Start Add - MPang - Defect 3444302- 2016-05-30
	private Connection connection;
	//End Add - MPang - Defect 3444302- 2016-05-30

	// CONSTANTS
	private static final String CONNECTION_ONLINE = "O";
	private static final String CONNECTION_BATCH = "B";
	
	private static final String SWITCH_YES = "Y";
	private static final String SWITCH_NO = "N";
	
	@Override
	public ServiceType getServiceType() {
		return serviceType;
	}

	@Override
	public void setPremise(Premise arg0) {
		premise = arg0;
	}

	@Override
	public void setRevertToLandlord(String arg0) {
		revertToLandlord = arg0;
	}

	@Override
	public void setServiceAgreement(ServiceAgreement arg0) {
		serviceAgreement = arg0;
	}

	@Override
	public void setServiceType(ServiceType arg0) {
		serviceType = arg0;
	}

	@Override
	public void setShouldCreateFieldActivity(Bool arg0) {
		shouldCreateFieldActivity = arg0;
	}

	@Override
	public void setStopDate(Date arg0) {
		stopDate = arg0;
	}

	@Override
	public void setStopRequestedBy(String arg0) {
		stopRequestedBy = arg0;
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		brokenPaymentArrangementCharType = getBrokenPaymentArrangementCharType();
		brokenPaymentArrangementCharValue = getBrokenPaymentArrangementCharValue();
		transferAdjustmentType = getTransferAdjustmentType();
		cancelReason = getCancelReason();
		cisDivision = getCisDivision();
		serviceAgreementTypeString = getServiceAgreementType();
	}

	@Override
	public void invoke() {
		try { 
			initializeCobolProgram();
			
			// set cobol program's hard parameters
			if(notNull(serviceAgreement)) {
				cmpcbpax.setCozzxInputWrkSaId(serviceAgreement.getId().getTrimmedValue());
			}
			else {
				cmpcbpax.setCozzxInputWrkSaId(CobolCode.SPACES.toString()); 
			}
			
			if(notNull(stopDate)) {
				cmpcbpax.setStopDt(stopDate.toString());
			}
			else {
				cmpcbpax.setStopDt(CobolCode.SPACES.toString()); 
			}
			
			if(notNull(premise)) {
				cmpcbpax.setPremId(premise.getId().getTrimmedValue());
			}
			else {
				cmpcbpax.setPremId(CobolCode.SPACES.toString()); 
			}
			
			if(notNull(stopRequestedBy)) {
				cmpcbpax.setInputWrkStopReqedBy(stopRequestedBy.trim());
			}
			else {
				cmpcbpax.setInputWrkStopReqedBy(CobolCode.SPACES.toString()); 
			}
			
			if(notNull(shouldCreateFieldActivity)) {
				String shouldCreateFieldActivitySw = (shouldCreateFieldActivity.isTrue()) ? SWITCH_YES : SWITCH_NO;
				cmpcbpax.setCreateFaSw(shouldCreateFieldActivitySw);
			}
			else {
				cmpcbpax.setCreateFaSw(CobolCode.SPACES.toString()); 
			}
			
			if(notNull(revertToLandlord)) {
				cmpcbpax.setReversionSw(revertToLandlord.trim());
			}
			else {
				cmpcbpax.setReversionSw(CobolCode.SPACES.toString()); 
			}
			
			if(notNull(serviceType)) {
				cmpcbpax.setInputOutputWrkSvcTypeCd(serviceType.getId().getTrimmedValue());
			}
			else {
				cmpcbpax.setInputOutputWrkSvcTypeCd(CobolCode.SPACES.toString()); 
			}
			
			// soft parameters
			cmpcbpax.setAlgParmVal(1, brokenPaymentArrangementCharType.getId().getTrimmedValue()); 
			cmpcbpax.setAlgParmVal(2, brokenPaymentArrangementCharValue.trim()); 
			cmpcbpax.setAlgParmVal(3, transferAdjustmentType.getId().getTrimmedValue());
			cmpcbpax.setAlgParmVal(4, cancelReason.getId().getTrimmedValue()); 
			if(notNull(cisDivision)) {
				cmpcbpax.setAlgParmVal(5, cisDivision.getId().getTrimmedValue()); 
			}
			else {
				cmpcbpax.setAlgParmVal(5, CobolCode.SPACES.toString()); 
			}
			if(notBlank(serviceAgreementTypeString)) {
				cmpcbpax.setAlgParmVal(6, serviceAgreementTypeString);
			}
			else {
				cmpcbpax.setAlgParmVal(6, CobolCode.SPACES.toString()); 
			}
			
			// invoke the main method
		    cmpcbpax.cobolMain(); 
		} 
		catch(Exception _ex) {
		    Throwable ex=_ex;
		    while(ex.getCause()!=null) ex=ex.getCause();
		    if(ex instanceof Stop) {
		    	if (cmpcbpax.getMessageNbr().compareTo(java.math.BigDecimal.ZERO) != 0 
		    			&& cmpcbpax.getZmsgnMessageCatNbr().compareTo(java.math.BigDecimal.ZERO) != 0) {
		    		
		    		MessageParameters messageparameters = new MessageParameters();
		    		for (int i = 1; i <= 9; i++) {
		    			try {
		    				String parmValue = cmpcbpax.getMessageParm(i);
			    			if (notBlank(cmpcbpax.getMessageParm(i))) {
			    				messageparameters.addRawString(parmValue.trim());
			    			}
		    			}
		    			catch(IndexOutOfBounds e) {
		    				break;
		    			}
		    			
		    		}
		    		
		    		MessageCategory_Id categoryId = new MessageCategory_Id(cmpcbpax.getZmsgnMessageCatNbr().toBigInteger());
		    		ServerMessage serverMessage = 
		    				ServerMessageFactory.Factory.newInstance().createMessage(
		    						categoryId, cmpcbpax.getMessageNbr().intValue(), messageparameters);
		    		
		    		// info
		    		if (cmpcbpax.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.INFORMATIONAL.getLookupValue().fetchIdFieldValue()) == 0) {
		    			logInfo(serverMessage);
		    		}
		    		// warning
		    		else if (cmpcbpax.getMessageSeverity().compareTo(
		    				MessageSeverityLookup.constants.WARNING.getLookupValue().fetchIdFieldValue()) == 0){
		    			addWarning(serverMessage);
		    		}
		    		// error
		    		else {
		    			addError(serverMessage);
		    		}
		    		
		    	}
		    	
		    	serviceType = new ServiceType_Id(cmpcbpax.getInputOutputWrkSvcTypeCd().trim()).getEntity();
		    	
		    }
		    else {
		        //Start Add - MPang - Defect 3444302- 2016-05-30
		        ex.printStackTrace();
		        //End Add - MPang - Defect 3444302- 2016-05-30
		        if (ex instanceof ApplicationError) {
		        	addError(((ApplicationError)ex).getServerMessage());
		        }
		        else {
		        	addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), ex.toString()));
		        }
		    }
		}
		finally {
			cmpcbpax=Session.returnSessionAndCodeToCache(cmpcbpax);
			// start delete - equint - 2025-11-14 - CCB25.4 Upgrade
//			//Start Add - MPang - Defect 3444302- 2016-05-30
//			try {
//                connection.close();
//            } catch (SQLException e) {
//                addError(CustomMessageRepository.JACOB_errorMessage(getAlgorithmId().getTrimmedValue(), e.toString()));
//            }
//			//End Add - MPang - Defect 3444302- 2016-05-30
			// end delete - equint - 2025-11-14 - CCB25.4 Upgrade
		}

	}
	
	/*
	 * Initialize Cobol Program
	 */
	@SuppressWarnings("deprecation")
	private void initializeCobolProgram() throws Exception {
	
		FrameworkSession session = (FrameworkSession) SessionHolder.getSession();
		RequestContext context = session.getRequestContext();
		
		// start update - equint - 2025-11-14 - CCB25.4 Upgrade
		session.doWork(new ConnectionWork() {
			
			@Override
			public void execute(Connection connection) throws SQLException {
				try {			
					String username = connection.getMetaData().getUserName();
					String url = connection.getMetaData().getURL();
					
					CobolSession.setLogSessionStartEnd(false);
				    cmpcbpax=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpcbpax.class);
					
					cmpcbpax.getSession().getDbSession().setUpdateConnection(connection);
					cmpcbpax.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
					cmpcbpax.aa100Initialize();
					// set ZSTAT parameters

					cmpcbpax.setProcessDt(getProcessDateTime().getDate().toString());
					cmpcbpax.setProcessDttmSep("-");
					cmpcbpax.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
					
					if (session.isOnlineConnection()) { 
						cmpcbpax.setConnectionFlg(CONNECTION_ONLINE);
					}
					else {
						cmpcbpax.setConnectionFlg(CONNECTION_BATCH);
					}
					
					cmpcbpax.setUserId(context.getUserId());
					cmpcbpax.setZstatLanguageCd(context.getLanguageCode());
			        
			        if (context.ignoreWarnings()) {
			        	cmpcbpax.setIgnoreWarningSw(SWITCH_YES);
			        }
			        else {
			        	cmpcbpax.setIgnoreWarningSw(SWITCH_NO);
			        }
			        
			        if (session.getBatchInstanceId() != null) {
			        	cmpcbpax.setSqlInfoSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
			        	
					} else {
						cmpcbpax.setSqlInfoSchedulerId(new BigDecimal(0).toBigDecimal());
					}
			        
			        cmpcbpax.setAppSvcId(context.getSecurityServiceIdContext());
			        
			        DatabaseHelper dbHelper = session.getDatabaseHelper();
			        cmpcbpax.setDbMode(dbHelper.getCobolDBMode());
			        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
			        //cmpcbpax.setSplHighValue(cmpcbpax.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
			        //cmpcbpax.setSplLowValue(cmpcbpax.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
			        
			        cmpcbpax.setSplHighValue(cmpcbpax.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
			        cmpcbpax.setSplLowValue(cmpcbpax.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));

			        // CCB v2.6 Upgrade - 2018-05-31 - End Change
			        
			        cmpcbpax.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
			        cmpcbpax.setLkExpiryDt(Date.MAX.toString());
			        cmpcbpax.setProgramStatus(" ");
			        
			        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
			        cmpcbpax.setCallSeq(";");
			        cmpcbpax.setMessageAreaProgramName("CMPCBPAX");
			        // CCB v2.6 Upgrade - 2018-08-02 - End Add
			        
			        if (context.getRandomGeneratorSeedSet().isTrue()) {
			        	cmpcbpax.setRandomGenSeedSw(SWITCH_YES);
			        	cmpcbpax.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
			        	cmpcbpax.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
			        	cmpcbpax.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
			        	cmpcbpax.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
			        }
			        else {
			        	cmpcbpax.setRandomGenSeedSw(SWITCH_NO);
			        }
			        
			        if (context.traceStandardOut()) { 
			        	cmpcbpax.setTrcStdoutSw(SWITCH_YES);
			        }
			        else {
			        	cmpcbpax.setTrcStdoutSw(SWITCH_NO);
			        }
			        
			        if (context.traceProgramStart()) { 
			        	cmpcbpax.setTrcProgStartSw(SWITCH_YES);
			        }
			        else {
			        	cmpcbpax.setTrcProgStartSw(SWITCH_NO);
			        }
			        
			        if (context.traceProgramExit()) { 
			        	cmpcbpax.setTrcProgExitSw(SWITCH_YES);
			        }
			        else {
			        	cmpcbpax.setTrcProgExitSw(SWITCH_NO);
			        }
			        
			        if (context.traceSQL()) { 
			        	cmpcbpax.setTrcExecSqlSw(SWITCH_YES);
			        }
			        else {
			        	cmpcbpax.setTrcExecSqlSw(SWITCH_NO);
			        }
			        
			        // Set ZMSGN parms
			        BigInteger messageSequence = session.getMessageSequence();
			        if (notNull(messageSequence)) {
			        	cmpcbpax.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
			        }
			        else {
			        	cmpcbpax.setMessageSeq(new BigDecimal(0).toBigDecimal());
			        }
				}
				catch(Exception e) {
					throw new SQLException(e.getCause());
				}
				
			}
		});
		 
//		SessionFactoryImplementor implementor = (SessionFactoryImplementor) session.getHibernateSession().getSessionFactory();
//        //Start Change - MPang - Defect 3444302- 2016-05-30
//        //Connection connection = implementor.getConnectionProvider().getConnection();
//        connection = implementor.getConnectionProvider().getConnection();
//        //End Change - MPang - Defect 3444302- 2016-05-30		
//		String username = connection.getMetaData().getUserName();
//		String url = connection.getMetaData().getURL();
//		
//		CobolSession.setLogSessionStartEnd(false);
//	    cmpcbpax=CobolSession.getSessionAndCode(new CobolSession.CobolSessionCreator(username,url),Cmpcbpax.class);
//		
//		cmpcbpax.getSession().getDbSession().setUpdateConnection(connection);
//		cmpcbpax.getSession().getDbSession().execute("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH:MI:SS.FF' NLS_DATE_FORMAT = 'YYYY-MM-DD'");
//		cmpcbpax.aa100Initialize();
//		// set ZSTAT parameters
//
//		cmpcbpax.setProcessDt(getProcessDateTime().getDate().toString());
//		cmpcbpax.setProcessDttmSep("-");
//		cmpcbpax.setProcessTm(getProcessDateTime().getTime().toString() + ".000000");
//		
//		if (session.isOnlineConnection()) { 
//			cmpcbpax.setConnectionFlg(CONNECTION_ONLINE);
//		}
//		else {
//			cmpcbpax.setConnectionFlg(CONNECTION_BATCH);
//		}
//		
//		cmpcbpax.setUserId(context.getUserId());
//		cmpcbpax.setZstatLanguageCd(context.getLanguageCode());
//        
//        if (context.ignoreWarnings()) {
//        	cmpcbpax.setIgnoreWarningSw(SWITCH_YES);
//        }
//        else {
//        	cmpcbpax.setIgnoreWarningSw(SWITCH_NO);
//        }
//        
//        if (session.getBatchInstanceId() != null) {
//        	cmpcbpax.setSqlInfoSchedulerId(new BigDecimal(session.getBatchInstanceId()).toBigDecimal());
//        	
//		} else {
//			cmpcbpax.setSqlInfoSchedulerId(new BigDecimal(0).toBigDecimal());
//		}
//        
//        cmpcbpax.setAppSvcId(context.getSecurityServiceIdContext());
//        
//        DatabaseHelper dbHelper = session.getDatabaseHelper();
//        cmpcbpax.setDbMode(dbHelper.getCobolDBMode());
//        // CCB v2.6 Upgrade - 2018-05-31 - Start Change
//        //cmpcbpax.setSplHighValue(cmpcbpax.getSession().getSettings().getString(new byte[]{dbHelper.highByteForCobol()}));
//        //cmpcbpax.setSplLowValue(cmpcbpax.getSession().getSettings().getString(new byte[]{dbHelper.lowByteForCobol()}));
//        
//        cmpcbpax.setSplHighValue(cmpcbpax.getSession().getSettings().getString(new String(new char[]{dbHelper.highByteForCobol()}).getBytes()));
//        cmpcbpax.setSplLowValue(cmpcbpax.getSession().getSettings().getString(new String(new char[]{dbHelper.lowByteForCobol()}).getBytes()));
//
//        // CCB v2.6 Upgrade - 2018-05-31 - End Change
//        
//        cmpcbpax.setEnvId(new BigDecimal(ContextHolder.getContext().getEnvironmentId()).toBigDecimal());
//        cmpcbpax.setLkExpiryDt(Date.MAX.toString());
//        cmpcbpax.setProgramStatus(" ");
//        
//        // CCB v2.6 Upgrade - 2018-08-02 - Start Add
//        cmpcbpax.setCallSeq(";");
//        cmpcbpax.setMessageAreaProgramName("CMPCBPAX");
//        // CCB v2.6 Upgrade - 2018-08-02 - End Add
//        
//        if (context.getRandomGeneratorSeedSet().isTrue()) {
//        	cmpcbpax.setRandomGenSeedSw(SWITCH_YES);
//        	cmpcbpax.setRandomNbr_1(new BigDecimal(context.getRandomNumber1()).toBigDecimal());
//        	cmpcbpax.setRandomNbr_2(new BigDecimal(context.getRandomNumber2()).toBigDecimal());
//        	cmpcbpax.setRandomNbr_3(new BigDecimal(context.getRandomNumber3()).toBigDecimal());
//        	cmpcbpax.setRandomNbr_4(new BigDecimal(context.getRandomNumber4()).toBigDecimal());
//        }
//        else {
//        	cmpcbpax.setRandomGenSeedSw(SWITCH_NO);
//        }
//        
//        if (context.traceStandardOut()) { 
//        	cmpcbpax.setTrcStdoutSw(SWITCH_YES);
//        }
//        else {
//        	cmpcbpax.setTrcStdoutSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramStart()) { 
//        	cmpcbpax.setTrcProgStartSw(SWITCH_YES);
//        }
//        else {
//        	cmpcbpax.setTrcProgStartSw(SWITCH_NO);
//        }
//        
//        if (context.traceProgramExit()) { 
//        	cmpcbpax.setTrcProgExitSw(SWITCH_YES);
//        }
//        else {
//        	cmpcbpax.setTrcProgExitSw(SWITCH_NO);
//        }
//        
//        if (context.traceSQL()) { 
//        	cmpcbpax.setTrcExecSqlSw(SWITCH_YES);
//        }
//        else {
//        	cmpcbpax.setTrcExecSqlSw(SWITCH_NO);
//        }
//        
//        // Set ZMSGN parms
//        BigInteger messageSequence = session.getMessageSequence();
//        if (notNull(messageSequence)) {
//        	cmpcbpax.setMessageSeq(new BigDecimal(messageSequence).toBigDecimal());
//        }
//        else {
//        	cmpcbpax.setMessageSeq(new BigDecimal(0).toBigDecimal());
//        }
		
		// end update - equint - 2025-11-14 - CCB25.4 Upgrade

	}

}
