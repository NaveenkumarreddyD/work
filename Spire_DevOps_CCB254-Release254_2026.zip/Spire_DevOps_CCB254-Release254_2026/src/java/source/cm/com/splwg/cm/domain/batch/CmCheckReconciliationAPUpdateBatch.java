/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Check Reconciliation A/P Update Batch Process
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-06-01   RDizon  CCB041.2. Initial version. 
 * 2021-09-16   JLumbre QAC#4596793. Update check numbers.   
 * 2021-09-14	JMeden	CCB041.Issue3. Create To Do Entry if check is voided
 **************************************************************************
 */

package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_Id;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.ccb.api.lookup.PaymentSelectionStatusLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.adjustment.adjustment.entity.ApCheckRequest;
import com.splwg.ccb.domain.adjustment.adjustment.entity.ApCheckRequest_DTO;
import com.splwg.ccb.domain.adjustment.adjustment.entity.ApCheckRequest_Id;
import com.splwg.ccb.domain.todo.common.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.data.ToDoMaintenanceData;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ServerMessage;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;
/**
 * @author RDizon
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)})
 */

public class CmCheckReconciliationAPUpdateBatch extends
        CmCheckReconciliationAPUpdateBatch_Gen {
	
	private static Logger log = LoggerFactory.getLogger(CmCheckReconciliationAPUpdateBatch.class);
    
	@Override
    public void validateSoftParameters(boolean arg0) {

        // Parameter FILE_PATH
        String filePath = getParameters().getFILE_PATH();        
        File folder = new File(filePath);
        if (!folder.isDirectory()) {
        	addError(CustomMessageRepositorySpireOne.CCB041_2_InvalidFilePath("File Path"));
        }
    }

	@Override
    public JobWork getJobWork() {
        List<ThreadWorkUnit> threadWorkUnitList = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        threadWorkUnitList.add(threadWorkUnit);
        return createJobWorkForThreadWorkUnitList(threadWorkUnitList);
    }

    public Class<CmCheckReconciliationAPUpdateBatchWorker> getThreadWorkerClass() {
        return CmCheckReconciliationAPUpdateBatchWorker.class;
    }

    public static class CmCheckReconciliationAPUpdateBatchWorker extends
            CmCheckReconciliationAPUpdateBatchWorker_Gen {

        // Batch Parameters
        private String parmFilePath;
        private String parmFileName;
              
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }
        
        @Override
        public boolean executeWorkUnit(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {

        	// Retrieve Batch Parameters
            parmFilePath = getParameters().getFILE_PATH();
            parmFileName = getParameters().getFILE_NAME();
            
            File file = new File(parmFilePath, parmFileName);            
            BufferedReader bufferedReader = null;            
            try {
                bufferedReader = new BufferedReader(new FileReader(file));
            } catch (FileNotFoundException fe) {
            	addError(CustomMessageRepositorySpireOne.CCB041_2_FileNotFound());
            }
            
            try {
                while (bufferedReader.ready()) {
                    String record = bufferedReader.readLine();
                    
                    if (isBlankOrNull(record.trim())){
                        // Skip blank lines
                        continue;
                    }

                    //String checkNumber = record.substring(10, 20);
                    String checkNumber = record.substring(11, 21);

                    //String paymentMM = record.substring(20, 22);
                    //String paymentDD = record.substring(22, 24);
                    //String paymentYY = record.substring(24, 26);
                    String paymentMM = record.substring(32, 34);
                    String paymentDD = record.substring(34, 36);
                    String paymentYY = record.substring(36, 38);
                    Date paymentDate = new Date(Integer.parseInt("20"+ paymentYY), Integer.parseInt(paymentMM), Integer.parseInt(paymentDD)); 
                    
                    //String paidAmountNbr = record.substring(26, 34);
                    //String paidAmountDec = record.substring(34, 36);
                    String paidAmountNbr = record.substring(21, 30);
                    String paidAmountDec = record.substring(30, 32);
                    BigDecimal paidAmount = new BigDecimal(paidAmountNbr + "." + paidAmountDec);
                    //Start Add - JLumbre - 2021-09-16 - QAC#4596793
                    //checkNumber = checkNumber.replaceAll("^0+(?!$)", "");
                    //End Add - JLumbre - 2021-09-16 - QAC#4596793
                    log.info(">>>>>checkNumber:'" +checkNumber +"'");
                    /*log.info(">>>>>paymentMM:'" +paymentMM +"'");
                    log.info(">>>>>paymentDD:'" +paymentDD +"'");
                    log.info(">>>>>paymentYY:'" +paymentYY +"'");
                    log.info(">>>>>paidAmountNbr:'" +paidAmountNbr +"'");
                    log.info(">>>>>paidAmountDec:'" +paidAmountDec +"'");
                    log.info(">>>>>paidAmount:'" +paidAmount +"'");*/
                    ApCheckRequest apCheckRequest = getApCheckRequest(checkNumber);
                    
                    if (notNull(apCheckRequest)){
                        //Start Add - JMeden - 2021-09-14 - CCB041.Issue3
                        Adjustment_Id adjId = apCheckRequest.getAdjustmentId();
                       
                    	if(apCheckRequest.getPaymentSelectionStatus().equals(PaymentSelectionStatusLookup.constants.CANCELED)){
                    		createToDo(CustomMessageRepositorySpireOne.CCB041_ISSUE3_VoidCheck(checkNumber), checkNumber, adjId, paidAmount);
                    		logError(CustomMessageRepositorySpireOne.CCB041_ISSUE3_VoidCheck(checkNumber)); 
                    	}
                    	//End Add - JMeden - 2021-09-14 - CCB041.Issue3	
                    	
                    	ApCheckRequest_DTO apCheckRequestDto = apCheckRequest.getDTO();
                    	apCheckRequestDto.setPaymentSelectionStatus(PaymentSelectionStatusLookup.constants.PAID);
                    	apCheckRequestDto.setPaidAmount(new Money(paidAmount, apCheckRequest.getAdjustmentId().getEntity().fetchCurrency().getId()));
                    	apCheckRequestDto.setPaymentDate(paymentDate);
                    	apCheckRequest.setDTO(apCheckRequestDto);
                    }
                }
                
                bufferedReader.close();
            } catch (IOException ioe) {
            	 addError(CustomMessageRepositorySpireOne.CCB041_2_ErrorFileReading(ioe.getMessage()));
                 ioe.printStackTrace();
            }    
            
            return true;
        }
        
        //Start Add - JMeden - 2021-09-14 - CCB041.Issue3	
    	/**
    	 * This method creates a To Do Entry
    	 * @param account
    	 */
    	private void createToDo(ServerMessage message, String checkNumber, Adjustment_Id adjId, BigDecimal paidAmt) {
    		ToDoEntry_DTO entryDto  = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
            
    		ToDoType todoType = getToDoTypeForBatch(getBatchControlId());
    		if(isNull(todoType)) {
    			return;
    		}
    		
            entryDto.setToDoTypeId(todoType.getId());
            entryDto.setToDoRoleId(todoType.getDefaultRole().fetchIdToDoRole().getId());
            entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
            entryDto.setCreationDateTime(getProcessDateTime());
            entryDto.setBatchControlId(getBatchControlId());

            ArrayList<ToDoSortKeyValue_DTO>sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();
            ToDoSortKeyType sortKeyType = todoType.getSortKeyTypes().iterator().next();
            ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
            BigInteger seq = sortKeyType.fetchIdSequence();
            sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));
            sortKeyDto.setKeyValue(paidAmt.toString());
            sortKeyList.add(sortKeyDto);
                 
            ArrayList<ToDoDrillKeyValue_DTO>drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
            ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO) createDTO(ToDoDrillKeyValue.class);
            ToDoDrillKeyType drillKeyType = todoType.getDrillKeyTypes().iterator().next();
            BigInteger sequence = drillKeyType.fetchIdSequence();
            drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, sequence));
            drillKeyDto.setKeyValue(adjId.getTrimmedValue());
            drillKeyList.add(drillKeyDto);
            
            entryDto.setMessageId(message.getMessageId());
            ArrayList <String> messageParameterList = new ArrayList<String> ();
            messageParameterList.add(0, checkNumber);

            ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory.newInstance();
            toDoEntryData.setDrillKeys(drillKeyList);
            toDoEntryData.setEntryDto(entryDto);
            toDoEntryData.setSortKeys(sortKeyList);
            toDoEntryData.setMessageParams(messageParameterList);
            
            ArrayList <ToDoEntryCharacteristic_DTO>  charList = new ArrayList<ToDoEntryCharacteristic_DTO> ();
            toDoEntryData.setToDoCharacteristics(charList);

            ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
            toDoProcessor.addToDo(toDoEntryData);
            
    	}
    	//End Add - JMeden - 2021-09-14 - CCB041.Issue3
        
        private ApCheckRequest getApCheckRequest(String paymentId) {

            ApCheckRequest returnValue = null;
            StringBuilder stringBuilder = new StringBuilder();      
            stringBuilder.append("SELECT ");
            stringBuilder.append("    AAP.AP_REQ_ID ");
            stringBuilder.append("FROM ");
            stringBuilder.append("    CI_ADJ_APREQ AAP ");
            stringBuilder.append("WHERE ");
            stringBuilder.append("    TRIM(AAP.PYMNT_ID) = TRIM(:paymentId) ");

            PreparedStatement prepStatement = createPreparedStatement(stringBuilder.toString(), "=getApCheckRequest=");
            prepStatement.bindString("paymentId", paymentId, "PYMNT_ID");
            prepStatement.execute();
            prepStatement.setAutoclose(false);
            if (notNull(prepStatement.firstRow())) {
                SQLResultRow sqlRow = prepStatement.firstRow();
                ApCheckRequest_Id apRequestId = (ApCheckRequest_Id) sqlRow.getId("AP_REQ_ID", ApCheckRequest.class);
                returnValue = apRequestId.getEntity();
            }
            prepStatement.close();
            
            return returnValue;
        }
    }
}
