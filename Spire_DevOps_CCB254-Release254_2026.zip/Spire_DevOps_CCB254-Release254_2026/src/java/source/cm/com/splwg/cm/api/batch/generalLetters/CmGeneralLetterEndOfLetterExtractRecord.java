/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * End of Letter Extract Record                                                               
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                          
 * 2020-04-01  JHERNA      SA-322461. Initial version                 
 *                                                                
 *******************************************************************************
 */

package com.splwg.cm.api.batch.generalLetters;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmGeneralLetterEndOfLetterExtractRecord extends ColumnDelimitedRecord {
    
    // Mailing Information
    private static final String CC_END_PRINT_KEY = "9990";
    private static final String CC_XX_GRP = "99";    
    private static final String BLANK = "  ";
    private static final String EMPTY_STR = "";
    
    public CmGeneralLetterEndOfLetterExtractRecord() {
        super(8);
        defaultPrintKey();
    }

    /* EXTRACT COMMON SECTIONS */
    private void defaultPrintKey() {
        this.rightPadColumn(1, 4, formatString(CC_END_PRINT_KEY, 4));
    }
    
    public void setSortKeyLetterTemplateCode(String letterTemplateCode) {
        this.rightPadColumn(2, 12, formatString(letterTemplateCode, 12));
    }
    
    public void setSortKeyCcId(String ccId) {
        this.rightPadColumn(3, 10, formatString(ccId, 10));
        setSortKeyCcRecordGroup();
        setSortKeyCAndCRecordGroup();
    }
    
    private void setSortKeyCcRecordGroup() {
        this.rightPadColumn(4, 2, CC_XX_GRP);
    }
    
    private void setSortKeyCAndCRecordGroup() {
        this.rightPadColumn(5, 2, BLANK);
    }          
    
    public void setMailingKey(String mailingKey) {
        this.rightPadColumn(6, 12, formatString(mailingKey, 12));
        setFiller3Spaces();
    }
    
    private void setFiller3Spaces() {
        this.rightPadColumn(7, 3, " ");
        setFillerEndSpaces();
    }
    
    private void setFillerEndSpaces() {
        this.rightPadColumn(8, 1967, BLANK);
    }
    
    /**
     * Returns "" if text is null;
     * Truncates text if length exceed fieldLength;
     * @param text String variable to be formatted
     * @param fieldLength Length of Field
     * @return formatted text
     */
    private String formatString(String text, int fieldLength) {
        if(text == null) {
            text = EMPTY_STR;
        }
        else {
            text = text.trim();
            if(text.length() > fieldLength) {
                text = text.substring(0, fieldLength);
            }
        }
        return text;
    }
}
