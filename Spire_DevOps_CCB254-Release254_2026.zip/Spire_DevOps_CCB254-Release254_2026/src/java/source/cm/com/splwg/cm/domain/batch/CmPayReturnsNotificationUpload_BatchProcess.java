/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NI0019.5 - Payment Returns File
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-03-07   Srikanth		NI0019.5. Initial Version.
 * 2013-05-08	Karthik			KL20130508 - Added null check to handle a one-off case.
 * 2013-05-06   Srikanth        SD05062013 - Bug 1924 : Variables Initialization - Previous record values being used.
 * 2013-09-06   Neha            IM-037417 Remove static varibles
 * 2013-09-13	Karthik			KL20130913 - Fix for IM-034003. Modified code to retrieve
 * 								total no of payment return notifications processed,
 * 								no of payment returns successfully cancelled and in error.
 * 2013-09-23	Karthik			KL20130923 - Fix for IM-034616 -- ToDos are Replicating.
 * 2013-10-11	Karthik			KL20131011 - Code changes for CR128 - Add account reference
 * 								to returned payments ToDos
 * 2014-02-19   Neha            IM-044956 Tender not canceled but payments are canceled
 * 2016-01-29  	MPang			Updated for CCB v2.4 compilation.
 * 2018-07-25   SFelip          CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                              longer needed.
 * 2021-03-31   JVitug          CCB030.1. Updated to handle payment returns from Spire
 * 								Alabama and Gulf.
 * 2022-06-18	EQuint			SA-399613 - Cancel payment based on external system
 * 								tender source mapping
 * 2022-08-29   EQuint			B-23965 - added limit days when return file has no
 * 								orig date context
 * 2024-2-27	DarrylH			E08145_B31509 Handle Null exception when acct archive
 ******************************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.Query;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.MessageSeverityLookup;
import com.splwg.base.api.lookup.NotificationUploadContextLookup;
import com.splwg.base.api.lookup.NotificationUploadStatusLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.base.domain.common.lookup.LookupValue_Language;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_Id;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeSortKeyTypes;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadContext;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUploadContexts;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload_DTO;
import com.splwg.base.domain.workflow.notificationUpload.NotificationUpload_Id;
import com.splwg.base.domain.workflow.notificationUploadExtensionType.NotificationUploadExtensionType;
import com.splwg.base.support.context.FrameworkSession;
import com.splwg.base.support.context.SessionHolder;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.PaymentStatusLookup;
import com.splwg.ccb.api.lookup.TenderStatusLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.GeneralLedgerDistributionCode;
import com.splwg.ccb.domain.admin.paymentCancelReason.PaymentCancelReason;
import com.splwg.ccb.domain.admin.paymentCancelReason.PaymentCancelReason_Id;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentTender;
import com.splwg.ccb.domain.payment.paymentEvent.PaymentTender_Id;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.toDoEntry.ToDoMaintenanceData;*/
import com.splwg.ccb.domain.admin.generalLedgerDistributionCode.entity.GeneralLedgerDistributionCode;
import com.splwg.ccb.domain.admin.paymentCancelReason.entity.PaymentCancelReason;
import com.splwg.ccb.domain.admin.paymentCancelReason.entity.PaymentCancelReason_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentTender;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentTender_Id;
import com.splwg.ccb.domain.todo.common.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.data.ToDoMaintenanceData;
import com.splwg.cm.api.lookup.CmBankTenderSourceLookup;
import com.splwg.cm.api.lookup.ExternalSystemTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessages;
import com.splwg.shared.common.ApplicationError;

// KL20131011 - Start delete - Code Change for CR128
///**
// * @author sdesabhatl002
// *
// @BatchJob (modules = {}
// *      , multiThreaded = false, rerunnable = false,
// *      toDoCreation = @ToDoCreation (drillKeyEntity = notificationUpload,
// *            sortKeys = { "NT_UP_ID"}),
// *      softParameters = { @BatchJobSoftParameter (entityName = notificationUploadExtensionType, name = NOTIFICATION_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = toDoType, name = TD_TYPE_CD, required = true, type = entity)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = ACCT_ID_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = AMT_PAID_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = PAY_TYPE_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = ORG_PAY_BATCH_NUM_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = ORG_PAY_DATE_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = RETRN_PAY_DATE_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = RETRN_REASON_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = EXT_PAY_ID_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = CUST_NAME_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = CUST_ADRSS_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)})
// */
// KL20131011 - End delete

/*
 *  KL20131011 - start of Code Change for CR128
 *  Modify annotation to include Account ID Char Type
 */
///**
// * @author sdesabhatl002
// *
// @BatchJob (modules = {}
// *      , multiThreaded = false, rerunnable = false,
// *      softParameters = { @BatchJobSoftParameter (entityName = notificationUploadExtensionType, name = NOTIFICATION_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = toDoType, name = TD_TYPE_CD, required = true, type = entity)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = ACCT_ID_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = AMT_PAID_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = PAY_TYPE_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = ORG_PAY_BATCH_NUM_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = ORG_PAY_DATE_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = RETRN_PAY_DATE_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = RETRN_REASON_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = EXT_PAY_ID_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = CUST_NAME_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = CUST_ADRSS_NT_CTXT_TYPE, required = true, type = lookup)
// *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = ACCT_CHAR_TYPE, required = true, type = entity)})
// */
// KL20131011 - End Change

/**
 * @author sdesabhatl002
 *
 @BatchJob (modules = {}
 *      , multiThreaded = false, rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (entityName = notificationUploadExtensionType, name = NOTIFICATION_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = TD_TYPE_CD, required = true, type = entity)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = ACCT_ID_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = AMT_PAID_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = PAY_TYPE_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = ORG_PAY_BATCH_NUM_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = ORG_PAY_DATE_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = RETRN_PAY_DATE_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = RETRN_REASON_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = EXT_PAY_ID_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = CUST_NAME_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = notificationUploadContext, name = CUST_ADRSS_NT_CTXT_TYPE, required = true, type = lookup)
 *            , @BatchJobSoftParameter (name = MAX_ERRORS, type = integer)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = ACCT_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = lookupField, name = BANK_TENDER_SOURCE_LOOKUP, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = LIMIT_DAYS, required = true, type = integer)})
 */

public class CmPayReturnsNotificationUpload_BatchProcess extends
CmPayReturnsNotificationUpload_BatchProcess_Gen {
	private NotificationUploadExtensionType ntfExtensionType;
	/*
	 * start delete IM-037417 Neha
	 */
	//	private static NotificationUploadContextLookup ctxAcctIdLookup;
	//	private static NotificationUploadContextLookup ctxAmntPaidLookup;
	//	private static NotificationUploadContextLookup ctxPayTypeLookup;
	//	private static NotificationUploadContextLookup ctxOrgPayBatchNumLookup;
	//	private static NotificationUploadContextLookup ctxOrgPayDateLookup;
	//	private static NotificationUploadContextLookup ctxRtrnPayDateLookup;
	//	private static NotificationUploadContextLookup ctxRtrnRsnLookup;
	//	private static NotificationUploadContextLookup ctxExtPayIdLookup;
	//	private static NotificationUploadContextLookup ctxCustNameLookup;
	//	private static NotificationUploadContextLookup ctxCustAddrLookup;
	/*
	 * End delete IM-037417 Neha
	 */

	public void validateSoftParameters(boolean isnewRun){
		initializeSoftparams();
		BigInteger parmMaxErrors = getParameters().getSoftMaxErrors();
		// Check if the override maximum errors is less than 0
		if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
			addError(CustomMessageRepository.na0019_5IntegerParamCannotBeNegative(parmMaxErrors.toString().trim()));
		}

		//KL20131011 - Start of Code change for CR128
		// Account Characteristic Type
		CharacteristicType charType = getParameters().getACCT_CHAR_TYPE();
		CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType.getId(), CharacteristicEntityLookup.constants.TO_DO_ENTRY);
		if (isNull(charEntityId.getEntity())) {
			addError(CustomMessageRepository.NI0019_5_charTypeInvalidForTDEntryEntity(
					charType.getId().getTrimmedValue(),
					CharacteristicEntityLookup.constants.TO_DO_ENTRY.getLookupValue().fetchLanguageDescription()));
		}
		//KL20131011 - End of Code change for CR128

		// start add - EQuint - B-23965 - 2022-08-29
		BigInteger parmLimitDays = getParameters().getLIMIT_DAYS();
		// Check if the limit days is less than 0
		if (notNull(parmLimitDays) && parmLimitDays.intValue() < 0) {
			addError(CustomMessageRepository.na0019_5_returnLimitDaysPositive(parmLimitDays.toString().trim()));
		}
		// end add - EQuint - B-23965 - 2022-08-29

	}

	private void initializeSoftparams(){
		ntfExtensionType = getParameters().getNOTIFICATION_TYPE();
		/*
		 * Start delete IM-037417 Neha
		 */
		//		ctxAcctIdLookup  = getParameters().getACCT_ID_NT_CTXT_TYPE();
		//		ctxAmntPaidLookup = getParameters().getAMT_PAID_NT_CTXT_TYPE();
		//		ctxPayTypeLookup = getParameters().getPAY_TYPE_NT_CTXT_TYPE();
		//		ctxOrgPayBatchNumLookup = getParameters().getORG_PAY_BATCH_NUM_CTXT_TYPE();
		//		ctxOrgPayDateLookup =getParameters().getORG_PAY_DATE_NT_CTXT_TYPE();
		//		ctxRtrnPayDateLookup = getParameters().getRETRN_PAY_DATE_NT_CTXT_TYPE();
		//		ctxRtrnRsnLookup = getParameters().getRETRN_REASON_NT_CTXT_TYPE();
		//		ctxExtPayIdLookup = getParameters().getEXT_PAY_ID_NT_CTXT_TYPE();
		//		ctxCustNameLookup = getParameters().getCUST_NAME_NT_CTXT_TYPE();
		//		ctxCustAddrLookup = getParameters().getCUST_ADRSS_NT_CTXT_TYPE();
		/*
		 * End delete IM-037417 Neha
		 */

	}


	public JobWork getJobWork() {
		//setToDoCreateProcess();
		List<SQLResultRow> pendNotifList = getPendingNotifyList();
		ArrayList <ThreadWorkUnit> workUnitList = new ArrayList<ThreadWorkUnit>();
		for(SQLResultRow resultRow:pendNotifList){
			NotificationUpload_Id ntUploadId = (NotificationUpload_Id)resultRow.getId("NT_UP_ID", NotificationUpload.class);
			ThreadWorkUnit workUnit =  new ThreadWorkUnit(ntUploadId);
			workUnitList.add(workUnit);
		}

		return createJobWorkForThreadWorkUnitList(workUnitList);

	}

	private List<SQLResultRow> getPendingNotifyList(){
		List<SQLResultRow> pendNotifList = null;
		StringBuilder pendingNotifQueryString = new StringBuilder();
		pendingNotifQueryString.append("SELECT NT_UP_ID ");
		pendingNotifQueryString.append("FROM CI_NT_UP ");
		pendingNotifQueryString.append("WHERE NT_UP_XTYPE_CD = :inputNtType ");
		pendingNotifQueryString.append("AND NT_UP_STAT_FLG = :pending ");

		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement pendNotifPrepStmt = createPreparedStatement(pendingNotifQueryString.toString());
		PreparedStatement pendNotifPrepStmt = createPreparedStatement(pendingNotifQueryString.toString(), getClass().getName());
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		pendNotifPrepStmt.bindId("inputNtType", ntfExtensionType.getId());
		pendNotifPrepStmt.bindLookup("pending", NotificationUploadStatusLookup.constants.PENDING);
		pendNotifList = pendNotifPrepStmt.list();
		pendNotifPrepStmt.close();
		return pendNotifList;
	}

	public Class<CmPayReturnsNotificationUpload_BatchProcessWorker> getThreadWorkerClass() {
		return CmPayReturnsNotificationUpload_BatchProcessWorker.class;
	}

	public static class CmPayReturnsNotificationUpload_BatchProcessWorker
	extends	CmPayReturnsNotificationUpload_BatchProcessWorker_Gen {
		/*
		 * Start add IM-037417 Neha
		 */
		private NotificationUploadContextLookup ctxAcctIdLookup;
		private NotificationUploadContextLookup ctxAmntPaidLookup;
		private NotificationUploadContextLookup ctxPayTypeLookup;
		private NotificationUploadContextLookup ctxOrgPayBatchNumLookup;
		private NotificationUploadContextLookup ctxOrgPayDateLookup;
		private NotificationUploadContextLookup ctxRtrnPayDateLookup;
		private NotificationUploadContextLookup ctxRtrnRsnLookup;
		private NotificationUploadContextLookup ctxExtPayIdLookup;
		private NotificationUploadContextLookup ctxCustNameLookup;
		private NotificationUploadContextLookup ctxCustAddrLookup;
		/*
		 * End add IM-037417 Neha
		 */
		//KL20131011 - Start of Code change for CR128
		private ToDoType paramTodoType;
		private CharacteristicType parmAccountIdCharType;
		private MessageCategory_Id msgCatId = new MessageCategory_Id(BigInteger.valueOf(CustomMessageRepository.MESSAGE_CATEGORY));
		// KL20131011 - End of Code change for CR128
		// start add - EQuint - B-23965 - 2022-08-29
		private BigInteger parmLimitDays;
		// end add - EQuint - B-23965 - 2022-08-29

		private NotificationUpload ntfUpload;
		private String strAcctId;
		private String strAmntPaid;
		private String strPayType;
		private String strOrigPayBatchNum;
		private String strOrgPayDate;
		private String strRtrnPayDate;
		private String strRtrnRsn;
		private String strExtPayId;
		private String strCustName;
		private String strCustAddr;

		//KL20131011 - Start of Code change for CR128 - initiating Account ID as null
		private Account_Id acctId = null;
		//KL20131011 - End of Code change for CR128
		private Date orgPayDate;
		private BigDecimal payAmnt;
		private PaymentCancelReason cancelReason = null;
		private static final String DATE_FORMAT = "yy-MM-dd";
		private ThreadWorkUnit twUnit ;
		// start add - EQuint - B-23965 - 2022-08-29
		private Date rtrnPayDate;
		// end add - EQuint - B-23965 - 2022-08-29

		private Integer errCount = 0;
		private Integer totRecCount = 0;
		private Integer totCancelTenderCount = 0;

		//Start Add - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		private static FrameworkSession session;
		//End Add - 2016-01-29 - MPang - Updated for CCB v2.4 compilation

		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			/*
			 * Start add IM-037417 Neha
			 */
			JobParameters parameters = getParameters();
			ctxAcctIdLookup  = parameters.getACCT_ID_NT_CTXT_TYPE();
			ctxAmntPaidLookup = parameters.getAMT_PAID_NT_CTXT_TYPE();
			ctxPayTypeLookup = parameters.getPAY_TYPE_NT_CTXT_TYPE();
			ctxOrgPayBatchNumLookup = parameters.getORG_PAY_BATCH_NUM_CTXT_TYPE();
			ctxOrgPayDateLookup =parameters.getORG_PAY_DATE_NT_CTXT_TYPE();
			ctxRtrnPayDateLookup = parameters.getRETRN_PAY_DATE_NT_CTXT_TYPE();
			ctxRtrnRsnLookup = parameters.getRETRN_REASON_NT_CTXT_TYPE();
			ctxExtPayIdLookup = parameters.getEXT_PAY_ID_NT_CTXT_TYPE();
			ctxCustNameLookup = parameters.getCUST_NAME_NT_CTXT_TYPE();
			ctxCustAddrLookup = parameters.getCUST_ADRSS_NT_CTXT_TYPE();
			/*
			 * End add IM-037417 Neha
			 */
			//KL20131011 - Start of Code change for CR128
			paramTodoType = parameters.getTD_TYPE_CD();
			parmAccountIdCharType = parameters.getACCT_CHAR_TYPE();
			//KL20131011 - End of Code change for CR128
			// start add - EQuint - B-23965 - 2022-08-29
			parmLimitDays = parameters.getLIMIT_DAYS();
			// end add - EQuint - B-23965 - 2022-08-29

			// BUG 1924 SD05062013 Previous record values are being used due to non initialization
			//initialize variables
			strAcctId = null;
			strAmntPaid = null;
			strPayType = null;
			strOrigPayBatchNum = null;
			strOrgPayDate = null;
			strRtrnPayDate = null;
			strRtrnRsn = null;
			strExtPayId  = null;
			strCustName = null;
			strCustAddr = null;
			orgPayDate = null;

			totRecCount = totRecCount+1;
			twUnit = unit;

			ntfUpload = ((NotificationUpload_Id) unit.getPrimaryId()).getEntity();
			NotificationUploadContexts uploadContexts = ntfUpload.getContexts();
			retrieveContextValues(uploadContexts);
			if(isValidContextData().isFalse()){
				setRecordToError();
				return false;
			}


			PaymentTender_Id payTndrId =null;

			if(isBlankOrNull(strExtPayId)){

				// start change - EQuint - SA-399613  - 2018-06-18
				// //Start Change JVitug - CCB030.1 - 2021-03-31
				// //payTndrId = processPayCancelByAmnt();
				// if(notNull(orgPayDate)){
				// 	payTndrId = processPayCancelByAmntAndOrgPayDate();
				// } else {
				// 	payTndrId = processPayCancelByAmnt();
				// }
				// //End Change JVitug - CCB030.1- 2021-03-31
				// if(isNull(payTndrId)){
				//
				//
				//
				// 	// KL20131011 - Start of code change for CR128
				// 	ArrayList <String> msgParamList = new ArrayList<String> ();
				// 	msgParamList.add(0, strAmntPaid);
				// 	//Start Add JVitug - CCB030.1 - 2021-04-08
				// 	if(notNull(orgPayDate)) {
				// 	//End Add JVitug - CCB030.1 - 2021-04-08
				// 		msgParamList.add(1, strOrgPayDate);
				// 	//Start Add JVitug - CCB030.1 - 2021-04-08
				// 		createToDoEntry(msgCatId, CustomMessages.NA0019_5_PAY_TENDER_NOT_FOUND_FOR_PAY_DT, msgParamList);
				// 	} else {
				// 		createToDoEntry(msgCatId, CustomMessages.NA0019_5_PAY_TENDER_NOT_FOUND_FOR_AMT, msgParamList);
				// 	}
				// 	//End Add JVitug - CCB030.1 - 2021-04-08
				// 	//logErrorOrCreateToDo(CustomMessageRepository.na0019_5PayTenderNotFoundForPayDate(strAmntPaid,strOrgPayDate), twUnit);
				// 	// KL20131011 - End of code change for CR128
				// 	setRecordToError();
				// 	return false;
				//
				// }

				List<SQLResultRow> paymentTenderList = notNull(orgPayDate) ? processPayCancelByAmntAndOrgPayDate() : processPayCancelByAmnt();

				// when multiple tenders are retrieved
				if(paymentTenderList.size() > 1){
					if (notNull(ntfUpload.getNotificationExternal())) {
						LookupValue lookupVal = getLookupByDescription(ntfUpload.getNotificationExternal().getId().getTrimmedValue());
						if (notNull(lookupVal)) {
							payTndrId = processMultiplePayments(paymentTenderList, (CmBankTenderSourceLookup) lookupVal.asLookup());
						}
					}

					if (isNull(payTndrId)) {
						ArrayList <String> msgParamList = new ArrayList<String> ();
						msgParamList.add(0, strAmntPaid);
					 	if(notNull(orgPayDate)) {
							msgParamList.add(1, strOrgPayDate);
							createToDoEntry(msgCatId, CustomMessages.NA0019_5_MULTIPLE_PAY_TENDER_FOUND_FOR_PAY_DT, msgParamList);
						} else {
							createToDoEntry(msgCatId, CustomMessages.NA0019_5_MULTIPLE_PAY_TENDER_FOUND_FOR_AMT, msgParamList);
						}
						setRecordToError();
						return false;
					}
				} else if (paymentTenderList.size() == 1) {
					// get payment tender when only 1 is retrieved
					payTndrId = (PaymentTender_Id) paymentTenderList.get(0).getId("PAY_TENDER_ID", PaymentTender.class);
				} else {
					// else if no records is retrieved, create to do
					ArrayList <String> msgParamList = new ArrayList<String> ();
					msgParamList.add(0, strAmntPaid);
				 	if(notNull(orgPayDate)) {
						msgParamList.add(1, strOrgPayDate);
						createToDoEntry(msgCatId, CustomMessages.NA0019_5_PAY_TENDER_NOT_FOUND_FOR_PAY_DT, msgParamList);
					} else {
						createToDoEntry(msgCatId, CustomMessages.NA0019_5_PAY_TENDER_NOT_FOUND_FOR_AMT, msgParamList);
					}
					setRecordToError();
					return false;
				}
				// end change - EQuint - SA-399613  - 2018-06-18
			}else{
				payTndrId = processPayCancelByExtRefId();
				if(isNull(payTndrId)){
					// KL20131011 - Start of code change for CR128
					ArrayList <String> msgParamList = new ArrayList<String> ();
					msgParamList.add(0, strExtPayId);
					msgParamList.add(1, strAmntPaid);
					createToDoEntry(msgCatId, CustomMessages.NA0019_5_PAY_TENDER_NOT_FOUND_FOR_EXT_ID, msgParamList);
					//logErrorOrCreateToDo(CustomMessageRepository.na0019_5PayTenderNotFoundForExtId(strExtPayId,strAmntPaid), twUnit);
					// KL20131011 - End of code change for CR128
					setRecordToError();
					return false;
				}
			}
			//Start Add - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			session = (FrameworkSession)SessionHolder.getSession();
			//End Add - 2016-01-29 - MPang - Updated for CCB v2.4 compilation

			//KL20130923 - Start of fix for IM-034616
			// Moving record from Pending status to Error status when a Base error is thrown
			try{
				//KL20130923 - End of fix for IM-034616
				//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			    // 2014-02-19 - Start of fix  Neha  IM-044956
			    //setSavepoint("Cancel Tender");
			    // 2014-02-19 - End of fix  Neha  IM-044956

				session.setSavepoint("Cancel Tender");
			    //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				cancelPayTender(payTndrId);
				setRecordToComplete();
				//KL20130923 - Start of fix for IM-034616
			}
			catch(ApplicationError error){
				//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			 // 2014-02-19 - Start of fix  Neha  IM-044956
			    //rollbackToSavepoint("Cancel Tender");
			 // 2014-02-19 - End of fix  Neha  IM-044956
				session.rollbackToSavepoint("Cancel Tender");
			  //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
				setRecordToError();

				// KL20131011 - Start of code change for CR128
				ArrayList <String> msgParamList = new ArrayList<String> ();
				List <Object> msgParms = error.getServerMessage().getMessageParameters().getRawParameters();
				int msgParmSize = msgParms.size();

				if(msgParmSize > 0) {
					Iterator<Object> iter = msgParms.iterator();
					int index = 0;
					while(iter.hasNext()){
						msgParamList.add(index, iter.next().toString());
						index++;
					}
				}

				createToDoEntry(error.getServerMessage().getMessageId().getMessageCategoryId(),
						error.getServerMessage().getMessageId().getMessageNumber().intValue(), msgParamList);
				//logErrorOrCreateToDo(error.getServerMessage(), unit);
				// KL20131011 - End of code change for CR128

				return false;
			}
			//KL20130923 - End of fix for IM-034616

			return true;

		}

		/*
		 * KL20131011 - Start of delete for CR128
		 */
		//		public ToDoProperties createToDoProperties(ThreadWorkUnit unit){
		//			ToDoProperties todoProps =  new ToDoProperties(ntfUpload.getId());
		//			todoProps.setNT_UP_ID(ntfUpload.getId().toString());
		//			return todoProps;
		//		}
		/*
		 * KL20131011 - End of Delete for CR128
		 */

		// Start Add - EQuint - SA-399613  - 2018-06-18
		private PaymentTender_Id processMultiplePayments(List<SQLResultRow> paymentTenderList, CmBankTenderSourceLookup lookup) {
			// get tender sources from the feature config
			CmMGEFeatureConfigurationOptionsRetriever cmMGEFeatureConfigurationOptionsRetriever = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
			FeatureConfiguration_Id featureConfigurationId = cmMGEFeatureConfigurationOptionsRetriever.getFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_BANK_TENDER_SOURCE);
			List<String> tenderSources = cmMGEFeatureConfigurationOptionsRetriever.getListOfFeatureOptionValues(featureConfigurationId, lookup);
			PaymentTender_Id tenderToCancel = null;
			if (tenderSources.size() > 0) {
				for (SQLResultRow row: paymentTenderList) {
					PaymentTender tndr = ((PaymentTender_Id) row.getId("PAY_TENDER_ID", PaymentTender.class)).getEntity();

					// start Change - EQuint - B-23965 - 2022-08-29
					// for (String ts: tenderSources) {
					// 	TenderSource tenderSource = new TenderSource_Id(ts).getEntity();
					// 	TenderSource psTenderSource = tndr.getTenderControlId().getEntity().getTenderSource();
					// 	// check if tender source and tender source type is matched
					// 	if (ts.compareToIgnoreCase(tndr.getTenderControlId().getEntity().getTenderSource().getId().getTrimmedValue()) == 0
					// 			&& tenderSource.getTenderSourceType().compareTo(psTenderSource.getTenderSourceType()) == 0) {
					// 		// if tender to cancel is not null, then there are still multiple payment tenders to cancel
					// 		if (notNull(tenderToCancel)) {
					// 			tenderToCancel = null;
					// 			break;
					// 		} else {
					// 			tenderToCancel = tndr.getId();
					// 		}
					// 	}
					// }
					if (tenderSources.contains(tndr.getTenderControlId().getEntity().getTenderSource().getId().getTrimmedValue())) {
						if (notNull(tenderToCancel)) {
							tenderToCancel = null;
							break;
						} else {
							tenderToCancel = tndr.getId();
						}
					}
					// end change - EQuint - B-23965 - 2022-08-29
				}
			}
			return tenderToCancel;
		}
		// End change - EQuint - SA-399613  - 2018-06-18


		@Override
		public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException {

			//KL20130913 - Start of fix for IM-034003
			//logMessage(CustomMessageRepository.na0019_5TotalRecordCount(totRecCount.toString()),MessageSeverityLookup.constants.INFORMATIONAL);
			//logMessage(CustomMessageRepository.na0019_5TotalCancelledTendersCount(totCancelTenderCount.toString()),MessageSeverityLookup.constants.INFORMATIONAL);
			//logMessage(CustomMessageRepository.na0019_5TotalErrorRecordCount(errCount.toString()),MessageSeverityLookup.constants.INFORMATIONAL);

			SQLResultRow resultRow = getRecordCount();
			if(isNull(resultRow)){
				return;
			}
			BigInteger totalRecords = resultRow.getInteger("REC_PROC_CNT");
			BigInteger errorRecords = resultRow.getInteger("REC_ERR_CNT");
			BigInteger recordsProcessed = totalRecords.subtract(errorRecords);

			logMessage(CustomMessageRepository.na0019_5TotalRecordCount(totalRecords.toString()),MessageSeverityLookup.constants.INFORMATIONAL);
			logMessage(CustomMessageRepository.na0019_5TotalCancelledTendersCount(recordsProcessed.toString()),MessageSeverityLookup.constants.INFORMATIONAL);
			logMessage(CustomMessageRepository.na0019_5TotalErrorRecordCount(errorRecords.toString()),MessageSeverityLookup.constants.INFORMATIONAL);
			//KL20130913 - End of fix for IM-034003

		}

		private void retrieveContextValues(NotificationUploadContexts uploadContexts){
			NotificationUploadContextLookup ctxLookUp;
			for(NotificationUploadContext context: uploadContexts){
				// KL20130508 - New entry to Notification Context Lookup does not get reflected until Artifact Generator
				// is run again. So, added a null check to handle this one-off scenario.
				if(isNull(context.getId().getNotificationContextType())){
					continue;
				}
				ctxLookUp = context.getId().getNotificationContextType();

				if(ctxLookUp.compareTo(ctxAcctIdLookup) == 0 ){
					System.out.println("The value of strAcctId is: "+context.getId().getContextValue().trim());
					strAcctId = context.getId().getContextValue().trim();
				}else if(ctxLookUp.compareTo(ctxAmntPaidLookup) == 0){
					strAmntPaid = context.getId().getContextValue().trim();
				}else if(ctxLookUp.compareTo(ctxPayTypeLookup) == 0){
					strPayType = context.getId().getContextValue().trim();
				}else if(ctxLookUp.compareTo(ctxOrgPayBatchNumLookup) == 0){
					strOrigPayBatchNum = context.getId().getContextValue().trim();
				}else if(ctxLookUp.compareTo(ctxOrgPayDateLookup) == 0){
					strOrgPayDate = context.getId().getContextValue().trim();
				}else if(ctxLookUp.compareTo(ctxRtrnPayDateLookup) == 0){
					strRtrnPayDate = context.getId().getContextValue().trim();
				}else if(ctxLookUp.compareTo(ctxRtrnRsnLookup) == 0){
					strRtrnRsn = context.getId().getContextValue().trim();
				}else if(ctxLookUp.compareTo(ctxExtPayIdLookup) == 0){
					strExtPayId = context.getId().getContextValue().trim();
				}else if(ctxLookUp.compareTo(ctxCustNameLookup) == 0){
					strCustName = context.getId().getContextValue().trim();
				}else if(ctxLookUp.compareTo(ctxCustAddrLookup) == 0){
					strCustAddr = context.getId().getContextValue().trim();
				}

			}

		}

		private Bool isValidContextData(){
			//Validate Account Number
			if(isValidAccountNumber().isFalse())
				return Bool.FALSE;

			// KL20131011 - Start of code change for CR128
			//ServerMessage logMessage;
			// KL20131011 - End of code change for CR128

			//validate required COntext values
			if(isValidRequiredContextValues().isFalse())
				return Bool.FALSE;

			//validate Cancel Reason
			cancelReason = new PaymentCancelReason_Id(strRtrnRsn).getEntity();
			if(isNull(cancelReason)){
				// KL20131011 - Start of code change for CR128
				//logMessage = CustomMessageRepository.na0019_5InvalidReturnReasonCode(strRtrnRsn);
				ArrayList <String> msgParamList = new ArrayList<String> ();
				msgParamList.add(0, strRtrnRsn);
				createToDoEntry(msgCatId, CustomMessages.NA0019_5_INVALID_PAY_CANCEL_REASON_CODE, msgParamList);
				//logErrorOrCreateToDo(logMessage, twUnit);
				// KL20131011 - End of code change for CR128

				return Bool.FALSE;
			}

			//Validate Pay amount
			try{
				payAmnt = new BigDecimal(strAmntPaid.trim());
			}catch(NumberFormatException pe){

				// KL20131011 - Start of code change for CR128
				//logMessage = CustomMessageRepository.na0019_5InvalidPaymentAmountSpecified(strAmntPaid);
				ArrayList <String> msgParamList = new ArrayList<String> ();
				msgParamList.add(0, strAmntPaid);
				createToDoEntry(msgCatId, CustomMessages.NA0019_5_INVALID_PAY_AMOUNT_SPECIFIED, msgParamList);
				//logErrorOrCreateToDo(logMessage, twUnit);
				// KL20131011 - End of code change for CR128

				return Bool.FALSE;
			}

			DateFormat df = new DateFormat(DATE_FORMAT);

			//Start Add JVitug - CCB030.1 - 2021-03-31
			String strConvertedDateString = "";
			if(!isBlankOrNull(strOrgPayDate)) {
			//End Add JVitug - CCB030.1 - 2021-03-31
				//Start Change JVitug - CCB030.1 - 2021-03-31
				//String strConvertedDateString = getDateFormatFromString(strOrgPayDate.trim());
				strConvertedDateString = getDateFormatFromString(strOrgPayDate.trim());
				//End Change JVitug - CCB030.1 - 2021-03-31
				if(isBlankOrNull(strConvertedDateString)){

					// KL20131011 - Start of code change for CR128
					//logMessage = CustomMessageRepository.na0019_5InvalidOriginalPayDateSpecified(strOrgPayDate);
					ArrayList <String> msgParamList = new ArrayList<String> ();
					msgParamList.add(0, strOrgPayDate);
					createToDoEntry(msgCatId, CustomMessages.NA0019_5_INVALID_ORIGINAL_PAY_DATE_FORMAT, msgParamList);
					//logErrorOrCreateToDo(logMessage, twUnit);
					// KL20131011 - End of code change for CR128

					return Bool.FALSE;
				}

				// Validate Original pay Date
				try{
					orgPayDate = df.parseDate(strConvertedDateString);
				}catch(DateFormatParseException e){

					// KL20131011 - Start of code change for CR128
					//logMessage = CustomMessageRepository.na0019_5InvalidOriginalPayDateSpecified(strOrgPayDate);
					ArrayList <String> msgParamList = new ArrayList<String> ();
					msgParamList.add(0, strOrgPayDate);
					createToDoEntry(msgCatId, CustomMessages.NA0019_5_INVALID_ORIGINAL_PAY_DATE_FORMAT, msgParamList);
					//logErrorOrCreateToDo(logMessage, twUnit);
					// KL20131011 - End of code change for CR128

					return Bool.FALSE;
				}
			//Start Add JVitug - CCB030.1 - 2021-03-31
			}
			//End Add JVitug - CCB030.1 - 2021-03-31

			//Validate Return pay Date

			if(!isBlankOrNull(strRtrnPayDate)){
				strConvertedDateString = null;
				strConvertedDateString = getDateFormatFromString(strRtrnPayDate.trim());
				if(isBlankOrNull(strConvertedDateString)){

					// KL20131011 - Start of code change for CR128
					//logMessage = CustomMessageRepository.na0019_5InvalidReturnPayDateSpecified(strRtrnPayDate);
					ArrayList <String> msgParamList = new ArrayList<String> ();
					msgParamList.add(0, strRtrnPayDate);
					createToDoEntry(msgCatId, CustomMessages.NA0019_5_INVALID_RETURN_PAY_DATE_FORMAT, msgParamList);
					//logErrorOrCreateToDo(logMessage, twUnit);
					// KL20131011 - End of code change for CR128

					return Bool.FALSE;
				}
				try{
					// start change - EQuint - B-23965 - 2022-08-29
					// df.parseDate(strConvertedDateString);
					rtrnPayDate = df.parseDate(strConvertedDateString);
					// end change - EQuint - B-23965 - 2022-08-29
				}catch(DateFormatParseException e){

					// KL20131011 - Start of code change for CR128
					//logMessage = CustomMessageRepository.na0019_5InvalidReturnPayDateSpecified(strRtrnPayDate);
					ArrayList <String> msgParamList = new ArrayList<String> ();
					msgParamList.add(0, strRtrnPayDate);
					createToDoEntry(msgCatId, CustomMessages.NA0019_5_INVALID_RETURN_PAY_DATE_FORMAT, msgParamList);
					//logErrorOrCreateToDo(logMessage, twUnit);
					// KL20131011 - End of code change for CR128

					return Bool.FALSE;
				}
			}

			return Bool.TRUE;
		}

		private String getDateFormatFromString(String strDate){
			if(strDate.length()!=6)
				return null;

			String strFormatDate = strDate.substring(4) +"-"+strDate.substring(0,2) +"-" + strDate.substring(2, 4);
			return strFormatDate;

		}


		private Bool isValidRequiredContextValues(){

			// KL20131011 - Start of code change for CR128
			ArrayList <String> msgParamList = new ArrayList<String> ();
			//ServerMessage logMessage;

			//Moving this part as the first validation in isValidAccountNumber()
			//if(isNull(strAcctId)){
				// KL20131011 - Start of code change for CR128
				//logMessage = CustomMessageRepository.na0019_5AccountIdIsRequired();
				//logErrorOrCreateToDo(logMessage, twUnit);
				//ArrayList <String> msgParamList = new ArrayList<String> ();
				//msgParamList.add(0, ntfUpload.getId().getIdValue().toString());
				//createToDoEntry(msgCatId, CustomMessages.NA0019_5_ACCOUNT_ID_IS_REQUIRED, msgParamList);
				// KL20131011 - End of code change for CR128
				//return Bool.FALSE;
			//}
			// KL20131011 - End of code change for CR128


			if(isBlankOrNull(strAmntPaid)){

				// KL20131011 - Start of code change for CR128
				//logMessage = CustomMessageRepository.na0019_5AmountIsRequired();
				//logErrorOrCreateToDo(logMessage, twUnit);
				msgParamList.add(0, ntfUpload.getId().getIdValue().toString());
				createToDoEntry(msgCatId, CustomMessages.NA0019_5_AMOUNT_MISSING_IS_REQUIRED, msgParamList);
				// KL20131011 - End of code change for CR128

				return Bool.FALSE;
			}
			//Start Delete JVitug - CCB030.1 - 2021-03-31
			//Original Payment Date context is no longer a required context value
			//if(isBlankOrNull(strOrgPayDate)){

				// KL20131011 - Start of code change for CR128
				//logMessage = CustomMessageRepository.na0019_5OriginalPayDateIsRequired();
				//logErrorOrCreateToDo(logMessage, twUnit);
				//msgParamList.add(0, ntfUpload.getId().getIdValue().toString());
				//createToDoEntry(msgCatId, CustomMessages.NA0019_5_ORIGINAL_PAY_DATE_IS_REQUIRED, msgParamList);
				// KL20131011 - End of code change for CR128

				//return Bool.FALSE;
			//}
			//End Delete JVitug - CCB030.1 - 2021-03-31

			if(isBlankOrNull(strRtrnRsn)){

				// KL20131011 - Start of code change for CR128
				//logMessage = CustomMessageRepository.na0019_5ReturnReasonIsRequired();
				//logErrorOrCreateToDo(logMessage, twUnit);
				msgParamList.add(0, ntfUpload.getId().getIdValue().toString());
				createToDoEntry(msgCatId, CustomMessages.NA0019_5_PAY_CANCEL_REASON_IS_REQUIRED, msgParamList);
				// KL20131011 - End of code change for CR128

				return Bool.FALSE;
			}
			return Bool.TRUE;
		}

		private Bool isValidAccountNumber(){
			Bool isValidAcct = Bool.FALSE;
			// KL20131011 - Start of code change for CR128
			//ServerMessage logMessage;
			if(isBlankOrNull(strAcctId)){
				ArrayList <String> msgParamList = new ArrayList<String> ();
				msgParamList.add(0, ntfUpload.getId().getIdValue().toString());
				createToDoEntry(msgCatId, CustomMessages.NA0019_5_ACCOUNT_ID_IS_REQUIRED, msgParamList);
				return isValidAcct;
			}
			// KL20131011 - End of code change for CR128

			List<SQLResultRow> recCountList = null;
			//Start Change JVitug - CCB030.1 - 2021-04-08
			//Account acct = new Account_Id(strAcctId).getEntity();
			Account acct = null;
			//Check if the length of the account ID is 10.
			if(strAcctId.length() == 10) {
				//Start Change DarrylH-B31509-2024-02-27
			//	acct = new Account_Id(strAcctId).getEntity();
				//When acct is archived acct.getEntiry will create error right away
				try {
					acct = new Account_Id(strAcctId).getEntity();

				}catch (Exception e) {

				}
				//End Change DarrylH-B31509-2024-02-27


			}
			//End Change JVitug - CCB030.1 - 2021-04-08
			if(isNull(acct)){
				recCountList = retrieveAcctIdListFromOldAcct();
				if(recCountList.size()==0){
					// KL20131011 - Start of code change for CR128
					//logMessage = CustomMessageRepository.na0019_5AccountIdNotFound(strAcctId);
					//logErrorOrCreateToDo(logMessage, twUnit);
					ArrayList <String> msgParamList = new ArrayList<String> ();
					msgParamList.add(0, strAcctId);
					createToDoEntry(msgCatId, CustomMessages.NA0019_5_ACCOUNT_ID_NOT_FOUND, msgParamList);
					// KL20131011 - End of code change for CR128

					return isValidAcct;
				}

				if (recCountList.size() >1){
					// KL20131011 - Start of code change for CR128
					//logMessage = CustomMessageRepository.na0019_5AccountFoundForMoreThanOneSA(strAcctId);
					//logErrorOrCreateToDo(logMessage, twUnit);
					ArrayList <String> msgParamList = new ArrayList<String> ();
					msgParamList.add(0, strAcctId);
					createToDoEntry(msgCatId, CustomMessages.NA0019_5_ACCOUNT_FOUND_FOR_MORE_THAN_ONE_SA, msgParamList);
					// KL20131011 - End of code change for CR128

					return isValidAcct;
				}
				if(recCountList.size()==1){
					acctId = (Account_Id)((SQLResultRow)recCountList.get(0)).getId("ACCT_ID", Account.class);
					isValidAcct = Bool.TRUE;
				}
			}else{

				acctId = acct.getId();
				isValidAcct = Bool.TRUE;
			}
			return isValidAcct;
		}


		private List<SQLResultRow> retrieveAcctIdListFromOldAcct(){
			List<SQLResultRow> recCountList = null;

			StringBuilder oldAcctQueryString = new StringBuilder();
			oldAcctQueryString.append("SELECT DISTINCT(ACCT_ID) ACCT_ID  ");
			oldAcctQueryString.append("FROM CI_SA ");
			oldAcctQueryString.append("WHERE OLD_ACCT_ID = :acctId ");

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement oldAcctPrepStmt = createPreparedStatement(oldAcctQueryString.toString());
			PreparedStatement oldAcctPrepStmt = createPreparedStatement(oldAcctQueryString.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			oldAcctPrepStmt.bindStringProperty("acctId",ServiceAgreement.properties.oldAccountId,strAcctId.trim());
			recCountList = oldAcctPrepStmt.list();

			oldAcctPrepStmt.close();
			return recCountList;
		}

		private PaymentTender_Id processPayCancelByExtRefId(){

			PaymentTender_Id tndrId =null;

			StringBuilder payTenderQueryString = new StringBuilder();
			payTenderQueryString.append("SELECT TNDR.PAY_TENDER_ID  ");
			payTenderQueryString.append("FROM CI_PAY_TNDR TNDR , CI_PAY_EVENT EVENT ");
			payTenderQueryString.append("WHERE TNDR.PAYOR_ACCT_ID = :accountId ");
			// CCB v2.6 Upgrade - 2018-07-25 - Start Change
			//payTenderQueryString.append("AND TRIM(TNDR.EXT_REFERENCE_ID) = :extRefId ");
			payTenderQueryString.append("AND TNDR.EXT_REFERENCE_ID = :extRefId ");
			// CCB v2.6 Upgrade - 2018-07-25 - End Change
			payTenderQueryString.append("AND TNDR.TENDER_AMT = :tndrAmnt ");
			payTenderQueryString.append("AND TNDR.TNDR_STATUS_FLG != :cancel ");
			payTenderQueryString.append("AND TNDR.PAY_EVENT_ID = EVENT.PAY_EVENT_ID ");
			payTenderQueryString.append("ORDER BY EVENT.CRE_DTTM DESC ");

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement payTndrPrepStmt = createPreparedStatement(payTenderQueryString.toString());
			PreparedStatement payTndrPrepStmt = createPreparedStatement(payTenderQueryString.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			payTndrPrepStmt.bindId("accountId", acctId);
			payTndrPrepStmt.bindStringProperty("extRefId", PaymentTender.properties.externalReferenceId, strExtPayId);
			payTndrPrepStmt.bindBigDecimal("tndrAmnt",payAmnt);
			payTndrPrepStmt.bindLookup("cancel",TenderStatusLookup.constants.CANCELED);

			if (payTndrPrepStmt.list().size() > 0 ){
				tndrId = (PaymentTender_Id)payTndrPrepStmt.firstRow().getId("PAY_TENDER_ID", PaymentTender.class);
			}

			payTndrPrepStmt.close();
			return tndrId;
		}

		// start add - EQuint - SA-399613  - 2018-06-18
		private LookupValue getLookupByDescription(String description) {
			// End change - EQuint - SA-399613  - 2018-06-18

			Query<LookupValue_Language> query = createQuery("FROM LookupValue_Language lvl "
					+ "WHERE lvl.id.parent.id.fieldName = :fieldName "
					+ "AND lvl.id.language = :languageCode "
					+ "AND lvl.description = :description ", getClass().getName());

			query.bindEntity("fieldName", getParameters().getBANK_TENDER_SOURCE_LOOKUP());
			query.bindEntity("languageCode", getActiveContextLanguage());
			query.bindStringProperty("description", LookupValue.properties.languageDescription, description);

			LookupValue_Language lookup = query.firstRow();
			return lookup.getParent();
		}

		// end add - EQuint - SA-399613  - 2018-06-18

		// start change - EQuint - SA-399613  - 2018-06-18
		// //Start Change JVitug - CCB030.1 - 2021-03-31
		// //private PaymentTender_Id processPayCancelByAmnt(){
		// private PaymentTender_Id processPayCancelByAmntAndOrgPayDate() {
		// //End Change JVitug - CCB030.1 - 2021-03-31
		// 		PaymentTender_Id tndrId =null;

		private List<SQLResultRow> processPayCancelByAmntAndOrgPayDate() {
		// End change - EQuint - SA-399613  - 2018-06-18

			StringBuilder payTenderQueryString = new StringBuilder();
			payTenderQueryString.append("SELECT TNDR.PAY_TENDER_ID  ");
			// start change - EQuint - SA-399613  - 2018-06-18
			// payTenderQueryString.append("FROM CI_PAY_TNDR TNDR , CI_PAY_EVENT EVENT ");
			payTenderQueryString.append("FROM CI_PAY_TNDR TNDR , CI_PAY_EVENT EVENT, CI_PAY PAY ");
			// end change - EQuint - SA-399613  - 2018-06-18
			payTenderQueryString.append("WHERE TNDR.PAYOR_ACCT_ID = :accountId ");
			payTenderQueryString.append("AND EVENT.PAY_DT = :orgPayDt ");
			payTenderQueryString.append("AND TNDR.TENDER_AMT = :tndrAmnt ");
			payTenderQueryString.append("AND TNDR.TNDR_STATUS_FLG != :cancel ");
			payTenderQueryString.append("AND TNDR.PAY_EVENT_ID = EVENT.PAY_EVENT_ID ");
			// start add - EQuint - SA-399613  - 2018-06-18
			payTenderQueryString.append("AND PAY.PAY_EVENT_ID = EVENT.PAY_EVENT_ID ");
			payTenderQueryString.append("AND PAY.PAY_STATUS_FLG = :frozen ");
			// end add - EQuint - SA-399613  - 2018-06-18
			payTenderQueryString.append("ORDER BY EVENT.CRE_DTTM DESC ");

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement payTndrPrepStmt = createPreparedStatement(payTenderQueryString.toString());
			PreparedStatement payTndrPrepStmt = createPreparedStatement(payTenderQueryString.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			payTndrPrepStmt.bindId("accountId", acctId);
			payTndrPrepStmt.bindDate("orgPayDt", orgPayDate);
			payTndrPrepStmt.bindBigDecimal("tndrAmnt",payAmnt);
			payTndrPrepStmt.bindLookup("cancel",TenderStatusLookup.constants.CANCELED);
			// start add - EQuint - SA-399613  - 2018-06-18
			payTndrPrepStmt.bindLookup("frozen",PaymentStatusLookup.constants.FROZEN);
			// end end - EQuint - SA-399613  - 2018-06-18


			// start change - EQuint - SA-399613  - 2018-06-18
			// if (payTndrPrepStmt.list().size() > 0 ){
			// 	tndrId = (PaymentTender_Id)payTndrPrepStmt.firstRow().getId("PAY_TENDER_ID", PaymentTender.class);
			// }

			// payTndrPrepStmt.close();
			// return tndrId;

			List<SQLResultRow> list = payTndrPrepStmt.list();
			payTndrPrepStmt.close();
			return list;

			// end change - EQuint - SA-399613  - 2018-06-18

		}

		// start change - EQuint - SA-399613  - 2018-06-18
		//Start Add JVitug - CCB030.1 - 2021-03-31
		// private PaymentTender_Id processPayCancelByAmnt() {
		// 	PaymentTender_Id tndrId =null;
		private List<SQLResultRow> processPayCancelByAmnt() {
		// end change - EQuint - SA-399613  - 2018-06-18

			// start add - EQuint - B-23965 - 2022-08-29
			Date limitDate = rtrnPayDate.addDays(parmLimitDays.negate().intValue());
			// end add - EQuint - B-23965 - 2022-08-29

			StringBuilder payTenderQueryString = new StringBuilder();
			payTenderQueryString.append("SELECT TNDR.PAY_TENDER_ID  ");
			// start change - EQuint - SA-399613  - 2018-06-18
			// payTenderQueryString.append("FROM CI_PAY_TNDR TNDR , CI_PAY_EVENT EVENT ");
			payTenderQueryString.append("FROM CI_PAY_TNDR TNDR , CI_PAY_EVENT EVENT, CI_PAY PAY ");
			// end change - EQuint - SA-399613  - 2018-06-18
			payTenderQueryString.append("WHERE TNDR.PAYOR_ACCT_ID = :accountId ");
			payTenderQueryString.append("AND TNDR.TENDER_AMT = :tndrAmnt ");
			payTenderQueryString.append("AND TNDR.TNDR_STATUS_FLG != :cancel ");
			payTenderQueryString.append("AND TNDR.PAY_EVENT_ID = EVENT.PAY_EVENT_ID ");
			// start add - EQuint - SA-399613  - 2018-06-18
			payTenderQueryString.append("AND PAY.PAY_EVENT_ID = EVENT.PAY_EVENT_ID ");
			payTenderQueryString.append("AND PAY.PAY_STATUS_FLG = :frozen ");
			// end add - EQuint - SA-399613  - 2018-06-18
			// start change - EQuint - B-23965 - 2022-08-29
			//payTenderQueryString.append("ORDER BY EVENT.CRE_DTTM DESC ");
			payTenderQueryString.append("AND EVENT.PAY_DT BETWEEN :limitDate AND :returnDate ");
			payTenderQueryString.append("ORDER BY EVENT.PAY_DT DESC ");
			// end change - EQuint - B-23965 - 2022-08-29

			PreparedStatement payTndrPrepStmt = createPreparedStatement(payTenderQueryString.toString(), getClass().getName());
			payTndrPrepStmt.bindId("accountId", acctId);
			payTndrPrepStmt.bindBigDecimal("tndrAmnt",payAmnt);
			payTndrPrepStmt.bindLookup("cancel",TenderStatusLookup.constants.CANCELED);
			// start add - EQuint - SA-399613  - 2018-06-18
			payTndrPrepStmt.bindLookup("frozen",PaymentStatusLookup.constants.FROZEN);
			// end end - EQuint - SA-399613  - 2018-06-18

			// start add - EQuint - B-23965 - 2022-08-29
			payTndrPrepStmt.bindDate("limitDate", limitDate);
			payTndrPrepStmt.bindDate("returnDate", rtrnPayDate);
			// end add - EQuint - B-23965 - 2022-08-29

			// start change - EQuint - SA-399613  - 2018-06-18
			// if (payTndrPrepStmt.list().size() > 0 ){
			// 	tndrId = (PaymentTender_Id)payTndrPrepStmt.firstRow().getId("PAY_TENDER_ID", PaymentTender.class);
			// }

			// payTndrPrepStmt.close();
			// return tndrId;

			List<SQLResultRow> list = payTndrPrepStmt.list();
			payTndrPrepStmt.close();
			return list;
			// end  change - EQuint - SA-399613  - 2018-06-18

		}
		//End Add JVitug - CCB030.1 - 2021-03-31

		private void cancelPayTender(PaymentTender_Id payTenderId){
			PaymentTender tender = payTenderId.getEntity();
			GeneralLedgerDistributionCode gLDistCode = tender.fetchTenderControl().getTenderSource().getBankAccount().getDistributionCode();
			tender.cancel(cancelReason, gLDistCode);
			totCancelTenderCount = totCancelTenderCount +1;
		}

		private void setRecordToError(){
			errCount = errCount +1;
			NotificationUpload_DTO ntfUploadDTO = ntfUpload.getDTO();
			ntfUploadDTO.setNotificationStatus(NotificationUploadStatusLookup.constants.ERROR);
			ntfUpload.setDTO(ntfUploadDTO);
		}

		private void setRecordToComplete(){
			NotificationUpload_DTO ntfUploadDTO = ntfUpload.getDTO();
			ntfUploadDTO.setNotificationStatus(NotificationUploadStatusLookup.constants.COMPLETE);
			ntfUpload.setDTO(ntfUploadDTO);
		}

		//KL20130913 - Start of fix for IM-034003
		private SQLResultRow getRecordCount(){
			StringBuilder getRecordCountSQL = new StringBuilder();
			getRecordCountSQL.append("SELECT REC_PROC_CNT, REC_ERR_CNT FROM CI_BATCH_INST ");
			getRecordCountSQL.append("WHERE BATCH_CD = :batchCd AND BATCH_NBR = :batchNumber ");
			getRecordCountSQL.append("ORDER BY VERSION DESC ");

			//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			//PreparedStatement getRecordCountPrepStmt = createPreparedStatement(getRecordCountSQL.toString());
			PreparedStatement getRecordCountPrepStmt = createPreparedStatement(getRecordCountSQL.toString(), getClass().getName());
			//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
			getRecordCountPrepStmt.bindId("batchCd", getBatchControlId());
			getRecordCountPrepStmt.bindBigInteger("batchNumber", getBatchNumber());

			if(getRecordCountPrepStmt.list().isEmpty()){
				return null;
			}

			return getRecordCountPrepStmt.firstRow();
		}
		//KL20130913 - End of fix for IM-034003

		//KL20131011 - Start of Code change for CR128
		private void createToDoEntry(MessageCategory_Id msgCatId, int msgNum, ArrayList <String> messageParameterList){
			ToDoEntry_DTO entryDto  = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
			ToDoType toDoType = paramTodoType;

			entryDto.setToDoTypeId(toDoType.getId());
			entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
			entryDto.setCreationDateTime(getProcessDateTime());

			ArrayList<ToDoSortKeyValue_DTO>sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();
			ToDoTypeSortKeyTypes sortKeyTypes = toDoType.getSortKeyTypes();

			for (Iterator<ToDoSortKeyType> iter = sortKeyTypes.iterator(); iter.hasNext();) {
				ToDoSortKeyType sortKeyType = (ToDoSortKeyType) iter.next();
				ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
				BigInteger seq = sortKeyType.fetchIdSequence();
				sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));

				if(sortKeyType.getId().getSequence().compareTo(BigInteger.valueOf(1))==0){
					sortKeyDto.setKeyValue(ntfUpload.getId().getIdValue().toString());
				}
				sortKeyList.add(sortKeyDto);
			}

			ArrayList<ToDoDrillKeyValue_DTO>drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
			ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO) createDTO(ToDoDrillKeyValue.class);
			ToDoDrillKeyType drillKeyType = (ToDoDrillKeyType) toDoType.getDrillKeyTypes().iterator().next();
			BigInteger sequence = drillKeyType.fetchIdSequence();
			drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, sequence));

			drillKeyDto.setKeyValue(ntfUpload.getId().getIdValue().toString());
			drillKeyList.add(drillKeyDto);

			//MessageCategory_Id msgCatId = new MessageCategory_Id(BigInteger.valueOf(CustomMessageRepository.MESSAGE_CATEGORY));
			Message_Id msgId = new Message_Id(msgCatId, BigInteger.valueOf(msgNum));
			entryDto.setMessageId(msgId);

			ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory.newInstance();

			toDoEntryData.setDrillKeys(drillKeyList);
			toDoEntryData.setEntryDto(entryDto);
			toDoEntryData.setSortKeys(sortKeyList);
			if(!messageParameterList.isEmpty()){
				toDoEntryData.setMessageParams(messageParameterList);
			}

			List <ToDoEntryCharacteristic_DTO> charList = new ArrayList<ToDoEntryCharacteristic_DTO>();

			if(notNull(acctId)){
				ToDoEntryCharacteristic_DTO toDoCharDTO = (ToDoEntryCharacteristic_DTO) createDTO(ToDoEntryCharacteristic.class);
				toDoCharDTO.setId(new ToDoEntryCharacteristic_Id(ToDoEntry_Id.NULL,parmAccountIdCharType.getId(),BigInteger.ONE));
				CharacteristicTypeLookup toDoCharTypeLookup = parmAccountIdCharType.getCharacteristicType();
				if(toDoCharTypeLookup.isAdhocValue()){
					toDoCharDTO.setAdhocCharacteristicValue(acctId.getIdValue().trim());
				} else if (toDoCharTypeLookup.isPredefinedValue()){
					toDoCharDTO.setCharacteristicValue(acctId.getIdValue().trim());
				} else if (toDoCharTypeLookup.isForeignKeyValue()){
					toDoCharDTO.setCharacteristicValueForeignKey1(acctId.getIdValue().trim());
				}
				charList.add(toDoCharDTO);
			}

			toDoEntryData.setToDoCharacteristics(charList);

			ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
			ToDoEntry toDoEntry = toDoProcessor.addToDo(toDoEntryData);

		}
		//KL20131011 - End of Code change for CR128

	}//Inner

}
