/*******************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * CIS Attributes Record 
 *
 ********************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-02-21   SMiranda        NI0028.03. Initial Version.
 ********************************************************************************/
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmExtractCISAttributesRecord 
        extends ColumnDelimitedRecord {

    public CmExtractCISAttributesRecord() {        
        super(77);        
    }
    
    /*
     * Set the Badge Number for the Record Line
     */
    public void setBadgeNumber(String badgeNumber) {
        this.rightPadColumn(1, 16, cmTruncateString(badgeNumber, 16));
    }
    /*
     * Set the Service Type for the Record Line
     */
    public void setServiceType(String serviceType) {
        this.rightPadColumn(2, 1, cmTruncateString(serviceType, 1));
    }
    /*
     * Set the Manufacturer Code for the Record Line
     */
    public void setManufacturerCode(String manufacturerCode) {
        this.rightPadColumn(3, 1, cmTruncateString(manufacturerCode, 1));
    }
    /*
     * Set the Utility Company for the Record Line
     */
    public void setUtilityCompany(String utilityCompany) {
        this.rightPadColumn(4, 2, cmTruncateString(utilityCompany, 2));
    }
    /*
     * Set the Service Point ID for the Record Line
     */
    public void setServicePointId(String servicePointId) {
        this.rightPadColumn(5, 10, cmTruncateString(servicePointId, 10));
    }
    /*
     * Set the Read Route for the Record Line
     */
    public void setReadRoute(String readRoute) {
        this.rightPadColumn(6, 12, cmTruncateString(readRoute, 12));
    }
    /*
     * Set the Town Code for the Record Line
     */
    public void setTownCode(String townCode) {
        this.rightPadColumn(7, 3, cmTruncateString(townCode, 3));
    }
    /*
     * Set the Grid Code for the Record Line
     */
    public void setGridCode(String gridCode) {
        this.rightPadColumn(8, 50, cmTruncateString(gridCode, 50));
    }
    /*
     * Set the Landlord ID for the Record Line
     */
    public void setLandlordId(String landlordId) {
        this.rightPadColumn(9, 10, cmTruncateString(landlordId, 10));
    }
    /*
     * Set the Landlord Account ID for the Record Line
     */
    public void setLandlordAccountId(String landlordAccountId) {
        this.rightPadColumn(10, 10, cmTruncateString(landlordAccountId, 10));
    }
    /*
     * Set the Customer Class Code for the Record Line
     */
    public void setCustomerClassCode(String customerClassCode) {
        this.rightPadColumn(11, 8, cmTruncateString(customerClassCode, 8));
    }
    /*
     * Set the Person ID for the Record Line
     */
    public void setPersonId(String personId) {
        this.rightPadColumn(12, 10, cmTruncateString(personId, 10));
    }
    /*
     * Set the Service Agreement ID for the Record Line
     */
    public void setServiceAgreementId(String serviceAgreementId) {
        this.rightPadColumn(13, 10, cmTruncateString(serviceAgreementId, 10));
    }
    /*
     * Set the Account ID for the Record Line
     */
    public void setAccountId(String accountId) {
        this.rightPadColumn(14, 10, cmTruncateString(accountId, 10));
    }
    /*
     * Set the Revenue Class for the Record Line
     */
    public void setRevenueClass(String revenueClass) {
        this.rightPadColumn(15, 8, cmTruncateString(revenueClass, 8));
    }
    /*
     * Set the Heat Grant for the Record Line
     */
    public void setHeatGrant(String heatGrant) {
        this.rightPadColumn(16, 1, cmTruncateString(heatGrant, 1));
    }
    /*
     * Set the Bill Cycle for the Record Line
     */
    public void setBillCycle(String billCycle) {
        this.rightPadColumn(17, 4, cmTruncateString(billCycle, 4));
    }
    /*
     * Set the Irregular Use Code for the Record Line
     */
    public void setIrregularUseCode(String irregularUseCode) {
        this.rightPadColumn(18, 1, cmTruncateString(irregularUseCode, 1));
    }
    /*
     * Set the Meter On/Off Flag for the Record Line
     */
    public void setMeterOnOffFlag(String meterOnOffFlag) {
        this.rightPadColumn(19, 2, cmTruncateString(meterOnOffFlag, 2));
    }
    /*
     * Set the Service Point Source Status Flag for the Record Line
     */
    public void setServicePointSourceStatusFlag(String servicePointSourceStatusFlag) {
        this.rightPadColumn(20, 2, cmTruncateString(servicePointSourceStatusFlag, 2));
    }
    /*
     * Set the Meter Size for the Record Line
     */
    public void setMeterSize(String meterSize) {
        this.rightPadColumn(21, 5, cmTruncateString(meterSize, 5));
    }
    /*
     * Set the Meter Location for the Record Line
     */
    public void setMeterLocation(String meterLocation) {
        this.rightPadColumn(22, 1, cmTruncateString(meterLocation, 1));
    }
    /*
     * Set the Meter Dial Count for the Record Line
     */
    public void setMeterDialCount(String meterDialCount) {
        this.leftPadColumnWithZeros(23, 2, cmTruncateString(meterDialCount, 2));
    }
    /*
     * Set the CIS Division for the Record Line
     */
    public void setCisDivision(String cisDivision) {
        this.rightPadColumn(24, 5, cmTruncateString(cisDivision, 5));
    }
    /*
     * Set the SA Type Code for the Record Line
     */
    public void setSaTypeCode(String saTypeCode) {
        this.rightPadColumn(25, 8, cmTruncateString(saTypeCode, 8));
    }
    /*
     * Set the Meter Multiplier for the Record Line
     */
    public void setMeterMultiplier(String meterMultiplier) {
        this.leftPadColumnWithZeros(26, 13, cmTruncateString(meterMultiplier, 13));
    }
    /*
     * Set the AMR Device Switch for the Record Line
     */
    public void setAmrDeviceSwitch(String amrDeviceSwitch) {
        this.rightPadColumn(27, 1, cmTruncateString(amrDeviceSwitch, 1));
    }
    /*
     * Set the Appliance Type 1 for the Record Line
     */
    public void setApplianceType1(String applianceType1) {
        this.rightPadColumn(28, 8, cmTruncateString(applianceType1, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 1 for the Record Line
     */
    public void setNumberOfApplianceType1(String numberOfApplianceType1) {
        this.leftPadColumnWithZeros(29, 3, cmTruncateString(numberOfApplianceType1, 3));
    }
    /*
     * Set the Appliance Type 2 for the Record Line
     */
    public void setApplianceType2(String applianceType2) {
        this.rightPadColumn(30, 8, cmTruncateString(applianceType2, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 2 for the Record Line
     */
    public void setNumberOfApplianceType2(String numberOfApplianceType2) {
        this.leftPadColumnWithZeros(31, 3, cmTruncateString(numberOfApplianceType2, 3));
    }
    /*
     * Set the Appliance Type 3 for the Record Line
     */
    public void setApplianceType3(String applianceType3) {
        this.rightPadColumn(32, 8, cmTruncateString(applianceType3, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 3 for the Record Line
     */
    public void setNumberOfApplianceType3(String numberOfApplianceType3) {
        this.leftPadColumnWithZeros(33, 3, cmTruncateString(numberOfApplianceType3, 3));
    }
    /*
     * Set the Appliance Type 4 for the Record Line
     */
    public void setApplianceType4(String applianceType4) {
        this.rightPadColumn(34, 8, cmTruncateString(applianceType4, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 4 for the Record Line
     */
    public void setNumberOfApplianceType4(String numberOfApplianceType4) {
        this.leftPadColumnWithZeros(35, 3, cmTruncateString(numberOfApplianceType4, 3));
    }
    /*
     * Set the Appliance Type 5 for the Record Line
     */
    public void setApplianceType5(String applianceType5) {
        this.rightPadColumn(36, 8, cmTruncateString(applianceType5, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 5 for the Record Line
     */
    public void setNumberOfApplianceType5(String numberOfApplianceType5) {
        this.leftPadColumnWithZeros(37, 3, cmTruncateString(numberOfApplianceType5, 3));
    }
    /*
     * Set the Appliance Type 6 for the Record Line
     */
    public void setApplianceType6(String applianceType6) {
        this.rightPadColumn(38, 8, cmTruncateString(applianceType6, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 6 for the Record Line
     */
    public void setNumberOfApplianceType6(String numberOfApplianceType6) {
        this.leftPadColumnWithZeros(39, 3, cmTruncateString(numberOfApplianceType6, 3));
    }
    /*
     * Set the Appliance Type 7 for the Record Line
     */
    public void setApplianceType7(String applianceType7) {
        this.rightPadColumn(40, 8, cmTruncateString(applianceType7, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 7 for the Record Line
     */
    public void setNumberOfApplianceType7(String numberOfApplianceType7) {
        this.leftPadColumnWithZeros(41, 3, cmTruncateString(numberOfApplianceType7, 3));
    }
    /*
     * Set the Appliance Type 8 for the Record Line
     */
    public void setApplianceType8(String applianceType8) {
        this.rightPadColumn(42, 8, cmTruncateString(applianceType8, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 8 for the Record Line
     */
    public void setNumberOfApplianceType8(String numberOfApplianceType8) {
        this.leftPadColumnWithZeros(43, 3, cmTruncateString(numberOfApplianceType8, 3));
    }
    /*
     * Set the Appliance Type 9 for the Record Line
     */
    public void setApplianceType9(String applianceType9) {
        this.rightPadColumn(44, 8, cmTruncateString(applianceType9, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 9 for the Record Line
     */
    public void setNumberOfApplianceType9(String numberOfApplianceType9) {
        this.leftPadColumnWithZeros(45, 3, cmTruncateString(numberOfApplianceType9, 3));
    }
    /*
     * Set the Appliance Type 10 for the Record Line
     */
    public void setApplianceType10(String applianceType10) {
        this.rightPadColumn(46, 8, cmTruncateString(applianceType10, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 10 for the Record Line
     */
    public void setNumberOfApplianceType10(String numberOfApplianceType10) {
        this.leftPadColumnWithZeros(47, 3, cmTruncateString(numberOfApplianceType10, 3));
    }
    /*
     * Set the Appliance Type 11 for the Record Line
     */
    public void setApplianceType11(String applianceType11) {
        this.rightPadColumn(48, 8, cmTruncateString(applianceType11, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 11 for the Record Line
     */
    public void setNumberOfApplianceType11(String numberOfApplianceType11) {
        this.leftPadColumnWithZeros(49, 3, cmTruncateString(numberOfApplianceType11, 3));
    }
    /*
     * Set the Appliance Type 12 for the Record Line
     */
    public void setApplianceType12(String applianceType12) {
        this.rightPadColumn(50, 8, cmTruncateString(applianceType12, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 12 for the Record Line
     */
    public void setNumberOfApplianceType12(String numberOfApplianceType12) {
        this.leftPadColumnWithZeros(51, 3, cmTruncateString(numberOfApplianceType12, 3));
    }
    /*
     * Set the Appliance Type 13 for the Record Line
     */
    public void setApplianceType13(String applianceType13) {
        this.rightPadColumn(52, 8, cmTruncateString(applianceType13, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 13 for the Record Line
     */
    public void setNumberOfApplianceType13(String numberOfApplianceType13) {
        this.leftPadColumnWithZeros(53, 3, cmTruncateString(numberOfApplianceType13, 3));
    }
    /*
     * Set the Appliance Type 14 for the Record Line
     */
    public void setApplianceType14(String applianceType14) {
        this.rightPadColumn(54, 8, cmTruncateString(applianceType14, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 14 for the Record Line
     */
    public void setNumberOfApplianceType14(String numberOfApplianceType14) {
        this.leftPadColumnWithZeros(55, 3, cmTruncateString(numberOfApplianceType14, 3));
    }
    /*
     * Set the Appliance Type 15 for the Record Line
     */
    public void setApplianceType15(String applianceType15) {
        this.rightPadColumn(56, 8, cmTruncateString(applianceType15, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 15 for the Record Line
     */
    public void setNumberOfApplianceType15(String numberOfApplianceType15) {
        this.leftPadColumnWithZeros(57, 3, cmTruncateString(numberOfApplianceType15, 3));
    }
    /*
     * Set the Appliance Type 16 for the Record Line
     */
    public void setApplianceType16(String applianceType16) {
        this.rightPadColumn(58, 8, cmTruncateString(applianceType16, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 16 for the Record Line
     */
    public void setNumberOfApplianceType16(String numberOfApplianceType16) {
        this.leftPadColumnWithZeros(59, 3, cmTruncateString(numberOfApplianceType16, 3));
    }
    /*
     * Set the Appliance Type 17 for the Record Line
     */
    public void setApplianceType17(String applianceType17) {
        this.rightPadColumn(60, 8, cmTruncateString(applianceType17, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 17 for the Record Line
     */
    public void setNumberOfApplianceType17(String numberOfApplianceType17) {
        this.leftPadColumnWithZeros(61, 3, cmTruncateString(numberOfApplianceType17, 3));
    }
    /*
     * Set the Appliance Type 18 for the Record Line
     */
    public void setApplianceType18(String applianceType18) {
        this.rightPadColumn(62, 8, cmTruncateString(applianceType18, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 18 for the Record Line
     */
    public void setNumberOfApplianceType18(String numberOfApplianceType18) {
        this.leftPadColumnWithZeros(63, 3, cmTruncateString(numberOfApplianceType18, 3));
    }
    /*
     * Set the Appliance Type 19 for the Record Line
     */
    public void setApplianceType19(String applianceType19) {
        this.rightPadColumn(64, 8, cmTruncateString(applianceType19, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 19 for the Record Line
     */
    public void setNumberOfApplianceType19(String numberOfApplianceType19) {
        this.leftPadColumnWithZeros(65, 3, cmTruncateString(numberOfApplianceType19, 3));
    }
    /*
     * Set the Appliance Type 20 for the Record Line
     */
    public void setApplianceType20(String applianceType20) {
        this.rightPadColumn(66, 8, cmTruncateString(applianceType20, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 20 for the Record Line
     */
    public void setNumberOfApplianceType20(String numberOfApplianceType20) {
        this.leftPadColumnWithZeros(67, 3, cmTruncateString(numberOfApplianceType20, 3));
    }
    /*
     * Set the Appliance Type 21 for the Record Line
     */
    public void setApplianceType21(String applianceType21) {
        this.rightPadColumn(68, 8, cmTruncateString(applianceType21, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 21 for the Record Line
     */
    public void setNumberOfApplianceType21(String numberOfApplianceType21) {
        this.leftPadColumnWithZeros(69, 3, cmTruncateString(numberOfApplianceType21, 3));
    }
    /*
     * Set the Appliance Type 22 for the Record Line
     */
    public void setApplianceType22(String applianceType22) {
        this.rightPadColumn(70, 8, cmTruncateString(applianceType22, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 22 for the Record Line
     */
    public void setNumberOfApplianceType22(String numberOfApplianceType22) {
        this.leftPadColumnWithZeros(71, 3, cmTruncateString(numberOfApplianceType22, 3));
    }
    /*
     * Set the Appliance Type 23 for the Record Line
     */
    public void setApplianceType23(String applianceType23) {
        this.rightPadColumn(72, 8, cmTruncateString(applianceType23, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 23 for the Record Line
     */
    public void setNumberOfApplianceType23(String numberOfApplianceType23) {
        this.leftPadColumnWithZeros(73, 3, cmTruncateString(numberOfApplianceType23, 3));
    }
    /*
     * Set the Appliance Type 24 for the Record Line
     */
    public void setApplianceType24(String applianceType24) {
        this.rightPadColumn(74, 8, cmTruncateString(applianceType24, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 24 for the Record Line
     */
    public void setNumberOfApplianceType24(String numberOfApplianceType24) {
        this.leftPadColumnWithZeros(75, 3, cmTruncateString(numberOfApplianceType24, 3));
    }
    /*
     * Set the Appliance Type 25 for the Record Line
     */
    public void setApplianceType25(String applianceType25) {
        this.rightPadColumn(76, 8, cmTruncateString(applianceType25, 8));
    }
    /*
     * Set the Number of Appliances for Appliance Type 25 for the Record Line
     */
    public void setNumberOfApplianceType25(String numberOfApplianceType25) {
        this.leftPadColumnWithZeros(77, 3, cmTruncateString(numberOfApplianceType25, 3));
    }
    
    private String cmTruncateString(String string, int maxFieldLength){
        if (string.length() > maxFieldLength){
            return string.substring(0, maxFieldLength).trim();            
        } else {
            return string.trim();
        }
    }
}
