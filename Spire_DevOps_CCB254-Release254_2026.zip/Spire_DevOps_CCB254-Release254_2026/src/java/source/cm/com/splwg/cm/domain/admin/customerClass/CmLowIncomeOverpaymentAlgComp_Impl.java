/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Algorithm - Low Income Overpayment Distribution
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:			Reason:
 * YYYY-MM-DD   IN			Reason text.
 *
 * 2013-03-04   RDizon		NA0050. Initial Version.
 * 2013-03-26   CVB       	Fix issue on non creation of Dollar Help SA.
 * 2013-07-04   CVB       	Start SA on Pending Start instead of Active.
 * 2013-02-04   Neha	  	Implemented the new setters and getters under the 
 *						  	Algorithm Spot added as part of SP8
 * 2015-02-23   BMarquez  	SF-3134789. If Non-Billable Dollar SA Type
 *                        	is not provided, disable $1 Charity Overpayments
 * 2016-01-25   MPang		Updated for CCB v2.4 compilation.
 * 2016-10-12   PSree		Updated for Incident# 73573.
 * 2019-02-14	SRoman		Defect 4206113. 1. Handle the Null Pointer Issue
 * 							on missing tender control Id for direct debit
 * 							payments. 2. Removed unused imports.
 * 2019-03-04   MPang       Defect 4216682. Move the retrieval of Tender 
 *                          Control Id to a variable.
 * 2020-09-28   DLampa      B-17238. Check for pledge payments only when 
 *                          a Payment Id is available.
 * 2020-01-07   JVitug      CCB022. Added logic to transfer the credit amount
 *                          to the loan SA if the account has an active loan SA
 *                          and the account has the Apply Overpayment to Loan
 *                          SA Characteristic.     
 * 2022-10-12   EQuint      B24148. Apply any over payment to the Active 
 * 							SA's Payoff Balance before creating an  
 * 							Overpayment SA. 
 * 2022-11-17   EQuint      B24796. Retrieve billable overpayment SA
 * 							(not only active SA) when credit amount is about
 * 							is about to be distributed.
 * 2023-06-28   EQuint      D-03396. Added logic to make sure to apply the 
 * 							correct balance during overpayment distribution
 * 							for special role SAs
 **************************************************************************/

package com.splwg.cm.domain.admin.customerClass;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.Query;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.lookup.LookupField;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.base.domain.common.lookup.LookupValue_Id;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoSortKeyValue_Id;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.base.domain.todo.toDoType.ToDoTypeSortKeyTypes;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.CustomerReadLookup;
import com.splwg.ccb.api.lookup.PaymentPriorityLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.StopReasonLookup;
//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.customerClass.CustomerClassOverpaymentDistributionAlgorithmSpot;
import com.splwg.ccb.domain.admin.customerClass.CustomerClassOverpaymentDistributionData;
import com.splwg.ccb.domain.admin.depositClass.DepositClass;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTaskCharacteristic;
import com.splwg.ccb.domain.payment.payment.Payment;*/
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.customerClass.algorithm.overpayment.CustomerClassOverpaymentDistributionAlgorithmSpot;
import com.splwg.ccb.domain.admin.customerClass.algorithm.overpayment.CustomerClassOverpaymentDistributionData;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.depositClass.entity.DepositClass;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.serviceType.entity.ServiceType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.data.ServiceAgreementBalanceData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.payment.data.DetermineSaCreditAmountData;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.ccb.domain.payment.paymentEvent.entity.PaymentTender;
import com.splwg.ccb.domain.payment.tenderControl.entity.TenderControl_Id;
import com.splwg.ccb.domain.todo.common.ToDoEntryProcessor;
import com.splwg.ccb.domain.todo.data.ToDoMaintenanceData;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
import com.splwg.cm.api.lookup.CmPledgePaymentsOptionTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.cm.domain.payment.data.CmCategorizeAccountCreditData;
import com.splwg.cm.domain.payment.data.CmCategorizeCreditPaymentPriorityData;
import com.splwg.shared.common.ServerMessage;

/*
 * Start Change - Defect 3134789 - 2015-02-23
 */
///**
// * @author redizon
// *
//  @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = cisDivision, name = overpaymentSaTypeCisDivision, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = overpaymentSaType, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = cisDivision, name = nonBillableDollarHelpSaTypeCisDivision, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = nonBillableDollarHelpSaType, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = cisDivision, name = arpSaTypeCisDivision, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = arpSaType, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = businessObject, name = pledgeBusinessObject, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = serviceTaskType, name = pledgeServiceTaskType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = accountIdCharacteristicType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = businessObjectActiveStatusValue, required = true, type = string)})
// */
//Start Change - 2016-10-12 - PSreekan - 73753
///**
// * @author redizon
// *
//  @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = cisDivision, name = overpaymentSaTypeCisDivision, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = overpaymentSaType, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = cisDivision, name = nonBillableDollarHelpSaTypeCisDivision, type = entity)
// *            , @AlgorithmSoftParameter (name = nonBillableDollarHelpSaType, type = string)
// *            , @AlgorithmSoftParameter (entityName = cisDivision, name = arpSaTypeCisDivision, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = arpSaType, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = businessObject, name = pledgeBusinessObject, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = serviceTaskType, name = pledgeServiceTaskType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = accountIdCharacteristicType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = businessObjectActiveStatusValue, required = true, type = string)})
// */
/*
 * End Change - Defect 3134789 - 2015-02-23
 */
/*
 * Start Change JVitug - CCB022 - 2020-01-07
 */
///**
// * @author redizon
// *
//  @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = cisDivision, name = overpaymentSaTypeCisDivision, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = overpaymentSaType, required = true, type = string)
// *            , @AlgorithmSoftParameter (name = pledgeOverpaymentSaType, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = pledgePaymentFeatureConfiguration, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = cisDivision, name = nonBillableDollarHelpSaTypeCisDivision, type = entity)
// *            , @AlgorithmSoftParameter (name = nonBillableDollarHelpSaType, type = string)
// *            , @AlgorithmSoftParameter (entityName = cisDivision, name = arpSaTypeCisDivision, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = arpSaType, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = businessObject, name = pledgeBusinessObject, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = serviceTaskType, name = pledgeServiceTaskType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = accountIdCharacteristicType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = businessObjectActiveStatusValue, required = true, type = string)})
// */

//start change - EQuint - B24148 - 2022-10-12
///**
// * @author redizon
// *
//  @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = cisDivision, name = overpaymentSaTypeCisDivision, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = overpaymentSaType, required = true, type = string)
// *            , @AlgorithmSoftParameter (name = pledgeOverpaymentSaType, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = pledgePaymentFeatureConfiguration, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = cisDivision, name = nonBillableDollarHelpSaTypeCisDivision, type = entity)
// *            , @AlgorithmSoftParameter (name = nonBillableDollarHelpSaType, type = string)
// *            , @AlgorithmSoftParameter (entityName = cisDivision, name = arpSaTypeCisDivision, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = arpSaType, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = businessObject, name = pledgeBusinessObject, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = serviceTaskType, name = pledgeServiceTaskType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = accountIdCharacteristicType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = businessObjectActiveStatusValue, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = applyExcessCreditCharType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (entityName = toDoType, name = toDoTypeForOverpayment , type = entity)
// *            , @AlgorithmSoftParameter (entityName = role, name = toDoRoleForOverpayment, type = entity)
// *            , @AlgorithmSoftParameter (entityName = serviceType, name = loanServiceType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = amountThreshold, required = true, type = decimal)})
// */


/**
* @author redizon
*
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = cisDivision, name = overpaymentSaTypeCisDivision, required = true, type = entity)
*            , @AlgorithmSoftParameter (name = overpaymentSaType, required = true, type = string)
*            , @AlgorithmSoftParameter (name = pledgeOverpaymentSaType, required = true, type = string)
*            , @AlgorithmSoftParameter (entityName = featureConfiguration, name = pledgePaymentFeatureConfiguration, required = true, type = entity)
*            , @AlgorithmSoftParameter (entityName = cisDivision, name = nonBillableDollarHelpSaTypeCisDivision, type = entity)
*            , @AlgorithmSoftParameter (name = nonBillableDollarHelpSaType, type = string)
*            , @AlgorithmSoftParameter (entityName = cisDivision, name = arpSaTypeCisDivision, required = true, type = entity)
*            , @AlgorithmSoftParameter (name = arpSaType, required = true, type = string)
*            , @AlgorithmSoftParameter (entityName = businessObject, name = pledgeBusinessObject, required = true, type = entity)
*            , @AlgorithmSoftParameter (entityName = serviceTaskType, name = pledgeServiceTaskType, required = true, type = entity)
*            , @AlgorithmSoftParameter (entityName = characteristicType, name = accountIdCharacteristicType, required = true, type = entity)
*            , @AlgorithmSoftParameter (name = businessObjectActiveStatusValue, required = true, type = string)
*            , @AlgorithmSoftParameter (entityName = characteristicType, name = applyExcessCreditCharType, required = true, type = entity)
*            , @AlgorithmSoftParameter (entityName = toDoType, name = toDoTypeForOverpayment , type = entity)
*            , @AlgorithmSoftParameter (entityName = role, name = toDoRoleForOverpayment, type = entity)
*            , @AlgorithmSoftParameter (entityName = serviceType, name = loanServiceType, required = true, type = entity)
*            , @AlgorithmSoftParameter (name = amountThreshold, required = true, type = decimal)
*            , @AlgorithmSoftParameter (entityName = lookupField, name = specialRoleFlagLookup, required = true, type = entity)
*            , @AlgorithmSoftParameter (name = specialRolesFlags, required = true, type = string)
*            , @AlgorithmSoftParameter (entityName = customerContactClass, name = customerContactClass, required = true, type = entity)
*            , @AlgorithmSoftParameter (name = customerContactType, required = true, type = string)})
*/
//end change - EQuint - B24148 - 2022-10-12
/*
 * End Change JVitug - CCB022 - 2020-01-07
 */
//End Change - 2016-10-12 - PSreekan - 73753
public class CmLowIncomeOverpaymentAlgComp_Impl extends
CmLowIncomeOverpaymentAlgComp_Gen implements
CustomerClassOverpaymentDistributionAlgorithmSpot {
    
    // Soft Parameters
    private CisDivision parmOverpaymentSaTypeCisDivision;
    private String parmOverpaymentSaType;
    private CisDivision parmNonBillableDollarHelpSaTypeCisDivision;
    private String parmNonBillableDollarHelpSaType;
    private CisDivision parmArpSaTypeCisDivision;
    private String parmArpSaType;
    private BusinessObject parmPledgeBusinessObject;
    private ServiceTaskType parmPledgeServiceTaskType;
    private CharacteristicType parmAccountIdCharacteristicType;
    private String parmBoActiveStatusValue;
    //Start Add - 2016-10-12 - PSreekan - 73753
    private String parmPledgeOverpaymentSaType;
    private FeatureConfiguration parmPledgePaymentFeatureConfiguration;
    //End Add - 2016-10-12 - PSreekan - 73753
    //Start Add JVitug - CCB022 - 2020-01-07
    private CharacteristicType applyExcessCreditCharType;
    private ToDoType todoTypeForOverpayment;
    private Role todoRole;
    private ServiceType loanServiceType;
    private BigDecimal amountThreshold;
    //End Add JVitug - CCB022 - 2020-01-07
    // start add - EQuint - B24148 - 2022-10-12
    private LookupField specialRoleFlagLookupField;
    private String specialRolesFlags;
    private CustomerContactClass ccClass;
    private String ccTypeString;
    private CustomerContactType ccType;
    // end add - EQuint - B24148 - 2022-10-12

    // Hard Parameters
    private Account account;
    private Money creditAmount;
    private DepositClass depositClass;
    private Date processDate;
    
    //Start add - Neha 2013-02-04 
    private Payment payment;
	//End add - Neha 2013-02-04 

    // Properties
    private List<CustomerClassOverpaymentDistributionData> distributionDataList =  new ArrayList<CustomerClassOverpaymentDistributionData>();
    private ServiceAgreement arpPaymentArrangementSa;
    private ServiceAgreementType_Id overpaymentSaTypeId;
    private ServiceAgreementType_Id nonBillableDollarHelpSaTypeId;
    private ServiceAgreementType_Id arpSaTypeId;
    private Money amountDistributedToSa;
    //Start Add - 2016-10-12 - PSreekan - 73753
    private ServiceAgreementType_Id pledgeOverpaymentSaTypeId;
    private CmMGEFeatureConfigurationOptionsRetriever cmMGEFeatureConfigurationOptionsRetriever;
    //End Add - 2016-10-12 - PSreekan - 73753
    
    //Start Add JVitug - CCB022 - 2020-01-07
    //Constants
    private String DATE_FORMAT = "yyyy-MM-dd";
    
    //Working variables
    AccountCharacteristic applyExcessCreditCharacteristic;
    DateFormat dateFormat = new DateFormat(DATE_FORMAT);
    Date applyExcessCreditCharVal;
    Bool isCreditAmountAppliedToLoanSA = Bool.FALSE;
    //End Add JVitug - CCB022 - 2020-01-07
    
    // start add - EQuint - B24148 - 2022-10-12
    List<LookupValue> specialRoleFlagList = new ArrayList<LookupValue>();
    // end add - EQuint - B24148 - 2022-10-12
    
    public List<CustomerClassOverpaymentDistributionData> getCustomerClassOverpaymentDistributionData() {
        return distributionDataList;
    }

    public Money getTotalAmountDistributed() {
        return null;
    }

    //Start add - Neha 2013-02-04 
	public Payment getOverpaymentPayment() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public void setPayment(Payment arg0) {
		// TODO Auto-generated method stub
		this.payment = arg0;
	}

	
	public void setPaymentServiceAgreementCount(BigInteger arg0) {
		// TODO Auto-generated method stub
		
	}
	//End add - Neha 2013-02-04 

	public void setAccount(Account account) {
        this.account = account;
    }

    public void setCreditAmount(Money creditAmount) {
        this.creditAmount = creditAmount;
    }

    public void setDepositClass(DepositClass depositClass) {
        this.depositClass = depositClass;
    }

    public void setProcessDate(Date processDate) {
        this.processDate = processDate;
    }

    public void invoke() {
    	//Start Add - 2016-10-12 - PSreekan - 73753
  		cmMGEFeatureConfigurationOptionsRetriever = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
  		//End Add - 2016-10-12 - PSreekan - 73753
        processDate = getProcessDateTime().getDate();

        //Start Add JVitug - CCB022 - 2020-01-07
        applyOverpaymentToLoanSAIfApplicable();
        
        //Continue processing only if credit amount is not allocated to a loan SA.
        if(isCreditAmountAppliedToLoanSA.isFalse()) {
        //End Add JVitug - CCB022 - 2020-01-07
        //Start Add - 2016-10-12 - PSreekan - 73753
	        if(checkEligibility().isFalse()){
	        //End Add - 2016-10-12 - PSreekan - 73753
		        // Retrieve ARP Payment Arrangement SAs
		        Query queryActiveSas = cmGetActiveServiceAgreement(parmArpSaTypeCisDivision, arpSaTypeId.getEntity());
		        QueryIterator itrActiveSas = queryActiveSas.iterate();
		        while (itrActiveSas.hasNext()){
		            ServiceAgreement_Id activeSaId = (ServiceAgreement_Id) itrActiveSas.next();
		            arpPaymentArrangementSa = activeSaId.getEntity();
		
		            Money payOffBalance = arpPaymentArrangementSa.getPayoffBalance();
		            BigDecimal fiftyPercent = payOffBalance.getAmount().divide(BigDecimal.valueOf(2));
		            Money fiftyPercentAmount = new Money(fiftyPercent, payOffBalance.getCurrencyId());
		
		            // Get the Amount being distributed to the ARP SA = Current Balance + Credit Amount
		            amountDistributedToSa = creditAmount.add(arpPaymentArrangementSa.getCurrentBalance());
		
		            CustomerClassOverpaymentDistributionData distributionData = CustomerClassOverpaymentDistributionData.Factory.newInstance();
		            // If 50% Amount >= Distributed Amount, distribute the full Payment variable for the ARP SA			
		            if (fiftyPercentAmount.isGreaterThanOrEqual(amountDistributedToSa)){
		                distributionData.setCreditAmount(creditAmount);
		                distributionData.setServiceAgreement(arpPaymentArrangementSa);
		                distributionDataList.add(distributionData);
		                creditAmount = Money.ZERO;
		                break;
		            }
		            else {
		                // Else, distribute to the ARP SA an amount that is up to 50% of the SA Payoff Balance only 
		                Money arpSaAmount = fiftyPercentAmount.subtract(arpPaymentArrangementSa.getCurrentBalance());
		                distributionData.setCreditAmount(arpSaAmount);
		                distributionData.setServiceAgreement(arpPaymentArrangementSa);
		                distributionDataList.add(distributionData);
		
		                // Subtract ARP Credit Amount from the main Credit Amount
		                creditAmount = creditAmount.subtract(arpSaAmount);
		            }
		        }
		
		        // If at least one ARP Payment Arrangement SA was retrieved
		        if (queryActiveSas.listSize() > 0){
		            if (creditAmount.isGreaterThan(Money.ZERO)){
		                // Apply the remaining amount to the Overpayment SA
		                cmApplyCreditToServiceAgreement(parmOverpaymentSaTypeCisDivision, overpaymentSaTypeId.getEntity(), creditAmount, Bool.FALSE);
		            }
		            return;
		        }
		
		        /*
		         * Start Change - Defect 3134789 - 2015-02-23
		         */
		        //// Overpayment Amount is exactly $1 and no active ARP SA exists
		        //if (creditAmount.getAmount().compareTo(BigDecimal.ONE) == 0){
		        //    Bool activeServiceTaskExists = cmRetrieveActiveServiceTask();
		        //
		        //    //TIR_NA0050 2013-03-26 - CVB Start
		        //    // if (activeServiceTaskExists.isTrue()){
		        //    if (activeServiceTaskExists.isFalse()){
		        //        
		        //        // TIR_NA0050 2013-03-26 - CVB End
		        //        cmApplyCreditToServiceAgreement(parmNonBillableDollarHelpSaTypeCisDivision, nonBillableDollarHelpSaTypeId.getEntity(), creditAmount, Bool.TRUE);
		        //        // TIR_NA0050 2013-03-26 - CVB Start
		        //        return;
		        //        // TIR_NA0050 2013-03-26 - CVB End
		        //    }
		        //    // TIR_NA0050 2013-03-26 - CVB Start
		        //    // return;		
		        //    // TIR_NA0050 2013-03-26 - CVB End
		        //}
		        
		        // Overpayment Amount is exactly $1, no active ARP SA exists, and the Algorithm parameters define a Non-Billable Dollar Help SA Type
		        if (notNull(nonBillableDollarHelpSaTypeId) && creditAmount.getAmount().compareTo(BigDecimal.ONE) == 0) {
		            
		            Bool activeServiceTaskExists = cmRetrieveActiveServiceTask();
		            if (activeServiceTaskExists.isFalse()) {
		                cmApplyCreditToServiceAgreement(parmNonBillableDollarHelpSaTypeCisDivision, nonBillableDollarHelpSaTypeId.getEntity(), creditAmount, Bool.TRUE);
		                return;
		            }
		            
		        }
		        /*
		         * End Change - Defect 3134789 - 2015-02-23
		         */
		        
		        // start change - EQuint - B24148 - 2022-10-12
		        // Other Credit Amount values
		        // cmApplyCreditToServiceAgreement(parmOverpaymentSaTypeCisDivision, overpaymentSaTypeId.getEntity(), creditAmount, Bool.FALSE);
		        
		        // apply any overpayment to the Active SA's Payoff Balance before creating an Overpayment SA
		        processSpecialRoleSas();
		        
		        if (creditAmount.isPositive()) {
		        	// Other Credit Amount values
			         cmApplyCreditToServiceAgreement(parmOverpaymentSaTypeCisDivision, overpaymentSaTypeId.getEntity(), creditAmount, Bool.FALSE);
		        }
		        // end end change - EQuint - B24148 - 2022-10-12
		
		        
		    //Start Add - 2016-10-12 - PSreekan - 73753
	        }else{
	        	cmApplyCreditToServiceAgreement(parmOverpaymentSaTypeCisDivision, pledgeOverpaymentSaTypeId.getEntity(), creditAmount, Bool.FALSE);
	        }
	        //End Add - 2016-10-12 - PSreekan - 73753
        //Start Add JVitug - CCB022 - 2020-01-07
        }
        //End Add JVitug - CCB022 - 2020-01-07
    }
    
    // start add - EQuint - B24148 - 2022-10-12
    private void processSpecialRoleSas() {    
    	StringBuilder ccDescription = new StringBuilder();
    	PaymentPriorityLookup payPrio = null;
    	PaymentPriorityLookup payPrioOld = null;
    	CmCategorizeAccountCreditData categorizeAccountCreditData = null;
    	Money fullPaymentAmount = Money.ZERO;
    	Money partialPaymentAmount = Money.ZERO;
    	BigInteger arrearsDaysNotPaid = BigInteger.ZERO;
        Money payAmountOnNewDebits = Money.ZERO;
    	
    	// if payment is present, initialize categorized account credit data for future use
    	if (notNull(payment)) {
			
			categorizeAccountCreditData = CmCategorizeAccountCreditData.Factory.newInstance();
	        categorizeAccountCreditData.setCreditAmount(payment.getPaymentAmount());
	        categorizeAccountCreditData.setProcessDate(processDate);
	        categorizeAccountCreditData.setAccount(account);
	        
	        if (notNull(depositClass)) {
	            categorizeAccountCreditData.setDepositClass(depositClass);
	        }
	        
	        categorizeAccountCreditData.categorizeAccountCredit();
    	}
    	
    	// loop thru special role flag in order
    	for (LookupValue specialRole: specialRoleFlagList) {
    		// if there's still remaining balance
			if (creditAmount.isGreaterThan(Money.ZERO)) {
				// get the account's SA by special role flag by ascending order
				List<SQLResultRow> sasBySpecialRole = getSasBySpecialRole(specialRole);
				for(SQLResultRow result : sasBySpecialRole) {
					// start change - D-03396 - EQuint - 2023-06-28
					
					// // get the SA financial data
					// ServiceAgreement sa = result.getEntity("SA_ID", ServiceAgreement.class);
					//ServiceAgreementBalanceData saBalData = sa.getFinancialBalances();
					
					// Money toPay = Money.ZERO;
					// // set pay amount whichever is higher between then current and pay off balance
					// if (saBalData.getCurrentAmount().compareTo(saBalData.getTotalAmount()) > 0) {
					// 	// current balance must be positive
					// 	if (saBalData.getCurrentAmount().isPositive()) {
					// 		// set the pay amount whichever is lower between the remaining balance and the current amount
					// 		toPay = (saBalData.getCurrentAmount().compareTo(creditAmount) > 0) ? creditAmount : saBalData.getCurrentAmount();
					// 	}
					// } else {
					// 	// total balance must be positive
					// 	if (saBalData.getTotalAmount().isPositive()) {
					// 		// set the pay amount whichever is lower between the remaining balance and the total amount
					// 		toPay = (saBalData.getTotalAmount().compareTo(creditAmount) > 0) ? creditAmount : saBalData.getTotalAmount();
					// 	} 
					// }
					
					// if there's still remaining balance
					if (creditAmount.isGreaterThan(Money.ZERO)) {
							
						ServiceAgreement sa = result.getEntity("SA_ID", ServiceAgreement.class);
						ServiceAgreementBalanceData saBalData = sa.getFinancialBalances();
						payPrio = sa.getServiceAgreementType().getPaymentPriority();
						
						Money toPay = Money.ZERO;
						
						// if payment is preset, check if the we can find the current SA in the categorized credit data to determine if it has been processed by the normal payment distribution algorithm
						if (notNull(payment)) {
					        
					        Bool isPriorityFound = Bool.TRUE;
					        
					        if (!payPrio.equals(payPrioOld)) {
					        	isPriorityFound = Bool.FALSE;
					        	
					        	if (notNull(categorizeAccountCreditData.getCategorizeCreditPaymentPriorityDataList())) {
					        		for (CmCategorizeCreditPaymentPriorityData data : categorizeAccountCreditData.getCategorizeCreditPaymentPriorityDataList()) {
							        	if (payPrio.trimmedValue().compareTo(data.getPaymentPriority().trimmedValue()) == 0) { 
							        		isPriorityFound = Bool.TRUE;
							        		arrearsDaysNotPaid = data.getArrearDaysofUnpaidAmount();
						                    payAmountOnNewDebits = data.getPaymentAmountOnNewDebits();
							        		fullPaymentAmount = data.getFullPaymentAmount();
								        	partialPaymentAmount = data.getPartialPaymentAmount();
							        		break;
							        	
							        	}
							        }
					        	}
					        	
					        	
					        }
					        
					        // if details found within the same payment priority, use this base routine to determine the  actual amount paid
					        if (isPriorityFound.isTrue()) {
					        	DetermineSaCreditAmountData determineSaCreditAmountData = DetermineSaCreditAmountData.Factory.newInstance();            
				                determineSaCreditAmountData.setServiceAgreement(sa);
				                determineSaCreditAmountData.setProcessDate(processDate);
				                determineSaCreditAmountData.setArrearDaysOfDelinquent(categorizeAccountCreditData.getArrearDaysofDelinquentAmount());
				                determineSaCreditAmountData.setAmountPaidOnNewDebits(payAmountOnNewDebits);
				                determineSaCreditAmountData.setNonDeliquentAmountPaid(Money.ZERO);
				                determineSaCreditAmountData.setArrearDaysOfUnpaid(arrearsDaysNotPaid);  
				                determineSaCreditAmountData.setFullAmountPaid(fullPaymentAmount);
				                determineSaCreditAmountData.setPartialAmountPaid(partialPaymentAmount);
				                determineSaCreditAmountData.setExcessCreditAmount(Money.ZERO);
				                
				                determineSaCreditAmountData = sa.determineSaCreditAmount(determineSaCreditAmountData);
				                
				                // if SA balance is positive, then subtract the total balance by the payment made from the normal distribution
				                if (saBalData.getTotalAmount().isPositive()) {
				                	toPay = saBalData.getTotalAmount().subtract(determineSaCreditAmountData.getCreditAmount());
				                	
				                	// make sure to update the full and partial pament amounts
				                	fullPaymentAmount = determineSaCreditAmountData.getFullAmountPaid();
				                    partialPaymentAmount = determineSaCreditAmountData.getPartialAmountPaid();
				                	
				                }
					        } else {
					        	// if not credit  data is found, then use whichever is higher between current and total balance as amount to pay
					        	Money saBal = saBalData.getCurrentAmount().compareTo(saBalData.getTotalAmount()) > 0 ? saBalData.getCurrentAmount() : saBalData.getTotalAmount();
					        	if (saBal.isPositive()) {
					        		toPay = saBal;
					        	}
					        }
					        
					        
						} else {
							// if payment is found, then use whichever is higher between current and total balance as amount to pay
							Money saBal = saBalData.getCurrentAmount().compareTo(saBalData.getTotalAmount()) > 0 ? saBalData.getCurrentAmount() : saBalData.getTotalAmount();
				        	if (saBal.isPositive()) {
				        		toPay = saBal;
				        	}
						}
						
						// if amount to pay is greater than the remaining credit amount (meaning credit amount is consumed)
						if (toPay.compareTo(creditAmount) > 0) {
	                		toPay = creditAmount;
	                	} 
						
						
				        // end change - D-03396 - EQuint - 2023-06-28
				        
						// adjust the remaining balance based on the amount to pay
						creditAmount = creditAmount.subtract(toPay);
						
						// build CC description string
						if (toPay.isPositive()) {
							// add distribution data
							CustomerClassOverpaymentDistributionData distributionData = CustomerClassOverpaymentDistributionData.Factory.newInstance();
							distributionData.setCreditAmount(toPay);
							distributionData.setServiceAgreement(sa);
							distributionDataList.add(distributionData);
							
							ccDescription.append(CustomMessageRepositorySpireOne.B24148_amountAppliedToSa(toPay.toLocalizedString(account.getCurrency()), sa.getId().getTrimmedValue()).getMessageText());
							ccDescription.append(System.lineSeparator());
						}
						
						payPrioOld = payPrio;
					}
				}
			}
		}
    	
    	// add customer contact
    	createCustomerContact(account, ccDescription.toString());
    }
    
    private List<SQLResultRow> getSasBySpecialRole(LookupValue specialRole) {
    	StringBuilder sql = new StringBuilder();
    	
    	sql.append("SELECT ");
    	sql.append("	SA.SA_ID ");
    	sql.append("FROM ");
    	sql.append("	CI_SA SA ");
    	sql.append("	, CI_SA_TYPE SAT ");
    	sql.append("WHERE ");
    	sql.append("	SA.ACCT_ID = :account ");
    	sql.append("	AND SA.SA_STATUS_FLG BETWEEN :active and :reactivated ");
    	sql.append("	AND SA.CIS_DIVISION = SAT.CIS_DIVISION ");
    	sql.append("	AND SA.SA_TYPE_CD = SAT.SA_TYPE_CD ");
    	sql.append("	AND SPECIAL_ROLE_FLG = :specialRole ");
    	sql.append("ORDER BY SA.START_DT ASC");
    	
    	PreparedStatement stmt = createPreparedStatement(sql.toString(), getClass().getName());
    	stmt.bindId("account" , account.getId());
    	stmt.bindLookup("active" , ServiceAgreementStatusLookup.constants.ACTIVE);
    	stmt.bindLookup("reactivated" , ServiceAgreementStatusLookup.constants.REACTIVATED);
    	stmt.bindLookup("specialRole", specialRole.asLookup());
    	
    	List<SQLResultRow> result = stmt.list();
    	stmt.close();
    	
    	return result;
    }
    
    private CustomerContact createCustomerContact(Account account, String description) {

		CustomerContact_DTO contactDTO = new CustomerContact_DTO();
		contactDTO.setCustomerContactTypeId(ccType.getId());
		contactDTO.setPersonId(account.getMainPerson().getId());
		contactDTO.setAccountId(account.getId());
		contactDTO.setContactDateTime(getProcessDateTime());
		contactDTO.setUserId(getActiveContextUser().getId());
		contactDTO.setLongDescription(description);
		
		return contactDTO.newEntity();
	 }
    
    // end add - EQuint - B24148 - 2022-10-12
    
    //Start Add JVitug - CCB022 - 2020-01-07
    private void applyOverpaymentToLoanSAIfApplicable() {
    	List<SQLResultRow> activeLoanSAs = getActiveLoanSAs();

    	if(activeLoanSAs.size() > 0) {
    		//Calculate the amount to be distributed per loan SA by dividing the credit amount
    		// by the number of Loan SAs
    		BigDecimal amountPerSA = creditAmount.getAmount().setScale(2).
    				divide(BigDecimal.valueOf(activeLoanSAs.size()));
    		amountPerSA = amountPerSA.setScale(2);

    		Money amountToDistribute = new Money(amountPerSA, creditAmount.getCurrencyId());

    		//For each loan SA, create a overpayment distribution data to distribute
    		//the payment
    		for(SQLResultRow result : activeLoanSAs) {
    			ServiceAgreement loanServiceAgreement = result.getEntity("SA_ID", ServiceAgreement.class);
    			CustomerClassOverpaymentDistributionData overpaymentDistributionData = 
    					CustomerClassOverpaymentDistributionData.Factory.newInstance();

    			overpaymentDistributionData.setCreditAmount(amountToDistribute);
    			overpaymentDistributionData.setServiceAgreement(loanServiceAgreement);
    			distributionDataList.add(overpaymentDistributionData);
    		}
    		
    		//Set the shouldContinue flag to False as the credit amount was applied entirely 
    		//to the loan SA
    		isCreditAmountAppliedToLoanSA = Bool.TRUE;

    	} else {
    		//If there are no SAs with the apply excess credit characteristic type
    		//check the account
    		applyExcessCreditCharacteristic = account.getEffectiveCharacteristic(applyExcessCreditCharType);
    		ServiceAgreement loanSA = getActiveLoanSA();

    		if(notNull(loanSA) && notNull(applyExcessCreditCharacteristic)){
    			//Get the characteristic value
    			try{
    				if(applyExcessCreditCharType.getCharacteristicType().isAdhocValue() 
    						|| applyExcessCreditCharType.getCharacteristicType().isFileLocationValue() ) {
    					//If adhoc or file location, get it from the adhoc characteristi value field
    					applyExcessCreditCharVal = dateFormat.parseDate(applyExcessCreditCharacteristic.getAdhocCharacteristicValue().trim());
    				} else if (applyExcessCreditCharType.getCharacteristicType().isPredefinedValue()) {
    					//If predefined, get it from the characteristic value field
    					applyExcessCreditCharVal = dateFormat.parseDate(applyExcessCreditCharacteristic.getCharacteristicValue().trim());
    				} else if(applyExcessCreditCharType.getCharacteristicType().isForeignKeyValue()) {
    					//If foreign key, get it from the foreign key 1 value field
    					applyExcessCreditCharVal = dateFormat.parseDate(applyExcessCreditCharacteristic.getCharacteristicValueForeignKey1().trim());
    				}
    			} catch (Exception e) {
    				addError(CustomMessageRepositorySpireOne.
    						CCB022_errorInParsingCharacteristicValueAsDate(applyExcessCreditCharType.getId().getTrimmedValue(),
    								account.getId().getTrimmedValue()));
    			}

    			if(applyExcessCreditCharVal.isAfter(processDate)) {
    				//If there is an active loan SA linked to the account 
    				//Distribute it to the account
    				if(notNull(loanSA)) {
    					CustomerClassOverpaymentDistributionData overpaymentDistributionData = CustomerClassOverpaymentDistributionData.Factory.newInstance();

    					overpaymentDistributionData.setCreditAmount(creditAmount);
    					overpaymentDistributionData.setServiceAgreement(loanSA);
    					distributionDataList.add(overpaymentDistributionData);
    					
    					//Set the shouldContinue flag to False as the credit amount was applied entirely 
    		    		//to the loan SA
    		    		isCreditAmountAppliedToLoanSA = Bool.TRUE;
    				}
    			}
    		} else {
    		//If there are no apply credit to Loan SA characteristic is retrieved,
    		//check if a to do type parameter is supplied 
    			if (notNull(todoTypeForOverpayment)) {
    				//If To Do Type is provided, check if overpayment SA payoff balance 
    				//is greater than the amount threshold and if the account has an Active Loan SA.
    				//					PaymentSegments psegs = getOverpaymentPayment.getSegments();
    				//					for (PaymentSegment pseg : psegs) {
    				//						//Get the overpayment SA from the overpayment payment
    				//						overpaymentSA = pseg.getServiceAgreement();
    				//						break;
    				//					}

    				//If the Pay-off Balance of the Credit amount is greater than the amount threshold
    				//and there is an active loan SA for the account, Raise a To Do using the to do type parameter
    				//supplied if there is no Open or being worked on To do of that To do type for this account
    				if(creditAmount.getAmount().abs().compareTo(amountThreshold) > 0
    						&& notNull(loanSA)) {
    					if(checkIfThereIsOpenToDo(loanSA).isFalse()) {
    						createToDo(loanSA , 
    								CustomMessageRepositorySpireOne.CCB022_overpaymentSAPayOffIsGreaterThanTheAmountThreshold(loanSA.getId().getTrimmedValue() ,
    										amountThreshold.toString()));
    					}
    				}
    			}
    		}
    	}
    }
    
    /**
     * This method will check if there is an open To Do
     * linked to the overpayment SA 
     * @return
     */
    private Bool checkIfThereIsOpenToDo(ServiceAgreement loanSA) {
    	Bool isThereAnOpenTodo = Bool.FALSE;
    	StringBuilder sql = new StringBuilder();
    	
    	sql.append("SELECT ");
    	sql.append(   "TD.TD_ENTRY_ID ");
    	sql.append("FROM ");
    	sql.append(   "CI_TD_ENTRY TD, ");
    	sql.append(   "CI_TD_DRLKEY KY ");
    	sql.append("WHERE ");
    	sql.append(   "TD.TD_TYPE_CD = :todoType ");
    	sql.append("AND ");
    	sql.append(   "TD.ENTRY_STATUS_FLG IN (:open , :beingWorkedOn) ");
    	sql.append("AND ");
    	sql.append(   "TD.TD_ENTRY_ID = KY.TD_ENTRY_ID ");
    	sql.append("AND ");
    	sql.append(   "KY.KEY_VALUE = :loanSA ");
    	
    	PreparedStatement stmt = createPreparedStatement(sql.toString(), getClass().getName());
    	stmt.bindId("todoType" , todoTypeForOverpayment.getId());
    	stmt.bindLookup("open" , ToDoEntryStatusLookup.constants.OPEN);
    	stmt.bindLookup("beingWorkedOn" , ToDoEntryStatusLookup.constants.BEING_WORKED_ON);
    	stmt.bindId("loanSA", loanSA.getId());
    	
    	SQLResultRow result = stmt.firstRow();
    	stmt.close();
    	
    	if(notNull(result)){
    		isThereAnOpenTodo = Bool.TRUE;
    	}
    	
    	return isThereAnOpenTodo;
    }
    
	/**
	 * This method creates a To Do Entry
	 * @param account
	 */
	private void createToDo(ServiceAgreement loanSA, ServerMessage message) {
		ToDoEntry_DTO entryDto  = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
        
        entryDto.setToDoTypeId(todoTypeForOverpayment.getId());
        if(notNull(todoRole)) {
        	entryDto.setToDoRoleId(todoRole.getId());
        } else {
        	entryDto.setToDoRoleId(todoTypeForOverpayment.getDefaultRole().fetchIdToDoRole().getId());
        }
        entryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
        entryDto.setCreationDateTime(getProcessDateTime());

        ArrayList<ToDoSortKeyValue_DTO>sortKeyList = new ArrayList<ToDoSortKeyValue_DTO>();
        ToDoTypeSortKeyTypes sortKeyTypes = todoTypeForOverpayment.getSortKeyTypes();

        for (Iterator<ToDoSortKeyType> iter = sortKeyTypes.iterator(); iter.hasNext();) {
            ToDoSortKeyType sortKeyType = (ToDoSortKeyType) iter.next();
            ToDoSortKeyValue_DTO sortKeyDto = (ToDoSortKeyValue_DTO) createDTO(ToDoSortKeyValue.class);
            BigInteger seq = sortKeyType.fetchIdSequence();
            sortKeyDto.setId(new ToDoSortKeyValue_Id(ToDoEntry_Id.NULL, seq));
            sortKeyDto.setKeyValue(loanSA.getId().getTrimmedValue());
            sortKeyList.add(sortKeyDto);
        }

        ArrayList<ToDoDrillKeyValue_DTO> drillKeyList = new ArrayList<ToDoDrillKeyValue_DTO>();
        ToDoDrillKeyValue_DTO drillKeyDto = (ToDoDrillKeyValue_DTO) createDTO(ToDoDrillKeyValue.class);
        ToDoDrillKeyType drillKeyType = (ToDoDrillKeyType) todoTypeForOverpayment.getDrillKeyTypes().iterator().next();
        BigInteger sequence = drillKeyType.fetchIdSequence();
        drillKeyDto.setId(new ToDoDrillKeyValue_Id(ToDoEntry_Id.NULL, sequence));

        drillKeyDto.setKeyValue(loanSA.getId().getTrimmedValue());
        drillKeyList.add(drillKeyDto);
        
        entryDto.setMessageId(message.getMessageId());

        ArrayList <String> messageParameterList = new ArrayList<String> ();
        messageParameterList.add(0, loanSA.getId().getTrimmedValue());
        messageParameterList.add(1, amountThreshold.toString());

        ToDoMaintenanceData toDoEntryData = ToDoMaintenanceData.Factory.newInstance();

        toDoEntryData.setDrillKeys(drillKeyList);
        toDoEntryData.setEntryDto(entryDto);
        toDoEntryData.setSortKeys(sortKeyList);
        toDoEntryData.setMessageParams(messageParameterList);

        ArrayList <ToDoEntryCharacteristic_DTO>  charList = new ArrayList<ToDoEntryCharacteristic_DTO> ();
        toDoEntryData.setToDoCharacteristics(charList);

        ToDoEntryProcessor toDoProcessor = ToDoEntryProcessor.Factory.newInstance();
        ToDoEntry toDoEntry = toDoProcessor.addToDo(toDoEntryData);
        
	}

    /**
     * This method will return an active Loan SA linked to the
     * account being processed.
     * @return
     */
    private ServiceAgreement getActiveLoanSA() {
    	ServiceAgreement loanSA = null;
    	
    	StringBuilder sql = new StringBuilder();
    	
    	sql.append("SELECT ");
    	sql.append(   "SA.SA_ID ");
    	sql.append("FROM ");
    	sql.append(   "CI_SA SA, ");
    	sql.append(   "CI_SA_TYPE SAT ");
    	sql.append("WHERE ");
    	sql.append(   "SA.ACCT_ID = :account ");
    	sql.append("AND ");
    	sql.append(   "SA.SA_STATUS_FLG = :active ");
    	sql.append("AND ");
    	sql.append(   "SA.CIS_DIVISION = SAT.CIS_DIVISION ");
    	sql.append("AND ");
    	sql.append(   "SA.SA_TYPE_CD = SAT.SA_TYPE_CD ");
    	sql.append("AND ");
    	sql.append(   "SAT.SVC_TYPE_CD = :loanServiceType ");
    	
    	PreparedStatement stmt = createPreparedStatement(sql.toString(), getClass().getName());
    	stmt.bindId("account" , account.getId());
    	stmt.bindLookup("active" , ServiceAgreementStatusLookup.constants.ACTIVE);
    	stmt.bindId("loanServiceType", loanServiceType.getId());
    	
    	SQLResultRow result = stmt.firstRow();
    	stmt.close();
    	
    	if(notNull(result)){
    		loanSA = result.getEntity("SA_ID", ServiceAgreement.class);
    	}
    	
    	return loanSA;
    }
    
    /**
     * This method will return a list of active Loan SAs linked to the
     * account being processed.
     * @return
     */
    private List<SQLResultRow> getActiveLoanSAs() {
    	StringBuilder sql = new StringBuilder();
    	
    	sql.append("SELECT ");
    	sql.append(   "SA.SA_ID ");
    	sql.append("FROM ");
    	sql.append(   "CI_SA SA, ");
    	sql.append(   "CI_SA_TYPE SAT ");
    	sql.append("WHERE ");
    	sql.append(   "SA.ACCT_ID = :account ");
    	sql.append("AND ");
    	sql.append(   "SA.SA_STATUS_FLG = :active ");
    	sql.append("AND ");
    	sql.append(   "SA.CIS_DIVISION = SAT.CIS_DIVISION ");
    	sql.append("AND ");
    	sql.append(   "SA.SA_TYPE_CD = SAT.SA_TYPE_CD ");
    	sql.append("AND ");
    	sql.append(   "SAT.SVC_TYPE_CD = :loanServiceType ");
    	sql.append("AND ");
    	sql.append(   "EXISTS ( ");
    	sql.append(      "SELECT ");
    	sql.append(         "'X' ");
    	sql.append(      "FROM ");
    	sql.append(         "CI_SA_CHAR SACHAR ");
    	sql.append(      "WHERE ");
    	sql.append(         "SACHAR.SA_ID = SA.SA_ID ");
    	sql.append(      "AND ");
    	sql.append(         "SACHAR.CHAR_TYPE_CD = :charType ");
    	sql.append(      "AND ");
    	sql.append(         "TO_DATE(SACHAR.ADHOC_CHAR_VAL, 'YYYY-MM-DD') >= :processDate ");
    	sql.append(   ") ");
    	
    	PreparedStatement stmt = createPreparedStatement(sql.toString(), getClass().getName());
    	stmt.bindId("account" , account.getId());
    	stmt.bindLookup("active" , ServiceAgreementStatusLookup.constants.ACTIVE);
    	stmt.bindId("loanServiceType", loanServiceType.getId());
    	stmt.bindId("charType" , applyExcessCreditCharType.getId());
    	stmt.bindDate("processDate", processDate);
    	
    	List<SQLResultRow> result = stmt.list();
    	stmt.close();
    	
    	return result;
    }
    //End Add JVitug - CCB022 - 2020-01-07

    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
        // Retrieve the Algorithm Parameters
        parmOverpaymentSaTypeCisDivision = getOverpaymentSaTypeCisDivision();
        parmOverpaymentSaType = getOverpaymentSaType();
        parmNonBillableDollarHelpSaTypeCisDivision = getNonBillableDollarHelpSaTypeCisDivision();
        parmNonBillableDollarHelpSaType = getNonBillableDollarHelpSaType();
        parmArpSaTypeCisDivision = getArpSaTypeCisDivision();
        parmArpSaType = getArpSaType();
        parmPledgeBusinessObject = getPledgeBusinessObject();
        parmPledgeServiceTaskType = getPledgeServiceTaskType();
        parmAccountIdCharacteristicType = getAccountIdCharacteristicType();
        parmBoActiveStatusValue = getBusinessObjectActiveStatusValue();
        //Start Add - 2016-10-12 - PSreekan - 73753
        parmPledgeOverpaymentSaType = getPledgeOverpaymentSaType();
        parmPledgePaymentFeatureConfiguration = getPledgePaymentFeatureConfiguration();
        //End Add - 2016-10-12 - PSreekan - 73753
        //Start Add JVitug - CCB022 - 2020-01-07
        applyExcessCreditCharType = getApplyExcessCreditCharType();
    	todoTypeForOverpayment = getToDoTypeForOverpayment();
    	todoRole = getToDoRoleForOverpayment();
    	loanServiceType = getLoanServiceType();
    	amountThreshold = getAmountThreshold();
        //End Add Jvitug - CCB022 - 2020-01-07
    	
    	// start add EQuint - B24148 - 2022-10-12
    	specialRoleFlagLookupField= getSpecialRoleFlagLookup();
    	specialRolesFlags = getSpecialRolesFlags();
    	ccClass = getCustomerContactClass();
    	ccTypeString = getCustomerContactType();
    	// end add EQuint - B24148 - 2022-10-12

        // Validate the Overpayment SA Type and CIS Division
        overpaymentSaTypeId = cmValidateServiceAgreementType(parmOverpaymentSaTypeCisDivision, parmOverpaymentSaType);

        /*
         * Start Change - Defect 3134789 - 2015-02-23
         */
        //// Validate the Non-Billable Dollar Help SA Type and CIS Division
        //nonBillableDollarHelpSaTypeId = cmValidateServiceAgreementType(parmNonBillableDollarHelpSaTypeCisDivision, parmNonBillableDollarHelpSaType);
        
        // Validate the Non-Billable Dollar Help SA Type and CIS Division. If neither is present, set the SA Type to null
        if (isNull(parmNonBillableDollarHelpSaTypeCisDivision) && isBlankOrNull(parmNonBillableDollarHelpSaType)) {
            nonBillableDollarHelpSaTypeId = null;
        } else {
            nonBillableDollarHelpSaTypeId = cmValidateServiceAgreementType(parmNonBillableDollarHelpSaTypeCisDivision, parmNonBillableDollarHelpSaType);
        }
        /*
         * End Change - Defect 3134789 - 2015-02-23
         */

        // Validate the ARP SA Type and CIS Division
        arpSaTypeId = cmValidateServiceAgreementType(parmArpSaTypeCisDivision, parmArpSaType);
        //Start Add - 2016-10-12 - PSreekan - 73753
        pledgeOverpaymentSaTypeId = cmValidateServiceAgreementType(parmOverpaymentSaTypeCisDivision, parmPledgeOverpaymentSaType);
        //End Add - 2016-10-12 - PSreekan - 73753

        // Validate the Account ID Characteristic Type
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(parmAccountIdCharacteristicType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        if(isNull(charEntityId.getEntity())){
            addError(CustomMessageRepositoryMDC.na0050_InvalidCharacteristicTypeForServiceTaskEntity(parmAccountIdCharacteristicType.getId().getTrimmedValue()));
        }
        
        //Start Add JVitug - CCB022 - 2020-01-07
        //Validate that the excess credit characteristic type is valid for the
    	//Account entity
    	CharacteristicEntity charEntity = new CharacteristicEntity_Id(applyExcessCreditCharType,
    			CharacteristicEntityLookup.constants.ACCOUNT).getEntity();
    	
    	if(isNull(charEntity)){
    		//Algorithm Parameter Value %1 is not a valid characteristic type for the %2 Entity.
    		addError(CustomMessageRepositorySpireOne.
    					CCB022_invalidCharacteristicTypeForEntity(applyExcessCreditCharType.getId().getTrimmedValue(), 
    							CharacteristicEntityLookup.constants.ACCOUNT.getLookupValue().fetchLanguageDescription()));
    	}
    	
    	//Validate that the excess credit characteristic type is valid for the
    	//SA Entity
    	charEntity = new CharacteristicEntity_Id(applyExcessCreditCharType,
    			CharacteristicEntityLookup.constants.SERVICE_AGREEMENT).getEntity();
    	
    	if(isNull(charEntity)){
    		//Algorithm Parameter Value %1 is not a valid characteristic type for the %2 Entity.
    		addError(CustomMessageRepositorySpireOne.
    					CCB022_invalidCharacteristicTypeForEntity(applyExcessCreditCharType.getId().getTrimmedValue(), 
    							CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().fetchLanguageDescription()));
    	}
    	
    	//Validate the To Do Role supplied to the algorithm parameters.
    	if(notNull(todoTypeForOverpayment) && notNull(todoRole)) {
    		ToDoTypeRole_Id toDoTypeRoleId = new ToDoTypeRole_Id(todoTypeForOverpayment, todoRole);
    		
    		if(isNull(toDoTypeRoleId.getEntity())) {
    			//Algorithm Parameter Value %1 is not a valid To Do Role for To Do Type %2.
    			addError(CustomMessageRepositorySpireOne.CCB022_invalidtodoRoleForTodoType(todoRole.getId().getTrimmedValue(),
    					todoTypeForOverpayment.getId().getTrimmedValue()));
    		}
    	}
    	
    	//Amount Threshold cannot be negative
    	if(amountThreshold.compareTo(BigDecimal.ZERO) < 0) {
    		addError(CustomMessageRepositorySpireOne.CCB022_amountThresholdIsNegative());
    	}
        //End Add JVitug - CCB022 - 2020-01-07
    	
    	// start add EQuint - B24148 - 2022-10-12
    	String[] specialRoleFlagsArray = specialRolesFlags.split("\\s*,\\s*");
    	for (String specialRoleFlag : specialRoleFlagsArray) {
    		LookupValue lookupValue = new LookupValue_Id(specialRoleFlagLookupField, specialRoleFlag).getEntity();
    		if (isNull(lookupValue)) {
    			addError(CustomMessageRepositorySpireOne.B24148_invalidSpecialRoleFlag(specialRolesFlags));
    		} else {
    			specialRoleFlagList.add(lookupValue);
    		}
    	}
    	
    	ccType = new CustomerContactType_Id(ccClass, ccTypeString).getEntity();
    	if (isNull(ccType)) {
    		addError(CustomMessageRepositorySpireOne.B24148_invalidCcClassType(ccClass.getId().getTrimmedValue(), ccTypeString));
    	}
    	// end add EQuint - B24148 - 2022-10-12
    }

    /**
     * Validate a Service Agreement Type
     * @param cisDivision CisDivision
     * @param saTypeCode String
     * @return saTypeId ServiceAgreementType_Id
     */
    private ServiceAgreementType_Id cmValidateServiceAgreementType(CisDivision cisDivision, String saTypeCode){
        ServiceAgreementType_Id saTypeId = new ServiceAgreementType_Id(cisDivision, saTypeCode);
        if (isNull(saTypeId.getEntity())){
            /*
             * Start Change - Defect 3134789 - 2015-02-23
             */
            //addError(CustomMessageRepositoryMDC.na0050_InvalidSaTypeCisDivisionCombination(cisDivision.getId().getTrimmedValue(), saTypeCode));
            addError(CustomMessageRepositoryMDC.na0050_InvalidSaTypeCisDivisionCombination((isNull(cisDivision) ? "" : cisDivision.getId().getTrimmedValue()), (isBlankOrNull(saTypeCode) ? "" : saTypeCode)));
            /*
             * End Change - Defect 3134789 - 2015-02-23
             */
        }
        return saTypeId ;
    }
    
    //Start Add - 2016-10-12 - PSreekan - 73753
    private Bool checkEligibility() {     

        // Start Add - 2020-09-29 - DLampa - B-17238
        // Return false immediately if payment is null. This is to prevent a null pointer exception when the algorithm
        // is not triggered from payment creation.
        if (isNull(payment)) {
            return Bool.FALSE;
        }
        // End Add - 2020-09-29 - DLampa - B-17238 	
    	
		String tenderSourceStrOpt = cmMGEFeatureConfigurationOptionsRetriever
				.getFeatureOptionValue(
						parmPledgePaymentFeatureConfiguration.getId(),
						CmPledgePaymentsOptionTypeLookup.constants.PLEDGE_TENDER_SOURCE, Bool.TRUE, Bool.FALSE);
		String[] tenderSourceStr = tenderSourceStrOpt.split(",");
		for (int i = 0; i < tenderSourceStr.length; i++) {
			Iterator<PaymentTender> paymentTenderIterator = payment.getPaymentEvent().getPaymentTenders().iterator();
			//Start Change - 2019-03-04 - MPang - Defect 4216682
			//PaymentTender paymentTender = null;
			TenderControl_Id tenderControlId = null;
			//End Change - 2019-03-04 - MPang - Defect 4216682
			while(paymentTenderIterator.hasNext()){
				//Start Change - 2019-02-14 - SRoman - Defect 4206113.
				//if(paymentTenderIterator.next().getTenderControlId().getEntity().getTenderSource().getId().getTrimmedValue().equals(tenderSourceStr[i].trim())){
				//	return Bool.TRUE;
				//}
				tenderControlId = paymentTenderIterator.next().getTenderControlId();
				//Start Change - 2019-03-04 - MPang - Defect 4216682
				//if(notNull(paymentTenderIterator.next().getTenderControlId())){
					//if(paymentTenderIterator.next().getTenderControlId().getEntity().getTenderSource().getId().getTrimmedValue().equals(tenderSourceStr[i].trim())){
				if(notNull(tenderControlId)){
					if(tenderControlId.getEntity().getTenderSource().getId().getTrimmedValue().equals(tenderSourceStr[i].trim())){
				//End Change - 2019-03-04 - MPang - Defect 4216682		
						return Bool.TRUE;
					}
				}
				//End Change - 2019-02-14 - SRoman - Defect 4206113.
			}
		}
		return Bool.FALSE;
	}
    //End Add - 2016-10-12 - PSreekan - 73753

    /**
     * Create a Service Agreement
     * @param cisDivision CisDivision
     * @param saTypeId ServiceAgreementType_Id
     * @return ServiceAgreement
     */
    private ServiceAgreement cmCreateServiceAgreement(CisDivision cisDivision, ServiceAgreementType_Id  saTypeId){
        ServiceAgreement_DTO saDto = new ServiceAgreement_DTO();
        saDto.setAccountId(account.getId());
        saDto.setServiceAgreementTypeId(saTypeId);
        saDto.setStartDate(processDate);
        saDto.setCustomerRead(CustomerReadLookup.constants.NO);
        // CVB - 2013-07-04 - Start
        // saDto.setStatus(ServiceAgreementStatusLookup.constants.ACTIVE);
        saDto.setStatus(ServiceAgreementStatusLookup.constants.PENDING_START);
        // CVB - 2013-07-04 - End

        return saDto.newEntity();
    }

    /**
     * Apply credit amount to a Service Agreement
     * @param cisDivision CisDivision
     * @param saType ServiceAgreementType
     * @param amount Money
     * @param shouldBeNonRecurring Bool
     */
    private void cmApplyCreditToServiceAgreement(CisDivision cisDivision, ServiceAgreementType saType, Money amount, Bool shouldBeNonRecurring){
        ServiceAgreement_Id serviceAgreementId;
        ServiceAgreement serviceAgreement = null;
        if (shouldBeNonRecurring.isFalse()){
            // Retrieve the Active SA
            serviceAgreementId = (ServiceAgreement_Id) cmGetActiveServiceAgreement(cisDivision, saType).firstRow();
            if (isNull(serviceAgreementId)){
                serviceAgreement = cmCreateServiceAgreement(cisDivision, saType.getId());
            }
            else {
                serviceAgreement = serviceAgreementId.getEntity();
            }
        }
        else {
            SQLResultRow result = (SQLResultRow) cmGetActiveNonRecurringServiceAgreement(cisDivision, saType).firstRow();
            //TIR_NA0050 2013-03-26 - CVB Start
            // serviceAgreementId = (ServiceAgreement_Id) result.getId("ID", ServiceAgreement.class);
            if (notNull(result)){
                serviceAgreementId = (ServiceAgreement_Id) result.getId("ID", ServiceAgreement.class);
            //if (notNull(serviceAgreementId)){
            //TIR_NA0050 2013-03-26 - CVB End
                serviceAgreement = serviceAgreementId.getEntity();
                BigDecimal recurringChargeAmount = (BigDecimal) result.getBigDecimal("RCR_CHG_AMT");
                if (recurringChargeAmount.compareTo(BigDecimal.ZERO) != 0){
                    serviceAgreement = cmCreateServiceAgreement(cisDivision, saType.getId());
                }
            }
            else {
                serviceAgreement = cmCreateServiceAgreement(cisDivision, saType.getId());
            }
        }

        // Apply the Payment to the SA		
        CustomerClassOverpaymentDistributionData distributionData = CustomerClassOverpaymentDistributionData.Factory.newInstance();
        distributionData.setCreditAmount(amount);
        distributionData.setServiceAgreement(serviceAgreement);
        distributionDataList.add(distributionData);
    }

    /**
     * Retrieve an active Service Agreement
     * @param cisDivision CisDivision
     * @param saType ServiceAgreementType
     * @return query Query
     */
    private Query cmGetActiveServiceAgreement(CisDivision cisDivision, ServiceAgreementType saType) {
        Query query = createQuery("FROM ServiceAgreement SA "
                + "WHERE SA.account = :accountId "
                + "AND SA.serviceAgreementType.id.division = :cisDivision "
                + "AND SA.serviceAgreementType.id.saType = :saTypeCode "
                // start change B24796 - EQuint - 2022-11-17
                // //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                // //  + "AND SA.status = :activeStatus");
                // + "AND SA.status = :activeStatus", getClass().getName());
        		// //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                + "AND SA.status between :activeStatus and :reactivated", getClass().getName());
        		// end change B24796 - EQuint - 2022-11-17
        query.bindId("accountId", account.getId());
        query.bindId("cisDivision", cisDivision.getId());
        query.bindStringProperty("saTypeCode", ServiceAgreementType.properties.saType, saType.getId().getSaType());
        query.bindLookup("activeStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
        // start add B24796 - EQuint - 2022-11-17
        query.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
        // end add B24796 - EQuint - 2022-11-17
        query.addResult("saId", "SA.id");

        return query;
    }

    /**
     * Retrieve an active Non-Recurring Service Agreement
     * @param cisDivision CisDivision
     * @param saType ServiceAgreementType
     * @return ps PreparedStatement
     */
    private PreparedStatement cmGetActiveNonRecurringServiceAgreement(CisDivision cisDivision, ServiceAgreementType saType){
        StringBuilder sqlString = new StringBuilder();

        sqlString.append(" SELECT sa.SA_ID as ID");
        sqlString.append(" ,  COALESCE(sarc.RCR_CHG_AMT, 0) AS RCR_CHG_AMT");
        sqlString.append(" FROM CI_SA sa LEFT JOIN CI_SA_RCHG_HIST sarc");
        sqlString.append(" ON sa.SA_ID = sarc.SA_ID");
        sqlString.append(" AND sarc.EFFDT <= :processDate");
        sqlString.append(" WHERE sa.ACCT_ID = :accountId");
        sqlString.append(" AND sa.CIS_DIVISION = :cisDivision");
        sqlString.append(" AND sa.SA_TYPE_CD = :saTypeCode");
        // start change B24796 - EQuint - 2022-11-17
        // sqlString.append(" AND sa.SA_STATUS_FLG = :activeStatus");
        sqlString.append(" AND sa.SA_STATUS_FLG BETWEEN :activeStatus and :reactivated");
        // end change B24796 - EQuint - 2022-11-17
        sqlString.append(" ORDER BY rcr_chg_amt ASC");
        sqlString.append(" ");
        //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
       // PreparedStatement ps = createPreparedStatement(sqlString.toString());
        PreparedStatement ps = createPreparedStatement(sqlString.toString(), getClass().getName());
        //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        ps.bindDate("processDate", getProcessDateTime().getDate());
        ps.bindId("accountId", account.getId());
        ps.bindId("cisDivision", cisDivision.getId());
        ps.bindStringProperty("saTypeCode", ServiceAgreementType.properties.saType, saType.getId().getSaType());
        ps.bindLookup("activeStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
        // start add B24796 - EQuint - 2022-11-17
        ps.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
        // end add B24796 - EQuint - 2022-11-17

        ps.setMaxResults(1);		
        return ps;
    }

    /**
     * Determin if an active Service Task exists
     * @return Bool
     */
    private Bool cmRetrieveActiveServiceTask(){
        Query query = createQuery("FROM ServiceTask ST, ServiceTaskCharacteristic STC "
                + "WHERE ST.serviceTaskType = :serviceTaskType "
                + "AND ST.businessObject = :boCode "
                + "AND ST.status = :activeBoStatus "
                + "AND ST.id = STC.id.serviceTask "
                + "AND STC.id.characteristicType = :accountIdCharType "
                + "AND (STC.adhocCharacteristicValue = :accountIdAdhocCharVal "
                + "    OR STC.characteristicValueForeignKey1 = :accountIdCharValFk1 "
                //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                // + "    OR STC.characteristicValue = :accountIdCharVal)");
                + "    OR STC.characteristicValue = :accountIdCharVal)", getClass().getName());
        		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        
        query.bindId("serviceTaskType", parmPledgeServiceTaskType.getId());
        query.bindId("boCode", parmPledgeBusinessObject.getId());
        query.bindStringProperty("activeBoStatus", BusinessObjectStatus.properties.status, parmBoActiveStatusValue);
        query.bindId("accountIdCharType", parmAccountIdCharacteristicType.getId());
        query.bindStringProperty("accountIdAdhocCharVal", ServiceTaskCharacteristic.properties.adhocCharacteristicValue, account.getId().getTrimmedValue());
        query.bindStringProperty("accountIdCharValFk1", ServiceTaskCharacteristic.properties.characteristicValueForeignKey1, account.getId().getTrimmedValue());
        query.bindStringProperty("accountIdCharVal", ServiceTaskCharacteristic.properties.characteristicValue, account.getId().getTrimmedValue());
        query.addResult("serviceTaskId", "ST.id");

        if (query.listSize() > 0){
            return Bool.TRUE;
        }
        else {
            return Bool.FALSE;
        }
    }
}
