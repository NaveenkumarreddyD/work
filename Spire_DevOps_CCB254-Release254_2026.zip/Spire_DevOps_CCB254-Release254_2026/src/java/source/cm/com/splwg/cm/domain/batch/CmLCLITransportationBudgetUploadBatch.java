/* ************************************************************************                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * LCLI Transportation Budget Upload 
 * 
 * This batch program will mass upload budget information for Transportation Customers 
 * This job is subsequent to the Budget creation program CM-BRCRE. 
 * This job will transition the Budget Service Task to the BUDGET_STATUS configured
 * upon completion.
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:       Reason:
 * YYYY-MM-DD   IN        Reason text.
 *           
 * 2015-02-28   CAtilano  CCB023 Initial Version.
 * 
 * 
 *************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic;
import com.splwg.base.domain.serviceTask.ServiceTaskRelatedObject;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMDC;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;

/**
 * @author OGC04023
 *
@BatchJob (modules = {}
 *      , multiThreaded = false
 *      , rerunnable = false
 *      , softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = BUDGET_SERVICE_TASK_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = RATE_YEAR_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = RATE_YEAR_CHAR_VAL, required = true, type = string)
 *            , @BatchJobSoftParameter (name = BUDGET_STATUS, required = true, type = string)})
 */
public class CmLCLITransportationBudgetUploadBatch extends
		CmLCLITransportationBudgetUploadBatch_Gen {

    private static String filePath;
    private static String fileName;
    private static File inputFilePathAndName;
    private static BufferedReader inputFile;
    private static String budgetStatus;
    private static CharacteristicType rateYearCharType;
    private static ServiceTaskType budgetServiceTaskType;
    private static String rateYearCharVal;
    
    
    public void validateSoftParameters(boolean isNewRun){
        initializeSoftParams();

        File folder = new File(filePath);

        if(!(folder.exists() && folder.isDirectory())){
            addError(CustomMessageRepositorySpireOne.CCB015_2_FilePathInvalid(filePath));
        }
        
        File file = new File(filePath , fileName);
        
        if(!file.exists()) {
            addError(CustomMessageRepositorySpireOne.CCB015_2_FileDoesNotExist(fileName, filePath));
        }
        String status = getParameters().getBUDGET_STATUS();
        BusinessObject stBO = budgetServiceTaskType.getRelatedTransactionBO();
        ListFilter <BusinessObjectStatus>filter = stBO.getStatuses().createFilter("where this.id.status = :status", "BO Status Query");
        filter.bindStringProperty("status", BusinessObjectStatus.properties.status, status);
        if(isNull(filter.firstRow())){
        	addError(CustomMessageRepositoryMDC.ni00263InvalidStatusForBo(status,stBO.fetchLanguageDescription()));
        }
        
        

    }
	
	public JobWork getJobWork() {

        List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit workUnit = new ThreadWorkUnit();
        workUnits.add(workUnit);
        return createJobWorkForThreadWorkUnitList(workUnits);

	}
	
    private void initializeSoftParams(){
        filePath = getParameters().getFILE_PATH();
        fileName = getParameters().getFILE_NAME();
        budgetStatus = getParameters().getBUDGET_STATUS();
        rateYearCharType = getParameters().getRATE_YEAR_CHAR_TYPE();
        rateYearCharVal = getParameters().getRATE_YEAR_CHAR_VAL();
        budgetServiceTaskType = getParameters().getBUDGET_SERVICE_TASK_TYPE();
        
    }

	public Class<CmLCLITransportationBudgetUploadBatchWorker> getThreadWorkerClass() {
		return CmLCLITransportationBudgetUploadBatchWorker.class;
	}

	public static class CmLCLITransportationBudgetUploadBatchWorker extends
			CmLCLITransportationBudgetUploadBatchWorker_Gen {
        private int errRecCnt = 0;
        private Integer recordCounter = 0;
        private Integer lineNumber = 0;
        private BusinessObjectInstance boInstance = null;
        String strRecordLine = " ";
        Integer lineCount = 0;
        boolean isSAinError = false;
        //FILE LAYOUT
        private String fileName;
        private final int NBR_OF_COLUMNS_WOC = 11;
        private final int NBR_OF_COLUMNS_WC = 12;
        private final int SA_COL = 1;
        private final int YEAR_COL = 2;
        private final int MONTH_COL = 3;
        private final int FIRM1_COL = 4;
        private final int FIRM2_COL = 5;
        private final int FIRM3_COL = 6;
        private final int INT3_COL = 7;
        private final int INT4_COL = 8;
        private final int INT5_COL = 9;
        private final int INT6_COL = 10;
        private final int NOTES_COL = 11;
        private String saId_desc = "SA_ID";
        private String year_desc = "RATE_YEAR";
        private String month_desc = "MONTH";
        private String firm1_desc = "F1";
        private String firm2_desc = "F2";
        private String firm3_desc = "F3";
        private String int3_desc  = "I3";
        private String int4_desc = "I4";
        private String int5_desc = "I5";
        private String int6_desc = "I6";
        
        private String saId = "";
        private String previousSaId = null;
        private BigInteger year;
        private String month;
        private BigInteger firm1;
        private BigInteger firm2;
        private BigInteger firm3;
        private BigInteger int3;
        private BigInteger int4;
        private BigInteger int5;
        private BigInteger int6;
        private String notes;
        
        
        public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
            fileName = getParameters().getFILE_NAME();
        }

		public ThreadExecutionStrategy createExecutionStrategy() {
			// TODO Auto-generated method stub
			return new StandardCommitStrategy(this);
		}

        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {
            //Restart the counter
            recordCounter = 0;
            errRecCnt = 0;
            
            openFile();
            //Skip header Line
            strRecordLine = readFileLine();
            lineCount = 2;
            strRecordLine = readFileLine();
            while (notNull(strRecordLine)){
            	strRecordLine = strRecordLine + " ";
            	//the regular expression below will split values when the field is in double quotes 
            	String[]record = strRecordLine.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
            	saId = record[SA_COL];            	
                //parseLineAndRetrieveValues(record);
                //if there is a new SA and BO was not in error, Update it.
                if(!saId.equals(previousSaId)){
                	if(!isNull(boInstance) && !isSAinError){
                		if(!isBlankOrNull(notes))
                			boInstance.getGroup("budgetReviewDetails").set("notes", notes);
                		BusinessObjectDispatcher.update(boInstance);
                		boInstance = null;
                	}
                	notes = "";
                	previousSaId = saId;
                	recordCounter+=1;
                	isSAinError = false;
                    parseLineAndRetrieveValues(record);
                	if(!isSAinError){
	                	ServiceTask_Id budgetSt = verifyBudgetServiceTask();
	            		if(isNull(budgetSt)){
	            			isSAinError=true;
	            			errRecCnt+=1;
	            			logError(CustomMessageRepositorySpireOne.CCB023_FieldErrorInFile(lineCount.intValue(), YEAR_COL, year_desc, "Transport Budget Service Task not found"));
	            		}
	            		else{
	            			processNewSa(budgetSt);
	            			processFirmAndIntValues();
	            		}
                	}
                }
                //if the processed SA is the same, just add Interruptible and Firm Values.
                else{
                	parseLineAndRetrieveValues(record);
                	if(!isSAinError)
                		processFirmAndIntValues();              
                }
                strRecordLine = readFileLine();
                lineCount++;

            }
            
            if(!isSAinError && !isNull(boInstance)){
        		if(!isBlankOrNull(notes))
        			boInstance.getGroup("budgetReviewDetails").set("notes", notes);
        		BusinessObjectDispatcher.update(boInstance);
        	}
            closeFile();
            WorkUnitResult result = new WorkUnitResult(true);
            result.setUnitsProcessed(recordCounter);
            result.setUnitsInError(errRecCnt);

            return result;
        }
        
        /**
         * This method will validate and retrieve values
         * @param strRecordLine
         * @return Boolean
         */
        private Boolean parseLineAndRetrieveValues(String [] strRecordLine){
        	
        	if(!isSAinError)
	        {
                //If length of the whole record line, log error
                if(isNull (new ServiceAgreement_Id(saId).getEntity())){
                	errRecCnt+=1;
                	isSAinError = true;
                	logError(CustomMessageRepositorySpireOne.CCB023_FieldErrorInFile(lineCount.intValue(),SA_COL+1 , saId, "SA does not exist"));
                	return false;
    	            
                }
	        	strRecordLine = cleanValues(strRecordLine);
	            if(strRecordLine.length != NBR_OF_COLUMNS_WOC && strRecordLine.length != NBR_OF_COLUMNS_WC){
	                errRecCnt+=1;
	                isSAinError = true;
	                logError(CustomMessageRepositorySpireOne.CCB015_2_lineHasInvalidLength(String.valueOf(lineCount) , fileName));
	                return false;
	            }
	
	            
	            try{
	            	year = BigInteger.valueOf(Integer.parseInt(strRecordLine[YEAR_COL]));
	            }catch(NumberFormatException e){
	            	isSAinError = true;
	            	errRecCnt+=1;
	            	logError(CustomMessageRepositorySpireOne.CCB023_FieldErrorInFile(lineCount.intValue(), YEAR_COL+1, year_desc, strRecordLine[YEAR_COL]));
	            	return false;
	            }
	            
	            month = strRecordLine[MONTH_COL];
	            Integer monthInt = Integer.parseInt(month);
	            try{
	            	if(monthInt > 0  && monthInt <10)
	            		month = "0"+month;
	            	if(monthInt < 1 || monthInt >12){
		            	isSAinError = true;
		            	errRecCnt+=1;
	                	logError(CustomMessageRepositorySpireOne.CCB023_FieldErrorInFile(lineCount.intValue(), MONTH_COL+1, month_desc, strRecordLine[MONTH_COL]));
	                	return false;
	            	}
	            	
	            }catch(NumberFormatException e){
	            	isSAinError = true;
	            	errRecCnt+=1;
	            	logError(CustomMessageRepositorySpireOne.CCB023_FieldErrorInFile(lineCount.intValue(), MONTH_COL+1, month_desc, strRecordLine[MONTH_COL]));
	            	return false;
	            }
	            
	            try{
	            	if(isBlankOrNull(strRecordLine[FIRM1_COL]))
	            		firm1 = BigInteger.ZERO;
	            	else
	            		firm1 = BigInteger.valueOf(Integer.parseInt(strRecordLine[FIRM1_COL]));
	            }catch(NumberFormatException e){
	            	isSAinError = true;
	            	errRecCnt+=1;
	            	logError(CustomMessageRepositorySpireOne.CCB023_FieldErrorInFile(lineCount.intValue(), FIRM1_COL+1, firm1_desc, strRecordLine[FIRM1_COL]));
	            	return false;
	            }
	            
	            try{
	            	if(isBlankOrNull(strRecordLine[FIRM2_COL]))
	            		firm2 = BigInteger.ZERO;
	            	else 
	            		firm2 = BigInteger.valueOf(Integer.parseInt(strRecordLine[FIRM2_COL]));
	            }catch(NumberFormatException e){
	            	isSAinError = true;
	            	errRecCnt+=1;
	            	logError(CustomMessageRepositorySpireOne.CCB023_FieldErrorInFile(lineCount.intValue(), FIRM2_COL+1, firm2_desc, strRecordLine[FIRM2_COL]));
	            	return false;
	            }
	            
	            try{
	            	if(isBlankOrNull(strRecordLine[FIRM3_COL]))
	            		firm3 = BigInteger.ZERO;
	            	else 
	            		firm3 = BigInteger.valueOf(Integer.parseInt(strRecordLine[FIRM3_COL]));
	            }catch(NumberFormatException e){
	            	isSAinError = true;
	            	errRecCnt+=1;
	            	logError(CustomMessageRepositorySpireOne.CCB023_FieldErrorInFile(lineCount.intValue(), FIRM3_COL+1, firm3_desc, strRecordLine[FIRM3_COL]));
	            	return false;
	            }
	            
	            
	            try{
	            	if(isBlankOrNull(strRecordLine[INT3_COL]))
	            		int3 = BigInteger.ZERO;
	            	else
	            		int3 = BigInteger.valueOf(Integer.parseInt(strRecordLine[INT3_COL]));
	            }catch(NumberFormatException e){
	            	isSAinError = true;
	            	errRecCnt+=1;
	            	logError(CustomMessageRepositorySpireOne.CCB023_FieldErrorInFile(lineCount.intValue(), INT3_COL+1, int3_desc, strRecordLine[INT3_COL]));
	            	return false;
	            }
	            
	            
	            try{
	            	if(isBlankOrNull(strRecordLine[INT4_COL]))
	            		int4 = BigInteger.ZERO;
	            	else
	            		int4 = BigInteger.valueOf(Integer.parseInt(strRecordLine[INT4_COL]));
	            }catch(NumberFormatException e){
	            	isSAinError = true;
	            	errRecCnt+=1;
	            	logError(CustomMessageRepositorySpireOne.CCB023_FieldErrorInFile(lineCount.intValue(), INT4_COL+1, int4_desc, strRecordLine[INT4_COL]));
	            	return false;
	            }
	            
	            try{
	            	if(isBlankOrNull(strRecordLine[INT5_COL]))
	            		int5 = BigInteger.ZERO;
	            	else
	            		int5 = BigInteger.valueOf(Integer.parseInt(strRecordLine[INT5_COL]));
	            }catch(NumberFormatException e){
	            	isSAinError = true;
	            	errRecCnt+=1;
	            	logError(CustomMessageRepositorySpireOne.CCB023_FieldErrorInFile(lineCount.intValue(), INT5_COL+1, int5_desc, strRecordLine[INT5_COL]));
	            	return false;
	            }
	
	            try{
	            	if(isBlankOrNull(strRecordLine[INT6_COL]))
	            		int6 = BigInteger.ZERO;
	            	else
	            		int6 = BigInteger.valueOf(Integer.parseInt(strRecordLine[INT6_COL]));
	            }catch(NumberFormatException e){
	            	isSAinError = true;
	            	errRecCnt+=1;
	            	logError(CustomMessageRepositorySpireOne.CCB023_FieldErrorInFile(lineCount.intValue(), INT6_COL+1, int6_desc, strRecordLine[INT6_COL]));
	            	return false;
	            }
	            try{
	            	String note = strRecordLine[NOTES_COL];
	            	if(!isBlankOrNull(note))
	            		notes = notes + note;
	            }catch (ArrayIndexOutOfBoundsException e){
	            	notes = notes + "";
	            }
        	}
            
            return true;
        }
        
        /**
         * This method will get rid of double quotes and commas
         * @param String[] record
         * @return String[] record
         */
        private String[] cleanValues(String[] record){
        	String field = null;
        	for(int index = 0; index < record.length; index++){
        		if(!(index == NOTES_COL)){
	        		field = record[index];
	        		field = field.replace("\"", "");
	        		field = field.replace(",","");
	        		record[index] = field;
        		}
        	}
        	return record;
        }
        /**
         * This method will retrieve the Budget Service task associated with the Rate year and SA
         * @return ServiceTaskId 
         */
        private ServiceTask_Id verifyBudgetServiceTask(){
        	ServiceTask_Id result = null;
        	String stSql = "SELECT STSA.F1_SVC_TASK_ID"
        			+ " FROM F1_SVC_TASK_REL_OBJ STSA"
        			+ " ,F1_SVC_TASK_CHAR RY"
        			+ " WHERE STSA.F1_SVC_TASK_ID = RY.F1_SVC_TASK_ID"
        			+ " AND STSA.MAINT_OBJ_CD = 'SA'"
        			+ " AND STSA.PK_VALUE1 = :saId"
        			+ " AND RY.CHAR_TYPE_CD = :charType"
        			+ " AND SRCH_CHAR_VAL = :charVal";
        	PreparedStatement ps = createPreparedStatement(stSql, "verifyBudgetServiceTask");
            ps.bindStringProperty("saId" , ServiceTaskRelatedObject.properties.primaryKeyValue1 , saId);
            ps.bindEntity("charType", rateYearCharType);
            ps.bindStringProperty("charVal", ServiceTaskCharacteristic.properties.searchCharacteristicValue, rateYearCharVal); 
            SQLResultRow row =  ps.firstRow();
            if (!isNull(row))
            	result =(ServiceTask_Id) row.getId("F1_SVC_TASK_ID", ServiceTask.class);
            ps.close();
            
        	return result;
        }
        
        /**
         * Open File Method 
         */
        private void openFile() {
            inputFilePathAndName = new File(filePath, fileName);
            try{
                inputFile = new BufferedReader(new FileReader(inputFilePathAndName));
            }
            catch(IOException e){
                throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB015_2_ErrorInOpeningFile(fileName, filePath));
            }
        }
        
        /**
         * Read a line from the file
         * @return a line from a file
         */
        private String readFileLine(){
            try {
                return inputFile.readLine();
            }
            catch(IOException e) {
                throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB015_2_ErrorReadingFile(fileName , filePath));
            }
        }
        
        /**
         * This method will attempt to close the file 
         */
        private void closeFile(){
            try {
                inputFile.close();
            }
            catch(IOException e) {
                throw new RunAbortedException(CustomMessageRepositorySpireOne.CCB015_2_ErrorInClosingFile(fileName , filePath));
            }
        }
        
        /**
         * This method will populate BO data
         */
        private void processNewSa(ServiceTask_Id budgetSt){
			BusinessObject serviceTaskBO = budgetServiceTaskType.getRelatedTransactionBO();
			boInstance =  BusinessObjectInstance.create(serviceTaskBO);
			boInstance.set("serviceTaskId", budgetSt.getIdValue());
			boInstance = BusinessObjectDispatcher.read(boInstance);
			boInstance.set("boStatus", budgetStatus);
			boInstance.set("statusDateTime", getProcessDateTime());
        }
    	
        /**
         * This method will populate Form and Interruptible Values from a given Month
         */
        private void processFirmAndIntValues(){
        	COTSInstanceListNode dataList = boInstance.getGroup("budgetReviewDetails").getList("newBudget").getElementWhere("[month='"+month+"']");
			dataList.set("budgetF1",BigDecimal.valueOf(firm1.doubleValue()));
			dataList.set("budgetF2",BigDecimal.valueOf(firm2.doubleValue()));
			dataList.set("budgetF3",BigDecimal.valueOf(firm3.doubleValue()));
			dataList.set("budgetI3",BigDecimal.valueOf(int3.doubleValue()));
			dataList.set("budgetI4",BigDecimal.valueOf(int4.doubleValue()));
			dataList.set("budgetI5",BigDecimal.valueOf(int5.doubleValue()));
			dataList.set("budgetI6",BigDecimal.valueOf(int6.doubleValue()));
        }

	}

}
