/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Low Income Program Configurations Option Type (for Feature Configuration) 
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 *
 * 2018-07-30   JHERNA		SysAid#245408 Initial Version. 
 **************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * @author 90622
 *
 @LookupFieldname (value = XLIP_OPT_TYP_FLG)
 */
@SuppressWarnings("serial")
public class CmLowIncomeProgramConfigurationsOptionTypeLookup_Impl 
		extends CmLowIncomeProgramConfigurationsOptionTypeLookup_Gen {

}

