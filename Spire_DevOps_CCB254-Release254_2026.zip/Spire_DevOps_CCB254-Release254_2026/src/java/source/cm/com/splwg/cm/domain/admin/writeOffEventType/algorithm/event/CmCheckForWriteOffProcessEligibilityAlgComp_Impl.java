/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Write off Event - Check for Write Off Process Eligibility.
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2020-08-04   JHERNA     SysAid#336941. Initial Version.
 * 
 *************************************************************************/
package com.splwg.cm.domain.admin.writeOffEventType.algorithm.event;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObject;
import com.splwg.base.domain.common.maintenanceObject.MaintenanceObject_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.ccb.api.lookup.ReferralStatusLookup;
import com.splwg.ccb.api.lookup.WriteOffEventStatusLookup;
import com.splwg.ccb.api.lookup.WriteOffStatusLookup;
import com.splwg.ccb.api.lookup.WriteOffStatusReasonLookup;
import com.splwg.ccb.domain.admin.writeOffEventType.algorithm.event.WriteOffEventTypeEventAlgorithmSpot;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral;
import com.splwg.ccb.domain.creditcollections.collectionAgencyReferral.entity.CollectionAgencyReferral_Id;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffEvent;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffEvent_DTO;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffEvent_Id;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffProcess;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffProcess_DTO;
import com.splwg.ccb.domain.creditcollections.writeOffProcess.entity.WriteOffProcess_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author blu02772
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = role, name = toDoRole, type = entity)
 *            , @AlgorithmSoftParameter (name = criteria1EligibleIfNoActiveCAR, required = true, type = boolean)})
 */
public class CmCheckForWriteOffProcessEligibilityAlgComp_Impl 
		extends CmCheckForWriteOffProcessEligibilityAlgComp_Gen implements
		WriteOffEventTypeEventAlgorithmSpot {

	/* HARD PARAMETERS */
	@SuppressWarnings("unused")
	private Account hpAccount;
	private WriteOffEvent hpWOEvent;
	
	@Override
	public void setAccount(Account arg0) {
		hpAccount = arg0;
	}

	@Override
	public void setWriteOffEvent(WriteOffEvent arg0) {
		hpWOEvent = arg0;
	}
	
	/* SOFT PARAMETERS */
	private ToDoType parmTDType;
	private Role parmTDRole;
	private Bool parmCriteria1;
	
	/* WORK VARIABLES */
	private ToDoTypeRole wToDoTypeRole;
	private WriteOffProcess wWOProcess;
	@SuppressWarnings("unused")
	private String wAcctStr, wSaStr, wWoProcStr, wCollAgencyReferralStr;
	private Date wProcessDate;
	
	/* CONSTANTS */	
	private final static MaintenanceObject_Id MO_ACCOUNT = new MaintenanceObject_Id("ACCOUNT");
	private final static MaintenanceObject_Id MO_COLL_AGENCY_REFERRAL = new MaintenanceObject_Id("COLL AGY REF");
	private final static MaintenanceObject_Id MO_WO_PROCESS = new MaintenanceObject_Id("WO PROC");
	     	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		
		// Retrieve and validate parameter 10: To Do Type
		parmTDType = this.getToDoType();
		
		// Retrieve and validate parameter 20: To Do Role
		parmTDRole = this.getToDoRole();
		
		if (notNull(parmTDRole)) {
			// validate the provided role if it is valid parameter 10: To Do Type
			ToDoTypeRole_Id tdTypeRoleID = new ToDoTypeRole_Id(parmTDType, parmTDRole);
			if (isNull(tdTypeRoleID.getEntity())) {
			    // Algorithm (%1)'s To Do Role parameter (%2) is not valid for To Do Type parameter (%3)
				addError(CustomMessageRepositoryMGE.commAlgorithmParameterToDoRoleNotValidForParameterToDoType(this.getAlgorithmId().getTrimmedValue(),
						parmTDRole.getId().getTrimmedValue(), 
						parmTDType.getId().getTrimmedValue()));
			}	
			wToDoTypeRole = tdTypeRoleID.getEntity();
		}
		else {
			// In the event that parameter 20: To Do Role is not provided, use the configured default to do role for parameter 10: To Do Type
			wToDoTypeRole = parmTDType.getDefaultRole();
		}		
		
		// Retrieve and validate parameter 30: Criteria 1 - Eligible If No Active CAR
		parmCriteria1 = this.getCriteria1EligibleIfNoActiveCAR();
		
	}
	
	private void initVariables() {
		
		wAcctStr= " ";
		wSaStr = " ";
		wWoProcStr = " ";
		wCollAgencyReferralStr = " ";
		wWOProcess = hpWOEvent.fetchIdWriteOffProcess();
		wProcessDate = this.getProcessDateTime().getDate();
	}
	
	@Override
	public void invoke() {

		initVariables();
		
		if (parmCriteria1.isTrue()) {
			/* Perform Checks for Criteria 1*/
			Bool shouldProceed = performCriteria1Validation();
			/* An active collection agency referral is found for an SA being written off */
			if (shouldProceed.isFalse()) {
				/* Create a to do entry to inform necessary group to investigate and perform manual write off */
				performCreationOfToDoEntry(wAcctStr,
						wSaStr, 
						wWOProcess.getId().getTrimmedValue(), 
						wCollAgencyReferralStr);
				/* Cancel the write off */
				performWriteOffCancellation();
			}
		}		
	}
	
	private Bool performCriteria1Validation() {
		
		Bool returnValue = Bool.TRUE;
		
		/* Get collection of SAs to be written off */
		StringBuilder stringBuilder = new StringBuilder();		
		stringBuilder.append("SELECT SA_ID ");
		stringBuilder.append("FROM CI_WO_PROC_SA ");
		stringBuilder.append("WHERE WO_PROC_ID = :woProcID ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==getWOPSAs==");
		prepState.setAutoclose(false);
		prepState.bindId("woProcID", wWOProcess.getId());
		prepState.execute();
		
		if (prepState.list().size() > 0) {
			Iterator<SQLResultRow> collWopSa = prepState.list().iterator();
			while (collWopSa.hasNext()) {
				SQLResultRow sqlRow = (SQLResultRow) collWopSa.next();				 
				ServiceAgreement_Id saID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
				returnValue = validateSAForCriteria1(saID);			
			}
		}
		
		prepState.close();
		return returnValue;
	}

	@SuppressWarnings("unused")
	private Bool validateSAForCriteria1(ServiceAgreement_Id saID) {
		
		Bool returnValue = Bool.TRUE;
		wSaStr = saID.getTrimmedValue();
		
		StringBuilder sbRelatedObjOfCollAgyPlacement = new StringBuilder();		
		sbRelatedObjOfCollAgyPlacement.append("SELECT "); 
		sbRelatedObjOfCollAgyPlacement.append("  REL.F1_SVC_TASK_ID, REL.MAINT_OBJ_CD, REL.PK_VALUE1 ");
		sbRelatedObjOfCollAgyPlacement.append("FROM "); 
		sbRelatedObjOfCollAgyPlacement.append("  F1_SVC_TASK CP, F1_SVC_TASK_CHAR CPC, F1_SVC_TASK_REL_OBJ REL ");
		sbRelatedObjOfCollAgyPlacement.append("WHERE "); 
		sbRelatedObjOfCollAgyPlacement.append("  CP.BUS_OBJ_CD = 'CM-CollAgencyPlacement' ");
		sbRelatedObjOfCollAgyPlacement.append("  AND CP.BO_STATUS_CD = 'ACTIVE' ");
		sbRelatedObjOfCollAgyPlacement.append("  AND CPC.F1_SVC_TASK_ID = CP.F1_SVC_TASK_ID ");
		sbRelatedObjOfCollAgyPlacement.append("  AND CPC.CHAR_TYPE_CD = 'C1-SA' ");
		sbRelatedObjOfCollAgyPlacement.append("  AND CPC.SRCH_CHAR_VAL = :saID ");
		sbRelatedObjOfCollAgyPlacement.append("  AND REL.F1_SVC_TASK_ID = CP.F1_SVC_TASK_ID ");
		
		PreparedStatement psRelatedObjOfCollAgyPlacement = createPreparedStatement(
				sbRelatedObjOfCollAgyPlacement.toString(),
				"==sbRelatedObjOfCollAgyPlacement==");
		psRelatedObjOfCollAgyPlacement.setAutoclose(false);
		psRelatedObjOfCollAgyPlacement.bindId("saID", saID);
		psRelatedObjOfCollAgyPlacement.execute();
		
		if (psRelatedObjOfCollAgyPlacement.list().size() > 0) {
			Iterator<SQLResultRow> iter = psRelatedObjOfCollAgyPlacement.list().iterator();
			
			while (iter.hasNext()) {
				
				SQLResultRow sqlRow = iter.next();
				ServiceTask_Id collAgencyPlacementID = (ServiceTask_Id) sqlRow.getId("F1_SVC_TASK_ID", ServiceTask.class);
				MaintenanceObject_Id maintObjID = (MaintenanceObject_Id) sqlRow.getId("MAINT_OBJ_CD", MaintenanceObject.class);
				String pkValue = sqlRow.getString("PK_VALUE1");
				
				Account_Id relatedAcctID = null;
				CollectionAgencyReferral_Id relatedCollectionAgencyReferralID = null;
				WriteOffProcess_Id relatedWOProcessID = null;
				
				if (maintObjID.compareTo(MO_ACCOUNT) == 0) {
					relatedAcctID = new Account_Id(pkValue.trim());	
					wAcctStr = pkValue.trim();
				}
				else if (maintObjID.compareTo(MO_COLL_AGENCY_REFERRAL) == 0) {
					relatedCollectionAgencyReferralID = new CollectionAgencyReferral_Id(pkValue.trim());	
					wCollAgencyReferralStr = pkValue.trim();
				}
				else if (maintObjID.compareTo(MO_WO_PROCESS) == 0) {
					relatedWOProcessID = new WriteOffProcess_Id(pkValue.trim());
					wWoProcStr = pkValue.trim();
				}
				
				if (notNull(relatedCollectionAgencyReferralID) 
						&& notNull(relatedCollectionAgencyReferralID.getEntity())) {
					CollectionAgencyReferral relatedCollectionAgencyReferral = relatedCollectionAgencyReferralID.getEntity();
					ReferralStatusLookup referralStatus = relatedCollectionAgencyReferral.getReferralStatus();
					if (referralStatus.isActive()) {
						returnValue = Bool.FALSE;
						break;
					}
				}
			}
		}
		
		psRelatedObjOfCollAgyPlacement.close();
		
		return returnValue;
	}

	private void performCreationOfToDoEntry(String acctStr, String saStr, String woProcStr, String carID) {
		
		/* Message Parameters */
		List<String> msgParms = new ArrayList<String>();
		msgParms.add(woProcStr);
		msgParms.add(acctStr);
		msgParms.add(saStr);
		msgParms.add(carID);
		
		/* Message ID */
		Message_Id msgID = CustomMessageRepositoryMGE.sa336941AcctSaFailedCriteria1(woProcStr, acctStr, saStr, carID).getMessageId();
		
		/* Create list of sort keys */
		List<String> collSortKeyValues = new ArrayList<String>();
		collSortKeyValues.add(acctStr);
		collSortKeyValues.add(saStr);
		
		/* Create list of drill keys */
		List<String> collDrillKeyValues = new ArrayList<String>();
		collDrillKeyValues.add(woProcStr);
		
		/* Create a To Do Entry */
		createToDo(collSortKeyValues, collDrillKeyValues, msgID, msgParms);		
	}
	
	private void createToDo(List<String> collSortKeyValues, List<String> collDrillKeyValues,
			Message_Id msgID, List<String> msgParms) {

		ToDoType_Id tdTypeID = wToDoTypeRole.fetchIdToDoType().getId();		

		ToDoCreator tdCreator = ToDoCreator.Factory.newInstance();
		ToDoEntry_DTO tdEntryDTO = tdCreator.getToDoDTO();
		tdEntryDTO.setCreationDateTime(this.getProcessDateTime());
		tdEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
		tdEntryDTO.setToDoTypeId(tdTypeID);
		tdEntryDTO.setToDoRoleId(wToDoTypeRole.fetchIdToDoRole().getId());		
		tdEntryDTO.setMessageId(msgID);
		tdCreator.setToDoDTO(tdEntryDTO);
		
		//---------set message parameter---------//		
		for (int x = 0; x < msgParms.size(); x++) {
			tdCreator.addMessageParameter(msgParms.get(x));
		}

		List<ToDoSortKeyType> collOfSortKeyTypes = getSortKeyTypes(tdTypeID);

		for (int x = 0; x < collOfSortKeyTypes.size(); x++) {
			ToDoSortKeyType tdSortKeyType = collOfSortKeyTypes.get(x);
			tdCreator.addSortKeyValue(tdSortKeyType, collSortKeyValues.get(x));
		}

		List<ToDoDrillKeyType> collOfDrillKeyTypes = getDrillKeyTypes(tdTypeID);

		for (int x = 0; x < collOfDrillKeyTypes.size(); x++) {
			ToDoDrillKeyType tdDrillKeyType = collOfDrillKeyTypes.get(x);
			tdCreator.addDrillKeyValue(tdDrillKeyType, collDrillKeyValues.get(x));				
		}

		@SuppressWarnings("unused")
		ToDoEntry tdEntry = tdCreator.create();			
	}
	
	private List<ToDoSortKeyType> getSortKeyTypes(ToDoType_Id tdTypeID) {
		
		List<ToDoSortKeyType> returnValue = new ArrayList<ToDoSortKeyType>();
		
		StringBuilder stringBuilder = new StringBuilder();					
		stringBuilder.append("SELECT TD_TYPE_CD, SEQ_NUM ");
		stringBuilder.append("FROM CI_TD_SRTKEY_TY ");
		stringBuilder.append("WHERE TD_TYPE_CD = :tdTypeID ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=GET TO DO TYPE SORT KEYS");
		prepState.bindId("tdTypeID", tdTypeID);
		prepState.setAutoclose(false);
		prepState.execute();
		
		if (prepState.list().size() > 0) {			
			Iterator<SQLResultRow> iter = prepState.list().iterator();			
			while (iter.hasNext()) {			
				SQLResultRow sqlRow = (SQLResultRow) iter.next();					
				BigInteger seq = (BigInteger) sqlRow.getInteger("SEQ_NUM");
				ToDoSortKeyType_Id tdSortKeyTypeID = new ToDoSortKeyType_Id(tdTypeID, seq);
				returnValue.add(tdSortKeyTypeID.getEntity());
			}								
		}			
		prepState.close();
		return returnValue;
	}
	
	private List<ToDoDrillKeyType> getDrillKeyTypes(ToDoType_Id tdTypeID) {
		
		List<ToDoDrillKeyType> returnValue = new ArrayList<ToDoDrillKeyType>();
		
		StringBuilder stringBuilder = new StringBuilder();					
		stringBuilder.append("SELECT TD_TYPE_CD, SEQ_NUM ");
		stringBuilder.append("FROM CI_TD_DRLKEY_TY ");
		stringBuilder.append("WHERE TD_TYPE_CD = :tdTypeID ");
		
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "=GET TO DO TYPE DRILL KEYS=");
		prepState.bindId("tdTypeID", tdTypeID);
		prepState.setAutoclose(false);
		prepState.execute();
		
		if (prepState.list().size() > 0) {			
			Iterator<SQLResultRow> iter = prepState.list().iterator();			
			while (iter.hasNext()) {			
				SQLResultRow sqlRow = (SQLResultRow) iter.next();
				BigInteger seq = (BigInteger) sqlRow.getInteger("SEQ_NUM");
				ToDoDrillKeyType_Id tdDrillKeyTypeID = new ToDoDrillKeyType_Id(tdTypeID, seq);
				returnValue.add(tdDrillKeyTypeID.getEntity());
			}								
		}			
		prepState.close();
		return returnValue;		
	}
	
	private void performWriteOffCancellation() {
		
		cancelOtherWriteOffEvents(hpWOEvent);
		cancelWriteOffProcess(wWOProcess);
	}
	
	private void cancelOtherWriteOffEvents(WriteOffEvent woEvt) {
		
		StringBuilder stringBuilder = new StringBuilder();
		
		stringBuilder.append("SELECT WO_PROC_ID, EVT_SEQ ");
		stringBuilder.append("FROM CI_WO_EVT ");
		stringBuilder.append("WHERE WO_PROC_ID = :woProcID ");
		stringBuilder.append("AND WO_EVT_STAT_FLG = :pending ");
		stringBuilder.append("AND EVT_SEQ > :woEvtSeq ");
				
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==cancelOtherWriteOffEvents==");
		prepState.setAutoclose(false);
		prepState.bindId("woProcID", woEvt.fetchIdWriteOffProcess().getId());
		prepState.bindLookup("pending", WriteOffEventStatusLookup.constants.PENDING);
		prepState.bindBigInteger("woEvtSeq", woEvt.fetchIdEventSequence());
		prepState.execute();
		
		if (prepState.list().size() > 0) {
			
			Iterator<SQLResultRow> iter = prepState.list().iterator();
			while (iter.hasNext()) {
				
				SQLResultRow sqlRow = iter.next();
				BigInteger woEvtSeq = (BigInteger) sqlRow.getInteger("EVT_SEQ");
				
				WriteOffEvent_Id woEvtIDToCancel = new WriteOffEvent_Id(woEvt.fetchIdWriteOffProcess(), woEvtSeq);
				WriteOffEvent woEvtToCancel = woEvtIDToCancel.getEntity();
				updateWriteOffEventStatus(woEvtToCancel, wProcessDate, WriteOffEventStatusLookup.constants.CANCELED);
			}
		}
		prepState.close();				
	}
	
	private void updateWriteOffEventStatus(WriteOffEvent woEvt, 
			Date completionDate,
			WriteOffEventStatusLookup woEvtStatus) {
		startChanges();
		WriteOffEvent_DTO woEvtDTO = woEvt.getDTO();
		woEvtDTO.setWriteOffEventStatus(woEvtStatus);
		woEvtDTO.setCompletionDate(completionDate);
		woEvt.setDTO(woEvtDTO);
		saveChanges();
	}
	
	private void cancelWriteOffProcess(WriteOffProcess woProc) {
		
		String comments = woProc.getComments().trim();
		comments = comments.concat("\n").concat(
				CustomMessageRepositoryMGE.sa336941AcctSaFailedCriteria1(wWOProcess.getId().getTrimmedValue(),
				wAcctStr, wSaStr, wCollAgencyReferralStr).getMessageText().trim());
		startChanges();
		WriteOffProcess_DTO woProcDTO = woProc.getDTO();
		woProcDTO.setWriteOffStatusReason(WriteOffStatusReasonLookup.constants.CANCELEDBY_SYSTEM);
		woProcDTO.setWriteOffStatus(WriteOffStatusLookup.constants.INACTIVE);
		woProcDTO.setComments(comments);
		woProc.setDTO(woProcDTO);
		saveChanges();
		/* **************************************************************************************/
		/* The Write Off Status will be overridden by the Framework and will be set to COMPLETE */
		/* this is base functionality of WET batch. If there are no errors and the all there are*/
		/* no pending write off events anymore on the write off template, then base batch will  */
		/* update their status reason to COMPLETE.                                              */
		/* **************************************************************************************/
	}
}
