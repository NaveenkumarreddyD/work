/*                                                              
 *******************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Characteristic Info Extract Record                                                               
 *                                                                
 *******************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:       by:         Reason:                                                                                                   
 *                          
 * 2020-04-01  JHERNA      SA-322461. Initial version                 
 *                                                                
 *******************************************************************************
 */

package com.splwg.cm.api.batch.generalLetters;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

public class CmGeneralLetterOtherCharacteristicInfoExtractRecord extends ColumnDelimitedRecord {
    
    // Mailing Information
    private static final String CHAR_PRINT_KEY = "1170";
    private static final String MAIL_GRP = "20";
    private static final String BLANK = "  ";
    private static final String EMPTY_STR = "";
    
    public CmGeneralLetterOtherCharacteristicInfoExtractRecord() {
        super(13);
        defaultPrintKey();
    }

    /* EXTRACT COMMON SECTIONS */
    private void defaultPrintKey() {
        this.rightPadColumn(1, 4, formatString(CHAR_PRINT_KEY, 4));
    }
    
    public void setSortKeyLetterTemplateCode(String letterTemplateCode) {
        this.rightPadColumn(2, 12, formatString(letterTemplateCode, 12));
    }
    
    public void setSortKeyCcId(String ccId) {
        this.rightPadColumn(3, 10, formatString(ccId, 10));
        setSortKeyCcRecordGroup();
        setSortKeyCAndCRecordGroup();
    }
    
    private void setSortKeyCcRecordGroup() {
        this.rightPadColumn(4, 2, MAIL_GRP);
    }
    
    private void setSortKeyCAndCRecordGroup() {
        this.rightPadColumn(5, 2, BLANK);
    }
    
    public void setMailingKey(String mailingKey) {
        this.rightPadColumn(6, 12, formatString(mailingKey, 12));
        setFiller3Spaces();
    }
    
    private void setFiller3Spaces() {
        this.rightPadColumn(7, 3, " ");
    }
    
    /* EXTRACT DETAILS SECTION */
    public void setCharTypeCd(String charTypeCd) {
    	this.rightPadColumn(8, 8, formatString(charTypeCd, 8));    	
    }    

    public void setCharTypeDescr(String charTypeDescr) {
    	this.rightPadColumn(9, 60, formatString(charTypeDescr, 60));    	
    } 
    
    public void setCharVal(String charVal) {
    	this.rightPadColumn(10, 16, formatString(charVal, 16));    	
    } 
    
    public void setCharValDescr(String charValDescr) {
    	this.rightPadColumn(11, 60, formatString(charValDescr, 60));    	
    } 
    
    public void setAdhocCharVal(String adhocCharVal) {
    	this.rightPadColumn(12, 254, formatString(adhocCharVal, 254));    	
    	setFillerEndSpaces();
    } 
        
    private void setFillerEndSpaces() {
        this.rightPadColumn(13, 1569, BLANK);
    }
    
    /**
     * Returns "" if text is null;
     * Truncates text if length exceed fieldLength;
     * @param text String variable to be formatted
     * @param fieldLength Length of Field
     * @return formatted text
     */
    private String formatString(String text, int fieldLength) {
        if(text == null) {
            text = EMPTY_STR;
        }
        else {
            text = text.trim();
            if(text.length() > fieldLength) {
                text = text.substring(0, fieldLength);
            }
        }
        return text;
    }
}
