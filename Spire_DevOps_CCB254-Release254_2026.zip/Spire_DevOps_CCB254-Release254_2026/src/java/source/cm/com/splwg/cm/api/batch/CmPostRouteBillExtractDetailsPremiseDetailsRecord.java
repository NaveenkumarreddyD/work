/* ************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:
 * 
 * Column Delimited Record class for Custom Postal Route Bill Extract
 * 
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:        Reason:
 * 2017-03-03	JHERNA	   Initial Version.
 * 2024-07-30   DLampa     INC0037039. Updated field lengths to match 
 *                         the file layout extracted by the CM-BILEXTR 
 *                         algorithm 
 * 
 *************************************************************************/
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;
import com.splwg.shared.common.StringUtilities;

public class CmPostRouteBillExtractDetailsPremiseDetailsRecord 
		extends ColumnDelimitedRecord{	
	/*
	 * Constructor
	 */
	public CmPostRouteBillExtractDetailsPremiseDetailsRecord() {
		super(20);
		this.setBPPrinterKey(" ");		
		this.setBPSortKey(" ");
		this.setBPMailingKey(" ");	
		this.setNonePremiseSw(" ");
		this.setPremiseId(" ");
		this.setCountry(" ");
		this.setAddress1(" ");
		this.setAddress2(" ");
		this.setAddress3(" ");
		this.setAddress4(" ");
		this.setCity(" ");
		this.setNum1(" ");
		this.setNum2(" ");
		this.setHouseType(" ");
		this.setCounty(" ");
		this.setState(" ");
		this.setPostal(" ");
		this.setGeoCode(" ");
		this.setInCityLimit(" ");
		this.setFiller();
	}
	private String truncateInput(String value, int maxLength) {

		String returnValue = value;
		if (StringUtilities.notEmptyOrBlank(returnValue)) {
			if (returnValue.length() > maxLength) {
				returnValue = returnValue.substring(0, maxLength);
			}
		}
		return returnValue;
	}
	/*
	 * 
	 */
	public void setBPPrinterKey(String value) {		
		rightPadColumn(1, 4, truncateInput(value, 4));
	}
	public void setBPSortKey(String value) {
		rightPadColumn(2, 184, truncateInput(value, 184));
	}
	public void setBPMailingKey(String value) {
		rightPadColumn(3, 15, truncateInput(value, 15));
	}	
	/*
	 * Premise (List)
	 */
	public void setNonePremiseSw(String value) {
		rightPadColumn(4, 1, truncateInput(value, 1));
	}
	public void setPremiseId(String value) {
		rightPadColumn(5, 10, truncateInput(value, 10));
	}
	// START CICZADDD.
	public void setCountry(String value) {
		rightPadColumn(6, 3, truncateInput(value, 3));
	}
	public void setAddress1(String value) {
		rightPadColumn(7, 254, truncateInput(value, 254));
	}
	public void setAddress2(String value) {
		rightPadColumn(8, 254, truncateInput(value, 254));
	}
	public void setAddress3(String value) {
		rightPadColumn(9, 254, truncateInput(value, 254));
	}
	public void setAddress4(String value) {
		rightPadColumn(10, 254, truncateInput(value, 254));
	}
	public void setCity(String value) {
		/*For some reason OLD version has this field to be only 30 characters long; We are going to follow this instead of using base field length of 90*/
		//rightPadColumn(11, 90, truncateInput(value, 90));
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(11, 30, truncateInput(value, 30));
		rightPadColumn(11, 90, truncateInput(value, 90));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setNum1(String value) {
		rightPadColumn(12, 6, truncateInput(value, 6));
	}
	public void setNum2(String value) {
		rightPadColumn(13, 4, truncateInput(value, 4));
	}
	public void setHouseType(String value) {
		rightPadColumn(14, 2, truncateInput(value, 2));
	}
	public void setCounty(String value) {
		/*For some reason OLD version has this field to be only 30 characters long; We are going to follow this instead of using base field length of 90*/
		//rightPadColumn(15, 90, truncateInput(value, 90));
		// Start Change - DLampa - 2024-07-30 - INC0037039
		//rightPadColumn(15, 30, truncateInput(value, 30));
		rightPadColumn(15, 90, truncateInput(value, 90));
		// End Change - DLampa - 2024-07-30 - INC0037039
	}
	public void setState(String value) {
		rightPadColumn(16, 6, truncateInput(value, 6));
	}
	public void setPostal(String value) {
		rightPadColumn(17, 12, truncateInput(value, 12));
	}
	public void setGeoCode(String value) {
		rightPadColumn(18, 11, truncateInput(value, 11));
	}
	public void setInCityLimit(String value) {
		rightPadColumn(19, 1, truncateInput(value, 1));
	}
	// END CICZADDD.
	public void setFiller() {
		/*For some reason OLD version has this field to be only 2109 characters long; We are going to follow this instead of using base field length of 2192*/
		//rightPadColumn(20, 2192, " ");
		rightPadColumn(20, 2109, " ");		
	}
}
