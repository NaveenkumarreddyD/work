/**************************************************************************
* Program Name: CmThreeStepUsingAveragedDegreeDaysEstimationAlgComp_Impl
* Program Title: CmThreeStepUsingAveragedDegreeDaysEstimationAlgComp_Impl
* Author: Beverly Marquez
* Creation Date: 2017-10-24
* Purpose: This algorithm will calculate estimates using the same approach 
*          as the three-step algorithm. Once the estimate is calculated, 
*          it will compare the current period's degree days to an average
*          of the historic estimate period's degree days and adjust the 
*          estimate accordingly. 
*  
* Functional Spec: MGE-CCB019-Estimation
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 * SA-115715-A        Beverly Marquez  2017-10-24    Initial Version
 * Defect 4253862/    El Quinto        2019-05-22	 set prepared statement auto close 
 * ID56 (Reopen)                                                                                           
 ************************************************************************************************/

package com.splwg.cm.domain.admin.trendArea.algorithm.meterReadEstimation;

import java.math.BigInteger;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.cm.api.lookup.ExternalSystemTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmTrendBasedEstimation;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOptionInfo;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOptionsCache;
import com.splwg.base.domain.database.field.Field_Id;
import com.splwg.ccb.api.lookup.ConsumptionTypeLookup;
import com.splwg.ccb.api.lookup.EstimateAlgorithmLookup;
import com.splwg.ccb.api.lookup.MeterManagementOptionTypeLookup;
import com.splwg.ccb.domain.admin.degreeDay.entity.DegreeDay;
import com.splwg.ccb.domain.admin.degreeDay.entity.DegreeDay_Id;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse;
import com.splwg.ccb.domain.admin.trendArea.algorithm.meterReadEstimation.MeterReadEstimationAlgorithmSpot;
import com.splwg.ccb.domain.admin.trendArea.entity.TrendArea;
import com.splwg.ccb.domain.admin.trendClass.entity.TrendClass;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.meterread.common.EstimationCommonDataRetriever;
import com.splwg.ccb.domain.meterread.common.MeterReadEstimationUsingLastYearBillSegment;
import com.splwg.ccb.domain.meterread.common.MeterReadEstimationUsingPreviousBillSegment;
import com.splwg.ccb.domain.meterread.common.NegativeConsumptionOptionRetriever;
import com.splwg.ccb.domain.meterread.data.EstimationCommonData;
import com.splwg.ccb.domain.meterread.data.MeterReadEstimationUsingBillSegmentData;
import com.splwg.ccb.domain.meterread.data.NegativeConsumptionCheckData;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.MeterConfiguration;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.servicePointMeterHistory.entity.ServicePointMeterHistory;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = minimumDaysBetweenReads, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = daysSufficientforEstimation, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = degreeDayFactor, required = true, type = decimal)})
 */
public class CmThreeStepUsingAveragedDegreeDaysEstimationAlgComp_Impl extends
        CmThreeStepUsingAveragedDegreeDaysEstimationAlgComp_Gen implements
        MeterReadEstimationAlgorithmSpot {

    // Input hard parameters
    private String estimateType;
    private DateTime readDateTime;
    private Register register;
    private ServicePoint servicePoint;
    private ServiceAgreement serviceAgreement;
    
    // Input/Output hard parameters
    private ConsumptionTypeLookup consumptionType;
    private Bool measuresPeakQuantity;
    private BigInteger numberOfDigitsLeft;
    private BigInteger numberOfDigitsRight;
    private BigInteger numberOfReads;
    private BigDecimal registerConstant;
    private BigDecimal registerReading;
    private TimeOfUse timeOfUse;
    private TrendArea trendArea;
    private TrendClass trendClass;
    private UnitOfMeasure unitOfMeasure;
    
    // Output hard parameters
    private EstimateAlgorithmLookup estimateAlgorithm;
    private BigDecimal estimatedRawUsage;
    private BigDecimal estimatedRegisterReading;
    private Bool isEstimateImpossible;
    private DateTime latestReadDateTime;
    private BigDecimal latestRegisterReading;
    
    // Estimation Common Data
    private Account account;
    private Account_Id accountId;
    private Date startDate;
    private Date endDate;
    private Date midPeriodDateLastYear;
    
    // Soft parameters
    private BigInteger minimumDaysBetweenReads;
    private BigInteger daysSufficientforEstimation;
    private BigDecimal degreeDayFactor;
    
    // Debug logger
    private Logger logger = LoggerFactory.getLogger(getClass());
    
    // Constants
    private static final String EST_TYPE_EST_AND_HI_LOW = "EST&HILOW"; // based on CICMEST8
    
    @Override
    public void setConsumptionType(ConsumptionTypeLookup consumptionType) {
        this.consumptionType = consumptionType;
    }

    @Override
    public void setEstimationType(String estimationType) {
        estimateType = estimationType;
    }

    @Override
    public void setMeasuresPeakQuantity(Bool measuresPeakQuantity) {
        this.measuresPeakQuantity = measuresPeakQuantity;
    }

    @Override
    public void setNumberOfDigitsLeft(BigInteger numberOfDigitsLeft) {
        this.numberOfDigitsLeft = numberOfDigitsLeft;
    }

    @Override
    public void setNumberOfDigitsRight(BigInteger numberOfDigitsRight) {
        this.numberOfDigitsRight = numberOfDigitsRight;
    }

    @Override
    public void setNumberOfReads(BigInteger numberOfReads) {
        this.numberOfReads = numberOfReads;
    }

    @Override
    public void setReadDateTime(DateTime readDateTime) {
        this.readDateTime = readDateTime;
    }

    @Override
    public void setRegister(Register register) {
        this.register = register;
    }

    @Override
    public void setRegisterConstant(BigDecimal registerConstant) {
        this.registerConstant = registerConstant;
    }

    @Override
    public void setRegisterReading(BigDecimal registerReading) {
        this.registerReading = registerReading;
    }

    @Override
    public void setServiceAgreement(ServiceAgreement serviceAgreement) {
        this.serviceAgreement = serviceAgreement;
    }

    @Override
    public void setServicePoint(ServicePoint servicePoint) {
        this.servicePoint = servicePoint;
    }

    @Override
    public void setTimeOfUse(TimeOfUse timeOfUse) {
        this.timeOfUse = timeOfUse;
    }

    @Override
    public void setTrendArea(TrendArea trendArea) {
        this.trendArea = trendArea;
    }

    @Override
    public void setTrendClass(TrendClass trendClass) {
        this.trendClass = trendClass;
    }

    @Override
    public void setUnitOfMeasure(UnitOfMeasure unitOfMeasure) {
        this.unitOfMeasure = unitOfMeasure;
    }
    
    @Override
    public ConsumptionTypeLookup getConsumptionTypeLookup() {
        return consumptionType;
    }

    @Override
    public EstimateAlgorithmLookup getEstimateAlgorithm() {
        return estimateAlgorithm;
    }

    @Override
    public BigDecimal getEstimatedRawUsage() {
        return estimatedRawUsage;
    }

    @Override
    public BigDecimal getEstimatedRegisterReading() {
        return estimatedRegisterReading;
    }

    @Override
    public Bool getIsEstimateImpossible() {
        return isEstimateImpossible;
    }

    @Override
    public DateTime getLatestReadDateTime() {
        return latestReadDateTime;
    }

    @Override
    public BigDecimal getLatestRegisterReading() {
        return latestRegisterReading;
    }

    @Override
    public Bool getMeasuresPeakQuantity() {
        return measuresPeakQuantity;
    }

    @Override
    public BigInteger getNumberOfDigitsLeft() {
        return numberOfDigitsLeft;
    }

    @Override
    public BigInteger getNumberOfDigitsRight() {
        return numberOfDigitsRight;
    }

    @Override
    public BigInteger getNumberOfReads() {
        return numberOfReads;
    }

    @Override
    public BigDecimal getRegisterConstant() {
        return registerConstant;
    }

    @Override
    public BigDecimal getRegisterReading() {
        return registerReading;
    }

    @Override
    public TimeOfUse getTimeOfUse() {
        return timeOfUse;
    }

    @Override
    public TrendArea getTrendArea() {
        return trendArea;
    }

    @Override
    public TrendClass getTrendClass() {
        return trendClass;
    }

    @Override
    public UnitOfMeasure getUnitOfMeasure() {
        return unitOfMeasure;
    }

    @Override
    public void invoke() {

        // Initialize program
        initialize();
        
        // Validate Input
        checkInput();
        
        // Perform Process
        performProc();
        
    }
    
    /**
     * CA000-INITIALIZE
     * Initialize program
     */
    private void initialize() {
        
        isEstimateImpossible = Bool.FALSE;
        
    }
    
    /**
     * EA000-CHECK-INPUT
     * Validate input
     */
    private void checkInput() {
        
        // Register ID is required
        if (isNull(register)) {
            addError(CustomMessageRepository.SA_115715A_FieldMissing(new Field_Id("REG_ID")));
        }
        
        /*
         * Retrieve feature option for meter management that indicates if same UOM/TOU value 
         * combination is allowed.
         */
        FeatureConfigurationOptionInfo featureConfigurationOptionInfo = FeatureConfigurationOptionsCache.getHighestSequenceOptionFor(ExternalSystemTypeLookup.constants.METER_MANAGEMENT_OPTIONS, MeterManagementOptionTypeLookup.constants.ALLOW_DUPLICATE_UOM_TOU);
        if (notNull(featureConfigurationOptionInfo)) {
            if ("Y".equals(featureConfigurationOptionInfo.getValue().trim())) {
                
                /*
                 * If the value of the Allow Same UOM/TOU combination is Yes then this estimation 
                 * routine should not be used.
                 */
                if (getCountOfDuplicateRegisters(register).intValue() > 0) {
                    addError(CustomMessageRepository.SA_115715A_BaseEstimationNotAllowed());
                }
                
            }
        }

        // SP ID is required
        if (isNull(servicePoint)) {
            addError(CustomMessageRepository.SA_115715A_FieldMissing(new Field_Id("SP_ID")));
        }
        
        // Read Date/Time is required
        if (isNull(readDateTime)) {
            addError(CustomMessageRepository.SA_115715A_FieldMissing(new Field_Id("READ_DTTM")));
        }
        
        // See extraSoftParameterValidations for Soft Parameter validation
        
    }
    
    /**
     * XQ010-COUNT-DUPL-UOM-TOU
     * ZS100-SETUP-SQL-S-DUPL
     * Count duplicate UOM and TOU Combination
     * @param register
     */
    private BigInteger getCountOfDuplicateRegisters(Register register) {
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT COUNT(*) C ");
        stringBuilder.append("FROM CI_REG REG ");
        stringBuilder.append("WHERE REG.REG_ID <> :register ");
        stringBuilder.append("AND REG.UOM_CD = :unitOfMeasure ");
        stringBuilder.append("AND REG.TOU_CD = " + ((isNull(register.fetchTimeOfUse())) ? "' ' " : ":timeOfUse "));
        stringBuilder.append("AND REG.MTR_ID = :meterConfiguration ");
        stringBuilder.append("AND REG.EFF_DTTM = :effectiveDateTime ");
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        preparedStatement.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        preparedStatement.bindId("register", register.getId());
        preparedStatement.bindId("unitOfMeasure", register.getUnitOfMeasure().getId());
        if (notNull(register.fetchTimeOfUse())) {
            preparedStatement.bindId("timeOfUse", register.getTimeOfUseId());
        }
        preparedStatement.bindId("meterConfiguration", register.getMeterConfiguration().getMeter().getId());
        preparedStatement.bindDateTime("effectiveDateTime", register.getMeterConfiguration().getEffectiveDateTime());
        
        preparedStatement.execute();
        SQLResultRow sqlResultRow = preparedStatement.firstRow();
        preparedStatement.close();

        return (isNull(sqlResultRow)) ? BigInteger.ZERO : sqlResultRow.getInteger("C");
        
    }
    
    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        
        /*
         * Minimum Days Between Reads must be between 0 and 999.
         */
        minimumDaysBetweenReads = getMinimumDaysBetweenReads();
        if (minimumDaysBetweenReads.compareTo(BigInteger.ZERO) < 0
                || minimumDaysBetweenReads.compareTo(BigInteger.valueOf(999)) > 0) {
            addError(CustomMessageRepository.SA_115715A_MinimumIntervalInvalid(minimumDaysBetweenReads));
        }
        
        /*
         * Days Sufficient For Estimation must be between 0 and 999.
         */
        daysSufficientforEstimation = getDaysSufficientforEstimation();
        if (daysSufficientforEstimation.compareTo(BigInteger.ZERO) < 0
                || daysSufficientforEstimation.compareTo(BigInteger.valueOf(999)) > 0) {
            addError(CustomMessageRepository.SA_115715A_DaysSufficientInvalid(daysSufficientforEstimation));
        }
        
        /*
         * Degree Days Factor must be greater than or equal to 0
         */
        degreeDayFactor = getDegreeDayFactor();
        if (degreeDayFactor.compareTo(BigDecimal.ZERO) < 0) {
            addError(CustomMessageRepository.SA_115715A_DegreeDayFactorInvalid(degreeDayFactor));
        }
        
        super.extraSoftParameterValidations(forAlgorithmValidation);
        
    }
    
    /**
     * GA000-PERFORM-PROC
     * Perform Process.
     */
    private void performProc() {
        
        // Estimation not allowed for Negative Consumption Metering
        if (checkForNegativeConsumptionOption().isTrue()) {
            isEstimateImpossible = Bool.TRUE;
            // Error msg only if estimate requested (not just hi-lo)
            if (EST_TYPE_EST_AND_HI_LOW.equals(estimateType)) {
                addError(CustomMessageRepository.SA_115715A_NegativeConsumption());
            }
            return;
        }
        
        /*
         * Prepare Common Data:
         * - Get Account ID using SA or SP;
         * - Get Mid Period Date of Billing Period; and
         * - Get Billing Start Date.
         */
        prepareCommonData();
        
        determineEligibility();
        
        estimateRegister();
        
        finalProcessing();
        
        logDebug(logger, "*** FINAL ESTIMATION RESULTS ***");
        logDebug(logger, "Latest Register Reading  : " + getLatestRegisterReading());
        logDebug(logger, "Latest Read Date Time    : " + getLatestReadDateTime());
        logDebug(logger, "Estimate Impossible      : " + getIsEstimateImpossible());
        logDebug(logger, "Estimated Raw Usage      : " + getEstimatedRawUsage());
        logDebug(logger, "Estimated Register Read  : " + getEstimatedRegisterReading());
        
    }
    
    /**
     * MA010-CHECK-FOR-NEG-CONS-OPTN
     * Check for Meter Management Options, and Meter Type and SP characteristics that indicate that
     * Negative Consumption metering is allowed for this meter/sp. If allowed, estimation is not 
     * allowed.
     * @return Bool.TRUE if Negative Consumption is allowed on Meter/SP
     */
    private Bool checkForNegativeConsumptionOption() {
        
        NegativeConsumptionCheckData negativeConsumptionCheckData = NegativeConsumptionCheckData.Factory.newInstance();
        negativeConsumptionCheckData.setServicePoint(servicePoint);
        negativeConsumptionCheckData.setRegister(register);
        negativeConsumptionCheckData.setReadDateTime(readDateTime);
        
        return NegativeConsumptionOptionRetriever.Factory.newInstance().checkNegativeConsumptionAllowed(register, negativeConsumptionCheckData).getIsNegativeConsumptionAllowed();
        
    }

    /**
     * MA030-PREPARE-COMMON-DATA
     * XC010-GET-COMMON-DATA
     * Prepare Common Data for Processing
     */
    private void prepareCommonData() {
        EstimationCommonData estimationCommonData = EstimationCommonData.Factory.newInstance();
        estimationCommonData.setServicePoint(servicePoint);
        estimationCommonData.setRegister(register);
        estimationCommonData.setReadDateTime(readDateTime);
        estimationCommonData.setServiceAgreement(serviceAgreement);
        estimationCommonData.setUnitOfMeasure(unitOfMeasure);
        estimationCommonData.setTimeOfUse(timeOfUse);
        
        estimationCommonData = EstimationCommonDataRetriever.Factory.newInstance().retrieveEstimationCommonData(estimationCommonData);
        
        accountId = estimationCommonData.getAcctId();
        startDate = estimationCommonData.getStartDate();
        endDate = estimationCommonData.getEndDate();
        midPeriodDateLastYear = estimationCommonData.getMidPeriodDateLastYear();
        latestRegisterReading = estimationCommonData.getLatestRegisterReading();
        latestReadDateTime = estimationCommonData.getLatestReadDateTime();
    }

    /**
     * MA040-DETER-ELIG
     * Determine Eligibility
     */
    private void determineEligibility() {
        if (isNull(accountId)) {
            isEstimateImpossible = Bool.TRUE;
            return;
        }
        account = accountId.getEntity();
    }
  
    /**
     * MA000-EST-REG
     * Perform Estimation
     */
    private void estimateRegister() {
        /*
         * Call relevant estimate method Regular or TOU.
         */
        if (isEstimateImpossible.isTrue()) {
            return;
            
        } else if (notNull(unitOfMeasure) && notNull(trendArea)) {
            
            // When Trend Area is not available, a budget is being recommended. Skip to base estimation
            
            /*
             * SA-115715-A - 2017-10-24 - Start Add
             */
            boolean isEstimateFromLastYearBillSegment = true;
            /*
             * SA-115715-A - 2017-10-24 - End Add
             */
            
            registerEstimationFromLastYear();
            
            if (isEstimateImpossible.isTrue()) {
                
                isEstimateImpossible = Bool.FALSE;
                registerEstimationFromPreviousMonth();
                
                /*
                 * SA-115715-A - 2017-10-24 - Start Add
                 */
                isEstimateFromLastYearBillSegment = false;
                /*
                 * SA-115715-A - 2017-10-24 - End Add
                 */
                
            }
            
            /*
             * SA-115715-A - 2017-10-24 - Start Add
             */
            if (isEstimateImpossible.isFalse()) {
                applyDegreeDayAdjustment(isEstimateFromLastYearBillSegment);
            }
            /*
             * SA-115715-A - 2017-10-24 - End Add 
             */
            
        } else {
            isEstimateImpossible = Bool.TRUE;
        }
        
        if (isEstimateImpossible.isTrue()) {
            baseEstimation();
        }
        
    }
    
    /**
     * XC110-REG-EST-LASTYR
     * Estimation Using Last Year's Bill Segment Routine
     */
    private void registerEstimationFromLastYear() {
        
        MeterReadEstimationUsingBillSegmentData meterReadEstimationUsingLastYearBillSegmentData = composeMeterReadEstimationUsingBillSegmentData();
        
        meterReadEstimationUsingLastYearBillSegmentData = MeterReadEstimationUsingLastYearBillSegment.Factory.newInstance().retrieve(servicePoint, meterReadEstimationUsingLastYearBillSegmentData);
        
        latestRegisterReading = meterReadEstimationUsingLastYearBillSegmentData.getLatestRegisterReading();
        latestReadDateTime = meterReadEstimationUsingLastYearBillSegmentData.getLatestReadDateTime();
        estimatedRawUsage = meterReadEstimationUsingLastYearBillSegmentData.getEstimatedRawUsage();
        estimatedRegisterReading = meterReadEstimationUsingLastYearBillSegmentData.getEstimatedRegisterReading();
        isEstimateImpossible = meterReadEstimationUsingLastYearBillSegmentData.getIsEstimateImpossible();
        
        logDebug(logger, "***Meter Read Estimation Using Last Year Bill Segment***");
        logDebug(logger, "latestRegisterReading   : " + latestRegisterReading);
        logDebug(logger, "latestReadDateTime      : " + latestReadDateTime);
        logDebug(logger, "estimatedRawUsage       : " + estimatedRawUsage);
        logDebug(logger, "estimatedRegisterReading: " + estimatedRegisterReading);
        logDebug(logger, "isEstimateImpossible    : " + isEstimateImpossible);
        
    }
    
    /**
     * XC120-REG-EST-PREV
     */
    private void registerEstimationFromPreviousMonth() {
        
        MeterReadEstimationUsingBillSegmentData meterReadEstimationUsingPreviousBillSegmentData = composeMeterReadEstimationUsingBillSegmentData();
        
        meterReadEstimationUsingPreviousBillSegmentData = MeterReadEstimationUsingPreviousBillSegment.Factory.newInstance().retrieve(servicePoint, meterReadEstimationUsingPreviousBillSegmentData);
        
        latestRegisterReading = meterReadEstimationUsingPreviousBillSegmentData.getLatestRegisterReading();
        latestReadDateTime = meterReadEstimationUsingPreviousBillSegmentData.getLatestReadDateTime();
        estimatedRawUsage = meterReadEstimationUsingPreviousBillSegmentData.getEstimatedRawUsage();
        estimatedRegisterReading = meterReadEstimationUsingPreviousBillSegmentData.getEstimatedRegisterReading();
        isEstimateImpossible = meterReadEstimationUsingPreviousBillSegmentData.getIsEstimateImpossible();
        
        logDebug(logger, "***Meter Read Estimation Using Previous Bill Segment***");
        logDebug(logger, "latestRegisterReading   : " + latestRegisterReading);
        logDebug(logger, "latestReadDateTime      : " + latestReadDateTime);
        logDebug(logger, "estimatedRawUsage       : " + estimatedRawUsage);
        logDebug(logger, "estimatedRegisterReading: " + estimatedRegisterReading);
        logDebug(logger, "isEstimateImpossible    : " + isEstimateImpossible);
        
    }
    
    private MeterReadEstimationUsingBillSegmentData composeMeterReadEstimationUsingBillSegmentData() {
        
        MeterReadEstimationUsingBillSegmentData meterReadEstimationUsingBillSegmentData = MeterReadEstimationUsingBillSegmentData.Factory.newInstance();
        meterReadEstimationUsingBillSegmentData.setServicePoint(servicePoint);
        meterReadEstimationUsingBillSegmentData.setRegister(register);
        meterReadEstimationUsingBillSegmentData.setReadDateTime(readDateTime);
        meterReadEstimationUsingBillSegmentData.setServiceAgreement(serviceAgreement);
        meterReadEstimationUsingBillSegmentData.setUnitOfMeasure(unitOfMeasure);
        meterReadEstimationUsingBillSegmentData.setTimeOfUse(timeOfUse);
        meterReadEstimationUsingBillSegmentData.setRegisterConstant(registerConstant);
        meterReadEstimationUsingBillSegmentData.setConsumptionType(consumptionType);
        meterReadEstimationUsingBillSegmentData.setNumberOfDigitsLeft(numberOfDigitsLeft);
        meterReadEstimationUsingBillSegmentData.setNumberOfDigitsRight(numberOfDigitsRight);
        meterReadEstimationUsingBillSegmentData.setMeasuresPeakQuantity(measuresPeakQuantity);
        meterReadEstimationUsingBillSegmentData.setDaysSufficientForEstimation(daysSufficientforEstimation);
        meterReadEstimationUsingBillSegmentData.setAccount(account);
        meterReadEstimationUsingBillSegmentData.setStartDate(startDate);
        meterReadEstimationUsingBillSegmentData.setEndDate(endDate);
        meterReadEstimationUsingBillSegmentData.setMidPeriodDateLastYear(midPeriodDateLastYear);
        return meterReadEstimationUsingBillSegmentData;
        
    }

    /**
     * MA300-BASE-ESTIMATION
     * XC-140-BASE-ESTIMATION
     */
    private void baseEstimation() {
        
        /*
         * If there is no data last year or previous bill segment use any available trend data.
         */
        isEstimateImpossible = Bool.FALSE;

        // Call Java version of Trend Estimation
        CmTrendBasedEstimation cmTrendBasedEstimation = CmTrendBasedEstimation.Factory.newInstance();
        cmTrendBasedEstimation.setConsumptionType(consumptionType);
        cmTrendBasedEstimation.setEstimationType(estimateType);
        cmTrendBasedEstimation.setServicePoint(servicePoint);
        cmTrendBasedEstimation.setRegister(register);
        cmTrendBasedEstimation.setReadDateTime(readDateTime);
        cmTrendBasedEstimation.setServiceAgreement(serviceAgreement);
        cmTrendBasedEstimation.setUnitOfMeasure(unitOfMeasure);
        cmTrendBasedEstimation.setTimeOfUse(timeOfUse);
        cmTrendBasedEstimation.setRegisterConstant(registerConstant);
        cmTrendBasedEstimation.setNumberOfDigitsLeft(numberOfDigitsLeft);
        cmTrendBasedEstimation.setNumberOfDigitsRight(numberOfDigitsRight);
        cmTrendBasedEstimation.setNumberOfReads(numberOfReads);
        cmTrendBasedEstimation.setMeasuresPeakQuantity(measuresPeakQuantity);
        cmTrendBasedEstimation.setMinimumDaysBetweenReads(minimumDaysBetweenReads);
        cmTrendBasedEstimation.invoke();
        
        estimateAlgorithm = cmTrendBasedEstimation.getEstimateAlgorithm();
        latestRegisterReading = cmTrendBasedEstimation.getLatestRegisterReading();
        latestReadDateTime = cmTrendBasedEstimation.getLatestReadDateTime();
        estimatedRawUsage = cmTrendBasedEstimation.getEstimatedRawUsage();
        estimatedRegisterReading = cmTrendBasedEstimation.getEstimatedRegisterReading();
        isEstimateImpossible = cmTrendBasedEstimation.getIsEstimateImpossible();
        
        logDebug(logger, "***Meter Read Estimation Using Trend***");
        logDebug(logger, "latestRegisterReading   : " + latestRegisterReading);
        logDebug(logger, "latestReadDateTime      : " + latestReadDateTime);
        logDebug(logger, "estimatedRawUsage       : " + estimatedRawUsage);
        logDebug(logger, "estimatedRegisterReading: " + estimatedRegisterReading);
        logDebug(logger, "isEstimateImpossible    : " + isEstimateImpossible);
        
    }

    /**
     * MA900-FINAL-PROCESSING
     */
    private void finalProcessing() {
        if (isEstimateImpossible.isTrue()) {
            estimateAlgorithm = null;
            estimatedRawUsage = null;
            estimatedRegisterReading = null;
            isEstimateImpossible = Bool.TRUE;
            latestReadDateTime = null;
            latestRegisterReading = null;
        }
    }
    
    /*
     * SA-115715-A - 2017-10-24 - Start Add
     */
    /**
     * Calculate the estimation factor and apply the adjustment to the estimated usage. Compute
     * the new estimated register reading.
     * @param isEstimateFromLastYearBillSegment
     */
    private void applyDegreeDayAdjustment(boolean isEstimateFromLastYearBillSegment) {
        
        if (BigDecimal.ZERO.compareTo(degreeDayFactor) == 0) {
            return;
        }
        
        // Calculate Historical Degree Day Daily Average
        BigDecimal hdda = (isEstimateFromLastYearBillSegment) ? getHistoricDegreeDayDailyAverageFromLastYear() : getHistoricDegreeDayDailyAverageFromPrevious();
        
        // Calculate Current Degree Day Daily Average
        BigDecimal cdda = getCurrentDegreeDayDailyAverage();
        
        // Estimation Factor = 1 - ([(HDDA - CDDA) / HDDA] * Degree Day Factor)
        BigDecimal estimationFactor = BigDecimal.ONE.subtract(hdda.subtract(cdda).divide(hdda).multiply(degreeDayFactor));
        
        BigDecimal originalEstimatedRawUsage = estimatedRawUsage;
        
        // New Estimate = CC&B Estimate * Estimation Factor
        estimatedRawUsage = estimatedRawUsage.multiply(estimationFactor).setScale(numberOfDigitsRight.intValue(), BigDecimal.ROUND_HALF_UP);
        
        estimatedRegisterReading = computeRegisterReading(estimatedRegisterReading, estimatedRawUsage.subtract(originalEstimatedRawUsage));
        
        logDebug(logger, "***Apply Degree Day Adjustment***");
        logDebug(logger, "Historical Degree Day Daily Average: " + hdda);
        logDebug(logger, "Current Degree Day Daily Average   : " + cdda);
        logDebug(logger, "Degree Day Factor                  : " + degreeDayFactor);
        logDebug(logger, "Estimation Factor                  : " + estimationFactor);
        logDebug(logger, "Estimated Raw Usage                : " + estimatedRawUsage);
        logDebug(logger, "Raw Usage Difference               : " + estimatedRawUsage.subtract(originalEstimatedRawUsage));
        logDebug(logger, "Estimated Register Reading         : " + estimatedRegisterReading);
        
    }
    
    /**
     * Retrieve the degree days for the historic bill segment period and calculate the daily 
     * average. If the total Degree Days for the period add up to 0, assume the value of 1.
     * @return BigDecimal
     */
    private BigDecimal getHistoricDegreeDayDailyAverageFromLastYear() {
        
        BigDecimal degreeDayDailyAverage = BigDecimal.ZERO;
        
        BillSegment lastYearBillSegment = retrieveLastYearBillSegment();
        
        if (notNull(lastYearBillSegment)) {
            degreeDayDailyAverage = getDegreeDayDailyAverage(lastYearBillSegment.getStartDate(), lastYearBillSegment.getEndDate());
        }
        
        logDebug(logger, "***Historic Degree Day Daily Average from Last Year***");
        logDebug(logger, "Historical Degree Day Daily Average      : " + degreeDayDailyAverage);
        logDebug(logger, "Degree Day Factor                        : " + degreeDayFactor);

        if (isNull(degreeDayDailyAverage) || degreeDayDailyAverage.compareTo(BigDecimal.ZERO) == 0) {
            degreeDayDailyAverage = BigDecimal.ONE; 
        }
        logDebug(logger, "Final Historical Degree Day Daily Average: " + degreeDayDailyAverage);
        
        return degreeDayDailyAverage;
        
    }
    
    /**
     * Based on CIPMERLN:MA100-GET-LASTYR-BS
     * @return BillSegment
     */
    private BillSegment retrieveLastYearBillSegment() {
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT BS.BSEG_ID ");
        stringBuilder.append("FROM CI_BSEG_READ BSR, CI_BSEG BS, CI_SA SA ");
        stringBuilder.append("WHERE BSR.SP_ID = :servicePoint ");
        stringBuilder.append("AND BS.BSEG_ID = BSR.BSEG_ID ");
        stringBuilder.append("AND BS.START_DT <= :midPeriodDateLastYear ");
        stringBuilder.append("AND BS.END_DT >= :midPeriodDateLastYear ");
        stringBuilder.append("AND BS.BSEG_STAT_FLG = '50' ");
        stringBuilder.append("AND BS.MASTER_BSEG_ID = ' ' ");
        stringBuilder.append("AND BS.EST_SW = 'N' ");
        stringBuilder.append("AND BSR.UOM_CD = :unitOfMeasure ");
        stringBuilder.append("AND BSR.TOU_CD = " + ((notNull(timeOfUse)) ? ":timeOfUse " : "' ' "));
        stringBuilder.append("AND SA.SA_ID = BS.SA_ID ");
        stringBuilder.append("AND SA.ACCT_ID = :account ");
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        preparedStatement.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindDate("midPeriodDateLastYear", midPeriodDateLastYear);
        preparedStatement.bindId("unitOfMeasure", unitOfMeasure.getId());
        if (notNull(timeOfUse)) {
            preparedStatement.bindId("timeOfUse", timeOfUse.getId());
        }
        preparedStatement.bindId("account", account.getId());
        
        preparedStatement.execute();
        SQLResultRow sqlResultRow = preparedStatement.firstRow();
        // Start Change - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        // preparedStatement.setAutoclose(false);
        preparedStatement.close();
        // End Change - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        
        if (isNull(sqlResultRow)) {
            return null;
        }
        
        return sqlResultRow.getEntity("BSEG_ID", BillSegment.class);
        
    }
    
    /**
     * Retrieve the degree days for the previous bill segment period and calculate the daily 
     * average. If the total Degree Days for the period add up to 0, assume the value of 1.
     * @return BigDecimal
     */
    private BigDecimal getHistoricDegreeDayDailyAverageFromPrevious() {
        
        BigDecimal degreeDayDailyAverage = BigDecimal.ZERO;
        
        BillSegment previousBillSegment = retrievePreviousBillSegment();
        
        if (notNull(previousBillSegment)) {
            degreeDayDailyAverage = getDegreeDayDailyAverage(previousBillSegment.getStartDate(), previousBillSegment.getEndDate());
        }
        
        if (isNull(degreeDayDailyAverage) || degreeDayDailyAverage.compareTo(BigDecimal.ZERO) == 0) {
            degreeDayDailyAverage = BigDecimal.ONE; 
        }
        
        return degreeDayDailyAverage;
        
    }
    
    /**
     * Based on CIPMERPN:MA100-GET-PREV-BS
     * @return BillSegment
     */
    private BillSegment retrievePreviousBillSegment() {
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT BS.BSEG_ID ");
        stringBuilder.append("FROM CI_BSEG_READ BSR, CI_BSEG BS, CI_SA SA ");
        stringBuilder.append("WHERE BSR.SP_ID = :servicePoint ");
        stringBuilder.append("AND BS.BSEG_ID = BSR.BSEG_ID ");
        stringBuilder.append("AND BS.END_DT < :readDate ");
        stringBuilder.append("AND BS.BSEG_STAT_FLG = '50' ");
        stringBuilder.append("AND BS.MASTER_BSEG_ID = ' ' ");
        stringBuilder.append("AND BS.EST_SW = 'N' ");
        stringBuilder.append("AND BSR.UOM_CD = :unitOfMeasure ");
        stringBuilder.append("AND BSR.TOU_CD = " + ((notNull(timeOfUse)) ? ":timeOfUse " : "' ' "));
        stringBuilder.append("AND SA.SA_ID = BS.SA_ID ");
        stringBuilder.append("AND SA.ACCT_ID = :account ");
        stringBuilder.append("ORDER BY BS.START_DT DESC ");
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        preparedStatement.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindDate("readDate", readDateTime.getDate());
        preparedStatement.bindId("unitOfMeasure", unitOfMeasure.getId());
        if (notNull(timeOfUse)) {
            preparedStatement.bindId("timeOfUse", timeOfUse.getId());
        }
        preparedStatement.bindId("account", account.getId());
        
        preparedStatement.execute();
        SQLResultRow sqlResultRow = preparedStatement.firstRow();
        // Start Change - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        // preparedStatement.setAutoclose(false);
        preparedStatement.close();
        // End Change - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        
        if (isNull(sqlResultRow)) {
            return null;
        }
        
        return sqlResultRow.getEntity("BSEG_ID", BillSegment.class);
        
    }
    
    /**
     * Retrieve the degree days for the current bill segment period and calculate the daily 
     * average. If the total Degree Days for the period add up to 0, assume the value of 1.
     * @return BigDecimal
     */
    private BigDecimal getCurrentDegreeDayDailyAverage() {
        
        BigDecimal degreeDayDailyAverage = getDegreeDayDailyAverage(startDate, endDate);
        
        if (isNull(degreeDayDailyAverage) || degreeDayDailyAverage.compareTo(BigDecimal.ZERO) == 0) {
            degreeDayDailyAverage = BigDecimal.ONE; 
        }
        
        return degreeDayDailyAverage;
        
    }
    
    /**
     * Retrieve the average of the degree days between the start and end dates.
     * @param startDate
     * @param endDate
     * @return BigDecimal
     */
    private BigDecimal getDegreeDayDailyAverage(Date startDate, Date endDate) {
        
        BigDecimal degreeDaySum = BigDecimal.ZERO;
        BigDecimal degreeDayCount = BigDecimal.ZERO;
        
        // Do not include the end date where the meter would have had an estimate or read
        endDate = endDate.addDays(-1);
        
        DegreeDay degreeDay;
        logDebug(logger, "***Degree Day Daily Average***");
        logDebug(logger, "Start Date              : " + startDate);
        logDebug(logger, "End Date                : " + endDate);
        
        while (startDate.isSameOrBefore(endDate)) {
            
            degreeDay = new DegreeDay_Id(trendArea, startDate).getEntity();
            if (isNull(degreeDay)) {
                addError(CustomMessageRepository.SA_115715A_DegreeDayMissing(trendArea, startDate));
            }
            
            degreeDaySum = degreeDaySum.add(degreeDay.getDegreeDay());
            degreeDayCount = degreeDayCount.add(BigDecimal.ONE);
            
            logDebug(logger, degreeDayCount + " Trend Area " + trendArea + " Degree Day on " + startDate + ": " + degreeDay + ", Total: " + degreeDaySum);
            
            startDate = startDate.addDays(1);
            
        }

        logDebug(logger, "Final Degree Day Sum    : " + degreeDayCount);
        logDebug(logger, "Final Degree Day Count  : " + degreeDayCount);
        logDebug(logger, "Final Degree Day Average: " + degreeDaySum.divide(degreeDayCount));
        
        return (degreeDayCount.compareTo(BigDecimal.ZERO) == 0) ? BigDecimal.ZERO : degreeDaySum.divide(degreeDayCount);
        
    }
    
    /**
     * Compute the correct estimated register reading using register and 
     * installation constants, ensures correct reading if dial rolls over and truncates unneeded 
     * trailing digits.
     * @return BigDecimal RegisterReading
     */
    private BigDecimal computeRegisterReading(BigDecimal startRegisterReading, BigDecimal usage) {

        BigDecimal maximumDial = BigDecimal.TEN.pow(BigDecimal.valueOf(register.getNumberOfDigitsLeft().longValue()));
        
        BigDecimal rawUsage = usage.divide(register.getRegisterConstant());
        
        BigDecimal installationConstant = getServicePointMeterHistory(servicePoint, register.getMeterConfiguration()).getInstallationConstant();
        
        if (BigDecimal.ZERO.longValue() < installationConstant.longValue()) {
            rawUsage = rawUsage.divide(installationConstant);
        }
        
        if (rawUsage.compareTo(maximumDial) >= 0) {
            addError(CustomMessageRepository.SA_115715A_Rollover(register));
        }
        
        /*
         * Check the Raw Usage against Number of Digits Rgt and truncate the trailing digits
         */
        usage = rawUsage.setScale(register.getNumberOfDigitsRight().intValue(), BigDecimal.ROUND_HALF_DOWN);
        
        /*
         * Calculate the register reading. 
         */
        BigDecimal endReading = BigDecimal.ZERO;
        if (register.getConsumptionType().isSubtractive()) {
            endReading = startRegisterReading.add(usage);
        } else {
            endReading = usage;
        }
        
        /*
         * If greater than the capacity of the dial, then we assume that the dial has rolled over.
         */
        if (endReading.compareTo(maximumDial) > 0) {
            endReading = endReading.subtract(maximumDial);
        }
        
        return endReading;
        
    }
    
    /**
     * Based on CIPMERCN:ZS110-SETUP-SQL-S-SPMRRG
     * @param servicePoint
     * @param meterConfiguration
     * @return ServicePointMeterHistory
     */ 
    private ServicePointMeterHistory getServicePointMeterHistory(ServicePoint servicePoint, MeterConfiguration meterConfiguration) {
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select spmr.SP_MTR_HIST_ID ");
        stringBuilder.append("from CI_CFG_SPMR_VW spmr ");
        stringBuilder.append("where spmr.SP_ID = :servicePoint ");
        stringBuilder.append("and spmr.MTR_CONFIG_ID = :meterConfiguration ");
        stringBuilder.append("order by spmr.INSTALL_DTTM desc ");
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        // Start Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        preparedStatement.setAutoclose(false);
        // End Add - EQuint - Defect 4253862 - ID56 (Reopen) - 2019-05-22
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindId("meterConfiguration", meterConfiguration.getId());
        
        preparedStatement.execute();
        ServicePointMeterHistory servicePointMeterHistory = preparedStatement.firstRow().getEntity("SP_MTR_HIST_ID", ServicePointMeterHistory.class);
        preparedStatement.close();
        
        return servicePointMeterHistory;
        
    }
    /*
     * SA-115715-A - 2017-10-24 - End Add
     */
    
}
