/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Column Delimited Record class for Banking Record
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-05-27   RDizon  CCB041. Initial version.        
 **************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

/**
 * @author RDizon
 */
public class CmCheckExtractOriginBankingRecord extends ColumnDelimitedRecord {
    
    private static final String DELIMITER = "|";
        
    public CmCheckExtractOriginBankingRecord() {
        super(20);
    }
    
    public void setRecordType(String value) {
        this.leftPadColumn(1, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setSenderId(String value) {
        this.leftPadColumn(2, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setUserId(String value) {
        this.leftPadColumn(3, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setAbaNumber(String value) {
        this.leftPadColumn(4, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setCustomerName(String value) {
        this.leftPadColumn(5, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setCustomerFederalTaxId(String value) {
        this.leftPadColumn(6, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setFileSequenceId(String value) {
        this.leftPadColumn(7, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setAccountNumberQual(String value) {
        this.leftPadColumn(8, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setAccountNumber(String value) {
        this.leftPadColumn(9, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setDiscretionaryData(String value) {
        this.leftPadColumn(10, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setDescriptionDate(String value) {
        this.leftPadColumn(11, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPaymentsDescription(String value) {
        this.leftPadColumn(12, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setBankName(String value) {
        this.leftPadColumn(13, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setAddress1(String value) {
        this.leftPadColumn(14, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setCity(String value) {
        this.leftPadColumn(15, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setState(String value) {
        this.leftPadColumn(16, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setPostCode(String value) {
        this.leftPadColumn(17, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setCountry(String value) {
        this.leftPadColumn(18, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setFractionalRoutingCode(String value) {
        this.leftPadColumn(19, value.length() + 1, value.trim() + DELIMITER);
    }

    public void setStaleDateMessage(String value) {
        this.leftPadColumn(20, value.length() + 1, value.trim());
    }

}
