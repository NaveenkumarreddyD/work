/*
 ***************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * FirsTech All User File Upload (Customer Data Upload) 
 * 
 * This custom Batch Process will read the inbound All User file and load 
 * the data into a custom table. This table will have the same layout as 
 * the All User file's detail records and will be emptied of all data prior 
 * to loading the file.
 *            
 ****************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2019-11-25   JLumbre SpireOne. CCB-107. Initial Version.
 * 2020-04-27   JLumbre SpireOne. Updates for CSV processing.
 *  
 ****************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.batch.file.csv.CSVRecord;
import com.splwg.base.api.batch.file.csv.StandardCSVRecordReader;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.cm.domain.customerinfo.cmFirsTechCustomerData.CmFirsTechCustomerData;
import com.splwg.shared.common.ApplicationError;

/**
 * @author TMG02631
 *
@BatchJob (multiThreaded = false, modules={},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)})
 */
public class CmFirsTechCustomerDataUploadBatch extends
CmFirsTechCustomerDataUploadBatch_Gen {

	// Constant Variables
	private final static String YES = "Y";
	//private final static char DEFAULT_SEPARATOR = ',';
	//private final static char DEFAULT_QUOTE = '"';

	private String filePath;

	public void validateSoftParameters(boolean arg0) {
		// Parameter FILE_PATH
		filePath = getParameters().getFILE_PATH();        
		if (notBlank(filePath) && validateFilePath(filePath).isFalse()) {
			addError(CustomMessageRepositorySpireOne.S1_FilePathInvalid(filePath));            
		}
	}

	/**
	 * This method validates file path
	 * @param filePath - String
	 * @return Bool
	 */
	private Bool validateFilePath(String filePath) {

		File folder = new File(filePath);
		if (folder.exists()) {
			return Bool.TRUE;
		}
		return Bool.FALSE;
	}

	public JobWork getJobWork() {
		ArrayList<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
		ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
		arrayList.add(threadWorkUnit);

		return createJobWorkForThreadWorkUnitList(arrayList);
	}

	public Class<CmFirsTechCustomerDataUploadBatchWorker> getThreadWorkerClass() {
		return CmFirsTechCustomerDataUploadBatchWorker.class;
	}

	public static class CmFirsTechCustomerDataUploadBatchWorker extends
	CmFirsTechCustomerDataUploadBatchWorker_Gen {

		private String filePath;
		private String fileName;

		private int recordsProcessed = 0;
		private int recordsInserted = 0;

		private BufferedReader bufferedReader = null; 

		public ThreadExecutionStrategy createExecutionStrategy() {			
			return new StandardCommitStrategy(this);
		}

		@Override
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {		
		

			//String record = null;			

			//Purge records in table
			purgeTable();	
			
			StandardCSVRecordReader inputReader = new StandardCSVRecordReader();
			CSVRecord csvRecord;
			try {
				while ((csvRecord = inputReader.read(bufferedReader)) != null){
			/*try{
				while (!isBlankOrNull(record = readRecord())) {*/
					recordsProcessed++;

					//List<String> elementLine = parseLine(record);					
					if (csvRecord.getNumberOfColumns() != 5) {                   
						logError(CustomMessageRepositorySpireOne.S1_recordHasIncorrectNumOfFields(
								recordsProcessed));
						continue;					
					}

					/*String ACCT_ID = elementLine.get(0);
					String CM_CUST_NAME = elementLine.get(1).replace("\"", "");
					String CM_PAPERLESS_FLG = elementLine.get(2);
					String EMAILID = elementLine.get(3);
					String CM_BILL_PAY_VNDR = elementLine.get(4);*/
					String ACCT_ID = csvRecord.getString(0);
					String CM_CUST_NAME = csvRecord.getString(1);
					String CM_PAPERLESS_FLG = csvRecord.getString(2);
					String EMAILID = csvRecord.getString(3);
					String CM_BILL_PAY_VNDR = csvRecord.getString(4);

					Account_Id acctId = new Account_Id(ACCT_ID);
					try {
						if(isNull(acctId.getEntity()) )
							continue;
					} catch (Exception e) {  
						continue;
					}


					Bool paperlessFlg = Bool.FALSE;
					if (CM_PAPERLESS_FLG.compareTo(YES) == 0){
						paperlessFlg = Bool.TRUE;
					}

					
					try{

						StringBuilder insertSql = new StringBuilder();
						insertSql.append("INSERT INTO CM_FIRSTECH_CUST_IN ");
						insertSql.append("VALUES (:ACCT_ID, ");
						insertSql.append(":CM_CUST_NAME, ");
						insertSql.append(":CM_PAPERLESS_FLG, ");
						insertSql.append(":EMAILID, ");
						insertSql.append(":CM_BILL_PAY_VNDR)");

						PreparedStatement insertQry = createPreparedStatement(insertSql.toString(), getClass().getName());
						insertQry.bindId("ACCT_ID", acctId);
						insertQry.bindStringProperty("CM_CUST_NAME", CmFirsTechCustomerData.properties.cmCustomerName, CM_CUST_NAME);
						insertQry.bindBoolean("CM_PAPERLESS_FLG", paperlessFlg);
						insertQry.bindStringProperty("EMAILID", CmFirsTechCustomerData.properties.emailAddress, EMAILID);
						insertQry.bindStringProperty("CM_BILL_PAY_VNDR", CmFirsTechCustomerData.properties.cmBillPayVendor,CM_BILL_PAY_VNDR);

						insertQry.setAutoclose(false);
						insertQry.execute();	
						insertQry.close();
					
						recordsInserted++;

					} catch (ApplicationError ae) {
						logError(CustomMessageRepositorySpireOne.S1_unableToAddRecord(
								recordsProcessed, ae.getServerMessage().getMessageText()));							
					}
					 
				}	

				bufferedReader.close();

			} catch (IOException e) {
				throw new RunAbortedException(CustomMessageRepositorySpireOne.S1_errorWhileAccessingFile(e.getMessage().trim()));
			}
			
			WorkUnitResult result = new WorkUnitResult(true);
            result.setUnitsProcessed(recordsProcessed);

			logInfo(CustomMessageRepositorySpireOne.S1_totalRecordsInserted(recordsInserted));
			return result;
		}



		private void purgeTable(){
			PreparedStatement purgeTable = createPreparedStatement("DELETE FROM CM_FIRSTECH_CUST_IN", getClass().getName()); 

			purgeTable.execute();
			purgeTable.close();
		}


		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
						throws ThreadAbortedException, RunAbortedException {

			filePath = getParameters().getFILE_PATH();
			fileName = getParameters().getFILE_NAME();

			File file = new File(filePath, fileName);  

			try {				
				bufferedReader = new BufferedReader(new FileReader(file));
			} catch (FileNotFoundException fe) {
				throw new RunAbortedException(CustomMessageRepositorySpireOne.S1_errorWhileAccessingFile(fe.getMessage()));
			}
		}
		
	}

}
