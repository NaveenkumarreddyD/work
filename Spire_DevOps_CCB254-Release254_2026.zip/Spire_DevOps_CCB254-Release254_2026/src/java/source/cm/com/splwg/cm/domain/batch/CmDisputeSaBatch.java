/* **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * This custom batch process will select all active dispute SAs that 
 * has expired. The expiration date of the Dispute SA will be stored as a 
 * characteristic on the SA. If a dispute SA has expired, the transfer 
 * adjustment will be cancelled so that the disputed charges will be 
 * transferred back to the Gas SA. After cancelling the transfer 
 * adjustment, a Customer Contact with the cancelled Adjustment 
 * as a Foreign Key Char will be created so that it can be reviewed.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:        	 Reason:
 * YYYY-MM-DD   IN         	 Reason text.
 *
 * 2018-10-02   EQuint/MPang SA-241631A. Initial Version.
 * ************************************************************************/
package com.splwg.cm.domain.batch;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.util.StringTokenizer;
import com.splwg.base.api.Query;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.ccb.api.lookup.AdjustmentStatusLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.adjustment.common.CancelAdjustment;
import com.splwg.ccb.domain.admin.adjustmentCancelReason.entity.AdjustmentCancelReason;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.common.ServerMessage;

/**
 * @author Administrator
 *
@BatchJob (multiThreaded = false, rerunnable = false, modules ={},
 *      softParameters = { @BatchJobSoftParameter (name = DISPUTE_SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = DISP_EXP_DT_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = MPSC_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = adjustmentCancelReason, name = ADJ_CAN_RSN, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = TD_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = role, name = TD_ROLE, type = entity)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CC_CLASS, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = CC_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = ADJ_ID_CHAR_TYPE, required = true, type = entity)})
 */
public class CmDisputeSaBatch extends CmDisputeSaBatch_Gen {
	
	// Soft Parameters
	private String parmSaType;
	private CharacteristicType parmDisputeExpireDateCharType;
	private CharacteristicType parmMpscCharType;
	private AdjustmentCancelReason parmAdjCancelReason;
	private ToDoType parmTdType;
	private Role parmTdRole;
	private CustomerContactClass parmCcClass;
	private String parmCcType;
	private CharacteristicType parmAdjIdCharType;
	
	// Work Variables
	private CustomerContactType ccType;
	
	// Constants
	private static final String COMMA_DELIMITER = ",";
	private static final String SINGLE_QUOTE = "'";
	private static final String PARM_DESC_DISP_EXP_DT_CHAR_TYPE = "DISP_EXP_DT_CHAR_TYPE";
	private static final String PARM_DESC_MPSC_CHAR_TYPE = "MPSC_CHAR_TYPE";
	private static final String PARM_DESC_ADJ_ID_CHAR_TYPE = "ADJ_ID_CHAR_TYPE";
	private static final String PARM_DESC_TD_TYPE = "TD_TYPE";
	private static final String PARM_DESC_TD_ROLE = "TD_ROLE";
	private static final String PARM_DESC_DISPUTE_SA_TYPE = "DISPUTE_SA_TYPE";
	
	

	public JobWork getJobWork() {
		return createJobWorkForEntityQuery(retrieveActiveDisputeSas());
	}
	
	private Query<ServiceAgreement> retrieveActiveDisputeSas() {
		
		String saTypes = createServiceAgreementTypesString(parmSaType);
		
		Query<ServiceAgreement> query = createQuery(" FROM ServiceAgreement sa, ServiceAgreementCharacteristic saChar " +
				" WHERE sa.serviceAgreementType.id.saType IN (" + saTypes + ") " +
				" AND sa.status IN (:activeStatus, :pendingStopStatus, :stoppedStatus) " +
				" AND saChar.id.serviceAgreement.id = sa.id " +
				" AND saChar.id.characteristicType.id = :expDtCharTypeId " +
				" AND saChar.searchCharacteristicValue < TO_CHAR(:procDate, 'yyyy-MM-dd') " +
				" AND NOT EXISTS (SELECT saChar1.id.serviceAgreement.id FROM ServiceAgreementCharacteristic saChar1 " +
					" WHERE saChar1.id.serviceAgreement.id = sa.id " +
					" AND saChar1.id.characteristicType.id = :mpscCharTypeId) ",
				"retrieveActiveDisputeSas");
		
		query.bindLookup("activeStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
		query.bindLookup("pendingStopStatus", ServiceAgreementStatusLookup.constants.PENDING_STOP);
		query.bindLookup("stoppedStatus", ServiceAgreementStatusLookup.constants.STOPPED);
		query.bindId("expDtCharTypeId", parmDisputeExpireDateCharType.getId());
		query.bindDate("procDate", this.getProcessDateTime().getDate());
		query.bindId("mpscCharTypeId", parmMpscCharType.getId());
		
		query.addResult("sa", "sa");
		
		return query;

    }
	
	  /**
     * This method builds the Service Agreement Types String for Query.
     * @param saTypesStr
     * @return String
     */
    private String createServiceAgreementTypesString(String saTypesStr) {
        StringTokenizer strTokenizer = new StringTokenizer(saTypesStr, COMMA_DELIMITER);
        StringBuilder strBuilder = new StringBuilder();

        while (strTokenizer.hasMoreElements()) {
            strBuilder.append(SINGLE_QUOTE);
            strBuilder.append(strTokenizer.nextToken().trim());
            strBuilder.append(SINGLE_QUOTE);

            if (strTokenizer.hasMoreTokens()) {
                strBuilder.append(COMMA_DELIMITER);
            }
        }

        return strBuilder.toString();
    }

	public Class<CmDisputeSaBatchWorker> getThreadWorkerClass() {
		return CmDisputeSaBatchWorker.class;
	}

	@Override
	public void validateSoftParameters(boolean isNewRun) {
		parmSaType = getParameters().getDISPUTE_SA_TYPE();
		validateDisputeSaTypes(parmSaType);
		
		parmDisputeExpireDateCharType = getParameters().getDISP_EXP_DT_CHAR_TYPE();
		if (validateCharacteristicTypeToEntity(parmDisputeExpireDateCharType, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT).isFalse()) {
			addError(CustomMessageRepository.SA241631A_charTypeInvalidForEntity(PARM_DESC_DISP_EXP_DT_CHAR_TYPE, 
					parmDisputeExpireDateCharType.fetchLanguageDescription(), 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().fetchLanguageDescription()));
		}
		
		parmMpscCharType = getParameters().getMPSC_CHAR_TYPE();
		if (validateCharacteristicTypeToEntity(parmMpscCharType, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT).isFalse()) {
			addError(CustomMessageRepository.SA241631A_charTypeInvalidForEntity(PARM_DESC_MPSC_CHAR_TYPE,
					parmMpscCharType.fetchLanguageDescription(), 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().fetchLanguageDescription()));
		}
		
		parmAdjCancelReason = getParameters().getADJ_CAN_RSN();
		
		parmTdType = getParameters().getTD_TYPE();
		parmTdRole = getParameters().getTD_ROLE();
		
		if(notNull(parmTdRole)) {
			ToDoTypeRole_Id toDoTypeRoleId = new ToDoTypeRole_Id(parmTdType, parmTdRole);
			if(isNull(toDoTypeRoleId.getEntity())) {
				addError(CustomMessageRepository.SA241631A_toDoRoleInvalidToDoType(PARM_DESC_TD_ROLE,
						parmTdRole.getId().getIdValue().trim(), PARM_DESC_TD_TYPE, parmTdType.getId().getIdValue().trim()));
				
			}
		} else {
			parmTdRole = parmTdType.getDefaultRole().fetchIdToDoRole();
		}
		
			
		parmCcClass = getParameters().getCC_CLASS();
		parmCcType = getParameters().getCC_TYPE();
		
		ccType = new CustomerContactType_Id(parmCcClass, parmCcType).getEntity();
		if (isNull(ccType)) {
			addError(CustomMessageRepository.SA241631A_ccTypeInvalid(parmCcClass.getId().getTrimmedValue(), parmCcType));
		}
		
		parmAdjIdCharType = getParameters().getADJ_ID_CHAR_TYPE();
		if (validateCharacteristicTypeToEntity(parmAdjIdCharType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT).isFalse()) {
			addError(CustomMessageRepository.SA241631A_charTypeInvalidForEntity(PARM_DESC_ADJ_ID_CHAR_TYPE,
					parmAdjIdCharType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.CUSTOMER_CONTACT.getLookupValue().fetchLanguageDescription()));
		}
	}
	
	/**
     * This method validates the Dispute SA Types
     * @param disputeSaTypes
     */
    private void validateDisputeSaTypes(String disputeSaTypes) {
    	StringTokenizer strTokenizer = new StringTokenizer(disputeSaTypes, ",");
    	int saTypeCount = strTokenizer.countTokens();
    	if(saTypeCount < 1) {
    		addError(CustomMessageRepository.SA241631A_saTypeMissing(PARM_DESC_DISPUTE_SA_TYPE));
    	}
    	for(int i = 0; i < saTypeCount; i++) {
    		String saType = strTokenizer.nextToken().trim();
    		StringBuilder stringBuilder = new StringBuilder();
    		stringBuilder.append("SELECT 'X' ");
    		stringBuilder.append("FROM CI_SA_TYPE ");
    		stringBuilder.append("WHERE SA_TYPE_CD = :saType ");

    		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
    		prepState.bindString("saType", saType, "SA_TYPE_CD");
    		prepState.execute();
    		if (prepState.list().size() == 0) {
    			prepState.close();
    			// SA Type is invalid
    			addError(CustomMessageRepository.SA241631A_saTypeInvalid(PARM_DESC_DISPUTE_SA_TYPE, saType));
    		}
    	}
    	
    }
	
    /**
     * Validates the Characteristic Type is valid for Entity
     * @param charType
     * @param charEntityLookup
     * @return
     */
	private Bool validateCharacteristicTypeToEntity(CharacteristicType charType, CharacteristicEntityLookup charEntityLookup) {
		Bool isValid = Bool.TRUE;
		
		CharacteristicEntity charEntity = new CharacteristicEntity_Id(charType, charEntityLookup).getEntity();
		if (isNull(charEntity)) {
			isValid = Bool.FALSE;
		}
		
		return isValid;
	}

	public static class CmDisputeSaBatchWorker extends
			CmDisputeSaBatchWorker_Gen {
		
		// Soft Parameters
		private String parmSaType;
		private CharacteristicType parmDisputeExpireDateCharType;
		private CharacteristicType parmMpscCharType;
		private AdjustmentCancelReason parmAdjCancelReason;
		private ToDoType parmTdType;
		private Role parmTdRole;
		private CustomerContactClass parmCcClass;
		private String parmCcType;
		private CharacteristicType parmAdjIdCharType;
		
		// Work Variables
		private ServiceAgreement disputeSa;
		private CustomerContactType ccType;
		private List<Adjustment> disputeSaAdjList = new ArrayList<Adjustment>();
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			
			disputeSa = ((ServiceAgreement_Id) unit.getPrimaryId()).getEntity();
			disputeSaAdjList = getFrozenAdjustments(disputeSa.getId());

			Adjustment cancelledAdj = null;
			Bool success = Bool.FALSE;
			// For every Adjustment retrieved from SA. Cancel the adjustment.
			for (Adjustment adj : disputeSaAdjList) {
				try {
					CancelAdjustment cancelAdjustment = CancelAdjustment.Factory.newInstance();
					cancelAdjustment.cancelAdjustment(adj, parmAdjCancelReason);
					cancelledAdj = adj;
					success = Bool.TRUE;
				} catch (ApplicationError ae){
					// Create a To Do
					addToDoEntry(adj, ae.getServerMessage());
					success = Bool.FALSE;
				}
			}
			
			if(notNull(cancelledAdj) && success.isTrue()) {
				// Create a Customer Contact
				Person mainPerson = disputeSa.getAccount().getMainPerson();
				createCustomerContact(mainPerson.getId(), cancelledAdj.getId());
			}
			
			
			return true;
		}

		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
				throws ThreadAbortedException, RunAbortedException {
			parmSaType = getParameters().getDISPUTE_SA_TYPE();

			parmDisputeExpireDateCharType = getParameters().getDISP_EXP_DT_CHAR_TYPE();
			parmMpscCharType = getParameters().getMPSC_CHAR_TYPE();
			parmAdjCancelReason = getParameters().getADJ_CAN_RSN();
			parmTdType = getParameters().getTD_TYPE();
			parmTdRole = getParameters().getTD_ROLE();
			parmCcClass = getParameters().getCC_CLASS();
			parmCcType = getParameters().getCC_TYPE();
			ccType = new CustomerContactType_Id(parmCcClass, parmCcType).getEntity();

			parmAdjIdCharType = getParameters().getADJ_ID_CHAR_TYPE();
		}

		/**
		 * Get Frozen Adjustment
		 * @param saId
		 * @return frozenAdjList - List<Adjustment>
		 */
		private List<Adjustment> getFrozenAdjustments(ServiceAgreement_Id saId) {
			List<Adjustment> frozenAdjList = new ArrayList<Adjustment>();
			
			Query<Adjustment> query = createQuery(" FROM Adjustment adj " +
					" WHERE adj.serviceAgreement.id = :saId " +
					" AND adj.adjustmentStatus = :frozen "
					, "getFrozenAdjustments");
			
			query.bindId("saId", saId);
			query.bindLookup("frozen", AdjustmentStatusLookup.constants.FROZEN);
			
			frozenAdjList = query.list();
			
			return frozenAdjList;
		}
		
		
		/**
	     * This method creates a To Do Entry
	     * @param adjustment
	     * @return
	     */
	    private ToDoEntry addToDoEntry(Adjustment adjustment, ServerMessage errorMessage) {
	       
	        //Set Date, Status and Priority for the ToDo
	        ToDoEntry_DTO toDoEntryDto = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
	        toDoEntryDto.setToDoTypeId(parmTdType.getId());
	        toDoEntryDto.setCreationDateTime(getProcessDateTime());
	      
	        toDoEntryDto.setMessageId(errorMessage.getMessageId());
	        
	        // If parmToDoRole is not null then assigned to the toDoEntryDto
	        if(notNull(parmTdRole)){
	            toDoEntryDto.setToDoRoleId(parmTdRole.getId());
	        }
	        
	        //Create ToDo
	        ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
	        String adjustmentIdStr = adjustment.getId().getTrimmedValue();
	        toDoCreator.addMessageParameter(adjustmentIdStr);
	        toDoCreator.setToDoDTO(toDoEntryDto);
	        //Add drill key
	        Iterator<ToDoDrillKeyType> drillKeyIterator = parmTdType.getId().getEntity().getDrillKeyTypes().iterator();
	        toDoCreator.addDrillKeyValue(drillKeyIterator.next(), adjustmentIdStr);
	        //Add sort key
	        Iterator<ToDoSortKeyType> sortKeyIterator = parmTdType.getId().getEntity().getSortKeyTypes().iterator();
	        toDoCreator.addSortKeyValue(sortKeyIterator.next(), adjustmentIdStr);
	        
	        return toDoCreator.create();
	    }
		
		private void createCustomerContact(Person_Id perId, Adjustment_Id adjId) {
			CustomerContact_DTO ccDTO = new CustomerContact_DTO();
			
			ccDTO.setPersonId(perId);
			ccDTO.setContactDateTime(getProcessDateTime());
			ccDTO.setCustomerContactTypeId(ccType.getId());

			CustomerContact cc = ccDTO.newEntity();
			
			CustomerContactCharacteristic_DTO ccCharDTO = cc.getCharacteristics().newChildDTO();
			CharacteristicTypeLookup charTypeLookup = parmAdjIdCharType.getCharacteristicType();
			if (charTypeLookup.isPredefinedValue()) {
				ccCharDTO.setCharacteristicValue(adjId.getTrimmedValue());
			}
			else if (charTypeLookup.isForeignKeyValue()) {
				ccCharDTO.setCharacteristicValueForeignKey1(adjId.getTrimmedValue());
			}
			else {
				ccCharDTO.setAdhocCharacteristicValue(adjId.getTrimmedValue());
			}
			
			cc.getCharacteristics().add(ccCharDTO, parmAdjIdCharType.getId());
			
		}

	}

}
