/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Expire SA Algorithm
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2012-10-16   Rakesh          NA0046. Initial Version.
 ******************************************************************************************/

package com.splwg.cm.api.lookup;

/**
 * 
 * @author mlekkala001
 * @LookupFieldname (value = XUOM_OPT_TYP_FLG)
 *
 */


public class CmUnitOfMeasureLookup_Impl
	extends CmUnitOfMeasureLookup_Gen {
}