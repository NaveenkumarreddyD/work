/**************************************************************************
* Program Name: CmInactiveCWRQuoteAlgComp_Impl
* Program Title: CmInactiveCWRQuoteAlgComp_Impl
* Author: Louis Ballon
* Creation Date: 2017-03-07
* Purpose: Currently, CWR setup via My Account only works for active gas SAs.  
* This limits the functionality to a small percentage of customers.  
* In order to expand CWR (for reconnects and new turn ons) to customers 
* after their final bill, the quote and CWR setup process needs to be modified.  
* Quotes will be allowed on stopped gas SAs, but the CWR will not start until a 
* new SA is activated and the debt transferred.  When this happens, 
* if the old SA has a paid quote, a new quote will be generated 
* (using the same CWR level as the original) and CWR started on the new SA.
* Functional Spec: CCB-CC-002
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 *  CCB-CC-023-2      Louis Ballon     2018-09-20    Initial Version         
 *  Defect 4128689    Louis Ballon     2018-10-09    This Algorithm should be triggered even if the
 *  												 process date is before the SA Start date. Changed
 *  												 the checking of Paid CWR Quote Id from getting
 *  												 the effective characteristic to just checking if
 *                                                   the characteristic exist regardless if effective
 *                                                   or not. Also, the total amount of the target SA
 *                                                   will be transfered into the CWR SA (Payment
 *                                                   Arrangement SA).
 * CCB-CC-023-3		Kiran				2018-10-11	 add adjustment amount to recurring charge
 * Defect 4146443 	Kiran				2018-11-01   target SA has balance 0 so remove conditions      
 * Defect 4157313 	Kiran				2018-11-12	 during adjustment target SA has a balance 0 so remove condition                     
 * Defect 4157313 	Kiran				2018-11-14	 set the budget start date to SA start date          
 * V1 D-03352       Kiran               2023-04-04   should be looking only CSS-CWR                             
 ************************************************************************************************/
package com.splwg.cm.domain.admin.adjustmentType.algorithm.freezeAdjustment;

import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.Query;
import com.splwg.base.api.businessService.BusinessServiceDispatcher;
import com.splwg.base.api.businessService.BusinessServiceInstance;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.lookup.TodoPriorityFlagLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.common.lookup.LookupValue;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic_DTO;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristics;
import com.splwg.base.domain.serviceTask.ServiceTask_DTO;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType_Id;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.ccb.api.lookup.AdjustmentStatusLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.CustomerReadLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment_Id;
import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentCancelReason.entity.AdjustmentCancelReason;
import com.splwg.ccb.domain.admin.adjustmentType.algorithm.freezeAdjustment.AdjustmentFreezeAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.common.ServiceAgreementCreator;
import com.splwg.ccb.domain.customerinfo.data.ServiceAgreementCreatorData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristics;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.api.lookup.CmQuotePortalParametersLookup;
import com.splwg.cm.api.lookup.CmServiceTaskCharacteristicTypesLookup;
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.common.customBusinessComponent.CmCreateServiceTask;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ApplicationError;

/**
 * @author Administrator
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = paidCwrQuoteCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = role, name = toDoRole, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentCancelReason, name = cwrAdjCanRsn, required = true, type = entity)})
 */
public class CmInactiveCWRQuoteAlgComp_Impl extends
		CmInactiveCWRQuoteAlgComp_Gen implements AdjustmentFreezeAlgorithmSpot {
	
	// Hard Parameter
	private Adjustment adj;
	
	// Soft Parameters
	private CharacteristicType paidCwrQuoteCharType;
	private ToDoType toDoType;
	private Role toDoRole;
	private AdjustmentCancelReason cwrAdjCanRsn;
	
	// Constant variables
	private static final String QUOTE_PORTAL_FEAT_CONFIG = "CM-QPPARM";
	private static final String STANDARD_CHAR_VALUE = "Standard";
	private static final String CSS_CWR_CHAR_VALUE = "CSS-CWR";
	private static final String QUOTE_INFO_BS = "CM-CWRGPAQuoteInfo";
	private static final String SVC_TASK_CHAR_TYPES_FEAT_CONFIG = "CMSVCTSKCTYP";
	private static final String CWR_SA_TYPE = "GPACWR";
	private static final String BUD_PLAN_ADD_BUS_SVC = "C1-MaintainBudget";
	private static final String CWR_BUD_PLAN = "CWR";
    private static final String PAINST = "PAINST";
    private static final String PAINSTAT = "PAINSTAT";
    private static final String CWR_LEVEL_12 = "12";
	
	// Work variables
	private ServiceTaskType quoteServiceTaskType;
	private BusinessObject quoteBusinessObject;
	private String quoteBusinessObjectActiveStatus;
	private CharacteristicType downPaymentCharacteristicType;
	private CharacteristicType monthlyPayArrCharType;
	private String paidStatus;
	private ServiceAgreement targetSa;
	private CharacteristicType cwrLevelCharType;
	private ServiceTask_Id newQuoteId;
	private CharacteristicType quoteSrcCharType;
	private CharacteristicType cwrPremiseCharType;
	private String newQuoteCwrLevel;
	private ServiceTaskType pledgeServiceTaskType;
	private BusinessObject pledgeBusinessObject;
	private String pledgeBusinessObjectActiveStatus;
	private CharacteristicType_Id saCharTypeId;
	private CharacteristicType pledgeAmountCharType;
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		paidCwrQuoteCharType = getPaidCwrQuoteCharType();
		toDoType = getToDoType();
		toDoRole = getToDoRole();
		cwrAdjCanRsn = getCwrAdjCanRsn();;
		
		if(notNull(toDoRole)) {
			ToDoTypeRole_Id toDoTypeRoleId = new ToDoTypeRole_Id(toDoType, toDoRole);
			if(isNull(toDoTypeRoleId.getEntity())) {
				addError(CustomMessageRepository.CCB_CC_23_2_invalidRoleForToDoType(toDoRole.getId().getTrimmedValue(), toDoType.getId().getTrimmedValue()));
			}
		} else {
			toDoRole = toDoType.getDefaultRole().fetchIdToDoRole();
		}
	}
	
	@Override
	public void invoke() {
		// Exit if no transfer Adjustment
		if(isNull(adj.fetchTransferAdjustment())) {
		    return;
		}
		
		/*
		 * Defect 4128689 - 2018-10-09 - Start Add
		 */
		ServiceAgreement originalSa = adj.getServiceAgreement();
		ListFilter<ServiceAgreementCharacteristic> paidCwrQuoteCharFilter = 
				originalSa.getCharacteristics().createFilter(" where this.id.characteristicType = :paidCwrQuoteCharType order by this.id.effectiveDate DESC ", getClass().getName());
		paidCwrQuoteCharFilter.bindEntity("paidCwrQuoteCharType", paidCwrQuoteCharType);
		ServiceAgreementCharacteristic paidCwrQuoteChar = paidCwrQuoteCharFilter.firstRow();
		// V1 D-03352       Kiran               2023-04-04 
		if(notNull(paidCwrQuoteChar)) {
        StringBuilder getServiceTaskString = new StringBuilder();
        getServiceTaskString.append("SELECT 'X' FROM F1_SVC_TASK_CHAR ");
        getServiceTaskString.append("WHERE F1_SVC_TASK_ID = :servTaskId ");
        getServiceTaskString.append("AND CHAR_TYPE_CD = 'QTESRC' ");
        getServiceTaskString.append("AND ADHOC_CHAR_VAL = 'CSS-CWR' ");
        PreparedStatement getServiceTaskPrepStmt = createPreparedStatement(getServiceTaskString.toString(), getClass().getName()); 
        getServiceTaskPrepStmt.bindStringProperty("servTaskId", paidCwrQuoteChar.properties.adhocCharacteristicValue, paidCwrQuoteChar.getAdhocCharacteristicValue().trim());

        List<SQLResultRow> resultList = getServiceTaskPrepStmt.list();
        getServiceTaskPrepStmt.close();
        if(resultList.isEmpty()){
        	paidCwrQuoteChar = null;
        }
		}
		//V1 D-03352       Kiran               2023-04-04 
		//SELECT TSK.F1_SVC_TASK_ID 
		//"FROM F1_SVC_TASK_CHAR TSK
		//WHERE TSK.F1_SVC_TASK_ID = :F1
		//AND TSK.CHAR_TYPE_CD = 'QTESRC'
		//AND TSK.ADHOC_CHAR_VAL = 'CSS-CWR'

		
		/*
		 * Defect 4128689 - 2018-10-09 - End Add
		 */
		
		/*
		 * Defect 4128689 - 2018-10-09 - Start Change
		 */
		//if(notNull(adj.getServiceAgreement().getEffectiveCharacteristicAsOfDate(paidCwrQuoteCharType, getProcessDateTime().getDate()))) {
		if(notNull(paidCwrQuoteChar)) {
		/*
		 * Defect 4128689 - 2018-10-09 - End Change
		 */
			// Retrieve Target SA
			/*
			 * Defect 4128689 - 2018-10-09 - Start Delete
			 */
			//ServiceAgreement originalSa = adj.getServiceAgreement();
			/*
			 * Defect 4128689 - 2018-10-09 - End Delete
			 */
			
			targetSa = adj.fetchTransferAdjustment().getServiceAgreement();
			
//			if(!targetSa.getCurrentBalance().isZero()) { // Defect 4146443 	Kiran				2018-11-01   target SA has balance 0 so remove conditions
				try {
					// Retrieve Quote Portal Service Parameters
					FeatureConfiguration featureConfiguration = new FeatureConfiguration_Id(QUOTE_PORTAL_FEAT_CONFIG).getEntity();
					
					CmFeatureConfigurationRetriever featConfigRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
					featConfigRetriever.setParmWFMName(featureConfiguration);
					
					featConfigRetriever.setParmOptType(CmQuotePortalParametersLookup.constants.QUOTE_SERVICE_TASK_TYPE.getLookupValue().fetchIdFieldValue());
					quoteServiceTaskType = new ServiceTaskType_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
					
					featConfigRetriever.setParmOptType(CmQuotePortalParametersLookup.constants.QUOTE_BUSINESS_OBJECT.getLookupValue().fetchIdFieldValue());
					quoteBusinessObject = new BusinessObject_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
					
					featConfigRetriever.setParmOptType(CmQuotePortalParametersLookup.constants.QUOTE_BUSINESS_OBJECT_ACTIVE_STATUS.getLookupValue().fetchIdFieldValue());
					quoteBusinessObjectActiveStatus = featConfigRetriever.getMaxSequenceOptionValue().trim();
					
					featConfigRetriever.setParmOptType(CmQuotePortalParametersLookup.constants.QUOTE_BUSINESS_OBJECT_PAID_STATUS.getLookupValue().fetchIdFieldValue());
					paidStatus = featConfigRetriever.getMaxSequenceOptionValue().trim();
					
					featConfigRetriever.setParmOptType(CmQuotePortalParametersLookup.constants.CWR_PREMISE_CHARACTERISTIC_TYPE.getLookupValue().fetchIdFieldValue());
					cwrPremiseCharType = new CharacteristicType_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
					
					featConfigRetriever.setParmOptType(CmQuotePortalParametersLookup.constants.PLEDGE_SERVICE_TASK_TYPE.getLookupValue().fetchIdFieldValue());
					pledgeServiceTaskType = new ServiceTaskType_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
					
					featConfigRetriever.setParmOptType(CmQuotePortalParametersLookup.constants.PLEDGE_BUSINESS_OBJECT.getLookupValue().fetchIdFieldValue());
					pledgeBusinessObject = new BusinessObject_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
					
					featConfigRetriever.setParmOptType(CmQuotePortalParametersLookup.constants.PLEDGE_BUSINESS_OBJECT_ACTIVE_STATUS.getLookupValue().fetchIdFieldValue());
					pledgeBusinessObjectActiveStatus = featConfigRetriever.getMaxSequenceOptionValue().trim();
					
					featureConfiguration = new FeatureConfiguration_Id(SVC_TASK_CHAR_TYPES_FEAT_CONFIG).getEntity();
					
					featConfigRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
					featConfigRetriever.setParmWFMName(featureConfiguration);
					
					featConfigRetriever.setParmOptType(CmServiceTaskCharacteristicTypesLookup.constants.CUSTOM_DOWN_PAYMENT_CHARACTERISTIC_TYPE.getLookupValue().fetchIdFieldValue());
					downPaymentCharacteristicType = new CharacteristicType_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
					
					featConfigRetriever.setParmOptType(CmServiceTaskCharacteristicTypesLookup.constants.CWR_MONTHLY_PAYMENT_ARRANGEMENT_CHARACTERISTIC_TYPE.getLookupValue().fetchIdFieldValue());
					monthlyPayArrCharType = new CharacteristicType_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
					
					featConfigRetriever.setParmOptType(CmServiceTaskCharacteristicTypesLookup.constants.CWR_LEVEL_CHARACTERISTIC_TYPE.getLookupValue().fetchIdFieldValue());
					cwrLevelCharType = new CharacteristicType_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
					
					featConfigRetriever.setParmOptType(CmServiceTaskCharacteristicTypesLookup.constants.QUOTE_SOURCE_CHARACTERISTIC_TYPE.getLookupValue().fetchIdFieldValue());
					quoteSrcCharType = new CharacteristicType_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
					
					featConfigRetriever.setParmOptType(CmServiceTaskCharacteristicTypesLookup.constants.SA_ID_CHARACTERISTIC_TYPE.getLookupValue().fetchIdFieldValue());
					saCharTypeId = new CharacteristicType_Id(featConfigRetriever.getMaxSequenceOptionValue().trim());
					
					featConfigRetriever.setParmOptType(CmServiceTaskCharacteristicTypesLookup.constants.AMOUNT_CHARACTERISTIC_TYPE.getLookupValue().fetchIdFieldValue());
					pledgeAmountCharType = new CharacteristicType_Id(featConfigRetriever.getMaxSequenceOptionValue().trim()).getEntity();
					
					// Check if target SA Account has GPASIC
					cancelServiceInstallation(targetSa.getAccount());
					
					// Get Paid CWR Quote Id
					/*
					 * Defect 4128689 - 2018-10-09 - Start Change
					 */
					//ServiceAgreementCharacteristic quoteIdChar = originalSa.getEffectiveCharacteristic(paidCwrQuoteCharType);
					ServiceAgreementCharacteristic quoteIdChar = paidCwrQuoteChar;
					/*
					 * Defect 4128689 - 2018-10-09 - End Change
					 */
					String originalQuoteIdStr = "";
					if(quoteIdChar.getId().getCharacteristicType().getCharacteristicType().isAdhocValue()) {
						originalQuoteIdStr = quoteIdChar.getAdhocCharacteristicValue();
					} else if(quoteIdChar.getId().getCharacteristicType().getCharacteristicType().isForeignKeyValue()) {
						originalQuoteIdStr = quoteIdChar.getCharacteristicValueForeignKey1();
					} else if(quoteIdChar.getId().getCharacteristicType().getCharacteristicType().isPredefinedValue()) {
						originalQuoteIdStr = quoteIdChar.getCharacteristicValue();
					}
					
					// Add a standard quote to the SA
					ServiceTask newQuote = createActiveQuote(targetSa, CSS_CWR_CHAR_VALUE);
					newQuoteId = newQuote.getId();
					
	                // Call the Quote Info Business Service for the new quote
	                BusinessServiceInstance bsInstance = BusinessServiceInstance.create(QUOTE_INFO_BS);
	                bsInstance.set("sa", targetSa.getId().getTrimmedValue());
	                bsInstance.set("quote", newQuote.getId().getTrimmedValue());
	                BusinessServiceInstance result = BusinessServiceDispatcher.execute(bsInstance);
	                
	                // Get CWR level of the new quote
	                newQuoteCwrLevel = result.getString("cwrLevel");
	                
	                // Call the Quote Info Business Service for the original Quote 
	                ServiceTask_Id originalQuoteId = new ServiceTask_Id(originalQuoteIdStr);
	                bsInstance = BusinessServiceInstance.create(QUOTE_INFO_BS);
	                bsInstance.set("sa", originalSa.getId().getTrimmedValue());
	                bsInstance.set("quote", originalQuoteId.getTrimmedValue());
	                result = BusinessServiceDispatcher.execute(bsInstance);
	                
	                String originalQuoteCwrLevel = result.getString("cwrLevel");
	                
	                ServiceTaskCharacteristics newQuoteChars = newQuote.getCharacteristics();
	                
	                // Update the value of new quote CWR level to the same value as the original Quote CWR level
	                if(originalQuoteCwrLevel.compareTo(newQuoteCwrLevel) != 0) {
	                	newQuoteCwrLevel = originalQuoteCwrLevel;
	                	
	                	// Update Quote CWR Level
	                	ListFilter<ServiceTaskCharacteristic> cwrLevelCharFilter = 
	                			newQuoteChars.createFilter(" where this.id.characteristicType = :cwrLevelCharacteristicType "
	                					, getClass().getName());
	                	cwrLevelCharFilter.bindEntity("cwrLevelCharacteristicType", cwrLevelCharType);
	                	ServiceTaskCharacteristic newQuoteCwrLevelChar = cwrLevelCharFilter.firstRow();
	                	
	                	ServiceTaskCharacteristic_DTO cwrLevelCharDto = newQuoteCwrLevelChar.getDTO();
	                	cwrLevelCharDto.setCharacteristicValue(newQuoteCwrLevel);
	                	newQuoteCwrLevelChar.setDTO(cwrLevelCharDto);
	                }
	                
	                // Update the CWR downpayment to 0.
	                ListFilter<ServiceTaskCharacteristic> serviceTaskCharFilter = 
	                		newQuoteChars.createFilter(" where this.id.characteristicType = :downPaymentcharacteristicType"
	                				, getClass().getName());
	                
	                serviceTaskCharFilter.bindEntity("downPaymentcharacteristicType", downPaymentCharacteristicType);
	                ServiceTaskCharacteristic downpaymentChar = serviceTaskCharFilter.firstRow();
	                
	                ServiceTaskCharacteristic_DTO serviceTaskCharDto = downpaymentChar.getDTO();
	                serviceTaskCharDto.setAdhocCharacteristicValue("0");
	                downpaymentChar.setDTO(serviceTaskCharDto);
	                
	                // Transition Quote to Paid
	                ServiceTask_DTO serviceTaskDto = newQuote.getDTO();
	                serviceTaskDto.setStatus(paidStatus);
	                newQuote.setDTO(serviceTaskDto);
	                
	                // Retrieve recurring charge amount
	                /*
	                 * Defect 4128689 - 2018-10-09 - Start Change
	                 */
	                //ListFilter<ServiceTaskCharacteristic> charFilter2 = newQuoteChars.createFilter("where this.id.characteristicType = :charType" 
	                //        , getClass().getName());
	                //charFilter2.bindEntity("charType", monthlyPayArrCharType);
	                //ServiceTaskCharacteristic monthlyPayArrChar = charFilter2.firstRow();
	                //String recurringChargeAmtStr = monthlyPayArrChar.getSearchCharacteristicValue();
	                //Money recurringChargeAmt = new Money(recurringChargeAmtStr, targetSa.getCurrencyId());
	                //
	                //if(newQuoteCwrLevel.trim().compareToIgnoreCase(CWR_LEVEL_12.trim()) == 0) {
                    //	if(result.getGroup("optional").getMoney("lvl50CWRDownpaymentAmount").isLessThan(result.getMoney("downPayment"))) {
                    //		recurringChargeAmt = result.getGroup("optional").getMoney("lvl50MonthlyArrearsAmount");
                    //	}
                    //}

	                // Kiran 10/11/18 add adjustment amount
	                BigDecimal recurringCharge = (targetSa.getCurrentBalance().getAmount().subtract(adj.getCurrentAmount().getAmount())).divide(BigDecimal.valueOf(12));
	                Money recurringChargeAmt = new Money(recurringCharge.setScale(2, BigDecimal.ROUND_HALF_UP),targetSa.getCurrencyId());
	                /* 
	                 * Defect 4128689 - 2018-10-09 - End Change
	                 */
	                
	                ServiceAgreement paSa = createPaymentArrangementSa(targetSa.getAccount().getId(), CWR_SA_TYPE, recurringChargeAmt, "12");
	                
	                createAdjustments(targetSa, paSa);
	                
	                createBudgetPlan(targetSa.getAccount().getId());
	                
				} catch(ApplicationError e) {
					ToDoEntry_DTO toDoEntryDto = createDTO(ToDoEntry.class);
					toDoEntryDto.setToDoTypeId(toDoType.getId());
					toDoEntryDto.setToDoRoleId(toDoRole.getId());
					toDoEntryDto.setCreationDateTime(getProcessDateTime());
					toDoEntryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
					toDoEntryDto.setToDoPriority(TodoPriorityFlagLookup.constants.PRIORITY_1_0);
					toDoEntryDto.setMessageId(e.getServerMessage().getMessageId());
					
					ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
					toDoCreator.setToDoDTO(toDoEntryDto);
					
					toDoCreator.addSortKeyValue(toDoType.getSortKeyTypes().iterator().next(), targetSa.getId().getTrimmedValue());
					toDoCreator.addDrillKeyValue(toDoType.getDrillKeyTypes().iterator().next(), targetSa.getId().getTrimmedValue());
					
					toDoCreator.create();
				}
			}
		}
//	}

	@Override
	public void setAdjustment(Adjustment arg0) {
		this.adj = arg0;
	}
	
    private ServiceTask createActiveQuote(ServiceAgreement sa, String quoteSource) {
        // Create Service Task
        CmCreateServiceTask createServiceTask = CmCreateServiceTask.Factory.newInstance();
        createServiceTask.setServiceTaskType(quoteServiceTaskType);
        createServiceTask.setBusinessObject(quoteBusinessObject);
        createServiceTask.setStatus(quoteBusinessObjectActiveStatus);
        createServiceTask.setCreationDateTime(this.getProcessDateTime());
        createServiceTask.setStatusDateTime(this.getProcessDateTime());
        createServiceTask.setEffectiveDateTime(this.getProcessDateTime());
        createServiceTask.setServiceAgreement(sa);
        createServiceTask.setSelection(STANDARD_CHAR_VALUE);
        createServiceTask.setSource(quoteSource);
        ServiceTask serviceTask = createServiceTask.createServiceTask();
        return serviceTask;
    }
    
    /**
     * This method retrieves GPASIC SAs of an Account.
     * Non-canceled GPASIC SAs along with their Adjustments will be canceled.
     * @param account
     */
    private void cancelServiceInstallation(Account account) {
    	ServiceAgreement_Id serviceInstallationSaId = null;
    	ServiceAgreement serviceInstallationSa = null;
    	Adjustment_Id adjId = null;
    	Adjustment adj = null;
    	
    	// Retrieve GPASIC SAs of the Account
    	StringBuilder retrieveServiceInstallationQuery = new StringBuilder();
    	retrieveServiceInstallationQuery.append("SELECT ");
    	retrieveServiceInstallationQuery.append(  "SA.SA_ID ");
    	retrieveServiceInstallationQuery.append("FROM ");
    	retrieveServiceInstallationQuery.append(  "CI_SA SA ");
    	retrieveServiceInstallationQuery.append("WHERE ");
    	retrieveServiceInstallationQuery.append(  "SA.ACCT_ID = :accountId ");
    	retrieveServiceInstallationQuery.append(  "AND SA.SA_TYPE_CD = 'GPASIC' ");
    	retrieveServiceInstallationQuery.append(  "AND SA.SA_STATUS_FLG < 60 ");
    	
    	PreparedStatement retrieveServiceInstallationStmt = 
    			createPreparedStatement(retrieveServiceInstallationQuery.toString(), getClass().getName());
    	retrieveServiceInstallationStmt.bindId("accountId", account.getId());
    	
    	for(SQLResultRow resultRow : retrieveServiceInstallationStmt.list()) {
    		serviceInstallationSaId = (ServiceAgreement_Id) resultRow.getId("SA_ID", ServiceAgreement.class);
    		serviceInstallationSa = serviceInstallationSaId.getEntity();

    		// Retrieve Adjustments of non-canceled GPASIC SAs
    		if(serviceInstallationSa.getStatus().compareTo(ServiceAgreementStatusLookup.constants.CANCELED) != 0) {
    			StringBuilder retrieveSaAdjustmentsQuery = new StringBuilder();
    			retrieveSaAdjustmentsQuery.append("SELECT ");
    			retrieveSaAdjustmentsQuery.append(  "ADJ.ADJ_ID ");
    			retrieveSaAdjustmentsQuery.append("FROM ");
    			retrieveSaAdjustmentsQuery.append(  "CI_ADJ ADJ ");
    			retrieveSaAdjustmentsQuery.append("WHERE ");
    			retrieveSaAdjustmentsQuery.append(  "ADJ.SA_ID = :saId ");
    			
    			PreparedStatement retrieveSaAdjustmentsStmt = createPreparedStatement(retrieveSaAdjustmentsQuery.toString(), getClass().getName());
    			retrieveSaAdjustmentsStmt.bindId("saId", serviceInstallationSaId);
    			
    			for(SQLResultRow resultRow2 : retrieveSaAdjustmentsStmt.list()) {
    				adjId = (Adjustment_Id) resultRow2.getId("ADJ_ID", Adjustment.class);
    				adj = adjId.getEntity();
    				
    				// Cancel GPASIC SA Adjustments
    				if(adj.getAdjustmentStatus().compareTo(AdjustmentStatusLookup.constants.CANCELED) != 0) {
    					adj.cancel(cwrAdjCanRsn);
    				}
    			}
    			// Cancel GPASIC SA
    			serviceInstallationSa.cancel(Bool.FALSE);
    			retrieveSaAdjustmentsStmt.close();
    		}
    	}
    	retrieveServiceInstallationStmt.close();
    }
    
    private ServiceAgreement createPaymentArrangementSa(Account_Id acctId, String saType, 
            Money recurringChargeAmt, String numberOfInstallments){
        ServiceAgreement_DTO saDto = createDTO(ServiceAgreement.class);
        saDto.setAccountId(acctId);
        saDto.setServiceAgreementTypeId(new ServiceAgreementType_Id(acctId.getEntity().fetchDivision(), saType));
        saDto.setStatus(ServiceAgreementStatusLookup.constants.PENDING_START);
        saDto.setStartDate(getProcessDateTime().getDate()); 
        
        saDto.setCurrencyId(acctId.getEntity().getCurrency().getId());
        saDto.setAreEstimatesAllowed(Bool.FALSE);
        saDto.setCustomerRead(CustomerReadLookup.constants.NO);
        
        ServiceAgreementCreatorData saCreatorData = ServiceAgreementCreatorData.Factory.newInstance();
        saCreatorData.setServiceAgreementDTO(saDto);
        saCreatorData.setRecurringChargeAmount(recurringChargeAmt);
        saCreatorData.setShouldCreateFieldActivity(Bool.FALSE);
        
        // Create SA
        ServiceAgreementCreator saCreator = ServiceAgreementCreator.Factory.newInstance();
        ServiceAgreement paymentArrangementSa = saCreator.addServiceAgreement(saDto, saCreatorData);
        // Add Characteristics
        ServiceAgreementCharacteristics saChars = paymentArrangementSa.getCharacteristics();
        
        CharacteristicType_Id paInstCharTypeId = new CharacteristicType_Id(PAINST);
        CharacteristicType_Id paInstatCharTypeId = new CharacteristicType_Id(PAINSTAT);
        
        addSaChar(saChars, getProcessDateTime().getDate(), paInstCharTypeId.getEntity(), numberOfInstallments);
        addSaChar(saChars, getProcessDateTime().getDate(), paInstatCharTypeId.getEntity(), recurringChargeAmt.getAmount().toString());
        
        if(!isBlankOrNull(newQuoteCwrLevel)) {
            addSaChar(saChars, getProcessDateTime().getDate(), cwrLevelCharType, newQuoteCwrLevel);
        }
        
        if(notNull(newQuoteId)) {
            addSaChar(saChars, getProcessDateTime().getDate(), quoteSrcCharType, newQuoteId.getTrimmedValue());
        }
        
        if(notNull(targetSa.getPremiseId())) {
            addSaChar(saChars, getProcessDateTime().getDate(), cwrPremiseCharType, 
                    targetSa.getPremiseId().getTrimmedValue());
        }
        
        return paymentArrangementSa;
    }
    
    /**
     * Create transfer adjustments for the Utility SA 
     */
    private void createAdjustments(ServiceAgreement gasSa, ServiceAgreement paSa) {
        // Defect	4157313 	Begin of change
        //    if (!gasSa.getCurrentBalance().isZero()) {
        // Defect	4157313 	End of change	
            CreateFrozenAdjustmentData adjustmentData = CreateFrozenAdjustmentData.Factory.newInstance();
            
            Money pledgeAmount = retrieveTotalActivePledges(gasSa);

            adjustmentData.setServiceAgreement(gasSa);
            adjustmentData.setTransferServiceAgreement(paSa);
            // Kiran 10/11/18 add adjustment amount begin
            adjustmentData.setAdjustmentAmount(gasSa.getCurrentBalance().subtract(pledgeAmount).subtract(adj.getCurrentAmount()));
            // Kiran 10/11/18 end
            adjustmentData.setAdjustmentType(paSa.getServiceAgreementType().fetchAdjustmentTypeXfer());
            adjustmentData.setAllowZeroAmount(Bool.FALSE);
            adjustmentData.setArrearsDate(getProcessDateTime().getDate());

            CreateFrozenAdjustment createFrozenAdjustment = CreateFrozenAdjustment.Factory.newInstance();
            createFrozenAdjustment.createFrozenAdjustment(adjustmentData);
            
            CreateFrozenAdjustmentData changePACurBaladjustmentData = CreateFrozenAdjustmentData.Factory.newInstance();

            changePACurBaladjustmentData.setServiceAgreement(paSa);
            changePACurBaladjustmentData.setAdjustmentAmount(paSa.getCurrentBalance().negate());
            changePACurBaladjustmentData.setAdjustmentType(paSa.getServiceAgreementType().fetchAdjustmentTypeCurrent0());
            changePACurBaladjustmentData.setAllowZeroAmount(Bool.FALSE);
            changePACurBaladjustmentData.setArrearsDate(getProcessDateTime().getDate());

            CreateFrozenAdjustment createAdjustmentForCurBalTransfer = CreateFrozenAdjustment.Factory.newInstance();
            createAdjustmentForCurBalTransfer.createFrozenAdjustment(changePACurBaladjustmentData);
       //}
    }
    
    private Money retrieveTotalActivePledges(ServiceAgreement sa) {

        Query<ServiceTask> activePledgeQuery = retrieveActivePledge(sa);
        Iterator<ServiceTask> activePledgeItr = activePledgeQuery.list().iterator();

        Money totalActivePledges = Money.ZERO;

        while(activePledgeItr.hasNext()) {
            ServiceTask pledge = (ServiceTask) activePledgeItr.next();

            ListFilter<ServiceTaskCharacteristic> pledgeCharFilter = 
            		pledge.getCharacteristics().createFilter(" where this.id.characteristicType = :pledgeAmountCharType "
            				, getClass().getName());
            pledgeCharFilter.bindEntity("pledgeAmountCharType", pledgeAmountCharType);
            ServiceTaskCharacteristic pledgeAmount = pledgeCharFilter.firstRow();
            String amount = pledgeAmount.getSearchCharacteristicValue();
            if (notBlank(amount)) {
                totalActivePledges = totalActivePledges.add(new Money(amount, sa.getCurrencyId()));
            }
        }

        return totalActivePledges;
    }
    
    private Query retrieveActivePledge(ServiceAgreement sa) {
    	
    	validateServiceTaskCharacteristicType(CmServiceTaskCharacteristicTypesLookup.constants.SA_ID_CHARACTERISTIC_TYPE.getLookupValue()
    			, saCharTypeId);
    	
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(" FROM ServiceTask st, ServiceTaskCharacteristic stc ");
        stringBuilder.append(" WHERE st.serviceTaskType = :serviceTaskType ");
        stringBuilder.append(" AND st.businessObject = :businessObject ");
        stringBuilder.append(" AND st.status = :status ");
        stringBuilder.append(" AND st.id = stc.id.serviceTask.id ");
        stringBuilder.append(" AND stc.id.characteristicType = :characteristicType ");
        stringBuilder.append(" AND stc.searchCharacteristicValue = :searchCharacteristicValue ");

        Query query = createQuery(stringBuilder.toString(), getClass().getName());
        
        query.bindEntity("serviceTaskType", pledgeServiceTaskType);
        query.bindEntity("businessObject", pledgeBusinessObject);
        query.bindStringProperty("status", ServiceTask.properties.status, pledgeBusinessObjectActiveStatus);
        query.bindEntity("characteristicType", saCharTypeId.getEntity());
        query.bindStringProperty("searchCharacteristicValue", ServiceTaskCharacteristic.properties.searchCharacteristicValue, sa.getId().getTrimmedValue());

        query.addResult("serviceTask", "st");

        return query;
    }
    
    private void validateServiceTaskCharacteristicType(LookupValue optionType, CharacteristicType_Id charTypeId) {
        if (isNull(charTypeId.getEntity())) {
            addError(CustomMessageRepository.CC_002_2_invalidCharType(optionType.fetchLanguageDescription(), charTypeId.getTrimmedValue()));
        }

        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charTypeId.getEntity(), CharacteristicEntityLookup.constants.SERVICE_TASK);
        if (isNull(charEntityId.getEntity())) {
            addError(CustomMessageRepository.CC_002_2_invalidCharTypeForEntity(charTypeId.getTrimmedValue(), "Service Task"));
        }
    }
    
    /**
     * This method will create a budget plan
     * @param accountId Account_Id
     */
    private void createBudgetPlan(Account_Id accountId){
        BusinessServiceInstance bsInstance = BusinessServiceInstance.create(BUD_PLAN_ADD_BUS_SVC);
        bsInstance.set("accountId", accountId.getTrimmedValue());   
        bsInstance.set("calcApplyBudget", Bool.TRUE);
        bsInstance.set("budgetPlan", CWR_BUD_PLAN);
        BusinessServiceDispatcher.execute(bsInstance);
    }
    
    /**
     * This method will add Payment Arrangement SA Characteristics
     * @param serviceAgreementCharacteristics ServiceAgreementCharacteristics
     * @param characteristicType CharacteristicType
     * @param characteristicValue CharacteristicValue
     */
    private void addSaChar(ServiceAgreementCharacteristics saChars, Date effDt, CharacteristicType charType, 
            String charValue) {
        ServiceAgreementCharacteristic_DTO newSAChar_DTO = saChars.newChildDTO();
        CharacteristicTypeLookup charTypeLookUp = charType.getCharacteristicType();
        
        // File Location or Adhoc
        if (charTypeLookUp.isFileLocationValue() || charTypeLookUp.isAdhocValue()) {
            newSAChar_DTO.setAdhocCharacteristicValue(charValue);
        }
        
        // Foreign Key
        if (charTypeLookUp.isForeignKeyValue()) {
            newSAChar_DTO.setCharacteristicValueForeignKey1(charValue);
        }
        
        // File Location or Adhoc
        if (charTypeLookUp.isPredefinedValue()) {
            newSAChar_DTO.setCharacteristicValue(charValue);
        }
        
        saChars.add(newSAChar_DTO, charType.getId(), effDt);
    }
    
}
