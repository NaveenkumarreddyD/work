/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Quote Cancel Algorithm
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-01-18   Srikanth        NA0085. Initial Version.
 * 2013-02-08   Srikanth        TIR - To Validate on Transactional BO code only.
 * 2015-06-05   BMarquez        SF-3220984. Moved to correct package. Altered query to 
 *                              prevent time outs.
 * 2016-01-26   MPang		  	Updated for CCB v2.4 compilation.
 * 2018-05-17   AMasil          Defect 4037401. Updated the retrieval of active Service Task 
 *                              Types to not include CSS-REC, CSS-CWR, and CSS-GPA.
 ******************************************************************************************/
package com.splwg.cm.domain.admin.serviceAgreementType;

/*
 * Start Remove - SF-3220984 - 2015-06-05
 */
//import java.util.Set;
//import com.splwg.base.api.businessObject.BusinessObjectStatusCode;
//import com.splwg.base.support.schema.BusinessObjectInfo;
//import com.splwg.base.support.schema.BusinessObjectInfoCache;
/*
 * End Remove - SF-3220984 - 2015-06-05
 */
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.BusinessObjectStatusConditionLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus_Id;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
//Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.serviceAgreementType.SaTypeBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.billing.bill.BillData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTask;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTaskCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTask_DTO;*/

import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.billCompletion.SaTypeBillCompletionAlgorithmSpot;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.billing.data.BillData;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic;
import com.splwg.base.domain.serviceTask.ServiceTask_DTO;
//End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/*
 * Start Change - SF-3220984 - 2015-06-05
 */
///**
// * @author sdesabhatl002
// *
// @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = serviceTaskType, name = quoteServiceTaskType, required = true, type = entity)
// *            , @AlgorithmSoftParameter (name = quoteActiveStatus, required = true, type = string)
// *            , @AlgorithmSoftParameter (name = quoteExpirationStatus, required = true, type = string)
// *            , @AlgorithmSoftParameter (entityName = characteristicType, name = quoteExpireSaTypeChar, required = true, type = entity)})
// */
/**
 * @author sdesabhatl002
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = serviceTaskType, name = quoteServiceTaskType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = quoteExpirationStatus, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = quoteExpireSaTypeChar, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = quoteSourceChar, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = excludeQuoteSourceCharVal, required = true, type = string)})
 */
/*
 * End Change - SF-3220984 - 2015-06-05
 */
public class CmCWRQuoteExpireBillCompletionAlgComp_Impl 
  		extends CmCWRQuoteExpireBillCompletionAlgComp_Gen
  		implements SaTypeBillCompletionAlgorithmSpot {
	
	private ServiceAgreement sa;
	private ServiceTaskType quoteServiceTaskType;
	private CharacteristicType quoteSACharType;
    // Defect 4037401 - 2018-05-17 - Start Add
	private CharacteristicType quoteSourceCharType;
	private String excludeQuoteSourceCharVal;
    // Defect 4037401 - 2018-05-17 - End Add
    /*
     * Start Remove - SF-3220984 - 2015-06-05
     */
	//private String activeStatus ;
    /*
     * End Remove - SF-3220984 - 2015-06-05
     */
	private String expireStatus;
	private BillData billData;
	private BusinessObject_Id  transSrvcTaskBOId;
	
	private static final String TASK_ID = "F1_SVC_TASK_ID";
		
    private Bool isFtProcessAdded = Bool.FALSE;
    private Bool isFtTransferred = Bool.FALSE;
    private Bool isMultiRelExists = Bool.FALSE;
	

	public Bool getAllowBillReopening() {
		 return billData.getBillDTO().getIsReopenAllowed();
	}

	public BillData getBillData() {
		return billData;
	}

	public Bool getDoMultipleBillingRelationshipsExist() {
         return isMultiRelExists;
	}

	public Bool getIsFtProcessAdded() {
		return isFtProcessAdded;
	}

	public Bool getIsFtTransferred() {
		return isFtTransferred;
	}

	public void setAccountingDate(Date arg0) {
		// TODO Auto-generated method stub

	}

	public void setBillData(BillData billData) {
	
		 this.billData=billData;
	}

	public void setBillDate(Date arg0) {
		// TODO Auto-generated method stub

	}

	public void setServiceAgreement(ServiceAgreement serviceAgrmnt) {
		   sa = serviceAgrmnt;
	}
	
    @Override
    protected void extraSoftParameterValidations(boolean arg0) {
       	initializeSoftParams();
    	CharacteristicEntity charEntity = new CharacteristicEntity_Id(quoteSACharType, CharacteristicEntityLookup.constants.SERVICE_TASK).getEntity();
    	if(isNull(charEntity)){
    		addError(CustomMessageRepository.na0085InvalidCharEntity(quoteSACharType.getId().getIdValue()));
    	}
    	
    	// Defect 4037401 - 2018-05-17 - Start Add
    	charEntity = new CharacteristicEntity_Id(quoteSourceCharType, CharacteristicEntityLookup.constants.SERVICE_TASK).getEntity();
        if(isNull(charEntity)){
            addError(CustomMessageRepository.na0085InvalidCharEntity(quoteSourceCharType.getId().getIdValue()));
        }
        
        String[] excludeQuoteSourceCharValListArray = excludeQuoteSourceCharVal.split(",");
        if(excludeQuoteSourceCharValListArray.length == 0){
            addError(CustomMessageRepository.na0085quoteSourceListInvalid(excludeQuoteSourceCharVal));
        }
    	// Defect 4037401 - 2018-05-17 - End Add
    	
    	transSrvcTaskBOId = quoteServiceTaskType.getRelatedTransactionBO().getId();
    	validateInputBoStatus();
    }
    
    private void initializeSoftParams(){
    	quoteServiceTaskType = getQuoteServiceTaskType();
        /*
         * Start Remove - SF3220984 - 2015-06-05
         */
    	//activeStatus = getQuoteActiveStatus().trim();
        /*
         * End Remove - SF3220984 - 2015-06-05
         */
    	expireStatus = getQuoteExpirationStatus().trim();
    	quoteSACharType = getQuoteExpireSaTypeChar();
    	
    	// Defect 4037401 - 2018-05-17 - Start Add
    	quoteSourceCharType = getQuoteSourceChar();
    	excludeQuoteSourceCharVal = getExcludeQuoteSourceCharVal();
    	// Defect 4037401 - 2018-05-17 - End Add
    }
    
	private void validateInputBoStatus(){
        /*
         * Start Remove - SF-3220984 - 2015-06-05
         */
		//boolean isExists = false;
        /*
         * End Remove - SF-3220984 - 2015-06-05
         */
		String svcTaskBoName = transSrvcTaskBOId.getIdValue().trim();
        /*
         * Start Remove - SF-3220984 - 2015-06-05
         */
		//BusinessObjectStatus quoteActiveStatus = new BusinessObjectStatus_Id(transSrvcTaskBOId,activeStatus).getEntity();
    	//if(isNull(quoteActiveStatus)){
    	//	addError(CustomMessageRepository.na0085InvalidInputActiveBOStatus(activeStatus,svcTaskBoName,quoteServiceTaskType.getId().getIdValue()));
    	//}
        /*
         * End Remove - SF-3220984 - 2015-06-05
         */
    	
    	BusinessObjectStatus quoteExpireStatus = new BusinessObjectStatus_Id(transSrvcTaskBOId,expireStatus).getEntity();
    	
    	if(isNull(quoteExpireStatus)){
    		addError(CustomMessageRepository.na0085InvalidInputExpireBOStatus(expireStatus,svcTaskBoName,quoteServiceTaskType.getId().getIdValue()));
    	}
    	
        /*
         * Start Remove - SF-3220984 - 2015-06-05
         */
    	//BusinessObjectInfo info = BusinessObjectInfoCache.getBusinessObjectInfo(svcTaskBoName);
    	//Set<BusinessObjectStatusCode> nextStates = info.getAllowedStatusTransitionsFrom(new BusinessObjectStatusCode(quoteActiveStatus));
    	//
    	//for(BusinessObjectStatusCode statusCode :nextStates){
    	//	if(statusCode.getStatusString().trim().equalsIgnoreCase(expireStatus)){
    	//		isExists = true;
    	//		break;
    	//	}
    	//}
    	//if(!isExists)
    	//   addError(CustomMessageRepository.na0085InvalidNextStatusSpecified(activeStatus,expireStatus,svcTaskBoName,quoteServiceTaskType.getId().getIdValue()));
    	/*
         * End Remove - SF-3220984 - 2015-06-05 
    	 */
	}

	public void invoke() {
		ServiceTask svcTask = null;
		ServiceTask_DTO svcTaskdto = null;
		
		List<SQLResultRow> activeServiceTasks = getActiveServiceTasksForSA();
		
		for(SQLResultRow resultRow :activeServiceTasks ){
			    svcTask = resultRow.getEntity(TASK_ID, ServiceTask.class);
			    svcTaskdto = svcTask.getDTO();
		        svcTaskdto.setStatus(expireStatus);
		        svcTask.setDTO(svcTaskdto);
		        svcTask=null;
    	}
    }
	
	// Defect 4037401 - 2018-05-17 - Start Add
	/**
     * This method splits the parameter and returns as parameters for queries
     * @return String
     */
    private String parseParamaterToQueryParm(String parameter){
        StringBuilder queryParm = new StringBuilder();

        String[] valueList =  parameter.split(",");

        for(String value : valueList){
            if(queryParm.length() == 0){
                queryParm.append("\'");
                queryParm.append(value.trim());
                queryParm.append("\'");
            } else {
                queryParm.append(",\'");
                queryParm.append(value.trim());
                queryParm.append("\'");
            }
        }
        return queryParm.toString();
    }
    // Defect 4037401 - 2018-05-17 - End Add
	
	private List<SQLResultRow> getActiveServiceTasksForSA(){
		
        List<SQLResultRow> resultRow = null;
        StringBuilder activeSvcTaskQuery = new StringBuilder();
        /*
         * Start Change - SF-3220984 - 2015-06-05
         */
        //activeSvcTaskQuery.append("SELECT TASK.F1_SVC_TASK_ID ") ;
        //activeSvcTaskQuery.append("FROM F1_SVC_TASK TASK,F1_SVC_TASK_CHAR TASKCHAR ");
        //activeSvcTaskQuery.append("WHERE TASK.F1_STASK_TYPE_CD = :taskTypeCd ");
        //activeSvcTaskQuery.append("AND TASK.BUS_OBJ_CD = :boCode ");
        //activeSvcTaskQuery.append("AND TRIM(TASK.BO_STATUS_CD) = :activeStatus ");
        //activeSvcTaskQuery.append("AND TASK.F1_SVC_TASK_ID = TASKCHAR.F1_SVC_TASK_ID ");
        //activeSvcTaskQuery.append("AND TASKCHAR.CHAR_TYPE_CD = :inputCharType ");
        //activeSvcTaskQuery.append("AND TRIM(TASKCHAR.CHAR_VAL_FK1) = :saId ");
        
        activeSvcTaskQuery.append("SELECT TASK.F1_SVC_TASK_ID ") ;
        activeSvcTaskQuery.append("FROM F1_SVC_TASK TASK,F1_SVC_TASK_CHAR TASKCHAR ");
        activeSvcTaskQuery.append(", F1_BUS_OBJ_STATUS BOSTAT ");
        activeSvcTaskQuery.append("WHERE TASK.F1_STASK_TYPE_CD = :taskTypeCd ");
        activeSvcTaskQuery.append("AND BOSTAT.BUS_OBJ_CD = TASK.BUS_OBJ_CD ");
        activeSvcTaskQuery.append("AND BOSTAT.BO_STATUS_CD = TASK.BO_STATUS_CD ");
        activeSvcTaskQuery.append("AND BOSTAT.BO_STATUS_COND_FLG <> :finalBoStatusCondition ");
        activeSvcTaskQuery.append("AND TASK.F1_SVC_TASK_ID = TASKCHAR.F1_SVC_TASK_ID ");
        activeSvcTaskQuery.append("AND TASKCHAR.CHAR_TYPE_CD = :inputCharType ");
        activeSvcTaskQuery.append("AND TASKCHAR.SRCH_CHAR_VAL = :saId ");
        /*
         * End Change - SF-3220984 - 2015-06-05
         */
        // Defect 4037401 - 2018-05-17 - Start Add
        activeSvcTaskQuery.append("AND EXISTS (SELECT 'X' ");
        activeSvcTaskQuery.append("            FROM F1_SVC_TASK_CHAR STC ");
        activeSvcTaskQuery.append("            WHERE STC.F1_SVC_TASK_ID = TASK.F1_SVC_TASK_ID ");
        activeSvcTaskQuery.append("            AND STC.CHAR_TYPE_CD = :quoteSourceCharType ");
        activeSvcTaskQuery.append("            AND STC.SRCH_CHAR_VAL NOT IN (" + parseParamaterToQueryParm(excludeQuoteSourceCharVal) + ") ");
        activeSvcTaskQuery.append(") ");
        // Defect 4037401 - 2018-05-17 - End Add
        
        //Start Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        // PreparedStatement svcTaskPrepStmt = createPreparedStatement(activeSvcTaskQuery.toString());
        PreparedStatement svcTaskPrepStmt = createPreparedStatement(activeSvcTaskQuery.toString(), getClass().getName());
        //End Change - 2016-01-26 - MPang - Updated for Updated for CCB v2.4 compilation
        svcTaskPrepStmt.bindId("taskTypeCd", quoteServiceTaskType.getId());
        /*
         * Start Change - SF-3220984 - 2015-06-05
         */
        //svcTaskPrepStmt.bindId("boCode",transSrvcTaskBOId);
        //svcTaskPrepStmt.bindStringProperty("activeStatus", ServiceTask.properties.status , activeStatus);
        //svcTaskPrepStmt.bindStringProperty("saId",ServiceTaskCharacteristic.properties.adhocCharacteristicValue, sa.getId().getIdValue().trim());
        svcTaskPrepStmt.bindLookup("finalBoStatusCondition", BusinessObjectStatusConditionLookup.constants.FINAL);
        svcTaskPrepStmt.bindStringProperty("saId",ServiceTaskCharacteristic.properties.searchCharacteristicValue, sa.getId().getIdValue().trim());
        /*
         * End Change - SF-3220984 - 2015-06-05
         */
        svcTaskPrepStmt.bindEntity("inputCharType",quoteSACharType);
        
        // Defect 4037401 - 2018-05-17 - Start Add
        svcTaskPrepStmt.bindId("quoteSourceCharType", quoteSourceCharType.getId());
        // Defect 4037401 - 2018-05-17 - End Add
       
        resultRow = svcTaskPrepStmt.list();
                       
        svcTaskPrepStmt.close();
        return resultRow;
	}


}
