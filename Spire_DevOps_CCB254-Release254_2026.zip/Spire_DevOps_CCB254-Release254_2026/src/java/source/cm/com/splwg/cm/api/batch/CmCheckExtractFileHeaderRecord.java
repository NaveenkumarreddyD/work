/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Column Delimited Record class for File Header
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-05-27   RDizon  CCB041. Initial version.        
 **************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

/**
 * @author RDizon
 */
public class CmCheckExtractFileHeaderRecord extends ColumnDelimitedRecord {
    
    private static final String DELIMITER = "|";
        
    public CmCheckExtractFileHeaderRecord() {
        super(3);
    }
    
    public void setHRVald(String value) {
        this.leftPadColumn(1, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setFileGenerationDate(String value) {
        this.leftPadColumn(2, value.length() + 1, value.trim() + DELIMITER);
    }
    
    public void setFileGenerationTimestamp(String value) {
        this.leftPadColumn(3, value.length() + 1, value.trim());
    }
    
}
