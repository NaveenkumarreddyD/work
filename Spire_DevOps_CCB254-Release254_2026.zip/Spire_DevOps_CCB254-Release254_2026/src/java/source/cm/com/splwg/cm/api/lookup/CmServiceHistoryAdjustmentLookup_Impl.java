/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Service History Adjustment Lookup
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-01-25   Neha    NA0073. Initial Version.
 **************************************************************************/
package com.splwg.cm.api.lookup;

/**
 * 
 * @LookupFieldname (value = CM_SVC_HIST_ADJ_FLG)
 */
public class CmServiceHistoryAdjustmentLookup_Impl 
        extends CmServiceHistoryAdjustmentLookup_Gen {

}
