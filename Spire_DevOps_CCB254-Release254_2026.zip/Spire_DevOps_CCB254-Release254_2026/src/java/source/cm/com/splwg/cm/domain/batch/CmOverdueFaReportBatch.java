/* **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 * This custom batch process will Create a To Do when field activities are 
 * in a pending or held status and scheduled date is eight days past.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:        	 Reason:
 * YYYY-MM-DD   IN         	 Reason text.
 *
 * 2018-10-30   MPang        SA-241627. Initial Version.
 * 2020-10-23   JRaymu       B-17231. Overdue FA Batch Job Updates.
 * 2020-11-16   JRaymu       B-17231.Defect1 Overdue FA Batch Job Optimization.
 * 2020-11-23   JRaymu       B-17231.Defect2 Optimize execute work unit
 * ************************************************************************/
package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.util.StringTokenizer;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessService.BusinessServiceDispatcher;
import com.splwg.base.api.businessService.BusinessServiceInstance;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_Id;
import com.splwg.base.domain.batch.batchControl.BatchControlParameter_LanguageId;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.Message_Id;
import com.splwg.base.domain.database.field.Field_Id;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTaskRelatedObject;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoDrillKeyValue;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.base.domain.todo.toDoType.ToDoType_Id;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.domain.admin.dispatchGroup.entity.DispatchGroup;
import com.splwg.ccb.domain.admin.dispatchGroup.entity.DispatchGroup_Id;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType_Id;
import com.splwg.ccb.domain.common.data.FeatureConfigurationOptionData;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_Id;
import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
import com.splwg.cm.api.lookup.OverdueFAOptionsLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ServerMessage;

/**
 * @author Administrator
 *
@BatchJob (rerunnable = false, modules={},
 *      softParameters = { @BatchJobSoftParameter (name = FA_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = DAYS_OVERDUE, required = true, type = integer)
 *            , @BatchJobSoftParameter (entityName = toDoType, name = TO_DO_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = role, name = TO_DO_ROLE, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = FEATURE_CONFIG, required = true, type = entity)})
 */
public class CmOverdueFaReportBatch extends CmOverdueFaReportBatch_Gen {
	// Soft Parameters
	private String parmFaStatus;
	private BigInteger parmDaysOverdue;
	private ToDoType parmToDoType;
	private Role parmToDoRole;
    // START ADD - JRAYMU - 2020-10-23 - B-17231
	private FeatureConfiguration featureConf;
    // END ADD - JRAYMU - 2020-10-23 - B-17231
	
	// Constants
	private static final String COMMA_DELIMITER = ",";
	private static final String SINGLE_QUOTE = "'";
	private static final String RETRIEVE_ADDRESS_FOR_FA_BS = "C1-RetrieveAddressForFA";
    // START ADD - JRAYMU - 2020-10-23 - B-17231
	private static final String FIELD_ACTIVITY_TYP_STR = "Field Activity Type";
	private static final String DISPATCH_GRP_STR = "Dispatch Group";
	private static final String TODO_TYP_STR = "To Do Type";
    // END ADD - JRAYMU - 2020-10-23 - B-17231
	
	// Work Variable
	private String faStatuses;
    // START ADD - JRAYMU - 2020-10-23 - B-17231
	private String excludedFATypes;
	private String excludedDispGrp;
    // END ADD - JRAYMU - 2020-10-23 - B-17231
	
	public JobWork getJobWork() {

	    // START CHANGE - JRAYMU - 2020-10-23 - B-17231
		//		PreparedStatement getFas = createPreparedStatement(
		//				"SELECT FA.FA_ID " +
		//						"FROM CI_FA FA " +
		//						"WHERE FA.FA_STATUS_FLG IN (" +faStatuses+ ")" +
		//						"AND TRUNC(FA.SCHED_DTTM) < :pastXdays	" +
		//						"AND NOT EXISTS (SELECT 'X'	" +
		//						"                FROM CI_TD_ENTRY TDE, CI_TD_DRLKEY TDD " +
		//						"                WHERE TDE.TD_TYPE_CD = :todoTypeCd " +
		//						"                AND TDE.BATCH_CD = :batchCode " +
		//						"                AND TDE.TD_ENTRY_ID = TDD.TD_ENTRY_ID " +
		//						"                AND TRIM(TDD.KEY_VALUE) = TRIM(FA.FA_ID)" +
		//						"                )"
		//						, getClass().getName());
		StringBuilder queryString = new StringBuilder();
		queryString.append("SELECT FA.FA_ID ");
		queryString.append("FROM CI_FA FA ");
		queryString.append("WHERE FA.FA_STATUS_FLG IN (" +faStatuses+ ") ");
		queryString.append("AND TRUNC(FA.SCHED_DTTM) < :pastXdays ");  
        queryString.append("AND FA.FA_TYPE_CD NOT IN (" + excludedFATypes + ") ");
        if(!isBlankOrNull(excludedDispGrp)){
            queryString.append("AND FA.DISP_GRP_CD NOT IN (" + excludedDispGrp +") ");
        }
        // START CHANGE - JRAYMU - 2020-11-16 - B-17231.Defect1
        //		queryString.append("AND NOT EXISTS (SELECT 'X'                     ");
        //		queryString.append("   FROM CI_TD_ENTRY TDE, CI_TD_DRLKEY TDD      ");
        //		queryString.append("   WHERE TDE.TD_TYPE_CD = :todoTypeCd          ");
        //		queryString.append("   AND TDE.BATCH_CD = :batchCode               ");
        //		queryString.append("   AND TDE.TD_ENTRY_ID = TDD.TD_ENTRY_ID       ");
        //		queryString.append("   AND TDE.ENTRY_STATUS_FLG <> :complete       ");
        //		queryString.append("   AND TRIM(TDD.KEY_VALUE) = TRIM(FA.FA_ID))   ");	
        queryString.append("AND NOT EXISTS (select 'x' FROM CI_TD_DRLKEY TDD ");
        queryString.append(    "WHERE TDD.KEY_VALUE = FA.FA_ID ");
        queryString.append(    "AND EXISTS (SELECT 'x' ");
        queryString.append(        "FROM CI_TD_ENTRY TDE ");
        queryString.append(        "WHERE TDE.TD_ENTRY_ID = TDD.TD_ENTRY_ID ");
        queryString.append(        "AND TDE.TD_TYPE_CD = :todoTypeCd ");
        queryString.append(        "AND TDE.ENTRY_STATUS_FLG <> :complete ");
        queryString.append(        "AND TDE.BATCH_CD = :batchCode)) ");
        
        // END CHANGE - JRAYMU - 2020-11-16 - B-17231.Defect1
		
		PreparedStatement getFas = createPreparedStatement(queryString.toString(), getClass().getName());
	    // END CHANGE - JRAYMU - 2020-10-23 - B-17231
		getFas.bindDate("pastXdays", getProcessDateTime().getDate().addDays(parmDaysOverdue.negate().intValue()));
	    // START ADD - JRAYMU - 2020-10-23 - B-17231
		getFas.bindLookup("complete", ToDoEntryStatusLookup.constants.COMPLETED);
	    // END ADD - JRAYMU - 2020-10-23 - B-17231
		getFas.bindEntity("todoTypeCd", parmToDoType);
		getFas.bindEntity("batchCode", getBatchControlId().getEntity());

        // START DELETE - JRAYMU - 2020-11-16 - B-17231.Defect1
		// List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();
        // DELETE DELETE - JRAYMU - 2020-11-16 - B-17231.Defect1

		QueryIterator iter = getFas.iterate();
        // START DELETE - JRAYMU - 2020-11-16 - B-17231.Defect1
        //		while (iter.hasNext()) {
        //			SQLResultRow row = iter.next();
        //
        //			ThreadWorkUnit workUnit = new ThreadWorkUnit();
        //			workUnit.setPrimaryId((FieldActivity_Id) row.getId("FA_ID", FieldActivity.class));
        //
        //			workUnits.add(workUnit);              
        //		}
		// iter.close();
		// return createJobWorkForThreadWorkUnitList(workUnits);  
        // END DELETE - JRAYMU - 2020-11-16 - B-17231.Defect1
		return createJobWorkForQueryIterator(iter, this);

	}

    // START ADD - JRAYMU - 2020-11-16 - B-17231.Defect1
    public ThreadWorkUnit createWorkUnit(QueryResultRow row) {
        ThreadWorkUnit threadUnit = new ThreadWorkUnit();
        FieldActivity_Id faId = (FieldActivity_Id) row.getId("FA_ID", FieldActivity.class); 
        threadUnit.setPrimaryId(faId);
        return threadUnit;
    }
    // END ADD - JRAYMU - 2020-11-16 - B-17231.Defect1
	
	 /**
     * This method Retrieves the Batch Parameter Name
     * @param numSeq
     * @return
     */
    private String getBatchParameterName(int numSeq){

        String parmName = "";
        
        BatchControlParameter_Id batchControlParameter_Id = 
                new BatchControlParameter_Id(this.getBatchControlId(), BigInteger.valueOf(numSeq));        
        BatchControlParameter_LanguageId batchControlParameterLanguageId = 
                new BatchControlParameter_LanguageId(batchControlParameter_Id, getActiveContextLanguage().getId());
        parmName = batchControlParameterLanguageId.getParent().fetchLanguageDescription();
        
        return parmName;
    }
    

	public Class<CmOverdueFaReportBatchWorker> getThreadWorkerClass() {
		return CmOverdueFaReportBatchWorker.class;
	}
	
	@Override
	public void validateSoftParameters(boolean isNewRun) {

		// Validate Parameter SA Status
		String faStatusStr = "";
		FieldActivityStatusLookup faStatusLookup = null;
		StringBuilder faStrBuilder = new StringBuilder();
		
		parmFaStatus = getParameters().getFA_STATUS();
		StringTokenizer faStatusStrTokenizer = new StringTokenizer(parmFaStatus, COMMA_DELIMITER);
		int faStatusCount = faStatusStrTokenizer.countTokens();
		if(faStatusCount < 1) {
			addError(CustomMessageRepository.SA241627_parameterNotPopulated(getBatchParameterName(10)));
		}
		
		for(int i = 0; i < faStatusCount; i++) {
			faStatusStr = faStatusStrTokenizer.nextToken().trim();
			faStatusLookup = LookupHelper.getLookupInstance(FieldActivityStatusLookup.class, faStatusStr);
			if(!faStatusLookup.isValidLookupValue()) {
				addError(CustomMessageRepository.SA241627_parameterInvalid(getBatchParameterName(10), faStatusStr));
			} else {
    			faStrBuilder.append(SINGLE_QUOTE);
    			faStrBuilder.append(faStatusStr);
    			faStrBuilder.append(SINGLE_QUOTE);
	            if (faStatusStrTokenizer.hasMoreTokens()) {
	            	faStrBuilder.append(COMMA_DELIMITER);
	            }
			}
		}
		faStatuses = faStrBuilder.toString();

		// Validate Parameter Days Overdue
		parmDaysOverdue = getParameters().getDAYS_OVERDUE();
		
		if(parmDaysOverdue.intValue() < 0) {
			addError(CustomMessageRepository.SA241627_mustBeGreaterOrEqualToZero(getBatchParameterName(20)));
		}

		// Validate Parameter To Do Type
		parmToDoType = getParameters().getTO_DO_TYPE();

		// Validate Parameter To Do Role
		parmToDoRole = getParameters().getTO_DO_ROLE();

		// Checks Parameter To Do Role if valid for Parameter To Do Role
		if(notNull(parmToDoRole)) {
			ToDoTypeRole_Id toDoTypeRoleId = new ToDoTypeRole_Id(parmToDoType, parmToDoRole);
			if(isNull(toDoTypeRoleId.getEntity())) {
				addError(CustomMessageRepository.SA241627_toDoRoleInvalidForToDoType(
						getBatchParameterName(40), parmToDoRole.getId().getIdValue().trim()
						, getBatchParameterName(30), parmToDoType.getId().getIdValue().trim()));

			}
		}
	    // START ADD - JRAYMU - 2020-10-23 - B-17231
		// Validate feature configuration values
		featureConf = getParameters().getFEATURE_CONFIG();
		validateFeatureConfOptions(featureConf.getId());
		
	    // END ADD - JRAYMU - 2020-10-23 - B-17231
	}
    // START ADD - JRAYMU - 2020-10-23 - B-17231
	private void validateFeatureConfOptions(FeatureConfiguration_Id featureConfId){

		CmMGEFeatureConfigurationOptionsRetriever featOptRet = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
		// Validate FA Types 
		List<FeatureConfigurationOptionData> faTypeOpts = featOptRet.getFeatureOptionValueList(featureConfId, OverdueFAOptionsLookup.constants.EXCLUDED_FA_TYPE);
		int index = 0;
		int listSize = faTypeOpts.size();
		StringBuilder stringBuilder = new StringBuilder();
		for(FeatureConfigurationOptionData featOpt : faTypeOpts){
			index++;
			String optVal = featOpt.getOptionValue();
			FieldActivityType faType = new FieldActivityType_Id(optVal).getEntity();
			if(isNull(faType)){
				// Option value (%1) for option type (%2) is not a valid (%3) in Feature Configuration %4.
				addError(CustomMessageRepository.B17231_FeatConfOptNotValid(optVal, 
						OverdueFAOptionsLookup.constants.EXCLUDED_FA_TYPE.getLookupValue().fetchLanguageDescription(), FIELD_ACTIVITY_TYP_STR, featureConfId.getIdValue()));
			}else{
				stringBuilder.append(SINGLE_QUOTE);
				stringBuilder.append(optVal);
				stringBuilder.append(SINGLE_QUOTE);
				if(index < listSize){
					stringBuilder.append(COMMA_DELIMITER);
				}
			}
		}
		excludedFATypes = stringBuilder.toString();
		
		// Validate dispatch groups
		List<FeatureConfigurationOption> dispatchGrpOpts = featureConfId.getEntity().getOptions(OverdueFAOptionsLookup.constants.EXCLUDED_FA_DISPATCH_GRP);
		index = 0;
		listSize = dispatchGrpOpts.size();
		stringBuilder = new StringBuilder();
		for(FeatureConfigurationOption featOpt : dispatchGrpOpts){
			index++;
			String optVal = featOpt.getValue();
			DispatchGroup dispatchGrp = new DispatchGroup_Id(optVal).getEntity();
			if(isNull(dispatchGrp)){
				// Option value (%1) for option type (%2) is not a valid (%3) in Feature Configuration %4.
				addError(CustomMessageRepository.B17231_FeatConfOptNotValid(optVal, 
						OverdueFAOptionsLookup.constants.EXCLUDED_FA_DISPATCH_GRP.getLookupValue().fetchLanguageDescription(), DISPATCH_GRP_STR, featureConfId.getIdValue()));
			}else{
				stringBuilder.append(SINGLE_QUOTE);
				stringBuilder.append(optVal);
				stringBuilder.append(SINGLE_QUOTE);
				if(index < listSize){
					stringBuilder.append(COMMA_DELIMITER);
				}
			}
		}
		excludedDispGrp = stringBuilder.toString();
		// Validate To Do Types
		List<FeatureConfigurationOptionData> todoTypOpts = featOptRet.getFeatureOptionValueList(featureConfId, OverdueFAOptionsLookup.constants.EXCLUDED_TO_DO_TYPE);
		for(FeatureConfigurationOptionData featOpt : todoTypOpts){
			index++;
			String optVal = featOpt.getOptionValue();
			com.splwg.base.domain.todo.toDoType.ToDoType tdType = new ToDoType_Id(optVal).getEntity();
			if(isNull(tdType)){
				// Option value (%1) for option type (%2) is not a valid (%3) in Feature Configuration %4.
				addError(CustomMessageRepository.B17231_FeatConfOptNotValid(optVal, 
						OverdueFAOptionsLookup.constants.EXCLUDED_TO_DO_TYPE.getLookupValue().fetchLanguageDescription(), TODO_TYP_STR, featureConfId.getIdValue()));
			}
		}
	}
    // END ADD - JRAYMU - 2020-10-23 - B-17231

	public static class CmOverdueFaReportBatchWorker extends
			CmOverdueFaReportBatchWorker_Gen {

		// Soft Parameters
        // START DELETE - JRAYMU - 2020-11-16 - B-17231.Defect1
		// private String parmFaStatus;
		// private BigInteger parmDaysOverdue;
        // END DELETE - JRAYMU - 2020-11-16 - B-17231.Defect1
		private ToDoType parmToDoType;
		private Role parmToDoRole;
	    // START ADD - JRAYMU - 2020-10-23 - B-17231
		// Constants
		private static final Field_Id FA_ID = new Field_Id("FA_ID");
		private static final Field_Id MTR_ID = new Field_Id("MTR_ID");
		private static final Field_Id PREM_ID = new Field_Id("PREM_ID");
		private static final Field_Id F1_SVC_TASK_ID = new Field_Id("F1_SVC_TASK_ID");
		
		// Work Variable 
		private StringBuilder excludedTDTypesFAId = new StringBuilder();
		private StringBuilder excludedTDTypesPremId = new StringBuilder();
		private StringBuilder excludedTDTypesMeterId = new StringBuilder();
		private StringBuilder excludedTDTypesSvcTskId = new StringBuilder();
	    // END ADD - JRAYMU - 2020-10-23 - B-17231
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new StandardCommitStrategy(this);
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {
			FieldActivity_Id fieldActitivityId = (FieldActivity_Id) unit.getPrimaryId();
			FieldActivity fieldActivity = fieldActitivityId.getEntity();
			
		    // START CHANGE - JRAYMU - 2020-10-23 - B-17231
			// Check if the FA already has an existing TD Type and TD Type is in exclude TD Type list
			// Create To Do Entry
			// addToDoEntry(fieldActivity);
			Bool isActiveTDTypeExcluded = isActiveTDTypeExcluded(fieldActivity);
			if(isActiveTDTypeExcluded.isFalse()){
				// Create To Do Entry
				addToDoEntry(fieldActivity);
			}
		    // END CHANGE - JRAYMU - 2020-10-23 - B-17231
			return true;
		}
		
	    // START ADD - JRAYMU - 2020-10-23 - B-17231
		private Bool isActiveTDTypeExcluded(FieldActivity fieldActivity){
			ServicePoint_Id spId = fieldActivity.getServicePoint().getId();
			String faIdString = fieldActivity.getId().getTrimmedValue();
			String premiseIdString = spId.getEntity().getPremise().getId().getTrimmedValue();
			Bool isActiveTDTypeExcluded= Bool.FALSE;

			if(excludedTDTypesFAId.length() > 0){
				// If TD drill key field is FA_ID
				isActiveTDTypeExcluded = hasActiveTDgivenDrillKeyVal(excludedTDTypesFAId, faIdString);				
			}
			if (excludedTDTypesPremId.length() > 0 && isActiveTDTypeExcluded.isFalse()){
				// If TD drill key field is PREM_ID
				isActiveTDTypeExcluded = hasActiveTDgivenDrillKeyVal(excludedTDTypesPremId, premiseIdString);	
			}
			if (excludedTDTypesMeterId.length() > 0 && isActiveTDTypeExcluded.isFalse()){
				// If TD drill key field is MTR_ID    
				// Get Meter from the SP ID
				Meter_Id latestMeterIdForSP = getLatestMeterForSP(spId);
				if(notNull(latestMeterIdForSP)){
					isActiveTDTypeExcluded = hasActiveTDgivenDrillKeyVal(excludedTDTypesMeterId, latestMeterIdForSP.getTrimmedValue());
				}
			}
			if (excludedTDTypesSvcTskId.length() > 0 && isActiveTDTypeExcluded.isFalse()){
				// If TD drill key field is F1_SVC_TASK_ID
				List<SQLResultRow> results = getServiceTaskGivnFaId(faIdString);
				for(SQLResultRow result : results){
					ServiceTask_Id serviceTaskId = (ServiceTask_Id)result.getId("F1_SVC_TASK_ID", ServiceTask.class);
					if(isActiveTDTypeExcluded.isTrue()){
						break;
					}
					isActiveTDTypeExcluded = hasActiveTDgivenDrillKeyVal(excludedTDTypesSvcTskId, serviceTaskId.getTrimmedValue());	
				}
				
			}
			return isActiveTDTypeExcluded;
		}
		
		private Bool hasActiveTDgivenDrillKeyVal(StringBuilder excludeTdTypeStr, String drillKeyVal){
			StringBuilder queryString = new StringBuilder();
		    // START CHANGE - JRAYMU - 2020-11-16 - B-17231.Defect2
            //			queryString.append("SELECT 'X' FROM CI_TD_ENTRY TDE, CI_TD_DRLKEY TDD ");
            //			queryString.append("WHERE TDE.TD_TYPE_CD IN (" + excludeTdTypeStr.substring(0, excludeTdTypeStr.length()-1) + ") ");
            //			queryString.append("AND TDE.TD_ENTRY_ID = TDD.TD_ENTRY_ID ");
            //			queryString.append("AND TDE.ENTRY_STATUS_FLG <> :complete ");
            //			queryString.append("AND TRIM(TDD.KEY_VALUE) = :drillKeyVal ");
			queryString.append("SELECT 'x' FROM CI_TD_DRLKEY TDD ");
	        queryString.append("WHERE TDD.KEY_VALUE = :drillKeyVal ");
	        queryString.append("AND EXISTS (SELECT 'x' ");
	        queryString.append(    "FROM CI_TD_ENTRY TDE ");
	        queryString.append(    "WHERE TDE.TD_ENTRY_ID = TDD.TD_ENTRY_ID ");
	        queryString.append(    "AND TDE.TD_TYPE_CD IN (" + excludeTdTypeStr.substring(0, excludeTdTypeStr.length()-1) + ") ");
	        queryString.append(    "AND TDE.ENTRY_STATUS_FLG <> :complete) ");
		    // END CHANGE - JRAYMU - 2020-11-16 - B-17231.Defect2
			
			PreparedStatement retrieveActiveTdFAId = createPreparedStatement(queryString.toString(), getClass().getName());
			retrieveActiveTdFAId.bindStringProperty("drillKeyVal", ToDoDrillKeyValue.properties.keyValue, drillKeyVal);
			retrieveActiveTdFAId.bindLookup("complete", ToDoEntryStatusLookup.constants.COMPLETED);
			int listSize = retrieveActiveTdFAId.list().size();
			retrieveActiveTdFAId.close();
			return (listSize > 0) ? Bool.TRUE: Bool.FALSE;
			
		}
		private Meter_Id getLatestMeterForSP(ServicePoint_Id spId){
			StringBuilder queryString = new StringBuilder();
			queryString.append("SELECT MTRCNF.MTR_ID ");
			queryString.append("FROM CI_SP_MTR_HIST HIST, CI_MTR_CONFIG MTRCNF ");
			queryString.append("WHERE HIST.SP_ID = :spId ");
			queryString.append("AND MTRCNF.MTR_CONFIG_ID = HIST.MTR_CONFIG_ID ");
			queryString.append("AND HIST.REMOVAL_DTTM IS NULL ");
                    
			PreparedStatement getLatestMeterForSP = createPreparedStatement(queryString.toString(), getClass().getName());
			getLatestMeterForSP.bindId("spId", spId);

			SQLResultRow resultList = getLatestMeterForSP.firstRow();
			getLatestMeterForSP.close();                    
			return (notNull(resultList)) ? (Meter_Id)resultList.getId("MTR_ID", Meter.class): null;
			
		}
		private List<SQLResultRow> getServiceTaskGivnFaId(String faId){
			StringBuilder queryString = new StringBuilder();
			queryString.append("SELECT RELOBJ.F1_SVC_TASK_ID ");
			queryString.append("FROM F1_SVC_TASK_REL_OBJ RELOBJ ");
			queryString.append("WHERE RELOBJ.PK_VALUE1 = :faId ");
			queryString.append("AND RELOBJ.MAINT_OBJ_CD = 'FA' ");
			PreparedStatement retrieveSvcTaskGvnFa = createPreparedStatement(queryString.toString(), getClass().getName());
			retrieveSvcTaskGvnFa.bindStringProperty("faId", ServiceTaskRelatedObject.properties.primaryKeyValue1, faId);

			List<SQLResultRow> serviceTasks = retrieveSvcTaskGvnFa.list();
			retrieveSvcTaskGvnFa.close();
			return serviceTasks;
		} 
	    // END ADD - JRAYMU - 2020-10-23 - B-17231
		/**
		 * This method creates a To Do Entry
		 * @param fieldActivity
		 * @return
		 */
		private ToDoEntry addToDoEntry(FieldActivity fieldActivity) {

			ToDoType toDoType = getParameters().getTO_DO_TYPE();

			ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
			ToDoEntry_DTO toDoEntryDTO = toDoCreator.getToDoDTO();

			toDoEntryDTO.setBatchControlId(getBatchControlId());
			toDoEntryDTO.setBatchNumber(getBatchNumber());            
			toDoEntryDTO.setCreationDateTime(getProcessDateTime());
			
			 // Call the Quote Info Business Service for the new quote
            BusinessServiceInstance bsInstance = BusinessServiceInstance.create(RETRIEVE_ADDRESS_FOR_FA_BS);
            bsInstance.set("fieldActivityId", fieldActivity.getId().getIdValue().trim());
            BusinessServiceInstance result = BusinessServiceDispatcher.execute(bsInstance);
            // Get CWR level of the new quote
            String address = result.getList("results").iterator().next().getString("address");
			ServerMessage msg = CustomMessageRepository.SA241627_faIsPastDue(
					fieldActivity.getFieldActivityType().getId().getIdValue().trim(),
					fieldActivity.getId().getIdValue().trim(), 
					address, 
					fieldActivity.getFieldActivityStatus().getLookupValue().fetchLanguageDescription().trim(), 
					fieldActivity.getScheduleDateTimeStart().getDate().toString());
			MessageCategory_Id msgCatId = new MessageCategory_Id(msg.getCategory());
			Message_Id messageId = new Message_Id(msgCatId, msg.getNumber());
			toDoEntryDTO.setMessageId(messageId);   
			for(Iterator iter = msg.getMessageParameters().iterator(); iter.hasNext();){
				toDoCreator.addMessageParameter(iter.next().toString());
			}
			
			toDoEntryDTO.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
			toDoEntryDTO.setToDoTypeId(toDoType.getId());

			// If parmToDoRole is not null then assigned to the toDoEntryDto
			if(notNull(parmToDoRole)){
				toDoEntryDTO.setToDoRoleId(parmToDoRole.getId());
			}

			toDoCreator.setToDoDTO(toDoEntryDTO);  
			
			//Add drill key
			Iterator<ToDoDrillKeyType> drillKeyIterator = parmToDoType.getId().getEntity().getDrillKeyTypes().iterator();
			toDoCreator.addDrillKeyValue(drillKeyIterator.next(), fieldActivity.getId().getIdValue().trim());
			//Add sort key
			Iterator<ToDoSortKeyType> sortKeyIterator = parmToDoType.getId().getEntity().getSortKeyTypes().iterator();
			toDoCreator.addSortKeyValue(sortKeyIterator.next(), fieldActivity.getId().getIdValue().trim());
			toDoCreator.addSortKeyValue(sortKeyIterator.next(), fieldActivity.getFieldActivityType().getId().getIdValue().trim());
			return toDoCreator.create();
		}

		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful)
						throws ThreadAbortedException, RunAbortedException {
	        // START DELETE - JRAYMU - 2020-11-16 - B-17231.Defect1
			// parmFaStatus = getParameters().getFA_STATUS();
			// parmDaysOverdue = getParameters().getDAYS_OVERDUE();
	        // END DELETE - JRAYMU - 2020-11-16 - B-17231.Defect1
			parmToDoType = getParameters().getTO_DO_TYPE();
			parmToDoRole = getParameters().getTO_DO_ROLE();

		    // START ADD - JRAYMU - 2020-10-23 - B-17231
			// Populate exclude td types list
			CmMGEFeatureConfigurationOptionsRetriever featOptRet = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
			List<FeatureConfigurationOptionData> todoTypOpts = featOptRet.getFeatureOptionValueList(getParameters().getFEATURE_CONFIG().getId(), OverdueFAOptionsLookup.constants.EXCLUDED_TO_DO_TYPE);
			for(FeatureConfigurationOptionData featOpt : todoTypOpts){
				String optVal = featOpt.getOptionValue();
				ToDoType_Id tdTypeId = new ToDoType_Id(optVal);
				// Get drill key
				ToDoDrillKeyType drlKeyTyp = tdTypeId.getEntity().getDrillKeyTypes().iterator().next();
				// Get drill key field
				Field_Id fieldId = drlKeyTyp.getField().getId();
				if(fieldId.compareTo(FA_ID) == 0){
					excludedTDTypesFAId.append(SINGLE_QUOTE);
					excludedTDTypesFAId.append(optVal);
					excludedTDTypesFAId.append(SINGLE_QUOTE);
					excludedTDTypesFAId.append(COMMA_DELIMITER);

				}else if(fieldId.compareTo(MTR_ID) == 0){
					excludedTDTypesMeterId.append(SINGLE_QUOTE);
					excludedTDTypesMeterId.append(optVal);
					excludedTDTypesMeterId.append(SINGLE_QUOTE);
					excludedTDTypesMeterId.append(COMMA_DELIMITER);

				}else if(fieldId.compareTo(PREM_ID) == 0){
					excludedTDTypesPremId.append(SINGLE_QUOTE);
					excludedTDTypesPremId.append(optVal);
					excludedTDTypesPremId.append(SINGLE_QUOTE);
					excludedTDTypesPremId.append(COMMA_DELIMITER);

				}else if(fieldId.compareTo(F1_SVC_TASK_ID) == 0){
					excludedTDTypesSvcTskId.append(SINGLE_QUOTE);
					excludedTDTypesSvcTskId.append(optVal);
					excludedTDTypesSvcTskId.append(SINGLE_QUOTE);
					excludedTDTypesSvcTskId.append(COMMA_DELIMITER);
				}
			}
		    // END ADD - JRAYMU - 2020-10-23 - B-17231
		}
		
	}

}
