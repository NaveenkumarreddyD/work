/******************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Pledge Collection and Severance Cancellation Batch
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-01-24   Neha            NB0033 Initial Version.
 * 2013-08-14   Neha            IM-036117 Check Funding type char type to be Foreign key 
 *                              rather than Predefined
 * 2013-10-01   JPunza          Modified to retrieve the correct Amount Still Owing values.
 * 2013-10-08   JPunza          Set Debit Date to Current Date if Collection Process or 
 *                              Severance Process' Base Arrears Date is blank. 
 * 2014-02-26   Neha	        IM-046389 Add NVL to the query to avoind exception
 * 2016-01-29  	MPang			Updated for CCB v2.4 compilation. 
 * 2018-07-25   SFelip          CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                              longer needed. 
 * 2022-09-05   JVitug          B-23381. Updated to Thread Iteration strategry.                           
 ******************************************************************************************/

package com.splwg.cm.domain.batch;


import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadIterationStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.datatypes.Month;
import com.splwg.base.api.datatypes.StringId;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.program.standard.StandardRecords;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus_Id;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.currency.Currency_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.domain.creditcollections.collectionProcess.CollectionProcess;
import com.splwg.ccb.domain.creditcollections.collectionProcess.CollectionProcessServiceAgreement;
import com.splwg.ccb.domain.creditcollections.collectionProcess.CollectionProcess_Id;
import com.splwg.ccb.domain.creditcollections.severanceProcess.SeveranceProcess;
import com.splwg.ccb.domain.creditcollections.severanceProcess.SeveranceProcess_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTask;
import com.splwg.cm.domain.financial.financialTransaction.CobolCopybookCMCFFTCN;
import com.splwg.cm.domain.financial.financialTransaction.CobolProgramCMPFFTCN;*/
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.base.support.program.types.RecordFactory;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.CollectionSaStatusLookup;
import com.splwg.ccb.api.lookup.CollectionStatusLookup;
import com.splwg.ccb.api.lookup.CollectionStatusReasonLookup;
import com.splwg.ccb.api.lookup.SeveranceStatusLookup;
import com.splwg.ccb.api.lookup.SeveranceStatusReasonLookup;
import com.splwg.ccb.domain.creditcollections.collectionProcess.entity.CollectionProcess;
import com.splwg.ccb.domain.creditcollections.collectionProcess.entity.CollectionProcessServiceAgreement;
import com.splwg.ccb.domain.creditcollections.collectionProcess.entity.CollectionProcess_Id;
import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceProcess;
import com.splwg.ccb.domain.creditcollections.severanceProcess.entity.SeveranceProcess_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.financial.common.ProgramCIPFFTCN;
import com.splwg.ccb.domain.financial.data.RecordCICFFTCN;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

//Start Change JVitug - B-23381 - 2022-09-05
///** 
// * @BatchJob (modules = {}, multiThreaded = false, rerunnable = false,
// *      softParameters = { @BatchJobSoftParameter (entityName = serviceTaskType, name = PLEDGE_SVC_TASK_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = PLEDGE_ACTIVE_STATUS, required = true, type = string)
// *            , @BatchJobSoftParameter (name = PLEDGE_PAID_STATUS, required = true, type = string)
// *            , @BatchJobSoftParameter (name = MAJOR_PLEDGE_COLL_HOLD_DAYS, required = true, type = integer)
// *            , @BatchJobSoftParameter (name = PLEDGE_AMT_STILL_OWING, required = true, type = decimal)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = SVC_TASK_SA_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = SVC_TASK_AMT_CHAR_TYPE, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = characteristicType, name = SVC_TASK_FUNDING_TYPE_CHAR_TYP, required = true, type = entity)
// *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = ELIG_PLEDGE_FUNDING_FEAT_CONF, required = true, type = entity)
// *            , @BatchJobSoftParameter (name = ELIG_PLEDGE_FUNDING_OPT_TYP, required = true, type = string)})
// */
/** 
 * @BatchJob (modules = {}, multiThreaded = true, rerunnable = false,
 *      softParameters = { @BatchJobSoftParameter (entityName = serviceTaskType, name = PLEDGE_SVC_TASK_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = PLEDGE_ACTIVE_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PLEDGE_PAID_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = MAJOR_PLEDGE_COLL_HOLD_DAYS, required = true, type = integer)
 *            , @BatchJobSoftParameter (name = PLEDGE_AMT_STILL_OWING, required = true, type = decimal)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = SVC_TASK_SA_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = SVC_TASK_AMT_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = SVC_TASK_FUNDING_TYPE_CHAR_TYP, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = ELIG_PLEDGE_FUNDING_FEAT_CONF, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = ELIG_PLEDGE_FUNDING_OPT_TYP, required = true, type = string)})
 */
//End Change JVitug - B-23381 - 2022-09-05
public class CmPledgeCollSevCancel_BatchProcess 
extends CmPledgeCollSevCancel_BatchProcess_Gen{

    // JPunza - 2013-10-01 - Start
    //// Soft Parameters
    //private static ServiceTaskType parmServiceTaskType;
    //private static String parmPledgeActiveStatus;
    //private static String parmPledgePaidStatus;
    //private static BigInteger parmMajorPledgeCollHoldDays;
    //private static BigDecimal parmPledgeAmtStillOwing;
    //private static CharacteristicType parmSvcTaskSACharType;   
    //private static CharacteristicType parmSvcTaskAmtCharType; 
    //private static CharacteristicType parmSvcTaskFundingTypCharType; 
    //private static FeatureConfiguration parmEligFundingTypeFeatConfig; 
    //private static String parmEligFundingTypeOptionType;
    // JPunza - 2013-10-01 - End
  
    /**
     * This method retrieves the records to be processed and in case of error returns a JobWork with single ThreadWorkUnit
     * 
     * @return the JobWork that will be processed in this run.
     */
	//Start Delete JVitug - B-23381 - 2022-09-05
    //public JobWork getJobWork() {

        //List<ThreadWorkUnit> workUnits = new ArrayList<ThreadWorkUnit>();                                               
        //ThreadWorkUnit workUnit = new ThreadWorkUnit(); 
        //workUnits.add(workUnit);   
        //return createJobWorkForThreadWorkUnitList(workUnits);
    //}

    //public ThreadWorkUnit createWorkUnit(QueryResultRow queryResultRow) {
        //return super.createWorkUnit(queryResultRow);
    //}
    //End Delete JVitug - B-233381 - 2022-09-05
    /**
     * This method checks if all required Soft Parameters were populated,
     * and all optional Soft Parameters (if populated) are valid.
     * 
     * @param isNewRun - a boolean value
     */
    public void validateSoftParameters(boolean isNewRun){
        
        // JPunza - 2013-10-01 - Start
        ServiceTaskType parmServiceTaskType;
        String parmPledgeActiveStatus;
        String parmPledgePaidStatus;
        BigInteger parmMajorPledgeCollHoldDays;
        BigDecimal parmPledgeAmtStillOwing;
        CharacteristicType parmSvcTaskSACharType;   
        CharacteristicType parmSvcTaskAmtCharType; 
        CharacteristicType parmSvcTaskFundingTypCharType; 
        FeatureConfiguration parmEligFundingTypeFeatConfig; 
        String parmEligFundingTypeOptionType;
        // JPunza - 2013-10-01 - End
        
        parmServiceTaskType = getParameters().getPLEDGE_SVC_TASK_TYPE();

        parmPledgeActiveStatus = getParameters().getPLEDGE_ACTIVE_STATUS().trim();
        BusinessObject_Id transBoId = parmServiceTaskType.getRelatedTransactionBO().getId();

        BusinessObjectStatus businessObjectStatus = new BusinessObjectStatus_Id(transBoId, parmPledgeActiveStatus).getEntity();
        if(isNull(businessObjectStatus)){
            addError(CustomMessageRepository.nb0033InvalidActiveStatusForServiceTaskType(parmPledgeActiveStatus,transBoId.getTrimmedValue(),parmServiceTaskType.getId().getTrimmedValue())); 
        }      
        parmPledgePaidStatus = getParameters().getPLEDGE_PAID_STATUS().trim();
        businessObjectStatus = new BusinessObjectStatus_Id(transBoId, parmPledgePaidStatus).getEntity();
        if(isNull(businessObjectStatus)){
            addError(CustomMessageRepository.nb0033InvalidPaidStatusForServiceTaskType(parmPledgePaidStatus,transBoId.getTrimmedValue(), parmServiceTaskType.getId().getTrimmedValue())); 
        }
        parmMajorPledgeCollHoldDays = getParameters().getMAJOR_PLEDGE_COLL_HOLD_DAYS();
        if(parmMajorPledgeCollHoldDays.compareTo(BigInteger.ZERO) <= 0){
            addError(CustomMessageRepository.nb0033PledgeCollectionHoldDaysMustBGreaterThanZero(parmMajorPledgeCollHoldDays.toString()));  
        }
        parmPledgeAmtStillOwing = getParameters().getPLEDGE_AMT_STILL_OWING();
        if(parmPledgeAmtStillOwing.compareTo(BigDecimal.ZERO) < 0){
            addError(CustomMessageRepository.nb0033PledgeAmtHoldingMustBGreaterThanOrEqualToZero(parmPledgeAmtStillOwing.toString()));  
        }
        CharacteristicEntity_Id charEntityId;
        parmSvcTaskSACharType = getParameters().getSVC_TASK_SA_CHAR_TYPE();   
        charEntityId = new CharacteristicEntity_Id(parmSvcTaskSACharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        if (isNull(charEntityId.getEntity())){
            addError(CustomMessageRepository.nb0033InvalidSvcTaskSACharType(parmSvcTaskSACharType.getId().getTrimmedValue()));
        } 
        parmSvcTaskAmtCharType = getParameters().getSVC_TASK_AMT_CHAR_TYPE(); 
        charEntityId = new CharacteristicEntity_Id(parmSvcTaskAmtCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        if (isNull(charEntityId.getEntity())){
            addError(CustomMessageRepository.nb0033InvalidSvcTaskAmtCharType(parmSvcTaskAmtCharType.getId().getTrimmedValue()));
        } 
        parmSvcTaskFundingTypCharType = getParameters().getSVC_TASK_FUNDING_TYPE_CHAR_TYP(); 
        charEntityId = new CharacteristicEntity_Id(parmSvcTaskFundingTypCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
        if (isNull(charEntityId.getEntity())){
            addError(CustomMessageRepository.nb0033InvalidSvcTaskFundingTypCharType(parmSvcTaskFundingTypCharType.getId().getTrimmedValue()));
        } 
        parmEligFundingTypeFeatConfig = getParameters().getELIG_PLEDGE_FUNDING_FEAT_CONF(); 
        parmEligFundingTypeOptionType = getParameters().getELIG_PLEDGE_FUNDING_OPT_TYP().trim(); 
        SQLResultRow row = validateOptionType(parmEligFundingTypeFeatConfig, parmEligFundingTypeOptionType);
        if(isNull(row)){
            addError(CustomMessageRepository.nb0033InvalidOptionTypForFeatureConfig(parmEligFundingTypeOptionType,parmEligFundingTypeFeatConfig.getId().getTrimmedValue())); 
        }
    }

    private SQLResultRow validateOptionType(FeatureConfiguration featConfig, String optionType) {

        StringBuilder getOptionTypeString = new StringBuilder();
        getOptionTypeString.append("SELECT 'X' FROM CI_WFM_OPT OPT WHERE OPT.WFM_NAME = :wfmName AND TRIM(OPT.EXT_OPT_TYPE) = TRIM(:optionType) ");
        //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement optionTypeStmt = createPreparedStatement(getOptionTypeString.toString());
        PreparedStatement optionTypeStmt = createPreparedStatement(getOptionTypeString.toString(), getClass().getName());
        //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        optionTypeStmt.bindId("wfmName", featConfig.getId());
        optionTypeStmt.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType,optionType);

        return optionTypeStmt.firstRow();
    }

    /**
     * Method to retrieve the Thread Worker Class.
     * 
     * @return the thread worker class
     */
    public Class<CmPledgeCollSevCancel_BatchProcessWorker> getThreadWorkerClass() {    	
        return CmPledgeCollSevCancel_BatchProcessWorker.class;
    }

    /**
     * This Worker Class is responsible for processing a single Thread Instance.
     */
    public static class CmPledgeCollSevCancel_BatchProcessWorker
    extends CmPledgeCollSevCancel_BatchProcessWorker_Gen {
        
        // JPunza - 2013-10-01 - Start
        private final Date MAX_DATE = new Date(4712, Month.DECEMBER, 31);

        // Soft Parameters
        private ServiceTaskType parmServiceTaskType;
        private String parmPledgeActiveStatus;
        private String parmPledgePaidStatus;
        private BigInteger parmMajorPledgeCollHoldDays;
        private BigDecimal parmPledgeAmtStillOwing;
        private CharacteristicType parmSvcTaskSACharType;   
        private CharacteristicType parmSvcTaskAmtCharType; 
        private CharacteristicType parmSvcTaskFundingTypCharType; 
        private FeatureConfiguration parmEligFundingTypeFeatConfig; 
        private String parmEligFundingTypeOptionType;
        // JPunza - 2013-10-01 - End

        // Working Variables
        private BigInteger numberOfRecordsInError = BigInteger.ZERO;
        private BigInteger numberOfRecordsProcessed = BigInteger.ZERO;
        /**
         * This method identifies the execution strategy to be used for the thread.
         * 
         * @return an instance of ThreadExecutionStrategy that governs how this ThreadWorker will be executed at runtime.
         * @see com.splwg.base.api.batch.ThreadWorker#createExecutionStrategy()
         */
        public ThreadExecutionStrategy createExecutionStrategy() {
        	//Start Change JVitug - B-23381 - 2022-09-05
            //return new SingleTransactionStrategy(this);
        	return new ThreadIterationStrategy(this);
            //End Change JVitug - B-23381 - 2022-09-05
        }
        
        // JPunza - 2013-10-01 - Start
        @Override
        public void initializeThreadWork(boolean arg0) throws ThreadAbortedException, RunAbortedException {
            parmServiceTaskType = getParameters().getPLEDGE_SVC_TASK_TYPE();
            parmPledgeActiveStatus = getParameters().getPLEDGE_ACTIVE_STATUS().trim();
            parmPledgePaidStatus = getParameters().getPLEDGE_PAID_STATUS().trim();
            parmMajorPledgeCollHoldDays = getParameters().getMAJOR_PLEDGE_COLL_HOLD_DAYS();
            parmPledgeAmtStillOwing = getParameters().getPLEDGE_AMT_STILL_OWING();
            parmSvcTaskSACharType = getParameters().getSVC_TASK_SA_CHAR_TYPE();   
            parmSvcTaskAmtCharType = getParameters().getSVC_TASK_AMT_CHAR_TYPE(); 
            parmSvcTaskFundingTypCharType = getParameters().getSVC_TASK_FUNDING_TYPE_CHAR_TYP(); 
            parmEligFundingTypeFeatConfig = getParameters().getELIG_PLEDGE_FUNDING_FEAT_CONF(); 
            parmEligFundingTypeOptionType = getParameters().getELIG_PLEDGE_FUNDING_OPT_TYP().trim();
            
            //Start Add JVitug - B-23381 - 2022-09-05
            this.startResultRowQueryIteratorForThread(ServiceTask_Id.class);
            //End Add JVitug - B-23381 - 2022-09-05
        }
        // JPunza - 2013-10-01 - End
        
      //Start Add JVitug - B-23381 - 2022-09-05
        @Override
        protected QueryIterator getQueryIteratorForThread(StringId lowID, StringId highID) {
        	StringBuilder stringSql = new StringBuilder();
        	
			stringSql.append("SELECT CH2.SA_ID , CH2.SQL_ORDER , CH2.RNK ");
			stringSql.append("FROM ( ");
			stringSql.append(   "SELECT CH2.SA_ID , CH2.SQL_ORDER ,  rank() over (partition by CH2.SA_ID order by SQL_ORDER) as RNK ");
			stringSql.append(   "FROM ( ");
			//This marks the start of the first sql found in the getSAForServiceTasks() method
			stringSql.append(      "SELECT DISTINCT SA.SA_ID, 1 AS SQL_ORDER ");
			stringSql.append(      "FROM F1_SVC_TASK SVC, ");
			stringSql.append(         "CI_WFM_OPT OPT, ");
			stringSql.append(         "F1_SVC_TASK_CHAR CH1, ");
			stringSql.append(         "F1_SVC_TASK_CHAR CH2, ");
			stringSql.append(         "CI_SA SA ");
			stringSql.append(      "WHERE ");
			stringSql.append(         "SVC.F1_STASK_TYPE_CD = :parmSvcTaskType ");
			stringSql.append(      "AND ");
			stringSql.append(         "CH1.F1_SVC_TASK_ID = SVC.F1_SVC_TASK_ID  ");
			stringSql.append(      "AND ");
			stringSql.append(         "CH1.CHAR_TYPE_CD = :parmFundingTypCharType ");
			stringSql.append(      "AND ");
			stringSql.append(         "CH1.SRCH_CHAR_VAL = TRIM(OPT.WFM_OPT_VAL) ");
			stringSql.append(      "AND ");
			stringSql.append(         "OPT.WFM_NAME = :parmFeatconfig  ");
			stringSql.append(      "AND ");
			stringSql.append(         "OPT.EXT_OPT_TYPE = :parmOptionType ");
			stringSql.append(      "AND ");
			stringSql.append(         "SVC.BO_STATUS_CD IN (:parmActiveStatus, :parmPaidStatus) ");
			stringSql.append(      "AND ");
			stringSql.append(         "CH2.F1_SVC_TASK_ID = SVC.F1_SVC_TASK_ID ");
			stringSql.append(      "AND ");
			stringSql.append(         "CH2.CHAR_TYPE_CD = :parmSACharType ");
			stringSql.append(      "AND ");
			stringSql.append(         "(:batchRunDateTime - SVC.CRE_DTTM) <= :parmHoldDays ");
			stringSql.append(      "AND ");
			stringSql.append(         "CH2.SRCH_CHAR_VAL = SA.SA_ID ");
			stringSql.append(      "AND ");
			stringSql.append(         "SA.SA_ID BETWEEN :lowId and :highId ");
			stringSql.append(      "UNION ");
			
			//This marks the second SQL found in getActiveServiceTaskDetails() method. This SQL 
        	//is modified in that the amount is omitted initially and is then retrieved later in the
        	//execute work unit method. Goal is to obtain the same data set as with the SQL in 
        	//getActiveServiceTaskDetails()
			
			stringSql.append(      "SELECT DISTINCT SA.SA_ID, 2 AS SQL_ORDER ");
			stringSql.append(      "FROM ");
			stringSql.append(         "F1_SVC_TASK SVC,  ");
			stringSql.append(         "F1_SVC_TASK_CHAR CH2, ");
			stringSql.append(         "CI_SA SA ");
			stringSql.append(      "WHERE ");
			stringSql.append(         "SVC.F1_STASK_TYPE_CD = :parmSvcTaskType ");
			stringSql.append(      "AND ");
			stringSql.append(         "SVC.BO_STATUS_CD = :parmActiveStatus ");
			stringSql.append(      "AND NOT EXISTS ( ");
			stringSql.append(         "SELECT ");
			stringSql.append(            "'X' ");
			stringSql.append(         "FROM ");
			stringSql.append(            "CI_WFM_OPT OPT, ");
			stringSql.append(            "F1_SVC_TASK_CHAR CH1 ");
			stringSql.append(         "WHERE ");
			stringSql.append(            "CH1.F1_SVC_TASK_ID = SVC.F1_SVC_TASK_ID ");
			stringSql.append(         "AND ");
			stringSql.append(            "CH1.CHAR_TYPE_CD = :parmFundingTypCharType ");
			stringSql.append(         "AND ");
			stringSql.append(            "CH1.SRCH_CHAR_VAL = TRIM(OPT.WFM_OPT_VAL) ");
			stringSql.append(         "AND ");
			stringSql.append(            "OPT.WFM_NAME = :parmFeatconfig ");
			stringSql.append(         "AND ");
			stringSql.append(            "TRIM(OPT.EXT_OPT_TYPE) = :parmOptionType) ");
			stringSql.append(      "AND ");
			stringSql.append(         "CH2.F1_SVC_TASK_ID = SVC.F1_SVC_TASK_ID ");
			stringSql.append(      "AND ");
			stringSql.append(         "CH2.CHAR_TYPE_CD = :parmSACharType ");
			stringSql.append(      "AND EXISTS ( ");
			stringSql.append(         "SELECT ");
			stringSql.append(            "'X' ");
			stringSql.append(         "FROM ");
			stringSql.append(            "F1_SVC_TASK_CHAR CH3 ");
			stringSql.append(         "WHERE ");
			stringSql.append(            "CH3.F1_SVC_TASK_ID = SVC.F1_SVC_TASK_ID ");
			stringSql.append(         "AND ");
			stringSql.append(            "CH3.CHAR_TYPE_CD = :parmAmtCharType ");
			stringSql.append(      ") ");
        	stringSql.append(      "AND ");
        	stringSql.append(         "CH2.SRCH_CHAR_VAL = SA.SA_ID ");
        	stringSql.append(      "AND ");
			stringSql.append(         "SA.SA_ID BETWEEN :lowId and :highId ");
			stringSql.append(   ") CH2 ");
			stringSql.append(")CH2 ");
			stringSql.append("WHERE ");
			stringSql.append(   "CH2.RNK = 1 ");
        	
        	PreparedStatement sql = createPreparedStatement(stringSql.toString() , getClass().getName());
        	
        	sql.bindId("parmSvcTaskType", parmServiceTaskType.getId());
            sql.bindId("parmFundingTypCharType", parmSvcTaskFundingTypCharType.getId());
            sql.bindId("parmFeatconfig", parmEligFundingTypeFeatConfig.getId());
            sql.bindStringProperty("parmOptionType", FeatureConfigurationOption.properties.optionType,parmEligFundingTypeOptionType);
            sql.bindStringProperty("parmActiveStatus", ServiceTask.properties.status,parmPledgeActiveStatus);
            sql.bindStringProperty("parmPaidStatus", ServiceTask.properties.status,parmPledgePaidStatus);
            sql.bindDateTime("batchRunDateTime", getProcessDateTime());
            sql.bindBigInteger("parmHoldDays", parmMajorPledgeCollHoldDays);
            sql.bindId("parmSACharType", parmSvcTaskSACharType.getId());
            sql.bindId("parmAmtCharType", parmSvcTaskAmtCharType.getId());
            sql.bindId("lowId", lowID);
            sql.bindId("highId", highID);
            sql.setAutoclose(false);
            sql.execute();
        	
        	return sql.iterate();
        }
        
        @Override
		protected ThreadWorkUnit getNextWorkUnit(QueryResultRow qrw) {
			ThreadWorkUnit twu = new ThreadWorkUnit();
			ServiceAgreement_Id saId = null;
			
			saId = (ServiceAgreement_Id) qrw.getId("SA_ID" , ServiceAgreement.class);
			
			BigInteger sqlOrder = qrw.getInteger("SQL_ORDER");	

			twu.setPrimaryId(saId);
			twu.addSupplementalData("SQL_ORDER", sqlOrder);
			return twu;
		}	
        //End Add JVitug - B-23381 - 2022-09-05

        /**
         * Execute a WorkUnit and provide result details.
         * 
         * @param unit - a ThreadWorkUnit
         * @return a boolean that describes the success or failure of the work unit processing.
         * @throws ThreadAbortedException - thrown by application logic requesting the thread should be aborted 
         * @throws RunAbortedException - thrown by application logic requesting the entire run should be aborted
         * @see com.splwg.base.api.batch.ThreadWorker#executeWorkUnitDetailedResult(com.splwg.base.api.batch.ThreadWorkUnit)
         */
        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {
        	
        	
        	//Start Delete JVitug -  B-23381 - 2022-09-05
            //List<SQLResultRow> saList =  getSAForServiceTasks();
            //End Delete JVitug -  B-23381 - 2022-09-05
        	//Start Add JVitug -  B-23381 - 2022-09-05
        	ServiceAgreement_Id saId = (ServiceAgreement_Id) unit.getPrimaryId();
        	BigInteger sqlOrder = (BigInteger)unit.getSupplementallData("SQL_ORDER");
        	
        	numberOfRecordsInError = BigInteger.ZERO;
            numberOfRecordsProcessed = BigInteger.ZERO;
        	//End Add JVitug -  B-23381 - 2022-09-05
        	
            boolean saProcessed = false; 
          //Start Change JVitug -  B-23381 - 2022-09-05
            //if(!saList.isEmpty()){
            //If SQL order is 1, this was retrieved by the first SQL
            if(sqlOrder.intValue() == 1){
          //End Change JVitug -  B-23381 - 2022-09-05
            	//Start Delete JVitug -  B-23381 - 2022-09-05
            	//ServiceAgreement_Id saId = null;
            	//for(SQLResultRow row : saList){
            	//End Delete JVitug -  B-23381 - 2022-09-05
            	saProcessed = false; 
            	//Start Delete JVitug -  B-23381 - 2022-09-05
            	//CharacteristicTypeLookup charTypeLookup = parmSvcTaskSACharType.getCharacteristicType();
            	//if(charTypeLookup.isPredefinedValue()){
            	//saId =new ServiceAgreement_Id(row.getString("CHAR_VAL"));
            	//}else if(charTypeLookup.isForeignKeyValue()){
            	//saId =new ServiceAgreement_Id(row.getString("CHAR_VAL_FK1"));
            	//}else if(charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()){
            	//saId =new ServiceAgreement_Id(row.getString("ADHOC_CHAR_VAL"));
            	//}
            	//End Delete JVitug -  B-23381 - 2022-09-05
            	
            	//Start Change JVitug -  B-23381 - 2022-09-05
            	//if(isNull(saId)){
            		//continue;
            	//}
            	if(notNull(saId)) {
            	//End Change JVitug -  B-23381 - 2022-09-05
            		SQLResultRow collProcResult = getActiveCollectionProcess(saId);

            		if(notNull(collProcResult)){
            			CollectionProcess cp = ((CollectionProcess_Id)collProcResult.getId("COLL_PROC_ID", CollectionProcess.class)).getEntity();
            			cp.cancel(CollectionStatusReasonLookup.constants.CANCELEDBY_SYSTEM);
            			saProcessed = true;
            		}

            		SQLResultRow severanceProcResult = getActiveSeveranceProcess(saId);

            		if(notNull(severanceProcResult)){
            			SeveranceProcess sevProcess = ((SeveranceProcess_Id)severanceProcResult.getId("SEV_PROC_ID", SeveranceProcess.class)).getEntity();
            			sevProcess.cancel(SeveranceStatusReasonLookup.constants.CANCELEDBY_SYSTEM, Bool.TRUE);
            			saProcessed = true;
            		}
            		if(saProcessed){
            			numberOfRecordsProcessed = numberOfRecordsProcessed.add(BigInteger.ONE);
            		}

                }   
            }
            //Start Change JVitug -  B-23381 - 2022-09-05
            //List<SQLResultRow> saAmountList =  getActiveServiceTaskDetails();

            //if(!saAmountList.isEmpty()){
            else {
            //End Change JVitug -  B-23381 - 2022-09-05
            	//Start Delete JVitug -  B-23381 - 2022-09-05
                //ServiceAgreement_Id saId;
                //End Delete JVitug -  B-23381 - 2022-09-05
                Money sumOfPledges = Money.ZERO;
                
              //Start Delete JVitug -  B-23381 - 2022-09-05
                //for(SQLResultRow row : saAmountList){

                saProcessed = false;
                
                //saId = new ServiceAgreement_Id(row.getString("SA"));
                //End Delete JVitug -  B-23381 - 2022-09-05
                //Start Change JVitug  -  B-23381 - 2022-09-05
                
                //if SQL order is other than one, this means that the SA was retrieved by the second SQL
                //first retrieve the pledge amounts linked to the SA 
                //sumOfPledges = new Money(row.getBigDecimal("AMOUNT"), saId.getEntity().getCurrencyId());
                sumOfPledges = new Money(getSumOfPledges(saId) , saId.getEntity().getCurrencyId());
                //End Change JVitug -  B-23381 - 2022-09-05

                SQLResultRow collProcResult = getActiveCollectionProcess(saId);
                if(notNull(collProcResult)){
                	CollectionProcess_Id collProcId = (CollectionProcess_Id)collProcResult.getId("COLL_PROC_ID", CollectionProcess.class);
                	// JPunza - 2013-10-01 - Start
                	//Money amountStillOwing = (new CollectionProcessServiceAgreement_Id(saId, collProcId)).getEntity().getArrearsAmount();
                	//if((amountStillOwing.add(sumOfPledges.negate())).compareTo(new Money(parmPledgeAmtStillOwing, saId.getEntity().getCurrencyId())) <= 0){
                	Money amountStillOwing = getAmountStillOwingForCollProc(collProcId.getEntity(), saId.getEntity().getCurrencyId());
                	if(amountStillOwing.compareTo(new Money(parmPledgeAmtStillOwing, saId.getEntity().getCurrencyId())) <= 0){
                		// JPunza - 2013-10-01 - End    
                		collProcId.getEntity().cancel(CollectionStatusReasonLookup.constants.CANCELEDBY_SYSTEM);
                		saProcessed = true;
                	}
                }

                SQLResultRow severanceProcResult = getActiveSeveranceProcess(saId);
                if(notNull(severanceProcResult)){
                	SeveranceProcess sevProcess = ((SeveranceProcess_Id)severanceProcResult.getId("SEV_PROC_ID", SeveranceProcess.class)).getEntity();
                	// JPunza - 2013-10-01 - Start
                	//if((sevProcess.getArrearsAmount().add(sumOfPledges.negate())).compareTo(new Money(parmPledgeAmtStillOwing, saId.getEntity().getCurrencyId())) <= 0){
                	Money amountStillOwing = getAmountStillOwingForSevProc(sevProcess, saId.getEntity());
                	if((amountStillOwing.add(sumOfPledges.negate())).compareTo(new Money(parmPledgeAmtStillOwing, saId.getEntity().getCurrencyId())) <= 0){
                		// JPunza - 2013-10-01 - End
                		sevProcess.cancel(SeveranceStatusReasonLookup.constants.CANCELEDBY_SYSTEM, Bool.TRUE);
                		saProcessed = true;
                	}
                }
                if(saProcessed){
                	numberOfRecordsProcessed = numberOfRecordsProcessed.add(BigInteger.ONE);
                }
                //Start Delete JVitug -  B-23381 - 2022-09-05
                //}
               //End Delete JVitug -  B-23381 - 2022-09-05
            }

            WorkUnitResult workUnitResult = new WorkUnitResult(true);
            workUnitResult.setUnitsProcessed(numberOfRecordsProcessed.intValue());
            workUnitResult.setUnitsInError(numberOfRecordsInError.intValue());
            return workUnitResult; 
        }   

        // JPunza - 2013-10-01 - Start
        private Money getAmountStillOwingForCollProc(CollectionProcess cp, Currency_Id currencyId) {
            
            Date debitDate = cp.getCollectionArrearsDate();
            
            // JPunza - 2013-10-08 - Start
            if (isNull(debitDate)) {
                debitDate = getProcessDateTime().getDate();
            }
            // JPunza - 2013-10-08 - End
            
            BigDecimal totalAmount = BigDecimal.ZERO;
            BigDecimal pledgeAmount = BigDecimal.ZERO;
            
            Iterator<CollectionProcessServiceAgreement> iter = cp.getServiceAgreements().iterator();
            while (iter.hasNext()) {
                
                ServiceAgreement_Id saId = iter.next().fetchIdServiceAgreement().getId();
                
                // Amount Still Owning
                
                /*
                 * Start Change - 2.5 Upgrade - EQuint - 12-02-2016 
                 */
                StandardRecords standardRecords = new StandardRecords();
                
                RecordCICFFTCN cicfftcn = RecordFactory.getFactory(RecordCICFFTCN.class).newInstance();
                cicfftcn.refInputWrk().refSaId().setValue(saId.getTrimmedValue());
                cicfftcn.refInputWrk().refDebitDt().setValue(debitDate.toString());
                cicfftcn.refInputWrk().refCreditDt().setValue(MAX_DATE.toString());
                
                ProgramCIPFFTCN.invoke(standardRecords, cicfftcn);
                
                BigDecimal currentAmount = BigDecimal.valueOf(cicfftcn.refOutputWrk().refCurAmt().getValue().doubleValue());
                if (currentAmount.compareTo(BigDecimal.ZERO) > 0) {
                    totalAmount = totalAmount.add(currentAmount);
                }
//                CobolProgramCMPFFTCN routine = (CobolProgramCMPFFTCN) getDynamicComponent(CobolProgramCMPFFTCN.class);
//                CobolCopybookCMCFFTCN copybook = routine.getCobolCopybookCMCFFTCN();
//
//                copybook.get_INPUT_WRK().set_SA_ID(saId.getTrimmedValue());
//                copybook.get_INPUT_WRK().set_DEBIT_DT(debitDate);
//                copybook.get_INPUT_WRK().set_CREDIT_DT(MAX_DATE);
//                
//                routine.callCobol();
//                
//                BigDecimal currentAmount = copybook.get_OUTPUT_WRK().get_CUR_AMT();
//                if (currentAmount.compareTo(BigDecimal.ZERO) > 0) {
//                    totalAmount = totalAmount.add(currentAmount);
//                }
                
                /*
                 * End Change - 2.5 Upgrade - EQuint - 12-02-2016 
                 */
                
                // Pledge Amount
				// Start changes 2014-02-26   Neha
                //PreparedStatement getPledgeAmount = createPreparedStatement("SELECT SUM(TO_NUMBER(STC.ADHOC_CHAR_VAL)) AS AMOUNT " +
				PreparedStatement getPledgeAmount = createPreparedStatement("SELECT NVL(SUM(TO_NUMBER(STC.ADHOC_CHAR_VAL)),0) AS AMOUNT " +
				// End changes 2014-02-26   Neha
                        "FROM F1_SVC_TASK_CHAR STC " +
                        "WHERE STC.CHAR_TYPE_CD = :charType " +
                        "AND EXISTS (SELECT 'X' FROM F1_SVC_TASK_CHAR STC2 " +
                        "   WHERE STC2.F1_SVC_TASK_ID = STC.F1_SVC_TASK_ID " +
                        "   AND STC2.CHAR_TYPE_CD = :charType2 " +
                        //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
                        //"   AND TRIM(STC2.CHAR_VAL_FK1) = TRIM(:saId))");
						"   AND TRIM(STC2.CHAR_VAL_FK1) = TRIM(:saId))", getClass().getName());
						//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
                
                getPledgeAmount.bindEntity("charType", parmSvcTaskAmtCharType);
                getPledgeAmount.bindEntity("charType2", parmSvcTaskSACharType);
                getPledgeAmount.bindId("saId", saId);
                
                SQLResultRow result = getPledgeAmount.firstRow();
                
                if (notNull(result)) {                    
                    pledgeAmount = pledgeAmount.add(result.getBigDecimal("AMOUNT"));
                }
            }

            totalAmount = totalAmount.subtract(pledgeAmount);
            
            return new Money(totalAmount, currencyId);
        }
        
        private Money getAmountStillOwingForSevProc(SeveranceProcess sp, ServiceAgreement sa) {
                        
            // JPunza - 2013-10-08 - Start
            Date debitDate = sp.getArrearsDate();
            if (isNull(debitDate)) {
                debitDate = getProcessDateTime().getDate();
            }
            // JPunza - 2013-10-08 - End
            
            /*
             * Start Change - 2.5 Upgrade - EQuint - 12-02-2016 
             */
            StandardRecords standardRecords = new StandardRecords();
            
            RecordCICFFTCN cicfftcn = RecordFactory.getFactory(RecordCICFFTCN.class).newInstance();
            cicfftcn.refInputWrk().refSaId().setValue(sa.getId().getTrimmedValue());
            cicfftcn.refInputWrk().refDebitDt().setValue(debitDate.toString());
            cicfftcn.refInputWrk().refCreditDt().setValue(MAX_DATE.toString());
            
            ProgramCIPFFTCN.invoke(standardRecords, cicfftcn);
            
            BigDecimal currentAmount = BigDecimal.valueOf(cicfftcn.refOutputWrk().refCurAmt().getValue().doubleValue());
            if (currentAmount.compareTo(BigDecimal.ZERO) > 0) {
            	return new Money(currentAmount, sa.getCurrencyId());
            }
            
//            CobolProgramCMPFFTCN routine = (CobolProgramCMPFFTCN) getDynamicComponent(CobolProgramCMPFFTCN.class);
//            CobolCopybookCMCFFTCN copybook = routine.getCobolCopybookCMCFFTCN();
//
//            copybook.get_INPUT_WRK().set_SA_ID(sa.getId().getTrimmedValue());
//            // JPunza - 2013-10-08 - Start
//            //copybook.get_INPUT_WRK().set_DEBIT_DT(sp.getArrearsDate());
//            copybook.get_INPUT_WRK().set_DEBIT_DT(debitDate);
//            // JPunza - 2013-10-08 - End
//            copybook.get_INPUT_WRK().set_CREDIT_DT(MAX_DATE);
//            
//            routine.callCobol();
//            
//            BigDecimal currentAmount = copybook.get_OUTPUT_WRK().get_CUR_AMT();
//            if (currentAmount.compareTo(BigDecimal.ZERO) > 0) {
//                return new Money(currentAmount, sa.getCurrencyId());
//            }    
            
            /*
             * End Change - 2.5 Upgrade - EQuint - 12-02-2016 
             */
         
            return new Money(BigDecimal.ZERO, sa.getCurrencyId());
        }
        // JPunza - 2013-10-01 - End

        private List<SQLResultRow> getSAForServiceTasks() {
            List<SQLResultRow> saList = null;
            StringBuilder getAllServiceTasksString = new StringBuilder();
            getAllServiceTasksString.append("SELECT CH2.CHAR_VAL, CH2.ADHOC_CHAR_VAL, CH2.CHAR_VAL_FK1 ");
            getAllServiceTasksString.append("FROM F1_SVC_TASK SVC, CI_WFM_OPT OPT, F1_SVC_TASK_CHAR CH1, F1_SVC_TASK_CHAR CH2 ");
            getAllServiceTasksString.append("WHERE SVC.F1_STASK_TYPE_CD = :parmSvcTaskType ");
            getAllServiceTasksString.append("AND CH1.F1_SVC_TASK_ID = SVC.F1_SVC_TASK_ID "); 
            getAllServiceTasksString.append("AND CH1.CHAR_TYPE_CD = :parmFundingTypCharType ");
            // 08-14-2013 IM-036117
            //getAllServiceTasksString.append("AND TRIM(CH1.CHAR_VAL) = TRIM(OPT.WFM_OPT_VAL) ");
            CharacteristicTypeLookup charTypeLookup = parmSvcTaskFundingTypCharType.getCharacteristicType();
            if(charTypeLookup.isPredefinedValue()){
                getAllServiceTasksString.append("AND TRIM(CH1.CHAR_VAL) = TRIM(OPT.WFM_OPT_VAL) ");
            }else if(charTypeLookup.isForeignKeyValue()){
                getAllServiceTasksString.append("AND TRIM(CH1.CHAR_VAL_FK1) = TRIM(OPT.WFM_OPT_VAL) ");
            }else if(charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()){
                getAllServiceTasksString.append("AND TRIM(CH1.ADHOC_CHAR_VAL) = TRIM(OPT.WFM_OPT_VAL) ");
            }
            // End changes 08-14-2013 IM-036117
            getAllServiceTasksString.append("AND OPT.WFM_NAME = :parmFeatconfig ");
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //getAllServiceTasksString.append("AND TRIM(OPT.EXT_OPT_TYPE) = :parmOptionType ");
            //getAllServiceTasksString.append("AND TRIM(SVC.BO_STATUS_CD) IN (:parmActiveStatus, :parmPaidStatus) "); 
            getAllServiceTasksString.append("AND OPT.EXT_OPT_TYPE = :parmOptionType ");
            getAllServiceTasksString.append("AND SVC.BO_STATUS_CD IN (:parmActiveStatus, :parmPaidStatus) ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change
            getAllServiceTasksString.append("AND (:batchRunDateTime - SVC.CRE_DTTM) <= :parmHoldDays ");
            getAllServiceTasksString.append("AND CH2.F1_SVC_TASK_ID = SVC.F1_SVC_TASK_ID ");
            getAllServiceTasksString.append("AND CH2.CHAR_TYPE_CD = :parmSACharType ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement svcTasksPrepStmt = createPreparedStatement(getAllServiceTasksString.toString()); 
            PreparedStatement svcTasksPrepStmt = createPreparedStatement(getAllServiceTasksString.toString(), getClass().getName()); 
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            svcTasksPrepStmt.bindId("parmSvcTaskType", parmServiceTaskType.getId());
            svcTasksPrepStmt.bindId("parmFundingTypCharType", parmSvcTaskFundingTypCharType.getId());
            svcTasksPrepStmt.bindId("parmFeatconfig", parmEligFundingTypeFeatConfig.getId());
            svcTasksPrepStmt.bindStringProperty("parmOptionType", FeatureConfigurationOption.properties.optionType,parmEligFundingTypeOptionType);
            svcTasksPrepStmt.bindStringProperty("parmActiveStatus", ServiceTask.properties.status,parmPledgeActiveStatus);
            svcTasksPrepStmt.bindStringProperty("parmPaidStatus", ServiceTask.properties.status,parmPledgePaidStatus);
            svcTasksPrepStmt.bindDateTime("batchRunDateTime", getProcessDateTime());
            svcTasksPrepStmt.bindBigInteger("parmHoldDays", parmMajorPledgeCollHoldDays);
            svcTasksPrepStmt.bindId("parmSACharType", parmSvcTaskSACharType.getId());     

            saList = svcTasksPrepStmt.list();
            svcTasksPrepStmt.close();
            return saList;          
        }
        private SQLResultRow getActiveCollectionProcess(ServiceAgreement_Id saId) {
            SQLResultRow firstRow = null;
            StringBuilder getCollProcString = new StringBuilder();
            getCollProcString.append("SELECT COLL_SA.COLL_PROC_ID FROM CI_COLL_PROC_SA COLL_SA, CI_COLL_PROC PROC ");
            getCollProcString.append("WHERE SA_ID = :saFromPreviousQuery AND PROC.COLL_PROC_ID = COLL_SA.COLL_PROC_ID ");
            getCollProcString.append("AND PROC.COLL_STATUS_FLG = :collProcStatus AND COLL_SA_STAT_FLG = :collSAstatus  ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement collProcStmt = createPreparedStatement(getCollProcString.toString());
            PreparedStatement collProcStmt = createPreparedStatement(getCollProcString.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            collProcStmt.bindId("saFromPreviousQuery", saId);
            collProcStmt.bindLookup("collProcStatus", CollectionStatusLookup.constants.ACTIVE);
            collProcStmt.bindLookup("collSAstatus", CollectionSaStatusLookup.constants.ACTIVE);
            firstRow = collProcStmt.firstRow();
            collProcStmt.close();
            return firstRow;
        }

        private SQLResultRow getActiveSeveranceProcess(ServiceAgreement_Id saId) {
            SQLResultRow resultRow = null;
            StringBuilder getSevProcString = new StringBuilder();
            getSevProcString.append("SELECT PROC.SEV_PROC_ID FROM CI_SEV_PROC PROC, CI_SA_SP SASP, CI_SP SP ");
            getSevProcString.append("WHERE PROC.SA_ID = :sa_from_previous_query ");
            getSevProcString.append("AND SASP.SA_ID = PROC.SA_ID AND SASP.SP_ID = SP.SP_ID ");
            getSevProcString.append("AND SASP.START_DTTM <= :processingDttm ");
            getSevProcString.append("AND (SASP.STOP_DTTM IS NULL OR SASP.STOP_DTTM > :processingDttm) ");
            getSevProcString.append("AND PROC.SEV_STATUS_FLG = :active ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement sevProcStmt = createPreparedStatement(getSevProcString.toString()); 
            PreparedStatement sevProcStmt = createPreparedStatement(getSevProcString.toString(), getClass().getName()); 
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            sevProcStmt.bindId("sa_from_previous_query", saId);
            sevProcStmt.bindDateTime("processingDttm", getProcessDateTime());
            sevProcStmt.bindLookup("active",SeveranceStatusLookup.constants.ACTIVE);
            resultRow = sevProcStmt.firstRow();
            sevProcStmt.close();
            return resultRow;  
        }

        private List<SQLResultRow> getActiveServiceTaskDetails() {
            List<SQLResultRow> resultList = null;
            StringBuilder getActiveSvcTasksString = new StringBuilder();
            getActiveSvcTasksString.append("SELECT SUM(TO_NUMBER(CH3.ADHOC_CHAR_VAL)) AMOUNT,  CH2.CHAR_VAL_FK1 SA ");
            getActiveSvcTasksString.append("FROM F1_SVC_TASK SVC,  ");
            getActiveSvcTasksString.append("F1_SVC_TASK_CHAR CH2,  ");
            getActiveSvcTasksString.append("F1_SVC_TASK_CHAR CH3 ");
            getActiveSvcTasksString.append("WHERE SVC.F1_STASK_TYPE_CD = :parmSvcTaskType ");
            getActiveSvcTasksString.append("AND TRIM(SVC.BO_STATUS_CD) = TRIM(:parmActiveStatus) ");
            getActiveSvcTasksString.append("AND NOT EXISTS (SELECT 'X' FROM CI_WFM_OPT OPT, F1_SVC_TASK_CHAR CH1 ");
            getActiveSvcTasksString.append("                WHERE CH1.F1_SVC_TASK_ID = SVC.F1_SVC_TASK_ID ");
            getActiveSvcTasksString.append("                AND CH1.CHAR_TYPE_CD = :parmFundingTypCharType ");
            // Start changes 08-14-2013 Neha IM-036117
            //getActiveSvcTasksString.append("                AND TRIM(CH1.CHAR_VAL) = TRIM(OPT.WFM_OPT_VAL) ");
            CharacteristicTypeLookup charTypeLookup = parmSvcTaskFundingTypCharType.getCharacteristicType();
            if(charTypeLookup.isPredefinedValue()){
                getActiveSvcTasksString.append("AND TRIM(CH1.CHAR_VAL) = TRIM(OPT.WFM_OPT_VAL) ");
            }else if(charTypeLookup.isForeignKeyValue()){
                getActiveSvcTasksString.append("AND TRIM(CH1.CHAR_VAL_FK1) = TRIM(OPT.WFM_OPT_VAL) ");
            }else if(charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()){
                getActiveSvcTasksString.append("AND TRIM(CH1.ADHOC_CHAR_VAL) = TRIM(OPT.WFM_OPT_VAL) ");
            }
            // End changes 08-14-2013 Neha IM-036117
            getActiveSvcTasksString.append("                AND OPT.WFM_NAME = :parmFeatconfig ");
            getActiveSvcTasksString.append("                AND TRIM(OPT.EXT_OPT_TYPE) = TRIM(:parmOptionType)) ");
            getActiveSvcTasksString.append("AND CH2.F1_SVC_TASK_ID = SVC.F1_SVC_TASK_ID ");
            getActiveSvcTasksString.append("AND CH2.CHAR_TYPE_CD = :parmSACharType ");
            getActiveSvcTasksString.append("AND CH3.F1_SVC_TASK_ID = SVC.F1_SVC_TASK_ID ");
            getActiveSvcTasksString.append("AND CH3.CHAR_TYPE_CD = :parmAmtCharType ");
            getActiveSvcTasksString.append("GROUP BY CH2.CHAR_VAL_FK1 ");

            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement svcTasksPrepStmt = createPreparedStatement(getActiveSvcTasksString.toString());
            PreparedStatement svcTasksPrepStmt = createPreparedStatement(getActiveSvcTasksString.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            svcTasksPrepStmt.bindId("parmSvcTaskType", parmServiceTaskType.getId());
            svcTasksPrepStmt.bindId("parmFundingTypCharType", parmSvcTaskFundingTypCharType.getId());
            svcTasksPrepStmt.bindId("parmFeatconfig", parmEligFundingTypeFeatConfig.getId());
            svcTasksPrepStmt.bindStringProperty("parmOptionType", FeatureConfigurationOption.properties.optionType,parmEligFundingTypeOptionType);
            svcTasksPrepStmt.bindStringProperty("parmActiveStatus", ServiceTask.properties.status,parmPledgeActiveStatus);
            svcTasksPrepStmt.bindId("parmSACharType", parmSvcTaskSACharType.getId());      
            svcTasksPrepStmt.bindId("parmAmtCharType", parmSvcTaskAmtCharType.getId());    

            resultList = svcTasksPrepStmt.list();
            svcTasksPrepStmt.close();
            return resultList;          
        }
        
        //Start Add JVitug - B-23381 - 2022-09-05
        /**
         * This method returns the sum of Pledges for a given SA ID
         * @param saId
         * @return
         */
        private BigDecimal getSumOfPledges(ServiceAgreement_Id saId) {
        	StringBuilder stringSql = new StringBuilder();
        	BigDecimal returnValue = BigDecimal.ZERO;
        	
        	stringSql.append("SELECT ");
        	stringSql.append(   "SUM(TO_NUMBER(CH3.ADHOC_CHAR_VAL)) AS AMOUNT ");
        	stringSql.append("FROM ");
        	stringSql.append(   "F1_SVC_TASK_CHAR CH2, ");
        	stringSql.append(   "F1_SVC_TASK_CHAR CH3 ");
        	stringSql.append("WHERE ");
        	stringSql.append(   "CH2.CHAR_TYPE_CD = :parmSACharType ");
        	stringSql.append("AND ");
        	stringSql.append(   "TRIM(CH2.CHAR_VAL_FK1) = :saId ");
        	stringSql.append("AND ");
        	stringSql.append(   "CH2.F1_SVC_TASK_ID = CH3.F1_SVC_TASK_ID ");
        	stringSql.append("AND ");
        	stringSql.append(   "CH3.CHAR_TYPE_CD = :parmAmtCharType ");
        	
        	PreparedStatement sql = createPreparedStatement(stringSql.toString() , getClass().getName());
        	sql.bindId("parmSACharType", parmSvcTaskSACharType.getId());
        	sql.bindId("saId" , saId);
        	sql.bindId("parmAmtCharType", parmSvcTaskAmtCharType.getId());
        	
        	SQLResultRow result = sql.firstRow();
        	sql.close();
        	
        	if(notNull(result)) {
        		returnValue = result.getBigDecimal("AMOUNT");
        	}
        	
        	return returnValue;
        }
        //End Add JVitug - B-23381 - 2022-09-05
    }
}