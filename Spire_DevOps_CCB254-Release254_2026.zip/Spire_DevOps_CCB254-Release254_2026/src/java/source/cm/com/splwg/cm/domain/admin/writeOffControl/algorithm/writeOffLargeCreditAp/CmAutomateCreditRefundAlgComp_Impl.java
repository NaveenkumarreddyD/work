/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This algorithm will automate credit refund for SAs with credits.
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *   
 * 2019-12-03   JTiozon     CCB009.3. Initial version.  
 * 2020-08-25   JVitug      D-02143. Credit Refund Issue. Removed 
 *							setting the areSAsClosed flag to true if 
 * 							the account's balance is greater than zero.   
 * 2020-08-31   BMarquez    D-02143. Only process the SA if there are no
 *                          other non-closed, non-cancelled SAs on the
 *                          Account.               
 * *************************************************************************                
 */

package com.splwg.cm.domain.admin.writeOffControl.algorithm.writeOffLargeCreditAp;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.ListFilter;
import com.splwg.base.api.Query;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.algorithmType.AlgorithmTypeParameter_Id;
import com.splwg.base.domain.common.algorithmType.AlgorithmTypeParameter_LanguageId;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType_Id;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.admin.writeOffControl.algorithm.writeOffLargeCreditAp.WriteOffLargeCreditApAlgorithmSpot;
import com.splwg.ccb.domain.admin.writeOffDebtClass.entity.WriteOffDebtClass;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction;
import com.splwg.ccb.domain.financial.financialTransaction.entity.FinancialTransaction_Id;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
import com.splwg.ccb.domain.payment.payment.entity.PaymentCharacteristic;
import com.splwg.ccb.domain.payment.payment.entity.PaymentCharacteristics;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ServerMessage;

/**
 * @author jtiozon
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = refundThresholdAmount, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = doNotTransferCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = doNotTransferCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = transferAdjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = adjustmentType, name = refundAdjustmentType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = overpaymentSaType, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = toDoType, name = toDoType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = role, name = toDoRole, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = pledgePaymentCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = pledgePaymentCharValue, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = toDoEntryCharType, required = true, type = entity)})
 */
public class CmAutomateCreditRefundAlgComp_Impl extends
				CmAutomateCreditRefundAlgComp_Gen implements
					WriteOffLargeCreditApAlgorithmSpot {

	
	// hard parameters
	private Bool areServiceAgreementClosed =  Bool.FALSE;
	private Account account;
	private WriteOffDebtClass writeOffDebtClass;
	private Money writeOffDebtClassTotalBalance;
	
	// soft parameters
	private String refundThresholdAmount;
	private CharacteristicType doNotTransferCharType;
	private String doNotTransferCharValue;
	private AdjustmentType transferAdjustmentType;
	private AdjustmentType refundAdjustmentType;
	private String overpaymentSaTypeString;
	private ToDoType toDoType;
	private Role toDoRole;
	private CharacteristicType pledgePaymentCharType;
	private String pledgePaymentCharValue;
	private CharacteristicType toDoEntryCharType;
	
	// work variables
	private String algorithmCode;
	private ServiceAgreementType_Id overpaymentSaTypeId;
	
	@Override
	public Bool getAreServiceAgreementsClosed() {
		return areServiceAgreementClosed;
	}

	@Override
	public void setAccount(Account arg0) {
		account = arg0;
	}

	@Override
	public void setWriteOffDebtClass(WriteOffDebtClass arg0) {
		writeOffDebtClass = arg0;
	}

	@Override
	public void setWriteOffDebtClassTotalBalance(Money arg0) {
		writeOffDebtClassTotalBalance = arg0;
	}
	
	@Override
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) { 
		
		algorithmCode = this.getAlgorithm().getId().getTrimmedValue();
		
		// Retrieve Soft Parameters
		getSoftParameters();
		
		// Validate Refund Threshold Amount if valid numeric greater than 0
		isNumeric(refundThresholdAmount, 10);
		
		// Validate the Do Not Transfer Characteristic Type
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(doNotTransferCharType, CharacteristicEntityLookup.constants.SERVICE_AGREEMENT); 
        if(isNull(charEntityId.getEntity())){
        	addError(CustomMessageRepositorySpireOne.CCB009_3_algParmCharTypeInvalidForEntity(
        			algorithmCode, getAlgorithmParameterName(20), doNotTransferCharType.getId().getTrimmedValue(), 
        			CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().fetchLanguageDescription().trim()));
        }
		
        // Validate the Do Not Transfer Characteristic Value
        if (doNotTransferCharType.getCharacteristicType().isPredefinedValue()){
            CharacteristicValue_Id charValueId = new CharacteristicValue_Id(doNotTransferCharType, doNotTransferCharValue);

            if (isNull(charValueId.getEntity())) {
                addError(CustomMessageRepositorySpireOne.CCB009_3_algParmCharValueInvalidForCharType(
                		algorithmCode, getAlgorithmParameterName(30), doNotTransferCharValue.trim(), doNotTransferCharType.getId().getTrimmedValue()));
            }
        }
        
        // Validate the Pledge Payment Characteristic Type
        charEntityId = new CharacteristicEntity_Id(pledgePaymentCharType, CharacteristicEntityLookup.constants.PAYMENT);
        if(isNull(charEntityId.getEntity())){
        	addError(CustomMessageRepositorySpireOne.CCB009_3_algParmCharTypeInvalidForEntity(
        			algorithmCode, getAlgorithmParameterName(90), pledgePaymentCharType.getId().getTrimmedValue(), 
        			CharacteristicEntityLookup.constants.PAYMENT.getLookupValue().fetchLanguageDescription().trim()));
        }
        
        // Validate the Pledge Payment Characteristic Value
        if (doNotTransferCharType.getCharacteristicType().isPredefinedValue()){
            CharacteristicValue_Id charValueId = new CharacteristicValue_Id(pledgePaymentCharType, pledgePaymentCharValue);

            if (isNull(charValueId.getEntity())) {
                addError(CustomMessageRepositorySpireOne.CCB009_3_algParmCharValueInvalidForCharType(
                		algorithmCode, getAlgorithmParameterName(100), pledgePaymentCharValue.trim(), pledgePaymentCharType.getId().getTrimmedValue()));
            }
        }        
        
		// To Do Role must be valid for To Do Type
		if(notNull(toDoRole)){
			ToDoTypeRole_Id toDoTypeRoleId = new ToDoTypeRole_Id(toDoType, toDoRole);
	        if (isNull(toDoTypeRoleId.getEntity())) {
	            addError(CustomMessageRepositorySpireOne.CCB009_3_algParmInvalidRoleForToDoType(
	            		algorithmCode, getAlgorithmParameterName(80), toDoRole.getId().getTrimmedValue(), toDoType.getId().getTrimmedValue()));
	        }
		}
		
		// Validate the To Do Entry Characteristic Type
		charEntityId = new CharacteristicEntity_Id(toDoEntryCharType, CharacteristicEntityLookup.constants.TO_DO_ENTRY);
	    if(isNull(charEntityId.getEntity())){
	       	addError(CustomMessageRepositorySpireOne.CCB009_3_algParmCharTypeInvalidForEntity(
	       			algorithmCode, getAlgorithmParameterName(90), toDoEntryCharType.getId().getTrimmedValue(), 
	       			CharacteristicEntityLookup.constants.TO_DO_ENTRY.getLookupValue().fetchLanguageDescription().trim()));
	    }
	}

	private void getSoftParameters(){
		refundThresholdAmount = getRefundThresholdAmount(); 
		doNotTransferCharType = getDoNotTransferCharType();
		doNotTransferCharValue = getDoNotTransferCharValue();
		transferAdjustmentType = getTransferAdjustmentType();
		refundAdjustmentType = getRefundAdjustmentType();
		overpaymentSaTypeString = getOverpaymentSaType().trim();
		toDoType = getToDoType();
		toDoRole = getToDoRole();
		pledgePaymentCharType = getPledgePaymentCharType();
		pledgePaymentCharValue = getPledgePaymentCharValue();
		toDoEntryCharType = getToDoEntryCharType();
	}
	
	@Override
	public void invoke() { 		
	   
		// Validate Overpayment SA Type if valid for Account's CIS Division
		overpaymentSaTypeId = new ServiceAgreementType_Id(account.getDivisionId(), overpaymentSaTypeString);
		if(isNull(overpaymentSaTypeId.getEntity())){
			addError(CustomMessageRepositorySpireOne.CCB009_3_algParmNotValidSaTypeForCisDivision(algorithmCode, getAlgorithmParameterName(60), 
					overpaymentSaTypeString, account.getDivisionId().getTrimmedValue()));;			
		}
		
		//Check if the SA has a Open/Being Worked On To Do with To Do Type equal to the parameter
        //If found, do not process the SA and exit the algorithm.
        if(hasToDoEntry().isTrue()){
        	areServiceAgreementClosed = Bool.TRUE;
        	return;
        }
       
        // If WO Debt Class Total Balance >= 0, skip processing the SA       
        if(writeOffDebtClassTotalBalance.isGreaterThanOrEqual(Money.ZERO)){ 
        	//Start Delete JVitug - D-02143 - 2020-08-25
        	//areServiceAgreementClosed = Bool.TRUE;
        	//End Delete JVitug - D-02143 - 2020-08-25
        	return;
        }
        
        // Start Add - D-02142 - 2020-08-31
        if (isAccountClosing(account).isFalse()) {
            areServiceAgreementClosed = Bool.TRUE;
            return;
        }
        // End Add - D-02142 - 2020-08-31
        
        //Find all Write-Off eligible SAs for the given account and WO Debt Class, that do not have the Do not transfer characteristic type
        List<SQLResultRow> writeOffEligibleSaList = findWriteOffEligibleSas();  
        ServiceAgreement_Id creditSa = null;
        
        ServiceAgreement_Id firstSaId = null;
        
		if(writeOffEligibleSaList.size() > 0){
			firstSaId = (ServiceAgreement_Id) writeOffEligibleSaList.get(0).getId("SA_ID", ServiceAgreement.class);
			ServiceAgreement sa = firstSaId.getEntity(); 
			
			//Check if the first SA is an Overpayment SA
			// If the first SA retrieved is an Overpayment SA, use this SA as the credit SA to transfer other balances to.
			if(sa.getServiceAgreementType().fetchIdSaType().equals(overpaymentSaTypeId.getSaType())){			
				creditSa = firstSaId;
			}
			
		}else{
			return;
		}		
		//If the first SA retrieved is not an Overpayment SA, check if there is a non-closed/non-canceled Overpayment SA that exists for the account and same WO Debt Class
        if(isNull(creditSa)){        	
        	ServiceAgreement_Id tempOverPaymentSA  = checkOverPaymentSa();
        	if(notNull(tempOverPaymentSA)){
        		//If an Overpayment SA is found, use the overpayment SA as the credit SA to transfer other balances to
        		creditSa = tempOverPaymentSA;        		
        	}else{
        		//If no Overpayment SA is found, use current SA as the credit SA to transfer other balances to        		
        		creditSa = firstSaId;   		
        	}
        }
        // If the current balance of the SA is a credit, check if the credit is from a pledge payment.Check if the credit is from a pledge payment.
        if(creditSa.getEntity().getCurrentBalance().isNegative()){
        	if(checkIfCreditIsFromPledge(creditSa).isTrue()){ 
        		//End all processing and exit the algorithm.
        		areServiceAgreementClosed = Bool.TRUE;
				return;
        	}
        }
        
        //Process succeeding SAs
        List<ServiceAgreement_Id> nonOverpaymentSaList = new ArrayList<ServiceAgreement_Id>();
        Bool isPledgePaymentFound = Bool.FALSE;
        
        for(SQLResultRow row : writeOffEligibleSaList){
        	ServiceAgreement_Id saId = (ServiceAgreement_Id) row.getId("SA_ID", ServiceAgreement.class); 
        	
        	//Skip Credit/First SA        	
        	if(saId.getTrimmedValue().equals(creditSa.getTrimmedValue())){
        		continue;
        	}
        	// If the current balance of the SA is a credit, check if the credit is from a pledge payment.Check if the credit is from a pledge payment.
        	if(saId.getEntity().getCurrentBalance().isNegative()){ 
        		if(checkIfCreditIsFromPledge(saId).isTrue()){  
        			isPledgePaymentFound = Bool.TRUE;        			
        		}
        	}
        	
        	nonOverpaymentSaList.add(saId);
        	
        }        
        
        //End all processing and exit the algorithm.
		if(isPledgePaymentFound.isTrue()){
			areServiceAgreementClosed = Bool.TRUE;
			return;
		}      		

		//Process transfer balance
		for(ServiceAgreement_Id row : nonOverpaymentSaList){
			ServiceAgreement_Id saId = new ServiceAgreement_Id(row.getTrimmedValue());
			Money saCurrentBalance = saId.getEntity().getCurrentBalance(); 
			
			//Transfer balance to the Overpayment SA
	    	createTransferAdjustment(saId, creditSa, saCurrentBalance);
		}

    	
        // After all succeeding SAs are processed and balances have been transferred to the first SA, check the first SA for refund processing.
        BigDecimal creditSaBalance = creditSa.getEntity().getCurrentBalance().getAmount().abs();
        BigDecimal thresholdAmount = new BigDecimal(refundThresholdAmount);
        if(creditSaBalance.compareTo(thresholdAmount) <= 0){
        	//Generate and freeze the refund adjustment using the SA's credit balance
        	createRefundAdjustment(creditSa.getEntity(), creditSa.getEntity().getCurrentBalance()); 
        }else{
        	//Create a To Do with 'Credit balance $x.xx exceeds the threshold for automatic refund.'
        	ServerMessage message = CustomMessageRepositorySpireOne.CCB009_3_saBalanceExceededThreshold(creditSaBalance.toString());			
			createToDo(toDoType, toDoRole, message, creditSaBalance, creditSa);
        }
        
        areServiceAgreementClosed = Bool.TRUE; 
	}
	
	/** 
	 * This method check if SAs credit from from a pledge payment
	 * @param saId - Service Agreement
	 * @return - Bool
	 */
	private Bool checkIfCreditIsFromPledge(ServiceAgreement_Id saId){
		
		Money saCurrentBalance = saId.getEntity().getCurrentBalance();		
		BigDecimal absoluteSaCurrentBalance = saCurrentBalance.getAmount().abs(); 
		
		List<SQLResultRow> ftList  = checkSACreditFTs(saId);
		
		BigDecimal totalCurrentAmount = BigDecimal.ZERO;
		Bool isPledgePaymentFound = Bool.FALSE;
		
		for(SQLResultRow ftListRow : ftList){
			
			FinancialTransaction_Id ftId = (FinancialTransaction_Id) ftListRow.getId("FT_ID", FinancialTransaction.class);
			FinancialTransaction ft = ftId.getEntity();
			Payment payment = ft.fetchParentPayment();   		
			
			if(isPledgePaymentFound.isFalse()){ 
				
				if(notNull(payment)){
					PaymentCharacteristic payChar = checkPledgeCharOnPayment(payment);
        			
        			if(notNull(payChar)){
        				isPledgePaymentFound = Bool.TRUE;
        				
        				//Create a To Do with message 'Credit balance $x.xx for SA xxxxxxxxxx cannot be processed for automatic refund due to a pledge payment'.
        				ServerMessage message = CustomMessageRepositorySpireOne.CCB009_3_saBalanceCannotBeProcessedDueToPledgePayment(absoluteSaCurrentBalance.toString(), saId.getTrimmedValue());
        				
        				createToDo(toDoType, toDoRole, message, absoluteSaCurrentBalance, saId);
        				break;
        				
        			}
				}
				
				BigDecimal currentAmount = ft.getCurrentAmount().getAmount().abs();
    			totalCurrentAmount = totalCurrentAmount.add(currentAmount); 
    			
    			//Terminate loop if SA balance is less than the total computed current amount from credit FTs. This is to avoid searching pledge payment anymore.
    			if(saCurrentBalance.getAmount().abs().compareTo(totalCurrentAmount) <= 0){
    				break;
    			}
    			
			} 
			
			        			
		}
				
		return isPledgePaymentFound;
	}
	/**
	 * This method check if a string is numeric
	 * @param value - String to check
	 * @param paramSeq - Algorithm Parameter Seq
	 */
	private void isNumeric(String value, int paramSeq){ 
		 try {  
			    Double.parseDouble(value);
		 } catch(NumberFormatException e){  
			  addError(CustomMessageRepositorySpireOne.CCB009_3_algParmNotNumericGreaterthanZero(algorithmCode, getAlgorithmParameterName(paramSeq), value));
		 }
		 
		 if(Double.parseDouble(value) <= 0){
			 addError(CustomMessageRepositorySpireOne.CCB009_3_algParmNotNumericGreaterthanZero(algorithmCode, getAlgorithmParameterName(paramSeq), value));
		 }
	}
	
	/**
	 * This method gets the algorithm parameter name
	 * @param paramSeq - Parameter Seq
	 * @return algorithm parameter name
	 */
	private String getAlgorithmParameterName(int paramSeq){

		String paramName = "";      
		AlgorithmTypeParameter_Id algorithmTypeParameterId = new AlgorithmTypeParameter_Id(getAlgorithm().getAlgorithmType(), BigInteger.valueOf(paramSeq));        
		AlgorithmTypeParameter_LanguageId algorithmTypeParameterLanguageId = new AlgorithmTypeParameter_LanguageId(algorithmTypeParameterId, getActiveContextLanguage().getId());       
		paramName = algorithmTypeParameterLanguageId.getParent().fetchLanguageParameterLabel();
		return paramName;
	}
	
	/**
	 * This method check if a To Do Entry exists for the account
	 * @return Bool
	 */
	private Bool hasToDoEntry(){	

		StringBuilder sqlQuery = new StringBuilder();
    	
    	sqlQuery.append("SELECT " +
    						"TD.TD_ENTRY_ID "
    					+"FROM "
    						+"CI_TD_ENTRY TD "
    					+"WHERE "
    						+"TD_TYPE_CD = :toDoType "
    					+"AND ENTRY_STATUS_FLG <> :completed "
    					+"AND EXISTS(SELECT 'X' FROM "
    								+"CI_TD_ENTRY_CHA TDC "
    								+"WHERE TDC.CHAR_TYPE_CD = :accountCharType "
    								+"AND TDC.CHAR_VAL_FK1 = :account "
    								+"AND TDC.TD_ENTRY_ID = TD.TD_ENTRY_ID)");
    	
    	
    	PreparedStatement pStmt = createPreparedStatement(sqlQuery.toString(), getClass().getName());
    	pStmt.bindEntity("toDoType", toDoType);
    	pStmt.bindLookup("completed", ToDoEntryStatusLookup.constants.COMPLETED);
    	pStmt.bindEntity("accountCharType", toDoEntryCharType);
    	pStmt.bindStringProperty("account", ToDoEntryCharacteristic.properties.characteristicValueForeignKey1, account.getId().getTrimmedValue());
    	
    	SQLResultRow row = pStmt.firstRow();
    	
    	if(notNull(row)){
    		return Bool.TRUE;
    	}
    	
    	pStmt.close();
    	
		return Bool.FALSE;	
	}
	
	/**
	 * This method search all Write-Off Eligible SAs on the acocunt
	 * @return SQLResultRow
	 */
	private List<SQLResultRow> findWriteOffEligibleSas(){		
		
		List<SQLResultRow> results = new ArrayList<SQLResultRow>();
		
		StringBuilder sqlQuery = new StringBuilder();    
		
    	sqlQuery.append("SELECT "
    					    +"SA.SA_ID "
    					+"FROM "
    					    +"CI_ACCT AC, "
    					    +"CI_SA SA, "
    					    +"CI_SA_TYPE SATY "
    					+"WHERE "
    					    +"SA.ACCT_ID = :account "
    					+"AND AC.ACCT_ID = SA.ACCT_ID "
    					+"AND SA.SA_TYPE_CD = SATY.SA_TYPE_CD "
    					+"AND SATY.WO_DEBT_CL_CD = :writeOffDebtClass "
    					+"AND SATY.CIS_DIVISION = AC.CIS_DIVISION "
    					+"AND SA.SA_STATUS_FLG NOT IN (:closed,:cancelled) "
    					+"AND NOT EXISTS(SELECT 'X' "
    					               +"FROM CI_SA_CHAR SAC "
    					               +"WHERE SAC.CHAR_TYPE_CD = :doNotTransfer "
    					               +"AND (SAC.CHAR_VAL = :charVal "
    					                     +"OR SAC.ADHOC_CHAR_VAL = :adhocCharVal "
    					                     +"OR SAC.CHAR_VAL_FK1 = :charValFK1) "
    					               +"AND SAC.SA_ID = SA.SA_ID)");
    	
    	PreparedStatement pStmt = createPreparedStatement(sqlQuery.toString(), getClass().getName());
    	pStmt.bindId("account", account.getId());
    	pStmt.bindEntity("writeOffDebtClass", writeOffDebtClass);
    	pStmt.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
    	pStmt.bindLookup("cancelled", ServiceAgreementStatusLookup.constants.CANCELED);
    	pStmt.bindEntity("doNotTransfer", doNotTransferCharType);
    	pStmt.bindStringProperty("charVal", ServiceAgreementCharacteristic.properties.characteristicValue, doNotTransferCharValue);
    	pStmt.bindStringProperty("adhocCharVal", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, doNotTransferCharValue);
    	pStmt.bindStringProperty("charValFK1", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1, doNotTransferCharValue);
    	
    	results = pStmt.list();
		pStmt.close();
		
		return results;
		
	}
	
	/**
	 * This method search for an Overpayment SA of the account
	 * @return Service Agreement ID
	 */
	private ServiceAgreement_Id checkOverPaymentSa(){ 
		
		ServiceAgreement_Id saId = null;
		
		StringBuilder sqlQuery = new StringBuilder();    
		
    	sqlQuery.append("SELECT "
    					    +"SA.SA_ID "
    					+"FROM "
    					    +"CI_ACCT AC, "
    					    +"CI_SA SA, "
    					    +"CI_SA_TYPE SATY "
    					+"WHERE "
    					    +"SA.ACCT_ID = :account "
    					+"AND AC.ACCT_ID = SA.ACCT_ID "
    					+"AND SA.SA_TYPE_CD = :overpaymentSaType "
    					+"AND SA.SA_TYPE_CD = SATY.SA_TYPE_CD "
    					+"AND SATY.CIS_DIVISION = AC.CIS_DIVISION "
    					+"AND SA.SA_STATUS_FLG NOT IN (:closed,:cancelled)");
    	
    	PreparedStatement pStmt = createPreparedStatement(sqlQuery.toString(), getClass().getName());
    	pStmt.bindId("account", account.getId());
    	pStmt.bindStringProperty("overpaymentSaType", ServiceAgreementType.properties.saType, overpaymentSaTypeString);
    	pStmt.bindLookup("closed", ServiceAgreementStatusLookup.constants.CLOSED);
    	pStmt.bindLookup("cancelled", ServiceAgreementStatusLookup.constants.CANCELED);
    	
    	SQLResultRow row = pStmt.firstRow();
    	
    	if(notNull(row)){
    		saId = (ServiceAgreement_Id) row.getId("SA_ID", ServiceAgreement.class);
    	}
    	
    	pStmt.close();
    	
		return saId;
	}
	
	/**
	 * This method checks SAs Credit FTS
	 * @param saId
	 * @return SQLResultRow
	 */
	private List<SQLResultRow> checkSACreditFTs(ServiceAgreement_Id saId){		
		
		StringBuilder sqlQuery = new StringBuilder();    
		List<SQLResultRow> results = new ArrayList<SQLResultRow>();
		 
    	sqlQuery.append("SELECT "
    					    +"FT.FT_ID "
    					+"FROM "
    					    +"CI_FT FT "
    					+"WHERE "
    					    +"FT.SA_ID = :saId "
    					+"AND FT.FT_TYPE_FLG IN(:adjustment,:paySegment) "
    					+"AND FT.CUR_AMT < 0 "
    					+"ORDER BY FT.CRE_DTTM DESC");
    	
    	PreparedStatement pStmt = createPreparedStatement(sqlQuery.toString(), getClass().getName());
    	pStmt.bindId("saId", saId);
    	pStmt.bindLookup("adjustment", FinancialTransactionTypeLookup.constants.ADJUSTMENT); 
    	pStmt.bindLookup("paySegment", FinancialTransactionTypeLookup.constants.PAY_SEGMENT); 
		
    	results = pStmt.list();
    	pStmt.close();
    	
		return results;
	}
	
	/**
	 * This method checks if a payment is from a pledge
	 * @param payment
	 * @return Payment Characteristic
	 */
	private PaymentCharacteristic checkPledgeCharOnPayment(Payment payment){ 
		PaymentCharacteristics payChars = payment.getCharacteristics(); 
		ListFilter<PaymentCharacteristic> charFilter = payChars.createFilter("where this.id.characteristicType = :pledgePaymentCharType "
																			+"and (this.characteristicValue = :charVal "
																			    +"or this.adhocCharacteristicValue = :adhocCharVal "
																			    +"or this.characteristicValueForeignKey1 = :charValFK1)", getClass().getName());
		
		charFilter.bindEntity("pledgePaymentCharType", pledgePaymentCharType);
		charFilter.bindStringProperty("charVal", PaymentCharacteristic.properties.characteristicValue, pledgePaymentCharValue);
		charFilter.bindStringProperty("adhocCharVal", PaymentCharacteristic.properties.adhocCharacteristicValue, pledgePaymentCharValue);
		charFilter.bindStringProperty("charValFK1", PaymentCharacteristic.properties.characteristicValueForeignKey1, pledgePaymentCharValue);
    	
		PaymentCharacteristic payChar = charFilter.firstRow();
		
		return payChar;
	}
	
	// Start Add - D-02142 - 2020-08-31
    /**
     * This method checks if there are other SAs accepting credit for the account 
     * @param account
     * @return Bool
     */
    private Bool isAccountClosing(Account account){
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FROM ServiceAgreement SA, ServiceAgreementType SAT  ");
        stringBuilder.append("WHERE SA.status NOT IN (:closedStatus, :cancelledStatus) ");
        stringBuilder.append("AND SA.account = :account ");
        stringBuilder.append("AND SA.serviceAgreementType.id.division = SAT.id.division  ");
        stringBuilder.append("AND SA.serviceAgreementType.id.saType = SAT.id.saType ");
        stringBuilder.append("AND SAT.writeOffDebtClass.id <> :woDebtClassCode ");
        Query<ServiceAgreement> query = createQuery(stringBuilder.toString(), "isAccountActive");
        query.bindEntity("account", account);
        query.bindId("woDebtClassCode", writeOffDebtClass.getId());
        query.bindLookup("closedStatus", ServiceAgreementStatusLookup.constants.CLOSED);
        query.bindLookup("cancelledStatus", ServiceAgreementStatusLookup.constants.CANCELED);

        query.addResult("sa", "SA");
        if (notNull(query.firstRow())){
            return Bool.FALSE;
        }
        return Bool.TRUE;
    }
    // End Add - D-02142 - 2020-08-31
	
	/**
	 * This method creates a To Do Entry
	 * @param tdType - To Do Type
	 * @param tdRole - To Do Role
	 * @param message - Server Message
	 * @return ToDoCreator
	 */
	private void createToDo(ToDoType tdType, Role tdRole, ServerMessage message, BigDecimal saBalance, ServiceAgreement_Id saId){
		
		ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
		ToDoEntry_DTO toDoEntryDto = toDoCreator.getToDoDTO();
		
		// Create a new ToDo
        toDoEntryDto.setToDoTypeId(tdType.getId());
        if (isNull(tdRole)){
            toDoEntryDto.setToDoRoleId(tdType.getDefaultRole().fetchIdToDoRole().getId());
        } else {
            toDoEntryDto.setToDoRoleId(tdRole.getId());
        }
        toDoEntryDto.setMessageId(message.getMessageId());
        toDoEntryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.OPEN);
        toDoEntryDto.setCreationDateTime(this.getProcessDateTime());
        toDoCreator.setToDoDTO(toDoEntryDto);
        
        // Sets the Message Parameter Values
        for(Object parm : message.getMessageParameters().getRawParameters()){
        	toDoCreator.addMessageParameter(parm.toString());
        }
       
        toDoCreator.addSortKeyValue(new ToDoSortKeyType_Id(tdType, BigInteger.TEN).getEntity(), saBalance.toString());
        toDoCreator.addSortKeyValue(new ToDoSortKeyType_Id(tdType, BigInteger.valueOf(20)).getEntity(), message.getNumber().toString());
        toDoCreator.addDrillKeyValue(new ToDoDrillKeyType_Id(tdType, BigInteger.TEN).getEntity(), saId.getTrimmedValue());
        
        toDoCreator.create(); 
      
	}
	
	/**
     * This method creates a transfer adjustment on the target SA
     * by deducts the amount from the source SA
     * @param sourceSA
     * @param targetSA
     * @param amount
     */
    private void createTransferAdjustment(ServiceAgreement_Id sourceSA, ServiceAgreement_Id targetSA, Money amount) {
    	
        CreateFrozenAdjustmentData frozenAdjData = CreateFrozenAdjustmentData.Factory.newInstance();
        frozenAdjData.setServiceAgreement(sourceSA.getEntity());
        frozenAdjData.setAdjustmentType(transferAdjustmentType);
        frozenAdjData.setAdjustmentAmount(amount);
        frozenAdjData.setAllowZeroAmount(Bool.FALSE);
        frozenAdjData.setTransferServiceAgreement(targetSA.getEntity());
        CreateFrozenAdjustment frozenAdjustment = CreateFrozenAdjustment.Factory.newInstance();
        frozenAdjData = frozenAdjustment.createFrozenAdjustment(frozenAdjData);        
    }    

    /**
     * This method creates a refund adjustment on the
     * on the input SA
     */
    private void createRefundAdjustment(ServiceAgreement sa,  Money amount) {      
        CreateFrozenAdjustmentData frozenAdjData = CreateFrozenAdjustmentData.Factory.newInstance();
        frozenAdjData.setServiceAgreement(sa);
        frozenAdjData.setAdjustmentType(refundAdjustmentType);
        frozenAdjData.setAdjustmentAmount(amount.negate());
        frozenAdjData.setAllowZeroAmount(Bool.FALSE);
        CreateFrozenAdjustment frozenAdjustment = CreateFrozenAdjustment.Factory.newInstance();
        frozenAdjData = frozenAdjustment.createFrozenAdjustment(frozenAdjData);        
    }
}
