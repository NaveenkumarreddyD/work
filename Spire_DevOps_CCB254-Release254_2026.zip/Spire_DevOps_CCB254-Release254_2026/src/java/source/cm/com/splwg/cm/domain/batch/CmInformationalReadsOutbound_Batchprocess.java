/*
 ***************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * This custom Batch Process will extract non-AMR reads and Meter Reads 
 * that come from certain sources (e.g. G4, Maximo, Non-Office Estimated 
 * Online Reads, L&G Manual Read, and Transportation Read) 
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-04-30   Raviteja        NI0028.7 Initial Version.    
 * 2013-24-05   Srikanth        TIR_1 NPE for TOU 
 * 2013-06-06   Murali          CR90 Changes
 * 2013-11-06   Srikanth        TIR 3 - Corr/Uncorr Character Incorrect in output file
 * 2014-08-27   WCaranda        MGE-CCB013. 
 *                              - Added parameter CIS_DIVISION;
 *                              - Updated MAIN SQL to exclude MGE Meter Reads; and
 *                              - Cleaned up code to remove warnings (e.g. unused imports, unused variables, etc). 
 * 2016-01-29  	MPang			Updated for CCB v2.4 compilation.
 * 2018-07-25   SFelip          CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                              longer needed.                              
 **************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Lookup;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfigurationOption;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.FieldActivityStepTypeActionLookup;
import com.splwg.ccb.api.lookup.MeterOnOffStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointMeterEventTypeLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.itemType.ItemType;
import com.splwg.ccb.domain.admin.meterReadSource.MeterReadSource_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.Register;
import com.splwg.ccb.domain.meterread.meterConfiguration.Register_Id;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.MeterRead_Id;*/

import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.itemType.entity.ItemType;
import com.splwg.ccb.domain.admin.meterReadSource.entity.MeterReadSource_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint_Id;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register;
import com.splwg.ccb.domain.meterread.meterConfiguration.entity.Register_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead;
import com.splwg.ccb.domain.meterread.meterRead.entity.MeterRead_Id;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.common.CmFeatureConfigurationRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.StringUtilities;


/**
 * @author rgullapall003
 *
 @BatchJob (
 *      modules = {},
 *      multiThreaded = true, 
 *      rerunnable = false,
 *      softParameters = {@BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = MR_SOURCE_FEAT_CONFIG, required = true, type = entity)
 *            , @BatchJobSoftParameter (lookupName = cmInformationalMeterReadSourceOption, name = MR_SOURCE_FEAT_OPTION, required = true, type = lookup)
 *            , @BatchJobSoftParameter (entityName = itemType, name = AMR_DEVICE_ITEM_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = UOM_FEAT_CONFIG, required = true, type = entity)
 *            , @BatchJobSoftParameter (lookupName = cmUnitOfMeasure, name = CORR_REG_FEAT_OPTION, required = true, type = lookup)
 *            , @BatchJobSoftParameter (lookupName = cmUnitOfMeasure, name = UNCOR_REG_FEAT_OPTION, required = true, type = lookup)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = UOM_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = TOU_CHAR_TYPE, required = false, type = entity) 
 *            , @BatchJobSoftParameter (entityName = cisDivision, name = CIS_DIVISION, required = true, type = entity) })
 */


public class CmInformationalReadsOutbound_Batchprocess extends
CmInformationalReadsOutbound_Batchprocess_Gen {

    //Input Batch parameters
    private  FeatureConfiguration featureConfiguration;

    // Murali - Start Changes - CR90 - 06/06/2013

    private static FeatureConfiguration parmWfmName;
    private static Lookup corRegFeatConfigOptType;
    private static Lookup uncorRegFeatConfigOptType;

    // Murali - End Changes - CR90 -06/07/2013

    private static CharacteristicType uomCharType;
    private static CharacteristicType touCharType; 
    private Lookup strFcOptionType;
    private static ItemType itemTypeAMRDevice;
    private static String strFilePath;
    private static String strFileName;
    /* private static UnitOfMeasure correctedUOM;
    private static UnitOfMeasure unCorrectedUOM;*/
    
    // Start Add - 2014-08-27 - WCaranda - MGE-CCB013
    private static CisDivision cisDivision;
    // End Add - 2014-08-27 - WCaranda - MGE-CCB013

    //Class Variable
    private List<MeterReadSource_Id> mtrSrcIdList;

    //Program Constants
    private static final String BADGE_NUMBER = "BADGE_NBR";
    private static final String SP_ID = "SP_ID";
    private static final String REG_ID = "REG_ID";
    private static final String READ_DTTM = "READ_DTTM";
    private static final String REGREAD = "REGREAD";
    private static final String MFGCD = "MFG_CD";
    private static final String MR_CYC_CD = "MR_CYC_CD";
    private static final String MR_RTE_CD = "MR_RTE_CD";

    public void validateSoftParameters(boolean isNewRun){
        initializeSoftParams();
        // Validate if the file path is valid
        File folder = new File(strFilePath);
        if(!(folder.exists() && folder.isDirectory())) {
            addError(CustomMessageRepository.ni0028_7InvalidFilePath(strFilePath));
        }
        // Check if the override maximum errors is less than 0
        BigInteger parmMaxErrors = getParameters().getSoftMaxErrors();
        if (notNull(parmMaxErrors) && parmMaxErrors.intValue() < 0) {
            addError(CustomMessageRepository.ni0028_7IntegerParamCannotBeNegative(parmMaxErrors.toString().trim())); 
        }

        int tempThreadCount = getParameters().getThreadCount().intValue();
        // Start Delete - 2014-08-27 - WCaranda - MGE-CCB013
        //int tempThreadCountRemainder = 0;
        // End Delete - 2014-08-27 - WCaranda - MGE-CCB013
        char[] fileNameArray = strFileName.toCharArray();
        for (int curPos = strFileName.length()-1; curPos >= 0; curPos--){
            if (fileNameArray[curPos] == '?') {
                int curIndex = curPos;
                for (; (curIndex >= 0 && fileNameArray[curIndex] == '?' ); curIndex--){
                	// Start Delete - 2014-08-27 - WCaranda - MGE-CCB013
                    //tempThreadCountRemainder = tempThreadCount % 10;
                    // End Delete - 2014-08-27 - WCaranda - MGE-CCB013
                    tempThreadCount = tempThreadCount / 10;
                }
                if(tempThreadCount !=0){
                    addError(CustomMessageRepository.ni0028_7PlaceHolderNotSufficient()); 
                } 
                curPos = curIndex;
            }
        }
        validateCharTypes();
        validateFCOption();
    }




    private void initializeSoftParams(){
        featureConfiguration = getParameters().getMR_SOURCE_FEAT_CONFIG();
        touCharType = getParameters().getTOU_CHAR_TYPE();
        uomCharType = getParameters().getUOM_CHAR_TYPE();
        strFcOptionType = getParameters().getMR_SOURCE_FEAT_OPTION();
        itemTypeAMRDevice = getParameters().getAMR_DEVICE_ITEM_TYPE();
        strFilePath = getParameters().getFILE_PATH();
        strFileName = getParameters().getFILE_NAME();
        // Start Changes - Murali - 06/06/2013

        parmWfmName = getParameters().getUOM_FEAT_CONFIG();

        corRegFeatConfigOptType = getParameters().getCORR_REG_FEAT_OPTION();

        uncorRegFeatConfigOptType = getParameters().getUNCOR_REG_FEAT_OPTION();

        // End Changes - Murali - 06/06/2013

        /*correctedUOM = getParameters().getCORRECTED_UOM_CD();
        unCorrectedUOM = getParameters().getUNCORRECTED_UOM_CD();
         */
        
        // Start Add - 2014-08-27 - WCaranda - MGE-CCB013
        cisDivision = getParameters().getCIS_DIVISION(); 
        // End Add - 2014-08-27 - WCaranda - MGE-CCB013
    }

    private void validateCharTypes(){
        CharacteristicEntity charEntity = null;

        charEntity = new CharacteristicEntity_Id(uomCharType,CharacteristicEntityLookup.constants.ITEM).getEntity();
        if(isNull(charEntity)){
            addError(CustomMessageRepository.ni0028_7UOMCharTypeInvalidForItemEntity(uomCharType.getId().getTrimmedValue())); 
        }

        charEntity = new CharacteristicEntity_Id(uomCharType,CharacteristicEntityLookup.constants.ITEM_TYPE).getEntity();
        if(isNull(charEntity)){
            addError(CustomMessageRepository.ni0028_7UOMCharTypeInvalidForItemTypeEntity(uomCharType.getId().getTrimmedValue())); 
        }

        if(notNull(touCharType)){
            charEntity = new CharacteristicEntity_Id(touCharType,CharacteristicEntityLookup.constants.ITEM).getEntity();
            if(isNull(charEntity)){
                addError(CustomMessageRepository.ni0028_7TOUCharTypeInvalidForItemEntity(uomCharType.getId().getTrimmedValue())); 
            }

            charEntity = new CharacteristicEntity_Id(touCharType,CharacteristicEntityLookup.constants.ITEM_TYPE).getEntity();
            if(isNull(charEntity)){
                addError(CustomMessageRepository.ni0028_7TOUCharTypeInvalidForItemTypeEntity(uomCharType.getId().getTrimmedValue())); 
            }
        }
    }

    @SuppressWarnings("unchecked")
	private void validateFCOption(){
        boolean isExists = false;
        for( FeatureConfigurationOption featureConfigurationOption : featureConfiguration.getOptions()){
            if(strFcOptionType.trimmedValue().equals(featureConfigurationOption.fetchIdOptionType().trim())){
                CmFeatureConfigurationRetriever cmFeatureConfigurationRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
                cmFeatureConfigurationRetriever.setParmWFMName(featureConfiguration);
                cmFeatureConfigurationRetriever.setParmOptType(strFcOptionType.trimmedValue());
                List<String> mrSourceList = cmFeatureConfigurationRetriever.getListOfOptionValues();
                if(mrSourceList.size() == 0){
                    addError(CustomMessageRepository.ni0028_7BlankMeterSource(featureConfiguration.getId().getTrimmedValue()));
                }
                validateAndGetMeterReadSource(mrSourceList);
                isExists = true;
            }
        } 
        if(!isExists){
            addError(CustomMessageRepository.ni0028_7MeterSourceOptionTypeNotConfigured(featureConfiguration.getId().getTrimmedValue()));
        }
    }

    private void validateAndGetMeterReadSource(List<String> mrSourceList){
        MeterReadSource_Id mtrSrcId = null;
        mtrSrcIdList = new ArrayList<MeterReadSource_Id>();
        for(String strMrSource : mrSourceList ){
            mtrSrcId =  new  MeterReadSource_Id(strMrSource);
            if(isNull(mtrSrcId.getEntity())){
                addError(CustomMessageRepository.ni0028_7InvalidMeterSource(strMrSource,featureConfiguration.getId().getTrimmedValue()));
            }
            mtrSrcIdList.add(mtrSrcId)   ;		
        }

    }

    @SuppressWarnings("unchecked")
	public JobWork getJobWork() {       
        QueryIterator mainIter = retrieveMeterReadDetails().iterate();
        return createJobWorkForQueryIterator(mainIter, this);

    }

    private PreparedStatement retrieveMeterReadDetails(){

        StringBuilder getMeterDetails = new StringBuilder();
        getMeterDetails.append("SELECT MR.MR_ID,REG.REG_ID ,MTR.BADGE_NBR,SP.SP_ID, SP.MR_CYC_CD , SP.MR_RTE_CD , MR.READ_DTTM,REGRD.REG_READING REGREAD, MTR.MFG_CD ");
        getMeterDetails.append("FROM CI_MR MR, CI_MTR_CONFIG MC, CI_MTR MTR, CI_SP_MTR_HIST SMHIST, CI_SP SP,CI_REG_READ REGRD,CI_REG REG,  CI_SP_MTR_EVT EVT, CI_MR MR1 ");
        getMeterDetails.append("WHERE TRUNC(MR.READ_DTTM) = :mrReadDateTime ");
        getMeterDetails.append("AND MR.MR_SOURCE_CD IN (  ");
        int counter = 0;
        for (;counter < mtrSrcIdList.size(); counter++) {
            if (counter == 0) {
                getMeterDetails.append(":mtrSrcId" + counter);
            } else {
                getMeterDetails.append(", :mtrSrcId" + counter);
            }
        }
        getMeterDetails.append(") ");
        getMeterDetails.append("AND MR.MTR_CONFIG_ID = MC.MTR_CONFIG_ID ");
        getMeterDetails.append("AND SMHIST.MTR_CONFIG_ID  = MC.MTR_CONFIG_ID ");
        getMeterDetails.append("AND MTR.MTR_ID = MC.MTR_ID ");
        getMeterDetails.append("AND SP.SP_ID = SMHIST.SP_ID ");
        getMeterDetails.append("AND EVT.SP_MTR_EVT_FLG = :install ");
        getMeterDetails.append("AND EVT.SP_MTR_HIST_ID = SMHIST.SP_MTR_HIST_ID ");
        getMeterDetails.append("AND EVT.MR_ID = MR1.MR_ID ");
        getMeterDetails.append("AND MR1.READ_DTTM <= MR.READ_DTTM ");
        getMeterDetails.append("AND (SMHIST.REMOVAL_DTTM IS NULL OR (SMHIST.REMOVAL_DTTM >= MR.READ_DTTM)) ");
        getMeterDetails.append("AND MR.MR_ID = REGRD.MR_ID ");
        getMeterDetails.append("AND REG.REG_ID = REGRD.REG_ID ");
        // Start Add - 2014-08-27 - WCaranda - MGE-CCB013
        getMeterDetails.append("AND EXISTS ( ");
        getMeterDetails.append("    SELECT 'X' ");
        getMeterDetails.append("    FROM ");
        getMeterDetails.append("        CI_PREM PREM ");
        getMeterDetails.append("    WHERE ");
        getMeterDetails.append("        PREM.PREM_ID = SP.PREM_ID ");
        getMeterDetails.append("        AND PREM.CIS_DIVISION = :cisDivision ");
        getMeterDetails.append(") ");
        // End Add - 2014-08-27 - WCaranda - MGE-CCB013
        //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        //PreparedStatement pstmt =  createPreparedStatement(getMeterDetails.toString());
        PreparedStatement pstmt =  createPreparedStatement(getMeterDetails.toString(), getClass().getName());
        //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
        pstmt.bindDate("mrReadDateTime", getProcessDateTime().getDate().addDays(-1));
        pstmt.bindLookup("install", ServicePointMeterEventTypeLookup.constants.INSTALL);
        // Start Add - 2014-08-27 - WCaranda - MGE-CCB013
        pstmt.bindId("cisDivision", cisDivision.getId());
        // End Add - 2014-08-27 - WCaranda - MGE-CCB013
        counter = 0;
        for (MeterReadSource_Id mrsId : mtrSrcIdList) {
            pstmt.bindId("mtrSrcId" + counter++, mrsId);
        }
        return pstmt;	
    }

    public ThreadWorkUnit createWorkUnit(QueryResultRow row){

        ThreadWorkUnit threadUnit = new ThreadWorkUnit();             
        MeterRead_Id mtrReadId = (MeterRead_Id) row.getId("MR_ID", MeterRead.class);
        threadUnit.setPrimaryId(mtrReadId);
        threadUnit.addSupplementalData(REG_ID, ((Register_Id)row.getId("REG_ID", Register.class)));
        threadUnit.addSupplementalData(BADGE_NUMBER, row.getString("BADGE_NBR"));
        threadUnit.addSupplementalData(SP_ID, ((ServicePoint_Id)row.getId("SP_ID", ServicePoint.class)));
        threadUnit.addSupplementalData(MR_CYC_CD, row.getString("MR_CYC_CD"));
        threadUnit.addSupplementalData(MR_RTE_CD, row.getString("MR_RTE_CD"));
        threadUnit.addSupplementalData(READ_DTTM, row.getDateTime("READ_DTTM"));
        threadUnit.addSupplementalData(REGREAD, row.getBigDecimal("REGREAD"));
        threadUnit.addSupplementalData(MFGCD, row.getString("MFG_CD"));
        return threadUnit;
    } 



    public Class<CmInformationalReadsOutbound_BatchprocessWorker> getThreadWorkerClass() {
        return CmInformationalReadsOutbound_BatchprocessWorker.class;
    }



    public static class CmInformationalReadsOutbound_BatchprocessWorker extends
    CmInformationalReadsOutbound_BatchprocessWorker_Gen {
        // Thread Class Variables
        private BufferedWriter bufferedWriter;
        private File inputFilePathAndName;
        private String strNewFileName;
        private static StringBuilder stringDetailsReportBuilder;
        private Register register;
        private MeterRead_Id mrId ;
        private ServicePoint_Id spId;
        private List<String> correctedList = null;
        private List<String> unCorrectedList = null;
        private Integer listSize= 0;

        //Constants
        private final Integer METER_NBR_LEN = 16;
        private final Integer SERVICE_TYPE_LEN = 1;
        private final Integer TBL_MFG_LEN = 1;
        private final Integer UTIL_COMPANY_LEN = 2;
        private final Integer SERVICE_POINT_LEN = 10;
        private final Integer MR_CYC_CD_LEN = 4;
        private final Integer MR_RTE_CD_LEN = 8;
        private final Integer AMR_DEVICE_LEN = 1;
        private final Integer READ_DATE_LEN = 8;
        private final Integer READ_HIST_TRANS_LEN = 4;
        private final Integer READ_LEN = 9;

        //File Record Constants
        private final String NOT_AMR_DVC = "N";
        private final String AMR_DVC = "Y";
        private final String SRVC_TYPE ="G";
        private final String UTIL_COMP ="LG";
        private final String UNCORR_REG_CHAR ="U";

        private final String INSTALL = "MTRI";
        private final String MTROFF = "TOFF";
        private final String MTRON = "TONN";
        private final String MTRMVL = "MTRM";

        private final String STARTSTOP = "TFTO";
        private final String DISC = "DISC";
        private final String TEST = "TEST";
        private final String READMETER = "MTRO";


        // Record fields
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

        public void initializeThreadWork(boolean initializationPreviouslySuccessful) throws ThreadAbortedException,
        RunAbortedException {

            int tempThreadCount = getBatchThreadNumber().intValue();
            int tempThreadCountRemainder = 0;
            char[] fileNameArray = strFileName.toCharArray();
            for (int curPos = strFileName.length()-1; curPos >= 0; curPos--){
                if (fileNameArray[curPos] == '?') {
                    int curIndex = curPos;
                    for (; (curIndex >= 0 && fileNameArray[curIndex] == '?' ); curIndex--){
                        tempThreadCountRemainder = tempThreadCount % 10;
                        tempThreadCount = tempThreadCount / 10;
                        fileNameArray[curIndex] = String.valueOf(tempThreadCountRemainder).charAt(0);
                    }
                    curPos = curIndex;
                }
            }
            strNewFileName = String.valueOf(fileNameArray);
            openFileWriter();
        }

        public boolean executeWorkUnit(ThreadWorkUnit unit)
        throws ThreadAbortedException, RunAbortedException {

            DateTime readDttm =  null;
            BigDecimal regRead = null;
            String mfgCd = null;
            String mtrNumber = null;
            String mtrRoute = null;
            String sp = null;
            String mtrCycle = null;
            String amrDevice = null;
            String tblMfg = null;
            String readHistTrans = null;


            spId= null;
            mrId = null;
            register = null;
            listSize = 0;

            mrId = (MeterRead_Id) unit.getPrimaryId();
            mtrNumber = ((String) unit.getSupplementallData(BADGE_NUMBER)).trim();
            spId = (ServicePoint_Id)unit.getSupplementallData(SP_ID);
            sp  = spId.getIdValue().trim();
            mtrCycle = ((String) unit.getSupplementallData(MR_CYC_CD)).trim();
            mtrRoute = ((String) unit.getSupplementallData(MR_RTE_CD)).trim(); 
            register = ((Register_Id) unit.getSupplementallData(REG_ID)).getEntity();
            readDttm = (DateTime)unit.getSupplementallData(READ_DTTM); 
            regRead = (BigDecimal)unit.getSupplementallData(REGREAD); 
            mfgCd  = ((String) unit.getSupplementallData(MFGCD)).trim();
            
            //TIR - 06//11/2013
            if(isNull(correctedList))
                correctedList = retrieveFCOptionValuesList(corRegFeatConfigOptType.trimmedValue());
             if(isNull(unCorrectedList))
             	unCorrectedList = retrieveFCOptionValuesList(uncorRegFeatConfigOptType.trimmedValue());
            

            // Start Changes - CR - Propane Meters - 06/05/2013 

            Meter_Id  meterId = register.getMeterConfiguration().getMeter().getId();

          //TIR - 06//11/2013
           if(isCorrectedUOM().isTrue()){
            // Get Corrected Register Information
              List<SQLResultRow> corrRegResultRowList =  getRegisterData(corRegFeatConfigOptType.trimmedValue());
              listSize = corrRegResultRowList.size();
            // If more than One Correct Register is found for the Meter , Log a warning and proceed to the next record
             if(listSize > 1)    {
                logWarning(CustomMessageRepository.ni0028_7MoreThanOneCorrRegData(register.getId().getTrimmedValue(), meterId.getTrimmedValue())); 
                return true;
             }  
             if(listSize == 1)    {
                tblMfg = mfgCd.substring(0,1).toUpperCase();
             }
           }else if(isUnCorrectedUOM().isTrue()){ // Get Uncorrected Register Information
              List<SQLResultRow> uncorrRegResultRowList =  getRegisterData(uncorRegFeatConfigOptType.trimmedValue());
              listSize = uncorrRegResultRowList.size();
              if(listSize > 1)    {
                logWarning(CustomMessageRepository.ni0028_7MoreThanOneUnCorrRegData(register.getId().getTrimmedValue(),  meterId.getTrimmedValue())); 
                return true;
              }  
              if(listSize == 1)    {
                tblMfg = UNCORR_REG_CHAR;
              }
           }

            /* if(register.getUnitOfMeasure().getId().compareTo(unCorrectedUOM.getId()) == 0)
                    tblMfg = UNCORR_REG_CHAR;
                else if(register.getUnitOfMeasure().getId().compareTo(correctedUOM.getId()) == 0)
                    tblMfg = mfgCd.substring(0,1).toUpperCase();
             */

            if(listSize == 1 ){

                // End of changes - CR - 06/06/2013
                if(isAMRDevice().isFalse())
                    amrDevice = NOT_AMR_DVC;
                else
                    amrDevice =  AMR_DVC;

                readHistTrans = getReadHistTransactionString();

                stringDetailsReportBuilder = new StringBuilder();
                stringDetailsReportBuilder.append(padLeft(mtrNumber, METER_NBR_LEN));
                stringDetailsReportBuilder.append(padLeft(SRVC_TYPE, SERVICE_TYPE_LEN));
                stringDetailsReportBuilder.append(padLeft(tblMfg, TBL_MFG_LEN));  
                stringDetailsReportBuilder.append(padLeft(UTIL_COMP, UTIL_COMPANY_LEN));
                stringDetailsReportBuilder.append(padLeft(sp, SERVICE_POINT_LEN));
                stringDetailsReportBuilder.append(padLeft(mtrCycle, MR_CYC_CD_LEN));
                stringDetailsReportBuilder.append(padLeft(mtrRoute, MR_RTE_CD_LEN));
                stringDetailsReportBuilder.append(padLeft(amrDevice, AMR_DEVICE_LEN));  
                stringDetailsReportBuilder.append(padLeft(formatDate(readDttm), READ_DATE_LEN));
                stringDetailsReportBuilder.append(padLeft(readHistTrans, READ_HIST_TRANS_LEN));
                stringDetailsReportBuilder.append(padLeft(regRead.longValue()+"", READ_LEN));

                writeLine(stringDetailsReportBuilder.toString());
            }
            return true;

        }
        
        
        private List<SQLResultRow> getRegisterData(String uomStr) {

            StringBuilder regDataQueryStr = new StringBuilder();

            regDataQueryStr.append(" SELECT 'X' FROM CI_REG REG");
            regDataQueryStr.append(" WHERE  REG.MTR_ID = :meterId");
            regDataQueryStr.append(" AND @trim(REG.UOM_CD) IN (SELECT WFM_OPT_VAL FROM CI_WFM_OPT ");
            regDataQueryStr.append("                           WHERE WFM_NAME = :featConfigName ");
            regDataQueryStr.append("                           AND EXT_OPT_TYPE = :optionType ) ");
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement regDataPrepStmt =  createPreparedStatement(regDataQueryStr.toString());
            PreparedStatement regDataPrepStmt =  createPreparedStatement(regDataQueryStr.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            regDataPrepStmt.bindId("meterId", register.getMeterConfiguration().getMeter().getId());
            regDataPrepStmt.bindEntity("featConfigName", parmWfmName);
            regDataPrepStmt.bindStringProperty("optionType", FeatureConfigurationOption.properties.optionType,uomStr);

            List<SQLResultRow> resultRowList = regDataPrepStmt.list();

            regDataPrepStmt.close();

            return resultRowList; 
        }
        
      //TIR - 06//11/2013
        private Bool isCorrectedUOM(){
        	String strRegUom = register.getUnitOfMeasure().getId().getIdValue().trim();
             for(String uom : correctedList){
            	 if(uom.trim().equalsIgnoreCase(strRegUom))
            		 return Bool.TRUE;
             }
             return Bool.FALSE;
             
        }
        
      //TIR - 06//11/2013
        private Bool isUnCorrectedUOM(){
        	String strRegUom = register.getUnitOfMeasure().getId().getIdValue().trim();
             for(String uom : unCorrectedList){
            	 if(uom.trim().equalsIgnoreCase(strRegUom))
            		 return Bool.TRUE;
             }
             return Bool.FALSE;
             
        }
        
        
      //TIR - 06//11/2013 
        @SuppressWarnings("unchecked")
		private List<String> retrieveFCOptionValuesList(String strOptionValue){
        	List<String> optValuesList = new ArrayList<String>();
            CmFeatureConfigurationRetriever cmFeatureConfigRetriever = CmFeatureConfigurationRetriever.Factory.newInstance();
            cmFeatureConfigRetriever.setParmWFMName(parmWfmName);
            cmFeatureConfigRetriever.setParmOptType(strOptionValue);
            optValuesList = cmFeatureConfigRetriever.getListOfOptionValues();
            
            return optValuesList;
        }

        private Bool isAMRDevice(){
            Bool isAMR = Bool.TRUE;

            StringBuilder getAMRMeterDevice = new StringBuilder();
            getAMRMeterDevice.append("SELECT COUNT(*) COUNT ");
            getAMRMeterDevice.append("FROM CI_MTR_EQ MTRE,CI_ITEM ITEM,CI_ITEM_CHAR ICHAR  ");
            getAMRMeterDevice.append("WHERE MTRE.MTR_ID = :meterId ");
            getAMRMeterDevice.append("AND MTRE.ITEM_ID_EQ = ITEM.ITEM_ID ");
            getAMRMeterDevice.append("AND ICHAR.ITEM_ID = ITEM.ITEM_ID ");
            getAMRMeterDevice.append("AND ITEM.ITEM_TYPE_CD = :itemType ");
            getAMRMeterDevice.append("AND (MTRE.REMOVAL_DT IS NULL OR  MTRE.REMOVAL_DT > = :processDt) ");
            getAMRMeterDevice.append("AND (ICHAR.CHAR_TYPE_CD = :inputUOMCharTy ");

            CharacteristicTypeLookup uomCharTypeLookup = uomCharType.getCharacteristicType();
            if(uomCharTypeLookup.isAdhocValue() || uomCharTypeLookup.isFileLocationValue()){
                // CCB v2.6 Upgrade - 2018-07-25 - Start Change
                //getAMRMeterDevice.append(" AND @trim(ICHAR.ADHOC_CHAR_VAL) = :regUOM) ");
                getAMRMeterDevice.append(" AND ICHAR.ADHOC_CHAR_VAL = :regUOM) ");
                // CCB v2.6 Upgrade - 2018-07-25 - End Change
            } if(uomCharTypeLookup.isPredefinedValue()){
                // CCB v2.6 Upgrade - 2018-07-25 - Start Change
                //getAMRMeterDevice.append(" AND @trim(ICHAR.CHAR_VAL) = :regUOM) ");
                getAMRMeterDevice.append(" AND ICHAR.CHAR_VAL = :regUOM) ");
                // CCB v2.6 Upgrade - 2018-07-25 - End Change
            } if(uomCharTypeLookup.isForeignKeyValue()){
                // CCB v2.6 Upgrade - 2018-07-25 - Start Change
                //getAMRMeterDevice.append(" AND @trim(ICHAR.CHAR_VAL_FK1) = :regUOM) ");
                getAMRMeterDevice.append(" AND ICHAR.CHAR_VAL_FK1 = :regUOM) ");
                // CCB v2.6 Upgrade - 2018-07-25 - End Change
            }

            if(notNull(touCharType) && notNull(register.getTimeOfUseId())) {
                getAMRMeterDevice.append("AND (ICHAR.CHAR_TYPE_CD = :inputTOUCharTy ");
                CharacteristicTypeLookup touCharTypeLookup = touCharType.getCharacteristicType();
                if(touCharTypeLookup.isAdhocValue() || touCharTypeLookup.isFileLocationValue()){
                    // CCB v2.6 Upgrade - 2018-07-25 - Start Change
                    //getAMRMeterDevice.append(" AND @trim(ICHAR.ADHOC_CHAR_VAL) = :regTOU) ");
                    getAMRMeterDevice.append(" AND ICHAR.ADHOC_CHAR_VAL = :regTOU) ");
                    // CCB v2.6 Upgrade - 2018-07-25 - End Change
                } if(touCharTypeLookup.isPredefinedValue()){
                    // CCB v2.6 Upgrade - 2018-07-25 - Start Change
                    //getAMRMeterDevice.append(" AND @trim(ICHAR.CHAR_VAL) = :regTOU) ");
                    getAMRMeterDevice.append(" AND ICHAR.CHAR_VAL = :regTOU) ");
                    // CCB v2.6 Upgrade - 2018-07-25 - End Change
                } if(touCharTypeLookup.isForeignKeyValue()){
                    // CCB v2.6 Upgrade - 2018-07-25 - Start Change
                    //getAMRMeterDevice.append(" AND @trim(ICHAR.CHAR_VAL_FK1) = :regTOU) ");
                    getAMRMeterDevice.append(" AND ICHAR.CHAR_VAL_FK1 = :regTOU) ");
                    // CCB v2.6 Upgrade - 2018-07-25 - End Change
                }
            }
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement pstmt =  createPreparedStatement(getAMRMeterDevice.toString());
            PreparedStatement pstmt =  createPreparedStatement(getAMRMeterDevice.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            pstmt.bindId("meterId", mrId.getEntity().getMeterConfiguration().getMeter().getId());
            pstmt.bindId("itemType", itemTypeAMRDevice.getId());
            pstmt.bindDate("processDt", getProcessDateTime().getDate());
            pstmt.bindId("inputUOMCharTy", uomCharType.getId());
            pstmt.bindStringProperty("regUOM",CharacteristicValue.properties.characteristicValue ,register.getUnitOfMeasure().getId().getTrimmedValue());
            if(notNull(touCharType) && notNull(register.getTimeOfUseId())) {
                pstmt.bindId("inputTOUCharTy",touCharType.getId());
                pstmt.bindStringProperty("regTOU",CharacteristicValue.properties.characteristicValue , register.getTimeOfUseId().getTrimmedValue());
            }
            BigInteger result = pstmt.firstRow().getInteger("COUNT");
            if(result.compareTo(BigInteger.ZERO) == 0 )
            {isAMR = Bool.FALSE;}
            pstmt.close();

            return isAMR;

        }

        private String getReadHistTransactionString(){
            MeterRead_Id rmvlMtrId= null;
            StringBuilder getReadHistTrans = new StringBuilder();
            getReadHistTrans.append("SELECT HIST.REMOVAL_MR_ID, EVT.SP_MTR_EVT_FLG,EVT.MTR_ON_OFF_FLG ");
            getReadHistTrans.append("FROM CI_SP_MTR_HIST HIST, CI_SP_MTR_EVT EVT, CI_MR MR ");
            getReadHistTrans.append("WHERE EVT.SP_MTR_HIST_ID = EVT.SP_MTR_HIST_ID ");
            getReadHistTrans.append("AND HIST.SP_ID = :currSpId ");
            getReadHistTrans.append("AND MR.MR_ID = :mreadId ");
            getReadHistTrans.append("AND EVT.MR_ID = MR.MR_ID ");
            getReadHistTrans.append("AND HIST.MTR_CONFIG_ID = MR.MTR_CONFIG_ID ");
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement pstmt =  createPreparedStatement(getReadHistTrans.toString());
            PreparedStatement pstmt =  createPreparedStatement(getReadHistTrans.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            pstmt.bindId("currSpId", spId);
            pstmt.bindId("mreadId", mrId);
            SQLResultRow result = pstmt.firstRow();
            if(notNull(result)){

                rmvlMtrId = (MeterRead_Id)result.getId("REMOVAL_MR_ID", MeterRead.class);
                ServicePointMeterEventTypeLookup spMtrEvtLookup = result.getLookup("SP_MTR_EVT_FLG", ServicePointMeterEventTypeLookup.class);
                MeterOnOffStatusLookup mtrOnOffLookup = result.getLookup("MTR_ON_OFF_FLG", MeterOnOffStatusLookup.class);

                if(isNull(rmvlMtrId)){
                    if(ServicePointMeterEventTypeLookup.constants.INSTALL.compareTo(spMtrEvtLookup) ==0 )
                        return INSTALL;
                    if(ServicePointMeterEventTypeLookup.constants.NORMAL.compareTo(spMtrEvtLookup) ==0 ){
                        if(MeterOnOffStatusLookup.constants.OFF.compareTo(mtrOnOffLookup) ==0)
                            return MTROFF;
                        if(MeterOnOffStatusLookup.constants.ON.compareTo(mtrOnOffLookup) ==0)
                            return MTRON;
                    }
                }else{
                    if(rmvlMtrId.compareTo(mrId)==0)
                        return MTRMVL;
                }
            }

            if(checkStartStop()){
                return STARTSTOP;
            }
            if(checkMeterRead(FieldActivityStepTypeActionLookup.constants.DISCONNECT_SERVICE_POINT)){
                return DISC;
            }
            if(checkMeterRead(FieldActivityStepTypeActionLookup.constants.TEST_DEVICE)){
                return TEST;
            }
            if(checkMeterRead(FieldActivityStepTypeActionLookup.constants.READ_METER)){
                return READMETER;
            }

            return null;	
        }

        private Boolean checkStartStop(){

            StringBuilder getReadHistTransStr = new StringBuilder();
            getReadHistTransStr.append(" SELECT 'X' ");
            getReadHistTransStr.append(" FROM CI_SA_SP SP, CI_SA_SP SP1 ");
            getReadHistTransStr.append(" WHERE SP.SP_ID=:spId ");
            getReadHistTransStr.append(" AND SP.SP_ID=SP1.SP_ID ");
            getReadHistTransStr.append(" AND SP.START_MR_ID=:mrId ");
            getReadHistTransStr.append(" AND SP.START_MR_ID=SP1.STOP_MR_ID ");
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement getReadHistTransPrepStmt = createPreparedStatement(getReadHistTransStr.toString());
            PreparedStatement getReadHistTransPrepStmt = createPreparedStatement(getReadHistTransStr.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            getReadHistTransPrepStmt.bindId("spId", spId);
            getReadHistTransPrepStmt.bindId("mrId", mrId);
            SQLResultRow getReadHistTransRow = getReadHistTransPrepStmt.firstRow();
            if(isNull(getReadHistTransRow)){
                return false;
            }else{
                return true;
            } 
        }

        private Boolean checkMeterRead(FieldActivityStepTypeActionLookup lookup){

            StringBuilder getReadHistTransStr = new StringBuilder();
            getReadHistTransStr.append(" SELECT FA.FA_ID ");
            getReadHistTransStr.append(" FROM CI_FA FA, CI_FA_STEP STEP ");
            getReadHistTransStr.append(" WHERE FA.SP_ID=:spId ");
            getReadHistTransStr.append(" AND FA.FA_STATUS_FLG <> :status ");
            getReadHistTransStr.append(" AND EXISTS (SELECT 'X' FROM CI_FA_STEP STEP WHERE STEP.FA_ID = FA.FA_ID AND STEP.FA_STEP_TY_ACT_FLG=:lookup) ");
            getReadHistTransStr.append(" AND EXISTS (SELECT 'X' FROM CI_FA_STEP STEP WHERE STEP.FA_ID = FA.FA_ID AND STEP.MR_ID=:mrId) ");
            //Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            //PreparedStatement getReadHistTransPrepStmt = createPreparedStatement(getReadHistTransStr.toString());
            PreparedStatement getReadHistTransPrepStmt = createPreparedStatement(getReadHistTransStr.toString(), getClass().getName());
            //End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
            getReadHistTransPrepStmt.bindId("spId", spId);
            getReadHistTransPrepStmt.bindId("mrId", mrId);
            getReadHistTransPrepStmt.bindLookup("lookup", lookup);
            getReadHistTransPrepStmt.bindLookup("status", FieldActivityStatusLookup.constants.CANCELED);
            SQLResultRow getReadHistTransRow = getReadHistTransPrepStmt.firstRow();
            if(isNull(getReadHistTransRow)){
                return false;
            }else{
                return true;
            }
        }

        private String padLeft(String string, int size){
            if (string == null) {
                if (size == 0) return "";
                return padLeftWithSpaces(string, size, size);
            }
            int padding = size - string.length();
            if (padding == 0) return string;
            if (padding < 0) return string.substring(0, size);
            return padLeftWithSpaces(string, size, padding);
        }

        private String padLeftWithSpaces(String string, int size, int padding){
            char SPACE = ' ';
            int paddingSize = 0;
            if (string == null )
                paddingSize = size;
            else
                paddingSize = padding;	

            StringBuilder builder = new StringBuilder(size);
            for (int i = 0; i < paddingSize; i++) {
                builder.append(SPACE);
            }
            if(notNull(string))
                builder.append(string);

            return builder.toString();
        }

        private String formatDate(DateTime readDttm){
            String str = "";
            str += readDttm.getYear();
            str+= StringUtilities.leftPadWithZeros(""+readDttm.getMonth(), 2);
            str+= StringUtilities.leftPadWithZeros(""+readDttm.getDay(), 2);
            return str;

        }

        /**
         * Open File Writer
         */
        private void openFileWriter(){	     
            inputFilePathAndName = new File(strFilePath, strNewFileName);
            try { 
                bufferedWriter = new BufferedWriter(new FileWriter(inputFilePathAndName));
            } catch (IOException e) {
                addError(CustomMessageRepository.ni0028_7ErrorInFileOpening(e.getMessage()));
            }
        }

        /**
         * Write Line to File
         */
        private void writeLine(String recordline){		

            try {
                bufferedWriter.write(recordline);
                bufferedWriter.newLine();
            } catch (IOException e) {
                addError(CustomMessageRepository.ni0028_7ErrorInFileWriting(e.getMessage()));
            }
        }

        /**
         * Close File Writer after all the records for this thread are processed.
         */
        public void finalizeThreadWork() throws ThreadAbortedException, RunAbortedException{

            try {
                bufferedWriter.close();
            } catch (IOException e) {
                addError(CustomMessageRepository.ni0028_7ErrorInFileWriting(e.getMessage()));
            }
        }

    }//Inner

}//Outer
