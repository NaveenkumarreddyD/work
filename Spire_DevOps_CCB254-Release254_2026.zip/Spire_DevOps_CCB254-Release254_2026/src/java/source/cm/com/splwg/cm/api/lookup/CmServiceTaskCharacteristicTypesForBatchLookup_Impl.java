/*
 **************************************************************************
 *                Confidentiality Information:
 *
 * This module is the confidential and proprietary information of
 * Oracle Corporation; it is not to be copied, reproduced, or
 * transmitted in any form, by any means, in whole or in part,
 * nor is it to be used for any purpose other than that for which
 * it is expressly provided without the written permission of
 * Oracle Corporation.
 *
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Service Task Characteristic Types for Batch
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     	Reason:
 * YYYY-MM-DD   IN      	Reason text.
 * 
 * 2019-01-08   JHERNA      Requested by Origin for 2.6  
 * *************************************************************************                
 */

package com.splwg.cm.api.lookup;

/**
 * @author JHERNA
 *
 @LookupFieldname (value = XSCH_OPT_TYP_FLG)
 */
public class CmServiceTaskCharacteristicTypesForBatchLookup_Impl 
		extends CmServiceTaskCharacteristicTypesForBatchLookup_Gen {}
