/*
 **************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 *                                                                
 * Column Delimited Record class for ACH File Header
 *                                            
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 * 2021-05-27   RDizon  CCB041. Initial version.        
 **************************************************************************
 */
package com.splwg.cm.api.batch;

import com.splwg.base.api.batch.ColumnDelimitedRecord;

/**
 * @author RDizon
 */
public class CmCheckExtractACHFileHeaderRecord extends ColumnDelimitedRecord {
    
      
    public CmCheckExtractACHFileHeaderRecord() {
        super(13);
    }

    public void setRecordType(String value) {
        this.rightPadColumn(1, 1, value);
    }

    public void setPriorityCode(String value) {
        this.rightPadColumn(2, 2, value);
    }

    public void setImmediateDestination(String value) {
        this.rightPadColumn(3, 10, value);
    }

    public void setImmediateOrigin(String value) {
        this.rightPadColumn(4, 10, value);
    }

    public void setFileCreationDate(String value) {
        this.rightPadColumn(5, 6, value);
    }

    public void setFileCreationTime(String value) {
        this.rightPadColumn(6, 4, value);
    }

    public void setFileIdModifier(String value) {
        this.rightPadColumn(7, 1, value);
    }

    public void setRecordSize(String value) {
        this.rightPadColumn(8, 3, value);
    }

    public void setBlockingFactor(String value) {
        this.rightPadColumn(9, 2, value);
    }

    public void setFormatCode(String value) {
        this.rightPadColumn(10, 1, value);
    }

    public void setImmediateDestinationName(String value) {
        this.rightPadColumn(11, 23, value);
    }

    public void setImmediateOriginName(String value) {
        this.rightPadColumn(12, 23, value);
    }

    public void setReferenceCode(String value) {
        this.rightPadColumn(13, 8, value);
    }
    
}
