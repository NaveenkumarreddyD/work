/*
 * *****************************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NI0019.5 - Payment Cancellation Algorithm
 *
 ******************************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:             Reason:
 * YYYY-MM-DD   IN              Reason text.
 *
 * 2013-02-20   Rakesh          NI0019.5. Initial Version.
 * 2013-05-04	Karthik			CR - KL20130504 - Create a new Customer Contact 
 * 								Characteristic to store Payment Event ID
 * 2014-08-29	JHERNA			MGE-CCB005 - Added the following functionalities:
 *                                  - Remove the customer from AutoPay after x NSF 
 *                                    payments in a period.
 *                                  - Add an Account Bill Message to notify the customer
 *                                    that they have been removed from AutoPay
 *                                  - Creates a new Customer Contact to log the Customer's
 *                                    removal from AutoPay. 
 *                              - Corrected the original code. The Customer Contact should
 *                                be created for the Payor Account's Main Person (and not
 *                                the Payee Account's Main Person)
 * 2015-03-23	JHERNA			DEFECT#3174912 - After upgrading to SP8 and SP18, autopay
 * 								cancellation is not working. Example: number of payments for 
 *                              autopay removal is set to 2, the actual autopay removal does
 *                              not took place until a 3rd payment tender is cancelled (before 
 *                              sp8 and sp18 upgrade this is not the case, the autopay is
 *                              cancelled at the 2nd payment tender cancellation due to NSF).
 *                              Update to this program is to fix this issue that was brought 
 *                              upon by upgrading to SP8 and SP18.    
 * 2016-01-25   MPang			Updated for CCB v2.4 compilation.    
 * 2021-07-13   Kiran           Send an email(PMOC) when we remove from AP   
 * 2021-12-28   RDizon          D-02923. When an Account is in Autopay, only the NSF Letter
 *                              for Autopay Removal must be created.      
 * 2024-05-06   Kiran           Create a CC for each payment cancellation                                                          
 ******************************************************************************************/
package com.splwg.cm.domain.admin.customerClass;

import java.math.BigInteger;

import com.splwg.base.api.businessObject.COTSInstanceNode;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.serviceScript.ServiceScriptDispatcher;
import com.splwg.base.api.serviceScript.ServiceScriptInstance;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.algorithmType.AlgorithmType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.BillMessageTypeLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.TenderStatusLookup;
//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.billMessage.BillMessageType;
import com.splwg.ccb.domain.admin.customerClass.CustomerClassPaymentCancellationAlgorithmSpot;
import com.splwg.ccb.domain.admin.customerContactClass.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.paymentCancelReason.PaymentCancelReason;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.AccountAutopay;
import com.splwg.ccb.domain.customerinfo.account.AccountAutopay_DTO;
import com.splwg.ccb.domain.customerinfo.account.AccountAutopay_Id;
import com.splwg.ccb.domain.customerinfo.account.AccountMessage_DTO;
import com.splwg.ccb.domain.customerinfo.account.AccountMessage_Id;
import com.splwg.ccb.domain.customerinfo.account.AccountMessages;
import com.splwg.ccb.domain.customerinfo.account.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.Person;
import com.splwg.ccb.domain.customerinfo.person.Person_Id;
import com.splwg.ccb.domain.payment.payment.Payment;*/
import com.splwg.ccb.domain.admin.billMessage.entity.BillMessageType;
import com.splwg.ccb.domain.admin.customerClass.algorithm.payCancel.CustomerClassPaymentCancellationAlgorithmSpot;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.admin.paymentCancelReason.entity.PaymentCancelReason;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountAutopay;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountAutopay_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountAutopay_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountMessage_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountMessage_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountMessages;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.payment.payment.entity.Payment;
//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.shared.common.ApplicationError;

/**
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = customerContactClass, name = customerContactClass, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = customerContactType, required = true, type = string)
 *            , @AlgorithmSoftParameter (name = nfsOnly, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = customerContactPayEvtCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = nbrOfNSFPaymentsForAutoPayRemoval, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = nbrOfDaysInAutoPayNSFPaymentPeriod, required = true, type = integer)
 *            , @AlgorithmSoftParameter (entityName = customerContactClass, name = customerContactClassForAutoPayRemoval, type = entity)
 *            , @AlgorithmSoftParameter (name = customerContactTypeforAutoPayRemoval, type = string)
 *            , @AlgorithmSoftParameter (entityName = billMessageType, name = billMessageUsedForAutoPayRemoval, type = entity)
 *            , @AlgorithmSoftParameter (entityName = customerContactClass, name = customerContactClassAPRemWarn, type = entity)
 *            , @AlgorithmSoftParameter (name = customerContactTypeAPRemWarn, type = string)})
 */
public class CmPaymentCancellationAlgComp_Impl 
		extends CmPaymentCancellationAlgComp_Gen 
		implements CustomerClassPaymentCancellationAlgorithmSpot {

	private CustomerContactClass parmCustomerContactClass = null;
	private String parmCustomerContactTypeStr = null;
	private Bool parmNFSOnly = null;
	private CharacteristicType parmPayEventCharType = null;
	// START ADD - JHERNA - 2014-08-29 - MGE-CCB005
	private BigInteger parmNbrOfNSFPaymentsForApayRemoval;
	private BigInteger parmNbrOfDaysInApayNSFPaymentPeriod;
	private CustomerContactClass parmCustomerContactClassForApayRemoval;
	private String parmCcTypeForApayRemoval;
	private BillMessageType parmBillMessageUsedForApayRemoval;
	private CustomerContactType ccTypeForApayRemoval;
	// END ADD - JHERNA - 2014-08-29 - MGE-CCB005
	private PaymentCancelReason payCancelReason = null;
	private Payment currentPayment = null;
	@SuppressWarnings("unused")
	private Money paymentAmount = Money.ZERO;
	@SuppressWarnings("unused")
	private Account account = null;
	private CustomerContactType_Id custContactType_Id =null;
	// START ADD - Kiran Machavarapu - 2024-05-06
	private CustomerContactClass parmCustomerContactClassAPRemWarn = null;
	private String parmCustomerContactTypeStrAPRemWarn = null;
	private CustomerContactType ccTypeForApayRemovalWarn;
	// END ADD - Kiran Machavarapu - 2024-05-06
	
// Kiran 07/13/2021 Begin PMOC
	private String emailAddressPMOC = "";
	private String smsNumPMOC = "";
	private static final String CM_SAPNOTIF="CM-SAPNotif";
	private static final String CM_PMOCINFO="CM-PmocInfo";
	private static final String EVENT_DISCONNECT="OUTD";
	private static final String EVENT_CANCELLATION="OUTN";
	private static final String EVENT_RECONNECT="OUTR";
	private static final String COMM_TYPE = "O";
	private static final String PMOC_GROUP_INPUT = "input";
	private static final String PMOC_GROUP_OUTPUT = "output";
	private static final String PMOC_ACCOUNT_ID = "accountId";
	private static final String SAPNOTIF_OUTBOUND_MSG_ID = "outboundMessageId";
// kiran 07/13/2021 End PMOC
	
	// Start Add - RDizon - D-02923 - 12-28-2021
    Bool apayCcCreated = Bool.FALSE;
    // End Add - RDizon - D-02923 - 12-28-2021
	
	protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
		// START ADD - Kiran Machavarapu - 2024-05-06
		parmCustomerContactClassAPRemWarn = this.getCustomerContactClassAPRemWarn();
		parmCustomerContactTypeStrAPRemWarn = this.getCustomerContactTypeAPRemWarn();
        String parm100Desc = cmRetrieveParmDesc(this.getAlgorithm().getAlgorithmType().getId(), BigInteger.valueOf(100));
        String parm110Desc = cmRetrieveParmDesc(this.getAlgorithm().getAlgorithmType().getId(), BigInteger.valueOf(110));
        cmValidateCustomerContactClassAndTypeWarn(parmCustomerContactClassAPRemWarn, parm100Desc, parmCustomerContactTypeStrAPRemWarn, parm110Desc);
     // END ADD - Kiran Machavarapu - 2024-05-06
		
		parmCustomerContactClass = getCustomerContactClass();
		parmCustomerContactTypeStr = getCustomerContactType();
		parmNFSOnly = getNfsOnly();
		custContactType_Id = new CustomerContactType_Id(parmCustomerContactClass,parmCustomerContactTypeStr);
		if (isNull(custContactType_Id.getEntity())){
			addError(CustomMessageRepository.ni0019_5InvalidCustContactType(parmCustomerContactClass.getId().getIdValue().trim(),parmCustomerContactTypeStr));
		}
		parmPayEventCharType = getCustomerContactPayEvtCharType();
        CharacteristicEntity_Id characteristicEntityId = new CharacteristicEntity_Id(parmPayEventCharType, CharacteristicEntityLookup.constants.CUSTOMER_CONTACT);
        if (isNull(characteristicEntityId.getEntity())){
            addError(CustomMessageRepository.nm0019_5CharTypeInvalidForCharEntity(parmPayEventCharType.getId().getIdValue(), CharacteristicEntityLookup.constants.CUSTOMER_CONTACT.getConstantName()));
        } 
        
    	// START ADD - JHERNA - 2014-08-29 - MGE-CCB005
        // Retrieve Parameter 50: Number of NSF Payments for Autopay Removal
        parmNbrOfNSFPaymentsForApayRemoval = this.getNbrOfNSFPaymentsForAutoPayRemoval();
        // Validate that parameter is greater than zero
        String parm50Desc = cmRetrieveParmDesc(this.getAlgorithm().getAlgorithmType().getId(), BigInteger.valueOf(50));
        cmValidateNbrIsGreaterThanZero(parmNbrOfNSFPaymentsForApayRemoval, parm50Desc);
        // Retrieve Parameter 60: Number of Days in Autopay NSF Payment Period
        parmNbrOfDaysInApayNSFPaymentPeriod = this.getNbrOfDaysInAutoPayNSFPaymentPeriod();
        // Validate that parameter is greater than zero
        String parm60Desc = cmRetrieveParmDesc(this.getAlgorithm().getAlgorithmType().getId(), BigInteger.valueOf(60));
        cmValidateNbrIsGreaterThanZero(parmNbrOfDaysInApayNSFPaymentPeriod, parm60Desc);
        // Retrieve Parameter 70: Customer Contact Class For Autopay Removal
        parmCustomerContactClassForApayRemoval = this.getCustomerContactClassForAutoPayRemoval();
        // Retrieve Parameter 80: Customer Contact Type for Autopay Removal
        parmCcTypeForApayRemoval = this.getCustomerContactTypeforAutoPayRemoval();
        // Validate that the Customer Contact Class and Customer Contact Type are valid for each other (if populated)
        String parm70Desc = cmRetrieveParmDesc(this.getAlgorithm().getAlgorithmType().getId(), BigInteger.valueOf(70));
        String parm80Desc = cmRetrieveParmDesc(this.getAlgorithm().getAlgorithmType().getId(), BigInteger.valueOf(80));
        cmValidateCustomerContactClassAndType(parmCustomerContactClassForApayRemoval, parm70Desc, parmCcTypeForApayRemoval, parm80Desc);
        // Retrieve Parameter 90: Bill Message used for Autopay removal
        parmBillMessageUsedForApayRemoval = this.getBillMessageUsedForAutoPayRemoval();        
    	// END ADD - JHERNA - 2014-08-29 - MGE-CCB005
	}
	// START ADD - JHERNA - 2014-08-29 - MGE-CCB005
	/**
	 * Custom Method which validates if the number specified is greater than zero. If not, then an error would be raised 
	 * and processing will be terminated
	 * @param number the number to be validated
	 * @param parmDesc the parameter description
	 */
	private void cmValidateNbrIsGreaterThanZero(BigInteger number, String parmDesc) {
		
		if (number.compareTo(BigInteger.ZERO) <= 0) {
			// Algorithm %1's parameter '%2%3' value (%4) must be greater than zero
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterMustBeGreaterThanZero(
					this.getAlgorithm().getId().getTrimmedValue(),
					parmDesc.trim(), number.toString().trim()));
		}
	}
	/**
	 * Custom Method which retrieves the algorithm parameter description
	 * @param algTypeId The Algorithm Type
	 * @param parmSeq the Parameter's sequence
	 * @return returnValue the Parameter's Description
	 */
	private String cmRetrieveParmDesc(AlgorithmType_Id algTypeId, BigInteger parmSeq) {
		
		String returnValue = " ";
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT ALG_PARM_LBL ");
		stringBuilder.append("FROM CI_ALG_TYPE_PRM_L ");
		stringBuilder.append("WHERE ALG_TYPE_CD = :algTypeId ");
		stringBuilder.append("AND SEQNO = :parmSeq ");
		stringBuilder.append("AND LANGUAGE_CD = :language ");
		//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
		// PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
		prepState.bindId("algTypeId", algTypeId);
		prepState.bindBigInteger("parmSeq", parmSeq);
		prepState.bindId("language", this.getActiveContextLanguage().getId());
		prepState.execute();
		if (prepState.list().size() > 0) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			returnValue = (String) sqlRow.get("ALG_PARM_LBL");
		}
		prepState.close();		
		return returnValue;
	}
	/**
	 * Custom Method which validates that the customer contact class and type are valid 
	 * for each other if they are populated.
	 * @param ccClass The Customer Contact Class
	 * @param parmDesc1 the parameter description for customer contact class
	 * @param ccType The Customer Contact Type
	 * @param parmDesc2 the parameter description for customer contact type
	 */
	private void cmValidateCustomerContactClassAndType(CustomerContactClass ccClass, 
			String parmDesc1, String ccType, String parmDesc2) {
		
		if (notNull(ccClass)
				&& isBlankOrNull(ccType)) {
			// Algorithm %1's parameter '%2%3' is required when parameter '%3%4' is supplied.
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterRequiredWhenSpecifiedParmIsSupplied(
					this.getAlgorithm().getId().getTrimmedValue(),
					parmDesc2.trim(), parmDesc1.trim()));
		}		
		if (isNull(ccClass)
				&& notBlank(ccType)) {
			// Algorithm %1's parameter '%2%3' is required when parameter '%3%4' is supplied.
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterRequiredWhenSpecifiedParmIsSupplied(
					this.getAlgorithm().getId().getTrimmedValue(),
					parmDesc1.trim(), parmDesc2.trim()));
		}		
		if (notNull(ccClass)
				&& notBlank(ccType)) {
		
			CustomerContactType_Id ccTypeId = new CustomerContactType_Id(ccClass, ccType.trim());
			if (isNull(ccTypeId.getEntity())) {
				// Algorithm %1 parameter '%2%3' is an invalid Contact Type (%4) for Contact Class (%5)
				addError(CustomMessageRepositoryMGE.commAlgorithmParameterContactTypeInvalidForContactClass(
						this.getAlgorithm().getId().getTrimmedValue(),
						parmDesc2.trim(), ccType.trim(), ccClass.getId().getTrimmedValue()));
			}
			ccTypeForApayRemoval = ccTypeId.getEntity();
		}		
	}
	// END ADD - JHERNA - 2014-08-29 - MGE-CCB005
	
	// START ADD - Kiran Machavarapu - 2024-05-06
	private void cmValidateCustomerContactClassAndTypeWarn(CustomerContactClass ccClass, 
			String parmDesc1, String ccType, String parmDesc2) {
		
		if (notNull(ccClass)
				&& isBlankOrNull(ccType)) {
			// Algorithm %1's parameter '%2%3' is required when parameter '%3%4' is supplied.
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterRequiredWhenSpecifiedParmIsSupplied(
					this.getAlgorithm().getId().getTrimmedValue(),
					parmDesc2.trim(), parmDesc1.trim()));
		}		
		if (isNull(ccClass)
				&& notBlank(ccType)) {
			// Algorithm %1's parameter '%2%3' is required when parameter '%3%4' is supplied.
			addError(CustomMessageRepositoryMGE.commAlgorithmParameterRequiredWhenSpecifiedParmIsSupplied(
					this.getAlgorithm().getId().getTrimmedValue(),
					parmDesc1.trim(), parmDesc2.trim()));
		}		
		if (notNull(ccClass)
				&& notBlank(ccType)) {
		
			CustomerContactType_Id ccTypeId = new CustomerContactType_Id(ccClass, ccType.trim());
			if (isNull(ccTypeId.getEntity())) {
				// Algorithm %1 parameter '%2%3' is an invalid Contact Type (%4) for Contact Class (%5)
				addError(CustomMessageRepositoryMGE.commAlgorithmParameterContactTypeInvalidForContactClass(
						this.getAlgorithm().getId().getTrimmedValue(),
						parmDesc2.trim(), ccType.trim(), ccClass.getId().getTrimmedValue()));
			}
			ccTypeForApayRemovalWarn = ccTypeId.getEntity();
		}		
	}
	// END ADD - Kiran Machavarapu - 2024-05-06
	public void setAccount(Account arg0) {
		this.account = arg0;

	}

	public void setPayment(Payment arg0) {
		this.currentPayment = arg0;
	}

	public void setPaymentAmount(Money arg0) {
		this.paymentAmount = arg0;
	}

	public void setPaymentCancelReason(PaymentCancelReason arg0) {
		this.payCancelReason = arg0;

	}
	
	public void invoke() {
		if(payCancelReason.getIsNsfCharge().isFalse() && parmNFSOnly.isTrue()){
			return;
		}

		// START CHANGES - JHERNA - 2014-08-29 - MGE-CCB005
		/* 
		 * According to conversations with Lynette M., the Main Person of the
		 * Payor Account should be the one that this customization creates 
		 * a customer contact for and not the Payee Account's Main Person
		 */  
		/*
		for (AccountPerson person : account.getPersons()) {
			if(person.getIsMainCustomer().isTrue()){
				createCustomerContactWithChar(person.fetchIdPerson());
			}
		}
		*/
		// Retrieve the Payor Account
		Account payorAcct = cmRetrievePayorAccount(currentPayment);
		// Create (NSF) Customer Contact on the Payor Account's Main Person
		// Start Delete - RDizon - D-02923 - 12-28-2021
		// cmCreateCustomerContact(custContactType_Id.getEntity(), payorAcct);		
		// End Delete - RDizon - D-02923 - 12-28-2021
		// END CHANGES - JHERNA - 2014-08-29 - MGE-CCB005		
		
		// START ADD - JHERNA - 2014-08-29 - MGE-CCB005
		// Further processing for NSF Payment Cancellation
		if (payCancelReason.getIsNsfCharge().isTrue()) {
			// Check if account is currently on an active Autopay
			AccountAutopay acctApay = cmCheckIfAccountHasActiveApay(payorAcct);
			// Processing if the account has an effective autopay
			if (notNull(acctApay)) {
				// Further processing if Account is on Autopay
				cmFurtherProcessingForAccountOnAutopay(acctApay);
			}
		}
		// END ADD - JHERNA - 2014-08-29 - MGE-CCB005
		
		// Start Add - RDizon - D-02923 - 12-28-2021
		if (apayCcCreated.isFalse()){
		    cmCreateCustomerContact(custContactType_Id.getEntity(), payorAcct);
		}
		// End Add - RDizon - D-02923 - 12-28-2021
	}
	
	// START DELETE - JHERNA - 2014-08-29 - MGE-CCB005
	// Deleted because this is now an Unused method
	/*
	private void createCustomerContactWithChar(Person person) {
		CustomerContact_DTO contactDto = (CustomerContact_DTO) createDTO(CustomerContact.class);
		contactDto.setCustomerContactTypeId(custContactType_Id);
		contactDto.setPersonId(person.getId());
		contactDto.setContactDateTime(getProcessDateTime());
		CustomerContact custContact = contactDto.newEntity();

        CustomerContactCharacteristics ccCharacteristics =  custContact.getCharacteristics();

        // Start TIR3_NI0019.5 - KL20130504 - Create a new Customer Contact Characteristic to store Payment Event ID
        CustomerContactCharacteristic_DTO custContactCharacteristicDTO = ccCharacteristics.newChildDTO();
        CustomerContactCharacteristic_Id ccPayEvtCharId = new CustomerContactCharacteristic_Id(parmPayEventCharType, custContact);
        custContactCharacteristicDTO.setId(ccPayEvtCharId);
        CharacteristicTypeLookup ccPayEvtCharTypeLookup = parmPayEventCharType.getCharacteristicType();

        if(ccPayEvtCharTypeLookup.isAdhocValue() || ccPayEvtCharTypeLookup.isFileLocationValue()){
            custContactCharacteristicDTO.setAdhocCharacteristicValue(currentPayment.getPaymentEvent().getId().getTrimmedValue());
        } else if (ccPayEvtCharTypeLookup.isPredefinedValue()){
            custContactCharacteristicDTO.setCharacteristicValue(currentPayment.getPaymentEvent().getId().getTrimmedValue());
        } else if (ccPayEvtCharTypeLookup.isForeignKeyValue()){
            custContactCharacteristicDTO.setCharacteristicValueForeignKey1(currentPayment.getPaymentEvent().getId().getTrimmedValue());
        }        
        custContactCharacteristicDTO.newEntity();
        // End TIR3_NI0019.5
	}
	*/
	// END DELETE - JHERNA - 2014-08-29 - MGE-CCB005
	// START ADD - JHERNA - 2014-08-29 - MGE-CCB005
	/**
	 * Custom Method which checks if the account has an active autopay
	 * @param acct account to check
	 * @return The effective AccountAutopay
	 */
	private AccountAutopay cmCheckIfAccountHasActiveApay(Account acct) {
		AccountAutopay returnValue = null;		
		if (notNull(acct)) {
			StringBuilder stringBuilder = new StringBuilder();						
			stringBuilder.append("SELECT ACCT_APAY_ID "); 
			stringBuilder.append("FROM CI_ACCT_APAY ");
			stringBuilder.append("WHERE ACCT_ID = :acctId ");
			stringBuilder.append("AND START_DT <= :procDt ");
			stringBuilder.append("AND (END_DT IS NULL OR END_DT >= :procDt) ");
			stringBuilder.append("ORDER BY START_DT DESC ");
			//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
			// PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
			//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
			prepState.bindId("acctId", acct.getId());
			prepState.bindDate("procDt", this.getProcessDateTime().getDate());
			prepState.execute();
			if (prepState.list().size() > 0) {
				SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
				String acctApayStr = (String) sqlRow.get("ACCT_APAY_ID");
				AccountAutopay_Id acctApayId = new AccountAutopay_Id(acctApayStr.trim());
				returnValue = acctApayId.getEntity();
			}
			prepState.close();			
		}
		return returnValue;
	}
	/**
	 * Custom method which contains the additional processing (for autopay removal)
	 * @param acctApay the Payor account's autopay
	 */
	private void cmFurtherProcessingForAccountOnAutopay(AccountAutopay acctApay) {
		
		// Set the range (Start)
		// subtrahend = parameter 60 X (-1)
		int subtrahend = parmNbrOfDaysInApayNSFPaymentPeriod.multiply(BigInteger.valueOf(-1)).intValue(); 		
		Date startDate = this.getProcessDateTime().getDate().addDays(subtrahend);
		// Set the range (End)
		Date endDate = this.getProcessDateTime().getDate();
		// Retrieve the number of canceled payment tenders for the account in this period 
		// where the cancel reason used is configured as an NSF  cancelation reason 
		StringBuilder stringBuilder = new StringBuilder();				
		stringBuilder.append("SELECT PTNDR.PAY_TENDER_ID ");
		stringBuilder.append("FROM CI_PAY_TNDR PTNDR, CI_PAY_EVENT PEVT, CI_PAY_CAN_RSN CANRSN ");
		stringBuilder.append("WHERE PTNDR.PAYOR_ACCT_ID = :acctId ");
		stringBuilder.append("AND PTNDR.TNDR_STATUS_FLG = :tenderStatus ");
		stringBuilder.append("AND CANRSN.CAN_RSN_CD = PTNDR.CAN_RSN_CD ");
		stringBuilder.append("AND CANRSN.NSF_CHARGE_SW = :nsfChargeSw ");
		stringBuilder.append("AND PEVT.PAY_EVENT_ID = PTNDR.PAY_EVENT_ID ");
		stringBuilder.append("AND PEVT.PAY_DT BETWEEN :startDate AND :endDate ");
		//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
		// PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
		prepState.bindId("acctId", acctApay.getAccount().getId());
		prepState.bindLookup("tenderStatus", TenderStatusLookup.constants.CANCELED);
		prepState.bindBoolean("nsfChargeSw", Bool.TRUE);
		prepState.bindDate("startDate", startDate);
		prepState.bindDate("endDate", endDate);
		prepState.execute();		
		
		BigInteger nbrOfCancelledPayTndrs = BigInteger.valueOf(prepState.list().size());		
		
		// START ADD - JHERNA -2013-03-23 - DEFECT#3174912
		// Add 1 to the number of cancelled payment tenders to include the current payment tender being cancelled by NSF on the computation
		nbrOfCancelledPayTndrs = nbrOfCancelledPayTndrs.add(BigInteger.ONE);
		// END ADD - JHERNA -2013-03-23 - DEFECT#3174912
		
		// Processing in the eventat that the number of cancelled Pay Tenders  >= Parameter 50: Number of NSF Payments for Autopay Removal
		if (nbrOfCancelledPayTndrs.compareTo(parmNbrOfNSFPaymentsForApayRemoval) >= 0) {
			// Remove the Payor Account from autopay
			cmRemoveAutopay(acctApay);
			// Create Customer Contact for the Payor Account's Main Person 
			// (If parameters 70: Customer Contact Class for autopay removal & 80: Customer Contact Type
			// for Autopay Removal are both populated)
			cmCreateCustomerContact(ccTypeForApayRemoval, acctApay.getAccount());
			// Add a temporary Bill Message to the Payor account if parameter 90: Bill Message is provided
            
			cmAddBillMessage(acctApay.getAccount());
			
			// Send E-mail Kiran 
			
			//Get the Preferred Contact Method of the Account
			retrievePMOC(CM_PMOCINFO, acctApay.getAccount().getId());

			//Create Outbound Message

			//check if the PMOC Email Address has value
			if(notBlank(emailAddressPMOC)){
				
				ServiceScriptInstance serviceScriptInstance = null;
				serviceScriptInstance = ServiceScriptInstance.create(CM_SAPNOTIF);

				serviceScriptInstance.set("account", acctApay.getAccount().getId().getTrimmedValue());
				serviceScriptInstance.set("event", "RETURN_PAY_REM_AP");
				serviceScriptInstance.set("communicationType", "E");

				
				serviceScriptInstance.set("emailDestination", emailAddressPMOC);	
				serviceScriptInstance.set("emailParameter4", acctApay.getAccount().fetchDivision().getId().getTrimmedValue());
				
				try{
					ServiceScriptDispatcher.invoke(serviceScriptInstance);	
				} catch (ApplicationError e){
					e.getServerMessage();
				}

			}


			
		}
		else
		{
			cmCreateCustomerContact(ccTypeForApayRemovalWarn, acctApay.getAccount());
		}
		prepState.close();
	}	
	/**
	 * Custom method which removes the Autopay of an account
	 * @param acctApay the Account Autopay to end today
	 */
	private void cmRemoveAutopay(AccountAutopay acctApay) {
		AccountAutopay_DTO acctApayDTO = acctApay.getDTO();
		acctApayDTO.setEndDate(this.getProcessDateTime().getDate());
		acctApay.setDTO(acctApayDTO);		
	}
	/**
	 * Custom method which adds a temporary bill message to the account
	 * @param acct the Account to add a temporary bill message into
	 */
	private void cmAddBillMessage(Account acct) {		
		// Only attempt to create bill message if Algorithm Parameter 90: Bill Message Used for Autopay Removal is populated
		if (notNull(parmBillMessageUsedForApayRemoval)) {
			// Only proceed with creating a temporary bill message if this type of bill message does not 
			// exists yet on the Account.
			AccountMessage_Id acctMessageID = new AccountMessage_Id(parmBillMessageUsedForApayRemoval, acct );
			if (isNull(acctMessageID.getEntity())) {
				AccountMessages acctMessages = acct.getMessages();
				AccountMessage_DTO acctMessageDTO = acctMessages.newChildDTO();
				acctMessageDTO.setBillMessageType(BillMessageTypeLookup.constants.TEMPORARY);
				acctMessages.add(acctMessageDTO, parmBillMessageUsedForApayRemoval.getId());
			}			
		}		
	}
	/**
	 * Custom Method which creates a Customer Contact on an account's main person
	 * @param customerContacType the customer contact type to be created
	 * @param acct the account where in the customer contact would be created into its main person
	 */
	private void cmCreateCustomerContact(CustomerContactType customerContacType, Account acct) {

		if (notNull(customerContacType)) {
			
			// Retrieve Main Person where the customer contact would be created for
			Person mainPerson = cmRetrieveMainPerson(acct);
			
			CustomerContact_DTO contactDto = new CustomerContact_DTO();
			contactDto.setCustomerContactTypeId(customerContacType.getId());
			contactDto.setPersonId(mainPerson.getId());
			contactDto.setContactDateTime(getProcessDateTime());
			CustomerContact newCC = contactDto.newEntity();
			
	         // Start Add - RDizon - D-02923 - 12-28-2021
            apayCcCreated = Bool.TRUE;
            // End Add - RDizon - D-02923 - 12-28-2021
			
			// Create Characteristics
			cmCreateCustomerContactCharacteristics(newCC, parmPayEventCharType, currentPayment.getPaymentEvent().getId().getTrimmedValue());
		}		
	}
	/**
	 * Custom Method which creates a characteristic on the customer contact
	 * @param cc the customer contact to create the characteristics into
	 * @param charType
	 * @param charVal
	 */
	private void cmCreateCustomerContactCharacteristics(CustomerContact cc, CharacteristicType charType, String charVal) {
		
		if (notBlank(charVal)) {
			
			CustomerContactCharacteristic_DTO ccCharDTO = cc.getCharacteristics().newChildDTO();			
			if (charType.getCharacteristicType().isAdhocValue()
					|| charType.getCharacteristicType().isFileLocationValue()) {
				
				ccCharDTO.setAdhocCharacteristicValue(charVal.trim());
			}
			else if (charType.getCharacteristicType().isForeignKeyValue()) {
				
				ccCharDTO.setCharacteristicValueForeignKey1(charVal.trim());
			}
			else {
				
				ccCharDTO.setCharacteristicValue(charVal.trim());
			}	
			cc.getCharacteristics().add(ccCharDTO, charType.getId());
		}
	}
	/**
	 * Custom Method which retrieves the Account's Main Person
	 * @param acct the account to search
	 * @return returnValue the Account's Main Person
	 */
	private Person cmRetrieveMainPerson(Account acct) {

		Person returnValue = null;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT APER.PER_ID ");
		stringBuilder.append("FROM CI_ACCT_PER APER ");
		stringBuilder.append("WHERE APER.ACCT_ID = :acctID ");
		stringBuilder.append("AND APER.MAIN_CUST_SW = :mainCustSw ");
		//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
		// PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
		prepState.bindId("acctID", acct.getId());
		prepState.bindBoolean("mainCustSw", Bool.TRUE);
		prepState.execute();
		
		if (prepState.list().size() > 0) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			Person_Id perId = (Person_Id) sqlRow.getId("PER_ID", Person.class);
			returnValue = perId.getEntity();
		}		
		return returnValue; 
	}	
	/**
	 * Custom Method which retrieves the Payor Account from the Payment Tender of the Payment.
	 * Note that, Business Guarantees that there can only be one Payor Account per Payment Event.
	 * @param payment the Payment
	 * @return the Payor Account
	 */
	private Account cmRetrievePayorAccount(Payment payment) {
		
		Account returnValue = null;
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT PT.PAYOR_ACCT_ID ");
		stringBuilder.append("FROM CI_PAY PAY, CI_PAY_TNDR PT ");
		stringBuilder.append("WHERE PAY.PAY_ID = :paymentID ");
		stringBuilder.append("AND PT.PAY_EVENT_ID = PAY.PAY_EVENT_ID ");
		//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
		// PreparedStatement prepState = createPreparedStatement(stringBuilder.toString());
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), getClass().getName());
		//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
		prepState.bindId("paymentID", payment.getId());
		prepState.execute();
		
		if (prepState.list().size() > 0) {
			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			Account_Id acctID = (Account_Id) sqlRow.getId("PAYOR_ACCT_ID", Account.class);
			returnValue = acctID.getEntity();
		}
		prepState.close();
		return returnValue;		
	}
	

	/**
	 * This method will retrieve the PMOC email and sms of the account 
	 * using a specific service
	 * @param service
	 * @param accountId
	 */
	private void retrievePMOC(String service, Account_Id accountId){
		ServiceScriptInstance serviceScriptInstance = null;
		COTSInstanceNode scriptInput = null;
		COTSInstanceNode scriptOutput = null;
		
		emailAddressPMOC = "";
		smsNumPMOC = "";
	
		// Create an instance of the service script
		serviceScriptInstance = ServiceScriptInstance.create(service);
		
		// Retrieve the script's input node
		scriptInput = serviceScriptInstance.getGroup(PMOC_GROUP_INPUT);
		
		// Account Id
		scriptInput.set(PMOC_ACCOUNT_ID, accountId.getTrimmedValue());
		
		// Invoke the service script
		try {
			ServiceScriptDispatcher.invoke(serviceScriptInstance);
			scriptOutput = serviceScriptInstance.getGroup(PMOC_GROUP_OUTPUT);
			if (scriptOutput.getGroup("errorInformation").getBoolean("isInError").isFalse()){
				if (!isBlankOrNull(scriptOutput.getGroup("pmoc").getString("emailAddress"))){						
					emailAddressPMOC = scriptOutput.getGroup("pmoc").getString("emailAddress");
				}

				if (!isBlankOrNull(scriptOutput.getGroup("pmoc").getString("smsPhone"))){					
					smsNumPMOC = scriptOutput.getGroup("pmoc").getString("smsPhone");							
				}
			}
		} catch (ApplicationError ae){
			ae.getServerMessage();
		}
	}
	
	

	
	// END ADD - JHERNA - 2014-08-29 - MGE-CCB005
}
