/* ************************************************************************
 *                Confidentiality Information:
 *
 * This module is the confidential and proprietary information of
 * Oracle Corporation; it is not to be copied, reproduced, or
 * transmitted in any form, by any means, in whole or in part,
 * nor is it to be used for any purpose other than that for which
 * it is expressly provided without the written permission of
 * Oracle Corporation.
 *
 *
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 * 
 *  Data Correction - Meter Pressure
 *
 * This batch process will process Maximo data corrections for Meter 
 * Pressure Char and Meter Pressure UOM Char.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:        Reason:
 * YYYY-MM-DD   IN         Reason text.
 *
 * 2015-04-16   RKing      Initial Version.
 * 2016-01-29  	MPang	   Updated for CCB v2.4 compilation. 
 ***************************************************************************/
package com.splwg.cm.domain.batch;

import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.meterread.meter.Meter;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristic_DTO;
import com.splwg.ccb.domain.meterread.meter.MeterCharacteristics;
import com.splwg.ccb.domain.meterread.meter.Meter_Id;*/

import com.splwg.ccb.domain.meterread.meter.entity.Meter;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristic_DTO;
import com.splwg.ccb.domain.meterread.meter.entity.MeterCharacteristics;
import com.splwg.ccb.domain.meterread.meter.entity.Meter_Id;
//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.meter.meter.CmMeterDataLog;
import com.splwg.cm.domain.meter.meter.CmMeterDataLog_DTO;

/**
 * @author 90724
 *
 @BatchJob (multiThreaded = true, rerunnable = false, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = maximoErrorDescription, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = meterPressureCharType, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = meterPressureUOMCharType, required = true, type = entity)
 *            })
 */
public class CmMaximoDataCorrectionMeterPressureBatch
    	extends CmMaximoDataCorrectionMeterPressureBatch_Gen {
	
	// Parameter descriptions.
	private static final String MTR_PRESSURE = "Meter Pressure Char Type";
	private static final String MTR_PRESSURE_UOM = "Meter Pressure UOM Char Type";
	     
    public JobWork getJobWork() {
    	
    	// Setup bind variables.
    	String errorDescr = " '" + getParameters().getMaximoErrorDescription().trim() + "' ";
	
		StringBuilder mainQuery =  new StringBuilder();
		mainQuery.append(" SELECT ");
		mainQuery.append("    ER.MTR_ID ");
		mainQuery.append("   ,ER.MAXIMO_VALUE ");
		mainQuery.append("   ,ER.CCB_VALUE ");
		mainQuery.append("   ,CR.CORRECTED_PRESSURE ");
		mainQuery.append("   ,CR.CORRECTED_PRESS_UOM ");
		mainQuery.append(" FROM ");
		mainQuery.append("    CM_VALIDATE.CM_VALIDATION_ERROR_METER ER ");
		mainQuery.append("    ,CISADM.CM_MAXIMO_DATA_CORR_CROSS_REF CR ");
		mainQuery.append(" WHERE ");
		mainQuery.append("    ER.DESCRIPTION = ");
		mainQuery.append(errorDescr);
		mainQuery.append("   AND ER.CCB_VALUE = CR.CCB_VALUE ");
		mainQuery.append("   AND ER.MAXIMO_VALUE = CR.MAXIMO_VALUE ");
		mainQuery.append("   AND (CR.CORRECTED_PRESSURE IS NOT NULL ");
		mainQuery.append("     OR CR.CORRECTED_PRESSURE <> ' ' ");
		mainQuery.append("     OR CR.CORRECTED_PRESS_UOM IS NOT NULL ");
		mainQuery.append("     OR CR.CORRECTED_PRESS_UOM <> ' ') ");
		
		//Start Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		//PreparedStatement mainQueryPS = createPreparedStatement(mainQuery.toString());
		PreparedStatement mainQueryPS = createPreparedStatement(mainQuery.toString(), getClass().getName());
		//End Change - 2016-01-29 - MPang - Updated for CCB v2.4 compilation
		mainQueryPS.execute();
		
		QueryIterator iter = mainQueryPS.iterate();
		
		return createJobWorkForQueryIterator(iter, this);
	}
    
    public ThreadWorkUnit createWorkUnit(QueryResultRow resultRow) {
    	
    	ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        threadWorkUnit.addSupplementalData("mtrId", resultRow.getString("MTR_ID"));
        threadWorkUnit.addSupplementalData("correctedPressure", resultRow.getString("CORRECTED_PRESSURE"));
        threadWorkUnit.addSupplementalData("correctedPressUOM", resultRow.getString("CORRECTED_PRESS_UOM"));
    	
        return threadWorkUnit;
	}
    
    public void validateSoftParameters(boolean isNewRun) {
    	cmValidateBatchParmCharType(getParameters().getMeterPressureCharType(), CharacteristicEntityLookup.constants.METER, MTR_PRESSURE);
    	cmValidateBatchParmCharType(getParameters().getMeterPressureUOMCharType(), CharacteristicEntityLookup.constants.METER, MTR_PRESSURE_UOM);
    }
	
	private void cmValidateBatchParmCharType(CharacteristicType charType, CharacteristicEntityLookup charEntLookup, String parmDescr) {
		
		// Validate char entity.
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, charEntLookup);
        if(isNull(charEntityId.getEntity())) {
            addError(CustomMessageRepositoryMGE.commBatchParameterIsNotAValidCharTypeForEntity(parmDescr, 
            		charType.getId().getTrimmedValue(), charEntLookup.trimmedValue()));
        }
	}
	
	public Class<CmMaximoDataCorrectionMeterPressureBatchWorker> getThreadWorkerClass() {
        return CmMaximoDataCorrectionMeterPressureBatchWorker.class;
    }

    public static class CmMaximoDataCorrectionMeterPressureBatchWorker 
    		extends CmMaximoDataCorrectionMeterPressureBatchWorker_Gen {
    	
    	// Constants.
    	private static final String MAXIMO_MTR_ID_DESCR = "Meter ID from Maximo";
    	private static final String CCB_MTR_ID_DESCR = "Meter ID";
    	private static final String CI_MTR_CHAR = "CI_MTR_CHAR";
    	private static final String CHAR_VAL_FK1 = "CHAR_VAL_FK1";
    	private static final String CHAR_VAL = "CHAR_VAL";
    	private static final String ADHOC_CHAR_VAL = "ADHOC_CHAR_VAL";
    	
    	public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

		@Override
		public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit) throws ThreadAbortedException, RunAbortedException {

			WorkUnitResult result = new WorkUnitResult(true);
			
			// Retrieve error details from main query.
			String mtrIdStr = (String) unit.getSupplementallData("mtrId");
			String correctedPressure = (String) unit.getSupplementallData("correctedPressure");
			String correctedPressUOM = (String) unit.getSupplementallData("correctedPressUOM");
			
			// Validate retrieved values.
			if(isBlankOrNull(mtrIdStr)) {
				addError(CustomMessageRepositoryMGE.commGenericErrorParameterMissing(MAXIMO_MTR_ID_DESCR));
			} else if (isNull((new Meter_Id(mtrIdStr)).getEntity())) {
				addError(CustomMessageRepositoryMGE.commGenericErrorParameterIsInvalidEntity(MAXIMO_MTR_ID_DESCR,CCB_MTR_ID_DESCR));
			}
			
			Meter mtr = (new Meter_Id(mtrIdStr)).getEntity();
						
			// Retrieve meter chars for pressure and pressure UOM.
			MeterCharacteristic mtrPressure = mtr.getEffectiveCharacteristic(getParameters().getMeterPressureCharType());
			MeterCharacteristic mtrPressureUOM = mtr.getEffectiveCharacteristic(getParameters().getMeterPressureUOMCharType());
			
			// If meter pressure is null or not equal to corrected pressure, create new char with corrected value.
			if(!isBlankOrNull(correctedPressure) && 
					(isNull(mtrPressure) || !cmGetCharValue(mtrPressure).equals(correctedPressure))) {
				cmCreateMeterChar(mtr, getParameters().getMeterPressureCharType(), correctedPressure);
			}
			
			// If meter pressure UOM is null or not equal to corrected pressure UOM, create new char with corrected value.
			if(!isBlankOrNull(correctedPressUOM) && 
					(isNull(mtrPressureUOM) || !cmGetCharValue(mtrPressureUOM).equals(correctedPressUOM))) {
				cmCreateMeterChar(mtr, getParameters().getMeterPressureUOMCharType(), correctedPressUOM);
			}
			
			
			result.setUnitsProcessed(1);
			return result;
		}
		
		private String cmGetCharValue(MeterCharacteristic mc) {
			
			if(isNull(mc)) {
				return "";
			}
			
			if(mc.getId().getCharacteristicType().getCharacteristicType().isForeignKeyValue()) {
				return mc.getCharacteristicValueForeignKey1().trim();
			} else if(mc.getId().getCharacteristicType().getCharacteristicType().isPredefinedValue()) {
				return mc.getCharacteristicValue().trim();
			} else {
				return mc.getAdhocCharacteristicValue().trim();
			}
		}
		
		private void cmCreateMeterChar(Meter mtr, CharacteristicType charType, String charVal) {
			
			Date effDate = getProcessDateTime().getDate();
			CharacteristicTypeLookup charTypeFlag = charType.getCharacteristicType();
			String oldValue = "";
			
			// Perform update if effective char is effective on process date.
			MeterCharacteristic mc = mtr.getEffectiveCharacteristic(charType);
			
			if(notNull(mc)) {
				
				oldValue = cmGetCharValue(mc);
				
				if(mc.getId().getEffectiveDate().equals(effDate)) {
					MeterCharacteristic_DTO mcDto = mc.getDTO();
						
					if(charTypeFlag.isForeignKeyValue()) {
						mcDto.setCharacteristicValueForeignKey1(charVal);
					} else if(charTypeFlag.isPredefinedValue()) {
						mcDto.setCharacteristicValue(charVal);
					} else {
						mcDto.setAdhocCharacteristicValue(charVal);
					}
					
					mc.setDTO(mcDto);
					cmCreateLog(mc, charVal, oldValue);
					return;
				}
			}
			
			// Perform add meter char.
			MeterCharacteristics mcs = mtr.getCharacteristics();
			MeterCharacteristic_DTO mcDto = mcs.newChildDTO();
			
			if(charTypeFlag.isForeignKeyValue()) {
				mcDto.setCharacteristicValueForeignKey1(charVal);
			} else if(charTypeFlag.isPredefinedValue()) {
				mcDto.setCharacteristicValue(charVal);
			} else {
				mcDto.setAdhocCharacteristicValue(charVal);
			}
			
			MeterCharacteristic mcNew = mcs.add(mcDto, charType.getId(), effDate);
			cmCreateLog(mcNew, charVal, oldValue);
			
		}
		
		private void cmCreateLog(MeterCharacteristic mc, String newValue, String oldValue) {
			
			CharacteristicTypeLookup charTypeFlag = mc.getId().getCharacteristicType().getCharacteristicType();
			
			CmMeterDataLog_DTO logDto = createDTO(CmMeterDataLog.class);
			logDto.setCreationDateTime(getProcessDateTime());
			logDto.setPrimaryKeyValue1(mc.getId().getMeterId().getIdValue());
			logDto.setPrimaryKeyValue2(mc.getId().getCharacteristicTypeId().getIdValue());
			logDto.setPrimaryKeyValue3(mc.getId().getEffectiveDate().toString());
			logDto.setTable(CI_MTR_CHAR);
			logDto.setValueAfterUpdate(newValue);
			logDto.setValueBeforeUpdate(oldValue);
			
			if(charTypeFlag.isForeignKeyValue()) {
				logDto.setField(CHAR_VAL_FK1);
			} else if(charTypeFlag.isPredefinedValue()) {
				logDto.setField(CHAR_VAL);
			} else {
				logDto.setField(ADHOC_CHAR_VAL);
			}
			
			logDto.newEntity();
		}
    }
}