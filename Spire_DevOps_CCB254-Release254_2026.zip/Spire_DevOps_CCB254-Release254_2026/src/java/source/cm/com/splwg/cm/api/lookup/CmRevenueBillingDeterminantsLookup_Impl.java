/**************************************************************************
 *                                                                
 * PROGRAM DESCRIPTION:                                           
 * 
 * Revenue Billing Determinant Lookup
 *             
 **************************************************************************
 *                                                                
 * CHANGE HISTORY:                                                
 *                                                                
 * Date:        by:     Reason:                                     
 * YYYY-MM-DD   IN      Reason text.                                
 *           
 * 2013-04-25   JPunza  NI0034.1 Initial Version.
 *************************************************************************/

package com.splwg.cm.api.lookup;

/**
 * @author jpunzalan2
 *
 @LookupFieldname (value = XRBD_OPT_TYP_FLG)
 */
public class CmRevenueBillingDeterminantsLookup_Impl
        extends CmRevenueBillingDeterminantsLookup_Gen {

}
