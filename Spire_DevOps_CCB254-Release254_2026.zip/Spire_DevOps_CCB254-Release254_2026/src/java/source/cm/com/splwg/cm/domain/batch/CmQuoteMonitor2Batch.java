/*
 **************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * Quote monitoring batch total rewrite to JAVA (manually without using 
 * conversion tool)
 * 
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:         Reason:
 * YYYY-MM-DD   IN          Reason text.
 *  
 * 2018-10-05	JHERNA		SysAid#271019. Total rewrite of Quote Monitoring
 * 							batch to JAVA manually. 
 * 							New Functionality: Do not process ARP, BPAP, CWR
 *                          if account has a none canceled/closed GPAFARP 
 *                          Payment Arrangement SA.    
 * 2019-08-28   JHERNA      SysAid#303672. For CWR that starts due to minor
 *                          pledges, whatever amount is pledged should be
 *                          left on the Gas SA in both the current and 
 *                          payoff balances.    
 * 2021-03-18	JHERNA		SysAid#362495. Do not process CWR quote when
 * 							the customer is already enrolled on FCAP.                                                             
 * *************************************************************************                
 */

package com.splwg.cm.domain.batch;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.QueryIterator;
import com.splwg.base.api.QueryResultRow;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadIterationStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.businessObject.BusinessObjectDispatcher;
import com.splwg.base.api.businessObject.BusinessObjectInstance;
import com.splwg.base.api.businessObject.COTSFieldDataAndMD;
import com.splwg.base.api.businessObject.COTSInstanceList;
import com.splwg.base.api.businessObject.COTSInstanceListNode;
import com.splwg.base.api.businessService.BusinessServiceDispatcher;
import com.splwg.base.api.businessService.BusinessServiceInstance;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.datatypes.StringId;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus_Id;
import com.splwg.base.domain.common.businessObject.BusinessObject_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.currency.Currency_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.security.user.User;
import com.splwg.base.domain.serviceTask.ServiceTask;
import com.splwg.base.domain.serviceTask.ServiceTask_Id;
import com.splwg.base.domain.serviceTask.serviceTaskType.ServiceTaskType;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.SpecialRoleLookup;
import com.splwg.ccb.api.lookup.StopReasonLookup;
import com.splwg.ccb.domain.adjustment.adjustment.entity.Adjustment;
import com.splwg.ccb.domain.adjustment.common.CreateFrozenAdjustment;
import com.splwg.ccb.domain.adjustment.data.CreateFrozenAdjustmentData;
import com.splwg.ccb.domain.admin.adjustmentType.entity.AdjustmentType;
import com.splwg.ccb.domain.admin.budgetPlan.entity.BudgetPlan;
import com.splwg.ccb.domain.admin.budgetPlan.entity.BudgetPlan_Id;
import com.splwg.ccb.domain.admin.collectionClass.entity.CollectionClass_Id;
import com.splwg.ccb.domain.admin.customerClass.entity.CustomerClass_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.data.ServiceAgreementBalanceData;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristics;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.cm.api.lookup.CmBpapCreditValuesLookup;
import com.splwg.cm.api.lookup.CmDiversionSaTypesLookup;
import com.splwg.cm.api.lookup.CmEligibleMajorPledgeFundingTypesLookup;
import com.splwg.cm.api.lookup.CmLowIncomeProgramConfigurationsOptionTypeLookup;
import com.splwg.cm.api.lookup.CmPaymentArrangementSaTypesLookup;
import com.splwg.cm.api.lookup.CmQuotePortalParametersLookup;
import com.splwg.cm.api.lookup.CmQuoteSelectionValuesLookup;
import com.splwg.cm.api.lookup.CmServiceTaskCharacteristicTypesForBatchLookup;
import com.splwg.cm.api.lookup.ExternalSystemTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;

/**
 * @author 90622
 *
@BatchJob (rerunnable = false, modules = {}, 
 *      softParameters = { @BatchJobSoftParameter (entityName = serviceTaskType, name = QUOTE_SVC_TASK_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = serviceTaskType, name = PLEDGE_SVC_TASK_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = QUOTE_SVC_TASK_ACTIVE_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = QUOTE_SVC_TASK_EXPIRED_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (name = PLEDGE_SVC_TASK_ACTIVE_STATUS, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = PA_SA_WFM_NAME, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = SELECTION_WFM_NAME, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = DIVERSION_SA_WFM_NAME, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = BPAP_CRED_VAL_WFM_NAME, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = SVC_TASK_CHAR_WFM_NAME, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = featureConfiguration, name = MAJOR_PLED_FUND_TYP_WFM_NAME, required = true, type = entity)
 *            , @BatchJobSoftParameter (name = ARP_PA_SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = CWR_PA_SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FARP_PA_SA_TYPE, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = adjustmentType, name = ZERO_ADJ_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = budgetPlan, name = CWR_BUDGET_PLAN, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = budgetPlan, name = LOW_INCOME_BUDGET_PLAN, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = CWR_LVL_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = BPAP_CRED_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = HAS_QUOTE_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = PREM_ID_SA_CHAR_TYPE, required = true, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = QUOTE_ID_SA_CHAR_TYPE, required = true, type = entity)})
 */
public class CmQuoteMonitor2Batch 
		extends CmQuoteMonitor2Batch_Gen {

	public Class<CmQuoteMonitor2BatchWorker> getThreadWorkerClass() {
		return CmQuoteMonitor2BatchWorker.class;
	}

	@Override
	public void validateSoftParameters(boolean isNewRun) {

		BusinessObject quoteBo = getParameters().getQUOTE_SVC_TASK_TYPE().getRelatedTransactionBO();
		BusinessObjectStatus_Id quoteServiceTaskActiveStatusId = new BusinessObjectStatus_Id(quoteBo, getParameters().getQUOTE_SVC_TASK_ACTIVE_STATUS());
		if (isNull(quoteServiceTaskActiveStatusId.getEntity())) {
			CustomMessageRepository.JACOB_boStatusNotValidForBo(
					getParameters().getQUOTE_SVC_TASK_ACTIVE_STATUS(), quoteBo.getId().getTrimmedValue());
		}

		String cwrPaSaType = getParameters().getCWR_PA_SA_TYPE();
		validateSAType("CWR PA SA Type", cwrPaSaType);
		String arpPaSaType = getParameters().getARP_PA_SA_TYPE();
		validateSAType("ARP PA SA Type", arpPaSaType);
		String farpPaSaType = getParameters().getFARP_PA_SA_TYPE();
		validateSAType("FARP PA SA Type", farpPaSaType);
		
		CharacteristicType bpapCredCharType = getParameters().getBPAP_CRED_CHAR_TYPE();
		CharacteristicEntity charEntity = new CharacteristicEntity_Id(bpapCredCharType, 
				CharacteristicEntityLookup.constants.SERVICE_AGREEMENT).getEntity();
		if (isNull(charEntity)) {
			addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
					bpapCredCharType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().getEffectiveDescription()));
		}

		BusinessObject pledgeBo = getParameters().getPLEDGE_SVC_TASK_TYPE().getRelatedTransactionBO();
		BusinessObjectStatus_Id pledgeServiceTaskStatusId = new BusinessObjectStatus_Id(pledgeBo, getParameters().getPLEDGE_SVC_TASK_ACTIVE_STATUS());
		if (isNull(pledgeServiceTaskStatusId.getEntity())) {
			CustomMessageRepository.JACOB_boStatusNotValidForBo(
					getParameters().getPLEDGE_SVC_TASK_ACTIVE_STATUS(), pledgeBo.getId().getTrimmedValue());
		}

		CharacteristicType cwrSaCharType = getParameters().getCWR_LVL_CHAR_TYPE();
		charEntity = new CharacteristicEntity_Id(cwrSaCharType, 
				CharacteristicEntityLookup.constants.SERVICE_AGREEMENT).getEntity();
		if (isNull(charEntity)) {
			addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
					cwrSaCharType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().getEffectiveDescription()));
		}

		CharacteristicType quoteIdSaCharType = getParameters().getQUOTE_ID_SA_CHAR_TYPE();
		charEntity = new CharacteristicEntity_Id(quoteIdSaCharType, 
				CharacteristicEntityLookup.constants.SERVICE_AGREEMENT).getEntity();
		if (isNull(charEntity)) {
			addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
					quoteIdSaCharType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().getEffectiveDescription()));
		}

		BusinessObjectStatus_Id quoteServiceTaskExpiredStatusId = new BusinessObjectStatus_Id(quoteBo, getParameters().getQUOTE_SVC_TASK_EXPIRED_STATUS());
		if (isNull(quoteServiceTaskExpiredStatusId.getEntity())) {
			CustomMessageRepository.JACOB_boStatusNotValidForBo(
					getParameters().getQUOTE_SVC_TASK_EXPIRED_STATUS(), quoteBo.getId().getTrimmedValue());
		}

		CharacteristicType premiseIdSaCharType = getParameters().getPREM_ID_SA_CHAR_TYPE();
		charEntity = new CharacteristicEntity_Id(premiseIdSaCharType, 
				CharacteristicEntityLookup.constants.SERVICE_AGREEMENT).getEntity();
		if (isNull(charEntity)) {
			addError(CustomMessageRepository.JACOB_charTypeNotValidForEntity(
					premiseIdSaCharType.getId().getTrimmedValue(), 
					CharacteristicEntityLookup.constants.SERVICE_AGREEMENT.getLookupValue().getEffectiveDescription()));
		}
	}
	
	private void validateSAType(String parmDesc, String saType) {
		
		StringBuilder stringBuilder = new StringBuilder();			
		stringBuilder.append("SELECT 'X' ");
		stringBuilder.append("FROM CI_SA_TYPE ");
		stringBuilder.append("WHERE SA_TYPE_CD = '"+saType.trim()+"' ");
		PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==CmQuoteMonitor2Batch.valdiateSAType==");
		prepState.setAutoclose(false);
		prepState.execute();
		if (isNull(prepState.firstRow())) {
			prepState.close();
		    // Batch parameter '%1%2' value (%3) is invalid.
			addError(CustomMessageRepositoryMGE.commBatchParameterInvalid(parmDesc.trim(), saType.trim()));
		}
		prepState.close();			
	}

	public static class CmQuoteMonitor2BatchWorker 
			extends CmQuoteMonitor2BatchWorker_Gen {

		/*Soft Parameters*/
		private AdjustmentType parmAdjTypeZero;

		private BudgetPlan parmBudPlanLow;
		private BudgetPlan parmBudPlanCWR;

		private CharacteristicType parmCharTypeBPAPCred;						
		private CharacteristicType parmCharTypeCWRLevel;
		private CharacteristicType parmCharTypeQuoteSource;		
		private CharacteristicType parmCharTypePremiseId;
		private CharacteristicType parmCharTypeHasQuote;

		private FeatureConfiguration parmFeatConfSelection;
		private FeatureConfiguration parmFeatConfDiversionSA;
		private FeatureConfiguration parmFeatConfPASATypes;
		private FeatureConfiguration parmFeatConfBPAPCredVal;
		private FeatureConfiguration parmFeatConfSvcTaskChar;			
		private FeatureConfiguration parmFeatConfMajorPledgeFundingType;			

		private ServiceTaskType parmSTaskTypeQuote;
		private ServiceTaskType parmSTaskTypePledge;

		private String parmActiveStatusQuote;
		private String parmActiveStatusPledge;
		private String parmExpiredStatusQuote;		
		private String parmSATypeCWRPA;
		private String parmSATypeARPPA;
		private String parmSATypeFARPPA;

		/*Work Variable*/
		@SuppressWarnings("unused")
		private String wBatchControlID;		
		private Date wProcessDate;
		private User wContextUser;
		private BusinessObject_Id wBusinessObjectIDQuote;
		
		private String wSelStandard;
		private String wSelCWR;
		private String wSelARP_FPL_50_24;
		private String wSelARP_FPL_99_24;
		private String wSelARP_FPL_125_24;
		private String wSelARP_FPL_185_24;
		private String wSelBPAP_FPL_50_24;
		private String wSelBPAP_FPL_99_24;
		private String wSelBPAP_FPL_125_24;
		private String wSelBPAP_FPL_185_24;
		private String wSelARP_FPL_50_12;
		private String wSelARP_FPL_99_12;
		private String wSelARP_FPL_125_12;
		private String wSelARP_FPL_185_12;
		private String wSelBPAP_FPL_50_12;
		private String wSelBPAP_FPL_99_12;
		private String wSelBPAP_FPL_125_12;
		private String wSelBPAP_FPL_185_12;		

		private String wCredBPAP_0_50;
		private String wCredBPAP_51_99;
		private String wCredBPAP_100_125;
		private String wCredBPAP_126_185;

		private CharacteristicType_Id wCharTypeIdSAID;
		private CharacteristicType_Id wCharTypeIdSelection;
		private CharacteristicType_Id wCharTypeIdPledgeAmount;
		private CharacteristicType_Id wCharTypeIdTotalDiversion;
		private CharacteristicType_Id wCharTypeIdCWRDownPayment;
		private CharacteristicType_Id wCharTypeIdARP_0_50_DP;
		private CharacteristicType_Id wCharTypeIdARP_51_99_DP;
		private CharacteristicType_Id wCharTypeIdARP_100_125_DP;
		private CharacteristicType_Id wCharTypeIdARP_126_185_DP;
		private CharacteristicType_Id wCharTypeIdMonthlyBudget;
		private CharacteristicType_Id wCharTypeIdTotalSAArrears;
		private CharacteristicType_Id wCharTypeIdCWRLevel;
		private CharacteristicType_Id wCharTypeIdBPAP_0_50_MonthlyBudget;
		private CharacteristicType_Id wCharTypeIdBPAP_51_99_MonthlyBudget;
		private CharacteristicType_Id wCharTypeIdBPAP_100_125_MonthlyBudget;
		private CharacteristicType_Id wCharTypeIdBPAP_126_185_MonthlyBudget;
		private CharacteristicType_Id wCharTypeIdFundingType;
		
		private static final BigInteger CM_CONST_BPAP_CRED_MNTH_PERIOD = BigInteger.valueOf(24);
		private static final BigInteger CM_CONST_BPAP_CRED_1YR = BigInteger.valueOf(12);		
		private static final CmMGEFeatureConfigurationOptionsRetriever fcHelper = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
		
		public ThreadExecutionStrategy createExecutionStrategy() {
			return new ThreadIterationStrategy(this);
		}

		@Override
		public void initializeThreadWork(
				boolean initializationPreviouslySuccessful,
				ThreadWorkUnit lastWorkUnit) throws ThreadAbortedException,
				RunAbortedException {

			wBatchControlID = this.getBatchControlId().getTrimmedValue();
			wProcessDate = this.getProcessDateTime().getDate();
			wContextUser = this.getActiveContextUser();
			FeatureConfiguration_Id featConfIDQuote = fcHelper.getFeatureConfiguration(ExternalSystemTypeLookup.constants.CM_QUOTE_PORTAL_PARAMETERS);
			wBusinessObjectIDQuote = fcHelper.getBusinessObjectFeatureOptionValue(featConfIDQuote, 
					CmQuotePortalParametersLookup.constants.QUOTE_BUSINESS_OBJECT, Bool.TRUE, Bool.FALSE);
			
			parmSTaskTypeQuote = this.getParameters().getQUOTE_SVC_TASK_TYPE();
			parmActiveStatusQuote = this.getParameters().getQUOTE_SVC_TASK_ACTIVE_STATUS();

			parmSATypeCWRPA = this.getParameters().getCWR_PA_SA_TYPE();
			parmSATypeARPPA = this.getParameters().getARP_PA_SA_TYPE();
			parmSATypeFARPPA = this.getParameters().getFARP_PA_SA_TYPE();
			
			parmBudPlanLow = this.getParameters().getLOW_INCOME_BUDGET_PLAN();
			parmBudPlanCWR = this.getParameters().getCWR_BUDGET_PLAN();			
			parmCharTypeBPAPCred = this.getParameters().getBPAP_CRED_CHAR_TYPE();
			parmSTaskTypePledge = this.getParameters().getPLEDGE_SVC_TASK_TYPE();
			parmActiveStatusPledge = this.getParameters().getPLEDGE_SVC_TASK_ACTIVE_STATUS();
			parmFeatConfSelection = this.getParameters().getSELECTION_WFM_NAME();
			parmFeatConfDiversionSA = this.getParameters().getDIVERSION_SA_WFM_NAME();
			parmFeatConfPASATypes = this.getParameters().getPA_SA_WFM_NAME();

			parmCharTypeCWRLevel = this.getParameters().getCWR_LVL_CHAR_TYPE();
			parmCharTypeQuoteSource = this.getParameters().getQUOTE_ID_SA_CHAR_TYPE();
			parmExpiredStatusQuote = this.getParameters().getQUOTE_SVC_TASK_EXPIRED_STATUS();
			parmFeatConfBPAPCredVal = this.getParameters().getBPAP_CRED_VAL_WFM_NAME();
			parmFeatConfSvcTaskChar = this.getParameters().getSVC_TASK_CHAR_WFM_NAME();
			parmCharTypePremiseId = this.getParameters().getPREM_ID_SA_CHAR_TYPE();
			parmAdjTypeZero = this.getParameters().getZERO_ADJ_TYPE();
			parmFeatConfMajorPledgeFundingType = this.getParameters().getMAJOR_PLED_FUND_TYP_WFM_NAME();
			parmCharTypeHasQuote = this.getParameters().getHAS_QUOTE_CHAR_TYPE();

			this.startResultRowQueryIteratorForThread(ServiceTask_Id.class);
		}

		@SuppressWarnings("rawtypes")
		@Override
		protected QueryIterator getQueryIteratorForThread(StringId lowID,
				StringId highID) {

			String sqlStatement =          
					"SELECT " +
					"   ST.F1_SVC_TASK_ID, " +
					"   ST.CRE_DTTM, " +
					"   STC.CHAR_VAL_FK1 " +
					"FROM " +
					"   F1_SVC_TASK ST, " +
					"   F1_SVC_TASK_CHAR STC " +
					"WHERE " +
					"   ST.F1_STASK_TYPE_CD = :staskTypeQuote " +
					"    AND ST.BO_STATUS_CD = '"+parmActiveStatusQuote.trim()+"' " +
					"    AND STC.F1_SVC_TASK_ID = ST.F1_SVC_TASK_ID " +
					"    AND STC.CHAR_TYPE_CD = :charTypeSaID " +
					"    AND STC.SEQ_NUM = (SELECT MAX(STC2.SEQ_NUM) " +
					"                        FROM F1_SVC_TASK_CHAR STC2 " +
					"                        WHERE STC2.F1_SVC_TASK_ID = STC.F1_SVC_TASK_ID " +
					"                        AND STC2.CHAR_TYPE_CD = STC.CHAR_TYPE_CD) " +
					"AND ST.F1_SVC_TASK_ID BETWEEN :lowID AND :highID " +
					"ORDER BY ST.F1_SVC_TASK_ID ";

			PreparedStatement prepState = createPreparedStatement(sqlStatement, "===CmQuoteMonitor2Batch.getQueryIteratorForThread===");
			prepState.bindId("staskTypeQuote", parmSTaskTypeQuote.getId());			
			prepState.bindId("charTypeSaID", fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(),
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.SERVICE_AGREEMENT_ID, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK));
			prepState.bindId("lowID", lowID);
			prepState.bindId("highID", highID);
			prepState.setAutoclose(false);
			prepState.execute();	
			return prepState.iterate();			
		}				

		@Override
		protected ThreadWorkUnit getNextWorkUnit(QueryResultRow row) {

			ThreadWorkUnit twu = new ThreadWorkUnit(row.getId("F1_SVC_TASK_ID", ServiceTask.class));
			twu.addSupplementalData("creationDttm", row.getDateTime("CRE_DTTM"));
			twu.addSupplementalData("saID", row.getString("CHAR_VAL_FK1"));
			return twu;
		}

		public boolean executeWorkUnit(ThreadWorkUnit unit)
				throws ThreadAbortedException, RunAbortedException {

			ServiceTask_Id quoteID = (ServiceTask_Id) unit.getPrimaryId();
			DateTime quoteCreDttm = (DateTime) unit.getSupplementallData("creationDttm");
			String saIdStr = (String) unit.getSupplementallData("saID");

			/*Check work unit fields*/
			if (isNull(quoteID.getEntity())) {
				// Service Task Id (%1) does not exists
				addError(CustomMessageRepositoryMGE.qumonServiceTaskIDInvalid(quoteID.getTrimmedValue()));
			}

			if (isBlankOrNull(saIdStr)) {
				// Quote (%1)  does not have SA data
				addError(CustomMessageRepositoryMGE.qumonNoSAData(quoteID.getTrimmedValue()));
			}			
			ServiceAgreement_Id saID = new ServiceAgreement_Id(saIdStr.trim());

			if (isNull(saID.getEntity())) {
				// Quote's (%1) SA (%2) data is invalid
				addError(CustomMessageRepositoryMGE.qumonSAInvalid(quoteID.getTrimmedValue(), saIdStr.trim()));
			}

			if (isNull(quoteCreDttm)) {
				// Quote (%1) does not have Creation Date Time data
				addError(CustomMessageRepositoryMGE.qumonNoCreDttmData(quoteID.getTrimmedValue()));
			}

			/* START CMPQMBPN */
			checkInput();
			performProcessing(quoteID, quoteCreDttm, saID);
			/* END CMPQMBPN */
			return true;
		}		

		private void checkInput() {

			// Retrieve Option Values from Selection Feature Configuration
			wSelStandard = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_STANDARD, Bool.TRUE);
			wSelCWR = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_CWR, Bool.TRUE);
			wSelARP_FPL_50_24 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_ARP_5_0___2_4, Bool.TRUE); 
			wSelARP_FPL_99_24 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_ARP_9_9___2_4, Bool.TRUE);
			wSelARP_FPL_125_24 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_ARP_1_2_5___2_4, Bool.TRUE);
			wSelARP_FPL_185_24 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_ARP_1_8_5___2_4, Bool.TRUE);
			wSelBPAP_FPL_50_24 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_BPAP_5_0___2_4, Bool.TRUE);
			wSelBPAP_FPL_99_24 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_BPAP_9_9___2_4, Bool.TRUE);
			wSelBPAP_FPL_125_24 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_BPAP_1_2_5___2_4, Bool.TRUE);
			wSelBPAP_FPL_185_24 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_BPAP_1_8_5___2_4, Bool.TRUE);
			wSelARP_FPL_50_12 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_ARP_5_0___1_2, Bool.TRUE);
			wSelARP_FPL_99_12 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_ARP_9_9___1_2, Bool.TRUE);
			wSelARP_FPL_125_12 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_ARP_1_2_5___1_2, Bool.TRUE);
			wSelARP_FPL_185_12 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_ARP_1_8_5___1_2, Bool.TRUE);
			wSelBPAP_FPL_50_12 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_BPAP_5_0___1_2, Bool.TRUE);
			wSelBPAP_FPL_99_12 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_BPAP_9_9___1_2, Bool.TRUE);
			wSelBPAP_FPL_125_12 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_BPAP_1_2_5___1_2, Bool.TRUE);
			wSelBPAP_FPL_185_12 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfSelection.getId(), CmQuoteSelectionValuesLookup.constants.CM_BPAP_1_8_5___1_2, Bool.TRUE);

			// Retrieve Option Values from BPAP Feature Configurations
			wCredBPAP_0_50 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfBPAPCredVal.getId(), CmBpapCreditValuesLookup.constants.CM_BPAP_5_0_CREDIT_VALUE, Bool.TRUE);
			wCredBPAP_51_99 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfBPAPCredVal.getId(), CmBpapCreditValuesLookup.constants.CM_BPAP_9_9_CREDIT_VALUE, Bool.TRUE);
			wCredBPAP_100_125 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfBPAPCredVal.getId(), CmBpapCreditValuesLookup.constants.CM_BPAP_1_2_5_CREDIT_VALUE, Bool.TRUE);
			wCredBPAP_126_185 = fcHelper.getMaximumSequenceFeatureOptionValue(parmFeatConfBPAPCredVal.getId(), CmBpapCreditValuesLookup.constants.CM_BPAP_1_8_5_CREDIT_VALUE, Bool.TRUE);

			// Retrieve Service Task Characteristic Feature Configurations
			wCharTypeIdSAID = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.SERVICE_AGREEMENT_ID, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdSelection = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.SELECTION, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdPledgeAmount = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.PLEDGE_AMOUNT, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdTotalDiversion = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.TOTAL_DIVERSION, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdCWRDownPayment = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.CWR_DOWN_PAYMENT, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdARP_0_50_DP = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.ARP___0___5_0___DOWN_PAYMENT, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdARP_51_99_DP = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.ARP___5_1___9_9___DOWN_PAYMENT, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdARP_100_125_DP = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.ARP___1_0_0___1_2_5___DOWN_PAYMENT, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdARP_126_185_DP = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.ARP___1_2_6___1_8_5___DOWN_PAYMENT, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdMonthlyBudget = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.MONTHLY_BUDGET, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdTotalSAArrears = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.TOTAL_SA_ARREARS, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdCWRLevel = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.CWR_LEVEL, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdBPAP_0_50_MonthlyBudget = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.BPAP___0___5_0___MONTHLY_BUDGET, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdBPAP_51_99_MonthlyBudget = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.BPAP___5_1___9_9___MONTHLY_BUDGET, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdBPAP_100_125_MonthlyBudget = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.BPAP___1_0_0___1_2_5___MONTHLY_BUDGET, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdBPAP_126_185_MonthlyBudget = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.BPAP___1_2_6___1_8_5___MONTHLY_BUDGET, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);
			wCharTypeIdFundingType = fcHelper.getCharacteristicTypeFeatureOptionValue(parmFeatConfSvcTaskChar.getId(), 
					CmServiceTaskCharacteristicTypesForBatchLookup.constants.FUNDING_TYPE, Bool.TRUE, Bool.FALSE, CharacteristicEntityLookup.constants.SERVICE_TASK);				
		}
		
		private void performProcessing(ServiceTask_Id quoteID, DateTime quoteCreDttm, ServiceAgreement_Id saID) {

			ServiceAgreement serviceAgreement = saID.getEntity();
			ServiceAgreementStatusLookup saStatus = serviceAgreement.getStatus();
			Account_Id accountID = serviceAgreement.getAccount().getId();
			ServiceAgreementType saType = serviceAgreement.getServiceAgreementType();
			SpecialRoleLookup saSpecRole = saType.getSpecialRole();

			// If account have active payment arrangement then skip processing this record
			/* SA-19632*/
			if(hasActivePayArrangement(accountID)) {
				return;
			}			

			// Continue processing only if SA's status is Active/Reactivated and SA is not a Write Off.
			if ((saStatus.isActive()
					|| saStatus.isReactivated())
					&& !(saSpecRole.isWriteOff())) {

				String quoteSelection = getServiceTaskData(quoteID, wCharTypeIdSelection);
				// Continue processing if selection is not Standard				
				if (quoteSelection.compareToIgnoreCase(wSelStandard) != 0) {
					/*============================================================*/
					/* New Functionality for Low Income Program (shouldProceed)   */
					/*   Proceed processing quote only if the account             */
					/*   does not have any none canceled/closed GPAFARP PA SA     */
					/*   otherwise, expire the quote                              */
					/*============================================================*/
					if (shouldProceed(accountID).isTrue()) {
						
						if (hasMajorFundingType(quoteCreDttm, saID)){	
							BigDecimal downPayment = getDownPayment(quoteID, quoteSelection);
							processQuote(quoteID, quoteCreDttm, saID, quoteSelection, downPayment, BigDecimal.ZERO, true);
						}
						else {
							BigDecimal totPayPledges = getPaymentsAndPledges(quoteCreDttm, saID);
							BigDecimal downPayment = getDownPayment(quoteID, quoteSelection);

							// Continue process only if Total Payments and Pledges is greater than or equal the Down Payment
							if (totPayPledges.compareTo(downPayment) >= 0) {						
								processQuote(quoteID, quoteCreDttm, saID, quoteSelection, downPayment, totPayPledges, false);
							}
						}
					} else {
						/*==================*/
						/* Expire the Quote */
						/*==================*/				
						// Retrieve the Quote BO Instance											
						BusinessObjectInstance boInstance = BusinessObjectInstance.create(wBusinessObjectIDQuote.getEntity());
						boInstance.setXMLString("serviceTaskId", quoteID.getTrimmedValue());
						
						BusinessObjectInstance quoteBO = BusinessObjectDispatcher.read(boInstance);
						quoteBO.setXMLString("status", parmExpiredStatusQuote.trim());
						
						BusinessObjectDispatcher.update(quoteBO);
										
						/*==========================*/
						/* Delete SA Characteristic */
						/*==========================*/
						deleteSACharacteristic(serviceAgreement, parmCharTypeHasQuote);
					}
				}
			}
		}

		private boolean hasActivePayArrangement(Account_Id accountID) {

			boolean returnValue = false;

			// Retrieve Payment Arrangement SA Types Feature Configuration
			List<String> listOfPaSaTypes = fcHelper.getListOfFeatureOptionValues(parmFeatConfPASATypes.getId(),
					CmPaymentArrangementSaTypesLookup.constants.PAYMENT_ARRANGEMENT_SA_TYPE);
			Iterator<String> iter = listOfPaSaTypes.iterator();

			String paSaTypes = "";
			while (iter.hasNext()) {
				paSaTypes = paSaTypes.concat("'").trim();
				paSaTypes = paSaTypes.concat(iter.next()).trim();
				paSaTypes = paSaTypes.concat("',").trim();
			}
			paSaTypes = paSaTypes.substring(0, (paSaTypes.length() - 1) );

			// Check if an active PA SA exists for the account
			StringBuilder stringBuilder = new StringBuilder();	  
			stringBuilder.append("SELECT "); 
			stringBuilder.append("    SA_ID ");
			stringBuilder.append("FROM "); 
			stringBuilder.append("    CI_SA ");
			stringBuilder.append("WHERE "); 
			stringBuilder.append("    ACCT_ID = :acctID ");
			stringBuilder.append("    AND SA_TYPE_CD IN ("+paSaTypes+") ");
			stringBuilder.append("    AND SA_STATUS_FLG IN (:pendingStart, :active, :pendingStop, :reactivated) ");

			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==CmQuoteMonitor2Batch.hasActivePayArrangement()==");
			prepState.bindId("acctID", accountID);
			prepState.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
			prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
			prepState.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
			prepState.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
			prepState.setAutoclose(false);
			prepState.execute();
			if (prepState.list().size() > 0) {
				returnValue = true;
			}	  
			prepState.close();
			return returnValue;
		}
		
		private Bool shouldProceed(Account_Id acctID) {
			
			/* START CHANGES - JHERNA - 2021-MAR-18 - SysAid#362495 */

			//Bool returnValue = Bool.TRUE;
			/*===========================================================================================*/
			/* Should only proceed if Account does not have any none closed / none canceled GPAFARP PA SA*/
			/*===========================================================================================*/
			
			StringBuilder stringBuilder = new StringBuilder();			
			stringBuilder.append("SELECT SA.SA_ID ");
			stringBuilder.append("FROM CI_SA SA ");
			stringBuilder.append("WHERE SA.ACCT_ID = :acctID ");
			stringBuilder.append("AND SA.SA_TYPE_CD = '"+parmSATypeFARPPA.trim()+"' ");
			stringBuilder.append("AND SA.SA_STATUS_FLG < '60' ");
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "===CmQuoteMonitor2Batch.shouldProceed[check if account have GPAFARP]===");
			prepState.bindId("acctID", acctID);
			prepState.setAutoclose(false);
			prepState.execute();			
			if (notNull(prepState.firstRow())) {
				//return returnValue
				logWarning(CustomMessageRepositoryMGE.commGenericError("Account "+acctID.getTrimmedValue()+" have a none closed/canceled GPAFARP PA SA. Quote will not be processed and will be expired. "));
				return Bool.FALSE;
			}			
			prepState.close();
						
			/* ***********************************************/
			/* Do not process quote and terminate program if */
			/* account is enrolled on FCAP                   */
			/* ***********************************************/
			FeatureConfiguration_Id featConfIdFcap = fcHelper.getFeatureConfiguration(ExternalSystemTypeLookup.constants.LOW_INCOME_PROGRAM_CONFIG_OPTIONS);
			String custClassFcapStr = fcHelper.getMaximumSequenceFeatureOptionValue(featConfIdFcap, CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_CUSTOMER_CLASS, Bool.TRUE);
			String collClassFcapStr = fcHelper.getMaximumSequenceFeatureOptionValue(featConfIdFcap, CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_COLLECTION_CLASS, Bool.TRUE);
			String budPlanFcapStr = fcHelper.getMaximumSequenceFeatureOptionValue(featConfIdFcap, CmLowIncomeProgramConfigurationsOptionTypeLookup.constants.FCAP_BUDGET_PLAN, Bool.TRUE);
			
			CustomerClass_Id custClassIdFCAP = new CustomerClass_Id(custClassFcapStr.trim());
			CollectionClass_Id collClassIdFCAP = new CollectionClass_Id(collClassFcapStr.trim());
			BudgetPlan_Id budPlanIdFCAP = new BudgetPlan_Id(budPlanFcapStr.trim());
												
			Account account = acctID.getEntity();
			
			CustomerClass_Id acctCustClassId = account.getCustomerClass().getId();
			CollectionClass_Id acctCollClassId = account.getCollectionClassId();
			BudgetPlan_Id acctBudPlanId = account.getBudgetPlanId();
			
			if (acctCustClassId.compareTo(custClassIdFCAP) == 0) {
				logWarning(CustomMessageRepositoryMGE.commGenericError("Account "+acctID.getTrimmedValue()+" is on "+custClassFcapStr.trim()+"  customer class. Quote will not be processed and will be expired. "));
				return Bool.FALSE;
			}
			if (acctCollClassId.compareTo(collClassIdFCAP) == 0) {
				logWarning(CustomMessageRepositoryMGE.commGenericError("Account "+acctID.getTrimmedValue()+" is on "+collClassFcapStr.trim()+"  collection class. Quote will not be processed and will be expired. "));
				return Bool.FALSE;
			}
			if (notNull(acctBudPlanId) 
					&& acctBudPlanId.compareTo(budPlanIdFCAP) == 0) {
				logWarning(CustomMessageRepositoryMGE.commGenericError("Account "+acctID.getTrimmedValue()+" is on "+budPlanFcapStr.trim()+"  budget plan. Quote will not be processed and will be expired. "));
				return Bool.FALSE;
			}
			
			return Bool.TRUE;
			//return returnValue;
			/* END CHANGES - JHERNA - 2021-MAR-18 - SysAid#362495 */			
		}

		private String getServiceTaskData(ServiceTask_Id svcTaskID, CharacteristicType_Id charTypeID) {

			String returnValue = " ";

			StringBuilder sbGetQuoteData = new StringBuilder();			  
			sbGetQuoteData.append("SELECT SRCH_CHAR_VAL ");
			sbGetQuoteData.append("FROM F1_SVC_TASK_CHAR ");
			sbGetQuoteData.append("WHERE F1_SVC_TASK_ID = :svcTaskID ");
			sbGetQuoteData.append("AND CHAR_TYPE_CD = :charTypeID ");

			PreparedStatement prepState = createPreparedStatement(sbGetQuoteData.toString(), "==CmQuoteMonitor2Batch.getServiceTaskData==");
			prepState.bindId("svcTaskID", svcTaskID);
			prepState.bindId("charTypeID", charTypeID);
			prepState.setAutoclose(false);
			prepState.execute();
			if (isNull(prepState.firstRow())) {
				prepState.close();
				// %1<object> (%2)<object id> does not contain required characteristic of type %3 
				addError(CustomMessageRepositoryMGE.commGenericObjectDoesNotContainRequiredCharacteristic("Quote/Pledge (Service Task)", svcTaskID.getTrimmedValue(), charTypeID.getTrimmedValue()));
			}

			SQLResultRow sqlRow = (SQLResultRow) prepState.firstRow();
			returnValue = sqlRow.getString("SRCH_CHAR_VAL");

			if (isBlankOrNull(returnValue)) {
				prepState.close();
				// %1<object> (%2)<object id> does not contain required characteristic of type %3 
				addError(CustomMessageRepositoryMGE.commGenericObjectDoesNotContainRequiredCharacteristic("Quote/Pledge (Service Task)", svcTaskID.getTrimmedValue(), charTypeID.getTrimmedValue()));
			}			  			
			prepState.close();
			return returnValue.trim();
		}
		
		private boolean hasMajorFundingType(DateTime creDttm, ServiceAgreement_Id saID) {

			boolean returnValue = false;
			
			List<String> listOfMajorFundingType = fcHelper.getListOfFeatureOptionValues(parmFeatConfMajorPledgeFundingType.getId(), 
					CmEligibleMajorPledgeFundingTypesLookup.constants.CM_ELIGIBLE_MAJOR_PLEDGE_FUNDING_TYPE);
			String majorFundingTypes = "";
			
			for (int x = 0; x < listOfMajorFundingType.size(); x++) {
				String fundingType = listOfMajorFundingType.get(x);
				majorFundingTypes = majorFundingTypes.trim().concat("'");
				majorFundingTypes = majorFundingTypes.trim().concat(fundingType);
				majorFundingTypes = majorFundingTypes.trim().concat("',");				
			}

			majorFundingTypes = majorFundingTypes.substring(0, (majorFundingTypes.length() - 1));
			
			StringBuilder stringBuilder = new StringBuilder();
			
			stringBuilder.append("SELECT ");
			stringBuilder.append("   ST.F1_SVC_TASK_ID ");
			stringBuilder.append("FROM ");
			stringBuilder.append("   F1_SVC_TASK ST, ");
			stringBuilder.append("   F1_SVC_TASK_CHAR STC ");
			stringBuilder.append("WHERE ST.F1_STASK_TYPE_CD = :pledgeSvcTaskType ");
			stringBuilder.append("AND ST.BO_STATUS_CD = '"+parmActiveStatusPledge.trim()+"' ");
			stringBuilder.append("AND TRUNC(ST.CRE_DTTM) >= :creDt ");
			stringBuilder.append("AND STC.F1_SVC_TASK_ID = ST.F1_SVC_TASK_ID ");
			stringBuilder.append("AND STC.CHAR_TYPE_CD = :charTypeSAID ");
			stringBuilder.append("AND STC.SRCH_CHAR_VAL = '"+saID.getTrimmedValue()+"' ");
			stringBuilder.append("AND EXISTS (SELECT 'X' ");
			stringBuilder.append("			FROM F1_SVC_TASK_CHAR STC2 ");
			stringBuilder.append("			WHERE STC2.F1_SVC_TASK_ID = ST.F1_SVC_TASK_ID ");
			stringBuilder.append("			AND STC2.CHAR_TYPE_CD = :charTypeFundingType ");
			stringBuilder.append("			AND STC2.SRCH_CHAR_VAL IN ("+majorFundingTypes+") ");
			stringBuilder.append("		     ) ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==CmQuoteMonitor2Batch.hasMajorFundingType==");
			prepState.bindId("pledgeSvcTaskType", parmSTaskTypePledge.getId());
			prepState.bindDate("creDt", creDttm.getDate());
			prepState.bindId("charTypeSAID", wCharTypeIdSAID);
			prepState.bindId("charTypeFundingType", wCharTypeIdFundingType);
			prepState.setAutoclose(false);
			prepState.execute();
			if (notNull(prepState.firstRow())) {
				returnValue = true;
			}			
			prepState.close();
			return returnValue;
		}
		
		
		private BigDecimal getDownPayment(ServiceTask_Id quoteID, String quoteSelection) {

			BigDecimal returnValue = BigDecimal.ZERO;
			// for CWR
			if (quoteSelection.trim().compareToIgnoreCase(wSelCWR.trim()) == 0) {
				// Retrieve CWR Down Payment
				String cwrDPStr = getServiceTaskData(quoteID, wCharTypeIdCWRDownPayment);
				BigDecimal cwrDP = convertStrToAmount(cwrDPStr, 2);
				// Retrieve Total Diversion
				String totDivStr = getServiceTaskData(quoteID, wCharTypeIdTotalDiversion);
				BigDecimal totDiv = convertStrToAmount(totDivStr, 2);
				// Subtract the Total Diversion from the CWR Down Payment
				returnValue = cwrDP.subtract(totDiv);
				returnValue = returnValue.setScale(2, BigDecimal.ROUND_HALF_UP);				
			}			
			// for ARP 0-50
			else if (quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_50_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_50_24.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_50_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_50_24.trim()) == 0) {
				
				String arp0_50_str = getServiceTaskData(quoteID, wCharTypeIdARP_0_50_DP);
				returnValue = convertStrToAmount(arp0_50_str, 2);
				returnValue = returnValue.setScale(2, BigDecimal.ROUND_HALF_UP);				
			}
			// for ARP 51-99
			else if (quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_99_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_99_24.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_99_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_99_24.trim()) == 0) {
				
				String arp_51_99_str = getServiceTaskData(quoteID, wCharTypeIdARP_51_99_DP);
				returnValue = convertStrToAmount(arp_51_99_str, 2);
				returnValue = returnValue.setScale(2, BigDecimal.ROUND_HALF_UP);				
			}
			// for ARP 100-125
			else if (quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_125_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_125_24.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_125_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_125_24.trim()) == 0) {
				
				String arp_100_125_str = getServiceTaskData(quoteID, wCharTypeIdARP_100_125_DP);
				returnValue = convertStrToAmount(arp_100_125_str, 2);
				returnValue = returnValue.setScale(2, BigDecimal.ROUND_HALF_UP);	
			}
			// for ARP 126-185
			else if (quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_185_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_185_24.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_185_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_185_24.trim()) == 0) {
				
				String arp_126_185_str = getServiceTaskData(quoteID, wCharTypeIdARP_126_185_DP);
				returnValue = convertStrToAmount(arp_126_185_str, 2);
				returnValue = returnValue.setScale(2, BigDecimal.ROUND_HALF_UP);				
			}
			return returnValue;
		}
		
		private BigDecimal convertStrToAmount(String value, int scale) {
			
			BigDecimal returnValue = null;
			
			if (notBlank(value)) {
				try {
					returnValue = new BigDecimal(value.trim());
					returnValue = returnValue.setScale(scale, BigDecimal.ROUND_HALF_UP);
				}
				catch (NumberFormatException nfe) {
					
					addError(CustomMessageRepositoryMGE.commGenericError(nfe.getMessage()));
				}
			}
			return returnValue;
		}
		
		private BigDecimal getPaymentsAndPledges(DateTime creDttm, ServiceAgreement_Id saID) {

			BigDecimal returnValue = BigDecimal.ZERO;
			
			/* GET TOTAL PLEDGE AMOUNT */
			
			StringBuilder sbPledgeAmt = new StringBuilder();
			
			sbPledgeAmt.append("SELECT ");
			sbPledgeAmt.append("   ST.F1_SVC_TASK_ID ");
			sbPledgeAmt.append("FROM ");
			sbPledgeAmt.append("   F1_SVC_TASK ST, ");
			sbPledgeAmt.append("   F1_SVC_TASK_CHAR STC ");
			sbPledgeAmt.append("WHERE ST.F1_STASK_TYPE_CD = :pledgeSvcTaskType ");
			sbPledgeAmt.append("AND ST.BO_STATUS_CD = '"+parmActiveStatusPledge.trim()+"' ");
			sbPledgeAmt.append("AND TRUNC(ST.CRE_DTTM) >= :creDt ");
			sbPledgeAmt.append("AND STC.F1_SVC_TASK_ID = ST.F1_SVC_TASK_ID ");
			sbPledgeAmt.append("AND STC.CHAR_TYPE_CD = :charTypeSAID ");
			sbPledgeAmt.append("AND STC.SRCH_CHAR_VAL = '"+saID.getTrimmedValue()+"' ");

			PreparedStatement psPledgeAmt = createPreparedStatement(sbPledgeAmt.toString(), "==CmQuoteMonitor2Batch.getPaymentsAndPledges.getPledgeAmount==");
			psPledgeAmt.bindId("pledgeSvcTaskType", parmSTaskTypePledge.getId());
			psPledgeAmt.bindDate("creDt", creDttm.getDate());
			psPledgeAmt.bindId("charTypeSAID", wCharTypeIdSAID);
			psPledgeAmt.setAutoclose(false);
			psPledgeAmt.execute();
			
			if (notNull(psPledgeAmt.firstRow())) {				
				Iterator<SQLResultRow> iter = psPledgeAmt.list().iterator();
				while (iter.hasNext()) {
					
					SQLResultRow sqlRow = (SQLResultRow) iter.next();
					ServiceTask_Id pledgeID = (ServiceTask_Id) sqlRow.getId("F1_SVC_TASK_ID", ServiceTask.class);
					String pledgeAmtStr = getServiceTaskData(pledgeID, wCharTypeIdPledgeAmount);
					BigDecimal pledgeAmount = convertStrToAmount(pledgeAmtStr, 2);
					pledgeAmount = pledgeAmount.setScale(2, BigDecimal.ROUND_HALF_UP);
					// Summate all pledge amount
					returnValue = returnValue.add(pledgeAmount);										
				}
			}			
			psPledgeAmt.close();
			
			/* GET PAYMENT AMOUNT */
			
			BigDecimal totPayments = BigDecimal.ZERO;
			StringBuilder sbGetPayments = new StringBuilder();
			
			sbGetPayments.append("SELECT ");
			sbGetPayments.append("   NVL(SUM(PS.PAY_SEG_AMT), 0) TOT_PS_AMT ");
			sbGetPayments.append("FROM ");
			sbGetPayments.append("   CI_PAY_SEG PS, "); 
			sbGetPayments.append("   CI_PAY PY, ");
			sbGetPayments.append("   CI_PAY_EVENT PE ");
			sbGetPayments.append("WHERE PS.SA_ID = :saID ");
			sbGetPayments.append("AND PY.PAY_ID = PS.PAY_ID ");
			sbGetPayments.append("AND PY.PAY_STATUS_FLG = '50' ");
			sbGetPayments.append("AND PE.PAY_EVENT_ID = PY.PAY_EVENT_ID ");
			sbGetPayments.append("AND PE.PAY_DT >= :payDt ");
			
			PreparedStatement psGetPayments = createPreparedStatement(sbGetPayments.toString(), "==CmQuoteMonitor2Batch.getPaymentsAndPledges.getPayments==");
			psGetPayments.bindId("saID", saID);
			psGetPayments.bindDate("payDt", creDttm.getDate());
			psGetPayments.setAutoclose(false);
			psGetPayments.execute();
			if (notNull(psGetPayments.firstRow())) {
				SQLResultRow sqlRow = (SQLResultRow) psGetPayments.firstRow();
				totPayments = sqlRow.getBigDecimal("TOT_PS_AMT");
				totPayments = totPayments.setScale(2, BigDecimal.ROUND_HALF_UP);
			}
			psGetPayments.close();
			
			/* Add the total pledge amount and the total payments */
			returnValue = returnValue.add(totPayments);
			returnValue = returnValue.setScale(2, BigDecimal.ROUND_HALF_UP);

			return returnValue;
		}
		
		private void processQuote(ServiceTask_Id quoteID, DateTime quoteCredttm, ServiceAgreement_Id saID, String quoteSelection, BigDecimal downPayment,
				BigDecimal totPayPledges, boolean hasMajorFunding) {

			if (quoteSelection.trim().compareToIgnoreCase(wSelCWR.trim()) == 0) {
				/* Process Cold Weather Rule */
				processCWR(quoteID, quoteCredttm, saID, downPayment, totPayPledges, hasMajorFunding);
				
			}
			else if (quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_50_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_50_24.trim()) == 0 
					|| quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_99_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_99_24.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_125_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_125_24.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_185_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelARP_FPL_185_24.trim()) == 0) {
				/* Process Arrearage Re-payment Program */
				processARP(quoteID, quoteCredttm, saID, downPayment, totPayPledges, quoteSelection);
			}
			else if (quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_50_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_50_24.trim()) == 0 
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_99_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_99_24.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_125_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_125_24.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_185_12.trim()) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_185_24.trim()) == 0) {
				/* Process Bill Payment Assistance Program */
				processBPAP(quoteID, quoteCredttm, saID, downPayment, totPayPledges, quoteSelection);
			}			
		}
		
		private void processCWR(ServiceTask_Id quoteID, DateTime quoteCredttm, ServiceAgreement_Id saID, BigDecimal downPayment,
				BigDecimal totPayPledges, boolean hasMajorFunding) {

			ServiceAgreement gasSA = saID.getEntity();
			Account account = gasSA.getAccount();

			// Do not proceed if customer have diversion SA with payoff amount
			if (checkDiversionSaWithPayoffAmount(account.getId())) {

				Premise_Id premID = gasSA.getPremiseId();
				/* 
				 * No longer needed because if an active Payment Arrangement SA is 
				 * found, then no processing will happen as per SA-19632				 
				// Check for existing active Payment Arrangement SA and cancel them. 
				checkExistingPASA(saID);
				*/
				
				/*========================*/
				/* Create CWR Budget Plan */
				/*========================*/
				String monthlyBudgetStr = getServiceTaskData(quoteID, wCharTypeIdMonthlyBudget);
				BigDecimal monthlyBudget = convertStrToAmount(monthlyBudgetStr, 2);
				
				Account_DTO accountDTO = account.getDTO();
				accountDTO.setBudgetPlanId(parmBudPlanCWR.getId());
				account.setDTO(accountDTO);
				
				gasSA.turnOnBudgetForServiceAgreement(wProcessDate, new Money(monthlyBudget, account.getCurrency().getId()));
				
				/*================================*/
				/* Create CWR Payment Arrangement */
				/*================================*/
				String totSaArrearsStr = getServiceTaskData(quoteID, wCharTypeIdTotalSAArrears);
				BigDecimal totSaArrears = convertStrToAmount(totSaArrearsStr, 2);
				
				synchSAsBalance(gasSA);
				
				// START CHANGES - JHERNA - 2019-08-28 - SysAid#303672
				
				/*
				 * New formula to determine debt to transfer is
				 * debt to transfer = total SA arrears - total pay pledges
				 * 
				// Computer for debt to transfer = total SA arrears - down payment
				BigDecimal debtToTransfer = totSaArrears.subtract(downPayment);
				
				if (hasMajorFunding) {
					debtToTransfer = debtToTransfer.add(downPayment);
					debtToTransfer = debtToTransfer.subtract(totPayPledges);
					debtToTransfer = debtToTransfer.setScale(2, BigDecimal.ROUND_HALF_UP);					
				}
				*/	
				
				BigDecimal debtToTransfer = totSaArrears.subtract(totPayPledges);
				debtToTransfer = debtToTransfer.setScale(2, BigDecimal.ROUND_HALF_UP);	
				
				// END CHANGES - JHERNA - 2019-08-28 - SysAid#303672
				
				/* Do not transfer more amount to PA SA as this will lead the SA balance to go negative (credit) */
				ServiceAgreementBalanceData saBalanceData = gasSA.getFinancialBalances();
				BigDecimal saCurrentAmount = saBalanceData.getCurrentAmount().getAmount();
				BigDecimal saPayoffAmount = saBalanceData.getTotalAmount().getAmount();
				if (saPayoffAmount.compareTo(debtToTransfer) < 0) {
					debtToTransfer = saPayoffAmount;
				}
				
				/* proceed only if there is debt to transfer */
				if (debtToTransfer.compareTo(BigDecimal.ZERO) > 0) {
					// Compute recurring charge amount
					BigDecimal recChargeAmt = debtToTransfer.divide(BigDecimal.valueOf(12));
					recChargeAmt = recChargeAmt.setScale(2, BigDecimal.ROUND_HALF_UP);
					
					// Use the base business service "C1-CreatePaymentArrangement" to create a payment arrangement
					BusinessServiceInstance bsInstance = BusinessServiceInstance.create("CM-CreatePaymentArrangement");
					// populate schema elements
					cmPopulateSchemaElements(bsInstance, "accountId", account.getId().getTrimmedValue());
					cmPopulateSchemaElements(bsInstance, "cisDivision", gasSA.getServiceAgreementType().fetchIdDivision().getId().getTrimmedValue());
					cmPopulateSchemaElements(bsInstance, "saType", parmSATypeCWRPA.trim());		
					cmPopulateSchemaElements(bsInstance, "create", Bool.TRUE);
					cmPopulateSchemaElements(bsInstance, "PASACollection", gasSA, saCurrentAmount.toString().trim(), saPayoffAmount.toString().trim());
					cmPopulateSchemaElements(bsInstance, "paNewTotAmt", debtToTransfer); 				
					cmPopulateSchemaElements(bsInstance, "recurringChargeAmount", recChargeAmt.toString().trim());
					
					BusinessServiceInstance outputBsInstance = cmCallBusinessService(bsInstance);
					String paSAIDStr = cmGetSchemaElement(outputBsInstance, "paSaId");
					
					if (isBlankOrNull(paSAIDStr)
							|| isNull(new ServiceAgreement_Id(paSAIDStr.trim()).getEntity())) {
						addError(CustomMessageRepositoryMGE.commGenericError("CWR PA SA was not created."));
					}
					
					ServiceAgreement cwrPASA = new ServiceAgreement_Id(paSAIDStr.trim()).getEntity();
					String cwrLevel = getServiceTaskData(quoteID, wCharTypeIdCWRLevel);
					// Add CWR Level Characteristic on the new PA SA
					addSaChar(wProcessDate, cwrPASA.getId(), parmCharTypeCWRLevel.getId(), cwrLevel);
					// Add Quote ID Characteristic on the new PA SA
					addSaChar(wProcessDate, cwrPASA.getId(), parmCharTypeQuoteSource.getId(), quoteID.getTrimmedValue());
					// Add Premise ID Characteristic on the new PA SA
					addSaChar(wProcessDate, cwrPASA.getId(), parmCharTypePremiseId.getId(), gasSA.getPremiseId().getTrimmedValue());															
				}
				
				/*=============================*/
				/* Check for Active Deposit SA */
				/*=============================*/
				processDepositSA(account.getId(), premID);
				/*==================*/
				/* Expire the Quote */
				/*==================*/				
				// Retrieve the Quote BO Instance											
				BusinessObjectInstance boInstance = BusinessObjectInstance.create(wBusinessObjectIDQuote.getEntity());
				boInstance.setXMLString("serviceTaskId", quoteID.getTrimmedValue());
				
				BusinessObjectInstance quoteBO = BusinessObjectDispatcher.read(boInstance);
				quoteBO.setXMLString("status", parmExpiredStatusQuote.trim());
				
				BusinessObjectDispatcher.update(quoteBO);
								
				/*==========================*/
				/* Delete SA Characteristic */
				/*==========================*/
				deleteSACharacteristic(gasSA, parmCharTypeHasQuote);
			}			
		}
		
		private void processARP(ServiceTask_Id quoteID, DateTime quoteCredttm, ServiceAgreement_Id saID, 
				BigDecimal downPayment, BigDecimal totPayPledges, String quoteSelection) {
			
			ServiceAgreement gasSA = saID.getEntity();
			Account account = gasSA.getAccount();
			Premise_Id premID = gasSA.getPremiseId();
			
			/* 
			 * No longer needed because if an active Payment Arrangement SA is 
			 * found, then no processing will happen as per SA-19632				 
			// Check for existing active Payment Arrangement SA and cancel them. 
			checkExistingPASA(saID);
			*/
			
			/*====================*/
			/* Create Budget Plan */
			/*====================*/
			String monthlyBudgetStr = getServiceTaskData(quoteID, wCharTypeIdMonthlyBudget);
			BigDecimal monthlyBudget = convertStrToAmount(monthlyBudgetStr, 2);
			
			Account_DTO accountDTO = account.getDTO();
			accountDTO.setBudgetPlanId(parmBudPlanLow.getId());
			account.setDTO(accountDTO);
			
			gasSA.turnOnBudgetForServiceAgreement(wProcessDate, new Money(monthlyBudget, account.getCurrency().getId()));
			
			/*================================*/
			/* Create ARP Payment Arrangement */
			/*================================*/
			String totSaArrearsStr = getServiceTaskData(quoteID, wCharTypeIdTotalSAArrears);
			BigDecimal totSaArrears = convertStrToAmount(totSaArrearsStr, 2);
			
			synchSAsBalance(gasSA);
			
			// Computer for debt to transfer = total SA arrears - down payment
			BigDecimal debtToTransfer = totSaArrears.subtract(downPayment);
			debtToTransfer = debtToTransfer.add(downPayment);
			debtToTransfer = debtToTransfer.subtract(totPayPledges);
			debtToTransfer = debtToTransfer.setScale(2, BigDecimal.ROUND_HALF_UP);				

			// Get Diversion SAs
			List<ServiceAgreement_Id> listOfDivSAID = new ArrayList<ServiceAgreement_Id>();
			Iterator<SQLResultRow> iterDivSA = getDiversionSAsForARP(account.getId());
			while (iterDivSA.hasNext()) {
				SQLResultRow sqlRow = iterDivSA.next();
				ServiceAgreement_Id divSAID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
				ServiceAgreement divSA = divSAID.getEntity();
				BigDecimal divSAPayoffAmount = divSA.getPayoffBalance().getAmount().setScale(2, BigDecimal.ROUND_HALF_UP);
				
				if (divSAPayoffAmount.compareTo(BigDecimal.ZERO) > 0) {
					listOfDivSAID.add(divSAID);
					debtToTransfer = debtToTransfer.add(divSAPayoffAmount);
					debtToTransfer = debtToTransfer.setScale(2, BigDecimal.ROUND_HALF_UP);
				}			
			}
			
			// Determine Number of installment / Recurring Charge Amount
			BigDecimal recurringCharge = BigDecimal.ZERO;
			if (quoteSelection.trim().equalsIgnoreCase(wSelARP_FPL_50_24)
					|| quoteSelection.trim().equalsIgnoreCase(wSelARP_FPL_99_24)
					|| quoteSelection.trim().equalsIgnoreCase(wSelARP_FPL_125_24)
					|| quoteSelection.trim().equalsIgnoreCase(wSelARP_FPL_185_24)) {
				
				recurringCharge  = debtToTransfer.divide(BigDecimal.valueOf(48));
				recurringCharge = recurringCharge.setScale(2, BigDecimal.ROUND_HALF_UP);				
			}
			else {
				recurringCharge  = debtToTransfer.divide(BigDecimal.valueOf(24));
				recurringCharge = recurringCharge.setScale(2, BigDecimal.ROUND_HALF_UP);				
			}
			
			/* proceed only if there is debt to transfer */
			if (debtToTransfer.compareTo(BigDecimal.ZERO) > 0) {
				
				// Use the base business service "C1-CreatePaymentArrangement" to create a payment arrangement
				BusinessServiceInstance bsInstance = BusinessServiceInstance.create("CM-CreatePaymentArrangement");
				// populate schema elements
				cmPopulateSchemaElements(bsInstance, "accountId", account.getId().getTrimmedValue());
				cmPopulateSchemaElements(bsInstance, "cisDivision", gasSA.getServiceAgreementType().fetchIdDivision().getId().getTrimmedValue());
				cmPopulateSchemaElements(bsInstance, "saType", parmSATypeARPPA.trim());		
				cmPopulateSchemaElements(bsInstance, "create", Bool.TRUE);				
				cmPopulateSchemaElements(bsInstance, "PASACollection", gasSA, listOfDivSAID.iterator());				
				cmPopulateSchemaElements(bsInstance, "paNewTotAmt", debtToTransfer); 				
				cmPopulateSchemaElements(bsInstance, "recurringChargeAmount", recurringCharge.toString().trim());
				
				BusinessServiceInstance outputBsInstance = cmCallBusinessService(bsInstance);
				String paSAIDStr = cmGetSchemaElement(outputBsInstance, "paSaId");
				
				if (isBlankOrNull(paSAIDStr)
						|| isNull(new ServiceAgreement_Id(paSAIDStr.trim()).getEntity())) {
					addError(CustomMessageRepositoryMGE.commGenericError("ARP PA SA was not created."));
				}
				
				ServiceAgreement arpPASA = new ServiceAgreement_Id(paSAIDStr.trim()).getEntity();
				// Add Quote ID Characteristic on the new PA SA
				addSaChar(wProcessDate, arpPASA.getId(), parmCharTypeQuoteSource.getId(), quoteID.getTrimmedValue());				
			}
			
			/*=============================*/
			/* Check for Active Deposit SA */
			/*=============================*/
			processDepositSA(account.getId(), premID);
			
			/*==================*/
			/* Expire the Quote */
			/*==================*/				
			// Retrieve the Quote BO Instance							
			BusinessObjectInstance boInstance = BusinessObjectInstance.create(wBusinessObjectIDQuote.getEntity());
			boInstance.setXMLString("serviceTaskId", quoteID.getTrimmedValue());
			
			BusinessObjectInstance quoteBO = BusinessObjectDispatcher.read(boInstance);
			quoteBO.setXMLString("status", parmExpiredStatusQuote.trim());
			
			BusinessObjectDispatcher.update(quoteBO);
			
			/*==========================*/
			/* Delete SA Characteristic */
			/*==========================*/
			deleteSACharacteristic(gasSA, parmCharTypeHasQuote);			
		}
		
		private void processBPAP(ServiceTask_Id quoteID, DateTime quoteCredttm, ServiceAgreement_Id saID, 
				BigDecimal downPayment, BigDecimal totPayPledges, String quoteSelection) {
			
			ServiceAgreement gasSA = saID.getEntity();
			Account account = gasSA.getAccount();
			Premise_Id premID = gasSA.getPremiseId();
			
			/* 
			 * No longer needed because if an active Payment Arrangement SA is 
			 * found, then no processing will happen as per SA-19632				 
			// Check for existing active Payment Arrangement SA and cancel them. 
			checkExistingPASA(saID);
			*/
			
			/*====================*/
			/* Create Budget Plan */
			/*====================*/
			String bpapCredit = " ";
			CharacteristicType_Id charTypeIDToGetBudgetAmount = null;
			
			if (quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_50_12) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_50_24) == 0) {
				charTypeIDToGetBudgetAmount = wCharTypeIdBPAP_0_50_MonthlyBudget;
				bpapCredit = wCredBPAP_0_50;
			} else if (quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_99_12) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_99_24) == 0) {
				charTypeIDToGetBudgetAmount = wCharTypeIdBPAP_51_99_MonthlyBudget;
				bpapCredit = wCredBPAP_51_99;
			} else if (quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_125_12) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_125_24) == 0) {
				charTypeIDToGetBudgetAmount = wCharTypeIdBPAP_100_125_MonthlyBudget;
				bpapCredit = wCredBPAP_100_125;
			} else if (quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_185_12) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_185_24) == 0) {
				charTypeIDToGetBudgetAmount = wCharTypeIdBPAP_126_185_MonthlyBudget;
				bpapCredit = wCredBPAP_126_185;
			}
			
			String monthlyBudgetStr = getServiceTaskData(quoteID, charTypeIDToGetBudgetAmount);
			BigDecimal monthlyBudget = convertStrToAmount(monthlyBudgetStr, 2);
			
			Account_DTO accountDTO = account.getDTO();
			accountDTO.setBudgetPlanId(parmBudPlanLow.getId());
			account.setDTO(accountDTO);
			
			gasSA.turnOnBudgetForServiceAgreement(wProcessDate, new Money(monthlyBudget, account.getCurrency().getId()));
			
			/*=============================================*/
			/* Create BPAP Credit Characteristic on the SA */
			/*=============================================*/
			addSaChar(wProcessDate, saID, parmCharTypeBPAPCred.getId(), bpapCredit);
			
			Date futureEffDt = wProcessDate;
			if (quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_50_24) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_99_24) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_125_24) == 0
					|| quoteSelection.trim().compareToIgnoreCase(wSelBPAP_FPL_185_24) == 0) {				
				futureEffDt = futureEffDt.addMonths(CM_CONST_BPAP_CRED_MNTH_PERIOD.intValue());
			} else {
				futureEffDt = futureEffDt.addMonths(CM_CONST_BPAP_CRED_1YR.intValue());				
			}
			addSaChar(futureEffDt, saID, parmCharTypeBPAPCred.getId(), "0");
			
			/*================================*/
			/* Create BPAP Payment Arrangement */
			/*================================*/
			String totSaArrearsStr = getServiceTaskData(quoteID, wCharTypeIdTotalSAArrears);
			BigDecimal totSaArrears = convertStrToAmount(totSaArrearsStr, 2);
			
			synchSAsBalance(gasSA);
			
			BigDecimal debtToTransfer = totSaArrears.subtract(downPayment);
			debtToTransfer = debtToTransfer.add(totPayPledges);
			debtToTransfer = debtToTransfer.setScale(2, BigDecimal.ROUND_HALF_UP);
			
			// Get Diversion SAs
			List<ServiceAgreement_Id> listOfDivSAID = new ArrayList<ServiceAgreement_Id>();
			Iterator<SQLResultRow> iterDivSA = getDiversionSAsForARP(account.getId());
			while (iterDivSA.hasNext()) {
				SQLResultRow sqlRow = iterDivSA.next();
				ServiceAgreement_Id divSAID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
				ServiceAgreement divSA = divSAID.getEntity();
				BigDecimal divSAPayoffAmount = divSA.getPayoffBalance().getAmount().setScale(2, BigDecimal.ROUND_HALF_UP);

				if (divSAPayoffAmount.compareTo(BigDecimal.ZERO) > 0) {
					listOfDivSAID.add(divSAID);
					debtToTransfer = debtToTransfer.add(divSAPayoffAmount);
					debtToTransfer = debtToTransfer.setScale(2, BigDecimal.ROUND_HALF_UP);
				}				
			}
			
			// Determine Number of installment / Recurring Charge Amount
			BigDecimal recurringCharge = BigDecimal.ZERO;
			if (quoteSelection.trim().equalsIgnoreCase(wSelBPAP_FPL_50_24)
					|| quoteSelection.trim().equalsIgnoreCase(wSelBPAP_FPL_99_24)
					|| quoteSelection.trim().equalsIgnoreCase(wSelBPAP_FPL_125_24)
					|| quoteSelection.trim().equalsIgnoreCase(wSelBPAP_FPL_185_24)) {

				recurringCharge  = debtToTransfer.divide(BigDecimal.valueOf(48));
				recurringCharge = recurringCharge.setScale(2, BigDecimal.ROUND_HALF_UP);				
			}
			else {
				recurringCharge  = debtToTransfer.divide(BigDecimal.valueOf(24));
				recurringCharge = recurringCharge.setScale(2, BigDecimal.ROUND_HALF_UP);				
			}
			
			/* proceed only if there is debt to transfer */
			if (debtToTransfer.compareTo(BigDecimal.ZERO) > 0) {
				
				// Use the base business service "C1-CreatePaymentArrangement" to create a payment arrangement
				BusinessServiceInstance bsInstance = BusinessServiceInstance.create("CM-CreatePaymentArrangement");
				// populate schema elements
				cmPopulateSchemaElements(bsInstance, "accountId", account.getId().getTrimmedValue());
				cmPopulateSchemaElements(bsInstance, "cisDivision", gasSA.getServiceAgreementType().fetchIdDivision().getId().getTrimmedValue());
				cmPopulateSchemaElements(bsInstance, "saType", parmSATypeARPPA.trim());		
				cmPopulateSchemaElements(bsInstance, "create", Bool.TRUE);				
				cmPopulateSchemaElements(bsInstance, "PASACollection", gasSA, listOfDivSAID.iterator());				
				cmPopulateSchemaElements(bsInstance, "paNewTotAmt", debtToTransfer); 				
				cmPopulateSchemaElements(bsInstance, "recurringChargeAmount", recurringCharge.toString().trim());
				
				BusinessServiceInstance outputBsInstance = cmCallBusinessService(bsInstance);
				String paSAIDStr = cmGetSchemaElement(outputBsInstance, "paSaId");
				
				if (isBlankOrNull(paSAIDStr)
						|| isNull(new ServiceAgreement_Id(paSAIDStr.trim()).getEntity())) {
					addError(CustomMessageRepositoryMGE.commGenericError("ARP (BPAP) PA SA was not created."));
				}
				
				ServiceAgreement arpPASA = new ServiceAgreement_Id(paSAIDStr.trim()).getEntity();
				// Add Quote ID Characteristic on the new PA SA
				addSaChar(wProcessDate, arpPASA.getId(), parmCharTypeQuoteSource.getId(), quoteID.getTrimmedValue());						
			}
			
			/*=============================*/
			/* Check for Active Deposit SA */
			/*=============================*/
			processDepositSA(account.getId(), premID);
			
			/*==================*/
			/* Expire the Quote */
			/*==================*/				
			// Retrieve the Quote BO Instance				
			BusinessObjectInstance boInstance = BusinessObjectInstance.create(wBusinessObjectIDQuote.getEntity());
			boInstance.setXMLString("serviceTaskId", quoteID.getTrimmedValue());
			
			BusinessObjectInstance quoteBO = BusinessObjectDispatcher.read(boInstance);
			quoteBO.setXMLString("status", parmExpiredStatusQuote.trim());
			
			BusinessObjectDispatcher.update(quoteBO);
			
			/*==========================*/
			/* Delete SA Characteristic */
			/*==========================*/
			deleteSACharacteristic(gasSA, parmCharTypeHasQuote);				
		}
		
		private Iterator<SQLResultRow> getDiversionSAsForARP(Account_Id acctID) {
			
			List<String> listOfDiversionSATypes = fcHelper.getListOfFeatureOptionValues(parmFeatConfDiversionSA.getId(), 
					CmDiversionSaTypesLookup.constants.DIVERSION_SA_TYPE);
			String diversionSATypes = "";
			
			for (int x = 0; x < listOfDiversionSATypes.size(); x++) {
				String diversionSA = listOfDiversionSATypes.get(x);
				diversionSATypes = diversionSATypes.trim().concat("'");
				diversionSATypes = diversionSATypes.trim().concat(diversionSA);
				diversionSATypes = diversionSATypes.trim().concat("',");				
			}
			
			diversionSATypes = diversionSATypes.substring(0, (diversionSATypes.length() - 1));
			
			StringBuilder stringBuilder = new StringBuilder();
			
			stringBuilder.append("SELECT ");
			stringBuilder.append("   SA.SA_ID ");
			stringBuilder.append("FROM ");
			stringBuilder.append("   CI_SA SA ");
			stringBuilder.append("WHERE SA.ACCT_ID = :acctID ");
			stringBuilder.append("AND SA.SA_STATUS_FLG IN (:active, :pendingStop, :stopped, :reactivated) ");
			stringBuilder.append("AND SA.SA_TYPE_CD IN ("+diversionSATypes+") ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==CmQuoteMonitor2Batch.getDiversionSAsForARP==");
			prepState.bindId("acctID", acctID);
			prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
			prepState.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
			prepState.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
			prepState.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
			prepState.setAutoclose(false);
			prepState.execute();
			Iterator<SQLResultRow> returnValue = prepState.list().iterator();
			prepState.close();
			return returnValue;
		}
		
		private boolean checkDiversionSaWithPayoffAmount(Account_Id accountID) {
			
			boolean returnValue = true;
			
			List<String> listOfDiversionSATypes = fcHelper.getListOfFeatureOptionValues(parmFeatConfDiversionSA.getId(), 
					CmDiversionSaTypesLookup.constants.DIVERSION_SA_TYPE);
			String diversionSATypes = "";
			BigDecimal diversionSAPayoffAmount = BigDecimal.ZERO;
			
			for (int x = 0; x < listOfDiversionSATypes.size(); x++) {
				String diversionSA = listOfDiversionSATypes.get(x);
				diversionSATypes = diversionSATypes.trim().concat("'");
				diversionSATypes = diversionSATypes.trim().concat(diversionSA);
				diversionSATypes = diversionSATypes.trim().concat("',");				
			}
			
			diversionSATypes = diversionSATypes.substring(0, (diversionSATypes.length() - 1));
			
			StringBuilder sbDivSA = new StringBuilder();
			// original SQL from CMPQMBPN does not have any sa status check
			sbDivSA.append("SELECT ");
			sbDivSA.append("   SA.SA_ID ");
			sbDivSA.append("FROM ");
			sbDivSA.append("   CI_SA SA ");
			sbDivSA.append("WHERE SA.ACCT_ID = :accountID ");
			sbDivSA.append("AND SA.SA_TYPE_CD IN ("+diversionSATypes+") ");
			
			PreparedStatement psDivSA = createPreparedStatement(sbDivSA.toString(), "==CmQuoteMonitor2Batch.hasDiversionSA==");
			psDivSA.bindId("accountID", accountID);
			psDivSA.setAutoclose(false);
			psDivSA.execute();
			
			if (notNull(psDivSA.firstRow())) {
				
				Iterator<SQLResultRow> iter = psDivSA.list().iterator();
				while (iter.hasNext()) {
					SQLResultRow sqlRow = iter.next();
					ServiceAgreement_Id diversionSAID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
					ServiceAgreement diversionSA = diversionSAID.getEntity();
					ServiceAgreementBalanceData saBalanceData = diversionSA.getFinancialBalances();
					diversionSAPayoffAmount = saBalanceData.getTotalAmount().getAmount().setScale(2, BigDecimal.ROUND_HALF_UP);	
					
					if (diversionSAPayoffAmount.compareTo(BigDecimal.ZERO) > 0) {
						returnValue = false;
						break;
					}
				}
			}			
			psDivSA.close();			
			return returnValue;
		}
			
		private void addSaChar(Date effectiveDate, ServiceAgreement_Id saID, CharacteristicType_Id charTypeID, String charVal) {
			
			if (notBlank(charVal)) {
				CharacteristicTypeLookup charTypeLookup = charTypeID.getEntity().getCharacteristicType();
				ServiceAgreementCharacteristic_Id saCharID = new ServiceAgreementCharacteristic_Id(saID, charTypeID, effectiveDate);
				if (isNull(saCharID.getEntity())) {
					// create new
					ServiceAgreementCharacteristic_DTO saCharDTO = new ServiceAgreementCharacteristic_DTO();
					if (charTypeLookup.isAdhocValue()
							|| charTypeLookup.isFileLocationValue()) {
						saCharDTO.setAdhocCharacteristicValue(charVal.trim());
					}
					else if (charTypeLookup.isForeignKeyValue()) {
						saCharDTO.setCharacteristicValueForeignKey1(charVal.trim());
					}
					else {
						saCharDTO.setCharacteristicValue(charVal.trim());
					}
					saCharDTO.setId(saCharID);
					saCharDTO.newEntity();
				}
				else {
					// update
					ServiceAgreementCharacteristic saChar = saCharID.getEntity();
					ServiceAgreementCharacteristic_DTO saCharDTO = saChar.getDTO();
					if (charTypeLookup.isAdhocValue()
							|| charTypeLookup.isFileLocationValue()) {
						saCharDTO.setAdhocCharacteristicValue(charVal.trim());
					}
					else if (charTypeLookup.isForeignKeyValue()) {
						saCharDTO.setCharacteristicValueForeignKey1(charVal.trim());
					}
					else {
						saCharDTO.setCharacteristicValue(charVal.trim());
					}
					saChar.setDTO(saCharDTO);					
				}
			}
		}
		
		private void deleteSACharacteristic(ServiceAgreement serviceAgreement, CharacteristicType characteristicType) {
			
			// Check if a characteristic of the type exists and remove them			
			ServiceAgreementCharacteristics saChars = serviceAgreement.getCharacteristics();
			if (notNull(saChars)) {
				Iterator<ServiceAgreementCharacteristic> saCharIter = saChars.iterator();
				while (saCharIter.hasNext()) {
					ServiceAgreementCharacteristic saChar = saCharIter.next();
					CharacteristicType saCharType = saChar.fetchIdCharacteristicType();
					if (saCharType.equals(characteristicType)) {
						saCharIter.remove();
					}
				}
			}			
		}
		
		@SuppressWarnings("unused")
		private void processDepositSA(Account_Id acctID, Premise_Id premID) {
			
			StringBuilder stringBuilder = new StringBuilder();
			
			stringBuilder.append("SELECT ");
			stringBuilder.append("   SA.SA_ID ");
			stringBuilder.append("FROM ");
			stringBuilder.append("   CI_SA SA, ");
			stringBuilder.append("   CI_SA_TYPE SAT ");
			stringBuilder.append("WHERE SA.ACCT_ID = :acctID ");
			stringBuilder.append("AND SA.CHAR_PREM_ID = :premID ");
			stringBuilder.append("AND SA.SA_STATUS_FLG IN (:active, :pendingStop, :stopped, :reactivated) ");
			stringBuilder.append("AND SAT.CIS_DIVISION = SA.CIS_DIVISION ");
			stringBuilder.append("AND SAT.SA_TYPE_CD = SA.SA_TYPE_CD ");
			stringBuilder.append("AND SAT.SPECIAL_ROLE_FLG = :specialRoleCashDeposit ");
			
			PreparedStatement prepState = createPreparedStatement(stringBuilder.toString(), "==CmQUoteMonitor2Batch.processDepositSA==");
			
			prepState.bindId("acctID", acctID);
			prepState.bindId("premID", premID);
			prepState.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
			prepState.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
			prepState.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
			prepState.bindLookup("reactivated", ServiceAgreementStatusLookup.constants.REACTIVATED);
			prepState.bindLookup("specialRoleCashDeposit", SpecialRoleLookup.constants.CASH_DEPOSIT);
			prepState.setAutoclose(false);
			prepState.execute();
			
			if (notNull(prepState.firstRow())) {
				
				Iterator<SQLResultRow> iter =  prepState.list().iterator();
				while (iter.hasNext()) {
					SQLResultRow sqlRow = iter.next();
					ServiceAgreement_Id depositSAID = (ServiceAgreement_Id) sqlRow.getId("SA_ID", ServiceAgreement.class);
					ServiceAgreement depositSA = depositSAID.getEntity();
					ServiceAgreementBalanceData depositSABalance = depositSA.getFinancialBalances();
					BigDecimal depositSATotalAmt = depositSABalance.getTotalAmount().getAmount();
					if (depositSATotalAmt.compareTo(BigDecimal.ZERO) == 0) {						
						// (Initiate) Stop the Deposit SA
						depositSA.initiateStop(wProcessDate, premID, wContextUser.getFullName().trim(), StopReasonLookup.constants.SYSTEM_GENERATED, null, null);
					}
					else {
						
						// Compute for Total To Bill Amount (negate the value of deposit SA Total Amount)
						Currency_Id currencyID = acctID.getEntity().getCurrency().getId();
						BigDecimal totalToBill = depositSATotalAmt.negate();
						ServiceAgreement_DTO depositSADTO = depositSA.getDTO();
						depositSADTO.setTotalAmountToBill(new Money(totalToBill, currencyID));
						depositSA.setDTO(depositSADTO);
						
						BigDecimal depositSACurAmt = depositSABalance.getCurrentAmount().getAmount();
						if (depositSACurAmt.compareTo(BigDecimal.ZERO) != 0) {
							/*Zero out the current amount of the deposit SA*/
							CreateFrozenAdjustmentData adjData = CreateFrozenAdjustmentData.Factory.newInstance();
														
							adjData.setServiceAgreement(depositSA);
							adjData.setAdjustmentType(parmAdjTypeZero);
							adjData.setAdjustmentAmount(new Money(depositSACurAmt.negate(), currencyID));
							adjData.setAllowZeroAmount(Bool.FALSE);
							adjData.setAdjustmentDate(wProcessDate);
							
							CreateFrozenAdjustment frozenAdjustment = CreateFrozenAdjustment.Factory.newInstance();
							CreateFrozenAdjustmentData newAdjustmentData = frozenAdjustment.createFrozenAdjustment(adjData);
							Adjustment newAdjustment = newAdjustmentData.getAdjustment();
						}
					}					
				}
			}			
			prepState.close();
		}
		
		@SuppressWarnings("rawtypes")
		private void cmPopulateSchemaElements(BusinessServiceInstance bsInstance, String elementName, String value) {
			COTSFieldDataAndMD element = bsInstance.getFieldAndMD(elementName);
			element.setXMLValue(value);
		}
		
		@SuppressWarnings({ "rawtypes", "unchecked" })
		private void cmPopulateSchemaElements(BusinessServiceInstance bsInstance, String elementName, Bool value) {
			COTSFieldDataAndMD element = bsInstance.getFieldAndMD(elementName);
			element.setValue(value);				
		}
		
		@SuppressWarnings({ "rawtypes", "unchecked" })
		private void cmPopulateSchemaElements(BusinessServiceInstance bsInstance, String elementName, BigDecimal value) {
			COTSFieldDataAndMD element = bsInstance.getFieldAndMD(elementName);
			element.setValue(value);				
		}	
		
		@SuppressWarnings({ "rawtypes", "unchecked" })
		private void cmPopulateSchemaElements(BusinessServiceInstance bsInstance,
				String listName,
				ServiceAgreement gasSA,
				String currentAmount,
				String totalAmount) {

			BigDecimal summCandidateSaArrearsAmt = BigDecimal.ZERO;
			
			COTSInstanceList pasaCollection = bsInstance.getList(listName);
			COTSInstanceListNode newPasa = pasaCollection.newChild();
			
			COTSFieldDataAndMD saElement = newPasa.getFieldAndMD("saId");
			saElement.setXMLValue(gasSA.getId().getTrimmedValue());
			COTSFieldDataAndMD curAmtElement = newPasa.getFieldAndMD("currentAmount");
			curAmtElement.setXMLValue(currentAmount);
			COTSFieldDataAndMD totAmtElement = newPasa.getFieldAndMD("totalAmount");
			totAmtElement.setXMLValue(totalAmount);								
			
			summCandidateSaArrearsAmt = gasSA.getCurrentBalance().getAmount();
			
			COTSInstanceList saArrears = newPasa.getList("saArrears");
			COTSInstanceListNode newSaArrear = saArrears.newChild();
			
			COTSFieldDataAndMD saArrearSaIdElement = newSaArrear.getFieldAndMD("saId");
			saArrearSaIdElement.setXMLValue(gasSA.getId().getTrimmedValue());
					
			COTSFieldDataAndMD saArrearAmountElement = newSaArrear.getFieldAndMD("arrearsAmount");
			saArrearAmountElement.setXMLValue(summCandidateSaArrearsAmt.toString().trim());
			
			COTSFieldDataAndMD checkedForPAElement = newSaArrear.getFieldAndMD("checkedForPA");
			checkedForPAElement.setValue(Bool.TRUE);
		}

		@SuppressWarnings({ "rawtypes", "unchecked" })
		private void cmPopulateSchemaElements(BusinessServiceInstance bsInstance,
				String listName,
				ServiceAgreement gasSA,
				Iterator<ServiceAgreement_Id> collOfDiversionSAIDs) {
			
			ServiceAgreementBalanceData gasSABalanceData = gasSA.getFinancialBalances();
			
			COTSInstanceList pasaCollection = bsInstance.getList(listName);
			COTSInstanceListNode newPasa = pasaCollection.newChild();

			/* For main Gas SA*/
			COTSFieldDataAndMD saElement = newPasa.getFieldAndMD("saId");
			saElement.setXMLValue(gasSA.getId().getTrimmedValue());
			COTSFieldDataAndMD curAmtElement = newPasa.getFieldAndMD("currentAmount");
			curAmtElement.setXMLValue(gasSABalanceData.getCurrentAmount().getAmount().toString().trim());
			COTSFieldDataAndMD totAmtElement = newPasa.getFieldAndMD("totalAmount");
			totAmtElement.setXMLValue(gasSABalanceData.getTotalAmount().getAmount().toString().trim());											
			
			COTSInstanceList saArrears = newPasa.getList("saArrears");
			COTSInstanceListNode newSaArrear = saArrears.newChild();
			
			COTSFieldDataAndMD saArrearSaIdElement = newSaArrear.getFieldAndMD("saId");
			saArrearSaIdElement.setXMLValue(gasSA.getId().getTrimmedValue());

			COTSFieldDataAndMD saArrearAmountElement = newSaArrear.getFieldAndMD("arrearsAmount");
			saArrearAmountElement.setXMLValue(gasSA.getCurrentBalance().getAmount().toString().trim());
			
			COTSFieldDataAndMD checkedForPAElement = newSaArrear.getFieldAndMD("checkedForPA");
			checkedForPAElement.setValue(Bool.TRUE);
			
			/* For Diversion SAs */			
			while (collOfDiversionSAIDs.hasNext()) {
				
				ServiceAgreement_Id diversionSAID = collOfDiversionSAIDs.next();
				ServiceAgreement diversionSA = diversionSAID.getEntity();
									
				COTSInstanceList divSAArrears = newPasa.getList("saArrears");
				COTSInstanceListNode newDivSaArrear = divSAArrears.newChild();
				
				COTSFieldDataAndMD divSAArrearSaIdElement = newDivSaArrear.getFieldAndMD("saId");
				divSAArrearSaIdElement.setXMLValue(diversionSAID.getTrimmedValue());

				COTSFieldDataAndMD divSAArrearAmountElement = newDivSaArrear.getFieldAndMD("arrearsAmount");
				divSAArrearAmountElement.setXMLValue(diversionSA.getCurrentBalance().getAmount().toString().trim());
				
				COTSFieldDataAndMD checkedForPAElementDivSA = newDivSaArrear.getFieldAndMD("checkedForPA");
				checkedForPAElementDivSA.setValue(Bool.TRUE);								
			}			
		}
		
		private BusinessServiceInstance cmCallBusinessService(BusinessServiceInstance bsInstance) {
			return BusinessServiceDispatcher.execute(bsInstance);
		}
		
		@SuppressWarnings("rawtypes")
		private String cmGetSchemaElement(BusinessServiceInstance outputBsInstance, String elementName) {
			
			String returnValue = " ";
			COTSFieldDataAndMD element = outputBsInstance.getFieldAndMD(elementName);
			if (notNull(element)) {
				returnValue = element.getXMLValue();
			}
			return returnValue;
		}
		
		private Adjustment synchSAsBalance(ServiceAgreement sa) {
			
			Adjustment returnValue = null;
			
			CreateFrozenAdjustmentData inputData = CreateFrozenAdjustmentData.Factory.newInstance();
			inputData.setSynchNecessary(Bool.TRUE);		
			inputData.setServiceAgreement(sa);
			inputData.setAdjustmentType(sa.getServiceAgreementType().fetchAdjustmentTypeSynchCurrent());		
			inputData.setAdjustmentDate(wProcessDate);
			inputData.setCalculationDate(wProcessDate);
			inputData.setArrearsDate(wProcessDate);
			inputData.setAllowZeroAmount(Bool.FALSE);
			inputData.setTransferServiceAgreement(null);
			
			CreateFrozenAdjustmentData outputData = sa.createFrozenAdjustment(inputData);
			returnValue = outputData.getAdjustment();		
			return returnValue;
		}
	}
}
