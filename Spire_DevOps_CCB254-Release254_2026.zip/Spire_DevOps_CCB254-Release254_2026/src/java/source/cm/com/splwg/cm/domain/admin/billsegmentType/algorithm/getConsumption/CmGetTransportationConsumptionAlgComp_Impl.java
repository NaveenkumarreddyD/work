/**************************************************************************
* Program Name: CmGetTransportationConsumptionAlgComp_Impl
* Program Title: CmGetTransportationConsumptionAlgComp_Impl
* Author: Aya Masilang
* Creation Date: 2017-07-12
* Purpose: This algorithm will be a clone of base Algorithm Type, BSGC-SP
*          with added functionality to constrain the Bill Segment Period 
*          End Date to a specific day of the month.
* Functional Spec: SA-212480
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:          Date:         Description:
.* ----------------------------------------------------------------------------------------------
 * SA-212480          Aya Masilang     2017-07-12    Initial Version
 * Defect 3803911     Beverly Marquez  2017-09-04    Remove use of custom COBOL wrappers
 * CCB v2.6 Upgrade   Sharmayne Felipe 2018-08-02    Fixed null pointer issue if Account has no
 *                                                   prior Bill.
 * CCB004.Defect8     Beverly Marquez  2021-07-26    Add option to use next month, minus one day 
 *                                                   as end date. Removed loggers. Fixed other
 *                                                   issues.             
 ************************************************************************************************/
package com.splwg.cm.domain.admin.billsegmentType.algorithm.getConsumption;

import java.math.BigInteger;
import java.util.List;

import com.ibm.icu.math.BigDecimal;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.DayInMonth;
import com.splwg.base.api.datatypes.LookupHelper;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.algorithm.AlgorithmComponentCache;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.featureConfiguration.FeatureConfiguration_Id;
import com.splwg.base.domain.database.field.Field_Id;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.ExitIterationLoopLookup;
import com.splwg.ccb.api.lookup.ExternalSystemTypeLookup;
import com.splwg.ccb.api.lookup.HowToUseLookup;
import com.splwg.ccb.api.lookup.HowToUseReadLookup;
import com.splwg.ccb.api.lookup.SkipSaReasonLookup;
import com.splwg.ccb.cobol.bi.CobolCopybookCICBBLST;
import com.splwg.ccb.cobol.bi.CobolCopybookCICBBSFN;
import com.splwg.ccb.cobol.bi.CobolCopybookCICBBSI1;
import com.splwg.ccb.cobol.bi.CobolCopybookCICBBSR1;
import com.splwg.ccb.cobol.bi.CobolCopybookCICBSITC;
import com.splwg.ccb.cobol.bi.CobolCopybookCICBSITC.BILL_SEGMENT_ITEM_Row;
import com.splwg.ccb.cobol.bi.CobolCopybookCICBSRDC;
import com.splwg.ccb.cobol.bi.CobolCopybookCICBSRDC.BILL_SEGMENT_READ_Row;
import com.splwg.ccb.cobol.bi.CobolProgramCIPBBSFN;
import com.splwg.ccb.cobol.bi.CobolProgramCIPBBSI1;
import com.splwg.ccb.cobol.bi.CobolProgramCIPBBSR1;
import com.splwg.ccb.cobol.ct.CobolCopybookCICTFRQT;
import com.splwg.ccb.cobol.rt.CobolCopybookCICRRSAN;
import com.splwg.ccb.cobol.rt.CobolCopybookCICRRTST;
import com.splwg.ccb.cobol.rt.CobolProgramCIPRRSAN;
import com.splwg.ccb.domain.admin.billCancelReason.entity.BillCancelReason_Id;
import com.splwg.ccb.domain.admin.billCycle.entity.BillCycleSchedule_Id;
import com.splwg.ccb.domain.admin.billCycle.entity.BillCycle_Id;
import com.splwg.ccb.domain.admin.billSegmentType.algorithm.billSegmentAutoCancel.ExcessiveReadAutoCancelAlgorithmSpot;
import com.splwg.ccb.domain.admin.billSegmentType.algorithm.getConsumption.GetConsumptionAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceQuantityIdentifier.entity.ServiceQuantityIdentifier_Id;
import com.splwg.ccb.domain.admin.timeOfUse.entity.TimeOfUse_Id;
import com.splwg.ccb.domain.admin.unitOfMeasure.entity.UnitOfMeasure_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentItem_DTO;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentItem_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentRegisterRead_DTO;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegmentRegisterRead_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_DTO;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.billing.data.BillSegmentData;
import com.splwg.ccb.domain.billing.data.BillSegmentGeneratorData;
import com.splwg.ccb.domain.billing.data.BillSegmentItemData;
import com.splwg.ccb.domain.billing.data.BillSegmentReadData;
import com.splwg.ccb.domain.billing.data.BillSegmentServiceQuantityData;
import com.splwg.ccb.domain.common.installation.CcbInstallationHelper;
import com.splwg.ccb.domain.customerinfo.premise.entity.Premise_Id;
import com.splwg.ccb.domain.customerinfo.quote.entity.QuoteDetail_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.BillScenario_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.meterread.item.entity.Item_Id;
import com.splwg.ccb.domain.meterread.meterRead.entity.RegisterRead_Id;
import com.splwg.ccb.domain.meterread.usage.entity.Usage;
import com.splwg.ccb.domain.rate.rateSchedule.entity.RateSchedule_Id;
import com.splwg.cm.api.lookup.FinancialTransactionOptionTypeLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmMGEFeatureConfigurationOptionsRetriever;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.shared.common.ServerMessage;
/**
 * @author AMasil
 *
 * @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = maxConsecutiveEstimatedBillSegments, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = estimateWhenNoReadDetected, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (name = meterReadSelectionOption, type = string)
 *            , @AlgorithmSoftParameter (name = dayOfMonthForBillSegmentPeriodEnd, required = true, type = string)})
 */

public class CmGetTransportationConsumptionAlgComp_Impl
extends CmGetTransportationConsumptionAlgComp_Gen implements GetConsumptionAlgorithmSpot {
    
    /*
     * Start Change - Defect 3803911 - 2017-09-04
     */
    ////Working Variables
    //private Date consumptionEndDate;
    //private Date consumptionStartDate;
    //private Bool isCalledFromUsage = Bool.FALSE;
    //private Bool mustRetainItems = Bool.FALSE;
    //private Bool mustRetainReads = Bool.FALSE;
    //private Bool mustRetainServiceQuantities = Bool.FALSE;
    //private BillSegmentGeneratorData billSegmentGeneratorData;
    //private BillSegmentData billSegmentData;
    //private List<BillSegmentItemData> billSegmentItemData = new ArrayList<BillSegmentItemData>();
    //private List<BillSegmentReadData> billSegmentReadData = new ArrayList<BillSegmentReadData>();
    //private List<BillSegmentServiceQuantityData> billSegmentServiceQuantityData = new ArrayList<BillSegmentServiceQuantityData>();
    //private SkipSaReasonLookup skipSaReason;
    //private ExitIterationLoopLookup exitLoopCheck = ExitIterationLoopLookup.constants.NOT_APPLICABLE;
    //private Bool mustRestartGeneration = Bool.FALSE;
    //private Bool mustSkipServiceAgreement = Bool.FALSE;
    //private Usage usage;
    //private BillSegment previousFrozenBillSegment;
    //private ServiceAgreement serviceAgreement;
    //
    ////Constants
    //private static final String THREE = "3";

    // Input hard parameters
    private Bool mustRetainItems;
    private Bool mustRetainReads;
    private Bool mustRetainServiceQuantities;
    private BillSegment previousFrozenBillSegment;
    private ServiceAgreement serviceAgreement;
    
    // Input/Output hard parameters - Used as COBOL Copybooks
    private BillSegmentData billSegmentData; // copybookCICBBLST
    private List<BillSegmentReadData> billSegmentReadDataList; // copybookCICBSRDC
    private List<BillSegmentItemData> billSegmentItemDataList; // copybookCICBSITC
    
    // Input/Output hard parameters
    private BillSegmentGeneratorData billSegmentGeneratorData;
    private List<BillSegmentServiceQuantityData> billSegmentServiceQuantityDataList;
    private Date consumptionEndDate;
    private Date consumptionStartDate;
    private Bool isCalledFromUsage;
    private Bool mustSkipServiceAgreement;
    private SkipSaReasonLookup skipSaReason;
    private Usage usage;

    // Output hard parameters
    private ExitIterationLoopLookup exitIterationLoop;
    private Bool mustRestartGeneration = Bool.FALSE;
    
    // Soft parameters
    private BigInteger maxConsecutiveEstimatedBillSegments;
    private Bool mustEstimateWhenNoReadDetected;
    private String meterReadSelectionOption;
    /*
     * Start Change - CCB004.Defect8 - 2021-07-26
     */
    //private BigInteger dayOfMonthForBillSegmentPeriodEnd;
    private BigInteger dayOfMonthForBillSegmentPeriodEnd = BigInteger.ONE;
    private Bool useEndOfMonth = Bool.TRUE;
    /*
     * End Change - CCB004.Defect8 - 2021-07-26
     */

    // Working variables
    private BigInteger consumptionDays;
    private Bool allowAutoCancelBs;
    private BillSegment_Id preCnclLatestBsegId;
    private BillSegment_Id postCnclLatestBsegId;
    private Bool ovrdConsumpPrdSw;
    
    // Constants
    private static final String MR_SEL_OPT_LATEST = "LTST";
    private static final String MR_SEL_OPT_EACH_SCHED_MR = "SCHR";
    /*
     * Start Change - CCB004.Defect8 - 2021-07-26
     */
    private static final String BSEG_PD_END_OF_MONTH = "LAST";
    /*
     * End Change - CCB004.Defect8 - 2021-07-26
     */
    
    // Copybooks
    private CobolCopybookCICBBSFN copybookCICBBSFN;
    private CobolCopybookCICBBSI1 copybookCICBBSI1;
    private CobolCopybookCICBSITC copybookCICBSITC;
    private CobolCopybookCICBBLST copybookCICBBLST;
    private CobolCopybookCICBBSR1 copybookCICBBSR1;
    private CobolCopybookCICRRTST copybookCICRRTST;
    private CobolCopybookCICTFRQT copybookCICTFRQT;
    private CobolCopybookCICBSRDC copybookCICBSRDC;
    private CobolCopybookCICRRSAN copybookCICRRSAN;
    
    // Called Programs
    /** Determine Final Bill Segment Period */
    private CobolProgramCIPBBSFN programCIPBBSFN = (CobolProgramCIPBBSFN) getDynamicComponent(CobolProgramCIPBBSFN.class);
    
    /** Build Bill Segment Item collection */
    private CobolProgramCIPBBSI1 programCIPBBSI1 = (CobolProgramCIPBBSI1) getDynamicComponent(CobolProgramCIPBBSI1.class);

    /** Build Bill Segment Read Collection */
    private CobolProgramCIPBBSR1 programCIPBBSR1 = (CobolProgramCIPBBSR1) getDynamicComponent(CobolProgramCIPBBSR1.class);
    
    /** Get Rate Schedule Info for a SA */
    private CobolProgramCIPRRSAN programCIPRRSAN = (CobolProgramCIPRRSAN) getDynamicComponent(CobolProgramCIPRRSAN.class);
    
    /*
     * End Change - Defect 3803911 - 2017-09-04
     */

	@Override
	public void invoke() {
	    
	    /*
	     * Start Change - Defect 3803911 - 2017-09-04
	     */
        ////Attempt to call cobol
        //CobolProgramCMPBUSPX cobolCMPBUSPX = (CobolProgramCMPBUSPX) getDynamicComponent(CobolProgramCMPBUSPX.class);
        //CobolCopybookCMCBUSPX copybookCMCBUSPX = cobolCMPBUSPX.getCobolCopybookCMCBUSPX();
        //
        //// populate algorithm soft parameters
        //copybookCMCBUSPX.get_ZALPN().set_NBR_OF_PARMS(new BigInteger(THREE));
        //copybookCMCBUSPX.get_ZALPN().get_ALG_PARM_ARRAY().getArrayElement(0).set_ALG_PARM_VAL(getMaxConsecutiveEstimatedBillSegments().toString());
        //copybookCMCBUSPX.get_ZALPN().get_ALG_PARM_ARRAY().getArrayElement(1).set_ALG_PARM_VAL(getEstimateWhenNoReadDetected());
        //copybookCMCBUSPX.get_ZALPN().get_ALG_PARM_ARRAY().getArrayElement(2).set_ALG_PARM_VAL(getMeterReadSelectionOption());
        //
        //// populate algorithm hard parameters
        //copybookCMCBUSPX.get_BUZZX().get_INPUT_WRK().set_RETAIN_READ_COLL_SW(this.mustRetainReads);
        //copybookCMCBUSPX.get_BUZZX().get_INPUT_WRK().set_RETAIN_ITEM_COLL_SW(this.mustRetainItems);
        //copybookCMCBUSPX.get_BUZZX().get_INPUT_WRK().set_RETAIN_SQ_COLL_SW(this.mustRetainServiceQuantities);
        //if(notNull(this.previousFrozenBillSegment)){
        //    copybookCMCBUSPX.get_BUZZX().get_INPUT_WRK().set_PREV_FROZEN_BSEG_ID(this.previousFrozenBillSegment.getId().getTrimmedValue());
        //
        //}
        //copybookCMCBUSPX.get_BUZZX().get_INPUT_WRK().set_SA_ID(this.serviceAgreement.getId().getTrimmedValue());
        //copybookCMCBUSPX.get_BUZZX().get_INPUT_OUTPUT_WRK().get_CONSUMPTION_PERIOD().set_END_DT(this.consumptionEndDate);
        //copybookCMCBUSPX.get_BUZZX().get_INPUT_OUTPUT_WRK().get_CONSUMPTION_PERIOD().set_START_DT(this.consumptionStartDate);
        //copybookCMCBUSPX.get_BUZZX().get_INPUT_OUTPUT_WRK().set_CALLED_FROM_USG_SW(isCalledFromUsage);
        //if(notNull(this.usage)){
        //    copybookCMCBUSPX.get_BUZZX().get_INPUT_OUTPUT_WRK().set_USAGE_ID(this.usage.getId().getTrimmedValue());	        
        //}
        //
        ////populate copybook for bill segment generation
        //copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_ACCT_ID(this.billSegmentGeneratorData.getAccount().getId().getTrimmedValue());
        //copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_SA_ID(this.billSegmentGeneratorData.getServiceAgreement().getId().getTrimmedValue());
        //if(notNull(this.billSegmentGeneratorData.getBill())){
        //    copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_BILL_ID(this.billSegmentGeneratorData.getBill().getId().getTrimmedValue());	        
        //}
        //if(notNull(this.billSegmentGeneratorData.getBillableCharge())){
        //    copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_BILLABLE_CHG_ID(this.billSegmentGeneratorData.getBillableCharge().getId().toString());	        
        //}
        //if(notNull(this.billSegmentGeneratorData.getMasterServiceAgreement())){
        //    copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_MASTER_SA_ID(this.billSegmentGeneratorData.getMasterServiceAgreement().getId().getTrimmedValue());	        
        //}
        //if(notNull(this.billSegmentGeneratorData.getMasterBillSegment())){
        //    copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_MASTER_BSEG_ID(this.billSegmentGeneratorData.getMasterBillSegment().getId().getTrimmedValue());	        
        //}
        //copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_ITERATION_CNT(this.billSegmentGeneratorData.getIterationCount());
        //copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_CUTOFF_DT(this.billSegmentGeneratorData.getCutoffDate());
        //copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_ACCOUNTING_DT(this.billSegmentGeneratorData.getAccountingDate());
        //copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_ALLOW_EST_SW(this.billSegmentGeneratorData.getAreEstimatesAllowed());
        //copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_BILLING_OPT_SW(this.billSegmentGeneratorData.getHasBillingOption());
        //copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_REBILL_SW(this.billSegmentGeneratorData.getIsRebill());
        //if(notNull(this.billSegmentGeneratorData.getCancelBillSegmentId())){
        //    copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_CAN_BSEG_ID(this.billSegmentGeneratorData.getCancelBillSegmentId().getId().getTrimmedValue());	        
        //}
        //copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_USE_OLD_INFO_SW(this.billSegmentGeneratorData.getcanUseOldInfo());
        //if(notNull(this.billSegmentGeneratorData.getBillCycle())){
        //    copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_BILL_CYC_CD(this.billSegmentGeneratorData.getBillCycle().getId().getTrimmedValue());	        
        //}
        //copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_WIN_START_DT(this.billSegmentGeneratorData.getWindowStartDate());
        //copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_WIN_END_DT(this.billSegmentGeneratorData.getWindowEndDate());
        //copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_EST_DT(this.billSegmentGeneratorData.getEstimateDate());
        //copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_FREEZE_COMPLETE_SW(this.billSegmentGeneratorData.getFreezeAndComplete());
        //copybookCMCBUSPX.get_BBLSG().get_INPUT_WRK().set_BILL_SRC_FLG(this.billSegmentGeneratorData.getBillingSource());
        //if(notNull(this.billSegmentGeneratorData.getBillSegmentId())){
        //    copybookCMCBUSPX.get_BBLSG().get_INPUT_OUTPUT_WRK().set_BSEG_ID(this.billSegmentGeneratorData.getBillSegmentId().getTrimmedValue());	        
        //}
        //copybookCMCBUSPX.get_BBLSG().get_INPUT_OUTPUT_WRK().set_CALLED_FROM_USG_SW(this.billSegmentGeneratorData.getIsCalledFromUsage());
        //if(notNull(this.billSegmentGeneratorData.getUsage())){
        //    copybookCMCBUSPX.get_BBLSG().get_INPUT_OUTPUT_WRK().set_USAGE_ID(this.billSegmentGeneratorData.getUsage().getId().getTrimmedValue());	        
        //}
        //BillSegment_DTO bsegDTO = this.billSegmentData.getBillSegmentDto();
        //
        //// CIPBUSPX needs bill segment data to run. BBLST needs to be populated using billSegmentData
        //// populate BBLST of cobol using data from billSegmentData
        //if(notNull(bsegDTO)){
        //    copybookCMCBUSPX.get_BBLST().set_SA_ID(bsegDTO.getServiceAgreementId().getTrimmedValue());
        //    if(notNull(bsegDTO.getId())){
        //        copybookCMCBUSPX.get_BBLST().set_BSEG_ID(bsegDTO.getId().getTrimmedValue());
        //    }
        //    copybookCMCBUSPX.get_BBLST().set_CLOSING_BSEG_SW(bsegDTO.getIsClosingBillSegment());
        //    copybookCMCBUSPX.get_BBLST().set_EST_SW(bsegDTO.getIsEstimate());
        //    copybookCMCBUSPX.get_BBLST().set_START_DT(bsegDTO.getStartDate());
        //    copybookCMCBUSPX.get_BBLST().set_END_DT(bsegDTO.getEndDate());
        //    if(notNull(bsegDTO.fetchBillCycleSchedule())){
        //        copybookCMCBUSPX.get_BBLST().set_BILL_CYC_CD(bsegDTO.fetchBillCycleSchedule().fetchIdBillCycle().getId().getTrimmedValue());
        //        copybookCMCBUSPX.get_BBLST().set_WIN_START_DT(bsegDTO.fetchBillCycleSchedule().fetchIdWindowStartDate());	            
        //    }
        //    if(notNull(bsegDTO.fetchCancelReason())){
        //        copybookCMCBUSPX.get_BBLST().set_CAN_RSN_CD(bsegDTO.fetchCancelReason().getId().getTrimmedValue());	            
        //    }
        //    if(notNull(bsegDTO.fetchCancelBillSegment())){
        //        copybookCMCBUSPX.get_BBLST().set_CAN_BSEG_ID(bsegDTO.fetchCancelBillSegment().getId().getTrimmedValue());	            
        //    }
        //    copybookCMCBUSPX.get_BBLST().set_BILL_ID(bsegDTO.getBillId().getTrimmedValue());
        //    copybookCMCBUSPX.get_BBLST().set_SQ_OVERRIDE_SW(bsegDTO.getHasServiceQuantityOverride());
        //    copybookCMCBUSPX.get_BBLST().set_ITEM_OVERRIDE_SW(bsegDTO.getIsItemOverride());
        //    copybookCMCBUSPX.get_BBLST().set_PREM_ID(bsegDTO.getPremiseId().getTrimmedValue());
        //    if(notNull(bsegDTO.getBillSegmentStatus())){
        //        copybookCMCBUSPX.get_BBLST().set_BSEG_STAT_FLG(bsegDTO.getBillSegmentStatus().getLookupValue().getId().getFieldValue());
        //    }
        //    copybookCMCBUSPX.get_BBLST().set_CRE_DTTM(bsegDTO.getCreationDateTime());
        //    copybookCMCBUSPX.get_BBLST().set_STAT_CHG_DTTM(bsegDTO.getStatusChangeDateTime());
        //    if(notNull(bsegDTO.getReadSequenceId())){
        //        copybookCMCBUSPX.get_BBLST().set_REBILL_SEG_ID(bsegDTO.getReadSequenceId().getTrimmedValue());	            
        //    }
        //    if(notNull(bsegDTO.getMasterBillSegmentId())){
        //        copybookCMCBUSPX.get_BBLST().set_MASTER_BSEG_ID(bsegDTO.getMasterBillSegmentId().getTrimmedValue());	            
        //    }
        //    if(notNull(bsegDTO.getQuoteDetailId())){
        //    copybookCMCBUSPX.get_BBLST().set_QUOTE_DTL_ID(bsegDTO.getQuoteDetailId().getTrimmedValue());	            
        //    }
        //    copybookCMCBUSPX.get_BBLST().set_BSEG_DATA_AREA(bsegDTO.getBillSegmentDataArea());
        //    copybookCMCBUSPX.get_BBLST().set_MDM_START_DTTM(bsegDTO.getUsageStartDateTime());
        //    copybookCMCBUSPX.get_BBLST().set_MDM_END_DTTM(bsegDTO.getUsageEndDateTime());
        //    if(notNull(bsegDTO.getBillScenarioId())){
        //        copybookCMCBUSPX.get_BBLST().set_BILL_SCNR_ID(bsegDTO.getBillScenarioId().getTrimmedValue());	            
        //    }
        //    copybookCMCBUSPX.get_BBLST().set_ILM_DT(bsegDTO.getIlmDate());
        //    copybookCMCBUSPX.get_BBLST().set_ILM_ARCH_SW(bsegDTO.getIsEligibleForArchiving());
        //}
        //
        //cobolCMPBUSPX.callCobol();
        //
        //exitLoopCheck = LookupHelper.getLookupInstance(ExitIterationLoopLookup.class, cobolCMPBUSPX.getCobolCopybookCMCBUSPX().get_BUZZX().get_OUTPUT_WRK().get_EXIT_ITERATION_LOOP_FLG());
        //mustSkipServiceAgreement = cobolCMPBUSPX.getCobolCopybookCMCBUSPX().get_BUZZX().get_OUTPUT_WRK().get_SKIP_SA_SW();
        //
        //// populate billSegmentItemData using copybookCMCBUSPX.get_BSITC()
        ////iterate through copybookCMCBUSPX.get_BSITC().get_BILL_SEGMENT_ITEM()
        //int itemCounter = 0;
        //int itemCount = copybookCMCBUSPX.get_BSITC().get_BILL_SEGMENT_ITEM_CNT().intValue();
        //billSegmentItemData.clear();
        //while(itemCounter < itemCount){
        //    BILL_SEGMENT_ITEM_Row currentRow = copybookCMCBUSPX.get_BSITC().get_BILL_SEGMENT_ITEM().getArrayElement(itemCounter);
        //
        //    BillSegmentItemData data = BillSegmentItemData.Factory.newInstance();
        //    BillSegmentItem_DTO dto = new BillSegmentItem_DTO();
        //    BillSegmentItem_Id id = new BillSegmentItem_Id(bsegDTO.getId(), currentRow.get_SEQNO());
        //    dto.setId(id);
        //    dto.setItemType(currentRow.get_ITEM_TYPE_CD());
        //    dto.setItemId(new Item_Id(currentRow.get_ITEM_ID()));
        //    dto.setStartDate(currentRow.get_START_DT());
        //    dto.setEndDate(currentRow.get_END_DT());
        //    dto.setItemCount(currentRow.get_ITEM_CNT());
        //    dto.setUnitOfMeasureId(new UnitOfMeasure_Id(currentRow.get_UOM_CD()));
        //    dto.setDailyServiceQuantity(currentRow.get_SVC_QTY());
        //    
        //    data.setBillSegmentItemDto(dto);
        //    billSegmentItemData.add(data); 
        //
        //    itemCounter++;
        //}
        //
        ////populate billSegmentReadData copybookCMCBUSPX.get_BSRDC()
        ////iterate through copybookCMCBUSPX.get_BSRDC().get_BILL_SEGMENT_READ()
        //int readCounter = 0;
        //int readCount = copybookCMCBUSPX.get_BSRDC().get_BILL_SEGMENT_READ_CNT().intValue();
        //billSegmentReadData.clear();
        //while(readCounter < readCount){
        //    BILL_SEGMENT_READ_Row currentRow = copybookCMCBUSPX.get_BSRDC().get_BILL_SEGMENT_READ().getArrayElement(readCounter);
        //    BillSegmentReadData data = BillSegmentReadData.Factory.newInstance();
        //    BillSegmentRegisterRead_DTO dto = new BillSegmentRegisterRead_DTO();
        //    BillSegmentRegisterRead_Id id = new BillSegmentRegisterRead_Id(bsegDTO.getId(), currentRow.get_SP_ID(), currentRow.get_SEQNO());
        //    dto.setId(id);
        //    dto.setRegisterConstant(currentRow.get_REG_CONST());
        //    dto.setHowToUseRead(LookupHelper.getLookupInstance(HowToUseReadLookup.class, currentRow.get_USAGE_FLG()));
        //    dto.setUsePercent(currentRow.get_USE_PCT());
        //    dto.setHowToUse(LookupHelper.getLookupInstance(HowToUseLookup.class, currentRow.get_HOW_TO_USE_FLG()));
        //    dto.setMeasuresPeakQuantity(currentRow.get_MSR_PEAK_QTY_SW());
        //    dto.setUnitOfMeasureId(new UnitOfMeasure_Id(currentRow.get_UOM_CD()));
        //    dto.setTimeOfUseId(new TimeOfUse_Id(currentRow.get_TOU_CD()));
        //    dto.setServiceQuantityIdentifierId(new ServiceQuantityIdentifier_Id(currentRow.get_SQI_CD()));
        //    dto.setStartRegisterReadId(new RegisterRead_Id(currentRow.get_START_REG_READ_ID()));
        //    dto.setStartReadDateTime(currentRow.get_START_READ_DTTM());
        //    dto.setStartRegisterReading(currentRow.get_START_REG_READING());
        //    dto.setEndRegisterReadingId(new RegisterRead_Id(currentRow.get_END_REG_READ_ID()));
        //    dto.setEndReadDateTime(currentRow.get_END_READ_DTTM());
        //    dto.setEndRegisterReading(currentRow.get_END_REG_READING());
        //    dto.setMeasuredQuantity(currentRow.get_MSR_QTY());
        //    dto.setFinalUnitOfMeasureId(new UnitOfMeasure_Id(currentRow.get_FINAL_UOM_CD()));
        //    dto.setFinalTimeOfUseId(new TimeOfUse_Id(currentRow.get_FINAL_TOU_CD()));
        //    dto.setFinalServiceQuantityId(new ServiceQuantityIdentifier_Id(currentRow.get_FINAL_SQI_CD()));
        //    dto.setRegisterQuantity(currentRow.get_FINAL_REG_QTY());
        //
        //    data.setBillSegmentReadDto(dto);
        //    billSegmentReadData.add(data);
        //    readCounter++;
        //}
        //
        ////populate billSegmentServiceQuantityData using copybookCMCBUSPX.get_BSSQC()
        ////iterate through copybookCMCBUSPX.get_BSSQC().get_BILL_SEGMENT_SQ()
        //int sqCounter = 0;
        //int sqCount = copybookCMCBUSPX.get_BSSQC().get_BILL_SEGMENT_SQ_CNT().intValue();
        //billSegmentServiceQuantityData.clear();
        //while(sqCounter < sqCount){
        //    BILL_SEGMENT_SQ_Row currentRow = copybookCMCBUSPX.get_BSSQC().get_BILL_SEGMENT_SQ().getArrayElement(sqCounter);
        //    BillSegmentServiceQuantityData data = BillSegmentServiceQuantityData.Factory.newInstance();
        //    BillSegmentServiceQuantity_DTO dto = new BillSegmentServiceQuantity_DTO();
        //    BillSegmentServiceQuantity_Id id = new BillSegmentServiceQuantity_Id(bsegDTO.getId(), currentRow.get_UOM_CD(), currentRow.get_TOU_CD(), currentRow.get_SQI_CD());
        //    dto.setId(id);
        //    dto.setBillableServiceQuantity(currentRow.get_BILL_SQ());
        //    dto.setInitialServiceQuantity(currentRow.get_INIT_SQ());            
        //
        //    billSegmentServiceQuantityData.add(data);
        //    sqCounter++;
        //}
        //
        ////If not final bill, the consumption end date and bill segment end will be constrained to a specific day of the month.
        //BillSegmentType saBsegType = serviceAgreement.getServiceAgreementType().fetchBillSegmentType();
        //
        //if(saBsegType.fetchBillSegmentGetConsumptionAlgorithm().equals(getAlgorithm())){
        //    if(bsegDTO.getIsClosingBillSegment().isFalse()){
        //        Date resultingEndDate = this.consumptionStartDate.addMonths(1);
        //        int day = getIsValidDayOfMonth(resultingEndDate);
        //        resultingEndDate = new Date(resultingEndDate.getYear(), resultingEndDate.getMonth(), day);
        //        
        //        bsegDTO.setEndDate(resultingEndDate);
        //        this.billSegmentData.setBillSegmentDto(bsegDTO);
        //        
        //        this.consumptionEndDate = resultingEndDate;
        //    }
        //}
	    
	    // Initialize program
	    initialize();
	    
	    // Validate input
	    checkInput();
	    
        // NA-212480 - Process Effective End Date
        processEndDateSelection();
        
        // Move Java variables to COBOL Copybooks
        moveJavaInfoToCobol();
	    
	    // Perform Process
	    performProc();
        
        // Move COBOL Copybook information to Java variables
        moveCobolInfoToJava();
	    
	    /*
         * End Change - Defect 3803911 - 2017-09-04
         */
	}
	
    /*
     * Start Add - Defect 3803911 - 2017-09-04
     */
	/**
	 * CA000-INITIALIZE
	 * Initialize program.
	 */
    private void initialize() {
        
        exitIterationLoop = ExitIterationLoopLookup.constants.YES;
        allowAutoCancelBs = Bool.TRUE;
        
    }
    
    /**
     * EA000-CHECK-INPUT
     * Validate input.
     */
    private void checkInput() {
        
        // Start Date of Consumption Period must be specified
        if (isNull(consumptionStartDate)) {
            addError(CustomMessageRepository.SA_212480_FieldMissing(new Field_Id("CNSMP_PD_ST_DT")));
        }
        
        // End Date of Consumption Period must be specified
        if (isNull(consumptionEndDate)) {
            addError(CustomMessageRepository.SA_212480_FieldMissing(new Field_Id("CNSMP_PD_END_DT")));
        }
        
        // Consumption Period Start Date may not be later than End Date
        if (consumptionStartDate.isAfter(consumptionEndDate)) {
            addError(CustomMessageRepository.SA_212480_ConsumptionPeriodInvalid(
                    consumptionStartDate,
                    consumptionEndDate,
                    serviceAgreement.getId(),
                    billSegmentData.getBillSegmentDto().getId(),
                    billSegmentData.getBillSegmentDto().getStartDate(),
                    billSegmentData.getBillSegmentDto().getEndDate()));
        }
        
        // Retain Read Collection Switch must be specified
        if (isNull(mustRetainReads)) {
            addError(CustomMessageRepository.SA_212480_FieldMissing(new Field_Id("RTN_READ_COLL_SW")));
        }
        
        // Retain Item Collection Switch must be specified
        if (isNull(mustRetainItems)) {
            addError(CustomMessageRepository.SA_212480_FieldMissing(new Field_Id("RTN_ITEM_COLL_SW")));
        }
        
        // Retain SQ Collection Switch must be specified
        if (isNull(mustRetainServiceQuantities)) {
            addError(CustomMessageRepository.SA_212480_FieldMissing(new Field_Id("RTN_SQ_COLL_SW")));
        }
        
        // See extraSoftParameterValidations for Soft Parameter validation
        
    }
	
    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
        
        // Algorithm Parameters must be numeric and between 0 and 99999
        maxConsecutiveEstimatedBillSegments = getMaxConsecutiveEstimatedBillSegments();
        if (maxConsecutiveEstimatedBillSegments.compareTo(BigInteger.ZERO) < 0 
                || maxConsecutiveEstimatedBillSegments.compareTo(BigInteger.valueOf(99999)) > 0) {
            addError(CustomMessageRepository.SA_212480_MaxConsecutiveEstimatesInvalid());
        }
        
        mustEstimateWhenNoReadDetected = getEstimateWhenNoReadDetected();
        // See buildReadColl() for parameter information data moves
        
        meterReadSelectionOption = getMeterReadSelectionOption();
        if (isBlankOrNull(meterReadSelectionOption)) {
            meterReadSelectionOption = MR_SEL_OPT_LATEST;
        }
        
        if (!(MR_SEL_OPT_LATEST.equalsIgnoreCase(meterReadSelectionOption) 
                || MR_SEL_OPT_EACH_SCHED_MR.equalsIgnoreCase(meterReadSelectionOption))) {
            addError(CustomMessageRepository.SA_212480_SelectionOptionInvalid());
        }

        /*
         * Start Change - CCB004.Defect8 - 2021-07-26
         */
        //// Prescribed Day of Month for Bill Segment End Period must have a valid value for the next month
        //dayOfMonthForBillSegmentPeriodEnd = getDayOfMonthForBillSegmentPeriodEnd();
        //try{
        //    new DayInMonth(getProcessDateTime().getMonth(), dayOfMonthForBillSegmentPeriodEnd.intValue());            
        //} catch (IllegalArgumentException e) {
        //    addError(CustomMessageRepository.SA_212480_InvalidDayOfMonth(getDayOfMonthForBillSegmentPeriodEnd().toString(), getAlgorithmId().getTrimmedValue(), getProcessDateTime().getMonthValue().toString()));
        //}
        
        // If this value is not "LAST", process the entered value as a number
        String dayOfMonthForBillSegmentPeriodEndValue = getDayOfMonthForBillSegmentPeriodEnd();
        if (!BSEG_PD_END_OF_MONTH.equalsIgnoreCase(dayOfMonthForBillSegmentPeriodEndValue)) {
            
            // Prescribed Day of Month for Bill Segment End Period must have a valid value for the next month
            useEndOfMonth = Bool.FALSE;
            try{
                dayOfMonthForBillSegmentPeriodEnd = new BigInteger(dayOfMonthForBillSegmentPeriodEndValue);
                new DayInMonth(getProcessDateTime().getMonth(), dayOfMonthForBillSegmentPeriodEnd.intValue());            
            } catch (IllegalArgumentException e) {
                addError(CustomMessageRepository.SA_212480_InvalidDayOfMonth(getDayOfMonthForBillSegmentPeriodEnd(), getAlgorithmId().getTrimmedValue(), getProcessDateTime().getMonthValue().toString()));
            } 
            
        }
        /*
         * End Change - CCB004.Defect8 - 2021-07-26
         */
        
        super.extraSoftParameterValidations(forAlgorithmValidation);
        
    }
    
    /**
     * See NA-212480 Functional Design
     * Constrain the Bill Segment Period End Date to a specific day of the month except for final
     * bills
     */
    private void processEndDateSelection() {
        
        BillSegment_DTO bsegDTO = billSegmentData.getBillSegmentDto();
        
        // If the Bill Segment is closing
        if (bsegDTO.getIsClosingBillSegment().isTrue()) {
            return;
        }
        
        Date resultingEndDate = consumptionStartDate.addMonths(1);
        int day = getIsValidDayOfMonth(resultingEndDate);
        resultingEndDate = new Date(resultingEndDate.getYear(), resultingEndDate.getMonth(), day);
        
        /*
         * Start Add - CCB004.Defect8 - 2021-07-26
         */
        /*
         * If dayOfMonthForBillSegmentPeriodEnd was "LAST", resultingEndDate should be the first of
         * the month. Subtract one day to get the last day of last month.
         */
        if (useEndOfMonth.isTrue()) {
            resultingEndDate = resultingEndDate.addDays(-1);
        }
        /*
         * End Add - CCB004.Defect8 - 2021-07-26
         */
        
        bsegDTO.setEndDate(resultingEndDate);
        if (notNull(bsegDTO.getUsageEndDateTime())) {
            bsegDTO.setUsageEndDateTime(new DateTime(resultingEndDate, bsegDTO.getUsageEndDateTime().getTime()));
        }
        billSegmentData.setBillSegmentDto(bsegDTO);
        
        billSegmentGeneratorData.setWindowEndDate(resultingEndDate);
        
        if (billSegmentGeneratorData.getHasBillingOption().isTrue()) {
            billSegmentGeneratorData.setCutoffDate(resultingEndDate);
        }
        
        consumptionEndDate = resultingEndDate;
        
    }
    
    /**
     * Move Java variables to COBOL Copybooks
     */
    private void moveJavaInfoToCobol() {
        
        moveBillSegmentDataToCICBBLST();
        moveBillSegmentReadDataToCICBSRDC();
        moveBillSegmentItemDataToCICBSITC();
        
    }
    
    /**
     * Populate BBLST copybook using data from billSegmentData
     */
    private void moveBillSegmentDataToCICBBLST() {

        BillSegment_DTO bsegDTO = billSegmentData.getBillSegmentDto();
        if (isNull(bsegDTO)) {
            return;
        }
        
        if (isNull(copybookCICBBLST)) {
            copybookCICBBLST = programCIPBBSR1.getCobolCopybookCICBBLST();
        }
        
        copybookCICBBLST.set_SA_ID(bsegDTO.getServiceAgreementId().getTrimmedValue());
        if(notNull(bsegDTO.getId())){
            copybookCICBBLST.set_BSEG_ID(bsegDTO.getId().getTrimmedValue());
        }
        copybookCICBBLST.set_CLOSING_BSEG_SW(bsegDTO.getIsClosingBillSegment());
        copybookCICBBLST.set_EST_SW(bsegDTO.getIsEstimate());
        copybookCICBBLST.set_START_DT(bsegDTO.getStartDate());
        copybookCICBBLST.set_END_DT(bsegDTO.getEndDate());
        if(notNull(bsegDTO.fetchBillCycleSchedule())){
            copybookCICBBLST.set_BILL_CYC_CD(bsegDTO.fetchBillCycleSchedule().fetchIdBillCycle().getId().getTrimmedValue());
            copybookCICBBLST.set_WIN_START_DT(bsegDTO.fetchBillCycleSchedule().fetchIdWindowStartDate());             
        }
        if(notNull(bsegDTO.fetchCancelReason())){
            copybookCICBBLST.set_CAN_RSN_CD(bsegDTO.fetchCancelReason().getId().getTrimmedValue());               
        }
        if(notNull(bsegDTO.fetchCancelBillSegment())){
            copybookCICBBLST.set_CAN_BSEG_ID(bsegDTO.fetchCancelBillSegment().getId().getTrimmedValue());             
        }
        copybookCICBBLST.set_BILL_ID(bsegDTO.getBillId().getTrimmedValue());
        copybookCICBBLST.set_SQ_OVERRIDE_SW(bsegDTO.getHasServiceQuantityOverride());
        copybookCICBBLST.set_ITEM_OVERRIDE_SW(bsegDTO.getIsItemOverride());
        copybookCICBBLST.set_PREM_ID(bsegDTO.getPremiseId().getTrimmedValue());
        if(notNull(bsegDTO.getBillSegmentStatus())){
            copybookCICBBLST.set_BSEG_STAT_FLG(bsegDTO.getBillSegmentStatus().getLookupValue().getId().getFieldValue());
        }
        copybookCICBBLST.set_CRE_DTTM(bsegDTO.getCreationDateTime());
        copybookCICBBLST.set_STAT_CHG_DTTM(bsegDTO.getStatusChangeDateTime());
        if(notNull(bsegDTO.getReadSequenceId())){
            copybookCICBBLST.set_REBILL_SEG_ID(bsegDTO.getReadSequenceId().getTrimmedValue());                
        }
        if(notNull(bsegDTO.getMasterBillSegmentId())){
            copybookCICBBLST.set_MASTER_BSEG_ID(bsegDTO.getMasterBillSegmentId().getTrimmedValue());              
        }
        if(notNull(bsegDTO.getQuoteDetailId())){
            copybookCICBBLST.set_QUOTE_DTL_ID(bsegDTO.getQuoteDetailId().getTrimmedValue());              
        }
        copybookCICBBLST.set_BSEG_DATA_AREA(bsegDTO.getBillSegmentDataArea());
        copybookCICBBLST.set_MDM_START_DTTM(bsegDTO.getUsageStartDateTime());
        copybookCICBBLST.set_MDM_END_DTTM(bsegDTO.getUsageEndDateTime());
        if(notNull(bsegDTO.getBillScenarioId())){
            copybookCICBBLST.set_BILL_SCNR_ID(bsegDTO.getBillScenarioId().getTrimmedValue());             
        }
        copybookCICBBLST.set_ILM_DT(bsegDTO.getIlmDate());
        copybookCICBBLST.set_ILM_ARCH_SW(bsegDTO.getIsEligibleForArchiving());
        
    }
    
    /**
     * Populate BSRDC copybook using data from billSegmentReadDataList
     */
    private void moveBillSegmentReadDataToCICBSRDC() {
        
        if (isNull(copybookCICBSRDC)) {
            copybookCICBSRDC = programCIPBBSR1.getCobolCopybookCICBSRDC();
        }
        
        copybookCICBSRDC.clear();
        copybookCICBSRDC.set_BILL_SEGMENT_READ_CNT(BigInteger.valueOf(billSegmentReadDataList.size()));
        for (BillSegmentReadData readData : billSegmentReadDataList) {
            BillSegmentRegisterRead_DTO javaDto = readData.getBillSegmentReadDto();
            BILL_SEGMENT_READ_Row copybookRow = copybookCICBSRDC.get_BILL_SEGMENT_READ().newRow();
            copybookRow.set_SP_ID(javaDto.getId().getServicePointIdString());
            copybookRow.set_SEQNO(javaDto.getId().getSequence());
            copybookRow.set_REG_CONST(javaDto.getRegisterConstant());
            if (notNull(javaDto.getHowToUseRead())) {
                copybookRow.set_USAGE_FLG(javaDto.getHowToUseRead().value());
            }
            copybookRow.set_USE_PCT(javaDto.getUsePercent());
            if (notNull(javaDto.getHowToUse())) {
                copybookRow.set_HOW_TO_USE_FLG(javaDto.getHowToUse().value());
            }
            copybookRow.set_MSR_PEAK_QTY_SW(javaDto.getMeasuresPeakQuantity());
            if (notNull(javaDto.getUnitOfMeasureId())) {
                copybookRow.set_UOM_CD(javaDto.getUnitOfMeasureId().getIdValue());
            }
            if (notNull(javaDto.getTimeOfUseId())) {
                copybookRow.set_TOU_CD(javaDto.getTimeOfUseId().getIdValue());
            }
            if (notNull(javaDto.getServiceQuantityIdentifierId())) {
                copybookRow.set_SQI_CD(javaDto.getServiceQuantityIdentifierId().getIdValue());
            }
            if (notNull(javaDto.getStartRegisterReadId())) {
                copybookRow.set_START_REG_READ_ID(javaDto.getStartRegisterReadId().getIdValue());
            }
            copybookRow.set_START_READ_DTTM(javaDto.getStartReadDateTime());
            copybookRow.set_START_REG_READING(javaDto.getStartRegisterReading());
            if (notNull(javaDto.getEndRegisterReadingId())) {
                copybookRow.set_END_REG_READ_ID(javaDto.getEndRegisterReadingId().getIdValue());
            }
            copybookRow.set_END_READ_DTTM(javaDto.getEndReadDateTime());
            copybookRow.set_END_REG_READING(javaDto.getEndRegisterReading());
            copybookRow.set_MSR_QTY(javaDto.getMeasuredQuantity());
            if (notNull(javaDto.getFinalUnitOfMeasureId())) {
                copybookRow.set_FINAL_UOM_CD(javaDto.getFinalUnitOfMeasureId().getIdValue());
            }
            if (notNull(javaDto.getFinalTimeOfUseId())) {
                copybookRow.set_FINAL_TOU_CD(javaDto.getFinalTimeOfUseId().getIdValue());
            }
            if (notNull(javaDto.getFinalServiceQuantityId())) {
                copybookRow.set_FINAL_SQI_CD(javaDto.getFinalServiceQuantityId().getIdValue());
            }
            copybookRow.set_FINAL_REG_QTY(javaDto.getRegisterQuantity());
        }
        
    }
    
    /**
     * Populate BSITC copybook using data from billSegmentItemDataList
     */
    private void moveBillSegmentItemDataToCICBSITC() {
        
        if (isNull(copybookCICBSITC)) {
            copybookCICBSITC = programCIPBBSI1.getCobolCopybookCICBSITC();
        }
        
        copybookCICBSITC.clear();
        copybookCICBSITC.set_BILL_SEGMENT_ITEM_CNT(BigInteger.valueOf(billSegmentItemDataList.size()));
        for (BillSegmentItemData itemData : billSegmentItemDataList) {

            BillSegmentItem_DTO javaDto = itemData.getBillSegmentItemDto();
            BILL_SEGMENT_ITEM_Row copybookRow = copybookCICBSITC.get_BILL_SEGMENT_ITEM().newRow();
            if (notNull(javaDto.getId())) {
                copybookRow.set_SEQNO(javaDto.getId().getSequence());
            }
            copybookRow.set_ITEM_TYPE_CD(javaDto.getItemType());
            if (notNull(javaDto.getItemId())) {
                copybookRow.set_ITEM_ID(javaDto.getItemId().getIdValue());
            }
            copybookRow.set_START_DT(javaDto.getStartDate());
            copybookRow.set_END_DT(javaDto.getEndDate());
            copybookRow.set_ITEM_CNT(javaDto.getItemCount());
            if (notNull(javaDto.getUnitOfMeasureId())) {
                copybookRow.set_UOM_CD(javaDto.getUnitOfMeasureId().getIdValue());
            }
            copybookRow.set_SVC_QTY(javaDto.getDailyServiceQuantity());
            
        }
        
    }
    
    /**
     * GA000-PERFORM-PROC
     * Perform Process
     */
    private void performProc() {
        
        // Initial processing
        initProc();
        
        // Get RS Info
        getRsInfo();
        
        // Build Read Collection
        if (!buildReadColl()) {
            return;
        }
        
        // Determine final end date of bill segment
        if (!setFinalPeriod()) {
            return;
        }
       
        // Build Item collection
        buildItemColl();
        
    }
    
    /**
     * MA000-INIT-PROC
     * Initial Processing
     */
    private void initProc() {
        
        mustSkipServiceAgreement = Bool.FALSE;
        mustRestartGeneration = Bool.FALSE;
        exitIterationLoop = ExitIterationLoopLookup.constants.YES;
        
    }
    
    /**
     * MA010-GET-RS-INFO
     * Get Rate Schedule information
     */
    private void getRsInfo() {
        
        copybookCICRRSAN = programCIPRRSAN.getCobolCopybookCICRRSAN();
        copybookCICRRSAN.get_INPUT_WRK().set_SA_ID(serviceAgreement.getId().getTrimmedValue());
        copybookCICRRSAN.get_INPUT_WRK().set_ACCOUNTING_DT(billSegmentGeneratorData.getAccountingDate());
        copybookCICRRSAN.get_INPUT_WRK().get_CONSUMPTION_PERIOD().set_START_DT(consumptionStartDate);
        copybookCICRRSAN.get_INPUT_WRK().get_CONSUMPTION_PERIOD().set_END_DT(consumptionEndDate);
        programCIPRRSAN.callCobol(); // Using ZSQLN, ZSTAT, RRSAN, ZMSGN
        
    }
    
    /**
     * MA020-BUILD-READ-COLL
     * Build Read Collection
     */
    private boolean buildReadColl() {
        
        copybookCICBBSR1 = programCIPBBSR1.getCobolCopybookCICBBSR1();
        
        // Parameter-driven settings (see extraSoftParameterValidations)
        if (mustEstimateWhenNoReadDetected.isTrue()) {
            copybookCICBBSR1.get_INPUT_WRK().set_ALLOW_EST_WITH_NO_READS("Y");
        } else {
            copybookCICBBSR1.get_INPUT_WRK().set_ALLOW_EST_WITH_NO_READS("N");
        }
        copybookCICBBSR1.get_INPUT_WRK().set_EXCLUDE_OFFSET_DAYS("N");
        
        // Base settings
        copybookCICBBSR1.get_INPUT_WRK().set_RETAIN_READ_COLL_SW(mustRetainReads);
        //copybookCICBBSR1.get_INPUT_WRK().set_CUTOFF_DT(billSegmentGeneratorData.getCutoffDate());
        //copybookCICBBSR1.get_INPUT_WRK().set_BILLING_OPT_SW(billSegmentGeneratorData.getHasBillingOption());
        copybookCICBBSR1.get_INPUT_WRK().set_ALLOW_EST_SW(billSegmentGeneratorData.getAreEstimatesAllowed());
        copybookCICBBSR1.get_INPUT_WRK().set_EST_DT(billSegmentGeneratorData.getEstimateDate());
        // CCB v2.6 Upgrade - 2018-07-31 - Start Change
        //copybookCICBBSR1.get_INPUT_WRK().set_PREV_FROZEN_BSEG_ID(previousFrozenBillSegment.getId().getIdValue());
        if(notNull(previousFrozenBillSegment)) {
            copybookCICBBSR1.get_INPUT_WRK().set_PREV_FROZEN_BSEG_ID(previousFrozenBillSegment.getId().getIdValue());
        }
        // CCB v2.6 Upgrade - 2018-07-31 - End Change
        
        // Incident - #212480 - Override only if the Bill Segment is not closing
        BillSegment_DTO bsegDTO = billSegmentData.getBillSegmentDto();
        
        if (bsegDTO.getIsClosingBillSegment().isTrue()) {
            copybookCICBBSR1.get_INPUT_WRK().set_CUTOFF_DT(billSegmentGeneratorData.getCutoffDate());
            copybookCICBBSR1.get_INPUT_WRK().set_BILLING_OPT_SW(billSegmentGeneratorData.getHasBillingOption());
        } else {
            copybookCICBBSR1.get_INPUT_WRK().set_CUTOFF_DT(consumptionEndDate);
            copybookCICBBSR1.get_INPUT_WRK().set_BILLING_OPT_SW(Bool.TRUE);
        }
        
        // Check if the bill segment type has an Excessive Read Auto-Cancel algorithm
        if (notNull(serviceAgreement.getServiceAgreementType().fetchBillSegmentType().fetchAutoCancelAlgorithm())) {
            copybookCICBBSR1.get_INPUT_WRK().set_DETECT_AUTOX_ER_SW(Bool.TRUE);
        } else {
            copybookCICBBSR1.get_INPUT_WRK().set_DETECT_AUTOX_ER_SW(Bool.FALSE);
        }
        
        copybookCICBBSR1.get_INPUT_WRK().get_CONSUMPTION_PERIOD().set_START_DT(consumptionStartDate);
        copybookCICBBSR1.get_INPUT_WRK().get_CONSUMPTION_PERIOD().set_END_DT(consumptionEndDate);
        
        copybookCICRRTST = programCIPBBSR1.getCobolCopybookCICRRTST();
        copybookCICRRTST.set_RS_CD(copybookCICRRSAN.get_OUTPUT_WRK().get_RS_CD());
        
        copybookCICTFRQT = programCIPBBSR1.getCobolCopybookCICTFRQT();
        
        // Altering the Frequency limits the End Meter Read to the last consumption day
        int consumptionLength = (int) consumptionEndDate.difference(consumptionStartDate).getTotalDays();
        BigDecimal periodsPerYear = new BigDecimal(copybookCICRRSAN.get_OUTPUT_WRK().get_PERIODS_PER_YEAR());
        int averageMonthLengthAccdgToFrequency = Date.DAYS_IN_YEAR.divide(periodsPerYear, 0, BigDecimal.ROUND_FLOOR).intValue();
        BigInteger maxDaysOffset = BigInteger.valueOf(consumptionLength - averageMonthLengthAccdgToFrequency + 1);
        BigInteger minDaysOffset = BigInteger.valueOf(averageMonthLengthAccdgToFrequency - consumptionLength);
        
        copybookCICTFRQT.set_MAX_DAYS_OFFSET(maxDaysOffset);
        copybookCICTFRQT.set_MIN_DAYS_OFFSET(minDaysOffset);
        copybookCICTFRQT.set_PERIODS_PER_YEAR(copybookCICRRSAN.get_OUTPUT_WRK().get_PERIODS_PER_YEAR());
        
        programCIPBBSR1.callCobol(); // Using ZSQLN, ZSTAT, BBSRQ, BBLST, BSRDC, RRTST, TFRQT, ZMSGN
        
        copybookCICBSRDC = programCIPBBSR1.getCobolCopybookCICBSRDC();
        
        mustSkipServiceAgreement = copybookCICBBSR1.get_OUTPUT_WRK().get_SKIP_SA_SW();
        skipSaReason = LookupHelper.getLookupInstance(SkipSaReasonLookup.class, copybookCICBBSR1.get_OUTPUT_WRK().get_SKIP_SA_RSN_FLG());
        mustRestartGeneration = copybookCICBBSR1.get_OUTPUT_WRK().get_RESTART_GEN_SW();
        
        if (mustSkipServiceAgreement.isTrue()) {
            exitIterationLoop = ExitIterationLoopLookup.constants.YES;
        }
        
        if (mustSkipServiceAgreement.isTrue() || mustRestartGeneration.isTrue()) {
            return false;
        }
        
        if (copybookCICBBSR1.get_INPUT_WRK().get_DETECT_AUTOX_ER_SW().isTrue()
                && copybookCICBBSR1.get_OUTPUT_WRK().get_AUTOX_ER_REQ_SW().isTrue()) {
            
            /* 
             * Check Installation Option and Feature Configuration if Auto Cancellation of Bill 
             * Segment is allowed
             */
            chkAllowAutoCanBs();
            
            if (allowAutoCancelBs.isTrue()) {
                
                /* 
                 * Retrieve latest frozen bill segment BEFORE and AFTER invoking the Autocancel 
                 * algorithm and compare the BSEG-ID results
                 */
                // Initialize the latest BS holder
                preCnclLatestBsegId = null;
                postCnclLatestBsegId = null;
                
                getLatestFrozenBs();
                
                doAutoCancel();
                
                getLatestFrozenBs();
                
                if (preCnclLatestBsegId.equals(postCnclLatestBsegId)) {
                    mustRestartGeneration = Bool.TRUE;
                    return false;
                }
                
            } else {
                
                /*
                 * If not allowed, issue an error stating that auto cancellation of the previous
                 * bill segment with excessive reads is not allowed when bill correction option
                 * is for Correction/Credit Note and Feature Configuration for Allow Auto
                 * Cancellation BS is set to "N"
                 */
                if (CcbInstallationHelper.getCcbInstallationInstance().getBillCorrectionOption().isCorrectionNote()) {
                    addError(CustomMessageRepository.SA_212480_CancelThruCorrection(serviceAgreement.getId()));
                /*
                 * Start Change - CCB004.Defect8 - 2021-07-26
                 */
                //} else if (CcbInstallationHelper.getCcbInstallationInstance().getBillCorrectionOption().isCorrectionNote()) {
                } else if (!CcbInstallationHelper.getCcbInstallationInstance().getBillCorrectionOption().isCorrectionNote()) {
                /*
                 * End Change - CCB004.Defect8 - 2021-07-26
                 */
                    addError(CustomMessageRepository.SA_212480_CancelThruCreditNote(serviceAgreement.getId()));
                }
                
            }
            
        }
        
        /*
         * If there are remaining reads, do not exit iteration loop.
         * The remaining reads need to be processed later.
         */
        if (copybookCICBBSR1.get_OUTPUT_WRK().get_WITH_MORE_READ_SW().isTrue()) {
            exitIterationLoop = ExitIterationLoopLookup.constants.NO;
        }
        
        return true;
        
    }
    
    /**
     * MA030-DO-AUTO-CANCEL
     * Perform Auto-Cancel
     */
    private void doAutoCancel() {
        
        // Call the Excessive Reads Auto-Cancel Driver
        ExcessiveReadAutoCancelAlgorithmSpot excessiveReadAutoCancelAlgorithmSpot = AlgorithmComponentCache.getAlgorithmComponent(serviceAgreement.getServiceAgreementType().fetchBillSegmentType().getAutoCancelAlgorithmId(), ExcessiveReadAutoCancelAlgorithmSpot.class);
        excessiveReadAutoCancelAlgorithmSpot.setServiceAgreement(billSegmentData.getBillSegmentDto().getServiceAgreementId().getEntity());
        excessiveReadAutoCancelAlgorithmSpot.setRateSchedule(new RateSchedule_Id(copybookCICRRTST.get_RS_CD()).getEntity());
        excessiveReadAutoCancelAlgorithmSpot.setAccountingDate(billSegmentGeneratorData.getAccountingDate());
        moveCICBBLSTToBillSegmentData();
        excessiveReadAutoCancelAlgorithmSpot.setBillSegmentData(billSegmentData);
        moveCICBSRDCToBillSegmentReadDataList();
        excessiveReadAutoCancelAlgorithmSpot.setBillSegmentReadData(billSegmentReadDataList);
        
        excessiveReadAutoCancelAlgorithmSpot.invoke();
        
        billSegmentData = excessiveReadAutoCancelAlgorithmSpot.getBillSegmentData();
        moveBillSegmentDataToCICBBLST();
        billSegmentReadDataList = excessiveReadAutoCancelAlgorithmSpot.getBillSegmentReadData();
        moveBillSegmentReadDataToCICBSRDC();
        
    }
    
    /**
     * MA040-SET-FINAL-PERIOD
     * Determine final billing period
     */
    private boolean setFinalPeriod() {
        
        // Get SA Type Info
        ServiceAgreementType serviceAgreementType = serviceAgreement.getServiceAgreementType();
        
        // Initialize the Override Consumption Switch
        ovrdConsumpPrdSw = Bool.FALSE;
        
        /*
         * Check if an Override Consumption Period is defined in the Feature Configuration.
         * Return true if the following conditions are met:
         * -   Override Consumption Feature Configuration Option Type exists and has a valid
         *     Characteristic Type value
         * -   Current Service Agreement's SA Type has a characteristic type that matches the one
         *     defined in the Feature Configuration
         */
        checkOvrdConsumpPrdFc();
        
        /*
         * Skip manipulation of Consumption End Date when the Override Consumption Period is set
         * Or if Override Consumption Period set and Billing Option is set to true, override the
         * end date returned by the CIPBBSFN routine
         */
        
        // Override Consumption Period not set. Use the consumption period returned by CIPBBSFN
        if (ovrdConsumpPrdSw.isFalse()) {
            
            copybookCICBBSFN = programCIPBBSFN.getCobolCopybookCICBBSFN();
            copybookCICBBSFN.get_INPUT_OUTPUT_WRK().get_CONSUMPTION_PERIOD().set_START_DT(consumptionStartDate);
            copybookCICBBSFN.get_INPUT_OUTPUT_WRK().get_CONSUMPTION_PERIOD().set_END_DT(consumptionEndDate);
            
            moveCICBBLSTToBillSegmentData();
            copybookCICBBLST = programCIPBBSFN.getCobolCopybookCICBBLST();
            moveBillSegmentDataToCICBBLST();
            
            moveCICBSRDCToBillSegmentReadDataList();
            copybookCICBSRDC = programCIPBBSFN.getCobolCopybookCICBSRDC();
            moveBillSegmentReadDataToCICBSRDC();
            
            programCIPBBSFN.callCobol(); // Using ZSQLN, ZSTAT, BBSFN, BBLST, BSRDC, ZMSGN
            
            // Get computed consumption period
            consumptionStartDate = copybookCICBBSFN.get_INPUT_OUTPUT_WRK().get_CONSUMPTION_PERIOD().get_START_DT();
            consumptionEndDate = copybookCICBBSFN.get_INPUT_OUTPUT_WRK().get_CONSUMPTION_PERIOD().get_END_DT();
            
        /*
         * When Billing uses the Service Cycle Schedule and this is for non-closing bill
         * segment and also the Override Consumption period is set, manipulate the end date
         * returned by CIPBBSFN to adjust the value by 1 day earlier
         */
        } else if (ovrdConsumpPrdSw.isTrue()
                && billSegmentGeneratorData.getHasBillingOption().isFalse()
                && copybookCICBBLST.get_CLOSING_BSEG_SW().isFalse()) {
                
            copybookCICBBSFN = programCIPBBSFN.getCobolCopybookCICBBSFN();
            copybookCICBBSFN.get_INPUT_OUTPUT_WRK().get_CONSUMPTION_PERIOD().set_START_DT(consumptionStartDate);
            copybookCICBBSFN.get_INPUT_OUTPUT_WRK().get_CONSUMPTION_PERIOD().set_END_DT(consumptionEndDate);
            
            moveCICBBLSTToBillSegmentData();
            copybookCICBBLST = programCIPBBSFN.getCobolCopybookCICBBLST();
            moveBillSegmentDataToCICBBLST();
            
            moveCICBSRDCToBillSegmentReadDataList();
            copybookCICBSRDC = programCIPBBSFN.getCobolCopybookCICBSRDC();
            moveBillSegmentReadDataToCICBSRDC();
            
            programCIPBBSFN.callCobol(); // Using ZSQLN, ZSTAT, BBSFN, BBLST, BSRDC, ZMSGN
            
            // Get computed consumption period
            consumptionStartDate = copybookCICBBSFN.get_INPUT_OUTPUT_WRK().get_CONSUMPTION_PERIOD().get_START_DT();
            consumptionEndDate = copybookCICBBSFN.get_INPUT_OUTPUT_WRK().get_CONSUMPTION_PERIOD().get_END_DT();
            
            consumptionEndDate = consumptionEndDate.addDays(-1);
            
        /*
         * Skip manipulation of Consumption End Date for the following scenarios:
         * 1) Override Consumption is set
         * 2) Override Consumption is set and Billing uses the Cut-off Date and is for a closing
         *    Bill Segment
         */
        } else {
            // Skip/Do nothing
        }
        
        // Calculate the consumption days.
        consumptionDays = BigInteger.valueOf(consumptionEndDate.difference(consumptionStartDate).getTotalDays());
        
        /*
         * For non-closing bill segments, if the Consumption Days is less than the Minimum Days 
         * for a Bill Segment, skip the SA
         */
        if (serviceAgreementType.getBillingMinimumDays().compareTo(consumptionDays) > 0
                && serviceAgreementType.getBillingMinimumDays().compareTo(BigInteger.ZERO) > 0
                && copybookCICBBLST.get_CLOSING_BSEG_SW().isFalse()) {
            
            mustSkipServiceAgreement = Bool.TRUE;
            skipSaReason = SkipSaReasonLookup.constants.BILL_SEGMENT_PERIOD_TOO_SHORT;
            exitIterationLoop = ExitIterationLoopLookup.constants.YES;
            return false;
            
        }
        
        return true;
                
    }
    
    /**
     * MA050-BUILD-ITEM-COLL
     * Build Item Collection
     */
    private void buildItemColl() {
        
        copybookCICBBSI1 = programCIPBBSI1.getCobolCopybookCICBBSI1();
        copybookCICBBSI1.get_INPUT_WRK().get_CONSUMPTION_PERIOD().set_START_DT(consumptionStartDate);
        copybookCICBBSI1.get_INPUT_WRK().get_CONSUMPTION_PERIOD().set_END_DT(consumptionEndDate);
        
        // For some reason, this switch is not a cobolBoolField
        if (mustRetainItems.isTrue()) {
            copybookCICBBSI1.get_INPUT_WRK().set_RETAIN_ITEM_COLL_SW("Y");
        } else {
            copybookCICBBSI1.get_INPUT_WRK().set_RETAIN_ITEM_COLL_SW("N");
        }
        
        moveCICBBLSTToBillSegmentData();
        copybookCICBBLST = programCIPBBSI1.getCobolCopybookCICBBLST();
        moveBillSegmentDataToCICBBLST();
        
        // BSITC is set during moveBillSegmentItemDataToCICBSITC
        
        programCIPBBSI1.callCobol(); // Using ZSQLN, ZSTAT, BBSI1, BBLST, BSITC, ZMSGN
        
        copybookCICBSITC = programCIPBBSI1.getCobolCopybookCICBSITC();
        
    }
    
    /**
     * MA070-CHK-ALLOW-AUTO-CAN-BS
     * Check allow auto cancellation of bill segment
     */
    private void chkAllowAutoCanBs() {
        
        // Retrieve installation option
        // Check if Bill Correction Option is Correction Note or Credit Note
        if (CcbInstallationHelper.getCcbInstallationInstance().getBillCorrectionOption().isBlankLookupValue()) {
            return;
        }
        
        /*
         * Retrieve Allow Auto Cancellation of Bill Segment Feature Configuration value. 
         * Do not allow auto cancellation of the bill segments only when the FC value is set
         * to "N". Otherwise, allow cancellation of bill segments.
         */
        // XC070-GET-FC-OPTION
        CmMGEFeatureConfigurationOptionsRetriever cmMGEFeatureConfigurationOptionsRetriever = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
        FeatureConfiguration_Id featureConfigurationId = cmMGEFeatureConfigurationOptionsRetriever.getFeatureConfiguration(ExternalSystemTypeLookup.constants.FINANCIAL_TRANSACTION_OPTIONS);
        String featureOption = cmMGEFeatureConfigurationOptionsRetriever.cmGetFeatOptValue(featureConfigurationId, FinancialTransactionOptionTypeLookup.constants.ALLOW_AUTO_CANCEL_BILL_SEGMENT, Bool.FALSE, Bool.FALSE);
        
        if (isBlankOrNull(featureOption)) {
            return;
        }
        
        if (!"N".equals(featureOption)) {
            return;
        }
        
        allowAutoCancelBs = Bool.FALSE;
        
    }
    
    /**
     * MA080-GET-LATEST-FROZEN-BS
     * Retrieves the latest frozen bill segment
     */
    private void getLatestFrozenBs() {
        
        // XQ120-GET-FRZ-BS
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT BS.BSEG_ID ");
        stringBuilder.append("FROM CI_BSEG BS ");
        stringBuilder.append("WHERE BS.SA_ID = :serviceAgreement ");
        stringBuilder.append("AND BS.BSEG_STAT_FLG = :frozen ");
        stringBuilder.append("ORDER BY BS.START_DT DESC ");
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("serviceAgreement", serviceAgreement.getId());
        preparedStatement.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
        preparedStatement.execute();
        // We only need the latest BS
        SQLResultRow resultRow = preparedStatement.firstRow();
        preparedStatement.close();
        
        BillSegment_Id latestFrozenBillSegment = (BillSegment_Id) resultRow.getId("BS.BSEG_ID", BillSegment.class); 
        
        if (preCnclLatestBsegId.isNull()) {
            preCnclLatestBsegId = latestFrozenBillSegment;
        } else {
            postCnclLatestBsegId = latestFrozenBillSegment;
        }
        
    }
    
    /**
     * MA090-CHECK-OVRD-CONSUMP-PRD-FC
     * Check if there is Feature Config to override the Consumption Period
     */
    private void checkOvrdConsumpPrdFc() {
        
        // XC070-GET-FC-OPTION
        CmMGEFeatureConfigurationOptionsRetriever cmMGEFeatureConfigurationOptionsRetriever = CmMGEFeatureConfigurationOptionsRetriever.Factory.newInstance();
        FeatureConfiguration_Id featureConfigurationId = cmMGEFeatureConfigurationOptionsRetriever.getFeatureConfiguration(ExternalSystemTypeLookup.constants.FINANCIAL_TRANSACTION_OPTIONS);
        String featureOption = cmMGEFeatureConfigurationOptionsRetriever.cmGetFeatOptValue(featureConfigurationId, FinancialTransactionOptionTypeLookup.constants.OVERRIDE_CONSUMPTION_PERIOD, Bool.FALSE, Bool.FALSE);
        
        if (isBlankOrNull(featureOption)) {
            return;
        }
        
        if (featureOption.length() > CharacteristicType_Id.FIELD_SIZE) {
            return;
        }
        
        // XQ130-CHECK-OVRD-CONSUMP-PRD
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT 'X' ");
        stringBuilder.append("FROM CI_SA_TYPE_CHAR ");
        stringBuilder.append("WHERE SA_TYPE_CD = :saType ");
        stringBuilder.append("AND CIS_DIVISION = :cisDivision ");
        stringBuilder.append("AND CHAR_TYPE_CD = :charType ");
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindStringProperty("saType", ServiceAgreementType.properties.saType, serviceAgreement.getServiceAgreementType().getId().getSaType());
        preparedStatement.bindId("cisDivision", serviceAgreement.getServiceAgreementType().getId().getDivisionId());
        preparedStatement.bindId("charType", new CharacteristicType_Id(featureOption));
        
        preparedStatement.execute();
        SQLResultRow result = preparedStatement.firstRow();
        preparedStatement.close();
        
        if (isNull(result)){
            return;
        }
            
        ovrdConsumpPrdSw = Bool.TRUE;
        
    }
    
    /**
     * Move COBOL Copybook information to Java variables
     */
     private void moveCobolInfoToJava() {
         
         moveCICBBLSTToBillSegmentData();
         moveCICBSRDCToBillSegmentReadDataList();
         moveCICBSITCToBillSegmentItemDataList();
         
     }
     
     /**
      * Move CICBBLST copybook to BillSegmentData
      */
     private void moveCICBBLSTToBillSegmentData() {

         BillSegment_DTO billSegmentDto = new BillSegment_DTO();
         billSegmentDto.setId(new BillSegment_Id(copybookCICBBLST.get_BSEG_ID()));
         billSegmentDto.setServiceAgreementId(new ServiceAgreement_Id(copybookCICBBLST.get_SA_ID()));
         billSegmentDto.setIsClosingBillSegment(copybookCICBBLST.get_CLOSING_BSEG_SW());
         billSegmentDto.setIsEstimate(copybookCICBBLST.get_EST_SW());
         billSegmentDto.setStartDate(copybookCICBBLST.get_START_DT());
         billSegmentDto.setEndDate(copybookCICBBLST.get_END_DT());
         if (notBlank(copybookCICBBLST.get_BILL_CYC_CD())) {
             billSegmentDto.setBillCycleScheduleId(new BillCycleSchedule_Id(new BillCycle_Id(copybookCICBBLST.get_BILL_CYC_CD()), copybookCICBBLST.get_WIN_START_DT()));
         }
         billSegmentDto.setCancelReasonId(new BillCancelReason_Id(copybookCICBBLST.get_CAN_RSN_CD()));
         billSegmentDto.setCancelBillSegmentId(new BillSegment_Id(copybookCICBBLST.get_CAN_BSEG_ID()));
         billSegmentDto.setBillId(new Bill_Id(copybookCICBBLST.get_BILL_ID()));
         billSegmentDto.setHasServiceQuantityOverride(copybookCICBBLST.get_SQ_OVERRIDE_SW());
         billSegmentDto.setIsItemOverride(copybookCICBBLST.get_ITEM_OVERRIDE_SW());
         billSegmentDto.setPremiseId(new Premise_Id(copybookCICBBLST.get_PREM_ID()));
         billSegmentDto.setBillSegmentStatus(LookupHelper.getLookupInstance(BillSegmentStatusLookup.class, copybookCICBBLST.get_BSEG_STAT_FLG()));
         billSegmentDto.setCreationDateTime(copybookCICBBLST.get_CRE_DTTM());
         billSegmentDto.setStatusChangeDateTime(copybookCICBBLST.get_STAT_CHG_DTTM());
         billSegmentDto.setReadSequenceId(new BillSegment_Id(copybookCICBBLST.get_REBILL_SEG_ID()));
         billSegmentDto.setMasterBillSegmentId(new BillSegment_Id(copybookCICBBLST.get_MASTER_BSEG_ID()));
         billSegmentDto.setQuoteDetailId(new QuoteDetail_Id(copybookCICBBLST.get_QUOTE_DTL_ID()));
         billSegmentDto.setBillSegmentDataArea(copybookCICBBLST.get_BSEG_DATA_AREA());
         billSegmentDto.setUsageStartDateTime(copybookCICBBLST.get_MDM_START_DTTM());
         billSegmentDto.setUsageEndDateTime(copybookCICBBLST.get_MDM_END_DTTM());
         billSegmentDto.setBillScenarioId(new BillScenario_Id(copybookCICBBLST.get_BILL_SCNR_ID()));
         billSegmentDto.setIlmDate(copybookCICBBLST.get_ILM_DT());
         billSegmentDto.setIsEligibleForArchiving(copybookCICBBLST.get_ILM_ARCH_SW());
         billSegmentData.setBillSegmentDto(billSegmentDto);
         
     }
     
     /**
      * Move CICBSRDC copybook to BillSegmentReadDataList
      */
     private void moveCICBSRDCToBillSegmentReadDataList() {
         
         int readCounter = 0;
         int readCount = copybookCICBSRDC.get_BILL_SEGMENT_READ_CNT().intValue();
         billSegmentReadDataList.clear();
         while (readCounter < readCount) {
             
             BILL_SEGMENT_READ_Row copybookRow = copybookCICBSRDC.get_BILL_SEGMENT_READ().getArrayElement(readCounter);
             BillSegmentReadData readData = BillSegmentReadData.Factory.newInstance();
             BillSegmentRegisterRead_DTO bsReadRegisterDto = new BillSegmentRegisterRead_DTO();
             BillSegmentRegisterRead_Id id = new BillSegmentRegisterRead_Id(billSegmentData.getBillSegmentDto().getId(), copybookRow.get_SP_ID(), copybookRow.get_SEQNO());
             bsReadRegisterDto.setId(id);
             bsReadRegisterDto.setRegisterConstant(copybookRow.get_REG_CONST());
             bsReadRegisterDto.setHowToUseRead(LookupHelper.getLookupInstance(HowToUseReadLookup.class, copybookRow.get_USAGE_FLG()));
             bsReadRegisterDto.setUsePercent(copybookRow.get_USE_PCT());
             bsReadRegisterDto.setHowToUse(LookupHelper.getLookupInstance(HowToUseLookup.class, copybookRow.get_HOW_TO_USE_FLG()));
             bsReadRegisterDto.setMeasuresPeakQuantity(copybookRow.get_MSR_PEAK_QTY_SW());
             bsReadRegisterDto.setUnitOfMeasureId(new UnitOfMeasure_Id(copybookRow.get_UOM_CD()));
             bsReadRegisterDto.setTimeOfUseId(new TimeOfUse_Id(copybookRow.get_TOU_CD()));
             bsReadRegisterDto.setServiceQuantityIdentifierId(new ServiceQuantityIdentifier_Id(copybookRow.get_SQI_CD()));
             bsReadRegisterDto.setStartRegisterReadId(new RegisterRead_Id(copybookRow.get_START_REG_READ_ID()));
             bsReadRegisterDto.setStartReadDateTime(copybookRow.get_START_READ_DTTM());
             bsReadRegisterDto.setStartRegisterReading(copybookRow.get_START_REG_READING());
             bsReadRegisterDto.setEndRegisterReadingId(new RegisterRead_Id(copybookRow.get_END_REG_READ_ID()));
             bsReadRegisterDto.setEndReadDateTime(copybookRow.get_END_READ_DTTM());
             bsReadRegisterDto.setEndRegisterReading(copybookRow.get_END_REG_READING());
             bsReadRegisterDto.setMeasuredQuantity(copybookRow.get_MSR_QTY());
             bsReadRegisterDto.setFinalUnitOfMeasureId(new UnitOfMeasure_Id(copybookRow.get_FINAL_UOM_CD()));
             bsReadRegisterDto.setFinalTimeOfUseId(new TimeOfUse_Id(copybookRow.get_FINAL_TOU_CD()));
             bsReadRegisterDto.setFinalServiceQuantityId(new ServiceQuantityIdentifier_Id(copybookRow.get_FINAL_SQI_CD()));
             bsReadRegisterDto.setRegisterQuantity(copybookRow.get_FINAL_REG_QTY());
         
             readData.setBillSegmentReadDto(bsReadRegisterDto);
             billSegmentReadDataList.add(readData);
             readCounter++;
             
         }
         
     }
     
     /**
      * Move CICBSITC copybook to BillSegmentItemDataList
      */
     private void moveCICBSITCToBillSegmentItemDataList() {
         
         BillSegment_DTO billSegmentDto = billSegmentData.getBillSegmentDto();
         int itemCounter = 0;
         int itemCount = copybookCICBSITC.get_BILL_SEGMENT_ITEM_CNT().intValue();
         billSegmentItemDataList.clear();
         while(itemCounter < itemCount){
             BILL_SEGMENT_ITEM_Row copybookRow = copybookCICBSITC.get_BILL_SEGMENT_ITEM().getArrayElement(itemCounter);
             BillSegmentItemData itemData = BillSegmentItemData.Factory.newInstance();
             BillSegmentItem_DTO bsItemDto = new BillSegmentItem_DTO();
             BillSegmentItem_Id id = new BillSegmentItem_Id(billSegmentDto.getId(), copybookRow.get_SEQNO());
             bsItemDto.setId(id);
             bsItemDto.setItemType(copybookRow.get_ITEM_TYPE_CD());
             bsItemDto.setItemId(new Item_Id(copybookRow.get_ITEM_ID()));
             bsItemDto.setStartDate(copybookRow.get_START_DT());
             bsItemDto.setEndDate(copybookRow.get_END_DT());
             bsItemDto.setItemCount(copybookRow.get_ITEM_CNT());
             bsItemDto.setUnitOfMeasureId(new UnitOfMeasure_Id(copybookRow.get_UOM_CD()));
             bsItemDto.setDailyServiceQuantity(copybookRow.get_SVC_QTY());
             
             itemData.setBillSegmentItemDto(bsItemDto);
             billSegmentItemDataList.add(itemData); 
             itemCounter++;
         }
         
     }
    
    /*
     * End Add - Defect 3803911 - 2017-09-04
     */

    /**
     * This method will validate the input day value valid for the given month.
     * @param endDate
     * @return int
     */
    private int getIsValidDayOfMonth(Date endDate) {
        /*
         * Start Change - CCB004.Defect8 - 2021-07-26
         */
        //int dayOfMonth = getDayOfMonthForBillSegmentPeriodEnd().intValue();
        int dayOfMonth = dayOfMonthForBillSegmentPeriodEnd.intValue();
        /*
         * End Change - CCB004.Defect8 - 2021-07-26
         */
        try{
            new DayInMonth(endDate.getMonth(), dayOfMonth);            
        } catch (IllegalArgumentException e) {
            addError(CustomMessageRepository.SA_212480_InvalidDayOfMonth(getDayOfMonthForBillSegmentPeriodEnd(), getAlgorithmId().getTrimmedValue(), endDate.getMonthValue().toString()));
        }
        return dayOfMonth;
    }

    @Override
	public BillSegmentData getBillSegmentData() {
		return billSegmentData;
	}

	@Override
	public BillSegmentGeneratorData getBillSegmentGeneratorData() {
		return billSegmentGeneratorData;
	}

	@Override
	public List<BillSegmentItemData> getBillSegmentItemData() {
		return billSegmentItemDataList;
	}

	@Override
	public List<BillSegmentReadData> getBillSegmentReadData() {
		return billSegmentReadDataList;
	}

	@Override
	public List<BillSegmentServiceQuantityData> getBillSegmentServiceQuantityData() {
		return billSegmentServiceQuantityDataList;
	}

	@Override
	public Date getConsumptionEndDate() {
		return consumptionEndDate;
	}

	@Override
	public Date getConsumptionStartDate() {
		return consumptionStartDate;
	}

	@Override
	public ExitIterationLoopLookup getExitLoopCheck() {
		return exitIterationLoop;
	}

	@Override
	public Bool getIsCalledFromUsage() {
		return isCalledFromUsage;
	}

	@Override
	public Bool getIsRestartGeneration() {
		return mustRestartGeneration;
	}

	@Override
	public Bool getMustSkipServiceAgreement() {
		return mustSkipServiceAgreement;
	}

	@Override
	public SkipSaReasonLookup getSkipSaReason() {
		return skipSaReason;
	}

	@Override
	public ServerMessage getSkipSaReasonMessage() {
		return null;
	}

	@Override
	public Usage getUsage() {
		return usage;
	}

	@Override
	public void setBillSegmentData(BillSegmentData arg0) {
		billSegmentData = arg0;
	}

	@Override
	public void setBillSegmentGeneratorData(BillSegmentGeneratorData arg0) {
		billSegmentGeneratorData = arg0;
	}

	@Override
	public void setBillSegmentItemData(List<BillSegmentItemData> arg0) {
		billSegmentItemDataList = arg0;
	}

	@Override
	public void setBillSegmentReadData(List<BillSegmentReadData> arg0) {
		billSegmentReadDataList = arg0;
	}

	@Override
	public void setBillSegmentServiceQuantityData(
			List<BillSegmentServiceQuantityData> arg0) {
		billSegmentServiceQuantityDataList = arg0;
	}

	@Override
	public void setConsumptionEndDate(Date arg0) {
		consumptionEndDate = arg0;
	}

	@Override
	public void setConsumptionStartDate(Date arg0) {
		consumptionStartDate = arg0;
	}

	@Override
	public void setIsCalledFromUsage(Bool arg0) {
		isCalledFromUsage = arg0;
	}

	@Override
	public void setMustRetainItemCollection(Bool arg0) {
		mustRetainItems = arg0;
	}

	@Override
	public void setMustRetainReadCollection(Bool arg0) {
		mustRetainReads = arg0;
	}

	@Override
	public void setMustRetainSQCollection(Bool arg0) {
		mustRetainServiceQuantities = arg0;
	}

	@Override
	public void setMustSkipServiceAgreement(Bool arg0) {
		mustSkipServiceAgreement = arg0;
	}

	@Override
	public void setPreviousFrozenBillSegment(BillSegment arg0) {
	    previousFrozenBillSegment = arg0;
	}

	@Override
	public void setServiceAgreement(ServiceAgreement arg0) {
		serviceAgreement = arg0;
	}

	@Override
	public void setSkipSaReason(SkipSaReasonLookup arg0) {
		skipSaReason = arg0;
	}

	@Override
	public void setUsage(Usage arg0) {
		usage = arg0;
	}

}
