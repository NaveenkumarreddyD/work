/************************************************************************************************
 * Program Name: CmConsBillComplete_AlgComp_Impl
 * Program Title: CmConsBillComplete_AlgComp_Impl
 * Author: Jain Akshita
 * Creation Date: 2019-08-01
 * Purpose: The algorithm type will execute when the system attempts to complete a bill for the 
 * consolidated tax SA. It is responsible for recalculating historic consolidated tax bill 
 * segments. This is needed if any of the account gas bill segments undergo cancel/rebill. 
 * The Consolidated Tax SA Type Characteristic Type and Characteristic Value are used to 
 * identify consolidated tax service agreements during billing. 
 * 
 ************************************************************************************************/
/*----------------------------------------------------------------------------------------
 *-------------------------- Modification HISTORY: ---------------------------------------
 * ---------------------------------------------------------------------------------------
 * Modification ID:   CCTicket:	  Author:          Date:       Description:
.* --------------------------------------------------------------------------------------
 * CCB003  	       	  45992   	 Jain Akshita     2019-08-01   TMG02493 - Initial Version    
 * D-01889                       Joshua Ace Vitug 2020-03-02   D-01889 - Initial Version             
 * CCB003_Issue2                 Nino Mendoza     2020-04-01   CCB003_Issue2. Updated getFtForCurrentBill
 *                                                             to sweep all FT regardless of Parent ID.
 * CCB003_Issue3                 Nino Mendoza     2020-04-24   CCB003_Issue3. Updated getFtForCurrentBill
 *                                                             to sweep FT for current bill when it has
 *                                                             bill segment cancellation only.
 ************************************************************************************************/

package com.splwg.cm.domain.admin.serviceAgreementType;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.splwg.base.api.businessService.BusinessServiceDispatcher;
import com.splwg.base.api.businessService.BusinessServiceInstance;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.common.message.MessageCategory_Id;
import com.splwg.base.domain.common.message.MessageParameters;
import com.splwg.base.domain.common.message.ServerMessageFactory;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.FinancialTransactionTypeLookup;
import com.splwg.ccb.domain.admin.billCancelReason.entity.BillCancelReason;
import com.splwg.ccb.domain.admin.billCycle.entity.BillCycle;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.preBillCompletion.SaTypePreBillCompletionAlgorithmSpot;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementTypeCharacteristic;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.shared.common.ServerMessage;

/**
 * @author TMG02493
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (entityName = characteristicType, name = consTaxSaTypCharType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = consTaxCharVal, required = true, type = string)
 *            , @AlgorithmSoftParameter (entityName = billCancelReason, name = billCancelReason, required = true, type = entity)})
 */
public class CmConsBillComplete_AlgComp_Impl extends
CmConsBillComplete_AlgComp_Gen implements
SaTypePreBillCompletionAlgorithmSpot {

	//hard parameter
	private Account_Id parmAccountId;
	private Bill parmBill;

	//soft parameteres
	private CharacteristicType parmConsTaxSaTypCharType;
	private String parmConsTaxCharVal;
	private BillCancelReason parmBillCancelReason;

	//work variables
	private List<Bill_Id> parentBillIdList;
	private String consoloidatedTaxBsegId;
	private Date consoloidatedTaxBsegEndDate;

	//Constants
	private BigInteger INV_CHAR_VAL_CAT_NUM = BigInteger.valueOf(2);
	private int INV_CHAR_VAL_MSG_NUM = 60903;

	@Override
	protected void extraSoftParameterValidations() {
		parmConsTaxSaTypCharType=getConsTaxSaTypCharType();
		parmConsTaxCharVal= getConsTaxCharVal();
		parmBillCancelReason= getBillCancelReason();
		
		//Using the Base Error Messages
		MessageCategory_Id invCharValMsgCatId = new MessageCategory_Id(INV_CHAR_VAL_CAT_NUM);
		ServerMessageFactory serverMessagesFactory = ServerMessageFactory.Factory.newInstance();
		MessageParameters messageParameters = new MessageParameters();

		//Check if char val is a vaid value for given char type
		CharacteristicValue charVal = new CharacteristicValue_Id(parmConsTaxSaTypCharType, parmConsTaxCharVal).getEntity();
		if (isNull(charVal))
		{
			// Add Error - The Characteristic Value %1 is not a valid value for Characteristic Type %2. 
			messageParameters.addRawString(parmConsTaxCharVal);
			messageParameters.addRawString(parmConsTaxSaTypCharType.getId().getIdValue());
			ServerMessage invCharValServerMsg = serverMessagesFactory.createMessage(invCharValMsgCatId, INV_CHAR_VAL_MSG_NUM, messageParameters);
			addError(invCharValServerMsg);
		}

	}
	
	@Override
	public void invoke() {

		//Get all the bill segment FT that will be swept on this bill
		parentBillIdList= getFtForCurrentBill();

		for(Bill_Id billId : parentBillIdList){
			//Get tax consolidated bill segment 
			SQLResultRow consolidatedBsegDetailsRow= getConsolidatedTaxBseg(billId);
			if(notNull(consolidatedBsegDetailsRow))
			{
				consoloidatedTaxBsegId= consolidatedBsegDetailsRow.getString("BSEG_ID");
				consoloidatedTaxBsegEndDate= consolidatedBsegDetailsRow.getDate("END_DT");

				//Cancel and Rebill
				BusinessServiceInstance cancelRebillBseg = BusinessServiceInstance.create("C1-CancelRebillFreezeBillSegs");

				cancelRebillBseg.getFieldAndMDForPath("input/billSegmentId").setXMLValue(consoloidatedTaxBsegId);
				cancelRebillBseg.getFieldAndMDForPath("input/cancelReason").setXMLValue(parmBillCancelReason.getId().getIdValue());
				cancelRebillBseg.getFieldAndMDForPath("input/cutoffDate").setXMLValue(consoloidatedTaxBsegEndDate.toString());
				BusinessServiceDispatcher.execute(cancelRebillBseg); 
			}
		}
	}

	/* This method retrieves all the bill segment FT parent id (Bill Id)
	 * that will be swept on this bill
	 */
	private List<Bill_Id> getFtForCurrentBill()
	{

		StringBuilder retBillStr = new StringBuilder("SELECT DISTINCT FT.PARENT_ID");
		retBillStr.append(" FROM CI_FT FT");
		retBillStr.append(" WHERE FT.SA_ID IN (SELECT SA_ID FROM CI_SA WHERE ACCT_ID = :accountId)");
		retBillStr.append(" AND FT.BILL_ID = ' '");
		retBillStr.append(" AND FT.FT_TYPE_FLG IN (:billSegment, :billSegmentCancel)");
		retBillStr.append(" AND FT.FREEZE_SW = :freezeSw");
		//Start Delete NMendo - CCB003_Issue2 - 2020-04-01
		//Start Change JVitug - D-01889 - 2020-03-02
		//retBillStr.append(" AND FT.PARENT_ID <> :currentBill");
		//retBillStr.append(" AND FT.PARENT_ID = :currentBill");
		//End Change JVitug - D-01889 - 2020-03-02
		//End Delete NMendo - CCB003_Issue2 - 2020-04-01
		//Start Add NMendo - CCB003_Issue3 - 2020-04-24
		retBillStr.append(" AND FT.PARENT_ID <> :currentBill");
		retBillStr.append(" UNION ALL");
		retBillStr.append(" SELECT DISTINCT FT.PARENT_ID");
		retBillStr.append(" FROM CI_FT FT");
		retBillStr.append(" WHERE FT.SA_ID IN (SELECT SA_ID FROM CI_SA WHERE ACCT_ID = :accountId)");
		retBillStr.append(" AND FT.BILL_ID = ' '");
		retBillStr.append(" AND FT.FT_TYPE_FLG IN (:billSegmentCancel)");
		retBillStr.append(" AND FT.FREEZE_SW = :freezeSw");
		retBillStr.append(" AND FT.PARENT_ID = :currentBill");
		//Start Add NMendo - CCB003_Issue3 - 2020-04-24

		PreparedStatement retBillPrepStmt= createPreparedStatement(retBillStr.toString(), "Retrieve parent bill id list");
		retBillPrepStmt.bindId("accountId", parmAccountId);
		retBillPrepStmt.bindLookup("billSegment", FinancialTransactionTypeLookup.constants.BILL_SEGMENT);
		retBillPrepStmt.bindLookup("billSegmentCancel", FinancialTransactionTypeLookup.constants.BILL_CANCELLATION);
		retBillPrepStmt.bindBoolean("freezeSw", Bool.TRUE);
		retBillPrepStmt.bindId("currentBill", parmBill.getId());

		retBillPrepStmt.setAutoclose(false);

		List<SQLResultRow> billList= retBillPrepStmt.list();
		List<Bill_Id> parentBillIdList = new ArrayList<Bill_Id>();

		for(SQLResultRow sqlResultRow : billList)
		{
			Bill_Id billId= new Bill_Id(sqlResultRow.getString("PARENT_ID"));
			parentBillIdList.add(billId);

		}
		retBillPrepStmt.close();
		return parentBillIdList;
	}
	/* This method fetch the consolidated tax bill segment id and end date
	 * 
	 */
	private SQLResultRow getConsolidatedTaxBseg(Bill_Id billId)
	{
		StringBuilder retBSegStr = new StringBuilder("SELECT BSEG.BSEG_ID,BSEG.END_DT");
		retBSegStr.append(" FROM CI_BSEG BSEG, CI_SA SA, CI_SA_TYPE_CHAR SACHAR");
		retBSegStr.append(" WHERE BSEG.BILL_ID = :billId");
		retBSegStr.append(" AND BSEG.BSEG_STAT_FLG = :frozenBsegStatus");
		retBSegStr.append(" AND BSEG.SA_ID = SA.SA_ID");
		retBSegStr.append(" AND SA.CIS_DIVISION = SACHAR.CIS_DIVISION");
		retBSegStr.append(" AND SA.SA_TYPE_CD = SACHAR.SA_TYPE_CD ");
		retBSegStr.append(" AND SACHAR.CHAR_TYPE_CD = :consTaxSaTypCharType");
		retBSegStr.append(" AND SACHAR.CHAR_VAL = :consTaxCharVal");

		PreparedStatement retBSegPrepStmt= createPreparedStatement(retBSegStr.toString(), "Retrieve consolidated tax bill segment");
		retBSegPrepStmt.bindId("billId", billId);
		retBSegPrepStmt.bindLookup("frozenBsegStatus", BillSegmentStatusLookup.constants.FROZEN);
		retBSegPrepStmt.bindId("consTaxSaTypCharType", parmConsTaxSaTypCharType.getId());
		retBSegPrepStmt.bindStringProperty("consTaxCharVal",ServiceAgreementTypeCharacteristic.properties.characteristicValue, parmConsTaxCharVal.trim());
		
		retBSegPrepStmt.setAutoclose(false);

		SQLResultRow consBillId= retBSegPrepStmt.firstRow();
		retBSegPrepStmt.close();
		return consBillId;
	}


	@Override
	public Bool getShouldSkipRemainingAlgorithms() {

		return null;
	}

	@Override
	public void setBill(Bill bill) {
		parmBill=bill;
		parmAccountId= bill.getAccount().getId();

	}

	@Override
	public void setBillCycle(BillCycle arg0) {


	}

	@Override
	public void setEndDate(Date arg0) {


	}

	@Override
	public void setServiceAgreementType(ServiceAgreementType arg0) {


	}

	@Override
	public void setStartDate(Date arg0) {


	}

}
