/* *************************************************************************************************
 * PROGRAM DESCRIPTION
 *
 * E-06783.1 - Start / Stop Fieldwork Creation with ADDP integration
 *
 * Description
 *
 * This algorithm will be used to encompass current processes as well as contain the new logic for 
 * obtaining readings from ADDP for ITRON/Ultrasonic meters. If the SP is an I-TRON route this 
 * algorithm will create a non-dispatchable FA Type to obtain the reads from ADDP. It will sit in 
 * a Pending status until a read can be obtained since ADDP gets reads for the past 40 days, 
 * once per month. So, when the billing read is obtained based on the bill cycle, the daily reads 
 * for the prior 40 days are also loaded into ADDP. At this time this non-dispatchable FA will be 
 * completed with the available read.
 *
 ***************************************************************************************************
 *
 * CHANGE HISTORY
 *
 * Date:        by:              Reason:
 * YYYY-MM-DD   IN               Reason text.
 *
 * 2023-09-05   JVitug           E06783.1. Initial Version.
 * 2023-11-29   JVitug           E06783.Issue1. Updated to now always create the FA using the FA Type
 * 								 from the fifth parameter when the SP's service cycle is equal to
 * 								 any of the Service Route Types in that parameter.
 * 2023-12-06   CAtila / JVitug  D-03523. Updated the date used if back to back and  
 * 								 if the Pending Stop SA's end date is before the new SA's start date.
 * 								 The new SA's FA schedule date is now the new SA's start date. Also
 * 								 included the fix made via E06783_005 package. 
 * 2023-12-11   JVitug           E-06783.Issue2. Added additional criteria when cancelling Pending SAs linked to 
 * 								 a landlord account.
 * 2024-01-09   JVitug           E-06783.Issue3. Updated to now store the SA/SP of the SA linked to 
 *                               landlord SA to be used when creating a SA/SP record for the second FA.
 * 2024-02-01   JVitug           E-06783.7. Updated on how to create the To Do to cater the configuration
 * 								 change made to the To Do Type.           
 **************************************************************************************************/
package com.splwg.cm.domain.admin.serviceAgreementType;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateTime;
import com.splwg.base.api.datatypes.Time;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicType_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.base.domain.todo.role.Role;
import com.splwg.base.domain.todo.toDoEntry.ToDoCreator;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoType.ToDoDrillKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoSortKeyType;
import com.splwg.base.domain.todo.toDoType.ToDoTypeRole_Id;
import com.splwg.ccb.api.lookup.BillStatusLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.FieldActivityCreatedByLookup;
import com.splwg.ccb.api.lookup.FieldActivityStatusLookup;
import com.splwg.ccb.api.lookup.FieldOrderStatusLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementSpFaTypeLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.ServicePointFieldConditionLookup;
import com.splwg.ccb.api.lookup.SeveranceStatusLookup;
import com.splwg.ccb.domain.admin.fieldActivityType.entity.FieldActivityType;
import com.splwg.ccb.domain.admin.meterLocation.entity.MeterLocation;
import com.splwg.ccb.domain.admin.meterLocation.entity.MeterLocation_Id;
import com.splwg.ccb.domain.admin.meterReadCycle.entity.MeterReadRoute;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType;
import com.splwg.ccb.domain.admin.meterReadRouteType.entity.MeterReadRouteType_Id;
import com.splwg.ccb.domain.admin.serviceAgreementType.algorithm.saSpFieldWorkCreation.SaTypeSaSpFieldWorkCreationAlgorithmSpot;
import com.splwg.ccb.domain.customerinfo.account.entity.Account_Id;
import com.splwg.ccb.domain.customerinfo.data.SaSpFieldActivityCreatorData;
import com.splwg.ccb.domain.customerinfo.landlord.entity.Landlord;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementServicePoint_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementSpFieldActivity_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_DTO;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePoint;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic;
import com.splwg.ccb.domain.fieldorder.common.FieldActivityCreator;
import com.splwg.ccb.domain.fieldorder.data.FieldActivityCreatorData;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_DTO;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristic_Id;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivityCharacteristics;
import com.splwg.ccb.domain.fieldorder.fieldActivity.entity.FieldActivity_DTO;
import com.splwg.ccb.domain.todo.toDoType.entity.ToDoType;
import com.splwg.cm.api.lookup.CustomerEventLookup;
import com.splwg.cm.domain.common.customBusinessComponent.CmCancelUnlinkFasOfSaSp;
import com.splwg.cm.domain.common.customBusinessComponent.CmCancelUnlinkFasOfSaSpData;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 * @author JVitug
 *
 @AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = numberOfDaysLeadTime, required = true, type = integer)
 *            , @AlgorithmSoftParameter (name = backToBackThresholdDays, required = true, type = integer)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = nonDispatchableFATypeForMeterRead, required = true, type = entity)
 *            , @AlgorithmSoftParameter (lookupName = servicePointFieldCondition, name = spsDesiredStateForMeterRead, required = true, type = lookup)
 *            , @AlgorithmSoftParameter (name = excludedRouteTypes, type = string)
 *            , @AlgorithmSoftParameter (name = excludeMeterLocations, type = string)
 *            , @AlgorithmSoftParameter (name = immediateFaCreation, required = true, type = boolean)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = powerStatusCharacteristicType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = powerStatusCharacteristicValue, type = string, required = true)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = dispatchableFATypeForMeterRead, required = true, type = entity)
 *            , @AlgorithmSoftParameter (name = brightlyncServiceRouteTypes, type = string)
 *            , @AlgorithmSoftParameter (name = nonLGAMRserviceRouteTypes, type = string, required = true)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = nonDispatchableFATypeItronUltrasonicServiceRoutes, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = faCharacteristicTypeItronUltrasonicServiceRoute, required = true, type = entity)
 *           , @AlgorithmSoftParameter (entityName = fieldActivityType, name = mStopFAType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = fieldActivityType, name = mOnFAType, required = true, type = entity)
 *            , @AlgorithmSoftParameter (entityName = toDoType, name = cancelPendingLandlordToDoType , type = entity)
 *            , @AlgorithmSoftParameter (entityName = role, name = todoRole, type = entity)})
 *
 */

public class CmADDPStartStopFieldworkCreationAlgComp_Impl extends
		CmADDPStartStopFieldworkCreationAlgComp_Gen implements
        SaTypeSaSpFieldWorkCreationAlgorithmSpot {

    // Constants
    private static final String COMMA_DELIMITER = ",";

    // Soft parameters
    private BigInteger numberOfDaysLeadTime;
    private BigInteger backToBackThresholdDays;
    private Bool immediateFaCreation;
    private CharacteristicType  powerStatusCharacteristicType;
    private CharacteristicType faCharacteristicTypeItronUltrasonicServiceRoute;
    private FieldActivityType dispatchableFATypeForMeterRead;
    private FieldActivityType nonDispatchableFATypeForMeterRead;
    private FieldActivityType nonDispatchableFATypeItronUltrasonicServiceRoutes;
    private FieldActivityType mStopFAType;
    private FieldActivityType mOnFAType;
    private ServicePointFieldConditionLookup spsDesiredStateForMeterRead;
    private List<MeterReadRouteType> excludedRouteTypes = new ArrayList<MeterReadRouteType>();
    private List<MeterReadRouteType> nonLGAMRserviceRouteTypes = new ArrayList<MeterReadRouteType>();
    private List<MeterReadRouteType> brightlyncServiceRouteTypes = new ArrayList<MeterReadRouteType>();
    private List<MeterLocation> excludedMeterLocationsList = new ArrayList<MeterLocation>();
    private String powerStatusCharacteristicValue;
    private ToDoType todoType;
    private Role todoRole;
    
    // Hard parameters - input
    private ServiceAgreementSpFaTypeLookup saSpFieldActivityType;
    private DateTime saSpStartDateTime;
    private DateTime saSpStopDateTime;
    @SuppressWarnings("unused")
    private Date saStartDate;
    @SuppressWarnings("unused")
    private Date saStopDate;
    private ServiceAgreement serviceAgreement;
    private ServiceAgreementServicePoint serviceAgreementServicePoint;
    private ServicePoint servicePoint;
    private Bool shouldActivateManually;

    // Hard parameters - input/output
    private Bool isFaCreated;

    // Working variables
    private Bool isBackToBack = Bool.FALSE;
    private DateTime leastStopDateTime;
    private DateTime scheduleDateTime;
    private FieldActivity fa1;
    private FieldActivity fa2;
    Bool hasCreatedFA2 =  Bool.FALSE;
    ServiceAgreementServicePoint futureStoppedPendingStopSASP;
    ServiceAgreementServicePoint backToBackSASP;
    DateFormat dateFormat = new DateFormat("yyyy-MM-dd");
    //Start Add JVitug - E06783.Issue3 - 2024-01-09
    ServiceAgreementServicePoint pendingStopSASPLinkedToLandlordSA = null;
    //End Add JVitug - E06783.Issue3 - 2024-01-09
    
    //Start Add JVitug - E-06783.7 - 2024-02-01
    CharacteristicType premiseCharType = new CharacteristicType_Id("PREMISE").getEntity(); 
    //End Add JVitug - E-06783.7 - 2024-02-01

    // Common component
    private CmCancelUnlinkFasOfSaSp cancelUnlinkFasOfSaSp = CmCancelUnlinkFasOfSaSp.Factory.newInstance();

    public void setSaSpFieldActivityType(ServiceAgreementSpFaTypeLookup saSpFieldActivityType) {
        this.saSpFieldActivityType = saSpFieldActivityType;
    }

    public void setSaSpStartDateTime(DateTime saSpStartDateTime) {
        this.saSpStartDateTime = saSpStartDateTime;
    }

    public void setSaSpStopDateTime(DateTime saSpStopDateTime) {
        this.saSpStopDateTime = saSpStopDateTime;
    }

    public void setSaStartDate(Date saStartDate) {
        this.saStartDate = saStartDate;
    }

    public void setSaStopDate(Date saStopDate) {
        this.saStopDate = saStopDate;
    }

    public void setServiceAgreement(ServiceAgreement serviceAgreement) {
        this.serviceAgreement = serviceAgreement;
    }

    public void setServiceAgreementServicePoint(ServiceAgreementServicePoint serviceAgreementServicePoint) {
        this.serviceAgreementServicePoint = serviceAgreementServicePoint;
    }

    public void setServicePoint(ServicePoint servicePoint) {
        this.servicePoint = servicePoint;
    }

    public void setShouldActivateManually(Bool shouldActivateManually) {
        this.shouldActivateManually = shouldActivateManually;
    }

    public void setFaCreated(Bool isFaCreated) {
        this.isFaCreated = isFaCreated;
    }

    public Bool getIsFaCreated() {
        return this.isFaCreated;
    }

    @Override
    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {
    	numberOfDaysLeadTime = getNumberOfDaysLeadTime();
        backToBackThresholdDays = getBackToBackThresholdDays();
        immediateFaCreation = getImmediateFaCreation();
        powerStatusCharacteristicType = getPowerStatusCharacteristicType();
        powerStatusCharacteristicValue = getPowerStatusCharacteristicValue().trim();
        faCharacteristicTypeItronUltrasonicServiceRoute = getFaCharacteristicTypeItronUltrasonicServiceRoute();
        dispatchableFATypeForMeterRead = getDispatchableFATypeForMeterRead();
        nonDispatchableFATypeForMeterRead = getNonDispatchableFATypeForMeterRead();
        nonDispatchableFATypeItronUltrasonicServiceRoutes = getNonDispatchableFATypeItronUltrasonicServiceRoutes();
        spsDesiredStateForMeterRead = getSpsDesiredStateForMeterRead();
        mStopFAType = getMStopFAType();
        mOnFAType = getMOnFAType();
        todoType = getCancelPendingLandlordToDoType();
        todoRole = getTodoRole();
        
        //String Array to get the list of Route types to be validated later
        String[] routeTypesArray;
    	
        String routeTypesValidator = getExcludedRouteTypes();
        if (notBlank(routeTypesValidator)) {

            routeTypesArray = routeTypesValidator.split(COMMA_DELIMITER);

            for (String routeType : routeTypesArray) {

                if (routeType.trim().length() > MeterReadRouteType_Id.FIELD_SIZE) {
                	addError(CustomMessageRepository.E06783_invalidRouteType("Excluded Route Types" ,routeType));
                }

                MeterReadRouteType_Id meterReadRouteTypeId = new MeterReadRouteType_Id(routeType.trim());
                if (isNull(meterReadRouteTypeId.getEntity())) {
                    addError(CustomMessageRepository.E06783_invalidRouteType("Excluded Route Types" ,routeType));
                }

                excludedRouteTypes.add(meterReadRouteTypeId.getEntity());
            } 
        }

        String excludeMeterLocations = getExcludeMeterLocations();
        if (notBlank(excludeMeterLocations)) {

            String[] excludeMeterLocationList = excludeMeterLocations.split(COMMA_DELIMITER);

            for (String excludedMeterLocationIdString : excludeMeterLocationList) {

                if (excludedMeterLocationIdString.trim().length() > MeterLocation_Id.FIELD_SIZE) {
                    addError(CustomMessageRepository.E06783_invalidMeterLocation(excludedMeterLocationIdString));
                }

                MeterLocation_Id meterLocationId = new MeterLocation_Id(excludedMeterLocationIdString.trim());
                if (isNull(meterLocationId.getEntity())) {
                	addError(CustomMessageRepository.E06783_invalidMeterLocation(excludedMeterLocationIdString));
                }

                excludedMeterLocationsList.add(meterLocationId.getEntity());
            }
        }
        
        //Validate the BrightLync Service Route Types
        routeTypesValidator = getBrightlyncServiceRouteTypes();
        if (notBlank(routeTypesValidator)) {

            routeTypesArray = routeTypesValidator.split(COMMA_DELIMITER);

            for (String routeType : routeTypesArray) {

                if (routeType.trim().length() > MeterReadRouteType_Id.FIELD_SIZE) {
                    addError(CustomMessageRepository.E06783_invalidRouteType("Non-LGAMR Service Route Types" ,routeType));
                }

                MeterReadRouteType_Id meterReadRouteTypeId = new MeterReadRouteType_Id(routeType.trim());
                if (isNull(meterReadRouteTypeId.getEntity())) {
                    addError(CustomMessageRepository.E06783_invalidRouteType("BrightLync Service Route Types" ,routeType));
                }

                brightlyncServiceRouteTypes.add(meterReadRouteTypeId.getEntity());
            }
        }
        
        //Validate the non-LGAMR Service Route Types
        routeTypesValidator = getNonLGAMRserviceRouteTypes();
        if (notBlank(routeTypesValidator)) {

        	routeTypesArray = routeTypesValidator.split(COMMA_DELIMITER);

        	for (String routeType : routeTypesArray) {

        		if (routeType.trim().length() > MeterReadRouteType_Id.FIELD_SIZE) {
        			addError(CustomMessageRepository.E06783_invalidRouteType("Non-LGAMR Service Route Types" ,routeType));
        		}

        		MeterReadRouteType_Id meterReadRouteTypeId = new MeterReadRouteType_Id(routeType.trim());
        		if (isNull(meterReadRouteTypeId.getEntity())) {
        			addError(CustomMessageRepository.E06783_invalidRouteType("Non-LGAMR Service Route Types" ,routeType));
        		}

        		nonLGAMRserviceRouteTypes.add(meterReadRouteTypeId.getEntity());
        	}
        }

        //Validate Power Status Characteristic Type
        CharacteristicEntity validateCharType = null;
        validateCharType = new CharacteristicEntity_Id(powerStatusCharacteristicType, CharacteristicEntityLookup.constants.SERVICE_POINT).getEntity();
        
        if (isNull(validateCharType)) {
        	addError(CustomMessageRepository.E06783_invalidCharacteristicForServicePointEntity(powerStatusCharacteristicType.getId().getTrimmedValue()));
        }
        
        //Validate that the Power Status Characteristic Value is valid for the Power Status Characteristic Type
        CharacteristicValue charValueValidator = new CharacteristicValue_Id(powerStatusCharacteristicType , powerStatusCharacteristicValue.trim()).getEntity();
        
        if(isNull(charValueValidator)) {
        	addError(CustomMessageRepository.E06783_invalidCharacteristicValueForCharacteristicType(powerStatusCharacteristicValue.trim() , powerStatusCharacteristicType.getId().getTrimmedValue()));
        }
        
        super.extraSoftParameterValidations(forAlgorithmValidation);
        
        
        if(notNull(todoType) && notNull(todoRole)) {
        	ToDoTypeRole_Id toDoTypeRoleId = new ToDoTypeRole_Id(todoType, todoRole);
			if(isNull(toDoTypeRoleId.getEntity())) {
				addError(CustomMessageRepository.E06783_invalidToDoRoleForToDoType(todoRole.getId().getTrimmedValue(), todoType.getId().getTrimmedValue()));
			}
        }
    }

    /**
     * GA000
     */
    public void invoke() {
        // Decide if it is time to create the FA
        decideIfTooEarly();

        // Process the pending start/stop SA/SP for the SP
        checkPendingStartStop();

        // Process the pending start/stop SA/SP for same SP type
        checkPendingStartStopForSameSpType();
        
        // Determine if Back-To-Back situation exists
        checkForBackToBack();
        
        if (shouldActivateManually.isFalse()) {
            // Create Field Activity and Field Activity Steps for SA/SP
            processServiceAgreementServicePoint();

            // Link newly created pending Field Activity
            processFieldActivity();

        } else {
            if (immediateFaCreation.isTrue()){
            	 
                processServiceAgreementServicePoint();
                processFieldActivity();

            }else{
                if ((saSpFieldActivityType.isStartActivity()
                        && saSpStartDateTime.getDate().isSameOrBefore(getProcessDateTime().getDate()))
                     || (saSpFieldActivityType.isStopActivity()
                             && saSpStopDateTime.getDate().isSameOrBefore(getProcessDateTime().getDate()))) {
                    processServiceAgreementServicePoint();
                    processFieldActivity();
                }
            }
        }
    }

    /**
     * MA000 - If the Manual Activation switch is false and calculated days for START/STOP exceeds the Number of Days Lead Time,
     * it's too early for creating Field Activities.
     */
    private void decideIfTooEarly() {
        if (saSpFieldActivityType.isStartActivity()) {
            // Calculate Date Difference between SASP's Start Date and Business Date
            long startDays = saSpStartDateTime.getDate().difference(getProcessDateTime().getDate()).getDays();

            if (shouldActivateManually.isFalse() && startDays > getNumberOfDaysLeadTime().longValue()) {
                addError(CustomMessageRepository.E06783_tooEarlyForFa(
                        serviceAgreement, servicePoint, numberOfDaysLeadTime));
            }
        }

        if (saSpFieldActivityType.isStopActivity()) {
            // Calculate Date Difference between SA/SP's Stop Date and Business Date
            long stopDays = saSpStopDateTime.getDate().difference(getProcessDateTime().getDate()).getTotalDays();

            if (shouldActivateManually.isFalse() && stopDays > getNumberOfDaysLeadTime().longValue()) {
            	addError(CustomMessageRepository.E06783_tooEarlyForFa(
                        serviceAgreement, servicePoint, numberOfDaysLeadTime));
            }
        }
    }
    
    /**
     * Check if has active severance process for SA
     * @param saId
     */
    private Bool hasActiveSevProcForSA(ServiceAgreement_Id saId){
        Bool hasActiveSev = Bool.FALSE;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT SEVPROC.SA_ID ");
        stringBuilder.append("FROM CI_SEV_PROC SEVPROC ");
        stringBuilder.append("WHERE SEVPROC.SA_ID = :saId ");
        stringBuilder.append("AND SEVPROC.SEV_STATUS_FLG = :active ");
        
        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("saId", saId);
        preparedStatement.bindLookup("active", SeveranceStatusLookup.constants.ACTIVE);
        
        if(notNull(preparedStatement.firstRow())){
            hasActiveSev = Bool.TRUE;
        }
        preparedStatement.close();
        
        return hasActiveSev;
    }
    
    /**
     * MC000
     */
    private void checkPendingStartStop() {
       
        // If FA Type is Start, determine if there is a Pending Stop, Pending Start or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the PAST of the Start Date that has a
        // Non-Dispatched Pending Field Activity for Stop
        if (saSpFieldActivityType.isStartActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.negate().intValue());

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, start1Date, saSpStartDateTime.getDate()
                    , null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            
            if (!results.isEmpty()) {
                // Ensure only latest one is selected
                cancelUnlinkPendingFa(results.get(0), ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }
        }

        // If FA Type is Stop, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the FUTURE of the Stop Date that has a
        // Non-Dispatched Pending Field Activity for Start
        if (saSpFieldActivityType.isStopActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date stop2Date = saSpStopDateTime.getDate().addDays(backToBackThresholdDays.intValue());

            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, null, null, saSpStopDateTime.getDate()
                    , stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            
            for (ServiceAgreementServicePoint pendingSaSp : results) {
                cancelUnlinkPendingFa(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
        }
    }

    /**
     * SQ010, SQ030
     * @param servicePoint
     * @param start1Date
     * @param start2Date
     * @param stop1Date
     * @param stop2Date
     * @param serviceAgreementSpFaTypeLookup
     * @return List&lt;ServiceAgreementServicePoint&gt;
     */
    private List<ServiceAgreementServicePoint> getPendingSaSp(ServicePoint servicePoint, 
    		Date start1Date, 
    		Date start2Date,
            Date stop1Date, 
            Date stop2Date, 
            ServiceAgreementSpFaTypeLookup serviceAgreementSpFaTypeLookup) {

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "S2.STOP_DTTM, ");
        // Selected S2.START_DTTM instead of S2.SA_ID so that query can be used when searching for either Stop or Start
        stringBuilder.append(  "S2.START_DTTM, ");
        stringBuilder.append(  "S2.SA_SP_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA S1, ");
        stringBuilder.append(  "CI_SA_SP_DT_VW S2 ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "S2.SA_ID = S1.SA_ID ");
        stringBuilder.append("AND S2.SP_ID = :servicePoint ");
        stringBuilder.append("AND S1.SA_STATUS_FLG IN (:activeSaStatus , :pendingStopSaStatus, :pendingStartSaStatus) ");
        // Cater for either stop or start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_DT BETWEEN :start1Date AND :start2Date ");
        }
        // Cater for either stop or start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_DT BETWEEN :stop1Date AND :stop2Date ");
        }
        // Cater for either stop or start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_MR_ID = ' ' ");
        }
        // Cater for either stop or start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_MR_ID = ' ' ");
        }
        stringBuilder.append("AND EXISTS ( ");
        stringBuilder.append(  "SELECT ");
        stringBuilder.append(    "S3.FA_ID ");
        stringBuilder.append(  "FROM ");
        stringBuilder.append(    "CI_SA_SP_FA S3, ");
        stringBuilder.append(    "CI_FA F1 ");
        stringBuilder.append(  "WHERE ");
        stringBuilder.append(    "S3.SA_SP_ID = S2.SA_SP_ID ");
        stringBuilder.append(  "AND F1.FA_ID = S3.FA_ID ");
        stringBuilder.append(  "AND F1.FA_STATUS_FLG = :pendingFaStatus ");
        stringBuilder.append(  "AND S3.SA_SP_FA_TYPE_FLG = :saSpFaType ");
        stringBuilder.append(  "AND F1.FA_ID = S3.FA_ID ");
        stringBuilder.append(  "AND ( ");
        stringBuilder.append(    "F1.FO_ID = ' ' ");
        stringBuilder.append(      "OR EXISTS ( ");
        stringBuilder.append(        "SELECT ");
        stringBuilder.append(          "'X' ");
        stringBuilder.append(        "FROM ");
        stringBuilder.append(          "CI_FO FO ");
        stringBuilder.append(        "WHERE ");
        stringBuilder.append(          "F1.FO_ID = FO.FO_ID ");
        stringBuilder.append(        "AND FO.FO_STATUS_FLG = :pendingFoStatus ");
        stringBuilder.append(      ") ");
        stringBuilder.append(    ") ");
        stringBuilder.append(  ") ");
        stringBuilder.append("ORDER BY ");
        // Cater for either stop or start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append(  "S2.STOP_DTTM DESC ");
        }
        // Cater for either stop or start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append(  "S2.START_DTTM DESC ");
        }

        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindLookup("activeSaStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
        preparedStatement.bindLookup("pendingStopSaStatus", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        preparedStatement.bindLookup("pendingStartSaStatus", ServiceAgreementStatusLookup.constants.PENDING_START);
        if (notNull(start1Date) && notNull(start2Date)) {
            preparedStatement.bindDate("start1Date", start1Date);
            preparedStatement.bindDate("start2Date", start2Date);
        }
        if (notNull(stop1Date) && notNull(stop2Date)) {
            preparedStatement.bindDate("stop1Date", stop1Date);
            preparedStatement.bindDate("stop2Date", stop2Date);
        }
        preparedStatement.bindLookup("saSpFaType", serviceAgreementSpFaTypeLookup);
        preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);
        preparedStatement.bindLookup("pendingFoStatus", FieldOrderStatusLookup.constants.PENDEDBY_USER);

        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<ServiceAgreementServicePoint> serviceAgreementServicePointResults = new ArrayList<ServiceAgreementServicePoint>();
        for (SQLResultRow sqlResultRow : results) {
            serviceAgreementServicePointResults.add(sqlResultRow.getEntity("SA_SP_ID", ServiceAgreementServicePoint.class));
        }

        return serviceAgreementServicePointResults;
    }

    /**
     * MC060
     * @param serviceAgreementServicePoint
     * @param serviceAgreementSpFaType
     */
    private void cancelUnlinkPendingFa(ServiceAgreementServicePoint serviceAgreementServicePoint
            , ServiceAgreementSpFaTypeLookup serviceAgreementSpFaType) {

        CmCancelUnlinkFasOfSaSpData data = CmCancelUnlinkFasOfSaSpData.Factory.newInstance();
        data.setServiceAgreementServicePoint(serviceAgreementServicePoint);
        data.setServiceAgreementSpFaType(serviceAgreementSpFaType);
        cancelUnlinkFasOfSaSp.cancelUnlinkFas(data);
    }

    /**
     * ME000
     */
    private void checkPendingStartStopForSameSpType() {
    	
        // If FA Type is Start, determine if there is a Pending Stop, Pending Start or Active SA/SP for the SP
        // on the exact date as start date that has a Non-Dispatched Field Activity for Start
        if (saSpFieldActivityType.isStartActivity()) {
            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, null, null
                    , saSpStartDateTime.getDate(), saSpStartDateTime.getDate(), ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            for (ServiceAgreementServicePoint pendingSaSp : results) {
                cancelUnlinkPendingFa(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
            
        }

        // If FA Type is Stop, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // on the exact date as stop date that has a Non-Dispatched Pending Field Activity for Stop
        if (saSpFieldActivityType.isStopActivity()) {
            List<ServiceAgreementServicePoint> results = getPendingSaSp(servicePoint, saSpStopDateTime.getDate()
                    , saSpStopDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            for (ServiceAgreementServicePoint pendingSaSp : results) {
                cancelUnlinkPendingFa(pendingSaSp, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }
        }
    }

    /**
     * MG000
     *
     */
    private void checkForBackToBack() {

        // If FA Type is Start, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the Past of the Start Date
        // without Pending, Held or Completed Field Activity for Stop
        if (saSpFieldActivityType.isStartActivity()) {

            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.negate().intValue());

            List<ServiceAgreementServicePoint> results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , start1Date, saSpStartDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY , Bool.FALSE);

            if (!results.isEmpty()) {
                // Assume back to back
                isBackToBack = Bool.TRUE;
                leastStopDateTime = results.get(0).getStopDateTime();
                backToBackSASP = results.get(0);
            }
            
            //Now check if there is a pending stop SA whose pending stop date is on a later date compared to the 
            //Start date of this new SA. This is to cater a possible back-to-back scenario
            //where a pending stop SA is linked to a SP whose end date is future dated.
            start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.intValue());
            results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint, saSpStartDateTime.getDate(), 
            		start1Date, null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY , Bool.TRUE);

            if (!results.isEmpty()) {
                // Assume back to back
                isBackToBack = Bool.TRUE;
                leastStopDateTime = results.get(0).getStopDateTime();
                backToBackSASP = results.get(0);
                futureStoppedPendingStopSASP = results.get(0);
            }
        }

        // If FA Type is Stop, determine if there is a Pending Start, Pending Stop or Active SA/SP for the SP
        // within 0 to the number of Back To Back Threshold Days in the Future of the Stop Date
        // without Pending, Held or Completed Field Activity for Start
        if (saSpFieldActivityType.isStopActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date stop2Date = saSpStopDateTime.getDate().addDays(backToBackThresholdDays.intValue());

            List<ServiceAgreementServicePoint> results = getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , null, null, saSpStopDateTime.getDate(), stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY, Bool.FALSE);
          

            if (!results.isEmpty()) {
                // Assume back to back
                isBackToBack = Bool.TRUE;
            }
        }
    }

    /**
     * SQ050, SQ070
     * @param servicePoint
     * @param serviceAgreementServicePoint
     * @param start1Date
     * @param start2Date
     * @param stop1Date
     * @param stop2Date
     * @param serviceAgreementSpFaTypeLookup
     * @return List&lt;ServiceAgreementServicePoint&gt;
     */
    private List<ServiceAgreementServicePoint> getOtherSaSpFieldActivities(ServicePoint servicePoint
            , ServiceAgreementServicePoint serviceAgreementServicePoint, Date start1Date, Date start2Date
            , Date stop1Date, Date stop2Date, ServiceAgreementSpFaTypeLookup serviceAgreementSpFaTypeLookup, 
            Bool shouldCheckForFutureDatedBackToBack) {
    

    	StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "S2.STOP_DTTM, ");
        // Selected S2.START_DTTM instead of S2.SA_ID so that query can be used when searching for either back-to-back Stop or back-to-back Start
        stringBuilder.append(  "S2.START_DTTM, ");
        stringBuilder.append(  "S2.SA_SP_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA S1, ");
        stringBuilder.append(  "CI_SA_SP_DT_VW S2 ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "S2.SA_ID = S1.SA_ID ");
        stringBuilder.append("AND S2.SP_ID = :servicePoint ");
        stringBuilder.append("AND S2.SA_SP_ID <> :serviceAgreementServicePoint ");
        stringBuilder.append("AND S1.SA_STATUS_FLG IN ");
        stringBuilder.append(  "( ");
        stringBuilder.append(    ":activeSaStatus, :pendingStopSaStatus, :pendingStartSaStatus");
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append(    ", :stoppedSaStatus");
        }
        stringBuilder.append(  ") ");
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_DT BETWEEN :start1Date AND :start2Date ");
        }
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_DT BETWEEN :stop1Date AND :stop2Date ");
        }
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append("AND S2.STOP_MR_ID = ' ' ");
        }
        // Cater for either back-to-back stop or back-to-back start
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append("AND S2.START_MR_ID = ' ' ");
        }

    	if(shouldCheckForFutureDatedBackToBack.isFalse()) {
    		stringBuilder.append("AND NOT EXISTS ");
    		stringBuilder.append(  "( ");
    		stringBuilder.append(    "SELECT ");
    		stringBuilder.append(      "S3.FA_ID ");
    		stringBuilder.append(    "FROM ");
    		stringBuilder.append(      "CI_SA_SP_FA S3, ");
    		stringBuilder.append(      "CI_FA F1 ");
    		stringBuilder.append(    "WHERE ");
    		stringBuilder.append(      "S3.SA_SP_ID = S2.SA_SP_ID ");
    		stringBuilder.append(    "AND S3.SA_SP_FA_TYPE_FLG = :saSpFaType ");
    		stringBuilder.append(    "AND F1.FA_ID = S3.FA_ID ");
    		stringBuilder.append(    "AND F1.FA_STATUS_FLG IN (:heldFaStatus, :pendingFaStatus, :completedFaStatus) ");
    		stringBuilder.append(  ") ");


    	}
        stringBuilder.append("ORDER BY ");
        if (notNull(start1Date) && notNull(start2Date)) {
            stringBuilder.append(  "S2.STOP_DTTM DESC ");
        }
        if (notNull(stop1Date) && notNull(stop2Date)) {
            stringBuilder.append(  "S2.START_DTTM DESC ");
        }

        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("servicePoint", servicePoint.getId());
        preparedStatement.bindId("serviceAgreementServicePoint", serviceAgreementServicePoint.getId());
        preparedStatement.bindLookup("activeSaStatus", ServiceAgreementStatusLookup.constants.ACTIVE);
        preparedStatement.bindLookup("pendingStopSaStatus", ServiceAgreementStatusLookup.constants.PENDING_STOP);
        preparedStatement.bindLookup("pendingStartSaStatus", ServiceAgreementStatusLookup.constants.PENDING_START);
        if (notNull(start1Date) && notNull(start2Date)) {
            preparedStatement.bindLookup("stoppedSaStatus", ServiceAgreementStatusLookup.constants.STOPPED);
        }
        if (notNull(start1Date) && notNull(start2Date)) {
            preparedStatement.bindDate("start1Date", start1Date);
            preparedStatement.bindDate("start2Date", start2Date);
        }
        if (notNull(stop1Date) && notNull(stop2Date)) {
            preparedStatement.bindDate("stop1Date", stop1Date);
            preparedStatement.bindDate("stop2Date", stop2Date);
        }
        
        if(shouldCheckForFutureDatedBackToBack.isFalse()) {
        	preparedStatement.bindLookup("saSpFaType", serviceAgreementSpFaTypeLookup);
        	preparedStatement.bindLookup("heldFaStatus", FieldActivityStatusLookup.constants.HELD);
        	preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);
        	preparedStatement.bindLookup("completedFaStatus", FieldActivityStatusLookup.constants.COMPLETED);
        }

        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<ServiceAgreementServicePoint> serviceAgreementServicePointResults = new ArrayList<ServiceAgreementServicePoint>();
        for (SQLResultRow sqlResultRow : results) {
            serviceAgreementServicePointResults.add(sqlResultRow.getEntity("SA_SP_ID", ServiceAgreementServicePoint.class));
        }

        return serviceAgreementServicePointResults;
    }

    /**
     * Create FA based on SP condition in FA Profile
     * This is the section that was modified to cater for custom requirements for ADDP reads.
     */
    private void processServiceAgreementServicePoint() {
    	// Retrieve information about the Service Point
    	ServicePointFieldConditionLookup spCondition = servicePoint.determineFieldCondition();
    	MeterReadRoute spServiceRoute = servicePoint.fetchMeterReadRoute();
    	MeterReadRouteType spServiceRouteType = spServiceRoute.getMeterReadRouteType();
    	scheduleDateTime = decideScheduleDateTime();
    	
    	//Start add JVitug - E06783.Issue1 - 2023-11-29
    	if(notNull(spServiceRoute) && excludedRouteTypes.contains(spServiceRouteType)) {
			//If SP's service route matches any of the excluded Service Routes, create a FA 
			//using the FA Type from the 10th parameter (M-READ)
			fa1 = createFieldActivityAndLinkToSaSp(dispatchableFATypeForMeterRead, scheduleDateTime);
    	} 
    	//End Add JVitug - E06783.Issue1 - 2023-11-29
    	//Start Change JVitug - E06783.Issue1 - 2023-11-29
    	//if (saSpFieldActivityType.isStartActivity()) {
    	else if (saSpFieldActivityType.isStartActivity()) {
    	//End Change JVitug - E06783.Issue1 - 2023-11-29
    		if (!spCondition.equals(spsDesiredStateForMeterRead)) {
    			// If the SP's condition does not match the SP's desired State for Meter Read, create the FA using the FA Type Profile
    			createFieldActivityViaFieldActivityTypeProfile(CustomerEventLookup.constants.START_SERVICE);
    		} else {
    			//If SP's condition matches the Desired State for Meter Read (from the fourth parameter) proceed
    			//If the Cancel Pending landlord Start Parameter is set to True , check to see if a 
    			//pending start SA exists for a Landlord by verifying the pending start account Id 
    			//is tied to a Landlord agreement Id
    			//Start Change JVitug - E--06783.7 - 2024-02-01
    			//cancelPendingStartLandlordSAs();
    			cancelPendingStartLandlordSAs(spServiceRoute);
    			//End Change JVitug - E-06783.7 - 2024-02-01

    			ServicePointCharacteristic spChar = servicePoint.getEffectiveCharacteristic(powerStatusCharacteristicType);
    			String spCharValue = "";

    			if(notNull(spChar)) {
    				if(powerStatusCharacteristicType.getCharacteristicType().isPredefinedValue()) {
    					spCharValue = spChar.getCharacteristicValue().trim();
    				} else if (powerStatusCharacteristicType.getCharacteristicType().isForeignKeyValue()) {
    					spCharValue = spChar.getCharacteristicValueForeignKey1().trim();
    				} else if(powerStatusCharacteristicType.getCharacteristicType().isAdhocValue() 
    						|| powerStatusCharacteristicType.getCharacteristicType().isFileLocationValue()) {
    					spCharValue = spChar.getAdhocCharacteristicValue().trim();
    				}
    			} 

    			if(!isBlankOrNull(spCharValue) && spCharValue.compareToIgnoreCase(powerStatusCharacteristicValue) == 0) {

    				//If SP has the  Power Status Characteristic value and its characteristic value is equal to the 
    				//Power status characteristic value from the algorithm parameters, then proceed 
    				FieldActivity pendingFA = getPendingFAlinkedToSASPRecord();
    				
    				if (notNull(pendingFA) && isBackToBack.isFalse()
    						&& pendingFA.getFieldActivityType().getId().compareTo(mStopFAType.getId()) == 0){
    					//If there is a pending FA linked to the SA/SP and it's beyond the back-to-back threshold,
    					//and the pending FA's FA Type is M-STOP, create using FA Type profile
						fa1 = createFieldActivityAndLinkToSaSp(mOnFAType , scheduleDateTime);
    				} else {
    					fa1 = createFieldActivityAndLinkToSaSp(nonDispatchableFATypeForMeterRead , scheduleDateTime);
    					if(isBackToBack.isTrue() && (notNull(leastStopDateTime) && leastStopDateTime.isBefore(saSpStartDateTime))) {
    						//Start Change JVitug - D-03523 - 2023-12-06
    						//fa2 = createFieldActivity(nonDispatchableFATypeForMeterRead , scheduleDateTime);
    						fa2 = createFieldActivity(nonDispatchableFATypeForMeterRead , leastStopDateTime);
    						//End Change JVitug - D-03523 - 2023-12-06
    						hasCreatedFA2 = Bool.TRUE; 
    					}
    				}
    			} else {
    				//If SP Power status characteristic is not equal to the power status characteristic value parameter.
    				if(saStartDate.isBefore(getProcessDateTime().getDate())) {
    					//If the selected SA start date is before the current day , check if there is an active
    					//Gas SA at the SP and compare the SA start date to the most recent completed Bill date for the SA
    					//If the SA start date is before the most recent completed bill's bill date, call an error
    					Date recentlyCompletedBillBillDate = checkIfSelectedStartDateIsBeforeActiveSARecentCompletedBillDate();
    					if(notNull(recentlyCompletedBillBillDate) && saStartDate.isBefore(recentlyCompletedBillBillDate)) {
    						//Call an error , asking the user to select another SA Start date
    						addError(CustomMessageRepository.
    								E06783_selectAnotherStartDate(servicePoint.getId().getTrimmedValue(), 
    										recentlyCompletedBillBillDate.toString(dateFormat), 
    										saStartDate.toString(dateFormat)));
    					}
    				} 
    				
    				//If there is a pending FA linked to the SA/SP and it's beyond the back-to-back threshold,
					//and the pending FA's FA Type is M-STOP, create M-ON FA
    				FieldActivity pendingFA = getPendingFAlinkedToSASPRecord();
    				
    				if (notNull(pendingFA) && isBackToBack.isFalse()
    						&& pendingFA.getFieldActivityType().getId().compareTo(mStopFAType.getId()) == 0){
						fa1 = createFieldActivityAndLinkToSaSp(mOnFAType , scheduleDateTime);
    				}
    				
    				//we first check if the SP's service route is within the Service routes in 11th parameter(BrightLync Service Routes)
    				else if(brightlyncServiceRouteTypes.contains(spServiceRouteType)) {
    					fa1 = createFieldActivityAndLinkToSaSp(nonDispatchableFATypeItronUltrasonicServiceRoutes , scheduleDateTime);

    					if(isBackToBack.isTrue() && (notNull(leastStopDateTime) && leastStopDateTime.isBefore(saSpStartDateTime))) {
    						//Start Change JVitug - D-03523 - 2023-12-06
    						//fa2 = createFieldActivity(nonDispatchableFATypeItronUltrasonicServiceRoutes , scheduleDateTime);
    						fa2 = createFieldActivity(nonDispatchableFATypeItronUltrasonicServiceRoutes , leastStopDateTime);
    						//End Change JVitug - D-03523 - 2023-12-06
    						hasCreatedFA2 = Bool.TRUE;  
    					} 
    					
    					
    				} else if (nonLGAMRserviceRouteTypes.contains(spServiceRouteType)) {
    					//If there is no pending stop FA, we create the FA using the FA type in the 13th parameter
    					fa1 = createFieldActivityAndLinkToSaSp(nonDispatchableFATypeItronUltrasonicServiceRoutes, scheduleDateTime);

    					//Create the Hold for Read characteristic 
    					//Determine the characteristic value by using the next meter read date based on service cycle
    					String characteristicValue = determineNextReadBasedOnSPServiceRoute(spServiceRoute); 
    					createFieldActivityCharacteristic(fa1, faCharacteristicTypeItronUltrasonicServiceRoute, characteristicValue);

    					if(isBackToBack.isTrue() && (notNull(leastStopDateTime) && leastStopDateTime.isBefore(saSpStartDateTime))) {
    						//Start Change JVitug - D-03523 - 2023-12-06
    						//fa2 = createFieldActivity(nonDispatchableFATypeItronUltrasonicServiceRoutes , scheduleDateTime);
    						fa2 = createFieldActivity(nonDispatchableFATypeItronUltrasonicServiceRoutes , leastStopDateTime);
    						//End Change JVitug - D-03523 - 2023-12-06
    						
    						createFieldActivityCharacteristic(fa2, faCharacteristicTypeItronUltrasonicServiceRoute, characteristicValue);
    						hasCreatedFA2 = Bool.TRUE; 
    					}
    				} else {
    					//If none of the conditions are fulfilled, create using FA using the FA Type profile
    					createFieldActivityViaFieldActivityTypeProfile(CustomerEventLookup.constants.START_SERVICE);
    				} 
    			} // end bracket - if/else for Power Status Characteristic
    			//If there is a back-to-back scenario and there is another distinct Pending Start SA 
				// that has a FA Activity tagged as Start, call an error
				if(isBackToBack.isTrue() && hasAnotherPendingStartSA().isTrue()) {
					addError(CustomMessageRepository.E06783_hasPendingBacktoBack());
				}
    		} // End Bracket - check if SP condition is the same as sp desired state for meter read parm
    	} else if (saSpFieldActivityType.isStopActivity()) { 
    		//Start Add JVitug - TBD - 2023-12-12
    		if(notNull(serviceAgreement.fetchPremise().getLandLordId())) {
    			//If the account of this SA is also the account of the Landlord, and there is a pending stop SA
    			//whose end date is equal to this SA's start date, this means that the landlord reversion of the Premise
    			//was not finalized yet and there was an attempt for a new tenant to move in. Cancel this SA if this is the case
    			if(accountIsLandLordOfThisPremise().isTrue() && hasPendingStopSAWithSameStopDateAsStartDate(serviceAgreement).isTrue()) {
    				serviceAgreement.cancel(Bool.TRUE);
    				return;
        		}
    		} 
    		//End Add JVitug - TBD - 2023-12-12
    		if (!spCondition.equals(spsDesiredStateForMeterRead)) {
    			// If the SP's condition does not match the SP's desired State for Meter Read, create the FA using the FA Type Profile
    			createFieldActivityViaFieldActivityTypeProfile(CustomerEventLookup.constants.STOP_SERVICE);
    		} else if(notNull(servicePoint.fetchMeterLocation())
    				&& excludedMeterLocationsList.contains(servicePoint.fetchMeterLocation())) {
    			// If the SPs Meter Location is in the Exclude Meter Location list, Create a FA using the 
        		//FA Type Profile
    			createFieldActivityViaFieldActivityTypeProfile(CustomerEventLookup.constants.STOP_SERVICE);
    		} else if(hasActiveSevProcForSA(serviceAgreement.getId()).isTrue()) {
    			//If SA has severance process, create the FA using the FA Type Profile
    			createFieldActivityViaFieldActivityTypeProfile(CustomerEventLookup.constants.STOP_SERVICE);
    		}
    		//Start Delete JVitug - E06783.Issue1 - 2023-11-29
    		//else if(notNull(spServiceRoute) && excludedRouteTypes.contains(spServiceRouteType)) {
    			//If SP's service route matches any of the excluded Service Routes, create a FA 
    			//using the FA Type profile
    			//fa1 = createFieldActivityAndLinkToSaSp(dispatchableFATypeForMeterRead, scheduleDateTime);
    		//}
    		//End Delete JVitug - E06783.Issue1 - 2023-11-29
    		else { 
    			//If the Power status characteristic exists and the Power status characteristic value is Y, create the FA 
    			//using the FA Type in parameter 3.
    			ServicePointCharacteristic spChar = servicePoint.getEffectiveCharacteristic(powerStatusCharacteristicType);
    			String spCharValue = "";
    			if(notNull(spChar)) {
    				if(powerStatusCharacteristicType.getCharacteristicType().isPredefinedValue()) {
    					spCharValue = spChar.getCharacteristicValue().trim();
    				} else if (powerStatusCharacteristicType.getCharacteristicType().isForeignKeyValue()) {
    					spCharValue = spChar.getCharacteristicValueForeignKey1().trim();
    				} else if(powerStatusCharacteristicType.getCharacteristicType().isAdhocValue() 
    						|| powerStatusCharacteristicType.getCharacteristicType().isFileLocationValue()) {
    					spCharValue = spChar.getAdhocCharacteristicValue().trim();
    				}
    			} 

    			if(!isBlankOrNull(spCharValue) && spCharValue.compareToIgnoreCase(powerStatusCharacteristicValue) == 0) {
    				//If SP has the  Power Status Characteristic value and its characteristic value is equal to the 
    				//Power status characteristic value from the algorithm parameters, then create an FA type equal to 
    				//the third parameter for the Start Activity
    				fa1 = createFieldActivityAndLinkToSaSp(nonDispatchableFATypeForMeterRead , scheduleDateTime);
    			} else { 
    				if(brightlyncServiceRouteTypes.contains(spServiceRouteType) || nonLGAMRserviceRouteTypes.contains(spServiceRouteType)) {
    					fa1 = createFieldActivityAndLinkToSaSp(nonDispatchableFATypeItronUltrasonicServiceRoutes, scheduleDateTime);
    					//This is to create a characteristic on the FA created in the event that the SP's service route
    					//is the same as one of the service routes in Parameter 13
    					if(nonLGAMRserviceRouteTypes.contains(spServiceRouteType)) {
    						//Determine the characteristic value by using the next meter read date based on service cycle
    						String characteristicValue = determineNextReadBasedOnSPServiceRoute(spServiceRoute);
    						createFieldActivityCharacteristic(fa1, faCharacteristicTypeItronUltrasonicServiceRoute, characteristicValue);
    					}
    				} else {
    					//If none of the conditions are met, create a FA using the FA Type Profile
    					createFieldActivityViaFieldActivityTypeProfile(CustomerEventLookup.constants.STOP_SERVICE);
    				} 
    			}
    		}
    	} 
    }
    
    /**
     * MI040
     * @return scheduleDateTime
     */
    private DateTime decideScheduleDateTime() {

    	//Start Delete JVitug - D-03523 - 2023-12-06
        // If it is START and there is no BACK-to-BACK situation then SCHED-DTTM will be set to START-DTTM,
        // otherwise (i.e. BACK-to-BACK) it will be set to earliest STOP-DTTM among SA/SPs
        //if (saSpFieldActivityType.isStartActivity() && isBackToBack.isTrue()) {
            //return leastStopDateTime;
        //}
        //End Delete JVitug - D-03523 - 2023-12-06

    	//Start Change JVitug - D-03523 - 2023-12-06
        //if (saSpFieldActivityType.isStartActivity() && isBackToBack.isFalse()) {
    	if (saSpFieldActivityType.isStartActivity()){
        //End Change JVitug - D-03523 - 2023-12-06
            return saSpStartDateTime;
        }

        // If it is STOP, SCHED-DTTM will be set to STOP-DTTM of SA/SP regardless of BACK-to-BACK situation
        if (saSpFieldActivityType.isStopActivity()) {
            return saSpStopDateTime;
        }

        return null;
    }
    
    /**
     * PA130
     */
    private void createFieldActivityViaFieldActivityTypeProfile(CustomerEventLookup customerEvent) {
        SaSpFieldActivityCreatorData data = SaSpFieldActivityCreatorData.Factory.newInstance();
        data.setServiceAgreementSpFaType(saSpFieldActivityType);
        data.setIsBackToBack(isBackToBack);
        data.setCustomerEvent(customerEvent); 
        data.setScheduledDateTime(scheduleDateTime);
        data.setFieldActivityCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);
        data.setIsFaCollectionRequired(Bool.FALSE);

        data = serviceAgreementServicePoint.addFieldActivity(data);

        isFaCreated = data.getIsFaCreated();
    }

    private FieldActivity createFieldActivityAndLinkToSaSp(FieldActivityType fieldActivityType , DateTime scheduleDateTime) {
    
        FieldActivity_DTO fieldActivityDTO = new FieldActivity_DTO();
        fieldActivityDTO.setServicePointId(servicePoint.getId());
        fieldActivityDTO.setFieldActivityTypeId(fieldActivityType.getId());
        fieldActivityDTO.setScheduleDateTimeStart(scheduleDateTime);
        fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);

        FieldActivityCreatorData data = FieldActivityCreatorData.Factory.newInstance();
        data.setFaDTO(fieldActivityDTO);

        FieldActivity fieldActivity = FieldActivityCreator.Factory.newInstance().addFieldActivity(data);

        ServiceAgreementSpFieldActivity_DTO serviceAgreementSpFieldActivityDTO = new ServiceAgreementSpFieldActivity_DTO();
        serviceAgreementSpFieldActivityDTO.setFieldActivityType(saSpFieldActivityType);
        serviceAgreementSpFieldActivityDTO.setServiceAgreementId(serviceAgreementServicePoint.getServiceAgreement().getId());
        serviceAgreementSpFieldActivityDTO.setServicePointId(serviceAgreementServicePoint.getServicePoint().getId());
        serviceAgreementServicePoint.getServiceAgreementSpFieldActivities().add(serviceAgreementSpFieldActivityDTO, fieldActivity.getId());

        isFaCreated = Bool.TRUE;

        return fieldActivity;
    }
    
    private void createFieldActivityCharacteristic(FieldActivity fa, CharacteristicType charType, String characteristicValue) {
    	FieldActivityCharacteristics faChars = fa.getCharacteristics();
    	FieldActivityCharacteristic_DTO faChar = faChars.newChildDTO();
    	ListFilter<FieldActivityCharacteristic> faCharListFilter = faChars.createFilter(" WHERE this.id.characteristicType = :characteristicType ", getClass().getName());
		faCharListFilter.bindEntity("characteristicType", charType);
		CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();

    	faChar.setId(new FieldActivityCharacteristic_Id(fa , 
    			charType , 
    			BigInteger.valueOf(faCharListFilter.listSize() +1)));

    	if(charTypeLookup.isAdhocValue() || charTypeLookup.isFileLocationValue()) {
    		faChar.setAdhocCharacteristicValue(characteristicValue);
    	} else if (charTypeLookup.isForeignKeyValue()) {
    		faChar.setCharacteristicValueForeignKey1(characteristicValue);
    	} else if (charTypeLookup.isPredefinedValue()) {
    		faChar.setCharacteristicValue(characteristicValue);
    	}

    	faChar.newEntity();
    }

    /**
     * MM000 - Retrieve newly created Pending FAs of SA/SP and link to Back-to-Back SA/SPs
     */
    private void processFieldActivity() {

        if(hasCreatedFA2.isTrue()) {
            //If another FA was created, this means that there is a back to back SA for the SP. Link FA2 to the pending stop
            //and FA 1 to the active SA
            linkSameType(fa1);
            linkB2BSaSpFa(fa2);
        } else {
            for (FieldActivity fieldActivity : getSaSpFas(serviceAgreementServicePoint)) {
                if (isBackToBack.isTrue()) {
                    linkB2BSaSpFa(fieldActivity);
                }
                
                linkSameType(fieldActivity);
            }
        }
    }

    /**
     * SQ090
     * @param serviceAgreementServicePoint
     * @return List&lt;FieldActivity&gt;
     */
    private List<FieldActivity> getSaSpFas(ServiceAgreementServicePoint serviceAgreementServicePoint) {

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "SASPFA.FA_ID ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA_SP_FA SASPFA, ");
        stringBuilder.append(  "CI_FA FA ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(  "SASPFA.SA_SP_ID = :saSpId ");
        stringBuilder.append(  "AND SASPFA.SA_SP_FA_TYPE_FLG = :saSpFaType ");
        stringBuilder.append(  "AND FA.FA_ID = SASPFA.FA_ID ");
        stringBuilder.append(  "AND FA.FA_STATUS_FLG = :pendingFaStatus ");

        PreparedStatement preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("saSpId", serviceAgreementServicePoint.getId());

        preparedStatement.bindLookup("saSpFaType", saSpFieldActivityType);
        preparedStatement.bindLookup("pendingFaStatus", FieldActivityStatusLookup.constants.PENDING);

        List<SQLResultRow> results = preparedStatement.list();

        preparedStatement.close();

        List<FieldActivity> fieldActivityResults = new ArrayList<FieldActivity>();
        for (SQLResultRow sqlResultRow : results) {
            fieldActivityResults.add(sqlResultRow.getEntity("FA_ID", FieldActivity.class));
        }

        return fieldActivityResults;
    }

    /**
     * MM020 - Link the Field Activity to the Pending Start and Pending Stop SA/SPs.
     * @param fieldActivity
     */
    private void linkB2BSaSpFa(FieldActivity fieldActivity) {
        if (saSpFieldActivityType.isStartActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date start1Date = saSpStartDateTime.getDate().addDays(backToBackThresholdDays.negate().intValue());

            for (ServiceAgreementServicePoint pendingStopSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , start1Date, saSpStartDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY , Bool.FALSE)) {
            	createSaSpFa(pendingStopSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);                
            }
            
            //If there is a future dated pending stop whose stop date is future dated and is within the number of back to back threshold days
            // link the FA created to the future-dated Pending Stop SA and update its end date to be equal to the 
            //start date of the new SA
            if(notNull(futureStoppedPendingStopSASP) && futureStoppedPendingStopSASP.getStopDateTime().isAfter(saStartDate)) {
                //Update the SA's end date 
                ServiceAgreement pendingStopSA = futureStoppedPendingStopSASP.getServiceAgreement();
                ServiceAgreement_DTO pendingStopSA_DTO = pendingStopSA.getDTO();
                pendingStopSA_DTO.setEndDate(saStartDate);
                pendingStopSA.setDTO(pendingStopSA_DTO);
                
                //Update the SA/SP Record of the 
                ServiceAgreementServicePoint_DTO pendingStopSaSpDto = futureStoppedPendingStopSASP.getDTO();
                
                pendingStopSaSpDto.setStopDateTime(saSpStartDateTime);
                futureStoppedPendingStopSASP.setDTO(pendingStopSaSpDto);
                
                //Cancel any pending Stop Activity FAs on the Pending Stop SA
                cancelUnlinkPendingFa(futureStoppedPendingStopSASP, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
                
                //Link the created FA to the pending stop 
                createSaSpFa(futureStoppedPendingStopSASP, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }
            
            //Start Add JVitug - E06783.Issue3 - 2024-01-09
            //If A pending stop SA is found whose stop date is the same as the Start date of the cancelled Landlord SA's start date, 
            //we link the FA to that SA instead
            else if(notNull(pendingStopSASPLinkedToLandlordSA)) {
            	createSaSpFa(pendingStopSASPLinkedToLandlordSA, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);;
            }
            //End Add JVitug - E06783.Issue3 - 2024-01-09
        }

        if (saSpFieldActivityType.isStopActivity()) {
            // Subtract the number of Back To Back Threshold Days from the Start Date Time of SA/SP
            Date stop2Date = saSpStopDateTime.getDate().addDays(backToBackThresholdDays.intValue());

            for (ServiceAgreementServicePoint pendingStartSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , null, null, saSpStopDateTime.getDate(), stop2Date, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY , Bool.FALSE)) {
            	createSaSpFa(pendingStartSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
        }
    }

    /**
     * MM060 - Create SA/SP/FA record using the row maintenance.
     */
    private void createSaSpFa(ServiceAgreementServicePoint serviceAgreementServicePoint, FieldActivity fieldActivity
            , ServiceAgreementSpFaTypeLookup lookup) {

        ServiceAgreementSpFieldActivity_Id serviceAgreementSpFieldActivityId = new ServiceAgreementSpFieldActivity_Id(serviceAgreementServicePoint
                , fieldActivity);
        if (isNull(serviceAgreementSpFieldActivityId.getEntity())) {

            ServiceAgreementSpFieldActivity_DTO serviceAgreementSpFieldActivityDTO = new ServiceAgreementSpFieldActivity_DTO();
            serviceAgreementSpFieldActivityDTO.setFieldActivityType(lookup);
            serviceAgreementSpFieldActivityDTO.setServiceAgreementId(serviceAgreementServicePoint.getServiceAgreement().getId());
            serviceAgreementSpFieldActivityDTO.setServicePointId(serviceAgreementServicePoint.getServicePoint().getId());
            serviceAgreementSpFieldActivityDTO.setId(serviceAgreementSpFieldActivityId);
            serviceAgreementSpFieldActivityDTO.newEntity();
        }
    }

    /**
     * MK040 - Link the FA to the Pending Start and Pending Stop SA/SPs
     */
    private void linkSameType(FieldActivity fieldActivity) {
        if (saSpFieldActivityType.isStartActivity()) {
        	for (ServiceAgreementServicePoint pendingStartSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , null, null, saSpStartDateTime.getDate(), saSpStartDateTime.getDate(), ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY,Bool.FALSE)) {
        		// Cancel field activity and disconnect from SA/SP
                cancelUnlinkPendingFa(pendingStartSaSp, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
                
                // Link new FA to SA/SP
                createSaSpFa(pendingStartSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
            }
        }

        if (saSpFieldActivityType.isStopActivity()) {
        	for (ServiceAgreementServicePoint pendingStopSaSp : getOtherSaSpFieldActivities(servicePoint, serviceAgreementServicePoint
                    , saSpStopDateTime.getDate(), saSpStopDateTime.getDate(), null, null, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY , Bool.FALSE)) {
        		// Cancel field activity and disconnect from SA/SP
                cancelUnlinkPendingFa(pendingStopSaSp, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);

                // Link new FA to SA/SP
                createSaSpFa(pendingStopSaSp, fieldActivity, ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
            }
        }
    }
    
    /**
     * This method gets the Landlord SA linked to the account of the SA being started / stopped
     * and cancels this SA. This method also logs a To Do in the event that the landlord SA's start date
     * is before this new SA's start date
     */
    //Start Change JVitug - E-06783.7 - 2024-02-01
    //private void cancelPendingStartLandlordSAs() {
    private void cancelPendingStartLandlordSAs(MeterReadRoute spServiceRoute) {
    //End Change JVitug - E-06783.7 - 2024-02-01
    	ServiceAgreement landlordSA = null;
    	StringBuilder stringSql = new StringBuilder();
    	PreparedStatement sql;
    	List<SQLResultRow> results;
    	
    	stringSql.append("SELECT ");
    	stringSql.append(   "SA.SA_ID ");
    	stringSql.append("FROM ");
    	stringSql.append(   "CI_SA SA, ");
    	stringSql.append(   "CI_PREM PREM, ");
    	stringSql.append(   "CI_LANDLORD LL ");
    	stringSql.append("WHERE ");
    	stringSql.append(   "SA.CHAR_PREM_ID = :premiseId ");
    	stringSql.append("AND ");
    	stringSql.append(   "SA.ACCT_ID <> :accountID ");
    	stringSql.append("AND ");
    	stringSql.append(   "SA.CHAR_PREM_ID = PREM.PREM_ID ");
    	stringSql.append("AND ");
    	stringSql.append(   "PREM.LL_ID = LL.LL_ID ");
    	//Start Change JVitug - TBD - 2023-12-12
    	//stringSql.append("AND ");
    	//stringSql.append(   "SA.SA_STATUS_FLG = :pendingStart ");
    	stringSql.append("AND ");
    	stringSql.append(   "SA.ACCT_ID = LL.ACCT_ID ");
    	//End Change JVitug - TBD - 2023-12-12
    	
    	sql = createPreparedStatement(stringSql.toString() , getClass().getName());
    	sql.bindId("premiseId" , serviceAgreement.getPremiseId());
    	sql.bindId("accountID" ,serviceAgreement.getAccount().getId());
    	//Start Delete JVitug - TBD - 2023-12-12
    	//sql.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
    	//End Delete JVitug - TBD - 2023-12-12
    	results = sql.list();
    	sql.close();
    	
    	for(SQLResultRow result : results) {
    		landlordSA = result.getEntity("SA_ID" , ServiceAgreement.class);
    		//Start Add JVitug - TBD - 2023-12-12
    		//Due to the framework attempting to Stop the landlord SA in the event that we start a new SA
    		//in the landlord's premise , we now check if there is a landlord SA in pending stop Status 
    		//We also check if said landlord SA is linked to another pending stop SA where the pending stop 
    		// landlord SA's start date is equal to that pending Stop SA's end date. If there is
    		//this means that the Premise the new tenant is moving into is part of a Landlord Reversion.
    		//We cancel this Landlord SA if that is the case.
    		if(landlordSA.getStatus().isPendingStart() || landlordSA.getStatus().isPendingStop()) {
    			if(hasPendingStopSAWithSameStopDateAsStartDate(landlordSA).isTrue()) {
    		//End Add JVitug - TBD - 2023-12-12
    				if(notNull(todoType) && saStartDate.isAfter(landlordSA.getStartDate())) {
    					//We should raise a To Do if the pending Start Landlord SA 
    					// start date is before this starting SA's start date
    					//Start Change JVitug - E-06783.7 - 2024-02-01
    					//Start Change JVitug - TBD - 2023-12-12
    					//addToDoEntry(landlordSA.fetchPremise().fetchLandLord().getAccountId() , leastStopDateTime.getDate());
    					//addToDoEntry(landlordSA.fetchPremise().fetchLandLord().getAccountId() ,
    							//landlordSA.getStartDate() , 
    							//serviceAgreement.getStartDate());
    					addToDoEntry(landlordSA.fetchPremise().fetchLandLord().getAccountId() ,
    							landlordSA.getStartDate() , 
    							serviceAgreement.getStartDate(),
    							spServiceRoute);
    					//End Change JVitug - TBD - 2023-12-12
    					//End Change JVitug - E-06783.7 - 2024-02-01
    				} 
    				
    				landlordSA.cancel(Bool.TRUE);
    				leastStopDateTime = new DateTime(landlordSA.getStartDate(), Time.MIN);
    		//Start Add JVitug - TBD - 2023-12-12
    			}
    		}
    		//End Add JVitug - TBD - 2023-12-12
    	}
    }
    
    /**
     * This method returns true if there is an active SA on the SP 
     * and the most recent completed bill's Bill Date on said SA is after
     * the selected SA start date. Otherwise, this will return false
     * @return
     */
    private Date checkIfSelectedStartDateIsBeforeActiveSARecentCompletedBillDate() {
    	Date returnValue = null;
    	StringBuilder stringSql = new StringBuilder();
    	PreparedStatement sql;
    	SQLResultRow result;
    	
    	stringSql.append("SELECT ");
    	stringSql.append(   "MAX(BILL.BILL_DT) AS BILL_DT ");
    	stringSql.append("FROM ");
    	stringSql.append(   "CI_SA_SP SASP, ");
    	stringSql.append(   "CI_BILL BILL, ");
    	stringSql.append(   "CI_SA SA ");
    	stringSql.append("WHERE ");
    	stringSql.append(   "SASP.SP_ID = :spId ");
    	stringSql.append("AND ");
    	stringSql.append(   "SASP.SA_ID = SA.SA_ID ");
    	stringSql.append("AND ");
    	stringSql.append(   "SA.SA_STATUS_FLG IN (:active, :pendingStop , :stopped) ");
    	stringSql.append("AND ");
    	stringSql.append(   "SA.ACCT_ID = BILL.ACCT_ID ");
    	stringSql.append("AND ");
    	stringSql.append(   "BILL.BILL_STAT_FLG = :complete "); 
    	
    	sql = createPreparedStatement(stringSql.toString() , getClass().getName());
    	sql.bindId("spId" , servicePoint.getId());
    	sql.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
    	sql.bindLookup("pendingStop", ServiceAgreementStatusLookup.constants.PENDING_STOP);
    	sql.bindLookup("stopped", ServiceAgreementStatusLookup.constants.STOPPED);
    	sql.bindLookup("complete", BillStatusLookup.constants.COMPLETE);
    	
    	result = sql.firstRow();
    	sql.close();
    	
    	if(notNull(result)) {
    		returnValue = result.getDate("BILL_DT");
    	}
    	
    	return returnValue;
    }
    
    /**
     * Determines the next Scheduled Read Date of a SP Service Route Type
     * @param route
     * @return
     */
    private String determineNextReadBasedOnSPServiceRoute(MeterReadRoute route) {
    	String returnValue = "";
    	Date nextReadDate = null;
    	StringBuilder stringSql = new StringBuilder();
    	PreparedStatement sql;
    	SQLResultRow result;
    	
    	stringSql.append("SELECT ");
    	stringSql.append(   "SCH.SCHED_READ_DT ");
    	stringSql.append("FROM ");
    	stringSql.append(   "CI_MR_RTE RTE, ");
    	stringSql.append(   "CI_MR_SCHED SCH ");
    	stringSql.append("WHERE ");
    	stringSql.append(   "RTE.MR_RTE_CD = :route ");
    	//Start Add - CAtila - 2023-12-06
    	stringSql.append("AND ");
    	stringSql.append(   "RTE.MR_CYC_CD = :cycle ");
    	//End Add - CAtila - 2023-12-06
    	stringSql.append("AND ");
    	stringSql.append(   "RTE.MR_CYC_CD = SCH.MR_CYC_CD ");
    	stringSql.append("AND ");
    	stringSql.append(   "SCH.SCHED_READ_DT > :spStartDate ");
    	stringSql.append("ORDER BY ");
    	stringSql.append(   "SCH.SCHED_READ_DT ASC ");
    	
    	sql = createPreparedStatement(stringSql.toString() , getClass().getName());
    	sql.bindString("route", route.getId().getMeterReadRoute() , "MR_RTE_CD");
    	//Start Add - CAtila - 2023-12-06
    	sql.bindEntity("cycle", route.fetchIdMeterReadCycle());
    	//End Add - CAtila - 2023-12-06
    	sql.bindDate("spStartDate" , scheduleDateTime.getDate());
    	
    	result = sql.firstRow();
    	sql.close();
    	
    	if(notNull(result)) {
    		nextReadDate = result.getDate("SCHED_READ_DT");
    		returnValue = nextReadDate.toString(dateFormat);
    	} 
    	
    	return returnValue;
    }
    
    /**
     * This method will check if there is another SA/SP Record that has a Field Activity tagged 
     * as a Start Service FA Activity that is not yet completed linked to the SP being processed.
     * @return
     */
    private Bool hasAnotherPendingStartSA() {
    	Bool returnValue = Bool.FALSE;
    	StringBuilder stringBuilder = new StringBuilder();
    	SQLResultRow result = null;
    	PreparedStatement preparedStatement;
    	
        stringBuilder.append("SELECT ");
        stringBuilder.append(  "COUNT(FA.FA_ID) AS COUNTER ");
        stringBuilder.append("FROM ");
        stringBuilder.append(  "CI_SA_SP_FA S1, ");
        stringBuilder.append(  "CI_FA FA ");
        stringBuilder.append("WHERE ");
        stringBuilder.append(   "S1.SA_SP_ID <> :serviceAgreementServicePoint ");
        stringBuilder.append("AND S1.SA_ID <> :saId ");
        stringBuilder.append("AND S1.SP_ID = :spId ");
        stringBuilder.append("AND S1.SA_SP_FA_TYPE_FLG = :startActivity ");
        stringBuilder.append("AND S1.FA_ID = FA.FA_ID ");
        stringBuilder.append("AND FA.FA_STATUS_FLG = :pending "); 

        preparedStatement = createPreparedStatement(stringBuilder.toString(), getClass().getName());
        preparedStatement.bindId("serviceAgreementServicePoint", serviceAgreementServicePoint.getId());
        preparedStatement.bindId("spId", servicePoint.getId());
        preparedStatement.bindId("saId", serviceAgreement.getId());
        preparedStatement.bindLookup("startActivity", ServiceAgreementSpFaTypeLookup.constants.START_ACTIVITY);
        preparedStatement.bindLookup("pending", FieldActivityStatusLookup.constants.PENDING);

        result = preparedStatement.firstRow();

        preparedStatement.close();

        if(notNull(result)) {
        	BigInteger count = result.getInteger("COUNTER");
        	if(count.compareTo(BigInteger.ZERO) > 0) {
        		returnValue = Bool.TRUE;
        	}        	
        }
        return returnValue;
    }
    
    private FieldActivity createFieldActivity(FieldActivityType fieldActivityType , DateTime scheduledDateTime) {
        FieldActivity_DTO fieldActivityDTO = new FieldActivity_DTO();
        fieldActivityDTO.setServicePointId(servicePoint.getId());
        fieldActivityDTO.setFieldActivityTypeId(fieldActivityType.getId());
        //Start Change JVitug - D-03523 - 2023-12-06 
        //fieldActivityDTO.setScheduleDateTimeStart(scheduleDateTime);
        fieldActivityDTO.setScheduleDateTimeStart(scheduledDateTime);
        //End Change JVitug - D-03523 - 2023-12-06
        fieldActivityDTO.setCreatedBy(FieldActivityCreatedByLookup.constants.START_STOP_SERVICE_REQUEST);

        FieldActivityCreatorData data = FieldActivityCreatorData.Factory.newInstance();
        data.setFaDTO(fieldActivityDTO);

        FieldActivity fieldActivity = FieldActivityCreator.Factory.newInstance().addFieldActivity(data);
        
        return fieldActivity;
    }
    
    private FieldActivity getPendingFAlinkedToSASPRecord() {
    	FieldActivity returnValue = null;
    	StringBuilder stringBuilder = new StringBuilder();
    	SQLResultRow result = null;
    	PreparedStatement sql;
    	
    	stringBuilder.append("SELECT ");
    	stringBuilder.append(   "FA.FA_ID ");
    	stringBuilder.append("FROM ");
    	stringBuilder.append(   "CI_SA_SP_FA SASPFA, ");
    	stringBuilder.append(   "CI_FA FA ");
    	stringBuilder.append("WHERE ");
    	stringBuilder.append(   "SASPFA.SA_SP_ID <> :sasp ");
    	stringBuilder.append("AND ");
    	stringBuilder.append(   "SASPFA.SP_ID = :spId ");
    	stringBuilder.append("AND ");
    	stringBuilder.append(   "SASPFA.SA_SP_FA_TYPE_FLG = :stopEvent ");
    	stringBuilder.append("AND ");
    	stringBuilder.append(   "SASPFA.FA_ID = FA.FA_ID ");
    	stringBuilder.append("AND ");
    	stringBuilder.append(   "FA.FA_STATUS_FLG = :pending ");
    	stringBuilder.append("ORDER BY ");
    	stringBuilder.append(   "FA.SCHED_DTTM DESC ");
    	
    	sql = createPreparedStatement(stringBuilder.toString() , getClass().getName());
    	sql.bindId("sasp" , serviceAgreementServicePoint.getId());
    	sql.bindId("spId" , servicePoint.getId());
    	sql.bindLookup("stopEvent" , ServiceAgreementSpFaTypeLookup.constants.STOP_ACTIVITY);
    	sql.bindLookup("pending" , FieldActivityStatusLookup.constants.PENDING);
    	
    	result = sql.firstRow();
    	sql.close();
    	
    	if(notNull(result)) {
    		returnValue = result.getEntity("FA_ID", FieldActivity.class);
    	}
    	
    	return returnValue;
    }
    
    /**
     * This method creates a To Do Entry
     * @param Account
     * @return
     */
    //Start Change JVitug - E-06783.7 - 2024-02-01
    //Start Change JVitug - TBD - 2023-12-14
    //private ToDoEntry addToDoEntry(Account_Id landlordAccount, Date stopDateOfOldTenant) {
    //private ToDoEntry addToDoEntry(Account_Id landlordAccount, Date stopDateOfOldTenant , Date startDateOfNewTenant) {
    private ToDoEntry addToDoEntry(Account_Id landlordAccount, Date stopDateOfOldTenant , Date startDateOfNewTenant, MeterReadRoute spServiceRoute) {
    //End Change JVitug - TBD - 2023-12-14  
    //End Change JVitug - E-06783.7 - 2024-02-01
        //Set Date, Status and Priority for the ToDo
        ToDoEntry_DTO toDoEntryDto = (ToDoEntry_DTO) createDTO(ToDoEntry.class);
        toDoEntryDto.setToDoTypeId(todoType.getId());
        toDoEntryDto.setCreationDateTime(getProcessDateTime());
        
        // If parmToDoRole is not null then assigned to the toDoEntryDto
        if(notNull(todoRole)){
            toDoEntryDto.setToDoRoleId(todoRole.getId());
        }
        
        //Create ToDo
        ToDoCreator toDoCreator = ToDoCreator.Factory.newInstance();
        String acctIdStr = landlordAccount.getTrimmedValue();
        
        toDoCreator.setToDoDTO(toDoEntryDto);
        //Add drill key
        Iterator<ToDoDrillKeyType> drillKeyIterator = todoType.getId().getEntity().getDrillKeyTypes().iterator();
        toDoCreator.addDrillKeyValue(drillKeyIterator.next(), acctIdStr);
        //Add sort key
        Iterator<ToDoSortKeyType> sortKeyIterator = todoType.getId().getEntity().getSortKeyTypes().iterator();
        toDoCreator.addSortKeyValue(sortKeyIterator.next(), acctIdStr);
        //Start Add JVitug - E-06783.7 - 2024-02-01
        toDoCreator.addSortKeyValue(sortKeyIterator.next() , determineNextReadBasedOnSPServiceRoute(spServiceRoute));
        //End  Add JVitug - E-06783.7 - 2024-02-01
        
        toDoCreator.addMessageParameter(stopDateOfOldTenant.toString(dateFormat));
        //Start Change JVitug - TBD - 2023-12-14
        toDoCreator.addMessageParameter(startDateOfNewTenant.toString(dateFormat));
        //End Change JVitug - TBD - 2023-12-14
        
        //Start Add JVitug - E-06783.7 - 2024-02-01
        toDoCreator.addMessageParameter(serviceAgreement.fetchPremise().getId().getTrimmedValue());
        toDoCreator.addForeignKeyCharacteristic(premiseCharType, serviceAgreement.fetchPremise());
        //End Add JVitug - E-06783.7 - 2024-02-01
        
        return toDoCreator.create();
    }
    
  //Start Add JVitug - TBD - 2023-12-12
    /**
     * Check if the Landlord of this SA's premise is the same as the SA's account
     * @return
     */
    private Bool accountIsLandLordOfThisPremise() {
    	Bool isAccountLandlordOfThisPremise = Bool.FALSE;
    	Landlord landlord = serviceAgreement.fetchPremise().getLandLordId().getEntity();
    	
    	//If the landlord 's account is equal to this SA's account, this means 
    	//that this SA might be for the Service SA's land lord reversion
    	if(landlord.getAccountId().compareTo(serviceAgreement.getAccount().getId()) == 0) {
    		isAccountLandlordOfThisPremise = Bool.TRUE;
    	}
    	return isAccountLandlordOfThisPremise;
    }
    
    /**
     * Check if there is another pending stop SA linked to this SA's
     * premise whose stop date is the same as the Start date of this SA.
     * @return true if there is a pending stop SA on the same premise 
     * of this SA whose stop date is the same as this SA's start date
     */
    private Bool hasPendingStopSAWithSameStopDateAsStartDate(ServiceAgreement landlordSA) {
    	Bool hasPendingStopSAWithSameEndDateAsStopDate = Bool.FALSE;
    	StringBuilder stringSql = new StringBuilder();
    	PreparedStatement sql;
    	SQLResultRow result;
    	
    	stringSql.append("SELECT ");
    	//Start Change JVitug - E06783.Issue3 - 2024-01-09
    	//stringSql.append(   "SA.SA_ID ");
    	stringSql.append(   "SAP.SA_SP_ID ");
    	//End Change JVitug - E06783.Issue3 - 2024-01-09
    	stringSql.append("FROM ");
    	//Start Change JVitug - E06783.Issue3 - 2024-01-09
    	//stringSql.append(   "CI_SA SA ");
    	stringSql.append(   "CI_SA SA, ");
    	stringSql.append(   "CI_SA_SP SAP ");
    	//End Change JVitug - E06783.Issue3 - 2024-01-09
    	stringSql.append("WHERE ");
    	stringSql.append(   "SA.SA_ID <> :thisSA ");
    	stringSql.append("AND ");
    	stringSql.append(   "SA.ACCT_ID <> :thisAccount ");
    	stringSql.append("AND ");
    	stringSql.append(   "SA.SA_STATUS_FLG = :pendingStop ");
    	stringSql.append("AND ");
    	stringSql.append(   "SA.CHAR_PREM_ID = :thisSAPremise ");
    	stringSql.append("AND ");
    	stringSql.append(   "SA.END_DT = :thisSAStartDate ");
    	//Start Add JVitug - E06783.Issue3 - 2024-01-09
    	stringSql.append("AND ");
    	stringSql.append(   "SA.SA_ID = SAP.SA_ID ");
    	stringSql.append("AND ");
    	stringSql.append(   "SAP.SP_ID = :servicePoint ");
    	//End Add JVitug - E06783.Issue3 - 2024-01-09
    	
    	sql = createPreparedStatement(stringSql.toString() , getClass().getName());
    	sql.bindId("thisSA" , landlordSA.getId());
    	sql.bindId("thisAccount", landlordSA.getAccount().getId());
    	sql.bindLookup("pendingStop" , ServiceAgreementStatusLookup.constants.PENDING_STOP);
    	sql.bindId("thisSAPremise", landlordSA.fetchPremise().getId());
    	sql.bindDate("thisSAStartDate" , landlordSA.getStartDate());
    	//Start Add JVitug - E06783.Issue3 - 2024-01-09
    	sql.bindId("servicePoint", servicePoint.getId());
    	//Start Add JVitug - E06783.Issue3 - 2024-01-09
    	
    	result = sql.firstRow();
    	
    	if(notNull(result)) {
    		hasPendingStopSAWithSameEndDateAsStopDate = Bool.TRUE;
    		//Start Add JVitug - E06783.Issue3 - 2024-01-09
    		pendingStopSASPLinkedToLandlordSA = result.getEntity("SA_SP_ID" , ServiceAgreementServicePoint.class);
    		//End Add JVitug - E06783.Issue3 - 2024-01-09		
    	}
    	
    	return hasPendingStopSAWithSameEndDateAsStopDate;
    }
    //End Add JVitug - TBD - 2023-12-12
    
}
