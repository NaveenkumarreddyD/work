/**************************************************************************
 *
 * PROGRAM DESCRIPTION:
 *
 * NA0010 - Collection Criteria Algorithm
 * 
 * Returns true to Account Debt Monitor, in case conditions are satisfied,
 * so that Collection process may be created.
 *
 **************************************************************************
 *
 * CHANGE HISTORY:
 *
 * Date:        by:     Reason:
 * YYYY-MM-DD   IN      Reason text.
 *
 * 2013-01-02   Neha    NA0010. Initial Version.
 * 2013-03-07   MOL     MOL20130307. Fixed the Null Pointer Exception when
 *                      Account has budget plan but it is currently not on
 *                      budget. Also fixed the SQL that checks if the Account
 *                      is currently on budget.
 * 2016-01-25   MPang	Updated for CCB v2.4 compilation.
 * 2018-07-25   SFelip  CCB v2.6 Upgrade. Remove trim from SQLS that are no
 *                      longer needed. 
 **************************************************************************/

package com.splwg.cm.domain.admin.collectionClassControl;

import java.math.BigInteger;
import java.util.List;

import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.Money;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.sql.PreparedStatement;
import com.splwg.base.api.sql.SQLResultRow;
import com.splwg.base.domain.common.algorithm.Algorithm;
import com.splwg.base.domain.common.businessObject.BusinessObject;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus;
import com.splwg.base.domain.common.businessObject.BusinessObjectStatus_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.common.characteristicType.CharacteristicValue_Id;
import com.splwg.ccb.api.lookup.BillSegmentStatusLookup;
import com.splwg.ccb.api.lookup.CaseConditionLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.api.lookup.CollectionConditionPriorityLookup;
import com.splwg.ccb.api.lookup.ServiceAgreementStatusLookup;
import com.splwg.ccb.api.lookup.SpecialRoleLookup;
//Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
/*import com.splwg.ccb.domain.admin.budgetPlan.BudgetPlan;
import com.splwg.ccb.domain.admin.caseType.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.CaseType;
import com.splwg.ccb.domain.admin.cisDivision.CisDivision;
import com.splwg.ccb.domain.admin.collectionClassControl.CollectionClassControl;
import com.splwg.ccb.domain.admin.collectionClassControl.CollectionClassControlCollectionAlgorithmSpot;
import com.splwg.ccb.domain.admin.debtClass.DebtClass;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.ServiceAgreementType_Id;
import com.splwg.ccb.domain.customerinfo.account.Account;
import com.splwg.ccb.domain.customerinfo.account.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.person.Person;
import com.splwg.ccb.domain.customerinfo.person.PersonCharacteristic;
import com.splwg.ccb.domain.customerinfo.person.Person_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.ServicePointCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceTask.ServiceTaskCharacteristic;
import com.splwg.ccb.domain.rate.rateSchedule.RateSchedule;*/

import com.splwg.ccb.domain.admin.budgetPlan.entity.BudgetPlan;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus;
import com.splwg.ccb.domain.admin.caseType.entity.CaseStatus_Id;
import com.splwg.ccb.domain.admin.caseType.entity.CaseType;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.collectionClassControl.entity.CollectionClassControl;
import com.splwg.ccb.domain.admin.collectionClassControl.algorithm.collection.CollectionClassControlCollectionAlgorithmSpot;
import com.splwg.ccb.domain.admin.debtClass.entity.DebtClass;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType;
import com.splwg.ccb.domain.admin.serviceAgreementType.entity.ServiceAgreementType_Id;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountCharacteristic;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.person.entity.PersonCharacteristic;
import com.splwg.ccb.domain.customerinfo.person.entity.Person_Id;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreementCharacteristic;
import com.splwg.ccb.domain.customerinfo.serviceAgreement.entity.ServiceAgreement_Id;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic;
import com.splwg.base.domain.serviceTask.ServiceTaskCharacteristic;
import com.splwg.ccb.domain.rate.rateSchedule.entity.RateSchedule;
//End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
import com.splwg.cm.domain.customMessages.CustomMessageRepository;

/**
 *
@AlgorithmComponent (softParameters = { @AlgorithmSoftParameter (name = accountsCreditRating, type = integer, required = false)
 *            , @AlgorithmSoftParameter (lookupName = characteristicEntity, name = limitingCharacteristicEntity, type = lookup,required = false)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = limitingCharacteristicType, type = entity, required = false)
 *            , @AlgorithmSoftParameter (name = limitingCharacteristicValue, required = false, type = string)
 *            , @AlgorithmSoftParameter (name = limitingEffectiveDays, type = integer, required = false)
 *            , @AlgorithmSoftParameter (entityName = caseType, name = caseType, type = entity, required = false)
 *            , @AlgorithmSoftParameter (lookupName = caseCondition, name = caseConditionFlg, type = lookup, required = false)
 *            , @AlgorithmSoftParameter (name = caseStatusCd, required = false, type = string)
 *            , @AlgorithmSoftParameter (entityName = rateSchedule, name = rateSchedule, type = entity, required = false)
 *            , @AlgorithmSoftParameter (name = accountBudgetFlg, required = false, type = boolean)
 *            , @AlgorithmSoftParameter (entityName = budgetPlan, name = budgetPlan, type = entity, required = false)
 *            , @AlgorithmSoftParameter (name = unbilledSaType, required = false, type = string)
 *            , @AlgorithmSoftParameter (entityName = cisDivision, name = unbilledSaCisDivision, type = entity, required = false)
 *            , @AlgorithmSoftParameter (lookupName = specialRole, name = unbilledSaTypeSpecialRoleFlg, type = lookup, required = false)
 *            , @AlgorithmSoftParameter (entityName = businessObject, name = pledgeBO, type = entity, required = false)
 *            , @AlgorithmSoftParameter (name = svcTaskStatusCd, required = false, type = string)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = svcTaskAcctCharType, type = entity, required = false)
 *            , @AlgorithmSoftParameter (entityName = characteristicType, name = svcTaskSACharType, type = entity, required = false)
 *            }
 *            )
 */

public class CmValidateCollectionCondition_Impl extends
        CmValidateCollectionCondition_Gen implements
        CollectionClassControlCollectionAlgorithmSpot {

    // Soft parameter
    private BigInteger parmAccountsCreditRating;
    private CharacteristicEntityLookup parmLimitingCharEntity;
    private CharacteristicType parmLimitingCharacteristicType;
    private String parmLimitingCharacteristicValue;
    private BigInteger parmLimitingEffectiveDays;
    private CaseType parmCaseType;
    private CaseConditionLookup parmCaseConditionFlg;
    private String parmCaseStatusCd;
    private RateSchedule parmRateSchedule;
    private Bool parmAccountBudgetFlg;
    private BudgetPlan parmBudgetPlan;
    private String parmUnbilledSaType;
    private CisDivision parmUnbilledSaCisDivision;
    private SpecialRoleLookup parmUnbilledSaTypeSpecialRoleFlg;
    private BusinessObject parmPledgeBO;
    private String parmSvcTaskStatusCd;
    private CharacteristicType parmSvcTaskAcctCharType;
    private CharacteristicType parmSvcTaskSACharType;

    private static final String LIMITING_CHAR_ENTITY_PARAM_NAME = "Limiting Characteristic Entity";
    private static final String LIMITING_CHAR_TYPE_PARAM_NAME = "Limiting Characteristic Type";
    private static final String LIMITING_CHAR_VAL_PARAM_NAME = "Limiting Characteristic Value";
    private static final String LIMITING_CHAR_EFF_DAYS_PARAM_NAME = "Limiting Characteristic Effective days";
    private static final String CASE_CONDITION_FLG_PARAM_NAME = "Case Condition Flag";
    private static final String CASE_STATUS_CD_PARAM_NAME = "Case Status Code";
    private static final String PLEDGE_BO_PARAM_NAME = "Pledge Business Object";
    private static final String SERVICE_TASK_STATUS_PARAM_NAME = "Service Task Status";
    private static final String SERVICE_TASK_ACCT_CHAR_TYPE_PARAM_NAME = "Service Task Account Characteristic Type";
    private static final String SERVICE_TASK_SA_CHAR_TYPE_PARAM_NAME = "Service Task Service Agreement Characteristic Type";

    private Date effectiveDate; 

    // Hard parameters
    private Account parmAccount;
    private DebtClass parmDebtclass;
    private Bool isConditionSatisfied = Bool.TRUE;    

    public Bool getIsConditionSatisfied() {  
        return isConditionSatisfied;
    }

    public void setAccount(Account arg0) {
        parmAccount = arg0;
    }

    public void setCollectionClassControl(CollectionClassControl arg0) {

    }

    public void setCollectionConditionAlgorithm(Algorithm arg0) {

    }

    public void setCollectionConditionPriority(
            CollectionConditionPriorityLookup arg0) {

    }

    public void setDebtClass(DebtClass arg0) {
        parmDebtclass = arg0;
    }

    protected void extraSoftParameterValidations(boolean forAlgorithmValidation) {

        parmAccountsCreditRating = getAccountsCreditRating();

        parmLimitingCharEntity = getLimitingCharacteristicEntity();
        parmLimitingCharacteristicType = getLimitingCharacteristicType();
        parmLimitingCharacteristicValue = getLimitingCharacteristicValue();
        parmLimitingEffectiveDays = getLimitingEffectiveDays();
        // All limiting parameters need to be provided when either one is given
        if(isNull(parmLimitingCharEntity)){
            if(notNull(parmLimitingCharacteristicType) || !isEmptyOrNull(parmLimitingCharacteristicValue) || notNull(parmLimitingEffectiveDays)){
                addError(CustomMessageRepository.na0010ParamReqdWhenOtherLimitingParamProvided(getAlgorithm().getId().getTrimmedValue(), LIMITING_CHAR_ENTITY_PARAM_NAME));  
            }
        }
        if(isNull(parmLimitingCharacteristicType)){
            if(notNull(parmLimitingCharEntity) || !isEmptyOrNull(parmLimitingCharacteristicValue) || notNull(parmLimitingEffectiveDays)){
                addError(CustomMessageRepository.na0010ParamReqdWhenOtherLimitingParamProvided(getAlgorithm().getId().getTrimmedValue(), LIMITING_CHAR_TYPE_PARAM_NAME));  
            }
        }
        if(isEmptyOrNull(parmLimitingCharacteristicValue)){
            if(notNull(parmLimitingCharEntity) || notNull(parmLimitingCharacteristicType) || notNull(parmLimitingEffectiveDays)){
                addError(CustomMessageRepository.na0010ParamReqdWhenOtherLimitingParamProvided(getAlgorithm().getId().getTrimmedValue(), LIMITING_CHAR_VAL_PARAM_NAME));  
            }
        }
        if(isNull(parmLimitingEffectiveDays)){
            if(notNull(parmLimitingCharEntity) || notNull(parmLimitingCharacteristicType) || !isEmptyOrNull(parmLimitingCharacteristicValue)){
                addError(CustomMessageRepository.na0010ParamReqdWhenOtherLimitingParamProvided(getAlgorithm().getId().getTrimmedValue(), LIMITING_CHAR_EFF_DAYS_PARAM_NAME));  
            }
        }

        if(notNull(parmLimitingCharEntity)){ 
            // Validate Characteristic Entity
            if(!parmLimitingCharEntity.isPerson() && !parmLimitingCharEntity.isAccount() && !parmLimitingCharEntity.isServiceAgreement() && !parmLimitingCharEntity.isServicePoint()){
                addError(CustomMessageRepository.na0010InvalidCharEntity(getAlgorithm().getId().getTrimmedValue(), parmLimitingCharEntity.getLookupValue().fetchIdFieldValue()));  
            }
            // Validate Char Type and Char Value 
            validateCharTypeCharValue(parmLimitingCharacteristicType, parmLimitingCharacteristicValue,parmLimitingCharEntity);

            // Validate limiting effective days
            if(parmLimitingEffectiveDays.compareTo(BigInteger.ZERO) <0){
                addError(CustomMessageRepository.na0010InvalidNumericValue(getAlgorithm().getId().getTrimmedValue(), parmLimitingEffectiveDays.toString()));  
            }
        }

        parmCaseType = getCaseType();
        parmCaseConditionFlg = getCaseConditionFlg();
        parmCaseStatusCd = getCaseStatusCd();
        // All Case parameters need to be provided when either one is given
        if(notNull(parmCaseConditionFlg) && isNull(parmCaseType)){            
            addError(CustomMessageRepository.na0010CaseTypeRqdWhenCondFlgOrStatProvided(getAlgorithm().getId().getTrimmedValue(), CASE_CONDITION_FLG_PARAM_NAME));  
        }
        if(!isEmptyOrNull(parmCaseStatusCd) && isNull(parmCaseType)){
            addError(CustomMessageRepository.na0010CaseTypeRqdWhenCondFlgOrStatProvided(getAlgorithm().getId().getTrimmedValue(), CASE_STATUS_CD_PARAM_NAME));  
        }
        if(notNull(parmCaseType) && isEmptyOrNull(parmCaseStatusCd) && isNull(parmCaseConditionFlg)){
            addError(CustomMessageRepository.na0010ParamRqdWhenCaseTypeProvided(getAlgorithm().getId().getTrimmedValue(), parmCaseType.getId().getTrimmedValue()));  
        }
        if(notNull(parmCaseType) && !isEmptyOrNull(parmCaseStatusCd)){
            CaseStatus_Id caseStatusId = new CaseStatus_Id(parmCaseType, parmCaseStatusCd);
            if(isNull(caseStatusId.getEntity())){
                addError(CustomMessageRepository.na0010InvalidCaseStatusForCaseType(getAlgorithm().getId().getTrimmedValue(), parmCaseStatusCd, parmCaseType.getId().getTrimmedValue()));  
            }
        }
        parmRateSchedule = getRateSchedule();

        parmAccountBudgetFlg = getAccountBudgetFlg();
        parmBudgetPlan = getBudgetPlan();
        if(notNull(parmBudgetPlan)){
            if(isNull(parmAccountBudgetFlg) || parmAccountBudgetFlg.isFalse()){        
                addError(CustomMessageRepository.na0010BudgetPlanNotAllowedWhnFlagIsFalse(getAlgorithm().getId().getTrimmedValue(), parmBudgetPlan.getId().getTrimmedValue()));  
            }
        }

        parmUnbilledSaType = getUnbilledSaType();
        parmUnbilledSaCisDivision = getUnbilledSaCisDivision();
        if((!isEmptyOrNull(parmUnbilledSaType) && isNull(parmUnbilledSaCisDivision))){
            addError(CustomMessageRepository.na0010UnbilledCisDivisionReqd(getAlgorithm().getId().getTrimmedValue()));
        }
        if((isEmptyOrNull(parmUnbilledSaType) && notNull(parmUnbilledSaCisDivision))){            
            addError(CustomMessageRepository.na0010UnbilledSATypeReqd(getAlgorithm().getId().getTrimmedValue()));
        }
        if(notNull(parmUnbilledSaCisDivision)){
            ServiceAgreementType serviceAgreementType = new ServiceAgreementType_Id(parmUnbilledSaCisDivision, parmUnbilledSaType).getEntity();
            if(isNull(serviceAgreementType)){
                addError(CustomMessageRepository.na0010InvalidServiceAgreementType(getAlgorithm().getId().getTrimmedValue(), parmUnbilledSaType, parmUnbilledSaCisDivision.getId().getTrimmedValue()));
            }
        }
        parmUnbilledSaTypeSpecialRoleFlg = getUnbilledSaTypeSpecialRoleFlg();
        if(notNull(parmUnbilledSaTypeSpecialRoleFlg) && isEmptyOrNull(parmUnbilledSaType)){
            addError(CustomMessageRepository.na0010SaTypeReqdWhenRoleGiven(getAlgorithm().getId().getTrimmedValue()));
        }

        parmPledgeBO = getPledgeBO();
        parmSvcTaskStatusCd = getSvcTaskStatusCd();
        parmSvcTaskAcctCharType = getSvcTaskAcctCharType();
        parmSvcTaskSACharType = getSvcTaskSACharType();
        if(isNull(parmPledgeBO)){
            if(notNull(parmSvcTaskAcctCharType) || !isEmptyOrNull(parmSvcTaskStatusCd) || notNull(parmSvcTaskSACharType)){
                addError(CustomMessageRepository.na0010ParamRqdWhenSvcTaskParamProvided(getAlgorithm().getId().getTrimmedValue(), PLEDGE_BO_PARAM_NAME));  
            }
        }
        if(isEmptyOrNull(parmSvcTaskStatusCd)){
            if(notNull(parmPledgeBO) || notNull(parmSvcTaskAcctCharType) || notNull(parmSvcTaskSACharType)){
                addError(CustomMessageRepository.na0010ParamRqdWhenSvcTaskParamProvided(getAlgorithm().getId().getTrimmedValue(), SERVICE_TASK_STATUS_PARAM_NAME));  
            }
        }
        if(isNull(parmSvcTaskAcctCharType)){
            if(notNull(parmPledgeBO) || !isEmptyOrNull(parmSvcTaskStatusCd) || notNull(parmSvcTaskSACharType)){
                addError(CustomMessageRepository.na0010ParamRqdWhenSvcTaskParamProvided(getAlgorithm().getId().getTrimmedValue(), SERVICE_TASK_ACCT_CHAR_TYPE_PARAM_NAME));  
            }
        }
        if(isNull(parmSvcTaskSACharType)){
            if(notNull(parmPledgeBO) || !isEmptyOrNull(parmSvcTaskStatusCd) || notNull(parmSvcTaskAcctCharType)){
                addError(CustomMessageRepository.na0010ParamRqdWhenSvcTaskParamProvided(getAlgorithm().getId().getTrimmedValue(), SERVICE_TASK_SA_CHAR_TYPE_PARAM_NAME));  
            }
        }
        if(notNull(parmPledgeBO)){
            // Validate parmSvcTaskStatusCd
            BusinessObjectStatus businessObjectStatus = new BusinessObjectStatus_Id(parmPledgeBO, parmSvcTaskStatusCd).getEntity();
            if(isNull(businessObjectStatus)){
                addError(CustomMessageRepository.na0010InvalidBusinessObjectStatus(getAlgorithm().getId().getTrimmedValue(), parmSvcTaskStatusCd, parmPledgeBO.getId().getTrimmedValue()));
            }
            // Validate parmSvcTaskAcctCharType
            CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(parmSvcTaskAcctCharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
            if (isNull(charEntityId.getEntity())){
                addError(CustomMessageRepository.na0010InvalidSvcTaskAcctCharType(getAlgorithm().getId().getTrimmedValue(), parmSvcTaskAcctCharType.getId().getTrimmedValue(),CharacteristicEntityLookup.constants.SERVICE_TASK.getLookupValue().fetchIdFieldValue()));
            } 
            // Validate parmSvcTaskAcctCharType
            charEntityId = new CharacteristicEntity_Id(parmSvcTaskSACharType, CharacteristicEntityLookup.constants.SERVICE_TASK);
            if (isNull(charEntityId.getEntity())){
                addError(CustomMessageRepository.na0010InvalidSvcTaskSACharType(getAlgorithm().getId().getTrimmedValue(), parmSvcTaskSACharType.getId().getTrimmedValue(),CharacteristicEntityLookup.constants.SERVICE_TASK.getLookupValue().fetchIdFieldValue()));
            } 
        }
    }

    private void validateCharTypeCharValue(CharacteristicType charType, String charVal,CharacteristicEntityLookup lookup){
        CharacteristicEntity_Id charEntityId = new CharacteristicEntity_Id(charType, lookup);
        if (isNull(charEntityId.getEntity())){
            addError(CustomMessageRepository.na0010InvalidInputCharTypeForEntity(getAlgorithm().getId().getTrimmedValue(), charType.getId().getTrimmedValue(),lookup.getLookupValue().fetchIdFieldValue()));
        } 

        //validate Characteristic Values
        CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
        if(charTypeLookup.isPredefinedValue()){
            CharacteristicValue_Id charValId = new CharacteristicValue_Id(charType.getId(), charVal);
            if(isNull(charValId.getEntity())){
                addError(CustomMessageRepository.na0010InvalidInputCharVal(getAlgorithm().getId().getTrimmedValue(), charVal, charType.getId().getTrimmedValue()));
            }
        }
    }

    public void invoke() {
        if(notNull(parmAccountsCreditRating)){
            if((parmAccount.getCreditRatingInfo(getProcessDateTime().getDate())).getCreditRatingPoints().compareTo(parmAccountsCreditRating) > 0){
                isConditionSatisfied = Bool.FALSE;  
                return;
            }
        }
        if(notNull(parmLimitingCharEntity)){
            effectiveDate = getProcessDateTime().getDate().addDays(parmLimitingEffectiveDays.negate().intValue());

            if(parmLimitingCharEntity.compareTo(CharacteristicEntityLookup.constants.PERSON) == 0 ){
                if(getPersonCharacteristic().isFalse()){
                    return;
                }
            }else if(parmLimitingCharEntity.compareTo(CharacteristicEntityLookup.constants.ACCOUNT) == 0 ){
                if(getAccountCharacteristic().isFalse()){
                    return;
                }
            }else if(parmLimitingCharEntity.compareTo(CharacteristicEntityLookup.constants.SERVICE_AGREEMENT) == 0 ){
                if(getSACharacteristic().isFalse()){
                    return;
                }
            }else if(parmLimitingCharEntity.compareTo(CharacteristicEntityLookup.constants.SERVICE_POINT) == 0 ){
                if(getSPCharacteristic().isFalse()){
                    return;
                }
            }
        }
        if(notNull(parmCaseType)){
            if(getCase().isFalse()){
                return;
            }
        }

        if(notNull(parmRateSchedule)){
            if(getRateScheduleMatchesAccount().isFalse()){
                return;
            }                
        }
        if(notNull(parmAccountBudgetFlg) && parmAccountBudgetFlg.isTrue()){
            StringBuilder getSAString = new StringBuilder();
            getSAString.append("SELECT SA.SA_ID FROM CI_SA SA, CI_SA_TYPE SATY ");
            getSAString.append("WHERE SA.ACCT_ID = :parmAcctId ");
            getSAString.append("AND SA.SA_TYPE_CD = SATY.SA_TYPE_CD ");
            getSAString.append("AND SATY.CIS_DIVISION = SA.CIS_DIVISION ");
            getSAString.append("AND SATY.DEBT_CL_CD = :debtClass");        
           //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
           // PreparedStatement getSAPrepStmt = createPreparedStatement(getSAString.toString()); 
            PreparedStatement getSAPrepStmt = createPreparedStatement(getSAString.toString(), getClass().getName()); 
           //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
            getSAPrepStmt.bindId("parmAcctId", parmAccount.getId());
            getSAPrepStmt.bindId("debtClass", parmDebtclass.getId());
            List<SQLResultRow> resultList = getSAPrepStmt.list();
            getSAPrepStmt.close();
            ServiceAgreement_Id serviceAgreementId;
            for(SQLResultRow row : resultList){
                serviceAgreementId = (ServiceAgreement_Id)row.getId("SA_ID", ServiceAgreement.class);

                StringBuilder getRecurAmtString = new StringBuilder();
                // MOL20130307
                // getRecurAmtString.append("SELECT SUM(RCR_CHG_AMT) TOT_RCR_AMT FROM CI_SA_RCHG_HIST SR WHERE SR.SA_ID = :saId AND SR.EFFDT <= :processDate");
                getRecurAmtString.append("SELECT RCR_CHG_AMT TOT_RCR_AMT FROM CI_SA_RCHG_HIST SR WHERE SR.SA_ID = :saId AND SR.EFFDT = (SELECT MAX(EFFDT) FROM CI_SA_RCHG_HIST SR2 WHERE SR2.SA_ID = SR.SA_ID AND SR2.EFFDT <= :processDate)");
              //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
              // PreparedStatement getRecurAmtPrepStmt = createPreparedStatement(getRecurAmtString.toString());
                PreparedStatement getRecurAmtPrepStmt = createPreparedStatement(getRecurAmtString.toString(),getClass().getName());
              //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
                getRecurAmtPrepStmt.bindId("saId", serviceAgreementId);
                getRecurAmtPrepStmt.bindDate("processDate", getProcessDateTime().getDate());

                List<SQLResultRow> result = getRecurAmtPrepStmt.list();
                getRecurAmtPrepStmt.close();
                Money recurringAmount = result.iterator().next().getMoney("TOT_RCR_AMT");
                
                // MOL20130307
                if (isNull(recurringAmount)) {
                	// SA does not have recurring charges
					isConditionSatisfied = Bool.FALSE;
				} else {
	                if(recurringAmount.compareTo(Money.ZERO) == 0){
	                    isConditionSatisfied = Bool.FALSE;                    
	                }else{
	                    isConditionSatisfied = Bool.TRUE;  
	                    break;
	                }
				}
                
            }
            if(isConditionSatisfied.isFalse()){ // SA does not have recurring charges > 0 so return false
                return;
            }
            if(notNull(parmBudgetPlan)){
                if(isNull(parmAccount.getBudgetPlanId()) || !parmAccount.getBudgetPlanId().equals(parmBudgetPlan.getId())){
                    isConditionSatisfied = Bool.FALSE;
                    return;
                }
            }
        }
        if(!isEmptyOrNull(parmUnbilledSaType)){
            if(getUnbilledSAOfAccount().isFalse()){
                return;
            }
        }
        if(notNull(parmPledgeBO)){
            if(getServiceTaskForAccount().isFalse()){
                return;
            }
        }
        isConditionSatisfied = Bool.TRUE;
    }

    private Bool getPersonCharacteristic(){
        CharacteristicTypeLookup characteristicTypeLookup = parmLimitingCharacteristicType.getCharacteristicType();

        StringBuilder getPersonCharString = new StringBuilder();
        getPersonCharString.append("SELECT 'X' FROM CI_ACCT_PER AP,CI_PER_CHAR CH ");
        getPersonCharString.append("WHERE AP.MAIN_CUST_SW = 'Y' ");
        getPersonCharString.append("AND AP.ACCT_ID = :accountID ");
        getPersonCharString.append("AND AP.PER_ID = CH.PER_ID ");

        getPersonCharString.append(appendCharConditions(characteristicTypeLookup));
      //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
      // PreparedStatement getPersonCharPrepStmt = createPreparedStatement(getPersonCharString.toString()); 
        PreparedStatement getPersonCharPrepStmt = createPreparedStatement(getPersonCharString.toString(), getClass().getName());
      //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        getPersonCharPrepStmt.bindId("accountID", parmAccount.getId());
        getPersonCharPrepStmt.bindId("limitingCharacteristicType", parmLimitingCharacteristicType.getId());

        if(characteristicTypeLookup.isPredefinedValue()){
            getPersonCharPrepStmt.bindStringProperty("limitingCharValue", PersonCharacteristic.properties.characteristicValue ,parmLimitingCharacteristicValue.trim());    
        }else if(characteristicTypeLookup.isForeignKeyValue()){
            getPersonCharPrepStmt.bindStringProperty("limitingCharValue", PersonCharacteristic.properties.characteristicValueForeignKey1,parmLimitingCharacteristicValue.trim());         
        }else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
            getPersonCharPrepStmt.bindStringProperty("limitingCharValue", PersonCharacteristic.properties.adhocCharacteristicValue, parmLimitingCharacteristicValue.trim());
        }

        getPersonCharPrepStmt.bindDate("effectiveDate", effectiveDate);

        List<SQLResultRow> resultList = getPersonCharPrepStmt.list();
        getPersonCharPrepStmt.close();

        if(resultList.isEmpty()){
            isConditionSatisfied = Bool.FALSE;
        }
        return isConditionSatisfied;
    }

    private StringBuilder appendCharConditions(CharacteristicTypeLookup characteristicTypeLookup){
        StringBuilder queryString = new StringBuilder();
        queryString.append("AND CH.CHAR_TYPE_CD = :limitingCharacteristicType ");
        if(characteristicTypeLookup.isPredefinedValue()){
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //queryString.append("AND TRIM(CH.CHAR_VAL) = :limitingCharValue ");
            queryString.append("AND CH.CHAR_VAL = :limitingCharValue ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change
        }else if(characteristicTypeLookup.isForeignKeyValue()){
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //queryString.append("AND TRIM(CH.CHAR_VAL_FK1) = :limitingCharValue ");
            queryString.append("AND CH.CHAR_VAL_FK1 = :limitingCharValue ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change
        }else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //queryString.append("AND TRIM(CH.ADHOC_CHAR_VAL) = :limitingCharValue ");
            queryString.append("AND CH.ADHOC_CHAR_VAL = :limitingCharValue ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change
        }
        queryString.append("AND CH.EFFDT <= :effectiveDate ");
        return queryString;
    }
    private Bool getAccountCharacteristic(){
        CharacteristicTypeLookup characteristicTypeLookup = parmLimitingCharacteristicType.getCharacteristicType();

        StringBuilder getAcctCharString = new StringBuilder();
        getAcctCharString.append("SELECT 'X' FROM CI_ACCT_CHAR CH ");
        getAcctCharString.append("WHERE CH.ACCT_ID = :accountID ");

        getAcctCharString.append(appendCharConditions(characteristicTypeLookup));
      //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
      // PreparedStatement getAcctCharPrepStmt = createPreparedStatement(getAcctCharString.toString()); 
        PreparedStatement getAcctCharPrepStmt = createPreparedStatement(getAcctCharString.toString(), getClass().getName()); 
      //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        getAcctCharPrepStmt.bindId("accountID", parmAccount.getId());
        getAcctCharPrepStmt.bindId("limitingCharacteristicType", parmLimitingCharacteristicType.getId());

        if(characteristicTypeLookup.isPredefinedValue()){
            getAcctCharPrepStmt.bindStringProperty("limitingCharValue", AccountCharacteristic.properties.characteristicValue ,parmLimitingCharacteristicValue.trim());    
        }else if(characteristicTypeLookup.isForeignKeyValue()){
            getAcctCharPrepStmt.bindStringProperty("limitingCharValue", AccountCharacteristic.properties.characteristicValueForeignKey1,parmLimitingCharacteristicValue.trim());         
        }else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
            getAcctCharPrepStmt.bindStringProperty("limitingCharValue", AccountCharacteristic.properties.adhocCharacteristicValue, parmLimitingCharacteristicValue.trim());
        }
        getAcctCharPrepStmt.bindDate("effectiveDate", effectiveDate);

        List<SQLResultRow> resultList = getAcctCharPrepStmt.list();
        getAcctCharPrepStmt.close();
        if(resultList.isEmpty()){
            isConditionSatisfied = Bool.FALSE;
        }
        return isConditionSatisfied;
    }

    private Bool getSACharacteristic(){
        CharacteristicTypeLookup characteristicTypeLookup = parmLimitingCharacteristicType.getCharacteristicType();

        StringBuilder getSACharString = new StringBuilder();
        getSACharString.append("SELECT 'X' FROM CI_SA SA, CI_SA_TYPE SATYPE, CI_SA_CHAR CH ");
        getSACharString.append("WHERE SA.ACCT_ID = :accountID ");
        getSACharString.append("AND SATYPE.CIS_DIVISION = SA.CIS_DIVISION ");
        getSACharString.append("AND SATYPE.SA_TYPE_CD = SA.SA_TYPE_CD ");
        getSACharString.append("AND SATYPE.DEBT_CL_CD = :debtClass ");
        getSACharString.append("AND SA.SA_ID = CH.SA_ID "); 

        getSACharString.append(appendCharConditions(characteristicTypeLookup));
      //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
      // PreparedStatement getSACharPrepStmt = createPreparedStatement(getSACharString.toString()); 
        PreparedStatement getSACharPrepStmt = createPreparedStatement(getSACharString.toString(), getClass().getName()); 
      //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        getSACharPrepStmt.bindId("accountID", parmAccount.getId());
        getSACharPrepStmt.bindId("debtClass", parmDebtclass.getId());
        getSACharPrepStmt.bindId("limitingCharacteristicType", parmLimitingCharacteristicType.getId());

        if(characteristicTypeLookup.isPredefinedValue()){
            getSACharPrepStmt.bindStringProperty("limitingCharValue", ServiceAgreementCharacteristic.properties.characteristicValue ,parmLimitingCharacteristicValue.trim());    
        }else if(characteristicTypeLookup.isForeignKeyValue()){
            getSACharPrepStmt.bindStringProperty("limitingCharValue", ServiceAgreementCharacteristic.properties.characteristicValueForeignKey1,parmLimitingCharacteristicValue.trim());         
        }else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
            getSACharPrepStmt.bindStringProperty("limitingCharValue", ServiceAgreementCharacteristic.properties.adhocCharacteristicValue, parmLimitingCharacteristicValue.trim());
        }
        getSACharPrepStmt.bindDate("effectiveDate", effectiveDate);

        List<SQLResultRow> resultList = getSACharPrepStmt.list();
        getSACharPrepStmt.close();
        if(resultList.isEmpty()){
            isConditionSatisfied = Bool.FALSE;
        }
        return isConditionSatisfied;
    }

    private Bool getSPCharacteristic(){
        CharacteristicTypeLookup characteristicTypeLookup = parmLimitingCharacteristicType.getCharacteristicType();

        StringBuilder getSPCharString = new StringBuilder();
        getSPCharString.append("SELECT 'X' FROM CI_SA SA, CI_SA_TYPE SATYPE, CI_SA_SP SS, CI_SP_CHAR CH ");
        getSPCharString.append("WHERE SA.ACCT_ID = :accountID ");
        getSPCharString.append("AND SATYPE.CIS_DIVISION = SA.CIS_DIVISION ");
        getSPCharString.append("AND SATYPE.SA_TYPE_CD = SA.SA_TYPE_CD ");
        getSPCharString.append("AND SATYPE.DEBT_CL_CD = :debtClass ");
        getSPCharString.append("AND SA.SA_ID = SS.SA_ID "); 
        getSPCharString.append("AND SS.SP_ID = CH.SP_ID "); 

        getSPCharString.append(appendCharConditions(characteristicTypeLookup));
      //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
       // PreparedStatement getSPCharPrepStmt = createPreparedStatement(getSPCharString.toString()); 
        PreparedStatement getSPCharPrepStmt = createPreparedStatement(getSPCharString.toString(),getClass().getName()); 
      //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        getSPCharPrepStmt.bindId("accountID", parmAccount.getId());
        getSPCharPrepStmt.bindId("debtClass", parmDebtclass.getId());
        getSPCharPrepStmt.bindId("limitingCharacteristicType", parmLimitingCharacteristicType.getId());

        if(characteristicTypeLookup.isPredefinedValue()){
            getSPCharPrepStmt.bindStringProperty("limitingCharValue", ServicePointCharacteristic.properties.characteristicValue ,parmLimitingCharacteristicValue.trim());    
        }else if(characteristicTypeLookup.isForeignKeyValue()){
            getSPCharPrepStmt.bindStringProperty("limitingCharValue", ServicePointCharacteristic.properties.characteristicValueForeignKey1,parmLimitingCharacteristicValue.trim());         
        }else if (characteristicTypeLookup.isAdhocValue() || characteristicTypeLookup.isFileLocationValue()){
            getSPCharPrepStmt.bindStringProperty("limitingCharValue", ServicePointCharacteristic.properties.adhocCharacteristicValue, parmLimitingCharacteristicValue.trim());
        }
        getSPCharPrepStmt.bindDate("effectiveDate", effectiveDate);

        List<SQLResultRow> resultList = getSPCharPrepStmt.list();
        getSPCharPrepStmt.close();
        if(resultList.isEmpty()){
            isConditionSatisfied = Bool.FALSE;
        }
        return isConditionSatisfied;
    }
    private Bool getRateScheduleMatchesAccount(){

        StringBuilder getRSString = new StringBuilder();
        getRSString.append("SELECT 'X' FROM CI_SA SA, CI_SA_TYPE SATYPE, CI_SA_RS_HIST SR ");
        getRSString.append("WHERE SA.ACCT_ID =  :accountID ");
        getRSString.append("AND SATYPE.CIS_DIVISION = SA.CIS_DIVISION ");
        getRSString.append("AND SATYPE.SA_TYPE_CD = SA.SA_TYPE_CD ");
        getRSString.append("AND SATYPE.DEBT_CL_CD = :debtClass ");
        getRSString.append("AND SA.SA_ID = SR.SA_ID "); 
        getRSString.append("AND SR.EFFDT = (SELECT MAX(SR1.EFFDT) FROM CI_SA_RS_HIST SR1 WHERE SR1.SA_ID = SA.SA_ID  "); 
        getRSString.append("                AND SR1.EFFDT <= :processDate)  "); 
        getRSString.append("AND SR.RS_CD = :rateSchedule "); 
      //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
      //  PreparedStatement getRSPrepStmt = createPreparedStatement(getRSString.toString()); 
        PreparedStatement getRSPrepStmt = createPreparedStatement(getRSString.toString(), getClass().getName());
      //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        getRSPrepStmt.bindId("accountID", parmAccount.getId());
        getRSPrepStmt.bindId("debtClass", parmDebtclass.getId());
        getRSPrepStmt.bindDate("processDate", getProcessDateTime().getDate());
        getRSPrepStmt.bindId("rateSchedule", parmRateSchedule.getId());

        List<SQLResultRow> resultList = getRSPrepStmt.list();
        getRSPrepStmt.close();
        if(resultList.isEmpty()){
            isConditionSatisfied = Bool.FALSE;
        }
        return isConditionSatisfied;
    }

    private Bool getCase(){

        StringBuilder getCaseString = new StringBuilder();
        getCaseString.append("SELECT 'X' FROM CI_CASE ");
        getCaseString.append("WHERE CASE_TYPE_CD = :caseType ");
        if(!isEmptyOrNull(parmCaseStatusCd)){
            // CCB v2.6 Upgrade - 2018-07-25 - Start Change
            //getCaseString.append("AND TRIM(CASE_STATUS_CD) = :caseStatusCd ");
            getCaseString.append("AND CASE_STATUS_CD = :caseStatusCd ");
            // CCB v2.6 Upgrade - 2018-07-25 - End Change
        }
        if(notNull(parmCaseConditionFlg)){
            getCaseString.append("AND CASE_COND_FLG = :caseConditionFlg ");
        }
        if(parmCaseType.getAccountUsage().isRequired()){
            getCaseString.append("AND ACCT_ID = :acctId ");  
        }
        if(parmCaseType.getPersonUsage().isRequired()){
            getCaseString.append("AND PER_ID = :perId ");    
        }
        if(parmCaseType.getPremiseUsage().isRequired()){
            getCaseString.append("AND PREM_ID IN (SELECT SP.PREM_ID FROM CI_SA SA, CI_SA_TYPE SATYPE, CI_SA_SP SASP, CI_SP SP ");
            getCaseString.append("              WHERE SA.ACCT_ID = :acctId ");   
            getCaseString.append("              AND SATYPE.CIS_DIVISION = SA.CIS_DIVISION ");  
            getCaseString.append("              AND SATYPE.SA_TYPE_CD = SA.SA_TYPE_CD ");  
            getCaseString.append("              AND SATYPE.DEBT_CL_CD = :debtClass ");  
            getCaseString.append("              AND SASP.SA_ID = SA.SA_ID ");  
            getCaseString.append("              AND SP.SP_ID = SASP.SP_ID) ");  
        }else{
            isConditionSatisfied = Bool.FALSE; 
            return isConditionSatisfied;
        }
      //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
       // PreparedStatement getCasePrepStmt = createPreparedStatement(getCaseString.toString()); 
        PreparedStatement getCasePrepStmt = createPreparedStatement(getCaseString.toString(), getClass().getName()); 
      //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        getCasePrepStmt.bindId("caseType", parmCaseType.getId());      
        if(!isEmptyOrNull(parmCaseStatusCd)){
            getCasePrepStmt.bindStringProperty("caseStatusCd", CaseStatus.properties.status, parmCaseStatusCd.trim());
        }
        if(notNull(parmCaseConditionFlg)){
            getCasePrepStmt.bindLookup("caseConditionFlg", parmCaseConditionFlg);
        }
        if(parmCaseType.getAccountUsage().isRequired()){
            getCasePrepStmt.bindId("acctId", parmAccount.getId());
        }
        if(parmCaseType.getPersonUsage().isRequired()){

            StringBuilder getUsageDetailsString = new StringBuilder();
            getUsageDetailsString.append("SELECT APER.PER_ID ");
            getUsageDetailsString.append("FROM CI_ACCT_PER APER ");
            getUsageDetailsString.append("WHERE APER.ACCT_ID = :acctId  "); 
            getUsageDetailsString.append("AND APER.MAIN_CUST_SW = 'Y' "); 
            getUsageDetailsString.append("AND APER.ACCT_REL_TYPE_CD = 'MAIN' "); 
          //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
          // PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString()); 
            PreparedStatement getUsageDetailsPrepStmt = createPreparedStatement(getUsageDetailsString.toString(), getClass().getName()); 
          //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
            getUsageDetailsPrepStmt.bindId("acctId", parmAccount.getId());

            List<SQLResultRow> usageList = getUsageDetailsPrepStmt.list();

            getUsageDetailsPrepStmt.close();
            if(!usageList.isEmpty()){
                getCasePrepStmt.bindId("perId", (Person_Id)usageList.iterator().next().getId("PER_ID", Person.class));                             
            }
        }
        if(parmCaseType.getPremiseUsage().isRequired()){
            getCasePrepStmt.bindId("debtClass", parmDebtclass.getId());           
        }
        List<SQLResultRow> resultList = getCasePrepStmt.list();
        getCasePrepStmt.close();
        if(resultList.isEmpty()){
            isConditionSatisfied = Bool.FALSE;           
        }

        return isConditionSatisfied;
    }
    private Bool getUnbilledSAOfAccount(){
        StringBuilder getSAString = new StringBuilder();
        getSAString.append("SELECT SA_ID FROM CI_SA SA, CI_SA_TYPE ST ");
        getSAString.append("WHERE SA.ACCT_ID = :accountID ");
        getSAString.append("AND SA.SA_STATUS_FLG IN (:pendingStart, :active) ");
        getSAString.append("AND SA.SA_TYPE_CD = ST.SA_TYPE_CD "); 
        getSAString.append("AND SA.CIS_DIVISION = ST.CIS_DIVISION  "); 
        // CCB v2.6 Upgrade - 2018-07-25 - Start Change
        //getSAString.append("AND TRIM(ST.SA_TYPE_CD) = :unbilledSaType ");
        getSAString.append("AND ST.SA_TYPE_CD = :unbilledSaType ");
        // CCB v2.6 Upgrade - 2018-07-25 - End Change
        getSAString.append("AND ST.CIS_DIVISION = :unbilledSaCisDivision ");
        getSAString.append("AND ST.DEBT_CL_CD = :debtClass ");
        if(notNull(parmUnbilledSaTypeSpecialRoleFlg)){
            getSAString.append("AND ST.SPECIAL_ROLE_FLG = :unbilledSaTypeSpecialRoleFlg  "); 
        }
        //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement getSAPrepStmt = createPreparedStatement(getSAString.toString()); 
        PreparedStatement getSAPrepStmt = createPreparedStatement(getSAString.toString(), getClass().getName()); 
        //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        getSAPrepStmt.bindId("accountID", parmAccount.getId());
        getSAPrepStmt.bindId("debtClass", parmDebtclass.getId());
        getSAPrepStmt.bindLookup("pendingStart", ServiceAgreementStatusLookup.constants.PENDING_START);
        getSAPrepStmt.bindLookup("active", ServiceAgreementStatusLookup.constants.ACTIVE);
        getSAPrepStmt.bindStringProperty("unbilledSaType", ServiceAgreementType.properties.saType, parmUnbilledSaType.trim());
        getSAPrepStmt.bindId("unbilledSaCisDivision", parmUnbilledSaCisDivision.getId());
        if(notNull(parmUnbilledSaTypeSpecialRoleFlg)){
            getSAPrepStmt.bindLookup("unbilledSaTypeSpecialRoleFlg", parmUnbilledSaTypeSpecialRoleFlg);
        }
        List<SQLResultRow> resultList = getSAPrepStmt.list();
        getSAPrepStmt.close();
        if(resultList.isEmpty()){
            isConditionSatisfied = Bool.FALSE;
            return isConditionSatisfied;
        }
        for(SQLResultRow row : resultList){
            StringBuilder getBillingDetailsString = new StringBuilder();
            getBillingDetailsString.append("SELECT 'X' FROM CI_BSEG BS ");
            getBillingDetailsString.append("WHERE BS.SA_ID = :saId ");
            getBillingDetailsString.append("AND BS.START_DT <= :processDate ");
            getBillingDetailsString.append("AND BS.BSEG_STAT_FLG = :frozen ");
          //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
          // PreparedStatement getBillingDetailsPrepStmt = createPreparedStatement(getBillingDetailsString.toString()); 
            PreparedStatement getBillingDetailsPrepStmt = createPreparedStatement(getBillingDetailsString.toString(), getClass().getName()); 
          //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
            getBillingDetailsPrepStmt.bindId("saId", (ServiceAgreement_Id)row.getId("SA_ID", ServiceAgreement.class));
            getBillingDetailsPrepStmt.bindDate("processDate", getProcessDateTime().getDate());
            getBillingDetailsPrepStmt.bindLookup("frozen", BillSegmentStatusLookup.constants.FROZEN);
            List<SQLResultRow> result = getBillingDetailsPrepStmt.list();
            getBillingDetailsPrepStmt.close();
            if(!result.isEmpty()){
                isConditionSatisfied = Bool.FALSE;
            }else{
                isConditionSatisfied = Bool.TRUE;
                break;
            }
        }
        return isConditionSatisfied;
    }

    private Bool getServiceTaskForAccount(){

        StringBuilder getServiceTaskString = new StringBuilder();
        getServiceTaskString.append("SELECT 'X' FROM F1_SVC_TASK ST, F1_SVC_TASK_CHAR SC1, F1_SVC_TASK_CHAR SC2, CI_SA SA, CI_SA_TYPE SATY ");
        getServiceTaskString.append("WHERE ST.BUS_OBJ_CD = :pledgeBO ");
        // CCB v2.6 Upgrade - 2018-07-25 - Start Change
        //getServiceTaskString.append("AND TRIM(ST.BO_STATUS_CD) = :svcTaskStatusCd ");
        getServiceTaskString.append("AND ST.BO_STATUS_CD = :svcTaskStatusCd ");
        // CCB v2.6 Upgrade - 2018-07-25 - End Change
        getServiceTaskString.append("AND ST.F1_SVC_TASK_ID = SC1.F1_SVC_TASK_ID "); 
        getServiceTaskString.append("AND SC1.CHAR_TYPE_CD = :svcTaskAcctCharType ");
        // CCB v2.6 Upgrade - 2018-07-25 - Start Change
        //getServiceTaskString.append("AND TRIM(SC1.CHAR_VAL_FK1) =  :account ");
        getServiceTaskString.append("AND SC1.CHAR_VAL_FK1 =  :account ");
        // CCB v2.6 Upgrade - 2018-07-25 - End Change
        getServiceTaskString.append("AND ST.F1_SVC_TASK_ID = SC2.F1_SVC_TASK_ID "); 
        getServiceTaskString.append("AND SC2.CHAR_TYPE_CD = :saCharType ");
        getServiceTaskString.append("AND TRIM(SC2.CHAR_VAL_FK1) =  TRIM(SA.SA_ID) "); 
        getServiceTaskString.append("AND SATY.CIS_DIVISION = SA.CIS_DIVISION ");
        getServiceTaskString.append("AND SA.SA_TYPE_CD = SATY.SA_TYPE_CD "); 
        getServiceTaskString.append("AND SATY.DEBT_CL_CD = :debtClass "); 
        //Start Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        // PreparedStatement getServiceTaskPrepStmt = createPreparedStatement(getServiceTaskString.toString());
        PreparedStatement getServiceTaskPrepStmt = createPreparedStatement(getServiceTaskString.toString(), getClass().getName());
        //End Change - 2016-01-25 - MPang - Updated for CCB v2.4 compilation
        getServiceTaskPrepStmt.bindId("pledgeBO", parmPledgeBO.getId());
        getServiceTaskPrepStmt.bindId("debtClass", parmDebtclass.getId());
        getServiceTaskPrepStmt.bindStringProperty("svcTaskStatusCd", BusinessObjectStatus.properties.status, parmSvcTaskStatusCd.trim());
        getServiceTaskPrepStmt.bindId("svcTaskAcctCharType", parmSvcTaskAcctCharType.getId());
        getServiceTaskPrepStmt.bindId("saCharType", parmSvcTaskSACharType.getId());
        getServiceTaskPrepStmt.bindStringProperty("account", ServiceTaskCharacteristic.properties.characteristicValueForeignKey1, parmAccount.getId().getTrimmedValue());

        List<SQLResultRow> resultList = getServiceTaskPrepStmt.list();
        getServiceTaskPrepStmt.close();
        if(resultList.isEmpty()){
            isConditionSatisfied = Bool.FALSE;
        }else{
            isConditionSatisfied = Bool.TRUE;
        }
        return isConditionSatisfied;
    }
}
