/**************************************************************************
* Program Name: CmMassCancelRebillAndFreezeBillSegmentsBatch
* Program Title: CmMassCancelRebillAndFreezeBillSegmentsBatch
* Author: ACasta
* Creation Date: 2017-09-13
* Purpose: This Batch Program will read in a file that contains information
* that is necessary to perform cancel, rebill, and freezing of specified
* bill segments.
* Functional Spec: SA-224805
**************************************************************************/
/*-----------------------------------------------------------------------------------------------
 *----------------------------------- Modification HISTORY: -------------------------------------
 * ----------------------------------------------------------------------------------------------
 * Modification ID:   Author:         Date:         Description:
 * ----------------------------------------------------------------------------------------------
 * SA-224805          Alfonso Castano 2017-09-13    Initial Version
 * Defect 3873817     Abigail Umali   2017-10-02    Fix Array Index Out of Bounds Exception.
 * Story 38556        Bhaskar Yerr    2025-06-06    Adding Freezable status to mass rebill long bills
 ************************************************************************************************/
package com.splwg.cm.domain.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.splwg.base.api.ListFilter;
import com.splwg.base.api.batch.JobWork;
import com.splwg.base.api.batch.RunAbortedException;
import com.splwg.base.api.batch.StandardCommitStrategy;
import com.splwg.base.api.batch.ThreadAbortedException;
import com.splwg.base.api.batch.ThreadExecutionStrategy;
import com.splwg.base.api.batch.ThreadWorkUnit;
import com.splwg.base.api.batch.WorkUnitResult;
import com.splwg.base.api.datatypes.Bool;
import com.splwg.base.api.datatypes.Date;
import com.splwg.base.api.datatypes.DateFormat;
import com.splwg.base.api.datatypes.DateFormatParseException;
import com.splwg.base.api.lookup.CharacteristicTypeLookup;
import com.splwg.base.api.lookup.LogTypeLookup;
import com.splwg.base.api.lookup.ToDoEntryStatusLookup;
import com.splwg.base.domain.common.characteristicType.CharacteristicEntity_Id;
import com.splwg.base.domain.common.characteristicType.CharacteristicType;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryCharacteristic_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntryTransactionHistory_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_DTO;
import com.splwg.base.domain.todo.toDoEntry.ToDoEntry_Id;
import com.splwg.ccb.api.lookup.BillMessageTypeLookup;
import com.splwg.ccb.api.lookup.CharacteristicEntityLookup;
import com.splwg.ccb.domain.admin.billCancelReason.entity.BillCancelReason;
import com.splwg.ccb.domain.admin.billCancelReason.entity.BillCancelReason_Id;
import com.splwg.ccb.domain.admin.cisDivision.entity.CisDivision;
import com.splwg.ccb.domain.admin.customerContactClass.entity.CustomerContactClass;
import com.splwg.ccb.domain.admin.customerContactType.entity.CharacteristicTypeContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType;
import com.splwg.ccb.domain.admin.customerContactType.entity.CustomerContactType_Id;
import com.splwg.ccb.domain.billing.bill.entity.Bill;
import com.splwg.ccb.domain.billing.bill.entity.BillCharacteristic;
import com.splwg.ccb.domain.billing.bill.entity.BillCharacteristic_DTO;
import com.splwg.ccb.domain.billing.bill.entity.BillCharacteristics;
import com.splwg.ccb.domain.billing.bill.entity.Bill_Id;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment;
import com.splwg.ccb.domain.billing.billSegment.entity.BillSegment_Id;
import com.splwg.ccb.domain.billing.data.BillCompletionInputData;
import com.splwg.ccb.domain.billing.data.BillGenerationData;
import com.splwg.ccb.domain.customerinfo.account.entity.Account;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountMessage_DTO;
import com.splwg.ccb.domain.customerinfo.account.entity.AccountMessages;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_DTO;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContactCharacteristic_Id;
import com.splwg.ccb.domain.customerinfo.customerContact.entity.CustomerContact_DTO;
import com.splwg.ccb.domain.customerinfo.person.entity.Person;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic;
import com.splwg.ccb.domain.customerinfo.servicePoint.entity.ServicePointCharacteristic_DTO;
import com.splwg.cm.domain.customMessages.CustomMessageRepository;
import com.splwg.cm.domain.customMessages.CustomMessageRepositoryMGE;
import com.splwg.cm.domain.customMessages.CustomMessageRepositorySpireOne;
import com.splwg.shared.common.ApplicationError;
import com.splwg.shared.logging.Logger;
import com.splwg.shared.logging.LoggerFactory;

/**
 * @author ACasta
 *
@BatchJob (multiThreaded = false, rerunnable = true, modules = {},
 *      softParameters = { @BatchJobSoftParameter (name = FILE_PATH, required = true, type = string)
 *            , @BatchJobSoftParameter (name = FILE_NAME, required = true, type = string)
 *            , @BatchJobSoftParameter (entityName = customerContactClass, name = CUST_CONT_CL, type = entity)
 *            , @BatchJobSoftParameter (name = CUST_CONT_TYPE, type = string)
 *            , @BatchJobSoftParameter (entityName = billMessageType, name = BILL_MESSAGE_TYPE, type = entity)
 *            , @BatchJobSoftParameter (entityName = characteristicType, name = ALLOW_BC_CHAR, required = true, type = entity)})
 */
public class CmMassCancelRebillAndFreezeBillSegmentsBatch extends
        CmMassCancelRebillAndFreezeBillSegmentsBatch_Gen {

    // Soft Parameters
    private String filePath;
    private CustomerContactClass customerContactClass;
    private String customerContactTypeStr;
    private BigInteger paramMaxErrors;
  //B-38556 - 2025-06-06 - Start Add
    private static CharacteristicType billCharTypeAllowLongBill;
  //B-38556 - 2025-06-06 - End Add
    
    
    public JobWork getJobWork() {
        List<ThreadWorkUnit> arrayList = new ArrayList<ThreadWorkUnit>();
        ThreadWorkUnit threadWorkUnit = new ThreadWorkUnit();
        arrayList.add(threadWorkUnit);
        return createJobWorkForThreadWorkUnitList(arrayList);
    }

    @Override
    public void validateSoftParameters(boolean isNewRun) {
        retrieveBatchParameters();
        validateBatchParameters();
    }

    /**
     * This method retrieves all the soft Parameters of the batch
     */
    private void retrieveBatchParameters() {
        filePath = getParameters().getFILE_PATH();
        customerContactClass = getParameters().getCUST_CONT_CL();
        customerContactTypeStr = getParameters().getCUST_CONT_TYPE();
        paramMaxErrors = getParameters().getSoftMaxErrors();
      //B-38556 - 2025-06-06 - Start Add
        billCharTypeAllowLongBill = getParameters().getALLOW_BC_CHAR();
      //B-38556 - 2025-06-06 - End Add
    }
    
    /**
     * This method validates all the Soft Parameters of the Batch
     */
    private void validateBatchParameters(){
        // File Path
        File path = new File(filePath);
        if (!path.exists() || !path.isDirectory()){
            addError(CustomMessageRepository.SA_224805_invalidFilePath(filePath));
        }
        
        if (notNull(customerContactClass) && isNull(customerContactTypeStr)){
            addError(CustomMessageRepository.SA_224805_ccTypeMissing());
        }
        
        if (notNull(customerContactTypeStr) && isNull(customerContactClass)){
            addError(CustomMessageRepository.SA_224805_ccClassMissing());
        }
        
        // Max Errors
        if (notNull(paramMaxErrors) && paramMaxErrors.intValue() < 0) {
            addError(CustomMessageRepository.nm0101MaxErrorCannotBeLessThanZero(
                    paramMaxErrors.toString().trim()));
        }
        //B-38556 - 2025-06-06 - Start Add
        CharacteristicEntity_Id charEntity = new CharacteristicEntity_Id(billCharTypeAllowLongBill, CharacteristicEntityLookup.constants.BILL);
		if(isNull(charEntity.getEntity())){
		  addError(CustomMessageRepository.STORY_B_38556_InvalidBillChartype(billCharTypeAllowLongBill.getId().getIdValue().trim()));
		}
		//B-38556 - 2025-06-06 - End Add
    }
    
    public Class<CmMassCancelRebillAndFreezeBillSegmentsBatchWorker> getThreadWorkerClass() {
        return CmMassCancelRebillAndFreezeBillSegmentsBatchWorker.class;
    }

    public static class CmMassCancelRebillAndFreezeBillSegmentsBatchWorker
            extends CmMassCancelRebillAndFreezeBillSegmentsBatchWorker_Gen {

        // Soft parameter
        private int paramMaxErrors;
        private CustomerContactClass customerContactClass;
        private String customerContactTypeStr;
        
      //B-38556 - 2025-06-06 - Start Add
        private static CharacteristicType billCharTypeAllowLongBill;
      //B-38556 - 2025-06-06 - End Add
        
        // Counters
        private int processedRecord = 0;
        private int recordInError = 0;
        
        // Constants
        private static final DateFormat DATE_FORMAT = new DateFormat("yyyy-MM-dd");
        private static final int BILL_SEG = 0;
        private static final int CAN_RSN_CD = 1;
        private static final int CUTOFF_DT = 2;
        private static final int ACCOUNTING_DT = 3;
        private static final int ALLOW_EST_SW = 4;
        private static final int USE_OLD_INFO_SW = 5;
        private static final int BILLING_OPT_SW = 6;
        private static final int CC_COMMENTS = 7;
        
        private static final int TD_ENTRY_ID = 8;
        
        private static final String COMMA = ",";
        private static final String ACCOUNT = "ACCOUNT";
        
        // Record columns
        private BillSegment billSeg;
        private BillCancelReason cancelReason;
        private Date cutOffDt;
        private Date accountingDate;
        private Bool allowEstSw;
        private Bool useOldInfoSw;
        private Bool billingOptSw;
        
        // Work Parameters
        private Bool shouldCreateCC;
        private Bool shouldCreateAcctChar;
        private Bool shouldCreateBillMessage = Bool.FALSE;
        private CustomerContactType_Id customerContactTypeId;
      //B-38556 - 2025-06-06 - Start Add
        private Bool addBillChar = Bool.FALSE;
      //B-38556 - 2025-06-06 - End Add
        private static final Logger LG = LoggerFactory.getLogger(CmAnnualEAUsageAndPaymentBatch.class);
        
        public ThreadExecutionStrategy createExecutionStrategy() {
            return new StandardCommitStrategy(this);
        }

        @Override
        public void initializeThreadWork(
                boolean initializationPreviouslySuccessful)
                throws ThreadAbortedException, RunAbortedException {
            paramMaxErrors = this.getParameters().getSoftMaxErrors().intValue();
            customerContactClass = getParameters().getCUST_CONT_CL();
            customerContactTypeStr = getParameters().getCUST_CONT_TYPE();
            
          //B-38556 - 2025-06-06 - Start Add
            billCharTypeAllowLongBill = getParameters().getALLOW_BC_CHAR();
          //B-38556 - 2025-06-06 - End Add

            // Bill Message Type
            if (notNull(getParameters().getBILL_MESSAGE_TYPE())){
                shouldCreateBillMessage = Bool.TRUE;
            }
            
            // Customer Contact Type
            if (notNull(customerContactClass) && notNull(customerContactTypeStr)){
                if (validateCustomerContactType(customerContactClass, customerContactTypeStr).isFalse()){
                    addError(CustomMessageRepository.SA_224805_invalidCCClassCCTypeCombination(
                            customerContactClass.getId().getTrimmedValue(), customerContactTypeStr));
                } else {
                    shouldCreateCC = Bool.TRUE;
                    shouldCreateAcctChar = hasAccountCustomerContactChar(customerContactTypeId.getEntity());
                }
            } else {
                shouldCreateCC = Bool.FALSE;
            }
            
          //B-38556 - 2025-06-06 - Start Add
            CharacteristicEntity_Id charEntity = new CharacteristicEntity_Id(billCharTypeAllowLongBill, CharacteristicEntityLookup.constants.BILL);
    		if(isNull(charEntity.getEntity())){
    		  addError(CustomMessageRepository.STORY_B_38556_InvalidBillChartype(billCharTypeAllowLongBill.getId().getIdValue().trim()));
    		}
    		//B-38556 - 2025-06-06 - End Add
            
        }

        public WorkUnitResult executeWorkUnitDetailedResult(ThreadWorkUnit unit)
                throws ThreadAbortedException, RunAbortedException {
            // Open file
            String filePath = getParameters().getFILE_PATH();
            String fileName = getParameters().getFILE_NAME();
            
            File file = new File(filePath, fileName);
            BufferedReader reader = null;
            try {
                reader = new BufferedReader(new FileReader(file));
            } catch (FileNotFoundException e) {
                addError(CustomMessageRepository.SA_224805_errorOpeningInputFile(e.getMessage()));
            }
            
            // Read File
            Bool firstLine = Bool.TRUE;
            
            try {
                while (reader.ready()){
                    String record = reader.readLine();
                    // Ignore header
                    if (firstLine.isTrue()){
                        firstLine = Bool.FALSE;
                        continue;
                    }
                    
                    processedRecord++;
                    
                    String[] columns = record.split(COMMA);
                    
                    // Set columns
                    // Validate Bill Segment
                    String billSegIdStr = columns[BILL_SEG];
                    billSeg = new BillSegment_Id(billSegIdStr.trim()).getEntity();
                    if (isNull(billSeg)){
                        recordInError++;
                        if (recordInError > paramMaxErrors){
                            throw new RunAbortedException(CustomMessageRepositoryMGE.commMaxErrorLimitExceeded(String.valueOf(paramMaxErrors)));
                        } else {
                            logError(CustomMessageRepository.SA_224805_billSegmentNotFound(billSegIdStr.trim()));
                            continue;
                        }
                    }
                    
                    //B-38556 - 2025-06-06 - Start Add
                    //if (!(billSeg.getBillSegmentStatus().isFrozen()){
                    if (!(billSeg.getBillSegmentStatus().isFrozen() || billSeg.getBillSegmentStatus().isFreezable())){
                    //B-38556 - 2025-06-06 - End Add
                        recordInError++;
                        if (recordInError > paramMaxErrors){
                            throw new RunAbortedException(CustomMessageRepositoryMGE.commMaxErrorLimitExceeded(String.valueOf(recordInError)));
                        } else {
                            logError(CustomMessageRepository.SA_224805_billSegmentNotFrozen(billSeg.getId().getIdValue()));
                            continue;
                        }
                    }
                    //B-38556 - 2025-06-05 - End Add
                    
                    // Validate Cancel Reason Code
                    String cancelRsnCdStr = columns[CAN_RSN_CD];
                    cancelReason = new BillCancelReason_Id(cancelRsnCdStr).getEntity();
                    if (isNull(cancelReason)){
                        recordInError++;
                        if (recordInError > paramMaxErrors){
                            throw new RunAbortedException(CustomMessageRepositoryMGE.commMaxErrorLimitExceeded(String.valueOf(recordInError)));
                        } else {
                            logError(CustomMessageRepository.SA_224805_invalidCancelReason(cancelRsnCdStr.trim()));
                            continue;
                        }
                    }
                    
                    // Validate Cutoff Date. if not populated, use the Bill Segment's End Date 
                    String cutOffDateStr = columns[CUTOFF_DT];
                    if (isEmptyOrNull(cutOffDateStr)){
                        cutOffDt = billSeg.getEndDate();
                    } else {
                        try {
                            cutOffDt = DATE_FORMAT.parseDate(cutOffDateStr);
                        } catch (DateFormatParseException e) {
                            recordInError++;
                            if (recordInError > paramMaxErrors){
                                throw new RunAbortedException(CustomMessageRepositoryMGE.commMaxErrorLimitExceeded(String.valueOf(recordInError)));
                            } else {
                                logError(CustomMessageRepository.SA_224805_invalidCutoffEndDate());
                                continue;
                            }
                        }
                    }
                    
                    // Validate Account Date. if not populated, use current processing date 
                    String accountingDateStr = columns[ACCOUNTING_DT];
                    if (isEmptyOrNull(accountingDateStr)){
                        accountingDate = getProcessDateTime().getDate();
                    } else {
                        try {
                            accountingDate = DATE_FORMAT.parseDate(accountingDateStr);
                        } catch (DateFormatParseException e) {
                            recordInError++;
                            if (recordInError > paramMaxErrors){
                                throw new RunAbortedException(CustomMessageRepositoryMGE.commMaxErrorLimitExceeded(String.valueOf(recordInError)));
                            } else {
                                logError(CustomMessageRepository.SA_224805_invalidAccountingDate());
                                continue;
                            }
                        }
                    }
                    
                    // Validate Allow Estimate Switch. if not populated, default value is N
                    String allowEstSwStr = columns[ALLOW_EST_SW];
                    if (isEmptyOrNull(allowEstSwStr)){
                        allowEstSw = Bool.FALSE;
                    } else {
                        if (allowEstSwStr.equalsIgnoreCase("Y")){
                            allowEstSw = Bool.TRUE;
                        } else {
                            allowEstSw = Bool.FALSE;
                        }
                    }
                    
                    // Validate Old Info Switch. if not populated, default value is N
                    String useOldInfoSwStr = columns[USE_OLD_INFO_SW];
                    if (isEmptyOrNull(useOldInfoSwStr)){
                        useOldInfoSw = Bool.FALSE;
                    } else {
                        if (useOldInfoSwStr.equalsIgnoreCase("Y")){
                        	useOldInfoSw = Bool.TRUE;
                        } else {
                        	useOldInfoSw = Bool.FALSE;
                        }
                    }
                    
                    // Validate Billing Option Switch. if not populated, default value is N
                    String billingOptSwStr = columns[BILLING_OPT_SW];
                    
                    if (isEmptyOrNull(billingOptSwStr)){
                        billingOptSw = Bool.TRUE;
                    } else {
                        if (billingOptSwStr.equalsIgnoreCase("Y")){
                        	billingOptSw = Bool.TRUE;
                        } else {
                        	billingOptSw = Bool.FALSE;
                        }
                    }
                                        
                    // Process Record
                  //B-38556 - 2025-06-06 - Start Add
                    //billSeg.cancelReBillAndFreeze(cancelReason, cutOffDt, 
                    //        accountingDate, allowEstSw, billingOptSw, useOldInfoSw);
                    Bill_Id billId = billSeg.getBillId();
                    if(billSeg.getBillSegmentStatus().isFrozen()){
                    	billSeg.cancelReBillAndFreeze(cancelReason, cutOffDt, 
                                accountingDate, allowEstSw, billingOptSw, useOldInfoSw);
                    	addBillChar = Bool.TRUE;
                    }else if(billSeg.getBillSegmentStatus().isFreezable()){
                    	
                    	
                    	//Free the bill segment and perform cancel and rebill on bill segment
                    	billSeg.freeze(this.getProcessDateTime().toDate());
                    	billSeg.cancelReBillAndFreeze(cancelReason, cutOffDt, 
                                accountingDate, allowEstSw, billingOptSw, useOldInfoSw);
                    	
    					//After generating a bill, create a customer contact
    					//Set addBillChar to true
    					addBillChar = Bool.TRUE;
                    }
                    
                    //Complete ToDO entry
                    if(columns.length > 8){
                    	String todoId = columns[TD_ENTRY_ID];
                        if(!isEmptyOrNull(todoId)){
                        	ToDoEntry_Id tdEntryID = new ToDoEntry_Id(todoId);
                            ToDoEntry tdEntry = tdEntryID.getEntity();
                            if(!isNull(tdEntry)){
                            	ToDoEntry_DTO tdEntryDto = tdEntry.getDTO();
                                tdEntryDto.setToDoEntryStatus(ToDoEntryStatusLookup.constants.COMPLETED);
                                tdEntryDto.setCompletedDatetime(this.getProcessDateTime());
                                tdEntryDto.setCompletedByUserId(this.getActiveContextUser().getId());
                                tdEntryDto.setComments("Completed by CM-MCRBS");
                                tdEntry.setDTO(tdEntryDto);
                                addLogEntry(tdEntry);
                            }else{
                            	logError(CustomMessageRepository.STORY_B_38556_ToDoId_Not_Valid(todoId));
                            } 
                        }
                    }
                    
                    /*
                     *  // Retrieve any existing value for this Characteristic
                    ServicePointCharacteristic effectiveCharacteristic = servicePointInCCB.getEffectiveCharacteristic(stagingCharType);
                    String effectiveValue = "";
                    if (notNull(effectiveCharacteristic)) {
                        effectiveValue = getCharacteristicValueAsString(effectiveCharacteristic.toCharacteristicInterface());
                        
                        // Do not process outdated value
                        if (effectiveCharacteristic.fetchIdEffectiveDate().isAfter(stagingEffectiveDate)) {
                            continue;
                        }
                        
                    }
                    
                    // Add or update the Characteristic if the values are different
                    if (!effectiveValue.trim().equals(stagingValue)) {
                        
                        if (notNull(effectiveCharacteristic)
                                && stagingEffectiveDate.equals(effectiveCharacteristic.fetchIdEffectiveDate())) {
                            
                            CharacteristicTypeLookup typeOfCharacteristic = stagingCharType.getCharacteristicType();
                            ServicePointCharacteristic_DTO servicePointCharacteristicDTO = effectiveCharacteristic.getDTO();                     
                            if (typeOfCharacteristic.isPredefinedValue()) {
                                servicePointCharacteristicDTO.setCharacteristicValue(stagingValue);
                            } else if(typeOfCharacteristic.isForeignKeyValue()) {
                                servicePointCharacteristicDTO.setCharacteristicValueForeignKey1(stagingValue);
                            } else {
                                servicePointCharacteristicDTO.setAdhocCharacteristicValue(stagingValue);
                            }
                    
                    */
                    //Add the allow long bill completion characteristic to the bill
                    Bill_Id  billID = new Bill_Id(billId.getIdValue());
                	Bill bill= billID.getEntity();
                
                	/*
                	 List<BillCharacteristic> billCharacteristics = new ArrayList<BillCharacteristic>(bill.getCharacteristics().asSet());
                     for (BillCharacteristic billCharacteristic : billCharacteristics) {
                         if (billCharacteristic.fetchIdCharacteristicType().equals(billCharTypeAllowLongBill.getCharacteristicType())) {
                        	 addBillChar = Bool.FALSE;
                         }
                     }*/
                	
                     ListFilter<BillCharacteristic> billCharFilter = bill.getCharacteristics().createFilter("where this.id.characteristicType = :billBypassCharType " +
                 			"and this.searchCharacteristicValue = :billBypassCharVal " , getClass().getName());
                 	billCharFilter.bindId("billBypassCharType", billCharTypeAllowLongBill.getId());
                 	billCharFilter.bindStringProperty("billBypassCharVal", BillCharacteristic.properties.searchCharacteristicValue, "Y");
                     BillCharacteristic billChar = billCharFilter.firstRow();  
                 	if(notNull(billChar)) {
                 		addBillChar = Bool.FALSE;
                 	}
                     
                     
                    if(addBillChar.isTrue() && bill.getBillStatus().isPending()){
                    	billID = new Bill_Id(billId.getIdValue());
                    	bill= billID.getEntity();
                    	BillCharacteristics billChars = bill.getCharacteristics();
                    	BillCharacteristic_DTO billCharDto = bill.getCharacteristics().newChildDTO();
                    	if(billCharTypeAllowLongBill.getCharacteristicType().isAdhocValue()) {
                    		billCharDto.setAdhocCharacteristicValue("Y");
                        } else if(billCharTypeAllowLongBill.getCharacteristicType().isForeignKeyValue()) {
                        	billCharDto.setCharacteristicValueForeignKey1("Y");
                        } else {
                        	billCharDto.setCharacteristicValue("Y");
                        }
                    	billCharDto.setSearchCharacteristicValue("Y");
                        
                    	billChars.add(billCharDto, billCharTypeAllowLongBill.getId(), BigInteger.ONE); 
                    	
                    }
                    
                    //B-38556 - 2025-06-06 - End Add
                    
                    
                    Account account = billSeg.getBillId().getEntity().getAccount();

                    /*
                     * Defect 3873817 - 2017-10-02 - Start Add
                     */
                    if (shouldCreateCC.isTrue()){
                        Person mainPerson = account.getMainPerson();
                        if(columns.length == 8){
                        	String ccCommentsStr = columns[CC_COMMENTS];
                        	createCustomerContact(mainPerson, account, ccCommentsStr.trim());
                        } else{
                        	createCustomerContact(mainPerson, account, null);
                        }
                    }
                    /*
                     * Defect 3873817 - 2017-10-02 - End Add
                     */                   	
                }
                reader.close();
            } catch (IOException e){
                addError(CustomMessageRepository.SA_224805_errorOpeningInputFile(e.getMessage()));
            }
            WorkUnitResult result = new WorkUnitResult(true);
            result.setUnitsProcessed(processedRecord);
            result.setUnitsInError(recordInError);
            return result;
        }
        
        //B-38556 - 2025-06-16 - Start Add
        private void addLogEntry(ToDoEntry entry) {
        	
        	ToDoEntry toDoEntry = entry;
            ToDoEntryTransactionHistory_DTO logDto = toDoEntry.getTransactionHistories().newChildDTO();
            logDto.setLogType(LogTypeLookup.constants.COMPLETED);
            //logDto.setUserId(user.getId());
            logDto.setLogDateTime(getProcessDateTime());
            //logDto.setAssignedToUserId(user.getId());
            BigInteger logSequenceNumber = toDoEntry.getNextLogEntrySequence();
            toDoEntry.getTransactionHistories().add(logDto, logSequenceNumber);
            
        }
        //B-38556 - 2025-06-16 - End Add
        
        /**
         * This method validates Customer Contact Type.
         * @param customerContactClass - Customer Contact Class
         * @param customerContactType - String
         * @return Bool
         */
        private Bool validateCustomerContactType(CustomerContactClass customerContactClass, String customerContactType) {
            
            customerContactTypeId = new CustomerContactType_Id(customerContactClass, customerContactType);
            if (isNull(customerContactTypeId.getEntity())) { 
                return Bool.FALSE;
            }
            
            return Bool.TRUE;
        }
        
        /**
         * This method checks if the Customer Contact Type has a required ACCOUNT char
         * @param customerContactType
         * @return Bool
         */
        private Bool hasAccountCustomerContactChar(CustomerContactType customerContactType) {

            Bool hasAccountChar = Bool.FALSE;
            ListFilter<CharacteristicTypeContactType> charTypeFilter = customerContactType
                    .getCharacteristicTypeContactTypes()
                    .createFilter(
                            " WHERE this.isRequired = :isRequired ",
                            getClass().getName());
            charTypeFilter.bindBoolean("isRequired", Bool.TRUE);
            
            CharacteristicTypeContactType characteristicTypeContactType = null;
            for (Iterator<CharacteristicTypeContactType> iterator = 
                    charTypeFilter.list().iterator(); iterator.hasNext();) {
                
                characteristicTypeContactType = iterator.next();
                
                // If any other required CHAR is found, issue error
                if (!characteristicTypeContactType.fetchIdCharacteristicType().getId()
                        .getTrimmedValue().equals(ACCOUNT)){
                    addError(CustomMessageRepository.SA_224805_unableToUseCCClassAndCCTypeForCancelRebill(
                            customerContactClass.getId().getTrimmedValue(), customerContactTypeStr));
                } else {
                    hasAccountChar = Bool.TRUE;
                }
            }
            
            return hasAccountChar;
        }
        
        /**
         * This method creates Customer Contact
         * @param Person - person
         * @param String - comment
         */
        private void createCustomerContact(Person person, Account account, String comments){
            CustomerContact_DTO ccDTO = (CustomerContact_DTO) createDTO(CustomerContact.class);
            
            ccDTO.setContactDateTime(getProcessDateTime());
            ccDTO.setCustomerContactTypeId(customerContactTypeId);
            ccDTO.setPersonId(person.getId());
            ccDTO.setShouldPrintLetter(Bool.FALSE);
            if (!isEmptyOrNull(comments)){
                ccDTO.setLongDescription(comments.trim());
            } else {
                ccDTO.setLongDescription(CustomMessageRepository.
                        SA_224805_billSegmentForAccountWasRebilled(billSeg.getId().getTrimmedValue(), 
                                account.getId().getTrimmedValue()).getMessageText());
            }
            CustomerContact customerContact = ccDTO.newEntity();
            
            if (shouldCreateAcctChar.isTrue()){
                for (Iterator<CharacteristicTypeContactType> iter = customerContactTypeId.getEntity()
                        .getCharacteristicTypeContactTypes().iterator(); iter.hasNext();){
                    CharacteristicTypeContactType ccTypeCharType = (CharacteristicTypeContactType) iter.next();
                    CharacteristicType charType = ccTypeCharType.getId().getCharacteristicType();
                    
                    CustomerContactCharacteristic_DTO ccCharDTO = (CustomerContactCharacteristic_DTO) createDTO(CustomerContactCharacteristic.class);
                    CharacteristicTypeLookup charTypeLookup = charType.getCharacteristicType();
                    
                    if (charTypeLookup.isPredefinedValue()){
                        ccCharDTO.setCharacteristicValue(account.getId().getTrimmedValue());
                    }
                    else if (charTypeLookup.isForeignKeyValue()){
                        ccCharDTO.setCharacteristicValueForeignKey1(account.getId().getTrimmedValue());
                    }
                    else {
                        ccCharDTO.setAdhocCharacteristicValue(account.getId().getTrimmedValue());
                    }
                    
                    ccCharDTO.setId(new CustomerContactCharacteristic_Id(charType, customerContact));
                    ccCharDTO.newEntity();
                }
            }
            
            if (shouldCreateBillMessage.isTrue()){
                AccountMessages acctMessages = account.getMessages();
                AccountMessage_DTO acctMessageDTO = acctMessages.newChildDTO();
                acctMessageDTO.setBillMessageType(BillMessageTypeLookup.constants.TEMPORARY);
                acctMessages.add(acctMessageDTO, getParameters().getBILL_MESSAGE_TYPE().getId());
            }
        }
    }
}