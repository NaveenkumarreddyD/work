package com.splwg.cm.api.lookup;

/**
 * @author TMG02493
 *
@LookupFieldname (value = CM_SSI_INF_FLG)
 */
public class CmInformationFlagLookup_Impl extends CmInformationFlagLookup_Gen {

}
